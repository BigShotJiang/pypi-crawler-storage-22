"""
Compression-as-a-Service: LLM Auto-Evaluator

Automatically evaluates compression quality via LLM and feeds scores back
to the AdaptiveLearner, closing the learning loop without manual feedback.

Data flow:
    compress() → result → should_evaluate() → evaluate_compression()
        → LLM scores quality → learner.record_feedback()

Components:
    EvaluatorConfig — configuration dataclass with env var loading
    openai_llm_call — default LLM callable using openai.AsyncOpenAI
    LLMEvaluator — orchestrates sampling, prompting, parsing, and feedback
"""

from __future__ import annotations

import json
import logging
import os
import random
import re
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Dict, List, Optional, Tuple

from .caas_adaptive import AdaptiveLearner

logger = logging.getLogger(__name__)

# Type alias for injectable LLM callable
LLMCallable = Callable[[str, List[Dict[str, str]], int, float], Awaitable[str]]


# ---------------------------------------------------------------------------
# 1. EvaluationRecord
# ---------------------------------------------------------------------------

@dataclass
class EvaluationRecord:
    """A single evaluation result stored in history."""

    request_id: str
    timestamp: float
    strategy: str
    content_type: str
    compression_ratio: float
    token_reduction_pct: float
    score: float
    reason: str
    model: str

    def to_dict(self) -> Dict[str, Any]:
        """Convert to a JSON-serializable dict."""
        return {
            "request_id": self.request_id,
            "timestamp": self.timestamp,
            "strategy": self.strategy,
            "content_type": self.content_type,
            "compression_ratio": self.compression_ratio,
            "token_reduction_pct": self.token_reduction_pct,
            "score": self.score,
            "reason": self.reason,
            "model": self.model,
        }


# ---------------------------------------------------------------------------
# 2. EvaluatorConfig
# ---------------------------------------------------------------------------

@dataclass
class EvaluatorConfig:
    """Configuration for the LLM auto-evaluator."""

    enabled: bool = False
    api_key: str = ""
    model: str = "gpt-4o-mini"
    sample_rate: float = 0.1
    max_content_chars: int = 2000
    max_tokens: int = 150
    timeout_seconds: float = 10.0
    auto_rebuild_interval: int = 100

    @classmethod
    def from_env(cls) -> EvaluatorConfig:
        """Create config from environment variables."""
        return cls(
            enabled=os.getenv("CAAS_EVAL_ENABLED", "false").lower() in ("true", "1", "yes"),
            api_key=os.getenv("OPENAI_API_KEY", ""),
            model=os.getenv("CAAS_EVAL_MODEL", "gpt-4o-mini"),
            sample_rate=float(os.getenv("CAAS_EVAL_SAMPLE_RATE", "0.1")),
            max_content_chars=int(os.getenv("CAAS_EVAL_MAX_CONTENT_CHARS", "2000")),
            max_tokens=int(os.getenv("CAAS_EVAL_MAX_TOKENS", "150")),
            timeout_seconds=float(os.getenv("CAAS_EVAL_TIMEOUT", "10.0")),
            auto_rebuild_interval=int(os.getenv("CAAS_EVAL_AUTO_REBUILD", "100")),
        )


# ---------------------------------------------------------------------------
# 2. openai_llm_call (default LLM callable)
# ---------------------------------------------------------------------------

async def openai_llm_call(
    model: str,
    messages: List[Dict[str, str]],
    max_tokens: int,
    timeout: float,
) -> str:
    """Default LLM callable using openai.AsyncOpenAI.

    Created inside function body so a missing API key doesn't crash on import.
    """
    import openai

    client = openai.AsyncOpenAI(timeout=timeout)
    response = await client.chat.completions.create(
        model=model,
        messages=messages,
        max_tokens=max_tokens,
        temperature=0.0,
    )
    return response.choices[0].message.content or ""


# ---------------------------------------------------------------------------
# 4. LLMEvaluator
# ---------------------------------------------------------------------------

_SYSTEM_PROMPT = (
    "You are a compression quality evaluator. Rate the quality of a compression "
    "on a 0-1 scale:\n"
    "  1.0 = perfect — all meaning preserved, highly readable\n"
    "  0.8 = good — minor details lost, still very usable\n"
    "  0.5 = acceptable — noticeable losses but core meaning intact\n"
    "  0.3 = poor — significant information lost, hard to use\n"
    "  0.0 = unusable — meaning destroyed or output is garbage\n\n"
    'Respond with JSON: {"score": <float>, "reason": "<brief>"}'
)


class LLMEvaluator:
    """Evaluates compression quality via LLM and feeds scores to AdaptiveLearner.

    Args:
        learner: The adaptive learner to receive feedback scores.
        config: Evaluator configuration.
        llm_call: Optional injectable LLM callable (for testing).
                  Falls back to openai_llm_call if None.
    """

    def __init__(
        self,
        learner: AdaptiveLearner,
        config: Optional[EvaluatorConfig] = None,
        llm_call: Optional[LLMCallable] = None,
    ) -> None:
        self._learner = learner
        self._config = config or EvaluatorConfig()
        self._llm_call = llm_call or openai_llm_call
        self._evaluations_completed: int = 0
        self._evaluation_errors: int = 0
        self._history: deque[EvaluationRecord] = deque(maxlen=1000)
        self._evals_since_rebuild: int = 0
        self._auto_rebuilds: int = 0

    def should_evaluate(self) -> bool:
        """Decide whether to evaluate this request (sampling gate)."""
        if not self._config.enabled:
            return False
        if not self._config.api_key and self._llm_call is openai_llm_call:
            return False
        if self._config.sample_rate <= 0:
            return False
        if self._config.sample_rate >= 1.0:
            return True
        return random.random() < self._config.sample_rate

    async def evaluate_compression(
        self,
        request_id: str,
        original_content: str,
        compressed_content: str,
        strategy: str,
        content_type: str,
        compression_ratio: float,
        token_reduction_pct: float,
    ) -> None:
        """Evaluate a compression via LLM and submit feedback to learner.

        This method is fire-and-forget safe — all exceptions are caught and
        counted in evaluation_errors.
        """
        try:
            # Truncate content to limit prompt size
            max_chars = self._config.max_content_chars
            original_truncated = original_content[:max_chars]
            compressed_truncated = compressed_content[:max_chars]

            if len(original_content) > max_chars:
                original_truncated += f"\n... [truncated, {len(original_content)} chars total]"
            if len(compressed_content) > max_chars:
                compressed_truncated += f"\n... [truncated, {len(compressed_content)} chars total]"

            messages = self._build_prompt(
                original_truncated,
                compressed_truncated,
                strategy,
                content_type,
                compression_ratio,
                token_reduction_pct,
            )

            raw_response = await self._llm_call(
                self._config.model,
                messages,
                self._config.max_tokens,
                self._config.timeout_seconds,
            )

            score, reason = self._parse_response(raw_response)
            if score is None:
                logger.warning(
                    "Could not parse score from LLM response for request %s: %s",
                    request_id,
                    raw_response[:200],
                )
                self._evaluation_errors += 1
                return

            self._learner.record_feedback(request_id, score)
            self._evaluations_completed += 1

            self._history.append(EvaluationRecord(
                request_id=request_id,
                timestamp=time.time(),
                strategy=strategy,
                content_type=content_type,
                compression_ratio=compression_ratio,
                token_reduction_pct=token_reduction_pct,
                score=score,
                reason=reason,
                model=self._config.model,
            ))

            self._evals_since_rebuild += 1
            if (self._config.auto_rebuild_interval > 0
                    and self._evals_since_rebuild >= self._config.auto_rebuild_interval):
                self._evals_since_rebuild = 0
                policies = self._learner.rebuild_policies()
                self._auto_rebuilds += 1
                logger.info(
                    "Auto-rebuilt %d policies after %d evaluations",
                    policies, self._config.auto_rebuild_interval,
                )

        except Exception:
            logger.exception("Evaluation failed for request %s", request_id)
            self._evaluation_errors += 1

    def _build_prompt(
        self,
        original: str,
        compressed: str,
        strategy: str,
        content_type: str,
        compression_ratio: float,
        token_reduction_pct: float,
    ) -> List[Dict[str, str]]:
        """Build the system + user messages for the LLM evaluation call."""
        user_content = (
            f"Content type: {content_type}\n"
            f"Strategy: {strategy}\n"
            f"Compression ratio: {compression_ratio:.2f}\n"
            f"Token reduction: {token_reduction_pct:.1f}%\n\n"
            f"--- ORIGINAL ---\n{original}\n\n"
            f"--- COMPRESSED ---\n{compressed}"
        )
        return [
            {"role": "system", "content": _SYSTEM_PROMPT},
            {"role": "user", "content": user_content},
        ]

    @staticmethod
    def _parse_response(raw_response: str) -> Tuple[Optional[float], str]:
        """Parse a quality score and reason from the LLM response.

        Tries JSON first, then regex fallback for bare floats.
        Clamps score to [0, 1]. Returns (None, "") if unparseable.
        """
        # Try JSON parse
        try:
            data = json.loads(raw_response)
            if isinstance(data, dict) and "score" in data:
                score = float(data["score"])
                reason = str(data.get("reason", ""))
                return max(0.0, min(1.0, score)), reason
        except (json.JSONDecodeError, ValueError, TypeError):
            pass

        # Regex fallback: look for a float-like number
        match = re.search(r"\b([01](?:\.\d+)?|0?\.\d+)\b", raw_response)
        if match:
            score = float(match.group(1))
            return max(0.0, min(1.0, score)), ""

        return None, ""

    # Keep backward-compatible alias
    @staticmethod
    def _parse_score(raw_response: str) -> Optional[float]:
        """Parse a quality score from the LLM response (compat shim)."""
        score, _ = LLMEvaluator._parse_response(raw_response)
        return score

    def get_history(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Return most recent evaluation records as dicts (newest first)."""
        records = list(self._history)
        records.reverse()
        return [r.to_dict() for r in records[:limit]]

    def get_stats(self) -> Dict[str, Any]:
        """Return evaluator statistics."""
        return {
            "evaluations_completed": self._evaluations_completed,
            "evaluation_errors": self._evaluation_errors,
            "enabled": self._config.enabled,
            "sample_rate": self._config.sample_rate,
            "model": self._config.model,
            "auto_rebuilds": self._auto_rebuilds,
            "auto_rebuild_interval": self._config.auto_rebuild_interval,
        }
