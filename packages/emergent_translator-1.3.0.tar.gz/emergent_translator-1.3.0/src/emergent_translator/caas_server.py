"""
Compression-as-a-Service (CaaS) — FastAPI Server

Standalone API that auto-detects content types and applies optimal compression
strategies to reduce LLM token usage.

Run with:
    uvicorn src.emergent_translator.caas_server:app --reload --port 8002
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import threading
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from fastapi import Depends, FastAPI, HTTPException, Request, Response, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel, Field

from .caas_adaptive import AdaptiveLearner
from .caas_engine import CompressionEngine, ContentDetector
from .caas_evaluator import EvaluatorConfig, LLMEvaluator
from .caas_strategies import CompressedResult, CompressionLevel

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

CAAS_AUTH_TOKEN = os.getenv("CAAS_AUTH_TOKEN", os.getenv("API_AUTH_TOKEN", ""))
CAAS_ENABLE_AUTH = os.getenv("CAAS_ENABLE_AUTH", "false").lower() in ("true", "1", "yes")
MAX_CONTENT_SIZE = 5 * 1024 * 1024  # 5MB


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------

security = HTTPBearer(auto_error=False)


async def verify_auth(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security),
) -> str:
    """Verify authentication token.

    Returns the bearer token (or 'anonymous' if auth is disabled).
    """
    if not CAAS_ENABLE_AUTH:
        token = credentials.credentials if credentials else "anonymous"
        return token

    if not credentials:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication required",
            headers={"WWW-Authenticate": "Bearer"},
        )

    if CAAS_AUTH_TOKEN and credentials.credentials != CAAS_AUTH_TOKEN:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication token",
            headers={"WWW-Authenticate": "Bearer"},
        )

    return credentials.credentials


def _hash_token(token: str) -> str:
    """Hash a token for privacy-safe storage."""
    return hashlib.sha256(token.encode()).hexdigest()[:8]


# ---------------------------------------------------------------------------
# Usage Tracking
# ---------------------------------------------------------------------------

@dataclass
class TokenUsage:
    """Usage stats for a single API token."""
    requests: int = 0
    bytes_in: int = 0
    bytes_out: int = 0
    tokens_saved: int = 0
    errors: int = 0
    first_seen: float = field(default_factory=time.time)
    last_seen: float = field(default_factory=time.time)


class CaaSUsageTracker:
    """Thread-safe per-token usage tracking."""

    def __init__(self) -> None:
        self._usage: Dict[str, TokenUsage] = {}
        self._lock = threading.Lock()

    def record(
        self,
        token: str,
        bytes_in: int = 0,
        bytes_out: int = 0,
        tokens_saved: int = 0,
        error: bool = False,
    ) -> None:
        key = _hash_token(token)
        with self._lock:
            if key not in self._usage:
                self._usage[key] = TokenUsage()
            u = self._usage[key]
            u.requests += 1
            u.bytes_in += bytes_in
            u.bytes_out += bytes_out
            u.tokens_saved += tokens_saved
            u.last_seen = time.time()
            if error:
                u.errors += 1

    def get_usage(self, token: str) -> Optional[Dict[str, Any]]:
        key = _hash_token(token)
        with self._lock:
            u = self._usage.get(key)
            if u is None:
                return None
            return {
                "requests": u.requests,
                "bytes_in": u.bytes_in,
                "bytes_out": u.bytes_out,
                "tokens_saved": u.tokens_saved,
                "errors": u.errors,
                "first_seen": u.first_seen,
                "last_seen": u.last_seen,
            }

    def global_stats(self) -> Dict[str, Any]:
        with self._lock:
            total_requests = sum(u.requests for u in self._usage.values())
            total_tokens_saved = sum(u.tokens_saved for u in self._usage.values())
            total_errors = sum(u.errors for u in self._usage.values())
            return {
                "total_requests": total_requests,
                "total_tokens_saved": total_tokens_saved,
                "total_errors": total_errors,
                "active_users": len(self._usage),
            }


# ---------------------------------------------------------------------------
# Global Stats
# ---------------------------------------------------------------------------

class GlobalStats:
    """Aggregate compression statistics."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self.total_requests: int = 0
        self.total_tokens_saved: int = 0
        self.total_bytes_in: int = 0
        self.total_bytes_out: int = 0
        self._reduction_sum: float = 0.0
        self.requests_by_strategy: Dict[str, int] = {}
        self.requests_by_content_type: Dict[str, int] = {}

    def record(self, result: CompressedResult, content_type: str) -> None:
        with self._lock:
            self.total_requests += 1
            saved = result.original_tokens - result.compressed_tokens
            self.total_tokens_saved += max(0, saved)
            self.total_bytes_in += result.original_size
            self.total_bytes_out += result.compressed_size
            self._reduction_sum += result.token_reduction_pct

            self.requests_by_strategy[result.strategy] = (
                self.requests_by_strategy.get(result.strategy, 0) + 1
            )
            self.requests_by_content_type[content_type] = (
                self.requests_by_content_type.get(content_type, 0) + 1
            )

    def to_dict(self) -> Dict[str, Any]:
        with self._lock:
            avg_reduction = (
                self._reduction_sum / self.total_requests
                if self.total_requests > 0
                else 0.0
            )
            return {
                "total_requests": self.total_requests,
                "total_tokens_saved": self.total_tokens_saved,
                "total_bytes_in": self.total_bytes_in,
                "total_bytes_out": self.total_bytes_out,
                "average_reduction_pct": round(avg_reduction, 1),
                "requests_by_strategy": dict(self.requests_by_strategy),
                "requests_by_content_type": dict(self.requests_by_content_type),
            }


# ---------------------------------------------------------------------------
# Request / Response Models
# ---------------------------------------------------------------------------

class CompressRequest(BaseModel):
    content: str = Field(..., max_length=MAX_CONTENT_SIZE, description="Content to compress")
    content_type: Optional[str] = Field(
        None, description='Content type (e.g., "code/python", "data/json"). Auto-detected if omitted.'
    )
    filename_hint: Optional[str] = Field(
        None, description='Filename hint for auto-detection (e.g., "app.ts").'
    )
    level: CompressionLevel = Field(
        CompressionLevel.balanced, description="Compression level"
    )
    options: Optional[Dict[str, Any]] = Field(
        None, description="Strategy-specific options"
    )


class CompressResponse(BaseModel):
    success: bool
    compressed: str
    content_type: str
    strategy: str
    original_size: int
    compressed_size: int
    original_tokens: int
    compressed_tokens: int
    compression_ratio: float
    token_reduction_pct: float
    processing_time_ms: float
    request_id: Optional[str] = None
    recommended_level: Optional[str] = None
    metadata: Dict[str, Any] = {}


class BatchCompressRequest(BaseModel):
    items: List[CompressRequest] = Field(
        ..., min_length=1, max_length=50, description="Up to 50 items to compress"
    )


class BatchCompressResponse(BaseModel):
    success: bool
    results: List[CompressResponse]
    total_original_tokens: int
    total_compressed_tokens: int
    total_token_reduction_pct: float
    total_processing_time_ms: float


class ErrorResponse(BaseModel):
    success: bool = False
    error: str
    request_id: Optional[str] = None


class FeedbackRequest(BaseModel):
    request_id: str = Field(..., description="Request ID from a previous compression")
    quality_score: float = Field(..., ge=0.0, le=1.0, description="Quality score 0-1")
    notes: Optional[str] = Field(None, description="Optional notes about the quality assessment")


class FeedbackResponse(BaseModel):
    success: bool
    request_id: str
    matched: bool
    message: str


# ---------------------------------------------------------------------------
# Middleware
# ---------------------------------------------------------------------------

class RequestIDMiddleware:
    """Add X-Request-ID header to all requests."""

    def __init__(self, app: Any) -> None:
        self.app = app

    async def __call__(self, scope: Any, receive: Any, send: Any) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        request_id = None
        for header_name, header_value in scope.get("headers", []):
            if header_name == b"x-request-id":
                request_id = header_value.decode()
                break

        if not request_id:
            request_id = str(uuid.uuid4())

        scope["state"] = scope.get("state", {})
        scope["state"]["request_id"] = request_id

        async def send_with_id(message: Any) -> None:
            if message["type"] == "http.response.start":
                headers = list(message.get("headers", []))
                headers.append((b"x-request-id", request_id.encode()))
                message["headers"] = headers
            await send(message)

        await self.app(scope, receive, send_with_id)


class LimitRequestSizeMiddleware:
    """Reject requests exceeding a size limit."""

    def __init__(self, app: Any, max_size: int = MAX_CONTENT_SIZE) -> None:
        self.app = app
        self.max_size = max_size

    async def __call__(self, scope: Any, receive: Any, send: Any) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        content_length = 0
        for header_name, header_value in scope.get("headers", []):
            if header_name == b"content-length":
                try:
                    content_length = int(header_value)
                except ValueError:
                    pass
                break

        if content_length > self.max_size:
            response = Response(
                content='{"success":false,"error":"Request body too large"}',
                status_code=413,
                media_type="application/json",
            )
            await response(scope, receive, send)
            return

        await self.app(scope, receive, send)


# ---------------------------------------------------------------------------
# App Factory
# ---------------------------------------------------------------------------

def create_caas_app(adaptive_persist_path: Optional[str] = None) -> FastAPI:
    """Create and configure the CaaS FastAPI application."""

    app = FastAPI(
        title="Compression-as-a-Service (CaaS)",
        description="Context Window Optimizer API — auto-detect content types and apply optimal compression to reduce LLM token usage.",
        version="1.0.0",
        docs_url="/docs",
        redoc_url="/redoc",
    )

    # Middleware (applied in reverse order)
    app.add_middleware(GZipMiddleware, minimum_size=1000)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )
    app.add_middleware(LimitRequestSizeMiddleware, max_size=MAX_CONTENT_SIZE)
    app.add_middleware(RequestIDMiddleware)

    # Adaptive learner
    learner = AdaptiveLearner(persist_path=adaptive_persist_path)
    try:
        if adaptive_persist_path:
            learner.load()
    except (FileNotFoundError, json.JSONDecodeError):
        pass

    # Singletons
    engine = CompressionEngine(learner=learner)
    evaluator = LLMEvaluator(learner=learner, config=EvaluatorConfig.from_env())
    usage_tracker = CaaSUsageTracker()
    global_stats = GlobalStats()

    # Store on app state for testing access
    app.state.engine = engine
    app.state.evaluator = evaluator
    app.state.usage_tracker = usage_tracker
    app.state.global_stats = global_stats
    app.state.learner = learner

    # ------------------------------------------------------------------
    # Endpoints
    # ------------------------------------------------------------------

    @app.get("/v1/health")
    async def health() -> Dict[str, Any]:
        return {
            "status": "healthy",
            "service": "caas",
            "version": "1.0.0",
            "strategies": len(engine.supported_formats()),
        }

    @app.get("/v1/formats")
    async def formats() -> Dict[str, Any]:
        return {
            "formats": engine.supported_formats(),
            "total": len(engine.supported_formats()),
        }

    @app.post(
        "/v1/compress",
        response_model=CompressResponse,
        responses={400: {"model": ErrorResponse}, 401: {"model": ErrorResponse}},
    )
    async def compress(
        req: CompressRequest,
        request: Request,
        auth_token: str = Depends(verify_auth),
    ) -> CompressResponse:
        request_id = getattr(request.state, "request_id", None)

        if not req.content.strip():
            raise HTTPException(status_code=400, detail="Content cannot be empty")

        try:
            result = engine.compress(
                content=req.content,
                content_type=req.content_type,
                filename_hint=req.filename_hint,
                level=req.level,
                options=req.options,
            )
        except Exception as e:
            usage_tracker.record(auth_token, bytes_in=len(req.content), error=True)
            raise HTTPException(status_code=400, detail=str(e))

        detected_type = result.metadata.get("detected_type", "unknown")
        global_stats.record(result, detected_type)
        tokens_saved = max(0, result.original_tokens - result.compressed_tokens)
        usage_tracker.record(
            auth_token,
            bytes_in=result.original_size,
            bytes_out=result.compressed_size,
            tokens_saved=tokens_saved,
        )

        rec_level = engine.recommend_level(detected_type).value

        final_request_id = result.request_id or request_id

        # Fire-and-forget LLM evaluation (sampled)
        if evaluator.should_evaluate() and final_request_id:
            asyncio.create_task(
                evaluator.evaluate_compression(
                    request_id=final_request_id,
                    original_content=req.content,
                    compressed_content=result.compressed,
                    strategy=result.strategy,
                    content_type=detected_type,
                    compression_ratio=result.compression_ratio,
                    token_reduction_pct=result.token_reduction_pct,
                )
            )

        return CompressResponse(
            success=True,
            compressed=result.compressed,
            content_type=detected_type,
            strategy=result.strategy,
            original_size=result.original_size,
            compressed_size=result.compressed_size,
            original_tokens=result.original_tokens,
            compressed_tokens=result.compressed_tokens,
            compression_ratio=result.compression_ratio,
            token_reduction_pct=result.token_reduction_pct,
            processing_time_ms=result.processing_time_ms,
            request_id=final_request_id,
            recommended_level=rec_level,
            metadata=result.metadata,
        )

    @app.post(
        "/v1/compress/batch",
        response_model=BatchCompressResponse,
        responses={400: {"model": ErrorResponse}, 401: {"model": ErrorResponse}},
    )
    async def compress_batch(
        req: BatchCompressRequest,
        request: Request,
        auth_token: str = Depends(verify_auth),
    ) -> BatchCompressResponse:
        request_id = getattr(request.state, "request_id", None)
        start = time.monotonic()

        results: List[CompressResponse] = []
        total_orig = 0
        total_comp = 0

        for item in req.items:
            if not item.content.strip():
                continue
            try:
                result = engine.compress(
                    content=item.content,
                    content_type=item.content_type,
                    filename_hint=item.filename_hint,
                    level=item.level,
                    options=item.options,
                )
                detected_type = result.metadata.get("detected_type", "unknown")
                global_stats.record(result, detected_type)
                tokens_saved = max(0, result.original_tokens - result.compressed_tokens)
                usage_tracker.record(
                    auth_token,
                    bytes_in=result.original_size,
                    bytes_out=result.compressed_size,
                    tokens_saved=tokens_saved,
                )
                total_orig += result.original_tokens
                total_comp += result.compressed_tokens

                results.append(
                    CompressResponse(
                        success=True,
                        compressed=result.compressed,
                        content_type=detected_type,
                        strategy=result.strategy,
                        original_size=result.original_size,
                        compressed_size=result.compressed_size,
                        original_tokens=result.original_tokens,
                        compressed_tokens=result.compressed_tokens,
                        compression_ratio=result.compression_ratio,
                        token_reduction_pct=result.token_reduction_pct,
                        processing_time_ms=result.processing_time_ms,
                        request_id=request_id,
                        metadata=result.metadata,
                    )
                )
            except Exception as e:
                usage_tracker.record(
                    auth_token, bytes_in=len(item.content), error=True
                )
                results.append(
                    CompressResponse(
                        success=False,
                        compressed="",
                        content_type=item.content_type or "unknown",
                        strategy="error",
                        original_size=len(item.content),
                        compressed_size=0,
                        original_tokens=0,
                        compressed_tokens=0,
                        compression_ratio=0.0,
                        token_reduction_pct=0.0,
                        processing_time_ms=0.0,
                        request_id=request_id,
                        metadata={"error": str(e)},
                    )
                )

        elapsed = (time.monotonic() - start) * 1000
        total_pct = (
            (1 - total_comp / total_orig) * 100 if total_orig > 0 else 0.0
        )

        return BatchCompressResponse(
            success=True,
            results=results,
            total_original_tokens=total_orig,
            total_compressed_tokens=total_comp,
            total_token_reduction_pct=round(total_pct, 1),
            total_processing_time_ms=round(elapsed, 2),
        )

    @app.get("/v1/usage")
    async def usage(auth_token: str = Depends(verify_auth)) -> Dict[str, Any]:
        user_usage = usage_tracker.get_usage(auth_token)
        if user_usage is None:
            return {"usage": {"requests": 0, "tokens_saved": 0}}
        return {"usage": user_usage}

    @app.get("/v1/stats")
    async def stats(auth_token: str = Depends(verify_auth)) -> Dict[str, Any]:
        return {"stats": global_stats.to_dict()}

    # ------------------------------------------------------------------
    # Adaptive Learning Endpoints
    # ------------------------------------------------------------------

    @app.post(
        "/v1/feedback",
        response_model=FeedbackResponse,
        responses={400: {"model": ErrorResponse}},
    )
    async def feedback(
        req: FeedbackRequest,
        auth_token: str = Depends(verify_auth),
    ) -> FeedbackResponse:
        try:
            matched = learner.record_feedback(req.request_id, req.quality_score)
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e))

        if matched:
            return FeedbackResponse(
                success=True,
                request_id=req.request_id,
                matched=True,
                message="Feedback recorded successfully",
            )
        return FeedbackResponse(
            success=True,
            request_id=req.request_id,
            matched=False,
            message="Request ID not found in pending compressions",
        )

    @app.get("/v1/adaptive/status")
    async def adaptive_status(
        auth_token: str = Depends(verify_auth),
    ) -> Dict[str, Any]:
        return {
            "stats": learner.get_stats(),
            "policies": learner.get_policies(),
            "evaluator": evaluator.get_stats(),
        }

    @app.get("/v1/adaptive/recommend")
    async def adaptive_recommend(
        content_type: str,
        auth_token: str = Depends(verify_auth),
    ) -> Dict[str, Any]:
        level = engine.recommend_level(content_type)
        return {
            "content_type": content_type,
            "recommended_level": level.value,
        }

    @app.post("/v1/adaptive/rebuild")
    async def adaptive_rebuild(
        auth_token: str = Depends(verify_auth),
    ) -> Dict[str, Any]:
        count = learner.rebuild_policies()
        return {
            "success": True,
            "policies_created": count,
            "policies": learner.get_policies(),
        }

    @app.get("/v1/evaluator/history")
    async def evaluator_history(
        limit: int = 50,
        auth_token: str = Depends(verify_auth),
    ) -> Dict[str, Any]:
        return {
            "evaluations": evaluator.get_history(limit),
            "stats": evaluator.get_stats(),
        }

    return app


# Module-level app instance for uvicorn
app = create_caas_app(
    adaptive_persist_path=os.getenv("CAAS_ADAPTIVE_PATH"),
)
