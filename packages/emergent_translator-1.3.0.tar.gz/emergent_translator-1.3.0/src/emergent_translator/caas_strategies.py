"""
Compression-as-a-Service: Compression Strategies

Five content-aware compression strategies for reducing LLM token usage:
  1. CodeStrategy — code skeletonization via tree-sitter
  2. StructuredDataStrategy — JSON/YAML/TOML/XML/CSV optimization
  3. ProseStrategy — natural language compression
  4. LogStrategy — log file deduplication and pattern extraction
  5. SchemaStrategy — SQL/GraphQL schema compression
"""

from __future__ import annotations

import hashlib
import json
import re
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Set, Tuple


class CompressionLevel(str, Enum):
    """Compression aggressiveness level."""
    minimal = "minimal"
    balanced = "balanced"
    aggressive = "aggressive"


@dataclass
class CompressedResult:
    """Result of a compression operation."""
    compressed: str
    strategy: str
    original_size: int
    compressed_size: int
    original_tokens: int
    compressed_tokens: int
    compression_ratio: float
    token_reduction_pct: float
    processing_time_ms: float
    metadata: Dict[str, Any] = field(default_factory=dict)
    request_id: Optional[str] = None


def _estimate_tokens(text: str) -> int:
    """Estimate token count. Uses tiktoken if available, else chars//4."""
    try:
        from .claude_compression import estimate_tokens
        return estimate_tokens(text)
    except Exception:
        return max(1, len(text) // 4)


class CompressionStrategy(ABC):
    """Base class for content compression strategies."""

    name: str = "base"
    supported_types: List[str] = []

    def compress(
        self,
        content: str,
        content_type: str,
        level: CompressionLevel = CompressionLevel.balanced,
        options: Optional[Dict[str, Any]] = None,
    ) -> CompressedResult:
        """Compress content and return result with metrics."""
        start = time.monotonic()
        original_size = len(content.encode("utf-8"))
        original_tokens = _estimate_tokens(content)

        compressed = self._compress(content, content_type, level, options or {})

        compressed_size = len(compressed.encode("utf-8"))
        compressed_tokens = _estimate_tokens(compressed)
        elapsed_ms = (time.monotonic() - start) * 1000

        ratio = original_size / compressed_size if compressed_size > 0 else float("inf")
        token_pct = (
            (1 - compressed_tokens / original_tokens) * 100
            if original_tokens > 0
            else 0.0
        )

        return CompressedResult(
            compressed=compressed,
            strategy=self.name,
            original_size=original_size,
            compressed_size=compressed_size,
            original_tokens=original_tokens,
            compressed_tokens=compressed_tokens,
            compression_ratio=round(ratio, 2),
            token_reduction_pct=round(token_pct, 1),
            processing_time_ms=round(elapsed_ms, 2),
            metadata=self._metadata(content, content_type, level, options or {}),
        )

    @abstractmethod
    def _compress(
        self,
        content: str,
        content_type: str,
        level: CompressionLevel,
        options: Dict[str, Any],
    ) -> str:
        """Implement compression logic. Returns compressed string."""
        ...

    def _metadata(
        self,
        content: str,
        content_type: str,
        level: CompressionLevel,
        options: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Return strategy-specific metadata. Override in subclasses."""
        return {}


# ---------------------------------------------------------------------------
# 1. CodeStrategy
# ---------------------------------------------------------------------------

class CodeStrategy(CompressionStrategy):
    """Compress source code via tree-sitter skeletonization."""

    name = "code"
    supported_types = [
        "code/python",
        "code/typescript",
        "code/tsx",
        "code/javascript",
        "code/rust",
    ]

    _TYPE_TO_LANG = {
        "code/python": "python",
        "code/typescript": "typescript",
        "code/tsx": "tsx",
        "code/javascript": "javascript",
        "code/rust": "rust",
    }

    def _compress(
        self,
        content: str,
        content_type: str,
        level: CompressionLevel,
        options: Dict[str, Any],
    ) -> str:
        language = self._TYPE_TO_LANG.get(content_type, "python")
        focal = options.get("focal", None)

        if level == CompressionLevel.minimal:
            keep_docstrings = options.get("keep_docstrings", True)
        elif level == CompressionLevel.balanced:
            keep_docstrings = options.get("keep_docstrings", True)
        else:  # aggressive
            keep_docstrings = options.get("keep_docstrings", False)

        try:
            from .code_skeleton_multi import skeletonize_auto

            result = skeletonize_auto(
                source=content,
                language=language,
                focal=focal,
                keep_docstrings=keep_docstrings,
            )
        except Exception:
            # Fallback: basic comment/blank-line stripping
            result = self._fallback_compress(content, level)

        if level in (CompressionLevel.balanced, CompressionLevel.aggressive):
            result = self._strip_trailing_whitespace(result)
            result = self._collapse_blank_lines(result)

        if level == CompressionLevel.aggressive:
            result = self._strip_comments(result, language)

        return result

    def _metadata(
        self,
        content: str,
        content_type: str,
        level: CompressionLevel,
        options: Dict[str, Any],
    ) -> Dict[str, Any]:
        language = self._TYPE_TO_LANG.get(content_type, "python")
        return {
            "language": language,
            "focal": options.get("focal"),
        }

    @staticmethod
    def _strip_trailing_whitespace(text: str) -> str:
        return "\n".join(line.rstrip() for line in text.split("\n"))

    @staticmethod
    def _collapse_blank_lines(text: str) -> str:
        return re.sub(r"\n{3,}", "\n\n", text)

    @staticmethod
    def _strip_comments(text: str, language: str) -> str:
        if language == "python":
            lines = []
            for line in text.split("\n"):
                stripped = line.lstrip()
                if stripped.startswith("#") and not stripped.startswith("#!"):
                    continue
                lines.append(line)
            return "\n".join(lines)
        else:
            # C-style single-line comments
            lines = []
            for line in text.split("\n"):
                stripped = line.lstrip()
                if stripped.startswith("//"):
                    continue
                lines.append(line)
            return "\n".join(lines)

    @staticmethod
    def _fallback_compress(content: str, level: CompressionLevel) -> str:
        """Basic compression when tree-sitter is unavailable."""
        lines = []
        for line in content.split("\n"):
            stripped = line.lstrip()
            if not stripped:
                continue
            if level == CompressionLevel.aggressive and stripped.startswith("#"):
                continue
            lines.append(line)
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# 2. StructuredDataStrategy
# ---------------------------------------------------------------------------

class StructuredDataStrategy(CompressionStrategy):
    """Compress structured data (JSON, YAML, TOML, XML, CSV)."""

    name = "structured_data"
    supported_types = [
        "data/json",
        "data/yaml",
        "data/toml",
        "data/xml",
        "data/csv",
    ]

    def _compress(
        self,
        content: str,
        content_type: str,
        level: CompressionLevel,
        options: Dict[str, Any],
    ) -> str:
        data = self._parse(content, content_type)

        # Step 1: Null removal (all levels)
        data = self._remove_nulls(data)

        if level in (CompressionLevel.balanced, CompressionLevel.aggressive):
            # Step 2: Key shortening
            data, legend = self._shorten_keys(data)
        else:
            legend = {}

        if level in (CompressionLevel.balanced, CompressionLevel.aggressive):
            # Step 3: Array dedup
            data = self._dedup_arrays(data)

        if level == CompressionLevel.aggressive:
            # Step 4: Nested collapse
            data = self._collapse_nested(data)

        # Step 5: Compact serialize
        result = json.dumps(data, separators=(",", ":"), ensure_ascii=False)

        if legend:
            legend_str = json.dumps(legend, separators=(",", ":"))
            result = f"/*K:{legend_str}*/{result}"

        return result

    def _metadata(
        self,
        content: str,
        content_type: str,
        level: CompressionLevel,
        options: Dict[str, Any],
    ) -> Dict[str, Any]:
        return {"input_format": content_type}

    def _parse(self, content: str, content_type: str) -> Any:
        """Parse content string to Python objects."""
        if content_type == "data/json":
            return json.loads(content)
        elif content_type == "data/yaml":
            try:
                import yaml
                return yaml.safe_load(content)
            except ImportError:
                raise ValueError("PyYAML is required for YAML parsing (pip install pyyaml)")
        elif content_type == "data/toml":
            try:
                import tomllib
            except ImportError:
                try:
                    import tomli as tomllib  # type: ignore[no-redef]
                except ImportError:
                    raise ValueError("tomli is required for TOML parsing on Python <3.11")
            return tomllib.loads(content)
        elif content_type == "data/xml":
            try:
                from .format_handlers import xml_to_dicts
                return xml_to_dicts(content)
            except Exception:
                return self._basic_xml_parse(content)
        elif content_type == "data/csv":
            try:
                from .format_handlers import csv_to_dicts
                return csv_to_dicts(content)
            except Exception:
                return self._basic_csv_parse(content)
        # Fallback: try JSON
        return json.loads(content)

    @staticmethod
    def _basic_xml_parse(content: str) -> Any:
        """Minimal XML to dict fallback."""
        import xml.etree.ElementTree as ET
        root = ET.fromstring(content)

        def _elem_to_dict(elem: Any) -> Any:
            result: Dict[str, Any] = {}
            if elem.attrib:
                result.update(elem.attrib)
            for child in elem:
                child_data = _elem_to_dict(child)
                tag = child.tag
                if tag in result:
                    existing = result[tag]
                    if not isinstance(existing, list):
                        result[tag] = [existing]
                    result[tag].append(child_data)
                else:
                    result[tag] = child_data
            if elem.text and elem.text.strip():
                if result:
                    result["_text"] = elem.text.strip()
                else:
                    return elem.text.strip()
            return result

        return {root.tag: _elem_to_dict(root)}

    @staticmethod
    def _basic_csv_parse(content: str) -> List[Dict[str, str]]:
        """Minimal CSV parse fallback."""
        import csv
        import io
        reader = csv.DictReader(io.StringIO(content))
        return [dict(row) for row in reader]

    @classmethod
    def _remove_nulls(cls, data: Any) -> Any:
        """Recursively remove None, empty strings, empty lists, empty dicts."""
        if isinstance(data, dict):
            return {
                k: cls._remove_nulls(v)
                for k, v in data.items()
                if v is not None and v != "" and v != [] and v != {}
            }
        elif isinstance(data, list):
            return [cls._remove_nulls(item) for item in data if item is not None]
        return data

    def _shorten_keys(self, data: Any) -> Tuple[Any, Dict[str, str]]:
        """Shorten frequently-used keys."""
        # Count key frequencies
        freq: Dict[str, int] = {}
        self._count_keys(data, freq)

        # Build abbreviation map for keys appearing 3+ times
        legend: Dict[str, str] = {}
        short_map: Dict[str, str] = {}

        try:
            from .claude_compression import TextCodebook
            cb = TextCodebook.from_common_tables()
            known = cb.keys
        except Exception:
            known = {}

        for key, count in freq.items():
            if count < 3 and key not in known:
                continue
            if key in known:
                short_map[key] = known[key]
                legend[known[key]] = key
            elif count >= 3:
                short = self._abbreviate_key(key, short_map)
                short_map[key] = short
                legend[short] = key

        if not short_map:
            return data, {}

        return self._apply_key_map(data, short_map), legend

    def _count_keys(self, data: Any, freq: Dict[str, int]) -> None:
        if isinstance(data, dict):
            for k, v in data.items():
                freq[k] = freq.get(k, 0) + 1
                self._count_keys(v, freq)
        elif isinstance(data, list):
            for item in data:
                self._count_keys(item, freq)

    @staticmethod
    def _abbreviate_key(key: str, existing: Dict[str, str]) -> str:
        """Generate a short abbreviation for a key."""
        used = set(existing.values())
        # Try first 2 chars
        candidate = key[:2]
        if candidate not in used and candidate != key:
            return candidate
        # Try first letter + consonants
        consonants = "".join(c for c in key[1:] if c.lower() not in "aeiou_- ")
        candidate = key[0] + consonants[:2] if consonants else key[:3]
        if candidate not in used and candidate != key:
            return candidate
        # Try first 3 chars
        candidate = key[:3]
        if candidate not in used and candidate != key:
            return candidate
        # Add a number
        for i in range(10):
            candidate = key[:2] + str(i)
            if candidate not in used:
                return candidate
        return key  # Give up

    def _apply_key_map(self, data: Any, key_map: Dict[str, str]) -> Any:
        if isinstance(data, dict):
            return {
                key_map.get(k, k): self._apply_key_map(v, key_map)
                for k, v in data.items()
            }
        elif isinstance(data, list):
            return [self._apply_key_map(item, key_map) for item in data]
        return data

    @classmethod
    def _dedup_arrays(cls, data: Any) -> Any:
        """Deduplicate identical objects in arrays using _ref notation."""
        if isinstance(data, dict):
            return {k: cls._dedup_arrays(v) for k, v in data.items()}
        elif isinstance(data, list):
            if len(data) < 2:
                return data
            # Only dedup dicts/lists (not primitives)
            if not any(isinstance(item, (dict, list)) for item in data):
                return data

            seen: Dict[str, int] = {}
            result = []
            deduped_count = 0
            for item in data:
                key = json.dumps(item, sort_keys=True, separators=(",", ":"))
                if key in seen:
                    result.append({"_ref": seen[key]})
                    deduped_count += 1
                else:
                    idx = len(result)
                    seen[key] = idx
                    result.append(cls._dedup_arrays(item))

            # Only use dedup if >20% of items are duplicates
            if deduped_count / len(data) > 0.2:
                return result
            # Otherwise return recursively-processed original
            return [cls._dedup_arrays(item) for item in data]
        return data

    @classmethod
    def _collapse_nested(cls, data: Any) -> Any:
        """Flatten single-child nested dicts: {"a":{"b":{"c":1}}} -> {"a.b.c":1}"""
        if isinstance(data, dict):
            result: Dict[str, Any] = {}
            for k, v in data.items():
                v = cls._collapse_nested(v)
                if isinstance(v, dict) and len(v) == 1:
                    inner_k, inner_v = next(iter(v.items()))
                    result[f"{k}.{inner_k}"] = inner_v
                else:
                    result[k] = v
            return result
        elif isinstance(data, list):
            return [cls._collapse_nested(item) for item in data]
        return data


# ---------------------------------------------------------------------------
# 3. ProseStrategy
# ---------------------------------------------------------------------------

class ProseStrategy(CompressionStrategy):
    """Compress natural language text and markdown."""

    name = "prose"
    supported_types = ["text/prose", "text/markdown"]

    BOILERPLATE_PHRASES = [
        "for example",
        "for instance",
        "in order to",
        "as a matter of fact",
        "it is important to note that",
        "it should be noted that",
        "it is worth mentioning that",
        "at the end of the day",
        "in the context of",
        "with respect to",
        "in terms of",
        "on the other hand",
        "as a result of",
        "due to the fact that",
        "in light of the fact that",
    ]

    BOILERPLATE_REPLACEMENTS = {
        "for example": "e.g.",
        "for instance": "e.g.",
        "in order to": "to",
        "as a matter of fact": "in fact",
        "it is important to note that": "note:",
        "it should be noted that": "note:",
        "it is worth mentioning that": "notably,",
        "at the end of the day": "ultimately",
        "in the context of": "in",
        "with respect to": "regarding",
        "in terms of": "in",
        "on the other hand": "however,",
        "as a result of": "from",
        "due to the fact that": "because",
        "in light of the fact that": "since",
    }

    FILLER_WORDS = {
        "basically", "essentially", "actually", "literally", "really",
        "very", "quite", "rather", "somewhat", "just", "simply",
        "obviously", "clearly", "certainly", "definitely", "absolutely",
        "practically", "virtually", "honestly", "frankly",
    }

    def _compress(
        self,
        content: str,
        content_type: str,
        level: CompressionLevel,
        options: Dict[str, Any],
    ) -> str:
        is_markdown = content_type == "text/markdown"

        # All levels: whitespace normalization
        result = self._normalize_whitespace(content)

        if level in (CompressionLevel.balanced, CompressionLevel.aggressive):
            result = self._deduplicate_sentences(result, is_markdown)
            result = self._replace_boilerplate(result)

        if level == CompressionLevel.aggressive:
            result = self._deduplicate_paragraphs(result, is_markdown)
            result = self._remove_filler_words(result, is_markdown)
            result = self._compress_lists(result)

        return result

    def _metadata(
        self,
        content: str,
        content_type: str,
        level: CompressionLevel,
        options: Dict[str, Any],
    ) -> Dict[str, Any]:
        return {"is_markdown": content_type == "text/markdown"}

    @staticmethod
    def _normalize_whitespace(text: str) -> str:
        """Collapse blank lines and strip trailing whitespace."""
        lines = [line.rstrip() for line in text.split("\n")]
        result = []
        prev_blank = False
        for line in lines:
            if not line:
                if not prev_blank:
                    result.append("")
                prev_blank = True
            else:
                prev_blank = False
                result.append(line)
        return "\n".join(result).strip()

    @staticmethod
    def _is_protected_line(line: str) -> bool:
        """Check if a line is markdown-protected (headers, code, links)."""
        stripped = line.strip()
        return (
            stripped.startswith("#")
            or stripped.startswith("```")
            or stripped.startswith("|")
            or stripped.startswith("- [")
            or stripped.startswith("* [")
            or stripped.startswith("![")
        )

    def _deduplicate_sentences(self, text: str, is_markdown: bool) -> str:
        """Remove duplicate sentences (keep first occurrence)."""
        lines = text.split("\n")
        result = []
        seen_hashes: Set[str] = set()

        for line in lines:
            if is_markdown and self._is_protected_line(line):
                result.append(line)
                continue

            if not line.strip():
                result.append(line)
                continue

            # Split line into sentences
            sentences = re.split(r"(?<=[.!?])\s+", line)
            kept = []
            for sentence in sentences:
                h = hashlib.md5(sentence.strip().lower().encode()).hexdigest()
                if h not in seen_hashes:
                    seen_hashes.add(h)
                    kept.append(sentence)
            if kept:
                result.append(" ".join(kept))

        return "\n".join(result)

    def _replace_boilerplate(self, text: str) -> str:
        """Replace verbose phrases with concise equivalents."""
        for phrase, replacement in self.BOILERPLATE_REPLACEMENTS.items():
            text = re.sub(re.escape(phrase), replacement, text, flags=re.IGNORECASE)
        return text

    def _deduplicate_paragraphs(self, text: str, is_markdown: bool) -> str:
        """Remove duplicate paragraphs."""
        paragraphs = text.split("\n\n")
        seen: Set[str] = set()
        result = []
        for para in paragraphs:
            if is_markdown and self._is_protected_line(para.strip()):
                result.append(para)
                continue
            h = hashlib.md5(para.strip().lower().encode()).hexdigest()
            if h not in seen:
                seen.add(h)
                result.append(para)
        return "\n\n".join(result)

    def _remove_filler_words(self, text: str, is_markdown: bool) -> str:
        """Remove filler words while preserving code blocks."""
        lines = text.split("\n")
        in_code_block = False
        result = []

        for line in lines:
            if line.strip().startswith("```"):
                in_code_block = not in_code_block
                result.append(line)
                continue
            if in_code_block:
                result.append(line)
                continue
            if is_markdown and self._is_protected_line(line):
                result.append(line)
                continue

            words = line.split()
            filtered = []
            for word in words:
                clean = word.strip(".,;:!?").lower()
                if clean in self.FILLER_WORDS:
                    continue
                filtered.append(word)
            result.append(" ".join(filtered))

        return "\n".join(result)

    @staticmethod
    def _compress_lists(text: str) -> str:
        """Compress multi-line lists into compact form."""
        lines = text.split("\n")
        result = []
        list_items: List[str] = []

        def flush_list() -> None:
            if len(list_items) > 3:
                result.append(" | ".join(list_items))
            else:
                for item in list_items:
                    result.append(f"- {item}")
            list_items.clear()

        for line in lines:
            stripped = line.strip()
            match = re.match(r"^[-*]\s+(.+)$", stripped)
            if match:
                list_items.append(match.group(1))
            else:
                flush_list()
                result.append(line)

        flush_list()
        return "\n".join(result)


# ---------------------------------------------------------------------------
# 4. LogStrategy
# ---------------------------------------------------------------------------

class LogStrategy(CompressionStrategy):
    """Compress log files via deduplication and pattern extraction."""

    name = "log"
    supported_types = ["text/log"]

    # Common timestamp patterns
    _TS_PATTERNS = [
        # ISO 8601: 2024-01-15T10:30:00.123Z
        re.compile(
            r"\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})?"
        ),
        # Syslog: Jan 15 10:30:00
        re.compile(
            r"(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{1,2}\s+\d{2}:\d{2}:\d{2}"
        ),
        # Common log: 15/Jan/2024:10:30:00
        re.compile(r"\d{2}/\w{3}/\d{4}:\d{2}:\d{2}:\d{2}"),
        # Simple time: 10:30:00.123
        re.compile(r"\d{2}:\d{2}:\d{2}(?:\.\d+)?"),
    ]

    _LOG_LEVELS = re.compile(
        r"\b(DEBUG|TRACE|INFO|WARN(?:ING)?|ERROR|FATAL|CRITICAL)\b", re.IGNORECASE
    )

    _DEBUG_LEVELS = re.compile(r"\b(DEBUG|TRACE)\b", re.IGNORECASE)

    def _compress(
        self,
        content: str,
        content_type: str,
        level: CompressionLevel,
        options: Dict[str, Any],
    ) -> str:
        lines = content.split("\n")

        # Step 1: Timestamp compression
        lines = self._compress_timestamps(lines, level)

        # Step 2: Line dedup with counts
        lines = self._dedup_consecutive(lines)

        if level in (CompressionLevel.balanced, CompressionLevel.aggressive):
            # Step 3: Stack trace compression
            lines = self._compress_stack_traces(lines)

        if level == CompressionLevel.aggressive:
            # Step 4: Level filtering
            lines = self._filter_debug(lines)

        if level in (CompressionLevel.balanced, CompressionLevel.aggressive):
            # Step 5: Pattern extraction
            result = self._extract_patterns(lines)
        else:
            result = "\n".join(lines)

        return result

    def _metadata(
        self,
        content: str,
        content_type: str,
        level: CompressionLevel,
        options: Dict[str, Any],
    ) -> Dict[str, Any]:
        line_count = content.count("\n") + 1
        return {"original_lines": line_count}

    def _compress_timestamps(
        self, lines: List[str], level: CompressionLevel
    ) -> List[str]:
        """Replace or remove timestamps based on level."""
        result = []
        for line in lines:
            modified = line
            for pattern in self._TS_PATTERNS:
                match = pattern.search(modified)
                if match:
                    if level == CompressionLevel.minimal:
                        modified = modified[: match.start()] + modified[match.end() :]
                        modified = modified.lstrip(" -]>")
                    else:
                        # balanced/aggressive: remove entirely
                        modified = modified[: match.start()] + modified[match.end() :]
                        modified = modified.lstrip(" -]>")
                    break
            result.append(modified)
        return result

    @staticmethod
    def _dedup_consecutive(lines: List[str]) -> List[str]:
        """Collapse consecutive identical lines with counts."""
        if not lines:
            return lines
        result = []
        prev = lines[0]
        count = 1
        for line in lines[1:]:
            if line == prev:
                count += 1
            else:
                if count > 1:
                    result.append(f"[x{count}] {prev}")
                else:
                    result.append(prev)
                prev = line
                count = 1
        if count > 1:
            result.append(f"[x{count}] {prev}")
        else:
            result.append(prev)
        return result

    @staticmethod
    def _compress_stack_traces(lines: List[str]) -> List[str]:
        """Compress stack traces: keep first + last frame, collapse middle."""
        result: List[str] = []
        trace_frames: List[str] = []

        def flush_trace() -> None:
            if len(trace_frames) <= 3:
                result.extend(trace_frames)
            else:
                result.append(trace_frames[0])
                result.append(f"  ... ({len(trace_frames) - 2} frames) ...")
                result.append(trace_frames[-1])
            trace_frames.clear()

        for line in lines:
            stripped = line.strip()
            is_frame = (
                stripped.startswith("at ")
                or stripped.startswith("File ")
                or re.match(r"^\s+at\s+", line)
                or stripped.startswith("Traceback")
                or (stripped.startswith("in ") and "line" in stripped)
            )
            if is_frame:
                trace_frames.append(line)
            else:
                flush_trace()
                result.append(line)

        flush_trace()
        return result

    def _filter_debug(self, lines: List[str]) -> List[str]:
        """Remove DEBUG/TRACE level log lines."""
        return [
            line for line in lines
            if not self._DEBUG_LEVELS.search(line)
        ]

    def _extract_patterns(self, lines: List[str]) -> str:
        """Extract repeated log message patterns as templates."""
        # Normalize variable parts to find patterns
        pattern_counts: Dict[str, List[int]] = {}
        for i, line in enumerate(lines):
            normalized = re.sub(r"\b\d+\b", "<N>", line)
            normalized = re.sub(r"\b[0-9a-f]{8,}\b", "<HEX>", normalized, flags=re.IGNORECASE)
            normalized = re.sub(r"\b\d+\.\d+\.\d+\.\d+\b", "<IP>", normalized)
            normalized = re.sub(r'"[^"]*"', '"<S>"', normalized)
            if normalized not in pattern_counts:
                pattern_counts[normalized] = []
            pattern_counts[normalized].append(i)

        # Patterns appearing 3+ times get templated
        templates: List[str] = []
        template_lines: Set[int] = set()
        for pattern, indices in pattern_counts.items():
            if len(indices) >= 3:
                templates.append(f"[x{len(indices)}] {pattern}")
                template_lines.update(indices)

        remaining = [
            lines[i] for i in range(len(lines)) if i not in template_lines
        ]

        parts: List[str] = []
        if templates:
            parts.append("=== PATTERNS ===")
            parts.extend(templates)
            parts.append("=== UNIQUE ===")
        parts.extend(remaining)
        return "\n".join(parts)


# ---------------------------------------------------------------------------
# 5. SchemaStrategy
# ---------------------------------------------------------------------------

class SchemaStrategy(CompressionStrategy):
    """Compress SQL and GraphQL schema definitions."""

    name = "schema"
    supported_types = ["schema/sql", "schema/graphql"]

    # SQL type abbreviations
    SQL_TYPE_ABBREVS = {
        "VARCHAR": "VC",
        "INTEGER": "INT",
        "BOOLEAN": "BOOL",
        "TIMESTAMP": "TS",
        "BIGINT": "BIG",
        "SMALLINT": "SM",
        "CHARACTER VARYING": "VC",
        "DOUBLE PRECISION": "DBL",
        "TEXT": "TXT",
        "SERIAL": "SER",
        "BIGSERIAL": "BSER",
    }

    SQL_CONSTRAINT_ABBREVS = {
        "NOT NULL": "NN",
        "PRIMARY KEY": "PK",
        "FOREIGN KEY": "FK",
        "UNIQUE": "UQ",
        "REFERENCES": "REF",
        "DEFAULT": "DEF",
    }

    GRAPHQL_ABBREVS = {
        "type ": "T ",
        "input ": "I ",
        "enum ": "E ",
        "interface ": "IF ",
    }

    def _compress(
        self,
        content: str,
        content_type: str,
        level: CompressionLevel,
        options: Dict[str, Any],
    ) -> str:
        if content_type == "schema/sql":
            return self._compress_sql(content, level)
        else:
            return self._compress_graphql(content, level)

    def _metadata(
        self,
        content: str,
        content_type: str,
        level: CompressionLevel,
        options: Dict[str, Any],
    ) -> Dict[str, Any]:
        return {"schema_type": "sql" if content_type == "schema/sql" else "graphql"}

    def _compress_sql(self, content: str, level: CompressionLevel) -> str:
        # All levels: remove comments, normalize whitespace
        result = self._remove_sql_comments(content)
        result = self._normalize_sql_whitespace(result)

        if level in (CompressionLevel.balanced, CompressionLevel.aggressive):
            # Remove DEFAULT clauses
            result = re.sub(
                r"\bDEFAULT\s+(?:'[^']*'|\S+)", "", result, flags=re.IGNORECASE
            )
            # Remove CASCADE
            result = re.sub(r"\bCASCADE\b", "", result, flags=re.IGNORECASE)
            # Abbreviate types
            for full, short in self.SQL_TYPE_ABBREVS.items():
                result = re.sub(
                    r"\b" + re.escape(full) + r"\b", short, result, flags=re.IGNORECASE
                )
            # Abbreviate constraints
            for full, short in self.SQL_CONSTRAINT_ABBREVS.items():
                result = re.sub(
                    r"\b" + re.escape(full) + r"\b", short, result, flags=re.IGNORECASE
                )

        if level == CompressionLevel.aggressive:
            # Remove CHECK constraints
            result = re.sub(r"\bCHECK\s*\([^)]*\)", "", result, flags=re.IGNORECASE)
            # Remove INDEX statements
            result = re.sub(
                r"CREATE\s+(?:UNIQUE\s+)?INDEX\s+[^;]*;", "", result, flags=re.IGNORECASE
            )
            # Remove COMMENT statements
            result = re.sub(
                r"COMMENT\s+ON\s+[^;]*;", "", result, flags=re.IGNORECASE
            )

        # Clean up whitespace artifacts
        result = re.sub(r"  +", " ", result)
        result = re.sub(r"\n{2,}", "\n", result)
        return result.strip()

    @staticmethod
    def _remove_sql_comments(content: str) -> str:
        """Remove -- and /* */ comments."""
        # Remove block comments
        result = re.sub(r"/\*.*?\*/", "", content, flags=re.DOTALL)
        # Remove line comments
        result = re.sub(r"--[^\n]*", "", result)
        return result

    @staticmethod
    def _normalize_sql_whitespace(content: str) -> str:
        """Normalize SQL whitespace."""
        lines = [line.strip() for line in content.split("\n")]
        lines = [line for line in lines if line]
        return "\n".join(lines)

    def _compress_graphql(self, content: str, level: CompressionLevel) -> str:
        # All levels: remove comments, normalize whitespace
        result = self._remove_graphql_comments(content)
        result = self._normalize_graphql_whitespace(result)

        if level in (CompressionLevel.balanced, CompressionLevel.aggressive):
            # Remove description strings (triple-quoted)
            result = re.sub(r'""".*?"""', "", result, flags=re.DOTALL)
            result = re.sub(r'"[^"\n]*"\s*\n', "", result)
            # Abbreviate keywords
            for full, short in self.GRAPHQL_ABBREVS.items():
                result = result.replace(full, short)

        if level == CompressionLevel.aggressive:
            # Remove all directives (@deprecated, @auth, etc.)
            result = re.sub(r"@\w+(?:\([^)]*\))?", "", result)
            # Remove argument defaults
            result = re.sub(r'\s*=\s*(?:"[^"]*"|\d+|true|false|null|\[[^\]]*\])', "", result)

        # Clean up
        result = re.sub(r"  +", " ", result)
        result = re.sub(r"\n{2,}", "\n", result)
        return result.strip()

    @staticmethod
    def _remove_graphql_comments(content: str) -> str:
        """Remove # comments from GraphQL."""
        return re.sub(r"#[^\n]*", "", content)

    @staticmethod
    def _normalize_graphql_whitespace(content: str) -> str:
        """Normalize GraphQL whitespace."""
        lines = [line.strip() for line in content.split("\n")]
        lines = [line for line in lines if line]
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Registry of all strategies
# ---------------------------------------------------------------------------

ALL_STRATEGIES: List[CompressionStrategy] = [
    CodeStrategy(),
    StructuredDataStrategy(),
    ProseStrategy(),
    LogStrategy(),
    SchemaStrategy(),
]

STRATEGY_MAP: Dict[str, CompressionStrategy] = {}
for _strat in ALL_STRATEGIES:
    for _ct in _strat.supported_types:
        STRATEGY_MAP[_ct] = _strat
