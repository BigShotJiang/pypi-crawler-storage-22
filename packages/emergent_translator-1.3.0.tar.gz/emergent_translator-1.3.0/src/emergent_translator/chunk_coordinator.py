"""
Distributed Chunk Coordinator for Emergent Language Processing

Enables distributed processing of large files across multiple instances
using emergent language θ symbols as the wire protocol for 87% bandwidth reduction.

Architecture:
    ┌─────────────┐     ┌─────────────┐     ┌─────────────┐
    │   Ingest    │────▶│   Chunk +   │────▶│  Distribute │
    │   (10GB)    │     │  θ-compress │     │  (1.3GB)    │
    └─────────────┘     └─────────────┘     └──────┬──────┘
                                                   │
         ┌─────────────────────────────────────────┼─────────────────────────────────────────┐
         ▼                                         ▼                                         ▼
    ┌─────────┐                               ┌─────────┐                               ┌─────────┐
    │ Worker 1│                               │Worker 50│                               │Worker100│
    │ Process │                               │ Process │                               │ Process │
    └────┬────┘                               └────┬────┘                               └────┬────┘
         │                                         │                                         │
         └─────────────────────────────────────────┼─────────────────────────────────────────┘
                                                   │
                                          ┌───────▼───────┐
                                          │  Reassemble   │
                                          │  θ-decompress │
                                          └───────────────┘

Usage:
    coordinator = ChunkCoordinator(
        workers=["https://instance1.fly.dev", "https://instance2.fly.dev"],
        chunk_size_mb=100
    )

    job = await coordinator.submit(
        data=large_file_bytes,
        operation="transform"
    )

    result = await coordinator.wait(job.id)
"""

import asyncio
import hashlib
import time
import uuid
import base64
import json
import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Tuple, Union
from datetime import datetime
import struct

import httpx

logger = logging.getLogger(__name__)


class ChunkStatus(Enum):
    """Status of a chunk in the processing pipeline."""
    PENDING = "pending"
    COMPRESSING = "compressing"
    QUEUED = "queued"
    DISPATCHED = "dispatched"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    RETRYING = "retrying"


class JobStatus(Enum):
    """Status of a distributed job."""
    CREATED = "created"
    CHUNKING = "chunking"
    DISTRIBUTING = "distributing"
    PROCESSING = "processing"
    COLLECTING = "collecting"
    REASSEMBLING = "reassembling"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


@dataclass
class ChunkMetadata:
    """Metadata for tracking a chunk through the pipeline."""
    chunk_id: str
    job_id: str
    sequence: int  # Order in original file
    offset: int  # Byte offset in original
    size_raw: int  # Size before compression
    size_compressed: int = 0  # Size after θ-compression
    checksum_raw: str = ""  # SHA-256 of raw data
    checksum_compressed: str = ""  # SHA-256 of compressed
    status: ChunkStatus = ChunkStatus.PENDING
    worker_url: Optional[str] = None
    dispatch_time: Optional[float] = None
    complete_time: Optional[float] = None
    retries: int = 0
    error: Optional[str] = None


@dataclass
class Chunk:
    """A chunk of data ready for distributed processing."""
    metadata: ChunkMetadata
    data_raw: Optional[bytes] = None  # Original data (cleared after compression)
    data_compressed: Optional[bytes] = None  # θ-compressed data
    result_compressed: Optional[bytes] = None  # θ-compressed result from worker
    result_raw: Optional[bytes] = None  # Decompressed result

    @property
    def compression_ratio(self) -> float:
        if self.metadata.size_raw == 0:
            return 0.0
        return self.metadata.size_compressed / self.metadata.size_raw


@dataclass
class JobStats:
    """Statistics for a distributed job."""
    total_chunks: int = 0
    completed_chunks: int = 0
    failed_chunks: int = 0
    total_bytes_raw: int = 0
    total_bytes_compressed: int = 0
    total_bytes_transferred: int = 0
    start_time: Optional[float] = None
    end_time: Optional[float] = None

    @property
    def compression_ratio(self) -> float:
        if self.total_bytes_raw == 0:
            return 0.0
        return self.total_bytes_compressed / self.total_bytes_raw

    @property
    def bandwidth_savings_percent(self) -> float:
        return (1 - self.compression_ratio) * 100

    @property
    def duration_seconds(self) -> float:
        if not self.start_time or not self.end_time:
            return 0.0
        return self.end_time - self.start_time

    @property
    def throughput_mbps(self) -> float:
        if self.duration_seconds == 0:
            return 0.0
        return (self.total_bytes_raw / 1024 / 1024) / self.duration_seconds


@dataclass
class DistributedJob:
    """A distributed processing job."""
    id: str
    operation: str
    status: JobStatus = JobStatus.CREATED
    chunks: List[Chunk] = field(default_factory=list)
    stats: JobStats = field(default_factory=JobStats)
    created_at: datetime = field(default_factory=datetime.now)
    metadata: Dict[str, Any] = field(default_factory=dict)
    result: Optional[bytes] = None
    errors: List[str] = field(default_factory=list)

    def get_chunk(self, chunk_id: str) -> Optional[Chunk]:
        """Get chunk by ID."""
        for chunk in self.chunks:
            if chunk.metadata.chunk_id == chunk_id:
                return chunk
        return None


class WorkerPool:
    """Manages a pool of worker instances."""

    def __init__(self, workers: List[str], auth_token: Optional[str] = None):
        self.workers = workers
        self.auth_token = auth_token or "eudaimonia-translator-demo"
        self._worker_stats: Dict[str, Dict] = {
            url: {"active": 0, "completed": 0, "failed": 0, "avg_latency_ms": 0}
            for url in workers
        }
        self._lock = asyncio.Lock()

    async def get_best_worker(self) -> str:
        """Select the best available worker (least loaded, best performance)."""
        async with self._lock:
            # Simple strategy: least active connections
            best = min(
                self.workers,
                key=lambda w: (
                    self._worker_stats[w]["active"],
                    -self._worker_stats[w]["completed"],
                    self._worker_stats[w]["avg_latency_ms"]
                )
            )
            self._worker_stats[best]["active"] += 1
            return best

    async def release_worker(self, url: str, success: bool, latency_ms: float):
        """Release a worker after task completion."""
        async with self._lock:
            stats = self._worker_stats[url]
            stats["active"] = max(0, stats["active"] - 1)
            if success:
                stats["completed"] += 1
                # Rolling average latency
                n = stats["completed"]
                stats["avg_latency_ms"] = (
                    stats["avg_latency_ms"] * (n - 1) + latency_ms
                ) / n
            else:
                stats["failed"] += 1

    def get_stats(self) -> Dict[str, Dict]:
        """Get worker pool statistics."""
        return dict(self._worker_stats)


class ChunkCoordinator:
    """
    Coordinates distributed processing of large data across multiple instances.

    Uses emergent language θ-compression for efficient wire protocol,
    achieving ~87% bandwidth reduction on structured data.
    """

    def __init__(
        self,
        workers: List[str],
        chunk_size_mb: int = 100,
        max_concurrent: int = 50,
        auth_token: Optional[str] = None,
        compress_endpoint: str = "/translate",
        process_endpoint: str = "/process",
        timeout_seconds: float = 60.0,
        max_retries: int = 3
    ):
        """
        Initialize the chunk coordinator.

        Args:
            workers: List of worker instance URLs
            chunk_size_mb: Target chunk size in MB
            max_concurrent: Maximum concurrent chunk dispatches
            auth_token: Authentication token for workers
            compress_endpoint: Endpoint for θ-compression
            process_endpoint: Endpoint for processing
            timeout_seconds: Request timeout
            max_retries: Max retries per chunk
        """
        self.worker_pool = WorkerPool(workers, auth_token)
        self.chunk_size_bytes = int(chunk_size_mb * 1024 * 1024)
        self.max_concurrent = max_concurrent
        self.auth_token = auth_token or "eudaimonia-translator-demo"
        self.compress_endpoint = compress_endpoint
        self.process_endpoint = process_endpoint
        self.timeout = timeout_seconds
        self.max_retries = max_retries

        # Active jobs
        self._jobs: Dict[str, DistributedJob] = {}
        self._semaphore = asyncio.Semaphore(max_concurrent)

    def _split_into_chunks(self, data: bytes, job_id: str) -> List[Chunk]:
        """Split data into chunks for distribution."""
        chunks = []
        offset = 0
        sequence = 0

        while offset < len(data):
            chunk_data = data[offset:offset + self.chunk_size_bytes]
            chunk_size = len(chunk_data)

            metadata = ChunkMetadata(
                chunk_id=f"{job_id}-{sequence:04d}",
                job_id=job_id,
                sequence=sequence,
                offset=offset,
                size_raw=chunk_size,
                checksum_raw=hashlib.sha256(chunk_data).hexdigest()[:16]
            )

            chunks.append(Chunk(metadata=metadata, data_raw=chunk_data))

            offset += chunk_size
            sequence += 1

        return chunks

    async def _compress_chunk(self, chunk: Chunk, client: httpx.AsyncClient) -> Chunk:
        """Compress a chunk using θ-protocol via local or remote translator."""
        chunk.metadata.status = ChunkStatus.COMPRESSING

        # For prototype, use first worker for compression
        # In production, could have dedicated compression service
        worker = self.worker_pool.workers[0]

        try:
            # Encode raw data as base64 for JSON transport
            data_b64 = base64.b64encode(chunk.data_raw).decode('utf-8')

            response = await client.post(
                f"{worker}{self.compress_endpoint}",
                json={
                    "data": f"CHUNK:{chunk.metadata.chunk_id}:{data_b64}",
                    "source_format": "text",
                    "target_format": "emergent"
                },
                headers={"Authorization": f"Bearer {self.auth_token}"},
                timeout=self.timeout
            )

            if response.status_code == 200:
                result = response.json()
                compressed_b64 = result.get("translated_data", "")
                compressed_bytes = base64.b64decode(compressed_b64)

                chunk.data_compressed = compressed_bytes
                chunk.metadata.size_compressed = len(compressed_bytes)
                chunk.metadata.checksum_compressed = hashlib.sha256(compressed_bytes).hexdigest()[:16]
                chunk.metadata.status = ChunkStatus.QUEUED

                # Clear raw data to free memory
                chunk.data_raw = None

                logger.debug(
                    f"Chunk {chunk.metadata.chunk_id} compressed: "
                    f"{chunk.metadata.size_raw} → {chunk.metadata.size_compressed} "
                    f"({chunk.compression_ratio:.2%})"
                )
            else:
                chunk.metadata.status = ChunkStatus.FAILED
                chunk.metadata.error = f"Compression failed: HTTP {response.status_code}"

        except Exception as e:
            chunk.metadata.status = ChunkStatus.FAILED
            chunk.metadata.error = f"Compression error: {str(e)[:100]}"
            logger.error(f"Chunk {chunk.metadata.chunk_id} compression failed: {e}")

        return chunk

    async def _dispatch_chunk(
        self,
        chunk: Chunk,
        operation: str,
        client: httpx.AsyncClient,
        operation_params: Optional[Dict] = None
    ) -> Chunk:
        """Dispatch a chunk to a worker for processing."""
        async with self._semaphore:
            worker_url = await self.worker_pool.get_best_worker()
            chunk.metadata.worker_url = worker_url
            chunk.metadata.dispatch_time = time.time()
            chunk.metadata.status = ChunkStatus.DISPATCHED

            start_time = time.perf_counter()
            success = False

            try:
                chunk.metadata.status = ChunkStatus.PROCESSING

                # Send compressed chunk to worker
                payload = {
                    "chunk_id": chunk.metadata.chunk_id,
                    "operation": operation,
                    "data": base64.b64encode(chunk.data_compressed).decode('utf-8'),
                    "params": operation_params or {}
                }

                response = await client.post(
                    f"{worker_url}{self.process_endpoint}",
                    json=payload,
                    headers={"Authorization": f"Bearer {self.auth_token}"},
                    timeout=self.timeout
                )

                latency_ms = (time.perf_counter() - start_time) * 1000

                if response.status_code == 200:
                    result = response.json()
                    if result.get("success"):
                        result_b64 = result.get("result", "")
                        chunk.result_compressed = base64.b64decode(result_b64)
                        chunk.metadata.status = ChunkStatus.COMPLETED
                        chunk.metadata.complete_time = time.time()
                        success = True
                    else:
                        chunk.metadata.status = ChunkStatus.FAILED
                        chunk.metadata.error = result.get("error", "Unknown processing error")
                else:
                    chunk.metadata.status = ChunkStatus.FAILED
                    chunk.metadata.error = f"HTTP {response.status_code}"

            except asyncio.TimeoutError:
                chunk.metadata.status = ChunkStatus.FAILED
                chunk.metadata.error = "Timeout"
                latency_ms = self.timeout * 1000

            except Exception as e:
                chunk.metadata.status = ChunkStatus.FAILED
                chunk.metadata.error = str(e)[:100]
                latency_ms = (time.perf_counter() - start_time) * 1000

            finally:
                await self.worker_pool.release_worker(worker_url, success, latency_ms)

            return chunk

    async def _decompress_result(self, chunk: Chunk, client: httpx.AsyncClient) -> Chunk:
        """Decompress a chunk result back to original format."""
        if not chunk.result_compressed:
            return chunk

        worker = self.worker_pool.workers[0]

        try:
            response = await client.post(
                f"{worker}/decompress",
                json={
                    "compressed_data": base64.b64encode(chunk.result_compressed).decode('utf-8')
                },
                headers={"Authorization": f"Bearer {self.auth_token}"},
                timeout=self.timeout
            )

            if response.status_code == 200:
                result = response.json()
                if result.get("success"):
                    decompressed = result.get("decompressed_data", "")
                    # Handle CHUNK: prefix if present
                    if isinstance(decompressed, str) and decompressed.startswith("CHUNK:"):
                        parts = decompressed.split(":", 2)
                        if len(parts) >= 3:
                            decompressed = parts[2]

                    if isinstance(decompressed, str):
                        chunk.result_raw = base64.b64decode(decompressed)
                    else:
                        chunk.result_raw = decompressed

        except Exception as e:
            logger.error(f"Chunk {chunk.metadata.chunk_id} decompression failed: {e}")
            # Keep compressed result, let reassembly handle it

        return chunk

    def _reassemble_results(self, chunks: List[Chunk]) -> bytes:
        """Reassemble chunk results in order."""
        # Sort by sequence number
        sorted_chunks = sorted(chunks, key=lambda c: c.metadata.sequence)

        result_parts = []
        for chunk in sorted_chunks:
            if chunk.result_raw:
                result_parts.append(chunk.result_raw)
            elif chunk.result_compressed:
                # Fallback: include compressed if decompression failed
                result_parts.append(chunk.result_compressed)
            else:
                logger.warning(f"Chunk {chunk.metadata.chunk_id} has no result")

        return b''.join(result_parts)

    async def submit(
        self,
        data: bytes,
        operation: str,
        operation_params: Optional[Dict] = None,
        metadata: Optional[Dict] = None
    ) -> DistributedJob:
        """
        Submit data for distributed processing.

        Args:
            data: Raw data bytes to process
            operation: Operation name to perform on chunks
            operation_params: Optional parameters for the operation
            metadata: Optional job metadata

        Returns:
            DistributedJob with job ID for tracking
        """
        job_id = str(uuid.uuid4())[:8]

        job = DistributedJob(
            id=job_id,
            operation=operation,
            status=JobStatus.CHUNKING,
            metadata=metadata or {}
        )
        job.stats.start_time = time.time()
        job.stats.total_bytes_raw = len(data)

        logger.info(f"Job {job_id}: Starting chunking of {len(data)} bytes")

        # Split into chunks
        job.chunks = self._split_into_chunks(data, job_id)
        job.stats.total_chunks = len(job.chunks)

        logger.info(f"Job {job_id}: Created {len(job.chunks)} chunks")

        self._jobs[job_id] = job

        # Start async processing
        asyncio.create_task(self._process_job(job, operation_params))

        return job

    async def _process_job(self, job: DistributedJob, operation_params: Optional[Dict] = None):
        """Process a job through the full pipeline."""
        try:
            async with httpx.AsyncClient() as client:
                # Phase 1: Compress all chunks
                job.status = JobStatus.DISTRIBUTING
                logger.info(f"Job {job.id}: Compressing {len(job.chunks)} chunks")

                compress_tasks = [
                    self._compress_chunk(chunk, client)
                    for chunk in job.chunks
                ]
                await asyncio.gather(*compress_tasks)

                # Calculate compression stats
                job.stats.total_bytes_compressed = sum(
                    c.metadata.size_compressed for c in job.chunks
                )

                logger.info(
                    f"Job {job.id}: Compression complete - "
                    f"{job.stats.total_bytes_raw} → {job.stats.total_bytes_compressed} "
                    f"({job.stats.bandwidth_savings_percent:.1f}% savings)"
                )

                # Phase 2: Dispatch to workers
                job.status = JobStatus.PROCESSING
                logger.info(f"Job {job.id}: Dispatching to workers")

                # Filter chunks that compressed successfully
                ready_chunks = [
                    c for c in job.chunks
                    if c.metadata.status == ChunkStatus.QUEUED
                ]

                dispatch_tasks = [
                    self._dispatch_chunk(chunk, job.operation, client, operation_params)
                    for chunk in ready_chunks
                ]
                await asyncio.gather(*dispatch_tasks)

                # Track bytes transferred
                job.stats.total_bytes_transferred = (
                    job.stats.total_bytes_compressed * 2  # Round trip
                )

                # Phase 3: Collect and decompress results
                job.status = JobStatus.COLLECTING
                logger.info(f"Job {job.id}: Collecting results")

                completed_chunks = [
                    c for c in job.chunks
                    if c.metadata.status == ChunkStatus.COMPLETED
                ]

                decompress_tasks = [
                    self._decompress_result(chunk, client)
                    for chunk in completed_chunks
                ]
                await asyncio.gather(*decompress_tasks)

                # Phase 4: Reassemble
                job.status = JobStatus.REASSEMBLING
                logger.info(f"Job {job.id}: Reassembling {len(completed_chunks)} chunks")

                job.result = self._reassemble_results(completed_chunks)

                # Final stats
                job.stats.completed_chunks = len(completed_chunks)
                job.stats.failed_chunks = len(job.chunks) - len(completed_chunks)
                job.stats.end_time = time.time()

                if job.stats.failed_chunks == 0:
                    job.status = JobStatus.COMPLETED
                    logger.info(
                        f"Job {job.id}: Completed successfully - "
                        f"{job.stats.throughput_mbps:.2f} MB/s, "
                        f"{job.stats.bandwidth_savings_percent:.1f}% bandwidth saved"
                    )
                else:
                    job.status = JobStatus.COMPLETED  # Partial success
                    job.errors.append(f"{job.stats.failed_chunks} chunks failed")
                    logger.warning(
                        f"Job {job.id}: Completed with {job.stats.failed_chunks} failed chunks"
                    )

        except Exception as e:
            job.status = JobStatus.FAILED
            job.errors.append(str(e))
            job.stats.end_time = time.time()
            logger.error(f"Job {job.id}: Failed - {e}")

    async def wait(self, job_id: str, poll_interval: float = 0.5) -> DistributedJob:
        """Wait for a job to complete."""
        while True:
            job = self._jobs.get(job_id)
            if not job:
                raise ValueError(f"Job {job_id} not found")

            if job.status in (JobStatus.COMPLETED, JobStatus.FAILED, JobStatus.CANCELLED):
                return job

            await asyncio.sleep(poll_interval)

    def get_job(self, job_id: str) -> Optional[DistributedJob]:
        """Get job by ID."""
        return self._jobs.get(job_id)

    def get_job_status(self, job_id: str) -> Dict[str, Any]:
        """Get detailed job status."""
        job = self._jobs.get(job_id)
        if not job:
            return {"error": f"Job {job_id} not found"}

        chunk_statuses = {}
        for chunk in job.chunks:
            status = chunk.metadata.status.value
            chunk_statuses[status] = chunk_statuses.get(status, 0) + 1

        return {
            "job_id": job.id,
            "status": job.status.value,
            "operation": job.operation,
            "chunks": {
                "total": job.stats.total_chunks,
                "completed": job.stats.completed_chunks,
                "failed": job.stats.failed_chunks,
                "by_status": chunk_statuses
            },
            "bytes": {
                "raw": job.stats.total_bytes_raw,
                "compressed": job.stats.total_bytes_compressed,
                "transferred": job.stats.total_bytes_transferred,
                "compression_ratio": f"{job.stats.compression_ratio:.2%}",
                "bandwidth_saved": f"{job.stats.bandwidth_savings_percent:.1f}%"
            },
            "timing": {
                "duration_seconds": job.stats.duration_seconds,
                "throughput_mbps": job.stats.throughput_mbps
            },
            "errors": job.errors
        }

    def list_jobs(self) -> List[Dict[str, Any]]:
        """List all jobs with summary info."""
        return [
            {
                "id": job.id,
                "status": job.status.value,
                "operation": job.operation,
                "chunks": f"{job.stats.completed_chunks}/{job.stats.total_chunks}",
                "created": job.created_at.isoformat()
            }
            for job in self._jobs.values()
        ]


# Convenience function for simple usage
async def distributed_process(
    data: bytes,
    workers: List[str],
    operation: str = "passthrough",
    chunk_size_mb: int = 100,
    **kwargs
) -> Tuple[bytes, Dict[str, Any]]:
    """
    Simple interface for distributed processing.

    Args:
        data: Data to process
        workers: List of worker URLs
        operation: Operation to perform
        chunk_size_mb: Chunk size
        **kwargs: Additional parameters

    Returns:
        Tuple of (result_bytes, stats_dict)
    """
    coordinator = ChunkCoordinator(
        workers=workers,
        chunk_size_mb=chunk_size_mb
    )

    job = await coordinator.submit(data, operation, kwargs.get("params"))
    job = await coordinator.wait(job.id)

    return job.result or b'', coordinator.get_job_status(job.id)


if __name__ == "__main__":
    # Quick test
    async def test():
        # Create coordinator with single test endpoint
        coordinator = ChunkCoordinator(
            workers=["https://emergent-language.fly.dev"],
            chunk_size_mb=1  # Small chunks for testing
        )

        # Create test data (1MB of JSON-like content)
        test_data = json.dumps({
            "records": [
                {"id": i, "data": f"record_{i}" * 100}
                for i in range(1000)
            ]
        }).encode('utf-8')

        print(f"Test data size: {len(test_data)} bytes")

        # Submit job
        job = await coordinator.submit(
            data=test_data,
            operation="passthrough"
        )

        print(f"Job submitted: {job.id}")

        # Wait for completion
        job = await coordinator.wait(job.id)

        # Print results
        status = coordinator.get_job_status(job.id)
        print(f"\nJob Status: {json.dumps(status, indent=2)}")

        if job.result:
            print(f"\nResult size: {len(job.result)} bytes")

    asyncio.run(test())
