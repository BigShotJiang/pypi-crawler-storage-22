#!/usr/bin/env python3
"""
Emergent Language Translator CLI

Command-line interface for the Emergent Language Translator.
Provides easy access to compression and decompression functionality.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from typing import Any, Dict
from pathlib import Path


def main():
    """Main CLI entry point."""
    try:
        from . import TranslatorSDK, __version__
    except ImportError:
        print(
            "CLI requires the SDK extra: pip install emergent-translator[sdk]",
            file=sys.stderr,
        )
        sys.exit(1)

    parser = argparse.ArgumentParser(
        description="Emergent Language Translator CLI - 60x compression efficiency for AI communication",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Compress a JSON file
  emergent-translator compress data.json

  # Compress JSON from stdin
  echo '{"message": "hello"}' | emergent-translator compress -

  # Decompress a file
  emergent-translator decompress compressed.bin

  # Check API health
  emergent-translator health

  # Benchmark compression
  emergent-translator benchmark --size 1000
"""
    )

    parser.add_argument(
        "--version",
        action="version",
        version=f"emergent-translator {__version__}"
    )

    parser.add_argument(
        "--api-url",
        default="http://149.28.33.118:8001",
        help="API base URL (default: %(default)s)"
    )

    parser.add_argument(
        "--api-key",
        default="eudaimonia-translator-demo",
        help="API key for authentication"
    )

    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Verbose output"
    )

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Compress command
    compress_parser = subparsers.add_parser("compress", help="Compress data")
    compress_parser.add_argument(
        "input",
        help="Input file (JSON) or '-' for stdin"
    )
    compress_parser.add_argument(
        "--output", "-o",
        help="Output file (default: input.compressed)"
    )
    compress_parser.add_argument(
        "--format", "-f",
        choices=["json", "csv", "jsonl", "yaml", "toml", "ini", "xml",
                    "msgpack", "protobuf", "parquet", "arrow",
                    "bson", "cbor", "xlsx"],
        default=None,
        help="Input format (auto-detected from extension if omitted)"
    )
    compress_parser.add_argument(
        "--intent",
        default="general",
        choices=["general", "work", "governance", "social", "resource"],
        help="Compression intent (default: %(default)s)"
    )

    # Decompress command
    decompress_parser = subparsers.add_parser("decompress", help="Decompress data")
    decompress_parser.add_argument(
        "input",
        help="Input compressed file or '-' for stdin"
    )
    decompress_parser.add_argument(
        "--output", "-o",
        help="Output file (default: stdout)"
    )
    decompress_parser.add_argument(
        "--format", "-f",
        choices=["json", "csv", "jsonl", "yaml", "toml", "ini", "xml",
                    "msgpack", "protobuf", "parquet", "arrow",
                    "bson", "cbor", "xlsx"],
        default=None,
        help="Output format (auto-detected from output extension if omitted)"
    )

    # Health command
    health_parser = subparsers.add_parser("health", help="Check API health")

    # Benchmark command
    benchmark_parser = subparsers.add_parser("benchmark", help="Run performance benchmarks")
    benchmark_parser.add_argument(
        "--size",
        type=int,
        default=100,
        help="Data size for benchmark (default: %(default)s)"
    )
    benchmark_parser.add_argument(
        "--iterations",
        type=int,
        default=10,
        help="Number of iterations (default: %(default)s)"
    )

    # Stats command
    stats_parser = subparsers.add_parser("stats", help="Get API statistics")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 1

    try:
        # Initialize SDK
        sdk = TranslatorSDK(api_url=args.api_url, api_key=args.api_key)

        if args.command == "compress":
            return compress_command(sdk, args)
        elif args.command == "decompress":
            return decompress_command(sdk, args)
        elif args.command == "health":
            return health_command(sdk, args)
        elif args.command == "benchmark":
            return benchmark_command(sdk, args)
        elif args.command == "stats":
            return stats_command(sdk, args)

    except KeyboardInterrupt:
        print("\n❌ Operation cancelled", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"❌ Error: {e}", file=sys.stderr)
        return 1


def compress_command(sdk: TranslatorSDK, args) -> int:
    """Handle compress command."""
    # Determine format
    fmt = getattr(args, "format", None)
    if fmt is None and args.input != "-":
        try:
            from .format_handlers import detect_format
            fmt = detect_format(args.input)
        except (ImportError, ValueError):
            fmt = "json"
    fmt = fmt or "json"

    # Read input data (binary or text depending on format)
    try:
        from .format_handlers import is_binary_format
        binary_input = is_binary_format(fmt)
    except ImportError:
        binary_input = False

    if args.input == "-":
        input_data = sys.stdin.buffer.read() if binary_input else sys.stdin.read()
    else:
        input_path = Path(args.input)
        if not input_path.exists():
            print(f"❌ Input file not found: {args.input}", file=sys.stderr)
            return 1
        input_data = input_path.read_bytes() if binary_input else input_path.read_text()

    # Parse input according to format
    try:
        if fmt == "json":
            data = json.loads(input_data)
        else:
            from .format_handlers import get_handler
            parse_fn, _ = get_handler(fmt)
            data = parse_fn(input_data)
    except (json.JSONDecodeError, ValueError) as e:
        print(f"❌ Invalid {fmt.upper()} input: {e}", file=sys.stderr)
        return 1

    # Compress
    if args.verbose:
        print(f"🔧 Compressing {fmt.upper()} data with intent: {args.intent}")
        print(f"   Original size: {len(input_data)} bytes")

    start_time = time.time()
    compressed = sdk.compress(data, intent=args.intent)
    compression_time = (time.time() - start_time) * 1000

    if args.verbose:
        compressed_size = len(compressed)
        efficiency = (1 - compressed_size / len(input_data)) * 100
        print(f"   Compressed size: {compressed_size} bytes")
        print(f"   Efficiency: {efficiency:.1f}%")
        print(f"   Compression time: {compression_time:.2f}ms")

    # Write output
    if args.output:
        output_path = Path(args.output)
    else:
        if args.input == "-":
            # Write to stdout for stdin input
            sys.stdout.buffer.write(compressed)
            return 0
        else:
            output_path = Path(args.input).with_suffix(".compressed")

    output_path.write_bytes(compressed)
    print(f"✅ Compressed data written to: {output_path}")
    return 0


def decompress_command(sdk: TranslatorSDK, args) -> int:
    """Handle decompress command."""
    # Read compressed data
    if args.input == "-":
        compressed = sys.stdin.buffer.read()
    else:
        input_path = Path(args.input)
        if not input_path.exists():
            print(f"❌ Input file not found: {args.input}", file=sys.stderr)
            return 1
        compressed = input_path.read_bytes()

    # Decompress
    if args.verbose:
        print(f"🔧 Decompressing data")
        print(f"   Compressed size: {len(compressed)} bytes")

    start_time = time.time()
    decompressed = sdk.decompress(compressed)
    decompress_time = (time.time() - start_time) * 1000

    # Determine output format
    fmt = getattr(args, "format", None)
    if fmt is None and args.output:
        try:
            from .format_handlers import detect_format
            fmt = detect_format(args.output)
        except (ImportError, ValueError):
            fmt = "json"
    fmt = fmt or "json"

    # Serialize to output format
    try:
        from .format_handlers import is_binary_format
        binary_output = is_binary_format(fmt)
    except ImportError:
        binary_output = False

    if fmt == "json":
        output_data = json.dumps(decompressed, indent=2)
    else:
        from .format_handlers import get_handler
        _, serialize_fn = get_handler(fmt)
        data_list = decompressed if isinstance(decompressed, list) else [decompressed]
        output_data = serialize_fn(data_list)

    if args.verbose:
        print(f"   Decompressed size: {len(output_data)} bytes")
        print(f"   Output format: {fmt.upper()}")
        print(f"   Decompression time: {decompress_time:.2f}ms")

    # Write output
    if args.output:
        output_path = Path(args.output)
        if binary_output:
            output_path.write_bytes(output_data)
        else:
            output_path.write_text(output_data)
        print(f"✅ Decompressed data written to: {output_path}")
    else:
        if binary_output:
            sys.stdout.buffer.write(output_data)
        else:
            print(output_data)

    return 0


def health_command(sdk: TranslatorSDK, args) -> int:
    """Handle health command."""
    if args.verbose:
        print(f"🔍 Checking API health at: {sdk.api_url}")

    try:
        health = sdk.get_health()

        if health.get("status") == "healthy":
            print("✅ API is healthy")
        else:
            print("⚠️ API health check failed")
            return 1

        if args.verbose:
            print(f"   Version: {health.get('version', 'unknown')}")
            print(f"   Emergent language: {'✅' if health.get('emergent_language_available') else '❌'}")
            print(f"   Oracle: {'✅' if health.get('oracle_available') else '❌'}")
            print(f"   Uptime: {health.get('uptime_seconds', 0):.1f} seconds")
            print(f"   Memory usage: {health.get('memory_usage_mb', 0):.1f} MB")

        return 0

    except Exception as e:
        print(f"❌ Health check failed: {e}", file=sys.stderr)
        return 1


def benchmark_command(sdk: TranslatorSDK, args) -> int:
    """Handle benchmark command."""
    print(f"⚡ Running compression benchmark")
    print(f"   Data size: {args.size} items")
    print(f"   Iterations: {args.iterations}")
    print("-" * 50)

    # Generate test data
    test_data = {
        "benchmark": True,
        "items": [f"item_{i}" for i in range(args.size)],
        "metadata": {f"key_{i}": f"value_{i}" for i in range(min(args.size, 100))}
    }

    original_size = len(json.dumps(test_data))
    print(f"📊 Original data size: {original_size} bytes")

    # Warmup
    if args.verbose:
        print("🔥 Warming up...")
    for _ in range(3):
        sdk.compress(test_data)

    # Benchmark compression
    compression_times = []
    compressed_sizes = []

    for i in range(args.iterations):
        start_time = time.time()
        compressed = sdk.compress(test_data)
        end_time = time.time()

        compression_time = (end_time - start_time) * 1000
        compression_times.append(compression_time)
        compressed_sizes.append(len(compressed))

        if args.verbose:
            print(f"   Iteration {i+1}: {compression_time:.2f}ms")

    # Calculate statistics
    avg_compression_time = sum(compression_times) / len(compression_times)
    min_compression_time = min(compression_times)
    max_compression_time = max(compression_times)

    avg_compressed_size = sum(compressed_sizes) / len(compressed_sizes)
    efficiency = (1 - avg_compressed_size / original_size) * 100

    print("\n📈 Benchmark Results:")
    print(f"   Average compression time: {avg_compression_time:.2f}ms")
    print(f"   Min compression time: {min_compression_time:.2f}ms")
    print(f"   Max compression time: {max_compression_time:.2f}ms")
    print(f"   Average compressed size: {avg_compressed_size:.0f} bytes")
    print(f"   Compression efficiency: {efficiency:.1f}%")
    print(f"   Throughput: {1000/avg_compression_time:.1f} compressions/second")

    return 0


def stats_command(sdk: TranslatorSDK, args) -> int:
    """Handle stats command."""
    if args.verbose:
        print(f"📊 Getting API statistics from: {sdk.api_url}")

    try:
        stats = sdk.get_stats()

        print("📈 API Statistics:")
        print(f"   Total translations: {stats.get('total_translations', 0)}")
        print(f"   Data processed: {stats.get('total_data_processed', 0)} bytes")
        print(f"   Compression savings: {stats.get('total_compression_savings', 0)} bytes")
        print(f"   Average compression ratio: {stats.get('average_compression_ratio', 0):.3f}")
        print(f"   Requests per minute: {stats.get('requests_per_minute', 0):.1f}")
        print(f"   Uptime: {stats.get('uptime_seconds', 0) / 3600:.1f} hours")

        return 0

    except Exception as e:
        print(f"❌ Failed to get stats: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())