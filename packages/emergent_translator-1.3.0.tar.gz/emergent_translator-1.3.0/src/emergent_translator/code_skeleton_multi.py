"""Multi-language code skeletonization facade.

Dispatches to the Python ``ast``-based skeletonizer (:mod:`code_skeleton`) for
``.py`` files and to the tree-sitter-based skeletonizer (:mod:`code_skeleton_ts`)
for TypeScript, JavaScript, and Rust files.

Example::

    >>> from emergent_translator.code_skeleton_multi import skeletonize_auto
    >>> print(skeletonize_auto("def foo(): return 1", language="python"))
    def foo():
        ...
"""

from __future__ import annotations

import fnmatch
import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Union

from .code_skeleton import (
    CodeSkeleton,
    SkeletonResult,
    skeletonize,
    skeletonize_dir,
    skeletonize_file,
)
from .code_skeleton_ts import (
    EXT_TO_LANG,
    LANG_CONFIGS,
    detect_language,
    skeletonize_ts,
    skeletonize_ts_file,
)

# All supported extensions
_PYTHON_EXTENSIONS = {".py"}
_TS_EXTENSIONS = set(EXT_TO_LANG.keys())
_ALL_EXTENSIONS = _PYTHON_EXTENSIONS | _TS_EXTENSIONS


# ---------------------------------------------------------------------------
# Free functions
# ---------------------------------------------------------------------------


def skeletonize_auto(
    source: str,
    language: str,
    focal: Optional[list[str]] = None,
    keep_docstrings: bool = True,
) -> str:
    """Skeletonize *source* code, auto-dispatching by *language*.

    Parameters
    ----------
    source:
        Source code as a string.
    language:
        One of ``"python"``, ``"typescript"``, ``"tsx"``, ``"javascript"``,
        ``"rust"``.
    focal:
        Function/method names to keep fully expanded.
    keep_docstrings:
        Preserve docstrings / doc comments.
    """
    if language == "python":
        return skeletonize(source, focal=focal, keep_docstrings=keep_docstrings)
    if language in LANG_CONFIGS:
        return skeletonize_ts(
            source, language=language, focal=focal, keep_docstrings=keep_docstrings
        )
    raise ValueError(
        f"Unsupported language: {language!r}. "
        f"Supported: {sorted(['python'] + list(LANG_CONFIGS.keys()))}"
    )


def _detect_language_full(path: Union[str, Path]) -> Optional[str]:
    """Detect language from extension, including Python."""
    ext = Path(path).suffix.lower()
    if ext == ".py":
        return "python"
    return EXT_TO_LANG.get(ext)


def skeletonize_file_auto(
    path: Union[str, Path],
    focal: Optional[list[str]] = None,
    keep_docstrings: bool = True,
) -> SkeletonResult:
    """Read a source file and return a :class:`SkeletonResult`.

    Auto-detects language from the file extension.
    """
    path = Path(path)
    lang = _detect_language_full(path)
    if lang is None:
        raise ValueError(f"Cannot detect language for {path.suffix!r}")
    if lang == "python":
        return skeletonize_file(path, focal=focal, keep_docstrings=keep_docstrings)
    return skeletonize_ts_file(
        path, focal=focal, keep_docstrings=keep_docstrings, language=lang
    )


def skeletonize_dir_multi(
    root: Union[str, Path],
    focal: Optional[list[str]] = None,
    keep_docstrings: bool = True,
    exclude: Optional[list[str]] = None,
    extensions: Optional[list[str]] = None,
) -> Dict[str, SkeletonResult]:
    """Skeletonize all supported source files under *root*.

    Parameters
    ----------
    root:
        Directory to walk.
    focal:
        Focal function names (applied to all files).
    keep_docstrings:
        Preserve docstrings / doc comments.
    exclude:
        Glob patterns for relative paths to skip.
    extensions:
        File extensions to include (e.g. ``[".ts", ".py"]``).
        Defaults to all supported extensions.
    """
    root = Path(root)
    exclude = exclude or []
    allowed = set(extensions) if extensions else _ALL_EXTENSIONS
    results: Dict[str, SkeletonResult] = {}

    for dirpath, _dirnames, filenames in os.walk(root):
        for fname in sorted(filenames):
            ext = Path(fname).suffix.lower()
            if ext not in allowed:
                continue
            full = Path(dirpath) / fname
            rel = str(full.relative_to(root))

            if any(fnmatch.fnmatch(rel, pat) for pat in exclude):
                continue

            try:
                results[rel] = skeletonize_file_auto(
                    full, focal=focal, keep_docstrings=keep_docstrings
                )
            except Exception:
                continue

    return results


# ---------------------------------------------------------------------------
# Class wrapper
# ---------------------------------------------------------------------------


class MultiLanguageSkeleton:
    """Stateful wrapper for multi-language skeletonization.

    Same API shape as :class:`CodeSkeleton` but supports all languages.

    Example::

        >>> skel = MultiLanguageSkeleton(focal=["handleLogin"])
        >>> result = skel.skeletonize_file("auth.ts")
    """

    def __init__(
        self,
        focal: Optional[list[str]] = None,
        keep_docstrings: bool = True,
        exclude: Optional[list[str]] = None,
        extensions: Optional[list[str]] = None,
    ):
        self._focal: Set[str] = set(focal) if focal else set()
        self._keep_docstrings = keep_docstrings
        self._exclude = list(exclude) if exclude else []
        self._extensions = list(extensions) if extensions else None

    @property
    def focal(self) -> Set[str]:
        return set(self._focal)

    def add_focal(self, *names: str) -> None:
        self._focal.update(names)

    def remove_focal(self, *names: str) -> None:
        self._focal -= set(names)

    def skeletonize(self, source: str, language: str) -> str:
        return skeletonize_auto(
            source,
            language=language,
            focal=list(self._focal),
            keep_docstrings=self._keep_docstrings,
        )

    def skeletonize_file(self, path: Union[str, Path]) -> SkeletonResult:
        return skeletonize_file_auto(
            path,
            focal=list(self._focal),
            keep_docstrings=self._keep_docstrings,
        )

    def skeletonize_dir(
        self, root: Union[str, Path]
    ) -> Dict[str, SkeletonResult]:
        return skeletonize_dir_multi(
            root,
            focal=list(self._focal),
            keep_docstrings=self._keep_docstrings,
            exclude=self._exclude,
            extensions=self._extensions,
        )

    @staticmethod
    def summary(results: Dict[str, SkeletonResult]) -> Dict[str, Any]:
        return CodeSkeleton.summary(results)
