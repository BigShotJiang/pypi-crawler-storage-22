"""Tree-sitter-based code skeletonization for TypeScript, JavaScript, and Rust.

Replaces non-focal function/method bodies with ``{ ... }`` to reduce token usage
when feeding source code to LLMs.  Uses ``tree-sitter`` for parsing — requires
``tree-sitter`` and ``tree-sitter-language-pack`` as optional dependencies.

Example::

    >>> from emergent_translator.code_skeleton_ts import skeletonize_ts
    >>> print(skeletonize_ts('''
    ... function greet(name: string): string {
    ...     const msg = `Hello, ${name}!`;
    ...     console.log(msg);
    ...     return msg;
    ... }
    ... ''', language="typescript"))
    <BLANKLINE>
    function greet(name: string): string { ... }
    <BLANKLINE>
"""

from __future__ import annotations

import fnmatch
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Union

try:
    from tree_sitter import Language, Parser  # noqa: F401
    from tree_sitter_language_pack import get_language, get_parser

    _HAS_TREE_SITTER = True
except ImportError:
    _HAS_TREE_SITTER = False

from .code_skeleton import SkeletonResult, _is_focal

# ---------------------------------------------------------------------------
# Language configuration
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class _LangConfig:
    """Per-language tree-sitter configuration."""

    name: str
    extensions: tuple[str, ...]
    ts_language_name: str
    function_node_types: tuple[str, ...]
    method_node_types: tuple[str, ...]
    class_node_types: tuple[str, ...]
    body_node_type: str
    doccomment_prefix: str
    # Node types whose children we recurse into for functions
    container_node_types: tuple[str, ...] = ()
    # Node types that are wrappers (e.g. export_statement) we look through
    wrapper_node_types: tuple[str, ...] = ()


LANG_CONFIGS: Dict[str, _LangConfig] = {
    "typescript": _LangConfig(
        name="typescript",
        extensions=(".ts",),
        ts_language_name="typescript",
        function_node_types=("function_declaration", "generator_function_declaration"),
        method_node_types=("method_definition",),
        class_node_types=("class_declaration",),
        body_node_type="statement_block",
        doccomment_prefix="/**",
        container_node_types=("class_declaration", "class_body"),
        wrapper_node_types=("export_statement",),
    ),
    "tsx": _LangConfig(
        name="tsx",
        extensions=(".tsx",),
        ts_language_name="tsx",
        function_node_types=("function_declaration", "generator_function_declaration"),
        method_node_types=("method_definition",),
        class_node_types=("class_declaration",),
        body_node_type="statement_block",
        doccomment_prefix="/**",
        container_node_types=("class_declaration", "class_body"),
        wrapper_node_types=("export_statement",),
    ),
    "javascript": _LangConfig(
        name="javascript",
        extensions=(".js", ".jsx"),
        ts_language_name="javascript",
        function_node_types=("function_declaration", "generator_function_declaration"),
        method_node_types=("method_definition",),
        class_node_types=("class_declaration",),
        body_node_type="statement_block",
        doccomment_prefix="/**",
        container_node_types=("class_declaration", "class_body"),
        wrapper_node_types=("export_statement",),
    ),
    "rust": _LangConfig(
        name="rust",
        extensions=(".rs",),
        ts_language_name="rust",
        function_node_types=("function_item",),
        method_node_types=("function_item",),
        class_node_types=("impl_item", "trait_item"),
        body_node_type="block",
        doccomment_prefix="///",
        container_node_types=("impl_item", "trait_item", "declaration_list"),
        wrapper_node_types=(),
    ),
}

EXT_TO_LANG: Dict[str, str] = {
    ".ts": "typescript",
    ".tsx": "tsx",
    ".js": "javascript",
    ".jsx": "javascript",
    ".rs": "rust",
}

# ---------------------------------------------------------------------------
# Body range dataclass
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class _TSBodyRange:
    """Byte-range metadata for a single function/method body."""

    qual_name: str
    node_type: str
    body_start_byte: int
    body_end_byte: int
    has_block_body: bool


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _check_tree_sitter() -> None:
    """Raise ImportError with install instructions if tree-sitter is missing."""
    if not _HAS_TREE_SITTER:
        raise ImportError(
            "tree-sitter is required for multi-language skeletonization. "
            "Install with: pip install 'emergent-translator[skeleton]' "
            "or: pip install tree-sitter tree-sitter-language-pack"
        )


def _get_function_name(node: Any) -> Optional[str]:
    """Extract the name identifier from a function/method node."""
    name_node = node.child_by_field_name("name")
    if name_node is not None:
        return name_node.text.decode("utf-8")
    # For method_definition in JS/TS, the name may be a property_identifier child
    for child in node.children:
        if child.type in ("identifier", "property_identifier"):
            return child.text.decode("utf-8")
    return None


def _get_arrow_name(node: Any) -> Optional[str]:
    """Walk up from an arrow_function to find its variable name.

    Pattern: ``lexical_declaration > variable_declarator > arrow_function``
    """
    parent = node.parent
    if parent is not None and parent.type == "variable_declarator":
        name_node = parent.child_by_field_name("name")
        if name_node is not None:
            return name_node.text.decode("utf-8")
    return None


def _find_body_node(node: Any, body_type: str) -> Any:
    """Find the body child (statement_block or block) of a function node."""
    body = node.child_by_field_name("body")
    if body is not None and body.type == body_type:
        return body
    # Fallback: search children
    for child in node.children:
        if child.type == body_type:
            return child
    return None


def _find_doccomment(node: Any, config: _LangConfig) -> Optional[Any]:
    """Check the previous sibling for a doc comment."""
    prev = node.prev_named_sibling
    if prev is not None and prev.type == "comment":
        text = prev.text.decode("utf-8").strip()
        if text.startswith(config.doccomment_prefix):
            return prev
    # For Rust, also check for line_comment with ///
    if config.doccomment_prefix == "///" and prev is not None:
        if prev.type == "line_comment":
            text = prev.text.decode("utf-8").strip()
            if text.startswith("///"):
                return prev
    return None


def _collect_ts_ranges(
    root: Any,
    source_bytes: bytes,
    config: _LangConfig,
) -> List[_TSBodyRange]:
    """Recursively walk the tree and collect body ranges for all functions."""
    ranges: List[_TSBodyRange] = []

    def _walk(node: Any, prefix: str = "") -> None:
        for child in node.children:
            # Look through wrapper nodes (export_statement)
            actual = child
            if child.type in config.wrapper_node_types:
                # Find the actual declaration inside the wrapper
                for grandchild in child.children:
                    if grandchild.type in (
                        *config.function_node_types,
                        *config.class_node_types,
                        "lexical_declaration",
                    ):
                        actual = grandchild
                        break

            # Handle function/method declarations
            if actual.type in config.function_node_types:
                name = _get_function_name(actual)
                if name is None:
                    _walk(actual, prefix)
                    continue
                qual = f"{prefix}.{name}" if prefix else name
                body = _find_body_node(actual, config.body_node_type)
                if body is not None:
                    ranges.append(
                        _TSBodyRange(
                            qual_name=qual,
                            node_type=actual.type,
                            body_start_byte=body.start_byte,
                            body_end_byte=body.end_byte,
                            has_block_body=True,
                        )
                    )
                # Recurse into function body for nested functions
                _walk(actual, qual)

            elif actual.type in config.method_node_types:
                name = _get_function_name(actual)
                if name is None:
                    _walk(actual, prefix)
                    continue
                qual = f"{prefix}.{name}" if prefix else name
                body = _find_body_node(actual, config.body_node_type)
                if body is not None:
                    ranges.append(
                        _TSBodyRange(
                            qual_name=qual,
                            node_type=actual.type,
                            body_start_byte=body.start_byte,
                            body_end_byte=body.end_byte,
                            has_block_body=True,
                        )
                    )
                _walk(actual, qual)

            elif actual.type in config.class_node_types:
                # Get class/impl/trait name
                name = _get_function_name(actual)
                cls_qual = f"{prefix}.{name}" if prefix else name if name else prefix
                _walk(actual, cls_qual)

            elif actual.type == "lexical_declaration":
                # Handle arrow functions: const foo = () => { ... }
                _walk_lexical_declaration(actual, prefix, config, ranges)

            elif actual.type in config.container_node_types:
                # Recurse into class bodies, impl blocks, etc.
                _walk(actual, prefix)

            else:
                # Recurse into other nodes (e.g., program-level statements)
                _walk(actual, prefix)

    def _walk_lexical_declaration(
        node: Any, prefix: str, cfg: _LangConfig, out: List[_TSBodyRange]
    ) -> None:
        """Handle lexical_declaration nodes that may contain arrow functions."""
        for child in node.children:
            if child.type == "variable_declarator":
                # Check if the value is an arrow function
                value = child.child_by_field_name("value")
                if value is not None and value.type == "arrow_function":
                    name = _get_arrow_name(value)
                    if name is None:
                        name = "<anonymous>"
                    qual = f"{prefix}.{name}" if prefix else name
                    body = _find_body_node(value, cfg.body_node_type)
                    if body is not None:
                        out.append(
                            _TSBodyRange(
                                qual_name=qual,
                                node_type="arrow_function",
                                body_start_byte=body.start_byte,
                                body_end_byte=body.end_byte,
                                has_block_body=True,
                            )
                        )
                    # Recurse for nested functions inside arrow body
                    _walk(value, qual)

    _walk(root)
    return ranges


def _apply_replacements(
    source_bytes: bytes,
    ranges: List[_TSBodyRange],
    focal: Set[str],
    keep_docstrings: bool,
) -> bytes:
    """Apply byte-level replacements to collapse non-focal function bodies.

    Sorts ranges by body_start_byte descending so replacements don't shift
    earlier offsets.
    """
    # Filter to non-focal ranges with block bodies
    to_replace = [
        r
        for r in ranges
        if r.has_block_body and not _is_focal(r.qual_name, focal)
    ]

    # Sort descending by start byte so we can replace from end to start
    to_replace.sort(key=lambda r: r.body_start_byte, reverse=True)

    result = source_bytes
    for r in to_replace:
        result = result[: r.body_start_byte] + b"{ ... }" + result[r.body_end_byte :]

    return result


# ---------------------------------------------------------------------------
# Public functions
# ---------------------------------------------------------------------------


def detect_language(path: Union[str, Path]) -> Optional[str]:
    """Detect language from file extension.

    Returns one of ``"typescript"``, ``"tsx"``, ``"javascript"``, ``"rust"``,
    or ``None`` if the extension is not recognized.
    """
    ext = Path(path).suffix.lower()
    return EXT_TO_LANG.get(ext)


def skeletonize_ts(
    source: str,
    language: str,
    focal: Optional[list[str]] = None,
    keep_docstrings: bool = True,
) -> str:
    """Return a skeletonized version of *source* for a braced language.

    Non-focal function/method bodies are replaced with ``{ ... }``.

    Parameters
    ----------
    source:
        Source code as a string.
    language:
        One of ``"typescript"``, ``"tsx"``, ``"javascript"``, ``"rust"``.
    focal:
        List of function/method names to keep fully expanded.
    keep_docstrings:
        If True (default), doc comments before functions are preserved.
        (Doc comments are always preserved as they sit outside the body.)
    """
    _check_tree_sitter()

    if not source or not source.strip():
        return source

    if language not in LANG_CONFIGS:
        raise ValueError(
            f"Unsupported language: {language!r}. "
            f"Supported: {sorted(LANG_CONFIGS.keys())}"
        )

    config = LANG_CONFIGS[language]
    source_bytes = source.encode("utf-8")

    parser = get_parser(config.ts_language_name)
    tree = parser.parse(source_bytes)

    ranges = _collect_ts_ranges(tree.root_node, source_bytes, config)

    focal_set: Set[str] = set(focal) if focal else set()
    result_bytes = _apply_replacements(source_bytes, ranges, focal_set, keep_docstrings)

    return result_bytes.decode("utf-8")


def skeletonize_ts_file(
    path: Union[str, Path],
    focal: Optional[list[str]] = None,
    keep_docstrings: bool = True,
    language: Optional[str] = None,
) -> SkeletonResult:
    """Read a source file and return a :class:`SkeletonResult` with stats.

    Parameters
    ----------
    path:
        Path to a TypeScript, JavaScript, or Rust source file.
    focal:
        Focal function names to keep expanded.
    keep_docstrings:
        Preserve doc comments (always preserved for braced languages).
    language:
        Override auto-detection. If ``None``, detected from extension.
    """
    from .claude_compression import estimate_tokens

    _check_tree_sitter()

    path = Path(path)
    if language is None:
        language = detect_language(path)
        if language is None:
            raise ValueError(f"Cannot detect language for {path.suffix!r}")

    source = path.read_text(encoding="utf-8")
    skeleton = skeletonize_ts(
        source, language=language, focal=focal, keep_docstrings=keep_docstrings
    )

    # Count functions
    config = LANG_CONFIGS[language]
    source_bytes = source.encode("utf-8")
    parser = get_parser(config.ts_language_name)
    tree = parser.parse(source_bytes)
    ranges = _collect_ts_ranges(tree.root_node, source_bytes, config)

    focal_set: Set[str] = set(focal) if focal else set()
    total = len(ranges)
    focal_count = sum(1 for r in ranges if _is_focal(r.qual_name, focal_set))
    skeletonized = total - focal_count

    orig_lines = len(source.splitlines())
    skel_lines = len(skeleton.splitlines())
    reduction = (1 - skel_lines / max(orig_lines, 1)) * 100

    orig_tokens = estimate_tokens(source)
    skel_tokens = estimate_tokens(skeleton)
    token_reduction = (1 - skel_tokens / max(orig_tokens, 1)) * 100

    return SkeletonResult(
        source=skeleton,
        original_lines=orig_lines,
        skeleton_lines=skel_lines,
        reduction_pct=round(reduction, 1),
        functions_total=total,
        functions_skeletonized=skeletonized,
        functions_focal=focal_count,
        original_tokens=orig_tokens,
        skeleton_tokens=skel_tokens,
        token_reduction_pct=round(token_reduction, 1),
    )
