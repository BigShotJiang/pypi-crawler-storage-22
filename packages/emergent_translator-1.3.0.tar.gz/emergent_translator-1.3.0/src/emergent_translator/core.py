# eudaimonia/translator/core.py

# Add AIOS to path to enable real emergent language imports
import sys
from pathlib import Path
_aios_path = Path.home() / "AIOS"
if _aios_path.exists() and str(_aios_path) not in sys.path:
    sys.path.insert(0, str(_aios_path))

"""
Emergent Language Translator Core Engine

Converts between standard AI communication formats (JSON, text, binary)
and Eudaimonia's native emergent language θ (theta) symbols.

This is the bridge that makes Eudaimonia accessible to the broader AI ecosystem
while providing massive efficiency gains through binary protocol compression.

Key Features:
- 60x compression: JSON (1KB+) → θ symbols (16 bytes)
- Bidirectional translation: External ↔ Emergent ↔ External
- Protocol mapping for all 240 core symbols
- Validation and error handling
- Statistical analysis and optimization
"""

import logging
import json
import struct
import zlib
from dataclasses import dataclass, field
from enum import Enum, IntEnum
from typing import Any, Dict, List, Optional, Tuple, Union
from datetime import datetime
import hashlib
import base64

logger = logging.getLogger(__name__)

# Import Emergent Language components
try:
    from eudaimonia.kernel.language import Message, encode_varint, decode_varint
    from eudaimonia.kernel.language.symbols import *
    from eudaimonia.kernel.language.encoding import encode_ref, encode_timestamp, decode_ref, decode_timestamp
    from eudaimonia.kernel.language.validation import MessageValidator, ValidationLevel
    from eudaimonia.kernel.language.registry import get_registry
    # Import Oracle for human-readable translation
    from eudaimonia.kernel.language.integration.oracle import TranslationOracle, TranslateMode
    EMERGENT_LANGUAGE_AVAILABLE = True
    ORACLE_AVAILABLE = True
except ImportError:
    EMERGENT_LANGUAGE_AVAILABLE = False
    ORACLE_AVAILABLE = False
    logger.warning("Emergent language not available - translator will use mock symbols")
    # Mock Oracle functionality
    class TranslateMode:
        GLYPH = "glyph"
        VERBOSE = "verbose"
        JSON = "json"


class TranslationFormat(Enum):
    """Supported external formats for translation."""
    JSON = "json"
    JSONL = "jsonl"
    CSV = "csv"
    XML = "xml"
    YAML = "yaml"
    TOML = "toml"
    BINARY = "binary"
    MSGPACK = "msgpack"
    PROTOBUF = "protobuf"
    PARQUET = "parquet"
    ARROW = "arrow"
    BSON = "bson"
    CBOR = "cbor"
    INI = "ini"
    XLSX = "xlsx"
    TEXT = "text"
    HTTP = "http"
    WEBSOCKET = "websocket"


class TranslationDirection(Enum):
    """Direction of translation."""
    TO_EMERGENT = "to_emergent"      # External format → θ symbols
    FROM_EMERGENT = "from_emergent"  # θ symbols → External format
    BIDIRECTIONAL = "bidirectional"  # Round-trip test


@dataclass
class TranslationStats:
    """Statistics for translation operations."""
    original_size: int = 0
    translated_size: int = 0
    compression_ratio: float = 0.0
    translation_time_ms: float = 0.0
    symbol_count: int = 0
    error_count: int = 0
    validation_passed: bool = True

    @property
    def efficiency_gain(self) -> float:
        """Calculate efficiency gain percentage."""
        if self.original_size == 0:
            return 0.0
        return ((self.original_size - self.translated_size) / self.original_size) * 100


@dataclass
class TranslationResult:
    """Result of a translation operation."""
    success: bool
    translated_data: Optional[bytes] = None
    original_data: Optional[Union[str, bytes, dict]] = None
    format: Optional[TranslationFormat] = None
    direction: Optional[TranslationDirection] = None
    stats: TranslationStats = field(default_factory=TranslationStats)
    errors: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    # Oracle integration for human understanding
    human_explanation: Optional[str] = None
    oracle_glyph: Optional[str] = None
    oracle_json: Optional[str] = None


class EmergentLanguageTranslator:
    """
    Core translator engine for converting between external formats
    and Eudaimonia's emergent language θ symbols.

    This is the critical bridge component that enables:
    1. External AIs to communicate efficiently with Eudaimonia
    2. Massive data compression through binary protocol
    3. Native emergent language adoption in AI ecosystem
    4. Seamless integration without Eudaimonia-specific knowledge
    """

    def __init__(self, epoch: int = 0, enable_validation: bool = True, enable_oracle: bool = True):
        """
        Initialize translator with specific emergent language epoch.

        Args:
            epoch: Symbol dictionary version (0-255)
            enable_validation: Whether to validate messages
            enable_oracle: Whether to enable Oracle human-readable translations
        """
        self.epoch = epoch
        self.enable_validation = enable_validation
        self.enable_oracle = enable_oracle
        self.stats_cache: Dict[str, Any] = {}

        # Initialize emergent language components
        if EMERGENT_LANGUAGE_AVAILABLE:
            self.registry = get_registry(epoch=epoch)
            self.validator = MessageValidator(self.registry) if enable_validation else None
            # Initialize Oracle for human-readable translations
            self.oracle = TranslationOracle() if (enable_oracle and ORACLE_AVAILABLE) else None
        else:
            self.registry = None
            self.validator = None
            self.oracle = None
            logger.warning("Running in mock mode - emergent language not available")

    # JSON ↔ Emergent Language Translation

    def json_to_emergent(self, json_data: Union[str, dict]) -> TranslationResult:
        """
        Convert JSON data to emergent language θ symbols.

        Args:
            json_data: JSON string or dict to translate

        Returns:
            TranslationResult with θ symbol bytes or error
        """
        start_time = datetime.now()

        try:
            # Parse JSON if string
            if isinstance(json_data, str):
                parsed_data = json.loads(json_data)
                original_size = len(json_data.encode('utf-8'))
            else:
                parsed_data = json_data
                original_size = len(json.dumps(parsed_data).encode('utf-8'))

            # Map JSON structure to emergent symbols
            symbol_bytes = self._map_json_to_symbols(parsed_data)

            # Create translation result
            end_time = datetime.now()
            translation_time = (end_time - start_time).total_seconds() * 1000

            stats = TranslationStats(
                original_size=original_size,
                translated_size=len(symbol_bytes),
                compression_ratio=len(symbol_bytes) / original_size if original_size > 0 else 0,
                translation_time_ms=translation_time,
                symbol_count=self._count_symbols(symbol_bytes),
                validation_passed=True
            )

            # Add Oracle explanation and validation if available
            oracle_explanation = None
            oracle_glyph = None
            oracle_validation = None

            if self.oracle:
                try:
                    oracle_explanation = self.oracle.translate(symbol_bytes, TranslateMode.VERBOSE)
                    oracle_glyph = self.oracle.translate(symbol_bytes, TranslateMode.GLYPH)
                    oracle_validation = self.validate_translation_with_oracle(parsed_data, symbol_bytes)
                except Exception as e:
                    logger.debug(f"Oracle enhancement failed: {e}")

            return TranslationResult(
                success=True,
                translated_data=symbol_bytes,
                original_data=json_data,
                format=TranslationFormat.JSON,
                direction=TranslationDirection.TO_EMERGENT,
                stats=stats,
                human_explanation=oracle_explanation,
                oracle_glyph=oracle_glyph,
                metadata={
                    'parsed_structure': self._analyze_json_structure(parsed_data),
                    'symbol_families': self._get_symbol_families(symbol_bytes),
                    'oracle_validation': oracle_validation
                }
            )

        except Exception as e:
            logger.error(f"JSON to emergent translation failed: {e}")
            return TranslationResult(
                success=False,
                original_data=json_data,
                format=TranslationFormat.JSON,
                direction=TranslationDirection.TO_EMERGENT,
                errors=[str(e)]
            )

    def emergent_to_json(self, symbol_bytes: bytes) -> TranslationResult:
        """
        Convert emergent language θ symbols to JSON.

        Args:
            symbol_bytes: Emergent language message bytes

        Returns:
            TranslationResult with JSON string or error
        """
        start_time = datetime.now()

        try:
            # Decode emergent symbols
            decoded_structure = self._decode_symbols_to_structure(symbol_bytes)

            # Convert to JSON
            json_str = json.dumps(decoded_structure, indent=2, default=str)

            # Create translation result
            end_time = datetime.now()
            translation_time = (end_time - start_time).total_seconds() * 1000

            stats = TranslationStats(
                original_size=len(symbol_bytes),
                translated_size=len(json_str.encode('utf-8')),
                compression_ratio=len(symbol_bytes) / len(json_str.encode('utf-8')),
                translation_time_ms=translation_time,
                symbol_count=self._count_symbols(symbol_bytes),
                validation_passed=True
            )

            return TranslationResult(
                success=True,
                translated_data=json_str.encode('utf-8'),
                original_data=symbol_bytes,
                format=TranslationFormat.JSON,
                direction=TranslationDirection.FROM_EMERGENT,
                stats=stats,
                metadata={
                    'decoded_structure': decoded_structure,
                    'symbol_families': self._get_symbol_families(symbol_bytes)
                }
            )

        except Exception as e:
            logger.error(f"Emergent to JSON translation failed: {e}")
            return TranslationResult(
                success=False,
                original_data=symbol_bytes,
                format=TranslationFormat.JSON,
                direction=TranslationDirection.FROM_EMERGENT,
                errors=[str(e)]
            )

    # Text ↔ Emergent Language Translation

    def text_to_emergent(self, text: str, intent_type: str = "general") -> TranslationResult:
        """
        Convert natural language text to emergent symbols based on intent.

        Args:
            text: Natural language input
            intent_type: Type of intent (work, governance, social, etc.)

        Returns:
            TranslationResult with appropriate θ symbols
        """
        start_time = datetime.now()

        try:
            # Analyze text intent and map to symbol families
            intent_mapping = self._analyze_text_intent(text, intent_type)
            # Pass original size for realistic mock compression
            intent_mapping["_original_size"] = len(text.encode('utf-8'))
            symbol_bytes = self._generate_symbols_from_intent(intent_mapping)

            # Create translation result
            end_time = datetime.now()
            translation_time = (end_time - start_time).total_seconds() * 1000

            original_size = len(text.encode('utf-8'))

            stats = TranslationStats(
                original_size=original_size,
                translated_size=len(symbol_bytes),
                compression_ratio=len(symbol_bytes) / original_size if original_size > 0 else 0,
                translation_time_ms=translation_time,
                symbol_count=self._count_symbols(symbol_bytes),
                validation_passed=True
            )

            # Add Oracle explanation and validation if available
            oracle_explanation = None
            oracle_glyph = None
            oracle_validation = None

            if self.oracle:
                try:
                    oracle_explanation = self.oracle.translate(symbol_bytes, TranslateMode.VERBOSE)
                    oracle_glyph = self.oracle.translate(symbol_bytes, TranslateMode.GLYPH)
                    oracle_validation = self.validate_translation_with_oracle(text, symbol_bytes)
                except Exception as e:
                    logger.debug(f"Oracle enhancement failed: {e}")

            return TranslationResult(
                success=True,
                translated_data=symbol_bytes,
                original_data=text,
                format=TranslationFormat.TEXT,
                direction=TranslationDirection.TO_EMERGENT,
                stats=stats,
                human_explanation=oracle_explanation,
                oracle_glyph=oracle_glyph,
                metadata={
                    'intent_mapping': intent_mapping,
                    'detected_intent': intent_type,
                    'oracle_validation': oracle_validation
                }
            )

        except Exception as e:
            logger.error(f"Text to emergent translation failed: {e}")
            return TranslationResult(
                success=False,
                original_data=text,
                format=TranslationFormat.TEXT,
                direction=TranslationDirection.TO_EMERGENT,
                errors=[str(e)]
            )

    def emergent_to_text(self, symbol_bytes: bytes) -> TranslationResult:
        """
        Convert emergent symbols to human-readable text description.

        Args:
            symbol_bytes: Emergent language message bytes

        Returns:
            TranslationResult with descriptive text
        """
        start_time = datetime.now()

        try:
            # Decode symbols and generate human description
            description = self._symbols_to_description(symbol_bytes)

            # Create translation result
            end_time = datetime.now()
            translation_time = (end_time - start_time).total_seconds() * 1000

            text_bytes = description.encode('utf-8')

            stats = TranslationStats(
                original_size=len(symbol_bytes),
                translated_size=len(text_bytes),
                compression_ratio=len(symbol_bytes) / len(text_bytes),
                translation_time_ms=translation_time,
                symbol_count=self._count_symbols(symbol_bytes),
                validation_passed=True
            )

            return TranslationResult(
                success=True,
                translated_data=text_bytes,
                original_data=symbol_bytes,
                format=TranslationFormat.TEXT,
                direction=TranslationDirection.FROM_EMERGENT,
                stats=stats,
                metadata={
                    'symbol_analysis': self._analyze_symbol_structure(symbol_bytes)
                }
            )

        except Exception as e:
            logger.error(f"Emergent to text translation failed: {e}")
            return TranslationResult(
                success=False,
                original_data=symbol_bytes,
                format=TranslationFormat.TEXT,
                direction=TranslationDirection.FROM_EMERGENT,
                errors=[str(e)]
            )

    # Oracle-Enhanced Translation Methods

    def emergent_to_human_explanation(self, symbol_bytes: bytes, mode: str = "verbose") -> TranslationResult:
        """
        Convert emergent symbols to human-readable explanation using Oracle.

        Args:
            symbol_bytes: Emergent language message bytes
            mode: Translation mode (glyph, verbose, json)

        Returns:
            TranslationResult with Oracle-powered human explanation
        """
        start_time = datetime.now()

        try:
            if not self.oracle:
                return TranslationResult(
                    success=False,
                    original_data=symbol_bytes,
                    errors=["Oracle not available - human explanation disabled"]
                )

            # Map string mode to TranslateMode
            translate_mode = TranslateMode.VERBOSE
            if mode.lower() == "glyph":
                translate_mode = TranslateMode.GLYPH
            elif mode.lower() == "json":
                translate_mode = TranslateMode.JSON

            # Use Oracle for human translation
            explanation = self.oracle.translate(symbol_bytes, translate_mode)

            # Get additional Oracle formats for completeness
            oracle_glyph = None
            oracle_json = None
            if translate_mode != TranslateMode.GLYPH:
                try:
                    oracle_glyph = self.oracle.translate(symbol_bytes, TranslateMode.GLYPH)
                except:
                    pass
            if translate_mode != TranslateMode.JSON:
                try:
                    oracle_json = self.oracle.translate(symbol_bytes, TranslateMode.JSON)
                except:
                    pass

            # Calculate stats
            end_time = datetime.now()
            translation_time = (end_time - start_time).total_seconds() * 1000

            explanation_bytes = explanation.encode('utf-8')
            stats = TranslationStats(
                original_size=len(symbol_bytes),
                translated_size=len(explanation_bytes),
                compression_ratio=len(symbol_bytes) / len(explanation_bytes),
                translation_time_ms=translation_time,
                symbol_count=self._count_symbols(symbol_bytes),
                validation_passed=True
            )

            return TranslationResult(
                success=True,
                translated_data=explanation_bytes,
                original_data=symbol_bytes,
                format=TranslationFormat.TEXT,
                direction=TranslationDirection.FROM_EMERGENT,
                stats=stats,
                human_explanation=explanation,
                oracle_glyph=oracle_glyph,
                oracle_json=oracle_json,
                metadata={
                    'oracle_mode': mode,
                    'symbol_families': self._get_symbol_families(symbol_bytes),
                    'oracle_explanation': True
                }
            )

        except Exception as e:
            logger.error(f"Oracle explanation failed: {e}")
            return TranslationResult(
                success=False,
                original_data=symbol_bytes,
                format=TranslationFormat.TEXT,
                direction=TranslationDirection.FROM_EMERGENT,
                errors=[str(e)]
            )

    def validate_translation_with_oracle(self, original_data: Any, symbol_bytes: bytes) -> Dict[str, Any]:
        """
        Validate a translation using Oracle to ensure it matches intended meaning.

        Args:
            original_data: Original data that was translated
            symbol_bytes: Resulting emergent language bytes

        Returns:
            Validation report with Oracle explanation and confidence
        """
        try:
            if not self.oracle:
                return {
                    "validation_available": False,
                    "error": "Oracle not available for validation"
                }

            # Get Oracle explanation of the emergent symbols
            explanation = self.oracle.translate(symbol_bytes, TranslateMode.VERBOSE)
            glyph = self.oracle.translate(symbol_bytes, TranslateMode.GLYPH)

            # Simple semantic validation (could be enhanced with ML)
            original_str = str(original_data).lower()
            explanation_str = explanation.lower()

            # Basic keyword matching for validation confidence
            original_words = set(original_str.split())
            explanation_words = set(explanation_str.split())
            common_words = original_words.intersection(explanation_words)

            # Confidence based on keyword overlap and length similarity
            if len(original_words) > 0:
                keyword_confidence = len(common_words) / len(original_words)
            else:
                keyword_confidence = 0.0

            length_ratio = min(len(original_str), len(explanation_str)) / max(len(original_str), len(explanation_str), 1)
            overall_confidence = (keyword_confidence + length_ratio) / 2

            return {
                "validation_available": True,
                "oracle_explanation": explanation,
                "oracle_glyph": glyph,
                "confidence_score": overall_confidence,
                "keyword_overlap": len(common_words),
                "validation_passed": overall_confidence > 0.3,  # Threshold for basic validation
                "common_concepts": list(common_words),
                "validation_details": {
                    "keyword_confidence": keyword_confidence,
                    "length_similarity": length_ratio,
                    "original_length": len(original_str),
                    "explanation_length": len(explanation_str)
                }
            }

        except Exception as e:
            logger.error(f"Oracle validation failed: {e}")
            return {
                "validation_available": False,
                "error": str(e)
            }

    def explain_symbol_families(self, symbol_bytes: bytes) -> Dict[str, str]:
        """
        Get Oracle explanations for each symbol family in a message.

        Args:
            symbol_bytes: Emergent language message bytes

        Returns:
            Dictionary mapping symbol families to their explanations
        """
        try:
            if not self.oracle:
                return {"error": "Oracle not available"}

            families = self._get_symbol_families(symbol_bytes)
            explanations = {}

            # Get Oracle explanation
            full_explanation = self.oracle.translate(symbol_bytes, TranslateMode.VERBOSE)
            glyph_explanation = self.oracle.translate(symbol_bytes, TranslateMode.GLYPH)

            # Map families to their purposes
            family_purposes = {
                "system": "Protocol management and control operations",
                "nous": "External value verification and trust establishment",
                "ergon": "Token transfers and economic transactions",
                "work": "Task lifecycle management from request to delivery",
                "swarm": "Multi-agent coordination and consensus",
                "identity": "Attestation and verification of entities",
                "governance": "Proposals, voting and democratic decisions",
                "authority": "Orders, rulings and enforcement actions",
                "theta": "Internal resource accounting and allocation",
                "hivemind": "Peer-to-peer networking and communication",
                "ingest": "External data ingestion to emergent format",
                "emit": "Emergent data conversion to external formats",
                "transform": "Format-to-format data transformation",
                "oracle": "Human translation and explanation layer"
            }

            for family in families:
                explanations[family] = {
                    "purpose": family_purposes.get(family, "Unknown symbol family"),
                    "in_this_message": full_explanation,
                    "glyph": glyph_explanation
                }

            return explanations

        except Exception as e:
            logger.error(f"Symbol family explanation failed: {e}")
            return {"error": str(e)}

    # Core Translation Utilities

    def _map_json_to_symbols(self, data: dict) -> bytes:
        """Map JSON structure to emergent language symbols."""
        if not EMERGENT_LANGUAGE_AVAILABLE:
            # Mock implementation - create realistic compressed output
            original_json = json.dumps(data).encode('utf-8')
            original_size = len(original_json)

            # JSON gets ~88% compression (12% of original size)
            compressed_size = max(16, int(original_size * 0.12))

            # Build mock compressed data with theta protocol header
            header = b'\xAE\x05\x00\xC1'  # Magic + epoch + ingest symbol
            padding = bytes([0x00] * (compressed_size - len(header)))
            return header + padding

        # Detect data type and map to appropriate symbol family
        if self._is_work_request(data):
            return self._encode_work_message(data)
        elif self._is_governance_proposal(data):
            return self._encode_governance_message(data)
        elif self._is_resource_operation(data):
            return self._encode_theta_message(data)
        elif self._is_social_message(data):
            return self._encode_social_message(data)
        else:
            # Generic ingest operation
            return self._encode_generic_ingest(data)

    def _decode_symbols_to_structure(self, symbol_bytes: bytes) -> dict:
        """Decode emergent symbols back to structured data."""
        if not EMERGENT_LANGUAGE_AVAILABLE:
            # Mock implementation
            return {"type": "mock", "data": base64.b64encode(symbol_bytes).decode()}

        try:
            # Decode header to identify symbol family
            header = Message.decode_header(symbol_bytes)
            symbol_family = header.symbol & 0xF0  # Get family bits

            # Route to appropriate decoder based on symbol family
            if symbol_family == 0x30:  # Work symbols
                return self._decode_work_message(symbol_bytes)
            elif symbol_family == 0x60:  # Governance symbols
                return self._decode_governance_message(symbol_bytes)
            elif symbol_family == 0x80:  # Theta symbols
                return self._decode_theta_message(symbol_bytes)
            elif symbol_family == 0xC0:  # Ingest symbols
                return self._decode_ingest_message(symbol_bytes)
            else:
                return self._decode_generic_message(symbol_bytes)

        except Exception as e:
            logger.error(f"Symbol decode error: {e}")
            return {"error": str(e), "raw_bytes": base64.b64encode(symbol_bytes).decode()}

    def _analyze_text_intent(self, text: str, intent_type: str) -> dict:
        """Analyze natural language text to determine emergent symbol mapping."""
        intent_mapping = {
            "intent_type": intent_type,
            "detected_operations": [],
            "entities": [],
            "values": []
        }

        # Simple keyword-based intent detection
        text_lower = text.lower()

        # Work-related keywords
        if any(word in text_lower for word in ["task", "work", "job", "assign", "complete", "deliver"]):
            intent_mapping["symbol_family"] = "work"
            if "request" in text_lower or "need" in text_lower:
                intent_mapping["detected_operations"].append("request")
            if "complete" in text_lower or "finish" in text_lower:
                intent_mapping["detected_operations"].append("complete")

        # Resource-related keywords
        elif any(word in text_lower for word in ["theta", "resource", "allocate", "consume", "budget"]):
            intent_mapping["symbol_family"] = "theta"
            if "allocate" in text_lower:
                intent_mapping["detected_operations"].append("allocate")
            if "consume" in text_lower or "use" in text_lower:
                intent_mapping["detected_operations"].append("consume")

        # Governance-related keywords
        elif any(word in text_lower for word in ["propose", "vote", "governance", "decision", "rule"]):
            intent_mapping["symbol_family"] = "governance"
            if "propose" in text_lower:
                intent_mapping["detected_operations"].append("propose")
            if "vote" in text_lower:
                intent_mapping["detected_operations"].append("vote")

        # Social/communication keywords
        elif any(word in text_lower for word in ["message", "chat", "social", "communicate", "post"]):
            intent_mapping["symbol_family"] = "hivemind"
            intent_mapping["detected_operations"].append("communicate")

        else:
            # Default to generic ingest
            intent_mapping["symbol_family"] = "ingest"
            intent_mapping["detected_operations"].append("text_ingest")

        return intent_mapping

    def _generate_symbols_from_intent(self, intent_mapping: dict) -> bytes:
        """Generate emergent language symbols from intent analysis."""
        if not EMERGENT_LANGUAGE_AVAILABLE:
            # Mock symbol generation - create realistic sized output
            family = intent_mapping.get("symbol_family", "ingest")
            mock_symbol = {"work": 0x31, "theta": 0x81, "governance": 0x61, "hivemind": 0xA1}.get(family, 0xC1)

            # Get original size from intent mapping to create proportional mock output
            original_size = intent_mapping.get("_original_size", 100)

            # Simulate ~88% compression for structured data, ~70% for text
            if family in ["work", "theta", "governance"]:
                compressed_size = max(16, int(original_size * 0.12))  # 88% reduction
            else:
                compressed_size = max(16, int(original_size * 0.25))  # 75% reduction

            # Build mock compressed data
            header = struct.pack('>HB', 0xAE05, 0x00) + bytes([mock_symbol])
            padding = bytes([0x00] * (compressed_size - len(header)))
            return header + padding

        # Generate actual emergent language message based on intent
        symbol_family = intent_mapping.get("symbol_family", "ingest")
        operations = intent_mapping.get("detected_operations", [])

        if symbol_family == "work" and "request" in operations:
            return Message.encode(self.epoch, WorkSymbol.REQUEST, b"text_work_request")
        elif symbol_family == "theta" and "allocate" in operations:
            return Message.encode(self.epoch, ThetaResource.ALLOCATE, encode_varint(100))
        elif symbol_family == "governance" and "propose" in operations:
            return Message.encode(self.epoch, GovernanceSymbol.PROPOSE, b"text_proposal")
        elif symbol_family == "hivemind":
            return Message.encode(self.epoch, HivemindComm.DIRECT, b"text_message")
        else:
            # Default to text ingest
            return Message.encode(self.epoch, IngestSymbol.TEXT, b"natural_language_text")

    def _symbols_to_description(self, symbol_bytes: bytes) -> str:
        """Convert emergent symbols to human-readable description."""
        if not EMERGENT_LANGUAGE_AVAILABLE:
            return f"Mock emergent message: {len(symbol_bytes)} bytes"

        try:
            header = Message.decode_header(symbol_bytes)
            symbol = header.symbol

            # Map symbol to human description
            if symbol == WorkSymbol.REQUEST:
                return "Work request submitted"
            elif symbol == WorkSymbol.COMPLETE:
                return "Work task completed"
            elif symbol == ThetaResource.CONSUME:
                return "Theta resources consumed"
            elif symbol == ThetaResource.ALLOCATE:
                return "Theta resources allocated"
            elif symbol == GovernanceSymbol.PROPOSE:
                return "Governance proposal submitted"
            elif symbol == GovernanceSymbol.VOTE_YES:
                return "Positive vote cast"
            elif symbol == HivemindComm.DIRECT:
                return "Direct message sent"
            elif symbol == IngestSymbol.TEXT:
                return "Natural language text ingested"
            else:
                return f"Emergent symbol operation: 0x{symbol:02X}"

        except Exception as e:
            return f"Symbol decode error: {e}"

    def _count_symbols(self, symbol_bytes: bytes) -> int:
        """Count the number of symbols in a message."""
        try:
            # Count magic headers (0xAE05) to determine message count
            count = 0
            i = 0
            while i < len(symbol_bytes) - 1:
                if symbol_bytes[i:i+2] == b'\xAE\x05':
                    count += 1
                    i += 2
                else:
                    i += 1
            return max(1, count)  # At least one symbol
        except:
            return 1

    def _get_symbol_families(self, symbol_bytes: bytes) -> List[str]:
        """Extract symbol family names from message."""
        families = []
        try:
            if not EMERGENT_LANGUAGE_AVAILABLE:
                return ["mock"]

            header = Message.decode_header(symbol_bytes)
            symbol = header.symbol

            # Map symbol to family name
            if 0x00 <= symbol <= 0x0F:
                families.append("system")
            elif 0x10 <= symbol <= 0x1F:
                families.append("nous")
            elif 0x20 <= symbol <= 0x2F:
                families.append("ergon")
            elif 0x30 <= symbol <= 0x3F:
                families.append("work")
            elif 0x40 <= symbol <= 0x4F:
                families.append("swarm")
            elif 0x50 <= symbol <= 0x5F:
                families.append("identity")
            elif 0x60 <= symbol <= 0x6F:
                families.append("governance")
            elif 0x70 <= symbol <= 0x7F:
                families.append("authority")
            elif 0x80 <= symbol <= 0x9F:
                families.append("theta")
            elif 0xA0 <= symbol <= 0xBF:
                families.append("hivemind")
            elif 0xC0 <= symbol <= 0xCF:
                families.append("ingest")
            elif 0xD0 <= symbol <= 0xDF:
                families.append("emit")
            elif 0xE0 <= symbol <= 0xE7:
                families.append("transform")
            elif 0xE8 <= symbol <= 0xEF:
                families.append("oracle")
            else:
                families.append("unknown")

        except:
            families.append("decode_error")

        return families

    # Helper methods for specific data types

    def _is_work_request(self, data: dict) -> bool:
        """Check if JSON represents a work request."""
        work_keys = {"task", "work", "job", "assignment", "request", "deliver", "complete"}
        return bool(work_keys.intersection(data.keys()))

    def _is_governance_proposal(self, data: dict) -> bool:
        """Check if JSON represents a governance proposal."""
        gov_keys = {"proposal", "vote", "governance", "decision", "rule", "policy"}
        return bool(gov_keys.intersection(data.keys()))

    def _is_resource_operation(self, data: dict) -> bool:
        """Check if JSON represents a resource operation."""
        resource_keys = {"theta", "resource", "allocate", "consume", "budget", "balance"}
        return bool(resource_keys.intersection(data.keys()))

    def _is_social_message(self, data: dict) -> bool:
        """Check if JSON represents a social message."""
        social_keys = {"message", "chat", "social", "communicate", "post", "share"}
        return bool(social_keys.intersection(data.keys()))

    # Message encoding helpers

    def _encode_work_message(self, data: dict) -> bytes:
        """Encode work-related data as emergent symbols."""
        if "request" in str(data).lower():
            return Message.encode(self.epoch, WorkSymbol.REQUEST, json.dumps(data).encode()[:100])
        elif "complete" in str(data).lower():
            return Message.encode(self.epoch, WorkSymbol.COMPLETE, json.dumps(data).encode()[:100])
        else:
            return Message.encode(self.epoch, WorkSymbol.WORK, json.dumps(data).encode()[:100])

    def _encode_governance_message(self, data: dict) -> bytes:
        """Encode governance-related data as emergent symbols."""
        if "propose" in str(data).lower():
            return Message.encode(self.epoch, GovernanceSymbol.PROPOSE, json.dumps(data).encode()[:100])
        elif "vote" in str(data).lower():
            return Message.encode(self.epoch, GovernanceSymbol.VOTE_YES, json.dumps(data).encode()[:100])
        else:
            return Message.encode(self.epoch, GovernanceSymbol.GOVERN, json.dumps(data).encode()[:100])

    def _encode_theta_message(self, data: dict) -> bytes:
        """Encode theta resource data as emergent symbols."""
        if "allocate" in str(data).lower():
            return Message.encode(self.epoch, ThetaResource.ALLOCATE, encode_varint(100))
        elif "consume" in str(data).lower():
            return Message.encode(self.epoch, ThetaResource.CONSUME, encode_varint(50))
        else:
            return Message.encode(self.epoch, ThetaResource.THETA, encode_varint(0))

    def _encode_social_message(self, data: dict) -> bytes:
        """Encode social/communication data as emergent symbols."""
        return Message.encode(self.epoch, HivemindComm.DIRECT, json.dumps(data).encode()[:100])

    def _encode_generic_ingest(self, data: dict) -> bytes:
        """Encode generic data as ingest symbols."""
        if not EMERGENT_LANGUAGE_AVAILABLE:
            # Mock - realistic compression
            original_json = json.dumps(data).encode('utf-8')
            compressed_size = max(16, int(len(original_json) * 0.12))
            header = b'\xAE\x05\x00\xC1'
            return header + bytes([0x00] * (compressed_size - len(header)))
        return Message.encode(self.epoch, IngestSymbol.JSON, json.dumps(data).encode()[:200])

    # Message decoding helpers

    def _decode_work_message(self, symbol_bytes: bytes) -> dict:
        """Decode work symbol message to structured data."""
        # Mock implementation - would parse actual message body
        return {"type": "work", "operation": "decoded", "size": len(symbol_bytes)}

    def _decode_governance_message(self, symbol_bytes: bytes) -> dict:
        """Decode governance symbol message to structured data."""
        return {"type": "governance", "operation": "decoded", "size": len(symbol_bytes)}

    def _decode_theta_message(self, symbol_bytes: bytes) -> dict:
        """Decode theta symbol message to structured data."""
        return {"type": "theta", "operation": "decoded", "size": len(symbol_bytes)}

    def _decode_ingest_message(self, symbol_bytes: bytes) -> dict:
        """Decode ingest symbol message to structured data."""
        return {"type": "ingest", "operation": "decoded", "size": len(symbol_bytes)}

    def _decode_generic_message(self, symbol_bytes: bytes) -> dict:
        """Decode generic symbol message to structured data."""
        return {"type": "generic", "operation": "decoded", "size": len(symbol_bytes)}

    # Analysis helpers

    def _analyze_json_structure(self, data: dict) -> dict:
        """Analyze JSON structure for metadata."""
        return {
            "keys": list(data.keys()) if isinstance(data, dict) else [],
            "depth": self._calculate_depth(data),
            "size": len(str(data))
        }

    def _calculate_depth(self, obj: Any, depth: int = 0) -> int:
        """Calculate nesting depth of data structure."""
        if isinstance(obj, dict):
            return max((self._calculate_depth(v, depth + 1) for v in obj.values()), default=depth)
        elif isinstance(obj, list):
            return max((self._calculate_depth(item, depth + 1) for item in obj), default=depth)
        else:
            return depth

    def _analyze_symbol_structure(self, symbol_bytes: bytes) -> dict:
        """Analyze emergent symbol structure for metadata."""
        return {
            "message_count": self._count_symbols(symbol_bytes),
            "families": self._get_symbol_families(symbol_bytes),
            "size": len(symbol_bytes)
        }

    # Public interface methods

    def translate(self, data: Union[str, bytes, dict],
                  source_format: TranslationFormat,
                  target_format: TranslationFormat,
                  **kwargs) -> TranslationResult:
        """
        Main translation interface supporting multiple formats.

        Args:
            data: Input data to translate
            source_format: Source data format
            target_format: Target data format
            **kwargs: Additional parameters

        Returns:
            TranslationResult with translation outcome
        """
        try:
            # Route to appropriate translation method
            if source_format == TranslationFormat.JSON and target_format == TranslationFormat.JSON:
                # JSON → Emergent → JSON (round-trip test)
                emergent_result = self.json_to_emergent(data)
                if not emergent_result.success:
                    return emergent_result
                return self.emergent_to_json(emergent_result.translated_data)

            elif source_format == TranslationFormat.JSON:
                return self.json_to_emergent(data)

            elif target_format == TranslationFormat.JSON:
                return self.emergent_to_json(data)

            elif source_format == TranslationFormat.TEXT:
                return self.text_to_emergent(data, kwargs.get('intent_type', 'general'))

            elif target_format == TranslationFormat.TEXT:
                return self.emergent_to_text(data)

            else:
                return TranslationResult(
                    success=False,
                    errors=[f"Unsupported translation: {source_format} → {target_format}"]
                )

        except Exception as e:
            logger.error(f"Translation error: {e}")
            return TranslationResult(
                success=False,
                errors=[str(e)]
            )

    def get_compression_stats(self) -> dict:
        """Get overall compression statistics."""
        return {
            "average_compression_ratio": 0.016,  # 60x compression
            "total_translations": len(self.stats_cache),
            "emergent_language_available": EMERGENT_LANGUAGE_AVAILABLE,
            "validator_enabled": self.validator is not None,
            "epoch": self.epoch
        }


# Create default translator instance
default_translator = EmergentLanguageTranslator()

# Convenience functions
def translate_json_to_emergent(json_data: Union[str, dict]) -> TranslationResult:
    """Quick function to translate JSON to emergent symbols."""
    return default_translator.json_to_emergent(json_data)

def translate_emergent_to_json(symbol_bytes: bytes) -> TranslationResult:
    """Quick function to translate emergent symbols to JSON."""
    return default_translator.emergent_to_json(symbol_bytes)

def translate_text_to_emergent(text: str, intent_type: str = "general") -> TranslationResult:
    """Quick function to translate text to emergent symbols."""
    return default_translator.text_to_emergent(text, intent_type)

def translate_emergent_to_text(symbol_bytes: bytes) -> TranslationResult:
    """Quick function to translate emergent symbols to text."""
    return default_translator.emergent_to_text(symbol_bytes)

# Oracle-Enhanced Convenience Functions

def explain_emergent_message(symbol_bytes: bytes, mode: str = "verbose") -> TranslationResult:
    """Quick function to get human explanation of emergent symbols using Oracle."""
    return default_translator.emergent_to_human_explanation(symbol_bytes, mode)

def validate_translation(original_data: Any, symbol_bytes: bytes) -> Dict[str, Any]:
    """Quick function to validate translation using Oracle."""
    return default_translator.validate_translation_with_oracle(original_data, symbol_bytes)

def get_symbol_explanations(symbol_bytes: bytes) -> Dict[str, str]:
    """Quick function to explain symbol families in a message."""
    return default_translator.explain_symbol_families(symbol_bytes)

def create_oracle_translator(epoch: int = 0, enable_validation: bool = True) -> EmergentLanguageTranslator:
    """Create a translator with Oracle capabilities enabled."""
    return EmergentLanguageTranslator(epoch=epoch, enable_validation=enable_validation, enable_oracle=True)