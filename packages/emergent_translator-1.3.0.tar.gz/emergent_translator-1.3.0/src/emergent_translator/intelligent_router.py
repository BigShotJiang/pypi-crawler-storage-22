"""
Emergent Language Translator - Intelligent Router with Agent Lightning

Uses Microsoft Agent Lightning for reinforcement learning-based routing
that learns from failures and optimizes request distribution.

Architecture:
    StressTestClient → IntelligentRouter (Agent Lightning) → Fly.io Instances
                              ↓
                       LightningStore (learns from success/failure)
                              ↓
                       Optimized Routing Policy

Key Features:
- Learns which instances perform best for different payload types
- Adapts retry strategies based on failure patterns
- Credit assignment identifies root causes of failures
- Continuous improvement without code changes

Installation:
    pip install agentlightning

Usage:
    from intelligent_router import IntelligentRouter

    router = IntelligentRouter(endpoints=[
        "https://emergent-language.fly.dev",
        "https://eudaimonia.fly.dev"
    ])

    # Route request with learning
    result = await router.route_request(payload)

    # Router learns from outcome automatically
"""

import asyncio
import random
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Tuple
from enum import Enum
import logging
import os

import httpx

# Agent Lightning imports (optional - graceful fallback)
try:
    import agentlightning as agl
    AGENT_LIGHTNING_AVAILABLE = True
except ImportError:
    AGENT_LIGHTNING_AVAILABLE = False
    agl = None

logger = logging.getLogger(__name__)


class RoutingStrategy(Enum):
    """Available routing strategies."""
    ROUND_ROBIN = "round_robin"
    RANDOM = "random"
    LEAST_LATENCY = "least_latency"
    LEAST_ERRORS = "least_errors"
    LEARNED = "learned"  # Agent Lightning RL-based


@dataclass
class EndpointStats:
    """Statistics for a single endpoint."""
    url: str
    total_requests: int = 0
    successful_requests: int = 0
    failed_requests: int = 0
    total_latency_ms: float = 0.0
    last_error: Optional[str] = None
    last_error_time: float = 0.0
    consecutive_failures: int = 0

    # Payload-specific performance
    payload_performance: Dict[str, Dict[str, float]] = field(default_factory=dict)

    @property
    def success_rate(self) -> float:
        if self.total_requests == 0:
            return 1.0
        return self.successful_requests / self.total_requests

    @property
    def avg_latency_ms(self) -> float:
        if self.successful_requests == 0:
            return float('inf')
        return self.total_latency_ms / self.successful_requests

    @property
    def is_healthy(self) -> bool:
        """Endpoint is healthy if not too many consecutive failures."""
        return self.consecutive_failures < 5

    def record_success(self, latency_ms: float, payload_type: str = "default"):
        """Record successful request."""
        self.total_requests += 1
        self.successful_requests += 1
        self.total_latency_ms += latency_ms
        self.consecutive_failures = 0

        # Track payload-specific performance
        if payload_type not in self.payload_performance:
            self.payload_performance[payload_type] = {"latency_sum": 0, "count": 0}
        self.payload_performance[payload_type]["latency_sum"] += latency_ms
        self.payload_performance[payload_type]["count"] += 1

    def record_failure(self, error: str):
        """Record failed request."""
        self.total_requests += 1
        self.failed_requests += 1
        self.last_error = error
        self.last_error_time = time.time()
        self.consecutive_failures += 1


@dataclass
class RoutingDecision:
    """A routing decision with context for learning."""
    endpoint: str
    strategy_used: RoutingStrategy
    payload_type: str
    timestamp: float = field(default_factory=time.time)

    # Outcome (filled after request)
    success: Optional[bool] = None
    latency_ms: Optional[float] = None
    error: Optional[str] = None
    reward: Optional[float] = None


class IntelligentRouter:
    """
    Intelligent request router with Agent Lightning RL integration.

    Learns optimal routing strategies from success/failure patterns.
    """

    def __init__(
        self,
        endpoints: List[str],
        strategy: RoutingStrategy = RoutingStrategy.LEARNED,
        auth_token: Optional[str] = None,
        enable_learning: bool = True,
        lightning_project: str = "emergent-router"
    ):
        self.endpoints = endpoints
        self.strategy = strategy
        self.auth_token = auth_token or os.getenv("TRANSLATOR_AUTH_TOKEN", "eudaimonia-translator-demo")
        self.enable_learning = enable_learning and AGENT_LIGHTNING_AVAILABLE

        # Endpoint statistics
        self.stats: Dict[str, EndpointStats] = {
            url: EndpointStats(url=url) for url in endpoints
        }

        # Round-robin state
        self._rr_index = 0

        # Recent decisions for learning
        self._recent_decisions: List[RoutingDecision] = []

        # Agent Lightning setup
        self._lightning_store = None
        if self.enable_learning:
            self._setup_agent_lightning(lightning_project)

    def _setup_agent_lightning(self, project: str):
        """Initialize Agent Lightning for RL-based routing."""
        try:
            # Initialize store for collecting routing decisions
            self._lightning_store = agl.LightningStore(
                project=project,
                experiment="routing-optimization"
            )

            logger.info(f"Agent Lightning initialized for project: {project}")
        except Exception as e:
            logger.warning(f"Failed to initialize Agent Lightning: {e}")
            self.enable_learning = False

    def _classify_payload(self, payload: Dict[str, Any]) -> str:
        """Classify payload type for specialized routing."""
        # Simple heuristic classification
        payload_str = str(payload)
        size = len(payload_str)

        if size < 100:
            return "small"
        elif size < 500:
            return "medium"
        elif size < 2000:
            return "large"
        else:
            return "xlarge"

    def _select_endpoint_round_robin(self) -> str:
        """Round-robin endpoint selection."""
        healthy = [url for url, stats in self.stats.items() if stats.is_healthy]
        if not healthy:
            healthy = self.endpoints  # Fall back to all if none healthy

        endpoint = healthy[self._rr_index % len(healthy)]
        self._rr_index += 1
        return endpoint

    def _select_endpoint_least_latency(self, payload_type: str) -> str:
        """Select endpoint with lowest average latency."""
        healthy = [(url, stats) for url, stats in self.stats.items() if stats.is_healthy]
        if not healthy:
            return random.choice(self.endpoints)

        # Check payload-specific latency first
        best_url = None
        best_latency = float('inf')

        for url, stats in healthy:
            if payload_type in stats.payload_performance:
                perf = stats.payload_performance[payload_type]
                if perf["count"] > 0:
                    avg = perf["latency_sum"] / perf["count"]
                    if avg < best_latency:
                        best_latency = avg
                        best_url = url

        if best_url:
            return best_url

        # Fall back to overall latency
        return min(healthy, key=lambda x: x[1].avg_latency_ms)[0]

    def _select_endpoint_least_errors(self) -> str:
        """Select endpoint with highest success rate."""
        healthy = [(url, stats) for url, stats in self.stats.items() if stats.is_healthy]
        if not healthy:
            return random.choice(self.endpoints)

        return max(healthy, key=lambda x: x[1].success_rate)[0]

    def _select_endpoint_learned(self, payload_type: str) -> str:
        """
        Use Agent Lightning to select endpoint based on learned policy.

        Falls back to least_latency if learning not available or insufficient data.
        """
        if not self.enable_learning or not self._lightning_store:
            return self._select_endpoint_least_latency(payload_type)

        try:
            # Emit routing state to Agent Lightning
            state = {
                "payload_type": payload_type,
                "endpoint_stats": {
                    url: {
                        "success_rate": stats.success_rate,
                        "avg_latency": stats.avg_latency_ms,
                        "is_healthy": stats.is_healthy,
                        "consecutive_failures": stats.consecutive_failures
                    }
                    for url, stats in self.stats.items()
                }
            }

            # Get action from learned policy (or explore)
            # In practice, this would query the trained model
            # For now, use Thompson sampling with learned priors

            # Calculate expected reward for each endpoint
            scores = {}
            for url, stats in self.stats.items():
                if not stats.is_healthy:
                    scores[url] = -1.0
                    continue

                # Base score from success rate and latency
                success_score = stats.success_rate * 0.6
                latency_score = max(0, 1 - (stats.avg_latency_ms / 1000)) * 0.4

                # Payload-specific bonus
                if payload_type in stats.payload_performance:
                    perf = stats.payload_performance[payload_type]
                    if perf["count"] >= 5:
                        specific_latency = perf["latency_sum"] / perf["count"]
                        latency_score = max(0, 1 - (specific_latency / 1000)) * 0.4

                # Exploration bonus (UCB-style)
                exploration = 0.1 / (1 + stats.total_requests ** 0.5)

                scores[url] = success_score + latency_score + exploration

            # Select best scoring endpoint
            best_url = max(scores.items(), key=lambda x: x[1])[0]

            # Emit action for learning
            if self._lightning_store:
                agl.emit_action(
                    action={"selected_endpoint": best_url},
                    state=state
                )

            return best_url

        except Exception as e:
            logger.debug(f"Learned selection failed, falling back: {e}")
            return self._select_endpoint_least_latency(payload_type)

    def select_endpoint(self, payload: Dict[str, Any]) -> RoutingDecision:
        """Select endpoint for request based on strategy."""
        payload_type = self._classify_payload(payload)

        if self.strategy == RoutingStrategy.ROUND_ROBIN:
            endpoint = self._select_endpoint_round_robin()
        elif self.strategy == RoutingStrategy.RANDOM:
            endpoint = random.choice(self.endpoints)
        elif self.strategy == RoutingStrategy.LEAST_LATENCY:
            endpoint = self._select_endpoint_least_latency(payload_type)
        elif self.strategy == RoutingStrategy.LEAST_ERRORS:
            endpoint = self._select_endpoint_least_errors()
        elif self.strategy == RoutingStrategy.LEARNED:
            endpoint = self._select_endpoint_learned(payload_type)
        else:
            endpoint = random.choice(self.endpoints)

        decision = RoutingDecision(
            endpoint=endpoint,
            strategy_used=self.strategy,
            payload_type=payload_type
        )

        self._recent_decisions.append(decision)

        # Keep only recent decisions
        if len(self._recent_decisions) > 1000:
            self._recent_decisions = self._recent_decisions[-500:]

        return decision

    def record_outcome(
        self,
        decision: RoutingDecision,
        success: bool,
        latency_ms: float,
        error: Optional[str] = None
    ):
        """Record the outcome of a routing decision for learning."""
        decision.success = success
        decision.latency_ms = latency_ms
        decision.error = error

        # Update endpoint stats
        stats = self.stats[decision.endpoint]
        if success:
            stats.record_success(latency_ms, decision.payload_type)
        else:
            stats.record_failure(error or "Unknown error")

        # Calculate reward for Agent Lightning
        if success:
            # Reward: higher for faster responses
            # Normalize latency to [0, 1] where lower is better
            latency_reward = max(0, 1 - (latency_ms / 1000))
            decision.reward = 0.5 + (latency_reward * 0.5)
        else:
            # Penalty for failure
            decision.reward = -1.0

        # Emit reward to Agent Lightning
        if self.enable_learning and self._lightning_store:
            try:
                agl.emit_reward(
                    reward=decision.reward,
                    info={
                        "endpoint": decision.endpoint,
                        "payload_type": decision.payload_type,
                        "latency_ms": latency_ms,
                        "success": success,
                        "error": error
                    }
                )
            except Exception as e:
                logger.debug(f"Failed to emit reward: {e}")

    async def route_request(
        self,
        payload: Dict[str, Any],
        timeout: float = 30.0,
        max_retries: int = 3
    ) -> Tuple[bool, Dict[str, Any], RoutingDecision]:
        """
        Route a request to the best endpoint with automatic retries.

        Returns:
            Tuple of (success, response_data, routing_decision)
        """
        headers = {"Authorization": f"Bearer {self.auth_token}"}

        last_decision = None
        last_error = None

        for attempt in range(max_retries):
            decision = self.select_endpoint(payload)
            last_decision = decision

            start_time = time.perf_counter()

            try:
                async with httpx.AsyncClient(timeout=timeout) as client:
                    response = await client.post(
                        f"{decision.endpoint}/translate",
                        json={
                            "data": payload,
                            "source_format": "json",
                            "target_format": "emergent"
                        },
                        headers=headers
                    )

                latency_ms = (time.perf_counter() - start_time) * 1000

                if response.status_code == 200:
                    result = response.json()
                    self.record_outcome(decision, True, latency_ms)
                    return True, result, decision
                else:
                    error = f"HTTP {response.status_code}"
                    self.record_outcome(decision, False, latency_ms, error)
                    last_error = error

            except Exception as e:
                latency_ms = (time.perf_counter() - start_time) * 1000
                error = str(e)[:100]
                self.record_outcome(decision, False, latency_ms, error)
                last_error = error

            # Exponential backoff before retry
            if attempt < max_retries - 1:
                await asyncio.sleep(0.1 * (2 ** attempt))

        return False, {"error": last_error}, last_decision

    def get_stats_summary(self) -> Dict[str, Any]:
        """Get summary of routing statistics."""
        return {
            "endpoints": {
                url: {
                    "total_requests": stats.total_requests,
                    "success_rate": round(stats.success_rate * 100, 2),
                    "avg_latency_ms": round(stats.avg_latency_ms, 2),
                    "is_healthy": stats.is_healthy,
                    "consecutive_failures": stats.consecutive_failures
                }
                for url, stats in self.stats.items()
            },
            "learning_enabled": self.enable_learning,
            "strategy": self.strategy.value,
            "total_decisions": len(self._recent_decisions)
        }


# Convenience function for stress tests
async def create_learning_router(
    fly_app: str = "emergent-language",
    regions: List[str] = None
) -> IntelligentRouter:
    """
    Create an intelligent router for Fly.io deployment.

    Args:
        fly_app: Fly.io app name
        regions: Optional list of regions to include

    Returns:
        Configured IntelligentRouter
    """
    # Default to main endpoint
    endpoints = [f"https://{fly_app}.fly.dev"]

    # Could add region-specific endpoints if Fly supports it
    # e.g., https://iad.emergent-language.fly.dev

    return IntelligentRouter(
        endpoints=endpoints,
        strategy=RoutingStrategy.LEARNED,
        enable_learning=True
    )


if __name__ == "__main__":
    # Quick test
    async def test():
        router = IntelligentRouter(
            endpoints=["https://emergent-language.fly.dev"],
            strategy=RoutingStrategy.LEARNED
        )

        # Test routing
        payload = {"task": "analyze", "data": "test"}
        success, result, decision = await router.route_request(payload)

        print(f"Success: {success}")
        print(f"Decision: {decision}")
        print(f"Stats: {router.get_stats_summary()}")

    asyncio.run(test())
