"""
LocalLazyCollector - In-process lazy batching for emergent language encoding.

Buffers dict messages in an asyncio.Queue and flushes them through
BatchEncoder/GPUBatchEncoder when either:
  - batch_size is reached (default 75, GPU-optimal), OR
  - batch_timeout_ms elapses (default 25ms, matching ChunkCollector)

This is the classic producer-batching pattern (Kafka linger.ms + batch.size)
applied to emergent language compression.

Usage:
    from emergent_translator import BatchEncoder, LocalLazyCollector

    encoder = BatchEncoder()
    async with LocalLazyCollector(encoder, batch_size=75) as collector:
        await collector.add({"task": "analyze", "priority": "high"})
        await collector.add({"status": "running", "agent_id": "a1"})
        # batches flush automatically on size/time thresholds
"""

import asyncio
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)

# Sentinel object to signal an immediate flush request
_FLUSH_SENTINEL = object()


@dataclass
class LazyCollectorStats:
    """Cumulative statistics for a LocalLazyCollector instance."""
    messages_collected: int = 0
    batches_flushed: int = 0
    total_compressed_bytes: int = 0
    total_original_bytes: int = 0
    flush_timeouts: int = 0
    flush_thresholds: int = 0
    flush_manual: int = 0
    errors: int = 0
    start_time: float = field(default_factory=time.monotonic)

    @property
    def avg_batch_size(self) -> float:
        if self.batches_flushed == 0:
            return 0.0
        return self.messages_collected / self.batches_flushed

    @property
    def compression_ratio(self) -> float:
        if self.total_original_bytes == 0:
            return 0.0
        return self.total_compressed_bytes / self.total_original_bytes

    @property
    def throughput_msg_per_sec(self) -> float:
        elapsed = time.monotonic() - self.start_time
        if elapsed <= 0:
            return 0.0
        return self.messages_collected / elapsed


@dataclass
class _PendingMessage:
    """Internal wrapper that optionally carries a Future for add_awaitable."""
    message: Dict[str, Any]
    future: Optional[asyncio.Future] = None


class LocalLazyCollector:
    """In-process lazy batcher for BatchEncoder / GPUBatchEncoder.

    Args:
        encoder: A BatchEncoder or GPUBatchEncoder instance.
        batch_size: Flush when this many messages accumulate (default 75).
        batch_timeout_ms: Flush after this many ms even if batch isn't full (default 25).
        max_queue_size: Backpressure limit on the internal queue (default 10_000).
        codebook: Optional AdaptiveCodebook for frequency tracking.
        on_batch_ready: Optional callback invoked with the BatchResult after each flush.
    """

    def __init__(
        self,
        encoder,
        batch_size: int = 75,
        batch_timeout_ms: float = 25.0,
        max_queue_size: int = 10_000,
        codebook=None,
        on_batch_ready: Optional[Callable] = None,
    ):
        self._encoder = encoder
        self._batch_size = batch_size
        self._batch_timeout_ms = batch_timeout_ms
        self._codebook = codebook
        self._on_batch_ready = on_batch_ready

        self._queue: asyncio.Queue = asyncio.Queue(maxsize=max_queue_size)
        self._stats = LazyCollectorStats()
        self._running = False
        self._worker_task: Optional[asyncio.Task] = None
        self._drain_event: Optional[asyncio.Event] = None
        self._loop: Optional[asyncio.AbstractEventLoop] = None

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def start(self):
        """Start the background flush worker."""
        if self._running:
            return
        self._running = True
        self._loop = asyncio.get_running_loop()
        self._drain_event = asyncio.Event()
        self._drain_event.set()  # nothing pending yet
        self._stats = LazyCollectorStats()
        self._worker_task = asyncio.create_task(self._flush_worker())

    async def stop(self):
        """Stop the collector, flushing any remaining messages."""
        if not self._running:
            return
        self._running = False
        # Wake the worker so it can exit
        try:
            self._queue.put_nowait(_FLUSH_SENTINEL)
        except asyncio.QueueFull:
            pass
        if self._worker_task is not None:
            try:
                await asyncio.wait_for(self._worker_task, timeout=5.0)
            except (asyncio.TimeoutError, asyncio.CancelledError):
                self._worker_task.cancel()
                try:
                    await self._worker_task
                except asyncio.CancelledError:
                    pass
        self._worker_task = None

    async def __aenter__(self):
        await self.start()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.stop()
        return False

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def add(self, message: Dict[str, Any]):
        """Add a single message to the buffer (fire-and-forget)."""
        if not self._running:
            raise RuntimeError("Collector is not running — call start() or use 'async with'")
        self._drain_event.clear()
        await self._queue.put(_PendingMessage(message=message))

    async def add_many(self, messages: List[Dict[str, Any]]):
        """Add multiple messages to the buffer."""
        if not self._running:
            raise RuntimeError("Collector is not running — call start() or use 'async with'")
        self._drain_event.clear()
        for msg in messages:
            await self._queue.put(_PendingMessage(message=msg))

    async def add_awaitable(self, message: Dict[str, Any]) -> asyncio.Future:
        """Add a message and return a Future resolved with the BatchResult."""
        if not self._running:
            raise RuntimeError("Collector is not running — call start() or use 'async with'")
        fut = self._loop.create_future()
        self._drain_event.clear()
        await self._queue.put(_PendingMessage(message=message, future=fut))
        return fut

    async def flush(self):
        """Force an immediate flush of the current buffer."""
        if not self._running:
            return
        await self._queue.put(_FLUSH_SENTINEL)

    async def drain(self):
        """Wait until the queue is empty and the current batch is flushed."""
        # Send a flush sentinel to ensure partial batches get flushed
        if self._running:
            await self._queue.put(_FLUSH_SENTINEL)
        await self._drain_event.wait()

    def add_sync(self, message: Dict[str, Any]):
        """Thread-safe synchronous bridge for adding messages."""
        if not self._running or self._loop is None:
            raise RuntimeError("Collector is not running — call start() or use 'async with'")
        asyncio.run_coroutine_threadsafe(self.add(message), self._loop)

    @property
    def stats(self) -> LazyCollectorStats:
        return self._stats

    def get_stats(self) -> Dict[str, Any]:
        s = self._stats
        return {
            "messages_collected": s.messages_collected,
            "batches_flushed": s.batches_flushed,
            "total_compressed_bytes": s.total_compressed_bytes,
            "total_original_bytes": s.total_original_bytes,
            "flush_timeouts": s.flush_timeouts,
            "flush_thresholds": s.flush_thresholds,
            "flush_manual": s.flush_manual,
            "errors": s.errors,
            "avg_batch_size": s.avg_batch_size,
            "compression_ratio": s.compression_ratio,
            "throughput_msg_per_sec": s.throughput_msg_per_sec,
        }

    @property
    def pending_count(self) -> int:
        return self._queue.qsize()

    # ------------------------------------------------------------------
    # Internal flush loop
    # ------------------------------------------------------------------

    async def _flush_worker(self):
        """Background task: accumulate messages and flush on size/time triggers."""
        batch: List[_PendingMessage] = []
        last_flush = time.monotonic()

        while self._running or not self._queue.empty():
            try:
                try:
                    item = await asyncio.wait_for(
                        self._queue.get(),
                        timeout=self._batch_timeout_ms / 1000,
                    )
                    if item is _FLUSH_SENTINEL:
                        if batch:
                            await self._flush_batch(batch, "manual")
                            batch = []
                            last_flush = time.monotonic()
                        # Check drain: queue empty and batch empty
                        if self._queue.empty():
                            self._drain_event.set()
                        continue
                    batch.append(item)
                except asyncio.TimeoutError:
                    pass

                # Decide whether to flush
                elapsed_ms = (time.monotonic() - last_flush) * 1000
                if len(batch) >= self._batch_size:
                    await self._flush_batch(batch, "threshold")
                    batch = []
                    last_flush = time.monotonic()
                elif batch and elapsed_ms >= self._batch_timeout_ms:
                    await self._flush_batch(batch, "timeout")
                    batch = []
                    last_flush = time.monotonic()

                # Update drain event
                if self._queue.empty() and not batch:
                    self._drain_event.set()

            except asyncio.CancelledError:
                if batch:
                    await self._flush_batch(batch, "manual")
                break
            except Exception as e:
                logger.error(f"Flush worker error: {e}")
                self._stats.errors += 1

        # Drain any leftovers after _running goes False
        while not self._queue.empty():
            try:
                item = self._queue.get_nowait()
                if item is not _FLUSH_SENTINEL:
                    batch.append(item)
            except asyncio.QueueEmpty:
                break
        if batch:
            await self._flush_batch(batch, "manual")
        self._drain_event.set()

    async def _flush_batch(self, batch: List[_PendingMessage], trigger: str):
        """Encode a batch of messages via the encoder."""
        if not batch:
            return

        messages = [p.message for p in batch]
        futures = [p.future for p in batch if p.future is not None]

        try:
            # Observe through codebook if provided and encoder doesn't already have one
            if self._codebook is not None and getattr(self._encoder, '_codebook', None) is None:
                self._codebook.observe(messages)

            # Run the synchronous encoder in an executor to avoid blocking the loop
            loop = asyncio.get_running_loop()
            result = await loop.run_in_executor(
                None, self._encoder.encode_batch, messages
            )

            # Update stats
            self._stats.messages_collected += len(messages)
            self._stats.batches_flushed += 1
            self._stats.total_compressed_bytes += result.compressed_bytes
            self._stats.total_original_bytes += result.original_bytes
            if trigger == "timeout":
                self._stats.flush_timeouts += 1
            elif trigger == "threshold":
                self._stats.flush_thresholds += 1
            else:
                self._stats.flush_manual += 1

            # Resolve futures
            for fut in futures:
                if not fut.done():
                    fut.set_result(result)

            # Fire callback
            if self._on_batch_ready is not None:
                try:
                    cb_result = self._on_batch_ready(result)
                    if asyncio.iscoroutine(cb_result):
                        await cb_result
                except Exception as cb_err:
                    logger.error(f"on_batch_ready callback error: {cb_err}")

        except Exception as e:
            logger.error(f"Flush batch error: {e}")
            self._stats.errors += 1
            for fut in futures:
                if not fut.done():
                    fut.set_exception(e)
