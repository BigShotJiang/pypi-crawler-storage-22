"""
LocalPipeline - Single entry point for emergent language encoding.

Wires together GPUBatchEncoder, LocalLazyCollector, optional AdaptiveCodebook,
and optional ChunkCollector into one ``async with`` block.

Usage (async):
    from emergent_translator import LocalPipeline

    async with LocalPipeline(use_gpu=False) as p:
        await p.add({"role": "user", "content": "hello"})
        await p.drain()
        print(p.get_stats())

Usage (sync):
    from emergent_translator import LocalPipelineSync

    with LocalPipelineSync(use_gpu=False) as p:
        r = p.encode([{"role": "user", "content": "hello"}])
        print(r.messages_encoded)
"""

import asyncio
import logging
import threading
from typing import Any, Callable, Dict, Iterator, List, Optional

from .adaptive_codebook import AdaptiveCodebook, CodebookVersion
from .gpu_batch_encoder import GPUBatchEncoder, GPUBatchResult
from .lazy_collector import LocalLazyCollector

logger = logging.getLogger(__name__)


class LocalPipeline:
    """Async pipeline combining GPU encoding, lazy batching, and optional distributed processing.

    Args:
        num_workers: ThreadPoolExecutor size for the encoder.
        use_gpu: Try GPU acceleration (falls back to CPU automatically).
        compression_level: zlib compression level (0-9).
        min_embed_messages: Skip codebook embedding below this batch size.
        batch_size: Flush threshold for the lazy collector.
        batch_timeout_ms: Max wait before flushing a partial batch.
        max_queue_size: Backpressure limit on the collector queue.
        on_batch_ready: Optional callback invoked with each BatchResult.
        adaptive: Create an AdaptiveCodebook automatically.
        codebook: Explicit AdaptiveCodebook instance (overrides *adaptive*).
        codebook_rebuild_interval: Auto-rebuild codebook every N messages.
        codebook_path: File path for codebook persistence (load on start, save on stop).
        workers: Worker URLs for distributed ChunkCollector (opt-in).
        chunk_size_mb: Chunk size for distributed processing.
        auth_token: Auth token for ChunkCollector workers.
    """

    def __init__(
        self,
        *,
        # Encoder
        num_workers: int = 8,
        use_gpu: bool = True,
        compression_level: int = 6,
        min_embed_messages: int = 10,
        # Collector
        batch_size: int = 75,
        batch_timeout_ms: float = 25.0,
        max_queue_size: int = 10_000,
        on_batch_ready: Optional[Callable] = None,
        # Adaptive codebook (opt-in)
        adaptive: bool = False,
        codebook: Optional[AdaptiveCodebook] = None,
        codebook_rebuild_interval: int = 1000,
        codebook_path: Optional[str] = None,
        # ChunkCollector (opt-in)
        workers: Optional[List[str]] = None,
        chunk_size_mb: float = 1.0,
        auth_token: Optional[str] = None,
    ):
        # Codebook
        self._codebook_path = codebook_path
        if codebook is not None:
            self._codebook = codebook
            if codebook_path and not getattr(codebook, '_persist_path', None):
                self._codebook._persist_path = codebook_path
        elif adaptive:
            self._codebook = AdaptiveCodebook(persist_path=codebook_path)
        else:
            self._codebook = None

        self._codebook_rebuild_interval = codebook_rebuild_interval
        self._messages_since_rebuild = 0
        self._user_on_batch_ready = on_batch_ready

        # Encoder — codebook lives here so encoder auto-observes
        self._encoder = GPUBatchEncoder(
            num_workers=num_workers,
            use_gpu=use_gpu,
            compression_level=compression_level,
            codebook=self._codebook,
            min_embed_messages=min_embed_messages,
        )

        # Collector — codebook NOT passed (encoder already tracks)
        self._collector = LocalLazyCollector(
            encoder=self._encoder,
            batch_size=batch_size,
            batch_timeout_ms=batch_timeout_ms,
            max_queue_size=max_queue_size,
            on_batch_ready=self._on_batch_wrapper,
        )

        # ChunkCollector (opt-in)
        self._chunk_collector = None
        self._workers = workers
        self._chunk_size_mb = chunk_size_mb
        self._auth_token = auth_token

        self._running = False

    # ------------------------------------------------------------------
    # Batch callback wrapper (codebook auto-rebuild)
    # ------------------------------------------------------------------

    def _on_batch_wrapper(self, result):
        """Internal callback: auto-rebuild codebook, then forward to user."""
        if self._codebook is not None:
            self._messages_since_rebuild += result.messages_encoded
            if self._messages_since_rebuild >= self._codebook_rebuild_interval:
                self._codebook.rebuild(min_frequency=10)
                self._messages_since_rebuild = 0

        if self._user_on_batch_ready is not None:
            return self._user_on_batch_ready(result)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def start(self):
        """Start the collector (and optional chunk collector)."""
        if self._running:
            return
        self._running = True

        # Load persisted codebook if available
        if self._codebook is not None and self._codebook_path:
            import os
            if os.path.exists(self._codebook_path):
                try:
                    self._codebook.load()
                    logger.info("Loaded codebook from %s", self._codebook_path)
                except Exception:
                    logger.warning("Failed to load codebook from %s", self._codebook_path, exc_info=True)

        await self._collector.start()

        if self._workers:
            from .chunk_collector import ChunkCollector
            self._chunk_collector = ChunkCollector(
                workers=self._workers,
                chunk_size_mb=self._chunk_size_mb,
                auth_token=self._auth_token,
            )
            await self._chunk_collector.start()

    async def stop(self):
        """Stop everything, flushing remaining messages."""
        if not self._running:
            return
        self._running = False

        await self._collector.stop()
        self._encoder.close()

        if self._chunk_collector is not None:
            await self._chunk_collector.stop()

        # Persist codebook on shutdown
        if self._codebook is not None and self._codebook_path:
            try:
                self._codebook.save()
                logger.info("Saved codebook to %s", self._codebook_path)
            except Exception:
                logger.warning("Failed to save codebook to %s", self._codebook_path, exc_info=True)

    async def __aenter__(self):
        await self.start()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.stop()
        return False

    # ------------------------------------------------------------------
    # Message ingestion (delegate to collector)
    # ------------------------------------------------------------------

    async def add(self, message: Dict[str, Any]):
        """Add a single message to the buffer (fire-and-forget)."""
        await self._collector.add(message)

    async def add_many(self, messages: List[Dict[str, Any]]):
        """Add multiple messages to the buffer."""
        await self._collector.add_many(messages)

    async def add_awaitable(self, message: Dict[str, Any]) -> asyncio.Future:
        """Add a message and return a Future resolved with the BatchResult."""
        return await self._collector.add_awaitable(message)

    def add_sync(self, message: Dict[str, Any]):
        """Thread-safe synchronous bridge for adding messages."""
        self._collector.add_sync(message)

    async def flush(self):
        """Force an immediate flush of the current buffer."""
        await self._collector.flush()

    async def drain(self):
        """Wait until the queue is empty and the current batch is flushed."""
        await self._collector.drain()

    # ------------------------------------------------------------------
    # Direct encoding (bypass collector)
    # ------------------------------------------------------------------

    def encode(self, messages: List[Dict]) -> GPUBatchResult:
        """Encode messages directly (synchronous, bypasses collector)."""
        return self._encoder.encode_batch(messages)

    def decode(self, payload: bytes) -> List[Dict]:
        """Decode a batch payload back into message dicts."""
        return self._encoder.decode_batch(payload)

    def encode_stream(
        self,
        iterator: Iterator[Dict],
        batch_size: int = 75,
        callback: Optional[Callable] = None,
    ):
        """Encode a stream of messages in batches. Yields GPUBatchResult per batch."""
        return self._encoder.encode_stream(iterator, batch_size=batch_size, callback=callback)

    # ------------------------------------------------------------------
    # Distributed file processing (delegate to ChunkCollector)
    # ------------------------------------------------------------------

    async def submit_file(
        self,
        data: bytes,
        operation: str,
        params: Optional[Dict] = None,
        metadata: Optional[Dict] = None,
    ) -> str:
        """Submit a file for distributed processing. Returns job_id."""
        if self._chunk_collector is None:
            raise RuntimeError(
                "No ChunkCollector configured — pass workers=[...] to enable distributed processing"
            )
        return await self._chunk_collector.submit_file(
            data, operation, operation_params=params, metadata=metadata
        )

    async def get_result(self, job_id: str, timeout: float = 300.0) -> Optional[bytes]:
        """Wait for and return a distributed job result."""
        if self._chunk_collector is None:
            raise RuntimeError("No ChunkCollector configured")
        return await self._chunk_collector.get_result(job_id, timeout=timeout)

    def get_job_status(self, job_id: str) -> Dict[str, Any]:
        """Get status of a distributed job."""
        if self._chunk_collector is None:
            raise RuntimeError("No ChunkCollector configured")
        return self._chunk_collector.get_job_status(job_id)

    # ------------------------------------------------------------------
    # Properties / stats
    # ------------------------------------------------------------------

    @property
    def has_chunk_collector(self) -> bool:
        return self._chunk_collector is not None

    @property
    def codebook(self) -> Optional[AdaptiveCodebook]:
        return self._codebook

    def rebuild_codebook(self, min_frequency: int = 10) -> Optional[CodebookVersion]:
        """Manually rebuild the adaptive codebook. Returns new version or None."""
        if self._codebook is None:
            return None
        return self._codebook.rebuild(min_frequency=min_frequency)

    @property
    def pending_count(self) -> int:
        return self._collector.pending_count

    def get_stats(self) -> Dict[str, Any]:
        """Return nested stats dict."""
        stats: Dict[str, Any] = {
            "encoder": self._encoder.get_stats(),
            "collector": self._collector.get_stats(),
            "running": self._running,
        }
        if self._codebook is not None:
            stats["codebook"] = self._codebook.get_stats()
        if self._chunk_collector is not None:
            stats["chunk_collector"] = self._chunk_collector.get_stats()
        return stats


class LocalPipelineSync:
    """Synchronous wrapper around LocalPipeline.

    Uses a dedicated background thread with its own event loop so the
    LocalLazyCollector flush worker can run persistently.

    Usage:
        with LocalPipelineSync(use_gpu=False) as p:
            r = p.encode([{"role": "user", "content": "hello"}])
            decoded = p.decode(r.payload)
    """

    def __init__(self, **kwargs):
        self._kwargs = kwargs
        self._pipeline: Optional[LocalPipeline] = None
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._thread: Optional[threading.Thread] = None

    def _run(self, coro):
        """Submit a coroutine to the background loop and wait for the result."""
        if self._loop is None or self._loop.is_closed():
            raise RuntimeError("Pipeline is not running")
        future = asyncio.run_coroutine_threadsafe(coro, self._loop)
        return future.result()

    def _thread_main(self, started: threading.Event):
        """Background thread: run the event loop."""
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        started.set()
        self._loop.run_forever()

    def __enter__(self):
        started = threading.Event()
        self._thread = threading.Thread(target=self._thread_main, args=(started,), daemon=True)
        self._thread.start()
        started.wait()

        self._pipeline = LocalPipeline(**self._kwargs)
        self._run(self._pipeline.start())
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self._pipeline is not None:
            try:
                self._run(self._pipeline.stop())
            except Exception:
                pass
        if self._loop is not None:
            self._loop.call_soon_threadsafe(self._loop.stop)
        if self._thread is not None:
            self._thread.join(timeout=5.0)
        if self._loop is not None and not self._loop.is_closed():
            self._loop.close()
        self._pipeline = None
        self._loop = None
        self._thread = None
        return False

    # -- Async methods wrapped via _run --

    def add(self, message: Dict[str, Any]):
        self._run(self._pipeline.add(message))

    def add_many(self, messages: List[Dict[str, Any]]):
        self._run(self._pipeline.add_many(messages))

    def flush(self):
        self._run(self._pipeline.flush())

    def drain(self):
        self._run(self._pipeline.drain())

    def submit_file(self, data: bytes, operation: str, params=None, metadata=None) -> str:
        return self._run(self._pipeline.submit_file(data, operation, params, metadata))

    def get_result(self, job_id: str, timeout: float = 300.0) -> Optional[bytes]:
        return self._run(self._pipeline.get_result(job_id, timeout=timeout))

    # -- Already-sync methods delegated directly --

    def encode(self, messages: List[Dict]) -> GPUBatchResult:
        return self._pipeline.encode(messages)

    def decode(self, payload: bytes) -> List[Dict]:
        return self._pipeline.decode(payload)

    def encode_stream(self, iterator, batch_size: int = 75, callback=None):
        return self._pipeline.encode_stream(iterator, batch_size=batch_size, callback=callback)

    def get_job_status(self, job_id: str) -> Dict[str, Any]:
        return self._pipeline.get_job_status(job_id)

    @property
    def has_chunk_collector(self) -> bool:
        return self._pipeline.has_chunk_collector

    @property
    def codebook(self) -> Optional[AdaptiveCodebook]:
        return self._pipeline.codebook

    def rebuild_codebook(self, min_frequency: int = 10) -> Optional[CodebookVersion]:
        return self._pipeline.rebuild_codebook(min_frequency=min_frequency)

    @property
    def pending_count(self) -> int:
        return self._pipeline.pending_count

    def get_stats(self) -> Dict[str, Any]:
        return self._pipeline.get_stats()
