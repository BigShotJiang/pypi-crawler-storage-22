"""NATS-compatible codec for theta-encoded messages.

Works with any messaging system that passes opaque bytes (NATS, Redis,
MQTT, ZeroMQ). No nats-py dependency -- just encode/decode bytes.

Usage:
    from emergent_translator import EmergentCodec

    codec = EmergentCodec()
    data = codec.encode({"temperature": 22.5, "humidity": 61})
    msg = codec.decode(data)

    # Batch mode
    payload = codec.encode_batch([msg1, msg2, msg3])
    messages = codec.decode_batch(payload)

    # Adaptive mode (learns frequent keys/values for better compression)
    codec = EmergentCodec(adaptive=True)
"""

import json

from .batch_encoder import BatchEncoder


class EmergentCodec:
    """Stateless theta codec for messaging systems.

    Wraps ``BatchEncoder.encode_batch`` / ``decode_batch`` so every payload is
    self-describing (magic bytes, version, CRC, optional zlib, optional
    embedded codebook).  Single-message encode uses a batch-of-1 — 12 bytes
    of framing overhead in exchange for CRC integrity and zlib compression.

    Args:
        adaptive: When True, creates an ``AdaptiveCodebook`` that learns
            frequently-seen keys/values and improves compression over time.
            The codebook is embedded in each payload so the decoder side
            is stateless.
    """

    def __init__(self, adaptive: bool = False):
        self._adaptive = adaptive
        self._codebook = None
        if adaptive:
            from .adaptive_codebook import AdaptiveCodebook
            self._codebook = AdaptiveCodebook()
        self._encoder = BatchEncoder(codebook=self._codebook)
        self._msgs_encoded = 0
        self._msgs_decoded = 0
        self._bytes_in = 0
        self._bytes_out = 0

    def encode(self, msg: dict) -> bytes:
        """Encode a single dict to self-describing theta bytes."""
        json_size = len(json.dumps(msg, separators=(",", ":")).encode())
        result = self._encoder.encode_batch([msg])
        self._msgs_encoded += 1
        self._bytes_in += json_size
        self._bytes_out += len(result.payload)
        return result.payload

    def decode(self, data: bytes) -> dict:
        """Decode theta bytes back to a dict.

        Raises ``ValueError`` if the payload does not contain exactly 1 message.
        """
        messages = self._encoder.decode_batch(data)
        if len(messages) != 1:
            raise ValueError(
                f"Expected 1 message, got {len(messages)}. Use decode_batch() for multi-message payloads."
            )
        self._msgs_decoded += 1
        return messages[0]

    def encode_batch(self, msgs: list) -> bytes:
        """Encode multiple dicts into a single theta payload."""
        json_size = sum(
            len(json.dumps(m, separators=(",", ":")).encode()) for m in msgs
        )
        result = self._encoder.encode_batch(msgs)
        self._msgs_encoded += len(msgs)
        self._bytes_in += json_size
        self._bytes_out += len(result.payload)
        return result.payload

    def decode_batch(self, data: bytes) -> list:
        """Decode a theta batch payload to list of dicts."""
        messages = self._encoder.decode_batch(data)
        self._msgs_decoded += len(messages)
        return messages

    @property
    def stats(self) -> dict:
        """Codec statistics."""
        ratio = self._bytes_out / self._bytes_in if self._bytes_in > 0 else 0.0
        info = {
            "messages_encoded": self._msgs_encoded,
            "messages_decoded": self._msgs_decoded,
            "bytes_in": self._bytes_in,
            "bytes_out": self._bytes_out,
            "compression_ratio": round(ratio, 4),
        }
        if self._adaptive and self._codebook is not None:
            cb_stats = self._codebook.get_stats()
            info["codebook_version"] = cb_stats["active_version"]
            info["keys_tracked"] = cb_stats["tracked_keys"]
            info["values_tracked"] = cb_stats["tracked_values"]
        return info
