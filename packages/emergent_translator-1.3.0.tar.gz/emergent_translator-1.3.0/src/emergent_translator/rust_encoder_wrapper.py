"""
Rust Encoder Wrapper

Provides a unified interface that uses the high-performance Rust encoder
when available, falling back to the Python implementation.

Usage:
    from emergent_translator.rust_encoder_wrapper import encode_batch, RUST_AVAILABLE

    result = encode_batch(messages)  # Automatically uses fastest encoder
"""

from dataclasses import dataclass
from typing import List, Dict, Any, Optional

# Try to import Rust encoder
RUST_AVAILABLE = False
_rust_encoder = None

try:
    import emergent_encoder as _rust_encoder
    RUST_AVAILABLE = True
    print("✓ Rust encoder available (6x faster)")
except ImportError:
    print("⚠ Rust encoder not available, using Python fallback")


@dataclass
class BatchResult:
    """Unified result format for both encoders."""
    messages_encoded: int
    original_bytes: int
    compressed_bytes: int
    compression_ratio: float
    bandwidth_saved_pct: float
    payload: bytes
    encode_time_ms: float
    compress_time_ms: float = 0.0
    total_time_ms: float = 0.0
    gpu_accelerated: bool = False
    rust_accelerated: bool = False

    # Additional fields for compatibility
    transfer_time_ms: float = 0.0
    individual_bytes: int = 0
    batch_advantage_pct: float = 0.0
    throughput_msg_per_sec: float = 0.0


def encode_batch(messages: List[Dict[str, Any]], use_rust: bool = True) -> BatchResult:
    """
    Encode a batch of messages using the fastest available encoder.

    Args:
        messages: List of message dictionaries to encode
        use_rust: Whether to use Rust encoder if available (default True)

    Returns:
        BatchResult with encoded payload and metrics
    """
    if use_rust and RUST_AVAILABLE and _rust_encoder is not None:
        return _encode_with_rust(messages)
    else:
        return _encode_with_python(messages)


def _encode_with_rust(messages: List[Dict[str, Any]]) -> BatchResult:
    """Encode using the Rust encoder."""
    result = _rust_encoder.encode_batch(messages)

    throughput = (result.messages_encoded / result.total_time_ms) * 1000 if result.total_time_ms > 0 else 0

    return BatchResult(
        messages_encoded=result.messages_encoded,
        original_bytes=result.original_bytes,
        compressed_bytes=result.compressed_bytes,
        compression_ratio=result.compression_ratio,
        bandwidth_saved_pct=result.bandwidth_saved_pct,
        payload=bytes(result.payload),
        encode_time_ms=result.encode_time_ms,
        compress_time_ms=result.compress_time_ms,
        total_time_ms=result.total_time_ms,
        gpu_accelerated=False,
        rust_accelerated=True,
        throughput_msg_per_sec=throughput,
    )


def _encode_with_python(messages: List[Dict[str, Any]]) -> BatchResult:
    """Encode using the Python encoder (fallback)."""
    from .gpu_batch_encoder import GPUBatchEncoder

    encoder = GPUBatchEncoder()
    result = encoder.encode_batch(messages)

    return BatchResult(
        messages_encoded=result.messages_encoded,
        original_bytes=result.original_bytes,
        compressed_bytes=result.compressed_bytes,
        compression_ratio=result.compression_ratio,
        bandwidth_saved_pct=result.bandwidth_saved_pct,
        payload=result.payload,
        encode_time_ms=result.encode_time_ms,
        compress_time_ms=result.compress_time_ms,
        total_time_ms=result.encode_time_ms,
        gpu_accelerated=result.gpu_accelerated,
        rust_accelerated=False,
        transfer_time_ms=result.transfer_time_ms,
        individual_bytes=result.individual_bytes,
        batch_advantage_pct=result.batch_advantage_pct,
        throughput_msg_per_sec=result.throughput_msg_per_sec,
    )


def get_encoder_info() -> Dict[str, Any]:
    """Get information about the active encoder."""
    return {
        "rust_available": RUST_AVAILABLE,
        "active_encoder": "rust" if RUST_AVAILABLE else "python",
        "expected_speedup": "6x" if RUST_AVAILABLE else "1x (baseline)",
    }
