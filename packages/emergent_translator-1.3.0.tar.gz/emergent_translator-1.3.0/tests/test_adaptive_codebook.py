#!/usr/bin/env python3
"""Tests for the adaptive learned codebook system."""

import json
import os
import tempfile
import threading

import pytest

from emergent_translator.adaptive_codebook import (
    AdaptiveCodebook,
    CodebookVersion,
    FrequencyTracker,
    make_baseline_codebook,
)
from emergent_translator.batch_encoder import (
    BatchEncoder,
    SAMPLE_MESSAGES,
    encode_dict,
    encode_value,
    decode_dict,
    decode_value,
)
from emergent_translator.gpu_batch_encoder import (
    GPUBatchEncoder,
    SAMPLE_MESSAGES as GPU_SAMPLE_MESSAGES,
    encode_dict_cpu,
    encode_value_cpu,
    decode_dict_cpu,
    decode_value_cpu,
)


# ─────────────────────────────────────────────────────────────────────────────
# FrequencyTracker tests
# ─────────────────────────────────────────────────────────────────────────────

class TestFrequencyTracker:
    def test_observe_counts_keys(self):
        ft = FrequencyTracker()
        ft.observe({"task": "analyze", "priority": "high"})
        ft.observe({"task": "optimize", "status": "pending"})
        top = dict(ft.get_top_keys(10))
        assert top["task"] == 2
        assert top["priority"] == 1
        assert top["status"] == 1

    def test_observe_counts_values(self):
        ft = FrequencyTracker()
        ft.observe({"task": "analyze"})
        ft.observe({"task": "analyze"})
        ft.observe({"task": "optimize"})
        top = dict(ft.get_top_values(10))
        assert top["analyze"] == 2
        assert top["optimize"] == 1

    def test_observe_batch(self):
        ft = FrequencyTracker()
        msgs = [{"a": "x"}, {"a": "x"}, {"b": "y"}]
        ft.observe_batch(msgs)
        assert ft.total_messages == 3
        top_k = dict(ft.get_top_keys(10))
        assert top_k["a"] == 2
        assert top_k["b"] == 1

    def test_get_top_keys_ranking(self):
        ft = FrequencyTracker()
        for _ in range(10):
            ft.observe({"hot": "val"})
        for _ in range(3):
            ft.observe({"cold": "val"})
        top = ft.get_top_keys(1)
        assert top[0][0] == "hot"
        assert top[0][1] == 10

    def test_get_top_values_ranking(self):
        ft = FrequencyTracker()
        for _ in range(10):
            ft.observe({"k": "popular"})
        for _ in range(3):
            ft.observe({"k": "rare"})
        top = ft.get_top_values(1)
        assert top[0][0] == "popular"
        assert top[0][1] == 10

    def test_reset(self):
        ft = FrequencyTracker()
        ft.observe({"a": "b"})
        assert ft.total_messages == 1
        ft.reset()
        assert ft.total_messages == 0
        assert ft.get_top_keys(10) == []
        assert ft.get_top_values(10) == []

    def test_thread_safety(self):
        ft = FrequencyTracker()
        errors = []

        def worker():
            try:
                for _ in range(1000):
                    ft.observe({"task": "analyze", "priority": "high"})
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=worker) for _ in range(8)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert not errors
        assert ft.total_messages == 8000
        top_k = dict(ft.get_top_keys(10))
        assert top_k["task"] == 8000
        assert top_k["priority"] == 8000

    def test_nested_messages(self):
        ft = FrequencyTracker()
        ft.observe({"outer": {"inner": "deep"}})
        top_k = dict(ft.get_top_keys(10))
        assert "outer" in top_k
        assert "inner" in top_k
        top_v = dict(ft.get_top_values(10))
        assert "deep" in top_v

    def test_lowercase_normalization(self):
        ft = FrequencyTracker()
        ft.observe({"Task": "Analyze"})
        ft.observe({"TASK": "ANALYZE"})
        top_k = dict(ft.get_top_keys(10))
        assert top_k["task"] == 2
        top_v = dict(ft.get_top_values(10))
        assert top_v["analyze"] == 2

    def test_long_values_ignored(self):
        ft = FrequencyTracker()
        ft.observe({"k": "x" * 100})
        top_v = dict(ft.get_top_values(10))
        assert len(top_v) == 0

    def test_list_values_extracted(self):
        ft = FrequencyTracker()
        ft.observe({"items": ["a", "b", "c"]})
        top_v = dict(ft.get_top_values(10))
        assert "a" in top_v
        assert "b" in top_v
        assert "c" in top_v


# ─────────────────────────────────────────────────────────────────────────────
# CodebookVersion tests
# ─────────────────────────────────────────────────────────────────────────────

class TestCodebookVersion:
    def test_serialize_deserialize_round_trip(self):
        keys = {"task": 1, "status": 2, "priority": 3}
        values = {"high": 1, "low": 2, "analyze": 3}
        cb = CodebookVersion(
            version=1,
            keys=keys,
            values=values,
            keys_rev={v: k for k, v in keys.items()},
            values_rev={v: k for k, v in values.items()},
            trained_on=100,
            created_at=1234567890.0,
        )
        data = cb.serialize()
        restored, consumed = CodebookVersion.deserialize(data)
        assert restored.keys == keys
        assert restored.values == values
        assert restored.keys_rev == cb.keys_rev
        assert restored.values_rev == cb.values_rev
        assert consumed == len(data)

    def test_empty_codebook_serialize(self):
        cb = CodebookVersion(
            version=0,
            keys={},
            values={},
            keys_rev={},
            values_rev={},
        )
        data = cb.serialize()
        assert data == bytes([0, 0])
        restored, consumed = CodebookVersion.deserialize(data)
        assert restored.keys == {}
        assert restored.values == {}
        assert consumed == 2

    def test_to_dict_from_dict_round_trip(self):
        keys = {"task": 1, "status": 2}
        values = {"high": 1}
        cb = CodebookVersion(
            version=5,
            keys=keys,
            values=values,
            keys_rev={1: "task", 2: "status"},
            values_rev={1: "high"},
            trained_on=500,
            created_at=1234567890.0,
        )
        d = cb.to_dict()
        restored = CodebookVersion.from_dict(d)
        assert restored.version == 5
        assert restored.keys == keys
        assert restored.values == values
        assert restored.keys_rev == cb.keys_rev
        assert restored.values_rev == cb.values_rev
        assert restored.trained_on == 500

    def test_serialize_with_offset(self):
        keys = {"a": 1}
        values = {"b": 2}
        cb = CodebookVersion(
            version=1,
            keys=keys,
            values=values,
            keys_rev={1: "a"},
            values_rev={2: "b"},
        )
        data = cb.serialize()
        padded = b'\xff\xff\xff' + data
        restored, consumed = CodebookVersion.deserialize(padded, offset=3)
        assert restored.keys == keys
        assert restored.values == values
        assert consumed == len(data)


# ─────────────────────────────────────────────────────────────────────────────
# AdaptiveCodebook tests
# ─────────────────────────────────────────────────────────────────────────────

class TestAdaptiveCodebook:
    def test_baseline_is_version_zero(self):
        ac = AdaptiveCodebook()
        assert ac.get_active().version == 0
        assert ac.get_version(0) is not None

    def test_rebuild_creates_version_1(self):
        ac = AdaptiveCodebook()
        for _ in range(20):
            ac.observe(SAMPLE_MESSAGES)
        cb = ac.rebuild(min_frequency=5)
        assert cb.version == 1
        assert ac.get_active().version == 1
        assert len(cb.keys) > 0
        assert len(cb.values) > 0

    def test_version_management(self):
        ac = AdaptiveCodebook()
        for _ in range(20):
            ac.observe(SAMPLE_MESSAGES)
        cb1 = ac.rebuild(min_frequency=5)
        cb2 = ac.rebuild(min_frequency=5)
        assert cb1.version == 1
        assert cb2.version == 2
        assert ac.get_version(0) is not None
        assert ac.get_version(1) is not None
        assert ac.get_version(2) is not None
        assert ac.get_active().version == 2

    def test_min_frequency_filter(self):
        ac = AdaptiveCodebook()
        for _ in range(20):
            ac.observe([{"common": "frequent"}])
        ac.observe([{"rare": "infrequent"}])
        cb = ac.rebuild(min_frequency=10)
        assert "common" in cb.keys
        assert "rare" not in cb.keys
        assert "frequent" in cb.values
        assert "infrequent" not in cb.values

    def test_persistence_save_load(self):
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
            path = f.name
        try:
            ac = AdaptiveCodebook(persist_path=path)
            for _ in range(20):
                ac.observe(SAMPLE_MESSAGES)
            cb = ac.rebuild(min_frequency=5)
            ac.save()

            ac2 = AdaptiveCodebook(persist_path=path)
            ac2.load()
            assert ac2.get_active().version == cb.version
            assert ac2.get_active().keys == cb.keys
            assert ac2.get_active().values == cb.values
        finally:
            os.unlink(path)

    def test_stats(self):
        ac = AdaptiveCodebook()
        ac.observe(SAMPLE_MESSAGES)
        stats = ac.get_stats()
        assert stats["active_version"] == 0
        assert stats["total_versions"] == 1
        assert stats["tracked_messages"] == len(SAMPLE_MESSAGES)
        assert stats["tracked_keys"] > 0
        assert stats["tracked_values"] > 0

    def test_max_keys_values_limit(self):
        ac = AdaptiveCodebook()
        for i in range(200):
            ac.observe([{f"key_{i}": f"val_{i}"}])
        cb = ac.rebuild(min_frequency=1, max_keys=5, max_values=5)
        assert len(cb.keys) == 5
        assert len(cb.values) == 5


# ─────────────────────────────────────────────────────────────────────────────
# Encoder with codebook tests
# ─────────────────────────────────────────────────────────────────────────────

class TestEncoderWithCodebook:
    def _make_codebook(self):
        keys = {"task": 1, "status": 2, "priority": 3}
        values = {"analyze": 1, "high": 2, "pending": 3}
        return CodebookVersion(
            version=1,
            keys=keys,
            values=values,
            keys_rev={1: "task", 2: "status", 3: "priority"},
            values_rev={1: "analyze", 2: "high", 3: "pending"},
        )

    def test_encode_decode_cpu_with_codebook(self):
        cb = self._make_codebook()
        msg = {"task": "analyze", "priority": "high"}
        encoded = encode_dict_cpu(msg, codebook=cb)
        decoded, _ = decode_dict_cpu(encoded, codebook=cb)
        assert decoded == msg

    def test_encode_decode_batch_with_codebook(self):
        cb = self._make_codebook()
        msg = {"task": "analyze", "priority": "high"}
        encoded = encode_dict(msg, codebook=cb)
        decoded, _ = decode_dict(encoded, codebook=cb)
        assert decoded == msg

    def test_backward_compat_no_codebook(self):
        msg = {"task": "analyze", "priority": "high"}
        encoded_default = encode_dict_cpu(msg)
        encoded_none = encode_dict_cpu(msg, codebook=None)
        assert encoded_default == encoded_none
        decoded, _ = decode_dict_cpu(encoded_default)
        assert decoded == msg

    def test_value_encode_decode_with_codebook(self):
        cb = self._make_codebook()
        for val in ["analyze", "high", "pending"]:
            encoded = encode_value_cpu(val, codebook=cb)
            decoded, _ = decode_value_cpu(encoded, codebook=cb)
            assert decoded == val

    def test_nested_dict_with_codebook(self):
        cb = self._make_codebook()
        msg = {"task": {"status": "pending"}}
        encoded = encode_dict_cpu(msg, codebook=cb)
        decoded, _ = decode_dict_cpu(encoded, codebook=cb)
        assert decoded == msg

    def test_list_values_with_codebook(self):
        cb = self._make_codebook()
        msg = {"task": ["analyze", "high"]}
        encoded = encode_dict_cpu(msg, codebook=cb)
        decoded, _ = decode_dict_cpu(encoded, codebook=cb)
        assert decoded == msg

    def test_custom_key_with_codebook(self):
        cb = self._make_codebook()
        msg = {"task": "analyze", "custom_field": "hello"}
        encoded = encode_dict_cpu(msg, codebook=cb)
        decoded, _ = decode_dict_cpu(encoded, codebook=cb)
        assert decoded == msg


# ─────────────────────────────────────────────────────────────────────────────
# Batch round-trip with adaptive codebook
# ─────────────────────────────────────────────────────────────────────────────

class TestBatchRoundTripWithAdaptiveCodebook:
    def test_gpu_batch_v3_round_trip(self):
        ac = AdaptiveCodebook()
        for _ in range(50):
            ac.observe(GPU_SAMPLE_MESSAGES)
        ac.rebuild(min_frequency=5)

        enc = GPUBatchEncoder(num_workers=2, codebook=ac)
        result = enc.encode_batch(GPU_SAMPLE_MESSAGES)

        header = enc.decode_batch_header(result.payload)
        assert header["version"] == 0x03
        assert header["codebook_embedded"]

        decoded = enc.decode_batch(result.payload)
        assert len(decoded) == len(GPU_SAMPLE_MESSAGES)

    def test_batch_encoder_v3_round_trip(self):
        ac = AdaptiveCodebook()
        for _ in range(50):
            ac.observe(SAMPLE_MESSAGES)
        ac.rebuild(min_frequency=5)

        enc = BatchEncoder(codebook=ac)
        result = enc.encode_batch(SAMPLE_MESSAGES)

        header = enc.decode_batch_header(result.payload)
        assert header["version"] == 0x03
        assert header["codebook_embedded"]

        decoded = enc.decode_batch(result.payload)
        assert len(decoded) == len(SAMPLE_MESSAGES)

    def test_old_v1_v2_still_decodable(self):
        be = BatchEncoder()
        result_v1 = be.encode_batch(SAMPLE_MESSAGES)
        decoded_v1 = be.decode_batch(result_v1.payload)
        assert len(decoded_v1) == len(SAMPLE_MESSAGES)

        ge = GPUBatchEncoder(num_workers=2)
        result_v2 = ge.encode_batch(GPU_SAMPLE_MESSAGES)
        decoded_v2 = ge.decode_batch(result_v2.payload)
        assert len(decoded_v2) == len(GPU_SAMPLE_MESSAGES)

    def test_standalone_v3_decode(self):
        ac = AdaptiveCodebook()
        for _ in range(50):
            ac.observe(GPU_SAMPLE_MESSAGES)
        ac.rebuild(min_frequency=5)

        enc = GPUBatchEncoder(num_workers=2, codebook=ac)
        result = enc.encode_batch(GPU_SAMPLE_MESSAGES)

        fresh_enc = GPUBatchEncoder(num_workers=2)
        decoded = fresh_enc.decode_batch(result.payload)
        assert len(decoded) == len(GPU_SAMPLE_MESSAGES)

    def test_standalone_v3_decode_batch_encoder(self):
        ac = AdaptiveCodebook()
        for _ in range(50):
            ac.observe(SAMPLE_MESSAGES)
        ac.rebuild(min_frequency=5)

        enc = BatchEncoder(codebook=ac)
        result = enc.encode_batch(SAMPLE_MESSAGES)

        fresh = BatchEncoder()
        decoded = fresh.decode_batch(result.payload)
        assert len(decoded) == len(SAMPLE_MESSAGES)

    def test_cross_encoder_v3_compat(self):
        ac = AdaptiveCodebook()
        for _ in range(50):
            ac.observe(SAMPLE_MESSAGES)
        ac.rebuild(min_frequency=5)

        be = BatchEncoder(codebook=ac)
        result_be = be.encode_batch(SAMPLE_MESSAGES)

        ge = GPUBatchEncoder(num_workers=2)
        decoded = ge.decode_batch(result_be.payload)
        assert len(decoded) == len(SAMPLE_MESSAGES)

    def test_learned_codebook_encodes_training_data(self):
        ac = AdaptiveCodebook()
        msgs = [
            {"task": "analyze", "priority": "high"},
            {"task": "optimize", "status": "pending"},
        ]
        for _ in range(50):
            ac.observe(msgs)
        cb = ac.rebuild(min_frequency=5)

        for msg in msgs:
            encoded = encode_dict_cpu(msg, codebook=cb)
            decoded, _ = decode_dict_cpu(encoded, codebook=cb)
            assert decoded == msg

    def test_v3_with_many_messages(self):
        import random
        ac = AdaptiveCodebook()
        for _ in range(50):
            ac.observe(GPU_SAMPLE_MESSAGES)
        ac.rebuild(min_frequency=5)

        msgs = [random.choice(GPU_SAMPLE_MESSAGES) for _ in range(100)]
        enc = GPUBatchEncoder(num_workers=2, codebook=ac)
        result = enc.encode_batch(msgs)
        decoded = enc.decode_batch(result.payload)
        assert len(decoded) == 100
