"""
Tests for WebSocket (/ws/translate) and GPU batch (/translate/gpu-batch) endpoints.

These are the two biggest Product API test coverage gaps:
- WebSocket: real-time streaming translation, error handling, disconnect
- GPU batch: high-throughput encoding, decode roundtrip, validation, profiling
"""

import base64
import json

import pytest

try:
    from fastapi.testclient import TestClient
    from emergent_translator.api_server import app

    API_AVAILABLE = True
except ImportError:
    API_AVAILABLE = False

pytestmark = pytest.mark.skipif(
    not API_AVAILABLE, reason="API server deps not installed"
)

AUTH = {"Authorization": "Bearer eudaimonia-translator-demo"}


# ═══════════════════════════════════════════════════════════════════════════════
# Fixtures
# ═══════════════════════════════════════════════════════════════════════════════

@pytest.fixture()
def client():
    return TestClient(app, raise_server_exceptions=False)


# ═══════════════════════════════════════════════════════════════════════════════
# WebSocket /ws/translate
# ═══════════════════════════════════════════════════════════════════════════════

class TestWebSocketTranslate:
    """Tests for the /ws/translate WebSocket endpoint."""

    def test_ws_json_translation(self, client):
        """Send a JSON translation request and receive a response."""
        with client.websocket_connect("/ws/translate") as ws:
            ws.send_text(json.dumps({
                "data": {"task": "analyze", "agent_id": "a1"},
                "source_format": "json",
                "target_format": "emergent",
            }))
            resp = json.loads(ws.receive_text())

            assert resp["success"] is True
            assert resp["translated_data"] is not None
            # Verify it's valid base64
            raw = base64.b64decode(resp["translated_data"])
            assert len(raw) > 0
            assert "stats" in resp
            assert resp["stats"]["original_size"] > 0
            assert resp["stats"]["translated_size"] > 0
            assert resp["stats"]["compression_ratio"] > 0

    def test_ws_text_translation(self, client):
        """Send a text translation request."""
        with client.websocket_connect("/ws/translate") as ws:
            ws.send_text(json.dumps({
                "data": "Analyze the market data for trends",
                "source_format": "text",
                "target_format": "emergent",
            }))
            resp = json.loads(ws.receive_text())

            assert resp["success"] is True
            assert resp["translated_data"] is not None

    def test_ws_multiple_messages(self, client):
        """Multiple sequential translations on the same connection."""
        with client.websocket_connect("/ws/translate") as ws:
            for i in range(5):
                ws.send_text(json.dumps({
                    "data": {"task": f"task_{i}", "id": i},
                    "source_format": "json",
                    "target_format": "emergent",
                }))
                resp = json.loads(ws.receive_text())
                assert resp["success"] is True

    def test_ws_invalid_json_returns_error(self, client):
        """Sending non-JSON text returns an error response (not disconnect)."""
        with client.websocket_connect("/ws/translate") as ws:
            ws.send_text("this is not json {{{")
            resp = json.loads(ws.receive_text())

            assert resp["success"] is False
            assert len(resp["errors"]) > 0
            assert "JSON" in resp["errors"][0] or "json" in resp["errors"][0].lower()

    def test_ws_unsupported_format(self, client):
        """Unsupported source_format returns error response."""
        with client.websocket_connect("/ws/translate") as ws:
            ws.send_text(json.dumps({
                "data": "hello",
                "source_format": "protobuf",
                "target_format": "emergent",
            }))
            resp = json.loads(ws.receive_text())

            assert resp["success"] is False
            assert any("unsupported" in e.lower() or "format" in e.lower()
                       for e in resp.get("errors", []))

    def test_ws_symbol_families_in_response(self, client):
        """Response includes symbol_families list."""
        with client.websocket_connect("/ws/translate") as ws:
            ws.send_text(json.dumps({
                "data": {"task": "analyze", "priority": "high"},
                "source_format": "json",
                "target_format": "emergent",
            }))
            resp = json.loads(ws.receive_text())

            assert "symbol_families" in resp
            assert isinstance(resp["symbol_families"], list)

    def test_ws_errors_field_present(self, client):
        """Response always has an errors field."""
        with client.websocket_connect("/ws/translate") as ws:
            ws.send_text(json.dumps({
                "data": {"test": True},
                "source_format": "json",
                "target_format": "emergent",
            }))
            resp = json.loads(ws.receive_text())

            assert "errors" in resp
            assert isinstance(resp["errors"], list)

    def test_ws_empty_dict_translation(self, client):
        """Empty dict is still valid JSON to translate."""
        with client.websocket_connect("/ws/translate") as ws:
            ws.send_text(json.dumps({
                "data": {},
                "source_format": "json",
                "target_format": "emergent",
            }))
            resp = json.loads(ws.receive_text())
            # May succeed or fail gracefully — just shouldn't crash
            assert "success" in resp

    def test_ws_large_payload(self, client):
        """Larger payload is handled without crash."""
        big_data = {f"key_{i}": f"value_{i}" * 50 for i in range(50)}
        with client.websocket_connect("/ws/translate") as ws:
            ws.send_text(json.dumps({
                "data": big_data,
                "source_format": "json",
                "target_format": "emergent",
            }))
            resp = json.loads(ws.receive_text())
            assert "success" in resp


# ═══════════════════════════════════════════════════════════════════════════════
# GPU Batch /translate/gpu-batch
# ═══════════════════════════════════════════════════════════════════════════════

class TestGPUBatchEndpoint:
    """Tests for /translate/gpu-batch encoding endpoint."""

    def test_gpu_batch_basic(self, client):
        """Encode a small batch of messages."""
        messages = [
            {"task": "analyze", "data": "market trends"},
            {"agent_id": "agent_001", "status": "running"},
            {"order": {"symbol": "BTC", "side": "buy", "quantity": 100}},
        ]
        resp = client.post(
            "/translate/gpu-batch",
            json={"messages": messages},
            headers=AUTH,
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["success"] is True
        assert data["message_count"] == 3
        assert data["original_bytes"] > 0
        assert data["compressed_bytes"] > 0
        assert data["compression_ratio"] > 0
        assert data["encoding_time_ms"] >= 0
        assert data["throughput_msg_per_sec"] >= 0
        # Payload is valid base64
        raw = base64.b64decode(data["payload"])
        assert len(raw) > 0

    def test_gpu_batch_single_message(self, client):
        """Minimum batch: 1 message."""
        resp = client.post(
            "/translate/gpu-batch",
            json={"messages": [{"key": "value"}]},
            headers=AUTH,
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["success"] is True
        assert data["message_count"] == 1

    def test_gpu_batch_optimal_75(self, client):
        """Encode optimal batch size of 75 messages."""
        messages = [{"task": f"batch_{i}", "id": i} for i in range(75)]
        resp = client.post(
            "/translate/gpu-batch",
            json={"messages": messages},
            headers=AUTH,
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["success"] is True
        assert data["message_count"] == 75
        assert data["compression_ratio"] > 0

    def test_gpu_batch_empty_messages_422(self, client):
        """Empty message list triggers validation error."""
        resp = client.post(
            "/translate/gpu-batch",
            json={"messages": []},
            headers=AUTH,
        )
        assert resp.status_code == 422

    def test_gpu_batch_exceeds_1000_422(self, client):
        """More than 1000 messages triggers validation error."""
        messages = [{"id": i} for i in range(1001)]
        resp = client.post(
            "/translate/gpu-batch",
            json={"messages": messages},
            headers=AUTH,
        )
        assert resp.status_code == 422

    def test_gpu_batch_no_auth_401(self, client):
        """Missing auth token returns 401."""
        resp = client.post(
            "/translate/gpu-batch",
            json={"messages": [{"key": "value"}]},
        )
        assert resp.status_code in (401, 403)

    def test_gpu_batch_wrong_auth_401(self, client):
        """Invalid auth token returns 401."""
        resp = client.post(
            "/translate/gpu-batch",
            json={"messages": [{"key": "value"}]},
            headers={"Authorization": "Bearer wrong-token"},
        )
        assert resp.status_code in (401, 403)

    def test_gpu_batch_with_profiling(self, client):
        """Profile query param returns profiling data."""
        resp = client.post(
            "/translate/gpu-batch?profile=true",
            json={"messages": [{"task": "test"}, {"task": "test2"}]},
            headers=AUTH,
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["success"] is True
        if data.get("profile"):
            profile = data["profile"]
            assert "total_time_ms" in profile
            assert "encode_time_ms" in profile

    def test_gpu_batch_efficiency_gain(self, client):
        """efficiency_gain is computed as (1 - ratio) * 100."""
        messages = [{"task": "analyze", "data": "trends"} for _ in range(10)]
        resp = client.post(
            "/translate/gpu-batch",
            json={"messages": messages},
            headers=AUTH,
        )
        data = resp.json()
        if data["success"]:
            expected_gain = (1 - data["compression_ratio"]) * 100
            assert abs(data["efficiency_gain"] - expected_gain) < 0.1

    def test_gpu_batch_errors_list_empty_on_success(self, client):
        """Successful batch has empty errors list."""
        resp = client.post(
            "/translate/gpu-batch",
            json={"messages": [{"task": "test"}]},
            headers=AUTH,
        )
        data = resp.json()
        if data["success"]:
            assert data.get("errors", []) == []

    def test_gpu_batch_varied_message_shapes(self, client):
        """Messages with different key sets encode successfully."""
        messages = [
            {"task": "a"},
            {"agent_id": "b", "status": "done", "result": {"x": 1}},
            {"coordination": {"participants": ["a1", "a2"]}},
            {"simple": True},
            {"nested": {"deep": {"deeper": "value"}}},
        ]
        resp = client.post(
            "/translate/gpu-batch",
            json={"messages": messages},
            headers=AUTH,
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["success"] is True
        assert data["message_count"] == 5


# ═══════════════════════════════════════════════════════════════════════════════
# GPU Batch Decode /translate/gpu-batch/decode
# ═══════════════════════════════════════════════════════════════════════════════

class TestGPUBatchDecode:
    """Tests for /translate/gpu-batch/decode roundtrip."""

    def test_encode_decode_roundtrip(self, client):
        """Encode then decode should recover original messages."""
        original_messages = [
            {"task": "analyze", "data": "market trends"},
            {"agent_id": "agent_001", "status": "running"},
        ]

        # Encode
        encode_resp = client.post(
            "/translate/gpu-batch",
            json={"messages": original_messages},
            headers=AUTH,
        )
        assert encode_resp.status_code == 200
        payload_b64 = encode_resp.json()["payload"]

        # Decode
        decode_resp = client.post(
            "/translate/gpu-batch/decode",
            data={"payload_b64": payload_b64},
            headers=AUTH,
        )
        assert decode_resp.status_code == 200
        decoded = decode_resp.json()
        assert decoded["success"] is True
        assert len(decoded["messages"]) == 2

    def test_decode_invalid_payload(self, client):
        """Invalid base64 or corrupted payload returns error."""
        decode_resp = client.post(
            "/translate/gpu-batch/decode",
            data={"payload_b64": "not-valid-base64!!!"},
            headers=AUTH,
        )
        # Should return 200 with success=False or 400/422
        if decode_resp.status_code == 200:
            assert decode_resp.json()["success"] is False
        else:
            assert decode_resp.status_code in (400, 422, 500)

    def test_decode_no_auth_401(self, client):
        """Decode without auth returns 401."""
        decode_resp = client.post(
            "/translate/gpu-batch/decode",
            data={"payload_b64": "dGVzdA=="},
        )
        assert decode_resp.status_code in (401, 403)


# ═══════════════════════════════════════════════════════════════════════════════
# Compress Batch /compress/batch
# ═══════════════════════════════════════════════════════════════════════════════

class TestCompressBatch:
    """Tests for /compress/batch chunk compression endpoint."""

    def test_compress_batch_basic(self, client):
        """Compress a small batch of chunks (dicts with dict values)."""
        # GPUChunkCompressor.compress_batch iterates .items() on chunk values,
        # so values must be dicts (not raw strings).
        chunks = [
            {"messages": [{"task": "analyze"}]},
            {"messages": [{"agent_id": "agent_001", "status": "complete"}]},
        ]
        resp = client.post(
            "/compress/batch",
            json={"chunks": chunks},
            headers=AUTH,
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["success"] is True
        assert data["chunk_count"] == 2
        assert data["total_original_bytes"] > 0
        assert data["total_compressed_bytes"] > 0

    def test_compress_batch_single_chunk(self, client):
        """Single chunk batch."""
        resp = client.post(
            "/compress/batch",
            json={"chunks": [{"key": "value"}]},
            headers=AUTH,
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["success"] is True
        assert data["chunk_count"] == 1

    def test_compress_batch_no_auth(self, client):
        """Missing auth returns 401."""
        resp = client.post(
            "/compress/batch",
            json={"chunks": [{"key": "value"}]},
        )
        assert resp.status_code in (401, 403)
