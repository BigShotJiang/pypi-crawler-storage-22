"""
Compression Benchmarks -- Emergent Batch Encoder vs Standard Libraries

Compares the emergent language BatchEncoder against gzip, zstd, lz4,
and brotli across realistic AI-communication data profiles.

Run:
    python3 -m pytest tests/test_benchmarks.py -v -o 'addopts=' -s
"""

import gzip
import json
import struct
import time
import zlib
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Tuple

import pytest

# Optional libraries -- skip gracefully
lz4_frame = pytest.importorskip("lz4.frame", reason="lz4 not installed")
zstandard = pytest.importorskip("zstandard", reason="zstandard not installed")
brotli = pytest.importorskip("brotli", reason="brotli not installed")

from emergent_translator.batch_encoder import BatchEncoder


# ======================================================================
# Test Data Generators
# ======================================================================


def make_single_task() -> Dict:
    return {
        "task": "analyze",
        "type": "analysis",
        "agent_id": "agent-007",
        "priority": "high",
        "status": "pending",
        "params": {"depth": 3, "mode": "comprehensive"},
        "context": {"market": "data", "timeframe": "24h"},
    }


def make_batch_tasks(n: int = 50) -> List[Dict]:
    return [
        {
            "task": "analyze",
            "type": "analysis",
            "agent_id": f"agent-{i:03d}",
            "priority": ["high", "medium", "low"][i % 3],
            "status": "pending",
            "params": {"depth": i % 5 + 1, "mode": "comprehensive"},
            "context": {"market": "data", "timeframe": "24h"},
            "task_id": f"task-{i:04d}",
        }
        for i in range(n)
    ]


def make_coordination_message() -> Dict:
    return {
        "type": "coordination",
        "initiator": "agent-001",
        "participants": ["agent-002", "agent-003", "agent-004"],
        "task_distribution": {
            "agent-002": {"task": "analyze", "priority": "high"},
            "agent-003": {"task": "optimize", "priority": "medium"},
            "agent-004": {"task": "execute", "priority": "low"},
        },
        "consensus": "quorum",
        "metrics": {"confidence": 0.95, "risk": "low"},
    }


def make_market_analysis() -> Dict:
    return {
        "type": "analysis",
        "market": "data",
        "sentiment": "bullish",
        "volatility": "moderate",
        "confidence": 0.87,
        "recommendations": [
            {"action": "buy", "symbol": "AAPL", "quantity": 100, "limit": 150.0},
            {"action": "hold", "symbol": "GOOGL", "quantity": 50},
            {"action": "sell", "symbol": "TSLA", "quantity": 25, "limit": 200.0},
        ],
        "metrics": {
            "summary": "Bullish outlook with moderate volatility",
            "risk": "medium",
            "timeframe": "24h",
        },
        "agents": [
            {"agent_id": f"analyst-{i}", "role": "analysis", "status": "complete"}
            for i in range(5)
        ],
    }


def make_large_batch(n: int = 200) -> List[Dict]:
    messages = []
    for i in range(n):
        if i % 4 == 0:
            messages.append(make_single_task())
        elif i % 4 == 1:
            messages.append(make_coordination_message())
        elif i % 4 == 2:
            messages.append(make_market_analysis())
        else:
            messages.append({
                "task": "execute",
                "data": {"value": i, "name": f"item-{i}"},
                "priority": "medium",
                "status": "running",
            })
    return messages


# ======================================================================
# Compression Backends
# ======================================================================

@dataclass
class CompressionResult:
    name: str
    original_size: int
    compressed_size: int
    ratio: float
    compress_time_us: float
    decompress_time_us: float

    @property
    def reduction_pct(self) -> float:
        return (1 - self.ratio) * 100

    @property
    def throughput_mb_s(self) -> float:
        if self.compress_time_us == 0:
            return float('inf')
        return (self.original_size / 1e6) / (self.compress_time_us / 1e6)


def _bench(name: str, data_bytes: bytes,
           compress_fn: Callable[[bytes], bytes],
           decompress_fn: Callable[[bytes], bytes],
           iterations: int = 50) -> CompressionResult:
    for _ in range(3):
        compressed = compress_fn(data_bytes)
        decompress_fn(compressed)

    t0 = time.perf_counter()
    for _ in range(iterations):
        compressed = compress_fn(data_bytes)
    compress_total = (time.perf_counter() - t0) / iterations * 1e6

    t0 = time.perf_counter()
    for _ in range(iterations):
        decompress_fn(compressed)
    decompress_total = (time.perf_counter() - t0) / iterations * 1e6

    return CompressionResult(
        name=name,
        original_size=len(data_bytes),
        compressed_size=len(compressed),
        ratio=len(compressed) / len(data_bytes),
        compress_time_us=compress_total,
        decompress_time_us=decompress_total,
    )


def bench_gzip(data: bytes) -> CompressionResult:
    return _bench("gzip-9", data,
                  lambda d: gzip.compress(d, compresslevel=9),
                  gzip.decompress)


def bench_zlib(data: bytes) -> CompressionResult:
    return _bench("zlib-9", data,
                  lambda d: zlib.compress(d, 9),
                  zlib.decompress)


def bench_zstd(data: bytes) -> CompressionResult:
    cctx = zstandard.ZstdCompressor(level=3)
    dctx = zstandard.ZstdDecompressor()
    return _bench("zstd-3", data, cctx.compress, dctx.decompress)


def bench_zstd_max(data: bytes) -> CompressionResult:
    cctx = zstandard.ZstdCompressor(level=19)
    dctx = zstandard.ZstdDecompressor()
    return _bench("zstd-19", data, cctx.compress, dctx.decompress)


def bench_lz4(data: bytes) -> CompressionResult:
    return _bench("lz4", data, lz4_frame.compress, lz4_frame.decompress)


def bench_brotli(data: bytes) -> CompressionResult:
    return _bench("brotli-6", data,
                  lambda d: brotli.compress(d, quality=6),
                  brotli.decompress)


def bench_emergent_single(messages: List[Dict]) -> CompressionResult:
    encoder = BatchEncoder()
    json_bytes = json.dumps(messages, separators=(",", ":")).encode()

    def compress_fn(_ignored):
        return encoder.encode_batch(messages).payload

    def decompress_fn(data):
        return encoder.decode_batch(data)

    for _ in range(3):
        compressed = compress_fn(None)
        decompress_fn(compressed)

    iterations = 50

    t0 = time.perf_counter()
    for _ in range(iterations):
        compressed = compress_fn(None)
    compress_us = (time.perf_counter() - t0) / iterations * 1e6

    t0 = time.perf_counter()
    for _ in range(iterations):
        decompress_fn(compressed)
    decompress_us = (time.perf_counter() - t0) / iterations * 1e6

    return CompressionResult(
        name="emergent",
        original_size=len(json_bytes),
        compressed_size=len(compressed),
        ratio=len(compressed) / len(json_bytes),
        compress_time_us=compress_us,
        decompress_time_us=decompress_us,
    )


# ======================================================================
# Reporting
# ======================================================================

def _report(label: str, results: List[CompressionResult]):
    results.sort(key=lambda r: r.ratio)
    print(f"\n{'=' * 80}")
    print(f"  {label}")
    print(f"  Original: {results[0].original_size:,} bytes")
    print(f"{'=' * 80}")
    print(f"  {'Method':<12} {'Compressed':>10} {'Ratio':>7} {'Reduction':>10} "
          f"{'Encode':>10} {'Decode':>10} {'MB/s':>8}")
    print(f"  {'-' * 12} {'-' * 10} {'-' * 7} {'-' * 10} "
          f"{'-' * 10} {'-' * 10} {'-' * 8}")
    for r in results:
        print(f"  {r.name:<12} {r.compressed_size:>10,} {r.ratio:>7.3f} "
              f"{r.reduction_pct:>9.1f}% "
              f"{r.compress_time_us:>9.0f}us {r.decompress_time_us:>9.0f}us "
              f"{r.throughput_mb_s:>7.1f}")
    print()


def _full_benchmark(label: str, messages: List[Dict]) -> List[CompressionResult]:
    json_bytes = json.dumps(messages, separators=(",", ":")).encode()
    results = [
        bench_gzip(json_bytes),
        bench_zlib(json_bytes),
        bench_zstd(json_bytes),
        bench_zstd_max(json_bytes),
        bench_lz4(json_bytes),
        bench_brotli(json_bytes),
        bench_emergent_single(messages),
    ]
    _report(label, results)
    return results


# ======================================================================
# Tests — Emergent vs Standard
# ======================================================================


class TestEmergentVsStandard:
    def test_single_task_message(self):
        msg = make_single_task()
        results = _full_benchmark("Single Task Message", [msg])
        emergent = next(r for r in results if r.name == "emergent")
        assert emergent.ratio < 1.0
        assert emergent.compressed_size < emergent.original_size

    def test_batch_50_tasks(self):
        messages = make_batch_tasks(50)
        results = _full_benchmark("Batch: 50 Task Messages", messages)
        emergent = next(r for r in results if r.name == "emergent")
        assert emergent.ratio < 1.0

    def test_coordination_message(self):
        msg = make_coordination_message()
        results = _full_benchmark("Coordination Message", [msg])
        emergent = next(r for r in results if r.name == "emergent")
        assert emergent.ratio < 1.0

    def test_market_analysis(self):
        msg = make_market_analysis()
        results = _full_benchmark("Market Analysis Report", [msg])
        emergent = next(r for r in results if r.name == "emergent")
        assert emergent.ratio < 1.0

    def test_large_heterogeneous_batch(self):
        messages = make_large_batch(200)
        results = _full_benchmark("Large Batch: 200 Mixed Messages", messages)
        emergent = next(r for r in results if r.name == "emergent")
        assert emergent.ratio < 0.5

    def test_emergent_beats_json_always(self):
        scenarios = [
            ("single", [make_single_task()]),
            ("coord", [make_coordination_message()]),
            ("market", [make_market_analysis()]),
            ("batch50", make_batch_tasks(50)),
            ("batch200", make_large_batch(200)),
        ]
        for name, messages in scenarios:
            json_size = len(json.dumps(messages, separators=(",", ":")).encode())
            encoder = BatchEncoder()
            compressed = encoder.encode_batch(messages).payload
            assert len(compressed) < json_size, \
                f"{name}: emergent ({len(compressed)}) >= JSON ({json_size})"


class TestEmergentCompressionProperties:
    def test_common_keys_compress_well(self):
        optimized = [
            {"task": "analyze", "type": "analysis", "priority": "high",
             "status": "pending", "agent_id": "a1"}
            for _ in range(20)
        ]
        unoptimized = [
            {"custom_task_xyz": "analyze", "unusual_type": "analysis",
             "my_priority": "high", "current_status": "pending",
             "agent_identifier": "a1"}
            for _ in range(20)
        ]
        encoder = BatchEncoder()
        opt_size = len(encoder.encode_batch(optimized).payload)
        unopt_size = len(encoder.encode_batch(unoptimized).payload)
        assert opt_size < unopt_size

    def test_common_values_compress_well(self):
        optimized = [
            {"status": "pending", "priority": "high", "task": "analyze"}
            for _ in range(20)
        ]
        custom = [
            {"status": "waiting_for_approval", "priority": "ultra_critical",
             "task": "perform_deep_investigation"}
            for _ in range(20)
        ]
        encoder = BatchEncoder()
        opt_size = len(encoder.encode_batch(optimized).payload)
        custom_size = len(encoder.encode_batch(custom).payload)
        assert opt_size < custom_size

    def test_batch_size_scaling(self):
        encoder = BatchEncoder()
        ratios = []
        for n in [1, 5, 10, 50, 100]:
            messages = make_batch_tasks(n)
            json_size = len(json.dumps(messages, separators=(",", ":")).encode())
            compressed = encoder.encode_batch(messages).payload
            ratio = len(compressed) / json_size
            ratios.append(ratio)
        assert ratios[-1] < ratios[0], \
            f"Batch scaling failed: ratio@1={ratios[0]:.3f} vs ratio@100={ratios[-1]:.3f}"

    def test_round_trip_correctness(self):
        KEY_ALIASES = {
            "params": "parameters",
            "parameters": "params",
            "v": "version",
        }
        encoder = BatchEncoder()
        scenarios = [
            [make_single_task()],
            make_batch_tasks(20),
            [make_coordination_message()],
            [make_market_analysis()],
            make_large_batch(50),
        ]
        for messages in scenarios:
            compressed = encoder.encode_batch(messages).payload
            decoded = encoder.decode_batch(compressed)
            assert len(decoded) == len(messages)
            for orig, dec in zip(messages, decoded):
                dec_keys = set(dec.keys())
                for key in orig:
                    alias = KEY_ALIASES.get(key)
                    assert key in dec_keys or (alias and alias in dec_keys), \
                        f"Missing key {key} (alias {alias}) in {dec_keys}"

    def test_encoding_speed(self):
        """100-message batch encode < 50ms (generous for CI)."""
        messages = make_batch_tasks(100)
        encoder = BatchEncoder()
        for _ in range(5):
            encoder.encode_batch(messages)

        times = []
        for _ in range(20):
            t0 = time.perf_counter()
            encoder.encode_batch(messages)
            times.append((time.perf_counter() - t0) * 1000)

        avg_ms = sum(times) / len(times)
        assert avg_ms < 50, f"Encoding too slow: {avg_ms:.1f}ms for 100 messages"

    def test_decoding_speed(self):
        """100-message batch decode < 50ms."""
        messages = make_batch_tasks(100)
        encoder = BatchEncoder()
        compressed = encoder.encode_batch(messages).payload

        for _ in range(5):
            encoder.decode_batch(compressed)

        times = []
        for _ in range(20):
            t0 = time.perf_counter()
            encoder.decode_batch(compressed)
            times.append((time.perf_counter() - t0) * 1000)

        avg_ms = sum(times) / len(times)
        assert avg_ms < 50, f"Decoding too slow: {avg_ms:.1f}ms for 100 messages"


# ======================================================================
# New performance targets (post-optimization)
# ======================================================================


class TestPerformanceTargets:
    """Encoder speed assertions added for the optimization pass."""

    def test_100_message_encode_under_10ms(self):
        """100-message batch encode should complete in < 10ms."""
        messages = make_batch_tasks(100)
        encoder = BatchEncoder()
        # Warmup
        for _ in range(10):
            encoder.encode_batch(messages)

        times = []
        for _ in range(30):
            t0 = time.perf_counter()
            encoder.encode_batch(messages)
            times.append((time.perf_counter() - t0) * 1000)

        avg_ms = sum(times) / len(times)
        print(f"  100-msg encode: {avg_ms:.2f}ms avg")
        assert avg_ms < 10, f"Encode too slow: {avg_ms:.2f}ms (target < 10ms)"

    def test_1000_message_throughput(self):
        """1000-message throughput > 50K msg/s."""
        messages = make_batch_tasks(1000)
        encoder = BatchEncoder()
        # Warmup
        for _ in range(3):
            encoder.encode_batch(messages)

        times = []
        for _ in range(10):
            t0 = time.perf_counter()
            encoder.encode_batch(messages)
            elapsed = time.perf_counter() - t0
            times.append(elapsed)

        avg_time = sum(times) / len(times)
        throughput = 1000 / avg_time
        print(f"  1000-msg throughput: {throughput:,.0f} msg/s")
        assert throughput > 50_000, f"Throughput too low: {throughput:,.0f} msg/s (target > 50K)"

    def test_100_message_decode_under_10ms(self):
        """100-message batch decode should complete in < 10ms."""
        messages = make_batch_tasks(100)
        encoder = BatchEncoder()
        compressed = encoder.encode_batch(messages).payload
        # Warmup
        for _ in range(10):
            encoder.decode_batch(compressed)

        times = []
        for _ in range(30):
            t0 = time.perf_counter()
            encoder.decode_batch(compressed)
            times.append((time.perf_counter() - t0) * 1000)

        avg_ms = sum(times) / len(times)
        print(f"  100-msg decode: {avg_ms:.2f}ms avg")
        assert avg_ms < 10, f"Decode too slow: {avg_ms:.2f}ms (target < 10ms)"


# ======================================================================
# Summary benchmark
# ======================================================================


class TestBenchmarkSummary:
    def test_full_comparison_summary(self):
        print("\n" + "=" * 80)
        print("  EMERGENT LANGUAGE COMPRESSION BENCHMARK SUMMARY")
        print("=" * 80)

        scenarios = [
            ("Single Task (~200B)", [make_single_task()]),
            ("Coordination (~500B)", [make_coordination_message()]),
            ("Market Analysis (~1KB)", [make_market_analysis()]),
            ("Batch x50 (~8KB)", make_batch_tasks(50)),
            ("Mixed x200 (~40KB)", make_large_batch(200)),
        ]

        emergent_wins = 0
        total_scenarios = len(scenarios)

        for label, messages in scenarios:
            results = _full_benchmark(label, messages)
            emergent = next(r for r in results if r.name == "emergent")
            best_standard = min(
                (r for r in results if r.name != "emergent"),
                key=lambda r: r.ratio,
            )

            if emergent.ratio < best_standard.ratio:
                emergent_wins += 1
                print(f"  >>> Emergent WINS vs {best_standard.name}: "
                      f"{emergent.ratio:.3f} vs {best_standard.ratio:.3f}")
            else:
                print(f"  >>> {best_standard.name} wins: "
                      f"{best_standard.ratio:.3f} vs emergent {emergent.ratio:.3f}")

        print(f"\n  Emergent wins {emergent_wins}/{total_scenarios} scenarios")
        print("=" * 80)
