"""
Comprehensive pytest test suite for the Edge Worker (scripts/edge_worker.py).

Covers:
- All HTTP endpoints via FastAPI TestClient
- Batching mechanics (optimal size, partial batches, timeouts)
- Dispatcher forwarding with mocked upstream API
- Backpressure (503 on queue full, partial batch accept/drop)
- GPU-batch to batch fallback on upstream error
- Graceful shutdown (buffered batch flush)
- Stats accuracy (throughput, avg batch size)
- /forward polymorphic routing (list vs object)
- Error paths (upstream failures, invalid JSON)
"""

import asyncio
import sys
import time
from pathlib import Path
from typing import Dict, List, Any
from unittest.mock import AsyncMock, patch, MagicMock

import pytest
import httpx

# Ensure scripts/ is importable
_scripts_dir = str(Path(__file__).resolve().parent.parent / "scripts")
if _scripts_dir not in sys.path:
    sys.path.insert(0, _scripts_dir)

from edge_worker import (
    EdgeWorker,
    WorkerStats,
    EdgeStats,
    MessageRequest,
    BatchRequest,
    app,
)

try:
    from fastapi.testclient import TestClient
    TESTCLIENT_AVAILABLE = True
except ImportError:
    TESTCLIENT_AVAILABLE = False

pytestmark = pytest.mark.skipif(
    not TESTCLIENT_AVAILABLE, reason="FastAPI TestClient not available"
)


# ═══════════════════════════════════════════════════════════════════════════════
# Helpers
# ═══════════════════════════════════════════════════════════════════════════════

def _make_msg(i: int = 0) -> Dict[str, Any]:
    """Create a simple test message."""
    return {"task": "test", "id": i}


class MockEdgeWorker(EdgeWorker):
    """EdgeWorker with _send_batch intercepted — no real HTTP calls."""

    def __init__(self, **kwargs):
        super().__init__(api_url="http://mock-api:9999", **kwargs)
        self.batches_sent_log: List[List[Dict]] = []
        self.send_batch_side_effect = None  # callable or exception

    async def _send_batch(self, batch, dispatcher_id):
        if self.send_batch_side_effect:
            if callable(self.send_batch_side_effect):
                await self.send_batch_side_effect(batch, dispatcher_id)
                return
            raise self.send_batch_side_effect
        self.batches_sent_log.append([m.copy() for m in batch])
        self.stats.messages_forwarded += len(batch)
        self.stats.batches_sent += 1


# ═══════════════════════════════════════════════════════════════════════════════
# Unit Tests — EdgeWorker class directly
# ═══════════════════════════════════════════════════════════════════════════════

class TestEdgeWorkerUnit:
    """Test EdgeWorker internals without HTTP layer."""

    @pytest.mark.asyncio
    async def test_submit_single_message(self):
        w = MockEdgeWorker()
        await w.start()
        try:
            result = await w.submit(_make_msg(1))
            assert result["queued"] is True
            assert result["message_id"] == 1
            assert result["queue_size"] >= 0
            assert w.stats.messages_received == 1
        finally:
            await w.stop()

    @pytest.mark.asyncio
    async def test_submit_batch(self):
        w = MockEdgeWorker()
        await w.start()
        try:
            msgs = [_make_msg(i) for i in range(10)]
            result = await w.submit_batch(msgs)
            assert result["queued"] == 10
            assert result["dropped"] == 0
            assert w.stats.messages_received == 10
        finally:
            await w.stop()

    @pytest.mark.asyncio
    async def test_backpressure_single_submit_503(self):
        """Queue full triggers 503 on single submit."""
        w = MockEdgeWorker(max_queue_size=5)
        await w.start()
        try:
            # Fill the queue (dispatchers may drain some, so disable them)
            w._running = False  # pause dispatchers
            for task in w._tasks:
                task.cancel()
            await asyncio.gather(*w._tasks, return_exceptions=True)
            w._tasks.clear()

            # Fill queue manually
            for i in range(5):
                await w.queue.put(_make_msg(i))

            from fastapi import HTTPException
            with pytest.raises(HTTPException) as exc_info:
                await w.submit(_make_msg(99))
            assert exc_info.value.status_code == 503
            assert "backpressure" in exc_info.value.detail.lower()
        finally:
            w._running = False
            if w._client:
                await w._client.aclose()

    @pytest.mark.asyncio
    async def test_backpressure_batch_partial_accept(self):
        """Batch submit accepts partial when queue fills up."""
        w = MockEdgeWorker(max_queue_size=5)
        await w.start()
        try:
            w._running = False
            for task in w._tasks:
                task.cancel()
            await asyncio.gather(*w._tasks, return_exceptions=True)
            w._tasks.clear()

            # Fill 3 of 5 slots
            for i in range(3):
                await w.queue.put(_make_msg(i))

            # Submit 5 more — only 2 should fit
            msgs = [_make_msg(i) for i in range(100, 105)]
            result = await w.submit_batch(msgs)
            assert result["queued"] == 2
            assert result["dropped"] == 3
        finally:
            w._running = False
            if w._client:
                await w._client.aclose()

    @pytest.mark.asyncio
    async def test_batch_formation_at_optimal_size(self):
        """Dispatchers form batches at configured batch_size."""
        w = MockEdgeWorker(batch_size=10, num_dispatchers=1)
        await w.start()
        try:
            # Submit exactly 10 messages
            for i in range(10):
                await w.submit(_make_msg(i))

            # Wait for batch to be dispatched
            await asyncio.sleep(0.5)

            assert w.stats.batches_sent >= 1
            # At least one batch should be exactly 10
            assert any(len(b) == 10 for b in w.batches_sent_log)
        finally:
            await w.stop()

    @pytest.mark.asyncio
    async def test_partial_batch_on_timeout(self):
        """Partial batch sent when timeout fires with queued messages."""
        w = MockEdgeWorker(
            batch_size=100,  # high — won't fill naturally
            batch_timeout_ms=100,  # short timeout
            num_dispatchers=1,
        )
        await w.start()
        try:
            # Submit fewer than batch_size
            for i in range(5):
                await w.submit(_make_msg(i))

            # Wait for timeout to fire
            await asyncio.sleep(0.4)

            assert w.stats.batches_sent >= 1
            total_forwarded = sum(len(b) for b in w.batches_sent_log)
            assert total_forwarded == 5
        finally:
            await w.stop()

    @pytest.mark.asyncio
    async def test_multiple_dispatchers_drain_queue(self):
        """Multiple dispatchers concurrently drain the shared queue."""
        w = MockEdgeWorker(
            batch_size=10,
            batch_timeout_ms=100,
            num_dispatchers=4,
        )
        await w.start()
        try:
            for i in range(100):
                await w.submit(_make_msg(i))

            await asyncio.sleep(1.0)

            assert w.stats.messages_forwarded == 100
            assert w.stats.batches_sent >= 1
        finally:
            await w.stop()

    @pytest.mark.asyncio
    async def test_graceful_shutdown_flushes_buffered(self):
        """Graceful stop sends any remaining buffered messages."""
        w = MockEdgeWorker(
            batch_size=1000,  # very large — won't trigger by size
            batch_timeout_ms=10000,  # very long — won't trigger by timeout
            num_dispatchers=1,
        )
        await w.start()
        try:
            for i in range(5):
                await w.submit(_make_msg(i))
            # Give dispatcher a moment to pick up messages
            await asyncio.sleep(0.1)
        finally:
            await w.stop()

        # Shutdown should have flushed remaining
        total = sum(len(b) for b in w.batches_sent_log)
        assert total == 5

    @pytest.mark.asyncio
    async def test_stats_accuracy(self):
        """get_stats() returns accurate computed fields."""
        w = MockEdgeWorker(batch_size=5, num_dispatchers=1, batch_timeout_ms=50)
        await w.start()
        try:
            for i in range(15):
                await w.submit(_make_msg(i))
            await asyncio.sleep(0.5)

            stats = w.get_stats()
            assert stats.messages_received == 15
            assert stats.messages_forwarded == 15
            assert stats.batches_sent >= 1
            assert stats.uptime_seconds > 0
            assert stats.throughput_msg_per_sec > 0
            expected_avg = stats.messages_forwarded / stats.batches_sent
            assert abs(stats.avg_batch_size - expected_avg) < 0.01
        finally:
            await w.stop()

    @pytest.mark.asyncio
    async def test_stats_zero_division_safety(self):
        """get_stats() handles zero batches/uptime without errors."""
        w = MockEdgeWorker()
        # Don't start — check fresh stats
        w.stats = WorkerStats()
        stats = w.get_stats()
        assert stats.avg_batch_size == 0
        assert stats.throughput_msg_per_sec >= 0

    @pytest.mark.asyncio
    async def test_dispatcher_error_does_not_crash(self):
        """Dispatcher survives _send_batch exceptions and keeps running."""
        call_count = 0

        async def failing_send(batch, disp_id):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise RuntimeError("Simulated upstream failure")
            # Succeed on subsequent calls
            pass

        w = MockEdgeWorker(batch_size=1, num_dispatchers=1, batch_timeout_ms=50)
        w.send_batch_side_effect = failing_send
        await w.start()
        try:
            await w.submit(_make_msg(0))
            await asyncio.sleep(0.3)
            # Dispatcher should still be alive after error
            assert w.stats.errors >= 1
            # Submit another — should still be processed
            await w.submit(_make_msg(1))
            await asyncio.sleep(0.3)
            assert call_count >= 2
        finally:
            await w.stop()

    @pytest.mark.asyncio
    async def test_send_batch_rust_endpoint_success(self):
        """_send_batch hits /translate/rust-batch first (happy path)."""
        w = EdgeWorker(api_url="http://mock:9999", batch_size=5, num_dispatchers=0)

        mock_response = MagicMock()
        mock_response.status_code = 200

        mock_client = AsyncMock()
        mock_client.post = AsyncMock(return_value=mock_response)
        w._client = mock_client

        batch = [_make_msg(i) for i in range(3)]
        await w._send_batch(batch, dispatcher_id=0)

        assert w.stats.messages_forwarded == 3
        assert w.stats.batches_sent == 1
        # Should have called rust-batch first (only 1 call since it succeeded)
        assert mock_client.post.call_count == 1
        call_args = mock_client.post.call_args
        assert "/translate/rust-batch" in call_args[0][0]

    @pytest.mark.asyncio
    async def test_send_batch_fallback_rust_to_gpu(self):
        """When rust-batch fails, falls back to gpu-batch."""
        w = EdgeWorker(api_url="http://mock:9999", batch_size=5, num_dispatchers=0)

        rust_fail = MagicMock()
        rust_fail.status_code = 500
        gpu_ok = MagicMock()
        gpu_ok.status_code = 200

        mock_client = AsyncMock()
        mock_client.post = AsyncMock(side_effect=[rust_fail, gpu_ok])
        w._client = mock_client

        batch = [_make_msg(i) for i in range(3)]
        await w._send_batch(batch, dispatcher_id=0)

        assert w.stats.messages_forwarded == 3
        assert w.stats.batches_sent == 1
        assert mock_client.post.call_count == 2
        second_call = mock_client.post.call_args_list[1]
        assert "/translate/gpu-batch" in second_call[0][0]

    @pytest.mark.asyncio
    async def test_send_batch_fallback_to_regular_batch(self):
        """When rust-batch and gpu-batch both fail, falls back to /translate/batch."""
        w = EdgeWorker(api_url="http://mock:9999", batch_size=5, num_dispatchers=0)

        fail_resp = MagicMock()
        fail_resp.status_code = 500
        batch_ok = MagicMock()
        batch_ok.status_code = 200

        mock_client = AsyncMock()
        mock_client.post = AsyncMock(side_effect=[fail_resp, fail_resp, batch_ok])
        w._client = mock_client

        batch = [_make_msg(i) for i in range(3)]
        await w._send_batch(batch, dispatcher_id=0)

        assert w.stats.messages_forwarded == 3
        assert w.stats.batches_sent == 1
        assert mock_client.post.call_count == 3
        third_call = mock_client.post.call_args_list[2]
        assert "/translate/batch" in third_call[0][0]

    @pytest.mark.asyncio
    async def test_send_batch_all_endpoints_fail(self):
        """When all three endpoints fail, error is recorded."""
        w = EdgeWorker(api_url="http://mock:9999", batch_size=5, num_dispatchers=0)

        fail_resp = MagicMock()
        fail_resp.status_code = 500

        mock_client = AsyncMock()
        mock_client.post = AsyncMock(return_value=fail_resp)
        w._client = mock_client

        batch = [_make_msg(i) for i in range(3)]
        await w._send_batch(batch, dispatcher_id=0)

        assert w.stats.messages_forwarded == 0
        assert w.stats.errors == 1
        # Should have tried all 3 endpoints
        assert mock_client.post.call_count == 3

    @pytest.mark.asyncio
    async def test_send_batch_network_exception(self):
        """Network exception during _send_batch records error."""
        w = EdgeWorker(api_url="http://mock:9999", batch_size=5, num_dispatchers=0)

        mock_client = AsyncMock()
        mock_client.post = AsyncMock(side_effect=httpx.ConnectError("Connection refused"))
        w._client = mock_client

        batch = [_make_msg(i) for i in range(3)]
        await w._send_batch(batch, dispatcher_id=0)

        assert w.stats.errors == 1
        assert w.stats.messages_forwarded == 0

    @pytest.mark.asyncio
    async def test_send_batch_empty_batch_noop(self):
        """Empty batch is a no-op."""
        w = EdgeWorker(api_url="http://mock:9999", num_dispatchers=0)
        mock_client = AsyncMock()
        w._client = mock_client

        await w._send_batch([], dispatcher_id=0)
        mock_client.post.assert_not_called()

    @pytest.mark.asyncio
    async def test_send_batch_no_client_noop(self):
        """No HTTP client means no-op."""
        w = EdgeWorker(api_url="http://mock:9999", num_dispatchers=0)
        w._client = None

        await w._send_batch([_make_msg(0)], dispatcher_id=0)
        assert w.stats.messages_forwarded == 0

    @pytest.mark.asyncio
    async def test_auth_header_sent(self):
        """Authorization header is set correctly on outbound requests."""
        token = "test-secret-token"
        w = EdgeWorker(api_url="http://mock:9999", auth_token=token, num_dispatchers=0)

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_client = AsyncMock()
        mock_client.post = AsyncMock(return_value=mock_response)
        w._client = mock_client

        await w._send_batch([_make_msg(0)], dispatcher_id=0)

        call_kwargs = mock_client.post.call_args[1]
        assert call_kwargs["headers"]["Authorization"] == f"Bearer {token}"


# ═══════════════════════════════════════════════════════════════════════════════
# HTTP Endpoint Tests via TestClient
# ═══════════════════════════════════════════════════════════════════════════════

class TestEdgeWorkerEndpoints:
    """Test all Edge Worker HTTP endpoints via FastAPI TestClient."""

    @pytest.fixture(autouse=True)
    def setup_client(self):
        """Inject a MockEdgeWorker into the app's global state."""
        import edge_worker as ew_module

        mock_worker = MockEdgeWorker(batch_size=75, batch_timeout_ms=200)
        # Manually init without starting dispatchers (no event loop in sync test)
        mock_worker._running = True
        mock_worker._client = MagicMock()  # placeholder, _send_batch is mocked
        mock_worker.stats = WorkerStats()

        original_worker = ew_module.worker
        ew_module.worker = mock_worker
        self.client = TestClient(app, raise_server_exceptions=False)
        self.worker = mock_worker
        yield
        ew_module.worker = original_worker

    def test_health_endpoint(self):
        resp = self.client.get("/health")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "healthy"
        assert data["service"] == "edge-worker"

    def test_stats_endpoint(self):
        resp = self.client.get("/stats")
        assert resp.status_code == 200
        data = resp.json()
        assert "messages_received" in data
        assert "messages_forwarded" in data
        assert "batches_sent" in data
        assert "errors" in data
        assert "queue_size" in data
        assert "uptime_seconds" in data
        assert "throughput_msg_per_sec" in data
        assert "avg_batch_size" in data

    def test_submit_single_message(self):
        resp = self.client.post("/submit", json={"data": _make_msg(1)})
        assert resp.status_code == 200
        data = resp.json()
        assert data["queued"] is True
        assert "queue_size" in data
        assert "message_id" in data

    def test_submit_with_callback_id(self):
        resp = self.client.post(
            "/submit",
            json={"data": _make_msg(1), "callback_id": "cb-123"},
        )
        assert resp.status_code == 200
        assert resp.json()["queued"] is True

    def test_submit_batch_endpoint(self):
        msgs = [_make_msg(i) for i in range(5)]
        resp = self.client.post("/submit/batch", json={"messages": msgs})
        assert resp.status_code == 200
        data = resp.json()
        assert data["queued"] == 5
        assert data["dropped"] == 0

    def test_submit_invalid_payload_422(self):
        """Missing required 'data' field returns 422."""
        resp = self.client.post("/submit", json={"wrong_field": "oops"})
        assert resp.status_code == 422

    def test_submit_batch_empty_list(self):
        resp = self.client.post("/submit/batch", json={"messages": []})
        assert resp.status_code == 200
        data = resp.json()
        assert data["queued"] == 0
        assert data["dropped"] == 0

    def test_forward_with_object(self):
        """POST /forward with a JSON object routes to submit()."""
        resp = self.client.post("/forward", json=_make_msg(1))
        assert resp.status_code == 200
        data = resp.json()
        assert data["queued"] is True

    def test_forward_with_list(self):
        """POST /forward with a JSON array routes to submit_batch()."""
        msgs = [_make_msg(i) for i in range(3)]
        resp = self.client.post("/forward", json=msgs)
        assert resp.status_code == 200
        data = resp.json()
        assert "queued" in data

    def test_forward_invalid_json_400(self):
        """POST /forward with non-JSON body returns 400 or 422."""
        resp = self.client.post(
            "/forward",
            content=b"not json at all {{{",
            headers={"content-type": "application/json"},
        )
        # FastAPI may return 422 (validation) or the handler returns 400
        assert resp.status_code in (400, 422)

    def test_stats_reflect_submissions(self):
        """Stats endpoint reflects messages received after submissions."""
        # Submit a few messages
        for i in range(3):
            self.client.post("/submit", json={"data": _make_msg(i)})

        resp = self.client.get("/stats")
        data = resp.json()
        assert data["messages_received"] >= 3

    def test_openapi_docs_available(self):
        """OpenAPI schema is served (FastAPI default)."""
        resp = self.client.get("/openapi.json")
        assert resp.status_code == 200
        schema = resp.json()
        assert "paths" in schema
        assert "/health" in schema["paths"]
        assert "/submit" in schema["paths"]
        assert "/submit/batch" in schema["paths"]
        assert "/forward" in schema["paths"]
        assert "/stats" in schema["paths"]


# ═══════════════════════════════════════════════════════════════════════════════
# Integration-style tests (EdgeWorker + dispatchers with mock upstream)
# ═══════════════════════════════════════════════════════════════════════════════

class TestEdgeWorkerIntegration:
    """End-to-end EdgeWorker tests with mock HTTP upstream."""

    @pytest.mark.asyncio
    async def test_full_pipeline_submit_to_forward(self):
        """Messages flow: submit → queue → dispatcher → _send_batch."""
        w = MockEdgeWorker(batch_size=5, num_dispatchers=1, batch_timeout_ms=50)
        await w.start()
        try:
            for i in range(5):
                await w.submit(_make_msg(i))
            await asyncio.sleep(0.5)

            assert w.stats.messages_forwarded == 5
            assert w.stats.batches_sent >= 1
            # Verify message content preserved
            all_msgs = [m for batch in w.batches_sent_log for m in batch]
            ids = sorted(m["id"] for m in all_msgs)
            assert ids == list(range(5))
        finally:
            await w.stop()

    @pytest.mark.asyncio
    async def test_high_volume_all_messages_delivered(self):
        """All submitted messages eventually get forwarded."""
        w = MockEdgeWorker(batch_size=25, num_dispatchers=2, batch_timeout_ms=50)
        await w.start()
        try:
            for i in range(200):
                await w.submit(_make_msg(i))
            await asyncio.sleep(2.0)

            assert w.stats.messages_forwarded == 200
        finally:
            await w.stop()

    @pytest.mark.asyncio
    async def test_mixed_submit_and_batch_submit(self):
        """Both submit() and submit_batch() feed the same queue."""
        w = MockEdgeWorker(batch_size=10, num_dispatchers=1, batch_timeout_ms=100)
        await w.start()
        try:
            await w.submit(_make_msg(0))
            await w.submit_batch([_make_msg(i) for i in range(1, 6)])
            await w.submit(_make_msg(6))

            await asyncio.sleep(0.5)

            assert w.stats.messages_received == 7
            assert w.stats.messages_forwarded == 7
        finally:
            await w.stop()

    @pytest.mark.asyncio
    async def test_configurable_batch_size(self):
        """Custom batch sizes produce correctly-sized batches."""
        w = MockEdgeWorker(batch_size=3, num_dispatchers=1, batch_timeout_ms=50)
        await w.start()
        try:
            for i in range(9):
                await w.submit(_make_msg(i))
            await asyncio.sleep(0.5)

            # Should have 3 batches of 3
            full_batches = [b for b in w.batches_sent_log if len(b) == 3]
            assert len(full_batches) >= 3
        finally:
            await w.stop()

    @pytest.mark.asyncio
    async def test_configurable_dispatchers(self):
        """Worker starts the configured number of dispatcher tasks."""
        for n in [1, 2, 8]:
            w = MockEdgeWorker(num_dispatchers=n, batch_timeout_ms=50)
            await w.start()
            try:
                assert len(w._tasks) == n
            finally:
                await w.stop()


# ═══════════════════════════════════════════════════════════════════════════════
# Pydantic Model Tests
# ═══════════════════════════════════════════════════════════════════════════════

class TestEdgeWorkerModels:
    """Validate Pydantic request/response models."""

    def test_message_request_required_data(self):
        req = MessageRequest(data={"key": "value"})
        assert req.data == {"key": "value"}
        assert req.callback_id is None

    def test_message_request_with_callback(self):
        req = MessageRequest(data={"key": "value"}, callback_id="abc")
        assert req.callback_id == "abc"

    def test_batch_request(self):
        req = BatchRequest(messages=[{"a": 1}, {"b": 2}])
        assert len(req.messages) == 2

    def test_edge_stats_model(self):
        stats = EdgeStats(
            messages_received=100,
            messages_forwarded=90,
            batches_sent=10,
            errors=2,
            queue_size=5,
            uptime_seconds=60.0,
            throughput_msg_per_sec=1.5,
            avg_batch_size=9.0,
        )
        assert stats.messages_received == 100
        assert stats.avg_batch_size == 9.0


# ═══════════════════════════════════════════════════════════════════════════════
# Edge Cases & Stress
# ═══════════════════════════════════════════════════════════════════════════════

class TestEdgeWorkerEdgeCases:
    """Unusual inputs and boundary conditions."""

    @pytest.mark.asyncio
    async def test_large_message_payload(self):
        """Large dict payloads are accepted."""
        w = MockEdgeWorker(batch_size=1, num_dispatchers=1, batch_timeout_ms=50)
        await w.start()
        try:
            big_msg = {f"key_{i}": f"value_{i}" * 100 for i in range(100)}
            result = await w.submit(big_msg)
            assert result["queued"] is True
            await asyncio.sleep(0.3)
            assert w.stats.messages_forwarded == 1
        finally:
            await w.stop()

    @pytest.mark.asyncio
    async def test_nested_dict_payload(self):
        """Deeply nested dicts pass through."""
        w = MockEdgeWorker(batch_size=1, num_dispatchers=1, batch_timeout_ms=50)
        await w.start()
        try:
            nested = {"level": 0}
            current = nested
            for i in range(1, 20):
                current["child"] = {"level": i}
                current = current["child"]
            result = await w.submit(nested)
            assert result["queued"] is True
        finally:
            await w.stop()

    @pytest.mark.asyncio
    async def test_stop_idempotent(self):
        """Calling stop() multiple times doesn't crash."""
        w = MockEdgeWorker()
        await w.start()
        await w.stop()
        await w.stop()  # second call should be harmless

    @pytest.mark.asyncio
    async def test_submit_after_stop_raises(self):
        """Submitting after stop doesn't queue (worker not running)."""
        w = MockEdgeWorker(max_queue_size=5)
        await w.start()
        await w.stop()
        # Queue still accepts puts (asyncio.Queue doesn't know about _running),
        # but no dispatchers to process. Just verify no crash.
        result = await w.submit(_make_msg(0))
        assert result["queued"] is True

    def test_worker_stats_defaults(self):
        """WorkerStats initializes with zeros."""
        stats = WorkerStats()
        assert stats.messages_received == 0
        assert stats.messages_forwarded == 0
        assert stats.batches_sent == 0
        assert stats.errors == 0
        assert stats.start_time > 0

    @pytest.mark.asyncio
    async def test_queue_fifo_ordering(self):
        """Messages are processed in FIFO order within a single dispatcher."""
        w = MockEdgeWorker(
            batch_size=100,  # high — all messages in one batch
            num_dispatchers=1,
            batch_timeout_ms=100,
        )
        await w.start()
        try:
            for i in range(10):
                await w.submit(_make_msg(i))
            await asyncio.sleep(0.4)

            if w.batches_sent_log:
                first_batch = w.batches_sent_log[0]
                ids = [m["id"] for m in first_batch]
                assert ids == list(range(10))
        finally:
            await w.stop()
