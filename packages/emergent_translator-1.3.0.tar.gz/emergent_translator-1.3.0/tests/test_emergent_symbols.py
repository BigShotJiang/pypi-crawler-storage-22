"""Tests for EmergentSymbolEncoder encode/decode round-trips."""

import struct
import zlib

import pytest

from emergent_translator.emergent_symbols import (
    EmergentSymbolEncoder,
    EncodedMessage,
    DecodedMessage,
    SymbolFamily,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def encoder():
    return EmergentSymbolEncoder()


@pytest.fixture
def encoder_no_zlib():
    return EmergentSymbolEncoder(enable_zlib=False)


# ---------------------------------------------------------------------------
# Init / Stats
# ---------------------------------------------------------------------------


class TestInit:
    def test_defaults(self, encoder):
        assert encoder.enable_zlib is True
        assert encoder._encoding_stats["encoded"] == 0

    def test_no_zlib(self, encoder_no_zlib):
        assert encoder_no_zlib.enable_zlib is False


class TestStats:
    def test_stats_empty(self, encoder):
        stats = encoder.get_stats()
        assert stats["encoded"] == 0
        assert stats["total_original"] == 0
        assert stats["total_compressed"] == 0
        assert "overall_ratio" not in stats

    def test_stats_after_encode(self, encoder):
        encoder.encode({"role": "user", "content": "hello"})
        stats = encoder.get_stats()
        assert stats["encoded"] == 1
        assert stats["total_original"] > 0
        assert stats["total_compressed"] > 0
        assert "overall_ratio" in stats
        assert "overall_savings_pct" in stats


# ---------------------------------------------------------------------------
# Dict encode / decode round-trips
# ---------------------------------------------------------------------------


class TestDictRoundTrip:
    def test_simple_dict(self, encoder):
        data = {"task": "hello", "priority": "high"}
        encoded = encoder.encode(data)
        decoded = encoder.decode(encoded.symbols)
        assert decoded.success
        assert decoded.data == data

    def test_nested_dict(self, encoder):
        data = {
            "agent": {"id": "trader", "version": "2.0"},
            "task": {"type": "optimization", "priority": "high"},
        }
        encoded = encoder.encode(data)
        decoded = encoder.decode(encoded.symbols)
        assert decoded.success
        assert decoded.data == data

    def test_common_keys(self, encoder):
        data = {"role": "user", "content": "hello", "status": "active"}
        encoded = encoder.encode(data)
        decoded = encoder.decode(encoded.symbols)
        assert decoded.success
        assert decoded.data == data

    def test_common_values(self, encoder):
        data = {"role": "user", "status": "pending", "priority": "high"}
        encoded = encoder.encode(data)
        decoded = encoder.decode(encoded.symbols)
        assert decoded.success
        assert decoded.data == data

    def test_list_values(self, encoder):
        data = {"participants": ["agent_1", "agent_2", "agent_3"]}
        encoded = encoder.encode(data)
        decoded = encoder.decode(encoded.symbols)
        assert decoded.success
        assert decoded.data == data

    def test_empty_list(self, encoder):
        data = {"items": []}
        encoded = encoder.encode(data)
        decoded = encoder.decode(encoded.symbols)
        assert decoded.success
        assert decoded.data == data

    def test_empty_dict_value(self, encoder):
        data = {"config": {}}
        encoded = encoder.encode(data)
        decoded = encoder.decode(encoded.symbols)
        assert decoded.success
        assert decoded.data == data

    def test_none_value(self, encoder):
        data = {"error": None}
        encoded = encoder.encode(data)
        decoded = encoder.decode(encoded.symbols)
        assert decoded.success
        assert decoded.data == data

    def test_bool_values(self, encoder):
        data = {"active": True, "deleted": False}
        encoded = encoder.encode(data)
        decoded = encoder.decode(encoded.symbols)
        assert decoded.success
        assert decoded.data == data

    def test_int_values(self, encoder):
        data = {"small": 42, "negative": -10, "medium": 1000, "large": 100000}
        encoded = encoder.encode(data)
        decoded = encoder.decode(encoded.symbols)
        assert decoded.success
        assert decoded.data == data

    def test_float_value(self, encoder):
        data = {"confidence": 0.85}
        encoded = encoder.encode(data)
        decoded = encoder.decode(encoded.symbols)
        assert decoded.success
        assert abs(decoded.data["confidence"] - 0.85) < 0.001

    def test_complex_payload(self, encoder):
        data = {
            "coordination": {
                "request_id": "coord_abc123",
                "initiator": "orchestrator",
                "participants": ["agent_1", "agent_2", "agent_3"],
            }
        }
        encoded = encoder.encode(data)
        decoded = encoder.decode(encoded.symbols)
        assert decoded.success
        assert decoded.data == data

    def test_no_zlib(self, encoder_no_zlib):
        data = {"role": "user", "content": "hello world this is a test message"}
        encoded = encoder_no_zlib.encode(data)
        decoded = encoder_no_zlib.decode(encoded.symbols)
        assert decoded.success
        assert decoded.data == data


# ---------------------------------------------------------------------------
# Text encode / decode
# ---------------------------------------------------------------------------


class TestTextRoundTrip:
    def test_plain_text(self, encoder):
        text = "Hello, this is a plain text message."
        encoded = encoder.encode(text)
        decoded = encoder.decode(encoded.symbols)
        assert decoded.success
        assert decoded.data == text
        assert "text" in decoded.symbol_families

    def test_long_text(self, encoder):
        text = "The quick brown fox jumps over the lazy dog. " * 20
        encoded = encoder.encode(text)
        decoded = encoder.decode(encoded.symbols)
        assert decoded.success
        assert decoded.data == text

    def test_json_string_parsed(self, encoder):
        import json
        data = {"key": "value"}
        encoded = encoder.encode(json.dumps(data))
        decoded = encoder.decode(encoded.symbols)
        assert decoded.success
        assert decoded.data == data


# ---------------------------------------------------------------------------
# Primitive encode / decode
# ---------------------------------------------------------------------------


class TestPrimitiveRoundTrip:
    def test_integer(self, encoder):
        encoded = encoder.encode(42)
        decoded = encoder.decode(encoded.symbols)
        assert decoded.success
        assert decoded.data == 42
        assert "primitive" in decoded.symbol_families

    def test_float(self, encoder):
        encoded = encoder.encode(3.14)
        decoded = encoder.decode(encoded.symbols)
        assert decoded.success
        assert abs(decoded.data - 3.14) < 0.01

    def test_boolean(self, encoder):
        encoded = encoder.encode(True)
        decoded = encoder.decode(encoded.symbols)
        assert decoded.success
        assert decoded.data is True


# ---------------------------------------------------------------------------
# Intent detection
# ---------------------------------------------------------------------------


class TestIntentDetection:
    def test_swarm_by_coordination_key(self, encoder):
        data = {"coordination": {"agents": ["a1", "a2"]}}
        _, families = encoder._detect_intent(data)
        assert "swarm" in families

    def test_swarm_by_agents_key(self, encoder):
        data = {"agents": ["a1", "a2"]}
        _, families = encoder._detect_intent(data)
        assert "swarm" in families

    def test_swarm_by_agent_key(self, encoder):
        data = {"agent": "coordinator"}
        _, families = encoder._detect_intent(data)
        assert "swarm" in families

    def test_work_by_task_key(self, encoder):
        data = {"task": "analyze market"}
        _, families = encoder._detect_intent(data)
        assert "work" in families

    def test_work_by_analyze_value(self, encoder):
        data = {"action": "analyze trends"}
        intent, families = encoder._detect_intent(data)
        assert "work" in families
        assert intent == int(SymbolFamily.WORK)

    def test_theta_intent(self, encoder):
        data = {"action": "allocate resource"}
        intent, families = encoder._detect_intent(data)
        assert "theta" in families

    def test_governance_intent(self, encoder):
        data = {"action": "governance vote proposal"}
        intent, families = encoder._detect_intent(data)
        assert "governance" in families

    def test_default_work(self, encoder):
        data = {"foo": "bar"}
        _, families = encoder._detect_intent(data)
        assert "work" in families

    def test_work_keyword_appended(self, encoder):
        data = {"coordination": True, "task": "optimize"}
        _, families = encoder._detect_intent(data)
        assert "swarm" in families
        assert "work" in families


# ---------------------------------------------------------------------------
# _flatten_strings
# ---------------------------------------------------------------------------


class TestFlattenStrings:
    def test_string(self, encoder):
        assert "hello " in encoder._flatten_strings("hello")

    def test_dict(self, encoder):
        result = encoder._flatten_strings({"key": "value"})
        assert "key" in result
        assert "value" in result

    def test_list(self, encoder):
        result = encoder._flatten_strings(["a", "b"])
        assert "a" in result
        assert "b" in result

    def test_nested(self, encoder):
        result = encoder._flatten_strings({"a": {"b": "deep"}})
        assert "deep" in result

    def test_none(self, encoder):
        result = encoder._flatten_strings(None)
        assert result == ""

    def test_depth_limit(self, encoder):
        result = encoder._flatten_strings("deep", depth=11)
        assert result == ""


# ---------------------------------------------------------------------------
# EncodedMessage metadata
# ---------------------------------------------------------------------------


class TestEncodedMessageMetadata:
    def test_encoded_message_fields(self, encoder):
        data = {"role": "user", "content": "hello"}
        result = encoder.encode(data)
        assert isinstance(result, EncodedMessage)
        assert result.original_size > 0
        assert result.encoded_size > 0
        assert 0 < result.compression_ratio <= 2.0
        assert len(result.symbol_families) > 0
        assert result.checksum > 0
        assert "intent" in result.metadata
        assert "key_count" in result.metadata

    def test_text_metadata(self, encoder):
        result = encoder.encode("plain text")
        assert result.metadata["type"] == "text"

    def test_primitive_metadata(self, encoder):
        result = encoder.encode(42)
        assert result.metadata["type"] == "int"


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------


class TestDecodeErrors:
    def test_too_short(self, encoder):
        result = encoder.decode(b'\x00\x01')
        assert not result.success
        assert "too short" in result.error

    def test_bad_checksum(self, encoder):
        data = {"role": "user"}
        encoded = encoder.encode(data)
        corrupted = encoded.symbols[:-1] + bytes([(encoded.symbols[-1] + 1) % 256])
        result = encoder.decode(corrupted)
        assert not result.success
        assert "Checksum" in result.error

    def test_bad_magic(self, encoder):
        bad = b'\x00\x00\xF0\x00\x00'
        checksum = zlib.crc32(bad) & 0xFFFFFFFF
        payload = bad + struct.pack('>I', checksum)
        result = encoder.decode(payload)
        assert not result.success
        assert "magic" in result.error.lower()


# ---------------------------------------------------------------------------
# Value encoding edge cases
# ---------------------------------------------------------------------------


class TestValueEdgeCases:
    def test_small_positive_int(self, encoder):
        data = {"val": 0}
        rt = encoder.decode(encoder.encode(data).symbols)
        assert rt.data["val"] == 0

    def test_negative_int(self, encoder):
        data = {"val": -50}
        rt = encoder.decode(encoder.encode(data).symbols)
        assert rt.data["val"] == -50

    def test_large_negative_int(self, encoder):
        data = {"val": -10000}
        rt = encoder.decode(encoder.encode(data).symbols)
        assert rt.data["val"] == -10000

    def test_large_int(self, encoder):
        data = {"val": 100000}
        rt = encoder.decode(encoder.encode(data).symbols)
        assert rt.data["val"] == 100000

    def test_long_string_value(self, encoder):
        long_str = "x" * 200
        data = {"description": long_str}
        rt = encoder.decode(encoder.encode(data).symbols)
        assert rt.data["description"] == long_str

    def test_medium_string_15(self, encoder):
        med_str = "a" * 15
        data = {"val": med_str}
        rt = encoder.decode(encoder.encode(data).symbols)
        assert rt.data["val"] == med_str

    def test_medium_string_16(self, encoder):
        med_str = "a" * 16
        data = {"val": med_str}
        rt = encoder.decode(encoder.encode(data).symbols)
        assert rt.data["val"] == med_str

    def test_medium_string_50(self, encoder):
        med_str = "b" * 50
        data = {"val": med_str}
        rt = encoder.decode(encoder.encode(data).symbols)
        assert rt.data["val"] == med_str

    def test_medium_string_63(self, encoder):
        med_str = "c" * 63
        data = {"val": med_str}
        rt = encoder.decode(encoder.encode(data).symbols)
        assert rt.data["val"] == med_str

    def test_custom_key(self, encoder):
        data = {"my_custom_key": "value"}
        rt = encoder.decode(encoder.encode(data).symbols)
        assert rt.data["my_custom_key"] == "value"

    def test_list_with_mixed_types(self, encoder):
        data = {"items": [1, "hello", True, None, 3.14]}
        rt = encoder.decode(encoder.encode(data).symbols)
        assert rt.success
        items = rt.data["items"]
        assert items[0] == 1
        assert items[1] == "hello"
        assert items[2] is True
        assert items[3] is None
        assert abs(items[4] - 3.14) < 0.01
