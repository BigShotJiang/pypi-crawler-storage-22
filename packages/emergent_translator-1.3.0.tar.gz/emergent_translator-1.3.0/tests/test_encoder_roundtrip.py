#!/usr/bin/env python3
"""Consolidated encoder round-trip tests.

Combines:
  - archived/test_batch_decoder.py (value, dict, batch round-trips)
  - archived/test_batch_encoder_edge.py (edge cases, header parsing, errors)
"""

import struct
import zlib

import pytest

from emergent_translator.batch_encoder import (
    BatchEncoder,
    BatchResult,
    COMMON_KEYS,
    COMMON_VALUES,
    COMMON_KEYS_REV,
    COMMON_VALUES_REV,
    SAMPLE_MESSAGES,
    encode_dict,
    encode_value,
    decode_dict,
    decode_value,
    encode_single,
)
from emergent_translator.gpu_batch_encoder import (
    GPUBatchEncoder,
    encode_dict_cpu,
    encode_value_cpu,
    decode_dict_cpu,
    decode_value_cpu,
    SAMPLE_MESSAGES as GPU_SAMPLE_MESSAGES,
)


# ─────────────────────────────────────────────────────────────────────────────
# Alias helpers (many-to-one mappings in COMMON_KEYS / COMMON_VALUES)
# ─────────────────────────────────────────────────────────────────────────────

def _build_aliases(mapping):
    aliases = {}
    seen = {}
    for k, vid in mapping.items():
        if vid in seen:
            aliases.setdefault(k, set()).add(seen[vid])
            aliases.setdefault(seen[vid], set()).add(k)
        else:
            seen[vid] = k
    return aliases


_KEY_ALIASES = _build_aliases(COMMON_KEYS)
_VALUE_ALIASES = _build_aliases(COMMON_VALUES)


def _keys_equivalent(orig_keys, decoded_keys):
    if orig_keys == decoded_keys:
        return True
    for k in orig_keys:
        if k in decoded_keys:
            continue
        aliases = _KEY_ALIASES.get(k, set())
        if not any(a in decoded_keys for a in aliases):
            return False
    return True


def _find_decoded_key(orig_key, decoded_dict):
    if orig_key in decoded_dict:
        return orig_key
    for alias in _KEY_ALIASES.get(orig_key, set()):
        if alias in decoded_dict:
            return alias
    return None


def _assert_messages_equal(orig: dict, decoded: dict):
    assert _keys_equivalent(set(orig.keys()), set(decoded.keys())), \
        f"Key mismatch: {orig.keys()} != {decoded.keys()}"
    for k in orig:
        dk = _find_decoded_key(k, decoded)
        assert dk is not None, f"Key {k!r} not found in decoded (even with aliases)"
        _assert_values_equal(orig[k], decoded[dk], path=k)


def _assert_values_equal(orig, decoded, path=""):
    if isinstance(orig, float):
        assert isinstance(decoded, (int, float)), f"At {path}: expected number, got {type(decoded)}"
        assert abs(float(orig) - float(decoded)) < 0.01, f"At {path}: {orig} != {decoded}"
    elif isinstance(orig, dict):
        assert isinstance(decoded, dict), f"At {path}: expected dict"
        _assert_messages_equal(orig, decoded)
    elif isinstance(orig, list):
        assert isinstance(decoded, list), f"At {path}: expected list"
        assert len(orig) == len(decoded), f"At {path}: list length {len(orig)} != {len(decoded)}"
        for i, (a, b) in enumerate(zip(orig, decoded)):
            _assert_values_equal(a, b, f"{path}[{i}]")
    elif isinstance(orig, str) and isinstance(decoded, str):
        if orig != decoded:
            aliases = _VALUE_ALIASES.get(orig, set())
            assert decoded in aliases, f"At {path}: {orig!r} != {decoded!r} (aliases={aliases!r})"
    else:
        assert orig == decoded, f"At {path}: {orig!r} != {decoded!r}"


# ═════════════════════════════════════════════════════════════════════════════
# Value-level round-trip tests (CPU functions)
# ═════════════════════════════════════════════════════════════════════════════

class TestDecodeValueCPU:
    @pytest.mark.parametrize("val", [None, True, False])
    def test_primitives(self, val):
        encoded = encode_value_cpu(val)
        decoded, consumed = decode_value_cpu(encoded)
        assert decoded == val
        assert consumed == len(encoded)

    @pytest.mark.parametrize("val", [0, 1, 42, 63, 64, 100, 127])
    def test_small_positive_ints(self, val):
        encoded = encode_value_cpu(val)
        decoded, consumed = decode_value_cpu(encoded)
        assert decoded == val
        assert consumed == len(encoded)

    @pytest.mark.parametrize("val", [-1, -50, -128])
    def test_negative_ints(self, val):
        encoded = encode_value_cpu(val)
        decoded, consumed = decode_value_cpu(encoded)
        assert decoded == val
        assert consumed == len(encoded)

    @pytest.mark.parametrize("val", [128, 255, 256, 1000, 65535])
    def test_medium_ints(self, val):
        encoded = encode_value_cpu(val)
        decoded, consumed = decode_value_cpu(encoded)
        assert decoded == val
        assert consumed == len(encoded)

    @pytest.mark.parametrize("val", [65536, 100000, 2**30, -1000, -100000])
    def test_large_ints(self, val):
        encoded = encode_value_cpu(val)
        decoded, consumed = decode_value_cpu(encoded)
        assert decoded == val
        assert consumed == len(encoded)

    def test_float(self):
        encoded = encode_value_cpu(3.14)
        decoded, consumed = decode_value_cpu(encoded)
        assert abs(decoded - 3.14) < 0.001
        assert consumed == len(encoded)

    def test_float_whole_number_encoded_as_int(self):
        encoded = encode_value_cpu(42.0)
        decoded, consumed = decode_value_cpu(encoded)
        assert decoded == 42

    @pytest.mark.parametrize("val", ["high", "low", "pending", "buy", "sell"])
    def test_common_values(self, val):
        encoded = encode_value_cpu(val)
        decoded, consumed = decode_value_cpu(encoded)
        assert decoded == val
        assert consumed == len(encoded)

    @pytest.mark.parametrize("val", ["hello", "abc", "x", ""])
    def test_short_strings(self, val):
        encoded = encode_value_cpu(val)
        decoded, consumed = decode_value_cpu(encoded)
        assert decoded == val
        assert consumed == len(encoded)

    def test_medium_string(self):
        val = "a" * 20
        encoded = encode_value_cpu(val)
        decoded, consumed = decode_value_cpu(encoded)
        assert decoded == val
        assert consumed == len(encoded)

    def test_long_string(self):
        val = "x" * 200
        encoded = encode_value_cpu(val)
        decoded, consumed = decode_value_cpu(encoded)
        assert decoded == val
        assert consumed == len(encoded)

    def test_empty_list(self):
        encoded = encode_value_cpu([])
        decoded, consumed = decode_value_cpu(encoded)
        assert decoded == []
        assert consumed == len(encoded)

    def test_list_of_ints(self):
        val = [1, 2, 3]
        encoded = encode_value_cpu(val)
        decoded, consumed = decode_value_cpu(encoded)
        assert decoded == val
        assert consumed == len(encoded)

    def test_list_of_strings(self):
        val = ["a1", "a2", "a3"]
        encoded = encode_value_cpu(val)
        decoded, consumed = decode_value_cpu(encoded)
        assert decoded == val
        assert consumed == len(encoded)

    def test_empty_dict(self):
        encoded = encode_value_cpu({})
        decoded, consumed = decode_value_cpu(encoded)
        assert decoded == {}
        assert consumed == len(encoded)

    def test_nested_dict(self):
        val = {"key": "val"}
        encoded = encode_dict_cpu(val)
        decoded, consumed = decode_dict_cpu(encoded)
        assert decoded == val
        assert consumed == len(encoded)


# ═════════════════════════════════════════════════════════════════════════════
# Value-level round-trip tests (batch_encoder functions)
# ═════════════════════════════════════════════════════════════════════════════

class TestDecodeValue:
    @pytest.mark.parametrize("val", [None, True, False, 0, 42, 127, -1, -128,
                                      256, 65535, 65536, "hello", "high", [],
                                      [1, 2], {}])
    def test_round_trip(self, val):
        encoded = encode_value(val)
        decoded, consumed = decode_value(encoded)
        assert decoded == val
        assert consumed == len(encoded)


# ═════════════════════════════════════════════════════════════════════════════
# Dict-level round-trip tests
# ═════════════════════════════════════════════════════════════════════════════

class TestDecodeDictCPU:
    def test_empty_dict(self):
        encoded = encode_dict_cpu({})
        decoded, consumed = decode_dict_cpu(encoded)
        assert decoded == {}
        assert consumed == len(encoded)

    def test_common_keys(self):
        d = {"task": "analyze", "priority": "high"}
        encoded = encode_dict_cpu(d)
        decoded, consumed = decode_dict_cpu(encoded)
        assert decoded == d

    def test_custom_keys(self):
        d = {"foo": "bar", "baz": 42}
        encoded = encode_dict_cpu(d)
        decoded, consumed = decode_dict_cpu(encoded)
        assert decoded == d

    def test_nested_dict(self):
        d = {"result": {"summary": "bullish", "confidence": 0.85}}
        encoded = encode_dict_cpu(d)
        decoded, consumed = decode_dict_cpu(encoded)
        assert decoded["result"]["summary"] == "bullish"
        assert abs(decoded["result"]["confidence"] - 0.85) < 0.001

    def test_dict_with_list(self):
        d = {"participants": ["a1", "a2", "a3"]}
        encoded = encode_dict_cpu(d)
        decoded, consumed = decode_dict_cpu(encoded)
        assert decoded == d

    def test_deeply_nested(self):
        d = {"a": {"b": {"c": {"d": 1}}}}
        encoded = encode_dict_cpu(d)
        decoded, consumed = decode_dict_cpu(encoded)
        assert decoded == d


# ═════════════════════════════════════════════════════════════════════════════
# Full batch round-trip tests (GPUBatchEncoder)
# ═════════════════════════════════════════════════════════════════════════════

class TestGPUBatchDecoder:
    def setup_method(self):
        self.encoder = GPUBatchEncoder(num_workers=2)

    def test_round_trip_sample_messages(self):
        result = self.encoder.encode_batch(GPU_SAMPLE_MESSAGES)
        decoded = self.encoder.decode_batch(result.payload)
        assert len(decoded) == len(GPU_SAMPLE_MESSAGES)
        for orig, dec in zip(GPU_SAMPLE_MESSAGES, decoded):
            _assert_messages_equal(orig, dec)

    def test_single_message(self):
        msgs = [{"task": "analyze", "priority": "high"}]
        result = self.encoder.encode_batch(msgs)
        decoded = self.encoder.decode_batch(result.payload)
        assert decoded == msgs

    def test_batch_10(self):
        msgs = GPU_SAMPLE_MESSAGES[:10]
        result = self.encoder.encode_batch(msgs)
        decoded = self.encoder.decode_batch(result.payload)
        assert len(decoded) == len(msgs)

    def test_batch_75(self):
        import random
        msgs = [random.choice(GPU_SAMPLE_MESSAGES) for _ in range(75)]
        result = self.encoder.encode_batch(msgs)
        decoded = self.encoder.decode_batch(result.payload)
        assert len(decoded) == 75

    def test_batch_100(self):
        import random
        msgs = [random.choice(GPU_SAMPLE_MESSAGES) for _ in range(100)]
        result = self.encoder.encode_batch(msgs)
        decoded = self.encoder.decode_batch(result.payload)
        assert len(decoded) == 100

    def test_invalid_magic(self):
        result = self.encoder.encode_batch(GPU_SAMPLE_MESSAGES[:1])
        bad = b'\x00\x00' + result.payload[2:]
        with pytest.raises(ValueError, match="CRC32 mismatch|Invalid magic"):
            self.encoder.decode_batch(bad)

    def test_corrupted_checksum(self):
        result = self.encoder.encode_batch(GPU_SAMPLE_MESSAGES[:1])
        bad = result.payload[:-4] + b'\x00\x00\x00\x00'
        with pytest.raises(ValueError, match="CRC32 mismatch"):
            self.encoder.decode_batch(bad)

    def test_truncated_payload(self):
        with pytest.raises((ValueError, struct.error)):
            self.encoder.decode_batch(b'\xE7\xB0\x02')

    def test_uncompressed_path(self):
        enc = GPUBatchEncoder(num_workers=1, compression_level=0)
        msgs = [{"a": 1}]
        result = enc.encode_batch(msgs)
        decoded = enc.decode_batch(result.payload)
        assert decoded == msgs


# ═════════════════════════════════════════════════════════════════════════════
# Full batch round-trip tests (BatchEncoder)
# ═════════════════════════════════════════════════════════════════════════════

class TestBatchDecoder:
    def setup_method(self):
        self.encoder = BatchEncoder()

    def test_round_trip_sample_messages(self):
        result = self.encoder.encode_batch(SAMPLE_MESSAGES)
        decoded = self.encoder.decode_batch(result.payload)
        assert len(decoded) == len(SAMPLE_MESSAGES)
        for orig, dec in zip(SAMPLE_MESSAGES, decoded):
            _assert_messages_equal(orig, dec)

    def test_single_message(self):
        msgs = [{"status": "pending"}]
        result = self.encoder.encode_batch(msgs)
        decoded = self.encoder.decode_batch(result.payload)
        assert decoded == msgs

    def test_batch_100(self):
        import random
        msgs = [random.choice(SAMPLE_MESSAGES) for _ in range(100)]
        result = self.encoder.encode_batch(msgs)
        decoded = self.encoder.decode_batch(result.payload)
        assert len(decoded) == 100

    def test_invalid_magic(self):
        result = self.encoder.encode_batch(SAMPLE_MESSAGES[:1])
        bad = b'\xFF\xFF' + result.payload[2:]
        with pytest.raises(ValueError):
            self.encoder.decode_batch(bad)

    def test_corrupted_checksum(self):
        result = self.encoder.encode_batch(SAMPLE_MESSAGES[:1])
        bad = result.payload[:-4] + b'\xDE\xAD\xBE\xEF'
        with pytest.raises(ValueError, match="CRC32 mismatch"):
            self.encoder.decode_batch(bad)

    def test_too_short(self):
        with pytest.raises(ValueError, match="too short"):
            self.encoder.decode_batch(b'\x00' * 5)


# ═════════════════════════════════════════════════════════════════════════════
# Edge cases (from test_batch_encoder_edge.py)
# ═════════════════════════════════════════════════════════════════════════════

class TestEncodeValueEdgeCases:
    def test_none(self):
        enc = encode_value(None)
        val, consumed = decode_value(enc, 0)
        assert val is None
        assert consumed == 1

    def test_bool_true(self):
        enc = encode_value(True)
        val, _ = decode_value(enc, 0)
        assert val is True

    def test_bool_false(self):
        enc = encode_value(False)
        val, _ = decode_value(enc, 0)
        assert val is False

    def test_small_int(self):
        for v in [0, 1, 42, 127]:
            enc = encode_value(v)
            val, _ = decode_value(enc, 0)
            assert val == v

    def test_negative_int(self):
        for v in [-1, -50, -128]:
            enc = encode_value(v)
            val, _ = decode_value(enc, 0)
            assert val == v

    def test_unsigned_short_int(self):
        for v in [128, 1000, 65535]:
            enc = encode_value(v)
            val, _ = decode_value(enc, 0)
            assert val == v

    def test_large_int(self):
        for v in [65536, 100000, -1000000]:
            enc = encode_value(v)
            val, _ = decode_value(enc, 0)
            assert val == v

    def test_float(self):
        enc = encode_value(3.14)
        val, _ = decode_value(enc, 0)
        assert abs(val - 3.14) < 0.01

    def test_float_whole_number(self):
        enc = encode_value(42.0)
        val, _ = decode_value(enc, 0)
        assert val == 42

    def test_common_value_string(self):
        for s in ["high", "low", "pending"]:
            enc = encode_value(s)
            val, _ = decode_value(enc, 0)
            assert val == s

    def test_short_string(self):
        for s in ["", "a", "hello", "x" * 15]:
            enc = encode_value(s)
            val, _ = decode_value(enc, 0)
            assert val == s

    def test_medium_string(self):
        s = "x" * 100
        enc = encode_value(s)
        val, _ = decode_value(enc, 0)
        assert val == s

    def test_empty_list(self):
        enc = encode_value([])
        val, _ = decode_value(enc, 0)
        assert val == []

    def test_list_with_elements(self):
        lst = ["a", 1, True, None]
        enc = encode_value(lst)
        val, _ = decode_value(enc, 0)
        assert val == lst

    def test_empty_dict(self):
        enc = encode_value({})
        val, _ = decode_value(enc, 0)
        assert val == {}

    def test_nested_dict(self):
        d = {"inner": {"key": "val"}}
        enc = encode_value(d)
        val, _ = decode_value(enc, 0)
        assert val == d

    def test_non_standard_type_fallback(self):
        enc = encode_value(object)
        val, _ = decode_value(enc, 0)
        assert isinstance(val, str)

    def test_unknown_marker_raises(self):
        with pytest.raises(ValueError, match="Unknown marker"):
            decode_value(bytes([0xFF]), 0)


class TestEncodeDictEdgeCases:
    def test_empty_dict(self):
        enc = encode_dict({})
        val, _ = decode_dict(enc, 0)
        assert val == {}

    def test_common_key(self):
        enc = encode_dict({"role": "user"})
        val, _ = decode_dict(enc, 0)
        assert val["role"] == "user"

    def test_custom_key(self):
        enc = encode_dict({"my_key": "val"})
        val, _ = decode_dict(enc, 0)
        assert val["my_key"] == "val"

    def test_invalid_marker(self):
        with pytest.raises(ValueError, match="Expected dict marker"):
            decode_dict(bytes([0x10, 0x00]), 0)


class TestEncodeSingle:
    def test_basic(self):
        data = {"role": "user", "content": "test"}
        payload, orig, comp = encode_single(data)
        assert payload[:2] == b'\xE7\x02'
        assert orig > 0
        assert comp > 0

    def test_compression_flag(self):
        data = {"content": "x" * 200}
        payload, _, _ = encode_single(data)
        flag = payload[2]
        assert flag in (0x00, 0x01)


class TestBatchEncoderHeader:
    def test_decode_header_v1(self):
        enc = BatchEncoder()
        result = enc.encode_batch([{"role": "user"}])
        header = enc.decode_batch_header(result.payload)
        assert header["version"] == 0x01
        assert header["message_count"] == 1
        assert "compressed" in header

    def test_decode_header_too_short(self):
        enc = BatchEncoder()
        header = enc.decode_batch_header(b'\x00')
        assert "error" in header

    def test_decode_header_bad_magic(self):
        enc = BatchEncoder()
        header = enc.decode_batch_header(b'\xFF\xFF' + b'\x00' * 20)
        assert "error" in header


class TestBatchDecodeErrors:
    def test_too_short(self):
        enc = BatchEncoder()
        with pytest.raises(ValueError, match="too short"):
            enc.decode_batch(b'\x00')

    def test_bad_crc(self):
        enc = BatchEncoder()
        result = enc.encode_batch([{"role": "user"}])
        corrupted = result.payload[:-4] + b'\xFF\xFF\xFF\xFF'
        with pytest.raises(ValueError, match="CRC32"):
            enc.decode_batch(corrupted)

    def test_bad_magic(self):
        enc = BatchEncoder()
        fake = b'\xFF\xFF\x01\x00\x01\x00' + b'\x00' * 10
        crc = zlib.crc32(fake) & 0xFFFFFFFF
        payload = fake + struct.pack('>I', crc)
        with pytest.raises(ValueError, match="magic"):
            enc.decode_batch(payload)

    def test_bad_version(self):
        enc = BatchEncoder()
        fake = b'\xE7\xB0\xFF\x00\x01\x00' + b'\x00' * 10
        crc = zlib.crc32(fake) & 0xFFFFFFFF
        payload = fake + struct.pack('>I', crc)
        with pytest.raises(ValueError, match="Unsupported version"):
            enc.decode_batch(payload)


class TestBatchRoundTrip:
    def test_multiple_messages(self):
        enc = BatchEncoder()
        messages = [
            {"role": "user", "content": "hello"},
            {"role": "assistant", "content": "hi there"},
            {"status": "complete", "result": {"value": 42}},
        ]
        result = enc.encode_batch(messages)
        decoded = enc.decode_batch(result.payload)
        assert len(decoded) == 3

    def test_result_fields(self):
        enc = BatchEncoder()
        result = enc.encode_batch([{"role": "user"}])
        assert isinstance(result, BatchResult)
        assert result.messages_encoded == 1
        assert result.original_bytes > 0
        assert result.compressed_bytes > 0
        assert result.encode_time_ms >= 0
        assert result.payload is not None


# ═════════════════════════════════════════════════════════════════════════════
# Integer boundary & cross-encoder edge cases
# ═════════════════════════════════════════════════════════════════════════════

class TestIntegerBoundaries:
    def test_int_boundary_127(self):
        encoded = encode_value_cpu(127)
        assert encoded[0] == 0x10
        decoded, _ = decode_value_cpu(encoded)
        assert decoded == 127

    def test_int_boundary_128(self):
        encoded = encode_value_cpu(128)
        assert encoded[0] == 0x12
        decoded, _ = decode_value_cpu(encoded)
        assert decoded == 128

    def test_int_negative_1(self):
        encoded = encode_value_cpu(-1)
        assert encoded[0] == 0x11
        decoded, _ = decode_value_cpu(encoded)
        assert decoded == -1

    def test_int_negative_128(self):
        encoded = encode_value_cpu(-128)
        assert encoded[0] == 0x11
        decoded, _ = decode_value_cpu(encoded)
        assert decoded == -128

    def test_int_negative_129(self):
        encoded = encode_value_cpu(-129)
        assert encoded[0] == 0x13
        decoded, _ = decode_value_cpu(encoded)
        assert decoded == -129

    def test_string_length_15(self):
        val = "a" * 15
        encoded = encode_value_cpu(val)
        assert encoded[0] == (0x30 | 15)
        decoded, _ = decode_value_cpu(encoded)
        assert decoded == val

    def test_string_length_16(self):
        val = "a" * 16
        encoded = encode_value_cpu(val)
        assert encoded[0] == 0x40
        decoded, _ = decode_value_cpu(encoded)
        assert decoded == val

    def test_no_marker_collision_int_values(self):
        for v in range(128):
            encoded = encode_value_cpu(v)
            assert len(encoded) == 2
            assert encoded[0] == 0x10


class TestCrossEncoderCompat:
    def test_cross_encoder_compatibility(self):
        be = BatchEncoder()
        ge = GPUBatchEncoder(num_workers=1)
        msgs = [{"task": "analyze", "priority": "high"}]

        be_result = be.encode_batch(msgs)
        ge_decoded = ge.decode_batch(be_result.payload)
        assert ge_decoded == msgs

        ge_result = ge.encode_batch(msgs)
        be_decoded = be.decode_batch(ge_result.payload)
        assert be_decoded == msgs
