"""Tests for GPUBatchEncoder (CPU path), streaming, stats, and decode."""

import struct
import zlib

import pytest

from emergent_translator.gpu_batch_encoder import (
    GPUBatchEncoder,
    GPUBatchResult,
    GPUChunkCompressor,
    encode_dict_cpu,
    decode_dict_cpu,
    encode_value_cpu,
    decode_value_cpu,
    encode_single_cpu,
    COMMON_KEYS,
    COMMON_VALUES,
    COMMON_KEYS_REV,
    COMMON_VALUES_REV,
    SAMPLE_MESSAGES,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def encoder():
    return GPUBatchEncoder(num_workers=2, use_gpu=False)


MESSAGES = [
    {"task": "analyze", "data": "market trends", "priority": "high"},
    {"agent_id": "agent_001", "task_type": "analysis", "status": "pending"},
    {"role": "user", "content": "hello world"},
]


# ---------------------------------------------------------------------------
# CPU encode / decode free functions
# ---------------------------------------------------------------------------


class TestCPUFunctions:
    def test_encode_decode_simple_dict(self):
        data = {"role": "user", "content": "hello"}
        encoded = encode_dict_cpu(data)
        decoded, _ = decode_dict_cpu(encoded, 0)
        assert decoded["role"] == "user"
        assert decoded["content"] == "hello"

    def test_encode_decode_nested(self):
        data = {"result": {"summary": "bullish", "confidence": 0.85}}
        encoded = encode_dict_cpu(data)
        decoded, _ = decode_dict_cpu(encoded, 0)
        assert decoded["result"]["summary"] == "bullish"

    def test_encode_single_cpu(self):
        data = {"task": "analyze", "priority": "high"}
        payload, orig_size, comp_size = encode_single_cpu(data)
        assert payload[:2] == b'\xE7\x02'
        assert orig_size > 0
        assert comp_size > 0

    def test_value_none(self):
        encoded = encode_value_cpu(None)
        val, consumed = decode_value_cpu(encoded, 0)
        assert val is None
        assert consumed == 1

    def test_value_bool(self):
        for v in (True, False):
            encoded = encode_value_cpu(v)
            val, _ = decode_value_cpu(encoded, 0)
            assert val is v

    def test_value_small_int(self):
        encoded = encode_value_cpu(42)
        val, _ = decode_value_cpu(encoded, 0)
        assert val == 42

    def test_value_negative_int(self):
        encoded = encode_value_cpu(-10)
        val, _ = decode_value_cpu(encoded, 0)
        assert val == -10

    def test_value_unsigned_short(self):
        encoded = encode_value_cpu(1000)
        val, _ = decode_value_cpu(encoded, 0)
        assert val == 1000

    def test_value_large_int(self):
        encoded = encode_value_cpu(100000)
        val, _ = decode_value_cpu(encoded, 0)
        assert val == 100000

    def test_value_float(self):
        encoded = encode_value_cpu(3.14)
        val, _ = decode_value_cpu(encoded, 0)
        assert abs(val - 3.14) < 0.01

    def test_value_float_as_int(self):
        encoded = encode_value_cpu(42.0)
        val, _ = decode_value_cpu(encoded, 0)
        assert val == 42

    def test_value_common_string(self):
        encoded = encode_value_cpu("high")
        val, _ = decode_value_cpu(encoded, 0)
        assert val == "high"

    def test_value_short_string(self):
        encoded = encode_value_cpu("abc")
        val, _ = decode_value_cpu(encoded, 0)
        assert val == "abc"

    def test_value_medium_string(self):
        s = "x" * 20
        encoded = encode_value_cpu(s)
        val, _ = decode_value_cpu(encoded, 0)
        assert val == s

    def test_value_empty_list(self):
        encoded = encode_value_cpu([])
        val, _ = decode_value_cpu(encoded, 0)
        assert val == []

    def test_value_list(self):
        encoded = encode_value_cpu(["a", "b"])
        val, _ = decode_value_cpu(encoded, 0)
        assert val == ["a", "b"]

    def test_value_empty_dict(self):
        encoded = encode_value_cpu({})
        val, _ = decode_value_cpu(encoded, 0)
        assert val == {}

    def test_value_dict(self):
        d = {"key": "val"}
        encoded = encode_value_cpu(d)
        val, _ = decode_value_cpu(encoded, 0)
        assert val == d

    def test_value_non_string_fallback(self):
        encoded = encode_value_cpu(object)
        val, _ = decode_value_cpu(encoded, 0)
        assert isinstance(val, str)


# ---------------------------------------------------------------------------
# GPUBatchEncoder — encode / decode round-trip
# ---------------------------------------------------------------------------


class TestGPUBatchEncoderRoundTrip:
    def test_basic_roundtrip(self, encoder):
        result = encoder.encode_batch(MESSAGES)
        assert isinstance(result, GPUBatchResult)
        assert result.messages_encoded == 3
        decoded = encoder.decode_batch(result.payload)
        assert len(decoded) == 3

    def test_single_message(self, encoder):
        msgs = [{"role": "user", "content": "test"}]
        result = encoder.encode_batch(msgs)
        decoded = encoder.decode_batch(result.payload)
        assert decoded[0]["role"] == "user"
        assert decoded[0]["content"] == "test"

    def test_large_batch(self, encoder):
        import random
        msgs = [random.choice(SAMPLE_MESSAGES) for _ in range(200)]
        result = encoder.encode_batch(msgs)
        decoded = encoder.decode_batch(result.payload)
        assert len(decoded) == 200

    def test_result_metrics(self, encoder):
        result = encoder.encode_batch(MESSAGES)
        assert result.original_bytes > 0
        assert result.compressed_bytes > 0
        assert 0 < result.compression_ratio <= 2.0
        assert result.encode_time_ms >= 0
        assert result.gpu_accelerated is False
        assert result.throughput_msg_per_sec > 0


# ---------------------------------------------------------------------------
# GPUBatchEncoder — decode_batch_header
# ---------------------------------------------------------------------------


class TestDecodeBatchHeader:
    def test_valid_header(self, encoder):
        result = encoder.encode_batch(MESSAGES)
        header = encoder.decode_batch_header(result.payload)
        assert header["version"] in (0x01, 0x02, 0x03)
        assert header["message_count"] == 3
        assert "compressed" in header
        assert header["payload_size"] == len(result.payload)

    def test_too_short(self, encoder):
        header = encoder.decode_batch_header(b'\x00\x01')
        assert "error" in header

    def test_bad_magic(self, encoder):
        header = encoder.decode_batch_header(b'\x00\x00' + b'\x00' * 20)
        assert "error" in header


# ---------------------------------------------------------------------------
# GPUBatchEncoder — decode_batch error cases
# ---------------------------------------------------------------------------


class TestDecodeBatchErrors:
    def test_too_short(self, encoder):
        with pytest.raises(ValueError, match="too short"):
            encoder.decode_batch(b'\x00\x01')

    def test_bad_crc(self, encoder):
        result = encoder.encode_batch(MESSAGES)
        corrupted = result.payload[:-4] + b'\x00\x00\x00\x00'
        with pytest.raises(ValueError, match="CRC32"):
            encoder.decode_batch(corrupted)

    def test_bad_magic(self, encoder):
        fake = b'\x00\x00\x02\x00\x01\x00' + b'\x00' * 10
        crc = zlib.crc32(fake) & 0xFFFFFFFF
        payload = fake + struct.pack('>I', crc)
        with pytest.raises(ValueError, match="magic"):
            encoder.decode_batch(payload)


# ---------------------------------------------------------------------------
# GPUBatchEncoder — encode_stream
# ---------------------------------------------------------------------------


class TestEncodeStream:
    def test_streaming(self, encoder):
        messages = [{"task": "analyze", "priority": "high"}] * 200
        results = list(encoder.encode_stream(iter(messages), batch_size=75))
        assert len(results) == 3
        assert results[0].messages_encoded == 75
        assert results[1].messages_encoded == 75
        assert results[2].messages_encoded == 50

    def test_stream_callback(self, encoder):
        messages = [{"task": "test"}] * 100
        callback_results = []
        list(encoder.encode_stream(
            iter(messages),
            batch_size=50,
            callback=lambda r: callback_results.append(r),
        ))
        assert len(callback_results) == 2

    def test_stream_partial_batch(self, encoder):
        messages = [{"task": "test"}] * 10
        results = list(encoder.encode_stream(iter(messages), batch_size=100))
        assert len(results) == 1
        assert results[0].messages_encoded == 10


# ---------------------------------------------------------------------------
# GPUBatchEncoder — get_stats / close
# ---------------------------------------------------------------------------


class TestEncoderStats:
    def test_stats(self, encoder):
        encoder.encode_batch(MESSAGES)
        stats = encoder.get_stats()
        assert stats["total_encoded"] == 3
        assert stats["total_time_ms"] > 0
        assert stats["throughput_msg_per_sec"] > 0
        assert stats["gpu_available"] is not None
        assert stats["gpu_enabled"] is False
        assert stats["num_workers"] == 2

    def test_close(self, encoder):
        encoder.close()


# ---------------------------------------------------------------------------
# GPUChunkCompressor
# ---------------------------------------------------------------------------


class TestGPUChunkCompressor:
    def test_compress_batch(self):
        import asyncio

        compressor = GPUChunkCompressor(encoder=GPUBatchEncoder(num_workers=2, use_gpu=False))
        chunks = [{"data": msg} for msg in MESSAGES]
        results = asyncio.get_event_loop().run_until_complete(
            compressor.compress_batch(chunks)
        )
        assert len(results) == 3
        for chunk, payload, meta in results:
            assert isinstance(payload, bytes)
            assert "batch_index" in meta
            assert "compression_ratio" in meta

    def test_stats(self):
        import asyncio

        compressor = GPUChunkCompressor(encoder=GPUBatchEncoder(num_workers=2, use_gpu=False))
        chunks = [{"data": msg} for msg in MESSAGES]
        asyncio.get_event_loop().run_until_complete(
            compressor.compress_batch(chunks)
        )
        stats = compressor.get_stats()
        assert stats["batches_processed"] == 1
        assert stats["messages_compressed"] == 3
        assert stats["bytes_saved"] > 0
        assert "encoder_stats" in stats


# ---------------------------------------------------------------------------
# min_embed_messages threshold
# ---------------------------------------------------------------------------


class TestMinEmbedMessages:
    def test_small_batch_skips_codebook_embedding(self):
        """Batches below min_embed_messages produce v2 (no codebook header)."""
        from emergent_translator.adaptive_codebook import AdaptiveCodebook

        cb = AdaptiveCodebook()
        # Train the codebook
        training = [{"role": "user", "content": "hello"}] * 50
        for i in range(0, 50, 10):
            cb.observe(training[i:i + 10])
        cb.rebuild(min_frequency=1)

        enc = GPUBatchEncoder(num_workers=2, use_gpu=False, codebook=cb, min_embed_messages=10)
        # 5 messages — below threshold, should produce v2
        small_result = enc.encode_batch([{"role": "user", "content": "hi"}] * 5)
        # v2 header: magic(2) + version(1) + count(2) + flags(1) = 6 bytes
        assert small_result.payload[2] == 0x02  # v2 version byte

        decoded = enc.decode_batch(small_result.payload)
        assert len(decoded) == 5

    def test_large_batch_embeds_codebook(self):
        """Batches at or above min_embed_messages produce v3 (codebook embedded)."""
        from emergent_translator.adaptive_codebook import AdaptiveCodebook

        cb = AdaptiveCodebook()
        training = [{"role": "user", "content": "hello"}] * 50
        for i in range(0, 50, 10):
            cb.observe(training[i:i + 10])
        cb.rebuild(min_frequency=1)

        enc = GPUBatchEncoder(num_workers=2, use_gpu=False, codebook=cb, min_embed_messages=10)
        # 10 messages — at threshold, should produce v3
        large_result = enc.encode_batch([{"role": "user", "content": "hi"}] * 10)
        assert large_result.payload[2] == 0x03  # v3 version byte

        decoded = enc.decode_batch(large_result.payload)
        assert len(decoded) == 10

    def test_roundtrip_both_paths(self):
        """Both v2 and v3 paths produce correct round-trips."""
        from emergent_translator.adaptive_codebook import AdaptiveCodebook

        cb = AdaptiveCodebook()
        training = [{"role": "user", "content": "analyze", "priority": "high"}] * 50
        for i in range(0, 50, 10):
            cb.observe(training[i:i + 10])
        cb.rebuild(min_frequency=1)

        enc = GPUBatchEncoder(num_workers=2, use_gpu=False, codebook=cb, min_embed_messages=15)
        msgs = [{"role": "user", "content": "test", "priority": "high"}]

        # Below threshold (v2 path)
        r_small = enc.encode_batch(msgs * 5)
        d_small = enc.decode_batch(r_small.payload)
        assert len(d_small) == 5

        # Above threshold (v3 path)
        r_large = enc.encode_batch(msgs * 20)
        d_large = enc.decode_batch(r_large.payload)
        assert len(d_large) == 20
