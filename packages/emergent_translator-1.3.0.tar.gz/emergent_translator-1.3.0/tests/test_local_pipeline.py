"""Tests for LocalPipeline and LocalPipelineSync."""

import asyncio
import os

import pytest

from emergent_translator.local_pipeline import LocalPipeline, LocalPipelineSync
from emergent_translator.adaptive_codebook import AdaptiveCodebook
from emergent_translator.gpu_batch_encoder import GPUBatchResult


# ---------------------------------------------------------------------------
# Shared constants / fixtures
# ---------------------------------------------------------------------------

FAST_KWARGS = dict(use_gpu=False, num_workers=2, batch_size=5, batch_timeout_ms=50)

MESSAGES = [
    {"role": "user", "content": "hello"},
    {"task": "analyze", "priority": "high"},
    {"status": "running", "agent_id": "a1"},
]


@pytest.fixture
def pipeline_kwargs():
    return dict(FAST_KWARGS)


# ---------------------------------------------------------------------------
# TestLocalPipelineLifecycle
# ---------------------------------------------------------------------------


class TestLocalPipelineLifecycle:
    @pytest.mark.asyncio
    async def test_context_manager(self):
        async with LocalPipeline(**FAST_KWARGS) as p:
            assert p._running is True
        assert p._running is False

    @pytest.mark.asyncio
    async def test_start_stop_idempotent(self):
        p = LocalPipeline(**FAST_KWARGS)
        await p.start()
        await p.start()  # second call is a no-op
        assert p._running is True
        await p.stop()
        await p.stop()  # second call is a no-op
        assert p._running is False

    @pytest.mark.asyncio
    async def test_stop_flushes_remaining(self):
        batches = []

        async with LocalPipeline(**FAST_KWARGS, on_batch_ready=lambda r: batches.append(r)) as p:
            for msg in MESSAGES:
                await p.add(msg)
            # Don't drain — stop should flush

        total = sum(b.messages_encoded for b in batches)
        assert total == len(MESSAGES)


# ---------------------------------------------------------------------------
# TestLocalPipelineAdd
# ---------------------------------------------------------------------------


class TestLocalPipelineAdd:
    @pytest.mark.asyncio
    async def test_add_and_drain(self):
        async with LocalPipeline(**FAST_KWARGS) as p:
            await p.add({"role": "user", "content": "hi"})
            await p.drain()
            stats = p.get_stats()
            assert stats["collector"]["messages_collected"] == 1

    @pytest.mark.asyncio
    async def test_add_many(self):
        async with LocalPipeline(**FAST_KWARGS) as p:
            await p.add_many(MESSAGES)
            await p.drain()
            assert p.get_stats()["collector"]["messages_collected"] == len(MESSAGES)

    @pytest.mark.asyncio
    async def test_add_awaitable_future_resolves(self):
        async with LocalPipeline(**FAST_KWARGS) as p:
            fut = await p.add_awaitable({"role": "user", "content": "await me"})
            await p.drain()
            result = fut.result()
            assert isinstance(result, GPUBatchResult)
            assert result.messages_encoded >= 1

    @pytest.mark.asyncio
    async def test_add_after_stop_raises(self):
        p = LocalPipeline(**FAST_KWARGS)
        await p.start()
        await p.stop()
        with pytest.raises(RuntimeError):
            await p.add({"role": "user", "content": "too late"})


# ---------------------------------------------------------------------------
# TestLocalPipelineEncode
# ---------------------------------------------------------------------------


class TestLocalPipelineEncode:
    @pytest.mark.asyncio
    async def test_encode_decode_roundtrip(self):
        async with LocalPipeline(**FAST_KWARGS) as p:
            result = p.encode(MESSAGES)
            assert isinstance(result, GPUBatchResult)
            assert result.messages_encoded == len(MESSAGES)

            decoded = p.decode(result.payload)
            assert len(decoded) == len(MESSAGES)
            for orig, dec in zip(MESSAGES, decoded):
                for k in orig:
                    assert dec[k.lower()] == orig[k] or dec.get(k) == orig[k]

    @pytest.mark.asyncio
    async def test_encode_stream(self):
        async with LocalPipeline(**FAST_KWARGS) as p:
            batches = list(p.encode_stream(iter(MESSAGES * 5), batch_size=3))
            total = sum(b.messages_encoded for b in batches)
            assert total == len(MESSAGES) * 5

    def test_encode_without_context_manager(self):
        """encode/decode work without start() since they bypass the collector."""
        p = LocalPipeline(**FAST_KWARGS)
        result = p.encode(MESSAGES)
        decoded = p.decode(result.payload)
        assert len(decoded) == len(MESSAGES)


# ---------------------------------------------------------------------------
# TestLocalPipelineAdaptive
# ---------------------------------------------------------------------------


class TestLocalPipelineAdaptive:
    @pytest.mark.asyncio
    async def test_no_codebook_by_default(self):
        async with LocalPipeline(**FAST_KWARGS) as p:
            assert p.codebook is None

    @pytest.mark.asyncio
    async def test_adaptive_creates_codebook(self):
        async with LocalPipeline(**FAST_KWARGS, adaptive=True) as p:
            assert p.codebook is not None
            assert isinstance(p.codebook, AdaptiveCodebook)

    @pytest.mark.asyncio
    async def test_explicit_codebook(self):
        cb = AdaptiveCodebook()
        async with LocalPipeline(**FAST_KWARGS, codebook=cb) as p:
            assert p.codebook is cb

    @pytest.mark.asyncio
    async def test_auto_rebuild(self):
        """Codebook auto-rebuilds after codebook_rebuild_interval messages."""
        async with LocalPipeline(
            **FAST_KWARGS,
            adaptive=True,
            codebook_rebuild_interval=5,
        ) as p:
            initial_version = p.codebook.get_active().version
            # Send enough messages to trigger rebuild
            for _ in range(10):
                await p.add({"role": "user", "content": "hello"})
            await p.drain()
            assert p.codebook.get_active().version > initial_version

    @pytest.mark.asyncio
    async def test_manual_rebuild(self):
        async with LocalPipeline(**FAST_KWARGS, adaptive=True) as p:
            p.encode([{"role": "user", "content": "hello"}] * 20)
            result = p.rebuild_codebook(min_frequency=1)
            assert result is not None
            assert result.version >= 1

    @pytest.mark.asyncio
    async def test_rebuild_without_codebook_returns_none(self):
        async with LocalPipeline(**FAST_KWARGS) as p:
            assert p.rebuild_codebook() is None


# ---------------------------------------------------------------------------
# TestLocalPipelineChunkCollector
# ---------------------------------------------------------------------------


class TestLocalPipelineChunkCollector:
    @pytest.mark.asyncio
    async def test_no_workers_no_collector(self):
        async with LocalPipeline(**FAST_KWARGS) as p:
            assert p.has_chunk_collector is False

    @pytest.mark.asyncio
    async def test_submit_file_without_workers_raises(self):
        async with LocalPipeline(**FAST_KWARGS) as p:
            with pytest.raises(RuntimeError, match="No ChunkCollector configured"):
                await p.submit_file(b"data", "transform")

    @pytest.mark.asyncio
    async def test_get_result_without_workers_raises(self):
        async with LocalPipeline(**FAST_KWARGS) as p:
            with pytest.raises(RuntimeError, match="No ChunkCollector configured"):
                await p.get_result("fake-job-id")

    @pytest.mark.asyncio
    async def test_get_job_status_without_workers_raises(self):
        async with LocalPipeline(**FAST_KWARGS) as p:
            with pytest.raises(RuntimeError, match="No ChunkCollector configured"):
                p.get_job_status("fake-job-id")


# ---------------------------------------------------------------------------
# TestLocalPipelineStats
# ---------------------------------------------------------------------------


class TestLocalPipelineStats:
    @pytest.mark.asyncio
    async def test_stats_structure(self):
        async with LocalPipeline(**FAST_KWARGS) as p:
            stats = p.get_stats()
            assert "encoder" in stats
            assert "collector" in stats
            assert "running" in stats
            assert stats["running"] is True
            # No codebook or chunk_collector keys by default
            assert "codebook" not in stats
            assert "chunk_collector" not in stats

    @pytest.mark.asyncio
    async def test_stats_with_codebook(self):
        async with LocalPipeline(**FAST_KWARGS, adaptive=True) as p:
            stats = p.get_stats()
            assert "codebook" in stats
            assert "active_version" in stats["codebook"]

    @pytest.mark.asyncio
    async def test_pending_count(self):
        async with LocalPipeline(**FAST_KWARGS) as p:
            assert p.pending_count >= 0


# ---------------------------------------------------------------------------
# TestLocalPipelineSync
# ---------------------------------------------------------------------------


class TestLocalPipelineSync:
    def test_context_manager(self):
        with LocalPipelineSync(**FAST_KWARGS) as p:
            assert p.get_stats()["running"] is True
        # After exit, pipeline is stopped
        assert p._pipeline is None

    def test_encode_roundtrip(self):
        with LocalPipelineSync(**FAST_KWARGS) as p:
            result = p.encode(MESSAGES)
            assert result.messages_encoded == len(MESSAGES)
            decoded = p.decode(result.payload)
            assert len(decoded) == len(MESSAGES)

    def test_add_and_drain(self):
        with LocalPipelineSync(**FAST_KWARGS) as p:
            for msg in MESSAGES:
                p.add(msg)
            p.drain()
            stats = p.get_stats()
            assert stats["collector"]["messages_collected"] == len(MESSAGES)

    def test_add_many_and_drain(self):
        with LocalPipelineSync(**FAST_KWARGS) as p:
            p.add_many(MESSAGES)
            p.drain()
            assert p.get_stats()["collector"]["messages_collected"] == len(MESSAGES)

    def test_encode_stream(self):
        with LocalPipelineSync(**FAST_KWARGS) as p:
            batches = list(p.encode_stream(iter(MESSAGES * 3), batch_size=3))
            total = sum(b.messages_encoded for b in batches)
            assert total == len(MESSAGES) * 3

    def test_stats(self):
        with LocalPipelineSync(**FAST_KWARGS) as p:
            stats = p.get_stats()
            assert "encoder" in stats
            assert stats["running"] is True

    def test_no_chunk_collector(self):
        with LocalPipelineSync(**FAST_KWARGS) as p:
            assert p.has_chunk_collector is False

    def test_adaptive(self):
        with LocalPipelineSync(**FAST_KWARGS, adaptive=True) as p:
            assert p.codebook is not None
            p.encode([{"role": "user", "content": "hello"}] * 20)
            result = p.rebuild_codebook(min_frequency=1)
            assert result is not None


# ---------------------------------------------------------------------------
# TestLocalPipelineDefaults
# ---------------------------------------------------------------------------


class TestLocalPipelineDefaults:
    def test_default_values(self):
        p = LocalPipeline()
        # Encoder defaults
        assert p._encoder.num_workers == 8
        assert p._encoder.compression_level == 6
        # Collector defaults
        assert p._collector._batch_size == 75
        assert p._collector._batch_timeout_ms == 25.0
        # Codebook
        assert p._codebook is None
        assert p._codebook_rebuild_interval == 1000
        # Chunk collector
        assert p._chunk_collector is None
        assert p.has_chunk_collector is False
        assert p._running is False


# ---------------------------------------------------------------------------
# TestLocalPipelineCodebookPersistence
# ---------------------------------------------------------------------------


class TestLocalPipelineCodebookPersistence:
    @pytest.mark.asyncio
    async def test_save_on_stop(self, tmp_path):
        """Codebook is saved to disk when the pipeline stops."""
        cb_file = str(tmp_path / "codebook.json")
        async with LocalPipeline(**FAST_KWARGS, adaptive=True, codebook_path=cb_file) as p:
            p.encode([{"role": "user", "content": "hello"}] * 20)
            p.rebuild_codebook(min_frequency=1)
        assert os.path.exists(cb_file)

    @pytest.mark.asyncio
    async def test_load_on_start(self, tmp_path):
        """Codebook is loaded from disk when the pipeline starts."""
        cb_file = str(tmp_path / "codebook.json")

        # First run: train and save
        async with LocalPipeline(**FAST_KWARGS, adaptive=True, codebook_path=cb_file) as p:
            p.encode([{"role": "user", "content": "hello"}] * 20)
            p.rebuild_codebook(min_frequency=1)
            saved_version = p.codebook.get_active().version

        # Second run: should load the saved codebook
        async with LocalPipeline(**FAST_KWARGS, adaptive=True, codebook_path=cb_file) as p:
            loaded_version = p.codebook.get_active().version
            assert loaded_version == saved_version

    @pytest.mark.asyncio
    async def test_roundtrip_with_persistence(self, tmp_path):
        """Encode with trained codebook, save, load in new pipeline, decode."""
        cb_file = str(tmp_path / "codebook.json")
        msgs = [{"role": "user", "content": "hello", "priority": "high"}] * 10

        # Train and encode
        async with LocalPipeline(**FAST_KWARGS, adaptive=True, codebook_path=cb_file) as p:
            p.encode(msgs * 5)
            p.rebuild_codebook(min_frequency=1)
            result = p.encode(msgs)
            payload = result.payload

        # Load in fresh pipeline and decode
        async with LocalPipeline(**FAST_KWARGS, adaptive=True, codebook_path=cb_file) as p:
            decoded = p.decode(payload)
            assert len(decoded) == len(msgs)

    @pytest.mark.asyncio
    async def test_no_file_start_ok(self, tmp_path):
        """Starting with a nonexistent codebook_path doesn't crash."""
        cb_file = str(tmp_path / "nonexistent.json")
        async with LocalPipeline(**FAST_KWARGS, adaptive=True, codebook_path=cb_file) as p:
            assert p.codebook is not None
            # Version should be baseline (0)
            assert p.codebook.get_active().version == 0

    @pytest.mark.asyncio
    async def test_explicit_codebook_with_path(self, tmp_path):
        """Explicit codebook + codebook_path wires persistence."""
        cb_file = str(tmp_path / "codebook.json")
        cb = AdaptiveCodebook()
        async with LocalPipeline(**FAST_KWARGS, codebook=cb, codebook_path=cb_file) as p:
            p.encode([{"role": "user", "content": "hello"}] * 20)
            p.rebuild_codebook(min_frequency=1)
        assert os.path.exists(cb_file)

    def test_sync_persistence(self, tmp_path):
        """Codebook persistence works via LocalPipelineSync too."""
        cb_file = str(tmp_path / "codebook.json")

        with LocalPipelineSync(**FAST_KWARGS, adaptive=True, codebook_path=cb_file) as p:
            p.encode([{"role": "user", "content": "hello"}] * 20)
            p.rebuild_codebook(min_frequency=1)
            saved_version = p.codebook.get_active().version

        assert os.path.exists(cb_file)

        with LocalPipelineSync(**FAST_KWARGS, adaptive=True, codebook_path=cb_file) as p:
            assert p.codebook.get_active().version == saved_version
