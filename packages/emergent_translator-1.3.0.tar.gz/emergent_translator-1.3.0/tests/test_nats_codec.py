"""Tests for EmergentCodec (NATS-compatible theta codec)."""

import pytest

from emergent_translator.nats_codec import EmergentCodec


# ── Single message round-trip ──────────────────────────────────────────

class TestSingleMessage:
    def test_simple_dict(self):
        codec = EmergentCodec()
        msg = {"task": "analyze", "priority": "high", "status": "pending"}
        assert codec.decode(codec.encode(msg)) == msg

    def test_empty_dict(self):
        codec = EmergentCodec()
        msg = {}
        assert codec.decode(codec.encode(msg)) == msg

    def test_nested_dict(self):
        codec = EmergentCodec()
        msg = {"result": {"summary": "bullish", "confidence": 0.85}}
        decoded = codec.decode(codec.encode(msg))
        assert decoded["result"]["summary"] == "bullish"
        assert abs(decoded["result"]["confidence"] - 0.85) < 0.01

    def test_list_values(self):
        codec = EmergentCodec()
        msg = {"agents": ["a1", "a2", "a3"]}
        assert codec.decode(codec.encode(msg)) == msg

    def test_all_value_types(self):
        codec = EmergentCodec()
        msg = {
            "name": "test",
            "count": 42,
            "rate": 3.14,
            "active": True,
            "error": False,
            "data": None,
        }
        decoded = codec.decode(codec.encode(msg))
        assert decoded["name"] == "test"
        assert decoded["count"] == 42
        assert abs(decoded["rate"] - 3.14) < 0.01
        assert decoded["active"] is True
        assert decoded["error"] is False
        assert decoded["data"] is None


# ── Batch round-trip ───────────────────────────────────────────────────

class TestBatch:
    def test_batch_round_trip(self):
        codec = EmergentCodec()
        msgs = [
            {"task": "analyze", "priority": "high"},
            {"status": "pending", "result": {"value": 42}},
            {"agent_id": "a1", "task_type": "execution"},
        ]
        decoded = codec.decode_batch(codec.encode_batch(msgs))
        assert len(decoded) == len(msgs)
        for orig, dec in zip(msgs, decoded):
            assert dec == orig

    def test_single_item_batch(self):
        codec = EmergentCodec()
        msgs = [{"task": "analyze"}]
        assert codec.decode_batch(codec.encode_batch(msgs)) == msgs

    def test_large_batch(self):
        codec = EmergentCodec()
        msgs = [{"id": i, "status": "running"} for i in range(100)]
        decoded = codec.decode_batch(codec.encode_batch(msgs))
        assert len(decoded) == 100
        assert decoded[0]["id"] == 0
        assert decoded[99]["id"] == 99


# ── Adaptive mode ─────────────────────────────────────────────────────

class TestAdaptive:
    def test_adaptive_round_trip(self):
        codec = EmergentCodec(adaptive=True)
        msg = {"device": "sensor_1", "temperature": 22.5, "status": "running"}
        decoded = codec.decode(codec.encode(msg))
        assert decoded["status"] == "running"
        assert abs(decoded["temperature"] - 22.5) < 0.1

    def test_adaptive_batch_round_trip(self):
        codec = EmergentCodec(adaptive=True)
        msgs = [{"device": f"s{i}", "value": i} for i in range(10)]
        decoded = codec.decode_batch(codec.encode_batch(msgs))
        assert len(decoded) == 10

    def test_codebook_grows(self):
        codec = EmergentCodec(adaptive=True)
        for i in range(50):
            codec.encode({"custom_field": "custom_val", "index": i})
        stats = codec.stats
        assert stats["keys_tracked"] > 0
        assert stats["values_tracked"] > 0

    def test_rebuild_improves_stats(self):
        codec = EmergentCodec(adaptive=True)
        for i in range(100):
            codec.encode({"device": "sensor_1", "reading": "normal"})
        codec._codebook.rebuild(min_frequency=5)
        stats = codec.stats
        assert stats["codebook_version"] >= 1


# ── Stats tracking ────────────────────────────────────────────────────

class TestStats:
    def test_initial_stats(self):
        codec = EmergentCodec()
        s = codec.stats
        assert s["messages_encoded"] == 0
        assert s["messages_decoded"] == 0
        assert s["bytes_in"] == 0
        assert s["bytes_out"] == 0

    def test_stats_after_encode(self):
        codec = EmergentCodec()
        codec.encode({"task": "analyze"})
        s = codec.stats
        assert s["messages_encoded"] == 1
        assert s["bytes_in"] > 0
        assert s["bytes_out"] > 0

    def test_stats_after_batch(self):
        codec = EmergentCodec()
        msgs = [{"id": i} for i in range(5)]
        data = codec.encode_batch(msgs)
        codec.decode_batch(data)
        s = codec.stats
        assert s["messages_encoded"] == 5
        assert s["messages_decoded"] == 5

    def test_compression_ratio(self):
        codec = EmergentCodec()
        # Encode enough data to get a meaningful ratio
        for i in range(20):
            codec.encode({"task": "analyze", "priority": "high", "status": "pending"})
        s = codec.stats
        assert 0 < s["compression_ratio"] < 1.0


# ── Error cases ───────────────────────────────────────────────────────

class TestErrors:
    def test_decode_garbage(self):
        codec = EmergentCodec()
        with pytest.raises(ValueError):
            codec.decode(b"not valid theta bytes")

    def test_decode_single_from_batch(self):
        codec = EmergentCodec()
        msgs = [{"a": 1}, {"b": 2}]
        data = codec.encode_batch(msgs)
        with pytest.raises(ValueError, match="Expected 1 message"):
            codec.decode(data)
