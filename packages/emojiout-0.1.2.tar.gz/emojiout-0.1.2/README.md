# pyemoji

Biblioteca simples para forçar UTF-8 no stdout e evitar erros com emojis no terminal.

## Instalação


pip install pyemoji

## Uso

from pyemoji import enable_utf8_stdout

enable_utf8_stdout()

print("Teste de emoji: 🚀 😄 🎯")
