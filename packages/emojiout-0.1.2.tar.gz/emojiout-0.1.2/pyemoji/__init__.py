import sys
import io

# Função interna (não precisa nem ser pública)
def _enable_utf8_stdout():
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

# Executa AUTOMATICAMENTE ao importar a biblioteca
_enable_utf8_stdout()
