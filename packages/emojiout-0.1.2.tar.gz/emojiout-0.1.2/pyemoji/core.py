import sys
import io

# Força o terminal a usar UTF-8 para evitar erros com emojis e caracteres especiais
def enable_utf8_stdout():
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')