# EmpoorioChain Python SDK

Python library for interacting with the EmpoorioChain blockchain.

## Installation

```bash
pip install empooriochain
```

## Terminal dashboard

Set RPC/WS endpoints and run the interactive dashboard:

```bash
export EMPOORIO_RPC_URL=http://HOST:8545
export EMPOORIO_WS_URL=ws://HOST:8546
export EMPOORIO_CHAIN_ID=1234
empooriochain
```

## Features

- Support for AI model registration and inference.
- DeFi stablecoin management.
- Gaming and NFT operations.
- Async support using `aiohttp` and `websockets`.

## License

Copyright (c) 2026 Empoorio Inc. All rights reserved. Proprietary and confidential.
