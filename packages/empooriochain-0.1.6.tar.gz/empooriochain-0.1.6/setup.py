#!/usr/bin/env python3

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="empooriochain",
    version="0.1.6",
    author="EmpoorioChain Project Team",
    author_email="dev@empooriochain.io",
    description="Python SDK for interacting with EmpoorioChain",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/empoorio/EmpoorioChain",
    packages=find_packages(),
    license="Proprietary; Copyright (c) 2026 Empoorio Inc.",
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: Other/Proprietary License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.8",
    install_requires=[
        "web3>=6.0.0",
        "eth-account>=0.8.0",
        "websockets>=11.0.0",
        "aiohttp>=3.8.0",
        "rich>=13.7.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-asyncio>=0.21.0",
            "black>=22.0.0",
            "isort>=5.10.0",
            "mypy>=1.0.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "empooriochain=empooriochain.cli:main",
        ],
    },
)
