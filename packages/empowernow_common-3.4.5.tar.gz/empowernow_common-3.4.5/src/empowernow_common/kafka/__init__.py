"""EmpowerNow Kafka integration.

Re-exports commonly used functions from platform_producer for convenience.

Usage
-----
from empowernow_common.kafka import publish, publish_structured, shutdown

await publish("crud.operations", key="user:123", value={...})
await publish_structured("crud.create", payload={...})
"""
from empowernow_common.kafka.platform_producer import (
    publish,
    publish_structured,
    shutdown,
)
from empowernow_common.kafka.topics import TOPICS

__all__ = [
    "publish",
    "publish_structured",
    "shutdown",
    "TOPICS",
]
