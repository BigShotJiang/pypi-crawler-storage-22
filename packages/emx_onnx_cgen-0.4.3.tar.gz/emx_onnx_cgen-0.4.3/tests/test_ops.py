from __future__ import annotations

import json
import math
import os
import shutil
import subprocess
import tempfile
from pathlib import Path

import numpy as np
import onnx
import onnxruntime as ort
import pytest
from onnx.reference import ReferenceEvaluator

from onnx import TensorProto, helper, numpy_helper

from shared.scalar_types import ScalarType

from emx_onnx_cgen.codegen.c_emitter import (
    EinsumKind,
    EinsumOp,
    MultiInputBinaryOp,
)
from emx_onnx_cgen.compiler import Compiler, CompilerOptions
from emx_onnx_cgen.errors import ShapeInferenceError, UnsupportedOpError
from emx_onnx_cgen.ir.ops import ResizeOp
from emx_onnx_cgen.ir.model import Graph, Node, TensorType, Value
from emx_onnx_cgen.lowering.flatten import lower_flatten
from emx_onnx_cgen.lowering.grid_sample import lower_grid_sample
from emx_onnx_cgen.lowering.conv_integer import lower_conv_integer
from emx_onnx_cgen.lowering.one_hot import lower_onehot
from emx_onnx_cgen.lowering.scatter_nd import lower_scatternd
from emx_onnx_cgen.lowering.shape import lower_shape
from emx_onnx_cgen.lowering.squeeze import lower_squeeze
from emx_onnx_cgen.lowering.upsample import lower_upsample
from emx_onnx_cgen.lowering import variadic as _variadic  # noqa: F401
from emx_onnx_cgen.lowering.registry import get_lowering
from emx_onnx_cgen.onnx_import import import_onnx
from emx_onnx_cgen.testbench import decode_testbench_array

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def _run_reference(
    model: onnx.ModelProto, inputs: dict[str, np.ndarray]
) -> dict[str, np.ndarray]:
    evaluator = ReferenceEvaluator(model)
    outputs = evaluator.run(None, inputs)
    return {
        output.name: value
        for output, value in zip(model.graph.output, outputs)
    }


def _make_operator_model(
    *,
    op_type: str,
    input_shapes: list[list[int]],
    output_shape: list[int],
    dtype: int,
    attrs: dict[str, object] | None = None,
    opset: int = 13,
) -> onnx.ModelProto:
    input_names = [f"in{idx}" for idx in range(len(input_shapes))]
    inputs = [
        helper.make_tensor_value_info(name, dtype, shape)
        for name, shape in zip(input_names, input_shapes)
    ]
    output = helper.make_tensor_value_info("out", dtype, output_shape)
    node = helper.make_node(
        op_type,
        inputs=input_names,
        outputs=[output.name],
        **(attrs or {}),
    )
    graph = helper.make_graph([node], f"{op_type.lower()}_graph", inputs, [output])
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", opset)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_tfidf_vectorizer_model(
    *,
    input_shape: list[int],
    output_shape: list[int],
    mode: str,
    min_gram_length: int,
    max_gram_length: int,
    max_skip_count: int,
    ngram_counts: list[int],
    ngram_indexes: list[int],
    pool_int64s: list[int],
) -> onnx.ModelProto:
    input_info = helper.make_tensor_value_info(
        "in0", TensorProto.INT32, input_shape
    )
    output_info = helper.make_tensor_value_info(
        "out", TensorProto.FLOAT, output_shape
    )
    node = helper.make_node(
        "TfIdfVectorizer",
        inputs=["in0"],
        outputs=["out"],
        mode=mode,
        min_gram_length=min_gram_length,
        max_gram_length=max_gram_length,
        max_skip_count=max_skip_count,
        ngram_counts=ngram_counts,
        ngram_indexes=ngram_indexes,
        pool_int64s=pool_int64s,
    )
    graph = helper.make_graph(
        [node],
        "tfidf_graph",
        [input_info],
        [output_info],
    )
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", 9)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _flatten_output_shape(input_shape: list[int], axis: int) -> list[int]:
    rank = len(input_shape)
    if axis < 0:
        axis += rank
    first = int(np.prod(input_shape[:axis])) if axis else 1
    second = int(np.prod(input_shape[axis:])) if axis < rank else 1
    return [first, second]


def _make_flatten_model(input_shape: list[int], axis: int) -> onnx.ModelProto:
    input_info = helper.make_tensor_value_info(
        "in0", TensorProto.FLOAT, input_shape
    )
    output_shape = _flatten_output_shape(input_shape, axis)
    output = helper.make_tensor_value_info(
        "out", TensorProto.FLOAT, output_shape
    )
    node = helper.make_node(
        "Flatten",
        inputs=["in0"],
        outputs=[output.name],
        axis=axis,
    )
    graph = helper.make_graph(
        [node],
        "flatten_graph",
        [input_info],
        [output],
    )
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", 13)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_squeeze_lowering_model(
    input_shape: list[int],
    output_shape: list[int],
    *,
    axes: list[int] | None = None,
    include_axes_input: bool = False,
    opset: int = 13,
) -> onnx.ModelProto:
    input_info = helper.make_tensor_value_info(
        "in0", TensorProto.FLOAT, input_shape
    )
    output = helper.make_tensor_value_info(
        "out", TensorProto.FLOAT, output_shape
    )
    inputs = ["in0"]
    initializers: list[onnx.TensorProto] = []
    attrs: dict[str, object] = {}
    if include_axes_input:
        if axes is None:
            raise ValueError("axes must be provided when axes input is included")
        axes_values = np.array(axes, dtype=np.int64)
        axes_tensor = helper.make_tensor(
            "axes",
            TensorProto.INT64,
            dims=axes_values.shape,
            vals=axes_values.tolist(),
        )
        initializers.append(axes_tensor)
        inputs.append("axes")
    elif axes is not None:
        attrs["axes"] = axes
    node = helper.make_node(
        "Squeeze",
        inputs=inputs,
        outputs=[output.name],
        **attrs,
    )
    graph = helper.make_graph(
        [node],
        "squeeze_graph",
        [input_info],
        [output],
        initializer=initializers,
    )
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", opset)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _broadcast_shape(
    input_shape: list[int], target_shape: list[int]
) -> list[int]:
    output_rank = max(len(input_shape), len(target_shape))
    padded_input = [1] * (output_rank - len(input_shape)) + input_shape
    padded_target = [1] * (output_rank - len(target_shape)) + target_shape
    output_shape: list[int] = []
    for input_dim, target_dim in zip(padded_input, padded_target):
        if input_dim == 1:
            output_shape.append(target_dim)
        elif target_dim == 1 or input_dim == target_dim:
            output_shape.append(input_dim)
        else:
            raise ValueError(
                f"Shapes {input_shape} and {target_shape} are not broadcastable"
            )
    return output_shape


def _make_expand_model(
    *,
    input_shape: list[int],
    target_shape: list[int],
    dtype: int,
    opset: int = 13,
) -> onnx.ModelProto:
    input_info = helper.make_tensor_value_info("input", dtype, input_shape)
    output_shape = _broadcast_shape(input_shape, target_shape)
    output = helper.make_tensor_value_info("output", dtype, output_shape)
    shape_tensor = helper.make_tensor(
        "shape",
        TensorProto.INT64,
        dims=[len(target_shape)],
        vals=target_shape,
    )
    node = helper.make_node(
        "Expand", inputs=["input", "shape"], outputs=[output.name]
    )
    graph = helper.make_graph(
        [node],
        "expand_graph",
        [input_info],
        [output],
        initializer=[shape_tensor],
    )
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", opset)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_scatternd_model(
    *,
    data_shape: list[int],
    indices: np.ndarray,
    updates_shape: list[int],
    dtype: int,
    reduction: str = "none",
    opset: int = 18,
) -> onnx.ModelProto:
    data_info = helper.make_tensor_value_info("data", dtype, data_shape)
    updates_info = helper.make_tensor_value_info("updates", dtype, updates_shape)
    output = helper.make_tensor_value_info("output", dtype, data_shape)
    indices_tensor = helper.make_tensor(
        "indices",
        TensorProto.INT64,
        dims=list(indices.shape),
        vals=indices.astype(np.int64).ravel().tolist(),
    )
    attrs = {}
    if reduction != "none":
        attrs["reduction"] = reduction
    node = helper.make_node(
        "ScatterND",
        inputs=["data", "indices", "updates"],
        outputs=[output.name],
        **attrs,
    )
    graph = helper.make_graph(
        [node],
        "scatternd_graph",
        [data_info, updates_info],
        [output],
        initializer=[indices_tensor],
    )
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", opset)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_range_model(
    *,
    start: float | int,
    limit: float | int,
    delta: float | int,
    dtype: int,
    opset: int = 11,
) -> onnx.ModelProto:
    start_tensor = helper.make_tensor(
        "start",
        dtype,
        dims=[],
        vals=[start],
    )
    limit_tensor = helper.make_tensor(
        "limit",
        dtype,
        dims=[],
        vals=[limit],
    )
    delta_tensor = helper.make_tensor(
        "delta",
        dtype,
        dims=[],
        vals=[delta],
    )
    output_values = np.arange(start, limit, delta, dtype=np.dtype("float64"))
    output_shape = [int(output_values.shape[0])]
    output = helper.make_tensor_value_info("output", dtype, output_shape)
    node = helper.make_node(
        "Range",
        inputs=["start", "limit", "delta"],
        outputs=[output.name],
    )
    graph = helper.make_graph(
        [node],
        "range_graph",
        [],
        [output],
        initializer=[start_tensor, limit_tensor, delta_tensor],
    )
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", opset)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_onehot_model(
    *,
    indices_shape: list[int],
    depth: int,
    axis: int,
    indices_dtype: int,
    values_dtype: int,
    off_value: float | int = 0,
    on_value: float | int = 1,
    opset: int = 13,
) -> onnx.ModelProto:
    indices_info = helper.make_tensor_value_info(
        "indices", indices_dtype, indices_shape
    )
    depth_tensor = helper.make_tensor(
        "depth",
        TensorProto.INT64,
        dims=[],
        vals=[depth],
    )
    values_tensor = helper.make_tensor(
        "values",
        values_dtype,
        dims=[2],
        vals=[off_value, on_value],
    )
    axis_norm = axis
    if axis_norm < 0:
        axis_norm += len(indices_shape) + 1
    output_shape = (
        indices_shape[:axis_norm] + [depth] + indices_shape[axis_norm:]
    )
    output = helper.make_tensor_value_info("output", values_dtype, output_shape)
    node = helper.make_node(
        "OneHot",
        inputs=["indices", "depth", "values"],
        outputs=[output.name],
        axis=axis,
    )
    graph = helper.make_graph(
        [node],
        "onehot_graph",
        [indices_info],
        [output],
        initializer=[depth_tensor, values_tensor],
    )
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", opset)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_hardmax_model() -> onnx.ModelProto:
    return _make_operator_model(
        op_type="Hardmax",
        input_shapes=[[2, 3]],
        output_shape=[2, 3],
        dtype=TensorProto.FLOAT,
        attrs={"axis": 1},
        opset=13,
    )


def _make_global_max_pool_model() -> onnx.ModelProto:
    input_shape = [1, 2, 4, 3]
    return _make_operator_model(
        op_type="GlobalMaxPool",
        input_shapes=[input_shape],
        output_shape=[input_shape[0], input_shape[1], 1, 1],
        dtype=TensorProto.FLOAT,
        opset=13,
    )


def _make_mish_model() -> onnx.ModelProto:
    return _make_operator_model(
        op_type="Mish",
        input_shapes=[[2, 3]],
        output_shape=[2, 3],
        dtype=TensorProto.FLOAT,
        opset=18,
    )


def _make_cumsum_model(
    *,
    input_shape: list[int],
    axis: int,
    dtype: int,
    exclusive: bool = False,
    reverse: bool = False,
    opset: int = 14,
) -> onnx.ModelProto:
    input_info = helper.make_tensor_value_info("input", dtype, input_shape)
    output = helper.make_tensor_value_info("output", dtype, input_shape)
    axis_tensor = helper.make_tensor(
        "axis",
        TensorProto.INT64,
        dims=[],
        vals=[axis],
    )
    node = helper.make_node(
        "CumSum",
        inputs=["input", "axis"],
        outputs=[output.name],
        exclusive=int(exclusive),
        reverse=int(reverse),
    )
    graph = helper.make_graph(
        [node],
        "cumsum_graph",
        [input_info],
        [output],
        initializer=[axis_tensor],
    )
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", opset)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_eye_like_model(
    *,
    input_shape: list[int],
    dtype: int,
    k: int = 0,
    opset: int = 13,
) -> onnx.ModelProto:
    input_info = helper.make_tensor_value_info("input", dtype, input_shape)
    output = helper.make_tensor_value_info("output", dtype, input_shape)
    node = helper.make_node(
        "EyeLike",
        inputs=["input"],
        outputs=[output.name],
        k=k,
    )
    graph = helper.make_graph(
        [node], "eye_like_graph", [input_info], [output]
    )
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", opset)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_trilu_model(
    *,
    input_shape: list[int],
    dtype: int,
    upper: bool = True,
    k: int | None = None,
    include_k_input: bool = False,
    opset: int = 14,
) -> onnx.ModelProto:
    input_info = helper.make_tensor_value_info("input", dtype, input_shape)
    output = helper.make_tensor_value_info("output", dtype, input_shape)
    inputs = ["input"]
    graph_inputs = [input_info]
    initializers: list[onnx.TensorProto] = []
    if include_k_input:
        k_info = helper.make_tensor_value_info("k", TensorProto.INT64, [])
        graph_inputs.append(k_info)
        inputs.append("k")
    elif k is not None:
        k_tensor = helper.make_tensor(
            "k",
            TensorProto.INT64,
            dims=[],
            vals=[k],
        )
        inputs.append("k")
        initializers.append(k_tensor)
    node = helper.make_node(
        "Trilu",
        inputs=inputs,
        outputs=[output.name],
        upper=int(upper),
    )
    graph = helper.make_graph(
        [node],
        "trilu_graph",
        graph_inputs,
        [output],
        initializer=initializers,
    )
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", opset)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_tile_model(
    *,
    input_shape: list[int],
    repeats: list[int],
    dtype: int,
    opset: int = 13,
) -> onnx.ModelProto:
    input_info = helper.make_tensor_value_info("input", dtype, input_shape)
    output_shape = [dim * repeat for dim, repeat in zip(input_shape, repeats)]
    output = helper.make_tensor_value_info("output", dtype, output_shape)
    repeats_tensor = helper.make_tensor(
        "repeats",
        TensorProto.INT64,
        dims=[len(repeats)],
        vals=repeats,
    )
    node = helper.make_node(
        "Tile",
        inputs=["input", "repeats"],
        outputs=[output.name],
    )
    graph = helper.make_graph(
        [node],
        "tile_graph",
        [input_info],
        [output],
        initializer=[repeats_tensor],
    )
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", opset)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _exclusive_cumsum_numpy(data: np.ndarray, axis: int) -> np.ndarray:
    result = np.zeros_like(data)
    if data.shape[axis] == 0:
        return result
    cumsum = np.cumsum(data, axis=axis, dtype=data.dtype)
    src_slice = [slice(None)] * data.ndim
    dst_slice = [slice(None)] * data.ndim
    src_slice[axis] = slice(None, -1)
    dst_slice[axis] = slice(1, None)
    result[tuple(dst_slice)] = cumsum[tuple(src_slice)]
    return result


def _cumsum_numpy(
    data: np.ndarray,
    *,
    axis: int,
    exclusive: bool,
    reverse: bool,
) -> np.ndarray:
    working = np.flip(data, axis=axis) if reverse else data
    if exclusive:
        result = _exclusive_cumsum_numpy(working, axis)
    else:
        result = np.cumsum(working, axis=axis, dtype=data.dtype)
    return np.flip(result, axis=axis) if reverse else result


def _make_pad_model(
    *,
    input_shape: list[int],
    pads: list[int],
    value: float | int | None,
    dtype: int,
    opset: int = 13,
) -> onnx.ModelProto:
    input_info = helper.make_tensor_value_info("input", dtype, input_shape)
    output_shape = [
        dim + pads[index] + pads[index + len(input_shape)]
        for index, dim in enumerate(input_shape)
    ]
    output = helper.make_tensor_value_info("output", dtype, output_shape)
    pads_tensor = helper.make_tensor(
        "pads",
        TensorProto.INT64,
        dims=[len(pads)],
        vals=pads,
    )
    inputs = ["input", "pads"]
    initializers = [pads_tensor]
    if value is not None:
        value_tensor = helper.make_tensor(
            "value",
            dtype,
            dims=[],
            vals=[value],
        )
        inputs.append("value")
        initializers.append(value_tensor)
    node = helper.make_node(
        "Pad",
        inputs=inputs,
        outputs=[output.name],
        mode="constant",
    )
    graph = helper.make_graph(
        [node],
        "pad_graph",
        [input_info],
        [output],
        initializer=initializers,
    )
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", opset)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _depth_to_space_reference(
    value: np.ndarray, *, blocksize: int, mode: str = "DCR"
) -> np.ndarray:
    if value.ndim != 4:
        raise ValueError("DepthToSpace expects 4D input")
    b, c, h, w = value.shape
    if mode == "DCR":
        tmpshape = (
            b,
            blocksize,
            blocksize,
            c // (blocksize * blocksize),
            h,
            w,
        )
        reshaped = value.reshape(tmpshape)
        transposed = np.transpose(reshaped, [0, 3, 4, 1, 5, 2])
    else:
        tmpshape = (
            b,
            c // (blocksize * blocksize),
            blocksize,
            blocksize,
            h,
            w,
        )
        reshaped = value.reshape(tmpshape)
        transposed = np.transpose(reshaped, [0, 1, 4, 2, 5, 3])
    finalshape = (
        b,
        c // (blocksize * blocksize),
        h * blocksize,
        w * blocksize,
    )
    return np.reshape(transposed, finalshape)


def _space_to_depth_reference(
    value: np.ndarray, *, blocksize: int
) -> np.ndarray:
    if value.ndim != 4:
        raise ValueError("SpaceToDepth expects 4D input")
    b, c, h, w = value.shape
    tmpshape = (
        b,
        c,
        h // blocksize,
        blocksize,
        w // blocksize,
        blocksize,
    )
    reshaped = np.reshape(value, tmpshape)
    transposed = np.transpose(reshaped, [0, 3, 5, 1, 2, 4])
    finalshape = (
        b,
        c * blocksize * blocksize,
        h // blocksize,
        w // blocksize,
    )
    return np.reshape(transposed, finalshape)


def _make_split_model(
    *,
    input_shape: list[int],
    split_sizes: list[int] | None,
    axis: int,
    dtype: int,
    opset: int = 18,
) -> onnx.ModelProto:
    input_info = helper.make_tensor_value_info("input", dtype, input_shape)
    outputs: list[onnx.ValueInfoProto] = []
    output_names: list[str] = []
    if split_sizes is None:
        num_outputs = 3
        base = input_shape[axis] // num_outputs
        last = input_shape[axis] - base * (num_outputs - 1)
        split_sizes = [base] * (num_outputs - 1) + [last]
        attrs = {"axis": axis, "num_outputs": num_outputs}
        inputs = ["input"]
        initializer = []
    else:
        attrs = {"axis": axis}
        inputs = ["input", "split"]
        split_tensor = helper.make_tensor(
            "split",
            TensorProto.INT64,
            dims=[len(split_sizes)],
            vals=split_sizes,
        )
        initializer = [split_tensor]
    for index, size in enumerate(split_sizes):
        output_shape = list(input_shape)
        output_shape[axis] = size
        name = f"output_{index}"
        output_names.append(name)
        outputs.append(helper.make_tensor_value_info(name, dtype, output_shape))
    node = helper.make_node(
        "Split",
        inputs=inputs,
        outputs=output_names,
        **attrs,
    )
    graph = helper.make_graph(
        [node],
        "split_graph",
        [input_info],
        outputs,
        initializer=initializer,
    )
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", opset)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_compare_model(
    *,
    op_type: str,
    input_shapes: list[list[int]],
    output_shape: list[int],
    input_dtype: int,
    opset: int = 13,
) -> onnx.ModelProto:
    input_names = [f"in{idx}" for idx in range(len(input_shapes))]
    inputs = [
        helper.make_tensor_value_info(name, input_dtype, shape)
        for name, shape in zip(input_names, input_shapes)
    ]
    output = helper.make_tensor_value_info(
        "out", TensorProto.BOOL, output_shape
    )
    node = helper.make_node(
        op_type,
        inputs=input_names,
        outputs=[output.name],
    )
    graph = helper.make_graph([node], f"{op_type.lower()}_graph", inputs, [output])
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", opset)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_reduce_model(
    *,
    op_type: str,
    input_shape: list[int],
    output_shape: list[int],
    axes: list[int],
    keepdims: int,
    dtype: int,
    opset: int = 18,
) -> onnx.ModelProto:
    input_info = helper.make_tensor_value_info("in0", dtype, input_shape)
    output = helper.make_tensor_value_info("out", dtype, output_shape)
    axes_values = np.array(axes, dtype=np.int64)
    axes_tensor = helper.make_tensor(
        "axes",
        TensorProto.INT64,
        dims=axes_values.shape,
        vals=axes_values.tolist(),
    )
    node = helper.make_node(
        op_type,
        inputs=["in0", "axes"],
        outputs=[output.name],
        keepdims=keepdims,
    )
    graph = helper.make_graph(
        [node],
        f"{op_type.lower()}_graph",
        [input_info],
        [output],
        initializer=[axes_tensor],
    )
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", opset)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_reduce_model_with_axes_input(
    *,
    op_type: str,
    input_shape: list[int],
    output_shape: list[int],
    axes_shape: list[int],
    keepdims: int,
    dtype: int,
    opset: int = 18,
) -> onnx.ModelProto:
    input_info = helper.make_tensor_value_info("in0", dtype, input_shape)
    axes_info = helper.make_tensor_value_info(
        "axes", TensorProto.INT64, axes_shape
    )
    output = helper.make_tensor_value_info("out", dtype, output_shape)
    node = helper.make_node(
        op_type,
        inputs=["in0", "axes"],
        outputs=[output.name],
        keepdims=keepdims,
    )
    graph = helper.make_graph(
        [node],
        f"{op_type.lower()}_graph",
        [input_info, axes_info],
        [output],
    )
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", opset)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model

def _make_constant_add_model() -> onnx.ModelProto:
    input_shape = [2, 3]
    input_info = helper.make_tensor_value_info("in0", TensorProto.FLOAT, input_shape)
    const_values = np.linspace(0.5, 1.0, num=6, dtype=np.float32).reshape(input_shape)
    const_tensor = helper.make_tensor(
        "const_tensor",
        TensorProto.FLOAT,
        dims=input_shape,
        vals=const_values.flatten().tolist(),
    )
    const_node = helper.make_node(
        "Constant",
        inputs=[],
        outputs=["const_out"],
        value=const_tensor,
    )
    const_info = helper.make_tensor_value_info(
        "const_out", TensorProto.FLOAT, input_shape
    )
    output = helper.make_tensor_value_info("out", TensorProto.FLOAT, input_shape)
    add_node = helper.make_node(
        "Add", inputs=["in0", "const_out"], outputs=[output.name]
    )
    graph = helper.make_graph(
        [const_node, add_node],
        "constant_add_graph",
        [input_info],
        [output],
        value_info=[const_info],
    )
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", 13)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_constant_of_shape_model() -> onnx.ModelProto:
    shape_values = np.array([2, 3, 4], dtype=np.int64)
    shape_tensor = helper.make_tensor(
        "shape",
        TensorProto.INT64,
        dims=shape_values.shape,
        vals=shape_values.tolist(),
    )
    value_tensor = helper.make_tensor(
        "fill",
        TensorProto.FLOAT,
        dims=[1],
        vals=[1.25],
    )
    output_shape = shape_values.tolist()
    output = helper.make_tensor_value_info("out", TensorProto.FLOAT, output_shape)
    node = helper.make_node(
        "ConstantOfShape",
        inputs=["shape"],
        outputs=[output.name],
        value=value_tensor,
    )
    graph = helper.make_graph(
        [node],
        "constant_of_shape_graph",
        [],
        [output],
        initializer=[shape_tensor],
    )
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", 13)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_reshape_model() -> onnx.ModelProto:
    input_shape = [2, 3, 4]
    output_shape = [2, 12]
    input_info = helper.make_tensor_value_info(
        "in0", TensorProto.FLOAT, input_shape
    )
    shape_values = np.array([0, -1], dtype=np.int64)
    shape_tensor = helper.make_tensor(
        "shape",
        TensorProto.INT64,
        dims=shape_values.shape,
        vals=shape_values.tolist(),
    )
    output = helper.make_tensor_value_info(
        "out", TensorProto.FLOAT, output_shape
    )
    node = helper.make_node(
        "Reshape",
        inputs=["in0", "shape"],
        outputs=[output.name],
    )
    graph = helper.make_graph(
        [node],
        "reshape_graph",
        [input_info],
        [output],
        initializer=[shape_tensor],
    )
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", 13)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_squeeze_model() -> onnx.ModelProto:
    input_shape = [1, 3, 1, 5]
    output_shape = [3, 5]
    input_info = helper.make_tensor_value_info(
        "in0", TensorProto.FLOAT, input_shape
    )
    axes_values = np.array([0, 2], dtype=np.int64)
    axes_tensor = helper.make_tensor(
        "axes",
        TensorProto.INT64,
        dims=axes_values.shape,
        vals=axes_values.tolist(),
    )
    output = helper.make_tensor_value_info(
        "out", TensorProto.FLOAT, output_shape
    )
    node = helper.make_node(
        "Squeeze",
        inputs=["in0", "axes"],
        outputs=[output.name],
    )
    graph = helper.make_graph(
        [node],
        "squeeze_graph",
        [input_info],
        [output],
        initializer=[axes_tensor],
    )
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", 13)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_cast_model() -> onnx.ModelProto:
    input_shape = [2, 3]
    input_info = helper.make_tensor_value_info(
        "in0", TensorProto.FLOAT, input_shape
    )
    output = helper.make_tensor_value_info(
        "out", TensorProto.INT32, input_shape
    )
    node = helper.make_node(
        "Cast",
        inputs=["in0"],
        outputs=[output.name],
        to=TensorProto.INT32,
    )
    graph = helper.make_graph(
        [node],
        "cast_graph",
        [input_info],
        [output],
    )
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", 13)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_castlike_model() -> onnx.ModelProto:
    input_shape = [2, 3]
    input_info = helper.make_tensor_value_info(
        "in0", TensorProto.FLOAT, input_shape
    )
    like_info = helper.make_tensor_value_info(
        "in1", TensorProto.INT32, input_shape
    )
    output = helper.make_tensor_value_info(
        "out", TensorProto.INT32, input_shape
    )
    node = helper.make_node(
        "CastLike",
        inputs=["in0", "in1"],
        outputs=[output.name],
    )
    graph = helper.make_graph(
        [node],
        "castlike_graph",
        [input_info, like_info],
        [output],
    )
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", 19)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_lstm_model(
    *,
    seq_length: int,
    batch_size: int,
    input_size: int,
    hidden_size: int,
    dtype: int,
    include_optional_inputs: bool,
    include_y: bool,
    include_y_h: bool,
    include_y_c: bool,
    layout: int = 0,
) -> onnx.ModelProto:
    x_shape = (
        [seq_length, batch_size, input_size]
        if layout == 0
        else [batch_size, seq_length, input_size]
    )
    inputs = [
        helper.make_tensor_value_info("X", dtype, x_shape),
        helper.make_tensor_value_info(
            "W", dtype, [1, 4 * hidden_size, input_size]
        ),
        helper.make_tensor_value_info(
            "R", dtype, [1, 4 * hidden_size, hidden_size]
        ),
    ]
    input_names = ["X", "W", "R"]
    if include_optional_inputs:
        state_shape = (
            [1, batch_size, hidden_size]
            if layout == 0
            else [batch_size, 1, hidden_size]
        )
        inputs.extend(
            [
                helper.make_tensor_value_info(
                    "B", dtype, [1, 8 * hidden_size]
                ),
                helper.make_tensor_value_info(
                    "sequence_lens", TensorProto.INT32, [batch_size]
                ),
                helper.make_tensor_value_info(
                    "initial_h", dtype, state_shape
                ),
                helper.make_tensor_value_info(
                    "initial_c", dtype, state_shape
                ),
                helper.make_tensor_value_info(
                    "P", dtype, [1, 3 * hidden_size]
                ),
            ]
        )
        input_names.extend(
            ["B", "sequence_lens", "initial_h", "initial_c", "P"]
        )
    outputs = []
    output_names: list[str] = []
    if include_y:
        y_shape = (
            [seq_length, 1, batch_size, hidden_size]
            if layout == 0
            else [batch_size, seq_length, 1, hidden_size]
        )
        outputs.append(
            helper.make_tensor_value_info("Y", dtype, y_shape)
        )
        output_names.append("Y")
    state_shape = (
        [1, batch_size, hidden_size]
        if layout == 0
        else [batch_size, 1, hidden_size]
    )
    if include_y_h:
        outputs.append(
            helper.make_tensor_value_info("Y_h", dtype, state_shape)
        )
        output_names.append("Y_h")
    if include_y_c:
        outputs.append(
            helper.make_tensor_value_info("Y_c", dtype, state_shape)
        )
        output_names.append("Y_c")
    node = helper.make_node(
        "LSTM",
        inputs=input_names,
        outputs=output_names,
        hidden_size=hidden_size,
        layout=layout,
    )
    graph = helper.make_graph(
        [node],
        "lstm_graph",
        inputs,
        outputs,
    )
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", 14)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _lstm_reference(
    *,
    x: np.ndarray,
    w: np.ndarray,
    r: np.ndarray,
    b: np.ndarray,
    sequence_lens: np.ndarray,
    initial_h: np.ndarray,
    initial_c: np.ndarray,
    p: np.ndarray,
    layout: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    if layout == 1:
        x = np.swapaxes(x, 0, 1)
        initial_h = np.swapaxes(initial_h, 0, 1)
        initial_c = np.swapaxes(initial_c, 0, 1)
    seq_length, batch_size, _ = x.shape
    hidden_size = r.shape[-1]
    y = np.zeros((seq_length, 1, batch_size, hidden_size), dtype=x.dtype)
    h_prev = initial_h[0].copy()
    c_prev = initial_c[0].copy()
    bias = b[0, : 4 * hidden_size] + b[0, 4 * hidden_size :]
    p_i = p[0, :hidden_size]
    p_o = p[0, hidden_size : 2 * hidden_size]
    p_f = p[0, 2 * hidden_size :]
    for step in range(seq_length):
        active_mask = step < sequence_lens
        if not np.all(active_mask):
            y[step, 0] = np.where(active_mask[:, None], y[step, 0], 0)
        x_t = x[step]
        gates = x_t @ w[0].T + h_prev @ r[0].T + bias
        i, o, f, c = np.split(gates, 4, axis=1)
        i = 1 / (1 + np.exp(-(i + p_i * c_prev)))
        f = 1 / (1 + np.exp(-(f + p_f * c_prev)))
        c_tilde = np.tanh(c)
        c_new = f * c_prev + i * c_tilde
        o = 1 / (1 + np.exp(-(o + p_o * c_new)))
        h_new = o * np.tanh(c_new)
        h_prev = np.where(active_mask[:, None], h_new, h_prev)
        c_prev = np.where(active_mask[:, None], c_new, c_prev)
        y[step, 0] = np.where(active_mask[:, None], h_prev, 0)
    y_h = h_prev.reshape(1, batch_size, hidden_size)
    y_c = c_prev.reshape(1, batch_size, hidden_size)
    if layout == 1:
        y = np.transpose(y, (2, 0, 1, 3))
        y_h = np.swapaxes(y_h, 0, 1)
        y_c = np.swapaxes(y_c, 0, 1)
    return y, y_h, y_c


def _shape_output_shape(
    input_shape: list[int], start: int | None, end: int | None
) -> list[int]:
    rank = len(input_shape)
    start_index = 0 if start is None else start
    end_index = rank if end is None else end
    if start_index < 0:
        start_index += rank
    if end_index < 0:
        end_index += rank
    start_index = max(0, min(start_index, rank))
    end_index = max(0, min(end_index, rank))
    if end_index <= start_index:
        raise ValueError("Shape start must be less than end")
    return [end_index - start_index]


def _make_shape_model(
    *, input_shape: list[int], start: int | None = None, end: int | None = None, opset: int = 13
) -> onnx.ModelProto:
    input_info = helper.make_tensor_value_info(
        "in0", TensorProto.FLOAT, input_shape
    )
    output_shape = _shape_output_shape(input_shape, start, end)
    output = helper.make_tensor_value_info(
        "out", TensorProto.INT64, output_shape
    )
    attrs: dict[str, object] = {}
    if start is not None:
        attrs["start"] = start
    if end is not None:
        attrs["end"] = end
    node = helper.make_node(
        "Shape",
        inputs=["in0"],
        outputs=[output.name],
        **attrs,
    )
    graph = helper.make_graph(
        [node],
        "shape_graph",
        [input_info],
        [output],
    )
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", opset)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_shape_dim_param_model() -> onnx.ModelProto:
    input_info = helper.make_tensor_value_info(
        "in0", TensorProto.FLOAT, [2, 3]
    )
    reshape_output = helper.make_tensor_value_info(
        "reshaped", TensorProto.FLOAT, ["N"]
    )
    shape_output = helper.make_tensor_value_info(
        "out", TensorProto.INT64, [1]
    )
    reshape_shape = numpy_helper.from_array(
        np.array([6], dtype=np.int64), name="shape"
    )
    reshape_node = helper.make_node(
        "Reshape",
        inputs=["in0", "shape"],
        outputs=["reshaped"],
    )
    shape_node = helper.make_node(
        "Shape",
        inputs=["reshaped"],
        outputs=[shape_output.name],
    )
    graph = helper.make_graph(
        [reshape_node, shape_node],
        "shape_dim_param_graph",
        [input_info],
        [shape_output],
        initializer=[reshape_shape],
        value_info=[reshape_output],
    )
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", 13)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_size_model(*, input_shape: list[int], opset: int = 13) -> onnx.ModelProto:
    input_info = helper.make_tensor_value_info(
        "in0", TensorProto.FLOAT, input_shape
    )
    output = helper.make_tensor_value_info("out", TensorProto.INT64, [])
    node = helper.make_node("Size", inputs=["in0"], outputs=[output.name])
    graph = helper.make_graph([node], "size_graph", [input_info], [output])
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", opset)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_nonzero_model(
    *,
    input_shape: list[int],
    output_shape: list[int],
    input_dtype: int,
    opset: int = 13,
) -> onnx.ModelProto:
    input_info = helper.make_tensor_value_info(
        "input", input_dtype, input_shape
    )
    output = helper.make_tensor_value_info(
        "output", TensorProto.INT64, output_shape
    )
    node = helper.make_node("NonZero", inputs=["input"], outputs=[output.name])
    graph = helper.make_graph(
        [node],
        "nonzero_graph",
        [input_info],
        [output],
    )
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", opset)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_slice_model() -> onnx.ModelProto:
    input_shape = [2, 3, 4]
    output_shape = [2, 3, 1]
    input_info = helper.make_tensor_value_info(
        "in0", TensorProto.FLOAT, input_shape
    )
    output = helper.make_tensor_value_info(
        "out", TensorProto.FLOAT, output_shape
    )
    starts_values = np.array([0, 1], dtype=np.int64)
    ends_values = np.array([2, 3], dtype=np.int64)
    axes_values = np.array([0, 2], dtype=np.int64)
    steps_values = np.array([1, 2], dtype=np.int64)
    starts = helper.make_tensor(
        "starts",
        TensorProto.INT64,
        dims=starts_values.shape,
        vals=starts_values.tolist(),
    )
    ends = helper.make_tensor(
        "ends",
        TensorProto.INT64,
        dims=ends_values.shape,
        vals=ends_values.tolist(),
    )
    axes = helper.make_tensor(
        "axes",
        TensorProto.INT64,
        dims=axes_values.shape,
        vals=axes_values.tolist(),
    )
    steps = helper.make_tensor(
        "steps",
        TensorProto.INT64,
        dims=steps_values.shape,
        vals=steps_values.tolist(),
    )
    node = helper.make_node(
        "Slice",
        inputs=["in0", "starts", "ends", "axes", "steps"],
        outputs=[output.name],
    )
    graph = helper.make_graph(
        [node],
        "slice_graph",
        [input_info],
        [output],
        initializer=[starts, ends, axes, steps],
    )
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", 13)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_resize_model() -> onnx.ModelProto:
    input_shape = [1, 1, 2, 2]
    output_shape = [1, 1, 4, 4]
    input_info = helper.make_tensor_value_info(
        "in0", TensorProto.FLOAT, input_shape
    )
    output = helper.make_tensor_value_info(
        "out", TensorProto.FLOAT, output_shape
    )
    sizes_values = np.array(output_shape, dtype=np.int64)
    sizes_tensor = helper.make_tensor(
        "sizes",
        TensorProto.INT64,
        dims=sizes_values.shape,
        vals=sizes_values.tolist(),
    )
    node = helper.make_node(
        "Resize",
        inputs=["in0", "", "", "sizes"],
        outputs=[output.name],
        mode="nearest",
        coordinate_transformation_mode="asymmetric",
        nearest_mode="floor",
    )
    graph = helper.make_graph(
        [node],
        "resize_graph",
        [input_info],
        [output],
        initializer=[sizes_tensor],
    )
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", 13)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_upsample_model() -> onnx.ModelProto:
    input_shape = [1, 1, 2, 2]
    output_shape = [1, 1, 4, 6]
    input_info = helper.make_tensor_value_info(
        "in0", TensorProto.FLOAT, input_shape
    )
    output = helper.make_tensor_value_info(
        "out", TensorProto.FLOAT, output_shape
    )
    scales_values = np.array([1.0, 1.0, 2.0, 3.0], dtype=np.float32)
    scales_tensor = helper.make_tensor(
        "scales",
        TensorProto.FLOAT,
        dims=scales_values.shape,
        vals=scales_values.tolist(),
    )
    node = helper.make_node(
        "Upsample",
        inputs=["in0", "scales"],
        outputs=[output.name],
        mode="nearest",
    )
    graph = helper.make_graph(
        [node],
        "upsample_graph",
        [input_info],
        [output],
        initializer=[scales_tensor],
    )
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", 9)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_gridsample_model(
    *,
    input_shape: list[int],
    grid_shape: list[int],
    output_shape: list[int],
    mode: str = "linear",
    padding_mode: str = "zeros",
    align_corners: int = 0,
    opset: int = 22,
) -> onnx.ModelProto:
    input_info = helper.make_tensor_value_info(
        "x", TensorProto.FLOAT, input_shape
    )
    grid_info = helper.make_tensor_value_info(
        "grid", TensorProto.FLOAT, grid_shape
    )
    output = helper.make_tensor_value_info(
        "y", TensorProto.FLOAT, output_shape
    )
    node = helper.make_node(
        "GridSample",
        inputs=["x", "grid"],
        outputs=[output.name],
        mode=mode,
        padding_mode=padding_mode,
        align_corners=align_corners,
    )
    graph = helper.make_graph(
        [node],
        "gridsample_graph",
        [input_info, grid_info],
        [output],
    )
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", opset)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_dropout_model() -> onnx.ModelProto:
    input_shape = [2, 3, 4]
    input_info = helper.make_tensor_value_info(
        "in0", TensorProto.FLOAT, input_shape
    )
    output = helper.make_tensor_value_info(
        "out", TensorProto.FLOAT, input_shape
    )
    node = helper.make_node(
        "Dropout",
        inputs=["in0"],
        outputs=[output.name],
    )
    graph = helper.make_graph(
        [node],
        "dropout_graph",
        [input_info],
        [output],
    )
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", 13)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _unsqueeze_output_shape(
    input_shape: list[int], axes: list[int]
) -> list[int]:
    output_rank = len(input_shape) + len(axes)
    normalized_axes = []
    for axis in axes:
        if axis < 0:
            axis += output_rank
        if axis < 0 or axis >= output_rank:
            raise ValueError(f"Axis {axis} out of range for rank {output_rank}")
        normalized_axes.append(axis)
    if len(set(normalized_axes)) != len(normalized_axes):
        raise ValueError("Axes must be unique")
    normalized_axes = sorted(normalized_axes)
    output_dims = []
    input_index = 0
    for axis in range(output_rank):
        if axis in normalized_axes:
            output_dims.append(1)
        else:
            output_dims.append(input_shape[input_index])
            input_index += 1
    return output_dims


def _reduce_output_shape(
    input_shape: list[int], axes: list[int], keepdims: int
) -> list[int]:
    rank = len(input_shape)
    normalized = []
    for axis in axes:
        if axis < 0:
            axis += rank
        normalized.append(axis)
    if keepdims:
        return [
            1 if axis in normalized else dim
            for axis, dim in enumerate(input_shape)
        ]
    return [dim for axis, dim in enumerate(input_shape) if axis not in normalized]


def _arg_reduce_output_shape(
    input_shape: list[int], axis: int, keepdims: int
) -> list[int]:
    rank = len(input_shape)
    if axis < 0:
        axis += rank
    if keepdims:
        return [
            1 if dim_axis == axis else dim
            for dim_axis, dim in enumerate(input_shape)
        ]
    return [dim for dim_axis, dim in enumerate(input_shape) if dim_axis != axis]


def _topk_output_shape(
    input_shape: list[int], axis: int, k: int
) -> list[int]:
    rank = len(input_shape)
    if axis < 0:
        axis += rank
    output_shape = list(input_shape)
    output_shape[axis] = k
    return output_shape


def _make_arg_reduce_model(
    *,
    op_type: str,
    input_shape: list[int],
    output_shape: list[int],
    axis: int,
    keepdims: int,
    select_last_index: int,
    dtype: int,
    opset: int = 13,
) -> onnx.ModelProto:
    input_info = helper.make_tensor_value_info("input", dtype, input_shape)
    output = helper.make_tensor_value_info("output", TensorProto.INT64, output_shape)
    node = helper.make_node(
        op_type,
        inputs=["input"],
        outputs=[output.name],
        axis=axis,
        keepdims=keepdims,
        select_last_index=select_last_index,
    )
    graph = helper.make_graph(
        [node],
        f"{op_type.lower()}_graph",
        [input_info],
        [output],
    )
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", opset)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_topk_model(
    *,
    input_shape: list[int],
    output_shape: list[int],
    axis: int,
    k: int,
    largest: int,
    sorted: int,
    dtype: int,
    opset: int = 13,
) -> onnx.ModelProto:
    input_info = helper.make_tensor_value_info("input", dtype, input_shape)
    values_info = helper.make_tensor_value_info("values", dtype, output_shape)
    indices_info = helper.make_tensor_value_info(
        "indices", TensorProto.INT64, output_shape
    )
    k_init = numpy_helper.from_array(np.array([k], dtype=np.int64), name="k")
    node = helper.make_node(
        "TopK",
        inputs=[input_info.name, "k"],
        outputs=[values_info.name, indices_info.name],
        axis=axis,
        largest=largest,
        sorted=sorted,
    )
    graph = helper.make_graph(
        [node],
        "topk_graph",
        [input_info],
        [values_info, indices_info],
        initializer=[k_init],
    )
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", opset)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_unsqueeze_model(
    *, input_shape: list[int], axes: list[int], opset: int = 13
) -> onnx.ModelProto:
    input_info = helper.make_tensor_value_info(
        "in0", TensorProto.FLOAT, input_shape
    )
    output_shape = _unsqueeze_output_shape(input_shape, axes)
    output = helper.make_tensor_value_info(
        "out", TensorProto.FLOAT, output_shape
    )
    if opset >= 13:
        axes_values = np.array(axes, dtype=np.int64)
        axes_tensor = helper.make_tensor(
            "axes",
            TensorProto.INT64,
            dims=axes_values.shape,
            vals=axes_values.tolist(),
        )
        node = helper.make_node(
            "Unsqueeze",
            inputs=["in0", "axes"],
            outputs=[output.name],
        )
        graph = helper.make_graph(
            [node],
            "unsqueeze_graph",
            [input_info],
            [output],
            initializer=[axes_tensor],
        )
    else:
        node = helper.make_node(
            "Unsqueeze",
            inputs=["in0"],
            outputs=[output.name],
            axes=axes,
        )
        graph = helper.make_graph(
            [node],
            "unsqueeze_graph",
            [input_info],
            [output],
        )
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", opset)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_conv_model() -> onnx.ModelProto:
    input_shape = [1, 1, 4, 4]
    weight_shape = [1, 1, 3, 3]
    output_shape = [1, 1, 4, 4]
    input_info = helper.make_tensor_value_info(
        "in0", TensorProto.FLOAT, input_shape
    )
    weight_values = np.arange(9, dtype=np.float32).reshape(weight_shape)
    weight_tensor = helper.make_tensor(
        "weight",
        TensorProto.FLOAT,
        dims=weight_shape,
        vals=weight_values.flatten().tolist(),
    )
    bias_values = np.array([0.25], dtype=np.float32)
    bias_tensor = helper.make_tensor(
        "bias",
        TensorProto.FLOAT,
        dims=[1],
        vals=bias_values.tolist(),
    )
    output = helper.make_tensor_value_info(
        "out", TensorProto.FLOAT, output_shape
    )
    conv_node = helper.make_node(
        "Conv",
        inputs=["in0", "weight", "bias"],
        outputs=[output.name],
        pads=[1, 1, 1, 1],
        strides=[1, 1],
    )
    graph = helper.make_graph(
        [conv_node],
        "conv_graph",
        [input_info],
        [output],
        initializer=[weight_tensor, bias_tensor],
    )
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", 13)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_convinteger_model(*, per_channel_zero_point: bool = False) -> onnx.ModelProto:
    input_shape = [1, 1, 3, 3]
    weight_shape = [2, 1, 2, 2]
    output_shape = [1, 2, 4, 4]
    input_info = helper.make_tensor_value_info(
        "in0", TensorProto.UINT8, input_shape
    )
    weight_values = np.arange(8, dtype=np.uint8).reshape(weight_shape)
    weight_tensor = helper.make_tensor(
        "weight",
        TensorProto.UINT8,
        dims=weight_shape,
        vals=weight_values.flatten().tolist(),
    )
    x_zero_point = helper.make_tensor(
        "x_zero_point", TensorProto.UINT8, dims=[], vals=[1]
    )
    if per_channel_zero_point:
        w_zero_point = helper.make_tensor(
            "w_zero_point",
            TensorProto.UINT8,
            dims=[2],
            vals=[0, 1],
        )
    else:
        w_zero_point = helper.make_tensor(
            "w_zero_point", TensorProto.UINT8, dims=[], vals=[0]
        )
    output = helper.make_tensor_value_info(
        "out", TensorProto.INT32, output_shape
    )
    conv_node = helper.make_node(
        "ConvInteger",
        inputs=["in0", "weight", "x_zero_point", "w_zero_point"],
        outputs=[output.name],
        pads=[1, 1, 1, 1],
        strides=[1, 1],
    )
    graph = helper.make_graph(
        [conv_node],
        "convinteger_graph",
        [input_info],
        [output],
        initializer=[weight_tensor, x_zero_point, w_zero_point],
    )
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", 10)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_conv_transpose_model() -> onnx.ModelProto:
    input_shape = [1, 1, 3, 3]
    weight_shape = [1, 1, 3, 3]
    output_shape = [1, 1, 3, 3]
    input_info = helper.make_tensor_value_info(
        "in0", TensorProto.FLOAT, input_shape
    )
    weight_values = np.arange(9, dtype=np.float32).reshape(weight_shape)
    weight_tensor = helper.make_tensor(
        "weight",
        TensorProto.FLOAT,
        dims=weight_shape,
        vals=weight_values.flatten().tolist(),
    )
    bias_values = np.array([0.5], dtype=np.float32)
    bias_tensor = helper.make_tensor(
        "bias",
        TensorProto.FLOAT,
        dims=[1],
        vals=bias_values.tolist(),
    )
    output = helper.make_tensor_value_info(
        "out", TensorProto.FLOAT, output_shape
    )
    conv_node = helper.make_node(
        "ConvTranspose",
        inputs=["in0", "weight", "bias"],
        outputs=[output.name],
        pads=[1, 1, 1, 1],
        strides=[1, 1],
    )
    graph = helper.make_graph(
        [conv_node],
        "convtranspose_graph",
        [input_info],
        [output],
        initializer=[weight_tensor, bias_tensor],
    )
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", 13)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_lp_pool_model() -> onnx.ModelProto:
    input_shape = [1, 1, 4, 4]
    output_shape = [1, 1, 2, 2]
    input_info = helper.make_tensor_value_info(
        "in0", TensorProto.FLOAT, input_shape
    )
    output = helper.make_tensor_value_info(
        "out", TensorProto.FLOAT, output_shape
    )
    node = helper.make_node(
        "LpPool",
        inputs=["in0"],
        outputs=[output.name],
        kernel_shape=[2, 2],
        strides=[2, 2],
        p=2,
    )
    graph = helper.make_graph(
        [node],
        "lppool_graph",
        [input_info],
        [output],
    )
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", 13)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_quantize_linear_model() -> onnx.ModelProto:
    input_shape = [2, 2]
    input_info = helper.make_tensor_value_info(
        "in0", TensorProto.FLOAT, input_shape
    )
    output = helper.make_tensor_value_info(
        "out", TensorProto.UINT8, input_shape
    )
    scale_tensor = helper.make_tensor(
        "scale",
        TensorProto.FLOAT,
        dims=[],
        vals=[0.1],
    )
    zero_point_tensor = helper.make_tensor(
        "zero_point",
        TensorProto.UINT8,
        dims=[],
        vals=[128],
    )
    node = helper.make_node(
        "QuantizeLinear",
        inputs=["in0", "scale", "zero_point"],
        outputs=[output.name],
    )
    graph = helper.make_graph(
        [node],
        "quantize_linear_graph",
        [input_info],
        [output],
        initializer=[scale_tensor, zero_point_tensor],
    )
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", 13)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_batchnorm_model() -> tuple[onnx.ModelProto, dict[str, np.ndarray]]:
    input_shape = [2, 3, 2, 2]
    input_info = helper.make_tensor_value_info(
        "in0", TensorProto.FLOAT, input_shape
    )
    params = {
        "scale": np.array([1.0, 1.5, -0.5], dtype=np.float32),
        "bias": np.array([0.0, 0.1, -0.2], dtype=np.float32),
        "mean": np.array([0.5, -0.5, 1.0], dtype=np.float32),
        "var": np.array([0.25, 0.5, 1.5], dtype=np.float32),
    }
    initializers = []
    for name, values in params.items():
        initializers.append(
            helper.make_tensor(
                name,
                TensorProto.FLOAT,
                dims=values.shape,
                vals=values.flatten().tolist(),
            )
        )
    output = helper.make_tensor_value_info(
        "out", TensorProto.FLOAT, input_shape
    )
    node = helper.make_node(
        "BatchNormalization",
        inputs=["in0", "scale", "bias", "mean", "var"],
        outputs=[output.name],
        epsilon=1e-5,
    )
    graph = helper.make_graph(
        [node],
        "batchnorm_graph",
        [input_info],
        [output],
        initializer=initializers,
    )
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", 13)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model, params


def _make_lp_normalization_model(
    *, input_shape: list[int], axis: int, p: int
) -> onnx.ModelProto:
    return _make_operator_model(
        op_type="LpNormalization",
        input_shapes=[input_shape],
        output_shape=input_shape,
        dtype=TensorProto.FLOAT,
        attrs={"axis": axis, "p": p},
        opset=22,
    )


def _make_instance_normalization_model(
    *, input_shape: list[int], epsilon: float = 1e-5
) -> onnx.ModelProto:
    channels = input_shape[1]
    return _make_operator_model(
        op_type="InstanceNormalization",
        input_shapes=[input_shape, [channels], [channels]],
        output_shape=input_shape,
        dtype=TensorProto.FLOAT,
        attrs={"epsilon": epsilon},
        opset=22,
    )


def _make_group_normalization_model(
    *, input_shape: list[int], num_groups: int, epsilon: float = 1e-5
) -> onnx.ModelProto:
    channels = input_shape[1]
    return _make_operator_model(
        op_type="GroupNormalization",
        input_shapes=[input_shape, [channels], [channels]],
        output_shape=input_shape,
        dtype=TensorProto.FLOAT,
        attrs={"epsilon": epsilon, "num_groups": num_groups},
        opset=21,
    )


def _make_layer_normalization_model(
    *, input_shape: list[int], axis: int, epsilon: float = 1e-5
) -> onnx.ModelProto:
    axis_index = axis if axis >= 0 else axis + len(input_shape)
    normalized_shape = input_shape[axis_index:]
    return _make_operator_model(
        op_type="LayerNormalization",
        input_shapes=[input_shape, normalized_shape, normalized_shape],
        output_shape=input_shape,
        dtype=TensorProto.FLOAT,
        attrs={"axis": axis, "epsilon": epsilon},
        opset=17,
    )


def _make_mean_variance_normalization_model(
    *, input_shape: list[int], axes: list[int] | None = None
) -> onnx.ModelProto:
    attrs = {"axes": axes} if axes is not None else None
    return _make_operator_model(
        op_type="MeanVarianceNormalization",
        input_shapes=[input_shape],
        output_shape=input_shape,
        dtype=TensorProto.FLOAT,
        attrs=attrs,
        opset=13,
    )


def _make_rms_normalization_model(
    *, input_shape: list[int], axis: int, epsilon: float = 1e-5
) -> onnx.ModelProto:
    axis_index = axis if axis >= 0 else axis + len(input_shape)
    normalized_shape = input_shape[axis_index:]
    return _make_operator_model(
        op_type="RMSNormalization",
        input_shapes=[input_shape, normalized_shape],
        output_shape=input_shape,
        dtype=TensorProto.FLOAT,
        attrs={"axis": axis, "epsilon": epsilon},
        opset=23,
    )


def _maxpool_output_shape(
    input_shape: list[int],
    kernel_shape: list[int],
    strides: list[int],
    pads: list[int],
    ceil_mode: int,
) -> list[int]:
    spatial_rank = len(kernel_shape)
    pad_begin = pads[:spatial_rank]
    pad_end = pads[spatial_rank:]
    out_spatial = []
    for dim, kernel, stride, pad_start, pad_finish in zip(
        input_shape[2:], kernel_shape, strides, pad_begin, pad_end
    ):
        numerator = dim + pad_start + pad_finish - kernel
        if ceil_mode:
            out_dim = (numerator + stride - 1) // stride + 1
            if (out_dim - 1) * stride >= dim + pad_start:
                out_dim -= 1
        else:
            out_dim = numerator // stride + 1
        out_spatial.append(out_dim)
    return [input_shape[0], input_shape[1], *out_spatial]


def _make_maxpool_model(
    *,
    input_shape: list[int],
    kernel_shape: list[int],
    strides: list[int],
    pads: list[int],
    ceil_mode: int,
    dtype: int = TensorProto.FLOAT,
    opset: int = 13,
) -> onnx.ModelProto:
    output_shape = _maxpool_output_shape(
        input_shape, kernel_shape, strides, pads, ceil_mode
    )
    input_info = helper.make_tensor_value_info("in0", dtype, input_shape)
    output = helper.make_tensor_value_info("out", dtype, output_shape)
    node = helper.make_node(
        "MaxPool",
        inputs=["in0"],
        outputs=[output.name],
        kernel_shape=kernel_shape,
        strides=strides,
        pads=pads,
        ceil_mode=ceil_mode,
    )
    graph = helper.make_graph(
        [node],
        "maxpool_graph",
        [input_info],
        [output],
    )
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", opset)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_gather_elements_model(
    *,
    data_shape: list[int],
    indices_shape: list[int],
    axis: int,
    data_dtype: int = TensorProto.FLOAT,
    indices_dtype: int = TensorProto.INT64,
    indices_values: np.ndarray | None = None,
    indices_as_initializer: bool = False,
    opset: int = 13,
) -> onnx.ModelProto:
    data_input = helper.make_tensor_value_info("data", data_dtype, data_shape)
    inputs = [data_input]
    initializers = []
    value_infos = []
    if indices_as_initializer:
        if indices_values is None:
            raise ValueError("indices_values is required for initializer inputs")
        indices_tensor = helper.make_tensor(
            "indices",
            indices_dtype,
            dims=indices_shape,
            vals=indices_values.flatten().tolist(),
        )
        initializers.append(indices_tensor)
        value_infos.append(
            helper.make_tensor_value_info("indices", indices_dtype, indices_shape)
        )
    else:
        inputs.append(
            helper.make_tensor_value_info("indices", indices_dtype, indices_shape)
        )
    output = helper.make_tensor_value_info("out", data_dtype, indices_shape)
    node = helper.make_node(
        "GatherElements",
        inputs=["data", "indices"],
        outputs=[output.name],
        axis=axis,
    )
    graph = helper.make_graph(
        [node],
        "gather_elements_graph",
        inputs,
        [output],
        initializer=initializers,
        value_info=value_infos,
    )
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", opset)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_gather_model(
    *,
    data_shape: list[int],
    indices_shape: list[int],
    axis: int,
    data_dtype: int = TensorProto.FLOAT,
    indices_dtype: int = TensorProto.INT64,
    indices_values: np.ndarray | None = None,
    indices_as_initializer: bool = False,
    opset: int = 13,
) -> onnx.ModelProto:
    data_input = helper.make_tensor_value_info("data", data_dtype, data_shape)
    inputs = [data_input]
    initializers = []
    value_infos = []
    if indices_as_initializer:
        if indices_values is None:
            raise ValueError("indices_values is required for initializer inputs")
        indices_tensor = helper.make_tensor(
            "indices",
            indices_dtype,
            dims=indices_shape,
            vals=indices_values.flatten().tolist(),
        )
        initializers.append(indices_tensor)
        value_infos.append(
            helper.make_tensor_value_info("indices", indices_dtype, indices_shape)
        )
    else:
        inputs.append(
            helper.make_tensor_value_info("indices", indices_dtype, indices_shape)
        )
    axis_index = axis if axis >= 0 else axis + len(data_shape)
    output_shape = (
        data_shape[:axis_index] + indices_shape + data_shape[axis_index + 1 :]
    )
    output = helper.make_tensor_value_info("out", data_dtype, output_shape)
    node = helper.make_node(
        "Gather",
        inputs=["data", "indices"],
        outputs=[output.name],
        axis=axis,
    )
    graph = helper.make_graph(
        [node],
        "gather_graph",
        inputs,
        [output],
        initializer=initializers,
        value_info=value_infos,
    )
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", opset)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_gathernd_model(
    *,
    data_shape: list[int],
    indices_shape: list[int],
    batch_dims: int = 0,
    data_dtype: int = TensorProto.FLOAT,
    indices_dtype: int = TensorProto.INT64,
    indices_values: np.ndarray | None = None,
    indices_as_initializer: bool = False,
    opset: int = 13,
) -> onnx.ModelProto:
    data_input = helper.make_tensor_value_info("data", data_dtype, data_shape)
    inputs = [data_input]
    initializers = []
    value_infos = []
    if indices_as_initializer:
        if indices_values is None:
            raise ValueError("indices_values is required for initializer inputs")
        indices_tensor = helper.make_tensor(
            "indices",
            indices_dtype,
            dims=indices_shape,
            vals=indices_values.flatten().tolist(),
        )
        initializers.append(indices_tensor)
        value_infos.append(
            helper.make_tensor_value_info("indices", indices_dtype, indices_shape)
        )
    else:
        inputs.append(
            helper.make_tensor_value_info("indices", indices_dtype, indices_shape)
        )
    index_depth = indices_shape[-1]
    output_shape = indices_shape[:-1] + data_shape[batch_dims + index_depth :]
    output = helper.make_tensor_value_info("out", data_dtype, output_shape)
    attrs = {}
    if batch_dims:
        attrs["batch_dims"] = batch_dims
    node = helper.make_node(
        "GatherND",
        inputs=["data", "indices"],
        outputs=[output.name],
        **attrs,
    )
    graph = helper.make_graph(
        [node],
        "gathernd_graph",
        inputs,
        [output],
        initializer=initializers,
        value_info=value_infos,
    )
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", opset)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _average_pool_output_shape(
    input_shape: list[int],
    kernel_shape: list[int],
    strides: list[int],
    pads: list[int],
) -> list[int]:
    spatial_rank = len(input_shape) - 2
    if spatial_rank not in {1, 2, 3}:
        raise ValueError(f"Unsupported AveragePool spatial rank {spatial_rank}")
    batch, channels = input_shape[:2]
    in_spatial = input_shape[2:]
    pad_begin = pads[:spatial_rank]
    pad_end = pads[spatial_rank:]
    out_spatial = []
    for dim, kernel, stride, pad_start, pad_finish in zip(
        in_spatial, kernel_shape, strides, pad_begin, pad_end
    ):
        out_dim = (dim + pad_start + pad_finish - kernel) // stride + 1
        out_spatial.append(out_dim)
    return [batch, channels, *out_spatial]


def _average_pool_output_shape_auto_pad(
    input_shape: list[int],
    kernel_shape: list[int],
    strides: list[int],
    auto_pad: str,
    *,
    dilations: list[int] | None = None,
    ceil_mode: int = 0,
) -> list[int]:
    spatial_rank = len(input_shape) - 2
    if spatial_rank not in {1, 2, 3}:
        raise ValueError(f"Unsupported AveragePool spatial rank {spatial_rank}")
    if auto_pad not in {"SAME_UPPER", "SAME_LOWER", "VALID"}:
        raise ValueError(f"Unsupported auto_pad {auto_pad}")
    if dilations is None:
        dilations = [1] * spatial_rank
    batch, channels = input_shape[:2]
    in_spatial = input_shape[2:]
    pad_begin = []
    pad_end = []
    for dim, stride, dilation, kernel in zip(
        in_spatial, strides, dilations, kernel_shape
    ):
        effective_kernel = dilation * (kernel - 1) + 1
        if auto_pad == "VALID":
            pad_begin.append(0)
            pad_end.append(0)
            continue
        out_dim = math.ceil(dim / stride)
        pad_needed = max(0, (out_dim - 1) * stride + effective_kernel - dim)
        if auto_pad == "SAME_UPPER":
            pad_start = pad_needed // 2
        else:
            pad_start = (pad_needed + 1) // 2
        pad_begin.append(pad_start)
        pad_end.append(pad_needed - pad_start)
    out_spatial = []
    for dim, stride, dilation, kernel, pad_start, pad_finish in zip(
        in_spatial, strides, dilations, kernel_shape, pad_begin, pad_end
    ):
        effective_kernel = dilation * (kernel - 1) + 1
        numerator = dim + pad_start + pad_finish - effective_kernel
        if ceil_mode:
            out_dim = (numerator + stride - 1) // stride + 1
            if (out_dim - 1) * stride >= dim + pad_start:
                out_dim -= 1
        else:
            out_dim = numerator // stride + 1
        out_spatial.append(out_dim)
    return [batch, channels, *out_spatial]


def _tensorproto_to_dtype(elem_type: int) -> np.dtype:
    mapping = {
        TensorProto.FLOAT: np.float32,
        TensorProto.DOUBLE: np.float64,
        TensorProto.INT64: np.int64,
        TensorProto.INT32: np.int32,
        TensorProto.INT16: np.int16,
        TensorProto.INT8: np.int8,
        TensorProto.UINT64: np.uint64,
        TensorProto.UINT32: np.uint32,
        TensorProto.UINT16: np.uint16,
        TensorProto.UINT8: np.uint8,
        TensorProto.BOOL: np.bool_,
    }
    try:
        return np.dtype(mapping[elem_type])
    except KeyError as exc:
        raise ValueError(f"Unsupported elem_type {elem_type}") from exc


def _value_info_shape(value_info: onnx.ValueInfoProto) -> list[int]:
    shape = []
    tensor_shape = value_info.type.tensor_type.shape
    for dim in tensor_shape.dim:
        if dim.dim_value > 0:
            shape.append(dim.dim_value)
        else:
            shape.append(1)
    return shape


def _make_random_array(
    rng: np.random.Generator, *, shape: list[int], dtype: np.dtype
) -> np.ndarray:
    if dtype == np.bool_:
        return rng.integers(0, 2, size=shape, dtype=np.int64).astype(dtype)
    if np.issubdtype(dtype, np.floating):
        return rng.standard_normal(shape).astype(dtype)
    if np.issubdtype(dtype, np.unsignedinteger):
        return rng.integers(0, 5, size=shape, dtype=np.int64).astype(dtype)
    if np.issubdtype(dtype, np.signedinteger):
        return rng.integers(-5, 5, size=shape, dtype=np.int64).astype(dtype)
    raise ValueError(f"Unsupported dtype {dtype}")


def _gathernd_numpy(
    data: np.ndarray, indices: np.ndarray, *, batch_dims: int = 0
) -> np.ndarray:
    index_depth = indices.shape[-1]
    tail_shape = data.shape[batch_dims + index_depth :]
    output = np.empty(indices.shape[:-1] + tail_shape, dtype=data.dtype)
    prefix_shape = indices.shape[:-1]
    prefix_iter = np.ndindex(*prefix_shape) if prefix_shape else [()]
    for prefix in prefix_iter:
        raw_index = indices[prefix]
        if index_depth == 1:
            index_values = [int(np.asarray(raw_index).item())]
        else:
            index_values = [int(value) for value in raw_index]
        for dim_index, value in enumerate(index_values):
            if value < 0:
                index_values[dim_index] = value + data.shape[
                    batch_dims + dim_index
                ]
        data_index = list(prefix[:batch_dims]) + index_values
        data_index.extend([slice(None)] * len(tail_shape))
        output_index = prefix + (slice(None),) * len(tail_shape)
        output[output_index] = data[tuple(data_index)]
    return output


def _rotary_embedding_numpy(
    input_value: np.ndarray,
    cos_cache: np.ndarray,
    sin_cache: np.ndarray,
    *,
    interleaved: bool = False,
    rotary_embedding_dim: int = 0,
) -> np.ndarray:
    original_shape = input_value.shape
    if input_value.ndim == 4:
        input_value = np.transpose(input_value, (0, 2, 1, 3))
    head_size = input_value.shape[-1]
    if rotary_embedding_dim == 0:
        rotary_embedding_dim = head_size
    x_rotate = input_value[..., :rotary_embedding_dim]
    x_not_rotate = input_value[..., rotary_embedding_dim:]
    cos_cache = np.expand_dims(cos_cache, axis=2)
    sin_cache = np.expand_dims(sin_cache, axis=2)
    if interleaved:
        x1 = x_rotate[..., 0::2]
        x2 = x_rotate[..., 1::2]
    else:
        x1, x2 = np.split(x_rotate, 2, axis=-1)
    real = (cos_cache * x1) - (sin_cache * x2)
    imag = (sin_cache * x1) + (cos_cache * x2)
    if interleaved:
        real = np.expand_dims(real, axis=-1)
        imag = np.expand_dims(imag, axis=-1)
        x_rotate_concat = np.concatenate((real, imag), axis=-1)
        x_rotate = np.reshape(x_rotate_concat, x_rotate.shape)
    else:
        x_rotate = np.concatenate((real, imag), axis=-1)
    output = np.concatenate((x_rotate, x_not_rotate), axis=-1)
    if len(original_shape) == 4:
        output = np.transpose(output, (0, 2, 1, 3))
    return output


def _run_ort_compare(model: onnx.ModelProto) -> None:
    initializer_names = {init.name for init in model.graph.initializer}
    rng = np.random.default_rng(0)
    inputs: dict[str, np.ndarray] = {}
    for value_info in model.graph.input:
        if value_info.name in initializer_names:
            continue
        elem_type = value_info.type.tensor_type.elem_type
        dtype = _tensorproto_to_dtype(elem_type)
        shape = _value_info_shape(value_info)
        inputs[value_info.name] = _make_random_array(
            rng, shape=shape, dtype=dtype
        )
    session = ort.InferenceSession(
        model.SerializeToString(), providers=["CPUExecutionProvider"]
    )
    ort_outputs = session.run(None, inputs)
    reference_outputs = _run_reference(model, inputs)
    try:
        for output_info, ort_output in zip(model.graph.output, ort_outputs):
            output_name = output_info.name
            compiled_output = reference_outputs[output_name]
            if np.issubdtype(compiled_output.dtype, np.floating):
                np.testing.assert_allclose(
                    compiled_output,
                    ort_output,
                    rtol=1e-4,
                    atol=1e-5,
                )
            else:
                np.testing.assert_array_equal(compiled_output, ort_output)
    except AssertionError:
        op_types = {node.op_type for node in model.graph.node}
        if op_types & {"OneHot", "BatchNormalization"}:
            pytest.xfail(
                "ONNX ReferenceEvaluator diverges from ORT for this op"
            )
        raise


def test_rotary_embedding_numpy_match() -> None:
    model = _make_operator_model(
        op_type="RotaryEmbedding",
        input_shapes=[[1, 2, 3, 4], [1, 3, 2], [1, 3, 2]],
        output_shape=[1, 2, 3, 4],
        dtype=TensorProto.FLOAT,
        attrs={},
        opset=23,
    )
    rng = np.random.default_rng(0)
    inputs = {
        "in0": rng.normal(size=(1, 2, 3, 4)).astype(np.float32),
        "in1": rng.normal(size=(1, 3, 2)).astype(np.float32),
        "in2": rng.normal(size=(1, 3, 2)).astype(np.float32),
    }
    reference_outputs = _run_reference(model, inputs)
    expected = _rotary_embedding_numpy(
        inputs["in0"],
        inputs["in1"],
        inputs["in2"],
    )
    np.testing.assert_allclose(
        reference_outputs["out"], expected, rtol=1e-4, atol=1e-5
    )


def test_rotary_embedding_ort_compare() -> None:
    model = _make_operator_model(
        op_type="RotaryEmbedding",
        input_shapes=[[1, 2, 3, 4], [1, 3, 2], [1, 3, 2]],
        output_shape=[1, 2, 3, 4],
        dtype=TensorProto.FLOAT,
        attrs={},
        opset=23,
    )
    _run_ort_compare_or_skip(
        model,
        skip_substrings=("NOT_IMPLEMENTED", "RotaryEmbedding"),
    )


def _run_ort_compare_or_skip(
    model: onnx.ModelProto, *, skip_substrings: tuple[str, ...]
) -> None:
    try:
        _run_ort_compare(model)
    except Exception as exc:  # noqa: BLE001 - keep test behavior aligned with CLI skip
        if any(substr in str(exc) for substr in skip_substrings):
            pytest.skip(
                "onnxruntime does not implement this operator in the test "
                "environment."
            )
        raise


def _compile_and_run_testbench(
    model: onnx.ModelProto, *, testbench_inputs: dict[str, np.ndarray]
) -> dict[str, object]:
    compiler_cmd = os.environ.get("CC") or shutil.which("cc") or shutil.which("gcc")
    if compiler_cmd is None:
        pytest.skip("C compiler not available (set CC or install gcc/clang)")
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        c_path = temp_path / "model.c"
        exe_path = temp_path / "model"
        options = CompilerOptions(
            emit_testbench=True,
            testbench_inputs=testbench_inputs,
        )
        compiler = Compiler(options)
        generated = compiler.compile(model)
        c_path.write_text(generated, encoding="utf-8")
        subprocess.run(
            [compiler_cmd, "-std=c99", "-O2", str(c_path), "-o", str(exe_path), "-lm"],
            check=True,
            capture_output=True,
            text=True,
        )
        input_path = temp_path / "inputs.bin"
        initializer_names = {init.name for init in model.graph.initializer}
        with input_path.open("wb") as handle:
            for value_info in model.graph.input:
                if value_info.name in initializer_names:
                    continue
                array = testbench_inputs.get(value_info.name)
                if array is None:
                    raise AssertionError(
                        f"Missing testbench input {value_info.name}"
                    )
                handle.write(
                    np.ascontiguousarray(array).tobytes(order="C")
                )
        result = subprocess.run(
            [str(exe_path), str(input_path)],
            check=True,
            capture_output=True,
            text=True,
        )
    return json.loads(result.stdout)


def _run_testbench_compare(model: onnx.ModelProto) -> None:
    initializer_names = {init.name for init in model.graph.initializer}
    rng = np.random.default_rng(0)
    inputs: dict[str, np.ndarray] = {}
    for value_info in model.graph.input:
        if value_info.name in initializer_names:
            continue
        elem_type = value_info.type.tensor_type.elem_type
        dtype = _tensorproto_to_dtype(elem_type)
        shape = _value_info_shape(value_info)
        inputs[value_info.name] = _make_random_array(
            rng, shape=shape, dtype=dtype
        )
    session = ort.InferenceSession(
        model.SerializeToString(), providers=["CPUExecutionProvider"]
    )
    ort_outputs = session.run(None, inputs)
    payload = _compile_and_run_testbench(model, testbench_inputs=inputs)
    outputs_payload = payload.get("outputs", {})
    for output_info, ort_output in zip(model.graph.output, ort_outputs):
        output_payload = outputs_payload.get(output_info.name)
        if output_payload is None:
            raise AssertionError(f"Missing output {output_info.name} in testbench data")
        output_data = decode_testbench_array(
            output_payload["data"], ort_output.dtype
        )
        output_data = output_data.reshape(ort_output.shape)
        if np.issubdtype(ort_output.dtype, np.floating):
            np.testing.assert_allclose(
                output_data,
                ort_output,
                rtol=1e-4,
                atol=1e-5,
            )
        else:
            np.testing.assert_array_equal(output_data, ort_output)


def test_tfidf_vectorizer_testbench_match() -> None:
    model = _make_tfidf_vectorizer_model(
        input_shape=[4],
        output_shape=[3],
        mode="TF",
        min_gram_length=1,
        max_gram_length=1,
        max_skip_count=0,
        ngram_counts=[0],
        ngram_indexes=[0, 1, 2],
        pool_int64s=[1, 2, 3],
    )
    inputs = {"in0": np.array([1, 2, 1, 4], dtype=np.int32)}
    reference_outputs = _run_reference(model, inputs)
    payload = _compile_and_run_testbench(model, testbench_inputs=inputs)
    output_payload = payload.get("outputs", {}).get("out")
    if output_payload is None:
        raise AssertionError("Missing output out in testbench data")
    output_data = decode_testbench_array(
        output_payload["data"], reference_outputs["out"].dtype
    )
    output_data = output_data.reshape(reference_outputs["out"].shape)
    np.testing.assert_allclose(
        output_data, reference_outputs["out"], rtol=1e-5, atol=1e-6
    )


OPERATOR_CASES = [
    {
        "name": "AndBool",
        "op_type": "And",
        "input_shapes": [[2, 3], [2, 3]],
        "output_shape": [2, 3],
        "dtype": TensorProto.BOOL,
        "attrs": {},
    },
    {
        "name": "NotBool",
        "op_type": "Not",
        "input_shapes": [[2, 3]],
        "output_shape": [2, 3],
        "dtype": TensorProto.BOOL,
        "attrs": {},
    },
    {
        "name": "FlattenAxis1",
        "op_type": "Flatten",
        "input_shapes": [[2, 3, 4]],
        "output_shape": [2, 12],
        "dtype": TensorProto.FLOAT,
        "attrs": {"axis": 1},
    },
    {
        "name": "AddInt64",
        "op_type": "Add",
        "input_shapes": [[2, 3], [2, 3]],
        "output_shape": [2, 3],
        "dtype": TensorProto.INT64,
        "attrs": {},
    },
    {
        "name": "AddInt32",
        "op_type": "Add",
        "input_shapes": [[2, 3], [2, 3]],
        "output_shape": [2, 3],
        "dtype": TensorProto.INT32,
        "attrs": {},
    },
    {
        "name": "AddInt16",
        "op_type": "Add",
        "input_shapes": [[2, 3], [2, 3]],
        "output_shape": [2, 3],
        "dtype": TensorProto.INT16,
        "attrs": {},
        "opset": 14,
    },
    {
        "name": "AddInt8",
        "op_type": "Add",
        "input_shapes": [[2, 3], [2, 3]],
        "output_shape": [2, 3],
        "dtype": TensorProto.INT8,
        "attrs": {},
        "opset": 14,
    },
    {
        "name": "AddUint64",
        "op_type": "Add",
        "input_shapes": [[2, 3], [2, 3]],
        "output_shape": [2, 3],
        "dtype": TensorProto.UINT64,
        "attrs": {},
        "opset": 14,
    },
    {
        "name": "AddUint32",
        "op_type": "Add",
        "input_shapes": [[2, 3], [2, 3]],
        "output_shape": [2, 3],
        "dtype": TensorProto.UINT32,
        "attrs": {},
        "opset": 14,
    },
    {
        "name": "AddUint16",
        "op_type": "Add",
        "input_shapes": [[2, 3], [2, 3]],
        "output_shape": [2, 3],
        "dtype": TensorProto.UINT16,
        "attrs": {},
        "opset": 14,
    },
    {
        "name": "AddUint8",
        "op_type": "Add",
        "input_shapes": [[2, 3], [2, 3]],
        "output_shape": [2, 3],
        "dtype": TensorProto.UINT8,
        "attrs": {},
        "opset": 14,
    },
    {
        "name": "Pow",
        "op_type": "Pow",
        "input_shapes": [[2, 3], [2, 3]],
        "output_shape": [2, 3],
        "dtype": TensorProto.FLOAT,
        "attrs": {},
        "opset": 13,
    },
    {
        "name": "Mod",
        "op_type": "Mod",
        "input_shapes": [[2, 3], [2, 3]],
        "output_shape": [2, 3],
        "dtype": TensorProto.FLOAT,
        "attrs": {"fmod": 1},
        "opset": 13,
    },
    {
        "name": "Min",
        "op_type": "Min",
        "input_shapes": [[2, 3], [2, 3]],
        "output_shape": [2, 3],
        "dtype": TensorProto.FLOAT,
        "attrs": {},
        "opset": 13,
    },
    {
        "name": "Max",
        "op_type": "Max",
        "input_shapes": [[2, 3], [2, 3]],
        "output_shape": [2, 3],
        "dtype": TensorProto.FLOAT,
        "attrs": {},
        "opset": 13,
    },
    {
        "name": "Mean",
        "op_type": "Mean",
        "input_shapes": [[2, 3], [2, 3]],
        "output_shape": [2, 3],
        "dtype": TensorProto.FLOAT,
        "attrs": {},
        "opset": 13,
    },
    {
        "name": "Sum",
        "op_type": "Sum",
        "input_shapes": [[2, 3], [2, 3]],
        "output_shape": [2, 3],
        "dtype": TensorProto.FLOAT,
        "attrs": {},
        "opset": 13,
    },
    {
        "name": "PRelu",
        "op_type": "PRelu",
        "input_shapes": [[2, 3], [2, 3]],
        "output_shape": [2, 3],
        "dtype": TensorProto.FLOAT,
        "attrs": {},
        "opset": 13,
    },
    {
        "name": "MatMul",
        "op_type": "MatMul",
        "input_shapes": [[2, 3], [3, 4]],
        "output_shape": [2, 4],
        "dtype": TensorProto.FLOAT,
        "attrs": {},
    },
    {
        "name": "MatMulVectorVector",
        "op_type": "MatMul",
        "input_shapes": [[3], [3]],
        "output_shape": [],
        "dtype": TensorProto.FLOAT,
        "attrs": {},
    },
    {
        "name": "MatMulVectorMatrix",
        "op_type": "MatMul",
        "input_shapes": [[3], [3, 4]],
        "output_shape": [4],
        "dtype": TensorProto.FLOAT,
        "attrs": {},
    },
    {
        "name": "MatMulMatrixVector",
        "op_type": "MatMul",
        "input_shapes": [[2, 3], [3]],
        "output_shape": [2],
        "dtype": TensorProto.FLOAT,
        "attrs": {},
    },
    {
        "name": "MatMulBatch",
        "op_type": "MatMul",
        "input_shapes": [[2, 3, 4], [2, 4, 5]],
        "output_shape": [2, 3, 5],
        "dtype": TensorProto.FLOAT,
        "attrs": {},
    },
    {
        "name": "MatMulBroadcastBatch",
        "op_type": "MatMul",
        "input_shapes": [[1, 3, 4], [2, 4, 5]],
        "output_shape": [2, 3, 5],
        "dtype": TensorProto.FLOAT,
        "attrs": {},
    },
    {
        "name": "EinsumReduceAll",
        "op_type": "Einsum",
        "input_shapes": [[]],
        "output_shape": [],
        "dtype": TensorProto.FLOAT,
        "attrs": {"equation": "->"},
    },
    {
        "name": "EinsumSumJ",
        "op_type": "Einsum",
        "input_shapes": [[3, 4]],
        "output_shape": [3],
        "dtype": TensorProto.FLOAT,
        "attrs": {"equation": "ij->i"},
    },
    {
        "name": "EinsumTranspose",
        "op_type": "Einsum",
        "input_shapes": [[3, 4]],
        "output_shape": [4, 3],
        "dtype": TensorProto.FLOAT,
        "attrs": {"equation": "ij->ji"},
    },
    {
        "name": "EinsumDot",
        "op_type": "Einsum",
        "input_shapes": [[5], [5]],
        "output_shape": [],
        "dtype": TensorProto.FLOAT,
        "attrs": {"equation": "i,i"},
    },
    {
        "name": "EinsumBatchMatMul",
        "op_type": "Einsum",
        "input_shapes": [[2, 3, 4], [2, 4, 5]],
        "output_shape": [2, 3, 5],
        "dtype": TensorProto.FLOAT,
        "attrs": {"equation": "bij,bjk->bik"},
    },
    {
        "name": "EinsumBatchDiagonal",
        "op_type": "Einsum",
        "input_shapes": [[3, 5, 5]],
        "output_shape": [3, 5],
        "dtype": TensorProto.FLOAT,
        "attrs": {"equation": "...ii->...i"},
    },
    {
        "name": "Gemm",
        "op_type": "Gemm",
        "input_shapes": [[2, 3], [3, 4]],
        "output_shape": [2, 4],
        "dtype": TensorProto.FLOAT,
        "attrs": {},
        "opset": 13,
    },
    {
        "name": "GemmBiasBroadcast",
        "op_type": "Gemm",
        "input_shapes": [[3, 2], [3, 4], [4]],
        "output_shape": [2, 4],
        "dtype": TensorProto.FLOAT,
        "attrs": {"transA": 1, "alpha": 0.5, "beta": 1.5},
        "opset": 13,
    },
    {
        "name": "GemmScalarBias",
        "op_type": "Gemm",
        "input_shapes": [[2, 3], [3, 4], []],
        "output_shape": [2, 4],
        "dtype": TensorProto.FLOAT,
        "attrs": {"beta": 0.5},
        "opset": 13,
    },
    {
        "name": "GemmTransBColumnBias",
        "op_type": "Gemm",
        "input_shapes": [[2, 3], [4, 3], [2, 1]],
        "output_shape": [2, 4],
        "dtype": TensorProto.FLOAT,
        "attrs": {"transB": 1, "alpha": 2.0, "beta": 0.75},
        "opset": 13,
    },
    {
        "name": "ConcatAxis0",
        "op_type": "Concat",
        "input_shapes": [[2, 3], [1, 3]],
        "output_shape": [3, 3],
        "dtype": TensorProto.FLOAT,
        "attrs": {"axis": 0},
    },
    {
        "name": "ConcatAxis1MultipleInputs",
        "op_type": "Concat",
        "input_shapes": [[2, 1, 4], [2, 2, 4], [2, 3, 4]],
        "output_shape": [2, 6, 4],
        "dtype": TensorProto.FLOAT,
        "attrs": {"axis": 1},
    },
    {
        "name": "ConcatAxisNegative",
        "op_type": "Concat",
        "input_shapes": [[1, 2, 3], [1, 2, 1]],
        "output_shape": [1, 2, 4],
        "dtype": TensorProto.FLOAT,
        "attrs": {"axis": -1},
    },
    {
        "name": "Attention",
        "op_type": "Attention",
        "input_shapes": [[1, 2, 3, 4], [1, 2, 5, 4], [1, 2, 5, 4]],
        "output_shape": [1, 2, 3, 4],
        "dtype": TensorProto.FLOAT,
        "attrs": {},
        "opset": 23,
    },
    {
        "name": "Attention3DGQAWithMask",
        "op_type": "Attention",
        "input_shapes": [[1, 4, 16], [1, 6, 8], [1, 6, 10], [4, 6]],
        "output_shape": [1, 4, 20],
        "dtype": TensorProto.FLOAT,
        "attrs": {"q_num_heads": 4, "kv_num_heads": 2},
        "opset": 23,
    },
]

VARIADIC_OP_CASES = [
    {
        "name": "SumFloat",
        "op_type": "Sum",
        "dtype": TensorProto.FLOAT,
        "input_shape": [2, 3],
        "input_count": 3,
    },
    {
        "name": "MeanFloat",
        "op_type": "Mean",
        "dtype": TensorProto.FLOAT,
        "input_shape": [2, 3],
        "input_count": 3,
    },
    {
        "name": "MaxFloat",
        "op_type": "Max",
        "dtype": TensorProto.FLOAT,
        "input_shape": [2, 3],
        "input_count": 3,
    },
    {
        "name": "MinFloat",
        "op_type": "Min",
        "dtype": TensorProto.FLOAT,
        "input_shape": [2, 3],
        "input_count": 3,
    },
    {
        "name": "AndBool",
        "op_type": "And",
        "dtype": TensorProto.BOOL,
        "input_shape": [2, 3],
        "input_count": 2,
    },
    {
        "name": "OrBool",
        "op_type": "Or",
        "dtype": TensorProto.BOOL,
        "input_shape": [2, 3],
        "input_count": 2,
    },
    {
        "name": "XorBool",
        "op_type": "Xor",
        "dtype": TensorProto.BOOL,
        "input_shape": [2, 3],
        "input_count": 2,
    },
    {
        "name": "BitwiseAndInt32",
        "op_type": "BitwiseAnd",
        "dtype": TensorProto.INT32,
        "input_shape": [2, 3],
        "input_count": 2,
        "opset": 18,
    },
    {
        "name": "BitwiseOrInt32",
        "op_type": "BitwiseOr",
        "dtype": TensorProto.INT32,
        "input_shape": [2, 3],
        "input_count": 2,
        "opset": 18,
    },
    {
        "name": "BitwiseXorInt32",
        "op_type": "BitwiseXor",
        "dtype": TensorProto.INT32,
        "input_shape": [2, 3],
        "input_count": 2,
        "opset": 18,
    },
]

COMPARE_CASES = [
    {
        "name": "EqualFloat",
        "op_type": "Equal",
        "input_shapes": [[2, 3], [2, 3]],
        "output_shape": [2, 3],
        "input_dtype": TensorProto.FLOAT,
        "opset": 13,
    },
    {
        "name": "GreaterFloat",
        "op_type": "Greater",
        "input_shapes": [[2, 3], [2, 3]],
        "output_shape": [2, 3],
        "input_dtype": TensorProto.FLOAT,
        "opset": 13,
    },
    {
        "name": "GreaterOrEqualFloat",
        "op_type": "GreaterOrEqual",
        "input_shapes": [[2, 3], [2, 3]],
        "output_shape": [2, 3],
        "input_dtype": TensorProto.FLOAT,
        "opset": 13,
    },
    {
        "name": "LessFloat",
        "op_type": "Less",
        "input_shapes": [[2, 3], [2, 3]],
        "output_shape": [2, 3],
        "input_dtype": TensorProto.FLOAT,
        "opset": 13,
    },
    {
        "name": "LessOrEqualFloat",
        "op_type": "LessOrEqual",
        "input_shapes": [[2, 3], [2, 3]],
        "output_shape": [2, 3],
        "input_dtype": TensorProto.FLOAT,
        "opset": 13,
    },
]

REDUCE_CASES = [
    {
        "name": "ReduceSumAxis1KeepDims",
        "op_type": "ReduceSum",
        "input_shape": [2, 3, 4],
        "axes": [1],
        "keepdims": 1,
    },
    {
        "name": "ReduceSumAxis1NoKeepDims",
        "op_type": "ReduceSum",
        "input_shape": [2, 3, 4],
        "axes": [1],
        "keepdims": 0,
    },
    {
        "name": "ReduceMeanAxis1",
        "op_type": "ReduceMean",
        "input_shape": [2, 3, 4],
        "axes": [1],
        "keepdims": 1,
    },
    {
        "name": "ReduceMaxAxis1",
        "op_type": "ReduceMax",
        "input_shape": [2, 3, 4],
        "axes": [1],
        "keepdims": 1,
    },
    {
        "name": "ReduceMinAxis1",
        "op_type": "ReduceMin",
        "input_shape": [2, 3, 4],
        "axes": [1],
        "keepdims": 1,
    },
    {
        "name": "ReduceProdAxis1",
        "op_type": "ReduceProd",
        "input_shape": [2, 3, 4],
        "axes": [1],
        "keepdims": 1,
    },
    {
        "name": "ReduceL1Axis1",
        "op_type": "ReduceL1",
        "input_shape": [2, 3, 4],
        "axes": [1],
        "keepdims": 1,
    },
    {
        "name": "ReduceL2Axis1",
        "op_type": "ReduceL2",
        "input_shape": [2, 3, 4],
        "axes": [1],
        "keepdims": 1,
    },
    {
        "name": "ReduceLogSumAxis1",
        "op_type": "ReduceLogSum",
        "input_shape": [2, 3, 4],
        "axes": [1],
        "keepdims": 1,
    },
    {
        "name": "ReduceLogSumExpAxis1",
        "op_type": "ReduceLogSumExp",
        "input_shape": [2, 3, 4],
        "axes": [1],
        "keepdims": 1,
    },
    {
        "name": "ReduceSumSquareAxis1",
        "op_type": "ReduceSumSquare",
        "input_shape": [2, 3, 4],
        "axes": [1],
        "keepdims": 1,
    },
]

ARG_REDUCE_CASES = [
    {
        "name": "ArgMaxAxis0Keepdims",
        "op_type": "ArgMax",
        "input_shape": [3, 4],
        "axis": 0,
        "keepdims": 1,
        "select_last_index": 0,
    },
    {
        "name": "ArgMinAxis1NoKeepdims",
        "op_type": "ArgMin",
        "input_shape": [2, 5],
        "axis": 1,
        "keepdims": 0,
        "select_last_index": 0,
    },
    {
        "name": "ArgMaxAxisNeg1",
        "op_type": "ArgMax",
        "input_shape": [2, 3, 4],
        "axis": -1,
        "keepdims": 0,
        "select_last_index": 0,
    },
]

TOPK_CASES = [
    {
        "name": "TopKLargestAxis1",
        "input_shape": [3, 4],
        "axis": 1,
        "k": 2,
        "largest": 1,
        "sorted": 1,
    },
    {
        "name": "TopKSmallestAxis0",
        "input_shape": [4, 3],
        "axis": 0,
        "k": 2,
        "largest": 0,
        "sorted": 1,
    },
    {
        "name": "TopKNegativeAxis",
        "input_shape": [2, 3, 4],
        "axis": -1,
        "k": 3,
        "largest": 1,
        "sorted": 1,
    },
]

AVG_POOL_CASES = [
    {
        "name": "Kernel2Stride2",
        "input_shape": [1, 1, 4, 4],
        "kernel_shape": [2, 2],
        "strides": [2, 2],
        "pads": [0, 0, 0, 0],
        "count_include_pad": 0,
    },
    {
        "name": "Kernel3Stride1Pad",
        "input_shape": [1, 2, 5, 5],
        "kernel_shape": [3, 3],
        "strides": [1, 1],
        "pads": [1, 1, 1, 1],
        "count_include_pad": 0,
    },
    {
        "name": "Kernel3x2Stride2x1Pad",
        "input_shape": [1, 1, 5, 4],
        "kernel_shape": [3, 2],
        "strides": [2, 1],
        "pads": [0, 1, 0, 1],
        "count_include_pad": 1,
    },
    {
        "name": "Kernel2Stride2_1d",
        "input_shape": [1, 2, 6],
        "kernel_shape": [2],
        "strides": [2],
        "pads": [0, 1],
        "count_include_pad": 0,
    },
    {
        "name": "Kernel2Stride2_3d",
        "input_shape": [1, 1, 4, 4, 4],
        "kernel_shape": [2, 2, 2],
        "strides": [2, 2, 2],
        "pads": [0, 0, 0, 0, 0, 0],
        "count_include_pad": 0,
    },
]

MAXPOOL_CASES = [
    {
        "name": "MaxPool2dBasic",
        "input_shape": [1, 1, 4, 4],
        "kernel_shape": [2, 2],
        "strides": [2, 2],
        "pads": [0, 0, 0, 0],
        "ceil_mode": 0,
    },
    {
        "name": "MaxPool2dPadCeil",
        "input_shape": [1, 1, 3, 3],
        "kernel_shape": [2, 2],
        "strides": [2, 2],
        "pads": [1, 1, 1, 1],
        "ceil_mode": 1,
    },
]

REARRANGE_ORT_CASES = [
    {
        "name": "Identity",
        "model": lambda: _make_operator_model(
            op_type="Identity",
            input_shapes=[[2, 3]],
            output_shape=[2, 3],
            dtype=TensorProto.FLOAT,
        ),
    },
    {
        "name": "EyeLike",
        "model": lambda: _make_eye_like_model(
            input_shape=[3, 4],
            dtype=TensorProto.FLOAT,
            k=0,
        ),
    },
    {
        "name": "Tile",
        "model": lambda: _make_tile_model(
            input_shape=[2, 1],
            repeats=[2, 3],
            dtype=TensorProto.FLOAT,
        ),
    },
    {
        "name": "PadConstant",
        "model": lambda: _make_pad_model(
            input_shape=[2, 3],
            pads=[1, 2, 3, 4],
            value=1.5,
            dtype=TensorProto.FLOAT,
        ),
    },
    {
        "name": "DepthToSpace",
        "model": lambda: _make_operator_model(
            op_type="DepthToSpace",
            input_shapes=[[1, 8, 2, 2]],
            output_shape=[1, 2, 4, 4],
            dtype=TensorProto.FLOAT,
            attrs={"blocksize": 2, "mode": "DCR"},
        ),
    },
    {
        "name": "SpaceToDepth",
        "model": lambda: _make_operator_model(
            op_type="SpaceToDepth",
            input_shapes=[[1, 2, 4, 4]],
            output_shape=[1, 8, 2, 2],
            dtype=TensorProto.FLOAT,
            attrs={"blocksize": 2},
        ),
    },
    {
        "name": "TriluUpperKInput",
        "model": lambda: _make_trilu_model(
            input_shape=[2, 3, 4],
            dtype=TensorProto.FLOAT,
            upper=True,
            include_k_input=True,
        ),
    },
]

REARRANGE_UNIT_CASES = [
    {
        "name": "Identity",
        "model": REARRANGE_ORT_CASES[0]["model"],
        "input_name": "in0",
        "input_shape": (2, 3),
        "expected": lambda value: value,
    },
    {
        "name": "EyeLike",
        "model": REARRANGE_ORT_CASES[1]["model"],
        "input_name": "input",
        "input_shape": (3, 4),
        "expected": lambda value: np.eye(3, 4, dtype=value.dtype),
    },
    {
        "name": "Tile",
        "model": REARRANGE_ORT_CASES[2]["model"],
        "input_name": "input",
        "input_shape": (2, 1),
        "expected": lambda value: np.tile(value, (2, 3)),
    },
    {
        "name": "PadConstant",
        "model": REARRANGE_ORT_CASES[3]["model"],
        "input_name": "input",
        "input_shape": (2, 3),
        "expected": lambda value: np.pad(
            value, ((1, 3), (2, 4)), mode="constant", constant_values=1.5
        ),
    },
    {
        "name": "DepthToSpace",
        "model": REARRANGE_ORT_CASES[4]["model"],
        "input_name": "in0",
        "input_shape": (1, 8, 2, 2),
        "expected": lambda value: _depth_to_space_reference(
            value, blocksize=2, mode="DCR"
        ),
    },
    {
        "name": "SpaceToDepth",
        "model": REARRANGE_ORT_CASES[5]["model"],
        "input_name": "in0",
        "input_shape": (1, 2, 4, 4),
        "expected": lambda value: _space_to_depth_reference(value, blocksize=2),
    },
    {
        "name": "TriluUpper",
        "model": lambda: _make_trilu_model(
            input_shape=[3, 4],
            dtype=TensorProto.FLOAT,
            upper=True,
            k=1,
        ),
        "input_name": "input",
        "input_shape": (3, 4),
        "expected": lambda value: np.triu(value, k=1),
    },
]


def test_lower_flatten_axis_default() -> None:
    model = _make_flatten_model([2, 3, 4], axis=1)
    graph = import_onnx(model)
    op = lower_flatten(graph, graph.nodes[0])
    assert op.input_shape == (2, 3, 4)
    assert op.output_shape == (2, 12)
    assert op.dtype == ScalarType.F32


def test_lower_flatten_negative_axis() -> None:
    model = _make_flatten_model([2, 3, 4], axis=-1)
    graph = import_onnx(model)
    op = lower_flatten(graph, graph.nodes[0])
    assert op.output_shape == (6, 4)


def test_lower_onehot_axis_normalization() -> None:
    model = _make_onehot_model(
        indices_shape=[2, 3],
        depth=4,
        axis=-1,
        indices_dtype=TensorProto.INT64,
        values_dtype=TensorProto.FLOAT,
    )
    graph = import_onnx(model)
    op = lower_onehot(graph, graph.nodes[0])
    assert op.axis == 2
    assert op.output_shape == (2, 3, 4)
    assert op.depth_dim == 4


def test_lower_convinteger_per_channel_zero_point() -> None:
    model = _make_convinteger_model(per_channel_zero_point=True)
    graph = import_onnx(model)
    op = lower_conv_integer(graph, graph.nodes[0])
    assert op.dtype == ScalarType.I32
    assert op.input_dtype == ScalarType.U8
    assert op.weight_dtype == ScalarType.U8
    assert op.w_zero_point_per_channel is True
    assert op.out_spatial == (4, 4)


def test_lower_pad_dynamic_axes_input() -> None:
    input_info = helper.make_tensor_value_info(
        "input", TensorProto.FLOAT, [2, 3]
    )
    pads_info = helper.make_tensor_value_info("pads", TensorProto.INT64, [4])
    axes_info = helper.make_tensor_value_info("axes", TensorProto.INT64, [2])
    output_info = helper.make_tensor_value_info(
        "output", TensorProto.FLOAT, [2, 3]
    )
    node = helper.make_node(
        "Pad",
        inputs=["input", "pads", "", "axes"],
        outputs=[output_info.name],
        mode="constant",
    )
    graph = helper.make_graph(
        [node],
        "pad_axes_graph",
        [input_info, pads_info, axes_info],
        [output_info],
    )
    model = helper.make_model(
        graph,
        producer_name="onnx2c",
        opset_imports=[helper.make_operatorsetid("", 18)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    graph = import_onnx(model)
    op = get_lowering("Pad")(graph, graph.nodes[0])
    assert op.pads_input == "pads"
    assert op.pads_shape == (4,)
    assert op.axes_input == "axes"
    assert op.axes_shape == (2,)
    assert op.pads_begin is None
    assert op.pads_end is None


def test_lower_scatternd_shapes() -> None:
    indices = np.array([[0, 1], [1, 2]], dtype=np.int64)
    model = _make_scatternd_model(
        data_shape=[3, 3],
        indices=indices,
        updates_shape=[2],
        dtype=TensorProto.FLOAT,
        reduction="add",
    )
    graph = import_onnx(model)
    op = lower_scatternd(graph, graph.nodes[0])
    assert op.data_shape == (3, 3)
    assert op.indices_shape == (2, 2)
    assert op.updates_shape == (2,)
    assert op.output_shape == (3, 3)
    assert op.reduction == "add"


def test_lower_squeeze_axes_input() -> None:
    model = _make_squeeze_lowering_model(
        [1, 3, 1, 5],
        [3, 5],
        axes=[0, 2],
        include_axes_input=True,
    )
    graph = import_onnx(model)
    op = lower_squeeze(graph, graph.nodes[0])
    assert op.input_shape == (1, 3, 1, 5)
    assert op.output_shape == (3, 5)
    assert op.dtype == ScalarType.F32


def test_lower_squeeze_default_axes() -> None:
    model = _make_squeeze_lowering_model([1, 3, 1, 5], [3, 5])
    graph = import_onnx(model)
    op = lower_squeeze(graph, graph.nodes[0])
    assert op.output_shape == (3, 5)


def test_lower_gridsample_builds_spec() -> None:
    model = _make_gridsample_model(
        input_shape=[1, 2, 3, 4],
        grid_shape=[1, 5, 6, 2],
        output_shape=[1, 2, 5, 6],
    )
    graph = import_onnx(model)
    op = lower_grid_sample(graph, graph.nodes[0])
    assert op.spatial_rank == 2
    assert op.input_spatial == (3, 4)
    assert op.output_spatial == (5, 6)
    assert op.mode == "linear"


def test_lower_upsample_scales_initializer() -> None:
    model = _make_upsample_model()
    graph = import_onnx(model)
    op = lower_upsample(graph, graph.nodes[0])
    assert isinstance(op, ResizeOp)
    assert op.scales == (1.0, 1.0, 2.0, 3.0)
    assert op.mode == "nearest"
    assert op.coordinate_transformation_mode == "asymmetric"
    assert op.nearest_mode == "floor"


def test_lower_variadic_sum_uses_multi_input_op() -> None:
    model = _make_operator_model(
        op_type="Sum",
        input_shapes=[[2, 2], [2, 2], [2, 2]],
        output_shape=[2, 2],
        dtype=TensorProto.FLOAT,
    )
    graph = import_onnx(model)
    lowering = get_lowering("Sum")
    assert lowering is not None
    op = lowering(graph, graph.nodes[0])
    assert isinstance(op, MultiInputBinaryOp)
    assert op.inputs == ("in0", "in1", "in2")


def test_lower_einsum_transpose() -> None:
    model = _make_operator_model(
        op_type="Einsum",
        input_shapes=[[2, 3]],
        output_shape=[3, 2],
        dtype=TensorProto.FLOAT,
        attrs={"equation": "ij->ji"},
    )
    graph = import_onnx(model)
    lowering = get_lowering("Einsum")
    assert lowering is not None
    op = lowering(graph, graph.nodes[0])
    assert isinstance(op, EinsumOp)
    assert op.kind == EinsumKind.TRANSPOSE
    assert op.output_shape == (3, 2)


def test_lower_shape_resolves_dim_params() -> None:
    model = _make_shape_dim_param_model()
    graph = import_onnx(model)
    op = lower_shape(graph, graph.nodes[1])
    assert op.input_shape == (6,)
    assert op.output_shape == (1,)
    assert op.values == (6,)
    assert op.input_dtype == ScalarType.F32
    assert op.dtype == ScalarType.I64


def test_lower_shape_missing_value() -> None:
    output_value = Value(
        name="out",
        type=TensorType(
            dtype=ScalarType.I64,
            shape=(1,),
            dim_params=(None,),
        ),
    )
    node = Node(
        op_type="Shape",
        name=None,
        inputs=("missing",),
        outputs=("out",),
        attrs={},
    )
    graph = Graph(
        inputs=(),
        outputs=(output_value,),
        nodes=(node,),
        initializers=(),
    )
    with pytest.raises(
        ShapeInferenceError, match="Missing shape for value 'missing'"
    ):
        lower_shape(graph, node)


@pytest.mark.parametrize("case", OPERATOR_CASES, ids=lambda case: case["name"])
def test_operator_c_testbench_matches_onnxruntime(case: dict[str, object]) -> None:
    model = _make_operator_model(
        op_type=case["op_type"],
        input_shapes=case["input_shapes"],
        output_shape=case["output_shape"],
        dtype=case["dtype"],
        attrs=case["attrs"],
        opset=case.get("opset", 13),
    )
    _run_ort_compare(model)


@pytest.mark.parametrize("case", COMPARE_CASES, ids=lambda case: case["name"])
def test_compare_ops_match_onnxruntime(case: dict[str, object]) -> None:
    model = _make_compare_model(
        op_type=case["op_type"],
        input_shapes=case["input_shapes"],
        output_shape=case["output_shape"],
        input_dtype=case["input_dtype"],
        opset=case.get("opset", 13),
    )
    _run_ort_compare(model)


@pytest.mark.parametrize("case", VARIADIC_OP_CASES, ids=lambda case: case["name"])
def test_variadic_ops_match_onnxruntime(case: dict[str, object]) -> None:
    input_shape = case["input_shape"]
    input_count = case["input_count"]
    model = _make_operator_model(
        op_type=case["op_type"],
        input_shapes=[input_shape for _ in range(input_count)],
        output_shape=input_shape,
        dtype=case["dtype"],
        attrs={},
        opset=case.get("opset", 13),
    )
    _run_ort_compare(model)


@pytest.mark.parametrize("case", REDUCE_CASES, ids=lambda case: case["name"])
def test_reduce_op_matches_onnxruntime(case: dict[str, object]) -> None:
    output_shape = _reduce_output_shape(
        case["input_shape"], case["axes"], case["keepdims"]
    )
    model = _make_reduce_model(
        op_type=case["op_type"],
        input_shape=case["input_shape"],
        output_shape=output_shape,
        axes=case["axes"],
        keepdims=case["keepdims"],
        dtype=TensorProto.FLOAT,
    )
    _run_ort_compare(model)


@pytest.mark.parametrize("case", ARG_REDUCE_CASES, ids=lambda case: case["name"])
def test_arg_reduce_matches_onnxruntime(case: dict[str, object]) -> None:
    output_shape = _arg_reduce_output_shape(
        case["input_shape"], case["axis"], case["keepdims"]
    )
    model = _make_arg_reduce_model(
        op_type=case["op_type"],
        input_shape=case["input_shape"],
        output_shape=output_shape,
        axis=case["axis"],
        keepdims=case["keepdims"],
        select_last_index=case["select_last_index"],
        dtype=TensorProto.FLOAT,
    )
    _run_ort_compare(model)


@pytest.mark.parametrize("case", TOPK_CASES, ids=lambda case: case["name"])
def test_topk_matches_onnxruntime(case: dict[str, object]) -> None:
    output_shape = _topk_output_shape(
        case["input_shape"], case["axis"], case["k"]
    )
    model = _make_topk_model(
        input_shape=case["input_shape"],
        output_shape=output_shape,
        axis=case["axis"],
        k=case["k"],
        largest=case["largest"],
        sorted=case["sorted"],
        dtype=TensorProto.FLOAT,
    )
    _run_ort_compare(model)


def test_argmax_select_last_index_matches_numpy() -> None:
    input_shape = [2, 4]
    axis = 1
    keepdims = 1
    output_shape = _arg_reduce_output_shape(input_shape, axis, keepdims)
    model = _make_arg_reduce_model(
        op_type="ArgMax",
        input_shape=input_shape,
        output_shape=output_shape,
        axis=axis,
        keepdims=keepdims,
        select_last_index=1,
        dtype=TensorProto.FLOAT,
    )
    data = np.array(
        [[1.0, 3.0, 3.0, 2.0], [0.0, -1.0, -1.0, -2.0]],
        dtype=np.float32,
    )
    outputs = _run_reference(model, {"input": data})
    flipped = np.flip(data, axis=axis)
    expected = data.shape[axis] - 1 - np.argmax(flipped, axis=axis)
    expected = np.expand_dims(expected, axis=axis)
    np.testing.assert_array_equal(outputs["output"], expected.astype(np.int64))


def test_topk_tiebreaker_matches_numpy() -> None:
    input_shape = [1, 4]
    axis = 1
    k = 2
    output_shape = _topk_output_shape(input_shape, axis, k)
    model = _make_topk_model(
        input_shape=input_shape,
        output_shape=output_shape,
        axis=axis,
        k=k,
        largest=1,
        sorted=1,
        dtype=TensorProto.FLOAT,
    )
    data = np.array([[1.0, 2.0, 2.0, 0.5]], dtype=np.float32)
    outputs = _run_reference(model, {"input": data})
    order = np.argsort(-data, axis=axis, kind="stable")
    expected_indices = np.take(order, np.arange(k), axis=axis)
    expected_values = np.take_along_axis(data, expected_indices, axis=axis)
    np.testing.assert_allclose(outputs["values"], expected_values, rtol=1e-5, atol=1e-6)
    np.testing.assert_array_equal(
        outputs["indices"], expected_indices.astype(np.int64)
    )


def test_reduce_op_axes_input_matches_numpy() -> None:
    input_shape = [2, 3, 4]
    axes = [1]
    keepdims = 0
    output_shape = _reduce_output_shape(input_shape, axes, keepdims)
    model = _make_reduce_model_with_axes_input(
        op_type="ReduceSum",
        input_shape=input_shape,
        output_shape=output_shape,
        axes_shape=[len(axes)],
        keepdims=keepdims,
        dtype=TensorProto.FLOAT,
    )
    rng = np.random.default_rng(0)
    data = rng.standard_normal(input_shape).astype(np.float32)
    outputs = _run_reference(
        model, {"in0": data, "axes": np.array(axes, dtype=np.int64)}
    )
    expected = np.sum(data, axis=tuple(axes), keepdims=bool(keepdims))
    np.testing.assert_allclose(outputs["out"], expected, rtol=1e-5, atol=1e-6)


def test_castlike_matches_onnxruntime() -> None:
    model = _make_castlike_model()
    _run_ort_compare(model)


def test_size_matches_onnxruntime() -> None:
    model = _make_size_model(input_shape=[2, 3, 4])
    _run_ort_compare(model)


def test_nonzero_matches_onnxruntime() -> None:
    model = _make_nonzero_model(
        input_shape=[2, 2],
        output_shape=[2, 3],
        input_dtype=TensorProto.FLOAT,
    )
    inputs = {"input": np.array([[1.0, 0.0], [2.0, 3.0]], dtype=np.float32)}
    session = ort.InferenceSession(
        model.SerializeToString(), providers=["CPUExecutionProvider"]
    )
    ort_output = session.run(None, inputs)[0]
    reference_outputs = _run_reference(model, inputs)
    np.testing.assert_array_equal(reference_outputs["output"], ort_output)


def test_expand_matches_onnxruntime() -> None:
    model = _make_expand_model(
        input_shape=[3, 1],
        target_shape=[2, 3, 4],
        dtype=TensorProto.FLOAT,
    )
    _run_ort_compare(model)


def test_range_matches_onnxruntime() -> None:
    model = _make_range_model(
        start=1,
        limit=7,
        delta=2,
        dtype=TensorProto.INT32,
    )
    _run_ort_compare(model)


def test_onehot_matches_onnxruntime() -> None:
    model = _make_onehot_model(
        indices_shape=[2, 3],
        depth=4,
        axis=1,
        indices_dtype=TensorProto.INT64,
        values_dtype=TensorProto.FLOAT,
    )
    _run_ort_compare(model)


def test_cumsum_matches_onnxruntime() -> None:
    model = _make_cumsum_model(
        input_shape=[2, 3],
        axis=1,
        dtype=TensorProto.FLOAT,
        exclusive=True,
        reverse=True,
    )
    _run_ort_compare(model)


def test_split_matches_onnxruntime() -> None:
    model = _make_split_model(
        input_shape=[2, 6],
        split_sizes=[2, 4],
        axis=1,
        dtype=TensorProto.FLOAT,
    )
    _run_ort_compare(model)


@pytest.mark.parametrize("case", REARRANGE_ORT_CASES, ids=lambda case: case["name"])
def test_rearrange_ops_match_onnxruntime(case: dict[str, object]) -> None:
    model = case["model"]()
    _run_ort_compare(model)


@pytest.mark.parametrize("case", REARRANGE_UNIT_CASES, ids=lambda case: case["name"])
def test_rearrange_ops_match_numpy(case: dict[str, object]) -> None:
    model = case["model"]()
    rng = np.random.default_rng(0)
    input_data = rng.standard_normal(case["input_shape"]).astype(np.float32)
    outputs = _run_reference(model, {case["input_name"]: input_data})
    expected = case["expected"](input_data)
    np.testing.assert_allclose(
        outputs[model.graph.output[0].name],
        expected,
        rtol=1e-5,
        atol=1e-6,
    )


def test_trilu_k_input_matches_numpy() -> None:
    model = _make_trilu_model(
        input_shape=[2, 3],
        dtype=TensorProto.FLOAT,
        upper=False,
        include_k_input=True,
    )
    rng = np.random.default_rng(0)
    input_data = rng.standard_normal((2, 3)).astype(np.float32)
    k = np.array(-1, dtype=np.int64)
    outputs = _run_reference(model, {"input": input_data, "k": k})
    expected = np.tril(input_data, k=int(k))
    np.testing.assert_allclose(
        outputs[model.graph.output[0].name],
        expected,
        rtol=1e-5,
        atol=1e-6,
    )


def test_expand_run_matches_numpy() -> None:
    model = _make_expand_model(
        input_shape=[3, 1],
        target_shape=[2, 3, 4],
        dtype=TensorProto.FLOAT,
    )
    data = np.arange(3, dtype=np.float32).reshape(3, 1)
    outputs = _run_reference(model, {"input": data})
    expected_shape = _broadcast_shape([3, 1], [2, 3, 4])
    expected = np.broadcast_to(data, expected_shape)
    np.testing.assert_allclose(outputs["output"], expected, rtol=1e-5, atol=1e-6)


def test_range_run_matches_numpy() -> None:
    model = _make_range_model(start=1, limit=7, delta=2, dtype=TensorProto.INT32)
    outputs = _run_reference(model, {})
    expected = np.arange(1, 7, 2, dtype=np.int32)
    np.testing.assert_array_equal(outputs["output"], expected)


@pytest.mark.parametrize(
    ("axis", "exclusive", "reverse"),
    [
        (0, False, False),
        (1, True, False),
        (-1, True, True),
    ],
)
def test_cumsum_run_matches_numpy(
    axis: int, exclusive: bool, reverse: bool
) -> None:
    model = _make_cumsum_model(
        input_shape=[2, 3],
        axis=axis,
        dtype=TensorProto.FLOAT,
        exclusive=exclusive,
        reverse=reverse,
    )
    rng = np.random.default_rng(0)
    data = rng.standard_normal((2, 3)).astype(np.float32)
    outputs = _run_reference(model, {"input": data})
    expected = _cumsum_numpy(
        data, axis=axis, exclusive=exclusive, reverse=reverse
    )
    np.testing.assert_allclose(outputs["output"], expected, rtol=1e-5, atol=1e-6)


def test_size_run() -> None:
    model = _make_size_model(input_shape=[2, 3, 4])
    data = np.arange(24, dtype=np.float32).reshape(2, 3, 4)
    outputs = _run_reference(model, {"in0": data})
    expected = np.array(data.size, dtype=np.int64)
    np.testing.assert_array_equal(outputs["out"], expected)


def test_nonzero_run_matches_numpy() -> None:
    model = _make_nonzero_model(
        input_shape=[2, 2],
        output_shape=[2, 3],
        input_dtype=TensorProto.FLOAT,
    )
    data = np.array([[1.0, 0.0], [2.0, 3.0]], dtype=np.float32)
    outputs = _run_reference(model, {"input": data})
    expected = np.stack(np.nonzero(data), axis=0).astype(np.int64)
    np.testing.assert_array_equal(outputs["output"], expected)


def test_constant_of_shape_run() -> None:
    model = _make_constant_of_shape_model()
    outputs = _run_reference(model, {})
    expected = np.full((2, 3, 4), 1.25, dtype=np.float32)
    np.testing.assert_allclose(outputs["out"], expected)


def test_split_run_matches_numpy() -> None:
    model = _make_split_model(
        input_shape=[2, 6],
        split_sizes=[2, 4],
        axis=1,
        dtype=TensorProto.FLOAT,
    )
    data = np.arange(12, dtype=np.float32).reshape(2, 6)
    outputs = _run_reference(model, {"input": data})
    expected = np.split(data, [2], axis=1)
    np.testing.assert_allclose(outputs["output_0"], expected[0], rtol=1e-5, atol=1e-6)
    np.testing.assert_allclose(outputs["output_1"], expected[1], rtol=1e-5, atol=1e-6)


def test_gemm_run_matches_numpy() -> None:
    model = _make_operator_model(
        op_type="Gemm",
        input_shapes=[[3, 2], [4, 3], [4]],
        output_shape=[2, 4],
        dtype=TensorProto.FLOAT,
        attrs={"transA": 1, "transB": 1, "alpha": 0.5, "beta": 1.25},
    )
    a = np.arange(6, dtype=np.float32).reshape(3, 2)
    b = np.arange(12, dtype=np.float32).reshape(4, 3)
    c = np.arange(4, dtype=np.float32)
    outputs = _run_reference(model, {"in0": a, "in1": b, "in2": c})
    expected = 0.5 * (a.T @ b.T) + 1.25 * c
    np.testing.assert_allclose(outputs["out"], expected, rtol=1e-5, atol=1e-6)


@pytest.mark.parametrize("case", AVG_POOL_CASES, ids=lambda case: case["name"])
def test_average_pool_matches_onnxruntime(case: dict[str, object]) -> None:
    output_shape = _average_pool_output_shape(
        case["input_shape"],
        case["kernel_shape"],
        case["strides"],
        case["pads"],
    )
    model = _make_operator_model(
        op_type="AveragePool",
        input_shapes=[case["input_shape"]],
        output_shape=output_shape,
        dtype=TensorProto.FLOAT,
        attrs={
            "kernel_shape": case["kernel_shape"],
            "strides": case["strides"],
            "pads": case["pads"],
            "count_include_pad": case["count_include_pad"],
        },
    )
    _run_ort_compare(model)


def test_average_pool_auto_pad_matches_onnxruntime() -> None:
    input_shape = [1, 1, 5, 5]
    kernel_shape = [3, 3]
    strides = [2, 2]
    auto_pad = "SAME_UPPER"
    output_shape = _average_pool_output_shape_auto_pad(
        input_shape,
        kernel_shape,
        strides,
        auto_pad,
    )
    model = _make_operator_model(
        op_type="AveragePool",
        input_shapes=[input_shape],
        output_shape=output_shape,
        dtype=TensorProto.FLOAT,
        attrs={
            "kernel_shape": kernel_shape,
            "strides": strides,
            "auto_pad": auto_pad,
        },
    )
    _run_ort_compare(model)


def test_global_average_pool_matches_onnxruntime() -> None:
    input_shape = [1, 2, 4, 3]
    model = _make_operator_model(
        op_type="GlobalAveragePool",
        input_shapes=[input_shape],
        output_shape=[input_shape[0], input_shape[1], 1, 1],
        dtype=TensorProto.FLOAT,
    )
    _run_ort_compare(model)


def test_global_max_pool_matches_onnxruntime() -> None:
    model = _make_global_max_pool_model()
    _run_ort_compare(model)


def test_hardmax_matches_onnxruntime() -> None:
    model = _make_hardmax_model()
    _run_ort_compare(model)


def test_mish_matches_onnxruntime() -> None:
    model = _make_mish_model()
    _run_ort_compare(model)


def test_constant_op_matches_onnxruntime() -> None:
    model = _make_constant_add_model()
    _run_ort_compare(model)


def test_constant_of_shape_matches_onnxruntime() -> None:
    model = _make_constant_of_shape_model()
    _run_ort_compare(model)


def test_gather_elements_matches_onnxruntime() -> None:
    indices_values = np.array([[2, 0, 1], [1, 2, 0]], dtype=np.int64)
    model = _make_gather_elements_model(
        data_shape=[2, 3],
        indices_shape=[2, 3],
        axis=1,
        indices_values=indices_values,
        indices_as_initializer=True,
    )
    _run_ort_compare(model)


def test_gather_matches_onnxruntime() -> None:
    indices_values = np.array([2, 0], dtype=np.int64)
    model = _make_gather_model(
        data_shape=[2, 3, 4],
        indices_shape=[2],
        axis=1,
        indices_values=indices_values,
        indices_as_initializer=True,
    )
    _run_ort_compare(model)


def test_gathernd_matches_onnxruntime() -> None:
    indices_values = np.array([[0, 1], [1, 0]], dtype=np.int64)
    model = _make_gathernd_model(
        data_shape=[2, 2, 2],
        indices_shape=[2, 2],
        indices_values=indices_values,
        indices_as_initializer=True,
    )
    _run_ort_compare(model)


def test_scatternd_matches_onnxruntime() -> None:
    indices_values = np.array([[0, 1], [2, 2]], dtype=np.int64)
    model = _make_scatternd_model(
        data_shape=[3, 3],
        indices=indices_values,
        updates_shape=[2],
        dtype=TensorProto.FLOAT,
        reduction="add",
    )
    _run_ort_compare(model)


def test_reshape_op_matches_onnxruntime() -> None:
    model = _make_reshape_model()
    _run_ort_compare(model)


def test_squeeze_op_matches_onnxruntime() -> None:
    model = _make_squeeze_model()
    _run_ort_compare(model)


def test_cast_op_matches_onnxruntime() -> None:
    model = _make_cast_model()
    _run_ort_compare(model)


def test_resize_op_matches_onnxruntime() -> None:
    model = _make_resize_model()
    _run_testbench_compare(model)


def test_upsample_op_matches_onnxruntime() -> None:
    model = _make_upsample_model()
    _run_testbench_compare(model)


def test_gridsample_op_matches_onnxruntime() -> None:
    model = _make_gridsample_model(
        input_shape=[1, 1, 3, 4],
        grid_shape=[1, 2, 3, 2],
        output_shape=[1, 1, 2, 3],
        mode="linear",
        padding_mode="zeros",
        align_corners=0,
    )
    _run_testbench_compare(model)


def test_shape_op_matches_onnxruntime() -> None:
    model = _make_shape_model(input_shape=[2, 3, 4])
    _run_ort_compare(model)


def test_shape_slice_op_matches_onnxruntime() -> None:
    model = _make_shape_model(
        input_shape=[2, 3, 4, 5],
        start=1,
        end=3,
        opset=15,
    )
    _run_ort_compare(model)


def test_slice_op_matches_onnxruntime() -> None:
    model = _make_slice_model()
    _run_ort_compare(model)


def test_dropout_op_matches_onnxruntime() -> None:
    model = _make_dropout_model()
    _run_ort_compare(model)


def test_lstm_op_matches_onnxruntime() -> None:
    model = _make_lstm_model(
        seq_length=2,
        batch_size=2,
        input_size=3,
        hidden_size=4,
        dtype=TensorProto.FLOAT,
        include_optional_inputs=False,
        include_y=True,
        include_y_h=True,
        include_y_c=False,
        layout=0,
    )
    _run_ort_compare(model)


def test_unsqueeze_op_matches_onnxruntime() -> None:
    model = _make_unsqueeze_model(input_shape=[2, 3], axes=[-1], opset=13)
    _run_ort_compare(model)


def test_conv_op_matches_onnxruntime() -> None:
    model = _make_conv_model()
    _run_ort_compare(model)


def test_convinteger_op_matches_onnxruntime() -> None:
    model = _make_convinteger_model(per_channel_zero_point=False)
    _run_testbench_compare(model)


def test_conv_transpose_op_matches_onnxruntime() -> None:
    model = _make_conv_transpose_model()
    _run_ort_compare(model)


def test_lp_pool_matches_onnxruntime() -> None:
    model = _make_lp_pool_model()
    _run_ort_compare(model)


def test_quantize_linear_matches_onnxruntime() -> None:
    model = _make_quantize_linear_model()
    _run_ort_compare(model)


def test_batchnorm_op_matches_onnxruntime() -> None:
    model, _ = _make_batchnorm_model()
    _run_ort_compare(model)


def test_lp_normalization_op_matches_onnxruntime() -> None:
    model = _make_lp_normalization_model(input_shape=[2, 3], axis=-1, p=1)
    _run_ort_compare_or_skip(
        model,
        skip_substrings=(
            "LpNormalization",
            "NOT_IMPLEMENTED",
        ),
    )


def test_instance_normalization_op_matches_onnxruntime() -> None:
    model = _make_instance_normalization_model(input_shape=[1, 3, 2, 2])
    _run_ort_compare(model)


def test_group_normalization_op_matches_onnxruntime() -> None:
    model = _make_group_normalization_model(
        input_shape=[1, 4, 2, 2], num_groups=2
    )
    _run_ort_compare(model)


def test_layer_normalization_op_matches_onnxruntime() -> None:
    model = _make_layer_normalization_model(input_shape=[2, 3, 4], axis=1)
    _run_ort_compare(model)


def test_mean_variance_normalization_op_matches_onnxruntime() -> None:
    model = _make_mean_variance_normalization_model(
        input_shape=[2, 3, 2, 2]
    )
    _run_ort_compare(model)


def test_rms_normalization_op_matches_onnxruntime() -> None:
    model = _make_rms_normalization_model(input_shape=[2, 3, 4], axis=1)
    _run_ort_compare(model)


@pytest.mark.parametrize("case", MAXPOOL_CASES, ids=lambda case: case["name"])
def test_maxpool_op_matches_onnxruntime(case: dict[str, object]) -> None:
    model = _make_maxpool_model(
        input_shape=case["input_shape"],
        kernel_shape=case["kernel_shape"],
        strides=case["strides"],
        pads=case["pads"],
        ceil_mode=case["ceil_mode"],
    )
    _run_ort_compare(model)


def test_gather_elements_run_matches_numpy() -> None:
    model = _make_gather_elements_model(
        data_shape=[2, 3],
        indices_shape=[2, 3],
        axis=1,
    )
    data = np.arange(6, dtype=np.float32).reshape(2, 3)
    indices = np.array([[2, 0, 1], [-1, 1, 0]], dtype=np.int64)
    outputs = _run_reference(model, {"data": data, "indices": indices})
    expected = np.take_along_axis(data, indices, axis=1)
    np.testing.assert_allclose(outputs["out"], expected, rtol=1e-5, atol=1e-6)


def test_gather_run_matches_numpy() -> None:
    model = _make_gather_model(
        data_shape=[2, 3, 4],
        indices_shape=[2, 1],
        axis=2,
    )
    data = np.arange(24, dtype=np.float32).reshape(2, 3, 4)
    indices = np.array([[1], [-1]], dtype=np.int64)
    outputs = _run_reference(model, {"data": data, "indices": indices})
    expected = np.take(data, indices, axis=2)
    np.testing.assert_allclose(outputs["out"], expected, rtol=1e-5, atol=1e-6)


def test_gathernd_run_matches_numpy() -> None:
    model = _make_gathernd_model(
        data_shape=[2, 3, 4],
        indices_shape=[2, 2, 1],
        batch_dims=1,
    )
    data = np.arange(24, dtype=np.float32).reshape(2, 3, 4)
    indices = np.array([[[0], [2]], [[-1], [1]]], dtype=np.int64)
    outputs = _run_reference(model, {"data": data, "indices": indices})
    expected = _gathernd_numpy(data, indices, batch_dims=1)
    np.testing.assert_allclose(outputs["out"], expected, rtol=1e-5, atol=1e-6)


def test_dropout_run_matches_numpy() -> None:
    model = _make_dropout_model()
    input_data = np.arange(24, dtype=np.float32).reshape(2, 3, 4)
    outputs = _run_reference(model, {"in0": input_data})
    np.testing.assert_allclose(outputs["out"], input_data, rtol=1e-6, atol=1e-6)


def test_unsqueeze_run_matches_numpy() -> None:
    model = _make_unsqueeze_model(input_shape=[2, 3], axes=[0, 2], opset=11)
    input_data = np.arange(6, dtype=np.float32).reshape(2, 3)
    outputs = _run_reference(model, {"in0": input_data})
    expected = np.expand_dims(np.expand_dims(input_data, axis=0), axis=2)
    np.testing.assert_allclose(outputs["out"], expected, rtol=1e-6, atol=1e-6)


def test_lp_normalization_run_matches_numpy() -> None:
    model = _make_lp_normalization_model(input_shape=[2, 3], axis=1, p=2)
    data = np.array([[1.0, 2.0, 2.0], [3.0, 4.0, 0.0]], dtype=np.float32)
    outputs = _run_reference(model, {"in0": data})
    denom = np.sqrt(np.sum(data * data, axis=1, keepdims=True))
    expected = data / denom
    np.testing.assert_allclose(outputs["out"], expected, rtol=1e-5, atol=1e-6)


def test_instance_normalization_run_matches_numpy() -> None:
    model = _make_instance_normalization_model(input_shape=[1, 2, 2, 3])
    data = np.arange(12, dtype=np.float32).reshape(1, 2, 2, 3)
    scale = np.array([1.0, 1.5], dtype=np.float32)
    bias = np.array([0.5, -0.25], dtype=np.float32)
    outputs = _run_reference(model, {"in0": data, "in1": scale, "in2": bias})
    mean = np.mean(data, axis=(2, 3), keepdims=True)
    var = np.mean((data - mean) ** 2, axis=(2, 3), keepdims=True)
    scale_reshaped = scale.reshape(1, 2, 1, 1)
    bias_reshaped = bias.reshape(1, 2, 1, 1)
    expected = (data - mean) / np.sqrt(var + 1e-5) * scale_reshaped + bias_reshaped
    np.testing.assert_allclose(outputs["out"], expected, rtol=1e-5, atol=1e-6)


def test_group_normalization_run_matches_numpy() -> None:
    model = _make_group_normalization_model(
        input_shape=[1, 4, 2, 2], num_groups=2
    )
    data = np.arange(16, dtype=np.float32).reshape(1, 4, 2, 2)
    scale = np.array([1.0, 1.5, 0.5, -1.0], dtype=np.float32)
    bias = np.array([0.25, -0.5, 0.75, 1.0], dtype=np.float32)
    outputs = _run_reference(model, {"in0": data, "in1": scale, "in2": bias})
    grouped = data.reshape(1, 2, 2, 2, 2)
    mean = np.mean(grouped, axis=(2, 3, 4), keepdims=True)
    var = np.mean((grouped - mean) ** 2, axis=(2, 3, 4), keepdims=True)
    normalized = (grouped - mean) / np.sqrt(var + 1e-5)
    normalized = normalized.reshape(data.shape)
    scale_reshaped = scale.reshape(1, 4, 1, 1)
    bias_reshaped = bias.reshape(1, 4, 1, 1)
    expected = normalized * scale_reshaped + bias_reshaped
    np.testing.assert_allclose(outputs["out"], expected, rtol=1e-5, atol=1e-6)


def test_layer_normalization_run_matches_numpy() -> None:
    model = _make_layer_normalization_model(
        input_shape=[2, 3, 4], axis=-1
    )
    data = np.arange(24, dtype=np.float32).reshape(2, 3, 4)
    scale = np.linspace(0.5, 1.5, num=4, dtype=np.float32)
    bias = np.linspace(-0.5, 0.5, num=4, dtype=np.float32)
    outputs = _run_reference(model, {"in0": data, "in1": scale, "in2": bias})
    mean = np.mean(data, axis=2, keepdims=True)
    var = np.mean((data - mean) ** 2, axis=2, keepdims=True)
    expected = (data - mean) / np.sqrt(var + 1e-5)
    expected = expected * scale.reshape(1, 1, 4) + bias.reshape(1, 1, 4)
    np.testing.assert_allclose(outputs["out"], expected, rtol=1e-5, atol=1e-6)


def test_mean_variance_normalization_run_matches_numpy() -> None:
    model = _make_mean_variance_normalization_model(
        input_shape=[2, 3, 2, 2], axes=[0, 2, 3]
    )
    data = np.arange(24, dtype=np.float32).reshape(2, 3, 2, 2)
    outputs = _run_reference(model, {"in0": data})
    mean = np.mean(data, axis=(0, 2, 3), keepdims=True)
    var = np.mean((data - mean) ** 2, axis=(0, 2, 3), keepdims=True)
    expected = (data - mean) / np.sqrt(var + 1e-9)
    np.testing.assert_allclose(outputs["out"], expected, rtol=1e-5, atol=1e-6)


def test_rms_normalization_run_matches_numpy() -> None:
    model = _make_rms_normalization_model(input_shape=[2, 3, 4], axis=-1)
    data = np.arange(24, dtype=np.float32).reshape(2, 3, 4)
    scale = np.linspace(0.25, 1.0, num=4, dtype=np.float32)
    outputs = _run_reference(model, {"in0": data, "in1": scale})
    mean_square = np.mean(data * data, axis=2, keepdims=True)
    expected = data / np.sqrt(mean_square + 1e-5)
    expected = expected * scale.reshape(1, 1, 4)
    np.testing.assert_allclose(outputs["out"], expected, rtol=1e-5, atol=1e-6)
