A Spacy name entity recogniser to extract mof reagents from text

| Feature | Description |
| --- | --- |
| **Name** | `en_mof_chem_ner` |
| **Version** | `0.0.1` |
| **spaCy** | `>=3.7.5,<3.8.0` |
| **Default Pipeline** | `tok2vec`, `ner` |
| **Components** | `tok2vec`, `ner` |
| **Vectors** | 0 keys, 0 unique vectors (0 dimensions) |
| **Sources** | n/a |
| **License** | `MIT` |
| **Author** | [Dinga Wonanke](https://github.com/bafgreat/mofsyncondition.git) |

### Label Scheme

<details>

<summary>View label scheme (7 labels for 1 components)</summary>

| Component | Labels |
| --- | --- |
| **`ner`** | `ATMOSPHERE`, `METAL_SALT`, `MODULATOR`, `MOF`, `ORGANIC_LIGAND`, `SOLVENT`, `SYNTH_METHOD` |

</details>

### Accuracy

| Type | Score |
| --- | --- |
| `ENTS_F` | 91.66 |
| `ENTS_P` | 92.78 |
| `ENTS_R` | 90.56 |
| `TOK2VEC_LOSS` | 26365.16 |
| `NER_LOSS` | 78555.25 |