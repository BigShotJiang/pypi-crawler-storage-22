# Tests for enable_ai package
