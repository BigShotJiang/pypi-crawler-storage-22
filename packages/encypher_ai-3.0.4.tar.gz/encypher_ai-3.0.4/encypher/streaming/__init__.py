"""
Streaming support for Encypher metadata encoding.
"""

from encypher.streaming.handlers import StreamingHandler

__all__ = ["StreamingHandler"]
