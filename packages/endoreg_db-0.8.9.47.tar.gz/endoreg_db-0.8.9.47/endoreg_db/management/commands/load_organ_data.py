from django.core.management.base import BaseCommand

from endoreg_db.models import Organ

from ...data import ORGAN_DATA_DIR
from ...utils import load_model_data_from_yaml

MODEL_0 = Organ

IMPORT_MODELS = [  # string as model key, serves as key in IMPORT_METADATA
    MODEL_0.__name__,  #
]

IMPORT_METADATA = {
    MODEL_0.__name__: {
        "dir": ORGAN_DATA_DIR,  # e.g. "interventions"
        "model": MODEL_0,
        "foreign_keys": [],  # e.g. ["intervention_types"]
        "foreign_key_models": [],  # e.g. [InterventionType]
    }
}


class Command(BaseCommand):
    help = """Load all .yaml files in the data/intervention directory
    into the Intervention and InterventionType model"""

    def add_arguments(self, parser):
        parser.add_argument(
            "--verbose",
            action="store_true",
            help="Display verbose output",
        )

    def handle(self, *args, **options):
        verbose = options["verbose"]
        for model_name in IMPORT_MODELS:
            _metadata = IMPORT_METADATA[model_name]
            load_model_data_from_yaml(self, model_name, _metadata, verbose)
