"""Setup file for enebular-sdk package."""

from setuptools import setup

# Configuration is now in pyproject.toml
setup()
