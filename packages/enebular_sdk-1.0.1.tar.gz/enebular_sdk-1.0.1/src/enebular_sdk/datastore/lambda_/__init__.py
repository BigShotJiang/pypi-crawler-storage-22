"""Lambda-specific datastore implementations."""

from .cloud_data_store_client import CloudDataStoreClient

__all__ = ["CloudDataStoreClient"]
