from __future__ import annotations

import json
from pathlib import Path
import subprocess
import sys


SCRIPT_PATH = (
    Path(__file__).resolve().parents[1]
    / "harness"
    / "fitness-functions"
    / "check_loop_subprocess_boundary.py"
)


def _write_module(project_root: Path, relative_path: str, body: str) -> None:
    path = project_root / relative_path
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(body, encoding="utf-8")


def _run_checker(
    project_root: Path,
) -> tuple[subprocess.CompletedProcess[str], dict[str, object]]:
    proc = subprocess.run(
        [sys.executable, str(SCRIPT_PATH)],
        cwd=project_root,
        capture_output=True,
        text=True,
        check=False,
    )
    payload = json.loads(proc.stdout)
    return proc, payload


def test_loop_subprocess_boundary_checker_emits_expected_rule_id(
    tmp_path: Path,
) -> None:
    """Emit the stable rule id from the harness command adapter."""
    _write_module(
        tmp_path,
        "src/engineeringagent/loop.py",
        "def run() -> None:\n    return None\n",
    )

    proc, payload = _run_checker(tmp_path)

    assert proc.returncode == 0
    assert payload["rule_id"] == "architecture.loop-subprocess-boundary"


def test_loop_subprocess_boundary_rule_reports_direct_subprocess_use(
    tmp_path: Path,
) -> None:
    """Fail when a non-allowlisted module invokes subprocess directly."""
    _write_module(
        tmp_path,
        "src/engineeringagent/loop.py",
        "\n".join(
            [
                "import subprocess",
                "",
                "def run() -> None:",
                "    subprocess.run(['git', 'status'], check=False)",
            ]
        ),
    )

    proc, payload = _run_checker(tmp_path)
    violations = payload["violations"]

    assert proc.returncode == 0
    assert payload["status"] == "fail"
    assert isinstance(violations, list)
    assert any(
        "src/engineeringagent/loop.py:4 uses subprocess.run" in violation
        for violation in violations
    )


def test_loop_subprocess_boundary_rule_reports_subprocess_alias_pattern(
    tmp_path: Path,
) -> None:
    """Fail when alias import wrappers call blocked subprocess APIs."""
    _write_module(
        tmp_path,
        "src/engineeringagent/process_runner.py",
        "\n".join(
            [
                "import subprocess as sp",
                "",
                "def run_process() -> None:",
                "    sp.run(['git', 'status'], check=False)",
            ]
        ),
    )

    proc, payload = _run_checker(tmp_path)
    violations = payload["violations"]

    assert proc.returncode == 0
    assert payload["status"] == "fail"
    assert isinstance(violations, list)
    assert any(
        "src/engineeringagent/process_runner.py:4 uses sp.run" in violation
        for violation in violations
    )


def test_loop_subprocess_boundary_rule_reports_from_import_pattern(
    tmp_path: Path,
) -> None:
    """Fail when direct-imported subprocess call aliases are invoked."""
    _write_module(
        tmp_path,
        "src/engineeringagent/loop.py",
        "\n".join(
            [
                "from subprocess import run as run_cmd",
                "",
                "def run() -> None:",
                "    run_cmd(['git', 'status'], check=False)",
            ]
        ),
    )

    proc, payload = _run_checker(tmp_path)
    violations = payload["violations"]

    assert proc.returncode == 0
    assert payload["status"] == "fail"
    assert isinstance(violations, list)
    assert any(
        "src/engineeringagent/loop.py:4 uses run_cmd(...) from subprocess" in violation
        for violation in violations
    )


def test_loop_subprocess_boundary_rule_allows_approved_command_boundary_modules(
    tmp_path: Path,
) -> None:
    """Pass when subprocess calls stay inside explicit allowlisted modules."""
    _write_module(
        tmp_path,
        "src/engineeringagent/gates.py",
        "\n".join(
            [
                "import subprocess",
                "",
                "def run_gate() -> None:",
                "    subprocess.run(['git', 'status'], check=False)",
            ]
        ),
    )

    proc, payload = _run_checker(tmp_path)

    assert proc.returncode == 0
    assert payload["status"] == "pass"
    assert payload["violations"] == []


def test_loop_subprocess_boundary_rule_allows_git_client_module(tmp_path: Path) -> None:
    """Pass when subprocess calls stay inside the git client boundary."""
    _write_module(
        tmp_path,
        "src/engineeringagent/git/client.py",
        "\n".join(
            [
                "import subprocess",
                "",
                "def run_git() -> None:",
                "    subprocess.run(['git', 'status'], check=False)",
            ]
        ),
    )

    proc, payload = _run_checker(tmp_path)

    assert proc.returncode == 0
    assert payload["status"] == "pass"
    assert payload["violations"] == []
