from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import engineeringagent.loop_runtime.presentation as presentation_module
from engineeringagent.loop import print_summary
from engineeringagent.loop_runtime.models import (
    FeatureIterationInputs,
    IterationTelemetryInputs,
)
from engineeringagent.loop_runtime.telemetry import write_iteration_telemetry


def test_progress_log_records_verification_status(tmp_path: Path) -> None:
    verification_command = (
        "uv run pytest -q "
        "tests/test_loop_output.py::test_progress_log_records_verification_status"
    )
    iteration_inputs = FeatureIterationInputs(
        project_root=tmp_path,
        feature_path=tmp_path / "docs" / "spec" / "features" / "FEAT-040.yaml",
        gate_profile="loop_fast",
        implement_command=None,
        skip_implement=False,
        attempt=3,
        hook_feedback=None,
        verbose_output=False,
    )
    telemetry_inputs = IterationTelemetryInputs(
        iteration_inputs=iteration_inputs,
        started=0.0,
        feature_id="FEAT-040",
        result="failed",
        failed_gate=None,
        next_action="retry_same_feature",
        implement_status="passed",
        gate_status="not_run",
        verification_status=f"failed:{verification_command}",
        verification_failed_command=verification_command,
        reviewer_status="failed:blocking",
        reviewer_decision="request_changes",
        failed_reviewer_id="security-reviewer",
        implement_output="",
        gate_output="",
        verification_output="E       assert 1 == 2",
        reviewer_output="[reviewer:security-reviewer] mode=blocking decision=request_changes",
        hook_feedback=f"[verification] command={verification_command}",
    )

    write_iteration_telemetry(
        telemetry_inputs,
        git_head_resolver=lambda _: "abc1234",
    )

    run = json.loads((tmp_path / "progress" / "runs.jsonl").read_text(encoding="utf-8"))
    assert run["verification_status"] == f"failed:{verification_command}"
    assert run["verification_failed_command"] == verification_command
    assert run["reviewer_status"] == "failed:blocking"
    assert run["reviewer_decision"] == "request_changes"
    assert run["failed_reviewer_id"] == "security-reviewer"
    assert run["reviewer_feedback_present"] is False
    assert run["reviewer_feedback_summary"] == ""

    feature_log = (tmp_path / "progress" / "run-feature-FEAT-040.txt").read_text(
        encoding="utf-8"
    )
    first_line = feature_log.splitlines()[0]
    assert first_line.startswith("ts=")
    assert "=== ITERATION" in first_line
    assert "attempt=3" in first_line
    assert "feature_id=FEAT-040" in first_line
    assert (
        f"verification=failed:{verification_command} "
        f"failed_command={verification_command}"
    ) in feature_log
    assert "verification_output_begin" in feature_log
    assert "E       assert 1 == 2" in feature_log
    assert "verification_output_end" in feature_log
    assert (
        "reviewer=failed:blocking decision=request_changes "
        "failed_reviewer=security-reviewer"
    ) in feature_log
    assert "reviewer_output_begin" in feature_log
    assert "mode=blocking decision=request_changes" in feature_log
    assert "reviewer_output_end" in feature_log


def test_progress_log_writes_do_not_use_path_open(
    tmp_path: Path,
    monkeypatch: Any,
) -> None:
    iteration_inputs = FeatureIterationInputs(
        project_root=tmp_path,
        feature_path=tmp_path / "docs" / "spec" / "features" / "FEAT-040.yaml",
        gate_profile="loop_fast",
        implement_command=None,
        skip_implement=False,
        attempt=1,
        hook_feedback=None,
        verbose_output=False,
    )
    telemetry_inputs = IterationTelemetryInputs(
        iteration_inputs=iteration_inputs,
        started=0.0,
        feature_id="FEAT-040",
        result="passed",
        failed_gate=None,
        next_action="advance_to_next_feature",
        implement_status="passed",
        gate_status="passed",
        verification_status="passed",
        verification_failed_command=None,
        reviewer_status="not_run",
        reviewer_decision=None,
        failed_reviewer_id=None,
        implement_output="ok",
        gate_output="ok",
        verification_output="ok",
        reviewer_output="",
        hook_feedback="",
    )

    original_open = Path.open

    def _path_open_forbidden(*_args: Any, **_kwargs: Any) -> Any:
        raise AssertionError(
            "Direct Path.open() writes are forbidden for progress log sinks; "
            "use logging handlers."
        )

    monkeypatch.setattr(Path, "open", _path_open_forbidden)
    try:
        write_iteration_telemetry(
            telemetry_inputs,
            git_head_resolver=lambda _: "abc1234",
        )
    finally:
        monkeypatch.setattr(Path, "open", original_open)

    assert (tmp_path / "progress" / "runs.jsonl").exists()
    assert (tmp_path / "progress" / "run-feature-FEAT-040.txt").exists()


def test_progress_log_strips_ansi_only_at_write_time(
    tmp_path: Path,
    monkeypatch: Any,
) -> None:
    import engineeringagent.loop_runtime.telemetry as telemetry_module

    implement_status = "\x1b[31mpassed\x1b[0m"
    gate_status = "\x1b[32mpassed\x1b[0m"

    iteration_inputs = FeatureIterationInputs(
        project_root=tmp_path,
        feature_path=tmp_path / "docs" / "spec" / "features" / "FEAT-040.yaml",
        gate_profile="loop_fast",
        implement_command=None,
        skip_implement=False,
        attempt=1,
        hook_feedback=None,
        verbose_output=False,
    )
    telemetry_inputs = IterationTelemetryInputs(
        iteration_inputs=iteration_inputs,
        started=0.0,
        feature_id="FEAT-040",
        result="passed",
        failed_gate=None,
        next_action="advance_to_next_feature",
        implement_status=implement_status,
        gate_status=gate_status,
        verification_status="passed",
        verification_failed_command=None,
        reviewer_status="not_run",
        reviewer_decision=None,
        failed_reviewer_id=None,
        implement_output="",
        gate_output="",
        verification_output="",
        reviewer_output="",
        hook_feedback="",
    )

    original_strip_ansi = telemetry_module._strip_ansi
    strip_inputs: list[str] = []

    def _tracking_strip_ansi(text: str) -> str:
        strip_inputs.append(text)
        return original_strip_ansi(text)

    monkeypatch.setattr(telemetry_module, "_strip_ansi", _tracking_strip_ansi)

    write_iteration_telemetry(
        telemetry_inputs,
        git_head_resolver=lambda _: "abc1234",
    )

    implement_line = f"implement={implement_status}"
    gates_line = f"gates={gate_status}"
    assert implement_status not in strip_inputs
    assert gate_status not in strip_inputs
    assert implement_line in strip_inputs
    assert gates_line in strip_inputs

    feature_log = (tmp_path / "progress" / "run-feature-FEAT-040.txt").read_text(
        encoding="utf-8"
    )
    assert "\x1b[" not in feature_log


def test_progress_log_records_code_simplifier_advisory_followup_status(
    tmp_path: Path,
) -> None:
    iteration_inputs = FeatureIterationInputs(
        project_root=tmp_path,
        feature_path=tmp_path / "docs" / "spec" / "features" / "FEAT-059.yaml",
        gate_profile="loop_fast",
        implement_command=None,
        skip_implement=False,
        attempt=2,
        hook_feedback=None,
        verbose_output=False,
    )
    telemetry_inputs = IterationTelemetryInputs(
        iteration_inputs=iteration_inputs,
        started=0.0,
        feature_id="FEAT-059",
        result="failed",
        failed_gate="reviewer_advisory_followup",
        next_action="retry_same_feature",
        implement_status="passed",
        gate_status="passed",
        verification_status="passed",
        verification_failed_command=None,
        reviewer_status="failed:advisory_followup",
        reviewer_decision="warning",
        failed_reviewer_id="code_simplifier",
        implement_output="",
        gate_output="",
        verification_output="",
        reviewer_output="[reviewer:code_simplifier] mode=advisory decision=warning",
        hook_feedback="reviewer 'code_simplifier' advisory feedback: simplify nested branching.",
    )

    write_iteration_telemetry(
        telemetry_inputs,
        git_head_resolver=lambda _: "def5678",
    )

    run = json.loads((tmp_path / "progress" / "runs.jsonl").read_text(encoding="utf-8"))
    assert run["reviewer_status"] == "failed:advisory_followup"
    assert run["reviewer_decision"] == "warning"
    assert run["failed_reviewer_id"] == "code_simplifier"
    assert run["reviewer_feedback_present"] is True
    assert "simplify nested branching" in run["reviewer_feedback_summary"]

    feature_log = (tmp_path / "progress" / "run-feature-FEAT-059.txt").read_text(
        encoding="utf-8"
    )
    assert (
        "reviewer=failed:advisory_followup decision=warning "
        "failed_reviewer=code_simplifier"
    ) in feature_log
    assert "reviewer_output_begin" in feature_log
    assert "[reviewer:code_simplifier] mode=advisory decision=warning" in feature_log
    assert "reviewer_output_end" in feature_log
    assert "reviewer_feedback_forwarded_begin" in feature_log
    assert "reviewer 'code_simplifier' advisory feedback" in feature_log
    assert "reviewer_feedback_forwarded_end" in feature_log


def test_non_verbose_terminal_output_shows_verification_summary(
    monkeypatch: Any,
    capsys: Any,
) -> None:
    verification_command = "uv run pytest -q tests/test_loop_output.py"
    monkeypatch.setattr(presentation_module, "_stdout_is_tty", lambda _stdout: False)
    monkeypatch.delenv("NO_COLOR", raising=False)
    monkeypatch.setenv("TERM", "xterm-256color")

    print_summary(
        feature_id="FEAT-040",
        result="failed",
        failed_gate=None,
        attempt=2,
        next_action="retry_same_feature",
        selected_path="docs/spec/features/FEAT-040-per-iteration-verification-feedback-and-failure-signaling.yaml",
        implement_step="default opencode implement step",
        log_path="progress/run-feature-FEAT-040.txt",
        verification_status=f"failed:{verification_command}",
        verification_failed_command=verification_command,
        reviewer_status="failed:blocking",
        reviewer_decision="request_changes",
        failed_reviewer_id="security-reviewer",
    )

    output = capsys.readouterr().out
    assert "🧪 Verify: failed (uv run pytest -q tests/test_loop_output.py)" in output
    assert (
        "👀 Reviewer: failed:blocking (request_changes) [security-reviewer]" in output
    )
    assert "❌ Failed: gate=unknown" in output
