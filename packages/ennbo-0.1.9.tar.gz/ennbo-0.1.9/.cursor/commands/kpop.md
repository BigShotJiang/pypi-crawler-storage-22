### KPOP: Apply this method to the user's problem.

Restate the problem clearly. 
do
 **Hypothesize**: Hypothesize one falsifiable explanation of the cause of the problem. 
 **Predict**: Define a falsifying test. If the hypothesis were true, what outcome would the test produce? 
 **Falsify**: Run the test. If falsified, reject the hypothesis. 

until you think you've solved the problem
