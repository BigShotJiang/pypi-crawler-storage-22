# Host Python Tools

This folder contains host-side Python code that interacts with the ESP-IDF
firmware (e.g., over serial, sockets, or file exchange). It is kept separate
from the firmware build to avoid mixing tool dependencies with ESP-IDF.

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .

enode-host --help
enode-host socket 127.0.0.1 3333 "hello"
enode-host server --port 3333 --interactive
enode-host gui --port 3333
```

## Notes

- Add runtime dependencies to `pyproject.toml` under `project.dependencies`.
- Keep device/transport details in small modules so they can be shared by
  scripts and tests.
- The GUI uses wxPython; install it if you plan to run `enode-host gui`.

## Protocol (TCP, length-prefixed)

Frame format: 1 byte message type, 2 bytes big-endian payload length, payload.

Message types:
- 0x10 COMMAND (host -> device)
- 0x20 STATUS (device -> host)
- 0x30 ACK (either direction)
- 0x40 DATA (device -> host, ACC batch)
- 0x41 PPS (device -> host, immediate PPS)

Commands (payload begins with command_id):
- 0x01 start_daq
- 0x02 stop_daq
- 0x03 set_mode (1 byte: 0 realtime, 1 past)
- 0x04 start_realtime_stream
- 0x05 stop_realtime_stream
- 0x06 start_past_stream (payload: 8-byte start_ms, 8-byte end_ms)
- 0x07 stop_past_stream

Status payload (16 bytes):
- node_type: uint8
- node_number: uint8
- level: uint8
- parent_mac: 6 bytes
- self_mac: 6 bytes
- rssi: int8

DATA payload:
- node_type: uint8
- node_number: uint8
- sample_count: uint8
- repeated samples (count):
  - cc: uint64 (big-endian)
  - acc_x: float32 (big-endian)
  - acc_y: float32 (big-endian)
  - acc_z: float32 (big-endian)

PPS payload:
- node_type: uint8
- node_number: uint8
- cc: uint64 (big-endian)
- epoch: int64 (big-endian)
