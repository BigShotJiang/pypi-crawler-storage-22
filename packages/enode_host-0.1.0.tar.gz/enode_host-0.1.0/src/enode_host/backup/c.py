#!/usr/local/bin/python3

#----------------------------------------------
# NOTE 
# 1. Ask Ki about the definition of local axes for M352, or see the line # 397 of model.py
#    when you look at the screen of the node, 
#        the direction to the left hand-side is the X-axis
#        the downward direction is the Y-axis
#        the direction perpendicular to the screen and coming towards yourself is Z-axis
#
#    this is the right-hand rule: 
#        the direction of you index finger is the x-axis, 
#        that of the middle finger is the y-axis
#        that of the thumb is the z-axis
#
#---------------------------------------------  
# HOW TO USE THE SYSTEM
#
# 1. please execute this file first, so that the server is ready to receive data from ndoes
# 2. turn on the node(s)
#    - the PPS LED on the display can be believed
#    - please don't believe RSSI, Lv, BAT %, as they are not completed yet.
# 3. Files are saved under data2 folder in HDF 
# 4. Please read example.ipynb for how to load data file and display it
#    - Please notice the time is in UTC to avoid any issues regarding British Summer Time
# 5. For time-sync, never reset the acc node, but power-cycle it. 
#    - there are two buttons on the sensor node: 
#      - one for power next to the USB-c port
#      - the other for reset next to the SD slot
#    - pressing the pwr button for 5 sec will shutdown the node, and pressing it for 1 sec will start the node



import wx
import view
import model
import importlib
importlib.reload(view)
importlib.reload(model)

import logging
import threading
import queues
from numpy import array
import shm_sigproc
import glob
import os 
import esp_mesh
import pandas as pd 
from model import CmdType, ChannelType
from enum import IntEnum

os.remove('log/my_log_file.log')

logging.basicConfig(level=logging.INFO,  # Set the minimum log level
                    #format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    format='%(name)s - %(levelname)s - %(message)s',
                    handlers=[logging.FileHandler('log/my_log_file.log'), logging.StreamHandler()])
logger = logging.getLogger(__name__)


os.makedirs("raw-data", exist_ok = True)


class CMD_TYPE(IntEnum):
    SET_MODE = 0
    CLEAR_STORAGE = 1 
    NOTIFY_PARENT = 2
    NOTIFY_CHILDREN = 3
    SHUTDOWN = 4

class OPERATION_MODE(IntEnum):
    ONLINE_DAQ = 0
    STANDALONE_DATA_PEEKING = 1
    POST_DAQ_DATA_STREAMING = 2
    MAINTENANCE = 3

class Controller:

    def __init__(self):

        self.model = model.Model(self)
        self.view = view.View(self)
        self.view.Show()
        self.mesh = esp_mesh.Esp_Mesh(self.model)

        # mesh.begin()
        # shm_sigproc.begin()

        #
        # BINDINGS
        #
        
        # node_num_txt
        self.view.m_button_nodes_update.Bind(wx.EVT_BUTTON, self.on_change_node_nums)

        # Menu File>Exit
        self.view.Bind(wx.EVT_MENU, self.on_exit, self.view.m_menu_file_quit)
        
        # Menu Data>Export
        self.view.Bind(wx.EVT_MENU, self.on_data_export, self.view.m_menu_data_export)
        
        # Menu CMD>SD clear
        self.view.Bind(wx.EVT_MENU, self.on_cmd_sdclear, self.view.m_menu_cmd_sdclear)
        
        # Menu CMD>Shutdown
        self.view.Bind(wx.EVT_MENU, self.on_cmd_shutdown, self.view.m_menu_cmd_shutdown)
        
        # Menu Tool>clf
        self.view.Bind(wx.EVT_MENU, self.on_view_clf, self.view.m_menu_view_clf)
        
        # Start DAQ Button
        self.view.m_button1.Bind(wx.EVT_BUTTON, self.Start_Button_onclick)
        
        # Stop DAQ Button
        self.view.m_button2.Bind(wx.EVT_BUTTON, self.Stop_Button_onclick)

        # 
        self.view.m_choice_OperationMode.Bind(wx.EVT_CHOICE, self.choice_OperationMode_onchange)
    
    def on_change_node_nums(self, event):

        self.model.options['node_nums_txt'] = self.view.m_textCtrl2.GetValue()
        self.model.parse_node_nums_txt()
        self.model.save_config()
        self.model.init_mesh_status_data()
        self.model.init_other_data()
        self.view.mesh_status_data_view()
        self.view.m_grid2.ForceRefresh()
        # Init the time history and PSD plots
        self.view.init_plot()
        
    def on_exit(self, event):
        
        self.view.Close()

    def on_data_export(self, event):

        self.model.export()

    def Start_Button_onclick(self, event):
        
        map = {
                OPERATION_MODE.ONLINE_DAQ: 1,
                OPERATION_MODE.STANDALONE_DATA_PEEKING: 5,
                OPERATION_MODE.POST_DAQ_DATA_STREAMING: 7,
               }
        operation_Mode = self.view.m_choice_OperationMode.GetSelection()
        
        self.model.init_other_data()            
        self.view.init_plot()
        self.view.figure_update()
        for inode in self.mesh.sockets.keys():            
            self.mesh.send_cmd(inode, CMD_TYPE.SET_MODE, data0 = map[operation_Mode])
            self.model.update_mesh_status_data(inode, 'CMD', "sent")
            self.view.table_update()
        logger.info('command sent: {} start'.format(OPERATION_MODE(operation_Mode).name))

    def Stop_Button_onclick(self, event):
    
        map = {
                OPERATION_MODE.ONLINE_DAQ: 0,
                OPERATION_MODE.STANDALONE_DATA_PEEKING: 4,
                OPERATION_MODE.POST_DAQ_DATA_STREAMING: 2,
               }        

        operation_Mode = self.view.m_choice_OperationMode.GetSelection()
        
        for inode in self.mesh.sockets.keys():
            self.mesh.send_cmd(inode, CMD_TYPE.SET_MODE, data0 = map[operation_Mode])
            self.model.update_mesh_status_data(inode, 'CMD', "sent")
            self.view.table_update()

        logger.info('command sent: {} stop'.format(OPERATION_MODE(operation_Mode).name))
        # self.view.gui_update(1)
    
    def choice_OperationMode_onchange(self, event):
        operation_Mode = self.view.m_choice_OperationMode.GetSelection()
        if operation_Mode == OPERATION_MODE.POST_DAQ_DATA_STREAMING:
            for inode in self.mesh.sockets.keys():
                self.mesh.send_cmd(inode, CMD_TYPE.SET_MODE, data0 = 2)
                self.model.update_mesh_status_data(inode, 'CMD', "sent")
                self.view.table_update()
        
        if operation_Mode == OPERATION_MODE.ONLINE_DAQ:
            self.PPS_outdate_check = True
        else:
            self.PPS_outdate_check = False


    def on_view_clf(self, event):
        self.model.init_other_data()
        self.view.init_plot()
        self.view.figure_update()
        return

    def on_cmd_sdclear(self, event):

        for inode in self.mesh.sockets.keys():            
            self.mesh.send_cmd(inode, CMD_TYPE.CLEAR_STORAGE) 
            self.model.update_mesh_status_data(inode, 'CMD', "sent")
            self.view.table_update()
        logger.info('command sent: SD Clear sent')

    def on_cmd_shutdown(self, event):

        for inode in self.mesh.sockets.keys():            
            self.mesh.send_cmd(inode, CMD_TYPE.SHUTDOWN) 
            self.model.update_mesh_status_data(inode, 'CMD', "sent")
            self.view.table_update()
        logger.info('command sent: SD Clear sent')

        return

    

if __name__ == '__main__':
    app = wx.App()
    controller = Controller()
    # controller.view.gui_update(1)
    app.MainLoop()





