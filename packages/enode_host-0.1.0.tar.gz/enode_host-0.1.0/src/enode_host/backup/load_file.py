from numpy import *
import struct
import datetime
import os
import pandas as pd


def load_adxl355_file(filename):
    t, y = [], []
    with open(filename, 'rb') as file:
        while True:
            chunk = file.read(24)
            if not chunk:
                break
            data = struct.unpack('<QIfff', chunk)

            t_ = datetime.datetime.fromtimestamp(data[0])
            t_ = t_.replace(microsecond = data[1])
            t.append(t_)
            y.append(data[2:])
    t = array(t)
    y = array(y)
    df = pd.DataFrame({'timestamps': t, "X": y[:, 0], "Y": y[:, 1], "Z": y[:, 2]})
    df.set_index(df['timestamps'], inplace = True)
    del df['timestamps']    
    return df 

