'''Tools for signal processing of SHM                                       
'''

#                                                                           
#                                                                           
#                                                                           
#                                                                           

# TODO:                                                                     
#   - identify # of channles                                                
#   - csv or bin                                                            

# %matplotlib inline                                                        
# %matplotlib notebook                                                      
# %matplotlib widget                                                        

import struct
import datetime
from datetime import timezone
from numpy import *
import matplotlib.pyplot as pl
import matplotlib.dates as mdates

from scipy.signal import welch, detrend, cheby1, sosfiltfilt
from scipy.io import loadmat
import sys
import os

import pandas as pd
from bokeh.plotting import figure, show
from bokeh.embed import components
from bokeh.models import HoverTool
from bokeh.models import ColumnDataSource, OpenURL, TapTool
from bokeh.models import HoverTool
from bokeh.models import DatetimeTickFormatter
from bokeh.models import Range1d, LinearAxis
from bokeh.palettes import Dark2_5 as palette
import bokeh.layouts
import pandas_bokeh

#import ssi_dat
import time

class SHM:

    df = []
    t = []
    y = []
    mean = []
    std = []

    mp = []
    nfft = 2**10
    dt = []
    fs = []
    F = []
    Pxx = []

    dataPath = None
    file_duration = {'acc': 600, 'wnd': 3600*24} # in seconds               

    db_managers = {'File':None, 'Summary': None}

    def __init__(self):
        pass

    # LOAD ---------------------------------------------------------------------------------
    def load(self, src, *args, **kwargs):
        """                                                                                                                                                                   
        load(src = [raw|django-file|django-db])                                                                                                                               
        """

        def load_bin(fn, nch = 3):
            with open(fn, 'rb') as fp:
                data = fp.read()
            bytes_per_sample = 4*2 + 4*nch
            n = int(len(data)/bytes_per_sample)
            t, y = [], []
            for i in range(n):
                res = list(struct.unpack('<LL' + 'f'*nch, data[i*bytes_per_sample:(i+1)*bytes_per_sample]))
                t.append(res[0]*1000000 + res[1])  # in usec                                                                                                                  
                y.append(res[2:])
            t = pd.to_datetime(t, unit='us')
            return pd.DataFrame(array(y), index = t)

        def load_mat(fn, gain = 10):
            mat_contents = loadmat(fn)
            _keys = mat_contents.keys()
            if 't' not in _keys or 'a' not in _keys:
                raise Exception('loading mat failed: keys t and a are not found.')
            t = mat_contents['t']
            y = mat_contents['a']/10/gain # 10V per g, gain=10                                                                                                                
            return pd.DataFrame(y, index = t.flatten())

        def load_django_file(nodeName, sensorType, ti, duration=None, pos='start'):
            if pos == 'start':
                pass
            elif pos == 'centre':
                ti = ti - datetime.timedelta(seconds=duration/2)
            elif pos == 'end':
                ti = ti - datetime.timedelta(seconds=duration)
            else:
                raise Exception('unknown pos variable: {}'.format(pos))
            te = ti + datetime.timedelta(seconds=duration)
            recs = self.db_managers['File'].filter(nodeName = nodeName)\
                                           .filter(sensorType = sensorType)\
                                           .filter(timestamp__gte = ti)\
                                           .filter(timestamp__lt  = te)\
                                           .order_by('timestamp')
            if len(recs) > 0:
                dfs = []
                for rec in recs:
                    dfs.append(rec.load())
                return pd.concat(dfs)
            else:
                return None

        def read_db(tableName, fields, ti, duration):
            te = ti + datetime.timedelta(seconds = duration)
            recs = self.db_managers[tableName].filter(timestamp__gte = ti)\
                                              .filter(timestamp__lt  = te)\
                                              .order_by('timestamp')
            t, y, columnnames = [], [], []
            map = {
                'WindDir': ['WindDir'],
                'WindSpeed': ['WindSpeed'],
                'rmsd': ['rmsd_x', 'rmsd_y', 'rmsd_z', 'rmsd_tot'],
                'mean': ['mean_x', 'mean_y', 'mean_z'],
                'freq': ['freq_m11', 'freq_m12', 'freq_m21', 'freq_m22', 'freq_m3'],
                'xi': ['xi_m11', 'xi_m12', 'xi_m21', 'xi_m22', 'xi_m3'],
                'uptime': ['uptime']
                   }
            # populate column names                                                                                                                                           
            for field in fields:
                if field in map.keys():
                    columnnames += map[field]
                else:
                    columnnames += [field]
            # populate data                                                                                                                                                   
            for idx, rec in enumerate(recs):
                t.append(rec.timestamp)
                row = []
                for field in fields:
                    val = getattr(rec, field)
                    # print(field, val)
                    
                    if isinstance(val, list):
                        row += val
                    else:
                        row += [val]
                y.append(row)
                # print(row)
            # print(len(row), len(columnnames))
            return pd.DataFrame(y, index = t, columns = columnnames)

        if src == 'raw':
            if 'filename' not in kwargs.keys():
                raise Exception("filename not specified")
            else:
                filename = kwargs['filename']
                if 'mat' in filename:
                    self.df = load_mat(filename)
                else:
                    self.df = load_bin(filename)
                return self.df
            
        elif src == 'django-file':
            self.df = load_django_file(*args, **kwargs)
        elif src == 'django-db':
            self.df = read_db(*args)
        if self.df is not None:
            if len(self.df.index) > 1:
                dt = self.df.index[1] - self.df.index[0]
                if isinstance(dt, datetime.timedelta):
            	    dt = dt.total_seconds()
                self.fs = 1/dt
            else:
                pass
        return

    # SAVE ---------------------------------------------------------------------------------                                                                                  

    def save(self, tableName, timestamp, fields, values):
        recs = self.db_managers[tableName].filter(timestamp = timestamp)
        if len(recs) > 0:
            rec = recs[0]
            for field, value  in zip(fields, values):
                setattr(rec, field, value)
            rec.save()
        else:
            raise Exception("no record found")
    # SIGNAL PROC ---------------------------------------------------------------------------------                                                                           

    def get_statistics(self):
        self.mean = self.df.mean().tolist()
        self.std  = self.df.std().tolist()
        
#     def ssi(self, max_order = 100, i = 50, err = [0.01, 0.1, 0.99], max_poll = None, freq_ranges = None, **kwargs):
#         ssi_dat.y = self.df.to_numpy().T
#         ssi_dat.fs = self.fs
#         ssi_dat.max_order = max_order
#         ssi_dat.max_poll = max_poll
#         ssi_dat.err = err
#         if i is not None:
#             ssi_dat.i = i
#         ssi_dat.freq_ranges = freq_ranges
#         ssi_dat.show_plots = False
# 
#         print('ssi_dat: i = {}, stab_criteria={}'.format(ssi_dat.i, err))
#         t0 = time.time()
#         ssi_dat.ssi_dat(**kwargs)
#         self.ssi_dat = ssi_dat
# 

    # PLOT ---------------------------------------------------------------------------------                                                                                  

    # def plot(self, **kwargs):                                                                                                                                               
    #     # self.df.plot(**kwargs)                                                                                                                                            
    #     pl.plot(self.t, self.y)                                                                                                                                             
    #     pl.grid(True)                                                                                                                                                       

    def plot_bokeh(self, **kwargs):
        pd.set_option('plotting.backend', 'pandas_bokeh')
        p = self.df.plot(**kwargs, show_figure = False)
        p.toolbar.logo = None
        script, div = components(p)
        return script, div

    def psd(self, plot=True, **kwargs):
        # if 'figsize' in kwargs:
            # figure(figsize=kwargs.get('figsize'))
            # print(kwargs.get('figsize'))
            # del kwargs['figsize']
        f, Pxx_den = welch(self.df.to_numpy(), self.fs, nperseg=self.nfft, noverlap = fix(self.nfft*3/4), axis=0, **kwargs)
        self.F = f
        self.Pxx = Pxx_den
        if plot:
            pl.semilogy(f,sqrt(Pxx_den))
            pl.xlim(0,self.fs/2)
            pl.xlabel('Frequency (Hz)')
            pl.ylabel('PSD g/sq(Hz)')
            pl.grid(True)

    def lpf(self, r, **kwargs):
        sos = cheby1(8, 0.05, r, output='sos')
        sos = asarray(sos, dtype = self.y.dtype)
        self.y = sosfiltfilt(sos, self.y, **kwargs)



if __name__ == "__main__":
    s = SHM()
    s.load(src='raw', filename='data/1hr/smartply_acc1_acc_202305022200')
    # s.y = s.y[:2]                                                                                                                                                           
    s.plot()
    pl.figure()
    s.ssi(max_order = 100, i = 50, max_poll = 20)
    pl.show()




