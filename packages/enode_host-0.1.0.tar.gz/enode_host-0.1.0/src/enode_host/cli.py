import argparse
import asyncio
import contextlib
from typing import List, Optional

from .async_socket import run_client, run_server
from .protocol import (
    Mode,
    Toggle,
    build_past_stream,
    build_realtime_stream,
    build_sd_stream_start,
    build_sd_stream_stop,
    build_sd_clear,
    build_set_mode,
    build_start_daq,
    build_stop_daq,
)


def build_command_from_tokens(tokens: List[str]) -> Optional[bytes]:
    if not tokens:
        return None
    cmd = tokens[0].lower()
    if cmd == "start_daq":
        return build_start_daq()
    if cmd == "stop_daq":
        return build_stop_daq()
    if cmd == "set_mode":
        if len(tokens) < 2:
            raise ValueError("set_mode requires realtime|past")
        mode_token = tokens[1].lower()
        if mode_token == "realtime":
            mode = Mode.REALTIME
        elif mode_token == "past":
            mode = Mode.PAST
        else:
            raise ValueError("set_mode requires realtime|past")
        return build_set_mode(mode)
    if cmd == "realtime_stream":
        if len(tokens) < 2:
            raise ValueError("realtime_stream requires start|stop")
        toggle = Toggle.START if tokens[1].lower() == "start" else Toggle.STOP
        return build_realtime_stream(toggle)
    if cmd == "past_stream":
        if len(tokens) < 2:
            raise ValueError("past_stream requires start|stop")
        toggle = Toggle.START if tokens[1].lower() == "start" else Toggle.STOP
        if toggle == Toggle.START:
            if len(tokens) < 4:
                raise ValueError("past_stream start requires start_ms end_ms")
            return build_past_stream(toggle, int(tokens[2]), int(tokens[3]))
        return build_past_stream(toggle)
    if cmd == "sd_stream":
        if len(tokens) < 2:
            raise ValueError("sd_stream requires start|stop")
        if tokens[1].lower() == "start":
            if len(tokens) < 3:
                raise ValueError("sd_stream start requires hours")
            return build_sd_stream_start(int(tokens[2]))
        return build_sd_stream_stop()
    if cmd == "sd_clear":
        return build_sd_clear()
    raise ValueError(f"unknown command: {cmd}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="enode-host",
        description="Host-side tools for interacting with the ESP-IDF firmware.",
    )
    parser.add_argument(
        "--ping",
        action="store_true",
        help="Basic sanity check that the CLI is wired up.",
    )

    subparsers = parser.add_subparsers(dest="command")
    server_parser = subparsers.add_parser(
        "server",
        help="Run a TCP server for ESP-IDF nodes.",
    )
    server_parser.add_argument("--host", default="0.0.0.0")
    server_parser.add_argument("--port", type=int, default=3333)
    server_parser.add_argument(
        "--on-connect",
        nargs=argparse.REMAINDER,
        help="Send a protocol command immediately after a client connects.",
    )
    server_parser.add_argument(
        "--interactive",
        action="store_true",
        help="Read commands from stdin and broadcast to all clients.",
    )

    gui_parser = subparsers.add_parser(
        "gui",
        help="Run the wx GUI backed by the framed server.",
    )
    gui_parser.add_argument("--host", default="0.0.0.0")
    gui_parser.add_argument("--port", type=int, default=3333)

    socket_parser = subparsers.add_parser(
        "socket",
        help="Send a message over a TCP socket and print the response.",
    )
    socket_parser.add_argument("host")
    socket_parser.add_argument("port", type=int)
    socket_parser.add_argument("message")
    socket_parser.add_argument("--timeout", type=float, default=5.0)
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    if args.ping:
        print("pong")
        return 0

    if args.command is None:
        try:
            from .gui_framed import run_gui
        except Exception as exc:
            import traceback
            print(f"[gui] failed to start: {exc}")
            traceback.print_exc()
            return 2
        run_gui(host="0.0.0.0", port=3333)
        return 0

    if args.command == "server":
        on_connect_payload = None
        if args.on_connect:
            on_connect_payload = build_command_from_tokens(args.on_connect)

        if args.interactive:
            return asyncio.run(run_interactive_server(args.host, args.port, on_connect_payload))

        asyncio.run(run_server(args.host, args.port, on_connect_payload))
        return 0

    if args.command == "gui":
        try:
            from .gui_framed import run_gui
        except Exception as exc:
            import traceback
            print(f"[gui] failed to start: {exc}")
            traceback.print_exc()
            return 2
        run_gui(host=args.host, port=args.port)
        return 0

    if args.command == "socket":
        return run_client(args.host, args.port, args.message, args.timeout)

    parser.print_help()
    return 0


async def run_interactive_server(host: str, port: int, on_connect_payload: Optional[bytes]) -> int:
    queue: asyncio.Queue[bytes] = asyncio.Queue()
    server_task = asyncio.create_task(run_server(host, port, on_connect_payload, queue))

    try:
        while True:
            line = await asyncio.to_thread(input, "cmd> ")
            if not line:
                continue
            stripped = line.strip()
            if stripped in ("quit", "exit"):
                break
            tokens = stripped.split()
            try:
                payload = build_command_from_tokens(tokens)
            except ValueError as exc:
                print(f"[server] {exc}")
                continue
            if payload is None:
                continue
            await queue.put(payload)
    finally:
        server_task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await server_task

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
