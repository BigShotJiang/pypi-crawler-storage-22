# CONFIGURATION
rawFileLength_sec = 60
port = 3333
target_dir = "/home/kykoo/esp/esp-idf-v5.1.1/workspace/22_lvgl_gps_acc_mesh/attempt8/validation/02_mesh_test/"
target_dir = "/home/kykoo/OneDrive/esp/24_acc_svr_app/shm_v1/validation/data"
target_dir = "validation/data"
NNODES = 14
TIME_WINDOW_LENGTH_SEC = 30