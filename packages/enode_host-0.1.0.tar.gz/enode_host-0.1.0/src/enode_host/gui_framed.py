import logging
import threading

import wx

from .framed_mesh import FramedMesh
from .cli import build_command_from_tokens
from .protocol import (
    Toggle,
    build_realtime_stream,
    build_sd_clear,
    build_sd_stream_start,
    build_sd_stream_stop,
    build_set_daq_mode,
    build_start_daq,
    build_stop_daq,
)
from . import model
from . import view

logger = logging.getLogger(__name__)


class Controller:
    def __init__(self, host: str, port: int):
        self.model = model.Model(self)
        self.view = view.View(self)
        self.model.ui_log = self.view.append_status_message
        self.view.Show()
        self.mesh = FramedMesh(self.model, host=host, port=port)

        self.view.m_button_nodes_update.Bind(wx.EVT_BUTTON, self.on_change_node_nums)
        self.view.Bind(wx.EVT_MENU, self.on_exit, self.view.m_menu_file_quit)
        self.view.Bind(wx.EVT_MENU, self.on_merge_rt_files, self.view.m_menu_data_export)
        self.view.Bind(wx.EVT_MENU, self.on_merge_sd_files, self.view.m_menu_data_merge_sd)
        self.view.Bind(wx.EVT_MENU, self.on_plot_rt_merged, self.view.m_menu_data_plot_rt)
        self.view.Bind(wx.EVT_MENU, self.on_plot_sd_merged, self.view.m_menu_data_plot_sd)
        self.view.Bind(wx.EVT_MENU, self.on_clear_rt_files, self.view.m_menu_data_clear_rt)
        self.view.Bind(wx.EVT_MENU, self.on_clear_sd_files, self.view.m_menu_data_clear_sd)
        self.view.Bind(wx.EVT_MENU, self.on_view_clf, self.view.m_menu_view_clf)
        self.view.m_button1.Bind(wx.EVT_BUTTON, self.on_command_choice_send)
        self.view.m_textCtrl_cmd.Bind(wx.EVT_TEXT_ENTER, self.on_command_send)

    def on_change_node_nums(self, event):
        self.model.options["acc_nums_txt"] = self.view.m_textCtrl_acc.GetValue()
        self.model.options["tmp_nums_txt"] = self.view.m_textCtrl_tmp.GetValue()
        self.model.options["str_nums_txt"] = self.view.m_textCtrl_str.GetValue()
        self.model.options["veh_nums_txt"] = self.view.m_textCtrl_veh.GetValue()
        self.model.parse_node_nums_txt()
        self.model.save_config()
        self.model.init_mesh_status_data()
        self.model.init_other_data()
        self.view.mesh_status_data_view()
        self.view.m_grid2.ForceRefresh()
        self.view.init_plot()

    def on_exit(self, event):
        self.view.Close()

    def on_merge_rt_files(self, event):
        threading.Thread(target=self._run_merge_rt_files, daemon=True).start()

    def on_merge_sd_files(self, event):
        threading.Thread(target=self._run_merge_sd_files, daemon=True).start()

    def on_clear_rt_files(self, event):
        threading.Thread(target=self._run_clear_rt_files, daemon=True).start()

    def on_clear_sd_files(self, event):
        threading.Thread(target=self._run_clear_sd_files, daemon=True).start()

    def on_plot_rt_merged(self, event):
        threading.Thread(target=self._run_plot_rt_merged, daemon=True).start()

    def on_plot_sd_merged(self, event):
        threading.Thread(target=self._run_plot_sd_merged, daemon=True).start()

    def on_view_clf(self, event):
        self.model.init_other_data()
        self.view.init_plot()
        self.view.figure_update()

    def _broadcast(self, payload: bytes, label: str) -> None:
        sent = self.mesh.broadcast_command(payload, label=label)
        logger.info("command sent: %s (to %d clients)", label, sent)
        self.view.append_status_message(f"[cmd] sent {label} to {sent} clients")

    def on_command_choice_send(self, event):
        selection = self.view.m_choice_OperationMode.GetStringSelection()
        if selection == "DAQ Start":
            self._broadcast(build_start_daq(), "start_daq")
        elif selection == "DAQ Stop":
            self._broadcast(build_stop_daq(), "stop_daq")
        elif selection == "Realtime Stream Start":
            self._broadcast(build_realtime_stream(Toggle.START), "rt_stream_start")
        elif selection == "Realtime Stream Stop":
            self._broadcast(build_realtime_stream(Toggle.STOP), "rt_stream_stop")
        elif selection == "SD Stream Start":
            threading.Thread(
                target=self.mesh.stream_sd_sequential,
                args=(build_sd_stream_start(0), "sd_stream_start_all"),
                daemon=True,
            ).start()
        elif selection == "SD Stream Stop":
            self._broadcast(build_sd_stream_stop(), "sd_stream_stop")
        elif selection == "SD Clear All":
            self._broadcast(build_sd_clear(), "sd_clear")

    def set_daq_mode(self, node_id: str, mode: int) -> None:
        payload = build_set_daq_mode(mode)
        if self.mesh.send_command(node_id, payload, label=f"daq_mode={mode}"):
            self.view.append_status_message(f"[cmd] daq_mode={mode} -> {node_id}")
        else:
            self.view.append_status_message(f"[cmd] failed daq_mode={mode} -> {node_id}")

    def on_command_send(self, event):
        text = self.view.m_textCtrl_cmd.GetValue().strip()
        if not text:
            return
        self.view.append_status_message(f"> {text}")
        tokens = text.split()
        if tokens[0].lower() == "merge_sd_files":
            self.view.m_textCtrl_cmd.SetValue("")
            threading.Thread(target=self._run_merge_sd_files, daemon=True).start()
            return
        if len(tokens) >= 2 and tokens[0].lower() == "sd_stream" and tokens[1].lower() == "start":
            hours = 0
            if len(tokens) >= 3:
                try:
                    hours = int(tokens[2])
                except ValueError:
                    hours = 0
            self.view.m_textCtrl_cmd.SetValue("")
            threading.Thread(
                target=self.mesh.stream_sd_sequential,
                args=(build_sd_stream_start(hours), f"sd_stream_start({hours})"),
                daemon=True,
            ).start()
            return
        try:
            payload = build_command_from_tokens(tokens)
        except ValueError as exc:
            self.view.append_status_message(f"[cmd] {exc}")
            return
        if payload is None:
            return
        sent = self.mesh.broadcast_command(payload, label=text)
        self.view.append_status_message(f"[cmd] sent to {sent} clients")
        self.view.m_textCtrl_cmd.SetValue("")

    def _run_merge_sd_files(self):
        try:
            self.model.merge_sd_files()
        finally:
            wx.CallAfter(self.view.mesh_status_data_view)
            wx.CallAfter(self.view.m_grid2.ForceRefresh)
            wx.CallAfter(self.view.init_plot)
            wx.CallAfter(self.view.figure_update)
            wx.CallAfter(self.view.init_merged_plot)
            wx.CallAfter(self.view.figure_update_merged)
            wx.CallAfter(self.view.show_merged_plots)

    def _run_merge_rt_files(self):
        try:
            self.model.merge_rt_streamed_files()
        finally:
            wx.CallAfter(self.view.mesh_status_data_view)
            wx.CallAfter(self.view.m_grid2.ForceRefresh)
            wx.CallAfter(self.view.init_plot)
            wx.CallAfter(self.view.figure_update)
            wx.CallAfter(self.view.init_merged_plot)
            wx.CallAfter(self.view.figure_update_merged)
            wx.CallAfter(self.view.show_merged_plots)

    def _run_clear_rt_files(self):
        try:
            self.model.clear_rt_streamed_files()
        finally:
            wx.CallAfter(self.view.append_status_message, "[rt-clear] done")

    def _run_clear_sd_files(self):
        try:
            self.model.clear_sd_streamed_files()
        finally:
            wx.CallAfter(self.view.append_status_message, "[sd-clear] done")

    def _run_plot_rt_merged(self):
        try:
            self.model.load_latest_merged_rt()
        finally:
            wx.CallAfter(self.view.init_merged_plot)
            wx.CallAfter(self.view.figure_update_merged)
            wx.CallAfter(self.view.show_merged_plots)

    def _run_plot_sd_merged(self):
        try:
            self.model.load_latest_merged_sd()
        finally:
            wx.CallAfter(self.view.init_merged_plot)
            wx.CallAfter(self.view.figure_update_merged)
            wx.CallAfter(self.view.show_merged_plots)


def run_gui(host: str = "0.0.0.0", port: int = 3333) -> None:
    app = wx.App()
    Controller(host=host, port=port)
    app.MainLoop()
