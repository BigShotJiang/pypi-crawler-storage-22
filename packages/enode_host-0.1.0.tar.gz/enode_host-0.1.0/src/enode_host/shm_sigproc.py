import threading
import logging
try:
    from . import queues
except ImportError:
    import queues
try:
    from . import resampling
except ImportError:
    import resampling
try:
    from . import storage
except ImportError:
    import storage
import time

logger = logging.getLogger(__name__)

Resamplers = {}
Storage = storage.Storage(600) # 600 sec

def update():
    # this function 
    # - reads the queue and 
    # - resamples the measurement
    # - push resampled data into storage

    while True:
        if not queues.Mesh2Storage.empty():
            # logger.info("message received for t, a")
            item = queues.Mesh2Storage.get()
            nodeID = item['nodeID']  # starting from 1 representing ACC1                              
            t = item['t']
            y = item['acc']
            if not nodeID in Resamplers.keys():
                Resamplers[nodeID] = resampling.resampling(62.5)
            t_rs, y_rs = Resamplers[nodeID].push(t, y)
            # logger.info("resampled timestamp = {}".format(t_rs[0]))
            Storage.push(nodeID, t_rs, y_rs)                    
        else:
            time.sleep(0.01)
def begin():

    # start a thread to run update() function
    thread = threading.Thread(target = update)
    thread.start()
    logger.info("sigproc update started.")
