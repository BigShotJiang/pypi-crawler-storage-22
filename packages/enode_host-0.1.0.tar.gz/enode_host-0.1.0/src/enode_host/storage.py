from numpy import floor 
import datetime 
from pandas import DataFrame, to_datetime
import time
import copy
import logging
import os
try:
    from .constants import RT_STREAM_HD5_DIR
except ImportError:
    from constants import RT_STREAM_HD5_DIR
import re

logger = logging.getLogger(__name__)

class Storage:
    
    def __init__(self, file_length_in_sec):
        self.file_buf = {} 
        # the buffer for file outputs 
        # {
        #   'acc1':{'t':[], 'y':[], 'last_gridTime':-1}, 
        #   'acc2':{'t':[], 'y':[], 'last_gridTime':-1}, 
        # }
        self.file_length_in_sec = file_length_in_sec
        self.tmp_length_in_sec = 24 * 60 * 60
        os.makedirs(RT_STREAM_HD5_DIR, exist_ok=True)

    def _length_for_node(self, nodeID):
        if isinstance(nodeID, int):
            return self.file_length_in_sec
        match = re.match(r"([A-Za-z]+)", str(nodeID))
        if match and match.group(1).upper() == "TMP":
            return self.tmp_length_in_sec
        return self.file_length_in_sec

    def get_gridTime(self, t, nodeID):
        length = self._length_for_node(nodeID)
        return floor(t / length) * length
    
    def get_filepath(self, nodeID, t):
        timestamp = datetime.datetime.fromtimestamp(t).strftime('%Y_%m%d_%H%M')
        label = None
        if isinstance(nodeID, int):
            label = f"acc{nodeID:02d}"
        else:
            match = re.match(r"([A-Za-z]+)(\\d+)$", str(nodeID))
            if match:
                node_type = match.group(1).lower()
                node_num = int(match.group(2))
                label = f"{node_type}{node_num:02d}"
            else:
                label = str(nodeID).lower()
        return os.path.join(RT_STREAM_HD5_DIR, f"{timestamp}-{label}.hd5")

    def push(self, nodeID, t, y):
        if not nodeID in self.file_buf.keys():
            self.file_buf[nodeID] = {'last_gridTime': -1, 't':[], 'y':[]}
        
        for t_, y_ in zip(t, y):
            current_gridTime = self.get_gridTime(t_.timestamp(), nodeID)
            if self.file_buf[nodeID]['last_gridTime'] == -1:
                self.file_buf[nodeID]['last_gridTime'] = current_gridTime
            elif self.file_buf[nodeID]['last_gridTime'] != current_gridTime:
                # Save to disk in HDF
                df = DataFrame(self.file_buf[nodeID]['y'], columns = ['X', 'Y', 'Z'])
                df.index = to_datetime(self.file_buf[nodeID]['t'])
                filepath = self.get_filepath(nodeID, self.file_buf[nodeID]['last_gridTime'])
                df.to_hdf(filepath, key='df', mode='w')
                logger.info("file saved: {}".format(filepath))
                # Reinitialise
                self.file_buf[nodeID]['last_gridTime'] = copy.copy(current_gridTime)
                self.file_buf[nodeID]['t'] = []
                self.file_buf[nodeID]['y'] = []
                
            self.file_buf[nodeID]['t'].append(t_)
            self.file_buf[nodeID]['y'].append(y_)



if __name__ == '__main__':
    import pandas as pd

    t = [datetime.datetime(2024,1,1,0,i,j)  for i in range(3) for j in range(60)]    
    y = [[i,2*i,3*i] for i in range(180)]
    storage = Storage(60)
    i = 0
    # t[60*i:60*(i+1)]
    # y[60*i:60*(i+1)]
    for i in range(3):
        storage.push(1, t[60*i:60*(i+1)], y[60*i:60*(i+1)])
    
    
