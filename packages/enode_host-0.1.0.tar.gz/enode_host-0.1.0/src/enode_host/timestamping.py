from numpy import empty, append, array, where, logical_and, delete
from scipy.interpolate import interp1d
try:
    from . import config
except ImportError:
    import config
import struct
import datetime

class Timestamping():
     
    def __init__(self):

        self.CC_ppsEpoch = empty((0, 2), dtype = float)   # array( [[cc0, epoch_PPS0], [cc1, epoch_PPS1]] )
        self.CC_ACC = empty((0, 4), dtype = float)        # array( [[cc, acc_x, acc_y, acc_z], ...])

    def push_cc_acc(self, cc_acc):

        # only add when it is a new data
        if self.CC_ppsEpoch.shape[0] > 1 and cc_acc[0] > self.CC_ppsEpoch[1, 0]:
            self.CC_ACC = append(self.CC_ACC, array([cc_acc]), axis=0) # CC, acc_x, acc_y, acc_z
    
    def push_cc_pps(self, CC, epoch_time):

        # Populating CC_ppsEpoch Table
        self.CC_ppsEpoch = append(self.CC_ppsEpoch, array([[CC, epoch_time]]), axis = 0)
        if len(self.CC_ppsEpoch) == 1:
            return [], []
        elif len(self.CC_ppsEpoch) == 3:
            self.CC_ppsEpoch = self.CC_ppsEpoch[1:, :]  # shifting CC_ppsEpoch            
        
        # timestamping 
        cc0 = self.CC_ppsEpoch[0, 0]
        cc1 = self.CC_ppsEpoch[1, 0]
        idx = where(logical_and(self.CC_ACC[:,0] >= cc0, self.CC_ACC[:,0] < cc1))
        if len(idx[0]) > 0:
            cc_acc = self.CC_ACC[idx[0], :]
            linear_interp = interp1d(self.CC_ppsEpoch[:2, 0], self.CC_ppsEpoch[:2, 1], kind = 'linear')
            x_interp = cc_acc[:, 0]
            y_interp = linear_interp(x_interp)
            t = []
            for i in range(cc_acc.shape[0]):
                epoch = int(y_interp[i])
                suseconds = int((y_interp[i] - epoch) * 1e6)
                t_ = datetime.datetime.fromtimestamp(epoch, tz=datetime.timezone.utc)
                t_ = t_.replace(microsecond = suseconds)
                t.append(t_)
            y = cc_acc[:, 1:4]
            # Delete already timestamped points
            mask = self.CC_ACC[:, 0] >= cc1
            self.CC_ACC = self.CC_ACC[mask,...]
            return t, y
            
        return [], []
    
    

    # rawFileLength_sec = config.rawFileLength_sec
    # def getGridTime(self, epoch):
    #     return int(epoch / rawFileLength_sec) * rawFileLength_sec
    # # FILE SAVING 
    # if 0:
    #     if epoch_time > 0: 
    #         if fid == -1:
    #             latest_fileName = self.getFileName(streamID, epoch_time)
    #             fid = open(latest_fileName, "wb")
    #         elif self.getFileName(streamID, epoch_time) != latest_fileName:
    #             fid.close()
    #             latest_fileName = self.getFileName(streamID, epoch_time)
    #             fid = open(latest_fileName, "wb")
    #     if fid != -1:
    #         fid.write(packet[2:])
    # data = data[packet_size:]

    # def getFileName(self, streamID, epoch_time):
    #     nodeNumber = (streamID & 0x0FF0) >> 4
    #     streamID_str = 'ACC{}-ACC'.format(nodeNumber)
    #     t = datetime.datetime.fromtimestamp(epoch_time)
    #     return os.path.join(target_dir, '{}-{}'.format(datetime.datetime.strftime(t, '%Y_%m%d_%H%M'), streamID_str))
