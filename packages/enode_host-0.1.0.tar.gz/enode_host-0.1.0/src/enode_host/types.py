from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional
import datetime


@dataclass
class NodeStatus:
    node_id: int
    node_label: str
    connection: str = "waiting"
    speed_kb_s: float = 0.0
    level: Optional[int] = None
    parent: str = ""
    rssi_db: Optional[int] = None
    children: str = ""
    pps_age: str = ""
    cmd: str = ""
    pps_time: Optional[datetime.datetime] = None
    pps_flash_time: Optional[datetime.datetime] = None
    daq_time: Optional[datetime.datetime] = None
    parent_mac: Optional[str] = None
    self_mac: Optional[str] = None
    conn_rpt_time: Optional[datetime.datetime] = None


@dataclass
class PpsFlashState:
    flash_until: Optional[datetime.datetime] = None


@dataclass
class PlotBuffers:
    timehistory_xdata: List[datetime.datetime] = field(default_factory=list)
    timehistory_ydata: List[List[float]] = field(default_factory=list)
    psd_xdata: List[float] = field(default_factory=list)
    psd_ydata: Dict[int, List[List[float]]] = field(default_factory=dict)
