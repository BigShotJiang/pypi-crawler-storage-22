#!/usr/local/bin/python3
# -*- coding: utf-8 -*-

#
# This is the file to construct GUI elements
#


###########################################################################
## Python code generated with wxFormBuilder (version 4.2.1-0-g80c4cb6)
## http://www.wxformbuilder.org/
##
## PLEASE DO *NOT* EDIT THIS FILE!
###########################################################################

import wx
import wx.xrc
import wx.grid

import gettext
_ = gettext.gettext

import wx
import wx.lib.agw.aui as aui
import wx.lib.mixins.inspection as wit
from matplotlib.backends.backend_wxagg import FigureCanvasWxAgg as FigureCanvas
from matplotlib.backends.backend_wxagg import \
    NavigationToolbar2WxAgg as NavigationToolbar
from matplotlib.figure import Figure
import matplotlib.dates as mdates
import wx.grid as gridlib
try:
    import wx.html2 as webview
except ImportError:
    webview = None
try:
    from . import queues
except ImportError:
    import queues
import datetime
from numpy import empty, where, array, delete, append, ones, nan, floor, shape
import random
import logging
import time
import math
try:
    from .constants import (
        GUI_TIMER_MS,
        LEVEL_COL,
        SPEED_COL,
        RSSI_COL,
        PPS_AGE_LIMIT_SEC,
        PPS_AGE_UPDATE_MS,
        PPS_COL,
    )
except ImportError:
    from constants import (
        GUI_TIMER_MS,
        LEVEL_COL,
        SPEED_COL,
        RSSI_COL,
        PPS_AGE_LIMIT_SEC,
        PPS_AGE_UPDATE_MS,
        PPS_COL,
    )
import pandas as pd

if "SPEED_COL" not in globals():
    SPEED_COL = "Speed\n(kB/s)"

logger = logging.getLogger(__name__)

class Plot(wx.Panel):
    def __init__(self, parent, id=-1, dpi=None, **kwargs):
        super().__init__(parent, id=id, **kwargs)
        self.figure = Figure(dpi=dpi, figsize=(2, 2))
        self.canvas = FigureCanvas(self, -1, self.figure)
        self.toolbar = NavigationToolbar(self.canvas)
        self.toolbar.Realize()

        sizer = wx.BoxSizer(wx.VERTICAL)
        sizer.Add(self.canvas, 1, wx.EXPAND)
        sizer.Add(self.toolbar, 0, wx.LEFT | wx.EXPAND)
        self.SetSizer(sizer)

class PandasTable(wx.grid.GridTableBase):
    def __init__(self, dataframe):
        wx.grid.GridTableBase.__init__(self)
        self.dataframe = dataframe

    def GetNumberRows(self):
        return self.dataframe.shape[0]

    def GetNumberCols(self):
        return self.dataframe.shape[1]

    def GetValue(self, row, col):
        # Fetch value from pandas DataFrame
        return str(self.dataframe.iat[row, col])

    def SetValue(self, row, col, value):
        # Set value in pandas DataFrame
        self.dataframe.iat[row, col] = value
        self.GetView().ForceRefresh()

    def GetColLabelValue(self, col):
        # Get column names from pandas DataFrame
        return str(self.dataframe.columns[col])

    def GetRowLabelValue(self, row):
        # Optional: Get row indices from pandas DataFrame
        return str(self.dataframe.index[row])

    def update_table(self):
        # msg = wx.grid.GridTableMessage(self, wx.grid.GRIDTABLE_NOTIFY_TABLE_RESET)
        msg = wx.grid.GridTableMessage(self, wx.grid.GRIDTABLE_NOTIFY_ROWS_APPENDED)
        self.GetView().ProcessTableMessage(msg)


class TableUpdater:
    def __init__(self, view):
        self.view = view
        self.model = view.model
        self.grid = view.m_grid2
        self.table = None

    def setup_table(self):
        self.table = PandasTable(self.model.mesh_status_data)
        self.grid.SetTable(self.table, takeOwnership=True)
        self.grid.SetColLabelSize(40)
        self.col_index = {
            name: self.model.mesh_status_data.columns.get_loc(name)
            for name in self.model.mesh_status_data.columns
        }
        self.view.col_index = self.col_index
        self.grid.SetColSize(self.col_index["Node ID"], 70)
        self.grid.SetColSize(self.col_index["Connection"], 90)
        self.grid.SetColSize(self.col_index["Sensor"], 80)
        self.grid.SetColSize(self.col_index["DAQ Mode"], 120)
        if "DAQ" in self.col_index:
            self.grid.SetColSize(self.col_index["DAQ"], 40)
        if "Stream" in self.col_index:
            self.grid.SetColSize(self.col_index["Stream"], 60)
        self.grid.SetColSize(self.col_index[SPEED_COL], 60)
        self.grid.SetColSize(self.col_index[LEVEL_COL], 20)
        self.grid.SetColSize(self.col_index["Parent"], 70)
        self.grid.SetColSize(self.col_index[RSSI_COL], 40)
        self.grid.SetColSize(self.col_index["Children"], 70)
        self.grid.SetColSize(self.col_index[PPS_COL], 40)
        self.grid.SetColSize(self.col_index["CMD"], 200)
        for hidden in [
            "PPS-time",
            "PPS-flash-time",
            "DAQ-time",
            "Parent MAC",
            "Self MAC",
            "nodeID",
            "ConnRptTime",
            "node_number",
            "node_type",
        ]:
            if hidden in self.col_index:
                self.grid.SetColSize(self.col_index[hidden], 0)

    def refresh(self):
        self.grid.ForceRefresh()
        self.update_status_table()

    def update_status_table(self):
        for index, row in self.model.mesh_status_data.iterrows():
            if row['Connection'] == 'disconnected':
                attr = gridlib.GridCellAttr()
                attr.SetTextColour(wx.Colour(255, 0, 0))
                attr.SetBackgroundColour(wx.Colour(255, 255, 255))
                self.grid.SetAttr(index, self.col_index["Connection"], attr)
            else:
                attr = gridlib.GridCellAttr()
                attr.SetTextColour(wx.Colour(0, 0, 0))
                attr.SetBackgroundColour(wx.Colour(255, 255, 255))
                self.grid.SetAttr(index, self.col_index["Connection"], attr)

    def update_pps_age(self):
        t_now = datetime.datetime.now(datetime.timezone.utc)
        for index, row in self.model.mesh_status_data.iterrows():
            pps_time = row['PPS-time']
            if isinstance(pps_time, datetime.datetime):
                if pps_time.tzinfo is None:
                    pps_time = pps_time.replace(tzinfo=datetime.timezone.utc)
                age = (t_now - pps_time).total_seconds()
                value = f"{age:.1f}s" if age <= PPS_AGE_LIMIT_SEC else ''
            else:
                value = ''
            node_id = row.get('nodeID')
            if hasattr(self.model, "_set_node_fields"):
                self.model._set_node_fields(node_id, mark_dirty=False, **{PPS_COL: value})
            else:
                self.model.mesh_status_data.loc[index, PPS_COL] = value
        self.grid.ForceRefresh()

    def update_pps_flash(self):
        t_now = datetime.datetime.now(datetime.timezone.utc)
        with self.model.pps_flash_lock:
            flash_until_map = dict(self.model.pps_flash_until)
        for index, row in self.model.mesh_status_data.iterrows():
            node_id = row.get('nodeID')
            until = flash_until_map.get(node_id)
            attr = gridlib.GridCellAttr()
            if isinstance(until, datetime.datetime):
                if until.tzinfo is None:
                    until = until.replace(tzinfo=datetime.timezone.utc)
                if t_now <= until:
                    attr.SetTextColour(wx.Colour(0, 180, 0))
                else:
                    attr.SetTextColour(wx.Colour(0, 0, 0))
            else:
                attr.SetTextColour(wx.Colour(0, 0, 0))
            self.grid.SetAttr(index, self.col_index[PPS_COL], attr)


class PlotUpdater:
    def __init__(self, view):
        self.view = view
        self.model = view.model
        self.axes1 = view.axes1
        self.axes2 = view.axes2
        self.timehistory_lines = {}
        self.psd_lines = {}
        self._psd_legend_labels = {}

    def init_plot(self):
        self.timehistory_lines = {}
        self.psd_lines = {}
        self._psd_legend_labels = {}

        self.axes1.cla()
        locator = mdates.AutoDateLocator(minticks=3, maxticks=6)
        formatter = mdates.DateFormatter("%H:%M:%S")
        self.axes1.xaxis.set_major_locator(locator)
        self.axes1.xaxis.set_major_formatter(formatter)
        for _, row in self.model.mesh_status_data.iterrows():
            if not str(row['Node ID']).startswith('ACC'):
                continue
            for idx, ch in enumerate(['X', 'Y', 'Z']):
                if self.view.channel_selection[idx]:
                    node_id_ch = row['Node ID'] + ch
                    self.timehistory_lines[node_id_ch] = self.axes1.plot([], [], label=node_id_ch)[0]
        self.axes1.set_xlabel('Time')
        self.axes1.set_ylabel('Acceleration (g)')
        self.axes1.grid(True)
        self.axes1.set_ylim(-2, 2)
        self.axes1.tick_params(axis='x', labelbottom=True, pad=2)
        self.axes1.legend()
        self.view.m_fig.figure.autofmt_xdate(rotation=0, ha='right')
        self.axes1.tick_params(axis='x', labelbottom=True, pad=2)

        self.axes2.cla()
        for _, row in self.model.mesh_status_data.iterrows():
            if not str(row['Node ID']).startswith('ACC'):
                continue
            for idx, ch in enumerate(['X', 'Y', 'Z']):
                if self.view.channel_selection[idx]:
                    node_id_ch = row['Node ID'] + ch
                    self.psd_lines[node_id_ch] = self.axes2.semilogy([], [], label=node_id_ch)[0]

        self.axes2.set_xlabel('Frequency (Hz)')
        self.axes2.set_ylabel('ASD (g/sq(Hz))')
        self.axes2.grid(True)
        self.axes2.set_ylim(1e-6, 1e1)
        self.axes2.set_xlim(0, 25)
        self.axes2.legend()

    def figure_update(self):
        for _, row in self.model.mesh_status_data.iterrows():
            node_id = row['nodeID']
            for idx, ch in enumerate(['X', 'Y', 'Z']):
                node_id_ch = row['Node ID'] + ch
                if node_id_ch in self.timehistory_lines and node_id in self.model.timehistory_xdata:
                    with self.model.plot_mutex[node_id]:
                        if len(self.model.timehistory_xdata[node_id]) > 1:
                            self.timehistory_lines[node_id_ch].set_xdata(self.model.timehistory_xdata[node_id])
                            self.timehistory_lines[node_id_ch].set_ydata(self.model.timehistory_ydata[node_id][:, idx])
        if self.model.timehistory_xlim:
            self.axes1.set_xlim(self.model.timehistory_xlim)
        try:
            self.view.m_fig.figure.canvas.draw()
        except Exception:
            raise

        for _, row in self.model.mesh_status_data.iterrows():
            node_id = row['nodeID']
            for idx, ch in enumerate(['X', 'Y', 'Z']):
                node_id_ch = row['Node ID'] + ch
                if node_id_ch in self.psd_lines and node_id in self.model.psd_ydata:
                    with self.model.plot_mutex[node_id]:
                        self.psd_lines[node_id_ch].set_xdata(self.model.psd_xdata)
                        self.psd_lines[node_id_ch].set_ydata(self.model.psd_ydata[node_id][:, idx])

        if len(self.model.psd_xdata) > 0:
            self.axes2.set_xlim(0, round(self.model.psd_xdata[-1]))
        try:
            self.view.m_fig.figure.canvas.draw()
        except Exception:
            raise

    def update_psd_legend(self):
        if not self.psd_lines:
            return
        changed = False
        for _, row in self.model.mesh_status_data.iterrows():
            node_id = row['nodeID']
            node_label = row['Node ID']
            psder = self.model.psder.get(node_id)
            seconds_left = None
            if psder is not None:
                try:
                    seconds_left = psder.seconds_until_next_update()
                except Exception:
                    seconds_left = None
            label_suffix = ""
            if seconds_left is not None:
                sec_int = int(math.ceil(seconds_left))
                if sec_int < 0:
                    sec_int = 0
                label_suffix = f" ({sec_int} sec)"
            for ch in ['X', 'Y', 'Z']:
                node_ch = node_label + ch
                line = self.psd_lines.get(node_ch)
                if line is None:
                    continue
                new_label = node_ch + label_suffix if label_suffix else node_ch
                if self._psd_legend_labels.get(node_ch) != new_label:
                    line.set_label(new_label)
                    self._psd_legend_labels[node_ch] = new_label
                    changed = True
        if changed:
            self.axes2.legend()
            try:
                self.view.m_fig.figure.canvas.draw_idle()
            except Exception:
                pass

    
class MergedPlotUpdater:
    def __init__(self, view):
        self.view = view
        self.model = view.model
        self.axes1 = view.axes1_merged
        self.axes2 = view.axes2_merged
        self.timehistory_lines = {}
        self.psd_lines = {}

    def _node_label(self, node_id):
        return str(node_id).upper()

    def init_plot(self):
        self.timehistory_lines = {}
        self.psd_lines = {}

        self.axes1.cla()
        locator = mdates.AutoDateLocator(minticks=3, maxticks=6)
        formatter = mdates.DateFormatter("%H:%M:%S")
        self.axes1.xaxis.set_major_locator(locator)
        self.axes1.xaxis.set_major_formatter(formatter)
        for node_id in self.model.merged_node_ids:
            node_label = self._node_label(node_id)
            for idx, ch in enumerate(['X', 'Y', 'Z']):
                if self.view.channel_selection[idx]:
                    label = node_label + ch
                    self.timehistory_lines[label] = self.axes1.plot([], [], label=label)[0]
        self.axes1.set_xlabel('Time')
        self.axes1.set_ylabel('Acceleration (g)')
        self.axes1.grid(True)
        self.axes1.set_ylim(-2, 2)
        self.axes1.tick_params(axis='x', labelbottom=True, pad=2)
        self.axes1.legend()
        self.view.m_fig_merged.figure.autofmt_xdate(rotation=0, ha='right')
        self.axes1.tick_params(axis='x', labelbottom=True, pad=2)

        self.axes2.cla()
        for node_id in self.model.merged_node_ids:
            node_label = self._node_label(node_id)
            for idx, ch in enumerate(['X', 'Y', 'Z']):
                if self.view.channel_selection[idx]:
                    label = node_label + ch
                    self.psd_lines[label] = self.axes2.semilogy([], [], label=label)[0]

        self.axes2.set_xlabel('Frequency (Hz)')
        self.axes2.set_ylabel('ASD (g/sq(Hz))')
        self.axes2.grid(True)
        self.axes2.set_ylim(1e-6, 1e1)
        self.axes2.set_xlim(0, 25)
        self.axes2.legend()

    def figure_update(self):
        for node_id in self.model.merged_node_ids:
            node_label = self._node_label(node_id)
            xdata = self.model.merged_timehistory_xdata.get(node_id)
            ydata = self.model.merged_timehistory_ydata.get(node_id)
            if not xdata or ydata is None:
                continue
            for idx, ch in enumerate(['X', 'Y', 'Z']):
                label = node_label + ch
                line = self.timehistory_lines.get(label)
                if line is not None:
                    line.set_xdata(xdata)
                    line.set_ydata(ydata[:, idx])
        if self.model.merged_timehistory_xlim:
            self.axes1.set_xlim(self.model.merged_timehistory_xlim)
        try:
            self.view.m_fig_merged.figure.canvas.draw()
        except Exception:
            raise

        f = self.model.merged_psd_xdata
        if f is None:
            f = []
        for node_id in self.model.merged_node_ids:
            node_label = self._node_label(node_id)
            ydata = self.model.merged_psd_ydata.get(node_id)
            if ydata is None or len(f) == 0:
                continue
            for idx, ch in enumerate(['X', 'Y', 'Z']):
                label = node_label + ch
                line = self.psd_lines.get(label)
                if line is not None:
                    line.set_xdata(f)
                    line.set_ydata(ydata[:, idx])

        if len(f) > 0:
            self.axes2.set_xlim(0, round(f[-1]))
        try:
            self.view.m_fig_merged.figure.canvas.draw()
        except Exception:
            raise

###########################################################################
## Class View
###########################################################################

class View(wx.Frame):

    def __init__(self, parent):

        wx.Frame.__init__ ( self, None, id = wx.ID_ANY, title = _(u"Wireless Sensor DAQ"), pos = wx.DefaultPosition, size = wx.Size( 1024,600 ), style = wx.DEFAULT_FRAME_STYLE|wx.TAB_TRAVERSAL )

        self.controller = parent
        self.model = self.controller.model
        if self.model is not None:
            self.timespan_length = self.model.timespan_length
        self.m_table = None
        self.table_updater = None
        self.plot_updater = None
        self.merged_plot_updater = None
        self.PPS_outdate_check = True 
        self.channel_selection = [False, True, False]

        self.SetSizeHints( wx.DefaultSize, wx.DefaultSize )

        bSizer1 = wx.BoxSizer( wx.VERTICAL )
        # # Fs selection
        # self.m_staticText3 = wx.StaticText( self, wx.ID_ANY, _(u"Fs="), wx.DefaultPosition, wx.DefaultSize, 0 )
        # self.m_staticText3.Wrap(-1)
        # bSizer2.Add( self.m_staticText3, 0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 5 )

        # m_choice1Choices = [ _(u"62.5"), _(u"125") ]
        # self.m_choice1 = wx.Choice( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, m_choice1Choices, 0 )
        # self.m_choice1.SetSelection( 0 )
        # bSizer2.Add( self.m_choice1, 0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 5 )
        
        # self.m_staticText4 = wx.StaticText( self, wx.ID_ANY, _(u"Hz"), wx.DefaultPosition, wx.DefaultSize, 0 )
        # self.m_staticText4.Wrap(-1)
        # bSizer2.Add( self.m_staticText4, 0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 5 )

        bSizer3 = wx.BoxSizer( wx.VERTICAL )

        self.m_left_notebook = wx.Notebook(self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, 0)
        self.m_left_notebook.SetMinSize(wx.Size(300, -1))
        self.m_panel_nodes = wx.Panel(self.m_left_notebook, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL)
        self.m_panel_status = wx.Panel(self.m_left_notebook, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL)
        self.m_panel_map = wx.Panel(self.m_left_notebook, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL)
        self.m_panel_plots = wx.Panel(self.m_left_notebook, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL)
        self.m_panel_merged_plots = wx.Panel(self.m_left_notebook, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL)
        self.m_left_notebook.AddPage(self.m_panel_nodes, _(u"Nodes"), False)
        self.m_left_notebook.AddPage(self.m_panel_status, _(u"Mesh"), True)
        self.m_left_notebook.AddPage(self.m_panel_map, _(u"Map"), False)
        self.m_left_notebook.AddPage(self.m_panel_plots, _(u"RT-Plot"), False)
        self.m_left_notebook.AddPage(self.m_panel_merged_plots, _(u"Merged Plot"), False)
        self.tab_index_nodes = 0
        self.tab_index_status = 1
        self.tab_index_map = 2
        self.tab_index_rt_plots = 3
        self.tab_index_merged_plots = 4

        # Sensor Nodes definition tab
        nodes_sizer = wx.BoxSizer(wx.VERTICAL)
        self.m_nodes_box = wx.StaticBoxSizer(wx.StaticBox(self.m_panel_nodes, wx.ID_ANY, _(u"Sensor Nodes")), wx.VERTICAL)
        nodes_grid = wx.FlexGridSizer(4, 2, 4, 6)
        nodes_grid.AddGrowableCol(1, 1)

        self.m_staticText_acc = wx.StaticText(self.m_panel_nodes, wx.ID_ANY, _(u"ACC:"), wx.DefaultPosition, wx.DefaultSize, 0)
        nodes_grid.Add(self.m_staticText_acc, 0, wx.ALIGN_CENTER_VERTICAL)
        self.m_textCtrl_acc = wx.TextCtrl(
            self.m_panel_nodes,
            wx.ID_ANY,
            self.controller.model.options.get('acc_nums_txt', '[1:3]'),
            wx.DefaultPosition,
            wx.DefaultSize,
            0,
        )
        nodes_grid.Add(self.m_textCtrl_acc, 1, wx.EXPAND)

        self.m_staticText_tmp = wx.StaticText(self.m_panel_nodes, wx.ID_ANY, _(u"TMP:"), wx.DefaultPosition, wx.DefaultSize, 0)
        nodes_grid.Add(self.m_staticText_tmp, 0, wx.ALIGN_CENTER_VERTICAL)
        self.m_textCtrl_tmp = wx.TextCtrl(
            self.m_panel_nodes,
            wx.ID_ANY,
            self.controller.model.options.get('tmp_nums_txt', '[]'),
            wx.DefaultPosition,
            wx.DefaultSize,
            0,
        )
        nodes_grid.Add(self.m_textCtrl_tmp, 1, wx.EXPAND)

        self.m_staticText_str = wx.StaticText(self.m_panel_nodes, wx.ID_ANY, _(u"STR:"), wx.DefaultPosition, wx.DefaultSize, 0)
        nodes_grid.Add(self.m_staticText_str, 0, wx.ALIGN_CENTER_VERTICAL)
        self.m_textCtrl_str = wx.TextCtrl(
            self.m_panel_nodes,
            wx.ID_ANY,
            self.controller.model.options.get('str_nums_txt', '[]'),
            wx.DefaultPosition,
            wx.DefaultSize,
            0,
        )
        nodes_grid.Add(self.m_textCtrl_str, 1, wx.EXPAND)

        self.m_staticText_veh = wx.StaticText(self.m_panel_nodes, wx.ID_ANY, _(u"VEH:"), wx.DefaultPosition, wx.DefaultSize, 0)
        nodes_grid.Add(self.m_staticText_veh, 0, wx.ALIGN_CENTER_VERTICAL)
        self.m_textCtrl_veh = wx.TextCtrl(
            self.m_panel_nodes,
            wx.ID_ANY,
            self.controller.model.options.get('veh_nums_txt', '[]'),
            wx.DefaultPosition,
            wx.DefaultSize,
            0,
        )
        nodes_grid.Add(self.m_textCtrl_veh, 1, wx.EXPAND)

        self.m_nodes_box.Add(nodes_grid, 1, wx.EXPAND | wx.ALL, 0)
        nodes_sizer.Add(self.m_nodes_box, 0, wx.ALL | wx.EXPAND, 8)

        self.m_button_nodes_update = wx.Button(self.m_panel_nodes, wx.ID_ANY, _(u"Update"), wx.DefaultPosition, wx.DefaultSize, 0)
        nodes_sizer.Add(self.m_button_nodes_update, 0, wx.ALL | wx.ALIGN_RIGHT, 8)
        self.m_panel_nodes.SetSizer(nodes_sizer)

        # WiFi Mesh Status tab
        status_sizer = wx.BoxSizer(wx.VERTICAL)
        self.m_grid2 = wx.grid.Grid(self.m_panel_status, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, 0)
        self.table_updater = TableUpdater(self)
        self.table_updater.setup_table()
        self.m_table = self.table_updater.table

        # Grid
        self.nrows = len(self.controller.model.mesh_status_data)
        self.m_grid2.SetRowLabelSize(0)
        self.m_grid2.SetDefaultCellAlignment( wx.ALIGN_CENTER, wx.ALIGN_CENTER)
        self.m_grid2.Bind(wx.grid.EVT_GRID_CELL_CHANGED, self.on_daq_mode_change)
        self.m_grid2.Bind(wx.grid.EVT_GRID_SELECT_CELL, self.on_grid_select_cell)
        status_sizer.Add(self.m_grid2, 1, wx.ALL | wx.EXPAND, 5)
        self.m_panel_status.SetSizer(status_sizer)

        map_sizer = wx.BoxSizer(wx.VERTICAL)
        if webview is not None:
            self.m_map = webview.WebView.New(self.m_panel_map)
            map_sizer.Add(self.m_map, 1, wx.ALL | wx.EXPAND, 5)
            self.m_map_loaded = False
            self.m_map.Bind(webview.EVT_WEBVIEW_LOADED, self.on_map_loaded)
            self._load_map()
        else:
            self.m_map = None
            msg = wx.StaticText(
                self.m_panel_map,
                wx.ID_ANY,
                _(u"Map view unavailable (wx.html2 not installed)."),
            )
            map_sizer.Add(msg, 0, wx.ALL, 8)
        self.m_panel_map.SetSizer(map_sizer)

        plots_sizer = wx.BoxSizer(wx.VERTICAL)
        self.m_plot_panel = wx.Panel(self.m_panel_plots, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL)
        plots_sizer.Add(self.m_plot_panel, 1, wx.ALL | wx.EXPAND, 5)
        self.m_panel_plots.SetSizer(plots_sizer)

        merged_plots_sizer = wx.BoxSizer(wx.VERTICAL)
        self.m_plot_panel_merged = wx.Panel(self.m_panel_merged_plots, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL)
        merged_plots_sizer.Add(self.m_plot_panel_merged, 1, wx.ALL | wx.EXPAND, 5)
        self.m_panel_merged_plots.SetSizer(merged_plots_sizer)

        bSizer3.Add(self.m_left_notebook, 1, wx.ALL | wx.EXPAND, 5)
        bSizer1.Add( bSizer3, 1, wx.EXPAND, 5 )

        cmd_choice_sizer = wx.BoxSizer(wx.HORIZONTAL)
        self.m_staticText4 = wx.StaticText(self, wx.ID_ANY, _(u"Commands :"), wx.DefaultPosition, wx.DefaultSize, 0)
        self.m_staticText4.Wrap(-1)
        cmd_choice_sizer.Add(self.m_staticText4, 0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 5)

        self.m_choice_OperationMode = wx.Choice(
            self,
            choices=[
                "DAQ Start",
                "DAQ Stop",
                "Realtime Stream Start",
                "Realtime Stream Stop",
                "SD Stream Start",
                "SD Stream Stop",
                "SD Clear All",
            ],
        )
        cmd_choice_sizer.Add(self.m_choice_OperationMode, 0, wx.ALL | wx.CENTER, 5)
        self.m_choice_OperationMode.SetSelection(0)

        self.m_button1 = wx.Button(self, wx.ID_ANY, _(u"Send"), wx.DefaultPosition, wx.DefaultSize, 0)
        cmd_choice_sizer.Add(self.m_button1, 0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 5)

        self.m_textCtrl_cmd = wx.TextCtrl(
            self,
            wx.ID_ANY,
            _(u""),
            wx.DefaultPosition,
            wx.DefaultSize,
            wx.TE_PROCESS_ENTER,
        )
        cmd_choice_sizer.Add(self.m_textCtrl_cmd, 1, wx.ALL | wx.EXPAND, 5)

        bSizer1.Add(cmd_choice_sizer, 0, wx.EXPAND, 5)

        bSizer1.Add(cmd_choice_sizer, 0, wx.EXPAND, 5)


        self.SetSizer( bSizer1 )
        self.Layout()

        
        # MENU
        self.m_statusBar1 = self.CreateStatusBar(1, wx.STB_SIZEGRIP, wx.ID_ANY)
        self.m_menubar = wx.MenuBar(0)
        self.m_menu_file = wx.Menu()
        self.m_menu_file_open = wx.MenuItem(self.m_menu_file, wx.ID_ANY, _(u"&Open"), wx.EmptyString, wx.ITEM_NORMAL)
        self.m_menu_file_save = wx.MenuItem(self.m_menu_file, wx.ID_ANY, _(u"&Save"), wx.EmptyString, wx.ITEM_NORMAL)
        self.m_menu_file_quit = wx.MenuItem(self.m_menu_file, wx.ID_ANY, _(u"&Quit"), wx.EmptyString, wx.ITEM_NORMAL)
        self.m_menu_file.Append(self.m_menu_file_open)
        self.m_menu_file.Append(self.m_menu_file_save)
        self.m_menu_file.AppendSeparator()
        self.m_menu_file.Append(self.m_menu_file_quit)
        self.m_menubar.Append(self.m_menu_file, _(u"&File"))

        self.m_menu_data = wx.Menu()
        self.m_menu_data_export = wx.MenuItem(self.m_menu_data, wx.ID_ANY, _(u"Process &RT Streamed Files"), wx.EmptyString, wx.ITEM_NORMAL)
        self.m_menu_data.Append(self.m_menu_data_export)
        self.m_menu_data_plot_rt = wx.MenuItem(
            self.m_menu_data, wx.ID_ANY, _(u"Plot RT Streamed Data"), wx.EmptyString, wx.ITEM_NORMAL
        )
        self.m_menu_data.Append(self.m_menu_data_plot_rt)
        self.m_menu_data.AppendSeparator()
        self.m_menu_data_merge_sd = wx.MenuItem(
            self.m_menu_data, wx.ID_ANY, _(u"Process SD Streamed Files"), wx.EmptyString, wx.ITEM_NORMAL
        )
        self.m_menu_data.Append(self.m_menu_data_merge_sd)
        self.m_menu_data_plot_sd = wx.MenuItem(
            self.m_menu_data, wx.ID_ANY, _(u"Plot SD Streamed Data"), wx.EmptyString, wx.ITEM_NORMAL
        )
        self.m_menu_data.Append(self.m_menu_data_plot_sd)
        self.m_menu_data_clear = wx.Menu()
        self.m_menu_data_clear_rt = wx.MenuItem(
            self.m_menu_data_clear, wx.ID_ANY, _(u"Clear RT Streamed Files"), wx.EmptyString, wx.ITEM_NORMAL
        )
        self.m_menu_data_clear.Append(self.m_menu_data_clear_rt)
        self.m_menu_data_clear_sd = wx.MenuItem(
            self.m_menu_data_clear, wx.ID_ANY, _(u"Clear SD Streamed Files"), wx.EmptyString, wx.ITEM_NORMAL
        )
        self.m_menu_data_clear.Append(self.m_menu_data_clear_sd)
        self.m_menu_data.AppendSubMenu(self.m_menu_data_clear, _(u"Clear"))
        self.m_menubar.Append(self.m_menu_data, _(u"&Data"))

        self.m_menu_cmd = wx.Menu()
        self.m_menu_cmd_sdclear = wx.MenuItem(self.m_menu_cmd, wx.ID_ANY, _(u"SD &Clear"), wx.EmptyString, wx.ITEM_NORMAL)
        self.m_menu_cmd.Append(self.m_menu_cmd_sdclear)
        self.m_menu_cmd_shutdown = wx.MenuItem(self.m_menu_cmd, wx.ID_ANY, _(u"&Shutdown"), wx.EmptyString, wx.ITEM_NORMAL)
        self.m_menu_cmd.Append(self.m_menu_cmd_shutdown)
        self.m_menubar.Append(self.m_menu_cmd, _(u"&CMD"))


        self.m_menu_view = wx.Menu()
        self.m_menu_view_clf = wx.MenuItem(self.m_menu_view, wx.ID_ANY, _(u"&Clear Figure"), wx.EmptyString, wx.ITEM_NORMAL)
        self.m_menu_view.Append(self.m_menu_view_clf)

        self.m_menu_view_chsel = wx.Menu()
        self.m_menu_view_chsel_x = self.m_menu_view_chsel.AppendCheckItem(wx.ID_ANY, "X")
        self.m_menu_view_chsel_y = self.m_menu_view_chsel.AppendCheckItem(wx.ID_ANY, "Y")
        self.m_menu_view_chsel_z = self.m_menu_view_chsel.AppendCheckItem(wx.ID_ANY, "Z")
        self.m_menu_view_chsel_y.Check(True)
        self.m_menu_view.AppendSubMenu(self.m_menu_view_chsel, "Channel Selection")
        self.Bind(wx.EVT_MENU, self.onChannelToggled, self.m_menu_view_chsel_x)
        self.Bind(wx.EVT_MENU, self.onChannelToggled, self.m_menu_view_chsel_y)
        self.Bind(wx.EVT_MENU, self.onChannelToggled, self.m_menu_view_chsel_z)
        

        self.m_menu_view_timespan = wx.Menu()
        self.m_menu_view_timespan_radio_30s = self.m_menu_view_timespan.AppendRadioItem(wx.ID_ANY, "30 sec")
        self.m_menu_view_timespan_radio_20s = self.m_menu_view_timespan.AppendRadioItem(wx.ID_ANY, "20 sec")
        self.m_menu_view_timespan_radio_10s = self.m_menu_view_timespan.AppendRadioItem(wx.ID_ANY, "10 sec")
        self.m_menu_view_timespan_radio_05s = self.m_menu_view_timespan.AppendRadioItem(wx.ID_ANY, "5 sec")
        self.m_menu_view_timespan_radio_02s = self.m_menu_view_timespan.AppendRadioItem(wx.ID_ANY, "2 sec")
        self.m_menu_view_timespan_radio_30s.Check(True)
        self.m_menu_view.AppendSubMenu(self.m_menu_view_timespan, "Timespan Select")
        self.Bind(wx.EVT_MENU, self.onTimeSpanChange, self.m_menu_view_timespan_radio_30s)
        self.Bind(wx.EVT_MENU, self.onTimeSpanChange, self.m_menu_view_timespan_radio_20s)
        self.Bind(wx.EVT_MENU, self.onTimeSpanChange, self.m_menu_view_timespan_radio_10s)
        self.Bind(wx.EVT_MENU, self.onTimeSpanChange, self.m_menu_view_timespan_radio_05s)
        self.Bind(wx.EVT_MENU, self.onTimeSpanChange, self.m_menu_view_timespan_radio_02s)


        self.m_menubar.Append(self.m_menu_view, _(u"&View"))

        self.m_menu_help = wx.Menu()
        self.m_menu_help_about = wx.MenuItem(self.m_menu_help, wx.ID_ANY, _(u"&Help"), wx.EmptyString, wx.ITEM_NORMAL)
        self.m_menu_help.Append(self.m_menu_help_about)
        self.m_menubar.Append(self.m_menu_help, _(u"&Help"))

        self.SetMenuBar(self.m_menubar) 
        self.Centre( wx.BOTH )
        self.Bind(wx.EVT_CHAR_HOOK, self.on_key_shortcut)

        # FIGURE PANEL

        self.m_fig = Plot(self.m_plot_panel)
        self.axes1 = self.m_fig.figure.add_subplot(2, 1, 1)
        self.axes2 = self.m_fig.figure.add_subplot(2, 1, 2)
        self.m_fig.figure.subplots_adjust(hspace=0.28, bottom=0.08, top=0.95)
        self.plot_updater = PlotUpdater(self)
        self.plot_updater.init_plot()
        self.m_plot_canvas = self.m_fig.canvas
        sizer = wx.BoxSizer(wx.VERTICAL)
        sizer.Add(self.m_fig, 1, wx.EXPAND)
        self.m_plot_panel.SetSizer(sizer)
        self.m_plot_canvas.Bind(wx.EVT_LEFT_DOWN, self._focus_plot_canvas)

        self.m_fig_merged = Plot(self.m_plot_panel_merged)
        self.axes1_merged = self.m_fig_merged.figure.add_subplot(2, 1, 1)
        self.axes2_merged = self.m_fig_merged.figure.add_subplot(2, 1, 2)
        self.m_fig_merged.figure.subplots_adjust(hspace=0.28, bottom=0.08, top=0.95)
        self.merged_plot_updater = MergedPlotUpdater(self)
        self.merged_plot_updater.init_plot()
        self.m_plot_canvas_merged = self.m_fig_merged.canvas
        merged_sizer = wx.BoxSizer(wx.VERTICAL)
        merged_sizer.Add(self.m_fig_merged, 1, wx.EXPAND)
        self.m_plot_panel_merged.SetSizer(merged_sizer)
        self.m_plot_canvas_merged.Bind(wx.EVT_LEFT_DOWN, self._focus_plot_canvas)

        # UPDATE TIMERS

        self._last_plot_version = 0
        self._last_plot_log = 0.0
        self.timer_gui = wx.Timer(self)
        self.Bind(wx.EVT_TIMER, self.gui_update, self.timer_gui)
        self.timer_gui.Start(GUI_TIMER_MS)

        self.timer_pps = wx.Timer(self)
        self.Bind(wx.EVT_TIMER, self.pps_update, self.timer_pps)
        self.timer_pps.Start(PPS_AGE_UPDATE_MS)

        self.timer_speed = wx.Timer(self)
        self.Bind(wx.EVT_TIMER, self.speed_update, self.timer_speed)
        self.timer_speed.Start(1000)

        self.timer_gnss = wx.Timer(self)
        self.Bind(wx.EVT_TIMER, self.map_update, self.timer_gnss)
        self.timer_gnss.Start(1000)

        if hasattr(self, "m_plot_canvas"):
            self.m_plot_canvas.mpl_connect("scroll_event", self.on_mpl_scroll)
            self.m_plot_canvas.mpl_connect("key_press_event", self.on_mpl_key)
            self.m_plot_canvas.Bind(wx.EVT_KEY_DOWN, self._on_plot_key_down)
        if hasattr(self, "m_plot_canvas_merged"):
            self.m_plot_canvas_merged.mpl_connect("scroll_event", self.on_mpl_scroll)
            self.m_plot_canvas_merged.mpl_connect("key_press_event", self.on_mpl_key)
            self.m_plot_canvas_merged.Bind(wx.EVT_KEY_DOWN, self._on_plot_key_down)

        self._plot_modes = {
            self.m_plot_canvas: "zoom",
            self.m_plot_canvas_merged: "zoom",
        }
        self._plot_toolbars = {
            self.m_plot_canvas: self.m_fig.toolbar,
            self.m_plot_canvas_merged: self.m_fig_merged.toolbar,
        }
        self.m_left_notebook.Bind(wx.EVT_NOTEBOOK_PAGE_CHANGED, self.on_tab_changed)


        self.timespan_map = {
            self.m_menu_view_timespan_radio_30s.GetId(): 30,
            self.m_menu_view_timespan_radio_20s.GetId(): 20,
            self.m_menu_view_timespan_radio_10s.GetId(): 10,
            self.m_menu_view_timespan_radio_05s.GetId(): 5,
            self.m_menu_view_timespan_radio_02s.GetId(): 2,
        }

    def mesh_status_data_view(self):
        if self.table_updater is None:
            self.table_updater = TableUpdater(self)
        self.table_updater.setup_table()
        self.m_table = self.table_updater.table
        
    def __del__( self ):
        pass

    def on_key_shortcut(self, event):
        focus = wx.Window.FindFocus()
        if focus in (
            self.m_textCtrl_cmd,
            self.m_textCtrl_acc,
            self.m_textCtrl_tmp,
            self.m_textCtrl_str,
            self.m_textCtrl_veh,
            getattr(self, "m_plot_canvas", None),
            getattr(self, "m_plot_canvas_merged", None),
        ):
            event.Skip()
            return
        if event.HasModifiers():
            event.Skip()
            return
        key = event.GetKeyCode()
        if key in (ord('n'), ord('N')):
            self.m_left_notebook.SetSelection(self.tab_index_nodes)
            return
        if key in (ord('m'), ord('M')):
            self.m_left_notebook.SetSelection(self.tab_index_status)
            return
        if key in (ord('p'), ord('P')):
            self.m_left_notebook.SetSelection(self.tab_index_rt_plots)
            return
        if key in (ord('c'), ord('C')):
            self.m_choice_OperationMode.SetFocus()
            if hasattr(self.m_choice_OperationMode, "Popup"):
                self.m_choice_OperationMode.Popup()
            return
        if ord('1') <= key <= ord('9'):
            idx = key - ord('1')
            if idx < self.m_choice_OperationMode.GetCount():
                self.m_choice_OperationMode.SetSelection(idx)
            return
        event.Skip()


    # Virtual event handlers, override them in your derived class
    def test( self, event ):
        event.Skip()

    # def init_plot(self, parent, id=-1, dpi=None, **kwargs):
    #     wx.Panel.__init__(parent)
    #     self.figure = Figure(dpi=dpi, figsize=(2, 2))
    #     self.canvas = FigureCanvas(self, -1, self.figure)
    #     self.toolbar = NavigationToolbar(self.canvas)
    #     self.toolbar.Realize()

    #     sizer = wx.BoxSizer(wx.VERTICAL)
    #     sizer.Add(self.canvas, 1, wx.EXPAND)
    #     sizer.Add(self.toolbar, 0, wx.LEFT | wx.EXPAND)
    #     self.SetSizer(sizer)

    #     return self.figure

    def getTimeWindow(self, t1):
        if self.model is not None:
            return self.model.get_time_window(t1)
        return []
                
    def init_plot(self):
        if self.plot_updater is None:
            self.plot_updater = PlotUpdater(self)
        self.plot_updater.init_plot()

    def init_merged_plot(self):
        if self.merged_plot_updater is None:
            self.merged_plot_updater = MergedPlotUpdater(self)
        self.merged_plot_updater.init_plot()

    def on_merge_sd_files(self, event):
        if self.model is None:
            return
        self.model.merge_sd_files()

    def on_merge_rt_files(self, event):
        if self.model is None:
            return
        self.model.merge_rt_streamed_files()

    def figure_update_merged(self):
        if self.merged_plot_updater is None:
            return
        self.merged_plot_updater.figure_update()

    def show_merged_plots(self):
        if hasattr(self, "tab_index_merged_plots"):
            self.m_left_notebook.SetSelection(self.tab_index_merged_plots)

    def _focus_plot_canvas(self, event):
        try:
            event.GetEventObject().SetFocus()
        except Exception:
            pass
        event.Skip()

    def on_mpl_scroll(self, event):
        if event is None or event.inaxes is None:
            return
        if self._plot_modes.get(event.canvas, "zoom") != "zoom":
            return
        if event.button == "up":
            scale = 0.9
        elif event.button == "down":
            scale = 1.1
        else:
            return

        axes = event.inaxes
        x0, x1 = axes.get_xlim()
        if event.xdata is None or event.ydata is None:
            return
        cx = event.xdata
        new_x0 = cx - (cx - x0) * scale
        new_x1 = cx + (x1 - cx) * scale
        axes.set_xlim(new_x0, new_x1)
        try:
            axes.figure.canvas.draw_idle()
        except Exception:
            pass

    def _set_plot_mode(self, canvas, mode: str):
        toolbar = self._plot_toolbars.get(canvas)
        if toolbar is None:
            return
        if mode == "pan":
            if toolbar.mode != "pan/zoom":
                toolbar.pan()
        elif mode == "zoom":
            if toolbar.mode == "pan/zoom":
                toolbar.pan()
        self._plot_modes[canvas] = mode

    def _reset_plot_view(self, canvas):
        if canvas is self.m_plot_canvas:
            self.plot_updater.init_plot()
            self.figure_update()
        elif canvas is self.m_plot_canvas_merged:
            self.init_merged_plot()
            self.figure_update_merged()

    def on_mpl_key(self, event):
        if event is None or event.canvas is None:
            return
        key = (event.key or "").lower()
        if key == "p":
            self._set_plot_mode(event.canvas, "pan")
            return
        if key == "z":
            self._set_plot_mode(event.canvas, "zoom")
            return
        if key == "r":
            self._reset_plot_view(event.canvas)
            return

    def _on_plot_key_down(self, event):
        keycode = event.GetKeyCode()
        canvas = event.GetEventObject()
        if keycode in (ord('p'), ord('P')):
            self._set_plot_mode(canvas, "pan")
            return
        if keycode in (ord('z'), ord('Z')):
            self._set_plot_mode(canvas, "zoom")
            return
        if keycode in (ord('r'), ord('R')):
            self._reset_plot_view(canvas)
            return
        event.Skip()

    def on_tab_changed(self, event):
        idx = event.GetSelection()
        if idx == self.tab_index_rt_plots and hasattr(self, "m_plot_canvas"):
            try:
                self.m_plot_canvas.SetFocus()
            except Exception:
                pass
        if idx == self.tab_index_merged_plots and hasattr(self, "m_plot_canvas_merged"):
            try:
                self.m_plot_canvas_merged.SetFocus()
            except Exception:
                pass
        event.Skip()

    def on_map_loaded(self, event):
        self.m_map_loaded = True

    def map_update(self, event):
        if self.m_map is None or not self.m_map_loaded:
            return
        positions = getattr(self.model, "gnss_positions", {})
        if not positions:
            return
        for node_id, pos in positions.items():
            if not pos.get("valid"):
                continue
            lat = pos.get("lat")
            lon = pos.get("lon")
            if lat is None or lon is None:
                continue
            safe_id = str(node_id).replace("'", "\\'")
            self.m_map.RunScript(f"updateMarker('{safe_id}', {lat}, {lon});")

    def _load_map(self):
        if self.m_map is None:
            return
        html = """
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8"/>
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
                integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin=""/>
          <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"
                  integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>
          <style>
            html, body, #map { height: 100%; margin: 0; padding: 0; }
          </style>
        </head>
        <body>
          <div id="map"></div>
          <script>
            const map = L.map('map').setView([0, 0], 16);
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
              maxZoom: 19,
              attribution: '&copy; OpenStreetMap contributors'
            }).addTo(map);
            const markers = {};
            window.updateMarker = function(nodeId, lat, lon) {
              let m = markers[nodeId];
              if (!m) {
                m = L.marker([lat, lon]).addTo(map);
                m.bindTooltip(nodeId, {permanent: true, direction: 'top'});
                markers[nodeId] = m;
              }
              m.setLatLng([lat, lon]);
            };
          </script>
        </body>
        </html>
        """
        self.m_map.SetPage(html, "")
        
    def status_table_update(self):
        if self.table_updater is None:
            return
        self.table_updater.update_status_table()

    def update_pps_age(self):
        if self.table_updater is None:
            return
        self.table_updater.update_pps_age()

    def table_update(self):
        if self.table_updater is None:
            return
        self.table_updater.refresh()

    def figure_update(self):
        if self.plot_updater is None:
            return
        self.plot_updater.figure_update()

    def gui_update(self, event):
        if self.model.gui_dirty:
            self.table_update()
            self.model.gui_dirty = False
        self.update_pps_flash()
        self.update_psd_legend()
        if self.model.plot_dirty_version != self._last_plot_version:
            self.figure_update()
            self._last_plot_version = self.model.plot_dirty_version
            self.model.plot_dirty = False
            # [gui] redraw logging disabled

    def pps_update(self, event):
        self.update_pps_age()

    def speed_update(self, event):
        self.model.update_speed(datetime.datetime.now(datetime.timezone.utc))

    def update_pps_flash(self):
        if self.table_updater is None:
            return
        self.table_updater.update_pps_flash()

    def update_psd_title(self):
        stats = self._psd_stats_text()
        if stats:
            self.axes2.set_title(stats)
            try:
                self.m_fig.figure.canvas.draw_idle()
            except Exception:
                pass

    def _psd_stats_text(self):
        latest = None
        for node_id, psder in self.model.psder.items():
            ts = psder.last_sample_time
            if ts is None:
                continue
            if latest is None or ts > latest[0]:
                latest = (ts, psder)
        if latest is None:
            return ""
        _, psder = latest
        try:
            avg_n = max(psder.n - 1, 0)
            exp_lambda = math.exp(-psder.Lambda)
            return (
                f"λ={psder.Lambda:.4g}, exp(-λ)={exp_lambda:.4f}, avg_n={avg_n}"
            )
        except Exception:
            return ""
        return ""

    def update_psd_legend(self):
        if self.plot_updater is None:
            return
        self.plot_updater.update_psd_legend()


    def onChannelToggled(self, event):

        self.channel_selection = [
            self.m_menu_view_chsel_x.IsChecked(),
            self.m_menu_view_chsel_y.IsChecked(),
            self.m_menu_view_chsel_z.IsChecked()
        ]

        self.init_plot()
        self.figure_update()
        self.init_merged_plot()
        self.figure_update_merged()

    def get_daq_mode_choices(self, model_label: str):
        if self.model is None:
            return []
        return self.model.daq_mode_labels.get(model_label, [])

    def _parse_daq_mode(self, value: str):
        if not value:
            return None
        parts = value.split(":", 1)
        try:
            return int(parts[0].strip())
        except (ValueError, TypeError):
            return None

    def on_daq_mode_change(self, event):
        col = event.GetCol()
        if self.model is None or self.table_updater is None:
            event.Skip()
            return
        daq_col = self.table_updater.col_index.get("DAQ Mode")
        if daq_col is None or col != daq_col:
            event.Skip()
            return
        row = event.GetRow()
        try:
            node_id = self.model.mesh_status_data.iloc[row]['nodeID']
        except Exception:
            event.Skip()
            return
        value = self.m_grid2.GetCellValue(row, col)
        mode = self._parse_daq_mode(value)
        if mode is None:
            event.Skip()
            return
        if hasattr(self.controller, "set_daq_mode"):
            self.controller.set_daq_mode(node_id, mode)
        event.Skip()

    def on_grid_select_cell(self, event):
        if self.table_updater is None:
            event.Skip()
            return
        col = event.GetCol()
        daq_col = self.table_updater.col_index.get("DAQ Mode")
        if daq_col is None or col != daq_col:
            event.Skip()
            return
        row = event.GetRow()
        try:
            model_label = str(self.model.mesh_status_data.iloc[row]['Sensor'] or "")
        except Exception:
            event.Skip()
            return
        choices = self.get_daq_mode_choices(model_label)
        if choices:
            editor = gridlib.GridCellChoiceEditor(choices, allowOthers=False)
            self.m_grid2.SetCellEditor(row, daq_col, editor)
        event.Skip()

    def onTimeSpanChange(self, event):

        ts = self.timespan_map.get(event.GetId(), None)
        if ts:
            logger.info(f"Timespan selected: {ts} sec")
            self.timespan_length = ts
            if self.model is not None:
                self.model.timespan_length = ts
            self.init_plot()
            self.figure_update()
            self.init_merged_plot()
            self.figure_update_merged()

    def append_status_message(self, msg: str) -> None:
        wx.CallAfter(self._append_status_message, msg)

    def _append_status_message(self, msg: str) -> None:
        if hasattr(self, "m_statusBar1") and self.m_statusBar1 is not None:
            self.m_statusBar1.SetStatusText(msg)
        print(msg, flush=True)
        
        
