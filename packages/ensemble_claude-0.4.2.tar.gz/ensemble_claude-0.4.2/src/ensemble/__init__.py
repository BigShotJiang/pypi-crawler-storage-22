"""Ensemble AI Orchestration - Multi-agent orchestration for Claude Code."""

__version__ = "0.4.2"
__author__ = "Ensemble Team"

