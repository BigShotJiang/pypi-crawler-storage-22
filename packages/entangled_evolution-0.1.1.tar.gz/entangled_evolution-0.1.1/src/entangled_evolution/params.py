# entangled_evolution/params.py
from __future__ import annotations

from dataclasses import dataclass,fields
from typing import Any, Literal, Sequence
import numpy as np



# ----------------------------
# Type aliases (semantic)
# ----------------------------

Boundary = Literal["absorbing", "reflecting"]
IntegrationMethod = Literal["euler", "rk4"]

VectorLike = float | Sequence[float] | np.ndarray
MatrixLike = float | np.ndarray

INTEGRATION_METHODS = ("euler", "rk4")
BOUNDARIES = ("absorbing", "reflecting")


from dataclasses import fields, asdict

class ParamsBase:
    """
    Mixin for parameter dataclasses.
    Adds common utility methods.
    """

    def summary(self) -> None:
        cls_name = self.__class__.__name__
        print("\n" + cls_name)
        print("-" * len(cls_name))

        for f in fields(self):
            value = getattr(self, f.name)
            print(f"{f.name:24s}: {value}")

    def to_dict(self) -> dict:
        """
        Return parameters as a plain Python dict.
        Useful for logging, serialization, caching, etc.
        """
        return asdict(self)
    

# ----------------------------
# Simulation parameters
# ----------------------------

@dataclass(frozen=True, kw_only=True)
class SimulationParams(ParamsBase):
    # --- core simulation setup ---
    T: float
    N: int = 2
    dt: float | None = None
    steps: int | None = None
    x0: VectorLike | None = None

    # --- model / noise setup ---
    z0: VectorLike | str = "stationary"
    reproduction_rate: float = 1.0
    noise_timescale: float = 1.0

    mean_fitness: VectorLike = 1.0
    coeff_var_fitness: VectorLike = 1.0

    entanglement: MatrixLike | None = None
    covariance: MatrixLike | None = None
    normalize_mean_fitness: bool = True

    # --- extinction / boundary ---
    boundary: Boundary = "absorbing"
    threshold: float = 0.0
    extinction_events: int | None = None

    # --- recording ---
    record_trajectories: bool = True
    trajectory_save_every: int = 1
    integration_method: IntegrationMethod = "rk4"
    record_events: bool = True
    record_final_state: bool = True
    record_parameters: bool = True

    # --- randomness ---
    seed: int | None = None

    # ----------------------------
    # Validation
    # ----------------------------

    def __post_init__(self) -> None:
        if self.T <= 0:
            raise ValueError("T must be > 0")

        if self.N < 2:
            raise ValueError("N must be >= 2")

        # exactly one of dt or steps
        if (self.dt is None) == (self.steps is None):
            raise ValueError("Provide exactly one of dt or steps")

        if self.dt is not None and self.dt <= 0:
            raise ValueError("dt must be > 0")

        if self.steps is not None and self.steps <= 0:
            raise ValueError("steps must be > 0")

        if self.trajectory_save_every < 1:
            raise ValueError("trajectory_save_every must be >= 1")

        if self.threshold < 0:
            raise ValueError("threshold must be >= 0")

        if self.boundary not in BOUNDARIES:
            raise ValueError(f"boundary must be one of {BOUNDARIES}")

        if self.integration_method not in INTEGRATION_METHODS:
            raise ValueError(
                f"integration_method must be one of {INTEGRATION_METHODS}"
            )

        if self.extinction_events is not None and self.extinction_events < 0:
            raise ValueError("extinction_events must be >= 0 or None")
        
        if self.covariance is not None and self.entanglement is not None:
            raise ValueError("Provide only one of covariance or entanglement.")
        
        if self.seed is not None and not isinstance(self.seed, int):
            raise TypeError("seed must be an integer or None.")


# ----------------------------
# Ensemble parameters
# ----------------------------

from dataclasses import dataclass

@dataclass(frozen=True, kw_only=True)
class StatsParams(ParamsBase):
    fixed: bool = True
    ignore_inf: bool = False


@dataclass(frozen=True, kw_only=True)
class EnsembleParams(ParamsBase):
    samples: int
    seed: int | None = None
    N_trajectories: int | None = None

    # output / bookkeeping
    showprogress: bool = True

    # caching
    caching: bool = True
    cachedir: str = "cache"
    recompute: bool = False

    # analysis
    compute_stats: bool = False

    def __post_init__(self) -> None:
        if self.samples <= 0:
            raise ValueError("samples must be > 0")

        if self.N_trajectories is not None:
            if self.N_trajectories < 0:
                raise ValueError("N_trajectories must be >= 0 or None")
            if self.N_trajectories > self.samples:
                raise ValueError("N_trajectories must be <= samples")

        if not isinstance(self.cachedir, str) or self.cachedir.strip() == "":
            raise ValueError("cachedir must be a non-empty string")
                    
