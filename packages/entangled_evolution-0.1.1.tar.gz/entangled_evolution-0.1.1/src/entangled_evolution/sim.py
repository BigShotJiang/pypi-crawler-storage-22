import math
import os
import pickle
from hashlib import md5
from dataclasses import asdict, replace

import numpy as np
from tqdm import tqdm

from .integration import integrate_step
from .models import fitness_function
from .params import EnsembleParams, SimulationParams, StatsParams
from .stats import compute_stats
from .utils import (
    as_vector,
    mixing,
    simplex_initial_condition,
    stack_trajectories,
    time_grid,
)


def handle_extinction(
    x, alive, extinct, extinction_time, extinction_rank, t, threshold, boundary, extinctions
):
    for i in alive[:]:  # shallow copy to allow safe removal
        if x[i] < threshold:
            if boundary == "absorbing":
                extinctions += 1
                extinct[i] = True
                extinction_rank[i] = extinctions
                alive.remove(i)
                extinction_time[i] = t
                x[i] = 0
            else:
                x[i] = threshold
            x = x / np.sum(x)
    return x, alive, extinct, extinction_time, extinction_rank, extinctions


def simulate(model, params: SimulationParams):
    # Short alias (keeps code readable without lots of params.<field>)
    p = params

    # --- unpack params (grouped, compact) ---
    T, dt, steps, N, x0 = p.T, p.dt, p.steps, p.N, p.x0

    z0 = p.z0
    reproduction_rate, noise_timescale = p.reproduction_rate, p.noise_timescale
    mean_fitness, coeff_var_fitness = p.mean_fitness, p.coeff_var_fitness
    entanglement, covariance = p.entanglement, p.covariance
    normalize_mean_fitness = p.normalize_mean_fitness

    boundary, threshold, extinction_events = p.boundary, p.threshold, p.extinction_events

    record_trajectories = p.record_trajectories
    trajectory_save_every = p.trajectory_save_every
    integration_method = p.integration_method
    record_events, record_final_state, record_parameters = (
        p.record_events,
        p.record_final_state,
        p.record_parameters,
    )

    # --- RNG: seed-only API (single simulation) ---
    rng = np.random.default_rng(p.seed)

    # --- vectorize & normalize fitness params ---
    mean_fitness = as_vector(mean_fitness, N, "mean_fitness")
    coeff_var_fitness = as_vector(coeff_var_fitness, N, "coeff_var_fitness")

    if normalize_mean_fitness:
        mean_fitness = mean_fitness / np.mean(mean_fitness)

    # --- mixing / entanglement ---
    S, covariance, N, M = mixing(N=N, covariance=covariance, mixing_matrix=entanglement)

    # --- time grid ---
    dt, steps, t_full = time_grid(T, dt=dt, steps=steps)

    idx = np.arange(0, steps + 1, trajectory_save_every)
    t_stacked = t_full[idx]
    savedsteps = len(t_stacked) - 1

    # --- initial conditions ---
    x0 = simplex_initial_condition(x0, N=N, name="x0")

    if isinstance(z0, str) and z0 == "stationary":
        z0 = S @ rng.standard_normal(M)  # -> shape (N,)
    else:
        z0 = as_vector(z0, N, "z0")

    # --- record parameters (base = dataclass; add derived/executed values) ---
    parameters = None
    if record_parameters:
        parameters = asdict(params)
        parameters.update(
            {
                "model": model.__name__ if hasattr(model, "__name__") else str(model),
                "dt": dt,
                "steps": steps,
                "savedsteps": savedsteps,
                "N": N,
                "x0": x0,
                "z0": z0,
                "entanglement": S,
                "covariance": covariance,
                "mean_fitness": mean_fitness,
                "coeff_var_fitness": coeff_var_fitness,
                "threshold": threshold,
                "extinctions_enabled": (threshold is not None and threshold > 0),
                "rng_state": rng.bit_generator.state,
            }
        )

    # ---------------- Simulation begins here ----------------

    t = 0.0
    iterations = 0
    x = np.array(x0, copy=True)
    z = np.array(z0, copy=True)

    events = None
    extinctions = 0
    alive = list(range(N))
    extinct = [False] * N
    extinction_time = [math.inf] * N
    extinction_rank = [None] * N

    max_extinctions = (N - 1) if extinction_events is None else extinction_events

    # --- trajectory storage (preallocated) ---
    if record_trajectories:
        max_saved = len(t_stacked)  # upper bound on number of saved points
        tdata = np.empty((max_saved,), dtype=float)
        Xdata = np.empty((max_saved, N), dtype=float)
        Zdata = np.empty((max_saved, N), dtype=float)
        Adata = np.empty((max_saved, N), dtype=float)
        k = 0  # index of last written saved sample

    # initial fitness (use live state z)
    fitness = fitness_function(z, mean_fitness, coeff_var_fitness)

    if record_trajectories:
        Xdata[k] = x
        Zdata[k] = z
        Adata[k] = fitness
        tdata[k] = t

    while (iterations * dt < T and extinctions < max_extinctions):
        x, z = integrate_step(
            model,
            reproduction_rate,
            x,
            z,
            mean_fitness,
            coeff_var_fitness,
            S,
            dt,
            noise_timescale,
            integration_method,
            rng,
        )

        iterations += 1
        t = iterations * dt

        fitness = fitness_function(z, mean_fitness, coeff_var_fitness)

        if threshold > 0:
            x, alive, extinct, extinction_time, extinction_rank, extinctions = handle_extinction(
                x, alive, extinct, extinction_time, extinction_rank, t, threshold, boundary, extinctions
            )

        if record_trajectories and (iterations % trajectory_save_every == 0):
            k += 1
            if k >= max_saved:
                raise RuntimeError(
                    "Trajectory buffer overflow: saving schedule mismatch (k >= max_saved)."
                )
            Xdata[k] = x
            Zdata[k] = z
            Adata[k] = fitness
            tdata[k] = t

    # ---------------- loop ends here ----------------

    final_state = (x.copy(), z.copy())

    if record_events:
        fixation = (extinctions == N - 1)
        events = {
            "fixation": fixation,
            "extinct": extinct,
            "extinction_time": extinction_time,
            "extinction_rank": extinction_rank,
        }

    if record_trajectories:
        X = Xdata[: k + 1]
        Z = Zdata[: k + 1]
        A = Adata[: k + 1]
        t_out = tdata[: k + 1]
    else:
        X = Z = A = t_out = None

    sim = {
        "parameters": parameters,
        "X": X,
        "Z": Z,
        "fitness": A,
        "t": t_out,
        "events": events,
    }

    if record_final_state:
        sim["state"] = final_state

    return sim


def simulate_ensemble(
    model,
    sim: SimulationParams,
    ens: EnsembleParams,
    stats: StatsParams | None = None,
):
    if stats is None:
        stats = StatsParams()

    # IMPORTANT API RULE:
    # - simulate() uses sim.seed (single run reproducibility)
    # - simulate_ensemble() uses ens.seed (ensemble reproducibility)
    # Therefore: when calling simulate_ensemble, sim.seed should be None.
    if sim.seed is not None:
        raise ValueError(
            "When calling simulate_ensemble(...), set sim.seed=None and use ens.seed for reproducibility/caching."
        )

    samples = ens.samples
    N_trajectories = ens.N_trajectories if ens.N_trajectories is not None else samples

    # ---------------- CACHING SETUP ----------------
    # Rule: caching only makes sense for reproducible ensembles.
    # => No ens.seed -> no caching (by design).
    cachefile = None
    cacheable = bool(ens.caching) and (ens.seed is not None)

    if cacheable:
        os.makedirs(ens.cachedir, exist_ok=True)

        # IMPORTANT: recompute is *not* part of the cache key (execution policy)
        ens_dict = asdict(ens)
        ens_dict.pop("recompute", None)

        cache_payload = {
            "model": model.__name__ if hasattr(model, "__name__") else str(model),
            "simulation": asdict(sim),  # sim.seed is None here (enforced)
            "ensemble": ens_dict,       # includes ens.seed
            "stats": asdict(stats),
        }
        cachekey = md5(pickle.dumps(cache_payload)).hexdigest()
        cachefile = os.path.join(ens.cachedir, f"{cachekey}.pickle")

        if os.path.exists(cachefile) and not ens.recompute:
            with open(cachefile, "rb") as f:
                ensemble = pickle.load(f)

            ensemble.setdefault("parameters", {})
            ensemble["parameters"]["cache"] = {
                "enabled": True,
                "hit": True,
                "cachefile": cachefile,
                "cachedir": ens.cachedir,
                "recompute": ens.recompute,
            }
            return ensemble

    # ---------------- PER-SAMPLE SEEDS ----------------
    # If ens.seed is None, spawn seeds from entropy (non-reproducible ensemble).
    master_ss = np.random.SeedSequence(ens.seed) if ens.seed is not None else np.random.SeedSequence()
    child_ss = master_ss.spawn(samples)
    per_sample_seeds = [int(ss.generate_state(1, dtype=np.uint64)[0]) for ss in child_ss]

    # ---------------- ENSEMBLE SIMULATION ----------------

    # Precompute time grid once for stacking
    dt_grid, steps_grid, t_full = time_grid(sim.T, dt=sim.dt, steps=sim.steps)
    idx = np.arange(0, steps_grid + 1, sim.trajectory_save_every)
    t_stacked = t_full[idx]
    savedsteps = len(t_stacked) - 1

    trajectories_list = []
    events = []
    state = []
    stats_dict = {}
    parameters = {}

    it = range(samples)
    if ens.showprogress:
        it = tqdm(it)

    for i in it:
        local_sim = replace(
            sim,
            seed=per_sample_seeds[i],           # seed for THIS realization
            record_parameters=(i == 0),
            record_trajectories=(i < N_trajectories),
        )

        res = simulate(model, local_sim)

        if local_sim.record_parameters:
            parameters = res["parameters"] if res["parameters"] is not None else {}
            parameters["samples"] = samples
            parameters["N_trajectories"] = N_trajectories
            parameters["ensemble_seed"] = ens.seed
            parameters["per_sample_seeds"] = per_sample_seeds
            parameters["savedsteps"] = savedsteps

        if local_sim.record_trajectories:
            trajectories_list.append(
                {
                    "X": res["X"],
                    "Z": res["Z"],
                    "fitness": res["fitness"],
                }
            )

        if local_sim.record_events:
            events.append(res["events"])

        if local_sim.record_final_state:
            state.append(res["state"])

    # ---------------- ALWAYS STACKED OUTPUT ----------------
    if N_trajectories > 0:
        X = stack_trajectories(
            trajectories_list, key="X", pad_with_last=True, target_length=savedsteps + 1
        )
        Z = stack_trajectories(
            trajectories_list, key="Z", pad_with_last=False, target_length=savedsteps + 1
        )
        A = stack_trajectories(
            trajectories_list, key="fitness", pad_with_last=False, target_length=savedsteps + 1
        )
        t_out = t_stacked
    else:
        X = Z = A = t_out = None

    ensemble = {
        "parameters": parameters,
        "X": X,
        "Z": Z,
        "fitness": A,
        "t": t_out,
        "events": events,
        "stats": stats_dict,
        "state": state,
    }

    ensemble["parameters"]["cache"] = {
        "enabled": cacheable,
        "hit": False,
        "cachefile": cachefile if cacheable else None,
        "cachedir": ens.cachedir if cacheable else None,
        "recompute": ens.recompute,
    }

    # ---------------- STATS ----------------
    if ens.compute_stats:
        compute_stats(ensemble, fixed=stats.fixed, ignore_inf=stats.ignore_inf)

    # ---------------- WRITE CACHE ----------------
    if cacheable and cachefile is not None:
        with open(cachefile, "wb") as f:
            pickle.dump(ensemble, f)

    return ensemble