# entari-plugin-chronicle

Entari 聊天记录持久化插件

## 安装

```bash
pip install entari-plugin-chronicle
# or use pdm
pdm add entari-plugin-chronicle
# or use uv
uv add entari-plugin-chronicle
```

## 配置

插件提供以下配置选项：

| 配置项 | 必填 | 默认值 |
| :---: | :---: | :---: |
| record_send | 否 | False |
| to_me_only | 否 | False |

### 示例

在 `entari.yml` 配置文件中启用插件：

```yaml
plugins:
  chronicle:
    record_send: true
```

## 许可证

MIT License
