from arclet.entari import metadata

from .config import Config
from . import listener as listener
from .model import MessageRecord as MessageRecord
from .utils import get_message_records as get_message_records

metadata(
    name="聊天记录",
    author=[{"name": "KomoriDev", "email": "mute231010@gmail.com"}],
    version="0.1.0",
    description="聊天记录持久化",
    readme="README.md",
    config=Config,
)

__all__ = ["MessageRecord", "get_message_records"]
