from arclet.entari import BasicConfModel, plugin_config


class Config(BasicConfModel):
    to_me_only: bool = False
    """是否仅记录提及 Bot 自己的消息"""
    record_send: bool = False
    """是否记录发送的消息"""


config = plugin_config(Config)
