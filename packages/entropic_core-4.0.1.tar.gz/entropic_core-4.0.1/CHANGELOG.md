# Changelog

All notable changes to this project will be documented in this file.

This project aims to follow **Semantic Versioning** (SemVer): `MAJOR.MINOR.PATCH`.

## [Unreleased]

### Fixed
- Align runtime `entropic_core.__version__` with the installed distribution version (previously inconsistent).

### Added
- Deprecation policy document.
- `entropic_core.experimental` namespace for unstable APIs.
- Stable minimal API surface: `protect`, `create_middleware`, `wrap`.

### Changed
- Reduced `entropic_core` top-level exports to a minimal stable surface. Previous convenience exports are deprecated and moved to `entropic_core.experimental.api`.

## [4.0.0] - 2026-01-16

> Note: The `4.0.0` wheel published to PyPI contains internal version strings that still mention `3.0.x`.
> The next patch release should be considered the "hygiene fix" release to make runtime version reporting
> and docs consistent with packaging metadata.
