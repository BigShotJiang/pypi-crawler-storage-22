# Contributing

## Ground Rules
- Be concrete: include versions, minimal repro steps, and expected vs actual behavior.
- No secrets: never paste API keys or customer data in issues or logs.
- Prefer reproducible artifacts: attach `results.json` / `report.html` from demos or eval runs.

## Dev Setup
```bash
python -m venv .venv
python -m pip install -U pip
python -m pip install -e ".[dev]"
```

## Pre-commit (recommended)
```bash
pre-commit install
pre-commit run -a
```

## Run Tests
```bash
pytest
```

## Running the Benchmarks

- Reproducible evals (A/B): see `evals/README.md`
- Groundedness precision/recall: `entropic-groundedness-bench`

## What to Work On
- See `ROADMAP.md`.
- See `TRIAGE.md` for label meanings and priorities.
- See `MAINTENANCE.md` for operational cadence and "definition of done".
- Good first issues: documentation gaps, demo improvements, provider adapters, tests.

## Pull Requests
- Keep PRs focused (one problem).
- Add a small test or a demo run that shows the behavior change.
- Update `CHANGELOG.md` when user-facing behavior changes.
- Follow the PR checklist in `.github/PULL_REQUEST_TEMPLATE.md`.
