# Deprecation Policy (SemVer + Window)

## SemVer Summary
- **PATCH**: bug fixes, docs, performance improvements, *no breaking changes*.
- **MINOR**: new features, new APIs, backwards compatible behavior changes.
- **MAJOR**: breaking changes.

## Deprecation Window
- Deprecated APIs remain available for **at least 2 MINOR releases** (or **90 days**, whichever is longer).
- Deprecations must:
  - Emit `DeprecationWarning` (off by default, but visible in tests/CI).
  - Mention the replacement API.
  - Be listed in `CHANGELOG.md`.

## Stable vs Experimental
- **Stable API**: documented surface in `entropic_core` top-level exports.
  - Changes follow SemVer strictly.
- **Experimental API**: anything under `entropic_core.experimental`.
  - May change in MINOR or PATCH releases.
  - Best-effort compatibility only.

## Stable Surface (Current)
The stable surface is intentionally small (1-3 entrypoints) to avoid SemVer breaks:
- `entropic_core.protect()` / `entropic_core.unprotect()`
- `entropic_core.create_middleware()`
- `entropic_core.wrap(client)`

All other convenience exports that previously lived under `entropic_core` are deprecated
and available via `entropic_core.experimental.api` during the deprecation window.
