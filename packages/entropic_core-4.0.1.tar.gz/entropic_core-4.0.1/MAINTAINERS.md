# Maintainers

This file lists the current maintainers and how to contact them.

## Maintainer Team

- TBD (add GitHub handles here)

## How to Reach Maintainers

- For bugs/features: open a GitHub issue.
- For security: follow `SECURITY.md`.
- For conduct: follow `CODE_OF_CONDUCT.md`.

## Responsibilities

- Keep the stable API surface small and SemVer-safe.
- Ensure CI gates pass before merging.
- Maintain reproducible benchmarks and datasets.
- Publish releases and release notes.

