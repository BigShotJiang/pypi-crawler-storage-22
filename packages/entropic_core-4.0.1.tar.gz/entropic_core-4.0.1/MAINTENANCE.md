# Maintenance Policy (Best Effort)

This file describes how the project is kept healthy over time.

## Cadence

- Weekly: issue triage and PR review queue
- Monthly: patch release if needed (bugfixes, docs, adapter hardening)
- Quarterly: minor release if deprecations are ready (see `DEPRECATION_POLICY.md`)

## Response Targets (Best Effort)

- Issues: initial response within 7 days
- PRs: initial review within 14 days
- Security: see `SECURITY.md`

## "Definition of Done" For Merges

- CI green on default branch (see `.github/workflows/ci.yml`)
- Stable API surface preserved (see `src/entropic_core/api.py` and `src/entropic_core/__init__.py`)
- Tests added/updated for behavior changes
- Docs updated for user-facing changes (`docs/`)
- `CHANGELOG.md` updated for user-visible changes

## Backwards Compatibility Discipline

- Keep the stable API surface small.
- New experiments go under `entropic_core.experimental`.
- Any breaking change requires a minor/major bump and must be called out in `CHANGELOG.md`.

## Artifact Hygiene

Runs and reports are reproducible artifacts and should not be committed:
- `entropic_evals_runs/`
- `entropic_groundedness_runs*/`
- `demos/**/runs/`

## Where To Look

- Roadmap: `ROADMAP.md`
- Triage playbook: `TRIAGE.md`
- Governance: `GOVERNANCE.md`
- Releasing: `RELEASING.md`

