# Roadmap (Public)

This roadmap is intentionally short and "living". The source of truth should be GitHub milestones once the repo is hosted.

## Now / Next / Later

### Now (shipping)
- Keep CI and packaging green on every change.
- Expand reproducible eval coverage and stabilize provider adapters.
- Keep the stable API surface small and SemVer-safe.

### Next (near term)
- Production observability: OTel/Prometheus exporters and trace correlation.
- Stronger benchmarks: more datasets, more asserts, standardized metrics.
- Interventions: contract + idempotency + safety guarantees across modes.

### Later (research / longer bets)
- Multi-agent consensus policies and failure mode dashboards.
- Deeper groundedness verification and larger public benchmarks.
- Enterprise features around compliance and auditability (without weakening OSS core).

## 0. Foundations (P0)
- Reproducible evals with A/B reports (baseline vs entropic).
- Provider adapters hardened (OpenRouter, streaming, tool calling).
- Stable API surface + experimental namespace discipline.

## 1. Reliability Runtime
- Official control loop: observe -> diagnose -> intervene -> evidence.
- Event schema (JSONL / OpenTelemetry) and trace correlation IDs.
- Calibrated metrics (entropy baselines, z-scores) and health score.

## 2. Verifiable Hallucination Reduction
- Groundedness by mode (tools vs no-tools).
- Claim extraction + claim-to-evidence mapping.
- Public benchmark and measured precision/recall.

## 3. Production Observability
- OpenTelemetry exporters + Prometheus metrics.
- Grafana dashboards + sharable static HTML reports.
- "Run reproducibility pack": config + seeds + artifacts + report.

## How This Gets Updated

- Weekly: triage feedback and pull 1-3 items into "Now".
- Monthly: cut a patch release if needed.
- Quarterly: cut a minor release with deprecations handled.

See `TRIAGE.md`, `GOVERNANCE.md`, and `MAINTENANCE.md`.
