# Security Policy

## Reporting a Vulnerability

Please do not open a public issue for security reports.

Preferred channels:
1. GitHub Security Advisories (recommended if this repo is hosted on GitHub).
2. Email: `security@entropic-core.com` (or the address listed in the repo if different).

Include:
- affected versions
- minimal proof-of-concept
- impact and severity assessment
- suggested fix (if you have one)

## Supported Versions

We aim to support:
- the latest released version
- the latest patch of the previous minor (best effort)

If you need longer support windows, open an issue requesting LTS support (this may be an enterprise offering).

## Response Targets (Best Effort)

- Acknowledgement: within 72 hours
- Triage: within 7 days
- Fix ETA: depends on severity and reproducibility

## Security Notes for Contributors

- Never commit API keys, tokens, customer prompts, or tool outputs containing secrets.
- Logs and artifacts should be scrubbed before sharing.

## Supply-Chain Controls

- PyPI publication should use **Trusted Publisher (OIDC)** from GitHub Actions (no static PyPI token).
- Release artifacts should include:
  - wheel + sdist
  - CycloneDX SBOM (`dist/entropic-core.sbom.cdx.json`)
  - `SHA256SUMS`
- Release workflow emits GitHub artifact provenance attestation (SLSA-lite) for distributable files.
- If these controls fail, block release until fixed.
