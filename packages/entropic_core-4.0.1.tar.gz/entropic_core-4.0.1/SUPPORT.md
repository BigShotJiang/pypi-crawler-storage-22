# Support

## Where to Ask Questions

- Documentation: see `docs/README.md`
- Demos/benchmarks: see `demos/` and `evals/README.md`
- Issues (bugs/features): use GitHub Issues with the templates

## What to Include (to get help fast)

- OS + Python version
- `entropic-core` version
- provider + model (OpenRouter/Gemini/etc)
- a minimal repro script
- artifacts when available (`report.html`, `run.json`, `baseline.jsonl`, `entropic.jsonl`)

## What Not to Share

- API keys or tokens
- customer prompts or private data
- proprietary tool outputs

