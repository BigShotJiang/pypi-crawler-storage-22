# Triage and Maintenance

This document is the operational playbook for issues and pull requests.

## Labels (minimum set)

- `bug`: something is broken
- `enhancement`: feature request
- `docs`: documentation change
- `question`: user question / support
- `good first issue`: easy entry point
- `help wanted`: maintainers accept contributions
- `priority:P0`: broken build, security, data loss, or severe regressions
- `priority:P1`: important bug/regression with workaround
- `priority:P2`: normal bug/feature
- `status:needs-repro`: needs a minimal reproducible case
- `status:needs-info`: missing required info (versions, logs, artifacts)
- `status:blocked`: blocked on upstream or external dependency
- `status:ready`: actionable and ready to implement
- `area:*`: component labels (adapters, evals, metrics, interventions, docs, ci)

## Severity Guidance

- P0: security issue, data loss, broken releases, CI red on main, adapter breaks major providers
- P1: major regression, wrong results in eval grading, non-idempotent interventions, severe performance regression
- P2: everything else

## Response Targets (Best Effort)

- New issues: first response within 7 days
- PRs: first review within 14 days
- P0 issues: same day acknowledgement when possible

## Triage Loop (issues)

1. Reproduce (or request repro artifacts).
2. Label (`bug`/`enhancement`/`docs`/`question`) and set `priority` and `area:*`.
3. If missing info, apply `status:needs-info` and request:
   - OS + Python version
   - `entropic-core` version
   - provider + model
   - minimal repro script
   - artifacts when relevant (`report.html`, `run.json`, datasets)
3. If reproducible:
   - add failing test or eval case
   - assign to a milestone (roadmap)
4. If not reproducible after 14 days:
   - close with a clear request for missing info and a link to reopen

## Pull Request Review Checklist

- CI green (unit + regression + extras where relevant)
- Backwards compatibility: stable API surface preserved
- New behavior has tests or a benchmark case
- Docs updated when user-facing behavior changes
- `CHANGELOG.md` updated for user-visible changes

## Maintenance Cadence (best effort)

- Weekly: triage new issues, close stale, label good-first-issues
- Monthly: review roadmap, cut a patch release if needed
- Quarterly: evaluate deprecations, consider minor release
