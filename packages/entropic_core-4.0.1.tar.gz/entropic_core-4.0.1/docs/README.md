# Entropic Core Docs (Manual)

This folder is the "code manual" for Entropic Core: how to use it, what it guarantees, and how to run the reproducible demos.

## Adoption Path

`1 install, 1 command, 1 report`

- Landing: `docs/index.html`
- 5-minute tutorial + expected output + troubleshooting top-10: `docs/getting-started-openrouter.md`

## Start Here

- 5-minute OpenRouter getting started: `docs/getting-started-openrouter.md`
- Why Entropic (positioning + anti-claims): `docs/why-entropic.html`
- Metrics guide (how to read deltas): `docs/metrics.html`
- Whitepaper (auto-generated from runs): `docs/whitepaper.html`
- DIY loop (framework-agnostic): `docs/frameworks/diy-loop.md`
- Framework guides:
  - LangChain: `docs/frameworks/langchain.md`
  - CrewAI: `docs/frameworks/crewai.md`
  - AutoGen: `docs/frameworks/autogen.md`
- Observability (JSONL/OTel/Prometheus): `docs/observability.md`
- Limitations (explicit anti-claims): `docs/limitations.md`
- Glossary (terms used in docs and reports): `docs/glossary.md`

## Stable API Surface

Entropic Core keeps a small stable surface (SemVer-safe):

- `entropic_core.protect(...)` (legacy import-hook mode, or recommended runtime session mode via `mode=...`)
- `entropic_core.unprotect()`
- `entropic_core.create_middleware()`
- `entropic_core.wrap(client, provider=...)`

Everything else is best-effort and may move under `entropic_core.experimental`.
