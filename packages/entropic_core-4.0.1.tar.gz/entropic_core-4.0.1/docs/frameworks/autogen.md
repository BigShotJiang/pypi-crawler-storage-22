# AutoGen Guide

## Option A (recommended): Provider client wrapping

If you can access the underlying OpenAI-compatible client used by AutoGen agents, wrap it:

- `entropic_core.create_middleware()`
- `entropic_core.wrap(client, provider="openrouter")`

This keeps integration on the stable API surface.

## Option B (experimental): AutoGenEntropyPlugin

This repo provides:

- `entropic_core.integrations.autogen_adapter.AutoGenEntropyPlugin`

Notes:
- Uses `EntropyBrain` (not stable surface).
- Useful for quick demos; for production, prefer stable client wrapping where possible.

## Safety notes

- If you use tool calling, ensure tool outputs are fed back as messages with `role=="tool"`.
  Entropic's safe pruning guarantees never remove tool outputs.

