# CrewAI Guide

## Option A (recommended): Provider client wrapping

If your CrewAI stack lets you inject an OpenAI-compatible client, wrap it with:

- `entropic_core.create_middleware()`
- `entropic_core.wrap(client, provider="openrouter")`

See `examples/openrouter_chat.py` for the exact OpenRouter client pattern.

## Option B (experimental): CrewAIEntropyAdapter

This repo ships an adapter:

- `entropic_core.integrations.crewai_adapter.CrewAIEntropyAdapter`

Notes:
- It currently depends on `EntropyBrain` (not stable surface).
- Treat as experimental. Prefer Option A when possible.

## Operational guarantees you get (from middleware)

- Grounding injection is idempotent (no repeated system prompts).
- Context pruning is safe (never drops tool messages/evidence markers).

