# DIY Loop (Framework-Agnostic)

This is the recommended integration style because it stays close to Entropic Core's stable API and avoids framework-specific internals.

## Pattern

1. Create an OpenAI-compatible client (OpenAI or OpenRouter) or an Anthropic client.
2. Create a middleware instance.
3. Wrap the client in-place.
4. Use your normal agent loop.

## Minimal Example (offline)

Run:

```powershell
cd entropic_core_release
python examples/diy_loop_offline.py
```

This example uses a dummy LLM function and shows:
- idempotent prompt injections (no duplicates)
- safe context pruning rules
- a call history record with interventions applied

## Minimal Example (OpenRouter)

Run:

```powershell
cd entropic_core_release
python examples/openrouter_chat.py
```

## What Entropic Actually Does

- Observe: measure signals (entropy/health) and track outcomes.
- Diagnose: detect risk (high entropy, low signal, contradictions).
- Intervene: prompt injection, safe pruning, retries, temperature control.
- Evidence: record what happened (what was injected/pruned, usage, latency, outcomes).

See `INTERVENTIONS.md` for explicit intervention guarantees.

