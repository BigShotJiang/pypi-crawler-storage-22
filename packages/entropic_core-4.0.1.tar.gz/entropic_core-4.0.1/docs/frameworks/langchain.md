# LangChain Guide

Best practice: wrap the underlying provider client (OpenAI/OpenRouter/Anthropic) and then let LangChain use it.

## Option A (recommended): Provider client wrapping

If you call the provider yourself (DIY tool/agent loop) and only use LangChain for prompt tooling, use:

- `entropic_core.create_middleware()`
- `entropic_core.wrap(client, provider="openrouter")`

See `examples/openrouter_chat.py` for the pattern.

## Option B (experimental): Callback style integration

This repo contains a LangChain callback handler:

- `entropic_core.integrations.langchain_adapter.LangChainEntropyHandler`

Notes:
- This integration currently uses `EntropyBrain`, which is not part of the stable API surface.
- Treat it as experimental and pin versions if you use it in production.

## What to validate in production

- Streaming behavior: does LangChain stream through without breaking callbacks?
- Tool-use: tool messages are preserved by safe pruning.
- Rate limits: OpenRouter burst limits should trigger transport retries (no live network in CI).

