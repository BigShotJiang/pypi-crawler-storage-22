# 5-Minute Path: 1 Install, 1 Command, 1 Report

This is the fastest reproducible path for adoption:
- 1 install
- 1 command
- 1 shareable report

## Five-Minute Path

### 1) Install (single command)

```bash
pip install "entropic-core[evals]"
```

### 2) Run (single command, no API key required)

```bash
entropic-killer-demo --provider mock --model mock-v1 --out entropic_dx_runs --max-cases 20 --no-smokes
```

### 3) Open report

Open the generated HTML files:
- `entropic_dx_runs/.../report.html`

## Expected Output (Exact Metrics)

Expected console block for the mock path:

```text
Suite: standard_v2 | provider: mock | model: mock-v1
pass_rate:   0.0% -> 100.0% (+100.0%)
grounded:    0.0% -> 100.0% (+100.0%)
contra:      100.0% -> 100.0% (+0.0%)
refusals:    0.0% -> 0.0% (+0.0%)

Suite: tools_loop_v1 | provider: mock | model: mock-v1
pass_rate:   0.0% -> 100.0% (+100.0%)
grounded:    100.0% -> 100.0% (+0.0%)
contra:      100.0% -> 100.0% (+0.0%)
refusals:    0.0% -> 0.0% (+0.0%)
```

Run-specific timestamp folders will vary, but metric lines should match this output.

## Real Provider Path (OpenRouter + Gemini)

If you want real provider behavior (rate limits, refusals, streaming quirks):

```powershell
$env:OPENROUTER_API_KEY="..."
$env:OPENROUTER_MODEL="google/gemini-2.0-flash-lite"
pip install "entropic-core[openrouter,evals]"
entropic-killer-demo --provider openrouter --model $env:OPENROUTER_MODEL --out entropic_dx_runs
```

Optional OpenRouter headers:

```powershell
$env:OPENROUTER_HTTP_REFERER="https://your-domain.example"
$env:OPENROUTER_APP_TITLE="Entropic Core"
```

## Artifacts You Should See

For each suite run:
- `run.json`
- `baseline.jsonl`
- `entropic.jsonl`
- `summary.csv`
- `report.html`
- `events.jsonl` (when runtime events are enabled by the command)

## Troubleshooting Top-10

1. `entropic-killer-demo: command not found`
Fix: run `python -m pip install -U "entropic-core[evals]"` and reopen shell.

2. `No module named entropic_core`
Fix: same environment mismatch. Check `python -c "import entropic_core; print(entropic_core.__version__)"`.

3. `Missing env var OPENROUTER_API_KEY`
Fix: set `OPENROUTER_API_KEY` or use `--provider mock`.

4. `Missing model` on OpenRouter
Fix: set `OPENROUTER_MODEL` or pass `--model`.

5. Rate limit / 429 from provider
Fix: retry later, lower `--max-cases`, or run `--provider mock` for local demos.

6. SSL/proxy/network errors
Fix: verify corporate proxy settings and TLS interception policies.

7. No `report.html` found
Fix: check `--out` path and ensure the command completed without interruption.

8. Output metrics do not match expected mock values
Fix: use exactly `--provider mock --model mock-v1 --max-cases 20 --no-smokes`.

9. Old run folders make inspection confusing
Fix: use a clean output folder per run, for example `--out entropic_dx_runs_clean`.

10. Windows path quoting problems
Fix: quote arguments with spaces and prefer PowerShell syntax shown above.

## What To Share Internally

Share these three items for each run:
- `report.html`
- `run.json`
- suite + provider + model + commit reference
