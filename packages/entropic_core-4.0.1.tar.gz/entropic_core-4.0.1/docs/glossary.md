# Glossary

## Entropy (Shannon)

In information theory, Shannon entropy measures uncertainty in a distribution. In agent systems, "decision entropy" is a proxy for how diverse or unpredictable choices are.

## Decision entropy

A metric in `EntropyMonitor` derived from the distribution of agent decisions. High values mean choices are spread out (less predictable).

## Dispersion

A metric in `EntropyMonitor` intended to capture how far apart agent states are (divergence). It is a proxy and must be interpreted per workload.

## Communication complexity

A metric in `EntropyMonitor` intended to capture communication volume/complexity. High values can indicate coordination overhead or noise.

## Baseline (per workload)

A rolling window of typical metric values for a specific workload (identified by `workload_id`). Used to compute z-scores and detect anomalies.

## Z-score

How many standard deviations a value is from its baseline mean. Useful for anomaly detection across different scales.

## Health score

A composite score (0..1) computed from range checks and anomaly signals. It is configurable and should be calibrated on your workload.

## Groundedness

A claim is grounded if it is supported by provided evidence. In Entropic, groundedness is measured with deterministic checks when evidence items (E1, E2, ...) are available.

## Claim extraction

Turning a response into a list of checkable claims. Entropic uses deterministic heuristics so it is reproducible and testable.

## Claim-to-evidence mapping

Assigning each claim to the evidence items that support it. This is the basis for measurable precision/recall in a benchmark.

## Hallucination (verifiable definition)

In this project, a hallucination is an unsupported claim (ungrounded), an invented citation, a misattributed citation, or a contradiction that can be detected from evidence.

## Drift

When outputs move away from the intended task/context over time. Often correlated with long runs and context pressure.

## Landauer principle (context)

Landauer's principle relates information erasure to heat dissipation in physical systems. We use it as inspiration for thinking about "information loss" in context management, not as a literal proof of correctness.

