# Limitations (Explicit)

Entropic Core is a reliability/runtime layer. It does not magically make models "true".

## What Entropic Core CAN do (measurable)

- Reduce some verifiable failure modes on controlled tasks (A/B evals).
- Provide evidence: metrics, artifacts, and intervention traces.
- Enforce safe behaviors: retries, grounding instructions, safe pruning rules, idempotent interventions.
- Detect and label "unverifiable" outputs when no evidence exists (benchmark-driven).

## What Entropic Core CANNOT guarantee

- No universal "zero hallucinations". Without evidence or tools, truth is not verifiable.
- No correctness on open-world questions unless you provide tools/data and verify outputs.
- No automatic compliance/security guarantees. You must still handle secrets, PII, and policy requirements.
- No single metric that perfectly maps to "agent health" across all workloads. Baselines must be calibrated.

## Common failure modes (so you design around them)

- Missing evidence: models will sound confident even when unverifiable.
- Provider quirks: rate limits, intermittent 5xx, streaming differences, safety refusals.
- Context pressure: long conversations force pruning or summarization, which can drop details if not pinned.

Mitigations:
- Use the verifiable eval suites (`entropic-evals`).
- Use groundedness benchmarks when you have evidence ids.
- Mark tool outputs and evidence messages so they cannot be pruned.

