# Datasets (Public, Reproducible, Enterprise-Safe)

Entropic Core ships eval datasets that are:
- **Closed-world**: every case includes the evidence needed to answer, so correctness is verifiable.
- **Synthetic**: generated deterministically (no third-party copyrighted text).
- **MIT-licensed**: safe for companies to use in CI and internal benchmarking.

It also supports external, public benchmark suites fetched at runtime with explicit license metadata.

## Suites

- `core_v1`: small sanity suite for core behaviors (grounding, stable API, etc).
- `tools_loop_v1`: tool-use loop with real asserts (calculator + sandbox file).
- `standard_v1`: small-to-medium "standard" suite (hundreds of cases).
- `standard_v2`: large "standard" suite (thousands of cases).
- `squad_v1_external`: public external QA suite (SQuAD v1.1 subset; CC BY-SA 4.0).

List suites:
```bash
entropic-evals --list-suites
```

## Licensing and attribution

See `evals/DATASET_LICENSE.md`.
See `evals/EXTERNAL_BENCHMARKS.md`.

## Methodology

See `evals/METHODOLOGY.md`.
