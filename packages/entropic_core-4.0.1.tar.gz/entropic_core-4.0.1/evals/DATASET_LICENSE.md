# Dataset Licenses

## Synthetic in-repo datasets (MIT)

Datasets under:
- `src/entropic_core/experimental/evals/datasets/`
- `src/entropic_core/experimental/evals/tool_sandbox/` (sandbox fixtures used by datasets)

are licensed under the same MIT license as the library (`LICENSE` at repo root).

## What this means

- You can run these datasets in CI.
- You can use them to compare providers/models.
- You can publish your benchmark results (recommended: include the suite hash + git commit).

## External public datasets

External suites are fetched from upstream sources at runtime and keep the upstream license.

Current external suite:
- `squad_v1_external`: SQuAD v1.1 dev subset, **CC BY-SA 4.0**

See `evals/EXTERNAL_BENCHMARKS.md` for attribution, source URLs, and license links.

## Why synthetic-first by default

We intentionally avoid embedding third-party copyrighted text inside the benchmark. The goal is:
- enterprise-safe redistribution
- deterministic, verifiable grading
- no licensing ambiguity
