# Versioned Results

This folder is updated by the continuous results workflow.

- generated_utc: `2026-02-16T12:10:46.116582+00:00`
- total_entries: `3`
- entries_with_events: `0`

## Latest Entries

| created_utc | suite | provider | model | delta pass | events | target_path |
|---|---|---|---|---:|---|---|
| 2026-02-15T02:47:19.122503+00:00 | tools_loop_v1 | mock | mock-v1 | +100.0% | no | `evals/results/history/20260215T024719.122503_0000__20260215_024718__tools_loop_v1__mock__mock-v1__c14bdfed7c28` |
| 2026-02-15T02:46:15.480625+00:00 | tools_loop_v1 | mock | mock-v1 | +0.0% | no | `evals/results/history/20260215T024615.480625_0000__20260215_024615__tools_loop_v1__mock__mock-v1__c14bdfed7c28` |
| 2026-02-15T02:30:35.584870+00:00 | core_v1 | mock | mock-v1 | +0.0% | no | `evals/results/history/20260215T023035.584870_0000__20260215_023035__core_v1__mock__mock-v1__129f061338f8` |
