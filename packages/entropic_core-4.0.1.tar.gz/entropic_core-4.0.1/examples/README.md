# Examples

Run from `entropic_core_release/`.

## Offline (no API key)

```powershell
python examples/diy_loop_offline.py
```

## OpenRouter (requires OPENROUTER_API_KEY)

```powershell
python examples/openrouter_chat.py
```

