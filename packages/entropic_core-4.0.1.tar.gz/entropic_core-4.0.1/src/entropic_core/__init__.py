"""
Entropic Core

Stable API (SemVer, small surface):
- `protect()` / `unprotect()` : enable/disable zero-config wrapping via import hooks
- `create_middleware()` : construct an LLM middleware instance
- `wrap(client)` : wrap a provider client (OpenAI-compatible / Anthropic) in-place

Everything else is considered experimental:
- `entropic_core.experimental` (modules)
- `entropic_core.experimental.api` (legacy convenience symbols)
"""

from __future__ import annotations

import warnings
from typing import Any

from . import experimental
from .api import create_middleware, protect, unprotect, wrap
from .version import __version__

__all__ = [
    "__version__",
    "protect",
    "unprotect",
    "create_middleware",
    "wrap",
    "experimental",
]

# Deprecated legacy exports (kept for a deprecation window).
_DEPRECATED_REMOVAL_VERSION = "5.0.0"
_DEPRECATED_NAMES = {
    # Brain / config
    "EntropyBrain",
    "create_entropic_brain",
    "Config",
    "Tier",
    # Metrics / ROI
    "BusinessMetrics",
    "BusinessMetricsConfig",
    "ROISummary",
    "create_metrics",
    # Core components
    "EntropyMonitor",
    "EntropyRegulator",
    "EvolutionaryMemory",
    "AgentAdapter",
    # Hallucination detection
    "HallucinationDetector",
    "HallucinationReport",
    "create_detector",
    # Healing / consensus / intervention
    "AutoHealer",
    "AgentState",
    "Checkpoint",
    "create_healer",
    "ConsensusEngine",
    "ConsensusMethod",
    "ConsensusResult",
    "Vote",
    "create_consensus_engine",
    "ActiveInterventionEngine",
    "InterventionBridge",
    "InterventionConfig",
    "InterventionType",
    "create_intervention_engine",
    "wrap_openai_client",
    # Middleware details
    "LLMMiddleware",
    "LLMProvider",
    "MiddlewareConfig",
    "wrap_openai",
    "wrap_anthropic",
    # Discovery helpers
    "AutoDiscovery",
    "get_discovery",
    "get_protection_stats",
    # Dashboard
    "LiveDashboard",
    "DashboardConfig",
    "create_dashboard",
}


def __getattr__(name: str) -> Any:
    if name not in _DEPRECATED_NAMES:
        raise AttributeError(name)

    warnings.warn(
        f"`entropic_core.{name}` is deprecated and will be removed in v{_DEPRECATED_REMOVAL_VERSION}. "
        f"Use `entropic_core.experimental.api.{name}` (experimental) or import from the specific submodule.",
        DeprecationWarning,
        stacklevel=2,
    )
    from .experimental import api as exp_api

    return getattr(exp_api, name)


def __dir__() -> list[str]:
    # Only advertise stable names (plus experimental). Deprecated names are available via __getattr__.
    return sorted(set(__all__))
