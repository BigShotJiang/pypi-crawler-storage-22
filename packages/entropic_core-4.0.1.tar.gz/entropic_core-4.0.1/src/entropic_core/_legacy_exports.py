"""
Legacy top-level exports.

These symbols used to be exported from `entropic_core` directly.
They remain available via `entropic_core.experimental.api` and via
deprecated access through `entropic_core.<name>` during the deprecation window.
"""

from __future__ import annotations

# Main brain
from .brain import EntropyBrain, create_entropic_brain

# Business metrics (ROI tracking)
from .business.metrics import (
    BusinessMetrics,
    BusinessMetricsConfig,
    ROISummary,
    create_metrics,
)

# Config
from .config import Config, Tier

# Active intervention
from .core.active_intervention import (
    ActiveInterventionEngine,
    InterventionBridge,
    InterventionConfig,
    InterventionType,
    create_intervention_engine,
    wrap_openai_client,
)
from .core.agent_adapter import AgentAdapter

# Auto-healing
from .core.auto_healer import AgentState, AutoHealer, Checkpoint, create_healer

# Multi-agent consensus
from .core.consensus_engine import (
    ConsensusEngine,
    ConsensusMethod,
    ConsensusResult,
    Vote,
    create_consensus_engine,
)

# Core modules
from .core.entropy_monitor import EntropyMonitor
from .core.entropy_regulator import EntropyRegulator
from .core.evolutionary_memory import EvolutionaryMemory

# Hallucination detection
from .core.hallucination_detector import (
    HallucinationDetector,
    HallucinationReport,
    create_detector,
)

# Universal LLM middleware
from .core.llm_middleware import (
    LLMMiddleware,
    LLMProvider,
    MiddlewareConfig,
    create_middleware,
    wrap_anthropic,
    wrap_openai,
)

# Auto-discovery (zero-config protection)
from .discovery.auto_discover import (
    AutoDiscovery,
    get_discovery,
    get_protection_stats,
    protect,
    unprotect,
)

# Live dashboard (real-time monitoring)
from .realtime.live_dashboard import DashboardConfig, LiveDashboard, create_dashboard
from .version import __version__

__all__ = [
    # Version
    "__version__",
    # Main brain
    "EntropyBrain",
    "create_entropic_brain",
    # Config
    "Config",
    "Tier",
    # Core modules
    "EntropyMonitor",
    "EntropyRegulator",
    "EvolutionaryMemory",
    "AgentAdapter",
    # Hallucination detection
    "HallucinationDetector",
    "HallucinationReport",
    "create_detector",
    # Auto-healing
    "AutoHealer",
    "AgentState",
    "Checkpoint",
    "create_healer",
    # Multi-agent consensus
    "ConsensusEngine",
    "ConsensusMethod",
    "ConsensusResult",
    "Vote",
    "create_consensus_engine",
    # Active intervention
    "ActiveInterventionEngine",
    "InterventionConfig",
    "InterventionType",
    "InterventionBridge",
    "create_intervention_engine",
    "wrap_openai_client",
    # Universal LLM middleware
    "LLMMiddleware",
    "LLMProvider",
    "MiddlewareConfig",
    "create_middleware",
    "wrap_openai",
    "wrap_anthropic",
    # Auto-discovery
    "AutoDiscovery",
    "protect",
    "unprotect",
    "get_discovery",
    "get_protection_stats",
    # Live dashboard
    "LiveDashboard",
    "DashboardConfig",
    "create_dashboard",
    # Business metrics
    "BusinessMetrics",
    "BusinessMetricsConfig",
    "ROISummary",
    "create_metrics",
]
