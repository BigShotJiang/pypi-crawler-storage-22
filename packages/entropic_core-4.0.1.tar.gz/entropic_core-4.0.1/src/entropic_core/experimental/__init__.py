"""
Experimental (unstable) APIs.

Anything under `entropic_core.experimental` may change in MINOR or PATCH releases.
Prefer stable top-level exports from `entropic_core` when building production systems.
"""

from __future__ import annotations

import importlib
from typing import Any

_MODULES = {
    # Convenience re-exports of legacy symbols (see entropic_core.__getattr__ deprecations).
    "api": "entropic_core.experimental.api",
    # Reproducible benchmarks/evals (dataset + runner + reports).
    "evals": "entropic_core.experimental.evals",
    # Higher-level / evolving areas
    "advanced": "entropic_core.advanced",
    "enterprise": "entropic_core.enterprise",
    "plugins": "entropic_core.plugins",
    "optimization": "entropic_core.optimization",
    "conversion": "entropic_core.conversion",
    "messaging": "entropic_core.messaging",
    "integrations": "entropic_core.integrations",
    "discovery": "entropic_core.discovery",
    "diagnosis": "entropic_core.diagnosis",
    "telemetry": "entropic_core.telemetry",
    "observability": "entropic_core.experimental.observability",
    "visualization": "entropic_core.visualization",
    "streaming": "entropic_core.streaming",
}

__all__ = sorted(_MODULES.keys())


def __getattr__(name: str) -> Any:
    target = _MODULES.get(name)
    if not target:
        raise AttributeError(name)
    return importlib.import_module(target)
