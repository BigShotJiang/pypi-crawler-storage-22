"""
Experimental convenience API.

This module re-exports legacy top-level symbols that used to live directly under
`entropic_core`. They are intentionally marked experimental to keep the stable
surface small and SemVer-safe.
"""

from __future__ import annotations

from .. import _legacy_exports as _legacy
from .._legacy_exports import *  # noqa: F401,F403

__all__ = list(_legacy.__all__)
