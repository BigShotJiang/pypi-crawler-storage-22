"""
Reproducible evals and benchmarks (experimental).

Entry point:
- `entropic-evals` (console script)
- `python -m entropic_core.experimental.evals.cli ...`
"""

from __future__ import annotations

__all__ = []
