"""Verifiable groundedness / hallucination detection (experimental).

This module provides deterministic, offline-verifiable analysis:
- Claim extraction from a response
- Claim-to-evidence mapping against provided evidence items
- A taxonomy of failure modes (ungrounded, invented citation, misattributed, etc.)

Everything here is experimental and may change without notice.
"""

from .verifier import (
    Claim,
    ClaimAssessment,
    EvidenceItem,
    FailureType,
    GroundednessConfig,
    GroundednessReport,
    GroundednessSummary,
    analyze_groundedness,
)

__all__ = [
    "EvidenceItem",
    "GroundednessConfig",
    "GroundednessReport",
    "GroundednessSummary",
    "Claim",
    "ClaimAssessment",
    "FailureType",
    "analyze_groundedness",
]
