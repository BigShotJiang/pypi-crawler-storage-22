"""
Experimental observability helpers.

These sinks consume structured RuntimeEvents emitted by LLMMiddleware and export them to:
- OpenTelemetry (traces)
- Prometheus (metrics)

This module is optional. Install extras:
- pip install "entropic-core[otel,prometheus]"
"""

from __future__ import annotations

from .otel import OpenTelemetryEventSink
from .prometheus import PrometheusEventSink

__all__ = ["OpenTelemetryEventSink", "PrometheusEventSink"]
