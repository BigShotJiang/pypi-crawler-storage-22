"""
Experimental reporting utilities (HTML/JSON summaries).

This namespace is not part of the stable API surface.
"""

from __future__ import annotations

__all__ = []
