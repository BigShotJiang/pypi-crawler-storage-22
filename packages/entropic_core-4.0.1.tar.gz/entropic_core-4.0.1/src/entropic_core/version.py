from __future__ import annotations

from importlib import metadata


def get_version() -> str:
    """
    Return the installed distribution version.

    Rationale:
    - Keeps runtime version aligned with PyPI metadata.
    - Avoids hard-coded strings drifting from packaging config.
    """
    try:
        return metadata.version("entropic-core")
    except metadata.PackageNotFoundError:
        # Fallback for editable/unpackaged environments.
        return "0.0.0+unknown"


__version__ = get_version()
