from __future__ import annotations

from entropic_core.core.auto_healer import AutoHealer


def test_checkpoint_and_rollback_snapshot() -> None:
    h = AutoHealer()
    ck1 = h.checkpoint("a1", {"x": 1, "nested": {"y": 2}}, entropy=0.1)
    _ck2 = h.checkpoint("a1", {"x": 2}, entropy=0.2)
    assert _ck2  # keep side effects explicit

    # Latest snapshot by default.
    snap = h.rollback_snapshot("a1")
    assert snap == {"x": 2}

    # Specific checkpoint id.
    snap1 = h.rollback_snapshot("a1", ck1)
    assert snap1 == {"x": 1, "nested": {"y": 2}}

    # Deep copy guarantee.
    snap1["nested"]["y"] = 999
    snap1b = h.rollback_snapshot("a1", ck1)
    assert snap1b["nested"]["y"] == 2

    # Boolean rollback uses snapshot existence.
    assert h.rollback("a1") is True
    assert h.rollback("missing") is False
