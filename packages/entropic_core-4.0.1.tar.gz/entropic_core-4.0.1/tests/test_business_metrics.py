from __future__ import annotations

from entropic_core.business.metrics import BusinessMetrics, BusinessMetricsConfig


def test_track_tokens_legacy_signature_count_model_saved() -> None:
    bm = BusinessMetrics(BusinessMetricsConfig(default_model="gpt-4o-mini"))
    bm.track_tokens(100, "gpt-4o-mini", False)
    bm.track_tokens(25, "gpt-4o-mini", True)
    stats = bm.get_stats()
    assert stats["total_tokens"] >= 100  # saved tokens are tracked separately
    assert stats["total_saved"] > 0.0


def test_track_tokens_new_signature_model_in_out() -> None:
    bm = BusinessMetrics()
    bm.track_tokens("gpt-4o-mini", 10, 5)
    report = bm.generate_roi_report()
    assert report["total_tokens"] == 15
    assert report["total_cost"] > 0.0


def test_track_intervention_does_not_crash_and_increments() -> None:
    bm = BusinessMetrics()
    bm.track_intervention("retry")
    assert bm.get_stats()["interventions"] >= 1
