from __future__ import annotations

from entropic_core.core.consensus_engine import ConsensusEngine, ConsensusMethod


def test_consensus_for_text_outputs_is_deterministic_and_entropy_weighted() -> None:
    eng = ConsensusEngine()
    outputs = {"a": "X", "b": "Y", "c": "Y"}
    confidences = {"a": 0.9, "b": 0.6, "c": 0.6}
    entropies = {"a": 0.1, "b": 0.9, "c": 0.9}

    r1 = eng.consensus_for_text_outputs(
        outputs,
        confidences=confidences,
        entropies=entropies,
        method=ConsensusMethod.ENTROPY_WEIGHTED,
    )
    r2 = eng.consensus_for_text_outputs(
        outputs,
        confidences=confidences,
        entropies=entropies,
        method=ConsensusMethod.ENTROPY_WEIGHTED,
    )
    assert r1["idempotency_key"] == r2["idempotency_key"]
    assert r1["winner_text"] == r2["winner_text"]

    # Agent 'a' has low entropy + high confidence, so X can win even against two high-entropy votes for Y.
    assert r1["winner_text"] in {"X", "Y"}
