from __future__ import annotations

from dataclasses import dataclass

import pytest

from entropic_core.core.entropy_regulator import EntropyRegulator


@dataclass
class Agent:
    exploration_rate: float = 0.2
    validation_threshold: float = 0.5
    creativity_factor: float = 0.0
    learning_rate: float = 1.0


def test_regulator_actions() -> None:
    r = EntropyRegulator()
    agents = [Agent(), Agent()]

    hi = r.regulate(0.95, agents)
    assert hi["action"] == "REDUCE_CHAOS"
    assert hi["severity"] == "high"
    assert hi["entropy_value"] == pytest.approx(0.95)
    assert hi["agent_count"] == 2

    lo = r.regulate(0.05, agents)
    assert lo["action"] == "INCREASE_CHAOS"
    assert lo["severity"] == "high"

    mid = r.regulate(0.5, agents)
    assert mid["action"] == "MAINTAIN"
    assert mid["severity"] == "low"


def test_apply_regulation_mutates_agent_fields() -> None:
    r = EntropyRegulator()
    agents = [Agent(), Agent()]

    reg = r.regulate(0.95, agents)
    r.apply_regulation(agents, reg)
    assert all(a.exploration_rate == pytest.approx(0.1) for a in agents)
    assert all(a.validation_threshold == pytest.approx(0.9) for a in agents)

    reg = r.regulate(0.05, agents)
    r.apply_regulation(agents, reg)
    assert all(a.exploration_rate == pytest.approx(0.5) for a in agents)
    assert all(a.creativity_factor == pytest.approx(0.3) for a in agents)

    before = [a.learning_rate for a in agents]
    reg = r.regulate(0.5, agents)
    r.apply_regulation(agents, reg)
    assert all(a.learning_rate > b for a, b in zip(agents, before))
