from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict

import pytest

from entropic_core.experimental.evals import cli, external


def _fake_squad_payload() -> Dict[str, Any]:
    return {
        "version": "1.1",
        "data": [
            {
                "title": "Test",
                "paragraphs": [
                    {
                        "context": (
                            "Paris is the capital of France and one of the largest cities in Europe. "
                            "It is known for the Eiffel Tower."
                        ),
                        "qas": [
                            {
                                "id": "q1",
                                "question": "What is the capital of France?",
                                "answers": [
                                    {"text": "Paris", "answer_start": 0},
                                    {"text": "Paris", "answer_start": 0},
                                ],
                            }
                        ],
                    }
                ],
            }
        ],
    }


def test_external_builder_writes_license_and_checks(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr(external, "_fetch_json", lambda urls, timeout_s=30: _fake_squad_payload())
    out = tmp_path / "squad_v1_external.jsonl"
    external.build_squad_v1_external(out_path=out, sample_size=10, seed=1)

    rows = [json.loads(x) for x in out.read_text(encoding="utf-8").splitlines() if x.strip()]
    assert rows
    meta = rows[0]
    assert meta["type"] == "meta"
    assert meta["license"] == external.SQUAD_V1_LICENSE
    assert meta["license_url"] == external.SQUAD_V1_LICENSE_URL
    assert "source_urls" in meta and meta["source_urls"]

    case = rows[1]
    checks = case["checks"]
    types = {c["type"] for c in checks}
    assert "answer_any_of_normalized" in types
    assert "claim_groundedness" in types


def test_list_suites_includes_external(capsys: pytest.CaptureFixture[str]) -> None:
    rc = cli.main(["--list-suites"])
    assert rc == 0
    out = capsys.readouterr().out
    assert "squad_v1_external" in out
