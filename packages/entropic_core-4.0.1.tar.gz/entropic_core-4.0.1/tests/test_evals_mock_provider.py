from __future__ import annotations

import json
from pathlib import Path

from entropic_core.experimental.evals import cli


def test_evals_mock_provider_ab_improves_pass_rate(tmp_path: Path) -> None:
    out = tmp_path / "runs"
    rc = cli.main(["--provider", "mock", "--suite", "core_v1", "--out", str(out)])
    assert rc == 0

    # Find the newest run.json under out/core_v1/*
    run_files = list(out.glob("core_v1/mock*/**/run.json"))
    assert run_files, "expected run.json artifacts"
    run_path = sorted(run_files, key=lambda p: p.stat().st_mtime)[-1]
    payload = json.loads(run_path.read_text(encoding="utf-8"))
    assert payload["provider"] == "mock"

    base = payload["summary"]["baseline"]["pass_rate"]
    ent = payload["summary"]["entropic"]["pass_rate"]
    assert ent >= base


def test_evals_standard_suite_runs_offline(tmp_path: Path) -> None:
    out = tmp_path / "runs"
    rc = cli.main(
        ["--provider", "mock", "--suite", "standard_v1", "--out", str(out), "--max-cases", "10"]
    )
    assert rc == 0


def test_evals_run_includes_claim_evidence_mapping(tmp_path: Path) -> None:
    out = tmp_path / "runs"
    rc = cli.main(
        [
            "--provider",
            "mock",
            "--suite",
            "core_v1",
            "--out",
            str(out),
            "--max-cases",
            "2",
        ]
    )
    assert rc == 0

    run_files = list(out.glob("core_v1/mock*/**/run.json"))
    assert run_files, "expected run.json artifacts"
    run_path = sorted(run_files, key=lambda p: p.stat().st_mtime)[-1]
    payload = json.loads(run_path.read_text(encoding="utf-8"))

    baseline_rows = payload["results"]["baseline"]
    assert baseline_rows
    first = baseline_rows[0]
    assert isinstance(first.get("groundedness_summary"), dict)
    assert isinstance(first.get("groundedness_claims"), list)
