from __future__ import annotations

from entropic_core.experimental.groundedness import EvidenceItem, FailureType, analyze_groundedness


def test_supported_and_ungrounded_detection() -> None:
    ev = [EvidenceItem("E1", "Alpha is 3."), EvidenceItem("E2", "Beta is 5.")]
    rep = analyze_groundedness("Alpha is 3. Gamma is 9.", ev)

    assert rep.summary.total_claims >= 2
    assert rep.summary.supported_claims >= 1
    assert rep.summary.unsupported_claims >= 1

    # At least one claim should be marked ungrounded.
    assert any(FailureType.UNGROUNDED in a.failure_types for a in rep.assessments)


def test_invented_citation_and_numeric_mismatch() -> None:
    ev = [EvidenceItem("E1", "Alpha is 3.")]
    rep = analyze_groundedness("Alpha is 4 [E1]. Gamma is 9 [E99].", ev)

    assert rep.summary.citation_invented >= 1
    assert rep.summary.numeric_mismatch >= 1

    # The invented citation should appear as a failure type on at least one claim.
    assert any(FailureType.CITATION_INVENTED in a.failure_types for a in rep.assessments)
    assert any(FailureType.NUMERIC_MISMATCH in a.failure_types for a in rep.assessments)
