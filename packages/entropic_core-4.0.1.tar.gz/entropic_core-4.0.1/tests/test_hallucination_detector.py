from __future__ import annotations

from entropic_core.core.hallucination_detector import HallucinationDetector


def test_detect_wrapper_shape() -> None:
    d = HallucinationDetector()
    out = d.detect("Hello world", context=["Some context"])
    assert set(out.keys()) >= {
        "is_hallucination",
        "confidence",
        "score",
        "reason",
        "evidence",
        "details",
    }
    assert isinstance(out["details"], dict)


def test_self_contradiction_and_overconfidence_flags() -> None:
    d = HallucinationDetector()
    # Force stricter threshold
    d.update_entropy(0.95)

    text = (
        "Alpha is 3 and this is definitely true. "
        "Alpha is not 3 and this is definitely true. "
        "The value is 100% confirmed."
    )
    out = d.detect(text, context=["We are discussing Alpha."])
    assert out["reason"] in {
        "self_contradiction",
        "fact_inconsistency",
        "fabricated_facts",
        "context_drift",
        "none",
    }
    assert out["reason"] == "self_contradiction"
    assert out["is_hallucination"] is True
    assert out["confidence"] >= 0.4
