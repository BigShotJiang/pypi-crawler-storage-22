from __future__ import annotations

import pytest


@pytest.mark.extras
def test_prometheus_sink_import_and_emit() -> None:
    from entropic_core.core.runtime_events import RuntimeEvent
    from entropic_core.experimental.observability import PrometheusEventSink

    sink = PrometheusEventSink(include_model_label=False)
    sink.emit(
        RuntimeEvent(
            type="request",
            run_id="r1",
            request_id="q1",
            provider="openrouter",
            model="m",
            payload={"entropy_before": 0.4, "messages_count": 2},
        )
    )
    sink.emit(
        RuntimeEvent(
            type="response",
            run_id="r1",
            request_id="q1",
            provider="openrouter",
            model="m",
            payload={
                "latency_ms": 12.0,
                "entropy_after": 0.3,
                "usage": {"prompt_tokens": 1, "completion_tokens": 2, "total_tokens": 3},
                "interventions": ["GROUNDING_INJECTION"],
            },
        )
    )


@pytest.mark.extras
def test_otel_sink_import_and_emit() -> None:
    from entropic_core.core.runtime_events import RuntimeEvent
    from entropic_core.experimental.observability import OpenTelemetryEventSink

    sink = OpenTelemetryEventSink(service_name="entropic-core-test")
    sink.emit(
        RuntimeEvent(
            type="request",
            run_id="r1",
            request_id="q1",
            provider="openrouter",
            model="m",
            payload={"entropy_before": 0.4, "messages_count": 2},
        )
    )
    sink.emit(
        RuntimeEvent(
            type="response",
            run_id="r1",
            request_id="q1",
            provider="openrouter",
            model="m",
            payload={
                "latency_ms": 12.0,
                "entropy_after": 0.3,
                "usage": {"prompt_tokens": 1, "completion_tokens": 2, "total_tokens": 3},
                "interventions": ["GROUNDING_INJECTION"],
            },
        )
    )
    sink.shutdown()
