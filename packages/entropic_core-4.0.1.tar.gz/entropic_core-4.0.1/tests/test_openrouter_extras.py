from __future__ import annotations

import pytest


@pytest.mark.extras
def test_openai_client_constructible_for_openrouter() -> None:
    # This is the minimum "provider" check we need: the OpenAI-compatible client
    # can be constructed with a custom base_url (OpenRouter) without network I/O.
    openai = pytest.importorskip("openai")
    assert openai is not None

    from openai import OpenAI

    client = OpenAI(api_key="test", base_url="https://openrouter.ai/api/v1")
    assert client is not None
