from __future__ import annotations

from types import SimpleNamespace

from entropic_core.core.active_intervention import wrap_openai_client
from entropic_core.core.llm_middleware import LLMMiddleware, MiddlewareConfig, wrap_openai


def test_wrap_openai_patches_client_method() -> None:
    calls = {"n": 0}

    def create(*args, **kwargs):
        calls["n"] += 1
        return SimpleNamespace(choices=[SimpleNamespace(message=SimpleNamespace(content="ok"))])

    client = SimpleNamespace(chat=SimpleNamespace(completions=SimpleNamespace(create=create)))
    wrap_openai(client, middleware=LLMMiddleware(MiddlewareConfig(enable_retry_logic=False)))

    out = client.chat.completions.create(model="x", messages=[{"role": "user", "content": "hi"}])
    assert calls["n"] == 1
    assert getattr(out.choices[0].message, "content") == "ok"


def test_wrap_openai_client_is_noop_for_now() -> None:
    obj = object()
    assert wrap_openai_client(obj) is obj
