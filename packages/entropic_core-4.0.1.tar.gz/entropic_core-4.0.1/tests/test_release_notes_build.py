from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]


def test_build_release_notes_includes_precision_recall(tmp_path: Path) -> None:
    root = tmp_path / "groundedness_runs" / "groundedness_v1" / "20260216_000000"
    root.mkdir(parents=True, exist_ok=True)
    report = {
        "suite": {"suite": "groundedness_v1", "version": "1.0.0"},
        "dataset_sha256": "abc123",
        "metrics": {
            "precision_supported": 0.8,
            "recall_supported": 0.9,
            "f1_supported": 0.85,
            "extraction_recall": 1.0,
            "evidence_hit_rate": 0.95,
        },
    }
    (root / "report.json").write_text(json.dumps(report), encoding="utf-8")

    out = tmp_path / "release-notes.md"
    subprocess.run(
        [
            sys.executable,
            str(REPO_ROOT / "tools" / "build_release_notes.py"),
            "--version",
            "vtest",
            "--groundedness-root",
            str(tmp_path / "groundedness_runs"),
            "--out",
            str(out),
        ],
        check=True,
        cwd=str(REPO_ROOT),
    )
    text = out.read_text(encoding="utf-8")
    assert "precision_supported" in text
    assert "recall_supported" in text
