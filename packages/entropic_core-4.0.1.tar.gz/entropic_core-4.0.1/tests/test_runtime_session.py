from __future__ import annotations

import json
from pathlib import Path

import entropic_core


def test_protect_runtime_creates_run_dir_and_report(tmp_path: Path) -> None:
    sess = entropic_core.protect(
        mode="balanced",
        provider="openrouter",
        model="dummy-model",
        run_dir=str(tmp_path),
        atexit_report=False,
        auto_report=True,
    )
    # Session object (context manager)
    assert hasattr(sess, "run_dir")
    assert Path(sess.run_dir).exists()

    eff = Path(sess.run_dir) / "effective_config.json"
    assert eff.exists()
    obj = json.loads(eff.read_text(encoding="utf-8"))
    assert obj["mode"] == "balanced"

    # No calls were made, but report generation should still succeed.
    sess.close()
    rp = Path(sess.run_dir) / "runtime_report.html"
    assert rp.exists()


def test_runtime_event_schema_version(tmp_path: Path) -> None:
    from entropic_core.core.runtime_events import JsonlEventSink, RuntimeEvent

    p = tmp_path / "events.jsonl"
    sink = JsonlEventSink(p)
    sink.emit(RuntimeEvent(type="request", run_id="r1", request_id="q1"))
    lines = p.read_text(encoding="utf-8").splitlines()
    assert lines
    ev = json.loads(lines[0])
    assert ev["schema_version"]
    assert ev["type"] == "request"
