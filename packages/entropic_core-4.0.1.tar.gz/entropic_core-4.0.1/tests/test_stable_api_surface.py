from __future__ import annotations

import pytest


def test_stable_surface_is_small() -> None:
    import entropic_core

    stable = set(entropic_core.__all__)
    assert stable == {
        "__version__",
        "protect",
        "unprotect",
        "create_middleware",
        "wrap",
        "experimental",
    }


def test_legacy_exports_available_but_deprecated() -> None:
    import entropic_core

    with pytest.warns(DeprecationWarning):
        EntropyMonitor = entropic_core.EntropyMonitor

    from entropic_core.core.entropy_monitor import EntropyMonitor as Real

    assert EntropyMonitor is Real


def test_experimental_api_reexports_legacy_symbols() -> None:
    from entropic_core.core.entropy_monitor import EntropyMonitor as Real
    from entropic_core.experimental.api import EntropyMonitor

    assert EntropyMonitor is Real
