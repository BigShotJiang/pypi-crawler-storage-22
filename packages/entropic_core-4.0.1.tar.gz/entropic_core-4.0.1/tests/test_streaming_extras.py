from __future__ import annotations

import pytest


@pytest.mark.extras
def test_event_emitter_basic() -> None:
    from entropic_core.streaming.event_emitter import EventEmitter

    seen = []
    ee = EventEmitter()
    ee.on("x", lambda d: seen.append(("x", d)))
    ee.on("*", lambda d: seen.append(("*", d)))
    ee.emit("x", {"a": 1})

    assert ("x", {"a": 1}) in seen
    assert ("*", {"a": 1}) in seen


@pytest.mark.extras
def test_websocket_server_availability_flag_matches_install() -> None:
    # In the CI "extras" job we install entropic-core[streaming], so websockets should be available.
    websockets = pytest.importorskip("websockets")
    assert websockets is not None

    from entropic_core.streaming.websocket_server import WEBSOCKETS_AVAILABLE

    assert WEBSOCKETS_AVAILABLE is True
