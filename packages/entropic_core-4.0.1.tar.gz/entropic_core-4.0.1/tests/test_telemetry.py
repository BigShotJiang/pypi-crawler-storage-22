from __future__ import annotations

from pathlib import Path

from entropic_core.telemetry.collector import TelemetryCollector
from entropic_core.telemetry.reporter import TelemetryReporter


def test_telemetry_local_buffer_and_reporter(tmp_path: Path) -> None:
    data_dir = tmp_path / "telemetry"
    config_path = tmp_path / "config.json"
    install_id_path = tmp_path / "installation_id"

    c = TelemetryCollector(
        enabled=True,
        data_path=data_dir,
        config_path=config_path,
        installation_id_path=install_id_path,
    )
    c.track_event("quickstart_run", {"agent_count": 2, "python_version": "3.12"})

    events = c.get_events(days=7)
    assert len(events) >= 1
    assert events[-1]["event_type"] == "quickstart_run"

    r = TelemetryReporter(c)
    summary = r.generate_summary(days=7)
    assert summary["total_events"] >= 1
    assert "events_by_type" in summary
