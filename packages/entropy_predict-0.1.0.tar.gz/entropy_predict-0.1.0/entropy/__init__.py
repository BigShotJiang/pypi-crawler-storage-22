"""Entropy: Simulate how populations respond to scenarios."""

__version__ = "0.1.0"
