"""Core CLI app definition and global state."""

from typing import Annotated

import typer
from rich.console import Console

app = typer.Typer(
    name="entropy",
    help="Generate population specs for agent-based simulation.",
    no_args_is_help=True,
)

console = Console()

# Global state for JSON mode (set by callback)
_json_mode = False


def get_json_mode() -> bool:
    """Get current JSON mode state."""
    return _json_mode


def _version_callback(value: bool) -> None:
    if value:
        from .. import __version__

        print(f"entropy {__version__}")
        raise typer.Exit()


@app.callback()
def main_callback(
    json_output: Annotated[
        bool,
        typer.Option(
            "--json",
            help="Output machine-readable JSON instead of human-friendly text",
            is_eager=True,
        ),
    ] = False,
    version: Annotated[
        bool,
        typer.Option(
            "--version",
            help="Show version and exit",
            callback=_version_callback,
            is_eager=True,
        ),
    ] = False,
):
    """Entropy: Population simulation engine for agent-based modeling.

    Use --json for machine-readable output suitable for scripting and AI tools.
    """
    global _json_mode
    _json_mode = json_output


# Import commands to register them with the app
from .commands import (  # noqa: E402, F401
    validate,
    extend,
    spec,
    sample,
    network,
    persona,
    scenario,
    simulate,
    estimate,
    results,
    config_cmd,
)
