"""Main simulation engine orchestrator.

Coordinates the simulation loop: exposure, reasoning, propagation,
and aggregation across timesteps until stopping conditions are met.

Implements Phase 0 redesign:
- Two-pass reasoning (Pass 1: role-play, Pass 2: classification)
- Conviction-gated sharing (very_uncertain agents don't share)
- Conviction-based flip resistance
- Memory traces (sliding window of 3 per agent)
- Semantic peer influence (public_statement + sentiment, not position labels)
- Rate limiter integration (replaces hardcoded semaphore)
"""

import json
import logging
import random
import time
from datetime import datetime
from pathlib import Path
from typing import Any

from ..core.models import (
    PopulationSpec,
    ScenarioSpec,
    AgentState,
    ConvictionLevel,
    CONVICTION_MAP,
    MemoryEntry,
    PeerOpinion,
    ReasoningContext,
    SimulationEvent,
    SimulationEventType,
    SimulationRunConfig,
    TimestepSummary,
    float_to_conviction,
)
from ..core.rate_limiter import DualRateLimiter
from ..population.network import load_agents_json
from ..population.persona import PersonaConfig
from .progress import SimulationProgress
from .state import StateManager
from .persona import generate_persona
from .reasoning import batch_reason_agents, create_reasoning_context
from .propagation import apply_seed_exposures, propagate_through_network
from .stopping import evaluate_stopping_conditions
from .timeline import TimelineManager
from ..utils.callbacks import TimestepProgressCallback
from .aggregation import (
    compute_timestep_summary,
    compute_final_aggregates,
    compute_outcome_distributions,
    compute_timeline_aggregates,
)

logger = logging.getLogger(__name__)

# Conviction thresholds derived from the canonical model
_FIRM_CONVICTION = CONVICTION_MAP[ConvictionLevel.FIRM]
_MODERATE_CONVICTION = CONVICTION_MAP[ConvictionLevel.MODERATE]
_SHARING_CONVICTION_THRESHOLD = CONVICTION_MAP[ConvictionLevel.VERY_UNCERTAIN]


class SimulationSummary:
    """Summary of a completed simulation run."""

    def __init__(
        self,
        scenario_name: str,
        population_size: int,
        total_timesteps: int,
        stopped_reason: str | None,
        total_reasoning_calls: int,
        total_exposures: int,
        final_exposure_rate: float,
        outcome_distributions: dict[str, Any],
        runtime_seconds: float,
        model_used: str,
        completed_at: datetime,
    ):
        self.scenario_name = scenario_name
        self.population_size = population_size
        self.total_timesteps = total_timesteps
        self.stopped_reason = stopped_reason
        self.total_reasoning_calls = total_reasoning_calls
        self.total_exposures = total_exposures
        self.final_exposure_rate = final_exposure_rate
        self.outcome_distributions = outcome_distributions
        self.runtime_seconds = runtime_seconds
        self.model_used = model_used
        self.completed_at = completed_at

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "scenario_name": self.scenario_name,
            "population_size": self.population_size,
            "total_timesteps": self.total_timesteps,
            "stopped_reason": self.stopped_reason,
            "total_reasoning_calls": self.total_reasoning_calls,
            "total_exposures": self.total_exposures,
            "final_exposure_rate": self.final_exposure_rate,
            "outcome_distributions": self.outcome_distributions,
            "runtime_seconds": self.runtime_seconds,
            "model_used": self.model_used,
            "completed_at": self.completed_at.isoformat(),
        }


class SimulationEngine:
    """Main orchestrator for simulation execution.

    Coordinates the simulation loop: exposure, reasoning, propagation,
    and aggregation across timesteps.
    """

    def __init__(
        self,
        scenario: ScenarioSpec,
        population_spec: PopulationSpec,
        agents: list[dict[str, Any]],
        network: dict[str, Any],
        config: SimulationRunConfig,
        persona_config: PersonaConfig | None = None,
        rate_limiter: DualRateLimiter | None = None,
        chunk_size: int = 50,
    ):
        """Initialize simulation engine.

        Args:
            scenario: Scenario specification
            population_spec: Population specification
            agents: List of agent dictionaries
            network: Network data
            config: Simulation run configuration
            persona_config: Optional PersonaConfig for embodied persona rendering
            rate_limiter: Optional DualRateLimiter for API pacing (pivotal + routine)
            chunk_size: Number of agents per reasoning chunk for checkpointing
        """
        self.scenario = scenario
        self.population_spec = population_spec
        self.agents = agents
        self.network = network
        self.config = config
        self.persona_config = persona_config
        self.rate_limiter = rate_limiter
        self.chunk_size = chunk_size

        # Build agent map for quick lookup
        self.agent_map = {a.get("_id", str(i)): a for i, a in enumerate(agents)}

        # Build adjacency list for O(1) neighbor lookups (both directions)
        self.adjacency: dict[str, list[tuple[str, dict]]] = {}
        for edge in network.get("edges", []):
            src = edge.get("source")
            tgt = edge.get("target")
            if src is not None and tgt is not None:
                self.adjacency.setdefault(src, []).append((tgt, edge))
                self.adjacency.setdefault(tgt, []).append((src, edge))

        # Initialize RNG
        seed = config.random_seed
        if seed is None:
            seed = random.randint(0, 2**31 - 1)
        self.rng = random.Random(seed)
        self.seed = seed

        # Create output directory
        self.output_dir = Path(config.output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

        # Initialize state manager
        self.state_manager = StateManager(
            self.output_dir / "simulation.db",
            agents,
        )

        # Initialize timeline manager
        self.timeline = TimelineManager(self.output_dir / "timeline.jsonl")

        # Pre-generate personas for all agents
        # Extract decision-relevant attributes from outcome config (trait salience)
        decision_attrs = (
            scenario.outcomes.decision_relevant_attributes
            if hasattr(scenario.outcomes, "decision_relevant_attributes")
            else None
        )
        self._personas: dict[str, str] = {}
        for i, agent in enumerate(agents):
            agent_id = agent.get("_id", str(i))
            self._personas[agent_id] = generate_persona(
                agent,
                population_spec,
                persona_config=persona_config,
                decision_relevant_attributes=decision_attrs or None,
            )

        # Tracking variables
        self.recent_summaries: list[TimestepSummary] = []
        self.total_reasoning_calls = 0
        self.total_exposures = 0

        # Progress callback
        self._on_progress: TimestepProgressCallback | None = None

        # Live progress state (thread-safe, for CLI display)
        self._progress: SimulationProgress | None = None
        self._summary_interval: int = 50

    def set_progress_callback(self, callback: TimestepProgressCallback) -> None:
        """Set progress callback.

        Args:
            callback: Function(timestep, max_timesteps, status)
        """
        self._on_progress = callback

    def set_progress_state(self, progress: SimulationProgress) -> None:
        """Set shared progress state for live display.

        Args:
            progress: Thread-safe SimulationProgress instance
        """
        self._progress = progress

    def _report_progress(self, timestep: int, status: str) -> None:
        """Report progress to callback."""
        if self._on_progress:
            self._on_progress(
                timestep,
                self.scenario.simulation.max_timesteps,
                status,
            )

    def _log_verbose_summary(self, snap: dict) -> None:
        """Log a periodic summary block with distribution and averages.

        Args:
            snap: Snapshot dict from SimulationProgress.snapshot()
        """
        counts = snap.get("position_counts", {})
        total = sum(counts.values()) or 1
        avg_sent = snap.get("avg_sentiment")
        avg_conv = snap.get("avg_conviction")
        done = snap.get("agents_done", 0)
        agents_total = snap.get("agents_total", 0)

        lines = [
            f"[SUMMARY] Timestep {snap['timestep']} | {done}/{agents_total} agents"
        ]

        # Distribution sorted by count desc
        for position, count in sorted(counts.items(), key=lambda x: -x[1]):
            pct = count / total * 100
            lines.append(f"  {position}: {pct:.0f}% ({count})")

        if avg_sent is not None:
            lines.append(f"  avg_sentiment: {avg_sent:.2f}")
        if avg_conv is not None:
            lines.append(f"  avg_conviction: {avg_conv:.2f}")

        logger.info("\n".join(lines))

    def _get_resume_timestep(self) -> int:
        """Determine which timestep to start/resume from.

        Returns:
            Timestep number to begin execution at.
        """
        checkpoint = self.state_manager.get_checkpoint_timestep()
        if checkpoint is not None:
            # Crashed mid-timestep — resume it
            logger.info(f"Resuming from checkpoint timestep {checkpoint}")
            return checkpoint

        last_completed = self.state_manager.get_last_completed_timestep()
        if last_completed >= 0:
            # Completed some timesteps — start from next one
            logger.info(f"Resuming from timestep {last_completed + 1}")
            return last_completed + 1

        return 0

    def run(self) -> SimulationSummary:
        """Execute the full simulation.

        Supports automatic resume: if the output directory contains a
        simulation.db with partial progress, the engine picks up where
        it left off.

        Returns:
            SimulationSummary with results
        """
        start_time = time.time()
        stopped_reason = None
        final_timestep = 0

        start_timestep = self._get_resume_timestep()

        # Reload recent_summaries from DB on resume
        if start_timestep > 0:
            existing_summaries = self.state_manager.get_timestep_summaries()
            self.recent_summaries = existing_summaries[-20:]

        try:
            for timestep in range(
                start_timestep, self.scenario.simulation.max_timesteps
            ):
                final_timestep = timestep

                # Report progress
                exposure_rate = self.state_manager.get_exposure_rate()
                self._report_progress(timestep, f"Exposure: {exposure_rate:.1%}")

                # Run timestep
                summary = self._run_timestep(timestep)
                self.recent_summaries.append(summary)

                # Keep only last 20 summaries
                if len(self.recent_summaries) > 20:
                    self.recent_summaries.pop(0)

                # Check stopping conditions
                should_stop, reason = evaluate_stopping_conditions(
                    timestep,
                    self.scenario.simulation,
                    self.state_manager,
                    self.recent_summaries,
                )

                if should_stop:
                    stopped_reason = reason
                    logger.info(f"Stopping at timestep {timestep}: {reason}")
                    break

        except KeyboardInterrupt:
            logger.warning("Simulation interrupted by user")
            stopped_reason = "interrupted"

        # Finalize and export
        runtime = time.time() - start_time
        summary = self._finalize(final_timestep, stopped_reason, runtime)
        self._export_results()
        self.state_manager.close()

        return summary

    def _run_timestep(self, timestep: int) -> TimestepSummary:
        """Execute one timestep of simulation.

        Each phase (exposures, reasoning chunks, summary) has its own
        transaction. This enables per-chunk checkpointing so that a crash
        mid-timestep doesn't lose all progress.

        Args:
            timestep: Current timestep number

        Returns:
            TimestepSummary for this timestep
        """
        logger.info(f"[TIMESTEP {timestep}] ========== STARTING ==========")

        self.state_manager.mark_timestep_started(timestep)

        return self._execute_timestep(timestep)

    def _execute_timestep(self, timestep: int) -> TimestepSummary:
        """Execute the actual timestep logic — orchestrates sub-steps.

        Args:
            timestep: Current timestep number

        Returns:
            TimestepSummary for this timestep
        """
        # 1. Exposures (seed + network) — own transaction
        with self.state_manager.transaction():
            total_new_exposures = self._apply_exposures(timestep)
        self.total_exposures += total_new_exposures

        # 2. Chunked reasoning — each chunk has its own transaction
        agents_reasoned, state_changes, shares_occurred = self._reason_agents(timestep)

        # 3. Compute and save timestep summary — own transaction
        with self.state_manager.transaction():
            summary = compute_timestep_summary(
                timestep,
                self.state_manager,
                self.recent_summaries[-1] if self.recent_summaries else None,
            )
            summary.new_exposures = total_new_exposures
            summary.agents_reasoned = agents_reasoned
            summary.state_changes = state_changes
            summary.shares_occurred = shares_occurred

            self.state_manager.save_timestep_summary(summary)

        self.state_manager.mark_timestep_completed(timestep)

        # Flush timeline periodically
        if timestep % 10 == 0:
            self.timeline.flush()

        return summary

    def _apply_exposures(self, timestep: int) -> int:
        """Apply seed and network exposures for this timestep.

        Returns:
            Total new exposures this timestep.
        """
        new_seed = apply_seed_exposures(
            timestep,
            self.scenario,
            self.agents,
            self.state_manager,
            self.rng,
        )
        logger.info(f"[TIMESTEP {timestep}] Seed exposures: {new_seed}")

        new_network = propagate_through_network(
            timestep,
            self.scenario,
            self.agents,
            self.network,
            self.state_manager,
            self.rng,
            adjacency=self.adjacency,
            agent_map=self.agent_map,
        )
        logger.info(f"[TIMESTEP {timestep}] Network exposures: {new_network}")

        return new_seed + new_network

    def _reason_agents(self, timestep: int) -> tuple[int, int, int]:
        """Identify agents needing reasoning, run in chunks, commit per-chunk.

        On resume, agents already processed this timestep are skipped.

        Returns:
            Tuple of (agents_reasoned, state_changes, shares_occurred).
        """
        agents_to_reason = self.state_manager.get_agents_to_reason(
            timestep,
            self.config.multi_touch_threshold,
        )

        # Filter out agents already processed this timestep (resume support)
        already_done = self.state_manager.get_agents_already_reasoned_this_timestep(
            timestep
        )
        if already_done:
            agents_to_reason = [a for a in agents_to_reason if a not in already_done]
            logger.info(
                f"[TIMESTEP {timestep}] Skipping {len(already_done)} already-processed agents"
            )

        logger.info(f"[TIMESTEP {timestep}] Agents to reason: {len(agents_to_reason)}")

        # Update progress state for live display (even if 0 agents, so display updates)
        if self._progress:
            exposure_rate = self.state_manager.get_exposure_rate()
            self._progress.begin_timestep(
                timestep=timestep,
                max_timesteps=self.scenario.simulation.max_timesteps,
                agents_total=len(agents_to_reason),
                exposure_rate=exposure_rate,
            )

        if not agents_to_reason:
            return 0, 0, 0

        # Create on_agent_done closure for progress tracking
        def _on_agent_done(agent_id: str, result: Any) -> None:
            if result is None:
                return
            if self._progress:
                self._progress.record_agent_done(
                    position=result.position,
                    sentiment=result.sentiment,
                    conviction=result.conviction,
                )
                # Log verbose summary at intervals
                if (
                    self._progress.agents_done % self._summary_interval == 0
                    and self._progress.agents_done > 0
                ):
                    self._log_verbose_summary(self._progress.snapshot())

        # Build contexts and old states
        contexts = []
        old_states: dict[str, AgentState] = {}
        for agent_id in agents_to_reason:
            old_state = self.state_manager.get_agent_state(agent_id)
            old_states[agent_id] = old_state
            context = self._build_reasoning_context(agent_id, old_state)
            contexts.append(context)

        # Split into chunks
        total_reasoned = 0
        total_changes = 0
        total_shares = 0

        for chunk_start in range(0, len(contexts), self.chunk_size):
            chunk_contexts = contexts[chunk_start : chunk_start + self.chunk_size]

            reasoning_start = time.time()
            chunk_results = batch_reason_agents(
                chunk_contexts,
                self.scenario,
                self.config,
                rate_limiter=self.rate_limiter,
                on_agent_done=_on_agent_done,
            )
            reasoning_elapsed = time.time() - reasoning_start
            self.total_reasoning_calls += len(chunk_results)

            logger.info(
                f"[TIMESTEP {timestep}] Chunk {chunk_start // self.chunk_size + 1}: "
                f"{len(chunk_results)} agents in {reasoning_elapsed:.2f}s"
                if chunk_results
                else f"[TIMESTEP {timestep}] Chunk empty"
            )

            # Process and commit this chunk
            with self.state_manager.transaction():
                reasoned, changes, shares = self._process_reasoning_chunk(
                    timestep, chunk_results, old_states
                )

            total_reasoned += reasoned
            total_changes += changes
            total_shares += shares

        return total_reasoned, total_changes, total_shares

    def _process_reasoning_chunk(
        self,
        timestep: int,
        results: list[tuple[str, Any]],
        old_states: dict[str, AgentState],
    ) -> tuple[int, int, int]:
        """Process a chunk of reasoning results and update agent states.

        Returns:
            Tuple of (agents_reasoned, state_changes, shares_occurred).
        """
        agents_reasoned = 0
        state_changes = 0
        shares_occurred = 0
        state_updates: list[tuple[str, AgentState]] = []

        for agent_id, response in results:
            if response is None:
                continue

            old_state = old_states[agent_id]

            # Apply conviction-based flip resistance
            effective_will_share = response.will_share
            effective_position = response.position

            if (
                old_state.conviction is not None
                and old_state.conviction >= _FIRM_CONVICTION
            ):
                # High-conviction agent: resist position flip
                if (
                    old_state.position is not None
                    and response.position is not None
                    and old_state.position != response.position
                ):
                    new_conviction = response.conviction or 0.0
                    if new_conviction < _MODERATE_CONVICTION:
                        logger.info(
                            f"[CONVICTION] Agent {agent_id}: flip from {old_state.position} "
                            f"to {response.position} rejected (old conviction={float_to_conviction(old_state.conviction)}, "
                            f"new conviction={float_to_conviction(response.conviction)})"
                        )
                        effective_position = old_state.position

            # Apply conviction-gated sharing
            if (
                response.conviction is not None
                and response.conviction <= _SHARING_CONVICTION_THRESHOLD
            ):
                effective_will_share = False

            # Commitment: agents with conviction >= FIRM are committed
            is_committed = (
                response.conviction is not None
                and response.conviction >= _FIRM_CONVICTION
            )

            new_state = AgentState(
                agent_id=agent_id,
                aware=True,
                exposure_count=old_state.exposure_count,
                exposures=old_state.exposures,
                last_reasoning_timestep=timestep,
                position=effective_position,
                sentiment=response.sentiment,
                conviction=response.conviction,
                public_statement=response.public_statement,
                action_intent=response.action_intent,
                will_share=effective_will_share,
                committed=is_committed,
                outcomes=response.outcomes,
                raw_reasoning=response.reasoning,
                updated_at=timestep,
            )

            if self._state_changed(old_state, new_state):
                state_changes += 1

            if new_state.will_share and not old_state.will_share:
                shares_occurred += 1

            state_updates.append((agent_id, new_state))
            agents_reasoned += 1

            if response.reasoning_summary:
                memory_entry = MemoryEntry(
                    timestep=timestep,
                    sentiment=response.sentiment,
                    conviction=response.conviction,
                    summary=response.reasoning_summary,
                )
                self.state_manager.save_memory_entry(agent_id, memory_entry)

            self.timeline.log_event(
                SimulationEvent(
                    timestep=timestep,
                    event_type=SimulationEventType.AGENT_REASONED,
                    agent_id=agent_id,
                    details={
                        "position": new_state.position,
                        "sentiment": new_state.sentiment,
                        "conviction": new_state.conviction,
                        "will_share": new_state.will_share,
                    },
                )
            )

        if state_updates:
            self.state_manager.batch_update_states(state_updates, timestep)

        return agents_reasoned, state_changes, shares_occurred

    def _build_reasoning_context(
        self, agent_id: str, state: AgentState
    ) -> ReasoningContext:
        """Build reasoning context for an agent.

        Args:
            agent_id: Agent ID
            state: Current agent state

        Returns:
            ReasoningContext for LLM call
        """
        agent = self.agent_map.get(agent_id, {})
        persona = self._personas.get(agent_id, "")

        # Get peer opinions from neighbors (with public statements, not position labels)
        peer_opinions = self._get_peer_opinions(agent_id)

        # Get memory trace
        memory_trace = self.state_manager.get_memory_traces(agent_id)

        return create_reasoning_context(
            agent_id=agent_id,
            agent=agent,
            persona=persona,
            exposures=state.exposures,
            scenario=self.scenario,
            peer_opinions=peer_opinions,
            current_state=state if state.last_reasoning_timestep >= 0 else None,
            memory_trace=memory_trace,
        )

    def _get_peer_opinions(self, agent_id: str) -> list[PeerOpinion]:
        """Get opinions of connected peers.

        In the redesigned simulation, peers share public_statement + sentiment,
        NOT position labels. Position is output-only (Pass 2).

        Args:
            agent_id: Agent ID

        Returns:
            List of peer opinions
        """
        neighbors = self.adjacency.get(agent_id, [])
        opinions = []

        for neighbor_id, edge_data in neighbors[:5]:  # Limit to 5 peers
            neighbor_state = self.state_manager.get_agent_state(neighbor_id)

            # Include peer if they have formed any opinion (sentiment or statement)
            if neighbor_state.sentiment is not None or neighbor_state.public_statement:
                opinions.append(
                    PeerOpinion(
                        agent_id=neighbor_id,
                        relationship=edge_data.get("type", "contact"),
                        position=neighbor_state.position,  # kept for backwards compat
                        sentiment=neighbor_state.sentiment,
                        public_statement=neighbor_state.public_statement,
                        credibility=0.85,  # Phase 2 will make this dynamic
                    )
                )

        return opinions

    def _state_changed(self, old: AgentState, new: AgentState) -> bool:
        """Check if agent state changed meaningfully.

        Uses sentiment + conviction changes as primary signals,
        not position (which is output-only from Pass 2).

        Args:
            old: Previous state
            new: New state

        Returns:
            True if state changed
        """
        # Sentiment shift
        if old.sentiment is not None and new.sentiment is not None:
            if abs(old.sentiment - new.sentiment) > 0.1:
                return True

        # Conviction shift
        if old.conviction is not None and new.conviction is not None:
            if abs(old.conviction - new.conviction) > 0.15:
                return True

        # Position change (still tracked for output purposes)
        if old.position != new.position:
            return True

        # Sharing intent change
        if old.will_share != new.will_share:
            return True

        return False

    def _finalize(
        self,
        final_timestep: int,
        stopped_reason: str | None,
        runtime: float,
    ) -> SimulationSummary:
        """Finalize simulation and create summary.

        Args:
            final_timestep: Last completed timestep
            stopped_reason: Why simulation stopped
            runtime: Total runtime in seconds

        Returns:
            SimulationSummary
        """
        # Close timeline
        self.timeline.flush()
        self.timeline.close()

        # Compute final aggregates
        compute_final_aggregates(
            self.state_manager,
            self.agents,
            self.population_spec,
        )

        # Compute outcome distributions
        outcome_dists = compute_outcome_distributions(
            self.state_manager,
            self.scenario.outcomes.suggested_outcomes,
        )

        return SimulationSummary(
            scenario_name=self.scenario.meta.name,
            population_size=len(self.agents),
            total_timesteps=final_timestep + 1,
            stopped_reason=stopped_reason,
            total_reasoning_calls=self.total_reasoning_calls,
            total_exposures=self.total_exposures,
            final_exposure_rate=self.state_manager.get_exposure_rate(),
            outcome_distributions=outcome_dists,
            runtime_seconds=runtime,
            model_used=self.config.model,
            completed_at=datetime.now(),
        )

    def _export_results(self) -> None:
        """Export all results to output directory."""
        # Export summary
        summaries = self.state_manager.get_timestep_summaries()
        timeline_agg = compute_timeline_aggregates(summaries)

        with open(self.output_dir / "by_timestep.json", "w") as f:
            json.dump(timeline_agg, f, indent=2)

        # Export final agent states
        final_states = self.state_manager.export_final_states()

        # Merge with agent attributes
        agent_results = []
        for state in final_states:
            agent_id = state["agent_id"]
            agent = self.agent_map.get(agent_id, {})

            agent_results.append(
                {
                    "agent_id": agent_id,
                    "attributes": {
                        k: v for k, v in agent.items() if not k.startswith("_")
                    },
                    "final_state": state,
                    "reasoning_count": (
                        1 if state["last_reasoning_timestep"] >= 0 else 0
                    ),
                }
            )

        with open(self.output_dir / "agent_states.json", "w") as f:
            json.dump(agent_results, f, indent=2)

        # Export outcome distributions
        outcome_dists = compute_outcome_distributions(
            self.state_manager,
            self.scenario.outcomes.suggested_outcomes,
        )

        with open(self.output_dir / "outcome_distributions.json", "w") as f:
            json.dump(outcome_dists, f, indent=2)

        # Export meta information
        meta = {
            "scenario_name": self.scenario.meta.name,
            "scenario_path": self.config.scenario_path,
            "population_size": len(self.agents),
            "model": self.config.model,
            "pivotal_model": self.config.pivotal_model,
            "routine_model": self.config.routine_model,
            "seed": self.seed,
            "multi_touch_threshold": self.config.multi_touch_threshold,
            "completed_at": datetime.now().isoformat(),
        }

        if self.rate_limiter:
            meta["rate_limiter_stats"] = self.rate_limiter.stats()

        with open(self.output_dir / "meta.json", "w") as f:
            json.dump(meta, f, indent=2)


def run_simulation(
    scenario_path: str | Path,
    output_dir: str | Path,
    model: str = "",
    pivotal_model: str = "",
    routine_model: str = "",
    multi_touch_threshold: int = 3,
    random_seed: int | None = None,
    on_progress: TimestepProgressCallback | None = None,
    persona_config_path: str | Path | None = None,
    rate_tier: int | None = None,
    rpm_override: int | None = None,
    tpm_override: int | None = None,
    chunk_size: int = 50,
    progress: SimulationProgress | None = None,
) -> SimulationSummary:
    """Run a simulation from a scenario file.

    This is the main entry point for running simulations.

    Args:
        scenario_path: Path to scenario YAML file
        output_dir: Directory for results output
        model: LLM model for agent reasoning
        pivotal_model: Model for pivotal reasoning (default: same as model)
        routine_model: Cheap model for routine + classification
        multi_touch_threshold: Re-reason after N new exposures
        random_seed: Random seed for reproducibility
        on_progress: Progress callback(timestep, max, status)
        persona_config_path: Optional path to PersonaConfig YAML for embodied personas
        rate_tier: Rate limit tier (1-4, None = Tier 1)
        rpm_override: Override RPM limit
        tpm_override: Override TPM limit
        chunk_size: Agents per reasoning chunk for checkpointing
        progress: Optional SimulationProgress for live display tracking

    Returns:
        SimulationSummary with results
    """
    scenario_path = Path(scenario_path)
    output_dir = Path(output_dir)

    # Load scenario
    scenario = ScenarioSpec.from_yaml(scenario_path)

    # Load population spec
    pop_path = Path(scenario.meta.population_spec)
    if not pop_path.is_absolute():
        pop_path = scenario_path.parent / pop_path
    population_spec = PopulationSpec.from_yaml(pop_path)

    # Load agents
    agents_path = Path(scenario.meta.agents_file)
    if not agents_path.is_absolute():
        agents_path = scenario_path.parent / agents_path
    agents = load_agents_json(agents_path)

    # Load network
    network_path = Path(scenario.meta.network_file)
    if not network_path.is_absolute():
        network_path = scenario_path.parent / network_path
    with open(network_path) as f:
        network = json.load(f)

    # Load persona config if provided
    persona_config = None
    if persona_config_path:
        persona_config_path = Path(persona_config_path)
        if not persona_config_path.is_absolute():
            persona_config_path = scenario_path.parent / persona_config_path
        if persona_config_path.exists():
            persona_config = PersonaConfig.from_file(str(persona_config_path))
    else:
        # Try to find persona config automatically
        auto_config_path = pop_path.with_suffix(".persona.yaml")
        if auto_config_path.exists():
            persona_config = PersonaConfig.from_file(str(auto_config_path))

    # Create config
    config = SimulationRunConfig(
        scenario_path=str(scenario_path),
        output_dir=str(output_dir),
        model=model,
        pivotal_model=pivotal_model,
        routine_model=routine_model,
        multi_touch_threshold=multi_touch_threshold,
        random_seed=random_seed,
    )

    # Create dual rate limiter (separate limiters for pivotal and routine models)
    from ..config import get_config

    entropy_config = get_config()
    provider = entropy_config.simulation.provider
    effective_model = model or entropy_config.simulation.model or ""
    effective_pivotal = pivotal_model or effective_model
    effective_routine = routine_model or entropy_config.simulation.routine_model or ""

    rate_limiter = DualRateLimiter.create(
        provider=provider,
        pivotal_model=effective_pivotal,
        routine_model=effective_routine,
        tier=rate_tier,
        rpm_override=rpm_override,
        tpm_override=tpm_override,
    )

    # Create and run engine
    engine = SimulationEngine(
        scenario=scenario,
        population_spec=population_spec,
        agents=agents,
        network=network,
        config=config,
        persona_config=persona_config,
        rate_limiter=rate_limiter,
        chunk_size=chunk_size,
    )

    if on_progress:
        engine.set_progress_callback(on_progress)

    if progress:
        engine.set_progress_state(progress)

    return engine.run()
