# Netflix Password Sharing Crackdown: Ground Truth Data

This document contains the actual behavioral outcomes from Netflix's 2023 password sharing crackdown, for validating Entropy simulation predictions.

---

## The Experiment

**Question:** Does Entropy predict what people ACTUALLY DO, or what they SAY they'll do?

**Method:**
1. Run Entropy simulation of Netflix password sharers facing the crackdown
2. Compare predictions to:
   - **Surveys (stated intent):** What people said they'd do before the crackdown
   - **Actual outcomes (revealed behavior):** What people actually did

If Entropy ≈ surveys → we have "survey brain" problem
If Entropy ≈ actuals → we're fine (or lucky)

---

## Pre-Crackdown Survey Predictions (Stated Intent)

What surveys said people WOULD do:

| Survey | Sample | "Would Cancel" |
|--------|--------|----------------|
| Forbes Home (March 2023) | General subscribers | **35%** would cancel |
| Samba TV / HarrisX (May 2023) | Gen Z | **52%** would cancel |
| Samba TV / HarrisX (May 2023) | Millennials | **51%** would cancel |
| Samba TV / HarrisX (May 2023) | Gen X | ~25% would cancel |
| Samba TV / HarrisX (May 2023) | Boomers | ~25% would cancel |
| Earlier survey (April 2022) | US heads-of-household | **13%** would cancel |

**Password borrowers specifically:**
- 64% said they would subscribe if they couldn't borrow anymore
  - 39% would choose ad-supported tier
  - 25% would choose ad-free tier
- Implied: ~36% would NOT subscribe (cancel/churn)

**Survey consensus:** ~35-50% stated intent to cancel (varies by demographic)

Sources:
- [TV Technology: Survey 35% Would Cancel](https://www.tvtechnology.com/news/survey-35-of-netflix-subscribers-would-cancel-if-streamer-raises-prices-cracks-down-on-password-sharing)
- [StreamTV Insider: Gen Z/Millennials Cancel Intent](https://www.streamtvinsider.com/video/gen-z-millennials-more-likely-cancel-netflix-because-password-sharing-crackdown)
- [The Streamable: Churn Study](https://thestreamable.com/news/study-netflix-password-sharing-crackdown-could-lead-to-subscriber-churn)

---

## Actual Outcomes (Revealed Behavior)

What people ACTUALLY did after May 23, 2023 crackdown:

### Subscriber Numbers (the opposite of mass cancellation)

| Period | Net Subscriber Change | Notes |
|--------|----------------------|-------|
| Q2 2023 | **+5.9 million** | Beat analyst expectations of +1.77M |
| Q3 2023 | **+8.8 million** | vs +2.4M in Q3 2022 |
| Q2 2023 - Q4 2024 | **+50 million** | 238M → 301M total |

### Sign-up Surge (Antenna data)

- May 26-27, 2023: **~100,000 daily sign-ups** (highest in 4.5 years)
- Week of crackdown: **+117%** sign-ups week-over-week
- May 21 → June 18: **+236%** new subscriber growth
- Average daily sign-ups post-crackdown: **73,000** (+102% vs prior 60-day average)

### Cancellation Reality

- Cancels increased, but **sign-up to cancel ratio improved +25.6%**
- Netflix: "The cancel reaction was low"
- Net effect: **massive subscriber gain, not loss**

### Behavioral Breakdown (mid-2024 survey of actual behavior)

| Action Taken | Percentage |
|--------------|------------|
| Made no changes (share within household only) | **>60%** |
| Paid for extra member / family plan | **~15%** |
| Created own account | Unknown (included in sign-up surge) |
| Actually cancelled | **<10%** implied |

Sources:
- [Hollywood Reporter: Q2 2023 Earnings](https://www.hollywoodreporter.com/business/business-news/netflix-q2-2023-earnings-password-sharing-crackdown-1235539730/)
- [Variety: 6M Subscribers Added](https://variety.com/2023/tv/news/netflix-subscribers-up-q2-earnings-1235673960/)
- [Antenna: First Look at Impact](https://www.antenna.live/insights/a-first-look-at-the-impact-of-netflixs-password-sharing-crackdown)
- [Second Measure: Subscriber Counts Soared](https://secondmeasure.com/datapoints/netflix-password-sharing-crackdown-nasdaq-nflx/)
- [Statista: Consumer Response Survey](https://www.statista.com/statistics/1488093/consumer-response-netflix-password-sharing-crackdown-us/)

---

## The Say-Do Gap

| Metric | Surveys Said | Actuals |
|--------|--------------|---------|
| Would cancel | 35-52% | <10% |
| Net subscriber impact | Predicted losses of "up to 80M" | Gained 50M+ |
| Password borrowers who'd subscribe | 64% | Higher (100K/day sign-ups) |

**The gap is massive.** Surveys overestimated cancellation intent by 4-5x.

This is exactly what Aaru's Ned was talking about: "Humans lie... we are really really bad at imagining what we'll do in hypothetical scenarios."

---

## Validation Framework for Entropy

### Scenario Outcomes in Entropy Simulation

The `scenario.yaml` should have outcomes like:
- `pay_extra` - Pay the $7.99/month extra member fee
- `cancel_subscription` - Cancel Netflix entirely
- `comply_stop_sharing` - Stop sharing, keep own subscription
- `create_own_account` - Borrower creates their own paid account
- `find_workaround` - VPN, location spoofing, etc.
- `ignore_rules` - Continue sharing, hope not enforced

### Comparison Targets

**If Entropy has survey-brain:**
```
cancel_subscription: 35-50%  (matches stated intent)
pay_extra + create_own_account: 50-65%
```

**If Entropy predicts actual behavior:**
```
cancel_subscription: <10%
pay_extra + create_own_account + comply_stop_sharing: >80%
```

### Success Criteria

Entropy is validated if:
1. `cancel_subscription` prediction is closer to **<10%** than to **35-50%**
2. Overall "stay with Netflix" outcomes (pay/comply/create account) > 80%
3. Prediction captures the insight that stated intent ≠ actual behavior

---

## Notes

- Netflix had ~100M households sharing passwords pre-crackdown
- US crackdown began May 23, 2023
- Extra member fee: $7.99/month (US)
- The "family plan" / extra member uptake was ~15% of sharers
- Most sharers either already shared within household (compliant) or converted

---

## Appendix: Why Surveys Were Wrong

From the data, surveys failed because:

1. **Social desirability / spite signaling**: "I'd cancel!" sounds principled but people don't follow through
2. **Loss aversion underestimated**: People hate losing Netflix more than they hate paying $8
3. **Hypothetical ≠ real stakes**: When it's abstract, cancelling is easy. When your shows disappear, you pay.
4. **Inertia**: Cancelling requires action. Doing nothing (or paying) is easier.

This is the core insight Aaru builds on. Surveys measure *stated preference*. Behavior reveals *revealed preference*. They diverge systematically.
