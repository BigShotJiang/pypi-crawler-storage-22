"""envcheck — Validate environment variables at startup.

A minimalistic package that validates environment variables at startup,
providing type safety and clear error messages.

Example:
    >>> from envcheck import env
    >>> 
    >>> config = env({
    ...     "DATABASE_URL": str,          # required string
    ...     "DB_PORT": int,               # required, converted to int
    ...     "DEBUG": bool,                # required, smart bool parsing
    ...     "TIMEOUT": (float, 30.0),     # optional with default
    ... })
    >>> 
    >>> config.DATABASE_URL  # Typed, validated, guaranteed
    'postgres://localhost/db'
"""

from .config import EnvConfig
from .core import env
from .errors import EnvValidationError, ValidationFailure

__version__ = "0.1.1"
__all__ = [
    "env",
    "EnvConfig",
    "EnvValidationError",
    "ValidationFailure",
    "__version__",
]
