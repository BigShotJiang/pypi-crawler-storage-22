"""Configuration container for validated environment variables."""

from __future__ import annotations

from typing import Any, Dict, Iterator


class EnvConfig:
    """Immutable configuration container with attribute access.
    
    Provides clean attribute-style access to validated environment
    variables. Once created, the configuration cannot be modified.
    
    Example:
        >>> config = EnvConfig({"DATABASE_URL": "postgres://...", "DEBUG": True})
        >>> config.DATABASE_URL
        'postgres://...'
        >>> config.DEBUG
        True
    """
    
    __slots__ = ("_data", "_frozen")
    
    def __init__(self, data: Dict[str, Any]) -> None:
        """Initialize with validated configuration data.
        
        Args:
            data: Dictionary of variable names to validated values.
        """
        object.__setattr__(self, "_data", dict(data))
        object.__setattr__(self, "_frozen", True)
    
    def __getattr__(self, name: str) -> Any:
        """Get configuration value by attribute name.
        
        Args:
            name: Variable name.
            
        Returns:
            The validated value.
            
        Raises:
            AttributeError: If variable doesn't exist.
        """
        try:
            return self._data[name]
        except KeyError:
            raise AttributeError(
                f"'{type(self).__name__}' has no attribute '{name}'"
            )
    
    def __setattr__(self, name: str, value: Any) -> None:
        """Prevent modification after creation."""
        if getattr(self, "_frozen", False):
            raise AttributeError(
                "EnvConfig is immutable. Cannot modify after creation."
            )
        object.__setattr__(self, name, value)
    
    def __delattr__(self, name: str) -> None:
        """Prevent deletion of attributes."""
        raise AttributeError(
            "EnvConfig is immutable. Cannot delete attributes."
        )
    
    def __contains__(self, name: str) -> bool:
        """Check if a variable exists in config."""
        return name in self._data
    
    def __iter__(self) -> Iterator[str]:
        """Iterate over variable names."""
        return iter(self._data)
    
    def __len__(self) -> int:
        """Return number of variables."""
        return len(self._data)
    
    def __repr__(self) -> str:
        """Return string representation."""
        items = ", ".join(f"{k}={v!r}" for k, v in self._data.items())
        return f"EnvConfig({items})"
    
    def get(self, name: str, default: Any = None) -> Any:
        """Get a value with optional default.
        
        Args:
            name: Variable name.
            default: Default value if not found.
            
        Returns:
            The value or default.
        """
        return self._data.get(name, default)
    
    def to_dict(self) -> Dict[str, Any]:
        """Return a copy of the configuration as a dictionary."""
        return dict(self._data)
    
    def keys(self) -> Iterator[str]:
        """Return variable names."""
        return iter(self._data.keys())
    
    def values(self) -> Iterator[Any]:
        """Return variable values."""
        return iter(self._data.values())
    
    def items(self) -> Iterator[tuple[str, Any]]:
        """Return variable name-value pairs."""
        return iter(self._data.items())
