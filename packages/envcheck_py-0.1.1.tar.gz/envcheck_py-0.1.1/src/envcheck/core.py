"""Core validation logic for envguard."""

from __future__ import annotations

import os
from typing import Any, Dict, Tuple, Type, Union

from .config import EnvConfig
from .errors import EnvValidationError, ValidationFailure
from .types import get_converter

# Schema value can be:
# - A type (str, int, float, bool) for required variables
# - A tuple of (type, default) for optional variables with defaults
SchemaValue = Union[Type[Any], Tuple[Type[Any], Any]]
Schema = Dict[str, SchemaValue]


def _parse_schema_item(
    name: str, 
    spec: SchemaValue
) -> Tuple[Type[Any], Any, bool]:
    """Parse a schema item into type, default, and required flag.
    
    Args:
        name: Variable name (for error messages).
        spec: Schema specification (type or (type, default) tuple).
        
    Returns:
        Tuple of (type, default_value, is_required).
        
    Raises:
        TypeError: If spec format is invalid.
    """
    if isinstance(spec, type):
        # Required variable: just a type
        return spec, None, True
    
    if isinstance(spec, tuple) and len(spec) == 2:
        type_, default = spec
        if isinstance(type_, type):
            return type_, default, False
    
    raise TypeError(
        f"Invalid schema for '{name}': expected type or (type, default), "
        f"got {type(spec).__name__}"
    )


def env(
    schema: Schema,
    *,
    _environ: Dict[str, str] | None = None,
) -> EnvConfig:
    """Validate environment variables against a schema.
    
    Reads environment variables, validates their presence and types,
    and returns a typed configuration object. If validation fails,
    raises EnvValidationError with clear error messages.
    
    Args:
        schema: Dictionary mapping variable names to type specifications.
            - Use a type (str, int, float, bool) for required variables.
            - Use (type, default) tuple for optional variables.
        _environ: Optional environment dict for testing. Defaults to os.environ.
        
    Returns:
        EnvConfig object with validated, typed values.
        
    Raises:
        EnvValidationError: If any validation fails.
        TypeError: If schema contains unsupported types.
        
    Example:
        >>> config = env({
        ...     "DATABASE_URL": str,          # required
        ...     "DB_PORT": int,               # required, will be int
        ...     "DEBUG": bool,                # required, smart bool parsing
        ...     "TIMEOUT": (float, 30.0),     # optional with default
        ... })
        >>> config.DATABASE_URL
        'postgres://localhost/db'
        >>> config.DB_PORT
        5432
        >>> config.DEBUG
        True
    """
    environ = _environ if _environ is not None else os.environ
    
    missing: list[str] = []
    type_errors: list[ValidationFailure] = []
    values: Dict[str, Any] = {}
    
    for name, spec in schema.items():
        type_, default, required = _parse_schema_item(name, spec)
        
        # Get converter (validates type is supported)
        converter = get_converter(type_)
        
        # Get raw value from environment
        raw_value = environ.get(name)
        
        if raw_value is None:
            if required:
                missing.append(name)
            else:
                values[name] = default
            continue
        
        # Convert to target type
        try:
            values[name] = converter(raw_value)
        except ValueError as e:
            type_errors.append(
                ValidationFailure(
                    variable=name,
                    message=f"expected {type_.__name__}, {e}",
                )
            )
    
    # Raise if any errors
    error = EnvValidationError(missing=missing, type_errors=type_errors)
    if error.has_errors:
        raise error
    
    return EnvConfig(values)
