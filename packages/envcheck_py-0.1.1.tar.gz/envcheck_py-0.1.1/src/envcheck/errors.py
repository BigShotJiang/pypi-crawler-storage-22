"""Custom exceptions for envcheck."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List


@dataclass
class ValidationFailure:
    """Represents a single validation failure."""
    
    variable: str
    message: str


@dataclass
class EnvValidationError(Exception):
    """Raised when environment variable validation fails.
    
    Contains structured information about all validation failures,
    formatted into a clear, actionable error message.
    """
    
    missing: List[str] = field(default_factory=list)
    type_errors: List[ValidationFailure] = field(default_factory=list)
    
    def __post_init__(self) -> None:
        super().__init__(self._format_message())
    
    def _format_message(self) -> str:
        """Format a human-readable error message."""
        lines = [
            "",
            "❌ EnvCheck Validation Failed",
            "",
        ]
        
        if self.missing:
            lines.append("Missing required variables:")
            for var in self.missing:
                lines.append(f"  • {var}")
            lines.append("")
        
        if self.type_errors:
            lines.append("Type validation errors:")
            for failure in self.type_errors:
                lines.append(f"  • {failure.variable}: {failure.message}")
            lines.append("")
        
        lines.append("Fix these issues and restart the application.")
        
        return "\n".join(lines)
    
    @property
    def has_errors(self) -> bool:
        """Check if there are any validation errors."""
        return bool(self.missing or self.type_errors)
