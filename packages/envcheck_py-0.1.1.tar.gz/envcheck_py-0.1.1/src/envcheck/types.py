"""Type conversion utilities for environment variables."""

from __future__ import annotations

from typing import Any, Callable, Dict, Type

# Boolean truthy values (case-insensitive)
_BOOL_TRUE = frozenset({"true", "1", "yes", "on", "t", "y"})
_BOOL_FALSE = frozenset({"false", "0", "no", "off", "f", "n"})


def convert_str(value: str) -> str:
    """Convert string to string (passthrough)."""
    return value


def convert_int(value: str) -> int:
    """Convert string to integer.
    
    Args:
        value: String value from environment.
        
    Returns:
        Integer value.
        
    Raises:
        ValueError: If conversion fails.
    """
    try:
        return int(value)
    except ValueError:
        raise ValueError(f"cannot convert '{value}' to int")


def convert_float(value: str) -> float:
    """Convert string to float.
    
    Args:
        value: String value from environment.
        
    Returns:
        Float value.
        
    Raises:
        ValueError: If conversion fails.
    """
    try:
        return float(value)
    except ValueError:
        raise ValueError(f"cannot convert '{value}' to float")


def convert_bool(value: str) -> bool:
    """Convert string to boolean with smart parsing.
    
    Accepts (case-insensitive):
        True:  "true", "1", "yes", "on", "t", "y"
        False: "false", "0", "no", "off", "f", "n"
    
    Args:
        value: String value from environment.
        
    Returns:
        Boolean value.
        
    Raises:
        ValueError: If value is not a recognized boolean string.
    """
    normalized = value.strip().lower()
    
    if normalized in _BOOL_TRUE:
        return True
    if normalized in _BOOL_FALSE:
        return False
    
    raise ValueError(
        f"cannot convert '{value}' to bool "
        f"(expected: true/false, 1/0, yes/no, on/off)"
    )


# Type converter registry
CONVERTERS: Dict[Type[Any], Callable[[str], Any]] = {
    str: convert_str,
    int: convert_int,
    float: convert_float,
    bool: convert_bool,
}


def get_converter(type_: Type[Any]) -> Callable[[str], Any]:
    """Get the converter function for a type.
    
    Args:
        type_: The Python type to convert to.
        
    Returns:
        Converter function.
        
    Raises:
        TypeError: If no converter exists for the type.
    """
    if type_ not in CONVERTERS:
        supported = ", ".join(t.__name__ for t in CONVERTERS)
        raise TypeError(
            f"Unsupported type: {type_.__name__}. "
            f"Supported types: {supported}"
        )
    return CONVERTERS[type_]
