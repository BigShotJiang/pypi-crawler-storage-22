"""Tests for the EnvConfig container."""

import pytest
from envcheck.config import EnvConfig


class TestEnvConfig:
    """Tests for EnvConfig class."""
    
    def test_attribute_access(self):
        config = EnvConfig({"DATABASE_URL": "postgres://", "PORT": 5432})
        assert config.DATABASE_URL == "postgres://"
        assert config.PORT == 5432
    
    def test_missing_attribute(self):
        config = EnvConfig({"VAR": "value"})
        with pytest.raises(AttributeError, match="has no attribute"):
            _ = config.NONEXISTENT
    
    def test_immutable_no_set(self):
        config = EnvConfig({"VAR": "value"})
        with pytest.raises(AttributeError, match="immutable"):
            config.VAR = "new_value"
    
    def test_immutable_no_delete(self):
        config = EnvConfig({"VAR": "value"})
        with pytest.raises(AttributeError, match="immutable"):
            del config.VAR
    
    def test_contains(self):
        config = EnvConfig({"VAR": "value"})
        assert "VAR" in config
        assert "NONEXISTENT" not in config
    
    def test_iter(self):
        config = EnvConfig({"A": 1, "B": 2, "C": 3})
        keys = list(config)
        assert set(keys) == {"A", "B", "C"}
    
    def test_len(self):
        config = EnvConfig({"A": 1, "B": 2})
        assert len(config) == 2
        assert len(EnvConfig({})) == 0
    
    def test_repr(self):
        config = EnvConfig({"VAR": "value"})
        assert "EnvConfig" in repr(config)
        assert "VAR" in repr(config)
    
    def test_get_with_default(self):
        config = EnvConfig({"VAR": "value"})
        assert config.get("VAR") == "value"
        assert config.get("NONEXISTENT") is None
        assert config.get("NONEXISTENT", "default") == "default"
    
    def test_to_dict(self):
        data = {"A": 1, "B": "two"}
        config = EnvConfig(data)
        result = config.to_dict()
        assert result == data
        # Verify it's a copy
        result["C"] = 3
        assert "C" not in config
    
    def test_keys_values_items(self):
        config = EnvConfig({"A": 1, "B": 2})
        assert set(config.keys()) == {"A", "B"}
        assert set(config.values()) == {1, 2}
        assert set(config.items()) == {("A", 1), ("B", 2)}
