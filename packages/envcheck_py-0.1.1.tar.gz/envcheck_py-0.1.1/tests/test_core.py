"""Tests for core validation logic."""

import pytest
from envcheck import env, EnvConfig, EnvValidationError


class TestEnvBasic:
    """Basic env() function tests."""
    
    def test_required_string(self):
        config = env({"VAR": str}, _environ={"VAR": "value"})
        assert config.VAR == "value"
    
    def test_required_int(self):
        config = env({"PORT": int}, _environ={"PORT": "5432"})
        assert config.PORT == 5432
        assert isinstance(config.PORT, int)
    
    def test_required_float(self):
        config = env({"RATE": float}, _environ={"RATE": "3.14"})
        assert config.RATE == 3.14
        assert isinstance(config.RATE, float)
    
    def test_required_bool(self):
        config = env({"DEBUG": bool}, _environ={"DEBUG": "true"})
        assert config.DEBUG is True
    
    def test_returns_env_config(self):
        config = env({"VAR": str}, _environ={"VAR": "value"})
        assert isinstance(config, EnvConfig)


class TestEnvOptional:
    """Tests for optional variables with defaults."""
    
    def test_optional_uses_default_when_missing(self):
        config = env({"VAR": (str, "default")}, _environ={})
        assert config.VAR == "default"
    
    def test_optional_uses_env_when_present(self):
        config = env({"VAR": (str, "default")}, _environ={"VAR": "actual"})
        assert config.VAR == "actual"
    
    def test_optional_int_default(self):
        config = env({"PORT": (int, 8080)}, _environ={})
        assert config.PORT == 8080
    
    def test_optional_bool_default(self):
        config = env({"DEBUG": (bool, False)}, _environ={})
        assert config.DEBUG is False


class TestEnvMissing:
    """Tests for missing required variables."""
    
    def test_single_missing_raises(self):
        with pytest.raises(EnvValidationError) as exc_info:
            env({"VAR": str}, _environ={})
        
        error = exc_info.value
        assert "VAR" in error.missing
        assert "Missing required variables" in str(error)
    
    def test_multiple_missing_raises(self):
        with pytest.raises(EnvValidationError) as exc_info:
            env({"A": str, "B": int, "C": bool}, _environ={})
        
        error = exc_info.value
        assert set(error.missing) == {"A", "B", "C"}


class TestEnvTypeErrors:
    """Tests for type validation errors."""
    
    def test_invalid_int_raises(self):
        with pytest.raises(EnvValidationError) as exc_info:
            env({"PORT": int}, _environ={"PORT": "not_a_number"})
        
        error = exc_info.value
        assert len(error.type_errors) == 1
        assert error.type_errors[0].variable == "PORT"
        assert "expected int" in error.type_errors[0].message
    
    def test_invalid_bool_raises(self):
        with pytest.raises(EnvValidationError) as exc_info:
            env({"DEBUG": bool}, _environ={"DEBUG": "maybe"})
        
        error = exc_info.value
        assert len(error.type_errors) == 1
        assert "expected bool" in error.type_errors[0].message


class TestEnvCombinedErrors:
    """Tests for combined missing and type errors."""
    
    def test_reports_all_errors_at_once(self):
        with pytest.raises(EnvValidationError) as exc_info:
            env(
                {
                    "MISSING": str,
                    "BAD_INT": int,
                    "BAD_BOOL": bool,
                },
                _environ={
                    "BAD_INT": "nope",
                    "BAD_BOOL": "maybe",
                },
            )
        
        error = exc_info.value
        assert "MISSING" in error.missing
        assert len(error.type_errors) == 2


class TestEnvSchemaErrors:
    """Tests for invalid schema specifications."""
    
    def test_unsupported_type_raises(self):
        with pytest.raises(TypeError, match="Unsupported type"):
            env({"VAR": list}, _environ={"VAR": "[]"})
    
    def test_invalid_tuple_raises(self):
        with pytest.raises(TypeError, match="Invalid schema"):
            env({"VAR": ("not_a_type", "default")}, _environ={})


class TestEnvRealWorld:
    """Real-world usage patterns."""
    
    def test_typical_web_app_config(self):
        environ = {
            "DATABASE_URL": "postgres://user:pass@localhost:5432/db",
            "REDIS_URL": "redis://localhost:6379",
            "SECRET_KEY": "super-secret-key",
            "DEBUG": "false",
            "PORT": "8000",
        }
        
        config = env(
            {
                "DATABASE_URL": str,
                "REDIS_URL": str,
                "SECRET_KEY": str,
                "DEBUG": bool,
                "PORT": int,
                "WORKERS": (int, 4),
                "LOG_LEVEL": (str, "INFO"),
            },
            _environ=environ,
        )
        
        assert config.DATABASE_URL == "postgres://user:pass@localhost:5432/db"
        assert config.DEBUG is False
        assert config.PORT == 8000
        assert config.WORKERS == 4  # default
        assert config.LOG_LEVEL == "INFO"  # default
