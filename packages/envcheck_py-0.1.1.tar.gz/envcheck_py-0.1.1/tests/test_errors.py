"""Tests for error formatting."""

import pytest
from envcheck.errors import EnvValidationError, ValidationFailure


class TestEnvValidationError:
    """Tests for error message formatting."""
    
    def test_missing_only_message(self):
        error = EnvValidationError(missing=["DATABASE_URL", "API_KEY"])
        message = str(error)
        
        assert "EnvCheck Validation Failed" in message
        assert "Missing required variables" in message
        assert "DATABASE_URL" in message
        assert "API_KEY" in message
    
    def test_type_errors_only_message(self):
        error = EnvValidationError(
            type_errors=[
                ValidationFailure("PORT", "expected int, got 'abc'"),
                ValidationFailure("DEBUG", "expected bool, got 'maybe'"),
            ]
        )
        message = str(error)
        
        assert "Type validation errors" in message
        assert "PORT" in message
        assert "DEBUG" in message
    
    def test_combined_message(self):
        error = EnvValidationError(
            missing=["REQUIRED_VAR"],
            type_errors=[ValidationFailure("BAD_VAR", "expected int")],
        )
        message = str(error)
        
        assert "Missing required variables" in message
        assert "Type validation errors" in message
    
    def test_has_errors_true(self):
        error = EnvValidationError(missing=["VAR"])
        assert error.has_errors is True
        
        error = EnvValidationError(type_errors=[ValidationFailure("V", "err")])
        assert error.has_errors is True
    
    def test_has_errors_false(self):
        error = EnvValidationError()
        assert error.has_errors is False
