"""Tests for type conversion utilities."""

import pytest
from envcheck.types import (
    convert_str,
    convert_int,
    convert_float,
    convert_bool,
    get_converter,
)


class TestConvertStr:
    """Tests for string conversion."""
    
    def test_passthrough(self):
        assert convert_str("hello") == "hello"
        assert convert_str("") == ""
        assert convert_str("123") == "123"


class TestConvertInt:
    """Tests for integer conversion."""
    
    def test_valid_integers(self):
        assert convert_int("0") == 0
        assert convert_int("42") == 42
        assert convert_int("-10") == -10
        assert convert_int("5432") == 5432
    
    def test_invalid_integers(self):
        with pytest.raises(ValueError, match="cannot convert"):
            convert_int("not_a_number")
        with pytest.raises(ValueError, match="cannot convert"):
            convert_int("3.14")
        with pytest.raises(ValueError, match="cannot convert"):
            convert_int("")


class TestConvertFloat:
    """Tests for float conversion."""
    
    def test_valid_floats(self):
        assert convert_float("0") == 0.0
        assert convert_float("3.14") == 3.14
        assert convert_float("-2.5") == -2.5
        assert convert_float("42") == 42.0
    
    def test_invalid_floats(self):
        with pytest.raises(ValueError, match="cannot convert"):
            convert_float("not_a_number")
        with pytest.raises(ValueError, match="cannot convert"):
            convert_float("")


class TestConvertBool:
    """Tests for boolean conversion."""
    
    @pytest.mark.parametrize("value", ["true", "True", "TRUE", "1", "yes", "Yes", "on", "ON", "t", "y"])
    def test_truthy_values(self, value):
        assert convert_bool(value) is True
    
    @pytest.mark.parametrize("value", ["false", "False", "FALSE", "0", "no", "No", "off", "OFF", "f", "n"])
    def test_falsy_values(self, value):
        assert convert_bool(value) is False
    
    def test_whitespace_handling(self):
        assert convert_bool("  true  ") is True
        assert convert_bool("  false  ") is False
    
    def test_invalid_boolean(self):
        with pytest.raises(ValueError, match="cannot convert.*to bool"):
            convert_bool("maybe")
        with pytest.raises(ValueError, match="cannot convert.*to bool"):
            convert_bool("2")
        with pytest.raises(ValueError, match="cannot convert.*to bool"):
            convert_bool("")


class TestGetConverter:
    """Tests for converter registry."""
    
    def test_supported_types(self):
        assert get_converter(str) is convert_str
        assert get_converter(int) is convert_int
        assert get_converter(float) is convert_float
        assert get_converter(bool) is convert_bool
    
    def test_unsupported_type(self):
        with pytest.raises(TypeError, match="Unsupported type"):
            get_converter(list)
        with pytest.raises(TypeError, match="Unsupported type"):
            get_converter(dict)
