import pandas as pd
import streamlit as st
import streamlit.web.cli as stcli
import sys

from enviador_de_ordenes.core.email_sender import send_pdf_email
from enviador_de_ordenes.core.input_factory import InputFactory
from enviador_de_ordenes.core.logger import log_error
from enviador_de_ordenes.core.model_loader import load_models
from enviador_de_ordenes.core.parsers import parse_excel_to_order_form
from enviador_de_ordenes.core.pdf_generator import generate_pdf, show_pdf
from enviador_de_ordenes.core.telegram_sender import send_pdf_via_telegram
from enviador_de_ordenes.core.google_sheets import append_order_to_google_sheets

OrderForm, OrderItem = load_models()
# ============================================================
# CONFIG STREAMLIT
# ============================================================

st.set_page_config(page_title="Enviador de Órdenes", layout="centered")
st.title("📦 Enviador de Órdenes")
st.write(
    "Sube un archivo Excel o ingresa datos manualmente y genera un PDF con envío automático."
)


# ============================================================
# SECCIÓN: CAMPOS FIJOS (OrderForm sin items)
# ============================================================

st.subheader("Información del Pedido")

form_fields = {}
exclude_fields = {"items", "fecha", "unidades_pedidas", "id_orden"}

col1, col2 = st.columns(2)
toggle = 0

for field_name, field_info in OrderForm.model_fields.items():
    if field_name in exclude_fields:
        continue

    annotation = field_info.annotation
    label = field_name.replace("_", " ").title()

    target_col = col1 if toggle % 2 == 0 else col2
    toggle += 1

    with target_col:
        if annotation == str:
            form_fields[field_name] = st.text_input(label)
        elif annotation == int:
            form_fields[field_name] = st.number_input(label, min_value=0, step=1)
        elif annotation == float:
            form_fields[field_name] = st.number_input(label, min_value=0.0, step=0.1)
        else:
            form_fields[field_name] = st.text_input(label)


# ============================================================
# SECCIÓN: ITEMS — DOS MODOS: EXCEL O MANUAL
# ============================================================

st.markdown("---")
st.subheader("Items del Pedido")

modo = st.radio("Seleccione el modo de carga:", ["Excel", "Manual"], index=1)


# ============================================================
# MODO 1 — CARGA DESDE EXCEL
# ============================================================

if modo == "Excel":
    uploaded_file = st.file_uploader("Sube un archivo Excel", type=["xls", "xlsx"])

    if uploaded_file:
        try:
            strategy = InputFactory.get_strategy("excel", uploaded_file)
            raw_df = strategy.load()

            st.write("Vista previa del archivo cargado:")
            st.dataframe(raw_df.head(200))

            order = parse_excel_to_order_form(
                raw_df, order_form_cls=OrderForm, order_item_cls=OrderItem
            )

            st.session_state["order_form"] = order
            st.session_state["items"] = order.items

            st.success(
                "Excel procesado correctamente. OrderForm generado automáticamente."
            )

        except Exception as e:
            st.error(f"Error procesando Excel: {e}")
            log_error(str(e))


# ============================================================
# MODO 2 — INGRESO MANUAL (a prueba de reinicios)
# ============================================================

if modo == "Manual":
    item_fields = list(OrderItem.model_fields.keys())

    # Inicializa el DataFrame manual con las columnas del OrderItem dinámico
    if "manual_items_df" not in st.session_state or set(
        st.session_state.manual_items_df.columns
    ) != set(item_fields):
        st.session_state.manual_items_df = pd.DataFrame(
            [{field: "" for field in item_fields}]
        )

    st.write("Agrega o edita los items:")

    with st.form("manual_items_form", clear_on_submit=False):
        edited_df = st.data_editor(
            st.session_state.manual_items_df,
            num_rows="dynamic",
            width="stretch",
            hide_index=True,
            key="manual_items_editor",
        )

        submitted = st.form_submit_button("✅ Actualizar items")

    if submitted:
        st.session_state.manual_items_df = edited_df

        clean_df = edited_df.dropna(how="all")

        items_list = []

        for _, row in clean_df.iterrows():
            row_dict = {}

            for field in item_fields:
                value = row.get(field)

                if pd.isna(value):
                    value = None
                elif isinstance(value, str):
                    value = value.strip()
                    if value == "":
                        value = None

                row_dict[field] = value

            if all(v in (None, "") for v in row_dict.values()):
                continue

            try:
                items_list.append(OrderItem(**row_dict))
            except Exception as e:
                st.warning(f"Fila inválida: {e}")

        st.session_state["items"] = items_list

        st.success(f"{len(items_list)} items actualizados desde el modo manual.")

# ============================================================
# BOTÓN — PROCESAR + GENERAR PDF (FUSIONADO)
# ============================================================

if st.button("📄 Procesar y Generar PDF"):
    try:
        items = st.session_state.get("items", [])

        # --- Validación amigable ----
        missing_fields = [k for k, v in form_fields.items() if v in ("", None)]

        if missing_fields:
            campos = ", ".join([f"`{c}`" for c in missing_fields])
            st.error(f"Faltan campos obligatorios por completar: {campos}")
            st.stop()

        # --- Construir pedido ---
        order = OrderForm(**form_fields, items=items)
        order.calcular_unidades_pedidas()
        st.session_state["order"] = order
        st.session_state["google_sheets_saved"] = False

        # --- Generar PDF ---
        pdf_path = generate_pdf(order)
        st.session_state["pdf_path"] = pdf_path

        # --- Resumen limpio (dinámico según el modelo cargado) ---
        total_units = getattr(order, "unidades_pedidas", None)

        summary_lines = [
            "### 📦 Pedido procesado",
            f"**Ítems distintos:** {len(order.items)}",
        ]

        if total_units is not None:
            summary_lines.insert(1, f"**Total unidades pedidas:** {total_units}")

        # Agrega los campos del OrderForm dinámico (excepto items/fecha)
        for field_name, field_info in OrderForm.model_fields.items():
            if field_name in {"items", "fecha"}:
                continue

            value = getattr(order, field_name, None)
            if value in (None, ""):
                continue

            label = field_info.description or field_name.replace("_", " ").title()
            summary_lines.append(f"**{label}:** {value}")

        # Usa doble espacio antes de \n para forzar saltos de línea en Markdown
        st.info("  \n".join(summary_lines))

        # --- Info PDF ---
        st.success("PDF generado correctamente.")

    except Exception as e:
        st.error(f"Error procesando el pedido: {e}")


# ============================================================
# BOTONES DE ENVÍO
# ============================================================


def save_order_to_google_sheets_once():
    order = st.session_state.get("order")
    if not order:
        return (
            "missing_order",
            "No hay un pedido procesado para guardar en Google Sheets.",
            None,
        )

    if st.session_state.get("google_sheets_saved"):
        existing_id = st.session_state.get("order_id")
        if existing_id in (None, ""):
            existing_id = getattr(order, "id_orden", None)
        if existing_id not in (None, ""):
            order.id_orden = str(existing_id)
            st.session_state["order_id"] = existing_id
        return (
            "already_saved",
            "El pedido ya fue guardado en Google Sheets en esta sesión.",
            existing_id,
        )

    saved, assigned_id = append_order_to_google_sheets(order)
    if saved:
        st.session_state["google_sheets_saved"] = True
        if assigned_id is not None:
            st.session_state["order_id"] = assigned_id
            order.id_orden = str(assigned_id)
        return "saved", "Pedido guardado en Google Sheets.", assigned_id

    return "error", "Google Sheets no configurado o no se pudo guardar.", None


if "pdf_path" in st.session_state:
    col1, col2 = st.columns(2)

    # ----------------------- TELEGRAM -----------------------
    with col1:
        if st.button("📩 Enviar por Telegram", key="btn_tg"):
            status, msg, assigned_id = save_order_to_google_sheets_once()
            if status == "saved":
                st.success(msg)
            elif status == "already_saved":
                st.info(msg)
            else:
                st.warning(msg)

            pdf_path = st.session_state.get("pdf_path")
            if assigned_id is not None:
                order = st.session_state.get("order")
                if order:
                    order.id_orden = str(assigned_id)
                    pdf_path = generate_pdf(order)
                    st.session_state["pdf_path"] = pdf_path

            with st.spinner("Enviando a Telegram..."):
                ok = send_pdf_via_telegram(pdf_path)

            if ok:
                st.success("📨 PDF enviado por Telegram correctamente.")
            else:
                st.error("❌ No se pudo enviar por Telegram.")

    # ------------------------- EMAIL ------------------------
    with col2:
        if st.button("📧 Enviar por Email", key="btn_email"):
            status, msg, assigned_id = save_order_to_google_sheets_once()
            if status == "saved":
                st.success(msg)
            elif status == "already_saved":
                st.info(msg)
            else:
                st.warning(msg)

            pdf_path = st.session_state.get("pdf_path")
            if assigned_id is not None:
                order = st.session_state.get("order")
                if order:
                    order.id_orden = str(assigned_id)
                    pdf_path = generate_pdf(order)
                    st.session_state["pdf_path"] = pdf_path

            with st.spinner("Enviando correo..."):
                ok = send_pdf_email(pdf_path)

            if ok:
                st.success("📨 Email enviado correctamente.")
            else:
                st.error("❌ No se pudo enviar el correo.")


# ============================================================
# VISTA PREVIA PERSISTENTE DEL PDF
# ============================================================

if "pdf_path" in st.session_state:
    st.markdown("### 📄 Vista previa del PDF")
    pdf_display = show_pdf(st.session_state["pdf_path"])
    st.markdown(pdf_display, unsafe_allow_html=True)


def main():
    sys.argv = ["streamlit", "run", __file__]
    sys.exit(stcli.main())
