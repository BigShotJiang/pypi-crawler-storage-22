from typing import List, Optional

from pydantic import EmailStr
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    # Telegram
    TELEGRAM_BOT_TOKEN: Optional[str] = None
    TELEGRAM_CHAT_ID: Optional[str] = None

    # SMTP
    SMTP_SERVER: Optional[str] = None
    SMTP_PORT: Optional[int] = None
    SMTP_USER: Optional[EmailStr] = None
    SMTP_PASSWORD: Optional[str] = None
    EMAIL_TO: Optional[List[str]] = None

    # Paths
    OUTBOX_DIR: str = "src/enviador_de_ordenes/data/outbox"
    INBOX_DIR: str = "src/enviador_de_ordenes/data/inbox"
    LOGO_PATH: Optional[str] = None

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",  # 👈 soluciones todas las variables adicionales
    )


def get_settings():
    return Settings()
