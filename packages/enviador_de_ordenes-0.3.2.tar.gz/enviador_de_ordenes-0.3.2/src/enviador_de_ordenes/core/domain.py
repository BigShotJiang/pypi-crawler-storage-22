import importlib
import os
from datetime import datetime
from typing import List, Optional

from dotenv import load_dotenv
from pydantic import BaseModel, Field


class OrderItem(BaseModel):
    producto: str
    cantidad: int
    talla: Optional[str] = None
    color: Optional[str] = None
    precio: Optional[float] = None


class OrderForm(BaseModel):
    # ------------------------------
    # Metadatos automáticos
    # ------------------------------
    fecha: datetime = Field(default_factory=datetime.now)
    id_orden: Optional[str] = Field(default=None, description="ID")

    # ------------------------------
    # Campos fijos del formulario
    # ------------------------------
    quien_envia: str
    quien_recibe: str
    forma_pago: str
    direccion_envio: str
    celular_quien_recibe: str

    alistado_por: Optional[str] = None
    revisado_por: Optional[str] = None
    unidades_despachadas: Optional[int] = None
    facturado_por: Optional[str] = None
    quien_lleno_el_formato: Optional[str] = None

    # ------------------------------
    # Campo derivado (NO input del usuario)
    # ------------------------------
    unidades_pedidas: Optional[int] = Field(default=None)

    # ------------------------------
    # Items dinámicos
    # ------------------------------
    items: List[OrderItem] = Field(default_factory=list)

    # ------------------------------
    # Helpers
    # ------------------------------
    def calcular_unidades_pedidas(self):
        """Calcula la suma de cantidades de los items."""
        if self.items:
            self.unidades_pedidas = sum(i.cantidad for i in self.items)
        else:
            self.unidades_pedidas = 0

    @classmethod
    def from_items_only(cls, items):
        """Construir sin validar campos obligatorios."""
        return cls.model_construct(items=items)


class PDFTemplateConfig(BaseModel):
    title: str = "Orden de Pedido"
    empresa: str = "Mi Empresa"
    nit: str = "NIT 123.456.789"
    direccion: str = "Calle 123 #45-67"
    telefono: str = "320 555 1234"
    logo_path: Optional[str] = None


def load_pdf_template_config(module_path: str | None = None) -> PDFTemplateConfig:
    """
    Devuelve la configuración del template PDF.

    Prioridad:
      - Módulo externo (PDF_TEMPLATE_MODULE o ORDER_SCHEMA_MODULE) si define:
          * función get_pdf_template_config() que retorna dict o PDFTemplateConfig
          * o constante PDF_TEMPLATE_CONFIG (instancia o dict)
          * o dict PDF_TEMPLATE_KWARGS / TEMPLATE_KWARGS
      - Valores por defecto empaquetados.
    """
    # Cargar variables desde .env (si existe) para que PDF_TEMPLATE_MODULE/ORDER_SCHEMA_MODULE estén disponibles
    load_dotenv(override=False)

    target_module = (
        module_path
        or os.getenv("PDF_TEMPLATE_MODULE")
        or os.getenv("ORDER_SCHEMA_MODULE")
    )

    if not target_module:
        return PDFTemplateConfig()

    try:
        module = importlib.import_module(target_module)

        provider = None
        if hasattr(module, "get_pdf_template_config"):
            provider = module.get_pdf_template_config()
        elif hasattr(module, "PDF_TEMPLATE_CONFIG"):
            provider = getattr(module, "PDF_TEMPLATE_CONFIG")
        elif hasattr(module, "PDF_TEMPLATE_KWARGS"):
            provider = getattr(module, "PDF_TEMPLATE_KWARGS")
        elif hasattr(module, "TEMPLATE_KWARGS"):
            provider = getattr(module, "TEMPLATE_KWARGS")

        if isinstance(provider, PDFTemplateConfig):
            return provider
        if isinstance(provider, dict):
            return PDFTemplateConfig(**provider)

        # Si no se encontró nada usable, usa defaults
        return PDFTemplateConfig()
    except Exception as e:
        from .logger import log_error

        log_error(f"Error cargando PDF_TEMPLATE_CONFIG desde {target_module}: {e}")
        return PDFTemplateConfig()
