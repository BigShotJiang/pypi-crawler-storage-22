import smtplib
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path

from enviador_de_ordenes.core.config import get_settings
from enviador_de_ordenes.core.logger import log_error, log_info

settings = get_settings()


def send_pdf_email(
    pdf_path: str,
    to_emails: list[str] = None,
    subject: str = "Reporte automático",
    body: str = "Adjunto encontrarás el reporte generado automáticamente.",
):
    """
    Envía un PDF por correo usando SMTP seguro.
    """
    try:
        if to_emails is None:
            if not settings.EMAIL_TO:
                log_error("No hay destinatarios en to_emails ni en EMAIL_TO.")
                return False
            to_emails = settings.EMAIL_TO

        smtp_server = settings.SMTP_SERVER
        smtp_port = settings.SMTP_PORT
        smtp_user = settings.SMTP_USER
        smtp_password = settings.SMTP_PASSWORD

        if not smtp_server or not smtp_user or not smtp_password:
            log_error("Configuración SMTP incompleta.")
            return False

        file_path = Path(pdf_path)
        if not file_path.exists():
            raise FileNotFoundError(f"No existe el PDF: {pdf_path}")

        # -------------------------------------
        # Construir correo
        # -------------------------------------
        msg = MIMEMultipart()
        msg["From"] = smtp_user
        msg["To"] = ", ".join(to_emails)
        msg["Subject"] = subject

        msg.attach(MIMEText(body, "plain"))

        # Adjuntar PDF
        with open(file_path, "rb") as f:
            part = MIMEBase("application", "octet-stream")
            part.set_payload(f.read())
            encoders.encode_base64(part)
            part.add_header(
                "Content-Disposition", f"attachment; filename={file_path.name}"
            )
            msg.attach(part)

        # -------------------------------------
        # Conectar SMTP (modo seguro)
        # -------------------------------------
        log_info(f"Enviando PDF por correo a: {to_emails}")

        with smtplib.SMTP(smtp_server, smtp_port) as server:
            server.starttls()  # seguridad TLS
            server.login(smtp_user, smtp_password)
            server.sendmail(smtp_user, to_emails, msg.as_string())

        log_info("Correo enviado correctamente.")
        return True

    except Exception as e:
        log_error(f"Error enviando correo: {e}")
        return False
