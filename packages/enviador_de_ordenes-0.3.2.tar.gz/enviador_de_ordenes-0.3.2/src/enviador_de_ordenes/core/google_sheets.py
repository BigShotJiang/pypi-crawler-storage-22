import base64
import json
import os
from typing import Dict, List, Tuple

import gspread
import pandas as pd
from dotenv import load_dotenv
from google.oauth2 import service_account

from enviador_de_ordenes.core.logger import log_error, log_info


def _load_env_vars():
    load_dotenv(override=False)
    service_account_file = os.getenv("GDRIVE_SERVICE_ACCOUNT_FILE")
    service_account_b64 = os.getenv("GDRIVE_SERVICE_ACCOUNT_BASE64")
    sheet_id = os.getenv("GOOGLE_SHEETS_ID")
    worksheet_name = os.getenv("GOOGLE_SHEETS_WORKSHEET", "Hoja1")
    return service_account_file, service_account_b64, sheet_id, worksheet_name


def _get_client(
    service_account_file: str | None, service_account_b64: str | None
) -> gspread.Client:
    scopes = ["https://www.googleapis.com/auth/spreadsheets"]

    if service_account_b64:
        try:
            info = json.loads(base64.b64decode(service_account_b64))
            creds = service_account.Credentials.from_service_account_info(
                info, scopes=scopes
            )
            return gspread.authorize(creds)
        except Exception as e:
            log_error(f"Error decodificando GDRIVE_SERVICE_ACCOUNT_BASE64: {e}")
            raise

    if not service_account_file:
        raise ValueError(
            "No se proporcionó GDRIVE_SERVICE_ACCOUNT_FILE ni GDRIVE_SERVICE_ACCOUNT_BASE64"
        )

    creds = service_account.Credentials.from_service_account_file(
        service_account_file, scopes=scopes
    )
    return gspread.authorize(creds)


def _normalize_header(header: str) -> str:
    return header.strip().lower()


def _ensure_headers(
    worksheet: gspread.Worksheet, required_headers: List[str]
) -> Tuple[List[str], Dict[str, str]]:
    current_headers = worksheet.row_values(1)
    normalized_map: Dict[str, str] = {}
    for header in current_headers:
        header_str = str(header)
        if header_str.strip():
            normalized_map[_normalize_header(header_str)] = header_str

    actual_required = [
        normalized_map.get(_normalize_header(header), header)
        for header in required_headers
    ]
    header_map = {
        required: actual for required, actual in zip(required_headers, actual_required)
    }

    if not current_headers:
        worksheet.append_row(actual_required)
        return actual_required, header_map

    new_headers = list(current_headers)
    missing = [h for h in actual_required if h not in current_headers]
    if missing:
        new_headers.extend(missing)
        worksheet.update("1:1", [new_headers])
        log_info(f"Google Sheets: header actualizado, nuevas columnas: {missing}.")

    return new_headers, header_map


def _parse_consecutive_id(value: str | None) -> int | None:
    if value is None:
        return None
    text = str(value).strip()
    if not text:
        return None
    try:
        return int(text)
    except ValueError:
        try:
            return int(float(text))
        except ValueError:
            return None


def _get_next_consecutive_id(
    worksheet: gspread.Worksheet, headers: List[str], id_column: str
) -> int:
    try:
        id_col_idx = headers.index(id_column) + 1
    except ValueError:
        return 1

    id_values = worksheet.col_values(id_col_idx)
    for raw in reversed(id_values[1:]):
        parsed = _parse_consecutive_id(raw)
        if parsed is not None:
            return parsed + 1
    return 1


def append_order_to_google_sheets(order) -> tuple[bool, int | None]:
    """
    Envía los datos del pedido a Google Sheets.
    Retorna (True, id_consecutivo) o (False, None). No lanza errores a la UI.
    """
    service_account_file, service_account_b64, sheet_id, worksheet_name = (
        _load_env_vars()
    )

    if (not service_account_file and not service_account_b64) or not sheet_id:
        log_info("Google Sheets no configurado; se omite el guardado.")
        return False, None

    try:
        log_info(
            f"Google Sheets: iniciando append (worksheet={worksheet_name}, items={len(order.items) if order.items else 0})"
        )

        client = _get_client(service_account_file, service_account_b64)
        log_info("Google Sheets: autenticación OK.")

        sh = client.open_by_key(sheet_id)
        log_info(f"Google Sheets: hoja abierta ID={sheet_id}.")

        try:
            ws = sh.worksheet(worksheet_name)
            log_info(f"Google Sheets: worksheet seleccionada '{worksheet_name}'.")
        except gspread.WorksheetNotFound:
            titles = [ws.title for ws in sh.worksheets()]
            log_error(
                f"Worksheet '{worksheet_name}' no existe. Worksheets disponibles: {titles}"
            )
            return False, None

        # Prepara columnas: id consecutivo + campos del OrderForm (sin items/fecha) + campos del OrderItem
        form_fields = [f for f in order.model_fields.keys() if f not in ("items",)]
        item_fields = list(order.items[0].model_fields.keys()) if order.items else []
        required_headers = ["id"] + form_fields + item_fields

        headers, header_map = _ensure_headers(ws, required_headers)
        log_info(f"Google Sheets: header verificado con columnas {headers}.")

        id_column = header_map["id"]
        next_id = _get_next_consecutive_id(ws, headers, id_column)
        log_info(f"Google Sheets: consecutivo asignado id={next_id}.")

        # Construir filas como dicts, deduplicar y respetar orden de columnas
        rows_data = []
        for item in order.items or [None]:
            order_dict = order.model_dump(mode="json")
            item_dict = item.model_dump(mode="json") if item else {}

            row_dict = {id_column: next_id}
            for field in form_fields:
                value = order_dict.get(field)
                if field == "id_orden" and value in (None, ""):
                    value = next_id
                if isinstance(value, str):
                    value = value.strip()
                row_dict[header_map.get(field, field)] = value
            for field in item_fields:
                value = item_dict.get(field)
                if isinstance(value, str):
                    value = value.strip()
                row_dict[header_map.get(field, field)] = value

            rows_data.append(row_dict)

        df_rows = pd.DataFrame(rows_data, columns=headers).fillna("")
        before = len(df_rows)
        df_rows = df_rows.drop_duplicates()
        after = len(df_rows)
        if after < before:
            log_info(f"Google Sheets: filas deduplicadas de {before} a {after}.")

        ws.append_rows(df_rows.values.tolist(), value_input_option="USER_ENTERED")
        log_info(f"Google Sheets: append_rows OK ({len(df_rows)} filas).")
        return True, next_id

    except Exception as e:
        log_error(f"Error al guardar en Google Sheets: {e}")
        return False, None
