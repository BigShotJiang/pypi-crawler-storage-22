from enviador_de_ordenes.core.strategies.excel_input import ExcelInputStrategy
from enviador_de_ordenes.core.strategies.manual_input import ManualInputStrategy
from enviador_de_ordenes.core.logger import log_info


class InputFactory:
    """
    Selecciona la estrategia correcta según el origen de datos.
    """

    @staticmethod
    def get_strategy(modo: str, data):
        """
        modo: "excel" o "manual"
        data: puede ser archivo (excel) o un DataFrame (manual)
        """

        if modo == "excel":
            log_info("Seleccionando estrategia ExcelInputStrategy")
            return ExcelInputStrategy(file=data)

        elif modo == "manual":
            log_info("Seleccionando estrategia ManualInputStrategy")
            return ManualInputStrategy(df=data)

        else:
            raise ValueError(f"Modo no soportado: {modo}")
