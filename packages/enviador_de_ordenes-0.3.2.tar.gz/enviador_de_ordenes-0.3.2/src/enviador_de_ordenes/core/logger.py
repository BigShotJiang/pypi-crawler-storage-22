from datetime import datetime
from pathlib import Path
from typing import Literal
from enviador_de_ordenes.core.config import get_settings


settings = get_settings()

# Ruta del archivo de logs (opcional)
LOG_FILE = Path(settings.OUTBOX_DIR) / "logs.txt"
LOG_FILE.parent.mkdir(parents=True, exist_ok=True)


def _timestamp() -> str:
    """Retorna timestamp estándar para logs."""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _write_to_file(message: str) -> None:
    """Escribe el log en el archivo logs.txt."""
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(message + "\n")
    except Exception:
        # No queremos que un error de logging rompa la app
        pass


def _log(level: Literal["INFO", "WARNING", "ERROR", "EVENT"], msg: str) -> None:
    """Log centralizado: escribe en consola y archivo."""
    formatted = f"[{_timestamp()}] [{level}] {msg}"

    # Log a consola
    print(formatted)

    # Log a archivo
    _write_to_file(formatted)


# ---------------------------------------------------------
# Funciones públicas
# ---------------------------------------------------------


def log_info(message: str) -> None:
    _log("INFO", message)


def log_warning(message: str) -> None:
    _log("WARNING", message)


def log_error(message: str) -> None:
    _log("ERROR", message)


def log_event(message: str) -> None:
    """Eventos clave (envío de PDF, procesamiento, etc.)"""
    _log("EVENT", message)
