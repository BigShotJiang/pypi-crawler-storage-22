import importlib
import os
from typing import Tuple, Type

from dotenv import load_dotenv

from .domain import OrderForm as BaseOrderForm
from .domain import OrderItem as BaseOrderItem


def load_models() -> Tuple[Type[BaseOrderForm], Type[BaseOrderItem]]:
    """
    Devuelve las clases OrderForm y OrderItem a usar en la app.

    - Por defecto: usa las clases del core (BaseOrderForm, BaseOrderItem).
    - Si existe la variable ORDER_SCHEMA_MODULE, intenta importar
      OrderForm y OrderItem desde ese módulo.
    """
    # Asegura que se lean variables desde .env si no están exportadas
    load_dotenv(override=False)

    module_path = os.getenv("ORDER_SCHEMA_MODULE")

    if not module_path:
        return BaseOrderForm, BaseOrderItem

    try:
        module = importlib.import_module(module_path)

        CustomOrderForm = getattr(module, "OrderForm", BaseOrderForm)
        CustomOrderItem = getattr(module, "OrderItem", BaseOrderItem)

        return CustomOrderForm, CustomOrderItem
    except Exception as e:
        # Logueas y haces fallback a los modelos base
        from .logger import log_error

        log_error(f"Error cargando modelos desde {module_path}: {e}")
        return BaseOrderForm, BaseOrderItem
