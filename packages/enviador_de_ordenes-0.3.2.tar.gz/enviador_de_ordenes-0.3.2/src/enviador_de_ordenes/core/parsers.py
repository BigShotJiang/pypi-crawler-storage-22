import pandas as pd

from enviador_de_ordenes.core.domain import OrderForm, OrderItem
from enviador_de_ordenes.core.logger import log_info
from enviador_de_ordenes.core.utils.dataframe_utils import (
    clean_dataframe,
    df_to_order_items,
)


def parse_excel_to_order_form(
    df: pd.DataFrame,
    order_form_cls: type[OrderForm] = OrderForm,
    order_item_cls: type[OrderItem] = OrderItem,
) -> OrderForm:
    """
    Convierte un DataFrame Excel → OrderForm parcial.
    SOLO construye los items.
    NO valida ni completa los campos fijos del formulario.
    La UI será la encargada de completar y validar el pedido final.
    """

    log_info("Iniciando parseo de Excel → OrderForm (parcial)")

    # 1. Limpieza del DataFrame
    df_clean = clean_dataframe(df)

    # 2. Extraer los ítems del Excel
    try:
        items = df_to_order_items(df_clean, item_cls=order_item_cls)
    except Exception as e:
        raise ValueError(f"Error procesando items del Excel: {e}")

    # 3. Construir OrderForm parcial (sin validación)
    try:
        order = order_form_cls.from_items_only(items)
    except Exception as e:
        raise ValueError(f"Error construyendo OrderForm parcial: {e}")

    log_info("OrderForm parcial generado correctamente desde Excel.")
    return order
