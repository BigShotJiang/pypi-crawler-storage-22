import base64

from enviador_de_ordenes.core.config import get_settings
from enviador_de_ordenes.core.domain import load_pdf_template_config
from enviador_de_ordenes.core.utils.pdf_utils import order_to_dataframe
from enviador_de_ordenes.templates.pdf.base_template import SimplePDFTemplate

settings = get_settings()


def load_template_kwargs():
    """
    Carga los argumentos para SimplePDFTemplate con prioridad:
    1) Módulo externo (PDF_TEMPLATE_MODULE o ORDER_SCHEMA_MODULE) que exporte
       PDF_TEMPLATE_CONFIG / get_pdf_template_config / PDF_TEMPLATE_KWARGS.
    2) Defaults del core (PDFTemplateConfig).
    3) LOGO_PATH por .env puede sobreescribir el logo.
    """
    # Base: defaults (o módulo externo si está configurado en env)
    module_config = load_pdf_template_config()
    kwargs = module_config.model_dump()

    # Permitir que LOGO_PATH vía .env siga sobreescribiendo el logo
    if settings.LOGO_PATH:
        kwargs["logo_path"] = settings.LOGO_PATH

    return kwargs


def generate_pdf(order):
    """
    Genera un PDF profesional usando SimplePDFTemplate.
    """
    df = order_to_dataframe(order)

    # Nombre del archivo
    filename = f"orden_{order.fecha.strftime('%Y%m%d_%H%M%S')}.pdf"

    # Crear template
    template = SimplePDFTemplate(**load_template_kwargs())

    # Construir PDF
    pdf_path = template.build(order, df, filename)

    return pdf_path


def show_pdf(file_path):
    with open(file_path, "rb") as f:
        base64_pdf = base64.b64encode(f.read()).decode("utf-8")

    pdf_display = f"""
        <iframe
            src="data:application/pdf;base64,{base64_pdf}"
            width="100%"
            height="700px"
            style="border: none;"
        ></iframe>
    """
    return pdf_display
