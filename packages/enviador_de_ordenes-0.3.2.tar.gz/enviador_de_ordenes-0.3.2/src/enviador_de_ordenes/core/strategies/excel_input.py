import pandas as pd
from enviador_de_ordenes.core.logger import log_info, log_error


class ExcelInputStrategy:
    """
    Estrategia para cargar datos desde un archivo Excel.
    """

    def __init__(self, file):
        # El 'file' viene directo del Streamlit uploader
        self.file = file

    def load(self) -> pd.DataFrame:
        """Carga el Excel y lo retorna como DataFrame."""
        try:
            log_info("Leyendo archivo Excel…")
            df = pd.read_excel(self.file)
            log_info(f"Excel cargado correctamente ({df.shape[0]} filas).")
            return df

        except Exception as e:
            log_error(f"Error leyendo Excel: {e}")
            raise
