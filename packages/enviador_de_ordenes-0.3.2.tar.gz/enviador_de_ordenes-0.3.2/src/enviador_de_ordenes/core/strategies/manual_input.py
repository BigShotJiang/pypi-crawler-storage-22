import pandas as pd
from enviador_de_ordenes.core.logger import log_info


class ManualInputStrategy:
    """
    Estrategia para datos ingresados manualmente desde la UI.
    Recibe directamente el DataFrame construido en Streamlit.
    """

    def __init__(self, df: pd.DataFrame):
        self.df = df

    def load(self) -> pd.DataFrame:
        """Retorna el DataFrame manual tal cual está."""
        log_info(f"Usando DataFrame manual ({self.df.shape[0]} filas).")
        return self.df
