from pathlib import Path

import requests

from enviador_de_ordenes.core.config import get_settings
from enviador_de_ordenes.core.logger import log_error, log_info

settings = get_settings()


TELEGRAM_API_URL = "https://api.telegram.org/bot{token}/{method}"


def send_pdf_via_telegram(pdf_path: str):
    """
    Envía un PDF al chat/usuario configurado en env variables.
    """

    try:
        token = settings.TELEGRAM_BOT_TOKEN
        chat_id = settings.TELEGRAM_CHAT_ID

        if not token or not chat_id:
            log_error("Config Telegram incompleta: TOKEN o CHAT_ID vacíos.")
            return False

        file_path = Path(pdf_path)
        if not file_path.exists():
            raise FileNotFoundError(f"No existe el archivo a enviar: {pdf_path}")

        url = TELEGRAM_API_URL.format(token=token, method="sendDocument")

        log_info(f"Enviando PDF a Telegram → {file_path.name}")

        with open(file_path, "rb") as f:
            response = requests.post(
                url,
                data={"chat_id": chat_id},
                files={"document": (file_path.name, f, "application/pdf")},
                timeout=30,
            )

        if response.status_code == 200:
            log_info("PDF enviado exitosamente vía Telegram.")
            return True
        else:
            log_error(f"Error Telegram [{response.status_code}]: {response.text}")
            return False

    except Exception as e:
        log_error(f"Excepción al enviar PDF por Telegram: {e}")
        return False
