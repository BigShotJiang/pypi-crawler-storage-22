import unicodedata
from typing import Dict, Iterable, List, Optional, Type

import pandas as pd

from enviador_de_ordenes.core.domain import OrderForm, OrderItem
from enviador_de_ordenes.core.logger import log_error, log_info

# ============================================================
#  Helpers de normalización de texto
# ============================================================


def _normalize_text(value: str) -> str:
    """Normaliza texto para nombres de columnas."""
    if not isinstance(value, str):
        value = str(value)

    value = value.strip().lower()

    value = unicodedata.normalize("NFKD", value)
    value = "".join(c for c in value if not unicodedata.combining(c))

    value = value.replace(" ", "_")

    value = "".join(c for c in value if (c.isalnum() or c == "_"))

    return value or "columna_sin_nombre"


# ============================================================
#  Normalización de columnas
# ============================================================


def normalize_column_names(df: pd.DataFrame) -> pd.DataFrame:
    """Normaliza nombres de columnas."""
    original_cols = list(df.columns)
    new_cols = [_normalize_text(col) for col in original_cols]

    mapping = dict(zip(original_cols, new_cols))
    df = df.rename(columns=mapping)

    log_info(f"Columnas normalizadas: {mapping}")
    return df


# ============================================================
#  Limpieza de texto
# ============================================================


def strip_string_columns(df: pd.DataFrame) -> pd.DataFrame:
    for col in df.select_dtypes(include=["object", "string"]).columns:
        df[col] = df[col].astype(str).str.strip()
    log_info("Se aplicó strip() a columnas de texto.")
    return df


# ============================================================
#  Conversión a numérico
# ============================================================


def coerce_numeric_columns(
    df: pd.DataFrame,
    columns: Optional[Iterable[str]] = None,
    errors: str = "ignore",
) -> pd.DataFrame:
    if columns is None:
        columns = df.columns

    for col in columns:
        try:
            df[col] = pd.to_numeric(df[col], errors=errors)
        except Exception:
            pass

    log_info("Intento de conversión a numérico.")
    return df


# ============================================================
#  Filas vacías
# ============================================================


def drop_fully_empty_rows(df: pd.DataFrame) -> pd.DataFrame:
    before = len(df)
    df = df.dropna(how="all")
    removed = before - len(df)
    if removed > 0:
        log_info(f"Filas vacías eliminadas: {removed}")
    return df


# ============================================================
#  CLEAN DATAFRAME COMPLETO
# ============================================================


def clean_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    """
    Pipeline robusto para Excel PyME:
      1. Elimina filas vacías
      2. Limpia strings
      3. Normaliza columnas (acentos, espacios, mayúsculas)
      4. Intenta convertir a numérico
    """
    log_info("Iniciando limpieza de DataFrame…")

    df = df.copy()

    df = drop_fully_empty_rows(df)
    df = strip_string_columns(df)
    df = normalize_column_names(df)
    df = coerce_numeric_columns(df, errors="ignore")

    log_info(f"DataFrame limpio: {df.shape[0]} filas × {df.shape[1]} columnas.")
    return df


# ============================================================
#  CONVERSIÓN: DF → List[OrderItem] (Modelo Pydantic)
# ============================================================


def df_to_order_items(
    df: pd.DataFrame, item_cls: Type[OrderItem] = OrderItem
) -> List[OrderItem]:
    """
    Convierte un DataFrame limpio → lista de OrderItem
    usando validación Pydantic.
    """

    required_fields = {
        name for name, field in item_cls.model_fields.items() if field.is_required()
    }

    # Asegurar que existan columnas mínimas según el modelo dinámico
    missing = required_fields - set(df.columns)
    if missing:
        raise ValueError(f"Faltan columnas obligatorias: {missing}")

    valid_fields = set(item_cls.model_fields.keys())

    items = []
    for idx, row in df.iterrows():
        row_dict = {}

        for field in valid_fields:
            if field not in df.columns:
                continue

            value = row.get(field)
            if pd.isna(value):
                value = None
            elif isinstance(value, str):
                value = value.strip()

            row_dict[field] = value

        try:
            item = item_cls(**row_dict)
            items.append(item)

        except Exception as e:
            log_error(f"Fila {idx} inválida: {e}")
            raise ValueError(f"Error en fila {idx}: {e}")

    log_info(f"Items convertidos correctamente: {len(items)} items.")
    return items


# ============================================================
#  OPTIONAL: DF → CAMPOS DEL FORMULARIO
#  (Por si un Excel trae datos del cliente)
# ============================================================


def df_to_order_form_fields(
    df: pd.DataFrame, order_form_cls: Type[OrderForm] = OrderForm
) -> Dict:
    """
    Si un Excel incluye columnas como:
      - quien_envia
      - quien_recibe
      - forma_pago
    …este método las extrae automáticamente.
    """
    form_fields = {}
    order_form_fields = set(order_form_cls.model_fields.keys()) - {"items", "fecha"}

    for field in order_form_fields:
        if field in df.columns:
            # Tomar el primer valor no vacío de la columna
            val = df[field].dropna().astype(str).head(1)
            if len(val):
                form_fields[field] = val.iloc[0]

    log_info(f"Campos de formulario extraídos desde Excel: {form_fields.keys()}")
    return form_fields
