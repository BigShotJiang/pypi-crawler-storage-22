import pandas as pd

from enviador_de_ordenes.core.domain import OrderForm


def order_to_dataframe(order: OrderForm) -> pd.DataFrame:
    """
    Convierte OrderForm.items a un DataFrame para el PDF usando
    el esquema dinámico del OrderItem actual (sin campos fijos quemados).
    """
    if not order.items:
        return pd.DataFrame()

    # Respeta el orden de declaración de los campos del modelo dinámico
    fields = list(order.items[0].model_fields.keys())

    rows = []
    for item in order.items:
        item_dict = item.model_dump()
        rows.append({field: item_dict.get(field, "") for field in fields})

    df = pd.DataFrame(rows)
    return df.fillna("")
