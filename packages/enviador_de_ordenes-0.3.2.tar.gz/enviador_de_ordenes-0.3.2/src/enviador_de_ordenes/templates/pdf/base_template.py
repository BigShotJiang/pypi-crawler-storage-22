import importlib.resources as resources
from datetime import datetime
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.lib.utils import ImageReader
from reportlab.platypus import (
    BaseDocTemplate,
    Frame,
    Image,
    PageTemplate,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

from enviador_de_ordenes.core.config import get_settings
from enviador_de_ordenes.core.logger import log_error, log_info

settings = get_settings()


def _default_logo_path() -> str | None:
    """
    Devuelve la ruta del logo empaquetado con la librería.
    Si no existe (p.ej. en un entorno sin los assets), retorna None.
    """
    try:
        path = resources.files("enviador_de_ordenes.data").joinpath("logo.png")
        return str(path)
    except Exception:
        return None


class SimplePDFTemplate:
    """
    Template único para Enviador de Órdenes.
    Incluye:
      - Logo de la empresa (opcional)
      - Información de la empresa
      - Título del reporte
      - Tabla principal
      - Footer del sistema
    """

    def __init__(
        self,
        title: str = "Reporte de Órdenes",
        empresa: str = "Mi Empresa",
        nit: str = "",
        direccion: str = "",
        telefono: str = "",
        logo_path: str | None = None,
        pagesize=A4,
        logo_max_width: float | None = None,
        logo_max_height: float | None = None,
    ):
        self.title = title
        self.empresa = empresa
        self.nit = nit
        self.direccion = direccion
        self.telefono = telefono
        # Prioridad: argumento explícito > variable de entorno > logo empaquetado
        self.logo_path = logo_path or settings.LOGO_PATH or _default_logo_path()
        self.pagesize = pagesize
        # Bounding box opcional para el logo; preserva aspecto
        self.logo_max_width = logo_max_width or 1.3 * inch
        self.logo_max_height = logo_max_height or 1.3 * inch
        self.styles = getSampleStyleSheet()

        # Colores corporativos simples
        self.primary = colors.HexColor("#1A73E8")  # azul
        self.gray = colors.HexColor("#555555")

    # -----------------------------------------------------------
    # HEADER
    # -----------------------------------------------------------
    def build_header(self):
        elements = []

        # Logo
        if self.logo_path:
            try:
                reader = ImageReader(self.logo_path)
                iw, ih = reader.getSize()
                # Escala proporcional dentro de la caja max permitida
                scale = min(self.logo_max_width / iw, self.logo_max_height / ih, 1.0)
                width = iw * scale * 2
                height = ih * scale * 2

                img = Image(self.logo_path, width=width, height=height)
                elements.append(img)
                elements.append(Spacer(1, 6))
            except Exception:
                log_error("Logo no encontrado o inválido.")

        # Nombre empresa
        header_text = f"""
            <b>{self.empresa}</b><br/>
            <font size=10 color="#555555">
                {self.direccion}<br/>
                {self.telefono}<br/>
                {self.nit}
            </font>
        """
        elements.append(Paragraph(header_text, self.styles["Normal"]))
        elements.append(Spacer(1, 18))

        # Título del reporte
        title_p = Paragraph(
            f"<b><font size=16>{self.title}</font></b>", self.styles["Title"]
        )
        elements.append(title_p)

        # Fecha
        date = datetime.now().strftime("%d/%m/%Y %H:%M")
        date_p = Paragraph(
            f"<i><font size=10>Fecha: {date}</font></i>", self.styles["Normal"]
        )
        elements.append(date_p)

        elements.append(Spacer(1, 12))

        return elements

    def build_order_summary(self, order):
        """
        Construye un resumen dinámico basado en los metadatos del modelo.
        No usa textos quemados.
        """
        lines = ["<font size=11><b>Información del Pedido</b><br/><br/>"]

        fields = order.model_fields

        for field_name, field_info in fields.items():
            if field_name in ("items", "fecha"):
                continue  # No incluir items ni fecha en resumen

            label = field_info.description or field_name.replace("_", " ").title()
            value = getattr(order, field_name)

            # No mostrar campos vacíos
            if value is None or value == "":
                continue

            lines.append(f"<b>{label}:</b> {value}<br/>")

        lines.append("</font>")

        summary_html = "\n".join(lines)

        return [
            Paragraph(summary_html, self.styles["Normal"]),
            Spacer(1, 18),
        ]

    # -----------------------------------------------------------
    # TABLA PRINCIPAL
    # -----------------------------------------------------------
    def build_table(self, df):
        data = [df.columns.tolist()] + df.astype(str).values.tolist()

        table = Table(data)

        table_style = TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#F0F4FF")),
                ("TEXTCOLOR", (0, 0), (-1, 0), self.gray),
                ("ALIGN", (0, 0), (-1, -1), "CENTER"),
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#C2C2C2")),
                ("FONTSIZE", (0, 0), (-1, -1), 8),
                ("BOTTOMPADDING", (0, 0), (-1, 0), 10),
            ]
        )

        table.setStyle(table_style)
        return table

    # -----------------------------------------------------------
    # FOOTER
    # -----------------------------------------------------------
    def build_footer(self):
        text = """<font color="#777777" size=9>
                  Reporte generado automáticamente por Enviador de Órdenes.
                  </font>"""
        return [Spacer(1, 16), Paragraph(text, self.styles["Normal"])]

    # -----------------------------------------------------------
    # BUILD FINAL
    # -----------------------------------------------------------

    def build(self, order, df, filename):
        try:
            output_path = Path(settings.OUTBOX_DIR) / filename
            output_path.parent.mkdir(parents=True, exist_ok=True)

            log_info(f"Construyendo PDF (2 columnas) → {output_path}")

            # ----------- BaseDocTemplate con 2 columnas -----------
            doc = BaseDocTemplate(
                str(output_path),
                pagesize=self.pagesize,
                leftMargin=30,
                rightMargin=30,
                topMargin=30,
                bottomMargin=30,
            )

            # Tamaños columna
            frame_width = (self.pagesize[0] - 60) / 2 - 10  # margenes + gap
            frame_height = self.pagesize[1] - 60

            frame1 = Frame(
                30,
                30,  # x,y
                frame_width,
                frame_height,
                leftPadding=5,
                rightPadding=5,
                topPadding=5,
                bottomPadding=5,
                id="col1",
            )

            frame2 = Frame(
                30 + frame_width + 20,
                30,  # x desplazado + gap
                frame_width,
                frame_height,
                leftPadding=5,
                rightPadding=5,
                topPadding=5,
                bottomPadding=5,
                id="col2",
            )

            # Plantilla de página con 2 columnas
            page_template = PageTemplate(
                id="TwoCol",
                frames=[frame1, frame2],
            )

            doc.addPageTemplates([page_template])

            # -------- Story (contenido) ----------
            story = []

            # Header
            story += self.build_header()

            # 2. Resumen del pedido (OrderForm)
            story += self.build_order_summary(order)

            # Tabla
            story.append(self.build_table(df))
            story.append(Spacer(1, 18))

            # Footer
            story += self.build_footer()

            # Build final
            doc.build(story)

            log_info(f"PDF creado correctamente en dos columnas: {output_path}")
            return str(output_path)

        except Exception as e:
            log_error(f"Error creando PDF: {e}")
            raise
