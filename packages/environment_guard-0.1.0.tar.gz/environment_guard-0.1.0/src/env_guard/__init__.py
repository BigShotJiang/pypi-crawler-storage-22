"""
env-guard: Zero-config environment variable validation.

Infer types from .env.example, validate at runtime, fail fast with beautiful errors.
"""

from .validator import (
    validate,
    validate_env,
    EnvValidationError,
    EnvVar,
    InferredType,
    ValidationResult,
)

__version__ = "0.1.0"
__all__ = [
    "validate",
    "validate_env",
    "EnvValidationError",
    "EnvVar",
    "InferredType",
    "ValidationResult",
    "__version__",
]


def main() -> None:
    """CLI entry point for env-guard."""
    import sys
    import argparse

    parser = argparse.ArgumentParser(
        prog="env-guard",
        description="Validate environment variables against .env.example",
    )
    parser.add_argument(
        "-e", "--example",
        default=".env.example",
        help="Path to .env.example file (default: .env.example)",
    )
    parser.add_argument(
        "-q", "--quiet",
        action="store_true",
        help="Only output errors, no success messages",
    )
    parser.add_argument(
        "--no-exit",
        action="store_true",
        help="Don't exit with code 1 on validation failure",
    )
    parser.add_argument(
        "-v", "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )

    args = parser.parse_args()

    try:
        result = validate_env(example_path=args.example, exit_on_error=False)

        if result.is_valid:
            if not args.quiet:
                print(f"\n  All {len(result.variables)} environment variables validated successfully!")
            sys.exit(0)
        else:
            if not args.no_exit:
                sys.exit(1)
    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
