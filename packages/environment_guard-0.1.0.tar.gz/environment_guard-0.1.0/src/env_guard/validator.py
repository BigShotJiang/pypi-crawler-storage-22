"""
Core validation logic for env-guard.

This module provides environment variable validation by:
1. Parsing .env.example to infer expected variables and their types
2. Checking os.environ for presence and type conformance
3. Reporting all errors with colorized, grouped output
"""

from __future__ import annotations

import os
import re
import sys
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any

from dotenv import dotenv_values


class InferredType(Enum):
    """Types that can be inferred from .env.example values."""

    STRING = "string"
    INTEGER = "integer"
    FLOAT = "float"
    BOOLEAN = "boolean"

    def __str__(self) -> str:
        return self.value


@dataclass
class EnvVar:
    """Represents an environment variable specification."""

    name: str
    example_value: str
    inferred_type: InferredType
    optional: bool = False
    comment: str | None = None

    def validate_value(self, value: str) -> tuple[bool, str | None]:
        """
        Validate that a value conforms to this variable's inferred type.

        Returns:
            Tuple of (is_valid, error_message)
        """
        if self.inferred_type == InferredType.INTEGER:
            try:
                int(value)
                return True, None
            except ValueError:
                return False, f"expected integer, got '{value}'"

        elif self.inferred_type == InferredType.FLOAT:
            try:
                float(value)
                return True, None
            except ValueError:
                return False, f"expected float, got '{value}'"

        elif self.inferred_type == InferredType.BOOLEAN:
            if value.lower() in ("true", "false", "1", "0", "yes", "no"):
                return True, None
            return False, f"expected boolean (true/false/1/0/yes/no), got '{value}'"

        # STRING type accepts anything
        return True, None


@dataclass
class ValidationError:
    """Represents a single validation error."""

    var_name: str
    error_type: str  # "missing" or "type_mismatch"
    message: str
    expected_type: InferredType | None = None
    actual_value: str | None = None


@dataclass
class ValidationResult:
    """Result of environment validation."""

    is_valid: bool
    variables: list[EnvVar]
    errors: list[ValidationError] = field(default_factory=list)
    validated_values: dict[str, Any] = field(default_factory=dict)


class EnvValidationError(Exception):
    """Raised when environment validation fails."""

    def __init__(self, result: ValidationResult):
        self.result = result
        super().__init__(f"Environment validation failed with {len(result.errors)} error(s)")


def infer_type(value: str) -> InferredType:
    """
    Infer the type of an environment variable from its example value.

    Rules:
    - Integers: digits only, optionally with leading minus
    - Floats: digits with decimal point
    - Booleans: true/false/yes/no (case insensitive)
    - Everything else: string
    """
    if not value:
        return InferredType.STRING

    # Check for boolean
    if value.lower() in ("true", "false", "yes", "no"):
        return InferredType.BOOLEAN

    # Check for integer (including negative)
    if re.match(r"^-?\d+$", value):
        return InferredType.INTEGER

    # Check for float (including negative, must have decimal point)
    if re.match(r"^-?\d+\.\d+$", value):
        return InferredType.FLOAT

    return InferredType.STRING


def is_optional_marker(comment: str | None) -> bool:
    """Check if a comment indicates the variable is optional."""
    if not comment:
        return False
    comment_lower = comment.lower()
    return any(marker in comment_lower for marker in ["optional", "?", "not required"])


def parse_env_example(path: str | Path) -> list[EnvVar]:
    """
    Parse a .env.example file and return a list of EnvVar specifications.

    Handles:
    - Standard KEY=value pairs
    - Comments (# ...) for optional markers
    - Empty values
    """
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Example file not found: {path}")

    # Use dotenv to parse key-value pairs
    values = dotenv_values(path)

    # Also read raw content to extract comments
    content = path.read_text(encoding="utf-8")
    lines = content.splitlines()

    # Build a map of variable names to their inline comments
    var_comments: dict[str, str] = {}
    for line in lines:
        line = line.strip()
        if not line or line.startswith("#"):
            continue

        # Check for inline comment
        if "#" in line:
            # Split on first = to get the key
            if "=" in line:
                key_part = line.split("=")[0].strip()
                comment_part = line.split("#", 1)[1].strip() if "#" in line else ""
                var_comments[key_part] = comment_part

    env_vars = []
    for name, value in values.items():
        value = value or ""
        inferred = infer_type(value)
        comment = var_comments.get(name)
        optional = is_optional_marker(comment)

        env_vars.append(
            EnvVar(
                name=name,
                example_value=value,
                inferred_type=inferred,
                optional=optional,
                comment=comment,
            )
        )

    return env_vars


def validate_environment(
    env_vars: list[EnvVar],
    environ: dict[str, str] | None = None,
) -> ValidationResult:
    """
    Validate environment variables against specifications.

    Args:
        env_vars: List of expected environment variables
        environ: Environment dict to validate (defaults to os.environ)

    Returns:
        ValidationResult with status, errors, and validated values
    """
    if environ is None:
        environ = dict(os.environ)

    errors: list[ValidationError] = []
    validated_values: dict[str, Any] = {}

    for var in env_vars:
        value = environ.get(var.name)

        # Check if missing
        if value is None:
            if not var.optional:
                errors.append(
                    ValidationError(
                        var_name=var.name,
                        error_type="missing",
                        message=f"Required variable '{var.name}' is not set",
                        expected_type=var.inferred_type,
                    )
                )
            continue

        # Check type
        is_valid, error_msg = var.validate_value(value)
        if not is_valid:
            errors.append(
                ValidationError(
                    var_name=var.name,
                    error_type="type_mismatch",
                    message=f"Variable '{var.name}': {error_msg}",
                    expected_type=var.inferred_type,
                    actual_value=value,
                )
            )
        else:
            # Store the coerced value
            validated_values[var.name] = _coerce_value(value, var.inferred_type)

    return ValidationResult(
        is_valid=len(errors) == 0,
        variables=env_vars,
        errors=errors,
        validated_values=validated_values,
    )


def _coerce_value(value: str, inferred_type: InferredType) -> Any:
    """Convert a string value to its inferred type."""
    if inferred_type == InferredType.INTEGER:
        return int(value)
    elif inferred_type == InferredType.FLOAT:
        return float(value)
    elif inferred_type == InferredType.BOOLEAN:
        return value.lower() in ("true", "1", "yes")
    return value


# =============================================================================
# Output Formatting (with optional rich support)
# =============================================================================

try:
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    from rich.text import Text

    RICH_AVAILABLE = True
except ImportError:
    RICH_AVAILABLE = False


def _format_output_rich(result: ValidationResult) -> None:
    """Format validation output using rich library."""
    console = Console(stderr=True)

    if result.is_valid:
        # Success output
        console.print()
        text = Text()
        text.append("  ", style="green")
        text.append(f"All {len(result.variables)} environment variables validated successfully!", style="green bold")
        console.print(Panel(text, border_style="green", title="env-guard"))
        console.print()
        return

    # Error output
    console.print()
    console.print(Panel(
        f"[red bold]Environment validation failed with {len(result.errors)} error(s)[/]",
        border_style="red",
        title="env-guard",
    ))
    console.print()

    # Group errors by type
    missing = [e for e in result.errors if e.error_type == "missing"]
    type_errors = [e for e in result.errors if e.error_type == "type_mismatch"]

    if missing:
        table = Table(title="Missing Variables", border_style="red", title_style="red bold")
        table.add_column("Variable", style="cyan")
        table.add_column("Expected Type", style="yellow")

        for error in missing:
            table.add_row(error.var_name, str(error.expected_type))

        console.print(table)
        console.print()

    if type_errors:
        table = Table(title="Type Mismatches", border_style="red", title_style="red bold")
        table.add_column("Variable", style="cyan")
        table.add_column("Expected", style="yellow")
        table.add_column("Got", style="red")

        for error in type_errors:
            table.add_row(
                error.var_name,
                str(error.expected_type),
                repr(error.actual_value),
            )

        console.print(table)
        console.print()

    # Hint
    console.print("[dim]Hint: Set missing variables or fix type mismatches in your environment.[/]")
    console.print()


def _format_output_plain(result: ValidationResult) -> None:
    """Format validation output using ANSI codes (no rich dependency)."""
    # ANSI color codes
    RED = "\033[91m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    CYAN = "\033[96m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    RESET = "\033[0m"

    if result.is_valid:
        print(file=sys.stderr)
        print(f"{GREEN}{BOLD}  All {len(result.variables)} environment variables validated successfully!{RESET}", file=sys.stderr)
        print(file=sys.stderr)
        return

    # Error output
    print(file=sys.stderr)
    print(f"{RED}{BOLD}=== env-guard: Validation Failed ==={RESET}", file=sys.stderr)
    print(f"{RED}Found {len(result.errors)} error(s){RESET}", file=sys.stderr)
    print(file=sys.stderr)

    # Group errors by type
    missing = [e for e in result.errors if e.error_type == "missing"]
    type_errors = [e for e in result.errors if e.error_type == "type_mismatch"]

    if missing:
        print(f"{RED}{BOLD}Missing Variables:{RESET}", file=sys.stderr)
        for error in missing:
            print(f"  {CYAN}{error.var_name}{RESET} - expected {YELLOW}{error.expected_type}{RESET}", file=sys.stderr)
        print(file=sys.stderr)

    if type_errors:
        print(f"{RED}{BOLD}Type Mismatches:{RESET}", file=sys.stderr)
        for error in type_errors:
            print(
                f"  {CYAN}{error.var_name}{RESET}: expected {YELLOW}{error.expected_type}{RESET}, "
                f"got {RED}{repr(error.actual_value)}{RESET}",
                file=sys.stderr
            )
        print(file=sys.stderr)

    print(f"{DIM}Hint: Set missing variables or fix type mismatches in your environment.{RESET}", file=sys.stderr)
    print(file=sys.stderr)


def print_validation_result(result: ValidationResult, use_rich: bool | None = None) -> None:
    """
    Print validation result with colorized output.

    Args:
        result: The validation result to display
        use_rich: Force rich (True) or plain (False) output. None = auto-detect.
    """
    if use_rich is None:
        use_rich = RICH_AVAILABLE

    if use_rich and RICH_AVAILABLE:
        _format_output_rich(result)
    else:
        _format_output_plain(result)


# =============================================================================
# Public API
# =============================================================================

def validate_env(
    example_path: str | Path = ".env.example",
    exit_on_error: bool = True,
    use_rich: bool | None = None,
    quiet: bool = False,
) -> ValidationResult:
    """
    Validate environment variables against a .env.example file.

    This is the main entry point for most users.

    Args:
        example_path: Path to the .env.example file
        exit_on_error: If True, calls sys.exit(1) on validation failure
        use_rich: Force rich (True) or plain (False) output. None = auto-detect.
        quiet: If True, suppress all output (useful for programmatic use)

    Returns:
        ValidationResult object

    Raises:
        FileNotFoundError: If the example file doesn't exist
        SystemExit: If validation fails and exit_on_error is True

    Example:
        >>> from env_guard import validate_env
        >>> result = validate_env()  # Uses .env.example by default
    """
    env_vars = parse_env_example(example_path)
    result = validate_environment(env_vars)

    if not quiet:
        print_validation_result(result, use_rich=use_rich)

    if not result.is_valid and exit_on_error:
        sys.exit(1)

    return result


def validate(
    example_path: str | Path = ".env.example",
    environ: dict[str, str] | None = None,
) -> dict[str, Any]:
    """
    Validate and return typed environment values.

    A more Pythonic alternative that returns the validated values directly
    or raises an exception on failure.

    Args:
        example_path: Path to the .env.example file
        environ: Environment dict to validate (defaults to os.environ)

    Returns:
        Dictionary of variable names to their typed values

    Raises:
        FileNotFoundError: If the example file doesn't exist
        EnvValidationError: If validation fails

    Example:
        >>> from env_guard import validate
        >>> env = validate()
        >>> print(env["PORT"])  # Already an int!
        8000
    """
    env_vars = parse_env_example(example_path)
    result = validate_environment(env_vars, environ)

    if not result.is_valid:
        print_validation_result(result)
        raise EnvValidationError(result)

    return result.validated_values
