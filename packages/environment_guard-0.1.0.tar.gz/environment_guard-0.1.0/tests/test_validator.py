"""Tests for env-guard validator."""

import os
import pytest
from pathlib import Path

from env_guard.validator import (
    infer_type,
    is_optional_marker,
    parse_env_example,
    validate_environment,
    validate_env,
    validate,
    EnvVar,
    InferredType,
    EnvValidationError,
)


class TestInferType:
    """Tests for type inference from example values."""

    def test_infer_integer(self):
        assert infer_type("123") == InferredType.INTEGER
        assert infer_type("0") == InferredType.INTEGER
        assert infer_type("-42") == InferredType.INTEGER

    def test_infer_float(self):
        assert infer_type("3.14") == InferredType.FLOAT
        assert infer_type("0.5") == InferredType.FLOAT
        assert infer_type("-2.5") == InferredType.FLOAT

    def test_infer_boolean(self):
        assert infer_type("true") == InferredType.BOOLEAN
        assert infer_type("false") == InferredType.BOOLEAN
        assert infer_type("True") == InferredType.BOOLEAN
        assert infer_type("FALSE") == InferredType.BOOLEAN
        assert infer_type("yes") == InferredType.BOOLEAN
        assert infer_type("no") == InferredType.BOOLEAN

    def test_infer_string(self):
        assert infer_type("hello") == InferredType.STRING
        assert infer_type("localhost") == InferredType.STRING
        assert infer_type("user@example.com") == InferredType.STRING
        assert infer_type("") == InferredType.STRING
        assert infer_type("123abc") == InferredType.STRING
        assert infer_type("3.14.159") == InferredType.STRING  # Not a valid float


class TestOptionalMarker:
    """Tests for optional marker detection."""

    def test_optional_keyword(self):
        assert is_optional_marker("optional") is True
        assert is_optional_marker("Optional") is True
        assert is_optional_marker("OPTIONAL") is True
        assert is_optional_marker("this is optional") is True

    def test_question_mark(self):
        assert is_optional_marker("?") is True
        assert is_optional_marker("value ?") is True

    def test_not_required(self):
        assert is_optional_marker("not required") is True
        assert is_optional_marker("Not Required") is True

    def test_required_is_not_optional(self):
        assert is_optional_marker("required") is False
        assert is_optional_marker("must be set") is False

    def test_no_comment(self):
        assert is_optional_marker(None) is False
        assert is_optional_marker("") is False


class TestEnvVarValidation:
    """Tests for individual EnvVar validation."""

    def test_validate_integer(self):
        var = EnvVar("PORT", "8000", InferredType.INTEGER)
        assert var.validate_value("3000") == (True, None)
        assert var.validate_value("-1") == (True, None)

        is_valid, error = var.validate_value("abc")
        assert is_valid is False
        assert "expected integer" in error

    def test_validate_float(self):
        var = EnvVar("RATE", "0.5", InferredType.FLOAT)
        assert var.validate_value("3.14") == (True, None)
        assert var.validate_value("-2.5") == (True, None)
        assert var.validate_value("42") == (True, None)  # Ints are valid floats

        is_valid, error = var.validate_value("abc")
        assert is_valid is False
        assert "expected float" in error

    def test_validate_boolean(self):
        var = EnvVar("DEBUG", "true", InferredType.BOOLEAN)
        assert var.validate_value("true") == (True, None)
        assert var.validate_value("false") == (True, None)
        assert var.validate_value("1") == (True, None)
        assert var.validate_value("0") == (True, None)
        assert var.validate_value("yes") == (True, None)
        assert var.validate_value("no") == (True, None)

        is_valid, error = var.validate_value("maybe")
        assert is_valid is False
        assert "expected boolean" in error

    def test_validate_string(self):
        var = EnvVar("HOST", "localhost", InferredType.STRING)
        assert var.validate_value("anything") == (True, None)
        assert var.validate_value("") == (True, None)
        assert var.validate_value("123") == (True, None)


class TestParseEnvExample:
    """Tests for .env.example parsing."""

    def test_parse_simple_file(self, tmp_path):
        env_file = tmp_path / ".env.example"
        env_file.write_text("PORT=8000\nDEBUG=true\nHOST=localhost\n")

        vars = parse_env_example(env_file)

        assert len(vars) == 3

        port_var = next(v for v in vars if v.name == "PORT")
        assert port_var.inferred_type == InferredType.INTEGER
        assert port_var.optional is False

        debug_var = next(v for v in vars if v.name == "DEBUG")
        assert debug_var.inferred_type == InferredType.BOOLEAN

        host_var = next(v for v in vars if v.name == "HOST")
        assert host_var.inferred_type == InferredType.STRING

    def test_parse_with_optional_comment(self, tmp_path):
        env_file = tmp_path / ".env.example"
        env_file.write_text("API_KEY=secret\nOPTIONAL_VAR=value # optional\n")

        vars = parse_env_example(env_file)

        api_key = next(v for v in vars if v.name == "API_KEY")
        assert api_key.optional is False

        optional_var = next(v for v in vars if v.name == "OPTIONAL_VAR")
        assert optional_var.optional is True

    def test_parse_empty_values(self, tmp_path):
        env_file = tmp_path / ".env.example"
        env_file.write_text("EMPTY_VAR=\nNON_EMPTY=value\n")

        vars = parse_env_example(env_file)

        empty_var = next(v for v in vars if v.name == "EMPTY_VAR")
        assert empty_var.inferred_type == InferredType.STRING
        assert empty_var.example_value == ""

    def test_file_not_found(self, tmp_path):
        with pytest.raises(FileNotFoundError):
            parse_env_example(tmp_path / "nonexistent.env")


class TestValidateEnvironment:
    """Tests for environment validation."""

    def test_valid_environment(self):
        env_vars = [
            EnvVar("PORT", "8000", InferredType.INTEGER),
            EnvVar("DEBUG", "true", InferredType.BOOLEAN),
        ]
        environ = {"PORT": "3000", "DEBUG": "false"}

        result = validate_environment(env_vars, environ)

        assert result.is_valid is True
        assert len(result.errors) == 0
        assert result.validated_values["PORT"] == 3000
        assert result.validated_values["DEBUG"] is False

    def test_missing_required_variable(self):
        env_vars = [
            EnvVar("PORT", "8000", InferredType.INTEGER),
            EnvVar("SECRET", "xxx", InferredType.STRING),
        ]
        environ = {"PORT": "3000"}  # Missing SECRET

        result = validate_environment(env_vars, environ)

        assert result.is_valid is False
        assert len(result.errors) == 1
        assert result.errors[0].var_name == "SECRET"
        assert result.errors[0].error_type == "missing"

    def test_missing_optional_variable(self):
        env_vars = [
            EnvVar("PORT", "8000", InferredType.INTEGER),
            EnvVar("OPTIONAL", "default", InferredType.STRING, optional=True),
        ]
        environ = {"PORT": "3000"}  # Missing OPTIONAL, but that's ok

        result = validate_environment(env_vars, environ)

        assert result.is_valid is True
        assert len(result.errors) == 0

    def test_type_mismatch(self):
        env_vars = [
            EnvVar("PORT", "8000", InferredType.INTEGER),
        ]
        environ = {"PORT": "not-a-number"}

        result = validate_environment(env_vars, environ)

        assert result.is_valid is False
        assert len(result.errors) == 1
        assert result.errors[0].error_type == "type_mismatch"
        assert result.errors[0].actual_value == "not-a-number"

    def test_multiple_errors(self):
        env_vars = [
            EnvVar("PORT", "8000", InferredType.INTEGER),
            EnvVar("DEBUG", "true", InferredType.BOOLEAN),
            EnvVar("SECRET", "xxx", InferredType.STRING),
        ]
        environ = {"PORT": "abc", "DEBUG": "maybe"}  # Missing SECRET, wrong types

        result = validate_environment(env_vars, environ)

        assert result.is_valid is False
        assert len(result.errors) == 3  # 2 type errors + 1 missing

    def test_uses_os_environ_by_default(self):
        env_vars = [EnvVar("PATH", "/usr/bin", InferredType.STRING)]

        result = validate_environment(env_vars)

        # PATH should exist in any system
        assert "PATH" in result.validated_values or any(
            e.var_name == "PATH" for e in result.errors
        )


class TestValidateEnv:
    """Tests for the main validate_env function."""

    def test_validate_env_success(self, tmp_path, monkeypatch):
        env_file = tmp_path / ".env.example"
        env_file.write_text("PORT=8000\nDEBUG=true\n")

        monkeypatch.setenv("PORT", "3000")
        monkeypatch.setenv("DEBUG", "false")

        result = validate_env(env_file, exit_on_error=False, quiet=True)

        assert result.is_valid is True

    def test_validate_env_failure_no_exit(self, tmp_path, monkeypatch):
        env_file = tmp_path / ".env.example"
        env_file.write_text("REQUIRED_VAR=value\n")

        # Don't set REQUIRED_VAR
        monkeypatch.delenv("REQUIRED_VAR", raising=False)

        result = validate_env(env_file, exit_on_error=False, quiet=True)

        assert result.is_valid is False

    def test_validate_env_exits_on_failure(self, tmp_path, monkeypatch):
        env_file = tmp_path / ".env.example"
        env_file.write_text("REQUIRED_VAR=value\n")

        monkeypatch.delenv("REQUIRED_VAR", raising=False)

        with pytest.raises(SystemExit) as exc_info:
            validate_env(env_file, exit_on_error=True, quiet=True)

        assert exc_info.value.code == 1


class TestValidate:
    """Tests for the validate() function that returns typed values."""

    def test_validate_returns_typed_values(self, tmp_path, monkeypatch):
        env_file = tmp_path / ".env.example"
        env_file.write_text("PORT=8000\nDEBUG=true\nRATE=0.5\nNAME=test\n")

        monkeypatch.setenv("PORT", "3000")
        monkeypatch.setenv("DEBUG", "yes")
        monkeypatch.setenv("RATE", "1.5")
        monkeypatch.setenv("NAME", "myapp")

        env = validate(env_file)

        assert env["PORT"] == 3000
        assert isinstance(env["PORT"], int)

        assert env["DEBUG"] is True
        assert isinstance(env["DEBUG"], bool)

        assert env["RATE"] == 1.5
        assert isinstance(env["RATE"], float)

        assert env["NAME"] == "myapp"
        assert isinstance(env["NAME"], str)

    def test_validate_raises_on_failure(self, tmp_path, monkeypatch):
        env_file = tmp_path / ".env.example"
        env_file.write_text("REQUIRED=value\n")

        monkeypatch.delenv("REQUIRED", raising=False)

        with pytest.raises(EnvValidationError) as exc_info:
            validate(env_file)

        assert len(exc_info.value.result.errors) == 1


class TestIntegration:
    """Integration tests with real-world scenarios."""

    def test_full_workflow(self, tmp_path, monkeypatch):
        # Create a realistic .env.example
        env_file = tmp_path / ".env.example"
        env_file.write_text("""
# Database configuration
DATABASE_URL=postgresql://localhost/myapp
DATABASE_POOL_SIZE=10

# Server settings
PORT=8000
DEBUG=false

# API Keys
API_KEY=your-api-key-here
OPTIONAL_WEBHOOK_URL=https://example.com/webhook # optional
""")

        # Set environment variables
        monkeypatch.setenv("DATABASE_URL", "postgresql://prod-db/app")
        monkeypatch.setenv("DATABASE_POOL_SIZE", "20")
        monkeypatch.setenv("PORT", "80")
        monkeypatch.setenv("DEBUG", "false")
        monkeypatch.setenv("API_KEY", "real-api-key")
        # Note: OPTIONAL_WEBHOOK_URL is not set

        result = validate_env(env_file, exit_on_error=False, quiet=True)

        assert result.is_valid is True
        assert result.validated_values["DATABASE_POOL_SIZE"] == 20
        assert result.validated_values["PORT"] == 80
        assert result.validated_values["DEBUG"] is False

    def test_fails_on_missing_required(self, tmp_path, monkeypatch):
        env_file = tmp_path / ".env.example"
        env_file.write_text("""
DATABASE_URL=postgresql://localhost/myapp
API_KEY=secret
""")

        monkeypatch.setenv("DATABASE_URL", "postgresql://localhost/test")
        # API_KEY is not set

        result = validate_env(env_file, exit_on_error=False, quiet=True)

        assert result.is_valid is False
        missing_vars = [e.var_name for e in result.errors if e.error_type == "missing"]
        assert "API_KEY" in missing_vars
