"""Tests for envcheck."""
