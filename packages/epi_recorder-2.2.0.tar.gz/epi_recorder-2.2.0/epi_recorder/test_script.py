
print("Hello from EPI Test Script")
import sys
print(f"Python version: {sys.version}")


