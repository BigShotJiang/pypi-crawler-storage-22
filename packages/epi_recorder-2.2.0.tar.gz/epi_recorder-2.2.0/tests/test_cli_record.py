"""Simple script to test CLI record command"""
import time

print("Starting test workflow...")
time.sleep(0.1)

# Simulate some work
result = sum(range(100))
print(f"Calculation result: {result}")

print("Workflow complete!")



 