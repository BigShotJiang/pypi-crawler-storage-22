import sys
import os
from pathlib import Path
import wx
import wx.lib.scrolledpanel as scrolled
import wx.dataview as dv
import json
import numpy as np
import time
from datetime import datetime
from epics import caput, get_pv
from epics.wx import EpicsFunction

from functools import partial

from transformations import superimposition_matrix

from wxutils import (SimpleText, FloatCtrl, MenuItem, Popup, pack,
                     Button, GUIColors, FRAMESTYLE, LEFT, CEN)
DVSTYLE = dv.DV_VERT_RULES|dv.DV_ROW_LINES|dv.DV_MULTIPLE

def add_button(parent, label, size=(-1, -1), action=None):
    "add simple button with bound action"
    thisb = wx.Button(parent, label=label, size=size)
    if hasattr(action, '__call__'):
        parent.Bind(wx.EVT_BUTTON, action, thisb)
    return thisb


from ..instruments import InstrumentDB

from ..utils import MoveToDialog, normalize_pvname, get_pvdesc
from .imageframe import ImageDisplayFrame

ALL_EXP  = wx.ALL|wx.EXPAND
CEN_ALL  = wx.ALIGN_CENTER_HORIZONTAL|wx.ALIGN_CENTER_VERTICAL
LEFT_CEN = wx.ALIGN_LEFT|wx.ALIGN_CENTER_VERTICAL
LEFT_TOP = wx.ALIGN_LEFT|wx.ALIGN_TOP
LEFT_BOT = wx.ALIGN_LEFT|wx.ALIGN_BOTTOM
CEN_TOP  = wx.ALIGN_CENTER_HORIZONTAL|wx.ALIGN_TOP
CEN_BOT  = wx.ALIGN_CENTER_HORIZONTAL|wx.ALIGN_BOTTOM

warn_msg = ' Note: ERASING CANNOT BE UNDONE!! Use "Export Positions" to Save!'

def read_xyz(instdb, name, xyz_stages):
    """
    read XYZ Positions from instrument
    returns dictionary of PositionName: (x, y, z)
    """
    out = {}
    for posname in instdb.get_positions(name, reverse=True):
        vals =  instdb.get_position_values(posname, name)
        out[posname]  = [float(vals[pos]) for pos in xyz_stages]
    return out

def calc_rotmatrix(d1, d2):
    """get rotation matrix to transform coordinates
    from 1st position dict into the 2nd position dict
    """
    labels = []
    d2keys = d2.keys()
    for x in d1.keys():
        if x in d2keys:
            labels.append(x)
    labels.sort()
    if len(labels) < 6:
        print( """Error: need at least 6 saved positions in common to calculate rotation matrix""")
        return None, None, None
    # find mean and stddev of position differences
    xdiff, ydiff, zdiff = [], [], []
    for lab in labels:
        xdiff.append(d2[lab][0] - d1[lab][0])
        ydiff.append(d2[lab][1] - d1[lab][1])
        zdiff.append(d2[lab][2] - d1[lab][2])
    x0, xs = np.array(xdiff).mean(), np.array(xdiff).std()
    y0, ys = np.array(ydiff).mean(), np.array(ydiff).std()
    z0, zs = np.array(zdiff).mean(), np.array(zdiff).std()

    #  remove outliers
    if xs > 1.2 or ys > 1.2 or zs > 1.2:
        u1, u2 = {}, {}
        for i, lab in enumerate(labels):
            p1, p2 = d1[lab], d2[lab]
            dx, dy, dz = p2[0]-p1[0], p2[1]-p1[0], p2[2]-p1[2]
            if abs(dx-x0) < 2*xs and abs(dy-y0) < 2*ys and abs(dz-z0) < 2*zs:
                u1[lab] = p1
                u2[lab] = p2
            else:
                print("skip outlier point ", lab, p1, p2)
        d1, d2 = u1, u2

    print("Calculate Rotation Matrix with Positions:", labels)
    v1 = np.ones((4, len(labels)))
    v2 = np.ones((4, len(labels)))
    for i, label in enumerate(labels):
        v1[0, i] = d1[label][0]
        v1[1, i] = d1[label][1]
        v1[2, i] = d1[label][2]
        v2[0, i] = d2[label][0]
        v2[1, i] = d2[label][1]
        v2[2, i] = d2[label][2]

    # get rotation matrix
    os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'
    return superimposition_matrix(v1, v2, scale=True)


def make_uscope_rotation(instdb,
                         offline_inst='IDE_Microscope',
                         offline_xyz=('13IDE:m1.VAL', '13IDE:m2.VAL', '13IDE:m3.VAL'),
                         online_inst='SampleStage',
                         online_xyz=('13XRM:m6.VAL', '13XRM:m9.VAL', '13XRM:m4.VAL')):
    """
    Calculate and store the rotation maxtrix needed to convert
    positions from the GSECARS offline microscope (OSCAR)
    to the SampleStage in the microprobe station.

    This calculates the rotation matrix based on all position
    names that occur in the Position List for both instruments.

    Note:
        The result is saved as a json dictionary to the config table
    """
    pos_us = read_xyz(instdb, offline_inst, offline_xyz)
    pos_ss = read_xyz(instdb, online_inst, online_xyz)
    # calculate the rotation matrix
    mat_us2ss = calc_rotmatrix(pos_us, pos_ss)
    if mat_us2ss is None:
        return
    #endif
    uscope = instdb.get_instrument(offline_inst)
    sample = instdb.get_instrument(online_inst)

    uname = uscope.name.replace(' ', '_')
    sname = sample.name.replace(' ', '_')
    conf_us2ss = f"CoordTrans:{uname}:{sname}"

    us2ss = {'source': offline_xyz, 'dest': online_xyz,
             'rotmat': mat_us2ss.tolist()}
    instdb.set_config(conf_us2ss, json.dumps(us2ss))

    # calculate the rotation matrix going the other way
    mat_ss2us = calc_rotmatrix(pos_ss, pos_us)
    conf_ss2us = f"CoordTrans:{sname}:{uname}"
    ss2us = {'source': online_xyz, 'dest': offline_xyz,
             'rotmat': mat_ss2us.tolist()}
    instdb.set_config(conf_ss2us, json.dumps(ss2us))

######################

POS_HEADER = '#SampleViewer POSITIONS FILE v1.0'
class ErasePositionsDialog(wx.Frame):
    """ Erase all positions, with check boxes for all"""
    def __init__(self, positions, instname=None, instdb=None):
        wx.Frame.__init__(self, None, -1, title="Select Positions to Erase")
        self.instname = instname
        self.instdb = instdb
        self.build_dialog(positions)

    def build_dialog(self, positions):
        self.positions = positions
        panel = scrolled.ScrolledPanel(self)
        self.checkboxes = {}
        sizer = wx.GridBagSizer(2, 3)
        bkws = dict(size=(95, -1))
        btn_ok   = Button(panel, "Erase Selected",   action=self.onOK, **bkws)
        btn_all  = Button(panel, "Select All",    action=self.onAll, **bkws)
        btn_none = Button(panel, "Select None",   action=self.onNone,  **bkws)

        brow = wx.BoxSizer(wx.HORIZONTAL)
        brow.Add(btn_all ,  0, ALL_EXP|wx.ALIGN_LEFT, 1)
        brow.Add(btn_none,  0, ALL_EXP|wx.ALIGN_LEFT, 1)
        brow.Add(btn_ok ,   0, ALL_EXP|wx.ALIGN_LEFT, 1)

        sizer.Add(SimpleText(panel, ' Note: ERASING POSITIONS CANNOT BE UNDONE!! Use "Export Positions" to Save!',
                            colour=wx.Colour(200, 0, 0)), (0, 0), (1, 2),  LEFT_CEN, 2)
        sizer.Add(SimpleText(panel, ' Use "Export Positions" to Save Positions!',
                            colour=wx.Colour(200, 0, 0)), (1, 0), (1, 2),  LEFT_CEN, 2)

        sizer.Add(brow,  (2, 0), (1, 3),  LEFT_CEN, 2)

        sizer.Add(SimpleText(panel, ' Position Name'), (3, 0), (1, 1),  LEFT_CEN, 2)
        sizer.Add(SimpleText(panel, 'Erase?'),         (3, 1), (1, 1),  LEFT_CEN, 2)
        sizer.Add(SimpleText(panel, ' Position Name'), (3, 2), (1, 1),  LEFT_CEN, 2)
        sizer.Add(SimpleText(panel, 'Erase?'),         (3, 3), (1, 1),  LEFT_CEN, 2)
        sizer.Add(wx.StaticLine(panel, size=(500, 2)), (4, 0), (1, 4),  LEFT_CEN, 2)

        irow = 4
        for ip, pname in enumerate(positions):
            cbox = self.checkboxes[pname] = wx.CheckBox(panel, -1, "")
            cbox.SetValue(True)

            if ip % 2 == 0:
                irow += 1
                icol = 0
            else:
                icol = 2
            sizer.Add(SimpleText(panel, "  %s  "%pname), (irow, icol),   (1, 1),  LEFT_CEN, 2)
            sizer.Add(cbox,                              (irow, icol+1), (1, 1),  LEFT_CEN, 2)
        irow += 1
        sizer.Add(wx.StaticLine(panel, size=(500, 2)), (irow, 0), (1, 4),  LEFT_CEN, 2)

        pack(panel, sizer)
        panel.SetupScrolling()

        mainsizer = wx.BoxSizer(wx.VERTICAL)
        mainsizer.Add(panel, 1,  ALL_EXP|wx.GROW|wx.ALIGN_LEFT, 1)
        pack(self, mainsizer)
        self.SetSize((625, 750))
        self.Raise()
        self.Show()

    def onAll(self, event=None):
        for cbox in self.checkboxes.values():
            cbox.SetValue(True)

    def onNone(self, event=None):
        for cbox in self.checkboxes.values():
            cbox.SetValue(False)

    def onOK(self, event=None):
        if self.instname is not None and self.instdb is not None:
            for pname, cbox in self.checkboxes.items():
                if cbox.IsChecked():
                    self.instdb.remove_position(pname, self.instname)
        self.Destroy()

    def onCancel(self, event=None):
        self.Destroy()

#### Erase Many

class PositionModel(dv.DataViewIndexListModel):
    def __init__(self, instdb, instname='SampleStage'):
        dv.DataViewIndexListModel.__init__(self, 0)
        self.instdb = instdb
        self.instname = instname
        self.data = []
        self.posvals = {}
        self.read_data()

    def read_data(self):
        self.data = []
        for posname in self.instdb.get_positions(self.instname, reverse=True):
            erase = True
            if posname in self.posvals:
                erase = self.posvals[posname]
            self.data.append([posname, erase])
            self.posvals[posname] = erase
        if len(self.data) > 0:
            self.Reset(len(self.data))

    def select_all(self, erase=True):
        for posname in self.posvals:
            self.posvals[posname] = erase
        self.read_data()

    def select_above(self, item):
        itemname = self.GetValue(item, 0)
        val = True
        for posname, _x in self.data:
            self.posvals[posname] = val
            if posname == itemname:
                val = False
        self.read_data()

    def GetColumnType(self, col):
        if col == 1:
            return "bool"
        return "string"

    def GetValueByRow(self, row, col):
        try:
            return self.data[row][col]
        except:
            return None

    def SetValueByRow(self, value, row, col):
        self.data[row][col] = value
        return True

    def GetColumnCount(self):
        try:
            return len(self.data[0])
        except:
            return 0

    def GetCount(self):
        return len(self.data)

    def Compare(self, item1, item2, col, ascending):
        """help for sorting data"""
        if not ascending: # swap sort order?
            item2, item1 = item1, item2
        row1 = self.GetRow(item1)
        row2 = self.GetRow(item2)
        if col == 1:
            return cmp(int(self.data[row1][col]), int(self.data[row2][col]))
        else:
            return cmp(self.data[row1][col], self.data[row2][col])

    def DeleteRows(self, rows):
        rows = list(rows)
        rows.sort(reverse=True)
        for row in rows:
            del self.data[row]
            self.RowDeleted(row)

    def AddRow(self, value):
        self.data.append(value)
        self.RowAppended()


class EraseManyPositionsFrame(wx.Frame) :
    """Erase Many Positions"""
    def __init__(self, instdb, instname, pos=(-1, -1), size=(625, 550)):
        self.instname = instname
        self.instdb = instdb
        self.last_refresh = time.monotonic() - 100.0
        self.Font10=wx.Font(10, wx.SWISS, wx.NORMAL, wx.BOLD, 0, "")
        titlefont = wx.Font(12, wx.SWISS, wx.NORMAL, wx.BOLD, 0, "")

        wx.Frame.__init__(self, None, -1,
                          title="Erase Many Positions",
                          style=FRAMESTYLE, size=size)

        self.dvc = dv.DataViewCtrl(self, style=DVSTYLE)
        self.dvc.SetMinSize((600, 350))

        self.SetFont(self.Font10)
        panel = wx.Panel(self, size=(650, -1))
        panel.SetBackgroundColour(wx.Colour(240, 240, 230))

        self.model = PositionModel(self.instdb, instname=self.instname)
        self.dvc.AssociateModel(self.model)

        sizer = wx.GridBagSizer(3, 2)

        irow = 0
        sizer.Add(add_button(panel, label='Select All', size=(150, -1),
                             action=self.onSelAll),
                  (irow, 0), (1, 1), LEFT, 2)
        sizer.Add(add_button(panel, label='Select None', size=(150, -1),
                             action=self.onSelNone),
                  (irow, 1), (1, 1), LEFT, 2)
        sizer.Add(add_button(panel, label='Select All Above Highlighted', size=(250, -1),
                             action=self.onSelAbove),
                  (irow, 2), (1, 2), LEFT, 2)

        irow += 1
        sizer.Add(add_button(panel, label='Erase Selected', size=(150, -1),
                             action=self.onErase),
                  (irow, 0), (1, 1), LEFT, 2)

        warn = SimpleText(panel, warn_msg, size=(450, -1),
                          colour=wx.Colour(200, 0, 0))

        sizer.Add(warn, (irow, 1), (1, 3),  LEFT_CEN, 2)

        pack(panel, sizer)

        for icol, dat in enumerate((('Position Name',  400, 'text'),
                                    ('Erase? ',        100, 'bool'))):
            label, width, dtype = dat
            method = self.dvc.AppendTextColumn
            kws = {}
            if dtype == 'bool':
                method = self.dvc.AppendToggleColumn
                kws = {'mode': dv.DATAVIEW_CELL_ACTIVATABLE}
            method(label, icol, width=width, **kws)
            c = self.dvc.Columns[icol]
            c.Alignment = wx.ALIGN_LEFT
            c.Sortable = False

        mainsizer = wx.BoxSizer(wx.VERTICAL)
        mainsizer.Add(panel,    0, LEFT|wx.GROW, 1)
        mainsizer.Add(self.dvc, 1, LEFT|wx.GROW, 1)

        pack(self, mainsizer)
        if len(self.model.data) > 0:
            self.dvc.EnsureVisible(self.model.GetItem(0))
        self.Bind(wx.EVT_CLOSE, self.onClose)
        self.Show()
        self.Raise()

    def onClose(self, event=None):
        self.Destroy()

    def onRefresh(self, event=None):
        self.update()

    def onErase(self, event=None):
        for posname, erase in reversed(self.model.data):
            if erase:
                self.instdb.remove_position(posname, self.instname)
        self.update()

    def onSelAll(self, event=None):
        self.model.select_all(True)

    def onSelNone(self, event=None):
        self.model.select_all(False)

    def onSelAbove(self, event=None):
        if self.dvc.HasSelection():
            self.model.select_above(self.dvc.GetSelection())

    def update(self):
        self.model.read_data()
        self.Refresh()
        item0 = None
        try:
            item0 = self.model.GetItem(0)
        except:
            print("Could not get any items")
        if item0 is not None:
            self.dvc.EnsureVisible(self.model.GetItem(0))


class TransferPositionsDialog(wx.Frame):
    """ transfer positions from offline microscope"""
    def __init__(self, offline, instname=None, instdb=None, parent=None):
        wx.Frame.__init__(self, None, -1, title="Copy Positions from Offline Microscope")
        self.offline = offline
        self.instname = instname
        self.parent = parent
        self.instdb = instdb
        self.build_dialog()

    def build_dialog(self):
        posnames  = self.instdb.get_positions(self.offline, reverse=True)
        panel = scrolled.ScrolledPanel(self)
        self.checkboxes = {}
        sizer = wx.GridBagSizer(2, 2)
        sizer.SetVGap(2)
        sizer.SetHGap(3)
        bkws = dict(size=(95, -1))
        btn_ok   = Button(panel, "Copy Selected", action=self.onOK, **bkws)
        btn_all  = Button(panel, "Select All",    action=self.onAll, **bkws)
        btn_none = Button(panel, "Select None",   action=self.onNone,  **bkws)

        brow = wx.BoxSizer(wx.HORIZONTAL)
        brow.Add(btn_all ,  0, ALL_EXP|wx.ALIGN_LEFT, 1)
        brow.Add(btn_none,  0, ALL_EXP|wx.ALIGN_LEFT, 1)
        brow.Add(btn_ok ,   0, ALL_EXP|wx.ALIGN_LEFT, 1)


        self.suffix =  wx.TextCtrl(panel, value="", size=(150, -1))
        self.xoff = FloatCtrl(panel, value=0, precision=3, size=(75, -1))
        self.yoff = FloatCtrl(panel, value=0, precision=3, size=(75, -1))
        self.zoff = FloatCtrl(panel, value=0, precision=3, size=(75, -1))

        irow = 0
        sizer.Add(brow,   (irow, 0), (1, 4),  LEFT_CEN, 2)

        irow += 1
        sizer.Add(SimpleText(panel, ' Add Suffix:'), (irow, 0), (1, 1),  LEFT_CEN, 2)
        sizer.Add(self.suffix, (irow, 1), (1, 3), LEFT_CEN, 2)

        irow += 1
        sizer.Add(SimpleText(panel, 'Offsets X, Y, Z:'), (irow, 0), (1, 1),  LEFT_CEN, 2)
        sizer.Add(self.xoff, (irow, 1), (1, 1),  LEFT_CEN, 2)
        sizer.Add(self.yoff, (irow, 2), (1, 1),  LEFT_CEN, 2)
        sizer.Add(self.zoff, (irow, 3), (1, 1),  LEFT_CEN, 2)

        irow += 1
        sizer.Add(SimpleText(panel, ' Position Name'), (irow, 0), (1, 1),  LEFT_CEN, 2)
        sizer.Add(SimpleText(panel, 'Copy?'),          (irow, 1), (1, 1),  LEFT_CEN, 2)
        sizer.Add(SimpleText(panel, ' Position Name'), (irow, 2), (1, 1),  LEFT_CEN, 2)
        sizer.Add(SimpleText(panel, 'Copy?'),          (irow, 3), (1, 1),  LEFT_CEN, 2)

        irow += 1
        sizer.Add(wx.StaticLine(panel, size=(500, 2)), (irow, 0), (1, 4),  LEFT_CEN, 2)

        for ip, pname in enumerate(posnames):
            cbox = self.checkboxes[pname] = wx.CheckBox(panel, -1, "")
            cbox.SetValue(True)
            if ip % 2 == 0:
                irow += 1
                icol = 0
            else:
                icol = 2
            sizer.Add(SimpleText(panel, f" {pname} "), (irow, icol),   (1, 1),  LEFT_CEN, 2)
            sizer.Add(cbox,                            (irow, icol+1), (1, 1),  LEFT_CEN, 2)
        irow += 1
        sizer.Add(wx.StaticLine(panel, size=(500, 2)), (irow, 0), (1, 4),  LEFT_CEN, 2)

        pack(panel, sizer)
        panel.SetMinSize((700, 550))

        panel.SetupScrolling()

        mainsizer = wx.BoxSizer(wx.VERTICAL)
        mainsizer.Add(panel, 1,  ALL_EXP|wx.GROW|wx.ALIGN_LEFT, 1)
        pack(self, mainsizer)

        self.SetMinSize((700, 550))
        self.Raise()
        self.Show()

    def onAll(self, event=None):
        for cbox in self.checkboxes.values():
            cbox.SetValue(True)

    def onNone(self, event=None):
        for cbox in self.checkboxes.values():
            cbox.SetValue(False)

    def onOK(self, event=None):
        if self.instname is not None and self.instdb is not None:
            suff = self.suffix.GetValue()

            idb = self.instdb
            uscope = idb.get_instrument(self.offline)
            sample = idb.get_instrument(self.instname)

            uname = uscope.name.replace(' ', '_')
            sname = sample.name.replace(' ', '_')
            conf_name = "CoordTrans:%s:%s" % (uname, sname)

            conf = json.loads(idb.get_config(conf_name).notes)
            source_pvs = conf['source']
            dest_pvs = conf['dest']

            rotmat = np.array(conf['rotmat'])
            upos = {}
            for pname, cbox in self.checkboxes.items():
                if cbox.IsChecked():
                    v =  idb.get_position_values(pname, self.offline)
                    upos[pname]  = [v[pvn] for pvn in source_pvs]

            newnames = upos.keys()

            vals = np.ones((4, len(upos)))
            for i, pname in enumerate(newnames):
                vals[0, i] = upos[pname][0]
                vals[1, i] = upos[pname][1]
                vals[2, i] = upos[pname][2]

            # ignore potential problems with multiple OpenMP libraries -
            # apparently some cameras have a static link to this?
            os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'
            pred = np.dot(rotmat, vals)
            os.environ['KMP_DUPLICATE_LIB_OK'] = 'FALSE'

            poslist = idb.get_positions(self.instname, reverse=True)
            saved_temp = None

            if len(poslist) < 1 and self.parent is not None:
                saved_temp = '__tmp__'
                if saved_temp in newnames:
                    saved_temp = '__tmp_a0012AZqspkwx9827nf917+o,ppa+'
                self.parent.onSave(saved_temp)
                time.sleep(3.0)
                poslist = idb.get_positions(self.instname, reverse=True)

            pos0 = idb.get_position_values(poslist[0], self.instname)
            spos = {}
            for pvname in sorted(pos0.keys()):
                spos[pvname] = 0.000

            xoffset = self.xoff.GetValue()
            yoffset = self.yoff.GetValue()
            zoffset = self.zoff.GetValue()
            xpv, ypv, zpv = dest_pvs
            for i, pname in enumerate(newnames):
                spos[xpv] = float(pred[0, i] + xoffset)
                spos[ypv] = float(pred[1, i] + yoffset)
                spos[zpv] = float(pred[2, i] + zoffset)
                nlabel = '%s%s' % (pname, suff)
                idb.save_position(nlabel, self.instname, spos)

            if saved_temp is not None:
                self.parent.onErase(posname=saved_temp, query=False)

        self.Destroy()

    def onCancel(self, event=None):
        self.Destroy()

class PositionPanel(wx.Panel):
    """panel of position lists, with buttons"""

    def __init__(self, parent, viewer, instrument='SampleStage', dbname=None,
                 xyzmotors=None, offline_instrument=None,
                 offline_xyzmotors=None, safe_move=None, **kws):

        wx.Panel.__init__(self, parent, -1, size=(300, 800))
        self.size = (300, 900)
        self.parent = parent
        self.viewer = viewer
        self.instrument = instrument
        if dbname in ('None', '', False, 'false'):
            dbname = None
        self.dbname  = dbname
        self.xyzmotors = xyzmotors
        self.offline_instrument = offline_instrument
        self.offline_xyzmotors = offline_xyzmotors
        self.safe_move = safe_move
        self.image_display = None

        self.pos_name =  wx.TextCtrl(self, value="", size=(300, 25),
                                     style= wx.TE_PROCESS_ENTER)
        self.pos_name.Bind(wx.EVT_TEXT_ENTER, self.onSave)

        tlabel = wx.StaticText(self, label="Save Position: ")

        bkws = dict(size=(55, -1))
        btn_goto  = Button(self, "Go To", action=self.onGo,    **bkws)
        btn_erase = Button(self, "Erase", action=self.onErase, **bkws)
        btn_show  = Button(self, "Show",  action=self.onShow,  **bkws)
        brow = wx.BoxSizer(wx.HORIZONTAL)
        brow.Add(btn_goto,  0, ALL_EXP|wx.ALIGN_LEFT, 1)
        brow.Add(btn_erase, 0, ALL_EXP|wx.ALIGN_LEFT, 1)
        brow.Add(btn_show,  0, ALL_EXP|wx.ALIGN_LEFT, 1)
        # brow.Add(btn_many,  0, ALL_EXP|wx.ALIGN_LEFT, 1)

        self.pos_list  = wx.ListBox(self)
        self.pos_list.SetMinSize((275, 1200))
        self.pos_list.SetBackgroundColour(wx.Colour(253, 253, 250))
        self.pos_list.Bind(wx.EVT_LISTBOX, self.onSelect)
        self.pos_list.Bind(wx.EVT_RIGHT_DOWN, self.onRightClick)

        sizer = wx.BoxSizer(wx.VERTICAL)
        sizer.Add(tlabel,         0, wx.ALIGN_LEFT|wx.ALL)
        sizer.Add(self.pos_name,  0, wx.ALIGN_LEFT|wx.ALL)
        sizer.Add(brow,           0, wx.ALIGN_LEFT|wx.ALL)
        sizer.Add(self.pos_list,  1, wx.ALIGN_CENTER, 3)

        self.pos_list.SetSize((275, 1200))
        pack(self, sizer)
        self.SetSize((275, 1300))

        if 'ESCAN_CREDENTIALS' in os.environ and self.dbname is None:
            self.instdb = InstrumentDB()
        elif Path(self.dbname).exists():
            self.instdb = InstrumentDB(dbname=self.dbname, server='sqlite')
        else:
            raise ValueError("cannot connect to position database")

        self.last_refresh = 0
        self.get_positions_from_db()
        self.timer = wx.Timer(self)
        self.Bind(wx.EVT_TIMER, self.onTimer, self.timer)
        self.timer.Start(2500)

    def onSave(self, event=None, name=None):
        if name is None:
            name = event.GetString().strip()
        if len(name) < 1:
            return

        if name in self.positions and self.viewer.v_replace:
            ret = Popup(self, "Overwrite Position %s?" % name,
                        "Veriry Overwrite Position",
                        style=wx.YES_NO|wx.NO_DEFAULT|wx.ICON_QUESTION)
            if ret != wx.ID_YES:
                return

        imgfile = '%s_micro.jpg' % time.strftime('%b%d_%H%M%S')
        imgfile = os.path.join(self.viewer.imgdir, imgfile)
        tmp_pos = self.viewer.ctrlpanel.read_position()
        # print("Read position ", tmp_pos)
        imgdata, count = None, 0
        if not os.path.exists(self.viewer.imgdir):
            os.makedirs(self.viewer.imgdir)
        while imgdata is None and count <100:
            imgdata = self.viewer.save_image(imgfile)
            if imgdata is None:
                time.sleep(0.05)
            count = count + 1

        imgdata['source'] = 'SampleStage'
        imgdata['data_format'] = 'file'
        imgdata.pop('data')
        notes = json.dumps(imgdata)
        fullpath = os.path.join(os.getcwd(), imgfile)

        im2_fullpath = self.viewer.save_videocam()
        thispos = self.positions[name] = {'image': fullpath,
                                          'image2': im2_fullpath,
                                          'timestamp': time.strftime('%b %d %H:%M:%S'),
                                          'position': tmp_pos,
                                          'notes':  notes}
        self.instdb.save_position(name, self.instrument, tmp_pos,
                                  notes=notes, image=fullpath)
        self.instdb.set_info('sample_position', name)
        self.get_positions_from_db()
        if (self.viewer.pvlog_pos is not None and
            self.viewer.pvlog_pos.connected):
            self.viewer.pvlog_pos.put(name)

        imgfile_exists = False
        t0 = time.time()
        if not imgfile_exists and time.time()-t0 < 10:
            imgfile_exists = os.path.exists(fullpath)
            time.sleep(0.5)
        if imgfile_exists:
            self.viewer.write_message("Saved Position '%s', image in %s" %
                                      (name, imgfile))
        else:
            self.viewer.write_message("COULD NOT SAVE IMAGE FILE!!")
        wx.CallAfter(partial(self.viewer.write_htmllog, name=name, thispos=thispos))
        wx.CallAfter(partial(self.onSelect, event=None, name=name))

    def onShow(self, event):
        posname = self.pos_list.GetStringSelection()
        if posname is None or len(posname) < 1:
            return

        imfile = None
        imagelist = self.viewer.read_imagelog()
        if posname in imagelist:
            imfile, imfile1, tstamp = imagelist[posname]

        # imfile = Path(self.viewer.imgdir, imfile).as_posix()
        if imfile is None:
            print('no image file found for position ', posname)
            return

        try:
            self.image_display.Raise()
            self.image_display.Show()
        except:
            self.image_display = ImageDisplayFrame()
            self.image_display.Raise()
            self.image_display.Show()

        self.image_display.showfile(imfile, title=posname)


    @EpicsFunction
    def onGo(self, event):
        posname = self.pos_list.GetStringSelection()
        if posname is None or len(posname) < 1:
            return

        instname = self.instrument

        # pre-load to make sure the PVs are connected
        posvals = {}
        for name, val in self.instdb.get_position_values(posname, instname).items():
            pvname = normalize_pvname(name)
            get_pv(pvname)
            get_pvdesc(pvname)
            posvals[pvname] =  val


        orig, safe = {}, {}
        if self.safe_move is not None:
            for spv in self.safe_move:
                pvname = spv.get('pv', None)
                step = spv.get('step', None)
                sval = spv.get('value', None)
                if pvname is not None:
                    cur_val = get_pv(pvname).get()
                    orig[pvname] = cur_val
                    if step is not None:
                        safe[pvname] = cur_val + step
                    elif sval is not None:
                        safe[pvname] = sval

        time.sleep(0.005)

        def DoMove(pv_data):
            # do move, maybe moving to "Safe Positions" for some PVs
            # while move is in progress.
            if len(safe) > 0:
                for pvname, sval in safe.items():
                    get_pv(pvname).put(sval, wait=True)

            # start move of sample stage
            for pvname, sval in pv_data.items():
                get_pv(pvname).put(sval)

            if len(orig) > 0:
                # finish move of sample stage before restoring Safe Positions
                for pvname, sval in pv_data.items():
                    get_pv(pvname).put(sval, wait=True)

                # then restore safe positions, in order
                for pvname, sval in orig.items():
                    get_pv(pvname).put(sval, wait=True)

        pvdata = {}
        for pvname, value in posvals.items():
            save_val = str(value)
            curr_val = get_pv(pvname).get(as_string=True)
            desc = get_pvdesc(pvname)
            pvdata[pvname] = (desc, save_val, curr_val)

        if self.viewer.v_move:
            md = MoveToDialog(self, pvdata, instname, posname, callback=DoMove)
            spos = self.viewer.imgpanel.GetScreenPosition()
            md.SetPosition((int(spos[0]+200), int(spos[1]+50)))
            md.Raise()
        else:
            pv_data = {}
            for pvname, data in pvdata.items():
                pv_data[pvname] = data[1]
            DoMove(pv_data)

        # print("SET SAMPLE POSITION ", posname, name)
        self.instdb.set_info('sample_position', posname)
        self.viewer.write_message('moved to %s' % posname)

    def onErase(self, event=None, posname=None, query=True):
        if posname is None:
            posname = self.pos_list.GetStringSelection()
        if posname is None or len(posname) < 1:
            return
        if self.viewer.v_erase and query:
            if wx.ID_YES != Popup(self, "Erase  %s?" % (posname),
                                  'Verify Erase',
                                  style=wx.YES_NO|wx.ICON_QUESTION):
                return

        pos_names = self.pos_list.GetItems()
        ipos = pos_names.index(posname)
        self.instdb.remove_position(posname, self.instrument)
        self.positions.pop(posname)
        self.pos_list.Delete(ipos)
        self.pos_name.Clear()
        self.viewer.write_message('Erased Position %s' % posname)

    def onEraseMany(self, event=None):
        EraseManyPositionsFrame(self.instdb, self.instrument)

    def onMicroscopeTransfer(self, event=None):
        offline =  self.offline_instrument

        if len(offline) > 0 and self.instdb is not None:
            TransferPositionsDialog(offline, instname=self.instrument,
                                    instdb=self.instdb, parent=self)

    def onMicroscopeCalibrate(self, event=None, **kws):
        online = self.instrument
        offline = self.offline_instrument
        if len(online) > 0 and len(offline) > 0 and self.instdb is not None:
            # offline_xyz = self.offline_xyzmotors
            offline_xyz = [s.strip() for s in self.offline_xyzmotors]
            online_xyz  = [s.strip() for s in self.xyzmotors]
            if len(offline_xyz) == 3 and len(online_xyz) == 3:
                # print("calibrate %s to %s " % (offline, online))
                # print(offline_xyz, online_xyz)

                make_uscope_rotation(self.instdb,
                                     offline_inst=offline,
                                     offline_xyz=offline_xyz,
                                     online_inst=online,
                                     online_xyz=online_xyz)


    def onSelect(self, event=None, name=None):
        "Event handler for selecting a named position"
        if name is None:
            name = str(event.GetString().strip())
        if name is None or name not in self.positions:
            return
        self.pos_name.SetValue(name)

    def onRightClick(self, event=None):
        menu = wx.Menu()
        # make basic widgets for popup menu
        for item, name in (('popup_up1', 'Move up'),
                           ('popup_dn1', 'Move down'),
                           ('popup_upall', 'Move to top'),
                           ('popup_dnall', 'Move to bottom')):
            setattr(self, item,  wx.NewId())
            wid = getattr(self, item)
            self.Bind(wx.EVT_MENU, self.onRightEvent, wid)
            menu.Append(wid, name)
        self.PopupMenu(menu)
        menu.Destroy()

    def onRightEvent(self, event=None):
        "popup box event handler"
        idx = self.pos_list.GetSelection()
        if idx < 0: # no item selected
            return
        wid = event.GetId()
        namelist = list(self.positions.keys())[:]
        stmp = {}
        for name in namelist:
            stmp[name] = self.positions[name]

        if wid == self.popup_up1 and idx > 0:
            namelist.insert(idx-1, namelist.pop(idx))
        elif wid == self.popup_dn1 and idx < len(namelist):
            namelist.insert(idx+1, namelist.pop(idx))
        elif wid == self.popup_upall:
            namelist.insert(0, namelist.pop(idx))
        elif wid == self.popup_dnall:
            namelist.append( namelist.pop(idx))

        newpos = {}
        for name in namelist:
            newpos[name]  = stmp[name]
        self.init_positions(newpos)

    def set_positions(self, positions):
        "set the list of position on the left-side panel"
        cur_sel = self.pos_list.GetStringSelection()

        self.pos_list.Clear()
        self.positions = positions
        for name in self.positions:
            self.pos_list.Append(name)
        if cur_sel in self.positions:
            self.pos_list.SetStringSelection(cur_sel)
        self.last_refresh = 0

    def onTimer(self, evt=None):
        inst = self.instdb.get_instrument(self.instrument)
        poslist = self.instdb.get_rows('position', where={'instrument_id':inst.id})
        npos = len(poslist)
        now = time.time()
        if (npos != len(self.posnames) or (now - self.last_refresh) > 900.0):
            self.get_positions_from_db()
            self.last_refresh = now

    def get_positions_from_db(self):
        if self.instdb is None:
            return
        positions = {}
        iname = self.instrument
        self.posnames = self.instdb.get_positions(iname, reverse=True)
        for pname in self.posnames:
            thispos = self.instdb.get_position(pname, iname)
            image = ''
            notes = {}
            mtime = datetime.now()
            if thispos.modify_time is not None:
                mtime = thispos.modify_time
            if thispos.image is not None:
                image = thispos.image
            if thispos.notes is not None:
                notes = thispos.notes
            pdat = {}
            for name, val in self.instdb.get_position_values(pname, iname).items():
                pdat[name] =  val
            positions[pname] = {'position': pdat, 'image': image,
                                'notes': notes, 'modify_time': mtime}
        self.set_positions(positions)

    def SavePositions(self, fname):
        """
        save positions to external file
        """
        out = [POS_HEADER]
        for name, val in self.positions.items():
            pos = []
            notes = val['notes']
            img =  val['image']
            ts = val.get('timestamp', '')
            for pvname, val in val['position'].items():
                pos.append((pvname, val))
            out.append(json.dumps((name, pos, notes, img, ts)))

        out.append('')
        out = '\n'.join(out)
        fout = open(fname, 'w')
        fout.write(out)
        fout.close()

    def LoadPositions(self, fname):
        """
        save positions to external file
        """
        try:
            fh = open(fname, 'r')
            text = fh.readlines()
            fh.close()
        except IOError:
            print( 'IO Error')
            return -1
        header = text[0].replace('\n', '').replace('\r', '')
        if header != POS_HEADER:
            print( 'Bad Header', header)
            return -2
        for line in text[1:]:
            name, pos, notes, img, ts = json.loads(line)
            tmp_pos = dict(pos)

            try:
                self.positions[name] = {'image': img, 'timestamp': ts,
                                        'position': tmp_pos, 'notes': notes}
            except:
                print('Could not set position ', name, tmp_pos)
            try:
                self.instdb.save_position(name, self.instrument, tmp_pos,
                                          notes=json.dumps(notes))
                self.instdb.set_info('sample_position', name)
            except:
                print( 'Could not save position ', name, tmp_pos)
        self.set_positions(self.positions)

        return 0
