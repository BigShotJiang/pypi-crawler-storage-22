
CREATE TABLE slewscanstatus (id  serial primary key, text text, modify_time timestamp without time zone);
