from epicsscan.gui import ScanApp

# from scan_credentials import conn
ScanApp().MainLoop()
