import Rhino
import Grasshopper
from typing import Any, Dict, List, Optional
# Relative import for package structure
try:
    from .models import GHDataItem, GHParam, ComputePayload
except ImportError:
    from models import GHDataItem, GHParam, ComputePayload

def get_compute_type_name(obj: Any) -> str:
    """Returns the C# System Type string required by Compute."""
    if obj is None: return "System.Object"

    # 1. Rhino Geometry
    if hasattr(obj, "GetType"):
        t = obj.GetType()
        if t.Namespace and "Rhino.Geometry" in t.Namespace:
            return t.ToString()

    # 2. Primitives
    if isinstance(obj, bool): return "System.Boolean"
    if isinstance(obj, int): return "System.Int32"
    if isinstance(obj, float): return "System.Double"
    if isinstance(obj, str): return "System.String"
    
    return "System.Object"

def serialize_item(item: Any) -> GHDataItem:
    """Serializes a single raw object into {type, data}."""
    # Ensure we are working with the raw data, not the Goo wrapper
    real_data = item.Value if hasattr(item, "Value") else item
    
    type_str = get_compute_type_name(real_data)
    
    if hasattr(real_data, "ToJSON"):
        opts = Rhino.FileIO.SerializationOptions()
        data_str = real_data.ToJSON(opts)
    else:
        # Lowercase booleans for .NET compatibility
        data_str = str(real_data).lower() if isinstance(real_data, bool) else str(real_data)

    return GHDataItem(type=type_str, data=data_str)

def build_payload(component, param_map: dict = None) -> ComputePayload:
    """
    Acts as the main engine. 
    Accepts ghenv.Component and an optional nickname mapping.
    """
    param_map = param_map or {}
    
    # 1. Get Algorithm Name (Input 0)
    algo_name = "definition.gh"
    try:
        input_0 = component.Params.Input[0]
        # consuming enumerator via list() as per your working standalone
        raw_input_data = list(input_0.VolatileData.AllData(True))
        if len(raw_input_data) > 0:
            val = raw_input_data[0]
            algo_name = val.Value if hasattr(val, "Value") else str(val)
    except Exception:
        pass

    # 2. Build Params list
    payload_params = []
    # Skip input 0 (the def path)
    for i in range(1, component.Params.Input.Count):
        param = component.Params.Input[i]
        nickname = param.NickName
        
        # Mapping logic
        json_name = param_map.get(nickname, nickname)
        
        tree_dict = {}
        gh_structure = param.VolatileData
        
        for path in gh_structure.Paths:
            path_string = path.ToString()
            branch_items = gh_structure.get_Branch(path)
            
            serialized_branch = []
            if branch_items:
                for goo in branch_items:
                    if goo is None: continue
                    serialized_branch.append(serialize_item(goo))
            
            tree_dict[path_string] = serialized_branch
            
        payload_params.append(GHParam(ParamName=json_name, InnerTree=tree_dict))

    return ComputePayload(algo=str(algo_name), values=payload_params)