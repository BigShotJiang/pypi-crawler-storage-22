from typing import Dict, List, Optional
from pydantic import BaseModel

class GHDataItem(BaseModel):
    type: str 
    data: str

class GHParam(BaseModel):
    ParamName: str
    InnerTree: Dict[str, List[GHDataItem]]

class ComputePayload(BaseModel):
    algo: str
    # Moved pointer here so it appears immediately after 'algo'
    pointer: Optional[str] = None
    # 'values' now follows 'pointer'
    values: List[GHParam]