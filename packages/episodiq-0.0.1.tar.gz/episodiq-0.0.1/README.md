# Episodiq

**Ambient episodic memory for AI agents. Zero dependencies.**

Every interaction becomes an episode. Every episode leaves a trace.

Episodiq gives AI agents a threshold of awareness: they know *that* past episodes exist without knowing *what* was found. This epistemic gap prevents hallucination and forces grounded retrieval.

**Coming soon.** Star the repo for updates.

## Features (planned)

- Zero runtime dependencies (stdlib only)
- Framework-agnostic (text in, text out)
- Epistemic guard prevents confabulation from episode titles
- Episode-centric memory (not just tasks — conversations, research, moments)
- Single JSON file storage

## License

MIT
