"""Episodiq: Ambient episodic memory for AI agents.

Every interaction becomes an episode. Every episode leaves a trace.
"""

__version__ = "0.0.1"
