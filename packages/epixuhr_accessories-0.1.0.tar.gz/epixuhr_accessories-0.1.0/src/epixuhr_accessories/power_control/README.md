# A set of utilities related to running the ePixUHR3x2

This was hacked together from a series of very old projects I had...

## Provides
- A GUI for controlling a DP700 Rigol Power Supply
- A command-line interface for the DP700 Rigol Power Supply
- A small command-line utility for a DHCP server
  - This can be used to IP a multi-mode fiber converter box

## Installation

You can install with pip, either from PyPI, or building from source.

### From Source
```bash
# Create a venv
python3 -m venv <path to venv>
source <path to venv>/bin/activate
pip install hatch build
pip install .
```

### From PyPI
```bash
# Create a venv
python3 -m venv <path to venv>
source <path to venv>/bin/activate
pip install epixuhr-accessories
```

## Usage
### Rigol Power Supply

You may need to be added to the `dialout` group. E.g.:

```bash
> sudo gpasswd --add <username> dialout
```

You can then test by opening multiple terminals. In the first, run:

```bash
# Determine which device is the Rigol (maybe /dev/ttyUSB0)
> cat /dev/ttyUSB0
# ... output should come as you run echo commands
```

In the second terminal:
```bash
> echo "*IDN?" > /dev/ttyUSB0
```

You can then launch the GUI with:
```bash
> rigolps-gui
```

Or use the command-line tool:
```bash
> rigolps --help
usage: rigolps [-h] [--port PORT] {status,on,off}

CLI for Rigol Power Supply control

positional arguments:
  {status,on,off}  Command to execute

optional arguments:
  -h, --help       show this help message and exit
  --port PORT      Serial port for the Rigol supply. E.g. `/dev/ttyUSB0`.

```

### DHCP Server

You can use this to IP a specific device, like the mulitmode fiber converter box.

```bash
> dhcp-server
usage: dhcp-server [-h] target_mac assigned_ip gateway_ip interface subnet_mask lease_time

positional arguments:
  target_mac   The MAC address to assign an IP to.
  assigned_ip  The IP address to assign to the target.
  gateway_ip   The gateway IP. For point-to-point this should be the IP on the interface. Even without point-to-point, it can be the IP of the server anyway.
  interface    The interface being used.
  subnet_mask  The subnet mask.
  lease_time   The DHCP lease time in seconds.

optional arguments:
  -h, --help   show this help message and exit

```
