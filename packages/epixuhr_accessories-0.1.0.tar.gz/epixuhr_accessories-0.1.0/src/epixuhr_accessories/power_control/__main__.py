"""Run a GUI to control the Rigol power supply."""

import sys
from typing import Any, List, Tuple

from PyQt5 import QtWidgets

from .gui.mainwindow import MainWindow
from .control.maincontroller import MainController


def main():
    app: QtWidgets.QApplication = QtWidgets.QApplication(sys.argv)

    controller: MainController = MainController()
    namespaces: List[Tuple[str, Any]] = controller.exported_dev_namespaces
    namespaces.append(("m", sys.modules[__name__]))

    mw: MainWindow = MainWindow(extra_namespaces=namespaces)
    mw.showMaximized()

    # Connect all signals/slots for relaying changes
    mw.cmd[str, str, str].connect(controller.distribute_cmd)
    controller.log[str, str].connect(mw.update_log)
    controller.device_state[str, dict].connect(mw.parse_state)
    controller.device_state[str, str].connect(mw.parse_state)
    controller.device_state[str, str, bool].connect(mw.parse_state)
    controller.data.connect(mw.data)

    # Cleanup on shutdown
    app.aboutToQuit.connect(controller.exit)

    # Start application and device communication
    controller.init_devices()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
