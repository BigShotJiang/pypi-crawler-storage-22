"""Base class for communicating with physical devices."""

import time
from typing import Any, ClassVar

from PyQt5.QtCore import QObject
from PyQt5.QtCore import pyqtSignal as Signal


class Device(QObject):
    """The base device class.

    Provides basic interface for interacting with device parameters, logging,
    and using Qt Signals and Slots.
    """

    state: ClassVar[Signal] = Signal((str, dict), (str, str), (str, str, bool))
    """Relays device parameters and values"""

    cmd_result: ClassVar[Signal] = Signal(str)
    """Relays the last message read back from the device."""

    def __init__(self, name="Device"):
        """! The SerialDevice base class initializer."""
        super().__init__()

        self.name: str = name

        self._isconnected: bool = False

        self._cond_vars: dict = {}

        self._comtime: float = 0.1

        self._logs: str = ""

    # Connecting and communicating
    ############################################################################
    def open(self) -> None:
        """Open communication with the physical device."""
        try:
            self._open()
            self._isconnected = True
            self._logs += f"{self.current_time} Opened communication with {self.name}\n"
            self.log(f"Opened communication with: {self.name}", is_high_priority=True)
            self.cmd_result.emit("Succesfully opened communication.")

        except Exception as err:
            self._logs += (
                f"{self.current_time} Unable to open communication with {self.name}: "
                f"{str(err)}"
            )
            self.log(
                f"Unable to open communication: {str(err)}",
                is_high_priority=True,
            )
            self.cmd_result.emit(f"Unable to open communication: {str(err)}")

    def close(self) -> None:
        """Close communication for the physical device if needed"""
        if self._isconnected:
            try:
                self._close()
                self._isconnected = False
                self._logs += (
                    f"{self.current_time} Closed communication with {self.name}.\n"
                )
                self.cmd_result.emit("Succesfully closed serial port.")

            except Exception as err:
                self._logs += (
                    f"{self.current_time} Unable to close communication with "
                    f"{self.name}: {str(err)}"
                )
                self.log(
                    f"Unable to close serial port: {str(err)}",
                    is_high_priority=True,
                )
                self.cmd_result.emit(f"Unable to close serial port: {str(err)}")
        else:
            self._logs += (
                f"{self.current_time} Cannot close communication with {self.name}: "
                "not currently connected.\n"
            )

    def _open(self):
        """Overwritten by subclasses for the actual device specific communication."""
        pass

    def _close(self):
        """Overwritten by subclasses for the actual device specific communication."""
        pass

    # Properties for setting values and retrieving results
    ############################################################################
    @property
    def comtime(self) -> float:
        """Default time to wait after writing a command.

        Returns:
            comtime (float): The wait time in seconds.
        """
        return self._comtime

    @comtime.setter
    def comtime(self, val: float) -> None:
        """Set the defalut time to wait after writing a command.

        Args:
            val (float): The wait time to set.
        """
        try:
            if not isinstance(val, float):
                raise TypeError("Communication wait time must be float.")
            self._comtime = val
            self.cmd_result.emit(f"Communication wait time set to: {val}")

        except Exception as err:
            self.cmd_result.emit(
                f"Communication wait time not changed. Error: {str(err)}"
            )

    def parse_cmd(self, param: str, val: Any):
        """Overwritten by sub-classes to perform actions based on messages from GUI."""
        pass

    def query_state(self) -> None:
        """Perform a device-specific query of the current device status.

        This method has no return value. Instead the associated private method
        updates the internally managed state and then a signal is emitted with
        new parameter value pairs.
        """
        self._query_state()
        self.state[str, dict].emit(self.name, self._cond_vars)

    def _query_state(self):
        pass

    def log(self, msg: str, is_high_priority: bool = False):
        """Log a device-specific message.

        Args:
            msg (str): The message.

            is_high_priority (bool): If True, surface to the top level of GUI.
        """
        if is_high_priority:
            self.state[str, str, bool].emit(f"{self.name}+Logs", msg, is_high_priority)
        else:
            self.state[str, str].emit(f"{self.name}+Logs", msg)

    @property
    def current_time(self):
        """Current time as a formated string."""
        return time.asctime(time.localtime(time.time()))

    # On application close
    ############################################################################
    def exit(self):
        """Perform any shutdown procedures."""
        pass
