"""Power control class for the Rigol DP700.

General information on the power supply can be found at:
https://www.batronix.com/files/Rigol/Labornetzteile/DP700/DP700_UserGuide_EN.pdf

Information on the commands can be found at:
https://www.batronix.com/files/Rigol/Labornetzteile/DP700/DP700_ProgrammingGuide_EN.pdf

Only the DP700 has been used; however, the interface may be similar for other models.

Classes:
    Rigol
"""

from typing import Any, ClassVar

from PyQt5.QtCore import pyqtSignal as Signal
import serial.tools.list_ports
from serial.serialutil import PortNotOpenError

from .serialdevice import SerialDevice


class Rigol(SerialDevice):
    """The class for controlling the Rigol power supply."""

    cmd_result: ClassVar[Signal] = Signal(str)

    cmd_completed: ClassVar[Signal] = Signal()

    def __init__(self, name="Rigol"):
        """The Rigol power supply class initializer."""
        super().__init__(name)
        com_ports = serial.tools.list_ports.comports()
        self.baudrate = 9600
        self.comport = com_ports[2].device  # "/dev/ttyUSB0"

        self._cond_vars = {
            "op_state": "OFF",
            "ch1_current": "0",
            "ch1_voltage": "0",
            "voltage_protection": "OFF",
            "voltage_tripped": "NO",
            "current_protection": "OFF",
            "current_tripped": "NO",
            "ch1_voltage_out": "0",
            "ch1_current_out": "0",
            "ch1_power_out": "0",
        }
        self._first_check = True
        # self.name = name

        # Override the communication time. Seems to need longer.
        self._comtime = 0.2

        self.state.emit(self.name, self._cond_vars)

    # Error checking
    ############################################################################
    def _query_state(self) -> None:
        """Read the full operational status of the power supply."""
        try:
            self._read_current_conditions()
        except PortNotOpenError:
            ...
        try:
            self._check_errors()
            if self._first_check:
                self._first_check = False
        except PortNotOpenError:
            ...

    def _check_errors(self) -> None:
        self._cond_vars["op_errors"] = self.write(":SYSTem:ERRor?", self.comtime)

    def _read_current_conditions(self):
        """Read the Rigol power supply status."""
        self._cond_vars["op_state"] = self.write(":OUTput:STATe? CH1", self.comtime)

        self._cond_vars["ch1_current"] = self.write(":SOURce:CURRent?", self.comtime)

        self._cond_vars["ch1_voltage"] = self.write(":SOURce:VOLTage?", self.comtime)

        self._cond_vars["current_protection"] = self.write(
            ":SOURce:CURRent:PROTection:STATe?", self.comtime
        )

        self._cond_vars["ocp_val"] = self.write(
            ":SOURce:CURRent:PROTection?", self.comtime
        )

        self._cond_vars["voltage_protection"] = self.write(
            ":SOURce:VOLTage:PROTection:STATe?", self.comtime
        )

        self._cond_vars["ovp_val"] = self.write(
            ":SOURce:VOLTage:PROTection?", self.comtime
        )

        self._cond_vars["current_tripped"] = self.write(
            ":SOURce:CURRent:PROTection:TRIPped?", self.comtime
        )

        self._cond_vars["voltage_tripped"] = self.write(
            ":SOURce:VOLTage:PROTection:TRIPped?", self.comtime
        )

        # Returns a csv: voltage,current,power measured at channel output terminal
        measure_all: str = self.write(":MEASure:ALL? CH1", self.comtime)
        voltage_out: str
        current_out: str
        power_out: str
        try:
            voltage_out, current_out, power_out = measure_all.split(",")
        except ValueError:
            # Occassionally may not return anything. Just wait until next update
            voltage_out = "-"
            current_out = "-"
            power_out = "-"
        self._cond_vars["ch1_voltage_out"] = voltage_out
        self._cond_vars["ch1_current_out"] = current_out
        self._cond_vars["ch1_power_out"] = power_out

    def parse_cmd(self, param: str, val: Any):

        # Can use apply as well
        # :APPLy CH1,5,1 ### Voltage==5, Current=1
        # Current:
        #   [:SOURce[<n>]]:CURRent[:LEVel][:IMMediate][:AMPLitude]
        #  :CURRent 3
        try:
            if param == "COM":
                if self._isconnected:
                    self.close()
                self.comport = val
                self.open()

            elif param == "op_state":
                if val == "ON":
                    if self._cond_vars["op_state"] == "ON":
                        self.write(":OUTPut:STATe CH1,OFF", self.comtime)
                        self.cmd_result.emit("Turning power supply output off.")
                    else:
                        self.write(":OUTPut:STATe CH1,ON", self.comtime)
                        self.cmd_result.emit("Turning power supply output on.")
            elif param == "current":
                self.write(f":CURRent {val}", self.comtime)
            elif param == "voltage":
                self.write(f":VOLTage {val}", self.comtime)

            elif param == "ovp_val":
                self.write(f":VOLTage:PROTection {val}", self.comtime)

            elif param == "ocp_val":
                self.write(f":CURRent:PROTection {val}", self.comtime)

            elif param == "voltage_protection":
                if self._cond_vars["voltage_protection"] == "ON":
                    self.write(f":VOLTage:PROTection:STATe OFF", self.comtime)
                elif self._cond_vars["voltage_protection"] == "OFF":
                    self.write(f":VOLTage:PROTection:STATe ON", self.comtime)

            elif param == "current_protection":
                if self._cond_vars["current_protection"] == "ON":
                    self.write(f":CURRent:PROTection:STATe OFF", self.comtime)
                elif self._cond_vars["current_protection"] == "OFF":
                    self.write(f":CURRent:PROTection:STATe ON", self.comtime)
        except PortNotOpenError:
            self.log("Not connected to Rigol.")
            self.cmd_result.emit("Not connected to Rigol.")
        self.cmd_completed.emit()

    # On application close
    ############################################################################
    def exit(self):
        if self._cond_vars["op_state"] == "ON":
            print("........Rigol turning of output.")
            self.write(":OUTPut:STATe CH1,OFF", self.comtime)
        print("........Closing serial communication port.\n")
        self.close()

    # On application open
    ############################################################################
    def _open(self):
        # No special things need to be done at startup
        super()._open()
