"""Contains base class for serial devices.

Implements methods for reading and writing to a serial port.
"""

import sys
import threading
import time
import warnings
from collections import deque
from typing import Optional

from serial import Serial

from .device import Device


class SerialDevice(Device):
    def __init__(self, name: str = "Serial Device"):
        """The SerialDevice base class constructor."""
        super().__init__(name)

        self._sercom: Serial = Serial(timeout=0)

        self._comport: str = ""

        self._isconnected: bool = False

        self._baudrate: int = 115200

        self._write_thread: threading.Thread = threading.Thread(
            target=self._thread_write, daemon=True
        )
        self._write_lock: threading.RLock = threading.RLock()
        self._write_cmd_event: threading.Event = threading.Event()
        self._write_status_event: threading.Event = threading.Event()
        self._thread_continue: bool = True
        self._cmd_queue: deque = deque()
        self._status_queue: deque = deque()

        self._write_thread.start()

    # Connecting and communicating
    ############################################################################
    def _open(self):
        """Opens serial port for communication at defined baud rate.."""
        self._sercom.port = self.comport
        self._sercom.baudrate = self.baudrate
        self._sercom.open()

    def _close(self):
        """Close serial port."""
        self._sercom.close()

    def write(self, cmd: str, waittime: float, queue: str = "status") -> str:
        """Write a command to the serial device.

        Args:
            cmd (str): The serial command.

            waittime (float): Time to wait after writing, in seconds.

        Returns:
            response (str): Response from the device.
        """
        with self._write_lock:
            self._sercom.write(bytes(f"{cmd}\n", encoding="utf8"))
            time.sleep(waittime)
            return self.read().strip()

    def write_new(self, cmd: str, waittime: float, queue: str = "cmd"):
        """Write a command to the serial device.

        Args:
            cmd (str): The serial command.

            waittime (float): Time to wait after writing, in seconds.

        Returns:
            response (str): Response from the device.
        """
        if queue == "cmd":
            self._cmd_queue.append((cmd, waittime))
            self._write_cmd_event.set()
        elif queue == "status":
            self._status_queue.append((cmd, waittime))
            self._write_status_event.set()
        else:
            warnings.warn(
                f"Except one of `cmd` or `status` for queue to write to. Received: {queue}. "
                f"Will not execute {cmd}."
            )
        time.sleep(waittime)
        return self.read().strip()

    def _write(self, cmd: str, waittime: float):
        """Write a command to the serial device.

        Args:
            cmd (str): The serial command.

            waittime (float): Time to wait after writing, in seconds.

        Returns:
            response (str): Response from the device.
        """
        self._sercom.write(bytes(f"{cmd}\n", encoding="utf8"))

    def read(self) -> str:
        """Read from the serial device.

        Returns:
            response (str): Response from the device.
        """
        with self._write_lock:
            return self._sercom.readline().decode("ascii")

    # Threading
    ###########################################################################
    def _thread_write(self):
        while self._thread_continue:
            if not self._isconnected:
                continue
            with self._write_lock:
                cmd: Optional[str] = None
                waittime: Optional[float] = None
                if self._write_cmd_event.is_set():
                    cmd, waittime = self._cmd_queue.popleft()
                    self._write_cmd_event.clear()
                elif self._write_status_event.is_set():
                    cmd, waittime = self._status_queue.popleft()
                    self._write_status_event.clear()

                if cmd is not None and waittime is not None:
                    self._write(cmd, waittime)

    # Properties for setting values and retrieving results
    ############################################################################
    @property
    def baudrate(self) -> int:
        """Communication baud rate.

        Returns:
            baudrate (int): The baud rate.
        """
        return self._baudrate

    @baudrate.setter
    def baudrate(self, val: int) -> None:
        """Set the baud rate.

        Args:
            baudrate (int): The baud rate.
        """
        self._baudrate = val
        self._sercom.baudrate = val
        self.cmd_result.emit(f"Baud rate set to: {val}")

    @property
    def comport(self) -> str:
        """The serial port.

        Returns:
            port (str): The serial port to communicate over.
        """
        return self._comport

    @comport.setter
    def comport(self, val: str) -> None:
        """Set the serial port.

        Args:
            port (str): The serial port to communicate over.
        """
        try:
            if not isinstance(val, str):
                raise TypeError("Communication port must be str.")

            if "win32" in sys.platform:
                if val[:3] != "COM":
                    if val[3] not in range(1, 9):
                        raise ValueError(
                            "Communication port must be in format 'COMX' where X "
                            "is an integer."
                        )

            self._comport = val
            self.cmd_result.emit(f"COM port set to: {val}")
        except Exception as err:
            self.cmd_result.emit(f"COM port not changed. Error: {str(err)}")

    # On application close
    ############################################################################
    def exit(self):
        print("........Closing serial communication port.\n")
        self.close()

        self._thread_continue = False
        self._write_thread.join()
