from typing import Any, ClassVar, Dict, List, Tuple

from PyQt5.QtCore import pyqtSignal as Signal
from PyQt5.QtCore import pyqtSlot as Slot
from PyQt5.QtCore import QThread, QObject

from .devices.rigol import Rigol
from .statusreporter import StatusReporter


class MainController(QObject):
    """The MainController interfaces multiple devices with the GUI."""

    device_state: ClassVar[Signal] = Signal((str, dict), (str, str), (str, str, bool))
    """Emitted with the name of the device, and its settings as the two parameters."""

    data: ClassVar[Signal] = Signal(object)
    """Emitted with new data for plotting/display."""

    log: ClassVar[Signal] = Signal(str, str)
    """Emitted with a message to be recorded on the GUIs log."""

    rigol_cmd: ClassVar[Signal] = Signal(object, object)
    """Emitted with a message with a command for the rigol."""

    def __init__(self):
        """! The MainController class constructor."""
        super().__init__()

        self._rigol = Rigol(name="Rigol")
        self.rigol_cmd.connect(self._rigol.parse_cmd)
        self._rigol.cmd_completed.connect(self._resume_reporter)
        self._rigol.state[str, str].connect(self.device_state[str, str])
        self._rigol.state[str, dict].connect(self.device_state[str, dict])
        self._rigol.state[str, str, bool].connect(self.device_state[str, str, bool])
        self._rigol.cmd_result[str].connect(self._read_result)

        # Thread for running the StatusReporter worker.
        self._status_thread: QThread = QThread()

        # Reporter queries device state in a loop at intervals
        self._reporter = StatusReporter([self._rigol])
        self._reporter.moveToThread(self._status_thread)
        self._status_thread.started.connect(self._reporter.query_state)

        # Cleanup on shutdown
        self._reporter.shutdown.connect(self._status_thread.quit)
        self._reporter.shutdown.connect(self._reporter.deleteLater)
        self._status_thread.finished.connect(self._status_thread.deleteLater)

        # Start the query thread
        self._status_thread.start()

        # Exportable namespaces of devices for GUI console
        self.exported_dev_namespaces: List[Tuple[str, Any]] = [("rigol", self._rigol)]

    def init_devices(self) -> None:
        """Run the startup procedure for the various devices."""
        msg = "Opening communication with Rigol....\n\t\t"
        self._rigol.open()
        msg += self.cmd_result
        self.log.emit("Controller", msg)

    @Slot(str)
    def _read_result(self, msg: str) -> None:
        """Receive the result of the last action taken.

        Args:
            msg (str): The message describing the last result.
        """
        self.cmd_result = msg

    def parse_data(self, type: str, data: Any) -> None:
        """Package data for display handling supported types (images, plots, etc).

        Args:
            type (str): The type of the data.

            data (Any): The data.
        """
        if type == "Image":
            self.data.emit(data)

    @Slot(str, str, str)
    def distribute_cmd(self, device: str, param: str, val: str) -> None:
        """Parse messages from the GUI and pass them to the appropriate devices.

        Args:
            device (str): The device to route to.

            param (str): The parameter affected.

            val (str): The requested value to update `param` to.
        """
        self.log.emit(device, f"Attempting command - {param}: {val}")
        self._pause_reporter()
        if device == "Global":
            self.global_control(param, val)
        elif device == "Rigol":
            self.rigol_cmd.emit(param, val)

    @Slot()
    def _pause_reporter(self):
        """Pause the status reporter worker thread."""
        self._reporter.pause = True

    @Slot()
    def _resume_reporter(self):
        """Resume the status reporter worker thread."""
        self._reporter.pause = False

    def global_control(self, parameter: str, val: str) -> str:
        """Manage device responses to what are currently called "global" parameters.

        These include things such as including COM ports etc.

        No currently doing anything... don't remember what this was supposed to do.

        Args:
            parameter (str): The global parameter.

            val (str): The value to update it to.
        """
        resp: str
        if parameter == "Experiment Type":
            resp = f"Experiment Type changed to: {str(val)}"
        elif parameter == "Rigol COM Port":
            resp = f"Rigol COM Port changed to: {str(val)}"
        else:
            resp = "Unknown change"
        return resp

    def return_device_conditions(self) -> Dict[str, Any]:
        """Method will be deprecated."""
        return self._rigol.cond_vars

    def exit(self):
        """Run the shutdown procedures for each device in turn."""
        self.running = False
        print("Shutting down query thread.")
        print("....Exiting device status thread.\n")
        self._status_thread.quit()
        print("Closing devices connections....")
        print("....Rigol.")
        self._rigol.exit()
