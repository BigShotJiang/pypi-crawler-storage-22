"""!
@brief Definition of the StatusReporter class which is intended as a worker
on a separate thread for reporting device status updates.
"""

import time
from typing import ClassVar, List

from PyQt5.QtCore import QObject
from PyQt5.QtCore import pyqtSignal as Signal

from .devices.device import Device


class StatusReporter(QObject):
    """Worker class for device status querying.

    Executes query functions for every device reference it is passed.
    """

    shutdown: ClassVar[Signal] = Signal()

    def __init__(self, devices: List[Device]):
        """Setup a device status status querier.

        Args:
            devices (List[Device]): A list of device objects to be queried
                for status updates.
        """
        super().__init__()

        self.devices: List[Device] = devices

        self.pause: bool = False

    def query_state(self):
        """Query the device list."""
        while True:
            time.sleep(1)
            for device in self.devices:
                if self.pause:
                    break
                device.query_state()

    def add_device(self, device):
        """Add a new device to the query list.

        Args:
            device (Device): New device to query.
        """
        self.devices.append(device)
        self.pause = False
