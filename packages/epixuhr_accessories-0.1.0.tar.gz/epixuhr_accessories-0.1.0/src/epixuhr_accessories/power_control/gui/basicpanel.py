"""A series of widgets to compose a panel for device controls."""

import re
import time
from typing import Any, ClassVar, Dict, List

from PyQt5 import QtGui
from PyQt5.QtCore import Qt
from pyqtgraph.dockarea import Dock
from PyQt5.QtWidgets import (
    QWidget,
    QGridLayout,
    QLabel,
    QPlainTextEdit,
    QLineEdit,
    QPushButton,
)
from PyQt5.QtCore import pyqtSignal as Signal
from PyQt5.QtCore import pyqtSlot as Slot
import numpy as np
import pyqtgraph as pg


class BasicPanel(Dock):
    expmt_msg: ClassVar[Signal] = Signal(str, str)
    """Emitted for a log message/statusbar update."""

    cmd: ClassVar[Signal] = Signal(str, str, str)
    """Emitted for a parameter change attempt for a device."""

    def __init__(self, *args, **kwargs):
        """The BasicPanel serves as a template class for device specific GUI.

        Basic organizational units are included, as are global parameters like font
        sizes/choices.

        Args:
            *args: Passed along to the Dock widget.

            **kwargs should include:
            - statpath (str): The path to the text file containing the GUI's
                status elements. These elements only display information.
            - ctrlpath (str):  The path to the text file containing the GUI's
                control elements. These elements allow interaction with the
                associated device.
        """
        self.dev_panel_name: str = "Experiment Panel"
        super().__init__(self.dev_panel_name, *args, hideTitle=kwargs["hideTitle"])

        # Search for status variables, titles and such
        self.status_vars = {}
        self.h1font = QtGui.QFont()
        self.h1font.setFamily("Verdana")
        self.h1font.setPointSize(18)

        self.h2font = QtGui.QFont()
        self.h2font.setFamily("Verdana")
        self.h2font.setPointSize(14)

        self.h3font = QtGui.QFont()
        self.h3font.setFamily("Verdana")
        self.h3font.setPointSize(12)

        self.h1_patn = "(?<=^# )(.*)"
        self.h2_patn = "(?<=^## )(.*)"
        self.h3_patn = "(?<=^### )(.*)"

        # Search for control variables in templates
        self.control_vars = {}
        self.cmd_patn = "(?<=\$)(.*)(?=\$)"
        self.param_patn = "(?<=\{)(.*?)(?=\})"

        if "statpath" in kwargs.keys():
            widget = self._status_widgets(kwargs["statpath"])
            self.addWidget(widget, 0, 0, 1, -1)
        else:
            self.addWidget(QLabel("Device Status"), 0, 0, 1, -1)

        if "ctrlpath" in kwargs.keys():
            widget = self._control_widgets(kwargs["ctrlpath"])
            self.addWidget(widget, 2, 0, 1, -1)
        else:
            self.addWidget(QLabel("Device Controls"), 2, 0, 1, -1)

        self.addWidget(self._log_widget(), 4, 0, 1, -1)

    # Parse text to GUI elements
    ############################################################################
    def _status_widgets(self, path: str) -> None:
        """Parse a template for status-type device variables for the GUI,

        Args:
            path (str): Path to the template.
        """
        widget: QWidget = QWidget()
        layout: QGridLayout = QGridLayout()
        row: int = 0
        col: int = 0
        with open(path) as f:
            for line in f:
                s: List[str] = line.split("&")
                substr: str
                for substr in s:
                    text: str
                    label: QLabel
                    if m := re.search(self.h1_patn, substr):
                        text = m.group()
                        label = QLabel(f"{text}")
                        label.setAlignment(Qt.AlignCenter)
                        label.setFont(self.h1font)
                        layout.addWidget(label, row, col, 1, -1)
                        row += 1
                    elif m := re.search(self.h2_patn, substr):
                        text = m.group()
                        label = QLabel(f"{text}")
                        label.setAlignment(Qt.AlignCenter)
                        label.setFont(self.h2font)
                        layout.addWidget(label, row, col, 1, -1)
                        row += 1
                    elif m := re.search(self.h3_patn, substr):
                        text = m.group()
                        label = QLabel(f"{text}")
                        label.setAlignment(Qt.AlignCenter)
                        label.setFont(self.h3font)
                        layout.addWidget(label, row, col, 1, -1)
                        row += 1
                    else:
                        obj: str = substr.lstrip()
                        if "*" in obj:
                            obj = obj.strip()
                            obj = obj[1:]
                            self.status_vars[obj] = QLabel("0")
                            self.status_vars[obj].setAlignment(Qt.AlignLeft)
                            layout.addWidget(self.status_vars[obj], row, col, 1, 1)
                        else:
                            label = QLabel("{}".format(obj))
                            label.setAlignment(Qt.AlignLeft)
                            layout.addWidget(label, row, col, 1, 1)
                    col += 1
                col = 0
                row += 1
        widget.setLayout(layout)
        return widget

    def _control_widgets(self, path: str) -> None:
        """Parse a template for control-type elements for the GUI.

        These issue commands to the device.

        Args:
            path (str): Path to the template.
        """
        widget: QWidget = QWidget()
        layout: QGridLayout = QGridLayout()
        row: int = 0
        col: int = 0
        with open(path) as f:
            for line in f:
                s: List[str] = line.split("&")
                for substr in s:
                    text: str
                    label: QLabel
                    if m := re.search(self.h1_patn, substr):
                        text = m.group()
                        label = QLabel(f"{text}")
                        label.setAlignment(Qt.AlignCenter)
                        label.setFont(self.h1font)
                        layout.addWidget(label, row, col, 1, -1)
                        row += 1
                    elif m := re.search(self.h2_patn, substr):
                        text = m.group()
                        label = QLabel(f"{text}")
                        label.setAlignment(Qt.AlignCenter)
                        label.setFont(self.h2font)
                        layout.addWidget(label, row, col, 1, -1)
                        row += 1
                    elif m := re.search(self.h3_patn, substr):
                        text = m.group()
                        label = QLabel("{}".format(text))
                        label.setAlignment(Qt.AlignCenter)
                        label.setFont(self.h3font)
                        layout.addWidget(label, row, col, 1, -1)
                        row += 1
                    elif m := re.search(self.cmd_patn, substr):
                        cmd: str = m.group()
                        params: List[str] = re.findall(self.param_patn, substr)
                        if cmd == "btn":
                            dispname: str = params[0]
                            varname: str = params[1]
                            funcname: str = params[2]
                            btn: QPushButton = QPushButton(dispname)
                            try:
                                btn.clicked.connect(self.funcs[funcname])
                            except KeyError:
                                print("No function associated with button.")
                            self.control_vars[varname] = btn
                            layout.addWidget(self.control_vars[varname], row, col, 1, 1)
                        elif cmd == "form":
                            varname = params[0]
                            form: QLineEdit = QLineEdit()
                            self.control_vars[varname] = form
                            layout.addWidget(self.control_vars[varname], row, col, 1, 1)
                        elif cmd == "imv":
                            varname = params[0]
                            dataname: str = params[1]
                            imv: pg.ImageView = pg.ImageView()
                            self.control_vars[varname] = imv
                            self.control_vars[dataname] = np.random.random([512, 512])
                            self.control_vars[varname].show()
                            self.control_vars[varname].setImage(
                                self.control_vars[dataname]
                            )
                            layout.addWidget(
                                self.control_vars[varname], row, col, 1, -1
                            )
                        elif cmd == "plot":
                            varname = params[0]
                            dataname = params[1]
                            plot: pg.PlotWidget = pg.PlotWidget()
                            self.control_vars[varname] = plot
                            self.control_vars[dataname] = np.random.random([200])
                            self.control_vars[varname].plot(
                                self.control_vars[dataname], symbol="o"
                            )
                            layout.addWidget(
                                self.control_vars[varname], row, col, 1, -1
                            )
                    else:
                        label = QLabel(f"{substr}")
                        label.setAlignment(Qt.AlignLeft)
                        layout.addWidget(label, row, col, 1, 1)
                    col += 1
                col = 0
                row += 1
        widget.setLayout(layout)
        return widget

    # Methods for updating GUI display - may be overwritten by subclasses
    ############################################################################
    @Slot(dict)
    def update_state(self, params: Dict[str, Any]):
        """Update status widgets.

        Args:
            params (Dict[str, Any]): The parameters to update and the values
                to be displayed.
        """
        for param in params:
            if param in self.status_vars:
                try:
                    self.status_vars[param].setText(f"{params[param]:.3g}")
                except ValueError:
                    self.status_vars[param].setText(f"{params[param]}")
            else:
                self._update_controls(param, params[param])

    def _update_controls(self, param: str, val: Any):
        """Update control widgets.

        This is a device-GUI specific method overloaded by sub-classes.

        It is called by the update_state method to update a single specific widget.

        Args:
            param (Dict[str, Any]): The parameter to update and the values
                to be displayed.

            val (Any): The new value of the parameter.
        """
        pass

    def update_data(self, data: Any):
        """Update displayed data.

        Args:
            data (Any): Data to be displayed.
        """
        pass

    # Logging methods
    ############################################################################
    def _log_widget(self) -> QPlainTextEdit:
        """A textbox widget for device logs.

        Returns:
            log_widget (QPlainTextEdit): A text edit box for the logs.
        """
        self._log_label: QLabel = QLabel("Experiment Logs")
        self._log_label.setAlignment(Qt.AlignCenter)
        self._logs: QPlainTextEdit = QPlainTextEdit()
        return self._logs

    @Slot(str)
    def update_log(self, msg: str) -> None:
        """Insert a message into the log widget.

        Args:
            msg (str): The message to log.
        """
        self._logs.insertPlainText(f"{self.current_time}: {msg}\n")

    @property
    def current_time(self) -> str:
        """A formatted string for the current time.

        Returns:
            time (str): The current time.
        """
        return time.asctime(time.localtime(time.time()))

    def _display_widget(self):
        pass
