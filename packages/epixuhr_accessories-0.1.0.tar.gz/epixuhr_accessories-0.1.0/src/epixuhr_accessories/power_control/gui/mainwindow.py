import os

"""Defines the main GUI window."""

import sys
import time
from typing import Any, ClassVar, Dict, Iterable, List, Optional, Tuple, Union

import serial.tools.list_ports
from PyQt5.QtCore import Qt
from PyQt5.QtCore import pyqtSignal as Signal
from PyQt5.QtCore import pyqtSlot as Slot
from PyQt5.QtWidgets import (
    QMenu,
    QMenuBar,
    QMainWindow,
    QStatusBar,
    QAction,
    QLabel,
    QPlainTextEdit,
    QMessageBox,
)
from pyqtgraph.console import ConsoleWidget
from pyqtgraph.dockarea import DockArea, Dock
from pyqtgraph.parametertree import ParameterTree
from pyqtgraph.parametertree.parameterTypes import ListParameter


from .basicpanel import BasicPanel
from .rigolpanel import RigolPanel


class MainWindow(QMainWindow):
    # Signals for the controller or experiment result connected through __main__
    ############################################################################
    cmd: ClassVar[Signal] = Signal(str, str, str)
    """Emit GUI changes for parsing by the controller."""

    log_changed: ClassVar[Signal] = Signal(str)
    """Emit log changes for parsing by the result file."""

    # Signals for subcomponent GUI elements
    ############################################################################
    data: ClassVar[Signal] = Signal(object)
    """Relays data to Slots on the experiment Docks."""

    rigol_logs: ClassVar[Signal] = Signal(str)
    """Emit Rigol specific logs."""
    rigol_state: ClassVar[Signal] = Signal(dict)
    """Emit Rigol specific status updates."""

    def __init__(self, *, extra_namespaces: Optional[Iterable[Tuple[str, Any]]] = None):
        """The main GUI window.

        The window is populated with the necessary elements for various
        experiment types and loading of data/projects.

        Contains a DockArea, to allow rearrangement of the various GUI modules.

        Args:
            extra_namespaces (Optional[Iterable[Tuple[str, Any]]]): A series of
                name, object pairs to be exported into the Python REPL object. This
                allows for objects to be interacted with programmatically.
        """
        super().__init__()
        self.setWindowTitle("ePixUHR Rigol Power Supply Control")

        self._dock_area: DockArea = DockArea(self)
        self.setCentralWidget(self._dock_area)

        self._statusbar: QStatusBar = QStatusBar(self)
        self.setStatusBar(self._statusbar)
        self._statusbar.showMessage("Starting with default settings.")

        self._current_panel: BasicPanel = BasicPanel(hideTitle=True)

        self._dock_area.addDock(self._current_panel, position="right")
        self._rigol_panel: RigolPanel = RigolPanel(
            hideTitle=True,
            statpath=os.path.join(
                os.path.dirname(__file__), "format", "rigol_status.fmt"
            ),
            ctrlpath=os.path.join(
                os.path.dirname(__file__), "format", "rigol_controls.ctrl"
            ),
        )
        self._rigol_panel.cmd[str, str, str].connect(self.cmd)
        self._rigol_panel.expmt_msg[str, str].connect(self.update_log)
        self.rigol_logs[str].connect(self._rigol_panel.update_log)
        self.rigol_state[dict].connect(self._rigol_panel.update_state)

        # Top navigation in menu form (File... etc)
        self._create_menubar()

        # Create the system explorer tab
        self._create_explorer_dock()

        # Create the console, needs to be created after the egxplorer tab
        self._create_console_dock(extra_namespaces=extra_namespaces)

        # Create the actual experiment tab, must be made after explorer tab
        # self._create_expmt_tab()

        self.update_log("Global", "Starting with default settings.")

    # Setup experiment explorer tab (Experiment parameters, Project hierarchy,
    # logging, etc)
    ############################################################################
    def _create_explorer_dock(self) -> None:
        """Dock containing the remaining widgets."""
        self._explorer_dock: Dock = Dock("Experiment Explorer", hideTitle=True)
        self._dock_area.addDock(self._explorer_dock, position="left")

        # Experiment logs
        self._log_label: QLabel = QLabel("Experiment Logs")
        self._log_label.setAlignment(Qt.AlignCenter)

        self._logs: QPlainTextEdit = QPlainTextEdit()
        self._explorer_dock.addWidget(self._log_label, 3, 0)
        self._explorer_dock.addWidget(self._logs, 4, 0)

        # Create the parameter tree widget and add to dock
        self._create_parameters_widget()
        self._param_label: QLabel = QLabel("Experiment Parameters")
        self._param_label.setAlignment(Qt.AlignCenter)
        self._explorer_dock.addWidget(self._param_label, 1, 0)
        self._explorer_dock.addWidget(self._parameters_widget, 2, 0)

        # Adjust layout parameters
        self._explorer_dock.layout.setVerticalSpacing(10)
        self._explorer_dock.layout.setRowStretch(1, 0)
        self._explorer_dock.layout.setRowStretch(2, 3)
        self._explorer_dock.layout.setRowStretch(4, 3)

    def _create_parameters_widget(self) -> None:
        """Create the widget to display global options for panel selection etc."""
        # Element to hold all the selector elements for more "global" options
        self._parameters_widget = ParameterTree()

        # Element to select the experiment panel to display
        self._expmt_type: ListParameter = ListParameter(
            name="Experiment Type",
            value="------------",
            default="------------",
            limits=[
                "------------",
                "Rigol Controls",
            ],
        )

        # Signal/slot connections for updating the experiment display
        self._expmt_type.sigStateChanged.connect(self.global_changed)
        self._expmt_type.sigStateChanged.connect(self._update_expmt)

        com_ports: List[str] = [
            dev.device for dev in serial.tools.list_ports.comports()
        ]
        # Element to select the COM port for the Rigol
        self._rigol_com: ListParameter = ListParameter(
            name="Rigol COM Port",
            value=com_ports[0],
            default=com_ports[0],
            limits=com_ports,
        )

        # Relevant signals/slots
        self._rigol_com.sigStateChanged.connect(self.global_changed)

        # Add all the parameters to the ParameterTree
        self._parameters_widget.addParameters(self._expmt_type)
        self._parameters_widget.addParameters(self._rigol_com)

    # Create experiment tab, for specific control and image display depending
    # on experiment type
    ############################################################################
    def _create_expmt_tab(self) -> None:
        """Create the tab to display all panel widgets."""
        self._dock_area.addDock(self._current_panel, position="right")
        self._current_panel.expmt_msg[str, str].connect(self.update_log)

        self._rigol_panel.cmd[str, str, str].connect(self.cmd)
        self.data.connect(self._rigol_panel.update_data)
        self.rigol_logs[str].connect(self._rigol_panel.update_log)
        self.rigol_state[dict].connect(self._rigol_panel.update_state)

    def _update_expmt(self, obj: Any, param: Any, val: str) -> None:
        """Update the experiment panel to display.

        Method signature is left over....

        Args:
            obj (BasicPanel): Reference to the GUI element.

            param (str): Parameter changed.

            val (str): Value to select the experiment panel.
        """
        panels: Dict[str, BasicPanel] = {
            "": BasicPanel(hideTitle=True),
            "------------": BasicPanel(hideTitle=True),
            "Rigol Controls": self._rigol_panel,
        }
        self._current_panel.close()
        self._current_panel = panels[str(val)]
        self._dock_area.addDock(self._current_panel, position="right")

    @Slot(str, str)
    @Slot(str, dict)
    @Slot(str, str, bool)
    def parse_state(
        self, device: str, params: Union[str, Dict[str, Any]], surface_log: bool = False
    ) -> None:
        """Update specific devices.

        This slot relays the signal to the appropriate device-specific elements.

        Args:
            device (str): The device to update the state for.

            params (Union[str, Dict[str, Any]]): Either a singal parameter or set
               of parameters depending on what device is being relayed.

            surface_log (bool): Whether to move logs up to the highest GUI levels.
        """
        if device == "Rigol":
            # self.rigol_state[dict].connect(self._rigol_panel.update_state)
            self.rigol_state[dict].emit(params)
        elif device == "Rigol+Logs":
            self.rigol_logs[str].emit(params)
        if surface_log:
            if "+Logs" in device:
                useful_name = device[: -len("+Logs")]
            else:
                useful_name = device
            assert isinstance(params, str)
            self.update_log(useful_name, params)

    # Console tab and related options
    ############################################################################
    def _create_console_dock(
        self, extra_namespaces: Optional[Iterable[Tuple[str, Any]]] = None
    ) -> None:
        """Create a dock and the underlying widget to hold a Python REPL.

        Args:
            extra_namespaces (Optional[Iterable[Tuple[str, object]]]): An iterable
                of Python namespaces (objects) to get exposed in the REPL.
        """
        self._console_dock: Dock = Dock("Console", hideTitle=True)
        self._dock_area.addDock(
            self._console_dock, position="bottom", relativeTo=self._explorer_dock
        )
        self._console_dock.hide()

        namespaces: Dict[str, Any] = {"gui": self}
        if extra_namespaces is not None:
            for item in extra_namespaces:
                namespaces[item[0]] = item[1]

        console_msg: str = (
            "This console provides direct access to the objects that control the GUI "
            "as well as the underlying devices like the Evolution laser.\n"
            "USE AT YOUR OWN RISK. Refer to the user manual, or consult with a SME, "
            "before sending commands to a device. Some commands could cause permanent "
            "damage.\n\n"
            "Available namespaces/objects:\n"
        )
        for namespace in namespaces:
            obj_type = type(namespaces[namespace])
            if hasattr(namespaces[namespace], "name"):
                obj_type = namespaces[namespace].name
            elif "__main__" in str(namespaces[namespace]):
                obj_type = "Global __main__ namespace (access root objects)."
            elif isinstance(namespaces[namespace], QMainWindow):
                obj_type = "Main Window (Instance for GUI)"
            console_msg += f"- {namespace}: {obj_type}\n"

        self._console: ConsoleWidget = ConsoleWidget(
            namespace=namespaces, text=console_msg
        )
        self._console.hide()
        self._showconsole: bool = False

        self._console_dock.addWidget(self._console)

    def _toggleconsole(self) -> None:
        """Toggle the visibility of the Python REPL console."""
        if not self._showconsole:
            self._console_dock.show()
            self._console.show()
            self._showconsole = True
        else:
            self._console_dock.hide()
            self._console.hide()
            self._showconsole = False

    # Emit on change
    ############################################################################
    def global_changed(self, obj: Any, param: str, val: Any) -> None:
        """Emit a signal to be parsed by the controller.

        Args:
            obj (Any): The object the signal is coming from.

            param (str): I forgot...

            val (Any): The value to pass along.
        """
        parameter: str = str(obj).split("'")[1]
        self.update_log("Global", f"{parameter} changed to {str(val)}")
        if "Evolution" in obj.name():
            if "COM" in obj.name():
                self.cmd.emit("Evolution", "COM", str(val))
        else:
            self.cmd.emit("Global", parameter, str(val))

    def expmt_changed(self, device: Any, param: str, val: Any) -> None:
        """Emitted when the experiment is changed.

        Args:
            obj (Any): The object the signal is coming from.

            param (str): The parameter changed.

            val (Any): The value to pass along.
        """
        self.update_log("Global", f"{device} attempting to: {param}")
        self.gui_changed.emit(device, param, val)

    # Logging and status bar
    ############################################################################
    @property
    def statusbar(self):
        return None

    @statusbar.setter
    def statusbar(self, msg: str) -> None:
        """Update the status displayed on the status bar widget.

        Args:
            msg (str): The message to display on the status bar.
        """
        self._statusbar.showMessage(msg)

    @Slot(str, str)
    def update_log(self, name: str, msg: str) -> None:
        """Add text to the log widget.

        Args:
            name (str): The panel or device the message is coming from.

            msg (str): The message to log.
        """
        self._logs.insertPlainText(
            "{}: [{}] {}\n".format(time.asctime(time.localtime(time.time())), name, msg)
        )
        # This updates the statusbar (see property above)
        self.statusbar = msg

    # Menubar options and actions
    ############################################################################
    def _create_menubar(self):
        """Create the menubar and populate it."""
        # Menubar for experiment options. Open/Save, display console etc.
        self._menubar: QMenuBar = QMenuBar()
        self.setMenuBar(self._menubar)
        self._create_filemenu()
        self._menubar.addMenu(self._filemenu)
        self._create_routinesmenu()
        self._menubar.addMenu(self._routinesmenu)

    def _create_filemenu(self):
        """Create the 'File' menu to be added to the menubar."""
        # Contains general options for the experiment and display.
        self._filemenu: QMenu = QMenu("File", self)

        self._open_act: QAction = QAction("Open", self)
        self._open_act.setStatusTip("Open Previous Project")
        self._open_act.triggered.connect(self._openfile)

        # Not currently in use
        self._save_im_act: QAction = QAction("Save Image", self)
        self._save_im_act.setStatusTip("Save Current Image")
        self._save_im_act.triggered.connect(self._saveim)

        # Opens up the console. This is a full Python REPL
        self._console_act: QAction = QAction("&Console", self)
        self._console_act.setToolTip(
            (
                "**WARNING** Read device manuals. "
                "Improper function calls can cause "
                "irreperable damage."
            )
        )
        self._console_act.setStatusTip("Open or Close the Console")
        self._console_act.triggered.connect(self._toggleconsole)
        self._console_act.setShortcut("Alt+C")

        # Add all options to the menu.
        self._filemenu.addAction(self._open_act)
        self._filemenu.addAction(self._save_im_act)
        self._filemenu.addSeparator()
        self._filemenu.addAction(self._console_act)

        # Show mouse hover tool tips.
        self._filemenu.setToolTipsVisible(True)

    def _create_routinesmenu(self):
        """Create the 'Routines' menu to be added to the menubar."""
        self._routinesmenu: QMenu = QMenu("Routines", self)

        self._routinesmenu.setToolTipsVisible(True)

    def _openfile(self):
        """! Open a file. Not currently in use."""
        pass

    def _saveim(self):
        """! Save an image. Not currently in use."""
        pass

    # Application close and cleanup
    ############################################################################
    def closeEvent(self, event: "QEvent"):
        """Shutdown routine.

        On clicking the 'X' for closing a message will appear asking for confirmation.
        Acceptance closes the application and emits signals where needed to allow
        proper shutdown and logging.
        """
        result: QMessageBox = QMessageBox.question(
            self,
            "Confirm Exit",
            "Are you sure you want to exit ?",
            QMessageBox.Yes | QMessageBox.No,
        )
        event.ignore()

        if result == QMessageBox.Yes:
            sys.stdout = sys.__stdout__
            self.update_log("Global", "Shutting down.")
            self.log_changed.emit(self._logs.toPlainText())
            # with open('logs.txt', 'a') as f:
            #     f.write(self._logs.toPlainText())
            event.accept()
