"""Definition of the GUI elements to control Rigol power supplies."""

from typing import Callable, Dict

from .basicpanel import BasicPanel


class RigolPanel(BasicPanel):
    def __init__(self, *args, **kwargs):
        """The RigolPanel contains elements to control a Rigol power supply.

        Basic organizational units are included, as are global parameters like font
        sizes/choices.

        Args:
            *args: Passed along to the Dock widget.

            **kwargs should include:
            - statpath (str): The path to the text file containing the GUI's
                status elements. These elements only display information.
            - ctrlpath (str):  The path to the text file containing the GUI's
                control elements. These elements allow interaction with the
                associated device.
        """
        self.funcs: Dict[str, Callable[[], None]] = {
            "_turnon": self._turnon,
            "_voltage": self._voltage,
            "_current": self._current,
            "_voltage_protection": self._voltage_protection,
            "_set_ovp_val": self._set_ovp_val,
            "_current_protection": self._current_protection,
            "_set_ocp_val": self._set_ocp_val,
        }
        super().__init__(*args, **kwargs)
        self.dev_panel_name = "Evolution"

    def _turnon(self) -> None:
        """Turn on the Rigol power supply."""
        self.cmd.emit("Rigol", "op_state", "ON")

    def _voltage_protection(self) -> None:
        """Turn on/off over-voltage protection."""
        self.cmd.emit("Rigol", "voltage_protection", "")

    def _set_ovp_val(self) -> None:
        """Set the over-voltage protection value."""
        val: str = self.control_vars["ovp_box"].text()
        if val:
            try:
                float_val = float(val)
                if float_val >= 0.0 and float_val <= 55.0:
                    cmd_str = f"{float_val:0.2f}"
                    self.cmd.emit(
                        "Rigol",
                        "ovp_val",
                        cmd_str,
                    )
                    self.expmt_msg.emit(
                        self.dev_panel_name,
                        "Attempting to set over-voltage protection value.",
                    )
                else:
                    self.expmt_msg.emit(
                        self.dev_panel_name,
                        f"Must set voltage between 0.0 and 55.0 V. Provided: {val}",
                    )
            except Exception as err:
                self.expmt_msg.emit(
                    self.dev_panel_name,
                    f"Error encountered in changing over-voltage value: {err}",
                )
        else:
            self.expmt_msg.emit(
                self.dev_panel_name,
                f"Must set voltage between 0.0 and 55.0 V. Provided: {val}",
            )

    def _current_protection(self) -> None:
        """Turn on/off over-current protection."""
        self.cmd.emit("Rigol", "current_protection", "")

    def _set_ocp_val(self) -> None:
        """Set the over-current protection value."""
        val: str = self.control_vars["ocp_box"].text()
        if val:
            try:
                float_val = float(val)
                if float_val >= 0.0 and float_val <= 3.5:
                    cmd_str = f"{float_val:0.2f}"
                    self.cmd.emit(
                        "Rigol",
                        "ocp_val",
                        cmd_str,
                    )
                    self.expmt_msg.emit(
                        self.dev_panel_name,
                        "Attempting to set over-voltage protection value.",
                    )
                else:
                    self.expmt_msg.emit(
                        self.dev_panel_name,
                        f"Must set current between 0.0 and 3.5 A. Provided: {val}",
                    )
            except Exception as err:
                self.expmt_msg.emit(
                    self.dev_panel_name,
                    f"Error encountered in changing over-current value: {err}",
                )
        else:
            self.expmt_msg.emit(
                self.dev_panel_name,
                f"Must set current between 0.0 and 3.5 A. Provided: {val}",
            )

    def _voltage(self) -> None:
        """Change the output voltage setting.

        Accepted values from the GUI elements are between 0 and 48 volts.
        """
        val: str = self.control_vars["voltage_box"].text()
        if val:
            try:
                float_val: float = float(val)
                if float_val >= 0.0 and float_val <= 48.0:
                    cmd_str: str = f"{float_val:0.2f}"
                    self.cmd.emit(
                        "Rigol",
                        "voltage",
                        cmd_str,
                    )
                    self.expmt_msg.emit(
                        self.dev_panel_name,
                        "Attempting to set voltage.",
                    )
                else:
                    self.expmt_msg.emit(
                        self.dev_panel_name,
                        f"Must set voltage between 0.0 and 48.0 V. Provided: {val}",
                    )
            except Exception as err:
                self.expmt_msg.emit(
                    self.dev_panel_name,
                    f"Error encountered in changing output voltage: {err}",
                )
        else:
            self.expmt_msg.emit(
                self.dev_panel_name,
                f"Must set voltage between 0.0 and 48.0 V. Provided: {val}",
            )

    def _current(self) -> None:
        """Change the output current setting.

        Accepted values from the GUI elements are between 0 and 3 Amps.
        """
        val: str = self.control_vars["current_box"].text()
        if val:
            try:
                float_val: float = float(val)
                if float_val >= 0 and float_val <= 3.0:
                    cmd_str: str = f"{float_val:0.2f}"
                    self.cmd.emit(
                        "Rigol",
                        "current",
                        cmd_str,
                    )
                    self.expmt_msg.emit(
                        self.dev_panel_name,
                        "Attempting to set current.",
                    )
                else:
                    self.expmt_msg.emit(
                        self.dev_panel_name,
                        f"Must set current between 0.0 and 3.0 A. Provided: {val}",
                    )
            except Exception as err:
                self.expmt_msg.emit(
                    self.dev_panel_name,
                    f"Error encountered in changing output current: {err}",
                )
        else:
            self.expmt_msg.emit(
                self.dev_panel_name,
                f"Must set current between 0.0 and 3.0 A. Provided: {val}",
            )

    def _update_controls(self, param, val):
        """Update the control widget display.

        Currently only changes power button color to red when supply is on.

        Args:
            param (Dict[str, Any]): The parameter to update and the values
                to be displayed. Only uses `op_state`.

            val (Any): The new value of the parameter.
        """
        if param == "op_state":
            if val == "ON":
                self.control_vars["output_on_btn"].setStyleSheet(
                    "background-color: red"
                )
            else:
                self.control_vars["output_on_btn"].setStyleSheet(
                    "background-color: light gray"
                )
