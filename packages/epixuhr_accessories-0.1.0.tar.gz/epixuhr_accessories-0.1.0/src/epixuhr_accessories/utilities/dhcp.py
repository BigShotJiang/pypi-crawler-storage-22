import argparse
from typing import Optional

from scapy.all import get_if_hwaddr, sendp, sniff, BOOTP, DHCP, Ether, IP, UDP


def run_dhcp_server(
    assigned_ip: str = "10.0.0.10",
    gateway_ip: str = "10.0.0.1",
    iface_name: str = "eno2",
    lease_time: int = 604800,
    subnet_mask: str = "255.255.255.0",
    target_mac: str = "00:0a:35:24:6d:69",
) -> None:
    """Assign an IP address via DHCP to a device with the specified MAC address.

    This script listens for DHCP requests and completes the handshake by sending
    two packets.

    The handshake works as follows:
        1. A DHCP Discover is listened for (comes from the device to be IP'd)
        2. A DHCP Offer is sent in response
        3. A DHCP Request is sent to confirm the offer (comes from the device to be IP'd)
        4. A DHCP Acknwledge is sent to complete the process

    Args:
        assigned_ip (str): The IP address to assign to the device.

        gateway_ip (str): The IP address of the gateway. Can be the server IP.

        iface_name (str): The name of the interface we are using.

        lease_time (int): The duration of the DHCP lease in seconds.

        subnet_mask (str): The subnet mask.

        target_mac (str): The MAC address of the device to IP.
    """

    def send_dhcp_responses(pkt: Ether) -> None:
        ether: Ether = Ether(src=get_if_hwaddr(iface_name), dst=pkt[Ether].src)
        ip: IP = IP(src=gateway_ip, dst="255.255.255.255")
        udp: UDP = UDP(sport=67, dport=68)
        transaction_id: Optional[int] = None
        if pkt.haslayer(BOOTP):
            # Need the transaction ID to send targeted response
            transaction_id = pkt[BOOTP].xid
        else:
            print("No transaction id/ Not BOOTP")
            return
        bootp: BOOTP = BOOTP(
            op=2,
            chaddr=pkt[BOOTP].chaddr,
            yiaddr=assigned_ip,
            siaddr=gateway_ip,
            xid=transaction_id,
        )
        dhcp_offer: DHCP = DHCP(
            options=[
                ("message-type", "offer"),
                ("server_id", gateway_ip),
                ("lease_time", lease_time),
                ("subnet_mask", subnet_mask),
                ("router", gateway_ip),
                ("end"),
            ],
        )
        dhcp_ack: DHCP = DHCP(
            options=[
                ("message-type", "ack"),
                ("server_id", gateway_ip),
                ("lease_time", lease_time),
                ("subnet_mask", subnet_mask),
                ("router", gateway_ip),
                ("end"),
            ],
        )
        if pkt.haslayer(DHCP) and pkt[DHCP].options[0][1] == 1:
            # Found the Discover packet - send an Offer
            offer_pkt: Ether = ether / ip / udp / bootp / dhcp_offer

            # Send DHCP Offer packet
            sendp(offer_pkt, iface=iface_name)
            print(f"Sent DHCP Offer to {target_mac} with IP {assigned_ip}")

        elif pkt.haslayer(DHCP) and pkt[DHCP].options[0][1] == 3:
            # Found the Request packet - send an Acknwledge
            ack_pkt: Ether = ether / ip / udp / bootp / dhcp_ack

            sendp(ack_pkt, iface=iface_name)
            print(f"Sent DHCP Ack to {pkt[Ether].src} with IP {assigned_ip}")

    sniff(
        filter="udp and (port 67 or 68)",
        prn=send_dhcp_responses,
        store=0,
        iface=iface_name,
    )


def main() -> None:
    parser: argparse.ArgumentParser = argparse.ArgumentParser()
    parser.add_argument(
        "target_mac",
        type=str,
        default="00:0a:35:24:6d:69",
        help="The MAC address to assign an IP to.",
    )
    parser.add_argument(
        "assigned_ip",
        type=str,
        default="10.0.0.10",
        help="The IP address to assign to the target.",
    )
    parser.add_argument(
        "gateway_ip",
        type=str,
        default="10.0.0.1",
        help=(
            "The gateway IP. For point-to-point this should be the IP on the interface. "
            "Even without point-to-point, it can be the IP of the server anyway."
        ),
    )
    parser.add_argument(
        "interface",
        type=str,
        default="eno2",
        help="The interface being used.",
    )
    parser.add_argument(
        "subnet_mask",
        type=str,
        default="255.255.255.0",
        help="The subnet mask.",
    )
    parser.add_argument(
        "lease_time",
        type=int,
        default=604800,
        help="The DHCP lease time in seconds.",
    )

    args: argparse.Namespace = parser.parse_args()

    run_dhcp_server(
        assigned_ip=args.assigned_ip,
        gateway_ip=args.gateway_ip,
        iface_name=args.interface,
        lease_time=args.lease_time,
        subnet_mask=args.subnet_mask,
        target_mac=args.target_mac,
    )


if __name__ == "__main__":
    main()
