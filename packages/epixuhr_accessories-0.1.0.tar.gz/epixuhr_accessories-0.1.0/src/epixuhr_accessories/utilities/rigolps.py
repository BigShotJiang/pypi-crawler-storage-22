import argparse
import sys

from PyQt5.QtWidgets import QApplication

from epixuhr_accessories.power_control.control.devices.rigol import Rigol


def main():
    parser = argparse.ArgumentParser(description="CLI for Rigol Power Supply control")
    parser.add_argument(
        "--port",
        type=str,
        help="Serial port for the Rigol supply. E.g. `/dev/ttyUSB0`."
    )
    parser.add_argument(
        "command", choices=["status", "on", "off"], help="Command to execute"
    )

    args: argparse.Namespace = parser.parse_args()

    # May need this since the devices have QObject in the hierarchy...
    app: QApplication = QApplication(sys.argv)

    rigol: Rigol = Rigol()
    if args.port:
        rigol.comport = args.port
    try:
        rigol.open()
        if not rigol._isconnected:
            print(f"Failed to connect to Rigol on {rigol.comport}")
            sys.exit(1)

        if args.command == "status":
            # Direct query as suggested by user
            state: str = rigol.write(":OUTput:STATe? CH1", rigol.comtime)
            print(f"CH1 Power State: {state}")

            # Also get measured values
            measure_all: str = rigol.write(":MEASure:ALL? CH1", rigol.comtime)
            print(f"Measurements (V,A,W): {measure_all}")

        elif args.command == "on":
            rigol.write(":OUTPut:STATe CH1,ON", rigol.comtime)
            print("CH1 turned ON")

        elif args.command == "off":
            rigol.write(":OUTPut:STATe CH1,OFF", rigol.comtime)
            print("CH1 turned OFF")

    finally:
        rigol.close()


if __name__ == "__main__":
    main()
