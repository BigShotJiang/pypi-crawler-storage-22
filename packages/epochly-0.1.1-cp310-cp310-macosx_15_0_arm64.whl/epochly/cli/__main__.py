"""
Entry point for running epochly.cli as a module.
"""

from epochly.cli import cli_main

if __name__ == "__main__":
    cli_main()