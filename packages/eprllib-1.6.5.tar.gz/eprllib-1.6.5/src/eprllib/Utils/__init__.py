"""
Utilities
==========

Work in progress...
"""