"""Erasus version information (set from Git tag at release)."""

__version__ = "0.1.3"
__version_info__ = tuple(int(x) for x in __version__.split(".")[:3] if x.isdigit())
