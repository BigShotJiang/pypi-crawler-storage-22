"""
Entity actions for searching canonical metric and entity definitions service functions.
Auto-generated - DO NOT EDIT.

Provides type-safe action definitions for entity service.
Actual execution happens in the Go backend after syncing.
"""

from typing import Any, Optional, Union

from pydantic import BaseModel

from erdo.template import TemplateString


class BaseActionParams(BaseModel):
    """Base class for all action parameter classes.

    Provides common fields that all actions support:
    - name: The action type identifier
    - step_metadata: Optional configuration for the step created from this action
    """

    name: str
    step_metadata: Optional[Any] = None


class SearchFromQueriesParams(BaseActionParams):
    """Search entity definitions using multiple queries to find relevant metric and entity definitions parameters"""

    name: str = "entity.search_from_queries"  # Action type for roundtrip compatibility
    queries: Optional[Any] = None  # queries parameter
    limit: Optional[Union[int, TemplateString]] = None  # limit parameter


class BatchUpsertParams(BaseActionParams):
    """Batch upsert entities, resource bindings, and relationships extracted by LLM parameters"""

    name: str = "entity.batch_upsert"  # Action type for roundtrip compatibility
    organization_id: Optional[Union[str, TemplateString]] = (
        None  # organization_id parameter
    )
    dataset_id: Optional[Union[str, TemplateString]] = None  # dataset_id parameter
    integration_id: Optional[Union[str, TemplateString]] = (
        None  # integration_id parameter
    )
    items: Optional[Any] = None  # items parameter
    relationships: Optional[Any] = None  # relationships parameter


class SearchFromQueriesResult(BaseModel):
    """Search entity definitions using multiple queries to find relevant metric and entity definitions result type

    Generic result schema for entity.search_from_queries action.
    """

    success: bool = True  # Whether the action was successful

    class Config:
        extra = "allow"  # Allow additional fields dynamically


class BatchUpsertResult(BaseModel):
    """Batch upsert entities, resource bindings, and relationships extracted by LLM result type

    Generic result schema for entity.batch_upsert action.
    """

    success: bool = True  # Whether the action was successful

    class Config:
        extra = "allow"  # Allow additional fields dynamically


def search_from_queries(
    queries: Optional[Any] = None,
    limit: Optional[Union[int, TemplateString]] = None,
    **params: Any,
) -> SearchFromQueriesParams:
    """Search entity definitions using multiple queries to find relevant metric and entity definitions

    Args:
        queries: queries parameter
        limit: limit parameter

    Returns:
        SearchFromQueriesParams: Type-safe parameter object
    """
    param_dict = {
        "queries": queries,
        "limit": limit,
    }
    # Remove None values for optional parameters
    param_dict = {k: v for k, v in param_dict.items() if v is not None}
    param_dict.update(params)
    params_obj = SearchFromQueriesParams(**param_dict)
    return params_obj


def batch_upsert(
    organization_id: Optional[Union[str, TemplateString]] = None,
    dataset_id: Optional[Union[str, TemplateString]] = None,
    integration_id: Optional[Union[str, TemplateString]] = None,
    items: Optional[Any] = None,
    relationships: Optional[Any] = None,
    **params: Any,
) -> BatchUpsertParams:
    """Batch upsert entities, resource bindings, and relationships extracted by LLM

    Args:
        organization_id: organization_id parameter
        dataset_id: dataset_id parameter
        integration_id: integration_id parameter
        items: items parameter
        relationships: relationships parameter

    Returns:
        BatchUpsertParams: Type-safe parameter object
    """
    param_dict = {
        "organization_id": organization_id,
        "dataset_id": dataset_id,
        "integration_id": integration_id,
        "items": items,
        "relationships": relationships,
    }
    # Remove None values for optional parameters
    param_dict = {k: v for k, v in param_dict.items() if v is not None}
    param_dict.update(params)
    params_obj = BatchUpsertParams(**param_dict)
    return params_obj


# Associate parameter classes with their result types
SearchFromQueriesParams._result = SearchFromQueriesResult
BatchUpsertParams._result = BatchUpsertResult
