import numpy as np
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator, FuncFormatter, MultipleLocator
import os
from scipy.stats import shapiro, skew, kurtosis, norm, ks_2samp
from scipy.stats import norm
from sklearn.utils import deprecated
from sympy import ceiling

from .Point import Point, VirtualPoint, MarkerPoint
from .Plane import Plane


class JointAngles:
    def __init__(self):
        self.random_id = np.random.randint(0, 100000000)
        self.is_empty = True
        self.zero_frame_or_angle = [None, None, None]
        self.zero_by_frame_not_angle = False
        self.ergo_name = {'flexion':'flexion', 'abduction':'abduction', 'rotation':'rotation'}

    def set_zero(self, frame_or_angle, by_frame=False):
        '''
        set to None if you don't want to zero the angles
        if by_frame is True, zero_frame_or_angle is a list of 3 frame numbers
        if by_frame is False, zero_frame_or_angle is a list of 3 angles in degrees
        '''
        if frame_or_angle is None:
            output = [None, None, None]
        elif type(frame_or_angle) == list:
            if len(frame_or_angle) != 3:
                raise ValueError('zero frame must be a list of length 3 or a single int')
            output = [np.radians(x) for x in frame_or_angle] if by_frame is False else frame_or_angle
        elif type(frame_or_angle) == int:
            frame_or_angle = np.radians(frame_or_angle) if by_frame is False else frame_or_angle  # convert to radian
            output = [frame_or_angle, frame_or_angle, frame_or_angle]
        self.zero_frame_or_angle = output
        self.zero_by_frame_not_angle = by_frame

    def get_flex_abd(self, coordinate_system, target_vector, plane_seq=['xy', 'xz'], flip_sign=[1, 1]):
        """
        get flexion and abduction angles of a vector in a coordinate system
        plane_seq: ['xy', None]
        """
        if len(plane_seq) != 2:
            raise ValueError('plane_seq must be a list of length 2, with flexion plane first and abduction plane second, fill None if not needed')
        xy_angle, xz_angle, yz_angle = coordinate_system.projection_angles(target_vector)
        output_angles = []
        for plane_id, plane_name in enumerate(plane_seq):
            if plane_name is not None:
                if plane_name == 'xy':
                    output_angle = xy_angle
                elif plane_name == 'xz' or plane_name == 'zx':
                    output_angle = xz_angle
                elif plane_name == 'yz':
                    output_angle = yz_angle
                else:
                    raise ValueError('plane_name must be one of "xy", "xz", "zx", "yz", or None')
                # output_angle = np.abs(output_angle)
                if self.zero_frame_or_angle[plane_id] is not None:
                    if self.zero_by_frame_not_angle:
                        zero_frame_id = self.zero_frame_or_angle[plane_id]
                        zero_angle = output_angle[zero_frame_id]
                    else:  # zero by angle directly
                        zero_angle = self.zero_frame_or_angle[plane_id]
                    output_angle = output_angle - zero_angle
                    # deal with output -pi pi range issue
                    output_angle = np.where(output_angle > np.pi, output_angle - 2 * np.pi, output_angle)
                    output_angle = np.where(output_angle < -np.pi, output_angle + 2 * np.pi, output_angle)
                output_angles.append(output_angle)

            else:
                output_angles.append(None)

        self.flexion = output_angles[0] * flip_sign[0]
        # self.flexion_info = {'plane': plane_seq[0], 'zero_angle': zero_angles[0], 'zero_frame': self.zero_frame[0], 'flip_sign': flip_sign[0]}
        self.abduction = output_angles[1] * flip_sign[1]
        # self.abduction_info = {'plane': plane_seq[1], 'zero_angle': zero_angles[1], 'zero_frame': self.zero_frame[1], 'flip_sign': flip_sign[1]}
        self.is_empty = False
        return output_angles

    def get_rot(self, pt1a, pt1b, pt2a, pt2b, flip_sign=1):
        '''
        get rotation angle between two vectors
        flip_sign: 1 or -1, if the rotation is in the opposite direction
        Example:
        TRUNK_angles.get_rot(LSHOULDER, RSHOULDER, RHIP, LHIP, flip_sign=1)
        '''
        pt1mid = Point.mid_point(pt1a, pt1b)
        pt2mid = Point.mid_point(pt2a, pt2b)
        plane1 = Plane(pt1a, pt1b, pt2mid)
        plane2 = Plane(pt2a, pt2b, pt1mid)  # TODO: this sign is anti-intuitive, should be plane2 = Plane(pt2b, pt2a, pt1mid), fix this and all dependencies
        rotation_angle = Point.angle(plane1.normal_vector.xyz, plane2.normal_vector.xyz)

        rotation_sign = plane2.above_or_below(pt1a)
        rotation_angle = rotation_angle * rotation_sign * flip_sign

        if self.zero_frame_or_angle[2] is not None:
            if self.zero_by_frame_not_angle:
                rotation_zero = rotation_angle[int(self.zero_frame_or_angle[2])]
            else:
                rotation_zero = self.zero_frame_or_angle[2]
            rotation_angle = rotation_angle - rotation_zero
        else:
            rotation_zero = None

        # make plot in -pi to pi range
        rotation_angle = np.where(rotation_angle > np.pi, rotation_angle - 2 * np.pi, rotation_angle)
        rotation_angle = np.where(rotation_angle < -np.pi, rotation_angle + 2 * np.pi, rotation_angle)

        self.rotation = rotation_angle
        self.rotation_info = {'plane': None, 'zero_angle': rotation_zero, 'zero_frame': self.zero_frame_or_angle[2]}
        self.is_empty = False
        return self.rotation

    def zero_by_idx(self, idx):
        """
        idx is 0, 1, 2, corresponding to flexion, abduction, rotation
        usage:
        RKNEE_angles.flexion = RKNEE_angles.zero_by_idx(0)
        """
        angle = self.flexion if idx == 0 else self.abduction if idx == 1 else self.rotation
        this_zero_frame = self.zero_frame_or_angle[idx]
        if this_zero_frame is not None:
            if self.zero_by_frame_not_angle:
                zero_angle = angle[this_zero_frame]
            else:
                zero_angle = this_zero_frame
            output_angle = angle - zero_angle
            output_angle = np.where(output_angle > np.pi, output_angle - 2 * np.pi, output_angle)
            output_angle = np.where(output_angle < -np.pi, output_angle + 2 * np.pi, output_angle)
        else:
            output_angle = angle

        return output_angle

    def output_np(self):
        output_list = []
        if self.flexion is not None:
            output_list.append(self.flexion)
        if self.abduction is not None:
            output_list.append(self.abduction)
        if self.rotation is not None:
            output_list.append(self.rotation)
        return np.array(output_list)

    def plot_angles_old_style(self, joint_name='', alpha=1, linewidth=1, linestyle='-', label=None, frame_range=None, colors=['r', 'g', 'b'], overlay=None):
        """
        plot angles
        overlay: [fig, ax] to overlay on an existing plot
        """
        if self.is_empty:
            # raise ValueError('JointAngles is empty, please set angles first')
            print('JointAngles is empty, please set angles first')
            return None, None
        if frame_range is None:
            if self.flexion is not None:
                frame_range = [0, len(self.flexion)]
            elif self.abduction is not None:
                frame_range = [0, len(self.abduction)]
            elif self.rotation is not None:
                frame_range = [0, len(self.rotation)]
            else:
                raise ValueError('all three angles are None, cannot plot')
        if overlay is None:
            fig, ax = plt.subplots(3, 1, sharex=True)
        else:
            fig, ax = overlay
        angle_names = ['Flexion', 'H-Abduction', 'Rotation']
        for angle_id, angle in enumerate([self.flexion, self.abduction, self.rotation]):
            # horizontal line at zero, pi, and -pi
            ax[angle_id].axhline(0, color='k', linestyle='--', alpha=0.5, linewidth=0.25)
            ax[angle_id].axhline(90, color='k', linestyle='dotted', alpha=0.5, linewidth=0.25)
            ax[angle_id].axhline(180, color='k', linestyle='--', alpha=0.5, linewidth=0.25)
            ax[angle_id].axhline(-90, color='k', linestyle='dotted', alpha=0.5, linewidth=0.25)
            ax[angle_id].axhline(-180, color='k', linestyle='--', alpha=0.5, linewidth=0.25)
            ax[angle_id].yaxis.set_ticks(np.arange(-180, 181, 90))
            ax[angle_id].set_ylabel(f'{angle_names[angle_id]}')
            ax[angle_id].set_xlim(frame_range[0], frame_range[1])  # set xlim
            ax[angle_id].margins(x=0)
            if angle is not None:
                ax[angle_id].plot(angle[0:frame_range[1]] / np.pi * 180, color=colors[angle_id], alpha=alpha, linewidth=linewidth, linestyle=linestyle, label=label)
            else:
                # plot diagonal line crossing through the chart
                ax[angle_id].plot([frame_range[0], frame_range[1]], [-180, 180], color='gray', linewidth=1)

        ax[0].set_title(f'{joint_name} (deg)')
        # plt.show()
        return fig, ax


    def plot_angles(self, render_dir, joint_name='', alpha=1, linewidth=1, linestyle='-', label=None, frame_range=None, frame_range_max=None, skip_first=False,  frame_interval=243,
                             angle_names=['Flexion', 'H-Abduction', 'Rotation'], colors=['r', 'r', 'r'], overlay=None, overlay_colors=['g', 'g', 'g'], overlay_label="GT", fps=20, downsample=1):
        """
        frame_range_max: max number of frames to plot in one image, if None, plot all frames, if int, plot in segments of this length, if list, plot in segments of this length
        """

        if self.is_empty:
            raise ValueError('JointAngles is empty, please set angles first')
        if frame_range is None:
            if self.flexion is not None:
                frame_range = [0, len(self.flexion)]
            elif self.abduction is not None:
                frame_range = [0, len(self.abduction)]
            elif self.rotation is not None:
                frame_range = [0, len(self.rotation)]
            else:
                raise ValueError('all three angles are None, cannot plot')
        if frame_range_max is None:
            frame_ranges = [frame_range]
            seg_len = frame_range[1] - frame_range[0]
        elif type(frame_range_max) == int:
            frame_ranges = []
            seg_len = np.floor((frame_range[1] - frame_range[0]) / frame_range_max).astype(int)
            for seg_id in range(seg_len):
                frame_ranges.append([frame_range[0] + seg_id * frame_range_max, frame_range[0] + (seg_id + 1) * frame_range_max])
                                     # min(frame_range[0] + (seg_id + 1) * frame_range_max, frame_range[1])])
        elif type(frame_range_max) == list:
            frame_ranges = []
            left = 0
            if skip_first:
                left = frame_range_max[0]
                frame_range_max = frame_range_max[1:]
            for segment_frame_len in frame_range_max:
                right = left + segment_frame_len
                frame_ranges.append([left, right])
                left = right
            seg_len = len(frame_range_max)
        else:
            raise ValueError(f'frame_range_max must be None, int or list, not {type(frame_range_max)}')
        for seg_id, frame_range in enumerate(frame_ranges):
            print(f'[{seg_id}/{seg_len}] Saving {joint_name} angle frames to {render_dir}')

            fig, ax = plt.subplots(3, 1, sharex=True, figsize=(9, 14))

            # --- (2) larger tick label font size on all subplots
            for a in ax:
                a.tick_params(axis='x', which='both', labelbottom=True, labelsize=16)
                a.tick_params(axis='y', which='both', labelsize=16)

            # segment length for this frame_range (fixes your undefined data_length)
            data_length = frame_range[1] - frame_range[0]
            seconds_total = data_length / fps

            # Human-friendly intervals (seconds)
            nice_intervals = np.array([1, 2, 5, 10, 20, 30, 50, 100, 150, 200])

            # choose the smallest interval that gives <= ~10 ticks
            valid = nice_intervals[seconds_total / nice_intervals <= 10]
            tick_interval_sec = valid[0] if len(valid) > 0 else nice_intervals[-1]
            tick_interval_frames = tick_interval_sec * fps

            # x-axis formatter: restart at 0 for each segment
            def seconds_formatter(x, pos):
                return f'{(x - frame_range[0]) / fps:.0f}'

            for angle_id, angle in enumerate([self.flexion, self.abduction, self.rotation]):
                # vertical interval lines
                for frame_243 in range(frame_range[0], frame_range[1], frame_interval):
                    ax[angle_id].axvline(frame_243, color='darkblue', linestyle='-', alpha=0.75, linewidth=0.5)

                # horizontal reference lines
                ax[angle_id].axhline(0, color='k', linestyle='-', alpha=0.75, linewidth=1)
                ax[angle_id].axhline(90, color='k', linestyle='--', alpha=0.5, linewidth=0.75)
                ax[angle_id].axhline(180, color='k', linestyle='--', alpha=0.5, linewidth=0.75)
                ax[angle_id].axhline(-90, color='k', linestyle='--', alpha=0.5, linewidth=0.75)
                ax[angle_id].axhline(-180, color='k', linestyle='--', alpha=0.5, linewidth=0.75)
                ax[angle_id].axhline(-45, color='k', linestyle='dotted', alpha=0.5, linewidth=0.75)
                ax[angle_id].axhline(-135, color='k', linestyle='dotted', alpha=0.5, linewidth=0.75)
                ax[angle_id].axhline(45, color='k', linestyle='dotted', alpha=0.5, linewidth=0.75)
                ax[angle_id].axhline(135, color='k', linestyle='dotted', alpha=0.5, linewidth=0.75)



                ax[angle_id].yaxis.set_ticks(np.arange(-180, 181, 90))
                ax[angle_id].set_xlim(frame_range[0], frame_range[1])
                ax[angle_id].set_ylabel(f'{angle_names[angle_id].capitalize()}', fontsize=26)
                ax[angle_id].margins(x=0)

                if angle is not None:
                    angle_deg = angle / np.pi * 180
                    x = np.arange(len(angle_deg))

                    ax[angle_id].fill_between(
                        x,
                        angle_deg,
                        0,  # baseline
                        color='red',
                        alpha=0.15,
                        zorder=1
                    )
                    # --- (4) shade NaN blocks dark gray over the full plot height
                    seg = angle_deg[frame_range[0]:frame_range[1]]
                    nan_mask = np.isnan(seg)
                    if nan_mask.any():
                        # find contiguous NaN runs [s, e)
                        nan_idx = np.flatnonzero(nan_mask)
                        # split into runs where gaps > 1
                        breaks = np.where(np.diff(nan_idx) > 1)[0]
                        run_starts = np.r_[nan_idx[0], nan_idx[breaks + 1]]
                        run_ends = np.r_[nan_idx[breaks] + 1, nan_idx[-1] + 1]
                        for s, e in zip(run_starts, run_ends):
                            ax[angle_id].axvspan(
                                frame_range[0] + s,
                                frame_range[0] + e,
                                color='0.2',  # dark gray
                                alpha=0.4,
                                zorder=0
                            )

                    # overlay behind
                    if overlay is not None:
                        sub_angle_general_names = ['flexion', 'abduction', 'rotation']
                        overlay_angle = getattr(overlay, sub_angle_general_names[angle_id])
                        overlay_deg = overlay_angle / np.pi * 180
                        ax[angle_id].plot(
                            overlay_deg,
                            color=overlay_colors[angle_id],
                            alpha=alpha,
                            linewidth=linewidth,  # keep overlay thinner
                            linestyle=linestyle,
                            zorder=2
                        )

                    # --- (3) thicker main data plot (and stop washing it out)
                    ax[angle_id].plot(
                        angle_deg,
                        color=colors[angle_id],
                        alpha=alpha,
                        linewidth=max(2.5, linewidth * 2.0),
                        linestyle=linestyle,
                        zorder=3
                    )
                else:
                    ax[angle_id].plot([frame_range[0], frame_range[1]], [-180, 180], color='gray', linewidth=1)

            # --- (1) more space between title and plot: use suptitle + tight_layout rect
            fig.suptitle(f'{joint_name.capitalize()} (deg)', fontsize=30, weight='bold')

            ax[2].xaxis.set_major_formatter(FuncFormatter(seconds_formatter))
            ax[2].xaxis.set_major_locator(MultipleLocator(tick_interval_frames))
            ax[2].set_xlabel('Time (s)', fontsize=26)

            xdata = ax[2].lines[0].get_xdata()
            # print("xdata[0:5] =", xdata[:5])
            # print("xdata step approx =", np.median(np.diff(xdata[:200])))
            # print("xlim =", ax[2].get_xlim())
            # print("fps used =", fps, "downsample =", downsample)

            # leave room at top for suptitle
            plt.tight_layout(pad=1.0)

            if not os.path.exists(render_dir):
                os.makedirs(render_dir)

            plt.savefig(os.path.join(render_dir, f'{joint_name}_{seg_id:03d}_{frame_range[0]}-{frame_range[1]}.png'))
            plt.close(fig)
                # if not os.path.exists(render_dir):
                #     os.makedirs(render_dir)
                # if False:
                #     plt.legend(
                #         loc='upper right',
                #         fontsize=12,
                #         handlelength=3,
                #         handleheight=2,
                #         prop={'weight': 'bold'},
                #         frameon=True,  # Enable the frame
                #         facecolor='white',  # Set background color to white
                #         framealpha=1,  # Make the background fully opaque
                #         edgecolor='black'  # Set the border color
                #     )
                #     raise NotImplementedError('Intentional stop, get legend pic in the first frame')



    def plot_angles_by_frame(self, render_dir, joint_name='', alpha=1, linewidth=1, linestyle='-', label=None, frame_range=None, frame_range_max=None, skip_first=False,  frame_interval=243,
                             angle_names=['Flexion', 'H-Abduction', 'Rotation'], colors=['r', 'r', 'r'], overlay=None, overlay_colors=['g', 'g', 'g'], overlay_label="GT", fps=20, x_tick_s=15, downsample=1):
        """
        frame_range_max: max number of frames to plot in one image, if None, plot all frames, if int, plot in segments of this length, if list, plot in segments of this length
        """

        if self.is_empty:
            raise ValueError('JointAngles is empty, please set angles first')
        if frame_range is None:
            if self.flexion is not None:
                frame_range = [0, len(self.flexion)]
            elif self.abduction is not None:
                frame_range = [0, len(self.abduction)]
            elif self.rotation is not None:
                frame_range = [0, len(self.rotation)]
            else:
                raise ValueError('all three angles are None, cannot plot')
        if frame_range_max is None:
            frame_ranges = [frame_range]
            seg_len = frame_range[1] - frame_range[0]
        elif type(frame_range_max) == int:
            frame_ranges = []
            seg_len = np.floor((frame_range[1] - frame_range[0]) / frame_range_max).astype(int)
            for seg_id in range(seg_len):
                frame_ranges.append([frame_range[0] + seg_id * frame_range_max, frame_range[0] + (seg_id + 1) * frame_range_max])
                                     # min(frame_range[0] + (seg_id + 1) * frame_range_max, frame_range[1])])
        elif type(frame_range_max) == list:
            frame_ranges = []
            left = 0
            if skip_first:
                left = frame_range_max[0]
                frame_range_max = frame_range_max[1:]
            for segment_frame_len in frame_range_max:
                right = left + segment_frame_len
                frame_ranges.append([left, right])
                left = right
            seg_len = len(frame_range_max)
        else:
            raise ValueError(f'frame_range_max must be None, int or list, not {type(frame_range_max)}')
        for seg_id, frame_range in enumerate(frame_ranges):
            print(f'[{seg_id}/{seg_len}] Saving {joint_name} angle frames to {render_dir}')
            for frame_id in range(frame_range[0], frame_range[1]):
                if frame_id % downsample != 0:
                    continue
                fig, ax = plt.subplots(3, 1, sharex=True)
                for angle_id, angle in enumerate([self.flexion, self.abduction, self.rotation]):
                    print(f'frame {frame_id}/{frame_range[1]}', end='\r')
                    # horizontal line at zero, pi, and -pi
                    ax[angle_id].axhline(0, color='k', linestyle='--', alpha=0.5, linewidth=0.25)
                    ax[angle_id].axhline(90, color='k', linestyle='dotted', alpha=0.5, linewidth=0.25)
                    ax[angle_id].axhline(180, color='k', linestyle='--', alpha=0.5, linewidth=0.25)
                    ax[angle_id].axhline(-90, color='k', linestyle='dotted', alpha=0.5, linewidth=0.25)
                    ax[angle_id].axhline(-180, color='k', linestyle='--', alpha=0.5, linewidth=0.25)

                    # Draw vertical lines every 243 frames
                    for frame_243 in range(frame_range[0], frame_range[1], frame_interval):
                        ax[angle_id].axvline(frame_243, color='darkblue', linestyle='dotted', alpha=0.75, linewidth=0.1)

                    ax[angle_id].yaxis.set_ticks(np.arange(-180, 181, 90))
                    ax[angle_id].set_xlim(frame_range[0], frame_range[1])  # set xlim
                    ax[angle_id].axvline(frame_id, color='k', linestyle='--', alpha=0.5, linewidth=0.25)  # vertical line at current frame
                    # a dot with value at current frame
                    ax[angle_id].set_ylabel(f'{angle_names[angle_id].capitalize()}', fontsize=16)
                    ax[angle_id].margins(x=0)
                    if angle is not None:
                        if overlay is not None:  # overlay GT plots, put behind
                            sub_angle_general_names = ['flexion', 'abduction', 'rotation']
                            overlay_angle = getattr(overlay, sub_angle_general_names[angle_id])
                            overlay_color = overlay_colors[angle_id]
                            ax[angle_id].plot(overlay_angle[0:frame_id + 1] / np.pi * 180, color=overlay_color, alpha=alpha, linewidth=linewidth, linestyle=linestyle, label=overlay_label)
                            ax[angle_id].plot(overlay_angle / np.pi * 180, color=overlay_color, alpha=alpha*0.2, linewidth=linewidth, linestyle=linestyle)
                            ax[angle_id].plot(frame_id, overlay_angle[frame_id] / np.pi * 180, color=overlay_color, marker='o', markersize=3)

                        ax[angle_id].plot(angle[0:frame_id + 1] / np.pi * 180, color=colors[angle_id], alpha=alpha, linewidth=linewidth, linestyle=linestyle, label=label)
                        ax[angle_id].plot(angle / np.pi * 180, color=colors[angle_id], alpha=alpha*0.2, linewidth=linewidth, linestyle=linestyle)
                        ax[angle_id].plot(frame_id, angle[frame_id] / np.pi * 180, color=colors[angle_id], marker='o', markersize=5)  # a dot with value at current frame
                        if not np.isnan(angle[frame_id]):
                            ax[angle_id].text(frame_id, angle[frame_id] / np.pi * 180, f'{angle[frame_id] / np.pi * 180:.1f}', fontsize=12, horizontalalignment='left',
                                              verticalalignment='bottom')  # add text of current angle value

                    else:
                        ax[angle_id].plot([frame_range[0], frame_range[1]], [-180, 180], color='gray', linewidth=1)  # plot diagonal line crossing through the chart

                ax[0].set_title(f'{joint_name.capitalize()} (deg)', fontsize=18, weight='bold')

                def seconds_formatter(x, pos):
                    return f'{x / fps:.0f}'

                data_length = frame_range[1] - frame_range[0]
                tick_interval = max(1, data_length // 12)  # Adjust the interval to have ~10 ticks

                ax[2].xaxis.set_major_formatter(FuncFormatter(seconds_formatter))
                ax[2].xaxis.set_major_locator(MultipleLocator(tick_interval))  # Dynamically set x ticks
                ax[2].set_xlabel('Time (s)', fontsize=16)

                if not os.path.exists(render_dir):
                    os.makedirs(render_dir)
                if False:
                    plt.legend(
                        loc='upper right',
                        fontsize=12,
                        handlelength=3,
                        handleheight=2,
                        prop={'weight': 'bold'},
                        frameon=True,  # Enable the frame
                        facecolor='white',  # Set background color to white
                        framealpha=1,  # Make the background fully opaque
                        edgecolor='black'  # Set the border color
                    )
                    raise NotImplementedError('Intentional stop, get legend pic in the first frame')
                plt.savefig(os.path.join(render_dir, f'{joint_name}_{frame_id:06d}.png'))
                plt.close()



class AngleCompare:
    def __init__(self, angle1, angle2):
        """
        angle1, angle2: angle lists in radians
        """
        self.random_id = np.random.randint(0, 100000000)
        if len(angle1) != len(angle2):
            raise ValueError('The two sets of angles must have the same length')
        self.angle1 = angle1
        self.angle2 = angle2
        self.diff_rad = angle_diff(angle1, angle2, input_rad=True, output_rad=True)
        self.diff_deg = angle_diff(angle1, angle2, input_rad=True, output_rad=False)
        self.md_deg = np.nanmean(self.diff_deg)
        self.sd_deg = np.nanstd(self.diff_deg)
        self.median_deg = np.nanmedian(self.diff_deg)

        ## remove outliers at +-3 std
        range_sd = 1.96
        self.diff_inliers_deg = self.diff_deg[self.diff_deg < range_sd * self.sd_deg]
        self.diff_inliers_deg = self.diff_inliers_deg[self.diff_inliers_deg > -range_sd * self.sd_deg]
        self.inliers_mean_deg = np.nanmean(self.diff_inliers_deg)
        self.inliers_sd_deg = np.nanstd(self.diff_inliers_deg)

        # self.plot_normal_curve = [[self.md_deg, self.sd_deg],[self.inliers_mean_deg, self.inliers_sd_deg]]
        self.plot_normal_curve = [[self.md_deg, self.sd_deg]]



# todo: make them not senstive to 180 overflow errors.

def angle_diff(angle1, angle2, input_rad=True, output_rad=True):
        """
        smaller angle difference between two angles in circular space
        input -pi to pi range angles
        returns within -pi to pi range
        """
        if not input_rad:
            angle1 = np.deg2rad(angle1)
            angle2 = np.deg2rad(angle2)
        diff = angle1 - angle2
        diff = np.where(diff > np.pi, diff - 2 * np.pi, diff)
        diff = np.where(diff < -np.pi, diff + 2 * np.pi, diff)
        if not output_rad:
            diff = np.rad2deg(diff)
        return diff


def calculate_iqr(data):
    Q1 = np.percentile(data, 25)
    Q3 = np.percentile(data, 75)
    IQR = Q3 - Q1
    return IQR


def bland_altman_plot(data1, data2, title='', xlabel='Mean (\N{DEGREE SIGN})', ylabel='Difference (\N{DEGREE SIGN})', save_path=None,
                      plot_percentage=0.05, csfont={'fontname':'Times New Roman'}):
    """
    Bland-Altman plot
    data1, data2: two sets of measurements
    """
    data1 = np.rad2deg(data1)
    data2 = np.rad2deg(data2)
    mean = np.nanmean([data1, data2], axis=0)
    diff = angle_diff(data1, data2, input_rad=False, output_rad=False)
    md = np.nanmean(diff)
    sd = np.nanstd(diff, axis=0)
    # only plot 10% of the data
    idx = np.random.choice(range(len(mean)), int(len(mean) * plot_percentage), replace=False)
    plt.scatter(mean[idx], diff[idx], alpha=0.2, s=1)
    plt.axhline(md, color='red', linestyle='--')
    plt.axhline(md + 1.96 * sd, color='red', linestyle='--')
    plt.axhline(md - 1.96 * sd, color='red', linestyle='--')
    text_height = 1
    text_right_pos = 0.98 * (plt.gca().get_xlim()[1] - plt.gca().get_xlim()[0]) + plt.gca().get_xlim()[0]
    # text above the line on the right hand side "+1.9, weight='bold'6 SD, size
    t1 = plt.text(text_right_pos, md + 1.96 * sd + text_height, f'+1.96 SD: {md+1.96*sd:.1f}\N{DEGREE SIGN}', horizontalalignment='right', verticalalignment='bottom',  fontsize=25, weight='bold', **csfont)
    t2 = plt.text(text_right_pos, md - 1.96 * sd - text_height, f'-1.96 SD: {md-1.96*sd:.1f}\N{DEGREE SIGN}', horizontalalignment='right', verticalalignment='top',     fontsize=25, weight='bold', **csfont)
    t3 = plt.text(text_right_pos, md , f'Mean: {md:.1f}\N{DEGREE SIGN}',                                      horizontalalignment='right', verticalalignment='bottom',  fontsize=25, weight='bold', **csfont)
    for t in [t1, t2, t3]:
        t.set_bbox(dict(facecolor='white', alpha=0.5, edgecolor='white', linewidth=0))
    plt.xticks(fontsize=12)
    plt.yticks(fontsize=12)
    plt.title(title,    fontsize=28, weight='bold', **csfont)
    # plt.xlabel(xlabel,  fontsize=22, **csfont)
    # plt.ylabel(ylabel,  fontsize=22, **csfont)
    plt.ylim([-35, 35])
    # plt.text(0.5, 0.95, f'Mean diff: {md:.2f}, std {sd:.2f}', horizontalalignment='center', verticalalignment='center', transform=plt.gca().transAxes)
    if save_path is not None:
        plt.savefig(save_path)
    else:
        plt.show()
    plt.close()
    return md, sd


def plot_error_histogram(errors, bins=50, title='Error Histogram', xlabel='Error (degrees)', ylabel='Probability Density', save_path=None, range_min=-30, range_max=30, plot_normal_curve=[]):
    """
    Plot a histogram of the errors between two sets of angles and overlay a normal distribution curve.

    errors: array of error values
    bins: number of bins in the histogram
    title: title of the plot
    xlabel: label for the x-axis
    ylabel: label for the y-axis
    save_path: path to save the plot, if None, the plot will be displayed
    range_min: minimum value for the histogram range
    range_max: maximum value for the histogram range
    plot_normal_curve: list of [mean, std] pairs for normal distribution curves to overlay
    """

    # Calculate the total number of samples
    total_samples = len(errors)

    # Plot the histogram with relative frequency
    plt.figure()
    counts, bins, patches = plt.hist(errors, bins=bins, edgecolor='black', alpha=0.7, range=(range_min, range_max), density=True)

    # Plot the normal distribution curve
    for mdsd in plot_normal_curve:
        md, sd = mdsd
        x = np.linspace(range_min, range_max, 1000)
        p = norm.pdf(x, md, sd)
        plt.plot(x, p, 'k', linewidth=2)

    plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel(f'{ylabel} (n={total_samples*2:,})')
    plt.ylim([0, 0.22])
    # plt.yticks(np.arange(0, 0.26, 0.05), ['0', '5%', '10%', '15%', '20%', '25%'])  # not for pdf
    plt.yticks(np.arange(0, 0.21, 0.05))
    plt.xlim([range_min, range_max])

    if save_path is not None:
        plt.savefig(save_path)
    else:
        plt.show()
    plt.close()


def analyze_error_distribution(errors):
    """
    Perform Kolmogorov-Smirnov test and calculate skewness and kurtosis of the errors between two sets of angles.

    angles1, angles2: two sets of angle measurements
    Returns: dictionary with Kolmogorov-Smirnov test result, skewness, and kurtosis
    """

    # Calculate the errors
    errors = errors[~np.isnan(errors)]
    md = np.nanmean(errors)
    sd = np.nanstd(errors)

    # Perform Kolmogorov-Smirnov test
    ks_test = ks_2samp(errors, np.random.normal(md, sd, len(errors)))

    # Calculate skewness and kurtosis
    error_skewness = skew(errors, nan_policy='omit')
    error_kurtosis = kurtosis(errors, nan_policy='omit')

    IQR = calculate_iqr(errors)

    return {
        'ks_statistic': ks_test.statistic,
        'ks_p_value': ks_test.pvalue,
        'skewness': error_skewness,
        'kurtosis': error_kurtosis,
        'IQR': IQR
    }


def mean_absolute_error(data1, data2):
    """
    data1, data2: two sets of measurements
    """
    diff = angle_diff(data1, data2, input_rad=True, output_rad=False)
    return np.nanmean(np.abs(diff))

def median_absolute_error(data1, data2):
    """
    data1, data2: two sets of measurements
    """
    diff = angle_diff(data1, data2, input_rad=True, output_rad=False)
    return np.nanmedian(np.abs(diff))


def root_mean_squared_error(data1, data2):
    """
    data1, data2: two sets of measurements
    """
    diff = angle_diff(data1, data2, input_rad=True, output_rad=False)
    return np.nanmean(diff ** 2)**0.5


# def bland_altman_plot_batch(ja1, ja2, angle_names):
#     """
#     ja1, ja2: two sets of JointAngle objects
#     set ja2 to gt
#     """
#     for angle_index, this_angle_name in enumerate(angle_names):
#
#         # md, sd = bland_altman_plot(ja1[this_angle_name].flexion, ja2[this_angle_name].flexion, title=this_angle_name) #, save_path=f'frames/MB_angles/{this_angle_name}_bland_altman.png')
#         # print(f'Visualizing - {this_angle_name}: md: {md:.2f}, sd: {sd:.2f}')
#         MSE, sd = mean_squared_error(ja1[this_angle_name].flexion, ja2[this_angle_name].flexion)
#         print(f'MSE - {this_angle_name}: mean: {MSE:.2f}, sd: {sd:.2f}')
#
#         MAE = mean_absolute_error(ja1[this_angle_name].flexion, ja2[this_angle_name].flexion)
#         print(f'MAE - {this_angle_name}: {MAE:.2f}')

# bland_altman_plot_batch(estimate_ergo_angles, GT_ergo_angles, GT_skeleton.angle_names)
#
# ja1 = GT_ergo_angles
# ja2 = estimate_ergo_angles
#
# this_angle_name = 'left_wrist'
# for i, angle in enumerate(estimate_ergo_angles[this_angle_name].flexion):
#     if np.isnan(angle):
#         print(i)
