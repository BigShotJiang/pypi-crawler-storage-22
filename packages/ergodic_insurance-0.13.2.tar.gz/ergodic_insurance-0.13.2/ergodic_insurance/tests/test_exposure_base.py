"""Unit tests for exposure base module."""

import time
from typing import Dict, List

import numpy as np
import pytest

from ergodic_insurance.config import ManufacturerConfig
from ergodic_insurance.decimal_utils import to_decimal
from ergodic_insurance.exposure_base import (
    AssetExposure,
    CompositeExposure,
    EmployeeExposure,
    EquityExposure,
    ExposureBase,
    ProductionExposure,
    RevenueExposure,
    ScenarioExposure,
    StochasticExposure,
)
from ergodic_insurance.manufacturer import WidgetManufacturer


class TestRevenueExposure:
    """Tests for revenue-based exposure with state provider."""

    def test_revenue_exposure_tracks_actual_revenue(self):
        """Revenue exposure should use actual revenue from manufacturer."""
        # GIVEN: Manufacturer with initial revenue of $10M
        config = ManufacturerConfig(
            initial_assets=10_000_000,
            asset_turnover_ratio=1.0,
            base_operating_margin=0.12,
            tax_rate=0.25,
            retention_ratio=0.7,
        )
        manufacturer = WidgetManufacturer(config)

        # AND: Revenue exposure using state provider
        exposure = RevenueExposure(state_provider=manufacturer)

        # THEN: Initial exposure equals initial revenue
        assert float(exposure.get_exposure(1.0)) == 10_000_000
        assert float(exposure.get_frequency_multiplier(1.0)) == 1.0

        # WHEN: Manufacturer revenue doubles through business growth
        manufacturer._record_cash_adjustment(
            to_decimal(20_000_000) - manufacturer.total_assets, "Increase assets for test"
        )

        # THEN: Frequency multiplier should reflect actual 2x revenue
        assert float(exposure.get_exposure(1.0)) == 20_000_000
        assert float(exposure.get_frequency_multiplier(1.0)) == 2.0

    def test_revenue_exposure_with_zero_base(self):
        """Handle zero base revenue gracefully."""
        config = ManufacturerConfig(
            initial_assets=1,  # Minimal assets
            asset_turnover_ratio=0.01,  # Minimal turnover
            base_operating_margin=0.12,
            tax_rate=0.25,
            retention_ratio=0.7,
        )
        manufacturer = WidgetManufacturer(config)
        # Manually override to test edge case
        manufacturer.asset_turnover_ratio = 0.0
        manufacturer._initial_assets = 0
        exposure = RevenueExposure(state_provider=manufacturer)

        assert float(exposure.get_exposure(1.0)) == 0  # Zero turnover means zero revenue
        assert float(exposure.get_frequency_multiplier(1.0)) == 0

    def test_revenue_exposure_reflects_business_changes(self):
        """Exposure should track actual business performance."""
        config = ManufacturerConfig(
            initial_assets=10_000_000,
            asset_turnover_ratio=1.0,
            base_operating_margin=0.12,
            tax_rate=0.25,
            retention_ratio=0.7,
        )
        manufacturer = WidgetManufacturer(config)
        exposure = RevenueExposure(state_provider=manufacturer)

        # Initial state
        initial_multiplier = exposure.get_frequency_multiplier(1.0)

        # Simulate business growth through retained earnings
        manufacturer.step(growth_rate=0.05)

        # Exposure should reflect actual business state, not artificial growth
        # The multiplier will depend on actual financial performance
        assert exposure.get_frequency_multiplier(1.0) != initial_multiplier


class TestAssetExposure:
    """Tests for asset-based exposure with state provider."""

    def test_asset_exposure_tracks_actual_assets(self):
        """Asset exposure tracks changes when cash stays positive."""
        # GIVEN: Manufacturer with $50M assets
        config = ManufacturerConfig(
            initial_assets=50_000_000,
            asset_turnover_ratio=1.0,
            base_operating_margin=0.12,
            tax_rate=0.25,
            retention_ratio=0.7,
        )
        manufacturer = WidgetManufacturer(config)
        exposure = AssetExposure(state_provider=manufacturer)

        # THEN: Initial exposure equals initial assets
        assert float(exposure.get_exposure(1.0)) == 50_000_000
        assert float(exposure.get_frequency_multiplier(1.0)) == 1.0

        # WHEN: Moderate reduction keeps cash positive (within cash balance)
        manufacturer._record_cash_adjustment(
            to_decimal(45_000_000) - manufacturer.total_assets, "Reduce assets for test"
        )

        # THEN: Frequency multiplier should be 0.9 (45M/50M)
        assert float(exposure.get_exposure(1.0)) == 45_000_000
        assert float(exposure.get_frequency_multiplier(1.0)) == 0.9

    def test_asset_exposure_with_negative_cash_reclassification(self):
        """When cash goes negative, total_assets floors cash at 0 per ASC 210-10-45-1."""
        # GIVEN: Manufacturer with $50M assets
        config = ManufacturerConfig(
            initial_assets=50_000_000,
            asset_turnover_ratio=1.0,
            base_operating_margin=0.12,
            tax_rate=0.25,
            retention_ratio=0.7,
        )
        manufacturer = WidgetManufacturer(config)
        exposure = AssetExposure(state_provider=manufacturer)

        # WHEN: Large claim pushes cash negative
        manufacturer._record_cash_adjustment(
            to_decimal(30_000_000) - manufacturer.total_assets, "Large claim for test"
        )

        # THEN: total_assets floors cash at 0 — exposure reflects GAAP presentation
        # Non-cash assets are preserved, so total_assets > 30M
        assert float(exposure.get_exposure(1.0)) > 30_000_000
        # Overdraft is reclassified as short-term borrowings (ASC 470-10)
        assert float(manufacturer.short_term_borrowings) > 0

    def test_asset_exposure_reflects_operations(self):
        """Asset exposure tracks real operational changes."""
        config = ManufacturerConfig(
            initial_assets=50_000_000,
            asset_turnover_ratio=1.0,
            base_operating_margin=0.12,
            tax_rate=0.25,
            retention_ratio=0.7,
        )
        manufacturer = WidgetManufacturer(config)
        exposure = AssetExposure(state_provider=manufacturer)

        # Process a large claim with deductible
        manufacturer.process_insurance_claim(
            claim_amount=10_000_000, deductible_amount=5_000_000, insurance_limit=10_000_000
        )

        # Assets will be affected by the claim processing
        # Frequency should scale with actual asset ratio
        assert float(exposure.get_exposure(1.0)) == float(manufacturer.total_assets)
        assert (
            float(exposure.get_frequency_multiplier(1.0))
            == float(manufacturer.total_assets) / 50_000_000
        )

    def test_zero_base_assets(self):
        """Test handling of zero base assets."""
        config = ManufacturerConfig(
            initial_assets=1,  # Will write off to 0 after
            asset_turnover_ratio=1.0,
            base_operating_margin=0.12,
            tax_rate=0.25,
            retention_ratio=0.7,
        )
        manufacturer = WidgetManufacturer(config)
        # Write off all assets to zero via ledger (single source of truth)
        manufacturer._write_off_all_assets("Zero out assets for test")
        manufacturer._initial_assets = 0
        exposure = AssetExposure(state_provider=manufacturer)

        assert float(exposure.get_exposure(1.0)) == 0
        assert float(exposure.get_frequency_multiplier(1.0)) == 0


class TestEquityExposure:
    """Tests for equity-based exposure with state provider."""

    def test_equity_exposure_tracks_actual_equity(self):
        """Equity exposure should use actual equity from manufacturer."""
        # GIVEN: Manufacturer with initial equity
        config = ManufacturerConfig(
            initial_assets=20_000_000,
            asset_turnover_ratio=1.0,
            base_operating_margin=0.12,
            tax_rate=0.25,
            retention_ratio=0.7,
        )
        manufacturer = WidgetManufacturer(config)
        exposure = EquityExposure(state_provider=manufacturer)

        # THEN: Initial exposure equals initial equity
        assert float(exposure.get_exposure(1.0)) == 20_000_000
        assert float(exposure.get_frequency_multiplier(1.0)) == 1.0

        # WHEN: Profitable operations increase equity
        # To set equity to 25M, adjust cash via ledger (equity = assets - liabilities)
        current_equity = manufacturer.equity
        equity_adjustment = to_decimal(25_000_000) - current_equity
        manufacturer._record_cash_adjustment(
            amount=equity_adjustment,
            description="Increase equity via cash for test scenario",
        )

        # THEN: Frequency scales with cube root of equity ratio
        assert float(exposure.get_exposure(1.0)) == 25_000_000
        # Multiplier = (25M/20M)^(1/3) = 1.25^0.333 ≈ 1.077
        expected_multiplier = 25_000_000 / 20_000_000
        assert np.isclose(float(exposure.get_frequency_multiplier(1.0)), expected_multiplier)

    def test_equity_exposure_handles_bankruptcy(self):
        """Equity exposure should handle zero equity correctly (limited liability)."""
        config = ManufacturerConfig(
            initial_assets=10_000_000,
            asset_turnover_ratio=1.0,
            base_operating_margin=0.12,
            tax_rate=0.25,
            retention_ratio=0.7,
        )
        manufacturer = WidgetManufacturer(config)
        exposure = EquityExposure(state_provider=manufacturer)

        # WHEN: Claims cause zero equity (bankruptcy with limited liability)
        # LIMITED LIABILITY: Equity is floored at 0, not negative
        current_equity = manufacturer.equity
        # Reduce cash by equity amount via ledger to set equity to 0
        manufacturer._record_cash_adjustment(
            amount=-current_equity,
            description="Reduce cash to zero equity for bankruptcy test",
        )

        # THEN: Frequency multiplier should be 0 (no exposure when bankrupt)
        # Use approx for floating point comparison (may have tiny rounding errors)
        assert exposure.get_exposure(1.0) == pytest.approx(0, abs=1e-9)
        assert exposure.get_frequency_multiplier(1.0) == pytest.approx(0.0, abs=1e-9)

    def test_conservative_scaling(self):
        """Verify frequency scales conservatively with equity using cube root."""
        config = ManufacturerConfig(
            initial_assets=20_000_000,
            asset_turnover_ratio=1.0,
            base_operating_margin=0.12,
            tax_rate=0.25,
            retention_ratio=0.7,
        )
        manufacturer = WidgetManufacturer(config)
        exposure = EquityExposure(state_provider=manufacturer)

        # Double the equity
        # To set equity to 40M, adjust cash via ledger
        current_equity = manufacturer.equity
        equity_adjustment = to_decimal(40_000_000) - current_equity
        manufacturer._record_cash_adjustment(
            amount=equity_adjustment,
            description="Double equity via cash for test scenario",
        )

        # Multiplier should be 2^(1/3) ≈ 1.26, not 2.0
        expected = 2.0
        assert np.isclose(float(exposure.get_frequency_multiplier(1.0)), expected)


class TestEmployeeExposure:
    """Tests for employee-based exposure."""

    def test_hiring_growth(self):
        """Verify employee count grows with hiring."""
        exposure = EmployeeExposure(base_employees=100, hiring_rate=0.10)

        # After 1 year: 100 * 1.1 = 110
        assert np.isclose(exposure.get_exposure(1), 110)

        # After 2 years: 100 * 1.1^2 = 121
        assert np.isclose(exposure.get_exposure(2), 121)

    def test_automation_reduction(self):
        """Verify automation reduces frequency multiplier."""
        exposure = EmployeeExposure(base_employees=100, hiring_rate=0.10, automation_factor=0.05)

        # Employees grow to 110 but automation reduces incident rate
        # Multiplier = 1.10 * 0.95 = 1.045
        assert np.isclose(exposure.get_frequency_multiplier(1), 1.10 * 0.95)

    def test_downsizing(self):
        """Test negative hiring rate (downsizing)."""
        exposure = EmployeeExposure(base_employees=100, hiring_rate=-0.05)  # 5% reduction per year

        # After 1 year: 100 * 0.95 = 95
        assert np.isclose(exposure.get_exposure(1), 95)

    def test_zero_employees(self):
        """Test handling of zero employees."""
        exposure = EmployeeExposure(base_employees=0)
        assert float(exposure.get_exposure(1)) == 0
        assert float(exposure.get_frequency_multiplier(1)) == 0

    def test_invalid_automation_factor(self):
        """Test that invalid automation factor raises error."""
        with pytest.raises(ValueError, match="Automation factor must be between 0 and 1"):
            EmployeeExposure(base_employees=100, automation_factor=1.5)


class TestProductionExposure:
    """Tests for production volume exposure."""

    def test_basic_growth(self):
        """Test basic production growth."""
        exposure = ProductionExposure(base_units=1000, growth_rate=0.08)

        # After 1 year: 1000 * 1.08 = 1080
        assert np.isclose(exposure.get_exposure(1), 1080)

    def test_seasonality(self):
        """Verify seasonal patterns apply correctly."""

        def seasonal_pattern(time):
            # Simple sinusoidal pattern
            return 1.0 + 0.3 * np.sin(2 * np.pi * time)

        exposure = ProductionExposure(base_units=1000, seasonality=seasonal_pattern)

        # At time 0.25 (quarter year), sin(π/2) = 1
        # Production = 1000 * (1 + 0.3 * 1) = 1300
        assert np.isclose(exposure.get_exposure(0.25), 1300)

        # At time 0.75, sin(3π/2) = -1
        # Production = 1000 * (1 + 0.3 * -1) = 700
        assert np.isclose(exposure.get_exposure(0.75), 700)

    def test_quality_improvement(self):
        """Verify quality improvements reduce frequency."""
        exposure = ProductionExposure(
            base_units=1000, growth_rate=0.10, quality_improvement_rate=0.05
        )

        # Production grows to 1100 but quality improvements offset frequency
        # Multiplier = 1.10 * 0.95 = 1.045
        assert np.isclose(exposure.get_frequency_multiplier(1), 1.10 * 0.95)

    def test_combined_effects(self):
        """Test growth, seasonality, and quality together."""

        def seasonal_pattern(time):
            return 1.2  # Constant 20% boost

        exposure = ProductionExposure(
            base_units=1000,
            growth_rate=0.10,
            seasonality=seasonal_pattern,
            quality_improvement_rate=0.03,
        )

        # After 1 year: 1000 * 1.1 * 1.2 = 1320
        assert np.isclose(exposure.get_exposure(1), 1320)

        # Frequency: (1320/1000) * 0.97 = 1.32 * 0.97 = 1.2804
        assert np.isclose(exposure.get_frequency_multiplier(1), 1.32 * 0.97)


class TestCompositeExposure:
    """Tests for composite exposure combinations."""

    def test_weighted_combination(self):
        """Verify weighted averaging works correctly."""
        # Create manufacturer for state-driven exposures
        config = ManufacturerConfig(
            initial_assets=50_000_000,
            asset_turnover_ratio=0.2,  # Revenue = $10M
            base_operating_margin=0.12,
            tax_rate=0.25,
            retention_ratio=0.7,
        )
        manufacturer = WidgetManufacturer(config)

        revenue_exp = RevenueExposure(state_provider=manufacturer)
        asset_exp = AssetExposure(state_provider=manufacturer)

        composite = CompositeExposure(
            exposures={"revenue": revenue_exp, "assets": asset_exp},
            weights={"revenue": 0.7, "assets": 0.3},
        )

        # Weighted multiplier at t=1
        rev_mult = float(revenue_exp.get_frequency_multiplier(1))
        asset_mult = float(asset_exp.get_frequency_multiplier(1))
        expected = 0.7 * rev_mult + 0.3 * asset_mult

        assert np.isclose(float(composite.get_frequency_multiplier(1)), expected)

    def test_weight_normalization(self):
        """Verify weights are normalized to sum to 1."""
        config = ManufacturerConfig(
            initial_assets=50_000_000,
            asset_turnover_ratio=0.2,
            base_operating_margin=0.12,
            tax_rate=0.25,
            retention_ratio=0.7,
        )
        manufacturer = WidgetManufacturer(config)

        revenue_exp = RevenueExposure(state_provider=manufacturer)
        asset_exp = AssetExposure(state_provider=manufacturer)

        composite = CompositeExposure(
            exposures={"revenue": revenue_exp, "assets": asset_exp},
            weights={"revenue": 2.0, "assets": 1.0},  # Sum = 3
        )

        # Weights should be normalized to 2/3 and 1/3
        assert np.isclose(composite.weights["revenue"], 2 / 3)
        assert np.isclose(composite.weights["assets"], 1 / 3)

    def test_three_component_composite(self):
        """Test composite with three exposure types."""
        config = ManufacturerConfig(
            initial_assets=50_000_000,
            asset_turnover_ratio=0.2,
            base_operating_margin=0.12,
            tax_rate=0.25,
            retention_ratio=0.7,
        )
        manufacturer = WidgetManufacturer(config)

        exposures = {
            "revenue": RevenueExposure(state_provider=manufacturer),
            "assets": AssetExposure(state_provider=manufacturer),
            "employees": EmployeeExposure(base_employees=100, hiring_rate=0.03),
        }

        composite = CompositeExposure(
            exposures=exposures, weights={"revenue": 0.5, "assets": 0.3, "employees": 0.2}
        )

        # Verify it produces reasonable results
        mult = float(composite.get_frequency_multiplier(1))
        # Since state-driven exposures start at 1.0, employee exposure drives growth
        assert mult >= 0.8  # Should be reasonable
        assert mult <= 1.5  # But not excessive

    def test_reset_propagation(self):
        """Test that reset propagates to all constituent exposures."""
        # Use StochasticExposure which has state to reset
        stochastic_exp = StochasticExposure(
            base_value=10_000_000,
            process_type="gbm",
            parameters={"drift": 0.05, "volatility": 0.20},
            seed=42,
        )

        composite = CompositeExposure(
            exposures={"stochastic": stochastic_exp}, weights={"stochastic": 1.0}
        )

        val1 = composite.get_exposure(1)
        composite.reset()
        val2 = composite.get_exposure(1)

        assert val1 == val2  # Should be identical after reset

    def test_empty_exposures_raises_error(self):
        """Test that empty exposures raises error."""
        with pytest.raises(ValueError, match="Must provide at least one exposure"):
            CompositeExposure(exposures={}, weights={})


# ScenarioExposure doesn't require state providers, it works with predefined scenarios
class TestScenarioExposure:
    """Tests for scenario-based exposure."""

    def test_recession_scenario(self):
        """Verify recession scenario path."""
        scenarios = {
            "baseline": [100.0, 105.0, 110.0, 115.0, 120.0],
            "recession": [100.0, 95.0, 90.0, 92.0, 95.0],
            "boom": [100.0, 110.0, 125.0, 140.0, 160.0],
        }

        exposure = ScenarioExposure(scenarios=scenarios, selected_scenario="recession")

        # At year 2, exposure should be 90
        assert float(exposure.get_exposure(2)) == 90

        # Frequency multiplier = 90/100 = 0.9
        assert np.isclose(float(exposure.get_frequency_multiplier(2)), 0.9)

    def test_linear_interpolation(self):
        """Verify linear interpolation between years."""
        scenarios = {"test": [100.0, 110.0, 120.0]}

        exposure = ScenarioExposure(
            scenarios=scenarios, selected_scenario="test", interpolation="linear"
        )

        # At time 0.5, should be halfway between 100 and 110
        assert np.isclose(exposure.get_exposure(0.5), 105)

        # At time 1.5, should be halfway between 110 and 120
        assert np.isclose(exposure.get_exposure(1.5), 115)

    def test_nearest_interpolation(self):
        """Test nearest neighbor interpolation."""
        scenarios = {"test": [100.0, 110.0, 120.0]}

        exposure = ScenarioExposure(
            scenarios=scenarios, selected_scenario="test", interpolation="nearest"
        )

        # At time 0.4, should round to 0 -> 100
        assert float(exposure.get_exposure(0.4)) == 100

        # At time 0.6, should round to 1 -> 110
        assert float(exposure.get_exposure(0.6)) == 110

    def test_boundary_conditions(self):
        """Test exposure at and beyond scenario boundaries."""
        scenarios = {"test": [100.0, 110.0, 120.0]}

        exposure = ScenarioExposure(scenarios=scenarios, selected_scenario="test")

        # Before start
        assert float(exposure.get_exposure(0)) == 100

        # After end
        assert float(exposure.get_exposure(10)) == 120

    def test_scenario_switching(self):
        """Test switching between scenarios."""
        scenarios = {"optimistic": [100.0, 110.0, 120.0], "pessimistic": [100.0, 90.0, 80.0]}

        exposure = ScenarioExposure(scenarios=scenarios, selected_scenario="optimistic")

        assert float(exposure.get_exposure(1)) == 110

        # Create new exposure with different scenario
        exposure2 = ScenarioExposure(scenarios=scenarios, selected_scenario="pessimistic")
        assert float(exposure2.get_exposure(1)) == 90

    def test_invalid_scenario_raises_error(self):
        """Test that invalid scenario selection raises error."""
        scenarios = {"test": [100.0, 110.0]}

        with pytest.raises(
            ValueError, match="Selected scenario 'invalid' not in available scenarios"
        ):
            ScenarioExposure(scenarios=scenarios, selected_scenario="invalid")


# StochasticExposure doesn't require state providers, it uses its own stochastic processes
class TestStochasticExposure:
    """Tests for stochastic exposure processes."""

    def test_gbm_process(self):
        """Verify GBM properties."""
        exposure = StochasticExposure(
            base_value=100,
            process_type="gbm",
            parameters={"drift": 0.05, "volatility": 0.20},
            seed=42,
        )

        # Generate value at t=1
        value = exposure.get_exposure(1.0)

        # Should be positive
        assert value > 0

        # Should be reproducible with same seed
        exposure2 = StochasticExposure(
            base_value=100,
            process_type="gbm",
            parameters={"drift": 0.05, "volatility": 0.20},
            seed=42,
        )
        assert exposure2.get_exposure(1.0) == value

    def test_mean_reverting_process(self):
        """Test Ornstein-Uhlenbeck process."""
        exposure = StochasticExposure(
            base_value=100,
            process_type="mean_reverting",
            parameters={"mean_reversion_speed": 0.5, "long_term_mean": 110, "volatility": 0.15},
            seed=42,
        )

        # Generate value
        value = exposure.get_exposure(1.0)
        assert value > 0

        # Should tend toward long-term mean over time
        # (statistical test would require many paths)

    def test_jump_diffusion_process(self):
        """Test jump diffusion process."""
        exposure = StochasticExposure(
            base_value=100,
            process_type="jump_diffusion",
            parameters={
                "drift": 0.05,
                "volatility": 0.15,
                "jump_intensity": 0.1,
                "jump_mean": 0.0,
                "jump_std": 0.1,
            },
            seed=42,
        )

        value = exposure.get_exposure(1.0)
        assert value > 0

    def test_path_caching(self):
        """Verify paths are cached for consistency."""
        exposure = StochasticExposure(
            base_value=100,
            process_type="gbm",
            parameters={"drift": 0.05, "volatility": 0.20},
            seed=42,
        )

        # Multiple calls should return same value
        val1 = exposure.get_exposure(1.0)
        val2 = exposure.get_exposure(1.0)
        assert val1 == val2

    def test_reset_clears_cache(self):
        """Test that reset clears the path cache."""
        exposure = StochasticExposure(
            base_value=100,
            process_type="gbm",
            parameters={"drift": 0.05, "volatility": 0.20},
            seed=42,
        )

        val1 = exposure.get_exposure(1.0)
        exposure.reset()
        val2 = exposure.get_exposure(1.0)

        # Should be same value due to same seed
        assert val1 == val2

    def test_invalid_process_type_raises_error(self):
        """Test that invalid process type raises error."""
        with pytest.raises(ValueError, match="Unknown process type"):
            StochasticExposure(base_value=100, process_type="invalid", parameters={}, seed=42)

    def test_zero_time_returns_base_value(self):
        """Test that time=0 returns base value."""
        exposure = StochasticExposure(
            base_value=100, process_type="gbm", parameters={"drift": 0.05, "volatility": 0.20}
        )

        assert float(exposure.get_exposure(0)) == 100


class TestPerformance:
    """Performance and stress tests."""

    def test_memory_usage(self):
        """Verify memory usage is reasonable."""
        import sys

        exposure = StochasticExposure(
            base_value=100, process_type="gbm", parameters={"drift": 0.05, "volatility": 0.20}
        )

        # Generate many paths
        for t in range(100):
            _ = exposure.get_exposure(float(t))

        # Check cache size is bounded
        cache_size = sys.getsizeof(exposure._path_cache)
        assert cache_size < 100_000  # Less than 100KB


class TestEdgeCases:
    """Test edge cases and error conditions."""

    def test_fractional_years(self):
        """Test exposure calculation at fractional time points."""
        exposure = ProductionExposure(base_units=10_000, growth_rate=0.12)

        # Test various fractional times
        for t in [0.25, 0.5, 0.75, 1.25, 2.5]:
            value = exposure.get_exposure(t)
            assert value > 0
            expected = 10_000 * (1.12**t)
            assert np.isclose(value, expected)
