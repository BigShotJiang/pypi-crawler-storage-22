def main() -> None:
    print("Hello from erictor888-mcp!")
