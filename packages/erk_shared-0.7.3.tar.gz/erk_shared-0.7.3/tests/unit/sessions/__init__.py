"""Tests for sessions package."""
