erp5.util
=========

Package containing various ERP5 related utilities.

Modules documentation
=====================
