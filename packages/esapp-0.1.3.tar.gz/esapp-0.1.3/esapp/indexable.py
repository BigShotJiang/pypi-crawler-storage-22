from .saw import SAW, PowerWorldPrerequisiteError
from .components import GObject
from .utils import timing
from typing import Type, Optional
from pandas import DataFrame
from os import path


# Helper Function to parse Python Syntax/Field Syntax outliers
# Example: fexcept('ThreeWindingTransformer') -> '3WindingTransformer
fexcept = lambda t: "3" + t[5:] if t[:5] == "Three" else t

# Power World Read/Write
class Indexable:
    """
    PowerWorld Read/Write tool providing indexer-based access to grid components.

    This class enables DataFrame-like access to PowerWorld Simulator data,
    allowing users to retrieve and modify component parameters using familiar
    indexing syntax.
    """
    esa: SAW
    fname: str

    @timing
    def open(self):
        """
        Open the PowerWorld case and initialize transient stability.

        This method validates the case path, initializes the SimAuto COM object,
        and attempts to initialize transient stability to ensure initial values
        are available for dynamic models.

        Raises
        ------
        FileNotFoundError
            If the case file does not exist on disk.
        """
        # Validate Path Name
        if not path.isabs(self.fname):
            self.fname = path.abspath(self.fname)

        if not path.exists(self.fname):
            raise FileNotFoundError(
                f"Case file not found: '{self.fname}'\n"
                f"Please verify the file path is correct and the file exists."
            )

        # ESA Object & Transient Sim
        self.esa = SAW(self.fname, CreateIfNotFound=True, early_bind=True)
    
    def __getitem__(self, index) -> Optional[DataFrame]:
        """Retrieve data from PowerWorld using indexer notation.

        This method allows for flexible querying of grid component data directly
        from the PowerWorld simulation instance.

        Parameters
        ----------
        index : Union[Type[GObject], Tuple[Type[GObject], Any]]
            Can be a `GObject` type to get key fields, or a tuple of
            (GObject type, fields) to specify fields. `fields` can be a
            single field name (str), a list of names, or `slice(None)` (:)
            to retrieve all available fields.

        Returns
        -------
        Optional[pandas.DataFrame]
            A DataFrame containing the requested data, or ``None`` if no
            data could be retrieved.

        Raises
        ------
        ValueError
            If an unsupported slice is used for field selection.
        """
        # 1. Parse index to get gtype and what fields are requested.
        if isinstance(index, tuple):
            gtype, requested_fields = index
        else:
            gtype, requested_fields = index, None

        # 2. Determine the complete set of fields to retrieve.
        # Always start with the object's key fields.
        fields_to_get = set(gtype.keys())

        # 3. Add any additional fields based on the request.
        if requested_fields is None:
            # Case: pw[Bus] -> only key fields are needed.
            pass
        elif requested_fields == slice(None):
            # Case: pw[Bus, :] -> add all defined fields.
            fields_to_get.update(gtype.fields())
        else:
            # Case: pw[Bus, 'field'] or pw[Bus, ['f1', 'f2']]
            # Normalize to an iterable to handle single or multiple fields.
            if isinstance(requested_fields, (str, GObject)):
                requested_fields = [requested_fields]
            
            for field in requested_fields:
                if isinstance(field, GObject):
                    fields_to_get.add(field.value[1])
                elif isinstance(field, str):
                    fields_to_get.add(field)
                elif isinstance(field, slice):
                    raise ValueError("Only the full slice [:] is supported for selecting fields.")

        # 4. Handle edge case where no fields are identified.
        if not fields_to_get:
            return None

        # 5. Retrieve data from PowerWorld
        return self.esa.GetParamsRectTyped(gtype.TYPE(), sorted(list(fields_to_get)))
    
    def __setitem__(self, args, value) -> None:
        """
        Set grid data in PowerWorld using indexer notation.

        Two write modes are supported:

        **Case 1 — Bulk update** ``idx[GObject] = DataFrame``:
            Sends every column in *value* to PowerWorld via
            ``ChangeParametersMultipleElementRect``.  If the objects do
            not yet exist (PowerWorld returns *"not found"*), the method
            falls back to ``ChangeParametersMultipleElement`` which can
            create new objects **provided the SAW instance was opened
            with** ``CreateIfNotFound=True`` **and PowerWorld is in EDIT
            mode** (see ``esa.EnterMode('EDIT')``).  If primary keys are
            missing from the DataFrame, a ``ValueError`` is raised
            immediately — secondary keys are *not* required.

        **Case 2 — Broadcast update** ``idx[GObject, field(s)] = value``:
            Reads existing objects' primary keys, appends *value* as new
            column(s), and writes the result back.  This path only
            *updates* existing objects; it never creates new ones.

        Parameters
        ----------
        args : Union[Type[GObject], Tuple[Type[GObject], Union[str, List[str]]]]
            The target object type and optional fields.
        value : Union[pandas.DataFrame, Any]
            The data to write. If `args` is just a GObject type, `value`
            must be a DataFrame containing primary keys. If `args` includes
            fields, `value` can be a scalar (which is broadcast) or a
            list/array matching the number of objects.

        Raises
        ------
        TypeError
            If the index or value types are mismatched or unsupported.
        """
        # Case 1: Bulk update from a DataFrame. e.g., pw[Bus] = df
        if isinstance(args, type) and issubclass(args, GObject):
            self._bulk_update_from_df(args, value)
            return

        # Case 2: Broadcast update to specific fields. e.g., pw[Bus, 'BusPUVolt'] = 1.05
        if isinstance(args, tuple) and len(args) == 2:
            gtype, fields = args

            if not (isinstance(gtype, type) and issubclass(gtype, GObject)):
                raise TypeError(f"First element of index must be a GObject subclass, not {type(gtype)}")

            # Normalize fields to be a list of strings
            if isinstance(fields, str):
                fields = [fields]
            elif not isinstance(fields, (list, tuple)):
                raise TypeError("Fields must be a string or a list/tuple of strings.")

            self._broadcast_update_to_fields(gtype, fields, value)
            return

        raise TypeError(f"Unsupported index for __setitem__: {args}")

    def _bulk_update_from_df(self, gtype: Type[GObject], df: DataFrame):
        """Update (or create) objects from a DataFrame.

        Execution flow
        --------------
        1. Validate that every column is *settable* (key, secondary, or
           editable).  Reject read-only fields early.
        2. Call ``ChangeParametersMultipleElementRect`` — this is the fast
           path that updates all rows in a single COM round-trip.
        3. **If** the call raises ``PowerWorldPrerequisiteError`` with
           *"not found"*:

           a. Check whether the DataFrame contains all **primary keys**
              (``gtype.keys()``).  If any are missing, raise ``ValueError``
              — we cannot identify/create objects without them.
           b. Fall back to ``ChangeParametersMultipleElement`` which
              iterates row-by-row.  When the SAW property
              ``CreateIfNotFound`` is ``True`` **and** PowerWorld is in
              **EDIT mode**, this variant creates objects that do not yet
              exist.  *"not found"* messages from this call are silently
              suppressed (they are expected for newly created rows).

        4. Any *other* ``PowerWorldPrerequisiteError`` (not "not found")
           is re-raised immediately.

        Prerequisites for object creation
        ----------------------------------
        * ``SAW(path, CreateIfNotFound=True)``
        * ``esa.EnterMode('EDIT')`` before the call

        Parameters
        ----------
        gtype : Type[GObject]
            The GObject subclass representing the type of objects to update.
        df : pandas.DataFrame
            The DataFrame containing object data.  Must include all
            primary key columns (``gtype.keys()``).

        Raises
        ------
        TypeError
            If *df* is not a DataFrame.
        ValueError
            If any column is not settable, or if primary keys are missing
            when object creation is required.
        """
        if not isinstance(df, DataFrame):
            raise TypeError("A DataFrame is required for bulk updates.")

        # Validate that all columns are settable (keys or editable)
        non_settable = [c for c in df.columns if not gtype.is_settable(c)]
        if non_settable:
            raise ValueError(
                f"Cannot set read-only field(s) on {gtype.TYPE()}: {non_settable}"
            )

        try:
            self.esa.ChangeParametersMultipleElementRect(gtype.TYPE(), df.columns.tolist(), df)
        except PowerWorldPrerequisiteError as e:
            if "not found" in str(e).lower():
                missing_keys = set(gtype.keys()) - set(df.columns)
                if missing_keys:
                    raise ValueError(
                        f"Missing required primary key field(s) for {gtype.TYPE()}: {missing_keys}. "
                        f"All primary keys must be included to create new objects."
                    ) from e
                # Primary keys present — fall back to
                # ChangeParametersMultipleElement which creates objects
                # that do not yet exist.  The "not found" message from
                # this call is expected and suppressed.
                cols = df.columns.tolist()
                values = df.values.tolist()
                try:
                    self.esa.ChangeParametersMultipleElement(gtype.TYPE(), cols, values)
                except PowerWorldPrerequisiteError as create_err:
                    if 'not found' not in str(create_err).lower():
                        raise
            else:
                raise

    def _broadcast_update_to_fields(self, gtype: Type[GObject], fields: list[str], value):
        """Modifies specific fields for existing objects by broadcasting a value.

        This corresponds to the use case: `pw[ObjectType, 'FieldName'] = value`.

        Parameters
        ----------
        gtype : Type[GObject]
            The GObject subclass representing the type of objects to update.
        fields : List[str]
            A list of field names to update.
        value : Any
            The value to broadcast to the specified fields. Can be a scalar or
            a list/array if updating multiple fields on a keyless object.

        Raises
        ------
        ValueError
            If value length doesn't match field length for keyless objects,
            or if any specified field is not editable (excluding key fields).
        """
        # Validate all fields are settable (keys or editable)
        non_settable = [f for f in fields if not gtype.is_settable(f)]
        if non_settable:
            raise ValueError(
                f"Cannot set read-only field(s) on {gtype.TYPE()}: {non_settable}"
            )
        # For objects without keys (e.g., Sim_Solution_Options), we construct
        # the change DataFrame directly without reading from PowerWorld first.
        if not gtype.keys():
            data_dict = {}
            if len(fields) == 1:
                data_dict[fields[0]] = [value]
            elif isinstance(value, (list, tuple)) and len(value) == len(fields):
                for i, field in enumerate(fields):
                    data_dict[field] = [value[i]]
            else:
                raise ValueError(
                    "For multiple fields on a keyless object, 'value' must be a list/tuple of the same length as the fields."
                )
            change_df = DataFrame(data_dict)
        
        # For objects with keys, we first get the keys (primary keys)
        # of all existing objects to ensure we only modify what's already there.
        else:
            keys = gtype.keys()
            change_df = self[gtype, keys]
            
            if change_df is None or change_df.empty:
                # No objects of this type exist, so there's nothing to modify.
                return

            # Add the new values to the DataFrame of keys.
            # Pandas will broadcast a scalar `value` or align a list/array `value`.
            # When fields has a single element, use the field name directly to avoid pandas treating it as multiple columns
            if len(fields) == 1:
                change_df[fields[0]] = value
            else:
                change_df[fields] = value
        
        # Send the minimal DataFrame to PowerWorld.
        self.esa.ChangeParametersMultipleElementRect(gtype.TYPE(), change_df.columns.tolist(), change_df)