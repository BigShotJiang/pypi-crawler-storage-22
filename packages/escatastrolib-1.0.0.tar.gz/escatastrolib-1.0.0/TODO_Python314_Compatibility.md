# TODO: Python 3.8-3.14 Compatibility Update

## Objective
Update the ESCatastroLib library to be compatible with Python versions 3.8 through 3.14.

## Tasks

### 1. Update pyproject.toml
- [x] Add "3.14" to the test matrix under `[tool.hatch.envs.test.matrix]`
- [ ] Ensure all dependencies support Python 3.8-3.14 range

### 2. Code Review and Updates
- [x] Review `src/escatastrolib/models/InfoCatastral.py` for deprecated patterns
- [x] Review `src/escatastrolib/utils/utils.py` for deprecated patterns
- [x] Check for any `list(dict.values())[0]` patterns that may need updating
- [x] Verify `typing` imports are compatible with all Python versions

### 3. Testing
- [x] Verify the library can be imported successfully
- [x] Run existing tests to ensure compatibility
- [x] Check for any deprecation warnings

### 4. Documentation
- [ ] Update README.md if needed
- [ ] Verify classifiers in pyproject.toml are accurate

## Notes
- Must maintain backward compatibility with Python 3.8
- Python 3.14 may have stricter type checking and deprecation warnings
- Some patterns may work but trigger deprecation warnings

## Progress
- [x] Analyzed codebase structure
- [x] Reviewed pyproject.toml configuration
- [x] Reviewed main source files for potential compatibility issues
- [x] Implemented updates for Python 3.14 compatibility
- [x] Updated pyproject.toml to include Python 3.14 in test matrix
- [x] Verified library imports successfully
- [x] Ran tests to verify compatibility

