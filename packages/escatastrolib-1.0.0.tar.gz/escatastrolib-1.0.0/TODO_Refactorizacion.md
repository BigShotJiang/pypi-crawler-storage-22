# TODO: Refactorización de InfoCatastral.py

## Objetivo
Refactorizar el archivo `src/escatastrolib/models/InfoCatastral.py` para mejorar:
- Eliminación de código duplicado entre `ParcelaCatastral` y `MetaParcela`
- Mejor manejo de errores
- Type hints en todos los métodos
- Docstrings mejorados

## Cambios de Nomenclatura
- `BaseParcela` → `ParcelaHelper`
- `_make_api_request` → `_llamar_a_api`

## Estado Actual (Actualizado: 2024)
- ✅ Fase 1: Extracción de funcionalidades comunes - COMPLETADA
- ✅ Fase 2: Refactorización de ParcelaCatastral - COMPLETADA
- ✅ Fase 3: Refactorización de MetaParcela - COMPLETADA
- ✅ Fase 4: Validación - COMPLETADA (10 tests pasan)
- ✅ Fase 5: Type Hints y Docstrings Faltantes - COMPLETADA
  - ✅ `__create_regions()` - type hints y docstring agregados
  - ✅ `__create_geometry()` - type hints y docstring agregados, usa `_llamar_a_api()`
  - ✅ `distancias_aristas` - type hints agregados (`Optional[List[float]]`)
  - ✅ `perimetro` - type hints agregados (`Optional[float]`)
  - ✅ `valor_catastral_urbano_m2()` - type hints agregados, usa `_llamar_a_api()`
  - ✅ `numero_plantas` - type hints y docstring mejorados
  - ✅ `valor_catastral_rustico_m2()` - type hints en parámetro

## Tests
- ✅ Todos los 10 tests pasan sin regresiones

## Notas
- Mantener compatibilidad con la API existente
- No cambiar la firma pública de los métodos

