from eshgham import main


def main_exe():
    """Actual entry point"""
    exit(main())


if __name__ == "__main__":
    main_exe()
