_installed_version = '0.4.0'
_installed_git_hash = '248256f0345985c8a11cd8facddc8d57a948732e'
_version_setup_depth = 1
