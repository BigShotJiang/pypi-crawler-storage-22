==========
E.Sios API
==========

Interact with e.sios API
http://esios.readthedocs.org/

.. image:: https://github.com/gisce/esios/actions/workflows/python2.7-app.yml/badge.svg
    :target: https://github.com/gisce/esios/actions/workflows/python2.7-app.yml

.. image:: https://github.com/gisce/esios/actions/workflows/python3.11-app.yml/badge.svg
    :target: https://github.com/gisce/esios/actions/workflows/python3.11-app.yml


.. image:: https://coveralls.io/repos/github/gisce/esios/badge.svg?branch=master
    :target: https://coveralls.io/github/gisce/esios?branch=master

------
Usage
------

Ensure that ``ESIOS_TOKEN`` var exists and is exported for the working env.
