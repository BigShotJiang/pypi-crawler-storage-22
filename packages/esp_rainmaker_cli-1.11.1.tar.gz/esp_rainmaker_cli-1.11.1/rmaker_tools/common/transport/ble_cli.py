# SPDX-FileCopyrightText: 2018-2023 Espressif Systems (Shanghai) CO LTD
# SPDX-License-Identifier: Apache-2.0
#

import platform

try:
    # Try to import from utils package
    from ..utils.convenience import hex_str_to_bytes, str_to_bytes
except ImportError:
    # Fallback - create minimal utils functions locally
    def hex_str_to_bytes(s: str) -> bytes:
        return bytes.fromhex(s)
    
    def str_to_bytes(s):
        """Convert string to bytes"""
        if isinstance(s, str):
            return s.encode('latin-1')
        return s

fallback = True


# Check if required packages are installed
# else fallback to console mode
try:
    import bleak
    fallback = False
except ImportError:
    pass


# --------------------------------------------------------------------

def device_sort(device):
    return device[0].address


class BLE_Bleak_Client:
    def __init__(self):
        self.adapter = None
        self.adapter_props = None
        self.characteristics = dict()
        self.chrc_names = None
        self.device = None
        self.devname = None
        self.iface = None
        self.nu_lookup = None
        self.services = None
        self.srv_uuid_adv = None
        self.srv_uuid_fallback = None

    async def connect(self, devname, iface, chrc_names, fallback_srv_uuid):
        self.devname = devname
        self.srv_uuid_fallback = fallback_srv_uuid
        self.chrc_names = [name.lower() for name in chrc_names]
        self.iface = iface

        print('Discovering...')
        try:
            discovery = await bleak.BleakScanner.discover(return_adv=True)
            devices = list(discovery.values())
        except bleak.exc.BleakDBusError as e:
            if str(e) == '[org.bluez.Error.NotReady] Resource Not Ready':
                raise RuntimeError('Bluetooth is not ready. Maybe try `bluetoothctl power on`?')
            raise

        found_device = None

        if self.devname is None:
            if len(devices) == 0:
                print('No devices found!')
                exit(1)

            while True:
                devices.sort(key=device_sort)
                print('==== BLE Discovery results ====')
                print('{0: >4} {1: <33} {2: <12}'.format(
                    'S.N.', 'Name', 'Address'))
                for i, _ in enumerate(devices):
                    print('[{0: >2}] {1: <33} {2: <12}'.format(i + 1, devices[i][0].name or 'Unknown', devices[i][0].address))

                while True:
                    try:
                        select = int(input('Select device by number (0 to rescan) : '))
                        if select < 0 or select > len(devices):
                            raise ValueError
                        break
                    except ValueError:
                        print('Invalid input! Retry')

                if select != 0:
                    break

                discovery = await bleak.BleakScanner.discover(return_adv=True)
                devices = list(discovery.values())

            self.devname = devices[select - 1][0].name
            found_device = devices[select - 1]
        else:
            for d in devices:
                if d[0].name == self.devname:
                    found_device = d

        if not found_device:
            raise RuntimeError('Device not found')

        uuids = found_device[1].service_uuids
        # There should be 1 service UUID in advertising data
        # If bluez had cached an old version of the advertisement data
        # the list of uuids may be incorrect, in which case connection
        # or service discovery may fail the first time. If that happens
        # the cache will be refreshed before next retry
        if len(uuids) == 1:
            self.srv_uuid_adv = uuids[0]

        print('Connecting...')
        self.device = bleak.BleakClient(found_device[0].address)
        await self.device.connect()
        # must be paired on Windows to access characteristics;
        # cannot be paired on Mac
        if platform.system() == 'Windows':
            await self.device.pair()

        print('Getting Services...')
        services = self.device.services

        service = services[self.srv_uuid_adv] or services[self.srv_uuid_fallback]
        if not service:
            await self.device.disconnect()
            self.device = None
            raise RuntimeError('Provisioning service not found')

        # Read all characteristics and their user descriptors to build endpoint name -> UUID mapping
        nu_lookup = dict()
        discovered_endpoints = []
        for characteristic in service.characteristics:
            # Store all characteristics for later use
            self.characteristics[characteristic.uuid] = characteristic
            # Read user descriptors (UUID 2901) which contain endpoint names
            for descriptor in characteristic.descriptors:
                if descriptor.uuid[4:8] != '2901':
                    continue
                try:
                    readval = await self.device.read_gatt_descriptor(descriptor.handle)
                    found_name = ''.join(chr(b) for b in readval).lower()
                    nu_lookup[found_name] = characteristic.uuid
                    discovered_endpoints.append(found_name)
                except Exception as e:
                    # Skip if descriptor read fails
                    continue

        # Debug: Print discovered endpoints
        if discovered_endpoints:
            print(f"Discovered endpoints via user descriptors: {', '.join(discovered_endpoints)}")
        else:
            print("Warning: No endpoints found with user descriptors (UUID 2901)")

        # Check if all requested endpoints were found
        match_found = True
        missing_endpoints = []
        for name in self.chrc_names:
            if name not in nu_lookup:
                # Endpoint name not present
                match_found = False
                missing_endpoints.append(name)

        # Use the lookup table if all endpoints found, otherwise None (will use fallback)
        self.nu_lookup = nu_lookup if match_found else None
        
        # If some endpoints are missing, log which ones
        if missing_endpoints:
            print(f"Missing endpoints: {', '.join(missing_endpoints)}")

        return True

    def get_nu_lookup(self):
        return self.nu_lookup

    def has_characteristic(self, uuid):
        print('checking for characteristic ' + uuid)
        if uuid in self.characteristics:
            return True
        return False
    
    def get_available_characteristics(self):
        """Return list of available characteristic UUIDs"""
        return list(self.characteristics.keys())
    
    def get_service_uuid(self):
        """Return the actual service UUID that was used (from advertisement or fallback)"""
        # Return the discovered service UUID if available, otherwise fallback
        return self.srv_uuid_adv or self.srv_uuid_fallback

    async def disconnect(self):
        if self.device:
            print('Disconnecting...')
            if platform.system() == 'Windows':
                await self.device.unpair()
            await self.device.disconnect()
            self.device = None
            self.nu_lookup = None
            self.characteristics = dict()

    async def send_data(self, characteristic_uuid, data):
        await self.device.write_gatt_char(characteristic_uuid, bytearray(data.encode('latin-1')), True)
        readval = await self.device.read_gatt_char(characteristic_uuid)
        return ''.join(chr(b) for b in readval)
# --------------------------------------------------------------------


# Console based BLE client for Cross Platform support
class BLE_Console_Client:
    async def connect(self, devname, iface, chrc_names, fallback_srv_uuid):
        print('BLE client is running in console mode')
        print('\tThis could be due to your platform not being supported or dependencies not being met')
        print('\tPlease ensure all pre-requisites are met to run the full fledged client')
        print('BLECLI >> Please connect to BLE device `' + devname + '` manually using your tool of choice')
        resp = input('BLECLI >> Was the device connected successfully? [y/n] ')
        if resp != 'Y' and resp != 'y':
            return False
        print('BLECLI >> List available attributes of the connected device')
        resp = input("BLECLI >> Is the service UUID '" + fallback_srv_uuid + "' listed among available attributes? [y/n] ")
        if resp != 'Y' and resp != 'y':
            return False
        return True

    def get_nu_lookup(self):
        return None

    def has_characteristic(self, uuid):
        resp = input("BLECLI >> Is the characteristic UUID '" + uuid + "' listed among available attributes? [y/n] ")
        if resp != 'Y' and resp != 'y':
            return False
        return True
    
    def get_available_characteristics(self):
        """Return empty list for console client (can't auto-detect)"""
        return []
    
    def get_service_uuid(self):
        """Return fallback service UUID for console client"""
        return None

    async def disconnect(self):
        pass

    async def send_data(self, characteristic_uuid, data):
        print("BLECLI >> Write following data to characteristic with UUID '" + characteristic_uuid + "' :")
        print('\t>> ' + str_to_bytes(data).hex())
        print('BLECLI >> Enter data read from characteristic (in hex) :')
        resp = input('\t<< ')
        return hex_str_to_bytes(resp)


# --------------------------------------------------------------------


# Function to get client instance depending upon platform
def get_client():
    if fallback:
        return BLE_Console_Client()
    return BLE_Bleak_Client()
