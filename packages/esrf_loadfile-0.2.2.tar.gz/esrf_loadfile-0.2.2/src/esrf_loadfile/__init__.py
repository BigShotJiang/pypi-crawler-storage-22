"""Standalone accessors for ESRF tomography data files."""

from .version import VERSION, VERSION_SHORT

__version__ = VERSION

from .loadFile import (  # noqa: F401
    FileType,
    FilterH5Dataset,
    FilterMATDataset,
    LoadCIFFile,
    LoadDistortionMapFile,
    LoadH5File,
    LoadMatFile,
    LoadReflexionFile,
    genericFile,
    loadFile,
)
from .version import VERSION

__version__ = VERSION

__all__ = [
    "FileType",
    "FilterH5Dataset",
    "FilterMATDataset",
    "LoadCIFFile",
    "LoadDistortionMapFile",
    "LoadH5File",
    "LoadMatFile",
    "LoadReflexionFile",
    "genericFile",
    "loadFile",
    "VERSION",
    "VERSION_SHORT",
    "__version__",
]
