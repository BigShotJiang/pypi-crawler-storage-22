"""Allow running CLI as `python -m essence_wars.cli`."""

import sys

from . import main

if __name__ == "__main__":
    sys.exit(main())
