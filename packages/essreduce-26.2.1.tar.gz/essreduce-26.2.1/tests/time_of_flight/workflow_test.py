# SPDX-License-Identifier: BSD-3-Clause
# Copyright (c) 2025 Scipp contributors (https://github.com/scipp)
import numpy as np
import pytest
import sciline
import scipp as sc
import scippnexus as snx
from scipp.testing import assert_identical

from ess.reduce import time_of_flight
from ess.reduce.nexus.types import (
    AnyRun,
    DiskChoppers,
    EmptyDetector,
    NeXusData,
    Position,
    RawDetector,
    SampleRun,
)
from ess.reduce.time_of_flight import (
    GenericTofWorkflow,
    TofLookupTableWorkflow,
    fakes,
)

sl = pytest.importorskip("sciline")


@pytest.fixture
def workflow() -> GenericTofWorkflow:
    sizes = {'detector_number': 10}
    calibrated_beamline = sc.DataArray(
        data=sc.ones(sizes=sizes),
        coords={
            "position": sc.spatial.as_vectors(
                sc.zeros(sizes=sizes, unit='m'),
                sc.zeros(sizes=sizes, unit='m'),
                sc.linspace("detector_number", 79, 81, 10, unit='m'),
            ),
            "detector_number": sc.array(
                dims=["detector_number"], values=np.arange(10), unit=None
            ),
        },
    )

    events = sc.DataArray(
        data=sc.ones(dims=["event"], shape=[1000]),
        coords={
            "event_time_offset": sc.linspace(
                "event", 0.0, 1000.0 / 14, num=1000, unit="ms"
            ).to(unit="ns"),
            "event_id": sc.array(
                dims=["event"], values=np.arange(1000) % 10, unit=None
            ),
        },
    )
    nexus_data = sc.DataArray(
        sc.bins(
            begin=sc.array(dims=["pulse"], values=[0], unit=None),
            data=events,
            dim="event",
        )
    )

    wf = GenericTofWorkflow(run_types=[SampleRun], monitor_types=[])
    wf[EmptyDetector[SampleRun]] = calibrated_beamline
    wf[NeXusData[snx.NXdetector, SampleRun]] = nexus_data
    wf[Position[snx.NXsample, SampleRun]] = sc.vector([0, 0, 77], unit='m')
    wf[Position[snx.NXsource, SampleRun]] = sc.vector([0, 0, 0], unit='m')

    return wf


def test_TofLookupTableWorkflow_can_compute_tof_lut():
    wf = TofLookupTableWorkflow()
    wf[DiskChoppers[AnyRun]] = fakes.psc_choppers()
    wf[time_of_flight.NumberOfSimulatedNeutrons] = 10_000
    wf[time_of_flight.LtotalRange] = (
        sc.scalar(75.0, unit="m"),
        sc.scalar(85.0, unit="m"),
    )
    wf[time_of_flight.SourcePosition] = fakes.source_position()
    lut = wf.compute(time_of_flight.TofLookupTable)
    assert lut.array is not None
    assert lut.distance_resolution is not None
    assert lut.time_resolution is not None
    assert lut.pulse_stride is not None
    assert lut.pulse_period is not None
    assert lut.choppers is not None


@pytest.mark.parametrize("coord", ["tof", "wavelength"])
def test_GenericTofWorkflow_with_tof_lut_from_tof_simulation(workflow, coord: str):
    # Should be able to compute DetectorData without chopper and simulation params
    # This contains event_time_offset (time-of-arrival).
    _ = workflow.compute(RawDetector[SampleRun])
    # By default, the workflow tries to load the LUT from file
    with pytest.raises(sciline.UnsatisfiedRequirement):
        _ = workflow.compute(time_of_flight.TofLookupTable)
    with pytest.raises(sciline.UnsatisfiedRequirement):
        _ = workflow.compute(time_of_flight.TofDetector[SampleRun])

    lut_wf = TofLookupTableWorkflow()
    lut_wf[DiskChoppers[AnyRun]] = fakes.psc_choppers()
    lut_wf[time_of_flight.NumberOfSimulatedNeutrons] = 10_000
    lut_wf[time_of_flight.LtotalRange] = (
        sc.scalar(75.0, unit="m"),
        sc.scalar(85.0, unit="m"),
    )
    lut_wf[time_of_flight.SourcePosition] = fakes.source_position()
    table = lut_wf.compute(time_of_flight.TofLookupTable)

    workflow[time_of_flight.TofLookupTable] = table

    if coord == "tof":
        detector = workflow.compute(time_of_flight.TofDetector[SampleRun])
        assert 'tof' in detector.bins.coords
    else:
        detector = workflow.compute(time_of_flight.WavelengthDetector[SampleRun])
        assert 'wavelength' in detector.bins.coords


@pytest.mark.parametrize("coord", ["tof", "wavelength"])
def test_GenericTofWorkflow_with_tof_lut_from_file(
    workflow, tmp_path: pytest.TempPathFactory, coord: str
):
    lut_wf = TofLookupTableWorkflow()
    lut_wf[DiskChoppers[AnyRun]] = fakes.psc_choppers()
    lut_wf[time_of_flight.NumberOfSimulatedNeutrons] = 10_000
    lut_wf[time_of_flight.LtotalRange] = (
        sc.scalar(75.0, unit="m"),
        sc.scalar(85.0, unit="m"),
    )
    lut_wf[time_of_flight.SourcePosition] = fakes.source_position()
    lut = lut_wf.compute(time_of_flight.TofLookupTable)
    lut.save_hdf5(filename=tmp_path / "lut.h5")

    workflow[time_of_flight.TofLookupTableFilename] = (tmp_path / "lut.h5").as_posix()

    loaded_lut = workflow.compute(time_of_flight.TofLookupTable)
    assert_identical(lut.array, loaded_lut.array)
    assert_identical(lut.pulse_period, loaded_lut.pulse_period)
    assert lut.pulse_stride == loaded_lut.pulse_stride
    assert_identical(lut.distance_resolution, loaded_lut.distance_resolution)
    assert_identical(lut.time_resolution, loaded_lut.time_resolution)
    assert_identical(lut.choppers, loaded_lut.choppers)

    if coord == "tof":
        detector = workflow.compute(time_of_flight.TofDetector[SampleRun])
        assert 'tof' in detector.bins.coords
    else:
        detector = workflow.compute(time_of_flight.WavelengthDetector[SampleRun])
        assert 'wavelength' in detector.bins.coords


def test_GenericTofWorkflow_with_tof_lut_from_file_old_format(
    workflow, tmp_path: pytest.TempPathFactory
):
    lut_wf = TofLookupTableWorkflow()
    lut_wf[DiskChoppers[AnyRun]] = fakes.psc_choppers()
    lut_wf[time_of_flight.NumberOfSimulatedNeutrons] = 10_000
    lut_wf[time_of_flight.LtotalRange] = (
        sc.scalar(75.0, unit="m"),
        sc.scalar(85.0, unit="m"),
    )
    lut_wf[time_of_flight.SourcePosition] = fakes.source_position()
    lut = lut_wf.compute(time_of_flight.TofLookupTable)
    old_lut = sc.DataArray(
        data=lut.array.data,
        coords={
            "distance": lut.array.coords["distance"],
            "event_time_offset": lut.array.coords["event_time_offset"],
            "pulse_period": lut.pulse_period,
            "pulse_stride": sc.scalar(lut.pulse_stride, unit=None),
            "distance_resolution": lut.distance_resolution,
            "time_resolution": lut.time_resolution,
        },
    )
    old_lut.save_hdf5(filename=tmp_path / "lut.h5")

    workflow[time_of_flight.TofLookupTableFilename] = (tmp_path / "lut.h5").as_posix()
    loaded_lut = workflow.compute(time_of_flight.TofLookupTable)
    assert_identical(lut.array, loaded_lut.array)
    assert_identical(lut.pulse_period, loaded_lut.pulse_period)
    assert lut.pulse_stride == loaded_lut.pulse_stride
    assert_identical(lut.distance_resolution, loaded_lut.distance_resolution)
    assert_identical(lut.time_resolution, loaded_lut.time_resolution)
    assert loaded_lut.choppers is None  # No chopper info in old format

    detector = workflow.compute(time_of_flight.TofDetector[SampleRun])
    assert 'tof' in detector.bins.coords


def test_GenericTofWorkflow_with_tof_lut_from_tof_simulation_using_alias(workflow):
    # Should be able to compute DetectorData without chopper and simulation params
    # This contains event_time_offset (time-of-arrival).
    _ = workflow.compute(RawDetector[SampleRun])

    lut_wf = TofLookupTableWorkflow()
    lut_wf[DiskChoppers[AnyRun]] = fakes.psc_choppers()
    lut_wf[time_of_flight.NumberOfSimulatedNeutrons] = 10_000
    lut_wf[time_of_flight.LtotalRange] = (
        sc.scalar(75.0, unit="m"),
        sc.scalar(85.0, unit="m"),
    )
    lut_wf[time_of_flight.SourcePosition] = fakes.source_position()
    table = lut_wf.compute(time_of_flight.TimeOfFlightLookupTable)

    workflow[time_of_flight.TimeOfFlightLookupTable] = table
    # Should now be able to compute DetectorData with chopper and simulation params
    detector = workflow.compute(time_of_flight.TofDetector[SampleRun])
    assert 'tof' in detector.bins.coords


def test_GenericTofWorkflow_with_tof_lut_from_file_using_alias(
    workflow, tmp_path: pytest.TempPathFactory
):
    lut_wf = TofLookupTableWorkflow()
    lut_wf[DiskChoppers[AnyRun]] = fakes.psc_choppers()
    lut_wf[time_of_flight.NumberOfSimulatedNeutrons] = 10_000
    lut_wf[time_of_flight.LtotalRange] = (
        sc.scalar(75.0, unit="m"),
        sc.scalar(85.0, unit="m"),
    )
    lut_wf[time_of_flight.SourcePosition] = fakes.source_position()
    lut = lut_wf.compute(time_of_flight.TimeOfFlightLookupTable)
    lut.save_hdf5(filename=tmp_path / "lut.h5")

    workflow[time_of_flight.TimeOfFlightLookupTableFilename] = (
        tmp_path / "lut.h5"
    ).as_posix()
    loaded_lut = workflow.compute(time_of_flight.TimeOfFlightLookupTable)
    assert_identical(lut.array, loaded_lut.array)
    assert_identical(lut.pulse_period, loaded_lut.pulse_period)
    assert lut.pulse_stride == loaded_lut.pulse_stride
    assert_identical(lut.distance_resolution, loaded_lut.distance_resolution)
    assert_identical(lut.time_resolution, loaded_lut.time_resolution)
    assert_identical(lut.choppers, loaded_lut.choppers)

    detector = workflow.compute(time_of_flight.TofDetector[SampleRun])
    assert 'tof' in detector.bins.coords


@pytest.mark.parametrize("coord", ["tof", "wavelength"])
def test_GenericTofWorkflow_assigns_Ltotal_coordinate(workflow, coord):
    raw = workflow.compute(RawDetector[SampleRun])

    assert "Ltotal" not in raw.coords

    lut_wf = TofLookupTableWorkflow()
    lut_wf[DiskChoppers[AnyRun]] = fakes.psc_choppers()
    lut_wf[time_of_flight.NumberOfSimulatedNeutrons] = 10_000
    lut_wf[time_of_flight.LtotalRange] = (
        sc.scalar(20.0, unit="m"),
        sc.scalar(100.0, unit="m"),
    )
    lut_wf[time_of_flight.SourcePosition] = fakes.source_position()
    table = lut_wf.compute(time_of_flight.TofLookupTable)
    workflow[time_of_flight.TofLookupTable] = table

    if coord == "tof":
        result = workflow.compute(time_of_flight.TofDetector[SampleRun])
    else:
        result = workflow.compute(time_of_flight.WavelengthDetector[SampleRun])

    assert "Ltotal" in result.coords
