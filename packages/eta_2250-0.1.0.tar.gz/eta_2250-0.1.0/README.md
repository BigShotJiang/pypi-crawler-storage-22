# $\eta$-2250
---

η-2250 is a relativistic spaceship game set in a weird-realism sci-fi future. While Earth is ruled by a series of petty corporate barons, most Earthlings have no clue that the rest of the solar system is inhabited by the descendents of the first intrepid explorers who set off for mars before the onset of the Kessler Era of space travel. For the first time in over a century, humanity is returning to the stars, and YOU are lucky enough to join the crew of the Agartha under the daring Captain Serrano.