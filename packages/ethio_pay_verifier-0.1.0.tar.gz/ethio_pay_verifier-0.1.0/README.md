# Ethio-Pay-Verifier

A lightweight, pure-Python library to verify payment receipts from major Ethiopian banks directly against their official public endpoints. No third-party APIs, no middleware—just direct verification.

## 🚀 Features

- **Direct Verification**: Hits the official bank endpoints directly.
- **Support for Major Banks**:
    - **CBE** (Commercial Bank of Ethiopia) - PDF Parsing
    - **Telebirr** (Ethio Telecom) - HTML Scraping
    - **Bank of Abyssinia** - JSON API
    - **Dashen Bank** - PDF Parsing
    - **CBE Birr** - PDF Parsing
- **Clean Business Logic**: Includes utilities for name normalization, masked account matching, and amount verification.
- **Lightweight**: Just a few dependencies (`requests`, `beautifulsoup4`, `PyPDF2`, `pdfplumber`).

## 📦 Installation

```bash
pip install ethio-pay-verifier
```

## 🛠 Usage

### Using the Unified Verifier

The `PaymentVerifier` class provides a single interface for all banks and includes common business rules like amount checking and receiver validation.

```python
from python_verifier import PaymentVerifier

v = PaymentVerifier()

# 1. Telebirr
result = v.verify("telebirr", reference="CE2513001XYT")

# 2. CBE (Requires 8-digit account suffix)
result = v.verify("cbe", reference="FT2513001V2G", account_suffix="12345678")

# 3. Abyssinia (Requires 5-digit account suffix)
result = v.verify("abyssinia", reference="FT23062669JJ", suffix="12345")

# 4. Dashen
result = v.verify("dashen", reference="TXN123456")

# 5. CBE Birr
result = v.verify("cbebirr", receipt_number="CGU9REIHHB", phone_number="251912345678")

if result.success:
    print(f"Verified {result.amount} ETB from {result.payer_name}")
```

### Direct Scraper Access

You can also call the scrapers directly if you don't need the high-level dispatcher rules:

```python
from python_verifier import verify_telebirr, verify_cbe

# Get Telebirr receipt object
receipt = verify_telebirr("CE2513001XYT")
if receipt.success:
    print(receipt.settled_amount)

# Get CBE result
cbe = verify_cbe("FT2513001V2G", "12345678")
```

## ⚖️ License

MIT License. See [LICENSE](LICENSE) for details.

## ⚠️ Disclaimer

This library is not affiliated with, maintained, or endorsed by any of the banks listed. It relies on scraping public endpoints, which may change without notice. Use in production at your own risk.
