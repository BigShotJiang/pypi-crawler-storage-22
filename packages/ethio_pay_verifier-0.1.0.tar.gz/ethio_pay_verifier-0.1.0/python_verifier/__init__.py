"""
python_verifier – Direct payment receipt verification against official bank endpoints.

Scrapes / queries the real bank websites:
    • CBE       → https://apps.cbe.com.et:100/
    • Telebirr  → https://transactioninfo.ethiotelecom.et/receipt/
    • Abyssinia → https://cs.bankofabyssinia.com/api/onlineSlip/getDetails/
    • Dashen    → https://receipt.dashensuperapp.com/receipt/
    • CBE Birr  → https://cbepay1.cbe.com.et/aureceipt

No third-party middleman APIs.
"""

__version__ = "0.1.0"

from .cbe import verify_cbe, CBEResult
from .telebirr import verify_telebirr, TelebirrReceipt
from .abyssinia import verify_abyssinia, AbyssiniaResult
from .dashen import verify_dashen, DashenResult
from .cbebirr import verify_cbebirr, CBEBirrReceipt
from .verification import PaymentVerifier, VerificationError

__all__ = [
    "verify_cbe",
    "CBEResult",
    "verify_telebirr",
    "TelebirrReceipt",
    "verify_abyssinia",
    "AbyssiniaResult",
    "verify_dashen",
    "DashenResult",
    "verify_cbebirr",
    "CBEBirrReceipt",
    "PaymentVerifier",
    "VerificationError",
]
