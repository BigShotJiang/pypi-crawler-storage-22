"""
Bank of Abyssinia receipt verification.

Official endpoint:
    https://cs.bankofabyssinia.com/api/onlineSlip/getDetails/?id={reference}{suffix}

Returns a **JSON** response with header/body structure.

Direct port of verifyAbyssinia.ts from the verifier-api source.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from datetime import datetime
from typing import Optional

import requests

logger = logging.getLogger(__name__)

# ── Official Bank of Abyssinia endpoint ───────────────────────────────
ABYSSINIA_BASE_URL = "https://cs.bankofabyssinia.com/api/onlineSlip/getDetails/"


@dataclass
class AbyssiniaResult:
    """Parsed fields from an Abyssinia JSON receipt."""
    success: bool
    payer: Optional[str] = None
    payer_account: Optional[str] = None
    receiver: Optional[str] = None
    receiver_account: Optional[str] = None
    amount: Optional[float] = None
    date: Optional[datetime] = None
    reference: Optional[str] = None
    reason: Optional[str] = None
    error: Optional[str] = None


def verify_abyssinia(reference: str, suffix: str) -> AbyssiniaResult:
    """
    Verify a Bank of Abyssinia payment by reference + 5-digit account suffix.

    Hits the official API:
        https://cs.bankofabyssinia.com/api/onlineSlip/getDetails/?id={reference}{suffix}

    Parses the JSON response and returns structured data.
    """
    api_url = f"{ABYSSINIA_BASE_URL}?id={reference}{suffix}"
    logger.info("Abyssinia verify  url=%s", api_url)

    try:
        resp = requests.get(
            api_url,
            timeout=30,
            headers={
                "User-Agent": (
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/91.0.4472.124 Safari/537.36"
                ),
                "Accept": "application/json, text/plain, */*",
                "Accept-Language": "en-US,en;q=0.9",
                "Cache-Control": "no-cache",
                "Pragma": "no-cache",
            },
        )
        resp.raise_for_status()
        logger.info("Abyssinia fetch OK  status=%d", resp.status_code)

        data = resp.json()
        logger.debug("Abyssinia JSON: %s", data)

        # ── Validate structure (mirrors the TS checks) ────────────────
        header = data.get("header")
        body = data.get("body")

        if not header or not isinstance(body, list):
            return AbyssiniaResult(
                success=False,
                error="Invalid response structure from Abyssinia API",
            )

        if header.get("status") != "success":
            return AbyssiniaResult(
                success=False,
                error=f"API returned error status: {header.get('status')}",
            )

        if len(body) == 0:
            return AbyssiniaResult(
                success=False,
                error="No transaction data found in response body",
            )

        # ── Map fields (mirrors the TS field mapping) ─────────────────
        txn = body[0]
        logger.debug("Abyssinia txn keys: %s", list(txn.keys()))

        transferred_str = txn.get("Transferred Amount", "")
        amount = None
        if transferred_str:
            cleaned = re.sub(r"[^\d.]", "", transferred_str)
            try:
                amount = float(cleaned)
            except ValueError:
                pass

        txn_date_str = txn.get("Transaction Date", "")
        date = None
        if txn_date_str:
            try:
                date = datetime.fromisoformat(txn_date_str)
            except ValueError:
                try:
                    date = datetime.strptime(txn_date_str, "%Y-%m-%d %H:%M:%S")
                except ValueError:
                    logger.warning("Could not parse Abyssinia date: %s", txn_date_str)

        payer = txn.get("Payer's Name")
        payer_account = txn.get("Source Account")
        receiver = txn.get("Source Account Name")  # maps to receiver per the TS code
        ref = txn.get("Transaction Reference")
        reason = txn.get("Narrative")

        # ── Validate essential fields ─────────────────────────────────
        if not ref or amount is None or not payer:
            return AbyssiniaResult(
                success=False,
                error="Missing essential fields in transaction data",
            )

        return AbyssiniaResult(
            success=True,
            payer=payer,
            payer_account=payer_account,
            receiver=receiver,
            receiver_account=None,  # not available in Abyssinia data
            amount=amount,
            date=date,
            reference=ref,
            reason=reason,
        )

    except requests.RequestException as exc:
        logger.error("Abyssinia fetch failed: %s", exc)
        return AbyssiniaResult(
            success=False,
            error=f"Failed to verify Abyssinia transaction: {exc}",
        )
