"""
CBE (Commercial Bank of Ethiopia) receipt verification.

Official endpoint:
    https://apps.cbe.com.et:100/?id={reference}{accountSuffix}

The bank returns a **PDF** receipt. We download it and parse the text
with PyPDF2 (or pdfplumber as fallback).

Direct port of verifyCBE.ts from the verifier-api source.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from datetime import datetime
from typing import Optional

import requests

logger = logging.getLogger(__name__)

# ── Official CBE endpoint ─────────────────────────────────────────────
CBE_BASE_URL = "https://apps.cbe.com.et:100/"


@dataclass
class CBEResult:
    """Parsed fields from a CBE receipt PDF."""
    success: bool
    payer: Optional[str] = None
    payer_account: Optional[str] = None
    receiver: Optional[str] = None
    receiver_account: Optional[str] = None
    amount: Optional[float] = None
    date: Optional[datetime] = None
    reference: Optional[str] = None
    reason: Optional[str] = None
    error: Optional[str] = None


def _title_case(s: str) -> str:
    return s.lower().title()


def _parse_cbe_pdf(pdf_bytes: bytes) -> CBEResult:
    """
    Extract transaction fields from a CBE receipt PDF.

    Tries PyPDF2 first, falls back to pdfplumber.
    Regex patterns are a faithful translation of parseCBEReceipt() in verifyCBE.ts.
    """
    raw_text = _extract_pdf_text(pdf_bytes)
    if raw_text is None:
        return CBEResult(success=False, error="Failed to extract text from PDF")

    # Collapse whitespace (exactly like the TS code)
    text = re.sub(r"\s+", " ", raw_text).strip()
    logger.debug("CBE PDF text (%d chars): %.300s…", len(text), text)

    # ── Field extraction (mirrors the TS regex patterns) ──────────────
    payer_name = _match(r"Payer\s*:?\s*(.*?)\s+Account", text)
    receiver_name = _match(r"Receiver\s*:?\s*(.*?)\s+Account", text)

    # Two Account lines in order (payer first, receiver second)
    account_matches = re.findall(r"Account\s*:?\s*([A-Z0-9]?\*{4}\d{4})", text, re.I)
    payer_account = account_matches[0] if len(account_matches) > 0 else None
    receiver_account = account_matches[1] if len(account_matches) > 1 else None

    reason = _match(
        r"Reason\s*/\s*Type of service\s*:?\s*(.*?)\s+Transferred Amount", text
    )
    amount_text = _match(r"Transferred Amount\s*:?\s*([\d,]+\.\d{2})\s*ETB", text)
    reference_match = _match(
        r"Reference No\.?\s*\(VAT Invoice No\)\s*:?\s*([A-Z0-9]+)", text
    )
    date_raw = _match(
        r"Payment Date & Time\s*:?\s*([\d/,: ]+[APM]{2})", text
    )

    amount = float(amount_text.replace(",", "")) if amount_text else None
    date = None
    if date_raw:
        try:
            date = datetime.strptime(date_raw, "%m/%d/%Y, %I:%M:%S %p")
        except ValueError:
            try:
                date = datetime.strptime(date_raw, "%d/%m/%Y, %I:%M:%S %p")
            except ValueError:
                logger.warning("Could not parse CBE date: %s", date_raw)

    payer_name = _title_case(payer_name) if payer_name else None
    receiver_name = _title_case(receiver_name) if receiver_name else None

    if all([payer_name, payer_account, receiver_name, receiver_account, amount, date, reference_match]):
        return CBEResult(
            success=True,
            payer=payer_name,
            payer_account=payer_account,
            receiver=receiver_name,
            receiver_account=receiver_account,
            amount=amount,
            date=date,
            reference=reference_match,
            reason=reason,
        )
    else:
        return CBEResult(
            success=False,
            error="Could not extract all required fields from PDF.",
        )


def verify_cbe(reference: str, account_suffix: str) -> CBEResult:
    """
    Verify a CBE payment by reference number + 8-digit account suffix.

    Hits the official CBE endpoint:
        https://apps.cbe.com.et:100/?id={reference}{accountSuffix}

    Returns the parsed receipt or an error.
    """
    full_id = f"{reference}{account_suffix}"
    url = f"{CBE_BASE_URL}?id={full_id}"

    logger.info("CBE verify  url=%s", url)

    try:
        resp = requests.get(
            url,
            verify=False,  # CBE uses a cert that often fails validation
            timeout=30,
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
                "Accept": "application/pdf",
            },
        )
        resp.raise_for_status()
        logger.info("CBE fetch OK  status=%d  size=%d", resp.status_code, len(resp.content))
        return _parse_cbe_pdf(resp.content)

    except requests.RequestException as exc:
        logger.error("CBE fetch failed: %s", exc)
        return CBEResult(success=False, error=f"Failed to fetch CBE receipt: {exc}")


# ── Internal helpers ──────────────────────────────────────────────────

def _match(pattern: str, text: str) -> Optional[str]:
    m = re.search(pattern, text, re.I)
    return m.group(1).strip() if m else None


def _extract_pdf_text(pdf_bytes: bytes) -> Optional[str]:
    """Extract text from PDF bytes. Tries PyPDF2, then pdfplumber."""
    # Try PyPDF2 first
    try:
        import io
        from PyPDF2 import PdfReader

        reader = PdfReader(io.BytesIO(pdf_bytes))
        pages_text = [page.extract_text() or "" for page in reader.pages]
        text = "\n".join(pages_text)
        if text.strip():
            return text
    except Exception as e:
        logger.debug("PyPDF2 failed: %s", e)

    # Fallback: pdfplumber
    try:
        import io
        import pdfplumber

        with pdfplumber.open(io.BytesIO(pdf_bytes)) as pdf:
            pages_text = [page.extract_text() or "" for page in pdf.pages]
            text = "\n".join(pages_text)
            if text.strip():
                return text
    except Exception as e:
        logger.debug("pdfplumber failed: %s", e)

    return None
