"""
CBE Birr (CBE mobile money) receipt verification.

Official endpoint:
    https://cbepay1.cbe.com.et/aureceipt?TID={receiptNumber}&PH={phoneNumber}

Returns a **PDF** receipt.

Direct port of verifyCBEBirr.ts from the verifier-api source.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from typing import Optional

import requests

logger = logging.getLogger(__name__)

# ── Official CBE Birr endpoint ────────────────────────────────────────
CBEBIRR_BASE_URL = "https://cbepay1.cbe.com.et/aureceipt"


@dataclass
class CBEBirrReceipt:
    """Parsed fields from a CBE Birr receipt PDF."""
    success: bool = False
    customer_name: str = ""
    debit_account: str = ""
    credit_account: str = ""
    receiver_name: str = ""
    order_id: str = ""
    transaction_status: str = ""
    reference: str = ""
    receipt_number: str = ""
    transaction_date: str = ""
    amount: str = ""
    paid_amount: str = ""
    service_charge: str = ""
    vat: str = ""
    total_paid_amount: str = ""
    payment_reason: str = ""
    payment_channel: str = ""
    error: Optional[str] = None


def _extract_value(text: str, pattern: str) -> str:
    """Extract a value from PDF text using a regex pattern."""
    m = re.search(pattern, text, re.I)
    result = m.group(1).strip() if m else ""
    logger.debug("Pattern %s matched: '%s'", pattern, result)
    return result


def _parse_cbebirr_pdf(pdf_text: str) -> Optional[CBEBirrReceipt]:
    """
    Parse a CBE Birr receipt from extracted PDF text.
    Regex patterns ported from parseCBEBirrReceipt() in verifyCBEBirr.ts.
    """
    try:
        logger.info("Parsing CBE Birr PDF text (%d chars)", len(pdf_text))

        customer_name = (
            _extract_value(pdf_text, r"Customer Name:\s*([^\n\r]+?)(?=\s*Region:)")
        )

        debit_account = ""  # Not reliably present in the PDF

        credit_account = (
            _extract_value(pdf_text, r"Credit Account[\s\n\r]+([^\n\r]+?)(?=\s*Receiver Name)")
        )

        receiver_name = (
            _extract_value(pdf_text, r"Receiver Name[\s\n\r]+([^\n\r]+?)(?=\s*Order ID)")
        )

        order_id = (
            _extract_value(pdf_text, r"Order ID[\s\n\r]+([A-Z0-9]+)")
            or _extract_value(pdf_text, r"(FT\d+[A-Z0-9]*)")
        )

        transaction_status = (
            _extract_value(pdf_text, r"Transaction Status[\s\n\r]+([^\n\r]+?)(?=\s*Reference)")
            or "Completed"
        )

        reference = (
            _extract_value(pdf_text, r"Reference[\s\n\r]+([^\n\r]+?)(?=\s*Receipt Number)")
            or order_id
        )

        receipt_number = (
            _extract_value(pdf_text, r"(CGU[A-Z0-9]+)")
        )

        transaction_date = (
            _extract_value(pdf_text, r"(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2})")
        )

        amount = (
            _extract_value(pdf_text, r"([\d,]+\.\d{2})")
        )

        paid_amount = (
            _extract_value(pdf_text, r"Paid amount[\s\n\r]*([\d,]+\.\d{2})")
            or amount
        )
        service_charge = (
            _extract_value(pdf_text, r"Service Charge[\s\n\r]*([\d,]+\.\d{2})")
            or "0.00"
        )
        vat = (
            _extract_value(pdf_text, r"VAT[\s\n\r]*([\d,]+\.\d{2})")
            or "0.00"
        )
        total_paid_amount = (
            _extract_value(pdf_text, r"Total Paid Amount[\s\n\r]*([\d,]+\.\d{2})")
            or amount
        )

        payment_reason = (
            _extract_value(pdf_text, r"(TransferFromBankToMM[^\n\r]*)")
            or ""
        )
        payment_channel = (
            _extract_value(pdf_text, r"(USSD)")
            or ""
        )

        receipt = CBEBirrReceipt(
            customer_name=customer_name,
            debit_account=debit_account,
            credit_account=credit_account,
            receiver_name=receiver_name,
            order_id=order_id,
            transaction_status=transaction_status,
            reference=reference,
            receipt_number=receipt_number,
            transaction_date=transaction_date,
            amount=amount,
            paid_amount=paid_amount,
            service_charge=service_charge,
            vat=vat,
            total_paid_amount=total_paid_amount,
            payment_reason=payment_reason,
            payment_channel=payment_channel,
        )

        if not customer_name and not receipt_number and not amount:
            logger.warning("No essential fields found in CBE Birr PDF")
            return None

        receipt.success = True
        return receipt

    except Exception as e:
        logger.error("Error parsing CBE Birr PDF: %s", e)
        return None


def verify_cbebirr(receipt_number: str, phone_number: str) -> CBEBirrReceipt:
    """
    Verify a CBE Birr payment by receipt number + phone number.

    Hits the official endpoint:
        https://cbepay1.cbe.com.et/aureceipt?TID={receiptNumber}&PH={phoneNumber}

    Downloads the PDF and parses it.
    """
    url = f"{CBEBIRR_BASE_URL}?TID={receipt_number}&PH={phone_number}"
    logger.info("CBE Birr verify  url=%s", url)

    try:
        resp = requests.get(
            url,
            timeout=30,
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            },
        )
        resp.raise_for_status()
        logger.info("CBE Birr fetch OK  status=%d  size=%d", resp.status_code, len(resp.content))

        # Parse PDF
        pdf_text = _extract_pdf_text(resp.content)
        if pdf_text is None:
            return CBEBirrReceipt(
                success=False,
                error="Failed to extract text from CBE Birr PDF",
            )

        result = _parse_cbebirr_pdf(pdf_text)
        if result is None:
            return CBEBirrReceipt(
                success=False,
                error="Failed to parse receipt data from PDF",
            )
        return result

    except requests.RequestException as exc:
        logger.error("CBE Birr fetch failed: %s", exc)
        return CBEBirrReceipt(
            success=False,
            error=f"Failed to fetch CBE Birr receipt: {exc}",
        )


def _extract_pdf_text(pdf_bytes: bytes) -> Optional[str]:
    """Extract text from PDF bytes — tries PyPDF2, then pdfplumber."""
    try:
        import io
        from PyPDF2 import PdfReader

        reader = PdfReader(io.BytesIO(pdf_bytes))
        text = "\n".join(page.extract_text() or "" for page in reader.pages)
        if text.strip():
            return text
    except Exception as e:
        logger.debug("PyPDF2 failed: %s", e)

    try:
        import io
        import pdfplumber

        with pdfplumber.open(io.BytesIO(pdf_bytes)) as pdf:
            text = "\n".join(page.extract_text() or "" for page in pdf.pages)
            if text.strip():
                return text
    except Exception as e:
        logger.debug("pdfplumber failed: %s", e)

    return None
