"""
Configuration management for the payment verifier.

Loads settings from environment variables and provides
per-user config overrides (mirrors UserConfig from the original schema).
"""

import os
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class UserConfig:
    """Per-user payment verification config (mirrors the Prisma UserConfig model)."""
    platform_owner_fullname: Optional[str] = None
    telebirr_number: Optional[str] = None          # e.g. "2519xxxxxxxx"
    cbe_account_suffix: Optional[str] = None       # 8 digits
    cbe_account_number: Optional[str] = None       # 13 digits
    abyssinia_account_suffix: Optional[str] = None  # 5 digits
    abyssinia_account_number: Optional[str] = None


@dataclass
class AppConfig:
    """
    Global app configuration resolved from env vakrs.
    Acts as the fallback when no per-user config or explicit input config is provided.
    """
    verifier_api_key: str = ""
    verifier_base_url: str = "https://verifyapi.leulzenebe.pro"
    verifier_timeout: int = 20  # seconds

    # Platform owner identity (fallback for Telebirr name validation)
    platform_owner_fullname: str = ""

    # CBE: 8-digit account suffix
    cbe_account_suffix: str = ""

    # Abyssinia: 5-digit account suffix
    abyssinia_account_suffix: str = ""

    # Public-facing payment destination numbers (informational)
    telebirr_number: str = ""
    cbe_account_number: str = ""
    abyssinia_account_number: str = ""

    @classmethod
    def from_env(cls) -> "AppConfig":
        """Build config from environment variables."""
        return cls(
            verifier_api_key=os.getenv("VERIFIER_API_KEY", ""),
            verifier_base_url=os.getenv("VERIFIER_BASE_URL", "https://verifyapi.leulzenebe.pro"),
            verifier_timeout=int(os.getenv("VERIFIER_TIMEOUT", "20")),
            platform_owner_fullname=os.getenv("PLATFORM_OWNER_FULLNAME", ""),
            cbe_account_suffix=os.getenv("CBE_ACCOUNT_SUFFIX", ""),
            abyssinia_account_suffix=os.getenv("ABYSSINIA_ACCOUNT_SUFFIX", ""),
            telebirr_number=os.getenv("NEXT_PUBLIC_TELEBIRR_NUMBER", ""),
            cbe_account_number=os.getenv("NEXT_PUBLIC_CBE_ACCOUNT_NUMBER", ""),
            abyssinia_account_number=os.getenv("NEXT_PUBLIC_ABYSSINIA_ACCOUNT_NUMBER", ""),
        )


# ---------------------------------------------------------------------------
# Package / pricing definitions (mirrors the PACKAGES const in purchase.ts)
# ---------------------------------------------------------------------------

@dataclass
class Package:
    """A purchasable token package."""
    id: int
    price: int   # ETB
    tokens: int


PACKAGES: dict[int, Package] = {
    1: Package(id=1, price=50, tokens=50),
    2: Package(id=2, price=200, tokens=200),
    3: Package(id=3, price=500, tokens=500),
}
