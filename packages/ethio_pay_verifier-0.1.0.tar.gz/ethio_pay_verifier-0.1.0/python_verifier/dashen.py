"""
Dashen Bank receipt verification.

Official endpoint:
    https://receipt.dashensuperapp.com/receipt/{transactionReference}

Returns a **PDF** receipt. We download and parse it.

Direct port of verifyDashen.ts from the verifier-api source.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from datetime import datetime
from typing import Optional

import requests

logger = logging.getLogger(__name__)

# ── Official Dashen endpoint ──────────────────────────────────────────
DASHEN_BASE_URL = "https://receipt.dashensuperapp.com/receipt/"


@dataclass
class DashenResult:
    """Parsed fields from a Dashen Bank receipt PDF."""
    success: bool
    sender_name: Optional[str] = None
    sender_account_number: Optional[str] = None
    transaction_channel: Optional[str] = None
    service_type: Optional[str] = None
    narrative: Optional[str] = None
    receiver_name: Optional[str] = None
    phone_no: Optional[str] = None
    institution_name: Optional[str] = None
    transaction_reference: Optional[str] = None
    transfer_reference: Optional[str] = None
    transaction_date: Optional[datetime] = None
    transaction_amount: Optional[float] = None
    service_charge: Optional[float] = None
    excise_tax: Optional[float] = None
    vat: Optional[float] = None
    penalty_fee: Optional[float] = None
    income_tax_fee: Optional[float] = None
    interest_fee: Optional[float] = None
    stamp_duty: Optional[float] = None
    discount_amount: Optional[float] = None
    total: Optional[float] = None
    error: Optional[str] = None


def _title_case(s: str) -> str:
    return s.lower().title()


def _extract_amount(text: str, pattern: str) -> Optional[float]:
    """Extract a monetary amount using a regex pattern."""
    m = re.search(pattern, text, re.I)
    if m and m.group(1):
        cleaned = m.group(1).replace(",", "")
        try:
            return float(cleaned)
        except ValueError:
            return None
    return None


def _match(pattern: str, text: str) -> Optional[str]:
    m = re.search(pattern, text, re.I)
    return m.group(1).strip() if m else None


def _parse_dashen_pdf(pdf_bytes: bytes) -> DashenResult:
    """
    Parse a Dashen Bank receipt PDF.
    Regex patterns ported from parseDashenReceipt() in verifyDashen.ts.
    """
    raw_text = _extract_pdf_text(pdf_bytes)
    if raw_text is None:
        return DashenResult(success=False, error="Failed to extract text from PDF")

    text = re.sub(r"\s+", " ", raw_text).strip()
    logger.debug("Dashen PDF text (%d chars): %.300s…", len(text), text)

    # ── Sender info ───────────────────────────────────────────────────
    sender_name = _match(r"Sender\s*Name\s*:?\s*(.*?)\s+(?:Sender\s*Account|Account)", text)
    sender_account = _match(r"Sender\s*Account\s*(?:Number)?\s*:?\s*([A-Z0-9\*\-]+)", text)

    # ── Transaction details ───────────────────────────────────────────
    transaction_channel = _match(r"Transaction\s*Channel\s*:?\s*(.*?)\s+(?:Service|Type)", text)
    service_type = _match(r"Service\s*Type\s*:?\s*(.*?)\s+(?:Narrative|Description)", text)
    narrative = _match(r"Narrative\s*:?\s*(.*?)\s+(?:Receiver|Phone)", text)

    # ── Receiver info ─────────────────────────────────────────────────
    receiver_name = _match(r"Receiver\s*Name\s*:?\s*(.*?)\s+(?:Phone|Institution)", text)
    phone_no = _match(r"Phone\s*(?:No\.?|Number)?\s*:?\s*([\+\d\-\s]+)", text)
    institution_name = _match(r"Institution\s*Name\s*:?\s*(.*?)\s+(?:Transaction|Reference)", text)

    # ── References ────────────────────────────────────────────────────
    transaction_reference = _match(r"Transaction\s*Reference\s*:?\s*([A-Z0-9\-]+)", text)
    transfer_reference = _match(r"Transfer\s*Reference\s*:?\s*([A-Z0-9\-]+)", text)

    # ── Date ──────────────────────────────────────────────────────────
    date_raw = _match(r"Transaction\s*Date\s*(?:&\s*Time)?\s*:?\s*([\d/\-,: ]+(?:[APM]{2})?)", text)
    transaction_date = None
    if date_raw:
        try:
            transaction_date = datetime.strptime(date_raw.strip(), "%m/%d/%Y, %I:%M:%S %p")
        except ValueError:
            try:
                transaction_date = datetime.strptime(date_raw.strip(), "%Y-%m-%d %H:%M:%S")
            except ValueError:
                logger.warning("Could not parse Dashen date: %s", date_raw)

    # ── Amounts ───────────────────────────────────────────────────────
    transaction_amount = _extract_amount(text, r"Transaction\s*Amount\s*(?:ETB|Birr)?\s*([\d,]+\.?\d*)")
    service_charge = _extract_amount(text, r"Service\s*Charge\s*(?:ETB|Birr)?\s*([\d,]+\.?\d*)")
    excise_tax = _extract_amount(text, r"Excise\s*Tax\s*(?:\(15%\))?\s*(?:ETB|Birr)?\s*([\d,]+\.?\d*)")
    vat = _extract_amount(text, r"VAT\s*(?:\(15%\))?\s*(?:ETB|Birr)?\s*([\d,]+\.?\d*)")
    penalty_fee = _extract_amount(text, r"Penalty\s*Fee\s*(?:ETB|Birr)?\s*([\d,]+\.?\d*)")
    income_tax_fee = _extract_amount(text, r"Income\s*Tax\s*Fee\s*(?:ETB|Birr)?\s*([\d,]+\.?\d*)")
    interest_fee = _extract_amount(text, r"Interest\s*Fee\s*(?:ETB|Birr)?\s*([\d,]+\.?\d*)")
    stamp_duty = _extract_amount(text, r"Stamp\s*Duty\s*(?:ETB|Birr)?\s*([\d,]+\.?\d*)")
    discount_amount = _extract_amount(text, r"Discount\s*Amount\s*(?:ETB|Birr)?\s*([\d,]+\.?\d*)")
    total = _extract_amount(text, r"Total\s*(?:ETB|Birr)?\s*([\d,]+\.?\d*)")

    # ── Title-case names ──────────────────────────────────────────────
    sender_name = _title_case(sender_name) if sender_name else None
    receiver_name = _title_case(receiver_name) if receiver_name else None
    institution_name = _title_case(institution_name) if institution_name else None

    if transaction_reference and transaction_amount is not None:
        return DashenResult(
            success=True,
            sender_name=sender_name,
            sender_account_number=sender_account,
            transaction_channel=transaction_channel,
            service_type=service_type,
            narrative=narrative,
            receiver_name=receiver_name,
            phone_no=phone_no,
            institution_name=institution_name,
            transaction_reference=transaction_reference,
            transfer_reference=transfer_reference,
            transaction_date=transaction_date,
            transaction_amount=transaction_amount,
            service_charge=service_charge,
            excise_tax=excise_tax,
            vat=vat,
            penalty_fee=penalty_fee,
            income_tax_fee=income_tax_fee,
            interest_fee=interest_fee,
            stamp_duty=stamp_duty,
            discount_amount=discount_amount,
            total=total,
        )
    else:
        return DashenResult(
            success=False,
            error="Could not extract required fields (Transaction Reference and Amount) from PDF.",
        )


def verify_dashen(transaction_reference: str) -> DashenResult:
    """
    Verify a Dashen Bank payment by transaction reference.

    Hits the official endpoint:
        https://receipt.dashensuperapp.com/receipt/{transactionReference}

    Downloads the PDF receipt and parses it.
    """
    url = f"{DASHEN_BASE_URL}{transaction_reference}"
    logger.info("Dashen verify  url=%s", url)

    try:
        resp = requests.get(
            url,
            verify=False,
            timeout=30,
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
                "Accept": "application/pdf",
            },
        )
        resp.raise_for_status()
        logger.info("Dashen fetch OK  status=%d  size=%d", resp.status_code, len(resp.content))
        return _parse_dashen_pdf(resp.content)

    except requests.RequestException as exc:
        logger.error("Dashen fetch failed: %s", exc)
        return DashenResult(
            success=False,
            error=f"Failed to fetch Dashen receipt: {exc}",
        )


def _extract_pdf_text(pdf_bytes: bytes) -> Optional[str]:
    """Extract text from PDF bytes — tries PyPDF2, then pdfplumber."""
    try:
        import io
        from PyPDF2 import PdfReader

        reader = PdfReader(io.BytesIO(pdf_bytes))
        text = "\n".join(page.extract_text() or "" for page in reader.pages)
        if text.strip():
            return text
    except Exception as e:
        logger.debug("PyPDF2 failed: %s", e)

    try:
        import io
        import pdfplumber

        with pdfplumber.open(io.BytesIO(pdf_bytes)) as pdf:
            text = "\n".join(page.extract_text() or "" for page in pdf.pages)
            if text.strip():
                return text
    except Exception as e:
        logger.debug("pdfplumber failed: %s", e)

    return None
