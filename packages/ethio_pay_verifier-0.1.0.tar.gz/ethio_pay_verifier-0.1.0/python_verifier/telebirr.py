"""
Telebirr (Ethio Telecom) receipt verification.

Official endpoint:
    https://transactioninfo.ethiotelecom.et/receipt/{reference}

Returns an **HTML page** with an Amharic/English receipt table.
Scraped with BeautifulSoup (Cheerio equivalent in Python).

Direct port of verifyTelebirr.ts from the verifier-api source.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from typing import Optional

import requests
from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)

# ── Official Telebirr endpoint ────────────────────────────────────────
TELEBIRR_PRIMARY_URL = "https://transactioninfo.ethiotelecom.et/receipt/"


@dataclass
class TelebirrReceipt:
    """Parsed fields from a Telebirr HTML receipt."""
    success: bool = False
    payer_name: str = ""
    payer_telebirr_no: str = ""
    credited_party_name: str = ""
    credited_party_account_no: str = ""
    transaction_status: str = ""
    receipt_no: str = ""
    payment_date: str = ""
    settled_amount: str = ""
    service_fee: str = ""
    service_fee_vat: str = ""
    total_paid_amount: str = ""
    bank_name: str = ""
    error: Optional[str] = None


# =====================================================================
# Regex extractors (ported from the TS code)
# =====================================================================

def _extract_settled_amount_regex(html: str) -> Optional[str]:
    """Multiple patterns to extract settled amount — mirrors the TS version."""
    patterns = [
        # Pattern 1: Amharic + English label → value
        r'የተከፈለው\s+መጠን/Settled\s+Amount.*?</td>\s*<td[^>]*>\s*(\d+(?:\.\d{2})?\s+Birr)',
        # Pattern 2: table-row structure
        r'<tr[^>]*>.*?የተከፈለው\s+መጠን/Settled\s+Amount.*?<td[^>]*>\s*(\d+(?:\.\d{2})?\s+Birr)',
        # Pattern 3: flexible
        r'Settled\s+Amount.*?(\d+(?:\.\d{2})?\s+Birr)',
    ]
    for pat in patterns:
        m = re.search(pat, html, re.I | re.S)
        if m:
            return m.group(1).strip()
    return None


def _extract_service_fee_regex(html: str) -> Optional[str]:
    """Extract service fee (excluding VAT line)."""
    pat = r'የአገልግሎት\s+ክፍያ/Service\s+fee(?!\s+ተ\.እ\.ታ).*?</td>\s*<td[^>]*>\s*(\d+(?:\.\d{2})?\s+Birr)'
    m = re.search(pat, html, re.I)
    return m.group(1).strip() if m else None


def _extract_receipt_no_regex(html: str) -> Optional[str]:
    pat = r'<td[^>]*class="[^"]*receipttableTd[^"]*receipttableTd2[^"]*"[^>]*>\s*([A-Z0-9]+)\s*</td>'
    m = re.search(pat, html, re.I)
    return m.group(1).strip() if m else None


def _extract_date_regex(html: str) -> Optional[str]:
    pat = r'(\d{2}-\d{2}-\d{4}\s+\d{2}:\d{2}:\d{2})'
    m = re.search(pat, html)
    return m.group(1).strip() if m else None


def _extract_with_regex(html: str, label: str) -> Optional[str]:
    """Generic: find a label in a <td>, then grab the next <td> value."""
    escaped = re.escape(label)
    pat = rf'{escaped}.*?</td>\s*<td[^>]*>\s*([^<]+)'
    m = re.search(pat, html, re.I)
    if m:
        return re.sub(r'<[^>]*>', '', m.group(1)).strip()
    return None


# =====================================================================
# BeautifulSoup scraper  (equivalent of scrapeTelebirrReceipt in TS)
# =====================================================================

def _scrape_telebirr_html(html: str) -> TelebirrReceipt:
    """Parse the Telebirr HTML receipt page using BS4 + regex fallbacks."""
    soup = BeautifulSoup(html, "html.parser")

    def get_text(label: str) -> str:
        """Find a <td> containing `label`, return the next sibling <td> text."""
        td = soup.find("td", string=re.compile(re.escape(label), re.I))
        if td:
            nxt = td.find_next_sibling("td")
            if nxt:
                return nxt.get_text(strip=True)
        # Fallback to regex
        val = _extract_with_regex(html, label)
        return val or ""

    def get_payment_date() -> str:
        d = _extract_date_regex(html)
        if d:
            return d
        # BS4 fallback: find a td with a date-like pattern
        for td in soup.select(".receipttableTd"):
            txt = td.get_text(strip=True)
            if "-202" in txt:
                return txt
        return ""

    def get_receipt_no() -> str:
        r = _extract_receipt_no_regex(html)
        if r:
            return r
        tds = soup.select("td.receipttableTd.receipttableTd2")
        if len(tds) >= 2:
            return tds[1].get_text(strip=True)
        return ""

    def get_settled_amount() -> str:
        a = _extract_settled_amount_regex(html)
        if a:
            return a
        # BS4 fallback
        for td in soup.select("td.receipttableTd.receipttableTd2"):
            prev = td.find_previous_sibling("td")
            if prev and ("የተከፈለው መጠን" in prev.get_text() or "Settled Amount" in prev.get_text()):
                return td.get_text(strip=True)
        return ""

    def get_service_fee() -> str:
        f = _extract_service_fee_regex(html)
        if f:
            return f
        for td in soup.select("td.receipttableTd1"):
            txt = td.get_text()
            if ("የአገልግሎት ክፍያ" in txt or "Service fee" in txt) and "ተ.እ.ታ" not in txt and "VAT" not in txt:
                nxt = td.find_next_sibling("td", class_=re.compile("receipttableTd2"))
                if nxt:
                    return nxt.get_text(strip=True)
        return ""

    # ── Extract credited party / bank account logic ───────────────────
    credited_party_name = get_text("የገንዘብ ተቀባይ ስም/Credited Party name")
    credited_party_account_no = get_text("የገንዘብ ተቀባይ ቴሌብር ቁ./Credited party account no")
    bank_name = ""

    bank_account_raw = get_text("የባንክ አካውንት ቁጥር/Bank account number")
    if bank_account_raw:
        bank_name = credited_party_name  # original name is the bank
        m = re.match(r"(\d+)\s+(.*)", bank_account_raw)
        if m:
            credited_party_account_no = m.group(1).strip()
            credited_party_name = m.group(2).strip()

    receipt = TelebirrReceipt(
        payer_name=get_text("የከፋይ ስም/Payer Name"),
        payer_telebirr_no=get_text("የከፋይ ቴሌብር ቁ./Payer telebirr no."),
        credited_party_name=credited_party_name,
        credited_party_account_no=credited_party_account_no,
        transaction_status=get_text("የክፍያው ሁኔታ/transaction status"),
        receipt_no=get_receipt_no(),
        payment_date=get_payment_date(),
        settled_amount=get_settled_amount(),
        service_fee=get_service_fee(),
        service_fee_vat=get_text("የአገልግሎት ክፍያ ተ.እ.ታ/Service fee VAT"),
        total_paid_amount=get_text("ጠቅላላ የተከፈለ/Total Paid Amount"),
        bank_name=bank_name,
    )

    # Validate essential fields
    if receipt.receipt_no and receipt.payer_name and receipt.transaction_status:
        receipt.success = True
    else:
        receipt.error = "Could not extract essential fields from Telebirr receipt"

    return receipt


# =====================================================================
# Public API
# =====================================================================

def verify_telebirr(reference: str) -> TelebirrReceipt:
    """
    Verify a Telebirr payment by reference number.

    Hits the official Ethio Telecom endpoint:
        https://transactioninfo.ethiotelecom.et/receipt/{reference}

    Scrapes the HTML receipt and returns parsed fields.
    """
    url = f"{TELEBIRR_PRIMARY_URL}{reference}"
    logger.info("Telebirr verify  url=%s", url)

    try:
        resp = requests.get(url, timeout=15, headers={
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
            "Accept": "text/html",
        })
        resp.raise_for_status()
        logger.info("Telebirr fetch OK  status=%d  size=%d", resp.status_code, len(resp.text))

        if len(resp.text) < 100:
            logger.warning("Suspiciously short response (%d bytes)", len(resp.text))

        receipt = _scrape_telebirr_html(resp.text)
        return receipt

    except requests.RequestException as exc:
        logger.error("Telebirr fetch failed: %s", exc)
        return TelebirrReceipt(
            success=False,
            error=f"Failed to fetch Telebirr receipt: {exc}",
        )
