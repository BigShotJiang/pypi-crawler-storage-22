"""
High-level verification dispatcher.

Provides a single `PaymentVerifier` class that routes to the correct
bank scraper based on the provider name. Also includes the business
logic from the Next.js starter (amount checks, name matching, etc.).
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from typing import Any, Optional

from .cbe import verify_cbe, CBEResult
from .telebirr import verify_telebirr, TelebirrReceipt
from .abyssinia import verify_abyssinia, AbyssiniaResult
from .dashen import verify_dashen, DashenResult
from .cbebirr import verify_cbebirr, CBEBirrReceipt

logger = logging.getLogger(__name__)


class VerificationError(Exception):
    """Raised when verification fails for any provider."""
    def __init__(self, message: str, code: str = "BAD_REQUEST"):
        super().__init__(message)
        self.code = code


# ── Utility helpers (from the starter project's purchase.ts) ──────────

def normalize_name(v: str) -> str:
    """Normalize to lowercase single-space form."""
    return re.sub(r"\s+", " ", v.strip().lower())


def only_digits(s: str) -> str:
    return re.sub(r"\D", "", s)


def matches_masked_account(masked: str, full: str) -> bool:
    """Compare a masked account (e.g. '2519****4243') to a full number."""
    m = masked.strip()
    f = only_digits(full.strip())
    has_mask = bool(re.search(r"[*xX•]", m))

    prefix_m = re.match(r"^(\d+)", m)
    suffix_m = re.search(r"(\d+)$", m)
    prefix = prefix_m.group(1) if prefix_m else ""
    suffix = suffix_m.group(1) if suffix_m else ""

    if has_mask:
        if prefix and not f.startswith(prefix):
            return False
        if suffix and not f.endswith(suffix):
            return False
        return True

    return only_digits(m) == f


# ── Standardised result ───────────────────────────────────────────────

@dataclass
class VerifyResult:
    """Unified result across all providers."""
    success: bool
    provider: str
    reference: str = ""
    amount: Optional[float] = None
    payer_name: Optional[str] = None
    receiver_name: Optional[str] = None
    receiver_account: Optional[str] = None
    payer_account: Optional[str] = None
    txn_date: Optional[str] = None
    status: Optional[str] = None
    reason: Optional[str] = None
    error: Optional[str] = None
    raw: Any = None


# ── Main dispatcher ──────────────────────────────────────────────────

class PaymentVerifier:
    """
    Routes verification requests to the correct bank scraper.

    Usage:
        v = PaymentVerifier()
        result = v.verify("telebirr", reference="CE2513001XYT")
        result = v.verify("cbe", reference="FT2513001V2G", account_suffix="39003377")
        result = v.verify("abyssinia", reference="FT23062669JJ", suffix="90172")
        result = v.verify("dashen", reference="TXN123456")
        result = v.verify("cbebirr", receipt_number="CGU9REIHHB", phone_number="251912345678")
    """

    def verify(self, provider: str, **kwargs: Any) -> VerifyResult:
        """
        Verify a payment receipt against the official bank endpoint.

        Args:
            provider: One of "telebirr", "cbe", "abyssinia", "dashen", "cbebirr".
            **kwargs: Provider-specific params (reference, account_suffix, suffix,
                      receipt_number, phone_number).

        Returns:
            Unified VerifyResult.
        """
        provider = provider.lower().strip()

        if provider == "telebirr":
            return self._verify_telebirr(**kwargs)
        elif provider == "cbe":
            return self._verify_cbe(**kwargs)
        elif provider == "abyssinia":
            return self._verify_abyssinia(**kwargs)
        elif provider == "dashen":
            return self._verify_dashen(**kwargs)
        elif provider == "cbebirr":
            return self._verify_cbebirr(**kwargs)
        else:
            raise VerificationError(f"Unsupported provider: {provider}")

    # ── Provider implementations ──────────────────────────────────────

    def _verify_telebirr(self, reference: str, **_: Any) -> VerifyResult:
        r = verify_telebirr(reference)
        if not r.success:
            return VerifyResult(success=False, provider="telebirr", error=r.error)

        # Parse amount from "123.00 Birr" format
        amount = _parse_birr_amount(r.settled_amount)

        return VerifyResult(
            success=True,
            provider="telebirr",
            reference=r.receipt_no,
            amount=amount,
            payer_name=r.payer_name,
            receiver_name=r.credited_party_name,
            receiver_account=r.credited_party_account_no,
            payer_account=r.payer_telebirr_no,
            txn_date=r.payment_date,
            status=r.transaction_status,
            raw=r,
        )

    def _verify_cbe(self, reference: str, account_suffix: str, **_: Any) -> VerifyResult:
        r = verify_cbe(reference, account_suffix)
        if not r.success:
            return VerifyResult(success=False, provider="cbe", error=r.error)

        return VerifyResult(
            success=True,
            provider="cbe",
            reference=r.reference or "",
            amount=r.amount,
            payer_name=r.payer,
            receiver_name=r.receiver,
            receiver_account=r.receiver_account,
            payer_account=r.payer_account,
            txn_date=r.date.isoformat() if r.date else None,
            reason=r.reason,
            raw=r,
        )

    def _verify_abyssinia(self, reference: str, suffix: str, **_: Any) -> VerifyResult:
        r = verify_abyssinia(reference, suffix)
        if not r.success:
            return VerifyResult(success=False, provider="abyssinia", error=r.error)

        return VerifyResult(
            success=True,
            provider="abyssinia",
            reference=r.reference or "",
            amount=r.amount,
            payer_name=r.payer,
            receiver_name=r.receiver,
            payer_account=r.payer_account,
            txn_date=r.date.isoformat() if r.date else None,
            reason=r.reason,
            raw=r,
        )

    def _verify_dashen(self, reference: str, **_: Any) -> VerifyResult:
        r = verify_dashen(reference)
        if not r.success:
            return VerifyResult(success=False, provider="dashen", error=r.error)

        return VerifyResult(
            success=True,
            provider="dashen",
            reference=r.transaction_reference or "",
            amount=r.transaction_amount,
            payer_name=r.sender_name,
            receiver_name=r.receiver_name,
            payer_account=r.sender_account_number,
            txn_date=r.transaction_date.isoformat() if r.transaction_date else None,
            reason=r.narrative,
            raw=r,
        )

    def _verify_cbebirr(self, receipt_number: str, phone_number: str, **_: Any) -> VerifyResult:
        r = verify_cbebirr(receipt_number, phone_number)
        if not r.success:
            return VerifyResult(success=False, provider="cbebirr", error=r.error)

        # Parse amount string
        amount = None
        if r.amount:
            try:
                amount = float(r.amount.replace(",", ""))
            except ValueError:
                pass

        return VerifyResult(
            success=True,
            provider="cbebirr",
            reference=r.reference,
            amount=amount,
            payer_name=r.customer_name,
            receiver_name=r.receiver_name,
            receiver_account=r.credit_account,
            txn_date=r.transaction_date,
            status=r.transaction_status,
            reason=r.payment_reason,
            raw=r,
        )


# ── Helpers ───────────────────────────────────────────────────────────

def _parse_birr_amount(s: str) -> Optional[float]:
    """Parse '123.00 Birr' or '1,234.56 Birr' → float."""
    if not s:
        return None
    cleaned = re.sub(r"[^\d.]", "", s.replace(",", ""))
    try:
        return float(cleaned)
    except ValueError:
        return None
