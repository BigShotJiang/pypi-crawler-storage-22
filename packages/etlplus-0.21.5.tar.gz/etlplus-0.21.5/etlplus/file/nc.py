"""
:mod:`etlplus.file.nc` module.

Helpers for reading/writing NetCDF (NC) data files.

Notes
-----
- A NC file is a binary file format used for array-oriented scientific data,
    particularly in meteorology, oceanography, and climate science.
- Common cases:
    - Storing multi-dimensional scientific data.
    - Sharing large datasets in research communities.
    - Efficient data access and manipulation.
- Rule of thumb:
    - If the file follows the NetCDF standard, use this module for reading and
        writing.
"""

from __future__ import annotations

from pathlib import Path

from ..types import JSONData
from ..types import JSONList
from ..types import StrPath
from ._imports import get_dependency
from ._imports import get_pandas
from ._io import call_deprecated_module_read
from ._io import call_deprecated_module_write
from ._io import ensure_parent_dir
from ._io import normalize_records
from ._io import records_from_table
from .base import ReadOptions
from .base import SingleDatasetScientificFileHandlerABC
from .base import WriteOptions
from .enums import FileFormat

# SECTION: EXPORTS ========================================================== #


__all__ = [
    # Classes
    'NcFile',
    # Functions
    'read',
    'write',
]


# SECTION: INTERNAL FUNCTIONS =============================================== #


def _raise_engine_error(
    err: ImportError,
) -> None:
    """
    Raise a consistent ImportError for missing NetCDF engine support.

    Parameters
    ----------
    err : ImportError
        The original ImportError raised when trying to use NetCDF support
        without the required dependency.

    Raises
    ------
    ImportError
        Consistent ImportError indicating that NetCDF support requires
        optional dependencies.
    """
    raise ImportError(
        'NC support requires optional dependency "netCDF4" or "h5netcdf".\n'
        'Install with: pip install netCDF4',
    ) from err


# SECTION: CLASSES ========================================================== #


class NcFile(SingleDatasetScientificFileHandlerABC):
    """
    Handler implementation for NC files.
    """

    # -- Class Attributes -- #

    format = FileFormat.NC
    dataset_key = 'data'

    # -- Instance Methods -- #

    def read_dataset(
        self,
        path: Path,
        *,
        dataset: str | None = None,
        options: ReadOptions | None = None,
    ) -> JSONList:
        """
        Read and return one dataset from NC at *path*.

        Parameters
        ----------
        path : Path
            Path to the NC file on disk.
        dataset : str | None, optional
            Dataset selector. Use the default dataset key or ``None``.
        options : ReadOptions | None, optional
            Optional read parameters.

        Returns
        -------
        JSONList
            Parsed records.
        """
        self.resolve_single_read_dataset(
            dataset,
            options=options,
        )
        format_name = self.format_name
        xarray = get_dependency('xarray', format_name=format_name)
        try:
            xarray_dataset = xarray.open_dataset(path)
        except ImportError as err:  # pragma: no cover
            _raise_engine_error(err)
        with xarray_dataset as ds:
            frame = ds.to_dataframe().reset_index()
        if 'index' in frame.columns:
            values = list(frame['index'])
            if values == list(range(len(values))):
                frame = frame.drop(columns=['index'])
        return records_from_table(frame)

    def write_dataset(
        self,
        path: Path,
        data: JSONData,
        *,
        dataset: str | None = None,
        options: WriteOptions | None = None,
    ) -> int:
        """
        Write one dataset to NC at *path* and return record count.

        Parameters
        ----------
        path : Path
            Path to the NC file on disk.
        data : JSONData
            Dataset payload to write.
        dataset : str | None, optional
            Dataset selector. Use the default dataset key or ``None``.
        options : WriteOptions | None, optional
            Optional write parameters.

        Returns
        -------
        int
            Number of records written.
        """
        self.resolve_single_write_dataset(
            dataset,
            options=options,
        )

        format_name = self.format_name
        records = normalize_records(data, format_name)
        if not records:
            return 0

        xarray = get_dependency('xarray', format_name=format_name)
        pandas = get_pandas(format_name)
        frame = pandas.DataFrame.from_records(records)
        ds = xarray.Dataset.from_dataframe(frame)
        ensure_parent_dir(path)
        try:
            ds.to_netcdf(path)
        except ImportError as err:  # pragma: no cover
            _raise_engine_error(err)
        return len(records)


# SECTION: INTERNAL CONSTANTS =============================================== #

_NC_HANDLER = NcFile()


# SECTION: FUNCTIONS ======================================================== #


def read(
    path: StrPath,
) -> JSONData:
    """
    Deprecated wrapper. Use ``NcFile().read(...)`` instead.

    Parameters
    ----------
    path : StrPath
        Path to the NC file on disk.

    Returns
    -------
    JSONData
        The structured data read from the NC file.
    """
    return call_deprecated_module_read(
        path,
        __name__,
        _NC_HANDLER.read,
    )


def write(
    path: StrPath,
    data: JSONData,
) -> int:
    """
    Deprecated wrapper. Use ``NcFile().write(...)`` instead.

    Parameters
    ----------
    path : StrPath
        Path to the NC file on disk.
    data : JSONData
        Data to write as NC file. Should be a list of dictionaries or a
        single dictionary.

    Returns
    -------
    int
        The number of rows written to the NC file.
    """
    return call_deprecated_module_write(
        path,
        data,
        __name__,
        _NC_HANDLER.write,
    )
