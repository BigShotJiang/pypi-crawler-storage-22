"""
:mod:`etlplus.file.psv` module.

Helpers for reading/writing Pipe-Separated Values (PSV) files.

Notes
-----
- A PSV file is a plain text file that uses the pipe character (`|`) to
    separate values.
- Common cases:
    - Each line in the file represents a single record.
    - The first line often contains headers that define the column names.
    - Values may be enclosed in quotes, especially if they contain pipes
        or special characters.
- Rule of thumb:
    - If the file follows the PSV specification, use this module for
        reading and writing.
"""

from __future__ import annotations

from pathlib import Path

from ..types import JSONData
from ..types import JSONList
from ..types import StrPath
from ._io import call_deprecated_module_read
from ._io import call_deprecated_module_write
from ._io import read_delimited
from ._io import write_delimited
from .base import DelimitedTextFileHandlerABC
from .base import ReadOptions
from .base import WriteOptions
from .enums import FileFormat

# SECTION: EXPORTS ========================================================== #


__all__ = [
    # Classes
    'PsvFile',
    # Functions
    'read',
    'write',
]


# SECTION: CLASSES ========================================================== #


class PsvFile(DelimitedTextFileHandlerABC):
    """
    Handler implementation for PSV files.
    """

    # -- Class Attributes -- #

    format = FileFormat.PSV
    delimiter = '|'

    # -- Instance Methods -- #

    def read_rows(
        self,
        path: Path,
        *,
        options: ReadOptions | None = None,
    ) -> JSONList:
        """
        Read delimited PSV rows from *path*.

        Parameters
        ----------
        path : Path
            Path to the PSV file on disk.
        options : ReadOptions | None, optional
            Optional read parameters. Extra key ``delimiter`` can override
            :attr:`delimiter`.

        Returns
        -------
        JSONList
            Parsed rows.
        """
        return read_delimited(
            path,
            delimiter=self.delimiter_from_read_options(options),
        )

    def write_rows(
        self,
        path: Path,
        rows: JSONList,
        *,
        options: WriteOptions | None = None,
    ) -> int:
        """
        Write PSV *rows* to *path*.

        Parameters
        ----------
        path : Path
            Path to the PSV file on disk.
        rows : JSONList
            Rows to write.
        options : WriteOptions | None, optional
            Optional write parameters. Extra key ``delimiter`` can override
            :attr:`delimiter`.

        Returns
        -------
        int
            The number of rows written to the PSV file.
        """
        return write_delimited(
            path,
            rows,
            delimiter=self.delimiter_from_write_options(options),
            format_name='PSV',
        )


# SECTION: INTERNAL CONSTANTS =============================================== #

_PSV_HANDLER = PsvFile()


# SECTION: FUNCTIONS ======================================================== #


def read(
    path: StrPath,
) -> JSONList:
    """
    Deprecated wrapper. Use ``PsvFile().read(...)`` instead.

    Parameters
    ----------
    path : StrPath
        Path to the PSV file on disk.

    Returns
    -------
    JSONList
        The list of dictionaries read from the PSV file.
    """
    return call_deprecated_module_read(
        path,
        __name__,
        _PSV_HANDLER.read,
    )


def write(
    path: StrPath,
    data: JSONData,
) -> int:
    """
    Deprecated wrapper. Use ``PsvFile().write(...)`` instead.

    Parameters
    ----------
    path : StrPath
        Path to the PSV file on disk.
    data : JSONData
        Data to write as PSV file. Should be a list of dictionaries or a
        single dictionary.

    Returns
    -------
    int
        The number of rows written to the PSV file.
    """
    return call_deprecated_module_write(
        path,
        data,
        __name__,
        _PSV_HANDLER.write,
    )
