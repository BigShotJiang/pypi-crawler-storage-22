class LogicError(Exception):
    pass
