"""Evaldeck test suite."""
