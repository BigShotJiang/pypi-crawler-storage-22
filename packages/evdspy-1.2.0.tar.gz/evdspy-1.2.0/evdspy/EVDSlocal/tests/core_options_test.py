
""" Test Options """
verbose = False