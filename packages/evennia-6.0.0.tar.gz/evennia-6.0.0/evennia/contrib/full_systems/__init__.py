"""
Complete game implementations/engines.

"""
