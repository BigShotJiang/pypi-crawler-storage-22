from .namespace import list_namespaces

__all__ = ["list_namespaces"]
