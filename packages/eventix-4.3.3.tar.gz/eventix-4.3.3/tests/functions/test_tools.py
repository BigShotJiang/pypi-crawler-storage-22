from eventix import __version__


def test_version():
    print(__version__)
