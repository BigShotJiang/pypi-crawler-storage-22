from __future__ import annotations


__all__ = ['Event', 'ExtendedEvent']

from collections.abc import Iterator
from types import MappingProxyType
from typing import TYPE_CHECKING

from typing_extensions import Any
from collections import defaultdict


if TYPE_CHECKING:
    from eventry.asyncio.middleware_manager import MiddlewareManagerTypes
    from eventry.asyncio.handler_manager import HandlerManager


class EventBase:
    if TYPE_CHECKING:
        __event_name__: str

    __handled__: bool = False

    def __init_subclass__(cls, **kwargs: Any) -> None:
        name = kwargs.pop('event_name', None)

        if not getattr(cls, '__event_name__', None):
            if name is None:
                raise TypeError(
                    f'{cls.__name__} must be defined with keyword argument \'event_name\'.'
                )

            if not isinstance(name, str):
                raise ValueError(
                    f'Event name for class {cls.__name__} must be a string, '
                    f'got {type(name).__name__}.'
                )

        if name is not None:
            cls.__event_name__ = name
        super().__init_subclass__(**kwargs)

    @property
    def name(self) -> str:
        return self.__event_name__


class Event(EventBase, event_name='event'):
    """
    Base event class.
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._propagation_stopped = False

        self.__inherited_middlewares__: dict[
            MiddlewareManagerTypes,
            dict[HandlerManager, list[Any]]
        ] = defaultdict(lambda: defaultdict(list))

    def __inherit_manager__(self, handler_manager: HandlerManager) -> None:
        from eventry.asyncio.middleware_manager import MiddlewareManagerTypes

        for i in MiddlewareManagerTypes:
            manager = handler_manager.middleware_manager(i)
            if manager is None:
                continue
            self.__inherited_middlewares__[i][handler_manager].extend(
                manager.inheritable_middlewares
            )

    def __renounce_manager__(self, handler_manager: HandlerManager) -> None:
        for middleware_type, data in self.__inherited_middlewares__.items():
            if handler_manager in data:
                del self.__inherited_middlewares__[middleware_type][handler_manager]

    def __get_inherited_middlewares__(self, middleware_type: MiddlewareManagerTypes) -> list[Any]:
        return [
            mdw
            for mdw_list in self.__inherited_middlewares__[middleware_type].values()
            for mdw in mdw_list
        ]

    def stop_propagation(self) -> None:
        """
        Stop further propagation of this event.

        Once called, the dispatcher will no longer deliver the event
        to subsequent handlers.
        """
        self._propagation_stopped = True

    @property
    def event_context_injection(self) -> dict[str, Any]:
        """
        Data to inject into the event context.

        Subclasses may override this property to provide additional
        key-value pairs that will be merged into the event context.

        :return: A dictionary with event-specific context data.
        """
        return {}

    @property
    def propagation_stopped(self) -> bool:
        """
        Check whether the event propagation has been stopped.

        :return: ``True`` if propagation has been stopped, otherwise ``False``.
        """
        return self._propagation_stopped


class ExtendedEvent(Event, event_name='event'):
    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """
        Extended event class with flags and data features.
        """

        super().__init__(*args, **kwargs)
        self._data: dict[Any, Any] = {}
        self._flags: set[Any] = set()

    def __setitem__(self, key: Any, value: Any) -> None:
        self._data[key] = value

    def __getitem__(self, key: Any) -> Any:
        return self._data[key]

    def __contains__(self, key: Any) -> bool:
        return key in self._data

    def __iter__(self) -> Iterator[Any]:
        return iter(self._data)

    def set_flag(self, flag: Any) -> None:
        self._flags.add(flag)

    def set_flags(self, *flags: Any) -> None:
        self._flags.update(flags)

    def unset_flag(self, flag: Any) -> None:
        if flag in self._flags:
            self._flags.remove(flag)

    def unset_flags(self, *flags: Any) -> None:
        self._flags.difference_update(flags)

    def has_flag(self, flag: Any) -> bool:
        return flag in self._flags

    @property
    def flags(self) -> frozenset[Any]:
        return frozenset(self._flags)

    @property
    def data(self) -> MappingProxyType[Any, Any]:
        return MappingProxyType(self._data)


