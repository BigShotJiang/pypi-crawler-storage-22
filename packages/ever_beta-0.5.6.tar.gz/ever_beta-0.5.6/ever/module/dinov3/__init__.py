# Copyright (c) Meta Platforms, Inc. and affiliates.
#
# This software may be used and distributed in accordance with
# the terms of the DINOv3 License Agreement.
from ever.module.dinov3.models.vision_transformer import *
from ever.module.dinov3.models.convnext import get_convnext_arch

__version__ = "0.0.1"
