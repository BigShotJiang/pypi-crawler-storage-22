# Eversolar PMU Protocol

Protocol implementation for Eversolar PMU devices, extracted from the
`eversolar-pmu-ha` Home Assistant integration.

## Install

```bash
pip install eversolar-pmu-protocol
```

## Usage

```python
from eversolar_pmu_protocol import EversolarPMU

pmu = EversolarPMU("192.0.2.10", 8080, timeout=5.0)
data = pmu.connect_and_poll()
print(data["power_w"], data["pv_v"], data["pv_a"])
```

## API

The main entry point is `EversolarPMU`, which provides:

- `test_connection(host, port, timeout=5.0) -> bool`
- `connect_and_poll(set_time=False, tz_name="Australia/Brisbane") -> dict`
- `sync_time(tz_name="Australia/Brisbane") -> bool`

The returned dict includes both parsed values and the raw 16-bit values:

- `power_w`, `vac_v`, `fac_hz`, `e_today_kwh`, `e_total_kwh`, `h_total_hours`
- `mode`, `pv_v`, `pv_a`, `pv_w_est`, `error_flags`
- `pmu_time_utc`, `time_delta`, `pmu_epoch`
- `raw_u16` (mapping of hex code string to raw value)

## License

GPL-3.0
