# SPDX-License-Identifier: GPL-3.0
# Copyright (C) 2026 Anthony Burow

"""Public API for the Eversolar PMU protocol package."""
from importlib.metadata import PackageNotFoundError, version

from .protocol import (
    EversolarPMU,
    SYNC,
    build_init_payload,
    build_req,
    crc16_xmodem,
    decode_normal_info_from_resp14,
    parse_code_list_from_resp12,
    parse_inverter_id,
    recv_exact,
    recv_frame,
    tz_field_84,
)

__all__ = [
    "EversolarPMU",
    "SYNC",
    "build_init_payload",
    "build_req",
    "crc16_xmodem",
    "decode_normal_info_from_resp14",
    "parse_code_list_from_resp12",
    "parse_inverter_id",
    "recv_exact",
    "recv_frame",
    "tz_field_84",
]

try:
    __version__ = version("eversolar-pmu-protocol")
except PackageNotFoundError:
    __version__ = "0.0.0"
