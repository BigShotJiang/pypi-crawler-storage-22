# SPDX-License-Identifier: GPL-3.0

from datetime import datetime, timezone

from eversolar_pmu_protocol import (
    build_init_payload,
    build_req,
    decode_normal_info_from_resp14,
    parse_code_list_from_resp12,
    parse_inverter_id,
    tz_field_84,
)


def test_tz_field_len_and_padding():
    field = tz_field_84("Test TZ")
    assert len(field) == 84
    assert field[-2:] == b"\x00\x00"


def test_build_init_payload_length():
    payload = build_init_payload(datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc))
    assert len(payload) == 188


def test_build_req_frame_size_and_sync():
    payload = b"\x01\x02\x03"
    frame = build_req(0x11, payload)
    # sync(2) + cmd(1) + 0x00(1) + len(1) + payload + crc(2)
    assert frame[:2] == b"\xAA\x55"
    assert len(frame) == 2 + 1 + 1 + 1 + len(payload) + 2


def test_parse_inverter_id_and_codes():
    inverter_id = b"ABCD1234EFGH5678"
    codes = bytes([0x01, 0x00, 0x02, 0x03, 0x00, 0x00, 0x00, 0x00])
    payload = inverter_id + codes
    resp12 = b"\xAA\x55\x12\x00" + bytes([len(payload)]) + payload

    assert parse_inverter_id(resp12) == inverter_id.decode("ascii")
    parsed_codes = parse_code_list_from_resp12(resp12)
    assert parsed_codes[:4] == [0x01, 0x00, 0x02, 0x03]


def test_decode_normal_info_from_resp14():
    codes = [0x01, 0x02, 0x03]
    # payload[0:8] header bytes, then 3 uint16 values (LE)
    values = [0x0011, 0x2233, 0x4455]
    data = bytearray(8)
    for v in values:
        data += bytes([v & 0xFF, (v >> 8) & 0xFF])

    resp14 = b"\xAA\x55\x14\x00" + bytes([len(data)]) + bytes(data)
    decoded = decode_normal_info_from_resp14(resp14, codes)

    assert decoded == {0x01: 0x0011, 0x02: 0x2233, 0x03: 0x4455}
