Individual
============

.. autoclass:: evolib.core.individual.Indiv
   :members:
   :undoc-members:
   :show-inheritance:
