EvoNet
===================

.. automodule:: evolib.representation.evonet
   :members:
   :undoc-members:
   :show-inheritance:
