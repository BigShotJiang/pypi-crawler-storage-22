"""evolv Agent SDK for Python."""

from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any, Generic, TypeVar

from ._errors import (
    CLIConnectionError,
    CLIJSONDecodeError,
    CLINotFoundError,
    EvolvSDKError,
    ProcessError,
)
from ._internal.transport import Transport
from ._version import __version__
from .client import EvolvSDKClient
from .query import query
from .types import (
    AgentDefinition,
    AssistantMessage,
    CanUseTool,
    ContentBlock,
    EvolvAgentOptions,
    HookCallback,
    HookContext,
    HookEvent,
    HookInput,
    HookJSONOutput,
    HookMatcher,
    McpSdkServerConfig,
    McpServerConfig,
    Message,
    PermissionMode,
    PermissionResult,
    PermissionResultAllow,
    PermissionResultDeny,
    PermissionUpdate,
    PostToolUseHookInput,
    PreToolUseHookInput,
    ResultMessage,
    SdkBeta,
    SettingSource,
    SyncHookJSONOutput,
    SystemMessage,
    TextBlock,
    ThinkingBlock,
    ToolPermissionContext,
    ToolResultBlock,
    ToolUseBlock,
    UserMessage,
)

# MCP Server Support

T = TypeVar("T")


@dataclass
class SdkMcpTool(Generic[T]):
    """Definition for an SDK MCP tool."""

    name: str
    description: str
    input_schema: type[T] | dict[str, Any]
    handler: Callable[[T], Awaitable[dict[str, Any]]]


def tool(
    name: str, description: str, input_schema: type | dict[str, Any]
) -> Callable[[Callable[[Any], Awaitable[dict[str, Any]]]], SdkMcpTool[Any]]:
    """Decorator for defining MCP tools with type safety.

    Creates a tool that can be used with SDK MCP servers. The tool runs
    in-process within your Python application, providing better performance
    than external MCP servers.

    Args:
        name: Unique identifier for the tool.
        description: Human-readable description of what the tool does.
        input_schema: Schema defining the tool's input parameters.

    Returns:
        A decorator function that wraps the tool implementation.

    Example:
        ```python
        @tool("greet", "Greet a user", {"name": str})
        async def greet(args):
            return {"content": [{"type": "text", "text": f"Hello, {args['name']}!"}]}
        ```
    """

    def decorator(
        handler: Callable[[Any], Awaitable[dict[str, Any]]],
    ) -> SdkMcpTool[Any]:
        return SdkMcpTool(
            name=name,
            description=description,
            input_schema=input_schema,
            handler=handler,
        )

    return decorator


def create_sdk_mcp_server(
    name: str, version: str = "1.0.0", tools: list[SdkMcpTool[Any]] | None = None
) -> McpSdkServerConfig:
    """Create an in-process MCP server that runs within your Python application.

    Unlike external MCP servers that run as separate processes, SDK MCP servers
    run directly in your application's process.

    Args:
        name: Unique identifier for the server.
        version: Server version string. Defaults to "1.0.0".
        tools: List of SdkMcpTool instances created with the @tool decorator.

    Returns:
        McpSdkServerConfig: A configuration object for use with EvolvAgentOptions.

    Example:
        ```python
        @tool("add", "Add numbers", {"a": float, "b": float})
        async def add(args):
            return {"content": [{"type": "text", "text": f"Sum: {args['a'] + args['b']}"}]}

        calculator = create_sdk_mcp_server(
            name="calculator",
            tools=[add]
        )

        options = EvolvAgentOptions(
            mcp_servers={"calc": calculator},
        )
        ```
    """
    from mcp.server import Server
    from mcp.types import ImageContent, TextContent, Tool

    server = Server(name, version=version)

    if tools:
        tool_map = {tool_def.name: tool_def for tool_def in tools}

        @server.list_tools()  # type: ignore[no-untyped-call,untyped-decorator]
        async def list_tools() -> list[Tool]:
            """Return the list of available tools."""
            tool_list = []
            for tool_def in tools:
                if isinstance(tool_def.input_schema, dict):
                    if (
                        "type" in tool_def.input_schema
                        and "properties" in tool_def.input_schema
                    ):
                        schema = tool_def.input_schema
                    else:
                        properties = {}
                        for param_name, param_type in tool_def.input_schema.items():
                            if param_type is str:
                                properties[param_name] = {"type": "string"}
                            elif param_type is int:
                                properties[param_name] = {"type": "integer"}
                            elif param_type is float:
                                properties[param_name] = {"type": "number"}
                            elif param_type is bool:
                                properties[param_name] = {"type": "boolean"}
                            else:
                                properties[param_name] = {"type": "string"}
                        schema = {
                            "type": "object",
                            "properties": properties,
                            "required": list(properties.keys()),
                        }
                else:
                    schema = {"type": "object", "properties": {}}

                tool_list.append(
                    Tool(
                        name=tool_def.name,
                        description=tool_def.description,
                        inputSchema=schema,
                    )
                )
            return tool_list

        @server.call_tool()  # type: ignore[untyped-decorator]
        async def call_tool(name: str, arguments: dict[str, Any]) -> Any:
            """Execute a tool by name with given arguments."""
            if name not in tool_map:
                raise ValueError(f"Tool '{name}' not found")

            tool_def = tool_map[name]
            result = await tool_def.handler(arguments)

            content: list[TextContent | ImageContent] = []
            if "content" in result:
                for item in result["content"]:
                    if item.get("type") == "text":
                        content.append(TextContent(type="text", text=item["text"]))
                    if item.get("type") == "image":
                        content.append(
                            ImageContent(
                                type="image",
                                data=item["data"],
                                mimeType=item["mimeType"],
                            )
                        )

            return content

    return McpSdkServerConfig(type="sdk", name=name, instance=server)


# Backward compatibility aliases
CortexSDKClient = EvolvSDKClient
CortexAgentOptions = EvolvAgentOptions
CortexSDKError = EvolvSDKError
ClaudeSDKClient = EvolvSDKClient
ClaudeAgentOptions = EvolvAgentOptions
ClaudeSDKError = EvolvSDKError


__all__ = [
    # Main exports
    "query",
    "__version__",
    # Transport
    "Transport",
    "EvolvSDKClient",
    # Types
    "PermissionMode",
    "McpServerConfig",
    "McpSdkServerConfig",
    "UserMessage",
    "AssistantMessage",
    "SystemMessage",
    "ResultMessage",
    "Message",
    "EvolvAgentOptions",
    "TextBlock",
    "ThinkingBlock",
    "ToolUseBlock",
    "ToolResultBlock",
    "ContentBlock",
    # Tool callbacks
    "CanUseTool",
    "ToolPermissionContext",
    "PermissionResult",
    "PermissionResultAllow",
    "PermissionResultDeny",
    "PermissionUpdate",
    # Hooks
    "HookCallback",
    "HookContext",
    "HookEvent",
    "HookInput",
    "HookJSONOutput",
    "HookMatcher",
    "PreToolUseHookInput",
    "PostToolUseHookInput",
    "SyncHookJSONOutput",
    # Agent support
    "AgentDefinition",
    "SettingSource",
    # Beta support
    "SdkBeta",
    # MCP Server Support
    "create_sdk_mcp_server",
    "tool",
    "SdkMcpTool",
    # Errors
    "EvolvSDKError",
    "CLIConnectionError",
    "CLINotFoundError",
    "ProcessError",
    "CLIJSONDecodeError",
    # Backward compatibility aliases
    "CortexSDKClient",
    "CortexAgentOptions",
    "CortexSDKError",
    "ClaudeSDKClient",
    "ClaudeAgentOptions",
    "ClaudeSDKError",
]
