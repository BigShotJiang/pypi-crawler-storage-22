"""evolv CLI version tracking."""

CLI_VERSION = "1.0.5"
