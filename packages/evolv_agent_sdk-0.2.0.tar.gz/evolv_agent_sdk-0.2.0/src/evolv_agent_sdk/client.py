"""evolv SDK Client for interacting with evolv Code."""

import os
from collections.abc import AsyncIterator
from typing import Any

from ._errors import CLIConnectionError
from ._internal.message_parser import parse_message
from ._internal.query import Query
from ._internal.transport.subprocess_cli import SubprocessCLITransport
from .types import (
    EvolvAgentOptions,
    Message,
    PermissionMode,
    ResultMessage,
)


class EvolvSDKClient:
    """
    Client for conversations with evolv Code.

    This client supports two modes:

    1. **Standard Mode**:
       - Each query() spawns a new process
       - No bidirectional communication
       - Limited to basic queries

    2. **Bidirectional Mode** (evolv Code required):
       - Persistent connection with JSON protocol
       - Supports can_use_tool callbacks
       - Supports hooks (PreToolUse, PostToolUse, etc.)
       - Supports SDK MCP servers (in-process tools)
       - Supports runtime control: interrupt(), set_permission_mode(), set_model()

    Bidirectional mode is automatically enabled when:
    - can_use_tool callback is provided
    - hooks are configured
    - mcp_servers with SDK type are configured

    Example (Standard Mode):
        ```python
        async with EvolvSDKClient() as client:
            await client.query("What files are here?")
            async for msg in client.receive_response():
                print(msg)
        ```

    Example (Bidirectional Mode):
        ```python
        async def my_can_use_tool(tool_name, tool_input, context):
            if "rm -rf" in tool_input.get("command", ""):
                return PermissionResultDeny(message="Blocked!")
            return PermissionResultAllow()

        options = EvolvAgentOptions(
            cli_path="/path/to/evolv",
            can_use_tool=my_can_use_tool,
            hooks={
                "PreToolUse": [HookMatcher(matcher="*", hooks=[my_hook])],
            },
        )

        async with EvolvSDKClient(options=options) as client:
            await client.query("Do something")
            async for msg in client.receive_response():
                print(msg)

            # Runtime control (bidirectional mode only)
            await client.set_permission_mode("acceptEdits")
            await client.interrupt()
        ```
    """

    def __init__(
        self,
        options: EvolvAgentOptions | None = None,
    ):
        """Initialize evolv SDK client."""
        if options is None:
            options = EvolvAgentOptions()
        self.options = options
        self._current_transport: SubprocessCLITransport | None = None
        self._query: Query | None = None
        self._connected = False
        self._bidirectional_mode = False

        # Determine if bidirectional mode is needed
        self._bidirectional_mode = (
            options.can_use_tool is not None
            or options.hooks is not None
            or self._has_sdk_mcp_servers()
        )

        entrypoint = "sdk-py-client-bidirectional" if self._bidirectional_mode else "sdk-py-client"
        os.environ["EVOLV_CODE_ENTRYPOINT"] = entrypoint

    def _has_sdk_mcp_servers(self) -> bool:
        """Check if options include SDK MCP servers."""
        if not self.options.mcp_servers:
            return False
        if isinstance(self.options.mcp_servers, dict):
            for config in self.options.mcp_servers.values():
                if isinstance(config, dict) and config.get("type") == "sdk":
                    return True
        return False

    def _get_sdk_mcp_servers(self) -> dict[str, Any]:
        """Extract SDK MCP server instances from options."""
        servers = {}
        if isinstance(self.options.mcp_servers, dict):
            for name, config in self.options.mcp_servers.items():
                if isinstance(config, dict) and config.get("type") == "sdk":
                    servers[name] = config.get("instance")
        return servers

    def _build_hooks_config(self) -> dict[str, list[dict[str, Any]]] | None:
        """Convert hooks to format expected by Query class."""
        if not self.options.hooks:
            return None

        hooks_config: dict[str, list[dict[str, Any]]] = {}
        for event, matchers in self.options.hooks.items():
            hooks_config[event] = []
            for matcher in matchers:
                hooks_config[event].append({
                    "matcher": matcher.matcher,
                    "hooks": matcher.hooks,
                    "timeout": matcher.timeout,
                })
        return hooks_config

    async def connect(self) -> None:
        """
        Prepare the client for queries.

        In bidirectional mode, this starts the CLI process and initializes
        the control protocol. In standard mode, this just marks the client
        as ready (processes are started per-query).
        """
        self._connected = True

    async def query(self, prompt: str) -> None:
        """
        Send a query to the agent.

        Args:
            prompt: The prompt to send

        In standard mode, this starts a new process for the query.
        In bidirectional mode, this sends the query through the existing connection.
        """
        if not self._connected:
            raise CLIConnectionError("Not connected. Call connect() first.")

        # Create transport for this query
        self._current_transport = SubprocessCLITransport(
            prompt=prompt,
            options=self.options,
            bidirectional=self._bidirectional_mode,
        )
        await self._current_transport.connect()

        # In bidirectional mode, wrap with Query for control protocol
        if self._bidirectional_mode:
            self._query = Query(
                transport=self._current_transport,
                is_streaming_mode=True,
                can_use_tool=self.options.can_use_tool,
                hooks=self._build_hooks_config(),
                sdk_mcp_servers=self._get_sdk_mcp_servers(),
            )
            await self._query.start()
            await self._query.initialize()
            # Send the user message through the bidirectional protocol
            await self._query.send_user_message(prompt)

    async def receive_messages(self) -> AsyncIterator[Message]:
        """Receive all messages from the current query."""
        if not self._current_transport:
            raise CLIConnectionError("No active query. Call query() first.")

        if self._bidirectional_mode and self._query:
            # Use Query's message stream for bidirectional mode
            async for data in self._query._message_receive:
                if data.get("type") == "end":
                    break
                if data.get("type") == "error":
                    raise CLIConnectionError(data.get("error", "Unknown error"))
                yield parse_message(data)
        else:
            # Standard mode - read directly from transport
            async for data in self._current_transport.read_messages():
                yield parse_message(data)

        # Clean up after reading all messages
        await self._cleanup_query()

    async def receive_response(self) -> AsyncIterator[Message]:
        """
        Receive messages until and including a ResultMessage.

        This async iterator yields all messages in sequence and automatically
        terminates after yielding a ResultMessage.

        Yields:
            Message: Each message received
        """
        async for message in self.receive_messages():
            yield message
            if isinstance(message, ResultMessage):
                return

    async def interrupt(self) -> None:
        """
        Interrupt the current operation.

        This sends an interrupt signal to cancel any ongoing processing.
        Only available in bidirectional mode (requires evolv Code).

        Raises:
            CLIConnectionError: If not in bidirectional mode or not connected
        """
        if not self._bidirectional_mode:
            raise CLIConnectionError(
                "interrupt() requires bidirectional mode. "
                "Enable by providing can_use_tool, hooks, or SDK MCP servers."
            )
        if not self._query:
            raise CLIConnectionError("No active query to interrupt.")

        await self._query.interrupt()

    async def set_permission_mode(self, mode: PermissionMode) -> None:
        """
        Change the permission mode at runtime.

        Permission modes:
        - "default": Standard prompting for dangerous operations
        - "acceptEdits": Auto-accept file modifications
        - "plan": Show planned actions without executing
        - "bypassPermissions": Allow all operations (use with caution!)

        Only available in bidirectional mode (requires evolv Code).

        Args:
            mode: The permission mode to set

        Raises:
            CLIConnectionError: If not in bidirectional mode or not connected
        """
        if not self._bidirectional_mode:
            raise CLIConnectionError(
                "set_permission_mode() requires bidirectional mode. "
                "Enable by providing can_use_tool, hooks, or SDK MCP servers."
            )
        if not self._query:
            raise CLIConnectionError("No active query.")

        await self._query.set_permission_mode(mode)

    async def set_model(self, model: str | None) -> None:
        """
        Change the AI model at runtime.

        Only available in bidirectional mode (requires evolv Code).

        Args:
            model: The model identifier, or None to use default

        Raises:
            CLIConnectionError: If not in bidirectional mode or not connected
        """
        if not self._bidirectional_mode:
            raise CLIConnectionError(
                "set_model() requires bidirectional mode. "
                "Enable by providing can_use_tool, hooks, or SDK MCP servers."
            )
        if not self._query:
            raise CLIConnectionError("No active query.")

        await self._query.set_model(model)

    async def rewind_files(self, user_message_id: str) -> None:
        """
        Rewind tracked files to their state at a specific user message.

        This allows undoing file changes made after a particular point
        in the conversation.

        Only available in bidirectional mode (requires evolv Code).

        Args:
            user_message_id: The message ID to rewind to

        Raises:
            CLIConnectionError: If not in bidirectional mode or not connected
        """
        if not self._bidirectional_mode:
            raise CLIConnectionError(
                "rewind_files() requires bidirectional mode. "
                "Enable by providing can_use_tool, hooks, or SDK MCP servers."
            )
        if not self._query:
            raise CLIConnectionError("No active query.")

        await self._query.rewind_files(user_message_id)

    async def get_mcp_status(self) -> dict[str, Any]:
        """
        Get the status of MCP server connections.

        Only available in bidirectional mode (requires evolv Code).

        Returns:
            Dict containing MCP server status information

        Raises:
            CLIConnectionError: If not in bidirectional mode or not connected
        """
        if not self._bidirectional_mode:
            raise CLIConnectionError(
                "get_mcp_status() requires bidirectional mode. "
                "Enable by providing can_use_tool, hooks, or SDK MCP servers."
            )
        if not self._query:
            raise CLIConnectionError("No active query.")

        return await self._query.get_mcp_status()

    async def _cleanup_query(self) -> None:
        """Clean up after a query completes."""
        if self._query:
            self._query._closed = True
            self._query = None

        if self._current_transport:
            await self._current_transport.close()
            self._current_transport = None

    async def disconnect(self) -> None:
        """Disconnect and clean up resources."""
        await self._cleanup_query()
        self._connected = False

    async def __aenter__(self) -> "EvolvSDKClient":
        """Enter async context - prepares the client."""
        await self.connect()
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> bool:
        """Exit async context - disconnects."""
        await self.disconnect()
        return False

    @property
    def is_bidirectional(self) -> bool:
        """Check if client is operating in bidirectional mode."""
        return self._bidirectional_mode


# Backward compatibility aliases
CortexSDKClient = EvolvSDKClient
ClaudeSDKClient = EvolvSDKClient
