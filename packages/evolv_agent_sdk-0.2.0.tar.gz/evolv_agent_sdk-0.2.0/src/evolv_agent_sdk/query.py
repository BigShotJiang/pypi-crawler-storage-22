"""Query function for one-shot interactions with evolv Code."""

import os
from collections.abc import AsyncIterable, AsyncIterator
from typing import Any

from ._internal.client import InternalClient
from ._internal.transport import Transport
from .types import EvolvAgentOptions, Message


async def query(
    *,
    prompt: str | AsyncIterable[dict[str, Any]],
    options: EvolvAgentOptions | None = None,
    transport: Transport | None = None,
) -> AsyncIterator[Message]:
    """
    Query evolv Code for one-shot or bidirectional streaming interactions.

    This function supports full bidirectional mode with evolv Code CLI,
    enabling:
    - can_use_tool callback for tool permissions
    - SDK hooks (PreToolUse, PostToolUse, etc.)
    - SDK MCP servers (in-process)
    - Runtime control: interrupt(), set_permission_mode(), set_model()

    When to use query():
    - Simple one-off questions ("What is 2+2?")
    - Batch processing of independent prompts
    - Code generation or analysis tasks
    - Automated scripts and CI/CD pipelines
    - When you know all inputs upfront

    When to use EvolvSDKClient:
    - Interactive conversations with follow-ups
    - Chat applications or REPL-like interfaces
    - When you need to send messages based on responses
    - When you need interrupt capabilities
    - Long-running sessions with state

    Args:
        prompt: The prompt to send to evolv. Can be a string for single-shot queries
                or an AsyncIterable[dict] for streaming mode with continuous interaction.
        options: Optional configuration (defaults to EvolvAgentOptions() if None).
        transport: Optional transport implementation. If provided, this will be used
                  instead of the default transport selection based on options.

    Yields:
        Messages from the conversation

    Example - Simple query:
        ```python
        from evolv_agent_sdk import query

        async for message in query(prompt="What is the capital of France?"):
            print(message)
        ```

    Example - With options:
        ```python
        from evolv_agent_sdk import query, EvolvAgentOptions

        async for message in query(
            prompt="Create a Python web server",
            options=EvolvAgentOptions(
                cwd="/home/user/project"
            )
        ):
            print(message)
        ```

    Example - With can_use_tool callback:
        ```python
        from evolv_agent_sdk import query, EvolvAgentOptions, PermissionResultAllow, PermissionResultDeny

        async def my_can_use_tool(tool_name, tool_input, context):
            if tool_name == "Bash" and "rm" in tool_input.get("command", ""):
                return PermissionResultDeny(message="Destructive command blocked")
            return PermissionResultAllow()

        async for message in query(
            prompt="Delete temp files",
            options=EvolvAgentOptions(can_use_tool=my_can_use_tool)
        ):
            print(message)
        ```
    """
    if options is None:
        options = EvolvAgentOptions()

    os.environ["EVOLV_CODE_ENTRYPOINT"] = "sdk-py"

    client = InternalClient()

    async for message in client.process_query(
        prompt=prompt, options=options, transport=transport
    ):
        yield message
