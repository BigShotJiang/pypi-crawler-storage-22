"""Pytest configuration and fixtures for evolv Agent SDK tests."""

import pytest


@pytest.fixture
def sample_assistant_message() -> dict:
    """Sample assistant message from evolv CLI."""
    return {
        "type": "assistant",
        "message": {
            "id": "msg_123",
            "role": "assistant",
            "content": [
                {"type": "text", "text": "Hello! How can I help you?"},
            ],
            "model": "evolv",
            "usage": {"input_tokens": 10, "output_tokens": 20},
        },
    }


@pytest.fixture
def sample_result_message() -> dict:
    """Sample result message from evolv CLI."""
    return {
        "type": "result",
        "subtype": "success",
        "session_id": "test-session-123",
        "duration_ms": 1000,
        "duration_api_ms": 800,
        "num_turns": 1,
        "total_cost_usd": 0.001,
        "is_error": False,
        "usage": {"input_tokens": 10, "output_tokens": 20},
    }


@pytest.fixture
def sample_user_message() -> dict:
    """Sample user message."""
    return {
        "type": "user",
        "message": {
            "role": "user",
            "content": "What is 2+2?",
        },
    }


@pytest.fixture
def sample_thinking_block_message() -> dict:
    """Sample assistant message with thinking block (missing signature)."""
    return {
        "type": "assistant",
        "message": {
            "id": "msg_456",
            "role": "assistant",
            "content": [
                {"type": "thinking", "thinking": "Let me calculate..."},
                {"type": "text", "text": "The answer is 4."},
            ],
            "model": "evolv",
        },
    }


@pytest.fixture
def sample_tool_use_message() -> dict:
    """Sample assistant message with tool use."""
    return {
        "type": "assistant",
        "message": {
            "id": "msg_789",
            "role": "assistant",
            "content": [
                {
                    "type": "tool_use",
                    "id": "tool_123",
                    "name": "Read",
                    "input": {"file_path": "/tmp/test.txt"},
                },
            ],
            "model": "evolv",
        },
    }
