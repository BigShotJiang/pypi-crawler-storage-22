"""Tests for EvolvSDKClient."""

import pytest

from evolv_agent_sdk import EvolvAgentOptions, EvolvSDKClient
from evolv_agent_sdk._errors import CLIConnectionError


class TestEvolvSDKClientInit:
    """Tests for EvolvSDKClient initialization."""

    def test_default_options(self) -> None:
        """Test client with default options."""
        client = EvolvSDKClient()
        assert client.options is not None
        assert client._current_transport is None
        assert client._connected is False

    def test_custom_options(self) -> None:
        """Test client with custom options."""
        options = EvolvAgentOptions(
            cwd="/home/user/project",
            model="test-model",
        )
        client = EvolvSDKClient(options=options)
        assert client.options.cwd == "/home/user/project"
        assert client.options.model == "test-model"


class TestEvolvSDKClientNotConnected:
    """Tests for client methods when not connected."""

    @pytest.mark.asyncio
    async def test_query_not_connected(self) -> None:
        """Test that query raises error when not connected."""
        client = EvolvSDKClient()

        with pytest.raises(CLIConnectionError, match="Not connected"):
            await client.query("test")

    @pytest.mark.asyncio
    async def test_receive_messages_not_connected(self) -> None:
        """Test that receive_messages raises error when no active query."""
        client = EvolvSDKClient()
        await client.connect()

        # No query has been made yet
        with pytest.raises(CLIConnectionError, match="No active query"):
            async for _ in client.receive_messages():
                pass


class TestEvolvSDKClientBackwardCompatibility:
    """Tests for backward compatibility aliases."""

    def test_claude_sdk_client_alias(self) -> None:
        """Test that ClaudeSDKClient is an alias for EvolvSDKClient."""
        from evolv_agent_sdk import ClaudeSDKClient

        assert ClaudeSDKClient is EvolvSDKClient

    def test_claude_agent_options_alias(self) -> None:
        """Test that ClaudeAgentOptions is an alias for EvolvAgentOptions."""
        from evolv_agent_sdk import ClaudeAgentOptions

        assert ClaudeAgentOptions is EvolvAgentOptions

    def test_claude_sdk_error_alias(self) -> None:
        """Test that ClaudeSDKError is an alias for EvolvSDKError."""
        from evolv_agent_sdk import ClaudeSDKError, EvolvSDKError

        assert ClaudeSDKError is EvolvSDKError

    def test_cortex_sdk_client_alias(self) -> None:
        """Test that CortexSDKClient is an alias for EvolvSDKClient."""
        from evolv_agent_sdk import CortexSDKClient

        assert CortexSDKClient is EvolvSDKClient

    def test_cortex_agent_options_alias(self) -> None:
        """Test that CortexAgentOptions is an alias for EvolvAgentOptions."""
        from evolv_agent_sdk import CortexAgentOptions

        assert CortexAgentOptions is EvolvAgentOptions

    def test_cortex_sdk_error_alias(self) -> None:
        """Test that CortexSDKError is an alias for EvolvSDKError."""
        from evolv_agent_sdk import CortexSDKError, EvolvSDKError

        assert CortexSDKError is EvolvSDKError


class TestEvolvSDKClientFeatures:
    """Tests for evolv CLI features."""

    def test_bidirectional_streaming_supported(self) -> None:
        """Document that evolv supports bidirectional streaming.

        evolv CLI supports --input-format stream-json for
        bidirectional communication, enabling interrupt(),
        set_permission_mode(), can_use_tool callbacks, etc.
        """
        # This is a documentation test - evolv has full bidirectional support
        client = EvolvSDKClient()

        # The actual methods are on the Query class, not the client
        # Client uses the transport layer which handles bidirectional mode
        assert client is not None
