"""Tests for message parser with evolv transformations."""

import pytest

from evolv_agent_sdk._internal.message_parser import parse_message
from evolv_agent_sdk._errors import MessageParseError
from evolv_agent_sdk.types import (
    AssistantMessage,
    ResultMessage,
    SystemMessage,
    TextBlock,
    ThinkingBlock,
    ToolUseBlock,
    UserMessage,
)


class TestParseAssistantMessage:
    """Tests for parsing assistant messages."""

    def test_parse_text_block(self, sample_assistant_message: dict) -> None:
        """Test parsing assistant message with text block."""
        message = parse_message(sample_assistant_message)

        assert isinstance(message, AssistantMessage)
        assert len(message.content) == 1
        assert isinstance(message.content[0], TextBlock)
        assert message.content[0].text == "Hello! How can I help you?"
        assert message.model == "evolv"

    def test_parse_thinking_block_adds_signature(
        self, sample_thinking_block_message: dict
    ) -> None:
        """Test that missing signature is added to thinking blocks."""
        message = parse_message(sample_thinking_block_message)

        assert isinstance(message, AssistantMessage)
        assert len(message.content) == 2

        thinking_block = message.content[0]
        assert isinstance(thinking_block, ThinkingBlock)
        assert thinking_block.thinking == "Let me calculate..."
        assert thinking_block.signature == ""  # Added by parser

        text_block = message.content[1]
        assert isinstance(text_block, TextBlock)
        assert text_block.text == "The answer is 4."

    def test_parse_tool_use_block(self, sample_tool_use_message: dict) -> None:
        """Test parsing assistant message with tool use block."""
        message = parse_message(sample_tool_use_message)

        assert isinstance(message, AssistantMessage)
        assert len(message.content) == 1

        tool_use = message.content[0]
        assert isinstance(tool_use, ToolUseBlock)
        assert tool_use.id == "tool_123"
        assert tool_use.name == "Read"
        assert tool_use.input == {"file_path": "/tmp/test.txt"}

    def test_parse_assistant_missing_model_uses_default(self) -> None:
        """Test that missing model field uses 'evolv' as default."""
        data = {
            "type": "assistant",
            "message": {
                "content": [{"type": "text", "text": "Hello"}],
            },
        }
        message = parse_message(data)

        assert isinstance(message, AssistantMessage)
        assert message.model == "evolv"


class TestParseResultMessage:
    """Tests for parsing result messages."""

    def test_parse_result_message(self, sample_result_message: dict) -> None:
        """Test parsing complete result message."""
        message = parse_message(sample_result_message)

        assert isinstance(message, ResultMessage)
        assert message.subtype == "success"
        assert message.session_id == "test-session-123"
        assert message.duration_ms == 1000
        assert message.duration_api_ms == 800
        assert message.num_turns == 1
        assert message.is_error is False

    def test_parse_result_adds_missing_fields(self) -> None:
        """Test that missing fields are added with defaults."""
        data = {
            "type": "result",
            "subtype": "success",
        }
        message = parse_message(data)

        assert isinstance(message, ResultMessage)
        assert message.duration_ms == 0
        assert message.duration_api_ms == 0
        assert message.num_turns == 1
        assert message.is_error is False
        assert message.session_id == "evolv-session"
        assert message.total_cost_usd == 0

    def test_parse_result_derives_is_error(self) -> None:
        """Test that is_error is derived from subtype when missing."""
        error_data = {
            "type": "result",
            "subtype": "error",
        }
        message = parse_message(error_data)

        assert isinstance(message, ResultMessage)
        assert message.is_error is True

        success_data = {
            "type": "result",
            "subtype": "success",
        }
        message = parse_message(success_data)
        assert message.is_error is False


class TestParseUserMessage:
    """Tests for parsing user messages."""

    def test_parse_user_message_string_content(
        self, sample_user_message: dict
    ) -> None:
        """Test parsing user message with string content."""
        message = parse_message(sample_user_message)

        assert isinstance(message, UserMessage)
        assert message.content == "What is 2+2?"

    def test_parse_user_message_with_uuid(self) -> None:
        """Test parsing user message with UUID."""
        data = {
            "type": "user",
            "uuid": "user-123",
            "message": {
                "role": "user",
                "content": "Hello",
            },
        }
        message = parse_message(data)

        assert isinstance(message, UserMessage)
        assert message.uuid == "user-123"


class TestParseSystemMessage:
    """Tests for parsing system messages."""

    def test_parse_system_message(self) -> None:
        """Test parsing system message."""
        data = {
            "type": "system",
            "subtype": "init",
            "session_id": "test-session",
        }
        message = parse_message(data)

        assert isinstance(message, SystemMessage)
        assert message.subtype == "init"
        assert message.data == data


class TestParseErrors:
    """Tests for parsing error handling."""

    def test_parse_invalid_type(self) -> None:
        """Test parsing non-dict data raises error."""
        with pytest.raises(MessageParseError, match="Invalid message data type"):
            parse_message("not a dict")  # type: ignore

    def test_parse_missing_type_field(self) -> None:
        """Test parsing message without type field raises error."""
        with pytest.raises(MessageParseError, match="missing 'type' field"):
            parse_message({"content": "test"})

    def test_parse_unknown_type(self) -> None:
        """Test parsing unknown message type raises error."""
        with pytest.raises(MessageParseError, match="Unknown message type"):
            parse_message({"type": "unknown_type"})
