"""Tests for query function."""

import pytest

from evolv_agent_sdk import EvolvAgentOptions


class TestQueryOptions:
    """Tests for query options handling."""

    def test_options_default_creation(self) -> None:
        """Test that options are created with defaults when None."""
        options = EvolvAgentOptions()
        assert options is not None
        assert options.cli_path is None

    def test_options_with_cli_path(self) -> None:
        """Test options with custom CLI path."""
        options = EvolvAgentOptions(cli_path="/custom/path/evolv")
        assert options.cli_path == "/custom/path/evolv"

    def test_options_with_cwd(self) -> None:
        """Test options with working directory."""
        options = EvolvAgentOptions(cwd="/home/user/project")
        assert options.cwd == "/home/user/project"

    def test_options_with_env(self) -> None:
        """Test options with environment variables."""
        options = EvolvAgentOptions(env={"MY_VAR": "value"})
        assert options.env == {"MY_VAR": "value"}


class TestQueryValidation:
    """Tests for query parameter validation."""

    @pytest.mark.asyncio
    async def test_can_use_tool_requires_streaming(self) -> None:
        """Test that can_use_tool callback requires streaming mode."""
        from evolv_agent_sdk._internal.client import InternalClient

        async def mock_callback(tool_name, tool_input, context):
            return {"behavior": "allow"}

        options = EvolvAgentOptions(can_use_tool=mock_callback)
        client = InternalClient()

        with pytest.raises(ValueError, match="streaming mode"):
            async for _ in client.process_query(
                prompt="test string",  # String, not AsyncIterable
                options=options,
            ):
                pass

    @pytest.mark.asyncio
    async def test_can_use_tool_and_permission_prompt_exclusive(self) -> None:
        """Test that can_use_tool and permission_prompt_tool_name are mutually exclusive."""
        from evolv_agent_sdk._internal.client import InternalClient

        async def mock_callback(tool_name, tool_input, context):
            return {"behavior": "allow"}

        async def mock_stream():
            yield {"type": "user", "message": {"role": "user", "content": "test"}}

        options = EvolvAgentOptions(
            can_use_tool=mock_callback,
            permission_prompt_tool_name="stdio",
        )
        client = InternalClient()

        with pytest.raises(ValueError, match="cannot be used with"):
            async for _ in client.process_query(
                prompt=mock_stream(),
                options=options,
            ):
                pass
