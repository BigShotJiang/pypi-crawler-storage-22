"""Tests for type definitions."""

from evolv_agent_sdk.types import (
    EvolvAgentOptions,
    PermissionResultAllow,
    PermissionResultDeny,
    PermissionRuleValue,
    PermissionUpdate,
    TextBlock,
    ThinkingBlock,
    ToolUseBlock,
    ToolResultBlock,
)


class TestEvolvAgentOptions:
    """Tests for EvolvAgentOptions dataclass."""

    def test_default_values(self) -> None:
        """Test that default values are set correctly."""
        options = EvolvAgentOptions()

        assert options.cli_path is None
        assert options.cwd is None
        assert options.model is None
        assert options.permission_mode is None
        assert options.allowed_tools == []
        assert options.env == {}
        assert options.can_use_tool is None
        assert options.hooks is None

    def test_custom_values(self) -> None:
        """Test setting custom values."""
        options = EvolvAgentOptions(
            cli_path="/usr/local/bin/evolv",
            cwd="/home/user/project",
            model="test-model",
            env={"KEY": "value"},
            max_turns=10,
        )

        assert options.cli_path == "/usr/local/bin/evolv"
        assert options.cwd == "/home/user/project"
        assert options.model == "test-model"
        assert options.env == {"KEY": "value"}
        assert options.max_turns == 10


class TestContentBlocks:
    """Tests for content block types."""

    def test_text_block(self) -> None:
        """Test TextBlock creation."""
        block = TextBlock(text="Hello, world!")
        assert block.text == "Hello, world!"

    def test_thinking_block(self) -> None:
        """Test ThinkingBlock creation."""
        block = ThinkingBlock(thinking="Let me think...", signature="sig123")
        assert block.thinking == "Let me think..."
        assert block.signature == "sig123"

    def test_tool_use_block(self) -> None:
        """Test ToolUseBlock creation."""
        block = ToolUseBlock(
            id="tool_123",
            name="Read",
            input={"file_path": "/tmp/test.txt"},
        )
        assert block.id == "tool_123"
        assert block.name == "Read"
        assert block.input == {"file_path": "/tmp/test.txt"}

    def test_tool_result_block(self) -> None:
        """Test ToolResultBlock creation."""
        block = ToolResultBlock(
            tool_use_id="tool_123",
            content="File contents here",
            is_error=False,
        )
        assert block.tool_use_id == "tool_123"
        assert block.content == "File contents here"
        assert block.is_error is False


class TestPermissionTypes:
    """Tests for permission-related types."""

    def test_permission_result_allow(self) -> None:
        """Test PermissionResultAllow creation."""
        result = PermissionResultAllow()
        assert result.behavior == "allow"
        assert result.updated_input is None

        result_with_input = PermissionResultAllow(
            updated_input={"modified": True}
        )
        assert result_with_input.updated_input == {"modified": True}

    def test_permission_result_deny(self) -> None:
        """Test PermissionResultDeny creation."""
        result = PermissionResultDeny(
            message="Permission denied",
            interrupt=True,
        )
        assert result.behavior == "deny"
        assert result.message == "Permission denied"
        assert result.interrupt is True

    def test_permission_update_to_dict(self) -> None:
        """Test PermissionUpdate.to_dict() method."""
        update = PermissionUpdate(
            type="addRules",
            rules=[
                PermissionRuleValue(tool_name="Bash", rule_content="allow")
            ],
            behavior="allow",
            destination="session",
        )

        result = update.to_dict()

        assert result["type"] == "addRules"
        assert result["destination"] == "session"
        assert result["behavior"] == "allow"
        assert len(result["rules"]) == 1
        assert result["rules"][0]["toolName"] == "Bash"

    def test_permission_update_set_mode(self) -> None:
        """Test PermissionUpdate with setMode type."""
        update = PermissionUpdate(
            type="setMode",
            mode="bypassPermissions",
        )

        result = update.to_dict()

        assert result["type"] == "setMode"
        assert result["mode"] == "bypassPermissions"
