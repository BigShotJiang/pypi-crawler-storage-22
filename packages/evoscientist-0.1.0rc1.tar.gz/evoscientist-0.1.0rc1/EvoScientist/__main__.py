"""Enable `python -m EvoScientist` execution."""
from EvoScientist.cli import main

main()
