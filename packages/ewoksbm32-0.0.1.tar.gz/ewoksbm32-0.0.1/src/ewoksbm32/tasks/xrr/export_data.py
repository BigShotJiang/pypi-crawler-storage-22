import os
import h5py
import numpy as np
from ewokscore import Task


class ExportHDF5(
    Task,
    input_names=[
        "sample_name",
        "tth",
        "det",
        "tth_bg",
        "det_bg",
        "q",
        "R",
        "qraw",
        "Rraw",
        "z",
        "delta_rho",
        "delta_rho_bl",
        "delta_rho_nc",
        "detm",
        "detm_bg",
        "tthc",
        "tthcr",
        "tthc_bg",
        "tthcr_bg",
        "detmn",
        "detmn_bg",
        "detmnp",
        "detmnpr",
        "detmnp_bg",
        "detmnpr_bg",
        "detmnpri_bg",
        "fpc",
        "baseline",
        "minima",
        "phase",
        "phase_bl",
        "Rq4_bl",
        "Rq4_sm",
        "filename",
    ],
    optional_input_names=[
        "start_time_str",
        "end_time_str",
    ],
    output_names=["filename"],
):
    """
    Export to an HDF5 file organized like NeXus:
    - /entry (NXentry) with sample, times
    - /entry/instrument/detector (NXdetector) for raw counts
    - /entry/data/* (NXdata) for plot-ready signals (R(tth), R(q), Rraw(qraw))
    - /entry/process (NXprocess) for intermediate/derived arrays
    """

    @staticmethod
    def _ensure_group(parent: h5py.Group, path: str) -> h5py.Group:
        g = parent
        for part in path.strip("/").split("/"):
            if part:
                g = g.require_group(part)
        return g

    @staticmethod
    def _write_1d(
        parent: h5py.Group,
        name: str,
        data,
        *,
        units: str | None = None,
        long_name: str | None = None,
    ) -> None:
        if data is None:
            return
        if isinstance(data, np.ndarray):
            arr = data
        else:
            arr = np.asarray(data)
        if arr.ndim != 1:
            return
        dset = parent.create_dataset(name, data=arr)
        if units is not None:
            dset.attrs["units"] = units
        if long_name is not None:
            dset.attrs["long_name"] = long_name

    @staticmethod
    def _nxclass(g: h5py.Group, cls: str) -> None:
        g.attrs["NX_class"] = cls

    def run(self):
        inp = self.inputs

        # Decide output filename
        out = inp.filename or f"{(inp.sample_name or 'output')}.h5"
        root_dir = os.path.dirname(out)
        if root_dir and not os.path.isdir(root_dir):
            os.makedirs(root_dir, exist_ok=True)

        with h5py.File(out, "w") as f:
            # Root default → entry
            f.attrs["default"] = "entry"

            # /entry (NXentry)
            entry = self._ensure_group(f, "entry")
            self._nxclass(entry, "NXentry")
            entry.attrs["default"] = "R_of_tth"

            # Title & times
            title = inp.sample_name or "unknown"
            entry.create_dataset("title", data=np.bytes_(title))
            if getattr(inp, "start_time_str", None):
                entry.create_dataset("start_time", data=np.bytes_(inp.start_time_str))
            if getattr(inp, "end_time_str", None):
                entry.create_dataset("end_time", data=np.bytes_(inp.end_time_str))

            # /entry/sample (NXsample)
            sample = self._ensure_group(entry, "sample")
            self._nxclass(sample, "NXsample")
            sample.create_dataset("name", data=np.bytes_(title))

            # /entry/instrument/detector (NXdetector) for raw counts
            detgrp = self._ensure_group(entry, "instrument/detector")
            self._nxclass(detgrp, "NXdetector")
            self._write_1d(detgrp, "det", inp.det, units="counts")
            self._write_1d(detgrp, "det_bg", inp.det_bg, units="counts")

            # /entry/data: NXdata groups for canonical plots
            dataroot = self._ensure_group(entry, "data")

            # R(tth)
            if inp.R is not None and inp.tth is not None:
                rtth = self._ensure_group(dataroot, "R_of_tth")
                self._nxclass(rtth, "NXdata")
                rtth.attrs["signal"] = "R"
                rtth.attrs["axes"] = "tth"
                self._write_1d(rtth, "R", inp.R, units="")  # dimensionless
                self._write_1d(rtth, "tth", inp.tth, units="deg", long_name="two-theta")

            # R(q)
            if inp.R is not None and inp.q is not None:
                rq = self._ensure_group(dataroot, "R_of_q")
                self._nxclass(rq, "NXdata")
                rq.attrs["signal"] = "R"
                rq.attrs["axes"] = "q"
                self._write_1d(rq, "R", inp.R, units="")
                self._write_1d(rq, "q", inp.q, units="1/Angstrom")

            # Rraw(qraw)
            if inp.Rraw is not None and inp.qraw is not None:
                rr = self._ensure_group(dataroot, "Rraw_of_qraw")
                self._nxclass(rr, "NXdata")
                rr.attrs["signal"] = "Rraw"
                rr.attrs["axes"] = "qraw"
                self._write_1d(rr, "Rraw", inp.Rraw, units="")
                self._write_1d(rr, "qraw", inp.qraw, units="1/Angstrom")

            # /entry/process (NXprocess) for intermediates/derived arrays
            proc = self._ensure_group(entry, "process")
            self._nxclass(proc, "NXprocess")

            # Angles (corrected)
            self._write_1d(proc, "tthc", inp.tthc, units="deg")
            self._write_1d(proc, "tthcr", inp.tthcr, units="deg")
            self._write_1d(proc, "tthc_bg", inp.tthc_bg, units="deg")
            self._write_1d(proc, "tthcr_bg", inp.tthcr_bg, units="deg")

            # Preprocessed detector signals
            self._write_1d(proc, "detm", inp.detm, units="counts")
            self._write_1d(proc, "detmn", inp.detmn, units="counts")
            self._write_1d(proc, "detmnp", inp.detmnp, units="counts")
            self._write_1d(proc, "detmnpr", inp.detmnpr, units="counts")
            self._write_1d(proc, "detm_bg", inp.detm_bg, units="counts")
            self._write_1d(proc, "detmn_bg", inp.detmn_bg, units="counts")
            self._write_1d(proc, "detmnp_bg", inp.detmnp_bg, units="counts")
            self._write_1d(proc, "detmnpr_bg", inp.detmnpr_bg, units="counts")
            self._write_1d(proc, "detmnpri_bg", inp.detmnpri_bg, units="counts")

            # Corrections & analysis
            self._write_1d(proc, "fpc", inp.fpc, units="")
            self._write_1d(proc, "baseline", inp.baseline, units="")
            self._write_1d(proc, "minima", inp.minima, units="")
            self._write_1d(proc, "phase", inp.phase, units="rad")
            self._write_1d(proc, "phase_bl", inp.phase_bl, units="rad")
            self._write_1d(proc, "Rq4_bl", inp.Rq4_bl, units="")
            self._write_1d(proc, "Rq4_sm", inp.Rq4_sm, units="")

            # Profiles / model outputs
            self._write_1d(proc, "z", inp.z, units="Angstrom")
            self._write_1d(proc, "delta_rho", inp.delta_rho, units="e/Angstrom^3")
            self._write_1d(proc, "delta_rho_bl", inp.delta_rho_bl, units="e/Angstrom^3")
            self._write_1d(proc, "delta_rho_nc", inp.delta_rho_nc, units="e/Angstrom^3")

        self.outputs.filename = out
