# ewokstxs

Ewoks tasks for the [txs package](https://gitlab.esrf.fr/levantin/txs).

## Resources

- [Package on pypi.org](https://pypi.org/project/ewokstxs/)
- [Documentation](https://ewokstxs.readthedocs.io/)
- [Contributing](CONTRIBUTING.md)
- [Changelog](CHANGELOG.md)

