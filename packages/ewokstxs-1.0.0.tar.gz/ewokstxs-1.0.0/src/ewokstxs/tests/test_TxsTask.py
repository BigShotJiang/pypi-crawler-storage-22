import logging

import h5py
import numpy as np
import pytest
from ewoks import execute_graph
from silx.io.dictdump import dicttonx
from silx.io.url import DataUrl


@pytest.fixture
def h5_scan_file(tmp_path):
    """Create a temporary HDF5 file with a minimal structure for testing."""

    file_path = tmp_path / "dataset.h5"

    h5_file_content = {
        "@NX_class": "NXentry",
        "start_time": "2023-07-04T23:10:56.747201+02:00",
        "end_time": "2023-07-04T23:13:55.143782+02:00",
        "title": "test_scan_command",
        "instrument": {
            "@NX_class": "NXinstrument",
            "rayonix": {
                "@NX_class": "NXdetector",
                ">data": "image",
                "image": np.random.randint(
                    low=10, high=1000, size=(3, 1920, 1920), dtype=np.uint16
                ),
            },
        },
        "measurement": {
            "@NX_class": "NXcollection",
            "elapsed_time": [0.0, 1.0, 2.0],
            ">rayonix": "../instrument/rayonix/data",
        },
        "sample": {
            "@NX_class": "NXsample",
            "name": "Test",
        },
    }
    with h5py.File(file_path, "w") as h5_file:
        dicttonx(h5_file_content, h5_file, h5path="1.1")

    return file_path


def test_task(tmp_path, h5_scan_file):
    workflow = {
        "graph": {"id": "txs"},
        "nodes": [
            {
                "id": "txs",
                "task_type": "class",
                "task_identifier": "ewokstxs.tasks.txs.TxsTask",
            },
        ],
    }

    output_filename = str(tmp_path.absolute() / "output.h5")
    scan_number = 1

    parameters = {
        "scan_key": None,
        "filename": str(h5_scan_file),
        "scan": scan_number,
        "energy": 18000,
        "distance": 0.3,
        "center": (960.0, 960.0),
        "detector": "rayonix",
        "binning": (2, 2),
        "output_filename": output_filename,
    }

    inputs = [
        {"id": "txs", "name": name, "value": value}
        for name, value in parameters.items()
    ]

    logging.debug(f"worflow parameters: {parameters}")
    result = execute_graph(workflow, inputs=inputs)
    logging.debug(f"workflow result: {result}")
    assert DataUrl(result["nxdata_url"]) == DataUrl(
        file_path=output_filename, data_path=f"/{scan_number}.1/integrate/integrated"
    )
