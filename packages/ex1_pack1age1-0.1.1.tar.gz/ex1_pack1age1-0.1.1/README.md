# ex_package

A simple hello package that can be installed using pip.

This project is for learning how to:

- Build a Python package
- Install using pip
- Share projects
- Practice Git and GitHub

## Installation

pip install ex_package

## Usage

```python
from ex_package import Hello, Impute

h = Hello("Hi", 3)
h.show()

i = Impute("Hello", 2)
i.printl()