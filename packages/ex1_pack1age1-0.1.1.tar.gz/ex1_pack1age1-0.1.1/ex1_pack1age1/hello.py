class Hello:
    # define a constructor
    def __init__(self,word,repetition =1):
        self.word = word
        self.repeat = repetition
    
    # define a function show 
    def show(self):
        '''
        This function is used to show the word with repetitions
        
        :param self: Description
        '''
        return (self.word * self.repeat)
    