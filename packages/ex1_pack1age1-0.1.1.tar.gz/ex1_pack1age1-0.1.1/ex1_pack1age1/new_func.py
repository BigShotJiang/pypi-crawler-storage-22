from .hello import Hello

# Creating a new class called impute
class Impute:
    # define constructor
    def __init__(self,word,rep):
        self.impute = Hello(word,rep)
    
    # define a print function
    def printl(self):
        print(f'this is what you would get in {self.impute.show()}')
        
    def __str__(self):
        return f"Impute(word={self.impute.word}, repetition={self.impute.repeat})"