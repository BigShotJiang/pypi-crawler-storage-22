# Changelog

* [unreleased](unreleased.md)
* [5.1.0](changes_5.1.0.md)
* [5.0.0](changes_5.0.0.md)
* [4.0.1](changes_4.0.1.md)
* [4.0.0](changes_4.0.0.md)
* [3.0.0](changes_3.0.0.md)
* [2.0.0](changes_2.0.0.md)
* [1.13.0](changes_1.13.0.md)
* [1.12.0](changes_1.12.0.md)
* [1.11.0](changes_1.11.0.md)
* [1.10.0](changes_1.10.0.md)
* [1.9.0](changes_1.9.0.md)
* [1.8.0](changes_1.8.0.md)
* [1.7.4](changes_1.7.4.md)
* [1.7.3](changes_1.7.3.md)
* [1.7.2](changes_1.7.2.md)
* [1.7.1](changes_1.7.1.md)
* [1.7.0](changes_1.7.0.md)
* [1.6.1](changes_1.6.1.md)
* [1.6.0](changes_1.6.0.md)
* [1.5.0](changes_1.5.0.md)
* [1.4.0](changes_1.4.0.md)
* [1.3.0](changes_1.3.0.md)
* [1.2.0](changes_1.2.0.md)
* [1.1.0](changes_1.1.0.md)
* [1.0.1](changes_1.0.1.md)
* [1.0.0](changes_1.0.0.md)
* [0.21.0](changes_0.21.0.md)
* [0.20.0](changes_0.20.0.md)
* [0.19.0](changes_0.19.0.md)
* [0.18.0](changes_0.18.0.md)
* [0.17.0](changes_0.17.0.md)
* [0.16.0](changes_0.16.0.md)
* [0.15.0](changes_0.15.0.md)
* [0.14.0](changes_0.14.0.md)
* [0.13.0](changes_0.13.0.md)
* [0.12.0](changes_0.12.0.md)
* [0.11.0](changes_0.11.0.md)
* [0.10.0](changes_0.10.0.md)
* [0.9.0](changes_0.9.0.md)
* [0.8.0](changes_0.8.0.md)
* [0.7.0](changes_0.7.0.md)
* [0.6.2](changes_0.6.2.md)
* [0.6.1](changes_0.6.1.md)
* [0.6.0](changes_0.6.0.md)
* [0.5.0](changes_0.5.0.md)
* [0.4.0](changes_0.4.0.md)
* [0.3.0](changes_0.3.0.md)
* [0.2.0](changes_0.2.0.md)
* [0.1.0](changes_0.1.0.md)

```{toctree}
---
hidden:
---
unreleased
changes_5.1.0
changes_5.0.0
changes_4.0.1
changes_4.0.0
changes_3.0.0
changes_2.0.0
changes_1.13.0
changes_1.12.0
changes_1.11.0
changes_1.10.0
changes_1.9.0
changes_1.8.0
changes_1.7.4
changes_1.7.3
changes_1.7.2
changes_1.7.1
changes_1.7.0
changes_1.6.1
changes_1.6.0
changes_1.5.0
changes_1.4.0
changes_1.3.0
changes_1.2.0
changes_1.1.0
changes_1.0.1
changes_1.0.0
changes_0.21.0
changes_0.20.0
changes_0.19.0
changes_0.18.0
changes_0.17.0
changes_0.16.0
changes_0.15.0
changes_0.14.0
changes_0.13.0
changes_0.12.0
changes_0.11.0
changes_0.10.0
changes_0.9.0
changes_0.8.0
changes_0.7.0
changes_0.6.2
changes_0.6.1
changes_0.6.0
changes_0.5.0
changes_0.4.0
changes_0.3.0
changes_0.2.0
changes_0.1.0
```
