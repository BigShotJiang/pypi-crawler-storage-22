#!/usr/bin/env python3
import sys

from .main import main

sys.exit(main())
