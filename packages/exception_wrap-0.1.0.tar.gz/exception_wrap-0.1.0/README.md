# Exception Wrapper

Rather than needing to remember all of the exception types or do "catch all" exceptions, and rather than having to reimplement logging formats constantly,
this module provides consistent and comprehensive logging and error handing approach.


