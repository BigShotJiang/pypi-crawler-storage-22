def hello() -> str:
    return "Hello from exgentic!"
