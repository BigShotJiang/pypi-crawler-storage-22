from expanse.pagination.exceptions import PaginationError


class DatabasePaginationError(PaginationError): ...
