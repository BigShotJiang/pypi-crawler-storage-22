# explainplot 📊🧠

**Explainplot** is an **advanced Python visualization library** that not only plots your data but also **automatically generates AI-style insights**.  
Designed for students, analysts, and Python developers who want **visualization + understanding** in one package.

---

## 🚀 Features

- **Scatter, Line, Histogram, Pairplots**
- **Automatic trend & correlation detection**
- **Outlier detection**
- **Distribution insights** (mean, skewness, kurtosis)
- **Interactive plots** (Plotly for Jupyter)
- **Beginner & advanced-friendly API**

---

## 📦 Installation

```bash
pip install explainplot
