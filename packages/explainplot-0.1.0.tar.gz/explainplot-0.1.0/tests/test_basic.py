import pandas as pd
from explainplot.api import plot

df = pd.DataFrame({'x':[1,2,3,4], 'y':[2,4,6,8]})
fig = plot(df, 'x', 'y')
assert fig is not None
