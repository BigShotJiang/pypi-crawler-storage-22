"""""
模块作用：提供常用的类型判断工具函数。
"""""
import numpy as np


#%%  CHAPTER：====判断是否整数或整型====
def isinteger(num):
    """""
    input.num：任意对象
    output：bool，True表示是整数类型（含内置int/float和numpy整型）
    influence：用于对参数进行整数性检查
    """""
    return isinstance(num, (int, float,np.int8,np.int16,np.int32, np.int64))


#%%  CHAPTER：====判断是否序列(list/tuple/ndarray/range)====
def islist(num):
    """""
    input.num：任意对象
    output：bool，True表示是列表/元组/ndarray/range之一
    influence：用于区分单值与序列输入
    """""
    return isinstance(num, (list, tuple, np.ndarray,range))