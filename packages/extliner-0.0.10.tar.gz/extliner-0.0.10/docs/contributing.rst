Contributing
============

We welcome contributions!

1. Fork the repository and clone it locally.
2. Create a new feature branch.
3. Add tests and ensure existing tests pass.
4. Follow PEP8 style guidelines.
5. Submit a pull request for review.
