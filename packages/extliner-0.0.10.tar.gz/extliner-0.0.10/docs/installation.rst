Installation
============

Install Extliner easily with pip:

.. code-block:: bash

   pip install extliner

Requirements:
- Python 3.6+
