# Publishing `eye-cv` to PyPI

This repo is set up for modern builds via `pyproject.toml` (PEP 517) with metadata in `setup.py`.

## 0) One-time setup

- Create accounts:
  - PyPI: https://pypi.org/
  - (Recommended) TestPyPI: https://test.pypi.org/
- Create an API token:
  - PyPI → Account settings → API tokens
  - Set token scope to the project (once created) or entire account initially

## 1) Pick a package name

The distribution name is `eye-cv` (see `setup.py`). If PyPI says the name is taken, change the `name=` in `setup.py` to something unique (e.g. `eye-cv-lib`, `eye-cv-toolkit`, etc.).

## 2) Bump the version

Update `version=` in `setup.py` before each release (use semver: `MAJOR.MINOR.PATCH`).

## 3) Build

From the repo root:

```bash
python -m pip install --upgrade pip
python -m pip install --upgrade build twine

python -m build
python -m twine check dist/*
```

Outputs are written to `dist/`.

## 4) Upload to TestPyPI (recommended)

```bash
python -m twine upload --repository testpypi dist/*
```

Install from TestPyPI:

```bash
pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple eye-cv
```

## 5) Upload to PyPI

```bash
python -m twine upload dist/*
```

## 6) Sanity-check install

In a clean venv:

```bash
pip install eye-cv
python -c "import eye; print('eye version:', eye.__version__)"
```

Optional features:

```bash
pip install "eye-cv[all]"
```
