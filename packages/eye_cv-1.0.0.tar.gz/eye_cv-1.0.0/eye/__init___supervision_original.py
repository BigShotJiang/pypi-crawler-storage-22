import importlib.metadata as importlib_metadata

try:
    # This will read version from pyproject.toml
    __version__ = importlib_metadata.version(__package__ or __name__)
except importlib_metadata.PackageNotFoundError:
    __version__ = "development"

from eye.annotators.core import (
    BackgroundOverlayAnnotator,
    BlurAnnotator,
    BoundingBoxAnnotator,
    BoxAnnotator,
    BoxCornerAnnotator,
    CircleAnnotator,
    ColorAnnotator,
    CropAnnotator,
    DotAnnotator,
    EllipseAnnotator,
    HaloAnnotator,
    HeatMapAnnotator,
    IconAnnotator,
    LabelAnnotator,
    MaskAnnotator,
    OrientedBoxAnnotator,
    PercentageBarAnnotator,
    PixelateAnnotator,
    PolygonAnnotator,
    RichLabelAnnotator,
    RoundBoxAnnotator,
    TraceAnnotator,
    TriangleAnnotator,
)
from eye.annotators.utils import ColorLookup
from eye.classification.core import Classifications
from eye.dataset.core import (
    BaseDataset,
    ClassificationDataset,
    DetectionDataset,
)
from eye.dataset.utils import mask_to_rle, rle_to_mask
from eye.detection.core import Detections
from eye.detection.line_zone import (
    LineZone,
    LineZoneAnnotator,
    LineZoneAnnotatorMulticlass,
)
from eye.detection.lmm import LMM
from eye.detection.overlap_filter import (
    OverlapFilter,
    box_non_max_merge,
    box_non_max_suppression,
    mask_non_max_suppression,
)
from eye.detection.tools.csv_sink import CSVSink
from eye.detection.tools.inference_slicer import InferenceSlicer
from eye.detection.tools.json_sink import JSONSink
from eye.detection.tools.polygon_zone import PolygonZone, PolygonZoneAnnotator
from eye.detection.tools.smoother import DetectionsSmoother
from eye.detection.utils import (
    box_iou_batch,
    calculate_masks_centroids,
    clip_boxes,
    contains_holes,
    contains_multiple_segments,
    filter_polygons_by_area,
    mask_iou_batch,
    mask_to_polygons,
    mask_to_xyxy,
    move_boxes,
    move_masks,
    oriented_box_iou_batch,
    pad_boxes,
    polygon_to_mask,
    polygon_to_xyxy,
    scale_boxes,
    xcycwh_to_xyxy,
    xywh_to_xyxy,
)
from eye.draw.color import Color, ColorPalette
from eye.draw.utils import (
    calculate_optimal_line_thickness,
    calculate_optimal_text_scale,
    draw_filled_polygon,
    draw_filled_rectangle,
    draw_image,
    draw_line,
    draw_polygon,
    draw_rectangle,
    draw_text,
)
from eye.geometry.core import Point, Position, Rect
from eye.geometry.utils import get_polygon_center
from eye.keypoint.annotators import (
    EdgeAnnotator,
    VertexAnnotator,
    VertexLabelAnnotator,
)
from eye.keypoint.core import KeyPoints
from eye.metrics.detection import ConfusionMatrix, MeanAveragePrecision
from eye.tracker.byte_tracker.core import ByteTrack
from eye.utils.conversion import cv2_to_pillow, pillow_to_cv2
from eye.utils.file import list_files_with_extensions
from eye.utils.image import (
    ImageSink,
    create_tiles,
    crop_image,
    letterbox_image,
    overlay_image,
    resize_image,
    scale_image,
)
from eye.utils.notebook import plot_image, plot_images_grid
from eye.utils.video import (
    FPSMonitor,
    VideoInfo,
    VideoSink,
    get_video_frames_generator,
    process_video,
)
