from __future__ import annotations

from enum import Enum
from typing import Optional

import numpy as np

from eye.detection.core import Detections
from eye.core.trackers.sort_tracker import SORTTracker
from eye.core.trackers.bytetrack_tracker import ByteTrackTracker


class TrackerType(str, Enum):
    SORT = "sort"
    BYTETRACK = "bytetrack"


def _inflate_xyxy(xyxy: np.ndarray, factor: float) -> np.ndarray:
    if factor is None or factor == 1.0:
        return xyxy
    xyxy = np.asarray(xyxy, dtype=np.float32)
    w = xyxy[:, 2] - xyxy[:, 0]
    h = xyxy[:, 3] - xyxy[:, 1]
    cx = xyxy[:, 0] + 0.5 * w
    cy = xyxy[:, 1] + 0.5 * h
    w2 = 0.5 * w * factor
    h2 = 0.5 * h * factor
    out = np.empty_like(xyxy, dtype=np.float32)
    out[:, 0] = cx - w2
    out[:, 1] = cy - h2
    out[:, 2] = cx + w2
    out[:, 3] = cy + h2
    return out


def _iou_matrix(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """IoU matrix between a (N,4) and b (M,4) in xyxy."""
    if a.size == 0 or b.size == 0:
        return np.zeros((a.shape[0], b.shape[0]), dtype=np.float32)

    a = a.astype(np.float32)
    b = b.astype(np.float32)

    xx1 = np.maximum(a[:, None, 0], b[None, :, 0])
    yy1 = np.maximum(a[:, None, 1], b[None, :, 1])
    xx2 = np.minimum(a[:, None, 2], b[None, :, 2])
    yy2 = np.minimum(a[:, None, 3], b[None, :, 3])

    inter_w = np.maximum(0.0, xx2 - xx1)
    inter_h = np.maximum(0.0, yy2 - yy1)
    inter = inter_w * inter_h

    area_a = (a[:, 2] - a[:, 0]) * (a[:, 3] - a[:, 1])
    area_b = (b[:, 2] - b[:, 0]) * (b[:, 3] - b[:, 1])

    union = area_a[:, None] + area_b[None, :] - inter
    return inter / (union + 1e-6)


def _assign_ids_by_iou(
    det_xyxy: np.ndarray,
    trk_xyxy: np.ndarray,
    trk_ids: np.ndarray,
    min_iou: float,
) -> np.ndarray:
    """Greedy IoU assignment. Returns per-detection tracker_id, -1 if unmatched."""
    n = det_xyxy.shape[0]
    if n == 0 or trk_xyxy.shape[0] == 0:
        return np.full((n,), -1, dtype=np.int64)

    ious = _iou_matrix(det_xyxy, trk_xyxy)
    assigned = np.full((n,), -1, dtype=np.int64)

    used_tracks: set[int] = set()
    for det_i in range(n):
        best_j = int(np.argmax(ious[det_i]))
        best_iou = float(ious[det_i, best_j])
        if best_iou < min_iou:
            continue
        if best_j in used_tracks:
            continue
        used_tracks.add(best_j)
        assigned[det_i] = int(trk_ids[best_j])

    return assigned


class Tracker:
    """Compatibility tracker wrapper.

    This exists to support example scripts that use `eye.Tracker` + `eye.TrackerType`.
    For production, you can still use `eye.ByteTrack` directly.
    """

    def __init__(
        self,
        tracker_type: TrackerType = TrackerType.BYTETRACK,
        inflation_factor: float = 1.0,
        max_age: int = 30,
        min_hits: int = 3,
        iou_threshold: float = 0.3,
        high_threshold: float = 0.5,
        low_threshold: float = 0.1,
        min_iou_assignment: float = 0.3,
    ) -> None:
        self.tracker_type = TrackerType(tracker_type)
        self.inflation_factor = float(inflation_factor)
        self.min_iou_assignment = float(min_iou_assignment)

        if self.tracker_type == TrackerType.SORT:
            self._tracker = SORTTracker(max_age=max_age, min_hits=min_hits, iou_threshold=iou_threshold)
        else:
            self._tracker = ByteTrackTracker(
                max_age=max_age,
                min_hits=min_hits,
                iou_threshold=iou_threshold,
                high_threshold=high_threshold,
                low_threshold=low_threshold,
            )

    def update(self, detections: Detections) -> Detections:
        if detections is None or len(detections) == 0:
            if detections is not None:
                detections.tracker_id = np.empty((0,), dtype=np.int64)
            return detections

        xyxy = np.asarray(detections.xyxy, dtype=np.float32)
        conf = getattr(detections, "confidence", None)
        if conf is None:
            conf = np.ones((xyxy.shape[0],), dtype=np.float32)
        conf = np.asarray(conf, dtype=np.float32).reshape(-1)

        inflated = _inflate_xyxy(xyxy, self.inflation_factor)
        dets_for_tracker = np.column_stack([inflated, conf])

        tracked = self._tracker.update(dets_for_tracker)
        if tracked is None or tracked.size == 0:
            detections.tracker_id = np.full((len(detections),), -1, dtype=np.int64)
            return detections[detections.tracker_id != -1]

        trk_xyxy = np.asarray(tracked[:, :4], dtype=np.float32)
        trk_ids = np.asarray(tracked[:, 4], dtype=np.int64)

        assigned = _assign_ids_by_iou(inflated, trk_xyxy, trk_ids, min_iou=self.min_iou_assignment)
        detections.tracker_id = assigned
        return detections[detections.tracker_id != -1]
