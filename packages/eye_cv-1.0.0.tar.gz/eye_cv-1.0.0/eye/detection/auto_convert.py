"""Universal auto-conversion for ALL model formats - Works with supervision!"""

import numpy as np
from typing import Any, Optional, Union
from eye.detection.core import Detections


def auto_convert(results: Any) -> Detections:
    """Automatically convert ANY model output to eye.Detections.
    
    Supports: YOLO (Ultralytics), PyTorch, TensorFlow, OpenCV, ONNX,
             TensorRT, MMDetection, Detectron2, PaddlePaddle, and more!
    
    Args:
        results: Model output in any supported format
        
    Returns:
        eye.Detections object ready to use
        
    Example:
        >>> results = model(image)
        >>> detections = eye.auto_convert(results)
        >>> annotated = annotator.annotate(image, detections)
    """
    # YOLO (Ultralytics) - Most common in this project
    if hasattr(results, 'boxes'):
        boxes = results.boxes
        if hasattr(boxes, 'xyxy'):
            xyxy = boxes.xyxy.cpu().numpy() if hasattr(boxes.xyxy, 'cpu') else boxes.xyxy
            confidence = boxes.conf.cpu().numpy() if hasattr(boxes.conf, 'cpu') else boxes.conf
            class_id = boxes.cls.cpu().numpy().astype(int) if hasattr(boxes.cls, 'cpu') else boxes.cls.astype(int)
            
            # Handle optional tracking IDs
            tracker_id = None
            if hasattr(boxes, 'id') and boxes.id is not None:
                tracker_id = boxes.id.cpu().numpy().astype(int) if hasattr(boxes.id, 'cpu') else boxes.id.astype(int)
            
            # Handle segmentation masks
            mask = None
            if hasattr(results, 'masks') and results.masks is not None:
                try:
                    mask = results.masks.data.cpu().numpy() if hasattr(results.masks.data, 'cpu') else results.masks.data
                except Exception:
                    pass
            
            return Detections(
                xyxy=xyxy,
                confidence=confidence,
                class_id=class_id,
                tracker_id=tracker_id,
                mask=mask
            )
    
    # YOLO list format (batch)
    if isinstance(results, list) and len(results) > 0:
        if hasattr(results[0], 'boxes'):
            return auto_convert(results[0])  # Take first result
    
    # PyTorch (torchvision) - Dict with boxes/scores/labels
    if isinstance(results, dict):
        if all(k in results for k in ['boxes', 'scores', 'labels']):
            boxes = results['boxes']
            xyxy = boxes.cpu().numpy() if hasattr(boxes, 'cpu') else boxes
            confidence = results['scores'].cpu().numpy() if hasattr(results['scores'], 'cpu') else results['scores']
            class_id = results['labels'].cpu().numpy().astype(int) if hasattr(results['labels'], 'cpu') else results['labels'].astype(int)
            
            return Detections(
                xyxy=xyxy,
                confidence=confidence,
                class_id=class_id
            )
    
    # TensorFlow Object Detection API
    if isinstance(results, (tuple, list)) and len(results) >= 3:
        boxes, scores, classes = results[:3]
        # TF format is [ymin, xmin, ymax, xmax] normalized - convert to xyxy
        if hasattr(boxes, 'numpy'):
            boxes = boxes.numpy()
        boxes = boxes.squeeze()
        
        # Convert to absolute coordinates (assuming image size is available)
        # For now, keep as is and let user handle scaling
        xyxy = boxes[:, [1, 0, 3, 2]]  # Reorder to [xmin, ymin, xmax, ymax]
        
        confidence = scores.numpy() if hasattr(scores, 'numpy') else scores
        class_id = classes.numpy().astype(int) if hasattr(classes, 'numpy') else classes.astype(int)
        
        return Detections(
            xyxy=xyxy.squeeze(),
            confidence=confidence.squeeze(),
            class_id=class_id.squeeze()
        )
    
    # OpenCV DNN format
    if isinstance(results, np.ndarray):
        if results.ndim == 4 and results.shape[0] == 1:
            # OpenCV format: [1, 1, N, 7] where 7 = [image_id, class_id, conf, x1, y1, x2, y2]
            detections_2d = results.reshape(-1, results.shape[-1])
            
            confidence_mask = detections_2d[:, 2] > 0  # Filter valid detections
            valid = detections_2d[confidence_mask]
            
            return Detections(
                xyxy=valid[:, 3:7],  # [x1, y1, x2, y2]
                confidence=valid[:, 2],
                class_id=valid[:, 1].astype(int)
            )
        
        # Raw array format (ONNX/TensorRT): [N, 6+] where columns are [x, y, w, h, conf, class, ...]
        if results.ndim == 2 and results.shape[1] >= 6:
            # Convert xywh to xyxy
            x = results[:, 0]
            y = results[:, 1]
            w = results[:, 2]
            h = results[:, 3]
            
            xyxy = np.stack([
                x - w/2,  # x1
                y - h/2,  # y1
                x + w/2,  # x2
                y + h/2   # y2
            ], axis=1)
            
            return Detections(
                xyxy=xyxy,
                confidence=results[:, 4],
                class_id=results[:, 5].astype(int)
            )
    
    # If nothing matched, raise helpful error
    raise TypeError(
        f"Unsupported model output format: {type(results)}. "
        f"Supported: YOLO, PyTorch, TensorFlow, OpenCV, ONNX, TensorRT. "
        f"Got: {results.__class__.__name__}"
    )


def from_yolo(results) -> Detections:
    """Convert YOLO (Ultralytics) results to Detections."""
    return auto_convert(results)


def from_pytorch(results: dict) -> Detections:
    """Convert PyTorch/torchvision results to Detections."""
    return auto_convert(results)


def from_tensorflow(results: tuple) -> Detections:
    """Convert TensorFlow Object Detection API results to Detections."""
    return auto_convert(results)


def from_opencv(results: np.ndarray) -> Detections:
    """Convert OpenCV DNN results to Detections."""
    return auto_convert(results)
