"""Simple color management - Easy to use."""

import numpy as np
from dataclasses import dataclass
from typing import Tuple, List

@dataclass
class Color:
    """RGB color."""
    r: int
    g: int
    b: int
    
    def as_bgr(self) -> Tuple[int, int, int]:
        """Convert to BGR for OpenCV."""
        return (self.b, self.g, self.r)
    
    def as_rgb(self) -> Tuple[int, int, int]:
        """Get as RGB tuple."""
        return (self.r, self.g, self.b)
    
    @classmethod
    def from_hex(cls, hex_color: str) -> 'Color':
        """Create from hex string (#RRGGBB)."""
        hex_color = hex_color.lstrip('#')
        return cls(
            int(hex_color[0:2], 16),
            int(hex_color[2:4], 16),
            int(hex_color[4:6], 16)
        )

# Predefined colors for supervision compatibility
Color.ROBOFLOW = Color(255, 107, 0)
Color.WHITE = Color(255, 255, 255)
Color.BLACK = Color(0, 0, 0)
Color.RED = Color(255, 0, 0)
Color.GREEN = Color(0, 255, 0)
Color.BLUE = Color(0, 0, 255)
Color.YELLOW = Color(255, 255, 0)


class Palette:
    """Palette of colors."""
    
    def __init__(self, colors: List[Color]):
        self.colors = colors
    
    def __len__(self) -> int:
        return len(self.colors)
    
    def __getitem__(self, index: int) -> Color:
        """Get color by index with wrapping."""
        return self.colors[index % len(self.colors)]
    
    def by_id(self, obj_id: int) -> Color:
        """Get color by object/class ID."""
        return self[obj_id]


# Alias for backward compatibility
ColorPalette = Palette


class PredefinedPalettes:
    """Predefined color palettes."""
    
    @staticmethod
    def bright() -> Palette:
        """Bright, vibrant colors."""
        return Palette([
            Color(255, 0, 0),      # Red
            Color(0, 255, 0),      # Green
            Color(0, 0, 255),      # Blue
            Color(255, 255, 0),    # Yellow
            Color(255, 0, 255),    # Magenta
            Color(0, 255, 255),    # Cyan
            Color(255, 128, 0),    # Orange
            Color(128, 0, 255),    # Purple
            Color(255, 192, 203),  # Pink
            Color(0, 255, 128),    # Spring Green
        ])
    
    @staticmethod
    def pastel() -> Palette:
        """Soft pastel colors."""
        return Palette([
            Color(255, 179, 186),  # Pastel Red
            Color(186, 255, 201),  # Pastel Green
            Color(186, 225, 255),  # Pastel Blue
            Color(255, 255, 186),  # Pastel Yellow
            Color(255, 223, 186),  # Pastel Orange
            Color(226, 186, 255),  # Pastel Purple
        ])
    
    @staticmethod
    def traffic() -> Palette:
        """Traffic/vehicle themed."""
        return Palette([
            Color(220, 20, 60),    # Crimson (cars)
            Color(70, 130, 180),   # Steel Blue (trucks)
            Color(255, 215, 0),    # Gold (buses)
            Color(50, 205, 50),    # Lime Green (motorcycles)
            Color(255, 140, 0),    # Dark Orange (vans)
        ])
    
    @staticmethod
    def monochrome(base: Color, steps: int = 10) -> 'Palette':
        """Monochrome gradient from black to base color."""
        colors = []
        for i in range(steps):
            factor = i / (steps - 1)
            colors.append(Color(
                int(base.r * factor),
                int(base.g * factor),
                int(base.b * factor)
            ))
        
        return Palette(colors)


# Palette alias for convenience
ColorPalette = Palette

# Add DEFAULT palette
Palette.DEFAULT = PredefinedPalettes.bright()

# Legacy color palette for backward compatibility
LEGACY_COLOR_PALETTE = Palette.DEFAULT


# Predefined eye colors
Color.EYE_ORANGE = Color(255, 107, 0)
Color.WHITE = Color(255, 255, 255)
Color.BLACK = Color(0, 0, 0)
Color.RED = Color(255, 0, 0)
Color.GREEN = Color(0, 255, 0)
Color.BLUE = Color(0, 0, 255)
Color.YELLOW = Color(255, 255, 0)


# Quick color access - Return Color objects
class Colors:
    """Easy color access with Color objects."""
    RED = Color(255, 0, 0)
    GREEN = Color(0, 255, 0)
    BLUE = Color(0, 0, 255)
    YELLOW = Color(255, 255, 0)
    CYAN = Color(0, 255, 255)
    MAGENTA = Color(255, 0, 255)
    WHITE = Color(255, 255, 255)
    EYE_ORANGE = Color(255, 107, 0)
    BLACK = Color(0, 0, 0)
    ORANGE = Color(255, 165, 0)
    PURPLE = Color(128, 0, 128)
