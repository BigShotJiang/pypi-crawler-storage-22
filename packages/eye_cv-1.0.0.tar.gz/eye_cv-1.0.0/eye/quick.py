"""Quick helper functions for one-line operations."""

import numpy as np
from typing import Optional, Any
from .core.detections import Detections
from .core.tracking import Tracker, TrackerType
from .annotators.box import BoxAnnotator
from .annotators.label import LabelAnnotator


def detect(model_results: Any, model_type: str = "yolo") -> Detections:
    """Convert any model output to Detections (one-liner).
    
    Args:
        model_results: Model output
        model_type: "yolo", "tensorflow", "pytorch", "opencv"
    
    Returns:
        Detections
    
    Example:
        >>> detections = eye.detect(yolo_results)
        >>> detections = eye.detect(tf_output, "tensorflow")
    """
    if model_type == "yolo":
        return Detections.from_yolo(model_results)
    elif model_type == "tensorflow":
        # Assume tuple: (boxes, scores, classes)
        return Detections.from_tensorflow(*model_results)
    elif model_type == "pytorch":
        return Detections.from_pytorch(model_results)
    elif model_type == "opencv":
        return Detections.from_opencv(model_results)
    else:
        raise ValueError(f"Unknown model_type: {model_type}")


def track(
    detections: Detections,
    tracker: Optional[Tracker] = None,
    use_case: str = "traffic"
) -> Detections:
    """Track detections (one-liner with auto-setup).
    
    Args:
        detections: Input detections
        tracker: Existing tracker (or None to create)
        use_case: "traffic", "pedestrians", "sports", etc.
    
    Returns:
        Tracked detections
    
    Example:
        >>> tracked = eye.track(detections, use_case="traffic")
    """
    if tracker is None:
        # Create default tracker
        if use_case == "pedestrians":
            tracker = Tracker(TrackerType.BYTETRACK, inflation_factor=1.8)
        else:
            tracker = Tracker(TrackerType.SORT, inflation_factor=1.5)
    
    return tracker.update(detections)


def annotate(
    image: np.ndarray,
    detections: Detections,
    labels: Optional[list] = None,
    show_boxes: bool = True,
    show_labels: bool = True
) -> np.ndarray:
    """Annotate image (one-liner).
    
    Args:
        image: Input image
        detections: Detections to draw
        labels: Custom labels (or None for auto)
        show_boxes: Draw bounding boxes
        show_labels: Draw labels
    
    Returns:
        Annotated image
    
    Example:
        >>> annotated = eye.annotate(frame, detections)
    """
    result = image.copy()
    
    if show_boxes:
        box_ann = BoxAnnotator()
        result = box_ann.annotate(result, detections)
    
    if show_labels:
        if labels is None and detections.tracker_id is not None:
            labels = [f"#{tid}" for tid in detections.tracker_id]
        elif labels is None and detections.class_id is not None:
            labels = [f"Class {cid}" for cid in detections.class_id]
        
        if labels:
            label_ann = LabelAnnotator()
            result = label_ann.annotate(result, detections, labels)
    
    return result
