"""Geometry utilities."""

import numpy as np
from dataclasses import dataclass
from typing import Tuple


@dataclass
class Point:
    """2D point."""
    x: float
    y: float
    
    def as_tuple(self) -> Tuple[float, float]:
        return (self.x, self.y)
    
    def as_int_tuple(self) -> Tuple[int, int]:
        return (int(self.x), int(self.y))


def get_polygon_center(polygon: np.ndarray) -> Point:
    """Calculate center of polygon."""
    center_x = np.mean(polygon[:, 0])
    center_y = np.mean(polygon[:, 1])
    return Point(center_x, center_y)


def is_point_in_polygon(points: np.ndarray, polygon: np.ndarray) -> np.ndarray:
    """Check if points are inside polygon.
    
    Args:
        points: (N, 2) array of points
        polygon: (M, 2) array of polygon vertices
    
    Returns:
        Boolean array of length N
    """
    from matplotlib.path import Path
    path = Path(polygon)
    return path.contains_points(points)


def calculate_iou(box1: np.ndarray, box2: np.ndarray) -> float:
    """Calculate IoU between two boxes.
    
    Args:
        box1, box2: [x1, y1, x2, y2]
    """
    x1_inter = max(box1[0], box2[0])
    y1_inter = max(box1[1], box2[1])
    x2_inter = min(box1[2], box2[2])
    y2_inter = min(box1[3], box2[3])
    
    if x2_inter < x1_inter or y2_inter < y1_inter:
        return 0.0
    
    intersection = (x2_inter - x1_inter) * (y2_inter - y1_inter)
    
    area1 = (box1[2] - box1[0]) * (box1[3] - box1[1])
    area2 = (box2[2] - box2[0]) * (box2[3] - box2[1])
    
    union = area1 + area2 - intersection
    
    return intersection / (union + 1e-6)


def polygon_area(polygon: np.ndarray) -> float:
    """Calculate area of polygon using shoelace formula."""
    x = polygon[:, 0]
    y = polygon[:, 1]
    return 0.5 * np.abs(np.dot(x, np.roll(y, 1)) - np.dot(y, np.roll(x, 1)))
