"""Smoke tests for Eye (supervision-style) package."""

import os
import sys

# Add repo root so `import eye` resolves when running tests directly
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

import numpy as np


def test_public_exports_smoke():
    import eye

    must_have = [
        "Detections",
        "auto_convert",
        "VideoInfo",
        "VideoWriter",
        "ByteTrack",
        "Tracker",
        "TrackerType",
        "SmoothingConfig",
        "SmoothingPreset",
        "ExponentialSmoothing",
        "KalmanSmoothing",
        "BoxAnnotator",
        "GradientBoxAnnotator",
        "NeonTraceAnnotator",
        "ShadowBoxAnnotator",
        "FPSAnnotator",
        "InfoAnnotator",
        "PolygonZone",
    ]

    missing = [name for name in must_have if not hasattr(eye, name)]
    assert not missing, f"Missing exports: {missing}"


def test_detections_construct_and_slice():
    import eye

    xyxy = np.array([[10, 10, 20, 20], [30, 30, 60, 60]], dtype=np.float32)
    conf = np.array([0.9, 0.8], dtype=np.float32)
    class_id = np.array([1, 2], dtype=np.int64)

    det = eye.Detections(xyxy=xyxy, confidence=conf, class_id=class_id)
    assert len(det) == 2

    det1 = det[:1]
    assert len(det1) == 1
    assert det1.xyxy.shape == (1, 4)


def test_annotators_smoke_on_empty_detections():
    import eye

    image = np.zeros((240, 320, 3), dtype=np.uint8)
    det_empty = eye.Detections(xyxy=np.zeros((0, 4), dtype=np.float32))

    box = eye.BoxAnnotator()
    out = box.annotate(image.copy(), det_empty)
    assert out.shape == image.shape

    grad = eye.GradientBoxAnnotator()
    out2 = grad.annotate(image.copy(), det_empty)
    assert out2.shape == image.shape


def test_smoothing_smoke():
    import eye

    smoother = eye.ExponentialSmoothing(alpha=0.5)
    box = np.array([10.0, 20.0, 30.0, 40.0], dtype=np.float32)

    out1 = smoother.update(7, box)
    out2 = smoother.update(7, box + 1.0)

    assert out1.shape == (4,)
    assert out2.shape == (4,)
