"""Public API surface for Eye.

This module intentionally avoids importing optional dependencies at import-time.
Most symbols are provided via lazy attribute loading (PEP 562) so that `import eye`
works with only the core dependencies installed.
"""

from __future__ import annotations

import importlib
import importlib.metadata as importlib_metadata
from typing import Any

try:
    __version__ = importlib_metadata.version(__package__ or __name__)
except importlib_metadata.PackageNotFoundError:  # pragma: no cover
    __version__ = "development"


_EXPORTS: dict[str, tuple[str, str]] = {
    # Detection conversion
    "auto_convert": ("eye.detection.auto_convert", "auto_convert"),
    "from_yolo": ("eye.detection.auto_convert", "from_yolo"),
    "from_roboflow": ("eye.detection.auto_convert", "from_roboflow"),
    "from_detectron2": ("eye.detection.auto_convert", "from_detectron2"),
    "from_pytorch": ("eye.detection.auto_convert", "from_pytorch"),
    "from_tensorflow": ("eye.detection.auto_convert", "from_tensorflow"),
    "from_mmdetection": ("eye.detection.auto_convert", "from_mmdetection"),
    "from_opencv": ("eye.detection.auto_convert", "from_opencv"),

    # Core data structures
    "Detections": ("eye.detection.core", "Detections"),
    "Classifications": ("eye.classification.core", "Classifications"),

    # Tracking
    "Tracker": ("eye.core.tracking", "Tracker"),
    "TrackerType": ("eye.core.tracking", "TrackerType"),
    "ByteTrack": ("eye.tracker.byte_tracker.core", "ByteTrack"),
    "BoTSORTTracker": ("eye.core.trackers.botsort_tracker", "BoTSORTTracker"),

    # Smoothing
    "KalmanSmoothing": ("eye.detection.tools.smoothing", "KalmanSmoothing"),
    "ExponentialSmoothing": ("eye.detection.tools.smoothing", "ExponentialSmoothing"),
    "smooth_detections": ("eye.detection.tools.smoothing", "smooth_detections"),
    "SmoothingConfig": ("eye.detection.tools.smoothing_config", "SmoothingConfig"),
    "SmoothingPreset": ("eye.detection.tools.smoothing_config", "SmoothingPreset"),
    "get_smoothing_guide": ("eye.detection.tools.smoothing_config", "get_smoothing_guide"),

    # Zones / tools
    "PolygonZone": ("eye.detection.tools.polygon_zone", "PolygonZone"),
    "PolygonZoneAnnotator": ("eye.detection.tools.polygon_zone", "PolygonZoneAnnotator"),
    "LineZone": ("eye.detection.line_zone", "LineZone"),
    "LineZoneAnnotator": ("eye.detection.line_zone", "LineZoneAnnotator"),
    "LineZoneAnnotatorMulticlass": ("eye.detection.line_zone", "LineZoneAnnotatorMulticlass"),

    # Video
    "VideoInfo": ("eye.utils.video", "VideoInfo"),
    "VideoWriter": ("eye.utils.video", "VideoWriter"),
    "VideoSink": ("eye.utils.video", "VideoSink"),
    "FPSMonitor": ("eye.utils.video", "FPSMonitor"),
    "get_video_frames_generator": ("eye.utils.video", "get_video_frames_generator"),
    "process_video": ("eye.utils.video", "process_video"),

    # Common annotators
    "BoxAnnotator": ("eye.annotators.core", "BoxAnnotator"),
    "TraceAnnotator": ("eye.annotators.core", "TraceAnnotator"),
    "BoxCornerAnnotator": ("eye.annotators.core", "BoxCornerAnnotator"),
    "BoundingBoxAnnotator": ("eye.annotators.core", "BoundingBoxAnnotator"),
    "LabelAnnotator": ("eye.annotators.core", "LabelAnnotator"),
    "MaskAnnotator": ("eye.annotators.core", "MaskAnnotator"),
    "HeatMapAnnotator": ("eye.annotators.core", "HeatMapAnnotator"),
    "ColorLookup": ("eye.annotators.utils", "ColorLookup"),
}


_MODERN_EXPORTS = {
    "GradientBoxAnnotator",
    "NeonTraceAnnotator",
    "ShadowBoxAnnotator",
    "CornerBoxAnnotator",
    "FPSAnnotator",
    "InfoAnnotator",
}


__all__ = sorted({"__version__", *_EXPORTS.keys(), *_MODERN_EXPORTS})


def __getattr__(name: str) -> Any:  # PEP 562
    if name in _EXPORTS:
        module_name, attr_name = _EXPORTS[name]
        module = importlib.import_module(module_name)
        value = getattr(module, attr_name)
        globals()[name] = value
        return value

    if name in _MODERN_EXPORTS:
        try:
            module = importlib.import_module("eye.annotators.modern")
            value = getattr(module, name)
        except Exception:
            # Keep the same behavior as the old eager-import version.
            if name == "GradientBoxAnnotator":
                value = __getattr__("BoxAnnotator")
            elif name == "NeonTraceAnnotator":
                value = __getattr__("TraceAnnotator")
            elif name == "ShadowBoxAnnotator":
                value = __getattr__("BoxAnnotator")
            elif name == "CornerBoxAnnotator":
                value = __getattr__("BoxCornerAnnotator")
            elif name in {"FPSAnnotator", "InfoAnnotator"}:
                value = None
            else:
                raise

        globals()[name] = value
        return value

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
