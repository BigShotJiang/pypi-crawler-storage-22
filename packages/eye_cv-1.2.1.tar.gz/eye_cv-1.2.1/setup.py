from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="eye-cv",
    version="1.2.1",
    author="kokouvi",
    description="Eye - Simple & Powerful Computer Vision. Auto-convert, smart tracking, jitter reduction.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    include_package_data=True,
    package_data={"eye": ["py.typed"]},
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Scientific/Engineering :: Image Recognition",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
    ],
    python_requires=">=3.8",
    install_requires=[
        "opencv-python>=4.8.0",
        "numpy>=1.24.0",
        "matplotlib>=3.7.0",
        "tqdm>=4.66.0",
    ],
    extras_require={
        "smooth": [
            "filterpy>=1.4.5",
        ],
        "track": [
            "lap>=0.4.0",
        ],
        "web-flask": [
            "flask>=2.3.0",
            "flask-cors>=4.0.0",
        ],
        "web-fastapi": [
            "fastapi>=0.104.0",
            "uvicorn>=0.24.0",
        ],
        "web": [
            "flask>=2.3.0",
            "flask-cors>=4.0.0",
            "fastapi>=0.104.0",
            "uvicorn>=0.24.0",
        ],
        "all": [
            "filterpy>=1.4.5",
            "lap>=0.4.0",
            "flask>=2.3.0",
            "flask-cors>=4.0.0",
            "fastapi>=0.104.0",
            "uvicorn>=0.24.0",
        ],
        "dev": [
            "pytest>=7.4.0",
            "black>=23.0.0",
            "flake8>=6.0.0",
            "build>=1.0.0",
            "twine>=5.0.0",
        ],
    },
)
