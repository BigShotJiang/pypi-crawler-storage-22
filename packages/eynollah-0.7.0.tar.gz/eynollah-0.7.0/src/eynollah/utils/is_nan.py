
def isNaN(num):
    return num != num
