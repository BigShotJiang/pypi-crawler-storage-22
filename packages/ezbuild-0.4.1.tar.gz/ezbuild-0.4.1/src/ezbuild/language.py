from enum import Enum


class Language(Enum):
    C = "c"
    CXX = "cxx"
