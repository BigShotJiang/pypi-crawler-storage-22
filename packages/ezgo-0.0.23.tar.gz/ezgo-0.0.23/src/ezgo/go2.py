import time
import numpy as np
import cv2
import netifaces
import subprocess
from unitree_sdk2py.core.channel import ChannelSubscriber, ChannelFactoryInitialize
from unitree_sdk2py.go2.sport.sport_client import SportClient
from unitree_sdk2py.go2.video.video_client import VideoClient
from unitree_sdk2py.idl.unitree_go.msg.dds_ import SportModeState_


error_code = {
    0: "检查设备状态",
    100: "灵动",
    1001: "阻尼",
    1002: "站立锁定",
    1004: "蹲下",
    2006: "蹲下",
    1006: "打招呼/伸懒腰/舞蹈/拜年/比心/开心",
    1007: "坐下",
    1008: "前跳",
    1009: "扑人",
    1013: "平衡站立",
    1015: "常规行走",
    1016: "常规跑步",
    1017: "常规续航",
    1091: "摆姿势",
    2004: "翻身",   # ???
    2007: "闪避",
    2008: "并腿跑",
    2009: "跳跃跑",
    2010: "经典",
    2011: "倒立",
    2012: "前空翻",
    2013: "后空翻",
    2014: "左空翻",
    2016: "交叉步",
    2017: "直立",
    2019: "牵引",
}


class Go2:
    """
    宇树Go2 运动控制封装类
    适用于：Unitree SDK2 Python接口
    """
    def __init__(self, interface=None, timeout=20.0):
        """
        初始化控制器
        :param interface: 网卡接口名称
        :param timeout: 超时时间（秒）
        """
        self.interface = interface
        self.timeout = timeout
        self.sport_client = None
        self.video_client = None
        self.cap = None
        self.error_code = 0  # 状态码
        
        # 摄像头对象
        self.camera = None

        # 声光控制对象
        self._vui = None

        if self.interface is None:
            self.get_interface()
        
        # 清理标志
        self._initialized = False

    def get_interface(self):
        """获取当前接口"""

        interfaces = netifaces.interfaces()
        for iface in interfaces:
            if iface.startswith("en"):
                self.interface = iface
                break

    def check_go2_connection(self):
        """检查机器狗IP连通性"""
        try:
            # 先尝试不使用sudo ping
            result = subprocess.run(['ping', '-c', '1', '-W', '2', '192.168.123.161'], 
                                  capture_output=True, text=True, timeout=5)
            if result.returncode == 0:
                return True
            
            # 如果不使用sudo失败，尝试使用sudo
            result = subprocess.run(['sudo', 'ping', '-c', '1', '-W', '2', '192.168.123.161'], 
                                  capture_output=True, text=True, timeout=5)
            return result.returncode == 0
        except subprocess.TimeoutExpired:
            print("ping超时")
            return False
        except Exception as e:
            print(f"检查连接时出错: {e}")
            return False
        



    def init(self):
        """初始化与Go2的连接"""
        
        # 检查机器狗IP连通性（仅作为警告，不阻止初始化）
        if not self.check_go2_connection():
            print("警告：无法ping通机器狗IP，但继续尝试初始化SDK")
            print("请确保机器狗已开机且网络连接正常")
        
        try:
            ChannelFactoryInitialize(0, self.interface)

            # 启动状态订阅
            self.sub_state(self.callback)

            # 初始化运动控制客户端
            self.sport_client = SportClient()
            self.sport_client.SetTimeout(self.timeout)
            self.sport_client.Init()
            
            # 注意：视频流不再自动初始化，按需开启
            # self.cap = self.open_video()  # 移除自动初始化
            
            self._initialized = True
            print("Go2 SDK初始化成功")
            return True
        except Exception as e:
            print(f"SDK初始化失败: {e}")
            return False
        

    def open_video(self, width: int = 480, height: int = 320):
        """打开视频流"""
        gstreamer_str = (
            f"udpsrc address=230.1.1.1 port=1720 multicast-iface={self.interface} "
            "! application/x-rtp, media=video, encoding-name=H264 "
            "! rtph264depay ! h264parse "
            "! avdec_h264 "  # 解码H.264
            "! videoscale "  # 添加缩放元素，用于调整分辨率
            f"! video/x-raw,width={width},height={height} "  # 目标分辨率
            "! videoconvert ! video/x-raw, format=BGR "  # 转换为OpenCV支持的BGR格式
            "! appsink drop=1"
        )
        cap = cv2.VideoCapture(gstreamer_str, cv2.CAP_GSTREAMER)
        if not cap.isOpened():
            print("视频流打开失败")
            print(f"使用的网络接口: {self.interface}")
            print("GStreamer字符串:", gstreamer_str)
            return None
        print("视频流打开成功")
        return cap

    def read_image(self):
        """从视频流获取一帧图像"""
        if self.cap is None:
            print("视频流未打开，请先调用 open_video()")
            return None
            
        ret, frame = self.cap.read()
        if not ret:
            print("读取图像失败")
            return None
        return frame

    
    def sub_state(self, callback, queue_size: int = 5):
        subscriber = ChannelSubscriber("rt/sportmodestate", SportModeState_)
        subscriber.Init(callback, queue_size)

    def callback(self, msg):
        self.error_code = msg.error_code


    # def read_image(self):
    #     """从视频流获取一帧图像"""
    #     code, data = self.video_client.GetImageSample()
    #     if code != 0 or data is None:
    #         print("获取图像样本失败，错误码:", code)
    #         return None
    #     image_data = np.frombuffer(bytes(data), dtype=np.uint8)
    #     image = cv2.imdecode(image_data, cv2.IMREAD_COLOR)
    #     return image

    def Damp(self):
        """进入阻尼状态。"""
        ret = self.sport_client.Damp()
        print(f"Damp 执行结果: {ret}")
        return ret == 0

    def BalanceStand(self):
        """解除锁定。"""
        ret = self.sport_client.BalanceStand()
        print(f"BalanceStand 执行结果: {ret}")
        return ret == 0

    def StopMove(self):
        """停止移动"""
        # 使用 Move(0, 0, 0) 停止，而不是 StopMove()，避免重置模式
        self.sport_client.Move(0, 0, 0)

    def StandUp(self):
        """ 关节锁定，站高。"""
        self.sport_client.StandUp()
        return True



    def StandDown(self):
        """ 关节锁定，站低。"""
        self.sport_client.StandDown()
        return True

    def RecoveryStand(self):
        """	恢复站立。"""
        self.sport_client.RecoveryStand()
        return True

    def Euler(self, roll, pitch, yaw):
        """站立和行走时的姿态。"""
        pass

    def Move(self, vx, vy, vyaw):
        """移动"""
        self.sport_client.Move(vx, vy, vyaw)
        return True

    def MoveForDuration(self, vx, vy, vyaw, duration):
        """
        持续移动指定时间

        Args:
            vx (float): 前后速度 (-1.0 到 1.0)
            vy (float): 左右速度 (-1.0 到 1.0)
            vyaw (float): 转动速度 (-2.0 到 2.0)
            duration (float): 移动时间（秒）

        Returns:
            bool: 是否成功执行
        """
        # 立即发送移动指令
        self.sport_client.Move(vx, vy, vyaw)
        
        start_time = time.time()
        try:
            # 持续发送移动指令保持移动
            while time.time() - start_time < duration:
                self.sport_client.Move(vx, vy, vyaw)
                time.sleep(0.01)  # 每10ms调用一次，保持流畅

            # 时间到后，发送零速度停止移动（不调用StopMove，避免重置模式）
            self.sport_client.Move(0, 0, 0)
            return True

        except KeyboardInterrupt:
            self.sport_client.Move(0, 0, 0)
            return False

    def Forward(self, speed=0.3, duration=2.0):
        """向前移动"""
        return self.MoveForDuration(speed, 0, 0, duration)

    def Backward(self, speed=0.3, duration=2.0):
        """向后移动"""
        return self.MoveForDuration(-speed, 0, 0, duration)

    def Left(self, speed=0.3, duration=2.0):
        """向左移动"""
        return self.MoveForDuration(0, speed, 0, duration)

    def Right(self, speed=0.3, duration=2.0):
        """向右移动"""
        return self.MoveForDuration(0, -speed, 0, duration)

    def TurnLeft(self, speed=0.5, duration=2.0):
        """左转"""
        return self.MoveForDuration(0, 0, speed, duration)

    def TurnRight(self, speed=0.5, duration=2.0):
        """右转"""
        return self.MoveForDuration(0, 0, -speed, duration)

    def StartMove(self, vx, vy, vyaw):
        """
        开始持续移动，需要调用StopMove来停止

        Args:
            vx (float): 前后速度 (-1.0 到 1.0)
            vy (float): 左右速度 (-1.0 到 1.0)
            vyaw (float): 转动速度 (-2.0 到 2.0)

        Returns:
            bool: 是否成功开始移动
        """
        print(f"开始持续移动: vx={vx}, vy={vy}, vyaw={vyaw}")
        return self.Move(vx, vy, vyaw)

    def StartForward(self, speed=0.3):
        """开始向前移动"""
        return self.StartMove(speed, 0, 0)

    def StartBackward(self, speed=0.3):
        """开始向后移动"""
        return self.StartMove(-speed, 0, 0)

    def StartLeft(self, speed=0.3):
        """开始向左移动"""
        return self.StartMove(0, speed, 0)

    def StartRight(self, speed=0.3):
        """开始向右移动"""
        return self.StartMove(0, -speed, 0)

    def StartTurnLeft(self, speed=0.5):
        """开始左转"""
        return self.StartMove(0, 0, speed)

    def StartTurnRight(self, speed=0.5):
        """开始右转"""
        return self.StartMove(0, 0, -speed)

    def Sit(self):
        """ 坐下。"""
        ret = self.sport_client.Sit()
        print(f"Sit 执行结果: {ret}")
        return ret == 0

    def RiseSit(self):
        """ 站起（相对于坐下）。"""
        ret = self.sport_client.RiseSit()
        print(f"RiseSit 执行结果: {ret}")
        return ret == 0



    def SpeedLevel(self, level: int):
        """设置速度档位。"""
        pass

    def Hello(self):
        """
        打招呼
        执行后状态: 1013:平衡站立
        """
        ret = self.sport_client.Hello()
        print(f"Hello 执行结果: {ret}")
        return ret == 0

    def Stretch(self):
        """
        伸懒腰。
        执行后状态: 1013:平衡站立
        """
        ret = self.sport_client.Stretch()
        print(f"Stretch 执行结果: {ret}")
        return ret == 0

    def Content(self):
        """
        开心。
        执行后状态: 1013:平衡站立
        """
        ret = self.sport_client.Content()
        print(f"Content 执行结果: {ret}")
        return ret == 0

    def Heart(self):
        """
        比心。
        执行后状态: 1013:平衡站立
        """
        ret = self.sport_client.Heart()
        print(f"Heart 执行结果: {ret}")
        return ret == 0


    def Pose(self, flag):
        """摆姿势。"""
        pass

    def Scrape(self):
        """ 拜年作揖。"""
        ret = self.sport_client.Scrape()
        print(f"Scrape 执行结果: {ret}")
        return ret == 0



    def FrontJump(self):
        """ 前跳。"""
        ret = self.sport_client.FrontJump()
        print(f"FrontJump 执行结果: {ret}")
        return ret == 0



    def FrontPounce(self):
        """ 向前扑人。"""
        ret = self.sport_client.FrontPounce()
        print(f"FrontPounce 执行结果: {ret}")
        return ret == 0


    def Dance1(self):
        """ 舞蹈段落1。"""
        ret = self.sport_client.Dance1()
        print(f"Dance1 执行结果: {ret}")
        return ret == 0

    def Dance2(self):
        """ 舞蹈段落2。"""
        ret = self.sport_client.Dance2()
        print(f"Dance2 执行结果: {ret}")
        return ret == 0

    def HandStand(self, flag: int):
        """倒立行走。flag=1开启，flag=0关闭。"""
        ret = self.sport_client.HandStand(bool(flag))
        print(f"HandStand({flag}) 执行结果: {ret}")
        return ret == 0

    def LeftFlip(self):
        """左空翻。"""
        ret = self.sport_client.LeftFlip()
        print(f"LeftFlip 执行结果: {ret}")
        return ret == 0

    def BackFlip(self):
        """后空翻。"""
        ret = self.sport_client.BackFlip()
        print(f"BackFlip 执行结果: {ret}")
        return ret == 0

    def FreeWalk(self, flag: int = None):
        """ 灵动模式（默认步态）。"""
        self.sport_client.FreeWalk()
        return True

    def FreeBound(self, flag: int):
        """ 并腿跑模式。flag=1开启，flag=0关闭。"""
        self.sport_client.FreeBound(bool(flag))
        return True

    def FreeJump(self, flag: int):
        """ 跳跃模式。flag=1开启，flag=0关闭。"""
        self.sport_client.FreeJump(bool(flag))
        return True

    def FreeAvoid(self, flag: int):
        """ 闪避模式。flag=1开启，flag=0关闭。开启后可配合Move函数进行自动避障移动。"""
        self.sport_client.FreeAvoid(bool(flag))
        return True

    def WalkUpright(self, flag: int):
        """ 后腿直立模式。flag=1开启，flag=0关闭。"""
        self.sport_client.WalkUpright(bool(flag))
        return True

    def CrossStep(self, flag: int):
        """ 交叉步模式。flag=1开启，flag=0关闭。"""
        self.sport_client.CrossStep(bool(flag))
        return True

    def AutoRecoverSet(self, flag: int):
        """ 设置自动翻身是否生效。"""
        try:
            ret = self.sport_client.AutoRecoverSet(bool(flag))
            print(f"AutoRecoverSet({flag}) 执行结果: {ret}")
            return ret == 0
        except AttributeError:
            print("警告: AutoRecoverSet 方法在当前SDK版本中不可用")
            return False

    def AutoRecoverGet(self):
        """ 查询自动翻身是否生效。"""
        try:
            ret = self.sport_client.AutoRecoverGet()
            print(f"AutoRecoverGet 执行结果: {ret}")
            return ret
        except AttributeError:
            print("警告: AutoRecoverGet 方法在当前SDK版本中不可用")
            return False

    def ClassicWalk(self, flag: int):
        """ 经典步态。"""
        self.sport_client.ClassicWalk(bool(flag))
        return True

    def TrotRun(self):
        """ 进入常规跑步模式 """
        self.sport_client.TrotRun()
        return True

    def StaticWalk(self):
        """ 进入常规行走模式 """
        self.sport_client.StaticWalk()
        return True

    def EconomicGait(self):
        """ 进入常规续航模式 """
        self.sport_client.EconomicGait()
        return True

    def SwitchAvoidMode(self):
        """ 闪避模式下，关闭摇杆未推时前方障碍物的闪避以及后方的障碍物躲避"""
        try:
            ret = self.sport_client.SwitchAvoidMode()
            print(f"SwitchAvoidMode 执行结果: {ret}")
            return ret == 0
        except AttributeError:
            print("警告: SwitchAvoidMode 方法在当前SDK版本中不可用")
            return False
    
    def get_camera(self):
        """
        获取摄像头对象（按需初始化）
        
        Returns:
            Go2Camera: 摄像头控制对象
        """
        if self.camera is None:
            # 直接导入go2_camera模块
            from .go2_camera import Go2Camera
            self.camera = Go2Camera(self.interface, self.timeout)
            # 注意：这里不自动初始化，让用户按需调用
        return self.camera
    
    def get_vui(self):
        """
        获取声光控制对象（按需初始化）
        
        Returns:  
            Go2VUI: 声光控制对象
        """
        if not hasattr(self, '_vui') or self._vui is None:
            # 直接导入go2_vui模块
            from .go2_vui import Go2VUI
            self._vui = Go2VUI(self.interface)
            # 注意：这里不自动初始化，让用户按需调用
        return self._vui
    
    def capture_image(self, save_path=None):
        """
        便利方法：获取一张图片（按需初始化摄像头）
        
        Args:
            save_path (str): 保存路径
            
        Returns:
            numpy.ndarray: 图像数据
        """
        camera = self.get_camera()
        if not camera.init(self.interface):
            print("摄像头初始化失败")
            return None
        return camera.capture_image(save_path)
    
    def start_video_stream(self, width=480, height=320):
        """
        便利方法：开始视频流（按需初始化摄像头）
        
        Args:
            width (int): 视频宽度
            height (int): 视频高度
            
        Returns:
            bool: 是否成功
        """
        camera = self.get_camera()
        if not camera.init(self.interface):
            print("摄像头初始化失败")
            return False
        return camera.start_stream(width, height)
    
    def get_video_frame(self):
        """
        便利方法：获取最新视频帧
        
        Returns:
            numpy.ndarray: 图像数据
        """
        if self.camera is None:
            print("视频流未启动，请先调用 start_video_stream()")
            return None
        return self.camera.get_latest_frame()
    
    def stop_video_stream(self):
        """便利方法：停止视频流"""
        if self.camera:
            self.camera.stop_stream()
    
    def cleanup(self):
        """清理资源，停止所有连接"""
        if not self._initialized:
            return

        print("正在清理Go2资源...")

        # 清理摄像头资源
        if self.camera is not None:
            try:
                self.camera.cleanup()
                self.camera = None
            except:
                pass

        # 释放视频流
        if self.cap is not None:
            try:
                self.cap.release()
                self.cap = None
            except:
                pass

        # 清理DDS连接
        try:
            from unitree_sdk2py.core.channel import ChannelFactoryRelease
            ChannelFactoryRelease()
        except:
            pass

        self._initialized = False
        print("Go2资源清理完成")
    
    def __del__(self):
        """析构函数，自动清理资源"""
        try:
            self.cleanup()
        except:
            pass




# -------------------- 测试 --------------------
if __name__ == "__main__":
    interface = "enx00e0986113a6"  # 替换为你的Go2网卡接口名称
    
    go2 = Go2(interface=interface)

    go2.stand_down()
    go2.stand_up()
