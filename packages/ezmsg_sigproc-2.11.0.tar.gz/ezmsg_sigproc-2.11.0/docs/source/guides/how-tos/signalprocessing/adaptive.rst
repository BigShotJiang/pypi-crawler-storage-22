How to implement adaptive signal processing in ezmsg?
#######################################################

(under construction)