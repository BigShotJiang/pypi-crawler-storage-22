How to write a signal processor in ezmsg?
#########################################

For general processor implementation guidance, see the `ezmsg-baseproc documentation <https://www.ezmsg.org/ezmsg-baseproc/guides/ProcessorsBase.html>`_.

For signal processing specific patterns, see the existing processors in ``ezmsg.sigproc`` as examples.

(under construction)
