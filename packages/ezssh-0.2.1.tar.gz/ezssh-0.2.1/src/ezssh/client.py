
from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, Sequence, Union
from pathlib import Path
import shlex
import time

from ezssh.utils import classify_keyfile
from ezssh.exceptions import *
from ezssh.models import *

import paramiko


SUPPORTED_KEYS = [
     'rsa',
     'dsa',
     'ecdsa',
     'ed25519'
]

def _discover_identity_files(identity_dir: str) -> list[str]:
    """
    Return a list of candidate *private* key files in `identity_dir`.

    Heuristics:
      - ignore directories
      - ignore obvious public keys (*.pub) and known_hosts/config files
      - keep files that classify as a supported private key type
    """
    if identity_dir is None:
        return []

    p = Path(identity_dir).expanduser()
    if not p.exists() or not p.is_dir():
        raise ValueError(f"identity_dir is not a directory: {identity_dir}")

    deny_names = {"known_hosts", "config", "authorized_keys"}
    candidates: list[str] = []

    for f in sorted(p.iterdir()):
        if not f.is_file():
            continue
        if f.name in deny_names:
            continue
        if f.suffix == ".pub":
            continue

        try:
            key_type = classify_keyfile(str(f))
        except Exception:
            continue

        if key_type in SUPPORTED_KEYS:
            candidates.append(str(f))

    return candidates

def _compose_command(c: Command) -> str:
    """
    Build a remote shell string that supports env + cwd + sudo.

    WARNING: Env/cwd and Sudo are in alpha.

        Note: this uses shell concatenation; for hostile input, callers should be careful.

    """

    special = c.cwd or c.env or c.sudo

    parts = []
    if c.env:
        # export KEY=VALUE ...
        exports = " ".join(f"{k}={shlex.quote(v)}" for k, v in c.env.items())
        parts.append(f"export {exports}")
        
    if c.cwd:
        parts.append(f"cd {shlex.quote(c.cwd)}")

    if c.sudo:
        # -n: non-interactive, fail if password required
        cmd = f"sudo -n -- {c.cmd}"

    if special:
        # appending requested command after env/dir setup.
        parts.append(c.cmd)
        return " && ".join(parts)
    else:
        # default command
        return c.cmd

@dataclass
class SSHRunner:

    host: str
    username: str
    port: int = 22
    keys_dir: Optional[str] = None
    pkey: Optional[paramiko.PKey] = None
    pkey_file: Optional[str] = None
    password: Optional[str] = None
    known_hosts: Optional[str] = None  # path if you want
    missing_host_key_policy: str = "autoadd"  # "autoadd" | "reject"
    connect_timeout: float = 10.0

    _client: Optional[paramiko.SSHClient] = None

    def connect(self) -> "SSHRunner":
        """        
        Establishes an SSH connection to the remote host using the provided credentials.

        This method initializes a Paramiko SSHClient, sets up host key policies, loads
        known hosts if specified, and attempts to connect using either a private key file,
        a password, or both. If a private key file is provided, it is classified and
        loaded into the appropriate Paramiko key type.

        :return: The SSHRunner instance, allowing for method chaining.
        :rtype: SSHRunner

        :raises SSHConnectionError: If the connection to the SSH server fails.
        :raises UnsupportedKeyError: If the private key file is of an unsupported type.
        :raises SSHKeyError: If the private key file cannot be decoded or classified.
        """
        try:
            client = paramiko.SSHClient()
            use_password = self.password is not None
            key_filenames: list[str] = _discover_identity_files(self.keys_dir)

            if self.missing_host_key_policy == "autoadd":
                client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            else:
                client.set_missing_host_key_policy(paramiko.RejectPolicy())

            if self.pkey_file:
                # classifies keyfile suite.
                key_type = classify_keyfile(self.pkey_file)
                if key_type != "unknown":
                    # if RSA
                    if key_type == 'rsa':
                        self.pkey = paramiko.RSAKey.from_private_key_file(self.pkey_file)
                    # if DSA
                    # elif key_type == 'dsa':
                    #     self.pkey = paramiko.DSSKey.from_private_key_file(self.pkey_file)
                    # if ED25519
                    elif key_type == 'ecdsa':
                        self.pkey = paramiko.ECDSAKey.from_private_key_file(self.pkey_file)

                    elif key_type == 'ed25519':
                        self.pkey = paramiko.Ed25519Key.from_private_key_file(self.pkey_file)
                    else:
                        raise UnsupportedKeyError(f"{key_type} keys are not currently supported.")
                elif key_type == "encrypted": 
                    raise UnsupportedKeyError(f"{key_type} keys are not currently supported. Please remove it from specified directory, or use another.")
                else:                
                    raise SSHKeyError('Keyfile decoding failed. Key type could not be classified.')

            # If no explicit key/password provided, and identity_dir is set,
            # attempt auth using keys found in that directory.
            if (not use_password) and (self.pkey is None) and (not self.pkey_file) and self.keys_dir:
                discovered = _discover_identity_files(self.keys_dir)
                if not discovered or len(discovered) == 0:
                    raise SSHKeyError(f"No supported private keys found in identity_dir: {self.keys_dir}")
                key_filenames = discovered

                for key in key_filenames:
                    # try client.connect with current key
                    try:
                        client.connect(
                            hostname=self.host,
                            port=self.port,
                            username=self.username,
                                        key_filename=key,
                            timeout=self.connect_timeout,
                            banner_timeout=self.connect_timeout,
                            auth_timeout=self.connect_timeout,
                                        look_for_keys=False,
                                        allow_agent=False,
                        )
                        # If we successfully connected, return early
                        self._client = client
                        return self
                    except paramiko.AuthenticationException:
                        # If authentication failed, continue to next key
                        continue
                    except Exception:
                        # For other exceptions, re-raise
                        raise

            client.connect(
                hostname=self.host,
                port=self.port,
                username=self.username,
                pkey=self.pkey,
                password=self.password,
                timeout=self.connect_timeout,
                banner_timeout=self.connect_timeout,
                auth_timeout=self.connect_timeout,
                # If we're explicitly providing key_filename, don't also sweep ~/.ssh or ssh-agent.
                look_for_keys=(not use_password and self.pkey is None and key_filenames is None),
                allow_agent=(not use_password and self.pkey is None and key_filenames is None),
            )
            self._client = client
            return self

        except Exception as e:
            raise SSHKeyError(f"Failed to establish SSH connection: {e}")

    def close(self) -> None:
        if self._client:
            self._client.close()
            self._client = None

    def __enter__(self) -> "SSHRunner":
        return self.connect()

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def run(self, cmd: Union[str, Command], timeout: Optional[float] = None) -> CommandResult:
        """
        Executes a single command on the remote SSH server.

        :param cmd: The command to execute, either as a string or a Command object.
        :type cmd: Union[str, Command]
        :param timeout: Optional timeout in seconds for the command execution.
        :type timeout: Optional[float]
        :return: The result of the command execution.
        :rtype: CommandResult
        :raises SSHConnectionError: If the SSH connection is not established.
        :raises SSHCommandError: If the command execution fails.
        """
        if self._client is None:
            raise SSHConnectionError("Not connected. Use SSHRunner(...).connect() or context manager.")

        command = cmd if isinstance(cmd, Command) else Command(cmd=cmd, timeout=timeout)

        started = time.time()
        remote = _compose_command(command)

        # get_pty is sometimes required if sudo prompts, but we use sudo -n to avoid prompts
        stdin, stdout, stderr = self._client.exec_command(remote, timeout=command.timeout)

        # Paramiko's exec_command timeout is a socket timeout, not a hard kill.
        # We'll still read until exit status is available or channel indicates completion.
        exit_status = stdout.channel.recv_exit_status()

        out = stdout.read().decode(errors="replace")
        err = stderr.read().decode(errors="replace")
        finished = time.time()

        return CommandResult(
            command=command,
            exit_status=exit_status,
            stdout=out,
            stderr=err,
            started_at=started,
            finished_at=finished,
        )

    def run_batch(
        self,
        commands: Sequence[Union[str, Command]],
        policy: BatchPolicy = BatchPolicy(stop_on_failure=True),
    ) -> BatchResult:
        """
        Executes a sequence of commands on the remote SSH server sequentially.

        :param commands: A sequence of commands to execute, either as strings or Command objects.
        :type commands: Sequence[Union[str, Command]]
        :param policy: The batch execution policy, determining behavior on command failure.
        :type policy: BatchPolicy
        :return: The result of the batch execution, containing results for each command.
        :rtype: BatchResult
        :raises SSHCommandError: If a command fails and the policy is set to stop on failure.
        """
        batch = BatchResult()

        for item in commands:
            c = item if isinstance(item, Command) else Command(cmd=str(item))
            result = self.run(c)
            batch.results.append(result)

            if policy.stop_on_failure and not result.ok:
                raise SSHCommandError(
                    message=f"Command failed: {c.name or c.cmd}",
                    exit_status=result.exit_status,
                )

        return batch

