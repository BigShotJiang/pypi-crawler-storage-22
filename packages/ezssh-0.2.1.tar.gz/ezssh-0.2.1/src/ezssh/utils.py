from __future__ import annotations

from typing import Optional, Literal
import paramiko


KeyType = Literal["rsa", "dsa", "ecdsa", "ed25519", "encrypted", "unknown"]

def classify_keyfile(key_file: str, passphrase: Optional[str] = None) -> KeyType:
    """
    Classify an SSH private key file using Paramiko's parsers.

    Returns:
      - "rsa", "dsa", "ecdsa", "ed25519" when it can be loaded
      - "encrypted" if the key is encrypted and no passphrase was provided
      - "unknown" otherwise
    """
    # Fast path: identify OpenSSH container (common case)
    try:
        with open(key_file, "r", encoding="utf-8", errors="ignore") as f:
            head = f.read(2048)
    except Exception:
        return "unknown"

    if "BEGIN OPENSSH PRIVATE KEY" in head:
        # It's OpenSSH container. The actual key type is inside.
        # Paramiko will tell us which loader succeeds.
        pass

    loaders = [
        ("ed25519", paramiko.Ed25519Key),
        ("ecdsa", paramiko.ECDSAKey),
        ("rsa", paramiko.RSAKey),
    ]

    for key_name, cls in loaders:
        try:
            cls.from_private_key_file(key_file, password=passphrase)
            return key_name  # type: ignore[return-value]
        except paramiko.PasswordRequiredException:
            return "encrypted"
        except paramiko.SSHException:
            # Not this key type / not parseable by this loader
            continue
        except Exception:
            continue

    return "unknown"