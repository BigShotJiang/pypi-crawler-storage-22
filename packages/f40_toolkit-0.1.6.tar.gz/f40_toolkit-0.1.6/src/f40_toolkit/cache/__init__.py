import importlib
from typing import Any

__all__ = [
    "CacheManager",
    "MemoryCacheBackend",
    "FileCacheBackend",
    "RedisCacheBackend",
]

_LAZY = {
    "CacheManager": "f40_toolkit.cache.manager",
    "MemoryCacheBackend": "f40_toolkit.cache.backends.memory_backend",
    "FileCacheBackend": "f40_toolkit.cache.backends.file_backend",
    "RedisCacheBackend": "f40_toolkit.cache.backends.redis_backend",
}


def __getattr__(name: str) -> Any:
    mod = _LAZY.get(name)
    if not mod:
        raise AttributeError(name)
    module = importlib.import_module(mod)
    return getattr(module, name)
