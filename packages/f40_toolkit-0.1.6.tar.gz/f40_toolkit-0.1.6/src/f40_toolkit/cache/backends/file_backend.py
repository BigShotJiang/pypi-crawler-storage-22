from __future__ import annotations

import os
import threading
import time
from pathlib import Path
from typing import Any, Dict, Optional
from fnmatch import fnmatchcase
import logging

from f40_toolkit.common.fs import read_json_safe, atomic_write_json
from f40_toolkit.cache.interfaces import CacheBackend, Serializer
from f40_toolkit.cache.serializers import JsonSerializer
from f40_toolkit.cache.errors import InvalidCacheValue

# stdlib logger only; no implicit configuration
log = logging.getLogger("f40.cache.file")


class FileCacheBackend(CacheBackend):
    """
    Simple file-based cache:

    - index.json holds metadata (expiries)
    - cache.blob holds hex-encoded serialized values keyed by cache key
    - Writes are atomic via os.replace to survive crashes.
    - Thread-safe via RLock.

    TTL is an effective ttl from CacheManager:
        None  -> no expiry
        <=0   -> do not cache
        >0    -> expire in ttl seconds
    """

    def __init__(
        self,
        cache_dir: str | os.PathLike[str],
        serializer: Optional[Serializer] = None,
    ):
        self.cache_dir = str(Path(cache_dir).resolve())
        self.serializer = serializer or JsonSerializer()

        self._idx_path = str(Path(self.cache_dir) / "index.json")
        self._blob_path = str(Path(self.cache_dir) / "cache.blob")
        self._lock = threading.RLock()

        os.makedirs(self.cache_dir, exist_ok=True)
        if not os.path.exists(self._idx_path):
            atomic_write_json(self._idx_path, {})
        if not os.path.exists(self._blob_path):
            atomic_write_json(self._blob_path, {})

        log.info(
            "FileCacheBackend initialized cache_dir=%s idx=%s blob=%s",
            self.cache_dir,
            self._idx_path,
            self._blob_path,
        )

    @staticmethod
    def _now() -> float:
        return time.time()

    def get(self, key: str) -> Any:
        with self._lock:
            idx: Dict[str, Any] = read_json_safe(self._idx_path)
            meta = idx.get(key)
            if not meta:
                raise KeyError(key)

            exp = meta.get("exp")  # None => no expiry
            if exp is not None and self._now() > float(exp):
                self.invalidate(key)
                raise KeyError(key)

            blob: Dict[str, Any] = read_json_safe(self._blob_path)
            raw = blob.get(key)
            if raw is None:
                self.invalidate(key)
                raise KeyError(key)

            try:
                data = bytes.fromhex(raw)
            except Exception as e:
                # Corrupt on-disk value
                try:
                    self.invalidate(key)
                except Exception:
                    pass
                raise InvalidCacheValue(key) from e

            try:
                return self.serializer.loads(data)
            except Exception as e:
                try:
                    self.invalidate(key)
                except Exception:
                    pass
                raise InvalidCacheValue(key) from e

    def set(self, key: str, value: Any, ttl: Optional[int]) -> None:
        if ttl is not None:
            ttl = int(ttl)

        if ttl is not None and ttl <= 0:
            self.invalidate(key)
            return

        with self._lock:
            idx: Dict[str, Any] = read_json_safe(self._idx_path)
            blob: Dict[str, Any] = read_json_safe(self._blob_path)

            exp = None if ttl is None else self._now() + ttl

            data_hex = self.serializer.dumps(value).hex()
            idx[key] = {"exp": exp}
            blob[key] = data_hex

            atomic_write_json(self._blob_path, blob)
            atomic_write_json(self._idx_path, idx)

    def invalidate(self, key: str) -> None:
        with self._lock:
            idx: Dict[str, Any] = read_json_safe(self._idx_path)
            blob: Dict[str, Any] = read_json_safe(self._blob_path)

            idx.pop(key, None)
            blob.pop(key, None)

            atomic_write_json(self._blob_path, blob)
            atomic_write_json(self._idx_path, idx)

    def clear(self) -> None:
        with self._lock:
            atomic_write_json(self._blob_path, {})
            atomic_write_json(self._idx_path, {})

    def keys(self, pattern: Optional[str] = None) -> list[str]:
        with self._lock:
            idx: Dict[str, Any] = read_json_safe(self._idx_path)
            blob: Dict[str, Any] = read_json_safe(self._blob_path)

            now = self._now()
            valid: list[str] = []
            dirty = False

            for k, meta in list(idx.items()):
                exp = meta.get("exp")

                if exp is not None and now > float(exp):
                    idx.pop(k, None)
                    blob.pop(k, None)
                    dirty = True
                    continue

                if k not in blob:
                    idx.pop(k, None)
                    dirty = True
                    continue

                valid.append(k)

            for k in list(blob.keys()):
                if k not in idx:
                    blob.pop(k, None)
                    dirty = True

            if dirty:
                atomic_write_json(self._blob_path, blob)
                atomic_write_json(self._idx_path, idx)

            if pattern:
                valid = [k for k in valid if fnmatchcase(k, pattern)]
            return valid
