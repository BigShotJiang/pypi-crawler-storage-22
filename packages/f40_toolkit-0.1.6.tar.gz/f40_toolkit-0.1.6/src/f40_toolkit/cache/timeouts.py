from __future__ import annotations

from typing import Optional, TypeAlias, Union


class _DefaultTimeout:
    """Sentinel used to mean: "use the backend/manager default timeout"."""

    __slots__ = ()

    def __repr__(self) -> str:  # pragma: no cover
        return "DEFAULT_TIMEOUT"


DEFAULT_TIMEOUT = _DefaultTimeout()

Timeout: TypeAlias = Union[int, None, _DefaultTimeout]


def resolve_timeout(timeout: Timeout, default_timeout: Optional[int]) -> Optional[int]:
    """Resolve a user-specified timeout to an effective TTL.

    Semantics:
      - timeout is DEFAULT_TIMEOUT -> use default_timeout
      - timeout is None           -> no expiry
      - timeout <= 0              -> do not cache
      - timeout > 0               -> cache for `timeout` seconds
    """
    if timeout is DEFAULT_TIMEOUT:
        return default_timeout
    return timeout
