from __future__ import annotations

import json
from pathlib import Path

import pytest

from f40_toolkit.cache.backends.memory_backend import MemoryCacheBackend
import f40_toolkit.cache.backends.memory_backend as mem_mod

from f40_toolkit.cache.backends.file_backend import FileCacheBackend
import f40_toolkit.cache.backends.file_backend as file_mod

from f40_toolkit.cache.manager import CacheManager


def test_memory_backend_keys_lists_current_keys(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    now = {"t": 1_000.0}
    monkeypatch.setattr(mem_mod.time, "time", lambda: now["t"])

    b = MemoryCacheBackend(default_timeout=10)
    b.set("a", 1, timeout=5)
    b.set("b", 2, timeout=0)  # ttl<=0 => no expiry in current implementation

    assert set(b.keys()) == {"a", "b"}  # <-- will fail until keys() exists

    now["t"] += 6.0  # advance time beyond "a" expiry
    assert set(b.keys()) == {"b"}

    with pytest.raises(KeyError):
        b.get("a")


def test_file_backend_keys_filters_expired_and_cleans_files(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    now = {"t": 2_000.0}
    monkeypatch.setattr(file_mod.time, "time", lambda: now["t"])

    cache_dir = tmp_path / "cache"
    b = FileCacheBackend(cache_dir=str(cache_dir), default_timeout=10)

    b.set("a", {"x": 1}, timeout=5)
    b.set("b", {"x": 2}, timeout=0)  # no expiry

    assert set(b.keys()) == {"a", "b"}  # <-- will fail until keys() exists

    # Expire "a"
    now["t"] += 6.0
    assert set(b.keys()) == {"b"}

    # After keys(), index/blob should be cleaned of expired entries
    idx = json.loads((cache_dir / "index.json").read_text(encoding="utf-8"))
    blob = json.loads((cache_dir / "cache.blob").read_text(encoding="utf-8"))
    assert "a" not in idx
    assert "a" not in blob
    assert "b" in idx
    assert "b" in blob


def test_cache_manager_keys_delegates(monkeypatch: pytest.MonkeyPatch) -> None:
    now = {"t": 3_000.0}
    monkeypatch.setattr(mem_mod.time, "time", lambda: now["t"])

    backend = MemoryCacheBackend()
    cache = CacheManager(backend)

    cache.set("k1", "v1", timeout=0)
    assert "k1" in set(cache.keys())  # <-- will fail until CacheManager.keys() exists
