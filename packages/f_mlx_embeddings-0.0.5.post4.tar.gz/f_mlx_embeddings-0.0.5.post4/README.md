Nothing but a fork to make heavy dep optional before upstream mlx-embeddings tagging a new release.
