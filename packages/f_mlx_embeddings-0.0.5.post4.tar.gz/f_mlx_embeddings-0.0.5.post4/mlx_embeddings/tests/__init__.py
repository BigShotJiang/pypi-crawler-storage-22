"""Unit test package for mlx_embeddings."""
