# Fabric PBI Client

Python client for the Microsoft Fabric REST API.

## Install

```bash
pip install fabric-pbi
```

## Quick start

```python
from fabricpandas import FabricClient

client = FabricClient()
workspaces = client.list_workspaces()
```

Example `.env` for quick start:

```env
FABRIC_ACCESS_TOKEN=your_access_token_here
```

## Authentication

Authentication is loaded from a `.env` file (default) or your shell. You can:

- Provide a bearer token directly, or
- Use service principal credentials to request a token via MSAL, or
- Use interactive login via system browser.

### Option 1: Access token

Set an access token as an environment variable:

- `FABRIC_ACCESS_TOKEN` (preferred if you already have a token), or
- `tenant_id`, `client_id`, `client_secret` (service principal)

Example `.env`:

```env
FABRIC_ACCESS_TOKEN=your_access_token_here
```

### Option 2: Service principal (MSAL)

Set your Azure AD app credentials in `.env`:

```env
tenant_id=your_tenant_id
client_id=your_client_id
client_secret=your_client_secret
```

The client will request a token for:

- `https://analysis.windows.net/powerbi/api/.default`

Install MSAL if you use service principal auth:

```bash
pip install msal
```

### Option 3: Interactive login (system browser)

Configure a public client app in Azure AD and add a redirect URI of `http://localhost`.
Set your app and tenant IDs in `.env`:

```env
tenant_id=your_tenant_id
client_id=your_client_id
```

Usage:

```python
from fabricpandas import FabricClient

client = FabricClient(interactive_login=True)
```

Or request a token directly:

```python
from fabricpandas.auth import get_fabric_token_interactive

token = get_fabric_token_interactive()
```

### Custom `.env` path

Pass a custom env file path when constructing the client:

```python
from fabricpandas import FabricClient

client = FabricClient(env_file="path/to/.env")
```

## Troubleshooting auth

- `Missing required environment variables`: set `FABRIC_ACCESS_TOKEN` or all of `tenant_id`, `client_id`, `client_secret`.
- `Missing required environment variables for interactive login`: set `tenant_id` and `client_id` and ensure your app is a public client with `http://localhost` redirect URI.
- `msal library is required`: install MSAL with `pip install msal`.
- `Failed to acquire token`: verify Azure AD app credentials and that the app has access to Fabric APIs.

