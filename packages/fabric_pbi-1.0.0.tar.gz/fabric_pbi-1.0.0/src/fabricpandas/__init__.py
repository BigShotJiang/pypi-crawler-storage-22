"""
FabricPandas - Microsoft Fabric REST API Client
A Python client for interacting with Microsoft Fabric APIs
"""

from .client import FabricClient
from .workspace import WorkspaceClient
from .semantic_model import SemanticModelClient
from .report import ReportClient
from .bulks import BulkClient
from .auth import BaseClient

__version__ = "1.0.0"
__all__ = [
    "FabricClient",        # Main convenience class
    "BaseClient",          # Base authentication class
    "WorkspaceClient",     # Workspace operations
    "SemanticModelClient", # Semantic Model operations
    "ReportClient",        # Report operations
    "BulkClient",          # Bulk operations
]

