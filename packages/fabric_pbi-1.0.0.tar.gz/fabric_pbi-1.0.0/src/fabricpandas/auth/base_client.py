"""
Base Fabric API Client
Provides core functionality for Microsoft Fabric REST API interactions.
"""

import requests
from typing import Optional, Dict, Any
from dataclasses import dataclass


def get_fabric_token(env_file: str = ".env") -> str:
    """
    Get Fabric access token from .env file
    
    Args:
        env_file: Path to .env file
        
    Returns:
        Access token string
    """
    import os
    from dotenv import load_dotenv
    
    # Load environment variables
    load_dotenv(env_file)
    
    # Check if we already have an access token in env
    access_token = os.getenv("FABRIC_ACCESS_TOKEN")
    if access_token:
        return access_token
    
    # Otherwise, get token using service principal
    tenant_id = os.getenv("tenant_id")
    client_id = os.getenv("client_id")
    client_secret = os.getenv("client_secret")
    
    if not all([tenant_id, client_id, client_secret]):
        raise ValueError(
            "Missing required environment variables. Please set either:\n"
            "  - FABRIC_ACCESS_TOKEN\n"
            "Or:\n"
            "  - tenant_id, client_id, client_secret"
        )
    
    # Get token using MSAL
    try:
        import msal
        
        authority = f"https://login.microsoftonline.com/{tenant_id}"
        app = msal.ConfidentialClientApplication(
            client_id=client_id,
            authority=authority,
            client_credential=client_secret
        )
        
        # Fabric API scope
        scopes = ["https://analysis.windows.net/powerbi/api/.default"]
        
        result = app.acquire_token_for_client(scopes=scopes)
        
        if "access_token" in result:
            return result["access_token"]
        else:
            error = result.get("error_description", result.get("error", "Unknown error"))
            raise Exception(f"Failed to acquire token: {error}")
            
    except ImportError:
        raise ImportError(
            "msal library is required for service principal authentication. "
            "Install it with: pip install msal"
        )


def get_fabric_token_interactive(
    env_file: str = ".env",
    tenant_id: Optional[str] = None,
    client_id: Optional[str] = None,
    redirect_uri: str = "http://localhost",
    scopes: Optional[list] = None
) -> str:
    """
    Get Fabric access token using interactive login in a system browser.
    
    Args:
        env_file: Path to .env file
        tenant_id: Azure AD tenant ID (optional; falls back to env)
        client_id: Azure AD app client ID (optional; falls back to env)
        redirect_uri: Redirect URI for the public client app
        scopes: Optional list of scopes to request
        
    Returns:
        Access token string
    """
    import os
    from dotenv import load_dotenv
    
    load_dotenv(env_file)
    
    resolved_tenant_id = tenant_id or os.getenv("tenant_id")
    resolved_client_id = client_id or os.getenv("client_id")
    
    if not all([resolved_tenant_id, resolved_client_id]):
        raise ValueError(
            "Missing required environment variables for interactive login. "
            "Please set tenant_id and client_id."
        )
    
    try:
        import msal
        
        authority = f"https://login.microsoftonline.com/{resolved_tenant_id}"
        app = msal.PublicClientApplication(
            client_id=resolved_client_id,
            authority=authority
        )
        
        requested_scopes = scopes or ["https://analysis.windows.net/powerbi/api/.default"]
        
        result = app.acquire_token_interactive(
            scopes=requested_scopes,
            redirect_uri=redirect_uri
        )
        
        if "access_token" in result:
            return result["access_token"]
        
        error = result.get("error_description", result.get("error", "Unknown error"))
        raise Exception(f"Failed to acquire token interactively: {error}")
        
    except ImportError:
        raise ImportError(
            "msal library is required for interactive authentication. "
            "Install it with: pip install msal"
        )


@dataclass
class FabricConfig:
    """Configuration for Fabric API client"""
    base_url: str = "https://api.fabric.microsoft.com/v1"
    access_token: Optional[str] = None


class BaseClient:
    """Base client for Microsoft Fabric API interactions"""
    
    def __init__(
        self,
        access_token: Optional[str] = None,
        base_url: str = "https://api.fabric.microsoft.com/v1",
        env_file: str = ".env",
        interactive_login: bool = False,
        tenant_id: Optional[str] = None,
        client_id: Optional[str] = None,
        redirect_uri: str = "http://localhost"
    ):
        """
        Initialize Fabric client
        
        Args:
            access_token: Bearer token for authentication (optional, will be acquired from .env if not provided)
            base_url: Base URL for Fabric API (default: https://api.fabric.microsoft.com/v1)
            env_file: Path to .env file for authentication (default: ".env")
            interactive_login: Use interactive login flow if no access token provided
            tenant_id: Azure AD tenant ID for interactive login (optional)
            client_id: Azure AD app client ID for interactive login (optional)
            redirect_uri: Redirect URI for interactive login (default: http://localhost)
        """
        # If no access token provided, get one from .env credentials
        if access_token is None:
            if interactive_login:
                access_token = get_fabric_token_interactive(
                    env_file=env_file,
                    tenant_id=tenant_id,
                    client_id=client_id,
                    redirect_uri=redirect_uri
                )
            else:
                access_token = get_fabric_token(env_file)
        
        self.config = FabricConfig(base_url=base_url, access_token=access_token)
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json"
        })
    
    def _make_request(
        self,
        method: str,
        endpoint: str,
        data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None
    ) -> requests.Response:
        """
        Make HTTP request to Fabric API
        
        Args:
            method: HTTP method (GET, POST, PUT, DELETE, PATCH)
            endpoint: API endpoint path
            data: Request body data
            params: Query parameters
            
        Returns:
            Response object
        """
        url = f"{self.config.base_url}/{endpoint.lstrip('/')}"
        
        response = self.session.request(
            method=method,
            url=url,
            json=data,
            params=params
        )
        
        # Raise exception for error status codes
        response.raise_for_status()
        
        return response

