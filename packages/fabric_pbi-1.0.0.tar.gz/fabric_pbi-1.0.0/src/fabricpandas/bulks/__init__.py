"""
Bulk operations module for FabricPandas
"""

from .bulk_client import BulkClient

__all__ = ["BulkClient"]

