"""
Bulk Operations Client for Microsoft Fabric
Provides bulk operations across multiple workspaces and items.
"""

import time
import requests
from pathlib import Path
from typing import Optional, Dict, Any, List, Callable
from concurrent.futures import ThreadPoolExecutor, as_completed
from ..auth import BaseClient
from ..semantic_model import SemanticModelClient
from ..report import ReportClient


class BulkClient(BaseClient):
    """
    Client for performing bulk operations across workspaces and items
    
    Provides methods to:
    - Get all workspaces
    - Get all semantic models across workspaces
    - Get all reports across workspaces
    - Download all definitions in bulk
    - Update multiple items in bulk
    """
    
    def __init__(
        self,
        access_token: Optional[str] = None,
        base_url: str = "https://api.fabric.microsoft.com/v1",
        env_file: str = ".env",
        max_workers: int = 5
    ):
        """
        Initialize Bulk Client
        
        Args:
            access_token: Bearer token for authentication
            base_url: Base URL for Fabric API
            env_file: Path to .env file
            max_workers: Maximum number of parallel workers for bulk operations (default: 5)
        """
        super().__init__(access_token, base_url, env_file)
        self.max_workers = max_workers
        
        # Initialize specialized clients
        self.semantic_model_client = SemanticModelClient(
            access_token=self.config.access_token,
            base_url=base_url
        )
        self.report_client = ReportClient(
            access_token=self.config.access_token,
            base_url=base_url
        )
    
    def _download_with_retry(
        self,
        download_func: Callable,
        max_retries: int = 5,
        initial_delay: int = 2,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Download with exponential backoff retry on 429 errors
        
        Args:
            download_func: Function to call for download
            max_retries: Maximum retry attempts (default: 5)
            initial_delay: Initial delay in seconds (default: 2)
            **kwargs: Arguments to pass to download_func
            
        Returns:
            Result from download_func
            
        Raises:
            Exception: If max retries exceeded or non-recoverable error
        """
        delay = initial_delay
        
        for attempt in range(max_retries):
            try:
                return download_func(**kwargs)
            
            except requests.exceptions.HTTPError as e:
                if e.response.status_code == 429:
                    # Get Retry-After header if available
                    retry_after = e.response.headers.get("Retry-After")
                    if retry_after:
                        try:
                            delay = int(retry_after)
                        except ValueError:
                            pass
                    
                    if attempt < max_retries - 1:
                        print(f"    ⚠️  Rate limited (429). Waiting {delay}s before retry {attempt + 1}/{max_retries}...")
                        time.sleep(delay)
                        # Exponential backoff for next retry
                        delay = min(delay * 2, 60)  # Cap at 60 seconds
                        continue
                    else:
                        # Max retries exceeded
                        raise Exception(f"429 Client Error:  for url: {e.response.url}")
                else:
                    # Non-429 HTTP error, don't retry
                    raise
            
            except Exception as e:
                # Non-HTTP error, don't retry
                raise
        
        raise Exception(f"Failed after {max_retries} retries")
    
    def list_workspaces(
        self,
        continuation_token: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        List all workspaces
        
        Reference: https://learn.microsoft.com/en-us/rest/api/fabric/core/workspaces/list-workspaces
        
        Args:
            continuation_token: Optional token for pagination
            
        Returns:
            Dictionary with workspace list
        """
        endpoint = "workspaces"
        params = {}
        
        if continuation_token:
            params["continuationToken"] = continuation_token
        
        response = self._make_request("GET", endpoint, params=params)
        return response.json()
    
    def get_all_workspaces(self) -> List[Dict[str, Any]]:
        """
        Get all workspaces with automatic pagination
        
        Returns:
            List of all workspaces
        """
        all_workspaces = []
        continuation_token = None
        
        print("Fetching all workspaces...")
        
        while True:
            result = self.list_workspaces(continuation_token=continuation_token)
            workspaces = result.get("value", [])
            all_workspaces.extend(workspaces)
            
            print(f"  Retrieved {len(workspaces)} workspaces (Total: {len(all_workspaces)})")
            
            # Check if there are more pages
            continuation_token = result.get("continuationToken")
            if not continuation_token:
                break
        
        print(f"✓ Total workspaces found: {len(all_workspaces)}\n")
        return all_workspaces
    
    def get_all_semantic_models(
        self,
        workspace_ids: Optional[List[str]] = None,
        include_workspace_info: bool = True
    ) -> List[Dict[str, Any]]:
        """
        Get all semantic models across specified workspaces or all workspaces
        
        Args:
            workspace_ids: List of workspace IDs (if None, fetches from all workspaces)
            include_workspace_info: If True, includes workspace info with each model
            
        Returns:
            List of all semantic models with optional workspace info
        """
        # Get workspaces if not provided
        if workspace_ids is None:
            workspaces = self.get_all_workspaces()
            workspace_ids = [w["id"] for w in workspaces]
            workspace_map = {w["id"]: w for w in workspaces}
        else:
            workspace_map = {}
        
        all_models = []
        
        print(f"Fetching semantic models from {len(workspace_ids)} workspace(s)...\n")
        
        for idx, workspace_id in enumerate(workspace_ids, 1):
            try:
                print(f"[{idx}/{len(workspace_ids)}] Workspace: {workspace_id}")
                result = self.semantic_model_client.list_semantic_models(workspace_id)
                models = result.get("value", [])
                
                # Add workspace info if requested
                if include_workspace_info and workspace_id in workspace_map:
                    for model in models:
                        model["_workspace"] = workspace_map[workspace_id]
                elif include_workspace_info:
                    for model in models:
                        model["_workspace_id"] = workspace_id
                
                all_models.extend(models)
                print(f"  ✓ Found {len(models)} model(s)\n")
                
            except Exception as e:
                print(f"  ✗ Error: {e}\n")
                continue
        
        print(f"{'=' * 60}")
        print(f"Total semantic models found: {len(all_models)}")
        print(f"{'=' * 60}\n")
        
        return all_models
    
    def get_all_reports(
        self,
        workspace_ids: Optional[List[str]] = None,
        include_workspace_info: bool = True
    ) -> List[Dict[str, Any]]:
        """
        Get all reports across specified workspaces or all workspaces
        
        Args:
            workspace_ids: List of workspace IDs (if None, fetches from all workspaces)
            include_workspace_info: If True, includes workspace info with each report
            
        Returns:
            List of all reports with optional workspace info
        """
        # Get workspaces if not provided
        if workspace_ids is None:
            workspaces = self.get_all_workspaces()
            workspace_ids = [w["id"] for w in workspaces]
            workspace_map = {w["id"]: w for w in workspaces}
        else:
            workspace_map = {}
        
        all_reports = []
        
        print(f"Fetching reports from {len(workspace_ids)} workspace(s)...\n")
        
        for idx, workspace_id in enumerate(workspace_ids, 1):
            try:
                print(f"[{idx}/{len(workspace_ids)}] Workspace: {workspace_id}")
                result = self.report_client.list_reports(workspace_id)
                reports = result.get("value", [])
                
                # Add workspace info if requested
                if include_workspace_info and workspace_id in workspace_map:
                    for report in reports:
                        report["_workspace"] = workspace_map[workspace_id]
                elif include_workspace_info:
                    for report in reports:
                        report["_workspace_id"] = workspace_id
                
                all_reports.extend(reports)
                print(f"  ✓ Found {len(reports)} report(s)\n")
                
            except Exception as e:
                print(f"  ✗ Error: {e}\n")
                continue
        
        print(f"{'=' * 60}")
        print(f"Total reports found: {len(all_reports)}")
        print(f"{'=' * 60}\n")
        
        return all_reports
    
    def download_all_semantic_model_definitions(
        self,
        workspace_ids: Optional[List[str]] = None,
        output_base_folder: str = "bulk_semantic_models",
        use_model_id_as_folder: bool = True,
        organize_by_workspace: bool = True,
        parallel: bool = True,
        max_workers: int = 2,
        max_retries: int = 5,
        rate_limit_delay: float = 0.5,
        retry_failed_after: int = 300,
        max_retry_rounds: int = 2
    ) -> Dict[str, Any]:
        """
        Download all semantic model definitions across workspaces with automatic retry rounds
        
        Args:
            workspace_ids: List of workspace IDs (if None, fetches from all workspaces)
            output_base_folder: Base folder for output (default: "bulk_semantic_models")
            use_model_id_as_folder: Use model ID instead of name for folder (default: True)
            organize_by_workspace: Create subfolder for each workspace (default: True)
            parallel: Download in parallel (default: True)
            max_workers: Number of parallel workers (default: 2, reduced to avoid rate limits)
            max_retries: Maximum retry attempts on 429 errors per download (default: 5)
            rate_limit_delay: Delay between requests in seconds (default: 0.5)
            retry_failed_after: Seconds to wait before retrying failed downloads (default: 300 = 5 minutes)
            max_retry_rounds: Maximum number of retry rounds for failed downloads (default: 2)
            
        Returns:
            Dictionary with download statistics and results
        """
        # Get all semantic models
        models = self.get_all_semantic_models(workspace_ids, include_workspace_info=True)
        
        results = {
            "total": len(models),
            "successful": 0,
            "failed": 0,
            "downloads": []
        }
        
        print(f"\n{'=' * 60}")
        print(f"Starting bulk download of {len(models)} semantic model(s)")
        print(f"{'=' * 60}\n")
        
        def download_single_model(model_info):
            """Download a single model definition with retry logic"""
            workspace_id = model_info.get("_workspace_id") or model_info.get("_workspace", {}).get("id")
            model_id = model_info["id"]
            model_name = model_info.get("displayName", model_id)
            
            # Add delay to avoid rate limiting
            time.sleep(rate_limit_delay)
            
            # Determine output folder
            if organize_by_workspace:
                workspace_name = model_info.get("_workspace", {}).get("displayName", workspace_id)
                import re
                workspace_folder = re.sub(r'[<>:"/\\|?*]', "_", workspace_name)
                output_folder = f"{output_base_folder}/{workspace_folder}"
            else:
                output_folder = output_base_folder
            
            try:
                # Download with retry logic for 429 errors
                result = self._download_with_retry(
                    self.semantic_model_client.get_semantic_model_definition,
                    max_retries=max_retries,
                    workspace_id=workspace_id,
                    semantic_model_id=model_id,
                    save_to_folder=True,
                    output_folder=output_folder,
                    use_model_id_as_folder=use_model_id_as_folder
                )
                
                print(f"  ✓ Downloaded: {model_name} ({len(result.get('saved_files', []))} files)")
                
                return {
                    "status": "success",
                    "model_id": model_id,
                    "model_name": model_name,
                    "workspace_id": workspace_id,
                    "output_folder": result.get("output_folder"),
                    "files_count": len(result.get("saved_files", []))
                }
            except Exception as e:
                print(f"  ✗ Failed: {model_name} - {str(e)}")
                return {
                    "status": "failed",
                    "model_id": model_id,
                    "model_name": model_name,
                    "workspace_id": workspace_id,
                    "error": str(e)
                }
        
        # Process downloads with retry rounds
        models_to_process = models.copy()
        retry_round = 0
        all_results = []
        
        while models_to_process and retry_round < max_retry_rounds:
            retry_round += 1
            
            if retry_round > 1:
                print(f"\n{'=' * 60}")
                print(f"🔄 RETRY ROUND {retry_round}: Retrying {len(models_to_process)} failed model(s)")
                print(f"⏰ Waiting {retry_failed_after} seconds before retry...")
                print(f"{'=' * 60}\n")
                time.sleep(retry_failed_after)
            
            round_results = []
            
            # Download models (parallel or sequential)
            if parallel and len(models_to_process) > 1:
                print(f"⚡ Downloading with {max_workers} parallel workers...\n")
                with ThreadPoolExecutor(max_workers=max_workers) as executor:
                    futures = {executor.submit(download_single_model, model): model for model in models_to_process}
                    
                    for future in as_completed(futures):
                        download_result = future.result()
                        round_results.append(download_result)
                        
                        if download_result["status"] == "success":
                            results["successful"] += 1
                        else:
                            results["failed"] += 1
                        
                        # Progress update
                        completed = results["successful"] + results["failed"]
                        print(f"Progress: {completed}/{results['total']} ({results['successful']} ✓, {results['failed']} ✗)")
            else:
                print("📥 Downloading sequentially...\n")
                for idx, model in enumerate(models_to_process, 1):
                    print(f"[{idx}/{len(models_to_process)}] Downloading {model.get('displayName', model['id'])}...")
                    download_result = download_single_model(model)
                    round_results.append(download_result)
                    
                    if download_result["status"] == "success":
                        results["successful"] += 1
                    else:
                        results["failed"] += 1
            
            # Collect failed models for next round
            failed_models = []
            for result in round_results:
                all_results.append(result)
                
                if result["status"] == "failed":
                    # Find the model info to retry
                    model_id = result["model_id"]
                    for model in models_to_process:
                        if model["id"] == model_id:
                            failed_models.append(model)
                            break
            
            # Prepare for next round
            models_to_process = failed_models
            
            # Summary for this round
            round_success = sum(1 for r in round_results if r["status"] == "success")
            round_failed = sum(1 for r in round_results if r["status"] == "failed")
            
            print(f"\n{'=' * 60}")
            print(f"Round {retry_round} Summary:")
            print(f"  Processed: {len(round_results)}")
            print(f"  Successful: {round_success}")
            print(f"  Failed: {round_failed}")
            
            if models_to_process and retry_round < max_retry_rounds:
                print(f"\n⚠️  {len(models_to_process)} model(s) will be retried in next round")
            elif models_to_process:
                print(f"\n⚠️  {len(models_to_process)} model(s) failed after {retry_round} rounds")
            print(f"{'=' * 60}\n")
        
        # Store all results
        results["downloads"] = all_results
        results["retry_rounds"] = retry_round
        
        print(f"\n{'=' * 60}")
        print("✅ FINAL BULK DOWNLOAD SUMMARY")
        print(f"{'=' * 60}")
        print(f"  Total Models: {results['total']}")
        print(f"  Successful: {results['successful']}")
        print(f"  Failed: {results['failed']}")
        print(f"  Retry Rounds: {retry_round}")
        print(f"{'=' * 60}\n")
        
        # Show failed models if any
        if results["failed"] > 0:
            print("❌ Failed Models:")
            for result in all_results:
                if result["status"] == "failed":
                    print(f"  - {result['model_name']} ({result['model_id']})")
                    print(f"    Error: {result['error']}")
            print()
        
        return results
    
    def download_all_report_definitions(
        self,
        workspace_ids: Optional[List[str]] = None,
        output_base_folder: str = "bulk_reports",
        use_report_id_as_folder: bool = True,
        organize_by_workspace: bool = True,
        parallel: bool = True,
        max_workers: int = 2,
        max_retries: int = 5,
        rate_limit_delay: float = 0.5,
        retry_failed_after: int = 300,
        max_retry_rounds: int = 2
    ) -> Dict[str, Any]:
        """
        Download all report definitions across workspaces with automatic retry rounds
        
        Args:
            workspace_ids: List of workspace IDs (if None, fetches from all workspaces)
            output_base_folder: Base folder for output (default: "bulk_reports")
            use_report_id_as_folder: Use report ID instead of name for folder (default: True)
            organize_by_workspace: Create subfolder for each workspace (default: True)
            parallel: Download in parallel (default: True)
            max_workers: Number of parallel workers (default: 2, reduced to avoid rate limits)
            max_retries: Maximum retry attempts on 429 errors per download (default: 5)
            rate_limit_delay: Delay between requests in seconds (default: 0.5)
            retry_failed_after: Seconds to wait before retrying failed downloads (default: 300 = 5 minutes)
            max_retry_rounds: Maximum number of retry rounds for failed downloads (default: 2)
            
        Returns:
            Dictionary with download statistics and results
        """
        # Get all reports
        reports = self.get_all_reports(workspace_ids, include_workspace_info=True)
        
        results = {
            "total": len(reports),
            "successful": 0,
            "failed": 0,
            "downloads": []
        }
        
        print(f"\n{'=' * 60}")
        print(f"Starting bulk download of {len(reports)} report(s)")
        print(f"{'=' * 60}\n")
        
        def download_single_report(report_info):
            """Download a single report definition with retry logic"""
            workspace_id = report_info.get("_workspace_id") or report_info.get("_workspace", {}).get("id")
            report_id = report_info["id"]
            report_name = report_info.get("displayName", report_id)
            
            # Add delay to avoid rate limiting
            time.sleep(rate_limit_delay)
            
            # Determine output folder
            if organize_by_workspace:
                workspace_name = report_info.get("_workspace", {}).get("displayName", workspace_id)
                import re
                workspace_folder = re.sub(r'[<>:"/\\|?*]', "_", workspace_name)
                output_folder = f"{output_base_folder}/{workspace_folder}"
            else:
                output_folder = output_base_folder
            
            try:
                # Download with retry logic for 429 errors
                result = self._download_with_retry(
                    self.report_client.get_report_definition,
                    max_retries=max_retries,
                    workspace_id=workspace_id,
                    report_id=report_id,
                    save_to_folder=True,
                    output_folder=output_folder,
                    use_report_id_as_folder=use_report_id_as_folder
                )
                
                print(f"  ✓ Downloaded: {report_name} ({len(result.get('saved_files', []))} files)")
                
                return {
                    "status": "success",
                    "report_id": report_id,
                    "report_name": report_name,
                    "workspace_id": workspace_id,
                    "output_folder": result.get("output_folder"),
                    "files_count": len(result.get("saved_files", []))
                }
            except Exception as e:
                print(f"  ✗ Failed: {report_name} - {str(e)}")
                return {
                    "status": "failed",
                    "report_id": report_id,
                    "report_name": report_name,
                    "workspace_id": workspace_id,
                    "error": str(e)
                }
        
        # Process downloads with retry rounds
        reports_to_process = reports.copy()
        retry_round = 0
        all_results = []
        
        while reports_to_process and retry_round < max_retry_rounds:
            retry_round += 1
            
            if retry_round > 1:
                print(f"\n{'=' * 60}")
                print(f"🔄 RETRY ROUND {retry_round}: Retrying {len(reports_to_process)} failed report(s)")
                print(f"⏰ Waiting {retry_failed_after} seconds before retry...")
                print(f"{'=' * 60}\n")
                time.sleep(retry_failed_after)
            
            round_results = []
            
            # Download reports (parallel or sequential)
            if parallel and len(reports_to_process) > 1:
                print(f"⚡ Downloading with {max_workers} parallel workers...\n")
                with ThreadPoolExecutor(max_workers=max_workers) as executor:
                    futures = {executor.submit(download_single_report, report): report for report in reports_to_process}
                    
                    for future in as_completed(futures):
                        download_result = future.result()
                        round_results.append(download_result)
                        
                        if download_result["status"] == "success":
                            results["successful"] += 1
                        else:
                            results["failed"] += 1
                        
                        # Progress update
                        completed = results["successful"] + results["failed"]
                        print(f"Progress: {completed}/{results['total']} ({results['successful']} ✓, {results['failed']} ✗)")
            else:
                print("📥 Downloading sequentially...\n")
                for idx, report in enumerate(reports_to_process, 1):
                    print(f"[{idx}/{len(reports_to_process)}] Downloading {report.get('displayName', report['id'])}...")
                    download_result = download_single_report(report)
                    round_results.append(download_result)
                    
                    if download_result["status"] == "success":
                        results["successful"] += 1
                    else:
                        results["failed"] += 1
            
            # Collect failed reports for next round
            failed_reports = []
            for result in round_results:
                all_results.append(result)
                
                if result["status"] == "failed":
                    # Find the report info to retry
                    report_id = result["report_id"]
                    for report in reports_to_process:
                        if report["id"] == report_id:
                            failed_reports.append(report)
                            break
            
            # Prepare for next round
            reports_to_process = failed_reports
            
            # Summary for this round
            round_success = sum(1 for r in round_results if r["status"] == "success")
            round_failed = sum(1 for r in round_results if r["status"] == "failed")
            
            print(f"\n{'=' * 60}")
            print(f"Round {retry_round} Summary:")
            print(f"  Processed: {len(round_results)}")
            print(f"  Successful: {round_success}")
            print(f"  Failed: {round_failed}")
            
            if reports_to_process and retry_round < max_retry_rounds:
                print(f"\n⚠️  {len(reports_to_process)} report(s) will be retried in next round")
            elif reports_to_process:
                print(f"\n⚠️  {len(reports_to_process)} report(s) failed after {retry_round} rounds")
            print(f"{'=' * 60}\n")
        
        # Store all results
        results["downloads"] = all_results
        results["retry_rounds"] = retry_round
        
        print(f"\n{'=' * 60}")
        print("✅ FINAL BULK DOWNLOAD SUMMARY")
        print(f"{'=' * 60}")
        print(f"  Total Reports: {results['total']}")
        print(f"  Successful: {results['successful']}")
        print(f"  Failed: {results['failed']}")
        print(f"  Retry Rounds: {retry_round}")
        print(f"{'=' * 60}\n")
        
        # Show failed reports if any
        if results["failed"] > 0:
            print("❌ Failed Reports:")
            for result in all_results:
                if result["status"] == "failed":
                    print(f"  - {result['report_name']} ({result['report_id']})")
                    print(f"    Error: {result['error']}")
            print()
        
        return results
    
    def download_all_definitions(
        self,
        workspace_ids: Optional[List[str]] = None,
        output_base_folder: str = "bulk_fabric_items",
        include_semantic_models: bool = True,
        include_reports: bool = True,
        organize_by_workspace: bool = True,
        parallel: bool = True
    ) -> Dict[str, Any]:
        """
        Download all semantic models and reports across workspaces
        
        Args:
            workspace_ids: List of workspace IDs (if None, fetches from all workspaces)
            output_base_folder: Base folder for output
            include_semantic_models: Include semantic models (default: True)
            include_reports: Include reports (default: True)
            organize_by_workspace: Create subfolder for each workspace (default: True)
            parallel: Download in parallel (default: True)
            
        Returns:
            Dictionary with combined download statistics
        """
        results = {
            "semantic_models": None,
            "reports": None
        }
        
        if include_semantic_models:
            sm_folder = f"{output_base_folder}/semantic_models" if not organize_by_workspace else output_base_folder
            results["semantic_models"] = self.download_all_semantic_model_definitions(
                workspace_ids=workspace_ids,
                output_base_folder=sm_folder,
                organize_by_workspace=organize_by_workspace,
                parallel=parallel
            )
        
        if include_reports:
            report_folder = f"{output_base_folder}/reports" if not organize_by_workspace else output_base_folder
            results["reports"] = self.download_all_report_definitions(
                workspace_ids=workspace_ids,
                output_base_folder=report_folder,
                organize_by_workspace=organize_by_workspace,
                parallel=parallel
            )
        
        return results


# Example usage
if __name__ == "__main__":
    print("BulkClient - Bulk operations for Microsoft Fabric")
    print("\nExample usage:")
    print("  from bulk_client import BulkClient")
    print("  client = BulkClient()")
    print("  ")
    print("  # Get all workspaces")
    print("  workspaces = client.get_all_workspaces()")
    print("  ")
    print("  # Get all semantic models")
    print("  models = client.get_all_semantic_models()")
    print("  ")
    print("  # Download all definitions")
    print("  results = client.download_all_definitions()")

