"""
Main FabricClient - Unified class with all functionality
"""

from typing import Optional
from .workspace import WorkspaceClient
from .semantic_model import SemanticModelClient
from .report import ReportClient
from .bulks import BulkClient


class FabricClient(WorkspaceClient, SemanticModelClient, ReportClient, BulkClient):
    """
    FabricClient handles authentication and API calls to the Microsoft Fabric REST API.
    
    This is the main client that combines all the specialized clients for different
    Fabric objects and operations using multiple inheritance.
    
    Attributes:
        access_token (str): Access token retrieved using client credentials.
        base_url (str): Base URL for the Fabric API.
        config (FabricConfig): Configuration object with API settings.
    
    Example:
        client = FabricClient()
        
        # Direct access to all methods
        workspaces = client.list_workspaces()
        models = client.list_semantic_models(workspace_id)
        reports = client.list_reports(workspace_id)
        client.download_all_definitions()
    """
    
    def __init__(
        self,
        access_token: Optional[str] = None,
        base_url: str = "https://api.fabric.microsoft.com/v1",
        env_file: str = ".env",
        interactive_login: bool = False,
        tenant_id: Optional[str] = None,
        client_id: Optional[str] = None,
        redirect_uri: str = "http://localhost"
    ):
        """
        Initialize the client and retrieve an access token.
        
        Args:
            access_token: Bearer token for authentication (optional, will get from env if not provided)
            base_url: Base URL for Fabric API
            env_file: Path to .env file for authentication
            interactive_login: Use interactive login flow if no access token provided
            tenant_id: Azure AD tenant ID for interactive login (optional)
            client_id: Azure AD app client ID for interactive login (optional)
            redirect_uri: Redirect URI for interactive login (default: http://localhost)
        """
        # Initialize all parent classes with the same credentials
        super().__init__(
            access_token=access_token,
            base_url=base_url,
            env_file=env_file,
            interactive_login=interactive_login,
            tenant_id=tenant_id,
            client_id=client_id,
            redirect_uri=redirect_uri
        )


# Example usage
if __name__ == "__main__":
    print("FabricClient - Main client for Microsoft Fabric")
    print("\nExample usage:")
    print("  from fabricpandas import FabricClient")
    print("  client = FabricClient()")
    print("  ")
    print("  # All methods are directly accessible")
    print("  workspaces = client.list_workspaces()")
    print("  models = client.list_semantic_models(workspace_id)")
    print("  reports = client.list_reports(workspace_id)")
    print("  client.download_all_definitions()")

