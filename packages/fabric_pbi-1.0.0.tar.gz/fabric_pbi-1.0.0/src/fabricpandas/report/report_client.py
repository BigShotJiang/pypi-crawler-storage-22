"""
Report Client for Microsoft Fabric
Provides operations for managing Reports in Fabric workspaces.
"""

import requests
import base64
import time
from pathlib import Path
from typing import Optional, Dict, Any, List
from ..auth import BaseClient


class ReportClient(BaseClient):
    """
    Client for interacting with Fabric Report APIs
    
    Reference: https://learn.microsoft.com/en-us/rest/api/fabric/report/items
    """
    
    def create_report(
        self,
        workspace_id: str,
        display_name: str,
        description: Optional[str] = None,
        definition: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Create a new Report
        
        Reference: https://learn.microsoft.com/en-us/rest/api/fabric/report/items/create-report
        
        Args:
            workspace_id: The workspace ID where the report will be created
            display_name: Display name for the report
            description: Optional description
            definition: Optional report definition
            
        Returns:
            Created report details
        """
        endpoint = f"workspaces/{workspace_id}/reports"
        
        payload = {
            "displayName": display_name
        }
        
        if description:
            payload["description"] = description
        
        if definition:
            payload["definition"] = definition
        
        response = self._make_request("POST", endpoint, data=payload)
        return response.json()
    
    def get_report(
        self,
        workspace_id: str,
        report_id: str
    ) -> Dict[str, Any]:
        """
        Get a Report by ID
        
        Reference: https://learn.microsoft.com/en-us/rest/api/fabric/report/items/get-report
        
        Args:
            workspace_id: The workspace ID
            report_id: The report ID
            
        Returns:
            Report details
        """
        endpoint = f"workspaces/{workspace_id}/reports/{report_id}"
        response = self._make_request("GET", endpoint)
        return response.json()
    
    def list_reports(
        self,
        workspace_id: str,
        continuation_token: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        List all Reports in a workspace
        
        Reference: https://learn.microsoft.com/en-us/rest/api/fabric/report/items/list-reports
        
        Args:
            workspace_id: The workspace ID
            continuation_token: Optional token for pagination
            
        Returns:
            List of reports
        """
        endpoint = f"workspaces/{workspace_id}/reports"
        params = {}
        
        if continuation_token:
            params["continuationToken"] = continuation_token
        
        response = self._make_request("GET", endpoint, params=params)
        return response.json()
    
    def get_report_definition(
        self,
        workspace_id: str,
        report_id: str,
        format: Optional[str] = None,
        save_to_folder: bool = False,
        output_folder: Optional[str] = None,
        use_report_id_as_folder: bool = False,
        wait_for_completion: bool = True,
        max_retries: int = 30,
        retry_delay: int = 5
    ) -> Dict[str, Any]:
        """
        Get a Report's definition with optional waiting and saving
        
        Reference: https://learn.microsoft.com/en-us/rest/api/fabric/report/items/get-report-definition
        
        Args:
            workspace_id: The workspace ID
            report_id: The report ID
            format: Optional format for the definition
            save_to_folder: If True, saves definition to folder structure (default: False)
            output_folder: Root folder to save files (optional, auto-generated if not provided)
            use_report_id_as_folder: If True, uses report ID as folder name (default: False)
            wait_for_completion: If True, waits for long-running operations (default: True)
            max_retries: Maximum number of polling attempts (default: 30)
            retry_delay: Seconds to wait between retries (default: 5)
            
        Returns:
            Dictionary containing definition and optional saved files info
        """
        endpoint = f"workspaces/{workspace_id}/reports/{report_id}/getDefinition"
        
        payload = {}
        if format:
            payload["format"] = format
        
        response = self._make_request("POST", endpoint, data=payload)
        
        # Handle long-running operation (202 Accepted)
        if response.status_code == 202:
            if not wait_for_completion:
                return {
                    "status": "Accepted",
                    "status_code": 202,
                    "x-ms-operation-id": response.headers.get("x-ms-operation-id"),
                    "retry_after": response.headers.get("Retry-After"),
                    "message": "Long-running operation started."
                }
            
            operation_id = response.headers.get("x-ms-operation-id")
            if operation_id:
                print(f"Long-running operation started (ID: {operation_id})")
                print(f"Waiting for operation to complete (checking every {retry_delay}s)...")
                
                status_url = f"https://api.fabric.microsoft.com/v1/operations/{operation_id}"
                
                for attempt in range(max_retries):
                    status_response = requests.get(
                        status_url,
                        headers={"Authorization": f"Bearer {self.config.access_token}"}
                    )
                    status_response.raise_for_status()
                    
                    operation_result = status_response.json()
                    status = operation_result.get("status", "").lower()
                    
                    if status == "succeeded":
                        # Fetch result
                        result_url = f"https://api.fabric.microsoft.com/v1/operations/{operation_id}/result"
                        result_response = requests.get(
                            result_url,
                            headers={"Authorization": f"Bearer {self.config.access_token}"}
                        )
                        
                        if result_response.status_code == 200:
                            result = result_response.json()
                            break
                        else:
                            result_response.raise_for_status()
                    elif status == "failed":
                        error_details = operation_result.get("error", operation_result)
                        raise Exception(f"Operation failed: {error_details}")
                    elif status in ["running", "notstarted", "inprogress"]:
                        if attempt < max_retries - 1:
                            print(f"Operation status: {status}. Waiting {retry_delay}s... (attempt {attempt + 1}/{max_retries})")
                            time.sleep(retry_delay)
                            continue
                    else:
                        print(f"Warning: Unknown operation status: {status}")
                        result = operation_result
                        break
                else:
                    raise Exception(f"Operation timed out after {max_retries} attempts")
            else:
                raise Exception("Operation accepted but no operation ID returned")
        else:
            # Immediate response
            if response.text:
                result = response.json()
            else:
                result = {
                    "status": "Success",
                    "status_code": response.status_code,
                    "message": "Request completed but no content returned"
                }
        
        # Extract definition from result
        if "definition" in result:
            definition = result["definition"]
        elif "format" in result and "parts" in result:
            definition = result
        else:
            return result
        
        response_data = {
            "definition": definition
        }
        
        # Save to folder if requested
        if save_to_folder:
            if output_folder is None:
                if use_report_id_as_folder:
                    output_folder = report_id
                    print(f"Using report ID as folder: '{output_folder}'\n")
                else:
                    print("Getting report information...")
                    report_info = self.get_report(workspace_id, report_id)
                    report_name = report_info.get("displayName", f"report_{report_id}")
                    
                    import re
                    output_folder = re.sub(r'[<>:"/\\|?*]', "_", report_name)
                    print(f"Using report name as folder: '{output_folder}'\n")
                    
                    response_data["report_info"] = report_info
            
            saved_files = self.save_definition_to_folder(definition, output_folder)
            response_data["saved_files"] = saved_files
            response_data["output_folder"] = output_folder
        
        return response_data
    
    def update_report(
        self,
        workspace_id: str,
        report_id: str,
        display_name: Optional[str] = None,
        description: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Update a Report's metadata
        
        Reference: https://learn.microsoft.com/en-us/rest/api/fabric/report/items/update-report
        
        Args:
            workspace_id: The workspace ID
            report_id: The report ID
            display_name: New display name
            description: New description
            
        Returns:
            Updated report details
        """
        endpoint = f"workspaces/{workspace_id}/reports/{report_id}"
        
        payload = {}
        if display_name:
            payload["displayName"] = display_name
        if description:
            payload["description"] = description
        
        response = self._make_request("PATCH", endpoint, data=payload)
        return response.json()
    
    def update_report_definition(
        self,
        workspace_id: str,
        report_id: str,
        definition: Optional[Dict[str, Any]] = None,
        definition_folder: Optional[str] = None,
        wait_for_completion: bool = True,
        max_retries: int = 30,
        retry_delay: int = 5
    ) -> Dict[str, Any]:
        """
        Update report definition from either a definition object or folder structure
        
        Reference: https://learn.microsoft.com/en-us/rest/api/fabric/report/items/update-report-definition
        
        Args:
            workspace_id: The workspace ID
            report_id: The report ID
            definition: Definition object with 'format' and 'parts' (optional if definition_folder provided)
            definition_folder: Path to folder containing report files (optional if definition provided)
            wait_for_completion: Wait for the operation to complete (default: True)
            max_retries: Maximum number of polling attempts (default: 30)
            retry_delay: Delay in seconds between polling attempts (default: 5)
            
        Returns:
            Dictionary with operation status
        """
        endpoint = f"workspaces/{workspace_id}/reports/{report_id}/updateDefinition"
        
        # Build definition from folder if provided
        if definition_folder and not definition:
            print(f"Building definition from folder: {definition_folder}")
            definition = self._build_definition_from_folder(definition_folder)
        
        if not definition:
            raise ValueError("Either 'definition' or 'definition_folder' must be provided")
        
        payload = {
            "definition": definition
        }
        
        print("Updating report definition...")
        print(f"Number of parts: {len(definition.get('parts', []))}\n")
        
        response = self._make_request("POST", endpoint, data=payload)
        
        # Handle long-running operation (202 Accepted)
        if response.status_code == 202:
            if not wait_for_completion:
                return {
                    "status": "Accepted",
                    "message": "Update initiated. Operation is running.",
                    "location": response.headers.get("Location"),
                    "retry_after": response.headers.get("Retry-After")
                }
            
            operation_id = response.headers.get("x-ms-operation-id")
            
            if not operation_id:
                raise ValueError("No operation ID found in response headers")
            
            print(f"Long-running operation initiated. Operation ID: {operation_id}")
            print("Polling for completion...\n")
            
            # Poll for completion
            status_url = f"https://api.fabric.microsoft.com/v1/operations/{operation_id}"
            
            for attempt in range(max_retries):
                status_response = requests.get(
                    status_url,
                    headers={"Authorization": f"Bearer {self.config.access_token}"}
                )
                status_response.raise_for_status()
                
                operation_status = status_response.json()
                status = operation_status.get("status", "").lower()
                
                if status == "succeeded":
                    print("✓ Operation completed successfully!")
                    return {
                        "status": "Completed",
                        "message": "Definition updated successfully",
                        "operation_details": operation_status
                    }
                elif status == "failed":
                    error_details = operation_status.get("error", operation_status)
                    raise Exception(f"Operation failed: {error_details}")
                elif status in ["running", "notstarted", "inprogress"]:
                    if attempt < max_retries - 1:
                        print(f"Operation status: {status}. Waiting {retry_delay}s... (attempt {attempt + 1}/{max_retries})")
                        time.sleep(retry_delay)
                        continue
                else:
                    print(f"Warning: Unknown operation status: {status}")
                    
            raise Exception(f"Operation timed out after {max_retries} attempts")
        
        elif response.status_code == 200:
            return {
                "status": "Completed",
                "message": "Definition updated successfully"
            }
        else:
            return {
                "status": "Unknown",
                "status_code": response.status_code,
                "response": response.text
            }
    
    def delete_report(
        self,
        workspace_id: str,
        report_id: str
    ) -> None:
        """
        Delete a Report
        
        Reference: https://learn.microsoft.com/en-us/rest/api/fabric/report/items/delete-report
        
        Args:
            workspace_id: The workspace ID
            report_id: The report ID to delete
            
        Returns:
            None (204 No Content on success)
        """
        endpoint = f"workspaces/{workspace_id}/reports/{report_id}"
        self._make_request("DELETE", endpoint)
    
    def _build_definition_from_folder(
        self,
        folder_path: str,
        format_type: str = "PBIR"
    ) -> Dict[str, Any]:
        """Build definition object from folder structure"""
        folder = Path(folder_path)
        if not folder.exists():
            raise FileNotFoundError(f"Folder not found: {folder_path}")
        
        parts = []
        
        for file_path in folder.rglob("*"):
            if file_path.is_file():
                relative_path = file_path.relative_to(folder)
                path_str = str(relative_path).replace("\\", "/")
                
                try:
                    with open(file_path, "r", encoding="utf-8") as f:
                        content = f.read()
                    
                    encoded_content = base64.b64encode(content.encode("utf-8")).decode("utf-8")
                    
                    parts.append({
                        "path": path_str,
                        "payload": encoded_content,
                        "payloadType": "InlineBase64"
                    })
                    
                    print(f"  ✓ Added: {path_str}")
                    
                except Exception as e:
                    print(f"  ✗ Failed to read {path_str}: {e}")
        
        print(f"\nTotal files processed: {len(parts)}\n")
        
        return {
            "format": format_type,
            "parts": parts
        }
    
    def save_definition_to_folder(
        self,
        definition_data: Dict[str, Any],
        output_folder: str = "report_definition"
    ) -> List[str]:
        """Save report definition parts to folder structure"""
        format_type = definition_data.get("format", "PBIR")
        parts = definition_data.get("parts", [])
        
        print(f"Format: {format_type}")
        print(f"Number of parts: {len(parts)}\n")
        
        output_path = Path(output_folder)
        output_path.mkdir(parents=True, exist_ok=True)
        
        saved_files = []
        
        for part in parts:
            file_path = part.get("path", "")
            payload = part.get("payload", "")
            payload_type = part.get("payloadType", "")
            
            if not file_path or not payload:
                print("⚠ Skipping part with missing path or payload")
                continue
            
            if payload_type == "InlineBase64":
                try:
                    decoded_content = base64.b64decode(payload).decode("utf-8")
                except Exception as e:
                    print(f"✗ Failed to decode {file_path}: {e}")
                    continue
            else:
                decoded_content = payload
            
            full_path = output_path / file_path
            full_path.parent.mkdir(parents=True, exist_ok=True)
            
            try:
                with open(full_path, "w", encoding="utf-8") as f:
                    f.write(decoded_content)
                
                print(f"✓ Saved: {file_path}")
                saved_files.append(str(full_path))
            except Exception as e:
                print(f"✗ Failed to save {file_path}: {e}")
        
        print(f"\n{'=' * 60}")
        print(f"Summary: Saved {len(saved_files)} files to '{output_folder}'")
        print(f"{'=' * 60}")
        
        return saved_files


# Example usage
if __name__ == "__main__":
    print("ReportClient - Client for Fabric Reports")
    print("\nExample usage:")
    print("  from report_client import ReportClient")
    print("  client = ReportClient()")
    print("  client.list_reports(workspace_id)")

