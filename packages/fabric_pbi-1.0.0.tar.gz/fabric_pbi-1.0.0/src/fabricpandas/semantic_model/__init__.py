"""
Semantic Model module for FabricPandas
"""

from .semantic_model_client import SemanticModelClient

__all__ = ["SemanticModelClient"]

