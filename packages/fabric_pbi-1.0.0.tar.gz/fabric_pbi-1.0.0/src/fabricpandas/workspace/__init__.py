"""
Workspace module for FabricPandas
"""

from .workspace_client import WorkspaceClient

__all__ = ["WorkspaceClient"]

