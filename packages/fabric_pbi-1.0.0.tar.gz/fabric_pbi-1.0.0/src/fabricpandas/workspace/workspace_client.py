"""
Workspace Client for Microsoft Fabric
Provides operations for managing Workspaces.
"""

from typing import Optional, Dict, Any, List
from ..auth import BaseClient


class WorkspaceClient(BaseClient):
    """
    Client for interacting with Fabric Workspace APIs
    
    Reference: https://learn.microsoft.com/en-us/rest/api/fabric/core/workspaces
    """
    
    def list_workspaces(
        self,
        continuation_token: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        List all workspaces
        
        Reference: https://learn.microsoft.com/en-us/rest/api/fabric/core/workspaces/list-workspaces
        
        Args:
            continuation_token: Optional token for pagination
            
        Returns:
            Dictionary with workspace list
        """
        endpoint = "workspaces"
        params = {}
        
        if continuation_token:
            params["continuationToken"] = continuation_token
        
        response = self._make_request("GET", endpoint, params=params)
        return response.json()
    
    def get_workspace(
        self,
        workspace_id: str
    ) -> Dict[str, Any]:
        """
        Get a workspace by ID
        
        Reference: https://learn.microsoft.com/en-us/rest/api/fabric/core/workspaces/get-workspace
        
        Args:
            workspace_id: The workspace ID
            
        Returns:
            Workspace details
        """
        endpoint = f"workspaces/{workspace_id}"
        response = self._make_request("GET", endpoint)
        return response.json()
    
    def create_workspace(
        self,
        display_name: str,
        description: Optional[str] = None,
        capacity_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Create a new workspace
        
        Reference: https://learn.microsoft.com/en-us/rest/api/fabric/core/workspaces/create-workspace
        
        Args:
            display_name: Display name for the workspace
            description: Optional description
            capacity_id: Optional capacity ID
            
        Returns:
            Created workspace details
        """
        endpoint = "workspaces"
        
        payload = {
            "displayName": display_name
        }
        
        if description:
            payload["description"] = description
        if capacity_id:
            payload["capacityId"] = capacity_id
        
        response = self._make_request("POST", endpoint, data=payload)
        return response.json()
    
    def update_workspace(
        self,
        workspace_id: str,
        display_name: Optional[str] = None,
        description: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Update a workspace
        
        Reference: https://learn.microsoft.com/en-us/rest/api/fabric/core/workspaces/update-workspace
        
        Args:
            workspace_id: The workspace ID
            display_name: New display name
            description: New description
            
        Returns:
            Updated workspace details
        """
        endpoint = f"workspaces/{workspace_id}"
        
        payload = {}
        if display_name:
            payload["displayName"] = display_name
        if description:
            payload["description"] = description
        
        response = self._make_request("PATCH", endpoint, data=payload)
        return response.json()
    
    def delete_workspace(
        self,
        workspace_id: str
    ) -> None:
        """
        Delete a workspace
        
        Reference: https://learn.microsoft.com/en-us/rest/api/fabric/core/workspaces/delete-workspace
        
        Args:
            workspace_id: The workspace ID to delete
            
        Returns:
            None (204 No Content on success)
        """
        endpoint = f"workspaces/{workspace_id}"
        self._make_request("DELETE", endpoint)
    
    def get_all_workspaces(self) -> List[Dict[str, Any]]:
        """
        Get all workspaces with automatic pagination
        
        Returns:
            List of all workspaces
        """
        all_workspaces = []
        continuation_token = None
        
        print("Fetching all workspaces...")
        
        while True:
            result = self.list_workspaces(continuation_token=continuation_token)
            workspaces = result.get("value", [])
            all_workspaces.extend(workspaces)
            
            print(f"  Retrieved {len(workspaces)} workspaces (Total: {len(all_workspaces)})")
            
            # Check if there are more pages
            continuation_token = result.get("continuationToken")
            if not continuation_token:
                break
        
        print(f"✓ Total workspaces found: {len(all_workspaces)}\n")
        return all_workspaces

