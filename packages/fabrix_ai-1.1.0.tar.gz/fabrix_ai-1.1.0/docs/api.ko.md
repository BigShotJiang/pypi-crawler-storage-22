# Fabrix API 사용 가이드

Language: [English](api.md) | 한국어  
Home: [README](../README.md) | [README.ko.md](../README.ko.md)

## 목적 및 범위

이 문서는 Fabrix의 public 사용 표면을 설명합니다.
에이전트 생성, `run_stream`, 메시지 모델, 이벤트 스트림 처리를 다룹니다.

## 요구 사항

- Python `>=3.12`
- 패키지 설치: `pip install fabrix-ai`
- `oauth-codex` 인증 설정
- Async 런타임 (`asyncio`)

## 공개 Import

```python
from fabrix import Agent
from fabrix.events import (
    AgentEvent,
    ReasoningEvent,
    ResponseEvent,
    TaskFailedEvent,
    TaskFinishedEvent,
    ToolEvent,
)
from fabrix.messages import ImageMessage, TextMessage
```

## Agent 생성

```python
Agent(
    *,
    instructions: str,
    model: str = "gpt-5.3-codex",
    tools: list[Callable[..., Any]] | None = None,
)
```

참고:

- 내부 실행 기본값: `max_steps=128`
- public 생성자에 per-tool timeout 없음
- 호환되지 않는 tool schema는 생성 시 즉시 실패

## 메시지 모델

Fabrix 런타임 입력은 메시지 모델 객체 리스트입니다.

```python
class TextMessage(BaseModel):
    role: str = "user"
    text: str

class ImageMessage(BaseModel):
    role: str = "user"
    image: str | Path | bytes
    text: str | None = None
```

규칙:

- `run_stream`은 `TextMessage` / `ImageMessage` 인스턴스만 허용
- 생성 시 정의되지 않은 필드는 거부됩니다.
- `ImageMessage.image`는 URL/path/bytes 지원
- `bytes`와 로컬 path는 모델 호출 전에 data URL로 변환

## 스트림 실행

```python
run_stream(
    *,
    messages: list[TextMessage | ImageMessage],
) -> AsyncIterator[AgentEvent]
```

검증:

- 빈 리스트 -> `ValueError`
- 메시지 모델 외 객체 포함 -> `TypeError`

텍스트 예시:

```python
messages = [TextMessage(text="Use add_numbers to compute 3 + 9")]
async for event in agent.run_stream(messages=messages):
    ...
```

멀티모달 예시:

```python
messages = [
    TextMessage(text="이 이미지를 설명해줘"),
    ImageMessage(image="https://example.com/cat.png"),
    TextMessage(text="경고 문구를 중심으로 요약해줘"),
]
async for event in agent.run_stream(messages=messages):
    ...
```

## Tool 정의 규칙

허용되는 tool 형태:

```python
def tool(payload: BaseModel) -> Any: ...
```

런타임 규칙:

- 파라미터는 정확히 1개
- 파라미터 타입은 Pydantic `BaseModel`
- 인자는 payload 필드와 일치하는 JSON object
- 추가 키는 거부

## 이벤트 레퍼런스

공통 필드:

- `event_type: str`
- `step: int`
- `timestamp: datetime` (UTC)

이벤트별 핵심 필드:

| event_type | Model | Key fields |
| --- | --- | --- |
| `reasoning` | `ReasoningEvent` | `reasoning`, `focus`, `next_state` |
| `tool` | `ToolEvent` | `phase`, `tool_name`, `call_id`, `arguments`, `result` |
| `response` | `ResponseEvent` | `response` |
| `task_finished` | `TaskFinishedEvent` | `final_output`, `completion_reason` |
| `task_failed` | `TaskFailedEvent` | `error_code`, `message` |

## 실패 처리

종료 실패는 `TaskFailedEvent`로 전달됩니다.
현재 error code 예시:

- `llm_error`
- `invalid_state_type`
- `invalid_transition`
- `max_steps_reached`

tool 실패는 non-terminal이며 `ToolEvent(phase="finish")`의 `result.ok == False`로 전달됩니다.

## 마이그레이션 (브레이킹)

제거된 API:

- `run_task_stream(task, images, context)`

신규 API:

- `run_stream(messages=[...])`

입력 매핑:

- `task` -> `TextMessage(text="...")`
- `images` -> `ImageMessage(image="..." | Path(...) | b"...")`
- `context` -> 직렬화해서 `TextMessage.text`에 포함

## 트러블슈팅

- `ValueError: messages must be a non-empty list of TextMessage/ImageMessage objects`:
  메시지 모델 객체를 최소 1개 이상 전달하세요.
- `TypeError: messages must be a list of TextMessage/ImageMessage objects`:
  dict 대신 메시지 모델 인스턴스를 전달하세요.
- `task_failed` + `invalid_transition`:
  instructions를 보강해 허용 전이를 따르도록 유도하세요.
- `task_failed` + `llm_error`:
  인증/모델 설정과 tool schema 호환성을 확인하세요.
