"""Face Cluster CLI — cluster images by face similarity."""

__version__ = "0.1.0"
