"""Typer CLI entry point for Face Cluster CLI."""

from __future__ import annotations

from pathlib import Path

import typer
from rich.panel import Panel
from rich.table import Table

from face_cluster_cli.config import FaceClusterSettings
from face_cluster_cli.exceptions import (
    FaceClusterError,
    InputDirectoryError,
)
from face_cluster_cli.logging_setup import console, setup_logging
from face_cluster_cli.pipeline import run_pipeline

app = typer.Typer(
    name="face-cluster",
    help="Cluster images by face similarity using InsightFace and Agglomerative Clustering.",
    rich_markup_mode="rich",
    no_args_is_help=True,
)

# Exit codes
_EXIT_OK = 0
_EXIT_USER_ERROR = 1
_EXIT_SYSTEM_ERROR = 2


def _render_summary(
    *,
    total_images: int,
    images_with_faces: int,
    total_faces: int,
    n_clusters: int,
    largest_cluster_size: int,
    n_outliers: int,
) -> Panel:
    """Build a Rich panel summarising the pipeline run.

    Returns:
        A ``rich.panel.Panel`` ready to print.
    """
    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("Metric", style="bold cyan")
    table.add_column("Value", style="bold white", justify="right")

    table.add_row("Total images", str(total_images))
    table.add_row("Images with faces", str(images_with_faces))
    table.add_row("Total faces detected", str(total_faces))
    table.add_row("Clusters", str(n_clusters))
    table.add_row("Largest cluster", str(largest_cluster_size))
    table.add_row("Outliers", str(n_outliers))

    return Panel(table, title="[bold green]Pipeline Summary", expand=False)


@app.command()
def cluster(
    input_dir: Path = typer.Argument(
        ...,
        help="Directory containing images to cluster.",
        exists=True,
        file_okay=False,
        dir_okay=True,
        readable=True,
        resolve_path=True,
    ),
    output_dir: Path = typer.Option(
        Path("./face_clusters"),
        "--output",
        "-o",
        help="Directory for exported cluster folders.",
        resolve_path=True,
    ),
    distance_threshold: float = typer.Option(
        0.8,
        "--distance-threshold",
        help="Cosine distance threshold above which clusters are not merged (> 0).",
        min=0.001,
    ),
    linkage: str = typer.Option(
        "complete",
        "--linkage",
        help="Linkage criterion: 'average', 'complete', or 'single'.",
    ),
    min_cluster_size: int = typer.Option(
        2,
        "--min-cluster-size",
        help="Clusters smaller than this are reclassified as outliers (>= 2).",
        min=2,
    ),
    batch_size: int = typer.Option(
        32,
        "--batch-size",
        help="Number of images per progress-bar tick.",
        min=1,
    ),
    force: bool = typer.Option(
        False,
        "--force",
        "-f",
        help="Overwrite output directory without confirmation.",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="Enable debug-level logging.",
    ),
) -> None:
    """Detect faces, cluster them by similarity, and export results."""
    setup_logging(verbose=verbose)

    settings = FaceClusterSettings(
        output_dir=output_dir,
        distance_threshold=distance_threshold,
        linkage=linkage,
        min_cluster_size=min_cluster_size,
        batch_size=batch_size,
        force=force,
        verbose=verbose,
    )

    try:
        summary = run_pipeline(input_dir, settings)
    except InputDirectoryError as exc:
        console.print(f"[bold red]Error:[/bold red] {exc}")
        raise SystemExit(_EXIT_USER_ERROR) from exc
    except typer.Abort:
        console.print("[yellow]Aborted by user.[/yellow]")
        raise SystemExit(_EXIT_USER_ERROR)
    except FaceClusterError as exc:
        console.print(f"[bold red]Error:[/bold red] {exc}")
        raise SystemExit(_EXIT_SYSTEM_ERROR) from exc

    panel = _render_summary(
        total_images=summary.total_images,
        images_with_faces=summary.images_with_faces,
        total_faces=summary.total_faces,
        n_clusters=summary.n_clusters,
        largest_cluster_size=summary.largest_cluster_size,
        n_outliers=summary.n_outliers,
    )
    console.print()
    console.print(panel)
    raise SystemExit(_EXIT_OK)


def main() -> None:
    """Package entry point (called by ``face-cluster`` script)."""
    app()
