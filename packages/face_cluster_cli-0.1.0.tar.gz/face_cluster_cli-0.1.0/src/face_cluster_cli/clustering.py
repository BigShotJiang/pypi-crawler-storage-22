"""Agglomerative hierarchical face clustering on L2-normalised embeddings."""

from __future__ import annotations

import logging
from collections import Counter
from typing import Any

import numpy as np
from sklearn.cluster import AgglomerativeClustering

from face_cluster_cli.config import FaceClusterSettings
from face_cluster_cli.exceptions import ClusteringError
from face_cluster_cli.models import ClusterResult, EmbeddingRecord

logger = logging.getLogger(__name__)


def normalize_embeddings(
    records: list[EmbeddingRecord],
) -> np.ndarray[Any, Any]:
    """Stack and L2-normalise embedding vectors.

    Args:
        records: Non-empty list of embedding records.

    Returns:
        A ``(N, 512)`` float32 array where each row has unit L2 norm.

    Raises:
        ClusteringError: If the records list is empty.
    """
    if not records:
        msg = "Cannot normalise embeddings: no records provided."
        raise ClusteringError(msg)

    matrix = np.stack([r.embedding for r in records])
    norms: np.ndarray[Any, Any] = np.linalg.norm(matrix, axis=1, keepdims=True)
    norms = np.where(norms == 0, 1.0, norms)
    normalised: np.ndarray[Any, Any] = matrix / norms
    return normalised.astype(np.float32)


def cluster_faces(
    records: list[EmbeddingRecord],
    settings: FaceClusterSettings,
) -> ClusterResult:
    """Cluster face embeddings using agglomerative clustering with cosine distance.

    Clusters smaller than ``settings.min_cluster_size`` are reclassified as
    outliers (label ``-1``).

    Args:
        records: Non-empty list of embedding records.
        settings: Application settings (clustering hyper-parameters).

    Returns:
        A ``ClusterResult`` with labels, counts and statistics.

    Raises:
        ClusteringError: If clustering fails or no records are provided.
    """
    logger.debug(
        "Clustering %d faces (distance_threshold=%.3f, linkage=%s)",
        len(records),
        settings.distance_threshold,
        settings.linkage,
    )
    normalised = normalize_embeddings(records)

    # AgglomerativeClustering requires at least 2 samples
    if len(records) < 2:
        logger.warning("Only %d face(s) found — too few to cluster.", len(records))
        return ClusterResult(
            labels=[-1] * len(records),
            n_clusters=0,
            n_outliers=len(records),
            cluster_sizes={},
        )

    try:
        clusterer = AgglomerativeClustering(  # type: ignore[no-untyped-call]
            n_clusters=None,
            metric="cosine",
            linkage=settings.linkage,
            distance_threshold=settings.distance_threshold,
        )
        labels_array: np.ndarray[Any, Any] = clusterer.fit_predict(normalised)  # type: ignore[no-untyped-call]
    except Exception as exc:
        msg = f"Agglomerative clustering failed: {exc}"
        raise ClusteringError(msg) from exc

    labels = [int(lbl) for lbl in labels_array]

    # Reclassify clusters smaller than min_cluster_size as outliers (-1).
    counts = Counter(labels)
    small_clusters = {
        lbl for lbl, size in counts.items() if size < settings.min_cluster_size
    }
    if small_clusters:
        labels = [-1 if lbl in small_clusters else lbl for lbl in labels]

    counts = Counter(labels)
    n_outliers = counts.pop(-1, 0)
    cluster_sizes = dict(counts)
    n_clusters = len(cluster_sizes)

    logger.debug(
        "Found %d clusters and %d outliers",
        n_clusters,
        n_outliers,
    )

    return ClusterResult(
        labels=labels,
        n_clusters=n_clusters,
        n_outliers=n_outliers,
        cluster_sizes=cluster_sizes,
    )
