"""Centralized configuration via Pydantic BaseSettings.

All settings can be overridden with environment variables prefixed by
``FACE_CLUSTER_`` (e.g. ``FACE_CLUSTER_DISTANCE_THRESHOLD=0.5``).
"""

from __future__ import annotations

from pathlib import Path
from typing import Tuple

from pydantic import Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

_VALID_LINKAGES: frozenset[str] = frozenset({"average", "complete", "single"})


class FaceClusterSettings(BaseSettings):
    """Application-wide settings for Face Cluster CLI.

    Attributes:
        model_name: InsightFace model pack name.
        det_size: Detection input size (width, height).
        batch_size: Number of images to process per progress-bar tick.
        distance_threshold: Cosine distance threshold for cluster merging.
        linkage: Linkage criterion (``average``, ``complete``, or ``single``).
        min_cluster_size: Clusters smaller than this are reclassified as outliers.
        output_dir: Directory where cluster folders are written.
        force: Skip interactive confirmation before overwriting output_dir.
        verbose: Enable verbose (DEBUG-level) logging.
    """

    model_config = SettingsConfigDict(
        env_prefix="FACE_CLUSTER_",
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # InsightFace model
    model_name: str = Field(
        default="antelopev2",
        description="InsightFace model pack name.",
    )
    det_size: Tuple[int, int] = Field(
        default=(640, 640),
        description="Detection input size (width, height).",
    )
    batch_size: int = Field(
        default=32,
        ge=1,
        description="Number of images per progress-bar tick.",
    )

    # Agglomerative clustering
    distance_threshold: float = Field(
        default=0.8,
        gt=0.0,
        description="Cosine distance threshold above which clusters are not merged.",
    )
    linkage: str = Field(
        default="complete",
        description="Linkage criterion: 'average', 'complete', or 'single'.",
    )
    min_cluster_size: int = Field(
        default=2,
        ge=2,
        description="Clusters smaller than this are reclassified as outliers.",
    )

    # Paths
    output_dir: Path = Field(
        default=Path("./face_clusters"),
        description="Directory where cluster folders are written.",
    )

    # Runtime flags
    force: bool = Field(
        default=False,
        description="Skip interactive confirmation before overwriting output_dir.",
    )
    verbose: bool = Field(
        default=False,
        description="Enable verbose (DEBUG-level) logging.",
    )

    @model_validator(mode="after")
    def _validate_cross_fields(self) -> "FaceClusterSettings":
        """Ensure linkage is one of the supported methods."""
        if self.linkage not in _VALID_LINKAGES:
            msg = (
                f"linkage must be one of {sorted(_VALID_LINKAGES)}, "
                f"got '{self.linkage}'"
            )
            raise ValueError(msg)
        return self
