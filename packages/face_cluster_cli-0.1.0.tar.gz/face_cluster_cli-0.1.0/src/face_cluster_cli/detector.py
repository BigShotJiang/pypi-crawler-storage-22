"""InsightFace face detection and embedding extraction.

Uses a lazy-loaded singleton ``FaceAnalysis`` instance with the
*antelopev2* model pack.  The model is downloaded automatically on
first use if it is not already cached.
"""

from __future__ import annotations

import logging
import shutil
from pathlib import Path
from typing import Any

import cv2
import numpy as np
from insightface.app import FaceAnalysis
from rich.progress import (
    BarColumn,
    MofNCompleteColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeElapsedColumn,
    TimeRemainingColumn,
)

from face_cluster_cli.config import FaceClusterSettings
from face_cluster_cli.exceptions import ImageProcessingError, ModelLoadError
from face_cluster_cli.logging_setup import console
from face_cluster_cli.models import EmbeddingRecord

logger = logging.getLogger(__name__)

_model: FaceAnalysis | None = None

_INSIGHTFACE_ROOT = Path("~/.insightface").expanduser()


def _repair_nested_model_dir(model_name: str, root: Path) -> None:
    """Flatten a double-nested model directory created by zip extraction.

    Some versions of ``antelopev2.zip`` extract into
    ``models/antelopev2/antelopev2/*.onnx`` instead of the expected
    ``models/antelopev2/*.onnx``.  InsightFace discovers ONNX files
    with a non-recursive glob, so the nested layout silently breaks
    model loading.

    This function detects the pattern and moves the files up one level.

    Args:
        model_name: InsightFace model pack name (e.g. ``"antelopev2"``).
        root: InsightFace root directory (default ``~/.insightface``).
    """
    model_dir = root / "models" / model_name

    if not model_dir.is_dir():
        return

    if list(model_dir.glob("*.onnx")):
        return

    nested_dir = model_dir / model_name
    if not nested_dir.is_dir():
        return

    nested_onnx = list(nested_dir.glob("*.onnx"))
    if not nested_onnx:
        return

    for src in nested_dir.iterdir():
        dest = model_dir / src.name
        shutil.move(str(src), str(dest))
    nested_dir.rmdir()

    logger.info(
        "Repaired nested model directory for '%s': moved %d file(s) from %s to %s",
        model_name,
        len(nested_onnx),
        nested_dir,
        model_dir,
    )


def get_model(settings: FaceClusterSettings) -> FaceAnalysis:
    """Return the lazily-loaded InsightFace model singleton.

    Args:
        settings: Application settings (model name, detection size).

    Returns:
        A prepared ``FaceAnalysis`` instance.

    Raises:
        ModelLoadError: If the model cannot be loaded or downloaded.
    """
    global _model  # noqa: PLW0603
    if _model is not None:
        return _model
    _repair_nested_model_dir(settings.model_name, _INSIGHTFACE_ROOT)
    try:
        logger.debug("Loading InsightFace model '%s'…", settings.model_name)
        app = FaceAnalysis(
            name=settings.model_name,
            providers=["CUDAExecutionProvider", "CPUExecutionProvider"],
        )
        app.prepare(ctx_id=0, det_size=settings.det_size)
        _model = app
    except Exception as exc:
        msg = f"Failed to load InsightFace model '{settings.model_name}': {exc}"
        raise ModelLoadError(msg) from exc
    return _model


def detect_faces(
    image_path: Path,
    settings: FaceClusterSettings,
) -> list[EmbeddingRecord]:
    """Detect faces in a single image and return their embeddings.

    Args:
        image_path: Path to the image file.
        settings: Application settings.

    Returns:
        A list of ``EmbeddingRecord`` objects, one per detected face.
        Returns an empty list if the image is unreadable or no faces
        are found.
    """
    model = get_model(settings)
    try:
        img: np.ndarray[Any, Any] | None = cv2.imread(str(image_path))
        if img is None:
            raise ImageProcessingError(  # noqa: TRY301
                f"cv2.imread returned None for '{image_path}'"
            )
        faces: list[Any] = model.get(img)
    except ImageProcessingError:
        logger.warning("Skipping unreadable image: %s", image_path)
        return []
    except Exception as exc:
        logger.warning(
            "Skipping image '%s' due to error: %s",
            image_path,
            exc,
        )
        return []

    records: list[EmbeddingRecord] = []
    for idx, face in enumerate(faces):
        embedding: np.ndarray[Any, Any] = face.embedding
        records.append(
            EmbeddingRecord(
                image_path=image_path.resolve(),
                face_index=idx,
                embedding=np.array(embedding, dtype=np.float32),
            )
        )
    return records


def process_directory(
    image_paths: list[Path],
    settings: FaceClusterSettings,
) -> list[EmbeddingRecord]:
    """Detect faces across all images with a Rich progress bar.

    Args:
        image_paths: Ordered list of image file paths to process.
        settings: Application settings.

    Returns:
        Aggregated list of ``EmbeddingRecord`` from all images.
    """
    all_records: list[EmbeddingRecord] = []
    with Progress(
        SpinnerColumn(),
        TextColumn("[bold blue]Detecting faces"),
        BarColumn(),
        MofNCompleteColumn(),
        TimeElapsedColumn(),
        TimeRemainingColumn(),
        console=console,
    ) as progress:
        task = progress.add_task("Detecting", total=len(image_paths))
        for path in image_paths:
            records = detect_faces(path, settings)
            all_records.extend(records)
            progress.advance(task)
    return all_records
