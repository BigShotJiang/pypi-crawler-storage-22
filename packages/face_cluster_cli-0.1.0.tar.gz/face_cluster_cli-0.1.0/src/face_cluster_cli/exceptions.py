"""Custom exception hierarchy for Face Cluster CLI."""


class FaceClusterError(Exception):
    """Base exception for all Face Cluster CLI errors."""


class InputDirectoryError(FaceClusterError):
    """Raised when the input directory is invalid, unreadable, or contains no images.

    Exit code: 1 (user error).
    """


class ImageProcessingError(FaceClusterError):
    """Raised when an individual image cannot be read or processed.

    This error is non-fatal: the pipeline logs a warning and skips the image.
    """


class ModelLoadError(FaceClusterError):
    """Raised when the InsightFace model fails to load or download.

    Exit code: 2 (system error).
    """


class ClusteringError(FaceClusterError):
    """Raised when clustering fails.

    Exit code: 2 (system error).
    """


class ExportError(FaceClusterError):
    """Raised when cluster export to disk fails.

    Exit code: 2 (system error).
    """
