"""Export clustered images into per-cluster subdirectories."""

from __future__ import annotations

import logging
import shutil
from pathlib import Path

import typer
from rich.progress import (
    BarColumn,
    MofNCompleteColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeElapsedColumn,
)

from face_cluster_cli.exceptions import ExportError
from face_cluster_cli.logging_setup import console
from face_cluster_cli.models import ClusterResult, EmbeddingRecord

logger = logging.getLogger(__name__)


def _confirm_overwrite(output_dir: Path) -> None:
    """Prompt the user before cleaning a non-empty output directory.

    Args:
        output_dir: The directory that would be overwritten.

    Raises:
        typer.Abort: If the user declines.
    """
    console.print(
        f"[yellow]Output directory '{output_dir}' already exists and is not empty.[/yellow]"
    )
    if not typer.confirm("Do you want to overwrite it?"):
        raise typer.Abort()


def export_clusters(
    records: list[EmbeddingRecord],
    cluster_result: ClusterResult,
    output_dir: Path,
    *,
    force: bool = False,
) -> None:
    """Copy source images into per-cluster subdirectories.

    Directory layout::

        output_dir/
            cluster_000/
            cluster_001/
            …
            outliers/

    If an image contains faces in multiple clusters, it is copied into
    each relevant cluster directory.

    Args:
        records: The embedding records (one per face).
        cluster_result: The clustering result with labels.
        output_dir: Root directory for the exported clusters.
        force: Skip interactive confirmation when overwriting.

    Raises:
        ExportError: If any I/O operation fails.
    """
    try:
        if output_dir.exists() and any(output_dir.iterdir()):
            if not force:
                _confirm_overwrite(output_dir)
            logger.debug("Cleaning output directory: %s", output_dir)
            shutil.rmtree(output_dir)

        output_dir.mkdir(parents=True, exist_ok=True)

        # Build mapping: cluster_label → set of image paths
        cluster_images: dict[int, set[Path]] = {}
        for record, label in zip(records, cluster_result.labels):
            cluster_images.setdefault(label, set()).add(record.image_path)

        total_copies = sum(len(paths) for paths in cluster_images.values())

        with Progress(
            SpinnerColumn(),
            TextColumn("[bold green]Exporting clusters"),
            BarColumn(),
            MofNCompleteColumn(),
            TimeElapsedColumn(),
            console=console,
        ) as progress:
            task = progress.add_task("Exporting", total=total_copies)

            for label in sorted(cluster_images.keys()):
                if label == -1:
                    subdir = output_dir / "outliers"
                else:
                    subdir = output_dir / f"cluster_{label:03d}"
                subdir.mkdir(parents=True, exist_ok=True)

                for src in sorted(cluster_images[label]):
                    dst = subdir / src.name
                    # Handle filename collisions
                    if dst.exists():
                        stem = src.stem
                        suffix = src.suffix
                        counter = 1
                        while dst.exists():
                            dst = subdir / f"{stem}_{counter}{suffix}"
                            counter += 1
                    shutil.copy2(src, dst)
                    progress.advance(task)

    except typer.Abort:
        raise
    except Exception as exc:
        if isinstance(exc, ExportError):
            raise
        msg = f"Failed to export clusters to '{output_dir}': {exc}"
        raise ExportError(msg) from exc
