"""Rich-based logging configuration for Face Cluster CLI."""

from __future__ import annotations

import logging

from rich.console import Console
from rich.logging import RichHandler

#: Shared console instance used by both logging and CLI output.
console = Console()


def setup_logging(*, verbose: bool = False) -> None:
    """Configure the root logger with a Rich handler.

    Args:
        verbose: When ``True``, set the log level to ``DEBUG``;
            otherwise use ``WARNING``.
    """
    level = logging.DEBUG if verbose else logging.WARNING
    handler = RichHandler(
        console=console,
        show_time=True,
        show_path=False,
        markup=True,
    )
    logging.basicConfig(
        level=level,
        format="%(message)s",
        datefmt="[%X]",
        handlers=[handler],
        force=True,
    )
