"""Pydantic data models for the face clustering pipeline."""

from __future__ import annotations

from pathlib import Path

import numpy as np
from pydantic import BaseModel, ConfigDict, field_validator


class EmbeddingRecord(BaseModel):
    """A single detected face with its validated embedding vector.

    Attributes:
        image_path: Absolute path to the source image.
        face_index: Zero-based index of this face within the source image.
        embedding: 512-dimensional float32 embedding vector.
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    image_path: Path
    face_index: int
    embedding: np.ndarray  # type: ignore[type-arg]

    @field_validator("embedding")
    @classmethod
    def _validate_embedding(cls, value: np.ndarray) -> np.ndarray:  # type: ignore[type-arg]
        """Ensure the embedding has the expected shape and dtype."""
        if not isinstance(value, np.ndarray):
            msg = f"Expected numpy.ndarray, got {type(value).__name__}"
            raise TypeError(msg)
        if value.shape != (512,):
            msg = f"Expected embedding shape (512,), got {value.shape}"
            raise ValueError(msg)
        if value.dtype != np.float32:
            value = value.astype(np.float32)
        return value


class ClusterResult(BaseModel):
    """Result of the agglomerative clustering step.

    Attributes:
        labels: Cluster label for each face (-1 = outlier).
        n_clusters: Number of clusters found (excluding outliers).
        n_outliers: Number of faces classified as outliers.
        cluster_sizes: Mapping from cluster label to number of faces.
    """

    labels: list[int]
    n_clusters: int
    n_outliers: int
    cluster_sizes: dict[int, int]


class PipelineSummary(BaseModel):
    """Summary statistics displayed at the end of a pipeline run.

    Attributes:
        total_images: Number of image files discovered.
        images_with_faces: Number of images with at least one detected face.
        total_faces: Total number of faces detected across all images.
        n_clusters: Number of clusters found.
        largest_cluster_size: Number of faces in the largest cluster.
        n_outliers: Number of outlier faces.
    """

    total_images: int
    images_with_faces: int
    total_faces: int
    n_clusters: int
    largest_cluster_size: int
    n_outliers: int
