"""Pipeline orchestrator: discover → detect → cluster → export."""

from __future__ import annotations

import logging
from pathlib import Path

from face_cluster_cli.clustering import cluster_faces
from face_cluster_cli.config import FaceClusterSettings
from face_cluster_cli.detector import process_directory
from face_cluster_cli.exceptions import InputDirectoryError
from face_cluster_cli.exporter import export_clusters
from face_cluster_cli.models import PipelineSummary

logger = logging.getLogger(__name__)

IMAGE_EXTENSIONS: frozenset[str] = frozenset(
    {".jpg", ".jpeg", ".png", ".bmp", ".webp", ".tiff", ".tif"}
)


def discover_images(input_dir: Path) -> list[Path]:
    """Find all supported image files in *input_dir*.

    Args:
        input_dir: Directory to scan (non-recursive).

    Returns:
        Sorted list of image paths found.

    Raises:
        InputDirectoryError: If the directory does not exist, is not
            readable, or contains no supported images.
    """
    if not input_dir.exists():
        msg = f"Input directory does not exist: '{input_dir}'"
        raise InputDirectoryError(msg)
    if not input_dir.is_dir():
        msg = f"Input path is not a directory: '{input_dir}'"
        raise InputDirectoryError(msg)
    try:
        entries = list(input_dir.iterdir())
    except PermissionError as exc:
        msg = f"Cannot read input directory '{input_dir}': {exc}"
        raise InputDirectoryError(msg) from exc

    images = sorted(
        p for p in entries if p.is_file() and p.suffix.lower() in IMAGE_EXTENSIONS
    )
    if not images:
        msg = (
            f"No supported images found in '{input_dir}'. "
            f"Supported extensions: {', '.join(sorted(IMAGE_EXTENSIONS))}"
        )
        raise InputDirectoryError(msg)

    logger.debug("Discovered %d images in '%s'", len(images), input_dir)
    return images


def run_pipeline(
    input_dir: Path,
    settings: FaceClusterSettings,
) -> PipelineSummary:
    """Execute the full face-clustering pipeline.

    Steps:
        1. Discover images in *input_dir*.
        2. Detect faces and extract embeddings.
        3. Cluster embeddings with agglomerative clustering.
        4. Export images into per-cluster directories.

    Args:
        input_dir: Directory containing source images.
        settings: Application settings.

    Returns:
        A ``PipelineSummary`` with statistics about the run.
    """
    # 1. Discover
    image_paths = discover_images(input_dir)
    total_images = len(image_paths)

    # 2. Detect
    records = process_directory(image_paths, settings)
    total_faces = len(records)
    images_with_faces = len({r.image_path for r in records})

    if total_faces == 0:
        logger.warning("No faces detected in any of the %d images.", total_images)
        return PipelineSummary(
            total_images=total_images,
            images_with_faces=0,
            total_faces=0,
            n_clusters=0,
            largest_cluster_size=0,
            n_outliers=0,
        )

    # 3. Cluster
    cluster_result = cluster_faces(records, settings)

    # 4. Export
    export_clusters(
        records,
        cluster_result,
        settings.output_dir,
        force=settings.force,
    )

    largest_cluster_size = (
        max(cluster_result.cluster_sizes.values())
        if cluster_result.cluster_sizes
        else 0
    )

    return PipelineSummary(
        total_images=total_images,
        images_with_faces=images_with_faces,
        total_faces=total_faces,
        n_clusters=cluster_result.n_clusters,
        largest_cluster_size=largest_cluster_size,
        n_outliers=cluster_result.n_outliers,
    )
