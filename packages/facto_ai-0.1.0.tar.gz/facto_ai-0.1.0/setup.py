from setuptools import setup

# This file is required for editable installs (pip install -e .)
# All configuration is in pyproject.toml
setup()
