# EvalMode

::: factrainer.core.EvalMode