#!/usr/bin/env python3
"""Example: Evaluate a research report using Faerie.

Usage:
    python examples/evaluate_report.py path/to/report.md

Requires:
    - EXA_API_KEY environment variable
    - GOOGLE_API_KEY environment variable (for Gemini)
    - dragen package installed
"""

import sys
import json
from pathlib import Path

# Add parent to path for local development
sys.path.insert(0, str(Path(__file__).parent.parent))

from dotenv import load_dotenv
load_dotenv()

from faerie import FaerieEvaluator


def main():
    if len(sys.argv) < 2:
        print("Usage: python examples/evaluate_report.py <report.md>")
        sys.exit(1)

    report_path = sys.argv[1]

    print(f"Evaluating: {report_path}")
    print("=" * 60)

    # Create evaluator
    evaluator = FaerieEvaluator(
        model="gemini-3-flash-preview",
        skip_fact_check=False,  # Set to True for faster citation-only check
        max_workers=3,
        verbose=True,
    )

    # Run evaluation
    result = evaluator.evaluate_file(report_path)

    # Print results
    print("\n" + "=" * 60)
    print("EVALUATION RESULTS")
    print("=" * 60)

    m = result.faer_metrics
    print(f"\nReport: {result.report_title}")
    print(f"Claims: {m.total_claims} total ({m.claims_with_citations} with citations)")

    print(f"\nCitation Accuracy: {m.citation_accuracy_rate:.0%}")
    print(f"  - Accurate: {m.citation_accurate}")
    print(f"  - Partial: {m.citation_partial}")
    print(f"  - Inaccurate: {m.citation_inaccurate}")
    print(f"  - Not Found: {m.citation_not_found}")

    print(f"\nFactual Accuracy: {m.fact_accuracy_rate:.0%}")
    print(f"  - Verified: {m.fact_verified}")
    print(f"  - False: {m.fact_false}")
    print(f"  - Unverified: {m.fact_unverified}")

    print(f"\nOverall: {m.overall_accuracy_rate:.0%} fully verified")
    print(f"  - Fully Verified: {m.fully_verified}")
    print(f"  - Miscited: {m.miscited}")
    print(f"  - Cited but False: {m.cited_but_false}")
    print(f"  - Problematic: {m.problematic}")

    print(f"\nSources: {m.accessible_sources}/{m.total_sources} accessible")

    print(f"\n--- Executive Summary ---")
    print(result.executive_summary)

    print(f"\n--- Recommendations ---")
    for i, rec in enumerate(result.recommendations, 1):
        print(f"  {i}. {rec}")

    print(f"\nOverall Quality Score: {result.overall_quality_score:.0%}")

    # Optionally save full results
    output_path = Path(report_path).stem + "_evaluation.json"
    with open(output_path, "w") as f:
        f.write(result.model_dump_json(indent=2))
    print(f"\nFull results saved to: {output_path}")


if __name__ == "__main__":
    main()
