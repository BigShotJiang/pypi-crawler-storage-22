"""Faerie: Fact Error Rate evaluation framework for deep research reports."""

from faerie.pipeline.evaluator import FaerieEvaluator
from faerie.models.evaluation import FaERMetrics, EvaluationReport

__version__ = "0.1.0"
__all__ = ["FaerieEvaluator", "FaERMetrics", "EvaluationReport"]
