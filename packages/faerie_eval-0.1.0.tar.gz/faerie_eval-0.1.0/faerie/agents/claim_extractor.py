"""Claim extraction agent."""

import sys
import json
import re
from typing import Optional

from faerie.models.parsing import ParsedSection
from faerie.models.claims import ExtractedClaim, ClaimExtractionOutput
from faerie.agents.prompts import CLAIM_EXTRACTOR_PROMPT

from dragen import Agent


def parse_result(result) -> dict:
    """Parse the result from the agent, handling various formats including truncated output."""
    if isinstance(result, dict):
        return result

    if isinstance(result, str):
        # Try to extract JSON - handle potentially truncated output

        # Find the start of the claims array
        claims_start = result.find('"claims"')
        if claims_start == -1:
            claims_start = result.find("'claims'")

        if claims_start != -1:
            # Find the opening bracket of claims array
            array_start = result.find('[', claims_start)
            if array_start != -1:
                # Extract individual claim objects
                claims = []
                depth = 0
                current_claim = ""
                in_string = False
                escape_next = False

                for i, char in enumerate(result[array_start:]):
                    if escape_next:
                        current_claim += char
                        escape_next = False
                        continue

                    if char == '\\':
                        current_claim += char
                        escape_next = True
                        continue

                    if char == '"' and not escape_next:
                        in_string = not in_string

                    if not in_string:
                        if char == '{':
                            if depth == 0:
                                current_claim = "{"
                            else:
                                current_claim += char
                            depth += 1
                        elif char == '}':
                            depth -= 1
                            current_claim += char
                            if depth == 0:
                                # Complete claim object
                                try:
                                    claim = json.loads(current_claim)
                                    claims.append(claim)
                                except json.JSONDecodeError:
                                    pass
                                current_claim = ""
                        elif depth > 0:
                            current_claim += char
                    elif depth > 0:
                        current_claim += char

                if claims:
                    return {
                        "claims": claims,
                        "total_claims": len(claims),
                        "claims_with_citations": sum(1 for c in claims if c.get("citation_numbers")),
                        "claims_without_citations": sum(1 for c in claims if not c.get("citation_numbers")),
                    }

        # Fallback: Try standard JSON parsing
        try:
            return json.loads(result)
        except json.JSONDecodeError:
            pass

    return {}


def extract_claims_batch(
    sections: list[tuple[int, ParsedSection]],
    model: str,
    verbose: bool,
) -> list[ExtractedClaim]:
    """Extract claims from a batch of sections."""
    if not sections:
        return []

    # Build task for this batch
    sections_xml = []
    for idx, section in sections:
        sections_xml.append(f"""<section id="s{idx}" title="{section.title}">
{section.content[:2500]}
</section>""")

    all_sections_text = "\n\n".join(sections_xml)

    task = f"""Extract all factual claims from the following report sections.

{all_sections_text}

For each claim, use claim_id format: s{{section_id}}-c{{claim_number}}
Extract claims from ALL sections above in a single response.
Focus on statistical claims, attribution claims, and specific factual statements.
"""

    # Use Cerebras for reliable claim extraction (Gemini is inconsistent)
    agent = Agent(
        "cerebras:zai-glm-4.7",
        max_iterations=5,
        system=CLAIM_EXTRACTOR_PROMPT,
    )

    @agent.tool(finish=True)
    def finish(result: dict) -> dict:
        """Return the extracted claims."""
        return result

    claims: list[ExtractedClaim] = []

    try:
        result = agent.run(task)
        parsed = parse_result(result)

        if parsed:
            for claim_data in parsed.get("claims", []):
                try:
                    claims.append(ExtractedClaim(**claim_data))
                except Exception:
                    pass

    except Exception as e:
        if verbose:
            print(f"    Batch error: {e}", file=sys.stderr)

    return claims


def extract_claims(
    sections: list[ParsedSection],
    model: str = "gemini-3-flash-preview",
    verbose: bool = False,
    batch_size: int = 5,
) -> ClaimExtractionOutput:
    """Extract all factual claims from report sections.

    Args:
        sections: Parsed sections from the report
        model: LLM model to use for extraction
        verbose: Whether to print progress
        batch_size: Number of sections per batch

    Returns:
        ClaimExtractionOutput with all extracted claims
    """
    # Filter sections with actual content
    content_sections = [
        (idx, s) for idx, s in enumerate(sections)
        if s.content.strip() and len(s.content.strip()) > 50
    ]

    if verbose:
        print(f"  Processing {len(content_sections)} sections in batches of {batch_size}...", file=sys.stderr)

    if not content_sections:
        return ClaimExtractionOutput(
            claims=[],
            total_claims=0,
            claims_with_citations=0,
            claims_without_citations=0,
        )

    all_claims: list[ExtractedClaim] = []

    # Process in batches
    for i in range(0, len(content_sections), batch_size):
        batch = content_sections[i:i + batch_size]
        if verbose:
            section_names = [s.title for _, s in batch]
            print(f"    Batch {i // batch_size + 1}: {len(batch)} sections", file=sys.stderr)

        batch_claims = extract_claims_batch(batch, model, verbose)
        all_claims.extend(batch_claims)

        if verbose:
            print(f"      Found {len(batch_claims)} claims", file=sys.stderr)

    if verbose:
        print(f"  Total extracted: {len(all_claims)} claims", file=sys.stderr)

    # Calculate stats
    claims_with_citations = sum(1 for c in all_claims if c.citation_numbers)
    claims_without_citations = len(all_claims) - claims_with_citations

    return ClaimExtractionOutput(
        claims=all_claims,
        total_claims=len(all_claims),
        claims_with_citations=claims_with_citations,
        claims_without_citations=claims_without_citations,
    )
