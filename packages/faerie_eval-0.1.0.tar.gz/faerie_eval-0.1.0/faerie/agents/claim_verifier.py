"""Claim verification agents - both citation and fact checking."""

import os
import sys
import json
import requests
from datetime import datetime
from typing import Optional

from faerie.models.claims import ExtractedClaim
from faerie.models.verification import (
    CitationVerdict,
    FactVerdict,
    ClaimVerificationResult,
    SourceContent,
    CitationCheckResult,
    FactCheckResult,
)
from faerie.agents.prompts import CITATION_VERIFIER_PROMPT, FACT_VERIFIER_PROMPT

from dragen import Agent


def get_datetime_xml() -> str:
    """Get current datetime as XML section for prompts."""
    now = datetime.now()
    return f"<datetime>Today is {now.strftime('%A, %B %d, %Y')} at {now.strftime('%I:%M %p')}.</datetime>"


def search_web(query: str, num_results: int = 5) -> list[dict]:
    """Search the web using Parallel API for fact verification."""
    api_key = os.environ.get("PARALLEL_API_KEY")
    if not api_key:
        return [{"error": "PARALLEL_API_KEY not set"}]

    try:
        response = requests.post(
            "https://api.parallel.ai/v1beta/search",
            headers={
                "x-api-key": api_key,
                "Content-Type": "application/json",
                "parallel-beta": "search-extract-2025-10-10",
            },
            json={
                "mode": "one-shot",
                "search_queries": [query],
                "max_results": min(max(int(num_results), 1), 10),
                "objective": f"Find factual information to verify: {query}",
            },
            timeout=60,
        )
        response.raise_for_status()
        data = response.json()

        results = []
        for r in data.get("results", []):
            # Parallel returns excerpts as a list of strings
            excerpts = r.get("excerpts", [])
            text = "\n".join(excerpts) if excerpts else ""
            results.append({
                "title": r.get("title", ""),
                "url": r.get("url", ""),
                "snippet": text[:2000] if text else "",
            })

        return results

    except Exception as e:
        return [{"error": str(e)}]


def verify_citations_batch(
    claims: list[ExtractedClaim],
    source_contents: dict[int, SourceContent],
    model: str = "gemini-3-flash-preview",
    verbose: bool = False,
) -> list[CitationCheckResult]:
    """Verify citations for multiple claims using agent.map().

    Args:
        claims: List of claims to verify
        source_contents: Map of citation number -> source content
        model: LLM model to use
        verbose: Print progress

    Returns:
        List of CitationCheckResult in same order as claims
    """
    if not claims:
        return []

    # Build tasks and track which claims have sources
    tasks = []
    task_to_claim_idx = []  # Maps task index to original claim index
    no_source_results = {}  # claim index -> result for claims with no sources

    for idx, claim in enumerate(claims):
        # Get source content for this claim's citations
        relevant_sources = []
        for num in claim.citation_numbers:
            if num in source_contents:
                src = source_contents[num]
                if src.accessible and src.content:
                    relevant_sources.append({
                        "number": num,
                        "title": src.title,
                        "url": src.url,
                        "content": src.content[:5000],
                    })

        if not relevant_sources:
            # No sources accessible - store result directly
            no_source_results[idx] = CitationCheckResult(
                claim_id=claim.claim_id,
                claim_text=claim.claim_text,
                citation_verdict=CitationVerdict.SOURCE_UNAVAILABLE,
                confidence=1.0,
                source_quote=None,
                reasoning="Could not access any of the cited sources",
                sources_checked=claim.citation_numbers,
            )
        else:
            # Build task string with sources embedded
            sources_text = "\n\n".join(
                f"<source number=\"{s['number']}\" title=\"{s['title']}\">\n{s['content']}\n</source>"
                for s in relevant_sources
            )

            task = f"""Verify if the following claim is accurately represented by its cited sources.

<claim id="{claim.claim_id}">
{claim.claim_text}
</claim>

<cited_sources>
{sources_text}
</cited_sources>

Check if the sources actually say what the claim states. Return your verdict with claim_id="{claim.claim_id}"."""

            tasks.append(task)
            task_to_claim_idx.append(idx)

    # If no tasks need LLM verification, return early
    if not tasks:
        return [no_source_results[i] for i in range(len(claims))]

    if verbose:
        print(f"    Citation verification: {len(tasks)} claims with sources...", file=sys.stderr)

    # Create agent and run all tasks in parallel
    # Use Cerebras for reliable finish() calls (Gemini is inconsistent)
    agent = Agent("cerebras:zai-glm-4.7", max_iterations=8, system=CITATION_VERIFIER_PROMPT)

    @agent.tool(finish=True)
    def finish(result: dict) -> dict:
        return result

    # Run all tasks in parallel using agent.map()
    # Each result is either success dict or {"error": "..."} for individual failures
    raw_results = agent.map(tasks)

    # Process results and build output in original order
    task_results = {}
    for task_idx, raw in enumerate(raw_results):
        claim_idx = task_to_claim_idx[task_idx]
        claim = claims[claim_idx]

        if raw and isinstance(raw, dict) and "error" not in raw:
            verdict_str = raw.get("citation_verdict", "NOT_FOUND")
            try:
                verdict = CitationVerdict(verdict_str)
            except ValueError:
                verdict = CitationVerdict.NOT_FOUND

            task_results[claim_idx] = CitationCheckResult(
                claim_id=claim.claim_id,
                claim_text=claim.claim_text,
                citation_verdict=verdict,
                confidence=raw.get("confidence", 0.5),
                source_quote=raw.get("source_quote"),
                reasoning=raw.get("reasoning", ""),
                sources_checked=claim.citation_numbers,
            )
        else:
            error_msg = raw.get("error", "Verification failed") if isinstance(raw, dict) else "Verification failed"
            task_results[claim_idx] = CitationCheckResult(
                claim_id=claim.claim_id,
                claim_text=claim.claim_text,
                citation_verdict=CitationVerdict.NOT_FOUND,
                confidence=0.0,
                reasoning=error_msg,
                sources_checked=claim.citation_numbers,
            )

    # Combine results in original order
    results = []
    for idx in range(len(claims)):
        if idx in no_source_results:
            results.append(no_source_results[idx])
        else:
            results.append(task_results[idx])

    return results


def verify_facts_batch(
    claims: list[ExtractedClaim],
    verbose: bool = False,
) -> list[FactCheckResult]:
    """Verify facts for multiple claims using agent.map().

    Args:
        claims: List of claims to verify
        verbose: Print progress

    Returns:
        List of FactCheckResult in same order as claims
    """
    if not claims:
        return []

    if verbose:
        print(f"    Fact verification: {len(claims)} claims...", file=sys.stderr)

    # Build task strings
    tasks = []
    for claim in claims:
        task = f"""Verify if the following claim is factually true by searching for independent sources.

<claim id="{claim.claim_id}">
{claim.claim_text}
</claim>

<context>
This claim appears in section: "{claim.section_title}"
Original sentence: "{claim.original_sentence}"
</context>

Search for independent verification of this claim and determine if it is true. Return your verdict with claim_id="{claim.claim_id}"."""
        tasks.append(task)

    # Create agent with search tool
    prompt = FACT_VERIFIER_PROMPT.replace("{datetime_xml}", get_datetime_xml())
    agent = Agent("cerebras:zai-glm-4.7", max_iterations=10, system=prompt)

    @agent.tool
    def search(query: str, num_results: int = 5) -> list:
        """Search the web to find evidence for or against the claim."""
        return search_web(query, num_results)

    @agent.tool(finish=True)
    def finish(result: dict) -> dict:
        return result

    # Run all tasks in parallel using agent.map()
    # Each result is either success dict or {"error": "..."} for individual failures
    raw_results = agent.map(tasks)

    # Process results
    results = []
    for idx, raw in enumerate(raw_results):
        claim = claims[idx]

        if raw and isinstance(raw, dict) and "error" not in raw:
            verdict_str = raw.get("fact_verdict", "UNVERIFIED")
            try:
                verdict = FactVerdict(verdict_str)
            except ValueError:
                verdict = FactVerdict.UNVERIFIED

            results.append(FactCheckResult(
                claim_id=claim.claim_id,
                claim_text=claim.claim_text,
                fact_verdict=verdict,
                confidence=raw.get("confidence", 0.5),
                supporting_sources=raw.get("supporting_sources", []),
                contradicting_sources=raw.get("contradicting_sources", []),
                evidence=raw.get("evidence"),
                reasoning=raw.get("reasoning", ""),
            ))
        else:
            error_msg = raw.get("error", "Verification failed") if isinstance(raw, dict) else "Verification failed"
            results.append(FactCheckResult(
                claim_id=claim.claim_id,
                claim_text=claim.claim_text,
                fact_verdict=FactVerdict.UNVERIFIED,
                confidence=0.0,
                reasoning=error_msg,
            ))

    return results


def verify_claims(
    claims: list[ExtractedClaim],
    source_contents: dict[int, SourceContent],
    model: str = "gemini-3-flash-preview",
    skip_fact_check: bool = False,
    max_workers: int = 3,  # Kept for API compatibility, not used
    verbose: bool = False,
) -> list[ClaimVerificationResult]:
    """Verify all claims using agent.map() for parallel execution.

    Args:
        claims: List of claims to verify
        source_contents: Map of citation number -> source content
        model: LLM model to use for citation verification
        skip_fact_check: If True, skip independent fact verification
        max_workers: Ignored (kept for API compatibility)
        verbose: Print progress

    Returns:
        List of ClaimVerificationResult
    """
    if not claims:
        return []

    if verbose:
        print(f"  Verifying {len(claims)} claims...", file=sys.stderr)

    # Step 1: Verify citations in parallel
    citation_results = verify_citations_batch(claims, source_contents, model, verbose)

    # Step 2: Verify facts in parallel (if not skipped)
    if skip_fact_check:
        fact_results = [
            FactCheckResult(
                claim_id=claim.claim_id,
                claim_text=claim.claim_text,
                fact_verdict=FactVerdict.UNVERIFIED,
                confidence=0.0,
                reasoning="Fact checking skipped",
            )
            for claim in claims
        ]
    else:
        fact_results = verify_facts_batch(claims, verbose)

    # Combine results
    results = []
    for idx, claim in enumerate(claims):
        citation_result = citation_results[idx]
        fact_result = fact_results[idx]

        results.append(ClaimVerificationResult(
            claim_id=claim.claim_id,
            claim_text=claim.claim_text,
            section_title=claim.section_title,
            citation_numbers=claim.citation_numbers,
            # Citation results
            citation_verdict=citation_result.citation_verdict,
            citation_confidence=citation_result.confidence,
            citation_evidence=citation_result.source_quote,
            citation_reasoning=citation_result.reasoning,
            # Fact results
            fact_verdict=fact_result.fact_verdict,
            fact_confidence=fact_result.confidence,
            fact_evidence=fact_result.evidence,
            fact_sources=fact_result.supporting_sources + fact_result.contradicting_sources,
            fact_reasoning=fact_result.reasoning,
        ))

    # Sort by claim_id
    results.sort(key=lambda r: r.claim_id)
    return results
