"""Extract and rate Nth order insights from text."""

import os
import sys
import requests
from pydantic import BaseModel

from dragen import Agent


INSIGHT_EXTRACTOR_PROMPT = """<role>
You are an expert at identifying insights in research reports. An insight is a conclusion or synthesis derived from combining multiple facts.
</role>

<definitions>
**Nth Order Insight**: A conclusion that requires N base facts to derive.

- **0th order**: Direct fact stated in a source (not an insight)
  Example: "GPT-4 scores 38% on SWE-bench" - just a fact

- **1st order**: Simple restatement or paraphrase of a single fact (not really an insight)
  Example: "GPT-4 performs at 38% accuracy" - same fact, different words

- **2nd order**: Insight combining 2 facts
  Example: "GPT-4 outperforms GPT-3.5 on coding tasks"
  (Requires: GPT-4 score + GPT-3.5 score)

- **3rd order**: Insight combining 3 facts
  Example: "The gap between open and closed models is narrowing"
  (Requires: closed model scores + open model scores + historical trend)

- **4th+ order**: Complex synthesis of many facts
  Example: "The market is bifurcating into high-autonomy and human-in-loop philosophies"
  (Requires: multiple tool comparisons, pricing data, feature analysis, market trends)
</definitions>

<task>
Given a text, extract all insights (2nd order and above). For each insight:
1. Quote the exact text
2. Identify what base facts it combines
3. Rate the order (2, 3, 4, etc.)
4. Explain your reasoning
</task>

<output_format>
Call finish() with a list of insights:
{
  "insights": [
    {
      "text": "exact quote from the report",
      "order": 3,
      "base_facts": ["fact 1 it combines", "fact 2", "fact 3"],
      "reasoning": "why this is a 3rd order insight"
    }
  ]
}
</output_format>

<rules>
- Only extract 2nd order and above (ignore direct facts and paraphrases)
- Focus on claims that synthesize, conclude, or derive new meaning
- Look for causal statements, comparisons, predictions, and evaluations
- The order = number of distinct facts needed to derive the insight
</rules>"""


class Insight(BaseModel):
    """A single insight extracted from text."""
    text: str
    order: int
    base_facts: list[str]
    reasoning: str


class InsightExtractionOutput(BaseModel):
    """Output from insight extraction."""
    insights: list[Insight]


def extract_insights(
    text: str,
    model: str = "claude-sonnet-4-20250514",
    verbose: bool = False,
) -> list[Insight]:
    """Extract Nth order insights from text.

    Args:
        text: The text to analyze
        model: LLM model to use
        verbose: Print progress

    Returns:
        List of insights with their orders
    """
    if verbose:
        print(f"  Extracting insights from text ({len(text)} chars)...", file=sys.stderr)

    agent = Agent(model, max_iterations=5, system=INSIGHT_EXTRACTOR_PROMPT)

    @agent.tool(finish=True)
    def finish(result: dict) -> dict:
        return result

    task = f"""Analyze this text and extract all insights (2nd order and above):

<text>
{text[:30000]}
</text>

Extract insights and call finish() with the results."""

    try:
        result = agent.run(task, schema=InsightExtractionOutput.model_json_schema())

        if isinstance(result, dict) and "insights" in result:
            insights = []
            for item in result["insights"]:
                insights.append(Insight(
                    text=item.get("text", ""),
                    order=item.get("order", 2),
                    base_facts=item.get("base_facts", []),
                    reasoning=item.get("reasoning", ""),
                ))
            return insights
        else:
            if verbose:
                print(f"  Unexpected result format: {type(result)}", file=sys.stderr)
            return []

    except Exception as e:
        if verbose:
            print(f"  Error extracting insights: {e}", file=sys.stderr)
        return []


def analyze_report_insights(report_path: str, verbose: bool = False) -> dict:
    """Analyze a report file for insights.

    Args:
        report_path: Path to the markdown report
        verbose: Print progress

    Returns:
        Analysis summary with insights by order
    """
    with open(report_path, 'r') as f:
        text = f.read()

    insights = extract_insights(text, verbose=verbose)

    # Group by order
    by_order = {}
    for insight in insights:
        order = insight.order
        if order not in by_order:
            by_order[order] = []
        by_order[order].append(insight)

    return {
        "total_insights": len(insights),
        "by_order": {k: len(v) for k, v in sorted(by_order.items())},
        "insights": insights,
        "avg_order": sum(i.order for i in insights) / len(insights) if insights else 0,
    }


if __name__ == "__main__":
    import json

    if len(sys.argv) < 2:
        print("Usage: python insight_extractor.py <report.md>")
        sys.exit(1)

    report_path = sys.argv[1]
    result = analyze_report_insights(report_path, verbose=True)

    print(f"\n=== INSIGHT ANALYSIS ===")
    print(f"Total insights found: {result['total_insights']}")
    print(f"Average order: {result['avg_order']:.1f}")
    print(f"\nBy order:")
    for order, count in result['by_order'].items():
        print(f"  {order}th order: {count}")

    print(f"\n=== INSIGHTS ===")
    for insight in result['insights']:
        print(f"\n[{insight.order}th order] {insight.text[:100]}...")
        print(f"  Base facts: {insight.base_facts[:3]}...")
