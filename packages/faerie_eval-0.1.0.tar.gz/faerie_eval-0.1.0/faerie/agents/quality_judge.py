"""LLM-based quality judge for structure and thoroughness."""

import sys
from pydantic import BaseModel, Field

from dragen import Agent

QUALITY_JUDGE_PROMPT = """You are an expert evaluator of research report quality. You assess two dimensions:

1. **Structure & Organization** (0-100):
   - Clear hierarchical organization with logical sections
   - Good flow from introduction to conclusion
   - Appropriate use of headings and subheadings
   - Balanced section lengths
   - Professional formatting

2. **Thoroughness & Depth** (0-100):
   - Comprehensive coverage of the topic
   - Sufficient detail and explanation
   - Multiple perspectives considered
   - Evidence and examples provided
   - No obvious gaps in coverage

Be critical but fair. A score of 70+ is good, 50-70 is acceptable, below 50 needs improvement.

Return your assessment as a JSON object with:
- structure_score: 0-100
- structure_reasoning: brief explanation
- thoroughness_score: 0-100
- thoroughness_reasoning: brief explanation
"""


class QualityAssessment(BaseModel):
    """Quality assessment result."""
    structure_score: float = Field(ge=0, le=100, description="Structure/organization score 0-100")
    structure_reasoning: str = Field(description="Explanation for structure score")
    thoroughness_score: float = Field(ge=0, le=100, description="Thoroughness/depth score 0-100")
    thoroughness_reasoning: str = Field(description="Explanation for thoroughness score")


def assess_quality(
    report_content: str,
    section_titles: list[str],
    model: str = "gemini-3-flash-preview",
    verbose: bool = False,
) -> QualityAssessment:
    """Assess report quality using LLM judge.

    Args:
        report_content: The full report content (truncated if too long)
        section_titles: List of section titles for structure analysis
        model: LLM model to use
        verbose: Print progress

    Returns:
        QualityAssessment with structure and thoroughness scores
    """
    if verbose:
        print("  Assessing report quality...", file=sys.stderr)

    # Build the task with report overview
    sections_list = "\n".join(f"  - {title}" for title in section_titles)

    # Truncate content if too long (keep first 8000 chars for overview)
    content_preview = report_content[:8000]
    if len(report_content) > 8000:
        content_preview += "\n\n[... content truncated for assessment ...]"

    task = f"""Assess the quality of this research report.

## Report Sections:
{sections_list}

## Report Content (preview):
{content_preview}

Evaluate the structure/organization and thoroughness/depth of this report.
Return your scores and reasoning.
"""

    agent = Agent(model, max_iterations=3, system=QUALITY_JUDGE_PROMPT)

    @agent.tool(finish=True)
    def submit_assessment(result: dict) -> dict:
        """Submit the quality assessment."""
        return result

    try:
        result = agent.run(task)

        if isinstance(result, dict):
            return QualityAssessment(
                structure_score=result.get("structure_score", 50),
                structure_reasoning=result.get("structure_reasoning", ""),
                thoroughness_score=result.get("thoroughness_score", 50),
                thoroughness_reasoning=result.get("thoroughness_reasoning", ""),
            )
    except Exception as e:
        if verbose:
            print(f"    Quality assessment error: {e}", file=sys.stderr)

    # Default scores if assessment fails
    return QualityAssessment(
        structure_score=50,
        structure_reasoning="Could not assess structure",
        thoroughness_score=50,
        thoroughness_reasoning="Could not assess thoroughness",
    )
