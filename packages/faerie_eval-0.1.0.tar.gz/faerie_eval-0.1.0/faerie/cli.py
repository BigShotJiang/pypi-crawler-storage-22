"""Command-line interface for Faerie."""

import json
import sys
from pathlib import Path

import click
from dotenv import load_dotenv

from faerie.pipeline.evaluator import FaerieEvaluator
from faerie.grading import create_grade_card, print_grade_card


@click.group()
@click.version_option(version="0.1.0")
def main():
    """Faerie: Fact Error Rate evaluation for research reports."""
    load_dotenv()


@main.command()
@click.argument("report_path", type=click.Path(exists=True))
@click.option(
    "--output", "-o",
    type=click.Path(),
    help="Output file for JSON results (default: stdout summary)",
)
@click.option(
    "--model", "-m",
    default="gemini-3-flash-preview",
    help="LLM model to use for verification",
)
@click.option(
    "--skip-fact-check",
    is_flag=True,
    help="Skip independent fact verification (faster, citation-only)",
)
@click.option(
    "--skip-insights",
    is_flag=True,
    help="Skip Nth order insight extraction",
)
@click.option(
    "--max-workers", "-w",
    default=3,
    type=int,
    help="Max parallel verification workers",
)
@click.option(
    "--verbose", "-v",
    is_flag=True,
    help="Print detailed progress",
)
@click.option(
    "--json",
    "output_json",
    is_flag=True,
    help="Output full JSON report to stdout",
)
def evaluate(
    report_path: str,
    output: str | None,
    model: str,
    skip_fact_check: bool,
    skip_insights: bool,
    max_workers: int,
    verbose: bool,
    output_json: bool,
):
    """Evaluate a research report for factual accuracy.

    REPORT_PATH: Path to the markdown report file to evaluate.

    Examples:

        faerie evaluate report.md

        faerie evaluate report.md --output results.json

        faerie evaluate report.md --skip-fact-check --verbose
    """
    evaluator = FaerieEvaluator(
        model=model,
        skip_fact_check=skip_fact_check,
        skip_insights=skip_insights,
        max_workers=max_workers,
        verbose=verbose,
    )

    try:
        result = evaluator.evaluate_file(report_path)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)

    # Flush stderr to ensure verbose output appears before summary
    sys.stderr.flush()

    # Output results
    if output:
        # Save full JSON to file
        Path(output).write_text(
            result.model_dump_json(indent=2),
            encoding="utf-8",
        )
        click.echo(f"Results saved to {output}")

    if output_json:
        # Print full JSON to stdout
        click.echo(result.model_dump_json(indent=2))
    elif not output:
        # Print summary to stdout
        print_summary(result)


def print_summary(result):
    """Print a human-readable summary of the evaluation."""
    m = result.faer_metrics

    # Create and print grade card
    grade_card = create_grade_card(
        score=result.overall_quality_score * 100,
        citation_accuracy=m.citation_accuracy_rate * 100,
        factual_accuracy=m.fact_accuracy_rate * 100,
        source_accessibility=m.source_accessibility_rate * 100,
        verified_ratio=m.overall_accuracy_rate * 100,
        total_claims=m.total_claims,
        accurate_citations=m.citation_accurate,
        verified_claims=m.fact_verified,
        false_claims=m.fact_false,
        unverifiable_claims=m.fact_unverified,
        accessible_sources=m.accessible_sources,
        total_sources=m.total_sources,
        false_penalty=m.false_penalty,
        unverifiable_penalty=m.unverifiable_penalty,
        combined_penalty=m.combined_penalty,
        structure_score=m.structure_score,
        thoroughness_score=m.thoroughness_score,
    )
    print_grade_card(grade_card)

    click.echo()
    click.echo(click.style("=" * 60, fg="blue"))
    click.echo(click.style(f"  FAERIE EVALUATION: {result.report_title}", fg="blue", bold=True))
    click.echo(click.style("=" * 60, fg="blue"))

    click.echo()
    click.echo(click.style("METRICS SUMMARY", bold=True))
    click.echo("-" * 40)

    # Claims
    click.echo(f"Total Claims:          {m.total_claims}")
    click.echo(f"  With Citations:      {m.claims_with_citations}")
    click.echo(f"  Without Citations:   {m.claims_without_citations}")

    click.echo()

    # Citation accuracy
    rate = m.citation_accuracy_rate
    color = "green" if rate >= 0.7 else "yellow" if rate >= 0.5 else "red"
    click.echo(f"Citation Accuracy:     {click.style(f'{rate:.0%}', fg=color)}")
    click.echo(f"  Accurate:            {m.citation_accurate}")
    click.echo(f"  Partial:             {m.citation_partial}")
    click.echo(f"  Inaccurate:          {m.citation_inaccurate}")
    click.echo(f"  Not Found:           {m.citation_not_found}")

    click.echo()

    # Fact accuracy
    rate = m.fact_accuracy_rate
    color = "green" if rate >= 0.7 else "yellow" if rate >= 0.5 else "red"
    click.echo(f"Factual Accuracy:      {click.style(f'{rate:.0%}', fg=color)}")
    click.echo(f"  Verified:            {m.fact_verified}")
    click.echo(f"  False:               {m.fact_false}")
    click.echo(f"  Unverified:          {m.fact_unverified}")
    click.echo(f"  Disputed:            {m.fact_disputed}")

    click.echo()

    # Overall
    rate = m.overall_accuracy_rate
    color = "green" if rate >= 0.7 else "yellow" if rate >= 0.5 else "red"
    click.echo(f"Overall Verification:  {click.style(f'{rate:.0%}', fg=color)}")
    click.echo(f"  Fully Verified:      {m.fully_verified}")
    click.echo(f"  Miscited:            {m.miscited}")
    click.echo(f"  Cited but False:     {m.cited_but_false}")
    click.echo(f"  Problematic:         {m.problematic}")

    click.echo()

    # Sources
    click.echo(f"Sources:               {m.accessible_sources}/{m.total_sources} accessible")

    click.echo()
    click.echo(click.style("EXECUTIVE SUMMARY", bold=True))
    click.echo("-" * 40)
    click.echo(result.executive_summary)

    click.echo()
    click.echo(click.style("RECOMMENDATIONS", bold=True))
    click.echo("-" * 40)
    for i, rec in enumerate(result.recommendations, 1):
        click.echo(f"  {i}. {rec}")

    click.echo()
    click.echo(f"Overall Quality Score: {click.style(f'{result.overall_quality_score:.0%}', bold=True)}")

    # Display insights (separate from grade)
    if result.insight_analysis:
        click.echo()
        click.echo(click.style("=" * 60, fg="cyan"))
        click.echo(click.style("  INSIGHT ANALYSIS (separate from grade)", fg="cyan", bold=True))
        click.echo(click.style("=" * 60, fg="cyan"))

        ia = result.insight_analysis
        click.echo()
        click.echo(f"Total Insights:        {ia.total_insights}")
        click.echo(f"Average Order:         {ia.average_order:.1f}")
        click.echo()
        click.echo("Order Distribution:")
        for order in sorted(ia.order_distribution.keys()):
            count = ia.order_distribution[order]
            bar = "█" * count
            click.echo(f"  {order}th order: {count:2d} {bar}")

        click.echo()
        click.echo(click.style("Top Insights:", bold=True))
        # Show top 5 highest-order insights
        sorted_insights = sorted(ia.insights, key=lambda x: -x.order)
        for i, insight in enumerate(sorted_insights[:5], 1):
            click.echo()
            click.echo(f"  [{insight.order}th order] {insight.text[:100]}...")
            click.echo(f"    Base facts: {len(insight.base_facts)} facts combined")

    click.echo()


@main.command()
@click.argument("report_path", type=click.Path(exists=True))
def parse(report_path: str):
    """Parse a report and show its structure (for debugging)."""
    from faerie.parsers.markdown_parser import parse_report

    with open(report_path, "r", encoding="utf-8") as f:
        markdown = f.read()

    result = parse_report(markdown)

    click.echo(f"Title: {result.title}")
    click.echo(f"\nSections ({len(result.sections)}):")
    for section in result.sections:
        indent = "  " if section.level == 1 else "    "
        citations = f" [{', '.join(map(str, section.citation_numbers))}]" if section.citation_numbers else ""
        click.echo(f"{indent}- {section.title}{citations}")

    click.echo(f"\nCitations ({len(result.citations)}):")
    for citation in result.citations:
        click.echo(f"  [{citation.number}] {citation.title}")
        click.echo(f"       {citation.url}")


if __name__ == "__main__":
    main()
