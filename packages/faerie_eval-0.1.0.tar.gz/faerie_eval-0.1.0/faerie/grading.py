"""Grade card generator with ASCII art grades."""

from dataclasses import dataclass
from enum import Enum


class Grade(str, Enum):
    S_PLUS = "S+"
    S = "S"
    S_MINUS = "S-"
    A_PLUS = "A+"
    A = "A"
    A_MINUS = "A-"
    B_PLUS = "B+"
    B = "B"
    B_MINUS = "B-"
    C_PLUS = "C+"
    C = "C"
    C_MINUS = "C-"
    D_PLUS = "D+"
    D = "D"
    D_MINUS = "D-"
    E_PLUS = "E+"
    E = "E"
    E_MINUS = "E-"
    F_PLUS = "F+"
    F = "F"
    F_MINUS = "F-"


# Grade thresholds (percentage)
GRADE_THRESHOLDS = [
    (98, Grade.S_PLUS),
    (95, Grade.S),
    (92, Grade.S_MINUS),
    (90, Grade.A_PLUS),
    (87, Grade.A),
    (83, Grade.A_MINUS),
    (80, Grade.B_PLUS),
    (77, Grade.B),
    (73, Grade.B_MINUS),
    (70, Grade.C_PLUS),
    (67, Grade.C),
    (63, Grade.C_MINUS),
    (60, Grade.D_PLUS),
    (57, Grade.D),
    (53, Grade.D_MINUS),
    (50, Grade.E_PLUS),
    (47, Grade.E),
    (43, Grade.E_MINUS),
    (40, Grade.F_PLUS),
    (30, Grade.F),
    (0, Grade.F_MINUS),
]


ASCII_GRADES = {
    "S": r"""
  ███████╗
  ██╔════╝
  ███████╗
  ╚════██║
  ███████║
  ╚══════╝
""",
    "A": r"""
   █████╗
  ██╔══██╗
  ███████║
  ██╔══██║
  ██║  ██║
  ╚═╝  ╚═╝
""",
    "B": r"""
  ██████╗
  ██╔══██╗
  ██████╔╝
  ██╔══██╗
  ██████╔╝
  ╚═════╝
""",
    "C": r"""
   ██████╗
  ██╔════╝
  ██║
  ██║
  ╚██████╗
   ╚═════╝
""",
    "D": r"""
  ██████╗
  ██╔══██╗
  ██║  ██║
  ██║  ██║
  ██████╔╝
  ╚═════╝
""",
    "E": r"""
  ███████╗
  ██╔════╝
  █████╗
  ██╔══╝
  ███████╗
  ╚══════╝
""",
    "F": r"""
  ███████╗
  ██╔════╝
  █████╗
  ██╔══╝
  ██║
  ╚═╝
""",
    "+": r"""
  ██╗
  ██║
██████╗
╚═██╔═╝
  ╚═╝
""",
    "-": r"""


█████╗
╚════╝

""",
}


@dataclass
class GradeReason:
    """A reason contributing to the grade."""
    category: str
    assessment: str
    impact: str  # "positive", "negative", "neutral"
    detail: str


@dataclass
class GradeCard:
    """Complete grade card with ASCII art and reasoning."""
    grade: Grade
    score: float
    ascii_art: str
    reasons: list[GradeReason]
    summary: str


def get_grade(score: float) -> Grade:
    """Convert a percentage score to a letter grade."""
    for threshold, grade in GRADE_THRESHOLDS:
        if score >= threshold:
            return grade
    return Grade.F_MINUS


def get_ascii_art(grade: Grade) -> str:
    """Generate ASCII art for a grade."""
    grade_str = grade.value

    # Get the base letter
    base_letter = grade_str[0]
    modifier = grade_str[1] if len(grade_str) > 1 else None

    base_art = ASCII_GRADES.get(base_letter, ASCII_GRADES["F"])

    if modifier is None:
        return base_art

    # Combine base letter with modifier side by side
    modifier_art = ASCII_GRADES.get(modifier, "")

    base_lines = base_art.split("\n")
    modifier_lines = modifier_art.split("\n")

    # Pad to same length
    max_lines = max(len(base_lines), len(modifier_lines))
    while len(base_lines) < max_lines:
        base_lines.append("")
    while len(modifier_lines) < max_lines:
        modifier_lines.append("")

    # Find max width of base
    max_base_width = max(len(line) for line in base_lines) if base_lines else 0

    # Combine side by side
    combined = []
    for base_line, mod_line in zip(base_lines, modifier_lines):
        padded_base = base_line.ljust(max_base_width)
        combined.append(padded_base + " " + mod_line)

    return "\n".join(combined)


def generate_reasons(
    citation_accuracy: float,
    factual_accuracy: float,
    source_accessibility: float,
    verified_ratio: float,
    total_claims: int,
    accurate_citations: int,
    verified_claims: int,
    false_claims: int,
    unverifiable_claims: int,
    accessible_sources: int,
    total_sources: int,
    false_penalty: float,
    unverifiable_penalty: float,
    combined_penalty: float,
    structure_score: float = 1.0,
    thoroughness_score: float = 1.0,
) -> list[GradeReason]:
    """Generate reasons based on evaluation metrics."""
    reasons = []

    # Source accessibility
    if source_accessibility >= 90:
        reasons.append(GradeReason(
            category="Sources",
            assessment="Excellent",
            impact="positive",
            detail=f"{accessible_sources}/{total_sources} sources are accessible and verifiable"
        ))
    elif source_accessibility >= 70:
        reasons.append(GradeReason(
            category="Sources",
            assessment="Good",
            impact="positive",
            detail=f"{accessible_sources}/{total_sources} sources accessible ({100-source_accessibility:.0f}% inaccessible)"
        ))
    elif source_accessibility >= 50:
        reasons.append(GradeReason(
            category="Sources",
            assessment="Fair",
            impact="neutral",
            detail=f"Only {accessible_sources}/{total_sources} sources accessible - {100-source_accessibility:.0f}% may be fabricated"
        ))
    else:
        reasons.append(GradeReason(
            category="Sources",
            assessment="Poor",
            impact="negative",
            detail=f"Only {accessible_sources}/{total_sources} sources accessible - {100-source_accessibility:.0f}% appear fabricated"
        ))

    # Citation accuracy
    if citation_accuracy >= 90:
        reasons.append(GradeReason(
            category="Citations",
            assessment="Excellent",
            impact="positive",
            detail=f"{accurate_citations} citations accurately represent their sources"
        ))
    elif citation_accuracy >= 70:
        reasons.append(GradeReason(
            category="Citations",
            assessment="Good",
            impact="positive",
            detail=f"{citation_accuracy:.0f}% of citations accurately represent sources"
        ))
    elif citation_accuracy >= 50:
        reasons.append(GradeReason(
            category="Citations",
            assessment="Fair",
            impact="neutral",
            detail=f"Only {citation_accuracy:.0f}% citation accuracy - many claims don't match sources"
        ))
    else:
        reasons.append(GradeReason(
            category="Citations",
            assessment="Poor",
            impact="negative",
            detail=f"Only {citation_accuracy:.0f}% citation accuracy - sources don't support claims"
        ))

    # Factual accuracy - with penalty information
    if false_claims > 0:
        reasons.append(GradeReason(
            category="False Facts",
            assessment=f"CRITICAL ({false_claims})",
            impact="negative",
            detail=f"{false_claims} provably false claims - score penalty: ×{false_penalty:.0%}"
        ))

    if unverifiable_claims > 0:
        reasons.append(GradeReason(
            category="Unverifiable",
            assessment=f"Warning ({unverifiable_claims})",
            impact="negative" if unverifiable_claims > total_claims * 0.5 else "neutral",
            detail=f"{unverifiable_claims} claims cannot be verified - penalty: ×{unverifiable_penalty:.0%}"
        ))

    if verified_claims > 0:
        if verified_claims > total_claims * 0.5:
            reasons.append(GradeReason(
                category="Verified Facts",
                assessment="Good",
                impact="positive",
                detail=f"{verified_claims}/{total_claims} claims independently verified as true"
            ))
        else:
            reasons.append(GradeReason(
                category="Verified Facts",
                assessment="Limited",
                impact="neutral",
                detail=f"Only {verified_claims}/{total_claims} claims could be independently verified"
            ))

    # Combined penalty summary
    if combined_penalty < 1.0:
        reasons.append(GradeReason(
            category="FaER Penalty",
            assessment=f"×{combined_penalty:.0%}",
            impact="negative",
            detail=f"Combined fact error penalty applied to content score"
        ))

    # Structure (5% of grade - differentiates A from S+)
    structure_pct = structure_score * 100
    if structure_score >= 0.9:
        reasons.append(GradeReason(
            category="Structure",
            assessment=f"Excellent ({structure_pct:.0f}%)",
            impact="positive",
            detail="Well-organized with clear sections and logical flow"
        ))
    elif structure_score >= 0.7:
        reasons.append(GradeReason(
            category="Structure",
            assessment=f"Good ({structure_pct:.0f}%)",
            impact="positive",
            detail="Reasonably organized with adequate structure"
        ))
    elif structure_score >= 0.5:
        reasons.append(GradeReason(
            category="Structure",
            assessment=f"Fair ({structure_pct:.0f}%)",
            impact="neutral",
            detail="Some organizational issues but readable"
        ))
    else:
        reasons.append(GradeReason(
            category="Structure",
            assessment=f"Poor ({structure_pct:.0f}%)",
            impact="negative",
            detail="Poorly organized or difficult to follow"
        ))

    # Thoroughness (5% of grade - differentiates A from S+)
    thoroughness_pct = thoroughness_score * 100
    if thoroughness_score >= 0.9:
        reasons.append(GradeReason(
            category="Thoroughness",
            assessment=f"Excellent ({thoroughness_pct:.0f}%)",
            impact="positive",
            detail="Comprehensive coverage with excellent depth"
        ))
    elif thoroughness_score >= 0.7:
        reasons.append(GradeReason(
            category="Thoroughness",
            assessment=f"Good ({thoroughness_pct:.0f}%)",
            impact="positive",
            detail="Good coverage of the topic with adequate detail"
        ))
    elif thoroughness_score >= 0.5:
        reasons.append(GradeReason(
            category="Thoroughness",
            assessment=f"Fair ({thoroughness_pct:.0f}%)",
            impact="neutral",
            detail="Some gaps in coverage or depth"
        ))
    else:
        reasons.append(GradeReason(
            category="Thoroughness",
            assessment=f"Poor ({thoroughness_pct:.0f}%)",
            impact="negative",
            detail="Significant gaps in coverage or superficial treatment"
        ))

    # Overall verification
    if verified_ratio >= 80:
        reasons.append(GradeReason(
            category="Overall",
            assessment="Trustworthy",
            impact="positive",
            detail="High confidence in report accuracy"
        ))
    elif verified_ratio >= 50:
        reasons.append(GradeReason(
            category="Overall",
            assessment="Mixed",
            impact="neutral",
            detail="Some claims verified, but gaps remain"
        ))
    elif verified_ratio >= 20:
        reasons.append(GradeReason(
            category="Overall",
            assessment="Questionable",
            impact="negative",
            detail="Most claims cannot be verified"
        ))
    else:
        reasons.append(GradeReason(
            category="Overall",
            assessment="Unreliable",
            impact="negative",
            detail="Report cannot be trusted without independent verification"
        ))

    return reasons


def generate_summary(grade: Grade, reasons: list[GradeReason]) -> str:
    """Generate a summary statement based on grade and reasons."""
    negative_count = sum(1 for r in reasons if r.impact == "negative")
    positive_count = sum(1 for r in reasons if r.impact == "positive")

    if grade.value.startswith("S"):
        return "Outstanding research quality with excellent sourcing and verification."
    elif grade.value.startswith("A"):
        return "High quality research with strong sourcing and minimal issues."
    elif grade.value.startswith("B"):
        return "Good research quality with some areas for improvement."
    elif grade.value.startswith("C"):
        return "Acceptable research but significant verification gaps exist."
    elif grade.value.startswith("D"):
        return "Below standard - multiple issues with sources and verification."
    elif grade.value.startswith("E"):
        return "Poor quality - serious concerns about accuracy and sourcing."
    else:
        return "Failing grade - report cannot be trusted without major revisions."


def create_grade_card(
    score: float,
    citation_accuracy: float,
    factual_accuracy: float,
    source_accessibility: float,
    verified_ratio: float,
    total_claims: int,
    accurate_citations: int,
    verified_claims: int,
    false_claims: int,
    unverifiable_claims: int,
    accessible_sources: int,
    total_sources: int,
    false_penalty: float = 1.0,
    unverifiable_penalty: float = 1.0,
    combined_penalty: float = 1.0,
    structure_score: float = 1.0,
    thoroughness_score: float = 1.0,
) -> GradeCard:
    """Create a complete grade card from evaluation metrics."""
    grade = get_grade(score)
    ascii_art = get_ascii_art(grade)
    reasons = generate_reasons(
        citation_accuracy=citation_accuracy,
        factual_accuracy=factual_accuracy,
        source_accessibility=source_accessibility,
        verified_ratio=verified_ratio,
        total_claims=total_claims,
        accurate_citations=accurate_citations,
        verified_claims=verified_claims,
        false_claims=false_claims,
        unverifiable_claims=unverifiable_claims,
        accessible_sources=accessible_sources,
        total_sources=total_sources,
        false_penalty=false_penalty,
        unverifiable_penalty=unverifiable_penalty,
        combined_penalty=combined_penalty,
        structure_score=structure_score,
        thoroughness_score=thoroughness_score,
    )
    summary = generate_summary(grade, reasons)

    return GradeCard(
        grade=grade,
        score=score,
        ascii_art=ascii_art,
        reasons=reasons,
        summary=summary,
    )


def format_grade_card(card: GradeCard, use_color: bool = True) -> str:
    """Format a grade card for terminal output."""
    lines = []

    # Color codes
    if use_color:
        RESET = "\033[0m"
        BOLD = "\033[1m"
        RED = "\033[91m"
        GREEN = "\033[92m"
        YELLOW = "\033[93m"
        BLUE = "\033[94m"
        CYAN = "\033[96m"

        # Grade colors
        grade_colors = {
            "S": CYAN + BOLD,
            "A": GREEN + BOLD,
            "B": BLUE + BOLD,
            "C": YELLOW + BOLD,
            "D": YELLOW,
            "E": RED,
            "F": RED + BOLD,
        }
        grade_color = grade_colors.get(card.grade.value[0], RESET)
    else:
        RESET = BOLD = RED = GREEN = YELLOW = BLUE = CYAN = ""
        grade_color = ""

    # Header
    lines.append("")
    lines.append(f"{BOLD}{'=' * 60}{RESET}")
    lines.append(f"{BOLD}  FAERIE GRADE CARD{RESET}")
    lines.append(f"{'=' * 60}")
    lines.append("")

    # ASCII grade
    for line in card.ascii_art.split("\n"):
        if line.strip():
            lines.append(f"{grade_color}{line}{RESET}")

    lines.append("")
    lines.append(f"  {BOLD}Grade: {grade_color}{card.grade.value}{RESET}  ({card.score:.1f}%)")
    lines.append("")

    # Reasons
    lines.append(f"{BOLD}  ASSESSMENT{RESET}")
    lines.append(f"  {'-' * 40}")

    for reason in card.reasons:
        if use_color:
            if reason.impact == "positive":
                icon = f"{GREEN}✓{RESET}"
            elif reason.impact == "negative":
                icon = f"{RED}✗{RESET}"
            else:
                icon = f"{YELLOW}○{RESET}"
        else:
            if reason.impact == "positive":
                icon = "+"
            elif reason.impact == "negative":
                icon = "-"
            else:
                icon = "o"

        lines.append(f"  {icon} {BOLD}{reason.category}{RESET}: {reason.assessment}")
        lines.append(f"      {reason.detail}")

    lines.append("")
    lines.append(f"  {'-' * 40}")
    lines.append(f"  {card.summary}")
    lines.append("")
    lines.append(f"{'=' * 60}")
    lines.append("")

    return "\n".join(lines)


def print_grade_card(card: GradeCard, use_color: bool = True) -> None:
    """Print a grade card to stdout."""
    print(format_grade_card(card, use_color))
