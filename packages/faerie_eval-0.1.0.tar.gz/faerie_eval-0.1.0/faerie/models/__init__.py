"""Data models for Faerie evaluation."""

from faerie.models.parsing import ParsedReport, ParsedSection, Citation
from faerie.models.claims import ExtractedClaim, Verdict, ClaimExtractionOutput
from faerie.models.verification import (
    CitationVerdict,
    FactVerdict,
    ClaimVerificationResult,
    SourceContent,
    SourceVerificationResult,
    CitationCheckResult,
    FactCheckResult,
)
from faerie.models.evaluation import FaERMetrics, EvaluationReport, QualityDimension

__all__ = [
    # Parsing
    "ParsedReport",
    "ParsedSection",
    "Citation",
    # Claims
    "ExtractedClaim",
    "Verdict",
    "ClaimExtractionOutput",
    # Verification
    "CitationVerdict",
    "FactVerdict",
    "ClaimVerificationResult",
    "SourceContent",
    "SourceVerificationResult",
    "CitationCheckResult",
    "FactCheckResult",
    # Evaluation
    "FaERMetrics",
    "EvaluationReport",
    "QualityDimension",
]
