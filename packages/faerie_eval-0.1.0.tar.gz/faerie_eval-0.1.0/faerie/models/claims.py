"""Models for claim extraction."""

from enum import Enum
from pydantic import BaseModel


class Verdict(str, Enum):
    """Verdict for a claim verification."""

    SUPPORTED = "SUPPORTED"  # Source content supports the claim
    CONTRADICTED = "CONTRADICTED"  # Source content contradicts the claim
    UNSUPPORTED = "UNSUPPORTED"  # Claim cannot be verified from source
    FABRICATED = "FABRICATED"  # Source URL is fake/inaccessible
    UNSURE = "UNSURE"  # Insufficient evidence either way


class ExtractedClaim(BaseModel):
    """An atomic factual claim extracted from the report."""

    claim_id: str  # Unique identifier (e.g., "s2-c3")
    claim_text: str  # The factual statement
    section_title: str  # Which section it came from
    citation_numbers: list[int]  # Citation numbers for this claim
    claim_type: str = "factual"  # factual, statistical, attribution
    original_sentence: str = ""  # Full sentence for context


class ClaimExtractionOutput(BaseModel):
    """Output schema for claim extraction agent."""

    claims: list[ExtractedClaim]
    total_claims: int
    claims_with_citations: int
    claims_without_citations: int
