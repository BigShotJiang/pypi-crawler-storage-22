"""Models for evaluation results."""

from pydantic import BaseModel, Field

from faerie.models.verification import (
    ClaimVerificationResult,
    SourceVerificationResult,
    CitationVerdict,
    FactVerdict,
)


class QualityDimension(BaseModel):
    """A single quality dimension score."""

    name: str
    score: float = Field(ge=0.0, le=1.0)  # 0-1 score
    description: str
    details: str = ""


class FaERMetrics(BaseModel):
    """Fact Error Rate metrics - now with dual verification."""

    # Claim counts
    total_claims: int
    claims_with_citations: int
    claims_without_citations: int

    # Citation accuracy metrics
    citation_accurate: int  # Source says what's claimed
    citation_inaccurate: int  # Source doesn't say that
    citation_partial: int  # Partially accurate
    citation_not_found: int  # Claim not in source
    citation_unavailable: int  # Couldn't access source

    # Factual accuracy metrics
    fact_verified: int  # Independently confirmed true
    fact_false: int  # Independently confirmed false
    fact_unverified: int  # Couldn't verify
    fact_disputed: int  # Sources disagree

    # Combined status counts
    fully_verified: int  # Both citation accurate AND fact true
    cited_but_false: int  # Citation accurate but fact is false
    miscited: int  # Fact true but citation inaccurate
    problematic: int  # Both citation and fact have issues

    # Calculated rates
    citation_accuracy_rate: float  # (accurate + partial) / total
    fact_accuracy_rate: float  # verified / (verified + false)
    overall_accuracy_rate: float  # fully_verified / total

    # Source-level metrics
    total_sources: int
    accessible_sources: int
    inaccessible_sources: int
    source_accessibility_rate: float

    # FaER - Fact Error Rate penalties
    fact_error_count: int = 0  # Number of provably false facts
    unverifiable_count: int = 0  # Number of unverifiable/hallucinated facts

    # Penalty multipliers (exponential decay)
    # False facts: 0.5^n (each false fact halves the score)
    # Unverifiable: 0.75^n (each unverifiable cuts 25%)
    false_penalty: float = 1.0  # 0.5^fact_error_count
    unverifiable_penalty: float = 1.0  # 0.75^unverifiable_count
    combined_penalty: float = 1.0  # false_penalty * unverifiable_penalty

    # Quality scores from LLM judge (0-1)
    structure_score: float = 1.0  # Structure/organization
    thoroughness_score: float = 1.0  # Depth/coverage
    structure_reasoning: str = ""
    thoroughness_reasoning: str = ""

    @classmethod
    def from_results(
        cls,
        results: list[ClaimVerificationResult],
        source_result: SourceVerificationResult,
    ) -> "FaERMetrics":
        """Calculate metrics from verification results."""
        total = len(results)
        claims_with_citations = sum(1 for r in results if r.citation_numbers)

        # Citation verdicts
        citation_accurate = sum(
            1 for r in results if r.citation_verdict == CitationVerdict.ACCURATE
        )
        citation_inaccurate = sum(
            1 for r in results if r.citation_verdict == CitationVerdict.INACCURATE
        )
        citation_partial = sum(
            1 for r in results if r.citation_verdict == CitationVerdict.PARTIAL
        )
        citation_not_found = sum(
            1 for r in results if r.citation_verdict == CitationVerdict.NOT_FOUND
        )
        citation_unavailable = sum(
            1 for r in results if r.citation_verdict == CitationVerdict.SOURCE_UNAVAILABLE
        )

        # Fact verdicts
        fact_verified = sum(
            1 for r in results if r.fact_verdict == FactVerdict.VERIFIED
        )
        fact_false = sum(
            1 for r in results if r.fact_verdict == FactVerdict.FALSE
        )
        fact_unverified = sum(
            1 for r in results if r.fact_verdict == FactVerdict.UNVERIFIED
        )
        fact_disputed = sum(
            1 for r in results if r.fact_verdict == FactVerdict.DISPUTED
        )

        # Combined status
        fully_verified = sum(
            1 for r in results if r.overall_status == "VERIFIED"
        )
        cited_but_false = sum(
            1 for r in results if r.overall_status == "CITED_BUT_FALSE"
        )
        miscited = sum(
            1 for r in results if r.overall_status == "MISCITED"
        )
        problematic = sum(
            1 for r in results if r.overall_status == "PROBLEMATIC"
        )

        # Rates
        citation_accuracy_rate = (
            (citation_accurate + citation_partial) / total if total > 0 else 0
        )
        verifiable_facts = fact_verified + fact_false
        fact_accuracy_rate = (
            fact_verified / verifiable_facts if verifiable_facts > 0 else 0
        )
        overall_accuracy_rate = fully_verified / total if total > 0 else 0

        # FaER: count of errors
        fact_error_count = fact_false
        unverifiable_count = fact_unverified

        # Exponential penalties:
        # - False facts: 0.5^n (each halves the score)
        # - Unverifiable: 0.75^n (each cuts 25%)
        false_penalty = 0.5 ** fact_error_count if fact_error_count > 0 else 1.0
        unverifiable_penalty = 0.75 ** unverifiable_count if unverifiable_count > 0 else 1.0
        combined_penalty = false_penalty * unverifiable_penalty

        return cls(
            total_claims=total,
            claims_with_citations=claims_with_citations,
            claims_without_citations=total - claims_with_citations,
            citation_accurate=citation_accurate,
            citation_inaccurate=citation_inaccurate,
            citation_partial=citation_partial,
            citation_not_found=citation_not_found,
            citation_unavailable=citation_unavailable,
            fact_verified=fact_verified,
            fact_false=fact_false,
            fact_unverified=fact_unverified,
            fact_disputed=fact_disputed,
            fully_verified=fully_verified,
            cited_but_false=cited_but_false,
            miscited=miscited,
            problematic=problematic,
            citation_accuracy_rate=citation_accuracy_rate,
            fact_accuracy_rate=fact_accuracy_rate,
            overall_accuracy_rate=overall_accuracy_rate,
            total_sources=len(source_result.sources),
            accessible_sources=source_result.accessible_count,
            inaccessible_sources=source_result.inaccessible_count,
            source_accessibility_rate=(
                source_result.accessible_count / len(source_result.sources)
                if source_result.sources
                else 0
            ),
            fact_error_count=fact_error_count,
            unverifiable_count=unverifiable_count,
            false_penalty=false_penalty,
            unverifiable_penalty=unverifiable_penalty,
            combined_penalty=combined_penalty,
        )


class InsightDetail(BaseModel):
    """A single Nth order insight extracted from the report."""

    text: str  # The insight text
    order: int  # Nth order (2, 3, 4, etc.)
    base_facts: list[str]  # Facts this insight is derived from
    reasoning: str  # Why this is an Nth order insight


class InsightAnalysis(BaseModel):
    """Analysis of Nth order insights in the report (separate from grade)."""

    total_insights: int
    average_order: float
    order_distribution: dict[int, int]  # order -> count
    insights: list[InsightDetail]


class EvaluationReport(BaseModel):
    """Complete fact-checking evaluation report."""

    # Metadata
    report_title: str
    evaluation_timestamp: str

    # Metrics
    faer_metrics: FaERMetrics

    # Quality dimensions
    quality_dimensions: list[QualityDimension]
    overall_quality_score: float = Field(ge=0.0, le=1.0)

    # Detailed results
    claim_verdicts: list[ClaimVerificationResult]
    source_verification: SourceVerificationResult

    # Insight analysis (separate from grade)
    insight_analysis: InsightAnalysis | None = None

    # Summary
    executive_summary: str
    recommendations: list[str]
