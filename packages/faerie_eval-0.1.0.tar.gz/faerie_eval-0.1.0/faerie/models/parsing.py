"""Models for report parsing."""

from pydantic import BaseModel


class Citation(BaseModel):
    """A citation reference in the report."""

    number: int  # Citation number [1], [2], etc.
    url: str  # URL from sources section
    title: str  # Title from sources section


class ParsedSection(BaseModel):
    """A section extracted from the report."""

    title: str  # Section heading
    level: int  # 1 for ##, 2 for ###
    content: str  # Raw markdown content
    citation_numbers: list[int] = []  # Citation numbers used in this section


class ParsedReport(BaseModel):
    """Complete parsed report structure."""

    title: str
    sections: list[ParsedSection]
    citations: list[Citation]
    raw_markdown: str
