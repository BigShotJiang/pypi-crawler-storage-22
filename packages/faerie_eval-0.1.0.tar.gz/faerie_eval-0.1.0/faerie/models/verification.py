"""Models for claim verification."""

from enum import Enum
from typing import Optional
from pydantic import BaseModel, Field

from faerie.models.claims import Verdict


class CitationVerdict(str, Enum):
    """Verdict for citation accuracy - does the source say what's claimed?"""

    ACCURATE = "ACCURATE"  # Source explicitly states the claim
    INACCURATE = "INACCURATE"  # Source does not state or contradicts the claim
    PARTIAL = "PARTIAL"  # Source partially supports the claim
    NOT_FOUND = "NOT_FOUND"  # Claim not found in source content
    SOURCE_UNAVAILABLE = "SOURCE_UNAVAILABLE"  # Could not access source


class FactVerdict(str, Enum):
    """Verdict for factual accuracy - is the claim actually true?"""

    VERIFIED = "VERIFIED"  # Independent sources confirm the claim
    FALSE = "FALSE"  # Independent sources contradict the claim
    UNVERIFIED = "UNVERIFIED"  # Could not find independent verification
    DISPUTED = "DISPUTED"  # Sources disagree on the claim


class SourceContent(BaseModel):
    """Fetched content from a source URL."""

    citation_number: int
    url: str
    title: str
    content: Optional[str] = None  # Fetched text content
    accessible: bool = False  # Whether URL was reachable
    fetch_error: Optional[str] = None  # Error message if fetch failed
    published_date: Optional[str] = None


class SourceVerificationResult(BaseModel):
    """Result of source URL verification."""

    sources: list[SourceContent]
    accessible_count: int
    inaccessible_count: int
    fabricated_urls: list[str] = []  # URLs that don't exist


class CitationCheckResult(BaseModel):
    """Result of checking if a citation accurately represents its source."""

    claim_id: str
    claim_text: str
    citation_verdict: CitationVerdict
    confidence: float = Field(ge=0.0, le=1.0)
    source_quote: Optional[str] = None  # Relevant quote from source
    reasoning: str
    sources_checked: list[int]


class FactCheckResult(BaseModel):
    """Result of independently verifying if a claim is factually true."""

    claim_id: str
    claim_text: str
    fact_verdict: FactVerdict
    confidence: float = Field(ge=0.0, le=1.0)
    supporting_sources: list[str] = []  # URLs that support the claim
    contradicting_sources: list[str] = []  # URLs that contradict
    evidence: Optional[str] = None  # Key evidence found
    reasoning: str


class ClaimVerificationResult(BaseModel):
    """Combined result of both citation and fact verification."""

    claim_id: str
    claim_text: str
    section_title: str
    citation_numbers: list[int]

    # Citation accuracy - does the source say this?
    citation_verdict: CitationVerdict
    citation_confidence: float = Field(ge=0.0, le=1.0)
    citation_evidence: Optional[str] = None
    citation_reasoning: str

    # Factual accuracy - is this actually true?
    fact_verdict: FactVerdict
    fact_confidence: float = Field(ge=0.0, le=1.0)
    fact_evidence: Optional[str] = None
    fact_sources: list[str] = []  # Independent sources checked
    fact_reasoning: str

    @property
    def is_well_cited(self) -> bool:
        """Claim is accurately represented by its citation."""
        return self.citation_verdict in (CitationVerdict.ACCURATE, CitationVerdict.PARTIAL)

    @property
    def is_factually_correct(self) -> bool:
        """Claim is factually true based on independent verification."""
        return self.fact_verdict == FactVerdict.VERIFIED

    @property
    def overall_status(self) -> str:
        """Human-readable overall status."""
        if self.is_well_cited and self.is_factually_correct:
            return "VERIFIED"
        elif self.is_well_cited and not self.is_factually_correct:
            return "CITED_BUT_FALSE"
        elif not self.is_well_cited and self.is_factually_correct:
            return "MISCITED"
        else:
            return "PROBLEMATIC"
