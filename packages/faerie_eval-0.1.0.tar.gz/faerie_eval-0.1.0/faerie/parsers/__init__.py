"""Report parsing utilities."""

from faerie.parsers.markdown_parser import parse_report

__all__ = ["parse_report"]
