"""Markdown report parser."""

import re
from faerie.models.parsing import ParsedReport, ParsedSection, Citation


def extract_citations_from_text(text: str) -> list[int]:
    """Extract citation numbers from text like [1], [2, 3], [1, 2, 5]."""
    citation_pattern = r"\[(\d+(?:,\s*\d+)*)\]"
    matches = re.findall(citation_pattern, text)

    numbers = []
    for match in matches:
        # Split on comma and convert to integers
        nums = [int(n.strip()) for n in match.split(",")]
        numbers.extend(nums)

    return sorted(set(numbers))


def parse_sources_section(content: str) -> list[Citation]:
    """Parse the sources section to extract citations.

    Expected format:
    1. [Title](URL)
    2. [Another Title](URL)
    """
    citations = []

    # Pattern: number. [title](url)
    source_pattern = r"(\d+)\.\s*\[([^\]]+)\]\(([^)]+)\)"
    matches = re.findall(source_pattern, content)

    for num, title, url in matches:
        citations.append(
            Citation(
                number=int(num),
                title=title.strip(),
                url=url.strip(),
            )
        )

    return citations


def parse_report(markdown: str) -> ParsedReport:
    """Parse a markdown report into structured format.

    Args:
        markdown: Raw markdown content of the report

    Returns:
        ParsedReport with title, sections, and citations
    """
    lines = markdown.split("\n")
    title = ""
    sections: list[ParsedSection] = []
    citations: list[Citation] = []

    current_section: dict | None = None
    current_content_lines: list[str] = []
    in_sources_section = False
    sources_content_lines: list[str] = []

    for line in lines:
        # Extract title (first # heading)
        if line.startswith("# ") and not title:
            title = line[2:].strip()
            continue

        # Check for sources section
        if line.strip().lower() in ["## sources", "## references"]:
            # Save current section if exists
            if current_section:
                content = "\n".join(current_content_lines).strip()
                sections.append(
                    ParsedSection(
                        title=current_section["title"],
                        level=current_section["level"],
                        content=content,
                        citation_numbers=extract_citations_from_text(content),
                    )
                )
                current_section = None
                current_content_lines = []

            in_sources_section = True
            continue

        # Collect sources content
        if in_sources_section:
            sources_content_lines.append(line)
            continue

        # Check for ## section heading
        if line.startswith("## "):
            # Save previous section
            if current_section:
                content = "\n".join(current_content_lines).strip()
                sections.append(
                    ParsedSection(
                        title=current_section["title"],
                        level=current_section["level"],
                        content=content,
                        citation_numbers=extract_citations_from_text(content),
                    )
                )

            current_section = {"title": line[3:].strip(), "level": 1}
            current_content_lines = []
            continue

        # Check for ### subsection heading
        if line.startswith("### "):
            # Save previous section
            if current_section:
                content = "\n".join(current_content_lines).strip()
                sections.append(
                    ParsedSection(
                        title=current_section["title"],
                        level=current_section["level"],
                        content=content,
                        citation_numbers=extract_citations_from_text(content),
                    )
                )

            current_section = {"title": line[4:].strip(), "level": 2}
            current_content_lines = []
            continue

        # Collect content for current section
        if current_section:
            current_content_lines.append(line)

    # Don't forget the last section
    if current_section and not in_sources_section:
        content = "\n".join(current_content_lines).strip()
        sections.append(
            ParsedSection(
                title=current_section["title"],
                level=current_section["level"],
                content=content,
                citation_numbers=extract_citations_from_text(content),
            )
        )

    # Parse sources
    if sources_content_lines:
        sources_content = "\n".join(sources_content_lines)
        citations = parse_sources_section(sources_content)

    return ParsedReport(
        title=title,
        sections=sections,
        citations=citations,
        raw_markdown=markdown,
    )
