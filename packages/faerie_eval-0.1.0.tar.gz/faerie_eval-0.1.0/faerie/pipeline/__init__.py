"""Evaluation pipeline."""

from faerie.pipeline.evaluator import FaerieEvaluator

__all__ = ["FaerieEvaluator"]
