"""Main Faerie evaluation pipeline."""

import sys
from datetime import datetime
from typing import Optional

from faerie.models.parsing import ParsedReport
from faerie.models.claims import ExtractedClaim, ClaimExtractionOutput
from faerie.models.verification import (
    SourceContent,
    SourceVerificationResult,
    ClaimVerificationResult,
)
from faerie.models.evaluation import FaERMetrics, EvaluationReport, QualityDimension, InsightAnalysis, InsightDetail
from faerie.parsers.markdown_parser import parse_report
from faerie.tools.exa_search import verify_sources
from faerie.agents.claim_extractor import extract_claims
from faerie.agents.claim_verifier import verify_claims
from faerie.agents.quality_judge import assess_quality, QualityAssessment
from faerie.agents.insight_extractor import extract_insights


class FaerieEvaluator:
    """Main evaluation pipeline for fact-checking research reports."""

    def __init__(
        self,
        model: str = "gemini-3-flash-preview",
        skip_fact_check: bool = False,
        skip_insights: bool = False,
        max_workers: int = 3,
        verbose: bool = False,
    ):
        """Initialize the evaluator.

        Args:
            model: LLM model to use for verification
            skip_fact_check: If True, skip independent fact verification (faster)
            skip_insights: If True, skip insight extraction
            max_workers: Max parallel verifications
            verbose: Print progress to stderr
        """
        self.model = model
        self.skip_fact_check = skip_fact_check
        self.skip_insights = skip_insights
        self.max_workers = max_workers
        self.verbose = verbose

    def _log(self, message: str):
        """Log a message if verbose mode is enabled."""
        if self.verbose:
            print(message, file=sys.stderr)

    def evaluate(self, markdown: str) -> EvaluationReport:
        """Evaluate a research report.

        Args:
            markdown: Raw markdown content of the report

        Returns:
            Complete EvaluationReport with metrics and verdicts
        """
        start_time = datetime.now()
        self._log(f"Starting evaluation at {start_time.strftime('%H:%M:%S')}")

        # Step 1: Parse the report
        self._log("\n[1/7] Parsing report...")
        parsed = parse_report(markdown)
        self._log(f"  Found {len(parsed.sections)} sections, {len(parsed.citations)} citations")

        # Step 2: Verify sources (fetch content)
        self._log("\n[2/7] Verifying sources...")
        source_result = verify_sources(parsed.citations)
        self._log(
            f"  Accessible: {source_result.accessible_count}/{len(source_result.sources)}"
        )

        # Build source content map
        source_contents: dict[int, SourceContent] = {
            src.citation_number: src for src in source_result.sources
        }

        # Step 3: Extract claims
        self._log("\n[3/7] Extracting claims...")
        extraction = extract_claims(parsed.sections, self.model, self.verbose)
        self._log(
            f"  Found {extraction.total_claims} claims "
            f"({extraction.claims_with_citations} with citations)"
        )

        # Step 4: Verify claims
        self._log("\n[4/7] Verifying claims...")
        if self.skip_fact_check:
            self._log("  (Skipping independent fact verification)")

        verdicts = verify_claims(
            extraction.claims,
            source_contents,
            self.model,
            self.skip_fact_check,
            self.max_workers,
            self.verbose,
        )

        # Step 5: Calculate metrics
        self._log("\n[5/7] Calculating metrics...")
        metrics = FaERMetrics.from_results(verdicts, source_result)

        # Calculate quality dimensions
        quality_dimensions = self._calculate_quality_dimensions(metrics)

        # Step 6: Assess quality (structure + thoroughness) via LLM judge
        self._log("\n[6/7] Assessing report quality...")
        quality = assess_quality(
            report_content=markdown,
            section_titles=[s.title for s in parsed.sections],
            model=self.model,
            verbose=self.verbose,
        )
        structure_score = quality.structure_score / 100  # Convert to 0-1
        thoroughness_score = quality.thoroughness_score / 100
        self._log(f"  Structure: {quality.structure_score:.0f}/100 - {quality.structure_reasoning}")
        self._log(f"  Thoroughness: {quality.thoroughness_score:.0f}/100 - {quality.thoroughness_reasoning}")

        # Update metrics with quality scores
        metrics = metrics.model_copy(update={
            "structure_score": structure_score,
            "thoroughness_score": thoroughness_score,
            "structure_reasoning": quality.structure_reasoning,
            "thoroughness_reasoning": quality.thoroughness_reasoning,
        })

        # Calculate overall score with FaER penalty system:
        # - 30% citation accuracy
        # - 60% factual correctness (with exponential penalties)
        # - 5% structure/organization
        # - 5% thoroughness/depth
        base_content_score = (
            0.30 * metrics.citation_accuracy_rate +
            0.60 * metrics.fact_accuracy_rate +
            0.05 * structure_score +
            0.05 * thoroughness_score
        )

        # Apply exponential penalties for errors
        # False facts: 0.5^n (each halves the score)
        # Unverifiable: 0.75^n (each cuts 25%)
        overall_score = base_content_score * metrics.combined_penalty

        # Log penalty info if there are errors
        if metrics.fact_error_count > 0 or metrics.unverifiable_count > 0:
            self._log(f"  Penalties applied:")
            if metrics.fact_error_count > 0:
                self._log(f"    False facts ({metrics.fact_error_count}): ×{metrics.false_penalty:.0%}")
            if metrics.unverifiable_count > 0:
                self._log(f"    Unverifiable ({metrics.unverifiable_count}): ×{metrics.unverifiable_penalty:.0%}")
            self._log(f"    Combined penalty: ×{metrics.combined_penalty:.0%}")
            self._log(f"    Base score: {base_content_score:.0%} → Final: {overall_score:.0%}")

        # Generate summary
        summary, recommendations = self._generate_summary(metrics, verdicts)

        # Step 7: Extract insights (separate from grade)
        insight_analysis = None
        if not self.skip_insights:
            self._log("\n[7/7] Extracting insights...")
            insights = extract_insights(
                markdown,
                model="claude-sonnet-4-5-20250929",
                verbose=self.verbose,
            )
            if insights:
                order_distribution = {}
                for insight in insights:
                    order_distribution[insight.order] = order_distribution.get(insight.order, 0) + 1

                insight_analysis = InsightAnalysis(
                    total_insights=len(insights),
                    average_order=sum(i.order for i in insights) / len(insights),
                    order_distribution=order_distribution,
                    insights=[
                        InsightDetail(
                            text=i.text,
                            order=i.order,
                            base_facts=i.base_facts,
                            reasoning=i.reasoning,
                        )
                        for i in insights
                    ],
                )
                self._log(f"  Found {len(insights)} insights (avg order: {insight_analysis.average_order:.1f})")
            else:
                self._log("  No insights found")
        else:
            self._log("\n[7/7] Skipping insight extraction")

        elapsed = (datetime.now() - start_time).total_seconds()
        self._log(f"\nEvaluation complete in {elapsed:.1f}s")

        return EvaluationReport(
            report_title=parsed.title,
            evaluation_timestamp=datetime.now().isoformat(),
            faer_metrics=metrics,
            quality_dimensions=quality_dimensions,
            overall_quality_score=overall_score,
            claim_verdicts=verdicts,
            source_verification=source_result,
            insight_analysis=insight_analysis,
            executive_summary=summary,
            recommendations=recommendations,
        )

    def _calculate_quality_dimensions(
        self, metrics: FaERMetrics
    ) -> list[QualityDimension]:
        """Calculate quality dimension scores."""
        return [
            QualityDimension(
                name="Source Accessibility",
                score=metrics.source_accessibility_rate,
                description="Proportion of cited sources that are accessible",
                details=f"{metrics.accessible_sources}/{metrics.total_sources} sources accessible",
            ),
            QualityDimension(
                name="Citation Accuracy",
                score=metrics.citation_accuracy_rate,
                description="Proportion of claims accurately represented by their citations",
                details=f"{metrics.citation_accurate + metrics.citation_partial}/{metrics.total_claims} citations accurate or partial",
            ),
            QualityDimension(
                name="Factual Accuracy",
                score=metrics.fact_accuracy_rate,
                description="Proportion of verifiable claims that are factually correct",
                details=f"{metrics.fact_verified}/{metrics.fact_verified + metrics.fact_false} facts verified",
            ),
            QualityDimension(
                name="Overall Verification",
                score=metrics.overall_accuracy_rate,
                description="Proportion of claims that are both well-cited AND factually correct",
                details=f"{metrics.fully_verified}/{metrics.total_claims} fully verified",
            ),
        ]

    def _generate_summary(
        self,
        metrics: FaERMetrics,
        verdicts: list[ClaimVerificationResult],
    ) -> tuple[str, list[str]]:
        """Generate executive summary and recommendations."""
        # Build summary
        summary_parts = []

        summary_parts.append(
            f"This report contains {metrics.total_claims} verifiable claims, "
            f"of which {metrics.claims_with_citations} have citations."
        )

        # Citation accuracy summary
        if metrics.citation_accuracy_rate >= 0.8:
            summary_parts.append(
                f"Citation accuracy is strong at {metrics.citation_accuracy_rate:.0%}, "
                f"with {metrics.citation_accurate} claims accurately citing their sources."
            )
        elif metrics.citation_accuracy_rate >= 0.5:
            summary_parts.append(
                f"Citation accuracy is moderate at {metrics.citation_accuracy_rate:.0%}. "
                f"{metrics.citation_inaccurate} claims do not accurately represent their sources."
            )
        else:
            summary_parts.append(
                f"Citation accuracy is concerning at {metrics.citation_accuracy_rate:.0%}. "
                f"Many claims do not accurately represent their cited sources."
            )

        # Fact accuracy summary
        if metrics.fact_verified + metrics.fact_false > 0:
            if metrics.fact_accuracy_rate >= 0.8:
                summary_parts.append(
                    f"Factual accuracy is high at {metrics.fact_accuracy_rate:.0%}."
                )
            elif metrics.fact_accuracy_rate >= 0.5:
                summary_parts.append(
                    f"Factual accuracy is moderate at {metrics.fact_accuracy_rate:.0%}. "
                    f"{metrics.fact_false} claims appear to be factually incorrect."
                )
            else:
                summary_parts.append(
                    f"Factual accuracy is low at {metrics.fact_accuracy_rate:.0%}. "
                    f"Significant fact-checking concerns were identified."
                )

        # Overall verdict
        if metrics.overall_accuracy_rate >= 0.7:
            summary_parts.append(
                f"Overall, {metrics.fully_verified} claims ({metrics.overall_accuracy_rate:.0%}) "
                f"are both well-cited and factually verified."
            )
        else:
            summary_parts.append(
                f"Only {metrics.fully_verified} claims ({metrics.overall_accuracy_rate:.0%}) "
                f"could be fully verified as both well-cited and factually accurate."
            )

        summary = " ".join(summary_parts)

        # Generate recommendations
        recommendations = []

        if metrics.inaccessible_sources > 0:
            recommendations.append(
                f"Replace {metrics.inaccessible_sources} inaccessible source URLs with working links"
            )

        if metrics.citation_inaccurate > 0:
            recommendations.append(
                f"Review {metrics.citation_inaccurate} claims that don't accurately represent their sources"
            )

        if metrics.citation_not_found > 0:
            recommendations.append(
                f"Add citations for {metrics.citation_not_found} claims not found in cited sources"
            )

        if metrics.fact_false > 0:
            recommendations.append(
                f"Verify and correct {metrics.fact_false} claims that appear factually incorrect"
            )

        if metrics.miscited > 0:
            recommendations.append(
                f"Fix citations for {metrics.miscited} claims that are true but miscited"
            )

        if metrics.cited_but_false > 0:
            recommendations.append(
                f"Investigate {metrics.cited_but_false} claims where the cited source may be incorrect"
            )

        if not recommendations:
            recommendations.append("Report passes fact-checking with no major issues identified")

        return summary, recommendations

    def evaluate_file(self, filepath: str) -> EvaluationReport:
        """Evaluate a report from a file path.

        Args:
            filepath: Path to the markdown file

        Returns:
            EvaluationReport
        """
        with open(filepath, "r", encoding="utf-8") as f:
            markdown = f.read()
        return self.evaluate(markdown)
