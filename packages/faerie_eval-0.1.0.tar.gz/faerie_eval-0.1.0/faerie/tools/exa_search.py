"""Exa API tools for source verification."""

import os
import requests
from typing import Optional
from concurrent.futures import ThreadPoolExecutor, as_completed

from faerie.models.parsing import Citation
from faerie.models.verification import SourceContent, SourceVerificationResult


def fetch_source_content(
    url: str,
    citation_number: int,
    title: str,
    api_key: Optional[str] = None,
) -> SourceContent:
    """Fetch content from a URL using Exa API.

    Args:
        url: The source URL to fetch
        citation_number: The citation number in the report
        title: The title of the source
        api_key: Exa API key (defaults to EXA_API_KEY env var)

    Returns:
        SourceContent with fetched content or error
    """
    api_key = api_key or os.environ.get("EXA_API_KEY")

    if not api_key:
        return SourceContent(
            citation_number=citation_number,
            url=url,
            title=title,
            accessible=False,
            fetch_error="EXA_API_KEY not set",
        )

    try:
        # Use Exa's contents endpoint to fetch page content
        response = requests.post(
            "https://api.exa.ai/contents",
            headers={
                "x-api-key": api_key,
                "Content-Type": "application/json",
            },
            json={
                "urls": [url],
                "text": True,
            },
            timeout=30,
        )

        if response.status_code == 200:
            data = response.json()
            results = data.get("results", [])

            if results:
                result = results[0]
                text = result.get("text", "")
                published_date = result.get("publishedDate")

                return SourceContent(
                    citation_number=citation_number,
                    url=url,
                    title=title,
                    content=text[:10000] if text else None,  # Limit content size
                    accessible=True,
                    published_date=published_date,
                )
            else:
                return SourceContent(
                    citation_number=citation_number,
                    url=url,
                    title=title,
                    accessible=False,
                    fetch_error="No content returned from Exa",
                )
        else:
            return SourceContent(
                citation_number=citation_number,
                url=url,
                title=title,
                accessible=False,
                fetch_error=f"HTTP {response.status_code}: {response.text[:200]}",
            )

    except requests.exceptions.Timeout:
        return SourceContent(
            citation_number=citation_number,
            url=url,
            title=title,
            accessible=False,
            fetch_error="Request timeout",
        )
    except requests.exceptions.RequestException as e:
        return SourceContent(
            citation_number=citation_number,
            url=url,
            title=title,
            accessible=False,
            fetch_error=str(e),
        )


def verify_sources(
    citations: list[Citation],
    api_key: Optional[str] = None,
    max_workers: int = 5,
) -> SourceVerificationResult:
    """Verify all source URLs and fetch their content.

    Args:
        citations: List of citations to verify
        api_key: Exa API key (defaults to EXA_API_KEY env var)
        max_workers: Max parallel requests

    Returns:
        SourceVerificationResult with all source contents
    """
    sources: list[SourceContent] = []
    fabricated_urls: list[str] = []

    # Fetch all sources in parallel
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {
            executor.submit(
                fetch_source_content,
                citation.url,
                citation.number,
                citation.title,
                api_key,
            ): citation
            for citation in citations
        }

        for future in as_completed(futures):
            citation = futures[future]
            try:
                source = future.result()
                sources.append(source)

                if not source.accessible:
                    fabricated_urls.append(source.url)

            except Exception as e:
                sources.append(
                    SourceContent(
                        citation_number=citation.number,
                        url=citation.url,
                        title=citation.title,
                        accessible=False,
                        fetch_error=str(e),
                    )
                )
                fabricated_urls.append(citation.url)

    # Sort by citation number
    sources.sort(key=lambda s: s.citation_number)

    accessible_count = sum(1 for s in sources if s.accessible)
    inaccessible_count = len(sources) - accessible_count

    return SourceVerificationResult(
        sources=sources,
        accessible_count=accessible_count,
        inaccessible_count=inaccessible_count,
        fabricated_urls=fabricated_urls,
    )
