-- Rename recorded column to result
ALTER TABLE fairchild_jobs RENAME COLUMN recorded TO result;
