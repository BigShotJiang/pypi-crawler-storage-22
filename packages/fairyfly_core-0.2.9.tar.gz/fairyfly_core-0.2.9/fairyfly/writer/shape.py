"""Shape Writer.

Note to developers:
Use this module to extend fairyfly's Shape writer for new extensions.
(eg. adding `therm` to this module adds the method `Shape.to.therm`)
"""
