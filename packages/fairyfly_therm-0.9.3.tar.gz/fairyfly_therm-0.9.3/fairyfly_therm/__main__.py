from fairyfly_therm.cli import therm

if __name__ == '__main__':
    therm()
