---
orphan: true
---

# Release Notes

```{include} ../CHANGELOG.md
:start-line: 2
```
