__all__ = ["PLUGIN_ID"]
PLUGIN_ID = "sample"
