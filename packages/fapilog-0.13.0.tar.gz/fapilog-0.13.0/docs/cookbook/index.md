# Cookbook

Practical solutions to common logging problems. Each recipe is self-contained with copy-pasteable code.

```{toctree}
:maxdepth: 1
:titlesonly:
:caption: Cookbook

fastapi-microservice-production
fastapi-json-logging
fastapi-request-id-logging
django-structured-logging
non-blocking-async-logging
dev-prod-logging-config
redacting-secrets-pii
compliance-redaction
safe-request-response-logging
skip-noisy-endpoints
log-sampling-rate-limiting
adaptive-sampling-high-volume
graceful-shutdown-flush
exception-logging-request-context
custom-log-levels
```

## Getting Started with Fapilog

New to fapilog? Start here:

- [Why Fapilog?](../why-fapilog.md) - Is fapilog right for your project?
- [Quickstart](../getting-started/quickstart.md) - Install and run in 2 minutes
- [Core Concepts](../core-concepts/index.md) - How the async pipeline works
- [Comparisons](../comparisons.md) - fapilog vs structlog, loguru, stdlib
