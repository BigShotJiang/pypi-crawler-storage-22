# License & Credits

- License: Apache 2.0 (see LICENSE in the repository root).
- Author: Chris Haste and contributors.
- Thanks to the open-source community for libraries leveraged by fapilog (e.g., asyncio, pydantic).
