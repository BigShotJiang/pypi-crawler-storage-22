# Integration Patterns

Reusable patterns for building sinks, processors, and enrichers.

```{toctree}
:maxdepth: 1
:titlesonly:

patterns/sdk-sinks
patterns/http-sinks
```
