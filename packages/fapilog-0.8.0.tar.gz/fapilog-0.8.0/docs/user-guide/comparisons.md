---
orphan: true
---

# Comparisons

```{note}
This page has moved to [Python Logging Library Comparison](../comparisons.md).
```

For a comprehensive comparison of fapilog with structlog, loguru, stdlib logging, and OpenTelemetry, see the **[main comparisons page](../comparisons.md)**.
