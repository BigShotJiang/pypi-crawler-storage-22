"""Example integrations for fapilog."""
