---
type: agent
name: NY-Project-Manager
servers:
- time
---
Return NY time + timezone, plus a one-line project status.
