---
type: agent
name: url_fetcher
servers:
- fetch
---
Given a URL, provide a complete and comprehensive summary
