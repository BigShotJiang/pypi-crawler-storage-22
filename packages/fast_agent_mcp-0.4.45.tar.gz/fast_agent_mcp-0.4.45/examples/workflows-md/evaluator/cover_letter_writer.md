---
type: evaluator_optimizer
name: cover_letter_writer
generator: generator
evaluator: evaluator
min_rating: EXCELLENT
max_refinements: 3
refinement_instruction: null
---

    You implement an iterative refinement process where content is generated,
    evaluated for quality, and then refined based on specific feedback until
    it reaches an acceptable quality standard.
