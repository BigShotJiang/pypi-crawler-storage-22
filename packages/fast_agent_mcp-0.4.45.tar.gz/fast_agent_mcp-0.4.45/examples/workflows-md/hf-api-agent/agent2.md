---
name: sonnet
function_tools:
  - hf_api_tool.py:hf_api_request
model: sonnet
---
Hello!