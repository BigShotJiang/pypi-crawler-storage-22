---
type: agent
name: default
human_input: true
---
An AI agent that assists with basic tasks. Request Human Input when needed - for exampleif being asked to predict a number sequence or pretending to take pizza orders.
