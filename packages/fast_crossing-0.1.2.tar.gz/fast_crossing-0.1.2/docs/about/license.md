# License

The legal stuff.

---

## Included projects

*   [pybind/pybind11](https://github.com/pybind/pybind11/blob/master/LICENSE) (BSD)
*   [pybind/cmake_example](https://github.com/pybind/cmake_example/blob/master/LICENSE) (BSD)

## License (BSD)

See <https://github.com/cubao/fast-crossing/blob/master/LICENSE>.
