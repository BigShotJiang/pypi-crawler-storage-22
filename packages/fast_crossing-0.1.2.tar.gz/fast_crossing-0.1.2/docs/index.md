# fast-crossing

![](fast-crossing.png)

![](https://cubao.readthedocs.io/en/latest/notebooks/fast-crossing.gif)

(See jupyter notebook [here](https://github.com/cubao/index/blob/master/docs/notebooks/fast-crossing.ipynb))

{%
   include-markdown "../README.md"
   start="<!--intro-start-->"
   end="<!--intro-end-->"
%}

<div class="text-center">
<a href="https://github.com/cubao/fast-crossing" class="btn btn-primary" role="button">Code on GitHub</a>
<a href="https://pypi.org/project/fast-crossing" class="btn btn-primary" role="button">Package on PyPi</a>
</div>
