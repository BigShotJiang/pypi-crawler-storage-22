# polyline-in-polygon

code:

-   <https://github.com/cubao/fast-crossing/blob/master/scripts/debug_polyline_in_polygon.py>

video:

-   <https://www.bilibili.com/video/BV1D24y1u7uB>
-   <https://www.youtube.com/watch?v=1dPJ3P84FxE>

```python
{%
   include-markdown "../scripts/debug_polyline_in_polygon.py"
   comments=false
%}
```
