# Usage

## test_basic.py

```python
{%
    include-markdown "../tests/test_basic.py"
    comments=false
%}
```
