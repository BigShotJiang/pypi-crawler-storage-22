import asyncio
import os

from faststream.rabbit import RabbitBroker
from httpx import AsyncClient


async def main():
    queue = "foo"
    broker_url = (
        f"amqp://{os.getenv('RABBITMQ_DEFAULT_USER')}:{os.getenv('RABBITMQ_DEFAULT_PASS')}"
        f"@{os.getenv('RABBITMQ_DEFAULT_HOST')}:{os.getenv('RABBITMQ_DEFAULT_PORT')}/"
    )
    broker = RabbitBroker(broker_url)
    fastapi_url = os.getenv("FASTAPI_URL")
    async with AsyncClient(base_url=fastapi_url) as client:
        async with broker:
            await broker.start()
            i = 0
            while True:
                message = {"Hello": "World", "message_number": i}
                print("Send message", message)
                await client.post("/foo", json=message)
                await broker.publish(message, queue)
                i += 1
                print("Sleep...")
                await asyncio.sleep(1)


if __name__ == "__main__":
    asyncio.run(main())
