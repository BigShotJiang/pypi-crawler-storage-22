from dishka import Provider, Scope, provide

from fast_telemetry.core import PrometheusMetric, MetricsCollector, MetricsExporter


class MetricsProvider(Provider):
    scope = Scope.APP

    @provide
    def get_metrics_impl(self) -> PrometheusMetric:
        return PrometheusMetric(service_name="payment_service", version="1.0.0", env="production")

    @provide
    def get_collector(self, metrics: PrometheusMetric) -> MetricsCollector:
        return metrics

    @provide
    def get_exporter(self, metrics: PrometheusMetric) -> MetricsExporter:
        return metrics
