import logging

logger = logging.getLogger("fast-telemetry")
