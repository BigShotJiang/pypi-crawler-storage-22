"""FastAPI Anchor: session-based auth with cookie and server-side invalidation (real logout)."""
__version__ = "0.1.1"

from fastapi_anchor.backends.session_backend import BackendError, SessionBackend
from fastapi_anchor.frontends.session_frontend import FrontendError, SessionFrontend
from fastapi_anchor.session_verifier import SessionVerifier

__all__ = [
    "__version__",
    "BackendError",
    "SessionBackend",
    "SessionVerifier",
    "SessionFrontend",
    "FrontendError",
]
