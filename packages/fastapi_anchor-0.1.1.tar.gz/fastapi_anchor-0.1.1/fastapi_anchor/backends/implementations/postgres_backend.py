"""PostgreSQL session backend. Session in DB = real logout (invalidate on server)."""
from datetime import datetime, timezone
from typing import Optional
from uuid import UUID

from fastapi_anchor.backends.session_backend import BackendError, SessionBackend
from fastapi_anchor.frontends.session_frontend import ID
from pydantic import BaseModel
from sqlalchemy import Column, DateTime, MetaData, String, Table, delete, select
from sqlalchemy.dialects.postgresql import UUID as PG_UUID
from sqlalchemy.ext.asyncio import async_sessionmaker

# Session data model for auth: user_id + expiry (so we can invalidate on logout)
SessionModel = BaseModel


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


class SessionData(BaseModel):
    """Default session payload: user_id and expiry. Used by PostgresBackend."""
    user_id: str
    expires_at: datetime
    created_at: datetime


def anchor_sessions_table(metadata: MetaData) -> Table:
    """Create the anchor_sessions table. Add to your MetaData and call metadata.create_all(engine)."""
    return Table(
        "anchor_sessions",
        metadata,
        Column("id", PG_UUID(as_uuid=True), primary_key=True),
        Column("user_id", String(255), nullable=False, index=True),
        Column("expires_at", DateTime(timezone=True), nullable=False),
        Column("created_at", DateTime(timezone=True), nullable=False),
    )


class PostgresBackend(SessionBackend[UUID, SessionData]):
    """Stores sessions in PostgreSQL. Invalidate on logout = delete row."""

    def __init__(
        self,
        async_session_factory: async_sessionmaker,
        *,
        table: Table,
        expire_seconds: int = 14 * 24 * 60 * 60,
    ):
        """
        Args:
            async_session_factory: sqlalchemy.ext.asyncio async_sessionmaker(engine, class_=AsyncSession, ...).
            table: SQLAlchemy Table from anchor_sessions_table(metadata).
            expire_seconds: Default TTL for new sessions (e.g. 14 days).
        """
        self._session_factory = async_session_factory
        self._table = table
        self._expire_seconds = expire_seconds

    async def create(self, session_id: ID, data: SessionData) -> None:
        tbl = self._table
        async with self._session_factory() as session:
            stmt = tbl.insert().values(
                id=session_id,
                user_id=data.user_id,
                expires_at=data.expires_at,
                created_at=data.created_at,
            )
            try:
                await session.execute(stmt)
                await session.commit()
            except Exception as e:
                await session.rollback()
                if "unique" in str(e).lower() or "duplicate" in str(e).lower():
                    raise BackendError("create can't overwrite an existing session") from e
                raise

    async def read(self, session_id: ID) -> Optional[SessionData]:
        tbl = self._table
        async with self._session_factory() as session:
            stmt = select(tbl).where(tbl.c.id == session_id)
            result = await session.execute(stmt)
            row = result.first()
            if row is None:
                return None
            now = _utc_now()
            exp = row.expires_at
            if exp.tzinfo is None:
                exp = exp.replace(tzinfo=timezone.utc)
            if exp < now:
                return None
            return SessionData(
                user_id=row.user_id,
                expires_at=row.expires_at,
                created_at=row.created_at,
            )

    async def update(self, session_id: ID, data: SessionData) -> None:
        tbl = self._table
        async with self._session_factory() as session:
            stmt = tbl.update().where(tbl.c.id == session_id).values(
                user_id=data.user_id,
                expires_at=data.expires_at,
                created_at=data.created_at,
            )
            result = await session.execute(stmt)
            await session.commit()
            if result.rowcount == 0:
                raise BackendError("session does not exist, cannot update")

    async def delete(self, session_id: ID) -> None:
        tbl = self._table
        async with self._session_factory() as session:
            await session.execute(delete(tbl).where(tbl.c.id == session_id))
            await session.commit()
