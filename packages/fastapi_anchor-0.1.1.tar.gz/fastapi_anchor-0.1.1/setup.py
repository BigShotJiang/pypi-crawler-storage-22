from setuptools import find_packages, setup

setup(
    name="fastapi-anchor",
    packages=find_packages(),
    version="0.1.1",
    license="MIT",
    description="Session-based auth for FastAPI: cookie + DB storage, real logout",
    long_description=open("readme.md", encoding="utf-8").read(),
    author="Andre Ahlert",
    url="https://github.com/andreahlert/fastapi-anchor",
    install_requires=["fastapi>=0.100", "itsdangerous>=2.0", "pydantic>=2.0"],
    extras_require={
        "postgres": ["sqlalchemy[asyncio]>=2.0", "asyncpg"],
    },
    python_requires=">=3.10",
)
