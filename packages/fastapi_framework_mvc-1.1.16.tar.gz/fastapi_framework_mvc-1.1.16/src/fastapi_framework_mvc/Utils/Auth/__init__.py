# coding: utf-8


__author__ = "Frederick NEY"

from .decorators import admin_login_required
