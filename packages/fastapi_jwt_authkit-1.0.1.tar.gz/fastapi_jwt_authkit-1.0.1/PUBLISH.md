# Publishing to PyPI with uv

## Prerequisites

1. Build the package first:
```bash
uv build
```

This creates distribution files in the `dist/` directory.

## Method 1: Using Token Directly (Recommended)

### Production PyPI:
```bash
uv publish --token pypi-AgEIcHlwaS5vcmcCJDY0NTQ1OTk2LTkzY2EtNGE4NS04NzMzLWY3NmQ1NjhmNGU3NAACKlszLCIyNGVkZWIxOS03MTBlLTQ2NTEtYjNjOC0xYTJhMGJhZTZlNjAiXQAABiBF_426wAtFA2Teg6I3xeKwOb2-1FiGG4C7p3o77h5uxQN
```

### TestPyPI:
```bash
uv publish --publish-url https://test.pypi.org/legacy/ --token pypi-AgEIcHlwaS5vcmcCJDY0NTQ1OTk2LTkzY2EtNGE4NS04NzMzLWY3NmQ1NjhmNGU3NAACKlszLCIyNGVkZWIxOS03MTBlLTQ2NTEtYjNjOC0xYTJhMGJhZTZlNjAiXQAABiBF_426wAtFA2Teg6I3xeKwOb2-1FiGG4C7p3o77h5uxQ
```

## Method 2: Using Environment Variables

Set environment variables and run:

### Windows PowerShell:
```powershell
$env:UV_PUBLISH_TOKEN="pypi-AgEIcHlwaS5vcmcCJDY0NTQ1OTk2LTkzY2EtNGE4NS04NzMzLWY3NmQ1NjhmNGU3NAACKlszLCIyNGVkZWIxOS03MTBlLTQ2NTEtYjNjOC0xYTJhMGJhZTZlNjAiXQAABiBF_426wAtFA2Teg6I3xeKwOb2-1FiGG4C7p3o77h5uxQN"
uv publish
```

### Windows CMD:
```cmd
set UV_PUBLISH_TOKEN=pypi-AgEIcHlwaS5vcmcCJDY0NTQ1OTk2LTkzY2EtNGE4NS04NzMzLWY3NmQ1NjhmNGU3NAACKlszLCIyNGVkZWIxOS03MTBlLTQ2NTEtYjNjOC0xYTJhMGJhZTZlNjAiXQAABiBF_426wAtFA2Teg6I3xeKwOb2-1FiGG4C7p3o77h5uxQN
uv publish
```

## Method 3: Build and Publish in One Step

`uv publish` can build and publish automatically:

```bash
uv publish --token pypi-AgEIcHlwaS5vcmcCJDY0NTQ1OTk2LTkzY2EtNGE4NS04NzMzLWY3NmQ1NjhmNGU3NAACKlszLCIyNGVkZWIxOS03MTBlLTQ2NTEtYjNjOC0xYTJhMGJhZTZlNjAiXQAABiBF_426wAtFA2Teg6I3xeKwOb2-1FiGG4C7p3o77h5uxQN
```

## Dry Run (Test Without Uploading)

Test the upload without actually publishing:

```bash
uv publish --dry-run --token pypi-AgEIcHlwaS5vcmcCJDY0NTQ1OTk2LTkzY2EtNGE4NS04NzMzLWY3NmQ1NjhmNGU3NAACKlszLCIyNGVkZWIxOS03MTBlLTQ2NTEtYjNjOC0xYTJhMGJhZTZlNjAiXQAABiBF_426wAtFA2Teg6I3xeKwOb2-1FiGG4C7p3o77h5uxQN
```

## Notes

- `uv publish` by default uploads all files in `dist/` directory
- Make sure to increment the version in `pyproject.toml` before publishing
- The token in `.pypirc` is for `twine`, not `uv`. Use the token directly with `uv publish`
- For security, consider using environment variables instead of passing tokens on command line

## Complete Workflow

```bash
# 1. Update version in pyproject.toml (if needed)
# 2. Build the package
uv build

# 3. Verify the built files
ls dist/

# 4. Publish to PyPI
uv publish --token YOUR_PYPI_TOKEN
```
