# FastAPI / SQLAlchemy N+1 query middleware

A FastAPI middleware to find N+1 queries in development.
This middleware helps developers identify and fix N+1 query issues in their FastAPI applications.
It provides logging information on the query and the number of N+1 query occurrences. This is helpful in identifying and fixing N+1 query issues.

This middleware should probably not be used in production, but it can be useful in development.

## Installation

Pip Install:
```bash
pip install fastapi-nplusone
```

UV install:
```bash
uv install fastapi-nplusone
```

Poetry install:
```bash
poetry add fastapi-nplusone
```

## Usage

You probably want to disable this middleware in production.

```python
from fastapi import FastAPI
from fastapi_nplusone import NPlusOne

app = FastAPI()
if not app.debug:
    app.add_middleware(NPlusOne)

```

### Tests

To run the tests:
```bash
uv run pytest ./tests
```
