import logging
from collections import defaultdict
from contextvars import ContextVar
from typing import Any, Dict, Optional
import re

from sqlalchemy import Engine, event
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

logger = logging.getLogger("fastapi_nplusone")

# Context variable to track queries per request
query_tracker: ContextVar[Optional[Dict[str, Any]]] = ContextVar(
    "query_tracker", default=None
)


def _normalize_query(query: str) -> str:
    """
    Normalize SQL query by replacing specific values with placeholders.
    This helps identify similar queries that differ only in parameter values.
    """
    # Remove extra whitespace
    normalized = re.sub(r"\s+", " ", query.strip())
    # Replace numeric values
    normalized = re.sub(r"\b\d+\b", "?", normalized)
    # Replace string literals
    normalized = re.sub(r"'[^']*'", "?", normalized)
    # Replace UUID-like patterns
    normalized = re.sub(
        r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}",
        "?",
        normalized,
        flags=re.IGNORECASE,
    )
    return normalized


@event.listens_for(Engine, "before_cursor_execute", named=True)
def global_receive_before_cursor_execute(**kw):
    tracker = query_tracker.get()
    if tracker is not None:
        statement = kw.get("statement", "")
        normalized = _normalize_query(statement)

        tracker["queries"].append(
            {
                "statement": statement,
                "normalized": normalized,
            }
        )
        tracker["query_patterns"][normalized] += 1


class NPlusOne(BaseHTTPMiddleware):
    """
    Middleware to detect N+1 query problems in SQLAlchemy.

    Monitors database queries and identifies patterns where multiple similar
    queries are executed sequentially, which typically indicates an N+1 problem.
    """

    def __init__(self, app, threshold: int = 5, full_query: bool = False):
        super().__init__(app)
        self.threshold = threshold
        self.full_query = full_query

    async def dispatch(self, request: Request, call_next) -> Response:
        """Process request and detect N+1 queries."""
        # Initialize query tracker for this request
        tracker: dict = {
            "queries": [],
            "query_patterns": defaultdict(int),
        }
        token = query_tracker.set(tracker)
        try:
            response = await call_next(request)
            # Analyze queries after request completion
            self._analyze_queries(tracker, request)
            return response
        finally:
            # Clean up context
            query_tracker.reset(token)

    def _analyze_queries(self, tracker: dict, request: Request) -> None:
        """Analyze collected queries for N+1 patterns."""
        query_patterns = tracker["query_patterns"]
        total_queries = len(tracker["queries"])

        if total_queries == 0:
            return

        # Check for repeated query patterns
        for normalized_query, count in query_patterns.items():
            if count >= self.threshold:
                query_string = self.query_string_truncation(normalized_query)

                logger.warning(
                    f"Potential N+1 query detected on {request.method} {request.url.path}: "
                    f"Query executed {count} times. "
                    f"Normalized query: {query_string}"
                )

    def query_string_truncation(self, normalized_query: str) -> str:
        """Truncate query string to avoid logging large queries."""
        query_string = normalized_query
        if not self.full_query:
            query_string = normalized_query[:200] + "..."
        return query_string

    def _normalize_query(self, query: str) -> str:
        # Keep this for backward compatibility or if called directly
        return _normalize_query(query)
