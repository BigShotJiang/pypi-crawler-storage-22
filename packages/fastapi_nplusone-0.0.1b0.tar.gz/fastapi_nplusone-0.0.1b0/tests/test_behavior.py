import logging
from fastapi import FastAPI
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, text
from fastapi_nplusone import NPlusOne, query_tracker


def test_no_middleware_no_tracking(caplog):
    app = FastAPI()
    # No middleware added here

    @app.get("/")
    async def root():
        engine = create_engine("sqlite:///:memory:")
        with engine.connect() as conn:
            for _ in range(10):
                conn.execute(text("SELECT 1"))
        return {"tracker_exists": query_tracker.get() is not None}

    client = TestClient(app)

    with caplog.at_level(logging.WARNING):
        response = client.get("/")
        assert response.status_code == 200
        # The response should show tracker does not exist
        assert response.json()["tracker_exists"] is False

    # No N+1 warning should be logged
    assert "Potential N+1 query detected" not in caplog.text


def test_middleware_enabled_tracking(caplog):
    app = FastAPI()
    app.add_middleware(NPlusOne, threshold=3)

    @app.get("/")
    async def root():
        engine = create_engine("sqlite:///:memory:")
        with engine.connect() as conn:
            for _ in range(5):
                conn.execute(text("SELECT 1"))
        return {"done": True}

    client = TestClient(app)

    with caplog.at_level(logging.WARNING):
        response = client.get("/")
        assert response.status_code == 200

    assert "Potential N+1 query detected" in caplog.text
