import logging
from fastapi import FastAPI
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, text
from fastapi_nplusone import NPlusOne, query_tracker


def test_normalize_query():
    # We need an instance of NPlusOne, but it requires an app
    app = FastAPI()
    middleware = NPlusOne(app)

    query = "SELECT * FROM users WHERE id = 123 AND name = 'John' AND uuid = '550e8400-e29b-41d4-a716-446655440000'"
    normalized = middleware._normalize_query(query)

    assert "?" in normalized
    assert "123" not in normalized
    assert "John" not in normalized
    assert "550e8400-e29b-41d4-a716-446655440000" not in normalized
    assert normalized == "SELECT * FROM users WHERE id = ? AND name = ? AND uuid = ?"


def test_query_string_truncation():
    app = FastAPI()
    middleware_short = NPlusOne(app, full_query=False)
    middleware_full = NPlusOne(app, full_query=True)

    long_query = "SELECT " + "a" * 300 + " FROM table"

    truncated = middleware_short.query_string_truncation(long_query)
    assert len(truncated) == 203  # 200 + ...
    assert truncated.endswith("...")

    not_truncated = middleware_full.query_string_truncation(long_query)
    assert len(not_truncated) > 300
    assert not not_truncated.endswith("...")


def test_nplusone_detection(caplog):
    app = FastAPI()
    # Set threshold to 3 for testing
    app.add_middleware(NPlusOne, threshold=3)

    @app.get("/")
    async def root():
        engine = create_engine("sqlite:///:memory:")
        with engine.connect() as conn:
            # Execute the same query 3 times
            for _ in range(3):
                conn.execute(text("SELECT 1"))
        return {"message": "done"}

    client = TestClient(app)

    with caplog.at_level(logging.WARNING):
        response = client.get("/")
        assert response.status_code == 200

    assert "Potential N+1 query detected" in caplog.text
    assert "Query executed 3 times" in caplog.text


def test_below_threshold(caplog):
    """
    Test the threshold is enforced correctly.
    """
    app = FastAPI()
    app.add_middleware(NPlusOne, threshold=5)

    @app.get("/")
    async def root():
        engine = create_engine("sqlite:///:memory:")
        with engine.connect() as conn:
            for _ in range(3):
                conn.execute(text("SELECT 1"))
        return {"message": "done"}

    client = TestClient(app)

    with caplog.at_level(logging.WARNING):
        response = client.get("/")
        assert response.status_code == 200

    assert "Potential N+1 query detected" not in caplog.text


def test_context_cleanup():
    app = FastAPI()
    app.add_middleware(NPlusOne)

    @app.get("/")
    async def root():
        tracker = query_tracker.get()
        return {"tracker_exists": tracker is not None and "queries" in tracker}

    client = TestClient(app)

    # Before request
    assert query_tracker.get() is None

    client.get("/")

    # After request
    assert query_tracker.get() is None


def test_multiple_different_queries(caplog):
    app = FastAPI()
    app.add_middleware(NPlusOne, threshold=3)

    @app.get("/")
    async def root():
        engine = create_engine("sqlite:///:memory:")
        with engine.connect() as conn:
            # 2 distinct queries, each 2 times -> no warning (threshold 3)
            # Use basic SQL that doesn't require tables in SQLite
            for _ in range(2):
                conn.execute(text("SELECT 1 AS a"))
                conn.execute(text("SELECT 2 AS b"))
        return {"message": "done"}

    client = TestClient(app)

    with caplog.at_level(logging.WARNING):
        client.get("/")

    assert "Potential N+1 query detected" not in caplog.text
