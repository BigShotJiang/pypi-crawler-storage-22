__title__ = 'FastAPI Pundra'
__version__ = '0.0.20'
__author__ = 'Mostafa'

# Version synonym
VERSION = __version__