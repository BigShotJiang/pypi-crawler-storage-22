import os

def base_path():
    return os.getcwd()