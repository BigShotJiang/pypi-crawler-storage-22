# auto-upgrade@fastapi-vue-setup - remove this if you modify this file
import argparse
import os

from fastapi_vue import server

DEFAULT_PORT = 3100
DEVMODE = os.getenv("FOOBAR_DEV") == "1"


def main():
    parser = argparse.ArgumentParser(description="Run the foobar server.")
    parser.add_argument(
        "-l",
        "--listen",
        action="append",
        help=(f"Endpoint (default: localhost:{DEFAULT_PORT})."),
    )
    args = parser.parse_args()
    dev = {"reload": True, "reload_dirs": ["foobar"]}
    server.run(
        "foobar.app:app",
        listen=args.listen,
        default_port=DEFAULT_PORT,
        **(dev if DEVMODE else {}),
    )


if __name__ == "__main__":
    main()
