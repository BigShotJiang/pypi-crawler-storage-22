"""Exceptions raised inside FastCC."""

from .constants import UNKNOWN_ERROR_CODE


class FastCCError(Exception):
    """Base exception class for FastCC-related errors."""


class MessagingError(FastCCError):
    """Exception raised for messaging operation errors.

    This includes publish, subscribe, and unsubscribe
    operations.
    """


class RouteError(FastCCError):
    """Exception raised for errors in route handling."""


class RouteConflictError(RouteError):
    """Exception raised for route conflicts.

    Raised during route registration when a topic is already registered.
    """


class RouteValidationError(RouteError):
    """Exception raised for errors in route validation."""


class RouteExecutionError(RouteError):
    """Exception raised for route execution errors.

    Parameters
    ----------
    details
        Human-readable error description.
    error_code
        Numeric error code sent back to the client.
    """

    def __init__(
        self,
        details: str,
        error_code: int = UNKNOWN_ERROR_CODE,
    ) -> None:
        self.error_code = error_code
        super().__init__(details)
