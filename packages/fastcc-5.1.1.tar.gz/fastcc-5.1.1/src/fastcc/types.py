"""Type definitions for FastCC."""

import typing

if typing.TYPE_CHECKING:
    from collections.abc import Callable

    import google.protobuf.message

    type Packet = bytes | str | int | float | google.protobuf.message.Message
    type AnyCallable = Callable[..., typing.Any]
