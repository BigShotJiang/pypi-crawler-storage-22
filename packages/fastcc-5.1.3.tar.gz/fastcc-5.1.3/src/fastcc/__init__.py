"""
Framework for component communication.

FastCC is a lightweight, efficient and developer-friendly framework for
component communication. By leveraging MQTT [1]_ for messaging and
Protocol Buffers [2]_ for data serialization, this framework ensures
fast, reliable, and bandwidth-efficient communication. Its simplicity
in setup and development makes it ideal for both small-scale and
enterprise-level applications.

References
----------
.. [1] https://mqtt.org
.. [2] https://protobuf.dev/
"""

import typing

if typing.TYPE_CHECKING:
    from .types import Packet

from .app import Application
from .client import Client
from .exceptions import RouteExecutionError
from .qos import QoS
from .router import Route, Router
