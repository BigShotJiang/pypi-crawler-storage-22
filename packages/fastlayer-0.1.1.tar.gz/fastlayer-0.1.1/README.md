# fastlayer


A FastAPI Clean Architecture (or Layered) project generator.

## Features

* **Clean Architecture**: Layered structure (Domain, Application, Infrastructure, Presentation)
* **Layered Architecture**: Presentation, Core, DB, Models, Repositories, Services, API layers for simpler projects
* **FastAPI**: Modern and high-performance web framework
* **Docker**: Optional Docker and Docker Compose configuration
* **Databases**: Support for SQLAlchemy, MongoDB, or no database
* **Authentication**: Templates for JWT, OAuth2, or no authentication
* **Testing**: Pytest configuration with fixtures and examples
* **CI/CD**: GitHub Actions or GitLab CI templates
* **Update**: Ability to update projects with new template versions

## Installation

### From PyPI

```bash
pip install fastlayer
```

### From source

```bash
git clone https://github.com/Ulrich75/fastlayer.git
cd fastlayer
pip install -e .
```

## Usage

### Create a new project

Interactive mode (recommended):

```bash
fastlayer create my-api
```

Non-interactive mode with options:

```bash
fastlayer create my-api \
  --database sqlalchemy \
  --auth jwt \
  --docker \
  --cicd github \
  --arch clean \
  --no-interactive
```

### Available options

* `--database, -d`: Database type (`sqlalchemy`, `mongodb`, `none`)
* `--auth, -a`: Authentication method (`jwt`, `oauth2`, `none`)
* `--docker/--no-docker`: Include Docker configuration
* `--cicd, -c`: CI/CD provider (`github`, `gitlab`, `none`)
* `--output-dir, -o`: Custom output directory
* `--interactive/--no-interactive, -i/-n`: Interactive mode
* `--arch, -r`: Architecture type (`clean`, `layered`)

### Update an existing project

```bash
cd my-api
fastlayer update
```

### Show version

```bash
fastlayer --version
```

### Show help

```bash
fastlayer --help
fastlayer create --help
```

## Generated project structures

### 1. Clean Architecture

```
my-api/
├── src/
│   └── my_api/
│       ├── domain/
│       │   ├── entities/
│       │   ├── repositories/
│       │   └── exceptions.py
│       ├── application/
│       │   ├── use_cases/
│       │   └── dto/
│       ├── infrastructure/
│       │   ├── repositories/
│       │   ├── database.py
│       │   └── config.py
│       ├── presentation/
│       │   └── api/
│       │       ├── routes/
│       │       ├── schemas/
│       │       └── dependencies.py
│       └── main.py
├── tests/
├── pyproject.toml
├── README.md
├── .env.example
├── Dockerfile
├── docker-compose.yml
└── .github/workflows/
```

### 2. Layered Architecture

```
my-api/
├── src/
│   └── my-api/
│       ├── api/
│       │   ├── deps.py
│       │   ├── __init__.py
│       │   └── v1/
│       ├── core/
│       │   ├── config.py
│       │   ├── exceptions.py
│       │   └── __init__.py
│       ├── db/
│       │   ├── __init__.py
│       │   ├── migrations/
│       │   └── session.py
│       ├── __init__.py
│       ├── main.py
│       ├── models/
│       │   └── __init__.py
│       ├── repositories/
│       │   └── __init__.py
│       ├── schemas/
│       │   └── __init__.py
│       └── services/
│           └── __init__.py
└── tests/
|   ├── conftest.py
|   └── test_api.py
├── README.md
├── pyproject.toml
├── Dockerfile
├── docker-compose.yml
```

## Clean Architecture Principles

### Domain Layer

* **Entities**: Pure business objects with no external dependencies
* **Repositories**: Abstract interfaces for persistence
* **Exceptions**: Custom business exceptions

### Application Layer

* **Use Cases**: Application logic and orchestration
* **DTOs**: Data transfer objects

### Infrastructure Layer

* **Repositories**: Concrete implementations of interfaces
* **Database**: Configuration and database connection
* **Config**: Configuration management

### Presentation Layer

* **Routes**: FastAPI endpoints
* **Schemas**: Pydantic validation
* **Dependencies**: FastAPI dependency injection

## Development

### Install in development mode

```bash
git clone https://github.com/Ulrich75/fastlayer.git
cd fastlayer
pip install -e ".[dev]"
```

### Run tests

```bash
pytest
```

### Linter and formatting

```bash
ruff check src/ tests/
black src/ tests/
mypy src/
```

## License

MIT License - see the [LICENSE](LICENSE) file for details.

## Contribution

Contributions are welcome! Feel free to open an issue or a pull request.

## Resources

* [FastAPI Documentation](https://fastapi.tiangolo.com/)
* [Clean Architecture by Uncle Bob](https://blog.cleancoder.com/uncle-bob/2012/08/13/the-clean-architecture.html)
* [Copier Documentation](https://copier.readthedocs.io/)
