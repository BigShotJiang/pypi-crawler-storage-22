"""FastAPI Clean Architecture Generator."""

__version__ = "0.1.0"
__author__ = "Ulrich"
__description__ = "A FastAPI Clean Architecture project generator"
