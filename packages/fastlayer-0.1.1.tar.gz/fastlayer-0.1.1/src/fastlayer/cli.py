"""CLI interface for Fastlayer Generator."""

import click
from pathlib import Path
from typing import Optional

from fastlayer import __version__
from fastlayer.generator import generate_project, update_project


@click.group(invoke_without_command=True)
@click.option("--version", "-v", is_flag=True, help="Show version and exit")
@click.pass_context
def main(ctx: click.Context, version: bool) -> None:
    """Fastlayer Generator.
    
    Generate FastAPI projects following Clean Architecture principles.
    """
    if version:
        click.echo(f"fastlayer version {__version__}")
        ctx.exit()
    
    # If no command is provided, show help
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@main.command()
@click.argument("project_name")
@click.option(
    "--output-dir",
    "-o",
    type=click.Path(exists=False, path_type=Path),
    default=None,
    help="Output directory (default: current directory)",
)
@click.option(
    "--database",
    "-d",
    type=click.Choice(["sqlalchemy", "mongodb", "none"], case_sensitive=False),
    default="sqlalchemy",
    help="Database type to use",
)
@click.option(
    "--auth",
    "-a",
    type=click.Choice(["jwt", "oauth2", "none"], case_sensitive=False),
    default="jwt",
    help="Authentication method",
)
@click.option(
    "--docker/--no-docker",
    default=True,
    help="Include Docker configuration",
)
@click.option(
    "--cicd",
    "-c",
    type=click.Choice(["github", "gitlab", "none"], case_sensitive=False),
    default="github",
    help="CI/CD provider",
)
@click.option(
    "--arch",
    type=click.Choice(["clean", "layered"], case_sensitive=False),
    default="clean",
    help="Project architecture (clean: classic layered, layered: flat structure)",
)
@click.option(
    "--interactive/--no-interactive",
    "-i/-n",
    default=True,
    help="Interactive mode (prompts for additional options)",
)
def create(
    project_name: str,
    output_dir: Optional[Path],
    database: str,
    auth: str,
    docker: bool,
    cicd: str,
    arch: str,
    interactive: bool,
) -> None:
    """Create a new FastAPI project.
    
    PROJECT_NAME: Name of the project to create
    
    Examples:
        fastlayer create my-api
        fastlayer create my-api --arch layered
        fastlayer create my-api -d mongodb -a oauth2
    """
    click.echo(f"🚀 Creating FastAPI project: {project_name} ({arch} architecture)")
    
    if output_dir is None:
        output_dir = Path.cwd()
    
    try:
        generate_project(
            project_name=project_name,
            output_dir=output_dir,
            database=database,
            auth=auth,
            docker=docker,
            cicd=cicd,
            arch=arch,
            interactive=interactive,
        )
        click.echo(f"✅ Project '{project_name}' created successfully!")
        click.echo(f"\nNext steps:")
        click.echo(f"  cd {project_name}")
        click.echo(f"  python -m venv venv")
        click.echo(f"  source venv/bin/activate  # On Windows: venv\\Scripts\\activate")
        click.echo(f"  pip install -e '.[dev]'")
        click.echo(f"  uvicorn {project_name}.main:app --reload")
    except Exception as e:
        click.echo(f"❌ Error creating project: {e}", err=True)
        raise click.Abort()


@main.command()
@click.option(
    "--project-dir",
    "-p",
    type=click.Path(exists=True, file_okay=False, path_type=Path),
    default=None,
    help="Project directory to update (default: current directory)",
)
def update(project_dir: Optional[Path]) -> None:
    """Update an existing FastAPI Clean Architecture project.
    
    This command updates your project to the latest template version
    while preserving your custom changes.
    
    Examples:
        fastlayer update
        fastlayer update -p ./my-api
    """
    if project_dir is None:
        project_dir = Path.cwd()
    
    click.echo(f"🔄 Updating project in: {project_dir}")
    
    try:
        update_project(project_dir)
        click.echo("✅ Project updated successfully!")
    except Exception as e:
        click.echo(f"❌ Error updating project: {e}", err=True)
        raise click.Abort()


if __name__ == "__main__":
    main()
