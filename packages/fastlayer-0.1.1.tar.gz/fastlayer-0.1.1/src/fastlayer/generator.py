"""Project generation logic using Copier."""

from pathlib import Path
from typing import Optional, Dict, Any
import copier


def get_template_path(arch: str = "clean") -> Path:
    """Get the path to the template directory.
    
    Args:
        arch: Architecture type (clean or layered)

    Handles both development mode (pip install -e) and installed package.
    """
    if arch not in ["clean", "layered"]:
        raise ValueError(f"Unknown architecture: {arch}. Must be 'clean' or 'layered'.")

    # Strategy 1: Template bundled inside the package (pip install from PyPI)
    package_dir = Path(__file__).parent
    # Now templates are in templates/{arch}
    template_dir = package_dir / "templates" / arch
    if template_dir.exists() and (template_dir / "copier.yml").exists():
        return template_dir
    
    # Strategy 2: Development mode (pip install -e .)
    # In editable installs, __file__ is at src/fastlayer/generator.py
    # so templates is at ../../templates (project root)
    dev_template_dir = package_dir.parent.parent / "templates" / arch
    if dev_template_dir.exists() and (dev_template_dir / "copier.yml").exists():
        return dev_template_dir
    
    raise RuntimeError(
        f"Template directory not found for arch '{arch}'. Searched:\n"
        f"  - {template_dir}\n"
        f"  - {dev_template_dir}\n"
        f"Please reinstall the package or check your installation."
    )


def generate_project(
    project_name: str,
    output_dir: Path,
    database: str = "sqlalchemy",
    auth: str = "jwt",
    docker: bool = True,
    cicd: str = "github",
    arch: str = "clean",
    interactive: bool = True,
) -> None:
    """Generate a new FastAPI project.
    
    Args:
        project_name: Name of the project
        output_dir: Directory where to create the project
        database: Database type (sqlalchemy, mongodb, none)
        auth: Authentication method (jwt, oauth2, none)
        docker: Whether to include Docker configuration
        cicd: CI/CD provider (github, gitlab, none)
        arch: Architecture type (clean, layered)
        interactive: Whether to prompt for additional options
    """
    template_path = get_template_path(arch=arch)
    
    # Prepare data for Copier
    data: Dict[str, Any] = {
        "project_name": project_name,
        "database_type": database,
        "auth_type": auth,
        "docker_support": docker,
        "cicd_provider": cicd,
    }
    
    # Run Copier
    # Note: template root is {{ project_name }}/, so copier creates
    # output_dir/project_name/... automatically
    copier.run_copy(
        src_path=str(template_path),
        dst_path=str(output_dir),
        data=data,
        unsafe=True,  # Allow templates to execute
        quiet=False,
        defaults=not interactive,  # Use defaults if not interactive
    )


def update_project(project_dir: Path, arch: str = "clean") -> None:
    """Update an existing project to the latest template version.
    
    Args:
        project_dir: Directory of the project to update
        arch: Architecture type (used if template source is not found in answers)
    """
    # Note: copier update usually finds the src from .copier-answers.yml
    # But we can provide defaults or if we want to switch architectures (hard)
    
    # Run Copier update
    copier.run_update(
        dst_path=str(project_dir),
        unsafe=True,
        quiet=False,
    )
