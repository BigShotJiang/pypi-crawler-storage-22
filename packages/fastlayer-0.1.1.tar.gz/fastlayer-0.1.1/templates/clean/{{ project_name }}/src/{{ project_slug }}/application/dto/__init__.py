"""Data Transfer Objects package."""
