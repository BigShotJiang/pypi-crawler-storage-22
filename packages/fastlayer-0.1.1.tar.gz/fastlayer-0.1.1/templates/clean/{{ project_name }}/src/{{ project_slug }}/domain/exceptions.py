"""Domain exceptions for the application."""

from typing import Any, Optional


class DomainException(Exception):
    """Base exception for all domain-related errors."""

    def __init__(self, message: str, details: Optional[dict[str, Any]] = None) -> None:
        self.message = message
        self.details = details or {}
        super().__init__(self.message)


class EntityNotFoundError(DomainException):
    """Raised when an entity is not found."""

    def __init__(self, entity_type: str, entity_id: Any) -> None:
        message = f"{entity_type} with id '{entity_id}' not found"
        super().__init__(message, {"entity_type": entity_type, "entity_id": entity_id})


class EntityAlreadyExistsError(DomainException):
    """Raised when trying to create an entity that already exists."""

    def __init__(self, entity_type: str, identifier: str) -> None:
        message = f"{entity_type} with identifier '{identifier}' already exists"
        super().__init__(message, {"entity_type": entity_type, "identifier": identifier})


class ValidationError(DomainException):
    """Raised when entity validation fails."""

    def __init__(self, field: str, message: str) -> None:
        super().__init__(f"Validation error on field '{field}': {message}", {"field": field})


class BusinessRuleViolationError(DomainException):
    """Raised when a business rule is violated."""

    pass
