"""Application alias configuration - Process name mappings for common applications."""

from __future__ import annotations

# Process alias mappings - Based on fastmcp_app_launcher's PROCESS_ALIASES
PROCESS_ALIASES: dict[str, set[str]] = {
    "qq": {"qq", "qqprotect", "qqsclaunch", "qqsclauncher", "qqbrowser"},
    "wechat": {"wechat", "weixin", "wechatapp"},
    "微信": {"wechat", "weixin", "wechatapp"},
    "weixin": {"wechat", "weixin", "wechatapp"},
    "tim": {"tim"},
    "dingtalk": {"dingtalk", "钉钉"},
    "钉钉": {"dingtalk"},
    "lark": {"lark", "feishu", "飞书"},
    "feishu": {"lark", "feishu", "飞书"},
    "飞书": {"lark", "feishu"},
}

# System critical processes - Cannot be closed
PROTECTED_PROCESSES: dict[str, set[str]] = {
    "windows": {
        "explorer",
        "winlogon",
        "csrss",
        "services",
        "svchost",
        "lsass",
        "smss",
        "wininit",
        "dwm",
        "system",
        "registry",
    },
    "darwin": {
        "finder",
        "windowserver",
        "loginwindow",
        "systemuiserver",
        "dock",
        "kernel_task",
        "launchd",
    },
    "linux": {
        "systemd",
        "init",
        "xorg",
        "x11",
        "gdm",
        "lightdm",
        "sddm",
        "kwin",
        "gnome-shell",
    },
}


def get_aliases(query: str) -> set[str]:
    """Get all aliases for a query string.
    
    Args:
        query: Query string (application name or process name)
        
    Returns:
        Set containing all aliases
    """
    query_lower = query.lower().replace(".exe", "")
    
    # Direct lookup
    if query_lower in PROCESS_ALIASES:
        return PROCESS_ALIASES[query_lower].copy()
    
    # Reverse lookup - if query string is part of an alias
    result = {query_lower}
    for key, aliases in PROCESS_ALIASES.items():
        if query_lower in aliases:
            result.update(aliases)
            result.add(key)
    
    return result


def is_protected(process_name: str, platform: str = "windows") -> bool:
    """Check if a process is a protected system critical process.
    
    Args:
        process_name: Process name
        platform: Platform name (windows/darwin/linux)
        
    Returns:
        True if the process is protected
    """
    process_lower = process_name.lower().replace(".exe", "")
    protected = PROTECTED_PROCESSES.get(platform.lower(), set())
    return process_lower in protected
