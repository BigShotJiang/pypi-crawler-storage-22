# FastMCP App Closer

MCP 服务器，用于关闭正在运行的应用程序。

## 功能特性

- 🔍 **智能进程查找** - 支持模糊匹配进程名
- 🎯 **别名支持** - 内置常见应用别名（微信、飞书、钉钉等）
- 🛡️ **安全保护** - 防止关闭系统关键进程
- 🌍 **跨平台** - 支持 Windows、macOS、Linux

## Installation

### From PyPI (Recommended)

```bash
pip install fastmcp-app-closer
```

### From Source

```bash
git clone https://github.com/yourusername/fastmcp-app-closer.git
cd fastmcp_app_closer
pip install -e .
```

## 使用方法

### 启动 MCP 服务器

```bash
fastmcp-app-closer
```

### 可用工具

#### 1. close_app - 关闭应用

关闭指定名称的应用程序。

**参数：**
- `appName` (string, required) - 应用名称或进程名

**示例：**
```json
{
  "tool": "close_app",
  "arguments": {
    "appName": "微信"
  }
}
```

支持的匹配方式：
- 精确匹配：`WeChat.exe`
- 模糊匹配：`wechat`、`WeChat`
- 别名匹配：`微信`、`weixin`

#### 2. list_running_apps - 列出运行的应用

列出所有正在运行的应用程序。

**示例：**
```json
{
  "tool": "list_running_apps"
}
```

## 支持的应用别名

| 应用名 | 别名 |
|--------|------|
| 微信 | wechat, weixin, wechat.exe |
| 飞书 | lark, feishu, lark.exe |
| 钉钉 | dingtalk, dingtalk.exe |
| QQ | qq.exe, qqprotect.exe |
| QQ音乐 | qqmusic, qqmusicexternal |
| 网易云音乐 | cloudmusic, neteasecloudmusic |
| 日历 (macOS) | calendar |
| 备忘录 (macOS) | notes |

更多别名请查看 [ALIAS_GUIDE.md](ALIAS_GUIDE.md)

## 故障排除

### 应用无法识别？

如果遇到 "No matching process found" 错误：

1. **查看实际进程名**
   ```bash
   # Windows
   Get-Process | Select-Object Name
   
   # macOS/Linux
   ps aux | grep -i "app_name"
   ```

2. **添加自定义别名**
   
   编辑 `src/app_closer_mcp/aliases.py`，在 `PROCESS_ALIASES` 中添加：
   ```python
   "应用中文名": {"actual_process_name"},
   ```

3. **使用实际进程名**
   
   直接使用进程名而不是应用名：
   ```json
   {"appName": "qqmusic"}  // 而不是 "QQ音乐"
   ```

详细指南请参考 [ALIAS_GUIDE.md](ALIAS_GUIDE.md)

## 安全限制

以下系统关键进程无法被关闭：
- Windows: `explorer.exe`, `winlogon.exe`, `csrss.exe`, `services.exe`, `svchost.exe`
- macOS: `Finder`, `WindowServer`, `loginwindow`
- Linux: `systemd`, `init`, `Xorg`

## 开发

### 运行测试

```bash
pip install -e ".[dev]"
pytest
```

### 代码格式化

```bash
black src/
ruff check src/
```

## 许可证

MIT License
