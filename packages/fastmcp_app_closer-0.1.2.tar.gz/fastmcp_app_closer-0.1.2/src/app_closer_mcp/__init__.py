"""FastMCP App Closer - MCP server for closing running applications."""

__version__ = "0.1.0"
