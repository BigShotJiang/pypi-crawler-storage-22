"""Application alias configuration - Process name mappings for common applications."""

from __future__ import annotations

# Process alias mappings - Comprehensive list for common applications
PROCESS_ALIASES: dict[str, set[str]] = {
    # ==================== Tencent Ecosystem ====================
    "qq": {"qq", "qqprotect", "qqsclaunch", "qqsclauncher", "qqbrowser"},
    "wechat": {"wechat", "weixin", "wechatapp"},
    "微信": {"wechat", "weixin", "wechatapp"},
    "weixin": {"wechat", "weixin", "wechatapp"},
    "tim": {"tim"},
    "qqmusic": {"qqmusic", "qqmusicexternal"},
    "qq音乐": {"qqmusic", "qqmusicexternal"},
    "qq music": {"qqmusic", "qqmusicexternal"},
    "企业微信": {"wxwork", "wework"},
    "wework": {"wxwork", "wework"},
    "腾讯会议": {"wemeet", "wemeetapp", "tencent meeting"},
    "wemeet": {"wemeet", "wemeetapp"},
    "腾讯文档": {"tdocs", "tencentdocs"},
    "qq浏览器": {"qqbrowser"},
    "腾讯视频": {"qqliveplayer", "tencentvideo"},
    "腾讯元宝": {"tencentyuanbao"},
    
    # ==================== Music & Media ====================
    "netease": {"cloudmusic", "neteasecloudmusic"},
    "网易云音乐": {"cloudmusic", "neteasecloudmusic"},
    "cloudmusic": {"cloudmusic", "neteasecloudmusic"},
    "spotify": {"spotify"},
    "itunes": {"itunes"},
    "music": {"music"},  # macOS Music app
    "音乐": {"music", "cloudmusic", "qqmusic"},  # Generic music
    "kugou": {"kugou", "kugoumusic"},
    "酷狗音乐": {"kugou", "kugoumusic"},
    "kuwo": {"kuwo", "kuwomusic"},
    "酷我音乐": {"kuwo", "kuwomusic"},
    "foobar2000": {"foobar2000"},
    "vlc": {"vlc"},
    "potplayer": {"potplayer", "potplayermini", "potplayermini64"},
    "汽水音乐": {"qishuimusic"},
    "lx music": {"lx-music-desktop"},
    
    # ==================== Work & Collaboration ====================
    "dingtalk": {"dingtalk", "钉钉"},
    "钉钉": {"dingtalk"},
    "lark": {"lark", "feishu", "飞书"},
    "feishu": {"lark", "feishu", "飞书"},
    "飞书": {"lark", "feishu"},
    "slack": {"slack"},
    "teams": {"teams", "microsoft teams", "msteams"},
    "zoom": {"zoom", "zoom.us", "cpthost"},
    "skype": {"skype"},
    "discord": {"discord"},
    "telegram": {"telegram"},
    "钉钉": {"dingtalk"},
    
    # ==================== Browsers ====================
    "chrome": {"chrome", "google chrome"},
    "谷歌浏览器": {"chrome", "google chrome"},
    "edge": {"msedge", "microsoftedge"},
    "firefox": {"firefox"},
    "火狐": {"firefox"},
    "safari": {"safari"},
    "opera": {"opera"},
    "brave": {"brave"},
    "360浏览器": {"360chrome", "360se"},
    "360chrome": {"360chrome", "360se"},
    "搜狗浏览器": {"sogouexplorer"},
    "uc浏览器": {"ucbrowser"},
    "夸克": {"quark"},
    "quark": {"quark"},
    "arc": {"arc"},
    "360极速浏览器": {"360chrome", "360se"},
    
    # ==================== Development Tools ====================
    "vscode": {"code", "visual studio code"},
    "vs code": {"code", "visual studio code"},
    "pycharm": {"pycharm", "pycharm64"},
    "webstorm": {"webstorm", "webstorm64"},
    "idea": {"idea", "idea64", "intellij idea"},
    "intellij": {"idea", "idea64", "intellij idea"},
    "android studio": {"studio", "studio64"},
    "sublime": {"sublime_text", "subl"},
    "notepad++": {"notepad++"},
    "atom": {"atom"},
    "vim": {"vim", "gvim"},
    "emacs": {"emacs"},
    "xcode": {"xcode"},
    "visual studio": {"devenv"},
    "git": {"git", "git-bash"},
    "github desktop": {"github desktop", "githubdesktop"},
    "sourcetree": {"sourcetree"},
    "postman": {"postman"},
    "docker": {"docker", "docker desktop"},
    "vmware": {"vmware", "vmware-vmx"},
    "virtualbox": {"virtualbox", "vboxheadless"},
    "cursor": {"cursor"},
    "apifox": {"apifox"},
    "apipost": {"apipost"},
    "navicat": {"navicat"},
    "dbeaver": {"dbeaver"},
    "hbuilderx": {"hbuilderx"},
    "charles": {"charles"},
    "fiddler": {"fiddler"},
    
    # ==================== Office & Productivity ====================
    "word": {"winword", "microsoft word"},
    "excel": {"excel", "microsoft excel"},
    "powerpoint": {"powerpnt", "microsoft powerpoint"},
    "ppt": {"powerpnt", "microsoft powerpoint"},
    "outlook": {"outlook", "microsoft outlook"},
    "onenote": {"onenote", "microsoft onenote"},
    "wps": {"wps", "wpsoffice", "et", "wpp"},
    "wps文字": {"wps"},
    "wps表格": {"et"},
    "wps演示": {"wpp"},
    "notion": {"notion"},
    "evernote": {"evernote"},
    "印象笔记": {"evernote"},
    "obsidian": {"obsidian"},
    "typora": {"typora"},
    "有道云笔记": {"youdaonote"},
    "为知笔记": {"wiznote"},
    "幕布": {"mubu"},
    "flomo": {"flomo"},
    "flowus": {"flowus"},
    "息流": {"flowus"},
    "wolai": {"wolai"},
    "我来": {"wolai"},
    
    # ==================== macOS System Apps ====================
    "finder": {"finder"},
    "访达": {"finder"},
    "calendar": {"calendar"},
    "日历": {"calendar"},
    "mail": {"mail"},
    "邮件": {"mail"},
    "notes": {"notes"},
    "备忘录": {"notes"},
    "reminders": {"reminders"},
    "提醒事项": {"reminders"},
    "contacts": {"contacts"},
    "通讯录": {"contacts"},
    "facetime": {"facetime"},
    "messages": {"messages"},
    "信息": {"messages"},
    "photos": {"photos"},
    "照片": {"photos"},
    "preview": {"preview"},
    "预览": {"preview"},
    "textedit": {"textedit"},
    "文本编辑": {"textedit"},
    "terminal": {"terminal"},
    "终端": {"terminal"},
    "iterm": {"iterm2", "iterm"},
    "activity monitor": {"activity monitor"},
    "活动监视器": {"activity monitor"},
    "system settings": {"system settings", "system preferences"},
    "系统设置": {"system settings", "system preferences"},
    "系统偏好设置": {"system settings", "system preferences"},
    
    # ==================== Windows System Apps ====================
    "explorer": {"explorer"},
    "资源管理器": {"explorer"},
    "notepad": {"notepad"},
    "记事本": {"notepad"},
    "calculator": {"calculator", "calc"},
    "计算器": {"calculator", "calc"},
    "paint": {"mspaint"},
    "画图": {"mspaint"},
    "cmd": {"cmd"},
    "powershell": {"powershell"},
    "terminal": {"windowsterminal", "wt"},
    "任务管理器": {"taskmgr"},
    "task manager": {"taskmgr"},
    
    # ==================== Design & Creative ====================
    "photoshop": {"photoshop"},
    "ps": {"photoshop"},
    "illustrator": {"illustrator"},
    "ai": {"illustrator"},
    "premiere": {"premiere", "premiere pro"},
    "pr": {"premiere"},
    "after effects": {"afterfx", "ae"},
    "ae": {"afterfx"},
    "figma": {"figma"},
    "sketch": {"sketch"},
    "blender": {"blender"},
    "davinci": {"resolve"},
    "剪映": {"jianying", "capcut"},
    "capcut": {"jianying", "capcut"},
    "剪映专业版": {"jianying", "capcut"},
    "final cut": {"final cut pro"},
    "final cut pro": {"final cut pro"},
    "obs": {"obs", "obs studio"},
    "obs studio": {"obs", "obs studio"},
    "screenflow": {"screenflow"},
    "corel": {"coreldraw"},
    "coreldraw": {"coreldraw"},
    
    # ==================== Download & Network ====================
    "迅雷": {"thunder", "thunderplatform"},
    "thunder": {"thunder", "thunderplatform"},
    "百度网盘": {"baidunetdisk"},
    "baidunetdisk": {"baidunetdisk"},
    "阿里云盘": {"aliyundrive"},
    "idm": {"idman"},
    "internet download manager": {"idman"},
    "qbittorrent": {"qbittorrent"},
    "utorrent": {"utorrent"},
    "aria2": {"aria2c"},
    "夸克网盘": {"quarkdrive"},
    "115网盘": {"115"},
    "城通网盘": {"ctfile"},
    "onedrive": {"onedrive"},
    
    # ==================== Security & Utilities ====================
    "火绒": {"huorong", "hipsvc"},
    "360安全卫士": {"360tray", "360sd"},
    "腾讯电脑管家": {"qqpcmgr", "qqpcrtp"},
    "1password": {"1password"},
    "bitwarden": {"bitwarden"},
    "lastpass": {"lastpass"},
    "everything": {"everything"},
    "bandizip": {"bandizip"},
    "7zip": {"7zfm", "7z"},
    "winrar": {"winrar"},
    "snipaste": {"snipaste"},
    "截图": {"snipaste", "screenshot"},
    "cleanshot": {"cleanshot"},
    "ishot": {"ishot"},
    "magnet": {"magnet"},
    "paste": {"paste"},
    "raycast": {"raycast"},
    "alfred": {"alfred"},
    "utools": {"utools"},
    "向日葵": {"sunlogin"},
    "向日葵远程控制": {"sunlogin"},
    "todesk": {"todesk"},
    "teamviewer": {"teamviewer"},
    "parsec": {"parsec"},
    
    # ==================== Gaming ====================
    "steam": {"steam"},
    "epic": {"epicgameslauncher"},
    "wegame": {"wegame", "wegametgp"},
    "wegame": {"wegame"},
    "origin": {"origin"},
    "uplay": {"uplay", "ubisoft connect"},
    "battle.net": {"battle.net"},
    "暴雪战网": {"battle.net"},
    "ubisoft connect": {"uplay", "ubisoft connect"},
    "育碧": {"uplay", "ubisoft connect"},
    
    # ==================== Input Methods ====================
    "搜狗输入法": {"sogouinput", "sgpinyinplatform"},
    "sogou": {"sogouinput", "sgpinyinplatform"},
    "百度输入法": {"baiduinput"},
    "讯飞输入法": {"iflyinput"},
    "微软拼音": {"chsime"},
    
    # ==================== Video Conferencing ====================
    "腾讯会议": {"wemeet", "wemeetapp"},
    "zoom": {"zoom", "cpthost"},
    "钉钉": {"dingtalk"},
    "飞书": {"lark", "feishu"},
    "teams": {"teams", "msteams"},
    "webex": {"webex", "ptoneclk"},
    
    # ==================== Reading & Learning ====================
    "微信读书": {"wereader", "weread"},
    "kindle": {"kindle"},
    "calibre": {"calibre"},
    "福昕阅读器": {"foxitreader"},
    "adobe reader": {"acrord32", "acrobat"},
    "pdf": {"acrord32", "foxitreader", "preview"},
    "anki": {"anki"},
    
    # ==================== Social & Entertainment ====================
    "抖音": {"douyin"},
    "bilibili": {"bilibili", "哔哩哔哩"},
    "哔哩哔哩": {"bilibili"},
    "爱奇艺": {"qiyi", "iqiyi"},
    "iqiyi": {"qiyi", "iqiyi"},
    "优酷": {"youku"},
    "腾讯视频": {"qqliveplayer", "tencentvideo"},
    
    # ==================== AI Assistants ====================
    "豆包": {"doubao"},
    "doubao": {"doubao"},
    "kimi": {"kimi"},
    "chatgpt": {"chatgpt"},
    "claude": {"claude"},
    "智谱清言": {"glm", "zhipu"},
    "glm": {"glm", "zhipu"},
    "文心一言": {"ernie"},
    "通义千问": {"qwen"},
    "copilot": {"copilot", "ima.copilot"},
    "antigravity": {"antigravity"},
    "codebuddy": {"codebuddy"},
    "cursor": {"cursor"},
    "monica": {"monica"},
    "cherry studio": {"cherry studio"},
    "chatbox": {"chatbox"},
    "poe": {"poe"},
    "ollama": {"ollama"},
    
    # ==================== Specialized Tools ====================
    "axure": {"axure", "axure rp"},
    "墨刀": {"modao"},
    "蓝湖": {"lanhu"},
    "mastergo": {"mastergo"},
    "pixso": {"pixso"},
    "摹客": {"mockplus"},
    "xmind": {"xmind"},
    "思维导图": {"xmind", "mindmaster"},
    "mindmaster": {"mindmaster"},
    "亿图图示": {"edrawmax"},
    "万兴图示": {"edrawmind"},
    "eagle": {"eagle"},
    "billfish": {"billfish"},
    "美图秀秀": {"meitu", "meituxiuxiu"},
    "光影魔术手": {"neopaint"},
    "解优": {"jieyou"},
    "cad快速看图": {"cadkuaisu"},
    "浩辰cad": {"gstarcad"},
    "autocad": {"acad"},
    "solidworks": {"sldworks"},
    "inventor": {"inventor"},
    "fusion 360": {"fusion360"},
    "bambu studio": {"bambustudio"},
    "cura": {"cura"},
    "prusa": {"prusaslicer"},
    "orca": {"orcaslicer"},
    
    # ==================== Finance & Banking ====================
    "同花顺": {"tonghuashun"},
    "东方财富": {"eastmoney"},
    "雪球": {"xueqiu"},
    "工行网银": {"icbc"},
    "建行网银": {"ccb"},
    "招商银行": {"cmb"},
    "支付宝": {"alipay"},
    
    # ==================== Education ====================
    "钉钉": {"dingtalk"},
    "classin": {"classin"},
    "腾讯课堂": {"ke"},
    "学而思": {"xueersi"},
    "猿辅导": {"yuanfudao"},
    "作业帮": {"zuoyebang"},
    "网易有道词典": {"youdaodict"},
    "网易有道翻译": {"youdaotrans"},
    "欧路词典": {"eudic"},
    "anki": {"anki"},
    "quizlet": {"quizlet"},
    
    # ==================== VPN & Network ====================
    "clash": {"clash", "clashx", "clash verge", "flclash"},
    "clashx": {"clashx"},
    "clash verge": {"clash verge"},
    "v2ray": {"v2rayn", "v2rayu"},
    "shadowrocket": {"shadowrocket"},
    "uu加速器": {"uu"},
    "雷神加速器": {"leigod"},
    "迅游加速器": {"xunyou"},
    "奇游加速器": {"qiyou"},
    "bywave": {"bywave"},
    "快连": {"kuailian"},
    "闪电加速器": {"shandian"},
}

# System critical processes - Cannot be closed
PROTECTED_PROCESSES: dict[str, set[str]] = {
    "windows": {
        "explorer",
        "winlogon",
        "csrss",
        "services",
        "svchost",
        "lsass",
        "smss",
        "wininit",
        "dwm",
        "system",
        "registry",
    },
    "darwin": {
        "finder",
        "windowserver",
        "loginwindow",
        "systemuiserver",
        "dock",
        "kernel_task",
        "launchd",
    },
    "linux": {
        "systemd",
        "init",
        "xorg",
        "x11",
        "gdm",
        "lightdm",
        "sddm",
        "kwin",
        "gnome-shell",
    },
}


def get_aliases(query: str) -> set[str]:
    """Get all aliases for a query string.
    
    Args:
        query: Query string (application name or process name)
        
    Returns:
        Set containing all aliases
    """
    query_lower = query.lower().replace(".exe", "")
    
    # Direct lookup
    if query_lower in PROCESS_ALIASES:
        return PROCESS_ALIASES[query_lower].copy()
    
    # Reverse lookup - if query string is part of an alias
    result = {query_lower}
    for key, aliases in PROCESS_ALIASES.items():
        if query_lower in aliases:
            result.update(aliases)
            result.add(key)
    
    return result


def is_protected(process_name: str, platform: str = "windows") -> bool:
    """Check if a process is a protected system critical process.
    
    Args:
        process_name: Process name
        platform: Platform name (windows/darwin/linux)
        
    Returns:
        True if the process is protected
    """
    process_lower = process_name.lower().replace(".exe", "")
    protected = PROTECTED_PROCESSES.get(platform.lower(), set())
    return process_lower in protected
