"""Process finder module - Find running processes."""

from __future__ import annotations

import logging
import platform
from dataclasses import dataclass
from typing import List

import psutil

from .aliases import get_aliases, is_protected

logger = logging.getLogger(__name__)


@dataclass
class ProcessInfo:
    """Process information."""
    pid: int
    name: str
    exe: str | None = None
    cmdline: List[str] | None = None


def get_platform() -> str:
    """Get current platform."""
    sys_platform = platform.system().lower()
    if sys_platform == "darwin":
        return "darwin"
    elif sys_platform == "windows":
        return "windows"
    elif sys_platform == "linux":
        return "linux"
    return sys_platform


def find_processes(query: str) -> List[ProcessInfo]:
    """Find matching processes.
    
    Args:
        query: Query string (application name or process name)
        
    Returns:
        List of matching processes
    """
    query_lower = query.lower().replace(".exe", "")
    
    # Get all aliases
    aliases = get_aliases(query)
    logger.debug(f"Finding processes: {query}, aliases: {aliases}")
    
    matched_processes: List[ProcessInfo] = []
    current_platform = get_platform()
    
    for proc in psutil.process_iter(['pid', 'name', 'exe', 'cmdline']):
        try:
            proc_info = proc.info
            proc_name = proc_info.get('name', '').lower().replace('.exe', '')
            
            # Skip empty process names
            if not proc_name:
                continue
            
            # Check if it's a protected process
            if is_protected(proc_name, current_platform):
                logger.debug(f"Skipping protected process: {proc_name}")
                continue
            
            # Matching logic
            matched = False
            
            # 1. Exact match
            if proc_name == query_lower:
                matched = True
                logger.debug(f"Exact match: {proc_name}")
            
            # 2. Alias match
            elif proc_name in aliases:
                matched = True
                logger.debug(f"Alias match: {proc_name} in {aliases}")
            
            # 3. Fuzzy match (contains)
            elif query_lower in proc_name or proc_name in query_lower:
                matched = True
                logger.debug(f"Fuzzy match: {query_lower} <-> {proc_name}")
            
            if matched:
                matched_processes.append(
                    ProcessInfo(
                        pid=proc_info['pid'],
                        name=proc_info['name'],
                        exe=proc_info.get('exe'),
                        cmdline=proc_info.get('cmdline'),
                    )
                )
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            continue
    
    logger.info(f"Found {len(matched_processes)} matching process(es)")
    return matched_processes


def list_all_processes() -> List[ProcessInfo]:
    """List all running processes.
    
    Returns:
        List of all processes
    """
    processes: List[ProcessInfo] = []
    
    for proc in psutil.process_iter(['pid', 'name', 'exe', 'cmdline']):
        try:
            proc_info = proc.info
            processes.append(
                ProcessInfo(
                    pid=proc_info['pid'],
                    name=proc_info.get('name', ''),
                    exe=proc_info.get('exe'),
                    cmdline=proc_info.get('cmdline'),
                )
            )
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            continue
    
    return processes
