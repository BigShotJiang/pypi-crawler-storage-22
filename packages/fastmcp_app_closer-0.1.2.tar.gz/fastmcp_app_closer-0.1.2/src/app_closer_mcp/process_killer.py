"""进程终止模块 - 关闭进程。"""

from __future__ import annotations

import logging
import time
from typing import Any, Dict, List

import psutil

from .process_finder import ProcessInfo

logger = logging.getLogger(__name__)


def terminate_process(proc_info: ProcessInfo, timeout: float = 3.0) -> Dict[str, Any]:
    """Terminate a single process.
    
    Args:
        proc_info: Process information
        timeout: Timeout in seconds
        
    Returns:
        包含终止结果的字典
    """
    try:
        proc = psutil.Process(proc_info.pid)
        
        # Check if process is still running
        if not proc.is_running():
            return {
                "success": True,
                "pid": proc_info.pid,
                "name": proc_info.name,
                "message": "Process is no longer running",
            }
        
        logger.info(f"Terminating process: {proc_info.name} (PID: {proc_info.pid})")
        
        # Try graceful termination
        proc.terminate()
        
        # Wait for process to end
        try:
            proc.wait(timeout=timeout)
            logger.info(f"Process gracefully terminated: {proc_info.name} (PID: {proc_info.pid})")
            return {
                "success": True,
                "pid": proc_info.pid,
                "name": proc_info.name,
                "method": "terminate",
                "message": f"Successfully closed process {proc_info.name}",
            }
        except psutil.TimeoutExpired:
            # Force kill after timeout
            logger.warning(f"Graceful termination timeout, force killing: {proc_info.name} (PID: {proc_info.pid})")
            proc.kill()
            proc.wait(timeout=2.0)
            logger.info(f"Process force killed: {proc_info.name} (PID: {proc_info.pid})")
            return {
                "success": True,
                "pid": proc_info.pid,
                "name": proc_info.name,
                "method": "kill",
                "message": f"Force closed process {proc_info.name}",
            }
            
    except psutil.NoSuchProcess:
        return {
            "success": True,
            "pid": proc_info.pid,
            "name": proc_info.name,
            "message": "Process no longer exists",
        }
    except psutil.AccessDenied:
        return {
            "success": False,
            "pid": proc_info.pid,
            "name": proc_info.name,
            "error": "Access denied, insufficient permissions to terminate process",
        }
    except Exception as e:
        logger.error(f"Failed to terminate process: {e}", exc_info=True)
        return {
            "success": False,
            "pid": proc_info.pid,
            "name": proc_info.name,
            "error": str(e),
        }


def terminate_processes(processes: List[ProcessInfo]) -> Dict[str, Any]:
    """Terminate multiple processes.
    
    Args:
        processes: List of process information
        
    Returns:
        包含终止结果的字典
    """
    if not processes:
        return {
            "success": False,
            "message": "No matching processes found",
            "terminated": [],
            "failed": [],
        }
    
    terminated = []
    failed = []
    
    for proc_info in processes:
        result = terminate_process(proc_info)
        if result["success"]:
            terminated.append(result)
        else:
            failed.append(result)
    
    return {
        "success": len(terminated) > 0,
        "message": f"Successfully closed {len(terminated)} process(es), failed {len(failed)}",
        "terminated": terminated,
        "failed": failed,
        "total": len(processes),
    }
