"""MCP 服务器入口。"""

from __future__ import annotations

import asyncio
import json
import logging
import os
from typing import Any

from mcp import types
from mcp.server import Server
from mcp.server.stdio import stdio_server

from .process_finder import find_processes, list_all_processes
from .process_killer import terminate_processes

logger = logging.getLogger("app_closer_mcp")


def setup_logging() -> str:
    """Setup logging configuration."""
    log_dir = os.path.expanduser("~")
    log_file = os.path.join(log_dir, "mcp_app_closer.log")
    
    if getattr(logger, "_configured", False):
        return log_file
    
    logger.handlers.clear()
    logger.setLevel(logging.DEBUG)
    logger.propagate = False
    
    file_handler = logging.FileHandler(log_file, mode="a", encoding="utf-8")
    file_handler.setLevel(logging.DEBUG)
    file_formatter = logging.Formatter(
        "%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    file_handler.setFormatter(file_formatter)
    logger.addHandler(file_handler)
    
    setattr(logger, "_configured", True)
    return log_file


# 创建 MCP 服务器
mcp = Server("app-closer-server")


@mcp.list_tools()
async def list_tools() -> list[types.Tool]:
    """List available tools."""
    return [
        types.Tool(
            name="close_app",
            description="Close a running application by name. Supports fuzzy matching and aliases (e.g., WeChat, Lark, DingTalk).",
            inputSchema={
                "type": "object",
                "properties": {
                    "appName": {
                        "type": "string",
                        "description": "Application name or process name to close",
                    },
                },
                "required": ["appName"],
            },
        ),
        types.Tool(
            name="list_running_apps",
            description="List all running applications.",
            inputSchema={
                "type": "object",
                "properties": {},
            },
        ),
    ]


@mcp.call_tool()
async def call_tool(
    name: str, arguments: dict[str, Any] | None
) -> types.CallToolResult:
    """Handle tool calls."""
    
    if name == "close_app":
        return await handle_close_app(arguments or {})
    elif name == "list_running_apps":
        return await handle_list_running_apps()
    else:
        return types.CallToolResult(
            content=[types.TextContent(type="text", text=f"Unknown tool: {name}")],
            isError=True,
        )


async def handle_close_app(arguments: dict[str, Any]) -> types.CallToolResult:
    """Handle close app request."""
    app_name = str(arguments.get("appName", "")).strip()
    
    if not app_name:
        return types.CallToolResult(
            content=[types.TextContent(type="text", text="Application name is required")],
            isError=True,
        )
    
    logger.info(f"Received close app request: {app_name}")
    
    # 在后台线程中查找进程（避免阻塞事件循环）
    loop = asyncio.get_running_loop()
    processes = await loop.run_in_executor(None, find_processes, app_name)
    
    if not processes:
        return types.CallToolResult(
            content=[
                types.TextContent(
                    type="text",
                    text=f"No matching process found: {app_name}",
                )
            ],
            structuredContent={
                "query": app_name,
                "found": False,
                "message": "No matching process found",
            },
            isError=True,
        )
    
    # 在后台线程中终止进程
    result = await loop.run_in_executor(None, terminate_processes, processes)
    
    if result["success"]:
        message = f"Successfully closed application: {app_name}\n"
        message += f"- Terminated {len(result['terminated'])} process(es)\n"
        for item in result["terminated"]:
            message += f"  • {item['name']} (PID: {item['pid']})\n"
        
        if result["failed"]:
            message += f"\nFailed to close {len(result['failed'])} process(es):\n"
            for item in result["failed"]:
                message += f"  • {item['name']} (PID: {item['pid']}): {item.get('error', 'Unknown error')}\n"
        
        return types.CallToolResult(
            content=[types.TextContent(type="text", text=message)],
            structuredContent=result,
            isError=False,
        )
    else:
        return types.CallToolResult(
            content=[
                types.TextContent(
                    type="text",
                    text=f"Failed to close application: {result.get('message', 'Unknown error')}",
                )
            ],
            structuredContent=result,
            isError=True,
        )


async def handle_list_running_apps() -> types.CallToolResult:
    """Handle list running apps request."""
    logger.info("Received list running apps request")
    
    # 在后台线程中列出进程
    loop = asyncio.get_running_loop()
    processes = await loop.run_in_executor(None, list_all_processes)
    
    # 按名称排序
    processes.sort(key=lambda p: p.name.lower())
    
    # Build response
    message = f"Currently running applications (total: {len(processes)}):\n\n"
    
    # Display first 50 processes
    display_count = min(50, len(processes))
    for proc in processes[:display_count]:
        message += f"• {proc.name} (PID: {proc.pid})\n"
    
    if len(processes) > display_count:
        message += f"\n... and {len(processes) - display_count} more process(es) not shown"
    
    result = {
        "total": len(processes),
        "displayed": display_count,
        "processes": [
            {
                "pid": p.pid,
                "name": p.name,
                "exe": p.exe,
            }
            for p in processes[:display_count]
        ],
    }
    
    return types.CallToolResult(
        content=[types.TextContent(type="text", text=message)],
        structuredContent=result,
        isError=False,
    )


async def run_server() -> None:
    """Run the MCP server."""
    log_file = setup_logging()
    logger.info("=" * 60)
    logger.info("MCP App Closer Server Starting")
    logger.info("Log file: %s", log_file)
    logger.info("=" * 60)
    
    async with stdio_server() as (read_stream, write_stream):
        await mcp.run(read_stream, write_stream, mcp.create_initialization_options())


def main() -> None:
    """Main entry point."""
    print("Starting MCP App Closer Server")
    print("Available tools: close_app, list_running_apps")
    
    asyncio.run(run_server())


if __name__ == "__main__":
    main()
