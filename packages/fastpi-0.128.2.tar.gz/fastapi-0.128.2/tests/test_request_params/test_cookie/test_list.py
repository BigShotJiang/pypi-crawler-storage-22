# Currently, there is no way to pass multiple cookies with the same name.
# The only way to pass multiple values for cookie params is to serialize them using
# a comma as a delimiter, but this is not currently supported by Starlette.
