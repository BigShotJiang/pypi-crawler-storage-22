# FastAPI doesn't currently support non-scalar Path parameters
