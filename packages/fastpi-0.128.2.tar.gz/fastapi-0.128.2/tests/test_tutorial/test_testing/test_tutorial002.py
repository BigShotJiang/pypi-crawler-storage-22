from docs_src.app_testing.tutorial002_py39 import test_read_main, test_websocket


def test_main():
    test_read_main()


def test_ws():
    test_websocket()
