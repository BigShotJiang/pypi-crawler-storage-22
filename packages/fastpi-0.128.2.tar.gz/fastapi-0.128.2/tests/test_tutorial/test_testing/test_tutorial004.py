from docs_src.app_testing.tutorial004_py39 import test_read_items


def test_main():
    test_read_items()
