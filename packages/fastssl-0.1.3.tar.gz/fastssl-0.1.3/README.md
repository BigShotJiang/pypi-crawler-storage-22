# FastSSL

FastSSL 是一个用于管理SSL证书的Python SDK，支持申请、验证和获取SSL证书。

签发密钥获取渠道：ssl.aa1.cn/user/

开发者：沈阳明心科技有限公司

## 联系方式
EMail：15001904@qq.com
## 安装

```bash
pip install fastssl
```

## 快速开始

```python
from fastssl import FastSSLClient

# 初始化客户端
client = FastSSLClient(api_key="your_api_key")

# 申请SSL证书
result = client.create_certificate(
    certificate_domain="example.com",
    channel_type="zerossl",  # 可选: zerossl, letsencrypt, google
    validation_method="DNS"  # 可选TXT文件验证 FILE_HTTP
)

# 验证域名
verify_result = client.verify_domain(domain="example.com")

# 获取证书信息
cert_info = client.get_certificate_info(domain="example.com")

# 一键申请并验证（便捷方法）
full_result = client.create_and_verify(
    certificate_domain="example.com",
    channel_type="zerossl"
)
```

## API 文档

### FastSSLClient

#### `__init__(api_key: str)`

初始化FastSSL客户端。

**参数:**
- `api_key`: API密钥

#### `create_certificate(certificate_domain: str, channel_type: str = "zerossl", validation_method: str = "DNS")`

申请SSL证书。

**参数:**
- `certificate_domain`: 需要验证的域名
- `channel_type`: 证书品牌，可选值: `zerossl`, `letsencrypt`, `google`
- `validation_method`: 验证方式，默认为 `DNS`（API统一使用DNS，但实际DNS记录类型不同：
  - `zerossl` 使用 **CNAME** 记录
  - `letsencrypt`/`google` 使用 **TXT** 记录）

**返回:** 包含证书申请结果的字典

#### `verify_domain(domain: str, max_retries: int = 10, retry_interval: int = 5)`

验证域名并等待证书签发完成。如果验证成功但download_url为空，会自动重试。

**参数:**
- `domain`: 要验证的域名
- `max_retries`: 最大重试次数（当download_url为空时）
- `retry_interval`: 重试间隔（秒）

**返回:** 包含验证结果的字典

#### `get_certificate_info(domain: str)`

获取证书信息，自动处理证书内容中的换行符。

**参数:**
- `domain`: 域名

**返回:** 包含证书信息的字典

#### `create_and_verify(certificate_domain: str, channel_type: str = "zerossl", validation_method: str = "DNS", max_retries: int = 10, retry_interval: int = 5)`

一键申请并验证证书的便捷方法。

**参数:**
- `certificate_domain`: 需要验证的域名
- `channel_type`: 证书品牌
- `validation_method`: 验证方式，默认为 `DNS`
- `max_retries`: 验证最大重试次数
- `retry_interval`: 重试间隔（秒）

**返回:** 包含完整流程结果的字典

## 示例

### 基本使用

```python
from fastssl import FastSSLClient

client = FastSSLClient(api_key="your_api_key")

# 申请证书
create_result = client.create_certificate(
    certificate_domain="example.com",
    channel_type="zerossl"
)

if create_result.get("success"):
    print("证书申请成功！")
    print(f"验证信息: {create_result.get('data', {}).get('verify_info')}")
    
    # 验证域名
    verify_result = client.verify_domain("example.com")
    
    if verify_result.get("success"):
        print("证书验证成功！")
        print(f"下载地址: {verify_result.get('data', {}).get('download_url')}")
        
        # 获取证书信息
        cert_info = client.get_certificate_info("example.com")
        if cert_info.get("success"):
            print("证书内容:")
            print(cert_info.get("data", {}).get("crt_pem"))
```

### 一键申请并验证

```python
from fastssl import FastSSLClient

client = FastSSLClient(api_key="your_api_key")

result = client.create_and_verify(
    certificate_domain="example.com",
    channel_type="zerossl",
    max_retries=15,  # 最多重试15次
    retry_interval=10  # 每次间隔10秒
)

if result.get("success"):
    verify_data = result.get("verify_result", {}).get("data", {})
    print(f"证书编号: {verify_data.get('certificate_no')}")
    print(f"下载地址: {verify_data.get('download_url')}")
```

## 许可证

MIT License

## 支持

如有问题或建议，请提交Issue。
