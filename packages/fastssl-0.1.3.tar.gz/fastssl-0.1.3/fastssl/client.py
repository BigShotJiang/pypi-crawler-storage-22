"""
FastSSL客户端 - 用于与SSL证书API交互
"""

import requests
import time
from typing import Dict, Optional, Literal


class FastSSLClient:
    """FastSSL客户端类，用于管理SSL证书的申请、验证和获取"""
    
    BASE_URL = "https://ssl.aa1.cn/api/v1"
    
    def __init__(self, api_key: str):
        """
        初始化FastSSL客户端
        
        Args:
            api_key: API密钥
        """
        self.api_key = api_key
        self.session = requests.Session()
    
    def create_certificate(
        self,
        certificate_domain: str,
        channel_type: Literal["zerossl", "letsencrypt", "google"] = "zerossl",
        validation_method: str = "DNS"
    ) -> Dict:
        """
        申请SSL证书
        
        Args:
            certificate_domain: 需要验证的域名
            channel_type: 证书品牌，可选值: zerossl, letsencrypt, google
            validation_method: 验证方式，默认为DNS
        
        Returns:
            包含证书申请结果的字典
        """
        url = f"{self.BASE_URL}/create"
        
        params = {
            "api_key": self.api_key
        }
        
        data = {
            "channel_type": channel_type,
            "certificate_domain": certificate_domain,
            "validation_method": validation_method
        }
        
        try:
            # 使用 multipart/form-data 格式
            # 传入空的 files 参数以强制使用 multipart/form-data
            response = self.session.post(url, params=params, data=data, files={})
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            return {
                "success": False,
                "message": f"请求失败: {str(e)}",
                "error": str(e)
            }
    
    def verify_domain(
        self,
        domain: str,
        max_retries: int = 10,
        retry_interval: int = 5
    ) -> Dict:
        """
        验证域名并等待证书签发完成
        
        Args:
            domain: 要验证的域名
            max_retries: 最大重试次数（当download_url为空时）
            retry_interval: 重试间隔（秒）
        
        Returns:
            包含验证结果的字典
        """
        url = f"{self.BASE_URL}/verify"
        
        params = {
            "api_key": self.api_key,
            "domain": domain
        }
        
        try:
            response = self.session.get(url, params=params)
            response.raise_for_status()
            result = response.json()
            
            # 如果验证成功但download_url为空，需要重试
            if (result.get("success") and 
                result.get("data", {}).get("download_url") == "" and
                max_retries > 0):
                time.sleep(retry_interval)
                return self.verify_domain(domain, max_retries - 1, retry_interval)
            
            return result
        except requests.exceptions.RequestException as e:
            return {
                "success": False,
                "message": f"请求失败: {str(e)}",
                "error": str(e)
            }
    
    def get_certificate_info(self, domain: str) -> Dict:
        """
        获取证书信息
        
        Args:
            domain: 域名
        
        Returns:
            包含证书信息的字典，证书内容中的\n会被自动删除
        """
        url = f"{self.BASE_URL}/get_info"
        
        params = {
            "api_key": self.api_key,
            "domain": domain
        }
        
        try:
            response = self.session.get(url, params=params)
            response.raise_for_status()
            result = response.json()
            
            # 移除证书内容中的\n（包括转义的\n和实际的换行符）
            if result.get("success") and "data" in result:
                data = result["data"]
                for key in ["crt_pem", "crt_key", "crt_bundle"]:
                    if key in data and isinstance(data[key], str):
                        # 删除转义的\n和实际的换行符
                        data[key] = data[key].replace("\\n", "").replace("\n", "")
            
            return result
        except requests.exceptions.RequestException as e:
            return {
                "success": False,
                "message": f"请求失败: {str(e)}",
                "error": str(e)
            }
    
    def create_and_verify(
        self,
        certificate_domain: str,
        channel_type: Literal["zerossl", "letsencrypt", "google"] = "zerossl",
        validation_method: str = "DNS",
        max_retries: int = 10,
        retry_interval: int = 5
    ) -> Dict:
        """
        一键申请并验证证书（便捷方法）
        
        Args:
            certificate_domain: 需要验证的域名
            channel_type: 证书品牌
            validation_method: 验证方式
            max_retries: 验证最大重试次数
            retry_interval: 重试间隔（秒）
        
        Returns:
            包含完整流程结果的字典
        """
        # 第一步：申请证书
        create_result = self.create_certificate(
            certificate_domain=certificate_domain,
            channel_type=channel_type,
            validation_method=validation_method
        )
        
        if not create_result.get("success"):
            return create_result
        
        # 第二步：验证域名
        verify_result = self.verify_domain(
            domain=certificate_domain,
            max_retries=max_retries,
            retry_interval=retry_interval
        )
        
        return {
            "create_result": create_result,
            "verify_result": verify_result,
            "success": verify_result.get("success", False)
        }
