# Tests for FastTOML
