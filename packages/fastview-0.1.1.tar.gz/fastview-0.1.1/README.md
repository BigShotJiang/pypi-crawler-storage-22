# FastView ⚡

**FastView** provides an instant, auto-generated web UI for FastAPI applications. Designed for developers who want a clean, beginner-friendly alternative to Swagger UI with zero configuration.

![License](https://img.shields.io/badge/license-MIT-blue.svg)
![Python](https://img.shields.io/badge/python-3.8%2B-blue)

## Features

- 🚀 **One-Line Integration**: Just add `FastView(app)`.
- 🔌 **Automatic Server Startup**: Detects available ports and starts Uvicorn automatically.
- 🎨 **Modern UI**: Clean, responsive interface with Dark Mode by default.
- 🛠️ **Simplified Inputs**: Auto-generated forms for text, numbers, booleans, files, and JSON.
- 📂 **No Frontend Code**: We handle the HTML/CSS/JS for you.

## Installation

```bash
pip install fastview
```
*(For development, install from source)*

## Usage

1. **Install the library**:
   ```bash
   pip install fastview
   ```

2. **Integrate with your FastAPI app**:

   ```python
   from fastapi import FastAPI
   from fastview import FastView

   app = FastAPI()

   # Initialize FastView - it will auto-mount at /fastview
   FastView(app)

   @app.get("/hello")
   def hello(name: str):
       return {"message": f"Hello {name}"}
   ```

3. **Run your application** (normally):
   ```bash
   uvicorn main:app --reload
   ```

4. **Open the UI**:
   Navigate to `http://localhost:8000/fastview` in your browser.

## Screenshots

![alt text](image.png)

## Architecture

- **Backend**: Python (FastAPI, Uvicorn)
- **Frontend**: Vanilla JS, HTML5, CSS3 (No build steps required)

## Conclusion
### Built by Mehtab Singh
