from .core import FastView

__all__ = ["FastView"]
