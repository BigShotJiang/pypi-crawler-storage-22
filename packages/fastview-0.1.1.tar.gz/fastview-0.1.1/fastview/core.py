import os
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, JSONResponse
from .schema_parser import parse_openapi_schema
from .server import register_auto_start

class FastView:
    def __init__(self, app: FastAPI):
        self.app = app
        self._setup_routes()
        self._setup_frontend()
        
        # Auto-start logic
        register_auto_start(self.app)
        
    def _setup_frontend(self):
        # Mount static files
        current_dir = os.path.dirname(os.path.abspath(__file__))
        frontend_dir = os.path.join(current_dir, "frontend")
        
        self.app.mount("/fastview/static", StaticFiles(directory=frontend_dir), name="fastview_static")
        
    def _setup_routes(self):
        @self.app.get("/fastview", response_class=HTMLResponse, include_in_schema=False)
        async def fastview_ui():
            # Serve index.html but we need to inject the correct static path or ensure relative paths work.
            # Since index.html references "style.css" and "app.js", and we mount them at /fastview/static,
            # we might need to adjust the HTML or serve them directly at /fastview level if we want simple relative paths.
            # But FastAPI StaticFiles takes a directory.
            
            # Simple hack: read index.html and replace links OR serve it from the static mount?
            # If we serve /fastview/static/index.html it works but the URL is ugly.
            
            # Let's read the file and return it
            current_dir = os.path.dirname(os.path.abspath(__file__))
            index_path = os.path.join(current_dir, "frontend", "index.html")
            with open(index_path, "r", encoding="utf-8") as f:
                content = f.read()
            
            # Fix paths to point to static mount to be robust?
            # Or just ensure the browser resolves "style.css" to relative "./style.css".
            # If we are at /fastview, "./style.css" is /style.css which is wrong.
            # We need them at /fastview/style.css.
            
            # Solution: Mount specific files or a router to serve them at /fastview/filename
            # Or just replace in HTML.
            content = content.replace('href="style.css"', 'href="/fastview/static/style.css"')
            content = content.replace('src="app.js"', 'src="/fastview/static/app.js"')
            
            return content

        @self.app.get("/fastview/data", include_in_schema=False)
        async def fastview_data():
            openapi = self.app.openapi()
            payload = parse_openapi_schema(openapi)
            return JSONResponse(payload)
