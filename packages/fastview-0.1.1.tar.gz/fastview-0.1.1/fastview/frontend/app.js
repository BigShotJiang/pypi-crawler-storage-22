document.addEventListener('DOMContentLoaded', async () => {
    
    // State
    let endpoints = [];
    let currentEndpoint = null;
    
    // DOM Elements
    const methodsContainer = document.getElementById('methods-container');
    const welcomeScreen = document.getElementById('welcome-screen');
    const endpointView = document.getElementById('endpoint-view');
    
    // Header Info
    const currentMethod = document.getElementById('current-method');
    const currentPath = document.getElementById('current-path');
    const currentSummary = document.getElementById('current-summary');
    
    // Form
    const formFields = document.getElementById('form-fields');
    const requestForm = document.getElementById('request-form');
    
    // Response
    const responseContainer = document.getElementById('response-container');
    const responseCode = document.getElementById('response-code');
    const responseTime = document.getElementById('response-time');
    const responseBody = document.getElementById('response-body');
    const loader = document.getElementById('loader');
    const mediaViewport = document.getElementById('media-viewport');

    // Fetch Schema
    try {
        const res = await fetch('/fastview/data');
        endpoints = await res.json();
        renderMethods(endpoints);
    } catch (err) {
        console.error("Failed to load schema", err);
        methodsContainer.innerHTML = '<div style="padding:1rem; color:red">Failed to load API schema.</div>';
    }

    // Render Horizontal Methods
    function renderMethods(items) {
        methodsContainer.innerHTML = '';
        items.forEach((ep) => {
            const btn = document.createElement('button');
            btn.className = 'endpoint-btn';
            btn.onclick = () => selectEndpoint(ep, btn);
            
            const methodLabel = document.createElement('span');
            methodLabel.className = 'method-label';
            methodLabel.textContent = ep.method;
            methodLabel.style.color = getMethodColor(ep.method);
            
            const pathLabel = document.createElement('span');
            pathLabel.className = 'path-label';
            pathLabel.textContent = ep.path;
            
            btn.appendChild(methodLabel);
            btn.appendChild(pathLabel);
            methodsContainer.appendChild(btn);
        });
    }

    function getMethodColor(method) {
        const map = {
            'GET': '#4ade80',
            'POST': '#60a5fa',
            'PUT': '#fbbf24',
            'DELETE': '#f87171',
            'PATCH': '#c084fc'
        };
        return map[method] || '#94a3b8';
    }

    // Select Endpoint
    function selectEndpoint(ep, btnElement) {
        currentEndpoint = ep;
        
        // Reset Body Status
        document.body.className = '';
        
        // Active State
        document.querySelectorAll('.endpoint-btn').forEach(b => b.classList.remove('active'));
        if (btnElement) btnElement.classList.add('active');
        
        // UI Updates
        welcomeScreen.classList.add('hidden');
        endpointView.classList.remove('hidden');
        
        // Update Header
        currentMethod.textContent = ep.method;
        currentMethod.style.backgroundColor = getMethodColor(ep.method);
        currentPath.textContent = ep.path;
        currentSummary.textContent = ep.summary || 'No description available';
        
        // Build Form
        buildForm(ep.parameters);
        
        // Clear Response
        clearResponse();
    }

    function clearResponse() {
        responseCode.textContent = '';
        responseTime.textContent = '';
        responseBody.textContent = 'Ready to execute...';
        mediaViewport.innerHTML = '';
        loader.classList.add('hidden');
    }

    function buildForm(params) {
        formFields.innerHTML = '';
        if (!params || params.length === 0) {
            formFields.innerHTML = '<p style="color:var(--text-secondary); grid-column: 1/-1;">No parameters required.</p>';
            return;
        }

        params.forEach(param => {
            const group = document.createElement('div');
            group.className = 'form-group';
            
            const label = document.createElement('label');
            label.textContent = `${param.name}${param.required ? ' *' : ''}`;
            label.htmlFor = `input-${param.name}`;
            
            let input;
            
            // Special handling for Checkbox -> Toggle Switch
            if (param.type === 'checkbox') {
                 group.className = 'form-group checkbox-group';
                 
                 const toggleWrapper = document.createElement('label');
                 toggleWrapper.className = 'toggle-switch';
                 
                 input = document.createElement('input');
                 input.type = 'checkbox';
                 
                 const slider = document.createElement('span');
                 slider.className = 'slider';
                 
                 toggleWrapper.appendChild(input);
                 toggleWrapper.appendChild(slider);
                 
                 // Attributes
                 input.id = `input-${param.name}`;
                 input.name = param.name;
                 input.dataset.in = param.in; 
                 input.dataset.type = param.type;
                 if (param.required) input.required = true;
                 if (param.default === true) input.checked = true;

                 // Append customized structure
                 group.appendChild(label);
                 group.appendChild(toggleWrapper);
                 formFields.appendChild(group);
                 return; // Skip standard append
            }

            // ... Standard handling for other types ...
            
            if (param.type === 'json') {
                 input = document.createElement('textarea');
                 input.rows = 5;
                 input.className = 'form-control';
                 input.placeholder = JSON.stringify(param.schema || {}, null, 2);
            } else if (param.type === 'file') {
                 input = document.createElement('input');
                 input.type = 'file';
                 input.className = 'form-control'; 
            } else if (param.type === 'number') {
                 input = document.createElement('input');
                 input.type = 'number';
                 input.className = 'form-control';
                 if (param.default !== null) input.value = param.default;
            } else {
                 input = document.createElement('input');
                 input.type = 'text';
                 input.className = 'form-control';
                 if (param.default) input.value = param.default;
            }
            
            input.id = `input-${param.name}`;
            input.name = param.name;
            input.dataset.in = param.in; 
            input.dataset.type = param.type;
            
            if (param.required) input.required = true;
            
            group.appendChild(label);
            group.appendChild(input);
            formFields.appendChild(group);
        });
    }

    // Handle Submit
    requestForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        if (!currentEndpoint) return;

        // Reset UI before request
        document.body.className = ''; 
        loader.classList.remove('hidden');
        responseBody.textContent = '';
        mediaViewport.innerHTML = '';
        responseCode.textContent = '';
        responseTime.textContent = '';
        
        const startTime = performance.now();
        
        // Collect Data
        let url = currentEndpoint.path;
        const queryParams = new URLSearchParams();
        const headers = {};
        let bodyPayload = null;
        let isMultipart = false;
        
        const inputs = formFields.querySelectorAll('input, textarea');
        const formData = new FormData();
        
        inputs.forEach(input => {
            const name = input.name;
            const place = input.dataset.in;
            const type = input.dataset.type;
            let value = input.value;
            
            if (type === 'checkbox') value = input.checked;
            if (type === 'number') value = Number(value);
            
            if (type === 'file') {
                if (input.files.length > 0) {
                     value = input.files[0];
                } else {
                     value = null; 
                }
            } else if (type === 'json') {
                try {
                    value = value ? JSON.parse(value) : {};
                } catch(e) {
                     console.error("Invalid JSON");
                }
            }

            if (place === 'path') {
                url = url.replace(`{${name}}`, encodeURIComponent(value));
            } else if (place === 'query') {
                if (value !== null && value !== "") queryParams.append(name, value);
            } else if (place === 'body') {
                // Initialize bodyPayload as object if null
                if (bodyPayload === null) bodyPayload = {};
                
                // If the input is specifically the "raw JSON" type, it might replace everything or merge.
                // Our schema parser separates them: either a single "body" (json) OR multiple fields.
                
                if (type === 'json') {
                    // If it's a raw JSON input, it takes precedence or merges? 
                    // Usually it's the specific "body" param.
                    bodyPayload = value; 
                } else {
                    // It's a field (e.g. "distance_au")
                    // Ensure bodyPayload is an object
                    if (typeof bodyPayload !== 'object') bodyPayload = {};
                    bodyPayload[name] = value;
                }
                
                headers['Content-Type'] = 'application/json';
            } else if (place === 'formData') {
                isMultipart = true;
                if (value !== null) formData.append(name, value);
            }
        });
        
        // Finalize body
        if (bodyPayload && typeof bodyPayload === 'object' && !isMultipart) {
             bodyPayload = JSON.stringify(bodyPayload);
        }

        // Construct final URL
        const queryString = queryParams.toString();
        if (queryString) url += `?${queryString}`;

        const options = {
            method: currentEndpoint.method,
            headers: headers
        };
        
        if (isMultipart) {
            options.body = formData;
            delete options.headers['Content-Type']; // Let browser set boundary
        } else if (bodyPayload) {
            options.body = bodyPayload;
        }

        // Execute
        try {
            const res = await fetch(url, options);
            const endTime = performance.now();
            const duration = (endTime - startTime).toFixed(0);
            
            loader.classList.add('hidden');
            
            // STATUS FEEDBACK
            if (res.ok) {
                document.body.className = 'status-success';
            } else {
                document.body.className = 'status-error';
            }
            
            responseCode.textContent = `${res.status} ${res.statusText}`;
            responseTime.textContent = `${duration}ms`;
            
            const contentType = res.headers.get('content-type') || '';
            
            // MEDIA RENDERING FOR ML/DL
            if (contentType.startsWith('image/')) {
                const blob = await res.blob();
                const imgUrl = URL.createObjectURL(blob);
                mediaViewport.innerHTML = `<img src="${imgUrl}" alt="Response Image">`;
                responseBody.style.display = 'none';
            } 
            else if (contentType.startsWith('audio/')) {
                const blob = await res.blob();
                const audioUrl = URL.createObjectURL(blob);
                mediaViewport.innerHTML = `<audio controls src="${audioUrl}"></audio>`;
                responseBody.style.display = 'none';
            }
            else if (contentType.startsWith('video/')) {
                const blob = await res.blob();
                const videoUrl = URL.createObjectURL(blob);
                mediaViewport.innerHTML = `<video controls src="${videoUrl}"></video>`;
                responseBody.style.display = 'none';
            } 
            else {
                // Default Text/JSON
                responseBody.style.display = 'block';
                const text = await res.text();
                try {
                    const json = JSON.parse(text);
                    responseBody.textContent = JSON.stringify(json, null, 2);
                    
                    // Allow simple Base64 Image Preview in JSON
                    // Check if any key has value starting with 'data:image'
                    // This is a naive heuristic for MVP
                    checkForBase64(json);
                } catch {
                    responseBody.textContent = text;
                }
            }
            
        } catch (err) {
            loader.classList.add('hidden');
            document.body.className = 'status-error';
            responseCode.textContent = 'Error';
            responseBody.textContent = err.toString();
        }
    });
    
    function checkForBase64(json) {
        // Recursive check or just top level? Top level for now.
        for (const key in json) {
            const val = json[key];
            if (typeof val === 'string' && val.startsWith('data:image/')) {
                const img = document.createElement('img');
                img.src = val;
                img.style.maxWidth = '200px';
                img.style.marginTop = '10px';
                mediaViewport.appendChild(img);
            }
        }
    }
});
