from typing import Dict, List, Any

def parse_openapi_schema(schema: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Parses the OpenAPI schema into a simplified format for the frontend.
    """
    endpoints = []
    
    paths = schema.get("paths", {})
    for path, methods in paths.items():
        for method, details in methods.items():
            if method.lower() not in ["get", "post", "put", "delete", "patch"]:
                continue
                
            summary = details.get("summary", f"{method.upper()} {path}")
            description = details.get("description", "")
            operation_id = details.get("operationId", f"{method}_{path}")
            
            parameters = []
            
            # Handle Path/Query parameters
            if "parameters" in details:
                for param in details["parameters"]:
                    param_type = "text"
                    schema_type = param.get("schema", {}).get("type", "string")
                    
                    if schema_type == "integer" or schema_type == "number":
                        param_type = "number"
                    elif schema_type == "boolean":
                        param_type = "checkbox"
                    
                    parameters.append({
                        "name": param["name"],
                        "in": param["in"],
                        "required": param.get("required", False),
                        "type": param_type,
                        "default": param.get("schema", {}).get("default", None),
                        "description": param.get("description", "")
                    })
            
            # Handle Request Body
            if "requestBody" in details:
                content = details["requestBody"].get("content", {})
                if "application/json" in content:
                    schema_ref = content["application/json"].get("schema", {})
                    
                    # Check if it's a reference (Pydantic model)
                    if "$ref" in schema_ref:
                        ref_name = schema_ref["$ref"].split("/")[-1]
                        model_schema = (
                            schema
                            .get("components", {})
                            .get("schemas", {})
                            .get(ref_name, {})
                        )
                        props = model_schema.get("properties", {})
                        required_props = model_schema.get("required", [])

                        if props:
                            # It has properties -> Flatten them
                            for prop_name, prop_details in props.items():
                                param_type = "text"
                                prop_type = prop_details.get("type")
                                
                                if prop_type in ["integer", "number"]:
                                    param_type = "number"
                                elif prop_type == "boolean":
                                    param_type = "checkbox"
                                
                                parameters.append({
                                    "name": prop_name,
                                    "in": "body", # Treat as body field
                                    "required": prop_name in required_props,
                                    "type": param_type,
                                    "default": prop_details.get("default", None),
                                    "description": prop_details.get("description", "")
                                })
                        else:
                            # Ref exists but no properties? Fallback to JSON
                            parameters.append({
                                "name": "body",
                                "in": "body",
                                "required": details["requestBody"].get("required", False),
                                "type": "json", 
                                "schema": schema_ref,
                                "description": "Request Body"
                            })
                    else:
                        # No ref, treat as generic JSON body
                        parameters.append({
                            "name": "body",
                            "in": "body",
                            "required": details["requestBody"].get("required", False),
                            "type": "json", 
                            "schema": schema_ref,
                            "description": "Request Body"
                        })
                elif "multipart/form-data" in content:
                    form_schema = content["multipart/form-data"].get("schema", {})
                    if "$ref" in form_schema:
                        ref_name = form_schema["$ref"].split("/")[-1]
                        form_schema = (
                            schema
                            .get("components", {})
                            .get("schemas", {})
                            .get(ref_name, {})
                        )
                    props = form_schema.get("properties", {})

                    for prop_name, prop_details in props.items():
                        param_type = "text"

                        if (
                            prop_details.get("type") == "string"
                            and prop_details.get("format") == "binary"
                        ):
                            param_type = "file"
                        elif prop_details.get("type") in ["integer", "number"]:
                            param_type = "number"
                        elif prop_details.get("type") == "boolean":
                            param_type = "checkbox"

                        parameters.append({
                            "name": prop_name,
                            "in": "formData",
                            "required": prop_name in form_schema.get("required", []),
                            "type": param_type,
                            "description": prop_details.get("description", "")
                        })


            endpoints.append({
                "path": path,
                "method": method.upper(),
                "summary": summary,
                "description": description,
                "operationId": operation_id,
                "parameters": parameters
            })
            
    return endpoints
