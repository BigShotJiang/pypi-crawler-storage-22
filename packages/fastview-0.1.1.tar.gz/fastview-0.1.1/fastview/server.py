import uvicorn
import webbrowser
import threading
import sys
import contextlib
import time
import socket

def is_port_in_use(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(("localhost", port)) == 0

def start_server(app, port: int = 8000, host: str = "127.0.0.1"):
    """
    Starts the Uvicorn server if it's not already running.
    Opens the browser to the FastView UI.
    """
    url = f"http://{host}:{port}/fastview"
    
    # Open browser in a separate thread after a short delay to allow server to start
    def open_browser():
        time.sleep(1.5)
        webbrowser.open(url)
        
    # Check if we are running under uvicorn already (e.g. uvicorn main:app)
    # This is a bit tricky to detect reliably, but we can check sys.argv or if the loop is running.
    # However, the user requirement says "If not running -> start uvicorn internally".
    
    # We will assume if this function is called, we intend to start it or check it.
    # But usually this is called from `FastView.__init__` or similar? 
    # No, the requirement says "When the user runs python main.py".
    # So we should probably run this block only if name == main, but we are inside a library.
    
    # Strategy: 
    # The user code will look like:
    # app = FastAPI()
    # FastView(app)
    # ...
    # (user code ends)
    
    # If the user just runs `python main.py`, the script finishes and exits unless we block.
    # So FastView needs to handle the blocking.
    
    # We can use `atexit` or just explicit call. 
    # But the prompt says "Automatic Server Startup... No manual uvicorn commands required".
    # And "Use uvicorn.run() programmatically".
    
    # If we put `uvicorn.run()` in `FastView.__init__`, it would block immediately, 
    # preventing further routes from being added if `FastView(app)` is called before routes.
    # But typically `FastView(app)` is initialized after app creation.
    # If users add routes AFTER `FastView(app)`, valid? 
    # Ideally `FastView(app)` should be called last, OR we register an event.
    
    # Better approach:
    # We can't block in __init__. 
    # We can check if `sys.modules['__main__']` has the app object and we are in `__main__`.
    # But we don't know when the user is "done" defining routes.
    
    # A common pattern is:
    # if __name__ == "__main__":
    #     uvicorn.run(...)
    
    # The user wants "No manual uvicorn commands". 
    # "User runs `python main.py` -> FastView must... start uvicorn internally".
    
    # Maybe we can hook into `atexit`? 
    # If the script is about to exit and we haven't started, start it!
    # But `atexit` might be too late or quirky with threads.
    
    # Let's try inspecting the stack or just providing a `start()` method is safer, 
    # param 'Automatic Server Startup' implies zero boilerplate.
    
    # Let's try to detect if we are in main execution and register an atexit handler 
    # that runs uvicorn if nothing else has.
    pass

import atexit
import inspect

_server_started = False

def find_available_port(start_port: int, max_retries: int = 100) -> int:
    """Finds the first available port starting from start_port."""
    for port in range(start_port, start_port + max_retries):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            if s.connect_ex(("localhost", port)) != 0:
                return port
    raise RuntimeError("No available ports found.")

def _run_server_at_exit(app, start_port, host):
    global _server_started
    if _server_started:
        return
    
    try:
        port = find_available_port(start_port)
    except RuntimeError as e:
        print(f"FastView: {e}")
        return

    url = f"http://{host}:{port}/fastview"
    print(f"FastView: Auto-starting server at {url}")
    threading.Thread(target=lambda: (time.sleep(1), webbrowser.open(url)), daemon=True).start()
    
    try:
        # We need to set generic loop or just run. 
        # Since we might be in a script that didn't import uvicorn, we rely on uvicorn being installed.
        uvicorn.run(app, host=host, port=port, log_level="info")
    except SystemExit:
        pass
    except Exception as e:
        print(f"FastView: Error starting server: {e}")

def register_auto_start(app):
    """
    Registers the auto-start logic.
    This should be called when FastView is initialized.
    """
    # We want to check if the code instantiating FastView is the __main__ module.
    # Stack:
    # 0: register_auto_start
    # 1: FastView.__init__
    # 2: <caller in main.py>
    
    try:
        stack = inspect.stack()
        if len(stack) > 2:
            frame = stack[2]
            module = inspect.getmodule(frame[0])
            
            if module and module.__name__ == "__main__":
                # We are in the main script.
                atexit.register(_run_server_at_exit, app, 8000, "127.0.0.1")
    except Exception as e:
        print(f"FastView warning: Failed to inspect stack for auto-start: {e}")

