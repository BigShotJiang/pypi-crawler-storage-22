from setuptools import setup, find_packages

setup(
    name="fastview",
    version="0.1.1",
    description="A lightweight FastAPI visualization tool",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    include_package_data=True,

    license="MIT",

    install_requires=[
        "fastapi",
        "uvicorn",
        "pydantic"
    ],
    python_requires=">=3.8",

    # 🔥 THIS LINE IS THE FIX
    license_files=[]
)
