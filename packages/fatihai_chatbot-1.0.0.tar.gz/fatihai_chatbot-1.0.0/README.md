# FatihAI Chatbot

AI-powered chatbot client for Python applications.

[![PyPI](https://img.shields.io/pypi/v/fatihai-chatbot)](https://pypi.org/project/fatihai-chatbot/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## Features

- AI-powered conversations
- Conversation history management
- Custom system prompts
- Simple API
- Type hints included

## Installation

```bash
pip install fatihai-chatbot
```

## Quick Start

```python
from fatihai_chatbot import FatihAIChatbot

# Initialize
chatbot = FatihAIChatbot('your_api_key')

# Send message
response = chatbot.send_message('Hello!')
print(response)

# With custom system prompt
chatbot = FatihAIChatbot('your_api_key',
    system_prompt="You are a helpful sales assistant for a SaaS company."
)

# Multi-turn conversation
chatbot.chat('What are your pricing plans?')
chatbot.chat('Tell me more about the enterprise plan')
print(chatbot.get_history())

# Clear history
chatbot.clear_history()
```

## One-liner

```python
from fatihai_chatbot import chat

response = chat('your_api_key', 'What is AI?')
print(response)
```

## Pricing

| Plan | Price | Messages/month |
|------|-------|----------------|
| Starter | $299/mo | 10,000 |
| Growth | $499/mo | 50,000 |
| Enterprise | Custom | Unlimited |

## Get API Key

Sign up at [fatihai.app](https://fatihai.app/register)

## License

MIT
