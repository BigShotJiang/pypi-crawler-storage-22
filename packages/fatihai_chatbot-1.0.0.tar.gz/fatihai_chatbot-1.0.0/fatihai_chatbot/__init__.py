"""
FatihAI Chatbot - AI-powered conversational chatbot
https://fatihai.app
"""

import requests
from typing import Dict, List, Optional

__version__ = "1.0.0"
__author__ = "FatihAI"


class FatihAIChatbot:
    """AI Chatbot client for FatihAI API."""

    BASE_URL = "https://fatihai.app/api/v1"

    def __init__(self, api_key: str, **options):
        """
        Initialize the chatbot client.

        Args:
            api_key: Your FatihAI API key. Get one at https://fatihai.app
            **options: Optional configuration (system_prompt, temperature, etc.)
        """
        if not api_key:
            raise ValueError("API key is required. Get yours at https://fatihai.app")

        self.api_key = api_key
        self.options = {
            "system_prompt": options.get("system_prompt", "You are a helpful assistant."),
            "temperature": options.get("temperature", 0.7),
            "max_tokens": options.get("max_tokens", 1000),
        }
        self.messages: List[Dict] = []
        self.session = requests.Session()
        self.session.headers.update({
            "X-API-Key": api_key,
            "Content-Type": "application/json"
        })

    def chat(self, message: str) -> Dict:
        """
        Send a message and get AI response.

        Args:
            message: User message

        Returns:
            dict: Response with 'response' field containing AI reply
        """
        self.messages.append({"role": "user", "content": message})

        response = self.session.post(
            f"{self.BASE_URL}/chat",
            json={
                "message": message,
                "history": self.messages[-10:],
                "system_prompt": self.options["system_prompt"],
                "temperature": self.options["temperature"],
            },
            timeout=30
        )
        response.raise_for_status()
        data = response.json()

        self.messages.append({"role": "assistant", "content": data["response"]})
        return data

    def send_message(self, message: str) -> str:
        """
        Simple method to get just the response text.

        Args:
            message: User message

        Returns:
            str: AI response text
        """
        result = self.chat(message)
        return result.get("response", "")

    def clear_history(self) -> None:
        """Clear conversation history."""
        self.messages = []

    def set_system_prompt(self, prompt: str) -> None:
        """
        Set custom system prompt for the chatbot.

        Args:
            prompt: System prompt to define chatbot behavior
        """
        self.options["system_prompt"] = prompt

    def get_history(self) -> List[Dict]:
        """
        Get conversation history.

        Returns:
            list: List of message dictionaries with 'role' and 'content'
        """
        return self.messages.copy()


# Convenience function
def chat(api_key: str, message: str, **options) -> str:
    """Quick chat without creating client instance."""
    client = FatihAIChatbot(api_key, **options)
    return client.send_message(message)
