# FatihAI Email Verification

Fast and accurate email verification API client for Python.

[![PyPI](https://img.shields.io/pypi/v/fatihai-email-verify)](https://pypi.org/project/fatihai-email-verify/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## Features

- ✅ Real-time validation (<100ms)
- ✅ Syntax, domain, MX checks
- ✅ Disposable email detection
- ✅ 99.9% accuracy
- ✅ Type hints included

## Installation

```bash
pip install fatihai-email-verify
```

## Quick Start

```python
from fatihai_email_verify import FatihAIEmailVerify

client = FatihAIEmailVerify('your_api_key')

# Verify single email
result = client.verify('test@example.com')
print(result)
# {'valid': True, 'email': '...', 'checks': {'syntax': True, 'domain': True, 'mx': True, 'disposable': False}}

# Simple boolean check
is_valid = client.is_valid('test@example.com')
print(is_valid)  # True or False

# Check if disposable
is_disposable = client.is_disposable('temp@mailinator.com')
print(is_disposable)  # True

# Bulk verification
emails = ['a@example.com', 'b@example.com']
results = client.verify_bulk(emails)
```

## Pricing

| Plan | Verifications/month | Price |
|------|---------------------|-------|
| Starter | 1,000 | $29/mo |
| Growth | 10,000 | $59/mo |
| Business | 50,000 | $99/mo |

## Get API Key

Sign up at [fatihai.app](https://fatihai.app/register)

## License

MIT
