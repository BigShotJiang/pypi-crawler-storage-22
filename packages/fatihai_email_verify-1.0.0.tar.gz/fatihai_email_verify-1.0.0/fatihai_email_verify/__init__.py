"""
FatihAI Email Verification API Client
https://fatihai.app/tools/email-verify
"""

import requests
from typing import Dict, List, Optional

__version__ = "1.0.0"
__author__ = "FatihAI"

class FatihAIEmailVerify:
    """Email verification client for FatihAI API."""
    
    BASE_URL = "https://fatihai.app/api/v1"
    
    def __init__(self, api_key: str):
        """
        Initialize the client.
        
        Args:
            api_key: Your FatihAI API key. Get one at https://fatihai.app
        """
        if not api_key:
            raise ValueError("API key is required. Get yours at https://fatihai.app")
        self.api_key = api_key
        self.session = requests.Session()
        self.session.headers.update({
            "X-API-Key": api_key,
            "Content-Type": "application/json"
        })
    
    def verify(self, email: str) -> Dict:
        """
        Verify a single email address.
        
        Args:
            email: Email address to verify
            
        Returns:
            dict: Verification result with valid, email, and checks fields
        """
        response = self.session.post(
            f"{self.BASE_URL}/email/verify",
            json={"email": email},
            timeout=10
        )
        response.raise_for_status()
        return response.json()
    
    def verify_bulk(self, emails: List[str]) -> List[Dict]:
        """
        Verify multiple email addresses.
        
        Args:
            emails: List of email addresses to verify
            
        Returns:
            list: List of verification results
        """
        results = []
        for email in emails:
            try:
                result = self.verify(email)
                results.append(result)
            except Exception as e:
                results.append({"email": email, "error": str(e)})
        return results
    
    def is_valid(self, email: str) -> bool:
        """
        Check if email is valid (simple boolean).
        
        Args:
            email: Email address to check
            
        Returns:
            bool: True if valid, False otherwise
        """
        result = self.verify(email)
        return result.get("valid", False)
    
    def is_disposable(self, email: str) -> bool:
        """
        Check if email is from a disposable provider.
        
        Args:
            email: Email address to check
            
        Returns:
            bool: True if disposable, False otherwise
        """
        result = self.verify(email)
        return result.get("checks", {}).get("disposable", False)


# Convenience function
def verify(api_key: str, email: str) -> Dict:
    """Quick verification without creating client instance."""
    client = FatihAIEmailVerify(api_key)
    return client.verify(email)
