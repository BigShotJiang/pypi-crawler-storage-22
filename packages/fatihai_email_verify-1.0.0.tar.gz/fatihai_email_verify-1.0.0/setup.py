from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="fatihai-email-verify",
    version="1.0.0",
    author="FatihAI",
    author_email="support@fatihai.app",
    description="Fast and accurate email verification API client",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://fatihai.app/tools/email-verify",
    project_urls={
        "Bug Tracker": "https://github.com/fatihdagustu20-hub/email-verify-sdk/issues",
        "Documentation": "https://fatihai.app/docs",
        "Source": "https://github.com/fatihdagustu20-hub/email-verify-sdk",
    },
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Communications :: Email",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    packages=find_packages(),
    python_requires=">=3.7",
    install_requires=[
        "requests>=2.25.0",
    ],
    keywords="email verification validation api fatihai disposable mx-check",
)
