
{
    "version": "2026.2.11",
    "target": "default",
    "variant": "cpu"
}
