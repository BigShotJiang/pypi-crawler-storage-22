
{
    "version": "2026.2.13",
    "target": "default",
    "variant": "cpu"
}
