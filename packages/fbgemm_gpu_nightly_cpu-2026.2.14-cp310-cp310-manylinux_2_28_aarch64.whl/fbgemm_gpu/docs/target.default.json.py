
{
    "version": "2026.2.14",
    "target": "default",
    "variant": "cpu"
}
