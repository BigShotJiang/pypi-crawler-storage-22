#!/usr/bin/env python3
"""
Demo: How to Update Prediction Labels via API

This script shows how to:
1. Make predictions and get prediction UUIDs
2. Send feedback when predictions are wrong
3. View prediction history and corrections

QUICK API REFERENCE:

# Make predictions (automatically stores with UUID)
result = predictor.predict(record)
prediction_uuid = result.prediction_uuid

# Correct wrong predictions via PredictionResult
feedback = result.send_feedback(ground_truth="correct_label")
feedback.send()

# Or correct via the client directly
featrix.prediction_feedback(prediction_uuid, "correct_label")
"""

import argparse

from featrixsphere.api import FeatrixSphere


def demo_label_updates():
    """Demonstrate how to update prediction labels via API."""

    parser = argparse.ArgumentParser(description="Prediction label update demo")
    parser.add_argument("--fm-id", type=str, default="20250623-124806_4591e7",
                        help="Foundational model ID with trained predictor")
    parser.add_argument("--compute-cluster", "--compute", type=str, default=None,
                        help="Compute cluster to use")
    args = parser.parse_args()

    fm_id = args.fm_id

    print("=" * 64)
    print("PREDICTION LABEL UPDATE DEMO")
    print("=" * 64)

    # Initialize client
    featrix = FeatrixSphere(
        "https://sphere-api.featrix.com",
        compute_cluster=args.compute_cluster,
    )

    # Get the foundational model and its predictor
    fm = featrix.foundational_model(fm_id)
    predictors = fm.list_predictors()

    if not predictors:
        print(f"No predictors found for foundational model {fm_id}")
        return

    predictor = predictors[0]

    print(f"\n1. Making predictions to get UUIDs...")

    # Test records for fuel card detection
    test_records = [
        {"domain": "shell.com", "snippet": "fuel card rewards program for drivers", "keyword": "fuel card"},
        {"domain": "walmart.com", "snippet": "grocery shopping and retail store", "keyword": "shopping"},
        {"domain": "bp.com", "snippet": "fleet fuel cards for business vehicles", "keyword": "fleet cards"},
        {"domain": "amazon.com", "snippet": "buy electronics and gadgets online", "keyword": "electronics"},
        {"domain": "exxon.com", "snippet": "gas station locator and fuel services", "keyword": "gas station"},
    ]

    prediction_results = []

    for i, record in enumerate(test_records):
        try:
            # Make prediction - automatically stored with UUID
            result = predictor.predict(record)
            prediction_results.append(result)

            print(f"  Record {i+1}: {result.predicted_class} ({result.confidence*100:.1f}% confidence)")
            print(f"     UUID: {result.prediction_uuid}")
            print(f"     Input: {record['domain']} - {record['snippet'][:50]}...")
            print()

        except Exception as e:
            print(f"  Error with record {i+1}: {e}")

    print(f"\n2. Updating prediction labels...")

    # Simulate user corrections based on domain knowledge
    corrections = [
        ("True", "Shell is a fuel company - this should be True"),
        ("False", "Walmart is retail, not fuel cards - this should be False"),
        ("True", "BP fleet cards are definitely fuel cards - this should be True"),
        ("False", "Amazon electronics has nothing to do with fuel - this should be False"),
        ("True", "Exxon gas stations typically have fuel cards - this should be True")
    ]

    corrections_made = 0

    for i, (result, (correct_label, reason)) in enumerate(zip(prediction_results, corrections)):
        try:
            original_prediction = result.predicted_class

            print(f"  Updating prediction {i+1}...")
            print(f"     UUID: {result.prediction_uuid}")
            print(f"     Original: {original_prediction} ({result.confidence*100:.1f}%)")
            print(f"     Correcting to: {correct_label}")
            print(f"     Reason: {reason}")

            # Send feedback via the PredictionResult object
            if result.prediction_uuid:
                feedback = result.send_feedback(ground_truth=correct_label)
                response = feedback.send()
                print(f"     Done: Feedback sent")
                corrections_made += 1

                # Show if this was actually a correction
                if original_prediction != correct_label:
                    print(f"     CORRECTION: {original_prediction} -> {correct_label}")
                else:
                    print(f"     Confirmed: Prediction was already correct")
            else:
                print(f"     Skipped: No prediction UUID available")
            print()

        except Exception as e:
            print(f"     Error updating: {e}")

    print(f"\n3. Getting predictor metrics...")

    try:
        metrics = predictor.get_metrics()
        if metrics:
            print(f"  Training metrics retrieved successfully")
            sp_metrics = metrics.get('single_predictor', {})
            if sp_metrics:
                print(f"  Accuracy: {sp_metrics.get('accuracy')}")
                print(f"  AUC: {sp_metrics.get('roc_auc') or sp_metrics.get('auc')}")
    except Exception as e:
        print(f"  Error retrieving metrics: {e}")

    print(f"\n" + "=" * 64)
    print(f"PREDICTION FEEDBACK DEMO COMPLETED")
    print(f"=" * 64)
    print(f"What you learned:")
    print(f"   1. Every prediction gets a UUID automatically (result.prediction_uuid)")
    print(f"   2. Use result.send_feedback(ground_truth=label) to correct")
    print(f"   3. Or use featrix.prediction_feedback(uuid, label) directly")
    print(f"   4. Feedback is used to improve model accuracy over time")
    print()
    print(f"Key API Patterns:")
    print(f"   # Make prediction")
    print(f"   result = predictor.predict(record)")
    print(f"   print(result.predicted_class, result.confidence)")
    print(f"")
    print(f"   # Send correction feedback")
    print(f"   feedback = result.send_feedback(ground_truth='correct_label')")
    print(f"   feedback.send()")
    print(f"")
    print(f"   # Or use the client directly")
    print(f"   featrix.prediction_feedback(result.prediction_uuid, 'correct_label')")
    print()
    print(f"Production Tips:")
    print(f"   - Store prediction UUIDs for all production predictions")
    print(f"   - Collect user feedback systematically")
    print(f"   - Monitor correction rates to detect model drift")
    print(f"   - Use batch predictions for better performance")

def show_api_examples():
    """Show quick API usage examples."""

    print("\n" + "=" * 60)
    print("QUICK API EXAMPLES")
    print("=" * 60)

    print("""
# 1. Initialize client
from featrixsphere.api import FeatrixSphere
featrix = FeatrixSphere("https://sphere-api.featrix.com")

# 2. Get foundational model and predictor
fm = featrix.foundational_model("your-fm-id")
predictors = fm.list_predictors()
predictor = predictors[0]

# 3. Make prediction (gets UUID automatically)
result = predictor.predict({"domain": "shell.com", "snippet": "fuel cards"})
print(result.predicted_class)   # "True"
print(result.confidence)        # 0.92
print(result.prediction_uuid)   # UUID for feedback

# 4. Correct wrong prediction (method 1: from result)
feedback = result.send_feedback(ground_truth="True")
feedback.send()

# 5. Correct wrong prediction (method 2: from client)
featrix.prediction_feedback(result.prediction_uuid, "True")

# 6. Batch predictions (more efficient)
records = [{"domain": "bp.com"}, {"domain": "amazon.com"}]
results = predictor.batch_predict(records)
for r in results:
    print(r.predicted_class, r.confidence)

# 7. Predict from CSV file
results = predictor.predict_csv_file("test_data.csv")
for r in results:
    print(r.predicted_class, r.confidence)
""")

if __name__ == "__main__":
    demo_label_updates()
    show_api_examples()
