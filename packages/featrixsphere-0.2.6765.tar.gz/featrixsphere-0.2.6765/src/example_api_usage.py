#!/usr/bin/env python3
"""
Example API Usage

Simple examples of how to use the Featrix Sphere API client
for common tasks and workflows.
"""

import argparse
from pathlib import Path

from featrixsphere.api import FeatrixSphere


def example_1_basic_model(featrix):
    """Example 1: Create a foundational model and check its status."""

    print("=== Example 1: Basic Foundational Model Management ===")

    try:
        # Check server health
        health = featrix.health_check()
        print(f"Server health: {health}")
    except Exception as e:
        print(f"Server error - {e}")


def example_2_file_upload(featrix):
    """Example 2: Upload a file and create a foundational model."""

    print("\n=== Example 2: File Upload ===")

    # Upload a file (modify path as needed)
    test_file = Path("featrix_data/test.csv")

    if test_file.exists():
        try:
            fm = featrix.create_foundational_model(data_file=str(test_file))
            print(f"File uploaded, foundational model created: {fm.id}")

            # Monitor progress briefly
            fm.refresh()
            print(f"Initial status: {fm.status}")
        except Exception as e:
            print(f"Upload error - this would upload: {test_file}")
    else:
        print(f"Test file not found: {test_file}")
        print("This would upload a CSV file and create a foundational model")


def example_3_make_prediction(featrix, fm_id):
    """Example 3: Make a prediction (requires trained predictor)."""

    print("\n=== Example 3: Making Predictions ===")

    # Example query record
    query_record = {
        "column1": "some_value",
        "column2": 42.0,
        "column3": "another_value"
    }

    try:
        # Get the foundational model and its predictors
        fm = featrix.foundational_model(fm_id)
        predictors = fm.list_predictors()

        if predictors:
            predictor = predictors[0]
            result = predictor.predict(query_record)
            print(f"Predicted class: {result.predicted_class}")
            print(f"Confidence: {result.confidence}")
        else:
            print("No predictors found for this foundational model")

    except Exception as e:
        print(f"Prediction failed (expected if no real foundational model): {e}")


def example_4_encoding_and_search(featrix, fm_id):
    """Example 4: Encode records and perform similarity search."""

    print("\n=== Example 4: Encoding and Similarity Search ===")

    query_record = {
        "feature1": "example",
        "feature2": 123.45
    }

    try:
        fm = featrix.foundational_model(fm_id)

        # Encode a record
        embeddings = fm.encode(query_record)
        print(f"Encoding dimension: {len(embeddings[0]) if embeddings else 0}")

        # Find similar records via vector database
        vdb = fm.create_vector_database()
        results = vdb.similarity_search(query_record, k=5)
        print(f"Found {len(results)} similar records")

    except Exception as e:
        print(f"Encoding/search failed (expected if no real foundational model): {e}")


def example_5_monitor_training(featrix, fm_id):
    """Example 5: Monitor training progress."""

    print("\n=== Example 5: Training Monitoring ===")

    try:
        fm = featrix.foundational_model(fm_id)
        info = fm.refresh()
        print(f"Foundational model status: {fm.status}")
        print(f"Dimensions: {fm.dimensions}")
        print(f"Epochs: {fm.epochs}")

        # If training is complete, get metrics
        if fm.status == 'done':
            try:
                metrics = fm.get_training_metrics()
                print("Training metrics retrieved successfully")
            except Exception as e:
                print(f"No training metrics available: {e}")

    except Exception as e:
        print(f"Status check failed (expected if no real foundational model): {e}")


def example_6_complete_workflow(featrix):
    """Example 6: Complete workflow simulation."""

    print("\n=== Example 6: Complete Workflow (Simulation) ===")

    print("This example shows the complete workflow:")
    print("1. Upload data -> Create foundational model")
    print("2. Wait for training completion")
    print("3. Create classifier")
    print("4. Make predictions")
    print("5. Get training metrics")
    print("6. Perform similarity search")

    print("\nTo run this for real:")
    print("  from featrixsphere.api import FeatrixSphere")
    print("  featrix = FeatrixSphere('https://sphere-api.featrix.com')")
    print("  fm = featrix.create_foundational_model(data_file='data.csv')")
    print("  fm.wait_for_training()")
    print("  predictor = fm.create_binary_classifier(target_column='target')")
    print("  predictor.wait_for_training()")
    print("  result = predictor.predict({'feature': 'value'})")
    print("  print(result.predicted_class, result.confidence)")


def main():
    """Run all examples."""

    parser = argparse.ArgumentParser(description="Featrix Sphere API usage examples")
    parser.add_argument("--fm-id", type=str, default="your-fm-id-here",
                        help="Foundational model ID for examples that need one")
    parser.add_argument("--compute-cluster", "--compute", type=str, default=None,
                        help="Compute cluster to use")
    args = parser.parse_args()

    print("Featrix Sphere API Client Examples")
    print("=" * 40)

    featrix = FeatrixSphere(
        "https://sphere-api.featrix.com",
        compute_cluster=args.compute_cluster,
    )

    # Run examples that don't require a real foundational model
    example_1_basic_model(featrix)
    example_2_file_upload(featrix)

    # Show examples that would work with real foundational models
    example_3_make_prediction(featrix, args.fm_id)
    example_4_encoding_and_search(featrix, args.fm_id)
    example_5_monitor_training(featrix, args.fm_id)
    example_6_complete_workflow(featrix)

    print("\n" + "=" * 40)
    print("Examples completed!")
    print("\nTo test with real data:")
    print("1. Start the API server")
    print("2. Upload a CSV and create a foundational model")
    print("3. Train a classifier and make predictions")


if __name__ == "__main__":
    main()
