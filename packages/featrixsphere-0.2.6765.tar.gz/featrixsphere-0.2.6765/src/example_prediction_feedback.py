#!/usr/bin/env python3
"""
Example: Prediction Feedback and Retraining System

This script demonstrates how to:
1. Make predictions that are stored with UUIDs
2. Send feedback when predictions are wrong
3. Build a feedback loop for model improvement
"""

import argparse

from featrixsphere.api import FeatrixSphere


def demonstrate_feedback_system():
    """Demonstrate the complete prediction feedback workflow."""

    parser = argparse.ArgumentParser(description="Prediction feedback demo")
    parser.add_argument("--fm-id", type=str, default="20250623-124806_4591e7",
                        help="Foundational model ID with trained predictor")
    parser.add_argument("--compute-cluster", "--compute", type=str, default=None,
                        help="Compute cluster to use")
    args = parser.parse_args()

    fm_id = args.fm_id

    print("=" * 64)
    print("PREDICTION FEEDBACK & RETRAINING DEMO")
    print("=" * 64)

    # Initialize client
    featrix = FeatrixSphere(
        "https://sphere-api.featrix.com",
        compute_cluster=args.compute_cluster,
    )

    # Get the foundational model and its predictor
    fm = featrix.foundational_model(fm_id)
    predictors = fm.list_predictors()

    if not predictors:
        print(f"No predictors found for foundational model {fm_id}")
        return

    predictor = predictors[0]

    print(f"\n1. Making predictions with feedback tracking...")

    # Example test records
    test_records = [
        {"domain": "shell.com", "snippet": "fuel card rewards program for drivers", "keyword": "fuel card"},
        {"domain": "exxon.com", "snippet": "gas station locator near you", "keyword": "gas station"},
        {"domain": "amazon.com", "snippet": "buy books and electronics online", "keyword": "shopping"},
        {"domain": "bp.com", "snippet": "fleet fuel cards for business", "keyword": "fleet cards"},
        {"domain": "chevron.com", "snippet": "find chevron gas stations", "keyword": "gas station"},
    ]

    # Known correct labels for demonstration
    correct_labels = ["True", "False", "False", "True", "False"]

    prediction_results = []

    for i, record in enumerate(test_records):
        try:
            # Make prediction (stored with UUID automatically)
            result = predictor.predict(record)

            prediction_results.append(result)

            print(f"  Record {i+1}: {result.predicted_class} ({result.confidence*100:.1f}% confidence)")
            print(f"    Prediction UUID: {result.prediction_uuid}")
            print(f"    Input: {record}")
            print()

        except Exception as e:
            print(f"  Error with record {i+1}: {e}")

    print(f"\n2. Sending feedback for incorrect predictions...")

    # Send feedback where the model got it wrong
    corrections_made = 0

    for i, (result, correct_label) in enumerate(zip(prediction_results, correct_labels)):
        if result.predicted_class != correct_label and result.prediction_uuid:
            try:
                # Use the PredictionResult's built-in feedback method
                feedback = result.send_feedback(ground_truth=correct_label)
                feedback.send()
                corrections_made += 1
                print(f"  Sent correction for record {i+1}: {result.predicted_class} -> {correct_label}")
            except Exception as e:
                print(f"  Error sending feedback for record {i+1}: {e}")
        elif result.prediction_uuid:
            # Can also send confirmation feedback via the client directly
            try:
                featrix.prediction_feedback(
                    prediction_uuid=result.prediction_uuid,
                    ground_truth=correct_label,
                )
                print(f"  Confirmed prediction for record {i+1}: {correct_label}")
            except Exception as e:
                print(f"  Error confirming prediction for record {i+1}: {e}")

    print(f"\n" + "=" * 64)
    print(f"FEEDBACK SYSTEM SUMMARY")
    print(f"=" * 64)
    print(f"Predictions made: {len(prediction_results)}")
    print(f"Corrections sent: {corrections_made}")
    print()
    print(f"Next steps for production:")
    print(f"   - Build UI for users to correct predictions")
    print(f"   - Monitor prediction accuracy over time")
    print(f"   - Use prediction_feedback() for every verified prediction")
    print(f"   - Store prediction UUIDs for all production predictions")
    print()
    print(f"Feedback loop established for continuous model improvement!")


if __name__ == "__main__":
    demonstrate_feedback_system()
