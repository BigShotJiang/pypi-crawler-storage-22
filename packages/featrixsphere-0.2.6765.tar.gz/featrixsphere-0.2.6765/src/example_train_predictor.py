#!/usr/bin/env python3
"""
Example: Add Classifier Training to Existing Foundational Model

This script demonstrates how to add classifier training to a foundational
model that already has a trained embedding space.
"""

import argparse
import sys

from featrixsphere.api import FeatrixSphere


def main():
    parser = argparse.ArgumentParser(
        description="Add classifier training to an existing foundational model",
        epilog="Example:\n"
               "  python example_train_predictor.py --fm-id 20250620-162402_fb593f "
               "--target-column is_fuel_card_reference --target-type set --epochs 100",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--fm-id", type=str, required=True,
                        help="ID of foundational model with trained embedding space")
    parser.add_argument("--target-column", type=str, required=True,
                        help="Name of target column to predict")
    parser.add_argument("--target-type", type=str, required=True, choices=["set", "scalar"],
                        help="'set' for categorical or 'scalar' for numeric")
    parser.add_argument("--epochs", type=int, default=0,
                        help="Number of training epochs (0 = auto)")
    parser.add_argument("--compute-cluster", "--compute", type=str, default=None,
                        help="Compute cluster to use")
    args = parser.parse_args()

    fm_id = args.fm_id
    target_column = args.target_column
    target_type = args.target_type
    epochs = args.epochs

    print("=" * 60)
    print("Adding Classifier Training to Foundational Model")
    print("=" * 60)
    print(f"Foundational Model ID: {fm_id}")
    print(f"Target Column: {target_column}")
    print(f"Target Type: {target_type}")
    print(f"Training Epochs: {epochs}")
    print()

    # Initialize the client
    featrix = FeatrixSphere(
        "https://sphere-api.featrix.com",
        compute_cluster=args.compute_cluster,
    )

    try:
        # 1. Check foundational model status first
        print("1. Checking foundational model status...")
        fm = featrix.foundational_model(fm_id)
        info = fm.refresh()

        print(f"   Status: {fm.status}")
        print(f"   Dimensions: {fm.dimensions}")
        print(f"   Epochs: {fm.epochs}")

        # Check if foundational model is ready
        if fm.status != 'done':
            print(f"Error: Foundational model must be fully trained first!")
            print(f"   Current status: {fm.status}")
            sys.exit(1)

        # Check if already has predictor
        existing_predictors = fm.list_predictors()
        if existing_predictors:
            print(f"   Existing predictors: {len(existing_predictors)}")
            for p in existing_predictors:
                print(f"      - {p.target_column} ({p.target_type}): {p.status}")

        print()

        # 2. Start classifier training
        print("2. Starting classifier training...")
        if target_type == "set":
            predictor = fm.create_binary_classifier(
                target_column=target_column,
                epochs=epochs,
            )
        else:
            predictor = fm.create_regressor(
                target_column=target_column,
                epochs=epochs,
            )

        print(f"   Classifier training started!")
        print()

        # 3. Monitor training progress
        print("3. Training started! You can monitor progress with:")
        print(f"   python check_training_results.py --fm-id {fm_id}")
        print()
        print("4. Once training is complete, you can make predictions with:")
        print(f"   from featrixsphere.api import FeatrixSphere")
        print(f"   featrix = FeatrixSphere('https://sphere-api.featrix.com')")
        print(f"   fm = featrix.foundational_model('{fm_id}')")
        print(f"   predictors = fm.list_predictors()")
        print(f"   result = predictors[0].predict({{'column': 'value'}})")
        print(f"   print(result.predicted_class, result.confidence)")
        print()
        print(f"5. Or view the model info page at:")
        print(f"   https://sphere-api.featrix.com/info/{fm_id}")

    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
