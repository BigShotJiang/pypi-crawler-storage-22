"""
Checkpoint validation utilities for SinglePredictor.

This module provides functionality to:
1. Sample representative predictions during validation (spanning the probability space)
2. Store these samples with checkpoint pickles
3. Verify predictions match after loading a checkpoint

The validation ensures that checkpoints load correctly and produce consistent predictions.
"""

import logging
import random
from typing import Dict, List, Optional, Tuple, Any

import numpy as np

logger = logging.getLogger(__name__)


# Maximum samples to collect during validation (before distilling to representative set)
MAX_VALIDATION_SAMPLES = 250

# Number of representative samples to store with checkpoint (min, Q1, Q2, Q3, max)
NUM_REPRESENTATIVE_SAMPLES = 5


def _convert_numeric_strings(data: Any, _count: List[int] = None) -> Tuple[Any, int]:
    """
    Convert numeric strings back to numbers in a dict/list structure.

    When storing to epoch_predictions.db, json.dumps with default=str converts
    numpy types (int64, float64, etc.) to strings. This function converts them back.

    Args:
        data: Dict, list, or scalar value
        _count: Internal counter list (do not pass externally)

    Returns:
        Tuple of (converted data, number of conversions made)
    """
    # Initialize counter on first call
    is_top_level = _count is None
    if is_top_level:
        _count = [0]

    if isinstance(data, dict):
        result = {k: _convert_numeric_strings(v, _count)[0] for k, v in data.items()}
    elif isinstance(data, list):
        result = [_convert_numeric_strings(v, _count)[0] for v in data]
    elif isinstance(data, str):
        # Try to convert string to number
        # First try int, then float
        try:
            # Check if it looks like an integer (no decimal point)
            if '.' not in data and 'e' not in data.lower():
                result = int(data)
            else:
                result = float(data)
            _count[0] += 1
        except ValueError:
            # Not a numeric string, return as-is
            result = data
    else:
        result = data

    if is_top_level:
        return result, _count[0]
    return result, 0  # Only return count at top level


def select_sample_indices(
    total_count: int,
    max_samples: int = MAX_VALIDATION_SAMPLES,
    epoch: Optional[int] = None
) -> List[int]:
    """
    Randomly select up to max_samples indices from a validation set.

    Uses epoch as seed to ensure different samples each validation pass,
    but reproducible within the same epoch.

    Args:
        total_count: Total number of samples in validation set
        max_samples: Maximum number of samples to select
        epoch: Current epoch number (used as random seed for reproducibility)

    Returns:
        List of randomly selected indices (sorted)
    """
    if total_count <= max_samples:
        return list(range(total_count))

    # Use epoch as seed for reproducibility but different samples each epoch
    if epoch is not None:
        rng = random.Random(epoch * 12345 + 7919)  # Prime-based mixing
        indices = rng.sample(range(total_count), max_samples)
    else:
        indices = random.sample(range(total_count), max_samples)
    return sorted(indices)


def collect_validation_sample(
    index: int,
    query: Dict,
    result: Dict,
    ground_truth: Any
) -> Dict:
    """
    Collect a single validation sample with its prediction result.

    Args:
        index: Original index in validation set
        query: The input query dict (without target column)
        result: The prediction result dict (with 'probabilities')
        ground_truth: The actual ground truth value

    Returns:
        Sample dict with query, result, ground_truth, and max_prob
    """
    # Extract maximum probability for sorting/ranking later
    max_prob = 0.0
    pos_prob = None
    if 'probabilities' in result:
        probs = result['probabilities']
        if probs:
            max_prob = max(probs.values())
            # Also store the probability values themselves
            pos_prob = probs

    return {
        'index': index,
        'query': query,
        'result': result,
        'ground_truth': ground_truth,
        'max_prob': max_prob,
    }


def select_representative_samples(
    samples: List[Dict],
    n_representatives: int = NUM_REPRESENTATIVE_SAMPLES
) -> List[Dict]:
    """
    Select representative samples spanning the probability space.

    Picks samples at min, Q1, median, Q3, and max probability levels.

    Args:
        samples: List of collected validation samples
        n_representatives: Number of representative samples to select

    Returns:
        List of representative samples
    """
    if not samples:
        return []

    if len(samples) <= n_representatives:
        return samples

    # Sort by max probability
    sorted_samples = sorted(samples, key=lambda x: x.get('max_prob', 0.0))
    n = len(sorted_samples)

    # Select at quantile positions: min, Q1, Q2 (median), Q3, max
    # For n=5, positions are 0%, 25%, 50%, 75%, 100%
    if n_representatives == 1:
        # Just return the first sample
        positions = [0]
    elif n_representatives == 5:
        positions = [0, n // 4, n // 2, 3 * n // 4, n - 1]
    else:
        # General case: evenly spaced positions
        positions = [int(i * (n - 1) / (n_representatives - 1)) for i in range(n_representatives)]

    # Ensure unique positions (in case of small sample sizes)
    positions = sorted(set(positions))

    return [sorted_samples[i] for i in positions]


def store_validation_samples(fsp, samples: List[Dict]) -> None:
    """
    Store representative validation samples on the SinglePredictor instance.

    These will be included in the checkpoint pickle via __getstate__.

    Args:
        fsp: SinglePredictor instance
        samples: List of representative samples to store
    """
    fsp._checkpoint_validation_samples = samples
    logger.info(f"💾 Stored {len(samples)} representative validation samples for checkpoint verification")

    # Log the probability distribution of stored samples
    if samples:
        probs = [s.get('max_prob', 0.0) for s in samples]
        logger.info(f"   Probability range: [{min(probs):.4f}, {max(probs):.4f}]")


def _load_samples_from_epoch_db(fsp, max_samples: int = 5, epoch: Optional[int] = None) -> List[Dict]:
    """
    Load representative samples from epoch_predictions.db as fallback.

    Selects samples from the specified epoch (or best epoch if not specified)
    spanning the probability space.

    Args:
        fsp: SinglePredictor instance
        max_samples: Maximum number of samples to load
        epoch: Specific epoch to load from (if None, uses checkpoint's best epoch or db's best)

    Returns:
        List of sample dicts with query, result, ground_truth
    """
    import sqlite3
    import json
    import os

    # Get db path
    output_dir = getattr(fsp, '_output_dir', None)
    if not output_dir:
        return []

    db_path = os.path.join(output_dir, "epoch_predictions.db")
    if not os.path.exists(db_path):
        return []

    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        # Determine which epoch to use
        target_epoch = epoch
        epoch_source = "specified"

        if target_epoch is None:
            # Try to get the checkpoint's best epoch
            target_epoch = getattr(fsp, '_best_auc_epoch', None)
            if target_epoch is not None and target_epoch >= 0:
                epoch_source = "checkpoint _best_auc_epoch"
            else:
                # Fall back to db's best epoch
                cursor.execute('''
                    SELECT epoch_idx, auc FROM epochs
                    WHERE auc IS NOT NULL
                    ORDER BY auc DESC
                    LIMIT 1
                ''')
                row = cursor.fetchone()
                if row:
                    target_epoch = row[0]
                    epoch_source = "db best AUC"

        if target_epoch is None:
            conn.close()
            logger.warning("⚠️  Could not determine epoch to load from epoch_predictions.db")
            return []

        # Get AUC for logging
        cursor.execute('SELECT auc FROM epochs WHERE epoch_idx = ?', (target_epoch,))
        auc_row = cursor.fetchone()
        auc_str = f", AUC={auc_row[0]:.4f}" if auc_row and auc_row[0] else ""

        logger.info(f"📂 Loading samples from epoch_predictions.db (epoch {target_epoch} via {epoch_source}{auc_str})")

        # Check what tables exist
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [row[0] for row in cursor.fetchall()]
        logger.debug(f"   Tables in db: {tables}")

        # Check if samples table has input_json
        has_samples_table = 'samples' in tables
        has_input_json = False
        if has_samples_table:
            cursor.execute("PRAGMA table_info(samples)")
            columns = [row[1] for row in cursor.fetchall()]
            has_input_json = 'input_json' in columns
            logger.debug(f"   samples table columns: {columns}")

        # Get predictions from that epoch with their probabilities
        if has_samples_table and has_input_json:
            # New format: samples table has input_json
            cursor.execute('''
                SELECT p.sample_idx, s.input_json, p.probability_json, p.ground_truth
                FROM predictions p
                JOIN samples s ON p.sample_idx = s.sample_idx
                WHERE p.epoch_idx = ?
                ORDER BY p.sample_idx
            ''', (target_epoch,))
        elif has_samples_table:
            # Old format: samples table exists but no input_json - try sample_input from predictions
            cursor.execute("PRAGMA table_info(predictions)")
            pred_columns = [row[1] for row in cursor.fetchall()]
            if 'sample_input' in pred_columns:
                logger.debug("   Using sample_input from predictions table (old format)")
                cursor.execute('''
                    SELECT p.sample_idx, p.sample_input, p.probability_json, p.ground_truth
                    FROM predictions p
                    WHERE p.epoch_idx = ?
                    ORDER BY p.sample_idx
                ''', (target_epoch,))
            else:
                logger.warning(f"   ⚠️  No input_json in samples and no sample_input in predictions - cannot load samples")
                conn.close()
                return []
        else:
            # No samples table - try sample_input from predictions directly
            cursor.execute("PRAGMA table_info(predictions)")
            pred_columns = [row[1] for row in cursor.fetchall()]
            logger.debug(f"   predictions table columns: {pred_columns}")
            if 'sample_input' in pred_columns:
                logger.debug("   Using sample_input from predictions table (no samples table)")
                cursor.execute('''
                    SELECT p.sample_idx, p.sample_input, p.probability_json, p.ground_truth
                    FROM predictions p
                    WHERE p.epoch_idx = ?
                    ORDER BY p.sample_idx
                ''', (target_epoch,))
            else:
                logger.warning(f"   ⚠️  No samples table and no sample_input in predictions - cannot load samples")
                conn.close()
                return []

        rows = cursor.fetchall()
        conn.close()

        if not rows:
            logger.warning(f"   ⚠️  Query returned 0 rows for epoch {target_epoch}")
            return []

        logger.debug(f"   Found {len(rows)} rows in epoch {target_epoch}")

        # Parse and collect samples
        all_samples = []
        for sample_idx, input_json, prob_json, ground_truth in rows:
            try:
                query = json.loads(input_json) if input_json else {}
                probs = json.loads(prob_json) if prob_json else {}

                # Skip samples with error data (from failed predictions during training)
                if 'error' in probs:
                    continue

                # Note: numeric string conversion is handled in predict_batch()
                # so we don't need to do it here - the query can contain strings
                # like "42" and they'll be converted before encoding

                # Get max probability for sorting - convert strings to floats
                prob_values = []
                for v in probs.values():
                    try:
                        prob_values.append(float(v) if isinstance(v, str) else v)
                    except (ValueError, TypeError):
                        continue
                max_prob = max(prob_values) if prob_values else 0.0

                all_samples.append({
                    'index': sample_idx,
                    'query': query,
                    'result': {'probabilities': probs},
                    'ground_truth': ground_truth,
                    'max_prob': max_prob,
                    '_query_metadata': {
                        'source': 'epoch_predictions_db',
                    },
                })
            except (json.JSONDecodeError, TypeError) as e:
                logger.debug(f"Skipping sample {sample_idx}: {e}")
                continue

        if not all_samples:
            return []

        # Select representative samples spanning probability space
        representative = select_representative_samples(all_samples, max_samples)
        logger.info(f"   Selected {len(representative)} representative samples from {len(all_samples)} total")

        return representative

    except Exception as e:
        logger.warning(f"⚠️  Failed to load samples from epoch_predictions.db: {e}")
        return []


def verify_checkpoint_predictions(
    fsp,
    tolerance: float = 1e-4,
    log_details: bool = True
) -> Tuple[bool, List[Dict]]:
    """
    Verify that predictions match after loading a checkpoint.

    Re-runs predictions on stored validation samples and compares results.
    Falls back to epoch_predictions.db if no samples are stored in checkpoint.

    Args:
        fsp: SinglePredictor instance (after loading)
        tolerance: Maximum allowed difference in probabilities
        log_details: Whether to log detailed comparison info

    Returns:
        Tuple of (success: bool, mismatches: List[Dict])
    """
    samples = getattr(fsp, '_checkpoint_validation_samples', None)

    if not samples:
        # Try loading from epoch_predictions.db as fallback
        logger.info("ℹ️  No validation samples in checkpoint - checking epoch_predictions.db...")
        samples = _load_samples_from_epoch_db(fsp)

    if not samples:
        logger.warning("⚠️  No validation samples available (neither in checkpoint nor epoch_predictions.db)")
        return True, []

    logger.info(f"🔍 Verifying {len(samples)} checkpoint validation samples...")

    mismatches = []
    max_diff = 0.0

    for i, sample in enumerate(samples):
        try:
            query = sample['query']
            expected_result = sample['result']

            # Debug: log query types
            string_fields = [(k, type(v).__name__) for k, v in query.items() if isinstance(v, str)][:3]
            if string_fields:
                logger.debug(f"   Sample {i}: string fields before predict: {string_fields}")

            # Re-run prediction
            actual_result = fsp.predict(query, debug_print=False)

            # Compare probabilities
            expected_probs = expected_result.get('probabilities', {})
            actual_probs = actual_result.get('probabilities', {})

            sample_max_diff = 0.0
            prob_diffs = {}

            # Check each probability
            for key in set(list(expected_probs.keys()) + list(actual_probs.keys())):
                expected_p = expected_probs.get(key, 0.0)
                actual_p = actual_probs.get(key, 0.0)
                # Convert to float in case values are strings (from JSON serialization)
                # Handle corrupted data gracefully (e.g., error messages stored as values)
                try:
                    expected_p = float(expected_p) if isinstance(expected_p, str) else expected_p
                    actual_p = float(actual_p) if isinstance(actual_p, str) else actual_p
                except ValueError:
                    logger.warning(f"   ⚠️  Sample {i}: Corrupted probability data for key '{key}', skipping comparison")
                    continue
                diff = abs(expected_p - actual_p)
                prob_diffs[key] = diff
                sample_max_diff = max(sample_max_diff, diff)

            max_diff = max(max_diff, sample_max_diff)

            if sample_max_diff > tolerance:
                mismatches.append({
                    'sample_index': i,
                    'original_index': sample.get('index'),
                    'expected_probs': expected_probs,
                    'actual_probs': actual_probs,
                    'max_diff': sample_max_diff,
                    'prob_diffs': prob_diffs,
                })

                if log_details:
                    logger.warning(f"   ❌ Sample {i}: max_diff={sample_max_diff:.6f} > tolerance={tolerance}")
                    logger.warning(f"      Expected: {expected_probs}")
                    logger.warning(f"      Actual:   {actual_probs}")
            else:
                if log_details:
                    logger.debug(f"   ✅ Sample {i}: max_diff={sample_max_diff:.6f}")

        except Exception as e:
            import traceback
            logger.error(f"   ❌ Sample {i}: Error during prediction: {e}")
            logger.error(f"   Full traceback:\n{traceback.format_exc()}")
            mismatches.append({
                'sample_index': i,
                'original_index': sample.get('index'),
                'error': str(e),
            })

    success = len(mismatches) == 0

    if success:
        logger.info(f"✅ Checkpoint verification PASSED: {len(samples)} samples, max_diff={max_diff:.6f}")
    else:
        logger.error(f"❌ Checkpoint verification FAILED: {len(mismatches)}/{len(samples)} samples had mismatches")
        logger.error(f"   Max probability difference: {max_diff:.6f}")

    return success, mismatches


class ValidationSampleCollector:
    """
    Context manager / helper class to collect validation samples during metrics computation.

    Usage:
        collector = ValidationSampleCollector(total_queries=len(queries), epoch=epoch_idx)
        for i, (query, result, gt) in enumerate(zip(queries, results, ground_truth)):
            collector.maybe_collect(i, query, result, gt)
        representative_samples = collector.get_representative_samples()
    """

    def __init__(
        self,
        total_queries: int,
        epoch: Optional[int] = None,
        max_samples: int = MAX_VALIDATION_SAMPLES
    ):
        """
        Initialize the collector.

        Args:
            total_queries: Total number of queries in validation set
            epoch: Current epoch number (for reproducible but varying samples)
            max_samples: Maximum samples to collect before distillation
        """
        self.total_queries = total_queries
        self.epoch = epoch
        self.sample_indices = set(select_sample_indices(total_queries, max_samples, epoch))
        self.collected_samples: List[Dict] = []

        logger.debug(f"ValidationSampleCollector: will collect {len(self.sample_indices)}/{total_queries} samples (epoch={epoch})")

    def should_collect(self, index: int) -> bool:
        """Check if this index should be collected."""
        return index in self.sample_indices

    def maybe_collect(
        self,
        index: int,
        query: Dict,
        result: Dict,
        ground_truth: Any
    ) -> None:
        """
        Collect sample if it's in the selected indices.

        Args:
            index: Index in the validation set
            query: Query dict (without target column)
            result: Prediction result dict
            ground_truth: Actual ground truth value
        """
        if index in self.sample_indices:
            sample = collect_validation_sample(index, query, result, ground_truth)
            self.collected_samples.append(sample)

    def get_representative_samples(
        self,
        n_representatives: int = NUM_REPRESENTATIVE_SAMPLES
    ) -> List[Dict]:
        """
        Get the representative samples spanning the probability space.

        Args:
            n_representatives: Number of representative samples

        Returns:
            List of representative samples
        """
        return select_representative_samples(self.collected_samples, n_representatives)


class CheckpointFileExistsError(Exception):
    """Raised when attempting to write a checkpoint to a path that already exists."""
    pass


def validate_checkpoint_path_for_write(
    file_path: str,
    allow_overwrite: bool = False,
    raise_on_exists: bool = True
) -> Tuple[bool, Optional[str]]:
    """
    Validate that a checkpoint path is safe to write to.

    This function checks if the file already exists and handles the situation
    according to the allow_overwrite flag.

    Args:
        file_path: The path where we want to write the checkpoint
        allow_overwrite: If True, allows overwriting existing files
        raise_on_exists: If True and file exists and allow_overwrite=False, raises error

    Returns:
        Tuple of (is_safe_to_write: bool, error_message: Optional[str])

    Raises:
        CheckpointFileExistsError: If file exists, allow_overwrite=False, and raise_on_exists=True
    """
    import os

    if not file_path:
        return False, "Empty file path provided"

    # Check if file already exists
    if os.path.exists(file_path):
        if allow_overwrite:
            logger.warning(f"⚠️  Checkpoint file exists and will be overwritten: {file_path}")
            return True, None
        else:
            error_msg = f"Checkpoint file already exists (refusing to overwrite): {file_path}"
            logger.error(f"🛑 {error_msg}")
            if raise_on_exists:
                raise CheckpointFileExistsError(error_msg)
            return False, error_msg

    # Check if parent directory exists
    parent_dir = os.path.dirname(file_path)
    if parent_dir and not os.path.exists(parent_dir):
        try:
            os.makedirs(parent_dir, exist_ok=True)
            logger.debug(f"Created checkpoint directory: {parent_dir}")
        except Exception as e:
            error_msg = f"Failed to create checkpoint directory {parent_dir}: {e}"
            logger.error(error_msg)
            return False, error_msg

    return True, None


def safe_checkpoint_write(
    file_path: str,
    write_func,
    allow_overwrite: bool = False,
    description: str = "checkpoint"
) -> bool:
    """
    Safely write a checkpoint file with overwrite protection.

    This is a wrapper that validates the path, then calls the provided write function.

    Args:
        file_path: Path to write the checkpoint
        write_func: Callable that takes file_path and writes the checkpoint
        allow_overwrite: If True, allows overwriting existing files
        description: Description of what's being saved (for logging)

    Returns:
        True if successfully written, False otherwise

    Raises:
        CheckpointFileExistsError: If file exists and allow_overwrite=False
    """
    import os

    # Validate path
    is_safe, error_msg = validate_checkpoint_path_for_write(
        file_path,
        allow_overwrite=allow_overwrite,
        raise_on_exists=True
    )

    if not is_safe:
        logger.error(f"Cannot write {description}: {error_msg}")
        return False

    try:
        write_func(file_path)

        # Verify write succeeded
        if not os.path.exists(file_path):
            logger.error(f"❌ {description} file was not created: {file_path}")
            return False

        file_size = os.path.getsize(file_path)
        if file_size == 0:
            logger.error(f"❌ {description} file is empty: {file_path}")
            # Clean up empty file
            try:
                os.remove(file_path)
            except:
                pass
            return False

        logger.info(f"✅ {description} saved: {file_path} ({file_size / 1024 / 1024:.2f} MB)")
        return True

    except CheckpointFileExistsError:
        raise  # Re-raise file exists errors
    except Exception as e:
        logger.error(f"❌ Failed to write {description}: {e}")
        # Clean up partial file if it exists
        if os.path.exists(file_path):
            try:
                os.remove(file_path)
                logger.debug(f"Cleaned up partial {description} file")
            except:
                pass
        raise
