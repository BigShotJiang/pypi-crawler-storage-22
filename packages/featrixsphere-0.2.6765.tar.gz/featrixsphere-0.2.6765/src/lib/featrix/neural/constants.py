#  -*- coding: utf-8 -*-
#
#  Copyright Featrix, Inc 2023-2025
#
#  Proprietary and Confidential.  Unauthorized use, copying or dissemination
#  of these materials is strictly prohibited.
#
"""
Shared constants for the neural encoding system.

This module provides a single source of truth for strategy names and counts
used across the various encoder and relationship operations modules.
"""

# Scalar encoder strategies (matches AdaptiveScalarEncoder encoding order)
SCALAR_STRATEGY_NAMES = [
    'linear', 'log', 'robust', 'rank', 'periodic', 'bucket',
    'is_positive', 'is_negative', 'is_outlier', 'zscore', 'minmax',
    'quantile', 'yeojohnson', 'winsor', 'sigmoid', 'inverse',
    'polynomial', 'frequency', 'target_bin', 'clipped_log'
]
N_SCALAR_STRATEGIES = len(SCALAR_STRATEGY_NAMES)

# String encoder strategies (matches StringEncoder compression_levels)
STRING_STRATEGY_NAMES = ['ZERO', 'RADIX', 'SCALAR', 'AGGRESSIVE', 'MODERATE', 'STANDARD']
N_STRING_STRATEGIES = len(STRING_STRATEGY_NAMES)

# Set encoder component names
SET_COMPONENT_NAMES = ['LEARNED', 'SEMANTIC', 'ORDINAL']
N_SET_COMPONENTS = len(SET_COMPONENT_NAMES)
