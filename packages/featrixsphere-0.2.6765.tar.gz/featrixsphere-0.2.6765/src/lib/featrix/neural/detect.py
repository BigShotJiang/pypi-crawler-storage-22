#
#  -*- coding: utf-8 -*-
#
#  Copyright Featrix, Inc 2023-2025
#
#  Proprietary and Confidential.  Unauthorized use, copying or dissemination
#  of these materials is strictly prohibited.
#

import logging
import math
import random
import sys
import traceback
from datetime import datetime
from enum import IntEnum
from enum import unique
import torch

import numpy as np
import pandas as pd
from dateutil.parser import parse as DateUtilParse
from pytimeparse import parse as DateIntervalParse  # pip install pytimeparse

logger = logging.getLogger(__name__)


def isnan_or_null_no_crash(x):
    try:
        return math.isnan(x)
    except:
        if x is None:
            return True
    if x == "nan" or x == "NaN":
        return True
    return False


@unique
class ColumnType(IntEnum):
    SCALAR = 0
    SET = 1
    TIMESTAMP = 2
    LIST_OF_SETS = 3
    FREE_STRING = 4
    EMAIL = 5
    TIME_INTERVAL = 6
    DOMAIN = 7
    VECTOR = 8
    JSON = 9
    PHONE = 10
    URL = 11
    ZIP_CODE = 12
    FIPS_CODE = 13
    YEAR_JSON = 14  # JSON dicts with year keys like {"2020": 100, "2021": 200}
    GEO_JSON = 15   # JSON dicts with FIPS/zip/area code keys


from babel.numbers import parse_decimal, parse_number
from sklearn.preprocessing import OneHotEncoder  # LabelBinarizer, LabelEncoder,


def _isNumber(s):
    """
    This function is a big part of Featrix IP. Guard it with your life!
    """
    # Check for None values first to avoid TypeError in float() conversion
    if s is None:
        return (False, None)
    
    if type(s) == int or type(s) == float:
        return (True, s)

    if type(s) == bool:
        return (True, s)

    if type(s) == list:
        return (False, None)

    # Convert to string if not already (handles numpy arrays, etc.)
    if not isinstance(s, str):
        try:
            s = str(s)
        except Exception:
            # Can't convert to string, can't be a number
            return (False, None)
    
    # Now s is guaranteed to be a string
    try:
        if len(s) == 0:
            return (False, None)
        
        if s[0] == "$":
            s = s[1:]
    except Exception as ee:
        traceback.print_exc()
        pass

    try:
        if s.find(",") >= 0:
            # NOTE: the locale functions in Python do not do this accurately!!!
            # TODO: consider handling (xxx) as a negative number.
            # TODO: doesn't handle scientific notation (e.g., "6.28e23" with some comma in it.)
            # TODO: doesn't handle European numbers
            if s[0] == "-":
                # negatives ok. same rules apply.
                s = s[1:]
            elif s[0] == "+":
                s = s[1:]
            # need to check for proper commas
            # first chop decimal
            decFirstPos = s.find(".")
            decLastPos = s.rfind(".")
            if decFirstPos >= 0:
                if decFirstPos != decLastPos:
                    # we have too many decimals. Maybe we're in Europe.. or maybe the string is something else.
                    return (False, "too many decimal points")

                decPos = decLastPos
                decPart = s[decPos:]
                if decPart.find(",") >= 0:
                    # we have a comma after the decimal point.
                    return (False, "comma after decimal")
                integerPart = s[:decPos]
            else:
                integerPart = s

            # print("integerPart...", integerPart)
            parts = integerPart.split(",")
            # print(parts)
            # OK the first part can be < 3
            # none of the parts can be > 3
            #
            if len(parts) > 1:
                if len(parts[0]) > 3:
                    return (False, "first part is > 3 wide")
                for i in range(1, len(parts)):
                    if len(parts[i]) != 3:
                        return (False, "part %s (%s) is != 3 wide" % (i, parts[i]))
                # ensure all are numeric
                for p in parts:
                    if not p.isnumeric():
                        return (False, "part __%s__ is not numeric" % p)

            s = s.replace(",", "")
            # print("... looking good:", parts, "-->", s)
        # endif
    except:
        traceback.print_exc()

    try:
        # Python 3.6+ allows underscores in numeric literals (e.g., 1_000_000)
        # but we don't want to treat strings like "0001_01" (IDs) as numbers
        if "_" in s:
            return (False, "contains underscore - likely an ID, not a number")
        f = float(s)
        # print("f = ", f)
        if math.isnan(f):
            return (False, "got nan")
        if f == float("inf") or f == float("-inf"):
            # We ended up with something crazy in the conversion.
            return (False, "hit infinity")
        return (True, f)
    except ValueError as e:
        # print("CAUGHT VALUE ERROR:")
        # traceback.print_exc()
        pass
    # try:
    #    # This will actually parse a European number into an American one... not helpful.
    #    f = float(parse_decimal(s, locale='en_US'))
    #    print("f... = ", f)
    #    return (True, f)
    # except:
    #    pass
    #     try:
    #         f = parse_decimal(s, locale='de') # EU numbers
    #         return (True, f)
    #     except:
    #         pass
    return (False, None)


class FeatrixFieldBaseDetection(object):
    """Base class for feature enrichment"""

    def __init__(
        self,
        colSample,
        numUniques=-1,
        numNotNulls=-1,
        debugColName=None,
        detectorName=None,
    ):
        if numUniques == -1:
            print("missing uniques...", numUniques)
            numUniques = len(set(colSample))
        if numNotNulls == -1:
            print("missing not nulls...", numUniques)
            n = 0
            for x in colSample:
                if x == x:
                    n += 1
                numNotNulls = n

        self._numUniques = numUniques
        self._numNulls = len(colSample) - numNotNulls
        self._numNotNulls = numNotNulls
        self._debugColName = debugColName
        self.colSample = colSample  # FIXME: make a copy/
        self.type_name = detectorName
        self._confidence = 0  # Set by child's try_parsing()
        self.codec_name = "NOT SET"
        # self._casted_values = None
        self._meta_description = None
        self.sample_debug_str = "<none>"
        self.debug_info = {}
        self.has_casted_values = False
        self._casted_values = None

    def get_col_sample(self):
        try:
            d = self.colSample.value_counts().nlargest(10).to_dict()
            return d
        except (TypeError, ValueError) as e:
            # Handle unhashable types (like numpy arrays) by converting to strings
            try:
                # Convert to string representation for unhashable types
                str_col = self.colSample.astype(str)
                d = str_col.value_counts().nlargest(10).to_dict()
                return d
            except Exception:
                # If that also fails, return None
                logger.warning(f"Could not get col sample for {self._debugColName}: {e}")
                return None

    def get_meta_description(self):
        return self._meta_description

    def get_debug_info(self):
        self.debug_info["numUniques"] = self._numUniques
        self.debug_info["numNotNulls"] = self._numNotNulls
        self.debug_info["numNulls"] = self._numNulls
        self.debug_info["codec_name"] = self.codec_name

        return self.debug_info

    def confidence(self):
        """Returns the confidence [0, 1] that the passed data column sample is parseable by this class."""
        return self._confidence

    def try_parsing(self):
        raise NotImplementedError("child class needs to implement try_parsing")

    def get_type_name(self):
        return self.type_name

    def get_col_name(self):
        return self._debugColName

    def free_memory(self):
        logger.info(f"---------------------------------------- {self._debugColName}: clearing casted values cache")
        self._casted_values = None
        return
    
    def cast_values(self, df_col):
        #self._casted_values = df_col
        print(f"WARNING: no cast_values implemented: {self}")
        return df_col #self._casted_values  # None means we don't need to convert anything...

    # def get_casted_values(self):
    #     #        if self._casted_values is None:
    #     #            return df_col # pass through the input.
    #     return self._casted_values

    def get_codec_name(self):
        return self.codec_name

    def is_encodeable(self):
        # print(f"... {self._debugColName} --> {self.codec_name}")
        return self.codec_name is not None



def parse_floats_properly(s):
    if s != s:
        return s
    
    if s is None:
        return s
    
    if (type(s) == float):
        return s
    
    had_vector_parts = 0
    if s[0] == "[":
        s = s[1:]
        had_vector_parts += 1
    if s[-1] == "]":
        s = s[:-1]
        had_vector_parts += 1
    if (had_vector_parts != 2):
        raise StopIteration()
    
    parts = s.split(",")
    fl = []
    for p in parts:
        try:
            fl.append(float(p))
        except ValueError as ex:
            # Don't print debug info or exit() - just raise StopIteration to indicate parsing failed
            raise StopIteration()
    
    result = torch.tensor(fl)
    return result

class FeatrixVectorEmbeddingDetection(FeatrixFieldBaseDetection):
    DETECTOR_NAME = "vector"
    def __init__(self, colSample, numUniques=-1, numNotNulls=-1, debugColName=None):
        super().__init__(
            colSample=colSample,
            numUniques=numUniques,
            numNotNulls=numNotNulls,
            debugColName=debugColName,
            detectorName="vector",
        )

        # if len(colSample) > 1_000:
        #     pass

        # print(f"colSample {len(colSample)} ... = ", colSample[:5])
        # for idx, x in enumerate(colSample):
        #     if idx > 50:
        #         break
        #     print(type(x));
        
        # self._uniques = None
        self.has_casted_values = True
        self.codec_name = "vector"

        self.num_samples = len(colSample)
        self.has_list = []

        self.best_len = []
        sampled_counts = 0

        numErrors = 0
        self._needs_cast = False
        self._casted_values = None

        for c in colSample:
            if sampled_counts > 1_000:
                self.num_samples = sampled_counts
                break
            # Handle NaN check - numpy arrays can't use c != c (returns array, not bool)
            if isinstance(c, np.ndarray):
                # For numpy arrays, check if it's None or empty
                if c is None or c.size == 0:
                    continue
                # For float arrays, check for NaN
                if c.dtype.kind == 'f' and np.isnan(c).any():
                    continue
            elif c is None:
                continue
            else:
                # For scalars and other types, use standard NaN check
                try:
                    if c != c:  # Standard NaN check (works for float('nan'))
                        continue
                except (ValueError, TypeError):
                    # If comparison fails (e.g., array-like), assume valid
                    pass
            sampled_counts += 1
            try:
                if type(c) == list:
                    self.best_len.append(len(c))
                    self.has_list.append(True)
                elif type(c) == str:
                    try:
                        float_list = parse_floats_properly(c)
                        # print(len(float_list))
                        self.best_len.append(len(float_list))
                        self.has_list.append(True)
                    except:
                        numErrors += 1
                        self.has_list = []
            except:
                self.has_list = []
                #print("ERROR!... do we care?")
                pass    # not a list.
        # 
        # print("VECTOR RESULTS.... ")

        # if numErrors > 0:
            # print(f"{debugColName}: Vector detection: {numErrors} errors out of {len(colSample)} samples")

        self.try_parsing()

    def get_input_embedding_length(self):
        print(f"{self._debugColName} get_input_embedding_length: BEST_LEN = ", self.best_len[0])
        return self.best_len[0]

    def try_parsing(self):
        if len(self.has_list) == 0:
            self._confidence = 0
        if len(self.has_list) == self.num_samples:
            self._confidence = 1.
        else:
            if self.num_samples > 0:
                self._confidence = 0 # it's gotta be perfect or nothing. float(len(self.has_list)) / float(self.num_samples)
        # print(f"VECTOR DETECTOR --> {self._confidence}")
        return #self._casted_values

    def cast_values(self, df_col):
        logger.info(f"... VECTOR CASTING --> {self._needs_cast} -->")
        if not self._needs_cast:
            try:
                r = []
                X = df_col.to_list()
                for idx, xx in enumerate(X):
                    # Handle NaN check for numpy arrays and scalars
                    is_nan = False
                    if xx is None:
                        is_nan = True
                    elif isinstance(xx, np.ndarray):
                        # For numpy arrays, check if empty or contains NaN
                        if xx.size == 0:
                            is_nan = True
                        elif xx.dtype.kind == 'f' and np.isnan(xx).any():
                            is_nan = True
                    else:
                        # For scalars, use standard NaN check
                        try:
                            if xx != xx:  # Standard NaN check
                                is_nan = True
                        except (ValueError, TypeError):
                            # If comparison fails, assume valid
                            pass
                    
                    if is_nan:
                        r.append(None)
                    else:
                        r.append(torch.tensor(xx))
                return r
            except Exception as ex:
                print("ERRRRR")
                X = df_col.to_list()
                for idx, xx in enumerate(X):
                    if xx is None: print(idx)
                print("crash")
                #exit(2)
        return df_col #self._casted_values


        # print("VECTOR CASTING: getting started on... ", self._debugColName, "no casted values" if self._casted_values is None else "got something!", "length of col = ", len(df_col))
        # print(f"VECTOR CASTING {self}")   

        # if self._casted_values is not None:
        #     return self._casted_values
        # _casted_values = None
        
        # try:
        #     _casted_values = df_col.apply(parse_floats_properly)
        #     print(f"VECTOR CASTING  ... {len(_casted_values)}; {type(_casted_values[0])}")
        # except Exception as err:
        #     #traceback.print_exc()
        #     print(f"VECTOR CASTING We crashed on some nonsense that doesn't matter but let's go! [{err}]")

        # try:
        #     print("VECTOR CASTING:", self._debugColName, len(df_col))
        #     print("VECTOR CASTING:", self._debugColName, type(_casted_values[0]), len(_casted_values[0]))
        #     print("VECTOR CASTING:", self._debugColName, type(_casted_values[0][0]), _casted_values[0][0])
        # except Exception as err:
        #     print(f"VECTOR CASTING: crashed in debug prints [{err}]")

        # # print("VECTOR CASTING:", self._debugColName, _casted_values[0])
        # self._casted_values = _casted_values
        # return self._casted_values

class FeatrixFreeStringDetection(FeatrixFieldBaseDetection):
    DETECTOR_NAME = "free_string"

    def __init__(self, colSample, numUniques=-1, numNotNulls=-1, debugColName=None):
        super().__init__(
            colSample=colSample,
            numUniques=numUniques,
            numNotNulls=numNotNulls,
            debugColName=debugColName,
            detectorName="free_string",
        )
        # self._uniques = None
        self._bertEncodeLength = 8
        self.codec_name = "free_string"
        self.try_parsing()

    def get_bert_length(self):
        return self._bertEncodeLength

    def try_parsing(self):
        # We look for a large sample of strings.
        # then across the samples, do we see shared elements across delimited values?

        # number of uniques
        d = self.get_col_sample() #self.colSample.value_counts().nlargest(10).to_dict()
        if d is None:
            return
        d_total = sum(d.values())
        self.debug_info["value_counts_10_largest"] = d
        self.debug_info["value_counts_10_weight"] = d_total

        colSample = self.colSample.copy()
        colSample = colSample.dropna()
        colSample = colSample.astype("str")
        strLens = colSample.str.len()
        self.debug_info["str_len_value_counts"] = strLens.value_counts().to_dict()
        # nonzeroStrLens = strLens.nonzero()
        minStrLen = strLens.min()
        maxStrLen = strLens.max()
        theMean = strLens.mean()
        if math.isnan(theMean):
            theMean = 0
        theMedian = strLens.median()
        if math.isnan(theMedian):
            theMedian = 0
        meanStrLen = math.ceil(theMean)
        medianStrLen = math.ceil(theMedian)
        quant75StrLen = strLens.quantile(0.75)
        if math.isnan(quant75StrLen):
            quant75StrLen = 0
        stdStrLen = strLens.std()
        if math.isnan(stdStrLen):
            stdStrLen = 0

        bertMaxLength = math.ceil(meanStrLen + (2 * stdStrLen))
        # It's tempting to put a max on bertMaxLength of maxStrLen, but
        # what if our sample is a bit below reality?
        if bertMaxLength > 32:
            if meanStrLen > 32:
                bertMaxLength = min(bertMaxLength, 256)  # don't go over.
            else:
                bertMaxLength = min(bertMaxLength, 32)
        else:
            if bertMaxLength > 16:
                bertMaxLength = 32
            elif bertMaxLength > 8:
                bertMaxLength = 16
            else:
                bertMaxLength = 8
        self.debug_info["min_str_len"] = minStrLen
        self.debug_info["max_str_len"] = maxStrLen
        self.debug_info["mean_str_len"] = meanStrLen
        self.debug_info["median_str_len"] = medianStrLen
        self.debug_info["quantile75_str_len"] = quant75StrLen
        self.debug_info["std_str_len"] = stdStrLen
        self.debug_info["bertMaxLength"] = bertMaxLength

        self._bertEncodeLength = bertMaxLength
        self._confidence = (
            0.5  # if other guys are less than 50% confident, we will use this
        )
        return

    def cast_values(self, df_col):
        """Cast values for free string detection - convert to string."""
        # For free strings, we just ensure everything is string type
        _casted_values = df_col.astype(str)
        return _casted_values


# class FeatrixFieldListsOfASetDetection(FeatrixFieldBaseDetection):
#     def __init__(self, colSample, numUniques=-1, numNotNulls=-1, debugColName=None):
#         super().__init__(
#             colSample=colSample,
#             numUniques=numUniques,
#             numNotNulls=numNotNulls,
#             debugColName=debugColName,
#             detectorName="lists_of_a_set",
#         )
#         # self._uniques = None
#         self.codec_name = "lists_of_a_set"
#         self.delimiterToken = None
#         self.partsCountDict = None
#         self.try_parsing()

#     def get_meta_description(self):
#         return "delimter: __%s__; number symbols = %s" % (
#             self.delimiterToken,
#             len(self.partsCountDict),
#         )

#     def get_delimiter(self):
#         return self.delimiterToken

#     def try_parsing(self):
#         # print(self._debugColName, ": try_parsing entered")
#         # We look for a large sample of strings.
#         # then across the samples, do we see shared elements across delimited values?
#         # print("LIST OF SET: ", type(self.colSample))

#         d = self.get_col_sample() #self.colSample.value_counts().nlargest(10).to_dict()
#         if d is None:
#             return

#         d_total = sum(d.values())
#         self.debug_info["value_counts_10_largest"] = d
#         self.debug_info["value_counts_10_weight"] = d_total

#         _uniques = set(self.colSample[self.colSample.notnull()].astype(str))

#         lenUniques = len(_uniques)

#         delimiterList = [",", ";", "-", "/"]  # " ", 31 Oct 2023 -- removing space for now.
#         delimitResults = {}

#         fullPartsCount = {}

#         for d in delimiterList:
#             numPartsDict = {}
#             totalGroups = 0
#             groupsOfThree = 0  # if there's a lot of these, probably a scalar.

#             partsCount = {}
#             # explodedParts = []
#             for v in _uniques:
#                 if type(v) != str:
#                     continue
#                 if v == "" or v.isspace():
#                     continue
#                 if d == ",":
#                     if len(v) > 3:
#                         if (
#                             v[0] == "$"
#                         ):  # HACK: cutting off $ on numbers for 3s counting.
#                             v = v[1:]
#                 parts = v.split(d)

#                 existing = numPartsDict.get(len(parts), 0)
#                 numPartsDict[len(parts)] = existing + 1

#                 if d == ",":
#                     lastPart = parts[-1]
#                     decPos = lastPart.find(".")
#                     if decPos > 0:  # HACK: cut off decimal point of end
#                         lastPart = lastPart[0:decPos]
#                         parts[-1] = lastPart
#                     # print(parts)
#                 for p in parts:
#                     p_trim = p.strip()
#                     existing = partsCount.get(p_trim, 0)
#                     partsCount[p_trim] = existing + 1

#                     totalGroups += 1
#                     if d == ",":
#                         if len(p) == 3 and p.isnumeric():
#                             groupsOfThree += 1
#                     # endif
#                 # endfor
#             # endfor

#             # if self._debugColName == "Title" and d == " ":
#             #    print("... partsCount = ", len(partsCount))
#             # print(d, ": TOTAL GROUPS = ", totalGroups, "; THREEs = ", groupsOfThree)

#             # FIXME: if groupsOfThree > 1/3rd of totalGroups, it's probably a number.
#             # FIXME: this is all crazy bad. :-) Locales, etc.

#             # if they are all length 1, it's not a list.
#             if numPartsDict.get(1, 0) >= (lenUniques * 0.5):
#                 continue
#             # print(self._debugColName, ": ", "'%s'" % d, ": numPartsDict = ", numPartsDict)
#             # if True and self._debugColName == "Title":
#             ##    for k, v in partsCount.items():
#             #        if v > 5:
#             #            print(k, "-->", v)
#             #            print(partsCount)

#             if groupsOfThree >= (0.33 * lenUniques):
#                 continue  # print("lists of a set -- LOOKS LIKE A SCALAR! -- ignoring")
#             else:
#                 # or more simply... if the num unique parts is < 0.5% of the uniques?

#                 numUniqueParts = len(partsCount)
#                 # print("numUniqueParts = ", numUniqueParts)
#                 # If we have a high number of unique parts
#                 if numUniqueParts > len(_uniques):
#                     # we have more unique parts than we have combinations --> no reduction of entropy here.
#                     reductionRatio = 0
#                 else:
#                     # We want to drive a low number of uniques (away from the unique combos) higher
#                     # so we do 1.0 - ratio
#                     reductionRatio = 1.0 - (float(numUniqueParts) / float(lenUniques))
#                 delimitResults[d] = reductionRatio
#                 fullPartsCount[d] = partsCount

#             # endif

#         #
#         # if self._debugColName == "Title":
#         #    print("lenUniques... = ", lenUniques)
#         #    print(self.colSample)

#         self._confidence = 0.0

#         if len(delimitResults) > 0:
#             maxValue = max(delimitResults.values())
#             for k, v in delimitResults.items():
#                 # print("try_parsing: RESULTS: ", v, maxValue)
#                 if v == maxValue:
#                     # print("try_parsing: SETTING...")
#                     self.delimiterToken = k
#                     self.partsCountDict = fullPartsCount.get(k)
#                     self._confidence = v
#                     break
#         # print("try_parsing: token = ", self.delimiterToken, "; confidence = ", self._confidence)
#         # print(delimitResults)
#         # print("try_parsing: @@@@@@@", self)
#         # print("try_parsing: delimiterToken...", self.delimiterToken)
#         # print("try_parsing: partsCountDict...", self.partsCountDict)

#         self.debug_info["delimitResults"] = delimitResults
#         self.debug_info["fullPartsCount"] = fullPartsCount
#         return

#     def cast_values(self, df_col):
#         _casted_values = df_col.astype(str)
#         return _casted_values       # XXX?????
#         # return []

#         #
#         # A lot of overlap with the codec part of this.
#         #
#         # Should the codecs take in help from the detector, or should the
#         # detector leverage the codec to try to capture a representation?
#         #

#         # print("cast_values: @@@@@@@", self)
#         if self._casted_values is not None:
#             print(">>> Warning: called cast_values() again")

#         assert self.partsCountDict is not None, "no parts dictionary"
#         assert self.delimiterToken is not None, "no delimter set?!"

#         X = []
#         self._casted_values = df_col.astype(str)

#         maxLen = 0
#         # now process them.
#         for idx, val in self._casted_values.items():
#             if val == "nan":
#                 parts = [np.nan]
#             else:
#                 parts = val.split(self.delimiterToken)
#                 parts.sort()
#             maxLen = max(maxLen, len(parts))
#             X.append(parts)
#         for i in range(len(X)):
#             xi = X[i]
#             while len(xi) < maxLen:
#                 xi.append(np.nan)
#             X[i] = xi
#         # x = OneHotEncoder().fit_transform(X).toarray()
#         # self._casted_values = x
#         print("CASTED_VALUES SIZE = ", sys.getsizeof(self._casted_values))
#         print()
#         return self._casted_values


class FeatrixFieldSetDetection(FeatrixFieldBaseDetection):
    DETECTOR_NAME = "set"

    def __init__(self, colSample, numUniques=-1, numNotNulls=-1, debugColName=None):
        super().__init__(
            colSample=colSample,
            numUniques=numUniques,
            numNotNulls=numNotNulls,
            debugColName=debugColName,
            detectorName="set",
        )
        # self._uniques = None
        self.try_parsing()
        self.codec_name = "set"

    def get_meta_description(self):
        return "number symbols = %s" % self._numUniques

    def try_parsing(self):
        # self._uniques = set(self.colSample[self.colSample.notnull()])
        # lenUniques = len(self._uniques)
        # lenSamples = len(self.colSample)
        lenUniques = self._numUniques
        lenSamples = self._numNotNulls  # len(self.colSample)
        # print(f"DETECT SET: {self._debugColName} -- {lenUniques} vs {lenSamples}")

        # CRITICAL: Reject numeric columns - they should be SCALAR, not SET
        # A SET can have numeric values (like ratings 1-5), but columns that are predominantly
        # numeric with many unique values should be SCALAR.
        #
        # We check two conditions:
        # 1. High cardinality: >10% unique values AND >80% numeric -> SCALAR
        # 2. Predominantly numeric: >95% of UNIQUE values are numeric AND >10 unique values -> SCALAR
        #    This catches cases like Age (0-79) which has low cardinality but is clearly numeric

        # Sample values to check if they're numeric
        NUM_ROWS_TO_CHECK = min(1000, len(self.colSample))
        try:
            s_replace = self.colSample[self.colSample.notnull()]
            NUM_ROWS_TO_CHECK = min(NUM_ROWS_TO_CHECK, len(s_replace))
            theSample = s_replace.sample(NUM_ROWS_TO_CHECK) if NUM_ROWS_TO_CHECK > 0 else s_replace
        except:
            theSample = self.colSample[self.colSample.notnull()]
            NUM_ROWS_TO_CHECK = min(1000, len(theSample))

        if NUM_ROWS_TO_CHECK > 0:
            numericCount = 0
            for v in theSample:
                isNumber, _ = _isNumber(v)
                if isNumber:
                    numericCount += 1

            # If >80% of values are numeric AND we have high cardinality (many unique values),
            # this should be SCALAR, not SET
            numericRatio = float(numericCount) / float(NUM_ROWS_TO_CHECK)
            if numericRatio > 0.8:
                # High cardinality threshold: if unique values > 10% of samples, it's likely continuous numeric
                # Low cardinality numeric sets (like ratings 1-5) will have few uniques and pass through
                cardinalityRatio = float(lenUniques) / float(lenSamples) if lenSamples > 0 else 0.0
                if cardinalityRatio > 0.1:  # More than 10% unique = high cardinality = should be SCALAR
                    self._confidence = 0.0  # Reject - should be scalar
                    return

        # Additional check: if >95% of UNIQUE values are numeric and there are more than 10,
        # this is a numeric column (like Age 0-79), not a categorical set (like ratings 1-5)
        # This catches low-cardinality numeric columns that slip through the above check
        if lenUniques > 10:
            try:
                unique_values = self.colSample.dropna().unique()
                numeric_unique_count = 0
                for v in unique_values:
                    isNumber, _ = _isNumber(v)
                    if isNumber:
                        numeric_unique_count += 1
                numeric_unique_ratio = float(numeric_unique_count) / float(lenUniques) if lenUniques > 0 else 0.0
                if numeric_unique_ratio >= 0.95:
                    # >95% of unique values are numeric and we have >10 unique values
                    # This is a numeric column, not a categorical set
                    self._confidence = 0.0  # Reject - should be scalar
                    return
            except Exception:
                pass  # If we can't check, continue with normal detection

        lenSamplesFactor = 0.001
        if lenSamples < 10_000:
            lenSamplesFactor = 0.01
        elif lenSamples < 1_000:
            lenSamplesFactor = 0.1
            
        if lenUniques < (lenSamples * lenSamplesFactor):
                self._confidence = 1.0

        elif lenUniques < (lenSamples *lenSamplesFactor):
            self._confidence = 0.9

        elif lenUniques < (lenSamples * lenSamplesFactor):
            self._confidence = 0.75

        if lenSamples < 20:
            if lenUniques < (lenSamples * 0.3):
                self._confidence = 0.51

        #        self._confidence = 1.0  else 0.0
        return

    def cast_values(self, df_col):
        # if self._casted_values is not None:
        #     print(">>> Warning: called cast_values() again")

        _casted_values = df_col.astype(str)
        return _casted_values


class FeatrixFieldTimeDetection(FeatrixFieldBaseDetection):
    DETECTOR_NAME = "timestamp"

    def __init__(self, colSample, numUniques=-1, numNotNulls=-1, debugColName=None):
        super().__init__(
            colSample=colSample,
            numUniques=numUniques,
            numNotNulls=numNotNulls,
            debugColName=debugColName,
            detectorName=FeatrixFieldTimeDetection.DETECTOR_NAME,
        )
        self.try_parsing()
        # print("... colSample = ", colSample)
        self._casted_values = None
        # Set codec_name to "timestamp" if detection was successful
        if self._confidence > 0:
            self.codec_name = "timestamp"
        else:
            self.codec_name = None

    def try_parsing(self):
        NUM_ROWS_TO_CHECK = 100
        # FIXME: bug if there's < 100 samples...
        # if len(self.colSample) < NUM_ROWS_TO_CHECK:
        #    NUM_ROWS_TO_CHECK = len(self.colSample[self.colSample.notnull()]) - 1
        # print("NUM_ROWS_TO_CHECK = ", NUM_ROWS_TO_CHECK)
        # print(self.colSample)
        try:
            s_replace = (
                self.colSample
            )  # .replace(['NaN', 'None', '', 'nan'], float('nan'))
            s_replace = s_replace[s_replace.notnull()]
            NUM_ROWS_TO_CHECK = min(NUM_ROWS_TO_CHECK, len(s_replace))
            theSample = s_replace.sample(NUM_ROWS_TO_CHECK)
        except:
            # Sometimes we crash if there's not enough data.
            traceback.print_exc()
            print("CRASH...")
            theSample = self.colSample

        if len(theSample) == 0:
            return

        #        print("theSample ... = ", theSample)
        ts_list = []
        for v in theSample:
            isNumber, vv = _isNumber(v)
            # if it's just a number... probably not a time unless it is a unix timestamp...
            # so for unix timestamps, we need to assume maybe a recent or near-future time?
            if not isNumber:
                try:
                    # XXX: send in a default datetime ; try to connect / or limit
                    # XXX: detect that this is just a timefield by virtue of a fewer number
                    # XXX: of elements and we only change the time and not date parts
                    # XXX: I don't think we have to try to connect time fields with their
                    # XXX: corresponding date fields right now anyway.
                    default_datetime = datetime.fromtimestamp(0)

                    parsedTime = DateUtilParse(
                        v, default=default_datetime
                    )  # I _have_ seen this crash before.
                    if parsedTime is not None:
                        ts_list.append(parsedTime)
                except Exception:
                    pass
                    # ts_list.append(None)
        # print(self._debugColName, ": ts_list... = ", ts_list)
        # print(self._debugColName, ":... sample  = ", list(theSample))
        # print()
        # if len(ts_list) >= (NUM_ROWS_TO_CHECK / 2):
        # looking good.
        if NUM_ROWS_TO_CHECK > 0:
            self._confidence = float(len(ts_list)) / float(NUM_ROWS_TO_CHECK)
        # endif
        return

    def cast_values(self, df_col):
        # if self._casted_values is not None:
        #     print(">>> Warning: called cast_values() again")

        _casted_values = pd.to_datetime(
            df_col, errors="coerce"
        )
        return _casted_values


class FeatrixFieldTimeIntervalDetection(FeatrixFieldBaseDetection):
    DETECTOR_NAME = "time_interval"

    def __init__(self, colSample, numUniques=-1, numNotNulls=-1, debugColName=None):
        super().__init__(
            colSample=colSample,
            numUniques=numUniques,
            numNotNulls=numNotNulls,
            debugColName=debugColName,
            detectorName=FeatrixFieldTimeIntervalDetection.DETECTOR_NAME,
        )
        self.try_parsing()
        # print("... colSample = ", colSample)
        self._casted_values = None
        self.codec_name = None

    def try_parsing(self):
        NUM_ROWS_TO_CHECK = 100
        # FIXME: bug if there's < 100 samples...
        # if len(self.colSample) < NUM_ROWS_TO_CHECK:
        #    NUM_ROWS_TO_CHECK = len(self.colSample[self.colSample.notnull()]) - 1
        # print("NUM_ROWS_TO_CHECK = ", NUM_ROWS_TO_CHECK)
        # print(self.colSample)
        try:
            s_replace = (
                self.colSample
            )  # .replace(['NaN', 'None', '', 'nan'], float('nan'))
            s_replace = s_replace[s_replace.notnull()]
            NUM_ROWS_TO_CHECK = min(NUM_ROWS_TO_CHECK, len(s_replace))
            theSample = s_replace.sample(NUM_ROWS_TO_CHECK)
        except:
            # Sometimes we crash if there's not enough data.
            traceback.print_exc()
            print("CRASH...")
            theSample = self.colSample

        if len(theSample) == 0:
            return

        #        print("theSample ... = ", theSample)
        ts_list = []
        for v in theSample:
            isNumber, vv = _isNumber(v)
            # if it's just a number... probably not a time unless it is a unix timestamp...
            # so for unix timestamps, we need to assume maybe a recent or near-future time?
            if not isNumber:
                try:
                    seconds = DateIntervalParse(v)
                    if not isnan_or_null_no_crash(
                        seconds
                    ):  # is not None or math.isnan():
                        ts_list.append(seconds)
                except Exception:
                    pass

        if NUM_ROWS_TO_CHECK > 0:
            self._confidence = float(len(ts_list)) / float(NUM_ROWS_TO_CHECK)
        # endif
        return

    def cast_values(self, df_col):
        # if self._casted_values is not None:
        #     print(">>> Warning: called cast_values() again")

        def wrap_parse(v):
            try:
                if type(v) == float:
                    return v
                return DateIntervalParse(v)
            except:
                print(f"ERROR PARSING POSSIBLE TIME INTERVAL: v = __{v}")
                traceback.print_exc()
            return None

        # Pandas DOES have a to_timedelta()
        _casted_values = df_col.map(lambda v: wrap_parse(v))
        return _casted_values




class FeatrixEmailDetection(FeatrixFieldBaseDetection):
    DETECTOR_NAME = "email"

    def __init__(self, colSample, numUniques=-1, numNotNulls=-1, debugColName=None):
        super().__init__(
            colSample=colSample,
            numUniques=numUniques,
            numNotNulls=numNotNulls,
            debugColName=debugColName,
            detectorName="email",
        )
        # self._uniques = None
        # Enrichment removed - encode email columns as strings
        self.codec_name = "free_string"
        self.delimiterToken = None
        self.partsCountDict = None
        self.try_parsing()

    # def get_meta_description(self):
    #     return "delimter: __%s__; number symbols = %s" % (self.delimiterToken, len(self.partsCountDict))

    # def get_delimiter(self):
    #     return self.delimiterToken

    def try_parsing(self):
        # print("try_parsing entered")

        _uniques = None
        try:
            _uniques = list(set(self.colSample[self.colSample.notnull()].astype(str)))
        except:
            traceback.print_exc()
            return
        
        # s_replace = self.colSample  # .replace(['NaN', 'None', '', 'nan'], float('nan'))
        # s_replace = s_replace[s_replace.notnull()]
        # NUM_ROWS_TO_CHECK = min(NUM_ROWS_TO_CHECK, len(s_replace))
        # theSample = s_replace.sample(NUM_ROWS_TO_CHECK)

        # pick 100.
        NUM_ROWS_TO_CHECK = min(len(_uniques), 100)

        sample = random.sample(_uniques, NUM_ROWS_TO_CHECK)

        foundEmails = []

        for s in sample:
            s = str(s)
            atPos = s.find("@")
            if atPos < 0:
                continue
            userPart = s[0:atPos]
            domainPart = s[atPos + 1 :]

            if len(userPart) <= 0 or len(domainPart) <= 0:
                continue  # nothing before or after the @

            if domainPart.find("@") >= 0:
                continue  # two @s

            if domainPart.find(".") > 0:
                # looks good.
                # this is superficial, but we matched a <token>@<token>. [and presumably another <token> later but who cares]
                foundEmails.append([s, userPart, domainPart])
        # endfor

        # print("FOUND EMAILS:")
        # for f in foundEmails:
        #     print(f)
        if NUM_ROWS_TO_CHECK > 0:
            self._confidence = float(len(foundEmails)) / float(NUM_ROWS_TO_CHECK)
        return

    def cast_values(self, df_col):
        """Cast values for email detection - convert to string."""
        # For emails, we just ensure everything is string type
        _casted_values = df_col.astype(str)
        return _casted_values


class FeatrixDomainNameDetection(FeatrixFieldBaseDetection):
    DETECTOR_NAME = "domain_name"

    def __init__(self, colSample, numUniques=-1, numNotNulls=-1, debugColName=None):
        super().__init__(
            colSample=colSample,
            numUniques=numUniques,
            numNotNulls=numNotNulls,
            debugColName=debugColName,
            detectorName="domain_name",
        )
        # self._uniques = None
        self.codec_name = "domain_name"  # Use domain codec
        self.delimiterToken = None
        self.partsCountDict = None
        self.try_parsing()

    # def get_meta_description(self):
    #     return "delimter: __%s__; number symbols = %s" % (self.delimiterToken, len(self.partsCountDict))

    # def get_delimiter(self):
    #     return self.delimiterToken

    def try_parsing(self):
        # print("try_parsing entered")

        _uniques = None
        try:
            _uniques = list(set(self.colSample[self.colSample.notnull()].astype(str)))
        except:
            traceback.print_exc()
            return
        
        # s_replace = self.colSample  # .replace(['NaN', 'None', '', 'nan'], float('nan'))
        # s_replace = s_replace[s_replace.notnull()]
        # NUM_ROWS_TO_CHECK = min(NUM_ROWS_TO_CHECK, len(s_replace))
        # theSample = s_replace.sample(NUM_ROWS_TO_CHECK)

        # pick 100.
        NUM_ROWS_TO_CHECK = min(len(_uniques), 100)

        sample = random.sample(_uniques, NUM_ROWS_TO_CHECK)

        foundDomains = []

        for s in sample:
            s = str(s)
            # If it has an @, it's an email not a domain
            if s.find('@') >= 0:
                continue
            
            if s.startswith("http://"):
                s = s[len("http://"):]
            elif s.startswith("https://"):
                s = s[len("https://"):]
            
            atPos = s.find(".")
            if atPos < 0:
                continue
            firstPart = s[0:atPos]
            secondPart = s[atPos + 1 :]

            if len(firstPart) <= 0 or len(secondPart) <= 0:
                continue  # nothing before or after the @

            if firstPart == "www":
                foundDomains.append(s)
                continue  # two @s
            if secondPart in ["com", "org", "net", "gov", "edu"]:
                foundDomains.append(s)
        # endfor

        # print("FOUND EMAILS:")
        # for f in foundEmails:
        #     print(f)
        if NUM_ROWS_TO_CHECK > 0:
            self._confidence = float(len(foundDomains)) / float(NUM_ROWS_TO_CHECK)
        return


class FeatrixURLDetection(FeatrixFieldBaseDetection):
    """
    Detector for URL/domain columns.
    Detects URLs with protocols, paths, query params.
    """
    DETECTOR_NAME = "url"

    def __init__(self, colSample, numUniques=-1, numNotNulls=-1, debugColName=None):
        super().__init__(
            colSample=colSample,
            numUniques=numUniques,
            numNotNulls=numNotNulls,
            debugColName=debugColName,
            detectorName="url",
        )
        self.codec_name = "url"
        self.try_parsing()

    def try_parsing(self):
        """Detect URLs by looking for URL patterns."""
        _uniques = None
        try:
            _uniques = list(set(self.colSample[self.colSample.notnull()].astype(str)))
        except:
            traceback.print_exc()
            return
        
        NUM_ROWS_TO_CHECK = min(len(_uniques), 100)
        sample = random.sample(_uniques, NUM_ROWS_TO_CHECK)

        foundURLs = []

        for s in sample:
            s = str(s).strip()
            
            # Strong URL indicators
            has_protocol = (s.startswith("http://") or s.startswith("https://") or 
                           s.startswith("ftp://") or s.startswith("ftps://") or
                           s.startswith("ws://") or s.startswith("wss://"))
            
            # Check for path or query string (indicators it's a URL not just domain)
            has_path = "/" in s and not s.endswith("/")
            has_query = "?" in s
            has_fragment = "#" in s
            
            # Check for domain-like structure
            has_dot = "." in s
            
            # If it has protocol, it's likely a URL
            if has_protocol:
                foundURLs.append(s)
                continue
            
            # If it has path/query/fragment + domain structure, likely URL
            if (has_path or has_query or has_fragment) and has_dot:
                # Make sure it's not an email
                if "@" not in s:
                    foundURLs.append(s)
                    continue
            
            # Check for common URL patterns without protocol
            # (e.g., "www.example.com/path" or "api.service.com/v1/endpoint")
            if has_dot and (has_path or has_query):
                # Avoid email addresses
                if "@" not in s:
                    foundURLs.append(s)
        
        # Calculate confidence
        if NUM_ROWS_TO_CHECK > 0:
            self._confidence = float(len(foundURLs)) / float(NUM_ROWS_TO_CHECK)
        return
    
    def get_codec_name(self):
        """Return codec name for URL columns."""
        return "url"
    
    def get_casted_column_values(self, df_col):
        """Cast column values to strings for URL encoding."""
        _casted_values = df_col.astype(str)
        return _casted_values

    def cast_values(self, df_col):
        """Cast values for domain name detection - convert to string."""
        # For domain names, we just ensure everything is string type
        _casted_values = df_col.astype(str)
        return _casted_values

def df_isNumberWrapper(f):
    (worked, _f) = _isNumber(f)
    if worked:
        return _f
    return np.nan


class FeatrixFieldScalarDetection(FeatrixFieldBaseDetection):
    def __init__(self, colSample, numUniques=-1, numNotNulls=-1, debugColName=None):
        super().__init__(
            colSample=colSample,
            numUniques=numUniques,
            numNotNulls=numNotNulls,
            debugColName=debugColName,
            detectorName="scalar",
        )
        self.try_parsing()
        self.codec_name = "scalar"
        self.sample_debug_str = None

    def try_parsing(self):
        NUM_ROWS_TO_CHECK = min(100, len(self.colSample))
        try:
            s_replace = (
                self.colSample
            )  # .replace(['NaN', 'None', '', 'nan'], float('nan'))
            s_replace = s_replace[s_replace.notnull()]
            NUM_ROWS_TO_CHECK = min(NUM_ROWS_TO_CHECK, len(s_replace))
            theSample = s_replace.sample(NUM_ROWS_TO_CHECK)

            # theSample = self.colSample[self.colSample.as_type('float32').notnull()].as_type('float32').sample(NUM_ROWS_TO_CHECK)
            # NUM_ROWS_TO_CHECK = min(len(theSample), NUM_ROWS_TO_CHECK)
        except:
            theSample = self.colSample
            NUM_ROWS_TO_CHECK = len(self.colSample)

        # print(f"{self._debugColName}.... NUM_ROWS_TO_CHECK = {NUM_ROWS_TO_CHECK}")
        numberCount = 0

        adjustedSampleCount = NUM_ROWS_TO_CHECK
        dollarSigns = 0
        nanStrCount = 0
        for v in theSample:
            if type(v) == str:
                if v == "":
                    v = np.nan
                elif v[0] == "$":
                    dollarSigns += 1
                    v = v[1:]
                elif v == "nan":
                    nanStrCount += 1
                    # print(f"{nanStrCount}/{NUM_ROWS_TO_CHECK}: got a nan str; grrrr")
                    v = np.nan
                    # this shouldn't even be in the sample.
                    adjustedSampleCount -= 1
                    continue
            isNumber, vv = _isNumber(v)

            if isNumber:
                numberCount += 1

        if adjustedSampleCount == 0:
            # well crap.
            self.sample_debug_str = "all the samples were 'nan' strings or something. Looks bad. Please debug more."
            adjustedSampleCount = NUM_ROWS_TO_CHECK

        # print("dollarSigns... = ", self._debugColName, dollarSigns)
        if adjustedSampleCount > 0:
            self._confidence = float(numberCount) / float(adjustedSampleCount)

        self.sample_debug_str = (
            "... sample = %s; numberCount = %d; adjustedSampleCount = %d"
            % (list(theSample), numberCount, adjustedSampleCount)
        )
        # print("....", self._debugColName, self.sample_debug_str)
        # print("confidence..", self._debugColName, self._confidence)
        return

    def cast_values(self, df_column):
        # columnName = self.get_col_name()
        # if self._casted_values is not None:
        #     print(">>> Warning: called cast_values() again")

        _casted_values = df_column.transform(lambda x: df_isNumberWrapper(x))
        return _casted_values


class FeatrixPhoneDetection(FeatrixFieldBaseDetection):
    """
    Detector for phone/fax number columns.

    Uses column name hints (phone, fax, mobile, cell, tel) as strong signals,
    combined with pattern detection for phone number formats.
    """
    DETECTOR_NAME = "phone"

    # Column name substrings that strongly suggest phone numbers
    PHONE_NAME_HINTS = ['phone', 'fax', 'mobile', 'cell', 'tel']

    # Column name substrings that EXCLUDE phone detection (dates, times, IDs)
    PHONE_NAME_EXCLUDES = ['date', 'time', 'timestamp', '_at', '_on', 'created', 'updated', 'modified', 'year', 'month', 'day']

    def __init__(self, colSample, numUniques=-1, numNotNulls=-1, debugColName=None):
        super().__init__(
            colSample=colSample,
            numUniques=numUniques,
            numNotNulls=numNotNulls,
            debugColName=debugColName,
            detectorName="phone",
        )
        self.codec_name = "phone"
        self.try_parsing()

    def _column_name_suggests_phone(self) -> bool:
        """Check if the column name suggests this is a phone number column."""
        if self._debugColName is None:
            return False
        col_lower = self._debugColName.lower()
        for hint in self.PHONE_NAME_HINTS:
            if hint in col_lower:
                return True
        return False

    def _column_name_excludes_phone(self) -> bool:
        """
        Check if the column name suggests this is NOT a phone column (e.g., dates).

        IMPORTANT: If the column name contains a phone hint (phone, fax, mobile, etc.),
        we do NOT exclude it even if it also contains a date-like word.
        Example: 'phone_for_sexy_date' should still be detected as phone.
        """
        if self._debugColName is None:
            return False
        col_lower = self._debugColName.lower()

        # If column name suggests phone, never exclude it
        for hint in self.PHONE_NAME_HINTS:
            if hint in col_lower:
                return False

        # No phone hint - check for date/time exclusions
        for exclude in self.PHONE_NAME_EXCLUDES:
            if exclude in col_lower:
                return True
        return False

    def _looks_like_phone_number(self, value: str) -> bool:
        """
        Check if a string value looks like a phone number.

        Accepts formats like:
        - (555) 123-4567
        - 555-123-4567
        - 555.123.4567
        - 5551234567
        - +1 555 123 4567
        - +1-555-123-4567
        - 1-800-555-1234
        - ext. 123, x123
        """
        import re

        if not isinstance(value, str):
            value = str(value)

        value = value.strip()
        if len(value) < 7 or len(value) > 30:
            return False

        # Remove common formatting characters and count digits
        digits_only = re.sub(r'[^\d]', '', value)
        num_digits = len(digits_only)

        # Phone numbers typically have 7-15 digits
        if num_digits < 7 or num_digits > 15:
            return False

        # Check for phone number patterns
        # Pattern: optional + or country code, then groups of digits with separators
        phone_patterns = [
            r'^\+?\d{1,3}[-.\s]?\(?\d{2,4}\)?[-.\s]?\d{2,4}[-.\s]?\d{2,4}',  # International
            r'^\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}',  # US format (xxx) xxx-xxxx
            r'^\d{3}[-.\s]\d{3}[-.\s]\d{4}',  # xxx-xxx-xxxx
            r'^\d{10,11}$',  # Plain 10 or 11 digit
            r'^\d{3}[-.\s]\d{4}$',  # 7-digit local xxx-xxxx
            r'^1[-.\s]?\d{3}[-.\s]?\d{3}[-.\s]?\d{4}',  # 1-xxx-xxx-xxxx
        ]

        for pattern in phone_patterns:
            if re.match(pattern, value):
                return True

        # If column name suggests phone, be more lenient - just check digit ratio
        if self._column_name_suggests_phone():
            # At least 60% of characters should be digits or common separators
            allowed_chars = set('0123456789+-.()/x ext')
            valid_chars = sum(1 for c in value.lower() if c in allowed_chars or c.isspace())
            if valid_chars / len(value) >= 0.8 and num_digits >= 7:
                return True

        return False

    def try_parsing(self):
        """Detect phone numbers based on VALUE PATTERNS, with small column name adjustments."""
        _uniques = None
        try:
            _uniques = list(set(self.colSample[self.colSample.notnull()].astype(str)))
        except:
            traceback.print_exc()
            return

        NUM_ROWS_TO_CHECK = min(len(_uniques), 100)
        if NUM_ROWS_TO_CHECK == 0:
            self._confidence = 0.0
            return

        sample = random.sample(_uniques, NUM_ROWS_TO_CHECK)

        # Check how many values look like phone numbers
        phone_count = 0
        for s in sample:
            if self._looks_like_phone_number(s):
                phone_count += 1

        # BASE CONFIDENCE: purely from pattern matching (content is king)
        pattern_confidence = float(phone_count) / float(NUM_ROWS_TO_CHECK)

        # Start with pattern confidence as the base
        self._confidence = pattern_confidence

        # Small adjustments based on column name (±25% max, never makes bad data good)
        if self._column_name_suggests_phone():
            # Column name has 'phone', 'fax', 'mobile', etc. - small boost
            self._confidence = min(1.0, self._confidence * 1.25)
        elif self._column_name_excludes_phone():
            # Column name has 'date', 'time', etc. - small penalty
            self._confidence = self._confidence * 0.75

        # Never return perfect 1.0 unless pattern match is perfect
        if pattern_confidence < 1.0 and self._confidence >= 1.0:
            self._confidence = 0.95

        # Must have at least 50% pattern match to be considered at all
        if pattern_confidence < 0.5:
            self._confidence = 0.0

        return

    def cast_values(self, df_col):
        """Cast values for phone detection - convert to string."""
        _casted_values = df_col.astype(str)
        return _casted_values


class FeatrixZipCodeDetection(FeatrixFieldBaseDetection):
    """
    Detector for zip code columns.

    Uses column name hints (zip, postal, zipcode) as strong signals,
    combined with pattern detection for zip code formats.
    """
    DETECTOR_NAME = "zip_code"

    # Column name substrings that strongly suggest zip codes
    ZIP_NAME_HINTS = ['zip', 'postal', 'postcode', 'zip_code', 'zipcode']

    def __init__(self, colSample, numUniques=-1, numNotNulls=-1, debugColName=None):
        super().__init__(
            colSample=colSample,
            numUniques=numUniques,
            numNotNulls=numNotNulls,
            debugColName=debugColName,
            detectorName="zip_code",
        )
        self.codec_name = "zip_code"
        self.try_parsing()

    def _column_name_suggests_zip(self) -> bool:
        """Check if the column name suggests this is a zip code column."""
        if self._debugColName is None:
            return False
        col_lower = self._debugColName.lower()
        for hint in self.ZIP_NAME_HINTS:
            if col_lower.find(hint) >= 0:
                return True
        return False

    def _looks_like_zip_code(self, value: str) -> bool:
        """
        Check if a string value looks like a US zip code.

        Accepts formats like:
        - 12345 (5-digit)
        - 12345-6789 (ZIP+4)
        - 123456789 (9-digit without hyphen)
        - 2128.0 (float that lost leading zero - really 02128)
        - 2128 (4-digit that lost leading zero)
        """
        import re

        if not isinstance(value, str):
            value = str(value)

        value = value.strip()

        # Handle floats like "2128.0" -> "2128"
        if '.' in value:
            try:
                # Check if it's a float representation of an integer
                float_val = float(value)
                if float_val == int(float_val):
                    value = str(int(float_val))
            except (ValueError, OverflowError):
                pass

        # Remove any non-digit/hyphen characters
        cleaned = re.sub(r'[^\d-]', '', value)

        # Check for valid zip patterns
        # 5-digit zip
        if re.match(r'^\d{5}$', cleaned):
            return True
        # ZIP+4 with hyphen
        if re.match(r'^\d{5}-\d{4}$', cleaned):
            return True
        # 9-digit without hyphen
        if re.match(r'^\d{9}$', cleaned):
            return True
        # 4-digit zip (lost leading zero, e.g., Boston 02128 -> 2128)
        # Only accept if column name suggests zip (checked elsewhere) or value is in valid range
        if re.match(r'^\d{4}$', cleaned):
            # 4-digit zips from leading-zero states: 0xxxx -> xxxx when stored as number
            # Valid range: roughly 1000-9999 (represents 01000-09999)
            try:
                val = int(cleaned)
                # Most NE US zips start with 0: 01xxx-09xxx
                # When leading zero is lost, they become 1xxx-9xxx
                if 1000 <= val <= 9999:
                    return True
            except ValueError:
                pass

        return False

    def try_parsing(self):
        """Detect zip codes using column name hints and value patterns."""
        _uniques = None
        try:
            _uniques = list(set(self.colSample[self.colSample.notnull()].astype(str)))
        except:
            traceback.print_exc()
            return

        NUM_ROWS_TO_CHECK = min(len(_uniques), 100)
        if NUM_ROWS_TO_CHECK == 0:
            self._confidence = 0.0
            return

        sample = random.sample(_uniques, NUM_ROWS_TO_CHECK)

        # Check how many values look like zip codes
        zip_count = 0
        for s in sample:
            if self._looks_like_zip_code(s):
                zip_count += 1

        pattern_confidence = float(zip_count) / float(NUM_ROWS_TO_CHECK)

        # Column name is a strong hint - boost confidence significantly
        if self._column_name_suggests_zip():
            # If column name suggests zip, we need less pattern evidence
            if pattern_confidence >= 0.3:
                self._confidence = max(0.85, pattern_confidence)
            elif pattern_confidence >= 0.1:
                self._confidence = 0.7
            else:
                # Name says zip but data doesn't look like it - still give some credit
                self._confidence = 0.4
        else:
            # No name hint - rely purely on pattern matching
            # Need higher pattern confidence without name hint
            if pattern_confidence >= 0.7:
                self._confidence = pattern_confidence
            elif pattern_confidence >= 0.5:
                self._confidence = pattern_confidence * 0.8
            else:
                self._confidence = 0.0

        return

    def cast_values(self, df_col):
        """
        Cast values for zip code detection - convert to string with proper padding.

        Handles the common case where zip codes are stored as floats/ints,
        losing leading zeros (e.g., 02128 -> 2128.0). We detect this and
        pad back to 5 digits.
        """
        def _format_zip(val):
            if val is None or (isinstance(val, float) and math.isnan(val)):
                return None

            # Convert to string
            s = str(val).strip()

            # Handle float representation (e.g., "2128.0" -> "2128")
            if '.' in s:
                try:
                    float_val = float(s)
                    if float_val == int(float_val):
                        s = str(int(float_val))
                except (ValueError, OverflowError):
                    pass

            # If it's a 4-digit number, it likely lost a leading zero
            # Pad to 5 digits (e.g., "2128" -> "02128")
            if s.isdigit() and len(s) == 4:
                s = '0' + s

            # If it's a valid 5-digit zip or ZIP+4, return as-is
            # Otherwise return the cleaned string
            return s

        _casted_values = df_col.apply(_format_zip)
        return _casted_values


class FeatrixFipsCodeDetection(FeatrixFieldBaseDetection):
    """
    Detector for FIPS code columns.

    Uses column name hints (fips, county_code, state_county) as strong signals,
    combined with pattern detection for FIPS code formats.

    FIPS codes are:
    - 2-digit state codes (01-56)
    - 5-digit county codes (state + county, e.g., 06075 = San Francisco, CA)
    """
    DETECTOR_NAME = "fips_code"

    # Column name substrings that strongly suggest FIPS codes
    FIPS_NAME_HINTS = ['fips', 'county_code', 'county_fips', 'state_fips', 'geo_id', 'geoid']

    def __init__(self, colSample, numUniques=-1, numNotNulls=-1, debugColName=None):
        super().__init__(
            colSample=colSample,
            numUniques=numUniques,
            numNotNulls=numNotNulls,
            debugColName=debugColName,
            detectorName="fips_code",
        )
        self.codec_name = "fips_code"
        self.try_parsing()

    def _column_name_suggests_fips(self) -> bool:
        """Check if the column name suggests this is a FIPS code column."""
        if self._debugColName is None:
            return False
        col_lower = self._debugColName.lower()
        for hint in self.FIPS_NAME_HINTS:
            if col_lower.find(hint) >= 0:
                return True
        return False

    def _looks_like_fips_code(self, value: str) -> bool:
        """
        Check if a string value looks like a FIPS code.

        Accepts formats like:
        - 06 (2-digit state FIPS)
        - 06075 (5-digit county FIPS)
        - 6075 (4-digit, missing leading zero)
        """
        import re

        if not isinstance(value, str):
            value = str(value)

        value = value.strip()

        # Remove any non-digit characters
        digits = re.sub(r'[^\d]', '', value)

        # Check for valid FIPS patterns
        # 2-digit state FIPS (01-56, 72, 78)
        if len(digits) == 2:
            state = int(digits)
            # Valid state FIPS range (with some gaps)
            if 1 <= state <= 56 or state in [72, 78]:
                return True
        # 5-digit county FIPS
        if len(digits) == 5:
            state = int(digits[:2])
            if 1 <= state <= 56 or state in [72, 78]:
                return True
        # 4-digit (missing leading zero, e.g., 6075 for California)
        if len(digits) == 4:
            # Could be state 01-09 with county
            return True

        return False

    def try_parsing(self):
        """Detect FIPS codes using column name hints and value patterns."""
        _uniques = None
        try:
            _uniques = list(set(self.colSample[self.colSample.notnull()].astype(str)))
        except:
            traceback.print_exc()
            return

        NUM_ROWS_TO_CHECK = min(len(_uniques), 100)
        if NUM_ROWS_TO_CHECK == 0:
            self._confidence = 0.0
            return

        sample = random.sample(_uniques, NUM_ROWS_TO_CHECK)

        # Check how many values look like FIPS codes
        fips_count = 0
        for s in sample:
            if self._looks_like_fips_code(s):
                fips_count += 1

        pattern_confidence = float(fips_count) / float(NUM_ROWS_TO_CHECK)

        # Column name is a VERY strong hint for FIPS - it's a specific format
        if self._column_name_suggests_fips():
            # If column name suggests FIPS, we need less pattern evidence
            if pattern_confidence >= 0.2:
                self._confidence = max(0.90, pattern_confidence)
            elif pattern_confidence >= 0.1:
                self._confidence = 0.75
            else:
                # Name says FIPS but data doesn't look like it - still give credit
                self._confidence = 0.5
        else:
            # No name hint - rely purely on pattern matching
            # FIPS patterns can look like regular numbers, so be conservative
            if pattern_confidence >= 0.8:
                self._confidence = pattern_confidence * 0.7  # Be conservative without name hint
            else:
                self._confidence = 0.0

        return

    def cast_values(self, df_col):
        """Cast values for FIPS code detection - convert to string."""
        _casted_values = df_col.astype(str)
        return _casted_values


class FeatrixJsonDetection(FeatrixFieldBaseDetection):
    DETECTOR_NAME = "json"

    def __init__(self, colSample, numUniques=-1, numNotNulls=-1, debugColName=None):
        super().__init__(
            colSample=colSample,
            numUniques=numUniques,
            numNotNulls=numNotNulls,
            debugColName=debugColName,
            detectorName="json",
        )
        self.codec_name = "json"
        self.try_parsing()
    
    def _safe_parse_dict_like(self, value: str):
        """Safely parse dict-like strings."""
        import json
        import ast
        import re
        
        if not isinstance(value, str):
            return None
            
        value = value.strip()
        if not (value.startswith('{') and value.endswith('}')):
            return None
        
        # Try standard JSON parsing
        try:
            parsed = json.loads(value)
            if isinstance(parsed, dict):
                return parsed
        except (json.JSONDecodeError, TypeError):
            pass
        
        # Try ast.literal_eval for Python dict literals
        try:
            parsed = ast.literal_eval(value)
            if isinstance(parsed, dict):
                return parsed
        except (ValueError, SyntaxError):
            pass
        
        return None
    
    def _safe_parse_list_of_dicts(self, value: str):
        """Safely parse list-of-dicts strings."""
        import json
        import ast
        
        if not isinstance(value, str):
            return None
            
        value = value.strip()
        if not (value.startswith('[') and value.endswith(']')):
            return None
        
        # Try standard JSON parsing
        try:
            parsed = json.loads(value)
            if isinstance(parsed, list) and len(parsed) > 0:
                if all(isinstance(item, dict) for item in parsed):
                    return parsed
        except (json.JSONDecodeError, TypeError):
            pass
        
        # Try ast.literal_eval for Python list literals
        try:
            parsed = ast.literal_eval(value)
            if isinstance(parsed, list) and len(parsed) > 0:
                if all(isinstance(item, dict) for item in parsed):
                    return parsed
        except (ValueError, SyntaxError):
            pass
        
        return None
    
    def try_parsing(self):
        """Detect JSON by checking if values are parseable as dicts or lists of dicts."""
        NUM_ROWS_TO_CHECK = min(100, len(self.colSample))
        try:
            s_replace = self.colSample[self.colSample.notnull()]
            NUM_ROWS_TO_CHECK = min(NUM_ROWS_TO_CHECK, len(s_replace))
            theSample = s_replace.sample(NUM_ROWS_TO_CHECK)
        except:
            theSample = self.colSample
            NUM_ROWS_TO_CHECK = len(self.colSample)
        
        if NUM_ROWS_TO_CHECK == 0:
            self._confidence = 0.0
            return
        
        json_count = 0
        for v in theSample:
            if not isinstance(v, str):
                continue
            
            # Check for dicts
            parsed_dict = self._safe_parse_dict_like(v)
            if parsed_dict is not None:
                json_count += 1
                continue
            
            # Check for lists of dicts
            parsed_list = self._safe_parse_list_of_dicts(v)
            if parsed_list is not None:
                json_count += 1
                continue
        
        if NUM_ROWS_TO_CHECK > 0:
            self._confidence = float(json_count) / float(NUM_ROWS_TO_CHECK)
        else:
            self._confidence = 0.0
    
    def get_codec_name(self):
        """Return codec name for JSON columns."""
        return "json"
    
    def cast_values(self, df_col):
        """Cast values for JSON - keep as strings since we'll parse during encoding."""
        return df_col.astype(str)


class FeatrixYearJsonDetection(FeatrixFieldBaseDetection):
    """
    Detector for JSON columns where keys are years.

    Detects patterns like:
    - {"2020": 100, "2021": 200, "2022": 300}
    - {"2019": 50, "2020": 75}

    These are time-series data encoded as JSON dicts, where:
    - Keys are 4-digit years (1900-2100 range)
    - Values are typically numeric (counts, amounts, etc.)

    The codec will extract temporal features like:
    - Year range (min, max, span)
    - Trend direction
    - Most recent value
    - Weighted average
    """
    DETECTOR_NAME = "year_json"

    # Valid year range
    MIN_YEAR = 1900
    MAX_YEAR = 2100

    def __init__(self, colSample, numUniques=-1, numNotNulls=-1, debugColName=None):
        super().__init__(
            colSample=colSample,
            numUniques=numUniques,
            numNotNulls=numNotNulls,
            debugColName=debugColName,
            detectorName="year_json",
        )
        self.codec_name = "year_json"
        self.try_parsing()

    def _safe_parse_dict_like(self, value: str):
        """Safely parse dict-like strings."""
        import json
        import ast

        if not isinstance(value, str):
            if isinstance(value, dict):
                return value
            return None

        value = value.strip()
        if not (value.startswith('{') and value.endswith('}')):
            return None

        # Try standard JSON parsing
        try:
            parsed = json.loads(value)
            if isinstance(parsed, dict):
                return parsed
        except (json.JSONDecodeError, TypeError):
            pass

        # Try ast.literal_eval for Python dict literals
        try:
            parsed = ast.literal_eval(value)
            if isinstance(parsed, dict):
                return parsed
        except (ValueError, SyntaxError):
            pass

        return None

    def _is_year(self, key: str) -> bool:
        """Check if a key looks like a year."""
        import re

        key_str = str(key).strip()
        # Must be exactly 4 digits
        if not re.match(r'^\d{4}$', key_str):
            return False

        year = int(key_str)
        return self.MIN_YEAR <= year <= self.MAX_YEAR

    def _check_year_keys(self, parsed_dict: dict) -> float:
        """
        Check what fraction of keys in a dict look like years.

        Returns:
            Float between 0 and 1 indicating fraction of year keys
        """
        if not parsed_dict or len(parsed_dict) == 0:
            return 0.0

        year_key_count = 0
        for key in parsed_dict.keys():
            if self._is_year(str(key)):
                year_key_count += 1

        return year_key_count / len(parsed_dict)

    def try_parsing(self):
        """Detect if JSON column has year keys."""
        NUM_ROWS_TO_CHECK = min(100, len(self.colSample))
        try:
            s_replace = self.colSample[self.colSample.notnull()]
            NUM_ROWS_TO_CHECK = min(NUM_ROWS_TO_CHECK, len(s_replace))
            if NUM_ROWS_TO_CHECK < 5:
                self._confidence = 0.0
                return
            theSample = s_replace.sample(NUM_ROWS_TO_CHECK)
        except:
            theSample = self.colSample
            NUM_ROWS_TO_CHECK = len(self.colSample)

        if NUM_ROWS_TO_CHECK == 0:
            self._confidence = 0.0
            return

        # Track how many values are year-keyed dicts
        year_json_count = 0
        total_year_key_ratio = 0.0
        parsed_count = 0

        for v in theSample:
            parsed_dict = self._safe_parse_dict_like(v)
            if parsed_dict is None:
                continue

            parsed_count += 1
            year_ratio = self._check_year_keys(parsed_dict)
            total_year_key_ratio += year_ratio

            # Count as year JSON if at least 80% of keys are years
            if year_ratio >= 0.8:
                year_json_count += 1

        if parsed_count == 0:
            self._confidence = 0.0
            return

        # Confidence based on:
        # 1. What fraction of parsed dicts have year keys
        # 2. Average year key ratio
        parsed_ratio = parsed_count / NUM_ROWS_TO_CHECK
        year_json_ratio = year_json_count / parsed_count
        avg_year_key_ratio = total_year_key_ratio / parsed_count

        # High confidence if most dicts have mostly year keys
        if year_json_ratio >= 0.8 and avg_year_key_ratio >= 0.8:
            self._confidence = min(0.95, parsed_ratio * year_json_ratio)
        elif year_json_ratio >= 0.5 and avg_year_key_ratio >= 0.6:
            self._confidence = min(0.7, parsed_ratio * year_json_ratio)
        else:
            self._confidence = 0.0

    def get_codec_name(self):
        """Return codec name for year JSON columns."""
        return "year_json"

    def cast_values(self, df_col):
        """Cast values - keep as strings since we'll parse during encoding."""
        return df_col.astype(str)


class FeatrixGeoJsonDetection(FeatrixFieldBaseDetection):
    """
    Detector for JSON columns where keys are geographic codes (FIPS, zip, area codes).

    Detects patterns like:
    - {"47037": 50, "06075": 10}  # FIPS codes with counts
    - {"94105": 100, "10001": 25}  # Zip codes with counts
    - {"415": 75, "212": 25}  # Area codes with counts

    The codec will extract geographic spread features.
    """
    DETECTOR_NAME = "geo_json"

    def __init__(self, colSample, numUniques=-1, numNotNulls=-1, debugColName=None):
        super().__init__(
            colSample=colSample,
            numUniques=numUniques,
            numNotNulls=numNotNulls,
            debugColName=debugColName,
            detectorName="geo_json",
        )
        self.codec_name = "geo_json"
        self.geo_type = None  # Will be 'fips', 'zip', or 'area_code'
        self.try_parsing()

    def _safe_parse_dict_like(self, value: str):
        """Safely parse dict-like strings."""
        import json
        import ast

        if not isinstance(value, str):
            if isinstance(value, dict):
                return value
            return None

        value = value.strip()
        if not (value.startswith('{') and value.endswith('}')):
            return None

        try:
            parsed = json.loads(value)
            if isinstance(parsed, dict):
                return parsed
        except (json.JSONDecodeError, TypeError):
            pass

        try:
            parsed = ast.literal_eval(value)
            if isinstance(parsed, dict):
                return parsed
        except (ValueError, SyntaxError):
            pass

        return None

    def _detect_geo_type_for_keys(self, keys: list) -> tuple:
        """
        Detect what type of geographic codes the keys are.

        Returns:
            (geo_type, confidence) where geo_type is 'fips', 'zip', 'area_code', or None
        """
        import re

        # Import geo data for validation
        try:
            from featrix.neural.data_fips import COUNTY_FIPS_COORDS
            from featrix.neural.fips_codec import STATE_FIPS
            from featrix.neural.zip_codec import ZIP_PREFIX_COORDS
            from featrix.neural.phone_codec import AREA_CODE_COORDS
        except ImportError:
            logger.warning("Could not import geo data for GeoJsonDetection")
            return None, 0.0

        fips_score = 0
        zip_score = 0
        area_code_score = 0

        for key in keys:
            key_str = str(key).strip()
            digits = re.sub(r'[^\d]', '', key_str)

            if len(digits) == 5:
                # Could be FIPS or zip
                if digits in COUNTY_FIPS_COORDS:
                    fips_score += 2
                elif digits[:3] in ZIP_PREFIX_COORDS:
                    zip_score += 1
                elif digits[:2] in STATE_FIPS:
                    fips_score += 1
                else:
                    zip_score += 0.5  # Default to zip for 5-digit

            elif len(digits) == 3:
                # Likely area code
                if digits in AREA_CODE_COORDS:
                    area_code_score += 2
                else:
                    area_code_score += 0.5

            elif len(digits) == 4:
                # Might be FIPS missing leading zero
                padded = '0' + digits
                if padded in COUNTY_FIPS_COORDS:
                    fips_score += 2
                elif padded[:2] in STATE_FIPS:
                    fips_score += 1

        total_keys = len(keys)
        if total_keys == 0:
            return None, 0.0

        scores = {'fips': fips_score, 'zip': zip_score, 'area_code': area_code_score}
        best_type = max(scores, key=scores.get)
        best_score = scores[best_type]

        # Confidence based on score relative to number of keys
        if best_score >= total_keys * 0.5:
            return best_type, min(0.9, best_score / (total_keys * 2))

        return None, 0.0

    def try_parsing(self):
        """Detect if JSON column has geographic code keys."""
        NUM_ROWS_TO_CHECK = min(100, len(self.colSample))
        try:
            s_replace = self.colSample[self.colSample.notnull()]
            NUM_ROWS_TO_CHECK = min(NUM_ROWS_TO_CHECK, len(s_replace))
            if NUM_ROWS_TO_CHECK < 5:
                self._confidence = 0.0
                return
            theSample = s_replace.sample(NUM_ROWS_TO_CHECK)
        except:
            theSample = self.colSample
            NUM_ROWS_TO_CHECK = len(self.colSample)

        if NUM_ROWS_TO_CHECK == 0:
            self._confidence = 0.0
            return

        # Collect all keys from all parsed dicts
        all_keys = []
        parsed_count = 0

        for v in theSample:
            parsed_dict = self._safe_parse_dict_like(v)
            if parsed_dict is None:
                continue

            parsed_count += 1
            all_keys.extend(parsed_dict.keys())

        if parsed_count == 0 or len(all_keys) == 0:
            self._confidence = 0.0
            return

        # Detect geo type from collected keys
        geo_type, geo_confidence = self._detect_geo_type_for_keys(all_keys)

        if geo_type is None:
            self._confidence = 0.0
            return

        self.geo_type = geo_type

        # Scale confidence by parsed ratio
        parsed_ratio = parsed_count / NUM_ROWS_TO_CHECK
        self._confidence = geo_confidence * parsed_ratio

    def get_codec_name(self):
        """Return codec name for geo JSON columns."""
        if self.geo_type:
            return f"geo_json_{self.geo_type}"
        return "geo_json"

    def cast_values(self, df_col):
        """Cast values - keep as strings since we'll parse during encoding."""
        return df_col.astype(str)


# The order in this list matters! <-- Pay attention folks!
DetectorList = [
    FeatrixFieldScalarDetection,
    FeatrixFieldSetDetection,
    FeatrixFieldTimeDetection,
    FeatrixFieldTimeIntervalDetection,
    # FeatrixFieldListsOfASetDetection,
    FeatrixEmailDetection,
    FeatrixPhoneDetection,         ## Check phone numbers (uses column name hints)
    FeatrixZipCodeDetection,       ## Check zip codes (uses column name hints)
    FeatrixFipsCodeDetection,      ## Check FIPS codes (uses column name hints)
    FeatrixURLDetection,           ## Check URLs before domains (more specific)
    FeatrixDomainNameDetection,
    FeatrixVectorEmbeddingDetection,
    FeatrixYearJsonDetection,      ## Check for year-keyed JSON (more specific than generic JSON)
    FeatrixGeoJsonDetection,       ## Check for geo-keyed JSON (FIPS/zip/area codes)
    FeatrixJsonDetection,          ## Check generic JSON before free string
    FeatrixFreeStringDetection     ## KEEP AT END
]

DetectorDict = {
    ColumnType.SCALAR: FeatrixFieldScalarDetection,
    ColumnType.SET: FeatrixFieldSetDetection,
    ColumnType.TIMESTAMP: FeatrixFieldTimeDetection,
    # ColumnType.LIST_OF_SETS: FeatrixFieldListsOfASetDetection,
    ColumnType.FREE_STRING: FeatrixFreeStringDetection,
    ColumnType.EMAIL: FeatrixEmailDetection,
    ColumnType.PHONE: FeatrixPhoneDetection,
    ColumnType.ZIP_CODE: FeatrixZipCodeDetection,
    ColumnType.FIPS_CODE: FeatrixFipsCodeDetection,
    ColumnType.DOMAIN: FeatrixDomainNameDetection,
    ColumnType.URL: FeatrixURLDetection,
    ColumnType.VECTOR: FeatrixVectorEmbeddingDetection,
    ColumnType.JSON: FeatrixJsonDetection,
    ColumnType.YEAR_JSON: FeatrixYearJsonDetection,
    ColumnType.GEO_JSON: FeatrixGeoJsonDetection,
}

DetectorStrDict = {
    "scalar": FeatrixFieldScalarDetection,
    "set": FeatrixFieldSetDetection,
    "timestamp": FeatrixFieldTimeDetection,
    # "lists_of_a_set": FeatrixFieldListsOfASetDetection,
    "free_string": FeatrixFreeStringDetection,
    "email": FeatrixEmailDetection,
    "phone": FeatrixPhoneDetection,
    "zip_code": FeatrixZipCodeDetection,
    "fips_code": FeatrixFipsCodeDetection,
    "domain_name": FeatrixDomainNameDetection,
    "url": FeatrixURLDetection,
    "vector": FeatrixVectorEmbeddingDetection,
    "json": FeatrixJsonDetection,
    "year_json": FeatrixYearJsonDetection,
    "geo_json": FeatrixGeoJsonDetection,
}


def detect_column_type(col_series: pd.Series, col_name: str) -> str:
    """
    Detect the Featrix encoder type for a single column.

    This runs through all detectors (except vector, which must be manually set)
    and returns the codec name of the best matching detector.

    Args:
        col_series: The pandas Series containing the column data
        col_name: The name of the column (for debugging)

    Returns:
        The codec name string (e.g., "scalar", "set", "timestamp", "free_string",
        "email", "url", "domain_name", "json")

    Example:
        >>> import pandas as pd
        >>> from featrix.neural.detect import detect_column_type
        >>> series = pd.Series([1.0, 2.5, 3.7, None, 5.0])
        >>> detect_column_type(series, "price")
        'scalar'
    """
    # Compute basic stats needed by detectors
    non_null = col_series.dropna()
    num_not_nulls = len(non_null)
    num_uniques = col_series.nunique()

    # Skip vector detection - must be manually set
    detectors_to_try = [d for d in DetectorList if d != FeatrixVectorEmbeddingDetection]

    best_detector = None
    best_confidence = 0

    for detector_class in detectors_to_try:
        try:
            detector = detector_class(
                colSample=col_series,
                debugColName=col_name,
                numUniques=num_uniques,
                numNotNulls=num_not_nulls,
            )

            confidence = detector.confidence()
            if confidence <= 0:
                continue

            # Use >= so later detectors (more specific) win on ties
            if confidence >= best_confidence:
                best_detector = detector
                best_confidence = confidence

        except Exception as e:
            logger.debug(f"Detector {detector_class.__name__} failed on {col_name}: {e}")
            continue

    if best_detector is None:
        # Default to set (categorical) if nothing else matches
        logger.warning(f"No detector matched column '{col_name}' - defaulting to 'set'")
        return "set"

    codec_name = best_detector.get_codec_name()
    logger.debug(f"Column '{col_name}' detected as '{codec_name}' (confidence={best_confidence:.2f})")
    return codec_name


if __name__ == "__main__":
    import random
    import time

    s = "5112"
    ret = _isNumber(s)
    assert ret[0] == True, "isNumber must return True for non-delimited numbers."
    # print(ret)

    s = "51,12"
    ret = _isNumber(s)
    # print(ret)
    assert ret[0] == False, "isNumber must return False for badly delimited numbers."
    # print(ret)

    s = "511210,513210,561311,713"
    ret = _isNumber(s)
    assert ret[0] == False, "isNumber must return False for badly delimited numbers."
    # print(ret)

    s = "511,210,513,210,561,311,713"
    ret = _isNumber(s)
    assert ret[0] == True, "isNumber must return True for properly delimited numbers"
    # print(ret)

    s = "511,210,513,210.561,311,713"
    ret = _isNumber(s)
    assert (
        ret[0] == False
    ), "isNumber must return False for badly delimited numbers [comma after decimal]."
    # print(ret)

    # get some timestamps.
    timeNow = time.time()
    timeRange = 30 * 86400
    timeList = []
    for i in range(200):
        this_ts = timeNow - random.randint(0, timeRange)
        if random.randint(0, 100) > 70:
            timeList.append(None)
        else:
            timeList.append(str(datetime.fromtimestamp(this_ts)))

    # print(timeList)

    df = pd.DataFrame(timeList)
    # print(df)

    print(df.columns)
    fftd = FeatrixFieldTimeDetection(df[df.columns[0]], debugColName="test_time")
    print("....")
    print(fftd.confidence())

    ffscalar = FeatrixFieldScalarDetection(
        df[df.columns[0]], debugColName="scalar-vals"
    )
    print(ffscalar.confidence())

    ffset = FeatrixFieldSetDetection(df[df.columns[0]], debugColName="set-vals")
    print(ffset.confidence())
