#  -*- coding: utf-8 -*-
#
#  Copyright Featrix, Inc 2023-2026
#
#  Proprietary and Confidential.  Unauthorized use, copying or dissemination
#  of these materials is strictly prohibited.
"""
Geographic JSON Codec

Encodes JSON columns containing geographic codes with counts/weights, like:
- {"47037": 50, "06075": 10}  # FIPS codes with counts
- {"94105": 100, "10001": 25}  # Zip codes with counts
- {"615": 75, "408": 25}  # Area codes with counts

The key insight is that these columns represent geographic distributions,
and we want to capture:
1. Where is the centroid of activity?
2. How spread out is the activity? (local vs regional vs national)
3. How concentrated vs distributed is it?

Feature Flag:
    Set FEATRIX_GEO_SPREAD_ENABLED=1 to enable these features.
    Default is disabled for safe rollout.

Usage:
    from featrix.neural.geo_json_codec import GeoJsonCodec, detect_geo_json_type

    # Detect what type of geo codes are in the JSON
    geo_type = detect_geo_json_type(df['activity_by_county'])

    if geo_type:
        codec = GeoJsonCodec(df['activity_by_county'], geo_type=geo_type)
        token = codec.tokenize('{"47037": 50, "06075": 10}')
"""

import ast
import json
import logging
import math
import re
import torch
from typing import Dict, List, Optional, Tuple

from featrix.neural.featrix_token import Token, TokenStatus
from featrix.neural.geo_spread import (
    GEO_SPREAD_ENABLED,
    GEO_SPREAD_DIM,
    compute_geo_spread,
    compute_geo_spread_from_codes,
    empty_geo_spread_tensor,
    GeoSpreadFeatures,
)
from featrix.neural.phone_codec import AREA_CODE_COORDS
from featrix.neural.zip_codec import ZIP_PREFIX_COORDS
from featrix.neural.data_fips import COUNTY_FIPS_COORDS
from featrix.neural.fips_codec import STATE_FIPS

logger = logging.getLogger(__name__)

# Token dimension for geo JSON codec
# Uses geo spread features (10) + some additional context features
GEO_JSON_TOKEN_DIM = GEO_SPREAD_DIM + 4  # +4 for: valid_flag, total_weight_log, num_codes_log, geo_type_idx


def _safe_parse_json_dict(value: str) -> Optional[Dict]:
    """Safely parse a JSON-like dict string."""
    if not isinstance(value, str):
        if isinstance(value, dict):
            return value
        return None

    value = value.strip()
    if not (value.startswith('{') and value.endswith('}')):
        return None

    # Try standard JSON parsing
    try:
        parsed = json.loads(value)
        if isinstance(parsed, dict):
            return parsed
    except (json.JSONDecodeError, TypeError):
        pass

    # Try ast.literal_eval for Python dict literals
    try:
        parsed = ast.literal_eval(value)
        if isinstance(parsed, dict):
            return parsed
    except (ValueError, SyntaxError):
        pass

    return None


def detect_geo_json_type(df_col) -> Optional[str]:
    """
    Detect what type of geographic codes are in a JSON column.

    Samples values from the column and checks if keys look like:
    - FIPS codes (5-digit county codes)
    - Zip codes (5-digit)
    - Area codes (3-digit)

    Args:
        df_col: pandas Series containing JSON strings

    Returns:
        'fips', 'zip', 'area_code', or None if not detected
    """
    fips_score = 0
    zip_score = 0
    area_code_score = 0
    total_checked = 0

    # Sample up to 100 non-null values
    for val in df_col.dropna().head(100):
        parsed = _safe_parse_json_dict(val)
        if not parsed:
            continue

        for key in parsed.keys():
            key_str = str(key).strip()
            digits = re.sub(r'[^\d]', '', key_str)

            if len(digits) == 5:
                # Could be FIPS or zip
                # Check if it's a known FIPS code
                if digits in COUNTY_FIPS_COORDS:
                    fips_score += 2
                # Check if first 3 digits are a known zip prefix
                elif digits[:3] in ZIP_PREFIX_COORDS:
                    zip_score += 1
                # Check if first 2 digits are valid state FIPS
                elif digits[:2] in STATE_FIPS:
                    fips_score += 1
                else:
                    # Default to zip if 5 digits
                    zip_score += 0.5

            elif len(digits) == 3:
                # Likely area code
                if digits in AREA_CODE_COORDS:
                    area_code_score += 2
                else:
                    area_code_score += 0.5

            elif len(digits) == 4:
                # Might be FIPS missing leading zero
                padded = '0' + digits
                if padded in COUNTY_FIPS_COORDS:
                    fips_score += 2
                elif padded[:2] in STATE_FIPS:
                    fips_score += 1

        total_checked += 1

    if total_checked == 0:
        return None

    # Return the type with highest score
    scores = {'fips': fips_score, 'zip': zip_score, 'area_code': area_code_score}
    best_type = max(scores, key=scores.get)

    # Only return if we have some confidence
    if scores[best_type] >= total_checked * 0.3:
        logger.info(f"Detected geo JSON type: {best_type} (scores: {scores})")
        return best_type

    return None


def _get_code_to_latlong(geo_type: str) -> Dict[str, Tuple[float, float]]:
    """Get the code->latlong mapping for a geo type."""
    if geo_type == 'fips':
        return {k: (v[0], v[1]) for k, v in COUNTY_FIPS_COORDS.items()}
    elif geo_type == 'zip':
        return {k: (v[0], v[1]) for k, v in ZIP_PREFIX_COORDS.items()}
    elif geo_type == 'area_code':
        return AREA_CODE_COORDS
    else:
        return {}


def _normalize_code(code: str, geo_type: str) -> str:
    """Normalize a geo code for lookup."""
    code = str(code).strip()
    digits = re.sub(r'[^\d]', '', code)

    if geo_type == 'fips':
        # Pad to 5 digits if needed
        if len(digits) == 4:
            digits = '0' + digits
        return digits
    elif geo_type == 'zip':
        # Use 3-digit prefix
        return digits[:3] if len(digits) >= 3 else digits
    elif geo_type == 'area_code':
        return digits[:3] if len(digits) >= 3 else digits

    return digits


class GeoJsonCodec:
    """
    Codec for JSON columns containing geographic codes with weights.

    Tokenizes JSON dicts like {"47037": 50, "06075": 10} into:
    - Geo spread features (centroid, spread, concentration, etc.)
    - Metadata features (total weight, number of codes)
    """

    def __init__(self, df_col, geo_type: str = 'fips', embed_dim: int = 768,
                 string_cache=None, detector=None):
        """
        Initialize the GeoJsonCodec.

        Args:
            df_col: pandas Series containing JSON strings
            geo_type: Type of geo codes ('fips', 'zip', 'area_code')
            embed_dim: embedding dimension (not used currently)
            string_cache: optional string cache
            detector: optional detector instance
        """
        self.embed_dim = embed_dim
        self.string_cache = string_cache
        self.detector = detector
        self.geo_type = geo_type

        # Get code->latlong mapping for this geo type
        self.code_to_latlong = _get_code_to_latlong(geo_type)

        # Geo type index for feature encoding
        self.geo_type_idx = {'fips': 0.0, 'zip': 0.33, 'area_code': 0.67}.get(geo_type, 0.0)

        # Create special tokens
        self._not_present_token = self._create_special_token(TokenStatus.NOT_PRESENT)
        self._unknown_token = self._create_special_token(TokenStatus.UNKNOWN)

        logger.info(f"GeoJsonCodec initialized for {geo_type} with {len(self.code_to_latlong)} known codes")

    def _create_special_token(self, status: TokenStatus) -> Token:
        """Create a special token (NOT_PRESENT or UNKNOWN)."""
        value = torch.zeros(GEO_JSON_TOKEN_DIM)
        return Token(value=value, status=status)

    def get_not_present_token(self) -> Token:
        return self._not_present_token

    def get_unknown_token(self) -> Token:
        return self._unknown_token

    def get_codec_name(self) -> str:
        return f"geo_json_{self.geo_type}"

    def _parse_code_weights(self, value) -> Optional[Dict[str, float]]:
        """Parse a JSON value into code->weight dict."""
        parsed = _safe_parse_json_dict(value)
        if not parsed:
            return None

        code_weights = {}
        for key, weight in parsed.items():
            # Normalize the code
            code = _normalize_code(str(key), self.geo_type)

            # Convert weight to float
            try:
                weight_float = float(weight)
                if weight_float > 0:
                    code_weights[code] = weight_float
            except (ValueError, TypeError):
                continue

        return code_weights if code_weights else None

    def get_geo_spread_features(self, value) -> GeoSpreadFeatures:
        """
        Compute geo spread features for a JSON value.

        Args:
            value: JSON string or dict with code->weight mapping

        Returns:
            GeoSpreadFeatures instance
        """
        code_weights = self._parse_code_weights(value)
        if not code_weights:
            return GeoSpreadFeatures()

        # Build list of (lat, lon, weight) points
        points = []
        state_fips_list = []

        for code, weight in code_weights.items():
            if code in self.code_to_latlong:
                lat, lon = self.code_to_latlong[code]
                points.append((lat, lon, weight))

                # Extract state FIPS if applicable
                if self.geo_type == 'fips' and len(code) >= 2:
                    state_fips_list.append(code[:2])

        if not points:
            return GeoSpreadFeatures()

        return compute_geo_spread(points, state_fips_list if state_fips_list else None)

    def tokenize(self, value) -> Token:
        """
        Convert a JSON value to a Token.

        Args:
            value: JSON string or dict with code->weight mapping

        Returns:
            Token with geo spread features
        """
        if value is None or (isinstance(value, float) and math.isnan(value)):
            return self._not_present_token

        if isinstance(value, str) and value.strip() == '':
            return self._not_present_token

        code_weights = self._parse_code_weights(value)
        if not code_weights:
            return self._unknown_token

        # Compute geo spread features
        geo_features = self.get_geo_spread_features(value)
        geo_tensor = geo_features.to_tensor()

        # Add metadata features
        total_weight = sum(code_weights.values())
        num_codes = len(code_weights)

        metadata = torch.tensor([
            1.0,  # valid_flag
            min(math.log(total_weight + 1) / 10.0, 1.0),  # total_weight_log normalized
            min(math.log(num_codes + 1) / 5.0, 1.0),  # num_codes_log normalized
            self.geo_type_idx,  # geo_type indicator
        ], dtype=torch.float32)

        # Concatenate features
        features = torch.cat([geo_tensor, metadata])
        assert features.shape[0] == GEO_JSON_TOKEN_DIM, f"Expected {GEO_JSON_TOKEN_DIM}, got {features.shape[0]}"

        return Token(value=features, status=TokenStatus.OK)

    def get_weighted_locations(self, value) -> Optional[List[Tuple[float, float, float]]]:
        """
        Get the weighted location points from a JSON value.

        Args:
            value: JSON string or dict with code->weight mapping

        Returns:
            List of (lat, lon, weight) tuples, or None if invalid
        """
        code_weights = self._parse_code_weights(value)
        if not code_weights:
            return None

        points = []
        for code, weight in code_weights.items():
            if code in self.code_to_latlong:
                lat, lon = self.code_to_latlong[code]
                points.append((lat, lon, weight))

        return points if points else None

    def get_centroid(self, value) -> Optional[Tuple[float, float]]:
        """
        Get the weighted centroid of the geo distribution.

        Args:
            value: JSON string or dict with code->weight mapping

        Returns:
            (lat, lon) tuple for centroid, or None if invalid
        """
        features = self.get_geo_spread_features(value)
        if features.num_locations == 0:
            return None
        # Denormalize from [-1, 1] back to actual coords
        # normalize_lat: (lat - 37.5) / 12.5 -> lat = normalized * 12.5 + 37.5
        # normalize_long: (lon + 95.0) / 30.0 -> lon = normalized * 30.0 - 95.0
        lat = features.centroid_lat * 12.5 + 37.5
        lon = features.centroid_long * 30.0 - 95.0
        return (lat, lon)

    def compute_distance_stats(
        self,
        value,
        target_lat: float,
        target_lon: float,
    ) -> Dict[str, float]:
        """
        Compute distance statistics from geo distribution to a target point.

        Args:
            value: JSON string or dict with code->weight mapping
            target_lat: Target latitude
            target_lon: Target longitude

        Returns:
            Dict with distance statistics:
            - min_distance_km: Distance to closest point
            - max_distance_km: Distance to farthest point
            - weighted_avg_distance_km: Weight-averaged distance
            - centroid_distance_km: Distance from centroid to target
            - weighted_fraction_within_100km: Fraction of weight within 100km
            - weighted_fraction_within_500km: Fraction of weight within 500km
        """
        from featrix.neural.phone_codec import haversine_distance

        weighted_locations = self.get_weighted_locations(value)
        if weighted_locations is None or len(weighted_locations) == 0:
            return {
                'min_distance_km': 0.0,
                'max_distance_km': 0.0,
                'weighted_avg_distance_km': 0.0,
                'centroid_distance_km': 0.0,
                'weighted_fraction_within_100km': 0.0,
                'weighted_fraction_within_500km': 0.0,
            }

        # At this point weighted_locations is guaranteed to be a non-empty list
        # pylint: disable=not-an-iterable
        points: List[Tuple[float, float, float]] = weighted_locations  # type: ignore[assignment]
        total_weight = sum(p[2] for p in points)
        # pylint: enable=not-an-iterable
        distances = []
        weighted_sum = 0.0
        weight_within_100 = 0.0
        weight_within_500 = 0.0

        for lat, lon, weight in points:  # pylint: disable=not-an-iterable
            dist = haversine_distance(lat, lon, target_lat, target_lon)
            distances.append(dist)
            weighted_sum += dist * weight
            if dist <= 100:
                weight_within_100 += weight
            if dist <= 500:
                weight_within_500 += weight

        # Centroid distance
        centroid = self.get_centroid(value)
        centroid_dist = 0.0
        if centroid:
            centroid_dist = haversine_distance(centroid[0], centroid[1], target_lat, target_lon)

        return {
            'min_distance_km': min(distances) if distances else 0.0,
            'max_distance_km': max(distances) if distances else 0.0,
            'weighted_avg_distance_km': weighted_sum / total_weight if total_weight > 0 else 0.0,
            'centroid_distance_km': centroid_dist,
            'weighted_fraction_within_100km': weight_within_100 / total_weight if total_weight > 0 else 0.0,
            'weighted_fraction_within_500km': weight_within_500 / total_weight if total_weight > 0 else 0.0,
        }


def create_geo_json_codec(df_col, geo_type: Optional[str] = None,
                          embed_dim: int = 768, string_cache=None,
                          detector=None) -> Optional[GeoJsonCodec]:
    """
    Factory function to create a GeoJsonCodec.

    Args:
        df_col: pandas Series containing JSON strings
        geo_type: Type of geo codes ('fips', 'zip', 'area_code'), or None to auto-detect
        embed_dim: embedding dimension
        string_cache: optional string cache
        detector: optional detector instance

    Returns:
        GeoJsonCodec instance, or None if geo type couldn't be detected
    """
    if geo_type is None:
        geo_type = detect_geo_json_type(df_col)

    if geo_type is None:
        logger.warning("Could not detect geo JSON type")
        return None

    return GeoJsonCodec(df_col, geo_type=geo_type, embed_dim=embed_dim,
                        string_cache=string_cache, detector=detector)


# Quick test
if __name__ == '__main__':
    import os
    os.environ['FEATRIX_GEO_SPREAD_ENABLED'] = '1'

    # Reimport to pick up the flag
    from featrix.neural.geo_spread import GEO_SPREAD_ENABLED
    print(f"GEO_SPREAD_ENABLED: {GEO_SPREAD_ENABLED}")

    import pandas as pd

    # Test FIPS JSON data
    test_data = [
        '{"47037": 50, "06075": 10}',  # Nashville + SF (bi-coastal)
        '{"47037": 100}',  # Just Nashville (single location)
        '{"06075": 30, "06001": 40, "06081": 30}',  # Bay Area (local)
        '{"17031": 25, "36061": 25, "06037": 25, "48201": 25}',  # Chicago, NYC, LA, Houston (national)
        '',
        None,
    ]
    df = pd.Series(test_data)

    print("\nGeo JSON Codec Test (FIPS)")
    print("=" * 70)

    # Auto-detect type
    detected = detect_geo_json_type(df)
    print(f"Detected type: {detected}")

    if detected:
        codec = GeoJsonCodec(df, geo_type=detected)

        for val in test_data:
            token = codec.tokenize(val)
            if token.status == TokenStatus.OK:
                geo_features = codec.get_geo_spread_features(val)
                print(f"\n  {str(val)[:50]:50}")
                print(f"    spread={geo_features.spread_km:.0f}km, "
                      f"concentration={geo_features.concentration:.2f}, "
                      f"entropy={geo_features.region_entropy:.2f}")
            else:
                print(f"\n  {str(val)[:50]:50} -> {token.status.name}")
