#  -*- coding: utf-8 -*-
#
#  Copyright Featrix, Inc 2023-2026
#
#  Proprietary and Confidential. Unauthorized use, copying or dissemination
#  of these materials is strictly prohibited.
"""
Geographic JSON Relationship Operations

Type-aware relationship operations for GEO_JSON columns.
Supports:
1. GeoJson × Address/AddressHybrid: Compare geo distribution with address location
2. GeoJson × FIPS: Compare geo distribution with FIPS code location
3. GeoJson × Zip: Compare geo distribution with zip code location
4. GeoJson × Phone: Compare geo distribution with phone area code location
5. GeoJson × GeoJson: Compare two geographic distributions
6. GeoJson × Scalar: Geographic distribution × value correlation
7. GeoJson × Set: Geographic patterns × category membership

GeoJson encodes geographic distributions (centroids, spread, concentration).
The relationship ops capture spatial correlations with other geo-aware columns.

Token feature indices (from GeoJsonCodec, GEO_SPREAD_DIM=10 + 4 metadata):
    0-9: geo_spread features (centroid_lat, centroid_lon, spread, concentration, etc.)
    10: valid_flag
    11: total_weight_log
    12: num_codes_log
    13: geo_type_idx (0=fips, 0.33=zip, 0.67=area_code)
"""
import logging
import torch
import torch.nn as nn
from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from featrix.neural.type_aware_ops_config import TypeAwareOpsConfig

logger = logging.getLogger(__name__)


class GeoJsonGeoOps(nn.Module):
    """
    Type-aware operations for GEO_JSON × GEO columns (FIPS, Zip, Phone, Address).

    Captures patterns like:
    - Is the geo column's location within the geo distribution's spread?
    - Distance from geo column location to distribution centroid
    - Does the geo column fall in a high-weight region of the distribution?

    Works with any geo-aware column that produces embeddings encoding location.
    """

    def __init__(
        self,
        d_model: int,
        config: Optional["TypeAwareOpsConfig"] = None,
    ):
        super().__init__()
        self.d_model = d_model
        self.config = config

        # GeoJson-conditioned geo gating
        self.geo_json_gate_mlp = nn.Sequential(
            nn.Linear(d_model, d_model // 2),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model // 2, d_model),
        )

        # Geo-conditioned geo_json interpretation
        self.geo_context_mlp = nn.Sequential(
            nn.Linear(d_model, d_model // 2),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model // 2, d_model),
        )

        # Spatial correlation
        self.spatial_mlp = nn.Sequential(
            nn.Linear(d_model * 2, d_model),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model, d_model),
        )

        # Fusion
        self.fusion_mlp = nn.Sequential(
            nn.Linear(d_model * 4, d_model),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model, d_model),
        )

        self.output_norm = nn.LayerNorm(d_model)

    def forward(
        self,
        geo_json_embedding: torch.Tensor,  # (batch, d_model)
        geo_embedding: torch.Tensor,  # (batch, d_model) from FIPS/Zip/Phone/Address encoder
    ) -> torch.Tensor:
        """Compute relationship for GeoJson × Geo pair."""
        # GeoJson gates geo
        geo_json_gate = torch.sigmoid(self.geo_json_gate_mlp(geo_json_embedding))
        gated_geo = geo_embedding * geo_json_gate

        # Geo contextualizes geo_json
        geo_context = self.geo_context_mlp(geo_embedding)
        contextualized_geo_json = geo_json_embedding * geo_context

        # Spatial correlation
        spatial = self.spatial_mlp(
            torch.cat([geo_json_embedding, geo_embedding], dim=-1)
        )

        # Product
        product = geo_json_embedding * geo_embedding

        # Fusion
        combined = torch.cat([
            gated_geo,
            contextualized_geo_json,
            spatial,
            product,
        ], dim=-1)

        return self.output_norm(self.fusion_mlp(combined))


# Alias for specific geo types (all use same architecture since they work on embeddings)
GeoJsonFipsOps = GeoJsonGeoOps
GeoJsonZipOps = GeoJsonGeoOps
GeoJsonPhoneOps = GeoJsonGeoOps
GeoJsonAddressOps = GeoJsonGeoOps


# Number of distance features from GeoJsonCodec.compute_distance_stats()
GEO_DISTANCE_FEATURES_DIM = 6


class GeoJsonGeoOpsWithDistance(nn.Module):
    """
    Enhanced GeoJsonGeoOps that can incorporate raw lat/lon distance features.

    When distance_features are provided (computed from GeoJsonCodec.compute_distance_stats()),
    this module encodes them alongside the embedding-based features for richer spatial
    relationship modeling.

    Distance features (6 dims):
    - min_distance_km: Distance to closest point in distribution
    - max_distance_km: Distance to farthest point
    - weighted_avg_distance_km: Weight-averaged distance
    - centroid_distance_km: Distance from centroid to geo point
    - weighted_fraction_within_100km: Fraction of weight within 100km
    - weighted_fraction_within_500km: Fraction of weight within 500km
    """

    def __init__(
        self,
        d_model: int,
        config: Optional["TypeAwareOpsConfig"] = None,
    ):
        super().__init__()
        self.d_model = d_model
        self.config = config

        # Embedding-based components (same as GeoJsonGeoOps)
        self.geo_json_gate_mlp = nn.Sequential(
            nn.Linear(d_model, d_model // 2),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model // 2, d_model),
        )

        self.geo_context_mlp = nn.Sequential(
            nn.Linear(d_model, d_model // 2),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model // 2, d_model),
        )

        self.spatial_mlp = nn.Sequential(
            nn.Linear(d_model * 2, d_model),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model, d_model),
        )

        # Distance feature encoder
        self.distance_encoder = nn.Sequential(
            nn.Linear(GEO_DISTANCE_FEATURES_DIM, d_model // 4),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model // 4, d_model // 2),
            nn.ReLU(),
            nn.Linear(d_model // 2, d_model),
        )

        # Fusion with distance features
        self.fusion_mlp = nn.Sequential(
            nn.Linear(d_model * 5, d_model),  # 4 embedding features + 1 distance feature
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model, d_model),
        )

        # Fusion without distance features (fallback)
        self.fusion_mlp_no_dist = nn.Sequential(
            nn.Linear(d_model * 4, d_model),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model, d_model),
        )

        self.output_norm = nn.LayerNorm(d_model)

    def forward(
        self,
        geo_json_embedding: torch.Tensor,  # (batch, d_model)
        geo_embedding: torch.Tensor,  # (batch, d_model)
        distance_features: Optional[torch.Tensor] = None,  # (batch, 6) from compute_distance_stats
    ) -> torch.Tensor:
        """
        Compute relationship for GeoJson × Geo pair with optional distance features.

        Args:
            geo_json_embedding: GeoJson column embedding
            geo_embedding: Geo column (FIPS/Zip/Phone/Address) embedding
            distance_features: Optional tensor with distance stats (batch, 6)
                If provided, must contain: min_dist, max_dist, weighted_avg_dist,
                centroid_dist, frac_within_100km, frac_within_500km
        """
        # Embedding-based features (same as GeoJsonGeoOps)
        geo_json_gate = torch.sigmoid(self.geo_json_gate_mlp(geo_json_embedding))
        gated_geo = geo_embedding * geo_json_gate

        geo_context = self.geo_context_mlp(geo_embedding)
        contextualized_geo_json = geo_json_embedding * geo_context

        spatial = self.spatial_mlp(
            torch.cat([geo_json_embedding, geo_embedding], dim=-1)
        )

        product = geo_json_embedding * geo_embedding

        if distance_features is not None:
            # Normalize distance features
            # Log-normalize distances (km can range from 0 to 20000+)
            normalized_dist = distance_features.clone()
            # Indices 0, 1, 2, 3 are distances in km
            normalized_dist[:, :4] = torch.log1p(normalized_dist[:, :4]) / 10.0  # log(1+x)/10
            normalized_dist[:, :4] = normalized_dist[:, :4].clamp(0, 1)
            # Indices 4, 5 are fractions already in [0, 1]

            # Encode distance features
            distance_encoded = self.distance_encoder(normalized_dist)

            # Fusion with distance
            combined = torch.cat([
                gated_geo,
                contextualized_geo_json,
                spatial,
                product,
                distance_encoded,
            ], dim=-1)
            output = self.fusion_mlp(combined)
        else:
            # Fallback to embedding-only fusion
            combined = torch.cat([
                gated_geo,
                contextualized_geo_json,
                spatial,
                product,
            ], dim=-1)
            output = self.fusion_mlp_no_dist(combined)

        return self.output_norm(output)


class GeoColumnOps(nn.Module):
    """
    Type-aware operations for geo column pairs (FIPS × FIPS, Zip × Zip, FIPS × Zip, etc.)

    These columns all have lat/lon coordinates that can be extracted, so we can compute
    actual geographic features like haversine distance, same-region, etc.

    This is a simpler version of GeoGeoOps that works purely with embeddings when
    raw coordinates aren't available in the forward pass.
    """

    def __init__(
        self,
        d_model: int,
        config: Optional["TypeAwareOpsConfig"] = None,
    ):
        super().__init__()
        self.d_model = d_model
        self.config = config

        # Embedding-based spatial comparison
        self.spatial_comparison_mlp = nn.Sequential(
            nn.Linear(d_model * 2, d_model),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model, d_model),
        )

        # Difference encoding (captures direction/distance in embedding space)
        self.difference_mlp = nn.Sequential(
            nn.Linear(d_model, d_model // 2),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model // 2, d_model),
        )

        # Product interaction
        self.product_mlp = nn.Sequential(
            nn.Linear(d_model, d_model // 2),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model // 2, d_model),
        )

        # Fusion
        self.fusion_mlp = nn.Sequential(
            nn.Linear(d_model * 3, d_model),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model, d_model),
        )

        self.output_norm = nn.LayerNorm(d_model)

    def forward(
        self,
        geo_embedding_a: torch.Tensor,  # (batch, d_model) from FIPS/Zip/Phone/Address
        geo_embedding_b: torch.Tensor,  # (batch, d_model) from FIPS/Zip/Phone/Address
    ) -> torch.Tensor:
        """Compute relationship for Geo × Geo pair (embedding-only version)."""
        # Spatial comparison
        comparison = self.spatial_comparison_mlp(
            torch.cat([geo_embedding_a, geo_embedding_b], dim=-1)
        )

        # Difference encoding (captures relative position in embedding space)
        difference = self.difference_mlp(geo_embedding_a - geo_embedding_b)

        # Product (captures correlation)
        product = self.product_mlp(geo_embedding_a * geo_embedding_b)

        # Fusion
        combined = torch.cat([comparison, difference, product], dim=-1)

        return self.output_norm(self.fusion_mlp(combined))


# Aliases for specific geo column pair types
FipsFipsOps = GeoColumnOps
ZipZipOps = GeoColumnOps
PhonePhoneOps = GeoColumnOps
FipsZipOps = GeoColumnOps
FipsPhoneOps = GeoColumnOps
ZipPhoneOps = GeoColumnOps
AddressFipsOps = GeoColumnOps
AddressZipOps = GeoColumnOps
AddressPhoneOps = GeoColumnOps


class GeoJsonGeoJsonOps(nn.Module):
    """
    Type-aware operations for GEO_JSON × GEO_JSON column pairs.

    Captures patterns like:
    - Do two geographic distributions overlap?
    - Are their centroids close or far?
    - Is one more concentrated than the other?
    - Do they have similar spread patterns?

    Example: "customer_locations_by_county" vs "store_locations_by_county"
    """

    def __init__(
        self,
        d_model: int,
        config: Optional["TypeAwareOpsConfig"] = None,
    ):
        super().__init__()
        self.d_model = d_model
        self.config = config

        # Distribution comparison
        self.comparison_mlp = nn.Sequential(
            nn.Linear(d_model * 2, d_model),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model, d_model),
        )

        # Difference encoding
        self.difference_mlp = nn.Sequential(
            nn.Linear(d_model, d_model // 2),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model // 2, d_model),
        )

        # Embedding interaction
        self.interaction_mlp = nn.Sequential(
            nn.Linear(d_model * 3, d_model),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model, d_model),
        )

        # Fusion
        self.fusion_mlp = nn.Sequential(
            nn.Linear(d_model * 3, d_model),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model, d_model),
        )

        self.output_norm = nn.LayerNorm(d_model)

    def forward(
        self,
        geo_json_embedding_a: torch.Tensor,  # (batch, d_model)
        geo_json_embedding_b: torch.Tensor,  # (batch, d_model)
    ) -> torch.Tensor:
        """Compute relationship for GeoJson × GeoJson pair."""
        # Direct comparison
        comparison = self.comparison_mlp(
            torch.cat([geo_json_embedding_a, geo_json_embedding_b], dim=-1)
        )

        # Difference encoding (captures asymmetric relationships)
        difference = self.difference_mlp(geo_json_embedding_a - geo_json_embedding_b)

        # Embedding interaction
        interaction_input = torch.cat([
            geo_json_embedding_a,
            geo_json_embedding_b,
            geo_json_embedding_a * geo_json_embedding_b,
        ], dim=-1)
        interaction = self.interaction_mlp(interaction_input)

        # Fusion
        combined = torch.cat([
            comparison,
            difference,
            interaction,
        ], dim=-1)

        return self.output_norm(self.fusion_mlp(combined))


class GeoJsonScalarOps(nn.Module):
    """
    Type-aware operations for GEO_JSON × SCALAR column pairs.

    Captures patterns like:
    - Does wider geographic spread correlate with higher scalar values?
    - Does concentration correlate with scalar magnitude?
    - Regional patterns in scalar distribution
    """

    def __init__(
        self,
        d_model: int,
        config: Optional["TypeAwareOpsConfig"] = None,
    ):
        super().__init__()
        self.d_model = d_model
        self.config = config

        # GeoJson-conditioned scalar scaling
        self.geo_json_scale_mlp = nn.Sequential(
            nn.Linear(d_model, d_model // 2),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model // 2, d_model),
        )

        # Scalar-conditioned geo_json gating
        self.scalar_gate_mlp = nn.Sequential(
            nn.Linear(d_model, d_model // 2),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model // 2, d_model),
        )

        # Spatial-scalar correlation
        self.correlation_mlp = nn.Sequential(
            nn.Linear(d_model * 2, d_model),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model, d_model),
        )

        # Fusion
        self.fusion_mlp = nn.Sequential(
            nn.Linear(d_model * 4, d_model),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model, d_model),
        )

        self.output_norm = nn.LayerNorm(d_model)

    def forward(
        self,
        geo_json_embedding: torch.Tensor,  # (batch, d_model)
        scalar_embedding: torch.Tensor,  # (batch, d_model)
    ) -> torch.Tensor:
        """Compute relationship for GeoJson × Scalar pair."""
        # GeoJson scales scalar
        geo_json_scale = self.geo_json_scale_mlp(geo_json_embedding)
        scaled_scalar = scalar_embedding * geo_json_scale

        # Scalar gates geo_json
        scalar_gate = torch.sigmoid(self.scalar_gate_mlp(scalar_embedding))
        gated_geo_json = geo_json_embedding * scalar_gate

        # Correlation
        correlation = self.correlation_mlp(
            torch.cat([geo_json_embedding, scalar_embedding], dim=-1)
        )

        # Product
        product = geo_json_embedding * scalar_embedding

        # Fusion
        combined = torch.cat([
            scaled_scalar,
            gated_geo_json,
            correlation,
            product,
        ], dim=-1)

        return self.output_norm(self.fusion_mlp(combined))


class GeoJsonSetOps(nn.Module):
    """
    Type-aware operations for GEO_JSON × SET column pairs.

    Captures patterns like:
    - Do certain categories correlate with geographic spread?
    - Regional category preferences
    - Geographic concentration × category membership
    """

    def __init__(
        self,
        d_model: int,
        config: Optional["TypeAwareOpsConfig"] = None,
    ):
        super().__init__()
        self.d_model = d_model
        self.config = config

        # GeoJson-conditioned set gating
        self.geo_json_gate_mlp = nn.Sequential(
            nn.Linear(d_model, d_model // 2),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model // 2, d_model),
        )

        # Set-conditioned geo_json interpretation
        self.set_context_mlp = nn.Sequential(
            nn.Linear(d_model, d_model // 2),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model // 2, d_model),
        )

        # Interaction
        self.interaction_mlp = nn.Sequential(
            nn.Linear(d_model * 2, d_model),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model, d_model),
        )

        # Fusion
        self.fusion_mlp = nn.Sequential(
            nn.Linear(d_model * 4, d_model),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model, d_model),
        )

        self.output_norm = nn.LayerNorm(d_model)

    def forward(
        self,
        geo_json_embedding: torch.Tensor,  # (batch, d_model)
        set_embedding: torch.Tensor,  # (batch, d_model)
    ) -> torch.Tensor:
        """Compute relationship for GeoJson × Set pair."""
        # GeoJson gates set
        geo_json_gate = torch.sigmoid(self.geo_json_gate_mlp(geo_json_embedding))
        gated_set = set_embedding * geo_json_gate

        # Set contextualizes geo_json
        set_context = self.set_context_mlp(set_embedding)
        contextualized_geo_json = geo_json_embedding * set_context

        # Interaction
        interaction = self.interaction_mlp(
            torch.cat([geo_json_embedding, set_embedding], dim=-1)
        )

        # Product
        product = geo_json_embedding * set_embedding

        # Fusion
        combined = torch.cat([
            gated_set,
            contextualized_geo_json,
            interaction,
            product,
        ], dim=-1)

        return self.output_norm(self.fusion_mlp(combined))


class GeoJsonTimestampOps(nn.Module):
    """
    Type-aware operations for GEO_JSON × TIMESTAMP column pairs.

    Captures patterns like:
    - Geographic distribution × time patterns (seasonality by region)
    - Temporal evolution of geographic spread
    """

    def __init__(
        self,
        d_model: int,
        config: Optional["TypeAwareOpsConfig"] = None,
    ):
        super().__init__()
        self.d_model = d_model
        self.config = config

        # GeoJson-conditioned temporal interpretation
        self.geo_json_temporal_mlp = nn.Sequential(
            nn.Linear(d_model, d_model // 2),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model // 2, d_model),
        )

        # Temporal-conditioned geo_json interpretation
        self.temporal_geo_json_mlp = nn.Sequential(
            nn.Linear(d_model, d_model // 2),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model // 2, d_model),
        )

        # Spatiotemporal interaction
        self.interaction_mlp = nn.Sequential(
            nn.Linear(d_model * 2, d_model),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model, d_model),
        )

        # Fusion
        self.fusion_mlp = nn.Sequential(
            nn.Linear(d_model * 4, d_model),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model, d_model),
        )

        self.output_norm = nn.LayerNorm(d_model)

    def forward(
        self,
        geo_json_embedding: torch.Tensor,  # (batch, d_model)
        timestamp_embedding: torch.Tensor,  # (batch, d_model)
    ) -> torch.Tensor:
        """Compute relationship for GeoJson × Timestamp pair."""
        # GeoJson modulates temporal
        geo_json_temporal = self.geo_json_temporal_mlp(geo_json_embedding)
        modulated_temporal = timestamp_embedding * geo_json_temporal

        # Temporal modulates geo_json
        temporal_geo_json = self.temporal_geo_json_mlp(timestamp_embedding)
        modulated_geo_json = geo_json_embedding * temporal_geo_json

        # Interaction
        interaction = self.interaction_mlp(
            torch.cat([geo_json_embedding, timestamp_embedding], dim=-1)
        )

        # Product
        product = geo_json_embedding * timestamp_embedding

        # Fusion
        combined = torch.cat([
            modulated_temporal,
            modulated_geo_json,
            interaction,
            product,
        ], dim=-1)

        return self.output_norm(self.fusion_mlp(combined))
