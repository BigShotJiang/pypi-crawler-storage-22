#
#  -*- coding: utf-8 -*-
#
#  Copyright Featrix, Inc 2023-2025
#
#  Proprietary and Confidential.  Unauthorized use, copying or dissemination
#  of these materials is strictly prohibited.
#

"""
Geographic Spread Features

This module provides a unified way to compute geographic spread/mobility features
from any geo-locatable data (phone area codes, zip codes, FIPS codes, cities, etc.)

The key insight is that geographic spread is a behavioral signal that should be
comparable across different source types. Someone with phone calls from Nashville
and San Francisco has the same ~3000km spread as someone with FIPS activity in
Davidson County TN and San Francisco County CA.

Feature Flag:
    Set FEATRIX_GEO_SPREAD_ENABLED=1 to enable these features.
    Default is disabled for safe rollout.

Usage:
    from featrix.neural.geo_spread import (
        GeoSpreadFeatures,
        compute_geo_spread,
        GEO_SPREAD_ENABLED
    )

    if GEO_SPREAD_ENABLED:
        # List of (lat, long, weight) tuples
        points = [(36.16, -86.78, 50), (37.77, -122.42, 10)]
        features = compute_geo_spread(points)
        # features.to_tensor() -> 10-dim feature vector
"""

import logging
import math
import os
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import torch

logger = logging.getLogger(__name__)

# Feature flag - disabled by default for safe rollout
GEO_SPREAD_ENABLED = os.environ.get('FEATRIX_GEO_SPREAD_ENABLED', '0') == '1'

# Geographic constants
EARTH_RADIUS_KM = 6371.0

# US region definitions (state FIPS -> region)
# Used for regional diversity features
STATE_TO_REGION = {
    # Northeast
    '09': 'northeast', '23': 'northeast', '25': 'northeast', '33': 'northeast',
    '44': 'northeast', '50': 'northeast', '34': 'northeast', '36': 'northeast',
    '42': 'northeast',
    # Southeast
    '01': 'southeast', '05': 'southeast', '10': 'southeast', '11': 'southeast',
    '12': 'southeast', '13': 'southeast', '21': 'southeast', '22': 'southeast',
    '24': 'southeast', '28': 'southeast', '37': 'southeast', '45': 'southeast',
    '47': 'southeast', '51': 'southeast', '54': 'southeast',
    # Midwest
    '17': 'midwest', '18': 'midwest', '19': 'midwest', '20': 'midwest',
    '26': 'midwest', '27': 'midwest', '29': 'midwest', '31': 'midwest',
    '38': 'midwest', '39': 'midwest', '46': 'midwest', '55': 'midwest',
    # West (Mountain + Pacific)
    '02': 'west', '04': 'west', '06': 'west', '08': 'west', '15': 'west',
    '16': 'west', '30': 'west', '32': 'west', '35': 'west', '41': 'west',
    '49': 'west', '53': 'west', '56': 'west',
    # Texas - own category or South
    '48': 'south',
    # Other territories
    '72': 'territory', '78': 'territory',
}

# Approximate region centroids for fallback
REGION_CENTROIDS = {
    'northeast': (42.0, -74.0),
    'southeast': (33.0, -84.0),
    'midwest': (41.0, -93.0),
    'west': (38.0, -118.0),
    'south': (31.0, -97.0),  # Texas-centric
    'territory': (18.0, -66.0),  # PR-centric
}

# Feature dimensions
GEO_SPREAD_DIM = 10


def haversine_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """
    Calculate the great-circle distance between two points on Earth.

    Args:
        lat1, lon1: First point coordinates in degrees
        lat2, lon2: Second point coordinates in degrees

    Returns:
        Distance in kilometers
    """
    lat1_rad = math.radians(lat1)
    lat2_rad = math.radians(lat2)
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)

    a = math.sin(dlat / 2) ** 2 + math.cos(lat1_rad) * math.cos(lat2_rad) * math.sin(dlon / 2) ** 2
    c = 2 * math.asin(math.sqrt(a))

    return EARTH_RADIUS_KM * c


def normalize_lat(lat: float) -> float:
    """Normalize latitude to [-1, 1] range (US-centric: 25-50 degrees)."""
    # US latitude range roughly 25-50
    return (lat - 37.5) / 12.5  # Centers around 37.5, range [-1, 1]


def normalize_long(lon: float) -> float:
    """Normalize longitude to [-1, 1] range (US-centric: -125 to -65 degrees)."""
    # US longitude range roughly -125 to -65
    return (lon + 95.0) / 30.0  # Centers around -95, range [-1, 1]


def normalize_distance_km(dist_km: float, max_km: float = 5000.0) -> float:
    """
    Normalize distance using log scale.

    Uses log(dist + 1) to handle zero distances gracefully.
    Max ~5000km covers continental US diagonal.
    """
    if dist_km <= 0:
        return 0.0
    log_dist = math.log(dist_km + 1)
    log_max = math.log(max_km + 1)
    return min(log_dist / log_max, 1.0)


@dataclass
class GeoSpreadFeatures:
    """
    Geographic spread features for a set of weighted locations.

    These features capture "expansiveness" - how spread out geographic
    activity is. Designed to be comparable across phone/zip/fips/city sources.

    Attributes:
        centroid_lat: Weighted centroid latitude, normalized to [-1, 1]
        centroid_long: Weighted centroid longitude, normalized to [-1, 1]
        spread_km: Standard deviation of distances from centroid (km)
        spread_normalized: Log-normalized spread [0, 1]
        max_span_km: Maximum distance between any two points (km)
        max_span_normalized: Log-normalized max span [0, 1]
        num_locations: Number of distinct locations
        num_locations_normalized: Log-normalized location count [0, 1]
        concentration: Fraction of weight in top location (0-1)
        region_entropy: Entropy of regional distribution (0 = all one region)
    """
    centroid_lat: float = 0.0
    centroid_long: float = 0.0
    spread_km: float = 0.0
    spread_normalized: float = 0.0
    max_span_km: float = 0.0
    max_span_normalized: float = 0.0
    num_locations: int = 0
    num_locations_normalized: float = 0.0
    concentration: float = 1.0
    region_entropy: float = 0.0

    def to_tensor(self) -> torch.Tensor:
        """Convert to a 10-dimensional feature tensor."""
        return torch.tensor([
            self.centroid_lat,
            self.centroid_long,
            self.spread_normalized,
            self.max_span_normalized,
            self.num_locations_normalized,
            self.concentration,
            self.region_entropy,
            # Add some derived features for richer representation
            1.0 if self.spread_km > 500 else 0.0,   # "regional" flag
            1.0 if self.spread_km > 2000 else 0.0,  # "national" flag
            1.0 if self.num_locations == 1 else 0.0,  # "single location" flag
        ], dtype=torch.float32)

    def to_dict(self) -> Dict:
        """Convert to dictionary for debugging/logging."""
        return {
            'centroid_lat': self.centroid_lat,
            'centroid_long': self.centroid_long,
            'spread_km': self.spread_km,
            'spread_normalized': self.spread_normalized,
            'max_span_km': self.max_span_km,
            'max_span_normalized': self.max_span_normalized,
            'num_locations': self.num_locations,
            'num_locations_normalized': self.num_locations_normalized,
            'concentration': self.concentration,
            'region_entropy': self.region_entropy,
        }


def compute_geo_spread(
    points: List[Tuple[float, float, float]],
    state_fips_list: Optional[List[str]] = None,
) -> GeoSpreadFeatures:
    """
    Compute geographic spread features from a list of weighted points.

    Args:
        points: List of (latitude, longitude, weight) tuples.
                Weight can be count, frequency, or any positive number.
        state_fips_list: Optional list of 2-digit state FIPS codes for
                        regional entropy calculation. If not provided,
                        we estimate regions from coordinates.

    Returns:
        GeoSpreadFeatures with all computed metrics.

    Example:
        # Nashville (weight 50) + San Francisco (weight 10)
        points = [(36.16, -86.78, 50), (37.77, -122.42, 10)]
        features = compute_geo_spread(points)
        print(f"Spread: {features.spread_km:.0f} km")  # ~3000 km
    """
    if not points:
        return GeoSpreadFeatures()

    # Filter out invalid points
    valid_points = [
        (lat, lon, w) for lat, lon, w in points
        if lat is not None and lon is not None and w is not None and w > 0
    ]

    if not valid_points:
        return GeoSpreadFeatures()

    n = len(valid_points)
    total_weight = sum(w for _, _, w in valid_points)

    if total_weight <= 0:
        return GeoSpreadFeatures(num_locations=n)

    # 1. Compute weighted centroid
    centroid_lat = sum(lat * w for lat, _, w in valid_points) / total_weight
    centroid_long = sum(lon * w for _, lon, w in valid_points) / total_weight

    # 2. Compute spread (weighted std dev of distances from centroid)
    if n == 1:
        spread_km = 0.0
    else:
        weighted_sq_dist_sum = 0.0
        for lat, lon, w in valid_points:
            dist = haversine_distance(centroid_lat, centroid_long, lat, lon)
            weighted_sq_dist_sum += w * (dist ** 2)
        spread_km = math.sqrt(weighted_sq_dist_sum / total_weight)

    # 3. Compute max span (diameter)
    max_span_km = 0.0
    if n > 1:
        for i in range(n):
            for j in range(i + 1, n):
                lat1, lon1, _ = valid_points[i]
                lat2, lon2, _ = valid_points[j]
                dist = haversine_distance(lat1, lon1, lat2, lon2)
                max_span_km = max(max_span_km, dist)

    # 4. Compute concentration (fraction of weight in top location)
    max_weight = max(w for _, _, w in valid_points)
    concentration = max_weight / total_weight

    # 5. Compute regional entropy
    region_entropy = 0.0
    if state_fips_list and len(state_fips_list) > 0:
        # Use provided state FIPS codes
        region_weights: Dict[str, float] = {}
        for i, fips in enumerate(state_fips_list):
            if i < len(valid_points):
                _, _, w = valid_points[i]
                region = STATE_TO_REGION.get(fips[:2], 'unknown')
                region_weights[region] = region_weights.get(region, 0) + w

        # Compute entropy
        if region_weights:
            total = sum(region_weights.values())
            for w in region_weights.values():
                if w > 0 and total > 0:
                    p = w / total
                    region_entropy -= p * math.log(p + 1e-10)
            # Normalize by max entropy (log of number of regions)
            max_entropy = math.log(max(len(region_weights), 1) + 1e-10)
            if max_entropy > 0:
                region_entropy /= max_entropy
    else:
        # Estimate region from coordinates (rough approximation)
        # This is less accurate but works when we don't have FIPS
        region_weights: Dict[str, float] = {}
        for lat, lon, w in valid_points:
            # Very rough region estimation based on longitude
            if lon > -85:
                region = 'northeast' if lat > 38 else 'southeast'
            elif lon > -100:
                region = 'midwest' if lat > 35 else 'south'
            else:
                region = 'west'
            region_weights[region] = region_weights.get(region, 0) + w

        if region_weights:
            total = sum(region_weights.values())
            for w in region_weights.values():
                if w > 0 and total > 0:
                    p = w / total
                    region_entropy -= p * math.log(p + 1e-10)
            max_entropy = math.log(max(len(region_weights), 1) + 1e-10)
            if max_entropy > 0:
                region_entropy /= max_entropy

    # 6. Normalize values
    return GeoSpreadFeatures(
        centroid_lat=normalize_lat(centroid_lat),
        centroid_long=normalize_long(centroid_long),
        spread_km=spread_km,
        spread_normalized=normalize_distance_km(spread_km),
        max_span_km=max_span_km,
        max_span_normalized=normalize_distance_km(max_span_km),
        num_locations=n,
        num_locations_normalized=min(math.log(n + 1) / math.log(100), 1.0),  # Normalize to ~100 locations
        concentration=concentration,
        region_entropy=region_entropy,
    )


def compute_geo_spread_from_codes(
    code_weights: Dict[str, float],
    code_to_latlong: Dict[str, Tuple[float, float]],
    code_to_state_fips: Optional[Dict[str, str]] = None,
) -> GeoSpreadFeatures:
    """
    Convenience function to compute geo spread from a dict of code -> weight.

    Args:
        code_weights: Dictionary mapping codes (zip, fips, area code) to weights
        code_to_latlong: Dictionary mapping codes to (lat, long) coordinates
        code_to_state_fips: Optional dict mapping codes to 2-digit state FIPS

    Returns:
        GeoSpreadFeatures

    Example:
        from featrix.neural.fips_codec import COUNTY_FIPS_COORDS

        code_weights = {'47037': 50, '06075': 10}
        code_to_latlong = {k: (v[0], v[1]) for k, v in COUNTY_FIPS_COORDS.items()}
        features = compute_geo_spread_from_codes(code_weights, code_to_latlong)
    """
    points = []
    state_fips_list = []

    for code, weight in code_weights.items():
        if code in code_to_latlong:
            lat, lon = code_to_latlong[code]
            points.append((lat, lon, weight))
            if code_to_state_fips and code in code_to_state_fips:
                state_fips_list.append(code_to_state_fips[code])
            elif len(code) >= 2:
                # Try to extract state FIPS from code (works for 5-digit FIPS)
                state_fips_list.append(code[:2])

    return compute_geo_spread(
        points,
        state_fips_list if state_fips_list else None
    )


# Convenience function to create empty/unknown features
def empty_geo_spread_features() -> GeoSpreadFeatures:
    """Return empty geo spread features for missing/invalid data."""
    return GeoSpreadFeatures()


def empty_geo_spread_tensor() -> torch.Tensor:
    """Return zero tensor for missing/invalid geo spread data."""
    return torch.zeros(GEO_SPREAD_DIM, dtype=torch.float32)


if __name__ == "__main__":
    # Test the geo spread computation
    print(f"GEO_SPREAD_ENABLED: {GEO_SPREAD_ENABLED}")
    print()

    # Test 1: Single location (Nashville)
    single = compute_geo_spread([(36.16, -86.78, 100)])
    print("Single location (Nashville):")
    print(f"  Spread: {single.spread_km:.0f} km")
    print(f"  Concentration: {single.concentration:.2f}")
    print(f"  Tensor: {single.to_tensor()}")
    print()

    # Test 2: Two locations close together (Nashville area)
    close = compute_geo_spread([
        (36.16, -86.78, 50),   # Nashville
        (36.30, -86.60, 50),   # Nearby
    ])
    print("Two close locations (Nashville area):")
    print(f"  Spread: {close.spread_km:.0f} km")
    print(f"  Max span: {close.max_span_km:.0f} km")
    print()

    # Test 3: Bi-coastal (Nashville + San Francisco)
    bicoastal = compute_geo_spread([
        (36.16, -86.78, 50),    # Nashville
        (37.77, -122.42, 10),   # San Francisco
    ])
    print("Bi-coastal (Nashville + SF):")
    print(f"  Spread: {bicoastal.spread_km:.0f} km")
    print(f"  Max span: {bicoastal.max_span_km:.0f} km")
    print(f"  Concentration: {bicoastal.concentration:.2f}")
    print(f"  Regional entropy: {bicoastal.region_entropy:.2f}")
    print()

    # Test 4: National spread (4 corners)
    national = compute_geo_spread([
        (47.6, -122.3, 25),   # Seattle
        (25.8, -80.2, 25),    # Miami
        (42.4, -71.1, 25),    # Boston
        (34.0, -118.2, 25),   # LA
    ])
    print("National spread (4 corners):")
    print(f"  Spread: {national.spread_km:.0f} km")
    print(f"  Max span: {national.max_span_km:.0f} km")
    print(f"  Concentration: {national.concentration:.2f}")
    print(f"  Regional entropy: {national.region_entropy:.2f}")
    print(f"  Tensor: {national.to_tensor()}")
