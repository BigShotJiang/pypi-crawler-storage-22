#  -*- coding: utf-8 -*-
#
#  Copyright Featrix, Inc 2023-2026
#
#  Proprietary and Confidential.  Unauthorized use, copying or dissemination
#  of these materials is strictly prohibited.
"""
Geocoding utilities for address-to-coordinates conversion.

Uses the Featrix geocoding API which wraps Google Maps with MongoDB caching.
Additionally caches results locally in SQLite for cross-training reuse.

See docs/GEOCODING_API.md for full API documentation.
"""

import hashlib
import json
import math
import logging
import os
import sqlite3
import time
from functools import lru_cache
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import requests

from featrix.neural.platform_utils import featrix_get_root

logger = logging.getLogger(__name__)

# Featrix geocoding API endpoints
GEOCODE_API_BASE = "https://cache.featrix.com/geoaddr"
GEOCODE_ENDPOINT = f"{GEOCODE_API_BASE}/geocode"
REVERSE_ENDPOINT = f"{GEOCODE_API_BASE}/reverse"
BATCH_ENDPOINT = f"{GEOCODE_API_BASE}/batch"

# Local SQLite cache for cross-training reuse
FEATRIX_ROOT = featrix_get_root()
GEOCODE_CACHE_DIR = Path(FEATRIX_ROOT) / "app" / "featrix_output"
GEOCODE_CACHE_FILE = GEOCODE_CACHE_DIR / ".geocode_cache.db"


class GeocodeCache:
    """
    Local SQLite cache for geocoding results.

    Persists across trainings to avoid repeated API calls.
    The remote API also caches, but this avoids network round-trips.
    """

    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if getattr(self, '_initialized', False):
            return

        self._initialized = True
        self.enabled = True
        self.conn = None

        try:
            self._init_db()
        except Exception as e:
            logger.warning(f"⚠️  Failed to initialize geocode cache: {e}")
            self.enabled = False

    def _init_db(self):
        """Initialize the SQLite database."""
        GEOCODE_CACHE_DIR.mkdir(parents=True, exist_ok=True)

        self.conn = sqlite3.connect(
            str(GEOCODE_CACHE_FILE),
            timeout=10.0,
            check_same_thread=False
        )
        self.conn.execute("PRAGMA journal_mode=WAL")

        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS geocode_cache (
                cache_key TEXT PRIMARY KEY,
                address TEXT NOT NULL,
                result_json TEXT NOT NULL,
                latitude REAL,
                longitude REAL,
                created_at REAL NOT NULL
            )
        """)

        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS reverse_cache (
                cache_key TEXT PRIMARY KEY,
                latitude REAL NOT NULL,
                longitude REAL NOT NULL,
                result_json TEXT NOT NULL,
                created_at REAL NOT NULL
            )
        """)

        self.conn.commit()
        logger.debug(f"Geocode cache initialized at {GEOCODE_CACHE_FILE}")

    @staticmethod
    def _make_address_key(address: str) -> str:
        """Generate cache key for an address."""
        normalized = address.lower().strip()
        return hashlib.md5(normalized.encode()).hexdigest()

    @staticmethod
    def _make_coords_key(lat: float, lon: float) -> str:
        """Generate cache key for coordinates (6 decimal places)."""
        return hashlib.md5(f"reverse_{lat:.6f},{lon:.6f}".encode()).hexdigest()

    def get_geocode(self, address: str) -> Optional[Dict]:
        """Get cached geocode result."""
        if not self.enabled:
            return None

        try:
            cache_key = self._make_address_key(address)
            cursor = self.conn.execute(
                "SELECT result_json FROM geocode_cache WHERE cache_key = ?",
                (cache_key,)
            )
            row = cursor.fetchone()
            if row:
                result = json.loads(row[0])
                result['cached'] = True
                result['cache_source'] = 'local'
                return result
        except Exception as e:
            logger.debug(f"Cache lookup failed: {e}")

        return None

    def set_geocode(self, address: str, result: Dict):
        """Store geocode result in cache."""
        if not self.enabled:
            return

        try:
            cache_key = self._make_address_key(address)
            self.conn.execute(
                """INSERT OR REPLACE INTO geocode_cache
                   (cache_key, address, result_json, latitude, longitude, created_at)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (cache_key, address, json.dumps(result),
                 result.get('latitude'), result.get('longitude'), time.time())
            )
            self.conn.commit()
        except Exception as e:
            logger.debug(f"Cache write failed: {e}")

    def get_reverse(self, lat: float, lon: float) -> Optional[Dict]:
        """Get cached reverse geocode result."""
        if not self.enabled:
            return None

        try:
            cache_key = self._make_coords_key(lat, lon)
            cursor = self.conn.execute(
                "SELECT result_json FROM reverse_cache WHERE cache_key = ?",
                (cache_key,)
            )
            row = cursor.fetchone()
            if row:
                result = json.loads(row[0])
                result['cached'] = True
                result['cache_source'] = 'local'
                return result
        except Exception as e:
            logger.debug(f"Cache lookup failed: {e}")

        return None

    def set_reverse(self, lat: float, lon: float, result: Dict):
        """Store reverse geocode result in cache."""
        if not self.enabled:
            return

        try:
            cache_key = self._make_coords_key(lat, lon)
            self.conn.execute(
                """INSERT OR REPLACE INTO reverse_cache
                   (cache_key, latitude, longitude, result_json, created_at)
                   VALUES (?, ?, ?, ?, ?)""",
                (cache_key, lat, lon, json.dumps(result), time.time())
            )
            self.conn.commit()
        except Exception as e:
            logger.debug(f"Cache write failed: {e}")

    def get_stats(self) -> Dict:
        """Get cache statistics."""
        if not self.enabled:
            return {"enabled": False}

        try:
            cursor = self.conn.execute("SELECT COUNT(*) FROM geocode_cache")
            geocode_count = cursor.fetchone()[0]

            cursor = self.conn.execute("SELECT COUNT(*) FROM reverse_cache")
            reverse_count = cursor.fetchone()[0]

            return {
                "enabled": True,
                "geocode_entries": geocode_count,
                "reverse_entries": reverse_count,
                "cache_file": str(GEOCODE_CACHE_FILE),
            }
        except Exception as e:
            return {"enabled": True, "error": str(e)}


# Global cache instance
_cache = GeocodeCache()

# In-memory LRU cache on top of SQLite (per-process)
_lru_geocode_cache: Dict[str, Dict] = {}
_lru_reverse_cache: Dict[str, Dict] = {}
LRU_CACHE_SIZE = 2000


def _lru_get_geocode(address: str) -> Optional[Dict]:
    """Check in-memory LRU cache for geocode result."""
    key = address.lower().strip()
    return _lru_geocode_cache.get(key)


def _lru_set_geocode(address: str, result: Dict):
    """Store in in-memory LRU cache (simple FIFO eviction)."""
    key = address.lower().strip()
    if len(_lru_geocode_cache) >= LRU_CACHE_SIZE:
        # Remove oldest entry (first key)
        oldest = next(iter(_lru_geocode_cache))
        del _lru_geocode_cache[oldest]
    _lru_geocode_cache[key] = result


def _lru_get_reverse(lat: float, lon: float) -> Optional[Dict]:
    """Check in-memory LRU cache for reverse geocode result."""
    key = f"{lat:.6f},{lon:.6f}"
    return _lru_reverse_cache.get(key)


def _lru_set_reverse(lat: float, lon: float, result: Dict):
    """Store in in-memory LRU cache."""
    key = f"{lat:.6f},{lon:.6f}"
    if len(_lru_reverse_cache) >= LRU_CACHE_SIZE:
        oldest = next(iter(_lru_reverse_cache))
        del _lru_reverse_cache[oldest]
    _lru_reverse_cache[key] = result


def geocode(address: str, timeout: float = 10.0, use_local_cache: bool = True) -> Optional[Dict]:
    """
    Convert an address to latitude/longitude coordinates.

    Uses a two-tier caching strategy:
    1. Local SQLite cache (fast, persists across trainings)
    2. Remote API with MongoDB cache (authoritative, shared across all clients)

    Args:
        address: Full address string (e.g., "123 Main St, San Francisco, CA 94105")
        timeout: Request timeout in seconds
        use_local_cache: Whether to use local SQLite cache (default True)

    Returns:
        Dictionary with 'latitude', 'longitude', 'formatted_address', 'components', etc.
        Returns None if geocoding fails.

    Example:
        >>> result = geocode("100 Market St, San Francisco, CA")
        >>> print(f"Lat: {result['latitude']}, Lon: {result['longitude']}")
        Lat: 37.7937..., Lon: -122.3950...
    """
    # Check in-memory LRU cache first (fastest)
    if use_local_cache:
        cached = _lru_get_geocode(address)
        if cached:
            cached['cache_source'] = 'memory'
            return cached

        # Check SQLite cache second
        cached = _cache.get_geocode(address)
        if cached:
            # Promote to LRU cache
            _lru_set_geocode(address, cached)
            return cached

    # Call remote API
    try:
        response = requests.post(
            GEOCODE_ENDPOINT,
            json={"address": address},
            timeout=timeout
        )
        response.raise_for_status()
        result = response.json()

        if result.get('status') == 'success':
            # Store in local caches for future use
            if use_local_cache:
                _cache.set_geocode(address, result)
                _lru_set_geocode(address, result)
            return result
        else:
            logger.warning(f"Geocoding failed for '{address}': {result.get('error', 'Unknown error')}")
            return None

    except requests.exceptions.RequestException as e:
        logger.error(f"Geocoding request failed for '{address}': {e}")
        return None


def reverse_geocode(latitude: float, longitude: float, timeout: float = 10.0,
                    use_local_cache: bool = True) -> Optional[Dict]:
    """
    Convert latitude/longitude coordinates to an address.

    Uses a two-tier caching strategy:
    1. Local SQLite cache (fast, persists across trainings)
    2. Remote API with MongoDB cache (authoritative, shared across all clients)

    Args:
        latitude: Latitude (-90 to 90)
        longitude: Longitude (-180 to 180)
        timeout: Request timeout in seconds
        use_local_cache: Whether to use local SQLite cache (default True)

    Returns:
        Dictionary with 'address', 'components', etc.
        Returns None if reverse geocoding fails.

    Example:
        >>> result = reverse_geocode(37.7937, -122.3950)
        >>> print(result['address'])
        100 Market St, San Francisco, CA 94105, USA
    """
    if not (-90 <= latitude <= 90):
        raise ValueError(f"Latitude must be between -90 and 90, got {latitude}")
    if not (-180 <= longitude <= 180):
        raise ValueError(f"Longitude must be between -180 and 180, got {longitude}")

    # Check in-memory LRU cache first (fastest)
    if use_local_cache:
        cached = _lru_get_reverse(latitude, longitude)
        if cached:
            cached['cache_source'] = 'memory'
            return cached

        # Check SQLite cache second
        cached = _cache.get_reverse(latitude, longitude)
        if cached:
            _lru_set_reverse(latitude, longitude, cached)
            return cached

    try:
        response = requests.post(
            REVERSE_ENDPOINT,
            json={"latitude": latitude, "longitude": longitude},
            timeout=timeout
        )
        response.raise_for_status()
        result = response.json()

        if result.get('status') == 'success':
            # Store in both caches for future use
            if use_local_cache:
                _cache.set_reverse(latitude, longitude, result)
                _lru_set_reverse(latitude, longitude, result)
            return result
        else:
            logger.warning(f"Reverse geocoding failed for ({latitude}, {longitude}): {result.get('error', 'Unknown error')}")
            return None

    except requests.exceptions.RequestException as e:
        logger.error(f"Reverse geocoding request failed for ({latitude}, {longitude}): {e}")
        return None


def batch_geocode(addresses: List[str], timeout: float = 30.0) -> Dict:
    """
    Batch geocode multiple addresses in a single request.

    Args:
        addresses: List of address strings
        timeout: Request timeout in seconds

    Returns:
        Dictionary with 'results' list and 'summary' statistics.

    Example:
        >>> results = batch_geocode(["123 Main St, NYC", "456 Oak Ave, LA"])
        >>> for r in results['results']:
        ...     print(f"{r['address']}: ({r['latitude']}, {r['longitude']})")
    """
    if len(addresses) > 100:
        raise ValueError(f"Maximum 100 addresses per batch, got {len(addresses)}")

    requests_list = [{"type": "geocode", "address": addr} for addr in addresses]

    try:
        response = requests.post(
            BATCH_ENDPOINT,
            json={"requests": requests_list},
            timeout=timeout
        )
        response.raise_for_status()
        return response.json()

    except requests.exceptions.RequestException as e:
        logger.error(f"Batch geocoding request failed: {e}")
        return {"results": [], "summary": {"error": str(e)}}


def haversine_distance_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """
    Calculate the great-circle distance between two points on Earth.

    Uses the Haversine formula for accurate distance calculation.

    Args:
        lat1, lon1: First point coordinates (degrees)
        lat2, lon2: Second point coordinates (degrees)

    Returns:
        Distance in kilometers.

    Example:
        >>> # SF to LA
        >>> haversine_distance_km(37.7749, -122.4194, 34.0522, -118.2437)
        559.12...
    """
    R = 6371  # Earth's radius in km

    lat1_rad = math.radians(lat1)
    lat2_rad = math.radians(lat2)
    delta_lat = math.radians(lat2 - lat1)
    delta_lon = math.radians(lon2 - lon1)

    a = math.sin(delta_lat / 2) ** 2 + \
        math.cos(lat1_rad) * math.cos(lat2_rad) * math.sin(delta_lon / 2) ** 2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

    return R * c


def haversine_distance_miles(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """
    Calculate the great-circle distance between two points on Earth in miles.

    Args:
        lat1, lon1: First point coordinates (degrees)
        lat2, lon2: Second point coordinates (degrees)

    Returns:
        Distance in miles.
    """
    return haversine_distance_km(lat1, lon1, lat2, lon2) * 0.621371


def get_coordinates(address: str) -> Optional[Tuple[float, float]]:
    """
    Simple helper to get just lat/lon from an address.

    Args:
        address: Full address string

    Returns:
        Tuple of (latitude, longitude) or None if geocoding fails.

    Example:
        >>> lat, lon = get_coordinates("Empire State Building, NYC")
        >>> print(f"{lat:.4f}, {lon:.4f}")
        40.7484, -73.9857
    """
    result = geocode(address)
    if result:
        return (result['latitude'], result['longitude'])
    return None


def distance_between_addresses(address1: str, address2: str) -> Optional[float]:
    """
    Calculate the distance between two addresses in kilometers.

    Args:
        address1: First address
        address2: Second address

    Returns:
        Distance in kilometers, or None if either address fails to geocode.

    Example:
        >>> distance_between_addresses("San Francisco, CA", "Los Angeles, CA")
        559.12...
    """
    coords1 = get_coordinates(address1)
    coords2 = get_coordinates(address2)

    if coords1 is None or coords2 is None:
        return None

    return haversine_distance_km(coords1[0], coords1[1], coords2[0], coords2[1])


def get_cache_stats() -> Dict:
    """
    Get statistics about all geocoding caches.

    Returns:
        Dictionary with cache file location and entry counts for both
        in-memory LRU and SQLite caches.
    """
    stats = _cache.get_stats()
    stats['memory_geocode_entries'] = len(_lru_geocode_cache)
    stats['memory_reverse_entries'] = len(_lru_reverse_cache)
    stats['memory_cache_max_size'] = LRU_CACHE_SIZE
    return stats


# LRU cache for frequently accessed coordinates (in-memory, per-process)
@lru_cache(maxsize=10000)
def get_coordinates_cached(address: str) -> Optional[Tuple[float, float]]:
    """
    Get coordinates with in-memory LRU caching.

    For high-frequency lookups within a single training run.
    """
    return get_coordinates(address)


# Quick test
if __name__ == '__main__':
    print("Testing geocoding API with local caching...")

    # Show cache stats
    stats = get_cache_stats()
    print(f"\n📊 Cache stats: {stats}")

    # Test forward geocoding
    result = geocode("100 Market St, San Francisco, CA 94105")
    if result:
        print(f"\n✅ Forward geocoding:")
        print(f"   Address: {result.get('formatted_address')}")
        print(f"   Lat: {result['latitude']:.6f}")
        print(f"   Lon: {result['longitude']:.6f}")
        print(f"   Cached: {result.get('cached', False)}")
        print(f"   Cache source: {result.get('cache_source', 'remote')}")
    else:
        print("❌ Forward geocoding failed")

    # Test again to verify caching
    result = geocode("100 Market St, San Francisco, CA 94105")
    if result:
        print(f"\n✅ Second lookup (should be cached):")
        print(f"   Cached: {result.get('cached', False)}")
        print(f"   Cache source: {result.get('cache_source', 'remote')}")

    # Test reverse geocoding
    result = reverse_geocode(37.7749, -122.4194)
    if result:
        print(f"\n✅ Reverse geocoding:")
        print(f"   Address: {result.get('address')}")
    else:
        print("❌ Reverse geocoding failed")

    # Test distance calculation
    print(f"\n📍 Distance calculations:")
    print(f"   SF to LA: {haversine_distance_km(37.7749, -122.4194, 34.0522, -118.2437):.0f} km")
    print(f"   SF to NYC: {haversine_distance_km(37.7749, -122.4194, 40.7128, -74.0060):.0f} km")

    # Test address distance
    dist = distance_between_addresses("San Francisco, CA", "Seattle, WA")
    if dist:
        print(f"   SF to Seattle: {dist:.0f} km")

    # Show final cache stats
    stats = get_cache_stats()
    print(f"\n📊 Final cache stats: {stats}")
