#  -*- coding: utf-8 -*-
#
#  Copyright Featrix, Inc 2023-2025
#
#  Proprietary and Confidential.  Unauthorized use, copying or dissemination
#  of these materials is strictly prohibited.
#
"""
Hybrid Column Encoders

Encoders that combine multiple related columns into a single embedding.
Used with MERGE strategy from hybrid_column_detector.

Following the pattern of URLEncoder and DomainEncoder.
"""
import logging
import math
from typing import List, Dict, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

from featrix.neural.gpu_utils import get_device
from featrix.neural.featrix_token import Token, TokenStatus, TokenBatch
from featrix.neural.model_config import SimpleMLPConfig
from featrix.neural.simple_mlp import SimpleMLP
from featrix.neural.simple_string_cache import SimpleStringCache as StringCache
from featrix.neural.sphere_config import get_config

logger = logging.getLogger(__name__)

# Lazy import geocode to avoid circular imports
_geocode_module = None


def _get_geocode():
    """Lazy import of geocode module."""
    global _geocode_module
    if _geocode_module is None:
        try:
            from featrix.neural import geocode as geo_module
            _geocode_module = geo_module
        except ImportError:
            logger.warning("geocode module not available - address geocoding disabled")
            _geocode_module = False
    return _geocode_module if _geocode_module else None


class AddressHybridEncoder(nn.Module):
    """
    Encodes address components into a single embedding.

    Combines two encoding strategies:
    1. String embeddings: Semantic similarity of address text (city names, street names)
    2. Geocoding features: Actual lat/long coordinates for geographic distance

    The geocoding features provide strong geographic signal (-0.9 correlation with distance),
    while string embeddings capture semantic relationships (same-state, same-region).

    Typical columns:
    - addr1, addr2: street address lines (string embeddings)
    - city: city name (string embedding)
    - state: state/province (could be string or categorical)
    - zip/postal_code: postal code (string embedding)
    - country: country (optional, string embedding)
    """

    # Geocoding feature dimension: lat, lon, lat_norm, lon_norm, lat_sin, lat_cos, lon_sin, lon_cos
    GEO_FEATURE_DIM = 8

    def __init__(self, config: SimpleMLPConfig, string_cache: StringCache,
                 column_names: List[str], column_name: Optional[str] = None):
        super().__init__()
        self.config = config
        self.string_cache = string_cache
        self.column_names = column_names
        self.column_name = column_name or f"hybrid_address_{'_'.join(column_names)}"
        self.d_model = config.d_out

        # Check if geocoding is enabled via config
        sphere_config = get_config()
        self.use_geocoding = sphere_config.get("address_geocoding_enabled", True)

        # String embeddings come from string_cache (384 dim)
        string_embed_dim = string_cache.embedding_dim if string_cache else 384

        # Project each address component
        # Street address gets more capacity (addr1 + addr2)
        self.addr1_proj = nn.Linear(string_embed_dim, 128, bias=False)
        self.addr2_proj = nn.Linear(string_embed_dim, 64, bias=False)
        self.city_proj = nn.Linear(string_embed_dim, 96, bias=False)
        self.state_proj = nn.Linear(string_embed_dim, 32, bias=False)
        self.zip_proj = nn.Linear(string_embed_dim, 32, bias=False)
        self.country_proj = nn.Linear(string_embed_dim, 32, bias=False)

        # Initialize projections
        nn.init.xavier_uniform_(self.addr1_proj.weight, gain=1.0)
        nn.init.xavier_uniform_(self.addr2_proj.weight, gain=0.5)
        nn.init.xavier_uniform_(self.city_proj.weight, gain=0.8)
        nn.init.xavier_uniform_(self.state_proj.weight, gain=0.5)
        nn.init.xavier_uniform_(self.zip_proj.weight, gain=0.5)
        nn.init.xavier_uniform_(self.country_proj.weight, gain=0.5)

        # Geocoding feature projection (lat/long + derived features)
        self.geo_proj = nn.Linear(self.GEO_FEATURE_DIM, 64, bias=False)
        nn.init.xavier_uniform_(self.geo_proj.weight, gain=1.5)  # Higher gain for important geo features

        # Total input dimension: 128 + 64 + 96 + 32 + 32 + 32 + 64 (geo) = 448
        total_dim = 128 + 64 + 96 + 32 + 32 + 32 + 64

        # MLP to combine all components
        mlp_config = SimpleMLPConfig(
            d_in=total_dim,
            d_out=config.d_out,
            d_hidden=config.d_hidden if hasattr(config, 'd_hidden') else 256,
            n_hidden_layers=config.n_hidden_layers if hasattr(config, 'n_hidden_layers') else 2,
            dropout=config.dropout if hasattr(config, 'dropout') else 0.3,
            normalize=config.normalize if hasattr(config, 'normalize') else True,
            residual=config.residual if hasattr(config, 'residual') else True,
            use_batch_norm=config.use_batch_norm if hasattr(config, 'use_batch_norm') else True,
        )
        self.combiner_mlp = SimpleMLP(mlp_config)

        # Replacement embedding for missing/invalid addresses
        self._replacement_embedding = nn.Parameter(torch.randn(config.d_out))
        nn.init.normal_(self._replacement_embedding, mean=0.0, std=0.01)

        # Cache for geocoding results (address_str -> (lat, lon))
        self._geo_cache: Dict[str, Optional[Tuple[float, float]]] = {}

        logger.info(f"🏠 AddressHybridEncoder initialized: columns={column_names}, d_model={config.d_out}, geocoding={self.use_geocoding}")
    
    def _get_string_embedding(self, text: str) -> torch.Tensor:
        """Get string embedding from cache, or zeros if not available."""
        if not text or not self.string_cache:
            # Keep on CPU for DataLoader workers
            return torch.zeros(self.string_cache.embedding_dim if self.string_cache else 384)

        try:
            emb = self.string_cache.get_embedding(str(text))
            if emb is not None:
                # Keep on CPU for DataLoader workers
                return torch.tensor(emb, dtype=torch.float32) if not isinstance(emb, torch.Tensor) else emb
        except Exception as e:
            logger.debug(f"Failed to get string embedding for '{text}': {e}")

        # Keep on CPU for DataLoader workers
        return torch.zeros(self.string_cache.embedding_dim if self.string_cache else 384)

    def _geocode_address(self, full_address: str) -> Optional[Tuple[float, float]]:
        """
        Geocode an address to lat/long coordinates.

        Uses the Featrix geocoding API with local caching.
        Returns (lat, lon) tuple or None if geocoding fails.
        """
        if not self.use_geocoding:
            return None

        # Check local cache first
        if full_address in self._geo_cache:
            return self._geo_cache[full_address]

        # Try geocoding
        geo_module = _get_geocode()
        if geo_module is None:
            self._geo_cache[full_address] = None
            return None

        try:
            result = geo_module.geocode(full_address)
            if result and result.get('status') == 'success':
                lat, lon = result['latitude'], result['longitude']
                self._geo_cache[full_address] = (lat, lon)
                return (lat, lon)
        except Exception as e:
            logger.debug(f"Geocoding failed for '{full_address}': {e}")

        self._geo_cache[full_address] = None
        return None

    def _encode_geo_features(self, lat: Optional[float], lon: Optional[float]) -> torch.Tensor:
        """
        Encode lat/long into a feature vector with geographic relationships.

        Returns tensor of shape [GEO_FEATURE_DIM]:
        - lat, lon: raw coordinates (normalized to [-1, 1])
        - lat_norm, lon_norm: normalized coordinates
        - lat_sin, lat_cos: sinusoidal encoding for latitude (captures periodicity)
        - lon_sin, lon_cos: sinusoidal encoding for longitude
        """
        if lat is None or lon is None:
            return torch.zeros(self.GEO_FEATURE_DIM, dtype=torch.float32)

        # Normalize coordinates
        lat_norm = lat / 90.0  # [-1, 1]
        lon_norm = lon / 180.0  # [-1, 1]

        # Sinusoidal encoding (captures geographic periodicity and enables distance computation)
        # Using radians for sin/cos
        lat_rad = math.radians(lat)
        lon_rad = math.radians(lon)

        return torch.tensor([
            lat_norm,           # Normalized latitude
            lon_norm,           # Normalized longitude
            lat / 90.0,         # Scaled latitude (redundant but helps gradient flow)
            lon / 180.0,        # Scaled longitude
            math.sin(lat_rad),  # Latitude sine
            math.cos(lat_rad),  # Latitude cosine
            math.sin(lon_rad),  # Longitude sine
            math.cos(lon_rad),  # Longitude cosine
        ], dtype=torch.float32)

    def _build_full_address(self, addr1: str, addr2: str, city: str, state: str,
                            zip_code: str, country: str) -> str:
        """Build a full address string for geocoding."""
        parts = []
        if addr1:
            parts.append(addr1)
        if addr2:
            parts.append(addr2)
        if city:
            parts.append(city)
        if state:
            if zip_code:
                parts.append(f"{state} {zip_code}")
            else:
                parts.append(state)
        elif zip_code:
            parts.append(zip_code)
        if country:
            parts.append(country)
        return ", ".join(parts)
    
    def _extract_component(self, batch_data: Dict[str, TokenBatch], component_name: str, 
                          row_idx: int) -> str:
        """Extract a component value from batch_data for a specific row."""
        # Try exact match first
        if component_name in batch_data:
            token_batch = batch_data[component_name]
            if "values" in token_batch:
                val = token_batch["values"][row_idx]
                # Handle tensor values - only call .item() on scalar tensors
                if hasattr(val, 'item') and val.dim() == 0:
                    return str(val.item())
                elif isinstance(val, torch.Tensor):
                    return ""  # Skip vector embeddings (not a raw string value)
                return str(val) if val is not None else ""

        # Try fuzzy match (find column ending with component_name)
        component_lower = component_name.lower()
        for col_name in batch_data.keys():
            if col_name.lower().endswith(component_lower):
                token_batch = batch_data[col_name]
                if "values" in token_batch:
                    val = token_batch["values"][row_idx]
                    # Handle tensor values - only call .item() on scalar tensors
                    if hasattr(val, 'item') and val.dim() == 0:
                        return str(val.item())
                    elif isinstance(val, torch.Tensor):
                        return ""  # Skip vector embeddings (not a raw string value)
                    return str(val) if val is not None else ""

        return ""
    
    def forward(self, batch_data: Dict[str, TokenBatch]) -> tuple:
        """
        Encode address components from batch_data.

        Combines:
        1. String embeddings for each address component (semantic similarity)
        2. Geocoding features (actual lat/long for geographic distance)

        Args:
            batch_data: Dictionary of column_name -> TokenBatch
                       Contains all columns, we extract our address components

        Returns:
            (short_encoding, full_encoding) tuple
        """
        # Determine batch size from first column
        first_col = next(iter(batch_data.values()))
        batch_size = len(first_col["values"]) if "values" in first_col else 1

        # Get device from model parameters
        device = next(self.addr1_proj.parameters()).device
        replacement_emb = self._replacement_embedding.to(device)

        # Collect combined features and track which samples need replacement
        combined_features = []
        valid_indices = []
        replacement_indices = []

        for i in range(batch_size):
            # Extract address components
            addr1 = self._extract_component(batch_data, "addr1", i) or \
                   self._extract_component(batch_data, "address", i) or \
                   self._extract_component(batch_data, "street", i)
            addr2 = self._extract_component(batch_data, "addr2", i)
            city = self._extract_component(batch_data, "city", i)
            state = self._extract_component(batch_data, "state", i)
            zip_code = self._extract_component(batch_data, "zip", i) or \
                      self._extract_component(batch_data, "postal_code", i)
            country = self._extract_component(batch_data, "country", i)

            # Check if address is mostly empty
            if not any([addr1, city, state, zip_code]):
                replacement_indices.append(i)
                continue

            # Get string embeddings for each component (move to device)
            addr1_emb = self.addr1_proj(self._get_string_embedding(addr1).to(device))
            addr2_emb = self.addr2_proj(self._get_string_embedding(addr2).to(device))
            city_emb = self.city_proj(self._get_string_embedding(city).to(device))
            state_emb = self.state_proj(self._get_string_embedding(state).to(device))
            zip_emb = self.zip_proj(self._get_string_embedding(zip_code).to(device))
            country_emb = self.country_proj(self._get_string_embedding(country).to(device))

            # Geocode the address and get geographic features
            full_address = self._build_full_address(addr1, addr2, city, state, zip_code, country)
            coords = self._geocode_address(full_address)
            lat, lon = coords if coords else (None, None)
            geo_features = self._encode_geo_features(lat, lon).to(device)
            geo_emb = self.geo_proj(geo_features)

            # Concatenate all components (string + geo)
            combined = torch.cat([
                addr1_emb,
                addr2_emb,
                city_emb,
                state_emb,
                zip_emb,
                country_emb,
                geo_emb,  # Geographic features
            ], dim=-1)
            combined_features.append(combined)
            valid_indices.append(i)

        # Initialize result with replacement embeddings
        result = replacement_emb.unsqueeze(0).expand(batch_size, -1).clone()

        # Process valid samples through MLP (batch to avoid BatchNorm single-sample issue)
        if combined_features:
            combined_batch = torch.stack(combined_features, dim=0)  # (n_valid, combined_dim)
            # Use eval mode for MLP if only 1 valid sample to avoid BatchNorm issue
            if combined_batch.shape[0] == 1 and self.training:
                self.combiner_mlp.eval()
                with torch.no_grad():
                    mlp_output = self.combiner_mlp(combined_batch)
                self.combiner_mlp.train()
            else:
                mlp_output = self.combiner_mlp(combined_batch)
            # Place MLP outputs into result at valid indices
            for idx, out_idx in enumerate(valid_indices):
                result[out_idx] = mlp_output[idx]

        # Check for NaN
        if torch.isnan(result).any():
            logger.error(f"💥 AddressHybridEncoder output contains NaN!")
            result = replacement_emb.to(result.dtype).unsqueeze(0).expand(batch_size, -1)

        # Return short and full encodings
        if self.config.normalize:
            short_vec = F.normalize(result[:, 0:3], dim=1, eps=1e-8)
            full_vec = F.normalize(result, dim=1, eps=1e-8)
        else:
            short_vec = result[:, 0:3]
            full_vec = result

        return short_vec, full_vec


class CoordinateHybridEncoder(nn.Module):
    """
    Encodes lat/long coordinate pairs into a single embedding.
    
    Simpler than AddressEncoder - just combines two scalars with optional geo-encoding.
    """
    
    def __init__(self, config: SimpleMLPConfig, lat_col: str, long_col: str, 
                 column_name: Optional[str] = None):
        super().__init__()
        self.config = config
        self.lat_col = lat_col
        self.long_col = long_col
        self.column_name = column_name or f"hybrid_coords_{lat_col}_{long_col}"
        self.d_model = config.d_out
        
        # Simple approach: 2D input (lat, long) → MLP → d_model
        # Can add geo-encoding features:
        # - Distance from equator
        # - Distance from prime meridian
        # - Hemisphere indicators
        # - Normalized coordinates
        
        # Input: lat, long, lat_norm, long_norm, dist_equator, dist_meridian = 6 features
        input_dim = 6
        
        mlp_config = SimpleMLPConfig(
            d_in=input_dim,
            d_out=config.d_out,
            d_hidden=config.d_hidden if hasattr(config, 'd_hidden') else 128,
            n_hidden_layers=config.n_hidden_layers if hasattr(config, 'n_hidden_layers') else 2,
            dropout=config.dropout if hasattr(config, 'dropout') else 0.3,
            normalize=config.normalize if hasattr(config, 'normalize') else True,
            residual=config.residual if hasattr(config, 'residual') else True,
            use_batch_norm=config.use_batch_norm if hasattr(config, 'use_batch_norm') else True,
        )
        self.encoder_mlp = SimpleMLP(mlp_config)
        
        # Replacement embedding for invalid coordinates
        self._replacement_embedding = nn.Parameter(torch.randn(config.d_out))
        nn.init.normal_(self._replacement_embedding, mean=0.0, std=0.01)
        
        logger.info(f"🌍 CoordinateHybridEncoder initialized: lat={lat_col}, long={long_col}, d_model={config.d_out}")
    
    def _geo_encode(self, lat: float, lon: float) -> torch.Tensor:
        """
        Encode geographic coordinates with additional features.
        
        Returns tensor of shape [6]: lat, lon, lat_norm, lon_norm, dist_equator, dist_prime_meridian
        """
        # Normalize to [-1, 1]
        lat_norm = lat / 90.0 if abs(lat) <= 90 else 0.0
        lon_norm = lon / 180.0 if abs(lon) <= 180 else 0.0
        
        # Distance from equator (0 to 1)
        dist_equator = abs(lat) / 90.0 if abs(lat) <= 90 else 1.0
        
        # Distance from prime meridian (0 to 1)
        dist_meridian = abs(lon) / 180.0 if abs(lon) <= 180 else 1.0
        
        return torch.tensor([
            lat, lon, lat_norm, lon_norm, dist_equator, dist_meridian
        ], dtype=torch.float32)
    
    def forward(self, batch_data: Dict[str, TokenBatch]) -> tuple:
        """
        Encode coordinate pairs from batch_data.
        
        Args:
            batch_data: Dictionary containing lat and long columns
        
        Returns:
            (short_encoding, full_encoding) tuple
        """
        # Extract lat/long batches
        lat_batch = batch_data.get(self.lat_col)
        long_batch = batch_data.get(self.long_col)
        
        if lat_batch is None or long_batch is None:
            logger.error(f"💥 CoordinateHybridEncoder missing columns: lat={self.lat_col}, long={self.long_col}")
            # Infer batch size from another column in batch_data, fall back to 1
            batch_size = 1
            for col_name, col_batch in batch_data.items():
                if col_batch is not None and "values" in col_batch:
                    batch_size = len(col_batch["values"])
                    break
            result = self._replacement_embedding.unsqueeze(0).expand(batch_size, -1)
            return result[:, 0:3], result
        
        batch_size = len(lat_batch["values"])
        embeddings = []

        # Get device from model parameters
        device = next(self.encoder_mlp.parameters()).device
        replacement_emb = self._replacement_embedding.to(device)

        logger.debug(f"CoordinateHybridEncoder: batch_size={batch_size}, lat_col={self.lat_col}, long_col={self.long_col}")

        for i in range(batch_size):
            # Check token status
            if (lat_batch["status"][i] != TokenStatus.OK or
                long_batch["status"][i] != TokenStatus.OK):
                embeddings.append(replacement_emb.unsqueeze(0))
                continue

            # Extract lat/long values
            try:
                lat = float(lat_batch["values"][i])
                lon = float(long_batch["values"][i])

                # Validate ranges
                if not (-90 <= lat <= 90) or not (-180 <= lon <= 180):
                    logger.debug(f"Invalid coordinates: lat={lat}, lon={lon}")
                    embeddings.append(replacement_emb.unsqueeze(0))
                    continue

                # Geo-encode and move to device
                features = self._geo_encode(lat, lon).to(device)

                # Encode through MLP
                emb = self.encoder_mlp(features.unsqueeze(0))
                embeddings.append(emb)

            except (ValueError, TypeError) as e:
                logger.debug(f"Failed to parse coordinates: {e}")
                embeddings.append(replacement_emb.unsqueeze(0))

        # Stack all embeddings
        if not embeddings:
            logger.error(f"💥 CoordinateHybridEncoder: no embeddings produced for batch_size={batch_size}")
            result = replacement_emb.unsqueeze(0).expand(batch_size, -1)
        else:
            result = torch.cat(embeddings, dim=0)
            if result.shape[0] != batch_size:
                logger.error(f"💥 CoordinateHybridEncoder: shape mismatch! expected {batch_size}, got {result.shape[0]}")
                result = replacement_emb.unsqueeze(0).expand(batch_size, -1)

        # Check for NaN
        if torch.isnan(result).any():
            logger.error(f"💥 CoordinateHybridEncoder output contains NaN!")
            result = self._replacement_embedding.to(result.dtype).unsqueeze(0).expand(batch_size, -1)
        
        # Return short and full encodings
        if self.config.normalize:
            short_vec = F.normalize(result[:, 0:3], dim=1, eps=1e-8)
            full_vec = F.normalize(result, dim=1, eps=1e-8)
        else:
            short_vec = result[:, 0:3]
            full_vec = result
        
        return short_vec, full_vec

