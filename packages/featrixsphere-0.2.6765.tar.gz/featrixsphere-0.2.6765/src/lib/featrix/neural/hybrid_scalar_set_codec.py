#  -*- coding: utf-8 -*-
#
#  Copyright Featrix, Inc 2023-2026
#
#  Proprietary and Confidential.  Unauthorized use, copying or dissemination
#  of these materials is strictly prohibited.
#
"""
HybridScalarSetCodec - A codec that wraps both ScalarCodec and SetCodec for low-cardinality
numeric columns, selecting the best encoding strategy based on training loss.

This addresses the problem where columns like "num_dependents" (values 0-3) or
"installment_commitment" (values 1-4) have poor embedding quality when treated as
continuous scalars, but might work better as discrete categorical sets.

The hybrid codec:
1. During warmup: runs both encodings, tracks loss for each
2. After warmup: selects the better strategy (or blends if losses are similar)
3. Is feature-flagged via use_hybrid_scalar_set_codec in sphere_config

TODO: Implement HybridStringSetCodec for columns like 'purpose' that have low cardinality
      (e.g., 10 unique values) but are detected as FREE_STRING due to string values.
      Similar approach: run both StringEncoder and SetEncoder during warmup, select best.
      This would catch cases where SET detection threshold misses categorical strings.
"""

import base64
import hashlib
import io
import logging
import math
import pickle
from typing import Optional, Dict, Any, Tuple

import numpy as np
import torch
import torch.nn as nn

from featrix.neural.featrix_token import Token, TokenStatus
from featrix.neural.model_config import ColumnType

logger = logging.getLogger(__name__)


class HybridScalarSetCodec(nn.Module):
    """
    Codec that wraps both ScalarCodec and SetCodec for low-cardinality numeric columns.

    During warmup, both encodings are computed and loss is tracked.
    After warmup, the better strategy is selected (or blended if similar).
    """

    def __init__(
        self,
        scalar_codec: 'ScalarCodec', # noqa: F821
        set_codec: 'SetCodec',       # noqa: F821
        column_name: str = "unknown",
        warmup_fraction: float = 0.05,
        blend_threshold: float = 0.1
    ):
        """
        Initialize the hybrid codec.

        Args:
            scalar_codec: Pre-configured ScalarCodec instance
            set_codec: Pre-configured SetCodec instance
            column_name: Name of the column (for logging)
            warmup_fraction: Fraction of training for warmup detection
            blend_threshold: If loss diff < threshold, blend both encodings
        """
        super().__init__()
        self._is_decodable = True

        self.scalar_codec = scalar_codec
        self.set_codec = set_codec
        self.column_name = column_name
        self.warmup_fraction = warmup_fraction
        self.blend_threshold = blend_threshold

        # Codec selection state
        self._in_warmup = True
        self._selected_mode: Optional[str] = None  # "scalar", "set", or "blend"
        self._blend_weight: float = 0.5  # Weight for scalar in blend (0.5 = equal)

        # Loss tracking during warmup
        self._scalar_losses = []
        self._set_losses = []
        self._warmup_steps = 0
        self._total_steps = 0

        # Copy key attributes from scalar codec for compatibility
        self.enc_dim = scalar_codec.enc_dim
        self.stats = scalar_codec.stats
        self.mean = scalar_codec.mean
        self.stdev = scalar_codec.stdev

        # Members from set codec
        self.members = set_codec.members
        self.n_members = set_codec.n_members

        logger.info(f"HybridScalarSetCodec[{column_name}]: Created with {self.n_members} set members, "
                   f"warmup={warmup_fraction:.1%}, blend_threshold={blend_threshold:.1%}")

    def get_codec_name(self) -> ColumnType:
        return ColumnType.HYBRID_SCALAR_SET

    def get_codec_info(self) -> Dict[str, Any]:
        """Return serializable codec info for checkpoints."""
        return {
            "codec_type": "hybrid_scalar_set",
            "column_name": self.column_name,
            "selected_mode": self._selected_mode,
            "blend_weight": self._blend_weight,
            "warmup_fraction": self.warmup_fraction,
            "blend_threshold": self.blend_threshold,
            # Include both codec infos
            "scalar_codec": self.scalar_codec.get_codec_info(),
            "set_codec": self.set_codec.get_codec_info(),
        }

    def get_not_present_token(self) -> Token:
        """Return token for missing/null values."""
        # Use scalar's token format (float) as default
        return Token(
            value=np.float32(0.0),
            status=TokenStatus.NOT_PRESENT,
        )

    def get_marginal_token(self) -> Token:
        """Return token for masked/marginal values."""
        return Token(
            value=np.float32(0.0),
            status=TokenStatus.MARGINAL,
        )

    @property
    def token_dtype(self):
        """Token dtype depends on selected mode."""
        if self._selected_mode == "set":
            return int
        return float  # scalar or blend

    def tokenize(self, value) -> Token:
        """
        Tokenize a value using the selected strategy.

        During warmup or blend mode, returns scalar token (float).
        After warmup with "set" selected, returns set token (int).
        """
        # During warmup or blend, we need both tokenizations
        # For simplicity, always return scalar token - the encoder handles strategy
        if self._selected_mode == "set" and not self._in_warmup:
            return self.set_codec.tokenize(value)
        else:
            return self.scalar_codec.tokenize(value)

    def tokenize_both(self, value) -> Tuple[Token, Token]:
        """Tokenize using both codecs (for warmup/blend)."""
        return self.scalar_codec.tokenize(value), self.set_codec.tokenize(value)

    def detokenize(self, token: Token):
        """Detokenize based on selected mode."""
        if token.status in (TokenStatus.NOT_PRESENT, TokenStatus.UNKNOWN):
            raise ValueError(f"Cannot detokenize token with status {token.status}")

        if self._selected_mode == "set" and not self._in_warmup:
            return self.set_codec.detokenize(token)
        else:
            return self.scalar_codec.detokenize(token)

    def loss(self, predictions, targets):
        """
        Compute loss based on selected mode.

        During warmup, this should be called separately for scalar and set predictions.
        After warmup, computes loss for the selected strategy.
        """
        if self._selected_mode == "set":
            return self.set_codec.loss(predictions, targets)
        else:
            return self.scalar_codec.loss(predictions, targets)

    def loss_single(self, predictions, targets):
        """Loss for batch size 1."""
        if self._selected_mode == "set":
            return self.set_codec.loss_single(predictions, targets)
        else:
            return self.scalar_codec.loss_single(predictions, targets)

    def record_warmup_loss(self, scalar_loss: float, set_loss: float):
        """
        Record losses during warmup phase.

        Called by the encoder during forward pass in warmup mode.
        """
        self._scalar_losses.append(scalar_loss)
        self._set_losses.append(set_loss)
        self._warmup_steps += 1

    def update_step(self, current_step: int, total_steps: int):
        """
        Update training step and check if warmup should end.

        Args:
            current_step: Current training step
            total_steps: Total training steps
        """
        self._total_steps = total_steps
        warmup_end = int(total_steps * self.warmup_fraction)

        if self._in_warmup and current_step >= warmup_end and self._warmup_steps > 0:
            self._finalize_selection()

    def _finalize_selection(self):
        """Select encoding based on which one is learning faster (improving more).

        Compares relative improvement (% reduction in loss) for scalar vs set.
        Both use InfoNCE loss so they're directly comparable.
        """
        if len(self._scalar_losses) < 2 or len(self._set_losses) < 2:
            # Not enough data - fall back to cardinality heuristic
            logger.warning(f"HybridScalarSetCodec[{self.column_name}]: Not enough loss samples ({len(self._scalar_losses)} scalar, {len(self._set_losses)} set), using cardinality heuristic")
            if self.n_members <= 5:
                self._selected_mode = "set"
            else:
                self._selected_mode = "scalar"
            self._blend_weight = 1.0 if self._selected_mode == "scalar" else 0.0
            self._in_warmup = False
            return

        # Compare first 25% vs last 25% for stable comparison
        n = len(self._scalar_losses)
        early_n = max(1, n // 4)
        late_n = max(1, n // 4)

        early_scalar = sum(self._scalar_losses[:early_n]) / early_n
        late_scalar = sum(self._scalar_losses[-late_n:]) / late_n
        early_set = sum(self._set_losses[:early_n]) / early_n
        late_set = sum(self._set_losses[-late_n:]) / late_n

        # Compute improvement rate (positive = loss went down = good)
        scalar_improvement = (early_scalar - late_scalar) / max(early_scalar, 1e-6)
        set_improvement = (early_set - late_set) / max(early_set, 1e-6)

        # Pick whichever improved more
        improvement_diff = scalar_improvement - set_improvement

        if abs(improvement_diff) < self.blend_threshold:
            # Similar improvement - blend
            self._selected_mode = "blend"
            # Weight towards the one that improved more
            total = abs(scalar_improvement) + abs(set_improvement)
            if total > 0:
                self._blend_weight = max(0, scalar_improvement) / total
            else:
                self._blend_weight = 0.5
        elif scalar_improvement > set_improvement:
            self._selected_mode = "scalar"
            self._blend_weight = 1.0
        else:
            self._selected_mode = "set"
            self._blend_weight = 0.0

        self._in_warmup = False

        logger.info(f"HybridScalarSetCodec[{self.column_name}]: Warmup complete after {self._warmup_steps} steps")
        logger.info(f"  Scalar: {early_scalar:.4f} → {late_scalar:.4f} (improvement={scalar_improvement:+.1%})")
        logger.info(f"  Set:    {early_set:.4f} → {late_set:.4f} (improvement={set_improvement:+.1%})")
        logger.info(f"  Selected: {self._selected_mode}" +
                   (f" (blend_weight={self._blend_weight:.2f})" if self._selected_mode == "blend" else ""))

    def force_select_mode(self, mode: str, blend_weight: float = 0.5):
        """Force a specific mode (for testing or manual override)."""
        assert mode in ("scalar", "set", "blend")
        self._selected_mode = mode
        self._blend_weight = blend_weight
        self._in_warmup = False
        logger.info(f"HybridScalarSetCodec[{self.column_name}]: Forced mode={mode}, blend_weight={blend_weight}")

    @property
    def is_in_warmup(self) -> bool:
        return self._in_warmup

    @property
    def selected_mode(self) -> Optional[str]:
        return self._selected_mode

    @property
    def blend_weight(self) -> float:
        return self._blend_weight

    def get_visualization_domain(self, _min=None, _max=None, _steps=40):
        """Return visualization domain based on selected mode."""
        if self._selected_mode == "set":
            return self.set_codec.get_visualization_domain(_min, _max, _steps)
        else:
            return self.scalar_codec.get_visualization_domain(_min, _max, _steps)

    def save(self) -> Dict[str, Any]:
        """Save codec state for checkpoint."""
        buffer = io.BytesIO()
        torch.save(self.state_dict(), buffer)

        buffer_b64 = "base64:" + str(
            base64.standard_b64encode(buffer.getvalue()).decode("utf8")
        )
        checksum = hashlib.md5(buffer.getvalue()).hexdigest()

        return {
            "type": "HybridScalarSetCodec",
            "column_name": self.column_name,
            "selected_mode": self._selected_mode,
            "blend_weight": self._blend_weight,
            "in_warmup": self._in_warmup,
            "warmup_fraction": self.warmup_fraction,
            "blend_threshold": self.blend_threshold,
            "embedding": buffer_b64,
            "embedding_checksum": checksum,
            # Save both codecs
            "scalar_codec": self.scalar_codec.save(),
            "set_codec": self.set_codec.save(),
        }

    def load(self, j: Dict[str, Any]):
        """Load codec state from checkpoint."""
        d_type = j.get("type")
        assert d_type == "HybridScalarSetCodec", f"wrong load method called for {d_type}"

        self.column_name = j.get("column_name", "unknown")
        self._selected_mode = j.get("selected_mode")
        self._blend_weight = j.get("blend_weight", 0.5)
        self._in_warmup = j.get("in_warmup", False)
        self.warmup_fraction = j.get("warmup_fraction", 0.05)
        self.blend_threshold = j.get("blend_threshold", 0.1)

        # Load embedded codecs
        if "scalar_codec" in j:
            self.scalar_codec.load(j["scalar_codec"])
        if "set_codec" in j:
            self.set_codec.load(j["set_codec"])

        # Load state dict if present
        embedding_str = j.get("embedding")
        if embedding_str:
            embedding = base64.standard_b64decode(embedding_str.replace("base64:", ""))
            buffer = io.BytesIO(embedding)
            self.load_state_dict(torch.load(buffer, weights_only=True))


class HybridScalarSetEncoder(nn.Module):
    """
    Encoder that wraps both AdaptiveScalarEncoder and SetEncoder for hybrid columns.

    During warmup, runs both encoders and tracks loss.
    After warmup, uses the selected strategy (or blends both).
    """

    def __init__(
        self,
        hybrid_codec: HybridScalarSetCodec,
        scalar_encoder: nn.Module,  # AdaptiveScalarEncoder
        set_encoder: nn.Module,  # SetEncoder
        normalize: bool = True
    ):
        """
        Initialize the hybrid encoder.

        Args:
            hybrid_codec: The HybridScalarSetCodec with state tracking
            scalar_encoder: Pre-configured AdaptiveScalarEncoder
            set_encoder: Pre-configured SetEncoder
            normalize: Whether to normalize output embeddings
        """
        super().__init__()
        self.hybrid_codec = hybrid_codec
        self.scalar_encoder = scalar_encoder
        self.set_encoder = set_encoder
        self.normalize = normalize

        # Reference to column name
        self.column_name = hybrid_codec.column_name

        # D_model from encoders (should match)
        self.d_model = scalar_encoder.d_model

        logger.info(f"HybridScalarSetEncoder[{self.column_name}]: Created wrapping scalar and set encoders")

    @property
    def marginal_embedding(self):
        """
        Return marginal embedding based on selected mode.

        During warmup or blend: average of both marginals
        After scalar selection: scalar marginal
        After set selection: set marginal
        """
        codec = self.hybrid_codec

        if codec.is_in_warmup or codec.selected_mode == "blend":
            # Average both marginal embeddings - ensure same device
            scalar_marginal = self.scalar_encoder.marginal_embedding
            set_marginal = self.set_encoder.marginal_embedding
            # Move to same device if needed
            if scalar_marginal.device != set_marginal.device:
                set_marginal = set_marginal.to(scalar_marginal.device)
            return 0.5 * scalar_marginal + 0.5 * set_marginal
        elif codec.selected_mode == "scalar":
            return self.scalar_encoder.marginal_embedding
        else:  # set mode
            return self.set_encoder.marginal_embedding

    @property
    def not_present_embedding(self):
        """Return same as marginal for consistency with other encoders."""
        return self.marginal_embedding

    def forward(self, token, return_strategy_encodings: bool = False):
        """
        Encode token batch through hybrid strategy.

        During warmup: runs both encoders, returns blended output
        After warmup: runs only selected encoder (or blends)

        Args:
            token: TokenBatch with value tensor
            return_strategy_encodings: If True, return strategy component encodings

        Returns:
            (short_vec, full_vec) tuple, optionally with strategy encodings
        """
        codec = self.hybrid_codec

        if codec.is_in_warmup:
            # WARMUP: Run both encoders and store for loss comparison
            # Scalar encoder expects float tokens
            scalar_short, scalar_full = self.scalar_encoder(token)

            # For set encoder, we need to convert float values to integer indices
            # Create a set token from the scalar value
            set_token = self._create_set_token(token)
            set_result = self.set_encoder(set_token, return_strategy_encodings=False)
            set_short, set_full = set_result[0], set_result[1]

            # Store both embeddings for loss comparison later
            self._warmup_scalar_embedding = scalar_full
            self._warmup_set_embedding = set_full

            # Blend 50/50 during warmup
            short_vec = 0.5 * scalar_short + 0.5 * set_short
            full_vec = 0.5 * scalar_full + 0.5 * set_full

            if return_strategy_encodings:
                # Stack both encodings for strategy-aware ops
                strategy_encodings = torch.stack([scalar_full, set_full], dim=1)
                return short_vec, full_vec, strategy_encodings

            return short_vec, full_vec

        elif codec.selected_mode == "scalar":
            # SCALAR ONLY
            result = self.scalar_encoder(token, return_strategy_encodings=return_strategy_encodings)
            return result

        elif codec.selected_mode == "set":
            # SET ONLY
            set_token = self._create_set_token(token)
            return self.set_encoder(set_token, return_strategy_encodings=return_strategy_encodings)

        else:  # blend mode
            # BLEND: Weighted combination
            weight = codec.blend_weight  # Weight for scalar

            scalar_short, scalar_full = self.scalar_encoder(token)
            set_token = self._create_set_token(token)
            set_result = self.set_encoder(set_token)
            set_short, set_full = set_result[0], set_result[1]

            short_vec = weight * scalar_short + (1 - weight) * set_short
            full_vec = weight * scalar_full + (1 - weight) * set_full

            if return_strategy_encodings:
                strategy_encodings = torch.stack([scalar_full, set_full], dim=1)
                return short_vec, full_vec, strategy_encodings

            return short_vec, full_vec

    def _create_set_token(self, scalar_token) -> Token:
        """
        Convert scalar token values to set token indices.

        The hybrid codec's set_codec has the value-to-index mapping.
        """
        set_codec = self.hybrid_codec.set_codec
        batch_size = scalar_token.value.shape[0]
        device = scalar_token.value.device

        # Convert each scalar value to its set member index
        indices = []
        for i in range(batch_size):
            val = scalar_token.value[i].item()
            # Denormalize the scalar value
            denorm_val = (val * self.hybrid_codec.stdev) + self.hybrid_codec.mean
            # Convert to string for set codec lookup
            str_val = str(int(round(denorm_val))) if abs(denorm_val - round(denorm_val)) < 0.001 else str(denorm_val)

            if str_val in set_codec.members_to_tokens:
                idx = set_codec.members_to_tokens[str_val]
            else:
                idx = 0  # <UNKNOWN>
            indices.append(idx)

        set_value = torch.tensor(indices, dtype=torch.long, device=device)

        return Token(
            value=set_value,
            status=scalar_token.status,
            attention_mask=getattr(scalar_token, 'attention_mask', None)
        )

    def compute_and_record_warmup_losses(self, target_encoding: torch.Tensor):
        """
        Compute cosine similarity loss for both embeddings and record them.

        Uses stored embeddings from forward() and compares to target.
        Same metric (cosine sim) for both, so each can be compared to itself over time.

        Args:
            target_encoding: The target column encoding (batch, d_model)
        """
        if not self.hybrid_codec.is_in_warmup:
            return

        if not hasattr(self, '_warmup_scalar_embedding') or not hasattr(self, '_warmup_set_embedding'):
            return

        with torch.no_grad():
            # Cosine similarity loss: 1 - cos_sim (lower = better alignment)
            scalar_sim = torch.nn.functional.cosine_similarity(
                self._warmup_scalar_embedding, target_encoding, dim=-1
            ).mean().item()
            set_sim = torch.nn.functional.cosine_similarity(
                self._warmup_set_embedding, target_encoding, dim=-1
            ).mean().item()

            # Convert to loss (1 - similarity, so lower is better)
            scalar_loss = 1.0 - scalar_sim
            set_loss = 1.0 - set_sim

        # Record the losses
        self.hybrid_codec.record_warmup_loss(scalar_loss, set_loss)

        # Clean up
        del self._warmup_scalar_embedding
        del self._warmup_set_embedding


def create_hybrid_scalar_set_codec(
    df_col,
    embed_dim: int,
    column_name: str = "unknown",
    detector=None,
    string_cache=None
) -> HybridScalarSetCodec:
    """
    Factory function to create a HybridScalarSetCodec.

    Args:
        df_col: DataFrame column to analyze
        embed_dim: Embedding dimension
        column_name: Name of the column
        detector: Column detector (for sparsity info)
        string_cache: String cache path for semantic initialization

    Returns:
        HybridScalarSetCodec wrapping both scalar and set codecs
    """
    from featrix.neural.encoders import create_scalar_codec, create_set_codec
    from featrix.neural.sphere_config import get_config

    config = get_config()

    # Create both codecs
    scalar_codec = create_scalar_codec(df_col, embed_dim)
    set_codec = create_set_codec(
        df_col, embed_dim,
        loss_type="cross_entropy",  # Simple loss for hybrid warmup comparison
        detector=detector,
        string_cache=string_cache
    )

    # Create hybrid wrapper
    hybrid_codec = HybridScalarSetCodec(
        scalar_codec=scalar_codec,
        set_codec=set_codec,
        column_name=column_name,
        warmup_fraction=config.get_hybrid_warmup_fraction(),
        blend_threshold=config.get_hybrid_blend_threshold()
    )

    return hybrid_codec
