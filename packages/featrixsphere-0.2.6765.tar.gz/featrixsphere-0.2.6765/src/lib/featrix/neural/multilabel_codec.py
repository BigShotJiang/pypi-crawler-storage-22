#  -*- coding: utf-8 -*-
#
#  Copyright Featrix, Inc 2023-2025
#
#  Proprietary and Confidential.  Unauthorized use, copying or dissemination
#  of these materials is strictly prohibited.
#
import base64
import hashlib
import io
import logging
import pickle
import traceback

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from featrix.neural.featrix_token import Token, TokenStatus
from featrix.neural.model_config import ColumnType

logger = logging.getLogger(__name__)


class FocalBCEWithLogitsLoss(nn.Module):
    """
    Focal Binary Cross-Entropy with Logits for multi-label classification.

    Per-label focal weighting: down-weights easy examples so the model focuses
    on hard-to-classify labels.  Equivalent to standard BCE when gamma=0.

    Args:
        gamma: Focusing parameter. Higher values increase focus on hard examples.
        pos_weight: Optional per-label positive-class weight tensor of shape [C].
    """

    def __init__(self, gamma=2.0, pos_weight=None):
        super().__init__()
        self.gamma = gamma
        self.register_buffer("pos_weight", pos_weight)

    def forward(self, logits, targets):
        """
        Args:
            logits:  [B, C] raw model output (before sigmoid)
            targets: [B, C] multi-hot float targets (0.0 or 1.0)
        """
        # Numerically stable BCE per element
        bce = F.binary_cross_entropy_with_logits(
            logits, targets, reduction="none", pos_weight=self.pos_weight
        )

        # p_t = probability of the correct answer
        probs = torch.sigmoid(logits)
        p_t = targets * probs + (1 - targets) * (1 - probs)

        focal_weight = (1 - p_t).pow(self.gamma)
        return (focal_weight * bce).mean()


class MultiLabelCodec(nn.Module):
    """
    Codec for multi-label classification targets.

    Each row's target is a delimited string of zero or more labels
    (e.g. "action,comedy,drama").  The codec converts these to multi-hot
    float tensors of shape [C] where C = number of unique labels.

    Unlike SetCodec there is no <UNKNOWN> slot — labels not in the
    vocabulary are silently ignored (0 in the multi-hot vector).
    """

    def __init__(self, label_set, enc_dim, delimiter=",", loss_type="bce",
                 pos_weight=None, focal_gamma=2.0):
        """
        Args:
            label_set: set of all unique label strings
            enc_dim: embedding dimension (stored for save/load compatibility)
            delimiter: string used to split multi-label values
            loss_type: "bce" or "focal_bce"
            pos_weight: optional tensor [C] of per-label positive weights
            focal_gamma: gamma for FocalBCEWithLogitsLoss (if focal_bce)
        """
        super().__init__()
        self.enc_dim = enc_dim
        self.delimiter = delimiter

        # Build sorted label vocabulary
        sorted_labels = sorted(label_set)
        self.n_labels = len(sorted_labels)
        self.label_to_idx = {label: idx for idx, label in enumerate(sorted_labels)}
        self.idx_to_label = sorted_labels

        # Loss function
        if loss_type == "focal_bce":
            self.loss_fn = FocalBCEWithLogitsLoss(
                gamma=focal_gamma,
                pos_weight=pos_weight,
            )
        else:
            # Standard BCE
            self.loss_fn = nn.BCEWithLogitsLoss(pos_weight=pos_weight)

        logger.info(
            f"MultiLabelCodec: {self.n_labels} labels, "
            f"loss={loss_type}, delimiter='{delimiter}'"
        )

    # ------------------------------------------------------------------
    # Tokenize / Detokenize
    # ------------------------------------------------------------------

    def tokenize(self, value):
        """
        Convert a delimited label string to a multi-hot Token.

        Args:
            value: string like "action,comedy" or NaN/None

        Returns:
            Token with value=float32 tensor [C] and appropriate status
        """
        multi_hot = torch.zeros(self.n_labels, dtype=torch.float32)

        # Handle missing values
        if value is None or (isinstance(value, float) and np.isnan(value)):
            return Token(value=multi_hot, status=TokenStatus.NOT_PRESENT)

        value_str = str(value).strip()
        if value_str == "" or value_str.lower() == "nan":
            return Token(value=multi_hot, status=TokenStatus.NOT_PRESENT)

        # Parse labels
        labels = [lbl.strip() for lbl in value_str.split(self.delimiter)]
        found_any = False
        for label in labels:
            if label in self.label_to_idx:
                multi_hot[self.label_to_idx[label]] = 1.0
                found_any = True

        status = TokenStatus.OK if found_any else TokenStatus.UNKNOWN
        return Token(value=multi_hot, status=status)

    def detokenize(self, tensor, threshold=0.5):
        """
        Convert a probability or multi-hot tensor to a list of label strings.

        Args:
            tensor: float tensor of shape [C]
            threshold: probability cutoff for predicting a label

        Returns:
            list of label strings whose value >= threshold
        """
        if isinstance(tensor, torch.Tensor):
            tensor = tensor.detach().cpu()
        return [
            self.idx_to_label[i]
            for i in range(self.n_labels)
            if tensor[i] >= threshold
        ]

    # ------------------------------------------------------------------
    # Loss
    # ------------------------------------------------------------------

    def loss(self, logits, targets):
        """Compute multi-label loss.  logits and targets are both [B, C] float."""
        return self.loss_fn(logits, targets)

    # ------------------------------------------------------------------
    # Token helpers (used by the embedding space for marginal/not-present)
    # ------------------------------------------------------------------

    def get_not_present_token(self):
        return Token(
            value=torch.zeros(self.n_labels, dtype=torch.float32),
            status=TokenStatus.NOT_PRESENT,
        )

    def get_marginal_token(self):
        return Token(
            value=torch.zeros(self.n_labels, dtype=torch.float32),
            status=TokenStatus.MARGINAL,
        )

    # ------------------------------------------------------------------
    # Serialization (matches SetCodec save/load pattern)
    # ------------------------------------------------------------------

    def save(self):
        buffer = io.BytesIO()
        torch.save(self.state_dict(), buffer)
        buffer_b64 = "base64:" + base64.standard_b64encode(buffer.getvalue()).decode("utf8")
        checksum = hashlib.md5(buffer.getvalue()).hexdigest()

        labels_bytes = pickle.dumps(set(self.idx_to_label))
        labels_b64 = "base64:" + base64.standard_b64encode(labels_bytes).decode("utf8")

        return {
            "type": "MultiLabelCodec",
            "embedding": buffer_b64,
            "embedding_checksum": checksum,
            "enc_dim": self.enc_dim,
            "labels": labels_b64,
            "delimiter": self.delimiter,
        }

    def load(self, j):
        d_type = j.get("type")
        assert d_type == "MultiLabelCodec", f"wrong load method called for __{d_type}__"
        self.enc_dim = j.get("enc_dim")
        self.delimiter = j.get("delimiter", ",")

        # Restore label set
        labels_b64 = j.get("labels")
        assert labels_b64.startswith("base64:")
        labels_b64 = labels_b64[6:]
        try:
            label_set = pickle.loads(base64.standard_b64decode(labels_b64))
        except Exception:
            logger.error(f"PICKLE ERROR loading MultiLabelCodec labels")
            traceback.print_exc()
            raise

        sorted_labels = sorted(label_set)
        self.n_labels = len(sorted_labels)
        self.label_to_idx = {label: idx for idx, label in enumerate(sorted_labels)}
        self.idx_to_label = sorted_labels

        # Restore state dict (nn.Module weights)
        embed = j.get("embedding")
        embed_checksum = j.get("embedding_checksum")
        assert embed.startswith("base64:")
        embed = embed[6:]
        embed_bytes = base64.standard_b64decode(embed)
        actual_checksum = hashlib.md5(embed_bytes).hexdigest()
        if actual_checksum != embed_checksum:
            logger.warning(
                f"MultiLabelCodec checksum mismatch: expected {embed_checksum}, got {actual_checksum}"
            )
        buffer = io.BytesIO(embed_bytes)
        state_dict = torch.load(buffer, map_location="cpu", weights_only=True)
        self.load_state_dict(state_dict, strict=False)

    # ------------------------------------------------------------------
    # Column type identifier
    # ------------------------------------------------------------------

    @property
    def token_dtype(self):
        return "multi_label"

    def get_codec_name(self):
        return ColumnType.MULTI_LABEL
