#  -*- coding: utf-8 -*-
#
#  Copyright Featrix, Inc 2023-2025
#
#  Proprietary and Confidential.  Unauthorized use, copying or dissemination
#  of these materials is strictly prohibited.
#
"""
Utility functions for multi-label classification.

These are isolated from single_predictor.py so that file stays as small as
possible.  single_predictor.py imports and delegates to these helpers.
"""
import logging

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from sklearn.metrics import (
    f1_score,
    hamming_loss as sklearn_hamming_loss,
    jaccard_score as sklearn_jaccard_score,
    roc_auc_score,
)

from featrix.neural.multilabel_codec import MultiLabelCodec

logger = logging.getLogger(__name__)


# ------------------------------------------------------------------
# Factory
# ------------------------------------------------------------------

def create_multilabel_codec(df_col, embed_dim, delimiter=",",
                            loss_type="bce", pos_weight=None,
                            focal_gamma=2.0):
    """
    Build a MultiLabelCodec from a DataFrame column of delimited label strings.

    Args:
        df_col: pandas Series whose values are delimited label strings
        embed_dim: embedding dimension (for codec compatibility)
        delimiter: separator between labels
        loss_type: "bce" or "focal_bce"
        pos_weight: optional pre-computed pos_weight tensor
        focal_gamma: gamma for focal BCE loss

    Returns:
        MultiLabelCodec ready to tokenize/detokenize
    """
    label_set = extract_label_vocabulary(df_col, delimiter)
    logger.info(
        f"Multi-label vocabulary: {len(label_set)} labels "
        f"extracted from {len(df_col)} rows"
    )
    return MultiLabelCodec(
        label_set=label_set,
        enc_dim=embed_dim,
        delimiter=delimiter,
        loss_type=loss_type,
        pos_weight=pos_weight,
        focal_gamma=focal_gamma,
    )


def extract_label_vocabulary(df_col, delimiter=","):
    """
    Extract the full set of unique labels from a column of delimited strings.

    Args:
        df_col: pandas Series with values like "action,comedy"
        delimiter: separator between labels

    Returns:
        set of unique label strings
    """
    labels = set()
    for val in df_col.dropna().astype(str):
        val = val.strip()
        if val == "" or val.lower() == "nan":
            continue
        for lbl in val.split(delimiter):
            lbl = lbl.strip()
            if lbl:
                labels.add(lbl)
    return labels


# ------------------------------------------------------------------
# Class weight computation
# ------------------------------------------------------------------

def compute_multilabel_class_weights(df_col, delimiter=","):
    """
    Compute per-label pos_weight for BCEWithLogitsLoss.

    pos_weight[i] = n_negative[i] / n_positive[i] so that rare labels
    receive higher weight.

    Args:
        df_col: pandas Series with delimited label strings
        delimiter: separator

    Returns:
        torch.Tensor of shape [C] (sorted label order), or None if
        computation fails.
    """
    label_set = extract_label_vocabulary(df_col, delimiter)
    if not label_set:
        return None

    sorted_labels = sorted(label_set)
    label_to_idx = {lbl: idx for idx, lbl in enumerate(sorted_labels)}
    n_labels = len(sorted_labels)
    n_samples = len(df_col)

    counts = np.zeros(n_labels, dtype=np.float64)
    for val in df_col.dropna().astype(str):
        val = val.strip()
        if val == "" or val.lower() == "nan":
            continue
        for lbl in val.split(delimiter):
            lbl = lbl.strip()
            if lbl in label_to_idx:
                counts[label_to_idx[lbl]] += 1

    # pos_weight = n_neg / n_pos, clamped to [0.5, 50] to avoid extremes
    pos_weight = np.ones(n_labels, dtype=np.float32)
    for i in range(n_labels):
        n_pos = max(counts[i], 1.0)
        n_neg = max(n_samples - counts[i], 1.0)
        pos_weight[i] = np.clip(n_neg / n_pos, 0.5, 50.0)

    logger.info(
        f"Multi-label pos_weight: min={pos_weight.min():.2f}, "
        f"max={pos_weight.max():.2f}, mean={pos_weight.mean():.2f}"
    )
    return torch.tensor(pos_weight, dtype=torch.float32)


# ------------------------------------------------------------------
# Batch target preparation
# ------------------------------------------------------------------

def prepare_multilabel_targets(target_token_batch):
    """
    Extract multi-hot target tensor from a TokenBatch.

    The MultiLabelCodec.tokenize() already produces Token(value=[C] float32),
    and TokenBatch stacks these into [B, C].  This function just ensures
    the dtype is correct.

    Args:
        target_token_batch: TokenBatch from the data loader

    Returns:
        float32 tensor of shape [B, C]
    """
    targets = target_token_batch.value  # Already [B, C] from torch.stack
    return targets.float()


# ------------------------------------------------------------------
# Prediction conversion
# ------------------------------------------------------------------

def convert_multilabel_output_to_prediction(logits, codec, threshold=0.5):
    """
    Convert raw model logits to a multi-label prediction dictionary.

    Applies sigmoid (not softmax) because labels are independent.

    Args:
        logits: tensor of shape [1, C] or [C] — raw model output
        codec: MultiLabelCodec instance
        threshold: probability cutoff for predicting a label

    Returns:
        dict with keys: prediction, probabilities, threshold, target_column
    """
    if logits.dim() > 1:
        logits = logits.squeeze(0)

    probs = torch.sigmoid(logits).detach().cpu()

    # Build probability dict for all labels
    probabilities = {}
    for i, label in enumerate(codec.idx_to_label):
        probabilities[label] = float(probs[i])

    # Predicted labels are those above threshold
    predicted_labels = [
        codec.idx_to_label[i]
        for i in range(codec.n_labels)
        if probs[i] >= threshold
    ]

    # Sort by probability descending for readability
    predicted_labels.sort(key=lambda lbl: probabilities[lbl], reverse=True)

    return {
        "prediction": predicted_labels,
        "probabilities": probabilities,
        "threshold": threshold,
        "n_predicted": len(predicted_labels),
    }


# ------------------------------------------------------------------
# Epoch metrics
# ------------------------------------------------------------------

def compute_multilabel_epoch_metrics(y_true, y_scores, label_names,
                                     threshold=0.5):
    """
    Compute standard multi-label classification metrics for an epoch.

    Args:
        y_true: np.ndarray [N, C] binary ground truth
        y_scores: np.ndarray [N, C] predicted probabilities (after sigmoid)
        label_names: list of label strings (length C)
        threshold: cutoff for converting probabilities to binary predictions

    Returns:
        dict of metric name → value
    """
    y_pred = (y_scores >= threshold).astype(int)
    metrics = {}

    # Hamming loss: fraction of labels that are wrong
    try:
        metrics["hamming_loss"] = float(sklearn_hamming_loss(y_true, y_pred))
    except Exception as e:
        logger.warning(f"Failed to compute hamming_loss: {e}")
        metrics["hamming_loss"] = None

    # Subset accuracy: fraction of samples with ALL labels correct
    try:
        exact_match = (y_true == y_pred).all(axis=1).mean()
        metrics["subset_accuracy"] = float(exact_match)
    except Exception as e:
        logger.warning(f"Failed to compute subset_accuracy: {e}")
        metrics["subset_accuracy"] = None

    # Jaccard (sample-averaged intersection-over-union)
    try:
        metrics["jaccard_score"] = float(
            sklearn_jaccard_score(y_true, y_pred, average="samples", zero_division=0)
        )
    except Exception as e:
        logger.warning(f"Failed to compute jaccard_score: {e}")
        metrics["jaccard_score"] = None

    # Macro F1 (average F1 across labels)
    try:
        metrics["macro_f1"] = float(
            f1_score(y_true, y_pred, average="macro", zero_division=0)
        )
    except Exception as e:
        logger.warning(f"Failed to compute macro_f1: {e}")
        metrics["macro_f1"] = None

    # Macro AUC (per-label AUC averaged) — only if there are both 0s and 1s per label
    try:
        per_label_auc = {}
        valid_aucs = []
        for i, name in enumerate(label_names):
            col_true = y_true[:, i]
            if len(np.unique(col_true)) < 2:
                per_label_auc[name] = None  # Can't compute AUC with single class
                continue
            auc = float(roc_auc_score(col_true, y_scores[:, i]))
            per_label_auc[name] = auc
            valid_aucs.append(auc)

        metrics["per_label_auc"] = per_label_auc
        metrics["macro_auc"] = float(np.mean(valid_aucs)) if valid_aucs else None
    except Exception as e:
        logger.warning(f"Failed to compute AUC metrics: {e}")
        metrics["macro_auc"] = None
        metrics["per_label_auc"] = None

    # BCE validation loss (useful for best-epoch tracking)
    try:
        y_scores_clamped = np.clip(y_scores, 1e-7, 1 - 1e-7)
        bce = -(
            y_true * np.log(y_scores_clamped)
            + (1 - y_true) * np.log(1 - y_scores_clamped)
        ).mean()
        metrics["val_bce_loss"] = float(bce)
    except Exception as e:
        logger.warning(f"Failed to compute val_bce_loss: {e}")
        metrics["val_bce_loss"] = None

    return metrics
