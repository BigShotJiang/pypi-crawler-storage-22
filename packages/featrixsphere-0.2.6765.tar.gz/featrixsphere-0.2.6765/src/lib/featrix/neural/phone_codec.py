#  -*- coding: utf-8 -*-
#
#  Copyright Featrix, Inc 2023-2026
#
#  Proprietary and Confidential.  Unauthorized use, copying or dissemination
#  of these materials is strictly prohibited.
"""
Phone Codec and Encoder

Encodes phone numbers by extracting:
- Country code (1 for US/Canada, others)
- Area code (NPA) with geographic embedding based on lat/long
- Exchange code (NXX) - first 3 digits of local number
- Raw digits for exact matching

Key insight: Area codes that are geographically close should have similar embeddings.
E.g., 650 (San Mateo), 408 (San Jose), and 415 (San Francisco) are all Bay Area codes.

Token value is a tensor of floats representing:
- country_code_idx (1): index into country code vocab
- area_code_lat (1): normalized latitude of area code centroid
- area_code_long (1): normalized longitude of area code centroid
- area_code_embedding (32): learned embedding for area code
- exchange_embedding (16): embedding for exchange (NXX)
- digit_features (10): one-hot count of each digit 0-9 in the number
- length_feature (1): normalized phone number length
Total: 62 floats
"""
import logging
import math
import re
import torch
import torch.nn as nn
import torch.nn.functional as F

from typing import Dict, List, Optional, Tuple

from featrix.neural.gpu_utils import get_device
from featrix.neural.featrix_token import Token, TokenStatus
from featrix.neural.model_config import ColumnType, SimpleMLPConfig
from featrix.neural.simple_mlp import SimpleMLP
from featrix.neural.geo_spread import GEO_SPREAD_ENABLED, GEO_SPREAD_DIM, compute_geo_spread, empty_geo_spread_tensor

logger = logging.getLogger(__name__)

# Phone token dimensions
PHONE_AREA_CODE_EMB_DIM = 32
PHONE_EXCHANGE_EMB_DIM = 16
PHONE_DIGIT_FEATURES_DIM = 10
PHONE_EXTENSION_EMB_DIM = 8  # Hash-based embedding for extension
# Token layout:
#   country_code (1) + lat (1) + long (1) + area_code_emb (32) + exchange_emb (16) +
#   digit_dist (10) + length (1) + has_extension (1) + extension_emb (8) = 71
PHONE_TOKEN_DIM = 1 + 1 + 1 + PHONE_AREA_CODE_EMB_DIM + PHONE_EXCHANGE_EMB_DIM + PHONE_DIGIT_FEATURES_DIM + 1 + 1 + PHONE_EXTENSION_EMB_DIM  # = 71

# US/Canada Area Code Geographic Data
# Source: https://github.com/ravisorg/Area-Code-Geolocation-Database
# Format: area_code -> (latitude, longitude, primary_city, state)
# We store just lat/long for distance calculations
AREA_CODE_COORDS: Dict[str, Tuple[float, float]] = {
    # Northeast
    '201': (40.8859, -74.0435),   # Jersey City, NJ
    '202': (38.8951, -77.0364),   # Washington, DC
    '203': (41.1865, -73.1954),   # Bridgeport, CT
    '205': (33.5207, -86.8025),   # Birmingham, AL
    '206': (47.6062, -122.3321),  # Seattle, WA
    '207': (44.3106, -69.7795),   # Maine
    '212': (40.7128, -74.0060),   # New York, NY (Manhattan)
    '215': (39.9526, -75.1652),   # Philadelphia, PA
    '216': (41.4993, -81.6944),   # Cleveland, OH
    '217': (39.7817, -89.6501),   # Springfield, IL
    '219': (41.5934, -87.3467),   # Gary, IN
    '224': (42.0451, -87.6877),   # Chicago suburbs, IL
    '225': (30.4515, -91.1871),   # Baton Rouge, LA
    '228': (30.3674, -89.0928),   # Biloxi, MS
    '229': (31.5785, -84.1557),   # Albany, GA
    '231': (43.6534, -86.4084),   # Muskegon, MI
    '234': (41.0814, -81.5190),   # Akron, OH
    '239': (26.6406, -81.8723),   # Fort Myers, FL
    '240': (39.0458, -77.4875),   # Maryland
    '248': (42.5803, -83.4705),   # Pontiac, MI
    '251': (30.6954, -88.0399),   # Mobile, AL
    '252': (35.9132, -77.7906),   # Greenville, NC
    '253': (47.2529, -122.4443),  # Tacoma, WA
    '254': (31.5493, -97.1467),   # Waco, TX
    '256': (34.7304, -86.5861),   # Huntsville, AL
    '260': (41.0793, -85.1394),   # Fort Wayne, IN
    '262': (42.7261, -87.7829),   # Kenosha, WI
    '267': (40.0094, -75.1333),   # Philadelphia, PA
    '269': (42.2917, -85.5872),   # Kalamazoo, MI
    '270': (36.9685, -86.4808),   # Bowling Green, KY
    '272': (41.4090, -75.6624),   # Scranton, PA
    '276': (36.7298, -81.9773),   # Bristol, VA
    '281': (29.7604, -95.3698),   # Houston, TX
    '301': (39.0458, -77.4875),   # Maryland
    '302': (39.1582, -75.5244),   # Delaware
    '303': (39.7392, -104.9903),  # Denver, CO
    '304': (38.3498, -81.6326),   # West Virginia
    '305': (25.7617, -80.1918),   # Miami, FL
    '307': (43.0760, -107.2903),  # Wyoming
    '308': (40.9264, -98.3420),   # Grand Island, NE
    '309': (40.6936, -89.5890),   # Peoria, IL
    '310': (33.9425, -118.4081),  # Los Angeles, CA (West)
    '312': (41.8781, -87.6298),   # Chicago, IL (Downtown)
    '313': (42.3314, -83.0458),   # Detroit, MI
    '314': (38.6270, -90.1994),   # St. Louis, MO
    '315': (43.0481, -76.1474),   # Syracuse, NY
    '316': (37.6872, -97.3301),   # Wichita, KS
    '317': (39.7684, -86.1581),   # Indianapolis, IN
    '318': (32.5252, -93.7502),   # Shreveport, LA
    '319': (41.6611, -91.5302),   # Cedar Rapids, IA
    '320': (45.5579, -94.1632),   # St. Cloud, MN
    '321': (28.5383, -81.3792),   # Orlando, FL
    '323': (34.0195, -118.4912),  # Los Angeles, CA (Central)
    '325': (32.4487, -99.7331),   # Abilene, TX
    '330': (41.0814, -81.5190),   # Akron, OH
    '331': (41.7508, -88.1535),   # Aurora, IL
    '334': (32.3792, -86.3077),   # Montgomery, AL
    '336': (36.0726, -79.7920),   # Greensboro, NC
    '337': (30.2241, -92.0198),   # Lafayette, LA
    '339': (42.3601, -71.0589),   # Boston, MA
    '340': (18.3358, -64.8963),   # US Virgin Islands
    '346': (29.7604, -95.3698),   # Houston, TX
    '347': (40.6501, -73.9496),   # New York, NY (Brooklyn/Queens)
    '351': (42.5195, -70.8967),   # Beverly, MA
    '352': (29.6516, -82.3248),   # Gainesville, FL
    '360': (47.0379, -122.9007),  # Olympia, WA
    '361': (27.8006, -97.3964),   # Corpus Christi, TX
    '385': (40.7608, -111.8910),  # Salt Lake City, UT
    '386': (29.2108, -81.0228),   # Daytona Beach, FL
    '401': (41.8240, -71.4128),   # Rhode Island
    '402': (41.2565, -95.9345),   # Omaha, NE
    '404': (33.7490, -84.3880),   # Atlanta, GA
    '405': (35.4676, -97.5164),   # Oklahoma City, OK
    '406': (46.8797, -110.3626),  # Montana
    '407': (28.5383, -81.3792),   # Orlando, FL
    '408': (37.3382, -121.8863),  # San Jose, CA
    '409': (29.9511, -93.9927),   # Beaumont, TX
    '410': (39.2904, -76.6122),   # Baltimore, MD
    '412': (40.4406, -79.9959),   # Pittsburgh, PA
    '413': (42.1015, -72.5898),   # Springfield, MA
    '414': (43.0389, -87.9065),   # Milwaukee, WI
    '415': (37.7749, -122.4194),  # San Francisco, CA
    '417': (37.2090, -93.2923),   # Springfield, MO
    '419': (41.6528, -83.5379),   # Toledo, OH
    '423': (35.0456, -85.3097),   # Chattanooga, TN
    '424': (33.9425, -118.4081),  # Los Angeles, CA
    '425': (47.6101, -122.2015),  # Bellevue, WA
    '430': (32.3513, -95.3011),   # Tyler, TX
    '432': (31.9973, -102.0779),  # Midland, TX
    '434': (37.2707, -79.9414),   # Lynchburg, VA
    '435': (40.7608, -111.8910),  # Utah
    '440': (41.4993, -81.6944),   # Cleveland suburbs, OH
    '442': (33.1959, -117.3795),  # Oceanside, CA
    '443': (39.2904, -76.6122),   # Baltimore, MD
    '458': (44.0521, -123.0868),  # Eugene, OR
    '469': (32.7767, -96.7970),   # Dallas, TX
    '470': (33.7490, -84.3880),   # Atlanta, GA
    '475': (41.1865, -73.1954),   # Connecticut
    '478': (32.8407, -83.6324),   # Macon, GA
    '479': (36.0726, -94.1574),   # Fort Smith, AR
    '480': (33.4484, -111.9400),  # Phoenix suburbs, AZ
    '484': (40.0094, -75.1333),   # Philadelphia suburbs, PA
    '501': (34.7465, -92.2896),   # Little Rock, AR
    '502': (38.2527, -85.7585),   # Louisville, KY
    '503': (45.5152, -122.6784),  # Portland, OR
    '504': (29.9511, -90.0715),   # New Orleans, LA
    '505': (35.0844, -106.6504),  # Albuquerque, NM
    '507': (44.0234, -92.4699),   # Rochester, MN
    '508': (42.2626, -71.8023),   # Worcester, MA
    '509': (47.6588, -117.4260),  # Spokane, WA
    '510': (37.8044, -122.2712),  # Oakland, CA
    '512': (30.2672, -97.7431),   # Austin, TX
    '513': (39.1031, -84.5120),   # Cincinnati, OH
    '515': (41.5868, -93.6250),   # Des Moines, IA
    '516': (40.7282, -73.6143),   # Long Island, NY (Nassau)
    '517': (42.7325, -84.5555),   # Lansing, MI
    '518': (42.6526, -73.7562),   # Albany, NY
    '520': (32.2226, -110.9747),  # Tucson, AZ
    '530': (38.5816, -121.4944),  # Sacramento suburbs, CA
    '531': (41.2565, -95.9345),   # Omaha, NE
    '534': (43.0731, -89.4012),   # Madison, WI
    '539': (36.1540, -95.9928),   # Tulsa, OK
    '540': (37.2710, -79.9414),   # Roanoke, VA
    '541': (44.0521, -123.0868),  # Eugene, OR
    '551': (40.7282, -74.0776),   # Jersey City, NJ
    '559': (36.7378, -119.7871),  # Fresno, CA
    '561': (26.7153, -80.0534),   # West Palm Beach, FL
    '562': (33.7701, -118.1937),  # Long Beach, CA
    '563': (41.5236, -90.5776),   # Davenport, IA
    '567': (41.6528, -83.5379),   # Toledo, OH
    '570': (41.4090, -75.6624),   # Scranton, PA
    '571': (38.8816, -77.0910),   # Northern Virginia
    '573': (38.5767, -92.1735),   # Jefferson City, MO
    '574': (41.6764, -86.2520),   # South Bend, IN
    '575': (32.3199, -106.7637),  # Las Cruces, NM
    '580': (34.6036, -98.3959),   # Lawton, OK
    '585': (43.1566, -77.6088),   # Rochester, NY
    '586': (42.4667, -82.9377),   # Warren, MI
    '601': (32.2988, -90.1848),   # Jackson, MS
    '602': (33.4484, -112.0740),  # Phoenix, AZ
    '603': (42.9956, -71.4548),   # New Hampshire
    '605': (43.5460, -96.7313),   # Sioux Falls, SD
    '606': (37.8393, -84.2700),   # Lexington suburbs, KY
    '607': (42.0987, -75.9180),   # Binghamton, NY
    '608': (43.0731, -89.4012),   # Madison, WI
    '609': (40.2171, -74.7429),   # Trenton, NJ
    '610': (40.0094, -75.1333),   # Philadelphia suburbs, PA
    '612': (44.9778, -93.2650),   # Minneapolis, MN
    '614': (39.9612, -82.9988),   # Columbus, OH
    '615': (36.1627, -86.7816),   # Nashville, TN
    '616': (42.9634, -85.6681),   # Grand Rapids, MI
    '617': (42.3601, -71.0589),   # Boston, MA
    '618': (38.6270, -89.9988),   # Belleville, IL
    '619': (32.7157, -117.1611),  # San Diego, CA
    '620': (37.6872, -97.3301),   # Kansas
    '623': (33.4484, -112.0740),  # Phoenix suburbs, AZ
    '626': (34.1478, -118.1445),  # Pasadena, CA
    '627': (38.5816, -121.4944),  # Sacramento, CA
    '628': (37.7749, -122.4194),  # San Francisco, CA
    '629': (36.1627, -86.7816),   # Nashville, TN
    '630': (41.8500, -88.0817),   # Chicago suburbs, IL
    '631': (40.7891, -73.1350),   # Long Island, NY (Suffolk)
    '636': (38.6270, -90.1994),   # St. Louis suburbs, MO
    '641': (41.0534, -92.4077),   # Ottumwa, IA
    '646': (40.7128, -74.0060),   # New York, NY (Manhattan)
    '650': (37.4419, -122.1430),  # San Mateo/Palo Alto, CA
    '651': (44.9537, -93.0900),   # St. Paul, MN
    '657': (33.7455, -117.8677),  # Orange County, CA
    '660': (39.0997, -94.5786),   # Sedalia, MO
    '661': (35.3733, -119.0187),  # Bakersfield, CA
    '662': (34.2576, -88.7034),   # Tupelo, MS
    '667': (39.2904, -76.6122),   # Baltimore, MD
    '669': (37.3382, -121.8863),  # San Jose, CA
    '678': (33.7490, -84.3880),   # Atlanta, GA
    '681': (38.3498, -81.6326),   # West Virginia
    '682': (32.7555, -97.3308),   # Fort Worth, TX
    '689': (28.5383, -81.3792),   # Orlando, FL
    '701': (46.8772, -96.7898),   # North Dakota
    '702': (36.1699, -115.1398),  # Las Vegas, NV
    '703': (38.8816, -77.0910),   # Northern Virginia
    '704': (35.2271, -80.8431),   # Charlotte, NC
    '706': (33.4735, -82.0105),   # Augusta, GA
    '707': (38.2975, -122.2869),  # Santa Rosa, CA
    '708': (41.8500, -87.8500),   # Chicago suburbs, IL
    '712': (42.4919, -96.4003),   # Sioux City, IA
    '713': (29.7604, -95.3698),   # Houston, TX
    '714': (33.7455, -117.8677),  # Orange County, CA
    '715': (44.9591, -89.6301),   # Wausau, WI
    '716': (42.8864, -78.8784),   # Buffalo, NY
    '717': (40.2732, -76.8867),   # Harrisburg, PA
    '718': (40.6501, -73.9496),   # New York, NY (Brooklyn/Queens)
    '719': (38.8339, -104.8214),  # Colorado Springs, CO
    '720': (39.7392, -104.9903),  # Denver, CO
    '724': (40.4406, -79.9959),   # Pittsburgh suburbs, PA
    '725': (36.1699, -115.1398),  # Las Vegas, NV
    '727': (27.7676, -82.6403),   # St. Petersburg, FL
    '731': (35.6145, -88.8139),   # Jackson, TN
    '732': (40.4774, -74.2591),   # New Brunswick, NJ
    '734': (42.2808, -83.7430),   # Ann Arbor, MI
    '737': (30.2672, -97.7431),   # Austin, TX
    '740': (39.9612, -82.9988),   # Columbus suburbs, OH
    '743': (36.0726, -79.7920),   # Greensboro, NC
    '747': (34.1808, -118.3090),  # Los Angeles, CA
    '754': (26.1224, -80.1373),   # Fort Lauderdale, FL
    '757': (36.8508, -76.2859),   # Norfolk, VA
    '760': (33.1959, -117.3795),  # Oceanside, CA
    '762': (33.4735, -82.0105),   # Augusta, GA
    '763': (45.0984, -93.3939),   # Minneapolis suburbs, MN
    '765': (40.1934, -85.3864),   # Muncie, IN
    '769': (32.2988, -90.1848),   # Jackson, MS
    '770': (33.7490, -84.3880),   # Atlanta suburbs, GA
    '772': (27.6648, -80.3431),   # Port St. Lucie, FL
    '773': (41.8781, -87.6298),   # Chicago, IL
    '774': (42.2626, -71.8023),   # Worcester, MA
    '775': (39.5296, -119.8138),  # Reno, NV
    '779': (42.2711, -89.0940),   # Rockford, IL
    '781': (42.3601, -71.0589),   # Boston suburbs, MA
    '785': (39.0473, -95.6752),   # Topeka, KS
    '786': (25.7617, -80.1918),   # Miami, FL
    '787': (18.4655, -66.1057),   # Puerto Rico
    '801': (40.7608, -111.8910),  # Salt Lake City, UT
    '802': (44.2601, -72.5754),   # Vermont
    '803': (34.0007, -81.0348),   # Columbia, SC
    '804': (37.5407, -77.4360),   # Richmond, VA
    '805': (34.4208, -119.6982),  # Santa Barbara, CA
    '806': (35.2220, -101.8313),  # Amarillo, TX
    '808': (21.3069, -157.8583),  # Hawaii
    '810': (42.9706, -83.6875),   # Flint, MI
    '812': (38.3289, -87.5317),   # Evansville, IN
    '813': (27.9506, -82.4572),   # Tampa, FL
    '814': (40.4957, -78.4047),   # Altoona, PA
    '815': (42.2711, -89.0940),   # Rockford, IL
    '816': (39.0997, -94.5786),   # Kansas City, MO
    '817': (32.7555, -97.3308),   # Fort Worth, TX
    '818': (34.1808, -118.3090),  # Los Angeles (San Fernando), CA
    '828': (35.5951, -82.5515),   # Asheville, NC
    '830': (29.5730, -98.2287),   # San Antonio suburbs, TX
    '831': (36.6002, -121.8947),  # Salinas, CA
    '832': (29.7604, -95.3698),   # Houston, TX
    '843': (32.7765, -79.9311),   # Charleston, SC
    '845': (41.5034, -74.0104),   # Poughkeepsie, NY
    '847': (42.0451, -87.6877),   # Chicago suburbs, IL
    '848': (40.4774, -74.2591),   # New Brunswick, NJ
    '850': (30.4213, -87.2169),   # Pensacola, FL
    '856': (39.9490, -75.1180),   # Camden, NJ
    '857': (42.3601, -71.0589),   # Boston, MA
    '858': (32.7157, -117.1611),  # San Diego, CA
    '859': (38.0406, -84.5037),   # Lexington, KY
    '860': (41.7658, -72.6734),   # Hartford, CT
    '862': (40.7357, -74.1724),   # Newark, NJ
    '863': (27.9477, -81.9578),   # Lakeland, FL
    '864': (34.8526, -82.3940),   # Greenville, SC
    '865': (35.9606, -83.9207),   # Knoxville, TN
    '870': (35.8423, -90.7043),   # Jonesboro, AR
    '872': (41.8781, -87.6298),   # Chicago, IL
    '878': (40.4406, -79.9959),   # Pittsburgh, PA
    '901': (35.1495, -90.0490),   # Memphis, TN
    '903': (32.3513, -95.3011),   # Tyler, TX
    '904': (30.3322, -81.6557),   # Jacksonville, FL
    '906': (46.5475, -87.3956),   # Upper Peninsula, MI
    '907': (61.2181, -149.9003),  # Alaska
    '908': (40.4774, -74.2591),   # New Jersey
    '909': (34.0633, -117.6509),  # San Bernardino, CA
    '910': (34.2257, -77.9447),   # Fayetteville, NC
    '912': (32.0809, -81.0912),   # Savannah, GA
    '913': (39.0473, -94.8561),   # Kansas City, KS
    '914': (41.0534, -73.7562),   # Westchester, NY
    '915': (31.7619, -106.4850),  # El Paso, TX
    '916': (38.5816, -121.4944),  # Sacramento, CA
    '917': (40.7128, -74.0060),   # New York, NY
    '918': (36.1540, -95.9928),   # Tulsa, OK
    '919': (35.7796, -78.6382),   # Raleigh, NC
    '920': (44.0190, -88.5426),   # Green Bay, WI
    '925': (37.8044, -122.2712),  # Oakland suburbs, CA
    '928': (35.1983, -111.6513),  # Flagstaff, AZ
    '929': (40.7128, -74.0060),   # New York, NY
    '930': (38.3289, -87.5317),   # Indiana
    '931': (35.7796, -86.3591),   # Murfreesboro, TN
    '936': (30.3038, -95.4561),   # Conroe, TX
    '937': (39.7589, -84.1916),   # Dayton, OH
    '938': (34.7304, -86.5861),   # Huntsville, AL
    '940': (33.9137, -98.4934),   # Wichita Falls, TX
    '941': (27.3364, -82.5307),   # Sarasota, FL
    '947': (42.5803, -83.4705),   # Michigan
    '949': (33.6846, -117.8265),  # Irvine, CA
    '951': (33.9533, -117.3962),  # Riverside, CA
    '952': (44.8608, -93.4691),   # Minneapolis suburbs, MN
    '954': (26.1224, -80.1373),   # Fort Lauderdale, FL
    '956': (26.2034, -98.2300),   # Laredo, TX
    '959': (41.7658, -72.6734),   # Hartford, CT
    '970': (40.5853, -105.0844),  # Fort Collins, CO
    '971': (45.5152, -122.6784),  # Portland, OR
    '972': (32.7767, -96.7970),   # Dallas, TX
    '973': (40.7357, -74.1724),   # Newark, NJ
    '978': (42.6334, -71.3162),   # Lowell, MA
    '979': (30.6280, -96.3344),   # College Station, TX
    '980': (35.2271, -80.8431),   # Charlotte, NC
    '984': (35.7796, -78.6382),   # Raleigh, NC
    '985': (29.9941, -90.2417),   # Houma, LA
    '989': (43.4195, -83.9508),   # Saginaw, MI
}

# Normalization constants for lat/long (US bounds)
LAT_MIN, LAT_MAX = 18.0, 72.0  # From Puerto Rico/Hawaii to Alaska
LONG_MIN, LONG_MAX = -180.0, -65.0  # From Alaska to Maine


def normalize_lat(lat: float) -> float:
    """Normalize latitude to [0, 1] range."""
    return (lat - LAT_MIN) / (LAT_MAX - LAT_MIN)


def normalize_long(lon: float) -> float:
    """Normalize longitude to [0, 1] range."""
    return (lon - LONG_MIN) / (LONG_MAX - LONG_MIN)


def haversine_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """
    Calculate the great circle distance between two points on earth (in km).
    """
    R = 6371  # Earth's radius in kilometers

    lat1_rad = math.radians(lat1)
    lat2_rad = math.radians(lat2)
    delta_lat = math.radians(lat2 - lat1)
    delta_lon = math.radians(lon2 - lon1)

    a = math.sin(delta_lat/2)**2 + math.cos(lat1_rad) * math.cos(lat2_rad) * math.sin(delta_lon/2)**2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))

    return R * c


def parse_phone_number(phone_str: str) -> Dict:
    """
    Parse a phone number string into components.

    ROBUST: This parser never fails - it always returns is_valid=True if there
    are any digits at all. We extract what we can and preserve extensions as
    signal to differentiate rows with same base number but different extensions.

    Returns:
        Dict with keys:
        - country_code: str (e.g., '1' for US/Canada)
        - area_code: str (e.g., '650')
        - exchange: str (e.g., '555')
        - subscriber: str (e.g., '1234')
        - extension: str (e.g., '123' from "x123")
        - digits: str (all digits from main number, excluding extension)
        - all_digits: str (all digits including extension)
        - is_valid: bool (True if we got any digits at all)
    """
    empty_result = {
        'is_valid': False,
        'digits': '',
        'all_digits': '',
        'country_code': '',
        'area_code': '',
        'exchange': '',
        'subscriber': '',
        'extension': '',
    }

    if phone_str is None:
        return empty_result

    # Handle numeric inputs (int/float) - convert cleanly without decimal point
    if isinstance(phone_str, (int, float)):
        if isinstance(phone_str, float):
            # Check for NaN first
            if math.isnan(phone_str):
                return empty_result
            # Check if it's a whole number (e.g., 6505551234.0)
            try:
                if phone_str == int(phone_str):
                    phone_str = str(int(phone_str))
                else:
                    phone_str = str(phone_str)
            except (ValueError, OverflowError):
                phone_str = str(phone_str)
        else:
            phone_str = str(phone_str)
    else:
        phone_str = str(phone_str).strip()

    # Empty string check
    if not phone_str:
        return empty_result

    # Extract extension first (before we strip all formatting)
    # Common patterns: x123, ext123, ext.123, ext 123, extension 123, ,123
    extension = ''
    main_part = phone_str

    # Look for extension patterns (case insensitive)
    ext_patterns = [
        r'[,;]\s*(\d+)\s*$',           # ,123 or ;123 at end
        r'\bx\.?\s*(\d+)\s*$',         # x123, x.123, x 123
        r'\bext\.?\s*(\d+)\s*$',       # ext123, ext.123, ext 123
        r'\bextension\s*(\d+)\s*$',    # extension 123
        r'#\s*(\d+)\s*$',              # #123
    ]

    for pattern in ext_patterns:
        match = re.search(pattern, phone_str, re.IGNORECASE)
        if match:
            extension = match.group(1)
            # Remove extension from main part
            main_part = phone_str[:match.start()].strip()
            break

    # Extract all digits from main part
    digits = re.sub(r'[^\d]', '', main_part)

    # Also keep track of all digits (for digit distribution features)
    all_digits = digits + extension

    result = {
        'is_valid': False,
        'digits': digits,
        'all_digits': all_digits,
        'country_code': '',
        'area_code': '',
        'exchange': '',
        'subscriber': '',
        'extension': extension,
    }

    # If we have no digits at all, still return but invalid
    if len(digits) == 0:
        # But if we have ANY digits in the original, try to use those
        all_original_digits = re.sub(r'[^\d]', '', phone_str)
        if all_original_digits:
            result['digits'] = all_original_digits
            result['all_digits'] = all_original_digits
            result['is_valid'] = True
        return result

    # From here on, we ALWAYS set is_valid=True - we got digits, we'll do our best
    result['is_valid'] = True

    # Handle different formats - extract area code if possible
    if len(digits) == 10:
        # US format without country code: (XXX) XXX-XXXX
        result['country_code'] = '1'
        result['area_code'] = digits[0:3]
        result['exchange'] = digits[3:6]
        result['subscriber'] = digits[6:10]
    elif len(digits) == 11 and digits[0] == '1':
        # US format with country code: 1 (XXX) XXX-XXXX
        result['country_code'] = '1'
        result['area_code'] = digits[1:4]
        result['exchange'] = digits[4:7]
        result['subscriber'] = digits[7:11]
    elif len(digits) == 7:
        # Local format: XXX-XXXX (no area code)
        result['country_code'] = '1'
        result['area_code'] = ''
        result['exchange'] = digits[0:3]
        result['subscriber'] = digits[3:7]
    elif len(digits) > 11:
        # Long number - could be international or has extra digits
        # Try to extract US-style components
        if digits[0] == '1':
            result['country_code'] = '1'
            result['area_code'] = digits[1:4]
            result['exchange'] = digits[4:7]
            result['subscriber'] = digits[7:11]
            # Any remaining digits go to extension if not already set
            if not extension and len(digits) > 11:
                result['extension'] = digits[11:]
        else:
            # Non-US international - extract what we can
            # Try common patterns: +XX XXXXXXXXX
            result['country_code'] = digits[0:2]
            # Attempt to get area-code-like thing (next 2-3 digits)
            if len(digits) >= 5:
                result['area_code'] = digits[2:5]
            if len(digits) >= 8:
                result['exchange'] = digits[5:8]
            if len(digits) >= 12:
                result['subscriber'] = digits[8:12]
    elif len(digits) < 7:
        # Short number - might be partial, vanity remnant, or just garbage
        # Still valid - we have digits, just not enough to parse components
        # Put what we have in a reasonable place
        if len(digits) >= 3:
            result['area_code'] = digits[:3]
            if len(digits) > 3:
                result['exchange'] = digits[3:min(6, len(digits))]

    return result


class PhoneCodec:
    """
    Codec for phone numbers.

    Tokenizes phone numbers into a tensor containing:
    - Geographic features (lat/long of area code)
    - Area code embedding
    - Exchange embedding
    - Digit distribution features
    """

    def __init__(self, df_col, embed_dim: int = 768, string_cache=None, detector=None):
        self.embed_dim = embed_dim
        self.enc_dim = PHONE_TOKEN_DIM  # Token dimension for encoder config
        self.string_cache = string_cache
        self.detector = detector
        self.column_type = ColumnType.PHONE

        # Build area code vocabulary from data + known codes
        self._build_area_code_vocab(df_col)

        # Create NOT_PRESENT and UNKNOWN tokens
        self._not_present_token = self._create_special_token(TokenStatus.NOT_PRESENT)
        self._unknown_token = self._create_special_token(TokenStatus.UNKNOWN)

        logger.info(f"PhoneCodec initialized with {len(self.area_code_to_idx)} area codes")

    def _build_area_code_vocab(self, df_col):
        """Build vocabulary of area codes from data and known codes."""
        self.area_code_to_idx = {}
        self.idx_to_area_code = {}

        # Start with known area codes
        for ac in AREA_CODE_COORDS.keys():
            idx = len(self.area_code_to_idx)
            self.area_code_to_idx[ac] = idx
            self.idx_to_area_code[idx] = ac

        # Add area codes from data that we don't know
        for val in df_col.dropna().unique():
            parsed = parse_phone_number(val)
            if parsed['is_valid'] and parsed['area_code']:
                ac = parsed['area_code']
                if ac not in self.area_code_to_idx:
                    idx = len(self.area_code_to_idx)
                    self.area_code_to_idx[ac] = idx
                    self.idx_to_area_code[idx] = ac

        # Add UNKNOWN area code
        self.unknown_area_code_idx = len(self.area_code_to_idx)
        self.area_code_to_idx['UNKNOWN'] = self.unknown_area_code_idx
        self.idx_to_area_code[self.unknown_area_code_idx] = 'UNKNOWN'

        # Build exchange vocabulary (simpler - just track unique exchanges)
        self.exchange_to_idx = {'UNKNOWN': 0}
        for val in df_col.dropna().unique():
            parsed = parse_phone_number(val)
            if parsed['is_valid'] and parsed['exchange']:
                ex = parsed['exchange']
                if ex not in self.exchange_to_idx:
                    self.exchange_to_idx[ex] = len(self.exchange_to_idx)

        self.unknown_exchange_idx = 0

    def _create_special_token(self, status: TokenStatus) -> Token:
        """Create a special token (NOT_PRESENT or UNKNOWN)."""
        # Zero tensor for special tokens
        value = torch.zeros(PHONE_TOKEN_DIM)
        return Token(value=value, status=status)

    def get_not_present_token(self) -> Token:
        return self._not_present_token

    def get_unknown_token(self) -> Token:
        return self._unknown_token

    def get_codec_name(self):
        return ColumnType.PHONE

    def get_geo_point(self, phone_value) -> Optional[Tuple[float, float]]:
        """
        Get geographic coordinates for a phone number based on area code.

        Args:
            phone_value: Phone number string

        Returns:
            (latitude, longitude) tuple, or None if unknown
        """
        if phone_value is None:
            return None

        parsed = parse_phone_number(phone_value)
        if not parsed['is_valid']:
            return None

        ac = parsed['area_code']
        if ac and ac in AREA_CODE_COORDS:
            return AREA_CODE_COORDS[ac]

        return None

    def get_geo_spread_features(self, phone_value) -> torch.Tensor:
        """
        Get geo spread features for a single phone number.

        For single values, this returns features for one location.
        Returns zero tensor if geo spread is disabled.
        """
        if not GEO_SPREAD_ENABLED:
            return empty_geo_spread_tensor()

        geo_point = self.get_geo_point(phone_value)
        if geo_point is None:
            return empty_geo_spread_tensor()

        lat, lon = geo_point
        features = compute_geo_spread([(lat, lon, 1.0)])
        return features.to_tensor()

    def tokenize(self, phone_value) -> Token:
        """
        Convert a phone number string to a Token.
        """
        if phone_value is None or (isinstance(phone_value, float) and math.isnan(phone_value)):
            return self._not_present_token

        if isinstance(phone_value, str) and phone_value.strip() == '':
            return self._not_present_token

        parsed = parse_phone_number(phone_value)

        if not parsed['is_valid']:
            return self._unknown_token

        # Build feature tensor
        features = []

        # 1. Country code index (1 float) - simple: 1=US/Canada, 0=other
        country_idx = 1.0 if parsed['country_code'] == '1' else 0.0
        features.append(country_idx)

        # 2. Area code lat/long (2 floats)
        ac = parsed['area_code']
        if ac and ac in AREA_CODE_COORDS:
            lat, lon = AREA_CODE_COORDS[ac]
            features.append(normalize_lat(lat))
            features.append(normalize_long(lon))
        else:
            # Unknown area code - use center of continental US
            features.append(normalize_lat(39.8283))
            features.append(normalize_long(-98.5795))

        # 3. Area code embedding (32 floats) - one-hot style but compressed
        ac_idx = self.area_code_to_idx.get(ac, self.unknown_area_code_idx) if ac else self.unknown_area_code_idx
        ac_emb = torch.zeros(PHONE_AREA_CODE_EMB_DIM)
        # Use hash-based embedding for area code
        ac_emb[ac_idx % PHONE_AREA_CODE_EMB_DIM] = 1.0
        if ac_idx >= PHONE_AREA_CODE_EMB_DIM:
            ac_emb[(ac_idx // PHONE_AREA_CODE_EMB_DIM) % PHONE_AREA_CODE_EMB_DIM] = 0.5
        features.extend(ac_emb.tolist())

        # 4. Exchange embedding (16 floats)
        ex = parsed['exchange']
        ex_idx = self.exchange_to_idx.get(ex, self.unknown_exchange_idx) if ex else self.unknown_exchange_idx
        ex_emb = torch.zeros(PHONE_EXCHANGE_EMB_DIM)
        ex_emb[ex_idx % PHONE_EXCHANGE_EMB_DIM] = 1.0
        features.extend(ex_emb.tolist())

        # 5. Digit distribution (10 floats) - count of each digit 0-9
        # Use all_digits to include extension in the digit distribution
        all_digits = parsed.get('all_digits', parsed['digits'])
        digit_counts = torch.zeros(10)
        for d in all_digits:
            if d.isdigit():
                digit_counts[int(d)] += 1
        # Normalize by length
        if len(all_digits) > 0:
            digit_counts = digit_counts / len(all_digits)
        features.extend(digit_counts.tolist())

        # 6. Length feature (1 float) - normalized phone number length
        length_norm = min(len(all_digits) / 15.0, 1.0)  # Normalize to [0, 1]
        features.append(length_norm)

        # 7. Extension features (1 + 8 = 9 floats)
        extension = parsed.get('extension', '')
        has_extension = 1.0 if extension else 0.0
        features.append(has_extension)

        # Extension hash embedding (8 floats) - differentiate different extensions
        ext_emb = torch.zeros(PHONE_EXTENSION_EMB_DIM)
        if extension:
            # Simple hash-based embedding
            ext_hash = hash(extension) % 10000
            ext_emb[ext_hash % PHONE_EXTENSION_EMB_DIM] = 1.0
            if len(extension) > 1:
                ext_emb[(ext_hash // PHONE_EXTENSION_EMB_DIM) % PHONE_EXTENSION_EMB_DIM] = 0.5
            # Also encode length of extension
            ext_len_idx = min(len(extension), PHONE_EXTENSION_EMB_DIM - 1)
            ext_emb[ext_len_idx] = max(ext_emb[ext_len_idx], 0.3)
        features.extend(ext_emb.tolist())

        value = torch.tensor(features, dtype=torch.float32)
        assert value.shape[0] == PHONE_TOKEN_DIM, f"Expected {PHONE_TOKEN_DIM} features, got {value.shape[0]}"

        return Token(value=value, status=TokenStatus.OK)


class PhoneEncoder(nn.Module):
    """
    Encodes phone features using an MLP.

    Input: TokenBatch with tensor values of shape [batch, 71]
    Output: (short_vec, full_vec) embeddings
    """

    def __init__(self, config: SimpleMLPConfig, string_cache=None, column_name: Optional[str] = None):
        super().__init__()
        self.config = config
        self.string_cache = string_cache
        self.column_name = column_name
        self.d_model = config.d_out

        # Project area code lat/long (2 -> 16)
        self.geo_proj = nn.Linear(2, 16, bias=False)
        nn.init.xavier_uniform_(self.geo_proj.weight, gain=1.0)

        # Project area code embedding (32 -> 64)
        self.area_code_proj = nn.Linear(PHONE_AREA_CODE_EMB_DIM, 64, bias=False)
        nn.init.xavier_uniform_(self.area_code_proj.weight, gain=1.0)

        # Project exchange embedding (16 -> 32)
        self.exchange_proj = nn.Linear(PHONE_EXCHANGE_EMB_DIM, 32, bias=False)
        nn.init.xavier_uniform_(self.exchange_proj.weight, gain=0.5)

        # Project digit features (10 -> 16)
        self.digit_proj = nn.Linear(PHONE_DIGIT_FEATURES_DIM, 16, bias=False)
        nn.init.xavier_uniform_(self.digit_proj.weight, gain=0.5)

        # Country code (1 -> 8)
        self.country_proj = nn.Linear(1, 8, bias=False)
        nn.init.xavier_uniform_(self.country_proj.weight, gain=0.5)

        # Length feature (1 -> 8)
        self.length_proj = nn.Linear(1, 8, bias=False)
        nn.init.xavier_uniform_(self.length_proj.weight, gain=0.5)

        # Extension features: has_extension (1) + extension_emb (8) -> 16
        self.extension_proj = nn.Linear(1 + PHONE_EXTENSION_EMB_DIM, 16, bias=False)
        nn.init.xavier_uniform_(self.extension_proj.weight, gain=0.5)

        # Total input dimension to MLP:
        # geo(16) + area_code(64) + exchange(32) + digit(16) + country(8) + length(8) + extension(16) = 160
        mlp_input_dim = 16 + 64 + 32 + 16 + 8 + 8 + 16

        # Final combination MLP
        self.combine_mlp = SimpleMLP(
            SimpleMLPConfig(
                d_in=mlp_input_dim,
                d_out=config.d_out,
                d_hidden=config.d_hidden if hasattr(config, 'd_hidden') else 256,
                n_hidden_layers=2,
                dropout=config.dropout if hasattr(config, 'dropout') else 0.2,
                normalize=config.normalize if hasattr(config, 'normalize') else True,
                residual=True,
                use_batch_norm=config.use_batch_norm if hasattr(config, 'use_batch_norm') else True,
            )
        )

        # Replacement embedding for unknown/not present tokens
        self._replacement_embedding = nn.Parameter(torch.randn(config.d_out))

    @property
    def marginal_embedding(self):
        """Return the marginal embedding (same as replacement for masked/not present)."""
        if self.config.normalize:
            return F.normalize(self._replacement_embedding, dim=-1)
        return self._replacement_embedding

    def forward(self, token_batch):
        """
        Encode phone token batch into embeddings.

        Args:
            token_batch: TokenBatch with value tensor of shape [batch, 62]:
                - [:, 0] country_code_idx
                - [:, 1:3] lat, long
                - [:, 3:35] area_code_embedding
                - [:, 35:51] exchange_embedding
                - [:, 51:61] digit_features
                - [:, 61] length_feature
                - [:, 62] has_extension
                - [:, 63:71] extension_embedding

        Returns:
            (short_vec, full_vec) tuple of embeddings
        """
        values = token_batch.value  # [batch, 71]
        statuses = token_batch.status  # [batch]

        device = values.device
        batch_size = values.shape[0]

        # Ensure correct dtype for BFloat16 compatibility
        target_dtype = next(self.combine_mlp.parameters()).dtype
        values = values.to(dtype=target_dtype)

        # Extract components - offsets based on token layout
        # country(1) + lat(1) + long(1) + ac_emb(32) + ex_emb(16) + digit(10) + len(1) + has_ext(1) + ext_emb(8) = 71
        country_code = values[:, 0:1]  # [batch, 1]
        geo_coords = values[:, 1:3]    # [batch, 2]
        offset = 3
        area_code_emb = values[:, offset:offset+PHONE_AREA_CODE_EMB_DIM]  # [batch, 32]
        offset += PHONE_AREA_CODE_EMB_DIM
        exchange_emb = values[:, offset:offset+PHONE_EXCHANGE_EMB_DIM]  # [batch, 16]
        offset += PHONE_EXCHANGE_EMB_DIM
        digit_features = values[:, offset:offset+PHONE_DIGIT_FEATURES_DIM]  # [batch, 10]
        offset += PHONE_DIGIT_FEATURES_DIM
        length_feature = values[:, offset:offset+1]  # [batch, 1]
        offset += 1
        extension_features = values[:, offset:]  # [batch, 1+8=9] has_extension + extension_emb

        # Project each component
        geo_proj = self.geo_proj(geo_coords)  # [batch, 16]
        ac_proj = self.area_code_proj(area_code_emb)  # [batch, 64]
        ex_proj = self.exchange_proj(exchange_emb)  # [batch, 32]
        digit_proj = self.digit_proj(digit_features)  # [batch, 16]
        country_proj = self.country_proj(country_code)  # [batch, 8]
        length_proj = self.length_proj(length_feature)  # [batch, 8]
        ext_proj = self.extension_proj(extension_features)  # [batch, 16]

        # Concatenate all projections
        combined = torch.cat([geo_proj, ac_proj, ex_proj, digit_proj, country_proj, length_proj, ext_proj], dim=-1)  # [batch, 160]

        # Apply MLP
        full_vec = self.combine_mlp(combined)  # [batch, d_out]

        # Handle NOT_PRESENT and UNKNOWN tokens
        replacement = self._replacement_embedding.to(dtype=target_dtype)
        if self.config.normalize:
            replacement = F.normalize(replacement, dim=-1)

        # Mask for valid tokens
        valid_mask = (statuses == TokenStatus.OK).unsqueeze(-1).to(dtype=target_dtype)  # [batch, 1]

        # Replace invalid tokens with replacement embedding
        full_vec = valid_mask * full_vec + (1 - valid_mask) * replacement.unsqueeze(0)

        # Short vec is just a slice (for 3D visualization)
        short_vec = full_vec[:, :3]

        return short_vec, full_vec


def create_phone_codec(df_col, embed_dim: int = 768, string_cache=None, detector=None) -> PhoneCodec:
    """
    Factory function to create a PhoneCodec.

    Args:
        df_col: pandas Series containing phone number data
        embed_dim: embedding dimension (default 768)
        string_cache: optional string cache (not used currently)
        detector: optional detector instance

    Returns:
        PhoneCodec instance
    """
    return PhoneCodec(df_col, embed_dim=embed_dim, string_cache=string_cache, detector=detector)
