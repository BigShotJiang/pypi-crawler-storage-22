#!/usr/bin/env python
"""
Test that the model learns geographic relationships between phone area codes and zip codes.

The test creates synthetic data where:
- Bay Area customers have Bay Area phones (408, 415, 510, 650) + Bay Area zips (94xxx, 95xxx)
- NYC customers have NYC phones (212, 718, 917, 646) + NYC zips (10xxx, 11xxx)
- LA customers have LA phones (213, 310, 323, 424) + LA zips (90xxx, 91xxx)
- Chicago customers have Chicago phones (312, 773, 872) + Chicago zips (60xxx)

We then test:
1. Do embeddings cluster by region?
2. Given a phone, can we predict the likely zip region?
3. Are "mismatched" phone/zip combos detected as anomalies?
"""
import os
import sys
import random
import math
import pandas as pd
import numpy as np

# Add the source path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', 'lib'))

from featrix.neural.phone_codec import (
    PhoneCodec,
    parse_phone_number,
    AREA_CODE_COORDS,
    haversine_distance,
    normalize_lat,
    normalize_long,
)


# Regional data: area codes, zip prefixes, and central coordinates
REGIONS = {
    'bay_area': {
        'name': 'San Francisco Bay Area',
        'area_codes': ['408', '415', '510', '650', '925', '669'],
        'zip_prefixes': ['940', '941', '943', '944', '945', '946', '947', '948', '949', '950', '951'],
        'center': (37.5, -122.0),  # lat, long
    },
    'nyc': {
        'name': 'New York City',
        'area_codes': ['212', '718', '917', '646', '347', '929'],
        'zip_prefixes': ['100', '101', '102', '103', '104', '110', '111', '112', '113', '114'],
        'center': (40.7, -74.0),
    },
    'la': {
        'name': 'Los Angeles',
        'area_codes': ['213', '310', '323', '424', '562', '626', '818'],
        'zip_prefixes': ['900', '901', '902', '903', '904', '905', '906', '907', '910', '911', '912'],
        'center': (34.0, -118.2),
    },
    'chicago': {
        'name': 'Chicago',
        'area_codes': ['312', '773', '872', '708', '630', '847'],
        'zip_prefixes': ['606', '607', '608', '600', '601', '602', '603', '604', '605'],
        'center': (41.9, -87.6),
    },
    'miami': {
        'name': 'Miami',
        'area_codes': ['305', '786', '954', '754'],
        'zip_prefixes': ['331', '332', '333', '334', '335'],
        'center': (25.8, -80.2),
    },
    'seattle': {
        'name': 'Seattle',
        'area_codes': ['206', '253', '425', '360'],
        'zip_prefixes': ['980', '981', '982', '983', '984'],
        'center': (47.6, -122.3),
    },
}

# US Zip code coordinates (sample - would need full dataset for production)
# Format: zip_prefix -> (lat, long)
ZIP_COORDS = {
    # Bay Area
    '940': (37.65, -122.40), '941': (37.55, -122.30), '943': (37.45, -122.20),
    '944': (37.35, -122.10), '945': (37.50, -122.25), '946': (37.55, -122.05),
    '947': (37.60, -121.90), '948': (37.45, -122.15), '949': (37.40, -122.08),
    '950': (37.30, -121.85), '951': (37.35, -121.90),
    # NYC
    '100': (40.75, -73.99), '101': (40.72, -74.00), '102': (40.78, -73.97),
    '103': (40.80, -73.95), '104': (40.82, -73.92), '110': (40.65, -73.95),
    '111': (40.70, -73.85), '112': (40.68, -73.90), '113': (40.72, -73.80),
    '114': (40.75, -73.75),
    # LA
    '900': (34.05, -118.25), '901': (34.00, -118.30), '902': (33.95, -118.35),
    '903': (33.90, -118.40), '904': (33.98, -118.28), '905': (33.85, -118.32),
    '906': (34.10, -118.20), '907': (34.15, -118.15), '910': (34.08, -118.12),
    '911': (34.12, -118.08), '912': (34.05, -118.05),
    # Chicago
    '606': (41.88, -87.63), '607': (41.92, -87.68), '608': (41.85, -87.70),
    '600': (41.90, -87.65), '601': (41.95, -87.60), '602': (41.80, -87.75),
    '603': (41.82, -87.72), '604': (41.78, -87.78), '605': (41.75, -87.80),
    # Miami
    '331': (25.78, -80.19), '332': (25.82, -80.22), '333': (25.75, -80.25),
    '334': (25.88, -80.15), '335': (25.92, -80.12),
    # Seattle
    '980': (47.60, -122.33), '981': (47.55, -122.38), '982': (47.65, -122.28),
    '983': (47.70, -122.25), '984': (47.50, -122.40),
}


def generate_phone(area_code: str) -> str:
    """Generate a random phone number with the given area code."""
    exchange = random.randint(200, 999)
    subscriber = random.randint(1000, 9999)
    return f"({area_code}) {exchange}-{subscriber}"


def generate_zip(zip_prefix: str) -> str:
    """Generate a random 5-digit zip code with the given prefix."""
    suffix = random.randint(0, 99)
    return f"{zip_prefix}{suffix:02d}"


def generate_dataset(n_samples: int = 1000, mismatch_rate: float = 0.1) -> pd.DataFrame:
    """
    Generate a dataset with phone/zip combinations.

    Args:
        n_samples: Number of samples to generate
        mismatch_rate: Fraction of samples with mismatched phone/zip regions

    Returns:
        DataFrame with columns: customer_id, phone, zip_code, region, is_mismatched
    """
    data = []
    regions = list(REGIONS.keys())

    for i in range(n_samples):
        # Pick a primary region for this customer
        primary_region = random.choice(regions)
        region_data = REGIONS[primary_region]

        # Decide if this is a mismatched sample
        is_mismatched = random.random() < mismatch_rate

        if is_mismatched:
            # Phone from one region, zip from another
            phone_region = primary_region
            zip_region = random.choice([r for r in regions if r != primary_region])
        else:
            # Both from same region
            phone_region = primary_region
            zip_region = primary_region

        # Generate phone and zip
        phone_ac = random.choice(REGIONS[phone_region]['area_codes'])
        zip_prefix = random.choice(REGIONS[zip_region]['zip_prefixes'])

        phone = generate_phone(phone_ac)
        zip_code = generate_zip(zip_prefix)

        # Add some customer attributes
        data.append({
            'customer_id': f"CUST-{i:05d}",
            'phone': phone,
            'zip_code': zip_code,
            'phone_region': phone_region,
            'zip_region': zip_region,
            'is_mismatched': is_mismatched,
        })

    return pd.DataFrame(data)


def compute_geo_distance(phone: str, zip_code: str) -> float:
    """
    Compute the geographic distance between a phone's area code and a zip code.

    Returns distance in km, or -1 if either can't be located.
    """
    parsed = parse_phone_number(phone)
    if not parsed['is_valid'] or not parsed['area_code']:
        return -1

    ac = parsed['area_code']
    zip_prefix = zip_code[:3] if len(zip_code) >= 3 else None

    if ac not in AREA_CODE_COORDS:
        return -1
    if zip_prefix not in ZIP_COORDS:
        return -1

    phone_lat, phone_lon = AREA_CODE_COORDS[ac]
    zip_lat, zip_lon = ZIP_COORDS[zip_prefix]

    return haversine_distance(phone_lat, phone_lon, zip_lat, zip_lon)


def test_phone_codec_basics():
    """Test basic phone codec functionality."""
    print("=" * 60)
    print("TEST 1: Phone Codec Basics")
    print("=" * 60)

    # Generate some test data
    df = generate_dataset(100, mismatch_rate=0.0)

    # Create codec
    codec = PhoneCodec(df['phone'])

    # Test tokenization
    print("\nSample tokenizations:")
    for _, row in df.head(5).iterrows():
        token = codec.tokenize(row['phone'])
        parsed = parse_phone_number(row['phone'])
        print(f"  {row['phone']:18} (AC:{parsed['area_code']}) -> shape={token.value.shape}, status={token.status.name}")

    print("\n✅ Phone codec basics working!")


def test_area_code_proximity():
    """Test that area codes from the same region have similar lat/long."""
    print("\n" + "=" * 60)
    print("TEST 2: Area Code Geographic Proximity")
    print("=" * 60)

    print("\nWithin-region distances (should be small):")
    for region_name, region_data in REGIONS.items():
        acs = [ac for ac in region_data['area_codes'] if ac in AREA_CODE_COORDS]
        if len(acs) < 2:
            continue

        distances = []
        for i, ac1 in enumerate(acs):
            for ac2 in acs[i+1:]:
                lat1, lon1 = AREA_CODE_COORDS[ac1]
                lat2, lon2 = AREA_CODE_COORDS[ac2]
                d = haversine_distance(lat1, lon1, lat2, lon2)
                distances.append(d)

        if distances:
            avg_dist = sum(distances) / len(distances)
            max_dist = max(distances)
            print(f"  {region_name:12}: avg={avg_dist:6.1f} km, max={max_dist:6.1f} km")

    print("\nCross-region distances (should be large):")
    region_pairs = [
        ('bay_area', 'nyc'),
        ('bay_area', 'la'),
        ('nyc', 'chicago'),
        ('miami', 'seattle'),
    ]
    for r1, r2 in region_pairs:
        ac1 = REGIONS[r1]['area_codes'][0]
        ac2 = REGIONS[r2]['area_codes'][0]
        if ac1 in AREA_CODE_COORDS and ac2 in AREA_CODE_COORDS:
            lat1, lon1 = AREA_CODE_COORDS[ac1]
            lat2, lon2 = AREA_CODE_COORDS[ac2]
            d = haversine_distance(lat1, lon1, lat2, lon2)
            print(f"  {r1:12} <-> {r2:12}: {d:6.1f} km")

    print("\n✅ Area code proximity makes geographic sense!")


def test_phone_zip_correlation():
    """Test that we can detect correlated vs mismatched phone/zip combos."""
    print("\n" + "=" * 60)
    print("TEST 3: Phone-Zip Geographic Correlation")
    print("=" * 60)

    # Generate dataset with some mismatches
    df = generate_dataset(500, mismatch_rate=0.2)

    # Compute geo distances
    df['geo_distance_km'] = df.apply(
        lambda row: compute_geo_distance(row['phone'], row['zip_code']),
        axis=1
    )

    # Compare matched vs mismatched
    matched = df[~df['is_mismatched']]['geo_distance_km']
    mismatched = df[df['is_mismatched']]['geo_distance_km']

    # Filter out -1 (unknown locations)
    matched = matched[matched >= 0]
    mismatched = mismatched[mismatched >= 0]

    print(f"\nMatched phone/zip pairs (same region):")
    print(f"  Count: {len(matched)}")
    print(f"  Mean distance: {matched.mean():.1f} km")
    print(f"  Max distance: {matched.max():.1f} km")
    print(f"  Median distance: {matched.median():.1f} km")

    print(f"\nMismatched phone/zip pairs (different regions):")
    print(f"  Count: {len(mismatched)}")
    print(f"  Mean distance: {mismatched.mean():.1f} km")
    print(f"  Min distance: {mismatched.min():.1f} km")
    print(f"  Median distance: {mismatched.median():.1f} km")

    # The key insight: mismatched pairs should have MUCH larger distances
    if len(matched) > 0 and len(mismatched) > 0:
        ratio = mismatched.mean() / matched.mean()
        print(f"\n  Distance ratio (mismatched/matched): {ratio:.1f}x")

        if ratio > 5:
            print("\n✅ Phone-Zip correlation test PASSED!")
            print("   Mismatched pairs are significantly farther apart.")
        else:
            print("\n⚠️  Phone-Zip correlation test needs attention.")
            print("   Expected mismatched pairs to be >5x farther apart.")

    return df


def test_embedding_similarity():
    """Test that phone embeddings from the same region are more similar."""
    print("\n" + "=" * 60)
    print("TEST 4: Phone Embedding Similarity by Region")
    print("=" * 60)

    # Generate phones from different regions
    phones_by_region = {}
    for region_name, region_data in REGIONS.items():
        phones = []
        for ac in region_data['area_codes'][:3]:  # Use first 3 area codes
            if ac in AREA_CODE_COORDS:
                phones.append(generate_phone(ac))
        phones_by_region[region_name] = phones

    # Create codec with all phones
    all_phones = []
    for phones in phones_by_region.values():
        all_phones.extend(phones)

    codec = PhoneCodec(pd.Series(all_phones))

    # Tokenize and extract lat/long features (indices 1 and 2)
    def get_geo_features(phone):
        token = codec.tokenize(phone)
        return token.value[1:3].numpy()  # lat, long

    print("\nWithin-region embedding similarity (lat/long features):")
    for region_name, phones in phones_by_region.items():
        if len(phones) < 2:
            continue

        features = [get_geo_features(p) for p in phones]

        # Compute pairwise Euclidean distances
        distances = []
        for i, f1 in enumerate(features):
            for f2 in features[i+1:]:
                d = np.linalg.norm(f1 - f2)
                distances.append(d)

        if distances:
            avg_dist = sum(distances) / len(distances)
            print(f"  {region_name:12}: avg embedding dist = {avg_dist:.4f}")

    print("\nCross-region embedding distances:")
    for r1, r2 in [('bay_area', 'nyc'), ('la', 'chicago'), ('miami', 'seattle')]:
        if r1 in phones_by_region and r2 in phones_by_region:
            f1 = get_geo_features(phones_by_region[r1][0])
            f2 = get_geo_features(phones_by_region[r2][0])
            d = np.linalg.norm(f1 - f2)
            print(f"  {r1:12} <-> {r2:12}: embedding dist = {d:.4f}")

    print("\n✅ Embedding similarity test complete!")


def save_test_dataset(output_path: str = None):
    """Save a test dataset for training experiments."""
    print("\n" + "=" * 60)
    print("Generating Training Dataset")
    print("=" * 60)

    # Generate larger dataset
    df = generate_dataset(5000, mismatch_rate=0.15)

    # Add computed distance
    df['geo_distance_km'] = df.apply(
        lambda row: compute_geo_distance(row['phone'], row['zip_code']),
        axis=1
    )

    # Add a target variable: is the customer "local" (phone and zip in same region)?
    df['is_local'] = (~df['is_mismatched']).astype(int)

    # Add some noise features
    df['signup_year'] = np.random.choice([2020, 2021, 2022, 2023, 2024], size=len(df))
    df['account_type'] = np.random.choice(['basic', 'premium', 'enterprise'], size=len(df), p=[0.6, 0.3, 0.1])

    if output_path is None:
        output_path = os.path.join(os.path.dirname(__file__), 'phone_zip_test_data.csv')

    # Select columns for output
    output_df = df[['customer_id', 'phone', 'zip_code', 'signup_year', 'account_type', 'is_local']]
    output_df.to_csv(output_path, index=False)

    print(f"\nSaved {len(output_df)} rows to: {output_path}")
    print(f"\nDataset summary:")
    print(f"  Local customers (phone/zip match): {df['is_local'].sum()} ({100*df['is_local'].mean():.1f}%)")
    print(f"  Non-local customers: {(~df['is_local'].astype(bool)).sum()} ({100*(1-df['is_local'].mean()):.1f}%)")
    print(f"\nSample rows:")
    print(output_df.head(10).to_string())

    return output_path


if __name__ == '__main__':
    print("Phone + Zip Geographic Relationship Tests")
    print("=" * 60)

    test_phone_codec_basics()
    test_area_code_proximity()
    test_phone_zip_correlation()
    test_embedding_similarity()

    # Generate and save a test dataset
    dataset_path = save_test_dataset()

    print("\n" + "=" * 60)
    print("All tests complete!")
    print("=" * 60)
    print(f"\nNext steps:")
    print(f"  1. Train an embedding space on: {dataset_path}")
    print(f"  2. Train a predictor to predict 'is_local' from phone + zip")
    print(f"  3. Check if the model learns the geographic relationship")
