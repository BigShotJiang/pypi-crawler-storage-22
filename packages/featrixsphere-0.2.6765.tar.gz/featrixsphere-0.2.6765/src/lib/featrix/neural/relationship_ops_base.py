#  -*- coding: utf-8 -*-
#
#  Copyright Featrix, Inc 2023-2025
#
#  Proprietary and Confidential.  Unauthorized use, copying or dissemination
#  of these materials is strictly prohibited.
#
"""
Base classes and utilities for relationship operations.

This module provides shared components for the various relationship ops modules
(scalar_scalar_ops, string_scalar_ops, set_scalar_ops, etc.) to reduce code
duplication and ensure consistent behavior.

Usage:
    Existing ops classes can inherit from RelationshipOpsMixin to get:
    - Standard MLP creation helpers
    - Safe division with learned epsilon
    - Debug logging utilities
    - Shape validation

    New ops classes can inherit from RelationshipOpsBase for a more structured
    approach with built-in fusion and output normalization.
"""
import logging
from typing import Dict, List, Optional, Tuple, TYPE_CHECKING

import torch
import torch.nn as nn

from featrix.neural.tensor_utils import safe_divide, validate_embedding_shape, validate_batch_match

if TYPE_CHECKING:
    from featrix.neural.type_aware_ops_config import TypeAwareOpsConfig

logger = logging.getLogger(__name__)


def create_feature_mlp(
    input_dim: int,
    output_dim: int,
    hidden_dim: Optional[int] = None,
    dropout: float = 0.1,
) -> nn.Sequential:
    """
    Create a standard 2-layer MLP for feature extraction.

    This is the common pattern used across all relationship ops:
    Linear -> ReLU -> Dropout -> Linear

    Args:
        input_dim: Input dimension (typically n * d_model for n concatenated features)
        output_dim: Output dimension (typically d_model)
        hidden_dim: Hidden layer dimension. If None, uses output_dim.
        dropout: Dropout rate (default 0.1)

    Returns:
        nn.Sequential with the standard MLP architecture
    """
    if hidden_dim is None:
        hidden_dim = output_dim

    return nn.Sequential(
        nn.Linear(input_dim, hidden_dim),
        nn.ReLU(),
        nn.Dropout(dropout),
        nn.Linear(hidden_dim, output_dim),
    )


def create_gating_mlp(d_model: int, dropout: float = 0.1) -> nn.Sequential:
    """
    Create a gating MLP that produces values in [0, 1] range.

    Used for scalar-conditioned gating where one embedding gates another.
    Output should be passed through sigmoid before use.

    Args:
        d_model: Model dimension
        dropout: Dropout rate

    Returns:
        nn.Sequential for gating (apply sigmoid to output)
    """
    return nn.Sequential(
        nn.Linear(d_model, d_model // 2),
        nn.ReLU(),
        nn.Dropout(dropout),
        nn.Linear(d_model // 2, d_model),
    )


def create_fusion_mlp(
    n_features: int,
    d_model: int,
    dropout: float = 0.1,
) -> nn.Sequential:
    """
    Create the standard fusion MLP for combining multiple feature embeddings.

    Args:
        n_features: Number of d_model-sized features being concatenated
        d_model: Model dimension
        dropout: Dropout rate

    Returns:
        nn.Sequential that maps n_features * d_model -> d_model
    """
    return nn.Sequential(
        nn.Linear(n_features * d_model, d_model * 2),
        nn.ReLU(),
        nn.Dropout(dropout),
        nn.Linear(d_model * 2, d_model),
    )


class RelationshipOpsMixin:
    """
    Mixin providing common utilities for relationship ops classes.

    Provides:
    - Safe division with learned epsilon
    - Debug logging helpers
    - Shape validation

    Usage:
        class MyOps(RelationshipOpsMixin, nn.Module):
            def __init__(self, d_model):
                nn.Module.__init__(self)
                self._init_safe_divide()  # Sets up epsilon buffer
                ...

            def forward(self, emb_a, emb_b):
                self._validate_inputs(emb_a, emb_b)
                ratio = self._safe_divide(emb_a, emb_b)
                ...
                self._debug_log(output, "MyOps")
                return output
    """

    def _init_safe_divide(self, epsilon: float = 0.1) -> None:
        """Initialize the epsilon buffer for safe division."""
        self.register_buffer('epsilon', torch.tensor(epsilon))

    def _safe_divide(
        self,
        numerator: torch.Tensor,
        denominator: torch.Tensor,
    ) -> torch.Tensor:
        """
        Safe division with learned epsilon to prevent explosion.

        Uses sign-preserving epsilon: sign(x) * (|x| + eps) ensures
        denominator is always at least eps from zero.

        Args:
            numerator: Dividend tensor
            denominator: Divisor tensor

        Returns:
            numerator / safe_denominator
        """
        return safe_divide(numerator, denominator, self.epsilon.item())

    def _validate_inputs(
        self,
        emb_a: torch.Tensor,
        emb_b: torch.Tensor,
        name_a: str = "emb_a",
        name_b: str = "emb_b",
    ) -> None:
        """
        Validate input embeddings have correct shape.

        Args:
            emb_a: First embedding (batch, d_model)
            emb_b: Second embedding (batch, d_model)
            name_a: Name for error messages
            name_b: Name for error messages

        Raises:
            ValueError: If shapes are invalid
        """
        validate_embedding_shape(emb_a, self.d_model, name_a)
        validate_embedding_shape(emb_b, self.d_model, name_b)
        validate_batch_match(emb_a, emb_b, name_a, name_b)

    def _debug_log(
        self,
        output: torch.Tensor,
        class_name: str,
        feature_norms: Optional[Dict[str, torch.Tensor]] = None,
        max_calls: int = 3,
    ) -> None:
        """
        Log debug information for first few forward passes.

        Args:
            output: The output tensor
            class_name: Name of the ops class for logging
            feature_norms: Optional dict of feature_name -> tensor for norm logging
            max_calls: Maximum number of times to log (default 3)
        """
        if not hasattr(self, '_debug_count'):
            self._debug_count = 0

        self._debug_count += 1
        if self._debug_count <= max_calls:
            with torch.no_grad():
                logger.info(f"🔬 {class_name} forward #{self._debug_count}:")
                logger.info(f"   Output norm: {output.norm(dim=-1).mean():.3f}")
                logger.info(f"   Output variance: {output.var(dim=0).mean().item():.4f}")

                if feature_norms:
                    norm_strs = [f"{k}={v.norm(dim=-1).mean():.3f}" for k, v in feature_norms.items()]
                    logger.info(f"   Feature norms: {', '.join(norm_strs)}")


class RelationshipOpsBase(RelationshipOpsMixin, nn.Module):
    """
    Base class for relationship operations with standard structure.

    Provides the common infrastructure:
    - d_model and config storage
    - Fusion MLP creation
    - Output normalization
    - Safe division utilities

    Subclasses should:
    1. Call super().__init__(d_model, config) in their __init__
    2. Create their feature MLPs
    3. Call self._init_fusion(n_features) after creating feature MLPs
    4. Implement _compute_features() returning a list of feature tensors
    5. Optionally override forward() for custom behavior

    Example:
        class MyOps(RelationshipOpsBase):
            def __init__(self, d_model, config=None):
                super().__init__(d_model, config)

                # Create feature MLPs
                self.feature1_mlp = create_feature_mlp(d_model * 2, d_model)
                self.feature2_mlp = create_gating_mlp(d_model)

                # Initialize fusion (2 features)
                self._init_fusion(2)

            def _compute_features(self, emb_a, emb_b):
                f1 = self.feature1_mlp(torch.cat([emb_a, emb_b], dim=-1))
                gate = torch.sigmoid(self.feature2_mlp(emb_a))
                f2 = emb_b * gate
                return [f1, f2]
    """

    def __init__(
        self,
        d_model: int,
        config: Optional["TypeAwareOpsConfig"] = None,
    ):
        """
        Args:
            d_model: Model dimension
            config: TypeAwareOpsConfig for granular feature control
        """
        nn.Module.__init__(self)
        self.d_model = d_model
        self.config = config
        self._init_safe_divide()

    def _init_fusion(self, n_features: int, dropout: float = 0.1) -> None:
        """
        Initialize the fusion MLP and output normalization.

        Call this after creating all feature MLPs in subclass __init__.

        Args:
            n_features: Number of d_model-sized features that will be fused
            dropout: Dropout rate for fusion MLP
        """
        self.n_features = n_features
        self.fusion_mlp = create_fusion_mlp(n_features, self.d_model, dropout)
        self.output_norm = nn.LayerNorm(self.d_model)

    def _compute_features(
        self,
        emb_a: torch.Tensor,
        emb_b: torch.Tensor,
    ) -> List[torch.Tensor]:
        """
        Compute feature tensors from input embeddings.

        Override in subclasses to compute type-specific features.

        Args:
            emb_a: First embedding (batch, d_model)
            emb_b: Second embedding (batch, d_model)

        Returns:
            List of feature tensors, each (batch, d_model)
        """
        raise NotImplementedError("Subclasses must implement _compute_features")

    def forward(
        self,
        emb_a: torch.Tensor,
        emb_b: torch.Tensor,
    ) -> torch.Tensor:
        """
        Compute relationship embedding from two input embeddings.

        Args:
            emb_a: First embedding (batch, d_model)
            emb_b: Second embedding (batch, d_model)

        Returns:
            Relationship embedding (batch, d_model)
        """
        # Compute all features
        features = self._compute_features(emb_a, emb_b)

        # Concatenate and fuse
        combined = torch.cat(features, dim=-1)
        output = self.output_norm(self.fusion_mlp(combined))

        return output
