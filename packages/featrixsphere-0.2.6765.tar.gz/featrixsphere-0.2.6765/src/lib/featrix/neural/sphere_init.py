#  -*- coding: utf-8 -*-
#
#  Copyright Featrix, Inc 2023-2025
#
#  Proprietary and Confidential.  Unauthorized use, copying or dissemination
#  of these materials is strictly prohibited.
#
"""
Sphere-aware initialization utilities.

This module provides initialization functions for neural network parameters
that can optionally use hypersphere-aware initialization (unit vectors)
based on the SphereConfig settings.

The hypersphere initialization helps with:
- Uniform coverage of the embedding space
- More stable training dynamics
- Better gradient flow for normalized embeddings

Usage:
    from featrix.neural.sphere_init import (
        use_hypersphere_init,
        init_embedding_uniform_sphere,
        init_mlp_for_sphere_coverage,
    )

    # In your encoder __init__:
    self.embedding = nn.Embedding(vocab_size, d_model)
    init_embedding_uniform_sphere(self.embedding)

    self.output_mlp = nn.Sequential(...)
    init_mlp_for_sphere_coverage(self.output_mlp)
"""
import logging

import torch
import torch.nn as nn

logger = logging.getLogger(__name__)


def use_hypersphere_init() -> bool:
    """
    Check sphere_config for use_hypersphere_init flag.

    Returns:
        True if hypersphere initialization should be used, False otherwise.
    """
    from featrix.neural.sphere_config import get_config
    return get_config().use_hypersphere_init()


def init_embedding_uniform_sphere(embedding: nn.Embedding) -> None:
    """
    Initialize embedding weights - hypersphere (unit vectors) or Xavier based on config.

    If use_hypersphere_init=True: random unit vectors for uniform sphere coverage.
    If use_hypersphere_init=False: Xavier uniform (the old/good init).

    Args:
        embedding: The embedding layer to initialize
    """
    if use_hypersphere_init():
        with torch.no_grad():
            embedding.weight.normal_()
            embedding.weight.div_(embedding.weight.norm(dim=1, keepdim=True))
    else:
        # OLD/GOOD: Xavier uniform init
        nn.init.xavier_uniform_(embedding.weight)


def init_mlp_for_sphere_coverage(mlp: nn.Module) -> None:
    """
    Initialize MLP final layer - orthogonal+sphere or skip based on config.

    If use_hypersphere_init=True: orthogonal init + normalize to unit sphere.
    If use_hypersphere_init=False: do nothing (keep default PyTorch init).

    Args:
        mlp: The MLP module to initialize (will find and init last Linear layer)
    """
    if not use_hypersphere_init():
        return  # Skip - use default init

    # Find the last Linear layer
    last_linear = None
    for module in mlp.modules():
        if isinstance(module, nn.Linear):
            last_linear = module

    if last_linear is not None:
        with torch.no_grad():
            # Orthogonal init produces more spread-out outputs
            nn.init.orthogonal_(last_linear.weight)
            # Scale rows to unit norm so outputs land on sphere
            last_linear.weight.div_(last_linear.weight.norm(dim=1, keepdim=True))
            if last_linear.bias is not None:
                nn.init.zeros_(last_linear.bias)


def init_linear_orthogonal_sphere(linear: nn.Linear) -> None:
    """
    Initialize a single Linear layer with orthogonal weights normalized to unit sphere.

    This is useful when you want to initialize a specific layer rather than
    searching through an MLP.

    Args:
        linear: The Linear layer to initialize
    """
    if not use_hypersphere_init():
        return  # Skip - use default init

    with torch.no_grad():
        nn.init.orthogonal_(linear.weight)
        linear.weight.div_(linear.weight.norm(dim=1, keepdim=True))
        if linear.bias is not None:
            nn.init.zeros_(linear.bias)


def init_tensor_uniform_sphere(tensor: torch.Tensor) -> None:
    """
    Initialize a tensor with random unit vectors (in-place).

    Useful for initializing parameter tensors that should lie on the unit sphere.

    Args:
        tensor: The tensor to initialize (modified in-place)
    """
    if not use_hypersphere_init():
        # Fallback to normal initialization
        tensor.normal_()
        return

    with torch.no_grad():
        tensor.normal_()
        # Normalize along last dimension to get unit vectors
        tensor.div_(tensor.norm(dim=-1, keepdim=True))
