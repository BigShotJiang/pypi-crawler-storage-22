#  -*- coding: utf-8 -*-
#
#  Copyright Featrix, Inc 2023-2025
#
#  Proprietary and Confidential.  Unauthorized use, copying or dissemination
#  of these materials is strictly prohibited.
#
"""
Base class for strategy-aware relationship operations.

This module provides shared infrastructure for the strategy-aware ops modules
(strategy_scalar_scalar_ops, strategy_string_scalar_ops, strategy_set_scalar_ops)
to reduce code duplication in the top-K selection and weighted combination logic.

The key insight is that all strategy-aware ops follow the same pattern:
1. Maintain a learned score matrix for strategy pairs
2. Select top-K combinations by score
3. Compute relationships for each combination
4. Return weighted blend of results

Usage:
    class MyStrategyAwareOps(StrategyAwareOpsBase):
        def __init__(self, d_model, n_strats_a, n_strats_b, top_k=4, config=None):
            super().__init__(d_model, n_strats_a, n_strats_b, top_k, config)
            # Create relationship computation MLPs
            self.my_mlp = nn.Sequential(...)

        def _compute_relationship(self, emb_a, emb_b):
            # Compute relationship for a single strategy pair
            return self.my_mlp(torch.cat([emb_a, emb_b], dim=-1))

        def _get_strategy_names(self, idx_a, idx_b):
            # Return human-readable names for debug logging
            return (name_a, name_b)
"""
import logging
from abc import abstractmethod
from typing import List, Optional, Tuple, TYPE_CHECKING

import torch
import torch.nn as nn
import torch.nn.functional as F

if TYPE_CHECKING:
    from featrix.neural.type_aware_ops_config import TypeAwareOpsConfig

logger = logging.getLogger(__name__)


class StrategyAwareOpsBase(nn.Module):
    """
    Base class for strategy-aware relationship operations.

    Provides:
    - Learned score matrix for strategy pairs
    - Learnable temperature for softmax
    - Top-K selection logic
    - Weighted combination of relationship embeddings
    - Debug logging utilities

    Subclasses must implement:
    - _compute_relationship(emb_a, emb_b) -> relationship embedding
    - _get_strategy_names(idx_a, idx_b) -> (name_a, name_b) for debug logging
    """

    def __init__(
        self,
        d_model: int,
        n_strategies_a: int,
        n_strategies_b: int,
        top_k: int = 4,
        config: Optional["TypeAwareOpsConfig"] = None,
        diagonal_bonus: float = 0.0,
    ):
        """
        Args:
            d_model: Model embedding dimension
            n_strategies_a: Number of strategies for first column type
            n_strategies_b: Number of strategies for second column type
            top_k: Number of strategy combinations to evaluate per relationship
            config: TypeAwareOpsConfig for feature control
            diagonal_bonus: Bonus to add to diagonal of score matrix (for symmetric types)
        """
        super().__init__()
        self.d_model = d_model
        self.n_strategies_a = n_strategies_a
        self.n_strategies_b = n_strategies_b
        self.top_k = top_k
        self.config = config

        # Learnable score matrix: score[i,j] = quality of (strategy_i for A, strategy_j for B)
        init_scores = torch.randn(n_strategies_a, n_strategies_b) * 0.1
        if diagonal_bonus > 0 and n_strategies_a == n_strategies_b:
            init_scores += torch.eye(n_strategies_a) * diagonal_bonus
        self.strategy_pair_scores = nn.Parameter(init_scores)

        # Temperature for softmax over top-K scores
        self.score_temperature = nn.Parameter(torch.tensor(1.0))

        # Debug counter
        self._debug_count = 0

    @abstractmethod
    def _compute_relationship(
        self,
        emb_a: torch.Tensor,
        emb_b: torch.Tensor,
    ) -> torch.Tensor:
        """
        Compute relationship embedding for a single strategy combination.

        Args:
            emb_a: Strategy encoding for column A (batch, d_model)
            emb_b: Strategy encoding for column B (batch, d_model)

        Returns:
            Relationship embedding (batch, d_model)
        """
        raise NotImplementedError

    def _get_strategy_names(self, idx_a: int, idx_b: int) -> Tuple[str, str]:
        """
        Get human-readable names for strategy indices (for debug logging).

        Override in subclasses to provide meaningful names.

        Args:
            idx_a: Strategy index for column A
            idx_b: Strategy index for column B

        Returns:
            Tuple of (name_a, name_b)
        """
        return (f"STRAT_A_{idx_a}", f"STRAT_B_{idx_b}")

    def _select_top_k_pairs(
        self,
        scores: torch.Tensor,
        device: torch.device,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Select top-K strategy pairs by score.

        Args:
            scores: Score matrix (n_strategies_a, n_strategies_b)
            device: Device for computations

        Returns:
            Tuple of (topk_indices_a, topk_indices_b, weights)
            - topk_indices_a: Strategy indices for column A (top_k,)
            - topk_indices_b: Strategy indices for column B (top_k,)
            - weights: Softmax weights for each pair (top_k,)
        """
        flat_scores = scores.view(-1)
        topk_values, topk_indices = torch.topk(
            flat_scores, min(self.top_k, flat_scores.numel())
        )

        # Convert flat indices to (i, j) pairs
        topk_indices_a = topk_indices // self.n_strategies_b
        topk_indices_b = topk_indices % self.n_strategies_b

        # Compute softmax weights over top-K scores
        temperature = self.score_temperature.clamp(min=0.1)
        weights = F.softmax(topk_values / temperature, dim=0)

        return topk_indices_a, topk_indices_b, weights

    def _apply_masks(
        self,
        scores: torch.Tensor,
        mask_a: Optional[torch.Tensor],
        mask_b: Optional[torch.Tensor],
        device: torch.device,
    ) -> torch.Tensor:
        """
        Apply strategy masks to score matrix.

        Args:
            scores: Score matrix (n_strategies_a, n_strategies_b)
            mask_a: Optional mask for strategies A (n_strategies_a,)
            mask_b: Optional mask for strategies B (n_strategies_b,)
            device: Device for computations

        Returns:
            Masked score matrix
        """
        if mask_a is not None:
            scores = scores * mask_a.unsqueeze(1).to(device)
        if mask_b is not None:
            scores = scores * mask_b.unsqueeze(0).to(device)
        return scores

    def forward(
        self,
        strategy_encodings_a: torch.Tensor,  # (batch, n_strategies_a, d_model)
        strategy_encodings_b: torch.Tensor,  # (batch, n_strategies_b, d_model)
        strategy_mask_a: Optional[torch.Tensor] = None,
        strategy_mask_b: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """
        Compute strategy-aware relationship embedding.

        Args:
            strategy_encodings_a: All strategy encodings for column A
            strategy_encodings_b: All strategy encodings for column B
            strategy_mask_a: Optional mask of active strategies for A
            strategy_mask_b: Optional mask of active strategies for B

        Returns:
            Relationship embedding of shape (batch, d_model)
        """
        batch_size = strategy_encodings_a.shape[0]
        device = strategy_encodings_a.device

        # Apply strategy masks if provided
        scores = self.strategy_pair_scores.clone()
        scores = self._apply_masks(scores, strategy_mask_a, strategy_mask_b, device)

        # Select top-K strategy combinations
        topk_indices_a, topk_indices_b, weights = self._select_top_k_pairs(scores, device)

        # Compute relationship for each top-K combination and accumulate
        output = torch.zeros(batch_size, self.d_model, device=device)

        for k in range(len(topk_indices_a)):
            idx_a = topk_indices_a[k].item()
            idx_b = topk_indices_b[k].item()

            # Get strategy encodings
            emb_a = strategy_encodings_a[:, idx_a, :]
            emb_b = strategy_encodings_b[:, idx_b, :]

            # Compute relationship
            rel_emb = self._compute_relationship(emb_a, emb_b)

            # Accumulate weighted contribution
            output = output + weights[k] * rel_emb

        # Debug logging (first few calls)
        self._debug_log(output, weights)

        return output

    def _debug_log(
        self,
        output: torch.Tensor,
        weights: torch.Tensor,
        max_calls: int = 3,
    ) -> None:
        """Log debug information for first few forward passes."""
        self._debug_count += 1
        if self._debug_count <= max_calls:
            with torch.no_grad():
                top_pairs = self.get_top_strategy_pairs(3)
                pairs_str = ", ".join([f"{a}×{b}={s:.2f}" for a, b, s in top_pairs])
                class_name = self.__class__.__name__
                logger.info(f"🔬 {class_name} forward #{self._debug_count}:")
                logger.info(f"   Top strategy pairs: {pairs_str}")
                logger.info(f"   Temperature: {self.score_temperature.clamp(min=0.1).item():.3f}")
                logger.info(f"   Output norm: {output.norm(dim=-1).mean():.3f}")

    def get_top_strategy_pairs(self, k: int = 10) -> List[Tuple[str, str, float]]:
        """
        Return top-K strategy combinations by learned score.

        Args:
            k: Number of top pairs to return

        Returns:
            List of (name_a, name_b, score) tuples
        """
        with torch.no_grad():
            scores = self.strategy_pair_scores.cpu()
            flat = scores.view(-1)
            topk_vals, topk_idx = torch.topk(flat, min(k, flat.numel()))

            results = []
            for val, idx in zip(topk_vals, topk_idx):
                i = idx.item() // self.n_strategies_b
                j = idx.item() % self.n_strategies_b
                name_a, name_b = self._get_strategy_names(i, j)
                results.append((name_a, name_b, val.item()))
            return results
