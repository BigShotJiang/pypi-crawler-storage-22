#  -*- coding: utf-8 -*-
#
#  Copyright Featrix, Inc 2023-2025
#
#  Proprietary and Confidential.  Unauthorized use, copying or dissemination
#  of these materials is strictly prohibited.
#
"""
Shared tensor utilities for the neural encoding system.

This module provides common tensor operations used across multiple modules,
including device safety checks, safe division, and shape validation.
"""
import logging
from typing import Optional, Tuple, Union

import torch
import torch.nn as nn

logger = logging.getLogger(__name__)


def ensure_same_device(
    reference: torch.Tensor,
    tensor: torch.Tensor,
    name: str = "tensor",
) -> torch.Tensor:
    """
    Move tensor to match reference tensor's device if needed.

    Args:
        reference: The tensor whose device should be matched
        tensor: The tensor to potentially move
        name: Name of tensor for error messages

    Returns:
        tensor on the same device as reference

    Raises:
        TypeError: If either argument is not a tensor
    """
    if not isinstance(reference, torch.Tensor):
        raise TypeError(f"reference must be a tensor, got {type(reference)}")
    if not isinstance(tensor, torch.Tensor):
        raise TypeError(f"{name} must be a tensor, got {type(tensor)}")

    if reference.device != tensor.device:
        return tensor.to(reference.device)
    return tensor


def ensure_device(tensor: torch.Tensor, device: torch.device) -> torch.Tensor:
    """
    Move tensor to specified device if needed.

    Args:
        tensor: The tensor to potentially move
        device: Target device

    Returns:
        tensor on the specified device
    """
    if tensor.device != device:
        return tensor.to(device)
    return tensor


def safe_divide(
    numerator: torch.Tensor,
    denominator: torch.Tensor,
    epsilon: float = 1e-8,
) -> torch.Tensor:
    """
    Safe division with sign-preserving epsilon to prevent explosion.

    Uses sign-preserving epsilon: sign(x) * (|x| + eps) ensures
    denominator is always at least eps from zero while preserving
    the original sign.

    Args:
        numerator: Dividend tensor
        denominator: Divisor tensor
        epsilon: Small value to prevent division by zero

    Returns:
        numerator / safe_denominator
    """
    sign = torch.sign(denominator)
    sign = torch.where(sign == 0, torch.ones_like(sign), sign)
    safe_denom = sign * (torch.abs(denominator) + epsilon)
    return numerator / safe_denom


def validate_embedding_shape(
    tensor: torch.Tensor,
    expected_dim: int,
    name: str = "embedding",
) -> None:
    """
    Validate that a tensor has the expected embedding dimension.

    Args:
        tensor: The tensor to validate (expected shape: batch, d_model)
        expected_dim: The expected d_model dimension
        name: Name of tensor for error messages

    Raises:
        ValueError: If tensor shape doesn't match expectations
    """
    if tensor.dim() != 2:
        raise ValueError(f"{name} must be 2D (batch, d_model), got shape {tensor.shape}")
    if tensor.shape[1] != expected_dim:
        raise ValueError(
            f"{name} has wrong dimension: {tensor.shape[1]} vs expected {expected_dim}"
        )


def validate_batch_match(
    tensor_a: torch.Tensor,
    tensor_b: torch.Tensor,
    name_a: str = "tensor_a",
    name_b: str = "tensor_b",
) -> None:
    """
    Validate that two tensors have matching batch dimensions.

    Args:
        tensor_a: First tensor
        tensor_b: Second tensor
        name_a: Name of first tensor for error messages
        name_b: Name of second tensor for error messages

    Raises:
        ValueError: If batch dimensions don't match
    """
    if tensor_a.shape[0] != tensor_b.shape[0]:
        raise ValueError(
            f"Batch size mismatch: {name_a}={tensor_a.shape[0]} vs {name_b}={tensor_b.shape[0]}"
        )


class SafeDivide(nn.Module):
    """
    Module wrapper for safe division with learnable epsilon.

    Useful for relationship operations that need safe division
    with a learnable epsilon parameter.
    """

    def __init__(self, init_epsilon: float = 1e-8):
        """
        Args:
            init_epsilon: Initial epsilon value (will be softplus'd for positivity)
        """
        super().__init__()
        # Store raw value that will be softplus'd to ensure positivity
        self._raw_epsilon = nn.Parameter(
            torch.tensor(init_epsilon).log()  # inverse softplus approximation
        )

    @property
    def epsilon(self) -> torch.Tensor:
        """Get the positive epsilon value."""
        return nn.functional.softplus(self._raw_epsilon)

    def forward(
        self,
        numerator: torch.Tensor,
        denominator: torch.Tensor,
    ) -> torch.Tensor:
        """
        Perform safe division.

        Args:
            numerator: Dividend tensor
            denominator: Divisor tensor

        Returns:
            numerator / safe_denominator
        """
        return safe_divide(numerator, denominator, self.epsilon.item())
