#  -*- coding: utf-8 -*-
#
#  Copyright Featrix, Inc 2023-2026
#
#  Proprietary and Confidential.  Unauthorized use, copying or dissemination
#  of these materials is strictly prohibited.
"""
Year JSON Codec

Encodes JSON columns containing year keys with numeric values, like:
- {"2020": 100, "2021": 200, "2022": 300}
- {"2019": 50, "2020": 75, "2021": 100}

The key insight is that these columns represent time-series data, and we want to capture:
1. Temporal span (how many years of data)
2. Trend direction (increasing, decreasing, stable)
3. Recency (most recent year's value)
4. Growth rate

Usage:
    from featrix.neural.year_json_codec import YearJsonCodec

    codec = YearJsonCodec(df['sales_by_year'])
    token = codec.tokenize('{"2020": 100, "2021": 200, "2022": 300}')
"""

import ast
import json
import logging
import math
import torch
import torch.nn as nn
import numpy as np
from typing import Dict, List, Optional, Tuple, Any

from featrix.neural.featrix_token import Token, TokenStatus
from featrix.neural.model_config import ColumnType

logger = logging.getLogger(__name__)

# Token dimension for year JSON codec
# Features: year_min, year_max, year_span, num_years, trend_slope, trend_r2,
#           total_value_log, avg_value_log, most_recent_value_log, growth_rate,
#           valid_flag, recency_score
YEAR_JSON_TOKEN_DIM = 12

# Valid year range
MIN_YEAR = 1900
MAX_YEAR = 2100


def _safe_parse_json_dict(value: Any) -> Optional[Dict]:
    """Safely parse a JSON-like dict string."""
    if value is None:
        return None

    if isinstance(value, dict):
        return value

    if not isinstance(value, str):
        return None

    value = value.strip()
    if not (value.startswith('{') and value.endswith('}')):
        return None

    # Try standard JSON parsing
    try:
        parsed = json.loads(value)
        if isinstance(parsed, dict):
            return parsed
    except (json.JSONDecodeError, TypeError):
        pass

    # Try ast.literal_eval for Python dict literals
    try:
        parsed = ast.literal_eval(value)
        if isinstance(parsed, dict):
            return parsed
    except (ValueError, SyntaxError):
        pass

    return None


def _is_year(key: str) -> bool:
    """Check if a key looks like a year."""
    import re

    key_str = str(key).strip()
    if not re.match(r'^\d{4}$', key_str):
        return False

    year = int(key_str)
    return MIN_YEAR <= year <= MAX_YEAR


def _compute_trend(years: List[int], values: List[float]) -> Tuple[float, float]:
    """
    Compute linear trend (slope and R²) for year-value pairs.

    Returns:
        (slope, r_squared) where:
        - slope: normalized slope (change per year, scaled by mean value)
        - r_squared: coefficient of determination (0-1, how linear the trend is)
    """
    if len(years) < 2:
        return 0.0, 0.0

    n = len(years)
    years_arr = np.array(years, dtype=float)
    values_arr = np.array(values, dtype=float)

    # Compute linear regression
    mean_x = np.mean(years_arr)
    mean_y = np.mean(values_arr)

    # Avoid division by zero
    if mean_y == 0:
        mean_y = 1.0

    # Compute slope using least squares
    numerator = np.sum((years_arr - mean_x) * (values_arr - mean_y))
    denominator = np.sum((years_arr - mean_x) ** 2)

    if denominator == 0:
        return 0.0, 0.0

    slope = numerator / denominator

    # Normalize slope by mean value (so it's a percentage change)
    normalized_slope = slope / abs(mean_y) if mean_y != 0 else 0.0

    # Compute R²
    y_pred = slope * (years_arr - mean_x) + mean_y
    ss_res = np.sum((values_arr - y_pred) ** 2)
    ss_tot = np.sum((values_arr - mean_y) ** 2)

    if ss_tot == 0:
        r_squared = 1.0  # Perfect fit (constant values)
    else:
        r_squared = 1 - (ss_res / ss_tot)

    return float(normalized_slope), float(max(0, r_squared))


class YearJsonCodec(nn.Module):
    """
    Codec for JSON columns containing year keys with numeric values.

    Tokenizes JSON dicts like {"2020": 100, "2021": 200} into temporal features:
    - Year range and span
    - Trend direction and strength
    - Total/average/recent values
    - Growth rate
    """

    def __init__(self, df_col=None, enc_dim: int = 768, debugName=None,
                 initial_values=None, detector=None):
        """
        Initialize the YearJsonCodec.

        Args:
            df_col: pandas Series containing JSON strings (optional)
            enc_dim: embedding dimension
            debugName: column name for debugging
            initial_values: optional list of values to pre-process
            detector: optional detector instance
        """
        super().__init__()

        self.enc_dim = enc_dim
        self.colName = debugName
        self.debug_name = "%50s" % str(debugName) if debugName else "year_json"
        self.detector = detector
        self._is_decodable = False

        # Current year for recency calculations
        from datetime import datetime
        self.current_year = datetime.now().year

        # Create special tokens
        self._not_present_token = self._create_special_token(TokenStatus.NOT_PRESENT)
        self._unknown_token = self._create_special_token(TokenStatus.UNKNOWN)

        # Projection layer: [YEAR_JSON_TOKEN_DIM] → [enc_dim]
        self.projection = nn.Sequential(
            nn.Linear(YEAR_JSON_TOKEN_DIM, enc_dim),
            nn.ReLU(),
            nn.Dropout(0.1),
        )

        # Initialize weights
        for name, param in self.projection.named_parameters():
            if 'weight' in name and param.ndim >= 2:
                nn.init.xavier_uniform_(param, gain=0.5)
            elif 'bias' in name:
                nn.init.zeros_(param)

        logger.info(f"🗓️ YearJsonCodec '{debugName}': YEAR_JSON_TOKEN_DIM={YEAR_JSON_TOKEN_DIM} → enc_dim={enc_dim}")

    def _create_special_token(self, status: TokenStatus) -> Token:
        """Create a special token (NOT_PRESENT or UNKNOWN)."""
        value = torch.zeros(YEAR_JSON_TOKEN_DIM, dtype=torch.float32)
        return Token(value=value, status=status)

    def get_not_present_token(self) -> Token:
        return self._not_present_token

    def get_unknown_token(self) -> Token:
        return self._unknown_token

    def get_marginal_token(self) -> Token:
        """Return a token representing a masked/marginal value."""
        return Token(
            value=torch.zeros(YEAR_JSON_TOKEN_DIM, dtype=torch.float32),
            status=TokenStatus.MARGINAL,
        )

    def get_codec_name(self):
        return ColumnType.YEAR_JSON

    @property
    def token_dtype(self):
        return float

    def get_raw_value_stats(self, value: Any) -> Dict[str, float]:
        """
        Extract raw value statistics for relationship ops.

        Returns dict with:
        - total: sum of all values
        - avg: average value
        - min_val: minimum value
        - max_val: maximum value
        - most_recent: value for most recent year
        - oldest: value for oldest year
        - growth_rate: (most_recent - oldest) / oldest
        - trend_slope: normalized slope of linear trend
        - trend_r2: R² of linear trend
        - year_min: earliest year
        - year_max: latest year
        - year_span: number of years covered
        - num_years: count of year entries
        """
        year_values = self._parse_year_values(value)

        if year_values is None or len(year_values) == 0:
            return {
                'total': 0.0, 'avg': 0.0, 'min_val': 0.0, 'max_val': 0.0,
                'most_recent': 0.0, 'oldest': 0.0, 'growth_rate': 0.0,
                'trend_slope': 0.0, 'trend_r2': 0.0,
                'year_min': 0, 'year_max': 0, 'year_span': 0, 'num_years': 0,
                'valid': False
            }

        # year_values is guaranteed to be a non-empty dict here
        yv: Dict[int, float] = year_values  # type: ignore[assignment]
        years = sorted(yv.keys())
        values = [yv[y] for y in years]  # pylint: disable=unsubscriptable-object

        total = sum(values)
        avg = total / len(values)
        trend_slope, trend_r2 = _compute_trend(years, values)

        # Growth rate
        if len(values) >= 2 and values[0] != 0:
            growth_rate = (values[-1] - values[0]) / abs(values[0])
        else:
            growth_rate = 0.0

        return {
            'total': total,
            'avg': avg,
            'min_val': min(values),
            'max_val': max(values),
            'most_recent': values[-1],
            'oldest': values[0],
            'growth_rate': growth_rate,
            'trend_slope': trend_slope,
            'trend_r2': trend_r2,
            'year_min': min(years),
            'year_max': max(years),
            'year_span': max(years) - min(years),
            'num_years': len(years),
            'valid': True
        }

    def get_year_range(self, value: Any) -> Optional[Tuple[int, int]]:
        """Get (min_year, max_year) tuple for timestamp comparison."""
        year_values = self._parse_year_values(value)
        if year_values is None or len(year_values) == 0:
            return None
        years = list(year_values.keys())
        return (min(years), max(years))

    def get_value_for_year(self, value: Any, year: int) -> Optional[float]:
        """Get the value for a specific year, or None if not present."""
        year_values = self._parse_year_values(value)
        if year_values is None or len(year_values) == 0:
            return None
        return year_values.get(year)

    def _parse_year_values(self, value: Any) -> Optional[Dict[int, float]]:
        """
        Parse a JSON value into year->value dict.

        Returns:
            Dict mapping year (int) to value (float), or None if invalid
        """
        parsed = _safe_parse_json_dict(value)
        if not parsed:
            return None

        year_values = {}
        for key, val in parsed.items():
            if not _is_year(str(key)):
                continue

            year = int(str(key).strip())

            # Convert value to float
            try:
                val_float = float(val)
                year_values[year] = val_float
            except (ValueError, TypeError):
                continue

        return year_values if year_values else None

    def compute_features(self, value: Any) -> torch.Tensor:
        """
        Compute temporal features for a year-keyed JSON value.

        Args:
            value: JSON string or dict with year->value mapping

        Returns:
            Tensor of temporal features
        """
        year_values = self._parse_year_values(value)

        if not year_values:
            return torch.zeros(YEAR_JSON_TOKEN_DIM, dtype=torch.float32)

        # year_values is guaranteed to be a non-empty dict here
        yv: Dict[int, float] = year_values  # type: ignore[assignment]
        years = sorted(yv.keys())
        values = [yv[y] for y in years]  # pylint: disable=unsubscriptable-object

        # Basic year stats
        year_min = min(years)
        year_max = max(years)
        year_span = year_max - year_min
        num_years = len(years)

        # Compute trend
        trend_slope, trend_r2 = _compute_trend(years, values)

        # Value stats (log-scaled for stability)
        total_value = sum(values)
        avg_value = total_value / num_years if num_years > 0 else 0
        most_recent_value = values[-1]  # Last year's value

        # Growth rate (from first to last year)
        if len(values) >= 2 and values[0] != 0:
            growth_rate = (values[-1] - values[0]) / abs(values[0])
        else:
            growth_rate = 0.0

        # Recency score (how recent is the most recent year)
        recency_score = max(0, 1 - (self.current_year - year_max) / 10.0)

        # Build feature vector (all normalized to reasonable ranges)
        features = torch.tensor([
            (year_min - 2000) / 50.0,  # Normalized year_min (around 2000)
            (year_max - 2000) / 50.0,  # Normalized year_max
            min(year_span / 20.0, 1.0),  # Year span (capped at 20 years)
            min(num_years / 10.0, 1.0),  # Number of years (capped at 10)
            np.tanh(trend_slope),  # Trend slope (tanh to bound it)
            trend_r2,  # R² (already 0-1)
            min(math.log(total_value + 1) / 20.0, 1.0),  # Log total value
            min(math.log(avg_value + 1) / 15.0, 1.0),  # Log average value
            min(math.log(most_recent_value + 1) / 15.0, 1.0),  # Log recent value
            np.tanh(growth_rate),  # Growth rate (bounded)
            1.0,  # Valid flag
            recency_score,  # How recent the data is
        ], dtype=torch.float32)

        return features

    def tokenize(self, value: Any) -> Token:
        """
        Convert a JSON value to a Token.

        Args:
            value: JSON string or dict with year->value mapping

        Returns:
            Token with temporal features
        """
        # Handle NaN/None
        if value is None:
            return self._not_present_token

        if isinstance(value, (float, int, np.float64, np.float32)):
            if math.isnan(value):
                return self._not_present_token

        if isinstance(value, str) and value.strip() in ('', 'nan', 'NaN', 'null', 'None'):
            return self._not_present_token

        # Parse and compute features
        features = self.compute_features(value)

        # Check if valid (valid_flag > 0)
        if features[-2] == 0:  # valid_flag
            return self._unknown_token

        return Token(value=features, status=TokenStatus.OK)

    def encode(self, token_batch):
        """
        Encode a batch of tokens.
        Tokenize() returns raw features; we project them here on the correct device.
        """
        if isinstance(token_batch, dict):
            values = [token.value for token in token_batch.values()]
            if len(values) == 0:
                device = next(self.projection.parameters()).device
                return torch.zeros(0, self.enc_dim, dtype=torch.float32, device=device)
            embeddings = torch.stack(values)
        elif isinstance(token_batch, list):
            values = [token.value for token in token_batch]
            if len(values) == 0:
                device = next(self.projection.parameters()).device
                return torch.zeros(0, self.enc_dim, dtype=torch.float32, device=device)
            embeddings = torch.stack(values)
        else:
            # Single token
            embeddings = token_batch.value.unsqueeze(0)

        # Move to projection layer's device and project
        device = next(self.projection.parameters()).device
        embeddings = embeddings.to(device)
        return self.projection(embeddings)


class YearJsonEncoder(nn.Module):
    """
    Encoder for year JSON and geo JSON columns.
    Tokenize() produces raw features; this encoder projects them to d_model.

    Works for any codec that produces fixed-dimension token features:
    - YearJsonCodec (YEAR_JSON_TOKEN_DIM = 12 features)
    - GeoJsonCodec (GEO_JSON_TOKEN_DIM = 14 features)
    """

    def __init__(self, config, codec):
        super().__init__()
        self.config = config
        self.codec = codec
        self.d_model = config.d_out

        # Projection from raw features to d_model
        # Uses config.d_in for input dimension
        d_in = config.d_in
        d_hidden = config.d_hidden if hasattr(config, 'd_hidden') and config.d_hidden else 64
        dropout = config.dropout if hasattr(config, 'dropout') else 0.2

        self.projection = nn.Sequential(
            nn.Linear(d_in, d_hidden),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(d_hidden, config.d_out),
        )

        # Initialize weights
        for name, param in self.projection.named_parameters():
            if 'weight' in name and param.ndim >= 2:
                nn.init.xavier_uniform_(param, gain=0.5)
            elif 'bias' in name:
                nn.init.zeros_(param)

    def forward(self, token_batch):
        """
        Forward pass: extract features from tokens and project to d_model.

        Args:
            token_batch: Batch of tokens (dict, list, or single token)

        Returns:
            short_vec: 3D embedding for visualization
            full_vec: Full embedding for training (d_model dimensions)
        """
        if isinstance(token_batch, dict):
            values = [token.value for token in token_batch.values()]
            batch_size = len(values)
            if batch_size > 0:
                embeddings = torch.stack(values)
        elif isinstance(token_batch, list):
            values = [token.value for token in token_batch]
            batch_size = len(values)
            if batch_size > 0:
                embeddings = torch.stack(values)
        else:
            batch_size = 1
            embeddings = token_batch.value.unsqueeze(0)

        if batch_size == 0:
            device = next(self.projection.parameters()).device
            zero_embedding = torch.zeros(0, self.d_model, dtype=torch.float32, device=device)
            return zero_embedding[:, 0:3], zero_embedding

        # Ensure embeddings are the right shape
        if len(embeddings.shape) == 1:
            embeddings = embeddings.unsqueeze(0)

        # Move to projection layer's device
        device = next(self.projection.parameters()).device
        embeddings = embeddings.to(device)

        # Project to d_model
        full_vec = self.projection(embeddings)

        # Short vec is first 3 dimensions of full vec
        short_vec = full_vec[:, 0:3]

        return short_vec, full_vec


# Quick test
if __name__ == '__main__':
    import pandas as pd

    # Test year JSON data
    test_data = [
        '{"2020": 100, "2021": 200, "2022": 300}',  # Increasing trend
        '{"2020": 300, "2021": 200, "2022": 100}',  # Decreasing trend
        '{"2019": 50, "2020": 50, "2021": 50}',  # Flat trend
        '{"2015": 10, "2020": 100, "2025": 1000}',  # Exponential growth
        '{"2022": 500}',  # Single year
        '',
        None,
    ]
    df = pd.Series(test_data)

    print("\nYear JSON Codec Test")
    print("=" * 70)

    codec = YearJsonCodec(df, debugName="test_sales_by_year")

    for val in test_data:
        token = codec.tokenize(val)
        if token.status == TokenStatus.OK:
            features = token.value
            print(f"\n  {str(val)[:50]:50}")
            print(f"    year_range=[{features[0]*50+2000:.0f}, {features[1]*50+2000:.0f}]")
            print(f"    span={features[2]*20:.0f}yr, n_years={features[3]*10:.0f}")
            print(f"    trend_slope={np.arctanh(features[4].item()):.3f}, R²={features[5]:.2f}")
            print(f"    growth_rate={np.arctanh(features[9].item()):.2f}, recency={features[11]:.2f}")
        else:
            print(f"\n  {str(val)[:50]:50} -> {token.status.name}")
