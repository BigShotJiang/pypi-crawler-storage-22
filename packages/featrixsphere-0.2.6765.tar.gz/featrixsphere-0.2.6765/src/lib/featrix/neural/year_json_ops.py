#  -*- coding: utf-8 -*-
#
#  Copyright Featrix, Inc 2023-2026
#
#  Proprietary and Confidential. Unauthorized use, copying or dissemination
#  of these materials is strictly prohibited.
"""
Year JSON Relationship Operations

Type-aware relationship operations for YEAR_JSON columns.
Supports:
1. YearJson × Timestamp: Does the timestamp fall within the year range?
2. YearJson × Scalar: Correlate aggregated values with scalars
3. YearJson × Set: Categorical patterns with temporal trends
4. YearJson × YearJson: Compare temporal patterns between two year-keyed columns

Key insight: YearJson encodes time-series data with values. The relationship ops
should capture both temporal alignment AND value correlations.

Token feature indices (from YearJsonCodec):
    0: year_min (normalized)
    1: year_max (normalized)
    2: year_span (normalized)
    3: num_years (normalized)
    4: trend_slope (tanh)
    5: trend_r2
    6: total_value_log (normalized)
    7: avg_value_log (normalized)
    8: most_recent_value_log (normalized)
    9: growth_rate (tanh)
    10: valid_flag
    11: recency_score
"""
import logging
import torch
import torch.nn as nn
from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from featrix.neural.type_aware_ops_config import TypeAwareOpsConfig

logger = logging.getLogger(__name__)

# Feature indices for YearJson token
FEAT_YEAR_MIN = 0
FEAT_YEAR_MAX = 1
FEAT_YEAR_SPAN = 2
FEAT_NUM_YEARS = 3
FEAT_TREND_SLOPE = 4
FEAT_TREND_R2 = 5
FEAT_TOTAL_VALUE_LOG = 6
FEAT_AVG_VALUE_LOG = 7
FEAT_MOST_RECENT_LOG = 8
FEAT_GROWTH_RATE = 9
FEAT_VALID_FLAG = 10
FEAT_RECENCY_SCORE = 11


class YearJsonTimestampOps(nn.Module):
    """
    Type-aware operations for YEAR_JSON × TIMESTAMP column pairs.

    Captures patterns like:
    - Does the timestamp year fall within the year range of the JSON?
    - Is the timestamp more recent than the most recent year in the JSON?
    - Temporal proximity between timestamp and JSON year range
    """

    # Features: year_in_range, before_range, after_range, distance_to_range,
    #           same_decade, year_diff_min, year_diff_max
    N_TEMPORAL_ALIGNMENT_FEATURES = 7

    def __init__(
        self,
        d_model: int,
        config: Optional["TypeAwareOpsConfig"] = None,
    ):
        super().__init__()
        self.d_model = d_model
        self.config = config

        # Process raw temporal alignment features
        self.alignment_mlp = nn.Sequential(
            nn.Linear(self.N_TEMPORAL_ALIGNMENT_FEATURES, d_model // 2),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model // 2, d_model),
        )

        # Embedding interaction
        self.interaction_mlp = nn.Sequential(
            nn.Linear(d_model * 3, d_model),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model, d_model),
        )

        # Fusion
        self.fusion_mlp = nn.Sequential(
            nn.Linear(d_model * 2, d_model),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model, d_model),
        )

        self.output_norm = nn.LayerNorm(d_model)

    def compute_temporal_alignment_features(
        self,
        year_json_raw: torch.Tensor,  # (batch, 12) raw year_json token features
        timestamp_year: torch.Tensor,  # (batch,) year extracted from timestamp
    ) -> torch.Tensor:
        """
        Compute temporal alignment features between year_json and timestamp.

        Args:
            year_json_raw: Raw 12-feature token from YearJsonCodec
            timestamp_year: Year from timestamp (as float, e.g., 2023.0)

        Returns:
            Alignment features (batch, 7)
        """
        # Extract year range from year_json token (denormalize)
        year_min = year_json_raw[:, FEAT_YEAR_MIN] * 50.0 + 2000
        year_max = year_json_raw[:, FEAT_YEAR_MAX] * 50.0 + 2000

        # Year in range?
        in_range = ((timestamp_year >= year_min) & (timestamp_year <= year_max)).float()

        # Before range?
        before_range = (timestamp_year < year_min).float()

        # After range?
        after_range = (timestamp_year > year_max).float()

        # Distance to range (0 if in range, positive otherwise)
        dist_to_min = (year_min - timestamp_year).clamp(min=0)
        dist_to_max = (timestamp_year - year_max).clamp(min=0)
        distance_to_range = (dist_to_min + dist_to_max) / 10.0  # Normalize

        # Same decade?
        decade_ts = (timestamp_year / 10).floor()
        decade_min = (year_min / 10).floor()
        decade_max = (year_max / 10).floor()
        same_decade = ((decade_ts >= decade_min) & (decade_ts <= decade_max)).float()

        # Year difference to boundaries (normalized)
        year_diff_min = (timestamp_year - year_min) / 20.0
        year_diff_max = (timestamp_year - year_max) / 20.0

        features = torch.stack([
            in_range,
            before_range,
            after_range,
            distance_to_range,
            same_decade,
            year_diff_min.clamp(-2, 2),
            year_diff_max.clamp(-2, 2),
        ], dim=1)

        return features

    def forward(
        self,
        year_json_embedding: torch.Tensor,  # (batch, d_model)
        timestamp_embedding: torch.Tensor,  # (batch, d_model)
        year_json_raw: Optional[torch.Tensor] = None,  # (batch, 12) optional raw features
        timestamp_year: Optional[torch.Tensor] = None,  # (batch,) optional year
    ) -> torch.Tensor:
        """
        Compute relationship embedding for YearJson × Timestamp pair.

        If raw features are provided, uses explicit temporal alignment.
        Otherwise, uses pure embedding interaction.
        """
        # Embedding interaction (always computed)
        interaction_input = torch.cat([
            year_json_embedding,
            timestamp_embedding,
            year_json_embedding * timestamp_embedding,
        ], dim=-1)
        interaction_emb = self.interaction_mlp(interaction_input)

        # Raw feature alignment (if available)
        if year_json_raw is not None and timestamp_year is not None:
            alignment_features = self.compute_temporal_alignment_features(
                year_json_raw, timestamp_year
            )
            alignment_emb = self.alignment_mlp(alignment_features)

            # Fuse both
            combined = torch.cat([interaction_emb, alignment_emb], dim=-1)
            output = self.fusion_mlp(combined)
        else:
            # Just use interaction embedding
            output = interaction_emb

        return self.output_norm(output)


class YearJsonScalarOps(nn.Module):
    """
    Type-aware operations for YEAR_JSON × SCALAR column pairs.

    Captures patterns like:
    - Does the scalar correlate with the total/avg/recent value in the JSON?
    - Does high growth rate correlate with high scalar values?
    - Ratio relationships (scalar / total, scalar / avg)

    The YearJson embedding already encodes value statistics (total, avg, recent, growth).
    This module learns to extract correlations between those and scalar values.
    """

    def __init__(
        self,
        d_model: int,
        config: Optional["TypeAwareOpsConfig"] = None,
    ):
        super().__init__()
        self.d_model = d_model
        self.config = config

        # Value-scalar correlation
        self.value_scalar_mlp = nn.Sequential(
            nn.Linear(d_model * 2, d_model),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model, d_model),
        )

        # Trend-scalar relationship (does growth correlate with scalar?)
        self.trend_scalar_mlp = nn.Sequential(
            nn.Linear(d_model, d_model // 2),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model // 2, d_model),
        )

        # Scalar-conditioned year_json gating
        self.scalar_gate_mlp = nn.Sequential(
            nn.Linear(d_model, d_model // 2),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model // 2, d_model),
        )

        # Fusion
        self.fusion_mlp = nn.Sequential(
            nn.Linear(d_model * 4, d_model),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model, d_model),
        )

        self.output_norm = nn.LayerNorm(d_model)

    def forward(
        self,
        year_json_embedding: torch.Tensor,  # (batch, d_model)
        scalar_embedding: torch.Tensor,  # (batch, d_model)
    ) -> torch.Tensor:
        """Compute relationship for YearJson × Scalar pair."""
        # Value-scalar correlation
        value_scalar = self.value_scalar_mlp(
            torch.cat([year_json_embedding, scalar_embedding], dim=-1)
        )

        # Trend-scalar relationship
        trend_scalar = self.trend_scalar_mlp(year_json_embedding) * scalar_embedding

        # Scalar gates year_json
        scalar_gate = torch.sigmoid(self.scalar_gate_mlp(scalar_embedding))
        gated_year_json = year_json_embedding * scalar_gate

        # Product
        product = year_json_embedding * scalar_embedding

        # Fusion
        combined = torch.cat([
            value_scalar,
            trend_scalar,
            gated_year_json,
            product,
        ], dim=-1)

        return self.output_norm(self.fusion_mlp(combined))


class YearJsonSetOps(nn.Module):
    """
    Type-aware operations for YEAR_JSON × SET column pairs.

    Captures patterns like:
    - Do certain categories have higher growth rates?
    - Category distribution × temporal trends
    - Set membership × recency patterns
    """

    def __init__(
        self,
        d_model: int,
        config: Optional["TypeAwareOpsConfig"] = None,
    ):
        super().__init__()
        self.d_model = d_model
        self.config = config

        # Year_json-conditioned set gating
        self.year_json_gate_mlp = nn.Sequential(
            nn.Linear(d_model, d_model // 2),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model // 2, d_model),
        )

        # Set-conditioned year_json interpretation
        self.set_context_mlp = nn.Sequential(
            nn.Linear(d_model, d_model // 2),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model // 2, d_model),
        )

        # Interaction
        self.interaction_mlp = nn.Sequential(
            nn.Linear(d_model * 2, d_model),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model, d_model),
        )

        # Fusion
        self.fusion_mlp = nn.Sequential(
            nn.Linear(d_model * 4, d_model),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model, d_model),
        )

        self.output_norm = nn.LayerNorm(d_model)

    def forward(
        self,
        year_json_embedding: torch.Tensor,  # (batch, d_model)
        set_embedding: torch.Tensor,  # (batch, d_model)
    ) -> torch.Tensor:
        """Compute relationship for YearJson × Set pair."""
        # Year_json gates set
        year_json_gate = torch.sigmoid(self.year_json_gate_mlp(year_json_embedding))
        gated_set = set_embedding * year_json_gate

        # Set contextualizes year_json
        set_context = self.set_context_mlp(set_embedding)
        contextualized_year_json = year_json_embedding * set_context

        # Interaction
        interaction = self.interaction_mlp(
            torch.cat([year_json_embedding, set_embedding], dim=-1)
        )

        # Product
        product = year_json_embedding * set_embedding

        # Fusion
        combined = torch.cat([
            gated_set,
            contextualized_year_json,
            interaction,
            product,
        ], dim=-1)

        return self.output_norm(self.fusion_mlp(combined))


class YearJsonYearJsonOps(nn.Module):
    """
    Type-aware operations for YEAR_JSON × YEAR_JSON column pairs.

    Captures patterns like:
    - Do two time series have overlapping year ranges?
    - Are their trends correlated (both increasing, opposite, etc.)?
    - Do they have similar recency?
    - Value ratio patterns (total_a / total_b)

    Example use case: "sales_by_year" vs "marketing_spend_by_year"
    """

    # Raw features: year_overlap, range_containment, trend_correlation,
    #               recency_diff, value_ratio, growth_alignment
    N_YEAR_JSON_PAIR_FEATURES = 8

    def __init__(
        self,
        d_model: int,
        config: Optional["TypeAwareOpsConfig"] = None,
    ):
        super().__init__()
        self.d_model = d_model
        self.config = config

        # Raw feature processing
        self.pair_feature_mlp = nn.Sequential(
            nn.Linear(self.N_YEAR_JSON_PAIR_FEATURES, d_model // 2),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model // 2, d_model),
        )

        # Embedding interaction
        self.interaction_mlp = nn.Sequential(
            nn.Linear(d_model * 3, d_model),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model, d_model),
        )

        # Fusion
        self.fusion_mlp = nn.Sequential(
            nn.Linear(d_model * 2, d_model),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model, d_model),
        )

        self.output_norm = nn.LayerNorm(d_model)

    def compute_pair_features(
        self,
        raw_a: torch.Tensor,  # (batch, 12)
        raw_b: torch.Tensor,  # (batch, 12)
    ) -> torch.Tensor:
        """
        Compute relationship features between two year_json columns.

        Args:
            raw_a: Raw 12-feature token for year_json column A
            raw_b: Raw 12-feature token for year_json column B

        Returns:
            Pair features (batch, 8)
        """
        # Extract features (denormalize where needed)
        year_min_a = raw_a[:, FEAT_YEAR_MIN] * 50.0 + 2000
        year_max_a = raw_a[:, FEAT_YEAR_MAX] * 50.0 + 2000
        year_min_b = raw_b[:, FEAT_YEAR_MIN] * 50.0 + 2000
        year_max_b = raw_b[:, FEAT_YEAR_MAX] * 50.0 + 2000

        trend_slope_a = raw_a[:, FEAT_TREND_SLOPE]  # Already tanh'd
        trend_slope_b = raw_b[:, FEAT_TREND_SLOPE]

        growth_a = raw_a[:, FEAT_GROWTH_RATE]  # Already tanh'd
        growth_b = raw_b[:, FEAT_GROWTH_RATE]

        recency_a = raw_a[:, FEAT_RECENCY_SCORE]
        recency_b = raw_b[:, FEAT_RECENCY_SCORE]

        total_log_a = raw_a[:, FEAT_TOTAL_VALUE_LOG]
        total_log_b = raw_b[:, FEAT_TOTAL_VALUE_LOG]

        # Year overlap: max(0, min(max_a, max_b) - max(min_a, min_b))
        overlap_start = torch.max(year_min_a, year_min_b)
        overlap_end = torch.min(year_max_a, year_max_b)
        year_overlap = ((overlap_end - overlap_start).clamp(min=0) / 10.0).clamp(max=2.0)

        # Range containment: does one fully contain the other?
        a_contains_b = ((year_min_a <= year_min_b) & (year_max_a >= year_max_b)).float()
        b_contains_a = ((year_min_b <= year_min_a) & (year_max_b >= year_max_a)).float()
        containment = a_contains_b + b_contains_a  # 0, 1, or 2

        # Trend correlation: do both trends go same direction?
        trend_correlation = trend_slope_a * trend_slope_b  # Positive if same direction

        # Growth alignment
        growth_alignment = growth_a * growth_b

        # Recency difference
        recency_diff = (recency_a - recency_b).abs()

        # Value ratio (in log space)
        value_ratio = total_log_a - total_log_b  # Log ratio

        # Both increasing? Both decreasing?
        both_increasing = ((trend_slope_a > 0.1) & (trend_slope_b > 0.1)).float()
        both_decreasing = ((trend_slope_a < -0.1) & (trend_slope_b < -0.1)).float()

        features = torch.stack([
            year_overlap,
            containment,
            trend_correlation,
            growth_alignment,
            recency_diff,
            value_ratio.clamp(-2, 2),
            both_increasing,
            both_decreasing,
        ], dim=1)

        return features

    def forward(
        self,
        year_json_embedding_a: torch.Tensor,  # (batch, d_model)
        year_json_embedding_b: torch.Tensor,  # (batch, d_model)
        raw_a: Optional[torch.Tensor] = None,  # (batch, 12)
        raw_b: Optional[torch.Tensor] = None,  # (batch, 12)
    ) -> torch.Tensor:
        """Compute relationship for YearJson × YearJson pair."""
        # Embedding interaction (always computed)
        interaction_input = torch.cat([
            year_json_embedding_a,
            year_json_embedding_b,
            year_json_embedding_a * year_json_embedding_b,
        ], dim=-1)
        interaction_emb = self.interaction_mlp(interaction_input)

        # Raw feature processing (if available)
        if raw_a is not None and raw_b is not None:
            pair_features = self.compute_pair_features(raw_a, raw_b)
            pair_emb = self.pair_feature_mlp(pair_features)

            # Fuse both
            combined = torch.cat([interaction_emb, pair_emb], dim=-1)
            output = self.fusion_mlp(combined)
        else:
            output = interaction_emb

        return self.output_norm(output)
