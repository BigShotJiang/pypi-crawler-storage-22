#  -*- coding: utf-8 -*-
#
#  Copyright Featrix, Inc 2023-2026
#
#  Proprietary and Confidential.  Unauthorized use, copying or dissemination
#  of these materials is strictly prohibited.
"""
Zip Code Codec and Encoder

Encodes US zip codes by extracting:
- Geographic coordinates (lat/long from zip code centroid)
- State/region information
- Urban/rural classification hints

Key insight: Zip codes that are geographically close should have similar embeddings.
This enables learning relationships like:
- Customer zip vs store zip (proximity)
- Shipping zones
- Regional patterns

Token value is a tensor of floats representing:
- zip_lat (1): normalized latitude
- zip_long (1): normalized longitude
- state_region_embedding (16): embedding for state/region
- digit_features (10): one-hot of each digit
- prefix_embedding (16): embedding for 3-digit prefix (SCF)
Total: 44 floats
"""
import logging
import math
import re
import torch
import torch.nn as nn
import torch.nn.functional as F

from typing import Dict, List, Optional, Tuple

from featrix.neural.gpu_utils import get_device
from featrix.neural.featrix_token import Token, TokenStatus
from featrix.neural.model_config import ColumnType, SimpleMLPConfig
from featrix.neural.simple_mlp import SimpleMLP
from featrix.neural.geo_spread import GEO_SPREAD_ENABLED, GEO_SPREAD_DIM, compute_geo_spread, empty_geo_spread_tensor

logger = logging.getLogger(__name__)

# Zip token dimensions
ZIP_STATE_EMB_DIM = 16
ZIP_PREFIX_EMB_DIM = 16
ZIP_DIGIT_FEATURES_DIM = 10
ZIP_TOKEN_DIM = 1 + 1 + ZIP_STATE_EMB_DIM + ZIP_DIGIT_FEATURES_DIM + ZIP_PREFIX_EMB_DIM  # = 44

# Normalization constants for lat/long (US bounds)
LAT_MIN, LAT_MAX = 18.0, 72.0  # From Puerto Rico/Hawaii to Alaska
LONG_MIN, LONG_MAX = -180.0, -65.0  # From Alaska to Maine


def normalize_lat(lat: float) -> float:
    """Normalize latitude to [0, 1] range."""
    return (lat - LAT_MIN) / (LAT_MAX - LAT_MIN)


def normalize_long(lon: float) -> float:
    """Normalize longitude to [0, 1] range."""
    return (lon - LONG_MIN) / (LONG_MAX - LONG_MIN)


# US Zip Code 3-digit prefix (SCF) to approximate coordinates
# Source: US Census Bureau, aggregated by SCF (Sectional Center Facility)
# Format: prefix -> (latitude, longitude, state_abbrev)
# This is a sample - full production dataset would have all 1000 prefixes
ZIP_PREFIX_COORDS: Dict[str, Tuple[float, float, str]] = {
    # Northeast
    '010': (42.10, -72.59, 'MA'),  # Springfield MA
    '011': (42.10, -72.59, 'MA'),
    '012': (42.45, -73.25, 'MA'),  # Pittsfield
    '013': (42.10, -72.59, 'MA'),
    '014': (42.27, -71.80, 'MA'),  # Worcester
    '015': (42.27, -71.80, 'MA'),
    '016': (42.27, -71.80, 'MA'),
    '017': (42.47, -71.15, 'MA'),  # Middlesex
    '018': (42.47, -71.15, 'MA'),
    '019': (42.47, -71.15, 'MA'),
    '020': (42.36, -71.06, 'MA'),  # Boston
    '021': (42.36, -71.06, 'MA'),
    '022': (42.36, -71.06, 'MA'),
    '023': (41.70, -70.30, 'MA'),  # Cape Cod
    '024': (42.52, -70.90, 'MA'),  # North Shore
    '025': (41.95, -70.67, 'MA'),  # Plymouth
    '026': (41.95, -70.67, 'MA'),
    '027': (41.82, -71.41, 'RI'),  # Providence
    '028': (41.82, -71.41, 'RI'),
    '029': (41.82, -71.41, 'RI'),
    '030': (42.99, -71.45, 'NH'),  # Manchester NH
    '031': (42.99, -71.45, 'NH'),
    '032': (42.99, -71.45, 'NH'),
    '033': (43.21, -71.54, 'NH'),  # Concord
    '034': (43.21, -71.54, 'NH'),
    '035': (44.47, -73.21, 'VT'),  # Burlington
    '036': (44.47, -73.21, 'VT'),
    '037': (44.47, -73.21, 'VT'),
    '038': (43.65, -72.32, 'VT'),  # White River Junction
    '039': (43.65, -72.32, 'VT'),
    '040': (43.66, -70.26, 'ME'),  # Portland ME
    '041': (43.66, -70.26, 'ME'),
    '042': (43.66, -70.26, 'ME'),
    '043': (44.80, -68.78, 'ME'),  # Bangor
    '044': (44.80, -68.78, 'ME'),
    '045': (44.80, -68.78, 'ME'),
    '046': (44.80, -68.78, 'ME'),
    '047': (44.80, -68.78, 'ME'),
    '048': (43.66, -70.26, 'ME'),
    '049': (43.66, -70.26, 'ME'),

    # New York
    '100': (40.71, -74.01, 'NY'),  # Manhattan
    '101': (40.71, -74.01, 'NY'),
    '102': (40.71, -74.01, 'NY'),
    '103': (40.58, -74.15, 'NY'),  # Staten Island
    '104': (40.85, -73.87, 'NY'),  # Bronx
    '105': (40.93, -73.90, 'NY'),  # Westchester
    '106': (40.93, -73.90, 'NY'),
    '107': (40.93, -73.90, 'NY'),
    '108': (40.93, -73.90, 'NY'),
    '109': (41.10, -73.72, 'NY'),
    '110': (40.65, -73.95, 'NY'),  # Queens
    '111': (40.73, -73.79, 'NY'),
    '112': (40.65, -73.95, 'NY'),  # Brooklyn
    '113': (40.65, -73.95, 'NY'),
    '114': (40.65, -73.95, 'NY'),
    '115': (40.77, -73.50, 'NY'),  # Nassau
    '116': (40.77, -73.50, 'NY'),
    '117': (40.85, -73.20, 'NY'),  # Suffolk
    '118': (40.85, -73.20, 'NY'),
    '119': (40.85, -73.20, 'NY'),
    '120': (42.65, -73.76, 'NY'),  # Albany
    '121': (42.65, -73.76, 'NY'),
    '122': (42.65, -73.76, 'NY'),
    '123': (42.82, -73.95, 'NY'),  # Schenectady
    '124': (42.82, -73.95, 'NY'),
    '125': (41.70, -73.93, 'NY'),  # Poughkeepsie
    '126': (41.70, -73.93, 'NY'),
    '127': (41.50, -74.01, 'NY'),  # Mid-Hudson
    '128': (43.08, -76.15, 'NY'),  # Syracuse
    '129': (43.08, -76.15, 'NY'),
    '130': (43.08, -76.15, 'NY'),
    '131': (43.08, -76.15, 'NY'),
    '132': (43.08, -76.15, 'NY'),
    '133': (43.10, -75.23, 'NY'),  # Utica
    '134': (43.10, -75.23, 'NY'),
    '135': (43.10, -75.23, 'NY'),
    '136': (44.70, -75.48, 'NY'),  # Watertown
    '137': (42.10, -76.08, 'NY'),  # Binghamton
    '138': (42.10, -76.08, 'NY'),
    '139': (42.10, -76.08, 'NY'),
    '140': (42.89, -78.88, 'NY'),  # Buffalo
    '141': (42.89, -78.88, 'NY'),
    '142': (42.89, -78.88, 'NY'),
    '143': (43.00, -78.20, 'NY'),  # Niagara Falls area
    '144': (43.16, -77.61, 'NY'),  # Rochester
    '145': (43.16, -77.61, 'NY'),
    '146': (43.16, -77.61, 'NY'),
    '147': (42.44, -76.50, 'NY'),  # Finger Lakes
    '148': (42.09, -79.24, 'NY'),  # Jamestown
    '149': (42.44, -76.50, 'NY'),

    # New Jersey
    '070': (40.86, -74.16, 'NJ'),  # Newark
    '071': (40.86, -74.16, 'NJ'),
    '072': (40.73, -74.17, 'NJ'),  # Elizabeth
    '073': (40.79, -74.23, 'NJ'),
    '074': (40.91, -74.17, 'NJ'),  # Paterson
    '075': (40.91, -74.17, 'NJ'),
    '076': (40.74, -74.03, 'NJ'),  # Hackensack
    '077': (40.74, -74.03, 'NJ'),
    '078': (40.49, -74.45, 'NJ'),  # New Brunswick
    '079': (40.35, -74.66, 'NJ'),
    '080': (39.95, -75.12, 'NJ'),  # Camden
    '081': (39.95, -75.12, 'NJ'),
    '082': (39.36, -74.44, 'NJ'),  # Atlantic City
    '083': (39.36, -74.44, 'NJ'),
    '084': (39.36, -74.44, 'NJ'),
    '085': (40.22, -74.76, 'NJ'),  # Trenton
    '086': (40.22, -74.76, 'NJ'),
    '087': (40.22, -74.76, 'NJ'),
    '088': (40.49, -74.45, 'NJ'),
    '089': (39.95, -75.12, 'NJ'),

    # Pennsylvania
    '150': (40.44, -79.99, 'PA'),  # Pittsburgh
    '151': (40.44, -79.99, 'PA'),
    '152': (40.44, -79.99, 'PA'),
    '153': (40.27, -76.88, 'PA'),  # Washington PA
    '154': (41.24, -80.09, 'PA'),  # Youngstown area
    '155': (40.32, -79.38, 'PA'),  # Johnstown
    '156': (40.32, -79.38, 'PA'),
    '157': (40.32, -79.38, 'PA'),
    '158': (40.87, -79.85, 'PA'),  # Butler
    '159': (40.87, -79.85, 'PA'),
    '160': (41.41, -79.71, 'PA'),  # Oil City
    '161': (41.41, -79.71, 'PA'),
    '162': (41.87, -80.08, 'PA'),  # Erie
    '163': (41.87, -80.08, 'PA'),
    '164': (41.87, -80.08, 'PA'),
    '165': (41.23, -77.00, 'PA'),  # Williamsport
    '166': (40.50, -78.40, 'PA'),  # Altoona
    '167': (40.50, -78.40, 'PA'),
    '168': (40.50, -78.40, 'PA'),
    '169': (40.27, -76.88, 'PA'),
    '170': (40.27, -76.88, 'PA'),  # Harrisburg
    '171': (40.27, -76.88, 'PA'),
    '172': (40.04, -76.31, 'PA'),  # Lancaster
    '173': (39.96, -76.73, 'PA'),  # York
    '174': (39.96, -76.73, 'PA'),
    '175': (40.04, -76.31, 'PA'),
    '176': (40.04, -76.31, 'PA'),
    '177': (40.27, -76.88, 'PA'),
    '178': (40.27, -76.88, 'PA'),
    '179': (40.33, -75.93, 'PA'),  # Reading
    '180': (40.61, -75.49, 'PA'),  # Allentown
    '181': (40.61, -75.49, 'PA'),
    '182': (40.61, -75.49, 'PA'),
    '183': (40.61, -75.49, 'PA'),
    '184': (41.41, -75.66, 'PA'),  # Scranton
    '185': (41.41, -75.66, 'PA'),
    '186': (41.24, -75.88, 'PA'),  # Wilkes-Barre
    '187': (41.24, -75.88, 'PA'),
    '188': (41.24, -75.88, 'PA'),
    '189': (40.08, -75.35, 'PA'),  # Norristown
    '190': (39.95, -75.17, 'PA'),  # Philadelphia
    '191': (39.95, -75.17, 'PA'),
    '192': (39.95, -75.17, 'PA'),
    '193': (39.95, -75.17, 'PA'),
    '194': (39.95, -75.17, 'PA'),
    '195': (40.08, -75.35, 'PA'),

    # California
    '900': (33.94, -118.41, 'CA'),  # Los Angeles
    '901': (33.94, -118.41, 'CA'),
    '902': (34.01, -118.49, 'CA'),
    '903': (34.06, -118.24, 'CA'),
    '904': (34.06, -118.24, 'CA'),
    '905': (33.86, -118.08, 'CA'),  # Long Beach area
    '906': (34.15, -118.45, 'CA'),  # San Fernando Valley
    '907': (34.15, -118.45, 'CA'),
    '908': (34.15, -118.45, 'CA'),
    '910': (34.15, -118.14, 'CA'),  # Pasadena
    '911': (34.15, -118.14, 'CA'),
    '912': (34.00, -117.88, 'CA'),  # Whittier
    '913': (33.75, -118.19, 'CA'),  # Long Beach
    '914': (33.75, -118.19, 'CA'),
    '915': (33.65, -117.90, 'CA'),  # Orange County
    '916': (33.65, -117.90, 'CA'),
    '917': (33.65, -117.90, 'CA'),  # Irvine
    '918': (33.65, -117.90, 'CA'),
    '919': (32.72, -117.16, 'CA'),  # San Diego
    '920': (32.72, -117.16, 'CA'),
    '921': (32.72, -117.16, 'CA'),
    '922': (33.05, -117.29, 'CA'),  # Oceanside
    '923': (33.46, -117.10, 'CA'),  # Temecula
    '924': (34.06, -117.65, 'CA'),  # San Bernardino
    '925': (34.06, -117.65, 'CA'),
    '926': (33.75, -116.97, 'CA'),  # Riverside
    '927': (33.75, -116.97, 'CA'),
    '928': (33.72, -116.37, 'CA'),  # Palm Springs
    '930': (34.42, -119.70, 'CA'),  # Santa Barbara
    '931': (34.42, -119.70, 'CA'),
    '932': (35.37, -119.02, 'CA'),  # Bakersfield
    '933': (35.37, -119.02, 'CA'),
    '934': (34.95, -120.44, 'CA'),  # Santa Maria
    '935': (35.28, -120.66, 'CA'),  # San Luis Obispo
    '936': (36.74, -119.79, 'CA'),  # Fresno
    '937': (36.74, -119.79, 'CA'),
    '938': (36.74, -119.79, 'CA'),
    '939': (36.60, -121.89, 'CA'),  # Salinas
    '940': (37.55, -122.27, 'CA'),  # San Mateo
    '941': (37.77, -122.42, 'CA'),  # San Francisco
    '942': (38.58, -121.49, 'CA'),  # Sacramento
    '943': (38.58, -121.49, 'CA'),
    '944': (37.77, -122.42, 'CA'),
    '945': (37.80, -122.27, 'CA'),  # Oakland
    '946': (37.80, -122.27, 'CA'),
    '947': (37.87, -122.27, 'CA'),  # Berkeley
    '948': (37.87, -122.27, 'CA'),
    '949': (37.98, -122.53, 'CA'),  # San Rafael
    '950': (37.34, -121.89, 'CA'),  # San Jose
    '951': (37.34, -121.89, 'CA'),
    '952': (37.50, -122.25, 'CA'),  # Redwood City
    '953': (36.97, -122.03, 'CA'),  # Santa Cruz
    '954': (37.55, -121.99, 'CA'),  # Fremont
    '955': (40.80, -124.16, 'CA'),  # Eureka
    '956': (38.58, -121.49, 'CA'),
    '957': (38.58, -121.49, 'CA'),
    '958': (38.58, -121.49, 'CA'),
    '959': (39.53, -119.81, 'CA'),  # Reno area
    '960': (40.59, -122.39, 'CA'),  # Redding
    '961': (40.59, -122.39, 'CA'),

    # Texas
    '750': (32.78, -96.80, 'TX'),  # Dallas
    '751': (32.78, -96.80, 'TX'),
    '752': (32.78, -96.80, 'TX'),
    '753': (32.78, -96.80, 'TX'),
    '754': (32.93, -96.77, 'TX'),  # Richardson
    '755': (32.93, -96.77, 'TX'),
    '756': (31.55, -97.15, 'TX'),  # Waco
    '757': (31.55, -97.15, 'TX'),
    '758': (31.55, -97.15, 'TX'),
    '759': (33.21, -97.13, 'TX'),  # Denton
    '760': (32.75, -97.33, 'TX'),  # Fort Worth
    '761': (32.75, -97.33, 'TX'),
    '762': (32.75, -97.33, 'TX'),
    '763': (33.46, -94.04, 'TX'),  # Texarkana
    '764': (32.35, -95.30, 'TX'),  # Tyler
    '765': (32.35, -95.30, 'TX'),
    '766': (33.44, -99.73, 'TX'),  # Wichita Falls
    '767': (33.44, -99.73, 'TX'),
    '768': (35.22, -101.83, 'TX'),  # Amarillo
    '769': (35.22, -101.83, 'TX'),
    '770': (29.76, -95.37, 'TX'),  # Houston
    '771': (29.76, -95.37, 'TX'),
    '772': (29.76, -95.37, 'TX'),
    '773': (29.76, -95.37, 'TX'),
    '774': (29.76, -95.37, 'TX'),
    '775': (29.76, -95.37, 'TX'),
    '776': (30.27, -97.74, 'TX'),  # Austin
    '777': (30.27, -97.74, 'TX'),
    '778': (30.27, -97.74, 'TX'),
    '779': (30.27, -97.74, 'TX'),
    '780': (29.42, -98.49, 'TX'),  # San Antonio
    '781': (29.42, -98.49, 'TX'),
    '782': (29.42, -98.49, 'TX'),
    '783': (27.51, -99.51, 'TX'),  # Laredo
    '784': (27.80, -97.40, 'TX'),  # Corpus Christi
    '785': (26.21, -98.23, 'TX'),  # McAllen
    '786': (30.08, -94.13, 'TX'),  # Beaumont
    '787': (30.08, -94.13, 'TX'),
    '788': (31.76, -106.49, 'TX'),  # El Paso
    '789': (31.76, -106.49, 'TX'),
    '790': (33.58, -101.86, 'TX'),  # Lubbock
    '791': (33.58, -101.86, 'TX'),
    '792': (31.99, -102.08, 'TX'),  # Midland
    '793': (31.99, -102.08, 'TX'),
    '794': (31.44, -100.45, 'TX'),  # San Angelo
    '795': (32.45, -99.73, 'TX'),  # Abilene
    '796': (32.45, -99.73, 'TX'),
    '797': (31.99, -102.08, 'TX'),

    # Florida
    '320': (30.33, -81.66, 'FL'),  # Jacksonville
    '321': (28.54, -81.38, 'FL'),  # Orlando
    '322': (30.33, -81.66, 'FL'),
    '323': (30.44, -84.28, 'FL'),  # Tallahassee
    '324': (30.44, -84.28, 'FL'),
    '325': (30.19, -85.66, 'FL'),  # Panama City
    '326': (29.65, -82.32, 'FL'),  # Gainesville
    '327': (28.54, -81.38, 'FL'),
    '328': (28.54, -81.38, 'FL'),
    '329': (28.54, -81.38, 'FL'),
    '330': (25.76, -80.19, 'FL'),  # Miami
    '331': (26.12, -80.14, 'FL'),  # Fort Lauderdale
    '332': (25.76, -80.19, 'FL'),
    '333': (26.12, -80.14, 'FL'),
    '334': (26.72, -80.05, 'FL'),  # West Palm Beach
    '335': (26.72, -80.05, 'FL'),
    '336': (27.95, -82.46, 'FL'),  # Tampa
    '337': (27.77, -82.64, 'FL'),  # St Petersburg
    '338': (28.06, -82.41, 'FL'),
    '339': (26.14, -81.79, 'FL'),  # Fort Myers
    '340': (18.34, -64.93, 'VI'),  # Virgin Islands
    '341': (27.34, -82.53, 'FL'),  # Sarasota
    '342': (29.03, -80.93, 'FL'),  # Daytona Beach

    # Illinois
    '600': (41.88, -87.63, 'IL'),  # Chicago
    '601': (41.88, -87.63, 'IL'),
    '602': (41.88, -87.63, 'IL'),
    '603': (41.85, -87.65, 'IL'),  # Oak Park
    '604': (41.85, -87.65, 'IL'),
    '605': (41.75, -87.75, 'IL'),  # South suburbs
    '606': (41.88, -87.63, 'IL'),
    '607': (41.88, -87.63, 'IL'),
    '608': (41.88, -87.63, 'IL'),
    '609': (42.10, -88.04, 'IL'),  # Northwest suburbs
    '610': (42.08, -88.28, 'IL'),  # Elgin
    '611': (42.27, -89.09, 'IL'),  # Rockford
    '612': (42.27, -89.09, 'IL'),
    '613': (41.51, -90.58, 'IL'),  # Rock Island
    '614': (41.51, -90.58, 'IL'),
    '615': (40.69, -89.59, 'IL'),  # Peoria
    '616': (40.69, -89.59, 'IL'),
    '617': (40.48, -88.99, 'IL'),  # Bloomington
    '618': (39.78, -89.65, 'IL'),  # Springfield
    '619': (39.78, -89.65, 'IL'),
    '620': (38.63, -90.20, 'IL'),  # East St Louis area
    '621': (38.63, -90.20, 'IL'),
    '622': (38.63, -90.20, 'IL'),
    '623': (37.73, -89.22, 'IL'),  # Carbondale
    '624': (37.73, -89.22, 'IL'),
    '625': (39.80, -88.95, 'IL'),  # Decatur

    # Add more states/regions as needed...
}

# State abbreviation to region mapping for embedding
STATE_REGIONS = {
    'MA': 0, 'RI': 0, 'CT': 0, 'NH': 0, 'VT': 0, 'ME': 0,  # New England
    'NY': 1, 'NJ': 1, 'PA': 1,  # Mid-Atlantic
    'OH': 2, 'MI': 2, 'IN': 2, 'IL': 2, 'WI': 2,  # Great Lakes
    'MN': 3, 'IA': 3, 'MO': 3, 'ND': 3, 'SD': 3, 'NE': 3, 'KS': 3,  # Midwest
    'DE': 4, 'MD': 4, 'DC': 4, 'VA': 4, 'WV': 4, 'NC': 4, 'SC': 4, 'GA': 4, 'FL': 4,  # Southeast
    'KY': 5, 'TN': 5, 'AL': 5, 'MS': 5,  # Deep South
    'AR': 6, 'LA': 6, 'OK': 6, 'TX': 6,  # South Central
    'MT': 7, 'ID': 7, 'WY': 7, 'CO': 7, 'NM': 7, 'AZ': 7, 'UT': 7, 'NV': 7,  # Mountain
    'WA': 8, 'OR': 8, 'CA': 8,  # Pacific
    'AK': 9,  # Alaska
    'HI': 10,  # Hawaii
    'VI': 11, 'PR': 11, 'GU': 11,  # Territories
}


def parse_zip_code(zip_str: str) -> Dict:
    """
    Parse a zip code string into components.

    Returns:
        Dict with keys:
        - zip5: str (5-digit zip)
        - zip3: str (3-digit prefix/SCF)
        - plus4: str (optional +4 extension)
        - is_valid: bool
    """
    if zip_str is None:
        return {'is_valid': False, 'zip5': '', 'zip3': '', 'plus4': ''}

    zip_str = str(zip_str).strip()

    # Remove any non-digit/hyphen characters
    zip_str = re.sub(r'[^\d-]', '', zip_str)

    result = {
        'is_valid': False,
        'zip5': '',
        'zip3': '',
        'plus4': '',
    }

    # Handle ZIP+4 format (12345-6789)
    if '-' in zip_str:
        parts = zip_str.split('-')
        if len(parts) == 2 and len(parts[0]) == 5 and len(parts[1]) == 4:
            result['zip5'] = parts[0]
            result['zip3'] = parts[0][:3]
            result['plus4'] = parts[1]
            result['is_valid'] = True
            return result

    # Handle plain 5-digit zip
    digits = re.sub(r'[^\d]', '', zip_str)

    if len(digits) == 5:
        result['zip5'] = digits
        result['zip3'] = digits[:3]
        result['is_valid'] = True
    elif len(digits) == 9:
        # ZIP+4 without hyphen
        result['zip5'] = digits[:5]
        result['zip3'] = digits[:3]
        result['plus4'] = digits[5:]
        result['is_valid'] = True
    elif len(digits) == 3:
        # Just prefix
        result['zip3'] = digits
        result['zip5'] = digits + '00'  # Approximate
        result['is_valid'] = True

    return result


class ZipCodec:
    """
    Codec for zip codes.

    Tokenizes zip codes into a tensor containing:
    - Geographic features (lat/long of zip centroid)
    - State/region embedding
    - Digit distribution features
    """

    def __init__(self, df_col, embed_dim: int = 768, string_cache=None, detector=None):
        self.embed_dim = embed_dim
        self.enc_dim = ZIP_TOKEN_DIM  # Token dimension for encoder config
        self.string_cache = string_cache
        self.detector = detector
        self.column_type = ColumnType.ZIP_CODE

        # Build prefix vocabulary from data + known prefixes
        self._build_prefix_vocab(df_col)

        # Create NOT_PRESENT and UNKNOWN tokens
        self._not_present_token = self._create_special_token(TokenStatus.NOT_PRESENT)
        self._unknown_token = self._create_special_token(TokenStatus.UNKNOWN)

        logger.info(f"ZipCodec initialized with {len(self.prefix_to_idx)} prefixes")

    def _build_prefix_vocab(self, df_col):
        """Build vocabulary of zip prefixes from data and known prefixes."""
        self.prefix_to_idx = {}
        self.idx_to_prefix = {}

        # Start with known prefixes
        for prefix in ZIP_PREFIX_COORDS.keys():
            idx = len(self.prefix_to_idx)
            self.prefix_to_idx[prefix] = idx
            self.idx_to_prefix[idx] = prefix

        # Add prefixes from data that we don't know
        for val in df_col.dropna().unique():
            parsed = parse_zip_code(val)
            if parsed['is_valid'] and parsed['zip3']:
                prefix = parsed['zip3']
                if prefix not in self.prefix_to_idx:
                    idx = len(self.prefix_to_idx)
                    self.prefix_to_idx[prefix] = idx
                    self.idx_to_prefix[idx] = prefix

        # Add UNKNOWN prefix
        self.unknown_prefix_idx = len(self.prefix_to_idx)
        self.prefix_to_idx['UNKNOWN'] = self.unknown_prefix_idx
        self.idx_to_prefix[self.unknown_prefix_idx] = 'UNKNOWN'

    def _create_special_token(self, status: TokenStatus) -> Token:
        """Create a special token (NOT_PRESENT or UNKNOWN)."""
        value = torch.zeros(ZIP_TOKEN_DIM)
        return Token(value=value, status=status)

    def get_not_present_token(self) -> Token:
        return self._not_present_token

    def get_unknown_token(self) -> Token:
        return self._unknown_token

    def get_codec_name(self):
        return ColumnType.ZIP_CODE

    def get_geo_point(self, zip_value) -> Optional[Tuple[float, float]]:
        """
        Get geographic coordinates for a zip code.

        Args:
            zip_value: Zip code string

        Returns:
            (latitude, longitude) tuple, or None if unknown
        """
        if zip_value is None:
            return None

        parsed = parse_zip_code(zip_value)
        if not parsed['is_valid']:
            return None

        prefix = parsed['zip3']
        if prefix and prefix in ZIP_PREFIX_COORDS:
            lat, lon, state = ZIP_PREFIX_COORDS[prefix]
            return (lat, lon)

        return None

    def get_geo_spread_features(self, zip_value) -> torch.Tensor:
        """
        Get geo spread features for a single zip code.

        For single values, this returns features for one location.
        Returns zero tensor if geo spread is disabled.
        """
        if not GEO_SPREAD_ENABLED:
            return empty_geo_spread_tensor()

        geo_point = self.get_geo_point(zip_value)
        if geo_point is None:
            return empty_geo_spread_tensor()

        lat, lon = geo_point
        features = compute_geo_spread([(lat, lon, 1.0)])
        return features.to_tensor()

    def tokenize(self, zip_value) -> Token:
        """
        Convert a zip code string to a Token.
        """
        if zip_value is None or (isinstance(zip_value, float) and math.isnan(zip_value)):
            return self._not_present_token

        if isinstance(zip_value, str) and zip_value.strip() == '':
            return self._not_present_token

        parsed = parse_zip_code(zip_value)

        if not parsed['is_valid']:
            return self._unknown_token

        # Build feature tensor
        features = []

        # 1. Zip lat/long (2 floats)
        prefix = parsed['zip3']
        if prefix and prefix in ZIP_PREFIX_COORDS:
            lat, lon, state = ZIP_PREFIX_COORDS[prefix]
            features.append(normalize_lat(lat))
            features.append(normalize_long(lon))
        else:
            # Unknown prefix - use center of continental US
            features.append(normalize_lat(39.8283))
            features.append(normalize_long(-98.5795))
            state = None

        # 2. State/region embedding (16 floats)
        state_emb = torch.zeros(ZIP_STATE_EMB_DIM)
        if state and state in STATE_REGIONS:
            region_idx = STATE_REGIONS[state]
            state_emb[region_idx % ZIP_STATE_EMB_DIM] = 1.0
        features.extend(state_emb.tolist())

        # 3. Digit distribution (10 floats)
        zip5 = parsed['zip5']
        digit_counts = torch.zeros(10)
        for d in zip5:
            if d.isdigit():
                digit_counts[int(d)] += 1
        if len(zip5) > 0:
            digit_counts = digit_counts / len(zip5)
        features.extend(digit_counts.tolist())

        # 4. Prefix embedding (16 floats)
        prefix_idx = self.prefix_to_idx.get(prefix, self.unknown_prefix_idx) if prefix else self.unknown_prefix_idx
        prefix_emb = torch.zeros(ZIP_PREFIX_EMB_DIM)
        prefix_emb[prefix_idx % ZIP_PREFIX_EMB_DIM] = 1.0
        if prefix_idx >= ZIP_PREFIX_EMB_DIM:
            prefix_emb[(prefix_idx // ZIP_PREFIX_EMB_DIM) % ZIP_PREFIX_EMB_DIM] = 0.5
        features.extend(prefix_emb.tolist())

        value = torch.tensor(features, dtype=torch.float32)
        assert value.shape[0] == ZIP_TOKEN_DIM, f"Expected {ZIP_TOKEN_DIM} features, got {value.shape[0]}"

        return Token(value=value, status=TokenStatus.OK)


class ZipEncoder(nn.Module):
    """
    Encodes zip code features using an MLP.

    Input: TokenBatch with tensor values of shape [batch, 44]
    Output: (short_vec, full_vec) embeddings
    """

    def __init__(self, config: SimpleMLPConfig, string_cache=None, column_name: Optional[str] = None):
        super().__init__()
        self.config = config
        self.string_cache = string_cache
        self.column_name = column_name
        self.d_model = config.d_out

        # Project lat/long (2 -> 32)
        self.geo_proj = nn.Linear(2, 32, bias=False)
        nn.init.xavier_uniform_(self.geo_proj.weight, gain=1.0)

        # Project state embedding (16 -> 32)
        self.state_proj = nn.Linear(ZIP_STATE_EMB_DIM, 32, bias=False)
        nn.init.xavier_uniform_(self.state_proj.weight, gain=1.0)

        # Project digit features (10 -> 16)
        self.digit_proj = nn.Linear(ZIP_DIGIT_FEATURES_DIM, 16, bias=False)
        nn.init.xavier_uniform_(self.digit_proj.weight, gain=0.5)

        # Project prefix embedding (16 -> 32)
        self.prefix_proj = nn.Linear(ZIP_PREFIX_EMB_DIM, 32, bias=False)
        nn.init.xavier_uniform_(self.prefix_proj.weight, gain=0.5)

        # Total input dimension to MLP:
        # geo(32) + state(32) + digit(16) + prefix(32) = 112
        mlp_input_dim = 32 + 32 + 16 + 32

        # Final combination MLP
        from featrix.neural.simple_mlp import SimpleMLP
        self.combine_mlp = SimpleMLP(
            SimpleMLPConfig(
                d_in=mlp_input_dim,
                d_out=config.d_out,
                d_hidden=config.d_hidden if hasattr(config, 'd_hidden') else 128,
                n_hidden_layers=2,
                dropout=config.dropout if hasattr(config, 'dropout') else 0.2,
                normalize=config.normalize if hasattr(config, 'normalize') else True,
                residual=True,
                use_batch_norm=config.use_batch_norm if hasattr(config, 'use_batch_norm') else True,
            )
        )

        # Replacement embedding for unknown/not present tokens
        self._replacement_embedding = nn.Parameter(torch.randn(config.d_out))

    @property
    def marginal_embedding(self):
        """Return the marginal embedding (same as replacement for masked/not present)."""
        if self.config.normalize:
            return F.normalize(self._replacement_embedding, dim=-1)
        return self._replacement_embedding

    def forward(self, token_batch):
        """
        Encode zip token batch into embeddings.

        Args:
            token_batch: TokenBatch with value tensor of shape [batch, 44]:
                - [:, 0:2] lat, long
                - [:, 2:18] state_region_embedding
                - [:, 18:28] digit_features
                - [:, 28:44] prefix_embedding

        Returns:
            (short_vec, full_vec) tuple of embeddings
        """
        values = token_batch.value  # [batch, 44]
        statuses = token_batch.status  # [batch]

        device = values.device
        batch_size = values.shape[0]

        # Ensure correct dtype for BFloat16 compatibility
        target_dtype = self.combine_mlp.linear_in.weight.dtype
        values = values.to(dtype=target_dtype)

        # Extract components
        geo_coords = values[:, 0:2]  # [batch, 2]
        state_emb = values[:, 2:2+ZIP_STATE_EMB_DIM]  # [batch, 16]
        digit_features = values[:, 2+ZIP_STATE_EMB_DIM:2+ZIP_STATE_EMB_DIM+ZIP_DIGIT_FEATURES_DIM]  # [batch, 10]
        prefix_emb = values[:, 2+ZIP_STATE_EMB_DIM+ZIP_DIGIT_FEATURES_DIM:]  # [batch, 16]

        # Project each component
        geo_proj = self.geo_proj(geo_coords)  # [batch, 32]
        state_proj = self.state_proj(state_emb)  # [batch, 32]
        digit_proj = self.digit_proj(digit_features)  # [batch, 16]
        prefix_proj = self.prefix_proj(prefix_emb)  # [batch, 32]

        # Concatenate all projections
        combined = torch.cat([geo_proj, state_proj, digit_proj, prefix_proj], dim=-1)  # [batch, 112]

        # Apply MLP
        full_vec = self.combine_mlp(combined)  # [batch, d_out]

        # Handle NOT_PRESENT and UNKNOWN tokens
        replacement = self._replacement_embedding.to(dtype=target_dtype)
        if self.config.normalize:
            replacement = F.normalize(replacement, dim=-1)

        # Mask for valid tokens
        valid_mask = (statuses == TokenStatus.OK).unsqueeze(-1).to(dtype=target_dtype)  # [batch, 1]

        # Replace invalid tokens with replacement embedding
        full_vec = valid_mask * full_vec + (1 - valid_mask) * replacement.unsqueeze(0)

        # Short vec is just a slice (for 3D visualization)
        short_vec = full_vec[:, :3]

        return short_vec, full_vec


def create_zip_codec(df_col, embed_dim: int = 768, string_cache=None, detector=None) -> ZipCodec:
    """
    Factory function to create a ZipCodec.

    Args:
        df_col: pandas Series containing zip code data
        embed_dim: embedding dimension (default 768)
        string_cache: optional string cache (not used currently)
        detector: optional detector instance

    Returns:
        ZipCodec instance
    """
    return ZipCodec(df_col, embed_dim=embed_dim, string_cache=string_cache, detector=detector)


# Quick test
if __name__ == '__main__':
    import pandas as pd

    test_zips = ['94105', '10001', '90210', '60601', '33101', '98101', '12345-6789', '', None]
    df = pd.Series(test_zips)

    codec = ZipCodec(df)

    print("Zip Code Codec Test")
    print("=" * 50)
    for z in test_zips:
        token = codec.tokenize(z)
        parsed = parse_zip_code(z)
        print(f"  {str(z):15} -> prefix={parsed['zip3']:4} status={token.status.name}, shape={token.value.shape}")
