"""
Runtime Version Manager for Model Inference

Downloads and caches specific code versions from the firmware server to enable
version-pinned model inference. This ensures models run with the exact code
version they were trained with, preventing prediction mismatches due to code changes.

See docs/MODEL_RUNTIME_INTEGRITY.md for the full design.

Usage:
    from runtime_version_manager import ensure_version_available, load_with_pinned_runtime

    # Get path to a specific version's code
    lib_path = ensure_version_available("1.2.3")

    # Or load a model with its pinned runtime automatically
    model = load_with_pinned_runtime("/path/to/model.pickle")
"""

import json
import logging
import os
import shutil
import sys
import tarfile
import tempfile
from pathlib import Path
from typing import Optional, Tuple
from urllib.request import urlopen, Request
from urllib.error import URLError

logger = logging.getLogger(__name__)

# Firmware server configuration
FIRMWARE_SERVER = "https://bits.featrix.com/sphere-firmware"
INDEX_URL = f"{FIRMWARE_SERVER}/index.json"

# Default cache directory for downloaded runtimes
# On server: /sphere/model_runtimes
# Fallback: ~/.featrix/model_runtimes
DEFAULT_CACHE_DIR = Path("/sphere/model_runtimes")
FALLBACK_CACHE_DIR = Path.home() / ".featrix" / "model_runtimes"


def _get_config_value(key: str, default):
    """Get a config value from SphereConfig if available, otherwise use default."""
    try:
        from featrix.neural.sphere_config import SphereConfig
        config = SphereConfig.get_instance()
        getter = getattr(config, f"get_{key}", None)
        if getter:
            return getter()
    except ImportError:
        pass
    except Exception as e:
        logger.debug(f"Could not get config value {key}: {e}")
    return default


def is_version_pinning_enabled() -> bool:
    """Check if runtime version pinning is enabled in config."""
    return _get_config_value("enable_runtime_version_pinning", True)


def is_strict_mode() -> bool:
    """Check if strict mode is enabled (fail if version can't be loaded)."""
    return _get_config_value("runtime_strict_mode", True)


def _get_cache_dir() -> Path:
    """Get the runtime cache directory, creating it if needed."""
    # Check config first
    config_dir = _get_config_value("runtime_cache_dir", None)
    if config_dir:
        cache_dir = Path(config_dir)
        if cache_dir.parent.exists() or cache_dir == DEFAULT_CACHE_DIR:
            cache_dir.mkdir(parents=True, exist_ok=True)
            return cache_dir

    # Fallback to defaults
    if DEFAULT_CACHE_DIR.parent.exists():
        cache_dir = DEFAULT_CACHE_DIR
    else:
        cache_dir = FALLBACK_CACHE_DIR

    cache_dir.mkdir(parents=True, exist_ok=True)
    return cache_dir


def get_runtime_path(version: str) -> Path:
    """
    Get path to cached runtime for a specific version.

    Args:
        version: Semantic version string (e.g., "1.2.3")

    Returns:
        Path to the lib directory containing featrix.neural
    """
    return _get_cache_dir() / version / "lib"


def is_version_cached(version: str) -> bool:
    """
    Check if a version is already downloaded and ready to use.

    Args:
        version: Semantic version string

    Returns:
        True if the version is cached and appears valid
    """
    runtime_path = get_runtime_path(version)
    # Check for a key file to verify the extraction was complete
    marker_file = runtime_path / "featrix" / "neural" / "single_predictor.py"
    return marker_file.exists()


def _fetch_firmware_index() -> dict:
    """
    Fetch the firmware index from the server.

    Returns:
        Dictionary with 'files' list containing available versions

    Raises:
        URLError: If the server is unreachable
        json.JSONDecodeError: If the response is invalid JSON
    """
    req = Request(INDEX_URL)
    req.add_header('User-Agent', 'Featrix-Runtime-Manager/1.0')

    with urlopen(req, timeout=30) as response:
        return json.loads(response.read().decode('utf-8'))


def _find_version_url(version: str, index_data: dict) -> Optional[str]:
    """
    Find the download URL for a specific version in the firmware index.

    Args:
        version: Semantic version string (e.g., "1.2.3")
        index_data: Firmware index dictionary

    Returns:
        URL to download the tarball, or None if not found
    """
    files = index_data.get('files', [])

    for file_info in files:
        filename = file_info.get('filename', '')
        # Filenames are like: sphere-app-1.2.3.tar.gz
        if f"sphere-app-{version}.tar.gz" in filename:
            return f"{FIRMWARE_SERVER}/{filename}"

    return None


def download_version(version: str) -> Path:
    """
    Download a specific version from the firmware server.

    Args:
        version: Semantic version string (e.g., "1.2.3")

    Returns:
        Path to the lib directory containing featrix.neural

    Raises:
        ValueError: If the version is not found on the server
        URLError: If the download fails
        RuntimeError: If extraction fails
    """
    # Check if already cached
    if is_version_cached(version):
        logger.info(f"✅ Version {version} already cached")
        return get_runtime_path(version)

    logger.info(f"📥 Downloading version {version} from firmware server...")

    # Fetch index to find the tarball URL
    try:
        index_data = _fetch_firmware_index()
    except URLError as e:
        logger.error(f"❌ Failed to fetch firmware index: {e}")
        raise

    # Find the version
    tarball_url = _find_version_url(version, index_data)
    if not tarball_url:
        raise ValueError(
            f"Version {version} not found on firmware server. "
            f"Available versions can be listed with 'ffsh upgrade list'."
        )

    logger.info(f"📦 Downloading from: {tarball_url}")

    # Download to temp directory
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        tarball_path = temp_path / "package.tar.gz"

        # Download the tarball
        req = Request(tarball_url)
        req.add_header('User-Agent', 'Featrix-Runtime-Manager/1.0')

        try:
            with urlopen(req, timeout=300) as response:
                total_size = response.headers.get('Content-Length')
                if total_size:
                    logger.info(f"   Size: {int(total_size) / 1024 / 1024:.1f} MB")

                with open(tarball_path, 'wb') as f:
                    f.write(response.read())
        except URLError as e:
            logger.error(f"❌ Download failed: {e}")
            raise

        logger.info(f"   Downloaded: {tarball_path.stat().st_size / 1024 / 1024:.1f} MB")

        # Extract the tarball
        logger.info(f"📂 Extracting...")
        with tarfile.open(tarball_path, 'r:gz') as tar:
            tar.extractall(temp_path)

        # Find the lib directory in the extracted content
        extracted_lib = None
        search_paths = [
            temp_path / "sphere-app" / "src" / "lib",
            temp_path / "src" / "lib",
        ]

        for candidate in search_paths:
            if candidate.exists():
                extracted_lib = candidate
                break

        # Also check subdirectories (tarball might have a version-named root)
        if not extracted_lib:
            for item in temp_path.iterdir():
                if item.is_dir():
                    for candidate in [item / "src" / "lib", item / "lib"]:
                        if candidate.exists():
                            extracted_lib = candidate
                            break
                    if extracted_lib:
                        break

        if not extracted_lib:
            raise RuntimeError(
                f"Could not find lib directory in {version} package. "
                f"Contents: {list(temp_path.rglob('*'))[:20]}"
            )

        # Verify the extraction looks valid
        neural_dir = extracted_lib / "featrix" / "neural"
        if not neural_dir.exists():
            raise RuntimeError(
                f"Extracted lib does not contain featrix/neural: {extracted_lib}"
            )

        # Copy to cache
        runtime_path = get_runtime_path(version)
        runtime_path.parent.mkdir(parents=True, exist_ok=True)

        if runtime_path.exists():
            shutil.rmtree(runtime_path)

        shutil.copytree(extracted_lib, runtime_path)
        logger.info(f"✅ Version {version} cached at: {runtime_path}")

    return runtime_path


def ensure_version_available(version: str) -> Path:
    """
    Ensure a version is available locally, downloading if needed.

    This is the main entry point for getting a version's code.

    Args:
        version: Semantic version string (e.g., "1.2.3")

    Returns:
        Path to the lib directory containing featrix.neural
    """
    if is_version_cached(version):
        return get_runtime_path(version)

    return download_version(version)


def get_model_runtime_version(model_path: str) -> Optional[str]:
    """
    Get the runtime version for a model.

    Looks for runtime_version.txt in the model's directory.

    Args:
        model_path: Path to the model pickle file

    Returns:
        Version string, or None if not found
    """
    model_path = Path(model_path)
    output_dir = model_path.parent

    version_file = output_dir / "runtime_version.txt"
    if version_file.exists():
        return version_file.read_text().strip()

    return None


def inject_runtime_into_path(version: str) -> Path:
    """
    Inject a specific version's code into sys.path.

    This modifies sys.path and purges cached modules so that
    subsequent imports use the specified version.

    Args:
        version: Semantic version string

    Returns:
        Path to the injected lib directory

    Warning:
        This is a global operation that affects all imports!
        Use with caution in multi-model scenarios.
    """
    runtime_lib = ensure_version_available(version)
    runtime_lib_str = str(runtime_lib)

    # Remove if already in path (to move to front)
    if runtime_lib_str in sys.path:
        sys.path.remove(runtime_lib_str)

    # Insert at front so it takes precedence
    sys.path.insert(0, runtime_lib_str)

    # Purge cached modules so they reload from the new path
    modules_to_purge = [
        mod for mod in list(sys.modules.keys())
        if mod.startswith('featrix.neural') or mod.startswith('lib.featrix.neural')
    ]

    for mod in modules_to_purge:
        del sys.modules[mod]

    logger.info(f"🔧 Injected runtime {version} into sys.path ({len(modules_to_purge)} modules purged)")

    return runtime_lib


def load_with_pinned_runtime(model_path: str, strict: bool = True):
    """
    Load a model using its pinned runtime version.

    This is the recommended way to load models for inference when
    version pinning is enabled.

    Args:
        model_path: Path to the model pickle file
        strict: If True, fail if version cannot be loaded.
               If False, fall back to current code with warning.

    Returns:
        Loaded model object

    Raises:
        RuntimeError: If strict=True and version loading fails
    """
    import pickle

    model_path = Path(model_path)

    # Get required version
    required_version = get_model_runtime_version(str(model_path))

    if required_version and required_version != 'unknown':
        try:
            inject_runtime_into_path(required_version)
            logger.info(f"✅ Using pinned runtime version: {required_version}")
        except Exception as e:
            msg = f"Failed to load pinned runtime {required_version}: {e}"
            if strict:
                raise RuntimeError(msg)
            else:
                logger.warning(f"⚠️  {msg}")
                logger.warning("   Falling back to current code - predictions may be incorrect!")
    else:
        logger.warning(
            f"⚠️  No runtime version found for {model_path.name} - using current code"
        )

    # Now load the model (will use pinned code if injection succeeded)
    with open(model_path, 'rb') as f:
        model = pickle.load(f)

    return model


def cleanup_old_runtimes(keep_versions: list = None, max_age_days: int = 30) -> int:
    """
    Remove old runtime versions to free disk space.

    Args:
        keep_versions: List of versions to never delete (e.g., currently in use)
        max_age_days: Delete versions older than this many days

    Returns:
        Number of versions deleted
    """
    from datetime import datetime, timedelta

    keep_versions = keep_versions or []
    cache_dir = _get_cache_dir()

    if not cache_dir.exists():
        return 0

    cutoff = datetime.now() - timedelta(days=max_age_days)
    deleted_count = 0

    for version_dir in cache_dir.iterdir():
        if not version_dir.is_dir():
            continue

        version = version_dir.name

        # Never delete versions in active use
        if version in keep_versions:
            continue

        # Check age
        mtime = datetime.fromtimestamp(version_dir.stat().st_mtime)
        if mtime < cutoff:
            logger.info(f"🗑️  Removing old runtime: {version}")
            try:
                shutil.rmtree(version_dir)
                deleted_count += 1
            except Exception as e:
                logger.warning(f"   Failed to remove {version}: {e}")

    if deleted_count > 0:
        logger.info(f"✅ Cleaned up {deleted_count} old runtime versions")

    return deleted_count


def list_cached_versions() -> list:
    """
    List all cached runtime versions.

    Returns:
        List of version strings
    """
    cache_dir = _get_cache_dir()

    if not cache_dir.exists():
        return []

    versions = []
    for version_dir in cache_dir.iterdir():
        if version_dir.is_dir() and is_version_cached(version_dir.name):
            versions.append(version_dir.name)

    return sorted(versions)
