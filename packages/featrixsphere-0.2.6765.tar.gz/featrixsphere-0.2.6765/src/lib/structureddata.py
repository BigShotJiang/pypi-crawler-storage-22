import hashlib
import sqlite3
import pandas as pd
import os
import sys
import logging
import json
import time
import shutil
from datetime import datetime

from pathlib import Path

# Set up Python path for featrix imports
try:
    from featrix.neural.logging_config import configure_logging
except (ModuleNotFoundError, ImportError):
    # Add current directory to path for featrix imports
    p = Path(__file__).parent
    if str(p) not in sys.path:
        sys.path.insert(0, str(p))

    try:
        from featrix.neural.logging_config import configure_logging
    except (ModuleNotFoundError, ImportError):
        # Fallback to basic logging if module not found
        import logging
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s [%(levelname)-8s] %(name)-45s: %(message)s'
        )
        def configure_logging():
            pass

configure_logging()
logger = logging.getLogger(__name__)

from featrix.neural.gpu_utils import get_device
device = get_device()  # Get device once at module level

from featrix.neural.featrix_csv import featrix_wrap_pd_read_csv
from featrix.neural.featrix_json import featrix_wrap_read_json_file

class CSVtoDB:
    def __init__(self, column_overrides=None, db_path=None, **kwargs):
        # CRITICAL: Don't create connection in __init__ if db_path will be set later
        # This prevents creating empty files (like data.db) that we don't actually use
        self.db_path = db_path or "data.db"
        self.conn = None
        self.cursor = None
        self.index = None

        self.column_overrides = column_overrides or {}  # Store column overrides

    def csv_to_sqlite(self, csv_path: str, table_name: str = "data"):
        # Check if file is JSONL or JSON format
        csv_path_obj = Path(csv_path)
        abs_path = csv_path_obj.resolve()
        file_extension = csv_path_obj.suffix.lower()
        logger.info(f"📄 Processing input file:")
        logger.info(f"   Raw path: {csv_path}")
        logger.info(f"   Absolute path: {abs_path}")
        logger.info(f"   File extension: {file_extension}")
        logger.info(f"   File exists: {csv_path_obj.exists()}")
        if csv_path_obj.exists():
            file_size = csv_path_obj.stat().st_size
            logger.info(f"   File size: {file_size / 1024 / 1024:.2f} MB ({file_size:,} bytes)")
        else:
            logger.error(f"   ❌ File does not exist at: {abs_path}")
        
        if file_extension in ['.jsonl', '.json']:
            # Trust the extension - parse as JSON/JSONL only
            if file_extension == '.jsonl':
                logger.info(f"📋 Detected JSONL file - parsing as JSON Lines (one JSON object per line)...")
            else:
                logger.info(f"📋 Detected JSON file - parsing as JSON...")
            
            read_start_time = time.time()
            try:
                df = featrix_wrap_read_json_file(csv_path)
                if df is None:
                    raise ValueError(f"JSON parsing returned None for {csv_path}")
            except Exception as e:
                logger.error(f"❌ Failed to parse {file_extension} file: {e}")
                raise ValueError(f"Failed to parse {file_extension} file {csv_path}: {e}")
            
            read_elapsed = time.time() - read_start_time
            logger.info(f"✅ JSON/JSONL file parsed in {read_elapsed:.1f} seconds")
        elif file_extension == '.parquet':
            # Parquet file
            logger.info(f"📦 Detected Parquet file - reading with pandas...")
            read_start_time = time.time()
            try:
                df = pd.read_parquet(csv_path)
            except Exception as e:
                logger.error(f"❌ Failed to read Parquet file: {e}")
                raise ValueError(f"Failed to parse Parquet file {csv_path}: {e}")
            read_elapsed = time.time() - read_start_time
            logger.info(f"✅ Parquet file read in {read_elapsed:.1f} seconds")
        elif file_extension in ['.csv', '.gz']:
            # Regular CSV file (or gzipped CSV) - trust the extension, no JSON parsing
            logger.info(f"📄 Detected CSV file - reading with pandas...")
            read_start_time = time.time()
            try:
                df = featrix_wrap_pd_read_csv(csv_path)
            except Exception as e:
                logger.error(f"❌ Failed to read CSV file: {e}")
                raise ValueError(f"Failed to parse CSV file {csv_path}: {e}")
            read_elapsed = time.time() - read_start_time
            logger.info(f"✅ CSV file read in {read_elapsed:.1f} seconds")
        else:
            # Unknown file extension - fail
            raise ValueError(f"Unsupported file extension '{file_extension}' for file {csv_path}. Supported formats: .csv, .gz, .parquet, .json, .jsonl")
        
        logger.info(f"🧹 Cleaning column names and string values...")
        df.columns = df.columns.str.strip()  # Strips spaces around column names
        df = df.map(lambda x: x.strip() if isinstance(x, str) else x)  # Strips spaces in string values
        logger.info(f"✅ Data cleaning complete")
        
        logger.info(f"📊 Data shape: {df.shape[0]} rows × {df.shape[1]} columns")

        # Log columns found after reading for debugging
        logger.info(f"📋 Columns ({len(df.columns)} total): {list(df.columns)[:50]}{'...' if len(df.columns) > 50 else ''}")
        if len(df.columns) > 50:
            logger.info(f"   ... and {len(df.columns) - 50} more columns")

        # 🛡️ DEFENSIVE CHECK: Convert any remaining dict/list objects to JSON strings for SQLite compatibility
        logger.info("🛡️ Performing final SQLite compatibility check...")
        for col in df.columns:
            # Check if any values in this column are dict/list objects
            dict_count = 0
            for idx, value in df[col].items():
                if isinstance(value, (dict, list)):
                    try:
                        df.at[idx, col] = json.dumps(value)
                        dict_count += 1
                    except (TypeError, ValueError):
                        df.at[idx, col] = str(value)
                        dict_count += 1
            
            if dict_count > 0:
                logger.warning(f"🔧 Converted {dict_count} dict/list objects to strings in column '{col}'")
        
        logger.info("✅ SQLite compatibility check complete")
        
        logger.info(f"💾 Writing data to SQLite table '{table_name}'...")
        sqlite_start_time = time.time()
        
        # Ensure we have a fresh connection before writing
        # Close existing connection if it exists
        try:
            if self.conn:
                self.conn.close()
        except Exception:
            pass
        
        # Create a fresh connection to ensure it's valid
        self.conn = sqlite3.connect(self.db_path)
        self.cursor = self.conn.cursor()
        
        try:
            # CRITICAL: Rename existing table instead of dropping it for safety
            # This preserves the old data as a backup in case something goes wrong
            self.cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table_name,))
            table_exists = self.cursor.fetchone() is not None
            
            if table_exists:
                # Generate backup table name with timestamp
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                backup_table_name = f"{table_name}_backup_{timestamp}"
                
                logger.info(f"💾 Renaming existing table '{table_name}' to '{backup_table_name}' for safety...")
                self.cursor.execute(f"ALTER TABLE {table_name} RENAME TO {backup_table_name}")
                self.conn.commit()
                logger.info(f"✅ Table '{table_name}' renamed to '{backup_table_name}'")
                
                # Clean up old backup tables (keep only the 3 most recent)
                # This prevents the database from growing indefinitely with backup tables
                self.cursor.execute("""
                    SELECT name FROM sqlite_master 
                    WHERE type='table' AND name LIKE ?
                    ORDER BY name DESC
                """, (f"{table_name}_backup_%",))
                backup_tables = [row[0] for row in self.cursor.fetchall()]
                
                if len(backup_tables) > 3:
                    # Drop the oldest backups, keeping only the 3 most recent
                    tables_to_drop = backup_tables[3:]  # Skip first 3 (most recent)
                    for old_backup in tables_to_drop:
                        logger.info(f"🗑️  Cleaning up old backup table '{old_backup}' (keeping 3 most recent)")
                        self.cursor.execute(f"DROP TABLE IF EXISTS {old_backup}")
                    self.conn.commit()
                    logger.info(f"✅ Cleaned up {len(tables_to_drop)} old backup tables")
            else:
                logger.info(f"ℹ️  Table '{table_name}' does not exist - will create new table")
            
            # Verify table doesn't exist before creating (safety check)
            self.cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table_name,))
            table_still_exists = self.cursor.fetchone() is not None
            
            if table_still_exists:
                logger.warning(f"⚠️  Table '{table_name}' still exists after rename attempt - using 'replace' mode as fallback")
                # Use 'replace' as fallback - this will drop and recreate, but we tried to preserve it
                if_exists_mode = 'replace'
            else:
                # Table doesn't exist (either never existed or was successfully renamed)
                if_exists_mode = 'fail'  # Will create new table, fail if somehow exists
            
            # Log DataFrame columns for debugging
            logger.info(f"📋 DataFrame columns ({len(df.columns)}): {list(df.columns)[:20]}{'...' if len(df.columns) > 20 else ''}")
            
            # Now create the table fresh with the current DataFrame schema
            df.to_sql(table_name, self.conn, if_exists=if_exists_mode, index=False)
            self.conn.commit()
            
            # Verify the table was created and has data
            self.cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
            row_count = self.cursor.fetchone()[0]
            if row_count == 0:
                raise ValueError(f"Table '{table_name}' was created but contains 0 rows. DataFrame had {len(df)} rows.")
            
            # Verify the database file is not empty
            db_file = Path(self.db_path)
            if db_file.exists():
                db_size = db_file.stat().st_size
                if db_size == 0:
                    raise ValueError(f"Database file {self.db_path} is 0 bytes after write operation")
                logger.info(f"   Database file size: {db_size / 1024 / 1024:.2f} MB")
            
            sqlite_elapsed = time.time() - sqlite_start_time
            logger.info(f"✅ Data written to SQLite in {sqlite_elapsed:.1f} seconds ({row_count:,} rows)")

            # Store data integrity stats alongside the data
            self.store_data_integrity(df, table_name=table_name)

        except Exception as e:
            sqlite_elapsed = time.time() - sqlite_start_time
            logger.error(f"❌ FAILED to write data to SQLite after {sqlite_elapsed:.1f} seconds")
            logger.error(f"   Error type: {type(e).__name__}")
            logger.error(f"   Error message: {str(e)}")
            logger.error(f"   DataFrame shape: {df.shape}")
            logger.error(f"   DataFrame columns ({len(df.columns)}): {list(df.columns)}")
            logger.error(f"   Database path: {self.db_path}")
            
            # Check what columns exist in the table (if it exists)
            try:
                self.cursor.execute(f"PRAGMA table_info({table_name})")
                existing_columns = [row[1] for row in self.cursor.fetchall()]
                if existing_columns:
                    logger.error(f"   Existing table columns: {existing_columns}")
                else:
                    logger.error(f"   Table '{table_name}' does not exist or has no columns")
            except Exception as pragma_error:
                logger.error(f"   Could not check existing table schema: {pragma_error}")
            # Check disk space
            try:
                import shutil
                stat = shutil.disk_usage(Path(self.db_path).parent)
                free_gb = stat.free / (1024**3)
                logger.error(f"   Disk space: {free_gb:.2f} GB free")
            except Exception:
                pass
            # Close connection on error
            try:
                if self.conn:
                    self.conn.close()
            except Exception:
                pass
            # Re-raise so the job fails properly
            raise

        # OK now that we have the data, we're done!
        # NOTE: We NO LONGER create a string cache here. The old StringCache class is deprecated.
        # The system now uses SimpleStringCache which is created on-demand per codec and calls
        # the string server directly. There's no need to pre-populate a cache file.
        # 
        # The strings_cache output field is kept for backward compatibility but will be None/empty.

    def csv_to_foundation_sqlite(
        self,
        csv_path: str,
        min_fill_rate: float = 0.40,
        warmup_fraction: float = 0.05,
        train_fraction: float = 0.80,
        val_fraction: float = 0.10,
        test_fraction: float = 0.05,
    ):
        """
        Create a foundation SQLite database for large dataset training.

        Foundation databases have:
        - Separate train/validation/test/warmup tables
        - Column types table for locked encoders
        - Metadata table with dataset statistics

        This is designed for datasets >= 100k rows that need:
        - Memory-efficient SQLite-backed storage during training
        - Chunked iteration through training data
        - Quality filtering (removes rows with too many nulls)

        Args:
            csv_path: Path to input CSV/Parquet/JSON file
            min_fill_rate: Minimum fill rate (1 - null_rate) for rows
            warmup_fraction: Fraction for warmup set (clean rows)
            train_fraction: Fraction for training set
            val_fraction: Fraction for validation set
            test_fraction: Fraction for test set
        """
        from featrix.neural.foundation_input_data import FeatrixFoundationInputData

        logger.info("=" * 80)
        logger.info("🏛️  CREATING FOUNDATION DATABASE")
        logger.info("=" * 80)
        logger.info(f"   Input file: {csv_path}")
        logger.info(f"   Output database: {self.db_path}")

        # Create foundation database using the FeatrixFoundationInputData class
        foundation = FeatrixFoundationInputData(
            input_path=csv_path,
            output_path=self.db_path,
            min_fill_rate=min_fill_rate,
            warmup_fraction=warmup_fraction,
            train_fraction=train_fraction,
            val_fraction=val_fraction,
            test_fraction=test_fraction,
        )

        foundation.build()

        # Store data integrity for the original (pre-filtered) data
        # The foundation DB is already created, so open a connection to it
        self.conn = sqlite3.connect(self.db_path)
        self.cursor = self.conn.cursor()
        self.store_data_integrity(foundation._df, table_name="foundation_input")
        self.conn.close()
        self.conn = None
        self.cursor = None

        # Store stats for get_output_files()
        self.foundation_stats = foundation.foundation_stats
        self.is_foundation_database = True

        logger.info("=" * 80)
        logger.info("✅ FOUNDATION DATABASE CREATED")
        logger.info("=" * 80)

    def get_output_files(self):
        # Build output dict - only include strings_cache if it actually exists
        output = dict(
            sqlite_db=self.db_path,
        )

        # Include foundation database flag if applicable
        if getattr(self, 'is_foundation_database', False):
            output['is_foundation_database'] = True
            if hasattr(self, 'foundation_stats') and self.foundation_stats:
                output['foundation_stats'] = {
                    'total_rows': self.foundation_stats.total_rows,
                    'filtered_rows': self.foundation_stats.filtered_rows,
                    'train_rows': self.foundation_stats.train_rows,
                    'val_rows': self.foundation_stats.val_rows,
                    'test_rows': self.foundation_stats.test_rows,
                    'warmup_rows': self.foundation_stats.warmup_rows,
                }
        
        # Only include strings_cache if it exists (we don't use it anymore)
        try:
            cwd = os.getcwd()
            cache_path = Path(cwd) / "strings.sqlite3"
        except FileNotFoundError:
            cache_path = Path(self.db_path).parent / "strings.sqlite3"
        
        cache_path = cache_path.resolve()
        if cache_path.exists():
            logger.debug(f"String cache exists at: {cache_path}")
            output['strings_cache'] = str(cache_path)
        else:
            logger.debug(f"String cache not created (not needed)")
        
        return output
    
    def close(self):
        if self.conn:
            self.conn.close()
            self.conn = None
            self.cursor = None

    def store_data_integrity(self, df, table_name="data"):
        """
        Compute and store data integrity statistics in the embedding_space.db.

        Creates two tables:
          - data_integrity: top-level stats (row/col counts, timestamp, checksums)
          - data_integrity_columns: per-column stats (null count, null rate, dtype, checksum)

        Args:
            df: The DataFrame that was written to SQLite
            table_name: The source table name (e.g. "data", "train", etc.)
        """
        if self.conn is None:
            logger.warning("No database connection — skipping data integrity storage")
            return

        try:
            start_time = time.time()

            # Create tables
            self.conn.execute("""
                CREATE TABLE IF NOT EXISTS data_integrity (
                    table_name TEXT PRIMARY KEY,
                    total_rows INTEGER NOT NULL,
                    total_columns INTEGER NOT NULL,
                    created_at TEXT NOT NULL,
                    sample_size INTEGER,
                    sample_row_checksums_json TEXT,
                    sample_col_checksums_json TEXT
                )
            """)

            self.conn.execute("""
                CREATE TABLE IF NOT EXISTS data_integrity_columns (
                    table_name TEXT NOT NULL,
                    column_name TEXT NOT NULL,
                    column_index INTEGER NOT NULL,
                    dtype TEXT,
                    null_count INTEGER NOT NULL,
                    null_rate REAL NOT NULL,
                    PRIMARY KEY (table_name, column_name)
                )
            """)

            nrows = len(df)
            ncols = len(df.columns)

            # Per-column stats
            for idx, col in enumerate(df.columns):
                null_count = int(df[col].isnull().sum())
                null_rate = null_count / nrows if nrows > 0 else 0.0
                dtype_str = str(df[col].dtype)

                self.conn.execute(
                    """
                    INSERT OR REPLACE INTO data_integrity_columns
                    (table_name, column_name, column_index, dtype, null_count, null_rate)
                    VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (table_name, col, idx, dtype_str, null_count, null_rate)
                )

            # Sample checksums (same approach as FeatrixDataIntegrity)
            SAMPLE_SIZE = 2500
            NULL_SENTINEL = "FEATRIX_FOUND_NULL"

            if nrows > SAMPLE_SIZE:
                sample_df = df.sample(n=SAMPLE_SIZE, random_state=42)
            else:
                sample_df = df

            # Row checksums on sample
            def row_checksum(row):
                filled = row.fillna(NULL_SENTINEL)
                row_str = ''.join(map(str, filled))
                return hashlib.sha256(row_str.encode('utf-8')).hexdigest()

            row_checksums = {
                str(i): row_checksum(sample_df.iloc[i])
                for i in range(len(sample_df))
            }

            # Column checksums on sample
            col_checksums = {}
            for col in sample_df.columns:
                filled = sample_df[col].fillna(NULL_SENTINEL)
                col_str = ''.join(map(str, filled))
                col_checksums[col] = hashlib.sha256(col_str.encode('utf-8')).hexdigest()

            self.conn.execute(
                """
                INSERT OR REPLACE INTO data_integrity
                (table_name, total_rows, total_columns, created_at, sample_size,
                 sample_row_checksums_json, sample_col_checksums_json)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    table_name,
                    nrows,
                    ncols,
                    datetime.utcnow().isoformat(),
                    len(sample_df),
                    json.dumps(row_checksums),
                    json.dumps(col_checksums),
                )
            )

            self.conn.commit()
            elapsed = time.time() - start_time
            logger.info(f"✅ Data integrity stored for '{table_name}': {nrows} rows × {ncols} cols ({elapsed:.2f}s)")

        except Exception as e:
            logger.error(f"Failed to store data integrity for '{table_name}': {e}")
            import traceback
            traceback.print_exc()