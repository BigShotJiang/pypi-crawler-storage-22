#!/usr/bin/env python3
"""
Persistent prediction server that keeps models loaded in memory/GPU.
Celery tasks communicate with this server via HTTP to avoid reloading models.
"""

import sys
import json
import logging
import traceback
import time
import threading
from pathlib import Path
from typing import Optional, Dict, Any
from http.server import HTTPServer, BaseHTTPRequestHandler
import socketserver

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)-8s] %(name)-45s: %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)

# Set up Python paths
current_path = Path(__file__).parent
lib_path = current_path / "lib"

if str(lib_path.resolve()) not in sys.path:
    sys.path.insert(0, str(lib_path.resolve()))
if str(current_path.resolve()) not in sys.path:
    sys.path.insert(0, str(current_path.resolve()))

logger.info(f"✅ Paths configured: lib={lib_path}, current={current_path}")


def _run_checkpoint_verification(model) -> dict:
    """
    Run checkpoint verification and return stats.

    Returns dict with:
        - verified: bool (True if verification passed or no samples available)
        - n_samples: int (number of samples tested)
        - n_mismatches: int (number of mismatches)
        - max_diff: float (maximum probability difference)
        - mean_diff: float (mean probability difference)
        - std_diff: float (std of probability differences)
        - source: str ("checkpoint", "epoch_db", or "none")
    """
    try:
        from featrix.neural.checkpoint_validation import verify_checkpoint_predictions

        # Check what source we have
        has_checkpoint_samples = hasattr(model, '_checkpoint_validation_samples') and model._checkpoint_validation_samples
        source = "checkpoint" if has_checkpoint_samples else "epoch_db"

        success, mismatches = verify_checkpoint_predictions(model, tolerance=1e-4, log_details=True)

        # Compute stats from mismatches
        if mismatches:
            diffs = [m.get('max_diff', 0.0) for m in mismatches if 'max_diff' in m]
            if diffs:
                import statistics
                max_diff = max(diffs)
                mean_diff = statistics.mean(diffs)
                std_diff = statistics.stdev(diffs) if len(diffs) > 1 else 0.0
            else:
                max_diff = mean_diff = std_diff = 0.0
        else:
            max_diff = mean_diff = std_diff = 0.0

        # Get sample count
        n_samples = len(getattr(model, '_checkpoint_validation_samples', []))
        if n_samples == 0:
            # Samples came from db fallback - check if we have any
            source = "none" if not success else source

        return {
            'verified': success,
            'n_samples': n_samples,
            'n_mismatches': len(mismatches),
            'max_diff': max_diff,
            'mean_diff': mean_diff,
            'std_diff': std_diff,
            'source': source,
        }

    except Exception as e:
        logger.warning(f"⚠️  Checkpoint verification failed: {e}")
        return {
            'verified': None,  # Unknown - verification failed
            'n_samples': 0,
            'n_mismatches': 0,
            'max_diff': 0.0,
            'mean_diff': 0.0,
            'std_diff': 0.0,
            'source': 'error',
            'error': str(e),
        }


class ModelCache:
    """LRU cache for loaded models with GPU memory management."""

    # Timeout for waiting on another thread to load a model (5 minutes)
    LOAD_WAIT_TIMEOUT = 300

    def __init__(self, max_size: int = 3):
        self.max_size = max_size
        self.cache = {}  # predictor_path -> (model, last_access_time)
        self.access_times = {}  # predictor_path -> access_time
        self._locks = {}  # predictor_path -> threading.Lock
        self._locks_lock = threading.Lock()  # protects _locks dict
        logger.info(f"💾 Model cache initialized (max_size={max_size})")

    def _get_lock(self, predictor_path: str) -> threading.Lock:
        """Get or create a lock for a specific predictor path."""
        with self._locks_lock:
            if predictor_path not in self._locks:
                self._locks[predictor_path] = threading.Lock()
            return self._locks[predictor_path]

    def get_or_load(self, predictor_path: str, load_func):
        """Get model from cache, or load it using load_func if not cached.

        Only one thread will load a given model; others wait for it.
        On CUDA OOM, evicts all cached models and retries.
        Returns (model, was_cache_hit).
        """
        import torch

        # Fast path: already cached
        if predictor_path in self.cache:
            current_time = time.time()
            self.cache[predictor_path] = (self.cache[predictor_path][0], current_time)
            self.access_times[predictor_path] = current_time
            logger.info(f"✅ CACHE HIT: {Path(predictor_path).name}")
            return self.cache[predictor_path][0], True

        # Slow path: need to load, but only one thread should do it
        lock = self._get_lock(predictor_path)

        # Try to acquire lock with timeout
        acquired = lock.acquire(timeout=self.LOAD_WAIT_TIMEOUT)
        if not acquired:
            logger.error(f"⏰ TIMEOUT waiting for model load: {Path(predictor_path).name}")
            raise TimeoutError(f"Timeout waiting for model to load: {predictor_path}")

        try:
            # Check again - another thread may have loaded it while we waited
            if predictor_path in self.cache:
                current_time = time.time()
                self.cache[predictor_path] = (self.cache[predictor_path][0], current_time)
                self.access_times[predictor_path] = current_time
                logger.info(f"✅ CACHE HIT (after wait): {Path(predictor_path).name}")
                return self.cache[predictor_path][0], True

            # We're the loader - try to load, retry on OOM after evicting cache
            for attempt in range(2):
                try:
                    logger.info(f"📦 Loading model (attempt {attempt + 1}): {Path(predictor_path).name}")
                    start_time = time.time()
                    model = load_func(predictor_path)
                    load_time = time.time() - start_time
                    logger.info(f"✅ Model loaded in {load_time:.1f}s: {Path(predictor_path).name}")

                    # Cache it
                    self.put(predictor_path, model)
                    return model, False

                except (torch.cuda.OutOfMemoryError, RuntimeError) as e:
                    error_msg = str(e).lower()
                    if 'cuda out of memory' in error_msg or 'out of memory' in error_msg:
                        if attempt == 0 and len(self.cache) > 0:
                            logger.warning(f"⚠️  CUDA OOM loading {Path(predictor_path).name} - evicting cache and retrying...")
                            self.evict_all()
                            continue  # Retry after eviction
                        else:
                            logger.error(f"❌ CUDA OOM even after evicting cache: {e}")
                            raise
                    else:
                        raise  # Not an OOM error, re-raise

        finally:
            lock.release()

    def get(self, predictor_path: str):
        """Get a model from cache if available."""
        if predictor_path in self.cache:
            current_time = time.time()
            self.cache[predictor_path] = (self.cache[predictor_path][0], current_time)
            self.access_times[predictor_path] = current_time
            logger.info(f"✅ CACHE HIT: {Path(predictor_path).name}")
            return self.cache[predictor_path][0]
        logger.info(f"❌ CACHE MISS: {Path(predictor_path).name}")
        return None
    
    def put(self, predictor_path: str, model):
        """Add a model to cache, evicting LRU if needed."""
        current_time = time.time()
        
        # If cache is full, remove least recently used
        if len(self.cache) >= self.max_size and predictor_path not in self.cache:
            lru_path = min(self.access_times.keys(), key=lambda k: self.access_times[k])
            logger.info(f"🗑️  CACHE EVICT: {Path(lru_path).name}")
            
            # Clean up GPU memory for evicted model
            try:
                evicted_model = self.cache[lru_path][0]
                if hasattr(evicted_model, 'cleanup_gpu_memory'):
                    evicted_model.cleanup_gpu_memory()
                    logger.info("✅ GPU memory cleaned for evicted model")
            except Exception as e:
                logger.warning(f"Failed to cleanup evicted model: {e}")
            
            del self.cache[lru_path]
            del self.access_times[lru_path]
        
        # Add new model to cache
        self.cache[predictor_path] = (model, current_time)
        self.access_times[predictor_path] = current_time
        logger.info(f"✅ CACHE ADD: {Path(predictor_path).name}")
    
    def evict_all(self):
        """Evict all models from cache and free GPU memory."""
        import torch

        evicted_count = 0
        for path in list(self.cache.keys()):
            try:
                model = self.cache[path][0]
                if hasattr(model, 'cleanup_gpu_memory'):
                    model.cleanup_gpu_memory()
                del self.cache[path]
                del self.access_times[path]
                evicted_count += 1
            except Exception as e:
                logger.warning(f"Error evicting {Path(path).name}: {e}")

        # Force GPU memory cleanup
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            torch.cuda.synchronize()

        logger.info(f"🗑️  EVICTED ALL: {evicted_count} models, GPU cache cleared")
        return evicted_count

    def stats(self):
        """Get cache statistics."""
        return {
            "size": len(self.cache),
            "max_size": self.max_size,
            "cached_models": [Path(p).name for p in self.cache.keys()]
        }


# Global model cache
model_cache = ModelCache(max_size=3)


class PredictionRequestHandler(BaseHTTPRequestHandler):
    """HTTP request handler for prediction requests."""
    
    def log_message(self, format, *args):
        """Override to use our logger."""
        logger.info(f"{self.address_string()} - {format % args}")
    
    def do_POST(self):
        """Handle POST requests for predictions and model card generation."""
        try:
            # Read request body
            content_length = int(self.headers['Content-Length'])
            request_body = self.rfile.read(content_length)
            request_data = json.loads(request_body.decode('utf-8'))
            
            # Route to appropriate handler
            if self.path == '/generate_model_card':
                self._handle_generate_model_card(request_data)
                return
            
            predictor_path = request_data.get('predictor_path')
            records = request_data.get('records', [])
            batch_size = request_data.get('batch_size', 256)
            
            if not predictor_path or not records:
                self.send_error(400, "Missing predictor_path or records")
                return
            
            logger.info(f"🔍 Prediction request: {len(records)} records for {Path(predictor_path).name}")

            # Load or get cached model (with locking to prevent duplicate loads)
            # Also stores verification results on the model for later retrieval
            def load_model(path):
                import torch

                # Try to use version-pinned runtime if available
                # This ensures the model runs with the exact code version it was trained with
                pinned_version = None
                try:
                    from runtime_version_manager import (
                        get_model_runtime_version,
                        inject_runtime_into_path,
                        is_version_pinning_enabled,
                        is_strict_mode,
                    )

                    if not is_version_pinning_enabled():
                        logger.info("ℹ️  Runtime version pinning disabled in config")
                    else:
                        pinned_version = get_model_runtime_version(path)
                        if pinned_version and pinned_version != 'unknown':
                            logger.info(f"🔧 Model requires runtime version: {pinned_version}")
                            try:
                                inject_runtime_into_path(pinned_version)
                                logger.info(f"✅ Using pinned runtime: {pinned_version}")
                            except Exception as e:
                                if is_strict_mode():
                                    raise RuntimeError(
                                        f"Failed to load pinned runtime {pinned_version}: {e}\n"
                                        f"Set runtime_strict_mode=false in config to fall back to current code."
                                    )
                                logger.warning(f"⚠️  Failed to load pinned runtime {pinned_version}: {e}")
                                logger.warning("   Falling back to current code - will rely on integrity check")
                        else:
                            logger.info("ℹ️  No pinned runtime version - using current code")
                except ImportError:
                    logger.debug("runtime_version_manager not available - using current code")
                except RuntimeError:
                    raise  # Re-raise strict mode failures
                except Exception as e:
                    logger.warning(f"⚠️  Error checking pinned runtime: {e}")

                # Now import and load (will use pinned code if injection succeeded)
                from single_predictor_training import load_single_predictor

                # Use centralized loader which handles:
                # - torch.load with map_location='cpu' to avoid CUDA OOM during unpickling
                # - Fallback to pickle.load for older files
                # - Setting models to eval mode
                # - Device synchronization
                model = load_single_predictor(path)
                model._pinned_runtime_version = pinned_version  # Store for diagnostics

                # Hydrate to GPU if available
                if torch.cuda.is_available():
                    logger.info("🔄 Hydrating to GPU...")
                    model.hydrate_to_gpu_if_needed()
                    if hasattr(model, 'embedding_space') and model.embedding_space is not None:
                        model.embedding_space.hydrate_to_gpu_if_needed()

                    gpu_memory_mb = torch.cuda.memory_allocated() / 1024 / 1024
                    logger.info(f"🖥️  GPU Memory: {gpu_memory_mb:.1f}MB")

                # Run checkpoint verification and store results on model
                model._behavioral_consistency_report = _run_checkpoint_verification(model)

                # CRITICAL: Fail if integrity check failed
                # This prevents serving predictions from a model that may have been
                # trained with different code than what's currently running
                report = model._behavioral_consistency_report
                if report.get('verified') is False:
                    n_mismatches = report.get('n_mismatches', 0)
                    max_diff = report.get('max_diff', 0.0)
                    source = report.get('source', 'unknown')
                    raise RuntimeError(
                        f"MODEL INTEGRITY CHECK FAILED - refusing to serve predictions.\n"
                        f"  Samples tested from: {source}\n"
                        f"  Mismatches: {n_mismatches}\n"
                        f"  Max probability diff: {max_diff:.6f}\n"
                        f"  This model was likely saved with a different code version.\n"
                        f"  Options:\n"
                        f"    1. Retrain the model with current code\n"
                        f"    2. Restore the code version used during training\n"
                        f"    3. Check docs/MODEL_RUNTIME_INTEGRITY.md for version pinning"
                    )

                return model

            fsp, was_cached = model_cache.get_or_load(predictor_path, load_model)
            
            # Make predictions
            logger.info(f"🚀 Running batch prediction...")
            predictions = fsp.predict_batch(
                records,
                batch_size=batch_size,
                debug_print=False,
                extended_result=True
            )
            
            logger.info(f"✅ Completed {len(predictions)} predictions")

            # Log batch summary (column counts are same for all records)
            if predictions:
                first_pred = predictions[0]

                # Log column counts once (same for all records in batch)
                original_cols = len(first_pred.get('original_query', {}))
                actual_cols = len(first_pred.get('actual_query', {}))
                ignored_cols = len(first_pred.get('ignored_query_columns', []))
                available_cols = len(first_pred.get('available_query_columns', []))
                logger.info(f"[Batch] columns: original={original_cols}, actual={actual_cols}, ignored={ignored_cols}, available={available_cols}")

                # Analyze guardrail warnings across all predictions
                # Track which columns have warnings and in how many rows
                col_warning_counts = {}  # col -> count of rows with warnings
                total_rows = len(predictions)

                for pred in predictions:
                    guardrails = pred.get('guardrails', {})
                    for col, checks in guardrails.items():
                        for check_msg in checks.keys():
                            if 'Warning' in check_msg:
                                col_warning_counts[col] = col_warning_counts.get(col, 0) + 1
                                break

                if col_warning_counts:
                    # Group by percentage of rows affected
                    all_rows_cols = [c for c, cnt in col_warning_counts.items() if cnt == total_rows]
                    most_rows_cols = [c for c, cnt in col_warning_counts.items() if cnt >= total_rows * 0.5 and cnt < total_rows]
                    some_rows_cols = [c for c, cnt in col_warning_counts.items() if cnt < total_rows * 0.5]

                    if all_rows_cols:
                        logger.info(f"[Batch] guardrails: {len(all_rows_cols)} columns with warnings in 100% of rows (likely ignored columns not in training)")
                    if most_rows_cols:
                        logger.info(f"[Batch] guardrails: {len(most_rows_cols)} columns with warnings in >50% of rows: {most_rows_cols[:5]}{'...' if len(most_rows_cols) > 5 else ''}")
                    if some_rows_cols:
                        logger.info(f"[Batch] guardrails: {len(some_rows_cols)} columns with warnings in <50% of rows: {some_rows_cols[:5]}{'...' if len(some_rows_cols) > 5 else ''}")

            # Log individual prediction results with per-row guardrails
            for i, pred in enumerate(predictions):
                results = pred.get('results', {})
                prediction = results.get('prediction')
                confidence = results.get('confidence', 0)
                threshold = results.get('threshold')
                threshold_str = f", threshold={threshold}" if threshold is not None else ""

                # Count row-specific guardrail warnings (excluding 100%-of-rows warnings)
                guardrails = pred.get('guardrails', {})
                row_specific_warnings = []
                for col, checks in guardrails.items():
                    # Skip if this column has warnings in all rows (already logged at batch level)
                    if col_warning_counts.get(col, 0) == total_rows:
                        continue
                    for check_msg in checks.keys():
                        if 'Warning' in check_msg:
                            row_specific_warnings.append(col)
                            break

                warning_str = f", warnings={row_specific_warnings}" if row_specific_warnings else ""
                logger.info(f"[{i+1}/{len(predictions)}] prediction={prediction}, confidence={confidence:.4f}{threshold_str}{warning_str}")
            # Extract model metadata that API needs
            target_col_name = getattr(fsp, 'target_col_name', None)
            target_col_type = getattr(fsp, 'target_col_type', None)

            # Extract class labels for classification models
            class_labels = None
            pos_label = None
            if hasattr(fsp, 'target_codec') and hasattr(fsp.target_codec, 'members'):
                # Get all class labels excluding <UNKNOWN>
                class_labels = sorted([m for m in fsp.target_codec.members if m != '<UNKNOWN>'])
            # Get positive label for binary classification
            pos_label = getattr(fsp, '_pos_label', None)

            # Get optimal threshold if available
            optimal_threshold = getattr(fsp, 'optimal_threshold', None)

            # Load training metrics if available
            model_quality_metrics = None
            try:
                metrics_path = Path(predictor_path).parent / "training_metrics.json"
                if metrics_path.exists():
                    with open(metrics_path) as f:
                        metrics_data = json.load(f)
                        model_quality_metrics = metrics_data.get("quality_metrics", {})
                        if model_quality_metrics:
                            logger.info("✅ Loaded model quality metrics")
            except Exception as metrics_error:
                logger.warning(f"Could not load training metrics: {metrics_error}")

            # Get verification stats (computed on model load)
            verification_stats = getattr(fsp, '_behavioral_consistency_report', None)

            # Get pinned runtime version info
            pinned_runtime_version = getattr(fsp, '_pinned_runtime_version', None)

            # Build response with all metadata API needs
            response_data = {
                'success': True,
                'predictions': predictions,
                'total_records': len(records),
                'target_col_name': target_col_name,
                'target_col_type': target_col_type,
                'class_labels': class_labels,
                'pos_label': pos_label,
                'optimal_threshold': float(optimal_threshold) if optimal_threshold is not None else None,
                'model_quality_metrics': model_quality_metrics,
                'cache_stats': model_cache.stats(),
                'behavioral_consistency_report': verification_stats,
                'pinned_runtime_version': pinned_runtime_version,
            }
            
            # Send response
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps(response_data).encode('utf-8'))
            
        except Exception as e:
            logger.error(f"❌ Prediction failed: {e}")
            logger.error(traceback.format_exc())
            
            error_response = {
                'success': False,
                'error': str(e),
                'traceback': traceback.format_exc()
            }
            
            self.send_response(500)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps(error_response).encode('utf-8'))
    
    def _handle_generate_model_card(self, request_data):
        """Generate model card for a session using loaded model (predictor or embedding space)."""
        try:
            session_id = request_data.get('session_id')
            predictor_path = request_data.get('predictor_path')
            embedding_space_path = request_data.get('embedding_space_path')
            output_dir = request_data.get('output_dir')

            if not output_dir:
                self.send_error(400, "Missing output_dir")
                return
            if not predictor_path and not embedding_space_path:
                self.send_error(400, "Missing predictor_path or embedding_space_path")
                return

            logger.info(f"📋 Model card request for: {session_id}")

            if predictor_path:
                model, model_card = self._generate_predictor_model_card(predictor_path)
            else:
                model, model_card = self._generate_es_model_card(embedding_space_path)

            # Save to disk
            output_path = Path(output_dir)
            output_path.mkdir(parents=True, exist_ok=True)
            card_path = output_path / "model_card.json"

            with open(card_path, 'w') as f:
                json.dump(model_card, f, indent=2, default=str)

            logger.info(f"✅ Model card saved: {card_path}")

            response = {
                'success': True,
                'model_card_path': str(card_path),
                'session_id': session_id
            }

            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps(response).encode('utf-8'))

        except Exception as e:
            logger.error(f"❌ Model card generation failed: {e}")
            logger.error(traceback.format_exc())

            self.send_response(500)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({
                'success': False,
                'error': str(e)
            }).encode('utf-8'))

    def _generate_predictor_model_card(self, predictor_path):
        """Load a predictor and generate its model card."""
        def load_model(path):
            import torch

            # Try to use version-pinned runtime (same as prediction path)
            try:
                from runtime_version_manager import (
                    get_model_runtime_version,
                    inject_runtime_into_path,
                    is_version_pinning_enabled,
                )

                if is_version_pinning_enabled():
                    pinned_version = get_model_runtime_version(path)
                    if pinned_version and pinned_version != 'unknown':
                        try:
                            inject_runtime_into_path(pinned_version)
                            logger.info(f"✅ Model card: using pinned runtime {pinned_version}")
                        except Exception as e:
                            logger.warning(f"⚠️  Failed to load pinned runtime: {e}")
            except ImportError:
                pass
            except Exception as e:
                logger.warning(f"⚠️  Error checking pinned runtime: {e}")

            from single_predictor_training import load_single_predictor

            model = load_single_predictor(path)

            if torch.cuda.is_available():
                model.hydrate_to_gpu_if_needed()
                if hasattr(model, 'embedding_space') and model.embedding_space is not None:
                    model.embedding_space.hydrate_to_gpu_if_needed()

            # Run checkpoint verification (same as prediction path)
            model._behavioral_consistency_report = _run_checkpoint_verification(model)

            # CRITICAL: Fail if integrity check failed
            report = model._behavioral_consistency_report
            if report.get('verified') is False:
                raise RuntimeError(
                    f"MODEL INTEGRITY CHECK FAILED - model card generation blocked.\n"
                    f"  Mismatches: {report.get('n_mismatches', 0)}\n"
                    f"  Max probability diff: {report.get('max_diff', 0.0):.6f}"
                )

            return model

        fsp, _ = model_cache.get_or_load(predictor_path, load_model)

        if not hasattr(fsp, '_create_model_card_json'):
            raise RuntimeError('Predictor model does not have _create_model_card_json method')

        return fsp, fsp._create_model_card_json()

    def _generate_es_model_card(self, embedding_space_path):
        """Load a foundational embedding space and generate its model card."""
        def load_es(path):
            import torch
            from featrix.neural.io_utils import load_embedded_space

            es = load_embedded_space(path, force_cpu=not torch.cuda.is_available(), skip_datasets=True)

            if torch.cuda.is_available():
                es.hydrate_to_gpu_if_needed()

            return es

        es, _ = model_cache.get_or_load(embedding_space_path, load_es)

        if not hasattr(es, '_create_model_card_json'):
            raise RuntimeError('Embedding space does not have _create_model_card_json method')

        # Determine best epoch from training info
        best_epoch_idx = es.training_info.get('best_checkpoint_epoch', 0)
        loss_history = es.training_info.get('progress_info', {}).get('loss_history', [])
        if best_epoch_idx >= len(loss_history) and loss_history:
            best_epoch_idx = len(loss_history) - 1

        return es, es._create_model_card_json(best_epoch_idx, metadata=None)
    
    def do_GET(self):
        """Handle GET requests for health check and stats."""
        if self.path == '/health':
            response = {
                'status': 'healthy',
                'cache_stats': model_cache.stats()
            }
            
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps(response).encode('utf-8'))
        else:
            self.send_error(404, "Not found")


def run_server(host='127.0.0.1', port=8765):
    """Run the prediction server."""
    logger.info(f"🚀 Starting prediction server on {host}:{port}")
    
    # Use ThreadingMixIn for concurrent requests
    class ThreadedHTTPServer(socketserver.ThreadingMixIn, HTTPServer):
        daemon_threads = True
    
    server = ThreadedHTTPServer((host, port), PredictionRequestHandler)
    
    logger.info(f"✅ Prediction server ready - listening on http://{host}:{port}")
    logger.info(f"💾 Model cache size: {model_cache.max_size} models")
    
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        logger.info("🛑 Shutting down prediction server...")
        server.shutdown()


if __name__ == '__main__':
    import argparse
    
    parser = argparse.ArgumentParser(description='Persistent prediction server')
    parser.add_argument('--host', default='127.0.0.1', help='Host to bind to')
    parser.add_argument('--port', type=int, default=8765, help='Port to bind to')
    parser.add_argument('--cache-size', type=int, default=3, help='Max models to cache')
    
    args = parser.parse_args()
    
    # Update cache size if specified
    if args.cache_size != 3:
        model_cache.max_size = args.cache_size
        logger.info(f"💾 Model cache size set to: {args.cache_size}")
    
    run_server(host=args.host, port=args.port)

