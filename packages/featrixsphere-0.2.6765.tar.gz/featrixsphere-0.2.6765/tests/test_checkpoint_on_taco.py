#!/usr/bin/env python3
"""
Test loading a checkpoint and running predict_batch on taco.
This script should be run on taco where GPU is available.
"""
import sys
sys.path.insert(0, "/sphere/app/lib")
sys.path.insert(0, "/sphere/app")

import pickle
import torch

# Try loading the actual session checkpoint
# This is the ROC-AUC best at epoch 64
checkpoint_path = "/sphere/app/featrix_output/predictor-dot_model_20260123_e7f-b2ed3644-aaec-4d9b-a5e5-9e2cc4519893/train_single_predictor_08c02ed5-a30f-40a9-9fb9-b5e74bcdac99/20260123_113620_best_single_predictor_auc_roc_0.7468_epoch_64.pickle"

print("=" * 60)
print(f"Loading checkpoint: {checkpoint_path}")
print("=" * 60)

with open(checkpoint_path, "rb") as f:
    sp = pickle.load(f)

print(f"Loaded! Type: {type(sp)}")
print(f"Has predictor: {hasattr(sp, 'predictor') and sp.predictor is not None}")
print(f"Has predictor_base: {hasattr(sp, 'predictor_base')}")
print(f"predictor_base value: {sp.predictor_base if hasattr(sp, 'predictor_base') else 'N/A'}")
print(f"Has embedding_space: {hasattr(sp, 'embedding_space') and sp.embedding_space is not None}")
print(f"Has target_codec: {hasattr(sp, 'target_codec') and sp.target_codec is not None}")

if hasattr(sp, 'target_codec') and sp.target_codec is not None:
    print(f"Target codec type: {type(sp.target_codec)}")
    if hasattr(sp.target_codec, 'members'):
        print(f"Target codec members: {sp.target_codec.members}")

# Check predictor structure
if hasattr(sp, 'predictor') and sp.predictor is not None:
    print(f"\nPredictor structure:")
    print(f"  Type: {type(sp.predictor)}")
    if hasattr(sp.predictor, '__len__'):
        for i, module in enumerate(sp.predictor):
            print(f"  [{i}] {type(module).__name__}")

# Check if predictor[1] is predictor_base
if hasattr(sp, 'predictor') and sp.predictor is not None and hasattr(sp, 'predictor_base') and sp.predictor_base is not None:
    if len(sp.predictor) > 1:
        print(f"\npredictor[1] is predictor_base: {sp.predictor[1] is sp.predictor_base}")

        # Check if weights are the same
        pred1_params = list(sp.predictor[1].parameters())
        base_params = list(sp.predictor_base.parameters())
        if pred1_params and base_params:
            print(f"predictor[1] first param: {pred1_params[0].data[0,0].item():.6f}")
            print(f"predictor_base first param: {base_params[0].data[0,0].item():.6f}")
            match = torch.allclose(pred1_params[0], base_params[0])
            print(f"Weights match: {match}")

# Check _pending_state_dicts
if hasattr(sp, '_pending_state_dicts'):
    print(f"\n_pending_state_dicts keys: {list(sp._pending_state_dicts.keys())}")

    if 'predictor' in sp._pending_state_dicts:
        pred_sd = sp._pending_state_dicts['predictor']
        print(f"\npredictor state_dict keys:")
        for key in sorted(pred_sd.keys()):
            print(f"  {key}: {pred_sd[key].shape}")

# Try predict_batch
print("\n" + "=" * 60)
print("Testing predict_batch...")
print("=" * 60)

# Get target column
target_col = sp.target_col_name if hasattr(sp, 'target_col_name') else None
print(f"Target column: {target_col}")

# Get available columns from codecs
if hasattr(sp, 'all_codecs'):
    cols = list(sp.all_codecs.keys())[:10]
    print(f"Available columns (first 10): {cols}")

# Create a dummy test record with some values
test_record = {}
if hasattr(sp, 'all_codecs'):
    for col, codec in list(sp.all_codecs.items())[:10]:
        if col != target_col:
            # Get a sample value from the codec
            if hasattr(codec, 'members') and codec.members:
                members = list(codec.members)
                # Skip <UNKNOWN> if possible
                valid_members = [m for m in members if m != "<UNKNOWN>"]
                test_record[col] = valid_members[0] if valid_members else members[0]
            elif hasattr(codec, 'mean'):
                test_record[col] = float(codec.mean)
            else:
                test_record[col] = "test"

print(f"Test record: {test_record}")

try:
    result = sp.predict_batch([test_record])
    print(f"SUCCESS! predict_batch result: {result}")
except Exception as e:
    import traceback
    print(f"\nERROR in predict_batch: {e}")
    print(f"\nFull traceback:")
    traceback.print_exc()
