#!/usr/bin/env python3
"""
Test loading a checkpoint from taco and running predict_batch locally.
"""
import sys
sys.path.insert(0, "/Users/admin/Desktop/tetra-ws/featrix/taco-fixes")
sys.path.insert(0, "/Users/admin/Desktop/tetra-ws/featrix/taco-fixes/src/lib")

import pickle
import os
import torch

# First, copy a checkpoint from taco to local
os.system("scp taco:~/sphere/qa.out-cant-get-fooled-again/featrix_output/single_predictor_epoch_10.pickle /tmp/test_checkpoint.pickle")

print("=" * 60)
print("Loading checkpoint...")
print("=" * 60)

with open("/tmp/test_checkpoint.pickle", "rb") as f:
    # Load on CPU if CUDA not available
    sp = pickle.load(f) if torch.cuda.is_available() else torch.load(f, map_location='cpu', weights_only=False)

print(f"Loaded! Type: {type(sp)}")
print(f"Has predictor: {hasattr(sp, 'predictor') and sp.predictor is not None}")
print(f"Has predictor_base: {hasattr(sp, 'predictor_base')}")
print(f"Has embedding_space: {hasattr(sp, 'embedding_space') and sp.embedding_space is not None}")
print(f"Has target_codec: {hasattr(sp, 'target_codec') and sp.target_codec is not None}")

if hasattr(sp, 'target_codec') and sp.target_codec is not None:
    print(f"Target codec type: {type(sp.target_codec)}")
    if hasattr(sp.target_codec, 'members'):
        print(f"Target codec members: {sp.target_codec.members}")

# Check predictor structure
if hasattr(sp, 'predictor') and sp.predictor is not None:
    print(f"\nPredictor structure:")
    print(f"  Type: {type(sp.predictor)}")
    if hasattr(sp.predictor, '__len__'):
        for i, module in enumerate(sp.predictor):
            print(f"  [{i}] {type(module).__name__}")

# Check predictor_base
if hasattr(sp, 'predictor_base'):
    print(f"\npredictor_base: {type(sp.predictor_base)}")

# Check if predictor[1] is predictor_base
if hasattr(sp, 'predictor') and sp.predictor is not None and hasattr(sp, 'predictor_base') and sp.predictor_base is not None:
    if len(sp.predictor) > 1:
        print(f"\npredictor[1] is predictor_base: {sp.predictor[1] is sp.predictor_base}")

# Try predict_batch
print("\n" + "=" * 60)
print("Testing predict_batch...")
print("=" * 60)

# Get available columns from codecs
if hasattr(sp, 'all_codecs'):
    print(f"Available columns: {list(sp.all_codecs.keys())[:10]}...")  # First 10

# Create a dummy test record
test_record = {}
if hasattr(sp, 'all_codecs'):
    for col, codec in list(sp.all_codecs.items())[:5]:
        if col != sp.target_col_name:
            # Get a sample value from the codec
            if hasattr(codec, 'members'):
                test_record[col] = list(codec.members)[0] if codec.members else "test"
            else:
                test_record[col] = 0

print(f"Test record: {test_record}")

try:
    result = sp.predict_batch([test_record])
    print(f"predict_batch result: {result}")
except Exception as e:
    import traceback
    print(f"ERROR in predict_batch: {e}")
    traceback.print_exc()
