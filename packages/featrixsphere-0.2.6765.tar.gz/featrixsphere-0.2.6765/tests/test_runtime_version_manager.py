"""
Tests for runtime version manager.

These tests verify the model runtime integrity system works correctly.
"""

import os
import sys
import tempfile
from pathlib import Path
from unittest import mock

import pytest

# Add src/lib to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent / "src" / "lib"))


class TestRuntimeVersionManager:
    """Tests for runtime_version_manager.py"""

    def test_import(self):
        """Test that the module can be imported."""
        from runtime_version_manager import (
            get_model_runtime_version,
            get_runtime_path,
            is_version_cached,
            is_version_pinning_enabled,
            is_strict_mode,
        )
        # Just verify imports work
        assert callable(get_model_runtime_version)
        assert callable(get_runtime_path)
        assert callable(is_version_cached)
        assert callable(is_version_pinning_enabled)
        assert callable(is_strict_mode)

    def test_get_runtime_path(self):
        """Test that runtime path is constructed correctly."""
        from runtime_version_manager import get_runtime_path

        # Set env var to use temp dir (avoids /sphere not existing)
        with tempfile.TemporaryDirectory() as tmpdir:
            with mock.patch.dict(os.environ, {"FEATRIX_RUNTIME_CACHE_DIR": tmpdir}):
                # Need to reimport to pick up the env var
                import importlib
                import runtime_version_manager
                importlib.reload(runtime_version_manager)

                path = runtime_version_manager.get_runtime_path("1.2.3")
                assert "1.2.3" in str(path)
                assert str(path).endswith("/lib") or str(path).endswith("\\lib")

    def test_is_version_cached_nonexistent(self):
        """Test that nonexistent versions are not cached."""
        from runtime_version_manager import is_version_cached

        with tempfile.TemporaryDirectory() as tmpdir:
            with mock.patch.dict(os.environ, {"FEATRIX_RUNTIME_CACHE_DIR": tmpdir}):
                # Use a version that definitely doesn't exist
                assert not is_version_cached("0.0.0-nonexistent-version")

    def test_get_model_runtime_version_no_file(self):
        """Test getting runtime version when file doesn't exist."""
        from runtime_version_manager import get_model_runtime_version

        with tempfile.TemporaryDirectory() as tmpdir:
            fake_model = Path(tmpdir) / "model.pickle"
            fake_model.touch()

            version = get_model_runtime_version(str(fake_model))
            assert version is None

    def test_get_model_runtime_version_with_file(self):
        """Test getting runtime version when file exists."""
        from runtime_version_manager import get_model_runtime_version

        with tempfile.TemporaryDirectory() as tmpdir:
            # Create model file
            fake_model = Path(tmpdir) / "model.pickle"
            fake_model.touch()

            # Create version file
            version_file = Path(tmpdir) / "runtime_version.txt"
            version_file.write_text("1.2.3")

            version = get_model_runtime_version(str(fake_model))
            assert version == "1.2.3"

    def test_config_defaults(self):
        """Test that config defaults are sensible."""
        from runtime_version_manager import is_version_pinning_enabled, is_strict_mode

        # Without config, should use defaults (both True)
        # Note: This may be affected by any config.json in the test environment
        enabled = is_version_pinning_enabled()
        strict = is_strict_mode()

        # Both should be booleans
        assert isinstance(enabled, bool)
        assert isinstance(strict, bool)

    def test_list_cached_versions_empty(self):
        """Test listing cached versions when none exist."""
        with tempfile.TemporaryDirectory() as tmpdir:
            with mock.patch.dict(os.environ, {"FEATRIX_RUNTIME_CACHE_DIR": tmpdir}):
                import importlib
                import runtime_version_manager
                importlib.reload(runtime_version_manager)

                # This should return a list (possibly empty)
                versions = runtime_version_manager.list_cached_versions()
                assert isinstance(versions, list)


class TestIntegrityCheckEnforcement:
    """Tests for integrity check enforcement in prediction_server."""

    def test_integrity_check_raises_on_failure(self):
        """Test that integrity check failure raises RuntimeError."""
        # This is more of an integration test - verify the error message format
        error_msg = (
            "MODEL INTEGRITY CHECK FAILED - refusing to serve predictions.\n"
            "  Samples tested from: checkpoint\n"
            "  Mismatches: 5\n"
            "  Max probability diff: 0.123456\n"
        )

        # Verify the error message contains expected parts
        assert "INTEGRITY CHECK FAILED" in error_msg
        assert "Mismatches" in error_msg
        assert "Max probability diff" in error_msg


class TestSaveRuntimeVersion:
    """Tests for saving runtime version during training."""

    def test_save_runtime_version_creates_file(self):
        """Test that _save_runtime_version creates the version file."""
        # This would require mocking SinglePredictor - skip for now
        # The actual functionality is tested via integration tests
        pass


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
