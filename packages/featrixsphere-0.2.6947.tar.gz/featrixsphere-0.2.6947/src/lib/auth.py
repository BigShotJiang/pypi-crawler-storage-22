"""
Sphere Auth Module

Drop this file into your Flask or FastAPI project. It provides:

  1. JWT verification (local, using Supabase JWT secret)
  2. API key exchange (calls Supabase Edge Function)
  3. AuthContext dataclass (the verified identity that gets stamped onto jobs)
  4. Flask middleware (before_request hook)
  5. Job identity helpers (stamp a job config, read identity from a job config)

Environment variables required:
  SUPABASE_URL            - Supabase project URL
  SUPABASE_ANON_KEY       - Supabase anon/public key
  SUPABASE_JWT_SECRET     - JWT signing secret (Settings > API in dashboard)
  SUPABASE_SERVICE_ROLE_KEY - Service role key (for server-side Supabase calls)

Optional:
  AUTH_LEEWAY_SECONDS     - Clock skew tolerance for JWT exp check (default: 120)

Dependency: PyJWT (pip install PyJWT)
"""

import hashlib
import logging
import os
import time
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from functools import wraps
from typing import Optional

import jwt  # PyJWT
import httpx

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Config (from env or /etc/.supabase) - loaded lazily for gradual rollout
# ---------------------------------------------------------------------------

SUPABASE_CONFIG_FILE = "/etc/.supabase"


def _get_env(name: str, required: bool = False) -> Optional[str]:
    val = os.getenv(name)
    if not val and required:
        raise RuntimeError(f"Missing required env var: {name}")
    return val


def _load_from_config_file() -> dict:
    """Load config from /etc/.supabase file (same format as backing_db)."""
    import json
    from pathlib import Path

    config_path = Path(SUPABASE_CONFIG_FILE)
    if not config_path.exists():
        return {}

    try:
        content = config_path.read_text().strip()

        # Try JSON format first: {"url": "...", "key": "..."}
        if content.startswith('{'):
            return json.loads(content)

        # Parse env format: KEY=value
        result = {}
        for line in content.splitlines():
            line = line.strip()
            if '=' in line and not line.startswith('#'):
                key, value = line.split('=', 1)
                result[key.strip()] = value.strip()
        return result
    except Exception as e:
        logger.warning(f"Failed to read config from {SUPABASE_CONFIG_FILE}: {e}")
        return {}


# Lazy-loaded config - allows import without env vars being set
_config_loaded = False
SUPABASE_URL: Optional[str] = None
SUPABASE_ANON_KEY: Optional[str] = None
SUPABASE_JWT_SECRET: Optional[str] = None
SUPABASE_SERVICE_ROLE_KEY: Optional[str] = None
AUTH_LEEWAY_SECONDS: int = 120


def _ensure_config():
    """Load config from env vars or /etc/.supabase. Call before any JWT operations."""
    global _config_loaded, SUPABASE_URL, SUPABASE_ANON_KEY, SUPABASE_JWT_SECRET
    global SUPABASE_SERVICE_ROLE_KEY, AUTH_LEEWAY_SECONDS

    if _config_loaded:
        return

    # Load from /etc/.supabase as fallback
    file_config = _load_from_config_file()

    # Env vars take precedence over file config
    SUPABASE_URL = _get_env("SUPABASE_URL") or file_config.get("SUPABASE_URL") or file_config.get("url")
    SUPABASE_ANON_KEY = _get_env("SUPABASE_ANON_KEY") or file_config.get("SUPABASE_ANON_KEY") or file_config.get("anon_key")
    SUPABASE_JWT_SECRET = _get_env("SUPABASE_JWT_SECRET") or file_config.get("SUPABASE_JWT_SECRET") or file_config.get("jwt_secret")
    SUPABASE_SERVICE_ROLE_KEY = _get_env("SUPABASE_SERVICE_ROLE_KEY") or file_config.get("SUPABASE_KEY") or file_config.get("key")
    AUTH_LEEWAY_SECONDS = int(os.getenv("AUTH_LEEWAY_SECONDS", "120"))
    _config_loaded = True

    if SUPABASE_JWT_SECRET:
        logger.info("Auth module configured with JWT support")
    else:
        logger.warning("Auth module loaded without JWT secret - JWT verification disabled")


def is_jwt_enabled() -> bool:
    """Check if JWT verification is available."""
    _ensure_config()
    return bool(SUPABASE_JWT_SECRET)


# ---------------------------------------------------------------------------
# AuthContext -- the verified identity that travels with every job
# ---------------------------------------------------------------------------

@dataclass
class AuthContext:
    """Verified identity extracted from a JWT.

    This gets stamped onto every job at creation time and travels with
    the job for its entire lifetime (days). The JWT itself expires, but
    the AuthContext persists in the job config and DB row.
    """
    user_id: str          # from JWT "sub" claim
    org_id: str           # from JWT "org_id" claim
    org_slug: Optional[str] = None    # from JWT "org_slug" claim (for logging)
    api_key_id: Optional[str] = None  # which API key was used (if known)
    scopes: Optional[list] = None     # API key scopes (for access control)
    verified_at: Optional[str] = None  # ISO timestamp of when the JWT was checked

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "AuthContext":
        return cls(
            user_id=d["user_id"],
            org_id=d["org_id"],
            org_slug=d.get("org_slug"),
            api_key_id=d.get("api_key_id"),
            scopes=d.get("scopes"),
            verified_at=d.get("verified_at"),
        )


# ---------------------------------------------------------------------------
# JWT verification (local -- no network call)
# ---------------------------------------------------------------------------

def verify_jwt(token: str, leeway: int = None) -> dict:
    """Verify a Supabase JWT and return its claims.

    Args:
        token: The raw JWT string (no "Bearer " prefix).
        leeway: Clock skew tolerance in seconds. Defaults to AUTH_LEEWAY_SECONDS.

    Returns:
        Dict of verified claims (sub, org_id, exp, iat, etc.)

    Raises:
        AuthError on any verification failure.
    """
    _ensure_config()

    if not SUPABASE_JWT_SECRET:
        raise AuthError(500, "JWT verification not configured (missing SUPABASE_JWT_SECRET)")

    if leeway is None:
        leeway = AUTH_LEEWAY_SECONDS

    try:
        claims = jwt.decode(
            token,
            SUPABASE_JWT_SECRET,
            algorithms=["HS256"],
            options={
                "require": ["sub", "org_id", "exp"],
                "verify_exp": True,
            },
            leeway=leeway,
        )
        return claims
    except jwt.ExpiredSignatureError:
        raise AuthError(403, "Token expired")
    except jwt.InvalidTokenError as e:
        raise AuthError(403, f"Invalid token: {e}")


def extract_auth_context(token: str, leeway: int = None) -> AuthContext:
    """Verify a JWT and return an AuthContext.

    This is the main entry point for request handling. Call this once
    per request, then pass the AuthContext to everything downstream.
    """
    claims = verify_jwt(token, leeway=leeway)
    return AuthContext(
        user_id=claims["sub"],
        org_id=claims["org_id"],
        org_slug=claims.get("org_slug"),
        api_key_id=claims.get("api_key_id"),
        scopes=claims.get("scopes"),
        verified_at=datetime.now(timezone.utc).isoformat(),
    )


# ---------------------------------------------------------------------------
# API key exchange (calls Supabase Edge Function or local lookup)
# ---------------------------------------------------------------------------

def exchange_api_key(api_key: str) -> str:
    """Exchange an API key for a JWT.

    Calls the Supabase Edge Function `exchange-api-key`.

    Args:
        api_key: The raw API key (e.g. "sk_live_abc123...")

    Returns:
        A JWT string.

    Raises:
        AuthError if the key is invalid or the exchange fails.
    """
    _ensure_config()

    if not SUPABASE_URL or not SUPABASE_ANON_KEY:
        raise AuthError(500, "API key exchange not configured (missing SUPABASE_URL or SUPABASE_ANON_KEY)")

    url = f"{SUPABASE_URL}/functions/v1/exchange-api-key"

    try:
        with httpx.Client(timeout=10) as client:
            resp = client.post(
                url,
                json={"api_key": api_key},
                headers={
                    "Authorization": f"Bearer {SUPABASE_ANON_KEY}",
                    "Content-Type": "application/json",
                },
            )
    except httpx.RequestError as e:
        raise AuthError(502, f"Failed to reach auth service: {e}")

    if resp.status_code == 401:
        raise AuthError(401, "Invalid API key")
    if resp.status_code != 200:
        raise AuthError(502, f"Auth service error: {resp.status_code}")

    data = resp.json()
    token = data.get("access_token")
    if not token:
        raise AuthError(502, "Auth service returned no token")

    return token


def hash_api_key(api_key: str) -> str:
    """Hash an API key for storage/lookup. SHA-256, hex encoded."""
    return hashlib.sha256(api_key.encode()).hexdigest()


def api_key_prefix(api_key: str) -> str:
    """Get the display prefix of an API key (first 8 chars)."""
    return api_key[:8] + "..."


# ---------------------------------------------------------------------------
# Request authentication (works with Flask or standalone)
# ---------------------------------------------------------------------------

def authenticate_request(
    authorization: Optional[str] = None,
    api_key: Optional[str] = None,
    fallback_validator: Optional[callable] = None,
) -> AuthContext:
    """Authenticate a request from its headers.

    Accepts either:
      - Authorization: Bearer <jwt>
      - X-Api-Key: <api_key>  (exchanges for JWT, then verifies)

    Args:
        authorization: Value of the Authorization header.
        api_key: Value of the X-Api-Key header.
        fallback_validator: Optional function(api_key) -> dict that validates
            API keys directly (for legacy/fallback mode when JWT not configured).
            Should return dict with 'organization_id', 'organization_slug', etc.

    Returns:
        AuthContext with verified user_id and org_id.

    Raises:
        AuthError on any failure.
    """
    _ensure_config()

    # If we have a Bearer token that looks like a JWT, try to verify it
    if authorization and authorization.startswith("Bearer "):
        token = authorization[7:].strip()
        if token:
            # Check if it looks like a JWT (has 2 dots)
            if token.count('.') == 2 and is_jwt_enabled():
                return extract_auth_context(token)
            # Otherwise it might be a raw API key in Bearer format
            api_key = token

    # If we have an API key
    if api_key:
        # Try JWT exchange if configured
        if is_jwt_enabled() and SUPABASE_URL:
            try:
                token = exchange_api_key(api_key)
                return extract_auth_context(token)
            except AuthError:
                # Fall through to fallback if exchange fails
                pass

        # Fallback: use direct API key validation (legacy mode)
        if fallback_validator:
            auth_info = fallback_validator(api_key)
            if auth_info:
                return AuthContext(
                    user_id=auth_info.get('user_id', 'api_key_user'),
                    org_id=auth_info['organization_id'],
                    org_slug=auth_info.get('organization_slug'),
                    api_key_id=auth_info.get('api_key_id'),
                    scopes=auth_info.get('scopes'),
                    verified_at=datetime.now(timezone.utc).isoformat(),
                )
            raise AuthError(401, "Invalid API key")

        raise AuthError(401, "Invalid API key (JWT exchange not configured)")

    raise AuthError(401, "Missing authentication. Send Authorization: Bearer <jwt> or X-Api-Key: <key>")


# ---------------------------------------------------------------------------
# Flask integration
# ---------------------------------------------------------------------------

# Paths that don't require auth
PUBLIC_PATHS = frozenset({
    "/",
    "/favicon.ico",
    "/health",
})

# Paths that use node/service auth instead of user JWTs
SERVICE_PATH_PREFIXES = (
    "/compute-nodes/",
    "/admin/",
    "/backend-code-update-ping",
    "/private/api/",
    "/meta/",
    "/strings/",
    "/proxy/",
)


def flask_auth_middleware(app, fallback_validator: callable = None, require_auth: bool = False):
    """Register auth middleware on a Flask app.

    Usage:
        from auth import flask_auth_middleware
        import backing_db

        app = Flask(__name__)
        flask_auth_middleware(app, fallback_validator=backing_db.validate_api_key)

    After this, `g.auth` is an AuthContext on every authenticated request.

    Args:
        app: Flask application instance.
        fallback_validator: Optional function(api_key) -> dict for legacy API key validation.
        require_auth: If True, return 401 when no auth provided. If False, proceed with g.auth=None.
    """
    from flask import g, request, jsonify

    @app.before_request
    def _check_auth():
        path = request.path.rstrip("/")

        # Public endpoints -- no auth
        if path in PUBLIC_PATHS or path == "":
            g.auth = None
            return None

        # Service/admin endpoints -- skip user JWT check
        # (these need their own auth: X-Node-Secret, admin key, etc.)
        for prefix in SERVICE_PATH_PREFIXES:
            if path.startswith(prefix.rstrip("/")):
                g.auth = None  # no user context
                return None

        # Everything else: try user auth
        auth_header = request.headers.get("Authorization")
        api_key = request.headers.get("X-Api-Key") or request.headers.get("X-API-Key")

        # Also check query param for api_key
        if not api_key:
            api_key = request.args.get("api_key")

        # If no auth provided
        if not auth_header and not api_key:
            g.auth = None
            if require_auth:
                return jsonify({"error": "Authentication required"}), 401
            return None

        try:
            ctx = authenticate_request(
                authorization=auth_header,
                api_key=api_key,
                fallback_validator=fallback_validator,
            )
            g.auth = ctx
        except AuthError as e:
            logger.warning(f"Auth failed for {request.method} {path}: {e.message}")
            if require_auth:
                return jsonify({"error": e.message}), e.status_code
            # If not requiring auth, proceed with g.auth=None
            g.auth = None
            return None

    return app


def require_auth(f):
    """Decorator for individual Flask routes that require auth.

    Use this if you don't want the global middleware, or for routes
    that need to explicitly fail if auth is missing.

    Usage:
        @app.route("/my-endpoint")
        @require_auth
        def my_endpoint():
            org_id = g.auth.org_id
            ...
    """
    from flask import g

    @wraps(f)
    def wrapper(*args, **kwargs):
        if not getattr(g, "auth", None):
            raise AuthError(401, "Authentication required")
        return f(*args, **kwargs)
    return wrapper


# ---------------------------------------------------------------------------
# Job identity helpers
# ---------------------------------------------------------------------------

def stamp_job_config(config: dict, auth: AuthContext) -> dict:
    """Stamp a job config dict with the verified identity.

    Call this when creating a job. The identity fields become immutable
    properties of the job that survive long after the JWT expires.

    Args:
        config: The job config dict (will be modified in place and returned).
        auth: The verified AuthContext from the request.

    Returns:
        The config dict with identity fields added.
    """
    config["org_id"] = auth.org_id
    config["org_slug"] = auth.org_slug
    config["user_id"] = auth.user_id
    config["created_by"] = auth.user_id
    config["api_key_id"] = auth.api_key_id
    config["auth_verified_at"] = auth.verified_at
    config["created_at"] = datetime.now(timezone.utc).isoformat()
    return config


def read_job_identity(config: dict) -> AuthContext:
    """Read the stamped identity from a job config.

    Use this in compute nodes and recovery code to get the org_id
    and user_id that were verified at job creation time.
    """
    return AuthContext(
        user_id=config.get("user_id", config.get("created_by", "unknown")),
        org_id=config["org_id"],
        org_slug=config.get("org_slug"),
        api_key_id=config.get("api_key_id"),
        verified_at=config.get("auth_verified_at"),
    )


# ---------------------------------------------------------------------------
# Supabase helpers (server-side calls using service role key)
# ---------------------------------------------------------------------------

def supabase_headers_service() -> dict:
    """Headers for server-side Supabase REST calls (bypasses RLS)."""
    return {
        "apikey": SUPABASE_SERVICE_ROLE_KEY,
        "Authorization": f"Bearer {SUPABASE_SERVICE_ROLE_KEY}",
        "Content-Type": "application/json",
    }


def supabase_headers_user(user_jwt: str) -> dict:
    """Headers for user-scoped Supabase REST calls (respects RLS)."""
    return {
        "apikey": SUPABASE_ANON_KEY,
        "Authorization": f"Bearer {user_jwt}",
        "Content-Type": "application/json",
    }


# ---------------------------------------------------------------------------
# Session-org binding check
# ---------------------------------------------------------------------------

def check_session_org(session_org_id: str, auth: AuthContext) -> None:
    """Verify a session belongs to the authenticated org.

    Call this at the router level before proxying any session-scoped
    request to a compute node.

    Args:
        session_org_id: The org_id stored on the session.
        auth: The authenticated user's context.

    Raises:
        AuthError if the session doesn't belong to the user's org.
    """
    if session_org_id != auth.org_id:
        raise AuthError(403, "Session does not belong to your organization")


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------

class AuthError(Exception):
    """Auth failure with an HTTP status code."""
    def __init__(self, status_code: int, message: str):
        self.status_code = status_code
        self.message = message
        super().__init__(message)
