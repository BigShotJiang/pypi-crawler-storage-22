#  -*- coding: utf-8 -*-
#
#  Copyright Featrix, Inc 2023-2025
#
#  ES Stress Tests Package
#
#  Synthetic stress tests for Featrix Embedding Space training.
#
from __future__ import annotations

from .generators import (
    Generator,
    DominantFeatureGenerator,
    XORClassificationGenerator,
    RareCategoryGenerator,
)

__all__ = [
    "Generator",
    "DominantFeatureGenerator",
    "XORClassificationGenerator",
    "RareCategoryGenerator",
]
