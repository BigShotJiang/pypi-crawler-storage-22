#  -*- coding: utf-8 -*-
#
#  Copyright Featrix, Inc 2023-2025
#
#  Base class for synthetic data generators
#
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

import pandas as pd


class Generator(ABC):
    """
    Base class for synthetic data generators.

    All generators must:
    1. Have a unique `name` property
    2. Implement `generate()` to return (DataFrame, metadata)
    3. Be reproducible via `seed` parameter
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """Unique identifier for this generator."""
        pass

    @abstractmethod
    def generate(
        self,
        *,
        n_rows: int,
        seed: int,
        **kwargs,
    ) -> tuple[pd.DataFrame, dict[str, Any]]:
        """
        Generate synthetic data.

        Args:
            n_rows: Number of rows to generate
            seed: Random seed for reproducibility
            **kwargs: Generator-specific parameters

        Returns:
            tuple of:
                - DataFrame with features + 'label' column
                - Metadata dict containing:
                    - generator_name: str
                    - generator_params: dict
                    - ground_truth: dict (describes the true relationship)
                    - n_rows: int
                    - seed: int
        """
        pass

    def _build_metadata(
        self,
        n_rows: int,
        seed: int,
        ground_truth: dict[str, Any],
        **params,
    ) -> dict[str, Any]:
        """Helper to build consistent metadata dicts."""
        return {
            "generator_name": self.name,
            "generator_params": {
                "n_rows": n_rows,
                "seed": seed,
                **params,
            },
            "ground_truth": ground_truth,
            "n_rows": n_rows,
            "seed": seed,
        }
