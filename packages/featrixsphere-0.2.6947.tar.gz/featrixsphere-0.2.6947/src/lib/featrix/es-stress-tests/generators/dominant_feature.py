#  -*- coding: utf-8 -*-
#
#  Copyright Featrix, Inc 2023-2025
#
#  Dominant Feature Generator - tests "dominant feature latch" failure mode
#
#  This generates data where a single feature S perfectly (or near-perfectly)
#  determines the label Y via a hard threshold. The challenge is that ES
#  may "latch" onto this dominant signal and ignore other potentially
#  informative features.
#
from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd

from .base import Generator


class DominantFeatureGenerator(Generator):
    """
    Generates data with a dominant threshold feature.

    The label is determined by:
        Y = 1 if S > threshold else 0

    With optional:
    - Label noise (p_flip): probability of flipping the correct label
    - Noise dimensions (n_noise_dims): additional uninformative features
    - Secondary signal (secondary_strength): weak correlation in noise dims

    This tests whether ES can learn the threshold relationship vs latching
    onto the dominant feature in a way that doesn't generalize.
    """

    @property
    def name(self) -> str:
        return "dominant_feature_threshold"

    def generate(
        self,
        *,
        n_rows: int,
        seed: int,
        threshold: float = 0.5,
        p_flip: float = 0.0,
        n_noise_dims: int = 10,
        signal_distribution: str = "uniform",  # "uniform" or "gaussian"
        secondary_strength: float = 0.0,
        imbalance_ratio: float = 0.5,  # P(Y=1) approximately
        **kwargs,
    ) -> tuple[pd.DataFrame, dict[str, Any]]:
        """
        Generate dominant feature threshold data.

        Args:
            n_rows: Number of rows
            seed: Random seed
            threshold: Threshold on signal feature S for Y=1
            p_flip: Label noise probability (0 = perfect, 0.5 = random)
            n_noise_dims: Number of noise dimensions to add
            signal_distribution: Distribution of signal feature ("uniform", "gaussian")
            secondary_strength: Strength of secondary signal in noise dims (0 = pure noise)
            imbalance_ratio: Approximate ratio of positive class (adjusts threshold)

        Returns:
            (DataFrame, metadata)
        """
        rng = np.random.default_rng(seed)

        # Generate signal feature S
        if signal_distribution == "uniform":
            S = rng.uniform(0, 1, size=n_rows)
            # Adjust threshold for desired imbalance
            adjusted_threshold = np.quantile(S, 1 - imbalance_ratio)
        elif signal_distribution == "gaussian":
            S = rng.standard_normal(n_rows)
            adjusted_threshold = np.quantile(S, 1 - imbalance_ratio)
        else:
            raise ValueError(f"Unknown signal_distribution: {signal_distribution}")

        # Generate clean labels based on threshold
        Y_clean = (S > adjusted_threshold).astype(int)

        # Apply label noise
        if p_flip > 0:
            flip_mask = rng.random(n_rows) < p_flip
            Y = np.where(flip_mask, 1 - Y_clean, Y_clean)
        else:
            Y = Y_clean

        # Generate noise dimensions
        noise_features = {}
        for i in range(n_noise_dims):
            noise = rng.standard_normal(n_rows)
            # Add weak secondary signal if requested
            if secondary_strength > 0:
                noise = noise + secondary_strength * (Y - 0.5)
            noise_features[f"noise_{i}"] = noise

        # Build DataFrame
        data = {"signal": S, **noise_features, "label": Y}
        df = pd.DataFrame(data)

        # Build metadata
        actual_positive_rate = Y.mean()
        ground_truth = {
            "relationship": "threshold",
            "formula": f"label = 1 if signal > {adjusted_threshold:.4f} else 0",
            "signal_column": "signal",
            "threshold": float(adjusted_threshold),
            "informative_columns": ["signal"],
            "noise_columns": list(noise_features.keys()),
        }

        metadata = self._build_metadata(
            n_rows=n_rows,
            seed=seed,
            ground_truth=ground_truth,
            threshold=threshold,
            adjusted_threshold=float(adjusted_threshold),
            p_flip=p_flip,
            n_noise_dims=n_noise_dims,
            signal_distribution=signal_distribution,
            secondary_strength=secondary_strength,
            imbalance_ratio=imbalance_ratio,
            actual_positive_rate=float(actual_positive_rate),
        )

        return df, metadata
