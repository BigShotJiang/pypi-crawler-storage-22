#!/usr/bin/env python3
#  -*- coding: utf-8 -*-
#
#  Copyright Featrix, Inc 2023-2025
#
#  Master Dataset Generator
#
#  Generates a single master dataset with semantically-named columns.
#  Tests compose views by selecting subsets of columns.
#
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import norm


def generate_master_dataset(
    n_rows: int = 5000,
    seed: int = 42,
    output_dir: Path | str | None = None,
) -> tuple[pd.DataFrame, dict]:
    """
    Generate the master stress test dataset.

    Returns:
        (DataFrame, schema_dict)
    """
    rng = np.random.default_rng(seed)
    output_dir = Path(output_dir) if output_dir else None

    data = {}
    schema = {"columns": {}, "n_rows": n_rows, "seed": seed}

    def add_column(name: str, values, col_schema: dict):
        data[name] = values
        schema["columns"][name] = col_schema

    # =========================================================================
    # SIGNAL COLUMNS - Features that determine labels
    # =========================================================================

    # Threshold signals
    add_column("threshold_signal", rng.uniform(0, 1, n_rows), {
        "type": "signal",
        "dtype": "float",
        "distribution": "uniform [0, 1]",
        "description": "Primary signal for threshold tests. Y=1 if value > threshold.",
    })

    add_column("threshold_signal_gaussian", rng.standard_normal(n_rows), {
        "type": "signal",
        "dtype": "float",
        "distribution": "standard normal",
        "description": "Gaussian signal for threshold tests.",
    })

    # XOR signals
    xor_a = rng.uniform(0, 1, n_rows)
    add_column("xor_signal_a", xor_a, {
        "type": "signal",
        "dtype": "float",
        "distribution": "uniform [0, 1]",
        "description": "First signal for XOR relationship.",
    })

    xor_b = rng.uniform(0, 1, n_rows)
    add_column("xor_signal_b", xor_b, {
        "type": "signal",
        "dtype": "float",
        "distribution": "uniform [0, 1]",
        "description": "Second signal for XOR (independent of a).",
    })

    # Correlated XOR partners
    z_a = norm.ppf(np.clip(xor_a, 0.001, 0.999))  # Convert to z-scores
    for corr, suffix in [(0.5, "corr50"), (0.8, "corr80")]:
        z_b = corr * z_a + np.sqrt(1 - corr**2) * rng.standard_normal(n_rows)
        xor_b_corr = norm.cdf(z_b)
        add_column(f"xor_signal_b_{suffix}", xor_b_corr, {
            "type": "signal",
            "dtype": "float",
            "distribution": f"uniform [0, 1], {int(corr*100)}% correlated with xor_signal_a",
            "description": f"Second XOR signal, {int(corr*100)}% correlated with a.",
        })

    # Categorical signals
    def make_rare_category_column(n_categories: int, n_positive: int, rare_freq: float, name: str):
        categories = [f"cat_{i}" for i in range(n_categories)]
        positive_cats = set(categories[:n_positive])

        # Build probability distribution
        total_rare = rare_freq * n_positive
        remaining = 1.0 - total_rare
        common_freq = remaining / (n_categories - n_positive)

        probs = [rare_freq if c in positive_cats else common_freq for c in categories]
        probs = np.array(probs) / np.sum(probs)

        indices = rng.choice(n_categories, size=n_rows, p=probs)
        values = np.array([categories[i] for i in indices])

        add_column(name, values, {
            "type": "signal",
            "dtype": "categorical",
            "cardinality": n_categories,
            "distribution": f"{n_positive} rare categories @ {rare_freq*100:.1f}% each",
            "positive_categories": list(positive_cats),
            "description": f"{n_categories} categories, {n_positive} rare ones predict positive.",
        })
        return values, positive_cats

    cat_20_5, pos_20_5 = make_rare_category_column(20, 5, 0.02, "category_20_5rare")
    cat_100_10, pos_100_10 = make_rare_category_column(100, 10, 0.005, "category_100_10rare")
    cat_50_1, pos_50_1 = make_rare_category_column(50, 1, 0.02, "category_50_needle")

    # Sinusoidal signals
    row_idx = np.arange(n_rows)
    add_column("sinusoidal_slow", np.sin(2 * np.pi * row_idx / 1000), {
        "type": "signal",
        "dtype": "float",
        "distribution": "sin(2*pi*x/1000), period=1000 rows",
        "description": "Slow sinusoidal wave over dataset.",
    })

    add_column("sinusoidal_fast", np.sin(2 * np.pi * row_idx / 100), {
        "type": "signal",
        "dtype": "float",
        "distribution": "sin(2*pi*x/100), period=100 rows",
        "description": "Fast sinusoidal wave.",
    })

    add_column("sinusoidal_pair_a", np.sin(2 * np.pi * row_idx / 500), {
        "type": "signal",
        "dtype": "float",
        "distribution": "sin(2*pi*x/500)",
        "description": "Sinusoidal wave, paired with b.",
    })

    add_column("sinusoidal_pair_b", np.sin(2 * np.pi * row_idx / 500 + np.pi/4), {
        "type": "signal",
        "dtype": "float",
        "distribution": "sin(2*pi*x/500 + pi/4), phase shifted",
        "description": "Sinusoidal wave, phase shifted from a.",
    })

    # Step function
    add_column("step_function", (row_idx >= n_rows // 2).astype(float), {
        "type": "signal",
        "dtype": "float",
        "distribution": "0 for first half, 1 for second half",
        "description": "Step function at dataset midpoint.",
    })

    # Outlier signal
    outlier_mask = rng.random(n_rows) < 0.02
    outlier_values = np.where(outlier_mask, rng.uniform(5, 10, n_rows), 0.0)
    add_column("outlier_signal", outlier_values, {
        "type": "signal",
        "dtype": "float",
        "distribution": "2% spikes (5-10), otherwise 0",
        "description": "Mostly zero, rare spikes indicate positive.",
    })

    # =========================================================================
    # NOISE COLUMNS - Uninformative features
    # =========================================================================

    # Gaussian noise
    for i in range(1, 21):
        add_column(f"noise_gaussian_{i:02d}", rng.standard_normal(n_rows), {
            "type": "noise",
            "dtype": "float",
            "distribution": "standard normal",
            "description": f"IID Gaussian noise #{i}.",
        })

    # Uniform noise
    for i in range(1, 11):
        add_column(f"noise_uniform_{i:02d}", rng.uniform(0, 1, n_rows), {
            "type": "noise",
            "dtype": "float",
            "distribution": "uniform [0, 1]",
            "description": f"IID Uniform noise #{i}.",
        })

    # Categorical noise (10 cardinality)
    for i in range(1, 6):
        cats = [f"ncat10_{j}" for j in range(10)]
        add_column(f"noise_categorical_10card_{i:02d}", rng.choice(cats, n_rows), {
            "type": "noise",
            "dtype": "categorical",
            "cardinality": 10,
            "distribution": "uniform over 10 categories",
            "description": f"Uninformative categorical #{i}, 10 values.",
        })

    # Categorical noise (50 cardinality)
    for i in range(1, 4):
        cats = [f"ncat50_{j}" for j in range(50)]
        add_column(f"noise_categorical_50card_{i:02d}", rng.choice(cats, n_rows), {
            "type": "noise",
            "dtype": "categorical",
            "cardinality": 50,
            "distribution": "uniform over 50 categories",
            "description": f"Uninformative categorical #{i}, 50 values.",
        })

    # Binary noise
    for i in range(1, 6):
        add_column(f"noise_binary_{i:02d}", rng.integers(0, 2, n_rows), {
            "type": "noise",
            "dtype": "int",
            "distribution": "50/50 binary",
            "description": f"Uninformative binary #{i}.",
        })

    # Sparse noise (90% zeros)
    for i in range(1, 6):
        sparse_mask = rng.random(n_rows) < 0.1
        sparse_vals = np.where(sparse_mask, rng.standard_normal(n_rows), 0.0)
        add_column(f"noise_sparse_{i:02d}", sparse_vals, {
            "type": "noise",
            "dtype": "float",
            "distribution": "90% zeros, 10% standard normal",
            "description": f"Sparse noise #{i}.",
        })

    # =========================================================================
    # LABEL COLUMNS - Targets for different tests
    # =========================================================================

    def flip_labels(labels: np.ndarray, p_flip: float) -> np.ndarray:
        if p_flip <= 0:
            return labels
        flip_mask = rng.random(len(labels)) < p_flip
        return np.where(flip_mask, 1 - labels, labels)

    threshold_signal = data["threshold_signal"]
    xor_a = data["xor_signal_a"]
    xor_b = data["xor_signal_b"]
    xor_b_corr50 = data["xor_signal_b_corr50"]
    xor_b_corr80 = data["xor_signal_b_corr80"]

    # Threshold labels
    for noise_pct, suffix in [(0, "clean"), (0.05, "noisy5"), (0.10, "noisy10"), (0.20, "noisy20")]:
        labels = (threshold_signal > 0.5).astype(int)
        labels = flip_labels(labels, noise_pct)
        add_column(f"label_threshold_{suffix}", labels, {
            "type": "label",
            "dtype": "int",
            "derives_from": ["threshold_signal"],
            "relationship": "Y = 1 if threshold_signal > 0.5",
            "noise_rate": noise_pct,
            "description": f"Threshold label, {int(noise_pct*100)}% noise.",
        })

    # Imbalanced threshold labels
    labels_imbal10 = flip_labels((threshold_signal > 0.9).astype(int), 0.05)
    add_column("label_threshold_imbal10", labels_imbal10, {
        "type": "label",
        "dtype": "int",
        "derives_from": ["threshold_signal"],
        "relationship": "Y = 1 if threshold_signal > 0.9 (~10% positive)",
        "noise_rate": 0.05,
        "description": "Threshold label, ~10% positive class.",
    })

    labels_imbal90 = flip_labels((threshold_signal > 0.1).astype(int), 0.05)
    add_column("label_threshold_imbal90", labels_imbal90, {
        "type": "label",
        "dtype": "int",
        "derives_from": ["threshold_signal"],
        "relationship": "Y = 1 if threshold_signal > 0.1 (~90% positive)",
        "noise_rate": 0.05,
        "description": "Threshold label, ~90% positive class.",
    })

    # XOR labels
    xor_clean = ((xor_a > 0.5) ^ (xor_b > 0.5)).astype(int)
    add_column("label_xor_clean", xor_clean, {
        "type": "label",
        "dtype": "int",
        "derives_from": ["xor_signal_a", "xor_signal_b"],
        "relationship": "Y = XOR(a > 0.5, b > 0.5)",
        "noise_rate": 0.0,
        "description": "Clean XOR label.",
    })

    for noise_pct, suffix in [(0.05, "noisy5"), (0.10, "noisy10")]:
        labels = flip_labels(xor_clean.copy(), noise_pct)
        add_column(f"label_xor_{suffix}", labels, {
            "type": "label",
            "dtype": "int",
            "derives_from": ["xor_signal_a", "xor_signal_b"],
            "relationship": "Y = XOR(a > 0.5, b > 0.5)",
            "noise_rate": noise_pct,
            "description": f"XOR label, {int(noise_pct*100)}% noise.",
        })

    # XOR with correlated signals
    xor_corr50 = flip_labels(((xor_a > 0.5) ^ (xor_b_corr50 > 0.5)).astype(int), 0.05)
    add_column("label_xor_corr50", xor_corr50, {
        "type": "label",
        "dtype": "int",
        "derives_from": ["xor_signal_a", "xor_signal_b_corr50"],
        "relationship": "Y = XOR(a > 0.5, b_corr50 > 0.5)",
        "noise_rate": 0.05,
        "description": "XOR with 50% correlated signals.",
    })

    xor_corr80 = flip_labels(((xor_a > 0.5) ^ (xor_b_corr80 > 0.5)).astype(int), 0.05)
    add_column("label_xor_corr80", xor_corr80, {
        "type": "label",
        "dtype": "int",
        "derives_from": ["xor_signal_a", "xor_signal_b_corr80"],
        "relationship": "Y = XOR(a > 0.5, b_corr80 > 0.5)",
        "noise_rate": 0.05,
        "description": "XOR with 80% correlated signals (hard).",
    })

    # XOR with asymmetric thresholds
    xor_asym = flip_labels(((xor_a > 0.3) ^ (xor_b > 0.7)).astype(int), 0.05)
    add_column("label_xor_asymmetric", xor_asym, {
        "type": "label",
        "dtype": "int",
        "derives_from": ["xor_signal_a", "xor_signal_b"],
        "relationship": "Y = XOR(a > 0.3, b > 0.7)",
        "noise_rate": 0.05,
        "description": "XOR with asymmetric thresholds.",
    })

    # Rare category labels
    def make_cat_label(cat_values, positive_cats, noise_rate, name, desc):
        labels = np.array([1 if c in positive_cats else 0 for c in cat_values])
        labels = flip_labels(labels, noise_rate)
        add_column(name, labels, {
            "type": "label",
            "dtype": "int",
            "derives_from": [name.replace("label_", "").rsplit("_", 1)[0]],
            "relationship": "Y = 1 if category in positive set",
            "noise_rate": noise_rate,
            "description": desc,
        })

    make_cat_label(cat_20_5, pos_20_5, 0.0, "label_rare_cat_clean",
                   "Rare category lookup, clean.")
    make_cat_label(cat_20_5, pos_20_5, 0.05, "label_rare_cat_noisy5",
                   "Rare category lookup, 5% noise.")
    make_cat_label(cat_20_5, pos_20_5, 0.15, "label_rare_cat_noisy15",
                   "Rare category lookup, 15% noise.")
    make_cat_label(cat_100_10, pos_100_10, 0.05, "label_rare_cat_high_card",
                   "High cardinality (100) rare category.")
    make_cat_label(cat_50_1, pos_50_1, 0.05, "label_rare_cat_needle",
                   "Needle in haystack (1 of 50).")

    # Sinusoidal label
    sin_label = flip_labels((data["sinusoidal_slow"] > 0).astype(int), 0.05)
    add_column("label_sinusoidal", sin_label, {
        "type": "label",
        "dtype": "int",
        "derives_from": ["sinusoidal_slow"],
        "relationship": "Y = 1 if sinusoidal_slow > 0",
        "noise_rate": 0.05,
        "description": "Label from slow sinusoid.",
    })

    # Step label
    step_label = flip_labels((data["step_function"] > 0.5).astype(int), 0.05)
    add_column("label_step", step_label, {
        "type": "label",
        "dtype": "int",
        "derives_from": ["step_function"],
        "relationship": "Y = 1 if step_function > 0.5",
        "noise_rate": 0.05,
        "description": "Label from step function.",
    })

    # Outlier label
    outlier_label = flip_labels((data["outlier_signal"] > 0).astype(int), 0.05)
    add_column("label_outlier", outlier_label, {
        "type": "label",
        "dtype": "int",
        "derives_from": ["outlier_signal"],
        "relationship": "Y = 1 if outlier spike present",
        "noise_rate": 0.05,
        "description": "Label from rare outlier spikes.",
    })

    # Multi-variate label (complex)
    multivar_label = flip_labels(
        ((threshold_signal > 0.5) & (xor_a > 0.5)).astype(int), 0.05
    )
    add_column("label_multivar", multivar_label, {
        "type": "label",
        "dtype": "int",
        "derives_from": ["threshold_signal", "xor_signal_a"],
        "relationship": "Y = 1 if threshold_signal > 0.5 AND xor_signal_a > 0.5",
        "noise_rate": 0.05,
        "description": "Multi-feature AND relationship.",
    })

    # =========================================================================
    # Build DataFrame and save
    # =========================================================================

    df = pd.DataFrame(data)

    # Add summary to schema
    signal_cols = [c for c, s in schema["columns"].items() if s["type"] == "signal"]
    noise_cols = [c for c, s in schema["columns"].items() if s["type"] == "noise"]
    label_cols = [c for c, s in schema["columns"].items() if s["type"] == "label"]

    schema["summary"] = {
        "signal_columns": len(signal_cols),
        "noise_columns": len(noise_cols),
        "label_columns": len(label_cols),
        "total_columns": len(df.columns),
        "signal_column_names": signal_cols,
        "noise_column_names": noise_cols,
        "label_column_names": label_cols,
    }

    if output_dir:
        output_dir.mkdir(parents=True, exist_ok=True)
        df.to_csv(output_dir / "master.csv", index=False)
        with open(output_dir / "master_schema.json", "w") as f:
            json.dump(schema, f, indent=2, default=str)

    return df, schema


if __name__ == "__main__":
    import sys
    output_dir = Path(__file__).parent.parent / "data"
    df, schema = generate_master_dataset(output_dir=output_dir)
    print(f"Generated master.csv: {len(df)} rows, {len(df.columns)} columns")
    print(f"  Signal columns: {schema['summary']['signal_columns']}")
    print(f"  Noise columns: {schema['summary']['noise_columns']}")
    print(f"  Label columns: {schema['summary']['label_columns']}")
