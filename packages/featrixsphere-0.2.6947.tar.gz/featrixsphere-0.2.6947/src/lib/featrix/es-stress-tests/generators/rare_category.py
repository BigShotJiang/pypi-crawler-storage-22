#  -*- coding: utf-8 -*-
#
#  Copyright Featrix, Inc 2023-2025
#
#  Rare Category Generator - tests categorical lookup with rare signal
#
#  This generates data where a categorical feature C determines the label
#  via a lookup table, but the informative categories are rare. This tests:
#  1. Whether ES can learn categorical encodings properly
#  2. Whether rare categories get sufficient embedding quality
#  3. Robustness to class imbalance in the signal
#
from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd

from .base import Generator


class RareCategoryGenerator(Generator):
    """
    Generates data with rare category signal.

    The label is determined by a lookup table on categorical feature C:
        Y = lookup_table[C]

    Where some categories that predict Y=1 are rare (low frequency).
    This tests whether ES properly encodes rare categorical values.
    """

    @property
    def name(self) -> str:
        return "rare_category_lookup"

    def generate(
        self,
        *,
        n_rows: int,
        seed: int,
        n_categories: int = 20,
        n_positive_categories: int = 5,
        rare_category_freq: float = 0.02,  # Frequency of each rare positive category
        common_category_freq: float = None,  # Auto-computed if None
        p_flip: float = 0.0,
        n_noise_dims: int = 10,
        n_noise_categorical: int = 2,  # Number of uninformative categorical features
        noise_categorical_cardinality: int = 10,
        **kwargs,
    ) -> tuple[pd.DataFrame, dict[str, Any]]:
        """
        Generate rare category lookup data.

        Args:
            n_rows: Number of rows
            seed: Random seed
            n_categories: Total number of categories in signal feature
            n_positive_categories: Number of categories that map to Y=1
            rare_category_freq: Frequency of each rare (positive) category
            common_category_freq: Frequency of common categories (auto if None)
            p_flip: Label noise probability
            n_noise_dims: Number of continuous noise dimensions
            n_noise_categorical: Number of uninformative categorical features
            noise_categorical_cardinality: Cardinality of noise categoricals

        Returns:
            (DataFrame, metadata)
        """
        rng = np.random.default_rng(seed)

        # Create category names
        categories = [f"cat_{i}" for i in range(n_categories)]
        positive_categories = set(categories[:n_positive_categories])
        negative_categories = set(categories[n_positive_categories:])

        # Compute category probabilities
        # Positive categories are rare
        total_rare_prob = rare_category_freq * n_positive_categories
        remaining_prob = 1.0 - total_rare_prob

        if remaining_prob <= 0:
            raise ValueError(
                f"rare_category_freq={rare_category_freq} * n_positive_categories={n_positive_categories} "
                f"= {total_rare_prob} exceeds 1.0"
            )

        n_negative = n_categories - n_positive_categories
        if common_category_freq is None:
            common_category_freq = remaining_prob / n_negative

        # Build probability distribution
        probs = []
        for cat in categories:
            if cat in positive_categories:
                probs.append(rare_category_freq)
            else:
                probs.append(common_category_freq)

        # Normalize to sum to 1
        probs = np.array(probs)
        probs = probs / probs.sum()

        # Generate categorical signal feature
        C_idx = rng.choice(n_categories, size=n_rows, p=probs)
        C = np.array([categories[i] for i in C_idx])

        # Generate clean labels from lookup table
        Y_clean = np.array([1 if c in positive_categories else 0 for c in C])

        # Apply label noise
        if p_flip > 0:
            flip_mask = rng.random(n_rows) < p_flip
            Y = np.where(flip_mask, 1 - Y_clean, Y_clean)
        else:
            Y = Y_clean

        # Generate continuous noise dimensions
        noise_features = {}
        for i in range(n_noise_dims):
            noise_features[f"noise_{i}"] = rng.standard_normal(n_rows)

        # Generate uninformative categorical features
        noise_categorical_features = {}
        for i in range(n_noise_categorical):
            noise_cats = [f"ncat{i}_{j}" for j in range(noise_categorical_cardinality)]
            noise_categorical_features[f"noise_cat_{i}"] = rng.choice(
                noise_cats, size=n_rows
            )

        # Build DataFrame
        data = {
            "category": C,
            **noise_features,
            **noise_categorical_features,
            "label": Y,
        }
        df = pd.DataFrame(data)

        # Compute actual statistics
        actual_positive_rate = Y.mean()
        category_counts = pd.Series(C).value_counts()
        rare_category_actual_freqs = {
            cat: category_counts.get(cat, 0) / n_rows for cat in positive_categories
        }

        # Build lookup table for metadata
        lookup_table = {cat: 1 if cat in positive_categories else 0 for cat in categories}

        ground_truth = {
            "relationship": "categorical_lookup",
            "formula": "label = lookup_table[category]",
            "signal_column": "category",
            "lookup_table": lookup_table,
            "positive_categories": list(positive_categories),
            "negative_categories": list(negative_categories),
            "informative_columns": ["category"],
            "noise_columns": list(noise_features.keys()) + list(noise_categorical_features.keys()),
        }

        metadata = self._build_metadata(
            n_rows=n_rows,
            seed=seed,
            ground_truth=ground_truth,
            n_categories=n_categories,
            n_positive_categories=n_positive_categories,
            rare_category_freq=rare_category_freq,
            common_category_freq=float(common_category_freq),
            p_flip=p_flip,
            n_noise_dims=n_noise_dims,
            n_noise_categorical=n_noise_categorical,
            noise_categorical_cardinality=noise_categorical_cardinality,
            actual_positive_rate=float(actual_positive_rate),
            rare_category_actual_freqs=rare_category_actual_freqs,
        )

        return df, metadata
