#  -*- coding: utf-8 -*-
#
#  Copyright Featrix, Inc 2023-2025
#
#  XOR Classification Generator - tests nonlinear interaction learning
#
#  This generates data where the label depends on XOR of two thresholded
#  features. This is a classic test case because:
#  1. Neither feature alone is predictive
#  2. Only their interaction matters
#  3. Linear models fail completely
#
from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd

from .base import Generator


class XORClassificationGenerator(Generator):
    """
    Generates XOR classification data.

    The label is determined by:
        S1_high = S1 > threshold1
        S2_high = S2 > threshold2
        Y = XOR(S1_high, S2_high)

    This means:
        - Y=1 when (S1 high AND S2 low) OR (S1 low AND S2 high)
        - Y=0 when both high or both low

    This tests whether ES can learn nonlinear feature interactions.
    """

    @property
    def name(self) -> str:
        return "xor_classification"

    def generate(
        self,
        *,
        n_rows: int,
        seed: int,
        threshold1: float = 0.5,
        threshold2: float = 0.5,
        p_flip: float = 0.0,
        n_noise_dims: int = 10,
        signal_distribution: str = "uniform",
        correlation: float = 0.0,  # Correlation between S1 and S2
        **kwargs,
    ) -> tuple[pd.DataFrame, dict[str, Any]]:
        """
        Generate XOR classification data.

        Args:
            n_rows: Number of rows
            seed: Random seed
            threshold1: Threshold for feature S1
            threshold2: Threshold for feature S2
            p_flip: Label noise probability
            n_noise_dims: Number of noise dimensions
            signal_distribution: Distribution of signal features
            correlation: Correlation between S1 and S2 (0 = independent)

        Returns:
            (DataFrame, metadata)
        """
        rng = np.random.default_rng(seed)

        # Generate signal features (optionally correlated)
        if signal_distribution == "uniform":
            if correlation != 0:
                # Generate correlated uniforms via copula
                z1 = rng.standard_normal(n_rows)
                z2 = correlation * z1 + np.sqrt(1 - correlation**2) * rng.standard_normal(n_rows)
                # Transform to uniform via CDF
                from scipy.stats import norm
                S1 = norm.cdf(z1)
                S2 = norm.cdf(z2)
            else:
                S1 = rng.uniform(0, 1, size=n_rows)
                S2 = rng.uniform(0, 1, size=n_rows)
        elif signal_distribution == "gaussian":
            if correlation != 0:
                z1 = rng.standard_normal(n_rows)
                z2 = correlation * z1 + np.sqrt(1 - correlation**2) * rng.standard_normal(n_rows)
                S1, S2 = z1, z2
            else:
                S1 = rng.standard_normal(n_rows)
                S2 = rng.standard_normal(n_rows)
        else:
            raise ValueError(f"Unknown signal_distribution: {signal_distribution}")

        # Adjust thresholds for balance
        if signal_distribution == "uniform":
            adj_threshold1 = threshold1
            adj_threshold2 = threshold2
        else:
            # For gaussian, use quantiles
            adj_threshold1 = np.quantile(S1, threshold1)
            adj_threshold2 = np.quantile(S2, threshold2)

        # Compute XOR label
        S1_high = S1 > adj_threshold1
        S2_high = S2 > adj_threshold2
        Y_clean = (S1_high ^ S2_high).astype(int)  # XOR

        # Apply label noise
        if p_flip > 0:
            flip_mask = rng.random(n_rows) < p_flip
            Y = np.where(flip_mask, 1 - Y_clean, Y_clean)
        else:
            Y = Y_clean

        # Generate noise dimensions
        noise_features = {}
        for i in range(n_noise_dims):
            noise_features[f"noise_{i}"] = rng.standard_normal(n_rows)

        # Build DataFrame
        data = {"signal_1": S1, "signal_2": S2, **noise_features, "label": Y}
        df = pd.DataFrame(data)

        # Build metadata
        actual_positive_rate = Y.mean()
        ground_truth = {
            "relationship": "xor",
            "formula": f"label = XOR(signal_1 > {adj_threshold1:.4f}, signal_2 > {adj_threshold2:.4f})",
            "signal_columns": ["signal_1", "signal_2"],
            "thresholds": [float(adj_threshold1), float(adj_threshold2)],
            "informative_columns": ["signal_1", "signal_2"],
            "noise_columns": list(noise_features.keys()),
            "interaction_type": "XOR (neither feature alone is predictive)",
        }

        metadata = self._build_metadata(
            n_rows=n_rows,
            seed=seed,
            ground_truth=ground_truth,
            threshold1=threshold1,
            threshold2=threshold2,
            adjusted_thresholds=[float(adj_threshold1), float(adj_threshold2)],
            p_flip=p_flip,
            n_noise_dims=n_noise_dims,
            signal_distribution=signal_distribution,
            correlation=correlation,
            actual_positive_rate=float(actual_positive_rate),
        )

        return df, metadata
