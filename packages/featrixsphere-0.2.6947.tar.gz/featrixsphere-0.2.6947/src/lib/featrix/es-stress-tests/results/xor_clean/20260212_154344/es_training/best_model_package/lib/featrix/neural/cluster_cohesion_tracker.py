#!/usr/bin/env python3
"""
Per-Epoch Cluster Cohesion Tracker

Tracks how cluster structure evolves during ES training by comparing
K-means clustering on raw features vs ES embeddings at each epoch.

Usage:
    from featrix.neural.cluster_cohesion_tracker import ClusterCohesionTracker

    tracker = ClusterCohesionTracker(raw_features, k_values=[3, 5, 7, 9])

    # During training loop:
    for epoch in range(n_epochs):
        es.train_one_epoch()
        embeddings = es.encode_batch(samples)
        tracker.record_epoch(epoch, embeddings)

    # After training:
    tracker.save_results("cluster_cohesion.json")
    tracker.generate_movie("cluster_cohesion_movie.gif")
"""

import gzip
import json
import logging
import numpy as np
import sqlite3
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from scipy.optimize import linear_sum_assignment
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import StandardScaler, OneHotEncoder

from featrix.neural.utils import atomic_write_json

logger = logging.getLogger(__name__)


class ClusterMembershipDB:
    """
    SQLite storage for per-epoch cluster membership labels.

    Stores which cluster each sample belongs to at each epoch, enabling
    Sankey diagram generation showing membership flow across epochs.

    Schema:
        cluster_labels(epoch, k, labels_blob) - compressed numpy int8 arrays
        metadata(key, value) - n_samples, k_values, sample_indices
    """

    def __init__(self, db_path: str | Path):
        self.db_path = Path(db_path)
        self.conn = sqlite3.connect(str(self.db_path))
        self._init_db()

    def _init_db(self):
        """Initialize database schema."""
        cursor = self.conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS cluster_labels (
                epoch INTEGER,
                k INTEGER,
                labels_blob BLOB,
                PRIMARY KEY (epoch, k)
            )
        """)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS metadata (
                key TEXT PRIMARY KEY,
                value TEXT
            )
        """)
        self.conn.commit()

    def set_metadata(self, n_samples: int, k_values: List[int], sample_indices: List[int] = None):
        """Store metadata about the tracking session."""
        cursor = self.conn.cursor()
        cursor.execute(
            "INSERT OR REPLACE INTO metadata (key, value) VALUES (?, ?)",
            ("n_samples", str(n_samples))
        )
        cursor.execute(
            "INSERT OR REPLACE INTO metadata (key, value) VALUES (?, ?)",
            ("k_values", json.dumps(k_values))
        )
        if sample_indices is not None:
            cursor.execute(
                "INSERT OR REPLACE INTO metadata (key, value) VALUES (?, ?)",
                ("sample_indices", json.dumps(sample_indices))
            )
        self.conn.commit()

    def get_metadata(self) -> Dict:
        """Retrieve metadata."""
        cursor = self.conn.cursor()
        cursor.execute("SELECT key, value FROM metadata")
        rows = cursor.fetchall()
        result = {}
        for key, value in rows:
            if key == "n_samples":
                result[key] = int(value)
            elif key in ("k_values", "sample_indices"):
                result[key] = json.loads(value)
            else:
                result[key] = value
        return result

    def save_labels(self, epoch: int, k: int, labels: np.ndarray):
        """
        Save cluster labels for an epoch/k combination.

        Args:
            epoch: Epoch number
            k: Number of clusters
            labels: numpy array of cluster assignments, shape (n_samples,)
        """
        # Convert to int8 (supports up to 127 clusters) and compress
        labels_int8 = labels.astype(np.int8)
        labels_blob = gzip.compress(labels_int8.tobytes())

        cursor = self.conn.cursor()
        cursor.execute(
            "INSERT OR REPLACE INTO cluster_labels (epoch, k, labels_blob) VALUES (?, ?, ?)",
            (epoch, k, labels_blob)
        )
        self.conn.commit()

    def get_labels(self, epoch: int, k: int) -> Optional[np.ndarray]:
        """
        Retrieve cluster labels for an epoch/k combination.

        Returns:
            numpy array of cluster assignments, or None if not found
        """
        cursor = self.conn.cursor()
        cursor.execute(
            "SELECT labels_blob FROM cluster_labels WHERE epoch = ? AND k = ?",
            (epoch, k)
        )
        row = cursor.fetchone()
        if row is None:
            return None

        labels_blob = row[0]
        labels_bytes = gzip.decompress(labels_blob)
        return np.frombuffer(labels_bytes, dtype=np.int8)

    def get_epochs(self) -> List[int]:
        """Get list of epochs with stored labels."""
        cursor = self.conn.cursor()
        cursor.execute("SELECT DISTINCT epoch FROM cluster_labels ORDER BY epoch")
        return [row[0] for row in cursor.fetchall()]

    def compute_flow_matrix(self, epoch_from: int, epoch_to: int, k: int) -> Optional[np.ndarray]:
        """
        Compute flow matrix between two epochs for a given k.

        Returns:
            (k, k) matrix where flow[i,j] = count of samples that moved
            from cluster i at epoch_from to cluster j at epoch_to.
            Returns None if labels not available for either epoch.
        """
        labels_from = self.get_labels(epoch_from, k)
        labels_to = self.get_labels(epoch_to, k)

        if labels_from is None or labels_to is None:
            return None

        if len(labels_from) != len(labels_to):
            logger.warning(f"Label count mismatch: {len(labels_from)} vs {len(labels_to)}")
            return None

        # Build flow matrix
        flow = np.zeros((k, k), dtype=np.int32)
        for i in range(len(labels_from)):
            flow[labels_from[i], labels_to[i]] += 1

        return flow

    def close(self):
        """Close database connection."""
        if self.conn:
            self.conn.close()
            self.conn = None


@dataclass
class EpochCohesionMetrics:
    """Metrics for a single epoch and K value."""
    epoch: int
    k: int
    raw_silhouette: float
    es_silhouette: float
    silhouette_improvement: float
    jaccard_mean: float
    jaccard_std: float
    jaccard_per_cluster: List[float]
    matched_pairs: List[Tuple[int, int]]
    raw_cluster_sizes: List[int]
    es_cluster_sizes: List[int]
    # Context-aligned metrics (optional, may be None for backward compat)
    missingness_jaccard: Optional[float] = None  # Jaccard between missingness clusters and ES clusters
    neighbor_preservation: Optional[float] = None  # Fraction of k-NN preserved in embedding space


@dataclass
class ClusterCohesionHistory:
    """Full history of cluster cohesion across epochs."""
    k_values: List[int]
    n_samples: int
    raw_feature_dim: int
    embedding_dim: int
    epochs: List[int] = field(default_factory=list)
    metrics: Dict[int, List[EpochCohesionMetrics]] = field(default_factory=dict)  # k -> list of epoch metrics

    def to_dict(self):
        """Convert to JSON-serializable dict."""
        return {
            'k_values': self.k_values,
            'n_samples': self.n_samples,
            'raw_feature_dim': self.raw_feature_dim,
            'embedding_dim': self.embedding_dim,
            'epochs': self.epochs,
            'metrics': {
                str(k): [asdict(m) for m in metrics_list]
                for k, metrics_list in self.metrics.items()
            }
        }


class ClusterCohesionTracker:
    """
    Tracks cluster cohesion between raw features and ES embeddings across epochs.

    This allows correlating cluster structure changes with training metrics like
    loss, AUC, etc.
    """

    def __init__(
        self,
        raw_features: np.ndarray,
        k_values: List[int] = [3, 5, 7, 9, 11, 13],
        random_state: int = 42,
        missingness_mask: Optional[np.ndarray] = None,
        n_neighbors_for_preservation: int = 10,
        output_dir: str | Path = None,
        sample_indices: List[int] = None
    ):
        """
        Initialize tracker with raw feature data.

        Args:
            raw_features: Pre-processed raw features (n_samples, n_features)
            k_values: List of K values for K-means clustering
            random_state: Random seed for reproducibility
            missingness_mask: Optional boolean mask (n_samples, n_cols) where True = missing.
                              If provided, enables context-aligned metrics.
            n_neighbors_for_preservation: K for k-NN neighbor preservation metric
            output_dir: Directory to store cluster_membership.db. If None, labels are not persisted.
            sample_indices: Original row indices if data was subsampled (for traceability)
        """
        self.raw_features = raw_features
        self.k_values = [k for k in k_values if k < len(raw_features)]
        self.random_state = random_state
        self.n_samples = len(raw_features)
        self.n_neighbors = n_neighbors_for_preservation
        self.output_dir = Path(output_dir) if output_dir else None
        self._sample_indices = sample_indices

        # Initialize cluster membership database if output_dir provided
        self._membership_db: Optional[ClusterMembershipDB] = None
        if self.output_dir:
            db_path = self.output_dir / "cluster_membership.db"
            self._membership_db = ClusterMembershipDB(db_path)
            self._membership_db.set_metadata(
                n_samples=self.n_samples,
                k_values=self.k_values,
                sample_indices=sample_indices
            )
            logger.info(f"🔍 ClusterCohesionTracker: Initialized membership DB at {db_path}")

        # Pre-compute raw clustering for each K (doesn't change)
        self._raw_labels = {}
        self._raw_silhouettes = {}
        self._raw_cluster_sets = {}

        logger.info(f"🔍 ClusterCohesionTracker: Pre-computing raw clustering for K={self.k_values}")
        for k in self.k_values:
            kmeans = KMeans(n_clusters=k, random_state=random_state, n_init=10)
            labels = kmeans.fit_predict(raw_features)
            self._raw_labels[k] = labels
            self._raw_silhouettes[k] = silhouette_score(raw_features, labels)
            self._raw_cluster_sets[k] = {i: set(np.where(labels == i)[0]) for i in range(k)}

        # Pre-compute missingness clustering if mask provided
        self._missingness_labels = {}
        self._missingness_cluster_sets = {}
        if missingness_mask is not None:
            self.missingness_mask = missingness_mask
            logger.info(f"🔍 ClusterCohesionTracker: Pre-computing missingness pattern clustering")
            for k in self.k_values:
                # Cluster by missingness pattern (binary vectors)
                kmeans = KMeans(n_clusters=k, random_state=random_state, n_init=10)
                labels = kmeans.fit_predict(missingness_mask.astype(float))
                self._missingness_labels[k] = labels
                self._missingness_cluster_sets[k] = {i: set(np.where(labels == i)[0]) for i in range(k)}
        else:
            self.missingness_mask = None

        # Pre-compute raw space k-NN for neighbor preservation metric
        self._raw_knn = None
        if self.n_samples > self.n_neighbors:
            from sklearn.neighbors import NearestNeighbors
            nn = NearestNeighbors(n_neighbors=self.n_neighbors + 1, algorithm='auto')
            nn.fit(raw_features)
            # Get indices of k nearest neighbors (excluding self)
            _, indices = nn.kneighbors(raw_features)
            self._raw_knn = indices[:, 1:]  # Exclude self (first column)
            logger.info(f"🔍 ClusterCohesionTracker: Pre-computed {self.n_neighbors}-NN for neighbor preservation")

        # Initialize history
        self.history = ClusterCohesionHistory(
            k_values=self.k_values,
            n_samples=self.n_samples,
            raw_feature_dim=raw_features.shape[1],
            embedding_dim=0  # Set on first record
        )

        # Store jaccard matrices for movie generation
        self._jaccard_matrices = {}  # (epoch, k) -> matrix

        # MI-weighted k-NN support for neighbor preservation loss
        self._column_weights: Optional[np.ndarray] = None
        self._weighted_knn: Optional[np.ndarray] = None
        self._knn_update_count: int = 0

    def get_neighbor_indices(self) -> Optional[np.ndarray]:
        """
        Get k-NN indices for neighbor preservation loss.

        Returns MI-weighted k-NN if available, otherwise raw feature k-NN.

        Returns:
            (n_samples, k) array of neighbor indices, or None if not computed
        """
        if self._weighted_knn is not None:
            return self._weighted_knn
        return self._raw_knn

    def update_column_weights(
        self,
        col_marginal_losses: Dict[str, float],
        col_order: List[str],
        feature_col_mapping: Optional[Dict[str, List[int]]] = None
    ) -> bool:
        """
        Update k-NN using column importance weights derived from marginal losses.

        Higher marginal loss = harder to predict = MORE important for similarity.
        This recomputes the k-NN graph using MI-weighted distances.

        Args:
            col_marginal_losses: Dict mapping column names to their marginal loss values
            col_order: List of column names in order
            feature_col_mapping: Optional mapping from column names to feature indices
                                 in raw_features. If None, assumes 1:1 mapping.

        Returns:
            True if k-NN was recomputed, False if skipped
        """
        if not col_marginal_losses:
            logger.debug("No col_marginal_losses provided, skipping k-NN update")
            return False

        n_features = self.raw_features.shape[1]

        # Build weight vector for features
        # Default: uniform weights
        weights = np.ones(n_features)

        if feature_col_mapping is not None:
            # Use provided mapping from columns to feature indices
            for col_name, feat_indices in feature_col_mapping.items():
                loss_val = col_marginal_losses.get(col_name, 0.0)
                for idx in feat_indices:
                    if 0 <= idx < n_features:
                        weights[idx] = loss_val
        else:
            # Simple heuristic: assume features are in same order as columns
            # This works when raw_features was built from prepare_raw_features()
            # with same column order
            for i, col_name in enumerate(col_order):
                if i < n_features:
                    weights[i] = col_marginal_losses.get(col_name, 0.0)

        # Normalize weights (higher loss = more important)
        weights = weights + 1e-8  # Avoid zeros
        weights = weights / weights.sum()
        weights = np.sqrt(weights)  # Use sqrt to avoid over-weighting

        # Check if weights changed significantly
        if self._column_weights is not None:
            weight_change = np.abs(weights - self._column_weights).mean()
            if weight_change < 0.01:
                logger.debug(f"Column weights changed by only {weight_change:.4f}, skipping k-NN recompute")
                return False

        self._column_weights = weights
        self._knn_update_count += 1

        # Recompute k-NN with weighted distance
        try:
            from sklearn.neighbors import NearestNeighbors

            # Weight the features
            weighted_features = self.raw_features * weights[np.newaxis, :]

            # Recompute k-NN
            nn = NearestNeighbors(n_neighbors=self.n_neighbors + 1, algorithm='auto')
            nn.fit(weighted_features)
            _, indices = nn.kneighbors(weighted_features)
            self._weighted_knn = indices[:, 1:]  # Exclude self

            logger.info(
                f"🔍 ClusterCohesionTracker: Recomputed MI-weighted {self.n_neighbors}-NN "
                f"(update #{self._knn_update_count})"
            )
            return True

        except Exception as e:
            logger.warning(f"⚠️  Failed to recompute weighted k-NN: {e}")
            return False

    def record_epoch(self, epoch: int, embeddings: np.ndarray) -> Dict[int, EpochCohesionMetrics]:
        """
        Record cluster cohesion metrics for this epoch.

        Args:
            epoch: Current epoch number
            embeddings: ES embeddings for the same samples (n_samples, embedding_dim)

        Returns:
            Dict mapping K -> metrics for this epoch
        """
        if len(embeddings) != self.n_samples:
            logger.warning(f"⚠️  Sample count mismatch: expected {self.n_samples}, got {len(embeddings)}")
            return {}

        if self.history.embedding_dim == 0:
            self.history.embedding_dim = embeddings.shape[1]

        self.history.epochs.append(epoch)
        epoch_metrics = {}

        # Compute neighbor preservation once per epoch (not per K)
        neighbor_preservation = self._compute_neighbor_preservation(embeddings)

        for k in self.k_values:
            # Cluster embeddings
            es_kmeans = KMeans(n_clusters=k, random_state=self.random_state, n_init=10)
            es_labels = es_kmeans.fit_predict(embeddings)
            es_sil = silhouette_score(embeddings, es_labels)

            # Save labels to database for Sankey generation
            if self._membership_db is not None:
                self._membership_db.save_labels(epoch, k, es_labels)

            # Build ES cluster sets
            es_sets = {i: set(np.where(es_labels == i)[0]) for i in range(k)}

            # Compute Jaccard matrix (raw vs ES)
            jaccard_matrix = np.zeros((k, k))
            for i in range(k):
                for j in range(k):
                    raw_set = self._raw_cluster_sets[k][i]
                    es_set = es_sets[j]
                    intersection = len(raw_set & es_set)
                    union = len(raw_set | es_set)
                    jaccard_matrix[i, j] = intersection / union if union > 0 else 0

            # Store for movie
            self._jaccard_matrices[(epoch, k)] = jaccard_matrix.copy()

            # Optimal 1:1 matching
            row_ind, col_ind = linear_sum_assignment(-jaccard_matrix)
            matched_jaccards = [jaccard_matrix[i, j] for i, j in zip(row_ind, col_ind)]

            # Compute missingness-aligned Jaccard if available
            missingness_jaccard = None
            if self._missingness_cluster_sets:
                miss_jaccard_matrix = np.zeros((k, k))
                for i in range(k):
                    for j in range(k):
                        miss_set = self._missingness_cluster_sets[k][i]
                        es_set = es_sets[j]
                        intersection = len(miss_set & es_set)
                        union = len(miss_set | es_set)
                        miss_jaccard_matrix[i, j] = intersection / union if union > 0 else 0
                miss_row_ind, miss_col_ind = linear_sum_assignment(-miss_jaccard_matrix)
                miss_matched = [miss_jaccard_matrix[i, j] for i, j in zip(miss_row_ind, miss_col_ind)]
                missingness_jaccard = float(np.mean(miss_matched))

            metrics = EpochCohesionMetrics(
                epoch=epoch,
                k=k,
                raw_silhouette=self._raw_silhouettes[k],
                es_silhouette=es_sil,
                silhouette_improvement=es_sil - self._raw_silhouettes[k],
                jaccard_mean=np.mean(matched_jaccards),
                jaccard_std=np.std(matched_jaccards),
                jaccard_per_cluster=matched_jaccards,
                matched_pairs=list(zip(row_ind.tolist(), col_ind.tolist())),
                raw_cluster_sizes=[len(self._raw_cluster_sets[k][i]) for i in range(k)],
                es_cluster_sizes=[len(es_sets[i]) for i in range(k)],
                missingness_jaccard=missingness_jaccard,
                neighbor_preservation=neighbor_preservation
            )

            epoch_metrics[k] = metrics

            # Store in history
            if k not in self.history.metrics:
                self.history.metrics[k] = []
            self.history.metrics[k].append(metrics)

        # Write incremental per-epoch JSON for crash resilience
        self._write_epoch_json(epoch, epoch_metrics)

        return epoch_metrics

    def _write_epoch_json(self, epoch: int, epoch_metrics: Dict[int, 'EpochCohesionMetrics']):
        """Write per-epoch cohesion data to JSON for crash resilience and cross-domain analysis."""
        if self.output_dir is None:
            return

        try:
            cohesion_dir = self.output_dir / "epoch_projections"
            cohesion_dir.mkdir(parents=True, exist_ok=True)

            # Build epoch data with metrics for all K values
            epoch_data = {
                "epoch": epoch,
                "k_values": self.k_values,
                "metrics_by_k": {},
            }

            for k, metrics in epoch_metrics.items():
                # Get cluster labels for this epoch/k
                labels = None
                if self._membership_db is not None:
                    labels = self._membership_db.get_labels(epoch, k)

                epoch_data["metrics_by_k"][k] = {
                    **asdict(metrics),
                    # Include per-sample cluster assignments for cross-domain analysis
                    "cluster_labels": labels.tolist() if labels is not None else None,
                }

            # Write atomically
            output_file = cohesion_dir / f"cohesion_epoch_{epoch:04d}.json"
            atomic_write_json(output_file, epoch_data, indent=2)

        except Exception as e:
            logger.warning(f"Failed to write epoch cohesion JSON for epoch {epoch}: {e}")

    def get_membership_labels(self, epoch: int, k: int) -> Optional[np.ndarray]:
        """
        Get cluster membership labels for a specific epoch and k.

        Returns:
            numpy array of cluster assignments (n_samples,), or None if not stored
        """
        if self._membership_db is None:
            return None
        return self._membership_db.get_labels(epoch, k)

    def get_membership_flow(self, epoch_from: int, epoch_to: int, k: int) -> Optional[np.ndarray]:
        """
        Compute cluster membership flow matrix between two epochs.

        Returns:
            (k, k) matrix where flow[i,j] = count of samples that moved
            from cluster i at epoch_from to cluster j at epoch_to.
            Returns None if labels not available.
        """
        if self._membership_db is None:
            return None
        return self._membership_db.compute_flow_matrix(epoch_from, epoch_to, k)

    def get_recorded_epochs(self) -> List[int]:
        """Get list of epochs with stored cluster membership labels."""
        if self._membership_db is None:
            return []
        return self._membership_db.get_epochs()

    def close(self):
        """Close any open resources (database connections, etc.)."""
        if self._membership_db is not None:
            self._membership_db.close()
            self._membership_db = None

    def _compute_neighbor_preservation(self, embeddings: np.ndarray) -> Optional[float]:
        """
        Compute what fraction of raw-space k-NN are preserved in embedding space.

        This measures whether rows that were close in raw feature space remain
        close in embedding space - a proxy for structure preservation.

        Returns:
            Fraction of neighbors preserved (0 to 1), or None if not computable
        """
        if self._raw_knn is None:
            return None

        from sklearn.neighbors import NearestNeighbors

        # Find k-NN in embedding space
        nn = NearestNeighbors(n_neighbors=self.n_neighbors + 1, algorithm='auto')
        nn.fit(embeddings)
        _, es_indices = nn.kneighbors(embeddings)
        es_knn = es_indices[:, 1:]  # Exclude self

        # For each sample, count how many of its raw-space neighbors are also
        # among its embedding-space neighbors
        preserved_count = 0
        total_count = 0

        for i in range(self.n_samples):
            raw_neighbors = set(self._raw_knn[i])
            es_neighbors = set(es_knn[i])
            preserved_count += len(raw_neighbors & es_neighbors)
            total_count += len(raw_neighbors)

        return preserved_count / total_count if total_count > 0 else None

    def log_epoch_summary(self, epoch: int, epoch_metrics: Dict[int, EpochCohesionMetrics]):
        """Log a compact summary for this epoch."""
        if not epoch_metrics:
            return

        # Pick a representative K (middle value)
        k = self.k_values[len(self.k_values) // 2]
        m = epoch_metrics.get(k)
        if m:
            # Build context-aligned metrics string if available
            context_str = ""
            if m.neighbor_preservation is not None:
                context_str += f", kNN={m.neighbor_preservation:.3f}"
            if m.missingness_jaccard is not None:
                context_str += f", MissJac={m.missingness_jaccard:.3f}"

            logger.info(
                f"📊 Cluster cohesion [e={epoch:03d}] K={k}: "
                f"Sil={m.es_silhouette:.3f} (Δ{m.silhouette_improvement:+.3f}), "
                f"RawJac={m.jaccard_mean:.3f}{context_str}"
            )

    def get_summary_for_epoch(self, epoch: int) -> Optional[Dict]:
        """Get summary metrics for charting/logging."""
        summary = {}
        for k in self.k_values:
            if k in self.history.metrics:
                for m in self.history.metrics[k]:
                    if m.epoch == epoch:
                        summary[f'cluster_sil_k{k}'] = m.es_silhouette
                        summary[f'cluster_sil_improvement_k{k}'] = m.silhouette_improvement
                        summary[f'cluster_jaccard_k{k}'] = m.jaccard_mean
                        summary[f'cluster_jaccard_std_k{k}'] = m.jaccard_std
                        if m.neighbor_preservation is not None:
                            summary[f'neighbor_preservation_k{k}'] = m.neighbor_preservation
                        if m.missingness_jaccard is not None:
                            summary[f'missingness_jaccard_k{k}'] = m.missingness_jaccard
                        break
        return summary if summary else None

    def save_results(self, path: str):
        """Save full history to JSON."""
        with open(path, 'w') as f:
            json.dump(self.history.to_dict(), f, indent=2)
        logger.info(f"💾 Saved cluster cohesion history to {path}")

    def log_final_report(self):
        """Log a comprehensive final clustering report at end of training."""
        if not self.history.epochs:
            logger.info("📊 No cluster cohesion data recorded during training")
            return

        logger.info("")
        logger.info("=" * 100)
        logger.info("📊 CLUSTER COHESION FINAL REPORT")
        logger.info("=" * 100)
        logger.info(f"   Samples tracked: {self.n_samples}")
        logger.info(f"   Raw feature dim: {self.history.raw_feature_dim}")
        logger.info(f"   Embedding dim: {self.history.embedding_dim}")
        logger.info(f"   Epochs tracked: {len(self.history.epochs)} ({self.history.epochs[0]} to {self.history.epochs[-1]})")
        logger.info("")

        # Get final epoch metrics
        final_epoch = self.history.epochs[-1]

        # Table header - show Jaccard lift vs random (1/K baseline)
        logger.info("┌─────────┬─────────────┬─────────────┬─────────────┬─────────────┬─────────────┐")
        logger.info("│    K    │  Raw Sil.   │   ES Sil.   │  Sil. Δ     │ Jac vs Rand │   kNN Pres. │")
        logger.info("├─────────┼─────────────┼─────────────┼─────────────┼─────────────┼─────────────┤")

        for k in self.k_values:
            if k in self.history.metrics and self.history.metrics[k]:
                # Get final metrics for this K
                final_m = None
                for m in self.history.metrics[k]:
                    if m.epoch == final_epoch:
                        final_m = m
                        break

                if final_m:
                    knn_str = f"{final_m.neighbor_preservation:.3f}" if final_m.neighbor_preservation is not None else "N/A"
                    # Compute Jaccard lift vs random baseline (1/K)
                    random_baseline = 1.0 / k
                    jaccard_lift = final_m.jaccard_mean / random_baseline
                    logger.info(
                        f"│   {k:3d}   │    {final_m.raw_silhouette:+.3f}   │    {final_m.es_silhouette:+.3f}   │"
                        f"    {final_m.silhouette_improvement:+.3f}   │    {jaccard_lift:5.2f}×    │     {knn_str:>5}   │"
                    )

        logger.info("└─────────┴─────────────┴─────────────┴─────────────┴─────────────┴─────────────┘")

        # Summary interpretation
        logger.info("")

        # Calculate average improvements across K values
        sil_improvements = []
        knn_preservations = []
        for k in self.k_values:
            if k in self.history.metrics and self.history.metrics[k]:
                for m in self.history.metrics[k]:
                    if m.epoch == final_epoch:
                        sil_improvements.append(m.silhouette_improvement)
                        if m.neighbor_preservation is not None:
                            knn_preservations.append(m.neighbor_preservation)
                        break

        if sil_improvements:
            avg_sil_improvement = np.mean(sil_improvements)
            if avg_sil_improvement > 0.05:
                logger.info(f"   ✅ Embedding improves cluster separation (avg Δ={avg_sil_improvement:+.3f})")
            elif avg_sil_improvement < -0.05:
                logger.info(f"   ⚠️  Embedding reduces cluster separation (avg Δ={avg_sil_improvement:+.3f})")
            else:
                logger.info(f"   ℹ️  Embedding has similar cluster separation (avg Δ={avg_sil_improvement:+.3f})")

        if knn_preservations:
            avg_knn = np.mean(knn_preservations)
            if avg_knn > 0.3:
                logger.info(f"   ✅ Good neighbor preservation ({avg_knn:.1%} of k-NN preserved)")
            elif avg_knn > 0.15:
                logger.info(f"   ⚠️  Moderate neighbor preservation ({avg_knn:.1%} of k-NN preserved)")
            else:
                logger.info(f"   ⚠️  Low neighbor preservation ({avg_knn:.1%} of k-NN preserved)")
                logger.info(f"      Note: Low preservation is expected if embedding learns context-based relationships")

        logger.info("")
        logger.info("   Metric Explanations:")
        logger.info("   • Silhouette: Cluster separation quality (-1 to 1, higher = better separated)")
        logger.info("   • Sil. Δ: Change from raw features to embedding (positive = embedding improves clustering)")
        logger.info("   • Jac vs Rand: Jaccard similarity vs random baseline (>1× = better than random, <1× = worse)")
        logger.info("   • kNN Pres.: Fraction of k-nearest neighbors preserved in embedding space")
        logger.info("=" * 100)

    def generate_timeline_plot(self, output_path: str):
        """Generate a timeline plot showing metrics across epochs."""
        import matplotlib.pyplot as plt

        if not self.history.epochs:
            logger.warning("No epochs recorded yet")
            return

        fig, axes = plt.subplots(2, 2, figsize=(14, 10))

        epochs = self.history.epochs

        # Plot 1: Silhouette over time for each K
        ax = axes[0, 0]
        for k in self.k_values:
            if k in self.history.metrics:
                sils = [m.es_silhouette for m in self.history.metrics[k]]
                ax.plot(epochs[:len(sils)], sils, '-o', label=f'K={k}', markersize=3)
        ax.axhline(y=0, color='gray', linestyle='--', alpha=0.5)
        ax.set_xlabel('Epoch')
        ax.set_ylabel('ES Silhouette Score')
        ax.set_title('Cluster Separation Quality Over Training')
        ax.legend()
        ax.grid(True, alpha=0.3)

        # Plot 2: Silhouette improvement over time
        ax = axes[0, 1]
        for k in self.k_values:
            if k in self.history.metrics:
                imps = [m.silhouette_improvement for m in self.history.metrics[k]]
                ax.plot(epochs[:len(imps)], imps, '-o', label=f'K={k}', markersize=3)
        ax.axhline(y=0, color='gray', linestyle='--', alpha=0.5)
        ax.set_xlabel('Epoch')
        ax.set_ylabel('Silhouette Improvement (ES - Raw)')
        ax.set_title('Cluster Separation Improvement Over Training')
        ax.legend()
        ax.grid(True, alpha=0.3)

        # Plot 3: Jaccard mean over time
        ax = axes[1, 0]
        for k in self.k_values:
            if k in self.history.metrics:
                jacs = [m.jaccard_mean for m in self.history.metrics[k]]
                ax.plot(epochs[:len(jacs)], jacs, '-o', label=f'K={k}', markersize=3)
        ax.set_xlabel('Epoch')
        ax.set_ylabel('Jaccard Similarity (Mean)')
        ax.set_title('Cluster Membership Overlap Over Training')
        ax.set_ylim(0, 1)
        ax.legend()
        ax.grid(True, alpha=0.3)

        # Plot 4: Jaccard std over time (variance in matching quality)
        ax = axes[1, 1]
        for k in self.k_values:
            if k in self.history.metrics:
                stds = [m.jaccard_std for m in self.history.metrics[k]]
                ax.plot(epochs[:len(stds)], stds, '-o', label=f'K={k}', markersize=3)
        ax.set_xlabel('Epoch')
        ax.set_ylabel('Jaccard Std Dev')
        ax.set_title('Cluster Match Variance Over Training')
        ax.legend()
        ax.grid(True, alpha=0.3)

        plt.tight_layout()
        fig.savefig(output_path, dpi=150, bbox_inches='tight')
        plt.close(fig)
        logger.info(f"📈 Saved timeline plot to {output_path}")

    def dump_to_directory(self, output_dir: str):
        """
        Dump all cluster cohesion data to a directory.

        Creates:
            - cluster_cohesion.json: Full history data
            - timeline_plot.png: Metrics over epochs
            - jaccard_heatmap_k{K}.gif: Animated heatmaps for each K
            - per_epoch/epoch_{N}_k{K}.json: Individual epoch data

        Args:
            output_dir: Directory to save all outputs
        """
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        # 1. Save full JSON history
        json_path = output_path / "cluster_cohesion.json"
        self.save_results(str(json_path))

        # 2. Generate timeline plot
        timeline_path = output_path / "timeline_plot.png"
        self.generate_timeline_plot(str(timeline_path))

        # 3. Generate heatmap movies for each K
        for k in self.k_values:
            movie_path = output_path / f"jaccard_heatmap_k{k}.gif"
            self.generate_heatmap_movie(str(movie_path), k=k)

        # 4. Save per-epoch detailed data
        per_epoch_dir = output_path / "per_epoch"
        per_epoch_dir.mkdir(exist_ok=True)

        for epoch in self.history.epochs:
            for k in self.k_values:
                if (epoch, k) in self._jaccard_matrices:
                    epoch_data = {
                        'epoch': epoch,
                        'k': k,
                        'jaccard_matrix': self._jaccard_matrices[(epoch, k)].tolist()
                    }
                    # Add metrics if available
                    for m in self.history.metrics.get(k, []):
                        if m.epoch == epoch:
                            epoch_data.update(asdict(m))
                            break

                    epoch_file = per_epoch_dir / f"epoch_{epoch:04d}_k{k}.json"
                    with open(epoch_file, 'w') as f:
                        json.dump(epoch_data, f, indent=2)

        logger.info(f"📁 Dumped all cluster cohesion data to {output_dir}")
        logger.info(f"   - {json_path.name}")
        logger.info(f"   - {timeline_path.name}")
        logger.info(f"   - {len(self.k_values)} heatmap movies")
        logger.info(f"   - {len(list(per_epoch_dir.glob('*.json')))} per-epoch files")

    def generate_heatmap_movie(self, output_path: str, k: int = None, fps: float = 2.0):
        """
        Generate animated GIF of Jaccard heatmaps over epochs.

        Args:
            output_path: Output path for GIF
            k: K value to use (default: middle K)
            fps: Frames per second
        """
        import matplotlib.pyplot as plt
        import matplotlib.animation as animation

        if k is None:
            k = self.k_values[len(self.k_values) // 2]

        if k not in self.k_values:
            logger.warning(f"K={k} not in tracked values {self.k_values}")
            return

        # Get all epochs with this K
        epochs_with_k = [e for e in self.history.epochs if (e, k) in self._jaccard_matrices]
        if not epochs_with_k:
            logger.warning(f"No Jaccard matrices recorded for K={k}")
            return

        fig, ax = plt.subplots(figsize=(10, 8))

        def animate(frame_idx):
            ax.clear()
            epoch = epochs_with_k[frame_idx]
            jm = self._jaccard_matrices[(epoch, k)]

            # Get metrics for this epoch
            metrics = None
            for m in self.history.metrics.get(k, []):
                if m.epoch == epoch:
                    metrics = m
                    break

            im = ax.imshow(jm, cmap='YlOrRd', aspect='equal', vmin=0, vmax=1)

            # Add text annotations
            for i in range(k):
                for j in range(k):
                    val = jm[i, j]
                    color = 'white' if val > 0.5 else 'black'
                    ax.text(j, i, f'{val:.2f}', ha='center', va='center',
                           fontsize=max(8, 14 - k), color=color, fontweight='bold')

            ax.set_xticks(range(k))
            ax.set_yticks(range(k))

            if metrics:
                ax.set_xticklabels([f'ES[{j}]\n(n={metrics.es_cluster_sizes[j]})' for j in range(k)], fontsize=9)
                ax.set_yticklabels([f'Raw[{i}] (n={metrics.raw_cluster_sizes[i]})' for i in range(k)], fontsize=9)
                title = (f'Epoch {epoch}: Jaccard Matrix K={k}\n'
                        f'Mean: {metrics.jaccard_mean:.3f} ± {metrics.jaccard_std:.3f}  |  '
                        f'Sil Δ: {metrics.silhouette_improvement:+.3f}')
            else:
                ax.set_xticklabels([f'ES[{j}]' for j in range(k)], fontsize=9)
                ax.set_yticklabels([f'Raw[{i}]' for i in range(k)], fontsize=9)
                title = f'Epoch {epoch}: Jaccard Matrix K={k}'

            ax.set_xlabel('ES Embedding Clusters', fontsize=12)
            ax.set_ylabel('Raw Feature Clusters', fontsize=12)
            ax.set_title(title, fontsize=12, fontweight='bold')

            if frame_idx == 0 and not hasattr(animate, 'cbar'):
                animate.cbar = fig.colorbar(im, ax=ax, label='Jaccard Similarity')

            return [im]

        anim = animation.FuncAnimation(
            fig, animate,
            frames=len(epochs_with_k),
            interval=1000 / fps,
            blit=False
        )

        try:
            anim.save(output_path, writer='pillow', fps=fps)
            logger.info(f"🎬 Saved heatmap movie to {output_path}")
        except Exception as e:
            logger.warning(f"⚠️  Could not save GIF: {e}")

        plt.close(fig)


def prepare_raw_features(df, ignore_cols: List[str] = None) -> np.ndarray:
    """
    Prepare raw features from a DataFrame for cluster comparison.

    Handles numeric scaling and categorical one-hot encoding.

    Args:
        df: Input DataFrame
        ignore_cols: Columns to exclude (e.g., target column)

    Returns:
        Processed feature matrix (n_samples, n_features)
    """
    ignore_cols = ignore_cols or []
    df_features = df.drop(columns=[c for c in ignore_cols if c in df.columns], errors='ignore')

    # Identify column types
    numeric_cols = df_features.select_dtypes(include=[np.number]).columns.tolist()
    categorical_cols = df_features.select_dtypes(include=['object', 'category']).columns.tolist()

    processed_parts = []

    if numeric_cols:
        numeric_data = df_features[numeric_cols].fillna(0).values
        scaler = StandardScaler()
        numeric_data = scaler.fit_transform(numeric_data)
        processed_parts.append(numeric_data)

    if categorical_cols:
        categorical_data = df_features[categorical_cols].astype(str).fillna('__MISSING__')
        encoder = OneHotEncoder(sparse_output=False, handle_unknown='ignore')
        categorical_encoded = encoder.fit_transform(categorical_data)
        processed_parts.append(categorical_encoded)

    if not processed_parts:
        raise ValueError("No features to process")

    return np.hstack(processed_parts)


def run_cohesion_check(
    es,
    df,
    epoch_idx: int,
    tracker: Optional[ClusterCohesionTracker] = None,
    sample_size: int = 2000,
    k_values: List[int] = None,
    ignore_cols: List[str] = None,
    random_state: int = 42,
    output_dir: str | Path = None
) -> Optional[ClusterCohesionTracker]:
    """
    Run cluster cohesion check during ES training.

    This is the main entry point for integrating cohesion tracking into training.
    Call this periodically (e.g., every 5 epochs) to track how cluster structure
    evolves during training.

    Args:
        es: EmbeddingSpace instance (must have encode_record method)
        df: DataFrame with training data
        epoch_idx: Current epoch number
        tracker: Existing tracker (None on first call, reuse on subsequent calls)
        sample_size: Max rows to sample for efficiency
        k_values: K values for clustering (default: [3, 5, 7, 9, 11, 13])
        ignore_cols: Columns to ignore (e.g., target column)
        random_state: Random seed
        output_dir: Directory to store cluster_membership.db for Sankey generation.
                    If None, labels are not persisted to disk.

    Returns:
        ClusterCohesionTracker instance (pass back on next call)
    """
    if k_values is None:
        k_values = [3, 5, 7, 9, 11, 13]

    ignore_cols = ignore_cols or []
    if hasattr(es, 'target_column') and es.target_column:
        ignore_cols = list(set(ignore_cols + [es.target_column]))

    try:
        # Sample if needed
        if len(df) > sample_size:
            df_sample = df.sample(n=sample_size, random_state=random_state)
            sample_indices = df_sample.index.tolist()
        else:
            df_sample = df
            sample_indices = list(range(len(df)))

        # Initialize tracker on first call
        if tracker is None:
            logger.info(f"🔍 Initializing ClusterCohesionTracker with {len(df_sample)} samples")

            # Prepare raw features
            raw_features = prepare_raw_features(df_sample, ignore_cols=ignore_cols)

            # Build missingness mask
            df_for_miss = df_sample.drop(columns=[c for c in ignore_cols if c in df_sample.columns], errors='ignore')
            missingness_mask = df_for_miss.isna().values

            tracker = ClusterCohesionTracker(
                raw_features=raw_features,
                k_values=k_values,
                random_state=random_state,
                missingness_mask=missingness_mask if missingness_mask.any() else None,
                n_neighbors_for_preservation=10,
                output_dir=output_dir,
                sample_indices=sample_indices
            )

            # Store sample DataFrame for consistent encoding
            tracker._df_sample = df_sample

        # Encode samples through ES using batch encoding (much faster than record-by-record)
        # Remove ignored columns from the sample DataFrame before converting to records
        df_for_encoding = tracker._df_sample.drop(
            columns=[c for c in ignore_cols if c in tracker._df_sample.columns],
            errors='ignore'
        )
        records = df_for_encoding.to_dict('records')

        try:
            # Use batch encoding - ~1000x faster than record-by-record
            embeddings_array = es.encode_records_batch(records, batch_size=256, short=False)
            if len(embeddings_array) < 50:
                logger.warning(f"⚠️  Only {len(embeddings_array)} rows encoded, skipping cohesion check")
                return tracker
        except Exception as e:
            logger.warning(f"⚠️  Batch encoding failed: {e}, skipping cohesion check")
            return tracker

        # Ensure we have the right number of embeddings
        if len(embeddings_array) != tracker.n_samples:
            logger.warning(f"⚠️  Embedding count mismatch: {len(embeddings_array)} vs {tracker.n_samples}")
            return tracker

        # Record metrics for this epoch
        epoch_metrics = tracker.record_epoch(epoch_idx, embeddings_array)

        # Log summary
        tracker.log_epoch_summary(epoch_idx, epoch_metrics)

        return tracker

    except Exception as e:
        logger.warning(f"⚠️  Cohesion check failed: {e}")
        return tracker


def compute_cohesion_snapshot(
    es,
    df,
    label: str = "current",
    sample_size: int = 2000,
    k_values: List[int] = None,
    ignore_cols: List[str] = None,
    random_state: int = 42
) -> Optional[Dict]:
    """
    Compute a one-time cohesion snapshot for checkpoint comparison.

    Unlike run_cohesion_check which tracks history across epochs, this function
    computes cohesion metrics for the current model state without maintaining
    history. Useful for comparing best vs final checkpoints.

    Args:
        es: EmbeddingSpace instance (must have encode_record method)
        df: DataFrame with training data
        label: Label for this snapshot (e.g., "best_epoch_64", "final_epoch_150")
        sample_size: Max rows to sample for efficiency
        k_values: K values for clustering (default: [5, 7, 9])
        ignore_cols: Columns to ignore (e.g., target column)
        random_state: Random seed

    Returns:
        Dict with cohesion metrics:
        {
            'label': str,
            'silhouette_raw': float,
            'silhouette_es': float,
            'silhouette_improvement': float,
            'jaccard_mean': float,
            'neighbor_preservation': float,
            'metrics_by_k': {k: {...}, ...}
        }
    """
    if k_values is None:
        k_values = [5, 7, 9]  # Smaller set for quick comparison

    ignore_cols = ignore_cols or []
    if hasattr(es, 'target_column') and es.target_column:
        ignore_cols = list(set(ignore_cols + [es.target_column]))

    try:
        # Sample if needed
        if len(df) > sample_size:
            df_sample = df.sample(n=sample_size, random_state=random_state)
        else:
            df_sample = df

        # Prepare raw features
        raw_features = prepare_raw_features(df_sample, ignore_cols=ignore_cols)

        # Build missingness mask
        df_for_miss = df_sample.drop(columns=[c for c in ignore_cols if c in df_sample.columns], errors='ignore')
        missingness_mask = df_for_miss.isna().values

        # Create temporary tracker
        tracker = ClusterCohesionTracker(
            raw_features=raw_features,
            k_values=k_values,
            random_state=random_state,
            missingness_mask=missingness_mask if missingness_mask.any() else None,
            n_neighbors_for_preservation=10
        )

        # Encode samples through ES using batch encoding (much faster than record-by-record)
        # Remove ignored columns from the sample DataFrame before converting to records
        df_for_encoding = df_sample.drop(
            columns=[c for c in ignore_cols if c in df_sample.columns],
            errors='ignore'
        )
        records = df_for_encoding.to_dict('records')

        try:
            # Use batch encoding - ~1000x faster than record-by-record
            embeddings_array = es.encode_records_batch(records, batch_size=256, short=False)
            if len(embeddings_array) < 50:
                logger.warning(f"⚠️  Only {len(embeddings_array)} rows encoded for snapshot")
                return None
        except Exception as e:
            logger.warning(f"⚠️  Batch encoding failed for snapshot: {e}")
            return None

        # Record metrics (using epoch=0 as placeholder)
        epoch_metrics = tracker.record_epoch(0, embeddings_array)

        if not epoch_metrics:
            return None

        # Aggregate results
        all_sil_raw = []
        all_sil_es = []
        all_sil_improvement = []
        all_jaccard = []
        all_knn = []
        metrics_by_k = {}

        for k, m in epoch_metrics.items():
            all_sil_raw.append(m.raw_silhouette)
            all_sil_es.append(m.es_silhouette)
            all_sil_improvement.append(m.silhouette_improvement)
            all_jaccard.append(m.jaccard_mean)
            if m.neighbor_preservation is not None:
                all_knn.append(m.neighbor_preservation)

            metrics_by_k[k] = {
                'raw_silhouette': m.raw_silhouette,
                'es_silhouette': m.es_silhouette,
                'silhouette_improvement': m.silhouette_improvement,
                'jaccard_mean': m.jaccard_mean,
                'jaccard_std': m.jaccard_std,
                'neighbor_preservation': m.neighbor_preservation
            }

        return {
            'label': label,
            'n_samples': len(embeddings_array),
            'silhouette_raw': float(np.mean(all_sil_raw)),
            'silhouette_es': float(np.mean(all_sil_es)),
            'silhouette_improvement': float(np.mean(all_sil_improvement)),
            'jaccard_mean': float(np.mean(all_jaccard)),
            'neighbor_preservation': float(np.mean(all_knn)) if all_knn else None,
            'metrics_by_k': metrics_by_k
        }

    except Exception as e:
        logger.warning(f"⚠️  Cohesion snapshot failed: {e}")
        import traceback
        logger.debug(traceback.format_exc())
        return None


def compare_checkpoint_cohesion(
    best_snapshot: Dict,
    final_snapshot: Dict
) -> Dict:
    """
    Compare cohesion metrics between two checkpoint snapshots.

    Args:
        best_snapshot: Cohesion snapshot from best checkpoint
        final_snapshot: Cohesion snapshot from final checkpoint

    Returns:
        Dict with comparison results and recommendation
    """
    if best_snapshot is None or final_snapshot is None:
        return {
            'comparison_valid': False,
            'recommendation': 'best',  # Default to best checkpoint if comparison fails
            'reason': 'Could not compute cohesion snapshots for comparison'
        }

    # Extract key metrics
    best_sil = best_snapshot['silhouette_es']
    final_sil = final_snapshot['silhouette_es']
    best_jaccard = best_snapshot['jaccard_mean']
    final_jaccard = final_snapshot['jaccard_mean']
    best_knn = best_snapshot.get('neighbor_preservation')
    final_knn = final_snapshot.get('neighbor_preservation')

    # Compute differences
    sil_diff = final_sil - best_sil  # Positive = final is better
    jaccard_diff = final_jaccard - best_jaccard  # Positive = final is better
    knn_diff = (final_knn - best_knn) if (best_knn and final_knn) else None

    # Score each checkpoint (higher = better)
    # Silhouette improvement matters most for cluster separation
    best_score = 0
    final_score = 0

    # Silhouette (weight: 3)
    if sil_diff > 0.02:
        final_score += 3
    elif sil_diff < -0.02:
        best_score += 3

    # Jaccard (weight: 2)
    if jaccard_diff > 0.02:
        final_score += 2
    elif jaccard_diff < -0.02:
        best_score += 2

    # k-NN preservation (weight: 1)
    if knn_diff is not None:
        if knn_diff > 0.02:
            final_score += 1
        elif knn_diff < -0.02:
            best_score += 1

    # Determine recommendation
    if final_score > best_score:
        recommendation = 'final'
        reason = f"Final epoch has better cluster separation (Sil: {final_sil:.3f} vs {best_sil:.3f})"
    elif best_score > final_score:
        recommendation = 'best'
        reason = f"Best checkpoint has better cluster separation (Sil: {best_sil:.3f} vs {final_sil:.3f})"
    else:
        recommendation = 'best'  # Tie goes to best (lower val loss)
        reason = f"Cluster metrics similar, defaulting to best validation loss checkpoint"

    return {
        'comparison_valid': True,
        'recommendation': recommendation,
        'reason': reason,
        'best_checkpoint': {
            'label': best_snapshot['label'],
            'silhouette_es': best_sil,
            'jaccard_mean': best_jaccard,
            'neighbor_preservation': best_knn
        },
        'final_checkpoint': {
            'label': final_snapshot['label'],
            'silhouette_es': final_sil,
            'jaccard_mean': final_jaccard,
            'neighbor_preservation': final_knn
        },
        'differences': {
            'silhouette_diff': sil_diff,
            'jaccard_diff': jaccard_diff,
            'knn_diff': knn_diff
        },
        'scores': {
            'best_score': best_score,
            'final_score': final_score
        }
    }
