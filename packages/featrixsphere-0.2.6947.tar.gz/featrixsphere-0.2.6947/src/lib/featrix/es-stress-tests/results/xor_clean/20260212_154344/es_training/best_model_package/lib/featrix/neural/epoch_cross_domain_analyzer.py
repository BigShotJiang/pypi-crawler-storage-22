#!/usr/bin/env python3
"""
Cross-Domain Epoch Analyzer

Reads per-epoch output files from multiple components (projections, cohesion)
and computes cross-domain metrics like cluster × movement × consistency.

Each component writes its own epoch files:
  - projections_epoch_NNNN.json  (from InlineMovieWriter)
  - cohesion_epoch_NNNN.json     (from ClusterCohesionTracker)

This analyzer reads both and produces:
  - cross_domain_epoch_NNNN.json (combined analysis)

Usage:
    from featrix.neural.epoch_cross_domain_analyzer import EpochCrossDomainAnalyzer

    analyzer = EpochCrossDomainAnalyzer(output_dir="/path/to/training/output")

    # After each epoch (or at end of training):
    analyzer.analyze_epoch(epoch=5)

    # Or analyze all available epochs:
    analyzer.analyze_all_epochs()
"""

import json
import logging
import numpy as np
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple

from featrix.neural.utils import atomic_write_json

logger = logging.getLogger(__name__)


class EpochCrossDomainAnalyzer:
    """
    Analyzes cross-domain relationships between movement and clustering data.
    """

    def __init__(self, output_dir: str | Path):
        """
        Initialize the cross-domain analyzer.

        Args:
            output_dir: Training output directory containing epoch_projections/
        """
        self.output_dir = Path(output_dir)
        self.projections_dir = self.output_dir / "epoch_projections"

    def _load_projection_data(self, epoch: int) -> Optional[Dict[str, Any]]:
        """Load projection data for an epoch."""
        # Try both naming conventions (with and without leading zeros)
        for pattern in [f"projections_epoch_{epoch:04d}.json", f"projections_epoch_{epoch}.json"]:
            path = self.projections_dir / pattern
            if path.exists():
                with open(path) as f:
                    return json.load(f)
        return None

    def _load_cohesion_data(self, epoch: int) -> Optional[Dict[str, Any]]:
        """Load cohesion data for an epoch."""
        for pattern in [f"cohesion_epoch_{epoch:04d}.json", f"cohesion_epoch_{epoch}.json"]:
            path = self.projections_dir / pattern
            if path.exists():
                with open(path) as f:
                    return json.load(f)
        return None

    def analyze_epoch(self, epoch: int) -> Optional[Dict[str, Any]]:
        """
        Analyze cross-domain metrics for a single epoch.

        Computes:
        - Movement by cluster: How much did points in each cluster move?
        - Cluster stability vs movement: Do stable clusters have less movement?
        - Movement distribution per cluster

        Args:
            epoch: Epoch number to analyze

        Returns:
            Cross-domain analysis dict, or None if data not available
        """
        projection_data = self._load_projection_data(epoch)
        cohesion_data = self._load_cohesion_data(epoch)

        if projection_data is None:
            logger.debug(f"No projection data for epoch {epoch}")
            return None

        # Extract per-point movement data
        coords = projection_data.get("coords", [])
        if not coords:
            return None

        # Build arrays of movement metrics indexed by sample
        n_samples = len(coords)
        epoch_distances = np.zeros(n_samples)
        cumulative_distances = np.zeros(n_samples)

        for i, coord in enumerate(coords):
            scalars = coord.get("scalar_columns", {})
            # Handle both old and new column names
            epoch_distances[i] = scalars.get("__featrix_epoch_distance", scalars.get("epoch_distance", 0))
            cumulative_distances[i] = scalars.get("__featrix_cumulative_distance", scalars.get("cumulative_distance", 0))

        # Start building cross-domain analysis
        cross_domain = {
            "epoch": epoch,
            "n_samples": n_samples,
            "movement_summary": {
                "epoch_distance": self._compute_distribution_stats(epoch_distances),
                "cumulative_distance": self._compute_distribution_stats(cumulative_distances),
            },
        }

        # If we have cohesion data, compute cluster × movement analysis
        if cohesion_data is not None:
            cross_domain["cluster_movement_analysis"] = self._analyze_cluster_movement(
                epoch_distances=epoch_distances,
                cumulative_distances=cumulative_distances,
                cohesion_data=cohesion_data,
            )

        # Write the cross-domain analysis
        output_file = self.projections_dir / f"cross_domain_epoch_{epoch:04d}.json"
        atomic_write_json(output_file, cross_domain, indent=2)

        logger.info(f"📊 Cross-domain analysis for epoch {epoch} written to {output_file.name}")
        return cross_domain

    def _analyze_cluster_movement(
        self,
        epoch_distances: np.ndarray,
        cumulative_distances: np.ndarray,
        cohesion_data: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Analyze movement patterns within each cluster.

        Returns analysis for each K value in the cohesion data.
        """
        metrics_by_k = cohesion_data.get("metrics_by_k", {})
        analysis_by_k = {}

        for k_str, metrics in metrics_by_k.items():
            k = int(k_str)
            cluster_labels = metrics.get("cluster_labels")

            if cluster_labels is None:
                continue

            cluster_labels = np.array(cluster_labels)

            # Per-cluster movement analysis
            per_cluster = []
            for cluster_id in range(k):
                mask = cluster_labels == cluster_id
                cluster_size = mask.sum()

                if cluster_size == 0:
                    continue

                cluster_epoch_dist = epoch_distances[mask]
                cluster_cum_dist = cumulative_distances[mask]

                per_cluster.append({
                    "cluster_id": cluster_id,
                    "size": int(cluster_size),
                    "epoch_distance": self._compute_distribution_stats(cluster_epoch_dist),
                    "cumulative_distance": self._compute_distribution_stats(cluster_cum_dist),
                })

            # Compute correlation between cluster metrics and movement
            jaccard_per_cluster = metrics.get("jaccard_per_cluster", [])

            # For correlation: get mean movement per cluster
            cluster_mean_epoch_dist = [c["epoch_distance"]["mean"] for c in per_cluster]
            cluster_mean_cum_dist = [c["cumulative_distance"]["mean"] for c in per_cluster]

            correlations = {}
            if len(jaccard_per_cluster) == len(cluster_mean_epoch_dist) and len(jaccard_per_cluster) > 2:
                # Correlation between cluster stability (Jaccard) and movement
                correlations["jaccard_vs_epoch_distance"] = float(
                    np.corrcoef(jaccard_per_cluster, cluster_mean_epoch_dist)[0, 1]
                ) if not np.isnan(np.corrcoef(jaccard_per_cluster, cluster_mean_epoch_dist)[0, 1]) else None

                correlations["jaccard_vs_cumulative_distance"] = float(
                    np.corrcoef(jaccard_per_cluster, cluster_mean_cum_dist)[0, 1]
                ) if not np.isnan(np.corrcoef(jaccard_per_cluster, cluster_mean_cum_dist)[0, 1]) else None

            analysis_by_k[k] = {
                "per_cluster": per_cluster,
                "correlations": correlations,
                "cohesion_metrics": {
                    "jaccard_mean": metrics.get("jaccard_mean"),
                    "jaccard_std": metrics.get("jaccard_std"),
                    "es_silhouette": metrics.get("es_silhouette"),
                    "silhouette_improvement": metrics.get("silhouette_improvement"),
                    "neighbor_preservation": metrics.get("neighbor_preservation"),
                },
            }

        return analysis_by_k

    def _compute_distribution_stats(self, arr: np.ndarray) -> Dict[str, Any]:
        """Compute distribution statistics for an array."""
        if len(arr) == 0:
            return {"mean": 0, "std": 0, "min": 0, "max": 0, "median": 0, "percentiles": {}}

        percentiles = [0, 10, 25, 50, 75, 90, 100]
        pct_values = np.percentile(arr, percentiles)

        return {
            "mean": float(np.mean(arr)),
            "std": float(np.std(arr)),
            "min": float(np.min(arr)),
            "max": float(np.max(arr)),
            "median": float(np.median(arr)),
            "percentiles": {str(p): float(v) for p, v in zip(percentiles, pct_values)},
        }

    def analyze_all_epochs(self) -> List[Dict[str, Any]]:
        """
        Analyze all available epochs.

        Returns:
            List of cross-domain analysis dicts for each epoch
        """
        if not self.projections_dir.exists():
            logger.warning(f"Projections directory does not exist: {self.projections_dir}")
            return []

        # Find all projection files to get epoch numbers
        projection_files = sorted(self.projections_dir.glob("projections_epoch_*.json"))

        results = []
        for pf in projection_files:
            # Extract epoch number from filename
            try:
                epoch_str = pf.stem.replace("projections_epoch_", "")
                epoch = int(epoch_str)
                result = self.analyze_epoch(epoch)
                if result:
                    results.append(result)
            except (ValueError, Exception) as e:
                logger.warning(f"Failed to analyze {pf.name}: {e}")

        logger.info(f"📊 Analyzed {len(results)} epochs for cross-domain metrics")
        return results

    def get_movement_by_cluster_timeline(self, k: int) -> Dict[str, Any]:
        """
        Get movement-by-cluster data across all epochs for a specific K.

        Useful for visualizing how cluster movement patterns evolve over training.

        Args:
            k: Number of clusters to analyze

        Returns:
            Timeline data structure for visualization
        """
        cross_domain_files = sorted(self.projections_dir.glob("cross_domain_epoch_*.json"))

        timeline = {
            "k": k,
            "epochs": [],
            "per_cluster_timelines": {},  # cluster_id -> list of metrics per epoch
        }

        for cf in cross_domain_files:
            try:
                with open(cf) as f:
                    data = json.load(f)

                epoch = data["epoch"]
                cluster_analysis = data.get("cluster_movement_analysis", {}).get(str(k))

                if cluster_analysis is None:
                    continue

                timeline["epochs"].append(epoch)

                for cluster_data in cluster_analysis.get("per_cluster", []):
                    cluster_id = cluster_data["cluster_id"]
                    if cluster_id not in timeline["per_cluster_timelines"]:
                        timeline["per_cluster_timelines"][cluster_id] = []

                    timeline["per_cluster_timelines"][cluster_id].append({
                        "epoch": epoch,
                        "size": cluster_data["size"],
                        "mean_epoch_distance": cluster_data["epoch_distance"]["mean"],
                        "mean_cumulative_distance": cluster_data["cumulative_distance"]["mean"],
                    })

            except Exception as e:
                logger.warning(f"Failed to load {cf.name}: {e}")

        return timeline
