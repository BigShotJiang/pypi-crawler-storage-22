"""
ES Training Visualization Module

Orchestrates generation of spatial/relational visualizations during ES training.
Each visualization saves both PNG (for viewing/monitoring) and JSON (for animation).

Visualizations generated per epoch:
1. Column Embedding PCA - 2D scatter of column embeddings
2. Lift Heatmap - Pairwise lift values between columns
3. Embedding Similarity - Cosine similarity between column embeddings
4. Column Loss Landscape - Bar chart of per-column prediction difficulty
5. Relationship Graph - Network of top relationships
6. Gradient Flow - Where learning is happening
7. Attention Flow - Which columns attend to which (if available)
8. Prediction Confidence - Confidence distribution per column
9. Cluster Cohesion - Sample embedding space colored by class (if labels available)
10. Lift Waves - Sparkline showing relationship evolution

Output structure:
    <output_dir>/
    ├── media/
    │   ├── column_embedding_pca/
    │   │   ├── column_embedding_pca_epoch_0000.png
    │   │   ├── column_embedding_pca_epoch_0000.json
    │   │   └── ...
    │   ├── lift_heatmap/
    │   ├── embedding_similarity/
    │   ├── column_loss_landscape/
    │   ├── relationship_graph/
    │   ├── gradient_flow/
    │   ├── attention_flow/
    │   ├── prediction_confidence/
    │   ├── cluster_cohesion/
    │   ├── column_embedding_pca.png      # Latest frames
    │   ├── lift_heatmap.png
    │   ├── embedding_similarity.png
    │   ├── column_loss_landscape.png
    │   ├── relationship_graph.png
    │   ├── gradient_flow.png
    │   ├── attention_flow.png
    │   ├── prediction_confidence.png
    │   ├── cluster_cohesion.png
    │   └── lift_waves.png
    └── lift_viz/
        ├── lift_data_epoch0000.json
        ├── lift_waves_epoch0000.json
        └── ...
"""

import logging
import os
from typing import Dict, List, Optional, Tuple, Any, TYPE_CHECKING

if TYPE_CHECKING:
    import numpy as np
    import torch

logger = logging.getLogger(__name__)


class ESTrainingVisualizer:
    """
    Orchestrates visualization generation during ES training.

    Call save_epoch_visualizations() at the end of each epoch to generate
    all available visualizations.
    """

    def __init__(self, output_dir: str, col_names: List[str]):
        """
        Initialize the visualizer.

        Args:
            output_dir: Directory to save visualizations
            col_names: List of column names in order
        """
        self.output_dir = output_dir
        self.col_names = col_names
        self.n_cols = len(col_names)

        # Create output directory
        os.makedirs(output_dir, exist_ok=True)

        # Track what data we have available
        self._has_embeddings = False
        self._has_losses = False
        self._has_pairs = False
        self._has_gradients = False
        self._has_attention = False
        self._has_confidence = False
        self._has_samples = False

    def save_epoch_visualizations(
        self,
        epoch: int,
        # Column embeddings
        col_embeddings: Optional["torch.Tensor"] = None,  # (n_cols, d_model)
        col_types: Optional[Dict[str, str]] = None,
        # Loss data
        col_losses: Optional[Dict[str, float]] = None,
        # Relationship data
        pair_importance: Optional[Dict[Tuple[int, int], float]] = None,
        lift_matrix: Optional["np.ndarray"] = None,
        # Gradient data
        gradient_norms: Optional[Dict[str, float]] = None,
        # Attention data (if available)
        attention_weights: Optional["np.ndarray"] = None,
        # Confidence data
        confidence_stats: Optional[Dict[str, Dict[str, float]]] = None,
        # Sample embeddings for cluster cohesion (optional, expensive)
        sample_embeddings_2d: Optional["np.ndarray"] = None,
        sample_labels: Optional[List] = None,
        silhouette_score: Optional[float] = None,
        # Lift wave data
        lift_wave_data: Optional[Dict] = None,
    ) -> Dict[str, Optional[str]]:
        """
        Generate all available visualizations for this epoch.

        Args:
            epoch: Current epoch number
            col_embeddings: Mean column embeddings (n_cols, d_model)
            col_types: Dict mapping column names to type strings
            col_losses: Dict mapping column names to marginal losses
            pair_importance: Dict mapping (i, j) pairs to importance scores
            lift_matrix: (n_cols, n_cols) matrix of lift values
            gradient_norms: Dict of gradient norms per operation/column
            attention_weights: (n_cols, n_cols) attention matrix
            confidence_stats: {col_name: {mean, std, min, max}} confidence stats
            sample_embeddings_2d: (n_samples, 2) PCA of sample embeddings
            sample_labels: Class labels for samples
            silhouette_score: Silhouette score for cluster quality
            lift_wave_data: Pre-computed lift wave data dict

        Returns:
            Dict mapping visualization name to output path (or None if failed/skipped)
        """
        results = {}

        # Import charting functions
        try:
            from featrix.neural.charting import (
                plot_column_embedding_pca,
                plot_lift_heatmap_frame,
                plot_embedding_similarity_heatmap,
                plot_column_loss_landscape,
                plot_relationship_graph,
                plot_gradient_flow_heatmap,
                plot_attention_flow,
                plot_prediction_confidence_heatmap,
                plot_cluster_cohesion_map,
            )
        except ImportError as e:
            logger.warning(f"Could not import charting functions: {e}")
            return results

        # 1. Column Embedding PCA
        if col_embeddings is not None:
            try:
                path = plot_column_embedding_pca(
                    col_embeddings=col_embeddings,
                    col_names=self.col_names,
                    output_dir=self.output_dir,
                    epoch=epoch,
                    col_types=col_types,
                    col_losses=col_losses,
                )
                results['column_embedding_pca'] = path
            except Exception as e:
                logger.debug(f"Failed to generate column embedding PCA: {e}")
                results['column_embedding_pca'] = None

        # 2. Lift Heatmap
        if lift_matrix is not None:
            try:
                path = plot_lift_heatmap_frame(
                    lift_matrix=lift_matrix,
                    col_names=self.col_names,
                    output_dir=self.output_dir,
                    epoch=epoch,
                )
                results['lift_heatmap'] = path
            except Exception as e:
                logger.debug(f"Failed to generate lift heatmap: {e}")
                results['lift_heatmap'] = None

        # 3. Embedding Similarity
        if col_embeddings is not None:
            try:
                path = plot_embedding_similarity_heatmap(
                    col_embeddings=col_embeddings,
                    col_names=self.col_names,
                    output_dir=self.output_dir,
                    epoch=epoch,
                )
                results['embedding_similarity'] = path
            except Exception as e:
                logger.debug(f"Failed to generate embedding similarity: {e}")
                results['embedding_similarity'] = None

        # 4. Column Loss Landscape
        if col_losses:
            try:
                # Get top pairs for overlay
                top_pairs = None
                if pair_importance:
                    sorted_pairs = sorted(pair_importance.items(), key=lambda x: x[1], reverse=True)[:10]
                    top_pairs = [
                        (self.col_names[i] if i < self.n_cols else f"col_{i}",
                         self.col_names[j] if j < self.n_cols else f"col_{j}",
                         float(imp))
                        for (i, j), imp in sorted_pairs
                    ]

                path = plot_column_loss_landscape(
                    col_names=self.col_names,
                    col_losses=col_losses,
                    output_dir=self.output_dir,
                    epoch=epoch,
                    top_pairs=top_pairs,
                )
                results['column_loss_landscape'] = path
            except Exception as e:
                logger.debug(f"Failed to generate column loss landscape: {e}")
                results['column_loss_landscape'] = None

        # 5. Relationship Graph
        if pair_importance:
            try:
                path = plot_relationship_graph(
                    col_names=self.col_names,
                    pair_importance=pair_importance,
                    output_dir=self.output_dir,
                    epoch=epoch,
                    top_k=30,
                    col_losses=col_losses,
                )
                results['relationship_graph'] = path
            except Exception as e:
                logger.debug(f"Failed to generate relationship graph: {e}")
                results['relationship_graph'] = None

        # 6. Gradient Flow
        if gradient_norms:
            try:
                path = plot_gradient_flow_heatmap(
                    col_names=self.col_names,
                    gradient_norms=gradient_norms,
                    output_dir=self.output_dir,
                    epoch=epoch,
                )
                results['gradient_flow'] = path
            except Exception as e:
                logger.debug(f"Failed to generate gradient flow: {e}")
                results['gradient_flow'] = None

        # 7. Attention Flow
        if attention_weights is not None:
            try:
                path = plot_attention_flow(
                    col_names=self.col_names,
                    attention_weights=attention_weights,
                    output_dir=self.output_dir,
                    epoch=epoch,
                )
                results['attention_flow'] = path
            except Exception as e:
                logger.debug(f"Failed to generate attention flow: {e}")
                results['attention_flow'] = None

        # 8. Prediction Confidence
        if confidence_stats:
            try:
                path = plot_prediction_confidence_heatmap(
                    col_names=self.col_names,
                    confidence_stats=confidence_stats,
                    output_dir=self.output_dir,
                    epoch=epoch,
                )
                results['prediction_confidence'] = path
            except Exception as e:
                logger.debug(f"Failed to generate prediction confidence: {e}")
                results['prediction_confidence'] = None

        # 9. Cluster Cohesion
        if sample_embeddings_2d is not None and sample_labels is not None:
            try:
                path = plot_cluster_cohesion_map(
                    embeddings_2d=sample_embeddings_2d,
                    labels=sample_labels,
                    output_dir=self.output_dir,
                    epoch=epoch,
                    silhouette_score=silhouette_score,
                )
                results['cluster_cohesion'] = path
            except Exception as e:
                logger.debug(f"Failed to generate cluster cohesion: {e}")
                results['cluster_cohesion'] = None

        # 10. Lift Waves (handled separately - needs full history)
        # This is generated by save_lift_wave_data in the relationship extractor

        # Log summary
        generated = [k for k, v in results.items() if v is not None]
        if generated:
            logger.info(f"📊 Generated {len(generated)} visualizations for epoch {epoch}")

        return results


def create_visualizer_for_relationship_extractor(
    relationship_extractor,
    output_dir: str,
) -> ESTrainingVisualizer:
    """
    Create a visualizer configured for a relationship extractor.

    Args:
        relationship_extractor: DynamicRelationshipExtractor instance
        output_dir: Output directory

    Returns:
        Configured ESTrainingVisualizer
    """
    return ESTrainingVisualizer(
        output_dir=output_dir,
        col_names=list(relationship_extractor.col_names),
    )


def save_all_visualizations_from_extractor(
    relationship_extractor,
    output_dir: str,
    epoch: int,
    gradient_norms: Optional[Dict[str, float]] = None,
    attention_weights: Optional["np.ndarray"] = None,
    confidence_stats: Optional[Dict[str, Dict[str, float]]] = None,
    sample_embeddings_2d: Optional["np.ndarray"] = None,
    sample_labels: Optional[List] = None,
    silhouette_score: Optional[float] = None,
) -> Dict[str, Optional[str]]:
    """
    Convenience function to generate all visualizations from a relationship extractor.

    Extracts available data from the extractor and generates all visualizations.

    Args:
        relationship_extractor: DynamicRelationshipExtractor instance
        output_dir: Output directory
        epoch: Current epoch
        gradient_norms: Optional gradient norms (if not extractable from extractor)
        attention_weights: Optional attention weights
        confidence_stats: Optional confidence statistics
        sample_embeddings_2d: Optional sample embeddings for cluster cohesion
        sample_labels: Optional sample labels
        silhouette_score: Optional silhouette score

    Returns:
        Dict mapping visualization name to output path
    """
    import numpy as np

    re = relationship_extractor
    col_names = list(re.col_names)

    # Create visualizer
    viz = ESTrainingVisualizer(output_dir=output_dir, col_names=col_names)

    # Extract available data from relationship extractor
    col_embeddings = re.get_col_mean_embeddings() if hasattr(re, 'get_col_mean_embeddings') else None
    col_losses = re.col_marginal_losses if hasattr(re, 'col_marginal_losses') else None

    # Get lift matrix
    lift_matrix = None
    if hasattr(re, 'get_lift_matrix'):
        try:
            lift_matrix, _ = re.get_lift_matrix()
        except Exception:
            pass

    # Get pair importance
    pair_importance = None
    if hasattr(re, 'causal_scorer') and hasattr(re, 'all_pairs'):
        pair_importance = {}
        for pair in re.all_pairs:
            try:
                importance, _ = re.causal_scorer.compute_importance(pair)
                pair_importance[pair] = importance
            except Exception:
                pass

    # Get gradient norms from extractor if not provided
    if gradient_norms is None and hasattr(re, '_compute_weight_stats'):
        try:
            weight_stats = re._compute_weight_stats()
            gradient_norms = {op: stats.get('grad_norm', 0.0) for op, stats in weight_stats.items()}
        except Exception:
            pass

    # Get column types if available
    col_types = None
    if hasattr(re, 'col_types'):
        col_types = re.col_types

    # Generate all visualizations
    results = viz.save_epoch_visualizations(
        epoch=epoch,
        col_embeddings=col_embeddings,
        col_types=col_types,
        col_losses=col_losses,
        pair_importance=pair_importance,
        lift_matrix=lift_matrix,
        gradient_norms=gradient_norms,
        attention_weights=attention_weights,
        confidence_stats=confidence_stats,
        sample_embeddings_2d=sample_embeddings_2d,
        sample_labels=sample_labels,
        silhouette_score=silhouette_score,
    )

    return results
