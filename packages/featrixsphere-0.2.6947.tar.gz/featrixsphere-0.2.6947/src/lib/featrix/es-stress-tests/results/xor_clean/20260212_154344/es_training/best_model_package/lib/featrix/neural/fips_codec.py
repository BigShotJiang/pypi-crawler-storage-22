#  -*- coding: utf-8 -*-
#
#  Copyright Featrix, Inc 2023-2026
#
#  Proprietary and Confidential.  Unauthorized use, copying or dissemination
#  of these materials is strictly prohibited.
"""
FIPS Code Codec and Encoder

Encodes US FIPS codes (Federal Information Processing Standards) which identify:
- States (2-digit FIPS)
- Counties (5-digit FIPS: 2-digit state + 3-digit county)

Key insight: Counties that are geographically close should have similar embeddings.
This enables learning relationships like:
- Customer county demographics
- Regional patterns
- Cross-county relationships

FIPS codes:
- State FIPS: 01-56 (01=AL, 02=AK, 04=AZ, 05=AR, 06=CA, ...)
- County FIPS: SSCCC (SS=state, CCC=county)
  E.g., 06001 = Alameda County, CA
        06075 = San Francisco County, CA
        36061 = New York County (Manhattan), NY

Token value is a tensor of floats representing:
- fips_lat (1): normalized latitude of county centroid
- fips_long (1): normalized longitude of county centroid
- state_idx (1): state FIPS code normalized
- state_region_embedding (16): embedding for census region
- county_embedding (16): hash-based embedding for county
Total: 35 floats
"""
import logging
import math
import re
import torch
import torch.nn as nn
import torch.nn.functional as F

from typing import Dict, List, Optional, Tuple

from featrix.neural.gpu_utils import get_device
from featrix.neural.featrix_token import Token, TokenStatus
from featrix.neural.model_config import ColumnType, SimpleMLPConfig
from featrix.neural.simple_mlp import SimpleMLP
from featrix.neural.geo_spread import GEO_SPREAD_ENABLED, GEO_SPREAD_DIM, compute_geo_spread, empty_geo_spread_tensor

# Import the full FIPS county dataset (3233 counties)
from featrix.neural.data_fips import COUNTY_FIPS_COORDS

logger = logging.getLogger(__name__)

# FIPS token dimensions
FIPS_STATE_REGION_EMB_DIM = 16
FIPS_COUNTY_EMB_DIM = 16
FIPS_TOKEN_DIM = 1 + 1 + 1 + FIPS_STATE_REGION_EMB_DIM + FIPS_COUNTY_EMB_DIM  # = 35

# Normalization constants for lat/long (US bounds)
LAT_MIN, LAT_MAX = 18.0, 72.0
LONG_MIN, LONG_MAX = -180.0, -65.0


def normalize_lat(lat: float) -> float:
    """Normalize latitude to [0, 1] range."""
    return (lat - LAT_MIN) / (LAT_MAX - LAT_MIN)


def normalize_long(lon: float) -> float:
    """Normalize longitude to [0, 1] range."""
    return (lon - LONG_MIN) / (LONG_MAX - LONG_MIN)


# State FIPS codes
STATE_FIPS = {
    '01': ('AL', 'Alabama'), '02': ('AK', 'Alaska'), '04': ('AZ', 'Arizona'),
    '05': ('AR', 'Arkansas'), '06': ('CA', 'California'), '08': ('CO', 'Colorado'),
    '09': ('CT', 'Connecticut'), '10': ('DE', 'Delaware'), '11': ('DC', 'District of Columbia'),
    '12': ('FL', 'Florida'), '13': ('GA', 'Georgia'), '15': ('HI', 'Hawaii'),
    '16': ('ID', 'Idaho'), '17': ('IL', 'Illinois'), '18': ('IN', 'Indiana'),
    '19': ('IA', 'Iowa'), '20': ('KS', 'Kansas'), '21': ('KY', 'Kentucky'),
    '22': ('LA', 'Louisiana'), '23': ('ME', 'Maine'), '24': ('MD', 'Maryland'),
    '25': ('MA', 'Massachusetts'), '26': ('MI', 'Michigan'), '27': ('MN', 'Minnesota'),
    '28': ('MS', 'Mississippi'), '29': ('MO', 'Missouri'), '30': ('MT', 'Montana'),
    '31': ('NE', 'Nebraska'), '32': ('NV', 'Nevada'), '33': ('NH', 'New Hampshire'),
    '34': ('NJ', 'New Jersey'), '35': ('NM', 'New Mexico'), '36': ('NY', 'New York'),
    '37': ('NC', 'North Carolina'), '38': ('ND', 'North Dakota'), '39': ('OH', 'Ohio'),
    '40': ('OK', 'Oklahoma'), '41': ('OR', 'Oregon'), '42': ('PA', 'Pennsylvania'),
    '44': ('RI', 'Rhode Island'), '45': ('SC', 'South Carolina'), '46': ('SD', 'South Dakota'),
    '47': ('TN', 'Tennessee'), '48': ('TX', 'Texas'), '49': ('UT', 'Utah'),
    '50': ('VT', 'Vermont'), '51': ('VA', 'Virginia'), '53': ('WA', 'Washington'),
    '54': ('WV', 'West Virginia'), '55': ('WI', 'Wisconsin'), '56': ('WY', 'Wyoming'),
    '72': ('PR', 'Puerto Rico'), '78': ('VI', 'Virgin Islands'),
}

# Census regions for state grouping
# https://www2.census.gov/geo/pdfs/maps-data/maps/reference/us_regdiv.pdf
STATE_TO_REGION = {
    # Region 1: Northeast
    'CT': 1, 'ME': 1, 'MA': 1, 'NH': 1, 'RI': 1, 'VT': 1,  # New England
    'NJ': 1, 'NY': 1, 'PA': 1,  # Middle Atlantic
    # Region 2: Midwest
    'IL': 2, 'IN': 2, 'MI': 2, 'OH': 2, 'WI': 2,  # East North Central
    'IA': 2, 'KS': 2, 'MN': 2, 'MO': 2, 'NE': 2, 'ND': 2, 'SD': 2,  # West North Central
    # Region 3: South
    'DE': 3, 'FL': 3, 'GA': 3, 'MD': 3, 'NC': 3, 'SC': 3, 'VA': 3, 'DC': 3, 'WV': 3,  # South Atlantic
    'AL': 3, 'KY': 3, 'MS': 3, 'TN': 3,  # East South Central
    'AR': 3, 'LA': 3, 'OK': 3, 'TX': 3,  # West South Central
    # Region 4: West
    'AZ': 4, 'CO': 4, 'ID': 4, 'MT': 4, 'NV': 4, 'NM': 4, 'UT': 4, 'WY': 4,  # Mountain
    'AK': 4, 'CA': 4, 'HI': 4, 'OR': 4, 'WA': 4,  # Pacific
    # Territories
    'PR': 5, 'VI': 5,
}


def parse_fips_code(fips_str: str) -> Dict:
    """
    Parse a FIPS code string into components.

    Returns:
        Dict with keys:
        - fips: str (full FIPS code)
        - state_fips: str (2-digit state code)
        - county_fips: str (3-digit county code, if present)
        - state_abbrev: str (state abbreviation)
        - is_valid: bool
    """
    if fips_str is None:
        return {'is_valid': False, 'fips': '', 'state_fips': '', 'county_fips': '', 'state_abbrev': ''}

    fips_str = str(fips_str).strip()

    # Remove any non-digit characters
    digits = re.sub(r'[^\d]', '', fips_str)

    result = {
        'is_valid': False,
        'fips': '',
        'state_fips': '',
        'county_fips': '',
        'state_abbrev': '',
    }

    if len(digits) == 2:
        # State FIPS only
        if digits in STATE_FIPS:
            result['fips'] = digits
            result['state_fips'] = digits
            result['state_abbrev'] = STATE_FIPS[digits][0]
            result['is_valid'] = True
    elif len(digits) == 5:
        # Full county FIPS
        state_fips = digits[:2]
        county_fips = digits[2:]
        if state_fips in STATE_FIPS:
            result['fips'] = digits
            result['state_fips'] = state_fips
            result['county_fips'] = county_fips
            result['state_abbrev'] = STATE_FIPS[state_fips][0]
            result['is_valid'] = True
    elif len(digits) == 4:
        # Might be missing leading zero (e.g., 6001 for Alameda, CA)
        digits = '0' + digits
        state_fips = digits[:2]
        county_fips = digits[2:]
        if state_fips in STATE_FIPS:
            result['fips'] = digits
            result['state_fips'] = state_fips
            result['county_fips'] = county_fips
            result['state_abbrev'] = STATE_FIPS[state_fips][0]
            result['is_valid'] = True

    return result


class FipsCodec:
    """
    Codec for FIPS codes.

    Tokenizes FIPS codes into a tensor containing:
    - Geographic features (lat/long of county centroid)
    - State/region information
    - County embedding
    """

    def __init__(self, df_col, embed_dim: int = 768, string_cache=None, detector=None):
        self.embed_dim = embed_dim
        self.enc_dim = FIPS_TOKEN_DIM  # Token dimension for encoder config
        self.string_cache = string_cache
        self.detector = detector
        self.column_type = ColumnType.FIPS_CODE

        # Build county vocabulary from data + known counties
        self._build_county_vocab(df_col)

        # Create NOT_PRESENT and UNKNOWN tokens
        self._not_present_token = self._create_special_token(TokenStatus.NOT_PRESENT)
        self._unknown_token = self._create_special_token(TokenStatus.UNKNOWN)

        logger.info(f"FipsCodec initialized with {len(self.county_to_idx)} counties")

    def _build_county_vocab(self, df_col):
        """Build vocabulary of county FIPS codes from data and known counties."""
        self.county_to_idx = {}
        self.idx_to_county = {}

        # Start with known counties from the full dataset
        for fips in COUNTY_FIPS_COORDS.keys():
            idx = len(self.county_to_idx)
            self.county_to_idx[fips] = idx
            self.idx_to_county[idx] = fips

        # Add FIPS codes from data that we don't know
        for val in df_col.dropna().unique():
            parsed = parse_fips_code(val)
            if parsed['is_valid'] and len(parsed['fips']) == 5:
                fips = parsed['fips']
                if fips not in self.county_to_idx:
                    idx = len(self.county_to_idx)
                    self.county_to_idx[fips] = idx
                    self.idx_to_county[idx] = fips

        # Add UNKNOWN
        self.unknown_county_idx = len(self.county_to_idx)
        self.county_to_idx['UNKNOWN'] = self.unknown_county_idx
        self.idx_to_county[self.unknown_county_idx] = 'UNKNOWN'

    def _create_special_token(self, status: TokenStatus) -> Token:
        """Create a special token (NOT_PRESENT or UNKNOWN)."""
        value = torch.zeros(FIPS_TOKEN_DIM)
        return Token(value=value, status=status)

    def get_not_present_token(self) -> Token:
        return self._not_present_token

    def get_unknown_token(self) -> Token:
        return self._unknown_token

    def get_codec_name(self):
        return ColumnType.FIPS_CODE

    def get_geo_point(self, fips_value) -> Optional[Tuple[float, float]]:
        """
        Get geographic coordinates for a FIPS code.

        Args:
            fips_value: FIPS code string

        Returns:
            (latitude, longitude) tuple, or None if unknown
        """
        if fips_value is None:
            return None

        parsed = parse_fips_code(fips_value)
        if not parsed['is_valid']:
            return None

        fips = parsed['fips']
        if fips and fips in COUNTY_FIPS_COORDS:
            lat, lon, county_name, state = COUNTY_FIPS_COORDS[fips]
            return (lat, lon)

        return None

    def get_state_fips(self, fips_value) -> Optional[str]:
        """
        Get the 2-digit state FIPS from a FIPS code.

        Args:
            fips_value: FIPS code string

        Returns:
            2-digit state FIPS string, or None if invalid
        """
        if fips_value is None:
            return None

        parsed = parse_fips_code(fips_value)
        if not parsed['is_valid']:
            return None

        return parsed['state_fips']

    def get_geo_spread_features(self, fips_value) -> torch.Tensor:
        """
        Get geo spread features for a single FIPS code.

        For single values, this returns features for one location.
        Returns zero tensor if geo spread is disabled.
        """
        if not GEO_SPREAD_ENABLED:
            return empty_geo_spread_tensor()

        geo_point = self.get_geo_point(fips_value)
        if geo_point is None:
            return empty_geo_spread_tensor()

        lat, lon = geo_point
        state_fips = self.get_state_fips(fips_value)
        state_fips_list = [state_fips] if state_fips else None

        features = compute_geo_spread([(lat, lon, 1.0)], state_fips_list)
        return features.to_tensor()

    def tokenize(self, fips_value) -> Token:
        """
        Convert a FIPS code string to a Token.
        """
        if fips_value is None or (isinstance(fips_value, float) and math.isnan(fips_value)):
            return self._not_present_token

        if isinstance(fips_value, str) and fips_value.strip() == '':
            return self._not_present_token

        parsed = parse_fips_code(fips_value)

        if not parsed['is_valid']:
            return self._unknown_token

        # Build feature tensor
        features = []

        fips = parsed['fips']

        # 1. FIPS lat/long (2 floats)
        if fips in COUNTY_FIPS_COORDS:
            lat, lon, county_name, state = COUNTY_FIPS_COORDS[fips]
            features.append(normalize_lat(lat))
            features.append(normalize_long(lon))
        else:
            # Unknown county - use center of continental US
            features.append(normalize_lat(39.8283))
            features.append(normalize_long(-98.5795))

        # 2. State index normalized (1 float)
        state_fips_int = int(parsed['state_fips']) if parsed['state_fips'] else 0
        state_norm = state_fips_int / 56.0  # Max state FIPS is 56 (Wyoming)
        features.append(state_norm)

        # 3. State/region embedding (16 floats)
        state_emb = torch.zeros(FIPS_STATE_REGION_EMB_DIM)
        state_abbrev = parsed['state_abbrev']
        if state_abbrev and state_abbrev in STATE_TO_REGION:
            region_idx = STATE_TO_REGION[state_abbrev]
            state_emb[region_idx] = 1.0
            # Also encode state more specifically
            state_emb[(state_fips_int % 12) + 4] = 0.5
        features.extend(state_emb.tolist())

        # 4. County embedding (16 floats)
        county_idx = self.county_to_idx.get(fips, self.unknown_county_idx)
        county_emb = torch.zeros(FIPS_COUNTY_EMB_DIM)
        county_emb[county_idx % FIPS_COUNTY_EMB_DIM] = 1.0
        if county_idx >= FIPS_COUNTY_EMB_DIM:
            county_emb[(county_idx // FIPS_COUNTY_EMB_DIM) % FIPS_COUNTY_EMB_DIM] = 0.5
        features.extend(county_emb.tolist())

        value = torch.tensor(features, dtype=torch.float32)
        assert value.shape[0] == FIPS_TOKEN_DIM, f"Expected {FIPS_TOKEN_DIM} features, got {value.shape[0]}"

        return Token(value=value, status=TokenStatus.OK)


class FipsEncoder(nn.Module):
    """
    Encodes FIPS code features using an MLP.

    Input: TokenBatch with tensor values of shape [batch, 35]
    Output: (short_vec, full_vec) embeddings
    """

    def __init__(self, config: SimpleMLPConfig, string_cache=None, column_name: Optional[str] = None):
        super().__init__()
        self.config = config
        self.string_cache = string_cache
        self.column_name = column_name
        self.d_model = config.d_out

        # Project lat/long (2 -> 32)
        self.geo_proj = nn.Linear(2, 32, bias=False)
        nn.init.xavier_uniform_(self.geo_proj.weight, gain=1.0)

        # Project state idx (1 -> 16)
        self.state_idx_proj = nn.Linear(1, 16, bias=False)
        nn.init.xavier_uniform_(self.state_idx_proj.weight, gain=0.5)

        # Project state region embedding (16 -> 32)
        self.state_region_proj = nn.Linear(FIPS_STATE_REGION_EMB_DIM, 32, bias=False)
        nn.init.xavier_uniform_(self.state_region_proj.weight, gain=1.0)

        # Project county embedding (16 -> 32)
        self.county_proj = nn.Linear(FIPS_COUNTY_EMB_DIM, 32, bias=False)
        nn.init.xavier_uniform_(self.county_proj.weight, gain=0.5)

        # Total input dimension to MLP:
        # geo(32) + state_idx(16) + state_region(32) + county(32) = 112
        mlp_input_dim = 32 + 16 + 32 + 32

        # Final combination MLP
        from featrix.neural.simple_mlp import SimpleMLP
        self.combine_mlp = SimpleMLP(
            SimpleMLPConfig(
                d_in=mlp_input_dim,
                d_out=config.d_out,
                d_hidden=config.d_hidden if hasattr(config, 'd_hidden') else 128,
                n_hidden_layers=2,
                dropout=config.dropout if hasattr(config, 'dropout') else 0.2,
                normalize=config.normalize if hasattr(config, 'normalize') else True,
                residual=True,
                use_batch_norm=config.use_batch_norm if hasattr(config, 'use_batch_norm') else True,
            )
        )

        # Replacement embedding for unknown/not present tokens
        self._replacement_embedding = nn.Parameter(torch.randn(config.d_out))

    @property
    def marginal_embedding(self):
        """Return the marginal embedding (same as replacement for masked/not present)."""
        if self.config.normalize:
            return F.normalize(self._replacement_embedding, dim=-1)
        return self._replacement_embedding

    def forward(self, token_batch):
        """
        Encode FIPS token batch into embeddings.

        Args:
            token_batch: TokenBatch with value tensor of shape [batch, 35]:
                - [:, 0:2] lat, long
                - [:, 2] state_idx
                - [:, 3:19] state_region_embedding
                - [:, 19:35] county_embedding

        Returns:
            (short_vec, full_vec) tuple of embeddings
        """
        values = token_batch["values"]  # [batch, 35]
        statuses = token_batch["status"]  # [batch]

        device = values.device
        batch_size = values.shape[0]

        # Ensure correct dtype for BFloat16 compatibility
        target_dtype = self.combine_mlp.layers[0].weight.dtype
        values = values.to(dtype=target_dtype)

        # Extract components
        geo_coords = values[:, 0:2]  # [batch, 2]
        state_idx = values[:, 2:3]  # [batch, 1]
        state_region_emb = values[:, 3:3+FIPS_STATE_REGION_EMB_DIM]  # [batch, 16]
        county_emb = values[:, 3+FIPS_STATE_REGION_EMB_DIM:]  # [batch, 16]

        # Project each component
        geo_proj = self.geo_proj(geo_coords)  # [batch, 32]
        state_idx_proj = self.state_idx_proj(state_idx)  # [batch, 16]
        state_region_proj = self.state_region_proj(state_region_emb)  # [batch, 32]
        county_proj = self.county_proj(county_emb)  # [batch, 32]

        # Concatenate all projections
        combined = torch.cat([geo_proj, state_idx_proj, state_region_proj, county_proj], dim=-1)  # [batch, 112]

        # Apply MLP
        full_vec = self.combine_mlp(combined)  # [batch, d_out]

        # Handle NOT_PRESENT and UNKNOWN tokens
        replacement = self._replacement_embedding.to(dtype=target_dtype)
        if self.config.normalize:
            replacement = F.normalize(replacement, dim=-1)

        # Mask for valid tokens
        valid_mask = (statuses == TokenStatus.OK).unsqueeze(-1).to(dtype=target_dtype)  # [batch, 1]

        # Replace invalid tokens with replacement embedding
        full_vec = valid_mask * full_vec + (1 - valid_mask) * replacement.unsqueeze(0)

        # Short vec is just a slice (for 3D visualization)
        short_vec = full_vec[:, :3]

        return short_vec, full_vec


def create_fips_codec(df_col, embed_dim: int = 768, string_cache=None, detector=None) -> FipsCodec:
    """
    Factory function to create a FipsCodec.

    Args:
        df_col: pandas Series containing FIPS code data
        embed_dim: embedding dimension (default 768)
        string_cache: optional string cache (not used currently)
        detector: optional detector instance

    Returns:
        FipsCodec instance
    """
    return FipsCodec(df_col, embed_dim=embed_dim, string_cache=string_cache, detector=detector)


# Quick test
if __name__ == '__main__':
    import pandas as pd

    print(f"Loaded {len(COUNTY_FIPS_COORDS)} counties from data_fips.py")

    test_fips = ['06075', '36061', '48201', '17031', '12086', '06001', '6001', '47037', '', None]
    df = pd.Series(test_fips)

    codec = FipsCodec(df)

    print("\nFIPS Code Codec Test")
    print("=" * 70)
    for f in test_fips:
        token = codec.tokenize(f)
        parsed = parse_fips_code(f)
        if parsed['is_valid'] and parsed['fips'] in COUNTY_FIPS_COORDS:
            lat, lon, county, state = COUNTY_FIPS_COORDS[parsed['fips']]
            print(f"  {str(f):8} -> {county:25} {state} lat={lat:.2f} status={token.status.name}")
        else:
            print(f"  {str(f):8} -> (unknown)                              status={token.status.name}")
