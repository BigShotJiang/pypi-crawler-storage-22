#  -*- coding: utf-8 -*-
#
#  Copyright Featrix, Inc 2023-2026
#
#  LabelSchema - Single source of truth for label handling in classification.
#
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Literal

import numpy as np

logger = logging.getLogger(__name__)


@dataclass
class LabelSchema:
    """
    Single source of truth for label handling in classification.

    Uses canonical prefixed strings internally to prevent type confusion:
    - "pos:1", "neg:0" for binary
    - "class:cat", "class:dog" for multiclass
    - "unknown" for the UNKNOWN token

    All label conversions go through this class - no ad-hoc label handling elsewhere.

    Example:
        >>> schema = LabelSchema.from_codec(target_codec, pos_label=1)
        >>> schema.pos_label
        '1'
        >>> schema.to_canonical(1)
        'pos:1'
        >>> schema.get_pos_prob({"0": 0.3, "1": 0.7})
        0.7
    """

    # Classification type
    problem_type: Literal["binary", "multiclass"]

    # Canonical labels (prefixed strings)
    _pos_canonical: str | None = None           # "pos:<value>" for binary
    _neg_canonical: str | None = None           # "neg:<value>" for binary
    _classes_canonical: list[str] = field(default_factory=list)  # ["class:<v1>", ...]

    # Original values and types (for conversion back)
    _original_values: dict[str, Any] = field(default_factory=dict)  # canonical -> original
    _original_types: dict[str, type] = field(default_factory=dict)  # canonical -> type

    # UNKNOWN handling
    has_unknown: bool = False

    # =========================================================================
    # CONSTRUCTORS
    # =========================================================================

    @classmethod
    def from_codec(cls, codec, pos_label: Any = None) -> LabelSchema:
        """
        Create LabelSchema from a SetCodec.

        Args:
            codec: SetCodec with the target column vocabulary
            pos_label: Which class is positive (for binary). Auto-detected if None.
                       For binary classification, defaults to the minority class
                       or lexicographically larger label if counts unknown.

        Returns:
            LabelSchema configured for the codec's vocabulary
        """
        # Get real members (excluding UNKNOWN)
        all_members = list(codec.members)
        has_unknown = "<UNKNOWN>" in all_members
        real_members = sorted([m for m in all_members if m != "<UNKNOWN>"])

        is_binary = len(real_members) == 2

        schema = cls(
            problem_type="binary" if is_binary else "multiclass",
            has_unknown=has_unknown,
        )

        if is_binary:
            # Determine pos/neg labels
            if pos_label is not None:
                # Normalize pos_label to match codec values
                pos_normalized = schema._find_matching_member(pos_label, real_members)
                if pos_normalized is None:
                    raise ValueError(
                        f"pos_label '{pos_label}' (type={type(pos_label).__name__}) "
                        f"not found in codec members: {real_members}"
                    )
                neg_normalized = [m for m in real_members if m != pos_normalized][0]
            else:
                # Default: lexicographically larger is positive (sklearn convention for strings)
                # This ensures consistent behavior when pos_label not specified
                neg_normalized = real_members[0]
                pos_normalized = real_members[1]
                logger.debug(
                    f"LabelSchema: No pos_label specified, using sklearn convention: "
                    f"pos='{pos_normalized}', neg='{neg_normalized}'"
                )

            schema._pos_canonical = f"pos:{pos_normalized}"
            schema._neg_canonical = f"neg:{neg_normalized}"
            schema._original_values[schema._pos_canonical] = pos_normalized
            schema._original_values[schema._neg_canonical] = neg_normalized
            schema._original_types[schema._pos_canonical] = type(pos_normalized)
            schema._original_types[schema._neg_canonical] = type(neg_normalized)

            logger.info(f"LabelSchema created: binary, pos='{pos_normalized}', neg='{neg_normalized}'")

        else:
            # Multiclass
            for member in real_members:
                canonical = f"class:{member}"
                schema._classes_canonical.append(canonical)
                schema._original_values[canonical] = member
                schema._original_types[canonical] = type(member)

            logger.info(f"LabelSchema created: multiclass, {len(real_members)} classes")

        return schema

    @classmethod
    def from_labels(cls, labels, pos_label: Any = None) -> LabelSchema:
        """
        Create LabelSchema directly from a list/array of labels.

        Useful when you don't have a codec (e.g., external evaluation).

        Args:
            labels: Array-like of labels
            pos_label: Which class is positive (for binary)

        Returns:
            LabelSchema configured for the unique labels
        """
        unique_labels = sorted(set(str(x) for x in labels if str(x) != "<UNKNOWN>"))
        is_binary = len(unique_labels) == 2
        has_unknown = "<UNKNOWN>" in set(str(x) for x in labels)

        schema = cls(
            problem_type="binary" if is_binary else "multiclass",
            has_unknown=has_unknown,
        )

        if is_binary:
            if pos_label is not None:
                pos_normalized = schema._find_matching_member(pos_label, unique_labels)
                if pos_normalized is None:
                    raise ValueError(f"pos_label '{pos_label}' not found in labels: {unique_labels}")
                neg_normalized = [m for m in unique_labels if m != pos_normalized][0]
            else:
                neg_normalized = unique_labels[0]
                pos_normalized = unique_labels[1]

            schema._pos_canonical = f"pos:{pos_normalized}"
            schema._neg_canonical = f"neg:{neg_normalized}"
            schema._original_values[schema._pos_canonical] = pos_normalized
            schema._original_values[schema._neg_canonical] = neg_normalized
            schema._original_types[schema._pos_canonical] = type(pos_normalized)
            schema._original_types[schema._neg_canonical] = type(neg_normalized)
        else:
            for member in unique_labels:
                canonical = f"class:{member}"
                schema._classes_canonical.append(canonical)
                schema._original_values[canonical] = member
                schema._original_types[canonical] = type(member)

        return schema

    @classmethod
    def from_dict(cls, d: dict) -> LabelSchema:
        """Deserialize from dict (for JSON/pickle compatibility)."""
        schema = cls(
            problem_type=d["problem_type"],
            has_unknown=d.get("has_unknown", False),
        )
        schema._pos_canonical = d.get("_pos_canonical")
        schema._neg_canonical = d.get("_neg_canonical")
        schema._classes_canonical = d.get("_classes_canonical", [])
        schema._original_values = d.get("_original_values", {})

        # Restore types from string names
        type_map = {"str": str, "int": int, "float": float, "bool": bool}
        schema._original_types = {
            k: type_map.get(v, str)
            for k, v in d.get("_original_types_str", {}).items()
        }
        return schema

    def to_dict(self) -> dict:
        """Serialize to dict (for JSON/pickle compatibility)."""
        return {
            "problem_type": self.problem_type,
            "has_unknown": self.has_unknown,
            "_pos_canonical": self._pos_canonical,
            "_neg_canonical": self._neg_canonical,
            "_classes_canonical": self._classes_canonical,
            "_original_values": self._original_values,
            "_original_types_str": {k: v.__name__ for k, v in self._original_types.items()},
        }

    # =========================================================================
    # PROPERTIES
    # =========================================================================

    @property
    def is_binary(self) -> bool:
        """True if binary classification."""
        return self.problem_type == "binary"

    @property
    def num_classes(self) -> int:
        """Number of real classes (excludes UNKNOWN)."""
        if self.is_binary:
            return 2
        return len(self._classes_canonical)

    @property
    def pos_label(self) -> Any:
        """Original positive label value (binary only)."""
        if not self.is_binary:
            raise ValueError("pos_label only valid for binary classification")
        return self._original_values.get(self._pos_canonical)

    @property
    def neg_label(self) -> Any:
        """Original negative label value (binary only)."""
        if not self.is_binary:
            raise ValueError("neg_label only valid for binary classification")
        return self._original_values.get(self._neg_canonical)

    @property
    def class_labels(self) -> list[Any]:
        """All class labels in canonical order (excludes UNKNOWN)."""
        if self.is_binary:
            return [self.neg_label, self.pos_label]  # neg=0, pos=1 index convention
        return [self._original_values[c] for c in self._classes_canonical]

    @property
    def pos_label_str(self) -> str | None:
        """Positive label as string (for sklearn compatibility)."""
        return str(self.pos_label) if self.is_binary else None

    @property
    def neg_label_str(self) -> str | None:
        """Negative label as string (for sklearn compatibility)."""
        return str(self.neg_label) if self.is_binary else None

    # =========================================================================
    # LABEL CONVERSION
    # =========================================================================

    def to_canonical(self, label: Any) -> str:
        """
        Convert any label representation to canonical form.

        Args:
            label: Raw label (int, str, bool, etc.)

        Returns:
            Canonical string like "pos:1" or "class:cat"

        Raises:
            ValueError: If label doesn't match any known class
        """
        # Handle UNKNOWN
        if label == "<UNKNOWN>" or str(label) == "<UNKNOWN>":
            return "unknown"

        if self.is_binary:
            pos_orig = self._original_values.get(self._pos_canonical)
            neg_orig = self._original_values.get(self._neg_canonical)

            if self._matches(label, pos_orig):
                return self._pos_canonical
            if self._matches(label, neg_orig):
                return self._neg_canonical
        else:
            for canonical in self._classes_canonical:
                orig = self._original_values.get(canonical)
                if self._matches(label, orig):
                    return canonical

        raise ValueError(
            f"Label '{label}' (type={type(label).__name__}) not in schema. "
            f"Known labels: {self.class_labels}"
        )

    def from_canonical(self, canonical: str, as_type: Literal["original", "str", "int"] = "original") -> Any:
        """
        Convert canonical label back to desired type.

        Args:
            canonical: Canonical string like "pos:1" or "class:cat"
            as_type: Output type - "original" (preserve), "str", or "int"

        Returns:
            Label in requested type
        """
        if canonical == "unknown":
            return "<UNKNOWN>"

        orig_value = self._original_values.get(canonical)
        if orig_value is None:
            raise ValueError(f"Unknown canonical label: {canonical}")

        if as_type == "original":
            return orig_value
        elif as_type == "str":
            return str(orig_value)
        elif as_type == "int":
            if self.is_binary:
                return 1 if canonical == self._pos_canonical else 0
            else:
                return self._classes_canonical.index(canonical)
        else:
            raise ValueError(f"Unknown as_type: {as_type}")

    def convert_labels(self, labels, to_type: Literal["original", "str", "int"] = "str") -> np.ndarray:
        """
        Convert array of labels to consistent type.

        Args:
            labels: Array-like of labels (any type)
            to_type: Target type for all labels

        Returns:
            numpy array with all labels converted
        """
        result = []
        for label in labels:
            try:
                canonical = self.to_canonical(label)
                converted = self.from_canonical(canonical, as_type=to_type)
                result.append(converted)
            except ValueError as e:
                logger.warning(f"Label conversion failed: {e}")
                # For robustness, pass through as string if conversion fails
                result.append(str(label) if to_type == "str" else label)
        return np.array(result)

    def to_binary_int(self, labels) -> np.ndarray:
        """
        Convert labels to binary 0/1 array.

        For binary classification: neg_label -> 0, pos_label -> 1
        For multiclass: raises ValueError

        Args:
            labels: Array-like of labels

        Returns:
            numpy array of 0s and 1s
        """
        if not self.is_binary:
            raise ValueError("to_binary_int() only valid for binary classification")
        return self.convert_labels(labels, to_type="int")

    # =========================================================================
    # PROBABILITY HANDLING
    # =========================================================================

    def get_pos_prob(self, probs_dict: dict) -> float:
        """
        Extract probability of positive class from probabilities dict.

        Handles all key type variations (int, str, original type).

        Args:
            probs_dict: Dict like {"0": 0.3, "1": 0.7} or {0: 0.3, 1: 0.7}

        Returns:
            Probability of positive class

        Raises:
            ValueError: If positive class not found in probs_dict
        """
        if not self.is_binary:
            raise ValueError("get_pos_prob() only valid for binary classification")

        pos_orig = self.pos_label

        # Try exact match first
        if pos_orig in probs_dict:
            return float(probs_dict[pos_orig])

        # Try string version
        pos_str = str(pos_orig)
        if pos_str in probs_dict:
            return float(probs_dict[pos_str])

        # Try int version (if original was numeric string)
        try:
            pos_int = int(pos_orig)
            if pos_int in probs_dict:
                return float(probs_dict[pos_int])
        except (ValueError, TypeError):
            pass

        # Try float version
        try:
            pos_float = float(pos_orig)
            if pos_float in probs_dict:
                return float(probs_dict[pos_float])
        except (ValueError, TypeError):
            pass

        # Fallback: find by elimination (for binary, it's the one that's not neg)
        neg_orig = self.neg_label
        for k, v in probs_dict.items():
            if k == "<UNKNOWN>" or str(k) == "<UNKNOWN>":
                continue
            if not self._matches(k, neg_orig):
                return float(v)

        raise ValueError(
            f"Could not find pos_label '{pos_orig}' in probs_dict keys: {list(probs_dict.keys())}. "
            f"Schema: {self}"
        )

    def get_neg_prob(self, probs_dict: dict) -> float:
        """Extract probability of negative class (binary only)."""
        if not self.is_binary:
            raise ValueError("get_neg_prob() only valid for binary classification")
        return 1.0 - self.get_pos_prob(probs_dict)

    def get_class_prob(self, probs_dict: dict, class_label: Any) -> float:
        """
        Get probability for a specific class.

        Args:
            probs_dict: Probability dictionary
            class_label: The class to get probability for

        Returns:
            Probability for that class

        Raises:
            ValueError: If class not found
        """
        canonical = self.to_canonical(class_label)
        orig = self._original_values.get(canonical)

        # Try all variations
        for key_variant in [orig, str(orig)]:
            if key_variant in probs_dict:
                return float(probs_dict[key_variant])

        try:
            int_variant = int(orig)
            if int_variant in probs_dict:
                return float(probs_dict[int_variant])
        except (ValueError, TypeError):
            pass

        raise ValueError(f"Could not find class '{class_label}' in probs_dict: {list(probs_dict.keys())}")

    def normalize_probs_dict(self, probs_dict: dict, exclude_unknown: bool = True) -> dict[str, float]:
        """
        Normalize probability dict to use string keys consistently.

        Args:
            probs_dict: Input probability dict with any key types
            exclude_unknown: If True, remove UNKNOWN and renormalize

        Returns:
            Dict with string keys matching class_labels
        """
        result = {}
        total = 0.0

        for label in self.class_labels:
            try:
                prob = self.get_class_prob(probs_dict, label)
                result[str(label)] = prob
                total += prob
            except ValueError:
                result[str(label)] = 0.0

        # Handle UNKNOWN if present and not excluded
        if not exclude_unknown and self.has_unknown:
            for k in probs_dict:
                if str(k) == "<UNKNOWN>" or k == "<UNKNOWN>":
                    result["<UNKNOWN>"] = float(probs_dict[k])
                    total += result["<UNKNOWN>"]
                    break

        # Renormalize if we excluded something or total != 1
        if total > 0 and abs(total - 1.0) > 1e-6:
            result = {k: v / total for k, v in result.items()}

        return result

    # =========================================================================
    # SKLEARN COMPATIBILITY
    # =========================================================================

    def prepare_for_sklearn(
        self,
        y_true,
        y_pred,
        y_prob=None
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray | None, str | None]:
        """
        Prepare labels and probabilities for sklearn metrics.

        Ensures consistent types and correct pos_label handling.

        Args:
            y_true: Ground truth labels (any type)
            y_pred: Predicted labels (any type)
            y_prob: Optional - either:
                    - List of probability dicts [{"0": 0.3, "1": 0.7}, ...]
                    - Array of probabilities for positive class [0.7, 0.8, ...]

        Returns:
            Tuple of (y_true_str, y_pred_str, y_prob_pos, pos_label_str)
            - y_true_str: Ground truth as string array
            - y_pred_str: Predictions as string array
            - y_prob_pos: Probabilities for positive class (or None)
            - pos_label_str: String to pass to sklearn's pos_label param
        """
        y_true_str = self.convert_labels(y_true, to_type="str")
        y_pred_str = self.convert_labels(y_pred, to_type="str")

        y_prob_pos = None
        if y_prob is not None:
            if len(y_prob) > 0 and isinstance(y_prob[0], dict):
                # List of probability dicts - extract P(positive)
                y_prob_pos = np.array([self.get_pos_prob(p) for p in y_prob])
            else:
                # Already extracted probabilities - assume they're for pos class
                y_prob_pos = np.array(y_prob, dtype=float)

        return y_true_str, y_pred_str, y_prob_pos, self.pos_label_str

    # =========================================================================
    # INTERNAL HELPERS
    # =========================================================================

    def _matches(self, a: Any, b: Any) -> bool:
        """Check if two labels match (with type coercion)."""
        if a == b:
            return True
        if str(a) == str(b):
            return True
        # Numeric comparison for edge cases like 1 vs 1.0
        try:
            if float(a) == float(b):
                return True
        except (ValueError, TypeError):
            pass
        return False

    def _find_matching_member(self, label: Any, members: list) -> Any | None:
        """Find the member that matches a label."""
        for member in members:
            if self._matches(label, member):
                return member
        return None

    # =========================================================================
    # STRING REPRESENTATION
    # =========================================================================

    def __repr__(self) -> str:
        if self.is_binary:
            return f"LabelSchema(binary, pos={self.pos_label!r}, neg={self.neg_label!r})"
        return f"LabelSchema(multiclass, classes={self.class_labels!r})"

    def __str__(self) -> str:
        return self.__repr__()
