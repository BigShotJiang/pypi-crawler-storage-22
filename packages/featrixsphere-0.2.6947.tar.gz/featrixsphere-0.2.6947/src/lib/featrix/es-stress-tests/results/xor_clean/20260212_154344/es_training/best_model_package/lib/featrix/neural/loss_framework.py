#!/usr/bin/env python3
"""
Loss Framework - Modular, configurable loss system for tabular embeddings.

Goals:
1. Each loss is a self-contained module with standard interface
2. Config controls which losses are active and their weights
3. Easy to add new losses, run experiments, compare results
4. Clear logging of what's on/off and contribution of each loss

Usage:
    framework = LossFramework.from_config(config)
    total_loss, metrics = framework.compute_total(
        embeddings_1=masked_view_1,
        embeddings_2=masked_view_2,
        embeddings_unmasked=full_view,
        ...
    )
"""

import logging
import math
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Any

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from featrix.neural.adaptive_event_log import (
    get_adaptive_event_log,
    AdaptiveEvent,
    ReasonCode,
    ExpectedEffect,
)
from featrix.neural.featrix_token import TokenStatus

logger = logging.getLogger(__name__)


# =============================================================================
# Base Classes
# =============================================================================

@dataclass
class LossConfig:
    """Configuration for a single loss component."""
    enabled: bool = True
    weight: float = 1.0
    params: Dict[str, Any] = field(default_factory=dict)


class LossComponent(ABC):
    """Base class for all loss components."""

    def __init__(self, name: str, config: LossConfig):
        self.name = name
        self.config = config
        self._call_count = 0
        self._current_epoch = 0
        self._total_epochs = 1

    def set_epoch(self, epoch: int, total_epochs: int):
        """Track current epoch for timeline logging. Subclasses can override for curriculum behavior."""
        self._current_epoch = epoch
        self._total_epochs = total_epochs

    @property
    def enabled(self) -> bool:
        return self.config.enabled

    @property
    def weight(self) -> float:
        return self.config.weight

    @abstractmethod
    def compute(
        self,
        embeddings_1: torch.Tensor,
        embeddings_2: torch.Tensor,
        embeddings_unmasked: torch.Tensor,
        **kwargs
    ) -> Tuple[torch.Tensor, Dict[str, float]]:
        """
        Compute the loss value and metrics.

        Args:
            embeddings_1: (B, D) embeddings from mask view 1
            embeddings_2: (B, D) embeddings from mask view 2
            embeddings_unmasked: (B, D) embeddings from unmasked view
            **kwargs: Additional inputs (column encodings, labels, etc.)

        Returns:
            loss: Scalar tensor
            metrics: Dict of diagnostic values (for logging)
        """
        pass

    def __call__(self, *args, **kwargs) -> Tuple[torch.Tensor, Dict[str, float]]:
        self._call_count += 1
        return self.compute(*args, **kwargs)


# =============================================================================
# Contrastive Loss - The main attractive + repulsive force
# =============================================================================

class ContrastiveLoss(LossComponent):
    """
    Contrastive loss for masked embeddings with curriculum blending.

    Blends COSINE loss (learnable warmup) with INFONCE (discriminative):
    - Cosine: Loss = 1 - cosine_sim(masked, unmasked) - learnable from scratch
    - InfoNCE: Cross-entropy over similarity matrix - stronger discrimination

    Curriculum:
    - Epoch 0:     100% cosine, 0% InfoNCE (warmup)
    - Epoch N/2:   50% cosine, 50% InfoNCE (transition)
    - Epoch N:     0% cosine, 100% InfoNCE (discrimination)

    The blend is controlled by `infonce_weight` which goes from 0→1 over training.

    CRITICAL COMPONENTS (from legacy that were MISSING):
    1. Latent noise: Add small noise to targets before normalizing - prevents collapse
    2. Anti-collapse regularization: norm_penalty + diversity_penalty on predictions
    """

    def __init__(self, config: LossConfig):
        super().__init__("contrastive", config)
        self.base_temperature = config.params.get("temperature", 0.1)
        self.adaptive_temperature = config.params.get("adaptive_temperature", True)  # Use adaptive by default
        # Prefix for event log variables (disambiguate full vs short framework)
        self._event_prefix = config.params.get("event_prefix", "")
        # Curriculum: warmup_epochs before starting InfoNCE blend
        # REDUCED from 5 to 2: need InfoNCE earlier for instance discrimination
        self.warmup_epochs = config.params.get("warmup_epochs", 2)
        # Curriculum: transition_epochs to blend from cosine to InfoNCE
        # REDUCED from 20 to 10: faster transition to InfoNCE
        self.transition_epochs = config.params.get("transition_epochs", 10)
        # MINIMUM InfoNCE weight: always have some NCE even during warmup
        # Pure cosine gives mushy gradients - need some InfoNCE for sharp discrimination
        self.min_infonce_weight = config.params.get("min_infonce_weight", 0.25)
        # Current infonce weight (0=pure cosine, 1=pure infonce)
        self._infonce_weight = self.min_infonce_weight  # Start with minimum, not 0
        # For adaptive temperature
        self._n_columns = config.params.get("n_columns", 20)  # Will be updated from kwargs
        self._temp_log_count = 0
        # Track curriculum phase for timeline events
        self._last_curriculum_phase = "warmup"
        self._last_logged_temp = None

        # Latent noise - from legacy infoNCE_loss (line 2325 in encoders.py)
        # Note: Legacy actually has latent_noise=0, so DISABLED by default
        # Keeping this as an option but not enabled
        self.latent_noise = config.params.get("latent_noise", 0.0)

        # CRITICAL: Anti-collapse regularization weights (from legacy compute_joint_infoNCE_loss)
        self.norm_penalty_weight = config.params.get("norm_penalty_weight", 0.1)
        self.diversity_penalty_weight = config.params.get("diversity_penalty_weight", 0.1)

    def _compute_adaptive_temp(self, batch_size: int) -> float:
        """
        Compute adaptive temperature based on batch size and columns.
        Matches the logic from encoders.py _compute_adaptive_temperature.
        """
        if not self.adaptive_temperature:
            return self.base_temperature

        # Base temperature: reasonable default
        base_temp = 0.1

        # Batch size factor: larger batches → more negatives → can use lower temp (sharper)
        batch_factor = max(0.7, min(1.5, batch_size / 256.0))

        # Column factor: more columns = more discriminative embeddings
        column_factor = 1.0 + (math.log10(max(10, self._n_columns)) - 1.0) * 0.15
        column_factor = max(0.8, min(1.5, column_factor))

        # Compute adaptive temp
        temp = base_temp / (batch_factor * column_factor)

        # Clamp to reasonable range
        temp = max(0.05, min(0.3, temp))

        # Log initial temperature and significant changes to timeline
        prefix = f"{self._event_prefix}_" if self._event_prefix else ""
        ctrl_name = f"ContrastiveLoss{f'({self._event_prefix})' if self._event_prefix else ''}"
        if self._last_logged_temp is None:
            # First call - log initial temperature
            log = get_adaptive_event_log()
            log.emit_simple(
                variable=f"{prefix}contrastive_temperature",
                old_value=self.base_temperature,
                new_value=temp,
                epoch=self._current_epoch,
                step=self._call_count,
                controller_name=ctrl_name,
                reason_code=ReasonCode.SCHEDULED_WARMUP,
                trigger_metric="batch_size",
                trigger_value=float(batch_size),
                expected_effect=ExpectedEffect.SHARPEN_DISCRIMINATION,
                notes=f"Initial adaptive temp: B={batch_size}, cols={self._n_columns}",
                force=True,
            )
            self._last_logged_temp = temp
        elif abs(temp - self._last_logged_temp) > 0.01:
            # Significant temperature change (>0.01)
            log = get_adaptive_event_log()
            log.emit_simple(
                variable=f"{prefix}contrastive_temperature",
                old_value=self._last_logged_temp,
                new_value=temp,
                epoch=self._current_epoch,
                step=self._call_count,
                controller_name=ctrl_name,
                reason_code=ReasonCode.TEMPERATURE_ANNEAL,
                trigger_metric="batch_size",
                trigger_value=float(batch_size),
                expected_effect=ExpectedEffect.SHARPEN_DISCRIMINATION if temp < self._last_logged_temp else ExpectedEffect.ALLOW_EXPLORATION,
                notes=f"Adaptive temp change: B={batch_size}, cols={self._n_columns}",
            )
            logger.info(
                f"🌡️  [TRAINING EVENT] Contrastive temperature: "
                f"{self._last_logged_temp:.4f} → {temp:.4f} (B={batch_size}, cols={self._n_columns})"
            )
            self._last_logged_temp = temp

        # Log occasionally (first 5 calls)
        if self._temp_log_count < 5:
            logger.info(f"🌡️  ContrastiveLoss adaptive temp: {temp:.4f} (B={batch_size}, cols={self._n_columns})")
            self._temp_log_count += 1

        return temp

    def set_epoch(self, epoch: int, total_epochs: int):
        """Update the cosine↔InfoNCE blend based on training progress.

        IMPORTANT: Always maintain at least min_infonce_weight (default 25%) InfoNCE.
        Pure cosine contrastive gives mushy gradients compared to InfoNCE/NT-Xent.
        Even during warmup, we need some InfoNCE for instance discrimination.
        """
        super().set_epoch(epoch, total_epochs)
        old_weight = self._infonce_weight

        if epoch < self.warmup_epochs:
            # Warmup: use minimum InfoNCE weight (not pure cosine!)
            self._infonce_weight = self.min_infonce_weight
            current_phase = "warmup"
        elif epoch >= self.warmup_epochs + self.transition_epochs:
            # After transition: pure InfoNCE
            self._infonce_weight = 1.0
            current_phase = "full_infonce"
        else:
            # Linear blend during transition: min_weight → 1.0
            progress = (epoch - self.warmup_epochs) / self.transition_epochs
            # Interpolate from min_infonce_weight to 1.0
            self._infonce_weight = self.min_infonce_weight + progress * (1.0 - self.min_infonce_weight)
            current_phase = "transition"

        # Log phase transitions to adaptive event log
        if current_phase != self._last_curriculum_phase:
            prefix = f"{self._event_prefix}_" if self._event_prefix else ""
            log = get_adaptive_event_log()
            log.emit_simple(
                variable=f"{prefix}contrastive_infonce_weight",
                old_value=old_weight,
                new_value=self._infonce_weight,
                epoch=epoch,
                step=0,
                controller_name=f"ContrastiveLoss{f'({self._event_prefix})' if self._event_prefix else ''}",
                reason_code=ReasonCode.CURRICULUM_PHASE_CHANGE,
                trigger_metric="epoch",
                trigger_value=float(epoch),
                expected_effect=ExpectedEffect.SHARPEN_DISCRIMINATION,
                notes=f"Phase: {self._last_curriculum_phase} → {current_phase}",
                force=True,
            )
            logger.info(
                f"📐 [TRAINING EVENT] Contrastive{f' ({self._event_prefix})' if self._event_prefix else ''} curriculum: "
                f"{self._last_curriculum_phase} → {current_phase} "
                f"(infonce_weight={self._infonce_weight:.2f}, epoch={epoch})"
            )
            self._last_curriculum_phase = current_phase

    def compute(
        self,
        embeddings_1: torch.Tensor,
        embeddings_2: torch.Tensor,
        embeddings_unmasked: torch.Tensor,
        **kwargs
    ) -> Tuple[torch.Tensor, Dict[str, float]]:
        """
        Blended contrastive loss: cosine warmup → InfoNCE discrimination.

        CRITICAL FIX: Includes latent noise and anti-collapse regularization
        from legacy infoNCE_loss and compute_joint_infoNCE_loss.
        """
        device = embeddings_1.device
        B = embeddings_1.shape[0]

        if B < 2:
            return torch.tensor(0.0, device=device), {"n_samples": B}

        # Update n_columns from column_targets if provided (for adaptive temperature)
        column_targets = kwargs.get("column_targets")
        if column_targets is not None and len(column_targets.shape) >= 2:
            self._n_columns = column_targets.shape[1]

        # Compute adaptive temperature based on batch size
        temperature = self._compute_adaptive_temp(B)

        # =================================================================
        # CRITICAL FIX #1: Add latent noise to targets (from legacy line 2325)
        # This prevents collapse by making targets slightly noisy
        # Always add noise during training (we're a loss function, always in training)
        # =================================================================
        emb_unmasked_noisy = embeddings_unmasked
        if self.latent_noise > 0:
            emb_unmasked_noisy = embeddings_unmasked + torch.randn_like(embeddings_unmasked) * self.latent_noise

        # Normalize for cosine similarity (AFTER adding noise to targets)
        emb1 = F.normalize(embeddings_1, dim=1, eps=1e-8)
        emb2 = F.normalize(embeddings_2, dim=1, eps=1e-8)
        emb_unmasked = F.normalize(emb_unmasked_noisy, dim=1, eps=1e-8)

        # =====================================================================
        # COSINE LOSS: Same-row similarity (learnable from scratch)
        # =====================================================================
        cosine_sim_1 = (emb1 * emb_unmasked).sum(dim=1)  # (B,)
        cosine_sim_2 = (emb2 * emb_unmasked).sum(dim=1)  # (B,)
        cosine_loss_1 = (1.0 - cosine_sim_1).mean()
        cosine_loss_2 = (1.0 - cosine_sim_2).mean()
        cosine_loss = (cosine_loss_1 + cosine_loss_2) / 2

        # =====================================================================
        # INFONCE LOSS: Cross-entropy discrimination
        # =====================================================================
        targets = torch.arange(B, device=device)
        sim_matrix_1 = emb1 @ emb_unmasked.T / temperature
        infonce_loss_1 = F.cross_entropy(sim_matrix_1, targets)
        sim_matrix_2 = emb2 @ emb_unmasked.T / temperature
        infonce_loss_2 = F.cross_entropy(sim_matrix_2, targets)
        infonce_loss = (infonce_loss_1 + infonce_loss_2) / 2

        # =====================================================================
        # BLEND: Curriculum from cosine → InfoNCE
        # =====================================================================
        w = self._infonce_weight
        base_loss = (1 - w) * cosine_loss + w * infonce_loss

        # =================================================================
        # CRITICAL FIX #2: Anti-collapse regularization (from legacy lines 3513-3529)
        # 1. Norm penalty: keep embedding norms close to 1.0
        # 2. Diversity penalty: prevent all embeddings from collapsing to same direction
        # =================================================================

        # Norm penalty: embeddings should have norm close to 1.0 (before normalization)
        emb1_norms = embeddings_1.norm(dim=1)
        emb2_norms = embeddings_2.norm(dim=1)
        norm_penalty = ((emb1_norms - 1.0) ** 2).mean() + ((emb2_norms - 1.0) ** 2).mean()

        # Diversity penalty: penalize high self-similarity across batch (collapsed predictions)
        # Use the already-normalized embeddings
        self_sim_1 = emb1 @ emb1.T
        self_sim_2 = emb2 @ emb2.T
        off_diag_mask = ~torch.eye(B, dtype=torch.bool, device=device)
        pred_self_sim_1 = self_sim_1[off_diag_mask].mean()
        pred_self_sim_2 = self_sim_2[off_diag_mask].mean()
        diversity_penalty = (pred_self_sim_1 ** 2 + pred_self_sim_2 ** 2) / 2

        # Combine: base_loss + weighted penalties
        loss = base_loss + self.norm_penalty_weight * norm_penalty + self.diversity_penalty_weight * diversity_penalty

        # =====================================================================
        # METRICS
        # =====================================================================
        with torch.no_grad():
            # Cosine metrics
            mean_cosine_1 = cosine_sim_1.mean().item()
            mean_cosine_2 = cosine_sim_2.mean().item()

            # InfoNCE metrics (multiply back by temperature to get actual similarity)
            pos_sim = torch.diag(sim_matrix_1).mean().item() * temperature
            mask = ~torch.eye(B, dtype=torch.bool, device=device)
            neg_sim = sim_matrix_1[mask].mean().item() * temperature

            # InfoNCE accuracy
            preds_1 = sim_matrix_1.argmax(dim=1)
            preds_2 = sim_matrix_2.argmax(dim=1)
            accuracy_1 = (preds_1 == targets).float().mean().item()
            accuracy_2 = (preds_2 == targets).float().mean().item()
            accuracy = (accuracy_1 + accuracy_2) / 2

        metrics = {
            "loss": loss.item(),
            "base_loss": base_loss.item(),
            "cosine_loss": cosine_loss.item(),
            "infonce_loss": infonce_loss.item(),
            "infonce_weight": w,
            "pos_sim": pos_sim,
            "neg_sim": neg_sim,
            "separation": pos_sim - neg_sim,
            "accuracy": accuracy,
            "batch_size": B,  # For computing ×random multiplier
            "mean_cosine_1": mean_cosine_1,
            "mean_cosine_2": mean_cosine_2,
            "temperature": temperature,  # Log actual temperature used
            "mode": f"blend({1-w:.0%}cos+{w:.0%}nce)",
            # Anti-collapse metrics
            "norm_penalty": norm_penalty.item(),
            "diversity_penalty": diversity_penalty.item(),
            "mean_norm_1": emb1_norms.mean().item(),
            "mean_norm_2": emb2_norms.mean().item(),
            "self_sim_1": pred_self_sim_1.item(),
            "self_sim_2": pred_self_sim_2.item(),
            "latent_noise": self.latent_noise,
        }

        return loss, metrics


# =============================================================================
# Separation Loss - Pure repulsive force
# =============================================================================

class SeparationLoss(LossComponent):
    """
    Penalizes high pairwise similarity between different rows.

    This is PURE REPULSION - no attractive component.
    Use sparingly, as contrastive loss already has repulsion built in.

    Also captures distribution stats for pairwise distance visualization.
    """

    def __init__(self, config: LossConfig):
        super().__init__("separation", config)
        self.target_sim = config.params.get("target_sim", 0.0)
        # Store last separation data for visualization (accessed by training movie writer)
        self._last_separation_data = None

    def compute(
        self,
        embeddings_1: torch.Tensor,
        embeddings_2: torch.Tensor,
        embeddings_unmasked: torch.Tensor,
        **kwargs
    ) -> Tuple[torch.Tensor, Dict[str, float]]:
        """Penalize mean off-diagonal similarity."""
        import numpy as np

        device = embeddings_unmasked.device
        B = embeddings_unmasked.shape[0]

        if B < 2:
            return torch.tensor(0.0, device=device), {"n_samples": B}

        # Normalize
        emb = F.normalize(embeddings_unmasked, dim=1, eps=1e-8)

        # Pairwise cosine similarity
        sim_matrix = emb @ emb.T

        # Off-diagonal mask and values
        mask = ~torch.eye(B, dtype=torch.bool, device=device)
        off_diag = sim_matrix[mask]
        mean_sim = off_diag.mean()

        # Loss: penalize deviation from target (usually 0)
        loss = (mean_sim - self.target_sim) ** 2

        # Compute distribution stats for visualization
        off_diag_np = off_diag.detach().cpu().numpy()
        std_val = float(np.std(off_diag_np))
        min_val = float(np.min(off_diag_np))
        max_val = float(np.max(off_diag_np))
        percentiles = np.percentile(off_diag_np, [5, 10, 25, 50, 75, 90, 95])

        # Diagonal similarity (self-similarity, always 1.0 for normalized)
        diag_sim = sim_matrix.diag().mean()
        separation_value = diag_sim - mean_sim

        metrics = {
            "loss": loss.item(),
            "mean_off_diag_sim": mean_sim.item(),
            "separation": separation_value.item(),
            "max_sim": off_diag.max().item(),
            "min_sim": min_val,
            # Distribution stats
            "std": std_val,
            "p5": float(percentiles[0]),
            "p10": float(percentiles[1]),
            "p25": float(percentiles[2]),
            "p50": float(percentiles[3]),
            "p75": float(percentiles[4]),
            "p90": float(percentiles[5]),
            "p95": float(percentiles[6]),
            "n_samples": B,
            "n_pairs": len(off_diag_np),
        }

        # Store for visualization (accessed by training movie writer)
        current_epoch = kwargs.get('epoch', 0)
        self._last_separation_data = {
            'epoch': current_epoch,
            'off_diag_similarities': off_diag_np,  # numpy array for histogram
            'n_samples': B,
            'stats': metrics,
        }

        return loss, metrics


# =============================================================================
# Uniformity Loss - Spread embeddings on sphere
# =============================================================================

class UniformityLoss(LossComponent):
    """
    Log-sum-exp uniformity loss (Wang & Isola 2020).

    Encourages embeddings to be uniformly distributed on the unit sphere.
    This is a softer repulsion than SeparationLoss.

    CRITICAL: Applies to MASKED embeddings (embeddings_1, embeddings_2) which have gradients,
    NOT to embeddings_unmasked which is typically detached. This ensures the repulsive force
    actually pushes the training embeddings apart.
    """

    def __init__(self, config: LossConfig):
        super().__init__("uniformity", config)
        self.temperature = config.params.get("temperature", 2.0)

    def _compute_uniformity_for_embeddings(self, emb: torch.Tensor) -> Tuple[torch.Tensor, float, float]:
        """Compute uniformity loss for a single set of embeddings."""
        device = emb.device
        B = emb.shape[0]

        # Normalize
        emb_norm = F.normalize(emb, dim=1, eps=1e-8)

        # Pairwise squared distances (for unit vectors: 2 - 2*cos_sim)
        sim_matrix = emb_norm @ emb_norm.T
        dist_sq = 2.0 - 2.0 * sim_matrix

        # Mask diagonal
        mask = ~torch.eye(B, dtype=torch.bool, device=device)
        dist_sq_offdiag = dist_sq[mask].view(B, B - 1)

        # Log-sum-exp of negative distances (penalizes close pairs)
        loss = torch.logsumexp(-self.temperature * dist_sq_offdiag, dim=1).mean()

        return loss, dist_sq_offdiag.mean().item(), dist_sq_offdiag.min().item()

    def compute(
        self,
        embeddings_1: torch.Tensor,
        embeddings_2: torch.Tensor,
        embeddings_unmasked: torch.Tensor,
        **kwargs
    ) -> Tuple[torch.Tensor, Dict[str, float]]:
        """
        Log-sum-exp uniformity loss applied to MASKED embeddings.

        CRITICAL FIX: Apply to embeddings_1 and embeddings_2 (which have gradients),
        not embeddings_unmasked (which is typically detached and won't backprop).
        This ensures the repulsive force actually trains the model to spread embeddings.
        """
        device = embeddings_1.device
        B = embeddings_1.shape[0]

        if B < 2:
            return torch.tensor(0.0, device=device), {"n_samples": B}

        # Compute uniformity for both masked views
        loss_1, mean_dist_1, min_dist_1 = self._compute_uniformity_for_embeddings(embeddings_1)
        loss_2, mean_dist_2, min_dist_2 = self._compute_uniformity_for_embeddings(embeddings_2)

        # Average the losses
        loss = (loss_1 + loss_2) / 2

        metrics = {
            "loss": loss.item(),
            "mean_dist_sq": (mean_dist_1 + mean_dist_2) / 2,
            "min_dist_sq": min(min_dist_1, min_dist_2),
            "loss_1": loss_1.item(),
            "loss_2": loss_2.item(),
        }

        return loss, metrics


# =============================================================================
# Spread Loss - Cross-entropy self-similarity (original working version)
# =============================================================================

class SpreadLoss(LossComponent):
    """
    Spread loss using cross-entropy on self-similarity matrix.

    This is the ORIGINAL spread loss that was used when AUC was 0.78+.
    It differs from UniformityLoss (log-sum-exp) - this uses cross-entropy
    where each row should be most similar to itself.

    Formula: CE(softmax(embeddings @ embeddings.T / temp), identity)

    This provides a strong repulsive force between different rows while
    maintaining that each row should match itself.
    """

    def __init__(self, config: LossConfig):
        super().__init__("spread", config)
        # Match legacy temperature (0.2 base, not 0.03)
        # Legacy compute_spread_loss uses base_temp=0.2 with adaptive scaling
        self.temperature = config.params.get("temperature", 0.2)

    def compute(
        self,
        embeddings_1: torch.Tensor,
        embeddings_2: torch.Tensor,
        embeddings_unmasked: torch.Tensor,
        **kwargs
    ) -> Tuple[torch.Tensor, Dict[str, float]]:
        """
        Compute spread loss using cross-entropy on self-similarity.

        CRITICAL: Do NOT normalize embeddings before computing spread loss!
        Legacy code (compute_spread_loss in encoders.py) uses unnormalized embeddings.
        For 128D normalized embeddings, random vectors are nearly orthogonal (dot~0),
        so the loss is ~0 and provides no gradient. Unnormalized embeddings have
        varying norms that give meaningful gradients.

        Applies to all three views: unmasked, masked_1, masked_2
        """
        device = embeddings_unmasked.device
        B = embeddings_unmasked.shape[0]
        D = embeddings_unmasked.shape[1]

        if B < 2:
            logger.warning(f"SpreadLoss: B={B} < 2, returning 0 (dim={D})")
            return torch.tensor(0.0, device=device), {"n_samples": B, "dim": D, "skipped": True}

        # Target: each row matches itself (diagonal)
        targets = torch.arange(B, device=device)

        # CRITICAL: Do NOT normalize! Use raw embeddings like legacy code.
        # Legacy: logits_joint = unmasked_encoding @ unmasked_encoding.T / temp
        # This gives non-zero gradients in high dimensions where normalized vectors are orthogonal.

        # Self-similarity matrices (unnormalized)
        logits_unmasked = embeddings_unmasked @ embeddings_unmasked.T / self.temperature
        logits_1 = embeddings_1 @ embeddings_1.T / self.temperature
        logits_2 = embeddings_2 @ embeddings_2.T / self.temperature

        # Cross-entropy losses
        loss_unmasked = F.cross_entropy(logits_unmasked, targets)
        loss_1 = F.cross_entropy(logits_1, targets)
        loss_2 = F.cross_entropy(logits_2, targets)

        # Total spread loss
        loss = loss_unmasked + loss_1 + loss_2

        # Debug: check for collapse (all embeddings identical)
        if not hasattr(self, '_collapse_check_count'):
            self._collapse_check_count = 0
        if self._collapse_check_count < 3:
            with torch.no_grad():
                diag_mean = torch.diag(logits_unmasked).mean().item()
                off_diag_mask = ~torch.eye(B, dtype=torch.bool, device=device)
                off_diag_mean = logits_unmasked[off_diag_mask].mean().item()
                sim_range = (logits_unmasked.max() - logits_unmasked.min()).item()
                logger.info(f"🔍 SpreadLoss DEBUG (D={D}): diag={diag_mean:.4f}, off_diag={off_diag_mean:.4f}, "
                           f"range={sim_range:.4f}, temp={self.temperature}")
            self._collapse_check_count += 1

        # Metrics (using unnormalized embeddings to match loss computation)
        with torch.no_grad():
            sim_matrix = embeddings_unmasked @ embeddings_unmasked.T
            # Diagonal similarity (should be high)
            diag_sim = torch.diag(sim_matrix).mean().item()
            # Off-diagonal similarity (should be low)
            mask = ~torch.eye(B, dtype=torch.bool, device=device)
            off_diag_sim = sim_matrix[mask].mean().item()

        metrics = {
            "loss": loss.item(),
            "loss_unmasked": loss_unmasked.item(),
            "loss_1": loss_1.item(),
            "loss_2": loss_2.item(),
            "diag_sim": diag_sim,
            "off_diag_sim": off_diag_sim,
            "separation": diag_sim - off_diag_sim,
            "temperature": self.temperature,
            "batch_size": B,
            "dim": D,
        }

        # Debug logging for first few batches
        if not hasattr(self, '_log_count'):
            self._log_count = 0
        if self._log_count < 5:
            logger.info(f"📊 SpreadLoss: B={B}, D={D}, loss={loss.item():.4f}, temp={self.temperature}")
            self._log_count += 1

        return loss, metrics


# =============================================================================
# Diversity Loss - Use all dimensions
# =============================================================================

class DiversityLoss(LossComponent):
    """
    Encourages embeddings to use all dimensions (not collapse to subspace).

    Penalizes dimensions with low variance across the batch.
    """

    def __init__(self, config: LossConfig):
        super().__init__("diversity", config)
        # Target std for uniform on sphere: 1/sqrt(d)
        # But we allow config override
        self.target_std_multiplier = config.params.get("target_std_multiplier", 1.0)

    def compute(
        self,
        embeddings_1: torch.Tensor,
        embeddings_2: torch.Tensor,
        embeddings_unmasked: torch.Tensor,
        **kwargs
    ) -> Tuple[torch.Tensor, Dict[str, float]]:
        """Penalize low per-dimension variance."""
        device = embeddings_unmasked.device
        B, D = embeddings_unmasked.shape

        if B < 2:
            return torch.tensor(0.0, device=device), {"n_samples": B, "d_model": D}

        # Normalize
        emb = F.normalize(embeddings_unmasked, dim=1, eps=1e-8)

        # Per-dimension std
        std_per_dim = emb.std(dim=0)

        # Target std for uniform distribution on unit sphere
        target_std = self.target_std_multiplier / (D ** 0.5)

        # Penalize dimensions below target
        deficit = torch.clamp(target_std - std_per_dim, min=0.0)
        loss = (deficit ** 2).mean()

        metrics = {
            "loss": loss.item(),
            "mean_std": std_per_dim.mean().item(),
            "min_std": std_per_dim.min().item(),
            "max_std": std_per_dim.max().item(),
            "target_std": target_std,
        }

        return loss, metrics


# =============================================================================
# Halfspace Coverage Loss - Random hyperplane partitioning for full sphere coverage
# =============================================================================

class HalfspaceCoverageLoss(LossComponent):
    """
    Encourages embeddings to cover the full hypersphere by checking coverage
    across random hyperplane splits.

    SINGLE-TARGET APPROACH (prevents oscillation):
    For K random hyperplane directions, we find the SINGLE most imbalanced split
    and pull toward only that one. This prevents conflicting gradients from
    multiple pulls causing points to oscillate back and forth.

    Algorithm:
    1. For each split direction, compute imbalance = |n_pos - n_neg| / B
    2. Find the split with the worst imbalance
    3. Pull points toward the empty/underpopulated side of ONLY that split

    Args (via config.params):
        n_splits: Number of random hyperplane splits to check (default: 16)
        min_count_target: Legacy param, now uses fair-share calculation
        resample_every: Re-sample split directions every N calls (default: 50)
    """

    def __init__(self, config: LossConfig):
        super().__init__("halfspace_coverage", config)
        self.n_splits = config.params.get("n_splits", 16)
        self.min_count_target = config.params.get("min_count_target", 1)
        self.resample_every = config.params.get("resample_every", 50)
        # Split directions will be lazily initialized on first call
        self._split_directions = None
        self._splits_device = None
        self._splits_dtype = None

    def _get_split_directions(self, D: int, device: torch.device, dtype: torch.dtype) -> torch.Tensor:
        """Get or resample random split directions."""
        needs_resample = (
            self._split_directions is None
            or self._call_count % self.resample_every == 0
            or self._split_directions.shape[1] != D
            or self._splits_device != device
        )
        if needs_resample:
            # Sample random unit vectors as hyperplane normals
            directions = torch.randn(self.n_splits, D, device=device, dtype=dtype)
            self._split_directions = F.normalize(directions, dim=1, eps=1e-8)
            self._splits_device = device
            self._splits_dtype = dtype
        return self._split_directions

    def compute(
        self,
        embeddings_1: torch.Tensor,
        embeddings_2: torch.Tensor,
        embeddings_unmasked: torch.Tensor,
        **kwargs
    ) -> Tuple[torch.Tensor, Dict[str, float]]:
        """
        Find the SINGLE most imbalanced hyperplane split and pull toward it.
        """
        device = embeddings_unmasked.device
        emb = F.normalize(embeddings_unmasked, dim=1, eps=1e-8)
        B, D = emb.shape

        if B < 8:
            return torch.tensor(0.0, device=device), {"n_samples": B, "skipped": True}

        # Get split directions: (K, D)
        splits = self._get_split_directions(D, device, emb.dtype)
        K = splits.shape[0]

        # Project all points onto all split directions: (B, K)
        projections = emb @ splits.T  # (B, K)

        # For each split, compute counts on each side
        positive_counts = (projections > 0).sum(dim=0).float()  # (K,)
        negative_counts = B - positive_counts  # (K,)

        # Fair share is B/2 for each halfspace
        fair_share = B / 2.0

        # Score each halfspace by how far below fair share it is (0 if at/above)
        # For each split k, we have 2 halfspaces (positive and negative side)
        pos_scores = torch.clamp(fair_share - positive_counts, min=0.0)  # (K,)
        neg_scores = torch.clamp(fair_share - negative_counts, min=0.0)  # (K,)

        # Find the worst halfspace across all splits
        # Stack to get (2K,) scores and find max
        all_scores = torch.cat([pos_scores, neg_scores])  # (2K,)
        max_score, max_idx = all_scores.max(dim=0)
        max_score_val = max_score.item()

        # If all halfspaces are reasonably balanced, no action needed
        # Threshold: 25% imbalance (one side has < 37.5% of points)
        if max_score_val < 0.25 * fair_share:
            metrics = {
                "n_samples": B,
                "dim": D,
                "n_splits": K,
                "max_imbalance_score": max_score_val,
                "fair_share": fair_share,
                "status": "balanced",
                "loss": 0.0,
            }
            return torch.tensor(0.0, device=device), metrics

        # Decode which split and which side (positive or negative)
        max_idx_val = max_idx.item()
        if max_idx_val < K:
            # Positive side of split max_idx is underpopulated
            target_split_idx = max_idx_val
            target_sign = 1.0  # Pull toward positive side
            target_count = positive_counts[target_split_idx].item()
        else:
            # Negative side of split (max_idx - K) is underpopulated
            target_split_idx = max_idx_val - K
            target_sign = -1.0  # Pull toward negative side
            target_count = negative_counts[target_split_idx].item()

        # Target direction: the split normal * sign
        target_direction = target_sign * splits[target_split_idx]  # (D,)

        # Select points on the WRONG side (opposite of target)
        proj_on_target = projections[:, target_split_idx]  # (B,)
        if target_sign > 0:
            # Target is positive side, so wrong side is negative (proj <= 0)
            wrong_side_mask = proj_on_target <= 0
        else:
            # Target is negative side, so wrong side is positive (proj > 0)
            wrong_side_mask = proj_on_target > 0

        n_wrong_side = wrong_side_mask.sum().item()
        if n_wrong_side == 0:
            return torch.tensor(0.0, device=device), {"n_samples": B, "status": "no_wrong_side"}

        # Cosine similarity of wrong-side points to target direction
        sims_to_target = emb[wrong_side_mask] @ target_direction  # (N,)

        # Pull the closest points (highest similarity = nearest to crossing)
        # Move proportional to deficit but cap reasonably
        deficit = int(fair_share - target_count)
        n_to_move = max(1, min(deficit, n_wrong_side, B // 8))
        top_sims, _ = sims_to_target.topk(n_to_move)

        # Loss: (1 - sim) so 0 at target, 1 orthogonal, 2 antipodal
        loss = (1.0 - top_sims).mean()

        metrics = {
            "n_samples": B,
            "dim": D,
            "n_splits": K,
            "target_split_idx": target_split_idx,
            "target_sign": target_sign,
            "target_count": target_count,
            "max_imbalance_score": max_score_val,
            "fair_share": fair_share,
            "n_wrong_side": n_wrong_side,
            "n_to_move": n_to_move,
            "status": "pulling",
            "loss": loss.item(),
        }

        return loss, metrics


# =============================================================================
# Column Prediction Loss (Marginal)
# =============================================================================

class ColumnPredictionLoss(LossComponent):
    """
    Predict masked columns from visible columns.

    This is the core TASK - can we predict column A from columns B, C, D?

    Uses SAME-ROW cosine similarity (not InfoNCE across batch):
    - For each column, compute cosine similarity between prediction and target of SAME row
    - Loss = 1 - cosine_similarity (minimizes to 0 when perfectly aligned)

    This is learnable from the start because:
    - We're asking "how well does this prediction match THIS row's target?"
    - NOT "which of 128 rows does this prediction belong to?" (impossible at init)
    """

    def __init__(self, config: LossConfig):
        super().__init__("column_prediction", config)
        self.temperature = config.params.get("temperature", 0.1)
        # Use same-row cosine by default (more learnable)
        self.use_infonce = config.params.get("use_infonce", False)

    def compute(
        self,
        embeddings_1: torch.Tensor,
        embeddings_2: torch.Tensor,
        embeddings_unmasked: torch.Tensor,
        column_predictions: Optional[torch.Tensor] = None,
        column_targets: Optional[torch.Tensor] = None,
        column_mask: Optional[torch.Tensor] = None,
        **kwargs
    ) -> Tuple[torch.Tensor, Dict[str, float]]:
        """
        Same-row cosine similarity loss for column prediction.

        CRITICAL: Only computes loss on MASKED columns (TokenStatus.MARGINAL).
        Unmasked columns have trivial predictions (input=target) and would dominate
        the loss if included.

        Args:
            column_predictions: (B, n_cols, D) predicted column embeddings
            column_targets: (B, n_cols, D) target column embeddings
            column_mask: (B, n_cols) mask tensor where MARGINAL (3) = masked, OK (2) = not masked
        """
        device = embeddings_unmasked.device

        if column_predictions is None or column_targets is None:
            return torch.tensor(0.0, device=device), {"skipped": True}

        B, n_cols, D = column_predictions.shape

        # CRITICAL: Only compute loss on MASKED columns
        # If mask not provided, compute on all (backward compat, but suboptimal)
        if column_mask is not None:
            mask_bool = (column_mask == TokenStatus.MARGINAL)  # (B, n_cols) - True where masked
            n_masked = mask_bool.sum().item()
            if n_masked == 0:
                # No masked columns in this batch - skip loss computation
                return torch.tensor(0.0, device=device, requires_grad=True), {
                    "skipped": True,
                    "reason": "no_masked_columns",
                    "n_masked": 0,
                }
        else:
            mask_bool = None
            n_masked = B * n_cols  # All positions

        if self.use_infonce:
            # Original InfoNCE approach (hard to learn from scratch)
            total_loss = 0.0
            n_computed = 0
            for col_idx in range(n_cols):
                # Check if this column has any masked positions
                if mask_bool is not None:
                    col_mask = mask_bool[:, col_idx]  # (B,)
                    if not col_mask.any():
                        continue  # Skip unmasked columns
                    # Only include masked rows for this column
                    pred = F.normalize(column_predictions[col_mask, col_idx], dim=1, eps=1e-8)
                    target = F.normalize(column_targets[col_mask, col_idx], dim=1, eps=1e-8)
                    batch_size = pred.shape[0]
                    if batch_size < 2:
                        continue  # Need at least 2 samples for InfoNCE
                else:
                    pred = F.normalize(column_predictions[:, col_idx], dim=1, eps=1e-8)
                    target = F.normalize(column_targets[:, col_idx], dim=1, eps=1e-8)
                    batch_size = B

                sim_matrix = pred @ target.T / self.temperature
                targets = torch.arange(batch_size, device=device)
                col_loss = F.cross_entropy(sim_matrix, targets)
                total_loss += col_loss
                n_computed += 1
            if n_computed > 0:
                total_loss = total_loss / n_computed
            else:
                total_loss = torch.tensor(0.0, device=device, requires_grad=True)

            metrics = {
                "loss": total_loss.item() if isinstance(total_loss, torch.Tensor) else total_loss,
                "n_columns": n_computed,
                "n_masked_positions": n_masked,
                "mode": "infonce",
            }
        else:
            # Same-row cosine similarity (more learnable)
            # Normalize both predictions and targets
            pred_norm = F.normalize(column_predictions, dim=-1, eps=1e-8)  # (B, n_cols, D)
            target_norm = F.normalize(column_targets, dim=-1, eps=1e-8)  # (B, n_cols, D)

            # Compute same-row cosine similarity for each (row, col) pair
            # This is element-wise dot product along D dimension, then sum
            cosine_sim = (pred_norm * target_norm).sum(dim=-1)  # (B, n_cols)

            # Loss = 1 - cosine_similarity (0 when perfectly aligned)
            loss_per_position = 1.0 - cosine_sim  # (B, n_cols)

            # CRITICAL: Only average over MASKED positions
            if mask_bool is not None:
                # Mask out unmasked positions (set to 0) then compute mean over masked only
                masked_loss = loss_per_position * mask_bool.float()  # Zero out unmasked
                total_loss = masked_loss.sum() / n_masked  # Mean over masked positions only

                # Compute metrics only on masked positions
                masked_cosine = cosine_sim[mask_bool]  # (n_masked,)
                mean_cosine = masked_cosine.mean().item() if len(masked_cosine) > 0 else 0.0
                min_cosine = masked_cosine.min().item() if len(masked_cosine) > 0 else 0.0
                max_cosine = masked_cosine.max().item() if len(masked_cosine) > 0 else 0.0
            else:
                # No mask - average over all positions (backward compat)
                total_loss = loss_per_position.mean()
                mean_cosine = cosine_sim.mean().item()
                min_cosine = cosine_sim.min().item()
                max_cosine = cosine_sim.max().item()

            metrics = {
                "loss": total_loss.item(),
                "n_columns": n_cols,
                "n_masked_positions": n_masked,
                "mode": "cosine",
                "mean_cosine_sim": mean_cosine,
                "min_cosine_sim": min_cosine,
                "max_cosine_sim": max_cosine,
            }

        return total_loss, metrics


# =============================================================================
# Per-Column Diversity Loss (anti-collapse for individual columns)
# =============================================================================

class PerColumnDiversityLoss(LossComponent):
    """
    Penalizes columns whose embeddings collapse to identical vectors.

    Problem: Scalar columns can collapse to constant embeddings while the model
    achieves low contrastive loss by relying on string/set columns. The global
    diversity penalty operates on joint embeddings and can't detect per-column collapse.

    Solution: For each column, compute average pairwise cosine similarity across
    the batch. High similarity = collapse = penalty.

    Loss = mean_over_columns( mean_pairwise_cosine_similarity_per_column^2 )

    The squared penalty penalizes high self-similarity more aggressively.
    """

    def __init__(self, config: LossConfig):
        super().__init__("per_column_diversity", config)
        # Sample columns for efficiency (None = all columns)
        self.max_columns_to_sample = config.params.get("max_columns_to_sample", None)
        # Minimum batch size to compute (need multiple rows for pairwise)
        self.min_batch_size = config.params.get("min_batch_size", 4)

        # Collapse margin: columns with self-sim above this get penalized
        # Using -log(1 - sim + eps) which has steep gradient near sim=1.0
        self.collapse_margin = config.params.get("collapse_margin", 0.5)

        # Adaptive weight parameters
        # When mean_self_sim exceeds threshold, weight scales up
        self.adaptive_threshold = config.params.get("adaptive_threshold", 0.5)  # Start scaling when mean_sim > 0.5
        self.adaptive_max_multiplier = config.params.get("adaptive_max_multiplier", 5.0)  # Max 5x weight

        # Track state for logging intervention events
        self._log_count = 0
        self._last_multiplier = 1.0
        self._intervention_active = False

    def compute(
        self,
        embeddings_1: torch.Tensor,
        embeddings_2: torch.Tensor,
        embeddings_unmasked: torch.Tensor,
        column_targets: Optional[torch.Tensor] = None,
        column_mask: Optional[torch.Tensor] = None,
        **kwargs
    ) -> Tuple[torch.Tensor, Dict[str, float]]:
        """
        Compute per-column diversity penalty.

        Args:
            column_targets: (B, n_cols, D) column encoder outputs
            column_mask: (B, n_cols) TokenStatus mask (NOT_PRESENT, OK, MARGINAL)
        """
        device = embeddings_unmasked.device

        if column_targets is None:
            return torch.tensor(0.0, device=device), {"skipped": True, "reason": "no column_targets"}

        B, n_cols, D = column_targets.shape

        if B < self.min_batch_size:
            return torch.tensor(0.0, device=device), {"skipped": True, "reason": f"batch_size={B} < {self.min_batch_size}"}

        # Normalize embeddings for cosine similarity
        col_emb = F.normalize(column_targets, dim=-1, eps=1e-8)  # (B, n_cols, D)

        # Optionally sample columns for efficiency
        col_indices = list(range(n_cols))
        if self.max_columns_to_sample and n_cols > self.max_columns_to_sample:
            import random
            col_indices = random.sample(col_indices, self.max_columns_to_sample)

        per_col_self_sims = []
        collapsed_count = 0
        low_diversity_count = 0

        for c in col_indices:
            # Get embeddings for column c across batch: (B, D)
            emb_c = col_emb[:, c, :]

            # Filter to rows where this column is present (not NULL)
            if column_mask is not None:
                present = (column_mask[:, c] != TokenStatus.NOT_PRESENT.value)
                if hasattr(present, 'item') and present.sum().item() < 2:
                    continue
                emb_c = emb_c[present]

            if emb_c.shape[0] < 2:
                continue  # Need at least 2 rows for pairwise

            # Compute pairwise similarity matrix: (B', B')
            sim_matrix = emb_c @ emb_c.T

            # Off-diagonal mean = batch self-similarity (collapse indicator)
            B_present = emb_c.shape[0]
            off_diag_mask = ~torch.eye(B_present, dtype=torch.bool, device=device)
            col_self_sim = sim_matrix[off_diag_mask].mean()

            per_col_self_sims.append(col_self_sim)

            # Track collapse statistics
            if col_self_sim.item() > 0.99:
                collapsed_count += 1
            elif col_self_sim.item() > 0.95:
                low_diversity_count += 1

        if not per_col_self_sims:
            return torch.tensor(0.0, device=device), {"skipped": True, "reason": "no columns evaluated"}

        # Stack all per-column self-similarities
        per_col_tensor = torch.stack(per_col_self_sims)

        n_evaluated = len(per_col_self_sims)
        mean_self_sim = per_col_tensor.mean().item()
        max_self_sim = per_col_tensor.max().item()
        min_self_sim = per_col_tensor.min().item()

        # COLLAPSE-FOCUSED MARGIN LOSS
        # Piecewise: -log(1-sim) below cap, linear extension above cap.
        #   sim=0.5 → loss=0.69,  grad=2.0
        #   sim=0.9 → loss=2.30,  grad=10.0
        #   sim=0.95 → loss=3.00, grad=20.0  (cap boundary)
        #   sim=0.99 → loss=3.80, grad=20.0  (linear, capped)
        #   sim=1.0  → loss=4.00, grad=20.0  (linear, capped)
        # The linear extension above cap=0.95 keeps the gradient bounded
        # at 20.0, preventing bf16 gradient overflow during backward while
        # still providing 10x stronger signal than the old sim^2 approach.
        above_margin_mask = per_col_tensor > self.collapse_margin
        n_penalized = above_margin_mask.sum().item()
        above_margin = per_col_tensor[above_margin_mask]
        if above_margin.numel() > 0:
            # Cast to float32 for numerically safe computation
            # (bf16 rounds 0.999 to 1.0, causing inf in log).
            above_margin_f32 = above_margin.float()
            # Piecewise function with bounded gradient:
            # Below cap: -log(1 - sim) — steep, natural pressure
            # Above cap: -log(1 - cap) + slope * (sim - cap) — linear, bounded grad
            grad_cap = 0.95
            slope = 1.0 / (1.0 - grad_cap)  # = 20.0, continuous at boundary
            log_part = -torch.log(1.0 - torch.clamp(above_margin_f32, max=grad_cap))
            linear_part = slope * torch.clamp(above_margin_f32 - grad_cap, min=0.0)
            diversity_penalty = (log_part + linear_part).mean()
        else:
            diversity_penalty = torch.tensor(0.0, device=device)

        # =================================================================
        # ADAPTIVE WEIGHT: Scale up penalty when collapse is detected
        # =================================================================
        # When mean_self_sim exceeds threshold, linearly scale weight up to max_multiplier
        # Formula: multiplier = 1 + (max_mult - 1) * (mean_sim - threshold) / (1 - threshold)
        #   mean_sim=threshold → multiplier=1.0
        #   mean_sim=1.0       → multiplier=max_multiplier
        if mean_self_sim > self.adaptive_threshold:
            scale_factor = (mean_self_sim - self.adaptive_threshold) / (1.0 - self.adaptive_threshold + 1e-8)
            adaptive_multiplier = 1.0 + (self.adaptive_max_multiplier - 1.0) * scale_factor
        else:
            adaptive_multiplier = 1.0

        # Apply adaptive multiplier to the loss (will be further multiplied by base weight in framework)
        diversity_penalty = diversity_penalty * adaptive_multiplier

        # =================================================================
        # LOG INTERVENTION EVENTS for training timeline
        # =================================================================
        self._log_count += 1
        intervention_started = adaptive_multiplier > 1.5 and not self._intervention_active
        intervention_ended = adaptive_multiplier < 1.2 and self._intervention_active

        if intervention_started:
            self._intervention_active = True
            log = get_adaptive_event_log()
            log.emit_simple(
                variable="per_column_diversity_multiplier",
                old_value=self._last_multiplier,
                new_value=adaptive_multiplier,
                epoch=self._current_epoch,
                step=self._call_count,
                controller_name="PerColumnDiversityLoss",
                reason_code=ReasonCode.COLUMN_COLLAPSE,
                trigger_metric="mean_self_sim",
                trigger_value=mean_self_sim,
                expected_effect=ExpectedEffect.INCREASE_DIVERSITY,
                notes=f"Intervention started: {collapsed_count}/{n_evaluated} cols collapsed",
                force=True,
            )
            logger.warning(
                f"⚠️  [TRAINING EVENT] Per-column diversity INTERVENTION STARTED: "
                f"mean_sim={mean_self_sim:.4f} > threshold={self.adaptive_threshold}, "
                f"weight_multiplier={adaptive_multiplier:.2f}x, "
                f"collapsed_cols={collapsed_count}/{n_evaluated}"
            )
        elif intervention_ended:
            self._intervention_active = False
            log = get_adaptive_event_log()
            log.emit_simple(
                variable="per_column_diversity_multiplier",
                old_value=self._last_multiplier,
                new_value=adaptive_multiplier,
                epoch=self._current_epoch,
                step=self._call_count,
                controller_name="PerColumnDiversityLoss",
                reason_code=ReasonCode.COLUMN_COLLAPSE_RECOVERY,
                trigger_metric="mean_self_sim",
                trigger_value=mean_self_sim,
                expected_effect=ExpectedEffect.DECREASE_REGULARIZATION,
                notes=f"Intervention resolved: mean_sim={mean_self_sim:.4f}",
                force=True,
            )
            logger.info(
                f"✅ [TRAINING EVENT] Per-column diversity intervention RESOLVED: "
                f"mean_sim={mean_self_sim:.4f}, weight_multiplier={adaptive_multiplier:.2f}x"
            )

        # Log significant changes in multiplier (>20% change)
        if abs(adaptive_multiplier - self._last_multiplier) > 0.2 * self._last_multiplier:
            log = get_adaptive_event_log()
            log.emit_simple(
                variable="per_column_diversity_multiplier",
                old_value=self._last_multiplier,
                new_value=adaptive_multiplier,
                epoch=self._current_epoch,
                step=self._call_count,
                controller_name="PerColumnDiversityLoss",
                reason_code=ReasonCode.COLUMN_COLLAPSE if adaptive_multiplier > self._last_multiplier else ReasonCode.COLUMN_COLLAPSE_RECOVERY,
                trigger_metric="mean_self_sim",
                trigger_value=mean_self_sim,
                expected_effect=ExpectedEffect.INCREASE_DIVERSITY if adaptive_multiplier > self._last_multiplier else ExpectedEffect.DECREASE_REGULARIZATION,
                notes=f"{self._last_multiplier:.2f}x→{adaptive_multiplier:.2f}x, collapsed={collapsed_count}",
            )
            if adaptive_multiplier > self._last_multiplier:
                logger.warning(
                    f"📈 [TRAINING EVENT] Per-column diversity weight INCREASED: "
                    f"{self._last_multiplier:.2f}x → {adaptive_multiplier:.2f}x "
                    f"(mean_sim={mean_self_sim:.4f}, collapsed={collapsed_count})"
                )
            else:
                logger.info(
                    f"📉 [TRAINING EVENT] Per-column diversity weight DECREASED: "
                    f"{self._last_multiplier:.2f}x → {adaptive_multiplier:.2f}x "
                    f"(mean_sim={mean_self_sim:.4f})"
                )
            self._last_multiplier = adaptive_multiplier

        # Regular periodic logging
        if self._log_count <= 5 or self._log_count % 100 == 0:
            logger.info(
                f"📊 PerColumnDiversity: {n_evaluated}/{n_cols} cols, "
                f"mean_sim={mean_self_sim:.4f}, max={max_self_sim:.4f}, "
                f"penalized={int(n_penalized)}, collapsed={collapsed_count}, "
                f"adaptive_mult={adaptive_multiplier:.2f}x"
            )

        metrics = {
            "loss": diversity_penalty.item(),
            "n_cols_evaluated": n_evaluated,
            "n_cols_total": n_cols,
            "mean_self_sim": mean_self_sim,
            "max_self_sim": max_self_sim,
            "min_self_sim": min_self_sim,
            "n_penalized": int(n_penalized),
            "collapsed_cols": collapsed_count,
            "low_diversity_cols": low_diversity_count,
            "adaptive_multiplier": adaptive_multiplier,
            "intervention_active": self._intervention_active,
        }

        return diversity_penalty, metrics


# =============================================================================
# Neighbor Preservation Loss (MI-weighted k-NN structure preservation)
# =============================================================================

class NeighborPreservationLoss(LossComponent):
    """
    Soft loss to preserve k-NN structure from raw features in embedding space.

    For each row in batch:
    - Find its precomputed raw-space neighbors (using MI-weighted distance)
    - Pull embedding closer to those neighbors (if similarity < margin)

    Uses column importance (from marginal loss) to weight what "similar" means.
    Neighbors are recomputed periodically as column importance evolves.

    This addresses the problem that embeddings don't naturally preserve raw-data
    similarity structure. The contrastive loss ensures same-row consistency across
    masks, but doesn't encourage similar rows to embed nearby.

    Key design choices:
    - Uses embeddings_unmasked (full context) for neighbor comparison
    - Batch-local comparison (sparse but cheap, all neighbors seen over training)
    - Soft margin loss (not forcing exact distances, just "close enough")
    - Low weight (regularizer, not primary loss)
    - Delayed start (wait for col_marginal_losses to be meaningful)
    """

    def __init__(self, config: LossConfig):
        super().__init__("neighbor_preservation", config)
        self.margin = config.params.get("margin", 0.3)
        self.k = config.params.get("k", 10)
        self.start_epoch = config.params.get("start_epoch", 10)

        # Repulsion for non-neighbors to maintain cluster boundaries
        self.repulsion_weight = config.params.get("repulsion_weight", 0.5)  # Relative to attraction
        self.repulsion_threshold = config.params.get("repulsion_threshold", 0.7)  # Push apart if sim > this

        # Cohesion-aware dynamics: adapt forces based on local neighborhood state
        # - Points with low cohesion (intermixed with non-neighbors) get STRONGER attraction
        # - Points with high cohesion (already in tight cluster) get WEAKER attraction
        # - Repulsion scales up for cohesive clusters to protect boundaries
        self.cohesion_aware = config.params.get("cohesion_aware", False)
        self.cohesion_attraction_decay = config.params.get("cohesion_attraction_decay", 0.8)  # attraction *= (1 - decay * cohesion)
        self.cohesion_repulsion_boost = config.params.get("cohesion_repulsion_boost", 2.0)  # repulsion *= (1 + boost * cohesion)

        # Centroid attraction: pull toward neighborhood centroid, not individual neighbors
        # Strength scales with how cohesive the neighborhood is (tight cluster = stronger gravity well)
        self.centroid_attraction = config.params.get("centroid_attraction", False)
        self.centroid_weight = config.params.get("centroid_weight", 0.5)  # Relative to pairwise attraction

        # State set externally by training loop
        self._neighbor_indices: Optional[torch.Tensor] = None  # (N, k) k-NN indices
        self._current_epoch: int = 0
        self._call_count: int = 0
        self._log_count: int = 0

        logger.info(
            f"📊 NeighborPreservationLoss initialized: k={self.k}, margin={self.margin}, "
            f"start_epoch={self.start_epoch}, weight={self.weight}, "
            f"repulsion_weight={self.repulsion_weight}, repulsion_threshold={self.repulsion_threshold}, "
            f"cohesion_aware={self.cohesion_aware}"
        )

    def set_neighbor_indices(self, indices: torch.Tensor):
        """
        Called by training loop with precomputed k-NN indices.

        Args:
            indices: (N, k) tensor of neighbor indices for each row in dataset
        """
        self._neighbor_indices = indices
        if self._log_count < 3:
            logger.info(f"📊 NeighborPreservationLoss: received neighbor indices shape {indices.shape}")

    def set_epoch(self, epoch: int, total_epochs: int = None):
        """Called by training loop at start of each epoch."""
        self._current_epoch = epoch
        if total_epochs is not None:
            self._total_epochs = total_epochs

    def compute(
        self,
        embeddings_1: torch.Tensor,
        embeddings_2: torch.Tensor,
        embeddings_unmasked: torch.Tensor,
        batch_indices: Optional[torch.Tensor] = None,
        **kwargs
    ) -> Tuple[torch.Tensor, Dict[str, Any]]:
        """
        Compute neighbor preservation loss.

        Uses embeddings_unmasked (full context embedding) for neighbor comparison.
        Only compares to neighbors that happen to be in the current batch.

        Args:
            embeddings_1: View 1 embeddings (not used)
            embeddings_2: View 2 embeddings (not used)
            embeddings_unmasked: Full context embeddings (B, d_model)
            batch_indices: Indices of rows in this batch within full dataset (B,)

        Returns:
            loss: Scalar loss tensor
            metrics: Dict with diagnostic info
        """
        self._call_count += 1
        self._log_count += 1
        device = embeddings_unmasked.device

        # Don't apply until col_marginal_losses are meaningful
        if self._current_epoch < self.start_epoch:
            return torch.tensor(0.0, device=device, requires_grad=False), {
                "skipped": True,
                "reason": f"epoch {self._current_epoch} < start_epoch {self.start_epoch}",
                "n_pairs_in_batch": 0,
            }

        if self._neighbor_indices is None:
            return torch.tensor(0.0, device=device, requires_grad=False), {
                "skipped": True,
                "reason": "no neighbor indices set",
                "n_pairs_in_batch": 0,
            }

        if batch_indices is None:
            return torch.tensor(0.0, device=device, requires_grad=False), {
                "skipped": True,
                "reason": "no batch_indices provided",
                "n_pairs_in_batch": 0,
            }

        B = embeddings_unmasked.shape[0]

        # Normalize for cosine similarity
        emb_norm = F.normalize(embeddings_unmasked, dim=-1)

        # Pairwise similarity within batch
        sim_matrix = emb_norm @ emb_norm.T  # (B, B)

        # Get neighbor indices for this batch
        # _neighbor_indices is (N, k) for full dataset
        # batch_indices tells us which rows are in this batch
        batch_indices_cpu = batch_indices.cpu()

        # Clamp batch indices to valid range for neighbor lookup
        max_idx = self._neighbor_indices.shape[0] - 1
        batch_indices_clamped = torch.clamp(batch_indices_cpu, 0, max_idx)
        batch_neighbors = self._neighbor_indices[batch_indices_clamped]  # (B, k)

        # Build mapping from global index to local batch index
        batch_set = set(batch_indices_cpu.tolist())
        batch_idx_to_local = {idx: i for i, idx in enumerate(batch_indices_cpu.tolist())}

        # For each row, check if its neighbors are in the current batch
        # and compute attraction loss
        losses = []
        neighbor_sims = []
        n_pairs = 0
        n_violations = 0

        # Per-point cohesion: mean similarity among this point's neighbors
        # Used for cohesion-aware dynamics (optional)
        point_cohesions = []

        for i in range(B):
            row_neighbors = batch_neighbors[i].tolist()

            # Find neighbors that are in current batch
            local_neighbor_indices = []
            for neighbor_idx in row_neighbors:
                if neighbor_idx in batch_idx_to_local and neighbor_idx != batch_indices_cpu[i].item():
                    local_neighbor_indices.append(batch_idx_to_local[neighbor_idx])

            if local_neighbor_indices:
                # Get similarities to neighbors
                local_indices_tensor = torch.tensor(local_neighbor_indices, device=device)
                sims = sim_matrix[i, local_indices_tensor]
                neighbor_sims.extend(sims.detach().cpu().tolist())

                # Compute cohesion: mean pairwise similarity among neighbors in batch
                if self.cohesion_aware and len(local_neighbor_indices) >= 2:
                    neighbor_pairs_sims = []
                    for ni in range(len(local_neighbor_indices)):
                        for nj in range(ni + 1, len(local_neighbor_indices)):
                            neighbor_pairs_sims.append(
                                sim_matrix[local_neighbor_indices[ni], local_neighbor_indices[nj]].item()
                            )
                    cohesion = np.mean(neighbor_pairs_sims) if neighbor_pairs_sims else 0.0
                    cohesion = max(0.0, min(1.0, cohesion))  # clamp to [0, 1]
                else:
                    cohesion = 0.0
                point_cohesions.append(cohesion)

                # Cohesion-aware attraction: reduce if already cohesive
                if self.cohesion_aware:
                    attraction_scale = 1.0 - self.cohesion_attraction_decay * cohesion
                    attraction_scale = max(0.1, attraction_scale)  # floor at 0.1
                else:
                    attraction_scale = 1.0

                # Hinge loss: penalize if similarity < margin
                violations = F.relu(self.margin - sims)
                n_violations += (violations > 0).sum().item()
                losses.append(attraction_scale * violations.sum())
                n_pairs += len(local_neighbor_indices)

        if n_pairs > 0 and losses:
            attraction_loss = sum(losses) / n_pairs
        else:
            attraction_loss = torch.tensor(0.0, device=device, requires_grad=False)

        mean_neighbor_sim = float(np.mean(neighbor_sims)) if neighbor_sims else 0.0
        mean_cohesion = float(np.mean(point_cohesions)) if point_cohesions else 0.0
        violation_rate = n_violations / max(n_pairs, 1)

        # Centroid attraction: pull points toward centroid of their neighbors
        # Stronger pull for cohesive neighborhoods (the "gravity well" effect)
        centroid_loss = torch.tensor(0.0, device=device, requires_grad=False)
        n_centroid_points = 0

        if self.centroid_attraction:
            centroid_losses = []
            for i in range(B):
                row_neighbors = batch_neighbors[i].tolist()

                # Find neighbors that are in current batch
                local_neighbor_indices = []
                for neighbor_idx in row_neighbors:
                    if neighbor_idx in batch_idx_to_local and neighbor_idx != batch_indices_cpu[i].item():
                        local_neighbor_indices.append(batch_idx_to_local[neighbor_idx])

                if len(local_neighbor_indices) >= 2:
                    # Compute centroid of neighbors (in normalized embedding space)
                    neighbor_embs = emb_norm[local_neighbor_indices]  # (n_neighbors, d)
                    centroid = neighbor_embs.mean(dim=0)  # (d,)
                    centroid = F.normalize(centroid, dim=0)  # re-normalize

                    # Point's similarity to centroid
                    sim_to_centroid = (emb_norm[i] * centroid).sum()

                    # Cohesion of the neighborhood (mean pairwise sim among neighbors)
                    if self.cohesion_aware and len(local_neighbor_indices) >= 2:
                        idx = point_cohesions[n_centroid_points] if n_centroid_points < len(point_cohesions) else 0.0
                        cohesion = idx
                    else:
                        # Compute cohesion here if not already done
                        neighbor_sim_matrix = neighbor_embs @ neighbor_embs.T
                        # Upper triangle excluding diagonal
                        mask = torch.triu(torch.ones_like(neighbor_sim_matrix, dtype=torch.bool), diagonal=1)
                        cohesion = neighbor_sim_matrix[mask].mean().item() if mask.sum() > 0 else 0.0
                        cohesion = max(0.0, min(1.0, cohesion))

                    # Gravity well: cohesive clusters pull harder
                    # But point only gets pulled if it's NOT already at the centroid
                    centroid_pull_strength = 1.0 + self.cohesion_repulsion_boost * cohesion

                    # Loss: penalize if point is far from centroid
                    # (1 - sim) gives distance-like measure
                    centroid_loss_i = centroid_pull_strength * F.relu(self.margin - sim_to_centroid)
                    centroid_losses.append(centroid_loss_i)
                    n_centroid_points += 1

            if centroid_losses:
                centroid_loss = sum(centroid_losses) / len(centroid_losses)

            # Add centroid loss to attraction
            attraction_loss = attraction_loss + self.centroid_weight * centroid_loss

        # Repulsion loss for non-neighbors: push apart if too similar
        repulsion_loss = torch.tensor(0.0, device=device, requires_grad=False)
        n_repulsion_pairs = 0
        n_repulsion_violations = 0
        non_neighbor_sims = []

        if self.repulsion_weight > 0:
            # Build set of all neighbor pairs in batch for exclusion
            all_neighbor_pairs = set()
            for i in range(B):
                row_neighbors = batch_neighbors[i].tolist()
                for neighbor_idx in row_neighbors:
                    if neighbor_idx in batch_idx_to_local:
                        local_j = batch_idx_to_local[neighbor_idx]
                        all_neighbor_pairs.add((i, local_j))
                        all_neighbor_pairs.add((local_j, i))  # Symmetric

            # Cohesion-aware repulsion: boost if local neighborhood is cohesive
            if self.cohesion_aware:
                repulsion_scale = 1.0 + self.cohesion_repulsion_boost * mean_cohesion
            else:
                repulsion_scale = 1.0

            # For non-neighbors, apply repulsion if similarity is too high
            repulsion_losses = []
            for i in range(B):
                for j in range(i + 1, B):
                    if (i, j) not in all_neighbor_pairs:
                        sim = sim_matrix[i, j]
                        non_neighbor_sims.append(sim.detach().cpu().item())
                        n_repulsion_pairs += 1

                        # Hinge: penalize if sim > threshold (too close)
                        repulsion = F.relu(sim - self.repulsion_threshold)
                        if repulsion > 0:
                            n_repulsion_violations += 1
                            repulsion_losses.append(repulsion_scale * repulsion)

            if repulsion_losses:
                repulsion_loss = sum(repulsion_losses) / len(repulsion_losses)

        # Combined loss
        loss = attraction_loss + self.repulsion_weight * repulsion_loss

        mean_non_neighbor_sim = float(np.mean(non_neighbor_sims)) if non_neighbor_sims else 0.0

        # Periodic logging
        if self._log_count <= 5 or self._log_count % 200 == 0:
            cohesion_str = f", cohesion={mean_cohesion:.4f}" if self.cohesion_aware else ""
            logger.info(
                f"📊 NeighborPreservation [e={self._current_epoch}]: "
                f"attract: pairs={n_pairs}, mean_sim={mean_neighbor_sim:.4f}, violations={n_violations}, "
                f"repel: pairs={n_repulsion_pairs}, mean_sim={mean_non_neighbor_sim:.4f}, violations={n_repulsion_violations}, "
                f"loss={loss.item():.6f} (attract={attraction_loss.item():.6f}, repel={repulsion_loss.item():.6f}){cohesion_str}"
            )

        metrics = {
            "n_pairs_in_batch": n_pairs,
            "mean_neighbor_sim": mean_neighbor_sim,
            "n_violations": n_violations,
            "violation_rate": violation_rate,
            "margin": self.margin,
            "n_repulsion_pairs": n_repulsion_pairs,
            "mean_non_neighbor_sim": mean_non_neighbor_sim,
            "n_repulsion_violations": n_repulsion_violations,
            "attraction_loss": attraction_loss.item() if isinstance(attraction_loss, torch.Tensor) else attraction_loss,
            "repulsion_loss": repulsion_loss.item() if isinstance(repulsion_loss, torch.Tensor) else repulsion_loss,
            "mean_cohesion": mean_cohesion,
            "skipped": False,
        }

        return loss, metrics


# =============================================================================
# Reconstruction Loss (for scalars)
# =============================================================================

class ReconstructionLoss(LossComponent):
    """
    MSE reconstruction loss for scalar columns.

    Ensures embeddings can decode back to original values.
    """

    def __init__(self, config: LossConfig):
        super().__init__("reconstruction", config)

    def compute(
        self,
        embeddings_1: torch.Tensor,
        embeddings_2: torch.Tensor,
        embeddings_unmasked: torch.Tensor,
        decoded_values: Optional[torch.Tensor] = None,
        target_values: Optional[torch.Tensor] = None,
        **kwargs
    ) -> Tuple[torch.Tensor, Dict[str, float]]:
        """MSE between decoded and target values."""
        device = embeddings_unmasked.device

        if decoded_values is None or target_values is None:
            return torch.tensor(0.0, device=device), {"skipped": True}

        loss = F.mse_loss(decoded_values, target_values)

        metrics = {
            "loss": loss.item(),
            "mae": (decoded_values - target_values).abs().mean().item(),
        }

        return loss, metrics


# =============================================================================
# Coverage Loss (128D) - Hypersphere coverage using cosine similarity repulsion
# =============================================================================

class CoverageLoss(LossComponent):
    """
    Coverage loss for full d_model embeddings (e.g., 128D) on unit sphere.

    Uses COSINE SIMILARITY based repulsion - penalizes high similarity between
    different embeddings, pushing them apart on the sphere surface.

    For unit vectors: cos_sim = dot(a, b), and we want this to be low (near 0)
    for different samples, meaning they're spread across the sphere.
    """

    def __init__(self, config: LossConfig):
        super().__init__("coverage", config)
        self.temperature = config.params.get("temperature", 2.0)

    def compute(
        self,
        embeddings_1: torch.Tensor,
        embeddings_2: torch.Tensor,
        embeddings_unmasked: torch.Tensor,
        **kwargs
    ) -> Tuple[torch.Tensor, Dict[str, float]]:
        """Compute coverage loss using log-sum-exp of pairwise cosine similarities."""
        device = embeddings_unmasked.device
        B, d = embeddings_unmasked.shape

        if B < 2:
            return torch.tensor(0.0, device=device), {"n_samples": B, "d_model": d}

        # Normalize (should already be, but be safe)
        emb = F.normalize(embeddings_unmasked, dim=1, eps=1e-8)

        # Pairwise cosine similarity (for unit vectors, this is just dot product)
        cos_sim = emb @ emb.T  # (B, B), values in [-1, 1]

        # Mask out diagonal (self-similarity = 1.0)
        mask = ~torch.eye(B, dtype=torch.bool, device=device)
        cos_sim_offdiag = cos_sim[mask].view(B, B - 1)

        # Log-sum-exp of similarities - penalizes HIGH similarity (close points)
        loss = torch.logsumexp(cos_sim_offdiag / self.temperature, dim=1).mean()

        # Metrics
        with torch.no_grad():
            mean_cos_sim = cos_sim_offdiag.mean().item()
            max_cos_sim = cos_sim_offdiag.max().item()
            min_cos_sim = cos_sim_offdiag.min().item()

            # Bounding box diagonal (for comparison with old metric)
            min_coords = emb.min(dim=0).values
            max_coords = emb.max(dim=0).values
            dimensions = max_coords - min_coords
            box_diagonal = torch.sqrt((dimensions ** 2).sum()).item()
            max_diagonal = 2.0 * (d ** 0.5)  # Max possible on unit sphere
            diagonal_ratio = box_diagonal / max_diagonal

        metrics = {
            "loss": loss.item(),
            "n_samples": B,
            "d_model": d,
            "mean_cos_sim": mean_cos_sim,
            "max_cos_sim": max_cos_sim,
            "min_cos_sim": min_cos_sim,
            "box_diagonal": box_diagonal,
            "diagonal_ratio": diagonal_ratio,
        }

        return loss, metrics


# =============================================================================
# VICReg Column Variance Loss - Per-column variance enforcement
# =============================================================================

class ColumnVarianceLoss(LossComponent):
    """
    VICReg-style variance loss applied per column.

    For each column's embeddings across the batch, enforces that each dimension
    has sufficient variance (std >= target_std). This prevents column encoders
    from collapsing to constant outputs.
    """

    def __init__(self, config: LossConfig):
        super().__init__("column_variance", config)
        self.target_std = config.params.get("target_std", 0.5)
        self.gamma = config.params.get("gamma", 1.0)  # VICReg gamma parameter

    def compute(
        self,
        embeddings_1: torch.Tensor,
        embeddings_2: torch.Tensor,
        embeddings_unmasked: torch.Tensor,
        column_encodings: Optional[torch.Tensor] = None,
        **kwargs
    ) -> Tuple[torch.Tensor, Dict[str, float]]:
        """
        Compute per-column variance loss.

        Args:
            column_encodings: (B, n_cols, d_model) tensor of per-column embeddings
        """
        device = embeddings_unmasked.device

        if column_encodings is None:
            return torch.tensor(0.0, device=device), {"skipped": True}

        B, n_cols, d_model = column_encodings.shape

        if B < 2:
            return torch.tensor(0.0, device=device), {"n_samples": B, "n_cols": n_cols}

        # Compute per-column variance penalties
        col_var_penalties = []
        col_stds = []

        for col_idx in range(n_cols):
            col_emb = column_encodings[:, col_idx, :]  # (B, d_model)
            # Per-dimension std across batch
            std_per_dim = col_emb.std(dim=0)  # (d_model,)
            # Penalize dimensions below target
            std_deficit = torch.clamp(self.target_std - std_per_dim, min=0.0)
            penalty = (std_deficit ** 2).mean()
            col_var_penalties.append(penalty)
            col_stds.append(std_per_dim.mean().item())

        if not col_var_penalties:
            return torch.tensor(0.0, device=device), {"n_cols": n_cols, "skipped": True}

        loss = self.gamma * torch.stack(col_var_penalties).mean()

        metrics = {
            "loss": loss.item(),
            "n_cols": n_cols,
            "mean_col_std": sum(col_stds) / len(col_stds) if col_stds else 0.0,
            "min_col_std": min(col_stds) if col_stds else 0.0,
            "max_col_std": max(col_stds) if col_stds else 0.0,
            "target_std": self.target_std,
        }

        return loss, metrics


# =============================================================================
# VICReg Column Covariance Loss - Decorrelation across dimensions
# =============================================================================

class ColumnCovarianceLoss(LossComponent):
    """
    VICReg-style covariance loss applied per column.

    For each column's embeddings, decorrelates the dimensions by penalizing
    off-diagonal elements of the covariance matrix. This ensures the embedding
    dimensions capture independent features.
    """

    def __init__(self, config: LossConfig):
        super().__init__("column_covariance", config)

    def compute(
        self,
        embeddings_1: torch.Tensor,
        embeddings_2: torch.Tensor,
        embeddings_unmasked: torch.Tensor,
        column_encodings: Optional[torch.Tensor] = None,
        **kwargs
    ) -> Tuple[torch.Tensor, Dict[str, float]]:
        """
        Compute per-column covariance loss.

        Args:
            column_encodings: (B, n_cols, d_model) tensor of per-column embeddings
        """
        device = embeddings_unmasked.device

        if column_encodings is None:
            return torch.tensor(0.0, device=device), {"skipped": True}

        B, n_cols, d_model = column_encodings.shape

        if B < 2:
            return torch.tensor(0.0, device=device), {"n_samples": B, "n_cols": n_cols}

        # Compute per-column covariance penalties
        col_cov_penalties = []
        col_offdiag_means = []

        for col_idx in range(n_cols):
            col_emb = column_encodings[:, col_idx, :]  # (B, d_model)
            # Center the embeddings
            col_emb_centered = col_emb - col_emb.mean(dim=0, keepdim=True)
            # Covariance matrix
            cov = (col_emb_centered.T @ col_emb_centered) / (B - 1)  # (d_model, d_model)
            # Off-diagonal penalty (decorrelation)
            off_diag_mask = ~torch.eye(d_model, dtype=torch.bool, device=device)
            off_diag = cov[off_diag_mask]
            penalty = (off_diag ** 2).mean()
            col_cov_penalties.append(penalty)
            col_offdiag_means.append(off_diag.abs().mean().item())

        if not col_cov_penalties:
            return torch.tensor(0.0, device=device), {"n_cols": n_cols, "skipped": True}

        loss = torch.stack(col_cov_penalties).mean()

        metrics = {
            "loss": loss.item(),
            "n_cols": n_cols,
            "mean_offdiag_cov": sum(col_offdiag_means) / len(col_offdiag_means) if col_offdiag_means else 0.0,
        }

        return loss, metrics


# =============================================================================
# Entropy Regularization Loss - Sharper encoder strategy selection
# =============================================================================

class EntropyRegularizationLoss(LossComponent):
    """
    Entropy regularization for adaptive encoder strategies.

    Encourages sharper strategy selection by penalizing high entropy
    in the strategy distribution. This helps encoders commit to a
    single strategy rather than blending.
    """

    def __init__(self, config: LossConfig):
        super().__init__("entropy_regularization", config)

    def compute(
        self,
        embeddings_1: torch.Tensor,
        embeddings_2: torch.Tensor,
        embeddings_unmasked: torch.Tensor,
        entropy_losses: Optional[List[torch.Tensor]] = None,
        **kwargs
    ) -> Tuple[torch.Tensor, Dict[str, float]]:
        """
        Aggregate entropy losses from adaptive encoders.

        Args:
            entropy_losses: List of entropy loss tensors from adaptive encoders
        """
        device = embeddings_unmasked.device

        if entropy_losses is None or len(entropy_losses) == 0:
            return torch.tensor(0.0, device=device), {"n_encoders": 0, "skipped": True}

        # Sum all entropy losses
        loss = sum(entropy_losses)

        metrics = {
            "loss": loss.item(),
            "n_encoders": len(entropy_losses),
        }

        return loss, metrics


# =============================================================================
# Short Embedding Loss - Combined 3D anti-collapse losses
# =============================================================================

class ShortEmbeddingLoss(LossComponent):
    """
    Combined loss for short (3D) embeddings to prevent collapse.

    Wraps the compute_combined_short_embedding_loss function which includes:
    - Uniformity loss (log-sum-exp)
    - Diversity loss (per-dimension std)
    - Repulsion loss (pairwise)
    - Spread loss (bounding box)
    - Octant coverage loss
    """

    def __init__(self, config: LossConfig):
        super().__init__("short_embedding", config)
        # Config passed to compute_combined_short_embedding_loss
        self.loss_config = config.params.get("loss_config", None)

    def compute(
        self,
        embeddings_1: torch.Tensor,
        embeddings_2: torch.Tensor,
        embeddings_unmasked: torch.Tensor,
        **kwargs
    ) -> Tuple[torch.Tensor, Dict[str, float]]:
        """Compute combined short embedding loss."""
        from featrix.neural.loss_short_embedding import compute_combined_short_embedding_loss

        device = embeddings_unmasked.device
        B = embeddings_unmasked.shape[0]

        if B < 2:
            return torch.tensor(0.0, device=device), {"n_samples": B}

        # Use unmasked embeddings for short embedding loss
        loss, metrics = compute_combined_short_embedding_loss(
            embeddings_unmasked,
            config=self.loss_config,
        )

        # Flatten nested metrics for logging
        flat_metrics = {"loss": loss.item(), "n_samples": B}
        for key, val in metrics.items():
            if isinstance(val, dict):
                for subkey, subval in val.items():
                    if isinstance(subval, (int, float)):
                        flat_metrics[f"{key}_{subkey}"] = subval
            elif isinstance(val, (int, float)):
                flat_metrics[key] = val

        return loss, flat_metrics


# =============================================================================
# Short Uniformity Loss - 3D sphere uniformity (legacy)
# =============================================================================

class ShortUniformityLoss(LossComponent):
    """
    Log-sum-exp uniformity loss for 3D short embeddings.

    This is the legacy uniformity loss that was used before the combined
    short_embedding_loss was introduced. Kept for backwards compatibility.
    """

    def __init__(self, config: LossConfig):
        super().__init__("short_uniformity", config)
        self.temperature = config.params.get("temperature", 2.0)

    def compute(
        self,
        embeddings_1: torch.Tensor,
        embeddings_2: torch.Tensor,
        embeddings_unmasked: torch.Tensor,
        **kwargs
    ) -> Tuple[torch.Tensor, Dict[str, float]]:
        """Compute uniformity loss for short embeddings."""
        device = embeddings_unmasked.device
        B = embeddings_unmasked.shape[0]

        if B < 2:
            return torch.tensor(0.0, device=device), {"n_samples": B}

        # Normalize
        short_emb = F.normalize(embeddings_unmasked, dim=1, eps=1e-8)

        # Pairwise squared distances (for unit vectors: 2 - 2*cos_sim)
        pairwise_sim = short_emb @ short_emb.T
        pairwise_dist_sq = 2.0 - 2.0 * pairwise_sim

        # Mask out diagonal
        mask = ~torch.eye(B, dtype=torch.bool, device=device)
        pairwise_dist_sq_offdiag = pairwise_dist_sq[mask].view(B, B - 1)

        # Log-sum-exp
        loss = torch.logsumexp(-self.temperature * pairwise_dist_sq_offdiag, dim=1).mean()

        metrics = {
            "loss": loss.item(),
            "n_samples": B,
            "mean_dist_sq": pairwise_dist_sq_offdiag.mean().item(),
            "min_dist_sq": pairwise_dist_sq_offdiag.min().item(),
        }

        return loss, metrics


# =============================================================================
# Loss Framework - Orchestrates all losses
# =============================================================================

@dataclass
class FrameworkConfig:
    """Configuration for the entire loss framework."""
    losses: Dict[str, LossConfig] = field(default_factory=dict)
    log_every_n_batches: int = 1  # Log every batch for diagnostics

    @classmethod
    def default(cls) -> "FrameworkConfig":
        """
        Default config matching v1 loss computation.

        All losses that were active in v1 are included with their original weights.
        """
        return cls(
            losses={
                # Re-enabled contrastive but we pass RAW embeddings (not predictor output)
                # in compute_total_loss_v2. The contrastive task should be: masked embedding
                # should be more similar to its own unmasked embedding than to other rows.
                "contrastive": LossConfig(enabled=True, weight=1.0, params={"temperature": 0.1}),
                # Column prediction (marginal loss) - predict original column embeddings
                # This is like BERT's MLM: predict masked tokens from context
                "column_prediction": LossConfig(enabled=True, weight=0.1, params={"temperature": 0.1}),
                "reconstruction": LossConfig(enabled=True, weight=0.05),
                # SPREAD: ENABLED - Original working spread loss (cross-entropy self-similarity)
                # This was used when AUC was 0.78+. Provides strong repulsion.
                # Temperature 0.2 matches legacy compute_spread_loss (base_temp=0.2)
                "spread": LossConfig(enabled=True, weight=1.0, params={"temperature": 0.2}),
                # Separation loss: penalizes high off-diagonal pairwise similarity (anti-collapse)
                # Enabled by default - captures distribution stats for visualization
                "separation": LossConfig(enabled=True, weight=1.0),
                "uniformity": LossConfig(enabled=False, weight=0.3, params={"temperature": 2.0}),
                "diversity": LossConfig(enabled=False, weight=1.0),
                # Per-column diversity: prevents individual column encoders from collapsing
                # Enabled by default to prevent scalar columns from outputting identical embeddings
                # Uses adaptive weighting: base weight * (1-5x) depending on detected collapse
                "per_column_diversity": LossConfig(enabled=True, weight=0.2),
                # Halfspace coverage: prevents hemisphere clustering by checking random hyperplane splits
                # Sparse loss - only fires when a halfspace is empty/underpopulated
                # n_splits=16 random directions, resampled every 50 batches for stochastic coverage
                "halfspace_coverage": LossConfig(enabled=True, weight=0.3, params={
                    "n_splits": 16, "min_count_target": 1, "resample_every": 50,
                }),
                # Neighbor preservation: preserves k-NN structure from raw features in embedding space
                # Uses MI-weighted distance to define "similar" based on column importance
                # Disabled by default - experimental feature, enable via config.json
                "neighbor_preservation": LossConfig(enabled=False, weight=0.1, params={
                    "k": 10, "margin": 0.3, "start_epoch": 10,
                }),
                # Coverage loss (128D): hypersphere coverage using cosine repulsion
                # Weight matches v1: coverage_weight = 1.0
                "coverage": LossConfig(enabled=True, weight=1.0, params={"temperature": 2.0}),
                # VICReg column variance: per-column std enforcement
                # Weight matches v1: column_variance_weight = 0.5
                "column_variance": LossConfig(enabled=True, weight=0.5, params={"target_std": 0.5}),
                # VICReg column covariance: dimension decorrelation
                # Weight matches v1: column_covariance_weight = 0.1
                "column_covariance": LossConfig(enabled=True, weight=0.1),
                # Entropy regularization: sharper encoder strategy selection
                # Weight matches v1: entropy_weight = 0.01
                "entropy_regularization": LossConfig(enabled=True, weight=0.01),
            }
        )

    @classmethod
    def minimal(cls) -> "FrameworkConfig":
        """Minimal config - just contrastive + column prediction."""
        return cls(
            losses={
                "contrastive": LossConfig(enabled=True, weight=1.0, params={"temperature": 0.1}),
                "column_prediction": LossConfig(enabled=True, weight=0.01, params={"temperature": 0.1}),
            }
        )


class LossFramework:
    """
    Orchestrates all loss components.

    Usage:
        framework = LossFramework(FrameworkConfig.default())
        total_loss, metrics = framework.compute_total(
            embeddings_1=view1,
            embeddings_2=view2,
            embeddings_unmasked=full_view,
        )
    """

    # Registry of available loss types
    LOSS_TYPES = {
        "contrastive": ContrastiveLoss,
        "separation": SeparationLoss,
        "uniformity": UniformityLoss,
        "spread": SpreadLoss,  # Original working spread loss (cross-entropy self-similarity)
        "diversity": DiversityLoss,
        "halfspace_coverage": HalfspaceCoverageLoss,  # Random hyperplane coverage (prevents hemisphere clustering)
        "column_prediction": ColumnPredictionLoss,
        "per_column_diversity": PerColumnDiversityLoss,  # Per-column collapse prevention
        "neighbor_preservation": NeighborPreservationLoss,  # MI-weighted k-NN structure preservation
        "reconstruction": ReconstructionLoss,
        # New losses (migrated from v1 hardcoded)
        "coverage": CoverageLoss,  # 128D hypersphere coverage
        "column_variance": ColumnVarianceLoss,  # VICReg per-column variance
        "column_covariance": ColumnCovarianceLoss,  # VICReg per-column covariance
        "entropy_regularization": EntropyRegularizationLoss,  # Encoder entropy
        "short_embedding": ShortEmbeddingLoss,  # Combined 3D anti-collapse
        "short_uniformity": ShortUniformityLoss,  # 3D uniformity (legacy)
    }

    def __init__(self, config: FrameworkConfig):
        self.config = config
        self.components: Dict[str, LossComponent] = {}
        self._batch_count = 0

        # Instantiate configured losses
        for name, loss_config in config.losses.items():
            if name in self.LOSS_TYPES:
                self.components[name] = self.LOSS_TYPES[name](loss_config)
            else:
                logger.warning(f"Unknown loss type: {name}")

        # Log configuration
        self._log_config()

    def _log_config(self):
        """Log the active configuration."""
        logger.info("=" * 60)
        logger.info("LOSS FRAMEWORK CONFIGURATION")
        logger.info("=" * 60)

        enabled = []
        disabled = []

        for name, comp in self.components.items():
            if comp.enabled:
                enabled.append(f"  ✓ {name}: weight={comp.weight}")
            else:
                disabled.append(f"  ✗ {name}: DISABLED")

        logger.info("ENABLED losses:")
        for line in enabled:
            logger.info(line)

        if disabled:
            logger.info("DISABLED losses:")
            for line in disabled:
                logger.info(line)

        logger.info("=" * 60)

    def compute_total(
        self,
        embeddings_1: torch.Tensor,
        embeddings_2: torch.Tensor,
        embeddings_unmasked: torch.Tensor,
        **kwargs
    ) -> Tuple[torch.Tensor, Dict[str, Any]]:
        """
        Compute total loss from all enabled components.

        Returns:
            total_loss: Weighted sum of all enabled losses
            metrics: Dict with per-component metrics and totals
        """
        device = embeddings_1.device
        all_metrics = {
            "total": 0.0,
            "components": {},
        }

        # Collect losses in a list, then sum at the end
        # This ensures proper gradient flow (not broken by torch.tensor(0.0))
        losses_to_sum = []

        for name, comp in self.components.items():
            if not comp.enabled:
                continue

            try:
                loss, metrics = comp(
                    embeddings_1=embeddings_1,
                    embeddings_2=embeddings_2,
                    embeddings_unmasked=embeddings_unmasked,
                    **kwargs
                )

                weighted_loss = comp.weight * loss
                losses_to_sum.append(weighted_loss)

                all_metrics["components"][name] = {
                    "loss": loss.item() if isinstance(loss, torch.Tensor) else loss,
                    "weighted_loss": weighted_loss.item() if isinstance(weighted_loss, torch.Tensor) else weighted_loss,
                    "weight": comp.weight,
                    **metrics
                }

            except Exception as e:
                logger.warning(f"Loss component {name} failed: {e}")
                all_metrics["components"][name] = {"error": str(e)}

        # Sum all losses - this maintains proper gradient flow
        if losses_to_sum:
            total_loss = sum(losses_to_sum)
        else:
            total_loss = torch.tensor(0.0, device=device, requires_grad=False)

        all_metrics["total"] = total_loss.item() if isinstance(total_loss, torch.Tensor) else total_loss

        # Periodic logging
        self._batch_count += 1
        if self._batch_count % self.config.log_every_n_batches == 0:
            self._log_batch_metrics(all_metrics)

        return total_loss, all_metrics

    def _log_batch_metrics(self, metrics: Dict[str, Any]):
        """Log metrics for this batch."""
        parts = [f"LOSS total={metrics['total']:.4f}"]
        for name, comp_metrics in metrics["components"].items():
            if "error" not in comp_metrics:
                parts.append(f"{name}={comp_metrics['weighted_loss']:.4f}")
        logger.info(" | ".join(parts))

        # Log contrastive diagnostics if available
        # CONTRASTIVE (masked→unmasked): Row-level contrastive loss
        # - Embeddings: masked view (emb1/emb2) vs unmasked view (emb_unmasked)
        # - Positives: same row (masked and unmasked are different views of the same row)
        # - Negatives: all other rows in the batch (cross-row comparisons)
        # - R@1 measures: can we match a masked embedding back to its unmasked source?
        contrastive = metrics["components"].get("contrastive", {})
        if contrastive and "pos_sim" in contrastive:
            mode = contrastive.get("mode", "unknown")
            acc = contrastive.get('accuracy', 0.0)
            pos_sim = contrastive['pos_sim']
            neg_sim = contrastive['neg_sim']
            separation = pos_sim - neg_sim
            # Compute ×random multiplier to contextualize the percentage
            bs = contrastive.get('batch_size', 256)
            random_acc = 1.0 / bs if bs > 0 else 0.004
            acc_vs_random = acc / random_acc if random_acc > 0 else 0
            logger.info(
                f"  📊 Contrastive (masked→unmasked) [{mode}]: R@1={acc:.1%} (×{acc_vs_random:.1f} random) "
                f"pos={pos_sim:.3f} neg={neg_sim:.3f} sep={separation:.3f} "
                f"loss={contrastive['loss']:.3f}"
            )

        # Log column prediction diagnostics
        col_pred = metrics["components"].get("column_prediction", {})
        if col_pred and "mean_cosine_sim" in col_pred:
            n_masked = col_pred.get('n_masked_positions', 'N/A')
            logger.info(
                f"  📊 ColPred [{col_pred.get('mode', 'unknown')}]: "
                f"mean_cosine={col_pred['mean_cosine_sim']:.3f} "
                f"n_masked={n_masked} "
                f"loss={col_pred['loss']:.3f}"
            )

    def enable(self, name: str):
        """Enable a loss component."""
        if name in self.components:
            self.components[name].config.enabled = True
            logger.info(f"Enabled loss: {name}")

    def disable(self, name: str):
        """Disable a loss component."""
        if name in self.components:
            self.components[name].config.enabled = False
            logger.info(f"Disabled loss: {name}")

    def set_weight(self, name: str, weight: float):
        """Set weight for a loss component."""
        if name in self.components:
            self.components[name].config.weight = weight
            logger.info(f"Set {name} weight to {weight}")

    def set_epoch(self, epoch: int, total_epochs: int):
        """
        Update curriculum-aware loss components for the current epoch.

        Components like ContrastiveLoss use this to blend cosine→InfoNCE.
        NeighborPreservationLoss uses this to know when to start.
        """
        for name, comp in self.components.items():
            if hasattr(comp, 'set_epoch'):
                comp.set_epoch(epoch, total_epochs)

    def set_neighbor_indices(self, indices: torch.Tensor):
        """
        Set neighbor indices for NeighborPreservationLoss.

        Called by the training loop after cohesion tracker updates k-NN.

        Args:
            indices: (n_samples, k) tensor of neighbor indices
        """
        if "neighbor_preservation" in self.components:
            comp = self.components["neighbor_preservation"]
            if hasattr(comp, 'set_neighbor_indices'):
                comp.set_neighbor_indices(indices)

    def get_summary(self) -> str:
        """Get a string summary of the framework configuration."""
        lines = ["Loss Framework Summary:"]
        for name, comp in self.components.items():
            status = "ON" if comp.enabled else "OFF"
            lines.append(f"  {name}: {status} (weight={comp.weight})")
        return "\n".join(lines)


# =============================================================================
# Dual Embedding Framework (128D + 3D)
# =============================================================================

@dataclass
class DualFrameworkConfig:
    """Configuration for dual (128D + 3D) loss framework."""
    full_config: FrameworkConfig = field(default_factory=FrameworkConfig.default)
    short_config: FrameworkConfig = field(default_factory=FrameworkConfig.default)
    short_weight: float = 1.0  # Weight for 3D loss relative to 128D
    log_every_n_batches: int = 50

    @classmethod
    def default(cls) -> "DualFrameworkConfig":
        """
        Default config matching v1 loss computation.

        Full (128D) uses all standard losses.
        Short (3D) uses contrastive + spread + short-specific losses.
        """
        return cls(
            full_config=FrameworkConfig.default(),
            short_config=FrameworkConfig(
                losses={
                    # For 3D: contrastive + spread (same as full, but 3D is more constrained)
                    "contrastive": LossConfig(enabled=True, weight=1.0, params={"temperature": 0.07, "event_prefix": "3D"}),  # Sharper temperature for 3D
                    "spread": LossConfig(enabled=True, weight=1.0, params={"temperature": 0.03}),  # Original spread loss
                    "separation": LossConfig(enabled=True, weight=0.5),  # Extra repulsion for 3D
                    # Short uniformity loss: 3D sphere uniformity (legacy)
                    # Weight matches v1: short_uniformity_weight = 2.0
                    "short_uniformity": LossConfig(enabled=True, weight=2.0, params={"temperature": 2.0}),
                    # Short embedding loss: combined 3D anti-collapse (uniformity + diversity + repulsion + spread + octant)
                    # Weight matches v1: short_embedding_loss_weight = 1.0
                    "short_embedding": LossConfig(enabled=True, weight=1.0),
                }
            ),
            short_weight=0.1,  # Reduced from 1.0 - 3D spread was dominating total loss
        )

    @classmethod
    def minimal(cls) -> "DualFrameworkConfig":
        """Minimal: just contrastive for both."""
        contrastive_only = FrameworkConfig(
            losses={
                "contrastive": LossConfig(enabled=True, weight=1.0, params={"temperature": 0.1}),
            }
        )
        return cls(
            full_config=contrastive_only,
            short_config=contrastive_only,
            short_weight=1.0,
        )


class DualEmbeddingLossFramework:
    """
    Handles both 128D (full) and 3D (short) embeddings.

    Runs the loss framework twice - once for each embedding type.
    This allows different configurations for each if needed.

    Usage:
        framework = DualEmbeddingLossFramework(DualFrameworkConfig.default())
        total_loss, metrics = framework.compute_total(
            full_embeddings_1=full_view1,
            full_embeddings_2=full_view2,
            full_embeddings_unmasked=full_unmasked,
            short_embeddings_1=short_view1,
            short_embeddings_2=short_view2,
            short_embeddings_unmasked=short_unmasked,
        )
    """

    def __init__(self, config: DualFrameworkConfig):
        self.config = config
        self.full_framework = LossFramework(config.full_config)
        self.short_framework = LossFramework(config.short_config)
        self._batch_count = 0

        logger.info("=" * 60)
        logger.info("DUAL EMBEDDING LOSS FRAMEWORK")
        logger.info(f"  Short (3D) weight: {config.short_weight}")
        logger.info("=" * 60)

    def compute_total(
        self,
        full_embeddings_1: torch.Tensor,
        full_embeddings_2: torch.Tensor,
        full_embeddings_unmasked: torch.Tensor,
        short_embeddings_1: torch.Tensor,
        short_embeddings_2: torch.Tensor,
        short_embeddings_unmasked: torch.Tensor,
        **kwargs
    ) -> Tuple[torch.Tensor, Dict[str, Any]]:
        """
        Compute total loss for both 128D and 3D embeddings.

        Returns:
            total_loss: full_loss + short_weight * short_loss
            metrics: Dict with metrics for both embedding types
        """
        # Compute 128D loss
        full_loss, full_metrics = self.full_framework.compute_total(
            embeddings_1=full_embeddings_1,
            embeddings_2=full_embeddings_2,
            embeddings_unmasked=full_embeddings_unmasked,
            **kwargs
        )

        # Compute 3D loss
        short_loss, short_metrics = self.short_framework.compute_total(
            embeddings_1=short_embeddings_1,
            embeddings_2=short_embeddings_2,
            embeddings_unmasked=short_embeddings_unmasked,
            # Don't pass column_predictions etc to short - not applicable
        )

        # Combine
        total_loss = full_loss + self.config.short_weight * short_loss

        metrics = {
            "total": total_loss.item(),
            "full": full_metrics,
            "short": short_metrics,
            "full_loss": full_loss.item(),
            "short_loss": short_loss.item(),
        }

        # Periodic logging
        self._batch_count += 1
        if self._batch_count % self.config.log_every_n_batches == 0:
            self._log_batch_metrics(metrics)

        return total_loss, metrics

    def set_epoch(self, epoch: int, total_epochs: int):
        """
        Update curriculum-aware loss components for the current epoch.

        Propagates to both full (128D) and short (3D) frameworks.
        """
        self.full_framework.set_epoch(epoch, total_epochs)
        self.short_framework.set_epoch(epoch, total_epochs)

    def set_neighbor_indices(self, indices: torch.Tensor):
        """
        Set neighbor indices for NeighborPreservationLoss.

        Only propagates to full framework (neighbor preservation is 256D only).

        Args:
            indices: (n_samples, k) tensor of neighbor indices
        """
        self.full_framework.set_neighbor_indices(indices)

    def _log_batch_metrics(self, metrics: Dict[str, Any]):
        """Log combined metrics."""
        full_total = metrics["full"]["total"]
        short_total = metrics["short"]["total"]

        # Build component summary for full
        full_parts = []
        for name, comp_metrics in metrics["full"]["components"].items():
            if "error" not in comp_metrics and "weighted_loss" in comp_metrics:
                full_parts.append(f"{name}={comp_metrics['weighted_loss']:.3f}")

        # Build component summary for short
        short_parts = []
        for name, comp_metrics in metrics["short"]["components"].items():
            if "error" not in comp_metrics and "weighted_loss" in comp_metrics:
                short_parts.append(f"{name}={comp_metrics['weighted_loss']:.3f}")

        logger.info(
            f"📊 LOSS total={metrics['total']:.3f} | "
            f"128D={full_total:.3f} [{', '.join(full_parts)}] | "
            f"3D={short_total:.3f} [{', '.join(short_parts)}]"
        )

    def get_summary(self) -> str:
        """Get summary of both frameworks."""
        lines = [
            "Dual Embedding Loss Framework:",
            f"  Short weight: {self.config.short_weight}",
            "",
            "128D (Full) Framework:",
        ]
        for name, comp in self.full_framework.components.items():
            status = "ON" if comp.enabled else "OFF"
            lines.append(f"    {name}: {status} (weight={comp.weight})")

        lines.append("")
        lines.append("3D (Short) Framework:")
        for name, comp in self.short_framework.components.items():
            status = "ON" if comp.enabled else "OFF"
            lines.append(f"    {name}: {status} (weight={comp.weight})")

        return "\n".join(lines)


# =============================================================================
# Convenience functions
# =============================================================================

def create_default_framework() -> LossFramework:
    """Create a framework with sensible defaults."""
    return LossFramework(FrameworkConfig.default())


def create_minimal_framework() -> LossFramework:
    """Create a minimal framework for testing."""
    return LossFramework(FrameworkConfig.minimal())


def create_dual_framework() -> DualEmbeddingLossFramework:
    """Create dual framework with sensible defaults."""
    return DualEmbeddingLossFramework(DualFrameworkConfig.default())


def create_framework_from_dict(config_dict: Dict[str, Any]) -> LossFramework:
    """
    Create a framework from a dictionary config.

    Example:
        config = {
            "contrastive": {"enabled": True, "weight": 1.0, "temperature": 0.1},
            "separation": {"enabled": False},
        }
        framework = create_framework_from_dict(config)
    """
    losses = {}
    for name, params in config_dict.items():
        if isinstance(params, dict):
            params = params.copy()  # Don't mutate original
            enabled = params.pop("enabled", True)
            weight = params.pop("weight", 1.0)
            losses[name] = LossConfig(enabled=enabled, weight=weight, params=params)

    return LossFramework(FrameworkConfig(losses=losses))
