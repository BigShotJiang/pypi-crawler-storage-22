#!/usr/bin/env python3
"""
Assemble Training Animation Frames

This script assembles per-epoch PNG frames from the media/ directory
into animated GIFs or MP4 videos showing how metrics evolve during training.

Animations created:
- media/lift_heatmap/*.png -> lift_heatmap_animated.gif
- media/embedding_similarity/*.png -> embedding_similarity_animated.gif

Usage:
    python assemble_training_animations.py <output_dir> [--format gif|mp4] [--fps 5]

    output_dir: The ES training output directory containing media/ subdirectory
"""
import argparse
import os
import re
from pathlib import Path
from typing import List, Optional, Tuple
import logging

logging.basicConfig(level=logging.INFO, format='%(message)s')
logger = logging.getLogger(__name__)


def find_frame_files(media_subdir: Path) -> List[Tuple[int, Path]]:
    """
    Find all PNG frames in a media subdirectory, sorted by epoch number.

    Returns list of (epoch_number, file_path) tuples.
    """
    frames = []
    if not media_subdir.exists():
        return frames

    # Pattern: *_epoch_NNNN.png
    pattern = re.compile(r'_epoch_(\d+)\.png$')

    for png_file in media_subdir.glob('*.png'):
        match = pattern.search(png_file.name)
        if match:
            epoch = int(match.group(1))
            frames.append((epoch, png_file))

    # Sort by epoch number
    frames.sort(key=lambda x: x[0])
    return frames


def create_gif(frames: List[Tuple[int, Path]], output_path: Path, fps: int = 5, loop: int = 0):
    """
    Create an animated GIF from frame images.

    Args:
        frames: List of (epoch, path) tuples
        output_path: Output GIF path
        fps: Frames per second
        loop: Number of loops (0 = infinite)
    """
    try:
        from PIL import Image
    except ImportError:
        logger.error("PIL/Pillow not installed. Run: pip install Pillow")
        return False

    if not frames:
        logger.warning(f"No frames to assemble for {output_path}")
        return False

    logger.info(f"Assembling {len(frames)} frames into {output_path}")

    # Load all frames
    images = []
    for epoch, path in frames:
        img = Image.open(path)
        images.append(img)

    # Calculate duration per frame in milliseconds
    duration = int(1000 / fps)

    # Save as GIF
    images[0].save(
        output_path,
        save_all=True,
        append_images=images[1:],
        duration=duration,
        loop=loop,
        optimize=True
    )

    logger.info(f"Created {output_path} ({len(frames)} frames, {fps} fps)")
    return True


def create_mp4(frames: List[Tuple[int, Path]], output_path: Path, fps: int = 5):
    """
    Create an MP4 video from frame images.

    Requires ffmpeg to be installed.

    Args:
        frames: List of (epoch, path) tuples
        output_path: Output MP4 path
        fps: Frames per second
    """
    import subprocess
    import tempfile
    import shutil

    if not frames:
        logger.warning(f"No frames to assemble for {output_path}")
        return False

    # Check if ffmpeg is available
    if shutil.which('ffmpeg') is None:
        logger.error("ffmpeg not found. Install ffmpeg to create MP4 videos.")
        return False

    logger.info(f"Assembling {len(frames)} frames into {output_path}")

    # Create a temporary directory with symlinks numbered sequentially
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)

        # Create sequentially numbered symlinks
        for i, (epoch, path) in enumerate(frames):
            link_path = tmpdir / f"frame_{i:05d}.png"
            link_path.symlink_to(path.absolute())

        # Run ffmpeg
        cmd = [
            'ffmpeg', '-y',  # Overwrite output
            '-framerate', str(fps),
            '-i', str(tmpdir / 'frame_%05d.png'),
            '-c:v', 'libx264',
            '-pix_fmt', 'yuv420p',
            '-crf', '23',  # Quality (lower = better, 18-28 is reasonable)
            str(output_path)
        ]

        try:
            subprocess.run(cmd, check=True, capture_output=True)
            logger.info(f"Created {output_path} ({len(frames)} frames, {fps} fps)")
            return True
        except subprocess.CalledProcessError as e:
            logger.error(f"ffmpeg failed: {e.stderr.decode()}")
            return False


def assemble_animations(
    output_dir: str,
    format: str = 'gif',
    fps: int = 5,
) -> dict:
    """
    Assemble all available animation frames in an output directory.

    Args:
        output_dir: ES training output directory
        format: 'gif' or 'mp4'
        fps: Frames per second

    Returns:
        Dict of animation_name -> output_path (or None if failed)
    """
    output_dir = Path(output_dir)
    media_dir = output_dir / 'media'

    results = {}

    # Animation configurations: (subdir_name, output_filename)
    # All spatial visualizations that save per-epoch frames
    animations = [
        ('lift_heatmap', f'lift_heatmap_animated.{format}'),
        ('embedding_similarity', f'embedding_similarity_animated.{format}'),
        ('column_embedding_pca', f'column_embedding_pca_animated.{format}'),
        ('column_loss_landscape', f'column_loss_landscape_animated.{format}'),
        ('relationship_graph', f'relationship_graph_animated.{format}'),
        ('gradient_flow', f'gradient_flow_animated.{format}'),
        ('attention_flow', f'attention_flow_animated.{format}'),
        ('prediction_confidence', f'prediction_confidence_animated.{format}'),
        ('cluster_cohesion', f'cluster_cohesion_animated.{format}'),
    ]

    create_func = create_gif if format == 'gif' else create_mp4

    for subdir_name, output_filename in animations:
        subdir = media_dir / subdir_name
        frames = find_frame_files(subdir)

        if frames:
            output_path = output_dir / output_filename
            success = create_func(frames, output_path, fps=fps)
            results[subdir_name] = str(output_path) if success else None
        else:
            logger.info(f"No frames found in {subdir}")
            results[subdir_name] = None

    return results


def print_summary(output_dir: str):
    """Print a summary of available frames in the output directory."""
    output_dir = Path(output_dir)
    media_dir = output_dir / 'media'

    print(f"\nAnimation Frames Summary for: {output_dir}")
    print("=" * 60)

    if not media_dir.exists():
        print("No media/ directory found.")
        return

    for subdir in sorted(media_dir.iterdir()):
        if subdir.is_dir():
            frames = find_frame_files(subdir)
            if frames:
                epochs = [e for e, _ in frames]
                print(f"\n{subdir.name}/")
                print(f"  Frames: {len(frames)}")
                print(f"  Epochs: {min(epochs)} - {max(epochs)}")
            else:
                print(f"\n{subdir.name}/")
                print(f"  No frames found")


def main():
    parser = argparse.ArgumentParser(
        description="Assemble training animation frames into GIF or MP4"
    )
    parser.add_argument("output_dir", help="ES training output directory")
    parser.add_argument(
        "--format", "-f",
        choices=['gif', 'mp4'],
        default='gif',
        help="Output format (default: gif)"
    )
    parser.add_argument(
        "--fps",
        type=int,
        default=5,
        help="Frames per second (default: 5)"
    )
    parser.add_argument(
        "--summary", "-s",
        action="store_true",
        help="Just print summary of available frames"
    )

    args = parser.parse_args()

    if args.summary:
        print_summary(args.output_dir)
        return

    results = assemble_animations(
        output_dir=args.output_dir,
        format=args.format,
        fps=args.fps,
    )

    print("\nResults:")
    for name, path in results.items():
        if path:
            print(f"  {name}: {path}")
        else:
            print(f"  {name}: (no frames or failed)")


if __name__ == "__main__":
    main()
