#!/usr/bin/env python3
"""
Visualize Lift Waves - Relationship Evolution During Training

This script reads lift_waves JSON data and creates a sparkline visualization
showing how each relationship's lift evolves over training epochs.

Each row is a relationship, each row contains a mini line graph (sparkline)
showing the lift trajectory. Relationships are sorted by importance.

The visualization reveals:
- When relationships peak (fast learners vs slow burners)
- Buildup patterns (steep vs gradual rise to peak)
- Rolloff patterns (sharp drop vs sustained plateau)
- "Waves" of relationships emerging at different times

Usage:
    python visualize_lift_waves.py <path_to_lift_waves.json> [--output output.png]
    python visualize_lift_waves.py <path_to_lift_waves.json> --html output.html
"""
import json
import sys
import argparse
from pathlib import Path
from typing import List, Dict, Any, Optional

try:
    import matplotlib.pyplot as plt
    import matplotlib.patches as mpatches
    from matplotlib.collections import LineCollection
    import numpy as np
    HAS_MATPLOTLIB = True
except ImportError:
    HAS_MATPLOTLIB = False


def load_wave_data(path: str) -> Dict[str, Any]:
    """Load the lift waves JSON file."""
    with open(path, 'r') as f:
        return json.load(f)


def normalize_timeline(timeline: List[Dict], global_min: float, global_max: float) -> List[float]:
    """Normalize lift values to 0-1 range using global min/max."""
    if global_max == global_min:
        return [0.5] * len(timeline)
    return [(t['lift'] - global_min) / (global_max - global_min) for t in timeline]


def render_text_sparkline(values: List[float], width: int = 40) -> str:
    """Render a simple ASCII sparkline."""
    if not values:
        return "-" * width

    # Resample to width
    n = len(values)
    if n > width:
        # Downsample
        indices = [int(i * n / width) for i in range(width)]
        values = [values[i] for i in indices]
    elif n < width:
        # Pad with last value
        values = values + [values[-1]] * (width - n)

    # Use block characters for height
    blocks = " ▁▂▃▄▅▆▇█"
    sparkline = ""
    for v in values:
        idx = int(v * (len(blocks) - 1))
        idx = max(0, min(len(blocks) - 1, idx))
        sparkline += blocks[idx]

    return sparkline


def print_text_summary(data: Dict[str, Any], max_relationships: int = 30):
    """Print a text-based visualization of lift waves."""
    relationships = data['relationships'][:max_relationships]
    metadata = data['metadata']

    if not relationships:
        print("No relationship data found.")
        return

    # Find global min/max for normalization
    all_lifts = []
    for rel in relationships:
        for t in rel['timeline']:
            all_lifts.append(t['lift'])

    if not all_lifts:
        print("No timeline data found.")
        return

    global_min = min(all_lifts)
    global_max = max(all_lifts)

    print("=" * 100)
    print("LIFT WAVE VISUALIZATION - Relationship Evolution During Training")
    print("=" * 100)
    print(f"Epoch: {metadata['current_epoch']} | Total pairs: {metadata['total_pairs']} | Showing top {len(relationships)}")
    print(f"Lift range: [{global_min:.4f}, {global_max:.4f}]")
    print()

    # Header
    print(f"{'Rank':<5} {'Relationship':<45} {'Peak@':<6} {'Buildup':<9} {'Rolloff':<9} {'Sparkline':<42}")
    print("-" * 120)

    for rel in relationships:
        rank = rel['rank']
        direction = rel['direction']
        # Truncate long names
        if len(direction) > 43:
            direction = direction[:40] + "..."

        peak_epoch = rel['peak_epoch']
        peak_str = str(peak_epoch) if peak_epoch is not None else "-"

        buildup = rel['buildup_slope']
        buildup_str = f"{buildup:+.4f}" if buildup is not None else "-"

        rolloff = rel['rolloff_slope']
        rolloff_str = f"{rolloff:+.4f}" if rolloff is not None else "-"

        # Normalize and render sparkline
        timeline = rel['timeline']
        if timeline:
            normalized = normalize_timeline(timeline, global_min, global_max)
            sparkline = render_text_sparkline(normalized, width=40)
        else:
            sparkline = "-" * 40

        print(f"{rank:<5} {direction:<45} {peak_str:<6} {buildup_str:<9} {rolloff_str:<9} {sparkline}")

    print()
    print("Legend: ▁▂▃▄▅▆▇█ = lift magnitude (normalized)")
    print()


def render_matplotlib_figure(data: Dict[str, Any], output_path: Optional[str] = None, max_relationships: int = 40):
    """Render a matplotlib figure with sparklines."""
    if not HAS_MATPLOTLIB:
        print("matplotlib not available, cannot render figure")
        return

    relationships = data['relationships'][:max_relationships]
    metadata = data['metadata']

    if not relationships:
        print("No relationship data found.")
        return

    # Find global min/max and epoch range
    all_lifts = []
    all_epochs = set()
    for rel in relationships:
        for t in rel['timeline']:
            all_lifts.append(t['lift'])
            all_epochs.add(t['epoch'])

    if not all_lifts:
        print("No timeline data found.")
        return

    global_min = min(all_lifts)
    global_max = max(all_lifts)
    min_epoch = min(all_epochs)
    max_epoch = max(all_epochs)

    # Create figure
    n_rows = len(relationships)
    fig_height = max(8, n_rows * 0.4)
    fig, ax = plt.subplots(figsize=(14, fig_height))

    # Plot each relationship as a sparkline row
    row_height = 1.0

    for idx, rel in enumerate(relationships):
        y_base = n_rows - idx - 1  # Flip so rank 1 is at top

        timeline = rel['timeline']
        if not timeline:
            continue

        # Extract epochs and lifts
        epochs = [t['epoch'] for t in timeline]
        lifts = [t['lift'] for t in timeline]

        # Normalize lifts to fit in row
        if global_max > global_min:
            normalized = [(l - global_min) / (global_max - global_min) for l in lifts]
        else:
            normalized = [0.5] * len(lifts)

        # Scale to row height (leave some margin)
        y_values = [y_base + 0.1 + n * 0.8 for n in normalized]

        # Normalize epochs to x-axis
        if max_epoch > min_epoch:
            x_values = [(e - min_epoch) / (max_epoch - min_epoch) * 10 for e in epochs]
        else:
            x_values = [5] * len(epochs)

        # Plot the sparkline
        # Color based on whether currently rising or falling
        if len(lifts) >= 2:
            if lifts[-1] > lifts[-2]:
                color = '#2ecc71'  # Green - rising
            elif lifts[-1] < lifts[-2]:
                color = '#e74c3c'  # Red - falling
            else:
                color = '#3498db'  # Blue - stable
        else:
            color = '#3498db'

        ax.plot(x_values, y_values, color=color, linewidth=1.5, alpha=0.8)

        # Mark peak with a dot
        peak_epoch = rel['peak_epoch']
        if peak_epoch is not None and peak_epoch in epochs:
            peak_idx = epochs.index(peak_epoch)
            ax.scatter([x_values[peak_idx]], [y_values[peak_idx]],
                      color='gold', s=30, zorder=5, edgecolor='black', linewidth=0.5)

        # Add relationship label on the left
        direction = rel['direction']
        if len(direction) > 35:
            direction = direction[:32] + "..."
        ax.text(-0.5, y_base + 0.5, f"{rel['rank']:2d}. {direction}",
               fontsize=8, va='center', ha='right', fontfamily='monospace')

        # Add slope info on the right
        buildup = rel['buildup_slope']
        rolloff = rel['rolloff_slope']
        slope_text = ""
        if buildup is not None:
            slope_text += f"↑{buildup:+.3f}"
        if rolloff is not None:
            if slope_text:
                slope_text += " "
            slope_text += f"↓{rolloff:+.3f}"
        if slope_text:
            ax.text(10.5, y_base + 0.5, slope_text, fontsize=7, va='center', ha='left', fontfamily='monospace')

    # Configure axes
    ax.set_xlim(-6, 12)
    ax.set_ylim(-0.5, n_rows + 0.5)
    ax.set_xlabel(f"Epoch ({min_epoch} → {max_epoch})", fontsize=10)
    ax.set_title(f"Lift Wave Evolution - Top {n_rows} Relationships (Epoch {metadata['current_epoch']})",
                fontsize=12, fontweight='bold')

    # Remove y-axis ticks (relationships are labeled)
    ax.set_yticks([])
    ax.set_xticks([0, 2.5, 5, 7.5, 10])
    ax.set_xticklabels([str(min_epoch), '', str((min_epoch + max_epoch) // 2), '', str(max_epoch)])

    # Add grid
    ax.axvline(x=0, color='gray', linestyle='-', linewidth=0.5, alpha=0.3)
    ax.axvline(x=10, color='gray', linestyle='-', linewidth=0.5, alpha=0.3)

    # Add legend
    legend_elements = [
        mpatches.Patch(color='#2ecc71', label='Rising'),
        mpatches.Patch(color='#e74c3c', label='Falling'),
        mpatches.Patch(color='#3498db', label='Stable'),
        plt.scatter([], [], color='gold', edgecolor='black', s=30, label='Peak'),
    ]
    ax.legend(handles=legend_elements, loc='upper right', fontsize=8)

    plt.tight_layout()

    if output_path:
        plt.savefig(output_path, dpi=150, bbox_inches='tight')
        print(f"Saved figure to {output_path}")
    else:
        plt.show()

    plt.close()


def render_html(data: Dict[str, Any], output_path: str, max_relationships: int = 50):
    """Render an interactive HTML visualization using inline SVG sparklines."""
    relationships = data['relationships'][:max_relationships]
    metadata = data['metadata']

    if not relationships:
        print("No relationship data found.")
        return

    # Find global min/max and epoch range
    all_lifts = []
    all_epochs = set()
    for rel in relationships:
        for t in rel['timeline']:
            all_lifts.append(t['lift'])
            all_epochs.add(t['epoch'])

    if not all_lifts:
        print("No timeline data found.")
        return

    global_min = min(all_lifts)
    global_max = max(all_lifts)
    min_epoch = min(all_epochs) if all_epochs else 0
    max_epoch = max(all_epochs) if all_epochs else 1

    def make_svg_sparkline(timeline: List[Dict], width: int = 200, height: int = 30) -> str:
        """Generate an SVG sparkline path."""
        if not timeline:
            return f'<svg width="{width}" height="{height}"><text x="50%" y="50%" text-anchor="middle" fill="#999">No data</text></svg>'

        epochs = [t['epoch'] for t in timeline]
        lifts = [t['lift'] for t in timeline]

        # Normalize
        if global_max > global_min:
            normalized = [(l - global_min) / (global_max - global_min) for l in lifts]
        else:
            normalized = [0.5] * len(lifts)

        # Scale to SVG coordinates
        padding = 2
        if max_epoch > min_epoch:
            x_values = [padding + (e - min_epoch) / (max_epoch - min_epoch) * (width - 2 * padding) for e in epochs]
        else:
            x_values = [width / 2] * len(epochs)

        y_values = [padding + (1 - n) * (height - 2 * padding) for n in normalized]  # Flip Y

        # Build path
        path_data = f"M {x_values[0]:.1f},{y_values[0]:.1f}"
        for x, y in zip(x_values[1:], y_values[1:]):
            path_data += f" L {x:.1f},{y:.1f}"

        # Determine color
        if len(lifts) >= 2:
            if lifts[-1] > lifts[-2]:
                color = '#2ecc71'
            elif lifts[-1] < lifts[-2]:
                color = '#e74c3c'
            else:
                color = '#3498db'
        else:
            color = '#3498db'

        svg = f'<svg width="{width}" height="{height}" style="background:#f8f9fa;border-radius:4px;">'
        svg += f'<path d="{path_data}" fill="none" stroke="{color}" stroke-width="2"/>'

        # Add peak marker
        peak_epoch = None
        peak_lift = max(lifts)
        for t in timeline:
            if t['lift'] == peak_lift:
                peak_epoch = t['epoch']
                break

        if peak_epoch is not None and peak_epoch in epochs:
            peak_idx = epochs.index(peak_epoch)
            svg += f'<circle cx="{x_values[peak_idx]:.1f}" cy="{y_values[peak_idx]:.1f}" r="4" fill="gold" stroke="#333" stroke-width="1"/>'

        svg += '</svg>'
        return svg

    # Build HTML
    html = f'''<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Lift Wave Visualization</title>
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            margin: 20px;
            background: #fff;
        }}
        h1 {{
            color: #333;
            border-bottom: 2px solid #3498db;
            padding-bottom: 10px;
        }}
        .metadata {{
            background: #f8f9fa;
            padding: 10px 15px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-size: 14px;
            color: #666;
        }}
        table {{
            border-collapse: collapse;
            width: 100%;
            font-size: 13px;
        }}
        th {{
            background: #34495e;
            color: white;
            padding: 10px 8px;
            text-align: left;
            position: sticky;
            top: 0;
        }}
        td {{
            padding: 8px;
            border-bottom: 1px solid #eee;
            vertical-align: middle;
        }}
        tr:hover {{
            background: #f5f5f5;
        }}
        .rank {{
            font-weight: bold;
            color: #3498db;
            width: 40px;
        }}
        .relationship {{
            font-family: monospace;
            max-width: 300px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }}
        .sparkline {{
            width: 220px;
        }}
        .slope {{
            font-family: monospace;
            font-size: 12px;
        }}
        .slope-up {{
            color: #2ecc71;
        }}
        .slope-down {{
            color: #e74c3c;
        }}
        .legend {{
            display: flex;
            gap: 20px;
            margin: 15px 0;
            font-size: 13px;
        }}
        .legend-item {{
            display: flex;
            align-items: center;
            gap: 5px;
        }}
        .legend-color {{
            width: 20px;
            height: 4px;
            border-radius: 2px;
        }}
        .peak-marker {{
            width: 10px;
            height: 10px;
            background: gold;
            border: 1px solid #333;
            border-radius: 50%;
            display: inline-block;
        }}
    </style>
</head>
<body>
    <h1>Lift Wave Visualization</h1>
    <div class="metadata">
        <strong>Epoch:</strong> {metadata['current_epoch']} |
        <strong>Total pairs:</strong> {metadata['total_pairs']} |
        <strong>Showing:</strong> top {len(relationships)} relationships |
        <strong>Lift range:</strong> [{global_min:.4f}, {global_max:.4f}] |
        <strong>Epoch range:</strong> [{min_epoch}, {max_epoch}]
    </div>
    <div class="legend">
        <div class="legend-item"><div class="legend-color" style="background:#2ecc71"></div> Rising</div>
        <div class="legend-item"><div class="legend-color" style="background:#e74c3c"></div> Falling</div>
        <div class="legend-item"><div class="legend-color" style="background:#3498db"></div> Stable</div>
        <div class="legend-item"><span class="peak-marker"></span> Peak</div>
    </div>
    <table>
        <thead>
            <tr>
                <th>Rank</th>
                <th>Relationship</th>
                <th>Lift Timeline</th>
                <th>Peak@</th>
                <th>Importance</th>
                <th>Buildup</th>
                <th>Rolloff</th>
            </tr>
        </thead>
        <tbody>
'''

    for rel in relationships:
        sparkline_svg = make_svg_sparkline(rel['timeline'])

        peak_str = str(rel['peak_epoch']) if rel['peak_epoch'] is not None else "-"
        importance_str = f"{rel['importance']:.4f}"

        buildup = rel['buildup_slope']
        if buildup is not None:
            buildup_class = "slope-up" if buildup > 0 else "slope-down"
            buildup_str = f'<span class="{buildup_class}">{buildup:+.4f}</span>'
        else:
            buildup_str = "-"

        rolloff = rel['rolloff_slope']
        if rolloff is not None:
            rolloff_class = "slope-up" if rolloff > 0 else "slope-down"
            rolloff_str = f'<span class="{rolloff_class}">{rolloff:+.4f}</span>'
        else:
            rolloff_str = "-"

        html += f'''            <tr>
                <td class="rank">{rel['rank']}</td>
                <td class="relationship" title="{rel['direction']}">{rel['direction']}</td>
                <td class="sparkline">{sparkline_svg}</td>
                <td>{peak_str}</td>
                <td>{importance_str}</td>
                <td class="slope">{buildup_str}</td>
                <td class="slope">{rolloff_str}</td>
            </tr>
'''

    html += '''        </tbody>
    </table>
</body>
</html>
'''

    with open(output_path, 'w') as f:
        f.write(html)

    print(f"Saved HTML visualization to {output_path}")


def main():
    parser = argparse.ArgumentParser(description="Visualize lift wave data from training")
    parser.add_argument("input", help="Path to lift_waves JSON file")
    parser.add_argument("--output", "-o", help="Output file path (PNG or HTML based on extension)")
    parser.add_argument("--html", action="store_true", help="Generate HTML output")
    parser.add_argument("--text", action="store_true", help="Print text-only summary")
    parser.add_argument("--max", "-n", type=int, default=40, help="Maximum relationships to show")

    args = parser.parse_args()

    # Load data
    data = load_wave_data(args.input)

    # Always print text summary
    print_text_summary(data, max_relationships=args.max)

    if args.text:
        return

    # Determine output format
    if args.html or (args.output and args.output.endswith('.html')):
        output_path = args.output or args.input.replace('.json', '.html')
        render_html(data, output_path, max_relationships=args.max)
    elif args.output or HAS_MATPLOTLIB:
        output_path = args.output
        render_matplotlib_figure(data, output_path, max_relationships=args.max)
    else:
        print("\nNote: Install matplotlib to generate graphical output, or use --html for HTML output")


if __name__ == "__main__":
    main()
