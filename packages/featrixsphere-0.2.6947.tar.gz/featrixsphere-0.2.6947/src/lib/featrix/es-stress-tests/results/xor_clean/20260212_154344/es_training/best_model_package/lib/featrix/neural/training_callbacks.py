#!/usr/bin/env python3
#  -*- coding: utf-8 -*-
#
#  Copyright Featrix, Inc 2023-2026
#
#  Training Callbacks Interface
#
#  This module defines the callback interface for server-side integrations
#  (job management, alerting, system health monitoring, etc.) that the
#  neural training code needs. The neural code should NEVER import directly
#  from lib.* modules - instead it uses this interface which can be
#  implemented by the server environment.
#
from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from enum import Enum
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


class JobStatus(Enum):
    """Job status enum - mirrors lib.job_manager.JobStatus."""
    PENDING = "pending"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"


class TrainingCallbacks(ABC):
    """
    Abstract interface for server-side training callbacks.

    The neural training code (EmbeddingSpace, SinglePredictor) uses this
    interface instead of importing directly from lib.* modules. This allows:

    1. The neural code to run standalone (without server infrastructure)
    2. Clean separation between neural algorithms and server concerns
    3. Easier testing with mock callbacks
    4. No pylint import errors from optional server modules

    Server environments should implement this interface and pass it to
    EmbeddingSpace/SinglePredictor constructors.
    """

    # =========================================================================
    # Job Control File Detection
    # =========================================================================

    @abstractmethod
    def find_control_file(self, job_id: str, control_type: str, output_dir: str | Path | None = None) -> str | None:
        """
        Find a control file (ABORT, PAUSE, FINISH, RESTART, etc.) for a job.

        Args:
            job_id: The job ID
            control_type: Type of control file ("ABORT", "PAUSE", "FINISH", etc.)
            output_dir: Optional output directory to check

        Returns:
            Path to control file if found, None otherwise
        """
        pass

    @abstractmethod
    def get_job_output_path(self, job_id: str) -> Path | None:
        """
        Get the output path for a job.

        Args:
            job_id: The job ID

        Returns:
            Path to job output directory, or None if not found
        """
        pass

    # =========================================================================
    # Job Status Updates
    # =========================================================================

    @abstractmethod
    def update_job_status(self, job_id: str, status: JobStatus, extra_data: dict[str, Any] | None = None) -> bool:
        """
        Update the status of a job.

        Args:
            job_id: The job ID
            status: New status
            extra_data: Optional additional data to store

        Returns:
            True if update succeeded, False otherwise
        """
        pass

    # =========================================================================
    # Alerting
    # =========================================================================

    @abstractmethod
    def send_alert(self, message: str, throttle: bool = True, skip_hostname_prefix: bool = False) -> bool:
        """
        Send an alert message (e.g., to Slack).

        Args:
            message: Alert message text
            throttle: Whether to throttle repeated messages
            skip_hostname_prefix: Whether to skip adding hostname prefix

        Returns:
            True if alert was sent, False otherwise
        """
        pass

    # =========================================================================
    # System Health Monitoring
    # =========================================================================

    @abstractmethod
    def find_dataloader_workers(self, parent_pid: int | None = None) -> list[dict[str, Any]]:
        """
        Find existing DataLoader worker processes.

        Args:
            parent_pid: Optional parent PID to filter by

        Returns:
            List of worker info dicts with keys like 'pid', 'rss_gb', etc.
        """
        pass

    @abstractmethod
    def check_system_health(self) -> dict[str, Any]:
        """
        Check overall system health (memory, disk, etc.).

        Returns:
            Dict with health info
        """
        pass

    @abstractmethod
    def check_training_memory_requirements(self, **kwargs) -> dict[str, Any]:
        """
        Check if system has enough memory for training.

        Returns:
            Dict with memory check results
        """
        pass

    @abstractmethod
    def print_oom_recovery_help(self) -> None:
        """Print help message for recovering from OOM errors."""
        pass

    # =========================================================================
    # Utilities
    # =========================================================================

    @abstractmethod
    def atomic_write_json(self, path: str | Path, data: dict[str, Any]) -> bool:
        """
        Atomically write JSON data to a file.

        Args:
            path: Destination path
            data: Data to write

        Returns:
            True if write succeeded, False otherwise
        """
        pass

    @abstractmethod
    def get_version(self) -> str | None:
        """
        Get the current software version.

        Returns:
            Version string, or None if not available
        """
        pass

    @abstractmethod
    def log_training_error(self, error: Exception, context: dict[str, Any] | None = None) -> None:
        """
        Log a training error to the error tracking system.

        Args:
            error: The exception that occurred
            context: Optional context dict with job_id, epoch, etc.
        """
        pass

    # =========================================================================
    # WeightWatcher Integration
    # =========================================================================

    @abstractmethod
    def compute_validation_alpha_score(self, **kwargs) -> float | None:
        """
        Compute WeightWatcher validation alpha score.

        Returns:
            Alpha score, or None if not available
        """
        pass

    @abstractmethod
    def compute_composite_validation_score(self, **kwargs) -> float | None:
        """
        Compute WeightWatcher composite validation score.

        Returns:
            Composite score, or None if not available
        """
        pass

    @abstractmethod
    def create_weightwatcher_callback(self, **kwargs) -> Any:
        """
        Create a WeightWatcher callback object.

        Returns:
            WeightWatcher callback, or None if not available
        """
        pass

    @abstractmethod
    def create_weightwatcher_summary(self, **kwargs) -> dict[str, Any] | None:
        """
        Create a WeightWatcher summary.

        Returns:
            Summary dict, or None if not available
        """
        pass


# Global default callbacks instance
_default_callbacks: TrainingCallbacks | None = None


def _is_firmware_environment() -> bool:
    """
    Detect if we're running in the Featrix firmware environment.

    Returns True if:
    - /sphere filesystem exists and is mounted (or symlinked)
    - We're running from an installed location (not a git workspace)

    Note: /sphere may be a symlink to /volume/sphere or similar.
    """
    # Check for /sphere filesystem (may be a symlink)
    sphere_path = Path("/sphere")
    if not sphere_path.exists():
        return False

    # Resolve the real path of /sphere in case it's a symlink
    try:
        sphere_real = sphere_path.resolve()
    except Exception:
        sphere_real = sphere_path

    # Check if we're in an installed location vs git workspace
    # Installed location: /sphere/app/... (or resolved path like /volume/sphere/app/...)
    # Git workspace: anywhere with .git directory
    current_file = Path(__file__).resolve()
    current_file_str = str(current_file)

    # Check if we're under /sphere/app or its resolved path
    sphere_app_paths = [
        "/sphere/app",
        str(sphere_real / "app") if sphere_real != sphere_path else None,
    ]
    for app_path in sphere_app_paths:
        if app_path and current_file_str.startswith(app_path):
            return True

    # Check for .git directory in parent paths (git workspace = dev mode)
    for parent in current_file.parents:
        if (parent / ".git").exists():
            return False
        # Don't go above /sphere if we're somewhere under it
        if parent == sphere_path or parent == sphere_real:
            break

    # If /sphere exists but no .git found, assume firmware
    return True


def _create_default_callbacks() -> TrainingCallbacks:
    """
    Create the appropriate callbacks based on environment detection.

    Returns:
        FirmwareTrainingCallbacks if in /sphere environment,
        DevTrainingCallbacks otherwise.
    """
    if _is_firmware_environment():
        logger.info("🖥️  Detected firmware environment - using FirmwareTrainingCallbacks")
        try:
            from featrix.neural.training_callbacks_firmware import FirmwareTrainingCallbacks
            return FirmwareTrainingCallbacks()
        except ImportError as e:
            logger.warning(f"Failed to import FirmwareTrainingCallbacks: {e}")
            # Fall through to dev callbacks

    logger.info("💻 Using DevTrainingCallbacks for local development")
    from featrix.neural.training_callbacks_dev import DevTrainingCallbacks
    return DevTrainingCallbacks()


def get_training_callbacks() -> TrainingCallbacks:
    """
    Get the current training callbacks instance.

    Auto-detects environment on first call:
    - FirmwareTrainingCallbacks for /sphere firmware environment
    - DevTrainingCallbacks for local development (git workspace)
    """
    global _default_callbacks
    if _default_callbacks is None:
        _default_callbacks = _create_default_callbacks()
    return _default_callbacks


def set_training_callbacks(callbacks: TrainingCallbacks) -> None:
    """
    Set the global training callbacks instance.

    Call this at server startup to configure the callbacks that
    EmbeddingSpace and SinglePredictor will use.

    This overrides the auto-detected callbacks.
    """
    global _default_callbacks
    _default_callbacks = callbacks
