#!/usr/bin/env python3
#  -*- coding: utf-8 -*-
#
#  Copyright Featrix, Inc 2023-2026
#
#  Development Training Callbacks Implementation
#
#  This module implements TrainingCallbacks for local development environments
#  (Mac/Linux desktop, git workspace, not installed on /sphere).
#
from __future__ import annotations

import json
import logging
import os
import platform
import subprocess
from pathlib import Path
from typing import Any

from featrix.neural.training_callbacks import TrainingCallbacks, JobStatus

logger = logging.getLogger(__name__)


def _mac_notify(title: str, message: str, subtitle: str | None = None) -> bool:
    """
    Send a macOS notification using osascript.

    Args:
        title: Notification title
        message: Notification body
        subtitle: Optional subtitle

    Returns:
        True if notification was sent, False otherwise
    """
    if platform.system() != "Darwin":
        return False

    try:
        script = f'display notification "{message}" with title "{title}"'
        if subtitle:
            script += f' subtitle "{subtitle}"'
        subprocess.run(["osascript", "-e", script], check=False, capture_output=True)
        return True
    except Exception as e:
        logger.debug(f"Failed to send Mac notification: {e}")
        return False


class DevTrainingCallbacks(TrainingCallbacks):
    """
    Training callbacks implementation for local development environments.

    This implementation:
    - Uses local filesystem paths (git workspace, ./featrix_output, etc.)
    - Does NOT require server modules (no lib.*, no slack, etc.)
    - Logs alerts to console instead of Slack
    - Provides basic fallback implementations for all methods
    - Can run on firmware boxes in a git workspace (not installed location)
    """

    def __init__(self, output_base: str | Path | None = None):
        """
        Initialize dev callbacks.

        Args:
            output_base: Base directory for output files. If None, uses
                        ./featrix_output relative to current working directory.
        """
        if output_base is None:
            output_base = Path.cwd() / "featrix_output"
        self.output_base = Path(output_base)
        self.output_base.mkdir(parents=True, exist_ok=True)

    # =========================================================================
    # Job Control File Detection
    # =========================================================================

    def find_control_file(self, job_id: str, control_type: str, output_dir: str | Path | None = None) -> str | None:
        """
        Find control files in local output directories.

        Checks:
        1. output_dir if provided
        2. self.output_base / job_id
        3. self.output_base (for session-level control files)
        """
        paths_to_check = []

        # Add output_dir if provided
        if output_dir:
            output_path = Path(output_dir)
            paths_to_check.append(output_path / control_type)
            paths_to_check.append(output_path.parent / control_type)

        # Add job-specific directory
        job_dir = self.output_base / job_id
        paths_to_check.append(job_dir / control_type)

        # Add base output directory (session-level)
        paths_to_check.append(self.output_base / control_type)

        for path in paths_to_check:
            if path.exists():
                logger.info(f"Found control file: {path}")
                return str(path)

        return None

    def get_job_output_path(self, job_id: str) -> Path | None:
        """Get output path for a job in local dev environment."""
        job_dir = self.output_base / job_id
        if job_dir.exists():
            return job_dir
        # Create it if it doesn't exist
        job_dir.mkdir(parents=True, exist_ok=True)
        return job_dir

    # =========================================================================
    # Job Status Updates
    # =========================================================================

    def update_job_status(self, job_id: str, status: JobStatus, extra_data: dict[str, Any] | None = None) -> bool:
        """
        Update job status by writing to a status.json file.

        In dev mode, we just write status to a file in the job directory.
        """
        try:
            job_dir = self.output_base / job_id
            job_dir.mkdir(parents=True, exist_ok=True)

            status_file = job_dir / "status.json"
            status_data = {
                "job_id": job_id,
                "status": status.value,
                **(extra_data or {})
            }

            with open(status_file, 'w') as f:
                json.dump(status_data, f, indent=2, default=str)

            logger.info(f"Updated job status: {job_id} -> {status.value}")
            return True
        except Exception as e:
            logger.warning(f"Failed to update job status: {e}")
            return False

    # =========================================================================
    # Alerting
    # =========================================================================

    def send_alert(self, message: str, throttle: bool = True, skip_hostname_prefix: bool = False) -> bool:
        """
        Send alert via console log and macOS notification (if on Mac).
        """
        # Log to console with a visible marker
        logger.warning(f"🔔 ALERT: {message}")

        # On Mac, also send a system notification
        # Extract a short title from the message (first line or first 50 chars)
        lines = message.strip().split('\n')
        title = "Featrix"
        subtitle = None

        # Try to extract meaningful title/subtitle from the message
        if lines:
            first_line = lines[0].strip()
            # Remove markdown formatting
            first_line = first_line.replace('**', '').replace('`', '')
            if len(first_line) <= 50:
                subtitle = first_line
            else:
                subtitle = first_line[:47] + "..."

        _mac_notify(title, message[:200], subtitle)
        return True

    # =========================================================================
    # System Health Monitoring
    # =========================================================================

    def find_dataloader_workers(self, parent_pid: int | None = None) -> list[dict[str, Any]]:
        """
        Find DataLoader workers using psutil.

        Basic implementation that looks for Python processes with 'dataloader' in cmdline.
        """
        try:
            import psutil
            workers = []
            parent_pid = parent_pid or os.getpid()

            for proc in psutil.process_iter(['pid', 'name', 'cmdline', 'memory_info']):
                try:
                    if proc.info['name'] and 'python' in proc.info['name'].lower():
                        cmdline = ' '.join(proc.info.get('cmdline') or []).lower()
                        if 'dataloader' in cmdline or 'worker' in cmdline:
                            mem = proc.info.get('memory_info')
                            if mem:
                                workers.append({
                                    'pid': proc.info['pid'],
                                    'rss_gb': mem.rss / (1024**3),
                                    'percent': proc.memory_percent(),
                                })
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
            return workers
        except ImportError:
            logger.debug("psutil not available for worker detection")
            return []
        except Exception as e:
            logger.debug(f"Error finding workers: {e}")
            return []

    def check_system_health(self) -> dict[str, Any]:
        """Check basic system health using psutil."""
        try:
            import psutil
            return {
                "status": "ok",
                "cpu_percent": psutil.cpu_percent(),
                "memory_percent": psutil.virtual_memory().percent,
                "disk_percent": psutil.disk_usage('/').percent,
            }
        except ImportError:
            return {"status": "unknown", "message": "psutil not available"}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def check_training_memory_requirements(self, **kwargs) -> dict[str, Any]:
        """Basic memory check using psutil."""
        try:
            import psutil
            mem = psutil.virtual_memory()
            return {
                "status": "ok",
                "available_gb": mem.available / (1024**3),
                "total_gb": mem.total / (1024**3),
                "percent_used": mem.percent,
            }
        except ImportError:
            return {"status": "unknown", "message": "psutil not available"}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def print_oom_recovery_help(self) -> None:
        """Print OOM recovery help to console."""
        logger.info("=" * 60)
        logger.info("OOM RECOVERY HELP")
        logger.info("=" * 60)
        logger.info("Your training ran out of memory. Try these steps:")
        logger.info("")
        logger.info("1. Reduce batch_size (e.g., from 64 to 32)")
        logger.info("2. Reduce n_epochs to train for fewer epochs")
        logger.info("3. Close other applications to free memory")
        logger.info("4. If using GPU, try CPU mode or a smaller model")
        logger.info("=" * 60)

    # =========================================================================
    # Utilities
    # =========================================================================

    def atomic_write_json(self, path: str | Path, data: dict[str, Any]) -> bool:
        """Write JSON atomically using a temp file + rename."""
        try:
            path = Path(path)
            path.parent.mkdir(parents=True, exist_ok=True)

            # Write to temp file first
            temp_path = path.with_suffix('.tmp')
            with open(temp_path, 'w') as f:
                json.dump(data, f, indent=2, default=str)

            # Atomic rename
            temp_path.rename(path)
            return True
        except Exception as e:
            logger.warning(f"Failed to write JSON to {path}: {e}")
            return False

    def get_version(self) -> str | None:
        """Get version from VERSION file in git workspace."""
        # Look for VERSION file relative to this module
        possible_paths = [
            Path(__file__).parent.parent.parent.parent / "VERSION",  # src/lib/featrix/neural -> src/
            Path(__file__).parent.parent.parent.parent.parent / "VERSION",  # up to repo root
            Path.cwd() / "VERSION",
        ]
        for version_path in possible_paths:
            if version_path.exists():
                try:
                    version = version_path.read_text().strip()
                    if version and version != "unknown":
                        return version
                except Exception:
                    pass
        return None

    def log_training_error(self, error: Exception, context: dict[str, Any] | None = None) -> None:
        """Log training error to console and optionally to file."""
        logger.error(f"Training error: {error}")
        if context:
            logger.error(f"Context: {context}")

        # Also write to error log file if we have an output base
        try:
            error_log = self.output_base / "errors.log"
            with open(error_log, 'a') as f:
                import traceback
                f.write(f"\n{'='*60}\n")
                f.write(f"Error: {error}\n")
                if context:
                    f.write(f"Context: {json.dumps(context, default=str)}\n")
                f.write(traceback.format_exc())
        except Exception:
            pass

    # =========================================================================
    # WeightWatcher Integration
    # =========================================================================

    def compute_validation_alpha_score(self, **kwargs) -> float | None:
        """WeightWatcher not available in dev mode."""
        return None

    def compute_composite_validation_score(self, **kwargs) -> float | None:
        """WeightWatcher not available in dev mode."""
        return None

    def create_weightwatcher_callback(self, **kwargs) -> Any:
        """WeightWatcher not available in dev mode."""
        return None

    def create_weightwatcher_summary(self, **kwargs) -> dict[str, Any] | None:
        """WeightWatcher not available in dev mode."""
        return None
