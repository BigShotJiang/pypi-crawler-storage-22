#!/usr/bin/env python3
#  -*- coding: utf-8 -*-
#
#  Copyright Featrix, Inc 2023-2026
#
#  Firmware Training Callbacks Implementation
#
#  This module implements TrainingCallbacks for the Featrix firmware environment
#  (compute nodes like taco, churro, burrito running on /sphere filesystem).
#
from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

from featrix.neural.training_callbacks import TrainingCallbacks, JobStatus

logger = logging.getLogger(__name__)


class FirmwareTrainingCallbacks(TrainingCallbacks):
    """
    Training callbacks implementation for Featrix firmware environment.

    This implementation:
    - Uses /sphere filesystem paths
    - Integrates with lib.job_manager for job status updates
    - Integrates with lib.system_health_monitor for health checks
    - Sends alerts via the slack module
    - Uses lib.weightwatcher_tracking for WeightWatcher integration
    """

    def __init__(self):
        """Initialize firmware callbacks - imports server modules lazily."""
        self._job_manager = None
        self._system_health_monitor = None
        self._slack = None
        self._weightwatcher_tracking = None
        self._error_tracker = None
        self._version = None
        self._lib_utils = None

    def _get_job_manager(self):
        """Lazy import of job_manager module."""
        if self._job_manager is None:
            try:
                from lib import job_manager
                self._job_manager = job_manager
            except ImportError:
                logger.debug("job_manager not available")
        return self._job_manager

    def _get_system_health_monitor(self):
        """Lazy import of system_health_monitor module."""
        if self._system_health_monitor is None:
            try:
                from lib import system_health_monitor
                self._system_health_monitor = system_health_monitor
            except ImportError:
                logger.debug("system_health_monitor not available")
        return self._system_health_monitor

    def _get_slack(self):
        """Lazy import of slack module."""
        if self._slack is None:
            try:
                import slack
                self._slack = slack
            except ImportError:
                logger.debug("slack not available")
        return self._slack

    def _get_weightwatcher_tracking(self):
        """Lazy import of weightwatcher_tracking module."""
        if self._weightwatcher_tracking is None:
            try:
                from lib import weightwatcher_tracking
                self._weightwatcher_tracking = weightwatcher_tracking
            except ImportError:
                logger.debug("weightwatcher_tracking not available")
        return self._weightwatcher_tracking

    def _get_error_tracker(self):
        """Lazy import of error_tracker module."""
        if self._error_tracker is None:
            try:
                import error_tracker
                self._error_tracker = error_tracker
            except ImportError:
                logger.debug("error_tracker not available")
        return self._error_tracker

    def _get_version(self):
        """Lazy import of version module."""
        if self._version is None:
            try:
                import version
                self._version = version
            except ImportError:
                logger.debug("version not available")
        return self._version

    def _get_lib_utils(self):
        """Lazy import of lib.utils module."""
        if self._lib_utils is None:
            try:
                from lib import utils
                self._lib_utils = utils
            except ImportError:
                logger.debug("lib.utils not available")
        return self._lib_utils

    # =========================================================================
    # Job Control File Detection
    # =========================================================================

    def find_control_file(self, job_id: str, control_type: str, output_dir: str | Path | None = None) -> str | None:
        jm = self._get_job_manager()
        if jm is None:
            return None
        try:
            result = jm._find_control_file(job_id, control_type, output_dir)
            return str(result) if result else None
        except Exception as e:
            logger.debug(f"Error finding control file: {e}")
            return None

    def get_job_output_path(self, job_id: str) -> Path | None:
        jm = self._get_job_manager()
        if jm is None:
            return None
        try:
            return jm.get_job_output_path(job_id)
        except Exception as e:
            logger.debug(f"Error getting job output path: {e}")
            return None

    # =========================================================================
    # Job Status Updates
    # =========================================================================

    def update_job_status(self, job_id: str, status: JobStatus, extra_data: dict[str, Any] | None = None) -> bool:
        jm = self._get_job_manager()
        if jm is None:
            return False
        try:
            # Convert our JobStatus to lib.job_manager.JobStatus
            lib_status = getattr(jm.JobStatus, status.name, None)
            if lib_status is None:
                logger.warning(f"Unknown job status: {status}")
                return False
            jm.update_job_status(job_id, lib_status, extra_data or {})
            return True
        except Exception as e:
            logger.debug(f"Error updating job status: {e}")
            return False

    # =========================================================================
    # Alerting
    # =========================================================================

    def send_alert(self, message: str, throttle: bool = True, skip_hostname_prefix: bool = False) -> bool:
        slack = self._get_slack()
        if slack is None:
            return False
        try:
            slack.send_slack_message(message, throttle=throttle, skip_hostname_prefix=skip_hostname_prefix)
            return True
        except Exception as e:
            logger.debug(f"Error sending alert: {e}")
            return False

    # =========================================================================
    # System Health Monitoring
    # =========================================================================

    def find_dataloader_workers(self, parent_pid: int | None = None) -> list[dict[str, Any]]:
        shm = self._get_system_health_monitor()
        if shm is None:
            return []
        try:
            monitor = shm.SystemHealthMonitor()
            return monitor.find_dataloader_workers(parent_pid=parent_pid)
        except Exception as e:
            logger.debug(f"Error finding dataloader workers: {e}")
            return []

    def check_system_health(self) -> dict[str, Any]:
        shm = self._get_system_health_monitor()
        if shm is None:
            return {"status": "unknown", "message": "system_health_monitor not available"}
        try:
            return shm.check_system_health()
        except Exception as e:
            logger.debug(f"Error checking system health: {e}")
            return {"status": "error", "message": str(e)}

    def check_training_memory_requirements(self, **kwargs) -> dict[str, Any]:
        shm = self._get_system_health_monitor()
        if shm is None:
            return {"status": "unknown", "message": "system_health_monitor not available"}
        try:
            return shm.check_training_memory_requirements(**kwargs)
        except Exception as e:
            logger.debug(f"Error checking memory requirements: {e}")
            return {"status": "error", "message": str(e)}

    def print_oom_recovery_help(self, error: Exception = None) -> None:
        shm = self._get_system_health_monitor()
        if shm is not None:
            try:
                shm.print_oom_recovery_help(error=error)
                return
            except Exception as e:
                logger.debug(f"Error printing OOM help: {e}")
        # Fallback
        logger.info("OOM Recovery: Try reducing batch_size or n_epochs")

    # =========================================================================
    # Utilities
    # =========================================================================

    def atomic_write_json(self, path: str | Path, data: dict[str, Any]) -> bool:
        utils = self._get_lib_utils()
        if utils is not None:
            try:
                utils.atomic_write_json(path, data)
                return True
            except Exception as e:
                logger.debug(f"Error with atomic_write_json: {e}")
        # Fallback to simple write
        try:
            path = Path(path)
            path.parent.mkdir(parents=True, exist_ok=True)
            with open(path, 'w') as f:
                json.dump(data, f, indent=2, default=str)
            return True
        except Exception as e:
            logger.warning(f"Failed to write JSON to {path}: {e}")
            return False

    def get_version(self) -> str | None:
        ver = self._get_version()
        if ver is not None:
            try:
                version_info = ver.get_version()
                return version_info.semantic_version
            except Exception as e:
                logger.debug(f"Error getting version: {e}")
        # Fallback - try VERSION file
        for version_path in [
            Path("/sphere/VERSION"),
            Path("/sphere/app/VERSION"),
        ]:
            if version_path.exists():
                try:
                    version = version_path.read_text().strip()
                    if version and version != "unknown":
                        return version
                except Exception:
                    pass
        return None

    def log_training_error(self, error: Exception, context: dict[str, Any] | None = None) -> None:
        et = self._get_error_tracker()
        if et is not None:
            try:
                et.log_training_error(error, **(context or {}))
                return
            except Exception as e:
                logger.debug(f"Error logging to error_tracker: {e}")
        # Fallback
        logger.error(f"Training error: {error}")
        if context:
            logger.error(f"Context: {context}")

    # =========================================================================
    # WeightWatcher Integration
    # =========================================================================

    def compute_validation_alpha_score(self, **kwargs) -> float | None:
        ww = self._get_weightwatcher_tracking()
        if ww is None:
            return None
        try:
            return ww.compute_validation_alpha_score(**kwargs)
        except Exception as e:
            logger.debug(f"Error computing validation alpha score: {e}")
            return None

    def compute_composite_validation_score(self, **kwargs) -> float | None:
        ww = self._get_weightwatcher_tracking()
        if ww is None:
            return None
        try:
            return ww.compute_composite_validation_score(**kwargs)
        except Exception as e:
            logger.debug(f"Error computing composite validation score: {e}")
            return None

    def create_weightwatcher_callback(self, **kwargs) -> Any:
        ww = self._get_weightwatcher_tracking()
        if ww is None:
            return None
        try:
            return ww.WeightWatcherCallback(**kwargs)
        except Exception as e:
            logger.debug(f"Error creating weightwatcher callback: {e}")
            return None

    def create_weightwatcher_summary(self, **kwargs) -> dict[str, Any] | None:
        ww = self._get_weightwatcher_tracking()
        if ww is None:
            return None
        try:
            return ww.create_weightwatcher_summary(**kwargs)
        except Exception as e:
            logger.debug(f"Error creating weightwatcher summary: {e}")
            return None
