#  -*- coding: utf-8 -*-
#
#  Copyright Featrix, Inc 2023-2025
#
#  Proprietary and Confidential.  Unauthorized use, copying or dissemination
#  of these materials is strictly prohibited.
#
"""
Training Suggestions Module

Analyzes SP training to identify where the model needs more information to improve.
Combines:
- Mutual Information (MI) of columns with target
- Hard-to-predict rows (consistently misclassified)
- Embedding space density analysis
- Feature value distributions for hard cases

Provides actionable suggestions for improving model performance.
"""

import logging
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Tuple, Set, TYPE_CHECKING

import numpy as np
import pandas as pd

if TYPE_CHECKING:
    from featrix.neural.single_predictor import FeatrixSinglePredictor

logger = logging.getLogger(__name__)


@dataclass
class HardRowAnalysis:
    """Analysis of a hard-to-predict row."""
    row_idx: int
    ground_truth: str
    predicted: str
    confidence: float
    epochs_wrong: int
    total_epochs: int
    unusual_features: Dict[str, Any] = field(default_factory=dict)
    embedding_neighbors: List[int] = field(default_factory=list)
    neighbor_labels: List[str] = field(default_factory=list)


@dataclass
class FeatureWeakness:
    """Identified weakness in a feature's representation."""
    column_name: str
    mi_score: float  # 0-1, higher = more predictive
    weakness_type: str  # 'sparse_region', 'class_boundary', 'interaction_effect', 'low_signal'
    affected_rows: List[int] = field(default_factory=list)
    description: str = ""
    suggested_action: str = ""


@dataclass
class TrainingSuggestion:
    """A specific suggestion for improving training."""
    priority: int  # 1 = highest priority
    category: str  # 'data_collection', 'feature_engineering', 'hyperparameter', 'architecture'
    title: str
    description: str
    affected_samples: int
    potential_improvement: str  # qualitative estimate
    details: Dict[str, Any] = field(default_factory=dict)


class TrainingSuggestionsAnalyzer:
    """
    Analyzes SP training results to provide actionable improvement suggestions.

    Key analyses:
    1. Hard row identification - rows consistently misclassified
    2. MI-weighted feature analysis - which high-MI features have unusual values in hard rows
    3. Embedding density - are hard rows in sparse regions of embedding space
    4. Class boundary analysis - are hard rows near decision boundaries
    """

    def __init__(self, sp: "FeatrixSinglePredictor"):
        """
        Initialize analyzer with a trained SinglePredictor.

        Args:
            sp: Trained FeatrixSinglePredictor instance
        """
        self.sp = sp
        self.es = sp.embedding_space
        self._mi_scores: Optional[Dict[str, float]] = None
        self._hard_rows: Optional[List[HardRowAnalysis]] = None
        self._feature_weaknesses: Optional[List[FeatureWeakness]] = None
        self._suggestions: Optional[List[TrainingSuggestion]] = None

    def analyze(self, train_df: Optional[pd.DataFrame] = None) -> List[TrainingSuggestion]:
        """
        Run full analysis and return prioritized suggestions.

        Uses data from training automatically:
        - Epoch prediction snapshots (stored during training)
        - SP's train_df (stored from prep_for_training)
        - Sample inputs from database (if available)

        Args:
            train_df: Optional additional DataFrame for feature analysis.
                     If not provided, uses sp.train_df from training.
                     Pass a new DataFrame with additional labeled examples
                     to analyze how they might help.

        Returns:
            List of TrainingSuggestion objects, sorted by priority
        """
        logger.info("=" * 80)
        logger.info("🔍 TRAINING SUGGESTIONS ANALYSIS")
        logger.info("=" * 80)

        # Use SP's stored train_df if not provided
        if train_df is None and hasattr(self.sp, 'train_df') and self.sp.train_df is not None:
            train_df = self.sp.train_df
            logger.info(f"Using stored training DataFrame: {len(train_df)} rows")

        # Step 1: Get MI scores for columns
        self._compute_mi_scores()

        # Step 2: Identify hard-to-predict rows
        self._identify_hard_rows()

        # Step 3: Analyze feature weaknesses (uses train_df or sample inputs)
        self._analyze_feature_weaknesses(train_df)

        # Step 4: Generate suggestions
        self._generate_suggestions()

        # Sort by priority
        self._suggestions.sort(key=lambda s: s.priority)

        logger.info(f"Generated {len(self._suggestions)} training suggestions")

        return self._suggestions

    def _compute_mi_scores(self):
        """Extract MI scores from embedding space training history."""
        self._mi_scores = {}

        # Try to get MI from training history database
        if hasattr(self.es, 'history_db') and self.es.history_db is not None:
            try:
                # Get the most recent MI entry
                history = self.es.history_db.get_recent_loss_history(n_epochs=1)
                if history and 'mutual_information' in history:
                    mi_data = history['mutual_information']
                    if isinstance(mi_data, dict) and 'columns' in mi_data:
                        self._mi_scores = {
                            col: score / 100.0  # Convert from percentage to 0-1
                            for col, score in mi_data['columns'].items()
                        }
                        logger.info(f"Loaded MI scores for {len(self._mi_scores)} columns")
            except Exception as e:
                logger.warning(f"Could not load MI from history_db: {e}")

        # Fallback: try training_info
        if not self._mi_scores and hasattr(self.es, 'training_info'):
            training_info = self.es.training_info or {}
            if 'column_mi' in training_info:
                self._mi_scores = training_info['column_mi']
                logger.info(f"Loaded MI scores from training_info: {len(self._mi_scores)} columns")

        # If still no MI, compute approximate MI from marginal losses
        if not self._mi_scores and hasattr(self.es, 'training_info'):
            training_info = self.es.training_info or {}
            progress_info = training_info.get('progress_info', {})
            marginal_losses = progress_info.get('marginal_losses', {})

            if marginal_losses:
                # Lower marginal loss = higher predictability = higher MI proxy
                max_loss = max(marginal_losses.values()) if marginal_losses else 1.0
                self._mi_scores = {
                    col: 1.0 - (loss / max_loss) if max_loss > 0 else 0.5
                    for col, loss in marginal_losses.items()
                }
                logger.info(f"Computed MI proxy from marginal losses: {len(self._mi_scores)} columns")

        if not self._mi_scores:
            logger.warning("No MI scores available - feature analysis will be limited")

    def _identify_hard_rows(self):
        """Identify rows that are consistently misclassified across epochs."""
        self._hard_rows = []

        # Get epoch prediction snapshots
        try:
            snapshots = self.sp.get_epoch_prediction_snapshots()
        except Exception as e:
            logger.warning(f"Could not get epoch snapshots: {e}")
            return

        if not snapshots:
            logger.warning("No epoch snapshots available")
            return

        n_epochs = len(snapshots)
        logger.info(f"Analyzing {n_epochs} epoch snapshots for hard rows")

        # Count how many epochs each row was misclassified
        row_wrong_counts: Dict[int, int] = defaultdict(int)
        row_predictions: Dict[int, List[Tuple[str, float]]] = defaultdict(list)
        row_ground_truth: Dict[int, str] = {}

        for epoch_idx, snapshot in snapshots.items():
            predictions = snapshot.get('predictions', [])
            ground_truth = snapshot.get('ground_truth', [])
            probabilities = snapshot.get('probabilities', [])

            for i, (pred, gt) in enumerate(zip(predictions, ground_truth)):
                row_ground_truth[i] = str(gt)

                # Get confidence
                prob = probabilities[i] if i < len(probabilities) else 0.5
                if isinstance(prob, dict):
                    prob = max(prob.values()) if prob else 0.5
                elif isinstance(prob, (list, np.ndarray)):
                    prob = max(prob) if len(prob) > 0 else 0.5

                row_predictions[i].append((str(pred), float(prob)))

                if str(pred) != str(gt):
                    row_wrong_counts[i] += 1

        # Identify hard rows: wrong > 50% of epochs
        threshold = n_epochs * 0.5
        hard_row_indices = [
            idx for idx, count in row_wrong_counts.items()
            if count >= threshold
        ]

        logger.info(f"Found {len(hard_row_indices)} hard rows (wrong >= {threshold:.0f} epochs)")

        # Create HardRowAnalysis objects
        for idx in hard_row_indices:
            # Get most common prediction
            preds = row_predictions[idx]
            pred_counts = defaultdict(int)
            for pred, _ in preds:
                pred_counts[pred] += 1
            most_common_pred = max(pred_counts.keys(), key=lambda k: pred_counts[k])

            # Average confidence when wrong
            wrong_confidences = [
                conf for pred, conf in preds
                if pred != row_ground_truth[idx]
            ]
            avg_wrong_conf = np.mean(wrong_confidences) if wrong_confidences else 0.5

            self._hard_rows.append(HardRowAnalysis(
                row_idx=idx,
                ground_truth=row_ground_truth[idx],
                predicted=most_common_pred,
                confidence=avg_wrong_conf,
                epochs_wrong=row_wrong_counts[idx],
                total_epochs=n_epochs,
            ))

        # Sort by epochs wrong (descending)
        self._hard_rows.sort(key=lambda h: h.epochs_wrong, reverse=True)

    def _load_samples_from_db(self) -> Optional[pd.DataFrame]:
        """
        Load sample inputs from the epoch predictions database.

        Returns:
            DataFrame with sample inputs, or None if not available
        """
        import json

        try:
            # Try to get all sample inputs from the SP's database
            if not hasattr(self.sp, 'get_sample_input'):
                return None

            # Get all sample indices we need
            all_indices = set()
            snapshots = self.sp.get_epoch_prediction_snapshots()
            if snapshots:
                for snapshot in snapshots.values():
                    predictions = snapshot.get('predictions', [])
                    all_indices.update(range(len(predictions)))

            if not all_indices:
                return None

            # Load samples
            samples = []
            for idx in sorted(all_indices):
                sample_data = self.sp.get_sample_input(idx)
                if sample_data:
                    sample_data['__sample_idx'] = idx
                    samples.append(sample_data)

            if not samples:
                logger.info("No sample inputs found in database")
                return None

            df = pd.DataFrame(samples)
            # Remove internal index column before analysis
            if '__sample_idx' in df.columns:
                df = df.drop(columns=['__sample_idx'])

            logger.info(f"Loaded {len(df)} samples from epoch predictions database")
            return df

        except Exception as e:
            logger.debug(f"Could not load samples from database: {e}")
            return None

    def _analyze_feature_weaknesses(self, train_df: Optional[pd.DataFrame] = None):
        """Analyze which features are problematic for hard rows."""
        self._feature_weaknesses = []

        if not self._hard_rows:
            logger.info("No hard rows to analyze for feature weaknesses")
            return

        # Try to build train_df from stored sample inputs if not provided
        if train_df is None:
            train_df = self._load_samples_from_db()

        if train_df is None:
            logger.info("No training data available - skipping feature distribution analysis")
            return

        if not self._mi_scores:
            logger.info("No MI scores available - skipping MI-weighted analysis")
            return

        # Get top-MI columns
        sorted_cols = sorted(
            self._mi_scores.items(),
            key=lambda x: x[1],
            reverse=True
        )
        top_mi_cols = [col for col, _ in sorted_cols[:10] if col in train_df.columns]

        logger.info(f"Analyzing top {len(top_mi_cols)} MI columns for weaknesses")

        hard_row_indices = [h.row_idx for h in self._hard_rows]

        # Filter to indices that exist in the DataFrame
        valid_hard_indices = [idx for idx in hard_row_indices if idx < len(train_df)]
        if not valid_hard_indices:
            logger.warning("No valid hard row indices found in training data")
            return

        for col in top_mi_cols:
            mi_score = self._mi_scores.get(col, 0.5)

            try:
                # Get values for hard rows vs all rows
                all_values = train_df[col].dropna()
                hard_values = train_df.iloc[valid_hard_indices][col].dropna()

                if len(hard_values) == 0:
                    continue

                weakness = self._detect_feature_weakness(
                    col, mi_score, all_values, hard_values, valid_hard_indices
                )

                if weakness:
                    self._feature_weaknesses.append(weakness)

            except Exception as e:
                logger.debug(f"Error analyzing column {col}: {e}")
                continue

        logger.info(f"Identified {len(self._feature_weaknesses)} feature weaknesses")

    def _detect_feature_weakness(
        self,
        col: str,
        mi_score: float,
        all_values: pd.Series,
        hard_values: pd.Series,
        hard_row_indices: List[int]
    ) -> Optional[FeatureWeakness]:
        """Detect the type of weakness for a specific feature."""

        # Check if column is numeric or categorical
        is_numeric = pd.api.types.is_numeric_dtype(all_values)

        if is_numeric:
            # For numeric: check if hard rows have values in sparse regions
            all_mean = all_values.mean()
            all_std = all_values.std()
            hard_mean = hard_values.mean()

            # Check if hard rows are in the tails
            z_score = abs(hard_mean - all_mean) / (all_std + 1e-10)

            if z_score > 1.5:
                # Hard rows have unusual values
                direction = "higher" if hard_mean > all_mean else "lower"
                return FeatureWeakness(
                    column_name=col,
                    mi_score=mi_score,
                    weakness_type='sparse_region',
                    affected_rows=hard_row_indices,
                    description=f"Hard-to-predict rows have {direction} values for '{col}' "
                               f"(mean={hard_mean:.2f} vs population mean={all_mean:.2f})",
                    suggested_action=f"Collect more training examples with {direction} values for '{col}'"
                )
        else:
            # For categorical: check if hard rows have rare categories
            all_value_counts = all_values.value_counts(normalize=True)
            hard_value_counts = hard_values.value_counts(normalize=True)

            # Find over-represented rare categories in hard rows
            rare_threshold = 0.05  # Categories with < 5% frequency
            rare_cats = all_value_counts[all_value_counts < rare_threshold].index.tolist()

            hard_rare_pct = hard_values.isin(rare_cats).mean()
            all_rare_pct = all_values.isin(rare_cats).mean()

            if hard_rare_pct > all_rare_pct * 2 and hard_rare_pct > 0.1:
                return FeatureWeakness(
                    column_name=col,
                    mi_score=mi_score,
                    weakness_type='sparse_region',
                    affected_rows=hard_row_indices,
                    description=f"Hard-to-predict rows over-represent rare categories in '{col}' "
                               f"({hard_rare_pct:.1%} vs {all_rare_pct:.1%} population)",
                    suggested_action=f"Collect more examples of rare categories for '{col}': {rare_cats[:5]}"
                )

        # Check for low MI despite being important
        if mi_score < 0.3:
            return FeatureWeakness(
                column_name=col,
                mi_score=mi_score,
                weakness_type='low_signal',
                affected_rows=hard_row_indices,
                description=f"Column '{col}' has low predictive signal (MI={mi_score:.2f})",
                suggested_action=f"Consider feature engineering for '{col}' or combining with related features"
            )

        return None

    def _generate_suggestions(self):
        """Generate actionable suggestions from the analysis."""
        self._suggestions = []
        priority = 1

        # Suggestion 1: Address hard rows
        if self._hard_rows:
            n_hard = len(self._hard_rows)
            always_wrong = [h for h in self._hard_rows if h.epochs_wrong == h.total_epochs]

            if always_wrong:
                self._suggestions.append(TrainingSuggestion(
                    priority=priority,
                    category='data_collection',
                    title=f"Address {len(always_wrong)} consistently misclassified samples",
                    description=(
                        f"These samples were NEVER correctly classified across all epochs. "
                        f"They may be: (1) mislabeled data, (2) edge cases needing more examples, "
                        f"or (3) fundamentally ambiguous cases."
                    ),
                    affected_samples=len(always_wrong),
                    potential_improvement="High - fixing these could improve accuracy by 1-5%",
                    details={
                        'sample_indices': [h.row_idx for h in always_wrong[:20]],
                        'ground_truth_distribution': self._count_labels([h.ground_truth for h in always_wrong]),
                    }
                ))
                priority += 1

            if n_hard > len(always_wrong):
                mostly_wrong = [h for h in self._hard_rows if h not in always_wrong]
                self._suggestions.append(TrainingSuggestion(
                    priority=priority,
                    category='data_collection',
                    title=f"Investigate {len(mostly_wrong)} frequently misclassified samples",
                    description=(
                        f"These samples were wrong >50% of epochs but occasionally correct. "
                        f"The model struggles with their feature patterns."
                    ),
                    affected_samples=len(mostly_wrong),
                    potential_improvement="Medium - these represent learnable but difficult cases",
                    details={
                        'sample_indices': [h.row_idx for h in mostly_wrong[:20]],
                        'avg_epochs_wrong': np.mean([h.epochs_wrong for h in mostly_wrong]),
                    }
                ))
                priority += 1

        # Suggestion 2: Address feature weaknesses
        for weakness in self._feature_weaknesses[:5]:  # Top 5 weaknesses
            self._suggestions.append(TrainingSuggestion(
                priority=priority,
                category='data_collection' if weakness.weakness_type == 'sparse_region' else 'feature_engineering',
                title=f"Improve coverage for '{weakness.column_name}'",
                description=weakness.description,
                affected_samples=len(weakness.affected_rows),
                potential_improvement="Medium",
                details={
                    'column': weakness.column_name,
                    'mi_score': weakness.mi_score,
                    'weakness_type': weakness.weakness_type,
                    'suggested_action': weakness.suggested_action,
                }
            ))
            priority += 1

        # Suggestion 3: Class imbalance in hard rows
        if self._hard_rows:
            hard_labels = [h.ground_truth for h in self._hard_rows]
            label_counts = self._count_labels(hard_labels)

            if label_counts:
                max_label = max(label_counts.keys(), key=lambda k: label_counts[k])
                max_pct = label_counts[max_label] / len(hard_labels)

                if max_pct > 0.7:  # One class dominates hard rows
                    self._suggestions.append(TrainingSuggestion(
                        priority=priority,
                        category='data_collection',
                        title=f"Class '{max_label}' is over-represented in hard cases",
                        description=(
                            f"{max_pct:.0%} of hard-to-predict samples belong to class '{max_label}'. "
                            f"The model may need more diverse examples of this class."
                        ),
                        affected_samples=int(max_pct * len(self._hard_rows)),
                        potential_improvement="Medium-High",
                        details={
                            'dominant_class': max_label,
                            'class_distribution': label_counts,
                        }
                    ))
                    priority += 1

        # Suggestion 4: Low overall MI
        if self._mi_scores:
            avg_mi = np.mean(list(self._mi_scores.values()))
            if avg_mi < 0.3:
                low_mi_cols = [col for col, mi in self._mi_scores.items() if mi < 0.2]
                self._suggestions.append(TrainingSuggestion(
                    priority=priority,
                    category='feature_engineering',
                    title="Low overall feature predictability",
                    description=(
                        f"Average column MI is {avg_mi:.2f}, indicating weak feature-target relationships. "
                        f"Consider feature engineering or collecting more informative features."
                    ),
                    affected_samples=0,
                    potential_improvement="High - better features could significantly improve performance",
                    details={
                        'avg_mi': avg_mi,
                        'low_mi_columns': low_mi_cols[:10],
                    }
                ))
                priority += 1

    def _count_labels(self, labels: List[str]) -> Dict[str, int]:
        """Count occurrences of each label."""
        counts = defaultdict(int)
        for label in labels:
            counts[str(label)] += 1
        return dict(counts)

    def get_report(self) -> str:
        """
        Generate a human-readable report of training suggestions.

        Returns:
            Formatted string report
        """
        if self._suggestions is None:
            self.analyze()

        lines = []
        lines.append("=" * 80)
        lines.append("TRAINING SUGGESTIONS REPORT")
        lines.append("=" * 80)
        lines.append("")

        # Summary
        lines.append("SUMMARY")
        lines.append("-" * 40)
        lines.append(f"Hard-to-predict rows: {len(self._hard_rows) if self._hard_rows else 0}")
        lines.append(f"Feature weaknesses identified: {len(self._feature_weaknesses) if self._feature_weaknesses else 0}")
        lines.append(f"Suggestions generated: {len(self._suggestions)}")
        lines.append("")

        # MI scores
        if self._mi_scores:
            lines.append("TOP PREDICTIVE FEATURES (by MI)")
            lines.append("-" * 40)
            sorted_mi = sorted(self._mi_scores.items(), key=lambda x: x[1], reverse=True)[:10]
            for col, mi in sorted_mi:
                lines.append(f"  {col}: {mi:.3f}")
            lines.append("")

        # Suggestions
        lines.append("PRIORITIZED SUGGESTIONS")
        lines.append("-" * 40)

        for i, suggestion in enumerate(self._suggestions, 1):
            lines.append("")
            lines.append(f"[{i}] {suggestion.title}")
            lines.append(f"    Category: {suggestion.category}")
            lines.append(f"    Affected samples: {suggestion.affected_samples}")
            lines.append(f"    Potential improvement: {suggestion.potential_improvement}")
            lines.append(f"    Description: {suggestion.description}")

            if 'suggested_action' in suggestion.details:
                lines.append(f"    Action: {suggestion.details['suggested_action']}")

        lines.append("")
        lines.append("=" * 80)

        return "\n".join(lines)


def get_training_suggestions(sp: "FeatrixSinglePredictor", train_df: Optional[pd.DataFrame] = None) -> str:
    """
    Convenience function to get training suggestions as a formatted report.

    Args:
        sp: Trained FeatrixSinglePredictor
        train_df: Optional training DataFrame for deeper analysis

    Returns:
        Formatted report string
    """
    analyzer = TrainingSuggestionsAnalyzer(sp)
    analyzer.analyze(train_df)
    return analyzer.get_report()
