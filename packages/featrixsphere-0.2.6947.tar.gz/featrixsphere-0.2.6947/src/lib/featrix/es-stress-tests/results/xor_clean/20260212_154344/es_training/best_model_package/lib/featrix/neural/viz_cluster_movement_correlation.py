#!/usr/bin/env python3
"""
Cluster-Movement Correlation Visualization

Visualizes relationships between:
- Cluster stability (Jaccard similarity) and point movement
- Cluster membership changes and movement intensity
- Silhouette improvement and movement patterns

Usage:
    from featrix.neural.viz_cluster_movement_correlation import ClusterMovementCorrelationViz

    viz = ClusterMovementCorrelationViz(output_dir="/path/to/training/output")
    viz.generate_all()
"""

import json
import logging
import numpy as np
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple

logger = logging.getLogger(__name__)


class ClusterMovementCorrelationViz:
    """
    Visualizes correlations between cluster metrics and movement patterns.
    """

    def __init__(self, output_dir: str | Path):
        """
        Initialize the visualization generator.

        Args:
            output_dir: Training output directory containing epoch_projections/
        """
        self.output_dir = Path(output_dir)
        self.projections_dir = self.output_dir / "epoch_projections"
        self.viz_dir = self.output_dir / "visualizations"

    def _ensure_viz_dir(self):
        """Create visualization output directory if needed."""
        self.viz_dir.mkdir(parents=True, exist_ok=True)

    def _load_all_cross_domain_data(self) -> List[Tuple[int, Dict[str, Any]]]:
        """Load all cross-domain analysis files, sorted by epoch."""
        if not self.projections_dir.exists():
            return []

        files = sorted(self.projections_dir.glob("cross_domain_epoch_*.json"))
        data = []

        for f in files:
            try:
                epoch_str = f.stem.replace("cross_domain_epoch_", "")
                epoch = int(epoch_str)
                with open(f) as fp:
                    data.append((epoch, json.load(fp)))
            except Exception as e:
                logger.warning(f"Failed to load {f.name}: {e}")

        return data

    def _load_all_cohesion_data(self) -> List[Tuple[int, Dict[str, Any]]]:
        """Load all cohesion files, sorted by epoch."""
        if not self.projections_dir.exists():
            return []

        files = sorted(self.projections_dir.glob("cohesion_epoch_*.json"))
        data = []

        for f in files:
            try:
                epoch_str = f.stem.replace("cohesion_epoch_", "")
                epoch = int(epoch_str)
                with open(f) as fp:
                    data.append((epoch, json.load(fp)))
            except Exception as e:
                logger.warning(f"Failed to load {f.name}: {e}")

        return data

    def plot_jaccard_vs_movement_scatter(self, k: int, output_filename: str = None):
        """
        Scatter plot of cluster Jaccard similarity vs mean movement.

        Shows if more stable clusters (higher Jaccard) have less movement.

        Args:
            k: Number of clusters
            output_filename: Output filename
        """
        try:
            import matplotlib.pyplot as plt
        except ImportError:
            logger.warning("matplotlib not available, skipping visualization")
            return

        self._ensure_viz_dir()

        if output_filename is None:
            output_filename = f"jaccard_vs_movement_k{k}.png"

        data = self._load_all_cross_domain_data()

        if not data:
            logger.warning("No cross-domain data found")
            return

        # Collect all cluster data points across epochs
        jaccards = []
        movements = []
        epochs_for_color = []

        for epoch, cd_data in data:
            analysis = cd_data.get("cluster_movement_analysis", {}).get(str(k))
            if not analysis:
                continue

            cohesion = analysis.get("cohesion_metrics", {})
            jaccard_per_cluster = cohesion.get("jaccard_per_cluster", [])

            if not jaccard_per_cluster:
                # Try to get from per_cluster data
                continue

            for i, cluster_data in enumerate(analysis.get("per_cluster", [])):
                if i < len(jaccard_per_cluster):
                    jaccards.append(jaccard_per_cluster[i])
                    movements.append(cluster_data["epoch_distance"]["mean"])
                    epochs_for_color.append(epoch)

        if not jaccards:
            logger.warning(f"No Jaccard/movement data found for k={k}")
            return

        fig, ax = plt.subplots(figsize=(10, 8))

        scatter = ax.scatter(jaccards, movements, c=epochs_for_color, cmap='viridis', alpha=0.6, s=50)
        plt.colorbar(scatter, ax=ax, label='Epoch')

        ax.set_xlabel('Cluster Jaccard Similarity (stability)')
        ax.set_ylabel('Mean Epoch Distance (movement)')
        ax.set_title(f'Cluster Stability vs Movement (K={k})')

        # Add correlation coefficient
        if len(jaccards) > 2:
            corr = np.corrcoef(jaccards, movements)[0, 1]
            if not np.isnan(corr):
                ax.annotate(f'r = {corr:.3f}', xy=(0.05, 0.95), xycoords='axes fraction',
                           fontsize=12, verticalalignment='top')

        ax.grid(True, alpha=0.3)

        output_path = self.viz_dir / output_filename
        plt.savefig(output_path, dpi=150, bbox_inches='tight')
        plt.close()

        logger.info(f"📊 Saved Jaccard vs movement scatter to {output_path}")

    def plot_correlation_timeline(self, k: int, output_filename: str = None):
        """
        Plot correlation between Jaccard and movement over time.

        Shows how the relationship between stability and movement evolves.

        Args:
            k: Number of clusters
            output_filename: Output filename
        """
        try:
            import matplotlib.pyplot as plt
        except ImportError:
            logger.warning("matplotlib not available, skipping visualization")
            return

        self._ensure_viz_dir()

        if output_filename is None:
            output_filename = f"correlation_timeline_k{k}.png"

        data = self._load_all_cross_domain_data()

        if not data:
            logger.warning("No cross-domain data found")
            return

        epochs = []
        correlations_epoch = []
        correlations_cum = []

        for epoch, cd_data in data:
            analysis = cd_data.get("cluster_movement_analysis", {}).get(str(k))
            if not analysis:
                continue

            corrs = analysis.get("correlations", {})
            corr_epoch = corrs.get("jaccard_vs_epoch_distance")
            corr_cum = corrs.get("jaccard_vs_cumulative_distance")

            if corr_epoch is not None or corr_cum is not None:
                epochs.append(epoch)
                correlations_epoch.append(corr_epoch if corr_epoch is not None else np.nan)
                correlations_cum.append(corr_cum if corr_cum is not None else np.nan)

        if not epochs:
            logger.warning(f"No correlation data found for k={k}")
            return

        fig, ax = plt.subplots(figsize=(12, 6))

        ax.plot(epochs, correlations_epoch, 'b-o', linewidth=2, markersize=4, label='Jaccard vs Epoch Distance')
        ax.plot(epochs, correlations_cum, 'g-s', linewidth=2, markersize=4, label='Jaccard vs Cumulative Distance')

        ax.axhline(y=0, color='gray', linestyle='--', alpha=0.5)
        ax.set_xlabel('Epoch')
        ax.set_ylabel('Correlation Coefficient')
        ax.set_title(f'Cluster Stability-Movement Correlation Over Training (K={k})')
        ax.legend()
        ax.grid(True, alpha=0.3)
        ax.set_ylim(-1.1, 1.1)

        output_path = self.viz_dir / output_filename
        plt.savefig(output_path, dpi=150, bbox_inches='tight')
        plt.close()

        logger.info(f"📊 Saved correlation timeline to {output_path}")

    def plot_silhouette_vs_movement(self, output_filename: str = "silhouette_vs_movement.png"):
        """
        Plot silhouette improvement vs overall movement across K values and epochs.
        """
        try:
            import matplotlib.pyplot as plt
        except ImportError:
            logger.warning("matplotlib not available, skipping visualization")
            return

        self._ensure_viz_dir()
        data = self._load_all_cross_domain_data()

        if not data:
            logger.warning("No cross-domain data found")
            return

        # Collect data across all K values
        silhouette_improvements = []
        mean_movements = []
        k_values = []
        epochs_for_color = []

        for epoch, cd_data in data:
            movement_summary = cd_data.get("movement_summary", {})
            mean_epoch_dist = movement_summary.get("epoch_distance", {}).get("mean", 0)

            cluster_analysis = cd_data.get("cluster_movement_analysis", {})

            for k_str, analysis in cluster_analysis.items():
                cohesion = analysis.get("cohesion_metrics", {})
                sil_imp = cohesion.get("silhouette_improvement")

                if sil_imp is not None:
                    silhouette_improvements.append(sil_imp)
                    mean_movements.append(mean_epoch_dist)
                    k_values.append(int(k_str))
                    epochs_for_color.append(epoch)

        if not silhouette_improvements:
            logger.warning("No silhouette improvement data found")
            return

        fig, axes = plt.subplots(1, 2, figsize=(14, 6))

        # Left: colored by epoch
        scatter1 = axes[0].scatter(silhouette_improvements, mean_movements, c=epochs_for_color,
                                   cmap='viridis', alpha=0.6, s=50)
        plt.colorbar(scatter1, ax=axes[0], label='Epoch')
        axes[0].set_xlabel('Silhouette Improvement')
        axes[0].set_ylabel('Mean Epoch Distance')
        axes[0].set_title('Silhouette Improvement vs Movement (by Epoch)')
        axes[0].grid(True, alpha=0.3)

        # Right: colored by K
        scatter2 = axes[1].scatter(silhouette_improvements, mean_movements, c=k_values,
                                   cmap='tab10', alpha=0.6, s=50)
        plt.colorbar(scatter2, ax=axes[1], label='K')
        axes[1].set_xlabel('Silhouette Improvement')
        axes[1].set_ylabel('Mean Epoch Distance')
        axes[1].set_title('Silhouette Improvement vs Movement (by K)')
        axes[1].grid(True, alpha=0.3)

        plt.tight_layout()

        output_path = self.viz_dir / output_filename
        plt.savefig(output_path, dpi=150, bbox_inches='tight')
        plt.close()

        logger.info(f"📊 Saved silhouette vs movement plot to {output_path}")

    def plot_neighbor_preservation_vs_movement(self, output_filename: str = "neighbor_preservation_vs_movement.png"):
        """
        Plot neighbor preservation vs cumulative movement.

        Shows if points that move more have worse neighbor preservation.
        """
        try:
            import matplotlib.pyplot as plt
        except ImportError:
            logger.warning("matplotlib not available, skipping visualization")
            return

        self._ensure_viz_dir()
        data = self._load_all_cross_domain_data()

        if not data:
            logger.warning("No cross-domain data found")
            return

        epochs = []
        neighbor_preservations = []
        mean_cum_distances = []

        for epoch, cd_data in data:
            movement_summary = cd_data.get("movement_summary", {})
            mean_cum_dist = movement_summary.get("cumulative_distance", {}).get("mean", 0)

            # Get neighbor preservation from any K (it's the same across K values)
            cluster_analysis = cd_data.get("cluster_movement_analysis", {})
            for k_str, analysis in cluster_analysis.items():
                cohesion = analysis.get("cohesion_metrics", {})
                np_val = cohesion.get("neighbor_preservation")
                if np_val is not None:
                    epochs.append(epoch)
                    neighbor_preservations.append(np_val)
                    mean_cum_distances.append(mean_cum_dist)
                    break  # Only need one K since neighbor_preservation is same

        if not epochs:
            logger.warning("No neighbor preservation data found")
            return

        fig, axes = plt.subplots(1, 2, figsize=(14, 5))

        # Left: Neighbor preservation over epochs
        axes[0].plot(epochs, neighbor_preservations, 'b-o', linewidth=2, markersize=4)
        axes[0].set_xlabel('Epoch')
        axes[0].set_ylabel('Neighbor Preservation')
        axes[0].set_title('Neighbor Preservation Over Training')
        axes[0].grid(True, alpha=0.3)

        # Right: Neighbor preservation vs cumulative distance
        scatter = axes[1].scatter(mean_cum_distances, neighbor_preservations, c=epochs,
                                  cmap='viridis', alpha=0.7, s=60)
        plt.colorbar(scatter, ax=axes[1], label='Epoch')
        axes[1].set_xlabel('Mean Cumulative Distance')
        axes[1].set_ylabel('Neighbor Preservation')
        axes[1].set_title('Neighbor Preservation vs Total Movement')
        axes[1].grid(True, alpha=0.3)

        # Add correlation
        if len(neighbor_preservations) > 2:
            corr = np.corrcoef(mean_cum_distances, neighbor_preservations)[0, 1]
            if not np.isnan(corr):
                axes[1].annotate(f'r = {corr:.3f}', xy=(0.05, 0.95), xycoords='axes fraction',
                                fontsize=12, verticalalignment='top')

        plt.tight_layout()

        output_path = self.viz_dir / output_filename
        plt.savefig(output_path, dpi=150, bbox_inches='tight')
        plt.close()

        logger.info(f"📊 Saved neighbor preservation vs movement plot to {output_path}")

    def generate_all(self, k_values: List[int] = None):
        """
        Generate all cluster-movement correlation visualizations.

        Args:
            k_values: List of K values (default: [5, 7, 9])
        """
        if k_values is None:
            k_values = [5, 7, 9]

        logger.info("📊 Generating cluster-movement correlation visualizations...")

        self.plot_silhouette_vs_movement()
        self.plot_neighbor_preservation_vs_movement()

        for k in k_values:
            self.plot_jaccard_vs_movement_scatter(k)
            self.plot_correlation_timeline(k)

        logger.info(f"📊 All visualizations saved to {self.viz_dir}")
