#!/usr/bin/env python3
"""
Movement Distribution Visualization

Generates visualizations of point movement patterns during training:
- Per-epoch movement histograms
- Cumulative distance distribution over time
- Movement heatmaps by cluster

Usage:
    from featrix.neural.viz_movement_distribution import MovementDistributionViz

    viz = MovementDistributionViz(output_dir="/path/to/training/output")

    # Generate all visualizations
    viz.generate_all()

    # Or individual visualizations
    viz.plot_epoch_distance_timeline()
    viz.plot_cumulative_distance_evolution()
    viz.plot_movement_by_cluster_heatmap(k=7)
"""

import json
import logging
import numpy as np
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple

logger = logging.getLogger(__name__)


class MovementDistributionViz:
    """
    Generates movement distribution visualizations from epoch projection data.
    """

    def __init__(self, output_dir: str | Path):
        """
        Initialize the visualization generator.

        Args:
            output_dir: Training output directory containing epoch_projections/
        """
        self.output_dir = Path(output_dir)
        self.projections_dir = self.output_dir / "epoch_projections"
        self.viz_dir = self.output_dir / "visualizations"

    def _ensure_viz_dir(self):
        """Create visualization output directory if needed."""
        self.viz_dir.mkdir(parents=True, exist_ok=True)

    def _load_all_projection_data(self) -> List[Tuple[int, Dict[str, Any]]]:
        """Load all projection files, sorted by epoch."""
        if not self.projections_dir.exists():
            return []

        projection_files = sorted(self.projections_dir.glob("projections_epoch_*.json"))
        data = []

        for pf in projection_files:
            try:
                epoch_str = pf.stem.replace("projections_epoch_", "")
                epoch = int(epoch_str)
                with open(pf) as f:
                    data.append((epoch, json.load(f)))
            except Exception as e:
                logger.warning(f"Failed to load {pf.name}: {e}")

        return data

    def _load_all_cross_domain_data(self) -> List[Tuple[int, Dict[str, Any]]]:
        """Load all cross-domain analysis files, sorted by epoch."""
        if not self.projections_dir.exists():
            return []

        files = sorted(self.projections_dir.glob("cross_domain_epoch_*.json"))
        data = []

        for f in files:
            try:
                epoch_str = f.stem.replace("cross_domain_epoch_", "")
                epoch = int(epoch_str)
                with open(f) as fp:
                    data.append((epoch, json.load(fp)))
            except Exception as e:
                logger.warning(f"Failed to load {f.name}: {e}")

        return data

    def plot_epoch_distance_timeline(self, output_filename: str = "epoch_distance_timeline.png"):
        """
        Plot epoch distance distribution over training.

        Shows mean, std, and percentiles of per-epoch movement.
        """
        try:
            import matplotlib.pyplot as plt
        except ImportError:
            logger.warning("matplotlib not available, skipping visualization")
            return

        self._ensure_viz_dir()
        data = self._load_all_projection_data()

        if not data:
            logger.warning("No projection data found")
            return

        epochs = []
        means = []
        stds = []
        p10 = []
        p90 = []

        for epoch, proj_data in data:
            movement = proj_data.get("movement_metrics", {})
            dist = movement.get("epoch_distance_distribution", {})

            if not dist:
                continue

            epochs.append(epoch)
            means.append(dist.get("mean", 0))
            stds.append(dist.get("std", 0))
            percentiles = dist.get("percentiles", {})
            p10.append(percentiles.get("10", 0))
            p90.append(percentiles.get("90", 0))

        if not epochs:
            logger.warning("No movement data found in projections")
            return

        fig, ax = plt.subplots(figsize=(12, 6))

        epochs = np.array(epochs)
        means = np.array(means)
        stds = np.array(stds)
        p10 = np.array(p10)
        p90 = np.array(p90)

        # Plot mean with std band
        ax.plot(epochs, means, 'b-', linewidth=2, label='Mean')
        ax.fill_between(epochs, means - stds, means + stds, alpha=0.2, color='blue', label='±1 Std')

        # Plot 10-90 percentile band
        ax.fill_between(epochs, p10, p90, alpha=0.1, color='green', label='10-90 percentile')

        ax.set_xlabel('Epoch')
        ax.set_ylabel('Epoch Distance')
        ax.set_title('Per-Epoch Movement Distribution Over Training')
        ax.legend()
        ax.grid(True, alpha=0.3)

        output_path = self.viz_dir / output_filename
        plt.savefig(output_path, dpi=150, bbox_inches='tight')
        plt.close()

        logger.info(f"📊 Saved epoch distance timeline to {output_path}")

    def plot_cumulative_distance_evolution(self, output_filename: str = "cumulative_distance_evolution.png"):
        """
        Plot how cumulative distance distribution evolves over training.

        Shows the growth of total distance traveled by points.
        """
        try:
            import matplotlib.pyplot as plt
        except ImportError:
            logger.warning("matplotlib not available, skipping visualization")
            return

        self._ensure_viz_dir()
        data = self._load_all_projection_data()

        if not data:
            logger.warning("No projection data found")
            return

        epochs = []
        means = []
        medians = []
        p25 = []
        p75 = []

        for epoch, proj_data in data:
            movement = proj_data.get("movement_metrics", {})
            dist = movement.get("cumulative_distance_distribution", {})

            if not dist:
                continue

            epochs.append(epoch)
            means.append(dist.get("mean", 0))
            medians.append(dist.get("median", 0))
            percentiles = dist.get("percentiles", {})
            p25.append(percentiles.get("25", 0))
            p75.append(percentiles.get("75", 0))

        if not epochs:
            logger.warning("No cumulative distance data found")
            return

        fig, ax = plt.subplots(figsize=(12, 6))

        epochs = np.array(epochs)
        means = np.array(means)
        medians = np.array(medians)
        p25 = np.array(p25)
        p75 = np.array(p75)

        ax.plot(epochs, means, 'b-', linewidth=2, label='Mean')
        ax.plot(epochs, medians, 'g--', linewidth=2, label='Median')
        ax.fill_between(epochs, p25, p75, alpha=0.2, color='blue', label='25-75 percentile')

        ax.set_xlabel('Epoch')
        ax.set_ylabel('Cumulative Distance')
        ax.set_title('Cumulative Distance Evolution Over Training')
        ax.legend()
        ax.grid(True, alpha=0.3)

        output_path = self.viz_dir / output_filename
        plt.savefig(output_path, dpi=150, bbox_inches='tight')
        plt.close()

        logger.info(f"📊 Saved cumulative distance evolution to {output_path}")

    def plot_movement_by_cluster_heatmap(self, k: int, output_filename: str = None):
        """
        Plot heatmap of movement by cluster over epochs.

        Args:
            k: Number of clusters
            output_filename: Output filename (default: movement_by_cluster_k{k}.png)
        """
        try:
            import matplotlib.pyplot as plt
        except ImportError:
            logger.warning("matplotlib not available, skipping visualization")
            return

        self._ensure_viz_dir()

        if output_filename is None:
            output_filename = f"movement_by_cluster_k{k}.png"

        data = self._load_all_cross_domain_data()

        if not data:
            logger.warning("No cross-domain data found. Run EpochCrossDomainAnalyzer first.")
            return

        # Build matrix: epochs x clusters
        epochs = []
        cluster_ids = set()

        for epoch, cd_data in data:
            analysis = cd_data.get("cluster_movement_analysis", {}).get(str(k))
            if analysis:
                epochs.append(epoch)
                for c in analysis.get("per_cluster", []):
                    cluster_ids.add(c["cluster_id"])

        if not epochs or not cluster_ids:
            logger.warning(f"No cluster movement data found for k={k}")
            return

        cluster_ids = sorted(cluster_ids)
        n_epochs = len(epochs)
        n_clusters = len(cluster_ids)

        # Build heatmap matrix
        heatmap = np.zeros((n_clusters, n_epochs))

        for ei, (epoch, cd_data) in enumerate(data):
            analysis = cd_data.get("cluster_movement_analysis", {}).get(str(k))
            if not analysis:
                continue

            for c in analysis.get("per_cluster", []):
                ci = cluster_ids.index(c["cluster_id"])
                heatmap[ci, ei] = c["epoch_distance"]["mean"]

        fig, ax = plt.subplots(figsize=(14, 6))

        im = ax.imshow(heatmap, aspect='auto', cmap='YlOrRd')
        ax.set_xlabel('Epoch')
        ax.set_ylabel('Cluster ID')
        ax.set_title(f'Mean Epoch Distance by Cluster (K={k})')

        # Set tick labels
        ax.set_xticks(range(0, n_epochs, max(1, n_epochs // 10)))
        ax.set_xticklabels([epochs[i] for i in range(0, n_epochs, max(1, n_epochs // 10))])
        ax.set_yticks(range(n_clusters))
        ax.set_yticklabels(cluster_ids)

        plt.colorbar(im, ax=ax, label='Mean Epoch Distance')

        output_path = self.viz_dir / output_filename
        plt.savefig(output_path, dpi=150, bbox_inches='tight')
        plt.close()

        logger.info(f"📊 Saved movement by cluster heatmap to {output_path}")

    def plot_movement_histogram_grid(self, epochs: List[int] = None, output_filename: str = "movement_histograms.png"):
        """
        Plot grid of movement histograms for selected epochs.

        Args:
            epochs: List of epochs to plot (default: evenly spaced sample)
            output_filename: Output filename
        """
        try:
            import matplotlib.pyplot as plt
        except ImportError:
            logger.warning("matplotlib not available, skipping visualization")
            return

        self._ensure_viz_dir()
        data = self._load_all_projection_data()

        if not data:
            logger.warning("No projection data found")
            return

        # Select epochs if not specified
        if epochs is None:
            all_epochs = [e for e, _ in data]
            if len(all_epochs) <= 9:
                epochs = all_epochs
            else:
                # Pick ~9 evenly spaced epochs
                indices = np.linspace(0, len(all_epochs) - 1, 9, dtype=int)
                epochs = [all_epochs[i] for i in indices]

        # Filter data to selected epochs
        data = [(e, d) for e, d in data if e in epochs]

        n_plots = len(data)
        if n_plots == 0:
            return

        ncols = min(3, n_plots)
        nrows = (n_plots + ncols - 1) // ncols

        fig, axes = plt.subplots(nrows, ncols, figsize=(4 * ncols, 3 * nrows))
        if nrows == 1 and ncols == 1:
            axes = np.array([[axes]])
        elif nrows == 1:
            axes = axes.reshape(1, -1)
        elif ncols == 1:
            axes = axes.reshape(-1, 1)

        for idx, (epoch, proj_data) in enumerate(data):
            row = idx // ncols
            col = idx % ncols
            ax = axes[row, col]

            movement = proj_data.get("movement_metrics", {})
            dist = movement.get("epoch_distance_distribution", {})
            histogram = dist.get("histogram", {})

            if histogram:
                counts = histogram.get("counts", [])
                edges = histogram.get("bin_edges", [])

                if counts and edges:
                    # Plot histogram
                    centers = [(edges[i] + edges[i + 1]) / 2 for i in range(len(edges) - 1)]
                    ax.bar(centers, counts, width=(edges[1] - edges[0]) * 0.9, alpha=0.7)

            ax.set_title(f'Epoch {epoch}')
            ax.set_xlabel('Distance')
            ax.set_ylabel('Count')

        # Hide empty subplots
        for idx in range(n_plots, nrows * ncols):
            row = idx // ncols
            col = idx % ncols
            axes[row, col].set_visible(False)

        plt.suptitle('Epoch Distance Distributions Over Training', y=1.02)
        plt.tight_layout()

        output_path = self.viz_dir / output_filename
        plt.savefig(output_path, dpi=150, bbox_inches='tight')
        plt.close()

        logger.info(f"📊 Saved movement histogram grid to {output_path}")

    def generate_all(self, k_values: List[int] = None):
        """
        Generate all movement distribution visualizations.

        Args:
            k_values: List of K values for cluster heatmaps (default: [5, 7, 9])
        """
        if k_values is None:
            k_values = [5, 7, 9]

        logger.info("📊 Generating movement distribution visualizations...")

        self.plot_epoch_distance_timeline()
        self.plot_cumulative_distance_evolution()
        self.plot_movement_histogram_grid()

        for k in k_values:
            self.plot_movement_by_cluster_heatmap(k)

        logger.info(f"📊 All visualizations saved to {self.viz_dir}")
