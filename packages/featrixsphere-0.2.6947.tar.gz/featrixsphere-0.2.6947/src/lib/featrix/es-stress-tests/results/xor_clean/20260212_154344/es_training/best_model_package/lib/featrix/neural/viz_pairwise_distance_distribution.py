#  -*- coding: utf-8 -*-
#
#  Copyright Featrix, Inc 2023-2025
#
#  Proprietary and Confidential.  Unauthorized use, copying or dissemination
#  of these materials is strictly prohibited.
#
"""
Pairwise Distance Distribution Visualization.

Tracks and visualizes the distribution of pairwise distances (cosine similarities)
between embeddings across training epochs. This helps diagnose:
- Whether embeddings are well-spread or clustered
- How distance distributions evolve during training
- Whether the embedding space is being used efficiently

Ideal distribution: Uniform spread (not Gaussian clustered around mean)

Output structure:
    <output_dir>/
    └── media/
        ├── pairwise_distance/
        │   ├── pairwise_distance_epoch_0000.png
        │   ├── pairwise_distance_epoch_0000.json
        │   └── ...
        ├── pairwise_distance.png         # Latest frame
        └── pairwise_distance_evolution.png  # Multi-epoch comparison
"""

import json
import logging
import os
import shutil
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    import numpy as np

# Set matplotlib to use non-interactive Agg backend
import matplotlib
matplotlib.use('Agg')

logger = logging.getLogger(__name__)


@dataclass
class DistributionStats:
    """Statistics for a pairwise distance distribution."""
    epoch: int
    n_samples: int
    n_pairs: int

    # Central tendency
    mean: float
    median: float

    # Spread
    std: float
    min_val: float
    max_val: float
    range_val: float

    # Percentiles (for understanding shape)
    p5: float
    p10: float
    p25: float
    p75: float
    p90: float
    p95: float

    # Histogram data (20 bins from -1 to 1 for cosine sim)
    hist_counts: List[int] = field(default_factory=list)
    hist_bin_edges: List[float] = field(default_factory=list)

    # Uniformity metrics
    # How far from uniform? Lower = more uniform
    uniformity_score: float = 0.0

    def to_dict(self) -> Dict:
        """Convert to JSON-serializable dict."""
        return asdict(self)

    @classmethod
    def from_dict(cls, d: Dict) -> "DistributionStats":
        """Create from dict."""
        return cls(**d)


class PairwiseDistanceTracker:
    """
    Tracks pairwise distance distributions across epochs.

    Stores stats for: epoch 0, every 5th epoch, best epoch (by uniformity), final.
    Generates per-epoch plots and a summary evolution plot.
    """

    def __init__(self, output_dir: str, n_bins: int = 20):
        """
        Initialize tracker.

        Args:
            output_dir: Base output directory for saving visualizations
            n_bins: Number of histogram bins (default 20 for -1 to 1 range)
        """
        self.output_dir = output_dir
        self.n_bins = n_bins

        # Store all epoch stats for evolution plot
        self.epoch_stats: Dict[int, DistributionStats] = {}

        # Track which epochs to include in evolution plot
        self.key_epochs: List[int] = []  # epoch 0, every 5th, best, final

        # Track best epoch by uniformity
        self.best_epoch: int = 0
        self.best_uniformity: float = float('inf')

        # Create output directories
        self.media_dir = os.path.join(output_dir, "media", "pairwise_distance")
        os.makedirs(self.media_dir, exist_ok=True)

    def compute_stats(
        self,
        off_diag_similarities: "np.ndarray",
        epoch: int,
        n_samples: int,
    ) -> DistributionStats:
        """
        Compute distribution statistics from off-diagonal similarities.

        Args:
            off_diag_similarities: 1D array of pairwise cosine similarities (excluding diagonal)
            epoch: Current epoch number
            n_samples: Number of samples in batch

        Returns:
            DistributionStats with all metrics
        """
        import numpy as np

        sims = off_diag_similarities
        n_pairs = len(sims)

        # Basic stats
        mean = float(np.mean(sims))
        median = float(np.median(sims))
        std = float(np.std(sims))
        min_val = float(np.min(sims))
        max_val = float(np.max(sims))
        range_val = max_val - min_val

        # Percentiles
        percentiles = np.percentile(sims, [5, 10, 25, 75, 90, 95])
        p5, p10, p25, p75, p90, p95 = [float(p) for p in percentiles]

        # Histogram (20 bins from -1 to 1)
        hist_counts, hist_bin_edges = np.histogram(sims, bins=self.n_bins, range=(-1.0, 1.0))
        hist_counts = [int(c) for c in hist_counts]
        hist_bin_edges = [float(e) for e in hist_bin_edges]

        # Uniformity score: chi-squared from uniform distribution
        # Lower = more uniform
        expected_count = n_pairs / self.n_bins
        if expected_count > 0:
            chi_sq = sum((c - expected_count) ** 2 / expected_count for c in hist_counts)
            uniformity_score = float(chi_sq)
        else:
            uniformity_score = float('inf')

        return DistributionStats(
            epoch=epoch,
            n_samples=n_samples,
            n_pairs=n_pairs,
            mean=mean,
            median=median,
            std=std,
            min_val=min_val,
            max_val=max_val,
            range_val=range_val,
            p5=p5,
            p10=p10,
            p25=p25,
            p75=p75,
            p90=p90,
            p95=p95,
            hist_counts=hist_counts,
            hist_bin_edges=hist_bin_edges,
            uniformity_score=uniformity_score,
        )

    def record_epoch(
        self,
        off_diag_similarities: "np.ndarray",
        epoch: int,
        n_samples: int,
        is_final: bool = False,
    ) -> DistributionStats:
        """
        Record distribution for this epoch and generate visualization.

        Args:
            off_diag_similarities: 1D array of pairwise cosine similarities
            epoch: Current epoch number
            n_samples: Number of samples in batch
            is_final: Whether this is the final epoch

        Returns:
            DistributionStats for this epoch
        """
        stats = self.compute_stats(off_diag_similarities, epoch, n_samples)
        self.epoch_stats[epoch] = stats

        # Track best epoch by uniformity (lower = better)
        if stats.uniformity_score < self.best_uniformity:
            self.best_uniformity = stats.uniformity_score
            self.best_epoch = epoch

        # Determine if this is a key epoch for evolution plot
        is_key_epoch = (
            epoch == 0 or
            epoch % 5 == 0 or
            epoch == self.best_epoch or
            is_final
        )

        if is_key_epoch and epoch not in self.key_epochs:
            self.key_epochs.append(epoch)
            self.key_epochs.sort()

        # Generate single-epoch plot
        self._plot_single_epoch(stats)

        # Update evolution plot
        self._plot_evolution()

        # Save JSON data
        self._save_epoch_json(stats)

        return stats

    def _plot_single_epoch(self, stats: DistributionStats) -> Optional[str]:
        """Generate histogram plot for a single epoch."""
        try:
            import matplotlib.pyplot as plt
            import numpy as np

            fig, ax = plt.subplots(figsize=(10, 6))

            # Plot histogram bars
            bin_centers = [(stats.hist_bin_edges[i] + stats.hist_bin_edges[i+1]) / 2
                          for i in range(len(stats.hist_counts))]
            bin_width = stats.hist_bin_edges[1] - stats.hist_bin_edges[0]

            # Color by deviation from uniform
            expected = stats.n_pairs / self.n_bins
            colors = []
            for count in stats.hist_counts:
                deviation = abs(count - expected) / max(expected, 1)
                # Green = close to uniform, Red = far from uniform
                if deviation < 0.2:
                    colors.append('#2ecc71')  # Green
                elif deviation < 0.5:
                    colors.append('#f39c12')  # Orange
                else:
                    colors.append('#e74c3c')  # Red

            ax.bar(bin_centers, stats.hist_counts, width=bin_width * 0.9,
                   color=colors, edgecolor='black', linewidth=0.5)

            # Draw uniform reference line
            ax.axhline(y=expected, color='blue', linestyle='--', linewidth=2,
                      label=f'Uniform ({expected:.0f})')

            # Mark percentiles
            for pval, pname in [(stats.p25, 'p25'), (stats.median, 'median'), (stats.p75, 'p75')]:
                ax.axvline(x=pval, color='purple', linestyle=':', alpha=0.7)

            # Labels and title
            ax.set_xlabel('Cosine Similarity', fontsize=12)
            ax.set_ylabel('Count', fontsize=12)
            ax.set_xlim(-1.05, 1.05)

            title = f'Pairwise Similarity Distribution - Epoch {stats.epoch}'
            ax.set_title(title, fontsize=14, fontweight='bold')

            # Stats text box
            stats_text = (
                f"n_samples: {stats.n_samples}\n"
                f"n_pairs: {stats.n_pairs:,}\n"
                f"mean: {stats.mean:.4f}\n"
                f"std: {stats.std:.4f}\n"
                f"range: [{stats.min_val:.3f}, {stats.max_val:.3f}]\n"
                f"uniformity: {stats.uniformity_score:.1f}"
            )
            ax.text(0.02, 0.98, stats_text, transform=ax.transAxes, fontsize=9,
                   verticalalignment='top', fontfamily='monospace',
                   bbox=dict(boxstyle='round', facecolor='white', alpha=0.9))

            # Quality indicator
            if stats.uniformity_score < 50:
                quality = "GOOD (near uniform)"
                qcolor = 'green'
            elif stats.uniformity_score < 200:
                quality = "OK (some clustering)"
                qcolor = 'orange'
            else:
                quality = "POOR (highly clustered)"
                qcolor = 'red'

            ax.text(0.98, 0.98, quality, transform=ax.transAxes, fontsize=11,
                   verticalalignment='top', horizontalalignment='right',
                   fontweight='bold', color=qcolor,
                   bbox=dict(boxstyle='round', facecolor='white', alpha=0.9))

            ax.legend(loc='upper right', bbox_to_anchor=(0.98, 0.85))

            plt.tight_layout()

            # Save
            frame_path = os.path.join(self.media_dir, f"pairwise_distance_epoch_{stats.epoch:04d}.png")
            plt.savefig(frame_path, dpi=100, bbox_inches='tight')
            plt.close()

            # Copy to latest
            media_root = os.path.join(self.output_dir, "media")
            shutil.copy(frame_path, os.path.join(media_root, "pairwise_distance.png"))

            logger.debug(f"Pairwise distance plot saved to: {frame_path}")
            return frame_path

        except Exception as e:
            logger.warning(f"Failed to plot pairwise distance distribution: {e}")
            import traceback
            traceback.print_exc()
            return None

    def _plot_evolution(self) -> Optional[str]:
        """Generate multi-epoch evolution plot showing distribution changes."""
        try:
            import matplotlib.pyplot as plt
            import numpy as np

            if len(self.epoch_stats) < 2:
                return None

            # Select epochs to show (max 8 for readability)
            epochs_to_show = sorted(self.epoch_stats.keys())
            if len(epochs_to_show) > 8:
                # Keep: first, last, best, and evenly spaced others
                keep = {epochs_to_show[0], epochs_to_show[-1], self.best_epoch}
                remaining = [e for e in epochs_to_show if e not in keep]
                step = max(1, len(remaining) // 5)
                keep.update(remaining[::step])
                epochs_to_show = sorted(keep)[:8]

            fig, axes = plt.subplots(2, 1, figsize=(12, 10))

            # Top: Overlaid histogram curves
            ax1 = axes[0]
            cmap = plt.get_cmap('viridis')
            colors = [cmap(i / max(1, len(epochs_to_show) - 1)) for i in range(len(epochs_to_show))]

            for idx, epoch in enumerate(epochs_to_show):
                stats = self.epoch_stats[epoch]
                bin_centers = [(stats.hist_bin_edges[i] + stats.hist_bin_edges[i+1]) / 2
                              for i in range(len(stats.hist_counts))]

                # Normalize to density for comparison
                density = [c / max(1, stats.n_pairs) for c in stats.hist_counts]

                label = f"Epoch {epoch}"
                if epoch == self.best_epoch:
                    label += " (best)"
                if epoch == epochs_to_show[-1]:
                    label += " (final)"

                ax1.plot(bin_centers, density, color=colors[idx], linewidth=2,
                        label=label, alpha=0.8)
                ax1.fill_between(bin_centers, density, alpha=0.1, color=colors[idx])

            # Uniform reference
            uniform_density = 1.0 / self.n_bins
            ax1.axhline(y=uniform_density, color='red', linestyle='--', linewidth=2,
                       label='Uniform', alpha=0.7)

            ax1.set_xlabel('Cosine Similarity', fontsize=12)
            ax1.set_ylabel('Density', fontsize=12)
            ax1.set_xlim(-1.05, 1.05)
            ax1.set_title('Pairwise Similarity Distribution Evolution', fontsize=14, fontweight='bold')
            ax1.legend(loc='upper right', fontsize=9, ncol=2)
            ax1.grid(True, alpha=0.3)

            # Bottom: Metrics over time
            ax2 = axes[1]
            all_epochs = sorted(self.epoch_stats.keys())

            means = [self.epoch_stats[e].mean for e in all_epochs]
            stds = [self.epoch_stats[e].std for e in all_epochs]
            uniformity = [self.epoch_stats[e].uniformity_score for e in all_epochs]

            ax2_twin = ax2.twinx()

            ax2.plot(all_epochs, means, 'b-', linewidth=2, label='Mean similarity', marker='o', markersize=4)
            ax2.fill_between(all_epochs,
                            [m - s for m, s in zip(means, stds)],
                            [m + s for m, s in zip(means, stds)],
                            alpha=0.2, color='blue')
            ax2.set_xlabel('Epoch', fontsize=12)
            ax2.set_ylabel('Mean Similarity (± std)', fontsize=12, color='blue')
            ax2.tick_params(axis='y', labelcolor='blue')
            ax2.axhline(y=0.0, color='blue', linestyle=':', alpha=0.5)

            ax2_twin.plot(all_epochs, uniformity, 'r-', linewidth=2, label='Uniformity score',
                         marker='s', markersize=4)
            ax2_twin.set_ylabel('Uniformity Score (lower=better)', fontsize=12, color='red')
            ax2_twin.tick_params(axis='y', labelcolor='red')

            # Mark best epoch
            ax2.axvline(x=self.best_epoch, color='green', linestyle='--', alpha=0.7,
                       label=f'Best epoch ({self.best_epoch})')

            # Combined legend
            lines1, labels1 = ax2.get_legend_handles_labels()
            lines2, labels2 = ax2_twin.get_legend_handles_labels()
            ax2.legend(lines1 + lines2, labels1 + labels2, loc='upper right', fontsize=9)

            ax2.set_title('Distribution Metrics Over Training', fontsize=12, fontweight='bold')
            ax2.grid(True, alpha=0.3)

            plt.tight_layout()

            # Save
            evolution_path = os.path.join(self.output_dir, "media", "pairwise_distance_evolution.png")
            plt.savefig(evolution_path, dpi=100, bbox_inches='tight')
            plt.close()

            logger.debug(f"Pairwise distance evolution plot saved to: {evolution_path}")
            return evolution_path

        except Exception as e:
            logger.warning(f"Failed to plot pairwise distance evolution: {e}")
            import traceback
            traceback.print_exc()
            return None

    def _save_epoch_json(self, stats: DistributionStats) -> Optional[str]:
        """Save epoch stats to JSON."""
        try:
            json_path = os.path.join(self.media_dir, f"pairwise_distance_epoch_{stats.epoch:04d}.json")
            with open(json_path, 'w') as f:
                json.dump(stats.to_dict(), f, indent=2)
            return json_path
        except Exception as e:
            logger.warning(f"Failed to save pairwise distance JSON: {e}")
            return None

    def save_summary(self) -> Optional[str]:
        """Save summary JSON with all tracked epochs."""
        try:
            summary = {
                'best_epoch': self.best_epoch,
                'best_uniformity': self.best_uniformity,
                'n_epochs_tracked': len(self.epoch_stats),
                'key_epochs': self.key_epochs,
                'epochs': {str(e): stats.to_dict() for e, stats in self.epoch_stats.items()},
            }

            summary_path = os.path.join(self.output_dir, "media", "pairwise_distance_summary.json")
            with open(summary_path, 'w') as f:
                json.dump(summary, f, indent=2)

            logger.info(f"Pairwise distance summary saved to: {summary_path}")
            return summary_path

        except Exception as e:
            logger.warning(f"Failed to save pairwise distance summary: {e}")
            return None


def plot_pairwise_distance_distribution(
    off_diag_similarities: "np.ndarray",
    output_dir: str,
    epoch: int,
    n_samples: int,
    tracker: Optional[PairwiseDistanceTracker] = None,
    is_final: bool = False,
) -> Optional[str]:
    """
    Convenience function to plot pairwise distance distribution for an epoch.

    Args:
        off_diag_similarities: 1D array of pairwise cosine similarities (excluding diagonal)
        output_dir: Base output directory
        epoch: Current epoch number
        n_samples: Number of samples in the batch
        tracker: Optional existing tracker (creates new one if None)
        is_final: Whether this is the final epoch

    Returns:
        Path to saved PNG, or None if failed
    """
    if tracker is None:
        tracker = PairwiseDistanceTracker(output_dir)

    stats = tracker.record_epoch(off_diag_similarities, epoch, n_samples, is_final)

    if is_final:
        tracker.save_summary()

    return os.path.join(tracker.media_dir, f"pairwise_distance_epoch_{epoch:04d}.png")
