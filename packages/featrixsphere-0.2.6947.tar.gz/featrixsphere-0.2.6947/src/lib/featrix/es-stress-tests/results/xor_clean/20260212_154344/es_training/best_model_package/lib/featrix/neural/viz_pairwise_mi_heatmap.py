#  -*- coding: utf-8 -*-
#
#  Copyright Featrix, Inc 2023-2025
#
#  Proprietary and Confidential.  Unauthorized use, copying or dissemination
#  of these materials is strictly prohibited.
#
"""
Pairwise Mutual Information Heatmap Visualization.

Generates heatmaps showing pairwise normalized mutual information between columns.
This shows the ground-truth statistical dependencies in the input data, which can
be compared against learned relationships (lift) to validate model learning.

Output structure:
    <output_dir>/
    └── media/
        ├── pairwise_mi/
        │   ├── pairwise_mi_epoch_0000.png
        │   ├── pairwise_mi_epoch_0000.json
        │   └── ...
        └── pairwise_mi.png  # Latest
"""

import logging
import os
import json
from typing import Dict, List, Optional, Tuple, TYPE_CHECKING

if TYPE_CHECKING:
    import numpy as np
    import pandas as pd

# Set matplotlib to use non-interactive Agg backend
import matplotlib
matplotlib.use('Agg')

logger = logging.getLogger(__name__)


def compute_pairwise_mi(
    df: "pd.DataFrame",
    col_names: Optional[List[str]] = None,
    exclude_columns: Optional[List[str]] = None,
) -> Tuple["np.ndarray", List[str]]:
    """
    Compute pairwise normalized mutual information matrix for dataframe columns.

    Args:
        df: Input dataframe
        col_names: Columns to include (default: all columns)
        exclude_columns: Columns to exclude (e.g., target column)

    Returns:
        Tuple of (mi_matrix, col_names) where mi_matrix is (n_cols, n_cols)
    """
    import numpy as np
    from sklearn.metrics import normalized_mutual_info_score

    if col_names is None:
        col_names = list(df.columns)

    if exclude_columns:
        col_names = [c for c in col_names if c not in exclude_columns]

    n_cols = len(col_names)
    mi_matrix = np.zeros((n_cols, n_cols))

    for i, col_i in enumerate(col_names):
        for j, col_j in enumerate(col_names):
            if i == j:
                mi_matrix[i, j] = 1.0  # Self-MI is 1 (normalized)
            elif j > i:
                try:
                    # Convert to categorical for MI computation
                    vals_i = df[col_i].fillna('__NA__').astype(str)
                    vals_j = df[col_j].fillna('__NA__').astype(str)
                    nmi = normalized_mutual_info_score(vals_i, vals_j)
                    mi_matrix[i, j] = nmi
                    mi_matrix[j, i] = nmi  # Symmetric
                except Exception:
                    mi_matrix[i, j] = 0.0
                    mi_matrix[j, i] = 0.0

    return mi_matrix, col_names


def plot_pairwise_mi_heatmap(
    mi_matrix: "np.ndarray",
    col_names: List[str],
    output_dir: str,
    epoch: int,
    lift_matrix: Optional["np.ndarray"] = None,
    title_suffix: str = "",
) -> Optional[str]:
    """
    Plot pairwise mutual information heatmap.

    Optionally overlays or compares with lift matrix to show how learned
    relationships compare to ground-truth statistical dependencies.

    Args:
        mi_matrix: (n_cols, n_cols) pairwise MI matrix
        col_names: List of column names
        output_dir: Base output directory
        epoch: Current epoch number
        lift_matrix: Optional (n_cols, n_cols) lift matrix for comparison
        title_suffix: Optional suffix for title (e.g., "Best" or "Final")

    Returns:
        Path to saved PNG, or None if failed
    """
    try:
        import matplotlib.pyplot as plt
        import numpy as np
        import shutil

        n_cols = len(col_names)

        # Create media directory
        media_dir = os.path.join(output_dir, "media", "pairwise_mi")
        os.makedirs(media_dir, exist_ok=True)

        # Truncate long column names for display
        short_names = [col[:15] if len(col) <= 15 else col[:12] + '...' for col in col_names]

        if lift_matrix is not None:
            # Side-by-side comparison: MI vs Lift
            fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(20, 9))

            # MI heatmap
            im1 = ax1.imshow(mi_matrix, cmap='YlOrRd', aspect='auto', vmin=0, vmax=1)
            cbar1 = fig.colorbar(im1, ax=ax1, shrink=0.8)
            cbar1.ax.set_ylabel('Normalized MI', rotation=-90, va="bottom")
            ax1.set_xticks(np.arange(n_cols))
            ax1.set_yticks(np.arange(n_cols))
            ax1.set_xticklabels(short_names, rotation=45, ha='right', fontsize=7)
            ax1.set_yticklabels(short_names, fontsize=7)
            ax1.set_title('Ground Truth: Pairwise MI', fontsize=11, fontweight='bold')

            # Lift heatmap (normalize to 0-1 for comparison)
            lift_normalized = lift_matrix.copy()
            lift_min, lift_max = np.nanmin(lift_normalized), np.nanmax(lift_normalized)
            if lift_max > lift_min:
                lift_normalized = (lift_normalized - lift_min) / (lift_max - lift_min)

            im2 = ax2.imshow(lift_normalized, cmap='YlOrRd', aspect='auto', vmin=0, vmax=1)
            cbar2 = fig.colorbar(im2, ax=ax2, shrink=0.8)
            cbar2.ax.set_ylabel('Normalized Lift', rotation=-90, va="bottom")
            ax2.set_xticks(np.arange(n_cols))
            ax2.set_yticks(np.arange(n_cols))
            ax2.set_xticklabels(short_names, rotation=45, ha='right', fontsize=7)
            ax2.set_yticklabels(short_names, fontsize=7)
            ax2.set_title('Learned: Pairwise Lift', fontsize=11, fontweight='bold')

            # Add epoch annotation
            title = f'Pairwise Relationships - Epoch {epoch}'
            if title_suffix:
                title += f' ({title_suffix})'
            fig.suptitle(title, fontsize=14, fontweight='bold')

        else:
            # Single MI heatmap
            fig, ax = plt.subplots(figsize=(12, 10))

            im = ax.imshow(mi_matrix, cmap='YlOrRd', aspect='auto', vmin=0, vmax=1)
            cbar = fig.colorbar(im, ax=ax, shrink=0.8)
            cbar.ax.set_ylabel('Normalized Mutual Information', rotation=-90, va="bottom")

            ax.set_xticks(np.arange(n_cols))
            ax.set_yticks(np.arange(n_cols))
            ax.set_xticklabels(short_names, rotation=45, ha='right', fontsize=8)
            ax.set_yticklabels(short_names, fontsize=8)

            title = f'Pairwise Normalized Mutual Information - Epoch {epoch}'
            if title_suffix:
                title += f' ({title_suffix})'
            ax.set_title(title, fontsize=12, fontweight='bold')

            # Epoch annotation in corner
            ax.text(0.02, 0.98, f'Epoch {epoch}', transform=ax.transAxes,
                    fontsize=12, fontweight='bold', va='top',
                    bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))

        plt.tight_layout()

        # Save frame
        frame_path = os.path.join(media_dir, f"pairwise_mi_epoch_{epoch:04d}.png")
        plt.savefig(frame_path, dpi=100, bbox_inches='tight')
        plt.close()

        # Save JSON data
        json_data = {
            'epoch': epoch,
            'col_names': col_names,
            'mi_matrix': mi_matrix.tolist(),
            'has_lift_comparison': lift_matrix is not None,
        }
        if lift_matrix is not None:
            json_data['lift_matrix'] = [[float(x) if not np.isnan(x) else None for x in row] for row in lift_matrix]

        json_path = os.path.join(media_dir, f"pairwise_mi_epoch_{epoch:04d}.json")
        with open(json_path, 'w') as f:
            json.dump(json_data, f, indent=2)

        # Save latest in media/
        media_root = os.path.join(output_dir, "media")
        os.makedirs(media_root, exist_ok=True)
        shutil.copy(frame_path, os.path.join(media_root, "pairwise_mi.png"))

        logger.debug(f"📊 Pairwise MI heatmap saved to: {frame_path}")
        return frame_path

    except Exception as e:
        logger.warning(f"Failed to plot pairwise MI heatmap: {e}")
        import traceback
        traceback.print_exc()
        return None


def get_top_mi_pairs(
    mi_matrix: "np.ndarray",
    col_names: List[str],
    top_k: int = 20,
    min_mi: float = 0.1,
) -> List[Tuple[str, str, float]]:
    """
    Get top K pairs by mutual information.

    Args:
        mi_matrix: (n_cols, n_cols) MI matrix
        col_names: Column names
        top_k: Number of top pairs to return
        min_mi: Minimum MI threshold

    Returns:
        List of (col1, col2, mi_value) tuples, sorted descending
    """
    import numpy as np

    n_cols = len(col_names)
    pairs = []

    for i in range(n_cols):
        for j in range(i + 1, n_cols):
            mi_val = mi_matrix[i, j]
            if mi_val >= min_mi:
                pairs.append((col_names[i], col_names[j], float(mi_val)))

    pairs.sort(key=lambda x: x[2], reverse=True)
    return pairs[:top_k]


def compute_mi_lift_correlation(
    mi_matrix: "np.ndarray",
    lift_matrix: "np.ndarray",
    col_names: List[str],
) -> Dict:
    """
    Compute correlation between MI (ground truth) and Lift (learned).

    High correlation indicates the model is learning real statistical relationships.

    Args:
        mi_matrix: Ground truth pairwise MI
        lift_matrix: Learned pairwise lift
        col_names: Column names

    Returns:
        Dict with correlation stats
    """
    import numpy as np

    n_cols = len(col_names)

    # Extract upper triangle (excluding diagonal)
    mi_vals = []
    lift_vals = []

    for i in range(n_cols):
        for j in range(i + 1, n_cols):
            mi_val = mi_matrix[i, j]
            lift_val = lift_matrix[i, j]
            if not np.isnan(mi_val) and not np.isnan(lift_val):
                mi_vals.append(mi_val)
                lift_vals.append(lift_val)

    if len(mi_vals) < 3:
        return {'correlation': None, 'n_pairs': len(mi_vals), 'error': 'Not enough pairs'}

    mi_arr = np.array(mi_vals)
    lift_arr = np.array(lift_vals)

    # Pearson correlation
    correlation = np.corrcoef(mi_arr, lift_arr)[0, 1]

    # Find high-MI pairs that also have high lift
    high_mi_mask = mi_arr > np.percentile(mi_arr, 75)
    high_lift_mask = lift_arr > np.percentile(lift_arr, 75)
    overlap = np.sum(high_mi_mask & high_lift_mask)

    return {
        'correlation': float(correlation),
        'n_pairs': len(mi_vals),
        'high_mi_high_lift_overlap': int(overlap),
        'high_mi_count': int(np.sum(high_mi_mask)),
        'high_lift_count': int(np.sum(high_lift_mask)),
    }
