#!/usr/bin/env python3
#  -*- coding: utf-8 -*-
#
#  Copyright Featrix, Inc 2023-2025
#
#  ES Stress Test Runner
#
#  Usage:
#    python src/lib/featrix/es-stress-tests/run.py --config configs/dominant_feature.json
#
from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import logging
import os
import pickle
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, roc_auc_score, f1_score
from sklearn.model_selection import train_test_split

# Set up path for imports
_this_dir = Path(__file__).parent
_lib_dir = _this_dir.parent.parent  # src/lib
if str(_lib_dir) not in sys.path:
    sys.path.insert(0, str(_lib_dir))
# Also add the es-stress-tests dir for local generator imports
if str(_this_dir) not in sys.path:
    sys.path.insert(0, str(_this_dir))

from featrix.neural.logging_config import configure_logging
configure_logging(job_prefix="es-stress-test")

from featrix.neural.input_data_set import FeatrixInputDataSet
from featrix.neural.embedded_space import EmbeddingSpace
from featrix.neural.single_predictor import FeatrixSinglePredictor
from featrix.neural.gpu_utils import get_device

# Import generators - use absolute import since directory has hyphen
# pylint: disable=import-error
from generators import (
    Generator,
    DominantFeatureGenerator,
    XORClassificationGenerator,
    RareCategoryGenerator,
)
# pylint: enable=import-error

logger = logging.getLogger(__name__)

# Registry of available generators
GENERATORS: dict[str, type[Generator]] = {
    "dominant_feature_threshold": DominantFeatureGenerator,
    "xor_classification": XORClassificationGenerator,
    "rare_category_lookup": RareCategoryGenerator,
}

# Path to master dataset
MASTER_DATASET_PATH = Path(__file__).parent / "data" / "master.csv"
MASTER_SCHEMA_PATH = Path(__file__).parent / "data" / "master_schema.json"


def get_git_commit() -> str | None:
    """Get current git commit hash, or None if not in a git repo."""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            return result.stdout.strip()[:12]
    except Exception:
        pass
    return None


def compute_config_hash(config: dict) -> str:
    """Compute a hash of the config for reproducibility tracking."""
    config_str = json.dumps(config, sort_keys=True)
    return hashlib.sha256(config_str.encode()).hexdigest()[:12]


def load_config(config_path: Path) -> dict:
    """Load configuration from JSON file."""
    with open(config_path) as f:
        return json.load(f)


def create_run_id() -> str:
    """Create a unique run ID based on timestamp."""
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def load_master_view(config: dict) -> tuple[pd.DataFrame, dict]:
    """
    Load a view from the master dataset based on config.

    Config should have:
        - features: list of column names to include as features
        - label: name of label column to use
        - (optional) n_rows: limit rows (default: all)
    """
    view_config = config.get("view", {})
    feature_cols = view_config.get("features", [])
    label_col = view_config.get("label")

    if not feature_cols or not label_col:
        raise ValueError("View config must specify 'features' and 'label'")

    # Load master dataset
    if not MASTER_DATASET_PATH.exists():
        raise FileNotFoundError(f"Master dataset not found: {MASTER_DATASET_PATH}")

    logger.info(f"📊 Loading view from master dataset")
    master_df = pd.read_csv(MASTER_DATASET_PATH)

    # Load schema for metadata
    with open(MASTER_SCHEMA_PATH) as f:
        master_schema = json.load(f)

    # Validate columns exist
    all_cols = feature_cols + [label_col]
    missing = set(all_cols) - set(master_df.columns)
    if missing:
        raise ValueError(f"Columns not found in master dataset: {missing}")

    # Select columns and rename label
    df = master_df[all_cols].copy()
    df = df.rename(columns={label_col: "label"})

    # Optional row limit
    n_rows = view_config.get("n_rows")
    if n_rows and n_rows < len(df):
        df = df.head(n_rows)

    # Build metadata
    metadata = {
        "source": "master_dataset",
        "view_config": view_config,
        "feature_columns": feature_cols,
        "label_column": label_col,
        "n_rows": len(df),
        "label_schema": master_schema["columns"].get(label_col, {}),
        "feature_schemas": {c: master_schema["columns"].get(c, {}) for c in feature_cols},
    }

    logger.info(f"   Loaded {len(df)} rows, {len(feature_cols)} features + label")
    logger.info(f"   Features: {feature_cols[:5]}{'...' if len(feature_cols) > 5 else ''}")
    logger.info(f"   Label: {label_col}")
    logger.info(f"   Label distribution: {df['label'].value_counts().to_dict()}")

    return df, metadata


def generate_data(config: dict) -> tuple[pd.DataFrame, dict]:
    """Generate or load data based on config."""

    # New style: load view from master dataset
    if "view" in config:
        return load_master_view(config)

    # Legacy style: use generator
    generator_name = config.get("generator_name")
    if not generator_name:
        raise ValueError("Config must have either 'view' or 'generator_name'")

    generator_params = config.get("generator_params", {})

    if generator_name not in GENERATORS:
        raise ValueError(
            f"Unknown generator: {generator_name}. "
            f"Available: {list(GENERATORS.keys())}"
        )

    generator = GENERATORS[generator_name]()
    logger.info(f"📊 Generating data with {generator_name}")

    df, metadata = generator.generate(**generator_params)

    logger.info(f"   Generated {len(df)} rows, {len(df.columns)} columns")
    logger.info(f"   Label distribution: {df['label'].value_counts().to_dict()}")

    return df, metadata


def train_embedding_space(
    full_df: pd.DataFrame,
    es_params: dict,
    output_dir: Path,
    val_fraction: float = 0.2,
) -> EmbeddingSpace:
    """Train EmbeddingSpace on the data.

    CRITICAL: Create ONE FeatrixInputDataSet for the full data, then split.
    This ensures column type detection happens on the full dataset and
    is preserved for both train and val splits.
    """
    logger.info("🧠 Training EmbeddingSpace")

    # Create input dataset for FULL data (excluding label column for ES training)
    feature_cols = [c for c in full_df.columns if c != "label"]
    full_features = full_df[feature_cols]

    # Create ONE dataset for the full data - detection happens here
    full_input = FeatrixInputDataSet(
        df=full_features,
        dataset_title="stress_test_full",
    )

    # Split AFTER detection - detected types are preserved for both splits
    train_input, val_input = full_input.split(fraction=val_fraction)

    # Extract ES constructor params
    d_model = es_params.get("d_model", 128)
    n_epochs = es_params.get("n_epochs", 25)
    n_transformer_layers = es_params.get("n_transformer_layers", 2)
    n_attention_heads = es_params.get("n_attention_heads", 8)

    # Create EmbeddingSpace
    es = EmbeddingSpace(
        train_input_data=train_input,
        val_input_data=val_input,
        d_model=d_model,
        n_epochs=n_epochs,
        n_transformer_layers=n_transformer_layers,
        n_attention_heads=n_attention_heads,
        output_dir=str(output_dir / "es_training"),
        name="stress_test_es",
    )

    # Extract training params
    batch_size = es_params.get("batch_size", 64)
    train_epochs = es_params.get("n_epochs", 25)

    # Train
    es.train(
        n_epochs=train_epochs,
        batch_size=batch_size,
        save_state_after_every_epoch=False,  # Don't save checkpoints for stress tests
        enable_weightwatcher=False,  # Skip weightwatcher for speed
        disable_recovery=True,  # Always train fresh
    )

    return es


async def train_predictor(
    es: EmbeddingSpace,
    train_val_df: pd.DataFrame,
    predictor_params: dict,
) -> FeatrixSinglePredictor:
    """Train predictor on top of ES embeddings.

    Uses the same train_val data that ES used - predictor will use
    the ES's internal train/val split for consistency.
    """
    logger.info("🎯 Training Predictor")

    # Create predictor
    predictor = FeatrixSinglePredictor(es)

    # Prep for training - use the full train_val_df
    predictor.prep_for_training(
        train_val_df,
        target_col_name="label",
        target_col_type="set",  # Binary classification
        use_class_weights=predictor_params.get("use_class_weights", True),
    )

    # Train
    n_epochs = predictor_params.get("n_epochs", 25)
    batch_size = predictor_params.get("batch_size", 64)
    fine_tune = predictor_params.get("fine_tune", True)

    await predictor.train(
        n_epochs=n_epochs,
        batch_size=batch_size,
        fine_tune=fine_tune,
        capture_epoch_predictions=False,  # Skip for speed in stress tests
    )

    return predictor


def evaluate_predictor(
    predictor: FeatrixSinglePredictor,
    test_df: pd.DataFrame,
    metrics_list: list[str],
) -> dict[str, float]:
    """Evaluate predictor on test set."""
    logger.info("📈 Evaluating Predictor")

    # Get label_schema from predictor - single source of truth for label handling
    label_schema = getattr(predictor, 'label_schema', None)
    if label_schema:
        logger.info(f"   Using label_schema: {label_schema}")
    else:
        logger.warning("   ⚠️  No label_schema on predictor - falling back to ad-hoc handling")

    # Get predictions using batched prediction (much faster than one-by-one)
    feature_cols = [c for c in test_df.columns if c != "label"]
    y_true_raw = test_df["label"].values

    # Convert to list of records for predict_batch
    records = test_df[feature_cols].to_dict(orient='records')

    # Batch predict - use large batch size for GPU efficiency
    results = predictor.predict_batch(records, batch_size=256)

    # Extract predictions and probabilities from results
    predictions = []
    probabilities = []
    for result in results:
        predictions.append(result.get("prediction", 0))
        probs = result.get("probabilities", {})
        if label_schema:
            prob_pos = label_schema.get_pos_prob(probs)
        else:
            prob_pos = probs.get("1", probs.get(1, 0.5))
        probabilities.append(prob_pos)

    y_pred_raw = np.array(predictions)
    y_prob = np.array(probabilities)

    # Use label_schema to prepare labels for sklearn (handles type matching)
    if label_schema:
        y_true, y_pred, _, pos_label = label_schema.prepare_for_sklearn(y_true_raw, y_pred_raw)
    else:
        # Fallback: convert both to strings for consistent comparison
        y_true = np.array([str(v) for v in y_true_raw])
        y_pred = np.array([str(v) for v in y_pred_raw])
        pos_label = "1"

    # Debug: log sample of predictions
    logger.info(f"   DEBUG: y_true sample: {y_true[:10]}")
    logger.info(f"   DEBUG: y_pred sample: {y_pred[:10]}")
    logger.info(f"   DEBUG: y_prob sample: {y_prob[:10]}")
    logger.info(f"   DEBUG: y_true unique: {np.unique(y_true)}")
    logger.info(f"   DEBUG: y_pred unique: {np.unique(y_pred)}")
    logger.info(f"   DEBUG: pos_label for sklearn: {pos_label}")

    # Compute metrics
    metrics = {}

    if "accuracy" in metrics_list:
        metrics["accuracy"] = float(accuracy_score(y_true, y_pred))

    if "auc" in metrics_list:
        try:
            metrics["auc"] = float(roc_auc_score(y_true, y_prob))
        except ValueError:
            # AUC undefined if only one class present
            metrics["auc"] = None

    if "f1" in metrics_list:
        metrics["f1"] = float(f1_score(y_true, y_pred, average="binary", pos_label=pos_label))

    return metrics


def write_results(
    run_dir: Path,
    config: dict,
    data_metadata: dict,
    metrics: dict,
    timing: dict,
) -> None:
    """Write all results to the run directory."""
    run_dir.mkdir(parents=True, exist_ok=True)

    # Write metrics.json
    metrics_output = {
        "metrics": metrics,
        "timing": timing,
        "config_hash": compute_config_hash(config),
        "git_commit": get_git_commit(),
        "run_timestamp": datetime.now().isoformat(),
    }
    with open(run_dir / "metrics.json", "w") as f:
        json.dump(metrics_output, f, indent=2)

    # Write resolved config
    with open(run_dir / "config_resolved.json", "w") as f:
        json.dump(config, f, indent=2)

    # Write data metadata
    with open(run_dir / "data_metadata.json", "w") as f:
        json.dump(data_metadata, f, indent=2, default=str)

    # Write summary markdown
    summary = generate_summary(config, data_metadata, metrics, timing)
    with open(run_dir / "summary.md", "w") as f:
        f.write(summary)

    logger.info(f"✅ Results written to {run_dir}")


def generate_summary(
    config: dict,
    data_metadata: dict,
    metrics: dict,
    timing: dict,
) -> str:
    """Generate a markdown summary of the run."""
    lines = [
        "# ES Stress Test Run Summary",
        "",
        f"**Run Time**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"**Git Commit**: {get_git_commit() or 'N/A'}",
        "",
        "## Configuration",
        "",
    ]

    # Handle both view-based and generator-based configs
    if "view" in config:
        view = config["view"]
        lines.append(f"- **Source**: Master Dataset View")
        lines.append(f"- **Features**: {view.get('features', 'N/A')}")
        lines.append(f"- **Label**: {view.get('label', 'N/A')}")
        lines.append(f"- **Rows**: {data_metadata.get('n_rows', 'N/A')}")
    else:
        lines.append(f"- **Generator**: {config.get('generator_name', 'N/A')}")
        gen_params = config.get('generator_params', {})
        lines.append(f"- **Rows**: {gen_params.get('n_rows', 'N/A')}")
        lines.append(f"- **Seed**: {gen_params.get('seed', 'N/A')}")

    lines.extend(["", "## Ground Truth", ""])

    gt = data_metadata.get("ground_truth", {})
    lines.append(f"- **Relationship**: {gt.get('relationship', 'N/A')}")
    lines.append(f"- **Formula**: `{gt.get('formula', 'N/A')}`")
    lines.append(f"- **Informative Columns**: {gt.get('informative_columns', [])}")
    lines.append("")

    lines.extend([
        "## Results",
        "",
        "| Metric | Value |",
        "|--------|-------|",
    ])

    for metric_name, value in metrics.items():
        if value is not None:
            lines.append(f"| {metric_name} | {value:.4f} |")
        else:
            lines.append(f"| {metric_name} | N/A |")

    lines.extend([
        "",
        "## Timing",
        "",
    ])

    for phase, duration in timing.items():
        lines.append(f"- **{phase}**: {duration:.2f}s")

    lines.extend([
        "",
        "## Generator Parameters",
        "",
        "```json",
        json.dumps(config.get("generator_params", {}), indent=2),
        "```",
    ])

    return "\n".join(lines)


async def run_stress_test(config: dict, results_base: Path) -> dict:
    """Run a complete stress test based on config."""
    run_id = create_run_id()
    run_dir = results_base / run_id

    logger.info(f"🚀 Starting stress test run: {run_id}")
    logger.info(f"   Config: {config.get('name', 'unnamed')}")

    timing = {}

    # Generate data
    t0 = time.time()
    df, data_metadata = generate_data(config)
    timing["data_generation"] = time.time() - t0

    # Split data: first split off test set, then pass train_val to ES for internal split
    eval_params = config.get("evaluation", {})
    split_seed = eval_params.get("split_seed", 42)
    test_fraction = eval_params.get("test_fraction", 0.2)
    val_fraction = eval_params.get("val_fraction", 0.1)

    # Split off test set
    train_val_df, test_df = train_test_split(
        df, test_size=test_fraction, random_state=split_seed, stratify=df["label"]
    )

    # Calculate val fraction relative to train_val (for FeatrixInputDataSet.split())
    val_fraction_adjusted = val_fraction / (1 - test_fraction)

    logger.info(f"   Split: train_val={len(train_val_df)}, test={len(test_df)}")

    # Train ES - pass full train_val, it will split internally preserving detected types
    t0 = time.time()
    es_params = config.get("embedding_space", {})
    es = train_embedding_space(train_val_df, es_params, run_dir, val_fraction=val_fraction_adjusted)
    timing["es_training"] = time.time() - t0

    # Train predictor - use train_val_df (predictor will use ES's train/val split)
    t0 = time.time()
    predictor_params = config.get("predictor", {})
    predictor = await train_predictor(es, train_val_df, predictor_params)
    timing["predictor_training"] = time.time() - t0

    # Evaluate using the saved pickle to ensure consistency
    # The saved pickle is the source of truth for production predictions
    t0 = time.time()
    metrics_list = eval_params.get("metrics", ["accuracy", "auc", "f1"])

    # Load predictor from pickle for evaluation (same as production inference)
    best_pickle_path = run_dir / "es_training" / "best_single_predictor.pickle"
    if best_pickle_path.exists():
        logger.info(f"📦 Loading predictor from pickle for evaluation: {best_pickle_path}")
        with open(best_pickle_path, "rb") as f:
            eval_predictor = pickle.load(f)
        metrics = evaluate_predictor(eval_predictor, test_df, metrics_list)
    else:
        # Fallback to in-memory predictor if pickle doesn't exist
        logger.warning("⚠️  best_single_predictor.pickle not found, using in-memory predictor")
        metrics = evaluate_predictor(predictor, test_df, metrics_list)
    timing["evaluation"] = time.time() - t0

    # Log results
    logger.info("📊 Results:")
    for metric_name, value in metrics.items():
        if value is not None:
            logger.info(f"   {metric_name}: {value:.4f}")

    # Write results
    write_results(run_dir, config, data_metadata, metrics, timing)

    # Save artifacts if requested
    artifacts_dir = run_dir / "artifacts"
    if config.get("save_artifacts", False):
        artifacts_dir.mkdir(exist_ok=True)

        # Save ES pickle
        with open(artifacts_dir / "embedding_space.pickle", "wb") as f:
            pickle.dump(es, f)

        # Save test predictions
        test_df_copy = test_df.copy()
        test_df_copy.to_parquet(artifacts_dir / "test_data.parquet")

        logger.info(f"   Artifacts saved to {artifacts_dir}")

    return {
        "run_id": run_id,
        "metrics": metrics,
        "timing": timing,
        "run_dir": str(run_dir),
    }


def main():
    parser = argparse.ArgumentParser(
        description="ES Stress Test Runner",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python -m featrix.es_stress_tests.run --config configs/dominant_feature.json
  python -m featrix.es_stress_tests.run --config configs/xor.json --results-dir /tmp/stress_results
        """,
    )
    parser.add_argument(
        "--config",
        type=str,
        required=True,
        help="Path to config JSON file",
    )
    parser.add_argument(
        "--results-dir",
        type=str,
        default=None,
        help="Base directory for results (default: es-stress-tests/results/)",
    )
    args = parser.parse_args()

    # Determine paths
    config_path = Path(args.config)
    if not config_path.is_absolute():
        # Try relative to stress tests dir first
        stress_test_dir = Path(__file__).parent
        if (stress_test_dir / config_path).exists():
            config_path = stress_test_dir / config_path
        elif not config_path.exists():
            # Try relative to current dir
            pass

    if not config_path.exists():
        print(f"❌ Config file not found: {config_path}")
        sys.exit(1)

    # Results directory
    if args.results_dir:
        results_base = Path(args.results_dir)
    else:
        results_base = Path(__file__).parent / "results"

    # Load config
    config = load_config(config_path)
    config_name = config_path.stem

    # Add config name to results path
    results_dir = results_base / config_name

    logger.info(f"📁 Config: {config_path}")
    logger.info(f"📁 Results: {results_dir}")

    # Run
    result = asyncio.run(run_stress_test(config, results_dir))

    print("\n" + "=" * 60)
    print("✅ STRESS TEST COMPLETE")
    print("=" * 60)
    print(f"Run ID: {result['run_id']}")
    print(f"Results: {result['run_dir']}")
    print("\nMetrics:")
    for metric, value in result["metrics"].items():
        if value is not None:
            print(f"  {metric}: {value:.4f}")
    print("\nTiming:")
    for phase, duration in result["timing"].items():
        print(f"  {phase}: {duration:.2f}s")


if __name__ == "__main__":
    main()
