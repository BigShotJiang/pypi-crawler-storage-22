#!/bin/bash
#
# Run all ES stress tests
#
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../../../.." && pwd)"

usage() {
    echo "Usage: $0 [OPTIONS] [CONFIG_PATTERN]"
    echo ""
    echo "Run ES stress tests."
    echo ""
    echo "Arguments:"
    echo "  CONFIG_PATTERN    Glob pattern for configs (default: configs/*.json)"
    echo "                    Examples: configs/smoke*.json, configs/xor_clean.json"
    echo ""
    echo "Options:"
    echo "  -h, --help        Show this help message"
    echo "  -l, --list        List available config files"
    echo "  --results-dir DIR Override results directory"
    echo ""
    echo "Examples:"
    echo "  $0                          # Run all tests"
    echo "  $0 configs/smoke_test.json  # Run single test"
    echo "  $0 'configs/xor_*.json'     # Run all XOR tests"
    echo "  $0 -l                       # List available configs"
}

list_configs() {
    echo "Available configs:"
    for config in "$SCRIPT_DIR"/configs/*.json; do
        echo "  $(basename "$config")"
    done
}

# Parse arguments
CONFIG_PATTERN=""
RESULTS_DIR=""

while [[ $# -gt 0 ]]; do
    case $1 in
        -h|--help)
            usage
            exit 0
            ;;
        -l|--list)
            list_configs
            exit 0
            ;;
        --results-dir)
            RESULTS_DIR="$2"
            shift 2
            ;;
        *)
            CONFIG_PATTERN="$1"
            shift
            ;;
    esac
done

export PYTHONPATH="${REPO_ROOT}/src/lib:${PYTHONPATH:-}"

# Use sphere venv if available (on compute nodes), otherwise fall back to python3
if [ -f "/sphere/.venv/bin/python" ]; then
    PYTHON="/sphere/.venv/bin/python"
elif [ -f "${REPO_ROOT}/.venv/bin/python" ]; then
    PYTHON="${REPO_ROOT}/.venv/bin/python"
else
    PYTHON="python3"
fi

cd "$SCRIPT_DIR"

echo "========================================"
echo "ES Stress Tests"
echo "========================================"
echo "Script dir: $SCRIPT_DIR"
echo "Repo root: $REPO_ROOT"
echo "Python: $PYTHON"
echo "PYTHONPATH: $PYTHONPATH"
echo ""

# Default to all configs
if [ -z "$CONFIG_PATTERN" ]; then
    CONFIG_PATTERN="configs/*.json"
fi

# Build extra args
EXTRA_ARGS=""
if [ -n "$RESULTS_DIR" ]; then
    EXTRA_ARGS="--results-dir $RESULTS_DIR"
fi

# Run tests
for config in $CONFIG_PATTERN; do
    if [ ! -f "$config" ]; then
        echo "❌ Config not found: $config"
        exit 1
    fi
    echo ""
    echo "========================================"
    echo "Running: $config"
    echo "========================================"
    $PYTHON run.py --config "$config" $EXTRA_ARGS || exit 1
done

echo ""
echo "✅ All stress tests completed!"
