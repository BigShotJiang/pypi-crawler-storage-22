#!/usr/bin/env python3
#  -*- coding: utf-8 -*-
#
#  Copyright Featrix, Inc 2023-2025
#
#  Unit tests for ES Stress Test generators
#
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

# Set up path for imports
_this_dir = Path(__file__).parent
_stress_tests_dir = _this_dir.parent  # es-stress-tests
_lib_dir = _stress_tests_dir.parent.parent  # src/lib
if str(_lib_dir) not in sys.path:
    sys.path.insert(0, str(_lib_dir))
if str(_stress_tests_dir) not in sys.path:
    sys.path.insert(0, str(_stress_tests_dir))

# pylint: disable=import-error,wrong-import-position
from generators import (
    DominantFeatureGenerator,
    XORClassificationGenerator,
    RareCategoryGenerator,
)
# pylint: enable=import-error,wrong-import-position


class TestDominantFeatureGenerator:
    """Tests for DominantFeatureGenerator."""

    def test_basic_generation(self):
        """Test basic data generation."""
        gen = DominantFeatureGenerator()
        df, metadata = gen.generate(n_rows=100, seed=42)

        # Check shape
        assert len(df) == 100
        assert "signal" in df.columns
        assert "label" in df.columns

        # Check metadata
        assert metadata["generator_name"] == "dominant_feature_threshold"
        assert metadata["n_rows"] == 100
        assert metadata["seed"] == 42

    def test_determinism(self):
        """Test that same seed produces identical output."""
        gen = DominantFeatureGenerator()

        df1, meta1 = gen.generate(n_rows=100, seed=42)
        df2, meta2 = gen.generate(n_rows=100, seed=42)

        pd.testing.assert_frame_equal(df1, df2)
        assert meta1 == meta2

    def test_different_seeds(self):
        """Test that different seeds produce different output."""
        gen = DominantFeatureGenerator()

        df1, _ = gen.generate(n_rows=100, seed=42)
        df2, _ = gen.generate(n_rows=100, seed=43)

        # DataFrames should differ
        assert not df1["signal"].equals(df2["signal"])

    def test_label_distribution(self):
        """Test that label distribution is approximately as expected."""
        gen = DominantFeatureGenerator()

        # With imbalance_ratio=0.3, expect ~30% positive
        df, _ = gen.generate(n_rows=1000, seed=42, imbalance_ratio=0.3, p_flip=0.0)
        positive_rate = df["label"].mean()

        # Allow 5% tolerance
        assert 0.25 <= positive_rate <= 0.35, f"Expected ~0.3, got {positive_rate}"

    def test_noise_dimensions(self):
        """Test that noise dimensions are created."""
        gen = DominantFeatureGenerator()
        df, metadata = gen.generate(n_rows=100, seed=42, n_noise_dims=5)

        noise_cols = [c for c in df.columns if c.startswith("noise_")]
        assert len(noise_cols) == 5

        # Check ground truth records them
        assert len(metadata["ground_truth"]["noise_columns"]) == 5

    def test_label_noise(self):
        """Test that label noise is applied correctly."""
        gen = DominantFeatureGenerator()

        # With p_flip=0, labels should match threshold exactly
        df_clean, _ = gen.generate(n_rows=1000, seed=42, p_flip=0.0)

        # With p_flip=0.5, labels should be ~random
        df_noisy, _ = gen.generate(n_rows=1000, seed=42, p_flip=0.5)

        # Noisy labels should be more balanced (closer to 0.5)
        clean_rate = df_clean["label"].mean()
        noisy_rate = df_noisy["label"].mean()

        # Noisy should be closer to 0.5
        assert abs(noisy_rate - 0.5) <= abs(clean_rate - 0.5) + 0.1


class TestXORClassificationGenerator:
    """Tests for XORClassificationGenerator."""

    def test_basic_generation(self):
        """Test basic data generation."""
        gen = XORClassificationGenerator()
        df, metadata = gen.generate(n_rows=100, seed=42)

        # Check shape
        assert len(df) == 100
        assert "signal_1" in df.columns
        assert "signal_2" in df.columns
        assert "label" in df.columns

        # Check metadata
        assert metadata["generator_name"] == "xor_classification"
        assert metadata["ground_truth"]["relationship"] == "xor"

    def test_determinism(self):
        """Test that same seed produces identical output."""
        gen = XORClassificationGenerator()

        df1, meta1 = gen.generate(n_rows=100, seed=42)
        df2, meta2 = gen.generate(n_rows=100, seed=42)

        pd.testing.assert_frame_equal(df1, df2)

    def test_xor_relationship(self):
        """Test that XOR relationship holds (without noise)."""
        gen = XORClassificationGenerator()
        df, metadata = gen.generate(
            n_rows=1000,
            seed=42,
            p_flip=0.0,
            threshold1=0.5,
            threshold2=0.5,
        )

        # Verify XOR: Y=1 when exactly one signal is above threshold
        s1_high = df["signal_1"] > 0.5
        s2_high = df["signal_2"] > 0.5
        expected_y = (s1_high ^ s2_high).astype(int)

        # Should match exactly (no noise)
        np.testing.assert_array_equal(df["label"].values, expected_y.values)

    def test_balanced_labels(self):
        """Test that XOR produces approximately balanced labels."""
        gen = XORClassificationGenerator()
        df, _ = gen.generate(n_rows=1000, seed=42, p_flip=0.0)

        positive_rate = df["label"].mean()
        # XOR with uniform thresholds at 0.5 should give ~50% positive
        assert 0.45 <= positive_rate <= 0.55

    def test_correlation(self):
        """Test that signal correlation works."""
        gen = XORClassificationGenerator()

        # High correlation
        df_corr, _ = gen.generate(n_rows=1000, seed=42, correlation=0.8)
        corr = df_corr["signal_1"].corr(df_corr["signal_2"])
        assert corr > 0.7

        # No correlation
        df_indep, _ = gen.generate(n_rows=1000, seed=42, correlation=0.0)
        corr = df_indep["signal_1"].corr(df_indep["signal_2"])
        assert abs(corr) < 0.15


class TestRareCategoryGenerator:
    """Tests for RareCategoryGenerator."""

    def test_basic_generation(self):
        """Test basic data generation."""
        gen = RareCategoryGenerator()
        df, metadata = gen.generate(n_rows=100, seed=42)

        # Check shape
        assert len(df) == 100
        assert "category" in df.columns
        assert "label" in df.columns

        # Check metadata
        assert metadata["generator_name"] == "rare_category_lookup"
        assert "lookup_table" in metadata["ground_truth"]

    def test_determinism(self):
        """Test that same seed produces identical output."""
        gen = RareCategoryGenerator()

        df1, meta1 = gen.generate(n_rows=100, seed=42)
        df2, meta2 = gen.generate(n_rows=100, seed=42)

        pd.testing.assert_frame_equal(df1, df2)

    def test_category_frequencies(self):
        """Test that positive categories are rare."""
        gen = RareCategoryGenerator()
        df, metadata = gen.generate(
            n_rows=10000,
            seed=42,
            n_categories=20,
            n_positive_categories=5,
            rare_category_freq=0.02,
        )

        positive_cats = set(metadata["ground_truth"]["positive_categories"])
        cat_counts = df["category"].value_counts(normalize=True)

        # Positive categories should each be ~2%
        for cat in positive_cats:
            if cat in cat_counts:
                assert cat_counts[cat] < 0.05, f"{cat} frequency too high: {cat_counts[cat]}"

    def test_lookup_correctness(self):
        """Test that labels match lookup table (without noise)."""
        gen = RareCategoryGenerator()
        df, metadata = gen.generate(n_rows=1000, seed=42, p_flip=0.0)

        lookup = metadata["ground_truth"]["lookup_table"]

        # Every row's label should match lookup
        for _, row in df.iterrows():
            expected = lookup[row["category"]]
            assert row["label"] == expected

    def test_noise_categorical_columns(self):
        """Test that noise categorical columns are created."""
        gen = RareCategoryGenerator()
        df, metadata = gen.generate(
            n_rows=100,
            seed=42,
            n_noise_categorical=3,
            noise_categorical_cardinality=5,
        )

        noise_cat_cols = [c for c in df.columns if c.startswith("noise_cat_")]
        assert len(noise_cat_cols) == 3

        # Each should have <=5 unique values
        for col in noise_cat_cols:
            assert df[col].nunique() <= 5


class TestGeneratorInterface:
    """Tests for the common Generator interface."""

    @pytest.mark.parametrize("generator_class", [
        DominantFeatureGenerator,
        XORClassificationGenerator,
        RareCategoryGenerator,
    ])
    def test_has_name(self, generator_class):
        """Test that all generators have a name."""
        gen = generator_class()
        assert isinstance(gen.name, str)
        assert len(gen.name) > 0

    @pytest.mark.parametrize("generator_class", [
        DominantFeatureGenerator,
        XORClassificationGenerator,
        RareCategoryGenerator,
    ])
    def test_returns_dataframe_and_metadata(self, generator_class):
        """Test that generate returns (DataFrame, dict)."""
        gen = generator_class()
        result = gen.generate(n_rows=50, seed=42)

        assert isinstance(result, tuple)
        assert len(result) == 2
        assert isinstance(result[0], pd.DataFrame)
        assert isinstance(result[1], dict)

    @pytest.mark.parametrize("generator_class", [
        DominantFeatureGenerator,
        XORClassificationGenerator,
        RareCategoryGenerator,
    ])
    def test_has_label_column(self, generator_class):
        """Test that all generators produce a 'label' column."""
        gen = generator_class()
        df, _ = gen.generate(n_rows=50, seed=42)
        assert "label" in df.columns

    @pytest.mark.parametrize("generator_class", [
        DominantFeatureGenerator,
        XORClassificationGenerator,
        RareCategoryGenerator,
    ])
    def test_metadata_structure(self, generator_class):
        """Test that metadata has required fields."""
        gen = generator_class()
        _, metadata = gen.generate(n_rows=50, seed=42)

        assert "generator_name" in metadata
        assert "generator_params" in metadata
        assert "ground_truth" in metadata
        assert "n_rows" in metadata
        assert "seed" in metadata


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
