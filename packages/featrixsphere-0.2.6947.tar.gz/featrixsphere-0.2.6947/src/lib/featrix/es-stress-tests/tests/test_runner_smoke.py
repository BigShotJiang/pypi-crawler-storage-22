#!/usr/bin/env python3
#  -*- coding: utf-8 -*-
#
#  Copyright Featrix, Inc 2023-2025
#
#  Smoke test for ES Stress Test runner
#
#  This test verifies the pipeline runs end-to-end with a tiny dataset.
#  It does NOT test model quality - just that all components work together.
#
from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

import pytest

# Set up path for imports
_this_dir = Path(__file__).parent
_stress_tests_dir = _this_dir.parent  # es-stress-tests
_lib_dir = _stress_tests_dir.parent.parent  # src/lib
if str(_lib_dir) not in sys.path:
    sys.path.insert(0, str(_lib_dir))
if str(_stress_tests_dir) not in sys.path:
    sys.path.insert(0, str(_stress_tests_dir))

# Note: 'run' module is imported inside test functions after sys.path is set
# pylint: disable=import-error,wrong-import-position,import-outside-toplevel


class TestRunnerSmoke:
    """Smoke tests for the stress test runner."""

    def test_load_master_view(self):
        """Test that views can be loaded from master dataset."""
        from run import generate_data

        config = {
            "view": {
                "features": ["threshold_signal", "noise_gaussian_01", "noise_gaussian_02"],
                "label": "label_threshold_clean",
                "n_rows": 100,
            },
        }

        df, metadata = generate_data(config)

        assert len(df) == 100
        assert "label" in df.columns
        assert "threshold_signal" in df.columns
        assert metadata["source"] == "master_dataset"

    def test_legacy_generator(self):
        """Test that legacy generators still work."""
        from run import generate_data

        config = {
            "generator_name": "dominant_feature_threshold",
            "generator_params": {
                "n_rows": 100,
                "seed": 42,
                "n_noise_dims": 3,
            },
        }

        df, metadata = generate_data(config)

        assert len(df) == 100
        assert "label" in df.columns
        assert metadata["generator_name"] == "dominant_feature_threshold"

    def test_config_hash(self):
        """Test that config hashing is deterministic."""
        from run import compute_config_hash

        config = {"a": 1, "b": {"c": 2}}

        hash1 = compute_config_hash(config)
        hash2 = compute_config_hash(config)

        assert hash1 == hash2
        assert len(hash1) == 12

    def test_run_id_generation(self):
        """Test that run IDs are generated."""
        from run import create_run_id

        run_id = create_run_id()

        assert len(run_id) > 0
        assert "_" in run_id  # Format: YYYYMMDD_HHMMSS

    def test_load_config(self):
        """Test that configs can be loaded."""
        from run import load_config

        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            json.dump({"test": "value"}, f)
            f.flush()

            config = load_config(Path(f.name))
            assert config == {"test": "value"}

    def test_generator_registry(self):
        """Test that all generators are registered."""
        from run import GENERATORS

        assert "dominant_feature_threshold" in GENERATORS
        assert "xor_classification" in GENERATORS
        assert "rare_category_lookup" in GENERATORS

    def test_all_configs_load(self):
        """Test that all config files in configs/ can load data."""
        from run import load_config, generate_data

        configs_dir = _stress_tests_dir / "configs"
        for cfg_file in configs_dir.glob("*.json"):
            config = load_config(cfg_file)
            df, metadata = generate_data(config)
            assert len(df) > 0, f"Config {cfg_file.name} produced empty dataframe"
            assert "label" in df.columns, f"Config {cfg_file.name} missing label column"

    @pytest.mark.slow
    @pytest.mark.asyncio
    async def test_full_pipeline_smoke(self):
        """
        Full pipeline smoke test with tiny dataset.

        This test is marked slow and may be skipped in fast test runs.
        It verifies that the complete pipeline (data gen -> ES training ->
        predictor training -> evaluation) runs without errors.
        """
        import tempfile
        from run import run_stress_test

        config = {
            "name": "Smoke Test",
            "view": {
                "features": ["threshold_signal", "noise_gaussian_01", "noise_gaussian_02"],
                "label": "label_threshold_clean",
                "n_rows": 200,
            },
            "embedding_space": {
                "d_model": 32,
                "n_epochs": 2,
                "batch_size": 32,
                "n_transformer_layers": 1,
                "n_attention_heads": 4,
            },
            "predictor": {
                "n_epochs": 2,
                "batch_size": 32,
                "fine_tune": False,
                "use_class_weights": False,
                "early_stop_patience": 5,
            },
            "evaluation": {
                "metrics": ["accuracy"],
                "split_seed": 42,
                "test_fraction": 0.2,
                "val_fraction": 0.1,
            },
            "save_artifacts": False,
        }

        with tempfile.TemporaryDirectory() as tmpdir:
            results_dir = Path(tmpdir)

            # Run the stress test
            result = await run_stress_test(config, results_dir)

            # Verify results structure
            assert "run_id" in result
            assert "metrics" in result
            assert "timing" in result
            assert "run_dir" in result

            # Verify metrics were computed
            assert "accuracy" in result["metrics"]
            assert result["metrics"]["accuracy"] is not None

            # Verify timing was recorded
            assert "data_generation" in result["timing"]
            assert "es_training" in result["timing"]
            assert "predictor_training" in result["timing"]
            assert "evaluation" in result["timing"]

            # Verify output files were created
            run_dir = Path(result["run_dir"])
            assert (run_dir / "metrics.json").exists()
            assert (run_dir / "config_resolved.json").exists()
            assert (run_dir / "summary.md").exists()


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
