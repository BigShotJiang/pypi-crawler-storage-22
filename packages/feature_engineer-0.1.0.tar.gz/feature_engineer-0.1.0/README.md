# Feature Engineer

Advanced feature engineering toolkit for pandas DataFrames.  
Automatically generates numeric, datetime, categorical, boolean, and text features along with a report.
