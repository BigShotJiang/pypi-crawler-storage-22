import pandas as pd
import numpy as np
from pandas.api.types import (
    is_numeric_dtype, is_datetime64_any_dtype,
    is_categorical_dtype, is_object_dtype, is_bool_dtype
)
from collections import Counter


@pd.api.extensions.register_dataframe_accessor("feature_ext")
class FeatureEngineer:
    """
    Feature Engineering Toolkit for pandas DataFrames.

    Provides numeric, datetime, categorical, boolean, and text feature generation,
    along with a summary report of created features.
    """

    def __init__(self, df: pd.DataFrame):
        self._df = df.copy()
        self._report = []

    def engineer(self, numeric=True, datetime=True, categorical=True,
                 boolean=True, text=True, top_n_tokens=5) -> pd.DataFrame:
        """Generate engineered features based on column types."""
        for col in self._df.columns:
            s = self._df[col]
            if numeric and is_numeric_dtype(s):
                self._numeric_features(col, s)
            if datetime and is_datetime64_any_dtype(s):
                self._datetime_features(col, s)
            if categorical and (is_categorical_dtype(s) or is_object_dtype(s)):
                self._categorical_features(col, s)
            if boolean and is_bool_dtype(s):
                self._boolean_features(col, s)
            if text and is_object_dtype(s):
                self._text_features(col, s, top_n=top_n_tokens)
        return self._df

    def report(self) -> pd.DataFrame:
        """Return a summary of all generated features."""
        return pd.DataFrame(self._report).set_index("feature")

    # ---------------------------
    # Numeric Feature Generation
    # ---------------------------
    def _numeric_features(self, col, s):
        if (s > 0).all():
            new_col = f"{col}_log"
            self._df[new_col] = np.log(s)
            self._report.append({"feature": new_col, "type": "numeric", "source": col, "transform": "log"})
        self._df[f"{col}_sq"] = s ** 2
        self._report.append({"feature": f"{col}_sq", "type": "numeric", "source": col, "transform": "square"})
        self._df[f"{col}_cube"] = s ** 3
        self._report.append({"feature": f"{col}_cube", "type": "numeric", "source": col, "transform": "cube"})
        new_col = f"{col}_bin"
        self._df[new_col] = pd.qcut(s.rank(method='first'), q=4, labels=False)
        self._report.append({"feature": new_col, "type": "numeric", "source": col, "transform": "quartile_bin"})

    # ---------------------------
    # Datetime Feature Generation
    # ---------------------------
    def _datetime_features(self, col, s):
        self._df[f"{col}_year"] = s.dt.year
        self._df[f"{col}_month"] = s.dt.month
        self._df[f"{col}_day"] = s.dt.day
        self._df[f"{col}_weekday"] = s.dt.weekday
        self._df[f"{col}_is_month_start"] = s.dt.is_month_start.astype(int)
        self._df[f"{col}_is_month_end"] = s.dt.is_month_end.astype(int)
        for feature in ["year", "month", "day", "weekday", "is_month_start", "is_month_end"]:
            self._report.append({
                "feature": f"{col}_{feature}",
                "type": "datetime",
                "source": col,
                "transform": feature
            })

    # ---------------------------
    # Categorical Feature Generation
    # ---------------------------
    def _categorical_features(self, col, s):
        top_categories = s.value_counts(dropna=True).head(10).index
        for cat in top_categories:
            new_col = f"{col}_is_{cat}"
            self._df[new_col] = (s == cat).astype(int)
            self._report.append({
                "feature": new_col,
                "type": "categorical",
                "source": col,
                "transform": f"is_{cat}"
            })

    # ---------------------------
    # Boolean Feature Generation
    # ---------------------------
    def _boolean_features(self, col, s):
        self._df[f"{col}_int"] = s.astype(int)
        self._report.append({
            "feature": f"{col}_int",
            "type": "boolean",
            "source": col,
            "transform": "bool_to_int"
        })

    # ---------------------------
    # Text Feature Generation
    # ---------------------------
    def _text_features(self, col, s, top_n=5):
        self._df[f"{col}_length"] = s.dropna().map(len)
        self._report.append({
            "feature": f"{col}_length",
            "type": "text",
            "source": col,
            "transform": "length"
        })
        self._df[f"{col}_word_count"] = s.dropna().map(lambda x: len(str(x).split()))
        self._report.append({
            "feature": f"{col}_word_count",
            "type": "text",
            "source": col,
            "transform": "word_count"
        })
        tokens = Counter()
        for val in s.dropna().astype(str):
            tokens.update(val.split())
        top_tokens = [tok for tok, _ in tokens.most_common(top_n)]
        for tok in top_tokens:
            new_col = f"{col}_has_{tok}"
            self._df[new_col] = s.dropna().map(lambda x: int(tok in str(x))).fillna(0)
            self._report.append({
                "feature": new_col,
                "type": "text",
                "source": col,
                "transform": f"has_{tok}"
            })
