# For fetching sources as dataframes, the default limit is set to -1
# to denote that all records should be fetched.
NO_RECORD_LIMIT = -1

# 2 million records
TWO_MILLION_RECORD_LIMIT = 2_000_000
