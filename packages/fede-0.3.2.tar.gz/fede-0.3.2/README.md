# Hello world! 👋🏻️ 🌎

## My name is **Fede Calendino**, I'm an Argentinian 🇦🇷 living in the UK 🇬🇧.


`$ pipx install fede; fede`
