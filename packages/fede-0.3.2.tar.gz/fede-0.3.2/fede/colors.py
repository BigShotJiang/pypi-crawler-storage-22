G = "\033[92m"  # GREEN
B = "\033[94m"  # BLUE
R = "\033[91m"  # RED
W = "\033[97m"  # WHITE
X = "\033[60m"  # GRAY
_ = "\033[0m"  # RESET
