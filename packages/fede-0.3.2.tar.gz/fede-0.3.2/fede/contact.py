EMAIL = "federico@calendino.com"


GITHUB_USERNAME = "fedecalendino"
GITHUB_URL = f"github.com/{GITHUB_USERNAME}"

LINKEDIN_USERNAME = "fedecalendino"
LINKEDIN_URL = f"linkedin.com/in/{LINKEDIN_USERNAME}"
