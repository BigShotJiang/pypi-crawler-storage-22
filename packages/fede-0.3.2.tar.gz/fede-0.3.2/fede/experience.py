from datetime import datetime

from fede.helpers import https

NOW = datetime.now()
YEARS = NOW.year - 2016
MONTHS = NOW.month - 6

TOTAL = f"{YEARS} years"

if MONTHS > 0:
    TOTAL += f" and {MONTHS} months"


class Job:
    def __init__(
        self,
        position: str,
        name: str,
        started_at: str,
        finished_at: str | None = None,
        url: str | None = None,
    ):
        self.title: str = position
        self.name: str = name
        self.started_at: str = started_at
        self.finished_at: str | None = finished_at
        self.url: str | None = url

    @property
    def company(self) -> str:
        if not self.url:
            return self.name

        return https(self.url, alt=self.name)


JOBS = [
    Job(
        position="Backend Software Engineer",
        name="Midnite",
        url="midnite.com",
        started_at="Nov 2025",
    ),
    Job(
        position="Contractor Software Engineer",
        name="Book.io",
        url="book.io",
        started_at="Aug 2023",
    ),
    Job(
        position="Software Engineer II",
        name="Microsoft",
        url="microsoft.com",
        started_at="May 2022",
        finished_at="Aug 2025",
    ),
    Job(
        position="Software Engineer",
        name="Glinvergy Inc.",
        started_at="Oct 2020",
        finished_at="Apr 2022",
    ),
    Job(
        position="Software Engineer",
        name="Reciprocity Labs",
        url="zengrc.com",
        started_at="Oct 2019",
        finished_at="Sep 2020",
    ),
    Job(
        position="Software Engineer",
        name="uBiome",
        started_at="Mar 2018",
        finished_at="Jul 2019",
    ),
    Job(
        position="Java Developer",
        name="Globant",
        url="globant.com",
        started_at="Jun 2016",
        finished_at="Feb 2018",
    ),
]
