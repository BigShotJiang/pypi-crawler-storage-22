def https(url: str, alt: str | None = None) -> str:
    text = alt or url
    return f"\033]8;;https://{url}\033\\{text}\033]8;;\033\\"


def mailto(email: str) -> str:
    return f"\033]8;;mailto:{email}\033\\{email}\033]8;;\033\\"
