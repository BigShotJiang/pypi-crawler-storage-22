from fede.contact import EMAIL, GITHUB_URL, LINKEDIN_URL
from fede.experience import TOTAL, JOBS

from fede.colors import G, W, R, X, _
from fede.helpers import https, mailto

INTRODUCTION = f"""
{G}Hello world!{_} 👋🏻️ 🌎

My name is {W}Fede Calendino{_}, I'm an Argentinian 🇦🇷 living in the UK 🇬🇧.

Creative and adaptable Software Engineer focused on back-end development. 
Pragmatic problem-solver with a strong analytical mindset. 
Experienced in building scalable APIs, automating infrastructure, and improving performance. 
Thrives in fast-paced teams, adapts quickly to new tools and domains, and values clean, maintainable, and testable code.
"""

CONTACT = f"""
{R}Contact Information:{_}
✉️ {X}{W}{mailto(EMAIL)}{_}
💻 {X}{W}{https(GITHUB_URL)}{_}
👤 {X}{W}{https(LINKEDIN_URL)}{_}
"""


def run():
    print(INTRODUCTION)

    print(f"{R}Experience ({TOTAL}):{_}")

    added_separator = False

    for job in JOBS:
        if job.finished_at and not added_separator:
            added_separator = True
            print()

        print(
            f"* {W}{job.title}{_} @ {job.company} ({job.started_at} - {job.finished_at or 'present'}){_}"
        )

    print(CONTACT)


if __name__ == "__main__":
    run()
