# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['fede']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['fede = fede.main:run']}

setup_kwargs = {
    'name': 'fede',
    'version': '0.3.2',
    'description': 'My CV',
    'long_description': "# Hello world! 👋🏻️ 🌎\n\n## My name is **Fede Calendino**, I'm an Argentinian 🇦🇷 living in the UK 🇬🇧.\n\n\n`$ pipx install fede; fede`\n",
    'author': 'Fede Calendino',
    'author_email': 'federico@calendino.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/fedecalendino',
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
