"""FEID - Framework Experimental para Integracion de Datos.

Framework experimental para la construccion de sistemas multi-agente.
"""

__version__ = "0.1.0"
__author__ = "Leon Alberne Torres Restrepo"
__email__ = "albernetorres@gmail.com"
__github__ = "https://github.com/albernetr"
