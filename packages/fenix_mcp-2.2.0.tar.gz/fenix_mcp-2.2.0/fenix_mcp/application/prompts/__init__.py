# SPDX-License-Identifier: MIT
"""Prompt implementations for Fenix MCP server."""

from __future__ import annotations

from typing import List

from fenix_mcp.application.prompt_base import Prompt
from fenix_mcp.application.prompts.memory import FenixMemoryPrompt
from fenix_mcp.application.prompts.mine import FenixMinePrompt
from fenix_mcp.application.prompts.rules import FenixRulesPrompt


def build_prompts() -> List[Prompt]:
    """Build and return all available prompts."""
    return [
        FenixMemoryPrompt(),
        FenixMinePrompt(),
        FenixRulesPrompt(),
    ]


__all__ = [
    "build_prompts",
    "FenixMemoryPrompt",
    "FenixMinePrompt",
    "FenixRulesPrompt",
]
