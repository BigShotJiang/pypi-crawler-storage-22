# SPDX-License-Identifier: MIT
"""Fenix Memory prompt - save content to semantic memory."""

from __future__ import annotations

from typing import Any, Dict, List

from fenix_mcp.application.prompt_base import (
    Prompt,
    PromptArgument,
    PromptMessage,
    PromptResult,
)


class FenixMemoryPrompt(Prompt):
    """Prompt to save content to Fenix semantic memory."""

    name = "fenix-memory"
    description = "Save content to Fenix semantic memory for future reference"
    arguments: List[PromptArgument] = [
        PromptArgument(
            name="content",
            description="The content to save to memory",
            required=True,
        ),
    ]

    def get_messages(self, arguments: Dict[str, Any]) -> PromptResult:
        content = arguments.get("content", "")

        if not content:
            return PromptResult(
                messages=[
                    PromptMessage(
                        role="user",
                        text=(
                            "I want to save something to Fenix memory but didn't "
                            "provide content. Please ask me what I want to save."
                        ),
                    )
                ]
            )

        instruction = f"""Save the following content to Fenix semantic memory using \
the `mcp__fenix__intelligence` tool with `action: memory_save`.

**Content to save:**
{content}

**Instructions:**
1. Create an appropriate title that summarizes the content
2. Generate relevant tags (at least 2-3 tags)
3. Use the content as provided for the memory content field
4. Confirm once saved successfully"""

        return PromptResult(
            description="Save content to Fenix semantic memory",
            messages=[PromptMessage(role="user", text=instruction)],
        )
