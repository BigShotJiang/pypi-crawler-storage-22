APP_NAME = "ferp"
APP_AUTHOR = "zappbrandigan"
SCRIPTS_REPO_URL = "https://github.com/zappbrandigan/ferp-scripts"
