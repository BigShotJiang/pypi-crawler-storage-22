"""ferrox - High-performance structure matching for crystallographic data."""

from ferrox._ferrox import StructureMatcher, __version__
