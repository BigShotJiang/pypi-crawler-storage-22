# ffdice

A simple Python package that acts as a dice.
Essentially, it's a random number generator (RNG) that can be used for multiple purposes.

## Getting started

### Installation

You install this package by running the following command:

```
python3 -m pip install ffdice
```

### Examples

Take a look at the [examples](examples/) for a few implementation ideas.

### Unit testing

In order to run automated tests, execute:

```
python3 -m unittest
```

## Notes

This project was created both to learn and to scratch a personal itch. Feel free to reach out and [submit an issue](https://github.com/mzilverberg/ffdice/issues) on GitHub if you encounter any problems with this package.