# Basic example

This example shows how to create a Dice instance and use the `roll()` method to return a random outcome, varying from 1 to 6.

## Run from command line

You can run this example with the following command:

```shell
cd path/to/ffdice
python3 -m examples.basic # Output: You rolled 5 and 3, adding up to a total of 8!
```
