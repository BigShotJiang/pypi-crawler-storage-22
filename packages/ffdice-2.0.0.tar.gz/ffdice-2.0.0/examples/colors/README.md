# Color dice example

This example shows how to pick a color by using the output of the `roll()` method.

## Run from command line

You can run this example with the following command:

```shell
cd path/to/ffdice
python3 -m examples.colors # Output: You rolled yellow!
```
