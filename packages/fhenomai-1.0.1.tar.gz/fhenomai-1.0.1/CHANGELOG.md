# Changelog

All notable changes to the FHEnom AI Python Library will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2024-01-15

### Added
- Initial release of FHEnom AI Python Library
- **Core Modules**:
  - `FHEnomClient`: Unified client combining Admin API and SFTP operations
  - `AdminAPI`: Complete Admin API client with all documented endpoints
  - `SFTPClient`: Robust SFTP client for file transfer operations
  - `FHEnomConfig`: Flexible configuration management (env vars, YAML files)
  
- **Admin API Features**:
  - Model discovery: `list_models()`, `list_online_models()`, `get_model_info()`
  - Serving control: `start_serving()`, `stop_serving()`
  - Model encryption: `encrypt_model()` with comprehensive parameters
  - Dataset encryption: `encrypt_dataset()` with text field support
  - Job management: `get_job_status()`, `wait_for_job()` with progress callbacks
  - Retry logic with exponential backoff
  - Comprehensive error handling
  
- **SFTP Features**:
  - Upload/download files and directories
  - Recursive operations with progress bars
  - Context manager support for automatic connection management
  - Exclude patterns for selective uploads
  - File size and existence checks
  
- **High-Level Workflows**:
  - `encrypt_and_upload_model()`: Complete model encryption workflow
  - `encrypt_and_upload_dataset()`: Complete dataset encryption workflow
  - Simplified model serving interface
  
- **Configuration**:
  - Load from environment variables
  - Load from YAML files (~/.fhenomai/config.yaml or ./fhenomai.yaml)
  - Save configurations for reuse
  - Nested configuration support
  
- **Exception Handling**:
  - Custom exception hierarchy
  - Context preservation (job IDs, status codes, error details)
  - Clear error messages
  
- **Utilities** (`fhenomai.utils`):
  - File and directory hashing
  - Human-readable formatting (bytes, duration)
  - Model directory validation
  - JSON file operations
  - Dictionary merging
  - Retry with backoff helper
  
- **Testing Utilities** (`fhenomai.testing`):
  - Connection validation: `validate_connection()`
  - SFTP validation: `validate_sftp()`
  - Admin API validation: `validate_admin_api()`
  - Full workflow test: `run_full_workflow_test()`
  - Test fixtures: `create_test_model()`, `create_test_dataset()`
  - Test cleanup: `cleanup_test_resources()`
  
- **Command-Line Interface**:
  - `fhenomai test connection`: Test API connectivity
  - `fhenomai test sftp`: Test SFTP connectivity
  - `fhenomai test admin`: Test Admin API endpoints
  - `fhenomai model list`: List available models
  - `fhenomai model info <model>`: Get model information
  - `fhenomai model upload <local> <remote>`: Upload model
  - `fhenomai model download <remote> <local>`: Download model
  - `fhenomai model encrypt <model> <output>`: Encrypt model
  - `fhenomai serve start <model>`: Start serving
  - `fhenomai serve stop`: Stop serving
  - `fhenomai config init`: Initialize configuration
  - `fhenomai config show`: Show current configuration
  
- **Documentation**:
  - Comprehensive README with examples
  - API reference documentation
  - Usage examples in examples/ directory
  - Detailed docstrings for all public APIs
  
- **Placeholder Features** (for future TEE implementation):
  - Health monitoring: `get_health()`, `get_metrics()`, `get_tee_info()`
  - Account management: `create_user()`, `delete_user()`, `list_users()`, `update_user_permissions()`
  - Advanced operations: `batch_encrypt_models()`, `get_queue_status()`, `cancel_job()`, `get_model_usage_stats()`

### Dependencies
- requests>=2.28.0
- paramiko>=3.0.0
- urllib3>=1.26.0
- pyyaml>=6.0
- tqdm>=4.65.0
- rich>=13.0.0
- click>=8.0.0

### Development Dependencies
- pytest>=7.0.0
- black>=22.0.0
- flake8>=5.0.0
- mypy>=0.990
- isort>=5.10.0
- sphinx>=5.0.0
- sphinx-rtd-theme>=1.0.0

## [Unreleased]

### Planned
- Async/await support for non-blocking operations
- Batch operations with progress tracking
- Enhanced caching mechanisms
- Plugin system for custom encryption algorithms
- Webhook support for job notifications
- Integration with popular ML frameworks (transformers, etc.)
- Model metadata management
- Dataset versioning
- Automated testing suite
- Performance benchmarking tools
