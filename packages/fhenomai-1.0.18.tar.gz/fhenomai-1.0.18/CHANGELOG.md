# Changelog

All notable changes to the FHEnom AI Python Library will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.17] - 2026-02-10

### Changed
- **PDF Library**: Switched from xhtml2pdf to ReportLab (industry-standard pure Python PDF library)
- ReportLab has zero system dependencies and works on all platforms
- PDF generation now uses direct ReportLab API instead of HTML conversion
- Simpler, more reliable PDF output with monospace formatting

### Improved
- PDF generation is now guaranteed to work everywhere Python works
- No hidden dependencies or system library requirements
- Cleaner PDF output optimized for attestation reports

## [1.0.16] - 2026-02-10

### Changed
- **BREAKING**: Replaced weasyprint with xhtml2pdf for PDF generation
- **Removed system library dependencies**: No longer requires libpango, libcairo, gdk-pixbuf, or libffi
- PDF generation now pure Python (xhtml2pdf>=0.2.11)
- Simplified installation - works on all platforms without system packages

### Removed
- System requirements documentation (no longer needed)
- check_pdf_dependencies.py script (no longer needed)

## [1.0.15] - 2026-02-10

### Added
- Comprehensive system requirements documentation for PDF generation in README.md
- Installation instructions for libpango, libcairo, and other system libraries
- Platform-specific installation commands (Ubuntu/Debian, RHEL/Fedora, macOS, Docker)
- Dependency checker script (check_pdf_dependencies.py) to verify system libraries
- Clear note that HTML/TXT reports work without system libraries

### Improved
- README.md now provides complete setup guidance for all attestation report formats
- Better documentation of PDF generation dependencies

## [1.0.14] - 2026-02-10

### Added
- Initial documentation for PDF system requirements

## [1.0.13] - 2026-02-10

### Fixed
- AttestationReportFormatter: Fixed bytes-to-hex conversion in format_standard() for chip_id, report_data, sig_r, sig_s
- AttestationEngineType enum: Updated to use uppercase values (AMD_SEV_SNP, INTEL_TDX) matching dk-tee-attestation 0.3.1 API
- CLI format handling: Restored original design - format flag controls content style (standard/detailed), file extension controls output format
- Import error handling: Changed to direct import for tee_amd_sev_snp_rust_py_wrap (no try-except)

### Changed
- ParsedAttestationReport class: Changed all byte fields from str to bytes type for proper parsing

## [1.0.12] - 2026-02-10

### Fixed
- AttestationEngineType enum references in verification command

## [1.0.11] - 2026-02-10

### Fixed
- ParsedAttestationReport: Fixed type handling for bytes fields
- format_standard(): Added .hex() conversion for all bytes fields

## [1.0.10] - 2026-02-10

### Fixed
- Import handling for tee_amd_sev_snp_rust_py_wrap module

## [1.0.9] - 2026-02-09

### Added
- weasyprint>=60.0 dependency for PDF generation

## [1.0.8] - 2026-02-09

### Fixed
- Minor bug fixes in attestation formatter integration

## [1.0.7] - 2026-02-06

### Added
- **TEE Attestation Enhancements**:
  - New `verify-attestation` CLI command for attestation report verification
  - Automatic triple file output: formatted report + .bin + .nonce
  - Format inference from file extensions (.html, .pdf, .txt)
  - Auto-load nonce feature in verification (reads from .nonce file)
  - Parsed attestation reports with CPU info, TCB details, and signatures
  - Color-coded hex dumps for technical analysis
  - HTML/PDF report generation with proper entity escaping
  - **Integrated AttestationReportFormatter** - moved from dk-tee-attestation into fhenomai for API stability

### Changed
- **Breaking Change**: `--format` option now controls display style (standard/detailed) instead of output format
- **Breaking Change**: File extension now determines output format instead of --format flag
- Attestation commands always create three files automatically
- Verification no longer requires explicit --nonce if .nonce file exists
- Updated dk-tee-attestation dependency to 0.2.4 (fixes HTML/PDF rendering bug)
- **AttestationReportFormatter** now part of fhenomai core library (no longer imported from dk-tee-attestation)

### Fixed
- HTML/PDF attestation reports displaying blank content (fixed in dk-tee-attestation 0.2.4)
- HTML entity escaping in ANSI-to-HTML conversion
- Import errors for LEGEND and CPUID constants in dk-tee-attestation
- Decoupled report formatting from dk-tee-attestation to prevent breaking changes

### Documentation
- Updated CLI command reference with new attestation behavior
- Added complete verification workflows with auto-load examples
- Updated SDK examples to show new v1.0.7 features
- Added migration guide from v1.0.6 to v1.0.7
- Updated README with new attestation features and formatter usage

## [1.0.0] - 2024-01-15

### Added
- Initial release of FHEnom AI Python Library
- **Core Modules**:
  - `FHEnomClient`: Unified client combining Admin API and SFTP operations
  - `AdminAPI`: Complete Admin API client with all documented endpoints
  - `SFTPClient`: Robust SFTP client for file transfer operations
  - `FHEnomConfig`: Flexible configuration management (env vars, YAML files)
  
- **Admin API Features**:
  - Model discovery: `list_models()`, `list_online_models()`, `get_model_info()`
  - Serving control: `start_serving()`, `stop_serving()`
  - Model encryption: `encrypt_model()` with comprehensive parameters
  - Dataset encryption: `encrypt_dataset()` with text field support
  - Job management: `get_job_status()`, `wait_for_job()` with progress callbacks
  - Retry logic with exponential backoff
  - Comprehensive error handling
  
- **SFTP Features**:
  - Upload/download files and directories
  - Recursive operations with progress bars
  - Context manager support for automatic connection management
  - Exclude patterns for selective uploads
  - File size and existence checks
  
- **High-Level Workflows**:
  - `encrypt_and_upload_model()`: Complete model encryption workflow
  - `encrypt_and_upload_dataset()`: Complete dataset encryption workflow
  - Simplified model serving interface
  
- **Configuration**:
  - Load from environment variables
  - Load from YAML files (~/.fhenomai/config.yaml or ./fhenomai.yaml)
  - Save configurations for reuse
  - Nested configuration support
  
- **Exception Handling**:
  - Custom exception hierarchy
  - Context preservation (job IDs, status codes, error details)
  - Clear error messages
  
- **Utilities** (`fhenomai.utils`):
  - File and directory hashing
  - Human-readable formatting (bytes, duration)
  - Model directory validation
  - JSON file operations
  - Dictionary merging
  - Retry with backoff helper
  
- **Testing Utilities** (`fhenomai.testing`):
  - Connection validation: `validate_connection()`
  - SFTP validation: `validate_sftp()`
  - Admin API validation: `validate_admin_api()`
  - Full workflow test: `run_full_workflow_test()`
  - Test fixtures: `create_test_model()`, `create_test_dataset()`
  - Test cleanup: `cleanup_test_resources()`
  
- **Command-Line Interface**:
  - `fhenomai test connection`: Test API connectivity
  - `fhenomai test sftp`: Test SFTP connectivity
  - `fhenomai test admin`: Test Admin API endpoints
  - `fhenomai model list`: List available models
  - `fhenomai model info <model>`: Get model information
  - `fhenomai model upload <local> <remote>`: Upload model
  - `fhenomai model download <remote> <local>`: Download model
  - `fhenomai model encrypt <model> <output>`: Encrypt model
  - `fhenomai serve start <model>`: Start serving
  - `fhenomai serve stop`: Stop serving
  - `fhenomai config init`: Initialize configuration
  - `fhenomai config show`: Show current configuration
  
- **Documentation**:
  - Comprehensive README with examples
  - API reference documentation
  - Usage examples in examples/ directory
  - Detailed docstrings for all public APIs
  
- **Placeholder Features** (for future TEE implementation):
  - Health monitoring: `get_health()`, `get_metrics()`, `get_tee_info()`
  - Account management: `create_user()`, `delete_user()`, `list_users()`, `update_user_permissions()`
  - Advanced operations: `batch_encrypt_models()`, `get_queue_status()`, `cancel_job()`, `get_model_usage_stats()`

### Dependencies
- requests>=2.28.0
- paramiko>=3.0.0
- urllib3>=1.26.0
- pyyaml>=6.0
- tqdm>=4.65.0
- rich>=13.0.0
- click>=8.0.0

### Development Dependencies
- pytest>=7.0.0
- black>=22.0.0
- flake8>=5.0.0
- mypy>=0.990
- isort>=5.10.0
- sphinx>=5.0.0
- sphinx-rtd-theme>=1.0.0

## [Unreleased]

### Planned
- Async/await support for non-blocking operations
- Batch operations with progress tracking
- Enhanced caching mechanisms
- Plugin system for custom encryption algorithms
- Webhook support for job notifications
- Integration with popular ML frameworks (transformers, etc.)
- Model metadata management
- Dataset versioning
- Automated testing suite
- Performance benchmarking tools
