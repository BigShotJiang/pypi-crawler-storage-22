"""
FHEnom AI Python Client Library

Official Python SDK for FHEnom for AI™ - Confidential AI with fully encrypted models and data.

Copyright © 2026 DataKrypto. All rights reserved.
"""

__version__ = "1.0.17"
__author__ = "DataKrypto"
__email__ = "support@datakrypto.ai"
__license__ = "MIT"

from .client import FHEnomClient
from .admin_api import AdminAPI
from .sftp import SFTPClient
from .sftp_manager import SFTPManager, FileInfo
from .sync import SyncManager
from .exceptions import (
    FHEnomError,
    ConnectionError,
    AuthenticationError,
    JobError,
    ModelNotFoundError,
    EncryptionError,
    ServingError,
    ValidationError,
    SFTPError,
    SyncError,
    TimeoutError,
    APIError
)
from .config import FHEnomConfig
from .attestation_formatter import AttestationReportFormatter
from . import utils
from . import testing

__all__ = [
    "FHEnomClient",
    "AdminAPI",
    "SFTPClient",
    "SFTPManager",
    "SyncManager",
    "FileInfo",
    "FHEnomConfig",
    "AttestationReportFormatter",
    "FHEnomError",
    "ConnectionError",
    "AuthenticationError",
    "JobError",
    "ModelNotFoundError",
    "EncryptionError",
    "ServingError",
    "ValidationError",
    "SFTPError",
    "SyncError",
    "TimeoutError",
    "APIError",
    "utils",
    "testing"
]
