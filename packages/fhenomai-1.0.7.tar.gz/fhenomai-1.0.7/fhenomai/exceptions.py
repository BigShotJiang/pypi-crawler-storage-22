"""
Custom exceptions for FHEnom AI operations.
"""


class FHEnomError(Exception):
    """Base exception for all FHEnom AI errors."""
    pass


class ConnectionError(FHEnomError):
    """Raised when connection to TEE machine fails."""
    pass


class AuthenticationError(FHEnomError):
    """Raised when authentication fails (SFTP, API keys, etc.)."""
    pass


class JobError(FHEnomError):
    """Raised when a job fails or times out."""
    
    def __init__(self, message: str, job_id: str = None, error_details: str = None):
        super().__init__(message)
        self.job_id = job_id
        self.error_details = error_details


class ModelNotFoundError(FHEnomError):
    """Raised when a requested model is not found."""
    
    def __init__(self, model_id: str):
        super().__init__(f"Model not found: {model_id}")
        self.model_id = model_id


class EncryptionError(FHEnomError):
    """Raised when model or dataset encryption fails."""
    pass


class ServingError(FHEnomError):
    """Raised when model serving operations fail."""
    pass


class ValidationError(FHEnomError):
    """Raised when input validation fails."""
    pass


class SFTPError(FHEnomError):
    """Raised when SFTP operations fail."""
    pass


class SyncError(FHEnomError):
    """Raised when peer synchronization operations fail."""
    
    def __init__(self, message: str, peer_url: str = None, error_details: str = None):
        super().__init__(message)
        self.peer_url = peer_url
        self.error_details = error_details


class TimeoutError(JobError):
    """Raised when an operation times out."""
    pass


class APIError(FHEnomError):
    """Raised when API requests fail."""
    
    def __init__(self, message: str, status_code: int = None, response: dict = None):
        super().__init__(message)
        self.status_code = status_code
        self.response = response
