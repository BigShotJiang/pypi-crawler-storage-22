"""Entrypoint module, in case you use `python -m figshare_client`."""

from .cli import main

if __name__ == "__main__":
    main()
