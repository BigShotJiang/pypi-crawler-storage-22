"""Main package for file-roulette."""


def hello(n: int) -> str:
    """Return a hello message with the sum of numbers from 1 to n."""
    return f"Hello {n}!"
