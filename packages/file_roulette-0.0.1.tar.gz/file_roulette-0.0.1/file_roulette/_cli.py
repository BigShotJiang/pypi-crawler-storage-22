"""Main cli entry point for File Roulette application."""

from file_roulette.cli.cli import main

if __name__ == "__main__":
    main()
