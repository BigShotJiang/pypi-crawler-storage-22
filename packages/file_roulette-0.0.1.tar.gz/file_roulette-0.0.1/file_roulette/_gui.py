"""Main gui entry point for File Roulette application."""

from file_roulette.gui.gui import main

if __name__ == "__main__":
    main()
