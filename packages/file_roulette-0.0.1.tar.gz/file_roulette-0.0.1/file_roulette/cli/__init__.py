"""CLI package for File Roulette."""
