def main():
    print("Hello from filemind!")


if __name__ == "__main__":
    main()
