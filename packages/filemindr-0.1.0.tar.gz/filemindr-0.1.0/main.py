def main():
    print("Hello from filemindr!")


if __name__ == "__main__":
    main()
