this package "filereter" contains a function which is -
run():-
 Defenition :-this function can take a variable in which a code is input and get the output and store it in a variable.
 Paranthesis :- at first the code(or the variable)and after comma the extention in string.
 IMPORTANT NOTE:-The  code in a lanaguage can be only run when it is present in the computer 
 how to install the code-
 " pip install filereter" in your terminal then write -
 "import filereter" or "from filereter import run"
 how to use -
  input:-
  a ="a = print('filereter')"
  l = run(a,"py")
  print (l)
 output:-
  filereter  