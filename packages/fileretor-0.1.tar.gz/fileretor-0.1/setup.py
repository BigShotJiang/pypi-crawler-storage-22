from setuptools import setup,find_packages
setup(name='fileretor',version='0.1',packages=find_packages(),install_requires=[])
