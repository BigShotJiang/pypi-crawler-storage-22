def cast_bool(value: str | None | bool) -> bool:
    if value is None:
        return False
    if isinstance(value, bool):
        return value
    return value.lower() in ("true", "t", "1", "on", "enabled", "yes", "y")
