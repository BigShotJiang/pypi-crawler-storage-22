# src/fileshear/__init__.py

__all__ = []
__version__ = "0.1.0"
