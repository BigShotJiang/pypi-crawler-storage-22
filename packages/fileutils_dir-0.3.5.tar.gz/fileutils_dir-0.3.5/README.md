# fileutils

A small Python library for filtering and listing files. 

## Installation

```bash
pip install fileutils-dir
```

## Usage

```python
from fileutils import in_dir

# List all files in the current directory
files = in_dir()

# Filter by extension
python_files = in_dir(ext=[".py"])

# Filter by predefined categories
media_files = in_dir(dtype=["image", "video"])

# Filter by both
results = in_dir(path="src", ext=[".c"], dtype=["text"])
```

## API Reference

### `in_dir(path=".", *, ext=None, dtype=None)`

Returns a list of file paths as strings from the specified directory.

- **path**: Directory to search. Accepts `str` or `pathlib.Path`. Defaults to `"."`.
- **ext**: An iterable of file extensions to include. 
- **dtype**: An iterable of predefined file type categories. 

If neither `ext` nor `dtype` are provided, all files in the directory are returned. If both are provided, the result is the union of both filters. Subdirectories are ignored.

## Supported Types

The `dtype` parameter supports the following categories:

| Category | Extensions |
| :--- | :--- |
| `image` | .jpg, .jpeg, .png, .webp, .bmp, .gif, .tiff |
| `text` | .txt, .md, .rst, .log |
| `pdf` | .pdf |
| `doc` | .doc, .docx, .odt |
| `sheet` | .xls, .xlsx, .ods, .csv |
| `presentation` | .ppt, .pptx, .odp |
| `code` | .py, .js, .ts, .java, .c, .cpp, .h, .go, .rs, .rb, .php, .sh |
| `data` | .json, .yaml, .yml, .xml, .toml |
| `audio` | .mp3, .wav, .flac, .ogg, .aac, .m4a |
| `video` | .mp4, .mkv, .avi, .mov, .webm |
| `archive` | .zip, .tar, .gz, .bz2, .7z, .rar |

## License

MIT
