from pathlib import Path

FILE_TYPES = {
    "image": [".jpg", ".jpeg", ".png", ".webp", ".bmp", ".gif", ".tiff"],
    "text": [".txt", ".md", ".rst", ".log"],
    "pdf": [".pdf"],
    "doc": [".doc", ".docx", ".odt"],
    "sheet": [".xls", ".xlsx", ".ods", ".csv"],
    "presentation": [".ppt", ".pptx", ".odp"],
    "code": [".py", ".js", ".ts", ".java", ".c", ".cpp", ".h", ".go", ".rs", ".rb", ".php", ".sh"],
    "data": [".json", ".yaml", ".yml", ".xml", ".toml"],
    "audio": [".mp3", ".wav", ".flac", ".ogg", ".aac", ".m4a"],
    "video": [".mp4", ".mkv", ".avi", ".mov", ".webm"],
    "archive": [".zip", ".tar", ".gz", ".bz2", ".7z", ".rar"],
}


class DirQuery:
    """Query object for listing files in a directory."""

    def __init__(self, path=".", *, ext=None, dtype=None):
        """Create a directory query with optional filters."""
        self.path = Path(path)
        self._show_hidden = False

        ext = ext or []
        dtype = dtype or []

        if isinstance(ext, str):
            ext = [ext]
        if isinstance(dtype, str):
            dtype = [dtype]

        self.normalized_extensions = {
            e.lower() if e.startswith(".") else f".{e.lower()}"
            for e in ext
        }

        for file_type in dtype:
            key = file_type.strip().lower()
            if key not in FILE_TYPES:
                raise ValueError(
                    f"Unknown file type: {file_type}. "
                    f"Valid types: {', '.join(FILE_TYPES)}"
                )
            self.normalized_extensions.update(FILE_TYPES[key])

    def show_hidden(self):
        """Include hidden files in results."""
        self._show_hidden = True
        return self

    def list(self) -> list[str]:
        """Return matching file paths."""
        files: list[str] = []

        for item in self.path.iterdir():
            if not item.is_file():
                continue
            if not self._show_hidden and item.name.startswith("."):
                continue
            if (
                self.normalized_extensions
                and item.suffix.lower() not in self.normalized_extensions
            ):
                continue
            files.append(str(item))

        return files

    def count(self) -> int:
        """Return number of matching files."""
        return len(self.list())


def in_dir(path=".", *args, ext=None, dtype=None) -> DirQuery:
    """Create a directory query."""
    if args:
        raise TypeError(
            "in_dir() accepts only one positional argument (path).\n"
            "Use keyword arguments for filters:\n"
            "  in_dir(path, ext='py')\n"
            "  in_dir(path, dtype='image')"
        )

    return DirQuery(path, ext=ext, dtype=dtype)
