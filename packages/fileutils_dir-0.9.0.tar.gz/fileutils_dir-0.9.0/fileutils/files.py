from pathlib import Path

FILE_TYPES = {
    "image": [".jpg", ".jpeg", ".png", ".webp", ".bmp", ".gif", ".tiff"],
    "text": [".txt", ".md", ".rst", ".log"],
    "pdf": [".pdf"],
    "doc": [".doc", ".docx", ".odt"],
    "sheet": [".xls", ".xlsx", ".ods", ".csv"],
    "presentation": [".ppt", ".pptx", ".odp"],
    "code": [".py", ".js", ".ts", ".java", ".c", ".cpp", ".h", ".go", ".rs", ".rb", ".php", ".sh"],
    "data": [".json", ".yaml", ".yml", ".xml", ".toml"],
    "audio": [".mp3", ".wav", ".flac", ".ogg", ".aac", ".m4a"],
    "video": [".mp4", ".mkv", ".avi", ".mov", ".webm"],
    "archive": [".zip", ".tar", ".gz", ".bz2", ".7z", ".rar"],
}


class DirQuery:
    """Declarative, chainable file selector over one or more directories."""

    def __init__(self, roots: list[Path]):
        self._roots = roots
        self._name_filter = "*"
        self._recursive = False
        self._dirs = False
        self._show_hidden = False
        self._include_exts: set[str] = set()
        self._exclude_exts: set[str] = set()

    # ---------- selectors ----------

    def name(self, pattern: str):
        self._name_filter = pattern.strip()
        return self

    def include_ext(self, *exts: str):
        for e in exts:
            e = e.lower()
            self._include_exts.add(e if e.startswith(".") else f".{e}")
        return self

    def exclude_ext(self, *exts: str):
        for e in exts:
            e = e.lower()
            self._exclude_exts.add(e if e.startswith(".") else f".{e}")
        return self

    def include_type(self, *types: str):
        for t in types:
            key = t.strip().lower()
            if key not in FILE_TYPES:
                raise ValueError(
                    f"Unknown file type: {t}. "
                    f"Valid types: {', '.join(FILE_TYPES)}"
                )
            self._include_exts.update(FILE_TYPES[key])
        return self

    def exclude_type(self, *types: str):
        for t in types:
            key = t.strip().lower()
            if key not in FILE_TYPES:
                raise ValueError(
                    f"Unknown file type: {t}. "
                    f"Valid types: {', '.join(FILE_TYPES)}"
                )
            self._exclude_exts.update(FILE_TYPES[key])
        return self

    # ---------- modes ----------

    def recursive(self):
        self._recursive = True
        return self

    def dirs(self):
        self._dirs = True
        return self

    def show_hidden(self):
        self._show_hidden = True
        return self

    # ---------- internals ----------

    def _iter(self):
        for root in self._roots:
            iterator = (
                root.rglob(self._name_filter)
                if self._recursive
                else root.glob(self._name_filter)
            )
            yield from iterator

    def _unique(self, items):
        seen: set[Path] = set()
        for item in items:
            try:
                resolved = item.resolve()
            except OSError:
                continue
            if resolved in seen:
                continue
            seen.add(resolved)
            yield item

    # ---------- execution ----------

    def list(self) -> list[str]:
        results: list[str] = []
        for item in self._unique(self._iter()):
            if not self._show_hidden and item.name.startswith("."):
                continue
            if self._dirs:
                if not item.is_dir():
                    continue
            else:
                if not item.is_file():
                    continue
                if self._include_exts and item.suffix.lower() not in self._include_exts:
                    continue
                if self._exclude_exts and item.suffix.lower() in self._exclude_exts:
                    continue
            results.append(str(item))
        return results

    def count(self) -> int:
        return len(self.list())


def in_dir(*paths) -> DirQuery:
    if not paths:
        paths = (".",)
    roots: list[Path] = []
    for p in paths:
        path = Path(p).resolve()
        if not path.exists():
            raise FileNotFoundError(f"Path does not exist: {path}")
        if not path.is_dir():
            raise NotADirectoryError(f"Path is not a directory: {path}")
        roots.append(path)
    return DirQuery(roots)
