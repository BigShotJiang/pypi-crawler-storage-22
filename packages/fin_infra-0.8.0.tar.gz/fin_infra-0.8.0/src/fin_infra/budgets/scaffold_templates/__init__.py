"""Budget scaffold templates.

This package contains template files for generating budget persistence code.
Templates are processed using string.Template substitution.
"""
