"""Pre-configured logging settings for different environments and use cases."""

from typing import Dict, Any
import os


def get_log_level() -> str:
    """Get log level from environment variable with fallback to INFO."""
    return os.getenv('LOG_LEVEL', 'INFO').upper()


# Base configuration that other configs extend
_BASE_CONFIG = {
    'version': 1,
    'disable_existing_loggers': True,
    'filters': {
        'correlation_id': {'()': 'finalsa.common.logger.filter.CorrelationIdFilter'},
    },
    'formatters': {
        'console': {
            'class': 'finalsa.common.logger.formatter.CustomJsonFormatter',
        },
        'json': {
            'class': 'finalsa.common.logger.formatter.CustomJsonFormatter',
        },
        'access': {
            'class': 'finalsa.common.logger.formatter.AccessJsonFormatter',
        },
    },
}

# AWS Lambda optimized configuration (original default)
LAMBDA_DEFAULT_LOGGER: Dict[str, Any] = {
    **_BASE_CONFIG,
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
            'filters': ['correlation_id'],
            'formatter': 'console',
        },
    },
    'loggers': {
        'http': {
            'handlers': ['console'],
            'level': 'INFO',
            'propagate': False,
        },
        'root': {
            'handlers': ['console'],
            'level': get_log_level(),
            'propagate': True
        },
    },
}

# Development configuration with more verbose logging
DEVELOPMENT_LOGGER: Dict[str, Any] = {
    **_BASE_CONFIG,
    'disable_existing_loggers': False,  # Don't disable existing loggers in dev
    'formatters': {
        **_BASE_CONFIG['formatters'],
        'detailed': {
            'class': 'finalsa.common.logger.formatter.CustomJsonFormatter',
            'format': '%(timestamp)s %(level)s %(name)s %(funcName)s:%(lineno)d %(message)s'
        },
    },
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
            'level': 'DEBUG',
            'filters': ['correlation_id'],
            'formatter': 'detailed',
        },
    },
    'loggers': {
        'http': {
            'handlers': ['console'],
            'level': 'DEBUG',
            'propagate': False,
        },
        'root': {
            'handlers': ['console'],
            'level': 'DEBUG',
            'propagate': True,
        },
    },
}

PRODUCTION_LOGGER: Dict[str, Any] = {
    **_BASE_CONFIG,
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
            'filters': ['correlation_id'],
            'formatter': 'console',
        },
    },
    'loggers': {
        'http': {
            'handlers': ['console'],
            'level': get_log_level(),
            'propagate': False,
        },
        'root': {
            'handlers': ['console'],
            'level': get_log_level(),
            'propagate': True,
        },
    },
}

# Access log specific configuration
ACCESS_LOGGER: Dict[str, Any] = {
    **_BASE_CONFIG,
    'handlers': {
        'access': {
            'class': 'logging.StreamHandler',
            'filters': ['correlation_id'],
            'formatter': 'access',
        },
    },
    'loggers': {
        'access': {
            'handlers': ['access'],
            'level': 'INFO',
            'propagate': False,
        },
        'root': {
            'handlers': [],
            'level': 'WARNING',
        },
    },
}

# Minimal configuration without correlation IDs (for external libraries)
MINIMAL_LOGGER: Dict[str, Any] = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'simple': {
            'class': 'finalsa.common.logger.formatter.CustomJsonFormatter',
        },
    },
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
            'formatter': 'simple',
        },
    },
    'loggers': {
        'root': {
            'handlers': ['console'],
            'level': get_log_level(),
            'propagate': True,
        },
    },
}

# Testing configuration that captures logs
TESTING_LOGGER: Dict[str, Any] = {
    **_BASE_CONFIG,
    'disable_existing_loggers': False,
    'handlers': {
        'memory': {
            'class': 'logging.handlers.MemoryHandler',
            'capacity': 1000,
            'filters': ['correlation_id'],
            'formatter': 'json',
        },
    },
    'loggers': {
        'root': {
            'handlers': ['memory'],
            'level': 'DEBUG',
            'propagate': True,
        },
    },
}
