from pythonjsonlogger.orjson import OrjsonFormatter
from datetime import datetime, timezone
from typing import Dict, Any, TYPE_CHECKING
import warnings

if TYPE_CHECKING:
    from logging import LogRecord


class CustomJsonFormatter(OrjsonFormatter):
    """Custom JSON formatter that adds timestamps and normalizes log levels.
    
    This formatter extends the OrjsonFormatter to add:
    - Automatic timestamp generation in ISO 8601 format with microseconds
    - Log level normalization to uppercase
    - Correlation ID string conversion
    """

    def add_fields(self, log_data: Dict[str, Any], record: 'LogRecord', message_dict: Dict[str, Any]) -> None:
        """Add custom fields to the log record.
        
        Args:
            log_data: The dictionary that will be serialized to JSON
            record: The original LogRecord instance
            message_dict: Additional message fields
        """
        super().add_fields(log_data, record, message_dict)
        
        # Add timestamp if not present
        if not log_data.get('timestamp'):
            now = datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%S.%fZ')
            log_data['timestamp'] = now
        
        # Normalize log level
        if log_data.get('level'):
            log_data['level'] = log_data['level'].upper()
        else:
            log_data['level'] = record.levelname
        
        # Convert correlation_id to string if present and not None
        if log_data.get('correlation_id') is not None:
            log_data['correlation_id'] = str(log_data['correlation_id'])


class AccessJsonFormatter(CustomJsonFormatter):
    """Specialized JSON formatter for HTTP access logs.
    
    This formatter expects log record args in the following order:
    (client_ip, http_method, path, protocol, status_code)
    
    Example:
        access_logger.info("Request", "192.168.1.1", "GET", "/api/users", "HTTP/1.1", 200)
    """

    def add_fields(self, log_data: Dict[str, Any], record: 'LogRecord', message_dict: Dict[str, Any]) -> None:
        """Add access log fields and standard fields.
        
        Args:
            log_data: The dictionary that will be serialized to JSON
            record: The original LogRecord instance  
            message_dict: Additional message fields
            
        Raises:
            ValueError: If record.args doesn't have exactly 5 elements
            IndexError: If record.args is malformed
        """
        # First add standard fields from parent
        super().add_fields(log_data, record, message_dict)
        
        # Parse access log arguments
        try:
            if len(record.args) != 5:
                raise ValueError(
                    f"AccessJsonFormatter expects exactly 5 args (ip, method, path, protocol, status_code), "
                    f"got {len(record.args)}: {record.args}"
                )
            
            ip, method, path, protocol, status_code = record.args
            
            # Add access-specific fields
            log_data['client_addr'] = str(ip)
            log_data['method'] = str(method)
            log_data['path'] = str(path)
            log_data['protocol'] = str(protocol)
            log_data['status_code'] = int(status_code) if str(status_code).isdigit() else status_code
            
        except (ValueError, TypeError, IndexError) as e:
            # Log the error but don't break the logging system
            warnings.warn(f"Failed to parse access log arguments: {e}. Args: {record.args}")
            
            # Add error information to the log record
            log_data['access_log_parse_error'] = str(e)
            log_data['raw_args'] = str(record.args)
