from typing import Any, Dict, Generic, Optional, Sequence, TypeVar

from pydantic import BaseModel, ConfigDict, Field, model_validator


ItemT = TypeVar("ItemT")


class PaginationRequest(BaseModel):
    """Represents the pagination related query params for HTTP GET requests."""

    model_config = ConfigDict(populate_by_name=True)

    limit: Optional[int] = Field(
        default=None,
        gt=0,
        description="Maximum number of elements to evaluate in a single page.",
    )
    exclusive_start_key: Optional[Dict[str, Any]] = Field(
        default=None,
        alias="from",
        description="DynamoDB ExclusiveStartKey encoded in the request.",
    )


class PaginationMeta(BaseModel):
    """Generic metadata that can be attached to a paginated response."""

    model_config = ConfigDict(populate_by_name=True)

    total: int
    approx_pages: int
    limit: Optional[int] = None
    from_: Optional[int] = Field(default=None, alias="from")
    to: Optional[int] = None


class PaginationResponse(BaseModel, Generic[ItemT]):
    """
    Generic response wrapper for paginated HTTP GET endpoints.

    The model keeps track of the DynamoDB ExclusiveStartKey used to fetch
    the current page and the LastEvaluatedKey required to fetch the next one.
    """

    model_config = ConfigDict(populate_by_name=True)

    items: Sequence[ItemT]
    count: int = Field(
        description="Number of elements returned in the current page.",
    )
    limit: Optional[int] = Field(
        default=None, description="Limit applied when retrieving this page."
    )
    exclusive_start_key: Optional[Dict[str, Any]] = Field(
        default=None,
        alias="from",
        description="ExclusiveStartKey used to produce the current page.",
    )
    last_evaluated_key: Optional[Dict[str, Any]] = Field(
        default=None,
        alias="end",
        description="DynamoDB LastEvaluatedKey to request the next page.",
    )

    @model_validator(mode="before")
    @classmethod
    def ensure_count(cls, data: Any) -> Any:
        """
        Automatically populate count when only items are provided.

        This makes it easier to build the response from raw query results.
        """
        if isinstance(data, dict) and "count" not in data and "items" in data:
            try:
                data["count"] = len(data["items"])
            except TypeError:
                # When items is not sized we let validation handle the error later.
                pass
        return data

    @classmethod
    def from_items(
        cls,
        items: Sequence[ItemT],
        *,
        limit: Optional[int] = None,
        exclusive_start_key: Optional[Dict[str, Any]] = None,
        last_evaluated_key: Optional[Dict[str, Any]] = None,
    ) -> "PaginationResponse[ItemT]":
        """
        Helper constructor that infers the count from the provided collection.
        """
        return cls(
            items=items,
            limit=limit,
            exclusive_start_key=exclusive_start_key,
            last_evaluated_key=last_evaluated_key,
        )
