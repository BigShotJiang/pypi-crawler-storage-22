"""FinanceGY - a Python library for accessing data from the Guyana Stock Exchange."""

from financegy.cache.cache_manager import clear_cache
from financegy.utils.utils import save_to_csv, to_dataframe, save_to_excel

from financegy.modules.securities import (
    get_securities,
    get_security_by_symbol,
    get_recent_trade,
    get_previous_close,
    get_price_change,
    get_price_change_percent,
    get_security_recent_year,
    get_session_trades,
    get_sessions_average_price,
    get_average_price,
    get_sessions_volatility,
    get_ytd_high_low,
    get_latest_session_for_symbol,
    get_security_session_trade,
    search_securities,
    get_trades_for_year,
    get_historical_trades,
)

from financegy.modules.portfolio import (
    calculate_position_value,
    calculate_position_return,
    calculate_position_return_percent,
    calculate_portfolio_summary,
)

__all__ = [
    "get_securities",
    "get_security_by_symbol",
    "get_recent_trade",
    "get_previous_close",
    "get_price_change",
    "get_price_change_percent",
    "get_security_recent_year",
    "get_session_trades",
    "get_sessions_average_price",
    "get_average_price",
    "get_security_session_trade",
    "get_latest_session_for_symbol",
    "get_sessions_volatility",
    "get_ytd_high_low",
    "search_securities",
    "get_trades_for_year",
    "get_historical_trades",
    "calculate_position_value",
    "calculate_position_return",
    "calculate_position_return_percent",
    "calculate_portfolio_summary",
    "clear_cache",
    "save_to_csv",
    "to_dataframe",
    "save_to_excel",
]
