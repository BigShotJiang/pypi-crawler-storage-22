"""Project automation scripts package.

Provides CLI tools and helpers for building, testing, versioning,
and releasing the project.
"""

from __future__ import annotations

__all__ = []
