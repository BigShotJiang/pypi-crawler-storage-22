"""finfetch — Free financial data for Indian stocks. No API key needed."""

from __future__ import annotations

from .core import Ticker, Tickers, get_price
from .models import search
from .classification import IndustryClassification, fetch_classification
from .indices import fetch_index_data, fetch_index_snapshot, list_indices
from .export import export_data
from .constants import INDIAN_INDICES
from .exceptions import (
    DataUnavailableError,
    FinFetchError,
    RateLimitError,
    ScrapingError,
    TickerNotFoundError,
)

__version__ = "0.2.01"


def available_fields(statement_type: str | None = None) -> dict:
    """List all available canonical field names.

    Returns a dict with keys ``'pl'``, ``'bs'``, ``'cf'``, ``'ratios'``.
    Each value is a sorted list of field name strings.

    Parameters
    ----------
    statement_type : str, optional
        If provided, return only the list of fields for that statement type.
    """
    from .mappings import (
        SCREENER_PL, SCREENER_BS, SCREENER_CF, SCREENER_RATIOS,
        MC_PL, MC_BS, MC_CF, MC_RATIOS,
    )

    sections = {
        "pl": (SCREENER_PL, MC_PL),
        "bs": (SCREENER_BS, MC_BS),
        "cf": (SCREENER_CF, MC_CF),
        "ratios": (SCREENER_RATIOS, MC_RATIOS),
    }

    result = {}
    for key, (screener_map, mc_map) in sections.items():
        # Merge all canonical names from both sources into one flat list
        all_fields = sorted(set(screener_map.values()) | set(mc_map.values()))
        result[key] = all_fields

    if statement_type:
        return result.get(statement_type, [])
    return result


__all__ = [
    # Core
    "Ticker",
    "Tickers",
    "get_price",
    "search",
    "available_fields",
    # Classification
    "IndustryClassification",
    "fetch_classification",
    # Indices
    "fetch_index_data",
    "fetch_index_snapshot",
    "list_indices",
    "INDIAN_INDICES",
    # Export
    "export_data",
    # Exceptions
    "FinFetchError",
    "TickerNotFoundError",
    "DataUnavailableError",
    "RateLimitError",
    "ScrapingError",
]
