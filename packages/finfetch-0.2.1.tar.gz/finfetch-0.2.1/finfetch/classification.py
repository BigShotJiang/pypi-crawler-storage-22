"""NSE 4-level industry classification for Indian equities."""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Optional

import requests

from .constants import NSE_HEADERS
from .exceptions import FinFetchError, TickerNotFoundError


@dataclass
class IndustryClassification:
    """Mirrors NSE's 4-level classification exactly.

    Screener.in displays this as a breadcrumb::

        Energy > Oil, Gas & Consumable Fuels > Petroleum Products > Refineries & Marketing
    """

    macro_economic_sector: str  # Level 1 — broadest (Energy, Financial Services, etc.)
    sector: str                 # Level 2 — narrower (Oil Gas & Consumable Fuels, Banks, etc.)
    industry: str               # Level 3 — specific (Petroleum Products, Private Banks, etc.)
    basic_industry: str         # Level 4 — most specific (Refineries & Marketing, etc.)

    def to_dict(self) -> dict:
        return {
            "macro_economic_sector": self.macro_economic_sector,
            "sector": self.sector,
            "industry": self.industry,
            "basic_industry": self.basic_industry,
        }

    def breadcrumb(self) -> str:
        """Screener-style breadcrumb format."""
        return (
            f"{self.macro_economic_sector} > {self.sector} > "
            f"{self.industry} > {self.basic_industry}"
        )


# Module-level variable that stores the last fetched classification.
# User can trigger: finfetch classify RELIANCE
current_classification: Optional[IndustryClassification] = None


def _get_nse_session() -> requests.Session:
    """Create a session with NSE cookies (hit homepage first)."""
    session = requests.Session()
    session.headers.update(NSE_HEADERS)
    try:
        session.get("https://www.nseindia.com", timeout=10)
        time.sleep(1)
    except Exception:
        pass  # cookies may still work from server response
    return session


def fetch_classification(symbol: str) -> IndustryClassification:
    """Fetch NSE industry classification for a given symbol.

    Hits the NSE quote-equity API to get the ``industryInfo`` field.
    Stores result in :data:`current_classification` for downstream use.

    Parameters
    ----------
    symbol : str
        NSE ticker symbol (e.g. ``"RELIANCE"``).

    Returns
    -------
    IndustryClassification
        The 4-level industry classification.

    Raises
    ------
    TickerNotFoundError
        If NSE returns no data for the symbol.
    FinFetchError
        On network or parsing errors.
    """
    global current_classification
    symbol = symbol.strip().upper()

    session = _get_nse_session()

    url = f"https://www.nseindia.com/api/quote-equity?symbol={symbol}"
    try:
        time.sleep(1)  # rate-limit
        resp = session.get(url, timeout=15)
    except Exception as exc:
        raise FinFetchError(f"Failed to connect to NSE for '{symbol}': {exc}") from exc

    if resp.status_code == 404 or resp.status_code == 400:
        raise TickerNotFoundError(
            symbol,
            suggestions=["Make sure this is the exact NSE ticker symbol."],
        )
    if resp.status_code != 200:
        raise FinFetchError(
            f"NSE returned HTTP {resp.status_code} for '{symbol}'"
        )

    try:
        data = resp.json()
    except Exception:
        raise FinFetchError(f"Invalid JSON response from NSE for '{symbol}'")

    industry_info = data.get("industryInfo", {})
    if not industry_info:
        raise FinFetchError(
            f"No industry classification data found for '{symbol}'. "
            "The symbol may be delisted or an index."
        )

    classification = IndustryClassification(
        macro_economic_sector=industry_info.get("macroSector", industry_info.get("macro", "")),
        sector=industry_info.get("sector", ""),
        industry=industry_info.get("industry", ""),
        basic_industry=industry_info.get("basicIndustry", industry_info.get("basic_industry", "")),
    )
    current_classification = classification
    return classification
