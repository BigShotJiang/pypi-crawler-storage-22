"""Command-line interface for FinFetch.

Usage::

    # Get industry classification
    finfetch classify RELIANCE

    # Get index data
    finfetch index "NIFTY 50" --period 6mo --export csv

    # Get all indices snapshot
    finfetch indices --export both
"""

from __future__ import annotations

import argparse
import sys

import pandas as pd


def _print_classification(classification) -> None:
    """Pretty-print industry classification."""
    print(f"\n{'━' * 50}")
    print(f"  Macro-Economic Sector : {classification.macro_economic_sector}")
    print(f"  Sector                : {classification.sector}")
    print(f"  Industry              : {classification.industry}")
    print(f"  Basic Industry        : {classification.basic_industry}")
    print(f"{'━' * 50}")
    print(f"  Breadcrumb: {classification.breadcrumb()}")
    print()


def _print_table(df: pd.DataFrame, title: str = "") -> None:
    """Print DataFrame as a formatted table."""
    from tabulate import tabulate

    if title:
        print(f"\n{title}")
        print("━" * min(len(title) + 20, 80))
    if df.empty:
        print("  (no data)")
        return
    print(tabulate(df, headers="keys", tablefmt="simple", showindex=False))
    print()


def _maybe_export(df: pd.DataFrame, name: str, fmt: str | None) -> None:
    """Export DataFrame if --export was specified."""
    if fmt:
        from .export import export_data
        export_data(df, name, fmt=fmt)


def cmd_classify(args) -> None:
    """Handle the ``classify`` subcommand."""
    from .classification import fetch_classification

    symbol = args.symbol.upper()
    print(f"Fetching industry classification for {symbol}...")
    try:
        classification = fetch_classification(symbol)
        print(f"\nSymbol: {symbol}")
        _print_classification(classification)
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)



def cmd_index(args) -> None:
    """Handle the ``index`` subcommand."""
    from .indices import fetch_index_data

    index_name = args.name
    period = args.period
    print(f"Fetching {index_name} data (period: {period})...")

    try:
        df = fetch_index_data(index_name, period=period)
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)

    if df.empty:
        print(f"No data available for '{index_name}'.")
        sys.exit(1)

    _print_table(df.tail(10), f"{index_name} — Last 10 entries")
    safe_name = index_name.lower().replace(" ", "_")
    _maybe_export(df, f"index_{safe_name}_{period}", args.export)


def cmd_indices(args) -> None:
    """Handle the ``indices`` subcommand."""
    from .indices import fetch_index_snapshot

    print("Fetching snapshot of all major Indian indices...")
    try:
        df = fetch_index_snapshot()
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)

    if df.empty:
        print("No index data available.")
        sys.exit(1)

    _print_table(df, "Indian Market Indices")
    _maybe_export(df, "indices_snapshot", args.export)



def build_parser() -> argparse.ArgumentParser:
    """Build the CLI argument parser."""
    parser = argparse.ArgumentParser(
        prog="finfetch",
        description="FinFetch — Free financial data for Indian stocks. No API key needed.",
    )
    parser.add_argument(
        "--version", action="version", version="%(prog)s 0.2.01"
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # --- classify ---
    p_classify = subparsers.add_parser(
        "classify", help="Get NSE 4-level industry classification for a stock"
    )
    p_classify.add_argument("symbol", help="NSE ticker symbol (e.g. RELIANCE)")
    p_classify.set_defaults(func=cmd_classify)

    # --- index ---
    p_index = subparsers.add_parser(
        "index", help="Fetch historical data for an Indian index"
    )
    p_index.add_argument("name", help="Index name (e.g. 'NIFTY 50') or yfinance ticker")
    p_index.add_argument(
        "--period", default="1y",
        help="Period: 1d, 5d, 1mo, 3mo, 6mo, 1y, 2y, 5y, max (default: 1y)"
    )
    p_index.add_argument(
        "--export", choices=["csv", "xlsx", "both"], default=None,
        help="Export format"
    )
    p_index.set_defaults(func=cmd_index)

    # --- indices ---
    p_indices = subparsers.add_parser(
        "indices", help="Snapshot of all major Indian indices"
    )
    p_indices.add_argument(
        "--export", choices=["csv", "xlsx", "both"], default=None,
        help="Export format"
    )
    p_indices.set_defaults(func=cmd_indices)

    return parser


def main() -> None:
    """CLI entry point."""
    parser = build_parser()
    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        sys.exit(0)

    args.func(args)


if __name__ == "__main__":
    main()
