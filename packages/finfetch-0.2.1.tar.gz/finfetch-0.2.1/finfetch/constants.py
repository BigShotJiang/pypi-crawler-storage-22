"""Shared constants: index tickers, NSE headers."""

from __future__ import annotations

# ---------------------------------------------------------------------------
# NSE request headers (required to avoid being blocked)
# ---------------------------------------------------------------------------

NSE_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    "Accept": "application/json",
    "Accept-Language": "en-US,en;q=0.9",
    "Referer": "https://www.nseindia.com/",
}

# ---------------------------------------------------------------------------
# Indian index yfinance ticker mapping
# ---------------------------------------------------------------------------

INDIAN_INDICES: dict[str, str] = {
    "NIFTY 50": "^NSEI",
    "SENSEX": "^BSESN",
    "NIFTY BANK": "^NSEBANK",
    "NIFTY IT": "^CNXIT",
    "NIFTY MIDCAP 100": "NIFTY_MIDCAP_100.NS",
    "NIFTY SMALLCAP 100": "NIFTY_SMLCAP_100.NS",
    "NIFTY PHARMA": "^CNXPHARMA",
    "NIFTY METAL": "^CNXMETAL",
    "NIFTY AUTO": "^CNXAUTO",
    "NIFTY FMCG": "^CNXFMCG",
    "NIFTY ENERGY": "^CNXENERGY",
    "NIFTY REALTY": "^CNXREALTY",
    "NIFTY INFRA": "^CNXINFRA",
    "NIFTY FIN SERVICE": "NIFTY_FIN_SERVICE.NS",
    "INDIA VIX": "^INDIAVIX",
}
