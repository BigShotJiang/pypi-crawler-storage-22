"""Core module: Ticker / Tickers classes — orchestrates data sources."""

from __future__ import annotations

import re
import warnings

import pandas as pd
import yfinance as yf

from .exceptions import DataUnavailableError, TickerNotFoundError
from .mappings import normalize_header
from .sources.screener import ScreenerSource
from .sources.moneycontrol import MoneyControlSource


_SECTION = {
    "pl": "profit-loss",
    "quarters": "quarters",
    "bs": "balance-sheet",
    "cf": "cash-flow",
    "ratios": "ratios",
}

# Patterns for normalizing period columns to "Mon YYYY" format
_SHORT_PERIOD_RE = re.compile(r"^([A-Za-z]{3})\s+(\d{2})$")              # "Mar 16"
_SHORT_PERIOD_APOS_RE = re.compile(r"^([A-Za-z]{3})['\u2019]?\s*(\d{2})$")  # "Mar'16", "Mar\u201916"


class Ticker:
    """Primary interface — wraps a single NSE-listed stock.

    Usage::

        import finfetch as ff
        stock = ff.Ticker("RELIANCE")

        # Properties (quick access)
        stock.financials           # P&L
        stock.balance_sheet        # Balance Sheet
        stock.cashflow             # Cash Flow
        stock.ratios               # Ratios

        # Methods (custom timeline)
        stock.get_financials(years=20)
        stock.get_balance_sheet(from_year=2005, to_year=2015)
        stock.get_cashflow(from_year=2010)
        stock.get_ratios(to_year=2020)
    """

    def __init__(self, ticker: str, view: str = "consolidated") -> None:
        self.ticker = ticker.upper().strip()
        self.view = view
        self._mc = MoneyControlSource()
        self._screener: ScreenerSource | None = None
        self._cache: dict[str, object] = {}

    def __repr__(self) -> str:
        return f"Ticker('{self.ticker}')"

    def _get_screener(self) -> ScreenerSource:
        """Lazy init Screener source (backup)."""
        if self._screener is None:
            self._screener = ScreenerSource()
        return self._screener

    # ---- Identity ----

    @property
    def symbol(self) -> str:
        """Resolved NSE symbol."""
        return self.ticker

    # ---- Properties ----

    @property
    def financials(self) -> pd.DataFrame:
        """Returns P&L with all available years."""
        return self._get_statement("pl")

    def get_financials(
        self,
        from_year: int | None = None,
        to_year: int | None = None,
        years: int | None = None,
    ) -> pd.DataFrame:
        """Fetch P&L with custom timeline.

        Parameters
        ----------
        from_year : int, optional
            Fiscal year start (e.g. 2005 = FY ending March 2005).
        to_year : int, optional
            Fiscal year end.
        years : int, optional
            Number of years from the most recent.
        """
        return self._get_statement("pl", from_year, to_year, years)

    @property
    def balance_sheet(self) -> pd.DataFrame:
        """Returns balance sheet with all available years."""
        return self._get_statement("bs")

    def get_balance_sheet(
        self,
        from_year: int | None = None,
        to_year: int | None = None,
        years: int | None = None,
    ) -> pd.DataFrame:
        """Fetch balance sheet with custom timeline."""
        return self._get_statement("bs", from_year, to_year, years)

    @property
    def cashflow(self) -> pd.DataFrame:
        """Returns cash flow with all available years."""
        return self._get_statement("cf")

    def get_cashflow(
        self,
        from_year: int | None = None,
        to_year: int | None = None,
        years: int | None = None,
    ) -> pd.DataFrame:
        """Fetch cash flow with custom timeline."""
        return self._get_statement("cf", from_year, to_year, years)

    @property
    def ratios(self) -> pd.DataFrame:
        """Returns ratios with all available years."""
        return self._get_statement("ratios")

    def get_ratios(
        self,
        from_year: int | None = None,
        to_year: int | None = None,
        years: int | None = None,
    ) -> pd.DataFrame:
        """Fetch ratios with custom timeline."""
        return self._get_statement("ratios", from_year, to_year, years)

    @property
    def quarterly_financials(self) -> pd.DataFrame:
        """Returns quarterly P&L with all available quarters."""
        return self._get_statement("quarters")

    def get_quarterly_financials(
        self,
        from_year: int | None = None,
        to_year: int | None = None,
        years: int | None = None,
    ) -> pd.DataFrame:
        """Fetch quarterly P&L with custom timeline.

        Parameters
        ----------
        from_year : int, optional
            Calendar year start (e.g. 2023).
        to_year : int, optional
            Calendar year end.
        years : int, optional
            Number of years of quarters from the most recent.
        """
        return self._get_statement("quarters", from_year, to_year, years)

    @property
    def price(self) -> float:
        """Current market price (INR) via yfinance."""
        cached = self._cache.get("price")
        if cached is not None:
            return cached
        yf_ticker = yf.Ticker(f"{self.ticker}.NS")
        data = yf_ticker.fast_info
        val = float(data["lastPrice"])
        self._cache["price"] = val
        return val

    @property
    def info(self) -> dict:
        """Key company information and ratios."""
        cached = self._cache.get("info")
        if cached is not None:
            return cached
        screener = self._get_screener()
        val = screener.fetch_info(
            self.ticker, consolidated=(self.view == "consolidated")
        )
        self._cache["info"] = val
        return val

    # ---- Price history via yfinance ----

    def history(
        self,
        period: str = "1y",
        interval: str = "1d",
        start: str | None = None,
        end: str | None = None,
    ) -> pd.DataFrame:
        """Fetch historical OHLCV price data via yfinance.

        Parameters
        ----------
        period : str
            Time period to fetch. Valid values: ``1d``, ``5d``, ``1mo``,
            ``3mo``, ``6mo``, ``1y``, ``2y``, ``5y``, ``10y``, ``ytd``, ``max``.
            Ignored if *start* is provided.
        interval : str
            Bar interval. Valid values: ``1m``, ``2m``, ``5m``, ``15m``,
            ``30m``, ``60m``, ``90m``, ``1h``, ``1d``, ``5d``, ``1wk``, ``1mo``, ``3mo``.
            Intraday intervals limited to last 60 days.
        start : str, optional
            Start date string (e.g. ``"2020-01-01"``). Overrides *period*.
        end : str, optional
            End date string (e.g. ``"2024-12-31"``).

        Returns
        -------
        pd.DataFrame
            DataFrame with DatetimeIndex and columns:
            ``open``, ``high``, ``low``, ``close``, ``volume``.
            Prices in INR.
        """
        cache_key = f"history_{period}_{interval}_{start}_{end}"
        if cache_key in self._cache:
            return self._cache[cache_key]

        yf_ticker = yf.Ticker(f"{self.ticker}.NS")

        if start:
            df = yf_ticker.history(start=start, end=end, interval=interval)
        else:
            df = yf_ticker.history(period=period, interval=interval)

        if df is None or df.empty:
            raise DataUnavailableError(
                self.ticker, "history",
                [("yfinance", f"No price data for {self.ticker}.NS")],
            )

        # Normalize column names to lowercase
        df.columns = [c.lower().replace(" ", "_") for c in df.columns]

        # Keep only core OHLCV columns + dividends/splits if present
        keep = [c for c in df.columns if c in (
            "open", "high", "low", "close", "volume",
            "dividends", "stock_splits",
        )]
        df = df[keep]

        self._cache[cache_key] = df
        return df

    @property
    def dividends(self) -> pd.Series:
        """Dividend history from yfinance."""
        cached = self._cache.get("dividends")
        if cached is not None:
            return cached
        yf_ticker = yf.Ticker(f"{self.ticker}.NS")
        divs = yf_ticker.dividends
        self._cache["dividends"] = divs
        return divs

    @property
    def splits(self) -> pd.Series:
        """Stock split history from yfinance."""
        cached = self._cache.get("splits")
        if cached is not None:
            return cached
        yf_ticker = yf.Ticker(f"{self.ticker}.NS")
        sp = yf_ticker.splits
        self._cache["splits"] = sp
        return sp

    # ---- Core fetch + merge logic ----

    def _get_statement(
        self,
        stmt_type: str,
        from_year: int | None = None,
        to_year: int | None = None,
        years: int | None = None,
    ) -> pd.DataFrame:
        """Master fetch method.

        1. Always fetch from MoneyControl first (primary source, complete data)
        2. Normalize MC headers to canonical names
        3. Optionally enrich with Screener data as backup
        4. MC data wins for overlapping year+field combos
        5. Apply timeline filter (from_year, to_year, years)
        6. Return final DataFrame
        """
        cache_key = f"{stmt_type}_{from_year}_{to_year}_{years}"
        if cache_key in self._cache:
            return self._cache[cache_key]

        consolidated = self.view == "consolidated"
        section = _SECTION.get(stmt_type)
        if section is None:
            raise DataUnavailableError(self.ticker, stmt_type, [])

        # Step 1: MoneyControl (primary source)
        mc_data = pd.DataFrame()
        try:
            max_years = years or 20
            pages = max(1, max_years // 5 + 1)

            raw_mc = self._mc.fetch(
                self.ticker,
                section,
                consolidated=consolidated,
                pages=pages,
            )

            if raw_mc is not None and not raw_mc.empty:
                raw_mc.columns = [self._normalize_period_col(c) for c in raw_mc.columns]
                raw_mc = raw_mc.dropna(axis=0, how="all")
                raw_mc.index = [
                    normalize_header(h, "moneycontrol", stmt_type)
                    for h in raw_mc.index
                ]
                raw_mc = raw_mc[~raw_mc.index.duplicated(keep="first")]
                mc_data = raw_mc
        except (KeyboardInterrupt, SystemExit):
            raise
        except Exception as e:
            warnings.warn(f"MoneyControl fetch failed: {e}")

        # Step 2: Screener (backup — enrich with any fields MC might miss)
        screener_data = pd.DataFrame()
        try:
            screener = self._get_screener()
            raw_scr = screener.fetch(
                self.ticker, section, consolidated=consolidated
            )

            if raw_scr is not None and not raw_scr.empty:
                raw_scr.columns = [self._normalize_period_col(c) for c in raw_scr.columns]
                raw_scr = raw_scr.dropna(axis=0, how="all")
                raw_scr.index = [
                    normalize_header(h, "screener", stmt_type)
                    for h in raw_scr.index
                ]
                raw_scr = raw_scr[~raw_scr.index.duplicated(keep="first")]
                screener_data = raw_scr
        except (TickerNotFoundError, KeyboardInterrupt, SystemExit):
            raise
        except Exception:
            pass  # Screener is backup — silently skip on failure

        # Step 3: Merge — MoneyControl wins on overlap
        if mc_data.empty and screener_data.empty:
            raise DataUnavailableError(self.ticker, stmt_type, [])

        if mc_data.empty:
            # Only Screener data available
            combined = screener_data
        elif screener_data.empty:
            # Only MC data available
            combined = mc_data
        else:
            # Both available — MC is primary, enrich with Screener-only rows/cols
            combined = mc_data.copy()

            # Add Screener-only rows (fields MC doesn't have)
            scr_only_rows = screener_data.loc[
                screener_data.index.difference(mc_data.index)
            ]
            if not scr_only_rows.empty:
                combined = pd.concat([combined, scr_only_rows])

            # Add Screener-only columns (unlikely but handle gracefully)
            scr_only_cols = [
                c for c in screener_data.columns
                if c not in mc_data.columns
            ]
            if scr_only_cols:
                for col in scr_only_cols:
                    combined[col] = screener_data[col]

        # Step 4: Clean up — drop rows that are entirely NaN
        combined = combined.dropna(axis=0, how="all")

        # Step 5: Apply timeline filter
        result = self._apply_timeline(combined, from_year, to_year, years)

        # Step 6: Cache and return
        self._cache[cache_key] = result
        return result

    def _apply_timeline(
        self,
        df: pd.DataFrame,
        from_year: int | None = None,
        to_year: int | None = None,
        years: int | None = None,
    ) -> pd.DataFrame:
        """Filter DataFrame columns by year range."""
        if df.empty:
            return df

        # Extract numeric years from column names
        year_cols: dict[str, int] = {}
        for col in df.columns:
            yr = self._extract_year(col)
            if yr:
                year_cols[col] = yr

        if not year_cols:
            return df

        # Filter by year range
        sorted_cols = sorted(year_cols.items(), key=lambda x: x[1])
        filtered_cols = []

        for col, yr in sorted_cols:
            if from_year and yr < from_year:
                continue
            if to_year and yr > to_year:
                continue
            filtered_cols.append(col)

        if years:
            # Take the last N years
            filtered_cols = filtered_cols[-years:]

        return df[filtered_cols] if filtered_cols else df

    @staticmethod
    def _normalize_period_col(col: str) -> str:
        """Normalize period column to 'Mon YYYY' format.

        Handles: 'Mar 16', 'Mar'16', 'Mar \u201916', 'Mar  16' → 'Mar 2016'.
        """
        col = col.strip().replace("\xa0", " ")
        # Try standard "Mar 16" pattern first
        m = _SHORT_PERIOD_RE.match(col)
        if m:
            month, yy = m.group(1), int(m.group(2))
            return f"{month} {2000 + yy}"
        # Try apostrophe variant "Mar'16"
        m = _SHORT_PERIOD_APOS_RE.match(col)
        if m:
            month, yy = m.group(1), int(m.group(2))
            return f"{month} {2000 + yy}"
        return col

    @staticmethod
    def _extract_year(col_name: str) -> int | None:
        """Extract fiscal year from column like 'Mar 2024', 'FY2024', '2024'."""
        match = re.search(r"(\d{4})", str(col_name))
        return int(match.group(1)) if match else None

    def clear_cache(self) -> None:
        """Expire all cached data for this ticker."""
        self._cache.clear()


# ======================================================================
# Tickers  (multi-stock convenience)
# ======================================================================


class Tickers:
    """Convenience wrapper for multiple tickers.

    Parameters
    ----------
    symbols : str
        Space-separated ticker symbols, e.g. ``"RELIANCE TCS INFY"``.
    """

    def __init__(self, symbols: str, **kw) -> None:
        self.symbols = [s.strip() for s in symbols.split() if s.strip()]
        self.tickers: dict[str, Ticker] = {
            s: Ticker(s, **kw) for s in self.symbols
        }

    def __repr__(self) -> str:
        return f"Tickers('{' '.join(self.symbols)}')"

    def __getitem__(self, symbol: str) -> Ticker:
        return self.tickers[symbol.upper()]

    def __iter__(self):
        return iter(self.tickers.values())


# ======================================================================
# Module-level convenience
# ======================================================================


def get_price(symbol: str) -> float:
    """Quick helper — return the current price for *symbol*."""
    return Ticker(symbol).price
