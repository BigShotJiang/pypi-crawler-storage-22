"""Custom exceptions for finfetch."""

from __future__ import annotations


class FinFetchError(Exception):
    """Base exception for all finfetch errors."""


class TickerNotFoundError(FinFetchError):
    """Raised when a ticker symbol cannot be resolved."""

    def __init__(self, symbol: str, suggestions: list[str] | None = None):
        self.symbol = symbol
        self.suggestions = suggestions or []
        msg = f"Ticker '{symbol}' not found"
        if self.suggestions:
            msg += f". Did you mean: {', '.join(self.suggestions)}?"
        super().__init__(msg)


class DataUnavailableError(FinFetchError):
    """Raised when data cannot be fetched from any source."""

    def __init__(
        self,
        symbol: str,
        section: str,
        errors: list[tuple[str, str]] | None = None,
    ):
        self.symbol = symbol
        self.section = section
        self.errors = errors or []
        msg = f"Could not fetch '{section}' data for '{symbol}'"
        if self.errors:
            details = "; ".join(f"{src}: {err}" for src, err in self.errors)
            msg += f" [{details}]"
        super().__init__(msg)


class RateLimitError(FinFetchError):
    """Raised when a source returns HTTP 429."""

    def __init__(self, source: str):
        self.source = source
        super().__init__(f"Rate limited by {source}. Try again later.")


class ScrapingError(FinFetchError):
    """Raised when HTML parsing fails unexpectedly."""

    def __init__(self, source: str, detail: str = ""):
        self.source = source
        msg = f"Failed to parse data from {source}"
        if detail:
            msg += f": {detail}"
        super().__init__(msg)
