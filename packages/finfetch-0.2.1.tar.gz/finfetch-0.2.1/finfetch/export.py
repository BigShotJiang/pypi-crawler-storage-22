"""CSV and Excel (.xlsx) export utilities."""

from __future__ import annotations

from pathlib import Path

import pandas as pd


DEFAULT_EXPORT_DIR = Path("./finfetch_exports")


def export_data(
    df: pd.DataFrame,
    name: str,
    fmt: str = "both",
    output_dir: str | Path | None = None,
) -> list[Path]:
    """Export a DataFrame to Excel and/or CSV.

    Parameters
    ----------
    df : pd.DataFrame
        The data to export.
    name : str
        Base filename (without extension).
    fmt : str
        ``"csv"``, ``"xlsx"``, or ``"both"`` (default).
    output_dir : str or Path, optional
        Directory for exports. Defaults to ``./finfetch_exports``.

    Returns
    -------
    list[Path]
        Paths to the exported files.
    """
    out = Path(output_dir) if output_dir else DEFAULT_EXPORT_DIR
    out.mkdir(parents=True, exist_ok=True)

    exported: list[Path] = []

    if fmt in ("csv", "both"):
        csv_path = out / f"{name}.csv"
        df.to_csv(csv_path)
        print(f"Exported: {csv_path}")
        exported.append(csv_path)

    if fmt in ("xlsx", "both"):
        xlsx_path = out / f"{name}.xlsx"
        from openpyxl.utils import get_column_letter
        from openpyxl.styles import Font, Alignment, PatternFill, Border, Side

        with pd.ExcelWriter(xlsx_path, engine="openpyxl") as writer:
            df.to_excel(writer, sheet_name="Data")
            ws = writer.sheets["Data"]

            # Style constants
            header_font = Font(bold=True, size=11)
            header_fill = PatternFill(start_color="2F3640", end_color="2F3640", fill_type="solid")
            header_text = Font(bold=True, size=11, color="FFFFFF")
            index_font = Font(bold=True, size=10)
            num_fmt = '#,##0.00'
            thin_border = Border(
                bottom=Side(style="thin", color="D5D8DC"),
            )

            # Style header row (row 1)
            for col_idx in range(1, ws.max_column + 1):
                cell = ws.cell(row=1, column=col_idx)
                cell.font = header_text
                cell.fill = header_fill
                cell.alignment = Alignment(horizontal="center")

            # Style index column (col A) and data cells
            for row_idx in range(2, ws.max_row + 1):
                # Bold index label
                idx_cell = ws.cell(row=row_idx, column=1)
                idx_cell.font = index_font

                # Format numeric data cells
                for col_idx in range(2, ws.max_column + 1):
                    cell = ws.cell(row=row_idx, column=col_idx)
                    if isinstance(cell.value, (int, float)):
                        cell.number_format = num_fmt
                        cell.alignment = Alignment(horizontal="right")
                    cell.border = thin_border

            # Auto-fit column widths
            for col_idx in range(1, ws.max_column + 1):
                max_len = 0
                for row_idx in range(1, ws.max_row + 1):
                    val = ws.cell(row=row_idx, column=col_idx).value
                    if val is not None:
                        max_len = max(max_len, len(str(val)))
                col_letter = get_column_letter(col_idx)
                ws.column_dimensions[col_letter].width = min(max_len + 3, 45)

            # Freeze top row + index column
            ws.freeze_panes = "B2"

        print(f"Exported: {xlsx_path}")
        exported.append(xlsx_path)

    return exported
