"""Indian index/indices data via yfinance."""

from __future__ import annotations

import pandas as pd
import yfinance as yf

from .constants import INDIAN_INDICES


def fetch_index_data(index_name: str, period: str = "1y") -> pd.DataFrame:
    """Fetch historical data for an Indian index.

    Parameters
    ----------
    index_name : str
        Human-readable name (e.g. ``"NIFTY 50"``) or yfinance ticker
        (e.g. ``"^NSEI"``).
    period : str
        yfinance period string — ``1d``, ``5d``, ``1mo``, ``3mo``, ``6mo``,
        ``1y``, ``2y``, ``5y``, ``max``.

    Returns
    -------
    pd.DataFrame
        DataFrame with Date, Open, High, Low, Close, Volume columns.
    """
    ticker = INDIAN_INDICES.get(index_name.upper(), index_name)
    data = yf.download(ticker, period=period, progress=False)
    if data is None or data.empty:
        return pd.DataFrame()
    data.reset_index(inplace=True)
    # Flatten MultiIndex columns if yfinance returns them
    if isinstance(data.columns, pd.MultiIndex):
        data.columns = [col[0] if col[1] == "" else col[0] for col in data.columns]
    return data


def fetch_index_snapshot() -> pd.DataFrame:
    """Fetch current price + day change for all major Indian indices.

    Returns
    -------
    pd.DataFrame
        DataFrame with columns: Index, Ticker, Current, Change, Change %.
    """
    rows = []
    for name, ticker in INDIAN_INDICES.items():
        try:
            info = yf.Ticker(ticker)
            hist = info.history(period="2d")
            if len(hist) >= 2:
                prev_close = hist["Close"].iloc[-2]
                curr = hist["Close"].iloc[-1]
                change = curr - prev_close
                pct = (change / prev_close) * 100
                rows.append({
                    "Index": name,
                    "Ticker": ticker,
                    "Current": round(float(curr), 2),
                    "Change": round(float(change), 2),
                    "Change %": round(float(pct), 2),
                })
        except Exception:
            continue
    return pd.DataFrame(rows)


def list_indices() -> dict[str, str]:
    """Return the mapping of human-readable index names to yfinance tickers."""
    return dict(INDIAN_INDICES)
