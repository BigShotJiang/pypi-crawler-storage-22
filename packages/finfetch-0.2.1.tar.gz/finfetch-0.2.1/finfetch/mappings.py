"""
Header mappings between data sources and canonical FinFetch names.

Rules:
1. Every DataFrame output uses CANONICAL names (the dict values below)
2. MoneyControl is the primary source — its headers are mapped first
3. Screener is the backup source — used for enrichment
4. Both sources map to the same canonical snake_case field names
"""

from __future__ import annotations

import re


# ============================================================
# PROFIT & LOSS STATEMENT
# ============================================================

SCREENER_PL = {
    "Sales +": "revenue",
    "Sales": "revenue",
    "Expenses +": "total_expenses",
    "Expenses": "total_expenses",
    "Operating Profit": "operating_profit",
    "OPM %": "opm_pct",
    "Other Income +": "other_income",
    "Other Income": "other_income",
    "Interest": "interest_expense",
    "Depreciation": "depreciation",
    "Profit before tax": "profit_before_tax",
    "Tax %": "tax_pct",
    "Net Profit +": "net_profit",
    "Net Profit": "net_profit",
    "EPS in Rs": "eps",
    "Dividend Payout %": "dividend_payout_pct",
}

MC_PL = {
    # --- Revenue ---
    "Net Sales/Income from operations": "revenue",
    "Net Sales/Income From Operations": "revenue",
    "Total Income From Operations": "revenue",
    "Total Operating Revenues": "revenue",
    "Revenue From Operations (Net)": "revenue",
    "Revenue From Operations": "revenue",
    "Revenue From Operations [Net]": "revenue",
    # --- Revenue (gross) ---
    "Revenue From Operations (Gross)": "revenue_gross",
    "Gross Sales": "revenue_gross",
    # --- Excise / levies ---
    "Less: Excise/Service Tax/Other Levies": "excise_and_levies",
    "Less: Excise/Sevice Tax/Other Levies": "excise_and_levies",
    # --- Total revenue ---
    "Total Revenue": "total_revenue",
    # --- Expenses ---
    "Total Expenditure": "total_expenses",
    "Total Expenses": "total_expenses",
    # --- Operating profit ---
    "Operating Profit (EBIT)": "operating_profit",
    "Operating Profit": "operating_profit",
    "Operating Profit Margin(%)": "opm_pct",
    # --- Other income ---
    "Other Income": "other_income",
    # --- Interest ---
    "Interest": "interest_expense",
    "Finance Costs": "interest_expense",
    # --- Depreciation ---
    "Depreciation": "depreciation",
    "Depreciation And Amortisation Expenses": "depreciation",
    # --- PBT ---
    "Profit/Loss Before Tax": "profit_before_tax",
    "Profit Before Tax": "profit_before_tax",
    "Profit/Loss Before Exceptional, Extraordinary Items And Tax": "profit_before_exceptional",
    "Profit/Loss Before Exceptional Extraordinary Items And Tax": "profit_before_exceptional",
    # --- Tax ---
    "Tax": "tax_expense",
    "Total Tax Expenses": "tax_expense",
    "Current Tax": "current_tax",
    "Deferred Tax": "deferred_tax",
    "Less: MAT Credit Entitlement": "mat_credit",
    "Tax For Earlier Years": "tax_earlier_years",
    # --- Net profit ---
    "Profit/Loss After Tax": "net_profit",
    "Profit After Tax": "net_profit",
    "Profit/Loss After Tax And Before ExtraOrdinary Items": "net_profit",
    "Profit/Loss After Tax And Before Extraordinary Items": "net_profit",
    "Profit/Loss From Continuing Operations": "net_profit",
    "Profit/Loss For The Period": "net_profit",
    # --- EPS ---
    "Earnings Per Share": "eps",
    "Basic EPS (Rs.)": "eps_basic",
    "Diluted EPS (Rs.)": "eps_diluted",
    "Dividend Per Share": "dividend_per_share",
    # --- Expense breakdowns ---
    "Cost Of Materials Consumed": "raw_material_cost",
    "Purchase Of Stock-In-Trade": "purchase_stock_in_trade",
    "Purchase Of Stock In Trade": "purchase_stock_in_trade",
    "Changes In Inventories": "inventory_change",
    "Changes In Inventories Of FG, WIP And Stock-In-Trade": "inventory_change",
    "Changes In Inventories Of FG WIP And Stock In Trade": "inventory_change",
    "Changes In Inventories Of FG,WIP And Stock-In-Trade": "inventory_change",
    "Employee Benefit Expenses": "employee_cost",
    "Employee Benefits Expense": "employee_cost",
    "Employee Cost": "employee_cost",
    "Operating And Direct Expenses": "operating_direct_expenses",
    "Selling General And Administrative Expenses": "sga_expense",
    "Other Expenses": "other_expenses",
    # --- Exceptional / extraordinary ---
    "Exceptional Items": "exceptional_items",
    "Prior Period Items": "prior_period_items",
    "Extraordinary Items": "extraordinary_items",
    "Minority Interest": "minority_interest",
    "Share Of Profit/Loss Of Associates": "associate_profit_share",
    # --- Dividend ---
    "Equity Share Dividend": "equity_share_dividend",
    "Tax On Dividend": "tax_on_dividend",
    "Equity Dividend Rate (%)": "equity_dividend_rate",
    "Equity Dividend Rate": "equity_dividend_rate",
    "Dividend Payout Ratio (Net Profit)(%)": "dividend_payout_pct",
    # --- Raw material detail ---
    "Imported Raw Materials": "imported_raw_materials",
    "Indigenous Raw Materials": "indigenous_raw_materials",
    "Imported Stores And Spares": "imported_stores_and_spares",
    "Indigenous Stores And Spares": "indigenous_stores_and_spares",
}


# ============================================================
# BALANCE SHEET
# ============================================================

SCREENER_BS = {
    "Equity Capital": "equity_capital",
    "Reserves": "reserves",
    "Borrowings +": "total_borrowings",
    "Borrowings": "total_borrowings",
    "Other Liabilities +": "other_liabilities",
    "Other Liabilities": "other_liabilities",
    "Total Liabilities": "total_liabilities",
    "Fixed Assets +": "fixed_assets",
    "Fixed Assets": "fixed_assets",
    "CWIP": "cwip",
    "Investments": "investments",
    "Other Assets +": "other_assets",
    "Other Assets": "other_assets",
    "Total Assets": "total_assets",
}

MC_BS = {
    # --- Equity / Shareholders' Funds ---
    "Equity Share Capital": "equity_capital",
    "Total Share Capital": "total_share_capital",
    "Reserves and Surplus": "reserves",
    "Reserves And Surplus": "reserves",
    "Total Reserves And Surplus": "reserves",
    "Total Shareholders Funds": "shareholders_funds",
    "Total Shareholders' Funds": "shareholders_funds",
    "Shareholders Funds": "shareholders_funds",

    # --- Non-Current Liabilities ---
    "Long Term Borrowings": "long_term_borrowings",
    "Deferred Tax Liabilities [Net]": "deferred_tax_liability",
    "Deferred Tax Liabilities": "deferred_tax_liability",
    "Other Long Term Liabilities": "other_long_term_liabilities",
    "Long Term Provisions": "long_term_provisions",
    "Total Non-Current Liabilities": "total_non_current_liabilities",

    # --- Current Liabilities ---
    "Short Term Borrowings": "short_term_borrowings",
    "Trade Payables": "trade_payables",
    "Other Current Liabilities": "other_current_liabilities",
    "Short Term Provisions": "short_term_provisions",
    "Total Current Liabilities": "total_current_liabilities",

    "Total Capital And Liabilities": "total_liabilities",
    "Total Liabilities": "total_liabilities",

    # --- Non-Current Assets ---
    "Tangible Assets": "tangible_assets",
    "Property Plant And Equipment": "tangible_assets",
    "Intangible Assets": "intangible_assets",
    "Capital Work-In-Progress": "cwip",
    "Capital Work In Progress": "cwip",
    "Intangible Assets Under Development": "intangible_under_dev",
    "Fixed Assets": "fixed_assets",
    "Non-Current Investments": "non_current_investments",
    "Non Current Investments": "non_current_investments",
    "Deferred Tax Assets [Net]": "deferred_tax_asset",
    "Deferred Tax Assets": "deferred_tax_asset",
    "Long Term Loans And Advances": "long_term_loans_advances",
    "Other Non-Current Assets": "other_non_current_assets",
    "Other Non Current Assets": "other_non_current_assets",
    "Total Non-Current Assets": "total_non_current_assets",
    "Total Non Current Assets": "total_non_current_assets",

    # --- Current Assets ---
    "Current Investments": "current_investments",
    "Inventories": "inventories",
    "Inventory": "inventories",
    "Trade Receivables": "trade_receivables",
    "Cash And Cash Equivalents": "cash_and_equivalents",
    "Cash and Cash Equivalents": "cash_and_equivalents",
    "Short Term Loans And Advances": "short_term_loans_advances",
    "Other Current Assets": "other_current_assets_detail",
    "Total Current Assets": "total_current_assets",

    "Total Assets": "total_assets",

    # --- Other ---
    "Contingent Liabilities": "contingent_liabilities",
    "Book Value": "book_value",
    "Book Value (Rs.)": "book_value",
    "Goodwill": "goodwill",
    "Minority Interest": "minority_interest",
    "Net Worth": "shareholders_funds",

    # --- Borrowings aggregate ---
    "Total Debt": "total_borrowings",
    "Borrowings": "total_borrowings",
}


# ============================================================
# CASH FLOW STATEMENT
# ============================================================

SCREENER_CF = {
    "Cash from Operating Activity +": "cfo",
    "Cash from Operating Activity": "cfo",
    "Cash from Investing Activity +": "cfi",
    "Cash from Investing Activity": "cfi",
    "Cash from Financing Activity +": "cff",
    "Cash from Financing Activity": "cff",
    "Net Cash Flow": "net_cash_flow",
}

MC_CF = {
    "Net CashFlow From Operating Activities": "cfo",
    "Net Cash Flow From Operating Activities": "cfo",
    "Cash From Operating Activity": "cfo",
    "Cash From Operating Activities": "cfo",
    "Net Cash Used In Investing Activities": "cfi",
    "Net Cash From Investing Activities": "cfi",
    "Cash From Investing Activity": "cfi",
    "Cash From Investing Activities": "cfi",
    "Net Cash Used From Financing Activities": "cff",
    "Net Cash From Financing Activities": "cff",
    "Cash From Financing Activity": "cff",
    "Cash From Financing Activities": "cff",
    "Net Inc/Dec In Cash And Cash Equivalents": "net_cash_flow",
    "Net Cash Flow": "net_cash_flow",
    "Net Increase In Cash And Cash Equivalents": "net_cash_flow",
    # --- Detailed breakdowns ---
    "Depreciation And Amortisation": "cf_depreciation",
    "Interest Received": "cf_interest_received",
    "Dividend Received": "cf_dividend_received",
    "Interest Paid": "cf_interest_paid",
    "Income Tax Paid": "cf_tax_paid",
    "Direct Taxes Paid (Refund)": "cf_tax_paid",
    "Purchase Of Fixed Assets": "cf_capex",
    "Sale Of Fixed Assets": "cf_asset_sale",
    "Purchase Of Investments": "cf_investment_purchase",
    "Sale Of Investments": "cf_investment_sale",
    "Proceeds From Borrowings": "cf_borrowing_proceeds",
    "Repayment Of Borrowings": "cf_borrowing_repayment",
    "Dividends Paid": "cf_dividends_paid",
    "Dividend Paid": "cf_dividends_paid",
}


# ============================================================
# RATIOS
# ============================================================

SCREENER_RATIOS = {
    "Debtor Days": "debtor_days",
    "Inventory Days": "inventory_days",
    "Days Payable": "days_payable",
    "Cash Conversion Cycle": "cash_conversion_cycle",
    "Working Capital Days": "working_capital_days",
    "ROCE %": "roce_pct",
    "ROE %": "roe_pct",
}

MC_RATIOS = {
    "Basic EPS (Rs.)": "eps_basic",
    "Diluted EPS (Rs.)": "eps_diluted",
    "Cash EPS (Rs.)": "eps_cash",
    "Book Value [InclRewordsn./ExclRewordsn.] (Rs.)": "book_value",
    "Book Value (Rs.)": "book_value",
    "Dividend Per Share (Rs.)": "dividend_per_share",
    "Revenue From Operations": "revenue",
    "Operating Profit (Rs. Cr.)": "operating_profit",
    "PBDIT (Rs. Cr.)": "pbdit",
    "PBIT (Rs. Cr.)": "pbit",
    "PBT (Rs. Cr.)": "pbt",
    "Net Profit (Rs. Cr.)": "net_profit",
    "Return on Networth / Equity(%)": "roe_pct",
    "Return On Networth(%)": "roe_pct",
    "Return On Capital Employed(%)": "roce_pct",
    "Return on Assets(%)": "roa_pct",
    "Debt Equity Ratio": "debt_equity_ratio",
    "Debt-Equity Ratio": "debt_equity_ratio",
    "Current Ratio": "current_ratio",
    "Quick Ratio": "quick_ratio",
    "Interest Cover": "interest_cover",
    "Total Debt/Equity": "total_debt_equity",
    "Asset Turnover Ratio": "asset_turnover",
    "Inventory Turnover Ratio": "inventory_turnover",
    "Debtors Turnover Ratio": "debtors_turnover",
    "Fixed Assets Turnover Ratio": "fixed_asset_turnover",
    "Operating Profit Margin(%)": "opm_pct",
    "Net Profit Margin(%)": "npm_pct",
    "Gross Profit Margin(%)": "gpm_pct",
    "Dividend Payout Ratio (Net Profit)(%)": "dividend_payout_pct",
    "Earnings Yield": "earnings_yield",
    "EV/EBITDA": "ev_ebitda",
    "Price To Book Value": "pb_ratio",
    "Price To Earnings": "pe_ratio",
    "Price To Sales": "ps_ratio",
}


# ============================================================
# FIELDS ONLY ON MONEYCONTROL (not on Screener at all)
# When user requests these, go directly to MC.
# ============================================================

MC_EXTENDED_FIELDS = {
    # P&L extended fields
    "revenue_gross",
    "excise_and_levies",
    "total_revenue",
    "raw_material_cost",
    "employee_cost",
    "purchase_stock_in_trade",
    "inventory_change",
    "operating_direct_expenses",
    "sga_expense",
    "exceptional_items",
    "profit_before_exceptional",
    "current_tax",
    "deferred_tax",
    "mat_credit",
    "tax_earlier_years",
    "tax_expense",
    "eps_basic",
    "eps_diluted",
    "minority_interest",
    "associate_profit_share",
    "equity_share_dividend",
    "tax_on_dividend",
    "equity_dividend_rate",
    "imported_raw_materials",
    "indigenous_raw_materials",
    "imported_stores_and_spares",
    "indigenous_stores_and_spares",
    # Balance Sheet breakdowns
    "total_share_capital",
    "shareholders_funds",
    "total_current_assets",
    "total_non_current_assets",
    "total_current_liabilities",
    "total_non_current_liabilities",
    "inventories",
    "trade_receivables",
    "cash_and_equivalents",
    "trade_payables",
    "short_term_borrowings",
    "long_term_borrowings",
    "tangible_assets",
    "intangible_assets",
    "intangible_under_dev",
    "goodwill",
    "deferred_tax_liability",
    "deferred_tax_asset",
    "contingent_liabilities",
    "current_investments",
    "non_current_investments",
    "short_term_loans_advances",
    "long_term_loans_advances",
    "other_long_term_liabilities",
    "long_term_provisions",
    "short_term_provisions",
    "other_current_assets_detail",
    "other_non_current_assets",
    # Cash Flow breakdowns
    "cf_capex",
    "cf_depreciation",
    "cf_interest_paid",
    "cf_interest_received",
    "cf_dividend_received",
    "cf_tax_paid",
    "cf_dividends_paid",
    "cf_asset_sale",
    "cf_investment_purchase",
    "cf_investment_sale",
    "cf_borrowing_proceeds",
    "cf_borrowing_repayment",
    # Ratios
    "current_ratio",
    "quick_ratio",
    "debt_equity_ratio",
    "total_debt_equity",
    "interest_cover",
    "roa_pct",
    "npm_pct",
    "gpm_pct",
    "pe_ratio",
    "pb_ratio",
    "ps_ratio",
    "ev_ebitda",
    "earnings_yield",
    "asset_turnover",
    "inventory_turnover",
    "debtors_turnover",
    "fixed_asset_turnover",
    "pbdit",
    "pbit",
    "pbt",
    "eps_cash",
}


# ============================================================
# UTILITY: Normalize any raw header from either source
# ============================================================

def normalize_header(raw_header: str, source: str, statement_type: str) -> str:
    """Convert a raw header from Screener or MoneyControl to canonical name.

    Parameters
    ----------
    raw_header : str
        The exact text from the HTML table (e.g., "Sales +").
    source : str
        ``"screener"`` or ``"moneycontrol"``.
    statement_type : str
        ``"pl"``, ``"bs"``, ``"cf"``, or ``"ratios"``.

    Returns
    -------
    str
        Canonical name (e.g., ``"revenue"``) or a snake_cased fallback.
    """
    maps = {
        ("screener", "pl"): SCREENER_PL,
        ("screener", "quarters"): SCREENER_PL,  # Quarters use same P&L headers
        ("screener", "bs"): SCREENER_BS,
        ("screener", "cf"): SCREENER_CF,
        ("screener", "ratios"): SCREENER_RATIOS,
        ("moneycontrol", "pl"): MC_PL,
        ("moneycontrol", "quarters"): MC_PL,
        ("moneycontrol", "bs"): MC_BS,
        ("moneycontrol", "cf"): MC_CF,
        ("moneycontrol", "ratios"): MC_RATIOS,
    }

    mapping = maps.get((source, statement_type), {})

    # Try exact match first
    if raw_header in mapping:
        return mapping[raw_header]

    # Try stripped (remove trailing +, whitespace, etc.)
    cleaned = raw_header.strip().rstrip("+").strip()
    if cleaned in mapping:
        return mapping[cleaned]

    # Try case-insensitive match
    cleaned_lower = cleaned.lower()
    for key, val in mapping.items():
        if key.lower() == cleaned_lower:
            return val

    # Fallback: snake_case the raw header
    fallback = re.sub(r"[^a-zA-Z0-9]+", "_", cleaned_lower).strip("_")
    return fallback
