"""Data models, field-name normalisation, and ticker resolution."""

from __future__ import annotations

import re
from dataclasses import dataclass, asdict


# ---------------------------------------------------------------------------
# Field-name aliases  (canonical name → known variants across sources)
# ---------------------------------------------------------------------------

FIELD_ALIASES: dict[str, list[str]] = {
    # --- Income statement ---
    "Revenue": [
        "Sales", "Revenue", "Net Sales", "Total Revenue", "Turnover",
        "Total Operating Revenue", "Income From Operations", "Net Revenue",
        "Revenue From Operations [Net]", "Total Operating Revenues",
    ],
    "COGS": [
        "Cost of Goods Sold", "COGS", "Cost Of Revenue", "Material Cost",
        "Cost of Materials Consumed", "Purchases of Stock-In-Trade",
    ],
    "Gross Profit": ["Gross Profit", "Gross Income"],
    "Operating Profit": [
        "Operating Profit", "EBIT", "Operating Income",
        "Profit from Operations", "Operating Profit Before Interest",
    ],
    "Operating Expenses": [
        "Operating Expenses", "Total Operating Expenses", "Expenses",
        "Total Expenses",
    ],
    "OPM%": ["OPM %", "OPM%", "Operating Profit Margin", "Operating Margin"],
    "EBITDA": ["EBITDA", "Operating Profit + Depreciation"],
    "Depreciation": [
        "Depreciation", "Depreciation & Amortization",
        "Depreciation And Amortization", "D&A",
        "Depreciation And Amortisation Expenses",
    ],
    "Interest": [
        "Interest", "Finance Costs", "Interest Expense",
        "Finance Cost", "Interest & Finance Charges",
        "Interest And Finance Charges",
    ],
    "Profit Before Tax": [
        "Profit Before Tax", "PBT", "Income Before Tax",
        "Pretax Income", "Profit before tax",
        "Profit/Loss Before Tax",
        "Profit/Loss Before Exceptional, ExtraOrdinary Items And Tax",
    ],
    "Tax": [
        "Tax", "Tax Expense", "Income Tax Expense",
        "Tax %", "Income Tax", "Taxes", "Tax Provision",
        "Total Tax Expenses",
    ],
    "Net Profit": [
        "Net Profit", "PAT", "Profit After Tax", "Net Income",
        "Profit for the period", "Net Profit / Loss",
        "Profit / Loss for the period",
        "Profit/Loss For The Period",
        "Profit/Loss After Tax And Before ExtraOrdinary Items",
        "Profit/Loss From Continuing Operations",
    ],
    "EPS": ["EPS", "Earnings Per Share", "Basic EPS", "EPS (Rs)", "EPS in Rs", "Basic EPS (Rs.)"],
    "Diluted EPS": ["Diluted EPS", "Diluted Earnings Per Share", "Diluted EPS (Rs.)"],
    "Dividend Payout": [
        "Dividend Payout", "Dividend Payout %", "Payout Ratio",
        "Equity Dividend Rate (%)", "Equity Share Dividend",
    ],
    # --- Balance sheet ---
    "Total Assets": ["Total Assets", "Total assets"],
    "Total Liabilities": ["Total Liabilities", "Total liabilities"],
    "Shareholders Equity": [
        "Shareholders Equity", "Total Equity", "Equity",
        "Net Worth", "Shareholders' Equity", "Stockholders Equity",
        "Total Shareholders Equity",
    ],
    "Total Debt": [
        "Total Debt", "Borrowings", "Total Borrowings",
        "Long-term Borrowings", "Short & Long Term Debt",
    ],
    "Current Assets": ["Current Assets", "Total Current Assets"],
    "Current Liabilities": ["Current Liabilities", "Total Current Liabilities"],
    "Cash": [
        "Cash", "Cash and Cash Equivalents", "Cash & Bank",
        "Cash And Cash Equivalents",
    ],
    "Fixed Assets": [
        "Fixed Assets", "Net PPE", "Property Plant Equipment",
        "Property, Plant & Equipment", "Tangible Assets",
    ],
    "Inventory": ["Inventory", "Inventories"],
    "Receivables": [
        "Receivables", "Trade Receivables", "Accounts Receivable",
        "Sundry Debtors",
    ],
    "Reserves": ["Reserves", "Reserves & Surplus", "Retained Earnings"],
    "Share Capital": ["Share Capital", "Equity Share Capital"],
    # --- Cash flow ---
    "Operating Cash Flow": [
        "Operating Cash Flow", "CFO", "Cash from Operating Activity",
        "Cash from Operations",
    ],
    "Investing Cash Flow": [
        "Investing Cash Flow", "CFI", "Cash from Investing Activity",
        "Cash Used in Investing",
    ],
    "Financing Cash Flow": [
        "Financing Cash Flow", "CFF", "Cash from Financing Activity",
        "Cash from Financing",
    ],
    "Net Cash Flow": ["Net Cash Flow", "Net Change in Cash"],
    "CapEx": [
        "CapEx", "Capital Expenditure", "Capital Expenditures",
        "Purchase of Fixed Assets",
    ],
    "Free Cash Flow": ["Free Cash Flow", "FCF"],
    # --- Ratios ---
    "PE Ratio": ["PE Ratio", "P/E", "Price to Earning"],
    "PB Ratio": ["PB Ratio", "P/B", "Price to Book Value"],
    "EV/EBITDA": ["EV/EBITDA", "Enterprise Value / EBITDA"],
    "ROE": ["ROE", "Return on Equity", "Return On Equity"],
    "ROCE": ["ROCE", "Return on Capital Employed"],
    "ROA": ["ROA", "Return on Assets"],
    "Debt to Equity": ["Debt to Equity", "Debt/Equity", "D/E"],
    "Current Ratio": ["Current Ratio"],
    "Interest Coverage": ["Interest Coverage", "Interest Coverage Ratio"],
    "Dividend Yield": ["Dividend Yield", "Div Yield"],
    "Promoter Holding": ["Promoter Holding", "Promoter Holding %", "Promoters"],
    "FII Holding": ["FII Holding", "FII %", "FIIs"],
    "DII Holding": ["DII Holding", "DII %", "DIIs"],
}

# Reverse lookup:  lowercased variant → canonical name
_VARIANT_TO_CANONICAL: dict[str, str] = {}
for _canonical, _variants in FIELD_ALIASES.items():
    _VARIANT_TO_CANONICAL[_canonical.lower()] = _canonical
    for _v in _variants:
        _VARIANT_TO_CANONICAL[_v.lower()] = _canonical


def normalize_field_name(name: str) -> str:
    """Map any known variant to its canonical field name."""
    cleaned = name.strip().lower()
    if cleaned in _VARIANT_TO_CANONICAL:
        return _VARIANT_TO_CANONICAL[cleaned]
    for sep in ("_", "-"):
        alt = cleaned.replace(sep, " ")
        if alt in _VARIANT_TO_CANONICAL:
            return _VARIANT_TO_CANONICAL[alt]
    return name.strip()


# ---------------------------------------------------------------------------
# Snake-case conversion
# ---------------------------------------------------------------------------

def _to_snake(name: str) -> str:
    """Convert a human-readable field name to snake_case."""
    s = name.replace("%", "_pct").replace("/", "_").replace("&", "_and_")
    s = re.sub(r"[''()]", "", s)
    s = re.sub(r"\s+", "_", s.strip())
    # Insert underscore before uppercase letters (camelCase → camel_Case)
    s = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", s)
    s = re.sub(r"_+", "_", s).strip("_").lower()
    return s


# Pre-built map for canonical names
CANONICAL_TO_SNAKE: dict[str, str] = {k: _to_snake(k) for k in FIELD_ALIASES}


def canonical_to_snake(name: str) -> str:
    """Convert canonical field name to snake_case, falling back to generic conversion."""
    return CANONICAL_TO_SNAKE.get(name, _to_snake(name))


# ---------------------------------------------------------------------------
# Ticker resolution  (direct NSE ticker — no map needed)
# ---------------------------------------------------------------------------

def resolve_ticker(query: str) -> str:
    """Resolve input to an NSE ticker symbol.

    Simply uppercases and strips the input.  Screener.in URLs use the
    exact NSE ticker directly, so no mapping dictionary is needed.

    Use :func:`search` to discover the correct ticker for a company.
    """
    return query.strip().upper()


def search(query: str, limit: int = 10) -> list[dict[str, str]]:
    """Search for companies by name via the Screener.in API.

    Parameters
    ----------
    query : str
        Company name or partial ticker to search for.
    limit : int
        Maximum number of results (default 10).

    Returns
    -------
    list[dict]
        Each dict has keys: ``symbol``, ``name``, ``url``.
    """
    from .sources.screener import ScreenerSource

    return ScreenerSource.search(query, limit=limit)


# ---------------------------------------------------------------------------
# Dataclass for structured company info
# ---------------------------------------------------------------------------

@dataclass
class TickerInfo:
    """Structured company information returned by :pyattr:`Ticker.info`."""

    symbol: str = ""
    name: str = ""
    sector: str = ""
    industry: str = ""
    market_cap: float | None = None
    current_price: float | None = None
    pe_ratio: float | None = None
    pb_ratio: float | None = None
    ev_ebitda: float | None = None
    roe: float | None = None
    roce: float | None = None
    dividend_yield: float | None = None
    debt_to_equity: float | None = None
    current_ratio: float | None = None
    book_value: float | None = None
    face_value: float | None = None
    high_52w: float | None = None
    low_52w: float | None = None
    promoter_holding: float | None = None

    def to_dict(self) -> dict:
        """Return all non-None fields as a plain dict."""
        return {k: v for k, v in asdict(self).items() if v is not None}
