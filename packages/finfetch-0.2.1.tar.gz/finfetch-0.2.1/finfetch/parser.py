"""HTML parsing, number conversion, and DataFrame standardisation."""

from __future__ import annotations

import math
import re
from datetime import datetime

import pandas as pd
from bs4 import BeautifulSoup, Tag

from .models import normalize_field_name, canonical_to_snake


# ---------------------------------------------------------------------------
# Indian-format number parser
# ---------------------------------------------------------------------------


def parse_indian_number(value: str | None) -> float | None:
    """Parse an Indian-formatted number string into a float.

    Handles lakhs/crores grouping (``2,34,567``), percentages, negative
    values in parentheses, currency symbols, and common suffixes like *Cr*.

    Returns ``None`` for blank or unparseable values.
    """
    if value is None:
        return None

    value = str(value).strip()
    # Normalize non-breaking spaces and other whitespace
    value = value.replace("\xa0", " ").replace("\u200b", "").strip()
    if not value or value in ("-", "\u2014", "\u2013", "\u2212"):
        return None

    # Percentage suffix
    is_percent = value.endswith("%")
    if is_percent:
        value = value[:-1].strip()

    # Negative: parenthesised or leading minus (including Unicode minus \u2212)
    is_negative = False
    if value.startswith("(") and value.endswith(")"):
        is_negative = True
        value = value[1:-1].strip()
    elif value.startswith("-") or value.startswith("\u2212"):
        is_negative = True
        value = value[1:].strip()

    # Strip commas, currency symbols, and common suffixes
    value = value.replace(",", "")
    value = value.replace("\u20b9", "").replace("Rs.", "").replace("Rs", "").strip()
    value = re.sub(
        r"\s*(Cr\.?|Crores?|Lakh|L)\s*$", "", value, flags=re.IGNORECASE
    ).strip()

    if not value:
        return None

    try:
        result = float(value)
    except ValueError:
        return None

    if is_negative:
        result = -result
    if math.isnan(result) or math.isinf(result):
        return None
    return result


# ---------------------------------------------------------------------------
# Period string → datetime
# ---------------------------------------------------------------------------

_MONTH_PATTERNS = [
    "%b %Y",     # "Mar 2024"
    "%B %Y",     # "March 2024"
    "%b %y",     # "Mar 24"
    "%Y-%m-%d",  # "2024-03-31"
    "%m/%Y",     # "03/2024"
]


def parse_period(text: str) -> datetime | None:
    """Best-effort parse of a period label into a :class:`datetime`."""
    text = text.strip()
    for fmt in _MONTH_PATTERNS:
        try:
            return datetime.strptime(text, fmt)
        except ValueError:
            continue
    return None


# ---------------------------------------------------------------------------
# HTML table → raw DataFrame  (used by Screener / Trendlyne / MoneyControl)
# ---------------------------------------------------------------------------


def parse_html_table(table: Tag) -> pd.DataFrame | None:
    """Parse a financial HTML ``<table>`` into a raw DataFrame.

    Returns a DataFrame with:
    - Index  = line-item labels
    - Columns = period strings exactly as they appear in the HTML header
    - Values  = parsed floats (via :func:`parse_indian_number`)

    Returns ``None`` if the table cannot be meaningfully parsed.
    """
    # --- header row ---
    thead = table.find("thead")
    header_row = (thead.find("tr") if thead else None) or table.find("tr")
    if header_row is None:
        return None

    headers = [th.get_text(strip=True) for th in header_row.find_all(["th", "td"]) if th.get_text(strip=True)]
    if len(headers) < 2:
        return None

    period_headers = headers[1:]  # first column is the row-label header

    # --- body rows ---
    tbody = table.find("tbody")
    rows = (tbody.find_all("tr") if tbody else table.find_all("tr")[1:])

    data: dict[str, list[float | None]] = {}
    for tr in rows:
        cells = tr.find_all(["td", "th"])
        if not cells:
            continue
        label = cells[0].get_text(strip=True)
        if not label:
            continue
        # Clean trailing '+' expand buttons from Screener
        label = re.sub(r"\s*\+\s*$", "", label).strip()
        # Normalize non-breaking spaces in labels
        label = label.replace("\xa0", " ").strip()

        values = [parse_indian_number(c.get_text(strip=True)) for c in cells[1:]]
        # Pad / trim to match headers
        while len(values) < len(period_headers):
            values.append(None)
        values = values[: len(period_headers)]

        # Skip rows where ALL values are None (section headers like "INCOME", "EXPENDITURE")
        if all(v is None for v in values):
            continue

        data[label] = values

    if not data:
        return None

    df = pd.DataFrame(data, index=period_headers).T
    df.columns.name = None
    df.index.name = None
    return df


def parse_screener_top_ratios(soup: BeautifulSoup) -> dict[str, float | str | None]:
    """Extract the key-highlights list from a Screener company page."""
    top = soup.find("div", id="top-ratios") or soup.find("ul", id="top-ratios")
    if not top:
        return {}

    ratios: dict[str, float | str | None] = {}
    for li in top.find_all("li"):
        name_el = li.find("span", class_="name")
        value_el = li.find("span", class_="number") or li.find("span", class_="value")
        if name_el and value_el:
            name = name_el.get_text(strip=True)
            raw = value_el.get_text(strip=True)
            parsed = parse_indian_number(raw)
            ratios[name] = parsed if parsed is not None else raw
    return ratios


# ---------------------------------------------------------------------------
# Raw DataFrame → standardised DataFrame
# ---------------------------------------------------------------------------


def standardize_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    """Convert a raw scraper DataFrame into the public API format.

    1. Normalise row labels to canonical field names.
    2. Transpose so that **periods become rows** and **fields become columns**.
    3. Convert period strings to a :class:`~pandas.DatetimeIndex`.
    4. Rename columns to ``snake_case``.
    5. Coerce all values to numeric, replacing blanks with ``NaN``.
    """
    # 1. Drop rows that are entirely NaN (section headers like "INCOME", "CURRENT ASSETS")
    #    before normalisation, so they don't shadow actual data rows during dedup
    df = df.dropna(axis=0, how="all")

    # 2. Normalise index (line-item names)
    df.index = [normalize_field_name(idx) for idx in df.index]

    # Remove duplicate field rows (keep first — now the data row, not the header)
    df = df[~df.index.duplicated(keep="first")]

    # 3. Transpose: periods → rows, fields → columns
    df = df.T

    # 4. Parse period index to datetime
    new_index = []
    for label in df.index:
        dt = parse_period(str(label))
        new_index.append(dt if dt is not None else label)
    df.index = pd.Index(new_index)

    # If all index values are datetime, set a proper DatetimeIndex
    if all(isinstance(v, datetime) for v in df.index):
        df.index = pd.DatetimeIndex(df.index)
        df.sort_index(inplace=True)

    # 5. Rename columns to snake_case
    df.columns = [canonical_to_snake(c) for c in df.columns]

    # 6. Ensure numeric types, NaN for missing
    df = df.apply(pd.to_numeric, errors="coerce")

    # 7. Drop columns that are entirely NaN
    df = df.dropna(axis=1, how="all")

    return df
