"""Data-source registry.

MoneyControl is the primary data source for all financial statements.
Screener.in is kept as a backup for enrichment.
"""

from __future__ import annotations

import logging

from .moneycontrol import MoneyControlSource
from .screener import ScreenerSource

logger = logging.getLogger("finfetch")

__all__ = ["MoneyControlSource", "ScreenerSource", "get_sources"]

_sources: list | None = None


def get_sources() -> list:
    """Lazy-initialise and return the ordered list of source singletons."""
    global _sources
    if _sources is not None:
        return _sources

    _sources = []
    for cls in (MoneyControlSource, ScreenerSource):
        try:
            _sources.append(cls())
        except Exception as exc:
            logger.debug("Skipping source %s: %s", cls.name, exc)
    return _sources
