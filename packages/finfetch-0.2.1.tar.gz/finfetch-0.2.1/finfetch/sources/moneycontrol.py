"""MoneyControl data source — primary source for all financial data.

Uses curl_cffi for Chrome TLS fingerprint impersonation to bypass
MoneyControl's Akamai CDN. URL-based pagination, no Selenium needed.
"""

from __future__ import annotations

import logging
import re

import pandas as pd
from bs4 import BeautifulSoup

from ..exceptions import RateLimitError
from ..parser import parse_html_table
from ..utils import _rate_limiter, retry_with_backoff

logger = logging.getLogger("finfetch")

_AUTOSUGGEST_URL = (
    "https://www.moneycontrol.com/mccode/common/autosuggestion_solr.php"
)


def _create_session():
    """Create an HTTP session that can bypass MoneyControl's CDN.

    Uses curl_cffi with Chrome TLS impersonation if available,
    falls back to plain requests otherwise.
    """
    try:
        from curl_cffi import requests as cffi_requests
        session = cffi_requests.Session(impersonate="chrome")
        session._is_cffi = True
        return session
    except ImportError:
        import requests
        from ..utils import DEFAULT_HEADERS
        logger.debug(
            "curl_cffi not installed — MoneyControl may return 403. "
            "Install with: pip install curl_cffi"
        )
        session = requests.Session()
        session.headers.update(
            {**DEFAULT_HEADERS, "Referer": "https://www.moneycontrol.com/"}
        )
        session._is_cffi = False
        return session


class MoneyControlSource:
    """Primary source for all financial data.

    URL pagination pattern::

        Page 1: /financials/{slug}/{type}/{code}#{code}
        Page 2: /financials/{slug}/{type}/{code}/2#{code}
        Page 3: /financials/{slug}/{type}/{code}/3#{code}

    Requires ``curl_cffi`` to bypass MoneyControl's Akamai CDN::

        pip install curl_cffi
    """

    name = "moneycontrol"
    BASE_URL = "https://www.moneycontrol.com"
    SUPPORTED_SECTIONS = [
        "profit-loss", "quarters", "balance-sheet", "cash-flow", "ratios",
    ]
    _SECTION_URL = {
        "profit-loss": "profit-lossVI",
        "quarters": "quarterly-resultsVI",
        "balance-sheet": "balance-sheetVI",
        "cash-flow": "cash-flowVI",
        "ratios": "ratiosVI",
    }

    def __init__(self) -> None:
        self._session = _create_session()
        # Cached per-ticker: {ticker: {name, id, slug, mc_code}}
        self._company_cache: dict[str, dict] = {}

    def supports(self, section: str) -> bool:
        return section in self.SUPPORTED_SECTIONS

    # ---- company discovery ----

    def _resolve_company(self, ticker: str) -> dict | None:
        """Resolve NSE ticker to MoneyControl identifiers.

        Flow:
        1. Hit autosuggest API with the ticker
        2. Extract slug from link_src URL, use sc_id as mc_code
        """
        if ticker in self._company_cache:
            return self._company_cache[ticker]

        company = self._autosuggest(ticker)
        if company is None:
            return None

        # Extract slug from link_src URL
        # e.g. ".../stockpricequote/refineries/relianceindustries/RI"
        link_src = company.get("link_src", "")
        match = re.search(r"/stockpricequote/[^/]+/([^/]+)/([^/]+)", link_src)
        if match:
            company["slug"] = match.group(1)
            company["mc_code"] = match.group(2)
        else:
            # Fallback: use id as mc_code (slug still needed)
            company["mc_code"] = company.get("id", "")

        self._company_cache[ticker] = company
        return company

    def _autosuggest(self, ticker: str) -> dict | None:
        """Use MoneyControl's autosuggest API to find company details.

        The API returns JSON with fields: sc_id, stock_name, link_src.
        """
        _rate_limiter.wait("moneycontrol.com")
        try:
            resp = self._session.get(
                _AUTOSUGGEST_URL,
                params={
                    "classic": "true",
                    "query": ticker,
                    "type": "1",
                    "format": "json",
                },
                timeout=10,
            )
            if resp.status_code != 200:
                return None

            data = resp.json()
            if not data:
                return None

            # The API returns a JSON list of company matches
            best = data[0]
            return {
                "name": best.get("stock_name", best.get("name", "")),
                "id": best.get("sc_id", ""),
                "link_src": best.get("link_src", ""),
            }
        except Exception as exc:
            logger.debug("MC autosuggest failed for '%s': %s", ticker, exc)
        return None

    # ---- URL pagination ----

    @staticmethod
    def _paginate_url(base_url: str, page: int) -> str:
        """Inject page number before the ``#`` fragment.

        Example::

            base:   .../profit-lossVI/RI#RI
            page 2: .../profit-lossVI/RI/2#RI
        """
        if page <= 1:
            return base_url
        if "#" in base_url:
            before_hash, fragment = base_url.split("#", 1)
            return f"{before_hash.rstrip('/')}/{page}#{fragment}"
        return f"{base_url.rstrip('/')}/{page}"

    # ---- fetching ----

    def fetch(
        self,
        ticker: str,
        section: str,
        *,
        consolidated: bool = True,
        pages: int = 1,
    ) -> pd.DataFrame | None:
        """Fetch financial data, optionally paginating for more history.

        Parameters
        ----------
        pages : int
            Number of pages to fetch (each page ~5 years).
        """
        seg = self._SECTION_URL.get(section)
        if seg is None:
            return None

        company = self._resolve_company(ticker)
        if company is None:
            return None

        slug = company.get("slug", "")
        mc_code = company.get("mc_code", company.get("id", ""))
        if not slug or not mc_code:
            return None

        base_url = f"{self.BASE_URL}/financials/{slug}/{seg}/{mc_code}#{mc_code}"

        all_dfs: list[pd.DataFrame] = []
        for page_num in range(1, pages + 1):
            url = self._paginate_url(base_url, page_num)
            df = self._fetch_single_page(url)
            if df is None or df.empty:
                break  # No more pages available
            all_dfs.append(df)

        if not all_dfs:
            return None

        # Merge pages: concat columns (periods), deduplicate
        merged = pd.concat(all_dfs, axis=1)
        merged = merged.loc[:, ~merged.columns.duplicated()]
        return merged

    def _fetch_single_page(self, url: str) -> pd.DataFrame | None:
        """Fetch and parse a single page of financial data."""
        def _do():
            _rate_limiter.wait("moneycontrol.com")
            r = self._session.get(url, timeout=15)
            if r.status_code == 429:
                raise RateLimitError("moneycontrol.com")
            if r.status_code != 200:
                return None
            return r

        try:
            resp = retry_with_backoff(_do)
        except Exception:
            return None

        if resp is None:
            return None

        soup = BeautifulSoup(resp.text, "lxml")
        table = (
            soup.find("table", class_="mctable1")
            or soup.find("table", class_="table4")
            or soup.find("table")
        )
        if table is None:
            return None
        return parse_html_table(table)
