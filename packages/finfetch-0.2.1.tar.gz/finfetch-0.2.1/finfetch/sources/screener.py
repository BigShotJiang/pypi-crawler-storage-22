"""Screener.in data source — backup source for enrichment and price/info."""

from __future__ import annotations

import logging
import os
import re

import pandas as pd
import requests
from bs4 import BeautifulSoup

from ..exceptions import RateLimitError, ScrapingError, TickerNotFoundError
from ..parser import parse_html_table, parse_indian_number, parse_screener_top_ratios
from ..utils import DEFAULT_HEADERS, _rate_limiter, retry_with_backoff

logger = logging.getLogger("finfetch")


class ScreenerSource:
    """Backup data source — scrapes financial tables from Screener.in."""

    name = "screener"
    BASE_URL = "https://www.screener.in"
    SEARCH_API = "https://www.screener.in/api/company/search/"
    SUPPORTED_SECTIONS = [
        "profit-loss", "quarters", "balance-sheet",
        "cash-flow", "ratios", "shareholding",
    ]

    def __init__(self) -> None:
        self._session = requests.Session()
        self._session.headers.update(
            {**DEFAULT_HEADERS, "Referer": f"{self.BASE_URL}/"}
        )
        self._logged_in = False
        email = os.getenv("SCREENER_EMAIL", "")
        password = os.getenv("SCREENER_PASSWORD", "")
        if email and password:
            self._login(email, password)

    # ---- authentication (optional, for extended history) ----

    def _login(self, email: str, password: str) -> None:
        _rate_limiter.wait("screener.in")
        page = self._session.get(f"{self.BASE_URL}/login/", timeout=15)
        page.raise_for_status()
        soup = BeautifulSoup(page.text, "lxml")
        csrf = soup.find("input", {"name": "csrfmiddlewaretoken"})
        if not csrf:
            return
        _rate_limiter.wait("screener.in")
        resp = self._session.post(
            f"{self.BASE_URL}/login/",
            data={
                "username": email,
                "password": password,
                "csrfmiddlewaretoken": csrf["value"],
            },
            headers={"Referer": f"{self.BASE_URL}/login/"},
            allow_redirects=True,
            timeout=15,
        )
        resp.raise_for_status()
        self._logged_in = "login" not in resp.url.lower()

    # ---- helpers ----

    def supports(self, section: str) -> bool:
        return section in self.SUPPORTED_SECTIONS

    def _company_url(self, ticker: str, consolidated: bool = True) -> str:
        view = "consolidated" if consolidated else "standalone"
        return f"{self.BASE_URL}/company/{ticker}/{view}/"

    def _fetch_page(self, ticker: str, consolidated: bool = True) -> BeautifulSoup:
        """Fetch and parse the Screener company page. Raises on 404."""
        url = self._company_url(ticker, consolidated)

        def _do() -> requests.Response:
            _rate_limiter.wait("screener.in")
            r = self._session.get(url, timeout=15)
            if r.status_code == 404:
                raise TickerNotFoundError(
                    ticker,
                    suggestions=[
                        f"Make sure '{ticker}' is the exact NSE ticker symbol.",
                        "Use finfetch.search() to find the correct ticker.",
                    ],
                )
            if r.status_code == 429:
                raise RateLimitError("screener.in")
            r.raise_for_status()
            return r

        resp = retry_with_backoff(_do)
        return BeautifulSoup(resp.text, "lxml")

    # ---- financial table fetch ----

    def fetch(self, ticker: str, section: str, **kw) -> pd.DataFrame | None:
        """Fetch a single financial section as a raw DataFrame."""
        consolidated = kw.get("consolidated", True)
        soup = self._fetch_page(ticker, consolidated)

        el = soup.find("section", id=section) or soup.find("div", id=section)
        if el is None:
            return None
        table = el.find("table")
        if table is None:
            return None
        return parse_html_table(table)

    # ---- price ----

    def fetch_price(self, ticker: str, consolidated: bool = True) -> float:
        """Scrape current market price from the Screener company page."""
        soup = self._fetch_page(ticker, consolidated)

        # Screener shows the current price in the top section
        # Try multiple selectors for resilience
        for selector in (
            "#top .current-price",
            "#top .number",
            ".company-info .current-price",
        ):
            el = soup.select_one(selector)
            if el:
                val = parse_indian_number(el.get_text(strip=True))
                if val is not None:
                    return float(val)

        # Fallback: look in top-ratios for "Current Price" or similar
        ratios = parse_screener_top_ratios(soup)
        for key in ("Current Price", "Market Price", "Price"):
            if key in ratios and isinstance(ratios[key], (int, float)):
                return float(ratios[key])

        raise ScrapingError("screener", f"Could not find price for '{ticker}'")

    # ---- company info ----

    def fetch_info(self, ticker: str, consolidated: bool = True) -> dict:
        """Scrape key company info and ratios from Screener top-ratios."""
        from ..models import canonical_to_snake

        soup = self._fetch_page(ticker, consolidated)
        ratios = parse_screener_top_ratios(soup)

        info: dict = {"symbol": ticker}
        for key, val in ratios.items():
            info[canonical_to_snake(key)] = val

        # Try to extract company name from the page title
        name_el = soup.select_one("h1.company-name, h1.shrink-text, #company-info h1")
        if name_el:
            info["name"] = name_el.get_text(strip=True)

        # Only "symbol" key means no actual data was scraped
        if len(info) <= 1:
            raise ScrapingError("screener", f"Could not find info for '{ticker}'")

        return info

    # ---- search (class method, no instance needed) ----

    @classmethod
    def search(cls, query: str, limit: int = 10) -> list[dict[str, str]]:
        """Search Screener.in API for company tickers.

        Returns list of dicts with keys: ``symbol``, ``name``, ``url``.
        """
        resp = requests.get(
            cls.SEARCH_API,
            params={"q": query},
            headers=DEFAULT_HEADERS,
            timeout=10,
        )
        resp.raise_for_status()

        results: list[dict[str, str]] = []
        for item in resp.json()[:limit]:
            url = item.get("url", "")
            # Extract ticker from URL: /company/RELIANCE/consolidated/ -> RELIANCE
            parts = [p for p in url.split("/") if p]
            symbol = parts[1] if len(parts) >= 2 else ""
            results.append({
                "symbol": symbol.upper(),
                "name": item.get("name", ""),
                "url": url,
            })
        return results
