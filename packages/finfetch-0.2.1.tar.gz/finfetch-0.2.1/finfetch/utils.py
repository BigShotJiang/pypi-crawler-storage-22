"""Utility functions: caching, rate limiting, retry logic."""

from __future__ import annotations

import time
import threading


# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------

DEFAULT_CACHE_TTL = 300  # 5 minutes
DEFAULT_REQUEST_DELAY = 1.5  # seconds between requests to the same domain
DEFAULT_MAX_RETRIES = 3

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/120.0.0.0 Safari/537.36"
)

DEFAULT_HEADERS = {
    "User-Agent": USER_AGENT,
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.5",
}


# ---------------------------------------------------------------------------
# TTL Cache
# ---------------------------------------------------------------------------


class TTLCache:
    """Simple thread-safe in-memory cache with per-key TTL expiration."""

    def __init__(self, ttl: int = DEFAULT_CACHE_TTL):
        self._ttl = ttl
        self._store: dict[str, tuple[float, object]] = {}
        self._lock = threading.Lock()

    def get(self, key: str):
        """Return cached value or ``None`` if missing / expired."""
        with self._lock:
            if key in self._store:
                ts, value = self._store[key]
                if time.time() - ts < self._ttl:
                    return value
                del self._store[key]
        return None

    def set(self, key: str, value: object) -> None:
        with self._lock:
            self._store[key] = (time.time(), value)

    def get_or_fetch(self, key: str, fetcher):
        """Return cached value, or call *fetcher* and cache the result."""
        cached = self.get(key)
        if cached is not None:
            return cached
        value = fetcher()
        self.set(key, value)
        return value

    def clear(self) -> None:
        with self._lock:
            self._store.clear()


# ---------------------------------------------------------------------------
# Rate Limiter
# ---------------------------------------------------------------------------


class RateLimiter:
    """Per-domain rate limiter with thread safety."""

    def __init__(self, default_delay: float = DEFAULT_REQUEST_DELAY):
        self._last_request: dict[str, float] = {}
        self._lock = threading.Lock()
        self._default_delay = default_delay

    def wait(self, domain: str, delay: float | None = None) -> None:
        """Block until enough time has passed since the last request to *domain*."""
        delay = delay if delay is not None else self._default_delay
        with self._lock:
            last = self._last_request.get(domain, 0)
            elapsed = time.time() - last
            if elapsed < delay:
                time.sleep(delay - elapsed)
            self._last_request[domain] = time.time()


# Singleton shared across all Ticker instances
_rate_limiter = RateLimiter()


# ---------------------------------------------------------------------------
# Retry with exponential back-off
# ---------------------------------------------------------------------------


def retry_with_backoff(
    func,
    *,
    max_retries: int = DEFAULT_MAX_RETRIES,
    base_delay: float = 1.0,
):
    """Execute *func* with exponential back-off on transient failures.

    Retries on HTTP 429, timeout, and connection errors.
    All other exceptions propagate immediately.
    """
    last_exc: Exception | None = None
    for attempt in range(max_retries):
        try:
            return func()
        except Exception as exc:
            last_exc = exc
            err = str(exc).lower()
            if "429" in str(exc) or "rate" in err:
                time.sleep(base_delay * (2 ** attempt))
            elif "timeout" in err or "connection" in err:
                time.sleep(base_delay * (attempt + 1))
            else:
                raise
    raise last_exc  # type: ignore[misc]
