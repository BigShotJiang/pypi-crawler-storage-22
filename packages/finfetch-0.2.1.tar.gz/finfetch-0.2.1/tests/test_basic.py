"""Basic unit tests for finfetch internals (no network required)."""

import math
from datetime import datetime
from unittest.mock import patch, MagicMock

import pandas as pd
import pytest


# ── imports ──────────────────────────────────────────────────────────

from finfetch.parser import parse_indian_number, parse_period, standardize_dataframe
from finfetch.models import (
    normalize_field_name,
    canonical_to_snake,
    resolve_ticker,
    search,
)
from finfetch.utils import TTLCache
from finfetch.exceptions import (
    FinFetchError,
    TickerNotFoundError,
    DataUnavailableError,
)


# ── parse_indian_number ─────────────────────────────────────────────


class TestParseIndianNumber:
    def test_plain_integer(self):
        assert parse_indian_number("1234") == 1234.0

    def test_indian_format(self):
        assert parse_indian_number("2,34,567") == 234567.0

    def test_western_format(self):
        assert parse_indian_number("1,234,567") == 1234567.0

    def test_negative_parentheses(self):
        assert parse_indian_number("(1,234)") == -1234.0

    def test_negative_minus(self):
        assert parse_indian_number("-500") == -500.0

    def test_percentage(self):
        assert parse_indian_number("12.5%") == 12.5

    def test_currency_symbol(self):
        assert parse_indian_number("\u20b91,000") == 1000.0

    def test_crore_suffix(self):
        assert parse_indian_number("1,500 Cr") == 1500.0

    def test_empty(self):
        assert parse_indian_number("") is None

    def test_dash(self):
        assert parse_indian_number("-") is None
        assert parse_indian_number("\u2014") is None

    def test_none(self):
        assert parse_indian_number(None) is None

    def test_unparseable(self):
        assert parse_indian_number("N/A") is None


# ── parse_period ─────────────────────────────────────────────────────


class TestParsePeriod:
    def test_month_year(self):
        dt = parse_period("Mar 2024")
        assert dt == datetime(2024, 3, 1)

    def test_iso_date(self):
        dt = parse_period("2024-03-31")
        assert dt == datetime(2024, 3, 31)

    def test_invalid(self):
        assert parse_period("TTM") is None


# ── normalize_field_name ─────────────────────────────────────────────


class TestNormalizeFieldName:
    def test_exact_canonical(self):
        assert normalize_field_name("Revenue") == "Revenue"

    def test_variant(self):
        assert normalize_field_name("Net Sales") == "Revenue"
        assert normalize_field_name("PAT") == "Net Profit"

    def test_case_insensitive(self):
        assert normalize_field_name("net profit") == "Net Profit"

    def test_unknown_passes_through(self):
        assert normalize_field_name("Some Random Field") == "Some Random Field"


# ── canonical_to_snake ───────────────────────────────────────────────


class TestCanonicalToSnake:
    def test_simple(self):
        assert canonical_to_snake("Revenue") == "revenue"
        assert canonical_to_snake("Net Profit") == "net_profit"

    def test_special_chars(self):
        assert canonical_to_snake("OPM%") == "opm_pct"
        assert canonical_to_snake("EV/EBITDA") == "ev_ebitda"


# ── resolve_ticker ───────────────────────────────────────────────────


class TestResolveTicker:
    def test_exact_ticker(self):
        assert resolve_ticker("RELIANCE") == "RELIANCE"

    def test_lowercase_uppercased(self):
        assert resolve_ticker("reliance") == "RELIANCE"

    def test_strips_whitespace(self):
        assert resolve_ticker("  INFY  ") == "INFY"

    def test_unknown_returns_upper(self):
        assert resolve_ticker("XYZNOTREAL") == "XYZNOTREAL"


# ── search (mocked — no network) ────────────────────────────────────


class TestSearch:
    def test_returns_list(self):
        mock_resp = MagicMock()
        mock_resp.raise_for_status = MagicMock()
        mock_resp.json.return_value = [
            {"name": "Reliance Industries", "url": "/company/RELIANCE/consolidated/"},
            {"name": "Reliance Power", "url": "/company/RPOWER/consolidated/"},
        ]
        with patch("finfetch.sources.screener.requests.get", return_value=mock_resp):
            results = search("Reliance")
            assert isinstance(results, list)
            assert len(results) == 2
            assert results[0]["symbol"] == "RELIANCE"
            assert results[0]["name"] == "Reliance Industries"

    def test_limit(self):
        mock_resp = MagicMock()
        mock_resp.raise_for_status = MagicMock()
        mock_resp.json.return_value = [
            {"name": f"Company {i}", "url": f"/company/CO{i}/consolidated/"}
            for i in range(10)
        ]
        with patch("finfetch.sources.screener.requests.get", return_value=mock_resp):
            results = search("Company", limit=3)
            assert len(results) <= 3


# ── TTLCache ─────────────────────────────────────────────────────────


class TestTTLCache:
    def test_set_get(self):
        c = TTLCache(ttl=60)
        c.set("k", 42)
        assert c.get("k") == 42

    def test_missing_key(self):
        c = TTLCache(ttl=60)
        assert c.get("nope") is None

    def test_get_or_fetch(self):
        c = TTLCache(ttl=60)
        val = c.get_or_fetch("x", lambda: 99)
        assert val == 99
        assert c.get("x") == 99

    def test_clear(self):
        c = TTLCache(ttl=60)
        c.set("a", 1)
        c.clear()
        assert c.get("a") is None


# ── standardize_dataframe ────────────────────────────────────────────


class TestStandardizeDataframe:
    def test_basic_standardization(self):
        # Simulate a raw screener-style DataFrame
        data = {
            "Sales": [100.0, 200.0, 300.0],
            "Net Profit": [10.0, 20.0, 30.0],
        }
        df = pd.DataFrame(data, index=["Mar 2022", "Mar 2023", "Mar 2024"]).T

        result = standardize_dataframe(df)

        # Should be transposed: periods as rows, fields as columns
        assert "revenue" in result.columns
        assert "net_profit" in result.columns
        assert len(result) == 3

    def test_nan_for_missing(self):
        data = {"Sales": [100.0, None]}
        df = pd.DataFrame(data, index=["Mar 2023", "Mar 2024"]).T
        result = standardize_dataframe(df)
        assert pd.isna(result["revenue"].iloc[1])


# ── exceptions ───────────────────────────────────────────────────────


class TestExceptions:
    def test_hierarchy(self):
        assert issubclass(TickerNotFoundError, FinFetchError)
        assert issubclass(DataUnavailableError, FinFetchError)

    def test_ticker_not_found_message(self):
        err = TickerNotFoundError("XYZ", suggestions=["XYZLTD", "XYZBANK"])
        assert "XYZ" in str(err)
        assert "XYZLTD" in str(err)

    def test_data_unavailable_message(self):
        err = DataUnavailableError("TCS", "balance-sheet", [("screener", "404")])
        assert "TCS" in str(err)
        assert "screener" in str(err)
