"""
FinNet - Financial Social Network Analysis & Information Diffusion Platform

100% FREE - No API Keys Required!
"""

# ============= CRITICAL: DISABLE TQDM GLOBALLY =============
# Must be done FIRST before any other imports
import os
import sys
import shutil

# 1. Force environment variables
os.environ['TQDM_DISABLE'] = '1'
os.environ['TQDM_NCOLS'] = '1000'

# 2. Patch BOTH shutil.get_terminal_size AND os.get_terminal_size
# deep libraries might call os.get_terminal_size directly
def _patched_get_terminal_size(fallback=(80, 24)):
    return os.terminal_size((100, 24))

shutil.get_terminal_size = _patched_get_terminal_size
try:
    os.get_terminal_size = _patched_get_terminal_size
except AttributeError:
    pass

# 3. Wrap sys.stderr to catch tqdm errors if they slip through
# This prevents specific tqdm crashes from propagating
class _StderrWrapper:
    def __init__(self, original_stderr):
        self.original_stderr = original_stderr
        
    def write(self, s):
        if self.original_stderr:
            try:
                # Filter out the specific error message if it somehow gets printed
                if "Not enough horizontal space" in s:
                    return
                self.original_stderr.write(s)
            except Exception:
                pass
                
    def flush(self):
        if self.original_stderr:
            try:
                self.original_stderr.flush()
            except Exception:
                pass
                
    def isatty(self):
        return True # Lie to tqdm that we are a TTY

if sys.stderr:
    sys.stderr = _StderrWrapper(sys.stderr)

# 4. Patch tqdm with Dummy
class _TqdmDummy:
    """Dummy tqdm that does nothing - prevents horizontal space errors in GUI."""
    def __init__(self, iterable=None, *args, **kwargs):
        self.iterable = iterable if iterable is not None else []
        self.total = len(self.iterable) if hasattr(self.iterable, '__len__') else 0
        self.n = 0
    def __iter__(self):
        return iter(self.iterable)
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_value, traceback):
        pass
        
    def update(self, n=1):
        self.n += n
        
    def set_description(self, desc=None, refresh=True):
        pass
        
    def set_postfix(self, *args, **kwargs):
        pass
        
    def close(self):
        pass
        
    def write(self, s, file=None, end="\n", nolock=False):
        pass

    def refresh(self, nolock=False, lock_args=None):
        pass

    def unpause(self):
        pass

    def reset(self, total=None):
        pass

    def display(self, msg=None, pos=None):
        pass
    
    @property
    def format_dict(self):
        return {}

    @classmethod
    def pandas(cls, *args, **kwargs):
        pass

# Create a dummy module to replace tqdm
from types import ModuleType
dummy_tqdm = ModuleType("tqdm")
dummy_tqdm.tqdm = _TqdmDummy
dummy_tqdm.trange = lambda *args, **kwargs: _TqdmDummy(range(*args))
dummy_tqdm.tqdm_notebook = _TqdmDummy
dummy_tqdm.tnrange = lambda *args, **kwargs: _TqdmDummy(range(*args))
dummy_tqdm.auto = dummy_tqdm
dummy_tqdm.std = dummy_tqdm
dummy_tqdm.notebook = dummy_tqdm

# Forcefully inject into sys.modules
sys.modules['tqdm'] = dummy_tqdm
sys.modules['tqdm.auto'] = dummy_tqdm
sys.modules['tqdm.std'] = dummy_tqdm
sys.modules['tqdm.notebook'] = dummy_tqdm

# Also try to patch if it was already imported (rare but possible)
try:
    import tqdm
    tqdm.tqdm = _TqdmDummy
    tqdm.auto.tqdm = _TqdmDummy
    tqdm.std.tqdm = _TqdmDummy
except (ImportError, AttributeError):
    pass

# ============= END TQDM PATCH =============

__version__ = "0.1.0"
__author__ = "FinNet Contributors"
__license__ = "MIT"

from finnet.utils.config import Config

config = Config()
