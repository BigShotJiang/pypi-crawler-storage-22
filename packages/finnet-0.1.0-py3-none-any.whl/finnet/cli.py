"""
FinNet CLI Entry Point

This module provides the command-line interface for launching the FinNet application.
When installed via pip, the 'finnet' command will execute the main() function.
"""

import argparse
import sys
from pathlib import Path


def main():
    """
    Main entry point for the FinNet application.
    
    Usage:
        finnet              # Launch GUI application
        finnet --version    # Show version
        finnet --cli        # Run in CLI mode (future)
    """
    parser = argparse.ArgumentParser(
        prog="finnet",
        description="FinNet - Financial Social Network Analysis Platform",
        epilog="100% FREE - No API Keys Required!"
    )
    
    parser.add_argument(
        "--version", "-v",
        action="store_true",
        help="Show version and exit"
    )
    
    parser.add_argument(
        "--cli",
        action="store_true",
        help="Run in command-line mode (non-GUI)"
    )
    
    parser.add_argument(
        "--tickers", "-t",
        type=str,
        nargs="+",
        help="Ticker symbols to analyze (for CLI mode)"
    )
    
    parser.add_argument(
        "--period", "-p",
        type=str,
        default="1y",
        choices=["1d", "5d", "1mo", "3mo", "6mo", "1y", "2y", "5y", "max"],
        help="Time period for data collection (default: 1y)"
    )
    
    parser.add_argument(
        "--output", "-o",
        type=str,
        default=None,
        help="Output directory for results"
    )
    
    args = parser.parse_args()
    
    # Show version
    if args.version:
        from finnet import __version__
        print(f"FinNet v{__version__}")
        print("Financial Social Network Analysis Platform")
        print("100% FREE - No API Keys Required!")
        sys.exit(0)
    
    # CLI mode
    if args.cli:
        if not args.tickers:
            print("Error: --tickers required in CLI mode")
            print("Example: finnet --cli --tickers AAPL GOOGL MSFT")
            sys.exit(1)
        
        run_cli_analysis(args.tickers, args.period, args.output)
        sys.exit(0)
    
    # Default: Launch GUI
    launch_gui()


def launch_gui():
    """Launch the CustomTkinter GUI application."""
    try:
        from finnet.gui.main_window import FinNetApp
        
        print("=" * 50)
        print("   FinNet - Financial Social Network Analysis")
        print("   100% FREE - No API Keys Required!")
        print("=" * 50)
        print("\nLaunching application...")
        
        app = FinNetApp()
        app.mainloop()
        
    except ImportError as e:
        print(f"Error: Could not import GUI components: {e}")
        print("Please ensure customtkinter is installed:")
        print("  pip install customtkinter")
        sys.exit(1)
    except Exception as e:
        print(f"Error launching GUI: {e}")
        sys.exit(1)


def run_cli_analysis(tickers: list, period: str, output_dir: str = None):
    """
    Run analysis in command-line mode.
    
    Args:
        tickers: List of ticker symbols
        period: Time period for data
        output_dir: Output directory for results
    """
    from finnet.utils.config import Config
    from finnet.data_collection.stock_collector import StockDataCollector
    from finnet.network_analysis.network_builder import FinancialNetworkBuilder
    from finnet.network_analysis.metrics_calculator import NetworkMetricsCalculator
    
    print("=" * 50)
    print("   FinNet CLI Analysis")
    print("=" * 50)
    print(f"\nTickers: {', '.join(tickers)}")
    print(f"Period: {period}")
    print(f"Output: {output_dir or 'default'}")
    print("-" * 50)
    
    # Initialize config with output directory
    config = Config()
    if output_dir:
        config.set_output_dir(output_dir)
    
    # Collect stock data
    print("\n[1/4] Collecting stock data...")
    collector = StockDataCollector(config)
    stock_data = collector.get_multiple_stocks(tickers, period=period)
    print(f"  ✓ Collected data for {len(stock_data)} tickers")
    
    # Build network
    print("\n[2/4] Building correlation network...")
    builder = FinancialNetworkBuilder()
    G = builder.build_correlation_network(stock_data, threshold=0.5)
    print(f"  ✓ Network: {G.number_of_nodes()} nodes, {G.number_of_edges()} edges")
    
    # Calculate metrics
    print("\n[3/4] Calculating network metrics...")
    calculator = NetworkMetricsCalculator()
    metrics = calculator.calculate_all_metrics(G)
    print(f"  ✓ Calculated {len(metrics)} metric types")
    
    # Display results
    print("\n[4/4] Results Summary")
    print("-" * 50)
    
    if 'pagerank' in metrics:
        print("\nTop Influential Stocks (by PageRank):")
        pagerank = metrics['pagerank']
        for ticker, score in sorted(pagerank.items(), key=lambda x: x[1], reverse=True)[:5]:
            print(f"  {ticker}: {score:.4f}")
    
    if 'degree_centrality' in metrics:
        print("\nMost Connected Stocks (by Degree):")
        degree = metrics['degree_centrality']
        for ticker, score in sorted(degree.items(), key=lambda x: x[1], reverse=True)[:5]:
            print(f"  {ticker}: {score:.4f}")
    
    print("\n" + "=" * 50)
    print("Analysis complete!")
    print(f"Results saved to: {config.get_current_session_dir()}")


if __name__ == "__main__":
    main()
