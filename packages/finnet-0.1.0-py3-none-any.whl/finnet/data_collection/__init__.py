"""FinNet Data Collection Package - 100% FREE, No API Keys Required."""

from finnet.data_collection.stock_collector import StockDataCollector
from finnet.data_collection.reddit_scraper import RedditJSONScraper
from finnet.data_collection.news_collector import GoogleNewsCollector, YahooFinanceNewsScraper
from finnet.data_collection.rss_collector import RSSNewsCollector
from finnet.data_collection.aggregator import DataAggregator

__all__ = [
    "StockDataCollector",
    "RedditJSONScraper",
    "GoogleNewsCollector",
    "YahooFinanceNewsScraper",
    "RSSNewsCollector",
    "DataAggregator",
]
