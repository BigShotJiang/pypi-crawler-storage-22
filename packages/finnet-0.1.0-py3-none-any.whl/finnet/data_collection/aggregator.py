"""
Data Aggregator for FinNet

Orchestrates all data collectors into a unified interface.
"""

from datetime import datetime
from typing import Dict, List, Optional, Any
import pickle
from pathlib import Path

import pandas as pd
# from tqdm import tqdm

from finnet.utils.logger import get_logger
from finnet.utils.config import Config
from finnet.data_collection.stock_collector import StockDataCollector
from finnet.data_collection.reddit_scraper import RedditJSONScraper
from finnet.data_collection.news_collector import GoogleNewsCollector, YahooFinanceNewsScraper
from finnet.data_collection.rss_collector import RSSNewsCollector

logger = get_logger(__name__)


class DataAggregator:
    """
    Unified data collection interface.
    
    Orchestrates all data collectors to gather comprehensive
    financial data from multiple sources.
    """
    
    def __init__(self, config: Optional[Config] = None):
        """
        Initialize the data aggregator.
        
        Args:
            config: Optional configuration object
        """
        self.config = config or Config()
        
        # Initialize collectors
        self.stock_collector = StockDataCollector(self.config)
        self.reddit_scraper = RedditJSONScraper(self.config)
        self.google_news = GoogleNewsCollector()
        self.yahoo_news = YahooFinanceNewsScraper()
        self.rss_news = RSSNewsCollector()
        
        # Data storage
        self.data: Dict[str, Any] = {}
    
    def collect_all_data(
        self,
        tickers: List[str],
        period: str = "1y",
        include_stocks: bool = True,
        include_reddit: bool = True,
        include_news: bool = True,
        save_to_session: bool = True,
        show_progress: bool = True
    ) -> Dict[str, Any]:
        """
        Collect data from all sources for given tickers.
        
        Args:
            tickers: List of ticker symbols
            period: Time period for stock data
            include_stocks: Collect stock data
            include_reddit: Collect Reddit sentiment
            include_news: Collect news
            save_to_session: Save data to session directory
            show_progress: Show progress
            
        Returns:
            Dictionary with all collected data
        """
        # Validate and clean tickers
        from finnet.utils.helpers import validate_ticker
        valid_tickers = []
        for t in tickers:
            is_valid, result = validate_ticker(t)
            if is_valid:
                valid_tickers.append(result)
        
        if not valid_tickers:
            logger.error("No valid tickers provided")
            return {}
        
        logger.info(f"Starting data collection for {len(valid_tickers)} tickers")
        
        results = {
            'tickers': valid_tickers,
            'collection_started': datetime.now(),
            'config': {
                'period': period,
                'include_stocks': include_stocks,
                'include_reddit': include_reddit,
                'include_news': include_news,
            }
        }
        
        # Collect stock data
        if include_stocks:
            if show_progress:
                print("\n📊 Collecting stock data...")
            
            stock_data = self.stock_collector.get_multiple_stocks(
                valid_tickers,
                period=period,
                show_progress=show_progress
            )
            
            company_info = self.stock_collector.get_multiple_company_info(
                valid_tickers,
                show_progress=show_progress
            )
            
            results['stock_data'] = stock_data
            results['company_info'] = company_info
            logger.info(f"Collected stock data: {stock_data.shape}")
        
        # Collect Reddit sentiment
        if include_reddit:
            if show_progress:
                print("\n💬 Collecting Reddit sentiment...")
            
            try:
                reddit_df, reddit_detailed = self.reddit_scraper.bulk_ticker_scrape(
                    valid_tickers,
                    show_progress=show_progress
                )
                results['reddit_summary'] = reddit_df
                results['reddit_detailed'] = reddit_detailed
                logger.info(f"Collected Reddit data: {len(reddit_df)} tickers, {reddit_df['mentions'].sum()} mentions")
            except Exception as e:
                logger.warning(f"Reddit collection failed: {e}")
                results['reddit_summary'] = pd.DataFrame()
                results['reddit_detailed'] = []
        
        # Collect news
        if include_news:
            if show_progress:
                print("\n📰 Collecting news...")
            
            try:
                # Google News
                google_df = self.google_news.search_multiple_tickers(
                    valid_tickers,
                    show_progress=show_progress
                )
                results['google_news'] = google_df
                logger.info(f"Collected Google News: {len(google_df)} articles")
            except Exception as e:
                logger.warning(f"Google News collection failed: {e}")
                results['google_news'] = pd.DataFrame()
            
            try:
                # Yahoo Finance News
                yahoo_df = self.yahoo_news.get_multiple_tickers_news(
                    valid_tickers,
                    show_progress=show_progress
                )
                results['yahoo_news'] = yahoo_df
                logger.info(f"Collected Yahoo Finance News: {len(yahoo_df)} articles")
            except Exception as e:
                logger.warning(f"Yahoo News collection failed: {e}")
                results['yahoo_news'] = pd.DataFrame()
            
            try:
                # RSS News
                rss_df = self.rss_news.get_all_financial_news(show_progress=show_progress)
                # Filter for our tickers
                rss_filtered = self.rss_news.search_multiple_tickers(valid_tickers, rss_df)
                results['rss_news'] = rss_filtered
                logger.info(f"Collected RSS News: {len(rss_filtered)} relevant articles")
            except Exception as e:
                logger.warning(f"RSS News collection failed: {e}")
                results['rss_news'] = pd.DataFrame()
        
        results['collection_completed'] = datetime.now()
        results['collection_duration'] = (
            results['collection_completed'] - results['collection_started']
        ).total_seconds()
        
        # Store internally
        self.data = results
        
        # Save to session directory
        if save_to_session:
            self.save_session_data()
        
        logger.info(f"Data collection completed in {results['collection_duration']:.1f} seconds")
        
        return results
    
    def get_stock_data(self) -> pd.DataFrame:
        """Get collected stock data."""
        return self.data.get('stock_data', pd.DataFrame())
    
    def get_company_info(self) -> Dict[str, Dict]:
        """Get collected company info."""
        return self.data.get('company_info', {})
    
    def get_reddit_data(self) -> pd.DataFrame:
        """Get collected Reddit summary."""
        return self.data.get('reddit_summary', pd.DataFrame())
    
    def get_all_news(self) -> pd.DataFrame:
        """
        Get all news from all sources combined.
        
        Returns:
            Combined DataFrame with all news
        """
        dfs = []
        
        for key in ['google_news', 'yahoo_news', 'rss_news']:
            df = self.data.get(key)
            if df is not None and not df.empty:
                df = df.copy()
                df['news_source'] = key
                dfs.append(df)
        
        if dfs:
            combined = pd.concat(dfs, ignore_index=True)
            return combined
        
        return pd.DataFrame()
    
    def save_session_data(self):
        """Save all collected data to session directory."""
        session_dir = self.config.get_session_dir()
        
        try:
            # Save stock data
            if 'stock_data' in self.data and not self.data['stock_data'].empty:
                self.data['stock_data'].to_pickle(session_dir / 'stock_data.pkl')
                self.data['stock_data'].to_csv(session_dir / 'stock_data.csv')
            
            # Save company info
            if 'company_info' in self.data:
                with open(session_dir / 'company_info.pkl', 'wb') as f:
                    pickle.dump(self.data['company_info'], f)
            
            # Save Reddit data
            if 'reddit_summary' in self.data and not self.data['reddit_summary'].empty:
                self.data['reddit_summary'].to_pickle(session_dir / 'reddit_summary.pkl')
                self.data['reddit_summary'].to_csv(session_dir / 'reddit_summary.csv')
            
            if 'reddit_detailed' in self.data:
                with open(session_dir / 'reddit_detailed.pkl', 'wb') as f:
                    pickle.dump(self.data['reddit_detailed'], f)
            
            # Save news data
            for key in ['google_news', 'yahoo_news', 'rss_news']:
                if key in self.data and not self.data[key].empty:
                    self.data[key].to_pickle(session_dir / f'{key}.pkl')
                    self.data[key].to_csv(session_dir / f'{key}.csv')
            
            # Save metadata
            metadata = {
                'tickers': self.data.get('tickers', []),
                'collection_started': str(self.data.get('collection_started', '')),
                'collection_completed': str(self.data.get('collection_completed', '')),
                'collection_duration': self.data.get('collection_duration', 0),
                'config': self.data.get('config', {}),
            }
            
            import json
            with open(session_dir / 'metadata.json', 'w') as f:
                json.dump(metadata, f, indent=2)
            
            logger.info(f"Session data saved to {session_dir}")
            
        except Exception as e:
            logger.error(f"Error saving session data: {e}")
    
    def load_session_data(self, session_id: Optional[str] = None) -> bool:
        """
        Load data from a previous session.
        
        Args:
            session_id: Session ID to load (or None for current)
            
        Returns:
            True if loaded successfully
        """
        if session_id:
            if not self.config.load_session(session_id):
                logger.error(f"Session not found: {session_id}")
                return False
        
        session_dir = self.config.get_session_dir()
        
        try:
            # Load stock data
            stock_path = session_dir / 'stock_data.pkl'
            if stock_path.exists():
                self.data['stock_data'] = pd.read_pickle(stock_path)
            
            # Load company info
            info_path = session_dir / 'company_info.pkl'
            if info_path.exists():
                with open(info_path, 'rb') as f:
                    self.data['company_info'] = pickle.load(f)
            
            # Load Reddit data
            reddit_path = session_dir / 'reddit_summary.pkl'
            if reddit_path.exists():
                self.data['reddit_summary'] = pd.read_pickle(reddit_path)
            
            reddit_detailed_path = session_dir / 'reddit_detailed.pkl'
            if reddit_detailed_path.exists():
                with open(reddit_detailed_path, 'rb') as f:
                    self.data['reddit_detailed'] = pickle.load(f)
            
            # Load news data
            for key in ['google_news', 'yahoo_news', 'rss_news']:
                news_path = session_dir / f'{key}.pkl'
                if news_path.exists():
                    self.data[key] = pd.read_pickle(news_path)
            
            # Load metadata
            meta_path = session_dir / 'metadata.json'
            if meta_path.exists():
                import json
                with open(meta_path, 'r') as f:
                    metadata = json.load(f)
                    self.data['tickers'] = metadata.get('tickers', [])
                    self.data['config'] = metadata.get('config', {})
            
            logger.info(f"Loaded session data from {session_dir}")
            return True
            
        except Exception as e:
            logger.error(f"Error loading session data: {e}")
            return False
    
    def get_summary(self) -> Dict[str, Any]:
        """
        Get summary of collected data.
        
        Returns:
            Dictionary with data summary
        """
        summary = {
            'tickers': self.data.get('tickers', []),
            'stock_data_shape': (
                self.data['stock_data'].shape
                if 'stock_data' in self.data and not self.data['stock_data'].empty
                else (0, 0)
            ),
            'companies_with_info': len(self.data.get('company_info', {})),
            'reddit_mentions': (
                int(self.data['reddit_summary']['mentions'].sum())
                if 'reddit_summary' in self.data and not self.data['reddit_summary'].empty
                else 0
            ),
            'news_articles': {
                'google': len(self.data.get('google_news', [])),
                'yahoo': len(self.data.get('yahoo_news', [])),
                'rss': len(self.data.get('rss_news', [])),
            },
            'collection_duration': self.data.get('collection_duration', 0),
        }
        
        summary['total_news'] = sum(summary['news_articles'].values())
        
        return summary
