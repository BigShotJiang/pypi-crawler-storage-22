"""
News Collectors for Financial Data

100% FREE - No API keys required!
- Google News via RSS feeds
- Yahoo Finance via web scraping
"""

import time
from datetime import datetime
from typing import Dict, List, Optional

import feedparser
import pandas as pd
import requests
from bs4 import BeautifulSoup

from finnet.utils.logger import get_logger
from finnet.utils.config import Config

logger = get_logger(__name__)


class GoogleNewsCollector:
    """
    Collect financial news from Google News RSS feeds.
    
    100% FREE - No API key required!
    Uses RSS feeds for reliable access.
    """
    
    def __init__(self, lang: str = "en", country: str = "US"):
        """
        Initialize the Google News collector.
        
        Args:
            lang: Language code (e.g., 'en')
            country: Country code (e.g., 'US')
        """
        self.lang = lang
        self.country = country
        self.base_url = "https://news.google.com/rss"
    
    def get_top_news(self) -> List[Dict]:
        """
        Get top news headlines.
        
        Returns:
            List of news article dictionaries
        """
        url = f"{self.base_url}?hl={self.lang}-{self.country}&gl={self.country}&ceid={self.country}:{self.lang}"
        return self._parse_feed(url)
    
    def get_business_news(self) -> List[Dict]:
        """
        Get business news headlines.
        
        Returns:
            List of news article dictionaries
        """
        url = f"{self.base_url}/topics/CAAqJggKIiBDQkFTRWdvSUwyMHZNRGx6TVdZU0FtVnVHZ0pWVXlnQVAB?hl={self.lang}-{self.country}"
        return self._parse_feed(url)
    
    def search_ticker_news(
        self,
        ticker: str,
        company_name: Optional[str] = None
    ) -> List[Dict]:
        """
        Search news for a specific ticker/company.
        
        Args:
            ticker: Stock ticker (e.g., 'AAPL')
            company_name: Optional company name (e.g., 'Apple')
            
        Returns:
            List of news articles
        """
        articles = []
        
        # Search by ticker
        ticker_url = f"{self.base_url}/search?q={ticker}+stock&hl={self.lang}-{self.country}"
        articles.extend(self._parse_feed(ticker_url))
        
        # Search by company name if provided
        if company_name:
            name_url = f"{self.base_url}/search?q={company_name.replace(' ', '+')}+stock&hl={self.lang}-{self.country}"
            articles.extend(self._parse_feed(name_url))
        
        # Deduplicate by link
        seen = set()
        unique_articles = []
        for article in articles:
            if article['link'] not in seen:
                seen.add(article['link'])
                article['ticker'] = ticker
                unique_articles.append(article)
        
        return unique_articles
    
    def search_multiple_tickers(
        self,
        tickers: List[str],
        company_names: Optional[Dict[str, str]] = None,
        show_progress: bool = True
    ) -> pd.DataFrame:
        """
        Search news for multiple tickers.
        
        Args:
            tickers: List of ticker symbols
            company_names: Optional dict mapping tickers to company names
            show_progress: Show progress
            
        Returns:
            DataFrame with all news
        """
        # from tqdm import tqdm
        
        all_news = []
        # iterator = tqdm(tickers, desc="Fetching news") if show_progress else tickers
        iterator = tickers
        if show_progress:
            print("Fetching news from Google...")
        
        for ticker in iterator:
            company_name = company_names.get(ticker) if company_names else None
            news = self.search_ticker_news(ticker, company_name)
            all_news.extend(news)
            time.sleep(1)  # Rate limiting
        
        df = pd.DataFrame(all_news)
        logger.info(f"Collected {len(df)} news articles for {len(tickers)} tickers")
        return df
    
    def _parse_feed(self, url: str) -> List[Dict]:
        """Parse RSS feed and return articles."""
        try:
            feed = feedparser.parse(url)
            articles = []
            
            for entry in feed.entries:
                articles.append({
                    'title': entry.get('title', ''),
                    'link': entry.get('link', ''),
                    'published': entry.get('published', ''),
                    'published_parsed': (
                        datetime(*entry.published_parsed[:6])
                        if hasattr(entry, 'published_parsed') and entry.published_parsed
                        else None
                    ),
                    'source': entry.get('source', {}).get('title', 'Google News'),
                    'summary': entry.get('summary', ''),
                })
            
            return articles
            
        except Exception as e:
            logger.error(f"Error parsing feed {url}: {e}")
            return []


class YahooFinanceNewsScraper:
    """
    Scrape news from Yahoo Finance.
    
    100% FREE - No API key required!
    Uses BeautifulSoup for web scraping.
    """
    
    def __init__(self):
        """Initialize the Yahoo Finance news scraper."""
        self.base_url = "https://finance.yahoo.com"
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
        }
    
    def get_ticker_news(
        self,
        ticker: str,
        max_articles: int = 20
    ) -> List[Dict]:
        """
        Get news for a specific ticker.
        
        Args:
            ticker: Stock symbol (e.g., 'AAPL')
            max_articles: Maximum number of articles to fetch
            
        Returns:
            List of news articles
        """
        url = f"{self.base_url}/quote/{ticker.upper()}/news"
        
        try:
            response = requests.get(url, headers=self.headers, timeout=15)
            
            if response.status_code == 200:
                soup = BeautifulSoup(response.content, 'html.parser')
                articles = []
                
                # Find news items - try multiple selectors
                news_items = soup.select('li.js-stream-content')
                
                if not news_items:
                    # Alternative selector
                    news_items = soup.select('div[data-test="STREAM-ITEM"]')
                
                if not news_items:
                    # Another alternative
                    news_items = soup.find_all('a', {'class': lambda x: x and 'mega-item' in x})
                
                for item in news_items[:max_articles]:
                    try:
                        # Extract title
                        title_elem = item.select_one('h3') or item.select_one('a')
                        if not title_elem:
                            continue
                        
                        title = title_elem.get_text(strip=True)
                        
                        # Extract link
                        link_elem = item.select_one('a[href]')
                        link = ''
                        if link_elem:
                            link = link_elem.get('href', '')
                            if link.startswith('/'):
                                link = f"{self.base_url}{link}"
                        
                        # Extract source if available
                        source_elem = item.select_one('span[data-test="AUTHOR-FOOTER"]')
                        source = source_elem.get_text(strip=True) if source_elem else 'Yahoo Finance'
                        
                        if title:
                            articles.append({
                                'ticker': ticker.upper(),
                                'title': title,
                                'link': link,
                                'source': source,
                                'scraped_at': datetime.now(),
                            })
                    except Exception:
                        continue
                
                logger.info(f"Scraped {len(articles)} articles for {ticker}")
                return articles
            else:
                logger.warning(f"Error fetching news for {ticker}: {response.status_code}")
                return []
                
        except Exception as e:
            logger.error(f"Exception scraping {ticker}: {e}")
            return []
    
    def get_market_news(self, max_articles: int = 30) -> List[Dict]:
        """
        Get general market news from Yahoo Finance homepage.
        
        Args:
            max_articles: Maximum number of articles
            
        Returns:
            List of news articles
        """
        url = f"{self.base_url}/"
        
        try:
            response = requests.get(url, headers=self.headers, timeout=15)
            
            if response.status_code == 200:
                soup = BeautifulSoup(response.content, 'html.parser')
                articles = []
                
                # Find news items
                news_items = soup.select('li.js-stream-content')
                
                for item in news_items[:max_articles]:
                    try:
                        title_elem = item.select_one('h3') or item.select_one('a')
                        if not title_elem:
                            continue
                        
                        title = title_elem.get_text(strip=True)
                        
                        link_elem = item.select_one('a[href]')
                        link = ''
                        if link_elem:
                            link = link_elem.get('href', '')
                            if link.startswith('/'):
                                link = f"{self.base_url}{link}"
                        
                        if title:
                            articles.append({
                                'title': title,
                                'link': link,
                                'source': 'Yahoo Finance',
                                'scraped_at': datetime.now(),
                            })
                    except Exception:
                        continue
                
                return articles
            else:
                return []
                
        except Exception as e:
            logger.error(f"Exception scraping market news: {e}")
            return []
    
    def get_multiple_tickers_news(
        self,
        tickers: List[str],
        max_per_ticker: int = 10,
        show_progress: bool = True
    ) -> pd.DataFrame:
        """
        Get news for multiple tickers.
        
        Args:
            tickers: List of ticker symbols
            max_per_ticker: Max articles per ticker
            show_progress: Show progress bar
            
        Returns:
            DataFrame with all news
        """
        # from tqdm import tqdm
        
        all_news = []
        # iterator = tqdm(tickers, desc="Scraping Yahoo Finance") if show_progress else tickers
        iterator = tickers
        if show_progress:
            print("Fetching news from Yahoo Finance...")
        
        for ticker in iterator:
            news = self.get_ticker_news(ticker, max_per_ticker)
            all_news.extend(news)
            time.sleep(1)  # Rate limiting
        
        return pd.DataFrame(all_news)
