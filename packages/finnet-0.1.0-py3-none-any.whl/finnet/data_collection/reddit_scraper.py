"""
Reddit Scraper using .json Endpoint

100% FREE - No API key required!
Uses the public .json endpoint trick: add .json to any Reddit URL.
"""

import re
import time
from datetime import datetime
from typing import Dict, List, Optional, Tuple

import pandas as pd
import requests
# from tqdm import tqdm

from finnet.utils.logger import get_logger
from finnet.utils.config import Config

logger = get_logger(__name__)


class RedditJSONScraper:
    """
    Scrape Reddit using .json endpoints.
    
    100% FREE - No API key required!
    Simply add .json to any Reddit URL to get JSON data.
    
    Features:
    - Subreddit post scraping
    - Comment extraction
    - Ticker mention detection
    - Sentiment aggregation
    - Rate limiting
    """
    
    # Common words to exclude (not tickers)
    EXCLUDED_WORDS = {
        'THE', 'AND', 'FOR', 'ARE', 'BUT', 'NOT', 'YOU', 'ALL',
        'CAN', 'HER', 'WAS', 'ONE', 'OUR', 'OUT', 'DAY', 'GET',
        'HAS', 'HIM', 'HIS', 'HOW', 'ITS', 'MAY', 'NEW', 'NOW',
        'OLD', 'SEE', 'TWO', 'WHO', 'BOY', 'DID', 'LET', 'SAY',
        'PUT', 'SHE', 'TOO', 'USE', 'WIN', 'YET', 'CEO', 'CFO',
        'CTO', 'IPO', 'ATH', 'WSB', 'ETF', 'NYSE', 'NASDAQ', 'SEC',
        'FDA', 'IMO', 'IMHO', 'TBH', 'FOMO', 'YOLO', 'HODL', 'BUY',
        'SELL', 'CALL', 'EPS', 'ATM', 'ITM', 'OTM', 'DTE', 'GUH',
        'FUD', 'MOON', 'RIP', 'APE', 'DD', 'TA', 'FA', 'USA', 'GDP',
        'FED', 'CPI', 'PPI', 'USD', 'EUR', 'GBP', 'JPY', 'CAD',
        'AUD', 'NZD', 'CHF', 'HKD', 'SGD', 'CNY', 'INR', 'KRW',
        'SPY', 'QQQ', 'DIA', 'IWM', 'VTI', 'VOO', 'VXX', 'TLT',
        'LOL', 'WTF', 'OMG', 'IDK', 'LMAO', 'TIL', 'AMA', 'ELI',
    }
    
    def __init__(self, config: Optional[Config] = None):
        """
        Initialize the Reddit scraper.
        
        Args:
            config: Optional configuration object
        """
        self.config = config or Config()
        self.base_url = "https://www.reddit.com"
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        }
        self.rate_limit = self.config.get("reddit_rate_limit", 2.0)
        self.ticker_pattern = re.compile(r'\b[A-Z]{1,5}\b')
    
    def get_subreddit_posts(
        self,
        subreddit: str,
        sort: str = "hot",
        limit: int = 100,
        timeframe: str = "day"
    ) -> List[Dict]:
        """
        Get posts from subreddit using .json endpoint.
        
        Args:
            subreddit: Subreddit name (e.g., 'wallstreetbets')
            sort: 'hot', 'new', 'top', 'rising'
            limit: Max posts (100 per request max)
            timeframe: 'hour', 'day', 'week', 'month', 'year', 'all' (for 'top')
            
        Returns:
            List of post dictionaries
        """
        url = f"{self.base_url}/r/{subreddit}/{sort}.json"
        params = {'limit': min(limit, 100)}
        
        if sort == 'top':
            params['t'] = timeframe
        
        try:
            response = requests.get(
                url,
                headers=self.headers,
                params=params,
                timeout=15
            )
            
            if response.status_code == 200:
                data = response.json()
                posts = []
                
                for child in data.get('data', {}).get('children', []):
                    if child.get('kind') == 't3':  # t3 = post
                        post_data = child['data']
                        posts.append({
                            'id': post_data.get('id', ''),
                            'title': post_data.get('title', ''),
                            'selftext': post_data.get('selftext', ''),
                            'score': post_data.get('score', 0),
                            'upvote_ratio': post_data.get('upvote_ratio', 0),
                            'num_comments': post_data.get('num_comments', 0),
                            'created_utc': post_data.get('created_utc', 0),
                            'created': datetime.fromtimestamp(
                                post_data.get('created_utc', 0)
                            ),
                            'author': post_data.get('author', '[deleted]'),
                            'url': post_data.get('url', ''),
                            'permalink': post_data.get('permalink', ''),
                            'subreddit': subreddit,
                            'link_flair_text': post_data.get('link_flair_text', ''),
                        })
                
                logger.info(f"Fetched {len(posts)} posts from r/{subreddit}")
                return posts
                
            elif response.status_code == 429:
                logger.warning("Rate limited! Waiting 60 seconds...")
                time.sleep(60)
                return self.get_subreddit_posts(subreddit, sort, limit, timeframe)
            else:
                logger.error(f"Error {response.status_code}: {response.text[:200]}")
                return []
                
        except requests.exceptions.Timeout:
            logger.error(f"Timeout fetching r/{subreddit}")
            return []
        except Exception as e:
            logger.error(f"Exception fetching posts: {e}")
            return []
        finally:
            time.sleep(self.rate_limit)
    
    def get_post_comments(
        self,
        permalink: str,
        limit: int = 500
    ) -> List[Dict]:
        """
        Get comments from a specific post.
        
        Args:
            permalink: Post permalink (e.g., '/r/wallstreetbets/comments/abc123/title/')
            limit: Max comments
            
        Returns:
            List of comment dictionaries
        """
        url = f"{self.base_url}{permalink}.json"
        params = {'limit': limit, 'depth': 10}
        
        try:
            response = requests.get(
                url,
                headers=self.headers,
                params=params,
                timeout=15
            )
            
            if response.status_code == 200:
                data = response.json()
                comments = []
                
                # data[0] = post, data[1] = comments
                if len(data) > 1:
                    self._extract_comments_recursive(
                        data[1].get('data', {}).get('children', []),
                        comments
                    )
                
                logger.debug(f"Extracted {len(comments)} comments")
                return comments
            else:
                logger.error(f"Error fetching comments: {response.status_code}")
                return []
                
        except Exception as e:
            logger.error(f"Exception getting comments: {e}")
            return []
        finally:
            time.sleep(self.rate_limit)
    
    def _extract_comments_recursive(
        self,
        comment_list: List,
        result_list: List
    ):
        """Recursively extract comments (handles nested replies)."""
        for item in comment_list:
            if item.get('kind') == 't1':  # t1 = comment
                comment_data = item.get('data', {})
                result_list.append({
                    'id': comment_data.get('id', ''),
                    'body': comment_data.get('body', ''),
                    'score': comment_data.get('score', 0),
                    'created_utc': comment_data.get('created_utc', 0),
                    'author': comment_data.get('author', '[deleted]'),
                    'permalink': comment_data.get('permalink', ''),
                })
                
                # Recursively get replies
                replies = comment_data.get('replies')
                if replies and isinstance(replies, dict):
                    self._extract_comments_recursive(
                        replies.get('data', {}).get('children', []),
                        result_list
                    )
    
    def extract_ticker_mentions(self, text: str) -> List[str]:
        """
        Extract stock ticker mentions from text.
        
        Patterns detected:
        - $AAPL (with $ prefix)
        - AAPL (all caps, 1-5 letters)
        
        Args:
            text: Text to analyze
            
        Returns:
            List of unique tickers
        """
        if not text:
            return []
        
        # Find tickers with $ prefix (more reliable)
        dollar_tickers = re.findall(r'\$([A-Z]{1,5})\b', text.upper())
        
        # Find all-caps words (potential tickers)
        potential_tickers = self.ticker_pattern.findall(text.upper())
        
        # Combine and filter
        all_tickers = set(dollar_tickers + potential_tickers)
        filtered_tickers = [t for t in all_tickers if t not in self.EXCLUDED_WORDS]
        
        return sorted(filtered_tickers)
    
    def get_ticker_sentiment(
        self,
        ticker: str,
        subreddits: Optional[List[str]] = None,
        max_posts_per_sub: int = 100
    ) -> Dict:
        """
        Get sentiment data for a specific ticker across subreddits.
        
        Args:
            ticker: Stock symbol (e.g., 'AAPL')
            subreddits: List of subreddits (default: config or wallstreetbets, stocks)
            max_posts_per_sub: Max posts per subreddit
            
        Returns:
            Dictionary with aggregated sentiment data
        """
        if subreddits is None:
            subreddits = self.config.get(
                "reddit_subreddits",
                ["wallstreetbets", "stocks", "investing"]
            )
        
        ticker = ticker.upper()
        all_mentions = []
        
        for subreddit in subreddits:
            logger.info(f"Searching {ticker} in r/{subreddit}")
            
            posts = self.get_subreddit_posts(
                subreddit,
                sort='new',
                limit=max_posts_per_sub
            )
            
            for post in posts:
                combined_text = f"{post['title']} {post['selftext']}"
                mentioned_tickers = self.extract_ticker_mentions(combined_text)
                
                if ticker in mentioned_tickers:
                    all_mentions.append({
                        'type': 'post',
                        'text': combined_text[:500],  # Truncate for storage
                        'title': post['title'],
                        'score': post['score'],
                        'num_comments': post['num_comments'],
                        'created': post['created'],
                        'subreddit': subreddit,
                        'url': f"{self.base_url}{post['permalink']}",
                        'author': post['author'],
                    })
        
        return {
            'ticker': ticker,
            'total_mentions': len(all_mentions),
            'mentions': all_mentions,
            'avg_score': (
                sum(m['score'] for m in all_mentions) / len(all_mentions)
                if all_mentions else 0
            ),
            'total_comments': sum(m['num_comments'] for m in all_mentions),
            'subreddits_searched': subreddits,
            'collected_at': datetime.now(),
        }
    
    def bulk_ticker_scrape(
        self,
        tickers: List[str],
        subreddits: Optional[List[str]] = None,
        show_progress: bool = True
    ) -> Tuple[pd.DataFrame, List[Dict]]:
        """
        Scrape multiple tickers at once.
        
        Args:
            tickers: List of ticker symbols
            subreddits: List of subreddits to search
            show_progress: Show progress bar
            
        Returns:
            Tuple of (summary DataFrame, list of detailed results)
        """
        if subreddits is None:
            subreddits = self.config.get(
                "reddit_subreddits",
                ["wallstreetbets", "stocks"]
            )
        
        results = []
        # iterator = tqdm(tickers, desc="Scraping tickers") if show_progress else tickers
        iterator = tickers
        iterator = tickers
        if show_progress:
            print("Scraping Reddit data...")
        
        for ticker in iterator:
            if show_progress:
                iterator.set_description(f"Scraping {ticker}")
            
            sentiment_data = self.get_ticker_sentiment(ticker, subreddits)
            results.append(sentiment_data)
            time.sleep(1)  # Extra delay between tickers
        
        # Create summary DataFrame
        df = pd.DataFrame([{
            'ticker': r['ticker'],
            'mentions': r['total_mentions'],
            'avg_score': r['avg_score'],
            'total_comments': r['total_comments'],
        } for r in results])
        
        logger.info(f"Scraped {len(tickers)} tickers, found {df['mentions'].sum()} total mentions")
        
        return df, results
    
    def get_trending_tickers(
        self,
        subreddit: str = "wallstreetbets",
        limit: int = 100,
        min_mentions: int = 2
    ) -> pd.DataFrame:
        """
        Find trending tickers in a subreddit.
        
        Args:
            subreddit: Subreddit to analyze
            limit: Number of posts to analyze
            min_mentions: Minimum mentions to include
            
        Returns:
            DataFrame with ticker mention counts
        """
        posts = self.get_subreddit_posts(subreddit, sort='hot', limit=limit)
        
        ticker_counts = {}
        
        for post in posts:
            combined_text = f"{post['title']} {post['selftext']}"
            tickers = self.extract_ticker_mentions(combined_text)
            
            for ticker in tickers:
                ticker_counts[ticker] = ticker_counts.get(ticker, 0) + 1
        
        # Filter by minimum mentions and sort
        filtered = {k: v for k, v in ticker_counts.items() if v >= min_mentions}
        sorted_tickers = sorted(filtered.items(), key=lambda x: x[1], reverse=True)
        
        df = pd.DataFrame(sorted_tickers, columns=['ticker', 'mentions'])
        logger.info(f"Found {len(df)} trending tickers in r/{subreddit}")
        
        return df
