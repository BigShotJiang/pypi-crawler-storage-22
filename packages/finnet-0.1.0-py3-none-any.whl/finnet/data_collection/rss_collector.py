"""
RSS News Collector for Financial Data

100% FREE - No API keys required!
Uses feedparser to collect news from various financial RSS feeds.
"""

from datetime import datetime
from typing import Dict, List, Optional

import feedparser
import pandas as pd

from finnet.utils.logger import get_logger

logger = get_logger(__name__)


class RSSNewsCollector:
    """
    Collect news from RSS feeds.
    
    100% FREE - No API key required!
    Parse any financial RSS feed.
    """
    
    # Default financial RSS feeds
    DEFAULT_FEEDS = {
        'cnbc': 'https://www.cnbc.com/id/100003114/device/rss/rss.html',
        'cnbc_investing': 'https://www.cnbc.com/id/15839069/device/rss/rss.html',
        'marketwatch_top': 'https://feeds.marketwatch.com/marketwatch/topstories/',
        'marketwatch_stocks': 'https://feeds.marketwatch.com/marketwatch/marketpulse/',
        'benzinga': 'https://www.benzinga.com/feed',
        'investing_news': 'https://www.investing.com/rss/news.rss',
        'nasdaq': 'https://www.nasdaq.com/feed/rssoutbound?category=Markets',
    }
    
    def __init__(self):
        """Initialize the RSS news collector with default feeds."""
        self.feeds = self.DEFAULT_FEEDS.copy()
    
    def add_custom_feed(self, name: str, url: str):
        """
        Add a custom RSS feed.
        
        Args:
            name: Feed name/identifier
            url: RSS feed URL
        """
        self.feeds[name] = url
        logger.info(f"Added custom feed: {name}")
    
    def remove_feed(self, name: str) -> bool:
        """
        Remove a feed by name.
        
        Args:
            name: Feed name to remove
            
        Returns:
            True if removed, False if not found
        """
        if name in self.feeds:
            del self.feeds[name]
            return True
        return False
    
    def list_feeds(self) -> Dict[str, str]:
        """
        List all configured feeds.
        
        Returns:
            Dictionary of feed names to URLs
        """
        return self.feeds.copy()
    
    def parse_feed(self, feed_url: str) -> List[Dict]:
        """
        Parse a single RSS feed.
        
        Args:
            feed_url: URL of the RSS feed
            
        Returns:
            List of article dictionaries
        """
        try:
            feed = feedparser.parse(feed_url)
            articles = []
            
            feed_title = feed.feed.get('title', 'Unknown')
            
            for entry in feed.entries:
                # Parse published date
                published_dt = None
                if hasattr(entry, 'published_parsed') and entry.published_parsed:
                    try:
                        published_dt = datetime(*entry.published_parsed[:6])
                    except (TypeError, ValueError):
                        pass
                
                articles.append({
                    'title': entry.get('title', ''),
                    'link': entry.get('link', ''),
                    'published': entry.get('published', ''),
                    'published_dt': published_dt,
                    'summary': self._clean_summary(entry.get('summary', '')),
                    'source': feed_title,
                    'author': entry.get('author', ''),
                })
            
            logger.debug(f"Parsed {len(articles)} articles from {feed_title}")
            return articles
            
        except Exception as e:
            logger.error(f"Error parsing feed {feed_url}: {e}")
            return []
    
    def get_feed_news(self, feed_name: str) -> List[Dict]:
        """
        Get news from a specific configured feed.
        
        Args:
            feed_name: Name of the feed to fetch
            
        Returns:
            List of articles
        """
        if feed_name not in self.feeds:
            logger.warning(f"Feed not found: {feed_name}")
            return []
        
        return self.parse_feed(self.feeds[feed_name])
    
    def get_all_financial_news(
        self,
        max_per_feed: Optional[int] = None,
        show_progress: bool = True
    ) -> pd.DataFrame:
        """
        Get news from all configured financial RSS feeds.
        
        Args:
            max_per_feed: Maximum articles per feed (None for all)
            show_progress: Show progress
            
        Returns:
            DataFrame with all articles
        """
        # from tqdm import tqdm
        # iterator = tqdm(self.feeds.items(), desc="Fetching RSS feeds") if show_progress else self.feeds.items()
        iterator = self.feeds.items()
        if show_progress:
            print("Fetching RSS feeds...")
        
        for source_name, feed_url in iterator:
            articles = self.parse_feed(feed_url)
            
            # Limit if specified
            if max_per_feed:
                articles = articles[:max_per_feed]
            
            # Add source identifier
            for article in articles:
                article['feed_name'] = source_name
            
            all_articles.extend(articles)
        
        df = pd.DataFrame(all_articles)
        logger.info(f"Collected {len(df)} articles from {len(self.feeds)} feeds")
        return df
    
    def search_ticker_in_news(
        self,
        ticker: str,
        news_df: pd.DataFrame
    ) -> pd.DataFrame:
        """
        Filter news DataFrame for ticker mentions.
        
        Args:
            ticker: Stock symbol
            news_df: DataFrame from get_all_financial_news()
            
        Returns:
            Filtered DataFrame
        """
        if news_df.empty:
            return news_df
        
        ticker = ticker.upper()
        
        # Search in title and summary
        mask = (
            news_df['title'].str.upper().str.contains(ticker, na=False) |
            news_df['summary'].str.upper().str.contains(ticker, na=False)
        )
        
        filtered = news_df[mask].copy()
        filtered['matched_ticker'] = ticker
        
        return filtered
    
    def search_multiple_tickers(
        self,
        tickers: List[str],
        news_df: Optional[pd.DataFrame] = None
    ) -> pd.DataFrame:
        """
        Search for multiple tickers in news.
        
        Args:
            tickers: List of ticker symbols
            news_df: Optional pre-fetched news (will fetch if None)
            
        Returns:
            DataFrame with matched articles
        """
        if news_df is None:
            news_df = self.get_all_financial_news()
        
        all_matches = []
        
        for ticker in tickers:
            matches = self.search_ticker_in_news(ticker, news_df)
            all_matches.append(matches)
        
        if all_matches:
            result = pd.concat(all_matches, ignore_index=True)
            # Remove duplicates (same article matching multiple tickers)
            result = result.drop_duplicates(subset=['link', 'matched_ticker'])
            return result
        
        return pd.DataFrame()
    
    def _clean_summary(self, summary: str) -> str:
        """Clean HTML tags from summary text."""
        if not summary:
            return ""
        
        # Simple HTML tag removal
        import re
        clean = re.sub(r'<[^>]+>', '', summary)
        clean = clean.replace('&nbsp;', ' ')
        clean = clean.replace('&amp;', '&')
        clean = clean.replace('&lt;', '<')
        clean = clean.replace('&gt;', '>')
        clean = clean.strip()
        
        return clean[:500]  # Truncate long summaries
    
    def auto_discover_feed(self, website_url: str) -> List[str]:
        """
        Try to discover RSS feeds from a website.
        
        Args:
            website_url: Website URL to check
            
        Returns:
            List of discovered feed URLs
        """
        import requests
        from bs4 import BeautifulSoup
        
        feeds = []
        
        try:
            response = requests.get(website_url, timeout=10, headers={
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            })
            
            if response.status_code == 200:
                soup = BeautifulSoup(response.content, 'html.parser')
                
                # Find RSS/Atom links in head
                for link in soup.find_all('link', type=True):
                    link_type = link.get('type', '')
                    href = link.get('href', '')
                    
                    if 'rss' in link_type or 'atom' in link_type:
                        # Make absolute URL
                        if href.startswith('/'):
                            from urllib.parse import urljoin
                            href = urljoin(website_url, href)
                        feeds.append(href)
                
                # Also check common RSS paths
                common_paths = ['/rss', '/feed', '/feeds', '/rss.xml', '/feed.xml', '/atom.xml']
                for path in common_paths:
                    test_url = website_url.rstrip('/') + path
                    try:
                        test_response = requests.head(test_url, timeout=5)
                        if test_response.status_code == 200:
                            feeds.append(test_url)
                    except Exception:
                        continue
                
        except Exception as e:
            logger.error(f"Error discovering feeds from {website_url}: {e}")
        
        return list(set(feeds))  # Deduplicate
