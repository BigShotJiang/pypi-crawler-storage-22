"""
Stock Data Collector using yFinance

100% FREE - No API key required!
Unlimited requests for historical and real-time stock data.
"""

import os
import sys
import pickle
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Any

# Disable tqdm before yfinance import
os.environ['TQDM_DISABLE'] = '1'

class _NoTqdm:
    def __init__(self, iterable=None, *a, **kw): self.iterable = iterable or []
    def __iter__(self): return iter(self.iterable)
    def __enter__(self): return self
    def __exit__(self, *a): pass
    def update(self, n=1): pass
    def set_description(self, d=None): pass
    def close(self): pass
    def write(self, s): pass

# Disable tqdm locally as well
# import tqdm
# import tqdm.auto
# try:
#     tqdm.tqdm = _NoTqdm
#     tqdm.auto.tqdm = _NoTqdm
# except:
#     pass

import pandas as pd
import yfinance as yf

from finnet.utils.logger import get_logger
from finnet.utils.config import Config

logger = get_logger(__name__)


class StockDataCollector:
    """
    Collect stock market data using yFinance.
    
    100% FREE - No API key required!
    
    Features:
    - Single/multiple ticker download
    - Historical OHLCV data
    - Company fundamentals
    - Real-time quotes
    - Technical indicators
    - Intelligent caching
    """
    
    def __init__(self, config: Optional[Config] = None):
        """
        Initialize the stock data collector.
        
        Args:
            config: Optional configuration object
        """
        self.config = config or Config()
        self._cache_enabled = self.config.get("cache_enabled", True)
        self._cache_expiry_days = self.config.get("cache_expiry_days", 1)
    
    def get_stock_data(
        self,
        ticker: str,
        period: str = "1y",
        interval: str = "1d",
        use_cache: bool = True
    ) -> pd.DataFrame:
        """
        Get historical stock data for a single ticker.
        
        Args:
            ticker: Stock symbol (e.g., 'AAPL')
            period: Time period ('1d', '5d', '1mo', '3mo', '6mo', '1y', '2y', '5y', 'max')
            interval: Data interval ('1m', '2m', '5m', '15m', '30m', '60m', '1d', '1wk', '1mo')
            use_cache: Whether to use cached data
            
        Returns:
            DataFrame with OHLCV data (Open, High, Low, Close, Volume)
        """
        ticker = ticker.upper().strip()
        
        # Try to load from cache
        if use_cache and self._cache_enabled:
            cached = self._load_from_cache(ticker, period, interval)
            if cached is not None:
                logger.debug(f"Loaded {ticker} from cache")
                return cached
        
        # Fetch from yFinance
        try:
            logger.info(f"Downloading {ticker} data (period={period}, interval={interval})")
            stock = yf.Ticker(ticker)
            hist = stock.history(period=period, interval=interval)
            
            if hist.empty:
                logger.warning(f"No data found for {ticker}")
                return pd.DataFrame()
            
            # Save to cache
            if use_cache and self._cache_enabled:
                self._save_to_cache(hist, ticker, period, interval)
            
            logger.info(f"Downloaded {len(hist)} records for {ticker}")
            return hist
            
        except Exception as e:
            logger.error(f"Error fetching data for {ticker}: {e}")
            return pd.DataFrame()
    
    def get_multiple_stocks(
        self,
        tickers: List[str],
        period: str = "1y",
        interval: str = "1d",
        use_cache: bool = True,
        show_progress: bool = True
    ) -> pd.DataFrame:
        """
        Get data for multiple stocks and combine into a single DataFrame.
        
        Args:
            tickers: List of ticker symbols
            period: Time period
            interval: Data interval
            use_cache: Use cached data
            show_progress: Show progress bar
            
        Returns:
            DataFrame with Close prices for all tickers (columns=tickers)
        """
        all_data = {}
        
        # iterator = tqdm(tickers, desc="Fetching stocks") if show_progress else tickers
        iterator = tickers
        if show_progress:
            print("Fetching stock data...")
        
        for ticker in iterator:
            df = self.get_stock_data(ticker, period, interval, use_cache)
            if not df.empty and 'Close' in df.columns:
                all_data[ticker] = df['Close']
        
        if not all_data:
            logger.warning("No data collected for any ticker")
            return pd.DataFrame()
        
        # Combine into single DataFrame
        combined = pd.DataFrame(all_data)
        logger.info(f"Combined data for {len(all_data)} tickers, {len(combined)} rows")
        return combined
    
    def get_multiple_stocks_bulk(
        self,
        tickers: List[str],
        period: str = "1y",
        interval: str = "1d"
    ) -> pd.DataFrame:
        """
        Download multiple tickers in parallel (faster for large lists).
        
        Args:
            tickers: List of ticker symbols
            period: Time period
            interval: Data interval
            
        Returns:
            DataFrame with Close prices for all tickers
        """
        try:
            logger.info(f"Bulk downloading {len(tickers)} tickers")
            data = yf.download(
                tickers=' '.join(tickers),
                period=period,
                interval=interval,
                group_by='ticker',
                threads=True,
                progress=False
            )
            
            # Extract Close prices only
            if isinstance(data.columns, pd.MultiIndex):
                # Multi-ticker download
                close_data = {}
                for ticker in tickers:
                    if ticker in data.columns.get_level_values(0):
                        close_data[ticker] = data[ticker]['Close']
                return pd.DataFrame(close_data)
            else:
                # Single ticker (edge case)
                return pd.DataFrame({tickers[0]: data['Close']})
                
        except Exception as e:
            logger.error(f"Bulk download error: {e}")
            # Fallback to sequential download
            return self.get_multiple_stocks(tickers, period, interval, use_cache=False)
    
    def get_company_info(self, ticker: str) -> Dict[str, Any]:
        """
        Get company fundamental information.
        
        Args:
            ticker: Stock symbol
            
        Returns:
            Dictionary with company details
        """
        try:
            stock = yf.Ticker(ticker.upper())
            info = stock.info
            
            return {
                'symbol': ticker.upper(),
                'name': info.get('longName', info.get('shortName', 'N/A')),
                'sector': info.get('sector', 'N/A'),
                'industry': info.get('industry', 'N/A'),
                'market_cap': info.get('marketCap', 0),
                'pe_ratio': info.get('trailingPE', 0),
                'forward_pe': info.get('forwardPE', 0),
                'dividend_yield': info.get('dividendYield', 0),
                'beta': info.get('beta', 0),
                'fifty_two_week_high': info.get('fiftyTwoWeekHigh', 0),
                'fifty_two_week_low': info.get('fiftyTwoWeekLow', 0),
                'avg_volume': info.get('averageVolume', 0),
                'description': info.get('longBusinessSummary', 'N/A'),
                'website': info.get('website', 'N/A'),
                'employees': info.get('fullTimeEmployees', 0),
                'exchange': info.get('exchange', 'N/A'),
                'currency': info.get('currency', 'USD'),
            }
        except Exception as e:
            logger.error(f"Error getting info for {ticker}: {e}")
            return {'symbol': ticker.upper(), 'error': str(e)}
    
    def get_multiple_company_info(
        self,
        tickers: List[str],
        show_progress: bool = True
    ) -> Dict[str, Dict[str, Any]]:
        """
        Get company info for multiple tickers.
        
        Args:
            tickers: List of ticker symbols
            show_progress: Show progress bar
            
        Returns:
            Dictionary mapping ticker to info dict
        """
        info_dict = {}
        
        # iterator = tqdm(tickers, desc="Fetching company info") if show_progress else tickers
        iterator = tickers
        if show_progress:
            print("Fetching company info...")
        
        for ticker in iterator:
            info_dict[ticker] = self.get_company_info(ticker)
        
        return info_dict
    
    def get_real_time_quote(self, ticker: str) -> Optional[Dict[str, Any]]:
        """
        Get current/latest stock quote.
        
        Args:
            ticker: Stock symbol
            
        Returns:
            Dictionary with latest price info
        """
        try:
            stock = yf.Ticker(ticker.upper())
            hist = stock.history(period='1d', interval='1m')
            
            if hist.empty:
                return None
            
            latest = hist.iloc[-1]
            
            return {
                'ticker': ticker.upper(),
                'price': float(latest['Close']),
                'open': float(latest['Open']),
                'high': float(latest['High']),
                'low': float(latest['Low']),
                'volume': int(latest['Volume']),
                'timestamp': hist.index[-1].to_pydatetime(),
            }
        except Exception as e:
            logger.error(f"Error getting quote for {ticker}: {e}")
            return None
    
    def calculate_returns(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Calculate daily returns from price data.
        
        Args:
            df: DataFrame with price data
            
        Returns:
            DataFrame with returns
        """
        if 'Close' in df.columns:
            return df['Close'].pct_change().dropna()
        else:
            return df.pct_change().dropna()
    
    def calculate_technical_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Calculate common technical indicators.
        
        Args:
            df: DataFrame with OHLCV data
            
        Returns:
            DataFrame with indicators added
        """
        result = df.copy()
        close = df['Close'] if 'Close' in df.columns else df.iloc[:, 0]
        
        # Simple Moving Averages
        result['SMA_20'] = close.rolling(window=20).mean()
        result['SMA_50'] = close.rolling(window=50).mean()
        result['SMA_200'] = close.rolling(window=200).mean()
        
        # Exponential Moving Averages
        result['EMA_12'] = close.ewm(span=12, adjust=False).mean()
        result['EMA_26'] = close.ewm(span=26, adjust=False).mean()
        
        # MACD
        result['MACD'] = result['EMA_12'] - result['EMA_26']
        result['MACD_Signal'] = result['MACD'].ewm(span=9, adjust=False).mean()
        result['MACD_Hist'] = result['MACD'] - result['MACD_Signal']
        
        # RSI
        delta = close.diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
        rs = gain / loss
        result['RSI'] = 100 - (100 / (1 + rs))
        
        # Bollinger Bands
        result['BB_Middle'] = close.rolling(window=20).mean()
        bb_std = close.rolling(window=20).std()
        result['BB_Upper'] = result['BB_Middle'] + (bb_std * 2)
        result['BB_Lower'] = result['BB_Middle'] - (bb_std * 2)
        
        # Volume indicators
        if 'Volume' in df.columns:
            result['Volume_SMA_20'] = df['Volume'].rolling(window=20).mean()
            result['Volume_Ratio'] = df['Volume'] / result['Volume_SMA_20']
        
        # Volatility (20-day rolling std of returns)
        returns = close.pct_change()
        result['Volatility_20'] = returns.rolling(window=20).std() * (252 ** 0.5)  # Annualized
        
        return result
    
    def _load_from_cache(
        self,
        ticker: str,
        period: str,
        interval: str
    ) -> Optional[pd.DataFrame]:
        """Load data from cache if available and not expired."""
        cache_path = self.config.get_cache_path('stocks', f"{ticker}_{period}_{interval}")
        
        if cache_path.exists():
            try:
                # Check if cache is recent
                mod_time = datetime.fromtimestamp(cache_path.stat().st_mtime)
                if datetime.now() - mod_time < timedelta(days=self._cache_expiry_days):
                    with open(cache_path, 'rb') as f:
                        return pickle.load(f)
            except Exception as e:
                logger.debug(f"Cache load failed: {e}")
        
        return None
    
    def _save_to_cache(
        self,
        df: pd.DataFrame,
        ticker: str,
        period: str,
        interval: str
    ):
        """Save data to cache."""
        cache_path = self.config.get_cache_path('stocks', f"{ticker}_{period}_{interval}")
        
        try:
            with open(cache_path, 'wb') as f:
                pickle.dump(df, f)
        except Exception as e:
            logger.debug(f"Cache save failed: {e}")
    
    def clear_cache(self):
        """Clear all cached stock data."""
        cache_dir = self.config.cache_dir / 'stocks'
        if cache_dir.exists():
            for f in cache_dir.glob('*.pkl'):
                try:
                    f.unlink()
                except OSError:
                    pass
        logger.info("Stock data cache cleared")
