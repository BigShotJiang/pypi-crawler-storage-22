"""
Data Cleaner for FinNet

Utilities for cleaning and preprocessing financial data.
"""

import re
from datetime import datetime
from typing import List, Optional, Dict, Any

import pandas as pd
import numpy as np

from finnet.utils.logger import get_logger

logger = get_logger(__name__)


class DataCleaner:
    """
    Data cleaning utilities for financial data.
    
    Handles:
    - Stock data cleaning (missing values, outliers)
    - Text data cleaning (for sentiment analysis)
    - News data deduplication
    - Date normalization
    """
    
    def __init__(self):
        """Initialize the data cleaner."""
        pass
    
    def clean_stock_data(
        self,
        df: pd.DataFrame,
        fill_method: str = "ffill",
        remove_outliers: bool = True,
        outlier_std: float = 3.0
    ) -> pd.DataFrame:
        """
        Clean stock price data.
        
        Args:
            df: DataFrame with stock data
            fill_method: Method for filling missing values ('ffill', 'bfill', 'interpolate')
            remove_outliers: Whether to cap outliers
            outlier_std: Number of standard deviations for outlier detection
            
        Returns:
            Cleaned DataFrame
        """
        if df.empty:
            return df
        
        df = df.copy()
        
        # Remove rows with all NaN
        df = df.dropna(how='all')
        
        # Fill missing values
        if fill_method == 'ffill':
            df = df.ffill()
        elif fill_method == 'bfill':
            df = df.bfill()
        elif fill_method == 'interpolate':
            df = df.interpolate(method='linear')
        
        # Still fill any remaining NaN
        df = df.ffill().bfill()
        
        # Cap outliers if requested
        if remove_outliers and len(df) > 5:
            for col in df.select_dtypes(include=[np.number]).columns:
                mean = df[col].mean()
                std = df[col].std()
                
                if std > 0:
                    lower = mean - outlier_std * std
                    upper = mean + outlier_std * std
                    df[col] = df[col].clip(lower, upper)
        
        logger.debug(f"Cleaned stock data: {len(df)} rows")
        return df
    
    def clean_text(
        self,
        text: str,
        lowercase: bool = True,
        remove_urls: bool = True,
        remove_mentions: bool = True,
        remove_hashtags: bool = False,
        remove_special_chars: bool = False
    ) -> str:
        """
        Clean text for sentiment analysis.
        
        Args:
            text: Input text
            lowercase: Convert to lowercase
            remove_urls: Remove URLs
            remove_mentions: Remove @mentions
            remove_hashtags: Remove hashtags
            remove_special_chars: Remove special characters
            
        Returns:
            Cleaned text
        """
        if not text or not isinstance(text, str):
            return ""
        
        cleaned = text
        
        # Remove URLs
        if remove_urls:
            cleaned = re.sub(r'https?://\S+|www\.\S+', '', cleaned)
        
        # Remove mentions
        if remove_mentions:
            cleaned = re.sub(r'@\w+', '', cleaned)
        
        # Remove hashtags (keep the word)
        if remove_hashtags:
            cleaned = re.sub(r'#(\w+)', r'\1', cleaned)
        
        # Remove special characters (keep alphanumeric and spaces)
        if remove_special_chars:
            cleaned = re.sub(r'[^a-zA-Z0-9\s]', '', cleaned)
        
        # Lowercase
        if lowercase:
            cleaned = cleaned.lower()
        
        # Normalize whitespace
        cleaned = re.sub(r'\s+', ' ', cleaned).strip()
        
        return cleaned
    
    def clean_text_column(
        self,
        df: pd.DataFrame,
        column: str,
        **kwargs
    ) -> pd.DataFrame:
        """
        Clean text in a DataFrame column.
        
        Args:
            df: Input DataFrame
            column: Column to clean
            **kwargs: Arguments for clean_text()
            
        Returns:
            DataFrame with cleaned column
        """
        if df.empty or column not in df.columns:
            return df
        
        df = df.copy()
        df[column] = df[column].apply(lambda x: self.clean_text(x, **kwargs))
        return df
    
    def deduplicate_news(
        self,
        df: pd.DataFrame,
        title_column: str = 'title',
        similarity_threshold: float = 0.85
    ) -> pd.DataFrame:
        """
        Remove duplicate news articles.
        
        Args:
            df: DataFrame with news articles
            title_column: Column containing article titles
            similarity_threshold: Threshold for considering articles as duplicates
            
        Returns:
            Deduplicated DataFrame
        """
        if df.empty or title_column not in df.columns:
            return df
        
        # First, exact duplicate removal
        df = df.drop_duplicates(subset=[title_column])
        
        # For similarity-based deduplication, use simple overlap
        # (avoiding heavy dependencies like sklearn for this feature)
        if len(df) > 1 and similarity_threshold < 1.0:
            def get_words(text):
                if not isinstance(text, str):
                    return set()
                return set(text.lower().split())
            
            titles = df[title_column].tolist()
            keep_indices = []
            
            for i, title in enumerate(titles):
                words_i = get_words(title)
                is_duplicate = False
                
                for j in keep_indices:
                    words_j = get_words(titles[j])
                    
                    if not words_i or not words_j:
                        continue
                    
                    # Jaccard similarity
                    intersection = len(words_i & words_j)
                    union = len(words_i | words_j)
                    
                    if union > 0 and intersection / union >= similarity_threshold:
                        is_duplicate = True
                        break
                
                if not is_duplicate:
                    keep_indices.append(i)
            
            df = df.iloc[keep_indices]
        
        logger.debug(f"Deduplicated to {len(df)} articles")
        return df.reset_index(drop=True)
    
    def normalize_dates(
        self,
        df: pd.DataFrame,
        date_column: str,
        output_format: str = '%Y-%m-%d'
    ) -> pd.DataFrame:
        """
        Normalize dates in a DataFrame column.
        
        Args:
            df: Input DataFrame
            date_column: Column containing dates
            output_format: Output date format
            
        Returns:
            DataFrame with normalized dates
        """
        if df.empty or date_column not in df.columns:
            return df
        
        df = df.copy()
        
        def parse_date(date_val):
            if pd.isna(date_val):
                return None
            
            if isinstance(date_val, datetime):
                return date_val
            
            if isinstance(date_val, pd.Timestamp):
                return date_val.to_pydatetime()
            
            if isinstance(date_val, str):
                try:
                    return pd.to_datetime(date_val).to_pydatetime()
                except Exception:
                    return None
            
            return None
        
        df[date_column] = df[date_column].apply(parse_date)
        df[f'{date_column}_formatted'] = df[date_column].apply(
            lambda x: x.strftime(output_format) if x else None
        )
        
        return df
    
    def remove_low_quality_text(
        self,
        df: pd.DataFrame,
        text_column: str,
        min_length: int = 10,
        min_words: int = 3
    ) -> pd.DataFrame:
        """
        Remove rows with low-quality text.
        
        Args:
            df: Input DataFrame
            text_column: Column containing text
            min_length: Minimum character length
            min_words: Minimum word count
            
        Returns:
            Filtered DataFrame
        """
        if df.empty or text_column not in df.columns:
            return df
        
        df = df.copy()
        
        def is_quality_text(text):
            if not isinstance(text, str):
                return False
            if len(text) < min_length:
                return False
            if len(text.split()) < min_words:
                return False
            # Check if mostly special characters
            alpha_ratio = sum(c.isalpha() for c in text) / max(len(text), 1)
            if alpha_ratio < 0.3:
                return False
            return True
        
        mask = df[text_column].apply(is_quality_text)
        filtered = df[mask]
        
        logger.debug(f"Removed {len(df) - len(filtered)} low-quality rows")
        return filtered.reset_index(drop=True)
    
    def standardize_ticker(self, ticker: str) -> str:
        """
        Standardize ticker symbol format.
        
        Args:
            ticker: Input ticker
            
        Returns:
            Standardized ticker
        """
        if not ticker or not isinstance(ticker, str):
            return ""
        
        # Remove common prefixes
        ticker = ticker.replace('$', '').strip()
        
        # Uppercase
        ticker = ticker.upper()
        
        # Handle special tickers (e.g., BRK.A -> BRK-A for some APIs)
        ticker = ticker.replace('.', '-')
        
        return ticker
    
    def merge_sentiment_data(
        self,
        stock_df: pd.DataFrame,
        sentiment_df: pd.DataFrame,
        date_column: str = 'Date',
        ticker_column: str = 'ticker',
        agg_method: str = 'mean'
    ) -> pd.DataFrame:
        """
        Merge sentiment data with stock data.
        
        Args:
            stock_df: Stock price DataFrame
            sentiment_df: Sentiment DataFrame
            date_column: Date column name
            ticker_column: Ticker column name
            agg_method: Aggregation method for multiple sentiments per day
            
        Returns:
            Merged DataFrame
        """
        if stock_df.empty or sentiment_df.empty:
            return stock_df
        
        # Ensure date columns are datetime
        if date_column in sentiment_df.columns:
            sentiment_df[date_column] = pd.to_datetime(sentiment_df[date_column])
        
        # Aggregate sentiment by date
        if 'sentiment_score' in sentiment_df.columns:
            agg_sentiment = sentiment_df.groupby(
                sentiment_df[date_column].dt.date
            )['sentiment_score'].agg(agg_method).reset_index()
            agg_sentiment.columns = ['date', 'avg_sentiment']
            
            # Merge with stock data
            stock_df = stock_df.copy()
            stock_df['date'] = pd.to_datetime(stock_df.index).date
            stock_df = stock_df.merge(agg_sentiment, on='date', how='left')
            stock_df['avg_sentiment'] = stock_df['avg_sentiment'].fillna(0)
        
        return stock_df
