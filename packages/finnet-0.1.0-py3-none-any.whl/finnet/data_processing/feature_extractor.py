"""
Feature Extractor for FinNet

Extract features from stock data and sentiment for network construction.
"""

from typing import Dict, List, Optional, Any, Tuple

import pandas as pd
import numpy as np

from finnet.utils.logger import get_logger

logger = get_logger(__name__)


class FeatureExtractor:
    """
    Extract features for network construction and machine learning.
    
    Extracts:
    - Stock correlation features
    - Sentiment features
    - Technical indicator features
    - Network-ready feature vectors
    """
    
    def __init__(self):
        """Initialize the feature extractor."""
        pass
    
    def extract_correlation_matrix(
        self,
        stock_df: pd.DataFrame,
        method: str = 'pearson',
        min_periods: int = 20
    ) -> pd.DataFrame:
        """
        Extract correlation matrix from stock returns.
        
        Args:
            stock_df: DataFrame with stock prices (columns = tickers)
            method: Correlation method ('pearson', 'spearman', 'kendall')
            min_periods: Minimum overlapping periods for correlation
            
        Returns:
            Correlation matrix DataFrame
        """
        if stock_df.empty:
            return pd.DataFrame()
        
        # Calculate returns
        returns = stock_df.pct_change().dropna()
        
        if len(returns) < min_periods:
            logger.warning(f"Insufficient data for correlation: {len(returns)} rows")
            return pd.DataFrame()
        
        # Calculate correlation matrix
        corr_matrix = returns.corr(method=method, min_periods=min_periods)
        
        # Fill NaN with 0 (no correlation for tickers with insufficient overlap)
        corr_matrix = corr_matrix.fillna(0)
        
        logger.info(f"Computed {method} correlation matrix: {corr_matrix.shape}")
        return corr_matrix
    
    def extract_rolling_correlations(
        self,
        stock_df: pd.DataFrame,
        window: int = 30,
        method: str = 'pearson'
    ) -> Dict[str, pd.DataFrame]:
        """
        Extract rolling correlations over time.
        
        Args:
            stock_df: DataFrame with stock prices
            window: Rolling window size
            method: Correlation method
            
        Returns:
            Dictionary mapping (ticker1, ticker2) to correlation series
        """
        returns = stock_df.pct_change().dropna()
        
        if len(returns) < window:
            return {}
        
        tickers = list(returns.columns)
        rolling_corrs = {}
        
        for i, ticker1 in enumerate(tickers):
            for ticker2 in tickers[i+1:]:
                rolling = returns[ticker1].rolling(window).corr(returns[ticker2])
                rolling_corrs[(ticker1, ticker2)] = rolling
        
        return rolling_corrs
    
    def extract_sentiment_features(
        self,
        sentiment_df: pd.DataFrame,
        ticker_column: str = 'ticker',
        score_column: str = 'sentiment_score'
    ) -> pd.DataFrame:
        """
        Extract aggregated sentiment features per ticker.
        
        Args:
            sentiment_df: DataFrame with sentiment data
            ticker_column: Column with ticker symbols
            score_column: Column with sentiment scores
            
        Returns:
            DataFrame with sentiment features per ticker
        """
        if sentiment_df.empty or ticker_column not in sentiment_df.columns:
            return pd.DataFrame()
        
        if score_column not in sentiment_df.columns:
            return pd.DataFrame()
        
        # Aggregate by ticker
        features = sentiment_df.groupby(ticker_column).agg({
            score_column: ['mean', 'std', 'min', 'max', 'count']
        }).reset_index()
        
        # Flatten column names
        features.columns = [
            ticker_column,
            'sentiment_mean',
            'sentiment_std',
            'sentiment_min',
            'sentiment_max',
            'sentiment_count'
        ]
        
        # Fill NaN std (when only one observation)
        features['sentiment_std'] = features['sentiment_std'].fillna(0)
        
        logger.info(f"Extracted sentiment features for {len(features)} tickers")
        return features
    
    def extract_co_mention_matrix(
        self,
        posts: List[Dict],
        text_key: str = 'text',
        min_co_mentions: int = 2
    ) -> pd.DataFrame:
        """
        Extract co-mention matrix from Reddit/news posts.
        
        Builds a matrix where entry (i, j) = number of times
        tickers i and j are mentioned together.
        
        Args:
            posts: List of post dictionaries
            text_key: Key containing text in each post
            min_co_mentions: Minimum co-mentions to include
            
        Returns:
            Co-mention matrix
        """
        from finnet.data_collection.reddit_scraper import RedditJSONScraper
        
        scraper = RedditJSONScraper()
        co_mentions = {}
        
        for post in posts:
            text = post.get(text_key, '') + ' ' + post.get('title', '')
            tickers = scraper.extract_ticker_mentions(text)
            
            # Record all pairs
            for i, t1 in enumerate(tickers):
                for t2 in tickers[i+1:]:
                    pair = tuple(sorted([t1, t2]))
                    co_mentions[pair] = co_mentions.get(pair, 0) + 1
        
        # Filter by minimum co-mentions
        filtered = {k: v for k, v in co_mentions.items() if v >= min_co_mentions}
        
        if not filtered:
            return pd.DataFrame()
        
        # Build matrix
        all_tickers = set()
        for t1, t2 in filtered.keys():
            all_tickers.add(t1)
            all_tickers.add(t2)
        
        tickers = sorted(all_tickers)
        n = len(tickers)
        ticker_idx = {t: i for i, t in enumerate(tickers)}
        
        matrix = np.zeros((n, n))
        
        for (t1, t2), count in filtered.items():
            i, j = ticker_idx[t1], ticker_idx[t2]
            matrix[i, j] = count
            matrix[j, i] = count
        
        df = pd.DataFrame(matrix, index=tickers, columns=tickers)
        logger.info(f"Computed co-mention matrix: {df.shape}")
        return df
    
    def extract_sector_features(
        self,
        company_info: Dict[str, Dict]
    ) -> pd.DataFrame:
        """
        Extract sector and industry features.
        
        Args:
            company_info: Dictionary mapping ticker to company info
            
        Returns:
            DataFrame with sector features
        """
        if not company_info:
            return pd.DataFrame()
        
        data = []
        for ticker, info in company_info.items():
            if isinstance(info, dict):
                data.append({
                    'ticker': ticker,
                    'sector': info.get('sector', 'Unknown'),
                    'industry': info.get('industry', 'Unknown'),
                    'market_cap': info.get('market_cap', 0),
                    'beta': info.get('beta', 1.0),
                })
        
        return pd.DataFrame(data)
    
    def extract_node_features(
        self,
        stock_df: pd.DataFrame,
        sentiment_df: Optional[pd.DataFrame] = None,
        company_info: Optional[Dict] = None
    ) -> pd.DataFrame:
        """
        Extract node feature vectors for GNN.
        
        Combines stock, sentiment, and company features into
        a single feature matrix for each ticker (node).
        
        Args:
            stock_df: Stock price data
            sentiment_df: Optional sentiment data
            company_info: Optional company info dict
            
        Returns:
            DataFrame with feature vectors (rows = tickers)
        """
        tickers = list(stock_df.columns)
        
        features = pd.DataFrame({'ticker': tickers})
        
        # Stock features
        returns = stock_df.pct_change().dropna()
        
        for ticker in tickers:
            if ticker in returns.columns:
                ticker_returns = returns[ticker]
                idx = features[features['ticker'] == ticker].index[0]
                
                features.loc[idx, 'return_mean'] = ticker_returns.mean()
                features.loc[idx, 'return_std'] = ticker_returns.std()
                features.loc[idx, 'return_skew'] = ticker_returns.skew()
                features.loc[idx, 'return_kurt'] = ticker_returns.kurtosis()
                features.loc[idx, 'sharpe_ratio'] = (
                    ticker_returns.mean() / ticker_returns.std()
                    if ticker_returns.std() > 0 else 0
                )
        
        # Sentiment features
        if sentiment_df is not None and not sentiment_df.empty:
            sent_features = self.extract_sentiment_features(sentiment_df)
            if not sent_features.empty:
                features = features.merge(sent_features, on='ticker', how='left')
        
        # Company features
        if company_info:
            for ticker in tickers:
                if ticker in company_info:
                    info = company_info[ticker]
                    idx = features[features['ticker'] == ticker].index[0]
                    
                    features.loc[idx, 'market_cap_log'] = (
                        np.log1p(info.get('market_cap', 0))
                    )
                    features.loc[idx, 'beta'] = info.get('beta', 1.0)
        
        # Fill missing values
        features = features.fillna(0)
        
        logger.info(f"Extracted node features: {features.shape}")
        return features
    
    def extract_edge_features(
        self,
        corr_matrix: pd.DataFrame,
        threshold: float = 0.5
    ) -> List[Tuple[str, str, Dict]]:
        """
        Extract edge features for network construction.
        
        Args:
            corr_matrix: Correlation matrix
            threshold: Minimum correlation for edge creation
            
        Returns:
            List of (source, target, attributes) tuples
        """
        edges = []
        tickers = list(corr_matrix.columns)
        
        for i, t1 in enumerate(tickers):
            for t2 in tickers[i+1:]:
                corr = corr_matrix.loc[t1, t2]
                
                if abs(corr) >= threshold:
                    edges.append((t1, t2, {
                        'weight': abs(corr),
                        'correlation': corr,
                        'type': 'positive' if corr > 0 else 'negative'
                    }))
        
        logger.info(f"Extracted {len(edges)} edges with threshold {threshold}")
        return edges
    
    def normalize_features(
        self,
        df: pd.DataFrame,
        columns: Optional[List[str]] = None,
        method: str = 'zscore'
    ) -> pd.DataFrame:
        """
        Normalize feature columns.
        
        Args:
            df: Input DataFrame
            columns: Columns to normalize (None = all numeric)
            method: 'zscore', 'minmax', or 'robust'
            
        Returns:
            Normalized DataFrame
        """
        df = df.copy()
        
        if columns is None:
            columns = df.select_dtypes(include=[np.number]).columns.tolist()
        
        for col in columns:
            if col not in df.columns:
                continue
            
            values = df[col].values
            
            if method == 'zscore':
                mean = values.mean()
                std = values.std()
                if std > 0:
                    df[col] = (values - mean) / std
            
            elif method == 'minmax':
                min_val = values.min()
                max_val = values.max()
                if max_val > min_val:
                    df[col] = (values - min_val) / (max_val - min_val)
            
            elif method == 'robust':
                median = np.median(values)
                iqr = np.percentile(values, 75) - np.percentile(values, 25)
                if iqr > 0:
                    df[col] = (values - median) / iqr
        
        return df
