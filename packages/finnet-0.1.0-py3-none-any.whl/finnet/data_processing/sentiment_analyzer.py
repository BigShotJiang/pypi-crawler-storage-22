"""
Sentiment Analyzer for Financial Text

Multi-model sentiment analysis using VADER, TextBlob, and optionally FinBERT.
"""

from typing import Dict, List, Optional, Any

import pandas as pd
# from tqdm import tqdm

from finnet.utils.logger import get_logger

logger = get_logger(__name__)


class SentimentAnalyzer:
    """
    Multi-model sentiment analysis for financial text.
    
    Models:
    - VADER: Fast, rule-based sentiment (good for social media)
    - TextBlob: Pattern-based sentiment
    - FinBERT: Transformer model specifically for financial text (optional)
    """
    
    def __init__(self, use_finbert: bool = False):
        """
        Initialize the sentiment analyzer.
        
        Args:
            use_finbert: Whether to load FinBERT (requires transformers library)
        """
        self._vader = None
        self._textblob_available = False
        self._finbert_model = None
        self._finbert_tokenizer = None
        self.use_finbert = use_finbert
        
        # Initialize models
        self._init_vader()
        self._init_textblob()
        
        if use_finbert:
            self._init_finbert()
    
    def _init_vader(self):
        """Initialize VADER sentiment analyzer."""
        try:
            from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
            self._vader = SentimentIntensityAnalyzer()
            logger.debug("VADER initialized successfully")
        except ImportError:
            logger.warning("VADER not available. Install: pip install vaderSentiment")
    
    def _init_textblob(self):
        """Initialize TextBlob."""
        try:
            from textblob import TextBlob
            self._textblob_available = True
            logger.debug("TextBlob initialized successfully")
        except ImportError:
            logger.warning("TextBlob not available. Install: pip install textblob")
    
    def _init_finbert(self):
        """Initialize FinBERT model."""
        try:
            from transformers import AutoModelForSequenceClassification, AutoTokenizer
            import torch
            
            logger.info("Loading FinBERT model (this may take a moment)...")
            
            model_name = "ProsusAI/finbert"
            self._finbert_tokenizer = AutoTokenizer.from_pretrained(model_name)
            self._finbert_model = AutoModelForSequenceClassification.from_pretrained(model_name)
            
            # Move to GPU if available
            if torch.cuda.is_available():
                self._finbert_model = self._finbert_model.cuda()
                logger.info("FinBERT loaded on GPU")
            else:
                logger.info("FinBERT loaded on CPU")
                
        except ImportError:
            logger.warning("FinBERT not available. Install: pip install transformers torch")
            self.use_finbert = False
        except Exception as e:
            logger.error(f"Error loading FinBERT: {e}")
            self.use_finbert = False
    
    def analyze_vader(self, text: str) -> Dict[str, float]:
        """
        Analyze text with VADER.
        
        Args:
            text: Text to analyze
            
        Returns:
            Dictionary with sentiment scores (neg, neu, pos, compound)
        """
        if not self._vader or not text:
            return {'neg': 0, 'neu': 1, 'pos': 0, 'compound': 0}
        
        scores = self._vader.polarity_scores(text)
        return scores
    
    def analyze_textblob(self, text: str) -> Dict[str, float]:
        """
        Analyze text with TextBlob.
        
        Args:
            text: Text to analyze
            
        Returns:
            Dictionary with polarity and subjectivity
        """
        if not self._textblob_available or not text:
            return {'polarity': 0, 'subjectivity': 0.5}
        
        try:
            from textblob import TextBlob
            blob = TextBlob(text)
            return {
                'polarity': blob.sentiment.polarity,  # -1 to 1
                'subjectivity': blob.sentiment.subjectivity,  # 0 to 1
            }
        except Exception as e:
            logger.debug(f"TextBlob error: {e}")
            return {'polarity': 0, 'subjectivity': 0.5}
    
    def analyze_finbert(self, text: str) -> Dict[str, float]:
        """
        Analyze text with FinBERT.
        
        Args:
            text: Text to analyze
            
        Returns:
            Dictionary with positive, negative, neutral scores
        """
        if not self._finbert_model or not text:
            return {'positive': 0.33, 'negative': 0.33, 'neutral': 0.34, 'score': 0}
        
        try:
            import torch
            
            # Tokenize
            inputs = self._finbert_tokenizer(
                text[:512],  # FinBERT max length
                return_tensors="pt",
                truncation=True,
                padding=True,
                max_length=512
            )
            
            # Move to GPU if model is on GPU
            if next(self._finbert_model.parameters()).is_cuda:
                inputs = {k: v.cuda() for k, v in inputs.items()}
            
            # Predict
            with torch.no_grad():
                outputs = self._finbert_model(**inputs)
                probs = torch.softmax(outputs.logits, dim=1)[0]
            
            # FinBERT labels: positive, negative, neutral
            scores = probs.cpu().numpy()
            
            return {
                'positive': float(scores[0]),
                'negative': float(scores[1]),
                'neutral': float(scores[2]),
                'score': float(scores[0] - scores[1]),  # Net sentiment
            }
            
        except Exception as e:
            logger.debug(f"FinBERT error: {e}")
            return {'positive': 0.33, 'negative': 0.33, 'neutral': 0.34, 'score': 0}
    
    def analyze(self, text: str) -> Dict[str, Any]:
        """
        Analyze text with all available models.
        
        Args:
            text: Text to analyze
            
        Returns:
            Dictionary with all sentiment results and aggregate score
        """
        results = {
            'text_length': len(text) if text else 0,
            'vader': self.analyze_vader(text),
            'textblob': self.analyze_textblob(text),
        }
        
        if self.use_finbert:
            results['finbert'] = self.analyze_finbert(text)
        
        # Calculate aggregate sentiment
        results['aggregate'] = self._calculate_aggregate(results)
        
        return results
    
    def _calculate_aggregate(self, results: Dict) -> Dict[str, float]:
        """Calculate aggregate sentiment from all models."""
        scores = []
        weights = []
        
        # VADER compound score (-1 to 1)
        vader_compound = results['vader']['compound']
        scores.append(vader_compound)
        weights.append(1.0)
        
        # TextBlob polarity (-1 to 1)
        textblob_polarity = results['textblob']['polarity']
        scores.append(textblob_polarity)
        weights.append(0.8)
        
        # FinBERT score (if available)
        if 'finbert' in results:
            finbert_score = results['finbert']['score']
            scores.append(finbert_score)
            weights.append(1.5)  # Higher weight for domain-specific model
        
        # Weighted average
        total_weight = sum(weights)
        aggregate_score = sum(s * w for s, w in zip(scores, weights)) / total_weight
        
        # Confidence based on agreement
        if len(scores) > 1:
            import statistics
            variance = statistics.variance(scores) if len(scores) > 1 else 0
            confidence = max(0, 1 - (variance * 2))  # Lower variance = higher confidence
        else:
            confidence = 0.5
        
        # Label
        if aggregate_score > 0.2:
            label = 'positive'
        elif aggregate_score < -0.2:
            label = 'negative'
        else:
            label = 'neutral'
        
        return {
            'score': aggregate_score,
            'confidence': confidence,
            'label': label,
        }
    
    def analyze_batch(
        self,
        texts: List[str],
        show_progress: bool = True
    ) -> List[Dict[str, Any]]:
        """
        Analyze multiple texts.
        
        Args:
            texts: List of texts
            show_progress: Show progress bar
            
        Returns:
            List of sentiment results
        """
        results = []
        
        # iterator = tqdm(texts, desc="Analyzing sentiment") if show_progress else texts
        iterator = texts
        if show_progress:
            print(f"Analyzing sentiment for {len(texts)} items...")
        
        for text in iterator:
            result = self.analyze(text)
            results.append(result)
        
        return results
    
    def analyze_dataframe(
        self,
        df: pd.DataFrame,
        text_column: str,
        show_progress: bool = True
    ) -> pd.DataFrame:
        """
        Analyze sentiment for a DataFrame column.
        
        Args:
            df: Input DataFrame
            text_column: Column containing text
            show_progress: Show progress bar
            
        Returns:
            DataFrame with sentiment columns added
        """
        if df.empty or text_column not in df.columns:
            return df
        
        df = df.copy()
        texts = df[text_column].fillna('').tolist()
        
        results = self.analyze_batch(texts, show_progress)
        
        # Add sentiment columns
        df['sentiment_vader'] = [r['vader']['compound'] for r in results]
        df['sentiment_textblob'] = [r['textblob']['polarity'] for r in results]
        df['sentiment_score'] = [r['aggregate']['score'] for r in results]
        df['sentiment_confidence'] = [r['aggregate']['confidence'] for r in results]
        df['sentiment_label'] = [r['aggregate']['label'] for r in results]
        
        if self.use_finbert:
            df['sentiment_finbert'] = [r.get('finbert', {}).get('score', 0) for r in results]
        
        return df
    
    def get_sentiment_summary(
        self,
        texts: List[str]
    ) -> Dict[str, Any]:
        """
        Get summary statistics for a collection of texts.
        
        Args:
            texts: List of texts
            
        Returns:
            Summary dictionary
        """
        if not texts:
            return {
                'count': 0,
                'avg_score': 0,
                'positive_pct': 0,
                'negative_pct': 0,
                'neutral_pct': 0,
            }
        
        results = self.analyze_batch(texts, show_progress=False)
        
        scores = [r['aggregate']['score'] for r in results]
        labels = [r['aggregate']['label'] for r in results]
        
        total = len(labels)
        positive = labels.count('positive')
        negative = labels.count('negative')
        neutral = labels.count('neutral')
        
        return {
            'count': total,
            'avg_score': sum(scores) / total,
            'min_score': min(scores),
            'max_score': max(scores),
            'positive_count': positive,
            'negative_count': negative,
            'neutral_count': neutral,
            'positive_pct': positive / total * 100,
            'negative_pct': negative / total * 100,
            'neutral_pct': neutral / total * 100,
        }
