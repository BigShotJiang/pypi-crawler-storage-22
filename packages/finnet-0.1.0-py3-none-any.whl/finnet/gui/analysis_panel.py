"""Analysis Panel - Community detection, metrics, and ML analysis."""

import threading
import customtkinter as ctk
from finnet.utils.logger import get_logger

logger = get_logger(__name__)


class AnalysisPanel(ctk.CTkFrame):
    """Analysis panel for community detection, metrics, and ML."""
    
    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app
        self._create_ui()
    
    def _create_ui(self):
        """Create panel UI."""
        # Left - Controls
        controls = ctk.CTkFrame(self, width=350)
        controls.pack(side="left", fill="y", padx=10, pady=10)
        
        ctk.CTkLabel(controls, text="📈 Analysis", 
                    font=ctk.CTkFont(size=18, weight="bold")).pack(pady=15)
        
        # Analysis type
        ctk.CTkLabel(controls, text="Analysis Type:").pack(anchor="w", padx=10)
        self.analysis_type = ctk.CTkComboBox(controls, width=280, values=[
            "Community Detection", "Centrality Analysis", "Link Prediction",
            "Cascade Simulation", "Anomaly Detection", "Node Embeddings"
        ])
        self.analysis_type.pack(padx=10, pady=5)
        self.analysis_type.set("Community Detection")
        
        # Algorithm
        ctk.CTkLabel(controls, text="Algorithm:").pack(anchor="w", padx=10, pady=(15, 0))
        self.algorithm = ctk.CTkComboBox(controls, width=280, values=[
            "Louvain", "Label Propagation", "Spectral", "Girvan-Newman"
        ])
        self.algorithm.pack(padx=10, pady=5)
        self.algorithm.set("Louvain")
        
        # Run button
        ctk.CTkButton(controls, text="▶️ Run Analysis", width=200,
                     command=self._run_analysis).pack(pady=20)
        
        # Results
        self.results_text = ctk.CTkTextbox(controls, height=300, width=280)
        self.results_text.pack(padx=10, pady=10)
        self.results_text.insert("0.0", "Results will appear here...")
        
        # Right - Charts
        charts = ctk.CTkFrame(self)
        charts.pack(side="right", fill="both", expand=True, padx=10, pady=10)
        
        ctk.CTkLabel(charts, text="Analysis Results",
                    font=ctk.CTkFont(size=16, weight="bold")).pack(pady=10)
        
        # Chart buttons
        btn_frame = ctk.CTkFrame(charts)
        btn_frame.pack(pady=10)
        
        ctk.CTkButton(btn_frame, text="📊 Centrality Chart",
                     command=self._plot_centrality).pack(side="left", padx=5)
        ctk.CTkButton(btn_frame, text="🥧 Community Chart",
                     command=self._plot_communities).pack(side="left", padx=5)
        ctk.CTkButton(btn_frame, text="📉 Sentiment Chart",
                     command=self._plot_sentiment).pack(side="left", padx=5)
    
    def _run_analysis(self):
        """Run selected analysis."""
        if 'current' not in self.app.networks:
            self.results_text.delete("0.0", "end")
            self.results_text.insert("0.0", "❌ Build a network first!")
            return
        
        def run():
            try:
                G = self.app.networks['current']
                analysis = self.analysis_type.get()
                algo = self.algorithm.get()
                
                result_str = f"🔬 {analysis}\n{'='*30}\n\n"
                
                if analysis == "Community Detection":
                    from finnet.network_analysis import CommunityDetector
                    detector = CommunityDetector()
                    
                    if algo == "Louvain":
                        partition = detector.detect_louvain(G)
                    else:
                        partition = detector.detect_label_propagation(G)
                    
                    n_communities = len(set(partition.values()))
                    modularity = detector.calculate_modularity(G, partition)
                    
                    result_str += f"Communities: {n_communities}\n"
                    result_str += f"Modularity: {modularity:.4f}\n\n"
                    
                    for comm_id in sorted(set(partition.values())):
                        nodes = [n for n, c in partition.items() if c == comm_id]
                        result_str += f"Community {comm_id}: {nodes[:5]}{'...' if len(nodes)>5 else ''}\n"
                    
                    self.app.analysis_results['communities'] = partition
                
                elif analysis == "Centrality Analysis":
                    from finnet.network_analysis import NetworkMetricsCalculator
                    calc = NetworkMetricsCalculator()
                    
                    metrics = calc.calculate_all_metrics(G)
                    top_nodes = calc.get_top_nodes(metrics['pagerank'], 5)
                    
                    result_str += "Top 5 by PageRank:\n"
                    for node, score in top_nodes:
                        result_str += f"  {node}: {score:.4f}\n"
                    
                    self.app.analysis_results['centrality'] = metrics
                
                elif analysis == "Node Embeddings":
                    from finnet.machine_learning import Node2VecEmbed
                    n2v = Node2VecEmbed(dimensions=32, walk_length=40, num_walks=5)
                    n2v.fit(G)
                    embeddings, nodes = n2v.get_all_embeddings()
                    result_str += f"Embeddings computed: {embeddings.shape}\n"
                    result_str += f"Nodes: {nodes[:5]}...\n"
                
                self.after(0, lambda: self._update_results(result_str))
                self.after(0, lambda: self.app.set_status("Analysis complete", 1.0))
                
            except Exception as e:
                logger.error(f"Analysis error: {e}")
                self.after(0, lambda: self._update_results(f"Error: {e}"))
        
        threading.Thread(target=run, daemon=True).start()
    
    def _update_results(self, text):
        self.results_text.delete("0.0", "end")
        self.results_text.insert("0.0", text)
    
    def _plot_centrality(self):
        """Plot centrality comparison."""
        if 'centrality' not in self.app.analysis_results:
            return
        try:
            from finnet.visualization import ChartGenerator
            gen = ChartGenerator()
            path = str(self.app.config.get_session_dir() / "centrality.png")
            gen.plot_centrality_comparison(self.app.analysis_results['centrality'], save_path=path)
            self.app.set_status(f"Chart saved: {path}", 1.0)
        except Exception as e:
            self.app.set_status(f"Error: {e}", 0)
    
    def _plot_communities(self):
        """Plot community chart."""
        if 'communities' not in self.app.analysis_results:
            return
        try:
            from finnet.visualization import ChartGenerator
            gen = ChartGenerator()
            path = str(self.app.config.get_session_dir() / "communities.png")
            gen.plot_community_sizes(self.app.analysis_results['communities'], save_path=path)
            self.app.set_status(f"Chart saved: {path}", 1.0)
        except Exception as e:
            self.app.set_status(f"Error: {e}", 0)
    
    def _plot_sentiment(self):
        """Plot sentiment chart."""
        if 'ticker_sentiment' not in self.app.collected_data:
            return
        try:
            from finnet.visualization import ChartGenerator
            gen = ChartGenerator()
            df = self.app.collected_data['ticker_sentiment']
            if 'sentiment_score' in df.columns:
                path = str(self.app.config.get_session_dir() / "sentiment.png")
                gen.plot_sentiment_distribution(df['sentiment_score'].tolist(), save_path=path)
                self.app.set_status(f"Chart saved: {path}", 1.0)
        except Exception as e:
            self.app.set_status(f"Error: {e}", 0)
