"""
Data Collection Panel

GUI panel for data collection controls.
"""

import threading
from typing import Any, List

import customtkinter as ctk

from finnet.utils.logger import get_logger

logger = get_logger(__name__)


class DataCollectionPanel(ctk.CTkFrame):
    """
    Data collection panel for the GUI.
    
    Features:
    - Ticker input
    - Source selection (stocks, Reddit, news)
    - Collection progress
    - Data preview
    """
    
    def __init__(self, parent, app):
        """
        Initialize data collection panel.
        
        Args:
            parent: Parent widget
            app: Main application reference
        """
        super().__init__(parent)
        
        self.app = app
        self.collected_data = {}
        
        self._create_ui()
    
    def _create_ui(self):
        """Create panel UI."""
        # Left column - Controls
        self.controls_frame = ctk.CTkFrame(self)
        self.controls_frame.pack(side="left", fill="y", padx=10, pady=10)
        
        # Title
        title = ctk.CTkLabel(
            self.controls_frame,
            text="📥 Data Collection",
            font=ctk.CTkFont(size=18, weight="bold")
        )
        title.pack(pady=15)
        
        # Ticker input
        ctk.CTkLabel(self.controls_frame, text="Stock Tickers (comma-separated):").pack(anchor="w", padx=10, pady=5)
        self.ticker_entry = ctk.CTkEntry(self.controls_frame, width=300, placeholder_text="AAPL, MSFT, GOOGL, AMZN")
        self.ticker_entry.pack(padx=10, pady=5)
        
        # Period selection
        ctk.CTkLabel(self.controls_frame, text="Time Period:").pack(anchor="w", padx=10, pady=5)
        self.period_combo = ctk.CTkComboBox(
            self.controls_frame,
            values=["1mo", "3mo", "6mo", "1y", "2y", "5y"],
            width=150
        )
        self.period_combo.pack(padx=10, pady=5)
        self.period_combo.set("1y")
        
        # Data sources
        ctk.CTkLabel(self.controls_frame, text="Data Sources:").pack(anchor="w", padx=10, pady=(20, 5))
        
        self.source_stocks = ctk.CTkCheckBox(self.controls_frame, text="Stock Prices (yFinance)")
        self.source_stocks.pack(anchor="w", padx=20, pady=3)
        self.source_stocks.select()
        
        self.source_reddit = ctk.CTkCheckBox(self.controls_frame, text="Reddit Discussions")
        self.source_reddit.pack(anchor="w", padx=20, pady=3)
        self.source_reddit.select()
        
        self.source_news = ctk.CTkCheckBox(self.controls_frame, text="Financial News")
        self.source_news.pack(anchor="w", padx=20, pady=3)
        self.source_news.select()
        
        self.source_rss = ctk.CTkCheckBox(self.controls_frame, text="RSS Feeds")
        self.source_rss.pack(anchor="w", padx=20, pady=3)
        
        # Reddit settings
        ctk.CTkLabel(self.controls_frame, text="Reddit Subreddits:").pack(anchor="w", padx=10, pady=(20, 5))
        self.subreddit_entry = ctk.CTkEntry(
            self.controls_frame,
            width=300,
            placeholder_text="wallstreetbets, stocks, investing"
        )
        self.subreddit_entry.pack(padx=10, pady=5)
        
        # Collect button
        self.collect_btn = ctk.CTkButton(
            self.controls_frame,
            text="🔄 Collect Data",
            width=200,
            height=40,
            command=self._collect_data
        )
        self.collect_btn.pack(pady=30)
        
        # Progress
        self.progress_label = ctk.CTkLabel(
            self.controls_frame,
            text="",
            text_color="gray"
        )
        self.progress_label.pack(pady=5)
        
        # Right column - Preview
        self.preview_frame = ctk.CTkFrame(self)
        self.preview_frame.pack(side="right", fill="both", expand=True, padx=10, pady=10)
        
        # Preview title
        preview_title = ctk.CTkLabel(
            self.preview_frame,
            text="Data Preview",
            font=ctk.CTkFont(size=16, weight="bold")
        )
        preview_title.pack(pady=10)
        
        # Preview text
        self.preview_text = ctk.CTkTextbox(self.preview_frame, width=500, height=500)
        self.preview_text.pack(fill="both", expand=True, padx=10, pady=10)
        self.preview_text.insert("0.0", "Collected data will appear here...")
    
    def _collect_data(self):
        """Start data collection."""
        tickers_str = self.ticker_entry.get().strip()
        
        if not tickers_str:
            self.progress_label.configure(text="❌ Please enter at least one ticker")
            return
        
        tickers = [t.strip().upper() for t in tickers_str.split(',')]
        period = self.period_combo.get()
        
        subreddits_str = self.subreddit_entry.get().strip()
        subreddits = [s.strip() for s in subreddits_str.split(',')] if subreddits_str else ['wallstreetbets', 'stocks']
        
        self.collect_btn.configure(state="disabled")
        self.progress_label.configure(text="Collecting data...")
        self.app.set_status("Collecting data...", 0.1)
        
        def collect():
            try:
                from finnet.data_collection import (
                    StockDataCollector,
                    RedditJSONScraper,
                    GoogleNewsCollector,
                    RSSNewsCollector
                )
                
                results = {}
                
                # Stock data
                if self.source_stocks.get():
                    self._update_progress("Fetching stock data...")
                    collector = StockDataCollector()
                    stock_data = collector.get_multiple_stocks(tickers, period=period)
                    results['stocks'] = stock_data
                    
                    # Company info
                    company_info = {}
                    for ticker in tickers[:5]:  # Limit to prevent slowdown
                        info = collector.get_company_info(ticker)
                        if info:
                            company_info[ticker] = info
                    results['company_info'] = company_info
                    
                    self.app.set_status("Stock data collected", 0.3)
                
                # Reddit
                if self.source_reddit.get():
                    self._update_progress("Scraping Reddit...")
                    scraper = RedditJSONScraper()
                    reddit_posts = []
                    
                    for sub in subreddits[:3]:  # Limit subreddits
                        posts = scraper.get_subreddit_posts(sub, limit=50)
                        reddit_posts.extend(posts)
                    
                    results['reddit_posts'] = reddit_posts
                    
                    # Ticker sentiment
                    sentiment_df, _ = scraper.bulk_ticker_scrape(tickers[:5], subreddits[:2])
                    results['ticker_sentiment'] = sentiment_df
                    
                    self.app.set_status("Reddit data collected", 0.5)
                
                # News
                if self.source_news.get():
                    self._update_progress("Fetching news...")
                    
                    try:
                        news_collector = GoogleNewsCollector()
                        all_news = []
                        
                        for ticker in tickers[:5]:
                            news = news_collector.search_ticker_news(ticker)
                            all_news.extend(news)
                        
                        results['news'] = all_news
                    except Exception as e:
                        logger.warning(f"News collection error: {e}")
                    
                    self.app.set_status("News collected", 0.7)
                
                # RSS
                if self.source_rss.get():
                    self._update_progress("Parsing RSS feeds...")
                    
                    try:
                        rss = RSSNewsCollector()
                        rss_news = rss.collect_all_feeds()
                        results['rss_news'] = rss_news
                    except Exception as e:
                        logger.warning(f"RSS collection error: {e}")
                    
                    self.app.set_status("RSS feeds collected", 0.9)
                
                # Store results
                self.collected_data = results
                self.app.collected_data = results
                
                # Update preview
                self.after(0, lambda: self._update_preview(results))
                self.after(0, lambda: self._update_progress("✅ Data collection complete!"))
                self.after(0, lambda: self.app.set_status("Data collection complete", 1.0))
                
            except Exception as e:
                logger.error(f"Data collection error: {e}")
                self.after(0, lambda: self._update_progress(f"❌ Error: {e}"))
                self.after(0, lambda: self.app.set_status(f"Error: {e}", 0))
            
            finally:
                self.after(0, lambda: self.collect_btn.configure(state="normal"))
        
        threading.Thread(target=collect, daemon=True).start()
    
    def _update_progress(self, message: str):
        """Update progress label."""
        self.progress_label.configure(text=message)
    
    def _update_preview(self, results: dict):
        """Update data preview."""
        self.preview_text.delete("0.0", "end")
        
        preview = "📊 COLLECTED DATA SUMMARY\n"
        preview += "=" * 40 + "\n\n"
        
        if 'stocks' in results:
            df = results['stocks']
            preview += f"📈 Stock Data:\n"
            preview += f"   • Tickers: {list(df.columns)}\n"
            preview += f"   • Date range: {df.index.min().date()} to {df.index.max().date()}\n"
            preview += f"   • Records: {len(df)}\n\n"
        
        if 'company_info' in results:
            preview += f"🏢 Company Info:\n"
            for ticker, info in list(results['company_info'].items())[:3]:
                preview += f"   • {ticker}: {info.get('name', 'N/A')}\n"
            preview += "\n"
        
        if 'reddit_posts' in results:
            posts = results['reddit_posts']
            preview += f"💬 Reddit Posts: {len(posts)}\n"
            for post in posts[:3]:
                title = post.get('title', 'N/A')[:50]
                preview += f"   • {title}...\n"
            preview += "\n"
        
        if 'ticker_sentiment' in results:
            df = results['ticker_sentiment']
            if hasattr(df, 'to_string') and len(df) > 0:
                preview += f"📊 Ticker Sentiment:\n{df.to_string()}\n\n"
        
        if 'news' in results:
            news = results['news']
            preview += f"📰 News Articles: {len(news)}\n"
            for article in news[:3]:
                title = article.get('title', 'N/A')[:50]
                preview += f"   • {title}...\n"
            preview += "\n"
        
        if 'rss_news' in results:
            rss = results['rss_news']
            preview += f"📡 RSS Items: {len(rss)}\n"
        
        self.preview_text.insert("0.0", preview)
