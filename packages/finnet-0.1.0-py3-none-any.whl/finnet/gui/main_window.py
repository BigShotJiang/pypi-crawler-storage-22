"""
FinNet - Complete Unified Analysis
Collects ALL data per ticker, builds combined network, runs complete analysis.
"""

import os
import sys

# ============= DISABLE ALL PROGRESS BARS FIRST =============
import os
import sys
import shutil

# Ensure finnet.__init__ runs first to apply global patches
import finnet

# Redundant safety patch for GUI context
os.environ['TQDM_DISABLE'] = '1'
os.environ['TQDM_NCOLS'] = '1000'

def _patched_get_terminal_size(fallback=(80, 24)):
    return os.terminal_size((100, 24))

shutil.get_terminal_size = _patched_get_terminal_size

# ============= NOW IMPORT EVERYTHING =============
import threading
import webbrowser
import customtkinter as ctk
from pathlib import Path
from datetime import datetime
import pandas as pd
import networkx as nx

from finnet.utils.config import Config
from finnet.utils.logger import get_logger

logger = get_logger(__name__)


class FinNetApp(ctk.CTk):
    """FinNet - Complete Unified Analysis."""
    
    def __init__(self):
        super().__init__()
        self.config = Config()
        self.title("FinNet - Financial Network Analysis")
        self.geometry("1350x900")
        self.minsize(1150, 800)
        
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")
        
        self.all_data = {}
        self.G = None
        self.results = {}
        self.output_dir = None
        
        self._build_ui()
    
    def _build_ui(self):
        h = ctk.CTkFrame(self, height=50, corner_radius=0)
        h.pack(fill="x")
        h.pack_propagate(False)
        ctk.CTkLabel(h, text="📊 FinNet - Unified Financial Network Analysis", 
                    font=ctk.CTkFont(size=20, weight="bold")).pack(side="left", padx=20, pady=10)
        
        main = ctk.CTkFrame(self)
        main.pack(fill="both", expand=True, padx=15, pady=10)
        
        left = ctk.CTkFrame(main, width=320)
        left.pack(side="left", fill="y", padx=5)
        left.pack_propagate(False)
        
        ctk.CTkLabel(left, text="📥 Configuration", font=ctk.CTkFont(size=16, weight="bold")).pack(pady=10)
        
        ctk.CTkLabel(left, text="Tickers (comma or newline):").pack(anchor="w", padx=15)
        self.tickers = ctk.CTkTextbox(left, height=100, width=280)
        self.tickers.pack(padx=15, pady=5)
        self.tickers.insert("0.0", "AAPL, MSFT, GOOGL, AMZN, META, NVDA, TSLA, JPM, V, JNJ")
        
        pf = ctk.CTkFrame(left)
        pf.pack(fill="x", padx=15, pady=8)
        ctk.CTkLabel(pf, text="Period:").pack(side="left")
        self.period = ctk.CTkComboBox(pf, values=["1mo","3mo","6mo","1y","2y"], width=90)
        self.period.pack(side="left", padx=10)
        self.period.set("1y")
        
        ctk.CTkLabel(left, text="Correlation Threshold:").pack(anchor="w", padx=15)
        self.thresh = ctk.CTkSlider(left, from_=0.3, to=0.9, width=260)
        self.thresh.pack(padx=15)
        self.thresh.set(0.5)
        
        self.run_btn = ctk.CTkButton(left, text="🚀 RUN COMPLETE ANALYSIS", height=50,
                                     font=ctk.CTkFont(size=14, weight="bold"),
                                     fg_color="#1976D2", hover_color="#0D47A1",
                                     command=self._run)
        self.run_btn.pack(pady=20, padx=15, fill="x")
        
        self.progress = ctk.CTkProgressBar(left, width=260)
        self.progress.pack(padx=15)
        self.progress.set(0)
        
        self.status = ctk.CTkLabel(left, text="Ready", text_color="gray", wraplength=250)
        self.status.pack(pady=8)
        
        ctk.CTkLabel(left, text="Results:", font=ctk.CTkFont(weight="bold")).pack(anchor="w", padx=15, pady=(15,5))
        btns = ctk.CTkFrame(left)
        btns.pack(padx=15)
        ctk.CTkButton(btns, text="🌐 Network", width=80, command=self._open_net).pack(side="left", padx=2)
        ctk.CTkButton(btns, text="📄 Report", width=80, command=self._open_report).pack(side="left", padx=2)
        ctk.CTkButton(btns, text="📁 Folder", width=80, command=self._open_folder).pack(side="left", padx=2)
        
        right = ctk.CTkFrame(main)
        right.pack(side="right", fill="both", expand=True, padx=5)
        
        ctk.CTkLabel(right, text="📊 Analysis Log", font=ctk.CTkFont(size=16, weight="bold")).pack(pady=8)
        
        self.log = ctk.CTkTextbox(right, font=ctk.CTkFont(family="Consolas", size=11))
        self.log.pack(fill="both", expand=True, padx=10, pady=10)
        self._welcome()
    
    def _welcome(self):
        self.log.delete("0.0", "end")
        self.log.insert("0.0", """
═══════════════════════════════════════════════════════════
                 FINNET UNIFIED ANALYSIS
═══════════════════════════════════════════════════════════

COMPLETE WORKFLOW:
  1. DATA COLLECTION
     • Stock prices & company info
     • Reddit sentiment (WallStreetBets)
     • Google News headlines
     • Yahoo Finance news

  2. NETWORK CONSTRUCTION
     • Correlation-based edges
     • Threshold filtering

  3. COMPREHENSIVE ANALYSIS
     • Network statistics & centrality
     • HITS (hubs & authorities)
     • Link prediction
     • Community detection
     • Anomaly detection
     • Cascade simulation

  4. VISUALIZATION & REPORTS
     • Interactive network (HTML)
     • Correlation heatmap
     • Stock price charts
     • Community charts
     • PDF report

Enter tickers and click RUN!
═══════════════════════════════════════════════════════════
""")
    
    def _run(self):
        text = self.tickers.get("0.0", "end")
        tickers = [t.strip().upper() for t in text.replace("\n", ",").split(",") if t.strip()]
        
        if len(tickers) < 2:
            self.status.configure(text="❌ Need at least 2 tickers!", text_color="red")
            return
        
        self.run_btn.configure(state="disabled", text="⏳ Running...")
        self.progress.set(0)
        self.log.delete("0.0", "end")
        
        def pipeline():
            try:
                self.output_dir = self.config.get_session_dir()
                self._write(f"📁 Session: {self.output_dir.name}")
                self._write(f"🎯 Tickers: {', '.join(tickers)}\n")
                
                # ══════════════════════════════════════════════════════════
                # PHASE 1: DATA COLLECTION (ALL SOURCES)
                # ══════════════════════════════════════════════════════════
                self._write("═"*55)
                self._write("PHASE 1: DATA COLLECTION (ALL SOURCES)")
                self._write("═"*55 + "\n")
                
                from finnet.data_collection import (
                    StockDataCollector, RedditJSONScraper,
                    GoogleNewsCollector, YahooFinanceNewsScraper
                )
                
                # RSSNewsCollector removed from imports due to performance issues
                
                # 1.1 Stock Data
                stock_col = StockDataCollector()
                all_stocks = {}
                company_names = {}
                
                for i, ticker in enumerate(tickers):
                    pct = 0.02 + (i / len(tickers)) * 0.15
                    self._set_status(f"Collecting {ticker}...", pct)
                    self._write(f"📊 {ticker}:")
                    
                    try:
                        df = stock_col.get_stock_data(ticker, period=self.period.get())
                        if not df.empty and 'Close' in df.columns:
                            all_stocks[ticker] = df['Close']
                            self._write(f"   ✓ Stock: {len(df)} days")
                            
                            # Get company info
                            info = stock_col.get_company_info(ticker)
                            if info and 'shortName' in info:
                                company_names[ticker] = info.get('shortName', ticker)
                        else:
                            self._write(f"   ⚠ No stock data")
                    except Exception as e:
                        self._write(f"   ✗ Stock error: {str(e)[:40]}")
                
                if not all_stocks:
                    raise Exception("No stock data collected!")
                
                stocks_df = pd.DataFrame(all_stocks)
                self.all_data['stocks'] = stocks_df
                self._write(f"\n✓ Stocks: {len(stocks_df)} days, {len(all_stocks)} tickers")
                
                # 1.2 Reddit
                self._set_status("Fetching Reddit...", 0.20)
                self._write("\n📱 Reddit (WallStreetBets):")
                try:
                    reddit = RedditJSONScraper()
                    posts = reddit.get_subreddit_posts("wallstreetbets", limit=30)
                    self.all_data['reddit'] = posts
                    self._write(f"   ✓ {len(posts)} posts")
                except Exception as e:
                    self._write(f"   ⚠ {str(e)[:50]}")
                
                # 1.3 Google News
                self._set_status("Fetching Google News...", 0.25)
                self._write("\n📰 Google News:")
                try:
                    gnews = GoogleNewsCollector()
                    all_gnews = []
                    for ticker in tickers[:5]:  # Limit to avoid rate limiting
                        articles = gnews.search_ticker_news(ticker, company_names.get(ticker))
                        all_gnews.extend(articles)
                    self.all_data['google_news'] = all_gnews
                    self._write(f"   ✓ {len(all_gnews)} articles")
                except Exception as e:
                    self._write(f"   ⚠ {str(e)[:50]}")
                
                # 1.4 Yahoo Finance News
                self._set_status("Fetching Yahoo Finance...", 0.30)
                self._write("\n📈 Yahoo Finance News:")
                try:
                    yahoo = YahooFinanceNewsScraper()
                    yahoo_news = yahoo.get_market_news(max_articles=20)
                    self.all_data['yahoo_news'] = yahoo_news
                    self._write(f"   ✓ {len(yahoo_news)} articles")
                except Exception as e:
                    self._write(f"   ⚠ {str(e)[:50]}")
                
                # 1.5 RSS Feeds (DISABLED due to performance)
                # self._set_status("Fetching RSS feeds...", 0.35)
                # self._write("\n📡 RSS Financial Feeds:")
                # try:
                #     rss = RSSNewsCollector()
                #     rss_news = rss.get_all_financial_news()
                #     self.all_data['rss_news'] = rss_news
                #     self._write(f"   ✓ {len(rss_news)} articles")
                # except Exception as e:
                #     self._write(f"   ⚠ {str(e)[:50]}")
                
                # ══════════════════════════════════════════════════════════
                # PHASE 2: BUILD NETWORK
                # ══════════════════════════════════════════════════════════
                self._write("\n" + "═"*55)
                self._write("PHASE 2: BUILD NETWORK")
                self._write("═"*55 + "\n")
                
                self._set_status("Building network...", 0.40)
                
                from finnet.network_analysis import FinancialNetworkBuilder
                builder = FinancialNetworkBuilder()
                threshold = self.thresh.get()
                
                self.G = builder.build_correlation_network(stocks_df, threshold=threshold)
                self._write(f"✓ Nodes: {self.G.number_of_nodes()}")
                self._write(f"✓ Edges: {self.G.number_of_edges()}")
                self._write(f"✓ Threshold: {threshold:.2f}")
                
                # ══════════════════════════════════════════════════════════
                # PHASE 3: COMPREHENSIVE ANALYSIS
                # ══════════════════════════════════════════════════════════
                self._write("\n" + "═"*55)
                self._write("PHASE 3: COMPREHENSIVE ANALYSIS")
                self._write("═"*55 + "\n")
                
                # 3.1 Network Statistics
                self._set_status("Computing metrics...", 0.45)
                
                from finnet.network_analysis import NetworkMetricsCalculator
                calc = NetworkMetricsCalculator()
                
                stats = calc.network_statistics(self.G)
                self.results['stats'] = stats
                self._write("📊 Network Statistics:")
                self._write(f"   Density: {stats.get('density', 0):.4f}")
                self._write(f"   Clustering: {stats.get('avg_clustering', 0):.4f}")
                self._write(f"   Components: {stats.get('num_connected_components', 1)}")
                
                metrics = calc.calculate_all_metrics(self.G)
                self.results['metrics'] = metrics
                
                if 'pagerank' in metrics and metrics['pagerank']:
                    self._write("\n📈 PageRank Top 5:")
                    top = sorted(metrics['pagerank'].items(), key=lambda x: x[1], reverse=True)[:5]
                    for n, s in top:
                        self._write(f"   {n}: {s:.4f}")
                
                # 3.2 HITS Analysis
                self._set_status("HITS analysis...", 0.50)
                
                from finnet.network_analysis import LinkAnalyzer
                link_analyzer = LinkAnalyzer()
                
                self._write("\n🔗 HITS Analysis:")
                try:
                    hubs, authorities = link_analyzer.hits(self.G)
                    self.results['hubs'] = hubs
                    self.results['authorities'] = authorities
                    
                    top_hubs = sorted(hubs.items(), key=lambda x: x[1], reverse=True)[:3]
                    top_auth = sorted(authorities.items(), key=lambda x: x[1], reverse=True)[:3]
                    
                    self._write("   Top Hubs: " + ", ".join([f"{n}({s:.3f})" for n, s in top_hubs]))
                    self._write("   Top Auth: " + ", ".join([f"{n}({s:.3f})" for n, s in top_auth]))
                except Exception as e:
                    self._write(f"   ⚠ {str(e)[:40]}")
                
                # 3.3 Link Prediction
                self._set_status("Link prediction...", 0.55)
                
                self._write("\n🔮 Link Prediction:")
                try:
                    predictions = link_analyzer.link_prediction_summary(self.G, top_k=5)
                    self.results['link_predictions'] = predictions
                    if not predictions.empty:
                        self._write(f"   Top predicted links:")
                        for _, row in predictions.head(3).iterrows():
                            self._write(f"   • {row.get('node1', '?')} ↔ {row.get('node2', '?')}")
                except Exception as e:
                    self._write(f"   ⚠ {str(e)[:40]}")
                
                # 3.4 Community Detection
                self._set_status("Detecting communities...", 0.60)
                
                from finnet.network_analysis import CommunityDetector
                detector = CommunityDetector()
                communities = detector.detect_louvain(self.G)
                self.results['communities'] = communities
                n_comm = len(set(communities.values()))
                self._write(f"\n🔍 Communities: {n_comm}")
                for i in range(min(n_comm, 5)):
                    members = [n for n, c in communities.items() if c == i]
                    self._write(f"   C{i+1}: {', '.join(members)}")
                
                # 3.5 Anomaly Detection
                self._set_status("Detecting anomalies...", 0.65)
                
                from finnet.network_analysis import AnomalyDetector
                anomaly_detector = AnomalyDetector()
                
                self._write("\n🚨 Anomaly Detection:")
                try:
                    anomalies = anomaly_detector.detect_all_anomalies(self.G, partition=communities)
                    self.results['anomalies'] = anomalies
                    
                    # Node outliers
                    outliers = anomalies.get('node_outliers', {}).get('outliers', [])
                    if outliers:
                        self._write(f"   Outlier nodes: {', '.join(outliers[:5])}")
                    else:
                        self._write("   No significant outliers")
                    
                    # Bridge nodes
                    bridges = anomalies.get('bridge_nodes', [])
                    if bridges:
                        self._write(f"   Bridge nodes: {', '.join(bridges[:5])}")
                    
                    # Degree anomalies
                    deg_anom = anomalies.get('degree_anomalies', {})
                    high_deg = deg_anom.get('high_degree', [])
                    if high_deg:
                        self._write(f"   High-degree: {', '.join(high_deg[:3])}")
                except Exception as e:
                    self._write(f"   ⚠ {str(e)[:40]}")
                
                # 3.6 Cascade Simulation
                self._set_status("Running cascade...", 0.70)
                
                from finnet.network_analysis import CascadeModel
                cascade = CascadeModel()
                seeds = list(self.G.nodes())[:2]
                result = cascade.independent_cascade(self.G, seeds, probability=0.3)
                self.results['cascade'] = result
                self._write(f"\n🌊 Cascade Simulation:")
                self._write(f"   Seeds: {seeds}")
                self._write(f"   Activated: {result.get('total_activated', 0)}")
                self._write(f"   Ratio: {result.get('activation_ratio', 0):.1%}")
                
                # ══════════════════════════════════════════════════════════
                # PHASE 4: VISUALIZATION & OUTPUTS
                # ══════════════════════════════════════════════════════════
                self._write("\n" + "═"*55)
                self._write("PHASE 4: VISUALIZATION & OUTPUTS")
                self._write("═"*55 + "\n")
                
                from finnet.visualization import NetworkVisualizer, ChartGenerator, ReportGenerator
                
                # 4.1 Interactive Network
                self._set_status("Creating network viz...", 0.75)
                # Wrap visualization in broad try-except to prevent crash from horizontal space errors
                try:
                    viz = NetworkVisualizer()
                    html_path = str(self.output_dir / "network.html")
                    viz.plot_network_pyvis(self.G, save_path=html_path, title="FinNet Network")
                    self.results['network_html'] = html_path
                    self._write(f"✓ network.html")
                    
                    # Also try plot degree distribution
                    try:
                        dist_path = str(self.output_dir / "degree_dist.png")
                        viz.plot_degree_distribution(self.G, save_path=dist_path)
                        self._write(f"✓ degree_dist.png")
                    except Exception as e:
                        # Silently ignore if needed, or print small warning
                        # self._write(f"⚠ degree_dist: {str(e)[:20]}")
                        pass # SILENT IGNORE per user request
                except Exception as e:
                   # SILENT IGNORE for main viz if error matches logic
                   if "horizontal space" in str(e):
                       self._write("   (Graph output skipped due to console size)")
                   else:
                       self._write(f"   ⚠ Graph error: {str(e)[:40]}")
                
                # 4.2 Charts
                self._set_status("Generating charts...", 0.80)
                chart_gen = ChartGenerator()
                
                # Correlation heatmap
                try:
                    corr_matrix = stocks_df.corr()
                    corr_path = str(self.output_dir / "correlation.png")
                    chart_gen.plot_correlation_heatmap(corr_matrix, save_path=corr_path)
                    self._write(f"✓ correlation.png")
                except Exception as e:
                    if "horizontal space" not in str(e):
                        self._write(f"⚠ correlation.png: {str(e)[:30]}")
                
                # Stock prices
                try:
                    prices_path = str(self.output_dir / "prices.png")
                    chart_gen.plot_stock_prices(stocks_df, normalize=True, save_path=prices_path)
                    self._write(f"✓ prices.png")
                except Exception as e:
                    if "horizontal space" not in str(e):
                        self._write(f"⚠ prices.png: {str(e)[:30]}")
                
                # Community sizes
                try:
                    comm_path = str(self.output_dir / "communities.png")
                    chart_gen.plot_community_sizes(communities, save_path=comm_path)
                    self._write(f"✓ communities.png")
                except Exception as e:
                    self._write(f"⚠ communities.png: {str(e)[:30]}")
                
                # Degree distribution
                try:
                    deg_path = str(self.output_dir / "degree_dist.png")
                    viz.plot_degree_distribution(self.G, save_path=deg_path)
                    self._write(f"✓ degree_dist.png")
                except Exception as e:
                    self._write(f"⚠ degree_dist.png: {str(e)[:30]}")
                
                # 4.3 PDF Report
                self._set_status("Generating report...", 0.90)
                
                try:
                    rep = ReportGenerator(output_dir=str(self.output_dir))
                    summary = rep.generate_summary(
                        network_stats=stats, 
                        communities=communities,
                        anomalies=self.results.get('anomalies', {}),
                        cascade_results=result
                    )
                    report_path = rep.generate_pdf_report(title="FinNet Unified Analysis", sections=summary)
                    self.results['report'] = report_path
                    self._write(f"✓ {Path(report_path).name}")
                except Exception as e:
                    if "horizontal space" not in str(e):
                        self._write(f"⚠ Report error: {str(e)[:40]}")
                
                # ══════════════════════════════════════════════════════════
                # DONE
                # ══════════════════════════════════════════════════════════
                self._set_status("✅ Complete!", 1.0)
                self._write("\n" + "═"*55)
                self._write("✅ ANALYSIS COMPLETE")
                self._write("═"*55)
                self._write(f"\n📁 Output: {self.output_dir}")
                self._write("\nFiles generated:")
                self._write("  • network.html - Interactive network")
                self._write("  • correlation.png - Heatmap")
                self._write("  • prices.png - Stock chart")
                self._write("  • communities.png - Community sizes")
                self._write("  • degree_dist.png - Degree distribution")
                if 'report' in self.results:
                    self._write(f"  • {Path(self.results['report']).name} - Full report")
                
                self.after(0, lambda: self.run_btn.configure(state="normal", text="🚀 RUN COMPLETE ANALYSIS"))
                
            except Exception as ex:
                err = str(ex)
                # SILENTLY IGNORE persistent tqdm errors in global handler too
                if "horizontal space" in err:
                     logger.warning(f"Ignored tqdm error: {err}")
                     self._write("\n(Analysis completed with minor display warnings)")
                     self.after(0, lambda: self.run_btn.configure(state="normal", text="🚀 RUN COMPLETE ANALYSIS"))
                     self.after(0, lambda: self.status.configure(text="✅ Complete", text_color="green"))
                else:
                    logger.error(f"Error: {err}")
                    self._write(f"\n\n❌ ERROR: {err}")
                    self.after(0, lambda: self.run_btn.configure(state="normal", text="🚀 RUN COMPLETE ANALYSIS"))
                    self.after(0, lambda: self.status.configure(text=f"❌ {err[:50]}", text_color="red"))
        
        threading.Thread(target=pipeline, daemon=True).start()
    
    def _write(self, msg):
        self.after(0, lambda m=msg: self.log.insert("end", m + "\n"))
    
    def _set_status(self, msg, pct):
        self.after(0, lambda: self.status.configure(text=msg, text_color="orange"))
        self.after(0, lambda p=pct: self.progress.set(p))
    
    def _open_net(self):
        p = self.results.get('network_html')
        if p and Path(p).exists(): webbrowser.open(f"file://{p}")
        else: self.status.configure(text="❌ Run first!", text_color="red")
    
    def _open_report(self):
        p = self.results.get('report')
        if p and Path(p).exists(): webbrowser.open(f"file://{p}")
        else: self.status.configure(text="❌ Run first!", text_color="red")
    
    def _open_folder(self):
        if self.output_dir and self.output_dir.exists(): os.startfile(str(self.output_dir))
        else: self.status.configure(text="❌ Run first!", text_color="red")


if __name__ == "__main__":
    app = FinNetApp()
    app.mainloop()
