"""Network Analysis Panel - GUI panel for network construction."""

import threading
import customtkinter as ctk
from finnet.utils.logger import get_logger

logger = get_logger(__name__)


class NetworkAnalysisPanel(ctk.CTkFrame):
    """Network analysis panel for building and visualizing networks."""
    
    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app
        self.current_network = None
        self._create_ui()
    
    def _create_ui(self):
        """Create panel UI."""
        # Controls
        self.controls = ctk.CTkFrame(self, width=350)
        self.controls.pack(side="left", fill="y", padx=10, pady=10)
        
        ctk.CTkLabel(self.controls, text="🕸️ Network Analysis",
                    font=ctk.CTkFont(size=18, weight="bold")).pack(pady=15)
        
        # Network type
        ctk.CTkLabel(self.controls, text="Network Type:").pack(anchor="w", padx=10)
        self.network_type = ctk.CTkComboBox(self.controls, width=280,
            values=["Correlation Network", "Sentiment Network", "Sector Network"])
        self.network_type.pack(padx=10, pady=5)
        self.network_type.set("Correlation Network")
        
        # Threshold
        ctk.CTkLabel(self.controls, text="Threshold:").pack(anchor="w", padx=10, pady=(15,0))
        self.threshold = ctk.CTkSlider(self.controls, from_=0.1, to=0.9)
        self.threshold.pack(padx=10, pady=5)
        self.threshold.set(0.5)
        
        # Build button
        ctk.CTkButton(self.controls, text="🔨 Build Network", width=200,
                     command=self._build_network).pack(pady=20)
        
        # Stats
        self.stats_text = ctk.CTkTextbox(self.controls, height=200, width=280)
        self.stats_text.pack(padx=10, pady=10)
        self.stats_text.insert("0.0", "Build a network to see stats...")
        
        # Viz options
        self.viz_type = ctk.CTkComboBox(self.controls, width=200,
            values=["2D Interactive", "Static", "3D Network", "PyVis HTML"])
        self.viz_type.pack(pady=10)
        
        ctk.CTkButton(self.controls, text="👁️ Visualize",
                     command=self._visualize).pack(pady=5)
        
        # Viz area
        self.viz_frame = ctk.CTkFrame(self)
        self.viz_frame.pack(side="right", fill="both", expand=True, padx=10, pady=10)
        ctk.CTkLabel(self.viz_frame, text="Network Visualization",
                    font=ctk.CTkFont(size=16, weight="bold")).pack(pady=10)
    
    def _build_network(self):
        """Build network from collected data."""
        if not self.app.collected_data:
            self.stats_text.delete("0.0", "end")
            self.stats_text.insert("0.0", "❌ Collect data first!")
            return
        
        def build():
            try:
                from finnet.network_analysis import FinancialNetworkBuilder, NetworkMetricsCalculator
                builder = FinancialNetworkBuilder()
                
                stock_data = self.app.collected_data.get('stocks')
                if stock_data is None:
                    raise ValueError("No stock data")
                
                G = builder.build_correlation_network(stock_data, threshold=self.threshold.get())
                self.current_network = G
                self.app.networks['current'] = G
                
                metrics = NetworkMetricsCalculator()
                stats = metrics.network_statistics(G)
                self.app.analysis_results['network_stats'] = stats
                
                stats_str = f"Nodes: {stats['num_nodes']}\nEdges: {stats['num_edges']}\n"
                stats_str += f"Density: {stats['density']:.4f}\nClustering: {stats['avg_clustering']:.4f}"
                
                self.after(0, lambda: self._update_stats(stats_str))
            except Exception as e:
                self.after(0, lambda: self._update_stats(f"Error: {e}"))
        
        threading.Thread(target=build, daemon=True).start()
    
    def _update_stats(self, text):
        self.stats_text.delete("0.0", "end")
        self.stats_text.insert("0.0", text)
    
    def _visualize(self):
        """Create network visualization."""
        if not self.current_network:
            return
        
        def viz():
            try:
                from finnet.visualization import NetworkVisualizer
                v = NetworkVisualizer()
                path = str(self.app.config.get_session_dir() / "network.html")
                v.plot_network_pyvis(self.current_network, save_path=path)
                self.after(0, lambda: self.app.set_status(f"Saved: {path}", 1.0))
            except Exception as e:
                self.after(0, lambda: self.app.set_status(f"Error: {e}", 0))
        
        threading.Thread(target=viz, daemon=True).start()
