"""GUI Tabs Package - 9 tabs for FinNet application."""

from finnet.gui.tabs.dashboard_tab import DashboardTab
from finnet.gui.tabs.input_tab import InputTab
from finnet.gui.tabs.network_tab import NetworkTab
from finnet.gui.tabs.analytics_tab import AnalyticsTab
from finnet.gui.tabs.cascade_tab import CascadeTab
from finnet.gui.tabs.sentiment_tab import SentimentTab
from finnet.gui.tabs.news_tab import NewsTab
from finnet.gui.tabs.reports_tab import ReportsTab
from finnet.gui.tabs.settings_tab import SettingsTab

__all__ = [
    "DashboardTab", "InputTab", "NetworkTab", "AnalyticsTab",
    "CascadeTab", "SentimentTab", "NewsTab", "ReportsTab", "SettingsTab"
]
