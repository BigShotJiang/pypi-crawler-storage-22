"""Analytics Tab - Network metrics and community analysis."""
import threading
import customtkinter as ctk
from finnet.utils.logger import get_logger
logger = get_logger(__name__)


class AnalyticsTab(ctk.CTkFrame):
    """Tab 4: Analytics and metrics."""
    
    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app
        self._create_ui()
    
    def _create_ui(self):
        # Controls
        controls = ctk.CTkFrame(self, width=300)
        controls.pack(side="left", fill="y", padx=10, pady=10)
        controls.pack_propagate(False)
        
        ctk.CTkLabel(controls, text="📊 Analytics", font=ctk.CTkFont(size=16, weight="bold")).pack(pady=15)
        
        # Analysis type
        ctk.CTkLabel(controls, text="Analysis:").pack(anchor="w", padx=10)
        self.analysis = ctk.CTkComboBox(controls, values=[
            "Centrality Metrics", "Community Detection", "Link Prediction",
            "Anomaly Detection", "Node Embeddings"
        ], width=220)
        self.analysis.pack(padx=10, pady=5)
        self.analysis.set("Centrality Metrics")
        
        # Algorithm
        ctk.CTkLabel(controls, text="Algorithm:").pack(anchor="w", padx=10, pady=(10,0))
        self.algo = ctk.CTkComboBox(controls, values=["Auto", "Louvain", "Label Prop", "PageRank", "Node2Vec"], width=180)
        self.algo.pack(padx=10, pady=5)
        
        ctk.CTkButton(controls, text="▶️ Run Analysis", command=self._run).pack(pady=20)
        
        # Results
        self.results = ctk.CTkTextbox(controls, height=300, width=260)
        self.results.pack(padx=10, pady=10)
        self.results.insert("0.0", "Run analysis to see results...")
        
        # Right area
        right = ctk.CTkFrame(self)
        right.pack(side="right", fill="both", expand=True, padx=10, pady=10)
        ctk.CTkLabel(right, text="Charts & Visualization", font=ctk.CTkFont(weight="bold")).pack(pady=10)
        
        # Chart buttons
        btns = ctk.CTkFrame(right)
        btns.pack(pady=10)
        ctk.CTkButton(btns, text="📊 Centrality Chart", command=lambda: self._chart("centrality")).pack(side="left", padx=5)
        ctk.CTkButton(btns, text="🥧 Communities", command=lambda: self._chart("community")).pack(side="left", padx=5)
        ctk.CTkButton(btns, text="📈 Degree Dist", command=lambda: self._chart("degree")).pack(side="left", padx=5)
    
    def _run(self):
        if 'current' not in self.app.networks:
            self.results.delete("0.0", "end")
            self.results.insert("0.0", "❌ Build a network first!")
            return
        
        def run():
            try:
                G = self.app.networks['current']
                analysis = self.analysis.get()
                txt = f"🔬 {analysis}\n{'='*25}\n\n"
                
                if "Centrality" in analysis:
                    from finnet.network_analysis import NetworkMetricsCalculator
                    calc = NetworkMetricsCalculator()
                    metrics = calc.calculate_all_metrics(G)
                    top = calc.get_top_nodes(metrics['pagerank'], 5)
                    txt += "Top by PageRank:\n"
                    for n, s in top:
                        txt += f"  {n}: {s:.4f}\n"
                    self.app.analysis_results['centrality'] = metrics
                
                elif "Community" in analysis:
                    from finnet.network_analysis import CommunityDetector
                    det = CommunityDetector()
                    partition = det.detect_louvain(G)
                    n_comm = len(set(partition.values()))
                    mod = det.calculate_modularity(G, partition)
                    txt += f"Communities: {n_comm}\nModularity: {mod:.4f}\n"
                    self.app.analysis_results['communities'] = partition
                
                elif "Node Embeddings" in analysis:
                    from finnet.machine_learning import Node2VecEmbed
                    n2v = Node2VecEmbed(dimensions=32, walk_length=30, num_walks=5)
                    n2v.fit(G)
                    emb, nodes = n2v.get_all_embeddings()
                    txt += f"Embeddings: {emb.shape}\nNodes: {nodes[:5]}..."
                
                self.after(0, lambda: self._update(txt))
            except Exception as e:
                self.after(0, lambda: self._update(f"❌ Error: {e}"))
        
        threading.Thread(target=run, daemon=True).start()
    
    def _update(self, txt):
        self.results.delete("0.0", "end")
        self.results.insert("0.0", txt)
    
    def _chart(self, chart_type):
        try:
            from finnet.visualization import ChartGenerator
            gen = ChartGenerator()
            path = str(self.app.config.get_session_dir() / f"{chart_type}.png")
            
            if chart_type == "centrality" and 'centrality' in self.app.analysis_results:
                gen.plot_centrality_comparison(self.app.analysis_results['centrality'], save_path=path)
            elif chart_type == "community" and 'communities' in self.app.analysis_results:
                gen.plot_community_sizes(self.app.analysis_results['communities'], save_path=path)
            elif chart_type == "degree" and 'current' in self.app.networks:
                from finnet.visualization import NetworkVisualizer
                viz = NetworkVisualizer()
                viz.plot_degree_distribution(self.app.networks['current'], save_path=path)
            
            self.app.set_status(f"Chart saved: {path}", 1.0)
        except Exception as e:
            self.app.set_status(f"Error: {e}", 0)
