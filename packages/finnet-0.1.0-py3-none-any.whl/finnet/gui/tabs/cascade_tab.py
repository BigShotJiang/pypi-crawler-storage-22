"""Cascade Tab - Cascade and epidemic simulation."""
import threading
import customtkinter as ctk
from finnet.utils.logger import get_logger
logger = get_logger(__name__)


class CascadeTab(ctk.CTkFrame):
    """Tab 5: Cascade/epidemic simulation."""
    
    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app
        self._create_ui()
    
    def _create_ui(self):
        controls = ctk.CTkFrame(self, width=300)
        controls.pack(side="left", fill="y", padx=10, pady=10)
        controls.pack_propagate(False)
        
        ctk.CTkLabel(controls, text="🌊 Cascade Simulation", font=ctk.CTkFont(size=16, weight="bold")).pack(pady=15)
        
        # Model selection
        ctk.CTkLabel(controls, text="Model:").pack(anchor="w", padx=10)
        self.model = ctk.CTkComboBox(controls, values=["Independent Cascade", "Linear Threshold", "SIR", "SIS"], width=200)
        self.model.pack(padx=10, pady=5)
        self.model.set("Independent Cascade")
        
        # Parameters
        ctk.CTkLabel(controls, text="Propagation Prob:").pack(anchor="w", padx=10, pady=(15,0))
        self.prob = ctk.CTkSlider(controls, from_=0.1, to=0.9)
        self.prob.pack(padx=10, pady=5)
        self.prob.set(0.3)
        
        ctk.CTkLabel(controls, text="Max Steps:").pack(anchor="w", padx=10, pady=(10,0))
        self.steps = ctk.CTkEntry(controls, width=100, placeholder_text="50")
        self.steps.pack(padx=10, pady=5)
        self.steps.insert(0, "50")
        
        # Seed nodes
        ctk.CTkLabel(controls, text="Seed Nodes (comma-sep):").pack(anchor="w", padx=10, pady=(10,0))
        self.seeds = ctk.CTkEntry(controls, width=200, placeholder_text="AAPL, MSFT")
        self.seeds.pack(padx=10, pady=5)
        
        ctk.CTkButton(controls, text="▶️ Run Simulation", command=self._run).pack(pady=20)
        
        # Results
        self.results = ctk.CTkTextbox(controls, height=200, width=260)
        self.results.pack(padx=10, pady=10)
        self.results.insert("0.0", "Simulation results will appear here...")
        
        # Right area
        right = ctk.CTkFrame(self)
        right.pack(side="right", fill="both", expand=True, padx=10, pady=10)
        ctk.CTkLabel(right, text="Cascade Timeline", font=ctk.CTkFont(weight="bold")).pack(pady=10)
        ctk.CTkButton(right, text="📊 Plot Timeline", command=self._plot).pack(pady=10)
    
    def _run(self):
        if 'current' not in self.app.networks:
            self.results.delete("0.0", "end")
            self.results.insert("0.0", "❌ Build a network first!")
            return
        
        def run():
            try:
                from finnet.network_analysis import CascadeModel
                G = self.app.networks['current']
                model = CascadeModel()
                
                seeds = [s.strip() for s in self.seeds.get().split(",") if s.strip()]
                if not seeds:
                    seeds = list(G.nodes())[:2]
                
                model_type = self.model.get()
                if "SIR" in model_type:
                    result = model.simulate_sir(G, seeds, beta=self.prob.get(), gamma=0.1, max_steps=int(self.steps.get()))
                elif "SIS" in model_type:
                    result = model.simulate_sis(G, seeds, beta=self.prob.get(), mu=0.15, max_steps=int(self.steps.get()))
                elif "Linear" in model_type:
                    result = model.simulate_linear_threshold(G, seeds, max_steps=int(self.steps.get()))
                else:
                    result = model.simulate_independent_cascade(G, seeds, p=self.prob.get())
                
                self.app.analysis_results['cascade'] = result
                txt = f"✅ Simulation Complete\n{'='*25}\nModel: {model_type}\nSeeds: {seeds}\n"
                txt += f"Final active: {result.get('final_active', result.get('total_infected', 'N/A'))}"
                self.after(0, lambda: self._update(txt))
            except Exception as e:
                self.after(0, lambda: self._update(f"❌ Error: {e}"))
        
        threading.Thread(target=run, daemon=True).start()
    
    def _update(self, txt):
        self.results.delete("0.0", "end")
        self.results.insert("0.0", txt)
    
    def _plot(self):
        if 'cascade' not in self.app.analysis_results:
            return
        try:
            from finnet.visualization import ChartGenerator
            gen = ChartGenerator()
            result = self.app.analysis_results['cascade']
            if 'history' in result:
                path = str(self.app.config.get_session_dir() / "cascade_timeline.png")
                gen.plot_cascade_timeline(result['history'], save_path=path)
                self.app.set_status(f"Chart: {path}", 1.0)
        except Exception as e:
            self.app.set_status(f"Error: {e}", 0)
