"""Dashboard Tab - Overview with KPIs and metrics cards."""
import customtkinter as ctk
from finnet.utils.logger import get_logger
logger = get_logger(__name__)


class DashboardTab(ctk.CTkFrame):
    """Tab 1: Overview dashboard with KPIs."""
    
    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app
        self._create_ui()
    
    def _create_ui(self):
        # Header
        ctk.CTkLabel(self, text="📊 Dashboard", font=ctk.CTkFont(size=24, weight="bold")).pack(pady=20)
        
        # Metrics grid
        metrics_frame = ctk.CTkFrame(self)
        metrics_frame.pack(fill="x", padx=20, pady=10)
        
        # Create metric cards
        self.cards = {}
        metrics = [
            ("Tickers", "0", "#2196F3"), ("Network Nodes", "0", "#4CAF50"),
            ("Edges", "0", "#FF9800"), ("Communities", "0", "#9C27B0"),
            ("Avg Sentiment", "N/A", "#E91E63"), ("Data Points", "0", "#00BCD4")
        ]
        
        for i, (label, value, color) in enumerate(metrics):
            card = self._create_metric_card(metrics_frame, label, value, color)
            card.grid(row=i//3, column=i%3, padx=10, pady=10, sticky="nsew")
            self.cards[label] = card
        
        for i in range(3):
            metrics_frame.columnconfigure(i, weight=1)
        
        # Quick actions
        actions_frame = ctk.CTkFrame(self)
        actions_frame.pack(fill="x", padx=20, pady=20)
        ctk.CTkLabel(actions_frame, text="Quick Actions", font=ctk.CTkFont(weight="bold")).pack(pady=10)
        
        btns = ctk.CTkFrame(actions_frame)
        btns.pack(pady=10)
        ctk.CTkButton(btns, text="📥 Collect Data", command=self._go_input).pack(side="left", padx=5)
        ctk.CTkButton(btns, text="🕸️ Build Network", command=self._go_network).pack(side="left", padx=5)
        ctk.CTkButton(btns, text="📈 Run Analysis", command=self._go_analytics).pack(side="left", padx=5)
        
        # Status
        self.status = ctk.CTkLabel(self, text="Ready - Collect data to begin", text_color="gray")
        self.status.pack(pady=20)
    
    def _create_metric_card(self, parent, label, value, color):
        card = ctk.CTkFrame(parent, corner_radius=10)
        ctk.CTkLabel(card, text=value, font=ctk.CTkFont(size=28, weight="bold"), text_color=color).pack(pady=(15, 5))
        ctk.CTkLabel(card, text=label, font=ctk.CTkFont(size=12)).pack(pady=(0, 15))
        return card
    
    def _go_input(self):
        self.app.tabview.set("📥 Data Input")
    def _go_network(self):
        self.app.tabview.set("🕸️ Network")
    def _go_analytics(self):
        self.app.tabview.set("📈 Analytics")
    
    def refresh(self):
        """Refresh dashboard metrics."""
        if hasattr(self.app, 'collected_data') and self.app.collected_data:
            stocks = self.app.collected_data.get('stocks')
            if stocks is not None:
                self.cards["Tickers"].winfo_children()[0].configure(text=str(len(stocks.columns)))
