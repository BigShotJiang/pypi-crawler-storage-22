"""Input Tab - Data collection controls."""
import threading
import customtkinter as ctk
from finnet.utils.logger import get_logger
logger = get_logger(__name__)


class InputTab(ctk.CTkFrame):
    """Tab 2: Data input and collection controls."""
    
    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app
        self._create_ui()
    
    def _create_ui(self):
        # Title
        ctk.CTkLabel(self, text="📥 Data Input", font=ctk.CTkFont(size=20, weight="bold")).pack(pady=15)
        
        # Ticker input section
        input_frame = ctk.CTkFrame(self)
        input_frame.pack(fill="x", padx=20, pady=10)
        
        ctk.CTkLabel(input_frame, text="Stock Tickers (comma-separated):").pack(anchor="w", padx=10, pady=5)
        self.ticker_entry = ctk.CTkEntry(input_frame, width=500, placeholder_text="AAPL, MSFT, GOOGL, AMZN, META")
        self.ticker_entry.pack(padx=10, pady=5)
        self.ticker_entry.insert(0, "AAPL, MSFT, GOOGL, AMZN, META")
        
        # Period selection
        period_frame = ctk.CTkFrame(input_frame)
        period_frame.pack(fill="x", padx=10, pady=10)
        ctk.CTkLabel(period_frame, text="Period:").pack(side="left", padx=5)
        self.period = ctk.CTkComboBox(period_frame, values=["1mo", "3mo", "6mo", "1y", "2y", "5y"], width=100)
        self.period.pack(side="left", padx=5)
        self.period.set("1y")
        
        # Data sources
        sources_frame = ctk.CTkFrame(self)
        sources_frame.pack(fill="x", padx=20, pady=10)
        ctk.CTkLabel(sources_frame, text="Data Sources:", font=ctk.CTkFont(weight="bold")).pack(anchor="w", padx=10, pady=5)
        
        self.src_stocks = ctk.CTkCheckBox(sources_frame, text="📈 Stock Prices (yFinance) - Required")
        self.src_stocks.pack(anchor="w", padx=20, pady=2)
        self.src_stocks.select()
        
        self.src_reddit = ctk.CTkCheckBox(sources_frame, text="💬 Reddit (WSB, stocks, investing)")
        self.src_reddit.pack(anchor="w", padx=20, pady=2)
        self.src_reddit.select()
        
        self.src_news = ctk.CTkCheckBox(sources_frame, text="📰 Financial News (Google News)")
        self.src_news.pack(anchor="w", padx=20, pady=2)
        
        self.src_rss = ctk.CTkCheckBox(sources_frame, text="📡 RSS Feeds (CNBC, Reuters, MarketWatch)")
        self.src_rss.pack(anchor="w", padx=20, pady=2)
        
        # Collect button
        self.collect_btn = ctk.CTkButton(self, text="🔄 Start Collection", width=200, height=40, 
                                         fg_color="#2196F3", command=self._collect)
        self.collect_btn.pack(pady=20)
        
        # Progress
        self.progress = ctk.CTkProgressBar(self, width=500)
        self.progress.pack(pady=10)
        self.progress.set(0)
        
        self.status = ctk.CTkLabel(self, text="Ready to collect data", text_color="gray", font=ctk.CTkFont(size=12))
        self.status.pack(pady=5)
        
        # Results frame
        self.results_frame = ctk.CTkFrame(self)
        self.results_frame.pack(fill="x", padx=20, pady=10)
        ctk.CTkLabel(self.results_frame, text="📊 Collection Results", font=ctk.CTkFont(weight="bold")).pack(pady=5)
        
        self.result_labels = {}
        for item in ["Stocks", "Reddit Posts", "News Articles", "RSS Items"]:
            f = ctk.CTkFrame(self.results_frame)
            f.pack(fill="x", padx=10, pady=2)
            ctk.CTkLabel(f, text=f"{item}:", width=120, anchor="w").pack(side="left")
            lbl = ctk.CTkLabel(f, text="Not collected", text_color="gray", width=150, anchor="w")
            lbl.pack(side="left")
            self.result_labels[item] = lbl
    
    def _collect(self):
        tickers = [t.strip().upper() for t in self.ticker_entry.get().split(",") if t.strip()]
        if not tickers:
            self.status.configure(text="❌ Enter at least one ticker", text_color="red")
            return
        
        self.collect_btn.configure(state="disabled", text="⏳ Collecting...")
        self.status.configure(text=f"Collecting data for {len(tickers)} tickers...", text_color="orange")
        self.progress.set(0.05)
        
        def collect():
            try:
                results = {}
                total_steps = sum([self.src_stocks.get(), self.src_reddit.get(), self.src_news.get(), self.src_rss.get()])
                step = 0
                
                # Stock data
                if self.src_stocks.get():
                    self.after(0, lambda: self.status.configure(text="📈 Downloading stock data..."))
                    from finnet.data_collection import StockDataCollector
                    c = StockDataCollector()
                    results['stocks'] = c.get_multiple_stocks(tickers, period=self.period.get())
                    results['company_info'] = {}
                    for t in tickers[:5]:
                        try:
                            results['company_info'][t] = c.get_company_info(t)
                        except:
                            pass
                    step += 1
                    self.after(0, lambda s=step, ts=total_steps: self.progress.set(s/ts))
                    self.after(0, lambda: self.result_labels["Stocks"].configure(text=f"✅ {len(tickers)} tickers, {len(results['stocks'])} rows", text_color="green"))
                
                # Reddit
                if self.src_reddit.get():
                    self.after(0, lambda: self.status.configure(text="💬 Fetching Reddit posts..."))
                    from finnet.data_collection import RedditJSONScraper
                    r = RedditJSONScraper()
                    all_posts = []
                    for sub in ["wallstreetbets", "stocks"]:
                        try:
                            posts = r.get_subreddit_posts(sub, limit=30)
                            all_posts.extend(posts)
                        except Exception as e:
                            logger.warning(f"Reddit {sub} error: {e}")
                    results['reddit_posts'] = all_posts
                    step += 1
                    self.after(0, lambda s=step, ts=total_steps: self.progress.set(s/ts))
                    self.after(0, lambda: self.result_labels["Reddit Posts"].configure(text=f"✅ {len(all_posts)} posts", text_color="green"))
                
                # News
                if self.src_news.get():
                    self.after(0, lambda: self.status.configure(text="📰 Fetching news articles..."))
                    from finnet.data_collection import GoogleNewsCollector
                    n = GoogleNewsCollector()
                    all_news = []
                    for t in tickers[:3]:
                        try:
                            news = n.search_ticker_news(t)
                            if news:
                                all_news.extend(news[:5])
                        except Exception as e:
                            logger.warning(f"News error for {t}: {e}")
                    results['news'] = all_news
                    step += 1
                    self.after(0, lambda s=step, ts=total_steps: self.progress.set(s/ts))
                    self.after(0, lambda: self.result_labels["News Articles"].configure(text=f"✅ {len(all_news)} articles", text_color="green"))
                
                # RSS
                if self.src_rss.get():
                    self.after(0, lambda: self.status.configure(text="📡 Fetching RSS feeds..."))
                    from finnet.data_collection import RSSNewsCollector
                    rss = RSSNewsCollector()
                    all_rss = []
                    for feed in ["cnbc", "reuters"]:
                        try:
                            items = rss.get_feed(feed)
                            if items:
                                all_rss.extend(items[:10])
                        except Exception as e:
                            logger.warning(f"RSS {feed} error: {e}")
                    results['rss_news'] = all_rss
                    step += 1
                    self.after(0, lambda s=step, ts=total_steps: self.progress.set(s/ts))
                    self.after(0, lambda: self.result_labels["RSS Items"].configure(text=f"✅ {len(all_rss)} items", text_color="green"))
                
                self.app.collected_data = results
                self.after(0, lambda: self._done(f"✅ Data collection complete! {len(tickers)} tickers processed."))
            except Exception as e:
                logger.error(f"Collection error: {e}")
                self.after(0, lambda: self._done(f"❌ Error: {e}", error=True))
        
        threading.Thread(target=collect, daemon=True).start()
    
    def _done(self, msg, error=False):
        self.status.configure(text=msg, text_color="red" if error else "green")
        self.progress.set(1.0)
        self.collect_btn.configure(state="normal", text="🔄 Start Collection")
        self.app.set_status(msg, 1.0 if not error else 0)
