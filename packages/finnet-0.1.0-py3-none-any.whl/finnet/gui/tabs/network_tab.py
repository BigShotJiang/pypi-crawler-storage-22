"""Network Tab - Network visualization and controls."""
import threading
import webbrowser
import customtkinter as ctk
from pathlib import Path
from finnet.utils.logger import get_logger
logger = get_logger(__name__)


class NetworkTab(ctk.CTkFrame):
    """Tab 3: Network visualization."""
    
    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app
        self.network = None
        self._create_ui()
    
    def _create_ui(self):
        # Left controls
        controls = ctk.CTkFrame(self, width=300)
        controls.pack(side="left", fill="y", padx=10, pady=10)
        controls.pack_propagate(False)
        
        ctk.CTkLabel(controls, text="🕸️ Network Builder", font=ctk.CTkFont(size=16, weight="bold")).pack(pady=15)
        
        # Network type
        ctk.CTkLabel(controls, text="Network Type:").pack(anchor="w", padx=10)
        self.net_type = ctk.CTkComboBox(controls, values=["Correlation", "Sentiment", "Sector", "Co-mention"], width=200)
        self.net_type.pack(padx=10, pady=5)
        self.net_type.set("Correlation")
        
        # Threshold
        ctk.CTkLabel(controls, text="Edge Threshold:").pack(anchor="w", padx=10, pady=(15, 0))
        self.threshold = ctk.CTkSlider(controls, from_=0.1, to=0.9, number_of_steps=8)
        self.threshold.pack(padx=10, pady=5)
        self.threshold.set(0.5)
        self.thresh_label = ctk.CTkLabel(controls, text="0.50")
        self.thresh_label.pack()
        self.threshold.configure(command=lambda v: self.thresh_label.configure(text=f"{v:.2f}"))
        
        # Build button
        ctk.CTkButton(controls, text="🔨 Build Network", command=self._build).pack(pady=20)
        
        # Stats display
        self.stats_frame = ctk.CTkFrame(controls)
        self.stats_frame.pack(fill="x", padx=10, pady=10)
        ctk.CTkLabel(self.stats_frame, text="📊 Network Stats", font=ctk.CTkFont(weight="bold")).pack(pady=5)
        self.stats_labels = {}
        for stat in ["Nodes", "Edges", "Density", "Clustering"]:
            f = ctk.CTkFrame(self.stats_frame)
            f.pack(fill="x", padx=5, pady=2)
            ctk.CTkLabel(f, text=f"{stat}:", width=80, anchor="w").pack(side="left")
            lbl = ctk.CTkLabel(f, text="-", width=80, anchor="e")
            lbl.pack(side="right")
            self.stats_labels[stat] = lbl
        
        # Visualization controls
        ctk.CTkLabel(controls, text="Export:", font=ctk.CTkFont(weight="bold")).pack(anchor="w", padx=10, pady=(15, 5))
        self.viz_type = ctk.CTkComboBox(controls, values=["Interactive HTML", "Static PNG", "GEXF", "GraphML"], width=180)
        self.viz_type.pack(padx=10, pady=5)
        self.viz_type.set("Interactive HTML")
        
        btns = ctk.CTkFrame(controls)
        btns.pack(pady=10)
        ctk.CTkButton(btns, text="💾 Export", width=80, command=self._export).pack(side="left", padx=5)
        ctk.CTkButton(btns, text="🌐 Open", width=80, command=self._open_viz).pack(side="left", padx=5)
        
        # Right visualization area
        self.viz_area = ctk.CTkFrame(self)
        self.viz_area.pack(side="right", fill="both", expand=True, padx=10, pady=10)
        
        self.viz_placeholder = ctk.CTkLabel(self.viz_area, text="🕸️ Network will appear here after build\n\nClick 'Build Network' to create a network\nthen 'Open' to view the interactive visualization",
                    font=ctk.CTkFont(size=14), text_color="gray")
        self.viz_placeholder.pack(expand=True)
        
        self.viz_info = None
        self.last_export_path = None
    
    def _build(self):
        if not self.app.collected_data or 'stocks' not in self.app.collected_data:
            self._show_error("❌ Collect stock data first!\nGo to 'Data Input' tab and collect data.")
            return
        
        self._show_building()
        
        def build():
            try:
                from finnet.network_analysis import FinancialNetworkBuilder, NetworkMetricsCalculator
                builder = FinancialNetworkBuilder()
                
                net_type = self.net_type.get()
                stocks = self.app.collected_data['stocks']
                
                if net_type == "Correlation":
                    G = builder.build_correlation_network(stocks, threshold=self.threshold.get())
                elif net_type == "Sentiment" and 'ticker_sentiment' in self.app.collected_data:
                    G = builder.build_sentiment_network(self.app.collected_data['ticker_sentiment'], threshold=self.threshold.get())
                else:
                    G = builder.build_correlation_network(stocks, threshold=self.threshold.get())
                
                self.network = G
                self.app.networks['current'] = G
                
                calc = NetworkMetricsCalculator()
                stats = calc.network_statistics(G)
                self.app.analysis_results['network_stats'] = stats
                
                # Auto-export to HTML for viewing
                from finnet.visualization import NetworkVisualizer
                viz = NetworkVisualizer()
                path = str(self.app.config.get_session_dir() / "network.html")
                viz.plot_network_pyvis(G, save_path=path)
                self.last_export_path = path
                
                self.after(0, lambda: self._update_display(stats, path))
            except Exception as e:
                logger.error(f"Build error: {e}")
                self.after(0, lambda: self._show_error(f"❌ Error: {e}"))
        
        threading.Thread(target=build, daemon=True).start()
    
    def _show_building(self):
        self.viz_placeholder.configure(text="⏳ Building network...\nPlease wait...")
        for lbl in self.stats_labels.values():
            lbl.configure(text="...")
    
    def _show_error(self, msg):
        self.viz_placeholder.configure(text=msg)
    
    def _update_display(self, stats, path):
        # Update stats
        self.stats_labels["Nodes"].configure(text=str(stats['num_nodes']))
        self.stats_labels["Edges"].configure(text=str(stats['num_edges']))
        self.stats_labels["Density"].configure(text=f"{stats['density']:.4f}")
        self.stats_labels["Clustering"].configure(text=f"{stats['avg_clustering']:.4f}")
        
        # Update viz area
        self.viz_placeholder.configure(
            text=f"✅ Network Built Successfully!\n\n"
                 f"📊 {stats['num_nodes']} nodes, {stats['num_edges']} edges\n\n"
                 f"💾 Saved to:\n{path}\n\n"
                 f"Click '🌐 Open' to view interactive visualization"
        )
        self.app.set_status(f"Network built: {stats['num_nodes']} nodes, {stats['num_edges']} edges", 1.0)
    
    def _export(self):
        if not self.network:
            self._show_error("❌ Build a network first!")
            return
        try:
            from finnet.visualization import NetworkVisualizer
            viz = NetworkVisualizer()
            viz_type = self.viz_type.get()
            session_dir = self.app.config.get_session_dir()
            
            if "HTML" in viz_type:
                path = str(session_dir / "network.html")
                viz.plot_network_pyvis(self.network, save_path=path)
            elif "PNG" in viz_type:
                path = str(session_dir / "network.png")
                viz.plot_network_static(self.network, save_path=path)
            elif "GEXF" in viz_type:
                import networkx as nx
                path = str(session_dir / "network.gexf")
                nx.write_gexf(self.network, path)
            else:
                import networkx as nx
                path = str(session_dir / "network.graphml")
                nx.write_graphml(self.network, path)
            
            self.last_export_path = path
            self.app.set_status(f"✅ Exported: {path}", 1.0)
        except Exception as e:
            self.app.set_status(f"❌ Error: {e}", 0)
    
    def _open_viz(self):
        if self.last_export_path and Path(self.last_export_path).exists():
            webbrowser.open(f"file://{self.last_export_path}")
        else:
            self._show_error("❌ Export a network first!")
