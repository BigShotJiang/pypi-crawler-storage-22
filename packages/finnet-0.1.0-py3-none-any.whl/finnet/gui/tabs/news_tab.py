"""News Tab - News feed display and filtering."""
import threading
import customtkinter as ctk
from finnet.utils.logger import get_logger
logger = get_logger(__name__)


class NewsTab(ctk.CTkFrame):
    """Tab 7: News feed."""
    
    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app
        self._create_ui()
    
    def _create_ui(self):
        # Header
        header = ctk.CTkFrame(self)
        header.pack(fill="x", padx=10, pady=10)
        
        ctk.CTkLabel(header, text="📰 News Feed", font=ctk.CTkFont(size=18, weight="bold")).pack(side="left", padx=10)
        
        # Search
        self.search = ctk.CTkEntry(header, width=200, placeholder_text="Search news...")
        self.search.pack(side="right", padx=10)
        ctk.CTkButton(header, text="🔍", width=40, command=self._search).pack(side="right", padx=5)
        ctk.CTkButton(header, text="🔄 Refresh", command=self._refresh).pack(side="right", padx=10)
        
        # Filters
        filters = ctk.CTkFrame(self)
        filters.pack(fill="x", padx=10, pady=5)
        
        ctk.CTkLabel(filters, text="Source:").pack(side="left", padx=5)
        self.source = ctk.CTkComboBox(filters, values=["All", "Google News", "Yahoo Finance", "RSS"], width=120)
        self.source.pack(side="left", padx=5)
        self.source.set("All")
        
        ctk.CTkLabel(filters, text="Ticker:").pack(side="left", padx=10)
        self.ticker = ctk.CTkComboBox(filters, values=["All", "AAPL", "MSFT", "GOOGL", "AMZN"], width=100)
        self.ticker.pack(side="left", padx=5)
        
        # News list
        self.news_frame = ctk.CTkScrollableFrame(self)
        self.news_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        self.no_news = ctk.CTkLabel(self.news_frame, text="No news loaded. Click Refresh or collect data first.",
                                    text_color="gray")
        self.no_news.pack(pady=50)
    
    def _refresh(self):
        # Clear existing
        for widget in self.news_frame.winfo_children():
            widget.destroy()
        
        news = []
        if self.app.collected_data:
            news.extend(self.app.collected_data.get('news', []))
            news.extend(self.app.collected_data.get('rss_news', []))
        
        if not news:
            ctk.CTkLabel(self.news_frame, text="No news available. Collect data first.",
                        text_color="gray").pack(pady=50)
            return
        
        for item in news[:30]:
            self._add_news_card(item)
    
    def _add_news_card(self, item):
        card = ctk.CTkFrame(self.news_frame, corner_radius=10)
        card.pack(fill="x", padx=5, pady=5)
        
        title = item.get('title', 'No title')[:80]
        source = item.get('source', item.get('feed', 'Unknown'))
        date = item.get('published', item.get('date', ''))[:20]
        
        ctk.CTkLabel(card, text=title, font=ctk.CTkFont(weight="bold"), wraplength=500, anchor="w").pack(anchor="w", padx=10, pady=(10, 2))
        ctk.CTkLabel(card, text=f"📰 {source} • {date}", text_color="gray", font=ctk.CTkFont(size=11)).pack(anchor="w", padx=10, pady=(0, 10))
    
    def _search(self):
        query = self.search.get().strip().lower()
        if not query:
            self._refresh()
            return
        
        for widget in self.news_frame.winfo_children():
            widget.destroy()
        
        news = []
        if self.app.collected_data:
            news.extend(self.app.collected_data.get('news', []))
            news.extend(self.app.collected_data.get('rss_news', []))
        
        filtered = [n for n in news if query in n.get('title', '').lower()]
        
        if not filtered:
            ctk.CTkLabel(self.news_frame, text=f"No results for '{query}'", text_color="gray").pack(pady=50)
            return
        
        for item in filtered[:20]:
            self._add_news_card(item)
