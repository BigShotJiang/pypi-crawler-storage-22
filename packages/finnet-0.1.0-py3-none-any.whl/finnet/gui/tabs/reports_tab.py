"""Reports Tab - Report generation."""
import threading
import customtkinter as ctk
from finnet.utils.logger import get_logger
logger = get_logger(__name__)


class ReportsTab(ctk.CTkFrame):
    """Tab 8: Report generation."""
    
    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app
        self._create_ui()
    
    def _create_ui(self):
        ctk.CTkLabel(self, text="📄 Generate Reports", font=ctk.CTkFont(size=20, weight="bold")).pack(pady=20)
        
        # Options frame
        options = ctk.CTkFrame(self)
        options.pack(fill="x", padx=50, pady=20)
        
        # Report type
        ctk.CTkLabel(options, text="Report Type:").grid(row=0, column=0, padx=10, pady=10, sticky="w")
        self.report_type = ctk.CTkComboBox(options, values=["PDF Report", "HTML Report", "Excel Export"], width=200)
        self.report_type.grid(row=0, column=1, padx=10, pady=10)
        self.report_type.set("PDF Report")
        
        # Include options
        ctk.CTkLabel(options, text="Include:").grid(row=1, column=0, padx=10, pady=10, sticky="w")
        
        include_frame = ctk.CTkFrame(options)
        include_frame.grid(row=1, column=1, padx=10, pady=10, sticky="w")
        
        self.inc_network = ctk.CTkCheckBox(include_frame, text="Network Analysis")
        self.inc_network.pack(anchor="w", pady=2)
        self.inc_network.select()
        
        self.inc_sentiment = ctk.CTkCheckBox(include_frame, text="Sentiment Analysis")
        self.inc_sentiment.pack(anchor="w", pady=2)
        self.inc_sentiment.select()
        
        self.inc_charts = ctk.CTkCheckBox(include_frame, text="Charts & Visualizations")
        self.inc_charts.pack(anchor="w", pady=2)
        self.inc_charts.select()
        
        self.inc_data = ctk.CTkCheckBox(include_frame, text="Raw Data Tables")
        self.inc_data.pack(anchor="w", pady=2)
        
        # Generate button
        ctk.CTkButton(self, text="📄 Generate Report", width=200, height=40, command=self._generate).pack(pady=30)
        
        # Progress
        self.progress = ctk.CTkProgressBar(self, width=300)
        self.progress.pack(pady=10)
        self.progress.set(0)
        
        self.status = ctk.CTkLabel(self, text="", text_color="gray")
        self.status.pack(pady=10)
    
    def _generate(self):
        self.progress.set(0.2)
        self.status.configure(text="Generating report...")
        
        def generate():
            try:
                from finnet.visualization import ReportGenerator
                gen = ReportGenerator(output_dir=str(self.app.config.get_session_dir()))
                
                report_type = self.report_type.get()
                self.after(0, lambda: self.progress.set(0.5))
                
                sections = gen.generate_summary(
                    network_stats=self.app.analysis_results.get('network_stats', {}),
                    sentiment_summary=self.app.analysis_results.get('sentiment_summary'),
                    communities=self.app.analysis_results.get('communities')
                )
                
                if "PDF" in report_type:
                    path = gen.generate_pdf_report("FinNet Analysis Report", sections=sections)
                elif "HTML" in report_type:
                    path = gen.generate_html_report("FinNet Analysis Report", sections=sections)
                else:
                    import pandas as pd
                    data = {'Summary': pd.DataFrame([self.app.analysis_results.get('network_stats', {})])}
                    path = gen.generate_excel_report(data)
                
                self.after(0, lambda: self._done(f"✅ Report saved: {path}"))
            except Exception as e:
                self.after(0, lambda: self._done(f"❌ Error: {e}"))
        
        threading.Thread(target=generate, daemon=True).start()
    
    def _done(self, msg):
        self.progress.set(1.0)
        self.status.configure(text=msg)
