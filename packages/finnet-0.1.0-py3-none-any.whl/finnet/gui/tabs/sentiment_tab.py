"""Sentiment Tab - Sentiment analysis display."""
import threading
import customtkinter as ctk
from finnet.utils.logger import get_logger
logger = get_logger(__name__)


class SentimentTab(ctk.CTkFrame):
    """Tab 6: Sentiment analysis."""
    
    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app
        self._create_ui()
    
    def _create_ui(self):
        controls = ctk.CTkFrame(self, width=300)
        controls.pack(side="left", fill="y", padx=10, pady=10)
        controls.pack_propagate(False)
        
        ctk.CTkLabel(controls, text="💭 Sentiment Analysis", font=ctk.CTkFont(size=16, weight="bold")).pack(pady=15)
        
        # Analyzer selection
        ctk.CTkLabel(controls, text="Analyzer:").pack(anchor="w", padx=10)
        self.analyzer = ctk.CTkComboBox(controls, values=["VADER", "TextBlob", "Combined", "FinBERT"], width=180)
        self.analyzer.pack(padx=10, pady=5)
        self.analyzer.set("Combined")
        
        # Text entry for manual analysis
        ctk.CTkLabel(controls, text="Test Text:").pack(anchor="w", padx=10, pady=(15,0))
        self.text_entry = ctk.CTkTextbox(controls, height=100, width=260)
        self.text_entry.pack(padx=10, pady=5)
        self.text_entry.insert("0.0", "Enter text to analyze...")
        
        ctk.CTkButton(controls, text="🔍 Analyze Text", command=self._analyze_text).pack(pady=10)
        ctk.CTkButton(controls, text="📊 Analyze Collected Data", command=self._analyze_data).pack(pady=5)
        
        # Results
        self.results = ctk.CTkTextbox(controls, height=200, width=260)
        self.results.pack(padx=10, pady=10)
        self.results.insert("0.0", "Sentiment results...")
        
        # Right - Charts
        right = ctk.CTkFrame(self)
        right.pack(side="right", fill="both", expand=True, padx=10, pady=10)
        ctk.CTkLabel(right, text="Sentiment Charts", font=ctk.CTkFont(weight="bold")).pack(pady=10)
        
        btns = ctk.CTkFrame(right)
        btns.pack(pady=10)
        ctk.CTkButton(btns, text="📊 Distribution", command=lambda: self._chart("dist")).pack(side="left", padx=5)
        ctk.CTkButton(btns, text="📈 Timeline", command=lambda: self._chart("timeline")).pack(side="left", padx=5)
    
    def _analyze_text(self):
        text = self.text_entry.get("0.0", "end").strip()
        if not text or text == "Enter text to analyze...":
            return
        
        try:
            from finnet.data_processing import SentimentAnalyzer
            sa = SentimentAnalyzer()
            result = sa.aggregate_sentiment(text)
            
            txt = f"📊 Sentiment Analysis\n{'='*25}\n"
            txt += f"Score: {result['aggregate_score']:.3f}\n"
            txt += f"Label: {result['label']}\n"
            txt += f"Confidence: {result['confidence']:.2f}\n\n"
            txt += f"VADER: {result['vader']['compound']:.3f}\n"
            txt += f"TextBlob: {result['textblob']['polarity']:.3f}"
            
            self.results.delete("0.0", "end")
            self.results.insert("0.0", txt)
        except Exception as e:
            self.results.delete("0.0", "end")
            self.results.insert("0.0", f"❌ Error: {e}")
    
    def _analyze_data(self):
        if not self.app.collected_data:
            return
        
        def analyze():
            try:
                from finnet.data_processing import SentimentAnalyzer
                sa = SentimentAnalyzer()
                
                posts = self.app.collected_data.get('reddit_posts', [])
                scores = []
                
                for post in posts[:50]:
                    text = post.get('title', '') + ' ' + post.get('selftext', '')
                    if text.strip():
                        result = sa.analyze_vader(text)
                        scores.append(result['compound'])
                
                if scores:
                    avg = sum(scores) / len(scores)
                    pos = sum(1 for s in scores if s > 0.05) / len(scores) * 100
                    neg = sum(1 for s in scores if s < -0.05) / len(scores) * 100
                    
                    txt = f"📊 Data Sentiment\n{'='*25}\n"
                    txt += f"Analyzed: {len(scores)} items\nAvg Score: {avg:.3f}\n"
                    txt += f"Positive: {pos:.1f}%\nNegative: {neg:.1f}%"
                    
                    self.app.analysis_results['sentiment_scores'] = scores
                    self.after(0, lambda: self._update(txt))
            except Exception as e:
                self.after(0, lambda: self._update(f"❌ Error: {e}"))
        
        threading.Thread(target=analyze, daemon=True).start()
    
    def _update(self, txt):
        self.results.delete("0.0", "end")
        self.results.insert("0.0", txt)
    
    def _chart(self, chart_type):
        if 'sentiment_scores' not in self.app.analysis_results:
            return
        try:
            from finnet.visualization import ChartGenerator
            gen = ChartGenerator()
            path = str(self.app.config.get_session_dir() / f"sentiment_{chart_type}.png")
            gen.plot_sentiment_distribution(self.app.analysis_results['sentiment_scores'], save_path=path)
            self.app.set_status(f"Chart: {path}", 1.0)
        except Exception as e:
            self.app.set_status(f"Error: {e}", 0)
