"""Settings Tab - Application preferences."""
import customtkinter as ctk
from finnet.utils.logger import get_logger
logger = get_logger(__name__)


class SettingsTab(ctk.CTkFrame):
    """Tab 9: Settings and preferences."""
    
    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app
        self.config = app.config
        self._create_ui()
    
    def _create_ui(self):
        ctk.CTkLabel(self, text="⚙️ Settings", font=ctk.CTkFont(size=20, weight="bold")).pack(pady=20)
        
        # Settings sections
        settings = ctk.CTkScrollableFrame(self)
        settings.pack(fill="both", expand=True, padx=20, pady=10)
        
        # Appearance
        self._add_section(settings, "🎨 Appearance")
        
        theme_frame = ctk.CTkFrame(settings)
        theme_frame.pack(fill="x", padx=10, pady=5)
        ctk.CTkLabel(theme_frame, text="Theme:").pack(side="left", padx=10)
        self.theme = ctk.CTkComboBox(theme_frame, values=["Dark", "Light", "System"], width=150)
        self.theme.pack(side="left", padx=10)
        self.theme.set("Dark")
        self.theme.configure(command=self._change_theme)
        
        # Data Collection
        self._add_section(settings, "📥 Data Collection")
        
        cache_frame = ctk.CTkFrame(settings)
        cache_frame.pack(fill="x", padx=10, pady=5)
        ctk.CTkLabel(cache_frame, text="Cache Expiry (days):").pack(side="left", padx=10)
        self.cache_days = ctk.CTkEntry(cache_frame, width=80)
        self.cache_days.pack(side="left", padx=10)
        self.cache_days.insert(0, str(self.config.get('cache_expiry_days', 7)))
        
        rate_frame = ctk.CTkFrame(settings)
        rate_frame.pack(fill="x", padx=10, pady=5)
        ctk.CTkLabel(rate_frame, text="Reddit Rate Limit (sec):").pack(side="left", padx=10)
        self.rate = ctk.CTkEntry(rate_frame, width=80)
        self.rate.pack(side="left", padx=10)
        self.rate.insert(0, str(self.config.get('reddit_rate_limit', 2)))
        
        # Network Analysis
        self._add_section(settings, "🕸️ Network Analysis")
        
        thresh_frame = ctk.CTkFrame(settings)
        thresh_frame.pack(fill="x", padx=10, pady=5)
        ctk.CTkLabel(thresh_frame, text="Default Threshold:").pack(side="left", padx=10)
        self.threshold = ctk.CTkSlider(thresh_frame, from_=0.1, to=0.9, width=150)
        self.threshold.pack(side="left", padx=10)
        self.threshold.set(0.5)
        
        # Machine Learning
        self._add_section(settings, "🤖 Machine Learning")
        
        embed_frame = ctk.CTkFrame(settings)
        embed_frame.pack(fill="x", padx=10, pady=5)
        ctk.CTkLabel(embed_frame, text="Embedding Dimension:").pack(side="left", padx=10)
        self.embed_dim = ctk.CTkComboBox(embed_frame, values=["16", "32", "64", "128"], width=100)
        self.embed_dim.pack(side="left", padx=10)
        self.embed_dim.set("64")
        
        # Actions
        actions = ctk.CTkFrame(self)
        actions.pack(fill="x", padx=20, pady=20)
        
        ctk.CTkButton(actions, text="💾 Save Settings", command=self._save).pack(side="left", padx=10)
        ctk.CTkButton(actions, text="🔄 Reset Defaults", command=self._reset).pack(side="left", padx=10)
        ctk.CTkButton(actions, text="🗑️ Clear Cache", fg_color="red", command=self._clear_cache).pack(side="right", padx=10)
        
        self.status = ctk.CTkLabel(self, text="", text_color="gray")
        self.status.pack(pady=10)
    
    def _add_section(self, parent, title):
        ctk.CTkLabel(parent, text=title, font=ctk.CTkFont(weight="bold")).pack(anchor="w", padx=10, pady=(15, 5))
    
    def _change_theme(self, theme):
        ctk.set_appearance_mode(theme.lower())
    
    def _save(self):
        try:
            self.config.set('cache_expiry_days', int(self.cache_days.get()))
            self.config.set('reddit_rate_limit', float(self.rate.get()))
            self.config.set('embed_dim', int(self.embed_dim.get()))
            self.config.save()
            self.status.configure(text="✅ Settings saved")
        except Exception as e:
            self.status.configure(text=f"❌ Error: {e}")
    
    def _reset(self):
        self.cache_days.delete(0, "end")
        self.cache_days.insert(0, "7")
        self.rate.delete(0, "end")
        self.rate.insert(0, "2")
        self.embed_dim.set("64")
        self.threshold.set(0.5)
        self.theme.set("Dark")
        self.status.configure(text="Settings reset to defaults")
    
    def _clear_cache(self):
        try:
            import shutil
            cache_dir = self.config.get_data_dir()
            if cache_dir.exists():
                shutil.rmtree(cache_dir)
                cache_dir.mkdir(parents=True, exist_ok=True)
            self.status.configure(text="✅ Cache cleared")
        except Exception as e:
            self.status.configure(text=f"❌ Error: {e}")
