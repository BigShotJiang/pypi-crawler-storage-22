"""Custom Widgets - Reusable GUI components."""
import customtkinter as ctk
from typing import Optional, Callable


class MetricCard(ctk.CTkFrame):
    """Metric display card with value and label."""
    
    def __init__(self, parent, label: str, value: str = "0", color: str = "#2196F3", **kwargs):
        super().__init__(parent, corner_radius=12, **kwargs)
        self.label = label
        self.color = color
        
        self.value_label = ctk.CTkLabel(self, text=value, font=ctk.CTkFont(size=28, weight="bold"), text_color=color)
        self.value_label.pack(pady=(15, 5))
        
        self.text_label = ctk.CTkLabel(self, text=label, font=ctk.CTkFont(size=12))
        self.text_label.pack(pady=(0, 15))
    
    def set_value(self, value: str):
        self.value_label.configure(text=value)


class LoadingSpinner(ctk.CTkFrame):
    """Loading spinner animation."""
    
    def __init__(self, parent, size: int = 40, **kwargs):
        super().__init__(parent, **kwargs)
        self.size = size
        self.loading = False
        self.angle = 0
        
        self.label = ctk.CTkLabel(self, text="⏳", font=ctk.CTkFont(size=size))
        self.label.pack()
    
    def start(self):
        self.loading = True
        self._animate()
    
    def stop(self):
        self.loading = False
        self.label.configure(text="✅")
    
    def _animate(self):
        if not self.loading:
            return
        symbols = ["⏳", "⌛"]
        self.angle = (self.angle + 1) % 2
        self.label.configure(text=symbols[self.angle])
        self.after(500, self._animate)


class TickerInput(ctk.CTkFrame):
    """Ticker input with validation."""
    
    def __init__(self, parent, placeholder: str = "AAPL, MSFT, GOOGL", **kwargs):
        super().__init__(parent, **kwargs)
        
        ctk.CTkLabel(self, text="Tickers:").pack(side="left", padx=5)
        self.entry = ctk.CTkEntry(self, width=300, placeholder_text=placeholder)
        self.entry.pack(side="left", padx=5)
    
    def get_tickers(self) -> list:
        text = self.entry.get().strip()
        return [t.strip().upper() for t in text.split(",") if t.strip()]


class StatusBar(ctk.CTkFrame):
    """Status bar with progress."""
    
    def __init__(self, parent, **kwargs):
        super().__init__(parent, height=30, corner_radius=0, **kwargs)
        self.pack_propagate(False)
        
        self.status = ctk.CTkLabel(self, text="Ready", font=ctk.CTkFont(size=11))
        self.status.pack(side="left", padx=10, pady=5)
        
        self.progress = ctk.CTkProgressBar(self, width=150)
        self.progress.pack(side="right", padx=10, pady=5)
        self.progress.set(0)
    
    def set_status(self, text: str, progress: float = None):
        self.status.configure(text=text)
        if progress is not None:
            self.progress.set(progress)


class CollapsibleSection(ctk.CTkFrame):
    """Collapsible section widget."""
    
    def __init__(self, parent, title: str, **kwargs):
        super().__init__(parent, **kwargs)
        self.expanded = True
        
        self.header = ctk.CTkButton(self, text=f"▼ {title}", anchor="w", command=self.toggle)
        self.header.pack(fill="x")
        
        self.content = ctk.CTkFrame(self)
        self.content.pack(fill="both", expand=True)
        
        self.title = title
    
    def toggle(self):
        self.expanded = not self.expanded
        if self.expanded:
            self.content.pack(fill="both", expand=True)
            self.header.configure(text=f"▼ {self.title}")
        else:
            self.content.pack_forget()
            self.header.configure(text=f"▶ {self.title}")


class DataTable(ctk.CTkScrollableFrame):
    """Simple data table widget."""
    
    def __init__(self, parent, columns: list, **kwargs):
        super().__init__(parent, **kwargs)
        self.columns = columns
        self.rows = []
        
        # Header
        header = ctk.CTkFrame(self)
        header.pack(fill="x", pady=2)
        for i, col in enumerate(columns):
            ctk.CTkLabel(header, text=col, font=ctk.CTkFont(weight="bold"), width=100).pack(side="left", padx=2)
    
    def add_row(self, values: list):
        row = ctk.CTkFrame(self)
        row.pack(fill="x", pady=1)
        for val in values[:len(self.columns)]:
            ctk.CTkLabel(row, text=str(val)[:15], width=100).pack(side="left", padx=2)
        self.rows.append(row)
    
    def clear(self):
        for row in self.rows:
            row.destroy()
        self.rows.clear()


class Tooltip:
    """Tooltip for widgets."""
    
    def __init__(self, widget, text: str):
        self.widget = widget
        self.text = text
        self.tip_window = None
        
        widget.bind("<Enter>", self.show)
        widget.bind("<Leave>", self.hide)
    
    def show(self, event=None):
        if self.tip_window:
            return
        x, y, _, _ = self.widget.bbox("insert") if hasattr(self.widget, 'bbox') else (0, 0, 0, 0)
        x += self.widget.winfo_rootx() + 25
        y += self.widget.winfo_rooty() + 25
        
        self.tip_window = tw = ctk.CTkToplevel(self.widget)
        tw.wm_overrideredirect(True)
        tw.wm_geometry(f"+{x}+{y}")
        
        label = ctk.CTkLabel(tw, text=self.text, corner_radius=5)
        label.pack(padx=5, pady=5)
    
    def hide(self, event=None):
        if self.tip_window:
            self.tip_window.destroy()
            self.tip_window = None
