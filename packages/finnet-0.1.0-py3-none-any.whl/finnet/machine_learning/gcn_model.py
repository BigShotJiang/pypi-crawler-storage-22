"""
Graph Convolutional Network Model - FROM SCRATCH

Complete GCN model for node classification and embedding extraction.
No PyTorch Geometric dependency.
"""

from typing import Optional, List, Tuple, Dict, Any

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import numpy as np
import networkx as nx

from finnet.machine_learning.graph_layers import GCNLayer, normalize_adjacency, graph_to_adjacency
from finnet.utils.logger import get_logger

logger = get_logger(__name__)


class FinNetGCN(nn.Module):
    """
    Financial Network GCN Model - FROM SCRATCH.
    
    Multi-layer GCN for:
    - Node classification
    - Node embedding extraction
    - Link prediction features
    
    No PyTorch Geometric required!
    """
    
    def __init__(
        self,
        input_dim: int,
        hidden_dims: List[int],
        output_dim: int,
        dropout: float = 0.5
    ):
        """
        Initialize the GCN model.
        
        Args:
            input_dim: Input feature dimension
            hidden_dims: List of hidden layer dimensions
            output_dim: Output dimension (num classes or embedding dim)
            dropout: Dropout probability
        """
        super(FinNetGCN, self).__init__()
        
        self.input_dim = input_dim
        self.hidden_dims = hidden_dims
        self.output_dim = output_dim
        self.dropout = dropout
        
        # Build layers
        self.layers = nn.ModuleList()
        
        prev_dim = input_dim
        for i, hidden_dim in enumerate(hidden_dims):
            self.layers.append(
                GCNLayer(
                    prev_dim,
                    hidden_dim,
                    activation='relu',
                    dropout=dropout if i > 0 else 0
                )
            )
            prev_dim = hidden_dim
        
        # Output layer (no activation for classification logits)
        self.output_layer = GCNLayer(
            prev_dim,
            output_dim,
            activation=None,
            dropout=0
        )
    
    def forward(
        self,
        X: torch.Tensor,
        A_norm: torch.Tensor
    ) -> torch.Tensor:
        """
        Forward pass.
        
        Args:
            X: Node features [N, input_dim]
            A_norm: Normalized adjacency [N, N]
            
        Returns:
            Output logits [N, output_dim]
        """
        h = X
        
        # Hidden layers
        for layer in self.layers:
            h = layer(h, A_norm)
        
        # Output layer
        out = self.output_layer(h, A_norm)
        
        return out
    
    def get_embeddings(
        self,
        X: torch.Tensor,
        A_norm: torch.Tensor,
        layer_idx: int = -1
    ) -> torch.Tensor:
        """
        Extract node embeddings from an intermediate layer.
        
        Args:
            X: Node features
            A_norm: Normalized adjacency
            layer_idx: Which layer to extract from (-1 = last hidden)
            
        Returns:
            Node embeddings
        """
        h = X
        
        # Process through layers
        for i, layer in enumerate(self.layers):
            h = layer(h, A_norm)
            if i == layer_idx:
                return h
        
        return h  # Last hidden layer
    
    def embed_graph(
        self,
        G: nx.Graph,
        node_features: Optional[torch.Tensor] = None,
        feature_dim: int = 16
    ) -> Tuple[torch.Tensor, List[str]]:
        """
        Embed all nodes in a graph.
        
        Args:
            G: NetworkX graph
            node_features: Optional pre-computed features
            feature_dim: Feature dimension if generating random features
            
        Returns:
            Tuple of (embeddings, node_list)
        """
        self.eval()
        
        nodes = list(G.nodes())
        
        # Get adjacency and normalize
        A = graph_to_adjacency(G)
        A_norm = normalize_adjacency(A)
        
        # Create features if not provided
        if node_features is None:
            node_features = torch.randn(len(nodes), self.input_dim)
        
        # Get embeddings
        with torch.no_grad():
            embeddings = self.get_embeddings(node_features, A_norm)
        
        return embeddings, nodes


class GCNTrainer:
    """
    Trainer for GCN models.
    
    Handles training, evaluation, and checkpointing.
    """
    
    def __init__(
        self,
        model: FinNetGCN,
        learning_rate: float = 0.01,
        weight_decay: float = 5e-4,
        device: str = 'auto'
    ):
        """
        Initialize trainer.
        
        Args:
            model: GCN model to train
            learning_rate: Learning rate
            weight_decay: L2 regularization
            device: 'cuda', 'cpu', or 'auto'
        """
        self.model = model
        
        # Select device
        if device == 'auto':
            self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        else:
            self.device = torch.device(device)
        
        self.model.to(self.device)
        
        # Optimizer
        self.optimizer = optim.Adam(
            model.parameters(),
            lr=learning_rate,
            weight_decay=weight_decay
        )
        
        # Training history
        self.history = {
            'train_loss': [],
            'train_acc': [],
            'val_loss': [],
            'val_acc': [],
        }
    
    def train_step(
        self,
        X: torch.Tensor,
        A_norm: torch.Tensor,
        labels: torch.Tensor,
        train_mask: torch.Tensor
    ) -> Tuple[float, float]:
        """
        Single training step.
        
        Args:
            X: Node features
            A_norm: Normalized adjacency
            labels: Node labels
            train_mask: Boolean mask for training nodes
            
        Returns:
            Tuple of (loss, accuracy)
        """
        self.model.train()
        
        # Move to device
        X = X.to(self.device)
        A_norm = A_norm.to(self.device)
        labels = labels.to(self.device)
        train_mask = train_mask.to(self.device)
        
        # Forward pass
        self.optimizer.zero_grad()
        out = self.model(X, A_norm)
        
        # Loss on training nodes
        loss = F.cross_entropy(out[train_mask], labels[train_mask])
        
        # Backward pass
        loss.backward()
        self.optimizer.step()
        
        # Calculate accuracy
        pred = out[train_mask].argmax(dim=1)
        acc = (pred == labels[train_mask]).float().mean().item()
        
        return loss.item(), acc
    
    def evaluate(
        self,
        X: torch.Tensor,
        A_norm: torch.Tensor,
        labels: torch.Tensor,
        mask: torch.Tensor
    ) -> Tuple[float, float]:
        """
        Evaluate model on given nodes.
        
        Args:
            X: Node features
            A_norm: Normalized adjacency
            labels: Node labels
            mask: Boolean mask for evaluation nodes
            
        Returns:
            Tuple of (loss, accuracy)
        """
        self.model.eval()
        
        # Move to device
        X = X.to(self.device)
        A_norm = A_norm.to(self.device)
        labels = labels.to(self.device)
        mask = mask.to(self.device)
        
        with torch.no_grad():
            out = self.model(X, A_norm)
            loss = F.cross_entropy(out[mask], labels[mask])
            
            pred = out[mask].argmax(dim=1)
            acc = (pred == labels[mask]).float().mean().item()
        
        return loss.item(), acc
    
    def train(
        self,
        X: torch.Tensor,
        A_norm: torch.Tensor,
        labels: torch.Tensor,
        train_mask: torch.Tensor,
        val_mask: Optional[torch.Tensor] = None,
        epochs: int = 200,
        early_stopping: int = 20,
        verbose: bool = True
    ) -> Dict[str, List]:
        """
        Train the model.
        
        Args:
            X: Node features
            A_norm: Normalized adjacency
            labels: Node labels
            train_mask: Training mask
            val_mask: Validation mask
            epochs: Number of epochs
            early_stopping: Patience for early stopping
            verbose: Print progress
            
        Returns:
            Training history
        """
        best_val_acc = 0
        patience_counter = 0
        best_state = None
        
        for epoch in range(epochs):
            # Training step
            train_loss, train_acc = self.train_step(X, A_norm, labels, train_mask)
            
            self.history['train_loss'].append(train_loss)
            self.history['train_acc'].append(train_acc)
            
            # Validation
            if val_mask is not None:
                val_loss, val_acc = self.evaluate(X, A_norm, labels, val_mask)
                self.history['val_loss'].append(val_loss)
                self.history['val_acc'].append(val_acc)
                
                # Early stopping check
                if val_acc > best_val_acc:
                    best_val_acc = val_acc
                    patience_counter = 0
                    best_state = self.model.state_dict().copy()
                else:
                    patience_counter += 1
                    if patience_counter >= early_stopping:
                        if verbose:
                            logger.info(f"Early stopping at epoch {epoch}")
                        break
            
            if verbose and (epoch + 1) % 10 == 0:
                msg = f"Epoch {epoch+1}/{epochs} - Loss: {train_loss:.4f}, Acc: {train_acc:.4f}"
                if val_mask is not None:
                    msg += f" - Val Loss: {val_loss:.4f}, Val Acc: {val_acc:.4f}"
                logger.info(msg)
        
        # Restore best model
        if best_state is not None:
            self.model.load_state_dict(best_state)
        
        return self.history
    
    def predict(
        self,
        X: torch.Tensor,
        A_norm: torch.Tensor
    ) -> torch.Tensor:
        """
        Get model predictions.
        
        Args:
            X: Node features
            A_norm: Normalized adjacency
            
        Returns:
            Predicted class labels
        """
        self.model.eval()
        
        X = X.to(self.device)
        A_norm = A_norm.to(self.device)
        
        with torch.no_grad():
            out = self.model(X, A_norm)
            pred = out.argmax(dim=1)
        
        return pred.cpu()
    
    def get_embeddings(
        self,
        X: torch.Tensor,
        A_norm: torch.Tensor
    ) -> torch.Tensor:
        """
        Get node embeddings from trained model.
        
        Args:
            X: Node features
            A_norm: Normalized adjacency
            
        Returns:
            Node embeddings
        """
        self.model.eval()
        
        X = X.to(self.device)
        A_norm = A_norm.to(self.device)
        
        with torch.no_grad():
            embeddings = self.model.get_embeddings(X, A_norm)
        
        return embeddings.cpu()
    
    def save_checkpoint(self, path: str):
        """Save model checkpoint."""
        torch.save({
            'model_state_dict': self.model.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'history': self.history,
        }, path)
        logger.info(f"Checkpoint saved to {path}")
    
    def load_checkpoint(self, path: str):
        """Load model checkpoint."""
        checkpoint = torch.load(path, map_location=self.device)
        self.model.load_state_dict(checkpoint['model_state_dict'])
        self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        self.history = checkpoint.get('history', self.history)
        logger.info(f"Checkpoint loaded from {path}")


def create_gcn_for_graph(
    G: nx.Graph,
    hidden_dims: List[int] = [64, 32],
    output_dim: int = 16,
    input_features: Optional[torch.Tensor] = None
) -> Tuple[FinNetGCN, torch.Tensor, torch.Tensor]:
    """
    Create a GCN model for a given graph.
    
    Args:
        G: NetworkX graph
        hidden_dims: Hidden layer dimensions
        output_dim: Output embedding dimension
        input_features: Optional input features
        
    Returns:
        Tuple of (model, features, normalized_adjacency)
    """
    n_nodes = G.number_of_nodes()
    
    # Create features if not provided
    if input_features is None:
        # Use degree-based features extended with random
        degrees = torch.tensor([d for _, d in G.degree()], dtype=torch.float)
        degrees = degrees / degrees.max()
        input_features = torch.randn(n_nodes, 16)
        input_features[:, 0] = degrees
    
    input_dim = input_features.size(1)
    
    # Get normalized adjacency
    A = graph_to_adjacency(G)
    A_norm = normalize_adjacency(A)
    
    # Create model
    model = FinNetGCN(
        input_dim=input_dim,
        hidden_dims=hidden_dims,
        output_dim=output_dim
    )
    
    return model, input_features, A_norm
