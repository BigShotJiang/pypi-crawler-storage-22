"""
Graph Convolutional Network Layers - FROM SCRATCH

Implements GCN layers using pure PyTorch WITHOUT PyTorch Geometric.

The propagation rule is:
    H' = σ(D̃^(-1/2) Ã D̃^(-1/2) H W)
    
Where:
    - Ã = A + I (adjacency with self-loops)
    - D̃ = degree matrix of Ã
    - H = node feature matrix
    - W = learnable weights
    - σ = activation function
"""

import math
from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import networkx as nx

from finnet.utils.logger import get_logger

logger = get_logger(__name__)


def normalize_adjacency(A: torch.Tensor, add_self_loops: bool = True) -> torch.Tensor:
    """
    Compute the symmetrically normalized adjacency matrix.
    
    Computes: D̃^(-1/2) Ã D̃^(-1/2)
    
    Args:
        A: Adjacency matrix [N, N]
        add_self_loops: Whether to add self-loops (Ã = A + I)
        
    Returns:
        Normalized adjacency matrix
    """
    # Add self-loops if requested
    if add_self_loops:
        I = torch.eye(A.size(0), device=A.device)
        A_tilde = A + I
    else:
        A_tilde = A
    
    # Compute degree matrix
    D = torch.diag(A_tilde.sum(dim=1))
    
    # Compute D^(-1/2)
    D_inv_sqrt = torch.diag(torch.pow(D.diag() + 1e-8, -0.5))
    
    # Compute normalized adjacency: D^(-1/2) * A * D^(-1/2)
    A_norm = D_inv_sqrt @ A_tilde @ D_inv_sqrt
    
    return A_norm


def sparse_normalize_adjacency(edge_index: torch.Tensor, num_nodes: int) -> torch.Tensor:
    """
    Compute normalized adjacency from edge index (sparse format).
    
    Args:
        edge_index: Edge index tensor [2, E]
        num_nodes: Number of nodes
        
    Returns:
        Normalized adjacency as dense matrix
    """
    # Create sparse adjacency
    values = torch.ones(edge_index.size(1))
    A = torch.sparse_coo_tensor(
        edge_index, values, (num_nodes, num_nodes)
    ).to_dense()
    
    return normalize_adjacency(A, add_self_loops=True)


class GCNLayer(nn.Module):
    """
    Graph Convolutional Network Layer - FROM SCRATCH.
    
    Implements the GCN propagation rule:
    H' = σ(Ã_norm @ H @ W)
    
    where Ã_norm is the normalized adjacency with self-loops.
    
    This implementation does NOT use PyTorch Geometric.
    It works directly with adjacency matrices.
    """
    
    def __init__(
        self,
        in_features: int,
        out_features: int,
        bias: bool = True,
        activation: Optional[str] = 'relu',
        dropout: float = 0.0
    ):
        """
        Initialize GCN layer.
        
        Args:
            in_features: Number of input features
            out_features: Number of output features
            bias: Whether to use bias
            activation: Activation function ('relu', 'elu', 'leaky_relu', None)
            dropout: Dropout probability
        """
        super(GCNLayer, self).__init__()
        
        self.in_features = in_features
        self.out_features = out_features
        
        # Learnable weight matrix
        self.weight = nn.Parameter(torch.FloatTensor(in_features, out_features))
        
        # Optional bias
        if bias:
            self.bias = nn.Parameter(torch.FloatTensor(out_features))
        else:
            self.register_parameter('bias', None)
        
        # Activation
        self.activation = activation
        
        # Dropout
        self.dropout = nn.Dropout(p=dropout) if dropout > 0 else None
        
        # Initialize parameters
        self.reset_parameters()
    
    def reset_parameters(self):
        """Initialize weights using Xavier initialization."""
        stdv = 1. / math.sqrt(self.weight.size(1))
        self.weight.data.uniform_(-stdv, stdv)
        if self.bias is not None:
            self.bias.data.uniform_(-stdv, stdv)
    
    def forward(
        self,
        X: torch.Tensor,
        A_norm: torch.Tensor
    ) -> torch.Tensor:
        """
        Forward pass.
        
        Args:
            X: Node feature matrix [N, in_features]
            A_norm: Normalized adjacency matrix [N, N]
            
        Returns:
            Output features [N, out_features]
        """
        # Apply dropout to input if training
        if self.dropout is not None:
            X = self.dropout(X)
        
        # Linear transformation: H @ W
        support = torch.mm(X, self.weight)
        
        # Graph convolution: Ã_norm @ (H @ W)
        output = torch.mm(A_norm, support)
        
        # Add bias
        if self.bias is not None:
            output = output + self.bias
        
        # Apply activation
        if self.activation == 'relu':
            output = F.relu(output)
        elif self.activation == 'elu':
            output = F.elu(output)
        elif self.activation == 'leaky_relu':
            output = F.leaky_relu(output, 0.2)
        
        return output
    
    def __repr__(self):
        return f'GCNLayer({self.in_features} -> {self.out_features})'


class GraphAttentionLayer(nn.Module):
    """
    Graph Attention Layer - FROM SCRATCH.
    
    Implements GAT layer without PyTorch Geometric.
    Uses attention mechanism to weight neighbor contributions.
    """
    
    def __init__(
        self,
        in_features: int,
        out_features: int,
        heads: int = 1,
        concat: bool = True,
        dropout: float = 0.0,
        negative_slope: float = 0.2
    ):
        """
        Initialize GAT layer.
        
        Args:
            in_features: Number of input features
            out_features: Number of output features per head
            heads: Number of attention heads
            concat: Whether to concatenate or average head outputs
            dropout: Dropout probability
            negative_slope: LeakyReLU negative slope
        """
        super(GraphAttentionLayer, self).__init__()
        
        self.in_features = in_features
        self.out_features = out_features
        self.heads = heads
        self.concat = concat
        self.negative_slope = negative_slope
        
        # Linear transformation for each head
        self.W = nn.Parameter(torch.FloatTensor(in_features, heads * out_features))
        
        # Attention parameters for each head
        self.a_src = nn.Parameter(torch.FloatTensor(heads, out_features))
        self.a_dst = nn.Parameter(torch.FloatTensor(heads, out_features))
        
        self.dropout = nn.Dropout(p=dropout) if dropout > 0 else None
        
        self.reset_parameters()
    
    def reset_parameters(self):
        """Initialize parameters."""
        nn.init.xavier_uniform_(self.W)
        nn.init.xavier_uniform_(self.a_src.unsqueeze(-1))
        nn.init.xavier_uniform_(self.a_dst.unsqueeze(-1))
    
    def forward(
        self,
        X: torch.Tensor,
        A: torch.Tensor
    ) -> torch.Tensor:
        """
        Forward pass.
        
        Args:
            X: Node features [N, in_features]
            A: Adjacency matrix [N, N] (used to mask attention)
            
        Returns:
            Output features [N, heads * out_features] or [N, out_features]
        """
        N = X.size(0)
        
        # Linear transformation: [N, heads * out_features]
        H = torch.mm(X, self.W)
        
        # Reshape for multi-head: [N, heads, out_features]
        H = H.view(N, self.heads, self.out_features)
        
        # Compute attention scores
        # a_src: source contribution, a_dst: destination contribution
        attn_src = (H * self.a_src).sum(dim=-1)  # [N, heads]
        attn_dst = (H * self.a_dst).sum(dim=-1)  # [N, heads]
        
        # Attention scores: e_ij = LeakyReLU(a_src_i + a_dst_j)
        # [N, 1, heads] + [1, N, heads] = [N, N, heads]
        e = F.leaky_relu(
            attn_src.unsqueeze(1) + attn_dst.unsqueeze(0),
            negative_slope=self.negative_slope
        )
        
        # Mask with adjacency (set non-edges to -inf)
        mask = (A.unsqueeze(-1) == 0)
        e = e.masked_fill(mask, float('-inf'))
        
        # Softmax to get attention weights
        alpha = F.softmax(e, dim=1)  # [N, N, heads]
        
        if self.dropout is not None:
            alpha = self.dropout(alpha)
        
        # Weighted sum of neighbor features
        # [N, N, heads] x [N, heads, out_features] -> [N, heads, out_features]
        out = torch.einsum('ijh,jhf->ihf', alpha, H)
        
        # Concatenate or average heads
        if self.concat:
            out = out.reshape(N, self.heads * self.out_features)
        else:
            out = out.mean(dim=1)
        
        return out


def graph_to_adjacency(G: nx.Graph) -> torch.Tensor:
    """
    Convert NetworkX graph to adjacency matrix tensor.
    
    Args:
        G: NetworkX graph
        
    Returns:
        Adjacency matrix as torch tensor
    """
    nodes = list(G.nodes())
    A = nx.to_numpy_array(G, nodelist=nodes)
    return torch.FloatTensor(A)


def create_node_features(
    G: nx.Graph,
    feature_dim: int = 16,
    method: str = 'random'
) -> torch.Tensor:
    """
    Create node feature matrix for a graph.
    
    Args:
        G: NetworkX graph
        feature_dim: Dimension of features
        method: 'random', 'degree', 'one_hot'
        
    Returns:
        Node feature matrix [N, feature_dim]
    """
    N = G.number_of_nodes()
    
    if method == 'random':
        return torch.randn(N, feature_dim)
    
    elif method == 'degree':
        degrees = torch.tensor([d for _, d in G.degree()], dtype=torch.float)
        # Normalize and expand
        degrees = degrees / degrees.max()
        features = degrees.unsqueeze(1).repeat(1, feature_dim)
        return features
    
    elif method == 'one_hot':
        return torch.eye(N)
    
    else:
        raise ValueError(f"Unknown method: {method}")
