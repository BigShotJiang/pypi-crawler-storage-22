"""
GNN-based Link Prediction

Link prediction using GCN embeddings and traditional ML classifiers.
"""

from typing import Dict, List, Tuple, Optional, Any

import numpy as np
import torch
import torch.nn as nn
import networkx as nx

from finnet.machine_learning.gcn_model import FinNetGCN, create_gcn_for_graph
from finnet.machine_learning.graph_layers import normalize_adjacency, graph_to_adjacency
from finnet.utils.logger import get_logger

logger = get_logger(__name__)


class GNNLinkPredictor:
    """
    Link prediction using GNN embeddings.
    
    Pipeline:
    1. Train/use GCN to get node embeddings
    2. For each node pair, combine embeddings (e.g., concatenate, Hadamard)
    3. Train classifier on edge existence
    """
    
    def __init__(
        self,
        embedding_dim: int = 32,
        hidden_dims: List[int] = [64],
        combination: str = 'hadamard'
    ):
        """
        Initialize link predictor.
        
        Args:
            embedding_dim: GCN output embedding dimension
            hidden_dims: GCN hidden layer dimensions
            combination: How to combine node embeddings ('concat', 'hadamard', 'avg', 'l1', 'l2')
        """
        self.embedding_dim = embedding_dim
        self.hidden_dims = hidden_dims
        self.combination = combination
        
        self.gcn = None
        self.node_features = None
        self.A_norm = None
        self.classifier = None
        self.nodes = None
        self.node_to_idx = None
    
    def fit(
        self,
        G: nx.Graph,
        train_edges: Optional[List[Tuple]] = None,
        train_non_edges: Optional[List[Tuple]] = None,
        epochs: int = 100
    ) -> "GNNLinkPredictor":
        """
        Fit the link predictor.
        
        Args:
            G: NetworkX graph
            train_edges: Positive training edges (if None, uses all edges)
            train_non_edges: Negative training edges (if None, samples randomly)
            epochs: GCN training epochs
            
        Returns:
            Self for chaining
        """
        self.nodes = list(G.nodes())
        self.node_to_idx = {n: i for i, n in enumerate(self.nodes)}
        
        # Create GCN model
        self.gcn, self.node_features, self.A_norm = create_gcn_for_graph(
            G,
            hidden_dims=self.hidden_dims,
            output_dim=self.embedding_dim
        )
        
        # Get embeddings (untrained GCN for now - could add supervised training)
        self.gcn.eval()
        with torch.no_grad():
            embeddings = self.gcn.get_embeddings(self.node_features, self.A_norm)
        
        # Prepare training data
        if train_edges is None:
            train_edges = list(G.edges())
        
        if train_non_edges is None:
            # Sample non-edges
            non_edges = list(nx.non_edges(G))
            np.random.shuffle(non_edges)
            train_non_edges = non_edges[:len(train_edges)]
        
        # Create feature vectors and labels
        X = []
        y = []
        
        for u, v in train_edges:
            if u in self.node_to_idx and v in self.node_to_idx:
                i, j = self.node_to_idx[u], self.node_to_idx[v]
                X.append(self._combine_embeddings(embeddings[i], embeddings[j]))
                y.append(1)
        
        for u, v in train_non_edges:
            if u in self.node_to_idx and v in self.node_to_idx:
                i, j = self.node_to_idx[u], self.node_to_idx[v]
                X.append(self._combine_embeddings(embeddings[i], embeddings[j]))
                y.append(0)
        
        X = torch.stack(X).numpy()
        y = np.array(y)
        
        # Train classifier
        try:
            from sklearn.linear_model import LogisticRegression
            
            self.classifier = LogisticRegression(max_iter=1000, random_state=42)
            self.classifier.fit(X, y)
            
            train_acc = self.classifier.score(X, y)
            logger.info(f"Link predictor trained with {len(y)} samples, accuracy: {train_acc:.4f}")
            
        except ImportError:
            logger.warning("sklearn not available, using simple threshold classifier")
            self.classifier = None
        
        return self
    
    def _combine_embeddings(
        self,
        emb1: torch.Tensor,
        emb2: torch.Tensor
    ) -> torch.Tensor:
        """Combine two node embeddings into edge features."""
        if self.combination == 'concat':
            return torch.cat([emb1, emb2])
        elif self.combination == 'hadamard':
            return emb1 * emb2
        elif self.combination == 'avg':
            return (emb1 + emb2) / 2
        elif self.combination == 'l1':
            return torch.abs(emb1 - emb2)
        elif self.combination == 'l2':
            return (emb1 - emb2) ** 2
        else:
            raise ValueError(f"Unknown combination: {self.combination}")
    
    def predict_proba(
        self,
        node_pairs: List[Tuple]
    ) -> np.ndarray:
        """
        Predict link probabilities for node pairs.
        
        Args:
            node_pairs: List of (node1, node2) tuples
            
        Returns:
            Array of probabilities
        """
        if self.gcn is None:
            raise ValueError("Model not fitted. Call fit() first.")
        
        # Get current embeddings
        self.gcn.eval()
        with torch.no_grad():
            embeddings = self.gcn.get_embeddings(self.node_features, self.A_norm)
        
        # Create features
        X = []
        valid_pairs = []
        
        for u, v in node_pairs:
            if u in self.node_to_idx and v in self.node_to_idx:
                i, j = self.node_to_idx[u], self.node_to_idx[v]
                X.append(self._combine_embeddings(embeddings[i], embeddings[j]))
                valid_pairs.append((u, v))
        
        if not X:
            return np.array([])
        
        X = torch.stack(X).numpy()
        
        if self.classifier is not None:
            probs = self.classifier.predict_proba(X)[:, 1]
        else:
            # Simple cosine similarity fallback
            probs = np.array([1 / (1 + np.linalg.norm(x)) for x in X])
        
        return probs
    
    def predict_top_links(
        self,
        G: nx.Graph,
        k: int = 10
    ) -> List[Tuple[str, str, float]]:
        """
        Predict top-k most likely new links.
        
        Args:
            G: Current graph
            k: Number of links to predict
            
        Returns:
            List of (node1, node2, probability) tuples
        """
        # Get all non-edges
        non_edges = list(nx.non_edges(G))
        
        if not non_edges:
            return []
        
        # Sample if too many
        if len(non_edges) > 10000:
            np.random.shuffle(non_edges)
            non_edges = non_edges[:10000]
        
        # Predict probabilities
        probs = self.predict_proba(non_edges)
        
        # Sort by probability
        if len(probs) > 0:
            sorted_indices = np.argsort(probs)[::-1][:k]
            
            results = [
                (non_edges[i][0], non_edges[i][1], float(probs[i]))
                for i in sorted_indices
            ]
            
            return results
        
        return []
    
    def evaluate(
        self,
        test_edges: List[Tuple],
        test_non_edges: List[Tuple]
    ) -> Dict[str, float]:
        """
        Evaluate link prediction performance.
        
        Args:
            test_edges: Positive test edges
            test_non_edges: Negative test edges
            
        Returns:
            Evaluation metrics
        """
        all_pairs = list(test_edges) + list(test_non_edges)
        y_true = [1] * len(test_edges) + [0] * len(test_non_edges)
        
        probs = self.predict_proba(all_pairs)
        
        if len(probs) == 0:
            return {'error': 'No valid predictions'}
        
        y_pred = (probs > 0.5).astype(int)
        
        # Calculate metrics
        tp = sum((p == 1 and t == 1) for p, t in zip(y_pred, y_true))
        fp = sum((p == 1 and t == 0) for p, t in zip(y_pred, y_true))
        fn = sum((p == 0 and t == 1) for p, t in zip(y_pred, y_true))
        tn = sum((p == 0 and t == 0) for p, t in zip(y_pred, y_true))
        
        precision = tp / max(tp + fp, 1)
        recall = tp / max(tp + fn, 1)
        f1 = 2 * precision * recall / max(precision + recall, 1e-10)
        accuracy = (tp + tn) / len(y_true)
        
        # AUC
        try:
            from sklearn.metrics import roc_auc_score
            auc = roc_auc_score(y_true, probs)
        except ImportError:
            auc = None
        
        return {
            'accuracy': accuracy,
            'precision': precision,
            'recall': recall,
            'f1': f1,
            'auc': auc,
        }


class EdgeDecoder(nn.Module):
    """
    Neural network edge decoder for link prediction.
    
    Takes concatenated node embeddings and predicts edge probability.
    """
    
    def __init__(
        self,
        embedding_dim: int,
        hidden_dim: int = 64,
        combination: str = 'concat'
    ):
        """
        Initialize edge decoder.
        
        Args:
            embedding_dim: Node embedding dimension
            hidden_dim: Hidden layer dimension
            combination: Embedding combination method
        """
        super(EdgeDecoder, self).__init__()
        
        self.combination = combination
        
        if combination == 'concat':
            input_dim = embedding_dim * 2
        else:
            input_dim = embedding_dim
        
        self.decoder = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(hidden_dim, 1),
            nn.Sigmoid()
        )
    
    def forward(
        self,
        z_i: torch.Tensor,
        z_j: torch.Tensor
    ) -> torch.Tensor:
        """
        Predict edge probability.
        
        Args:
            z_i: Source node embeddings
            z_j: Target node embeddings
            
        Returns:
            Edge probabilities
        """
        if self.combination == 'concat':
            x = torch.cat([z_i, z_j], dim=-1)
        elif self.combination == 'hadamard':
            x = z_i * z_j
        elif self.combination == 'dot':
            return torch.sigmoid((z_i * z_j).sum(dim=-1))
        else:
            x = z_i * z_j
        
        return self.decoder(x).squeeze(-1)
