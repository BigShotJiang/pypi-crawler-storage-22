"""
Node2Vec Implementation

Graph node embedding using biased random walks + Word2Vec.
Uses gensim for the Word2Vec portion.
"""

import random
from typing import Dict, List, Optional, Tuple

import numpy as np
import networkx as nx
# from tqdm import tqdm

from finnet.utils.logger import get_logger

logger = get_logger(__name__)


class Node2VecEmbed:
    """
    Node2Vec graph embedding implementation.
    
    Algorithm:
    1. Generate biased random walks on the graph
    2. Use walks as sentences for Word2Vec training
    3. Learn node embeddings from the model
    
    Parameters p and q control walk behavior:
    - Low p: More likely to return to previous node (BFS-like, local)
    - Low q: More likely to explore outward (DFS-like, global)
    """
    
    def __init__(
        self,
        dimensions: int = 64,
        walk_length: int = 80,
        num_walks: int = 10,
        p: float = 1.0,
        q: float = 1.0,
        workers: int = 4,
        seed: Optional[int] = None
    ):
        """
        Initialize Node2Vec.
        
        Args:
            dimensions: Embedding dimension
            walk_length: Length of each random walk
            num_walks: Number of walks per node
            p: Return parameter (lower = more local exploration)
            q: In-out parameter (lower = more global exploration)
            workers: Parallel workers for Word2Vec
            seed: Random seed
        """
        self.dimensions = dimensions
        self.walk_length = walk_length
        self.num_walks = num_walks
        self.p = p
        self.q = q
        self.workers = workers
        self.seed = seed
        
        self.G = None
        self.model = None
        self.transition_probs = {}
        
        if seed is not None:
            random.seed(seed)
            np.random.seed(seed)
    
    def fit(self, G: nx.Graph) -> "Node2VecEmbed":
        """
        Fit Node2Vec to a graph.
        
        Args:
            G: NetworkX graph
            
        Returns:
            Self for chaining
        """
        self.G = G
        
        # Precompute transition probabilities
        logger.info("Precomputing transition probabilities...")
        self._precompute_transition_probs()
        
        # Generate walks
        logger.info(f"Generating {self.num_walks} walks per node...")
        walks = self._generate_walks()
        
        # Train Word2Vec
        logger.info(f"Training Word2Vec on {len(walks)} walks...")
        self._train_word2vec(walks)
        
        logger.info(f"Node2Vec complete: {G.number_of_nodes()} nodes embedded")
        return self
    
    def _precompute_transition_probs(self):
        """Precompute transition probabilities for biased walks."""
        G = self.G
        
        for source in G.nodes():
            for current in G.neighbors(source):
                probs = []
                neighbors = list(G.neighbors(current))
                
                for neighbor in neighbors:
                    weight = G[current][neighbor].get('weight', 1.0)
                    
                    if neighbor == source:
                        # Return probability
                        prob = weight / self.p
                    elif G.has_edge(neighbor, source):
                        # Distance 1 from source
                        prob = weight
                    else:
                        # Distance 2 from source
                        prob = weight / self.q
                    
                    probs.append(prob)
                
                # Normalize
                probs = np.array(probs)
                probs = probs / probs.sum()
                
                self.transition_probs[(source, current)] = (neighbors, probs)
    
    def _biased_walk(self, start_node: str) -> List[str]:
        """
        Perform a single biased random walk.
        
        Args:
            start_node: Starting node
            
        Returns:
            Walk as list of node IDs
        """
        G = self.G
        walk = [start_node]
        
        # First step: uniform random
        neighbors = list(G.neighbors(start_node))
        if not neighbors:
            return walk
        
        walk.append(random.choice(neighbors))
        
        # Subsequent steps: biased by p and q
        while len(walk) < self.walk_length:
            cur = walk[-1]
            prev = walk[-2]
            
            if (prev, cur) in self.transition_probs:
                neighbors, probs = self.transition_probs[(prev, cur)]
                if neighbors:
                    next_node = np.random.choice(neighbors, p=probs)
                    walk.append(next_node)
                else:
                    break
            else:
                # Fallback to uniform
                neighbors = list(G.neighbors(cur))
                if neighbors:
                    walk.append(random.choice(neighbors))
                else:
                    break
        
        return walk
    
    def _generate_walks(self) -> List[List[str]]:
        """Generate random walks for all nodes."""
        walks = []
        nodes = list(self.G.nodes())
        
        # for _ in tqdm(range(self.num_walks), desc="Generating walks"):
        for _ in range(self.num_walks):
            random.shuffle(nodes)
            for node in nodes:
                walk = self._biased_walk(node)
                # Convert to strings for Word2Vec
                walks.append([str(n) for n in walk])
        
        return walks
    
    def _train_word2vec(self, walks: List[List[str]]):
        """Train Word2Vec model on walks."""
        try:
            from gensim.models import Word2Vec
            
            self.model = Word2Vec(
                sentences=walks,
                vector_size=self.dimensions,
                window=10,
                min_count=0,
                sg=1,  # Skip-gram
                workers=self.workers,
                seed=self.seed if self.seed else 42
            )
            
        except ImportError:
            logger.error("gensim required for Node2Vec. Install: pip install gensim")
            raise
    
    def get_embedding(self, node) -> np.ndarray:
        """
        Get embedding for a single node.
        
        Args:
            node: Node identifier
            
        Returns:
            Embedding vector
        """
        if self.model is None:
            raise ValueError("Model not fitted. Call fit() first.")
        
        return self.model.wv[str(node)]
    
    def get_all_embeddings(self) -> Tuple[np.ndarray, List]:
        """
        Get embeddings for all nodes.
        
        Returns:
            Tuple of (embedding matrix, node list)
        """
        if self.model is None or self.G is None:
            raise ValueError("Model not fitted. Call fit() first.")
        
        nodes = list(self.G.nodes())
        embeddings = np.array([self.model.wv[str(n)] for n in nodes])
        
        return embeddings, nodes
    
    def get_embedding_dict(self) -> Dict[str, np.ndarray]:
        """
        Get embeddings as a dictionary.
        
        Returns:
            Dictionary mapping node to embedding
        """
        if self.model is None or self.G is None:
            raise ValueError("Model not fitted. Call fit() first.")
        
        return {node: self.model.wv[str(node)] for node in self.G.nodes()}
    
    def most_similar(
        self,
        node,
        topn: int = 10
    ) -> List[Tuple[str, float]]:
        """
        Find most similar nodes.
        
        Args:
            node: Query node
            topn: Number of similar nodes
            
        Returns:
            List of (node, similarity) tuples
        """
        if self.model is None:
            raise ValueError("Model not fitted. Call fit() first.")
        
        similar = self.model.wv.most_similar(str(node), topn=topn)
        return similar
    
    def save_embeddings(self, path: str):
        """Save embeddings to file."""
        if self.model is not None:
            self.model.wv.save_word2vec_format(path)
            logger.info(f"Embeddings saved to {path}")
    
    def node_similarity(self, node1, node2) -> float:
        """
        Compute cosine similarity between two nodes.
        
        Args:
            node1: First node
            node2: Second node
            
        Returns:
            Cosine similarity
        """
        if self.model is None:
            raise ValueError("Model not fitted. Call fit() first.")
        
        return self.model.wv.similarity(str(node1), str(node2))


class DeepWalkEmbed:
    """
    DeepWalk implementation.
    
    Similar to Node2Vec but with uniform random walks (p=q=1).
    """
    
    def __init__(
        self,
        dimensions: int = 64,
        walk_length: int = 80,
        num_walks: int = 10,
        workers: int = 4,
        seed: Optional[int] = None
    ):
        """
        Initialize DeepWalk.
        
        Args:
            dimensions: Embedding dimension
            walk_length: Length of each random walk
            num_walks: Number of walks per node
            workers: Parallel workers
            seed: Random seed
        """
        # DeepWalk is Node2Vec with p=q=1
        self.node2vec = Node2VecEmbed(
            dimensions=dimensions,
            walk_length=walk_length,
            num_walks=num_walks,
            p=1.0,
            q=1.0,
            workers=workers,
            seed=seed
        )
    
    def fit(self, G: nx.Graph) -> "DeepWalkEmbed":
        """Fit DeepWalk to graph."""
        self.node2vec.fit(G)
        return self
    
    def get_embedding(self, node) -> np.ndarray:
        """Get embedding for a node."""
        return self.node2vec.get_embedding(node)
    
    def get_all_embeddings(self) -> Tuple[np.ndarray, List]:
        """Get all embeddings."""
        return self.node2vec.get_all_embeddings()
    
    def most_similar(self, node, topn: int = 10):
        """Find similar nodes."""
        return self.node2vec.most_similar(node, topn)
