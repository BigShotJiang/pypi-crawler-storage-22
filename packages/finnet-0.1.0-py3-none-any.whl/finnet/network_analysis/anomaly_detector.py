"""
Anomaly Detector - SNA Unit 5

Network anomaly and outlier detection.
"""

from typing import Dict, List, Optional, Any, Tuple

import numpy as np
import networkx as nx
import pandas as pd

from finnet.utils.logger import get_logger

logger = get_logger(__name__)


class AnomalyDetector:
    """
    Detect anomalies in network structure and behavior.
    
    SNA Unit 5: Anomaly Detection
    - Node outlier detection
    - Structural anomalies
    - Temporal anomalies
    - Community-based anomalies
    """
    
    def __init__(self):
        """Initialize the anomaly detector."""
        pass
    
    def detect_node_outliers(
        self,
        G: nx.Graph,
        method: str = 'zscore',
        threshold: float = 2.0
    ) -> Dict[str, Any]:
        """
        Detect node outliers based on structural properties.
        
        Args:
            G: NetworkX graph
            method: 'zscore', 'iqr', or 'isolation_forest'
            threshold: Detection threshold (std for zscore, multiplier for iqr)
            
        Returns:
            Dictionary with outlier detection results
        """
        # Calculate node features
        degrees = dict(G.degree())
        clustering = nx.clustering(G)
        
        try:
            betweenness = nx.betweenness_centrality(G)
        except Exception:
            betweenness = {n: 0 for n in G.nodes()}
        
        # Create feature matrix
        nodes = list(G.nodes())
        features = np.array([
            [degrees[n], clustering[n], betweenness[n]]
            for n in nodes
        ])
        
        if method == 'zscore':
            outliers = self._zscore_outliers(features, nodes, threshold)
        elif method == 'iqr':
            outliers = self._iqr_outliers(features, nodes, threshold)
        elif method == 'isolation_forest':
            outliers = self._isolation_forest_outliers(features, nodes)
        else:
            raise ValueError(f"Unknown method: {method}")
        
        # Get detailed info for outliers
        outlier_details = []
        for node in outliers:
            outlier_details.append({
                'node': node,
                'degree': degrees[node],
                'clustering': clustering[node],
                'betweenness': betweenness[node],
            })
        
        return {
            'outliers': outliers,
            'outlier_count': len(outliers),
            'outlier_details': outlier_details,
            'method': method,
            'threshold': threshold,
        }
    
    def _zscore_outliers(
        self,
        features: np.ndarray,
        nodes: List[str],
        threshold: float
    ) -> List[str]:
        """Detect outliers using z-score method."""
        mean = np.mean(features, axis=0)
        std = np.std(features, axis=0)
        std[std == 0] = 1  # Avoid division by zero
        
        zscores = np.abs((features - mean) / std)
        max_zscores = np.max(zscores, axis=1)
        
        outlier_mask = max_zscores > threshold
        return [nodes[i] for i in np.where(outlier_mask)[0]]
    
    def _iqr_outliers(
        self,
        features: np.ndarray,
        nodes: List[str],
        multiplier: float
    ) -> List[str]:
        """Detect outliers using IQR method."""
        q1 = np.percentile(features, 25, axis=0)
        q3 = np.percentile(features, 75, axis=0)
        iqr = q3 - q1
        iqr[iqr == 0] = 1
        
        lower = q1 - multiplier * iqr
        upper = q3 + multiplier * iqr
        
        outlier_mask = np.any((features < lower) | (features > upper), axis=1)
        return [nodes[i] for i in np.where(outlier_mask)[0]]
    
    def _isolation_forest_outliers(
        self,
        features: np.ndarray,
        nodes: List[str],
        contamination: float = 0.1
    ) -> List[str]:
        """Detect outliers using Isolation Forest."""
        try:
            from sklearn.ensemble import IsolationForest
            
            clf = IsolationForest(
                contamination=contamination,
                random_state=42
            )
            predictions = clf.fit_predict(features)
            
            return [nodes[i] for i in np.where(predictions == -1)[0]]
        except ImportError:
            logger.warning("sklearn not available, falling back to z-score")
            return self._zscore_outliers(features, nodes, 2.0)
    
    def detect_degree_anomalies(
        self,
        G: nx.Graph,
        threshold: float = 2.0
    ) -> Dict[str, Any]:
        """
        Detect nodes with anomalously high or low degrees.
        
        Args:
            G: NetworkX graph
            threshold: Z-score threshold
            
        Returns:
            Dictionary with degree anomalies
        """
        degrees = np.array([d for _, d in G.degree()])
        nodes = list(G.nodes())
        
        mean = np.mean(degrees)
        std = np.std(degrees)
        
        if std == 0:
            return {'high_degree': [], 'low_degree': [], 'normal': nodes}
        
        zscores = (degrees - mean) / std
        
        high_degree = [nodes[i] for i in np.where(zscores > threshold)[0]]
        low_degree = [nodes[i] for i in np.where(zscores < -threshold)[0]]
        normal = [n for n in nodes if n not in high_degree and n not in low_degree]
        
        return {
            'high_degree': high_degree,
            'low_degree': low_degree,
            'normal': normal,
            'degree_mean': mean,
            'degree_std': std,
        }
    
    def detect_community_outliers(
        self,
        G: nx.Graph,
        partition: Dict[str, int]
    ) -> Dict[str, Any]:
        """
        Detect nodes that don't fit well in their community.
        
        Nodes with more external than internal connections are anomalous.
        
        Args:
            G: NetworkX graph
            partition: Community partition
            
        Returns:
            Dictionary with community-based outliers
        """
        outliers = []
        node_scores = {}
        
        for node in G.nodes():
            node_comm = partition.get(node, -1)
            
            internal = 0
            external = 0
            
            for neighbor in G.neighbors(node):
                neighbor_comm = partition.get(neighbor, -1)
                if neighbor_comm == node_comm:
                    internal += 1
                else:
                    external += 1
            
            total = internal + external
            if total > 0:
                internal_ratio = internal / total
                node_scores[node] = internal_ratio
                
                # Outlier if more external than internal
                if external > internal:
                    outliers.append({
                        'node': node,
                        'community': node_comm,
                        'internal_edges': internal,
                        'external_edges': external,
                        'internal_ratio': internal_ratio,
                    })
        
        return {
            'outliers': outliers,
            'outlier_count': len(outliers),
            'node_scores': node_scores,
        }
    
    def detect_bridge_nodes(self, G: nx.Graph) -> List[str]:
        """
        Detect bridge nodes (articulation points).
        
        Removing these nodes would disconnect the graph.
        
        Args:
            G: NetworkX graph
            
        Returns:
            List of bridge nodes
        """
        if G.is_directed():
            G = G.to_undirected()
        
        bridges = list(nx.articulation_points(G))
        logger.info(f"Found {len(bridges)} bridge nodes")
        return bridges
    
    def detect_temporal_anomalies(
        self,
        temporal_networks: Dict[str, nx.Graph],
        node: str
    ) -> Dict[str, Any]:
        """
        Detect temporal anomalies for a specific node.
        
        Looks for sudden changes in node properties over time.
        
        Args:
            temporal_networks: Dictionary mapping timestamp to network
            node: Node to analyze
            
        Returns:
            Dictionary with temporal anomaly results
        """
        timestamps = sorted(temporal_networks.keys())
        
        degrees = []
        clusterings = []
        
        for ts in timestamps:
            G = temporal_networks[ts]
            if node in G:
                degrees.append(G.degree(node))
                clusterings.append(nx.clustering(G, node))
            else:
                degrees.append(0)
                clusterings.append(0)
        
        degrees = np.array(degrees)
        clusterings = np.array(clusterings)
        
        # Detect sudden changes
        degree_changes = np.abs(np.diff(degrees))
        clustering_changes = np.abs(np.diff(clusterings))
        
        anomaly_threshold = 2.0
        
        degree_anomalies = np.where(
            degree_changes > anomaly_threshold * np.std(degree_changes)
        )[0]
        
        clustering_anomalies = np.where(
            clustering_changes > anomaly_threshold * np.std(clustering_changes)
        )[0]
        
        return {
            'node': node,
            'timestamps': timestamps,
            'degrees': degrees.tolist(),
            'clusterings': clusterings.tolist(),
            'degree_anomaly_indices': degree_anomalies.tolist(),
            'clustering_anomaly_indices': clustering_anomalies.tolist(),
        }
    
    def detect_all_anomalies(
        self,
        G: nx.Graph,
        partition: Optional[Dict[str, int]] = None
    ) -> Dict[str, Any]:
        """
        Run all anomaly detection methods.
        
        Args:
            G: NetworkX graph
            partition: Optional community partition
            
        Returns:
            Comprehensive anomaly report
        """
        results = {}
        
        # Node outliers
        results['node_outliers'] = self.detect_node_outliers(G)
        
        # Degree anomalies
        results['degree_anomalies'] = self.detect_degree_anomalies(G)
        
        # Bridge nodes
        results['bridge_nodes'] = self.detect_bridge_nodes(G)
        
        # Community outliers
        if partition:
            results['community_outliers'] = self.detect_community_outliers(G, partition)
        
        # Summary
        results['summary'] = {
            'total_nodes': G.number_of_nodes(),
            'node_outlier_count': results['node_outliers']['outlier_count'],
            'high_degree_count': len(results['degree_anomalies']['high_degree']),
            'low_degree_count': len(results['degree_anomalies']['low_degree']),
            'bridge_count': len(results['bridge_nodes']),
        }
        
        return results
    
    def get_anomaly_report(
        self,
        results: Dict[str, Any]
    ) -> pd.DataFrame:
        """
        Convert anomaly results to a summary DataFrame.
        
        Args:
            results: Results from detect_all_anomalies()
            
        Returns:
            Summary DataFrame
        """
        data = []
        
        # Node outliers
        for detail in results.get('node_outliers', {}).get('outlier_details', []):
            data.append({
                'node': detail['node'],
                'anomaly_type': 'node_outlier',
                'details': f"degree={detail['degree']}, clustering={detail['clustering']:.3f}"
            })
        
        # High degree
        for node in results.get('degree_anomalies', {}).get('high_degree', []):
            data.append({
                'node': node,
                'anomaly_type': 'high_degree',
                'details': 'Unusually high connectivity'
            })
        
        # Low degree
        for node in results.get('degree_anomalies', {}).get('low_degree', []):
            data.append({
                'node': node,
                'anomaly_type': 'low_degree',
                'details': 'Unusually low connectivity'
            })
        
        # Bridge nodes
        for node in results.get('bridge_nodes', []):
            data.append({
                'node': node,
                'anomaly_type': 'bridge',
                'details': 'Critical for network connectivity'
            })
        
        return pd.DataFrame(data)
