"""
Cascade Model - SNA Unit 4

Information diffusion and cascade models.
"""

from typing import Dict, List, Optional, Set, Tuple, Any
from collections import deque
import random

import numpy as np
import networkx as nx
import pandas as pd

from finnet.utils.logger import get_logger

logger = get_logger(__name__)


class CascadeModel:
    """
    Information cascade and epidemic models.
    
    SNA Unit 4: Cascade and Epidemic Models
    - Independent Cascade (IC) Model
    - Linear Threshold (LT) Model
    - SIR/SIS Epidemic Models
    - Influence maximization
    """
    
    def __init__(self, seed: Optional[int] = None):
        """
        Initialize the cascade model.
        
        Args:
            seed: Random seed for reproducibility
        """
        if seed is not None:
            random.seed(seed)
            np.random.seed(seed)
    
    def independent_cascade(
        self,
        G: nx.Graph,
        seed_nodes: List[str],
        probability: float = 0.1,
        max_steps: int = 100
    ) -> Dict[str, Any]:
        """
        Simulate Independent Cascade model.
        
        Each active node has one chance to activate each inactive neighbor
        with given probability.
        
        Args:
            G: NetworkX graph
            seed_nodes: Initially active nodes
            probability: Activation probability (or use edge weights)
            max_steps: Maximum simulation steps
            
        Returns:
            Dictionary with cascade results
        """
        # Initialize
        active = set(seed_nodes)
        newly_active = set(seed_nodes)
        history = [{
            'step': 0,
            'newly_active': list(seed_nodes),
            'total_active': len(active)
        }]
        
        step = 0
        
        while newly_active and step < max_steps:
            step += 1
            next_active = set()
            
            for node in newly_active:
                for neighbor in G.neighbors(node):
                    if neighbor not in active:
                        # Get edge probability
                        edge_data = G.edges[node, neighbor]
                        p = edge_data.get('weight', probability)
                        p = min(p, 1.0)  # Ensure valid probability
                        
                        if random.random() < p:
                            next_active.add(neighbor)
            
            active.update(next_active)
            newly_active = next_active
            
            history.append({
                'step': step,
                'newly_active': list(newly_active),
                'total_active': len(active)
            })
        
        return {
            'final_active': list(active),
            'total_activated': len(active),
            'num_steps': step,
            'history': history,
            'activation_ratio': len(active) / G.number_of_nodes(),
        }
    
    def linear_threshold(
        self,
        G: nx.Graph,
        seed_nodes: List[str],
        thresholds: Optional[Dict[str, float]] = None,
        max_steps: int = 100
    ) -> Dict[str, Any]:
        """
        Simulate Linear Threshold model.
        
        Each node has a threshold. A node becomes active when the sum
        of weights from active neighbors exceeds the threshold.
        
        Args:
            G: NetworkX graph
            seed_nodes: Initially active nodes
            thresholds: Node thresholds (random if None)
            max_steps: Maximum simulation steps
            
        Returns:
            Dictionary with cascade results
        """
        # Initialize thresholds
        if thresholds is None:
            thresholds = {node: random.random() for node in G.nodes()}
        
        # Calculate incoming weight sum for normalization
        in_weights = {}
        for node in G.nodes():
            total_weight = sum(
                G.edges[n, node].get('weight', 1.0)
                for n in G.neighbors(node)
            )
            in_weights[node] = max(total_weight, 1.0)
        
        # Initialize
        active = set(seed_nodes)
        history = [{
            'step': 0,
            'newly_active': list(seed_nodes),
            'total_active': len(active)
        }]
        
        step = 0
        changed = True
        
        while changed and step < max_steps:
            step += 1
            changed = False
            newly_active = []
            
            for node in G.nodes():
                if node not in active:
                    # Calculate influence from active neighbors
                    influence = 0
                    for neighbor in G.neighbors(node):
                        if neighbor in active:
                            weight = G.edges[neighbor, node].get('weight', 1.0)
                            influence += weight / in_weights[node]
                    
                    # Activate if threshold exceeded
                    if influence >= thresholds[node]:
                        active.add(node)
                        newly_active.append(node)
                        changed = True
            
            history.append({
                'step': step,
                'newly_active': newly_active,
                'total_active': len(active)
            })
        
        return {
            'final_active': list(active),
            'total_activated': len(active),
            'num_steps': step,
            'history': history,
            'activation_ratio': len(active) / G.number_of_nodes(),
        }
    
    def sir_model(
        self,
        G: nx.Graph,
        initial_infected: List[str],
        beta: float = 0.3,
        gamma: float = 0.1,
        max_steps: int = 200
    ) -> Dict[str, Any]:
        """
        Simulate SIR epidemic model.
        
        Susceptible -> Infected -> Recovered
        
        Args:
            G: NetworkX graph
            initial_infected: Initially infected nodes
            beta: Infection rate (probability of S->I per contact)
            gamma: Recovery rate (probability of I->R)
            max_steps: Maximum simulation steps
            
        Returns:
            Dictionary with epidemic results
        """
        # Initialize states
        states = {node: 'S' for node in G.nodes()}
        for node in initial_infected:
            states[node] = 'I'
        
        history = [{
            'step': 0,
            'S': sum(1 for s in states.values() if s == 'S'),
            'I': sum(1 for s in states.values() if s == 'I'),
            'R': 0,
        }]
        
        step = 0
        
        while any(s == 'I' for s in states.values()) and step < max_steps:
            step += 1
            new_states = states.copy()
            
            for node in G.nodes():
                if states[node] == 'I':
                    # Try to infect susceptible neighbors
                    for neighbor in G.neighbors(node):
                        if states[neighbor] == 'S':
                            if random.random() < beta:
                                new_states[neighbor] = 'I'
                    
                    # Try to recover
                    if random.random() < gamma:
                        new_states[node] = 'R'
            
            states = new_states
            
            history.append({
                'step': step,
                'S': sum(1 for s in states.values() if s == 'S'),
                'I': sum(1 for s in states.values() if s == 'I'),
                'R': sum(1 for s in states.values() if s == 'R'),
            })
        
        return {
            'final_states': states,
            'total_infected': sum(1 for s in states.values() if s in ['I', 'R']),
            'total_recovered': sum(1 for s in states.values() if s == 'R'),
            'num_steps': step,
            'history': history,
            'infection_ratio': sum(1 for s in states.values() if s in ['I', 'R']) / G.number_of_nodes(),
        }
    
    def sis_model(
        self,
        G: nx.Graph,
        initial_infected: List[str],
        beta: float = 0.3,
        gamma: float = 0.1,
        max_steps: int = 200
    ) -> Dict[str, Any]:
        """
        Simulate SIS epidemic model.
        
        Susceptible -> Infected -> Susceptible (reinfection possible)
        
        Args:
            G: NetworkX graph
            initial_infected: Initially infected nodes
            beta: Infection rate
            gamma: Recovery rate
            max_steps: Maximum simulation steps
            
        Returns:
            Dictionary with epidemic results
        """
        # Initialize states
        states = {node: 'S' for node in G.nodes()}
        for node in initial_infected:
            states[node] = 'I'
        
        history = [{
            'step': 0,
            'S': sum(1 for s in states.values() if s == 'S'),
            'I': sum(1 for s in states.values() if s == 'I'),
        }]
        
        ever_infected = set(initial_infected)
        
        for step in range(1, max_steps + 1):
            new_states = states.copy()
            
            for node in G.nodes():
                if states[node] == 'I':
                    # Try to infect susceptible neighbors
                    for neighbor in G.neighbors(node):
                        if states[neighbor] == 'S':
                            if random.random() < beta:
                                new_states[neighbor] = 'I'
                                ever_infected.add(neighbor)
                    
                    # Try to recover (become susceptible again)
                    if random.random() < gamma:
                        new_states[node] = 'S'
            
            states = new_states
            
            history.append({
                'step': step,
                'S': sum(1 for s in states.values() if s == 'S'),
                'I': sum(1 for s in states.values() if s == 'I'),
            })
        
        return {
            'final_states': states,
            'total_ever_infected': len(ever_infected),
            'num_steps': max_steps,
            'history': history,
            'endemic_ratio': sum(1 for s in states.values() if s == 'I') / G.number_of_nodes(),
        }
    
    def estimate_influence(
        self,
        G: nx.Graph,
        seed_node: str,
        model: str = 'ic',
        num_simulations: int = 100,
        probability: float = 0.1
    ) -> float:
        """
        Estimate influence of a single seed node.
        
        Args:
            G: NetworkX graph
            seed_node: Node to evaluate
            model: 'ic' or 'lt'
            num_simulations: Number of Monte Carlo simulations
            probability: Propagation probability
            
        Returns:
            Expected number of activated nodes
        """
        total_activated = 0
        
        for _ in range(num_simulations):
            if model == 'ic':
                result = self.independent_cascade(G, [seed_node], probability)
            else:
                result = self.linear_threshold(G, [seed_node])
            
            total_activated += result['total_activated']
        
        return total_activated / num_simulations
    
    def greedy_influence_maximization(
        self,
        G: nx.Graph,
        k: int,
        model: str = 'ic',
        num_simulations: int = 50,
        probability: float = 0.1
    ) -> List[str]:
        """
        Find k most influential seed nodes using greedy algorithm.
        
        Args:
            G: NetworkX graph
            k: Number of seeds to select
            model: 'ic' or 'lt'
            num_simulations: Simulations per evaluation
            probability: Propagation probability
            
        Returns:
            List of k seed nodes
        """
        seeds = []
        candidates = list(G.nodes())
        
        for _ in range(k):
            best_node = None
            best_influence = 0
            
            for candidate in candidates:
                if candidate in seeds:
                    continue
                
                test_seeds = seeds + [candidate]
                
                # Estimate influence
                total = 0
                for _ in range(num_simulations):
                    if model == 'ic':
                        result = self.independent_cascade(G, test_seeds, probability)
                    else:
                        result = self.linear_threshold(G, test_seeds)
                    total += result['total_activated']
                
                avg_influence = total / num_simulations
                
                if avg_influence > best_influence:
                    best_influence = avg_influence
                    best_node = candidate
            
            if best_node:
                seeds.append(best_node)
                logger.debug(f"Selected seed {best_node} with influence {best_influence:.2f}")
        
        return seeds
    
    def get_cascade_timeline(
        self,
        history: List[Dict]
    ) -> pd.DataFrame:
        """
        Convert cascade history to DataFrame.
        
        Args:
            history: History from cascade simulation
            
        Returns:
            DataFrame with timeline
        """
        return pd.DataFrame(history)
