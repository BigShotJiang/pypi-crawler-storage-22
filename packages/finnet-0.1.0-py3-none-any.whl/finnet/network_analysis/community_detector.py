"""
Community Detector - SNA Unit 3

Community detection and clustering algorithms.
"""

from typing import Dict, List, Optional, Any, Tuple

import numpy as np
import networkx as nx
import pandas as pd

from finnet.utils.logger import get_logger

logger = get_logger(__name__)


class CommunityDetector:
    """
    Community detection algorithms for network analysis.
    
    SNA Unit 3: Community Detection
    - Louvain algorithm
    - Girvan-Newman algorithm  
    - Label Propagation
    - Spectral clustering
    - Modularity optimization
    """
    
    def __init__(self):
        """Initialize the community detector."""
        pass
    
    def detect_louvain(
        self,
        G: nx.Graph,
        weight: str = 'weight',
        resolution: float = 1.0
    ) -> Dict[str, int]:
        """
        Detect communities using Louvain algorithm.
        
        Louvain maximizes modularity through hierarchical optimization.
        Fast and produces high-quality partitions.
        
        Args:
            G: NetworkX graph
            weight: Edge weight attribute
            resolution: Resolution parameter (higher = more communities)
            
        Returns:
            Dictionary mapping node to community ID
        """
        try:
            import community as community_louvain
            partition = community_louvain.best_partition(
                G, 
                weight=weight, 
                resolution=resolution
            )
            logger.info(f"Louvain found {len(set(partition.values()))} communities")
            return partition
        except ImportError:
            logger.warning("python-louvain not installed, falling back to label propagation")
            return self.detect_label_propagation(G)
    
    def detect_label_propagation(self, G: nx.Graph) -> Dict[str, int]:
        """
        Detect communities using Label Propagation algorithm.
        
        Fast semi-supervised algorithm that propagates labels through edges.
        
        Args:
            G: NetworkX graph
            
        Returns:
            Dictionary mapping node to community ID
        """
        communities = nx.community.label_propagation_communities(G)
        
        partition = {}
        for comm_id, community in enumerate(communities):
            for node in community:
                partition[node] = comm_id
        
        logger.info(f"Label Propagation found {len(set(partition.values()))} communities")
        return partition
    
    def detect_girvan_newman(
        self,
        G: nx.Graph,
        num_communities: Optional[int] = None
    ) -> List[frozenset]:
        """
        Detect communities using Girvan-Newman algorithm.
        
        Hierarchical divisive algorithm based on edge betweenness.
        Warning: Can be slow for large graphs!
        
        Args:
            G: NetworkX graph
            num_communities: Target number of communities (None = stop at first split)
            
        Returns:
            List of community sets
        """
        communities_generator = nx.community.girvan_newman(G)
        
        if num_communities is None:
            # Get first split
            communities = next(communities_generator)
        else:
            # Iterate until target number
            for communities in communities_generator:
                if len(communities) >= num_communities:
                    break
        
        logger.info(f"Girvan-Newman found {len(communities)} communities")
        return list(communities)
    
    def detect_greedy_modularity(self, G: nx.Graph) -> List[frozenset]:
        """
        Detect communities using greedy modularity optimization.
        
        Args:
            G: NetworkX graph
            
        Returns:
            List of community sets
        """
        communities = nx.community.greedy_modularity_communities(G)
        logger.info(f"Greedy modularity found {len(communities)} communities")
        return list(communities)
    
    def detect_spectral(
        self,
        G: nx.Graph,
        k: int = 5
    ) -> Dict[str, int]:
        """
        Detect communities using spectral clustering.
        
        Uses eigenvectors of the graph Laplacian for clustering.
        
        Args:
            G: NetworkX graph
            k: Number of clusters
            
        Returns:
            Dictionary mapping node to community ID
        """
        try:
            from sklearn.cluster import SpectralClustering
            
            nodes = list(G.nodes())
            A = nx.to_numpy_array(G)
            
            # Spectral clustering
            sc = SpectralClustering(
                n_clusters=min(k, len(nodes)),
                affinity='precomputed',
                assign_labels='kmeans',
                random_state=42
            )
            labels = sc.fit_predict(A)
            
            partition = {node: int(label) for node, label in zip(nodes, labels)}
            logger.info(f"Spectral clustering found {len(set(labels))} communities")
            return partition
            
        except ImportError:
            logger.warning("sklearn not available, falling back to Louvain")
            return self.detect_louvain(G)
    
    def detect_clique_percolation(
        self,
        G: nx.Graph,
        k: int = 3
    ) -> List[frozenset]:
        """
        Detect overlapping communities using k-clique percolation.
        
        Finds communities as unions of k-cliques that share k-1 nodes.
        Allows overlapping communities.
        
        Args:
            G: NetworkX graph
            k: Clique size
            
        Returns:
            List of community sets
        """
        communities = list(nx.community.k_clique_communities(G, k))
        logger.info(f"K-clique percolation (k={k}) found {len(communities)} communities")
        return communities
    
    def calculate_modularity(
        self,
        G: nx.Graph,
        partition: Dict[str, int]
    ) -> float:
        """
        Calculate modularity of a partition.
        
        Modularity measures the quality of community structure.
        Range: -0.5 to 1 (higher is better)
        
        Args:
            G: NetworkX graph
            partition: Node to community mapping
            
        Returns:
            Modularity score
        """
        try:
            import community as community_louvain
            return community_louvain.modularity(partition, G)
        except ImportError:
            # Manual calculation
            communities = {}
            for node, comm in partition.items():
                if comm not in communities:
                    communities[comm] = set()
                communities[comm].add(node)
            
            return nx.community.modularity(G, list(communities.values()))
    
    def get_community_summary(
        self,
        G: nx.Graph,
        partition: Dict[str, int]
    ) -> pd.DataFrame:
        """
        Get summary statistics for each community.
        
        Args:
            G: NetworkX graph
            partition: Node to community mapping
            
        Returns:
            DataFrame with community statistics
        """
        # Group nodes by community
        communities = {}
        for node, comm in partition.items():
            if comm not in communities:
                communities[comm] = []
            communities[comm].append(node)
        
        summaries = []
        
        for comm_id, nodes in communities.items():
            subG = G.subgraph(nodes)
            
            summaries.append({
                'community_id': comm_id,
                'size': len(nodes),
                'density': nx.density(subG) if len(nodes) > 1 else 0,
                'avg_degree': np.mean([subG.degree(n) for n in nodes]) if nodes else 0,
                'internal_edges': subG.number_of_edges(),
                'nodes': ', '.join(nodes[:5]) + ('...' if len(nodes) > 5 else ''),
            })
        
        return pd.DataFrame(summaries).sort_values('size', ascending=False)
    
    def detect_all(
        self,
        G: nx.Graph
    ) -> Dict[str, Dict[str, int]]:
        """
        Run multiple community detection algorithms.
        
        Args:
            G: NetworkX graph
            
        Returns:
            Dictionary mapping algorithm name to partition
        """
        results = {}
        
        # Louvain
        try:
            results['louvain'] = self.detect_louvain(G)
        except Exception as e:
            logger.debug(f"Louvain failed: {e}")
        
        # Label Propagation
        try:
            results['label_propagation'] = self.detect_label_propagation(G)
        except Exception as e:
            logger.debug(f"Label Propagation failed: {e}")
        
        # Greedy Modularity
        try:
            communities = self.detect_greedy_modularity(G)
            partition = {}
            for i, comm in enumerate(communities):
                for node in comm:
                    partition[node] = i
            results['greedy_modularity'] = partition
        except Exception as e:
            logger.debug(f"Greedy Modularity failed: {e}")
        
        return results
    
    def compare_partitions(
        self,
        partition1: Dict[str, int],
        partition2: Dict[str, int]
    ) -> Dict[str, float]:
        """
        Compare two partitions using various metrics.
        
        Args:
            partition1: First partition
            partition2: Second partition
            
        Returns:
            Dictionary with comparison metrics
        """
        # Get common nodes
        common_nodes = set(partition1.keys()) & set(partition2.keys())
        
        if not common_nodes:
            return {'error': 'No common nodes'}
        
        # Extract labels for common nodes
        labels1 = [partition1[n] for n in common_nodes]
        labels2 = [partition2[n] for n in common_nodes]
        
        try:
            from sklearn.metrics import adjusted_rand_score, normalized_mutual_info_score
            
            return {
                'adjusted_rand_index': adjusted_rand_score(labels1, labels2),
                'normalized_mutual_info': normalized_mutual_info_score(labels1, labels2),
                'num_communities_1': len(set(labels1)),
                'num_communities_2': len(set(labels2)),
            }
        except ImportError:
            return {
                'num_communities_1': len(set(labels1)),
                'num_communities_2': len(set(labels2)),
            }
    
    def get_node_community_membership(
        self,
        partitions: Dict[str, Dict[str, int]]
    ) -> pd.DataFrame:
        """
        Get community membership for each node across algorithms.
        
        Args:
            partitions: Dictionary of partitions from different algorithms
            
        Returns:
            DataFrame with node memberships
        """
        all_nodes = set()
        for partition in partitions.values():
            all_nodes.update(partition.keys())
        
        data = []
        for node in all_nodes:
            row = {'node': node}
            for algo, partition in partitions.items():
                row[f'{algo}_community'] = partition.get(node, -1)
            data.append(row)
        
        return pd.DataFrame(data)
