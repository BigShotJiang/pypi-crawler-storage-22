"""
Link Analyzer - SNA Unit 2

PageRank, link prediction, and related algorithms.
"""

from typing import Dict, List, Tuple, Optional, Any

import numpy as np
import networkx as nx
import pandas as pd

from finnet.utils.logger import get_logger

logger = get_logger(__name__)


class LinkAnalyzer:
    """
    Link analysis algorithms for networks.
    
    SNA Unit 2: Link Analysis
    - PageRank variants
    - HITS algorithm
    - Link prediction methods
    - SimRank
    """
    
    def __init__(self):
        """Initialize the link analyzer."""
        pass
    
    def pagerank(
        self,
        G: nx.Graph,
        alpha: float = 0.85,
        personalization: Optional[Dict[str, float]] = None,
        max_iter: int = 100
    ) -> Dict[str, float]:
        """
        Calculate PageRank scores.
        
        Args:
            G: NetworkX graph
            alpha: Damping factor (probability of following a link)
            personalization: Personal PageRank vector
            max_iter: Maximum iterations
            
        Returns:
            Dictionary mapping node to PageRank score
        """
        return nx.pagerank(G, alpha=alpha, personalization=personalization, max_iter=max_iter)
    
    def hits(self, G: nx.Graph, max_iter: int = 100) -> Tuple[Dict, Dict]:
        """
        Calculate HITS hub and authority scores.
        
        Hubs: nodes that point to good authorities
        Authorities: nodes pointed to by good hubs
        
        Args:
            G: NetworkX graph
            max_iter: Maximum iterations
            
        Returns:
            Tuple of (hub_scores, authority_scores)
        """
        # Convert to directed graph if undirected
        if not G.is_directed():
            G = G.to_directed()
        
        hub_scores, authority_scores = nx.hits(G, max_iter=max_iter)
        return hub_scores, authority_scores
    
    def predict_links_common_neighbors(
        self,
        G: nx.Graph,
        node_pairs: Optional[List[Tuple]] = None,
        top_k: int = 10
    ) -> List[Tuple[str, str, float]]:
        """
        Predict links using common neighbors.
        
        Args:
            G: NetworkX graph
            node_pairs: Specific pairs to evaluate (None = all non-edges)
            top_k: Number of top predictions
            
        Returns:
            List of (node1, node2, score) tuples
        """
        if node_pairs is None:
            node_pairs = nx.non_edges(G)
        
        predictions = list(nx.common_neighbor_centrality(G, node_pairs))
        predictions.sort(key=lambda x: x[2], reverse=True)
        
        return predictions[:top_k]
    
    def predict_links_jaccard(
        self,
        G: nx.Graph,
        top_k: int = 10
    ) -> List[Tuple[str, str, float]]:
        """
        Predict links using Jaccard coefficient.
        
        Jaccard = |N(u) ∩ N(v)| / |N(u) ∪ N(v)|
        
        Args:
            G: NetworkX graph
            top_k: Number of top predictions
            
        Returns:
            List of (node1, node2, score) tuples
        """
        predictions = list(nx.jaccard_coefficient(G))
        predictions.sort(key=lambda x: x[2], reverse=True)
        
        return predictions[:top_k]
    
    def predict_links_adamic_adar(
        self,
        G: nx.Graph,
        top_k: int = 10
    ) -> List[Tuple[str, str, float]]:
        """
        Predict links using Adamic-Adar index.
        
        Adamic-Adar = Σ 1/log(|N(w)|) for w in N(u) ∩ N(v)
        
        Args:
            G: NetworkX graph
            top_k: Number of top predictions
            
        Returns:
            List of (node1, node2, score) tuples
        """
        predictions = list(nx.adamic_adar_index(G))
        predictions.sort(key=lambda x: x[2], reverse=True)
        
        return predictions[:top_k]
    
    def predict_links_preferential_attachment(
        self,
        G: nx.Graph,
        top_k: int = 10
    ) -> List[Tuple[str, str, float]]:
        """
        Predict links using preferential attachment.
        
        PA = |N(u)| × |N(v)|
        
        Args:
            G: NetworkX graph
            top_k: Number of top predictions
            
        Returns:
            List of (node1, node2, score) tuples
        """
        predictions = list(nx.preferential_attachment(G))
        predictions.sort(key=lambda x: x[2], reverse=True)
        
        return predictions[:top_k]
    
    def predict_links_resource_allocation(
        self,
        G: nx.Graph,
        top_k: int = 10
    ) -> List[Tuple[str, str, float]]:
        """
        Predict links using resource allocation index.
        
        RA = Σ 1/|N(w)| for w in N(u) ∩ N(v)
        
        Args:
            G: NetworkX graph
            top_k: Number of top predictions
            
        Returns:
            List of (node1, node2, score) tuples
        """
        predictions = list(nx.resource_allocation_index(G))
        predictions.sort(key=lambda x: x[2], reverse=True)
        
        return predictions[:top_k]
    
    def simrank(
        self,
        G: nx.Graph,
        source: str,
        target: str,
        importance_factor: float = 0.9,
        max_iter: int = 100
    ) -> float:
        """
        Calculate SimRank similarity between two nodes.
        
        SimRank: Two nodes are similar if their neighbors are similar.
        
        Args:
            G: NetworkX graph
            source: Source node
            target: Target node
            importance_factor: Decay factor
            max_iter: Maximum iterations
            
        Returns:
            Similarity score
        """
        return nx.simrank_similarity(
            G,
            source=source,
            target=target,
            importance_factor=importance_factor,
            max_iterations=max_iter
        )
    
    def simrank_all_pairs(
        self,
        G: nx.Graph,
        importance_factor: float = 0.9
    ) -> Dict[str, Dict[str, float]]:
        """
        Calculate SimRank for all pairs of nodes.
        
        Warning: This can be slow for large graphs!
        
        Args:
            G: NetworkX graph
            importance_factor: Decay factor
            
        Returns:
            Nested dictionary of similarity scores
        """
        return nx.simrank_similarity(G, importance_factor=importance_factor)
    
    def link_prediction_summary(
        self,
        G: nx.Graph,
        methods: Optional[List[str]] = None,
        top_k: int = 10
    ) -> pd.DataFrame:
        """
        Run multiple link prediction methods and compare.
        
        Args:
            G: NetworkX graph
            methods: List of methods to use
            top_k: Top predictions per method
            
        Returns:
            DataFrame comparing methods
        """
        if methods is None:
            methods = ['common_neighbors', 'jaccard', 'adamic_adar', 
                      'preferential_attachment', 'resource_allocation']
        
        method_funcs = {
            'common_neighbors': self.predict_links_common_neighbors,
            'jaccard': self.predict_links_jaccard,
            'adamic_adar': self.predict_links_adamic_adar,
            'preferential_attachment': self.predict_links_preferential_attachment,
            'resource_allocation': self.predict_links_resource_allocation,
        }
        
        all_predictions = []
        
        for method in methods:
            if method in method_funcs:
                preds = method_funcs[method](G, top_k=top_k)
                for u, v, score in preds:
                    all_predictions.append({
                        'method': method,
                        'node1': u,
                        'node2': v,
                        'score': score
                    })
        
        return pd.DataFrame(all_predictions)
    
    def evaluate_link_prediction(
        self,
        G: nx.Graph,
        test_edges: List[Tuple[str, str]],
        method: str = 'adamic_adar'
    ) -> Dict[str, float]:
        """
        Evaluate link prediction on known edges.
        
        Args:
            G: NetworkX graph (with test edges removed)
            test_edges: True positive edges
            method: Prediction method to use
            
        Returns:
            Evaluation metrics
        """
        # Get predictions
        method_funcs = {
            'common_neighbors': self.predict_links_common_neighbors,
            'jaccard': self.predict_links_jaccard,
            'adamic_adar': self.predict_links_adamic_adar,
            'preferential_attachment': self.predict_links_preferential_attachment,
            'resource_allocation': self.predict_links_resource_allocation,
        }
        
        predictions = method_funcs.get(method, self.predict_links_adamic_adar)(
            G, top_k=len(test_edges) * 2
        )
        
        # Convert to sets for comparison
        predicted_set = {(min(u, v), max(u, v)) for u, v, _ in predictions}
        true_set = {(min(u, v), max(u, v)) for u, v in test_edges}
        
        # Calculate metrics
        true_positives = len(predicted_set & true_set)
        false_positives = len(predicted_set - true_set)
        false_negatives = len(true_set - predicted_set)
        
        precision = true_positives / max(len(predicted_set), 1)
        recall = true_positives / max(len(true_set), 1)
        f1 = 2 * precision * recall / max(precision + recall, 1e-10)
        
        return {
            'precision': precision,
            'recall': recall,
            'f1': f1,
            'true_positives': true_positives,
            'false_positives': false_positives,
            'false_negatives': false_negatives,
        }
