"""
Network Metrics Calculator - SNA Unit 1

Compute network measures including centrality, clustering, and other metrics.
"""

from typing import Dict, List, Any, Optional, Tuple

import numpy as np
import networkx as nx
import pandas as pd

from finnet.utils.logger import get_logger

logger = get_logger(__name__)


class NetworkMetricsCalculator:
    """
    Calculate network metrics for social network analysis.
    
    SNA Unit 1: Network Measures
    - Degree centrality
    - Betweenness centrality  
    - Closeness centrality
    - Eigenvector centrality
    - Clustering coefficient
    - Network-level statistics
    """
    
    def __init__(self):
        """Initialize the metrics calculator."""
        pass
    
    def calculate_all_metrics(
        self,
        G: nx.Graph,
        include_expensive: bool = True
    ) -> Dict[str, Any]:
        """
        Calculate all available network metrics.
        
        Args:
            G: NetworkX graph
            include_expensive: Include computationally expensive metrics
            
        Returns:
            Dictionary with all metrics
        """
        if G.number_of_nodes() == 0:
            return {}
        
        metrics = {}
        
        # Node-level centrality metrics
        metrics['degree_centrality'] = self.degree_centrality(G)
        metrics['closeness_centrality'] = self.closeness_centrality(G)
        metrics['clustering'] = self.local_clustering(G)
        
        if include_expensive:
            metrics['betweenness_centrality'] = self.betweenness_centrality(G)
            
            # Eigenvector centrality may not converge for all graphs
            try:
                metrics['eigenvector_centrality'] = self.eigenvector_centrality(G)
            except nx.PowerIterationFailedConvergence:
                logger.warning("Eigenvector centrality failed to converge")
        
        # PageRank
        metrics['pagerank'] = self.pagerank(G)
        
        # Network-level metrics
        metrics['network_stats'] = self.network_statistics(G)
        
        # Degree distribution
        metrics['degree_distribution'] = self.degree_distribution(G)
        
        logger.info(f"Calculated metrics for graph with {G.number_of_nodes()} nodes")
        return metrics
    
    def degree_centrality(self, G: nx.Graph) -> Dict[str, float]:
        """
        Calculate degree centrality for all nodes.
        
        Args:
            G: NetworkX graph
            
        Returns:
            Dictionary mapping node to degree centrality
        """
        return nx.degree_centrality(G)
    
    def weighted_degree(self, G: nx.Graph) -> Dict[str, float]:
        """
        Calculate weighted degree (strength) for each node.
        
        Args:
            G: NetworkX graph with weighted edges
            
        Returns:
            Dictionary mapping node to weighted degree
        """
        weighted_degrees = {}
        for node in G.nodes():
            total_weight = sum(
                data.get('weight', 1.0)
                for _, _, data in G.edges(node, data=True)
            )
            weighted_degrees[node] = total_weight
        return weighted_degrees
    
    def betweenness_centrality(
        self,
        G: nx.Graph,
        normalized: bool = True,
        weight: Optional[str] = None
    ) -> Dict[str, float]:
        """
        Calculate betweenness centrality.
        
        Betweenness measures how often a node lies on shortest paths
        between other nodes. High betweenness = broker/bridge node.
        
        Args:
            G: NetworkX graph
            normalized: Normalize values
            weight: Edge weight attribute (None for unweighted)
            
        Returns:
            Dictionary mapping node to betweenness centrality
        """
        return nx.betweenness_centrality(G, normalized=normalized, weight=weight)
    
    def closeness_centrality(
        self,
        G: nx.Graph,
        distance: Optional[str] = None
    ) -> Dict[str, float]:
        """
        Calculate closeness centrality.
        
        Closeness measures how close a node is to all other nodes.
        
        Args:
            G: NetworkX graph
            distance: Edge attribute for distance
            
        Returns:
            Dictionary mapping node to closeness centrality
        """
        return nx.closeness_centrality(G, distance=distance)
    
    def eigenvector_centrality(
        self,
        G: nx.Graph,
        max_iter: int = 100,
        tol: float = 1e-6
    ) -> Dict[str, float]:
        """
        Calculate eigenvector centrality.
        
        Eigenvector centrality accounts for the importance of neighbors.
        A node is important if it's connected to other important nodes.
        
        Args:
            G: NetworkX graph
            max_iter: Maximum iterations
            tol: Convergence tolerance
            
        Returns:
            Dictionary mapping node to eigenvector centrality
        """
        return nx.eigenvector_centrality(G, max_iter=max_iter, tol=tol)
    
    def pagerank(
        self,
        G: nx.Graph,
        alpha: float = 0.85,
        max_iter: int = 100
    ) -> Dict[str, float]:
        """
        Calculate PageRank scores.
        
        PageRank is a variant of eigenvector centrality with damping.
        
        Args:
            G: NetworkX graph
            alpha: Damping factor
            max_iter: Maximum iterations
            
        Returns:
            Dictionary mapping node to PageRank score
        """
        return nx.pagerank(G, alpha=alpha, max_iter=max_iter)
    
    def local_clustering(self, G: nx.Graph) -> Dict[str, float]:
        """
        Calculate local clustering coefficient for each node.
        
        Measures how connected a node's neighbors are to each other.
        
        Args:
            G: NetworkX graph
            
        Returns:
            Dictionary mapping node to clustering coefficient
        """
        return nx.clustering(G)
    
    def network_statistics(self, G: nx.Graph) -> Dict[str, Any]:
        """
        Calculate network-level statistics.
        
        Args:
            G: NetworkX graph
            
        Returns:
            Dictionary with network statistics
        """
        stats = {
            'num_nodes': G.number_of_nodes(),
            'num_edges': G.number_of_edges(),
        }
        
        if G.number_of_nodes() == 0:
            return stats
        
        # Density
        stats['density'] = nx.density(G)
        
        # Average clustering
        stats['avg_clustering'] = nx.average_clustering(G)
        
        # Degree statistics
        degrees = [d for _, d in G.degree()]
        stats['avg_degree'] = np.mean(degrees)
        stats['max_degree'] = max(degrees)
        stats['min_degree'] = min(degrees)
        stats['degree_std'] = np.std(degrees)
        
        # Connectivity
        stats['is_connected'] = nx.is_connected(G)
        stats['num_connected_components'] = nx.number_connected_components(G)
        
        # Diameter and average path length (only for connected graphs)
        if stats['is_connected'] and G.number_of_nodes() > 1:
            stats['diameter'] = nx.diameter(G)
            stats['avg_path_length'] = nx.average_shortest_path_length(G)
        else:
            # Use largest connected component
            if stats['num_connected_components'] > 0:
                largest_cc = max(nx.connected_components(G), key=len)
                subG = G.subgraph(largest_cc)
                if subG.number_of_nodes() > 1:
                    stats['diameter'] = nx.diameter(subG)
                    stats['avg_path_length'] = nx.average_shortest_path_length(subG)
        
        # Transitivity (global clustering)
        stats['transitivity'] = nx.transitivity(G)
        
        # Assortativity
        try:
            stats['degree_assortativity'] = nx.degree_assortativity_coefficient(G)
        except Exception:
            stats['degree_assortativity'] = None
        
        return stats
    
    def degree_distribution(self, G: nx.Graph) -> Dict[str, Any]:
        """
        Calculate degree distribution statistics.
        
        Args:
            G: NetworkX graph
            
        Returns:
            Dictionary with degree distribution data
        """
        degrees = [d for _, d in G.degree()]
        
        if not degrees:
            return {}
        
        unique, counts = np.unique(degrees, return_counts=True)
        
        return {
            'degrees': degrees,
            'unique_degrees': unique.tolist(),
            'counts': counts.tolist(),
            'mean': np.mean(degrees),
            'median': np.median(degrees),
            'std': np.std(degrees),
            'min': min(degrees),
            'max': max(degrees),
        }
    
    def get_top_nodes(
        self,
        centrality: Dict[str, float],
        n: int = 10
    ) -> List[Tuple[str, float]]:
        """
        Get top N nodes by centrality measure.
        
        Args:
            centrality: Dictionary of centrality values
            n: Number of top nodes
            
        Returns:
            List of (node, value) tuples
        """
        return sorted(centrality.items(), key=lambda x: x[1], reverse=True)[:n]
    
    def get_node_ranking(
        self,
        G: nx.Graph,
        metric: str = 'pagerank',
        n: int = 10
    ) -> pd.DataFrame:
        """
        Get node ranking by specified metric.
        
        Args:
            G: NetworkX graph
            metric: Metric to rank by
            n: Number of top nodes
            
        Returns:
            DataFrame with node rankings
        """
        metrics_map = {
            'degree': lambda g: dict(g.degree()),
            'degree_centrality': nx.degree_centrality,
            'betweenness': nx.betweenness_centrality,
            'closeness': nx.closeness_centrality,
            'pagerank': nx.pagerank,
            'clustering': nx.clustering,
        }
        
        if metric not in metrics_map:
            raise ValueError(f"Unknown metric: {metric}")
        
        values = metrics_map[metric](G)
        top_nodes = self.get_top_nodes(values, n)
        
        df = pd.DataFrame(top_nodes, columns=['node', metric])
        df['rank'] = range(1, len(df) + 1)
        
        return df
    
    def compare_centralities(self, G: nx.Graph) -> pd.DataFrame:
        """
        Compare different centrality measures for all nodes.
        
        Args:
            G: NetworkX graph
            
        Returns:
            DataFrame with all centrality measures
        """
        nodes = list(G.nodes())
        
        data = {
            'node': nodes,
            'degree': [G.degree(n) for n in nodes],
            'degree_centrality': [nx.degree_centrality(G)[n] for n in nodes],
            'betweenness': [nx.betweenness_centrality(G)[n] for n in nodes],
            'closeness': [nx.closeness_centrality(G)[n] for n in nodes],
            'pagerank': [nx.pagerank(G)[n] for n in nodes],
            'clustering': [nx.clustering(G)[n] for n in nodes],
        }
        
        try:
            eigen = nx.eigenvector_centrality(G)
            data['eigenvector'] = [eigen[n] for n in nodes]
        except Exception:
            pass
        
        return pd.DataFrame(data).sort_values('pagerank', ascending=False)
