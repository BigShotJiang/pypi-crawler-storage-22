"""
Financial Network Builder

Build various types of financial networks from data.
"""

from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime

import pandas as pd
import numpy as np
import networkx as nx

from finnet.utils.logger import get_logger

logger = get_logger(__name__)


class FinancialNetworkBuilder:
    """
    Build financial networks from various data sources.
    
    Network Types:
    - Correlation Network: Edges based on price correlation
    - Sentiment Network: Edges based on sentiment similarity
    - Sector Network: Edges based on sector/industry
    - Co-mention Network: Edges based on social media co-mentions
    - Temporal Network: Time-varying networks
    - Multi-layer Network: Combined networks
    """
    
    def __init__(self):
        """Initialize the network builder."""
        self.networks: Dict[str, nx.Graph] = {}
        self.metadata: Dict[str, Dict] = {}
    
    def build_correlation_network(
        self,
        stock_df: pd.DataFrame,
        threshold: float = 0.5,
        method: str = 'pearson',
        min_periods: int = 20
    ) -> nx.Graph:
        """
        Build network based on stock price correlations.
        
        Args:
            stock_df: DataFrame with stock prices (columns = tickers)
            threshold: Minimum correlation for edge creation
            method: Correlation method ('pearson', 'spearman', 'kendall')
            min_periods: Minimum periods for correlation
            
        Returns:
            NetworkX Graph
        """
        if stock_df.empty:
            return nx.Graph()
        
        # Calculate returns
        returns = stock_df.pct_change().dropna()
        
        if len(returns) < min_periods:
            logger.warning(f"Insufficient data: {len(returns)} < {min_periods}")
            return nx.Graph()
        
        # Calculate correlation matrix
        corr_matrix = returns.corr(method=method, min_periods=min_periods)
        
        # Build graph
        G = nx.Graph()
        tickers = list(corr_matrix.columns)
        
        # Add nodes
        for ticker in tickers:
            G.add_node(ticker, type='stock')
        
        # Add edges
        for i, t1 in enumerate(tickers):
            for t2 in tickers[i+1:]:
                corr = corr_matrix.loc[t1, t2]
                if pd.notna(corr) and abs(corr) >= threshold:
                    G.add_edge(t1, t2,
                        weight=abs(corr),
                        correlation=corr,
                        edge_type='positive' if corr > 0 else 'negative'
                    )
        
        # Store metadata
        self.networks['correlation'] = G
        self.metadata['correlation'] = {
            'threshold': threshold,
            'method': method,
            'created_at': datetime.now(),
            'nodes': G.number_of_nodes(),
            'edges': G.number_of_edges(),
        }
        
        logger.info(f"Built correlation network: {G.number_of_nodes()} nodes, {G.number_of_edges()} edges")
        return G
    
    def build_sentiment_network(
        self,
        sentiment_df: pd.DataFrame,
        ticker_column: str = 'ticker',
        score_column: str = 'sentiment_score',
        threshold: float = 0.6
    ) -> nx.Graph:
        """
        Build network based on sentiment similarity.
        
        Two tickers are connected if their sentiment time series are similar.
        
        Args:
            sentiment_df: DataFrame with sentiment data
            ticker_column: Column with ticker symbols
            score_column: Column with sentiment scores
            threshold: Minimum similarity for edge
            
        Returns:
            NetworkX Graph
        """
        if sentiment_df.empty:
            return nx.Graph()
        
        # Aggregate sentiment by ticker and date
        if 'date' in sentiment_df.columns:
            date_col = 'date'
        elif 'created' in sentiment_df.columns:
            date_col = 'created'
            sentiment_df['date'] = pd.to_datetime(sentiment_df[date_col]).dt.date
        else:
            # Just use ticker-level aggregation
            agg = sentiment_df.groupby(ticker_column)[score_column].mean()
            
            G = nx.Graph()
            tickers = list(agg.index)
            
            for ticker in tickers:
                G.add_node(ticker, sentiment=agg[ticker])
            
            # Connect tickers with similar sentiment
            for i, t1 in enumerate(tickers):
                for t2 in tickers[i+1:]:
                    similarity = 1 - abs(agg[t1] - agg[t2])
                    if similarity >= threshold:
                        G.add_edge(t1, t2, weight=similarity)
            
            self.networks['sentiment'] = G
            logger.info(f"Built sentiment network: {G.number_of_nodes()} nodes, {G.number_of_edges()} edges")
            return G
        
        # Time-based sentiment similarity
        pivot = sentiment_df.pivot_table(
            index='date',
            columns=ticker_column,
            values=score_column,
            aggfunc='mean'
        )
        
        if pivot.empty:
            return nx.Graph()
        
        # Calculate correlation
        corr_matrix = pivot.corr()
        
        G = nx.Graph()
        tickers = list(corr_matrix.columns)
        
        for ticker in tickers:
            G.add_node(ticker, type='stock')
        
        for i, t1 in enumerate(tickers):
            for t2 in tickers[i+1:]:
                corr = corr_matrix.loc[t1, t2]
                if pd.notna(corr) and abs(corr) >= threshold:
                    G.add_edge(t1, t2, weight=abs(corr))
        
        self.networks['sentiment'] = G
        logger.info(f"Built sentiment network: {G.number_of_nodes()} nodes, {G.number_of_edges()} edges")
        return G
    
    def build_sector_network(
        self,
        company_info: Dict[str, Dict]
    ) -> nx.Graph:
        """
        Build network connecting stocks in the same sector/industry.
        
        Args:
            company_info: Dictionary mapping ticker to company info
            
        Returns:
            NetworkX Graph
        """
        if not company_info:
            return nx.Graph()
        
        G = nx.Graph()
        
        # Group by sector and industry
        sector_groups: Dict[str, List[str]] = {}
        industry_groups: Dict[str, List[str]] = {}
        
        for ticker, info in company_info.items():
            if not isinstance(info, dict):
                continue
                
            sector = info.get('sector', 'Unknown')
            industry = info.get('industry', 'Unknown')
            
            G.add_node(ticker,
                sector=sector,
                industry=industry,
                market_cap=info.get('market_cap', 0)
            )
            
            if sector not in sector_groups:
                sector_groups[sector] = []
            sector_groups[sector].append(ticker)
            
            if industry not in industry_groups:
                industry_groups[industry] = []
            industry_groups[industry].append(ticker)
        
        # Connect stocks in same industry (stronger connection)
        for industry, tickers in industry_groups.items():
            if industry == 'Unknown':
                continue
            for i, t1 in enumerate(tickers):
                for t2 in tickers[i+1:]:
                    G.add_edge(t1, t2, weight=1.0, connection_type='industry')
        
        # Connect stocks in same sector but different industry (weaker)
        for sector, tickers in sector_groups.items():
            if sector == 'Unknown':
                continue
            for i, t1 in enumerate(tickers):
                for t2 in tickers[i+1:]:
                    if not G.has_edge(t1, t2):
                        G.add_edge(t1, t2, weight=0.5, connection_type='sector')
        
        self.networks['sector'] = G
        logger.info(f"Built sector network: {G.number_of_nodes()} nodes, {G.number_of_edges()} edges")
        return G
    
    def build_comention_network(
        self,
        co_mention_matrix: pd.DataFrame,
        min_mentions: int = 2
    ) -> nx.Graph:
        """
        Build network from co-mention data.
        
        Args:
            co_mention_matrix: Matrix of co-mention counts
            min_mentions: Minimum co-mentions for edge
            
        Returns:
            NetworkX Graph
        """
        if co_mention_matrix.empty:
            return nx.Graph()
        
        G = nx.Graph()
        
        tickers = list(co_mention_matrix.columns)
        
        for ticker in tickers:
            G.add_node(ticker)
        
        for i, t1 in enumerate(tickers):
            for t2 in tickers[i+1:]:
                count = co_mention_matrix.loc[t1, t2]
                if count >= min_mentions:
                    G.add_edge(t1, t2, weight=count, co_mentions=count)
        
        self.networks['comention'] = G
        logger.info(f"Built co-mention network: {G.number_of_nodes()} nodes, {G.number_of_edges()} edges")
        return G
    
    def build_temporal_network(
        self,
        stock_df: pd.DataFrame,
        window_size: int = 30,
        step_size: int = 5,
        threshold: float = 0.5
    ) -> Dict[str, nx.Graph]:
        """
        Build a series of networks over time.
        
        Args:
            stock_df: DataFrame with stock prices
            window_size: Window size for each network (days)
            step_size: Step between windows
            threshold: Correlation threshold
            
        Returns:
            Dictionary mapping date to network
        """
        temporal_networks = {}
        
        dates = stock_df.index
        
        for i in range(0, len(dates) - window_size, step_size):
            end_idx = i + window_size
            window_data = stock_df.iloc[i:end_idx]
            
            G = self.build_correlation_network(
                window_data,
                threshold=threshold
            )
            
            window_end = str(dates[end_idx - 1].date())
            temporal_networks[window_end] = G
        
        self.networks['temporal'] = temporal_networks
        logger.info(f"Built {len(temporal_networks)} temporal networks")
        return temporal_networks
    
    def build_multilayer_network(
        self,
        networks: Optional[Dict[str, nx.Graph]] = None,
        weights: Optional[Dict[str, float]] = None
    ) -> nx.Graph:
        """
        Combine multiple network layers into one.
        
        Args:
            networks: Dictionary of networks to combine
            weights: Optional weights for each network type
            
        Returns:
            Combined NetworkX Graph
        """
        if networks is None:
            networks = {k: v for k, v in self.networks.items() 
                       if isinstance(v, nx.Graph)}
        
        if not networks:
            return nx.Graph()
        
        if weights is None:
            weights = {k: 1.0 for k in networks.keys()}
        
        # Get all nodes
        all_nodes = set()
        for G in networks.values():
            all_nodes.update(G.nodes())
        
        # Create combined graph
        combined = nx.Graph()
        combined.add_nodes_from(all_nodes)
        
        # Combine edges
        edge_weights: Dict[Tuple[str, str], float] = {}
        
        for net_name, G in networks.items():
            net_weight = weights.get(net_name, 1.0)
            
            for u, v, data in G.edges(data=True):
                edge_key = tuple(sorted([u, v]))
                edge_weight = data.get('weight', 1.0) * net_weight
                
                if edge_key in edge_weights:
                    edge_weights[edge_key] += edge_weight
                else:
                    edge_weights[edge_key] = edge_weight
        
        # Add edges to combined graph
        for (u, v), weight in edge_weights.items():
            combined.add_edge(u, v, weight=weight)
        
        self.networks['multilayer'] = combined
        logger.info(f"Built multilayer network: {combined.number_of_nodes()} nodes, {combined.number_of_edges()} edges")
        return combined
    
    def export_network(
        self,
        G: nx.Graph,
        filepath: str,
        format: str = 'gexf'
    ):
        """
        Export network to file.
        
        Args:
            G: Network to export
            filepath: Output file path
            format: 'gexf', 'graphml', 'edgelist', 'adjacency'
        """
        if format == 'gexf':
            nx.write_gexf(G, filepath)
        elif format == 'graphml':
            nx.write_graphml(G, filepath)
        elif format == 'edgelist':
            nx.write_edgelist(G, filepath)
        elif format == 'adjacency':
            nx.write_adjlist(G, filepath)
        else:
            raise ValueError(f"Unknown format: {format}")
        
        logger.info(f"Exported network to {filepath}")
    
    def get_adjacency_matrix(
        self,
        G: nx.Graph,
        weighted: bool = True
    ) -> Tuple[np.ndarray, List[str]]:
        """
        Get adjacency matrix from network.
        
        Args:
            G: NetworkX graph
            weighted: Use edge weights
            
        Returns:
            Tuple of (adjacency matrix, node list)
        """
        nodes = list(G.nodes())
        n = len(nodes)
        
        if weighted:
            A = nx.to_numpy_array(G, nodelist=nodes, weight='weight')
        else:
            A = nx.to_numpy_array(G, nodelist=nodes, weight=None)
        
        return A, nodes
    
    def get_network(self, name: str) -> Optional[nx.Graph]:
        """Get a stored network by name."""
        return self.networks.get(name)
    
    def list_networks(self) -> List[str]:
        """List all stored network names."""
        return list(self.networks.keys())
