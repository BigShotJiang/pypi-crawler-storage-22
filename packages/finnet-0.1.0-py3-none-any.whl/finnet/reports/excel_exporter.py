"""Excel Exporter - Export data to Excel format."""
from typing import Dict, List, Optional, Any
from pathlib import Path
from datetime import datetime
import pandas as pd

from finnet.utils.logger import get_logger
logger = get_logger(__name__)


class ExcelExporter:
    """Export analysis data to Excel format."""
    
    def __init__(self, output_dir: str = "./reports"):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
    
    def export(
        self,
        data: Dict[str, pd.DataFrame],
        save_path: Optional[str] = None,
        include_charts: bool = False
    ) -> str:
        """
        Export data to multi-sheet Excel file.
        
        Args:
            data: Dict mapping sheet names to DataFrames
            save_path: Output path
            include_charts: Whether to include embedded charts
            
        Returns:
            Path to saved Excel file
        """
        try:
            import openpyxl
        except ImportError:
            logger.error("openpyxl required: pip install openpyxl")
            return ""
        
        if save_path is None:
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            save_path = str(self.output_dir / f"export_{ts}.xlsx")
        
        with pd.ExcelWriter(save_path, engine='openpyxl') as writer:
            for sheet_name, df in data.items():
                # Truncate sheet name to 31 chars (Excel limit)
                sheet = sheet_name[:31]
                
                if isinstance(df, pd.DataFrame):
                    df.to_excel(writer, sheet_name=sheet, index=True)
                elif isinstance(df, dict):
                    pd.DataFrame([df]).to_excel(writer, sheet_name=sheet, index=False)
                elif isinstance(df, list):
                    pd.DataFrame(df).to_excel(writer, sheet_name=sheet, index=False)
        
        logger.info(f"Excel file saved: {save_path}")
        return save_path
    
    def export_network_data(
        self,
        G,
        metrics: Optional[Dict] = None,
        communities: Optional[Dict] = None,
        save_path: Optional[str] = None
    ) -> str:
        """
        Export network data to Excel.
        
        Args:
            G: NetworkX graph
            metrics: Node metrics dict
            communities: Community assignments
            save_path: Output path
            
        Returns:
            Path to saved file
        """
        import networkx as nx
        
        if save_path is None:
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            save_path = str(self.output_dir / f"network_{ts}.xlsx")
        
        data = {}
        
        # Nodes sheet
        nodes_data = []
        for node in G.nodes():
            row = {'node': node, 'degree': G.degree(node)}
            
            if metrics:
                for metric_name, values in metrics.items():
                    if isinstance(values, dict) and node in values:
                        row[metric_name] = values[node]
            
            if communities and node in communities:
                row['community'] = communities[node]
            
            nodes_data.append(row)
        
        data['Nodes'] = pd.DataFrame(nodes_data)
        
        # Edges sheet
        edges_data = []
        for u, v, attrs in G.edges(data=True):
            row = {'source': u, 'target': v}
            row.update(attrs)
            edges_data.append(row)
        
        data['Edges'] = pd.DataFrame(edges_data)
        
        # Summary sheet
        summary = {
            'Metric': ['Nodes', 'Edges', 'Density', 'Avg Degree', 'Components'],
            'Value': [
                G.number_of_nodes(),
                G.number_of_edges(),
                nx.density(G),
                sum(d for _, d in G.degree()) / max(G.number_of_nodes(), 1),
                nx.number_connected_components(G) if not G.is_directed() else 'N/A'
            ]
        }
        data['Summary'] = pd.DataFrame(summary)
        
        return self.export(data, save_path)
    
    def export_sentiment_data(
        self,
        sentiment_results: List[Dict],
        save_path: Optional[str] = None
    ) -> str:
        """
        Export sentiment analysis results to Excel.
        
        Args:
            sentiment_results: List of sentiment result dicts
            save_path: Output path
            
        Returns:
            Path to saved file
        """
        if save_path is None:
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            save_path = str(self.output_dir / f"sentiment_{ts}.xlsx")
        
        df = pd.DataFrame(sentiment_results)
        data = {'Sentiment Analysis': df}
        
        # Add summary
        if 'score' in df.columns or 'aggregate_score' in df.columns:
            score_col = 'aggregate_score' if 'aggregate_score' in df.columns else 'score'
            summary = {
                'Metric': ['Total Items', 'Avg Score', 'Positive %', 'Negative %'],
                'Value': [
                    len(df),
                    df[score_col].mean() if score_col in df.columns else 'N/A',
                    (df[score_col] > 0.05).sum() / len(df) * 100 if len(df) > 0 else 0,
                    (df[score_col] < -0.05).sum() / len(df) * 100 if len(df) > 0 else 0
                ]
            }
            data['Summary'] = pd.DataFrame(summary)
        
        return self.export(data, save_path)
