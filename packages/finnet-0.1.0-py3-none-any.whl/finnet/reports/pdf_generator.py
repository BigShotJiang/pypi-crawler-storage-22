"""PDF Report Generator - Create PDF analysis reports."""
from typing import Dict, List, Optional, Any
from pathlib import Path
from datetime import datetime

from finnet.utils.logger import get_logger
logger = get_logger(__name__)


class PDFReportGenerator:
    """Generate comprehensive PDF analysis reports."""
    
    def __init__(self, output_dir: str = "./reports"):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
    
    def generate(
        self,
        title: str = "FinNet Analysis Report",
        network_stats: Optional[Dict] = None,
        sentiment_data: Optional[Dict] = None,
        community_data: Optional[Dict] = None,
        charts: Optional[List[str]] = None,
        save_path: Optional[str] = None
    ) -> str:
        """
        Generate comprehensive PDF report.
        
        Args:
            title: Report title
            network_stats: Network statistics dict
            sentiment_data: Sentiment analysis results
            community_data: Community detection results
            charts: List of chart image paths
            save_path: Output path
            
        Returns:
            Path to generated PDF
        """
        try:
            from fpdf import FPDF
        except ImportError:
            logger.error("fpdf2 required: pip install fpdf2")
            return ""
        
        if save_path is None:
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            save_path = str(self.output_dir / f"report_{ts}.pdf")
        
        pdf = FPDF()
        pdf.set_auto_page_break(auto=True, margin=15)
        
        # Title page
        pdf.add_page()
        pdf.set_font("Helvetica", "B", 28)
        pdf.cell(0, 80, "", ln=True)
        pdf.cell(0, 15, title, ln=True, align="C")
        pdf.set_font("Helvetica", "", 12)
        pdf.cell(0, 10, f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}", ln=True, align="C")
        pdf.cell(0, 10, "FinNet - Financial Social Network Analysis", ln=True, align="C")
        
        # Network Statistics
        if network_stats:
            pdf.add_page()
            pdf.set_font("Helvetica", "B", 16)
            pdf.cell(0, 10, "Network Statistics", ln=True)
            pdf.ln(5)
            pdf.set_font("Helvetica", "", 11)
            
            for key, value in network_stats.items():
                if isinstance(value, float):
                    pdf.cell(0, 7, f"{key}: {value:.4f}", ln=True)
                else:
                    pdf.cell(0, 7, f"{key}: {value}", ln=True)
        
        # Sentiment Analysis
        if sentiment_data:
            pdf.add_page()
            pdf.set_font("Helvetica", "B", 16)
            pdf.cell(0, 10, "Sentiment Analysis", ln=True)
            pdf.ln(5)
            pdf.set_font("Helvetica", "", 11)
            
            for key, value in sentiment_data.items():
                pdf.cell(0, 7, f"{key}: {value}", ln=True)
        
        # Community Detection
        if community_data:
            pdf.add_page()
            pdf.set_font("Helvetica", "B", 16)
            pdf.cell(0, 10, "Community Detection", ln=True)
            pdf.ln(5)
            pdf.set_font("Helvetica", "", 11)
            
            n_communities = len(set(community_data.values())) if isinstance(community_data, dict) else 0
            pdf.cell(0, 7, f"Number of communities: {n_communities}", ln=True)
        
        # Charts
        if charts:
            for chart_path in charts:
                if Path(chart_path).exists():
                    try:
                        pdf.add_page()
                        pdf.image(chart_path, x=15, y=30, w=180)
                    except Exception as e:
                        logger.warning(f"Could not add chart {chart_path}: {e}")
        
        # Save
        pdf.output(save_path)
        logger.info(f"PDF report saved: {save_path}")
        return save_path
    
    def generate_quick_summary(
        self,
        stats: Dict,
        save_path: Optional[str] = None
    ) -> str:
        """Generate a quick one-page summary."""
        try:
            from fpdf import FPDF
        except ImportError:
            return ""
        
        if save_path is None:
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            save_path = str(self.output_dir / f"summary_{ts}.pdf")
        
        pdf = FPDF()
        pdf.add_page()
        pdf.set_font("Helvetica", "B", 20)
        pdf.cell(0, 15, "Quick Analysis Summary", ln=True, align="C")
        pdf.ln(10)
        
        pdf.set_font("Helvetica", "", 11)
        for key, value in stats.items():
            pdf.cell(0, 8, f"{key}: {value}", ln=True)
        
        pdf.output(save_path)
        return save_path
