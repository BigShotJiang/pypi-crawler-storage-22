"""
FinNet Configuration Management

Handles application settings, paths, and UUID_timestamp session management.
"""

import json
import os
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional


class Config:
    """
    Configuration management for FinNet.
    
    Features:
    - UUID_timestamp session management for data storage
    - User preferences persistence
    - Default settings with override capability
    """
    
    # Default configuration values
    DEFAULTS = {
        # Data collection settings
        "stock_period": "1y",
        "stock_interval": "1d",
        "reddit_subreddits": ["wallstreetbets", "stocks", "investing"],
        "reddit_rate_limit": 2.0,  # seconds between requests
        "max_news_articles": 50,
        
        # Network settings
        "correlation_threshold": 0.5,
        "sentiment_threshold": 0.6,
        
        # Analysis settings
        "cascade_probability": 0.3,
        "sir_beta": 0.3,
        "sir_gamma": 0.1,
        
        # GUI settings
        "theme": "dark",
        "color_theme": "blue",
        "window_width": 1400,
        "window_height": 900,
        
        # Caching
        "cache_enabled": True,
        "cache_expiry_days": 1,
    }
    
    def __init__(self, config_path: Optional[str] = None):
        """
        Initialize configuration.
        
        Args:
            config_path: Optional path to config file. Defaults to ~/.finnet/config.json
        """
        self._home_dir = Path.home() / ".finnet"
        self._config_path = Path(config_path) if config_path else self._home_dir / "config.json"
        self._data_dir = self._home_dir / "data"
        self._cache_dir = self._home_dir / "cache"
        self._logs_dir = self._home_dir / "logs"
        
        # Current session ID (UUID_timestamp format)
        self._session_id = self._generate_session_id()
        self._session_dir: Optional[Path] = None
        
        # Configuration storage
        self._config: Dict[str, Any] = {}
        
        # Initialize directories and load config
        self._init_directories()
        self._load_config()
    
    def _generate_session_id(self) -> str:
        """Generate a unique session ID in UUID_timestamp format."""
        uid = uuid.uuid4().hex[:8]
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        return f"{uid}_{timestamp}"
    
    def _init_directories(self):
        """Create necessary directories if they don't exist."""
        for directory in [self._home_dir, self._data_dir, self._cache_dir, self._logs_dir]:
            directory.mkdir(parents=True, exist_ok=True)
    
    def _load_config(self):
        """Load configuration from file or use defaults."""
        self._config = self.DEFAULTS.copy()
        
        if self._config_path.exists():
            try:
                with open(self._config_path, 'r', encoding='utf-8') as f:
                    user_config = json.load(f)
                    self._config.update(user_config)
            except (json.JSONDecodeError, IOError) as e:
                print(f"Warning: Could not load config file: {e}")
    
    def save_config(self):
        """Save current configuration to file."""
        try:
            with open(self._config_path, 'w', encoding='utf-8') as f:
                json.dump(self._config, f, indent=2)
        except IOError as e:
            print(f"Warning: Could not save config file: {e}")
    
    def get(self, key: str, default: Any = None) -> Any:
        """
        Get a configuration value.
        
        Args:
            key: Configuration key
            default: Default value if key not found
            
        Returns:
            Configuration value
        """
        return self._config.get(key, default)
    
    def set(self, key: str, value: Any):
        """
        Set a configuration value.
        
        Args:
            key: Configuration key
            value: Value to set
        """
        self._config[key] = value
    
    def reset_to_defaults(self):
        """Reset all configuration to default values."""
        self._config = self.DEFAULTS.copy()
        self.save_config()
    
    @property
    def session_id(self) -> str:
        """Get current session ID."""
        return self._session_id
    
    @property
    def home_dir(self) -> Path:
        """Get FinNet home directory."""
        return self._home_dir
    
    @property
    def data_dir(self) -> Path:
        """Get data directory."""
        return self._data_dir
    
    @property
    def cache_dir(self) -> Path:
        """Get cache directory."""
        return self._cache_dir
    
    @property
    def logs_dir(self) -> Path:
        """Get logs directory."""
        return self._logs_dir
    
    def get_session_dir(self) -> Path:
        """
        Get current session directory (created on first access).
        
        Returns:
            Path to session directory (data/{uuid}_{timestamp}/)
        """
        if self._session_dir is None:
            self._session_dir = self._data_dir / self._session_id
            self._session_dir.mkdir(parents=True, exist_ok=True)
        return self._session_dir
    
    def get_current_session_dir(self) -> Path:
        """Alias for get_session_dir for compatibility."""
        return self.get_session_dir()
    
    def set_output_dir(self, output_dir: str):
        """
        Set a custom output directory for the current session.
        
        Args:
            output_dir: Path to custom output directory
        """
        self._session_dir = Path(output_dir)
        self._session_dir.mkdir(parents=True, exist_ok=True)
    
    def get_cache_path(self, category: str, name: str) -> Path:
        """
        Get path for a cached file.
        
        Args:
            category: Cache category (e.g., 'stocks', 'sentiment')
            name: File name (without extension)
            
        Returns:
            Path to cache file
        """
        category_dir = self._cache_dir / category
        category_dir.mkdir(parents=True, exist_ok=True)
        return category_dir / f"{name}.pkl"
    
    def new_session(self) -> str:
        """
        Start a new session with a fresh UUID_timestamp.
        
        Returns:
            New session ID
        """
        self._session_id = self._generate_session_id()
        self._session_dir = None
        return self._session_id
    
    def list_sessions(self) -> list:
        """
        List all previous sessions.
        
        Returns:
            List of session directory names (UUID_timestamp format)
        """
        if not self._data_dir.exists():
            return []
        return sorted([d.name for d in self._data_dir.iterdir() if d.is_dir()], reverse=True)
    
    def load_session(self, session_id: str) -> bool:
        """
        Load a previous session.
        
        Args:
            session_id: Session ID to load
            
        Returns:
            True if session exists and was loaded
        """
        session_path = self._data_dir / session_id
        if session_path.exists() and session_path.is_dir():
            self._session_id = session_id
            self._session_dir = session_path
            return True
        return False
    
    def __repr__(self) -> str:
        return f"Config(session={self._session_id}, home={self._home_dir})"
