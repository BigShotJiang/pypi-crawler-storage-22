"""
FinNet Helper Utilities

Common utility functions used throughout the application.
"""

import re
import uuid
from datetime import datetime
from typing import Any, List, Optional, Tuple


def generate_session_id() -> str:
    """
    Generate a unique session ID in UUID_timestamp format.
    
    Returns:
        Session ID string (e.g., 'a1b2c3d4_20260204_185000')
    """
    uid = uuid.uuid4().hex[:8]
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    return f"{uid}_{timestamp}"


def validate_ticker(ticker: str) -> Tuple[bool, str]:
    """
    Validate a stock ticker symbol.
    
    Args:
        ticker: Ticker symbol to validate
        
    Returns:
        Tuple of (is_valid, cleaned_ticker_or_error_message)
    """
    if not ticker or not isinstance(ticker, str):
        return False, "Ticker must be a non-empty string"
    
    # Clean and uppercase
    cleaned = ticker.strip().upper()
    
    # Check length (1-5 characters)
    if len(cleaned) < 1 or len(cleaned) > 5:
        return False, f"Ticker must be 1-5 characters, got {len(cleaned)}"
    
    # Check for valid characters (letters only, some have dots like BRK.A)
    if not re.match(r'^[A-Z]{1,5}(\.[A-Z])?$', cleaned):
        return False, "Ticker must contain only letters (A-Z)"
    
    return True, cleaned


def format_large_number(num: float, precision: int = 2) -> str:
    """
    Format a large number with K/M/B/T suffixes.
    
    Args:
        num: Number to format
        precision: Decimal precision
        
    Returns:
        Formatted string (e.g., '1.5B', '250K')
    """
    if num is None or not isinstance(num, (int, float)):
        return "N/A"
    
    if abs(num) < 1000:
        return f"{num:.{precision}f}"
    
    suffixes = [
        (1e12, 'T'),
        (1e9, 'B'),
        (1e6, 'M'),
        (1e3, 'K'),
    ]
    
    for threshold, suffix in suffixes:
        if abs(num) >= threshold:
            return f"{num / threshold:.{precision}f}{suffix}"
    
    return f"{num:.{precision}f}"


def format_percentage(value: float, precision: int = 2) -> str:
    """
    Format a value as a percentage.
    
    Args:
        value: Value to format (0.05 = 5%)
        precision: Decimal precision
        
    Returns:
        Formatted percentage string
    """
    if value is None:
        return "N/A"
    return f"{value * 100:.{precision}f}%"


def calculate_percentage_change(old_value: float, new_value: float) -> Optional[float]:
    """
    Calculate percentage change between two values.
    
    Args:
        old_value: Original value
        new_value: New value
        
    Returns:
        Percentage change (0.1 = 10% increase) or None if invalid
    """
    if old_value == 0 or old_value is None or new_value is None:
        return None
    return (new_value - old_value) / old_value


def safe_divide(a: float, b: float, default: float = 0.0) -> float:
    """
    Safely divide two numbers, returning default if division by zero.
    
    Args:
        a: Numerator
        b: Denominator
        default: Default value if division by zero
        
    Returns:
        Result of division or default
    """
    try:
        if b == 0:
            return default
        return a / b
    except (TypeError, ZeroDivisionError):
        return default


def truncate_text(text: str, max_length: int = 100, suffix: str = "...") -> str:
    """
    Truncate text to a maximum length.
    
    Args:
        text: Text to truncate
        max_length: Maximum length
        suffix: Suffix to add if truncated
        
    Returns:
        Truncated text
    """
    if not text or len(text) <= max_length:
        return text or ""
    return text[:max_length - len(suffix)] + suffix


def get_sentiment_color(score: float) -> str:
    """
    Get a color code based on sentiment score.
    
    Args:
        score: Sentiment score (-1 to 1)
        
    Returns:
        Hex color code
    """
    if score > 0.3:
        return "#22c55e"  # Green (positive)
    elif score > 0.1:
        return "#86efac"  # Light green
    elif score > -0.1:
        return "#fbbf24"  # Yellow (neutral)
    elif score > -0.3:
        return "#f87171"  # Light red
    else:
        return "#ef4444"  # Red (negative)


def get_change_color(value: float) -> str:
    """
    Get color for a change value (positive/negative).
    
    Args:
        value: Change value
        
    Returns:
        Hex color code
    """
    if value > 0:
        return "#22c55e"  # Green
    elif value < 0:
        return "#ef4444"  # Red
    else:
        return "#9ca3af"  # Gray


def parse_tickers(text: str) -> List[str]:
    """
    Parse ticker symbols from a text string.
    
    Handles formats:
    - Comma-separated: "AAPL, GOOGL, MSFT"
    - Space-separated: "AAPL GOOGL MSFT"
    - Newline-separated
    - With $ prefix: "$AAPL, $GOOGL"
    
    Args:
        text: Text containing ticker symbols
        
    Returns:
        List of cleaned ticker symbols
    """
    if not text:
        return []
    
    # Remove $ prefix
    text = text.replace('$', '')
    
    # Split by common delimiters
    parts = re.split(r'[,\s\n]+', text)
    
    # Validate and clean each ticker
    tickers = []
    for part in parts:
        valid, result = validate_ticker(part)
        if valid:
            tickers.append(result)
    
    # Remove duplicates while preserving order
    seen = set()
    unique_tickers = []
    for t in tickers:
        if t not in seen:
            seen.add(t)
            unique_tickers.append(t)
    
    return unique_tickers


def clamp(value: float, min_val: float, max_val: float) -> float:
    """
    Clamp a value between min and max.
    
    Args:
        value: Value to clamp
        min_val: Minimum value
        max_val: Maximum value
        
    Returns:
        Clamped value
    """
    return max(min_val, min(max_val, value))


def normalize_values(values: List[float]) -> List[float]:
    """
    Normalize a list of values to 0-1 range.
    
    Args:
        values: List of numeric values
        
    Returns:
        Normalized values
    """
    if not values:
        return []
    
    min_val = min(values)
    max_val = max(values)
    
    if max_val == min_val:
        return [0.5] * len(values)
    
    return [(v - min_val) / (max_val - min_val) for v in values]


def format_timestamp(dt: datetime, format_str: str = "%Y-%m-%d %H:%M:%S") -> str:
    """
    Format a datetime object to string.
    
    Args:
        dt: Datetime object
        format_str: Format string
        
    Returns:
        Formatted string
    """
    if dt is None:
        return "N/A"
    return dt.strftime(format_str)


def time_ago(dt: datetime) -> str:
    """
    Get human-readable time ago string.
    
    Args:
        dt: Datetime object
        
    Returns:
        Human-readable string (e.g., "2 hours ago")
    """
    if dt is None:
        return "Unknown"
    
    now = datetime.now()
    diff = now - dt
    
    seconds = diff.total_seconds()
    
    if seconds < 60:
        return "just now"
    elif seconds < 3600:
        minutes = int(seconds / 60)
        return f"{minutes} minute{'s' if minutes != 1 else ''} ago"
    elif seconds < 86400:
        hours = int(seconds / 3600)
        return f"{hours} hour{'s' if hours != 1 else ''} ago"
    elif seconds < 604800:
        days = int(seconds / 86400)
        return f"{days} day{'s' if days != 1 else ''} ago"
    else:
        return dt.strftime("%Y-%m-%d")
