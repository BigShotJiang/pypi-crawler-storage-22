"""
FinNet Logging System

Provides centralized logging configuration with file and console handlers.
"""

import logging
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional


# Module-level logger cache
_loggers = {}


def get_logger(name: str, log_file: Optional[str] = None) -> logging.Logger:
    """
    Get a configured logger instance.
    
    Args:
        name: Logger name (typically module name)
        log_file: Optional log file path (if None, uses default)
        
    Returns:
        Configured logger instance
    """
    if name in _loggers:
        return _loggers[name]
    
    logger = logging.getLogger(name)
    
    # Only configure if not already configured
    if not logger.handlers:
        logger.setLevel(logging.DEBUG)
        
        # Console handler (INFO and above)
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(logging.INFO)
        console_format = logging.Formatter(
            '%(asctime)s | %(levelname)-8s | %(name)s | %(message)s',
            datefmt='%H:%M:%S'
        )
        console_handler.setFormatter(console_format)
        logger.addHandler(console_handler)
        
        # File handler (DEBUG and above)
        if log_file is None:
            log_dir = Path.home() / ".finnet" / "logs"
            log_dir.mkdir(parents=True, exist_ok=True)
            log_file = log_dir / f"finnet_{datetime.now().strftime('%Y%m%d')}.log"
        else:
            log_file = Path(log_file)
            log_file.parent.mkdir(parents=True, exist_ok=True)
        
        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_handler.setLevel(logging.DEBUG)
        file_format = logging.Formatter(
            '%(asctime)s | %(levelname)-8s | %(name)s | %(funcName)s:%(lineno)d | %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        file_handler.setFormatter(file_format)
        logger.addHandler(file_handler)
        
        # Prevent propagation to root logger
        logger.propagate = False
    
    _loggers[name] = logger
    return logger


def set_log_level(level: str = "INFO"):
    """
    Set log level for all FinNet loggers.
    
    Args:
        level: Log level ('DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL')
    """
    log_level = getattr(logging, level.upper(), logging.INFO)
    
    for logger in _loggers.values():
        logger.setLevel(log_level)
        for handler in logger.handlers:
            if isinstance(handler, logging.StreamHandler) and handler.stream == sys.stdout:
                handler.setLevel(log_level)


def cleanup_old_logs(days: int = 7):
    """
    Remove log files older than specified days.
    
    Args:
        days: Number of days to keep logs
    """
    log_dir = Path.home() / ".finnet" / "logs"
    if not log_dir.exists():
        return
    
    cutoff = datetime.now().timestamp() - (days * 24 * 60 * 60)
    
    for log_file in log_dir.glob("finnet_*.log"):
        if log_file.stat().st_mtime < cutoff:
            try:
                log_file.unlink()
            except OSError:
                pass
