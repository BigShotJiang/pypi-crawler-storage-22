"""Animation Module - Cascade and network animations."""
import numpy as np
from typing import Dict, List, Optional, Any
from pathlib import Path

from finnet.utils.logger import get_logger
logger = get_logger(__name__)


class CascadeAnimator:
    """Create cascade/epidemic animation frames."""
    
    def __init__(self, style: str = 'dark'):
        self.style = style
    
    def animate_cascade(
        self,
        G,
        history: List[Dict],
        save_path: str,
        fps: int = 5,
        node_size: int = 300
    ) -> str:
        """
        Create animated GIF of cascade propagation.
        
        Args:
            G: NetworkX graph
            history: Cascade history from simulation
            save_path: Path to save animation
            fps: Frames per second
            node_size: Size of nodes
            
        Returns:
            Path to saved animation
        """
        try:
            import matplotlib.pyplot as plt
            import matplotlib.animation as animation
            import networkx as nx
        except ImportError:
            logger.error("matplotlib required for animations")
            return ""
        
        fig, ax = plt.subplots(figsize=(10, 8))
        pos = nx.spring_layout(G, seed=42)
        
        if self.style == 'dark':
            fig.patch.set_facecolor('#1a1a2e')
            ax.set_facecolor('#1a1a2e')
        
        def update(frame):
            ax.clear()
            ax.axis('off')
            
            if frame >= len(history):
                return
            
            state = history[frame]
            active = state.get('newly_active', state.get('I', set()))
            if isinstance(active, (int, float)):
                # SIR model - just color by count
                colors = ['#4CAF50' if i < state.get('S', 0) else 
                         '#F44336' if i < state.get('S', 0) + state.get('I', 0) else '#2196F3'
                         for i in range(G.number_of_nodes())]
            else:
                # Cascade model
                all_active = set()
                for h in history[:frame+1]:
                    na = h.get('newly_active', set())
                    if isinstance(na, set):
                        all_active.update(na)
                
                colors = ['#F44336' if n in all_active else '#4CAF50' for n in G.nodes()]
            
            nx.draw_networkx(G, pos, ax=ax, node_color=colors, node_size=node_size,
                           font_color='white' if self.style == 'dark' else 'black', font_size=8)
            ax.set_title(f"Step {frame}", fontsize=14, color='white' if self.style == 'dark' else 'black')
        
        ani = animation.FuncAnimation(fig, update, frames=len(history), interval=1000//fps, repeat=True)
        
        # Save as GIF
        if save_path.endswith('.gif'):
            ani.save(save_path, writer='pillow', fps=fps)
        else:
            ani.save(save_path + '.gif', writer='pillow', fps=fps)
        
        plt.close(fig)
        logger.info(f"Animation saved to {save_path}")
        return save_path
    
    def create_network_gif(
        self,
        G,
        layouts: List[str] = ['spring', 'circular', 'kamada_kawai'],
        save_path: str = 'network_layouts.gif',
        duration: int = 2000
    ) -> str:
        """
        Create GIF showing different network layouts.
        
        Args:
            G: NetworkX graph
            layouts: List of layout names
            save_path: Path to save GIF
            duration: Duration per frame in ms
            
        Returns:
            Path to saved GIF
        """
        try:
            import matplotlib.pyplot as plt
            import networkx as nx
            from PIL import Image
            import io
        except ImportError:
            logger.error("matplotlib and Pillow required")
            return ""
        
        frames = []
        
        for layout_name in layouts:
            fig, ax = plt.subplots(figsize=(10, 8))
            
            if self.style == 'dark':
                fig.patch.set_facecolor('#1a1a2e')
                ax.set_facecolor('#1a1a2e')
            
            if layout_name == 'spring':
                pos = nx.spring_layout(G, seed=42)
            elif layout_name == 'circular':
                pos = nx.circular_layout(G)
            elif layout_name == 'kamada_kawai':
                pos = nx.kamada_kawai_layout(G)
            elif layout_name == 'spectral':
                pos = nx.spectral_layout(G)
            else:
                pos = nx.spring_layout(G, seed=42)
            
            nx.draw_networkx(G, pos, ax=ax, node_color='#2196F3', node_size=300,
                           font_color='white' if self.style == 'dark' else 'black')
            ax.set_title(f"Layout: {layout_name}", fontsize=14, 
                        color='white' if self.style == 'dark' else 'black')
            ax.axis('off')
            
            # Convert to image
            buf = io.BytesIO()
            plt.savefig(buf, format='png', facecolor=fig.get_facecolor(), bbox_inches='tight')
            buf.seek(0)
            frames.append(Image.open(buf).copy())
            plt.close(fig)
        
        # Save as GIF
        if frames:
            frames[0].save(save_path, save_all=True, append_images=frames[1:], 
                          duration=duration, loop=0)
            logger.info(f"Network GIF saved to {save_path}")
        
        return save_path


class NetworkAnimator:
    """Network visualization animations."""
    
    def __init__(self):
        pass
    
    def animate_growth(
        self,
        edges_by_time: List[tuple],
        save_path: str,
        fps: int = 3
    ) -> str:
        """
        Animate network growth over time.
        
        Args:
            edges_by_time: List of (node1, node2, time) tuples
            save_path: Path to save animation
            fps: Frames per second
            
        Returns:
            Path to animation
        """
        try:
            import matplotlib.pyplot as plt
            import matplotlib.animation as animation
            import networkx as nx
        except ImportError:
            return ""
        
        G = nx.Graph()
        fig, ax = plt.subplots(figsize=(10, 8))
        
        # Sort by time
        sorted_edges = sorted(edges_by_time, key=lambda x: x[2] if len(x) > 2 else 0)
        
        def update(frame):
            ax.clear()
            ax.axis('off')
            
            # Add edges up to this frame
            for i in range(min(frame + 1, len(sorted_edges))):
                e = sorted_edges[i]
                G.add_edge(e[0], e[1])
            
            if G.number_of_nodes() > 0:
                pos = nx.spring_layout(G, seed=42)
                nx.draw_networkx(G, pos, ax=ax, node_color='#4CAF50', node_size=200)
            
            ax.set_title(f"Edges: {G.number_of_edges()}", fontsize=12)
        
        ani = animation.FuncAnimation(fig, update, frames=len(sorted_edges), 
                                       interval=1000//fps, repeat=False)
        ani.save(save_path, writer='pillow', fps=fps)
        plt.close(fig)
        
        return save_path
