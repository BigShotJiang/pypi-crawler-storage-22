"""
Chart Generator

Create financial charts and analysis visualizations.
"""

from typing import Dict, List, Optional, Any, Tuple
from pathlib import Path

import pandas as pd
import numpy as np

from finnet.utils.logger import get_logger

logger = get_logger(__name__)


class ChartGenerator:
    """
    Generate financial charts and visualizations.
    
    Supports:
    - Stock price charts
    - Sentiment timelines
    - Technical indicators
    - Correlation heatmaps
    - Community statistics
    """
    
    def __init__(self, style: str = 'dark'):
        """
        Initialize chart generator.
        
        Args:
            style: 'dark' or 'light' theme
        """
        self.style = style
        self._setup_style()
    
    def _setup_style(self):
        """Set up visualization style."""
        try:
            import matplotlib
            import matplotlib.pyplot as plt
            import seaborn as sns
            
            # Force non-interactive backend for thread safety
            matplotlib.use('Agg')
            
            if self.style == 'dark':
                plt.style.use('dark_background')
            else:
                plt.style.use('seaborn-v0_8-whitegrid')
            
            sns.set_palette("husl")
        except Exception:
            pass
    
    def plot_stock_prices(
        self,
        df: pd.DataFrame,
        title: str = "Stock Prices",
        normalize: bool = False,
        save_path: Optional[str] = None
    ) -> Any:
        """
        Plot stock price chart.
        
        Args:
            df: DataFrame with stock prices (columns = tickers)
            title: Chart title
            normalize: Normalize to 100 at start
            save_path: Optional save path
            
        Returns:
            Matplotlib figure
        """
        import matplotlib.pyplot as plt
        
        fig, ax = plt.subplots(figsize=(12, 6))
        
        plot_data = df.copy()
        
        if normalize:
            plot_data = (plot_data / plot_data.iloc[0]) * 100
        
        for col in plot_data.columns:
            ax.plot(plot_data.index, plot_data[col], label=col, linewidth=1.5)
        
        ax.set_xlabel('Date')
        ax.set_ylabel('Price' if not normalize else 'Normalized Price')
        ax.set_title(title, fontsize=14, fontweight='bold')
        ax.legend(loc='upper left', bbox_to_anchor=(1.02, 1))
        ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
            logger.info(f"Stock chart saved to {save_path}")
            plt.close(fig)
        
        return fig
    
    def plot_candlestick(
        self,
        df: pd.DataFrame,
        title: str = "Candlestick Chart",
        save_path: Optional[str] = None
    ) -> Any:
        """
        Plot candlestick chart.
        
        Args:
            df: OHLC DataFrame
            title: Chart title
            save_path: Optional save path
            
        Returns:
            Plotly figure
        """
        try:
            import plotly.graph_objects as go
        except ImportError:
            logger.error("Plotly required for candlestick charts")
            return None
        
        fig = go.Figure(data=[go.Candlestick(
            x=df.index,
            open=df['Open'],
            high=df['High'],
            low=df['Low'],
            close=df['Close']
        )])
        
        fig.update_layout(
            title=title,
            xaxis_title='Date',
            yaxis_title='Price',
            xaxis_rangeslider_visible=False
        )
        
        if save_path:
            fig.write_html(save_path)
        
        return fig
    
    def plot_sentiment_timeline(
        self,
        df: pd.DataFrame,
        date_column: str = 'date',
        score_column: str = 'sentiment_score',
        title: str = "Sentiment Over Time",
        save_path: Optional[str] = None
    ) -> Any:
        """
        Plot sentiment timeline.
        
        Args:
            df: DataFrame with sentiment data
            date_column: Date column name
            score_column: Sentiment score column name
            title: Chart title
            save_path: Optional save path
            
        Returns:
            Matplotlib figure
        """
        import matplotlib.pyplot as plt
        
        fig, axes = plt.subplots(2, 1, figsize=(12, 8))
        
        # Aggregate by date
        if date_column in df.columns:
            daily = df.groupby(pd.to_datetime(df[date_column]).dt.date)[score_column].agg(['mean', 'count'])
        else:
            daily = df.groupby(df.index.date)[score_column].agg(['mean', 'count'])
        
        # Plot sentiment
        axes[0].plot(daily.index, daily['mean'], 'b-', linewidth=2)
        axes[0].axhline(y=0, color='gray', linestyle='--', alpha=0.5)
        axes[0].fill_between(
            daily.index,
            daily['mean'],
            0,
            where=(daily['mean'] >= 0),
            color='green',
            alpha=0.3,
            label='Positive'
        )
        axes[0].fill_between(
            daily.index,
            daily['mean'],
            0,
            where=(daily['mean'] < 0),
            color='red',
            alpha=0.3,
            label='Negative'
        )
        axes[0].set_ylabel('Average Sentiment')
        axes[0].legend()
        axes[0].set_title(title, fontsize=14, fontweight='bold')
        
        # Plot volume
        axes[1].bar(daily.index, daily['count'], alpha=0.7)
        axes[1].set_xlabel('Date')
        axes[1].set_ylabel('Number of Posts/Articles')
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        
        return fig
    
    def plot_correlation_heatmap(
        self,
        corr_matrix: pd.DataFrame,
        title: str = "Correlation Matrix",
        annot: bool = True,
        save_path: Optional[str] = None
    ) -> Any:
        """
        Plot correlation heatmap.
        
        Args:
            corr_matrix: Correlation matrix
            title: Chart title
            annot: Annotate cells with values
            save_path: Optional save path
            
        Returns:
            Matplotlib figure
        """
        import matplotlib.pyplot as plt
        import seaborn as sns
        
        fig, ax = plt.subplots(figsize=(10, 8))
        
        sns.heatmap(
            corr_matrix,
            annot=annot,
            cmap='RdYlGn',
            center=0,
            square=True,
            linewidths=0.5,
            cbar_kws={'shrink': 0.8},
            ax=ax,
            fmt='.2f'
        )
        
        ax.set_title(title, fontsize=14, fontweight='bold')
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        
        return fig
    
    def plot_technical_indicators(
        self,
        df: pd.DataFrame,
        ticker: str = "Stock",
        save_path: Optional[str] = None
    ) -> Any:
        """
        Plot stock with technical indicators.
        
        Args:
            df: DataFrame with OHLC and indicators
            ticker: Ticker symbol
            save_path: Optional save path
            
        Returns:
            Matplotlib figure
        """
        import matplotlib.pyplot as plt
        
        fig, axes = plt.subplots(3, 1, figsize=(12, 10), gridspec_kw={'height_ratios': [3, 1, 1]})
        
        # Price and moving averages
        axes[0].plot(df.index, df['Close'], label='Close', linewidth=1.5)
        
        if 'SMA_20' in df.columns:
            axes[0].plot(df.index, df['SMA_20'], label='SMA 20', alpha=0.7)
        if 'SMA_50' in df.columns:
            axes[0].plot(df.index, df['SMA_50'], label='SMA 50', alpha=0.7)
        if 'BB_Upper' in df.columns:
            axes[0].fill_between(df.index, df['BB_Upper'], df['BB_Lower'], alpha=0.2, label='Bollinger Bands')
        
        axes[0].set_ylabel('Price')
        axes[0].set_title(f'{ticker} Technical Analysis', fontsize=14, fontweight='bold')
        axes[0].legend(loc='upper left')
        axes[0].grid(True, alpha=0.3)
        
        # RSI
        if 'RSI' in df.columns:
            axes[1].plot(df.index, df['RSI'], 'purple', linewidth=1.5)
            axes[1].axhline(y=70, color='red', linestyle='--', alpha=0.5)
            axes[1].axhline(y=30, color='green', linestyle='--', alpha=0.5)
            axes[1].fill_between(df.index, 70, df['RSI'], where=(df['RSI'] >= 70), color='red', alpha=0.3)
            axes[1].fill_between(df.index, 30, df['RSI'], where=(df['RSI'] <= 30), color='green', alpha=0.3)
            axes[1].set_ylabel('RSI')
            axes[1].set_ylim(0, 100)
            axes[1].grid(True, alpha=0.3)
        
        # MACD
        if 'MACD' in df.columns and 'MACD_Signal' in df.columns:
            axes[2].plot(df.index, df['MACD'], label='MACD', linewidth=1.5)
            axes[2].plot(df.index, df['MACD_Signal'], label='Signal', linewidth=1.5)
            
            if 'MACD_Hist' in df.columns:
                colors = ['green' if x >= 0 else 'red' for x in df['MACD_Hist']]
                axes[2].bar(df.index, df['MACD_Hist'], color=colors, alpha=0.5)
            
            axes[2].axhline(y=0, color='gray', linestyle='--', alpha=0.5)
            axes[2].set_ylabel('MACD')
            axes[2].set_xlabel('Date')
            axes[2].legend(loc='upper left')
            axes[2].grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        
        return fig
    
    def plot_sentiment_distribution(
        self,
        scores: List[float],
        title: str = "Sentiment Distribution",
        save_path: Optional[str] = None
    ) -> Any:
        """
        Plot sentiment score distribution.
        
        Args:
            scores: List of sentiment scores
            title: Chart title
            save_path: Optional save path
            
        Returns:
            Matplotlib figure
        """
        import matplotlib.pyplot as plt
        import seaborn as sns
        
        fig, axes = plt.subplots(1, 2, figsize=(12, 5))
        
        # Histogram
        sns.histplot(scores, bins=30, kde=True, ax=axes[0])
        axes[0].axvline(x=0, color='gray', linestyle='--', alpha=0.5)
        axes[0].set_xlabel('Sentiment Score')
        axes[0].set_ylabel('Frequency')
        axes[0].set_title('Distribution')
        
        # Box plot
        sns.boxplot(x=scores, ax=axes[1])
        axes[1].axvline(x=0, color='gray', linestyle='--', alpha=0.5)
        axes[1].set_xlabel('Sentiment Score')
        axes[1].set_title('Box Plot')
        
        plt.suptitle(title, fontsize=14, fontweight='bold')
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        
        return fig
    
    def plot_community_sizes(
        self,
        partition: Dict[str, int],
        title: str = "Community Sizes",
        save_path: Optional[str] = None
    ) -> Any:
        """
        Plot community size distribution.
        
        Args:
            partition: Node to community mapping
            title: Chart title
            save_path: Optional save path
            
        Returns:
            Matplotlib figure
        """
        import matplotlib.pyplot as plt
        
        # Count community sizes
        community_counts = {}
        for node, comm in partition.items():
            community_counts[comm] = community_counts.get(comm, 0) + 1
        
        communities = sorted(community_counts.keys())
        sizes = [community_counts[c] for c in communities]
        
        fig, axes = plt.subplots(1, 2, figsize=(12, 5))
        
        # Bar chart
        colors = plt.cm.tab20(np.linspace(0, 1, len(communities)))
        axes[0].bar(range(len(communities)), sizes, color=colors)
        axes[0].set_xlabel('Community ID')
        axes[0].set_ylabel('Size')
        axes[0].set_title('Community Sizes')
        
        # Pie chart
        axes[1].pie(sizes, labels=[f'C{c}' for c in communities], autopct='%1.1f%%', colors=colors)
        axes[1].set_title('Community Distribution')
        
        plt.suptitle(title, fontsize=14, fontweight='bold')
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        
        return fig
    
    def plot_centrality_comparison(
        self,
        centralities: Dict[str, Dict[str, float]],
        top_n: int = 10,
        title: str = "Centrality Comparison",
        save_path: Optional[str] = None
    ) -> Any:
        """
        Plot comparison of different centrality measures.
        
        Args:
            centralities: Dict mapping metric name to node->value dict
            top_n: Number of top nodes
            title: Chart title
            save_path: Optional save path
            
        Returns:
            Matplotlib figure
        """
        import matplotlib.pyplot as plt
        
        n_metrics = len(centralities)
        fig, axes = plt.subplots(1, n_metrics, figsize=(5 * n_metrics, 6))
        
        if n_metrics == 1:
            axes = [axes]
        
        for i, (metric_name, values) in enumerate(centralities.items()):
            sorted_nodes = sorted(values.items(), key=lambda x: x[1], reverse=True)[:top_n]
            nodes = [n[0] for n in sorted_nodes]
            vals = [n[1] for n in sorted_nodes]
            
            axes[i].barh(range(len(nodes)), vals)
            axes[i].set_yticks(range(len(nodes)))
            axes[i].set_yticklabels(nodes)
            axes[i].set_xlabel(metric_name)
            axes[i].set_title(f'Top {top_n} by {metric_name}')
            axes[i].invert_yaxis()
        
        plt.suptitle(title, fontsize=14, fontweight='bold')
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        
        return fig
    
    def plot_cascade_timeline(
        self,
        history: List[Dict],
        title: str = "Cascade Timeline",
        save_path: Optional[str] = None
    ) -> Any:
        """
        Plot cascade/epidemic simulation timeline.
        
        Args:
            history: Cascade history from simulation
            title: Chart title
            save_path: Optional save path
            
        Returns:
            Matplotlib figure
        """
        import matplotlib.pyplot as plt
        
        df = pd.DataFrame(history)
        
        fig, ax = plt.subplots(figsize=(10, 6))
        
        if 'S' in df.columns:  # SIR model
            ax.plot(df['step'], df['S'], 'b-', label='Susceptible', linewidth=2)
            ax.plot(df['step'], df['I'], 'r-', label='Infected', linewidth=2)
            if 'R' in df.columns:
                ax.plot(df['step'], df['R'], 'g-', label='Recovered', linewidth=2)
        else:  # Cascade model
            ax.plot(df['step'], df['total_active'], 'b-', linewidth=2)
            ax.fill_between(df['step'], 0, df['total_active'], alpha=0.3)
        
        ax.set_xlabel('Time Step')
        ax.set_ylabel('Number of Nodes')
        ax.set_title(title, fontsize=14, fontweight='bold')
        ax.legend()
        ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        
        return fig
