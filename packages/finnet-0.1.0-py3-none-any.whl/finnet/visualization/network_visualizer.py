"""
Network Visualizer

Create static and interactive network visualizations.
"""

from typing import Dict, List, Optional, Any, Tuple
from pathlib import Path

import networkx as nx
import numpy as np
import shutil
import os

# Ultra-safe terminal size patching for visualization
if not hasattr(shutil, '_original_get_terminal_size'):
    shutil._original_get_terminal_size = shutil.get_terminal_size
    
def _safe_get_terminal_size(fallback=(80, 24)):
    return os.terminal_size((100, 24))
    
shutil.get_terminal_size = _safe_get_terminal_size

from finnet.utils.logger import get_logger

logger = get_logger(__name__)


class NetworkVisualizer:
    """
    Visualize financial networks.
    
    Supports:
    - Static visualization with Matplotlib
    - Interactive visualization with Plotly
    - Interactive HTML with PyVis
    - 3D network layouts
    """
    
    def __init__(self, style: str = 'dark'):
        """
        Initialize visualizer.
        
        Args:
            style: 'dark' or 'light' theme
        """
        self.style = style
        self._setup_style()
    
    def _setup_style(self):
        """Set up visualization style."""
        try:
            import matplotlib
            import matplotlib.pyplot as plt
            
            # Force non-interactive backend for thread safety
            matplotlib.use('Agg')
            
            if self.style == 'dark':
                plt.style.use('dark_background')
            else:
                plt.style.use('seaborn-v0_8-whitegrid')
        except Exception:
            pass
    
    def plot_network_matplotlib(
        self,
        G: nx.Graph,
        layout: str = 'spring',
        node_size: int = 300,
        node_color: str = 'community',
        edge_color: str = 'gray',
        with_labels: bool = True,
        title: str = "Network Graph",
        figsize: Tuple[int, int] = (12, 8),
        save_path: Optional[str] = None
    ) -> Any:
        """
        Create static network visualization with Matplotlib.
        
        Args:
            G: NetworkX graph
            layout: 'spring', 'kamada_kawai', 'circular', 'spectral', 'shell'
            node_size: Size of nodes
            node_color: 'community', 'degree', color name, or list
            edge_color: Edge color
            with_labels: Show node labels
            title: Plot title
            figsize: Figure size
            save_path: Optional save path
            
        Returns:
            Matplotlib figure
        """
        import matplotlib.pyplot as plt
        
        fig, ax = plt.subplots(figsize=figsize)
        
        # Compute layout
        pos = self._compute_layout(G, layout)
        
        # Determine node colors
        colors = self._get_node_colors(G, node_color)
        
        # Draw network
        nx.draw_networkx(
            G, pos, ax=ax,
            node_size=node_size,
            node_color=colors,
            edge_color=edge_color,
            with_labels=with_labels,
            font_size=8,
            font_color='white' if self.style == 'dark' else 'black',
            alpha=0.9
        )
        
        ax.set_title(title, fontsize=14, fontweight='bold')
        ax.axis('off')
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
            logger.info(f"Network plot saved to {save_path}")
            plt.close(fig)  # Close to free memory and avoid GUI thread issues
        
        return fig
    
    def plot_network_plotly(
        self,
        G: nx.Graph,
        layout: str = 'spring',
        node_color: str = 'community',
        title: str = "Interactive Network",
        save_path: Optional[str] = None
    ) -> Any:
        """
        Create interactive network visualization with Plotly.
        
        Args:
            G: NetworkX graph
            layout: Layout algorithm
            node_color: Color scheme
            title: Plot title
            save_path: Optional HTML save path
            
        Returns:
            Plotly figure
        """
        try:
            import plotly.graph_objects as go
        except ImportError:
            logger.error("Plotly not installed. Use pip install plotly")
            return None
        
        # Compute layout
        pos = self._compute_layout(G, layout)
        
        # Get node colors
        colors = self._get_node_colors(G, node_color, as_numbers=True)
        
        # Create edge traces
        edge_x = []
        edge_y = []
        
        for edge in G.edges():
            x0, y0 = pos[edge[0]]
            x1, y1 = pos[edge[1]]
            edge_x.extend([x0, x1, None])
            edge_y.extend([y0, y1, None])
        
        edge_trace = go.Scatter(
            x=edge_x, y=edge_y,
            line=dict(width=0.5, color='#888'),
            hoverinfo='none',
            mode='lines'
        )
        
        # Create node trace
        node_x = [pos[node][0] for node in G.nodes()]
        node_y = [pos[node][1] for node in G.nodes()]
        
        node_trace = go.Scatter(
            x=node_x, y=node_y,
            mode='markers+text',
            hoverinfo='text',
            marker=dict(
                showscale=True,
                colorscale='Viridis',
                size=10,
                color=colors,
                colorbar=dict(
                    thickness=15,
                    title='Node Value',
                    xanchor='left'
                )
            ),
            text=list(G.nodes()),
            textposition='top center'
        )
        
        # Create hover text
        hover_text = []
        for node in G.nodes():
            info = f"Node: {node}<br>Degree: {G.degree(node)}"
            hover_text.append(info)
        
        node_trace.hovertext = hover_text
        
        # Create figure
        fig = go.Figure(
            data=[edge_trace, node_trace],
            layout=go.Layout(
                title=title,
                showlegend=False,
                hovermode='closest',
                xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
                yaxis=dict(showgrid=False, zeroline=False, showticklabels=False)
            )
        )
        
        if save_path:
            fig.write_html(save_path)
            logger.info(f"Interactive network saved to {save_path}")
        
        return fig
    
    def plot_network_pyvis(
        self,
        G: nx.Graph,
        title: str = "Network",
        save_path: str = "network.html",
        height: str = "750px",
        width: str = "100%",
        physics: bool = True
    ) -> str:
        """
        Create interactive HTML network with PyVis.
        
        Args:
            G: NetworkX graph
            title: Network title
            save_path: HTML save path
            height: Visualization height
            width: Visualization width
            physics: Enable physics simulation
            
        Returns:
            Path to saved HTML file
        """
        try:
            from pyvis.network import Network
        except ImportError:
            logger.error("PyVis not installed. Use pip install pyvis")
            return ""
        
        # Create PyVis network
        net = Network(
            height=height,
            width=width,
            bgcolor='#222222' if self.style == 'dark' else '#ffffff',
            font_color='white' if self.style == 'dark' else 'black'
        )
        
        # Add nodes and edges
        net.from_nx(G)
        
        # Configure physics
        if physics:
            net.toggle_physics(True)
        else:
            net.toggle_physics(False)
        
        # Add options
        net.set_options("""
        var options = {
          "nodes": {
            "borderWidth": 2,
            "borderWidthSelected": 4,
            "font": {"size": 14}
          },
          "edges": {
            "color": {"inherit": true},
            "smooth": false
          },
          "physics": {
            "forceAtlas2Based": {
              "gravitationalConstant": -50,
              "centralGravity": 0.01,
              "springLength": 100
            },
            "solver": "forceAtlas2Based"
          }
        }
        """)
        
        # Save
        net.save_graph(save_path)
        logger.info(f"PyVis network saved to {save_path}")
        
        return save_path
    
    def plot_3d_network(
        self,
        G: nx.Graph,
        node_color: str = 'community',
        title: str = "3D Network",
        save_path: Optional[str] = None
    ) -> Any:
        """
        Create 3D network visualization with Plotly.
        
        Args:
            G: NetworkX graph
            node_color: Color scheme
            title: Plot title
            save_path: Optional save path
            
        Returns:
            Plotly figure
        """
        try:
            import plotly.graph_objects as go
        except ImportError:
            logger.error("Plotly not installed")
            return None
        
        # 3D spring layout
        pos = nx.spring_layout(G, dim=3, seed=42)
        
        # Get colors
        colors = self._get_node_colors(G, node_color, as_numbers=True)
        
        # Create edge traces
        edge_x = []
        edge_y = []
        edge_z = []
        
        for edge in G.edges():
            x0, y0, z0 = pos[edge[0]]
            x1, y1, z1 = pos[edge[1]]
            edge_x.extend([x0, x1, None])
            edge_y.extend([y0, y1, None])
            edge_z.extend([z0, z1, None])
        
        edge_trace = go.Scatter3d(
            x=edge_x, y=edge_y, z=edge_z,
            line=dict(width=1, color='#888'),
            hoverinfo='none',
            mode='lines'
        )
        
        # Create node trace
        node_x = [pos[node][0] for node in G.nodes()]
        node_y = [pos[node][1] for node in G.nodes()]
        node_z = [pos[node][2] for node in G.nodes()]
        
        node_trace = go.Scatter3d(
            x=node_x, y=node_y, z=node_z,
            mode='markers+text',
            hoverinfo='text',
            marker=dict(
                size=6,
                color=colors,
                colorscale='Viridis',
                opacity=0.8
            ),
            text=list(G.nodes()),
            textposition='top center'
        )
        
        # Create figure
        fig = go.Figure(
            data=[edge_trace, node_trace],
            layout=go.Layout(
                title=title,
                showlegend=False,
                scene=dict(
                    xaxis=dict(showbackground=False),
                    yaxis=dict(showbackground=False),
                    zaxis=dict(showbackground=False)
                )
            )
        )
        
        if save_path:
            fig.write_html(save_path)
            logger.info(f"3D network saved to {save_path}")
        
        return fig
    
    def _compute_layout(
        self,
        G: nx.Graph,
        layout: str
    ) -> Dict:
        """Compute network layout."""
        if layout == 'spring':
            return nx.spring_layout(G, seed=42)
        elif layout == 'kamada_kawai':
            return nx.kamada_kawai_layout(G)
        elif layout == 'circular':
            return nx.circular_layout(G)
        elif layout == 'spectral':
            return nx.spectral_layout(G)
        elif layout == 'shell':
            return nx.shell_layout(G)
        elif layout == 'random':
            return nx.random_layout(G, seed=42)
        else:
            return nx.spring_layout(G, seed=42)
    
    def _get_node_colors(
        self,
        G: nx.Graph,
        color_by: str,
        as_numbers: bool = False
    ) -> List:
        """Get node colors based on scheme."""
        if color_by == 'community':
            # Detect communities
            try:
                import community as community_louvain
                partition = community_louvain.best_partition(G)
                colors = [partition[node] for node in G.nodes()]
            except ImportError:
                colors = [G.degree(node) for node in G.nodes()]
        
        elif color_by == 'degree':
            colors = [G.degree(node) for node in G.nodes()]
        
        elif isinstance(color_by, list):
            colors = color_by
        
        else:
            colors = [color_by] * G.number_of_nodes()
        
        if not as_numbers and isinstance(colors[0], (int, float)):
            import matplotlib.pyplot as plt
            cmap = plt.cm.viridis
            norm = plt.Normalize(min(colors), max(colors))
            colors = [cmap(norm(c)) for c in colors]
        
        return colors
    
    def plot_degree_distribution(
        self,
        G: nx.Graph,
        title: str = "Degree Distribution",
        save_path: Optional[str] = None
    ) -> Any:
        """Plot degree distribution."""
        import matplotlib.pyplot as plt
        
        degrees = [d for _, d in G.degree()]
        
        fig, axes = plt.subplots(1, 2, figsize=(12, 5))
        
        # Histogram
        axes[0].hist(degrees, bins=20, edgecolor='black', alpha=0.7)
        axes[0].set_xlabel('Degree')
        axes[0].set_ylabel('Frequency')
        axes[0].set_title('Degree Histogram')
        
        # Log-log plot
        unique, counts = np.unique(degrees, return_counts=True)
        axes[1].loglog(unique, counts, 'o', markersize=8)
        axes[1].set_xlabel('Degree (log)')
        axes[1].set_ylabel('Frequency (log)')
        axes[1].set_title('Degree Distribution (Log-Log)')
        
        plt.suptitle(title, fontsize=14, fontweight='bold')
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        
        return fig
    
    def plot_community_structure(
        self,
        G: nx.Graph,
        partition: Dict[str, int],
        title: str = "Community Structure",
        save_path: Optional[str] = None
    ) -> Any:
        """Visualize community structure."""
        import matplotlib.pyplot as plt
        
        fig, ax = plt.subplots(figsize=(12, 8))
        
        pos = nx.spring_layout(G, seed=42)
        
        # Color by community
        colors = [partition.get(node, 0) for node in G.nodes()]
        
        nx.draw_networkx(
            G, pos, ax=ax,
            node_color=colors,
            cmap=plt.cm.tab20,
            node_size=200,
            with_labels=True,
            font_size=8
        )
        
        ax.set_title(title, fontsize=14, fontweight='bold')
        ax.axis('off')
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        
        return fig
