"""
Report Generator

Generate PDF and HTML analysis reports.
"""

from typing import Dict, List, Optional, Any
from pathlib import Path
from datetime import datetime

import pandas as pd

from finnet.utils.logger import get_logger

logger = get_logger(__name__)


class ReportGenerator:
    """
    Generate analysis reports in PDF and HTML format.
    
    Features:
    - Executive summary
    - Network statistics
    - Sentiment analysis results
    - Visualization embedding
    """
    
    def __init__(self, output_dir: str = "./reports"):
        """
        Initialize report generator.
        
        Args:
            output_dir: Directory for report output
        """
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
    
    def generate_pdf_report(
        self,
        title: str = "FinNet Analysis Report",
        data: Optional[Dict[str, Any]] = None,
        figures: Optional[List[str]] = None,
        sections: Optional[Dict[str, str]] = None,
        save_path: Optional[str] = None
    ) -> str:
        """
        Generate PDF report using FPDF.
        
        Args:
            title: Report title
            data: Analysis data dictionary
            figures: List of figure paths to include
            sections: Dictionary of section_name -> content
            save_path: Output path
            
        Returns:
            Path to generated PDF
        """
        try:
            from fpdf import FPDF
        except ImportError:
            logger.error("FPDF2 required for PDF reports. Install: pip install fpdf2")
            return ""
        
        if save_path is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            save_path = str(self.output_dir / f"report_{timestamp}.pdf")
        
        pdf = FPDF()
        pdf.set_auto_page_break(auto=True, margin=15)
        
        # Title page
        pdf.add_page()
        pdf.set_font("Helvetica", "B", 24)
        pdf.cell(0, 60, "", ln=True)  # Spacer
        pdf.cell(0, 10, title, ln=True, align="C")
        
        pdf.set_font("Helvetica", "", 12)
        pdf.cell(0, 10, f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", ln=True, align="C")
        pdf.cell(0, 10, "FinNet - Financial Social Network Analysis", ln=True, align="C")
        
        # Add sections
        if sections:
            for section_name, content in sections.items():
                pdf.add_page()
                pdf.set_font("Helvetica", "B", 16)
                pdf.cell(0, 10, section_name, ln=True)
                pdf.ln(5)
                
                pdf.set_font("Helvetica", "", 11)
                # Handle multi-line content
                for line in content.split('\n'):
                    pdf.multi_cell(0, 6, line)
        
        # Add data tables
        if data:
            pdf.add_page()
            pdf.set_font("Helvetica", "B", 16)
            pdf.cell(0, 10, "Analysis Results", ln=True)
            pdf.ln(5)
            
            for key, value in data.items():
                pdf.set_font("Helvetica", "B", 12)
                pdf.cell(0, 8, str(key), ln=True)
                
                pdf.set_font("Helvetica", "", 10)
                if isinstance(value, pd.DataFrame):
                    # Table format
                    for col in value.columns[:5]:  # Limit columns
                        pdf.cell(35, 6, str(col)[:15], border=1)
                    pdf.ln()
                    
                    for idx, row in value.head(10).iterrows():
                        for col in value.columns[:5]:
                            val = str(row[col])[:15]
                            pdf.cell(35, 6, val, border=1)
                        pdf.ln()
                elif isinstance(value, dict):
                    for k, v in list(value.items())[:10]:
                        pdf.cell(0, 6, f"  {k}: {v}", ln=True)
                else:
                    pdf.multi_cell(0, 6, str(value)[:500])
                
                pdf.ln(5)
        
        # Add figures
        if figures:
            for fig_path in figures:
                if Path(fig_path).exists():
                    try:
                        pdf.add_page()
                        pdf.image(fig_path, x=10, y=30, w=190)
                    except Exception as e:
                        logger.warning(f"Could not add image {fig_path}: {e}")
        
        # Save
        pdf.output(save_path)
        logger.info(f"PDF report saved to {save_path}")
        
        return save_path
    
    def generate_html_report(
        self,
        title: str = "FinNet Analysis Report",
        data: Optional[Dict[str, Any]] = None,
        figures: Optional[List[str]] = None,
        sections: Optional[Dict[str, str]] = None,
        network_html: Optional[str] = None,
        save_path: Optional[str] = None
    ) -> str:
        """
        Generate interactive HTML report.
        
        Args:
            title: Report title
            data: Analysis data dictionary
            figures: List of figure paths
            sections: Dictionary of section_name -> content
            network_html: Path to interactive network HTML
            save_path: Output path
            
        Returns:
            Path to generated HTML
        """
        if save_path is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            save_path = str(self.output_dir / f"report_{timestamp}.html")
        
        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <style>
        * {{ box-sizing: border-box; }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            color: #eee;
            margin: 0;
            padding: 20px;
            min-height: 100vh;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
        }}
        h1 {{
            text-align: center;
            color: #00d4ff;
            text-shadow: 0 0 20px rgba(0, 212, 255, 0.5);
            margin-bottom: 10px;
        }}
        .subtitle {{
            text-align: center;
            color: #888;
            margin-bottom: 30px;
        }}
        .section {{
            background: rgba(255, 255, 255, 0.05);
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 25px;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }}
        h2 {{
            color: #00d4ff;
            border-bottom: 2px solid #00d4ff;
            padding-bottom: 10px;
            margin-top: 0;
        }}
        table {{
            width: 100%;
            border-collapse: collapse;
            margin: 15px 0;
        }}
        th, td {{
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }}
        th {{
            background: rgba(0, 212, 255, 0.2);
            color: #00d4ff;
        }}
        tr:hover {{
            background: rgba(255, 255, 255, 0.05);
        }}
        .metric-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }}
        .metric-card {{
            background: linear-gradient(135deg, rgba(0, 212, 255, 0.1), rgba(180, 0, 255, 0.1));
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            border: 1px solid rgba(0, 212, 255, 0.3);
        }}
        .metric-value {{
            font-size: 2em;
            font-weight: bold;
            color: #00d4ff;
        }}
        .metric-label {{
            color: #aaa;
            margin-top: 5px;
        }}
        img {{
            max-width: 100%;
            border-radius: 10px;
            margin: 10px 0;
        }}
        iframe {{
            width: 100%;
            height: 600px;
            border: none;
            border-radius: 10px;
        }}
        .footer {{
            text-align: center;
            color: #666;
            padding: 30px;
            margin-top: 30px;
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1>📊 {title}</h1>
        <p class="subtitle">Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | FinNet Analysis</p>
"""
        
        # Add sections
        if sections:
            for section_name, content in sections.items():
                html += f"""
        <div class="section">
            <h2>{section_name}</h2>
            <p>{content.replace(chr(10), '<br>')}</p>
        </div>
"""
        
        # Add data
        if data:
            for key, value in data.items():
                html += f"""
        <div class="section">
            <h2>{key}</h2>
"""
                if isinstance(value, pd.DataFrame):
                    html += value.to_html(classes='', index=False, max_rows=20)
                elif isinstance(value, dict):
                    html += '<div class="metric-grid">'
                    for k, v in list(value.items())[:8]:
                        html += f'''
            <div class="metric-card">
                <div class="metric-value">{v if not isinstance(v, float) else f"{v:.4f}"}</div>
                <div class="metric-label">{k}</div>
            </div>'''
                    html += '</div>'
                else:
                    html += f"<p>{value}</p>"
                
                html += "</div>"
        
        # Add network visualization
        if network_html and Path(network_html).exists():
            html += f"""
        <div class="section">
            <h2>Interactive Network</h2>
            <iframe src="{network_html}"></iframe>
        </div>
"""
        
        # Add figures
        if figures:
            html += '<div class="section"><h2>Visualizations</h2>'
            for fig_path in figures:
                if Path(fig_path).exists():
                    html += f'<img src="{fig_path}" alt="Visualization">'
            html += '</div>'
        
        html += """
        <div class="footer">
            <p>Generated by FinNet - Financial Social Network Analysis Platform</p>
        </div>
    </div>
</body>
</html>
"""
        
        # Save
        with open(save_path, 'w', encoding='utf-8') as f:
            f.write(html)
        
        logger.info(f"HTML report saved to {save_path}")
        return save_path
    
    def generate_excel_report(
        self,
        data: Dict[str, pd.DataFrame],
        save_path: Optional[str] = None
    ) -> str:
        """
        Generate Excel report with multiple sheets.
        
        Args:
            data: Dictionary mapping sheet names to DataFrames
            save_path: Output path
            
        Returns:
            Path to generated Excel file
        """
        try:
            import openpyxl
        except ImportError:
            logger.error("openpyxl required for Excel reports")
            return ""
        
        if save_path is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            save_path = str(self.output_dir / f"report_{timestamp}.xlsx")
        
        with pd.ExcelWriter(save_path, engine='openpyxl') as writer:
            for sheet_name, df in data.items():
                # Truncate sheet name if needed
                sheet_name = sheet_name[:31]
                df.to_excel(writer, sheet_name=sheet_name, index=False)
        
        logger.info(f"Excel report saved to {save_path}")
        return save_path
    
    def generate_summary(
        self,
        network_stats: Dict,
        sentiment_summary: Optional[Dict] = None,
        top_nodes: Optional[List] = None,
        communities: Optional[Dict] = None,
        anomalies: Optional[Dict] = None,
        cascade_results: Optional[Dict] = None,
        **kwargs
    ) -> Dict[str, str]:
        """
        Generate text summaries for report sections.
        
        Args:
            network_stats: Network statistics dictionary
            sentiment_summary: Sentiment analysis summary
            top_nodes: List of top nodes by centrality
            communities: Community detection results
            anomalies: Anomaly detection results
            cascade_results: Cascade simulation results
            
        Returns:
            Dictionary of section names to content
        """
        sections = {}
        
        # Network Overview
        sections["Network Overview"] = f"""
This analysis examined a financial network with {network_stats.get('num_nodes', 'N/A')} nodes and {network_stats.get('num_edges', 'N/A')} edges.
The network density is {network_stats.get('density', 0):.4f}, indicating {'a sparse' if network_stats.get('density', 0) < 0.1 else 'a relatively connected'} network structure.
Average clustering coefficient: {network_stats.get('avg_clustering', 0):.4f}
Average degree: {network_stats.get('avg_degree', 0):.2f}
"""
        
        # Sentiment Summary
        if sentiment_summary:
            sections["Sentiment Analysis"] = f"""
Analyzed {sentiment_summary.get('count', 0)} text items for sentiment.
Average sentiment score: {sentiment_summary.get('avg_score', 0):.3f}
Positive: {sentiment_summary.get('positive_pct', 0):.1f}%
Negative: {sentiment_summary.get('negative_pct', 0):.1f}%
Neutral: {sentiment_summary.get('neutral_pct', 0):.1f}%
"""
        
        # Key Influencers
        if top_nodes:
            nodes_str = ', '.join([str(n[0]) for n in top_nodes[:5]])
            sections["Key Influencers"] = f"""
Top nodes by centrality: {nodes_str}
These nodes have the highest influence in the network based on their connectivity patterns.
"""
        
        # Community Structure
        if communities:
            n_communities = len(set(communities.values()))
            sections["Community Structure"] = f"""
Detected {n_communities} distinct communities in the network.
Communities represent clusters of closely connected nodes that may share common characteristics or trading patterns.
"""

        # Anomaly Detection
        if anomalies:
            outliers = anomalies.get('node_outliers', {}).get('outliers', [])
            bridges = anomalies.get('bridge_nodes', [])
            sections["Anomaly Detection"] = f"""
Identified {len(outliers)} potential outliers: {', '.join(outliers[:5]) if outliers else 'None'}
Found {len(bridges)} bridge nodes (critical connections): {', '.join(bridges[:5]) if bridges else 'None'}
Anomalies may indicate unusual market behavior, arbitrage opportunities, or disconnected assets.
"""

        # Cascade Simulation
        if cascade_results:
            seeds = cascade_results.get('seeds', [])
            activated = cascade_results.get('total_activated', 0)
            ratio = cascade_results.get('activation_ratio', 0)
            sections["Information Cascade"] = f"""
Simulated information diffusion starting from seeds: {', '.join(map(str, seeds))}
Total activated nodes: {activated}
Activation ratio: {ratio:.1%}
This simulation models how shocks or news might propagate through the financial network.
"""
        
        return sections
