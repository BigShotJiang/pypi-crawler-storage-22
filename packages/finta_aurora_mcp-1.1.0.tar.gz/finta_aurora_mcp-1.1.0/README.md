# Aurora

## Running Aurora locally:

Pre-requisite: Ensure you have Docker installed on your system and you are logged in. If not, download and install it from the [official website](https://www.docker.com/products/docker-desktop/).

### LangGraph CLI (Recommended)

Pre-requisite: Set up a virtual environment and install dependencies:

1. Run `python3 -m venv .venv`
2. Run `.venv/bin/pip install -r requirements.txt`
3. Get the .env file contents from Kevin or someone on the team. Aurora will not run via docker without this file. 

To run Aurora:

1. Run `langgraph up` in the terminal from the aurora directory. This will start the Aurora server on `localhost:8123`.
2. IMPORTANT: Before prompting Aurora, you will need to press the `+` button on the Chatbot UI in order to create a new thread.

- Note: Langgraph up will start a build before running the container, so it may take a while to start

### LangGraph Cloud Desktop GUI (For Graph UI)

- Note:
  - Apple Silicon only, as of 09/2024
  - You will need to manually update the endpoint in equity-token-webapp/src/api/fintaAI/aurora

Pre-requisite: Install [LangGraph Studio for Desktop](https://github.com/langchain-ai/langgraph-studio)

1. Log in with LangSmith credentials
2. Navigate to the cloned Aurora repo folder location
3. When Aurora has finished building, find the 'localhost:xxxxx' endpoint to use in equity-token-webapp
4. Update the client endpoint in equity-token-webapp/src/api/fintaAI/aurora.js to the 'localhost:xxxxx' endpoint
   `const client = new Client({
apiUrl: [YOUR ENDPOINT HERE],
defaultHeaders: {
'X-API-KEY': LANGSMITH_API_KEY,
},
});`

## Using Aurora MCP (for Cursor/Claude Desktop/ChatGPT)

The Aurora MCP allows you to chat with Aurora directly from Cursor, Claude Desktop, or ChatGPT, with automatic injection of your CRM contacts and deal information.

**✅ Compatible with:**
- **Cursor** - IDE with built-in MCP support
- **Claude Desktop** - Anthropic's desktop app
- **Any MCP-compatible client** - Uses standard stdio protocol

### Installation

Install the Aurora MCP package via pip:

```bash
pip install finta-aurora-mcp
```

Or if you have the repo:

```bash
cd aurora
pip install -e .
```

### Step 1: Authenticate (one-time)

Run the authentication command:

```bash
aurora-authenticate
```

This will:
- Open your browser for Finta OAuth login
- Store your authentication token in `~/.cursor/aurora_token.json`
- Store your organization info in `~/.cursor/aurora_org_info.json`

**Note:** By default, authentication uses the **staging** environment. To use production, set `FINTA_STAGING=false` before running:

```bash
FINTA_STAGING=false aurora-authenticate
```

### Step 2: Add to MCP config

**For Cursor:**
Add this to your `~/.cursor/mcp.json` (create the file if it doesn't exist):

```json
{
  "mcpServers": {
    "aurora": {
      "command": "python3",
      "args": ["-m", "finta_aurora_mcp.mcp"]
    }
  }
}
```

**For Claude Desktop:**
Add this to your `~/Library/Application Support/Claude/claude_desktop_config.json` (macOS) or `%APPDATA%\Claude\claude_desktop_config.json` (Windows):

```json
{
  "mcpServers": {
    "aurora": {
      "command": "python3",
      "args": ["-m", "finta_aurora_mcp.mcp"]
    }
  }
}
```

**For ChatGPT/OpenAI:**
If OpenAI supports MCP servers, configure it similarly. Check OpenAI's documentation for their MCP configuration format.

**Note:** This references the installed package, so no file paths needed! The same package works with all MCP clients.

### Step 3: Restart Your Application

**Restart your application completely** (quit and reopen) for the MCP changes to take effect:
- **Cursor**: Quit and reopen Cursor
- **Claude Desktop**: Quit and reopen Claude Desktop
- **ChatGPT**: Follow OpenAI's instructions for reloading MCP servers

### Step 4: Use Aurora

Once set up, you can use Aurora by:

**In Cursor:**
1. Type `@aurora_chat` followed by your question
2. Example: `@aurora_chat Who are the investors in my CRM?`

**In Claude Desktop:**
1. Use the `aurora_chat` tool in Claude's tool picker
2. Or mention it in conversation: "Use aurora_chat to tell me about my CRM"

**In ChatGPT (if supported):**
1. Follow OpenAI's MCP tool usage instructions
2. The `aurora_chat` tool will be available in ChatGPT's tool list

Aurora will automatically have access to:
- Your CRM contacts (investors, status, emails)
- Your deal information (terms, industry, deal notes, etc.)
- All of Aurora's tools (search, add contacts, etc.)

### Troubleshooting

- **"Invalid or expired token"**: Run `aurora-authenticate` again to refresh your token
- **"Unknown tool: aurora_chat"**: Make sure you restarted Cursor after adding the MCP config
- **"Module not found: finta_aurora_mcp"**: Make sure you installed the package with `pip install finta-aurora-mcp`
- **No CRM/deal info in responses**: Check that your organization handle is correct and you have a default deal set up in Finta

## Deploying Aurora to LangGraph Cloud:

Pre-requisites:

1. Ensure you have access to [LangSmith](https://smith.langchain.com/)
2. Ensure your changes are pushed to the respective branch of the Aurora repo:
   - Production: `main`
   - Staging: `develop-Oct-2025`

#### On LangSmith:

1. Click on the `Deployments` tab
2. Find respective project:
   - Production: `aurora-v1-production`
   - Staging: `aurora-v1-staging`
3. Click on the `+ New Revision` button on the top right
4. Update environment variables as needed
5. Click Submit to redeploy your changes
