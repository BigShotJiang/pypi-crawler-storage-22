"""Finta Aurora MCP - Chat with Aurora AI from Cursor/Claude Desktop."""

__version__ = "1.1.0"
