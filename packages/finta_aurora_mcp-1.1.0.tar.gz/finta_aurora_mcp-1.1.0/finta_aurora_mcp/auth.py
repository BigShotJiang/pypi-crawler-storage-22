#!/usr/bin/env python3
"""
Aurora MCP Authentication
Simple OAuth login - opens browser and stores token.
"""

import os
import sys
import webbrowser
import http.server
import socketserver
import urllib.parse
import json
import requests
from pathlib import Path

FINTA_API_URL_STAGING = "https://us-central1-equity-token-stage.cloudfunctions.net"
FINTA_API_URL_PRODUCTION = "https://us-central1-equity-token.cloudfunctions.net"

def get_api_url():
    """Get API URL based on environment."""
    use_staging = os.getenv("FINTA_STAGING", "true").lower() == "true"
    return FINTA_API_URL_STAGING if use_staging else FINTA_API_URL_PRODUCTION

def get_token_path():
    """Get path to store token."""
    return Path.home() / ".cursor" / "aurora_token.json"

def main():
    print("Aurora MCP Authentication")
    print("=" * 40)
    print("Opening browser for login...\n")
    
    api_url = get_api_url()
    auth_url = (
        f"{api_url}/auroraOAuthAuthorize?"
        f"response_type=code&"
        f"client_id=cursor&"
        f"redirect_uri=http://localhost:8765/callback"
    )
    
    webbrowser.open(auth_url)
    
    class CallbackHandler(http.server.SimpleHTTPRequestHandler):
        def do_GET(self):
            query = urllib.parse.urlparse(self.path).query
            params = urllib.parse.parse_qs(query)
            
            if 'code' in params:
                code = params['code'][0]
                api_url = get_api_url()
                
                try:
                    resp = requests.post(
                        f"{api_url}/auroraOAuthToken",
                        json={
                            "grant_type": "authorization_code",
                            "code": code,
                            "redirect_uri": "http://localhost:8765/callback"
                        },
                        timeout=10
                    )
                    
                    if resp.status_code == 200:
                        token_data = resp.json()
                        access_token = token_data.get("access_token")
                        
                        token_path = get_token_path()
                        token_path.parent.mkdir(exist_ok=True)
                        with open(token_path, 'w') as f:
                            json.dump(token_data, f, indent=2)
                        
                        self.send_response(200)
                        self.send_header('Content-type', 'text/html; charset=utf-8')
                        self.end_headers()
                        html = """<html><body style="font-family: system-ui; padding: 40px; text-align: center;"><h1>Authentication Successful!</h1><p>Token has been stored.</p><p>You can close this window and restart Cursor.</p></body></html>"""
                        self.wfile.write(html.encode('utf-8'))
                        print("\n✓ Authentication successful!")
                        print(f"✓ Token stored at: {token_path}")
                        print("\nRestart Cursor to use Aurora MCP.")
                        return
                    else:
                        print(f"\n✗ Failed to get token: {resp.status_code} - {resp.text}")
                except Exception as e:
                    print(f"\n✗ Error: {e}")
            
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            self.wfile.write(b"<h1>Processing...</h1>")
        
        def log_message(self, *args):
            pass
    
    with socketserver.TCPServer(("", 8765), CallbackHandler) as httpd:
        print("Waiting for authentication callback...")
        print("(Press Ctrl+C to cancel)\n")
        try:
            httpd.handle_request()
        except KeyboardInterrupt:
            print("\n\n✗ Authentication cancelled.")
            sys.exit(1)

if __name__ == "__main__":
    main()
