#!/usr/bin/env python3
"""Fix org_info file to add missing founderId field."""

import json
import sys
from pathlib import Path

ORG_INFO_PATH = Path.home() / ".cursor" / "aurora_org_info.json"

def fix_org_info():
    """Add founderId to org_info if missing."""
    if not ORG_INFO_PATH.exists():
        print("Error: org_info file does not exist. Please run: aurora-authenticate")
        return False
    
    try:
        with open(ORG_INFO_PATH) as f:
            org_info = json.load(f)
        
        print(f"Current org_info: {json.dumps(org_info, indent=2)}")
        
        # Add founderId if missing
        if not org_info.get("founderId"):
            founder_id = org_info.get("user_id") or org_info.get("userId")
            if founder_id:
                org_info["founderId"] = founder_id
                with open(ORG_INFO_PATH, 'w') as f:
                    json.dump(org_info, f, indent=2)
                print(f"\n✅ Updated org_info with founderId: {founder_id}")
                print(f"Updated org_info: {json.dumps(org_info, indent=2)}")
                return True
            else:
                print("\n❌ Error: No user_id found in org_info. Please re-authenticate with: aurora-authenticate")
                return False
        else:
            print(f"\n✅ org_info already has founderId: {org_info.get('founderId')}")
            return True
    except Exception as e:
        print(f"Error fixing org_info: {e}", file=sys.stderr)
        return False

if __name__ == "__main__":
    success = fix_org_info()
    sys.exit(0 if success else 1)
