#!/usr/bin/env python3
"""
Aurora MCP Server - Exposes all Aurora tools individually

Each tool calls a Firebase Cloud Function endpoint which:
1. Validates the user's OAuth token
2. Executes the tool with secure API keys (stored in Firebase Config)
3. Returns the result

Architecture:
  Cursor MCP (local) → Firebase Functions (auth + API keys) → External Services
"""

import asyncio
import json
import sys
import os
from pathlib import Path
from typing import Any, Dict, List, Optional

import httpx
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

TOKEN_PATH = Path.home() / ".cursor" / "aurora_token.json"
ORG_INFO_PATH = Path.home() / ".cursor" / "aurora_org_info.json"
FINTA_API_URL = os.getenv("FINTA_API_URL", "https://us-central1-equity-token-stage.cloudfunctions.net")


def get_token():
    """Load stored OAuth token."""
    try:
        if TOKEN_PATH.exists():
            with open(TOKEN_PATH) as f:
                data = json.load(f)
                return data.get("access_token")
    except Exception as e:
        print(f"Error loading token: {e}", file=sys.stderr)
    return None


def get_org_info():
    """Load stored org info."""
    try:
        if ORG_INFO_PATH.exists():
            with open(ORG_INFO_PATH) as f:
                return json.load(f)
    except Exception as e:
        print(f"Error loading org info: {e}", file=sys.stderr)
    return None


async def fetch_and_store_org_info(token: str):
    """Fetch org info from the validation endpoint and store it."""
    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{FINTA_API_URL}/validateAuroraOAuthToken",
                headers={"Authorization": f"Bearer {token}"},
                timeout=10.0
            )
            if response.status_code == 200:
                data = response.json()
                if data.get("valid"):
                    user_id = data.get("userId")
                    org_info = {
                        "organization_id": data.get("organizationId"),
                        "organization_name": data.get("organizationName"),
                        "user_id": user_id,
                        "founderId": user_id,
                        "handle": data.get("organizationId"),
                    }
                    with open(ORG_INFO_PATH, 'w') as f:
                        json.dump(org_info, f, indent=2)
                    return org_info
    except Exception as e:
        print(f"Error fetching org info: {e}", file=sys.stderr)
    return None


# =========================================================================
# Helper: Make authenticated request to Firebase
# =========================================================================

async def firebase_request(method: str, path: str, token: str, **kwargs) -> dict:
    """Make an authenticated request to a Firebase Cloud Function endpoint."""
    url = f"{FINTA_API_URL}{path}"
    headers = {"Authorization": f"Bearer {token}"}
    if "headers" in kwargs:
        headers.update(kwargs.pop("headers"))

    async with httpx.AsyncClient() as client:
        if method == "GET":
            response = await client.get(url, headers=headers, params=kwargs.get("params"), timeout=kwargs.get("timeout", 30.0))
        elif method == "POST":
            response = await client.post(url, headers=headers, json=kwargs.get("json"), timeout=kwargs.get("timeout", 60.0))
        else:
            raise ValueError(f"Unsupported method: {method}")

        if response.status_code == 200:
            return {"success": True, "data": response.json()}
        else:
            error_text = response.text
            try:
                error_data = response.json()
                error_text = error_data.get("error", error_text)
            except Exception:
                pass
            return {"success": False, "error": f"HTTP {response.status_code}: {error_text}"}


# =========================================================================
# MCP Server Setup
# =========================================================================

server = Server("aurora-tools")


@server.list_tools()
async def list_tools():
    """List all available Aurora tools."""
    token = get_token()
    if not token:
        return [
            Tool(
                name="aurora_login",
                description="You need to authenticate first. Run: aurora-authenticate",
                inputSchema={"type": "object", "properties": {}}
            )
        ]

    # Get org_info for tools that need it
    org_info = get_org_info()
    if not org_info:
        org_info = await fetch_and_store_org_info(token)

    tools = []

    # 1. Search Google (SerpAPI)
    tools.append(Tool(
        name="search_google",
        description="Search Google for information, news, or answers to questions. Use this to find current information, company details, investor profiles, or any web-based information.",
        inputSchema={
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "The search query to search Google for"
                }
            },
            "required": ["query"]
        }
    ))

    # 2. Scrape Website
    tools.append(Tool(
        name="scrape_website",
        description="Scrape and extract text content from any website URL. Use this to get information from web pages, articles, or documents.",
        inputSchema={
            "type": "object",
            "properties": {
                "url": {
                    "type": "string",
                    "description": "The URL of the website to scrape"
                }
            },
            "required": ["url"]
        }
    ))

    # 3. Scrape PDF
    tools.append(Tool(
        name="scrape_pdf",
        description="Download and extract text from a PDF file. Use this to read PDF documents, pitch decks, or reports.",
        inputSchema={
            "type": "object",
            "properties": {
                "pdfUrl": {
                    "type": "string",
                    "description": "The URL of the PDF file to scrape"
                }
            },
            "required": ["pdfUrl"]
        }
    ))

    # 4. Search Finta Knowledge Base
    tools.append(Tool(
        name="search_finta_knowledge",
        description="Search Finta's knowledge base for how-to guides, best practices, and information about using Finta's features like Deal Rooms, Investor Tracker CRM, prospecting leads, and more.",
        inputSchema={
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "The question or topic to search for in Finta's knowledge base"
                }
            },
            "required": ["query"]
        }
    ))

    # 5. Search Finta Resources
    tools.append(Tool(
        name="search_finta_resources",
        description="Search Finta's resource database for product documentation, help center articles, and guides about using Finta's software.",
        inputSchema={
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "The question or topic to search for in Finta's resources"
                }
            },
            "required": ["query"]
        }
    ))

    # 6. Get Investor Info
    tools.append(Tool(
        name="get_investor_info",
        description="Get detailed information about an investor in your CRM. You can search by investor ID, name, or email address.",
        inputSchema={
            "type": "object",
            "properties": {
                "investorId": {
                    "type": "string",
                    "description": "Investor's ID (if you have it)"
                },
                "investorName": {
                    "type": "string",
                    "description": "Investor's name (e.g., 'John Smith') - use this if you don't have the ID"
                },
                "investorEmail": {
                    "type": "string",
                    "description": "Investor's email address - use this if you don't have the ID or name"
                }
            }
        }
    ))

    # 7. Add Investor to CRM
    if org_info and org_info.get("handle"):
        tools.append(Tool(
            name="add_investor_to_crm",
            description="Add a new investor contact to your CRM tracker. Provide as much information as available - you don't need all fields.",
            inputSchema={
                "type": "object",
                "properties": {
                    "firstName": {
                        "type": "string",
                        "description": "Investor's first name (required)"
                    },
                    "lastName": {
                        "type": "string",
                        "description": "Investor's last name"
                    },
                    "email": {
                        "type": "string",
                        "description": "Investor's email address"
                    },
                    "location": {
                        "type": "string",
                        "description": "Investor's location"
                    },
                    "organizationName": {
                        "type": "string",
                        "description": "Name of the investor's organization"
                    },
                    "organizationWebsite": {
                        "type": "string",
                        "description": "Website of the investor's organization"
                    },
                    "linkedIn": {
                        "type": "string",
                        "description": "Investor's LinkedIn profile URL"
                    },
                    "twitter": {
                        "type": "string",
                        "description": "Investor's Twitter profile URL"
                    },
                    "crunchbase": {
                        "type": "string",
                        "description": "Investor's Crunchbase profile URL"
                    },
                    "bio": {
                        "type": "string",
                        "description": "Short biography of the investor"
                    },
                    "tags": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "List of tags to assign (e.g., ['Super Angel', 'Series A'])"
                    }
                },
                "required": ["firstName"]
            }
        ))

    # 8. Edit Investor
    if org_info and org_info.get("handle"):
        tools.append(Tool(
            name="edit_investor",
            description="Update information for an existing investor in your CRM. You can search by investor ID, name, or email, then update any fields.",
            inputSchema={
                "type": "object",
                "properties": {
                    "id": {
                        "type": "string",
                        "description": "Investor document ID (if you have it)"
                    },
                    "investorName": {
                        "type": "string",
                        "description": "Investor's name to search for (if you don't have the ID)"
                    },
                    "investorEmail": {
                        "type": "string",
                        "description": "Investor's email to search for (if you don't have the ID)"
                    },
                    "firstName": {"type": "string", "description": "First name"},
                    "lastName": {"type": "string", "description": "Last name"},
                    "email": {"type": "string", "description": "Email"},
                    "status": {
                        "type": "string",
                        "description": "Tracker status: target, emailed, viewed, interested, diligence, committed, invested, passed"
                    },
                    "grade": {"type": "string", "description": "Investor grade (e.g., 'A', 'B', 'C')"},
                    "amount": {"type": "string", "description": "Investment amount"},
                    "notes": {"type": "string", "description": "Notes about the investor"},
                    "dealName": {"type": "string", "description": "Deal name or round (e.g., 'Seed', 'Series B')"},
                    "tags": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "List of tags (replaces all existing tags)"
                    }
                }
            }
        ))

    # 9. Get Deal Info
    if org_info and org_info.get("handle"):
        tools.append(Tool(
            name="get_deal_info",
            description="Get information about your current fundraising deal, including terms, round size, type, and more.",
            inputSchema={
                "type": "object",
                "properties": {},
                "required": []
            }
        ))

    # 10. List Investors
    if org_info and org_info.get("handle"):
        tools.append(Tool(
            name="list_investors",
            description="List all investors in your CRM tracker with their status, amount, and contact info.",
            inputSchema={
                "type": "object",
                "properties": {},
                "required": []
            }
        ))

    # 11. Analyze Image
    tools.append(Tool(
        name="analyze_image",
        description="Analyze an image and answer questions about it. Use this to understand images, screenshots, charts, or diagrams.",
        inputSchema={
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "What you want to know about the image"
                },
                "imageUrl": {
                    "type": "string",
                    "description": "URL of the image to analyze"
                }
            },
            "required": ["query", "imageUrl"]
        }
    ))

    # 12. Contact Support
    tools.append(Tool(
        name="contact_support",
        description="Get information about contacting Finta support for additional help.",
        inputSchema={
            "type": "object",
            "properties": {},
            "required": []
        }
    ))

    return tools


@server.call_tool()
async def call_tool(name: str, arguments: dict):
    """Handle tool calls - route each to the appropriate Firebase endpoint."""
    token = get_token()
    if not token:
        return [TextContent(
            type="text",
            text="Not authenticated. Run: aurora-authenticate"
        )]

    org_info = get_org_info()
    if not org_info:
        org_info = await fetch_and_store_org_info(token)

    # Route to appropriate handler
    try:
        if name == "search_google":
            return await handle_search_google(arguments, token)
        elif name == "scrape_website":
            return await handle_scrape_website(arguments, token)
        elif name == "scrape_pdf":
            return await handle_scrape_pdf(arguments, token)
        elif name == "search_finta_knowledge":
            return await handle_search_knowledge(arguments, token)
        elif name == "search_finta_resources":
            return await handle_search_resources(arguments, token)
        elif name == "get_investor_info":
            return await handle_get_investor_info(arguments, org_info, token)
        elif name == "add_investor_to_crm":
            return await handle_add_investor(arguments, org_info, token)
        elif name == "edit_investor":
            return await handle_edit_investor(arguments, org_info, token)
        elif name == "get_deal_info":
            return await handle_get_deal_info(org_info, token)
        elif name == "list_investors":
            return await handle_list_investors(org_info, token)
        elif name == "analyze_image":
            return await handle_analyze_image(arguments, token)
        elif name == "contact_support":
            return [TextContent(type="text", text="For support, visit https://www.trustfinta.com or email support@trustfinta.com")]
        else:
            return [TextContent(type="text", text=f"Unknown tool: {name}")]
    except Exception as e:
        return [TextContent(type="text", text=f"Error executing {name}: {str(e)}")]


# =========================================================================
# Tool Handlers - Each calls a Firebase endpoint
# =========================================================================

async def handle_search_google(arguments: dict, token: str):
    """Search Google via Firebase → SerpAPI."""
    query = arguments.get("query", "")
    if not query:
        return [TextContent(type="text", text="Error: query is required")]

    result = await firebase_request("POST", "/fintaAI/tools/search-google", token, json={"query": query}, timeout=20.0)
    if result["success"]:
        return [TextContent(type="text", text=result["data"].get("result", "No results found"))]
    return [TextContent(type="text", text=f"Error searching Google: {result['error']}")]


async def handle_scrape_website(arguments: dict, token: str):
    """Scrape website via existing Firebase endpoint."""
    url = arguments.get("url", "")
    if not url:
        return [TextContent(type="text", text="Error: url is required")]

    result = await firebase_request("POST", "/fintaAI/tools/scrape-website", token, json={"url": url}, timeout=60.0)
    if result["success"]:
        return [TextContent(type="text", text=result["data"].get("content", "No content found"))]
    return [TextContent(type="text", text=f"Error scraping website: {result['error']}")]


async def handle_scrape_pdf(arguments: dict, token: str):
    """Scrape PDF via Firebase endpoint."""
    pdf_url = arguments.get("pdfUrl", "")
    if not pdf_url:
        return [TextContent(type="text", text="Error: pdfUrl is required")]

    result = await firebase_request("POST", "/fintaAI/tools/scrape-pdf", token, json={"pdfUrl": pdf_url}, timeout=120.0)
    if result["success"]:
        text = result["data"].get("result", "No content extracted")
        pages = result["data"].get("pages")
        if pages:
            text = f"[{pages} pages]\n\n{text}"
        return [TextContent(type="text", text=text)]
    return [TextContent(type="text", text=f"Error scraping PDF: {result['error']}")]


async def handle_search_knowledge(arguments: dict, token: str):
    """Search Finta knowledge base via Firebase → Pinecone."""
    query = arguments.get("query", "")
    if not query:
        return [TextContent(type="text", text="Error: query is required")]

    result = await firebase_request("POST", "/fintaAI/tools/search-knowledge", token, json={"query": query}, timeout=30.0)
    if result["success"]:
        return [TextContent(type="text", text=result["data"].get("result", "No results found"))]
    return [TextContent(type="text", text=f"Error searching knowledge base: {result['error']}")]


async def handle_search_resources(arguments: dict, token: str):
    """Search Finta resources via Firebase → Pinecone."""
    query = arguments.get("query", "")
    if not query:
        return [TextContent(type="text", text="Error: query is required")]

    result = await firebase_request("POST", "/fintaAI/tools/search-resources", token, json={"query": query}, timeout=30.0)
    if result["success"]:
        return [TextContent(type="text", text=result["data"].get("result", "No results found"))]
    return [TextContent(type="text", text=f"Error searching resources: {result['error']}")]


async def handle_get_investor_info(arguments: dict, org_info: dict, token: str):
    """Get investor info via existing Firebase endpoints."""
    if not org_info or not org_info.get("handle"):
        return [TextContent(type="text", text="Error: Organization info not available. Please re-authenticate.")]

    handle = org_info.get("handle")
    investor_id = arguments.get("investorId", "")
    investor_name = arguments.get("investorName", "")
    investor_email = arguments.get("investorEmail", "")

    if investor_id:
        # Direct lookup by ID
        result = await firebase_request(
            "GET", "/fintaAI/tools/get-investor-info", token,
            params={"investorId": investor_id, "organizationHandle": handle},
            timeout=15.0
        )
        if result["success"]:
            return [TextContent(type="text", text=json.dumps(result["data"].get("investorInfo", result["data"]), indent=2))]
        return [TextContent(type="text", text=f"Error getting investor info: {result['error']}")]

    elif investor_name or investor_email:
        # Search first
        search_params = {"organizationHandle": handle}
        if investor_email:
            search_params["email"] = investor_email
        elif investor_name:
            search_params["name"] = investor_name

        search_result = await firebase_request(
            "GET", "/fintaAI/tools/search-investor", token,
            params=search_params, timeout=15.0
        )

        if not search_result["success"]:
            return [TextContent(type="text", text=f"Error searching investor: {search_result['error']}")]

        investors = search_result["data"].get("investors", [])
        if not investors:
            search_term = f"email: {investor_email}" if investor_email else f"name: {investor_name}"
            return [TextContent(type="text", text=f"No investor found with {search_term}")]

        if len(investors) > 1:
            # Multiple matches - show all
            lines = [f"Found {len(investors)} investors:"]
            for inv in investors[:5]:
                inv_data = inv.get("investor", {})
                name = f"{inv_data.get('firstName', '')} {inv_data.get('lastName', '')}".strip()
                lines.append(f"  - {name} ({inv_data.get('email', 'no email')}) - Status: {inv.get('status', 'unknown')} - ID: {inv['id']}")
            return [TextContent(type="text", text="\n".join(lines))]

        # Get full info for the single match
        matched_id = investors[0]["id"]
        result = await firebase_request(
            "GET", "/fintaAI/tools/get-investor-info", token,
            params={"investorId": matched_id, "organizationHandle": handle},
            timeout=15.0
        )
        if result["success"]:
            return [TextContent(type="text", text=json.dumps(result["data"].get("investorInfo", result["data"]), indent=2))]
        return [TextContent(type="text", text=f"Error getting investor info: {result['error']}")]

    else:
        return [TextContent(type="text", text="Error: Either investorId, investorName, or investorEmail must be provided")]


async def handle_add_investor(arguments: dict, org_info: dict, token: str):
    """Add investor to CRM via existing Firebase endpoint."""
    if not org_info or not org_info.get("handle") or not org_info.get("founderId"):
        return [TextContent(type="text", text="Error: Organization info not available. Please re-authenticate.")]

    data = {
        "organizationId": org_info.get("handle"),
        "sourceUserId": org_info.get("founderId"),
        "investorFields": {
            "firstName": arguments.get("firstName", ""),
            "lastName": arguments.get("lastName", ""),
            "email": arguments.get("email", ""),
            "location": arguments.get("location", ""),
            "organizationName": arguments.get("organizationName", ""),
            "organizationWebsite": arguments.get("organizationWebsite", ""),
            "linkedIn": arguments.get("linkedIn", ""),
            "twitter": arguments.get("twitter", ""),
            "crunchbase": arguments.get("crunchbase", ""),
            "bio": arguments.get("bio", ""),
        }
    }

    if arguments.get("tags"):
        data["tags"] = arguments["tags"]

    result = await firebase_request("POST", "/fintaAI/tools/add-investor", token, json=data, timeout=15.0)
    if result["success"]:
        return [TextContent(type="text", text="Success! Investor added to Finta's CRM Tracker.")]
    return [TextContent(type="text", text=f"Error adding investor: {result['error']}")]


async def handle_edit_investor(arguments: dict, org_info: dict, token: str):
    """Edit investor via Firebase endpoints (search + update)."""
    if not org_info or not org_info.get("handle") or not org_info.get("founderId"):
        return [TextContent(type="text", text="Error: Organization info not available. Please re-authenticate.")]

    handle = org_info.get("handle")
    source_user_id = org_info.get("founderId")

    investor_id = arguments.get("id", "")
    investor_name = arguments.get("investorName", "")
    investor_email = arguments.get("investorEmail", "")
    deal_name = arguments.get("dealName", "")
    use_tracker = False

    # Step 1: Find investor if ID not provided
    if not investor_id:
        if not investor_name and not investor_email:
            return [TextContent(type="text", text="Error: Either id, investorName, or investorEmail must be provided")]

        # Search in target_investors first
        search_params = {"organizationHandle": handle}
        if investor_email:
            search_params["email"] = investor_email
        elif investor_name:
            search_params["name"] = investor_name

        search_result = await firebase_request(
            "GET", "/fintaAI/tools/search-investor", token,
            params=search_params, timeout=15.0
        )

        if search_result["success"] and search_result["data"].get("investors"):
            investors = search_result["data"]["investors"]
            investor_id = investors[0]["id"]
            use_tracker = False
        else:
            # Try investor_tracker
            tracker_result = await firebase_request(
                "GET", "/fintaAI/tools/search-tracker-entry", token,
                params=search_params, timeout=15.0
            )
            if tracker_result["success"] and tracker_result["data"].get("entries"):
                entries = tracker_result["data"]["entries"]
                investor_id = entries[0]["id"]
                use_tracker = True
            else:
                search_term = f"email: {investor_email}" if investor_email else f"name: {investor_name}"
                return [TextContent(type="text", text=f"No investor found with {search_term}")]

    # Step 2: Resolve deal if dealName provided
    resolved_deal_id = arguments.get("dealId", "")
    if not resolved_deal_id and deal_name:
        deal_result = await firebase_request(
            "GET", "/fintaAI/tools/search-deal", token,
            params={"organizationHandle": handle, "dealName": deal_name},
            timeout=15.0
        )
        if deal_result["success"] and deal_result["data"].get("deals"):
            resolved_deal_id = deal_result["data"]["deals"][0]["id"]

    # Step 3: Build update payload
    investor_fields = {}
    fields = {}

    # Investor fields (nested)
    for key in ["firstName", "lastName", "email", "location", "organizationName",
                "organizationWebsite", "linkedIn", "twitter", "crunchbase", "bio"]:
        value = arguments.get(key, "")
        if value:
            investor_fields[key] = value

    # Top-level fields
    status_mapping = {
        'target investor': 'target', 'target': 'target',
        'in contact': 'emailed', 'emailed': 'emailed',
        'viewed deal': 'viewed', 'viewed': 'viewed',
        'interested': 'interested', 'diligence': 'diligence',
        'committed': 'committed', 'money in the bank': 'invested',
        'invested': 'invested', 'passed': 'passed',
    }

    status = arguments.get("status", "")
    if status:
        fields["status"] = status_mapping.get(status.lower().strip(), status.lower().strip())

    for key in ["grade", "amount", "notes"]:
        value = arguments.get(key, "")
        if value:
            fields[key] = value

    if resolved_deal_id:
        fields["dealId"] = resolved_deal_id

    if arguments.get("tags") is not None:
        fields["tags"] = arguments["tags"]

    # Step 4: Update
    endpoint = "/fintaAI/tools/update-tracker-entry" if use_tracker else "/fintaAI/tools/update-target-investor"
    payload = {
        "data": {
            "id": investor_id,
            "organizationId": handle,
            "sourceUserId": source_user_id,
            "investorFields": investor_fields,
            "fields": fields,
        }
    }

    result = await firebase_request("POST", endpoint, token, json=payload, timeout=15.0)
    if result["success"]:
        collection_name = "tracker entry" if use_tracker else "investor"
        return [TextContent(type="text", text=f"Success! {collection_name.capitalize()} updated.")]
    return [TextContent(type="text", text=f"Error updating investor: {result['error']}")]


async def handle_get_deal_info(org_info: dict, token: str):
    """Get deal info via existing Firebase endpoint."""
    if not org_info or not org_info.get("handle"):
        return [TextContent(type="text", text="Error: Organization info not available. Please re-authenticate.")]

    result = await firebase_request(
        "GET", "/fintaAI/tools/get-deal-info", token,
        params={"organizationHandle": org_info.get("handle")},
        timeout=15.0
    )
    if result["success"]:
        formatted = result["data"].get("formatted", "")
        if formatted:
            return [TextContent(type="text", text=formatted)]
        return [TextContent(type="text", text=json.dumps(result["data"].get("dealInfo", result["data"]), indent=2))]
    return [TextContent(type="text", text=f"Error getting deal info: {result['error']}")]


async def handle_list_investors(org_info: dict, token: str):
    """List investors via existing Firebase endpoint."""
    if not org_info or not org_info.get("handle"):
        return [TextContent(type="text", text="Error: Organization info not available. Please re-authenticate.")]

    result = await firebase_request(
        "GET", "/fintaAI/tools/list-investors", token,
        params={"organizationHandle": org_info.get("handle")},
        timeout=30.0
    )
    if result["success"]:
        data = result["data"]
        count = data.get("count", 0)
        formatted = data.get("formatted", "")
        if formatted:
            return [TextContent(type="text", text=f"Found {count} investors:\n\nName; Organization; Status; Amount; Time Engaged; Email\n{formatted}")]
        return [TextContent(type="text", text=json.dumps(data, indent=2))]
    return [TextContent(type="text", text=f"Error listing investors: {result['error']}")]


async def handle_analyze_image(arguments: dict, token: str):
    """Analyze image via Firebase → OpenAI Vision."""
    query = arguments.get("query", "")
    image_url = arguments.get("imageUrl", "")

    if not query or not image_url:
        return [TextContent(type="text", text="Error: Both query and imageUrl are required")]

    result = await firebase_request(
        "POST", "/fintaAI/tools/analyze-image", token,
        json={"query": query, "imageUrl": image_url, "model_name": arguments.get("model_name", "gpt-4o")},
        timeout=60.0
    )
    if result["success"]:
        return [TextContent(type="text", text=result["data"].get("result", "No analysis available"))]
    return [TextContent(type="text", text=f"Error analyzing image: {result['error']}")]


# =========================================================================
# Main entry point
# =========================================================================

async def main():
    """Run the MCP server."""
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options()
        )


if __name__ == "__main__":
    asyncio.run(main())
