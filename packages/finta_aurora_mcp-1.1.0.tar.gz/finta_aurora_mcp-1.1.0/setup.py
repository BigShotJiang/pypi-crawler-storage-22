"""Setup script for Finta Aurora MCP package."""

from setuptools import setup, find_packages
from pathlib import Path

readme_file = Path(__file__).parent / "README.md"
long_description = ""
if readme_file.exists():
    long_description = readme_file.read_text()

setup(
    name="finta-aurora-mcp",
    version="1.1.0",
    description="Aurora MCP client for Cursor/Claude Desktop - Chat with Finta's AI assistant",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Finta",
    author_email="support@trustfinta.com",
    url="https://github.com/finta/aurora",
    py_modules=[],
    packages=["finta_aurora_mcp"],  # Only include the MCP client, NOT agent tools
    install_requires=[
        "httpx>=0.27.0",
        "mcp>=0.1.0",
        "requests>=2.31.0",
    ],
    entry_points={
        "console_scripts": [
            "aurora-authenticate=finta_aurora_mcp.auth:main",
            "aurora-mcp=finta_aurora_mcp.mcp:main",
        ],
    },
    python_requires=">=3.8",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
)
