from dataclasses import dataclass, field
from typing import Literal, Optional
from datetime import datetime


@dataclass
class UniverseConfig:
    """Universe configuration for attribution analysis."""
    name: Literal['us_stock', 'kr_stock']
    date_col: str = 'Date'
    next_date_col: str = 'NextDate'
    weight_col: str = 'weight'
    tri_col: str = 'TRI'
    gics_col: str = 'gics'
    category_col: str = 'sector'
    cash_id: Optional[str] = 'CASH'

    # ID columns (set based on universe)
    id_col: str = field(init=False)
    entity_col: str = field(init=False)

    def __post_init__(self):
        if self.name == 'us_stock':
            self.id_col = 'gvkeyiid'
            self.entity_col = 'gvkey'
        elif self.name == 'kr_stock':
            self.id_col = 'ccid'
            self.entity_col = 'ccid'
        else:
            raise ValueError(f"Invalid universe name: {self.name}")


@dataclass
class DateConfig:
    """Date configuration for attribution analysis."""
    start: str  # YYYYMMDD format
    end: str    # YYYYMMDD format
    lookback_days: int = 360
    lookforward_days: int = 60

    @property
    def preload_start(self) -> int:
        start_dt = datetime.strptime(self.start, '%Y%m%d')
        from datetime import timedelta
        preload_dt = start_dt - timedelta(days=self.lookback_days)
        return int(preload_dt.strftime('%Y%m%d'))

    @property
    def preload_end(self) -> int:
        end_dt = datetime.strptime(self.end, '%Y%m%d')
        from datetime import timedelta
        preload_dt = end_dt + timedelta(days=self.lookforward_days)
        return int(preload_dt.strftime('%Y%m%d'))


@dataclass
class AttributionConfig:
    """Configuration for attribution analysis."""
    universe: UniverseConfig
    dates: DateConfig
    benchmark_id: str
    portfolio_id: str
    sector_data_id: str

    # Attribution settings
    model: Literal['brinson', 'carino'] = 'carino'
    freq: Literal['D', 'W', 'M', 'Q', 'Y'] = 'Q'
    use_polars: bool = True
    drop_cash: bool = True  # Exclude cash positions from attribution calculation

    # Holdings loading settings
    cum_threshold: Optional[float] = None
    max_weight: float = 1e8
    normalize_weights: bool = True

    @classmethod
    def us_stock(cls,
                 benchmark_id: str,
                 portfolio_id: str,
                 start: str,
                 end: str,
                 cash_id: Optional[str] = 'CASH',
                 **kwargs) -> 'AttributionConfig':
        """Factory method for US stock attribution config."""
        universe = UniverseConfig(name='us_stock', cash_id=cash_id)
        dates = DateConfig(start=start, end=end)
        sector_data_id = "content.spglobal.compustat.classification.us-stock-gics.1d"

        return cls(
            universe=universe,
            dates=dates,
            benchmark_id=benchmark_id,
            portfolio_id=portfolio_id,
            sector_data_id=sector_data_id,
            **kwargs
        )

    @classmethod
    def kr_stock(cls,
                 benchmark_id: str,
                 portfolio_id: str,
                 start: str,
                 end: str,
                 cash_id: Optional[str] = 'CASH',
                 **kwargs) -> 'AttributionConfig':
        """Factory method for KR stock attribution config."""
        universe = UniverseConfig(name='kr_stock', cash_id=cash_id)
        dates = DateConfig(start=start, end=end)
        sector_data_id = "content.spglobal.db.stock.krx-spot-gics.1d"

        return cls(
            universe=universe,
            dates=dates,
            benchmark_id=benchmark_id,
            portfolio_id=portfolio_id,
            sector_data_id=sector_data_id,
            **kwargs
        )
