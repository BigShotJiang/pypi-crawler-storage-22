import pandas as pd
import polars as pl
from datetime import datetime
from typing import Optional
from concurrent.futures import ThreadPoolExecutor
import time

from finter.data import ModelData, ContentFactory, IdTable
from .config import AttributionConfig


class DataLoader:
    """
    Handles loading and processing of holdings, TRI, and sector data
    for attribution analysis.
    """

    def __init__(self, config: AttributionConfig, verbose: bool = False):
        self.config = config
        self.verbose = verbose
        self._cf: Optional[ContentFactory] = None
        self._trading_days: Optional[list] = None
        self._next_date_map: Optional[dict] = None
        self._backtest_days: Optional[list] = None
        self._stock_id_table: Optional[pd.DataFrame] = None

    @property
    def cf(self) -> ContentFactory:
        """Lazy-loaded ContentFactory."""
        if self._cf is None:
            self._cf = ContentFactory(
                self.config.universe.name,
                start=self.config.dates.preload_start,
                end=self.config.dates.preload_end
            )
        return self._cf

    @property
    def trading_days(self) -> list:
        """Trading days from ContentFactory."""
        if self._trading_days is None:
            self._trading_days = self.cf.trading_days
        return self._trading_days

    @property
    def next_date_map(self) -> dict:
        """Mapping of date to next trading date."""
        if self._next_date_map is None:
            self._next_date_map = {
                d: n for d, n in zip(self.trading_days[:-1], self.trading_days[1:])
            }
        return self._next_date_map

    @property
    def backtest_days(self) -> list:
        """Backtest days within start/end range."""
        if self._backtest_days is None:
            start_dt = datetime.strptime(self.config.dates.start, '%Y%m%d')
            end_dt = datetime.strptime(self.config.dates.end, '%Y%m%d')
            self._backtest_days = [
                d for d in self.trading_days
                if start_dt <= d <= end_dt
            ]
        return self._backtest_days

    @property
    def stock_id_table(self) -> pd.DataFrame:
        """Stock ID table for the universe."""
        if self._stock_id_table is None:
            if self.config.universe.name == 'us_stock':
                df = IdTable('spglobal-usa').get_stock()
                df['gvkeyiid'] = df['gvkey'] + df['iid']
            elif self.config.universe.name == 'kr_stock':
                df = IdTable('quantit').get_stock()
            else:
                raise ValueError(f"Invalid universe: {self.config.universe.name}")
            self._stock_id_table = df
        return self._stock_id_table

    def load_holdings(self, data_id: str, max_weight: Optional[float] = None) -> pd.DataFrame:
        """
        Load and process holdings data.

        Args:
            data_id: Data ID to load
            max_weight: Maximum weight (None for benchmark)

        Returns:
            Processed holdings DataFrame
        """
        cfg = self.config
        ucfg = cfg.universe
        dcfg = cfg.dates

        holdings_pv = ModelData.load(data_id)

        if max_weight is not None:
            max_sum = holdings_pv.sum(axis=1).max()
            assert max_sum <= max_weight * 1.2, \
                f"Sum of weights ({max_sum}) exceeds {max_weight * 1.2}"

        # Reindex to backtest days
        holdings_pv = holdings_pv.reindex(self.backtest_days)

        # Add cash column
        if max_weight is not None and ucfg.cash_id is not None:
            holdings_pv[ucfg.cash_id] = max_weight - holdings_pv.fillna(0.0).sum(axis=1)

        # Reshape to long format
        holdings = holdings_pv.copy()
        holdings.index.name = ucfg.date_col
        holdings = holdings.reset_index().melt(
            id_vars=[ucfg.date_col],
            var_name=ucfg.id_col,
            value_name=ucfg.weight_col
        )

        # Sort by date and weight
        holdings = holdings.sort_values(
            by=[ucfg.date_col, ucfg.weight_col, ucfg.id_col],
            ascending=[True, False, True]
        )

        # Add entity column for US stocks
        if ucfg.name == 'us_stock':
            holdings['gvkey'] = holdings['gvkeyiid'].str[:6]

        # Normalize weights
        if cfg.normalize_weights:
            tol = 1e-6
            holdings = holdings[holdings[ucfg.weight_col] > tol]
            holdings[ucfg.weight_col] = holdings.groupby(ucfg.date_col)[ucfg.weight_col].transform(
                lambda x: x / x.sum()
            )

        # Add cumulative weight and holdings count
        holdings['cum_' + ucfg.weight_col] = holdings.groupby(ucfg.date_col)[ucfg.weight_col].cumsum()
        holdings['num_holdings'] = holdings.groupby(ucfg.date_col)[ucfg.id_col].transform('nunique')

        # Apply cumulative threshold if specified
        if cfg.cum_threshold is not None:
            assert 0.0 < cfg.cum_threshold <= 1.0
            bypass_threshold = 50
            mask = (
                ((holdings['cum_' + ucfg.weight_col] <= cfg.cum_threshold) &
                 (holdings['num_holdings'] > bypass_threshold)) |
                (holdings['num_holdings'] <= bypass_threshold)
            )
            holdings = holdings[mask]
            holdings[ucfg.weight_col] = holdings.groupby(ucfg.date_col)[ucfg.weight_col].transform(
                lambda x: x / x.sum()
            )

        return holdings.reset_index(drop=True)

    def add_next_date(self, df: pd.DataFrame) -> pd.DataFrame:
        """Add next trading date column to DataFrame."""
        ucfg = self.config.universe
        df[ucfg.next_date_col] = df[ucfg.date_col].map(self.next_date_map)
        return df

    def load_tri_data(self, selected_ids: list, use_own_cf: bool = False) -> pd.DataFrame:
        """
        Load TRI (Total Return Index) data.

        Args:
            selected_ids: List of security IDs to load
            use_own_cf: If True, create a new ContentFactory (for parallel loading)

        Returns:
            TRI DataFrame in long format
        """
        cfg = self.config
        ucfg = cfg.universe
        dcfg = cfg.dates

        # Use separate ContentFactory for parallel loading
        t0 = time.time()
        if use_own_cf:
            cf = ContentFactory(ucfg.name, start=dcfg.preload_start, end=dcfg.preload_end)
        else:
            cf = self.cf
        if self.verbose:
            print(f"  [TRI] ContentFactory: {time.time() - t0:.2f}s")

        t1 = time.time()
        df_pv = cf.get_df(
            'price_close',
            adj=True,
            adj_div=True,
            quantit_universe=False,
            fill_nan=False
        )
        if self.verbose:
            print(f"  [TRI] cf.get_df: {time.time() - t1:.2f}s (shape: {df_pv.shape})")

        # Select only required IDs
        t2 = time.time()
        if selected_ids is not None:
            cols = df_pv.columns.intersection(selected_ids)
            df_pv = df_pv[cols]
        if self.verbose:
            print(f"  [TRI] Select IDs: {time.time() - t2:.2f}s (shape: {df_pv.shape})")

        # Drop all-NA columns and forward fill
        t3 = time.time()
        df_pv = df_pv.dropna(axis=1, how='all')
        df_pv = df_pv.ffill(limit_area='inside').ffill(limit_area='outside', limit=3)
        if self.verbose:
            print(f"  [TRI] dropna+ffill: {time.time() - t3:.2f}s")

        # Add constant TRI for cash
        if ucfg.cash_id is not None:
            df_pv[ucfg.cash_id] = 100.0

        # Reshape to long format
        df = df_pv.copy()
        df.index.name = ucfg.date_col
        df = df.reset_index().melt(
            id_vars=[ucfg.date_col],
            var_name=ucfg.id_col,
            value_name=ucfg.tri_col
        )
        df = df.dropna(subset=[ucfg.tri_col])
        df = df.sort_values(
            by=[ucfg.date_col, ucfg.tri_col],
            ascending=[True, False]
        ).reset_index(drop=True)

        return df

    def load_sector_data(self, selected_ids: list, use_own_cf: bool = False) -> pd.DataFrame:
        """
        Load sector (GICS) data.

        Args:
            selected_ids: List of entity IDs to load
            use_own_cf: If True, create a new ContentFactory (for parallel loading)

        Returns:
            Sector DataFrame with sector and industry_group columns
        """
        cfg = self.config
        ucfg = cfg.universe
        dcfg = cfg.dates

        # Get GICS data
        if ucfg.name == 'us_stock':
            data_key = 'gics'
        elif ucfg.name == 'kr_stock':
            data_key = 'krx-spot-gics'
        else:
            raise ValueError(f"Invalid universe: {ucfg.name}")

        # Use separate ContentFactory for parallel loading
        if use_own_cf:
            cf = ContentFactory(ucfg.name, start=dcfg.preload_start, end=dcfg.preload_end)
        else:
            cf = self.cf

        df_pv = cf.get_df(data_key, quantit_universe=False, fill_nan=False)

        # Select only required IDs
        if selected_ids is not None:
            df_pv = df_pv[selected_ids]

        # Forward fill
        df_pv = df_pv.ffill(limit_area='inside').ffill(limit_area='outside', limit=3)

        # Reshape to long format
        df = df_pv.copy()
        df.index.name = ucfg.date_col
        df = df.reset_index().melt(
            id_vars=[ucfg.date_col],
            var_name=ucfg.entity_col,
            value_name=ucfg.gics_col
        )
        df = df.dropna(subset=[ucfg.gics_col])

        # Add CASH rows
        if ucfg.cash_id is not None:
            unique_dates = df[ucfg.date_col].unique()
            cash_rows = pd.DataFrame({
                ucfg.date_col: unique_dates,
                ucfg.entity_col: ucfg.cash_id,
                ucfg.gics_col: ucfg.cash_id
            })
            df = pd.concat([df, cash_rows], ignore_index=True)

        df = df.sort_values(
            by=[ucfg.date_col, ucfg.entity_col],
            ascending=[True, False]
        ).reset_index(drop=True)

        # Process GICS codes
        cash_mask = df[ucfg.gics_col] == ucfg.cash_id

        def is_numeric_string(val):
            try:
                float(val)
                return True
            except (ValueError, TypeError):
                return False

        numeric_mask = df[ucfg.gics_col].apply(is_numeric_string)
        valid_numeric_mask = ~cash_mask & numeric_mask

        df.loc[valid_numeric_mask, ucfg.gics_col] = (
            df.loc[valid_numeric_mask, ucfg.gics_col].astype(int).astype(str)
        )

        # Filter to valid GICS codes (length 8) or CASH
        valid_mask = cash_mask | (df[ucfg.gics_col].str.len() == 8)
        df = df[valid_mask].reset_index(drop=True)

        # Recalculate cash_mask after filtering
        cash_mask = df[ucfg.gics_col] == ucfg.cash_id

        # Set sector and industry_group
        df.loc[~cash_mask, 'sector'] = df.loc[~cash_mask, ucfg.gics_col].str[:2]
        df.loc[~cash_mask, 'industry_group'] = df.loc[~cash_mask, ucfg.gics_col].str[:4]
        df.loc[cash_mask, 'sector'] = ucfg.cash_id
        df.loc[cash_mask, 'industry_group'] = ucfg.cash_id

        return df

    def load_holdings_parallel(self) -> tuple:
        """
        Load benchmark and portfolio holdings in parallel using ThreadPoolExecutor.

        Returns:
            Tuple of (bm_holdings, port_holdings)
        """
        cfg = self.config
        verbose = self.verbose
        t_start = time.time()

        def load_bm_with_timing():
            t0 = time.time()
            result = self.load_holdings(cfg.benchmark_id, None)
            if verbose:
                print(f"[BM] load_holdings: {time.time() - t0:.2f}s")
            return result

        def load_port_with_timing():
            t0 = time.time()
            result = self.load_holdings(cfg.portfolio_id, cfg.max_weight)
            if verbose:
                print(f"[Port] load_holdings: {time.time() - t0:.2f}s")
            return result

        with ThreadPoolExecutor(max_workers=2) as executor:
            bm_future = executor.submit(load_bm_with_timing)
            port_future = executor.submit(load_port_with_timing)

            bm_holdings = bm_future.result(timeout=600)
            port_holdings = port_future.result(timeout=600)

        if verbose:
            print(f"[Total] load_holdings_parallel: {time.time() - t_start:.2f}s")
        return bm_holdings, port_holdings

    def load_data_parallel(self, selected_sec_ids: list, selected_entity_ids: list) -> tuple:
        """
        Load TRI and sector data in parallel.

        Each thread creates its own ContentFactory to avoid contention.

        Args:
            selected_sec_ids: List of security IDs for TRI
            selected_entity_ids: List of entity IDs for sector

        Returns:
            Tuple of (df_tri, df_sector)
        """
        verbose = self.verbose
        t_start = time.time()

        def load_tri_with_timing():
            t0 = time.time()
            result = self.load_tri_data(selected_sec_ids, use_own_cf=True)
            if verbose:
                print(f"[TRI] load_tri_data: {time.time() - t0:.2f}s")
            return result

        def load_sector_with_timing():
            t0 = time.time()
            result = self.load_sector_data(selected_entity_ids, use_own_cf=True)
            if verbose:
                print(f"[Sector] load_sector_data: {time.time() - t0:.2f}s")
            return result

        with ThreadPoolExecutor(max_workers=2) as executor:
            tri_future = executor.submit(load_tri_with_timing)
            sector_future = executor.submit(load_sector_with_timing)

            df_tri = tri_future.result(timeout=600)
            df_sector = sector_future.result(timeout=600)

        if verbose:
            print(f"[Total] load_data_parallel: {time.time() - t_start:.2f}s")
        return df_tri, df_sector

    def to_polars(self, df: pd.DataFrame) -> pl.DataFrame:
        """Convert pandas DataFrame to polars."""
        return pl.from_pandas(df)

    def incorporate_stock_info(self, df: pd.DataFrame, selected_cols: list = None) -> pd.DataFrame:
        """
        Merge stock information into DataFrame.

        Args:
            df: DataFrame to add stock info
            selected_cols: Columns to select from stock ID table

        Returns:
            DataFrame with stock info merged
        """
        ucfg = self.config.universe
        id_col = ucfg.id_col

        if ucfg.name == 'us_stock':
            if selected_cols is None:
                selected_cols = ['conml', 'tic']
        elif ucfg.name == 'kr_stock':
            if selected_cols is None:
                selected_cols = ['entity_name', 'short_code']

        merge_cols = [id_col] + selected_cols
        df = df.merge(
            self.stock_id_table[merge_cols],
            on=id_col,
            how='left'
        )
        return df

    def incorporate_sector_info(self, df: pd.DataFrame, sector_col: str = 'sector') -> pd.DataFrame:
        """
        Add GICS sector names to DataFrame based on sector codes.

        Args:
            df: DataFrame with sector codes
            sector_col: Column name containing sector codes (default: 'sector')

        Returns:
            DataFrame with 'sector_name' column added
        """
        # GICS Sector code to name mapping
        gics_sector_map = {
            '10': 'Energy',
            '15': 'Materials',
            '20': 'Industrials',
            '25': 'Consumer Discretionary',
            '30': 'Consumer Staples',
            '35': 'Health Care',
            '40': 'Financials',
            '45': 'Information Technology',
            '50': 'Communication Services',
            '55': 'Utilities',
            '60': 'Real Estate',
        }

        # Handle cash
        cash_id = self.config.universe.cash_id
        if cash_id is not None:
            gics_sector_map[cash_id] = cash_id

        df['sector_name'] = df[sector_col].map(gics_sector_map)
        return df
