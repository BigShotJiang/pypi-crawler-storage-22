"""
KRX Derivatives Constants.

Defines asset types, product classifications, and utility functions
for identifying derivative products.
"""

from enum import Enum
from typing import Set, Literal


class AssetType(Enum):
    """
    KRX asset type classification.

    Futures products use codes 21-101 (odd numbers for outright, even for spreads).

    Example:
        >>> from finter.utils.krx.derivatives import AssetType
        >>> AssetType.KOSPI200_FUTURE.value
        21
    """
    # Equities
    COMMON_STOCK = 1
    TYPE_STOCK = 2  # 종류주
    ETF = 11
    ETN = 12
    ELW = 13

    # Index Futures
    KOSPI200_FUTURE = 21
    KOSPI200_FUTURE_SPREAD = 22
    MINI_KOSPI200_FUTURE = 31
    MINI_KOSPI200_FUTURE_SPREAD = 32
    KOSDAQ150_FUTURE = 41
    KOSDAQ150_FUTURE_SPREAD = 42

    # Stock Futures
    STOCK_FUTURE = 51
    STOCK_FUTURE_SPREAD = 52

    # Interest Rate Futures
    INTEREST_RATE_FUTURE = 61
    INTEREST_RATE_FUTURE_SPREAD = 62

    # Currency Futures
    CURRENCY_FUTURE = 71
    CURRENCY_FUTURE_SPREAD = 72
    CURRENCY_CNH_FUTURE = 81
    CURRENCY_CNH_FUTURE_SPREAD = 82

    # Commodity Futures
    LEAN_HOG_FUTURE = 91
    LEAN_HOG_FUTURE_SPREAD = 92
    GOLD_FUTURE = 101
    GOLD_FUTURE_SPREAD = 102

    # Special
    NOT_SUPPORTED = 1000
    UNKNOWN = 1001


# Asset type groupings
EQUITIES: Set[AssetType] = {
    AssetType.COMMON_STOCK,
    AssetType.TYPE_STOCK,
    AssetType.ETF,
    AssetType.ETN,
    AssetType.ELW,
}

FUTURES: Set[AssetType] = {
    AssetType.KOSPI200_FUTURE,
    AssetType.MINI_KOSPI200_FUTURE,
    AssetType.KOSDAQ150_FUTURE,
    AssetType.STOCK_FUTURE,
    AssetType.INTEREST_RATE_FUTURE,
    AssetType.CURRENCY_FUTURE,
    AssetType.CURRENCY_CNH_FUTURE,
    AssetType.LEAN_HOG_FUTURE,
    AssetType.GOLD_FUTURE,
}

SPREADS: Set[AssetType] = {
    AssetType.KOSPI200_FUTURE_SPREAD,
    AssetType.MINI_KOSPI200_FUTURE_SPREAD,
    AssetType.KOSDAQ150_FUTURE_SPREAD,
    AssetType.STOCK_FUTURE_SPREAD,
    AssetType.INTEREST_RATE_FUTURE_SPREAD,
    AssetType.CURRENCY_FUTURE_SPREAD,
    AssetType.CURRENCY_CNH_FUTURE_SPREAD,
    AssetType.LEAN_HOG_FUTURE_SPREAD,
    AssetType.GOLD_FUTURE_SPREAD,
}

INDEX_FUTURES: Set[AssetType] = {
    AssetType.KOSPI200_FUTURE,
    AssetType.KOSPI200_FUTURE_SPREAD,
    AssetType.MINI_KOSPI200_FUTURE,
    AssetType.MINI_KOSPI200_FUTURE_SPREAD,
    AssetType.KOSDAQ150_FUTURE,
    AssetType.KOSDAQ150_FUTURE_SPREAD,
}

# Product code to asset type mapping
# Code is ISIN[4:6] - the 2-digit product identifier
_FUTURE_CODE_MAP: dict[str, AssetType] = {
    # Index Futures
    "01": AssetType.KOSPI200_FUTURE,
    "05": AssetType.MINI_KOSPI200_FUTURE,  # V-KOSPI200 also uses 05
    "06": AssetType.KOSDAQ150_FUTURE,
    "08": AssetType.KOSPI200_FUTURE,       # KRX300 Futures (mapped to KOSPI200 for now)
    # Interest Rate Futures
    "65": AssetType.INTEREST_RATE_FUTURE,  # 3년 국채
    "66": AssetType.INTEREST_RATE_FUTURE,  # 5년 국채
    "67": AssetType.INTEREST_RATE_FUTURE,  # 10년 국채
    "70": AssetType.INTEREST_RATE_FUTURE,  # 금리선물 (신규)
    # Currency Futures
    "75": AssetType.CURRENCY_FUTURE,       # USD/KRW
    "76": AssetType.CURRENCY_FUTURE,       # EUR/KRW
    "77": AssetType.CURRENCY_FUTURE,       # JPY/KRW
    "78": AssetType.CURRENCY_CNH_FUTURE,   # CNH/KRW (위안화)
    # Commodity Futures (86, 88 and A0-AH)
    "86": AssetType.LEAN_HOG_FUTURE,
    "88": AssetType.GOLD_FUTURE,
}

# Commodity futures use codes starting with 'A' (A0-AH: gold, lean hog variants)
_COMMODITY_FUTURE_PREFIXES = {"A"}


def _is_commodity_future(code: str) -> bool:
    """Check if code is a commodity future (A0-AH range)."""
    return code[0] in _COMMODITY_FUTURE_PREFIXES

_SPREAD_CODE_MAP: dict[str, AssetType] = {
    # Index Futures Spreads
    "01": AssetType.KOSPI200_FUTURE_SPREAD,
    "05": AssetType.MINI_KOSPI200_FUTURE_SPREAD,
    "06": AssetType.KOSDAQ150_FUTURE_SPREAD,
    "08": AssetType.KOSPI200_FUTURE_SPREAD,   # KRX300 Spread
    # Interest Rate Futures Spreads
    "65": AssetType.INTEREST_RATE_FUTURE_SPREAD,
    "66": AssetType.INTEREST_RATE_FUTURE_SPREAD,
    "67": AssetType.INTEREST_RATE_FUTURE_SPREAD,
    "70": AssetType.INTEREST_RATE_FUTURE_SPREAD,
    # Currency Futures Spreads
    "75": AssetType.CURRENCY_FUTURE_SPREAD,
    "76": AssetType.CURRENCY_FUTURE_SPREAD,
    "77": AssetType.CURRENCY_FUTURE_SPREAD,
    "78": AssetType.CURRENCY_CNH_FUTURE_SPREAD,
    # Commodity Futures Spreads
    "86": AssetType.LEAN_HOG_FUTURE_SPREAD,
    "88": AssetType.GOLD_FUTURE_SPREAD,
}


def get_future_asset_type(code: str) -> AssetType:
    """
    Get asset type from 2-digit product code.

    Product codes can be:
    - Index futures: "01" (KOSPI200), "05" (Mini/V-KOSPI200), "06" (KOSDAQ150), "08" (KRX300)
    - Interest rate: "65", "66", "67", "70"
    - Currency: "75", "76", "77", "78"
    - Commodity: "86", "88", "A0"-"AH"
    - Stock futures: Everything else (alphanumeric codes like "11", "0A", "B5", "G7", etc.)

    Args:
        code: 2-digit product code (e.g., "01" for KOSPI200, "05" for Mini KOSPI200)

    Returns:
        AssetType enum value

    Example:
        >>> get_future_asset_type("01")
        <AssetType.KOSPI200_FUTURE: 21>
        >>> get_future_asset_type("11")  # Stock future (Samsung)
        <AssetType.STOCK_FUTURE: 51>
        >>> get_future_asset_type("G7")  # Stock future (alphanumeric code)
        <AssetType.STOCK_FUTURE: 51>
    """
    if code in _FUTURE_CODE_MAP:
        return _FUTURE_CODE_MAP[code]

    # Commodity futures use codes starting with 'A' (A0-AH)
    if _is_commodity_future(code):
        return AssetType.GOLD_FUTURE  # Map all A* codes to commodity futures

    # All other codes are stock futures
    # This includes: 0A-0Z, 11-57, 1A-1Z, 2A-2H, B0-BZ, C0-CY, D0-DY, E0-EZ, F1-FZ, G0-GZ, H0-HZ, M3, M7, etc.
    return AssetType.STOCK_FUTURE


def get_spread_asset_type(code: str) -> AssetType:
    """
    Get spread asset type from 2-digit product code.

    Args:
        code: 2-digit product code

    Returns:
        AssetType enum value for spread product
    """
    if code in _SPREAD_CODE_MAP:
        return _SPREAD_CODE_MAP[code]

    # Commodity futures spreads use codes starting with 'A' (A0-AH)
    if _is_commodity_future(code):
        return AssetType.GOLD_FUTURE_SPREAD

    # All other codes are stock futures spreads
    return AssetType.STOCK_FUTURE_SPREAD


def get_asset_type(isin: str) -> AssetType:
    """
    Determine asset type from ISIN code.

    KRX ISIN structure:
    - Position 2: Asset class identifier
      - '7': Stock (common, ETF)
      - '4': Derivative (future, option)
      - '9': ELW
      - 'G': ETN
    - Position 3: For derivatives
      - '1' or 'A': Futures
      - '4' or 'D': Spreads
    - Position 4-5: Product code
    - Position 8: For stocks
      - '0': Common stock
      - 'K': Type stock (종류주)

    Args:
        isin: 12-character ISIN code

    Returns:
        AssetType enum value

    Example:
        >>> get_asset_type("KR7005930003")  # Samsung
        <AssetType.COMMON_STOCK: 1>
        >>> get_asset_type("KR4101W20005")  # KOSPI200 Future
        <AssetType.KOSPI200_FUTURE: 21>
    """
    if len(isin) != 12:
        return AssetType.UNKNOWN

    asset_class = isin[2]

    if asset_class == "7":
        # Stock or ETF
        if isin[8] == "0":
            # Could be common stock or ETF - default to common stock
            # (ETF detection requires external data)
            return AssetType.COMMON_STOCK
        elif isin[8] == "K":
            return AssetType.TYPE_STOCK
    elif asset_class == "G":
        return AssetType.ETN
    elif asset_class == "9":
        return AssetType.ELW
    elif asset_class == "4":
        # Derivative
        derivative_type = isin[3]
        code = isin[4:6]

        if derivative_type in ("1", "A"):
            # Futures
            return get_future_asset_type(code)
        elif derivative_type in ("4", "D"):
            # Spreads
            return get_spread_asset_type(code)

    return AssetType.NOT_SUPPORTED


def is_future(isin: str) -> bool:
    """
    Check if ISIN represents a futures or spread contract.

    Args:
        isin: 12-character ISIN code

    Returns:
        True if the ISIN is a futures or spread contract

    Example:
        >>> is_future("KR4101W20005")
        True
        >>> is_future("KR7005930003")
        False
    """
    asset_type = get_asset_type(isin)
    return asset_type in FUTURES or asset_type in SPREADS


def is_derivative(isin: str) -> bool:
    """
    Check if ISIN represents a derivative product.

    Currently identical to is_future, but designed for future extension
    to include options.

    Args:
        isin: 12-character ISIN code

    Returns:
        True if the ISIN is a derivative product
    """
    return is_future(isin)
