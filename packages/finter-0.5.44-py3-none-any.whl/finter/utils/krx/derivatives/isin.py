"""
KRX ISIN Code Generation.

Generates ISIN codes for KRX derivative products according to ISO 6166.

ISIN Structure for KRX Futures:
    KR4 X CC YM NNN P
    └─┬─┘│ └┬┘└┬┘└┬┘│
      │  │  │  │  │ └─ Parity check digit
      │  │  │  │  └─── Serial number (000 for futures)
      │  │  │  └────── Year/Month code
      │  │  └───────── Product code (2 digits)
      │  └──────────── Derivative type (1=future before 2026, A=future from 2026)
      └────────────── Country code + derivative marker

Year codes cycle every 30 years:
    0-9 (2000-2005, 2026-2029), A-W excluding I,O (2006-2025)

Month codes:
    1-9 (Jan-Sep), A (Oct), B (Nov), C (Dec)
"""

from typing import Tuple

from finter.utils.krx.derivatives.expiry import near_expiry, next_expiry


# Year code encoding (30-year cycle)
# Years 2000-2029 use codes: 0,1,2,3,4,5,A,B,C,D,E,F,G,H,J,K,L,M,N,P,Q,R,S,T,V,W,6,7,8,9
_YEAR_CODES = "012345ABCDEFGHJKLMNPQRSTVW6789"


def parity_code(code: str) -> str:
    """
    Calculate ISIN check digit using Luhn algorithm variant.

    The check digit is the final character of an ISIN, computed by:
    1. Converting letters to numbers (A=10, B=11, ..., Z=35)
    2. Applying Luhn algorithm (double alternate digits, sum digits)
    3. Taking (10 - sum % 10) % 10

    Args:
        code: 11-character ISIN prefix (without check digit)

    Returns:
        Single-digit check character

    Example:
        >>> parity_code("KR4A01W2000")
        '5'
    """
    code = code.upper()

    # Convert letters to numbers (A=10, B=11, ..., Z=35)
    digit_string = "".join(
        c if c.isdigit() else str(ord(c) - 55) for c in code
    )

    # Double every second digit from right (starting from rightmost)
    # and join as string for digit summing
    processed = "".join(
        str(2 * int(c)) if i % 2 == 0 else c
        for i, c in enumerate(reversed(digit_string))
    )

    # Sum all individual digits
    total = sum(int(d) for d in processed)

    # Check digit
    return str((10 - total % 10) % 10)


def year_code(year: int) -> str:
    """
    Encode year to single-character code.

    Uses a 30-year cycle starting from 1990:
    - 2000-2005: '0'-'5'
    - 2006-2025: 'A'-'W' (excluding 'I' and 'O')
    - 2026-2029: '6'-'9'

    Args:
        year: 4-digit year (e.g., 2025)

    Returns:
        Single character year code

    Example:
        >>> year_code(2025)
        'W'
        >>> year_code(2026)
        '6'
    """
    # Offset from year 1990 (10 + year gives us 2000 = index 10)
    return _YEAR_CODES[(10 + year) % 30]


def year_code_reverse(code: str) -> int:
    """
    Decode year code to year.

    Args:
        code: Single character year code

    Returns:
        4-digit year

    Example:
        >>> year_code_reverse('W')
        2025
        >>> year_code_reverse('6')
        2026
    """
    # Pre-computed mapping for clarity and efficiency
    _YEAR_CODE_TO_YEAR = {
        "0": 2000, "1": 2001, "2": 2002, "3": 2003, "4": 2004, "5": 2005,
        "A": 2006, "B": 2007, "C": 2008, "D": 2009, "E": 2010,
        "F": 2011, "G": 2012, "H": 2013, "J": 2014, "K": 2015,
        "L": 2016, "M": 2017, "N": 2018, "P": 2019, "Q": 2020,
        "R": 2021, "S": 2022, "T": 2023, "V": 2024, "W": 2025,
        "6": 2026, "7": 2027, "8": 2028, "9": 2029,
    }
    return _YEAR_CODE_TO_YEAR[code.upper()]


def month_code(month: int) -> str:
    """
    Encode month to single character.

    January-September use '1'-'9', October-December use 'A'-'C'.

    Args:
        month: Month number (1-12)

    Returns:
        Single character month code

    Example:
        >>> month_code(10)
        'A'
        >>> month_code(3)
        '3'
    """
    _MONTH_CODES = "123456789ABC"
    return _MONTH_CODES[month - 1]


def month_code_reverse(code: str) -> int:
    """
    Decode month code to month number.

    Args:
        code: Single character month code

    Returns:
        Month number (1-12)

    Example:
        >>> month_code_reverse('A')
        10
    """
    # Hex conversion works: '1'-'9' -> 1-9, 'A'-'C' -> 10-12
    return int(code, 16)


def expire_code(expiry_yyyymm: int) -> str:
    """
    Generate 2-character year/month code from YYYYMM.

    Args:
        expiry_yyyymm: Expiry month in YYYYMM format (e.g., 202503)

    Returns:
        2-character code (year + month)

    Example:
        >>> expire_code(202503)
        'W3'
        >>> expire_code(202612)
        '6C'
    """
    year = expiry_yyyymm // 100
    month = expiry_yyyymm % 100
    return year_code(year) + month_code(month)


def future_near(code: str, date_yyyymmdd: int) -> str:
    """
    Generate ISIN for near-month futures contract.

    Args:
        code: 2-digit product code (e.g., "01" for KOSPI200, "11" for stock future)
        date_yyyymmdd: Reference date in YYYYMMDD format

    Returns:
        12-character ISIN code

    Example:
        >>> future_near("01", 20250120)  # KOSPI200 near month
        'KR4A01W30005'
        >>> future_near("11", 20250120)  # Stock future (e.g., Samsung)
        'KR4A1120005X'
    """
    expiry_yyyymmdd = near_expiry(code, date_yyyymmdd)
    if expiry_yyyymmdd is None:
        raise ValueError(f"Unsupported product code: {code}")

    year = expiry_yyyymmdd // 10000

    # Prefix changes from KR41 to KR4A starting 2026
    prefix = "KR4A" if year >= 2026 else "KR41"

    isin_prefix = prefix + code + expire_code(expiry_yyyymmdd // 100) + "000"
    return isin_prefix + parity_code(isin_prefix)


def future_next(code: str, date_yyyymmdd: int) -> str:
    """
    Generate ISIN for next-month futures contract.

    Args:
        code: 2-digit product code
        date_yyyymmdd: Reference date in YYYYMMDD format

    Returns:
        12-character ISIN code

    Example:
        >>> future_next("01", 20250120)  # KOSPI200 next month
        'KR4A0162000X'  # June expiry
    """
    expiry_yyyymmdd = next_expiry(code, date_yyyymmdd)
    if expiry_yyyymmdd is None:
        raise ValueError(f"Unsupported product code: {code}")

    year = expiry_yyyymmdd // 10000
    prefix = "KR4A" if year >= 2026 else "KR41"

    isin_prefix = prefix + code + expire_code(expiry_yyyymmdd // 100) + "000"
    return isin_prefix + parity_code(isin_prefix)


def future_spread(code: str, date_yyyymmdd: int) -> str:
    """
    Generate ISIN for futures calendar spread.

    A spread is a simultaneous long/short position between near and next month.
    The ISIN encodes both expiry months.

    Args:
        code: 2-digit product code
        date_yyyymmdd: Reference date in YYYYMMDD format

    Returns:
        12-character ISIN code

    Example:
        >>> future_spread("01", 20250120)  # KOSPI200 spread
        'KR4D01W362S5'  # March/June spread
    """
    expiry_near = near_expiry(code, date_yyyymmdd)
    expiry_next = next_expiry(code, date_yyyymmdd)

    if expiry_near is None or expiry_next is None:
        raise ValueError(f"Unsupported product code: {code}")

    year = expiry_near // 10000

    # Spread prefix changes from KR44 to KR4D starting 2026
    prefix = "KR4D" if year >= 2026 else "KR44"

    # Spread ISIN: near expiry code + next expiry code + "S"
    isin_prefix = (
        prefix
        + code
        + expire_code(expiry_near // 100)
        + expire_code(expiry_next // 100)
        + "S"
    )
    return isin_prefix + parity_code(isin_prefix)
