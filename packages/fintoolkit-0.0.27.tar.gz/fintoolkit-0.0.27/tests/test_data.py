import unittest
import numpy as np
import pandas as pd
import pandas.testing as pdt
import toolkit as ftk


class TestData(unittest.TestCase):

    def test_yahoo(self):
        self.assertAlmostEqual(ftk.get_yahoo('^SPX')['2025-12-31'], 6845.50, 2)
        pdt.assert_series_equal(ftk.get_yahoo_bulk(['AAPL', 'MSFT']).loc['2025-12-31', :],
                                pd.Series([271.86, 483.62],
                                          index=['AAPL', 'MSFT']),
                                check_names=False)

    def test_famafrench(self):
        ds = ftk.get_famafrench_datasets()
        self.assertEqual(len(ds), 25)
        # Asia_Pacific_ex_Japan_3_Factors
        pdt.assert_series_equal(ftk.get_famafrench_factors(ds[0]).loc['2025-12'],
                                pd.Series([1.28, 2.56, 0.24, 0.34], index=[
                                          'Mkt-RF', 'SMB', 'HML', 'RF']) / 100,
                                check_names=False)

    def test_msci(self):
        p = ftk.get_msci([892400], ror=False)
        r = ftk.get_msci([892400], ror=True)
        # MSCI ACWI Index Price USD
        self.assertAlmostEqual(p.loc['2025-12-31'].iloc[0], 1014.62, 2)
        self.assertAlmostEqual(
            np.expm1(np.log1p(r.loc['2025']).sum()).iloc[0], 0.2060, 4)

    def test_us_yield_curve(self):
        yield_us = ftk.get_us_yield_curve(
            2025, n=1).groupby(pd.Grouper(freq='ME')).last()
        self.assertAlmostEqual(yield_us.loc['2025-12-31', '1 Mo'], 3.74, 2)

    def test_ca_yield_curve(self):
        yield_ca = ftk.get_boc_bulk(['V80691342', 'V80691344', 'V80691345', 'V80691346', 'BD.CDN.2YR.DQ.YLD', 'BD.CDN.3YR.DQ.YLD', 'BD.CDN.5YR.DQ.YLD', 'BD.CDN.7YR.DQ.YLD', 'BD.CDN.10YR.DQ.YLD', 'BD.CDN.LONG.DQ.YLD'])\
            .groupby(pd.Grouper(freq='ME')).last()
        self.assertAlmostEqual(
            yield_ca.loc['2025-12-31', 'V80691342'], 2.09, 2)

    def test_us_economic(self):
        bls = ftk.get_bls_bulk()
        # Consumer Price Index for All Urban Consumers (CPI-U)
        self.assertAlmostEqual(
            bls.loc['2025-12', 'CUUR0000SA0'], 324.054, 3)
        # Unemployment Rate
        self.assertAlmostEqual(
            bls.loc['2025-12', 'LNS14000000'], 4.4, 1)

    def test_ca_economic(self):
        stat = ftk.get_statcan_bulk()
        # All-items Consumer Price Index (CPI)
        self.assertAlmostEqual(stat.loc['2025-12', 41690973], 165.0, 1)
        # Unemployment Rate
        self.assertAlmostEqual(stat.loc['2025-12', 2062815], 6.8, 1)
