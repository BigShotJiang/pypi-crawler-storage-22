"""Pull data from various sources

    - Yahoo! Finance
    - Ken French’s Data Library
    - Federal Reserve Economic Data
    - Bank of Canada
    - Statistics Canada
    - MSCI
    - With Intelligence
    - S&P
"""
from functools import wraps
import io
import re
import datetime
import json
import urllib
import zipfile
import requests
import pandas as pd
import yfinance as yf
from bs4 import BeautifulSoup
from curl_cffi import requests as cffi


def _default_date(func):

    @wraps(func)
    def wrapper(**kwargs):
        if 'date' not in kwargs:
            kwargs['date'] = datetime.datetime.today().date()
        return func(**kwargs)

    wrapper.__doc__ = func.__doc__
    return wrapper


@_default_date
def last_business_day(date: datetime.date = None):
    return (date - datetime.timedelta(days=max(0, date.weekday() - 4)))


@_default_date
def end_of_month(date: datetime.date = None, n: int = 0) -> datetime.date:
    """Last day of the month that is `n` months after the specified date.
    Similar to the `EOMONTH` function in Excel.

    Parameters
    ----------
    date : datetime.date, optional
        A date, by default None (i.e. today)
    n : int, optional
        Number of months, by default 0. A positive value yields a month in the future,
        a negative value yields a month in the past.

    Returns
    -------
    datetime.date
        _description_
    """
    year = date.year + (date.month + n) // 12
    month = (date.month + n) % 12 + 1
    return datetime.date(year, month, 1) - datetime.timedelta(days=1)


def end_of_quarter(date: datetime.date = None, n: int = 0) -> datetime.date:
    """Last day of the calendar quarter that is `n` quarters after the specified date.

    Parameters
    ----------
    date : datetime.date, optional
        A date, by default None (i.e. today)
    n : int, optional
        Number of quarters, by default 0. A positive value yields a quarter in the future,
        a negative value yields a quarter in the past.

    Returns
    -------
    datetime.date
        _description_
    """
    return end_of_month(date, 2 - ((date.month - 1) % 3) + 3 * n)


def end_of_year(date: datetime.date = None, n: int = 0) -> datetime.date:
    """Last date of the calendar year that is `n` years after the specified date.

    Parameters
    ----------
    date : datetime.date, optional
        A date, by default None (i.e. today)
    n : int, optional
        Number of years, by default 0. A positive value yields a year in the future,
        a negative value yields a year in the past.

    Returns
    -------
    datetime.date
        _description_
    """
    return end_of_month(date, -date.month + 12 * n + 12)


def get_all_famafrench_datasets() -> list:
    """Get the list of datasets

    Returns:
        list: List of dataset names in str
    """
    req = requests.get(
        "https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/data_library.html")
    soup = BeautifulSoup(req.text, "html.parser")
    links = soup.select("a[href$='_CSV.zip']")
    return sorted(set(
        link["href"].split("/")[-1].replace("_CSV.zip", "")
        for link in links
    ))


def get_famafrench_datasets() -> list:
    """Get the list of datasets related to factor analysis

    Returns:
        list: List of dataset names in str
    """
    pattern = re.compile(r"^\w+_Factors\w*$")
    full = get_all_famafrench_datasets()
    return sorted([x for x in full if pattern.match(x)])


def get_data_famafrench(dataset: str) -> pd.DataFrame:
    url = f"https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/ftp/{dataset}_CSV.zip"
    req = requests.get(url)
    with zipfile.ZipFile(io.BytesIO(req.content)) as z:
        f = [n for n in z.namelist() if n.lower().endswith(".csv")][0]
        raw_text = z.read(f).decode("latin1")

    # CSV may contain multiple tables in the CSV file, descriptions and disclaimers
    blocks = re.split(r"\n\s*\n", raw_text)

    data = None
    count = 0

    for block in blocks:
        block = block.strip()
        try:
            df = pd.read_csv(io.StringIO(block), index_col=0)
            if len(df) > count:
                count = len(df)
                data = df
        except Exception as e:
            pass

    idx = data.index.astype(str)
    if idx.str.len()[0] == 6:
        dt = pd.to_datetime(idx, format="%Y%m")
        df.index = dt.to_period("M")
    elif idx.str.len()[0] == 8:
        dt = pd.to_datetime(idx, format="%Y%m%d")
        df.index = dt.to_period("D")

    return data


def get_famafrench_factors(dataset: str, add_momentum: bool = False) -> pd.DataFrame:
    freq = "B" if "aily" in dataset else "M"
    data = get_data_famafrench(
        dataset).asfreq(freq) / 100
    factors = data.iloc[:, :-1]
    rfr = data.iloc[:, -1]
    if add_momentum:
        # Momentum has less data
        factors = factors.join(
            get_data_famafrench(
                re.sub(r"[35]_Factors", "Mom_Factor", dataset)).asfreq(freq)
            / 100,
            how="inner",
        )
    return factors.join(rfr, how="inner")


def get_funghsieh_factors() -> pd.DataFrame:
    """Hedge Fund Risk Factors

    https://people.duke.edu/%7Edah7/HFRFData.htm

    Returns
    -------
    pd.DataFrame
        S&P
        SC-LC
        10Y
        Cred Spr
        PTFSBD
        PTFSFX
        PTFSCOM
        PTFSIR
        PTFSSTK
    """

    eq = get_yahoo_bulk(['^SP500TR', '^RUTTR'])
    eq = eq.resample('ME').last()
    eq.index = eq.index.to_period('M')
    eq = eq.pct_change()
    eq = eq.rename(columns={'^SP500TR': 'S&P', '^RUTTR': 'SC-LC'})
    eq['SC-LC'] = eq['SC-LC'] - eq['S&P']

    bd = get_fred_bulk(['DGS10', 'DBAA'], start_date='1993-12-31')
    bd = bd.apply(pd.to_numeric, errors="coerce")
    bd['10Y'] = bd['DGS10'].diff() / 100
    bd['Cred Spr'] = (bd['DBAA'] - bd['DGS10']).diff() / 100
    bd = bd.drop(columns=['DGS10', 'DBAA'])
    bd.index = bd.index.to_period('M')
    bd.index.name = 'Date'

    tf = pd.read_excel(
        'https://people.duke.edu/~dah7/DataLibrary/TF-Fac.xls', skiprows=14, header=0)
    tf = tf.set_index('yyyymm')
    tf = tf.iloc[:, :5]
    tf.index = pd.to_datetime(tf.index, format='%Y%m').to_period('M')
    tf.index.name = 'Date'

    return pd.concat([eq, bd, tf], axis=1).dropna()

# Yahoo


def get_yahoo(ticker: str = "^GSPC", period: str = "max") -> pd.Series:
    """Download the historical adjusted closing price of a security with
    ticker `ticker`.

    Args:
        ticker (str): Yahoo! ticker of the security, by default "^GSPC", i.e. S&P 500
    period : str, optional
        Length of track record to download, by default 'max'

    Returns:
        pd.Series: Time series of the prices of the security
    """
    session = cffi.Session(impersonate="chrome")
    t = yf.Ticker(ticker, session=session)
    # Some securities e.g. crypto trades on weekends
    s = t.history(period=period)["Close"]
    s.name = ticker
    return s.asfreq("D")


def get_yahoo_bulk(tickers: list = ["^GSPC"], period: str = "max") -> pd.DataFrame:
    """Download the historical adjusted closing price of multiple securities
    with ticker in the `tickers` list.

    Parameters
    ----------
    tickers : list
        List of Yahoo! tickers
    period : str, optional
        Length of track record to download, by default 'max'

    Returns
    -------
    pd.DataFrame
        Time series of the prices of the securities
    """
    # Columns are already the tickers, note some securities like crypto trades in non-business days
    session = cffi.Session(impersonate="chrome")
    # Fix YFRateLimitError
    yf.Ticker("QQQ", session=session)
    return yf.download(" ".join(tickers), auto_adjust=False, period=period)["Adj Close"].asfreq('D')


def get_msci(
        codes: list = [990100],
        end_date: str = None,
        fx: str = "USD",
        variant: str = "STRD",
        freq: str = "END_OF_MONTH",
        ror: bool = True) -> pd.DataFrame:
    """Download the historical index value of multiple indexes.

    Parameters
    ----------
    codes : list
        List of MSCI index code, by default [990100], i.e. MSCI World
        See https://www.msci.com/our-solutions/indexes/index-resources/index-tools
    end_date : str, optional
        As of date, by default get_last_business_day().strftime("%Y%m%d")
    fx : str, optional
        Currency, by default "USD"
    variant : str, optional
        Index Level ('STRD' for Price, 'NETR' for Net, 'GRTR' for Gross), by default "STRD"
    freq : str, optional
        Data Frequency, by default "END_OF_MONTH"
    ror : bool, optional
        Convert from index value to return, by default True

    Returns
    -------
    pd.DataFrame
        Time series of the index values. Index is DatetimeIndex (freq=None).
    """
    if end_date is None:
        end_date = last_business_day().strftime("%Y%m%d")
    url = f'https://app2.msci.com/products/service/index/indexmaster/downloadLevelData?output=INDEX_LEVELS&currency_symbol={fx}&index_variant={variant}&start_date=19970101&end_date={end_date}&data_frequency={freq}&baseValue=false&index_codes={",".join(map(str, codes))}'
    df = pd.read_excel(url, thousands=',', parse_dates=[
                       0], skiprows=6, skipfooter=19).set_index('Date')
    if ror:
        df = df.sort_index().ffill().pct_change().to_period('M')
    return df


def get_withintelligence(code: int) -> pd.Series:
    """Download the historical returns of selected hedge fund index.

    Returns
    -------
    pd.Series
        Time series of the monthly returns.
    """
    url = 'https://platform.withintelligence.com/hfm/performance/indices/' + \
        str(code)
    soup = BeautifulSoup(requests.get(url).content, 'html.parser')
    res = soup.find('script', attrs={'id': 'script-apollo-state'}).text
    data = json.loads(res[24:-1])
    dom = data['ROOT_QUERY'][[key for key in data['ROOT_QUERY'] if key.startswith(
        'openGetFundIndexMonthlyReturns') and key.find(str(code)) != -1][0]][0]['__ref']
    df = pd.DataFrame(data[dom]['stats'])
    s = df.set_index('date')['performance']
    s.name = data[dom]['name']
    s.index = pd.PeriodIndex(s.index, freq='M')
    return s


def get_withintelligence_bulk(codes: list = [11469]) -> pd.DataFrame:
    """Download the historical returns of selected hedge fund indexes.

    Returns
    -------
    pd.DataFrame
        Time series of the monthly returns.
    """
    return pd.concat([get_withintelligence(code) for code in codes], axis=1)


def get_statcan_bulk(ids: list = [41690973, 2062815], n: int = 25) -> pd.DataFrame:
    """Download the historical data from Statisticas Canada

    Parameters
    ----------
    ids : list
        List of vectors, by default All-items Consumer Price Index (CPI) (41690973), and Unemployment Rate (2062815). Vector number is a 10-digit number without leading "V".
    n : int, optional
        Number of months, by default 24

    Returns
    -------
    pd.DataFrame
        Column names are ids. Index is DatetimeIndex (freq=None).
    """
    url = "https://www150.statcan.gc.ca/t1/wds/rest/getDataFromVectorsAndLatestNPeriods"
    param = [{"vectorId": id, "latestN": n} for id in ids]
    data = requests.post(url, json=param).json()

    d = {s['object']['vectorId']: pd.DataFrame(
        s['object']['vectorDataPoint']) for s in data}
    s = pd.concat(d.values(), keys=d.keys())
    s.index.names = ['vectorId', 'row']
    s.reset_index(inplace=True)
    s['refPer'] = pd.to_datetime(s['refPer']).dt.to_period('M')
    s.set_index(['vectorId', 'refPer'], inplace=True)
    s = s['value'].sort_index()
    return s.unstack(level=0)


def get_fred_data(ids: list, start=None, end=None) -> pd.DataFrame:
    # Start and end should be strings in 'YYYY-MM-DD' format

    ss = []
    url = "https://api.stlouisfed.org/fred/series/observations"
    params = {
        "api_key": "52d595c6d9002e9f2031c8c3a7193564",
        "file_type": "json",
    }
    if start:
        params["observation_start"] = start
    if end:
        params["observation_end"] = end

    for id in ids:
        params["series_id"] = id
        req = requests.get(url, params=params)
        data = req.json()["observations"]

        df = pd.DataFrame(data)
        s = df.set_index("date")["value"]
        s.name = id
        ss.append(s)

    df = pd.concat(ss, axis=1)
    df.index = pd.to_datetime(df.index)
    return df


def get_fred_bulk(ids: list = ["SOFR"], start_date: str = None, end_date: str = None) -> pd.DataFrame:
    """Download the historical Federal Reserve Economic Data (FRED) from Frederal Reserver Bank of St. Louis

    Parameters
    ----------
    ids : list, optional
        List of series Ids, by default ["SOFR"], i.e. Secured Overnight Financing Rate
    start : str, optional
        Start date in YYYY-MM-DD format, by default earliest available
    end : str, optional
        End date in YYYY-MM-DD format, by default latest available

    Returns
    -------
    pd.DataFrame
        Index is DatetimeIndex (freq='ME')
    """
    df = get_fred_data(ids, start_date, end_date)
    return df.groupby(pd.Grouper(freq="ME")).last()


def get_us_yield_curve(year: int = 0, n: int = 2) -> pd.DataFrame:
    """Download the historical Treasury Par Yield Curve Rates

    Parameters
    ----------
    year : int, optional
        Year, by default the current year
    n : int, optional
        Number of years, by default 2

    Returns
    -------
    pd.DataFrame
        Index is DatetimeIndex (freq=None)
    """
    if year == 0:
        year = datetime.datetime.today().year
    data = [requests.get(
        f"https://home.treasury.gov/resource-center/data-chart-center/interest-rates/daily-treasury-rates.csv/{y}/all?type=daily_treasury_yield_curve&_format=csv", verify=False).text for y in range(year, year - n, -1)]
    df = pd.concat([pd.read_csv(io.StringIO(d), index_col=0)
                   for d in data], axis=0)
    df.index = pd.to_datetime(df.index)
    return df.sort_index()


def get_bls_bulk(ids: list = ['CUUR0000SA0', 'LNS14000000'], start_year: int = None, end_year: int = None) -> pd.DataFrame:
    """Download the historical data from US Bureau of Labor Statistics

    Parameters
    ----------
    ids : list, optional
        List of Series Id, by default Consumer Price Index for All Urban Consumers (CPI-U) (CUUR0000SA0) and Unemployment Rate (LNS14000000)
    start_year : int, optional
        Year, by default the current year
    end_year : int, optional
        Year, by default 10 years ago due to the API limit

    Returns
    -------
    pd.DataFrame
        _description_
    """
    url = "https://api.bls.gov/publicAPI/v2/timeseries/data/"
    payload = {
        "seriesid": ids,
        "startyear": start_year if start_year else datetime.datetime.today().year - 9,
        "endyear": end_year if end_year else datetime.datetime.today().year
    }
    data = requests.post(url, json=payload).json()
    d = {s['seriesID']: pd.DataFrame(s['data'])
         for s in data['Results']['series']}
    df = pd.concat(d.values(), keys=d.keys())
    df['month'] = df.apply(lambda x: f"{x['year']}-{x['period'][1:]}", axis=1)
    df.index.names = ['seriesID', 'row']
    df.reset_index(inplace=True)
    df.set_index(['seriesID', 'month'], inplace=True)
    df = df['value'].sort_index()
    return pd.to_numeric(df, errors='coerce').unstack(level=0)


def get_boc_bulk(ids: list = ["V80691342"], start_date: datetime.date = None, end_date: datetime.date = None) -> pd.DataFrame:
    """Download the historical data from Bank of Canada

    Parameters
    ----------
    ids : list
        List of series names, by default ["V80691342"], i.e. 1 month Treasury bill
    start : datetime.date, optional
        Start date, by default end_of_month(n=-25)
    end : datetime.date, optional
        End date, by default end_of_month()

    Returns
    -------
    pd.DataFrame
        _description_
    """
    if start_date is None:
        start_date = end_of_month(n=-25)
    if end_date is None:
        end_date = end_of_month()
    url = f'https://www.bankofcanada.ca/valet/observations/{urllib.parse.quote(",".join(ids))}/csv?start_date={start_date.strftime("%Y-%m-%d")}&end_date={end_date.strftime("%Y-%m-%d")}'
    csv = requests.get(url, verify=False)
    return pd.read_csv(io.StringIO(csv.text.split('"OBSERVATIONS"\r\n')[1]), parse_dates=["date"]).set_index("date").loc[:, ids]


def get_spglobal_bulk(codes: list = [5457755]) -> pd.DataFrame:
    """Download the historical index values from S&P Global

    Parameters
    ----------
    codes : list, optional
        List of index code, by default [5457755]

    Returns
    -------
    pd.DataFrame
        Index is DatetimeIndex (freq='B')
    """
    url = f"https://www.spglobal.com/spdji/en/util/redesign/get-index-comparison-data.dot?compareArray={'&compareArray='.join([str(i) for i in codes])}&periodFlag=tenYearFlag&language_id=1"
    headers = {
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0",
        "x-requested-with": "XMLHttpRequest"
    }
    json = requests.get(url, headers=headers).json()
    names = {str(i["indexId"]): i["indexName"]
             for i in json["performanceComparisonHolder"]["indexPerformanceForComparison"]}
    values = json["levelComparisonHolder"]["indexLevelForComparison"]
    df = pd.DataFrame([j for i in list(names.keys()) for j in values[i]])
    df["date"] = df["effectiveDate"].apply(
        lambda e: datetime.datetime.fromtimestamp(e / 1000))
    df = df.pivot(index="date", columns="indexId",
                  values="indexValue").asfreq("B")
    df.columns = pd.MultiIndex.from_tuples(
        [(i, names[str(i)]) for i in list(df.columns)])
    return df
