#!/usr/bin/env python
"""Setup script for FinTrack package."""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="FinTrack",
    version="1.0.0",
    author="Aron Fredriksson",
    author_email="arofre903@gmail.com",
    description="A Python package for tracking a dynamic portfolio of stocks with daily price monitoring, cash management, and dividend handling",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/arofre/FinTrack",
    project_urls={
        "Bug Tracker": "https://github.com/arofre/FinTrack/issues",
        "Documentation": "https://github.com/arofre/FinTrack#readme",
        "Source Code": "https://github.com/arofre/FinTrack",
    },
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Financial and Insurance Industry",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Office/Business :: Financial :: Investment",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    python_requires=">=3.7",
    install_requires=[
        "pandas>=1.3.0",
        "yfinance>=0.2.0",
    ],
    keywords=[
        "portfolio",
        "stock-tracking",
        "finance",
        "stocks",
        "yfinance",
        "investment",
    ],
    zip_safe=False,
)
