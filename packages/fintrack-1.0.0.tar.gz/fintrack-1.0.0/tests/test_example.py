"""
Example unit tests for Portfolio Tracker package.

This is a basic example. Expand as needed.
"""

import unittest
import tempfile
import datetime
import os
from pathlib import Path

# Note: Once installed via pip, import like this:
# from FinTrack import FinTrack


class TestPortfolioTracker(unittest.TestCase):
    """Test cases for Portfolio Tracker."""

    def setUp(self):
        """Set up test fixtures."""
        self.temp_dir = tempfile.TemporaryDirectory()
        self.temp_path = Path(self.temp_dir.name)
        
        # Create a sample transactions CSV
        self.csv_content = """Date;Ticker;Type;Amount;Price
2023-01-15;AAPL;Buy;10;150.00
2023-02-20;MSFT;Buy;5;250.00
2023-03-10;AAPL;Sell;5;165.00"""
        
        self.csv_file = self.temp_path / "transactions.csv"
        with open(self.csv_file, 'w') as f:
            f.write(self.csv_content)

    def tearDown(self):
        """Clean up test fixtures."""
        self.temp_dir.cleanup()

    def test_portfolio_initialization(self):
        """Test that FinTrack initializes correctly."""
        # This test would fail without the package being installed
        # Uncomment once you have the package set up
        
        # from FinTrack import FinTrack
        # portfolio = FinTrack(
        #     initial_cash=150000,
        #     currency="SEK",
        #     csv_file=str(self.csv_file)
        # )
        # self.assertIsNotNone(portfolio)
        pass

    def test_csv_format(self):
        """Test that CSV is formatted correctly."""
        with open(self.csv_file, 'r') as f:
            content = f.read()
        
        self.assertIn("Date;Ticker;Type;Amount;Price", content)
        self.assertIn("2023-01-15;AAPL;Buy;10;150.00", content)

    def test_temp_directory(self):
        """Test that temporary directory works."""
        self.assertTrue(self.csv_file.exists())
        self.assertTrue(self.csv_file.is_file())


class TestDataStructures(unittest.TestCase):
    """Test data structure and CSV validation."""

    def test_valid_transaction_types(self):
        """Test that only Buy/Sell transactions are valid."""
        valid_types = ['Buy', 'Sell']
        for trans_type in valid_types:
            self.assertIn(trans_type, valid_types)

    def test_date_format(self):
        """Test that date format YYYY-MM-DD is valid."""
        date_str = "2023-01-15"
        parsed_date = datetime.datetime.strptime(date_str, "%Y-%m-%d")
        self.assertEqual(parsed_date.year, 2023)
        self.assertEqual(parsed_date.month, 1)
        self.assertEqual(parsed_date.day, 15)


if __name__ == '__main__':
    unittest.main()
