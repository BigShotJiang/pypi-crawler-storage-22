use anyhow::Result;
use firm_core::client_packets::{FIRMCommandPacket, FIRMLogPacket};
use firm_core::constants::command::{NUMBER_OF_CALIBRATION_OFFSETS, NUMBER_OF_CALIBRATION_SCALE_MATRIX_ELEMENTS};
use firm_core::constants::log_parsing::{FIRMLogPacketType, HEADER_PARSE_DELAY, HEADER_TOTAL_SIZE};
use firm_core::data_parser::SerialParser;
use firm_core::firm_packets::{DeviceConfig, DeviceInfo, DeviceProtocol, FIRMData, FIRMResponse};
use firm_core::framed_packet::Framed;
use firm_core::log_parsing::LogParser;
use serialport::SerialPort;
use std::collections::VecDeque;
use std::fs::File;
use std::io::{self, Read, Write};
use std::sync::Arc;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::mpsc::{Receiver, RecvTimeoutError, Sender, channel};
use std::thread::{self, JoinHandle};
use std::time::{Duration, Instant};

pub mod mock_serial;

/// Interface to the FIRM Client device.
///
/// # Example:
///
///
/// use firm_rust::FIRMClient;
/// use std::{thread, time::Duration};
///
/// fn main() {
///    let mut client = FIRMClient::new("/dev/ttyUSB0", 2_000_000, 0.1);
///    client.start();
///
///    loop {
///         while let Ok(packet) = client.get_packets(Some(Duration::from_millis(100))) {
///             println!("{:#?}", packet);
///         }
///     }
/// }
pub struct FIRMClient {
    packet_receiver: Receiver<FIRMData>,
    response_receiver: Receiver<FIRMResponse>,
    error_receiver: Receiver<String>,
    running: Arc<AtomicBool>,
    join_handle: Option<JoinHandle<Box<dyn SerialPort>>>,
    sender: Sender<FIRMData>,
    response_sender: Sender<FIRMResponse>,
    error_sender: Sender<String>,
    command_sender: Sender<FIRMCommandPacket>,
    command_receiver: Option<Receiver<FIRMCommandPacket>>,
    mock_sender: Sender<FIRMLogPacket>,
    mock_receiver: Option<Receiver<FIRMLogPacket>>,
    port: Option<Box<dyn SerialPort>>,

    response_buffer: VecDeque<FIRMResponse>,

    mock_stream_stop: Arc<AtomicBool>,
    mock_stream_handle: Option<JoinHandle<anyhow::Result<usize>>>,
}

impl FIRMClient {
    /// Creates a new FIRMClient instance connected to the specified serial port.
    ///
    /// # Arguments
    ///
    /// - `port_name` (`&str`) - The name of the serial port to connect to (e.g., "/dev/ttyUSB0").
    /// - `baud_rate` (`u32`) - The baud rate for the serial connection. Commonly 2,000,000 for FIRM devices.
    /// - `timeout` (`f64`) - Read timeout in seconds for the serial port.
    pub fn new(port_name: &str, baud_rate: u32, timeout: f64) -> Result<Self> {
        // Sets up the serial port
        let port: Box<dyn SerialPort> = serialport::new(port_name, baud_rate)
            .timeout(Duration::from_millis((timeout * 1000.0) as u64))
            .open()
            .map_err(io::Error::other)?;

        Ok(Self::new_from_port(port))
    }

    /// Creates a mocked client with a paired mock serial port and device handle.
    pub fn new_mock(timeout: f64) -> (Self, mock_serial::MockDeviceHandle) {
        let (port, device) = mock_serial::MockSerialPort::pair(Duration::from_secs_f64(timeout));
        let client = Self::new_from_port(port);
        (client, device)
    }

    fn new_from_port(port: Box<dyn SerialPort>) -> Self {
        let (sender, receiver) = channel();
        let (response_sender, response_receiver) = channel();
        let (error_sender, error_receiver) = channel();
        let (command_sender, command_receiver) = channel();
        let (mock_sender, mock_receiver) = channel();

        Self {
            packet_receiver: receiver,
            response_receiver,
            error_receiver,
            running: Arc::new(AtomicBool::new(false)),
            join_handle: None,
            sender,
            response_sender,
            error_sender,
            command_sender,
            command_receiver: Some(command_receiver),
            mock_sender,
            mock_receiver: Some(mock_receiver),
            port: Some(port),
            response_buffer: VecDeque::new(),

            mock_stream_stop: Arc::new(AtomicBool::new(false)),
            mock_stream_handle: None,
        }
    }

    /// Starts the background thread to read from the serial port and parse packets.
    pub fn start(&mut self) {
        // Return early if already running
        if self.join_handle.is_some() {
            return;
        }

        // Gets the port or return if not available
        let mut port = match self.port.take() {
            Some(s) => s,
            None => return,
        };

        let command_receiver = match self.command_receiver.take() {
            Some(r) => r,
            None => return,
        };

        let mock_receiver = match self.mock_receiver.take() {
            Some(r) => r,
            None => return,
        };

        self.running.store(true, Ordering::Relaxed);
        // Clone variables for the thread. This way we can move them in, and the original ones
        // are still owned by self.
        let running_clone = self.running.clone();
        let sender = self.sender.clone();
        let response_sender = self.response_sender.clone();
        let error_sender = self.error_sender.clone();

        let handle: JoinHandle<Box<dyn SerialPort>> = thread::spawn(move || {
            let mut parser = SerialParser::new();
            // Buffer for reading from serial port
            let mut buffer: [u8; 1024] = [0; 1024];

            while running_clone.load(Ordering::Relaxed) {
                // Drain pending command packets first and write them to the port.
                while let Ok(cmd) = command_receiver.try_recv() {
                    let cmd_bytes = cmd.to_bytes();
                    // let hex = cmd_bytes
                    //     .iter()
                    //     .map(|b| format!("{:02X}", b))
                    //     .collect::<Vec<_>>()
                    //     .join(" ");
                    // println!("Command packet bytes: {hex}");
                    if let Err(e) = port.write_all(&cmd_bytes) {
                        let _ = error_sender.send(e.to_string());
                        running_clone.store(false, Ordering::Relaxed);
                        return port;
                    }
                }
                let _ = port.flush();

                // Then drain pending mock packets and write them to the port.
                while let Ok(packet) = mock_receiver.try_recv() {
                    let packet_bytes = packet.to_bytes();
                    // let hex = packet_bytes
                    //     .iter()
                    //     .map(|b| format!("{:02X}", b))
                    //     .collect::<Vec<_>>()
                    //     .join(" ");
                    // println!("Mock packet bytes: {hex}");

                    if let Err(e) = port.write_all(&packet_bytes) {
                        let _ = error_sender.send(e.to_string());
                        running_clone.store(false, Ordering::Relaxed);
                        return port;
                    }
                }
                let _ = port.flush();

                // Read bytes from the serial port
                match port.read(&mut buffer) {
                    Ok(bytes_read @ 1..) => {
                        // Feed the read bytes into the parser
                        parser.parse_bytes(&buffer[..bytes_read]);

                        // Reads all available data packets and send them to the main thread
                        while let Some(firm_data_packet) = parser.get_data_packet() {
                            let packet = firm_data_packet.data().clone();
                            if sender.send(packet).is_err() {
                                return port; // Receiver dropped
                            }
                        }

                        // Reads all available response packets and send them to the main thread
                        while let Some(firm_response_packet) = parser.get_response_packet() {
                            let response = firm_response_packet.response().clone();
                            if response_sender.send(response).is_err() {
                                return port; // Receiver dropped
                            }
                        }
                    }
                    Ok(0) => {}
                    // Timeouts might happen; just continue reading
                    Err(e) if e.kind() == std::io::ErrorKind::TimedOut => {}
                    // Other errors should be reported and stop the thread:
                    Err(e) => {
                        let _ = error_sender.send(e.to_string());
                        running_clone.store(false, Ordering::Relaxed);
                        break;
                    }
                }
            }
            port
        });

        self.join_handle = Some(handle);
    }

    /// Stops the background thread and closes the serial port.
    pub fn stop(&mut self) {
        if let Err(e) = self.stop_mock_log_stream(false, true) {
            let _ = self.error_sender.send(e.to_string());
        }

        self.running.store(false, Ordering::Relaxed);
        // todo: explain this properly when I understand it better (it's mostly for restarting)
        if let Some(handle) = self.join_handle.take()
            && let Ok(port) = handle.join()
        {
            self.port = Some(port);
        }

        // The receivers are moved into the background thread on start()
        // This remakes them so the client can be restarted.
        if self.command_receiver.is_none() {
            let (new_sender, new_receiver) = channel();
            self.command_sender = new_sender;
            self.command_receiver = Some(new_receiver);
        }

        if self.mock_receiver.is_none() {
            let (new_sender, new_receiver) = channel();
            self.mock_sender = new_sender;
            self.mock_receiver = Some(new_receiver);
        }
    }

    /// Retrieves all available data packets, optionally blocking until at least one is available.
    ///
    /// # Arguments
    ///
    /// - `timeout` (`Option<Duration>`) - If `Some(duration)`, the method will block for up to `duration` waiting for a packet.
    pub fn get_data_packets(
        &mut self,
        timeout: Option<Duration>,
    ) -> Result<Vec<FIRMData>, RecvTimeoutError> {
        let mut packets = Vec::new();

        // If blocking, wait for at most one packet. The next loop will drain any others.
        if let Some(duration) = timeout {
            packets.push(self.packet_receiver.recv_timeout(duration)?);
        }

        // Drains the rest of the available packets without blocking
        while let Ok(packet) = self.packet_receiver.try_recv() {
            packets.push(packet);
        }
        Ok(packets)
    }

    /// Retrieves all available response packets, optionally blocking until at least one is available.
    ///
    /// # Arguments
    ///
    /// - `timeout` (`Option<Duration>`) - If `Some(duration)`, the method will block for up to `duration` waiting for a response.
    pub fn get_response_packets(
        &mut self,
        timeout: Option<Duration>,
    ) -> Result<Vec<FIRMResponse>, RecvTimeoutError> {
        let mut responses: Vec<FIRMResponse> = self.response_buffer.drain(..).collect();

        // If blocking and we have nothing buffered, wait for one response.
        if responses.is_empty()
            && let Some(duration) = timeout
        {
            responses.push(self.response_receiver.recv_timeout(duration)?);
        }

        while let Ok(res) = self.response_receiver.try_recv() {
            responses.push(res);
        }

        Ok(responses)
    }

    /// Requests device info and waits for the response.
    pub fn get_device_info(&mut self, timeout: Duration) -> Result<Option<DeviceInfo>> {
        self.send_command(FIRMCommandPacket::build_get_device_info_command())?;
        self.wait_for_matching_response(timeout, |res| match res {
            FIRMResponse::GetDeviceInfo(info) => Some(info.clone()),
            _ => None,
        })
    }

    /// Requests device configuration and waits for the response.
    pub fn get_device_config(&mut self, timeout: Duration) -> Result<Option<DeviceConfig>> {
        self.send_command(FIRMCommandPacket::build_get_device_config_command())?;
        self.wait_for_matching_response(timeout, |res| match res {
            FIRMResponse::GetDeviceConfig(cfg) => Some(cfg.clone()),
            _ => None,
        })
    }

    /// Sets device configuration and waits for acknowledgement.
    pub fn set_device_config(
        &mut self,
        name: String,
        frequency: u16,
        protocol: DeviceProtocol,
        timeout: Duration,
    ) -> Result<Option<bool>> {
        let config = DeviceConfig {
            name,
            frequency,
            protocol,
        };
        self.send_command(FIRMCommandPacket::build_set_device_config_command(config))?;
        self.wait_for_matching_response(timeout, |res| match res {
            FIRMResponse::SetDeviceConfig(ok) => Some(*ok),
            _ => None,
        })
    }

    pub fn set_magnetometer_calibration(
        &mut self,
        offsets: [f32; NUMBER_OF_CALIBRATION_OFFSETS],
        scale_matrix: [f32; NUMBER_OF_CALIBRATION_SCALE_MATRIX_ELEMENTS],
        timeout: Duration,
    ) -> Result<Option<bool>> {
        self.send_command(FIRMCommandPacket::build_set_magnetometer_calibration_command(
            offsets,
            scale_matrix,
        ))?;
        self.wait_for_matching_response(timeout, |res| match res {
            FIRMResponse::SetMagnetometerCalibration(ok) => Some(*ok),
            _ => None,
        })
    }

    pub fn set_imu_calibration(
        &mut self,
        offsets: [f32; NUMBER_OF_CALIBRATION_OFFSETS],
        scale_matrix: [f32; NUMBER_OF_CALIBRATION_SCALE_MATRIX_ELEMENTS],
        timeout: Duration,
    ) -> Result<Option<bool>> {
        self.send_command(FIRMCommandPacket::build_set_imu_calibration_command(
            offsets,
            scale_matrix,
        ))?;
        self.wait_for_matching_response(timeout, |res| match res {
            FIRMResponse::SetIMUCalibration(ok) => Some(*ok),
            _ => None,
        })
    }

    /// Starts streaming a `.frm` mock log file on a background thread.
    ///
    /// While the mock stream is running you can continue to call `get_data_packets()` or other
    /// APIs to read/log FIRM's output.
    ///
    /// Use `is_mock_log_streaming()` to check status and `try_join_mock_log_stream()` to
    /// retrieve the sent packet count when finished.
    pub fn start_mock_log_stream(
        &mut self,
        log_path: String,
        start_timeout: Duration,
        realtime: bool,
        speed: f64,
        chunk_size: usize,
        cancel_on_finish: bool,
    ) -> Result<()> {
        if self.is_mock_log_streaming() {
            return Err(anyhow::anyhow!("Mock stream already running"));
        }

        if !self.is_running() {
            self.start();
        }

        // If a previous stream finished but wasn't joined, join it now.
        if self.mock_stream_handle.as_ref().is_some_and(|h| h.is_finished()) {
            let _ = self.stop_mock_log_stream(false, true);
        }

        self.start_mock_mode(start_timeout)?;

        self.mock_stream_stop.store(false, Ordering::Relaxed);
        let stop = self.mock_stream_stop.clone();
        let mock_sender = self.mock_sender.clone();
        let command_sender = self.command_sender.clone();
        let error_sender = self.error_sender.clone();

        let handle = thread::spawn(move || {
            let result = stream_mock_log_file_worker(
                &log_path,
                realtime,
                speed,
                chunk_size,
                &stop,
                &mock_sender,
            );

            if cancel_on_finish {
                // Fire-and-forget: we can't wait for ack from this background thread.
                let _ = command_sender.send(FIRMCommandPacket::build_cancel_command());
            }

            if let Err(ref e) = result {
                let _ = error_sender.send(e.to_string());
            }
            result
        });

        self.mock_stream_handle = Some(handle);
        Ok(())
    }

    /// Returns `true` if a background mock stream is currently running.
    pub fn is_mock_log_streaming(&self) -> bool {
        self.mock_stream_handle
            .as_ref()
            .is_some_and(|h| !h.is_finished())
    }

    pub fn stop_mock_log_stream(&mut self, cancel_device: bool, block: bool) -> Result<Option<usize>> {
        self.mock_stream_stop.store(true, Ordering::Relaxed);

        if cancel_device {
            let _ = self.command_sender.send(FIRMCommandPacket::build_cancel_command());
        }

        if !block {
            // non-blocking: only join if already finished
            let Some(h) = self.mock_stream_handle.as_ref() else { return Ok(None); };
            if !h.is_finished() { return Ok(None); }
        }

        let Some(handle) = self.mock_stream_handle.take() else {
            return Ok(None);
        };

        let res = handle
            .join()
            .map_err(|_| anyhow::anyhow!("Mock stream thread panicked"))??;

        Ok(Some(res))
    }
    
    /// Sends a cancel command and waits for acknowledgement.
    pub fn cancel(&mut self, timeout: Duration) -> Result<Option<bool>> {
        self.send_command(FIRMCommandPacket::build_cancel_command())?;
        self.wait_for_matching_response(timeout, |res| match res {
            FIRMResponse::Cancel(ok) => Some(*ok),
            _ => None,
        })
    }

    /// Sends a reboot command.
    pub fn reboot(&self) -> Result<()> {
        self.send_command(FIRMCommandPacket::build_reboot_command())
    }

    /// Checks for any errors that have occurred in the background thread.
    ///
    /// # Returns
    ///
    /// - `Option<String>` - `Some(error_message)` if an error has occurred, otherwise `None`.
    pub fn check_error(&self) -> Option<String> {
        self.error_receiver.try_recv().ok()
    }

    /// Returns true if the client is currently running and reading data.
    pub fn is_running(&self) -> bool {
        self.running.load(Ordering::Relaxed)
    }

    /// Enter mock mode and require an acknowledgement.
    ///
    /// Returns `Ok(())` only if the device explicitly acknowledges mock mode.
    fn start_mock_mode(&mut self, timeout: Duration) -> Result<()> {
        self.send_command(FIRMCommandPacket::build_mock_command())?;

        match self.wait_for_matching_response(timeout, |res| match res {
            FIRMResponse::Mock(ok) => Some(*ok),
            _ => None,
        })? {
            Some(true) => Ok(()),
            Some(false) => Err(anyhow::anyhow!("Device rejected mock mode")),
            None => Err(anyhow::anyhow!("Timed out waiting for mock acknowledgement")),
        }
    }

    /// Sends a high-level command to the device.
    fn send_command(&self, command: FIRMCommandPacket) -> Result<()> {
        self.command_sender
            .send(command)
            .map_err(|_| io::Error::other("Command channel closed"))?;
        Ok(())
    }

    fn wait_for_response(&mut self, timeout: Duration) -> Result<Option<FIRMResponse>> {
        // Prefer already-buffered responses.
        if let Some(res) = self.response_buffer.pop_front() {
            return Ok(Some(res));
        }

        match self.response_receiver.recv_timeout(timeout) {
            Ok(res) => Ok(Some(res)),
            Err(RecvTimeoutError::Timeout) => Ok(None),
            Err(RecvTimeoutError::Disconnected) => {
                Err(io::Error::other("Response channel closed").into())
            }
        }
    }

    /// Wait for a response matching `matcher` up to `timeout`.
    ///
    /// Looks through buffered responses first and keeps non-matching responses. It makes sure
    /// that the total time spent waiting is less than `timeout`.
    fn wait_for_matching_response<T>(
        &mut self,
        timeout: Duration,
        mut matcher: impl FnMut(&FIRMResponse) -> Option<T>,
    ) -> Result<Option<T>> {
        // Pull any immediately-available responses into our buffer so we can search them first.
        while let Ok(res) = self.response_receiver.try_recv() {
            self.response_buffer.push_back(res);
        }

        let mut try_get_response = |response_buffer: &mut VecDeque<FIRMResponse>| {
            // First, search the buffer for a match without blocking.
            if let Some((idx, value)) = response_buffer
                .iter()
                .enumerate()
                .find_map(|(idx, res)| matcher(res).map(|value| (idx, value)))
            {
                // Remove the matched response from the buffer and return it.
                response_buffer.remove(idx);
                Some(value)
            } else {
                None
            }
        };

        if let Some(result) = try_get_response(&mut self.response_buffer) {
            return Ok(Some(result));
        }

        // Makes a deadline to enforce the overall timeout
        let deadline = std::time::Instant::now() + timeout;

        loop {
            // If we've already passed the deadline, give up and return None.
            let now = std::time::Instant::now();
            if now >= deadline {
                return Ok(None);
            }

            let remaining = deadline - now;

            // If the receiver was disconnected, propagate the error.
            let Some(next) = self.wait_for_response(remaining)? else {
                // No response arrived before the remaining time elapsed.
                return Ok(None);
            };

            // Keep the response in the buffer so non-matching responses are kept for other calls
            self.response_buffer.push_back(next);

            // Re-scan the buffer for a match now that we have new data.
            if let Some(result) = try_get_response(&mut self.response_buffer) {
                return Ok(Some(result));
            }
        }
    }
}

fn sleep_interruptible(total: Duration, stop: &AtomicBool) {
    let step = Duration::from_millis(10);
    let mut remaining = total;
    while remaining > Duration::ZERO && !stop.load(Ordering::Relaxed) {
        let s = remaining.min(step);
        thread::sleep(s);
        remaining = remaining.saturating_sub(s);
    }
}

fn stream_mock_log_file_worker(
    log_path: &str,
    realtime: bool,
    speed: f64,
    chunk_size: usize,
    stop: &AtomicBool,
    mock_sender: &Sender<FIRMLogPacket>,
) -> Result<usize> {
    if speed <= 0.0 {
        return Err(anyhow::anyhow!("speed must be > 0"));
    }

    let mut file = File::open(log_path)?;
    let mut header = vec![0u8; HEADER_TOTAL_SIZE];
    file.read_exact(&mut header)?;

    // Send the log header to the device, framed as a mock packet.
    let header_packet = FIRMLogPacket::new(FIRMLogPacketType::HeaderPacket, header.clone());
    mock_sender
        .send(header_packet)
        .map_err(|_| io::Error::other("Mock channel closed"))?;

    // After we send the header we pause for a short time to let the device process it.
    sleep_interruptible(HEADER_PARSE_DELAY, stop);

    let mut parser = LogParser::new();
    parser.read_header(&header);

    let mut buf = vec![0u8; chunk_size];
    let mut packets_sent = 0usize;
    let stream_start = Instant::now();
    let mut total_delay_seconds = 0.0f64;

    loop {
        if stop.load(Ordering::Relaxed) {
            break;
        }

        let n = file.read(&mut buf)?;
        if n == 0 {
            break;
        }

        parser.parse_bytes(&buf[..n]);

        while let Some((packet, delay_seconds)) = parser.get_packet_and_time_delay() {
            if stop.load(Ordering::Relaxed) {
                break;
            }

            total_delay_seconds += delay_seconds;

            mock_sender
                .send(packet)
                .map_err(|_| io::Error::other("Mock channel closed"))?;
            packets_sent += 1;

            if realtime && delay_seconds > 0.0 {
                let stream_elapsed = stream_start.elapsed().as_secs_f64();
                // Only sleep if we're not already behind.
                if stream_elapsed <= total_delay_seconds / speed {
                    sleep_interruptible(Duration::from_secs_f64(delay_seconds / speed), stop);
                }
            }
        }

        if parser.eof_reached() {
            break;
        }
    }

    // Drain any remaining packets buffered by the parser.
    while !stop.load(Ordering::Relaxed) {
        let Some((packet, delay_seconds)) = parser.get_packet_and_time_delay() else {
            break;
        };

        total_delay_seconds += delay_seconds;
        mock_sender
            .send(packet)
            .map_err(|_| io::Error::other("Mock channel closed"))?;
        packets_sent += 1;

        if realtime && delay_seconds > 0.0 {
            let stream_elapsed = stream_start.elapsed().as_secs_f64();
            if stream_elapsed <= total_delay_seconds / speed {
                sleep_interruptible(Duration::from_secs_f64(delay_seconds / speed), stop);
            }
        }
    }

    Ok(packets_sent)
}

/// Ensures that the client is properly stopped when dropped, i.e. .stop() is called.
impl Drop for FIRMClient {
    fn drop(&mut self) {
        self.stop();
    }
}

#[cfg(test)]
mod tests {
    use firm_core::{
        constants::{
            command::{
                DEVICE_ID_LENGTH, DEVICE_NAME_LENGTH, FIRMCommand, FIRMWARE_VERSION_LENGTH,
                FREQUENCY_LENGTH,
            },
            packet::PacketHeader,
        },
        firm_packets::FIRMResponsePacket,
        framed_packet::FramedPacket,
    };

    use super::*;

    fn str_to_bytes<const N: usize>(string: &str) -> [u8; N] {
        let mut out = [0u8; N];
        let bytes = string.as_bytes();
        let n = bytes.len().min(N);
        out[..n].copy_from_slice(&bytes[..n]);
        out
    }

    #[test]
    fn test_new_failure() {
        // Test that creating a client with an invalid port fails immediately
        let result = FIRMClient::new("invalid_port_name", 2_000_000, 0.1);
        assert!(result.is_err());
    }

    #[test]
    fn test_start_stop() {
        let (mut client, _device) = FIRMClient::new_mock(0.01);

        assert!(!client.is_running());
        client.start();
        assert!(client.is_running());
        client.stop();
        assert!(!client.is_running());
    }

    #[test]
    fn test_get_data_packet_over_mock_serial() {
        let (mut client, device) = FIRMClient::new_mock(0.01);
        client.start();

        let timestamp_seconds = 1.5f64;

        let mut payload = vec![0u8; 120];
        payload[0..8].copy_from_slice(&timestamp_seconds.to_le_bytes());
        payload[8..12].copy_from_slice(&25.0f32.to_le_bytes());

        let mocked_packet = FramedPacket::new(PacketHeader::Data, 0, payload);
        device.inject_framed_packet(mocked_packet);

        // Need to give some time for the background thread to read the data
        let packets = client
            .get_data_packets(Some(Duration::from_millis(100)))
            .unwrap();
        assert!(!packets.is_empty());
        assert!((packets[0].timestamp_seconds - timestamp_seconds).abs() < 1e-9);
    }

    #[test]
    fn test_get_response_packet_over_mock_serial() {
        let (mut client, device) = FIRMClient::new_mock(0.01);
        client.start();

        let payload = [1u8];

        let bytes = FramedPacket::new(
            PacketHeader::Response,
            FIRMCommand::SetDeviceConfig.to_u16(),
            payload.to_vec(),
        )
        .to_bytes();
        let response_packet = FIRMResponsePacket::from_bytes(&bytes).unwrap();

        device.inject_framed_packet(response_packet.frame().clone());

        let packet = client
            .get_response_packets(Some(Duration::from_millis(100)))
            .unwrap();

        // Make sure we didn't get any other type of packets
        assert!(matches!(
            client.get_data_packets(Some(Duration::from_millis(10))),
            Err(RecvTimeoutError::Timeout)
        ));

        // Make sure we got the expected response
        assert_eq!(packet.len(), payload.len());
        assert_eq!(packet[0], FIRMResponse::SetDeviceConfig(true));

        // Make sure we didn't get any extra response packets
        assert!(matches!(
            client.get_response_packets(Some(Duration::from_millis(10))),
            Err(RecvTimeoutError::Timeout)
        ));
    }

    #[test]
    fn test_set_device_config_command() {
        let (mut client, device) = FIRMClient::new_mock(0.01);
        client.start();

        // Prepare the response packet to be injected
        let response_payload = [1u8]; // Acknowledgement byte
        let response_packet = FramedPacket::new(
            PacketHeader::Response,
            FIRMCommand::SetDeviceConfig.to_u16(),
            response_payload.to_vec(),
        );
        device.inject_framed_packet(response_packet);

        // Send the set device config command
        let result = client.set_device_config(
            "TestDevice".to_string(),
            100,
            DeviceProtocol::UART,
            Duration::from_millis(100),
        );

        // Verify the result
        assert_eq!(result.unwrap(), Some(true));
    }

    #[test]
    fn test_get_device_info_command() {
        let (mut client, device) = FIRMClient::new_mock(0.01);
        client.start();

        let id = 0x1122334455667788u64;
        let mut payload = vec![0u8; DEVICE_ID_LENGTH + FIRMWARE_VERSION_LENGTH];
        payload[0..DEVICE_ID_LENGTH].copy_from_slice(&id.to_le_bytes());
        let fw_bytes = str_to_bytes::<FIRMWARE_VERSION_LENGTH>("v1.2.3");
        payload[DEVICE_ID_LENGTH..DEVICE_ID_LENGTH + FIRMWARE_VERSION_LENGTH]
            .copy_from_slice(&fw_bytes);

        let response_packet = FramedPacket::new(
            PacketHeader::Response,
            FIRMCommand::GetDeviceInfo.to_u16(),
            payload,
        );
        device.inject_framed_packet(response_packet);

        let result = client.get_device_info(Duration::from_millis(100));

        assert_eq!(
            result.unwrap(),
            Some(DeviceInfo {
                firmware_version: "v1.2.3".to_string(),
                id,
            })
        );
    }

    #[test]
    fn test_get_device_config_command() {
        let (mut client, device) = FIRMClient::new_mock(0.01);
        client.start();

        let name = "TestDevice";
        let frequency: u16 = 100;
        let protocol = DeviceProtocol::UART;

        let mut payload = vec![0u8; DEVICE_NAME_LENGTH + FREQUENCY_LENGTH + 1];
        let name_bytes = str_to_bytes::<DEVICE_NAME_LENGTH>(name);
        payload[0..DEVICE_NAME_LENGTH].copy_from_slice(&name_bytes);
        payload[DEVICE_NAME_LENGTH..DEVICE_NAME_LENGTH + FREQUENCY_LENGTH]
            .copy_from_slice(&frequency.to_le_bytes());
        payload[DEVICE_NAME_LENGTH + FREQUENCY_LENGTH] = 2;

        let response_packet = FramedPacket::new(
            PacketHeader::Response,
            FIRMCommand::GetDeviceConfig.to_u16(),
            payload,
        );
        device.inject_framed_packet(response_packet);

        let result = client.get_device_config(Duration::from_millis(100));

        assert_eq!(
            result.unwrap(),
            Some(DeviceConfig {
                name: name.to_string(),
                frequency,
                protocol,
            })
        );
    }

    #[test]
    fn test_cancel_command() {
        let (mut client, device) = FIRMClient::new_mock(0.01);
        client.start();

        let response_payload = [1u8];
        let response_packet = FramedPacket::new(
            PacketHeader::Response,
            FIRMCommand::Cancel.to_u16(),
            response_payload.to_vec(),
        );
        device.inject_framed_packet(response_packet);

        let result = client.cancel(Duration::from_millis(100));

        assert_eq!(result.unwrap(), Some(true));
    }
}
