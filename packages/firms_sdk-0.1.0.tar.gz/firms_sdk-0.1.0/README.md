# FIRMS SDK

Basic SDK Client to retrive hotspots data from FIRMS API.
The client requires the MAP_KEY from NASA and the region of interest to be instanciated.

```py
from firms_sdk import FIRMSClient

MAP_KEY = "******************************c7"
REGION = "-75.2736908751,10.2543646415,-74.7146900698,11.1024970837"
client = FIRMSClient(MAP_KEY, REGION)
```
