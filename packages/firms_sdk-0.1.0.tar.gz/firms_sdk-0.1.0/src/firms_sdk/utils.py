from datetime import datetime, timedelta
from typing import Literal
import numpy as np
from pandas import DataFrame, StringDtype

SensorType = Literal[
    "MODIS_NRT",
    "MODIS_SP",
    "VIIRS_NOAA20_NRT",
    "VIIRS_NOAA20_SP",
    "VIIRS_NOAA21_NRT",
    "VIIRS_SNPP_NRT",
    "VIIRS_SNPP_SP",
    "all",
]


def format_table(df: DataFrame) -> DataFrame:
    """Format FIRMS table for all available options.

    Args:
        df (DataFrame): base dataframe.

    Returns:
        (DataFrame): dataframe processed.
    """
    type_map = {
        "latitude": np.dtype("float64"),
        "longitude": np.dtype("float64"),
        "datetime": np.dtype("datetime64[us]"),
        "scan": np.dtype("float64"),
        "track": np.dtype("float64"),
        "satellite": StringDtype(),
        "instrument": StringDtype(),
        "type": np.dtype("int64"),
        "version": np.dtype("float64"),
        "confidence": StringDtype(),
        "brightness": np.dtype("float64"),
        "bright_t31": np.dtype("float64"),
        "bright_ti4": np.dtype("float64"),
        "bright_ti5": np.dtype("float64"),
    }
    for key, value in type_map.items():
        try:
            df[key] = df[key].astype(value)
        except KeyError:
            df[key] = None
            df[key] = df[key].astype(value)
    return df[type_map.keys()]


def datetime_and_ranges_in_year(year: int) -> list[tuple[datetime, int]]:
    """Get datetime and day_ranges pairs list for the specified year.

    Args:
        year (int): year of interest.

    Returns:
        list[tuple[datetime, int]]: list of datetime-day_range pairs.
    """
    first_date = datetime(year, 1, 1)
    final_date = datetime(year, 12, 31)
    dates = [(first_date, 5)]
    while True:
        current_date = dates[len(dates) - 1][0]
        current_day_range = dates[len(dates) - 1][1]
        if current_date + timedelta(days=current_day_range) >= final_date:
            break
        next_date = current_date + timedelta(days=current_day_range)
        to_final_date = final_date - next_date
        if to_final_date.days > 5:
            dates.append((next_date, 5))
        else:
            dates.append((next_date, to_final_date.days))
    return dates
