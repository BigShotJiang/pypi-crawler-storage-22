from datetime import datetime
from urllib.error import HTTPError, URLError

from pandas import DataFrame, Series, concat, read_csv
from requests import get
from requests.exceptions import RequestException

from firms_sdk.utils import SensorType, format_table, datetime_and_ranges_in_year
from firms_sdk.exceptions import FetchException, check_sensor, check_day_range


class Utils:
    """Utilities for data fetching."""

    def __init__(self):
        self.datetime_and_ranges_in_year = datetime_and_ranges_in_year


class FIRMSClient:
    """FIRMS Client generator to fetch hotspots data from all sensors."""

    def __init__(self, map_key: str, region: str = "world", region_name: str | None = None):
        self.base_url = "https://firms.modaps.eosdis.nasa.gov/"
        self.map_key = map_key
        self.region = region
        self.instance_date = datetime.now()
        self.region_name = region_name
        self.utils = Utils()

    def __str__(self):
        return f"FIRMS Client initiated at {self.instance_date}\
              \nRegion: {self.region_name + " - " if self.region_name else ""}[{self.region}]"

    def __repr__(self):
        return self.__str__()

    @property
    def status(self) -> Series:
        """Fetch MAP KEY status info.

        Raises:
            FetchException: unable to reach server for data.

        Returns:
            Series: transactions limit, transactions done, and refreshing time info
        """
        try:
            response = get(self.base_url + "mapserver/mapkey_status/?MAP_KEY=" + self.map_key, timeout=3600)
            data = response.json()
            s = Series(data)
            s.name = "Status"
            return s
        except RequestException as e:
            raise FetchException(e.args)

    @property
    def data_available(self) -> DataFrame:
        """Available sensors to fetch data.

        Raises:
            FetchException: unable to reach server for data.

        Returns:
            DataFrame: Sensors data.
        """
        try:
            f_url = self.base_url + "api/data_availability/csv/" + self.map_key + "/all"
            return read_csv(f_url)
        except (HTTPError, URLError) as e:
            raise FetchException(e.args)

    def get_data(self, sensor: SensorType, day_range: int, date_init: datetime) -> DataFrame:
        """Fetch hotspots from sensor in the specified date range.

        Args:
            sensor (SensorType): Sensor of interest.
            day_range (int): Number of days in advance to search (between 1-5).
            date_init (datetime): date of interest.

        Raises:
            FetchException: Data not available.

        Returns:
            DataFrame: hotspots dataframe.
        """
        check_day_range(day_range)
        check_sensor(sensor)
        f_url = f"{self.base_url}api/area/csv/{self.map_key}/{sensor}/{self.region}/{day_range}/{date_init.strftime("%Y-%m-%d")}"
        try:
            df = read_csv(f_url, parse_dates=["acq_date"])
            d, hh, mm = df["acq_date"], df["acq_time"] // 100, df["acq_time"] % 100
            dt_vector = [datetime(d.year, d.month, d.day, hour, minute) for d, hour, minute in zip(d, hh, mm)]
            df = df.drop(columns=["acq_date", "acq_time"])
            df["datetime"] = dt_vector
            return format_table(df)
        except (HTTPError, URLError) as e:
            raise FetchException(e.args)

    def get_sp_data(self, day_range: int, date_init: datetime) -> DataFrame:
        """Fetch validate hotspots from FIRMS.

        Args:
            day_range (int): Number of days in advance to search (between 1-5).
            date_init (datetime): date of interest.

        Returns:
            DataFrame: hotspots dataframe.
        """
        sensors: list[SensorType] = ["MODIS_SP", "VIIRS_NOAA20_SP", "VIIRS_SNPP_SP"]
        dfs = [self.get_data(sensor, day_range, date_init) for sensor in sensors]
        return concat(dfs, ignore_index=True)

    def get_nrt_data(self, day_range: int, date_init: datetime) -> DataFrame:
        """Fetch near-real-time hotspots from FIRMS (no validated by NASA).

        Args:
            day_range (int): Number of days in advance to search (between 1-5).
            date_init (datetime): date of interest.

        Returns:
            DataFrame: hotspots dataframe.
        """
        sensors: list[SensorType] = ["MODIS_NRT", "VIIRS_NOAA20_NRT", "VIIRS_NOAA21_NRT", "VIIRS_SNPP_NRT"]
        dfs = [self.get_data(sensor, day_range, date_init) for sensor in sensors]
        return format_table(concat(dfs, ignore_index=True))

    def get_all_data(self, day_range: int, date_init: datetime) -> DataFrame:
        """Fetch near-real-time and validated hotspots data.

        Args:
            day_range (int): Number of days in advance to search (between 1-5).
            date_init (datetime): date of interest.

        Returns:
            DataFrame: hotspots dataframe.
        """
        return format_table(concat([self.get_sp_data(day_range, date_init), self.get_nrt_data(day_range, date_init)], ignore_index=True))
