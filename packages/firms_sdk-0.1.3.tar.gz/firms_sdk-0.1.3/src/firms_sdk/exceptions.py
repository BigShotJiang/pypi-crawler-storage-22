from typing import Any

from firms_sdk.utils import SensorType


class FetchException(Exception):
    """Fetch Exception message."""

    def __init__(self, *args):
        super().__init__(*args)


class SensorException(FetchException):
    """No valid sensor error message."""

    def __init__(self, value: Any):
        message = f"Sensor must be one between: \
            'MODIS_NRT', 'MODIS_SP', 'VIIRS_NOAA20_NRT', 'VIIRS_NOAA20_SP', 'VIIRS_NOAA21_NRT', 'VIIRS_SNPP_NRT', 'VIIRS_SNPP_SP' \
            , not {value}"
        super().__init__(message)


class DayRangeException(FetchException):
    """No valid day range."""

    def __init__(self, value: Any):
        message = f"Day range must be a value between 1 or 5 days in advance, not {value}"
        super().__init__(message)


def check_sensor(sensor: SensorType):
    """Validate sensor input.

    Args:
        sensor (SensorType): sensor to validate.

    Raises:
        TypeError: Sensor is not string.
        SensorException: Sensor is not one of available.
    """
    available_sensors = [
        "MODIS_NRT",
        "MODIS_SP",
        "VIIRS_NOAA20_NRT",
        "VIIRS_NOAA20_SP",
        "VIIRS_NOAA21_NRT",
        "VIIRS_SNPP_NRT",
        "VIIRS_SNPP_SP",
    ]
    if not isinstance(sensor, str):
        raise TypeError(f"Sensor must be string type, not {type(sensor)}")
    if sensor not in available_sensors:
        raise SensorException(sensor)


def check_day_range(day_range: int):
    """Validate day_range input.

    Args:
        day_range (int): day range to validate.

    Raises:
        TypeError: Day range is not int.
        DayRangeException: Day range is not between 1-5 range.
    """
    if not isinstance(day_range, int):
        raise TypeError(f"Day range must be integer, not {type(day_range)}")
    if day_range <= 0 or day_range > 5:
        raise DayRangeException(day_range)
