"""
Different datasources used for fetching data
"""

from .rest import *
from .noren import *