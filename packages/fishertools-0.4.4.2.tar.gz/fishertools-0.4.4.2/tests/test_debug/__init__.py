"""Tests for debug module."""
