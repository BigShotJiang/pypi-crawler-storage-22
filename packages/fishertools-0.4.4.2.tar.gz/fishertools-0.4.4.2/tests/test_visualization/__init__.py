"""Tests for visualization module."""
