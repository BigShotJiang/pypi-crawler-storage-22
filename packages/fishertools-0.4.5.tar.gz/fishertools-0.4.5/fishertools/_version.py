"""Version information for fishertools."""

__version__ = "0.4.5"
