"""Version information for fishertools."""

from __future__ import annotations

__version__ = "0.4.6"
