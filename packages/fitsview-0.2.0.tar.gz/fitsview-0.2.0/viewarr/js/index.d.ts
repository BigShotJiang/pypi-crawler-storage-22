/**
 * TypeScript type definitions for viewarr
 */

/**
 * JavaScript TypedArray type names supported by viewarr.
 */
export type ArrayType =
  | 'Int8Array'
  | 'Uint8Array'
  | 'Int16Array'
  | 'Uint16Array'
  | 'Int32Array'
  | 'Uint32Array'
  | 'BigInt64Array'
  | 'BigUint64Array'
  | 'Float32Array'
  | 'Float64Array';

/**
 * Create a new viewer instance in the specified container.
 *
 * @param containerId - The ID of the HTML element to use as the container.
 *                      This ID is also used to identify the viewer instance.
 * @returns Resolves when the viewer is ready.
 * @throws If the container is not found or initialization fails.
 */
export function createViewer(containerId: string): Promise<void>;

/**
 * Set image data for a viewer.
 *
 * @param containerId - The ID of the container (viewer instance).
 * @param buffer - The raw pixel data.
 * @param width - Image width in pixels.
 * @param height - Image height in pixels.
 * @param arrayType - JavaScript TypedArray type name for interpreting the buffer.
 * @throws If the viewer is not found or data is invalid.
 */
export function setImageData(
  containerId: string,
  buffer: ArrayBuffer,
  width: number,
  height: number,
  arrayType: ArrayType
): void;

/**
 * Destroy a viewer instance and clean up resources.
 *
 * @param containerId - The ID of the container (viewer instance).
 */
export function destroyViewer(containerId: string): void;

/**
 * Check if a viewer exists for a given container.
 *
 * @param containerId - The ID of the container.
 * @returns True if a viewer exists.
 */
export function hasViewer(containerId: string): boolean;

/**
 * Get all active viewer IDs.
 *
 * @returns Array of container IDs with active viewers.
 */
export function getActiveViewers(): string[];

/**
 * Get current contrast value for a viewer.
 *
 * @param containerId - The ID of the container (viewer instance).
 * @returns Contrast value (0.0 to 10.0, default 1.0).
 */
export function getContrast(containerId: string): number;

/**
 * Set contrast value for a viewer.
 *
 * @param containerId - The ID of the container (viewer instance).
 * @param contrast - Contrast value (0.0 to 10.0).
 */
export function setContrast(containerId: string, contrast: number): void;

/**
 * Get current bias value for a viewer.
 *
 * @param containerId - The ID of the container (viewer instance).
 * @returns Bias value (0.0 to 1.0, default 0.5).
 */
export function getBias(containerId: string): number;

/**
 * Set bias value for a viewer.
 *
 * @param containerId - The ID of the container (viewer instance).
 * @param bias - Bias value (0.0 to 1.0).
 */
export function setBias(containerId: string, bias: number): void;

/**
 * Get current stretch mode for a viewer.
 *
 * @param containerId - The ID of the container (viewer instance).
 * @returns Stretch mode: "linear", "log", or "symmetric".
 */
export function getStretchMode(containerId: string): string;

/**
 * Set stretch mode for a viewer.
 *
 * @param containerId - The ID of the container (viewer instance).
 * @param mode - Stretch mode: "linear", "log", or "symmetric".
 */
export function setStretchMode(containerId: string, mode: string): void;

/**
 * Get visible image bounds in pixel coordinates.
 *
 * @param containerId - The ID of the container (viewer instance).
 * @returns Array [xmin, xmax, ymin, ymax] in pixel coordinates.
 */
export function getViewBounds(containerId: string): [number, number, number, number];

/**
 * Set view to show specific image bounds.
 *
 * @param containerId - The ID of the container (viewer instance).
 * @param xmin - Minimum x coordinate in pixels.
 * @param xmax - Maximum x coordinate in pixels.
 * @param ymin - Minimum y coordinate in pixels.
 * @param ymax - Maximum y coordinate in pixels.
 */
export function setViewBounds(
  containerId: string,
  xmin: number,
  xmax: number,
  ymin: number,
  ymax: number
): void;

/**
 * Get the colormap name for a viewer.
 *
 * @param containerId - The ID of the container (viewer instance).
 * @returns Colormap name (e.g., "Gray", "Inferno", "Magma", "RdBu").
 */
export function getColormap(containerId: string): string;

/**
 * Get whether the colormap is reversed.
 *
 * @param containerId - The ID of the container (viewer instance).
 * @returns True if the colormap is reversed.
 */
export function getColormapReversed(containerId: string): boolean;

/**
 * Get the image value range (vmin, vmax).
 *
 * @param containerId - The ID of the container (viewer instance).
 * @returns Array [vmin, vmax].
 */
export function getValueRange(containerId: string): [number, number];

/**
 * Get current rotation angle in degrees (counter-clockwise).
 *
 * @param containerId - The ID of the container (viewer instance).
 * @returns Rotation angle in degrees.
 */
export function getRotation(containerId: string): number;

/**
 * Set rotation angle in degrees (counter-clockwise).
 *
 * @param containerId - The ID of the container (viewer instance).
 * @param degrees - Rotation angle in degrees.
 */
export function setRotation(containerId: string, degrees: number): void;

/**
 * Get pivot point in image coordinates.
 *
 * @param containerId - The ID of the container (viewer instance).
 * @returns Array [x, y] in image coordinates.
 */
export function getPivotPoint(containerId: string): [number, number];

/**
 * Set pivot point in image coordinates.
 *
 * @param containerId - The ID of the container (viewer instance).
 * @param x - X coordinate in image pixels.
 * @param y - Y coordinate in image pixels.
 */
export function setPivotPoint(containerId: string, x: number, y: number): void;

/**
 * Get whether the pivot marker is visible.
 *
 * @param containerId - The ID of the container (viewer instance).
 * @returns True if the pivot marker is visible.
 */
export function getShowPivotMarker(containerId: string): boolean;

/**
 * Set whether to show the pivot marker.
 *
 * @param containerId - The ID of the container (viewer instance).
 * @param show - True to show the pivot marker.
 */
export function setShowPivotMarker(containerId: string, show: boolean): void;

/**
 * State object passed to state change callbacks.
 */
export interface ViewerState {
  contrast: number;
  bias: number;
  stretchMode: string;
  zoom: number;
  colormap: string;
  colormapReversed: boolean;
  vmin: number;
  vmax: number;
  xlim?: [number, number];
  ylim?: [number, number];
  rotation: number;
  pivot: [number, number];
  showPivotMarker: boolean;
}

/**
 * Click event object passed to click callbacks.
 */
export interface ClickEvent {
  x: number;
  y: number;
  value?: number;
}

/**
 * Register a callback to be called when the viewer state changes.
 *
 * The callback receives an object with the current state.
 *
 * @param containerId - The ID of the container (viewer instance).
 * @param callback - Callback function to receive state updates.
 */
export function onStateChange(
  containerId: string,
  callback: (state: ViewerState) => void
): void;

/**
 * Register a callback to be called when the user clicks in the viewer.
 *
 * The callback receives the click coordinates in data space.
 *
 * @param containerId - The ID of the container (viewer instance).
 * @param callback - Callback function to receive click events.
 */
export function onClick(
  containerId: string,
  callback: (event: ClickEvent) => void
): void;

/**
 * Clear all registered callbacks for a viewer.
 *
 * @param containerId - The ID of the container (viewer instance).
 */
export function clearCallbacks(containerId: string): void;

declare const viewarr: {
  createViewer: typeof createViewer;
  setImageData: typeof setImageData;
  destroyViewer: typeof destroyViewer;
  hasViewer: typeof hasViewer;
  getActiveViewers: typeof getActiveViewers;
  getContrast: typeof getContrast;
  setContrast: typeof setContrast;
  getBias: typeof getBias;
  setBias: typeof setBias;
  getStretchMode: typeof getStretchMode;
  setStretchMode: typeof setStretchMode;
  getViewBounds: typeof getViewBounds;
  setViewBounds: typeof setViewBounds;
  getColormap: typeof getColormap;
  getColormapReversed: typeof getColormapReversed;
  getValueRange: typeof getValueRange;
  getRotation: typeof getRotation;
  setRotation: typeof setRotation;
  getPivotPoint: typeof getPivotPoint;
  setPivotPoint: typeof setPivotPoint;
  getShowPivotMarker: typeof getShowPivotMarker;
  setShowPivotMarker: typeof setShowPivotMarker;
  onStateChange: typeof onStateChange;
  onClick: typeof onClick;
  clearCallbacks: typeof clearCallbacks;
};

export default viewarr;
