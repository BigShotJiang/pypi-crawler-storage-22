# -- coding: utf-8 --
# Project: fiuaiclient
# Created Date: 2025 07 We
# Author: liming
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI


V2_GET_LIST_URI = "/document"


ASSISTANT_USER = "assistant@fiuai.com"

DEFAULT_TENANT_ID = "8888888888888888888"
PASSIVE_TENANT_ID = "9999999999999999999"
UNSIGNED_TENANT_ID = "7777777777777777777"


