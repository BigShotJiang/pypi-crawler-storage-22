# FixtureForge 🛠️

Generate realistic dummy data for your tests using AI.
No more hardcoded JSONs or random strings.

## Installation

```bash
pip install fixtureforge