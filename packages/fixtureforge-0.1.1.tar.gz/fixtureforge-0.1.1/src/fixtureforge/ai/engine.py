import os
import time
from typing import Optional
from google import genai


class AIEngine:
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or os.getenv("GOOGLE_API_KEY")
        self.client = None
        
        if not self.api_key:
            return

        try:
            self.client = genai.Client(api_key=self.api_key)
        except Exception as e:
            print(f"⚠️ AI Config Error: {e}")

    def generate_text(self, prompt: str, retries: int = 5) -> str:
        if not self.api_key or not self.client:
            return "[AI Error: Missing API Key]"

        attempt = 0
        while attempt < retries:
            try:
                # הקריאה החדשה והרשמית
                response = self.client.models.generate_content(
                    model='gemini-2.0-flash', 
                    contents=prompt
                )
                return response.text.strip()
            
            except Exception as e:
                error_msg = str(e)
                if "429" in error_msg or "quota" in error_msg.lower() or "503" in error_msg or "400" in error_msg: 
                    wait_time = 10 * (attempt + 1)
                    print(f"⏳ Server busy (Quota). Waiting {wait_time}s... (Attempt {attempt + 1}/{retries})")
                    time.sleep(wait_time)
                    attempt += 1
                else:
                    return f"[AI Error: {error_msg}]"
        
        return "[AI Error: Timeout - Failed after retries]"