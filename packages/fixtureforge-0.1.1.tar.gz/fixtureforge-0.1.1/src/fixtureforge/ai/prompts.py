"""
System Prompts for the AI Engine.
Defines how the AI should behave and format data.
"""

SYSTEM_PROMPT = """
You are FixtureForge, an advanced test data generator.
Your goal is to generate realistic, context-aware synthetic data for developers and QA engineers.

RULES:
1. OUTPUT FORMAT: You must output ONLY valid JSON. No Markdown, no explanations, no code blocks (```json).
2. REALISM: Data must look real (names, addresses, emails). Use the requested locale if specified.
3. CONSISTENCY: If generating multiple fields, they must match (e.g., email should match the name).
4. CONTEXT: Pay attention to the user's specific scenario (e.g., "Angry customer", "Medical patient").
5. ARRAY ONLY: The output must always be a JSON array of objects, even if requesting 1 item.
"""

def build_prompt(model_schema: dict, count: int, context: str = "") -> str:
    """Builds the final prompt for the AI"""
    return f"""
    {SYSTEM_PROMPT}

    REQUEST:
    Generate {count} items based on this schema:
    {model_schema}

    CONTEXT/SCENARIO:
    {context if context else "General realistic data"}

    Remember: Output strictly a JSON list of objects.
    """