"""Basic data generation using Faker & AI"""
from typing import Any, Type, Optional, Dict, List
from faker import Faker
import random
import uuid
from .parser import ModelParser, FieldInfo
from .router import IntelligentRouter, FieldTier
from ..ai.engine import AIEngine 

class BasicGenerator:
    """Generate data using Faker based on Intelligent Routing"""
    
    def __init__(self, locale: str = "en_US", api_key: Optional[str] = None):
        self.faker = Faker(locale)
        self.router = IntelligentRouter()
        self._id_counters = {}
        self.registry: Dict[str, List[Any]] = {} 
        
        if api_key:
            self.ai_engine = AIEngine(api_key)
        else:
            self.ai_engine = None

    def generate(self, model: Type, context: str = None, **overrides) -> Any:
        """Generate a model instance with optional context"""
        parser = ModelParser()
        fields = parser.parse(model)
        
        data = {}
        for field in fields:
            if field.name in overrides:
                data[field.name] = overrides[field.name]
            else:
                data[field.name] = self._generate_smart_value(field, context)
        
        instance = model(**data)
        return instance

    def _generate_smart_value(self, field: FieldInfo, context: str = None) -> Any:
        tier = self.router.classify(field)

        if tier == FieldTier.STRUCTURAL:
            return self._generate_structural(field)
        
        if tier == FieldTier.SEMANTIC:
            return self._generate_semantic_content(field, context)
        
        return self._generate_standard(field)

    def _generate_structural(self, field: FieldInfo) -> Any:
        """Handle IDs and Foreign Keys"""
        name = field.name.lower()

        # 1
        if name.endswith("_id") and name != "id":
            target_model = name.replace("_id", "")
            
            if target_model in self.registry and self.registry[target_model]:
                random_record = random.choice(self.registry[target_model])
                return getattr(random_record, "id")

        # 2
        if "int" in field.type_name.lower():
            if field.name not in self._id_counters:
                self._id_counters[field.name] = 1
            
            val = self._id_counters[field.name]
            self._id_counters[field.name] += 1
            return val
            
        return str(uuid.uuid4())

    def _generate_semantic_content(self, field: FieldInfo, context: str = None) -> str:
        """Generate REAL content using AI with Context"""
        if not self.ai_engine or not self.ai_engine.api_key:
             return f"[AI Placeholder for {field.name}]"
        
        prompt = f"Generate a realistic value for a database field named '{field.name}'."
        
        if context:
            prompt += f" IMPORTANT CONTEXT: {context}."
            
        prompt += " Output ONLY the value, no quotes."
        
        return self.ai_engine.generate_text(prompt)

    def _generate_standard(self, field: FieldInfo) -> Any:
        """Standard Faker generation - Strictly Cleaned for Linter"""
        name = field.name.lower()
        type_name = field.type_name.lower()
        
        # Heuristics - Broken down line by line
        if "email" in name:
            return self.faker.email()
            
        if "name" in name:
            return self.faker.name()
            
        if "address" in name:
            return self.faker.address()
            
        if "phone" in name:
            return self.faker.phone_number()
            
        if "date" in name or "time" in name:
            return self.faker.date_time_this_year()
            
        if "city" in name:
            return self.faker.city()
            
        if "country" in name:
            return self.faker.country()
        
        # Type fallback
        if "int" in type_name:
            return self._generate_int(field)
            
        if "bool" in type_name:
            return self.faker.boolean()
            
        if "float" in type_name:
            return random.uniform(0, 1000)
            
        return self.faker.word()

    def _generate_int(self, field: FieldInfo) -> int:
        min_val, max_val = 0, 10000
        if field.constraints:
            min_val = field.constraints.get("ge", field.constraints.get("gt", -1) + 1)
            max_val = field.constraints.get("le", field.constraints.get("lt", 10001) - 1)
        
        if min_val > max_val:
            max_val = min_val + 100
            
        return random.randint(min_val, max_val)