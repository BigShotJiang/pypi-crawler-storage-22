"""
Model introspection and field extraction (Pydantic Edition)
"""
from typing import Any, Dict, List, Type, get_origin, get_args
from pydantic import BaseModel

# --- SQLAlchemy Support Check ---
try:
    from sqlalchemy import inspect as sa_inspect
    from sqlalchemy.orm import DeclarativeMeta
    HAS_SQLALCHEMY = True
except ImportError:
    HAS_SQLALCHEMY = False
    # SQLA
    DeclarativeMeta = type("DeclarativeMeta", (), {}) 
    sa_inspect = None

class FieldInfo:
    """Information about a model field"""
    
    def __init__(
        self,
        name: str,
        field_type: Type,
        required: bool = True,
        default: Any = None,
        constraints: Dict[str, Any] = None,
        metadata: Dict[str, Any] = None
    ):
        self.name = name
        self.field_type = field_type
        self.required = required
        self.default = default
        self.constraints = constraints or {}
        self.metadata = metadata or {}
    
    @property
    def type_name(self) -> str:
        """Get human-readable type name"""
        try:
            origin = get_origin(self.field_type)
            if origin:
                args = get_args(self.field_type)
                if args:
                    # args
                    args_str = ', '.join(
                        a.__name__ if hasattr(a, '__name__') else str(a) 
                        for a in args
                    )
                    return f"{origin.__name__}[{args_str}]"
                return origin.__name__
            return self.field_type.__name__
        except Exception: 
            return str(self.field_type)

class ModelParser:
    """Parse Pydantic models"""
    
    @classmethod
    def parse(cls, model: Type[BaseModel]) -> List[FieldInfo]:
        """Parse Pydantic V2 model"""
        fields = []
        
        for field_name, field_info in model.model_fields.items():
            # Extract type
            field_type = field_info.annotation
            
            # Check if required
            required = field_info.is_required()
            
            # Get default
            default = field_info.default if not required else None
            
            # Extract constraints 
            constraints = {}
            if field_info.metadata:
                for meta in field_info.metadata:
                    if hasattr(meta, 'ge') and meta.ge is not None:
                        constraints['ge'] = meta.ge
                    if hasattr(meta, 'le') and meta.le is not None:
                        constraints['le'] = meta.le
                    if hasattr(meta, 'gt') and meta.gt is not None:
                        constraints['gt'] = meta.gt
                    if hasattr(meta, 'lt') and meta.lt is not None:
                        constraints['lt'] = meta.lt
                    if hasattr(meta, 'min_length') and meta.min_length is not None:
                        constraints['min_length'] = meta.min_length
                    if hasattr(meta, 'max_length') and meta.max_length is not None:
                        constraints['max_length'] = meta.max_length
                    if hasattr(meta, 'pattern') and meta.pattern is not None:
                        constraints['pattern'] = meta.pattern

            # Extract metadata description
            metadata = {
                "description": field_info.description,
                "examples": field_info.examples if hasattr(field_info, 'examples') else None
            }
            
            fields.append(FieldInfo(
                name=field_name,
                field_type=field_type,
                required=required,
                default=default,
                constraints=constraints,
                metadata=metadata
            ))
        
        return fields