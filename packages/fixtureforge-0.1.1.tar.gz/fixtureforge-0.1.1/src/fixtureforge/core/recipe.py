"""
Recipe Runner: Executes YAML-based data generation scenarios.
"""
import yaml
from typing import Dict, Type
from pydantic import create_model, Field
from fixtureforge import forge

class RecipeRunner:
    """Parses YAML recipes and executes generation steps"""

    def __init__(self, recipe_path: str):
        self.recipe_path = recipe_path
        self.type_mapping = {
            "int": int,
            "str": str,
            "float": float,
            "bool": bool,
            "list": list,
            "dict": dict
        }

    def run(self):
        """Execute the recipe"""
        with open(self.recipe_path, 'r', encoding='utf-8') as f:
            recipe = yaml.safe_load(f)

        print(f"📜 Running Recipe: {self.recipe_path}")
        
        steps = recipe.get("steps", [])
        results = {}

        for step in steps:
            model_name = step["model"]
            count = step.get("count", 1)
            context = step.get("context", None)
            fields_config = step.get("fields", {})

            # 1
            dynamic_model = self._create_dynamic_model(model_name, fields_config)

            print(f"\n🏗️  Step: Creating {count} x {model_name}...")
            if context:
                print(f"   🎬 Context: {context}")

            # 2
            generated_data = forge.create_batch(
                dynamic_model, 
                count=count, 
                context=context
            )
            
            results[model_name] = generated_data
            
            # 3
            self._print_sample(generated_data)

        return results

    def _create_dynamic_model(self, name: str, fields_config: Dict[str, str]) -> Type:
        """Dynamically build a Pydantic model from YAML definitions"""
        pydantic_fields = {}
        
        for field_name, field_type_str in fields_config.items():
 
            py_type = self.type_mapping.get(field_type_str, str)
 
            pydantic_fields[field_name] = (py_type, Field(description=f"Dynamic field {field_name}"))

        return create_model(name, **pydantic_fields)

    def _print_sample(self, data: list):
        """Print a summary of generated data"""
        for item in data[:3]: # Print only first 3 items for brevity
            d = item.model_dump()
            print(f"   ✅ {d}")