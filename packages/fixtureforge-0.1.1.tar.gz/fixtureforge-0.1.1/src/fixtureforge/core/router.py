from enum import Enum, auto 
from .parser import FieldInfo

class FieldTier(Enum):
    STRUCTURAL = auto()  # IDs, PKs
    STANDARD = auto()    # Faker (Name, Email, Dates)
    SEMANTIC = auto()    # AI (Bio, Reviews, Descriptions)

class IntelligentRouter:
    """
    The Brain: Classifies fields into generation tiers based on metadata.
    """

    def classify(self, field: FieldInfo) -> FieldTier:
        name = field.name.lower()
        type_str = field.type_name.lower()
        constraints = field.constraints

        # --- Tier 0: Structural 
        if ("id" == name or "_id" in name) and "valid" not in name and "uuid" not in name:
             return FieldTier.STRUCTURAL
        
        if constraints.get("primary_key"):
            return FieldTier.STRUCTURAL

        standard_keywords = [
            "name", "email", "phone", "address", "city", 
            "country", "date", "time", "url", "link"
        ]
        if any(k in name for k in standard_keywords):
            return FieldTier.STANDARD

        # --- Tier 2: Semantic ---
        semantic_keywords = [
            "description", "bio", "review", "comment", "reason", 
            "message", "content", "summary", "feedback", "about", "story"
        ]
        
        if "str" in type_str:
           
            if any(keyword in name for keyword in semantic_keywords):
                return FieldTier.SEMANTIC
            
            
            max_len = constraints.get("max_length", 1000)
            if max_len > 200:
                return FieldTier.SEMANTIC

        # --- Tier 1: Standard ---
        return FieldTier.STANDARD