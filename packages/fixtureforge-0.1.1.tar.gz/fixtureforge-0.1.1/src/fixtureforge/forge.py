from typing import Type, Any, List, Optional, Generator, TypeVar
import os
from pydantic import BaseModel, create_model
from google import genai
from google.genai import types


from .core.generator import BasicGenerator
from .core.streamer import DataStreamer

__version__ = "0.1.1" 

T = TypeVar("T", bound=BaseModel)

class Forge:
    def __init__(self, api_key: Optional[str] = None, use_ai: bool = True, locale: str = "en_US"):
        self.use_ai = use_ai
     
        self.api_key = api_key or os.getenv("GOOGLE_API_KEY")
        
        self.generator = BasicGenerator(locale=locale, api_key=self.api_key)
        
        if self.api_key:
            self.client = genai.Client(api_key=self.api_key)
        else:
            self.client = None

    def create(self, model: Type, count: int = 1, context: str = None, **overrides) -> Any:
        """Standard creation (Loop). Good for single items or complex relationships."""
        results = []
       
        for i in range(count):
            if count > 1:
                print(f"   ...generating {i+1}/{count}...") 
            item = self.generator.generate(model, context=context, **overrides)
            self._add_to_registry(model, item)
            results.append(item)
        
        return results[0] if count == 1 else results

    def create_batch(self, model: Type[T], count: int, context: str = None, **overrides) -> List[T]:
        """
        🚀 NEW: Smart Batching.
        Generates data in ONE request instead of a loop.
        """
      
        if not self.use_ai or not self.client:
            return self.create(model, count=count, context=context, **overrides)

        print(f"⚡ Smart-Batching {count} items of '{model.__name__}'...", flush=True)

      
        BatchResult = create_model(
            "BatchResult",
            items=(List[model], ...)
        )

       
        prompt = (
            f"Generate exactly {count} realistic items based on this context: '{context}'. "
            f"Ensure diversity."
        )

        try:
          
            response = self.client.models.generate_content(
                model="gemini-2.0-flash",
                contents=prompt,
                config=types.GenerateContentConfig(
                    response_mime_type="application/json",
                    response_schema=BatchResult
                )
            )

            batch_data = response.parsed
            items = []
            
            if batch_data and hasattr(batch_data, 'items'):
                items = batch_data.items
            
            for item in items:
                self._add_to_registry(model, item)

            return items

        except Exception as e:
            print(f"⚠️ Batch Error: {e}. Falling back to slow loop.")
            return self.create(model, count=count, context=context, **overrides)

    def create_stream(self, model: Type, count: int, filename: str, context: str = None, **overrides) -> Generator[Any, None, None]:
        """
        Lazy Evaluation: Generates data and writes immediately to disk.
        (הקוד המקורי שלך נשמר כאן)
        """
        streamer = DataStreamer(filename)
        streamer.start()
        
        print(f"🌊 Starting stream to {filename} ({count} items)...")
        
        for i in range(count):
            item = self.generator.generate(model, context=context, **overrides)
            streamer.write(item)
            self._add_to_registry(model, item)
            yield item

        streamer.close()
        print(f"✅ Stream complete! Data saved to {filename}")

    def _add_to_registry(self, model: Type, item: Any):
        """Helper to register items for relationships"""
        model_name = model.__name__.lower()
        if model_name not in self.generator.registry:
            self.generator.registry[model_name] = []
        self.generator.registry[model_name].append(item)
    
    def stats(self):
        return {k: len(v) for k, v in self.generator.registry.items()}

# Global instance
forge = Forge()
