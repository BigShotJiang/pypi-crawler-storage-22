# SqlAssert

Fluent API for database state assertions in tests.

## Import

```python
from fixturify import sql, SqlAssert, SqlTestConfig
```

## Basic usage

```python
@sql(path="./setup.sql")
def test_user_creation(sql_assert: SqlAssert):
    create_user(name="John", email="john@example.com")

    # Verify user exists
    sql_assert.table("users").where(name="John").exists()
```

## Configuration

`sql_assert` fixture requires `sql_config` fixture returning `SqlTestConfig`:

```python
# conftest.py
import pytest
from fixturify import SqlTestConfig

@pytest.fixture
def sql_config() -> SqlTestConfig:
    return SqlTestConfig(
        driver="psycopg2",
        host="localhost",
        port=5432,
        database="testdb",
        user="postgres",
        password="postgres",
    )
```

The `sql_assert` fixture is automatically available when `sql_config` is defined.

## Existence assertions

### exists()

Assert at least one row matches:

```python
sql_assert.table("users").where(name="John").exists()
```

### not_exists()

Assert no rows match:

```python
sql_assert.table("users").where(name="Deleted").not_exists()
```

## Count assertions

### count(n)

Assert exact row count:

```python
sql_assert.table("users").count(5)
sql_assert.table("users").where(role="admin").count(2)
```

### count_gt(n), count_gte(n), count_lt(n), count_lte(n)

Assert row count comparisons:

```python
sql_assert.table("users").count_gt(0)    # more than 0
sql_assert.table("users").count_gte(1)   # at least 1
sql_assert.table("users").count_lt(100)  # less than 100
sql_assert.table("users").count_lte(10)  # at most 10
```

## Value assertions

### has(**fields)

Assert first matching row has specified values:

```python
sql_assert.table("users").where(id=1).has(
    name="John",
    email="john@example.com",
    role="admin"
)
```

### has_all(**fields)

Assert ALL matching rows have specified values:

```python
sql_assert.table("users").where(role="admin").has_all(is_active=True)
```

### has_any(**fields)

Assert ANY matching row has specified values:

```python
sql_assert.table("users").has_any(email="john@example.com")
```

## Fetching data

### fetch_one()

Fetch first matching row as dict:

```python
row = sql_assert.table("users").where(id=1).fetch_one()
# {'id': 1, 'name': 'John', 'email': 'john@example.com'}

assert row["name"] == "John"
```

### fetch_one(TargetClass)

Fetch and map to object using ObjectMapper:

```python
from dataclasses import dataclass

@dataclass
class User:
    id: int
    name: str
    email: str

user = sql_assert.table("users").where(id=1).fetch_one(User)
assert user.name == "John"
assert isinstance(user, User)
```

Works with dataclasses, Pydantic models, SQLAlchemy models, and plain objects.

### fetch_all()

Fetch all matching rows:

```python
rows = sql_assert.table("users").fetch_all()
# [{'id': 1, 'name': 'John'}, {'id': 2, 'name': 'Jane'}]
```

### fetch_all(TargetClass)

Fetch all and map to objects:

```python
users = sql_assert.table("users").fetch_all(User)
assert all(isinstance(u, User) for u in users)
```

### fetch_value(column)

Fetch single value from first row:

```python
email = sql_assert.table("users").where(id=1).fetch_value("email")
# "john@example.com"
```

## WHERE conditions

### where(**conditions)

Add equality conditions (AND):

```python
sql_assert.table("users").where(name="John", role="admin").exists()
# WHERE name = 'John' AND role = 'admin'
```

### Chaining where()

Multiple `where()` calls are combined with AND:

```python
sql_assert.table("users")\
    .where(role="admin")\
    .where(is_active=True)\
    .exists()
# WHERE role = 'admin' AND is_active = True
```

### where_null(column)

Check for NULL values:

```python
sql_assert.table("users").where_null("deleted_at").count(5)
# WHERE deleted_at IS NULL
```

### where_not_null(column)

Check for NOT NULL values:

```python
sql_assert.table("users").where_not_null("email").exists()
# WHERE email IS NOT NULL
```

## Ordering and limiting

### order_by(column, desc=False)

Order results:

```python
first_user = sql_assert.table("users").order_by("created_at").fetch_one()
latest_user = sql_assert.table("users").order_by("created_at", desc=True).fetch_one()
```

### limit(n)

Limit results:

```python
top_5 = sql_assert.table("users").order_by("score", desc=True).limit(5).fetch_all()
```

## Method chaining

All methods return new instances (immutable), enabling fluent chaining:

```python
sql_assert.table("users")\
    .where(role="admin")\
    .where(is_active=True)\
    .where_not_null("email")\
    .order_by("name")\
    .limit(10)\
    .fetch_all(User)
```

Chaining creates independent queries:

```python
base = sql_assert.table("users")
admins = base.where(role="admin")
active_admins = admins.where(is_active=True)

# Each query is independent
base.count(100)           # all users
admins.count(10)          # only admins
active_admins.count(8)    # only active admins
```

## Raw SQL queries

For complex queries, use `raw()`:

```python
# Custom query with parameters
result = sql_assert.raw(
    "SELECT COUNT(*) as cnt FROM users WHERE created_at > %s",
    ["2024-01-01"]
).fetch_one()
assert result["cnt"] > 0

# Existence check
sql_assert.raw(
    "SELECT 1 FROM users u JOIN orders o ON u.id = o.user_id WHERE o.total > %s",
    [1000]
).exists()

# Non-existence check
sql_assert.raw(
    "SELECT 1 FROM users WHERE email LIKE %s",
    ["%@banned.com"]
).not_exists()
```

## Async support

For async tests, use methods with `a` prefix:

```python
@sql(path="./setup.sql")
async def test_async(sql_assert: SqlAssert):
    await sql_assert.table("users").where(name="John").aexists()
    await sql_assert.table("users").anot_exists()
    await sql_assert.table("users").acount(5)

    user = await sql_assert.table("users").where(id=1).afetch_one(User)
    users = await sql_assert.table("users").afetch_all(User)
```

### Async methods

| Sync | Async |
|------|-------|
| `exists()` | `aexists()` |
| `not_exists()` | `anot_exists()` |
| `count(n)` | `acount(n)` |
| `fetch_one()` | `afetch_one()` |
| `fetch_all()` | `afetch_all()` |

## Relationships (not yet supported)

Automatic relationship loading (one-to-one, one-to-many) is **not yet implemented**.

For now, use manual queries or raw SQL:

### Manual queries

```python
# Fetch user
user = sql_assert.table("users").where(id=1).fetch_one()

# Fetch related profile (one-to-one)
profile = sql_assert.table("profiles").where(user_id=user["id"]).fetch_one()

# Fetch related orders (one-to-many)
orders = sql_assert.table("orders").where(user_id=user["id"]).fetch_all()
```

### Using raw() with JOIN

```python
# One-to-one with JOIN
result = sql_assert.raw("""
    SELECT u.id, u.name, p.bio, p.avatar
    FROM users u
    LEFT JOIN profiles p ON u.id = p.user_id
    WHERE u.id = %s
""", [1]).fetch_one()

# Aggregate with JOIN
result = sql_assert.raw("""
    SELECT u.id, u.name, COUNT(o.id) as order_count, SUM(o.total) as total_spent
    FROM users u
    LEFT JOIN orders o ON u.id = o.user_id
    WHERE u.id = %s
    GROUP BY u.id, u.name
""", [1]).fetch_one()
```

## Supported drivers

Works with all drivers supported by `@sql` decorator:

| Driver | Database | Type |
|--------|----------|------|
| `psycopg2` | PostgreSQL | sync |
| `asyncpg` | PostgreSQL | async |
| `mysql.connector` | MySQL | sync |
| `aiomysql` | MySQL | async |
| `sqlite3` | SQLite | sync |
| `aiosqlite` | SQLite | async |

## Full example

```python
from dataclasses import dataclass
from fixturify import sql, Phase, SqlAssert

@dataclass
class User:
    id: int
    name: str
    email: str
    role: str

@dataclass
class Order:
    id: int
    user_id: int
    total: float
    status: str

@sql(path="./fixtures/setup.sql")
@sql(path="./fixtures/cleanup.sql", phase=Phase.AFTER)
def test_order_processing(sql_assert: SqlAssert):
    # Arrange - verify initial state
    sql_assert.table("orders").where(status="pending").count(1)

    # Act - process the order
    process_pending_orders()

    # Assert - verify order was processed
    sql_assert.table("orders").where(status="pending").not_exists()
    sql_assert.table("orders").where(status="completed").exists()

    # Verify order details
    order = sql_assert.table("orders").where(id=1).fetch_one(Order)
    assert order.status == "completed"

    # Verify user notification was created
    sql_assert.table("notifications")\
        .where(user_id=order.user_id)\
        .where(type="order_completed")\
        .exists()

    # Verify audit log
    sql_assert.table("audit_log")\
        .where(entity="order")\
        .where(entity_id=1)\
        .has(action="status_change", new_value="completed")
```

## Error messages

Clear assertion errors with context:

```
AssertionError: Expected at least 1 row in 'users' where name='John', found 0
```

```
AssertionError: Expected 5 rows in 'orders' where status='pending', found 3
```

```
AssertionError: Row in 'users' doesn't match expected values:
  email: expected 'john@example.com', got 'jane@example.com'
  role: expected 'admin', got 'user'
```
