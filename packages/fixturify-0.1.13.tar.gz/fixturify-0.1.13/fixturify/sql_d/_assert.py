"""SQL assertion helper for database state verification."""

from typing import Any, Dict, List, Optional, Type, TypeVar, Union, TYPE_CHECKING

from fixturify.sql_d._query_executor import SqlQueryExecutor

if TYPE_CHECKING:
    from fixturify.sql_d._config import SqlTestConfig

T = TypeVar("T")


class SqlAssert:
    """
    ORM-agnostic database assertions using raw SQL.

    Provides a fluent API for verifying database state in tests.

    Example:
        @sql(path="./setup.sql")
        def test_user_creation(sql_assert):
            create_user(name="John", email="john@example.com")

            # Verify user exists
            sql_assert.table("users").where(name="John").exists()

            # Verify exact count
            sql_assert.table("users").count(1)

            # Fetch and verify with ObjectMapper
            user = sql_assert.table("users").where(name="John").fetch_one(User)
            assert user.email == "john@example.com"
    """

    def __init__(self, config: "SqlTestConfig"):
        """
        Initialize SqlAssert.

        Args:
            config: Database configuration
        """
        self._config = config
        self._executor = SqlQueryExecutor(config)

    def table(self, name: str) -> "TableAssert":
        """
        Start building assertion for a table.

        Args:
            name: Table name

        Returns:
            TableAssert for fluent chaining
        """
        return TableAssert(name, self._executor)

    def raw(self, sql: str, params: Optional[List[Any]] = None) -> "RawQueryAssert":
        """
        Execute raw SQL query for custom assertions.

        Args:
            sql: SQL query with %s placeholders
            params: Query parameters

        Returns:
            RawQueryAssert for result inspection
        """
        return RawQueryAssert(sql, params or [], self._executor)


class TableAssert:
    """
    Fluent assertion builder for a specific table.

    Supports method chaining for building complex queries.
    """

    def __init__(self, table: str, executor: SqlQueryExecutor):
        """
        Initialize TableAssert.

        Args:
            table: Table name
            executor: Query executor
        """
        self._table = table
        self._executor = executor
        self._conditions: List[tuple] = []
        self._order_by: Optional[str] = None
        self._limit: Optional[int] = None

    def _clone(self) -> "TableAssert":
        """Create a copy of this TableAssert with same state."""
        clone = TableAssert(self._table, self._executor)
        clone._conditions = self._conditions.copy()
        clone._order_by = self._order_by
        clone._limit = self._limit
        return clone

    def where(self, **conditions: Any) -> "TableAssert":
        """
        Add WHERE conditions (AND).

        Args:
            **conditions: Column=value pairs

        Returns:
            New TableAssert with conditions added

        Example:
            sql_assert.table("users").where(name="John", role="admin")
            # WHERE name = 'John' AND role = 'admin'
        """
        clone = self._clone()
        clone._conditions.extend(conditions.items())
        return clone

    def where_null(self, column: str) -> "TableAssert":
        """
        Add WHERE column IS NULL condition.

        Args:
            column: Column name

        Returns:
            New TableAssert with condition added
        """
        clone = self._clone()
        clone._conditions.append((column, None, "IS NULL"))
        return clone

    def where_not_null(self, column: str) -> "TableAssert":
        """
        Add WHERE column IS NOT NULL condition.

        Args:
            column: Column name

        Returns:
            New TableAssert with condition added
        """
        clone = self._clone()
        clone._conditions.append((column, None, "IS NOT NULL"))
        return clone

    def order_by(self, column: str, desc: bool = False) -> "TableAssert":
        """
        Add ORDER BY clause.

        Args:
            column: Column to order by
            desc: Descending order if True

        Returns:
            New TableAssert with order added
        """
        clone = self._clone()
        clone._order_by = f"{column} DESC" if desc else column
        return clone

    def limit(self, n: int) -> "TableAssert":
        """
        Add LIMIT clause.

        Args:
            n: Maximum number of rows

        Returns:
            New TableAssert with limit added
        """
        clone = self._clone()
        clone._limit = n
        return clone

    # ==========================================================================
    # Existence assertions
    # ==========================================================================

    def exists(self) -> None:
        """
        Assert at least one row matches the conditions.

        Raises:
            AssertionError: If no rows match
        """
        count = self._count()
        if count == 0:
            conditions_str = self._format_conditions()
            raise AssertionError(
                f"Expected at least 1 row in '{self._table}'{conditions_str}, found 0"
            )

    def not_exists(self) -> None:
        """
        Assert no rows match the conditions.

        Raises:
            AssertionError: If any rows match
        """
        count = self._count()
        if count > 0:
            conditions_str = self._format_conditions()
            raise AssertionError(
                f"Expected 0 rows in '{self._table}'{conditions_str}, found {count}"
            )

    # ==========================================================================
    # Count assertions
    # ==========================================================================

    def count(self, expected: int) -> None:
        """
        Assert exact row count.

        Args:
            expected: Expected number of rows

        Raises:
            AssertionError: If count doesn't match
        """
        actual = self._count()
        if actual != expected:
            conditions_str = self._format_conditions()
            raise AssertionError(
                f"Expected {expected} rows in '{self._table}'{conditions_str}, found {actual}"
            )

    def count_gt(self, n: int) -> None:
        """
        Assert row count > n.

        Args:
            n: Minimum count (exclusive)

        Raises:
            AssertionError: If count <= n
        """
        actual = self._count()
        if actual <= n:
            conditions_str = self._format_conditions()
            raise AssertionError(
                f"Expected more than {n} rows in '{self._table}'{conditions_str}, found {actual}"
            )

    def count_gte(self, n: int) -> None:
        """
        Assert row count >= n.

        Args:
            n: Minimum count (inclusive)

        Raises:
            AssertionError: If count < n
        """
        actual = self._count()
        if actual < n:
            conditions_str = self._format_conditions()
            raise AssertionError(
                f"Expected at least {n} rows in '{self._table}'{conditions_str}, found {actual}"
            )

    def count_lt(self, n: int) -> None:
        """
        Assert row count < n.

        Args:
            n: Maximum count (exclusive)

        Raises:
            AssertionError: If count >= n
        """
        actual = self._count()
        if actual >= n:
            conditions_str = self._format_conditions()
            raise AssertionError(
                f"Expected less than {n} rows in '{self._table}'{conditions_str}, found {actual}"
            )

    def count_lte(self, n: int) -> None:
        """
        Assert row count <= n.

        Args:
            n: Maximum count (inclusive)

        Raises:
            AssertionError: If count > n
        """
        actual = self._count()
        if actual > n:
            conditions_str = self._format_conditions()
            raise AssertionError(
                f"Expected at most {n} rows in '{self._table}'{conditions_str}, found {actual}"
            )

    # ==========================================================================
    # Value assertions
    # ==========================================================================

    def has(self, **fields: Any) -> None:
        """
        Assert first matching row has specified field values.

        Args:
            **fields: Field=value pairs to verify

        Raises:
            AssertionError: If no rows match or fields don't match
        """
        row = self.fetch_one()
        if row is None:
            conditions_str = self._format_conditions()
            raise AssertionError(
                f"Expected row in '{self._table}'{conditions_str}, found none"
            )

        mismatches = []
        for field, expected in fields.items():
            if field not in row:
                mismatches.append(f"  {field}: column not found")
            elif row[field] != expected:
                mismatches.append(f"  {field}: expected {expected!r}, got {row[field]!r}")

        if mismatches:
            raise AssertionError(
                f"Row in '{self._table}' doesn't match expected values:\n"
                + "\n".join(mismatches)
            )

    def has_all(self, **fields: Any) -> None:
        """
        Assert ALL matching rows have specified field values.

        Args:
            **fields: Field=value pairs that all rows must have

        Raises:
            AssertionError: If any row doesn't match
        """
        rows = self.fetch_all()
        if not rows:
            conditions_str = self._format_conditions()
            raise AssertionError(
                f"Expected rows in '{self._table}'{conditions_str}, found none"
            )

        for i, row in enumerate(rows):
            for field, expected in fields.items():
                if field not in row:
                    raise AssertionError(
                        f"Row {i} in '{self._table}': column '{field}' not found"
                    )
                if row[field] != expected:
                    raise AssertionError(
                        f"Row {i} in '{self._table}': {field} expected {expected!r}, "
                        f"got {row[field]!r}"
                    )

    def has_any(self, **fields: Any) -> None:
        """
        Assert ANY matching row has specified field values.

        Args:
            **fields: Field=value pairs (at least one row must match all)

        Raises:
            AssertionError: If no row matches all fields
        """
        rows = self.fetch_all()
        if not rows:
            conditions_str = self._format_conditions()
            raise AssertionError(
                f"Expected rows in '{self._table}'{conditions_str}, found none"
            )

        for row in rows:
            all_match = True
            for field, expected in fields.items():
                if field not in row or row[field] != expected:
                    all_match = False
                    break
            if all_match:
                return

        raise AssertionError(
            f"No row in '{self._table}' matches all fields: {fields}"
        )

    # ==========================================================================
    # Data fetching
    # ==========================================================================

    def fetch_one(self, target_class: Optional[Type[T]] = None) -> Union[Dict[str, Any], T, None]:
        """
        Fetch first matching row.

        Args:
            target_class: Optional class to map result to (uses ObjectMapper)

        Returns:
            First row as dict or mapped object, None if no results
        """
        sql = self._build_select()
        params = self._get_params()
        row = self._executor.fetch_one(sql, params)

        if row is None or target_class is None:
            return row

        from fixturify.object_mapper import ObjectMapper
        return ObjectMapper(row).to_object(target_class)

    def fetch_all(self, target_class: Optional[Type[T]] = None) -> Union[List[Dict[str, Any]], List[T]]:
        """
        Fetch all matching rows.

        Args:
            target_class: Optional class to map results to (uses ObjectMapper)

        Returns:
            List of rows as dicts or mapped objects
        """
        sql = self._build_select()
        params = self._get_params()
        rows = self._executor.fetch_all(sql, params)

        if target_class is None:
            return rows

        from fixturify.object_mapper import ObjectMapper
        return [ObjectMapper(row).to_object(target_class) for row in rows]

    def fetch_value(self, column: str) -> Any:
        """
        Fetch single value from first matching row.

        Args:
            column: Column name to fetch

        Returns:
            Value of the column, or None if no results
        """
        row = self.fetch_one()
        if row is None:
            return None
        return row.get(column)

    # ==========================================================================
    # Async methods
    # ==========================================================================

    async def aexists(self) -> None:
        """Async version of exists()."""
        count = await self._acount()
        if count == 0:
            conditions_str = self._format_conditions()
            raise AssertionError(
                f"Expected at least 1 row in '{self._table}'{conditions_str}, found 0"
            )

    async def anot_exists(self) -> None:
        """Async version of not_exists()."""
        count = await self._acount()
        if count > 0:
            conditions_str = self._format_conditions()
            raise AssertionError(
                f"Expected 0 rows in '{self._table}'{conditions_str}, found {count}"
            )

    async def acount(self, expected: int) -> None:
        """Async version of count()."""
        actual = await self._acount()
        if actual != expected:
            conditions_str = self._format_conditions()
            raise AssertionError(
                f"Expected {expected} rows in '{self._table}'{conditions_str}, found {actual}"
            )

    async def afetch_one(self, target_class: Optional[Type[T]] = None) -> Union[Dict[str, Any], T, None]:
        """Async version of fetch_one()."""
        sql = self._build_select()
        params = self._get_params()
        row = await self._executor.afetch_one(sql, params)

        if row is None or target_class is None:
            return row

        from fixturify.object_mapper import ObjectMapper
        return ObjectMapper(row).to_object(target_class)

    async def afetch_all(self, target_class: Optional[Type[T]] = None) -> Union[List[Dict[str, Any]], List[T]]:
        """Async version of fetch_all()."""
        sql = self._build_select()
        params = self._get_params()
        rows = await self._executor.afetch_all(sql, params)

        if target_class is None:
            return rows

        from fixturify.object_mapper import ObjectMapper
        return [ObjectMapper(row).to_object(target_class) for row in rows]

    # ==========================================================================
    # Internal methods
    # ==========================================================================

    def _build_select(self) -> str:
        """Build SELECT query."""
        sql = f"SELECT * FROM {self._table}"
        sql += self._build_where()

        if self._order_by:
            sql += f" ORDER BY {self._order_by}"

        if self._limit:
            sql += f" LIMIT {self._limit}"

        return sql

    def _build_count(self) -> str:
        """Build COUNT query."""
        sql = f"SELECT COUNT(*) AS cnt FROM {self._table}"
        sql += self._build_where()
        return sql

    def _build_where(self) -> str:
        """Build WHERE clause."""
        if not self._conditions:
            return ""

        parts = []
        for cond in self._conditions:
            if len(cond) == 3:
                # Special condition (IS NULL, IS NOT NULL)
                col, _, op = cond
                parts.append(f"{col} {op}")
            else:
                # Regular condition
                col, _ = cond
                parts.append(f"{col} = %s")

        return " WHERE " + " AND ".join(parts)

    def _get_params(self) -> List[Any]:
        """Get query parameters."""
        params = []
        for cond in self._conditions:
            if len(cond) == 2:
                # Regular condition with value
                _, val = cond
                params.append(val)
        return params

    def _count(self) -> int:
        """Execute count query."""
        sql = self._build_count()
        params = self._get_params()
        result = self._executor.fetch_one(sql, params)
        return result["cnt"] if result else 0

    async def _acount(self) -> int:
        """Execute count query asynchronously."""
        sql = self._build_count()
        params = self._get_params()
        result = await self._executor.afetch_one(sql, params)
        return result["cnt"] if result else 0

    def _format_conditions(self) -> str:
        """Format conditions for error messages."""
        if not self._conditions:
            return ""

        parts = []
        for cond in self._conditions:
            if len(cond) == 3:
                col, _, op = cond
                parts.append(f"{col} {op}")
            else:
                col, val = cond
                parts.append(f"{col}={val!r}")

        return " where " + ", ".join(parts)


class RawQueryAssert:
    """
    Assertion helper for raw SQL queries.

    Allows custom queries while still providing assertion methods.
    """

    def __init__(self, sql: str, params: List[Any], executor: SqlQueryExecutor):
        """
        Initialize RawQueryAssert.

        Args:
            sql: SQL query
            params: Query parameters
            executor: Query executor
        """
        self._sql = sql
        self._params = params
        self._executor = executor

    def fetch_one(self, target_class: Optional[Type[T]] = None) -> Union[Dict[str, Any], T, None]:
        """Fetch first row."""
        row = self._executor.fetch_one(self._sql, self._params)
        if row is None or target_class is None:
            return row

        from fixturify.object_mapper import ObjectMapper
        return ObjectMapper(row).to_object(target_class)

    def fetch_all(self, target_class: Optional[Type[T]] = None) -> Union[List[Dict[str, Any]], List[T]]:
        """Fetch all rows."""
        rows = self._executor.fetch_all(self._sql, self._params)
        if target_class is None:
            return rows

        from fixturify.object_mapper import ObjectMapper
        return [ObjectMapper(row).to_object(target_class) for row in rows]

    def exists(self) -> None:
        """Assert query returns at least one row."""
        row = self._executor.fetch_one(self._sql, self._params)
        if row is None:
            raise AssertionError("Expected results from query, got none")

    def not_exists(self) -> None:
        """Assert query returns no rows."""
        row = self._executor.fetch_one(self._sql, self._params)
        if row is not None:
            raise AssertionError(f"Expected no results from query, got: {row}")
