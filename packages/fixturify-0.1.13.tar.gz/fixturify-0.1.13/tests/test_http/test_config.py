"""Tests for HTTP configuration."""

from fixturify.http_d import HttpTestConfig
from fixturify.http_d._config import (
    DEFAULT_IGNORE_REQUEST_HEADERS,
    DEFAULT_EXCLUDE_REQUEST_HEADERS,
    DEFAULT_EXCLUDE_RESPONSE_HEADERS,
)


class TestHttpTestConfig:
    """Tests for HttpTestConfig class."""

    def test_default_config(self):
        """Test default configuration values."""
        config = HttpTestConfig()

        assert config.ignore_request_headers == []
        assert config.ignore_response_headers == []
        assert config.exclude_request_headers == []
        assert config.exclude_response_headers == []
        assert config.match_request_body is True
        assert config.strict_order is False

    def test_custom_config(self):
        """Test custom configuration values."""
        config = HttpTestConfig(
            ignore_request_headers=["Authorization"],
            exclude_request_headers=["X-API-Key"],
            match_request_body=False,
            strict_order=True,
        )

        assert config.ignore_request_headers == ["Authorization"]
        assert config.exclude_request_headers == ["X-API-Key"]
        assert config.match_request_body is False
        assert config.strict_order is True

    def test_get_ignore_request_headers_set_includes_defaults(self):
        """Test that ignore headers includes defaults."""
        config = HttpTestConfig()

        headers = config.get_ignore_request_headers_set()

        # Should include all defaults
        assert "user-agent" in headers
        assert "date" in headers
        assert "accept-encoding" in headers
        assert "content-length" in headers

    def test_get_ignore_request_headers_set_adds_custom(self):
        """Test that custom ignore headers are added."""
        config = HttpTestConfig(ignore_request_headers=["Authorization", "X-Custom"])

        headers = config.get_ignore_request_headers_set()

        # Should include defaults and custom
        assert "user-agent" in headers
        assert "authorization" in headers  # lowercase
        assert "x-custom" in headers  # lowercase

    def test_get_exclude_request_headers_set_includes_defaults(self):
        """Test that exclude request headers includes defaults."""
        config = HttpTestConfig()

        headers = config.get_exclude_request_headers_set()

        assert "user-agent" in headers
        assert "accept-encoding" in headers
        assert "connection" in headers
        assert "host" in headers

    def test_get_exclude_request_headers_set_adds_custom(self):
        """Test that custom exclude headers are added."""
        config = HttpTestConfig(exclude_request_headers=["Authorization", "X-Secret"])

        headers = config.get_exclude_request_headers_set()

        # Should include defaults and custom
        assert "user-agent" in headers
        assert "authorization" in headers
        assert "x-secret" in headers

    def test_get_exclude_response_headers_set_includes_defaults(self):
        """Test that exclude response headers includes defaults."""
        config = HttpTestConfig()

        headers = config.get_exclude_response_headers_set()

        assert "date" in headers
        assert "server" in headers
        assert "x-request-id" in headers
        assert "set-cookie" in headers
        assert "transfer-encoding" in headers

    def test_get_exclude_response_headers_set_adds_custom(self):
        """Test that custom exclude response headers are added."""
        config = HttpTestConfig(exclude_response_headers=["X-Internal-Trace"])

        headers = config.get_exclude_response_headers_set()

        assert "date" in headers  # default
        assert "x-internal-trace" in headers  # custom

    def test_get_ignore_response_headers_set(self):
        """Test ignore response headers (no defaults)."""
        config = HttpTestConfig(ignore_response_headers=["X-Vary-Header"])

        headers = config.get_ignore_response_headers_set()

        assert "x-vary-header" in headers
        # No defaults for response ignore
        assert len(headers) == 1

    def test_header_case_normalization(self):
        """Test that headers are normalized to lowercase."""
        config = HttpTestConfig(
            ignore_request_headers=["AUTHORIZATION", "Content-Type"],
            exclude_request_headers=["X-API-KEY"],
        )

        ignore_headers = config.get_ignore_request_headers_set()
        exclude_headers = config.get_exclude_request_headers_set()

        assert "authorization" in ignore_headers
        assert "content-type" in ignore_headers
        assert "x-api-key" in exclude_headers


class TestExcludeHosts:
    """Tests for exclude_hosts configuration."""

    def test_default_exclude_hosts_is_empty(self):
        """Test that exclude_hosts defaults to empty list."""
        config = HttpTestConfig()

        assert config.exclude_hosts == []
        assert config.get_exclude_hosts_set() == set()

    def test_exclude_hosts_set(self):
        """Test setting exclude_hosts."""
        config = HttpTestConfig(exclude_hosts=["testserver", "localhost:8000"])

        assert "testserver" in config.get_exclude_hosts_set()
        assert "localhost:8000" in config.get_exclude_hosts_set()

    def test_exclude_hosts_case_insensitive(self):
        """Test that exclude_hosts is case-insensitive."""
        config = HttpTestConfig(exclude_hosts=["TestServer", "LOCALHOST:8000"])

        hosts = config.get_exclude_hosts_set()
        assert "testserver" in hosts
        assert "localhost:8000" in hosts

    def test_is_host_excluded_basic(self):
        """Test is_host_excluded with basic URLs."""
        config = HttpTestConfig(exclude_hosts=["testserver", "localhost:8000"])

        assert config.is_host_excluded("http://testserver/api/v1") is True
        assert config.is_host_excluded("http://localhost:8000/users") is True
        assert config.is_host_excluded("https://api.example.com/data") is False

    def test_is_host_excluded_with_port(self):
        """Test is_host_excluded matches host with port."""
        config = HttpTestConfig(exclude_hosts=["localhost:8000"])

        assert config.is_host_excluded("http://localhost:8000/api") is True
        assert config.is_host_excluded("http://localhost:9000/api") is False
        assert config.is_host_excluded("http://localhost/api") is False

    def test_is_host_excluded_hostname_only(self):
        """Test is_host_excluded matches hostname without port."""
        config = HttpTestConfig(exclude_hosts=["localhost"])

        # "localhost" should match "localhost" but not "localhost:8000"
        assert config.is_host_excluded("http://localhost/api") is True
        # Also matches hostname part of "localhost:8000"
        assert config.is_host_excluded("http://localhost:8000/api") is True

    def test_is_host_excluded_empty_list(self):
        """Test is_host_excluded with empty exclude list."""
        config = HttpTestConfig()

        assert config.is_host_excluded("http://testserver/api") is False
        assert config.is_host_excluded("http://localhost:8000/api") is False

    def test_is_host_excluded_case_insensitive(self):
        """Test is_host_excluded is case-insensitive."""
        config = HttpTestConfig(exclude_hosts=["TestServer"])

        assert config.is_host_excluded("http://testserver/api") is True
        assert config.is_host_excluded("http://TESTSERVER/api") is True
        assert config.is_host_excluded("http://TestServer/api") is True


class TestDefaultHeaderSets:
    """Tests for default header sets."""

    def test_default_ignore_request_headers(self):
        """Test default ignore request headers contains key headers."""
        # Connection & Protocol
        assert "host" in DEFAULT_IGNORE_REQUEST_HEADERS
        assert "connection" in DEFAULT_IGNORE_REQUEST_HEADERS
        assert "content-length" in DEFAULT_IGNORE_REQUEST_HEADERS
        # Client/Browser
        assert "user-agent" in DEFAULT_IGNORE_REQUEST_HEADERS
        assert "accept-encoding" in DEFAULT_IGNORE_REQUEST_HEADERS
        # Tracing
        assert "x-request-id" in DEFAULT_IGNORE_REQUEST_HEADERS
        assert "traceparent" in DEFAULT_IGNORE_REQUEST_HEADERS

    def test_default_exclude_request_headers(self):
        """Test default exclude request headers."""
        assert "user-agent" in DEFAULT_EXCLUDE_REQUEST_HEADERS
        assert "host" in DEFAULT_EXCLUDE_REQUEST_HEADERS
        assert "traceparent" in DEFAULT_EXCLUDE_REQUEST_HEADERS

    def test_default_exclude_response_headers(self):
        """Test default exclude response headers."""
        assert "date" in DEFAULT_EXCLUDE_RESPONSE_HEADERS
        assert "server" in DEFAULT_EXCLUDE_RESPONSE_HEADERS
        assert "set-cookie" in DEFAULT_EXCLUDE_RESPONSE_HEADERS
