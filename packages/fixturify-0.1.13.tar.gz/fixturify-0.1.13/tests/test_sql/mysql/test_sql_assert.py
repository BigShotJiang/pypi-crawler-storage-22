"""Tests for SqlAssert with MySQL (mysql.connector)."""

from dataclasses import dataclass
from typing import Optional

import pytest

from fixturify.sql_d import Phase, sql, SqlAssert


def _can_connect() -> bool:
    """Check if MySQL is available."""
    try:
        import mysql.connector

        conn = mysql.connector.connect(
            host="localhost",
            port=3306,
            database="fixturify",
            user="root",
            password="",
        )
        conn.close()
        return True
    except Exception:
        return False


@dataclass
class User:
    """Test user model for ObjectMapper integration."""

    id: int
    name: str
    email: Optional[str] = None


@pytest.mark.skipif(not _can_connect(), reason="MySQL not available")
class TestMySqlAssert:
    """MySQL SqlAssert tests."""

    @sql(path="../fixtures/mysql_setup.sql")
    @sql(path="../fixtures/mysql_cleanup.sql", phase=Phase.AFTER)
    def test_exists(self, sql_assert: SqlAssert):
        """Test exists() assertion."""
        sql_assert.table("sql_test_users").where(name="Alice").exists()

    @sql(path="../fixtures/mysql_setup.sql")
    @sql(path="../fixtures/mysql_cleanup.sql", phase=Phase.AFTER)
    def test_not_exists(self, sql_assert: SqlAssert):
        """Test not_exists() assertion."""
        sql_assert.table("sql_test_users").where(name="NonExistent").not_exists()

    @sql(path="../fixtures/mysql_setup.sql")
    @sql(path="../fixtures/mysql_cleanup.sql", phase=Phase.AFTER)
    def test_count(self, sql_assert: SqlAssert):
        """Test count() assertion."""
        sql_assert.table("sql_test_users").count(2)

    @sql(path="../fixtures/mysql_setup.sql")
    @sql(path="../fixtures/mysql_cleanup.sql", phase=Phase.AFTER)
    def test_fetch_one(self, sql_assert: SqlAssert):
        """Test fetch_one() returns dict."""
        row = sql_assert.table("sql_test_users").where(name="Alice").fetch_one()

        assert row is not None
        assert row["name"] == "Alice"
        assert row["email"] == "alice@example.com"

    @sql(path="../fixtures/mysql_setup.sql")
    @sql(path="../fixtures/mysql_cleanup.sql", phase=Phase.AFTER)
    def test_fetch_one_with_object_mapper(self, sql_assert: SqlAssert):
        """Test fetch_one() with ObjectMapper."""
        user = sql_assert.table("sql_test_users").where(name="Alice").fetch_one(User)

        assert isinstance(user, User)
        assert user.name == "Alice"

    @sql(path="../fixtures/mysql_setup.sql")
    @sql(path="../fixtures/mysql_cleanup.sql", phase=Phase.AFTER)
    def test_fetch_all(self, sql_assert: SqlAssert):
        """Test fetch_all() returns list of dicts."""
        rows = sql_assert.table("sql_test_users").order_by("name").fetch_all()

        assert len(rows) == 2
        assert rows[0]["name"] == "Alice"
        assert rows[1]["name"] == "Bob"

    @sql(path="../fixtures/mysql_setup.sql")
    @sql(path="../fixtures/mysql_cleanup.sql", phase=Phase.AFTER)
    def test_has(self, sql_assert: SqlAssert):
        """Test has() assertion."""
        sql_assert.table("sql_test_users").where(name="Alice").has(
            email="alice@example.com"
        )

    @sql(path="../fixtures/mysql_setup.sql")
    @sql(path="../fixtures/mysql_cleanup.sql", phase=Phase.AFTER)
    def test_raw_query(self, sql_assert: SqlAssert):
        """Test raw() query."""
        result = sql_assert.raw(
            "SELECT COUNT(*) as cnt FROM sql_test_users WHERE name LIKE %s",
            ["%ob%"],
        ).fetch_one()

        assert result is not None
        assert result["cnt"] == 1  # Bob
