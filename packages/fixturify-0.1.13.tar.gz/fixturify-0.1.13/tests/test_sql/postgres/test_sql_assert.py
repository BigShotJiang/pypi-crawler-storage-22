"""Tests for SqlAssert with PostgreSQL (psycopg2)."""

from dataclasses import dataclass
from typing import Optional

import pytest

from fixturify.sql_d import Phase, sql, SqlAssert


def _can_connect() -> bool:
    """Check if PostgreSQL is available."""
    try:
        import psycopg2

        conn = psycopg2.connect(
            host="localhost",
            port=5432,
            dbname="fixturify",
            user="postgres",
            password="postgres",
        )
        conn.close()
        return True
    except Exception:
        return False


@dataclass
class User:
    """Test user model for ObjectMapper integration."""

    id: int
    name: str
    email: Optional[str] = None


@pytest.mark.skipif(not _can_connect(), reason="PostgreSQL not available")
class TestSqlAssertBasic:
    """Basic SqlAssert tests."""

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_exists(self, sql_assert: SqlAssert):
        """Test exists() assertion."""
        sql_assert.table("sql_test_users").where(name="Alice").exists()

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_exists_fails_when_no_match(self, sql_assert: SqlAssert):
        """Test exists() raises when no rows match."""
        with pytest.raises(AssertionError, match="Expected at least 1 row"):
            sql_assert.table("sql_test_users").where(name="NonExistent").exists()

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_not_exists(self, sql_assert: SqlAssert):
        """Test not_exists() assertion."""
        sql_assert.table("sql_test_users").where(name="NonExistent").not_exists()

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_not_exists_fails_when_match(self, sql_assert: SqlAssert):
        """Test not_exists() raises when rows match."""
        with pytest.raises(AssertionError, match="Expected 0 rows"):
            sql_assert.table("sql_test_users").where(name="Alice").not_exists()


@pytest.mark.skipif(not _can_connect(), reason="PostgreSQL not available")
class TestSqlAssertCount:
    """Count assertion tests."""

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_count_exact(self, sql_assert: SqlAssert):
        """Test count() with exact match."""
        sql_assert.table("sql_test_users").count(2)

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_count_with_where(self, sql_assert: SqlAssert):
        """Test count() with WHERE clause."""
        sql_assert.table("sql_test_users").where(name="Alice").count(1)

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_count_fails_on_mismatch(self, sql_assert: SqlAssert):
        """Test count() raises on mismatch."""
        with pytest.raises(AssertionError, match="Expected 5 rows"):
            sql_assert.table("sql_test_users").count(5)

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_count_gt(self, sql_assert: SqlAssert):
        """Test count_gt() assertion."""
        sql_assert.table("sql_test_users").count_gt(1)

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_count_gte(self, sql_assert: SqlAssert):
        """Test count_gte() assertion."""
        sql_assert.table("sql_test_users").count_gte(2)

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_count_lt(self, sql_assert: SqlAssert):
        """Test count_lt() assertion."""
        sql_assert.table("sql_test_users").count_lt(10)

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_count_lte(self, sql_assert: SqlAssert):
        """Test count_lte() assertion."""
        sql_assert.table("sql_test_users").count_lte(2)


@pytest.mark.skipif(not _can_connect(), reason="PostgreSQL not available")
class TestSqlAssertFetch:
    """Fetch tests."""

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_fetch_one_dict(self, sql_assert: SqlAssert):
        """Test fetch_one() returns dict."""
        row = sql_assert.table("sql_test_users").where(name="Alice").fetch_one()

        assert row is not None
        assert row["name"] == "Alice"
        assert row["email"] == "alice@example.com"

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_fetch_one_none(self, sql_assert: SqlAssert):
        """Test fetch_one() returns None when no match."""
        row = sql_assert.table("sql_test_users").where(name="NonExistent").fetch_one()

        assert row is None

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_fetch_one_with_object_mapper(self, sql_assert: SqlAssert):
        """Test fetch_one() with ObjectMapper."""
        user = sql_assert.table("sql_test_users").where(name="Alice").fetch_one(User)

        assert isinstance(user, User)
        assert user.name == "Alice"
        assert user.email == "alice@example.com"

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_fetch_all_dict(self, sql_assert: SqlAssert):
        """Test fetch_all() returns list of dicts."""
        rows = sql_assert.table("sql_test_users").order_by("name").fetch_all()

        assert len(rows) == 2
        assert rows[0]["name"] == "Alice"
        assert rows[1]["name"] == "Bob"

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_fetch_all_with_object_mapper(self, sql_assert: SqlAssert):
        """Test fetch_all() with ObjectMapper."""
        users = sql_assert.table("sql_test_users").order_by("name").fetch_all(User)

        assert len(users) == 2
        assert all(isinstance(u, User) for u in users)
        assert users[0].name == "Alice"
        assert users[1].name == "Bob"

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_fetch_value(self, sql_assert: SqlAssert):
        """Test fetch_value() returns single value."""
        email = sql_assert.table("sql_test_users").where(name="Alice").fetch_value("email")

        assert email == "alice@example.com"


@pytest.mark.skipif(not _can_connect(), reason="PostgreSQL not available")
class TestSqlAssertHas:
    """Value assertion tests."""

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_has_success(self, sql_assert: SqlAssert):
        """Test has() with matching values."""
        sql_assert.table("sql_test_users").where(name="Alice").has(
            email="alice@example.com"
        )

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_has_fails_on_mismatch(self, sql_assert: SqlAssert):
        """Test has() raises on value mismatch."""
        with pytest.raises(AssertionError, match="doesn't match expected values"):
            sql_assert.table("sql_test_users").where(name="Alice").has(
                email="wrong@example.com"
            )

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_has_fails_on_missing_row(self, sql_assert: SqlAssert):
        """Test has() raises when no row found."""
        with pytest.raises(AssertionError, match="Expected row"):
            sql_assert.table("sql_test_users").where(name="NonExistent").has(
                email="any@example.com"
            )

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_has_any(self, sql_assert: SqlAssert):
        """Test has_any() finds matching row."""
        sql_assert.table("sql_test_users").has_any(email="bob@example.com")

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_has_any_fails(self, sql_assert: SqlAssert):
        """Test has_any() raises when no row matches."""
        with pytest.raises(AssertionError, match="No row in .* matches"):
            sql_assert.table("sql_test_users").has_any(email="nonexistent@example.com")


@pytest.mark.skipif(not _can_connect(), reason="PostgreSQL not available")
class TestSqlAssertChaining:
    """Test method chaining."""

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_multiple_where(self, sql_assert: SqlAssert):
        """Test chaining multiple where() calls."""
        sql_assert.table("sql_test_users").where(name="Alice").where(
            email="alice@example.com"
        ).exists()

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_order_by_and_limit(self, sql_assert: SqlAssert):
        """Test order_by() and limit() chaining."""
        row = (
            sql_assert.table("sql_test_users")
            .order_by("name", desc=True)
            .limit(1)
            .fetch_one()
        )

        assert row is not None
        assert row["name"] == "Bob"

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_immutable_chaining(self, sql_assert: SqlAssert):
        """Test that chaining creates new instances (immutable)."""
        base = sql_assert.table("sql_test_users")
        with_alice = base.where(name="Alice")
        with_bob = base.where(name="Bob")

        # Each should find their respective users
        with_alice.exists()
        with_bob.exists()

        # Base should still find all users
        base.count(2)


@pytest.mark.skipif(not _can_connect(), reason="PostgreSQL not available")
class TestSqlAssertRawQuery:
    """Raw query tests."""

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_raw_query_fetch(self, sql_assert: SqlAssert):
        """Test raw() query execution."""
        result = sql_assert.raw(
            "SELECT COUNT(*) as cnt FROM sql_test_users WHERE name LIKE %s",
            ["%li%"],
        ).fetch_one()

        assert result is not None
        assert result["cnt"] == 1  # Alice

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_raw_query_exists(self, sql_assert: SqlAssert):
        """Test raw() with exists()."""
        sql_assert.raw(
            "SELECT 1 FROM sql_test_users WHERE email LIKE %s",
            ["%example.com%"],
        ).exists()

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_raw_query_not_exists(self, sql_assert: SqlAssert):
        """Test raw() with not_exists()."""
        sql_assert.raw(
            "SELECT 1 FROM sql_test_users WHERE email LIKE %s",
            ["%nonexistent%"],
        ).not_exists()
