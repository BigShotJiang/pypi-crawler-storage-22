"""Tests for SqlAssert with PostgreSQL async (asyncpg)."""

from dataclasses import dataclass
from typing import Optional

import pytest

from fixturify.sql_d import Phase, sql, SqlAssert


def _can_connect() -> bool:
    """Check if PostgreSQL is available."""
    try:
        import asyncio
        import asyncpg

        async def check():
            conn = await asyncpg.connect(
                host="localhost",
                port=5432,
                database="fixturify",
                user="postgres",
                password="postgres",
            )
            await conn.close()
            return True

        return asyncio.get_event_loop().run_until_complete(check())
    except Exception:
        return False


@dataclass
class User:
    """Test user model for ObjectMapper integration."""

    id: int
    name: str
    email: Optional[str] = None


@pytest.mark.skipif(not _can_connect(), reason="PostgreSQL not available")
class TestAsyncPgSqlAssert:
    """PostgreSQL async SqlAssert tests."""

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_aexists(self, sql_assert: SqlAssert):
        """Test aexists() assertion."""
        await sql_assert.table("sql_test_users").where(name="Alice").aexists()

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_anot_exists(self, sql_assert: SqlAssert):
        """Test anot_exists() assertion."""
        await sql_assert.table("sql_test_users").where(name="NonExistent").anot_exists()

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_acount(self, sql_assert: SqlAssert):
        """Test acount() assertion."""
        await sql_assert.table("sql_test_users").acount(2)

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_afetch_one(self, sql_assert: SqlAssert):
        """Test afetch_one() returns dict."""
        row = await sql_assert.table("sql_test_users").where(name="Alice").afetch_one()

        assert row is not None
        assert row["name"] == "Alice"
        assert row["email"] == "alice@example.com"

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_afetch_one_with_object_mapper(self, sql_assert: SqlAssert):
        """Test afetch_one() with ObjectMapper."""
        user = await sql_assert.table("sql_test_users").where(name="Alice").afetch_one(User)

        assert isinstance(user, User)
        assert user.name == "Alice"

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_afetch_all(self, sql_assert: SqlAssert):
        """Test afetch_all() returns list of dicts."""
        rows = await sql_assert.table("sql_test_users").order_by("name").afetch_all()

        assert len(rows) == 2
        assert rows[0]["name"] == "Alice"
        assert rows[1]["name"] == "Bob"

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_afetch_all_with_object_mapper(self, sql_assert: SqlAssert):
        """Test afetch_all() with ObjectMapper."""
        users = await sql_assert.table("sql_test_users").order_by("name").afetch_all(User)

        assert len(users) == 2
        assert all(isinstance(u, User) for u in users)
        assert users[0].name == "Alice"
        assert users[1].name == "Bob"
