"""Integration tests for HTTP mock decorator using real API.

These tests use https://api.restful-api.dev/objects - a free REST API
for testing. On first run, real HTTP calls are made and recorded.
On subsequent runs, recorded responses are played back.

To re-record: delete the fixture files in fixtures/ directory.
"""

import json
import pytest

from fixturify.http_d import (
    http,
    HttpTestConfig,
    NoMatchingRecordingError,
    UnusedRecordingsError,
)


# Check if httpx is available
try:
    import httpx

    HAS_HTTPX = True
except ImportError:
    HAS_HTTPX = False

# Check if requests is available
try:
    import requests

    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False


# Base URL for the test API
API_BASE = "https://api.restful-api.dev"


@pytest.mark.skipif(not HAS_REQUESTS, reason="requests not installed")
class TestRequestsIntegration:
    """Integration tests using requests library."""

    @http(path="./fixtures/requests_get_all_objects.json")
    def test_get_all_objects(self):
        """Test GET request to fetch all objects."""
        response = requests.get(f"{API_BASE}/objects")

        assert response.status_code == 200
        data = response.json()

        # Should return a list of objects
        assert isinstance(data, list)
        assert len(data) > 0

        # First object should have expected structure
        first_obj = data[0]
        assert "id" in first_obj
        assert "name" in first_obj

    @http(path="./fixtures/requests_get_single_object.json")
    def test_get_single_object(self):
        """Test GET request to fetch a single object by ID."""
        response = requests.get(f"{API_BASE}/objects/1")

        assert response.status_code == 200
        data = response.json()

        assert data["id"] == "1"
        assert "name" in data
        # Object 1 is "Google Pixel 6 Pro"
        assert "Google Pixel" in data["name"]

    @http(path="./fixtures/requests_get_multiple_objects.json")
    def test_get_multiple_objects_by_ids(self):
        """Test GET request with query parameters for multiple IDs."""
        response = requests.get(f"{API_BASE}/objects", params={"id": ["1", "2", "3"]})

        assert response.status_code == 200
        data = response.json()

        # Should return filtered list
        assert isinstance(data, list)

    @http(path="./fixtures/requests_post_object.json")
    def test_create_object(self):
        """Test POST request to create a new object."""
        new_object = {"name": "Test Product", "data": {"color": "Blue", "price": 99.99}}

        response = requests.post(
            f"{API_BASE}/objects",
            json=new_object,
            headers={"Content-Type": "application/json"},
        )

        assert response.status_code == 200
        data = response.json()

        # Should return created object with ID
        assert "id" in data
        assert data["name"] == "Test Product"

    @http(path="./fixtures/requests_sequential_calls.json")
    def test_sequential_api_calls(self):
        """Test multiple sequential API calls in one test."""
        # First call: get all objects
        response1 = requests.get(f"{API_BASE}/objects")
        assert response1.status_code == 200
        all_objects = response1.json()

        # Second call: get first object by ID
        first_id = all_objects[0]["id"]
        response2 = requests.get(f"{API_BASE}/objects/{first_id}")
        assert response2.status_code == 200

        # Third call: get second object by ID
        second_id = all_objects[1]["id"]
        response3 = requests.get(f"{API_BASE}/objects/{second_id}")
        assert response3.status_code == 200

    @http(
        path="./fixtures/requests_with_config.json",
        config=HttpTestConfig(
            ignore_request_headers=["X-Custom-Header"],
            exclude_request_headers=["X-Secret-Key"],
        ),
    )
    def test_with_custom_headers(self):
        """Test with custom headers that should be filtered."""
        response = requests.get(
            f"{API_BASE}/objects/1",
            headers={
                "X-Custom-Header": "custom-value",
                "X-Secret-Key": "secret-123",  # Should not be saved
            },
        )

        assert response.status_code == 200


@pytest.mark.skipif(not HAS_HTTPX, reason="httpx not installed")
class TestHttpxSyncIntegration:
    """Integration tests using httpx sync client."""

    @http(path="./fixtures/httpx_sync_get_all.json")
    def test_get_all_objects(self):
        """Test sync httpx GET request."""
        with httpx.Client() as client:
            response = client.get(f"{API_BASE}/objects")

        assert response.status_code == 200
        data = response.json()

        assert isinstance(data, list)
        assert len(data) > 0

    @http(path="./fixtures/httpx_sync_get_single.json")
    def test_get_single_object(self):
        """Test sync httpx GET request for single object."""
        with httpx.Client() as client:
            response = client.get(f"{API_BASE}/objects/7")

        assert response.status_code == 200
        data = response.json()

        # Object 7 is "Apple MacBook Pro 16"
        assert "MacBook" in data["name"]

    @http(path="./fixtures/httpx_sync_post.json")
    def test_create_object(self):
        """Test sync httpx POST request."""
        new_object = {
            "name": "Httpx Test Product",
            "data": {"category": "Electronics", "price": 149.99},
        }

        with httpx.Client() as client:
            response = client.post(
                f"{API_BASE}/objects",
                json=new_object,
            )

        assert response.status_code == 200
        data = response.json()
        assert "id" in data


@pytest.mark.skipif(not HAS_HTTPX, reason="httpx not installed")
class TestHttpxAsyncIntegration:
    """Integration tests using httpx async client."""

    @pytest.mark.asyncio
    @http(path="./fixtures/httpx_async_get_all.json")
    async def test_get_all_objects_async(self):
        """Test async httpx GET request."""
        async with httpx.AsyncClient() as client:
            response = await client.get(f"{API_BASE}/objects")

        assert response.status_code == 200
        data = response.json()

        assert isinstance(data, list)
        assert len(data) > 0

    @pytest.mark.asyncio
    @http(path="./fixtures/httpx_async_get_single.json")
    async def test_get_single_object_async(self):
        """Test async httpx GET for single object."""
        async with httpx.AsyncClient() as client:
            response = await client.get(f"{API_BASE}/objects/6")

        assert response.status_code == 200
        data = response.json()

        # Object 6 is "Apple AirPods"
        assert "AirPods" in data["name"]

    @pytest.mark.asyncio
    @http(path="./fixtures/httpx_async_multiple.json", strict_order=False)
    async def test_multiple_async_requests(self):
        """Test multiple async requests."""
        import asyncio

        async with httpx.AsyncClient() as client:
            # Make multiple concurrent requests
            tasks = [
                client.get(f"{API_BASE}/objects/1"),
                client.get(f"{API_BASE}/objects/2"),
                client.get(f"{API_BASE}/objects/3"),
            ]
            responses = await asyncio.gather(*tasks)

        # All should succeed
        for response in responses:
            assert response.status_code == 200

        # Verify we got different objects
        names = [r.json()["name"] for r in responses]
        assert len(set(names)) == 3  # All different


class TestMixedClients:
    """Tests using both requests and httpx in same test."""

    @pytest.mark.skipif(
        not (HAS_REQUESTS and HAS_HTTPX), reason="Both requests and httpx required"
    )
    @http(path="./fixtures/mixed_clients.json")
    def test_requests_and_httpx_together(self):
        """Test using both HTTP clients in one test."""
        # Use requests for first call
        response1 = requests.get(f"{API_BASE}/objects/1")
        assert response1.status_code == 200

        # Use httpx for second call
        with httpx.Client() as client:
            response2 = client.get(f"{API_BASE}/objects/2")
        assert response2.status_code == 200

        # Verify different objects
        assert response1.json()["id"] != response2.json()["id"]


class TestErrorScenarios:
    """Tests for error handling scenarios."""

    @pytest.mark.skipif(not HAS_REQUESTS, reason="requests not installed")
    def test_playback_fails_on_unrecorded_request(self, tmp_path):
        """Test that playback fails when request doesn't match recording."""
        # Create a recording file with only one endpoint
        recordings_file = tmp_path / "limited_recording.json"
        data = {
            "mappings": [
                {
                    "request": {
                        "method": "GET",
                        "url": f"{API_BASE}/objects/1",
                        "headers": {},
                        "queryParameters": {},
                    },
                    "response": {
                        "status": 200,
                        "headers": {"Content-Type": "application/json"},
                        "body": {"id": "1", "name": "Test"},
                    },
                }
            ]
        }
        with open(recordings_file, "w") as f:
            json.dump(data, f)

        @http(path=str(recordings_file))
        def test_func():
            # This request is not in the recording
            requests.get(f"{API_BASE}/objects/999")

        with pytest.raises(NoMatchingRecordingError) as exc_info:
            test_func()

        assert "objects/999" in str(exc_info.value)

    @pytest.mark.skipif(not HAS_REQUESTS, reason="requests not installed")
    def test_playback_fails_on_unused_recordings(self, tmp_path):
        """Test that playback fails when recordings are not used."""
        # Create a recording file with multiple endpoints
        recordings_file = tmp_path / "extra_recordings.json"
        data = {
            "mappings": [
                {
                    "request": {
                        "method": "GET",
                        "url": f"{API_BASE}/objects/1",
                        "headers": {},
                        "queryParameters": {},
                    },
                    "response": {
                        "status": 200,
                        "headers": {"Content-Type": "application/json"},
                        "body": {"id": "1", "name": "Test 1"},
                    },
                },
                {
                    "request": {
                        "method": "GET",
                        "url": f"{API_BASE}/objects/2",
                        "headers": {},
                        "queryParameters": {},
                    },
                    "response": {
                        "status": 200,
                        "headers": {"Content-Type": "application/json"},
                        "body": {"id": "2", "name": "Test 2"},
                    },
                },
            ]
        }
        with open(recordings_file, "w") as f:
            json.dump(data, f)

        @http(path=str(recordings_file))
        def test_func():
            # Only use one of the two recordings
            response = requests.get(f"{API_BASE}/objects/1")
            assert response.status_code == 200

        with pytest.raises(UnusedRecordingsError) as exc_info:
            test_func()

        assert "unused" in str(exc_info.value).lower()
        assert "objects/2" in str(exc_info.value)


class TestConfigWithFixture:
    """Tests demonstrating config fixture discovery by TYPE, not name."""

    @pytest.fixture
    def my_test_http_settings(self) -> HttpTestConfig:
        """Fixture with custom name - discovery works by TYPE (HttpTestConfig), not name."""
        return HttpTestConfig(
            ignore_request_headers=["X-Test-Header"],
            exclude_response_headers=["X-Powered-By"],
        )

    @pytest.mark.skipif(not HAS_REQUESTS, reason="requests not installed")
    @http(path="./fixtures/fixture_config_test.json")
    def test_with_fixture_config(self):
        """Test that config is auto-discovered by TYPE, fixture name doesn't matter."""
        # The 'my_test_http_settings' fixture is auto-discovered by its return type
        # (HttpTestConfig), NOT by its name. No parameter needed.
        response = requests.get(
            f"{API_BASE}/objects/1", headers={"X-Test-Header": "test-value"}
        )

        assert response.status_code == 200
