"""Shared constants for PyTools modules."""

# All file I/O operations must use UTF-8 encoding for cross-platform consistency
ENCODING = "utf-8"

# Maximum depth for object traversal (prevents infinite recursion).
# This value is intentionally hardcoded at 100 for simplicity and predictability.
# Deeply nested structures beyond 100 levels typically indicate circular references
# or design issues that should be addressed differently.
MAX_DEPTH = 100
