"""Generic pytest fixture discovery by return type annotation.

This module provides a reusable fixture discovery mechanism that finds
pytest fixtures based on their return type annotation, not their name.
"""

from typing import TYPE_CHECKING, Any, List, Optional, Type, TypeVar

if TYPE_CHECKING:
    from _pytest.fixtures import FixtureRequest


T = TypeVar("T")


class AmbiguousConfigFixtureError(Exception):
    """Raised when multiple pytest fixtures return the same config type."""


def is_pytest_available() -> bool:
    """Check if pytest is installed."""
    try:
        import pytest  # noqa: F401

        return True
    except ImportError:
        return False


def find_fixture_by_type(
    request: "FixtureRequest",
    config_type: Type[T],
) -> Optional[T]:
    """
    Find a pytest fixture by its return TYPE annotation.

    Scans ALL available fixtures (not just function dependencies) for fixtures
    that return the specified type. This allows defining config fixtures in
    conftest.py without needing to add them as test parameters.

    Args:
        request: Pytest's FixtureRequest object
        config_type: The type to search for (e.g., SqlTestConfig, HttpTestConfig)

    Returns:
        Instance of config_type if a matching fixture is found, None otherwise
    """
    # First pass: check fixture type annotations to find matching fixtures
    # This scans ALL available fixtures, not just function dependencies
    candidate_fixtures = _get_fixture_names_by_type(request, config_type)

    if len(candidate_fixtures) > 1:
        names = ", ".join(f"'{name}'" for name in candidate_fixtures)
        raise AmbiguousConfigFixtureError(
            f"Multiple pytest fixtures found returning {config_type.__name__}: "
            f"{names}. Define only one fixture returning {config_type.__name__}, "
            f"or pass config explicitly to the decorator."
        )

    # If we found a candidate by annotation, try it
    if candidate_fixtures:
        fixture_name = candidate_fixtures[0]
        try:
            value = request.getfixturevalue(fixture_name)
            if isinstance(value, config_type):
                return value
        except Exception:
            pass
        return None

    # Fallback: iterate through function's fixture dependencies
    # This maintains backward compatibility with unannotated fixtures
    resolved: list = []
    for fixture_name in request.fixturenames:
        try:
            value = request.getfixturevalue(fixture_name)
            if isinstance(value, config_type):
                resolved.append(fixture_name)
        except Exception:
            continue

    if len(resolved) > 1:
        names = ", ".join(f"'{name}'" for name in resolved)
        raise AmbiguousConfigFixtureError(
            f"Multiple pytest fixtures found returning {config_type.__name__}: "
            f"{names}. Define only one fixture returning {config_type.__name__}, "
            f"or pass config explicitly to the decorator."
        )

    if resolved:
        return request.getfixturevalue(resolved[0])  # type: ignore[no-any-return]

    return None


def _get_fixture_names_by_type(
    request: "FixtureRequest",
    config_type: Type[T],
) -> List[str]:
    """
    Get fixture names that are annotated as returning the specified type.

    Scans ALL available fixtures in the fixture manager, not just the ones
    in the function's dependency list.

    Args:
        request: Pytest's FixtureRequest object
        config_type: The type to search for

    Returns:
        List of fixture names with matching return annotation
    """
    candidates: List[str] = []

    # Access the fixture manager to get all fixture definitions
    fixturemanager = getattr(request, "_fixturemanager", None)
    if fixturemanager is None:
        return candidates

    # Get the node for fixture resolution (getfixturedefs needs node, not nodeid)
    node = getattr(request, "node", None)
    if node is None:
        return candidates

    # _arg2fixturedefs contains ALL registered fixtures
    # This is an internal pytest API but is stable
    arg2fixturedefs = getattr(fixturemanager, "_arg2fixturedefs", None)
    if arg2fixturedefs is None:
        # Fallback to just checking fixturenames
        return _get_from_fixturenames(request, fixturemanager, node, config_type)

    # Scan ALL fixtures for ones that return the target type
    for fixture_name in arg2fixturedefs.keys():
        try:
            # Get fixture definition(s) for this name
            fixturedefs = fixturemanager.getfixturedefs(fixture_name, node)
            if not fixturedefs:
                continue

            # Check the most recent fixture definition
            fixturedef = fixturedefs[-1]
            func = fixturedef.func

            # Check return annotation
            annotations = getattr(func, "__annotations__", {})
            return_type = annotations.get("return")

            if return_type is config_type:
                candidates.append(fixture_name)
        except Exception:
            # Can't inspect this fixture, skip
            continue

    return candidates


def _get_from_fixturenames(
    request: "FixtureRequest",
    fixturemanager: Any,
    node: Any,
    config_type: Type[T],
) -> List[str]:
    """
    Fallback: Get fixtures from function's fixturenames only.

    Used when _arg2fixturedefs is not available.
    """
    candidates: List[str] = []

    for fixture_name in getattr(request, "fixturenames", []):
        try:
            fixturedefs = fixturemanager.getfixturedefs(fixture_name, node)
            if not fixturedefs:
                continue

            fixturedef = fixturedefs[-1]
            func = fixturedef.func

            annotations = getattr(func, "__annotations__", {})
            return_type = annotations.get("return")

            if return_type is config_type:
                candidates.append(fixture_name)
        except Exception:
            continue

    return candidates
