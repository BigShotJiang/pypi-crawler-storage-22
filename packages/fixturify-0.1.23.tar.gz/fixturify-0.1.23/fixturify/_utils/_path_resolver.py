"""Path resolution utility for relative paths based on caller's file location."""

import inspect
from pathlib import Path
from typing import Optional


# Patterns to skip when walking the stack (debuggers, frameworks, internals)
_SKIP_PATH_PATTERNS = (
    # VS Code debugger
    "debugpy",
    "_debugpy",
    # PyCharm debugger
    "pydevd",
    "_pydevd",
    "_pydev_",
    "pydev",
    # Frameworks
    "site-packages",
    # Python internals
    "importlib",
    "<frozen",
)


class _PathResolver:
    """Resolves relative paths based on a reference file's location."""

    @staticmethod
    def resolve(relative_path: str, reference_file: Optional[str] = None) -> Path:
        """
        Resolve a relative path based on a reference file's location.

        Args:
            relative_path: Path like "../fixtures/data.json"
            reference_file: Absolute path to the reference file (e.g., test file).
                           If None, uses the caller's file location.

        Returns:
            Absolute Path object to the resolved file

        Raises:
            FileNotFoundError: If resolved path doesn't exist
        """
        if reference_file is None:
            # Get caller's file path (skip this function and the immediate caller)
            reference_file = _PathResolver._get_caller_file(stack_level=2)

        reference_dir = Path(reference_file).parent
        resolved = (reference_dir / relative_path).resolve()

        if not resolved.exists():
            raise FileNotFoundError(
                f"File not found: {resolved} "
                f"(resolved from '{relative_path}' relative to '{reference_file}')"
            )

        return resolved

    @staticmethod
    def resolve_without_check(
        relative_path: str, reference_file: Optional[str] = None
    ) -> Path:
        """
        Resolve a relative path without checking if the file exists.

        Args:
            relative_path: Path like "../fixtures/data.json"
            reference_file: Absolute path to the reference file.
                           If None, uses the caller's file location.

        Returns:
            Absolute Path object to the resolved file (may not exist)
        """
        if reference_file is None:
            reference_file = _PathResolver._get_caller_file(stack_level=2)

        reference_dir = Path(reference_file).parent
        return (reference_dir / relative_path).resolve()

    @staticmethod
    def _get_caller_file(stack_level: int = 1) -> str:
        """
        Get the file path of the caller, skipping internal and debugger frames.

        This method walks the stack and filters out:
        - pytools internal frames (detected via module name, not file path)
        - IDE debugger frames (VS Code debugpy, PyCharm pydevd)
        - Framework frames (site-packages, importlib)

        Using module names for pytools detection makes this independent of
        installation location (works with editable installs, wheels, etc.)

        Args:
            stack_level: Number of valid caller frames to skip (1 = immediate caller)

        Returns:
            Absolute path to the caller's file

        Raises:
            RuntimeError: If caller's file cannot be determined
        """
        frame = inspect.currentframe()
        if frame is None:
            raise RuntimeError("Cannot determine caller's file location")
        try:
            # Skip this function's frame
            frame = frame.f_back
            if frame is None:
                raise RuntimeError("Cannot determine caller's file location")
            valid_frames_found = 0

            while frame is not None:
                filename = inspect.getfile(frame)
                file_str = str(Path(filename).resolve())

                # Get module name from frame globals (reliable way to identify package)
                module_name = frame.f_globals.get("__name__", "")

                # Skip pytools internal frames (using module name, not file path)
                if module_name.startswith("fixturify.") or module_name == "fixturify":
                    frame = frame.f_back
                    continue

                # Skip debugger and framework frames (using file path patterns)
                if any(pattern in file_str for pattern in _SKIP_PATH_PATTERNS):
                    frame = frame.f_back
                    continue

                # Found a valid caller frame
                valid_frames_found += 1
                if valid_frames_found >= stack_level:
                    return file_str

                frame = frame.f_back

            raise RuntimeError("Cannot determine caller's file location")
        finally:
            del frame
