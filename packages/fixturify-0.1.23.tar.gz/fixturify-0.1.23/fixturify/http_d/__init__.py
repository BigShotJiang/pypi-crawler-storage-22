"""HTTP mock decorator for recording and replaying HTTP interactions.

This module provides a test decorator that automatically records HTTP calls
on the first run and replays them on subsequent runs, making tests fast
and deterministic.

Supported HTTP clients:
- httpx (sync and async)
- requests
- urllib3
- http.client (stdlib)
- aiohttp (async)
- httplib2
- tornado (sync and async)
- boto3/botocore (AWS SDK)
- httpcore (low-level, used by httpx)

Example:
    from fixturify.http_d import http

    @http(path="./fixtures/api_calls.json")
    def test_api_integration():
        response = requests.get("https://api.example.com/users")
        assert response.status_code == 200

    # With config for header control
    from fixturify.http_d import http, HttpTestConfig

    config = HttpTestConfig(
        ignore_request_headers=["Authorization"],
        exclude_request_headers=["Authorization", "X-API-Key"],
        exclude_response_headers=["Set-Cookie"],
    )

    @http(path="./fixtures/api.json", config=config)
    def test_with_auth():
        response = requests.get(
            "https://api.example.com/data",
            headers={"Authorization": "Bearer secret"}
        )
        assert response.status_code == 200

    # Or use pytest fixture for auto-discovery
    @pytest.fixture
    def http_config() -> HttpTestConfig:
        return HttpTestConfig(
            ignore_request_headers=["Authorization"],
        )

    @http(path="./fixtures/api.json")  # Config auto-discovered from fixture
    def test_with_fixture_config():
        ...
"""

from fixturify.http_d._config import HttpTestConfig
from fixturify.http_d._decorator import http
from fixturify.http_d._exceptions import (
    HttpMockError,
    NoMatchingRecordingError,
    RequestMismatchError,
    UnusedRecordingsError,
)
from fixturify.http_d._models import HttpMapping, HttpMappings, HttpRequest, HttpResponse

__all__ = [
    # Main decorator
    "http",
    # Configuration
    "HttpTestConfig",
    # Exceptions
    "HttpMockError",
    "NoMatchingRecordingError",
    "RequestMismatchError",
    "UnusedRecordingsError",
    # Models (for advanced usage)
    "HttpRequest",
    "HttpResponse",
    "HttpMapping",
    "HttpMappings",
]
