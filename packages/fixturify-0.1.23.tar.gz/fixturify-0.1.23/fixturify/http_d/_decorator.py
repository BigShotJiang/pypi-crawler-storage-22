"""HTTP mock decorator for recording and playback of HTTP interactions."""

import asyncio
import functools
import inspect
from pathlib import Path
from typing import Any, Callable, Optional, TYPE_CHECKING, TypeVar

from fixturify._utils import _PathResolver

from fixturify.http_d._fixture_discovery import (
    _find_config_from_request,
    _is_pytest_available,
)
from fixturify.http_d._mock_context import HttpMockContext

if TYPE_CHECKING:
    from fixturify.http_d._config import HttpTestConfig


F = TypeVar("F", bound=Callable[..., Any])


def _unwrap_func(func: Callable[..., Any]) -> Callable[..., Any]:
    """Return the original function by walking the __wrapped__ chain."""
    original = func
    while hasattr(original, "__wrapped__"):
        original = original.__wrapped__
    return original


def _get_test_file_path(func: Callable[..., Any]) -> str:
    """Get the test file path from a wrapped function."""
    if hasattr(func, "__pytools_test_file__"):
        result: str = getattr(func, "__pytools_test_file__")
        return result
    return inspect.getfile(_unwrap_func(func))


def http(
    path: str,
    config: Optional["HttpTestConfig"] = None,
    **kwargs: Any,
) -> Callable[[F], F]:
    """
    Decorator for recording and replaying HTTP interactions.

    When the fixture file does not exist, the decorator operates in recording
    mode: real HTTP calls are made through httpx and requests, and the
    request/response pairs are saved to the file.

    When the fixture file exists, the decorator operates in playback mode:
    HTTP calls are intercepted and matched against recorded requests, returning
    the recorded responses without making real network calls.

    Args:
        path: Relative path to JSON file (resolved from test file location).
              The file uses WireMock-compatible JSON format.
        config: HttpTestConfig instance with all settings. If not provided,
               the decorator will look for a pytest fixture named 'http_config'
               returning HttpTestConfig. If no fixture found, uses default config.
        **kwargs: Per-test overrides for HttpTestConfig fields. These are merged
                  with the resolved config (explicit, fixture, or default).
                  List fields (e.g. redact_response_body) are merged additively.
                  Bool fields (e.g. strict_order) override the config value.

    Returns:
        Decorated test function.

    Raises:
        NoMatchingRecordingError: In playback mode, when a request doesn't match
                                  any recording.
        UnusedRecordingsError: In playback mode, when recordings exist that were
                               never matched (after test completes).
        TypeError: If kwargs contain invalid HttpTestConfig field names.

    Example:
        # Simple usage - uses default config
        @http(path="./fixtures/api_calls.json")
        def test_api_integration():
            response = requests.get("https://api.example.com/users")
            assert response.status_code == 200

        # With explicit config
        from fixturify.http_d import HttpTestConfig

        config = HttpTestConfig(
            ignore_request_headers=["Authorization"],
            exclude_request_headers=["Authorization", "X-API-Key"],
            exclude_response_headers=["Set-Cookie"],
        )

        @http(path="./fixtures/api.json", config=config)
        def test_with_auth():
            ...

        # Or use pytest fixture for auto-discovery
        @pytest.fixture
        def http_config() -> HttpTestConfig:
            return HttpTestConfig(
                ignore_request_headers=["Authorization"],
            )

        @http(path="./fixtures/api.json")  # Config auto-discovered from fixture
        def test_with_fixture_config():
            ...

        # Per-test overrides (merged with fixture/explicit config)
        @http(path="./fixtures/api.json", redact_response_body=["token"])
        def test_with_per_test_redaction():
            ...

    Note:
        Supported HTTP clients:
        - httpx.Client (sync)
        - httpx.AsyncClient (async)
        - requests.Session
        - requests.get/post/... (via default session)

        Direct http.client or urllib calls are NOT intercepted.
    """
    # Validate kwargs at decoration time (fail fast)
    if kwargs:
        from fixturify.http_d._config import HttpTestConfig as _Cfg
        invalid_keys = set(kwargs) - _Cfg._VALID_FIELDS
        if invalid_keys:
            raise TypeError(
                f"Invalid HttpTestConfig field(s): {', '.join(sorted(invalid_keys))}. "
                f"Valid fields: {', '.join(sorted(_Cfg._VALID_FIELDS))}"
            )

    needs_fixture_discovery = config is None and _is_pytest_available()
    explicit_config = config

    def decorator(func: F) -> F:
        # Get the test file path at decoration time
        test_file_path = _get_test_file_path(func)

        # Resolve the path (without checking existence - file may not exist yet)
        resolved_path = _PathResolver.resolve_without_check(
            path,
            reference_file=test_file_path,
        )

        # Check if function is async
        is_async = asyncio.iscoroutinefunction(func)

        if is_async:
            wrapper = _create_async_wrapper(
                func,
                resolved_path,
                explicit_config,
                needs_fixture_discovery,
                kwargs,
            )
        else:
            wrapper = _create_sync_wrapper(
                func,
                resolved_path,
                explicit_config,
                needs_fixture_discovery,
                kwargs,
            )

        # Preserve function metadata
        functools.update_wrapper(wrapper, func)
        wrapper.__pytools_test_file__ = test_file_path  # type: ignore
        wrapper.__pytools_wrapper__ = True  # type: ignore

        # If we need fixture discovery, add 'request' to signature
        if needs_fixture_discovery:
            wrapper = _add_request_parameter(wrapper, func)

        return wrapper  # type: ignore

    return decorator


def _add_request_parameter(
    wrapper: Callable[..., Any],
    original_func: Callable[..., Any],
) -> Callable[..., Any]:
    """
    Add 'request' parameter to wrapper's signature for pytest fixture injection.

    Pytest inspects function signatures to determine which fixtures to inject.
    By adding 'request' to the signature, pytest will inject the FixtureRequest
    object, which we can use to discover HttpTestConfig fixtures.
    """
    if hasattr(wrapper, "__signature__"):
        sig = getattr(wrapper, "__signature__")
    else:
        sig = inspect.signature(original_func)

    # Check if 'request' is already in the signature
    if "request" in sig.parameters:
        return wrapper

    # Create new signature with 'request' added as keyword-only parameter
    new_params = list(sig.parameters.values())
    request_param = inspect.Parameter(
        "request",
        inspect.Parameter.KEYWORD_ONLY,
    )
    new_params.append(request_param)
    new_sig = sig.replace(parameters=new_params)

    # Set the new signature on the wrapper
    wrapper.__signature__ = new_sig  # type: ignore

    return wrapper


def _resolve_config(
    explicit_config: Optional["HttpTestConfig"],
    request: Any = None,
) -> "HttpTestConfig":
    """
    Resolve HTTP configuration.

    Priority:
    1. Explicit config parameter
    2. Pytest fixture discovery via request
    3. Default config
    """
    from ._config import HttpTestConfig

    # 1. Use explicit config if provided
    if explicit_config is not None:
        return explicit_config

    # 2. Try fixture discovery via request
    if request is not None:
        discovered_config = _find_config_from_request(request)
        if discovered_config is not None:
            return discovered_config

    # 3. Return default config
    return HttpTestConfig()


def _create_sync_wrapper(
    func: Callable[..., Any],
    resolved_path: Path,
    explicit_config: Optional["HttpTestConfig"],
    needs_fixture_discovery: bool,
    config_overrides: dict,
) -> Callable[..., Any]:
    """Create wrapper for sync test functions."""

    def wrapper(*args: Any, **kwargs: Any) -> Any:
        # Extract and propagate request for stacked decorators
        request = kwargs.pop("request", None)
        if request is None:
            request = kwargs.pop("_pytools_request", None)

        if getattr(func, "__pytools_wrapper__", False) and request is not None:
            kwargs["_pytools_request"] = request

        # Resolve config
        config = _resolve_config(explicit_config, request) if needs_fixture_discovery else _resolve_config(explicit_config)

        # Apply per-test overrides
        if config_overrides:
            config = config.merge(config_overrides)

        with HttpMockContext(resolved_path, config):
            return func(*args, **kwargs)

    return wrapper


def _create_async_wrapper(
    func: Callable[..., Any],
    resolved_path: Path,
    explicit_config: Optional["HttpTestConfig"],
    needs_fixture_discovery: bool,
    config_overrides: dict,
) -> Callable[..., Any]:
    """Create wrapper for async test functions."""

    async def wrapper(*args: Any, **kwargs: Any) -> Any:
        # Extract and propagate request for stacked decorators
        request = kwargs.pop("request", None)
        if request is None:
            request = kwargs.pop("_pytools_request", None)

        if getattr(func, "__pytools_wrapper__", False) and request is not None:
            kwargs["_pytools_request"] = request

        # Resolve config
        config = _resolve_config(explicit_config, request) if needs_fixture_discovery else _resolve_config(explicit_config)

        # Apply per-test overrides
        if config_overrides:
            config = config.merge(config_overrides)

        with HttpMockContext(resolved_path, config):
            return await func(*args, **kwargs)

    return wrapper
