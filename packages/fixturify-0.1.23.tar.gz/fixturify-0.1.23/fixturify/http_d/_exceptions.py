"""Custom exceptions for HTTP mock decorator."""

import json
from typing import Any, Dict, List, Optional

from fixturify.http_d._config import DEFAULT_IGNORE_HEADERS
from fixturify.http_d._models import HttpMapping, HttpRequest


def _to_compact_json(data: Any) -> str:
    """Convert data to compact single-line JSON for easy copying from console."""
    if data is None:
        return "<empty>"
    if isinstance(data, str):
        try:
            parsed = json.loads(data)
            return json.dumps(parsed, ensure_ascii=False, separators=(",", ":"))
        except (json.JSONDecodeError, TypeError):
            return data
    try:
        return json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    except (TypeError, ValueError):
        return str(data)


def _format_headers(headers: Dict[str, str], prefix: str = "    ") -> str:
    """Format headers as compact single-line JSON for easy copying from console."""
    if not headers:
        return f"{prefix}<no headers>"
    return f"{prefix}{json.dumps(dict(sorted(headers.items())), ensure_ascii=False, separators=(',', ':'))}"


def _format_body(body: Optional[str], prefix: str = "    ") -> str:
    """Format body as compact single-line JSON for easy copying from console."""
    if not body:
        return f"{prefix}<empty>"
    return f"{prefix}{_to_compact_json(body)}"


class HttpMockError(Exception):
    """Base exception for HTTP mock errors."""

    pass


class NoMatchingRecordingError(HttpMockError):
    """
    Raised when a request is made but no recording matches.

    This occurs during playback mode when an HTTP call is made that
    doesn't match any of the recorded request/response pairs.
    """

    def __init__(
        self,
        request: HttpRequest,
        available_mappings: Optional[List[HttpMapping]] = None,
        message: Optional[str] = None,
    ):
        self.request = request
        self.available_mappings = available_mappings or []

        if message is None:
            message = self._build_message()

        super().__init__(message)

    def _build_message(self) -> str:
        """Build a detailed error message."""
        lines = [
            "",
            "=" * 70,
            "NO MATCHING RECORDING FOUND",
            "=" * 70,
            "",
            "ACTUAL REQUEST:",
            "-" * 40,
            f"  Method: {self.request.method}",
            f"  URL:    {self.request.url}",
        ]

        if self.request.queryParameters:
            lines.append("")
            lines.append("  Query Parameters:")
            for key, value in self.request.queryParameters.items():
                lines.append(f"    {key}: {value}")

        if self.request.headers:
            # Filter out default ignored headers
            relevant_headers = {
                k: v
                for k, v in self.request.headers.items()
                if k.lower() not in DEFAULT_IGNORE_HEADERS
            }
            if relevant_headers:
                lines.append("")
                lines.append("  Headers:")
                lines.append(_format_headers(relevant_headers, prefix="    "))

        if self.request.body:
            lines.append("")
            lines.append("  Body:")
            lines.append(_format_body(self.request.body, prefix="    "))

        if self.available_mappings:
            lines.append("")
            lines.append("-" * 70)
            lines.append(f"AVAILABLE RECORDINGS ({len(self.available_mappings)}):")
            lines.append("-" * 40)
            for i, mapping in enumerate(self.available_mappings[:10]):
                req = mapping.request
                lines.append(f"  [{i + 1}] {req.method} {req.url}")
                if req.queryParameters:
                    lines.append(f"      Query:   {_to_compact_json(req.queryParameters)}")
                relevant = {
                    k: v
                    for k, v in req.headers.items()
                    if k.lower() not in DEFAULT_IGNORE_HEADERS
                } if req.headers else {}
                if relevant:
                    lines.append(f"      Headers: {_to_compact_json(relevant)}")
                if req.body:
                    lines.append(f"      Body:    {_to_compact_json(req.body)}")
            if len(self.available_mappings) > 10:
                lines.append(f"  ... and {len(self.available_mappings) - 10} more")

        lines.append("")
        lines.append("=" * 70)
        return "\n".join(lines)


class UnusedRecordingsError(HttpMockError):
    """
    Raised when recorded mappings were never matched during playback.

    This indicates that the test's HTTP behavior has changed - it no longer
    makes certain calls that were previously recorded.
    """

    def __init__(
        self,
        unused_mappings: List[HttpMapping],
        message: Optional[str] = None,
    ):
        self.unused_mappings = unused_mappings

        if message is None:
            message = self._build_message()

        super().__init__(message)

    def _build_message(self) -> str:
        """Build a detailed error message."""
        lines = [
            "",
            "=" * 70,
            f"UNUSED RECORDINGS ({len(self.unused_mappings)})",
            "=" * 70,
            "",
            "The following recorded HTTP calls were never made during the test:",
            "",
        ]

        for i, mapping in enumerate(self.unused_mappings):
            req = mapping.request
            lines.append(f"  [{i + 1}] {req.method} {req.url}")
            if req.queryParameters:
                lines.append(f"      Query: {req.queryParameters}")
            if req.body:
                body_preview = req.body[:80] if isinstance(req.body, str) else str(req.body)[:80]
                if len(str(req.body)) > 80:
                    body_preview += "..."
                lines.append(f"      Body:  {body_preview}")

        lines.append("")
        lines.append("-" * 70)
        lines.append("POSSIBLE CAUSES:")
        lines.append("-" * 40)
        lines.append("  - Business logic changed and no longer makes these calls")
        lines.append("  - Recording file is out of date (re-record fixtures)")
        lines.append("  - A bug in the application that skips expected HTTP calls")
        lines.append("")
        lines.append("=" * 70)

        return "\n".join(lines)


class RequestMismatchError(HttpMockError):
    """
    Raised when a request partially matches but has differences.

    This provides detailed information about what matched and what didn't,
    helping developers understand why a recording wasn't used.
    """

    def __init__(
        self,
        actual_request: HttpRequest,
        expected_request: HttpRequest,
        mismatches: Dict[str, Any],
        message: Optional[str] = None,
    ):
        self.actual_request = actual_request
        self.expected_request = expected_request
        self.mismatches = mismatches

        if message is None:
            message = self._build_message()

        super().__init__(message)

    def _build_message(self) -> str:
        """Build a detailed error message."""
        lines = [
            "",
            "=" * 70,
            "REQUEST MISMATCH",
            "=" * 70,
            "",
            f"URL: {self.actual_request.url}",
            "",
            "-" * 70,
            "DIFFERENCES FOUND:",
            "-" * 40,
        ]

        for field, (actual, expected) in self.mismatches.items():
            lines.append("")
            lines.append(f"  {field.upper()}:")
            if field == "body":
                lines.append(f"    Expected: {_to_compact_json(expected)}")
                lines.append(f"    Actual:   {_to_compact_json(actual)}")
            elif field == "headers":
                lines.append(_format_headers(expected or {}, prefix="    Expected: "))
                lines.append(_format_headers(actual or {}, prefix="    Actual:   "))
            else:
                lines.append(f"    Expected: {expected}")
                lines.append(f"    Actual:   {actual}")

        lines.append("")
        lines.append("=" * 70)
        return "\n".join(lines)
