"""Pytest fixture discovery for HttpTestConfig."""

from typing import TYPE_CHECKING, Optional

from fixturify._utils._fixture_discovery import (
    find_fixture_by_type,
    is_pytest_available as _is_pytest_available,
)
from fixturify.http_d._config import HttpTestConfig

if TYPE_CHECKING:
    from _pytest.fixtures import FixtureRequest


def _find_config_from_request(request: "FixtureRequest") -> Optional[HttpTestConfig]:
    """
    Find HttpTestConfig fixture using pytest's request object.

    Scans ALL available fixtures (not just function dependencies) for fixtures
    that return HttpTestConfig. This allows defining the config fixture in
    conftest.py without needing to add it as a test parameter.

    Args:
        request: Pytest's FixtureRequest object

    Returns:
        HttpTestConfig if a matching fixture is found, None otherwise
    """
    return find_fixture_by_type(request, HttpTestConfig)


# Re-export for backward compatibility
_is_pytest_available = _is_pytest_available
