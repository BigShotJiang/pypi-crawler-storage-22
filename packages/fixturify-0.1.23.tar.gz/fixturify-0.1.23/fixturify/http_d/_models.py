"""WireMock-compatible data models for HTTP recording and playback."""

import base64
import json
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class HttpRequest:
    """
    Represents an HTTP request in WireMock format.

    Attributes:
        method: HTTP method (GET, POST, PUT, DELETE, etc.)
        url: Full URL including scheme and host
        headers: Request headers as dict
        queryParameters: Query parameters as dict
        body: Request body (string or None)
        bodyEncoding: Encoding for binary bodies ('base64' or None for text)
    """

    method: str
    url: str
    headers: Dict[str, str] = field(default_factory=dict)
    queryParameters: Dict[str, str] = field(default_factory=dict)
    body: Optional[str] = None
    bodyEncoding: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        result: Dict[str, Any] = {
            "method": self.method.upper(),
            "url": self.url,
            "headers": self.headers,
            "queryParameters": self.queryParameters,
        }
        if self.body is not None:
            result["body"] = self.body
        if self.bodyEncoding is not None:
            result["bodyEncoding"] = self.bodyEncoding
        return result

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "HttpRequest":
        """Create from dictionary."""
        return cls(
            method=data.get("method", "GET"),
            url=data.get("url", ""),
            headers=data.get("headers", {}),
            queryParameters=data.get("queryParameters", {}),
            body=data.get("body"),
            bodyEncoding=data.get("bodyEncoding"),
        )


@dataclass
class HttpResponse:
    """
    Represents an HTTP response in WireMock format.

    Attributes:
        status: HTTP status code
        headers: Response headers as dict
        body: Response body (string or None if using bodyFileName)
        bodyFileName: Optional filename for binary content (stored separately)
        bodyEncoding: Encoding for inline binary bodies ('base64' or None for text)
    """

    status: int
    headers: Dict[str, str] = field(default_factory=dict)
    body: Optional[str] = ""
    bodyFileName: Optional[str] = None
    bodyEncoding: Optional[str] = None
    # Runtime field: actual bytes loaded from file (not serialized)
    _body_bytes: Optional[bytes] = field(default=None, repr=False)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        result: Dict[str, Any] = {
            "status": self.status,
            "headers": self.headers,
        }
        if self.bodyFileName is not None:
            result["bodyFileName"] = self.bodyFileName
        else:
            result["body"] = self.body if self.body is not None else ""
        if self.bodyEncoding is not None:
            result["bodyEncoding"] = self.bodyEncoding
        return result

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "HttpResponse":
        """Create from dictionary."""
        return cls(
            status=data.get("status", 200),
            headers=data.get("headers", {}),
            body=data.get("body", ""),
            bodyFileName=data.get("bodyFileName"),
            bodyEncoding=data.get("bodyEncoding"),
        )

    def get_body_bytes(self) -> bytes:
        """
        Get response body as bytes, handling base64 encoding and file references.

        Returns:
            Response body as bytes

        Note:
            If bodyFileName is used, _body_bytes must be set by the player
            after loading the file.
        """
        # If body was loaded from file
        if self._body_bytes is not None:
            return self._body_bytes

        # If using base64 encoding
        if self.bodyEncoding == "base64" and self.body:
            return base64.b64decode(self.body)

        # Regular text body
        return (self.body or "").encode("utf-8")

    def set_body_bytes(self, data: bytes) -> None:
        """Set body bytes (used when loading from file)."""
        self._body_bytes = data


@dataclass
class HttpMapping:
    """
    Represents a request-response mapping in WireMock format.

    Attributes:
        request: The HTTP request
        response: The HTTP response
    """

    request: HttpRequest
    response: HttpResponse

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "request": self.request.to_dict(),
            "response": self.response.to_dict(),
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "HttpMapping":
        """Create from dictionary."""
        return cls(
            request=HttpRequest.from_dict(data.get("request", {})),
            response=HttpResponse.from_dict(data.get("response", {})),
        )


@dataclass
class HttpMappings:
    """
    Container for multiple HTTP mappings in WireMock format.

    The JSON structure is:
    {
        "mappings": [
            { "request": {...}, "response": {...} },
            ...
        ]
    }
    """

    mappings: List[HttpMapping] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {"mappings": [m.to_dict() for m in self.mappings]}

    def to_json(self, indent: int = 2) -> str:
        """Convert to JSON string."""
        return json.dumps(self.to_dict(), indent=indent, ensure_ascii=False)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "HttpMappings":
        """Create from dictionary."""
        mappings_data = data.get("mappings", [])
        return cls(mappings=[HttpMapping.from_dict(m) for m in mappings_data])

    @classmethod
    def from_json(cls, json_str: str) -> "HttpMappings":
        """Create from JSON string."""
        data = json.loads(json_str)
        return cls.from_dict(data)

    def add(self, mapping: HttpMapping) -> None:
        """Add a mapping."""
        self.mappings.append(mapping)

    def __len__(self) -> int:
        """Return number of mappings."""
        return len(self.mappings)

    def __iter__(self):
        """Iterate over mappings."""
        return iter(self.mappings)
