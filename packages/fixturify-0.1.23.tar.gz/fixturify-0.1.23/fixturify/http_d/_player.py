"""Playback logic for HTTP mock responses."""

import json
from pathlib import Path
from typing import Any, List, Optional, Set, TYPE_CHECKING

from fixturify._utils import ENCODING

from fixturify.http_d._exceptions import (
    NoMatchingRecordingError,
    RequestMismatchError,
    UnusedRecordingsError,
)
from fixturify.http_d._matcher import RequestMatcher
from fixturify.http_d._models import HttpMapping, HttpRequest, HttpResponse

if TYPE_CHECKING:
    from fixturify.http_d._config import HttpTestConfig


# Directory name for binary response files (WireMock convention)
FILES_DIR = "__files"


def _deserialize_body(body: Any) -> Optional[str]:
    """
    Deserialize body from JSON storage format to string.

    If body is a dict/list (native JSON), serialize it back to string.
    If body is already a string, return as-is.
    If body is None, return None.

    Args:
        body: Body value from JSON file (could be dict, list, string, or None)

    Returns:
        Body as string (or None)
    """
    if body is None:
        return None
    if isinstance(body, str):
        return body
    # For dict/list, serialize back to JSON string
    return json.dumps(body, ensure_ascii=False)


class HttpPlayer:
    """
    Plays back recorded HTTP responses during tests.

    Matches incoming requests against recorded request/response pairs
    and returns the appropriate recorded response. Supports loading
    binary response bodies from external files.
    """

    def __init__(
        self,
        file_path: Path,
        config: Optional["HttpTestConfig"] = None,
        ignore_headers: Optional[List[str]] = None,
        match_body: bool = True,
        strict_order: bool = False,
    ):
        """
        Initialize the player.

        Args:
            file_path: Path to the recordings JSON file.
            config: HttpTestConfig instance with matching settings.
                   If provided, other parameters are ignored.
            ignore_headers: Additional headers to ignore during matching.
                           (Deprecated: use config instead)
            match_body: Whether to include body in matching.
                       (Deprecated: use config instead)
            strict_order: Whether requests must match in recorded order.
                         (Deprecated: use config instead)
        """
        self.file_path = file_path
        self.files_dir = file_path.parent / FILES_DIR
        self.matcher = RequestMatcher(
            config=config,
            ignore_headers=ignore_headers,
            match_body=match_body,
            strict_order=strict_order,
        )

        # Load mappings
        self.mappings: List[HttpMapping] = []
        self._load_mappings()

        # Track which mappings have been used
        self.used_indices: Set[int] = set()

    def _load_body_file(self, filename: str) -> bytes:
        """
        Load body content from a file in the __files directory.

        Args:
            filename: Name of the file (not full path)

        Returns:
            File contents as bytes

        Raises:
            FileNotFoundError: If the file doesn't exist
        """
        file_path = self.files_dir / filename
        if not file_path.exists():
            raise FileNotFoundError(
                f"Body file not found: {file_path}. "
                f"Referenced in recording but missing from {FILES_DIR}/ directory."
            )

        with open(file_path, "rb") as f:
            return f.read()

    def _load_mappings(self) -> None:
        """Load mappings from the JSON file."""
        with open(self.file_path, "r", encoding=ENCODING) as f:
            data = json.load(f)

        # Parse mappings, converting native JSON bodies to strings
        mappings_data = data.get("mappings", [])
        for mapping_data in mappings_data:
            req_data = mapping_data.get("request", {})
            resp_data = mapping_data.get("response", {})

            # Deserialize request body (convert JSON objects back to strings)
            req_body = _deserialize_body(req_data.get("body"))

            request = HttpRequest(
                method=req_data.get("method", "GET"),
                url=req_data.get("url", ""),
                headers=req_data.get("headers", {}),
                queryParameters=req_data.get("queryParameters", {}),
                body=req_body,
                bodyEncoding=req_data.get("bodyEncoding"),
            )

            # Handle response body - could be inline or file reference
            body_filename = resp_data.get("bodyFileName")

            if body_filename:
                # Binary body stored in external file
                response = HttpResponse(
                    status=resp_data.get("status", 200),
                    headers=resp_data.get("headers", {}),
                    body=None,
                    bodyFileName=body_filename,
                )
                # Load the file content
                response.set_body_bytes(self._load_body_file(body_filename))
            else:
                # Inline body
                resp_body = _deserialize_body(resp_data.get("body"))
                response = HttpResponse(
                    status=resp_data.get("status", 200),
                    headers=resp_data.get("headers", {}),
                    body=resp_body if resp_body is not None else "",
                    bodyEncoding=resp_data.get("bodyEncoding"),
                )

            self.mappings.append(HttpMapping(request=request, response=response))

    def _find_closest_mismatch(
        self, request: HttpRequest
    ) -> Optional[RequestMismatchError]:
        """
        Find the closest matching recording and return a RequestMismatchError.

        Looks for recordings where method and URL match but other fields differ.
        This provides much more useful error messages than a generic
        NoMatchingRecordingError.
        """
        for i, mapping in enumerate(self.mappings):
            if i in self.used_indices:
                continue
            expected = mapping.request
            # Method and URL match — this is a "close" match
            if (
                request.method.upper() == expected.method.upper()
                and self.matcher._urls_match(request.url, expected.url)
            ):
                mismatches = self.matcher.get_mismatch_details(request, expected)
                if mismatches:
                    return RequestMismatchError(
                        actual_request=request,
                        expected_request=expected,
                        mismatches=mismatches,
                    )
        return None

    def find_response(self, request: HttpRequest) -> HttpResponse:
        """
        Find and return the recorded response for a request.

        Args:
            request: The incoming HTTP request.

        Returns:
            The matching recorded response.

        Raises:
            RequestMismatchError: If a recording with matching method+URL exists
                but other fields (body, headers, query params) differ.
            NoMatchingRecordingError: If no recording matches the request at all.
        """
        result = self.matcher.find_match(request, self.mappings, self.used_indices)

        if result is None:
            # Try to find a close match for a better error message
            mismatch_error = self._find_closest_mismatch(request)
            if mismatch_error is not None:
                raise mismatch_error

            raise NoMatchingRecordingError(
                request=request,
                available_mappings=self.mappings,
            )

        index, mapping = result
        self.used_indices.add(index)

        return mapping.response

    def verify_all_used(self) -> None:
        """
        Verify that all recordings were used.

        Raises:
            UnusedRecordingsError: If any recordings were not matched.
        """
        unused = [
            mapping
            for i, mapping in enumerate(self.mappings)
            if i not in self.used_indices
        ]

        if unused:
            raise UnusedRecordingsError(unused_mappings=unused)

    def get_unused_mappings(self) -> List[HttpMapping]:
        """
        Get list of recordings that haven't been used.

        Returns:
            List of unused HttpMapping objects.
        """
        return [
            mapping
            for i, mapping in enumerate(self.mappings)
            if i not in self.used_indices
        ]

    def reset(self) -> None:
        """Reset usage tracking (for reuse across multiple tests)."""
        self.used_indices.clear()

    def __len__(self) -> int:
        """Return number of loaded mappings."""
        return len(self.mappings)
