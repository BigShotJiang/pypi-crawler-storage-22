"""HTTP client stubs for mocking."""

from ._connection import MockHTTPConnection, MockHTTPSConnection

__all__ = [
    "MockHTTPConnection",
    "MockHTTPSConnection",
]
