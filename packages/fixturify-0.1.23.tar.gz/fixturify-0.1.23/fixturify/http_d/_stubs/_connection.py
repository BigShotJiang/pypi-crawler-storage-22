"""Mock HTTP connection classes for http.client patching.

These classes replace http.client.HTTPConnection and HTTPSConnection
to intercept all HTTP traffic that goes through the stdlib.

Most HTTP libraries (requests, urllib3, httplib2) use http.client
under the hood, so patching at this level covers them automatically.
"""

import http.client
from contextlib import suppress
from http.client import HTTPConnection, HTTPResponse, HTTPSConnection
from io import BytesIO
from typing import Any, Dict, Optional, TYPE_CHECKING

from .._models import HttpRequest, HttpResponse as HttpResponseModel
from .._recorder import (
    create_request_from_http_client,
    create_response_from_http_client,
)

if TYPE_CHECKING:
    from .._mock_context import HttpMockContext


class MockHTTPResponse(HTTPResponse):
    """
    Mock HTTP response that doesn't require a real socket.
    
    Used to return recorded responses during playback mode.
    """
    
    def __init__(self, response_model: HttpResponseModel):
        """
        Initialize from an HttpResponse model.
        
        Args:
            response_model: The recorded response data
        """
        self.fp = None  # type: ignore[assignment]
        self._response_model = response_model
        body_bytes = response_model.get_body_bytes()
        
        self.status = self.code = response_model.status
        self.reason = self._get_reason_phrase(response_model.status)
        self.version = 11  # HTTP/1.1
        self.version_string = "HTTP/1.1"  # urllib3 compatibility
        self._content = BytesIO(body_bytes)
        self._closed = False
        self._original_response = self
        
        # urllib3 specific
        self.chunked = False
        self.will_close = True
        self.length_remaining = 0  # Already fully read
        self._decoder = None
        
        # Parse headers
        self.headers = self.msg = self._build_headers(response_model.headers)
        
        # Calculate length
        content_length = response_model.headers.get(
            "content-length", 
            response_model.headers.get("Content-Length")
        )
        if content_length:
            try:
                self.length = int(content_length)
            except ValueError:
                self.length = len(body_bytes)
        else:
            self.length = len(body_bytes)
    
    @staticmethod
    def _get_reason_phrase(status: int) -> str:
        """Get HTTP reason phrase for status code."""
        from http import HTTPStatus
        try:
            return HTTPStatus(status).phrase
        except ValueError:
            return "Unknown"
    
    @staticmethod
    def _build_headers(headers_dict: Dict[str, str]) -> http.client.HTTPMessage:
        """Build HTTPMessage from headers dict."""
        from email.message import Message
        msg = Message()
        for key, value in headers_dict.items():
            msg[key] = value
        return msg  # type: ignore[return-value]

    @property
    def closed(self) -> bool:  # type: ignore[override]
        return self._closed

    def read(self, amt: Optional[int] = None) -> bytes:
        return self._content.read(amt)

    def read1(self, amt: Optional[int] = None) -> bytes:
        return self._content.read(amt)

    def readinto(self, b: Any) -> int:
        return self._content.readinto(b)

    def readline(self, limit: int = -1) -> bytes:  # type: ignore[override]
        return self._content.readline(limit)

    def readlines(self, hint: int = -1) -> list[bytes]:
        return self._content.readlines(hint)

    def close(self) -> None:
        self._closed = True

    def isclosed(self) -> bool:
        return self._closed

    def getcode(self) -> int:
        return self.status

    def info(self) -> Any:
        return self.headers

    def getheaders(self) -> list[tuple[str, str]]:
        return list(self._response_model.headers.items())

    def getheader(self, name: str, default: Any = None) -> Optional[str]:  # type: ignore[override]
        result = self._response_model.headers.get(
            name,
            self._response_model.headers.get(name.lower(), default)
        )
        return str(result) if result is not None else None
    
    def readable(self) -> bool:
        return self._content.readable()
    
    def seekable(self) -> bool:
        return self._content.seekable()
    
    def tell(self) -> int:
        return self._content.tell()
    
    def seek(self, pos: int, whence: int = 0) -> int:
        return self._content.seek(pos, whence)
    
    @property
    def data(self) -> bytes:
        """Return full response body (for urllib3 compatibility)."""
        return self._content.getvalue()
    
    def drain_conn(self) -> None:
        """Drain connection (no-op for mock)."""
        pass
    
    def get_redirect_location(self) -> Optional[str]:
        """Get redirect location from response headers."""
        # Check for redirect status codes
        if 300 <= self.status < 400:
            return self._response_model.headers.get(
                "location",
                self._response_model.headers.get("Location")
            )
        return None
    
    def release_conn(self) -> None:
        """Release connection back to pool (no-op for mock)."""
        pass
    
    def retries(self) -> None:
        """Get retry info (not applicable for mock)."""
        return None
    
    def stream(self, amt: int = 65536, decode_content=None):
        """Stream response body in chunks."""
        while True:
            chunk = self._content.read(amt)
            if not chunk:
                break
            yield chunk


class MockFakeSocket:
    """Fake socket that does nothing (used when no real connection is needed)."""
    
    def close(self):
        pass
    
    def settimeout(self, *args, **kwargs):
        pass
    
    def fileno(self):
        return 0


class MockConnection:
    """
    Base class for mock HTTP connections.
    
    This class intercepts HTTP requests and either:
    - Returns recorded responses (playback mode)
    - Makes real requests and records them (record mode)
    
    The mock_context attribute is set dynamically via subclassing
    in PatcherBuilder._get_stub_with_context().
    """
    
    # Set via dynamic subclass creation
    mock_context: Optional["HttpMockContext"] = None

    # Override in subclasses
    _base_class: Optional[type] = None
    _protocol = "http"
    
    def __init__(self, host, port=None, timeout=None, **kwargs):
        """Initialize the mock connection."""
        # Remove urllib3-specific parameters not supported by http.client
        kwargs.pop("strict", None)  # Python 2 legacy
        kwargs.pop("cert_file", None)
        kwargs.pop("key_file", None)
        kwargs.pop("cert_reqs", None)
        kwargs.pop("ca_certs", None)
        kwargs.pop("ca_cert_dir", None)
        kwargs.pop("ca_cert_data", None)
        kwargs.pop("ssl_context", None)
        kwargs.pop("ssl_version", None)
        kwargs.pop("server_hostname", None)
        kwargs.pop("assert_hostname", None)
        kwargs.pop("assert_fingerprint", None)
        kwargs.pop("socket_options", None)
        kwargs.pop("proxy", None)
        kwargs.pop("proxy_config", None)
        kwargs.pop("blocksize", None)
        kwargs.pop("_http2_probe", None)
        kwargs.pop("_http2", None)
        
        # Create real connection with patches temporarily disabled
        from .._patcher import force_reset
        with force_reset():
            if self._base_class is None:
                raise RuntimeError("_base_class not set")
            self._real_conn = self._base_class(host, port=port, timeout=timeout)
        
        # Storage for pending request (between request() and getresponse())
        self._pending_request: Optional[HttpRequest] = None
        self._sock = None
    
    def _port_suffix(self) -> str:
        """Get port suffix for URL (empty string for default ports)."""
        port = self._real_conn.port
        default_port = {"https": 443, "http": 80}[self._protocol]
        return f":{port}" if port != default_port else ""
    
    def _build_uri(self, url: str) -> str:
        """Build full URI from request URL."""
        if url.startswith(("http://", "https://")):
            return url
        host = self._real_conn.host
        return f"{self._protocol}://{host}{self._port_suffix()}{url}"
    
    def _url_path(self, uri: str) -> str:
        """Extract path from full URI for real connection."""
        prefix = f"{self._protocol}://{self._real_conn.host}{self._port_suffix()}"
        return uri.replace(prefix, "", 1) or "/"
    
    def request(self, method: str, url: str, body=None, headers=None, **kwargs) -> None:
        """
        Store request data for processing in getresponse().
        
        The actual request is deferred until getresponse() is called,
        allowing us to check for recorded responses first.
        """
        # Normalize headers (convert bytes keys/values to strings)
        headers_dict: Dict[str, str] = {}
        if headers:
            for k, v in (headers.items() if hasattr(headers, "items") else headers):
                key = k.decode("utf-8") if isinstance(k, bytes) else str(k)
                val = v.decode("utf-8") if isinstance(v, bytes) else str(v)
                headers_dict[key] = val
        
        # Build full URL
        uri = self._build_uri(url)
        
        # Store request for getresponse()
        self._pending_request = create_request_from_http_client(
            method=method,
            url=uri,
            body=body,
            headers=headers_dict,
        )
        
        # Set fake socket for playback mode
        self._sock = MockFakeSocket()
    
    def putrequest(self, method: str, url: str, *args, **kwargs) -> None:
        """Start building a request (alternative API)."""
        self._pending_request = create_request_from_http_client(
            method=method,
            url=self._build_uri(url),
            body=None,
            headers={},
        )
    
    def putheader(self, header: str, *values) -> None:
        """Add header to pending request."""
        if self._pending_request:
            self._pending_request.headers[header] = ", ".join(str(v) for v in values)
    
    def endheaders(self, message_body=None, **kwargs) -> None:
        """Finish headers (body may be provided here)."""
        if message_body is not None and self._pending_request:
            self._pending_request.body = message_body
    
    def send(self, data) -> None:
        """Append data to request body."""
        if self._pending_request:
            current = self._pending_request.body or b""
            if isinstance(current, str):
                current = current.encode()
            if isinstance(data, str):
                data = data.encode()
            self._pending_request.body = current + data
    
    def getresponse(self) -> MockHTTPResponse:
        """
        Get response for the pending request.
        
        Either returns a recorded response (playback) or makes
        a real request and records it (record mode).
        """
        req = self._pending_request
        
        if req is None:
            raise RuntimeError("No pending request - call request() first")
        
        # Check if we should skip mocking (excluded host)
        if self.mock_context and self.mock_context.is_host_excluded(req.url):
            real_response = self._make_real_request_and_return()
            return MockHTTPResponse(create_response_from_http_client(real_response))
        
        # In playback mode, try to get the recorded response
        # This will raise NoMatchingRecordingError if not found
        if self.mock_context and self.mock_context.mode == "playback":
            response = self.mock_context.play_response(req)
            self._pending_request = None
            return MockHTTPResponse(response)
        
        # Record mode - make real request
        return self._make_real_request_and_record()
    
    def _make_real_request_and_return(self) -> HTTPResponse:
        """Make real request without recording (for excluded hosts)."""
        from .._patcher import force_reset

        req = self._pending_request
        if req is None:
            raise RuntimeError("No pending request")
        self._pending_request = None

        with force_reset():
            self._real_conn.request(
                method=req.method,
                url=self._url_path(req.url),
                body=req.body,
                headers=req.headers,
            )
            result: HTTPResponse = self._real_conn.getresponse()
            return result

    def _make_real_request_and_record(self) -> MockHTTPResponse:
        """Make real request and record the response."""
        from .._patcher import force_reset

        req = self._pending_request
        if req is None:
            raise RuntimeError("No pending request")
        self._pending_request = None

        with force_reset():
            self._real_conn.request(
                method=req.method,
                url=self._url_path(req.url),
                body=req.body,
                headers=req.headers,
            )
            real_response = self._real_conn.getresponse()

        # Create response model from real response
        resp_model = create_response_from_http_client(real_response)

        # Record the interaction
        if self.mock_context:
            self.mock_context.record(req, resp_model)

        return MockHTTPResponse(resp_model)
    
    def close(self) -> None:
        """Close the connection."""
        self._real_conn.close()
    
    @property
    def is_closed(self) -> bool:
        """Check if connection is closed."""
        return self._real_conn.sock is None
    
    @property
    def proxy(self):
        """Return proxy info (for urllib3 compatibility)."""
        return getattr(self._real_conn, "proxy", None)
    
    @property
    def proxy_is_verified(self):
        """Return proxy verification status."""
        return getattr(self._real_conn, "proxy_is_verified", None)
    
    def connect(self, *args, **kwargs):
        """
        Connect to the server.
        
        In playback mode, we don't actually connect - we'll return
        recorded responses later. In record mode, we need to connect.
        """
        # In playback mode, don't actually connect
        if self.mock_context and self.mock_context.mode == "playback":
            # Set a fake socket so is_closed returns False
            self._sock = MockFakeSocket()
            return
        
        # Record mode - need to make real connection
        from .._patcher import force_reset
        with force_reset():
            return self._real_conn.connect(*args, **kwargs)
    
    def set_debuglevel(self, *args, **kwargs):
        self._real_conn.set_debuglevel(*args, **kwargs)
    
    @property
    def sock(self):
        if self._real_conn.sock:
            return self._real_conn.sock
        return self._sock
    
    @sock.setter
    def sock(self, value):
        if self._real_conn.sock:
            self._real_conn.sock = value
    
    def __setattr__(self, name: str, value: Any) -> None:
        """Propagate attribute changes to real connection."""
        # Skip for our internal attributes
        if name in ("_real_conn", "_pending_request", "_sock", "mock_context"):
            super().__setattr__(name, value)
            return
        
        # Try to set on real connection too
        with suppress(AttributeError):
            if hasattr(self, "_real_conn"):
                setattr(self._real_conn, name, value)
        
        super().__setattr__(name, value)
    
    def __getattr__(self, name: str) -> Any:
        """Forward unknown attributes to real connection."""
        if "_real_conn" in self.__dict__:
            return getattr(self._real_conn, name)
        raise AttributeError(f"'{type(self).__name__}' has no attribute '{name}'")


class MockHTTPConnection(MockConnection):
    """Mock for http.client.HTTPConnection (HTTP)."""
    _base_class: type = HTTPConnection
    _protocol = "http"
    debuglevel = HTTPConnection.debuglevel
    _http_vsn = getattr(HTTPConnection, "_http_vsn", 11)


class MockHTTPSConnection(MockConnection):
    """Mock for http.client.HTTPSConnection (HTTPS)."""
    _base_class: type = HTTPSConnection
    _protocol = "https"
    is_verified = True
    debuglevel = HTTPSConnection.debuglevel
    _http_vsn = getattr(HTTPSConnection, "_http_vsn", 11)


# Copy static methods from HTTPConnection
for name, method in HTTPConnection.__dict__.items():
    if isinstance(method, staticmethod):
        setattr(MockConnection, name, method)
