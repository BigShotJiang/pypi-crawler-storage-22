"""Stubs for tornado HTTP client.

Tornado has its own async HTTP client that doesn't use http.client,
so it needs its own patching strategy.
"""

import functools
from typing import TYPE_CHECKING, Any

from .._models import HttpResponse
from .._recorder import create_request_from_tornado, create_response_from_tornado

if TYPE_CHECKING:
    from .._mock_context import HttpMockContext


class MockTornadoResponse:
    """Mock tornado HTTPResponse for playback."""
    
    def __init__(self, request: Any, response_model: HttpResponse):
        from tornado.httputil import HTTPHeaders
        
        self.request = request
        self._response_model = response_model
        
        self.code = response_model.status
        self.reason = self._get_reason(response_model.status)
        self.body = response_model.get_body_bytes()
        self.headers = HTTPHeaders(response_model.headers)
        self.buffer = None
        self.effective_url = request.url
        self.error = None
        self.request_time = 0.0
        self.start_time = 0.0
        self.time_info: dict[str, float] = {}
    
    @staticmethod
    def _get_reason(status: int) -> str:
        from http import HTTPStatus
        try:
            return HTTPStatus(status).phrase
        except ValueError:
            return "Unknown"
    
    def rethrow(self):
        """Raise error if request failed."""
        if self.error:
            raise self.error


def make_tornado_fetch_handler(mock_context: "HttpMockContext", original_fetch_impl):
    """
    Create patched fetch_impl for tornado HTTP clients.
    
    Works for both SimpleAsyncHTTPClient and CurlAsyncHTTPClient.
    Note: fetch_impl is NOT a coroutine - it uses callbacks.
    """
    
    @functools.wraps(original_fetch_impl)
    def fetch_impl(self, request, callback):
        """Patched fetch implementation."""
        # Create request model
        http_request = create_request_from_tornado(request)
        
        # Check for excluded hosts
        if mock_context.is_host_excluded(http_request.url):
            from .._patcher import force_reset
            with force_reset():
                return original_fetch_impl(self, request, callback)
        
        # In playback mode, return recorded response
        if mock_context.mode == "playback":
            response_model = mock_context.play_response(http_request)
            mock_response = MockTornadoResponse(request, response_model)
            
            # Call callback with mock response via IOLoop
            from tornado.ioloop import IOLoop
            IOLoop.current().add_callback(callback, mock_response)
            return
        
        # Record mode - wrap the callback to record the response
        def recording_callback(response):
            # Create response model and record
            resp_model = create_response_from_tornado(response)
            mock_context.record(http_request, resp_model)
            
            # Call original callback
            if callback:
                callback(response)
        
        from .._patcher import force_reset
        with force_reset():
            return original_fetch_impl(self, request, recording_callback)
    
    return fetch_impl
