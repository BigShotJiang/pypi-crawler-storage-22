"""Actual saver for saving actual JSON data on assertion failure."""

import json
from pathlib import Path
from typing import Tuple, Union

from fixturify._utils._constants import ENCODING


class _ActualSaver:
    """Saves actual JSON data to ACTUAL folder on assertion failure."""

    ACTUAL_FOLDER_NAME = "ACTUAL"

    @staticmethod
    def save(
        actual_data: Union[dict, list], expected_file_path: Path
    ) -> Tuple[Path, bool]:
        """
        Save actual JSON data to ACTUAL folder, mirroring the expected file path.

        Given expected file: /path/to/fixtures/expected_user.json
        Creates actual file:  /path/to/fixtures/ACTUAL/expected_user.json

        Args:
            actual_data: The normalized actual data (dict or list)
            expected_file_path: Absolute path to the expected JSON file

        Returns:
            Tuple of (path to saved file, success flag).
            The path is returned even if save fails so it can be included
            in error messages.

        Note:
            - Creates ACTUAL folder if it doesn't exist
            - Overwrites existing actual file if present
            - Saves JSON with indent=2 for readability
        """
        actual_path = _ActualSaver._get_actual_path(expected_file_path)

        try:
            # Create ACTUAL directory if it doesn't exist
            actual_path.parent.mkdir(parents=True, exist_ok=True)

            # Write actual data as JSON
            with open(actual_path, "w", encoding=ENCODING) as f:
                json.dump(actual_data, f, indent=2, ensure_ascii=False)

            return actual_path, True

        except Exception:
            # If save fails (permissions, disk full, etc.), return failure flag
            # so the error message can indicate the actual data could not be saved
            return actual_path, False

    @staticmethod
    def _get_actual_path(expected_file_path: Path) -> Path:
        """
        Calculate the ACTUAL folder path based on expected file path.

        Example:
            Input:  /project/tests/fixtures/expected_user.json
            Output: /project/tests/fixtures/ACTUAL/expected_user.json
        """
        expected_dir = expected_file_path.parent
        actual_dir = expected_dir / _ActualSaver.ACTUAL_FOLDER_NAME
        return actual_dir / expected_file_path.name
