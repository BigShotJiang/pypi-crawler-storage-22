"""Normalizer for converting various input types to comparable format."""

import json
from typing import Any, Union

from fixturify.object_mapper import ObjectMapper


class _Normalizer:
    """Converts various input types to dict/list for comparison."""

    def normalize(self, data: Any) -> Union[dict, list]:
        """
        Convert input data to dict or list for comparison.

        - Objects → ObjectMapper → dict/list
        - Dict → as-is
        - JSON string → json.loads → dict/list
        - List of objects → ObjectMapper → list

        Args:
            data: Input data to normalize

        Returns:
            Normalized dict or list ready for comparison

        Raises:
            ValueError: If data cannot be normalized
        """
        # Handle dict - return as-is
        if isinstance(data, dict):
            return data

        # Handle list/tuple/set - may contain objects to serialize
        if isinstance(data, (list, tuple, set)):
            return self._normalize_collection(data)

        # Handle JSON string
        if isinstance(data, str):
            try:
                parsed = json.loads(data)
                # Only accept JSON objects or arrays, not primitives
                if not isinstance(parsed, (dict, list)):
                    raise ValueError(
                        f"JSON string must contain an object or array, got: {type(parsed).__name__}"
                    )
                return parsed
            except json.JSONDecodeError:
                raise ValueError(
                    "String is not valid JSON. If comparing a string value, "
                    "wrap it in a dict or compare directly."
                )

        # Handle objects using ObjectMapper
        try:
            result = ObjectMapper(data).to_json()
            # Ensure result is a dict or list (not a primitive)
            if not isinstance(result, (dict, list)):
                raise ValueError(
                    f"ObjectMapper returned a primitive ({type(result).__name__}). "
                    f"JsonAssert expects objects that serialize to dict or list."
                )
            return result
        except Exception as e:
            raise ValueError(f"Cannot normalize data to JSON: {e}") from e

    def _normalize_collection(self, collection: Any) -> list[Any]:
        """Normalize a collection, serializing any objects within."""
        result: list[Any] = []
        for item in collection:
            if isinstance(item, dict):
                result.append(item)
            elif isinstance(item, (list, tuple, set)):
                result.append(self._normalize_collection(item))
            elif isinstance(item, (str, int, float, bool, type(None))):
                result.append(item)
            else:
                # Serialize object using ObjectMapper
                try:
                    result.append(ObjectMapper(item).to_json())
                except Exception as e:
                    raise ValueError(f"Cannot serialize collection item: {e}") from e
        return result
