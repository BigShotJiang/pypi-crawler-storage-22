"""ObjectMapper module for bidirectional object-to-JSON mapping."""

from fixturify.object_mapper.mapper import ObjectMapper

__all__ = ["ObjectMapper"]
