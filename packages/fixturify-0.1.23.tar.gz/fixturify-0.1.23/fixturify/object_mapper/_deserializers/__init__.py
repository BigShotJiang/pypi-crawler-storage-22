"""Deserializer implementations for different object types."""

from fixturify.object_mapper._deserializers._base import _BaseDeserializer
from fixturify.object_mapper._deserializers._dataclass import _DataclassDeserializer
from fixturify.object_mapper._deserializers._pydantic_v1 import _PydanticV1Deserializer
from fixturify.object_mapper._deserializers._pydantic_v2 import _PydanticV2Deserializer
from fixturify.object_mapper._deserializers._sqlalchemy import _SQLAlchemyDeserializer
from fixturify.object_mapper._deserializers._sqlmodel import _SQLModelDeserializer
from fixturify.object_mapper._deserializers._plain import _PlainObjectDeserializer

__all__ = [
    "_BaseDeserializer",
    "_DataclassDeserializer",
    "_PydanticV1Deserializer",
    "_PydanticV2Deserializer",
    "_SQLAlchemyDeserializer",
    "_SQLModelDeserializer",
    "_PlainObjectDeserializer",
]
