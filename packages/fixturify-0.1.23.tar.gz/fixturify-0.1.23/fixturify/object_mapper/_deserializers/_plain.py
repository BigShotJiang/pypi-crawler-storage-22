"""Plain Python object deserializer."""

from typing import Any, Type, TypeVar

from fixturify.object_mapper._deserializers._base import _BaseDeserializer

T = TypeVar("T")


class _PlainObjectDeserializer(_BaseDeserializer):
    """Deserializer for plain Python objects."""

    def deserialize(self, data: dict, target_class: Type[T]) -> T:
        """
        Deserialize a dictionary to a plain Python object.

        Attempts to create an instance using:
        1. __init__ with keyword arguments
        2. __new__ followed by attribute assignment

        Args:
            data: Dictionary data to deserialize
            target_class: The class to create an instance of

        Returns:
            Instance of target_class
        """
        # Get type hints for nested object conversion
        type_hints = self._get_type_hints(target_class)

        # Convert values to appropriate types
        converted_data = {}
        for key, value in data.items():
            target_type = type_hints.get(key, Any)
            converted_data[key] = self._convert_value(value, target_type)

        # Try to create instance with __init__
        try:
            return target_class(**converted_data)
        except TypeError:
            # __init__ doesn't accept kwargs, try manual assignment
            pass

        # Try creating with __new__ and manual assignment
        try:
            instance = object.__new__(target_class)
            for key, value in converted_data.items():
                setattr(instance, key, value)
            return instance
        except Exception as e:
            raise ValueError(f"Cannot create instance of {target_class.__name__}: {e}")

    def _deserialize_nested(self, data: dict, target_class: Type[T]) -> T:
        """Deserialize a nested plain object."""
        return self.deserialize(data, target_class)
