"""Pydantic v1 model deserializer."""

from typing import Type, TypeVar

from fixturify.object_mapper._deserializers._base import _BaseDeserializer

T = TypeVar("T")


class _PydanticV1Deserializer(_BaseDeserializer):
    """Deserializer for Pydantic v1 models."""

    def deserialize(self, data: dict, target_class: Type[T]) -> T:
        """
        Deserialize a dictionary to a Pydantic v1 model.

        Pydantic v1 models accept dict data directly in their constructor
        and handle validation/coercion internally.

        Args:
            data: Dictionary data to deserialize
            target_class: The Pydantic v1 model class

        Returns:
            Instance of target_class
        """
        # Pydantic v1 handles validation and type coercion
        # Just pass the data directly
        return target_class(**data)

    def _deserialize_nested(self, data: dict, target_class: Type[T]) -> T:
        """Deserialize a nested Pydantic v1 model."""
        # Check if it's a Pydantic v1 model
        if hasattr(target_class, "__fields__") and hasattr(target_class, "schema"):
            return self.deserialize(data, target_class)

        # For non-Pydantic nested objects, try basic instantiation
        return target_class(**data)
