"""Pydantic v2 model deserializer."""

from typing import Type, TypeVar

from fixturify.object_mapper._deserializers._base import _BaseDeserializer

T = TypeVar("T")


class _PydanticV2Deserializer(_BaseDeserializer):
    """Deserializer for Pydantic v2 models."""

    def deserialize(self, data: dict, target_class: Type[T]) -> T:
        """
        Deserialize a dictionary to a Pydantic v2 model.

        Pydantic v2 models accept dict data directly in their constructor
        and handle validation/coercion internally. Can also use model_validate().

        Args:
            data: Dictionary data to deserialize
            target_class: The Pydantic v2 model class

        Returns:
            Instance of target_class
        """
        # Pydantic v2 has model_validate for dict -> model conversion
        if hasattr(target_class, "model_validate"):
            return target_class.model_validate(data)  # type: ignore[attr-defined, no-any-return]

        # Fallback to constructor
        return target_class(**data)

    def _deserialize_nested(self, data: dict, target_class: Type[T]) -> T:
        """Deserialize a nested Pydantic v2 model."""
        # Check if it's a Pydantic v2 model
        if hasattr(target_class, "model_fields"):
            return self.deserialize(data, target_class)

        # For non-Pydantic nested objects, try basic instantiation
        return target_class(**data)
