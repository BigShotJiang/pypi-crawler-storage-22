"""Type detection for determining object types."""

import json
from dataclasses import is_dataclass
from enum import Enum, auto
from typing import Any, Type


class ObjectType(Enum):
    """Enumeration of supported object types."""

    JSON_STRING = auto()
    DICT = auto()
    COLLECTION = auto()
    SQLMODEL = auto()
    SQLALCHEMY = auto()
    PYDANTIC_V2 = auto()
    PYDANTIC_V1 = auto()
    DATACLASS = auto()
    PLAIN_OBJECT = auto()
    PRIMITIVE = auto()


class _TypeDetector:
    """Detects the type of input data or class."""

    # Primitive types that should be serialized directly
    PRIMITIVE_TYPES = (str, int, float, bool, type(None))

    @staticmethod
    def detect(data: Any) -> ObjectType:
        """
        Detect the type of input data.

        Detection order is critical for correct handling of hybrid types like SQLModel.

        Args:
            data: Any input data

        Returns:
            ObjectType enum value
        """
        # 1. Check for primitive types first
        if isinstance(data, _TypeDetector.PRIMITIVE_TYPES):
            if isinstance(data, str):
                # Check if it's a valid JSON string
                if _TypeDetector._is_json_string(data):
                    return ObjectType.JSON_STRING
            return ObjectType.PRIMITIVE

        # 2. Check for dict
        if isinstance(data, dict):
            return ObjectType.DICT

        # 3. Check for collections (list, tuple, set)
        if isinstance(data, (list, tuple, set, frozenset)):
            return ObjectType.COLLECTION

        # 4. Check for SQLModel (must be before SQLAlchemy and Pydantic v2)
        # SQLModel has both __tablename__ (from SQLAlchemy) and model_fields (from Pydantic v2)
        if _TypeDetector._is_sqlmodel(data):
            return ObjectType.SQLMODEL

        # 5. Check for SQLAlchemy
        if _TypeDetector._is_sqlalchemy(data):
            return ObjectType.SQLALCHEMY

        # 6. Check for Pydantic v2
        if _TypeDetector._is_pydantic_v2(data):
            return ObjectType.PYDANTIC_V2

        # 7. Check for Pydantic v1
        if _TypeDetector._is_pydantic_v1(data):
            return ObjectType.PYDANTIC_V1

        # 8. Check for dataclass
        if is_dataclass(data) and not isinstance(data, type):
            return ObjectType.DATACLASS

        # 9. Fallback to plain object
        return ObjectType.PLAIN_OBJECT

    @staticmethod
    def detect_class(cls: Type) -> ObjectType:
        """
        Detect the type from a class definition.

        Args:
            cls: A class type

        Returns:
            ObjectType enum value
        """
        # Check for SQLModel class
        if _TypeDetector._is_sqlmodel_class(cls):
            return ObjectType.SQLMODEL

        # Check for SQLAlchemy class
        if _TypeDetector._is_sqlalchemy_class(cls):
            return ObjectType.SQLALCHEMY

        # Check for Pydantic v2 class
        if _TypeDetector._is_pydantic_v2_class(cls):
            return ObjectType.PYDANTIC_V2

        # Check for Pydantic v1 class
        if _TypeDetector._is_pydantic_v1_class(cls):
            return ObjectType.PYDANTIC_V1

        # Check for dataclass
        if is_dataclass(cls):
            return ObjectType.DATACLASS

        # Check for Enum
        if isinstance(cls, type) and issubclass(cls, Enum):
            return ObjectType.PRIMITIVE

        # Fallback to plain object
        return ObjectType.PLAIN_OBJECT

    @staticmethod
    def _is_json_string(data: str) -> bool:
        """Check if a string is valid JSON.

        This detects any valid JSON including primitives like "null", "true",
        "123" and strings like '"active"'. The ObjectMapper.to_object() method
        handles the parsed result appropriately based on target class.
        """
        try:
            json.loads(data)
            return True
        except (json.JSONDecodeError, ValueError):
            return False

    @staticmethod
    def _is_sqlmodel(obj: Any) -> bool:
        """Check if object is a SQLModel instance."""
        # SQLModel has both __tablename__ and model_fields
        obj_type = type(obj)
        return hasattr(obj_type, "__tablename__") and hasattr(obj_type, "model_fields")

    @staticmethod
    def _is_sqlmodel_class(cls: Type) -> bool:
        """Check if class is a SQLModel class."""
        return hasattr(cls, "__tablename__") and hasattr(cls, "model_fields")

    @staticmethod
    def _is_sqlalchemy(obj: Any) -> bool:
        """Check if object is a SQLAlchemy model instance."""
        obj_type = type(obj)
        return hasattr(obj_type, "__tablename__") and hasattr(obj_type, "__mapper__")

    @staticmethod
    def _is_sqlalchemy_class(cls: Type) -> bool:
        """Check if class is a SQLAlchemy model class."""
        return hasattr(cls, "__tablename__") and hasattr(cls, "__mapper__")

    @staticmethod
    def _is_pydantic_v2(obj: Any) -> bool:
        """Check if object is a Pydantic v2 model instance."""
        obj_type = type(obj)
        return hasattr(obj_type, "model_fields")

    @staticmethod
    def _is_pydantic_v2_class(cls: Type) -> bool:
        """Check if class is a Pydantic v2 model class."""
        return hasattr(cls, "model_fields")

    @staticmethod
    def _is_pydantic_v1(obj: Any) -> bool:
        """Check if object is a Pydantic v1 model instance."""
        obj_type = type(obj)
        return (
            hasattr(obj_type, "__fields__")
            and hasattr(obj_type, "schema")
            and callable(getattr(obj_type, "schema", None))
        )

    @staticmethod
    def _is_pydantic_v1_class(cls: Type) -> bool:
        """Check if class is a Pydantic v1 model class."""
        return (
            hasattr(cls, "__fields__")
            and hasattr(cls, "schema")
            and callable(getattr(cls, "schema", None))
        )
