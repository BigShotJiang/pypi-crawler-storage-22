"""Read decorator module for injecting file-based test data."""

from fixturify.read_d._decorator import read

__all__ = ["read"]
