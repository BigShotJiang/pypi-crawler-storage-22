"""Database connection configuration."""

from dataclasses import dataclass
from typing import Optional


@dataclass
class SqlTestConfig:
    """
    Database connection configuration.

    Attributes:
        driver: Database driver name (e.g., "psycopg2", "psycopg", "asyncpg", "mysql.connector", "aiomysql")
        host: Database host address
        database: Database name
        user: Database user
        password: Database password
        port: Database port (optional, uses driver's default if not specified)
    """

    driver: str
    host: str
    database: str
    user: str
    password: str
    port: Optional[int] = None

    def __post_init__(self) -> None:
        if self.driver:
            self.driver = self.driver.lstrip("+").strip()
