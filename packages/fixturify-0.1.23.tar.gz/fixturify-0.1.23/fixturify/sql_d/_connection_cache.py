"""Connection cache for sharing database connections across test decorators.

This module provides a singleton cache that stores database connections
keyed by their configuration. This avoids creating a new connection
for each @sql decorator invocation, significantly improving test performance.
"""

import atexit
import asyncio
from dataclasses import dataclass
from typing import Any, Dict, Optional, Tuple, TYPE_CHECKING

if TYPE_CHECKING:
    from ._config import SqlTestConfig


@dataclass(frozen=True)
class CacheKey:
    """Immutable key for connection cache lookup."""

    driver: str
    host: str
    database: str
    user: str
    port: Optional[int]

    @classmethod
    def from_config(cls, config: "SqlTestConfig") -> "CacheKey":
        """Create cache key from SqlTestConfig."""
        return cls(
            driver=config.driver,
            host=config.host,
            database=config.database,
            user=config.user,
            port=config.port,
        )


class ConnectionCache:
    """
    Singleton cache for database connections.

    Maintains separate caches for sync and async connections.
    Connections are created on first access and reused for subsequent calls.
    All connections are closed when the process exits via atexit handler.

    Async connections are tracked with their event loop - if the loop changes
    or closes, the cached connection is invalidated automatically.
    """

    _instance: Optional["ConnectionCache"] = None

    _initialized: bool = False

    def __new__(cls) -> "ConnectionCache":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self) -> None:
        if self._initialized:
            return
        self._initialized = True
        self._sync_connections: Dict[CacheKey, Any] = {}
        # Store (connection, event_loop) tuple for async connections
        self._async_connections: Dict[CacheKey, Tuple[Any, Any]] = {}
        self._sync_close_funcs: Dict[CacheKey, Any] = {}
        self._async_close_funcs: Dict[CacheKey, Any] = {}

    def get_sync(
        self,
        config: "SqlTestConfig",
        connect_func: Any,
        connect_params: Dict[str, Any],
    ) -> Any:
        """
        Get or create a sync connection.

        Args:
            config: Database configuration
            connect_func: Function to create connection (e.g., driver.connect)
            connect_params: Parameters to pass to connect_func

        Returns:
            Database connection object
        """
        key = CacheKey.from_config(config)

        if key not in self._sync_connections:
            connection = connect_func(**connect_params)
            self._sync_connections[key] = connection

        return self._sync_connections[key]

    async def get_async(
        self,
        config: "SqlTestConfig",
        connect_factory: Any,
    ) -> Any:
        """
        Get or create an async connection.

        Tracks the event loop - if the cached connection was created in a
        different or closed loop, it's invalidated and a new one is created.

        Args:
            config: Database configuration
            connect_factory: Callable that returns a coroutine when called

        Returns:
            Database connection object
        """
        key = CacheKey.from_config(config)
        current_loop = asyncio.get_running_loop()

        if key in self._async_connections:
            connection, cached_loop = self._async_connections[key]
            # Check if loop is the same and still running
            if cached_loop is current_loop and not cached_loop.is_closed():
                return connection
            # Loop changed or closed - remove stale connection
            del self._async_connections[key]

        # Create new connection and track with current loop
        connection = await connect_factory()
        self._async_connections[key] = (connection, current_loop)
        return connection

    def register_sync_closer(
        self,
        config: "SqlTestConfig",
        close_func: Any,
    ) -> None:
        """Register a close function for a sync connection."""
        key = CacheKey.from_config(config)
        if key not in self._sync_close_funcs:
            self._sync_close_funcs[key] = close_func

    def register_async_closer(
        self,
        config: "SqlTestConfig",
        close_func: Any,
    ) -> None:
        """Register a close function for an async connection."""
        key = CacheKey.from_config(config)
        if key not in self._async_close_funcs:
            self._async_close_funcs[key] = close_func

    def close_all_sync(self) -> None:
        """Close all cached sync connections."""
        for key, connection in list(self._sync_connections.items()):
            try:
                if key in self._sync_close_funcs:
                    self._sync_close_funcs[key](connection)
                elif hasattr(connection, "close"):
                    connection.close()
            except Exception:
                pass  # Best effort cleanup
        self._sync_connections.clear()
        self._sync_close_funcs.clear()

    def close_all_async_sync(self) -> None:
        """
        Close all async connections from sync context.

        This is called by atexit handler which runs in sync context.
        We need to handle async cleanup carefully.
        """
        for key, (connection, _loop) in list(self._async_connections.items()):
            try:
                if hasattr(connection, "close"):
                    # Some async connections have sync close()
                    result = connection.close()
                    # If close() returns a coroutine, we need to run it
                    if asyncio.iscoroutine(result):
                        try:
                            loop = asyncio.get_event_loop()
                            if loop.is_running():
                                # Can't run from within running loop
                                pass
                            else:
                                loop.run_until_complete(result)
                        except RuntimeError:
                            # No event loop, create new one
                            asyncio.run(result)
            except Exception:
                pass  # Best effort cleanup
        self._async_connections.clear()
        self._async_close_funcs.clear()

    async def close_all_async(self) -> None:
        """Close all cached async connections from async context."""
        for key, (connection, _loop) in list(self._async_connections.items()):
            try:
                if key in self._async_close_funcs:
                    await self._async_close_funcs[key](connection)
                elif hasattr(connection, "close"):
                    result = connection.close()
                    if asyncio.iscoroutine(result):
                        await result
                    # Handle wait_closed for aiomysql-style connections
                    if hasattr(connection, "wait_closed"):
                        await connection.wait_closed()
            except Exception:
                pass  # Best effort cleanup
        self._async_connections.clear()
        self._async_close_funcs.clear()

    def clear(self) -> None:
        """Clear all connections (for testing purposes)."""
        self.close_all_sync()
        self.close_all_async_sync()


# Global cache instance
_cache: Optional[ConnectionCache] = None


def get_connection_cache() -> ConnectionCache:
    """Get the global connection cache instance."""
    global _cache
    if _cache is None:
        _cache = ConnectionCache()
    return _cache


def _cleanup_connections() -> None:
    """Cleanup handler called at process exit."""
    global _cache
    if _cache is not None:
        _cache.close_all_sync()
        _cache.close_all_async_sync()


# Register cleanup handler
atexit.register(_cleanup_connections)
