"""Driver configuration registry for database drivers."""

from dataclasses import dataclass
from typing import Dict, FrozenSet


@dataclass(frozen=True)
class _DriverConfig:
    """Configuration for a database driver."""

    module_name: str
    is_async: bool
    param_mapping: Dict[str, str]  # SqlTestConfig field -> driver parameter name
    default_port: int


# Known async drivers
_ASYNC_DRIVERS: FrozenSet[str] = frozenset(
    {
        "asyncpg",
        "aiomysql",
        "aiosqlite",
    }
)

# Driver registry with connection parameter mappings
_DRIVER_REGISTRY: Dict[str, _DriverConfig] = {
    # PostgreSQL - sync
    "psycopg2": _DriverConfig(
        module_name="psycopg2",
        is_async=False,
        param_mapping={
            "host": "host",
            "database": "dbname",  # psycopg2 uses 'dbname'
            "user": "user",
            "password": "password",
            "port": "port",
        },
        default_port=5432,
    ),
    # PostgreSQL - async
    "asyncpg": _DriverConfig(
        module_name="asyncpg",
        is_async=True,
        param_mapping={
            "host": "host",
            "database": "database",
            "user": "user",
            "password": "password",
            "port": "port",
        },
        default_port=5432,
    ),
    # MySQL - sync
    "mysql.connector": _DriverConfig(
        module_name="mysql.connector",
        is_async=False,
        param_mapping={
            "host": "host",
            "database": "database",
            "user": "user",
            "password": "password",
            "port": "port",
        },
        default_port=3306,
    ),
    # MySQL - async
    "aiomysql": _DriverConfig(
        module_name="aiomysql",
        is_async=True,
        param_mapping={
            "host": "host",
            "database": "db",  # aiomysql uses 'db'
            "user": "user",
            "password": "password",
            "port": "port",
        },
        default_port=3306,
    ),
    # SQLite - sync (for completeness)
    "sqlite3": _DriverConfig(
        module_name="sqlite3",
        is_async=False,
        param_mapping={
            "database": "database",  # sqlite3 only needs database (file path)
        },
        default_port=0,  # Not applicable for SQLite
    ),
    # SQLite - async
    "aiosqlite": _DriverConfig(
        module_name="aiosqlite",
        is_async=True,
        param_mapping={
            "database": "database",
        },
        default_port=0,
    ),
}


def _get_driver_config(driver_name: str) -> _DriverConfig:
    """
    Get driver configuration by name.

    Args:
        driver_name: Name of the database driver

    Returns:
        Driver configuration

    Raises:
        ValueError: If driver is not supported
    """
    if driver_name not in _DRIVER_REGISTRY:
        supported = ", ".join(sorted(_DRIVER_REGISTRY.keys()))
        raise ValueError(
            f"Unsupported driver: '{driver_name}'. Supported drivers: {supported}"
        )
    return _DRIVER_REGISTRY[driver_name]


def _is_async_driver(driver_name: str) -> bool:
    """
    Check if a driver is async.

    Args:
        driver_name: Name of the database driver

    Returns:
        True if the driver is async, False otherwise
    """
    config = _get_driver_config(driver_name)
    return config.is_async
