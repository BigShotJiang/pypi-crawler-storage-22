"""Pytest fixture discovery for SqlTestConfig."""

from typing import TYPE_CHECKING, Optional

from fixturify._utils._fixture_discovery import (
    find_fixture_by_type,
    is_pytest_available as _is_pytest_available,
)
from fixturify.sql_d._config import SqlTestConfig

if TYPE_CHECKING:
    from _pytest.fixtures import FixtureRequest


def _find_config_from_request(request: "FixtureRequest") -> Optional[SqlTestConfig]:
    """
    Find SqlTestConfig fixture using pytest's request object.

    Scans ALL available fixtures (not just function dependencies) for fixtures
    that return SqlTestConfig. This allows defining the config fixture in
    conftest.py without needing to add it as a test parameter.

    Args:
        request: Pytest's FixtureRequest object

    Returns:
        SqlTestConfig if a matching fixture is found, None otherwise
    """
    return find_fixture_by_type(request, SqlTestConfig)


# Re-export for backward compatibility
_is_pytest_available = _is_pytest_available


class _FixtureDiscovery:
    """Discover pytest fixtures by return type using request parameter."""

    @staticmethod
    def find_config_from_request(request: "FixtureRequest") -> Optional[SqlTestConfig]:
        """
        Find SqlTestConfig fixture using pytest's request.

        Args:
            request: Pytest's FixtureRequest object

        Returns:
            SqlTestConfig from fixture if found, None otherwise
        """
        return _find_config_from_request(request)

    @staticmethod
    def is_pytest_available() -> bool:
        """Check if pytest is installed."""
        return _is_pytest_available()
