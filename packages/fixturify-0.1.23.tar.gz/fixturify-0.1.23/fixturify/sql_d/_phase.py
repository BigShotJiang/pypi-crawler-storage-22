"""Phase enum for SQL execution timing."""

from enum import Enum


class Phase(Enum):
    """Execution phase for SQL scripts."""

    BEFORE = "before"  # Execute before test (default)
    AFTER = "after"  # Execute after test
