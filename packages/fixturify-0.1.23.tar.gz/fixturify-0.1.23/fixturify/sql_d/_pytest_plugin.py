"""Pytest plugin for sql_assert fixture."""

from typing import TYPE_CHECKING, Generator

if TYPE_CHECKING:
    from fixturify.sql_d._assert import SqlAssert


def _is_pytest_available() -> bool:
    """Check if pytest is available."""
    try:
        import pytest  # noqa: F401
        return True
    except ImportError:
        return False


# Only define fixtures if pytest is available
if _is_pytest_available():
    import pytest
    from fixturify.sql_d._fixture_discovery import _find_config_from_request
    from fixturify.sql_d._assert import SqlAssert

    @pytest.fixture
    def sql_assert(request: pytest.FixtureRequest) -> Generator["SqlAssert", None, None]:
        """
        Pytest fixture providing SqlAssert for database assertions.

        Requires a fixture returning SqlTestConfig to be defined (e.g., sql_config).

        Example:
            # conftest.py
            @pytest.fixture
            def sql_config() -> SqlTestConfig:
                return SqlTestConfig(
                    driver="psycopg2",
                    host="localhost",
                    database="testdb",
                    user="test",
                    password="test",
                )

            # test_example.py
            @sql(path="./setup.sql")
            def test_user_creation(sql_assert):
                create_user(name="John")
                sql_assert.table("users").where(name="John").exists()

        Raises:
            ValueError: If no SqlTestConfig fixture is found
        """
        config = _find_config_from_request(request)
        if config is None:
            raise ValueError(
                "sql_assert fixture requires a fixture returning SqlTestConfig. "
                "Define a fixture like:\n\n"
                "@pytest.fixture\n"
                "def sql_config() -> SqlTestConfig:\n"
                "    return SqlTestConfig(...)\n"
            )

        yield SqlAssert(config)
