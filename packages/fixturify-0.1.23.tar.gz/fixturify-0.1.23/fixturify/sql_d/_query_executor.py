"""SQL query executor for SELECT queries returning results as dicts."""

import asyncio
import atexit
import sys
import threading
from typing import Any, Dict, List, Optional, TYPE_CHECKING

from fixturify.sql_d._strategies._registry import get_strategy_registry
from fixturify.sql_d._strategies._base import AsyncSqlExecutionStrategy

if TYPE_CHECKING:
    from fixturify.sql_d._config import SqlTestConfig


# Persistent event loop for bridging async drivers from sync context.
# A single loop lives in a daemon thread so cached async connections
# stay valid across calls (same loop = cache hit).
_loop: Optional[asyncio.AbstractEventLoop] = None
_thread: Optional[threading.Thread] = None
_lock = threading.Lock()


def _get_loop() -> asyncio.AbstractEventLoop:
    """Get or create the persistent background event loop."""
    global _loop, _thread
    if _loop is not None and not _loop.is_closed():
        return _loop
    with _lock:
        if _loop is not None and not _loop.is_closed():
            return _loop
        if sys.platform == "win32":
            _loop = asyncio.SelectorEventLoop()
        else:
            _loop = asyncio.new_event_loop()
        _thread = threading.Thread(target=_loop.run_forever, daemon=True)
        _thread.start()
        return _loop


def _shutdown_loop() -> None:
    """Shutdown the persistent loop and close cached async connections."""
    global _loop, _thread
    if _loop is None or _loop.is_closed():
        return
    from fixturify.sql_d._connection_cache import get_connection_cache
    cache = get_connection_cache()
    try:
        future = asyncio.run_coroutine_threadsafe(cache.close_all_async(), _loop)
        future.result(timeout=5)
    except Exception:
        pass
    _loop.call_soon_threadsafe(_loop.stop)
    if _thread is not None:
        _thread.join(timeout=5)
    _loop.close()


atexit.register(_shutdown_loop)


def _run_async(coro: Any) -> Any:
    """Run async coroutine from sync context using a persistent event loop.

    The loop lives in a background thread so async connections created
    inside it stay valid across calls — the connection cache works as
    intended and avoids reconnecting on every invocation.
    """
    loop = _get_loop()
    future = asyncio.run_coroutine_threadsafe(coro, loop)
    return future.result()


class SqlQueryExecutor:
    """
    Execute SELECT queries and return results as dictionaries.

    This class is ORM-agnostic and works with any database driver
    supported by the strategy registry.
    """

    # Placeholder mapping for different drivers
    PLACEHOLDERS: Dict[str, str] = {
        "psycopg2": "%s",
        "psycopg": "%s",
        "asyncpg": "$",  # Uses $1, $2, etc.
        "mysql.connector": "%s",
        "aiomysql": "%s",
        "sqlite3": "?",
        "aiosqlite": "?",
    }

    def __init__(self, config: "SqlTestConfig"):
        """
        Initialize query executor.

        Args:
            config: Database configuration
        """
        self._config = config
        self._registry = get_strategy_registry()
        self._strategy = self._registry.get_or_raise(config.driver)

    @property
    def is_async(self) -> bool:
        """Check if this executor uses async driver."""
        return self._strategy.is_async

    @property
    def _async_strategy(self) -> AsyncSqlExecutionStrategy:
        """Get strategy cast to AsyncSqlExecutionStrategy for async methods."""
        assert isinstance(self._strategy, AsyncSqlExecutionStrategy)
        return self._strategy

    def get_placeholder(self) -> str:
        """Get the parameter placeholder for this driver."""
        return self.PLACEHOLDERS.get(self._config.driver, "%s")

    def _format_query(self, sql: str, param_count: int) -> str:
        """
        Format query with correct placeholders for the driver.

        For asyncpg, converts %s to $1, $2, etc.
        """
        if self._config.driver == "asyncpg":
            # Replace %s with $1, $2, etc.
            result = sql
            for i in range(param_count):
                result = result.replace("%s", f"${i + 1}", 1)
            return result
        return sql

    def fetch_one(self, sql: str, params: Optional[List[Any]] = None) -> Optional[Dict[str, Any]]:
        """
        Execute query and return first row as dict.

        Args:
            sql: SQL query with %s placeholders
            params: Query parameters

        Returns:
            First row as dict, or None if no results
        """
        if self._strategy.is_async:
            return _run_async(self.afetch_one(sql, params))  # type: ignore[no-any-return]
        return self._fetch_one_sync(sql, params or [])

    def fetch_all(self, sql: str, params: Optional[List[Any]] = None) -> List[Dict[str, Any]]:
        """
        Execute query and return all rows as dicts.

        Args:
            sql: SQL query with %s placeholders
            params: Query parameters

        Returns:
            List of rows as dicts
        """
        if self._strategy.is_async:
            return _run_async(self.afetch_all(sql, params))  # type: ignore[no-any-return]
        return self._fetch_all_sync(sql, params or [])

    async def afetch_one(self, sql: str, params: Optional[List[Any]] = None) -> Optional[Dict[str, Any]]:
        """
        Execute query asynchronously and return first row as dict.

        Args:
            sql: SQL query with %s placeholders
            params: Query parameters

        Returns:
            First row as dict, or None if no results
        """
        params = params or []
        formatted_sql = self._format_query(sql, len(params))

        if self._config.driver == "asyncpg":
            return await self._afetch_onepg(formatted_sql, params)
        elif self._config.driver == "aiomysql":
            return await self._fetch_one_aiomysql(formatted_sql, params)
        elif self._config.driver == "aiosqlite":
            return await self._fetch_one_aiosqlite(formatted_sql, params)
        elif self._config.driver == "psycopg":
            return await self._afetch_one_psycopg(formatted_sql, params)
        else:
            raise ValueError(f"Unsupported async driver: {self._config.driver}")

    async def afetch_all(self, sql: str, params: Optional[List[Any]] = None) -> List[Dict[str, Any]]:
        """
        Execute query asynchronously and return all rows as dicts.

        Args:
            sql: SQL query with %s placeholders
            params: Query parameters

        Returns:
            List of rows as dicts
        """
        params = params or []
        formatted_sql = self._format_query(sql, len(params))

        if self._config.driver == "asyncpg":
            return await self._afetch_allpg(formatted_sql, params)
        elif self._config.driver == "aiomysql":
            return await self._fetch_all_aiomysql(formatted_sql, params)
        elif self._config.driver == "aiosqlite":
            return await self._fetch_all_aiosqlite(formatted_sql, params)
        elif self._config.driver == "psycopg":
            return await self._afetch_all_psycopg(formatted_sql, params)
        else:
            raise ValueError(f"Unsupported async driver: {self._config.driver}")

    def _fetch_one_sync(self, sql: str, params: List[Any]) -> Optional[Dict[str, Any]]:
        """Fetch one row using sync driver."""
        driver = self._strategy.get_driver_module()
        conn_params = self._strategy.build_connection_params(self._config)

        connection = self._strategy.get_cached_connection(
            self._config, driver.connect, conn_params
        )

        cursor = connection.cursor()
        try:
            cursor.execute(sql, params or None)
            row = cursor.fetchone()
            if row is None:
                return None

            # Get column names
            columns = [desc[0] for desc in cursor.description]
            return dict(zip(columns, row))
        finally:
            cursor.close()
            connection.rollback()

    def _fetch_all_sync(self, sql: str, params: List[Any]) -> List[Dict[str, Any]]:
        """Fetch all rows using sync driver."""
        driver = self._strategy.get_driver_module()
        conn_params = self._strategy.build_connection_params(self._config)

        connection = self._strategy.get_cached_connection(
            self._config, driver.connect, conn_params
        )

        cursor = connection.cursor()
        try:
            cursor.execute(sql, params or None)
            rows = cursor.fetchall()
            if not rows:
                return []

            # Get column names
            columns = [desc[0] for desc in cursor.description]
            return [dict(zip(columns, row)) for row in rows]
        finally:
            cursor.close()
            connection.rollback()

    async def _afetch_onepg(self, sql: str, params: List[Any]) -> Optional[Dict[str, Any]]:
        """Fetch one row using asyncpg."""
        import asyncpg

        driver_params = self._strategy.build_connection_params(self._config)
        pool = await self._async_strategy.get_cached_connection_async(
            self._config,
            lambda: asyncpg.create_pool(**driver_params, min_size=1, max_size=5)
        )

        async with pool.acquire() as connection:
            row = await connection.fetchrow(sql, *params)
            if row is None:
                return None
            return dict(row)

    async def _afetch_allpg(self, sql: str, params: List[Any]) -> List[Dict[str, Any]]:
        """Fetch all rows using asyncpg."""
        import asyncpg

        driver_params = self._strategy.build_connection_params(self._config)
        pool = await self._async_strategy.get_cached_connection_async(
            self._config,
            lambda: asyncpg.create_pool(**driver_params, min_size=1, max_size=5)
        )

        async with pool.acquire() as connection:
            rows = await connection.fetch(sql, *params)
            return [dict(row) for row in rows]

    async def _fetch_one_aiomysql(self, sql: str, params: List[Any]) -> Optional[Dict[str, Any]]:
        """Fetch one row using aiomysql."""
        import aiomysql

        driver_params = self._strategy.build_connection_params(self._config)
        connection = await self._async_strategy.get_cached_connection_async(
            self._config,
            lambda: aiomysql.connect(**driver_params)
        )

        try:
            async with connection.cursor(aiomysql.DictCursor) as cursor:
                await cursor.execute(sql, params or None)
                result: Optional[Dict[str, Any]] = await cursor.fetchone()
                return result
        finally:
            await connection.rollback()

    async def _fetch_all_aiomysql(self, sql: str, params: List[Any]) -> List[Dict[str, Any]]:
        """Fetch all rows using aiomysql."""
        import aiomysql

        driver_params = self._strategy.build_connection_params(self._config)
        connection = await self._async_strategy.get_cached_connection_async(
            self._config,
            lambda: aiomysql.connect(**driver_params)
        )

        try:
            async with connection.cursor(aiomysql.DictCursor) as cursor:
                await cursor.execute(sql, params or None)
                rows = await cursor.fetchall()
                return list(rows) if rows else []
        finally:
            await connection.rollback()

    async def _fetch_one_aiosqlite(self, sql: str, params: List[Any]) -> Optional[Dict[str, Any]]:
        """Fetch one row using aiosqlite."""
        import aiosqlite

        # aiosqlite doesn't support connection pooling, use direct connection
        db_path = self._config.database
        async with aiosqlite.connect(db_path) as connection:
            connection.row_factory = aiosqlite.Row
            async with connection.execute(sql, params) as cursor:
                row = await cursor.fetchone()
                if row is None:
                    return None
                return dict(row)

    async def _fetch_all_aiosqlite(self, sql: str, params: List[Any]) -> List[Dict[str, Any]]:
        """Fetch all rows using aiosqlite."""
        import aiosqlite

        db_path = self._config.database
        async with aiosqlite.connect(db_path) as connection:
            connection.row_factory = aiosqlite.Row
            async with connection.execute(sql, params) as cursor:
                rows = await cursor.fetchall()
                return [dict(row) for row in rows]

    async def _afetch_one_psycopg(self, sql: str, params: List[Any]) -> Optional[Dict[str, Any]]:
        """Fetch one row using psycopg (async)."""
        import psycopg

        driver_params = self._strategy.build_connection_params(self._config)
        connection = await self._async_strategy.get_cached_connection_async(
            self._config, lambda: psycopg.AsyncConnection.connect(**driver_params)
        )
        try:
            cursor = await connection.execute(sql, params or None)
            row = await cursor.fetchone()
            if row is None:
                return None
            columns = [desc[0] for desc in cursor.description]
            return dict(zip(columns, row))
        finally:
            await connection.rollback()

    async def _afetch_all_psycopg(self, sql: str, params: List[Any]) -> List[Dict[str, Any]]:
        """Fetch all rows using psycopg (async)."""
        import psycopg

        driver_params = self._strategy.build_connection_params(self._config)
        connection = await self._async_strategy.get_cached_connection_async(
            self._config, lambda: psycopg.AsyncConnection.connect(**driver_params)
        )
        try:
            cursor = await connection.execute(sql, params or None)
            rows = await cursor.fetchall()
            if not rows:
                return []
            columns = [desc[0] for desc in cursor.description]
            return [dict(zip(columns, row)) for row in rows]
        finally:
            await connection.rollback()
