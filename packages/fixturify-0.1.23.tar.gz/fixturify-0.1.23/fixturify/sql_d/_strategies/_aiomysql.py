"""Strategy for aiomysql (MySQL async) driver."""

from typing import Any, TYPE_CHECKING

from ._base import AsyncSqlExecutionStrategy

if TYPE_CHECKING:
    from .._config import SqlTestConfig


class AiomysqlStrategy(AsyncSqlExecutionStrategy):
    """Execution strategy for aiomysql (MySQL async)."""

    driver_name = "aiomysql"
    is_async = True
    default_port = 3306
    param_mapping = {
        "host": "host",
        "database": "db",
        "user": "user",
        "password": "password",
        "port": "port",
    }

    async def execute_async(self, sql_content: str, config: "SqlTestConfig") -> None:
        """Execute SQL using aiomysql."""
        driver = self.get_driver_module()
        params = self.build_connection_params(config)

        connection = await self.get_cached_connection_async(
            config, lambda: driver.connect(**params)
        )
        async with connection.cursor() as cursor:
            # aiomysql doesn't support multi-statement by default
            await self._execute_statements(cursor, sql_content)
        await connection.commit()

    async def _execute_statements(self, cursor: Any, sql_content: str) -> None:
        """
        Execute multiple SQL statements for aiomysql.

        aiomysql doesn't execute multiple statements by default.
        We split by semicolon and execute each statement separately.

        Args:
            cursor: Async database cursor
            sql_content: SQL content with potentially multiple statements
        """
        statements = [s.strip() for s in sql_content.split(";") if s.strip()]
        for statement in statements:
            # Skip comments-only statements
            if statement.startswith("--") and "\n" not in statement:
                continue
            await cursor.execute(statement)
            # Consume any results to avoid unread result issues
            try:
                await cursor.fetchall()
            except Exception:
                # No results to fetch (e.g., INSERT, UPDATE, DELETE, DDL)
                pass
