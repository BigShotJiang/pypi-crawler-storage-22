"""Strategy for aiosqlite (SQLite async) driver."""

from typing import TYPE_CHECKING

from ._base import AsyncSqlExecutionStrategy

if TYPE_CHECKING:
    from .._config import SqlTestConfig


class AiosqliteStrategy(AsyncSqlExecutionStrategy):
    """Execution strategy for aiosqlite (SQLite async)."""

    driver_name = "aiosqlite"
    is_async = True
    default_port = 0  # SQLite doesn't use ports
    param_mapping = {
        "database": "database",
    }

    async def execute_async(self, sql_content: str, config: "SqlTestConfig") -> None:
        """Execute SQL using aiosqlite."""
        driver = self.get_driver_module()
        params = self.build_connection_params(config)

        database_path = params.get("database", ":memory:")

        connection = await self.get_cached_connection_async(
            config, lambda: driver.connect(database_path)
        )
        await connection.executescript(sql_content)
        await connection.commit()
