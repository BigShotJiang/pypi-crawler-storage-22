"""Strategy for asyncpg (PostgreSQL async) driver."""

from typing import TYPE_CHECKING

from ._base import AsyncSqlExecutionStrategy

if TYPE_CHECKING:
    from .._config import SqlTestConfig


class AsyncpgStrategy(AsyncSqlExecutionStrategy):
    """Execution strategy for asyncpg (PostgreSQL async).

    Uses connection pools instead of single connections to support
    concurrent operations across multiple tests.
    """

    driver_name = "asyncpg"
    is_async = True
    default_port = 5432
    param_mapping = {
        "host": "host",
        "database": "database",
        "user": "user",
        "password": "password",
        "port": "port",
    }

    async def execute_async(self, sql_content: str, config: "SqlTestConfig") -> None:
        """Execute SQL using asyncpg with connection pool."""
        driver = self.get_driver_module()
        params = self.build_connection_params(config)

        # Use pool instead of single connection for concurrency support
        pool = await self.get_cached_connection_async(
            config, lambda: driver.create_pool(**params, min_size=1, max_size=5)
        )
        async with pool.acquire() as connection:
            await connection.execute(sql_content)
