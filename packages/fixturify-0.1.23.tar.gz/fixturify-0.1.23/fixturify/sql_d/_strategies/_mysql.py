"""Strategy for mysql.connector (MySQL) driver."""

from typing import Any, TYPE_CHECKING

from ._base import SqlExecutionStrategy

if TYPE_CHECKING:
    from .._config import SqlTestConfig


class MysqlConnectorStrategy(SqlExecutionStrategy):
    """Execution strategy for mysql.connector (MySQL)."""

    driver_name = "mysql.connector"
    is_async = False
    default_port = 3306
    param_mapping = {
        "host": "host",
        "database": "database",
        "user": "user",
        "password": "password",
        "port": "port",
    }

    def execute(self, sql_content: str, config: "SqlTestConfig") -> None:
        """Execute SQL using mysql.connector."""
        driver = self.get_driver_module()
        params = self.build_connection_params(config)

        connection = self.get_cached_connection(config, driver.connect, params)
        cursor = connection.cursor()
        try:
            # MySQL connector doesn't support multi-statement by default
            self._execute_statements(cursor, sql_content, driver)
            connection.commit()
        finally:
            cursor.close()

    def _execute_statements(self, cursor: Any, sql_content: str, driver: Any) -> None:
        """
        Execute multiple SQL statements for MySQL.

        MySQL connector doesn't execute multiple statements by default.
        We split by semicolon and execute each statement separately.

        **Limitations:**
        - This naive splitting breaks with semicolons inside string literals
        - Stored procedures with DELIMITER changes are not supported
        - Multi-line comments containing semicolons may cause issues

        Args:
            cursor: Database cursor
            sql_content: SQL content with potentially multiple statements
            driver: The mysql.connector module
        """
        statements = [s.strip() for s in sql_content.split(";") if s.strip()]
        for statement in statements:
            # Skip comments-only statements
            if statement.startswith("--") and "\n" not in statement:
                continue
            cursor.execute(statement)
            # Consume any results to avoid "Unread result found" error
            try:
                cursor.fetchall()
            except driver.errors.InterfaceError:
                # No results to fetch (e.g., INSERT, UPDATE, DELETE, DDL)
                pass
