"""Registry for SQL execution strategies."""

from typing import Dict, Optional, Type

from ._base import SqlExecutionStrategy


class StrategyRegistry:
    """
    Registry for SQL execution strategies.

    Maps driver names to strategy classes.
    """

    def __init__(self):
        """Initialize empty registry."""
        self._strategies: Dict[str, SqlExecutionStrategy] = {}
        self._strategy_classes: Dict[str, Type[SqlExecutionStrategy]] = {}

    def register(self, strategy_class: Type[SqlExecutionStrategy]) -> None:
        """
        Register a strategy class.

        Args:
            strategy_class: The strategy class to register.
        """
        name = strategy_class.driver_name
        if not name:
            raise ValueError(f"Strategy class {strategy_class} has no driver_name")
        self._strategy_classes[name] = strategy_class

    def get(self, driver_name: str) -> Optional[SqlExecutionStrategy]:
        """
        Get a strategy instance by driver name.

        Args:
            driver_name: The driver name.

        Returns:
            Strategy instance or None if not registered.
        """
        if driver_name not in self._strategies:
            if driver_name in self._strategy_classes:
                self._strategies[driver_name] = self._strategy_classes[driver_name]()
        return self._strategies.get(driver_name)

    def get_or_raise(self, driver_name: str) -> SqlExecutionStrategy:
        """
        Get a strategy instance, raising if not found.

        Args:
            driver_name: The driver name.

        Returns:
            Strategy instance.

        Raises:
            ValueError: If driver is not registered.
        """
        strategy = self.get(driver_name)
        if strategy is None:
            available = ", ".join(self._strategy_classes.keys())
            raise ValueError(
                f"Unsupported driver: {driver_name}. "
                f"Available drivers: {available}"
            )
        return strategy

    def is_async(self, driver_name: str) -> bool:
        """Check if a driver uses async execution."""
        strategy = self.get(driver_name)
        return strategy.is_async if strategy else False


# Global registry instance
_registry: Optional[StrategyRegistry] = None


def get_strategy_registry() -> StrategyRegistry:
    """
    Get the global strategy registry, initializing if needed.

    Returns:
        The global StrategyRegistry instance.
    """
    global _registry
    if _registry is None:
        _registry = StrategyRegistry()
        _register_default_strategies(_registry)
    return _registry


def _register_default_strategies(registry: StrategyRegistry) -> None:
    """Register all built-in strategies."""
    from ._psycopg2 import Psycopg2Strategy
    from ._psycopg import PsycopgStrategy
    from ._mysql import MysqlConnectorStrategy
    from ._sqlite import Sqlite3Strategy
    from ._asyncpg import AsyncpgStrategy
    from ._aiomysql import AiomysqlStrategy
    from ._aiosqlite import AiosqliteStrategy

    registry.register(Psycopg2Strategy)
    registry.register(PsycopgStrategy)
    registry.register(MysqlConnectorStrategy)
    registry.register(Sqlite3Strategy)
    registry.register(AsyncpgStrategy)
    registry.register(AiomysqlStrategy)
    registry.register(AiosqliteStrategy)
