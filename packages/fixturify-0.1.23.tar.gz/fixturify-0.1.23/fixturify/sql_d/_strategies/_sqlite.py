"""Strategy for sqlite3 driver."""

from typing import Any, TYPE_CHECKING

from ._base import SqlExecutionStrategy

if TYPE_CHECKING:
    from .._config import SqlTestConfig


class Sqlite3Strategy(SqlExecutionStrategy):
    """Execution strategy for sqlite3."""

    driver_name = "sqlite3"
    is_async = False
    default_port = 0  # SQLite doesn't use ports
    param_mapping = {
        "database": "database",
    }

    def execute(self, sql_content: str, config: "SqlTestConfig") -> None:
        """Execute SQL using sqlite3."""
        driver = self.get_driver_module()
        params = self.build_connection_params(config)

        database_path = params.get("database", ":memory:")

        def connect_sqlite() -> Any:
            return driver.connect(database_path)

        connection = self.get_cached_connection(config, connect_sqlite, {})
        # SQLite supports executescript for multi-statement execution
        connection.executescript(sql_content)
        connection.commit()
