"""Integration tests for HTTP mock decorator using http.client (stdlib).

These tests verify that the http_d module correctly intercepts
http.client HTTP calls for recording and playback.
"""

import http.client as http_client
import json

from fixturify.http_d import http, HttpTestConfig


# Base URL for the test API
API_HOST = "api.restful-api.dev"


class TestHttpClientIntegration:
    """Integration tests using http.client (stdlib)."""

    @http(path="./fixtures/http_client_get_all_objects.json")
    def test_get_all_objects(self):
        """Test GET request to fetch all objects."""
        conn = http_client.HTTPSConnection(API_HOST)
        conn.request("GET", "/objects")
        response = conn.getresponse()

        assert response.status == 200
        data = json.loads(response.read().decode("utf-8"))

        # Should return a list of objects
        assert isinstance(data, list)
        assert len(data) > 0

        # First object should have expected structure
        first_obj = data[0]
        assert "id" in first_obj
        assert "name" in first_obj

        conn.close()

    @http(path="./fixtures/http_client_get_single_object.json")
    def test_get_single_object(self):
        """Test GET request to fetch a single object by ID."""
        conn = http_client.HTTPSConnection(API_HOST)
        conn.request("GET", "/objects/1")
        response = conn.getresponse()

        assert response.status == 200
        data = json.loads(response.read().decode("utf-8"))

        assert data["id"] == "1"
        assert "name" in data

        conn.close()

    @http(path="./fixtures/http_client_post_object.json")
    def test_create_object(self):
        """Test POST request to create a new object."""
        new_object = {"name": "HttpClient Test Product", "data": {"color": "Green"}}
        body = json.dumps(new_object)

        conn = http_client.HTTPSConnection(API_HOST)
        conn.request(
            "POST",
            "/objects",
            body=body,
            headers={"Content-Type": "application/json"},
        )
        response = conn.getresponse()

        assert response.status == 200
        data = json.loads(response.read().decode("utf-8"))

        # Should return created object with ID
        assert "id" in data
        assert data["name"] == "HttpClient Test Product"

        conn.close()

    @http(path="./fixtures/http_client_sequential.json")
    def test_sequential_requests(self):
        """Test multiple sequential requests on same connection."""
        conn = http_client.HTTPSConnection(API_HOST)

        # First request
        conn.request("GET", "/objects/1")
        response1 = conn.getresponse()
        assert response1.status == 200
        data1 = json.loads(response1.read().decode("utf-8"))

        # Second request
        conn.request("GET", "/objects/2")
        response2 = conn.getresponse()
        assert response2.status == 200
        data2 = json.loads(response2.read().decode("utf-8"))

        # Verify different objects
        assert data1["id"] != data2["id"]

        conn.close()


class TestHttpConnectionIntegration:
    """Tests for regular HTTP (non-HTTPS) connections."""

    @http(
        path="./fixtures/http_client_http_connection.json",
        config=HttpTestConfig(exclude_hosts=["httpbin.org"]),
    )
    def test_http_connection_excluded(self):
        """Test that excluded hosts bypass recording."""
        # This test just verifies the exclude_hosts mechanism works
        # with http.client as well
        pass
