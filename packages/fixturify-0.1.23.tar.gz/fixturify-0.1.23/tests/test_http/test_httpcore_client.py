"""Integration tests for HTTP mock decorator using httpcore.

These tests verify that the http_d module correctly intercepts
httpcore HTTP calls for recording and playback, while avoiding
double interception when httpx is used.
"""

import json
import pytest

from fixturify.http_d import http, HttpTestConfig


# Check if httpcore is available
try:
    import httpcore

    HAS_HTTPCORE = True
except ImportError:
    HAS_HTTPCORE = False

# Check if httpx is available
try:
    import httpx

    HAS_HTTPX = True
except ImportError:
    HAS_HTTPX = False


# Base URL for the test API
API_BASE = "https://api.restful-api.dev"


@pytest.mark.skipif(not HAS_HTTPCORE, reason="httpcore not installed")
class TestHttpcoreIntegration:
    """Integration tests using httpcore library directly."""

    @http(path="./fixtures/httpcore_get_single_object.json")
    def test_get_single_object(self):
        """Test GET request to fetch a single object by ID."""
        with httpcore.ConnectionPool() as pool:
            response = pool.request(
                "GET",
                f"{API_BASE}/objects/1",
            )

            assert response.status == 200
            response.read()  # Must read before accessing content
            data = json.loads(response.content.decode("utf-8"))

            assert data["id"] == "1"
            assert "name" in data

    @http(path="./fixtures/httpcore_post_object.json")
    def test_create_object(self):
        """Test POST request to create a new object."""
        new_object = {"name": "Httpcore Test Product", "data": {"color": "Cyan"}}
        body = json.dumps(new_object).encode("utf-8")

        with httpcore.ConnectionPool() as pool:
            response = pool.request(
                "POST",
                f"{API_BASE}/objects",
                headers=[
                    (b"content-type", b"application/json"),
                ],
                content=body,
            )

            assert response.status == 200
            response.read()  # Must read before accessing content
            data = json.loads(response.content.decode("utf-8"))

            # Should return created object with ID
            assert "id" in data
            assert data["name"] == "Httpcore Test Product"


@pytest.mark.skipif(not HAS_HTTPCORE, reason="httpcore not installed")
class TestHttpcoreAsyncIntegration:
    """Integration tests using httpcore async client."""

    @pytest.mark.asyncio
    @http(path="./fixtures/httpcore_async_get_single.json")
    async def test_get_single_object_async(self):
        """Test async GET request to fetch a single object by ID."""
        async with httpcore.AsyncConnectionPool() as pool:
            response = await pool.request(
                "GET",
                f"{API_BASE}/objects/1",
            )

            assert response.status == 200
            await response.aread()  # Must read before accessing content
            data = json.loads(response.content.decode("utf-8"))

            assert data["id"] == "1"
            assert "name" in data


@pytest.mark.skipif(
    not (HAS_HTTPCORE and HAS_HTTPX),
    reason="Both httpcore and httpx required",
)
class TestHttpcoreNoDoubleIntercept:
    """Tests to verify no double interception with httpx."""

    @http(path="./fixtures/httpcore_via_httpx.json")
    def test_httpx_uses_httpcore_no_double_record(self):
        """Verify that httpx using httpcore doesn't cause double recording.

        When httpx makes a request, it uses httpcore internally.
        We should only record at the httpx level, not also at httpcore.
        """
        # Make a request using httpx (which uses httpcore internally)
        with httpx.Client() as client:
            response = client.get(f"{API_BASE}/objects/1")
            assert response.status_code == 200

        # The recording should only have one entry, not two
        # (if double interception occurred, we'd have duplicate entries)

    @pytest.mark.asyncio
    @http(path="./fixtures/httpcore_via_httpx_async.json")
    async def test_httpx_async_uses_httpcore_no_double_record(self):
        """Verify that async httpx using httpcore doesn't cause double recording."""
        async with httpx.AsyncClient() as client:
            response = await client.get(f"{API_BASE}/objects/1")
            assert response.status_code == 200


@pytest.mark.skipif(not HAS_HTTPCORE, reason="httpcore not installed")
class TestHttpcoreWithConfig:
    """Tests with custom configuration."""

    @http(
        path="./fixtures/httpcore_with_config.json",
        config=HttpTestConfig(
            ignore_request_headers=["x-custom-header"],
            exclude_request_headers=["x-secret-key"],
        ),
    )
    def test_with_custom_headers(self):
        """Test with custom headers that should be filtered."""
        with httpcore.ConnectionPool() as pool:
            response = pool.request(
                "GET",
                f"{API_BASE}/objects/1",
                headers=[
                    (b"x-custom-header", b"custom-value"),
                    (b"x-secret-key", b"secret-123"),
                ],
            )

            assert response.status == 200
