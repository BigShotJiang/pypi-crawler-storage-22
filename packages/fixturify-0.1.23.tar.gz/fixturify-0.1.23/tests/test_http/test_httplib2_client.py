"""Integration tests for HTTP mock decorator using httplib2.

These tests verify that the http_d module correctly intercepts
httplib2 HTTP calls for recording and playback.
"""

import json
import pytest

from fixturify.http_d import http, HttpTestConfig


# Check if httplib2 is available
try:
    import httplib2

    HAS_HTTPLIB2 = True
except ImportError:
    HAS_HTTPLIB2 = False


# Base URL for the test API
API_BASE = "https://api.restful-api.dev"


@pytest.mark.skipif(not HAS_HTTPLIB2, reason="httplib2 not installed")
class TestHttplib2Integration:
    """Integration tests using httplib2 library."""

    @http(path="./fixtures/httplib2_get_all_objects.json")
    def test_get_all_objects(self):
        """Test GET request to fetch all objects."""
        h = httplib2.Http()
        response, content = h.request(f"{API_BASE}/objects", "GET")

        assert response.status == 200
        data = json.loads(content.decode("utf-8"))

        # Should return a list of objects
        assert isinstance(data, list)
        assert len(data) > 0

        # First object should have expected structure
        first_obj = data[0]
        assert "id" in first_obj
        assert "name" in first_obj

    @http(path="./fixtures/httplib2_get_single_object.json")
    def test_get_single_object(self):
        """Test GET request to fetch a single object by ID."""
        h = httplib2.Http()
        response, content = h.request(f"{API_BASE}/objects/1", "GET")

        assert response.status == 200
        data = json.loads(content.decode("utf-8"))

        assert data["id"] == "1"
        assert "name" in data

    @http(path="./fixtures/httplib2_post_object.json")
    def test_create_object(self):
        """Test POST request to create a new object."""
        new_object = {"name": "Httplib2 Test Product", "data": {"color": "Yellow"}}
        body = json.dumps(new_object)

        h = httplib2.Http()
        response, content = h.request(
            f"{API_BASE}/objects",
            "POST",
            body=body,
            headers={"Content-Type": "application/json"},
        )

        assert response.status == 200
        data = json.loads(content.decode("utf-8"))

        # Should return created object with ID
        assert "id" in data
        assert data["name"] == "Httplib2 Test Product"

    @http(path="./fixtures/httplib2_sequential.json")
    def test_sequential_requests(self):
        """Test multiple sequential requests."""
        h = httplib2.Http()

        # First request
        response1, content1 = h.request(f"{API_BASE}/objects/1", "GET")
        assert response1.status == 200
        data1 = json.loads(content1.decode("utf-8"))

        # Second request
        response2, content2 = h.request(f"{API_BASE}/objects/2", "GET")
        assert response2.status == 200
        data2 = json.loads(content2.decode("utf-8"))

        # Verify different objects
        assert data1["id"] != data2["id"]


@pytest.mark.skipif(not HAS_HTTPLIB2, reason="httplib2 not installed")
class TestHttplib2WithConfig:
    """Tests with custom configuration."""

    @http(
        path="./fixtures/httplib2_with_config.json",
        config=HttpTestConfig(
            ignore_request_headers=["X-Custom-Header"],
            exclude_request_headers=["X-Secret-Key"],
        ),
    )
    def test_with_custom_headers(self):
        """Test with custom headers that should be filtered."""
        h = httplib2.Http()
        response, content = h.request(
            f"{API_BASE}/objects/1",
            "GET",
            headers={
                "X-Custom-Header": "custom-value",
                "X-Secret-Key": "secret-123",
            },
        )

        assert response.status == 200
