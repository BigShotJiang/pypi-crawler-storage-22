"""Tests for HTTP models."""

import json

from fixturify.http_d import HttpMapping, HttpMappings, HttpRequest, HttpResponse


class TestHttpRequest:
    """Tests for HttpRequest model."""

    def test_create_basic_request(self):
        """Test creating a basic HTTP request."""
        request = HttpRequest(
            method="GET",
            url="https://api.example.com/users",
        )

        assert request.method == "GET"
        assert request.url == "https://api.example.com/users"
        assert request.headers == {}
        assert request.queryParameters == {}
        assert request.body is None

    def test_create_request_with_all_fields(self):
        """Test creating a request with all fields."""
        request = HttpRequest(
            method="POST",
            url="https://api.example.com/login",
            headers={"Content-Type": "application/json"},
            queryParameters={"redirect": "home"},
            body='{"username": "test"}',
            bodyEncoding=None,
        )

        assert request.method == "POST"
        assert request.headers["Content-Type"] == "application/json"
        assert request.queryParameters["redirect"] == "home"
        assert request.body == '{"username": "test"}'

    def test_to_dict(self):
        """Test converting request to dictionary."""
        request = HttpRequest(
            method="get",  # lowercase should be uppercased
            url="https://api.example.com/data",
            headers={"Accept": "application/json"},
            queryParameters={"id": "123"},
            body=None,
        )

        result = request.to_dict()

        assert result["method"] == "GET"
        assert result["url"] == "https://api.example.com/data"
        assert result["headers"] == {"Accept": "application/json"}
        assert result["queryParameters"] == {"id": "123"}
        assert "body" not in result  # None body should not be included

    def test_from_dict(self):
        """Test creating request from dictionary."""
        data = {
            "method": "DELETE",
            "url": "https://api.example.com/item/42",
            "headers": {"Authorization": "Bearer token"},
            "queryParameters": {},
            "body": None,
        }

        request = HttpRequest.from_dict(data)

        assert request.method == "DELETE"
        assert request.url == "https://api.example.com/item/42"
        assert request.headers["Authorization"] == "Bearer token"


class TestHttpResponse:
    """Tests for HttpResponse model."""

    def test_create_basic_response(self):
        """Test creating a basic HTTP response."""
        response = HttpResponse(status=200)

        assert response.status == 200
        assert response.headers == {}
        assert response.body == ""

    def test_create_response_with_all_fields(self):
        """Test creating a response with all fields."""
        response = HttpResponse(
            status=201,
            headers={"Content-Type": "application/json"},
            body='{"id": 123}',
        )

        assert response.status == 201
        assert response.headers["Content-Type"] == "application/json"
        assert response.body == '{"id": 123}'

    def test_to_dict(self):
        """Test converting response to dictionary."""
        response = HttpResponse(
            status=404,
            headers={"Content-Type": "text/plain"},
            body="Not found",
        )

        result = response.to_dict()

        assert result["status"] == 404
        assert result["headers"] == {"Content-Type": "text/plain"}
        assert result["body"] == "Not found"

    def test_from_dict(self):
        """Test creating response from dictionary."""
        data = {
            "status": 500,
            "headers": {"Content-Type": "application/json"},
            "body": '{"error": "Internal error"}',
        }

        response = HttpResponse.from_dict(data)

        assert response.status == 500
        assert response.body == '{"error": "Internal error"}'

    def test_get_body_bytes_text(self):
        """Test getting body bytes for text content."""
        response = HttpResponse(
            status=200,
            body="Hello, World!",
        )

        result = response.get_body_bytes()

        assert result == b"Hello, World!"

    def test_get_body_bytes_base64(self):
        """Test getting body bytes for base64-encoded content."""
        import base64

        original = b"\x89PNG\r\n\x1a\n"  # PNG header bytes
        encoded = base64.b64encode(original).decode("ascii")

        response = HttpResponse(
            status=200,
            body=encoded,
            bodyEncoding="base64",
        )

        result = response.get_body_bytes()

        assert result == original


class TestHttpMapping:
    """Tests for HttpMapping model."""

    def test_create_mapping(self):
        """Test creating a request/response mapping."""
        request = HttpRequest(method="GET", url="https://example.com")
        response = HttpResponse(status=200, body="OK")

        mapping = HttpMapping(request=request, response=response)

        assert mapping.request.method == "GET"
        assert mapping.response.status == 200

    def test_to_dict(self):
        """Test converting mapping to dictionary."""
        request = HttpRequest(
            method="POST",
            url="https://api.example.com/data",
            headers={"Content-Type": "application/json"},
            body='{"key": "value"}',
        )
        response = HttpResponse(
            status=201,
            headers={"Location": "/data/1"},
            body='{"id": 1}',
        )

        mapping = HttpMapping(request=request, response=response)
        result = mapping.to_dict()

        assert result["request"]["method"] == "POST"
        assert result["response"]["status"] == 201

    def test_from_dict(self):
        """Test creating mapping from dictionary."""
        data = {
            "request": {
                "method": "GET",
                "url": "https://example.com",
                "headers": {},
                "queryParameters": {},
            },
            "response": {
                "status": 200,
                "headers": {},
                "body": "OK",
            },
        }

        mapping = HttpMapping.from_dict(data)

        assert mapping.request.method == "GET"
        assert mapping.response.body == "OK"


class TestHttpMappings:
    """Tests for HttpMappings container."""

    def test_create_empty_mappings(self):
        """Test creating empty mappings container."""
        mappings = HttpMappings()

        assert len(mappings) == 0

    def test_add_mapping(self):
        """Test adding a mapping."""
        mappings = HttpMappings()
        request = HttpRequest(method="GET", url="https://example.com")
        response = HttpResponse(status=200)
        mapping = HttpMapping(request=request, response=response)

        mappings.add(mapping)

        assert len(mappings) == 1

    def test_to_json(self):
        """Test converting to JSON string."""
        mappings = HttpMappings()
        request = HttpRequest(method="GET", url="https://example.com")
        response = HttpResponse(status=200, body="OK")
        mappings.add(HttpMapping(request=request, response=response))

        json_str = mappings.to_json()
        data = json.loads(json_str)

        assert "mappings" in data
        assert len(data["mappings"]) == 1

    def test_from_json(self):
        """Test creating from JSON string."""
        json_str = """
        {
            "mappings": [
                {
                    "request": {
                        "method": "GET",
                        "url": "https://example.com"
                    },
                    "response": {
                        "status": 200,
                        "body": "OK"
                    }
                }
            ]
        }
        """

        mappings = HttpMappings.from_json(json_str)

        assert len(mappings) == 1
        assert mappings.mappings[0].request.method == "GET"

    def test_iterate_mappings(self):
        """Test iterating over mappings."""
        mappings = HttpMappings()

        for i in range(3):
            request = HttpRequest(method="GET", url=f"https://example.com/{i}")
            response = HttpResponse(status=200)
            mappings.add(HttpMapping(request=request, response=response))

        urls = [m.request.url for m in mappings]

        assert len(urls) == 3
        assert "https://example.com/1" in urls
