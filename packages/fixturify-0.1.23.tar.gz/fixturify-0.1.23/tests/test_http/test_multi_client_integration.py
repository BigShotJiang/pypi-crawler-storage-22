"""Integration test for multiple HTTP clients in a single test.

This test verifies that the @http decorator can record and playback
requests from multiple HTTP client libraries used together.

This is a critical business requirement - tests often use multiple
libraries (e.g., requests for simple calls, httpx for async, boto3 for AWS).
"""

import pytest

from fixturify.http_d import http, HttpTestConfig


# Check which clients are available
def _has_requests():
    try:
        import requests  # noqa: F401
        return True
    except ImportError:
        return False


def _has_httpx():
    try:
        import httpx  # noqa: F401
        return True
    except ImportError:
        return False


def _has_urllib3():
    try:
        import urllib3  # noqa: F401
        return True
    except ImportError:
        return False


def _has_aiohttp():
    try:
        import aiohttp  # noqa: F401
        return True
    except ImportError:
        return False


HAS_REQUESTS = _has_requests()
HAS_HTTPX = _has_httpx()
HAS_URLLIB3 = _has_urllib3()
HAS_AIOHTTP = _has_aiohttp()

# Skip if not enough clients available
pytestmark = pytest.mark.skipif(
    not (HAS_REQUESTS and HAS_HTTPX),
    reason="Requires at least requests and httpx"
)


API_BASE = "https://jsonplaceholder.typicode.com"


class TestMultiClientIntegration:
    """Test using multiple HTTP clients in a single test."""

    @http(path="./fixtures/multi_client_sync.json")
    def test_multiple_sync_clients(self):
        """Test using requests, httpx sync, and urllib3 together."""
        import requests
        import httpx

        # 1. Use requests to get a user
        resp1 = requests.get(f"{API_BASE}/users/1")
        assert resp1.status_code == 200
        user_data = resp1.json()
        assert "id" in user_data
        assert user_data["id"] == 1

        # 2. Use httpx sync to get posts for that user
        with httpx.Client() as client:
            resp2 = client.get(f"{API_BASE}/posts", params={"userId": 1})
            assert resp2.status_code == 200
            posts = resp2.json()
            assert isinstance(posts, list)

        # 3. Use requests again to get a specific post
        if posts:
            post_id = posts[0]["id"] if isinstance(posts[0], dict) else 1
            resp3 = requests.get(f"{API_BASE}/posts/{post_id}")
            assert resp3.status_code == 200

        # 4. Use httpx to get comments
        with httpx.Client() as client:
            resp4 = client.get(f"{API_BASE}/comments", params={"postId": 1})
            assert resp4.status_code == 200
            comments = resp4.json()
            assert isinstance(comments, list)

    @http(path="./fixtures/multi_client_with_urllib3.json")
    def test_requests_and_urllib3(self):
        """Test using requests and urllib3 together."""
        import requests
        import urllib3

        # 1. Use requests
        resp1 = requests.get(f"{API_BASE}/users/2")
        assert resp1.status_code == 200
        user = resp1.json()
        assert user["id"] == 2

        # 2. Use urllib3 directly
        http_pool = urllib3.HTTPSConnectionPool("jsonplaceholder.typicode.com", port=443)
        resp2 = http_pool.request("GET", "/todos/1")
        assert resp2.status == 200

        # 3. Back to requests
        resp3 = requests.get(f"{API_BASE}/albums/1")
        assert resp3.status_code == 200

    @pytest.mark.skipif(not HAS_AIOHTTP, reason="aiohttp not installed")
    @pytest.mark.asyncio
    @http(path="./fixtures/multi_client_async.json")
    async def test_multiple_async_clients(self):
        """Test using httpx async and aiohttp together."""
        import httpx
        import aiohttp

        # 1. Use httpx async
        async with httpx.AsyncClient() as client:
            resp1 = await client.get(f"{API_BASE}/users/3")
            assert resp1.status_code == 200
            user = resp1.json()
            assert user["id"] == 3

        # 2. Use aiohttp
        async with aiohttp.ClientSession() as session:
            async with session.get(f"{API_BASE}/posts/1") as resp2:
                assert resp2.status == 200
                post = await resp2.json()
                assert post["id"] == 1

        # 3. Back to httpx async
        async with httpx.AsyncClient() as client:
            resp3 = await client.get(f"{API_BASE}/comments", params={"postId": 1})
            assert resp3.status_code == 200

    @http(path="./fixtures/multi_client_sequential.json")
    def test_sequential_mixed_clients(self):
        """Test sequential calls with different clients."""
        import requests
        import httpx

        results = []

        # Alternate between clients
        for i in range(1, 4):
            # requests
            resp = requests.get(f"{API_BASE}/users/{i}")
            assert resp.status_code == 200
            results.append(("requests", resp.json()["id"]))

            # httpx
            with httpx.Client() as client:
                resp = client.get(f"{API_BASE}/posts/{i}")
                assert resp.status_code == 200
                results.append(("httpx", resp.json()["id"]))

        # Verify we got all results
        assert len(results) == 6
        assert results[0] == ("requests", 1)
        assert results[1] == ("httpx", 1)

    @http(path="./fixtures/multi_client_post_requests.json")
    def test_post_requests_multiple_clients(self):
        """Test POST requests with multiple clients."""
        import requests
        import httpx

        # 1. POST with requests
        resp1 = requests.post(
            f"{API_BASE}/posts",
            json={"title": "Test from requests", "body": "Content", "userId": 1}
        )
        assert resp1.status_code == 201

        # 2. POST with httpx
        with httpx.Client() as client:
            resp2 = client.post(
                f"{API_BASE}/posts",
                json={"title": "Test from httpx", "body": "Content", "userId": 2}
            )
            assert resp2.status_code == 201

        # 3. Another POST with requests
        resp3 = requests.post(
            f"{API_BASE}/posts",
            json={"title": "Another from requests", "body": "More content", "userId": 3}
        )
        assert resp3.status_code == 201

    @http(
        path="./fixtures/multi_client_with_config.json",
        config=HttpTestConfig(
            ignore_request_headers=["User-Agent", "Accept-Encoding"],
            exclude_request_headers=["X-Request-ID"],
        )
    )
    def test_multiple_clients_with_config(self):
        """Test multiple clients with custom config."""
        import requests
        import httpx

        # Requests with custom header
        resp1 = requests.get(
            f"{API_BASE}/users/1",
            headers={"X-Request-ID": "req-123", "X-Custom": "value1"}
        )
        assert resp1.status_code == 200

        # httpx with custom header
        with httpx.Client() as client:
            resp2 = client.get(
                f"{API_BASE}/users/2",
                headers={"X-Request-ID": "req-456", "X-Custom": "value2"}
            )
            assert resp2.status_code == 200


class TestMultiClientPlayback:
    """Test that playback works correctly with multiple clients."""

    @http(path="./fixtures/multi_client_playback_order.json")
    def test_playback_maintains_order(self):
        """Verify that playback returns responses in correct order."""
        import requests
        import httpx

        # These should match recorded responses in order
        resp1 = requests.get(f"{API_BASE}/users/1")
        user1 = resp1.json()

        with httpx.Client() as client:
            resp2 = client.get(f"{API_BASE}/users/2")
            user2 = resp2.json()

        resp3 = requests.get(f"{API_BASE}/users/3")
        user3 = resp3.json()

        # Verify correct data was returned for each
        assert user1["id"] == 1
        assert user2["id"] == 2
        assert user3["id"] == 3
