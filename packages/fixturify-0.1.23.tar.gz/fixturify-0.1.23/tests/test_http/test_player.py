"""Tests for HTTP player."""

import json
import pytest

from fixturify.http_d import NoMatchingRecordingError, RequestMismatchError, UnusedRecordingsError
from fixturify.http_d._player import HttpPlayer, _deserialize_body
from fixturify.http_d import HttpRequest


class TestDeserializeBody:
    """Tests for body deserialization."""

    def test_deserialize_none(self):
        """Test deserializing None body."""
        assert _deserialize_body(None) is None

    def test_deserialize_string(self):
        """Test deserializing string body."""
        assert _deserialize_body("Hello") == "Hello"

    def test_deserialize_dict(self):
        """Test deserializing dict body to JSON string."""
        result = _deserialize_body({"key": "value"})
        assert result == '{"key": "value"}'

    def test_deserialize_list(self):
        """Test deserializing list body to JSON string."""
        result = _deserialize_body([1, 2, 3])
        assert result == "[1, 2, 3]"


class TestHttpPlayer:
    """Tests for HttpPlayer class."""

    @pytest.fixture
    def recordings_file(self, tmp_path):
        """Create a test recordings file."""
        file_path = tmp_path / "recordings.json"
        data = {
            "mappings": [
                {
                    "request": {
                        "method": "GET",
                        "url": "https://api.example.com/users",
                        "headers": {"Accept": "application/json"},
                        "queryParameters": {},
                    },
                    "response": {
                        "status": 200,
                        "headers": {"Content-Type": "application/json"},
                        "body": {"users": [{"id": 1, "name": "John"}]},
                    },
                },
                {
                    "request": {
                        "method": "POST",
                        "url": "https://api.example.com/users",
                        "headers": {"Content-Type": "application/json"},
                        "queryParameters": {},
                        "body": {"name": "Jane"},
                    },
                    "response": {
                        "status": 201,
                        "headers": {"Content-Type": "application/json"},
                        "body": {"id": 2, "name": "Jane"},
                    },
                },
            ]
        }

        with open(file_path, "w") as f:
            json.dump(data, f)

        return file_path

    def test_load_mappings(self, recordings_file):
        """Test loading mappings from file."""
        player = HttpPlayer(recordings_file)

        assert len(player) == 2

    def test_find_response_exact_match(self, recordings_file):
        """Test finding response with exact match."""
        player = HttpPlayer(recordings_file)

        request = HttpRequest(
            method="GET",
            url="https://api.example.com/users",
            headers={"Accept": "application/json"},
        )

        response = player.find_response(request)

        assert response.status == 200
        assert '"users"' in response.body

    def test_find_response_no_match(self, recordings_file):
        """Test error when no match found."""
        player = HttpPlayer(recordings_file)

        request = HttpRequest(
            method="GET",
            url="https://api.example.com/items",  # Different URL
        )

        with pytest.raises(NoMatchingRecordingError) as exc_info:
            player.find_response(request)

        assert "NO MATCHING RECORDING FOUND" in str(exc_info.value)
        assert request.url in str(exc_info.value)

    def test_verify_all_used_success(self, recordings_file):
        """Test verify_all_used when all are used."""
        player = HttpPlayer(recordings_file)

        # Use both mappings
        player.find_response(
            HttpRequest(
                method="GET",
                url="https://api.example.com/users",
                headers={"Accept": "application/json"},
            )
        )
        player.find_response(
            HttpRequest(
                method="POST",
                url="https://api.example.com/users",
                headers={"Content-Type": "application/json"},
                body='{"name": "Jane"}',
            )
        )

        # Should not raise
        player.verify_all_used()

    def test_verify_all_used_failure(self, recordings_file):
        """Test verify_all_used when some unused."""
        player = HttpPlayer(recordings_file)

        # Only use one mapping
        player.find_response(
            HttpRequest(
                method="GET",
                url="https://api.example.com/users",
                headers={"Accept": "application/json"},
            )
        )

        with pytest.raises(UnusedRecordingsError) as exc_info:
            player.verify_all_used()

        assert "unused" in str(exc_info.value).lower()
        assert len(exc_info.value.unused_mappings) == 1

    def test_get_unused_mappings(self, recordings_file):
        """Test getting unused mappings."""
        player = HttpPlayer(recordings_file)

        # Use one mapping
        player.find_response(
            HttpRequest(
                method="GET",
                url="https://api.example.com/users",
                headers={"Accept": "application/json"},
            )
        )

        unused = player.get_unused_mappings()

        assert len(unused) == 1
        assert unused[0].request.method == "POST"

    def test_reset(self, recordings_file):
        """Test resetting used indices."""
        player = HttpPlayer(recordings_file)

        # Use a mapping
        player.find_response(
            HttpRequest(
                method="GET",
                url="https://api.example.com/users",
                headers={"Accept": "application/json"},
            )
        )

        assert len(player.used_indices) == 1

        player.reset()

        assert len(player.used_indices) == 0


class TestHttpPlayerWithBinaryFiles:
    """Tests for HttpPlayer with binary file references."""

    @pytest.fixture
    def recordings_with_binary(self, tmp_path):
        """Create recordings with binary file reference."""
        # Create __files directory
        files_dir = tmp_path / "__files"
        files_dir.mkdir()

        # Create binary file
        binary_content = b"\x89PNG\r\n\x1a\n" + b"fake png data"
        binary_file = files_dir / "image_abc123.png"
        with open(binary_file, "wb") as f:
            f.write(binary_content)

        # Create recordings file
        file_path = tmp_path / "recordings.json"
        data = {
            "mappings": [
                {
                    "request": {
                        "method": "GET",
                        "url": "https://example.com/image.png",
                        "headers": {},
                        "queryParameters": {},
                    },
                    "response": {
                        "status": 200,
                        "headers": {"Content-Type": "image/png"},
                        "bodyFileName": "image_abc123.png",
                    },
                }
            ]
        }

        with open(file_path, "w") as f:
            json.dump(data, f)

        return file_path, binary_content

    def test_load_binary_file(self, recordings_with_binary):
        """Test loading response with binary file."""
        file_path, expected_content = recordings_with_binary
        player = HttpPlayer(file_path)

        assert len(player) == 1

        request = HttpRequest(
            method="GET",
            url="https://example.com/image.png",
        )

        response = player.find_response(request)

        assert response.status == 200
        assert response.bodyFileName == "image_abc123.png"

        # Body bytes should be loaded
        body_bytes = response.get_body_bytes()
        assert body_bytes == expected_content

    def test_missing_binary_file(self, tmp_path):
        """Test error when binary file is missing."""
        # Create recordings with reference to non-existent file
        file_path = tmp_path / "recordings.json"
        data = {
            "mappings": [
                {
                    "request": {
                        "method": "GET",
                        "url": "https://example.com/image.png",
                        "headers": {},
                        "queryParameters": {},
                    },
                    "response": {
                        "status": 200,
                        "headers": {"Content-Type": "image/png"},
                        "bodyFileName": "missing_file.png",
                    },
                }
            ]
        }

        with open(file_path, "w") as f:
            json.dump(data, f)

        with pytest.raises(FileNotFoundError) as exc_info:
            HttpPlayer(file_path)

        assert "missing_file.png" in str(exc_info.value)


class TestHttpPlayerOptions:
    """Tests for HttpPlayer configuration options."""

    @pytest.fixture
    def simple_recordings(self, tmp_path):
        """Create simple recordings for option testing."""
        file_path = tmp_path / "recordings.json"
        data = {
            "mappings": [
                {
                    "request": {
                        "method": "POST",
                        "url": "https://api.example.com/data",
                        "headers": {},
                        "queryParameters": {},
                        "body": {"key": "value1"},
                    },
                    "response": {
                        "status": 200,
                        "body": "OK",
                    },
                }
            ]
        }

        with open(file_path, "w") as f:
            json.dump(data, f)

        return file_path

    def test_match_body_disabled(self, simple_recordings):
        """Test disabling body matching."""
        player = HttpPlayer(simple_recordings, match_body=False)

        # Different body should still match
        request = HttpRequest(
            method="POST",
            url="https://api.example.com/data",
            body='{"key": "different"}',
        )

        response = player.find_response(request)

        assert response.status == 200

    def test_match_body_enabled(self, simple_recordings):
        """Test body matching when enabled."""
        player = HttpPlayer(simple_recordings, match_body=True)

        # Different body should not match
        request = HttpRequest(
            method="POST",
            url="https://api.example.com/data",
            body='{"key": "different"}',
        )

        with pytest.raises(RequestMismatchError):
            player.find_response(request)
