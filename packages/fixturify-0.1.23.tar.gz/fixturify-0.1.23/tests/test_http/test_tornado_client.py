"""Integration tests for HTTP mock decorator using tornado.

These tests verify that the http_d module correctly intercepts
tornado HTTP client calls for recording and playback.
"""

import json
import pytest

from fixturify.http_d import http, HttpTestConfig


# Check if tornado is available
try:
    from tornado.httpclient import HTTPClient, AsyncHTTPClient, HTTPRequest

    HAS_TORNADO = True
except ImportError:
    HAS_TORNADO = False


# Base URL for the test API
API_BASE = "https://api.restful-api.dev"


@pytest.mark.skipif(not HAS_TORNADO, reason="tornado not installed")
class TestTornadoSyncIntegration:
    """Integration tests using tornado sync HTTPClient."""

    @http(path="./fixtures/tornado_sync_get_all_objects.json")
    def test_get_all_objects(self):
        """Test sync GET request to fetch all objects."""
        client = HTTPClient()
        try:
            response = client.fetch(f"{API_BASE}/objects")

            assert response.code == 200
            data = json.loads(response.body.decode("utf-8"))

            # Should return a list of objects
            assert isinstance(data, list)
            assert len(data) > 0

            # First object should have expected structure
            first_obj = data[0]
            assert "id" in first_obj
            assert "name" in first_obj
        finally:
            client.close()

    @http(path="./fixtures/tornado_sync_get_single_object.json")
    def test_get_single_object(self):
        """Test sync GET request to fetch a single object by ID."""
        client = HTTPClient()
        try:
            response = client.fetch(f"{API_BASE}/objects/1")

            assert response.code == 200
            data = json.loads(response.body.decode("utf-8"))

            assert data["id"] == "1"
            assert "name" in data
        finally:
            client.close()

    @http(path="./fixtures/tornado_sync_post_object.json")
    def test_create_object(self):
        """Test sync POST request to create a new object."""
        new_object = {"name": "Tornado Test Product", "data": {"color": "Orange"}}
        body = json.dumps(new_object)

        client = HTTPClient()
        try:
            request = HTTPRequest(
                f"{API_BASE}/objects",
                method="POST",
                body=body,
                headers={"Content-Type": "application/json"},
            )
            response = client.fetch(request)

            assert response.code == 200
            data = json.loads(response.body.decode("utf-8"))

            # Should return created object with ID
            assert "id" in data
            assert data["name"] == "Tornado Test Product"
        finally:
            client.close()


@pytest.mark.skipif(not HAS_TORNADO, reason="tornado not installed")
class TestTornadoAsyncIntegration:
    """Integration tests using tornado async AsyncHTTPClient."""

    @pytest.mark.asyncio
    @http(path="./fixtures/tornado_async_get_all_objects.json")
    async def test_get_all_objects_async(self):
        """Test async GET request to fetch all objects."""
        client = AsyncHTTPClient()
        try:
            response = await client.fetch(f"{API_BASE}/objects")

            assert response.code == 200
            data = json.loads(response.body.decode("utf-8"))

            # Should return a list of objects
            assert isinstance(data, list)
            assert len(data) > 0
        finally:
            client.close()

    @pytest.mark.asyncio
    @http(path="./fixtures/tornado_async_get_single_object.json")
    async def test_get_single_object_async(self):
        """Test async GET request to fetch a single object by ID."""
        client = AsyncHTTPClient()
        try:
            response = await client.fetch(f"{API_BASE}/objects/1")

            assert response.code == 200
            data = json.loads(response.body.decode("utf-8"))

            assert data["id"] == "1"
            assert "name" in data
        finally:
            client.close()

    @pytest.mark.asyncio
    @http(path="./fixtures/tornado_async_multiple.json")
    async def test_multiple_async_requests(self):
        """Test multiple async requests."""
        import asyncio

        client = AsyncHTTPClient()
        try:
            tasks = [
                client.fetch(f"{API_BASE}/objects/1"),
                client.fetch(f"{API_BASE}/objects/2"),
                client.fetch(f"{API_BASE}/objects/3"),
            ]
            responses = await asyncio.gather(*tasks)

            # All should succeed
            for response in responses:
                assert response.code == 200
        finally:
            client.close()


@pytest.mark.skipif(not HAS_TORNADO, reason="tornado not installed")
class TestTornadoWithConfig:
    """Tests with custom configuration."""

    @http(
        path="./fixtures/tornado_with_config.json",
        config=HttpTestConfig(
            ignore_request_headers=["X-Custom-Header"],
            exclude_request_headers=["X-Secret-Key"],
        ),
    )
    def test_with_custom_headers(self):
        """Test with custom headers that should be filtered."""
        client = HTTPClient()
        try:
            request = HTTPRequest(
                f"{API_BASE}/objects/1",
                headers={
                    "X-Custom-Header": "custom-value",
                    "X-Secret-Key": "secret-123",
                },
            )
            response = client.fetch(request)

            assert response.code == 200
        finally:
            client.close()
