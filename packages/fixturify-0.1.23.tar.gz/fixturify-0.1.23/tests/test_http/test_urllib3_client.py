"""Integration tests for HTTP mock decorator using urllib3.

These tests verify that the http_d module correctly intercepts
urllib3 HTTP calls for recording and playback.
"""

import pytest

from fixturify.http_d import http


# Check if urllib3 is available
try:
    import urllib3

    HAS_URLLIB3 = True
except ImportError:
    HAS_URLLIB3 = False


# Base URL for the test API
API_BASE = "https://api.restful-api.dev"


@pytest.mark.skipif(not HAS_URLLIB3, reason="urllib3 not installed")
class TestUrllib3Integration:
    """Integration tests using urllib3 library."""

    @http(path="./fixtures/urllib3_get_all_objects.json")
    def test_get_all_objects(self):
        """Test GET request to fetch all objects."""
        http_pool = urllib3.HTTPSConnectionPool("api.restful-api.dev", port=443)
        response = http_pool.request("GET", "/objects")

        assert response.status == 200
        import json

        data = json.loads(response.data.decode("utf-8"))

        # Should return a list of objects
        assert isinstance(data, list)
        assert len(data) > 0

        # First object should have expected structure
        first_obj = data[0]
        assert "id" in first_obj
        assert "name" in first_obj

    @http(path="./fixtures/urllib3_get_single_object.json")
    def test_get_single_object(self):
        """Test GET request to fetch a single object by ID."""
        http_pool = urllib3.HTTPSConnectionPool("api.restful-api.dev", port=443)
        response = http_pool.request("GET", "/objects/1")

        assert response.status == 200
        import json

        data = json.loads(response.data.decode("utf-8"))

        assert data["id"] == "1"
        assert "name" in data

    @http(path="./fixtures/urllib3_post_object.json")
    def test_create_object(self):
        """Test POST request to create a new object."""
        import json

        new_object = {"name": "Urllib3 Test Product", "data": {"color": "Red"}}

        http_pool = urllib3.HTTPSConnectionPool("api.restful-api.dev", port=443)
        response = http_pool.request(
            "POST",
            "/objects",
            body=json.dumps(new_object),
            headers={"Content-Type": "application/json"},
        )

        assert response.status == 200
        data = json.loads(response.data.decode("utf-8"))

        # Should return created object with ID
        assert "id" in data
        assert data["name"] == "Urllib3 Test Product"

    @http(path="./fixtures/urllib3_poolmanager.json")
    def test_with_poolmanager(self):
        """Test using urllib3 PoolManager."""
        http = urllib3.PoolManager()
        response = http.request("GET", f"{API_BASE}/objects/3")

        assert response.status == 200
        import json

        data = json.loads(response.data.decode("utf-8"))
        assert "id" in data


@pytest.mark.skipif(not HAS_URLLIB3, reason="urllib3 not installed")
class TestUrllib3NoDoubleIntercept:
    """Tests to verify no double interception with requests."""

    @http(path="./fixtures/urllib3_via_requests.json")
    def test_requests_uses_urllib3_no_double_record(self):
        """Verify that requests using urllib3 doesn't cause double recording."""
        try:
            import requests
        except ImportError:
            pytest.skip("requests not installed")

        # Make a request using requests (which uses urllib3 internally)
        response = requests.get(f"{API_BASE}/objects/1")
        assert response.status_code == 200

        # The recording should only have one entry, not two
        # (if double interception occurred, we'd have duplicate entries)
