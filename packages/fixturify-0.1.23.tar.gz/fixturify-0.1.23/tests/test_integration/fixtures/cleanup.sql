-- Cleanup test data
DROP TABLE IF EXISTS users;
