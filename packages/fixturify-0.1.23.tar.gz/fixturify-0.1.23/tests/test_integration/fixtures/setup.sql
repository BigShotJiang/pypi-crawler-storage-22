-- Setup test data
DROP TABLE IF EXISTS users;

CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) NOT NULL,
    name VARCHAR(255) NOT NULL
);

INSERT INTO users (id, email, name) VALUES
    (1, 'john@example.com', 'John Doe'),
    (2, 'jane@example.com', 'Jane Smith');
