"""Nested test package for path resolution tests."""
