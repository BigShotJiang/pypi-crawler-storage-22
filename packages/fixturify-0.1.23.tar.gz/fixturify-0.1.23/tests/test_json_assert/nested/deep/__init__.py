"""Deep nested test package for path resolution tests."""
