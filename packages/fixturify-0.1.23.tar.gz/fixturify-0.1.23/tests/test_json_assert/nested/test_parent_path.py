"""Tests for JsonAssert with parent directory paths (../)."""

import pytest
from dataclasses import dataclass

from fixturify.json_assert import JsonAssert


@dataclass
class User:
    name: str
    age: int


@dataclass
class UserWithId:
    name: str
    age: int
    id: int


class TestJsonAssertParentPath:
    """Tests for JsonAssert.compare_to_file() with ../ path patterns."""

    def test_dict_with_parent_path(self):
        """Test comparing dict using ../ path."""
        data = {"name": "John", "age": 30}
        JsonAssert(data).compare_to_file("../fixtures/user.json")

    def test_dataclass_with_parent_path(self):
        """Test comparing dataclass using ../ path."""
        user = User(name="John", age=30)
        JsonAssert(user).compare_to_file("../fixtures/user.json")

    def test_list_with_parent_path(self):
        """Test comparing list using ../ path."""
        users = [
            {"name": "John", "age": 30, "id": 1},
            {"name": "Jane", "age": 25, "id": 2},
        ]
        JsonAssert(users).compare_to_file("../fixtures/users.json")

    def test_ignore_with_parent_path(self):
        """Test ignore() with ../ path."""
        data = {"name": "John", "age": 99}  # age is different
        JsonAssert(data).ignore("age").compare_to_file("../fixtures/user.json")

    def test_options_with_parent_path(self):
        """Test options() with ../ path."""
        data = {"tags": ["c", "b", "a"]}  # Different order
        JsonAssert(data).options(ignore_order=True).compare_to_file(
            "../fixtures/unordered_list.json"
        )

    def test_numeric_tolerance_with_parent_path(self):
        """Test numeric_tolerance with ../ path."""
        data = {"value": 3.14}
        JsonAssert(data).options(numeric_tolerance=0.01).compare_to_file(
            "../fixtures/float_values.json"
        )


class TestJsonAssertParentPathMismatch:
    """Tests for JsonAssert mismatch with ../ paths."""

    def test_mismatch_raises_error_with_parent_path(self):
        """Test that mismatch raises AssertionError with ../ path."""
        data = {"name": "Jane", "age": 25}

        with pytest.raises(AssertionError) as exc_info:
            JsonAssert(data).compare_to_file("../fixtures/user.json")

        assert "JSON COMPARISON FAILED" in str(exc_info.value)


class TestJsonAssertParentPathWithWildcard:
    """Tests for JsonAssert wildcard ignore with ../ paths."""

    def test_wildcard_ignore_with_parent_path(self):
        """Test wildcard ignore with ../ path."""
        users = [
            {"name": "John", "age": 30, "id": 999},
            {"name": "Jane", "age": 25, "id": 888},
        ]
        JsonAssert(users).ignore("root[*]['id']").compare_to_file(
            "../fixtures/users.json"
        )
