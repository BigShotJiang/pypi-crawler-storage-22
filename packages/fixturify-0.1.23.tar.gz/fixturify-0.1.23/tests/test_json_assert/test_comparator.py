"""Tests for _Comparator class."""

from fixturify.json_assert._comparator import _Comparator


class TestComparatorBasic:
    """Basic tests for _Comparator."""

    def test_equal_dicts(self):
        """Test that equal dicts are considered equal."""
        comparator = _Comparator()
        actual = {"name": "John", "age": 30}
        expected = {"name": "John", "age": 30}

        result = comparator.compare(actual, expected)

        assert result.is_equal is True
        assert result.diff is None

    def test_different_values(self):
        """Test that different values are detected."""
        comparator = _Comparator()
        actual = {"name": "Jane", "age": 30}
        expected = {"name": "John", "age": 30}

        result = comparator.compare(actual, expected)

        assert result.is_equal is False
        assert result.diff is not None

    def test_missing_key(self):
        """Test that missing keys are detected."""
        comparator = _Comparator()
        actual = {"name": "John"}
        expected = {"name": "John", "age": 30}

        result = comparator.compare(actual, expected)

        assert result.is_equal is False

    def test_extra_key(self):
        """Test that extra keys are detected."""
        comparator = _Comparator()
        actual = {"name": "John", "age": 30, "extra": "value"}
        expected = {"name": "John", "age": 30}

        result = comparator.compare(actual, expected)

        assert result.is_equal is False


class TestComparatorExcludePaths:
    """Tests for exclude paths."""

    def test_exclude_simple_path(self):
        """Test excluding a simple path."""
        comparator = _Comparator(exclude_paths=["age"])
        actual = {"name": "John", "age": 99}
        expected = {"name": "John", "age": 30}

        result = comparator.compare(actual, expected)

        assert result.is_equal is True

    def test_exclude_with_root_prefix(self):
        """Test excluding with explicit root prefix."""
        comparator = _Comparator(exclude_paths=["root['age']"])
        actual = {"name": "John", "age": 99}
        expected = {"name": "John", "age": 30}

        result = comparator.compare(actual, expected)

        assert result.is_equal is True

    def test_exclude_nested_path(self):
        """Test excluding a nested path."""
        comparator = _Comparator(exclude_paths=["user.profile.age"])
        actual = {"user": {"profile": {"age": 99, "city": "NYC"}}}
        expected = {"user": {"profile": {"age": 30, "city": "NYC"}}}

        result = comparator.compare(actual, expected)

        assert result.is_equal is True


class TestComparatorWildcard:
    """Tests for wildcard path exclusion."""

    def test_wildcard_in_list(self):
        """Test wildcard [*] in path."""
        comparator = _Comparator(exclude_paths=["root[*]['id']"])
        actual = [{"name": "John", "id": 99}, {"name": "Jane", "id": 88}]
        expected = [{"name": "John", "id": 1}, {"name": "Jane", "id": 2}]

        result = comparator.compare(actual, expected)

        assert result.is_equal is True


class TestComparatorOptions:
    """Tests for comparison options."""

    def test_ignore_order(self):
        """Test ignore_order option."""
        comparator = _Comparator(ignore_order=True)
        actual = {"tags": ["c", "b", "a"]}
        expected = {"tags": ["a", "b", "c"]}

        result = comparator.compare(actual, expected)

        assert result.is_equal is True

    def test_numeric_tolerance(self):
        """Test numeric_tolerance option."""
        comparator = _Comparator(numeric_tolerance=0.01)
        actual = {"value": 3.14}
        expected = {"value": 3.145}

        result = comparator.compare(actual, expected)

        assert result.is_equal is True


class TestComparatorPathNormalization:
    """Tests for path normalization."""

    def test_normalize_simple_field(self):
        """Test normalizing simple field name."""
        comparator = _Comparator()

        result = comparator._normalize_path("id")
        assert result == "root['id']"

    def test_normalize_dot_notation(self):
        """Test normalizing dot notation."""
        comparator = _Comparator()

        result = comparator._normalize_path("user.name")
        assert result == "root['user']['name']"

    def test_normalize_mixed_notation(self):
        """Test normalizing mixed notation."""
        comparator = _Comparator()

        result = comparator._normalize_path("users[0].name")
        assert result == "root['users'][0]['name']"

    def test_normalize_preserves_root_prefix(self):
        """Test that existing root prefix is preserved."""
        comparator = _Comparator()

        result = comparator._normalize_path("root['id']")
        assert result == "root['id']"

    def test_normalize_mixed_bracket_and_dot(self):
        """Test normalizing mixed notation that starts with root[."""
        comparator = _Comparator()

        # This was a bug: paths starting with root[ but containing dots weren't normalized
        result = comparator._normalize_path("root['users'][*].id")
        assert result == "root['users'][*]['id']"

        result = comparator._normalize_path("root['data'][0].nested.value")
        assert result == "root['data'][0]['nested']['value']"


class TestComparatorWildcardConversion:
    """Tests for wildcard to regex conversion."""

    def test_wildcard_to_regex(self):
        """Test converting wildcard to regex."""
        comparator = _Comparator()

        result = comparator._convert_wildcard_to_regex("root['users'][*]['id']")
        assert r"\[\d+\]" in result
        assert r"\[\*\]" not in result

    def test_has_wildcard(self):
        """Test wildcard detection."""
        comparator = _Comparator()

        assert comparator._has_wildcard("root[*]['id']") is True
        assert comparator._has_wildcard("root[0]['id']") is False
