"""Tests for _Normalizer class."""

import pytest
from dataclasses import dataclass

from fixturify.json_assert._normalizer import _Normalizer


@dataclass
class User:
    name: str
    age: int


class TestNormalizerBasic:
    """Basic tests for _Normalizer."""

    def test_normalize_dict(self):
        """Test normalizing a dict (returns as-is)."""
        normalizer = _Normalizer()
        data = {"name": "John", "age": 30}

        result = normalizer.normalize(data)

        assert result == data
        assert result is data  # Same object

    def test_normalize_list_of_dicts(self):
        """Test normalizing a list of dicts."""
        normalizer = _Normalizer()
        data = [{"name": "John"}, {"name": "Jane"}]

        result = normalizer.normalize(data)

        assert result == data

    def test_normalize_json_string(self):
        """Test normalizing a JSON string."""
        normalizer = _Normalizer()
        data = '{"name": "John", "age": 30}'

        result = normalizer.normalize(data)

        assert result == {"name": "John", "age": 30}

    def test_normalize_dataclass(self):
        """Test normalizing a dataclass."""
        normalizer = _Normalizer()
        user = User(name="John", age=30)

        result = normalizer.normalize(user)

        assert result == {"name": "John", "age": 30}

    def test_normalize_list_of_dataclasses(self):
        """Test normalizing a list of dataclasses."""
        normalizer = _Normalizer()
        users = [User(name="John", age=30), User(name="Jane", age=25)]

        result = normalizer.normalize(users)

        assert result == [{"name": "John", "age": 30}, {"name": "Jane", "age": 25}]


class TestNormalizerNested:
    """Tests for nested data normalization."""

    def test_normalize_nested_dict(self):
        """Test normalizing nested dict."""
        normalizer = _Normalizer()
        data = {"user": {"name": "John", "profile": {"age": 30}}}

        result = normalizer.normalize(data)

        assert result == data

    def test_normalize_list_with_nested(self):
        """Test normalizing list with nested structures."""
        normalizer = _Normalizer()
        data = [{"users": [{"name": "John"}]}]

        result = normalizer.normalize(data)

        assert result == data


class TestNormalizerErrors:
    """Tests for error handling."""

    def test_invalid_json_string(self):
        """Test that invalid JSON string raises ValueError."""
        normalizer = _Normalizer()

        # Plain string that's not JSON
        data = "not json"

        # This should raise ValueError since we now reject non-JSON strings
        with pytest.raises(ValueError) as exc_info:
            normalizer.normalize(data)

        assert "not valid JSON" in str(exc_info.value)

    def test_json_primitive_string_rejected(self):
        """Test that JSON string containing a primitive is rejected."""
        normalizer = _Normalizer()

        # Valid JSON, but just a string primitive (not object or array)
        data = '"just a string"'

        with pytest.raises(ValueError) as exc_info:
            normalizer.normalize(data)

        assert "must contain an object or array" in str(exc_info.value)
