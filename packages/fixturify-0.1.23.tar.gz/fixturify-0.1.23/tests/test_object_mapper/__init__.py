"""Tests for object_mapper module."""
