"""Tests for ObjectMapper with circular references and shared objects."""

import pytest
from typing import Optional, List

from fixturify.object_mapper import ObjectMapper


class Node:
    """A simple node for testing circular references."""

    def __init__(self, value: int, parent: Optional["Node"] = None):
        self.value = value
        self.parent = parent


class TreeNode:
    """A tree node with children for testing."""

    def __init__(self, name: str, children: List["TreeNode"] = None):
        self.name = name
        self.children = children or []


class SharedData:
    """A class for testing shared object references."""

    def __init__(self, id: int, data: str):
        self.id = id
        self.data = data


class Container:
    """A container referencing shared data."""

    def __init__(self, name: str, data: "SharedData"):
        self.name = name
        self.data = data


class TestCircularReferences:
    """Tests for handling circular references."""

    def test_simple_circular_reference(self):
        """Test serialization with simple circular reference."""
        child = Node(value=1)
        parent = Node(value=0)
        child.parent = parent
        parent.parent = child  # Circular reference

        data = ObjectMapper(parent).to_json()

        # The circular reference should be represented as $ref
        assert data["value"] == 0
        assert data["parent"]["value"] == 1
        assert "$ref" in data["parent"]["parent"]

    def test_self_referential(self):
        """Test serialization with self-reference."""
        node = Node(value=42)
        node.parent = node  # Self-reference

        data = ObjectMapper(node).to_json()

        assert data["value"] == 42
        assert "$ref" in data["parent"]
        assert data["parent"]["$ref"] == "#"

    def test_tree_structure(self):
        """Test serialization of tree structure without circular refs."""
        root = TreeNode(name="root")
        child1 = TreeNode(name="child1")
        child2 = TreeNode(name="child2")
        root.children = [child1, child2]

        data = ObjectMapper(root).to_json()

        assert data["name"] == "root"
        assert len(data["children"]) == 2
        assert data["children"][0]["name"] == "child1"
        assert data["children"][1]["name"] == "child2"


class TestSharedObjects:
    """Tests for handling shared object references (diamond pattern)."""

    def test_shared_object_diamond_pattern(self):
        """Test serialization with shared object references through a container object."""

        class Root:
            def __init__(self, a: Container, b: Container):
                self.a = a
                self.b = b

        shared = SharedData(id=1, data="shared data")
        container_a = Container(name="A", data=shared)
        container_b = Container(name="B", data=shared)

        root = Root(a=container_a, b=container_b)

        data = ObjectMapper(root).to_json()

        # First occurrence should be fully serialized
        assert data["a"]["data"]["id"] == 1
        assert data["a"]["data"]["data"] == "shared data"

        # Second occurrence should be a reference
        assert "$ref" in data["b"]["data"]


class TestMaxDepth:
    """Tests for max depth protection."""

    def test_deeply_nested_structure(self):
        """Test that very deep nesting doesn't cause issues."""
        # Create a chain of 50 nodes (should be fine)
        current = Node(value=0)
        for i in range(1, 50):
            new_node = Node(value=i)
            new_node.parent = current
            current = new_node

        # This should work fine
        data = ObjectMapper(current).to_json()

        assert data["value"] == 49

    def test_exceeds_max_depth(self):
        """Test that exceeding max depth raises error."""
        # Create a very deep chain (more than default max depth)
        current = Node(value=0)
        for i in range(1, 150):  # More than MAX_DEPTH (100)
            new_node = Node(value=i)
            new_node.parent = current
            current = new_node

        with pytest.raises(ValueError) as exc_info:
            ObjectMapper(current).to_json()

        assert "Maximum serialization depth" in str(exc_info.value)
