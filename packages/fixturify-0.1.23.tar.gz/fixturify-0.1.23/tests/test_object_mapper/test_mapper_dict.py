"""Tests for ObjectMapper with dictionaries."""

import json
from datetime import datetime
from enum import Enum

from fixturify.object_mapper import ObjectMapper


class Color(Enum):
    RED = "red"
    GREEN = "green"
    BLUE = "blue"


class TestDictSerialization:
    """Tests for serializing dicts to JSON."""

    def test_simple_dict_to_json(self):
        """Test serializing a simple dict."""
        data = {"name": "John", "age": 30}
        result = ObjectMapper(data).to_json()

        assert result == data

    def test_nested_dict_to_json(self):
        """Test serializing nested dict."""
        data = {"name": "John", "address": {"city": "NYC", "country": "USA"}}
        result = ObjectMapper(data).to_json()

        assert result == data

    def test_dict_with_list_to_json(self):
        """Test serializing dict with list."""
        data = {"tags": ["python", "testing", "json"]}
        result = ObjectMapper(data).to_json()

        assert result == data

    def test_dict_with_none_to_json(self):
        """Test that None values in dict are serialized."""
        data = {"name": "John", "email": None}
        result = ObjectMapper(data).to_json()

        assert result == data

    def test_dict_with_datetime_to_json(self):
        """Test serializing dict with datetime."""
        dt = datetime(2024, 1, 15, 10, 30, 0)
        data = {"name": "John", "created_at": dt}
        result = ObjectMapper(data).to_json()

        assert result == {"name": "John", "created_at": "2024-01-15T10:30:00"}

    def test_dict_with_enum_to_json(self):
        """Test serializing dict with enum."""
        data = {"color": Color.RED}
        result = ObjectMapper(data).to_json()

        assert result == {"color": "red"}

    def test_list_of_dicts_to_json(self):
        """Test serializing list of dicts."""
        data = [{"name": "John", "age": 30}, {"name": "Jane", "age": 25}]
        result = ObjectMapper(data).to_json()

        assert result == data

    def test_dict_pretty_print(self):
        """Test serializing with indentation."""
        data = {"name": "John", "age": 30}
        json_str = ObjectMapper(data).to_json_string(indent=2)

        # Should contain newlines for pretty printing
        assert "\n" in json_str
        assert json.loads(json_str) == data


class TestDictRoundTrip:
    """Test JSON string round trips."""

    def test_json_string_round_trip(self):
        """Test that JSON string input can be re-serialized."""
        original = '{"name": "John", "age": 30}'
        result = ObjectMapper(original).to_json()

        assert result == {"name": "John", "age": 30}

    def test_json_array_string_round_trip(self):
        """Test that JSON array string can be re-serialized."""
        original = '[{"name": "John"}, {"name": "Jane"}]'
        result = ObjectMapper(original).to_json()

        assert result == [{"name": "John"}, {"name": "Jane"}]
