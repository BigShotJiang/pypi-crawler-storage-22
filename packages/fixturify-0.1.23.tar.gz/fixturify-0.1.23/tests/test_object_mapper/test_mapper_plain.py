"""Tests for ObjectMapper with plain Python objects."""

from typing import Optional

from fixturify.object_mapper import ObjectMapper


class SimplePerson:
    """A simple plain Python class."""

    def __init__(self, name: str, age: int):
        self.name = name
        self.age = age


class PersonWithOptional:
    """A class with optional attributes."""

    def __init__(self, name: str, email: Optional[str] = None):
        self.name = name
        self.email = email


class PersonWithPrivate:
    """A class with private attributes."""

    def __init__(self, name: str, internal_id: str):
        self.name = name
        self._internal_id = internal_id  # Single underscore - should be serialized


class Address:
    """Address class for nested testing."""

    def __init__(self, city: str, country: str):
        self.city = city
        self.country = country


class PersonWithAddress:
    """A class with nested object."""

    def __init__(self, name: str, address: Address):
        self.name = name
        self.address = address


class TestPlainObjectSerialization:
    """Tests for serializing plain Python objects."""

    def test_simple_object_to_json(self):
        """Test serializing a simple plain object."""
        person = SimplePerson(name="John", age=30)
        data = ObjectMapper(person).to_json()

        assert data == {"name": "John", "age": 30}

    def test_object_with_none_to_json(self):
        """Test that None values are serialized."""
        person = PersonWithOptional(name="John", email=None)
        data = ObjectMapper(person).to_json()

        assert data == {"name": "John", "email": None}

    def test_object_with_single_underscore_to_json(self):
        """Test that single underscore attributes ARE serialized."""
        person = PersonWithPrivate(name="John", internal_id="abc123")
        data = ObjectMapper(person).to_json()

        assert "name" in data
        assert "_internal_id" in data
        assert data["_internal_id"] == "abc123"

    def test_nested_object_to_json(self):
        """Test serializing nested plain objects."""
        person = PersonWithAddress(
            name="John", address=Address(city="NYC", country="USA")
        )
        data = ObjectMapper(person).to_json()

        assert data == {"name": "John", "address": {"city": "NYC", "country": "USA"}}

    def test_list_of_objects_to_json(self):
        """Test serializing a list of plain objects."""
        people = [SimplePerson(name="John", age=30), SimplePerson(name="Jane", age=25)]
        data = ObjectMapper(people).to_json()

        assert data == [{"name": "John", "age": 30}, {"name": "Jane", "age": 25}]


class TestPlainObjectDeserialization:
    """Tests for deserializing JSON to plain Python objects."""

    def test_json_to_simple_object(self):
        """Test deserializing JSON to simple plain object."""
        json_str = '{"name": "John", "age": 30}'
        person = ObjectMapper(json_str).to_object(SimplePerson)

        assert isinstance(person, SimplePerson)
        assert person.name == "John"
        assert person.age == 30

    def test_dict_to_simple_object(self):
        """Test deserializing dict to simple plain object."""
        data = {"name": "John", "age": 30}
        person = ObjectMapper(data).to_object(SimplePerson)

        assert isinstance(person, SimplePerson)
        assert person.name == "John"
        assert person.age == 30

    def test_json_list_to_object_list(self):
        """Test deserializing JSON array to list of plain objects."""
        json_str = '[{"name": "John", "age": 30}, {"name": "Jane", "age": 25}]'
        people = ObjectMapper(json_str).to_object(SimplePerson)

        assert isinstance(people, list)
        assert len(people) == 2
        assert all(isinstance(p, SimplePerson) for p in people)
        assert people[0].name == "John"
        assert people[1].name == "Jane"


class TestPlainObjectRoundTrip:
    """Test serialization/deserialization round trips for plain objects."""

    def test_simple_round_trip(self):
        """Test round trip for simple plain object."""
        original = SimplePerson(name="John", age=30)
        data = ObjectMapper(original).to_json()
        restored = ObjectMapper(data).to_object(SimplePerson)

        assert restored.name == original.name
        assert restored.age == original.age

    def test_list_round_trip(self):
        """Test round trip for list of plain objects."""
        original = [
            SimplePerson(name="John", age=30),
            SimplePerson(name="Jane", age=25),
        ]
        data = ObjectMapper(original).to_json()
        restored = ObjectMapper(data).to_object(SimplePerson)

        assert len(restored) == len(original)
        for orig, rest in zip(original, restored):
            assert rest.name == orig.name
            assert rest.age == orig.age
