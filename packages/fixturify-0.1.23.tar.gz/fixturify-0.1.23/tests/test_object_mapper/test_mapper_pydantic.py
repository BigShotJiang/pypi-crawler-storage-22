"""Tests for Pydantic v2 model serialization and deserialization."""

from datetime import datetime, date
from typing import List, Optional
from enum import Enum
from uuid import UUID

from pydantic import BaseModel, Field

from fixturify.object_mapper import ObjectMapper


class Status(Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"


class Address(BaseModel):
    """Nested Pydantic model for address."""

    street: str
    city: str
    country: str = "USA"


class User(BaseModel):
    """Simple Pydantic v2 model."""

    name: str
    age: int
    email: Optional[str] = None


class UserWithAddress(BaseModel):
    """Pydantic model with nested model."""

    name: str
    address: Address


class UserWithTags(BaseModel):
    """Pydantic model with list field."""

    name: str
    tags: List[str]


class UserWithNestedList(BaseModel):
    """Pydantic model with list of nested models."""

    name: str
    addresses: List[Address]


class UserWithDatetime(BaseModel):
    """Pydantic model with datetime field."""

    name: str
    created_at: datetime
    birth_date: Optional[date] = None


class UserWithEnum(BaseModel):
    """Pydantic model with enum field."""

    name: str
    status: Status


class UserWithUUID(BaseModel):
    """Pydantic model with UUID field."""

    id: UUID
    name: str


class UserWithAlias(BaseModel):
    """Pydantic model with field alias."""

    user_name: str = Field(alias="userName")
    user_age: int = Field(alias="userAge")

    model_config = {"populate_by_name": True}


class Company(BaseModel):
    """Complex Pydantic model with multiple nested models."""

    name: str
    ceo: User
    employees: List[User]
    headquarters: Address


class TestPydanticSerialization:
    """Tests for Pydantic v2 model to JSON serialization."""

    def test_simple_model_to_json(self):
        """Test serializing a simple Pydantic model."""
        user = User(name="John", age=30, email="john@example.com")
        data = ObjectMapper(user).to_json()

        assert data["name"] == "John"
        assert data["age"] == 30
        assert data["email"] == "john@example.com"

    def test_model_with_none_to_json(self):
        """Test serializing Pydantic model with None values."""
        user = User(name="John", age=30, email=None)
        data = ObjectMapper(user).to_json()

        assert data["name"] == "John"
        assert data["age"] == 30
        assert data["email"] is None

    def test_nested_model_to_json(self):
        """Test serializing Pydantic model with nested model."""
        user = UserWithAddress(
            name="John", address=Address(street="123 Main St", city="Boston")
        )
        data = ObjectMapper(user).to_json()

        assert data["name"] == "John"
        assert data["address"]["street"] == "123 Main St"
        assert data["address"]["city"] == "Boston"
        assert data["address"]["country"] == "USA"

    def test_model_with_list_to_json(self):
        """Test serializing Pydantic model with list field."""
        user = UserWithTags(name="John", tags=["python", "testing"])
        data = ObjectMapper(user).to_json()

        assert data["name"] == "John"
        assert data["tags"] == ["python", "testing"]

    def test_model_with_nested_list_to_json(self):
        """Test serializing Pydantic model with list of nested models."""
        user = UserWithNestedList(
            name="John",
            addresses=[
                Address(street="123 Main St", city="Boston"),
                Address(street="456 Oak Ave", city="NYC", country="USA"),
            ],
        )
        data = ObjectMapper(user).to_json()

        assert data["name"] == "John"
        assert len(data["addresses"]) == 2
        assert data["addresses"][0]["city"] == "Boston"
        assert data["addresses"][1]["city"] == "NYC"

    def test_model_with_datetime_to_json(self):
        """Test serializing Pydantic model with datetime."""
        dt = datetime(2024, 1, 15, 10, 30, 0)
        user = UserWithDatetime(
            name="John", created_at=dt, birth_date=date(1990, 5, 15)
        )
        data = ObjectMapper(user).to_json()

        assert data["name"] == "John"
        assert data["created_at"] == "2024-01-15T10:30:00"
        assert data["birth_date"] == "1990-05-15"

    def test_model_with_enum_to_json(self):
        """Test serializing Pydantic model with enum."""
        user = UserWithEnum(name="John", status=Status.ACTIVE)
        data = ObjectMapper(user).to_json()

        assert data["name"] == "John"
        assert data["status"] == "active"

    def test_model_with_uuid_to_json(self):
        """Test serializing Pydantic model with UUID."""
        uid = UUID("550e8400-e29b-41d4-a716-446655440000")
        user = UserWithUUID(id=uid, name="John")
        data = ObjectMapper(user).to_json()

        assert data["id"] == "550e8400-e29b-41d4-a716-446655440000"
        assert data["name"] == "John"

    def test_list_of_models_to_json(self):
        """Test serializing list of Pydantic models."""
        users = [
            User(name="John", age=30),
            User(name="Jane", age=25, email="jane@example.com"),
        ]
        data = ObjectMapper(users).to_json()

        assert len(data) == 2
        assert data[0]["name"] == "John"
        assert data[1]["name"] == "Jane"
        assert data[1]["email"] == "jane@example.com"

    def test_complex_model_to_json(self):
        """Test serializing complex Pydantic model with multiple nesting."""
        company = Company(
            name="Acme Corp",
            ceo=User(name="Alice", age=45),
            employees=[User(name="Bob", age=35), User(name="Charlie", age=28)],
            headquarters=Address(street="100 Corp Blvd", city="San Francisco"),
        )
        data = ObjectMapper(company).to_json()

        assert data["name"] == "Acme Corp"
        assert data["ceo"]["name"] == "Alice"
        assert len(data["employees"]) == 2
        assert data["headquarters"]["city"] == "San Francisco"


class TestPydanticDeserialization:
    """Tests for JSON to Pydantic v2 model deserialization."""

    def test_json_to_simple_model(self):
        """Test deserializing JSON to simple Pydantic model."""
        json_str = '{"name": "John", "age": 30, "email": "john@example.com"}'
        user = ObjectMapper(json_str).to_object(User)

        assert isinstance(user, User)
        assert user.name == "John"
        assert user.age == 30
        assert user.email == "john@example.com"

    def test_dict_to_simple_model(self):
        """Test deserializing dict to Pydantic model."""
        data = {"name": "John", "age": 30}
        user = ObjectMapper(data).to_object(User)

        assert isinstance(user, User)
        assert user.name == "John"
        assert user.age == 30
        assert user.email is None

    def test_json_to_nested_model(self):
        """Test deserializing JSON to Pydantic model with nested model."""
        json_str = """
        {
            "name": "John",
            "address": {
                "street": "123 Main St",
                "city": "Boston",
                "country": "USA"
            }
        }
        """
        user = ObjectMapper(json_str).to_object(UserWithAddress)

        assert isinstance(user, UserWithAddress)
        assert user.name == "John"
        assert isinstance(user.address, Address)
        assert user.address.city == "Boston"

    def test_json_to_model_with_list(self):
        """Test deserializing JSON to Pydantic model with list."""
        json_str = '{"name": "John", "tags": ["python", "testing"]}'
        user = ObjectMapper(json_str).to_object(UserWithTags)

        assert isinstance(user, UserWithTags)
        assert user.name == "John"
        assert user.tags == ["python", "testing"]

    def test_json_to_model_with_nested_list(self):
        """Test deserializing JSON to Pydantic model with list of nested models."""
        json_str = """
        {
            "name": "John",
            "addresses": [
                {"street": "123 Main St", "city": "Boston", "country": "USA"},
                {"street": "456 Oak Ave", "city": "NYC", "country": "USA"}
            ]
        }
        """
        user = ObjectMapper(json_str).to_object(UserWithNestedList)

        assert isinstance(user, UserWithNestedList)
        assert len(user.addresses) == 2
        assert all(isinstance(addr, Address) for addr in user.addresses)

    def test_json_list_to_model_list(self):
        """Test deserializing JSON list to list of Pydantic models."""
        json_str = '[{"name": "John", "age": 30}, {"name": "Jane", "age": 25}]'
        users = ObjectMapper(json_str).to_object(User)

        assert isinstance(users, list)
        assert len(users) == 2
        assert all(isinstance(u, User) for u in users)
        assert users[0].name == "John"
        assert users[1].name == "Jane"

    def test_json_to_model_with_enum(self):
        """Test deserializing JSON with enum value."""
        json_str = '{"name": "John", "status": "active"}'
        user = ObjectMapper(json_str).to_object(UserWithEnum)

        assert isinstance(user, UserWithEnum)
        assert user.status == Status.ACTIVE

    def test_json_to_complex_model(self):
        """Test deserializing complex nested model."""
        json_str = """
        {
            "name": "Acme Corp",
            "ceo": {"name": "Alice", "age": 45},
            "employees": [
                {"name": "Bob", "age": 35},
                {"name": "Charlie", "age": 28}
            ],
            "headquarters": {
                "street": "100 Corp Blvd",
                "city": "San Francisco",
                "country": "USA"
            }
        }
        """
        company = ObjectMapper(json_str).to_object(Company)

        assert isinstance(company, Company)
        assert company.name == "Acme Corp"
        assert isinstance(company.ceo, User)
        assert company.ceo.name == "Alice"
        assert len(company.employees) == 2
        assert isinstance(company.headquarters, Address)


class TestPydanticRoundTrip:
    """Tests for round-trip serialization/deserialization."""

    def test_simple_round_trip(self):
        """Test round-trip for simple model."""
        original = User(name="John", age=30, email="john@example.com")
        data = ObjectMapper(original).to_json()
        restored = ObjectMapper(data).to_object(User)

        assert restored.name == original.name
        assert restored.age == original.age
        assert restored.email == original.email

    def test_nested_round_trip(self):
        """Test round-trip for nested model."""
        original = UserWithAddress(
            name="John", address=Address(street="123 Main St", city="Boston")
        )
        data = ObjectMapper(original).to_json()
        restored = ObjectMapper(data).to_object(UserWithAddress)

        assert restored.name == original.name
        assert restored.address.street == original.address.street
        assert restored.address.city == original.address.city

    def test_complex_round_trip(self):
        """Test round-trip for complex model."""
        original = Company(
            name="Acme Corp",
            ceo=User(name="Alice", age=45),
            employees=[User(name="Bob", age=35)],
            headquarters=Address(street="100 Corp Blvd", city="SF"),
        )
        data = ObjectMapper(original).to_json()
        restored = ObjectMapper(data).to_object(Company)

        assert restored.name == original.name
        assert restored.ceo.name == original.ceo.name
        assert len(restored.employees) == len(original.employees)
        assert restored.headquarters.city == original.headquarters.city
