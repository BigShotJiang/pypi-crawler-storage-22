"""Tests for ObjectMapper with special types (datetime, UUID, Enum, etc.)."""

from dataclasses import dataclass
from datetime import datetime, date, time
from enum import Enum
from typing import Optional
from uuid import UUID

from fixturify.object_mapper import ObjectMapper


class Status(Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"


class Priority(Enum):
    LOW = 1
    MEDIUM = 2
    HIGH = 3


@dataclass
class EntityWithDatetime:
    created_at: datetime
    updated_at: Optional[datetime] = None


@dataclass
class EntityWithDate:
    birth_date: date


@dataclass
class EntityWithTime:
    start_time: time


@dataclass
class EntityWithUUID:
    id: UUID
    name: str


@dataclass
class EntityWithEnum:
    status: Status
    priority: Priority


class TestDatetimeSerialization:
    """Tests for datetime type serialization."""

    def test_datetime_to_iso_format(self):
        """Test that datetime is serialized to ISO 8601 format."""
        dt = datetime(2024, 1, 15, 10, 30, 45)
        entity = EntityWithDatetime(created_at=dt)
        data = ObjectMapper(entity).to_json()

        assert data["created_at"] == "2024-01-15T10:30:45"

    def test_date_to_iso_format(self):
        """Test that date is serialized to ISO format."""
        d = date(2024, 1, 15)
        entity = EntityWithDate(birth_date=d)
        data = ObjectMapper(entity).to_json()

        assert data["birth_date"] == "2024-01-15"

    def test_time_to_iso_format(self):
        """Test that time is serialized to ISO format."""
        t = time(10, 30, 45)
        entity = EntityWithTime(start_time=t)
        data = ObjectMapper(entity).to_json()

        assert data["start_time"] == "10:30:45"


class TestDatetimeDeserialization:
    """Tests for datetime type deserialization."""

    def test_iso_format_to_datetime(self):
        """Test that ISO 8601 string is deserialized to datetime."""
        json_str = '{"created_at": "2024-01-15T10:30:45"}'
        entity = ObjectMapper(json_str).to_object(EntityWithDatetime)

        assert isinstance(entity.created_at, datetime)
        assert entity.created_at == datetime(2024, 1, 15, 10, 30, 45)

    def test_iso_format_to_date(self):
        """Test that ISO date string is deserialized to date."""
        json_str = '{"birth_date": "2024-01-15"}'
        entity = ObjectMapper(json_str).to_object(EntityWithDate)

        assert isinstance(entity.birth_date, date)
        assert entity.birth_date == date(2024, 1, 15)

    def test_iso_format_to_time(self):
        """Test that ISO time string is deserialized to time."""
        json_str = '{"start_time": "10:30:45"}'
        entity = ObjectMapper(json_str).to_object(EntityWithTime)

        assert isinstance(entity.start_time, time)
        assert entity.start_time == time(10, 30, 45)


class TestUUIDSerialization:
    """Tests for UUID type serialization."""

    def test_uuid_to_string(self):
        """Test that UUID is serialized to string."""
        uuid_val = UUID("550e8400-e29b-41d4-a716-446655440000")
        entity = EntityWithUUID(id=uuid_val, name="test")
        data = ObjectMapper(entity).to_json()

        assert data["id"] == "550e8400-e29b-41d4-a716-446655440000"

    def test_string_to_uuid(self):
        """Test that UUID string is deserialized to UUID."""
        json_str = '{"id": "550e8400-e29b-41d4-a716-446655440000", "name": "test"}'
        entity = ObjectMapper(json_str).to_object(EntityWithUUID)

        assert isinstance(entity.id, UUID)
        assert entity.id == UUID("550e8400-e29b-41d4-a716-446655440000")


class TestEnumSerialization:
    """Tests for Enum type serialization."""

    def test_string_enum_to_value(self):
        """Test that string enum is serialized by value."""
        entity = EntityWithEnum(status=Status.ACTIVE, priority=Priority.HIGH)
        data = ObjectMapper(entity).to_json()

        assert data["status"] == "active"
        assert data["priority"] == 3

    def test_value_to_string_enum(self):
        """Test that string value is deserialized to enum."""
        json_str = '{"status": "active", "priority": 3}'
        entity = ObjectMapper(json_str).to_object(EntityWithEnum)

        assert entity.status == Status.ACTIVE
        assert entity.priority == Priority.HIGH

    def test_standalone_enum_to_json(self):
        """Test serializing a standalone enum value."""
        data = ObjectMapper(Status.ACTIVE).to_json()
        assert data == "active"

    def test_json_to_standalone_enum(self):
        """Test deserializing to standalone enum."""
        result = ObjectMapper('"active"').to_object(Status)
        assert result == Status.ACTIVE


class TestSpecialTypeRoundTrips:
    """Test round trips for special types."""

    def test_datetime_round_trip(self):
        """Test datetime round trip."""
        original = EntityWithDatetime(
            created_at=datetime(2024, 1, 15, 10, 30, 45),
            updated_at=datetime(2024, 1, 16, 12, 0, 0),
        )
        data = ObjectMapper(original).to_json()
        restored = ObjectMapper(data).to_object(EntityWithDatetime)

        assert restored.created_at == original.created_at
        assert restored.updated_at == original.updated_at

    def test_uuid_round_trip(self):
        """Test UUID round trip."""
        original = EntityWithUUID(
            id=UUID("550e8400-e29b-41d4-a716-446655440000"), name="test"
        )
        data = ObjectMapper(original).to_json()
        restored = ObjectMapper(data).to_object(EntityWithUUID)

        assert restored.id == original.id
        assert restored.name == original.name

    def test_enum_round_trip(self):
        """Test enum round trip."""
        original = EntityWithEnum(status=Status.PENDING, priority=Priority.MEDIUM)
        data = ObjectMapper(original).to_json()
        restored = ObjectMapper(data).to_object(EntityWithEnum)

        assert restored.status == original.status
        assert restored.priority == original.priority
