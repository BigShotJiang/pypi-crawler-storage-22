"""Tests for SQLAlchemy model serialization and deserialization."""

import pytest
from datetime import datetime
from typing import List, Optional

from sqlalchemy import String, Integer, ForeignKey, DateTime, create_engine
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship, Session

from fixturify.object_mapper import ObjectMapper


# SQLAlchemy 2.0 style declarative base
class Base(DeclarativeBase):
    pass


class Department(Base):
    """SQLAlchemy model for department."""

    __tablename__ = "departments"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(100))

    employees: Mapped[List["Employee"]] = relationship(
        "Employee", back_populates="department"
    )


class Employee(Base):
    """SQLAlchemy model for employee."""

    __tablename__ = "employees"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(100))
    email: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)
    department_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("departments.id"), nullable=True
    )

    department: Mapped[Optional["Department"]] = relationship(
        "Department", back_populates="employees"
    )


class SimpleModel(Base):
    """Simple SQLAlchemy model without relationships."""

    __tablename__ = "simple_models"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(100))
    value: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)


class ModelWithDatetime(Base):
    """SQLAlchemy model with datetime field."""

    __tablename__ = "models_with_datetime"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(100))
    created_at: Mapped[datetime] = mapped_column(DateTime)


class TestSQLAlchemySerialization:
    """Tests for SQLAlchemy model to JSON serialization."""

    def test_simple_model_to_json(self):
        """Test serializing a simple SQLAlchemy model."""
        model = SimpleModel(id=1, name="Test", value=42)
        data = ObjectMapper(model).to_json()

        assert data["id"] == 1
        assert data["name"] == "Test"
        assert data["value"] == 42

    def test_model_with_none_to_json(self):
        """Test serializing SQLAlchemy model with None values."""
        model = SimpleModel(id=1, name="Test", value=None)
        data = ObjectMapper(model).to_json()

        assert data["id"] == 1
        assert data["name"] == "Test"
        assert data["value"] is None

    def test_model_with_datetime_to_json(self):
        """Test serializing SQLAlchemy model with datetime."""
        dt = datetime(2024, 1, 15, 10, 30, 0)
        model = ModelWithDatetime(id=1, name="Test", created_at=dt)
        data = ObjectMapper(model).to_json()

        assert data["id"] == 1
        assert data["name"] == "Test"
        assert data["created_at"] == "2024-01-15T10:30:00"

    def test_list_of_models_to_json(self):
        """Test serializing list of SQLAlchemy models."""
        models = [
            SimpleModel(id=1, name="First", value=10),
            SimpleModel(id=2, name="Second", value=20),
        ]
        data = ObjectMapper(models).to_json()

        assert len(data) == 2
        assert data[0]["name"] == "First"
        assert data[1]["name"] == "Second"

    def test_model_without_loaded_relationship(self):
        """Test serializing model when relationships are not loaded."""
        # Create employee without loading department
        employee = Employee(id=1, name="John", email="john@example.com")
        data = ObjectMapper(employee).to_json()

        assert data["id"] == 1
        assert data["name"] == "John"
        assert data["email"] == "john@example.com"
        # department should not be in output since it's not loaded
        assert "department" not in data or data.get("department") is None


class TestSQLAlchemyDeserialization:
    """Tests for JSON to SQLAlchemy model deserialization."""

    def test_json_to_simple_model(self):
        """Test deserializing JSON to simple SQLAlchemy model."""
        json_str = '{"id": 1, "name": "Test", "value": 42}'
        model = ObjectMapper(json_str).to_object(SimpleModel)

        assert isinstance(model, SimpleModel)
        assert model.id == 1
        assert model.name == "Test"
        assert model.value == 42

    def test_dict_to_simple_model(self):
        """Test deserializing dict to SQLAlchemy model."""
        data = {"id": 1, "name": "Test", "value": 42}
        model = ObjectMapper(data).to_object(SimpleModel)

        assert isinstance(model, SimpleModel)
        assert model.id == 1
        assert model.name == "Test"

    def test_json_to_model_with_none(self):
        """Test deserializing JSON with null values."""
        json_str = '{"id": 1, "name": "Test", "value": null}'
        model = ObjectMapper(json_str).to_object(SimpleModel)

        assert isinstance(model, SimpleModel)
        assert model.value is None

    def test_json_list_to_model_list(self):
        """Test deserializing JSON list to list of SQLAlchemy models."""
        json_str = '[{"id": 1, "name": "First", "value": 10}, {"id": 2, "name": "Second", "value": 20}]'
        models = ObjectMapper(json_str).to_object(SimpleModel)

        assert isinstance(models, list)
        assert len(models) == 2
        assert all(isinstance(m, SimpleModel) for m in models)
        assert models[0].name == "First"
        assert models[1].name == "Second"

    def test_json_to_employee_model(self):
        """Test deserializing JSON to Employee model."""
        json_str = '{"id": 1, "name": "John", "email": "john@example.com", "department_id": null}'
        employee = ObjectMapper(json_str).to_object(Employee)

        assert isinstance(employee, Employee)
        assert employee.id == 1
        assert employee.name == "John"
        assert employee.email == "john@example.com"


class TestSQLAlchemyRoundTrip:
    """Tests for round-trip serialization/deserialization."""

    def test_simple_round_trip(self):
        """Test round-trip for simple model."""
        original = SimpleModel(id=1, name="Test", value=42)
        data = ObjectMapper(original).to_json()
        restored = ObjectMapper(data).to_object(SimpleModel)

        assert restored.id == original.id
        assert restored.name == original.name
        assert restored.value == original.value

    def test_model_with_datetime_round_trip(self):
        """Test round-trip for model with datetime."""
        dt = datetime(2024, 1, 15, 10, 30, 0)
        original = ModelWithDatetime(id=1, name="Test", created_at=dt)
        data = ObjectMapper(original).to_json()
        restored = ObjectMapper(data).to_object(ModelWithDatetime)

        assert restored.id == original.id
        assert restored.name == original.name
        # Note: datetime comparison may need adjustment for timezone-aware datetimes

    def test_list_round_trip(self):
        """Test round-trip for list of models."""
        originals = [
            SimpleModel(id=1, name="First", value=10),
            SimpleModel(id=2, name="Second", value=20),
        ]
        data = ObjectMapper(originals).to_json()
        restored = ObjectMapper(data).to_object(SimpleModel)

        assert len(restored) == len(originals)
        for orig, rest in zip(originals, restored):
            assert rest.id == orig.id
            assert rest.name == orig.name
            assert rest.value == orig.value


class TestSQLAlchemyWithDatabase:
    """Tests using actual database operations."""

    @pytest.fixture
    def engine(self):
        """Create in-memory SQLite engine."""
        engine = create_engine("sqlite:///:memory:")
        Base.metadata.create_all(engine)
        return engine

    @pytest.fixture
    def session(self, engine):
        """Create database session."""
        with Session(engine) as session:
            yield session

    def test_serialize_persisted_model(self, session):
        """Test serializing a model that was persisted to database."""
        model = SimpleModel(name="Persisted", value=100)
        session.add(model)
        session.commit()
        session.refresh(model)

        data = ObjectMapper(model).to_json()

        assert data["name"] == "Persisted"
        assert data["value"] == 100
        assert "id" in data

    def test_serialize_model_with_relationship(self, session):
        """Test serializing model with loaded relationship."""
        dept = Department(name="Engineering")
        session.add(dept)
        session.commit()

        employee = Employee(name="John", email="john@example.com", department=dept)
        session.add(employee)
        session.commit()
        session.refresh(employee)

        # Access relationship to load it
        _ = employee.department

        data = ObjectMapper(employee).to_json()

        assert data["name"] == "John"
        assert data["department"]["name"] == "Engineering"

    def test_serialize_department_with_employees(self, session):
        """Test serializing department with employee list."""
        dept = Department(name="Engineering")
        session.add(dept)
        session.commit()

        emp1 = Employee(name="Alice", department=dept)
        emp2 = Employee(name="Bob", department=dept)
        session.add_all([emp1, emp2])
        session.commit()
        session.refresh(dept)

        # Access relationship to load it
        _ = dept.employees

        data = ObjectMapper(dept).to_json()

        assert data["name"] == "Engineering"
        assert len(data["employees"]) == 2
        employee_names = {e["name"] for e in data["employees"]}
        assert employee_names == {"Alice", "Bob"}
