"""Tests for SQLModel model serialization and deserialization."""

import pytest
from datetime import datetime
from typing import List, Optional
from enum import Enum

from sqlmodel import SQLModel, Field, Relationship, create_engine, Session

from fixturify.object_mapper import ObjectMapper


class Status(Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"


class Team(SQLModel, table=True):
    """SQLModel for team."""

    __tablename__ = "teams"

    id: Optional[int] = Field(default=None, primary_key=True)
    name: str
    description: Optional[str] = None

    members: List["Member"] = Relationship(back_populates="team")


class Member(SQLModel, table=True):
    """SQLModel for team member."""

    __tablename__ = "members"

    id: Optional[int] = Field(default=None, primary_key=True)
    name: str
    email: Optional[str] = None
    team_id: Optional[int] = Field(default=None, foreign_key="teams.id")

    team: Optional["Team"] = Relationship(back_populates="members")


class SimpleItem(SQLModel, table=True):
    """Simple SQLModel without relationships."""

    __tablename__ = "simple_items"

    id: Optional[int] = Field(default=None, primary_key=True)
    name: str
    value: Optional[int] = None


class ItemWithDatetime(SQLModel, table=True):
    """SQLModel with datetime field."""

    __tablename__ = "items_with_datetime"

    id: Optional[int] = Field(default=None, primary_key=True)
    name: str
    created_at: datetime


# Non-table SQLModel (Pydantic-like usage)
class Address(SQLModel):
    """SQLModel used as Pydantic model (no table)."""

    street: str
    city: str
    country: str = "USA"


class Person(SQLModel):
    """SQLModel with nested SQLModel (no table)."""

    name: str
    age: int
    address: Address


class PersonWithList(SQLModel):
    """SQLModel with list of nested models."""

    name: str
    addresses: List[Address]


class TestSQLModelSerialization:
    """Tests for SQLModel to JSON serialization."""

    def test_simple_model_to_json(self):
        """Test serializing a simple SQLModel."""
        item = SimpleItem(id=1, name="Test", value=42)
        data = ObjectMapper(item).to_json()

        assert data["id"] == 1
        assert data["name"] == "Test"
        assert data["value"] == 42

    def test_model_with_none_to_json(self):
        """Test serializing SQLModel with None values."""
        item = SimpleItem(id=1, name="Test", value=None)
        data = ObjectMapper(item).to_json()

        assert data["id"] == 1
        assert data["name"] == "Test"
        assert data["value"] is None

    def test_model_with_datetime_to_json(self):
        """Test serializing SQLModel with datetime."""
        dt = datetime(2024, 1, 15, 10, 30, 0)
        item = ItemWithDatetime(id=1, name="Test", created_at=dt)
        data = ObjectMapper(item).to_json()

        assert data["id"] == 1
        assert data["name"] == "Test"
        assert data["created_at"] == "2024-01-15T10:30:00"

    def test_non_table_model_to_json(self):
        """Test serializing non-table SQLModel (Pydantic-like)."""
        address = Address(street="123 Main St", city="Boston")
        data = ObjectMapper(address).to_json()

        assert data["street"] == "123 Main St"
        assert data["city"] == "Boston"
        assert data["country"] == "USA"

    def test_nested_non_table_model_to_json(self):
        """Test serializing nested non-table SQLModels."""
        person = Person(
            name="John", age=30, address=Address(street="123 Main St", city="Boston")
        )
        data = ObjectMapper(person).to_json()

        assert data["name"] == "John"
        assert data["age"] == 30
        assert data["address"]["street"] == "123 Main St"
        assert data["address"]["city"] == "Boston"

    def test_model_with_list_to_json(self):
        """Test serializing SQLModel with list of nested models."""
        person = PersonWithList(
            name="John",
            addresses=[
                Address(street="123 Main St", city="Boston"),
                Address(street="456 Oak Ave", city="NYC"),
            ],
        )
        data = ObjectMapper(person).to_json()

        assert data["name"] == "John"
        assert len(data["addresses"]) == 2
        assert data["addresses"][0]["city"] == "Boston"
        assert data["addresses"][1]["city"] == "NYC"

    def test_list_of_models_to_json(self):
        """Test serializing list of SQLModels."""
        items = [
            SimpleItem(id=1, name="First", value=10),
            SimpleItem(id=2, name="Second", value=20),
        ]
        data = ObjectMapper(items).to_json()

        assert len(data) == 2
        assert data[0]["name"] == "First"
        assert data[1]["name"] == "Second"


class TestSQLModelDeserialization:
    """Tests for JSON to SQLModel deserialization."""

    def test_json_to_simple_model(self):
        """Test deserializing JSON to simple SQLModel."""
        json_str = '{"id": 1, "name": "Test", "value": 42}'
        item = ObjectMapper(json_str).to_object(SimpleItem)

        assert isinstance(item, SimpleItem)
        assert item.id == 1
        assert item.name == "Test"
        assert item.value == 42

    def test_dict_to_simple_model(self):
        """Test deserializing dict to SQLModel."""
        data = {"id": 1, "name": "Test", "value": 42}
        item = ObjectMapper(data).to_object(SimpleItem)

        assert isinstance(item, SimpleItem)
        assert item.id == 1
        assert item.name == "Test"

    def test_json_to_model_with_none(self):
        """Test deserializing JSON with null values."""
        json_str = '{"id": 1, "name": "Test", "value": null}'
        item = ObjectMapper(json_str).to_object(SimpleItem)

        assert isinstance(item, SimpleItem)
        assert item.value is None

    def test_json_to_non_table_model(self):
        """Test deserializing JSON to non-table SQLModel."""
        json_str = '{"street": "123 Main St", "city": "Boston", "country": "USA"}'
        address = ObjectMapper(json_str).to_object(Address)

        assert isinstance(address, Address)
        assert address.street == "123 Main St"
        assert address.city == "Boston"

    def test_json_to_nested_model(self):
        """Test deserializing JSON to nested SQLModel."""
        json_str = """
        {
            "name": "John",
            "age": 30,
            "address": {
                "street": "123 Main St",
                "city": "Boston",
                "country": "USA"
            }
        }
        """
        person = ObjectMapper(json_str).to_object(Person)

        assert isinstance(person, Person)
        assert person.name == "John"
        assert isinstance(person.address, Address)
        assert person.address.city == "Boston"

    def test_json_to_model_with_list(self):
        """Test deserializing JSON to SQLModel with list."""
        json_str = """
        {
            "name": "John",
            "addresses": [
                {"street": "123 Main St", "city": "Boston", "country": "USA"},
                {"street": "456 Oak Ave", "city": "NYC", "country": "USA"}
            ]
        }
        """
        person = ObjectMapper(json_str).to_object(PersonWithList)

        assert isinstance(person, PersonWithList)
        assert len(person.addresses) == 2

    def test_json_list_to_model_list(self):
        """Test deserializing JSON list to list of SQLModels."""
        json_str = '[{"id": 1, "name": "First", "value": 10}, {"id": 2, "name": "Second", "value": 20}]'
        items = ObjectMapper(json_str).to_object(SimpleItem)

        assert isinstance(items, list)
        assert len(items) == 2
        assert all(isinstance(i, SimpleItem) for i in items)

    def test_json_to_member_model(self):
        """Test deserializing JSON to Member model."""
        json_str = (
            '{"id": 1, "name": "John", "email": "john@example.com", "team_id": null}'
        )
        member = ObjectMapper(json_str).to_object(Member)

        assert isinstance(member, Member)
        assert member.id == 1
        assert member.name == "John"
        assert member.email == "john@example.com"


class TestSQLModelRoundTrip:
    """Tests for round-trip serialization/deserialization."""

    def test_simple_round_trip(self):
        """Test round-trip for simple model."""
        original = SimpleItem(id=1, name="Test", value=42)
        data = ObjectMapper(original).to_json()
        restored = ObjectMapper(data).to_object(SimpleItem)

        assert restored.id == original.id
        assert restored.name == original.name
        assert restored.value == original.value

    def test_non_table_model_round_trip(self):
        """Test round-trip for non-table model."""
        original = Address(street="123 Main St", city="Boston")
        data = ObjectMapper(original).to_json()
        restored = ObjectMapper(data).to_object(Address)

        assert restored.street == original.street
        assert restored.city == original.city
        assert restored.country == original.country

    def test_nested_round_trip(self):
        """Test round-trip for nested model."""
        original = Person(
            name="John", age=30, address=Address(street="123 Main St", city="Boston")
        )
        data = ObjectMapper(original).to_json()
        restored = ObjectMapper(data).to_object(Person)

        assert restored.name == original.name
        assert restored.age == original.age
        assert restored.address.street == original.address.street

    def test_list_round_trip(self):
        """Test round-trip for list of models."""
        originals = [
            SimpleItem(id=1, name="First", value=10),
            SimpleItem(id=2, name="Second", value=20),
        ]
        data = ObjectMapper(originals).to_json()
        restored = ObjectMapper(data).to_object(SimpleItem)

        assert len(restored) == len(originals)
        for orig, rest in zip(originals, restored):
            assert rest.id == orig.id
            assert rest.name == orig.name


class TestSQLModelWithDatabase:
    """Tests using actual database operations."""

    @pytest.fixture
    def engine(self):
        """Create in-memory SQLite engine."""
        engine = create_engine("sqlite:///:memory:")
        SQLModel.metadata.create_all(engine)
        return engine

    @pytest.fixture
    def session(self, engine):
        """Create database session."""
        with Session(engine) as session:
            yield session

    def test_serialize_persisted_model(self, session):
        """Test serializing a model that was persisted to database."""
        item = SimpleItem(name="Persisted", value=100)
        session.add(item)
        session.commit()
        session.refresh(item)

        data = ObjectMapper(item).to_json()

        assert data["name"] == "Persisted"
        assert data["value"] == 100
        assert "id" in data

    def test_serialize_model_with_relationship(self, session):
        """Test serializing model with loaded relationship."""
        team = Team(name="Engineering")
        session.add(team)
        session.commit()

        member = Member(name="John", email="john@example.com", team=team)
        session.add(member)
        session.commit()
        session.refresh(member)

        # Access relationship to load it
        _ = member.team

        data = ObjectMapper(member).to_json()

        assert data["name"] == "John"
        # Check if team is serialized (may be nested or just team_id depending on relationship loading)
        assert data.get("team") is not None or data.get("team_id") is not None

    def test_serialize_team_with_members(self, session):
        """Test serializing team with member list."""
        team = Team(name="Engineering", description="Dev team")
        session.add(team)
        session.commit()

        member1 = Member(name="Alice", team=team)
        member2 = Member(name="Bob", team=team)
        session.add_all([member1, member2])
        session.commit()
        session.refresh(team)

        # Access relationship to load it
        _ = team.members

        data = ObjectMapper(team).to_json()

        assert data["name"] == "Engineering"
        assert data["description"] == "Dev team"
        # Members should be serialized if relationship was loaded
        if "members" in data:
            assert len(data["members"]) == 2
