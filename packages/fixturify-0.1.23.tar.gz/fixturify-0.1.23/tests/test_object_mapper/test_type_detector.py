"""Tests for _TypeDetector."""

from dataclasses import dataclass
from enum import Enum

from fixturify.object_mapper._detectors import _TypeDetector, ObjectType


class Status(Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"


@dataclass
class SimpleDataclass:
    name: str
    value: int


class PlainObject:
    def __init__(self, name: str):
        self.name = name


class TestTypeDetector:
    """Tests for _TypeDetector.detect()"""

    def test_detect_json_string_object(self):
        """Test detection of JSON object string."""
        assert _TypeDetector.detect('{"key": "value"}') == ObjectType.JSON_STRING

    def test_detect_json_string_array(self):
        """Test detection of JSON array string."""
        assert _TypeDetector.detect("[1, 2, 3]") == ObjectType.JSON_STRING

    def test_detect_plain_string(self):
        """Test that plain strings are detected as primitives."""
        assert _TypeDetector.detect("hello world") == ObjectType.PRIMITIVE

    def test_detect_dict(self):
        """Test detection of dict."""
        assert _TypeDetector.detect({"key": "value"}) == ObjectType.DICT

    def test_detect_list(self):
        """Test detection of list."""
        assert _TypeDetector.detect([1, 2, 3]) == ObjectType.COLLECTION

    def test_detect_tuple(self):
        """Test detection of tuple."""
        assert _TypeDetector.detect((1, 2, 3)) == ObjectType.COLLECTION

    def test_detect_set(self):
        """Test detection of set."""
        assert _TypeDetector.detect({1, 2, 3}) == ObjectType.COLLECTION

    def test_detect_dataclass_instance(self):
        """Test detection of dataclass instance."""
        obj = SimpleDataclass(name="test", value=42)
        assert _TypeDetector.detect(obj) == ObjectType.DATACLASS

    def test_detect_plain_object(self):
        """Test detection of plain Python object."""
        obj = PlainObject(name="test")
        assert _TypeDetector.detect(obj) == ObjectType.PLAIN_OBJECT

    def test_detect_primitive_int(self):
        """Test detection of int as primitive."""
        assert _TypeDetector.detect(42) == ObjectType.PRIMITIVE

    def test_detect_primitive_float(self):
        """Test detection of float as primitive."""
        assert _TypeDetector.detect(3.14) == ObjectType.PRIMITIVE

    def test_detect_primitive_bool(self):
        """Test detection of bool as primitive."""
        assert _TypeDetector.detect(True) == ObjectType.PRIMITIVE

    def test_detect_primitive_none(self):
        """Test detection of None as primitive."""
        assert _TypeDetector.detect(None) == ObjectType.PRIMITIVE


class TestTypeDetectorClass:
    """Tests for _TypeDetector.detect_class()"""

    def test_detect_class_dataclass(self):
        """Test detection of dataclass class."""
        assert _TypeDetector.detect_class(SimpleDataclass) == ObjectType.DATACLASS

    def test_detect_class_plain_object(self):
        """Test detection of plain object class."""
        assert _TypeDetector.detect_class(PlainObject) == ObjectType.PLAIN_OBJECT

    def test_detect_class_enum(self):
        """Test detection of Enum class as primitive."""
        assert _TypeDetector.detect_class(Status) == ObjectType.PRIMITIVE


class TestTypeDetectorHelpers:
    """Tests for _TypeDetector helper methods."""

    def test_is_json_string_valid(self):
        """Test _is_json_string with valid JSON."""
        assert _TypeDetector._is_json_string('{"key": "value"}') is True
        assert _TypeDetector._is_json_string("[1, 2, 3]") is True
        assert _TypeDetector._is_json_string('"string"') is True
        assert _TypeDetector._is_json_string("123") is True
        assert _TypeDetector._is_json_string("null") is True

    def test_is_json_string_invalid(self):
        """Test _is_json_string with invalid JSON."""
        assert _TypeDetector._is_json_string("hello world") is False
        assert _TypeDetector._is_json_string("{invalid}") is False
        assert _TypeDetector._is_json_string("") is False
