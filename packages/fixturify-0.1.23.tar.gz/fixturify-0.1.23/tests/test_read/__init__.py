"""Tests for read decorator module."""
