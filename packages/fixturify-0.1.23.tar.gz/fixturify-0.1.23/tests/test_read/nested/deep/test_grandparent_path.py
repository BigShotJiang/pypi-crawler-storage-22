"""Tests for read.fixture with grandparent directory paths (../../)."""

from dataclasses import dataclass
from typing import List

from fixturify.read_d import read


@dataclass
class User:
    name: str
    age: int


@dataclass
class Company:
    name: str
    employees: List[User]


class TestReadFixtureGrandparentPath:
    """Tests for @read.fixture with ../../ path patterns."""

    @read.fixture(
        path="../../fixtures/user.json", fixture_name="user", object_class=User
    )
    def test_double_parent_directory(self, user: User):
        """Test loading fixture from grandparent directory using ../../"""
        assert isinstance(user, User)
        assert user.name == "John"
        assert user.age == 30

    @read.fixture(
        path="../../fixtures/users.json", fixture_name="users", object_class=User
    )
    def test_list_from_grandparent_directory(self, users: List[User]):
        """Test loading list fixture from grandparent directory."""
        assert isinstance(users, list)
        assert len(users) == 2

    @read.fixture(
        path="../../fixtures/company.json", fixture_name="company", object_class=Company
    )
    def test_nested_object_from_grandparent(self, company: Company):
        """Test loading nested object from grandparent directory."""
        assert isinstance(company, Company)
        assert company.name == "Acme Corp"

    @read.fixture(path="../../fixtures/config.json", fixture_name="config")
    def test_raw_dict_from_grandparent(self, config: dict):
        """Test loading raw dict from grandparent directory."""
        assert config["timeout"] == 30


class TestReadFixtureMultipleGrandparentPaths:
    """Tests for @read.fixture with multiple ../../ path components."""

    @read.fixture(
        path="../../fixtures/user.json", fixture_name="user", object_class=User
    )
    @read.fixture(
        path="../../fixtures/company.json", fixture_name="company", object_class=Company
    )
    @read.fixture(path="../../fixtures/config.json", fixture_name="config")
    def test_three_fixtures_from_grandparent(
        self, user: User, company: Company, config: dict
    ):
        """Test loading three fixtures from grandparent directory."""
        assert user.name == "John"
        assert company.name == "Acme Corp"
        assert config["debug"] is True


class TestReadFixtureAsyncGrandparentPath:
    """Tests for async functions with ../../ paths."""

    @read.fixture(
        path="../../fixtures/user.json", fixture_name="user", object_class=User
    )
    async def test_async_from_grandparent(self, user: User):
        """Test async function with grandparent path."""
        assert user.name == "John"

    @read.fixture(
        path="../../fixtures/user.json", fixture_name="user", object_class=User
    )
    @read.fixture(path="../../fixtures/config.json", fixture_name="config")
    async def test_async_multiple_from_grandparent(self, user: User, config: dict):
        """Test async function with multiple grandparent paths."""
        assert user.age == 30
        assert config["api_url"] == "https://api.example.com"
