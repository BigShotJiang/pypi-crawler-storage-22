"""Tests for read.fixture with parent directory paths (../)."""

from dataclasses import dataclass
from typing import List

from fixturify.read_d import read


@dataclass
class User:
    name: str
    age: int


@dataclass
class Company:
    name: str
    employees: List[User]


class TestReadFixtureParentPath:
    """Tests for @read.fixture with ../ path patterns."""

    @read.fixture(path="../fixtures/user.json", fixture_name="user", object_class=User)
    def test_single_parent_directory(self, user: User):
        """Test loading fixture from parent directory using ../"""
        assert isinstance(user, User)
        assert user.name == "John"
        assert user.age == 30

    @read.fixture(
        path="../fixtures/users.json", fixture_name="users", object_class=User
    )
    def test_list_from_parent_directory(self, users: List[User]):
        """Test loading list fixture from parent directory."""
        assert isinstance(users, list)
        assert len(users) == 2
        assert users[0].name == "John"
        assert users[1].name == "Jane"

    @read.fixture(
        path="../fixtures/company.json", fixture_name="company", object_class=Company
    )
    def test_nested_object_from_parent(self, company: Company):
        """Test loading nested object from parent directory."""
        assert isinstance(company, Company)
        assert company.name == "Acme Corp"
        assert len(company.employees) == 2

    @read.fixture(path="../fixtures/config.json", fixture_name="config")
    def test_raw_dict_from_parent(self, config: dict):
        """Test loading raw dict from parent directory."""
        assert config["timeout"] == 30
        assert config["debug"] is True


class TestReadFixtureMultipleParentPaths:
    """Tests for @read.fixture with multiple ../ path components."""

    @read.fixture(path="../fixtures/user.json", fixture_name="user", object_class=User)
    @read.fixture(path="../fixtures/config.json", fixture_name="config")
    def test_multiple_fixtures_from_parent(self, user: User, config: dict):
        """Test loading multiple fixtures from parent directory."""
        assert user.name == "John"
        assert config["timeout"] == 30
