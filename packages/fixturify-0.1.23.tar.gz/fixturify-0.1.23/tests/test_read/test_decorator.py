"""Tests for read.fixture decorator."""

import pytest
from dataclasses import dataclass
from typing import List

from fixturify.read_d import read


@dataclass
class User:
    name: str
    age: int


@dataclass
class Company:
    name: str
    employees: List[User]


class TestReadFixtureBasic:
    """Basic tests for @read.fixture decorator."""

    @read.fixture(path="./fixtures/user.json", fixture_name="user", object_class=User)
    def test_single_fixture_with_object(self, user: User):
        """Test loading a single fixture as an object."""
        assert isinstance(user, User)
        assert user.name == "John"
        assert user.age == 30

    @read.fixture(path="./fixtures/config.json", fixture_name="config")
    def test_single_fixture_as_dict(self, config: dict):
        """Test loading a fixture as raw dict."""
        assert isinstance(config, dict)
        assert config["timeout"] == 30
        assert config["debug"] is True
        assert config["api_url"] == "https://api.example.com"

    @read.fixture(path="./fixtures/users.json", fixture_name="users", object_class=User)
    def test_list_fixture(self, users: List[User]):
        """Test loading a list fixture as objects."""
        assert isinstance(users, list)
        assert len(users) == 2
        assert users[0].name == "John"
        assert users[1].name == "Jane"

    @read.fixture(
        path="./fixtures/company.json", fixture_name="company", object_class=Company
    )
    def test_nested_fixture(self, company: Company):
        """Test loading a nested fixture."""
        assert isinstance(company, Company)
        assert company.name == "Acme Corp"
        assert len(company.employees) == 2


class TestReadFixtureMultiple:
    """Tests for multiple @read.fixture decorators."""

    @read.fixture(path="./fixtures/user.json", fixture_name="user", object_class=User)
    @read.fixture(path="./fixtures/config.json", fixture_name="config")
    def test_two_fixtures(self, user: User, config: dict):
        """Test loading two fixtures."""
        assert isinstance(user, User)
        assert user.name == "John"

        assert isinstance(config, dict)
        assert config["timeout"] == 30

    @read.fixture(path="./fixtures/user.json", fixture_name="user", object_class=User)
    @read.fixture(
        path="./fixtures/company.json", fixture_name="company", object_class=Company
    )
    @read.fixture(path="./fixtures/config.json", fixture_name="config")
    def test_three_fixtures(self, user: User, company: Company, config: dict):
        """Test loading three fixtures."""
        assert user.name == "John"
        assert company.name == "Acme Corp"
        assert config["debug"] is True


class TestReadFixtureWithOtherParams:
    """Tests for @read.fixture with other test parameters."""

    @read.fixture(path="./fixtures/user.json", fixture_name="user", object_class=User)
    def test_fixture_with_existing_param(self, user: User, extra_value=42):
        """Test that fixture works alongside default parameters."""
        assert user.name == "John"
        assert extra_value == 42

    @pytest.mark.parametrize("expected_age", [30])
    @read.fixture(path="./fixtures/user.json", fixture_name="user", object_class=User)
    def test_fixture_with_parametrize(self, user: User, expected_age: int):
        """Test that fixture works with pytest.mark.parametrize."""
        assert user.age == expected_age


class TestReadFixtureAsync:
    """Tests for async function support."""

    @read.fixture(path="./fixtures/user.json", fixture_name="user", object_class=User)
    async def test_async_fixture(self, user: User):
        """Test that decorator works with async functions."""
        assert isinstance(user, User)
        assert user.name == "John"

    @read.fixture(path="./fixtures/user.json", fixture_name="user", object_class=User)
    @read.fixture(path="./fixtures/config.json", fixture_name="config")
    async def test_async_multiple_fixtures(self, user: User, config: dict):
        """Test multiple fixtures with async function."""
        assert user.name == "John"
        assert config["timeout"] == 30


class TestReadFixtureErrors:
    """Tests for error scenarios."""

    def test_duplicate_fixture_name_raises_error(self):
        """Test that duplicate fixture names raise ValueError."""
        with pytest.raises(ValueError) as exc_info:

            @read.fixture(
                path="./fixtures/user.json", fixture_name="data", object_class=User
            )
            @read.fixture(path="./fixtures/config.json", fixture_name="data")
            def dummy_test(data):
                pass

        assert "Duplicate fixture name" in str(exc_info.value)

    def test_missing_file_raises_error_at_runtime(self):
        """Test that missing file raises FileNotFoundError at load time (not decoration time)."""

        @read.fixture(path="./fixtures/nonexistent.json", fixture_name="data")
        def failing_test(data):
            pytest.fail("Should not reach here - fixture file doesn't exist")

        # FileNotFoundError should be raised when the test is called
        with pytest.raises(FileNotFoundError) as exc_info:
            failing_test()

        assert "nonexistent.json" in str(exc_info.value)

    def test_missing_file_error_message(self):
        """Test FileNotFoundError message for missing fixture file."""

        @read.fixture(path="./fixtures/nonexistent.json", fixture_name="data")
        def failing_test(data):
            pass

        with pytest.raises(FileNotFoundError):
            failing_test()


class TestReadFixturePreservesMetadata:
    """Tests for function metadata preservation."""

    @read.fixture(path="./fixtures/user.json", fixture_name="user", object_class=User)
    def test_docstring_preserved(self, user: User):
        """This is a test docstring that should be preserved."""
        pass

    def test_metadata_is_preserved(self):
        """Test that functools.wraps preserves function metadata."""

        @read.fixture(
            path="./fixtures/user.json", fixture_name="user", object_class=User
        )
        def my_test_function(user: User):
            """My test docstring."""
            pass

        assert my_test_function.__name__ == "my_test_function"
        assert my_test_function.__doc__ == "My test docstring."
