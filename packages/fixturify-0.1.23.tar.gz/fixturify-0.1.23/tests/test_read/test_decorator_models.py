"""Tests for read.fixture decorator with Pydantic, SQLAlchemy, and SQLModel types."""

import pytest
from typing import List, Optional

from pydantic import BaseModel
from sqlalchemy import String, Integer, ForeignKey
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from sqlmodel import SQLModel, Field

from fixturify.read_d import read


# ============================================================================
# Pydantic v2 Models
# ============================================================================


class PydanticAddress(BaseModel):
    """Nested Pydantic model."""

    street: str
    city: str
    country: str = "USA"


class PydanticUser(BaseModel):
    """Simple Pydantic model."""

    name: str
    age: int
    email: Optional[str] = None


class PydanticCompany(BaseModel):
    """Complex Pydantic model with nesting."""

    name: str
    ceo: PydanticUser
    employees: List[PydanticUser]
    headquarters: PydanticAddress


# ============================================================================
# SQLAlchemy Models
# ============================================================================


class SABase(DeclarativeBase):
    pass


class SAUser(SABase):
    """SQLAlchemy model for user."""

    __tablename__ = "sa_users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(100))
    email: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)


class SADepartment(SABase):
    """SQLAlchemy model for department."""

    __tablename__ = "sa_departments"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(100))
    budget: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)


class SAEmployee(SABase):
    """SQLAlchemy model for employee with department reference."""

    __tablename__ = "sa_employees"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(100))
    email: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)
    department_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("sa_departments.id"), nullable=True
    )


# ============================================================================
# SQLModel Models (Non-Table - Pydantic-like)
# ============================================================================


class SMAddress(SQLModel):
    """Non-table SQLModel (Pydantic-like)."""

    street: str
    city: str
    country: str = "USA"


class SMUser(SQLModel):
    """Non-table SQLModel for user."""

    name: str
    age: int
    email: Optional[str] = None


class SMCompany(SQLModel):
    """Complex SQLModel with deep nesting."""

    name: str
    ceo: SMUser
    employees: List[SMUser]
    headquarters: SMAddress


# ============================================================================
# SQLModel Models (Table Models)
# ============================================================================


class SMUserTable(SQLModel, table=True):
    """Table SQLModel for user."""

    __tablename__ = "sm_users"

    id: Optional[int] = Field(default=None, primary_key=True)
    name: str
    email: Optional[str] = None


class SMDepartmentTable(SQLModel, table=True):
    """Table SQLModel for department."""

    __tablename__ = "sm_departments"

    id: Optional[int] = Field(default=None, primary_key=True)
    name: str
    budget: Optional[int] = None


# ============================================================================
# Pydantic Tests
# ============================================================================


class TestReadFixturePydantic:
    """Tests for @read.fixture with Pydantic models."""

    @read.fixture(
        path="./fixtures/pydantic_user.json",
        fixture_name="user",
        object_class=PydanticUser,
    )
    def test_pydantic_single_object(self, user: PydanticUser):
        """Test loading single Pydantic model."""
        assert isinstance(user, PydanticUser)
        assert user.name == "PydanticUser"
        assert user.age == 35
        assert user.email == "pydantic@example.com"

    @read.fixture(
        path="./fixtures/pydantic_users.json",
        fixture_name="users",
        object_class=PydanticUser,
    )
    def test_pydantic_list_of_objects(self, users: List[PydanticUser]):
        """Test loading list of Pydantic models."""
        assert isinstance(users, list)
        assert len(users) == 2
        assert all(isinstance(u, PydanticUser) for u in users)
        assert users[0].name == "Alice"
        assert users[1].name == "Bob"
        assert users[1].email is None

    @read.fixture(
        path="./fixtures/pydantic_company.json",
        fixture_name="company",
        object_class=PydanticCompany,
    )
    def test_pydantic_nested_model(self, company: PydanticCompany):
        """Test loading nested Pydantic model."""
        assert isinstance(company, PydanticCompany)
        assert company.name == "PydanticCorp"
        assert isinstance(company.ceo, PydanticUser)
        assert company.ceo.name == "CEO"
        assert len(company.employees) == 2
        assert all(isinstance(e, PydanticUser) for e in company.employees)
        assert isinstance(company.headquarters, PydanticAddress)
        assert company.headquarters.city == "Boston"

    @read.fixture(
        path="./fixtures/pydantic_user.json",
        fixture_name="user",
        object_class=PydanticUser,
    )
    @read.fixture(path="./fixtures/config.json", fixture_name="config")
    def test_pydantic_with_other_fixtures(self, user: PydanticUser, config: dict):
        """Test Pydantic fixture alongside raw dict fixture."""
        assert isinstance(user, PydanticUser)
        assert user.name == "PydanticUser"
        assert isinstance(config, dict)
        assert config["timeout"] == 30


class TestReadFixturePydanticAsync:
    """Async tests for @read.fixture with Pydantic models."""

    @read.fixture(
        path="./fixtures/pydantic_user.json",
        fixture_name="user",
        object_class=PydanticUser,
    )
    async def test_async_pydantic_single(self, user: PydanticUser):
        """Test async loading of Pydantic model."""
        assert isinstance(user, PydanticUser)
        assert user.name == "PydanticUser"

    @read.fixture(
        path="./fixtures/pydantic_company.json",
        fixture_name="company",
        object_class=PydanticCompany,
    )
    async def test_async_pydantic_nested(self, company: PydanticCompany):
        """Test async loading of nested Pydantic model."""
        assert isinstance(company, PydanticCompany)
        assert len(company.employees) == 2


# ============================================================================
# SQLAlchemy Tests
# ============================================================================


class TestReadFixtureSQLAlchemy:
    """Tests for @read.fixture with SQLAlchemy models."""

    @read.fixture(
        path="./fixtures/sqlalchemy_user.json", fixture_name="user", object_class=SAUser
    )
    def test_sqlalchemy_single_object(self, user: SAUser):
        """Test loading single SQLAlchemy model."""
        assert isinstance(user, SAUser)
        assert user.id == 1
        assert user.name == "SQLAlchemyUser"
        assert user.email == "sqlalchemy@example.com"

    @read.fixture(
        path="./fixtures/sqlalchemy_users.json",
        fixture_name="users",
        object_class=SAUser,
    )
    def test_sqlalchemy_list_of_objects(self, users: List[SAUser]):
        """Test loading list of SQLAlchemy models."""
        assert isinstance(users, list)
        assert len(users) == 3
        assert all(isinstance(u, SAUser) for u in users)
        assert users[0].name == "Alice"
        assert users[0].email == "alice@example.com"
        assert users[1].name == "Bob"
        assert users[1].email is None  # Test null handling
        assert users[2].name == "Charlie"

    @read.fixture(
        path="./fixtures/sqlalchemy_user.json", fixture_name="user", object_class=SAUser
    )
    @read.fixture(path="./fixtures/config.json", fixture_name="config")
    def test_sqlalchemy_with_other_fixtures(self, user: SAUser, config: dict):
        """Test SQLAlchemy fixture alongside raw dict fixture."""
        assert isinstance(user, SAUser)
        assert user.name == "SQLAlchemyUser"
        assert isinstance(config, dict)
        assert config["timeout"] == 30


class TestReadFixtureSQLAlchemyAsync:
    """Async tests for @read.fixture with SQLAlchemy models."""

    @read.fixture(
        path="./fixtures/sqlalchemy_user.json", fixture_name="user", object_class=SAUser
    )
    async def test_async_sqlalchemy_single(self, user: SAUser):
        """Test async loading of SQLAlchemy model."""
        assert isinstance(user, SAUser)
        assert user.id == 1
        assert user.name == "SQLAlchemyUser"

    @read.fixture(
        path="./fixtures/sqlalchemy_users.json",
        fixture_name="users",
        object_class=SAUser,
    )
    async def test_async_sqlalchemy_list(self, users: List[SAUser]):
        """Test async loading of list of SQLAlchemy models."""
        assert isinstance(users, list)
        assert len(users) == 3
        assert all(isinstance(u, SAUser) for u in users)


# ============================================================================
# SQLModel Tests (Non-Table Models)
# ============================================================================


class TestReadFixtureSQLModelNonTable:
    """Tests for @read.fixture with SQLModel non-table models (Pydantic-like)."""

    @read.fixture(
        path="./fixtures/pydantic_user.json", fixture_name="user", object_class=SMUser
    )
    def test_sqlmodel_single_object(self, user: SMUser):
        """Test loading single SQLModel (non-table)."""
        assert isinstance(user, SMUser)
        assert user.name == "PydanticUser"
        assert user.age == 35
        assert user.email == "pydantic@example.com"

    @read.fixture(
        path="./fixtures/pydantic_users.json", fixture_name="users", object_class=SMUser
    )
    def test_sqlmodel_list_of_objects(self, users: List[SMUser]):
        """Test loading list of SQLModel (non-table)."""
        assert isinstance(users, list)
        assert len(users) == 2
        assert all(isinstance(u, SMUser) for u in users)

    @read.fixture(
        path="./fixtures/sqlmodel_nested_company.json",
        fixture_name="company",
        object_class=SMCompany,
    )
    def test_sqlmodel_nested_model(self, company: SMCompany):
        """Test loading deeply nested SQLModel."""
        assert isinstance(company, SMCompany)
        assert company.name == "SQLModelCorp"

        # Test nested CEO object
        assert isinstance(company.ceo, SMUser)
        assert company.ceo.name == "SQLModelCEO"
        assert company.ceo.age == 45
        assert company.ceo.email == "ceo@sqlmodel.com"

        # Test nested list of employees
        assert len(company.employees) == 2
        assert all(isinstance(e, SMUser) for e in company.employees)
        assert company.employees[0].name == "Worker1"
        assert company.employees[0].age == 30
        assert company.employees[1].name == "Worker2"
        assert company.employees[1].email is None  # Test null handling in nested

        # Test nested address object
        assert isinstance(company.headquarters, SMAddress)
        assert company.headquarters.street == "456 SQLModel Blvd"
        assert company.headquarters.city == "San Francisco"
        assert company.headquarters.country == "USA"


class TestReadFixtureSQLModelNonTableAsync:
    """Async tests for @read.fixture with SQLModel non-table models."""

    @read.fixture(
        path="./fixtures/pydantic_user.json", fixture_name="user", object_class=SMUser
    )
    async def test_async_sqlmodel_single(self, user: SMUser):
        """Test async loading of SQLModel."""
        assert isinstance(user, SMUser)
        assert user.name == "PydanticUser"

    @read.fixture(
        path="./fixtures/sqlmodel_nested_company.json",
        fixture_name="company",
        object_class=SMCompany,
    )
    async def test_async_sqlmodel_nested(self, company: SMCompany):
        """Test async loading of nested SQLModel."""
        assert isinstance(company, SMCompany)
        assert isinstance(company.ceo, SMUser)
        assert len(company.employees) == 2
        assert isinstance(company.headquarters, SMAddress)


# ============================================================================
# SQLModel Tests (Table Models)
# ============================================================================


class TestReadFixtureSQLModelTable:
    """Tests for @read.fixture with SQLModel table models."""

    @read.fixture(
        path="./fixtures/sqlmodel_user_table.json",
        fixture_name="user",
        object_class=SMUserTable,
    )
    def test_sqlmodel_table_single_object(self, user: SMUserTable):
        """Test loading single SQLModel table model."""
        assert isinstance(user, SMUserTable)
        assert user.id == 1
        assert user.name == "SQLModelTableUser"
        assert user.email == "sqlmodel_table@example.com"

    @read.fixture(
        path="./fixtures/sqlmodel_users_table.json",
        fixture_name="users",
        object_class=SMUserTable,
    )
    def test_sqlmodel_table_list_of_objects(self, users: List[SMUserTable]):
        """Test loading list of SQLModel table models."""
        assert isinstance(users, list)
        assert len(users) == 2
        assert all(isinstance(u, SMUserTable) for u in users)
        assert users[0].name == "TableAlice"
        assert users[0].id == 1
        assert users[1].name == "TableBob"
        assert users[1].email is None  # Test null handling

    @read.fixture(
        path="./fixtures/sqlmodel_user_table.json",
        fixture_name="user",
        object_class=SMUserTable,
    )
    @read.fixture(path="./fixtures/config.json", fixture_name="config")
    def test_sqlmodel_table_with_other_fixtures(self, user: SMUserTable, config: dict):
        """Test SQLModel table fixture alongside raw dict fixture."""
        assert isinstance(user, SMUserTable)
        assert user.name == "SQLModelTableUser"
        assert isinstance(config, dict)


class TestReadFixtureSQLModelTableAsync:
    """Async tests for @read.fixture with SQLModel table models."""

    @read.fixture(
        path="./fixtures/sqlmodel_user_table.json",
        fixture_name="user",
        object_class=SMUserTable,
    )
    async def test_async_sqlmodel_table_single(self, user: SMUserTable):
        """Test async loading of SQLModel table model."""
        assert isinstance(user, SMUserTable)
        assert user.id == 1
        assert user.name == "SQLModelTableUser"

    @read.fixture(
        path="./fixtures/sqlmodel_users_table.json",
        fixture_name="users",
        object_class=SMUserTable,
    )
    async def test_async_sqlmodel_table_list(self, users: List[SMUserTable]):
        """Test async loading of list of SQLModel table models."""
        assert isinstance(users, list)
        assert len(users) == 2
        assert all(isinstance(u, SMUserTable) for u in users)


# ============================================================================
# Multiple Model Types Combined
# ============================================================================


class TestReadFixtureMultipleTypes:
    """Tests for @read.fixture with multiple model types in same test."""

    @read.fixture(
        path="./fixtures/pydantic_user.json",
        fixture_name="pydantic_user",
        object_class=PydanticUser,
    )
    @read.fixture(
        path="./fixtures/pydantic_user.json",
        fixture_name="sqlmodel_user",
        object_class=SMUser,
    )
    def test_pydantic_and_sqlmodel_together(
        self, pydantic_user: PydanticUser, sqlmodel_user: SMUser
    ):
        """Test loading same fixture as different model types."""
        assert isinstance(pydantic_user, PydanticUser)
        assert isinstance(sqlmodel_user, SMUser)
        assert pydantic_user.name == sqlmodel_user.name
        assert pydantic_user.age == sqlmodel_user.age

    @read.fixture(
        path="./fixtures/sqlalchemy_user.json",
        fixture_name="sa_user",
        object_class=SAUser,
    )
    @read.fixture(
        path="./fixtures/sqlmodel_user_table.json",
        fixture_name="sm_user",
        object_class=SMUserTable,
    )
    def test_sqlalchemy_and_sqlmodel_table_together(
        self, sa_user: SAUser, sm_user: SMUserTable
    ):
        """Test loading SQLAlchemy and SQLModel table models together."""
        assert isinstance(sa_user, SAUser)
        assert isinstance(sm_user, SMUserTable)
        assert sa_user.id == sm_user.id == 1

    @read.fixture(
        path="./fixtures/pydantic_user.json",
        fixture_name="pydantic_user",
        object_class=PydanticUser,
    )
    @read.fixture(
        path="./fixtures/sqlalchemy_user.json",
        fixture_name="sa_user",
        object_class=SAUser,
    )
    @read.fixture(
        path="./fixtures/sqlmodel_user_table.json",
        fixture_name="sm_user",
        object_class=SMUserTable,
    )
    @read.fixture(path="./fixtures/config.json", fixture_name="config")
    def test_all_model_types_together(
        self,
        pydantic_user: PydanticUser,
        sa_user: SAUser,
        sm_user: SMUserTable,
        config: dict,
    ):
        """Test loading all model types in a single test."""
        assert isinstance(pydantic_user, PydanticUser)
        assert isinstance(sa_user, SAUser)
        assert isinstance(sm_user, SMUserTable)
        assert isinstance(config, dict)

        # Each has expected values
        assert pydantic_user.name == "PydanticUser"
        assert sa_user.name == "SQLAlchemyUser"
        assert sm_user.name == "SQLModelTableUser"
        assert config["timeout"] == 30

    @read.fixture(
        path="./fixtures/pydantic_user.json",
        fixture_name="user",
        object_class=PydanticUser,
    )
    @read.fixture(path="./fixtures/config.json", fixture_name="config")
    @read.fixture(path="./fixtures/user.json", fixture_name="dataclass_user")
    def test_three_different_fixture_types(
        self, user: PydanticUser, config: dict, dataclass_user: dict
    ):
        """Test loading Pydantic model, raw dict, and another raw dict together."""
        assert isinstance(user, PydanticUser)
        assert isinstance(config, dict)
        assert isinstance(dataclass_user, dict)


# ============================================================================
# Error Handling Tests
# ============================================================================


class TestReadFixtureModelErrors:
    """Tests for error scenarios with model types."""

    def test_fixture_name_not_in_signature_raises_error(self):
        """Test that missing fixture_name in signature raises ValueError."""
        with pytest.raises(ValueError) as exc_info:

            @read.fixture(
                path="./fixtures/pydantic_user.json",
                fixture_name="wrong_name",
                object_class=PydanticUser,
            )
            def test_function(user: PydanticUser):
                pass

        assert "wrong_name" in str(exc_info.value)
        assert "not found" in str(exc_info.value)

    def test_fixture_name_validation_error_message(self):
        """Test that error message shows available parameters."""
        with pytest.raises(ValueError) as exc_info:

            @read.fixture(
                path="./fixtures/pydantic_user.json",
                fixture_name="missing",
                object_class=PydanticUser,
            )
            def test_with_params(user: PydanticUser, config: dict):
                pass

        error_msg = str(exc_info.value)
        assert "missing" in error_msg
        # Should mention available parameters
        assert "user" in error_msg or "config" in error_msg
