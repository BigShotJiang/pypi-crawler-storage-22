"""Tests for _FixtureLoader class."""

import pytest
from pathlib import Path
from dataclasses import dataclass
from typing import List

from fixturify.read_d._fixture_loader import _FixtureLoader


@dataclass
class User:
    name: str
    age: int


@dataclass
class Company:
    name: str
    employees: List[User]


class TestFixtureLoaderBasic:
    """Basic tests for _FixtureLoader."""

    def test_load_raw_dict(self):
        """Test loading JSON as raw dict without object_class."""
        loader = _FixtureLoader(
            path="./fixtures/user.json",
            fixture_name="user",
            object_class=None,
            test_file_path=str(Path(__file__)),
        )

        result = loader.load()

        assert isinstance(result, dict)
        assert result == {"name": "John", "age": 30}

    def test_load_as_object(self):
        """Test loading JSON and mapping to object."""
        loader = _FixtureLoader(
            path="./fixtures/user.json",
            fixture_name="user",
            object_class=User,
            test_file_path=str(Path(__file__)),
        )

        result = loader.load()

        assert isinstance(result, User)
        assert result.name == "John"
        assert result.age == 30

    def test_load_list_as_objects(self):
        """Test loading JSON array and mapping to list of objects."""
        loader = _FixtureLoader(
            path="./fixtures/users.json",
            fixture_name="users",
            object_class=User,
            test_file_path=str(Path(__file__)),
        )

        result = loader.load()

        assert isinstance(result, list)
        assert len(result) == 2
        assert all(isinstance(u, User) for u in result)
        assert result[0].name == "John"
        assert result[1].name == "Jane"

    def test_load_nested_object(self):
        """Test loading JSON with nested objects."""
        loader = _FixtureLoader(
            path="./fixtures/company.json",
            fixture_name="company",
            object_class=Company,
            test_file_path=str(Path(__file__)),
        )

        result = loader.load()

        assert isinstance(result, Company)
        assert result.name == "Acme Corp"
        assert len(result.employees) == 2
        assert all(isinstance(e, User) for e in result.employees)

    def test_fixture_name_property(self):
        """Test that fixture_name property returns correct value."""
        loader = _FixtureLoader(
            path="./fixtures/user.json",
            fixture_name="my_fixture",
            object_class=None,
            test_file_path=str(Path(__file__)),
        )

        assert loader.fixture_name == "my_fixture"


class TestFixtureLoaderFreshReads:
    """Tests for fresh file reading behavior."""

    def test_load_reads_fresh_each_call(self):
        """Test that load() reads file fresh on each call (no caching)."""
        loader = _FixtureLoader(
            path="./fixtures/user.json",
            fixture_name="user",
            object_class=User,
            test_file_path=str(Path(__file__)),
        )

        result1 = loader.load()
        result2 = loader.load()

        # Should be different instances (fresh reads)
        assert result1 is not result2
        # But equal values
        assert result1.name == result2.name
        assert result1.age == result2.age


class TestFixtureLoaderErrors:
    """Tests for error handling."""

    def test_file_not_found(self):
        """Test that FileNotFoundError is raised for missing files."""
        loader = _FixtureLoader(
            path="./fixtures/nonexistent.json",
            fixture_name="data",
            object_class=None,
            test_file_path=str(Path(__file__)),
        )

        with pytest.raises(FileNotFoundError) as exc_info:
            loader.load()

        assert "nonexistent.json" in str(exc_info.value)

    def test_invalid_json(self, tmp_path: Path):
        """Test that ValueError is raised for invalid JSON."""
        # Create invalid JSON file
        invalid_file = tmp_path / "invalid.json"
        invalid_file.write_text("{invalid json}")

        loader = _FixtureLoader(
            path=str(invalid_file),
            fixture_name="data",
            object_class=None,
            test_file_path=str(tmp_path / "test.py"),
        )

        with pytest.raises(ValueError) as exc_info:
            loader.load()

        assert "Invalid JSON" in str(exc_info.value)
