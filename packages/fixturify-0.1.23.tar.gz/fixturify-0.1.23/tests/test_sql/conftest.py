"""Pytest configuration for SQL module tests.

Database-specific configs are in their own folders:
- postgres/conftest.py - psycopg2 sync
- postgres_async/conftest.py - asyncpg async
- mysql/conftest.py - mysql.connector sync
- mysql_async/conftest.py - aiomysql async

Each folder has ONE SqlTestConfig fixture, so autodiscovery always works.
"""

# No SqlTestConfig fixtures here - they're in subfolders
