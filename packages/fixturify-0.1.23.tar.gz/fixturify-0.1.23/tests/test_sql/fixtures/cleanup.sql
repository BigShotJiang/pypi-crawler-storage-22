-- Cleanup SQL for testing
DROP TABLE IF EXISTS test_users;
