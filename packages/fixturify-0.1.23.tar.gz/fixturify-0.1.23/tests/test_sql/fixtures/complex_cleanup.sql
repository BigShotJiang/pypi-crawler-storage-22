DROP TABLE IF EXISTS ct_assignments;
DROP TABLE IF EXISTS ct_projects;
DROP TABLE IF EXISTS ct_employees;
DROP TABLE IF EXISTS ct_departments;
