-- Complex schema: 4 tables with FKs, indexes, constraints, and seed data

DROP TABLE IF EXISTS ct_assignments;
DROP TABLE IF EXISTS ct_projects;
DROP TABLE IF EXISTS ct_employees;
DROP TABLE IF EXISTS ct_departments;

CREATE TABLE ct_departments (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    code VARCHAR(10) UNIQUE NOT NULL,
    budget DECIMAL(12, 2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE ct_employees (
    id SERIAL PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    department_id INTEGER REFERENCES ct_departments(id),
    salary DECIMAL(10, 2) NOT NULL,
    hire_date DATE NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE ct_projects (
    id SERIAL PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    department_id INTEGER REFERENCES ct_departments(id),
    lead_id INTEGER REFERENCES ct_employees(id),
    status VARCHAR(20) DEFAULT 'active',
    start_date DATE,
    end_date DATE,
    budget DECIMAL(12, 2)
);

CREATE TABLE ct_assignments (
    id SERIAL PRIMARY KEY,
    employee_id INTEGER REFERENCES ct_employees(id),
    project_id INTEGER REFERENCES ct_projects(id),
    role VARCHAR(50),
    hours_allocated INTEGER DEFAULT 40,
    UNIQUE(employee_id, project_id)
);

CREATE INDEX idx_ct_emp_dept ON ct_employees(department_id);
CREATE INDEX idx_ct_emp_active ON ct_employees(is_active);
CREATE INDEX idx_ct_proj_status ON ct_projects(status);
CREATE INDEX idx_ct_assign_emp ON ct_assignments(employee_id);

INSERT INTO ct_departments (name, code, budget) VALUES
    ('Engineering', 'ENG', 500000.00),
    ('Marketing', 'MKT', 200000.00),
    ('Sales', 'SAL', 300000.00),
    ('Human Resources', 'HR', 150000.00),
    ('Finance', 'FIN', 180000.00);

INSERT INTO ct_employees (first_name, last_name, email, department_id, salary, hire_date, is_active) VALUES
    ('Alice', 'Smith', 'alice@corp.com', 1, 95000, '2020-01-15', TRUE),
    ('Bob', 'Jones', 'bob@corp.com', 1, 88000, '2020-03-20', TRUE),
    ('Carol', 'Williams', 'carol@corp.com', 2, 75000, '2021-06-01', TRUE),
    ('Dave', 'Brown', 'dave@corp.com', 3, 82000, '2019-11-10', TRUE),
    ('Eve', 'Davis', 'eve@corp.com', 1, 105000, '2018-07-22', TRUE),
    ('Frank', 'Wilson', 'frank@corp.com', 4, 70000, '2022-01-05', TRUE),
    ('Grace', 'Taylor', 'grace@corp.com', 2, 78000, '2021-09-15', TRUE),
    ('Hank', 'Anderson', 'hank@corp.com', 3, 91000, '2020-05-01', FALSE),
    ('Iris', 'Thomas', 'iris@corp.com', 5, 85000, '2019-03-10', TRUE),
    ('Jack', 'Martinez', 'jack@corp.com', 1, 97000, '2021-01-20', TRUE);

INSERT INTO ct_projects (name, department_id, lead_id, status, start_date, end_date, budget) VALUES
    ('Project Alpha', 1, 1, 'active', '2024-01-01', NULL, 100000),
    ('Project Beta', 1, 5, 'active', '2024-03-15', NULL, 150000),
    ('Campaign Q1', 2, 3, 'completed', '2024-01-01', '2024-03-31', 50000),
    ('Sales Push', 3, 4, 'active', '2024-02-01', NULL, 75000),
    ('HR Portal', 4, 6, 'planning', '2024-06-01', NULL, 60000),
    ('Budget Tool', 5, 9, 'active', '2024-04-01', NULL, 40000);

INSERT INTO ct_assignments (employee_id, project_id, role, hours_allocated) VALUES
    (1, 1, 'Lead', 40),
    (2, 1, 'Developer', 30),
    (10, 1, 'Developer', 20),
    (5, 2, 'Lead', 40),
    (2, 2, 'Developer', 10),
    (3, 3, 'Lead', 40),
    (7, 3, 'Designer', 30),
    (4, 4, 'Lead', 40),
    (6, 5, 'Lead', 20),
    (9, 6, 'Lead', 40);
