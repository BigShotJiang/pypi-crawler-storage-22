-- MySQL cleanup: Drop test table
DROP TABLE IF EXISTS sql_test_users;
