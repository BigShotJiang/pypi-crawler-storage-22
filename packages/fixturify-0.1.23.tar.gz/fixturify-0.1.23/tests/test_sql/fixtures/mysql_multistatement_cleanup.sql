-- Cleanup for multi-statement test
DROP TABLE IF EXISTS multi_stmt_users;
DROP TABLE IF EXISTS multi_stmt_products;

