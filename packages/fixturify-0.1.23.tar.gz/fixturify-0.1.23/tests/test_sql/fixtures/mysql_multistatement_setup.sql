-- Multi-statement setup for aiomysql testing
-- This file contains multiple statements separated by semicolons

DROP TABLE IF EXISTS multi_stmt_users;
DROP TABLE IF EXISTS multi_stmt_products;

CREATE TABLE multi_stmt_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL
);

CREATE TABLE multi_stmt_products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) NOT NULL
);

INSERT INTO multi_stmt_users (name) VALUES ('Alice');
INSERT INTO multi_stmt_users (name) VALUES ('Bob');
INSERT INTO multi_stmt_users (name) VALUES ('Charlie');

INSERT INTO multi_stmt_products (title) VALUES ('Widget');
INSERT INTO multi_stmt_products (title) VALUES ('Gadget');

