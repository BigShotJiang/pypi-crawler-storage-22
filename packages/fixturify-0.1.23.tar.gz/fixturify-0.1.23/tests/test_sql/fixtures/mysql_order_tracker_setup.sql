-- MySQL: Setup order tracking table for testing decorator execution order
DROP TABLE IF EXISTS sql_exec_order;

CREATE TABLE sql_exec_order (
    id INT AUTO_INCREMENT PRIMARY KEY,
    step VARCHAR(100) NOT NULL,
    executed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)

