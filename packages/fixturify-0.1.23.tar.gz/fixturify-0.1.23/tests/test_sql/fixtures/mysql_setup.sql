-- MySQL setup: Create table and insert test data
DROP TABLE IF EXISTS sql_test_users;

CREATE TABLE sql_test_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(255)
);

INSERT INTO sql_test_users (name, email) VALUES ('Alice', 'alice@example.com');
INSERT INTO sql_test_users (name, email) VALUES ('Bob', 'bob@example.com');
