-- MySQL: UTF-8 encoding test with special characters
DROP TABLE IF EXISTS utf8_test_table;

CREATE TABLE utf8_test_table (
    id INT AUTO_INCREMENT PRIMARY KEY,
    greeting VARCHAR(100) NOT NULL,
    description TEXT
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

INSERT INTO utf8_test_table (greeting, description) VALUES ('Hello', 'English greeting');
INSERT INTO utf8_test_table (greeting, description) VALUES ('こんにちは', 'Japanese greeting');
INSERT INTO utf8_test_table (greeting, description) VALUES ('Привет', 'Russian greeting')

