-- Nested SQL file for path resolution testing
SELECT 1;
