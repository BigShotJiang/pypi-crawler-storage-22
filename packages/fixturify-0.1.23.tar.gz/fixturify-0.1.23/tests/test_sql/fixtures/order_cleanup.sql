-- Cleanup: Drop order tracking table
DROP TABLE IF EXISTS sql_exec_order;

