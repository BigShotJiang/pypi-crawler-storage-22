-- Step 1: First BEFORE decorator
INSERT INTO sql_exec_order (step) VALUES ('step1_before');

