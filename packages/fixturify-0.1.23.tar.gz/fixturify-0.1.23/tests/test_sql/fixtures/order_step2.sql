-- Step 2: Second BEFORE decorator
INSERT INTO sql_exec_order (step) VALUES ('step2_before');

