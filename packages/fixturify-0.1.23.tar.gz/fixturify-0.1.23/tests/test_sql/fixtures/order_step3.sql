-- Step 3: First AFTER decorator (runs last)
INSERT INTO sql_exec_order (step) VALUES ('step3_after');

