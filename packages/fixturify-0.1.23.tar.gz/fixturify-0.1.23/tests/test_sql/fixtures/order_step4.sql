-- Step 4: Second AFTER decorator (runs before step3)
INSERT INTO sql_exec_order (step) VALUES ('step4_after');

