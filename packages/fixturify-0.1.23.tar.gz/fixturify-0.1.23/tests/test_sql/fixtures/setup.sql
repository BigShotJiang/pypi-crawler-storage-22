-- Setup SQL for testing
CREATE TABLE IF NOT EXISTS test_users (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(255)
);

INSERT INTO test_users (name, email) VALUES ('Test User', 'test@example.com');
