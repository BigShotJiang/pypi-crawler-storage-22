-- Cleanup UTF-8 test table
DROP TABLE IF EXISTS utf8_test_table;

