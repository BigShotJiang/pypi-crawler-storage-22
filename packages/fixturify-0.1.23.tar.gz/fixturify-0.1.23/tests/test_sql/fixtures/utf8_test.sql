-- UTF-8 encoding test with special characters
-- Japanese: こんにちは (Hello)
-- Russian: Привет (Hello)
-- Emoji: 🎉 🚀 ✨

DROP TABLE IF EXISTS utf8_test_table;

CREATE TABLE utf8_test_table (
    id SERIAL PRIMARY KEY,
    greeting VARCHAR(100) NOT NULL,
    description TEXT
);

INSERT INTO utf8_test_table (greeting, description) VALUES ('Hello', 'English greeting');
INSERT INTO utf8_test_table (greeting, description) VALUES ('こんにちは', 'Japanese greeting');
INSERT INTO utf8_test_table (greeting, description) VALUES ('Привет', 'Russian greeting');

