"""MySQL sync (mysql.connector) configuration.

ONE config per folder = autodiscovery always finds the right one.
"""

import pytest

from fixturify.sql_d import SqlTestConfig


@pytest.fixture
def sql_config() -> SqlTestConfig:
    """MySQL sync configuration - auto-discovered by @sql decorator."""
    return SqlTestConfig(
        driver="mysql.connector",
        host="localhost",
        port=3306,
        database="fixturify",
        user="root",
        password="",
    )
