"""MySQL sync (mysql.connector) integration tests.

Config is auto-discovered from conftest.py - no need to pass config= or fixture param.
"""

from typing import List

import pytest

from fixturify.sql_d import Phase, sql


def _can_connect() -> bool:
    """Check if MySQL is available."""
    try:
        import mysql.connector

        conn = mysql.connector.connect(
            host="localhost",
            port=3306,
            database="fixturify",
            user="root",
            password="",
        )
        conn.close()
        return True
    except Exception:
        return False


def _get_steps() -> List[str]:
    """Get execution order steps from database."""
    import mysql.connector

    conn = mysql.connector.connect(
        host="localhost",
        port=3306,
        database="fixturify",
        user="root",
        password="",
    )
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT step FROM sql_exec_order ORDER BY id")
        rows = cursor.fetchall()
        cursor.close()
        return [row[0] for row in rows]
    finally:
        conn.close()


@pytest.mark.skipif(not _can_connect(), reason="MySQL not available")
class TestMySQLSync:
    """MySQL sync tests - config auto-discovered from conftest.py."""

    @sql(path="../fixtures/mysql_setup.sql")
    @sql(path="../fixtures/mysql_cleanup.sql", phase=Phase.AFTER)
    def test_basic_setup_cleanup(self):
        """Test basic setup and cleanup with autodiscovery."""
        import mysql.connector

        conn = mysql.connector.connect(
            host="localhost",
            port=3306,
            database="fixturify",
            user="root",
            password="",
        )
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM sql_test_users")
            count = cursor.fetchone()[0]
            cursor.close()
            assert count == 2
        finally:
            conn.close()

    @sql(path="../fixtures/mysql_setup.sql")
    @sql(path="../fixtures/mysql_cleanup.sql", phase=Phase.AFTER)
    def test_select_data(self):
        """Test selecting inserted data."""
        import mysql.connector

        conn = mysql.connector.connect(
            host="localhost",
            port=3306,
            database="fixturify",
            user="root",
            password="",
        )
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT name FROM sql_test_users ORDER BY name")
            rows = cursor.fetchall()
            cursor.close()
            assert len(rows) == 2
            assert rows[0][0] == "Alice"
            assert rows[1][0] == "Bob"
        finally:
            conn.close()

    @sql(path="../fixtures/mysql_utf8_test.sql")
    @sql(path="../fixtures/utf8_cleanup.sql", phase=Phase.AFTER)
    def test_utf8_encoding(self):
        """Test UTF-8 characters in SQL files."""
        import mysql.connector

        conn = mysql.connector.connect(
            host="localhost",
            port=3306,
            database="fixturify",
            user="root",
            password="",
        )
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT greeting FROM utf8_test_table ORDER BY id")
            rows = cursor.fetchall()
            cursor.close()
            assert len(rows) == 3
            assert rows[1][0] == "こんにちは"
        finally:
            conn.close()

    @sql(path="../fixtures/mysql_order_tracker_setup.sql")
    @sql(path="../fixtures/order_step1.sql")
    @sql(path="../fixtures/order_step2.sql")
    @sql(path="../fixtures/order_cleanup.sql", phase=Phase.AFTER)
    def test_chained_decorators(self):
        """Test multiple BEFORE decorators execute in order."""
        steps = _get_steps()
        assert steps == ["step1_before", "step2_before"]
