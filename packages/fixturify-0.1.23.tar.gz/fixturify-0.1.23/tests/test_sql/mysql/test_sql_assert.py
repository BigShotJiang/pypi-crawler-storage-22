"""Tests for SqlAssert with MySQL (mysql.connector)."""

from dataclasses import dataclass
from typing import Optional

import pytest

from fixturify.sql_d import Phase, sql, SqlAssert


def _can_connect() -> bool:
    """Check if MySQL is available."""
    try:
        import mysql.connector

        conn = mysql.connector.connect(
            host="localhost",
            port=3306,
            database="fixturify",
            user="root",
            password="",
        )
        conn.close()
        return True
    except Exception:
        return False


@dataclass
class User:
    """Test user model for ObjectMapper integration."""

    id: int
    name: str
    email: Optional[str] = None


@pytest.mark.skipif(not _can_connect(), reason="MySQL not available")
class TestMySqlAssert:
    """MySQL SqlAssert tests."""

    @sql(path="../fixtures/mysql_setup.sql")
    @sql(path="../fixtures/mysql_cleanup.sql", phase=Phase.AFTER)
    def test_exists(self, sql_assert: SqlAssert):
        """Test exists() assertion."""
        sql_assert.table("sql_test_users").where(name="Alice").exists()

    @sql(path="../fixtures/mysql_setup.sql")
    @sql(path="../fixtures/mysql_cleanup.sql", phase=Phase.AFTER)
    def test_not_exists(self, sql_assert: SqlAssert):
        """Test not_exists() assertion."""
        sql_assert.table("sql_test_users").where(name="NonExistent").not_exists()

    @sql(path="../fixtures/mysql_setup.sql")
    @sql(path="../fixtures/mysql_cleanup.sql", phase=Phase.AFTER)
    def test_count(self, sql_assert: SqlAssert):
        """Test count() assertion."""
        sql_assert.table("sql_test_users").count(2)

    @sql(path="../fixtures/mysql_setup.sql")
    @sql(path="../fixtures/mysql_cleanup.sql", phase=Phase.AFTER)
    def test_fetch_one(self, sql_assert: SqlAssert):
        """Test fetch_one() returns dict."""
        row = sql_assert.table("sql_test_users").where(name="Alice").fetch_one()

        assert row is not None
        assert row["name"] == "Alice"
        assert row["email"] == "alice@example.com"

    @sql(path="../fixtures/mysql_setup.sql")
    @sql(path="../fixtures/mysql_cleanup.sql", phase=Phase.AFTER)
    def test_fetch_one_with_object_mapper(self, sql_assert: SqlAssert):
        """Test fetch_one() with ObjectMapper."""
        user = sql_assert.table("sql_test_users").where(name="Alice").fetch_one(User)

        assert isinstance(user, User)
        assert user.name == "Alice"

    @sql(path="../fixtures/mysql_setup.sql")
    @sql(path="../fixtures/mysql_cleanup.sql", phase=Phase.AFTER)
    def test_fetch_all(self, sql_assert: SqlAssert):
        """Test fetch_all() returns list of dicts."""
        rows = sql_assert.table("sql_test_users").order_by("name").fetch_all()

        assert len(rows) == 2
        assert rows[0]["name"] == "Alice"
        assert rows[1]["name"] == "Bob"

    @sql(path="../fixtures/mysql_setup.sql")
    @sql(path="../fixtures/mysql_cleanup.sql", phase=Phase.AFTER)
    def test_has(self, sql_assert: SqlAssert):
        """Test has() assertion."""
        sql_assert.table("sql_test_users").where(name="Alice").has(
            email="alice@example.com"
        )

    @sql(path="../fixtures/mysql_setup.sql")
    @sql(path="../fixtures/mysql_cleanup.sql", phase=Phase.AFTER)
    def test_raw_query(self, sql_assert: SqlAssert):
        """Test raw() query."""
        result = sql_assert.raw(
            "SELECT COUNT(*) as cnt FROM sql_test_users WHERE name LIKE %s",
            ["%ob%"],
        ).fetch_one()

        assert result is not None
        assert result["cnt"] == 1  # Bob


@pytest.mark.skipif(not _can_connect(), reason="MySQL not available")
class TestMySqlAssertWhereIn:
    """Tests for where() with list values (IN clause)."""

    @sql(path="../fixtures/mysql_setup.sql")
    @sql(path="../fixtures/mysql_cleanup.sql", phase=Phase.AFTER)
    def test_where_in_exists(self, sql_assert: SqlAssert):
        """Test exists() with IN clause."""
        sql_assert.table("sql_test_users").where(name=["Alice", "Bob"]).exists()

    @sql(path="../fixtures/mysql_setup.sql")
    @sql(path="../fixtures/mysql_cleanup.sql", phase=Phase.AFTER)
    def test_where_in_count(self, sql_assert: SqlAssert):
        """Test count() with IN clause matches all listed values."""
        sql_assert.table("sql_test_users").where(name=["Alice", "Bob"]).count(2)

    @sql(path="../fixtures/mysql_setup.sql")
    @sql(path="../fixtures/mysql_cleanup.sql", phase=Phase.AFTER)
    def test_where_in_single_element(self, sql_assert: SqlAssert):
        """Test IN with single-element list."""
        sql_assert.table("sql_test_users").where(name=["Alice"]).count(1)

    @sql(path="../fixtures/mysql_setup.sql")
    @sql(path="../fixtures/mysql_cleanup.sql", phase=Phase.AFTER)
    def test_where_in_no_match(self, sql_assert: SqlAssert):
        """Test IN clause with no matching values."""
        sql_assert.table("sql_test_users").where(name=["X", "Y"]).not_exists()

    @sql(path="../fixtures/mysql_setup.sql")
    @sql(path="../fixtures/mysql_cleanup.sql", phase=Phase.AFTER)
    def test_where_in_with_scalar(self, sql_assert: SqlAssert):
        """Test IN clause combined with scalar equality."""
        sql_assert.table("sql_test_users").where(
            name=["Alice", "Bob"], email="alice@example.com"
        ).count(1)

    @sql(path="../fixtures/mysql_setup.sql")
    @sql(path="../fixtures/mysql_cleanup.sql", phase=Phase.AFTER)
    def test_where_in_fetch_all(self, sql_assert: SqlAssert):
        """Test fetch_all() with IN clause."""
        rows = sql_assert.table("sql_test_users").where(
            name=["Alice", "Bob"]
        ).order_by("name").fetch_all()

        assert len(rows) == 2
        assert rows[0]["name"] == "Alice"
        assert rows[1]["name"] == "Bob"

    @sql(path="../fixtures/mysql_setup.sql")
    @sql(path="../fixtures/mysql_cleanup.sql", phase=Phase.AFTER)
    def test_where_in_empty_list_raises(self, sql_assert: SqlAssert):
        """Test that empty list raises ValueError."""
        with pytest.raises(ValueError, match="where\\(\\) does not accept empty lists"):
            sql_assert.table("sql_test_users").where(name=[]).exists()
