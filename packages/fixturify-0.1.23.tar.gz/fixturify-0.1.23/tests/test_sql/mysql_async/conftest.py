"""MySQL async (aiomysql) configuration.

ONE config per folder = autodiscovery always finds the right one.
"""

import pytest

from fixturify.sql_d import SqlTestConfig


@pytest.fixture
def sql_config() -> SqlTestConfig:
    """MySQL async configuration - auto-discovered by @sql decorator."""
    return SqlTestConfig(
        driver="aiomysql",
        host="localhost",
        port=3306,
        database="fixturify",
        user="root",
        password="",
    )
