"""MySQL async (aiomysql) integration tests.

Config is auto-discovered from conftest.py - no need to pass config= or fixture param.
"""

import pytest

from fixturify.sql_d import Phase, sql


def _can_connect() -> bool:
    """Check if MySQL is available."""
    try:
        import mysql.connector

        conn = mysql.connector.connect(
            host="localhost",
            port=3306,
            database="fixturify",
            user="root",
            password="",
        )
        conn.close()
        return True
    except Exception:
        return False


def _has_aiomysql() -> bool:
    """Check if aiomysql is installed."""
    try:
        import aiomysql  # noqa: F401

        return True
    except ImportError:
        return False


@pytest.mark.skipif(
    not (_can_connect() and _has_aiomysql()),
    reason="MySQL or aiomysql not available",
)
class TestMySQLAsync:
    """MySQL async tests - config auto-discovered from conftest.py."""

    @sql(path="../fixtures/mysql_setup.sql")
    @sql(path="../fixtures/mysql_cleanup.sql", phase=Phase.AFTER)
    def test_async_setup_sync_test(self):
        """Test async config in sync test (uses asyncio.run internally)."""
        import mysql.connector

        conn = mysql.connector.connect(
            host="localhost",
            port=3306,
            database="fixturify",
            user="root",
            password="",
        )
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM sql_test_users")
            count = cursor.fetchone()[0]
            cursor.close()
            assert count == 2
        finally:
            conn.close()

    @sql(path="../fixtures/mysql_setup.sql")
    @sql(path="../fixtures/mysql_cleanup.sql", phase=Phase.AFTER)
    @pytest.mark.asyncio
    async def test_async_setup_async_test(self):
        """Test async config in async test."""
        import aiomysql

        conn = await aiomysql.connect(
            host="localhost",
            port=3306,
            db="fixturify",
            user="root",
            password="",
        )
        try:
            async with conn.cursor() as cursor:
                await cursor.execute("SELECT COUNT(*) FROM sql_test_users")
                row = await cursor.fetchone()
                assert row[0] == 2
        finally:
            conn.close()

    @sql(path="../fixtures/mysql_multistatement_setup.sql")
    @sql(path="../fixtures/mysql_multistatement_cleanup.sql", phase=Phase.AFTER)
    @pytest.mark.asyncio
    async def test_multistatement_script(self):
        """Test multi-statement SQL scripts with aiomysql."""
        import aiomysql

        conn = await aiomysql.connect(
            host="localhost",
            port=3306,
            db="fixturify",
            user="root",
            password="",
        )
        try:
            async with conn.cursor() as cursor:
                await cursor.execute("SELECT COUNT(*) FROM multi_stmt_users")
                users_count = (await cursor.fetchone())[0]
                await cursor.execute("SELECT COUNT(*) FROM multi_stmt_products")
                products_count = (await cursor.fetchone())[0]
                assert users_count >= 2
                assert products_count >= 2
        finally:
            conn.close()
