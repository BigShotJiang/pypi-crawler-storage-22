"""PostgreSQL sync (psycopg2) configuration.

ONE config per folder = autodiscovery always finds the right one.
"""

import pytest

from fixturify.sql_d import SqlTestConfig


@pytest.fixture
def sql_config() -> SqlTestConfig:
    """PostgreSQL sync configuration - auto-discovered by @sql decorator."""
    return SqlTestConfig(
        driver="psycopg2",
        host="localhost",
        port=5432,
        database="fixturify",
        user="postgres",
        password="postgres",
    )
