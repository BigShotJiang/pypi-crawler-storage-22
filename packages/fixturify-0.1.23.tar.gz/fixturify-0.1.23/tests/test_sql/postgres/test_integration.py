"""PostgreSQL sync integration tests.

Config is auto-discovered from conftest.py - no need to pass config= or fixture param.
"""

from typing import List

import pytest

from fixturify.sql_d import Phase, sql


def _can_connect() -> bool:
    """Check if PostgreSQL is available."""
    try:
        import psycopg2

        conn = psycopg2.connect(
            host="localhost",
            port=5432,
            dbname="fixturify",
            user="postgres",
            password="postgres",
        )
        conn.close()
        return True
    except Exception:
        return False


def _get_steps() -> List[str]:
    """Get execution order steps from database."""
    import psycopg2

    conn = psycopg2.connect(
        host="localhost",
        port=5432,
        dbname="fixturify",
        user="postgres",
        password="postgres",
    )
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT step FROM sql_exec_order ORDER BY id")
        rows = cursor.fetchall()
        cursor.close()
        return [row[0] for row in rows]
    finally:
        conn.close()


@pytest.mark.skipif(not _can_connect(), reason="PostgreSQL not available")
class TestPostgresSync:
    """PostgreSQL sync tests - config auto-discovered from conftest.py."""

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_basic_setup_cleanup(self):
        """Test basic setup and cleanup with autodiscovery."""
        import psycopg2

        conn = psycopg2.connect(
            host="localhost",
            port=5432,
            dbname="fixturify",
            user="postgres",
            password="postgres",
        )
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM sql_test_users")
            count = cursor.fetchone()[0]
            cursor.close()
            assert count == 2
        finally:
            conn.close()

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_select_data(self):
        """Test selecting inserted data."""
        import psycopg2

        conn = psycopg2.connect(
            host="localhost",
            port=5432,
            dbname="fixturify",
            user="postgres",
            password="postgres",
        )
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT name FROM sql_test_users ORDER BY name")
            rows = cursor.fetchall()
            cursor.close()
            assert len(rows) == 2
            assert rows[0][0] == "Alice"
            assert rows[1][0] == "Bob"
        finally:
            conn.close()

    @sql(path="../fixtures/utf8_test.sql")
    @sql(path="../fixtures/utf8_cleanup.sql", phase=Phase.AFTER)
    def test_utf8_encoding(self):
        """Test UTF-8 characters in SQL files."""
        import psycopg2

        conn = psycopg2.connect(
            host="localhost",
            port=5432,
            dbname="fixturify",
            user="postgres",
            password="postgres",
        )
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT greeting FROM utf8_test_table ORDER BY id")
            rows = cursor.fetchall()
            cursor.close()
            assert len(rows) == 3
            assert rows[1][0] == "こんにちは"
        finally:
            conn.close()

    @sql(path="../fixtures/order_tracker_setup.sql")
    @sql(path="../fixtures/order_step1.sql")
    @sql(path="../fixtures/order_step2.sql")
    @sql(path="../fixtures/order_cleanup.sql", phase=Phase.AFTER)
    def test_chained_decorators(self):
        """Test multiple BEFORE decorators execute in order."""
        steps = _get_steps()
        assert steps == ["step1_before", "step2_before"]
