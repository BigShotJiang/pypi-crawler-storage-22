"""PostgreSQL async (asyncpg) configuration.

ONE config per folder = autodiscovery always finds the right one.
"""

import pytest

from fixturify.sql_d import SqlTestConfig


@pytest.fixture
def sql_config() -> SqlTestConfig:
    """PostgreSQL async configuration - auto-discovered by @sql decorator."""
    return SqlTestConfig(
        driver="asyncpg",
        host="localhost",
        port=5432,
        database="fixturify",
        user="postgres",
        password="postgres",
    )
