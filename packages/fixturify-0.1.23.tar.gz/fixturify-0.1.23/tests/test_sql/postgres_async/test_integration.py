"""PostgreSQL async (asyncpg) integration tests.

Config is auto-discovered from conftest.py - no need to pass config= or fixture param.
"""

import pytest

from fixturify.sql_d import Phase, sql


def _can_connect() -> bool:
    """Check if PostgreSQL is available."""
    try:
        import psycopg2

        conn = psycopg2.connect(
            host="localhost",
            port=5432,
            dbname="fixturify",
            user="postgres",
            password="postgres",
        )
        conn.close()
        return True
    except Exception:
        return False


def _has_asyncpg() -> bool:
    """Check if asyncpg is installed."""
    try:
        import asyncpg  # noqa: F401

        return True
    except ImportError:
        return False


@pytest.mark.skipif(
    not (_can_connect() and _has_asyncpg()),
    reason="PostgreSQL or asyncpg not available",
)
class TestPostgresAsync:
    """PostgreSQL async tests - config auto-discovered from conftest.py."""

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_async_setup_sync_test(self):
        """Test async config in sync test (uses asyncio.run internally)."""
        import psycopg2

        conn = psycopg2.connect(
            host="localhost",
            port=5432,
            dbname="fixturify",
            user="postgres",
            password="postgres",
        )
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM sql_test_users")
            count = cursor.fetchone()[0]
            cursor.close()
            assert count == 2
        finally:
            conn.close()

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    @pytest.mark.asyncio
    async def test_async_setup_async_test(self):
        """Test async config in async test."""
        import asyncpg

        conn = await asyncpg.connect(
            host="localhost",
            port=5432,
            database="fixturify",
            user="postgres",
            password="postgres",
        )
        try:
            count = await conn.fetchval("SELECT COUNT(*) FROM sql_test_users")
            assert count == 2
        finally:
            await conn.close()

    @sql(path="../fixtures/utf8_test.sql")
    @sql(path="../fixtures/utf8_cleanup.sql", phase=Phase.AFTER)
    @pytest.mark.asyncio
    async def test_utf8_async(self):
        """Test UTF-8 with async driver."""
        import asyncpg

        conn = await asyncpg.connect(
            host="localhost",
            port=5432,
            database="fixturify",
            user="postgres",
            password="postgres",
        )
        try:
            rows = await conn.fetch("SELECT greeting FROM utf8_test_table ORDER BY id")
            assert len(rows) == 3
            assert rows[1]["greeting"] == "こんにちは"
        finally:
            await conn.close()
