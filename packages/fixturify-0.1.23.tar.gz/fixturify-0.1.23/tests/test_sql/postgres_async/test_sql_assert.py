"""Tests for SqlAssert with PostgreSQL async (asyncpg)."""

from dataclasses import dataclass
from typing import Optional

import pytest

from fixturify.sql_d import Phase, sql, SqlAssert


def _can_connect() -> bool:
    """Check if PostgreSQL is available."""
    try:
        import asyncio
        import asyncpg

        async def check():
            conn = await asyncpg.connect(
                host="localhost",
                port=5432,
                database="fixturify",
                user="postgres",
                password="postgres",
            )
            await conn.close()
            return True

        return asyncio.get_event_loop().run_until_complete(check())
    except Exception:
        return False


@dataclass
class User:
    """Test user model for ObjectMapper integration."""

    id: int
    name: str
    email: Optional[str] = None


@pytest.mark.skipif(not _can_connect(), reason="PostgreSQL not available")
class TestAsyncPgSqlAssert:
    """PostgreSQL async SqlAssert tests."""

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_aexists(self, sql_assert: SqlAssert):
        """Test aexists() assertion."""
        await sql_assert.table("sql_test_users").where(name="Alice").aexists()

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_anot_exists(self, sql_assert: SqlAssert):
        """Test anot_exists() assertion."""
        await sql_assert.table("sql_test_users").where(name="NonExistent").anot_exists()

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_acount(self, sql_assert: SqlAssert):
        """Test acount() assertion."""
        await sql_assert.table("sql_test_users").acount(2)

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_afetch_one(self, sql_assert: SqlAssert):
        """Test afetch_one() returns dict."""
        row = await sql_assert.table("sql_test_users").where(name="Alice").afetch_one()

        assert row is not None
        assert row["name"] == "Alice"
        assert row["email"] == "alice@example.com"

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_afetch_one_with_object_mapper(self, sql_assert: SqlAssert):
        """Test afetch_one() with ObjectMapper."""
        user = await sql_assert.table("sql_test_users").where(name="Alice").afetch_one(User)

        assert isinstance(user, User)
        assert user.name == "Alice"

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_afetch_all(self, sql_assert: SqlAssert):
        """Test afetch_all() returns list of dicts."""
        rows = await sql_assert.table("sql_test_users").order_by("name").afetch_all()

        assert len(rows) == 2
        assert rows[0]["name"] == "Alice"
        assert rows[1]["name"] == "Bob"

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_afetch_all_with_object_mapper(self, sql_assert: SqlAssert):
        """Test afetch_all() with ObjectMapper."""
        users = await sql_assert.table("sql_test_users").order_by("name").afetch_all(User)

        assert len(users) == 2
        assert all(isinstance(u, User) for u in users)
        assert users[0].name == "Alice"
        assert users[1].name == "Bob"


@pytest.mark.skipif(not _can_connect(), reason="PostgreSQL not available")
class TestAsyncPgSyncWithAsyncDriver:
    """Test sync SqlAssert methods with asyncpg async driver."""

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_exists(self, sql_assert: SqlAssert):
        sql_assert.table("sql_test_users").where(name="Alice").exists()

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_not_exists(self, sql_assert: SqlAssert):
        sql_assert.table("sql_test_users").where(name="NonExistent").not_exists()

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_count(self, sql_assert: SqlAssert):
        sql_assert.table("sql_test_users").count(2)

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_fetch_one(self, sql_assert: SqlAssert):
        row = sql_assert.table("sql_test_users").where(name="Alice").fetch_one()

        assert row is not None
        assert row["name"] == "Alice"
        assert row["email"] == "alice@example.com"

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_fetch_all(self, sql_assert: SqlAssert):
        rows = sql_assert.table("sql_test_users").order_by("name").fetch_all()

        assert len(rows) == 2
        assert rows[0]["name"] == "Alice"
        assert rows[1]["name"] == "Bob"

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_has(self, sql_assert: SqlAssert):
        sql_assert.table("sql_test_users").where(name="Alice").has(
            email="alice@example.com"
        )


@pytest.mark.skipif(not _can_connect(), reason="PostgreSQL not available")
class TestAsyncPgWhereIn:
    """Tests for where() with list values (IN clause) — async."""

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_where_in_aexists(self, sql_assert: SqlAssert):
        """Test aexists() with IN clause."""
        await sql_assert.table("sql_test_users").where(name=["Alice", "Bob"]).aexists()

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_where_in_acount(self, sql_assert: SqlAssert):
        """Test acount() with IN clause."""
        await sql_assert.table("sql_test_users").where(name=["Alice", "Bob"]).acount(2)

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_where_in_single_element(self, sql_assert: SqlAssert):
        """Test IN with single-element list."""
        await sql_assert.table("sql_test_users").where(name=["Alice"]).acount(1)

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_where_in_no_match(self, sql_assert: SqlAssert):
        """Test IN clause with no matching values."""
        await sql_assert.table("sql_test_users").where(name=["X", "Y"]).anot_exists()

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_where_in_with_scalar(self, sql_assert: SqlAssert):
        """Test IN clause combined with scalar equality."""
        await sql_assert.table("sql_test_users").where(
            name=["Alice", "Bob"], email="alice@example.com"
        ).acount(1)

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_where_in_afetch_all(self, sql_assert: SqlAssert):
        """Test afetch_all() with IN clause."""
        rows = await sql_assert.table("sql_test_users").where(
            name=["Alice", "Bob"]
        ).order_by("name").afetch_all()

        assert len(rows) == 2
        assert rows[0]["name"] == "Alice"
        assert rows[1]["name"] == "Bob"

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_where_in_afetch_one(self, sql_assert: SqlAssert):
        """Test afetch_one() with IN clause."""
        row = await sql_assert.table("sql_test_users").where(
            name=["Alice"]
        ).afetch_one()

        assert row is not None
        assert row["name"] == "Alice"

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_where_in_empty_list_raises(self, sql_assert: SqlAssert):
        """Test that empty list raises ValueError."""
        with pytest.raises(ValueError, match="where\\(\\) does not accept empty lists"):
            await sql_assert.table("sql_test_users").where(name=[]).aexists()


@pytest.mark.skipif(not _can_connect(), reason="PostgreSQL not available")
class TestAsyncPgWhereInSync:
    """Tests for where() with list values (IN clause) — sync methods with async driver."""

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_where_in_exists(self, sql_assert: SqlAssert):
        """Test sync exists() with IN clause on async driver."""
        sql_assert.table("sql_test_users").where(name=["Alice", "Bob"]).exists()

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_where_in_count(self, sql_assert: SqlAssert):
        """Test sync count() with IN clause on async driver."""
        sql_assert.table("sql_test_users").where(name=["Alice", "Bob"]).count(2)

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_where_in_fetch_all(self, sql_assert: SqlAssert):
        """Test sync fetch_all() with IN clause on async driver."""
        rows = sql_assert.table("sql_test_users").where(
            name=["Alice", "Bob"]
        ).order_by("name").fetch_all()

        assert len(rows) == 2
        assert rows[0]["name"] == "Alice"
        assert rows[1]["name"] == "Bob"
