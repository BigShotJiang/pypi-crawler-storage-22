"""PostgreSQL async (psycopg) configuration.

ONE config per folder = autodiscovery always finds the right one.
psycopg requires SelectorEventLoop on Windows (ProactorEventLoop not supported).
"""

import asyncio
import sys

import pytest

from fixturify.sql_d import SqlTestConfig


if sys.platform == "win32":

    @pytest.fixture
    def event_loop_policy():
        return asyncio.WindowsSelectorEventLoopPolicy()


@pytest.fixture
def sql_config() -> SqlTestConfig:
    """PostgreSQL async (psycopg) configuration - auto-discovered by @sql decorator."""
    return SqlTestConfig(
        driver="psycopg",
        host="localhost",
        port=5432,
        database="fixturify",
        user="postgres",
        password="postgres",
    )
