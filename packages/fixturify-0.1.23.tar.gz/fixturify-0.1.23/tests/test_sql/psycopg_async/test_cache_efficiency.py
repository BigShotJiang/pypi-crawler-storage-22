"""Cache efficiency test: 100 sync tests with psycopg async driver.

Verifies that the persistent event loop approach reuses a single
connection across all tests instead of creating a new one each time.
"""

import asyncio
import threading
from unittest.mock import patch

import pytest

from fixturify.sql_d import Phase, sql, SqlAssert
from fixturify.sql_d._connection_cache import ConnectionCache, CacheKey


def _can_connect() -> bool:
    try:
        import psycopg
        conn = psycopg.connect(
            host="localhost", port=5432, dbname="fixturify",
            user="postgres", password="postgres",
        )
        conn.close()
        return True
    except Exception:
        return False


# ── Global counters (thread-safe) ──────────────────────────────────

_counter_lock = threading.Lock()
_connections_created = 0   # cache misses → actual connect_factory() calls
_cache_hits = 0            # cache hits → reused existing connection
_get_async_calls = 0       # total get_async() invocations

_original_get_async = ConnectionCache.get_async


async def _counting_get_async(
    self: ConnectionCache,
    config: object,
    connect_factory: object,
) -> object:
    """Wrapper around get_async that counts cache hits vs misses."""
    global _connections_created, _cache_hits, _get_async_calls

    with _counter_lock:
        _get_async_calls += 1

    # Peek into cache to predict hit/miss BEFORE the call
    key = CacheKey.from_config(config)  # type: ignore[arg-type]
    current_loop = asyncio.get_running_loop()
    will_hit = (
        key in self._async_connections
        and self._async_connections[key][1] is current_loop
        and not current_loop.is_closed()
    )

    result = await _original_get_async(self, config, connect_factory)  # type: ignore[arg-type]

    with _counter_lock:
        if will_hit:
            _cache_hits += 1
        else:
            _connections_created += 1

    return result


# ── Patch active for entire module ─────────────────────────────────

_patcher = patch.object(ConnectionCache, "get_async", _counting_get_async)


def setup_module() -> None:
    global _connections_created, _cache_hits, _get_async_calls
    _connections_created = 0
    _cache_hits = 0
    _get_async_calls = 0
    _patcher.start()


def teardown_module() -> None:
    _patcher.stop()


# ── Autouse cleanup fixture (the scenario from the question) ───────

@pytest.fixture(autouse=True)
@sql(path="../fixtures/complex_cleanup.sql", phase=Phase.AFTER)
def _cleanup() -> None:
    """Autouse: run complex_cleanup.sql AFTER every test."""


# ── 100 sync tests with psycopg async driver ──────────────────────

pytestmark = pytest.mark.skipif(
    not _can_connect(), reason="PostgreSQL (psycopg) not available"
)


class TestCacheEfficiency:
    """100 sync def tests — all using psycopg async driver under the hood."""

    # ── departments ────────────────────────────────────────────────

    @sql(path="../fixtures/complex_setup.sql")
    def test_dept_count(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_departments").count(5)

    @sql(path="../fixtures/complex_setup.sql")
    def test_dept_eng_exists(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_departments").where(code="ENG").exists()

    @sql(path="../fixtures/complex_setup.sql")
    def test_dept_mkt_exists(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_departments").where(code="MKT").exists()

    @sql(path="../fixtures/complex_setup.sql")
    def test_dept_sal_exists(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_departments").where(code="SAL").exists()

    @sql(path="../fixtures/complex_setup.sql")
    def test_dept_hr_exists(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_departments").where(code="HR").exists()

    @sql(path="../fixtures/complex_setup.sql")
    def test_dept_fin_exists(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_departments").where(code="FIN").exists()

    @sql(path="../fixtures/complex_setup.sql")
    def test_dept_nonexistent(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_departments").where(code="XXX").not_exists()

    @sql(path="../fixtures/complex_setup.sql")
    def test_dept_eng_budget(self, sql_assert: SqlAssert) -> None:
        row = sql_assert.table("ct_departments").where(code="ENG").fetch_one()
        assert row is not None
        assert float(row["budget"]) == 500000.00

    @sql(path="../fixtures/complex_setup.sql")
    def test_dept_mkt_budget(self, sql_assert: SqlAssert) -> None:
        row = sql_assert.table("ct_departments").where(code="MKT").fetch_one()
        assert row is not None
        assert float(row["budget"]) == 200000.00

    @sql(path="../fixtures/complex_setup.sql")
    def test_dept_count_gt(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_departments").count_gt(3)

    @sql(path="../fixtures/complex_setup.sql")
    def test_dept_count_gte(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_departments").count_gte(5)

    @sql(path="../fixtures/complex_setup.sql")
    def test_dept_count_lt(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_departments").count_lt(10)

    @sql(path="../fixtures/complex_setup.sql")
    def test_dept_count_lte(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_departments").count_lte(5)

    @sql(path="../fixtures/complex_setup.sql")
    def test_dept_eng_name(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_departments").where(code="ENG").has(name="Engineering")

    @sql(path="../fixtures/complex_setup.sql")
    def test_dept_hr_name(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_departments").where(code="HR").has(name="Human Resources")

    @sql(path="../fixtures/complex_setup.sql")
    def test_dept_fetch_all(self, sql_assert: SqlAssert) -> None:
        rows = sql_assert.table("ct_departments").order_by("code").fetch_all()
        assert len(rows) == 5
        assert rows[0]["code"] == "ENG"

    @sql(path="../fixtures/complex_setup.sql")
    def test_dept_has_any_eng(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_departments").has_any(code="ENG")

    @sql(path="../fixtures/complex_setup.sql")
    def test_dept_has_any_fin(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_departments").has_any(code="FIN")

    @sql(path="../fixtures/complex_setup.sql")
    def test_dept_fin_budget(self, sql_assert: SqlAssert) -> None:
        val = sql_assert.table("ct_departments").where(code="FIN").fetch_value("budget")
        assert float(val) == 180000.00

    @sql(path="../fixtures/complex_setup.sql")
    def test_dept_sal_budget(self, sql_assert: SqlAssert) -> None:
        val = sql_assert.table("ct_departments").where(code="SAL").fetch_value("budget")
        assert float(val) == 300000.00

    # ── employees ──────────────────────────────────────────────────

    @sql(path="../fixtures/complex_setup.sql")
    def test_emp_count(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_employees").count(10)

    @sql(path="../fixtures/complex_setup.sql")
    def test_emp_alice_exists(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_employees").where(first_name="Alice").exists()

    @sql(path="../fixtures/complex_setup.sql")
    def test_emp_bob_exists(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_employees").where(first_name="Bob").exists()

    @sql(path="../fixtures/complex_setup.sql")
    def test_emp_carol_exists(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_employees").where(first_name="Carol").exists()

    @sql(path="../fixtures/complex_setup.sql")
    def test_emp_dave_exists(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_employees").where(first_name="Dave").exists()

    @sql(path="../fixtures/complex_setup.sql")
    def test_emp_eve_exists(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_employees").where(first_name="Eve").exists()

    @sql(path="../fixtures/complex_setup.sql")
    def test_emp_frank_exists(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_employees").where(first_name="Frank").exists()

    @sql(path="../fixtures/complex_setup.sql")
    def test_emp_grace_exists(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_employees").where(first_name="Grace").exists()

    @sql(path="../fixtures/complex_setup.sql")
    def test_emp_hank_exists(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_employees").where(first_name="Hank").exists()

    @sql(path="../fixtures/complex_setup.sql")
    def test_emp_iris_exists(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_employees").where(first_name="Iris").exists()

    @sql(path="../fixtures/complex_setup.sql")
    def test_emp_jack_exists(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_employees").where(first_name="Jack").exists()

    @sql(path="../fixtures/complex_setup.sql")
    def test_emp_nonexistent(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_employees").where(first_name="Zzz").not_exists()

    @sql(path="../fixtures/complex_setup.sql")
    def test_emp_alice_email(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_employees").where(first_name="Alice").has(email="alice@corp.com")

    @sql(path="../fixtures/complex_setup.sql")
    def test_emp_bob_email(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_employees").where(first_name="Bob").has(email="bob@corp.com")

    @sql(path="../fixtures/complex_setup.sql")
    def test_emp_eve_salary(self, sql_assert: SqlAssert) -> None:
        row = sql_assert.table("ct_employees").where(first_name="Eve").fetch_one()
        assert row is not None
        assert float(row["salary"]) == 105000

    @sql(path="../fixtures/complex_setup.sql")
    def test_emp_alice_salary(self, sql_assert: SqlAssert) -> None:
        val = sql_assert.table("ct_employees").where(first_name="Alice").fetch_value("salary")
        assert float(val) == 95000

    @sql(path="../fixtures/complex_setup.sql")
    def test_emp_active_count(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_employees").where(is_active=True).count(9)

    @sql(path="../fixtures/complex_setup.sql")
    def test_emp_inactive_count(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_employees").where(is_active=False).count(1)

    @sql(path="../fixtures/complex_setup.sql")
    def test_emp_inactive_is_hank(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_employees").where(is_active=False).has(first_name="Hank")

    @sql(path="../fixtures/complex_setup.sql")
    def test_emp_eng_count(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_employees").where(department_id=1).count(4)

    @sql(path="../fixtures/complex_setup.sql")
    def test_emp_mkt_count(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_employees").where(department_id=2).count(2)

    @sql(path="../fixtures/complex_setup.sql")
    def test_emp_sal_count(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_employees").where(department_id=3).count(2)

    @sql(path="../fixtures/complex_setup.sql")
    def test_emp_hr_count(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_employees").where(department_id=4).count(1)

    @sql(path="../fixtures/complex_setup.sql")
    def test_emp_fin_count(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_employees").where(department_id=5).count(1)

    @sql(path="../fixtures/complex_setup.sql")
    def test_emp_count_gt(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_employees").count_gt(5)

    @sql(path="../fixtures/complex_setup.sql")
    def test_emp_count_lt(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_employees").count_lt(100)

    @sql(path="../fixtures/complex_setup.sql")
    def test_emp_has_any_alice(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_employees").has_any(email="alice@corp.com")

    @sql(path="../fixtures/complex_setup.sql")
    def test_emp_has_any_jack(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_employees").has_any(email="jack@corp.com")

    @sql(path="../fixtures/complex_setup.sql")
    def test_emp_fetch_all_eng(self, sql_assert: SqlAssert) -> None:
        rows = sql_assert.table("ct_employees").where(department_id=1).order_by("first_name").fetch_all()
        assert len(rows) == 4
        assert rows[0]["first_name"] == "Alice"

    @sql(path="../fixtures/complex_setup.sql")
    def test_emp_alice_dept(self, sql_assert: SqlAssert) -> None:
        val = sql_assert.table("ct_employees").where(first_name="Alice").fetch_value("department_id")
        assert val == 1

    # ── projects ───────────────────────────────────────────────────

    @sql(path="../fixtures/complex_setup.sql")
    def test_proj_count(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_projects").count(6)

    @sql(path="../fixtures/complex_setup.sql")
    def test_proj_alpha_exists(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_projects").where(name="Project Alpha").exists()

    @sql(path="../fixtures/complex_setup.sql")
    def test_proj_beta_exists(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_projects").where(name="Project Beta").exists()

    @sql(path="../fixtures/complex_setup.sql")
    def test_proj_campaign_exists(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_projects").where(name="Campaign Q1").exists()

    @sql(path="../fixtures/complex_setup.sql")
    def test_proj_sales_exists(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_projects").where(name="Sales Push").exists()

    @sql(path="../fixtures/complex_setup.sql")
    def test_proj_hr_exists(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_projects").where(name="HR Portal").exists()

    @sql(path="../fixtures/complex_setup.sql")
    def test_proj_budget_exists(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_projects").where(name="Budget Tool").exists()

    @sql(path="../fixtures/complex_setup.sql")
    def test_proj_nonexistent(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_projects").where(name="Fake").not_exists()

    @sql(path="../fixtures/complex_setup.sql")
    def test_proj_active_count(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_projects").where(status="active").count(4)

    @sql(path="../fixtures/complex_setup.sql")
    def test_proj_completed_count(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_projects").where(status="completed").count(1)

    @sql(path="../fixtures/complex_setup.sql")
    def test_proj_planning_count(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_projects").where(status="planning").count(1)

    @sql(path="../fixtures/complex_setup.sql")
    def test_proj_alpha_budget(self, sql_assert: SqlAssert) -> None:
        val = sql_assert.table("ct_projects").where(name="Project Alpha").fetch_value("budget")
        assert float(val) == 100000

    @sql(path="../fixtures/complex_setup.sql")
    def test_proj_beta_budget(self, sql_assert: SqlAssert) -> None:
        val = sql_assert.table("ct_projects").where(name="Project Beta").fetch_value("budget")
        assert float(val) == 150000

    @sql(path="../fixtures/complex_setup.sql")
    def test_proj_alpha_lead(self, sql_assert: SqlAssert) -> None:
        val = sql_assert.table("ct_projects").where(name="Project Alpha").fetch_value("lead_id")
        assert val == 1

    @sql(path="../fixtures/complex_setup.sql")
    def test_proj_beta_lead(self, sql_assert: SqlAssert) -> None:
        val = sql_assert.table("ct_projects").where(name="Project Beta").fetch_value("lead_id")
        assert val == 5

    @sql(path="../fixtures/complex_setup.sql")
    def test_proj_campaign_completed(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_projects").where(name="Campaign Q1").has(status="completed")

    @sql(path="../fixtures/complex_setup.sql")
    def test_proj_hr_planning(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_projects").where(name="HR Portal").has(status="planning")

    @sql(path="../fixtures/complex_setup.sql")
    def test_proj_fetch_all_active(self, sql_assert: SqlAssert) -> None:
        rows = sql_assert.table("ct_projects").where(status="active").fetch_all()
        assert len(rows) == 4

    @sql(path="../fixtures/complex_setup.sql")
    def test_proj_has_any_active(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_projects").has_any(status="active")

    @sql(path="../fixtures/complex_setup.sql")
    def test_proj_has_any_completed(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_projects").has_any(status="completed")

    @sql(path="../fixtures/complex_setup.sql")
    def test_proj_count_gt(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_projects").count_gt(3)

    @sql(path="../fixtures/complex_setup.sql")
    def test_proj_count_lt(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_projects").count_lt(50)

    # ── assignments ────────────────────────────────────────────────

    @sql(path="../fixtures/complex_setup.sql")
    def test_assign_count(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_assignments").count(10)

    @sql(path="../fixtures/complex_setup.sql")
    def test_assign_lead_count(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_assignments").where(role="Lead").count(6)

    @sql(path="../fixtures/complex_setup.sql")
    def test_assign_dev_count(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_assignments").where(role="Developer").count(3)

    @sql(path="../fixtures/complex_setup.sql")
    def test_assign_designer_count(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_assignments").where(role="Designer").count(1)

    @sql(path="../fixtures/complex_setup.sql")
    def test_assign_has_any_lead(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_assignments").has_any(role="Lead")

    @sql(path="../fixtures/complex_setup.sql")
    def test_assign_has_any_designer(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_assignments").has_any(role="Designer")

    @sql(path="../fixtures/complex_setup.sql")
    def test_assign_proj1_count(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_assignments").where(project_id=1).count(3)

    @sql(path="../fixtures/complex_setup.sql")
    def test_assign_proj2_count(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_assignments").where(project_id=2).count(2)

    @sql(path="../fixtures/complex_setup.sql")
    def test_assign_proj3_count(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_assignments").where(project_id=3).count(2)

    @sql(path="../fixtures/complex_setup.sql")
    def test_assign_proj4_count(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_assignments").where(project_id=4).count(1)

    @sql(path="../fixtures/complex_setup.sql")
    def test_assign_40h_count(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_assignments").where(hours_allocated=40).count_gt(3)

    @sql(path="../fixtures/complex_setup.sql")
    def test_assign_fetch_all_proj1(self, sql_assert: SqlAssert) -> None:
        rows = sql_assert.table("ct_assignments").where(project_id=1).fetch_all()
        assert len(rows) == 3

    @sql(path="../fixtures/complex_setup.sql")
    def test_assign_count_gt(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_assignments").count_gt(5)

    @sql(path="../fixtures/complex_setup.sql")
    def test_assign_count_lt(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_assignments").count_lt(100)

    @sql(path="../fixtures/complex_setup.sql")
    def test_assign_count_gte(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_assignments").count_gte(10)

    @sql(path="../fixtures/complex_setup.sql")
    def test_assign_count_lte(self, sql_assert: SqlAssert) -> None:
        sql_assert.table("ct_assignments").count_lte(10)

    # ── cross-table queries via raw SQL ────────────────────────────

    @sql(path="../fixtures/complex_setup.sql")
    def test_raw_eng_employees(self, sql_assert: SqlAssert) -> None:
        sql_assert.raw(
            "SELECT e.* FROM ct_employees e "
            "JOIN ct_departments d ON e.department_id = d.id "
            "WHERE d.code = %s", ["ENG"]
        ).exists()

    @sql(path="../fixtures/complex_setup.sql")
    def test_raw_active_projects(self, sql_assert: SqlAssert) -> None:
        rows = sql_assert.raw(
            "SELECT * FROM ct_projects WHERE status = %s", ["active"]
        ).fetch_all()
        assert len(rows) == 4

    @sql(path="../fixtures/complex_setup.sql")
    def test_raw_assignment_join(self, sql_assert: SqlAssert) -> None:
        rows = sql_assert.raw(
            "SELECT a.role, e.first_name FROM ct_assignments a "
            "JOIN ct_employees e ON a.employee_id = e.id "
            "WHERE a.role = %s", ["Lead"]
        ).fetch_all()
        assert len(rows) == 6

    @sql(path="../fixtures/complex_setup.sql")
    def test_raw_dept_budget_sum(self, sql_assert: SqlAssert) -> None:
        row = sql_assert.raw(
            "SELECT SUM(budget) as total FROM ct_departments"
        ).fetch_one()
        assert row is not None
        assert float(row["total"]) == 1330000

    @sql(path="../fixtures/complex_setup.sql")
    def test_raw_highest_salary(self, sql_assert: SqlAssert) -> None:
        row = sql_assert.raw(
            "SELECT MAX(salary) as max_sal FROM ct_employees"
        ).fetch_one()
        assert row is not None
        assert float(row["max_sal"]) == 105000

    # ── final test: verify cache efficiency ────────────────────────

    @sql(path="../fixtures/complex_setup.sql")
    def test_zzz_cache_counters(self, sql_assert: SqlAssert) -> None:
        """Runs last (alphabetically). Checks the counters collected above."""
        # Sanity: the test data is present
        sql_assert.table("ct_departments").count(5)

        from fixturify.sql_d import _query_executor

        # ── persistent loop ────────────────────────────────────────
        loop = _query_executor._loop
        assert loop is not None, "Persistent loop was never created"
        assert not loop.is_closed(), "Persistent loop was closed mid-session"

        # ── connection cache ───────────────────────────────────────
        # At most 1 real connection should have been created for psycopg.
        # The decorator (@sql) and sql_assert share the same cache key,
        # so both go through the same cached connection.
        assert _connections_created <= 2, (
            f"Expected at most 2 connections (decorator + executor), "
            f"got {_connections_created}"
        )

        # Hundreds of get_async() calls should have been cache hits
        assert _get_async_calls > 100, (
            f"Expected >100 get_async calls, got {_get_async_calls}"
        )
        assert _cache_hits > 100, (
            f"Expected >100 cache hits, got {_cache_hits}"
        )

        hit_rate = _cache_hits / _get_async_calls * 100
        assert hit_rate > 95, (
            f"Cache hit rate too low: {hit_rate:.1f}% "
            f"(hits={_cache_hits}, misses={_connections_created}, "
            f"total={_get_async_calls})"
        )

        print(
            f"\n{'=' * 60}\n"
            f"  CACHE EFFICIENCY REPORT\n"
            f"{'=' * 60}\n"
            f"  get_async() calls : {_get_async_calls}\n"
            f"  cache hits        : {_cache_hits}\n"
            f"  new connections   : {_connections_created}\n"
            f"  hit rate          : {hit_rate:.1f}%\n"
            f"  persistent loop   : {loop!r}\n"
            f"{'=' * 60}",
            flush=True,
        )
