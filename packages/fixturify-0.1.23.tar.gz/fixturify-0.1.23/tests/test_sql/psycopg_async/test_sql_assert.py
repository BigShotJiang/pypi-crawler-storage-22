"""Tests for SqlAssert with PostgreSQL async (psycopg)."""

from dataclasses import dataclass
from typing import Any, Dict, List, Optional

import pytest

from fixturify.sql_d import Phase, sql, SqlAssert


def _can_connect() -> bool:
    """Check if PostgreSQL is available via psycopg."""
    try:
        import psycopg

        conn = psycopg.connect(
            host="localhost",
            port=5432,
            dbname="fixturify",
            user="postgres",
            password="postgres",
        )
        conn.close()
        return True
    except Exception:
        return False


@dataclass
class User:
    """Test user model for ObjectMapper integration."""

    id: int
    name: str
    email: Optional[str] = None


@pytest.mark.skipif(not _can_connect(), reason="PostgreSQL (psycopg) not available")
class TestPsycopgSqlAssert:
    """PostgreSQL async (psycopg) SqlAssert tests."""

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_aexists(self, sql_assert: SqlAssert):
        """Test aexists() assertion."""
        await sql_assert.table("sql_test_users").where(name="Alice").aexists()

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_aexists_fails_when_no_match(self, sql_assert: SqlAssert):
        """Test aexists() raises when no rows match."""
        with pytest.raises(AssertionError, match="Expected at least 1 row"):
            await sql_assert.table("sql_test_users").where(name="NonExistent").aexists()

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_anot_exists(self, sql_assert: SqlAssert):
        """Test anot_exists() assertion."""
        await sql_assert.table("sql_test_users").where(name="NonExistent").anot_exists()

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_anot_exists_fails_when_match(self, sql_assert: SqlAssert):
        """Test anot_exists() raises when rows match."""
        with pytest.raises(AssertionError, match="Expected 0 rows"):
            await sql_assert.table("sql_test_users").where(name="Alice").anot_exists()

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_acount(self, sql_assert: SqlAssert):
        """Test acount() assertion."""
        await sql_assert.table("sql_test_users").acount(2)

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_acount_with_where(self, sql_assert: SqlAssert):
        """Test acount() with WHERE clause."""
        await sql_assert.table("sql_test_users").where(name="Alice").acount(1)

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_acount_fails_on_mismatch(self, sql_assert: SqlAssert):
        """Test acount() raises on mismatch."""
        with pytest.raises(AssertionError, match="Expected 5 rows"):
            await sql_assert.table("sql_test_users").acount(5)

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_afetch_one(self, sql_assert: SqlAssert):
        """Test afetch_one() returns dict."""
        row = await sql_assert.table("sql_test_users").where(name="Alice").afetch_one()

        assert row is not None
        assert row["name"] == "Alice"
        assert row["email"] == "alice@example.com"

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_afetch_one_none(self, sql_assert: SqlAssert):
        """Test afetch_one() returns None when no match."""
        row = await sql_assert.table("sql_test_users").where(name="NonExistent").afetch_one()

        assert row is None

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_afetch_one_with_object_mapper(self, sql_assert: SqlAssert):
        """Test afetch_one() with ObjectMapper."""
        user = await sql_assert.table("sql_test_users").where(name="Alice").afetch_one(User)

        assert isinstance(user, User)
        assert user.name == "Alice"
        assert user.email == "alice@example.com"

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_afetch_all(self, sql_assert: SqlAssert):
        """Test afetch_all() returns list of dicts."""
        rows: List[Dict[str, Any]] = await sql_assert.table("sql_test_users").order_by("name").afetch_all()

        assert len(rows) == 2
        assert rows[0]["name"] == "Alice"
        assert rows[1]["name"] == "Bob"

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_afetch_all_with_object_mapper(self, sql_assert: SqlAssert):
        """Test afetch_all() with ObjectMapper."""
        users: List[User] = await sql_assert.table("sql_test_users").order_by("name").afetch_all(User)  # type: ignore[assignment]

        assert len(users) == 2
        assert all(isinstance(u, User) for u in users)
        assert users[0].name == "Alice"
        assert users[1].name == "Bob"

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_afetch_value(self, sql_assert: SqlAssert):
        """Test afetch_value() returns single value."""
        email = await sql_assert.table("sql_test_users").where(name="Alice").afetch_value("email")

        assert email == "alice@example.com"

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_acount_gt(self, sql_assert: SqlAssert):
        """Test acount_gt() assertion."""
        await sql_assert.table("sql_test_users").acount_gt(1)

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_acount_gt_fails(self, sql_assert: SqlAssert):
        """Test acount_gt() raises when count <= n."""
        with pytest.raises(AssertionError, match="Expected more than 2 rows"):
            await sql_assert.table("sql_test_users").acount_gt(2)

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_acount_gte(self, sql_assert: SqlAssert):
        """Test acount_gte() assertion."""
        await sql_assert.table("sql_test_users").acount_gte(2)

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_acount_lt(self, sql_assert: SqlAssert):
        """Test acount_lt() assertion."""
        await sql_assert.table("sql_test_users").acount_lt(10)

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_acount_lte(self, sql_assert: SqlAssert):
        """Test acount_lte() assertion."""
        await sql_assert.table("sql_test_users").acount_lte(2)

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_ahas(self, sql_assert: SqlAssert):
        """Test ahas() with matching values."""
        await sql_assert.table("sql_test_users").where(name="Alice").ahas(
            email="alice@example.com"
        )

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_ahas_fails_on_mismatch(self, sql_assert: SqlAssert):
        """Test ahas() raises on value mismatch."""
        with pytest.raises(AssertionError, match="doesn't match expected values"):
            await sql_assert.table("sql_test_users").where(name="Alice").ahas(
                email="wrong@example.com"
            )

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_ahas_fails_on_missing_row(self, sql_assert: SqlAssert):
        """Test ahas() raises when no row found."""
        with pytest.raises(AssertionError, match="Expected row"):
            await sql_assert.table("sql_test_users").where(name="NonExistent").ahas(
                email="any@example.com"
            )

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_ahas_all(self, sql_assert: SqlAssert):
        """Test ahas_all() - all rows match field."""
        await sql_assert.table("sql_test_users").where(name="Alice").ahas_all(email="alice@example.com")

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_ahas_any(self, sql_assert: SqlAssert):
        """Test ahas_any() finds matching row."""
        await sql_assert.table("sql_test_users").ahas_any(email="bob@example.com")

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_ahas_any_fails(self, sql_assert: SqlAssert):
        """Test ahas_any() raises when no row matches."""
        with pytest.raises(AssertionError, match="No row in .* matches"):
            await sql_assert.table("sql_test_users").ahas_any(email="nonexistent@example.com")


@pytest.mark.skipif(not _can_connect(), reason="PostgreSQL (psycopg) not available")
class TestPsycopgSyncWithAsyncDriver:
    """Test sync SqlAssert methods with psycopg async driver."""

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_exists(self, sql_assert: SqlAssert):
        """Test sync exists() with async driver."""
        sql_assert.table("sql_test_users").where(name="Alice").exists()

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_not_exists(self, sql_assert: SqlAssert):
        """Test sync not_exists() with async driver."""
        sql_assert.table("sql_test_users").where(name="NonExistent").not_exists()

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_count(self, sql_assert: SqlAssert):
        """Test sync count() with async driver."""
        sql_assert.table("sql_test_users").count(2)

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_fetch_one(self, sql_assert: SqlAssert):
        """Test sync fetch_one() with async driver."""
        row = sql_assert.table("sql_test_users").where(name="Alice").fetch_one()

        assert row is not None
        assert row["name"] == "Alice"
        assert row["email"] == "alice@example.com"

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_fetch_all(self, sql_assert: SqlAssert):
        """Test sync fetch_all() with async driver."""
        rows = sql_assert.table("sql_test_users").order_by("name").fetch_all()

        assert len(rows) == 2
        assert rows[0]["name"] == "Alice"
        assert rows[1]["name"] == "Bob"

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_has(self, sql_assert: SqlAssert):
        """Test sync has() with async driver."""
        sql_assert.table("sql_test_users").where(name="Alice").has(
            email="alice@example.com"
        )

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_fetch_value(self, sql_assert: SqlAssert):
        """Test sync fetch_value() with async driver."""
        email = sql_assert.table("sql_test_users").where(name="Alice").fetch_value("email")

        assert email == "alice@example.com"


@pytest.mark.skipif(not _can_connect(), reason="PostgreSQL (psycopg) not available")
class TestPsycopgWhereIn:
    """Tests for where() with list values (IN clause) — psycopg async."""

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_where_in_aexists(self, sql_assert: SqlAssert):
        """Test aexists() with IN clause."""
        await sql_assert.table("sql_test_users").where(name=["Alice", "Bob"]).aexists()

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_where_in_acount(self, sql_assert: SqlAssert):
        """Test acount() with IN clause."""
        await sql_assert.table("sql_test_users").where(name=["Alice", "Bob"]).acount(2)

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_where_in_single_element(self, sql_assert: SqlAssert):
        """Test IN with single-element list."""
        await sql_assert.table("sql_test_users").where(name=["Alice"]).acount(1)

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_where_in_no_match(self, sql_assert: SqlAssert):
        """Test IN clause with no matching values."""
        await sql_assert.table("sql_test_users").where(name=["X", "Y"]).anot_exists()

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_where_in_with_scalar(self, sql_assert: SqlAssert):
        """Test IN clause combined with scalar equality."""
        await sql_assert.table("sql_test_users").where(
            name=["Alice", "Bob"], email="alice@example.com"
        ).acount(1)

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_where_in_afetch_all(self, sql_assert: SqlAssert):
        """Test afetch_all() with IN clause."""
        rows = await sql_assert.table("sql_test_users").where(
            name=["Alice", "Bob"]
        ).order_by("name").afetch_all()

        assert len(rows) == 2
        assert rows[0]["name"] == "Alice"
        assert rows[1]["name"] == "Bob"

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_where_in_afetch_one(self, sql_assert: SqlAssert):
        """Test afetch_one() with IN clause."""
        row = await sql_assert.table("sql_test_users").where(
            name=["Alice"]
        ).afetch_one()

        assert row is not None
        assert row["name"] == "Alice"

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    async def test_where_in_empty_list_raises(self, sql_assert: SqlAssert):
        """Test that empty list raises ValueError."""
        with pytest.raises(ValueError, match="where\\(\\) does not accept empty lists"):
            await sql_assert.table("sql_test_users").where(name=[]).aexists()


@pytest.mark.skipif(not _can_connect(), reason="PostgreSQL (psycopg) not available")
class TestPsycopgWhereInSync:
    """Tests for where() with list values (IN clause) — sync methods with psycopg async driver."""

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_where_in_exists(self, sql_assert: SqlAssert):
        """Test sync exists() with IN clause on async driver."""
        sql_assert.table("sql_test_users").where(name=["Alice", "Bob"]).exists()

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_where_in_count(self, sql_assert: SqlAssert):
        """Test sync count() with IN clause on async driver."""
        sql_assert.table("sql_test_users").where(name=["Alice", "Bob"]).count(2)

    @sql(path="../fixtures/postgres_setup.sql")
    @sql(path="../fixtures/postgres_cleanup.sql", phase=Phase.AFTER)
    def test_where_in_fetch_all(self, sql_assert: SqlAssert):
        """Test sync fetch_all() with IN clause on async driver."""
        rows = sql_assert.table("sql_test_users").where(
            name=["Alice", "Bob"]
        ).order_by("name").fetch_all()

        assert len(rows) == 2
        assert rows[0]["name"] == "Alice"
        assert rows[1]["name"] == "Bob"
