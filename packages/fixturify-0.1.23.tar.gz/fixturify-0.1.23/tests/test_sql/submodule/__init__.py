"""Tests for nested path resolution."""
