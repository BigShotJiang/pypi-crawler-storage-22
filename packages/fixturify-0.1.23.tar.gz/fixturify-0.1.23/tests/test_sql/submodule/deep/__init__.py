"""Deeply nested test module for path resolution testing."""
