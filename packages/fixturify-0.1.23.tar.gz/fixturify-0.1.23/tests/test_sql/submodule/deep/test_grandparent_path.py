"""Tests for grandparent path resolution in SQL decorator (../../)."""

from fixturify._utils import _PathResolver


class TestGrandparentPathResolution:
    """Tests for path resolution from deeply nested directories."""

    def test_grandparent_directory(self) -> None:
        """Test resolving file in grandparent directory (../../)."""
        test_file = __file__
        resolved = _PathResolver.resolve(
            "../../fixtures/setup.sql", reference_file=test_file
        )
        assert resolved.exists()
        assert resolved.name == "setup.sql"

    def test_grandparent_nested_path(self) -> None:
        """Test resolving nested file from grandparent (../../fixtures/nested/deep.sql)."""
        test_file = __file__
        resolved = _PathResolver.resolve(
            "../../fixtures/nested/deep.sql", reference_file=test_file
        )
        assert resolved.exists()
        assert resolved.name == "deep.sql"

    def test_grandparent_postgres_setup(self) -> None:
        """Test resolving postgres setup file from grandparent."""
        test_file = __file__
        resolved = _PathResolver.resolve(
            "../../fixtures/postgres_setup.sql", reference_file=test_file
        )
        assert resolved.exists()
        assert resolved.name == "postgres_setup.sql"

    def test_grandparent_path_not_found(self) -> None:
        """Test that FileNotFoundError is raised for missing grandparent file."""
        import pytest

        test_file = __file__
        with pytest.raises(FileNotFoundError) as exc_info:
            _PathResolver.resolve(
                "../../fixtures/nonexistent.sql", reference_file=test_file
            )
        assert "nonexistent.sql" in str(exc_info.value)
