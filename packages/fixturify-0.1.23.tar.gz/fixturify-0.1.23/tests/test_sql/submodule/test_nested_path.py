"""Tests for nested path resolution in SQL decorator."""

from fixturify._utils import _PathResolver


class TestNestedPathResolution:
    """Tests for path resolution from nested directories."""

    def test_parent_directory(self) -> None:
        """Test resolving file in parent directory."""
        test_file = __file__
        resolved = _PathResolver.resolve(
            "../fixtures/setup.sql", reference_file=test_file
        )
        assert resolved.exists()
        assert resolved.name == "setup.sql"

    def test_deep_nested_path(self) -> None:
        """Test resolving deeply nested file."""
        test_file = __file__
        resolved = _PathResolver.resolve(
            "../fixtures/nested/deep.sql", reference_file=test_file
        )
        assert resolved.exists()
        assert resolved.name == "deep.sql"
