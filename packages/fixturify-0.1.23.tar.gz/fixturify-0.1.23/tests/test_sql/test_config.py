"""Tests for SqlTestConfig dataclass."""

from fixturify.sql_d import SqlTestConfig


class TestSqlTestConfig:
    """Tests for SqlTestConfig dataclass."""

    def test_required_fields(self) -> None:
        """Test that required fields must be provided."""
        config = SqlTestConfig(
            driver="psycopg2",
            host="localhost",
            database="test_db",
            user="test_user",
            password="test_pass",
        )
        assert config.driver == "psycopg2"
        assert config.host == "localhost"
        assert config.database == "test_db"
        assert config.user == "test_user"
        assert config.password == "test_pass"

    def test_optional_port_default(self) -> None:
        """Test that port defaults to None."""
        config = SqlTestConfig(
            driver="psycopg2",
            host="localhost",
            database="test_db",
            user="test_user",
            password="test_pass",
        )
        assert config.port is None

    def test_optional_port_set(self) -> None:
        """Test that port can be set."""
        config = SqlTestConfig(
            driver="psycopg2",
            host="localhost",
            database="test_db",
            user="test_user",
            password="test_pass",
            port=5432,
        )
        assert config.port == 5432

    def test_postgres_config(self) -> None:
        """Test PostgreSQL configuration."""
        config = SqlTestConfig(
            driver="psycopg2",
            host="localhost",
            database="fixturify",
            user="postgres",
            password="postgres",
            port=5432,
        )
        assert config.driver == "psycopg2"

    def test_mysql_config(self) -> None:
        """Test MySQL configuration."""
        config = SqlTestConfig(
            driver="mysql.connector",
            host="localhost",
            database="fixturify",
            user="root",
            password="",
            port=3306,
        )
        assert config.driver == "mysql.connector"

    def test_async_postgres_config(self) -> None:
        """Test async PostgreSQL configuration."""
        config = SqlTestConfig(
            driver="asyncpg",
            host="localhost",
            database="fixturify",
            user="postgres",
            password="postgres",
            port=5432,
        )
        assert config.driver == "asyncpg"

    def test_async_mysql_config(self) -> None:
        """Test async MySQL configuration."""
        config = SqlTestConfig(
            driver="aiomysql",
            host="localhost",
            database="fixturify",
            user="root",
            password="",
            port=3306,
        )
        assert config.driver == "aiomysql"
