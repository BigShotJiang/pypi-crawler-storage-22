"""Tests for the connection cache module."""

import pytest
from unittest.mock import Mock, AsyncMock

from fixturify.sql_d._connection_cache import (
    CacheKey,
    ConnectionCache,
    get_connection_cache,
)
from fixturify.sql_d import SqlTestConfig


class TestCacheKey:
    """Tests for CacheKey."""

    def test_from_config(self) -> None:
        """Test creating cache key from config."""
        config = SqlTestConfig(
            driver="psycopg2",
            host="localhost",
            database="testdb",
            user="testuser",
            password="testpass",
            port=5432,
        )
        key = CacheKey.from_config(config)

        assert key.driver == "psycopg2"
        assert key.host == "localhost"
        assert key.database == "testdb"
        assert key.user == "testuser"
        assert key.port == 5432

    def test_cache_key_equality(self) -> None:
        """Test that identical configs produce equal keys."""
        config1 = SqlTestConfig(
            driver="psycopg2",
            host="localhost",
            database="testdb",
            user="testuser",
            password="pass1",
            port=5432,
        )
        config2 = SqlTestConfig(
            driver="psycopg2",
            host="localhost",
            database="testdb",
            user="testuser",
            password="pass2",  # Different password
            port=5432,
        )

        key1 = CacheKey.from_config(config1)
        key2 = CacheKey.from_config(config2)

        # Keys should be equal (password is not part of key)
        assert key1 == key2

    def test_cache_key_different_host(self) -> None:
        """Test that different hosts produce different keys."""
        config1 = SqlTestConfig(
            driver="psycopg2",
            host="localhost",
            database="testdb",
            user="testuser",
            password="testpass",
        )
        config2 = SqlTestConfig(
            driver="psycopg2",
            host="remotehost",
            database="testdb",
            user="testuser",
            password="testpass",
        )

        key1 = CacheKey.from_config(config1)
        key2 = CacheKey.from_config(config2)

        assert key1 != key2

    def test_cache_key_hashable(self) -> None:
        """Test that cache key can be used in dict."""
        config = SqlTestConfig(
            driver="psycopg2",
            host="localhost",
            database="testdb",
            user="testuser",
            password="testpass",
        )
        key = CacheKey.from_config(config)

        # Should be usable as dict key
        d = {key: "value"}
        assert d[key] == "value"


class TestConnectionCache:
    """Tests for ConnectionCache."""

    def setup_method(self) -> None:
        """Reset singleton before each test."""
        ConnectionCache._instance = None

    def test_singleton(self) -> None:
        """Test that ConnectionCache is a singleton."""
        cache1 = ConnectionCache()
        cache2 = ConnectionCache()
        assert cache1 is cache2

    def test_get_sync_creates_connection(self) -> None:
        """Test that get_sync creates connection on first call."""
        cache = ConnectionCache()
        config = SqlTestConfig(
            driver="psycopg2",
            host="localhost",
            database="testdb",
            user="testuser",
            password="testpass",
        )

        mock_conn = Mock()
        mock_connect = Mock(return_value=mock_conn)

        result = cache.get_sync(config, mock_connect, {"host": "localhost"})

        assert result is mock_conn
        mock_connect.assert_called_once_with(host="localhost")

    def test_get_sync_reuses_connection(self) -> None:
        """Test that get_sync reuses existing connection."""
        cache = ConnectionCache()
        config = SqlTestConfig(
            driver="psycopg2",
            host="localhost",
            database="testdb",
            user="testuser",
            password="testpass",
        )

        mock_conn = Mock()
        mock_connect = Mock(return_value=mock_conn)

        # First call creates connection
        result1 = cache.get_sync(config, mock_connect, {"host": "localhost"})
        # Second call reuses
        result2 = cache.get_sync(config, mock_connect, {"host": "localhost"})

        assert result1 is result2
        # connect should only be called once
        mock_connect.assert_called_once()

    def test_get_sync_different_configs(self) -> None:
        """Test that different configs get different connections."""
        cache = ConnectionCache()
        config1 = SqlTestConfig(
            driver="psycopg2",
            host="host1",
            database="testdb",
            user="testuser",
            password="testpass",
        )
        config2 = SqlTestConfig(
            driver="psycopg2",
            host="host2",
            database="testdb",
            user="testuser",
            password="testpass",
        )

        mock_conn1 = Mock(name="conn1")
        mock_conn2 = Mock(name="conn2")
        mock_connect = Mock(side_effect=[mock_conn1, mock_conn2])

        result1 = cache.get_sync(config1, mock_connect, {"host": "host1"})
        result2 = cache.get_sync(config2, mock_connect, {"host": "host2"})

        assert result1 is mock_conn1
        assert result2 is mock_conn2
        assert mock_connect.call_count == 2

    @pytest.mark.asyncio
    async def test_get_async_creates_connection(self) -> None:
        """Test that get_async creates connection on first call."""
        cache = ConnectionCache()
        config = SqlTestConfig(
            driver="asyncpg",
            host="localhost",
            database="testdb",
            user="testuser",
            password="testpass",
        )

        mock_conn = AsyncMock()

        async def connect_factory():
            return mock_conn

        result = await cache.get_async(config, connect_factory)

        assert result is mock_conn

    @pytest.mark.asyncio
    async def test_get_async_reuses_connection(self) -> None:
        """Test that get_async reuses existing connection."""
        cache = ConnectionCache()
        config = SqlTestConfig(
            driver="asyncpg",
            host="localhost",
            database="testdb",
            user="testuser",
            password="testpass",
        )

        mock_conn = AsyncMock()
        call_count = 0

        async def connect_factory():
            nonlocal call_count
            call_count += 1
            return mock_conn

        # First call - creates connection
        result1 = await cache.get_async(config, connect_factory)
        # Second call - reuses connection
        result2 = await cache.get_async(config, connect_factory)

        assert result1 is result2
        # Factory should only be called once (cache hit on second call)
        assert call_count == 1

    def test_close_all_sync(self) -> None:
        """Test that close_all_sync closes all connections."""
        cache = ConnectionCache()
        config = SqlTestConfig(
            driver="psycopg2",
            host="localhost",
            database="testdb",
            user="testuser",
            password="testpass",
        )

        mock_conn = Mock()
        mock_connect = Mock(return_value=mock_conn)

        cache.get_sync(config, mock_connect, {})
        cache.close_all_sync()

        mock_conn.close.assert_called_once()

    def test_clear_removes_all(self) -> None:
        """Test that clear removes all connections."""
        cache = ConnectionCache()
        config = SqlTestConfig(
            driver="psycopg2",
            host="localhost",
            database="testdb",
            user="testuser",
            password="testpass",
        )

        mock_conn = Mock()
        mock_connect = Mock(return_value=mock_conn)

        cache.get_sync(config, mock_connect, {})
        cache.clear()

        # After clear, getting connection should create new one
        mock_conn2 = Mock()
        mock_connect2 = Mock(return_value=mock_conn2)
        result = cache.get_sync(config, mock_connect2, {})

        assert result is mock_conn2


class TestGetConnectionCache:
    """Tests for get_connection_cache function."""

    def setup_method(self) -> None:
        """Reset singleton before each test."""
        ConnectionCache._instance = None
        # Also reset module-level cache
        import fixturify.sql_d._connection_cache as cache_module
        cache_module._cache = None

    def test_returns_singleton(self) -> None:
        """Test that get_connection_cache returns same instance."""
        cache1 = get_connection_cache()
        cache2 = get_connection_cache()
        assert cache1 is cache2
