"""Tests for the @sql decorator."""

import pytest

from fixturify.sql_d import Phase, SqlTestConfig, sql


class TestSqlDecorator:
    """Tests for @sql decorator."""

    def test_decorator_preserves_function_name(self) -> None:
        """Test that decorator preserves function name."""
        config = SqlTestConfig(
            driver="psycopg2",
            host="localhost",
            database="test",
            user="test",
            password="test",
        )

        @sql(path="fixtures/setup.sql", config=config)
        def test_function() -> None:
            pass

        assert test_function.__name__ == "test_function"

    def test_decorator_with_phase_before(self) -> None:
        """Test decorator with BEFORE phase."""
        config = SqlTestConfig(
            driver="psycopg2",
            host="localhost",
            database="test",
            user="test",
            password="test",
        )

        @sql(path="fixtures/setup.sql", phase=Phase.BEFORE, config=config)
        def test_function() -> None:
            pass

        # Check that decorator metadata is stored
        assert hasattr(test_function, "_sql_decorators")
        decorators = test_function._sql_decorators
        assert len(decorators) == 1
        assert decorators[0][1] == Phase.BEFORE

    def test_decorator_with_phase_after(self) -> None:
        """Test decorator with AFTER phase."""
        config = SqlTestConfig(
            driver="psycopg2",
            host="localhost",
            database="test",
            user="test",
            password="test",
        )

        @sql(path="fixtures/cleanup.sql", phase=Phase.AFTER, config=config)
        def test_function() -> None:
            pass

        decorators = test_function._sql_decorators
        assert len(decorators) == 1
        assert decorators[0][1] == Phase.AFTER

    def test_chained_decorators(self) -> None:
        """Test multiple stacked decorators."""
        config = SqlTestConfig(
            driver="psycopg2",
            host="localhost",
            database="test",
            user="test",
            password="test",
        )

        @sql(path="fixtures/setup.sql", phase=Phase.BEFORE, config=config)
        @sql(path="fixtures/cleanup.sql", phase=Phase.AFTER, config=config)
        def test_function() -> None:
            pass

        decorators = test_function._sql_decorators
        assert len(decorators) == 2

    def test_missing_config_raises_error(self) -> None:
        """Test that missing config raises ValueError."""

        @sql(path="fixtures/setup.sql")
        def test_function() -> None:
            pass

        with pytest.raises(ValueError) as exc_info:
            test_function()
        assert "No database configuration provided" in str(exc_info.value)

    def test_missing_file_raises_error(self) -> None:
        """Test that missing SQL file raises FileNotFoundError."""
        config = SqlTestConfig(
            driver="psycopg2",
            host="localhost",
            database="test",
            user="test",
            password="test",
        )

        @sql(path="nonexistent.sql", config=config)
        def test_function() -> None:
            pass

        with pytest.raises(FileNotFoundError) as exc_info:
            test_function()
        assert "nonexistent.sql" in str(exc_info.value)


class TestAsyncDecorator:
    """Tests for @sql decorator with async functions."""

    def test_async_decorator_preserves_coroutine(self) -> None:
        """Test that decorator preserves async function."""
        import asyncio

        config = SqlTestConfig(
            driver="psycopg2",
            host="localhost",
            database="test",
            user="test",
            password="test",
        )

        @sql(path="fixtures/setup.sql", config=config)
        async def test_function() -> None:
            pass

        assert asyncio.iscoroutinefunction(test_function)

    @pytest.mark.asyncio
    async def test_async_missing_config_raises_error(self) -> None:
        """Test that missing config raises ValueError in async."""

        @sql(path="fixtures/setup.sql")
        async def test_function() -> None:
            pass

        with pytest.raises(ValueError) as exc_info:
            await test_function()
        assert "No database configuration provided" in str(exc_info.value)

    @pytest.mark.asyncio
    async def test_async_missing_file_raises_error(self) -> None:
        """Test that missing SQL file raises FileNotFoundError in async."""
        config = SqlTestConfig(
            driver="psycopg2",
            host="localhost",
            database="test",
            user="test",
            password="test",
        )

        @sql(path="nonexistent.sql", config=config)
        async def test_function() -> None:
            pass

        with pytest.raises(FileNotFoundError) as exc_info:
            await test_function()
        assert "nonexistent.sql" in str(exc_info.value)
