"""Tests for driver registry."""

import pytest

from fixturify.sql_d._driver_registry import (
    _get_driver_config,
    _is_async_driver,
)


class TestDriverRegistry:
    """Tests for driver registry functions."""

    def test_get_psycopg2_config(self) -> None:
        """Test getting psycopg2 driver config."""
        config = _get_driver_config("psycopg2")
        assert config.module_name == "psycopg2"
        assert config.is_async is False
        assert config.default_port == 5432
        assert config.param_mapping["database"] == "dbname"

    def test_get_asyncpg_config(self) -> None:
        """Test getting asyncpg driver config."""
        config = _get_driver_config("asyncpg")
        assert config.module_name == "asyncpg"
        assert config.is_async is True
        assert config.default_port == 5432
        assert config.param_mapping["database"] == "database"

    def test_get_mysql_connector_config(self) -> None:
        """Test getting mysql.connector driver config."""
        config = _get_driver_config("mysql.connector")
        assert config.module_name == "mysql.connector"
        assert config.is_async is False
        assert config.default_port == 3306
        assert config.param_mapping["database"] == "database"

    def test_get_aiomysql_config(self) -> None:
        """Test getting aiomysql driver config."""
        config = _get_driver_config("aiomysql")
        assert config.module_name == "aiomysql"
        assert config.is_async is True
        assert config.default_port == 3306
        assert config.param_mapping["database"] == "db"

    def test_unsupported_driver_raises_error(self) -> None:
        """Test that unsupported driver raises ValueError."""
        with pytest.raises(ValueError) as exc_info:
            _get_driver_config("unsupported_driver")
        assert "Unsupported driver" in str(exc_info.value)
        assert "unsupported_driver" in str(exc_info.value)

    def test_is_async_driver_sync(self) -> None:
        """Test is_async_driver returns False for sync drivers."""
        assert _is_async_driver("psycopg2") is False
        assert _is_async_driver("mysql.connector") is False
        assert _is_async_driver("sqlite3") is False

    def test_is_async_driver_async(self) -> None:
        """Test is_async_driver returns True for async drivers."""
        assert _is_async_driver("asyncpg") is True
        assert _is_async_driver("aiomysql") is True
        assert _is_async_driver("aiosqlite") is True
