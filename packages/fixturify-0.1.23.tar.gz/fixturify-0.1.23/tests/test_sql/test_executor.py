"""Integration tests for SQL executors.

These tests require Docker containers running:
- PostgreSQL: localhost:5432 (postgres/postgres, database: pytools)
- MySQL: localhost:3306 (root/empty password, database: pytools)

Run with: docker-compose up -d postgres mysql
"""

import pytest

from fixturify.sql_d import SqlTestConfig
from fixturify.sql_d._executor import SqlExecutor

# Test configurations
POSTGRES_SYNC_CONFIG = SqlTestConfig(
    driver="psycopg2",
    host="localhost",
    port=5432,
    database="fixturify",
    user="postgres",
    password="postgres",
)

POSTGRES_ASYNC_CONFIG = SqlTestConfig(
    driver="asyncpg",
    host="localhost",
    port=5432,
    database="fixturify",
    user="postgres",
    password="postgres",
)

MYSQL_SYNC_CONFIG = SqlTestConfig(
    driver="mysql.connector",
    host="localhost",
    port=3306,
    database="fixturify",
    user="root",
    password="",
)

MYSQL_ASYNC_CONFIG = SqlTestConfig(
    driver="aiomysql",
    host="localhost",
    port=3306,
    database="fixturify",
    user="root",
    password="",
)


# Helper functions must be defined before classes that use them in decorators
def _can_connect_postgres_sync() -> bool:
    """Check if PostgreSQL is available with psycopg2."""
    try:
        import psycopg2

        conn = psycopg2.connect(
            host="localhost",
            port=5432,
            dbname="fixturify",
            user="postgres",
            password="postgres",
        )
        conn.close()
        return True
    except Exception:
        return False


def _can_connect_postgres_async() -> bool:
    """Check if asyncpg is installed."""
    try:
        import asyncpg  # noqa: F401

        return _can_connect_postgres_sync()  # Reuse sync check for DB availability
    except ImportError:
        return False


def _can_connect_mysql_sync() -> bool:
    """Check if MySQL is available with mysql.connector."""
    try:
        import mysql.connector

        conn = mysql.connector.connect(
            host="localhost",
            port=3306,
            database="fixturify",
            user="root",
            password="",
        )
        conn.close()
        return True
    except Exception:
        return False


def _can_connect_mysql_async() -> bool:
    """Check if aiomysql is installed."""
    try:
        import aiomysql  # noqa: F401

        return _can_connect_mysql_sync()  # Reuse sync check for DB availability
    except ImportError:
        return False


class TestSyncSqlExecutor:
    """Tests for sync SQL executor."""

    @pytest.mark.skipif(
        not _can_connect_postgres_sync(),
        reason="PostgreSQL not available",
    )
    def test_postgres_execute(self) -> None:
        """Test executing SQL on PostgreSQL with psycopg2."""
        executor = SqlExecutor(POSTGRES_SYNC_CONFIG)
        sql = "SELECT 1 as test;"
        executor.execute(sql)  # Should not raise

    @pytest.mark.skipif(
        not _can_connect_mysql_sync(),
        reason="MySQL not available",
    )
    def test_mysql_execute(self) -> None:
        """Test executing SQL on MySQL with mysql.connector."""
        executor = SqlExecutor(MYSQL_SYNC_CONFIG)
        sql = "SELECT 1 as test;"
        executor.execute(sql)  # Should not raise


class TestAsyncSqlExecutor:
    """Tests for async SQL executor."""

    @pytest.mark.skipif(
        not _can_connect_postgres_async(),
        reason="PostgreSQL (asyncpg) not available",
    )
    @pytest.mark.asyncio
    async def test_postgres_execute(self) -> None:
        """Test executing SQL on PostgreSQL with asyncpg."""
        executor = SqlExecutor(POSTGRES_ASYNC_CONFIG)
        sql = "SELECT 1 as test;"
        await executor.execute_async(sql)  # Should not raise

    @pytest.mark.skipif(
        not _can_connect_mysql_async(),
        reason="MySQL (aiomysql) not available",
    )
    @pytest.mark.asyncio
    async def test_mysql_execute(self) -> None:
        """Test executing SQL on MySQL with aiomysql."""
        executor = SqlExecutor(MYSQL_ASYNC_CONFIG)
        sql = "SELECT 1 as test;"
        await executor.execute_async(sql)  # Should not raise
