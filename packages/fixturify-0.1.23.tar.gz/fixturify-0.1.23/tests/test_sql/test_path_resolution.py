"""Tests for path resolution in SQL decorator."""

from pathlib import Path

import pytest

from fixturify._utils import _PathResolver


class TestPathResolution:
    """Tests for SQL file path resolution."""

    def test_same_directory(self) -> None:
        """Test resolving file in same directory."""
        test_file = __file__
        # fixtures is a sibling directory
        resolved = _PathResolver.resolve("fixtures/setup.sql", reference_file=test_file)
        assert resolved.exists()
        assert resolved.name == "setup.sql"

    def test_child_directory(self) -> None:
        """Test resolving file in child directory."""
        test_file = __file__
        resolved = _PathResolver.resolve(
            "fixtures/nested/deep.sql", reference_file=test_file
        )
        assert resolved.exists()
        assert resolved.name == "deep.sql"

    def test_file_not_found(self) -> None:
        """Test that FileNotFoundError is raised for missing file."""
        test_file = __file__
        with pytest.raises(FileNotFoundError) as exc_info:
            _PathResolver.resolve("nonexistent.sql", reference_file=test_file)
        assert "nonexistent.sql" in str(exc_info.value)

    def test_resolve_without_check(self) -> None:
        """Test resolving path without existence check."""
        test_file = __file__
        resolved = _PathResolver.resolve_without_check(
            "nonexistent.sql", reference_file=test_file
        )
        # Should return a path even if file doesn't exist
        assert isinstance(resolved, Path)
        assert resolved.name == "nonexistent.sql"
