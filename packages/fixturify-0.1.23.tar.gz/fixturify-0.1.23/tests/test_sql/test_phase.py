"""Tests for Phase enum."""

from fixturify.sql_d import Phase


class TestPhase:
    """Tests for Phase enum."""

    def test_before_value(self) -> None:
        """Test BEFORE phase has correct value."""
        assert Phase.BEFORE.value == "before"

    def test_after_value(self) -> None:
        """Test AFTER phase has correct value."""
        assert Phase.AFTER.value == "after"

    def test_enum_members(self) -> None:
        """Test Phase has exactly two members."""
        assert len(Phase) == 2
        assert Phase.BEFORE in Phase
        assert Phase.AFTER in Phase
