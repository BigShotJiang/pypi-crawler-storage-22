"""Tests for shared utilities."""
