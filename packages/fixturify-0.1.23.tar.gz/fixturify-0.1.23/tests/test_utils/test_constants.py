"""Tests for shared constants."""

from fixturify._utils._constants import ENCODING, MAX_DEPTH


class TestConstants:
    """Tests for shared constants."""

    def test_encoding_is_utf8(self):
        """Test that ENCODING is set to utf-8."""
        assert ENCODING == "utf-8"

    def test_max_depth_is_reasonable(self):
        """Test that MAX_DEPTH is a reasonable value."""
        assert MAX_DEPTH == 100
        assert isinstance(MAX_DEPTH, int)
        assert MAX_DEPTH > 0
