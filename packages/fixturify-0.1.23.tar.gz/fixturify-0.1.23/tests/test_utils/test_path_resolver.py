"""Tests for _PathResolver utility."""

import pytest
from pathlib import Path


from fixturify._utils._path_resolver import _PathResolver, _SKIP_PATH_PATTERNS


class TestPathResolver:
    """Tests for _PathResolver class."""

    def test_resolve_existing_file(self, tmp_path: Path):
        """Test resolving a path to an existing file."""
        # Create a test file
        test_file = tmp_path / "data.json"
        test_file.write_text('{"test": true}')

        # Create a reference file
        ref_file = tmp_path / "tests" / "test_example.py"
        ref_file.parent.mkdir(parents=True, exist_ok=True)
        ref_file.write_text("# test file")

        # Resolve relative path from reference file
        resolved = _PathResolver.resolve("../data.json", str(ref_file))

        assert resolved == test_file.resolve()
        assert resolved.exists()

    def test_resolve_file_not_found(self, tmp_path: Path):
        """Test that FileNotFoundError is raised for non-existent files."""
        ref_file = tmp_path / "test.py"
        ref_file.write_text("# test")

        with pytest.raises(FileNotFoundError) as exc_info:
            _PathResolver.resolve("./nonexistent.json", str(ref_file))

        assert "nonexistent.json" in str(exc_info.value)

    def test_resolve_with_dot_prefix(self, tmp_path: Path):
        """Test resolving paths with ./ prefix."""
        test_file = tmp_path / "data.json"
        test_file.write_text("{}")

        ref_file = tmp_path / "test.py"
        ref_file.write_text("# test")

        resolved = _PathResolver.resolve("./data.json", str(ref_file))
        assert resolved == test_file.resolve()

    def test_resolve_nested_path(self, tmp_path: Path):
        """Test resolving nested relative paths."""
        # Create nested structure
        fixtures_dir = tmp_path / "fixtures" / "users"
        fixtures_dir.mkdir(parents=True)
        test_file = fixtures_dir / "user.json"
        test_file.write_text('{"name": "John"}')

        ref_file = tmp_path / "tests" / "api" / "test_users.py"
        ref_file.parent.mkdir(parents=True, exist_ok=True)
        ref_file.write_text("# test")

        resolved = _PathResolver.resolve(
            "../../fixtures/users/user.json", str(ref_file)
        )
        assert resolved == test_file.resolve()

    def test_resolve_without_check_nonexistent(self, tmp_path: Path):
        """Test resolve_without_check doesn't raise for non-existent files."""
        ref_file = tmp_path / "test.py"
        ref_file.write_text("# test")

        # Should not raise
        resolved = _PathResolver.resolve_without_check(
            "./nonexistent.json", str(ref_file)
        )

        assert not resolved.exists()
        assert resolved.name == "nonexistent.json"

    def test_resolve_normalizes_path(self, tmp_path: Path):
        """Test that paths are normalized (.. and . resolved)."""
        test_file = tmp_path / "data.json"
        test_file.write_text("{}")

        ref_file = tmp_path / "subdir" / "test.py"
        ref_file.parent.mkdir(parents=True, exist_ok=True)
        ref_file.write_text("# test")

        # Use a path with redundant components
        resolved = _PathResolver.resolve("./../subdir/../data.json", str(ref_file))
        assert resolved == test_file.resolve()

    def test_resolve_absolute_path_in_relative(self, tmp_path: Path):
        """Test behavior with paths that look absolute but are treated as relative."""
        ref_file = tmp_path / "test.py"
        ref_file.write_text("# test")

        # This should fail as it tries to resolve relative to ref_file
        with pytest.raises(FileNotFoundError):
            _PathResolver.resolve("/absolute/path/file.json", str(ref_file))


class TestPathResolverCallerDetection:
    """Tests for automatic caller file detection."""

    def test_get_caller_file(self):
        """Test that _get_caller_file returns a valid file path."""
        # The _get_caller_file function returns the file of the caller
        # When called from here, it should return a valid Python file
        caller_file = _PathResolver._get_caller_file(stack_level=1)

        # Should return a valid path to a Python file
        assert caller_file.endswith(".py")
        assert Path(caller_file).exists()

    def test_get_caller_file_from_wrapper(self):
        """Test caller detection through a wrapper function."""

        def wrapper():
            # stack_level=2 to get the caller of wrapper (this test method)
            return _PathResolver._get_caller_file(stack_level=2)

        caller_file = wrapper()
        # The caller of wrapper is pytest/this test - should be a .py file
        assert caller_file.endswith(".py")


class TestDebuggerFrameFiltering:
    """Tests for debugger and framework frame filtering."""

    def test_skip_patterns_contains_debugpy(self):
        """Test that VS Code debugger patterns are in skip list."""
        assert "debugpy" in _SKIP_PATH_PATTERNS
        assert "_debugpy" in _SKIP_PATH_PATTERNS

    def test_skip_patterns_contains_pydevd(self):
        """Test that PyCharm debugger patterns are in skip list."""
        assert "pydevd" in _SKIP_PATH_PATTERNS
        assert "_pydevd" in _SKIP_PATH_PATTERNS
        assert "_pydev_" in _SKIP_PATH_PATTERNS

    def test_skip_patterns_contains_site_packages(self):
        """Test that site-packages is in skip list."""
        assert "site-packages" in _SKIP_PATH_PATTERNS

    def test_skip_patterns_contains_importlib(self):
        """Test that importlib is in skip list."""
        assert "importlib" in _SKIP_PATH_PATTERNS

    def test_debugpy_path_would_be_skipped(self):
        """Test that paths containing debugpy would match skip patterns."""
        test_paths = [
            "/usr/lib/python3.10/debugpy/_vendored/pydevd/pydevd.py",
            "C:\\Python310\\Lib\\site-packages\\debugpy\\adapter\\main.py",
            "/home/user/.vscode/extensions/debugpy/launcher.py",
        ]
        for path in test_paths:
            assert any(pattern in path for pattern in _SKIP_PATH_PATTERNS), (
                f"Path should be skipped: {path}"
            )

    def test_pydevd_path_would_be_skipped(self):
        """Test that paths containing pydevd would match skip patterns."""
        test_paths = [
            "/opt/pycharm/plugins/python/helpers/pydev/pydevd.py",
            "C:\\Program Files\\JetBrains\\PyCharm\\plugins\\python\\helpers\\_pydevd_bundle\\pydevd_cython.pyx",
            "/home/user/.local/lib/python3.10/_pydev_imps/_pydev_execfile.py",
        ]
        for path in test_paths:
            assert any(pattern in path for pattern in _SKIP_PATH_PATTERNS), (
                f"Path should be skipped: {path}"
            )

    def test_regular_test_file_not_skipped(self):
        """Test that regular test files would NOT match skip patterns."""
        test_paths = [
            "/home/user/project/tests/test_something.py",
            "C:\\Projects\\myapp\\tests\\test_api.py",
            "/Users/dev/code/tests/integration/test_users.py",
        ]
        for path in test_paths:
            assert not any(pattern in path for pattern in _SKIP_PATH_PATTERNS), (
                f"Regular test file should NOT be skipped: {path}"
            )

    def test_caller_file_returns_test_file_not_pytools(self):
        """Test that _get_caller_file returns this test file, not pytools internals."""
        caller_file = _PathResolver._get_caller_file(stack_level=1)

        # Should return this test file
        assert "test_path_resolver.py" in caller_file

        # Should NOT be a pytools internal file
        assert "pytools/_utils" not in caller_file
        assert "pytools\\\\utils" not in caller_file
