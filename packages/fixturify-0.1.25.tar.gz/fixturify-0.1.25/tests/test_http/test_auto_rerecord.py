"""Tests for update (update mode) feature."""

import json
import pytest

from fixturify.http_d import HttpTestConfig, http
from fixturify.http_d._mock_context import HttpMockContext
from fixturify.http_d._models import HttpRequest, HttpResponse


API_BASE = "https://api.restful-api.dev"

# Check if requests is available
try:
    import requests

    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False


def _create_fixture(path, mappings):
    """Helper to create a fixture file with given mappings."""
    data = {"mappings": mappings}
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(data, f, indent=2)


def _read_fixture(path):
    """Helper to read a fixture file."""
    with open(path, "r") as f:
        return json.load(f)


class TestAutoRerecordConfig:
    """Tests for update config field."""

    def test_default_is_false(self):
        config = HttpTestConfig()
        assert config.update is False

    def test_can_set_true(self):
        config = HttpTestConfig(update=True)
        assert config.update is True

    def test_merge_override(self):
        config = HttpTestConfig(update=False)
        merged = config.merge({"update": True})
        assert merged.update is True

    def test_is_valid_field(self):
        assert "update" in HttpTestConfig._VALID_FIELDS

    def test_is_bool_field(self):
        assert "update" in HttpTestConfig._BOOL_FIELDS


class TestUpdateMode:
    """Tests for update mode (update=True with existing fixture)."""

    def test_mode_is_update_when_file_exists_and_update(self, tmp_path):
        """When fixture exists and update=True, mode should be 'update'."""
        fixture = tmp_path / "test.json"
        _create_fixture(fixture, [])
        config = HttpTestConfig(update=True)

        ctx = HttpMockContext(fixture, config)
        assert ctx.mode == "update"

    def test_mode_is_record_when_file_missing_even_with_update(self, tmp_path):
        """When fixture doesn't exist, mode is 'record' regardless of update."""
        fixture = tmp_path / "test.json"
        config = HttpTestConfig(update=True)

        ctx = HttpMockContext(fixture, config)
        assert ctx.mode == "record"

    def test_mode_is_playback_when_file_exists_without_update(self, tmp_path):
        """Normal playback when update is False."""
        fixture = tmp_path / "test.json"
        _create_fixture(fixture, [])
        config = HttpTestConfig(update=False)

        ctx = HttpMockContext(fixture, config)
        assert ctx.mode == "playback"

    def test_update_has_both_player_and_recorder(self, tmp_path):
        """Update mode initializes both player and recorder."""
        fixture = tmp_path / "test.json"
        _create_fixture(fixture, [])
        config = HttpTestConfig(update=True)

        ctx = HttpMockContext(fixture, config)
        assert ctx._player is not None
        assert ctx._recorder is not None

    def test_can_play_existing_recording(self, tmp_path):
        """In update mode, existing recordings can be played back."""
        fixture = tmp_path / "test.json"
        _create_fixture(fixture, [
            {
                "request": {
                    "method": "GET",
                    "url": "https://example.com/api/1",
                    "headers": {},
                    "queryParameters": {},
                },
                "response": {
                    "status": 200,
                    "headers": {"Content-Type": "application/json"},
                    "body": {"id": 1, "name": "Existing"},
                },
            }
        ])
        config = HttpTestConfig(update=True)
        ctx = HttpMockContext(fixture, config)

        request = HttpRequest(
            method="GET",
            url="https://example.com/api/1",
        )

        assert ctx.can_play_response_for(request) is True
        response = ctx.play_response(request)
        assert response.status == 200
        assert "Existing" in response.body

    def test_can_record_new_interaction(self, tmp_path):
        """In update mode, new interactions can be recorded."""
        fixture = tmp_path / "test.json"
        _create_fixture(fixture, [
            {
                "request": {
                    "method": "GET",
                    "url": "https://example.com/api/1",
                    "headers": {},
                    "queryParameters": {},
                },
                "response": {
                    "status": 200,
                    "headers": {},
                    "body": "existing",
                },
            }
        ])
        config = HttpTestConfig(update=True)
        ctx = HttpMockContext(fixture, config)

        # New request that doesn't match existing recording
        new_request = HttpRequest(
            method="GET",
            url="https://example.com/api/2",
        )
        assert ctx.can_play_response_for(new_request) is False

        # Record it
        new_response = HttpResponse(
            status= 201,
            headers={"Content-Type": "application/json"},
            body='{"id": 2, "name": "New"}',
        )
        ctx.record(new_request, new_response)

    def test_save_update_appends_new_recordings(self, tmp_path):
        """On exit, update mode appends new recordings to existing fixture."""
        fixture = tmp_path / "test.json"
        original_mapping = {
            "request": {
                "method": "GET",
                "url": "https://example.com/api/1",
                "headers": {},
                "queryParameters": {},
            },
            "response": {
                "status": 200,
                "headers": {},
                "body": "existing",
            },
        }
        _create_fixture(fixture, [original_mapping])
        config = HttpTestConfig(update=True)
        ctx = HttpMockContext(fixture, config)

        # Record a new interaction
        ctx.record(
            HttpRequest(method="POST", url="https://example.com/api/2",
                       headers={"Content-Type": "application/json"},
                       body='{"name": "New"}'),
            HttpResponse(status=201, headers={"Content-Type": "application/json"},
                        body='{"id": 2}'),
        )

        # Simulate __exit__ saving
        ctx._save_update()

        # Verify fixture file has both original and new
        data = _read_fixture(fixture)
        assert len(data["mappings"]) == 2
        assert data["mappings"][0]["request"]["url"] == "https://example.com/api/1"
        assert data["mappings"][1]["request"]["url"] == "https://example.com/api/2"
        assert data["mappings"][1]["request"]["method"] == "POST"

    def test_save_update_preserves_original_when_no_new_recordings(self, tmp_path):
        """When no new recordings, file is preserved as-is."""
        fixture = tmp_path / "test.json"
        original_mapping = {
            "request": {
                "method": "GET",
                "url": "https://example.com/api/1",
                "headers": {},
                "queryParameters": {},
            },
            "response": {
                "status": 200,
                "headers": {},
                "body": "existing",
            },
        }
        _create_fixture(fixture, [original_mapping])
        config = HttpTestConfig(update=True)
        ctx = HttpMockContext(fixture, config)

        # Play existing recording (no new ones)
        ctx.play_response(HttpRequest(method="GET", url="https://example.com/api/1"))

        # Save
        ctx._save_update()

        # Verify file unchanged
        data = _read_fixture(fixture)
        assert len(data["mappings"]) == 1
        assert data["mappings"][0]["request"]["url"] == "https://example.com/api/1"

    def test_update_mode_no_unused_recordings_error(self, tmp_path):
        """Update mode should NOT raise UnusedRecordingsError."""
        fixture = tmp_path / "test.json"
        _create_fixture(fixture, [
            {
                "request": {
                    "method": "GET",
                    "url": "https://example.com/api/1",
                    "headers": {},
                    "queryParameters": {},
                },
                "response": {
                    "status": 200,
                    "headers": {},
                    "body": "existing",
                },
            },
            {
                "request": {
                    "method": "GET",
                    "url": "https://example.com/api/2",
                    "headers": {},
                    "queryParameters": {},
                },
                "response": {
                    "status": 200,
                    "headers": {},
                    "body": "also existing",
                },
            },
        ])
        config = HttpTestConfig(update=True)
        ctx = HttpMockContext(fixture, config)

        # Use only one recording, leave the other unused
        ctx.__enter__()
        ctx.play_response(HttpRequest(method="GET", url="https://example.com/api/1"))

        # Should NOT raise UnusedRecordingsError
        ctx.__exit__(None, None, None)


class TestAutoRerecordDecorator:
    """Tests for update via decorator kwargs."""

    @pytest.mark.skipif(not HAS_REQUESTS, reason="requests not installed")
    def test_decorator_with_update_kwarg(self, tmp_path):
        """Test that update can be passed as decorator kwarg."""
        fixture = tmp_path / "decorator_test.json"
        _create_fixture(fixture, [
            {
                "request": {
                    "method": "GET",
                    "url": f"{API_BASE}/objects/1",
                    "headers": {},
                    "queryParameters": {},
                },
                "response": {
                    "status": 200,
                    "headers": {"Content-Type": "application/json"},
                    "body": {"id": "1", "name": "Test Object"},
                },
            }
        ])

        @http(path=str(fixture), update=True)
        def test_func():
            # Matching request — should return from playback
            response = requests.get(f"{API_BASE}/objects/1")
            assert response.status_code == 200
            data = response.json()
            assert data["name"] == "Test Object"

        test_func()

    @pytest.mark.skipif(not HAS_REQUESTS, reason="requests not installed")
    def test_decorator_with_config_update(self, tmp_path):
        """Test that update works via config object."""
        fixture = tmp_path / "config_test.json"
        _create_fixture(fixture, [
            {
                "request": {
                    "method": "GET",
                    "url": f"{API_BASE}/objects/1",
                    "headers": {},
                    "queryParameters": {},
                },
                "response": {
                    "status": 200,
                    "headers": {"Content-Type": "application/json"},
                    "body": {"id": "1", "name": "Config Test"},
                },
            }
        ])

        config = HttpTestConfig(update=True)

        @http(path=str(fixture), config=config)
        def test_func():
            response = requests.get(f"{API_BASE}/objects/1")
            assert response.status_code == 200

        test_func()
