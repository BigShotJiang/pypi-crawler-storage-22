"""HTTP mock context for recording and playback."""

import json
from contextlib import ExitStack
from pathlib import Path
from typing import TYPE_CHECKING, List, Optional, Union

from fixturify._utils import ENCODING

from ._player import HttpPlayer
from ._recorder import HttpRecorder

if TYPE_CHECKING:
    from ._config import HttpTestConfig
    from ._models import HttpMapping, HttpRequest, HttpResponse


class HttpMockContext:
    """
    Manages HTTP recording/playback for a single test.

    This is the main entry point for HTTP mocking. It handles:
    - Determining record vs playback vs update mode
    - Installing/uninstalling patches on HTTP clients
    - Recording request/response pairs
    - Playing back recorded responses
    - Verifying all recordings were used

    Modes:
        record: No fixture file exists. All HTTP calls go through and are recorded.
        playback: Fixture file exists. All HTTP calls are matched against recordings.
        update: Fixture file exists + update=True. Matching requests return
                recorded responses; non-matching requests make real calls.
                Mismatched stubs are replaced, unused stubs are removed.

    Usage:
        with HttpMockContext(path, config):
            # HTTP calls are intercepted here
            response = requests.get("https://api.example.com")
    """

    def __init__(self, path: Path, config: "HttpTestConfig"):
        """
        Initialize the mock context.

        Args:
            path: Path to the fixture file for recording/playback
            config: Configuration for HTTP mocking behavior
        """
        self.path = path
        self.config = config
        self._intercepted_error: Optional[Exception] = None

        # Determine mode
        if not path.exists():
            self.mode = "record"
        elif config.update:
            self.mode = "update"
        else:
            self.mode = "playback"

        # Initialize recorder and/or player based on mode
        if self.mode == "record":
            self._recorder: Optional[HttpRecorder] = HttpRecorder(
                path,
                exclude_request_headers=config.get_exclude_request_headers_set(),
                exclude_response_headers=config.get_exclude_response_headers_set(),
                redact_request_body=config.redact_request_body,
                redact_response_body=config.redact_response_body,
            )
            self._player: Optional[HttpPlayer] = None
        elif self.mode == "update":
            # Both player (for existing recordings) and recorder (for new ones)
            self._player = HttpPlayer(path, config=config)
            self._recorder = HttpRecorder(
                path,
                exclude_request_headers=config.get_exclude_request_headers_set(),
                exclude_response_headers=config.get_exclude_response_headers_set(),
                redact_request_body=config.redact_request_body,
                redact_response_body=config.redact_response_body,
            )
        else:
            self._recorder = None
            self._player = HttpPlayer(path, config=config)

        # Update mode: track interaction order for correct save
        # Each entry is either an int (index into player.mappings = played back)
        # or an HttpMapping (newly recorded)
        self._update_sequence: List[Union[int, "HttpMapping"]] = []

        # Patch management
        self._exit_stack: Optional[ExitStack] = None

    def __enter__(self) -> "HttpMockContext":
        """Start HTTP interception by installing patches."""
        from ._patcher import PatcherBuilder

        self._exit_stack = ExitStack()

        # Build and start all patches
        patcher = PatcherBuilder(self)
        for patch in patcher.build():
            self._exit_stack.enter_context(patch)

        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Stop HTTP interception and finalize recording/playback."""
        # Stop all patches
        if self._exit_stack:
            self._exit_stack.close()
            self._exit_stack = None

        # Re-raise intercepted error — it's the root cause and takes priority
        # over any subsequent exceptions (e.g. AssertionError from assertions
        # that failed because the HTTP mock returned garbage after being caught).
        # Chain with exc_val so the original test exception is not lost.
        if self._intercepted_error is not None:
            raise self._intercepted_error from exc_val

        # Handle recording/playback finalization
        # Only save/verify if no exception occurred (don't mask original error)
        if self.mode == "record" and self._recorder is not None:
            if exc_type is None:
                self._recorder.save()
        elif self.mode == "update":
            if exc_type is None:
                self._save_update()
        elif self.mode == "playback" and self._player and exc_type is None:
            self._player.verify_all_used()

        return False  # Don't suppress exceptions

    def _save_update(self) -> None:
        """
        Save updated fixture file based on what actually happened during the test.

        - Played-back stubs are kept (from original JSON, preserving exact data)
        - New/replacement recordings are serialized via the recorder
        - Unused original stubs are dropped
        - Order follows the actual test execution sequence
        """
        # Load original data to preserve exact JSON for played-back entries
        with open(self.path, "r", encoding=ENCODING) as f:
            data = json.load(f)
        original_mappings = data.get("mappings", [])

        # Serialize new recordings
        new_serialized: list = []
        if self._recorder and len(self._recorder) > 0:
            new_data = self._recorder._to_dict_with_json_bodies()
            new_serialized = new_data["mappings"]

            # Save binary files from new recordings
            if self._recorder._binary_files:
                files_dir = self.path.parent / HttpRecorder.FILES_DIR
                files_dir.mkdir(exist_ok=True)
                for filename, content in self._recorder._binary_files:
                    with open(files_dir / filename, "wb") as f:
                        f.write(content)

        # Build final mappings list from the interaction sequence
        result_mappings = []
        new_idx = 0
        for entry in self._update_sequence:
            if isinstance(entry, int):
                # Played-back original — keep exact JSON from file
                if entry < len(original_mappings):
                    result_mappings.append(original_mappings[entry])
            else:
                # Newly recorded — take from serialized recorder output
                if new_idx < len(new_serialized):
                    result_mappings.append(new_serialized[new_idx])
                    new_idx += 1

        data["mappings"] = result_mappings

        # Write updated file
        with open(self.path, "w", encoding=ENCODING) as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

    def can_play_response_for(self, request: "HttpRequest") -> bool:
        """
        Check if a recorded response exists for the given request.

        Args:
            request: The HTTP request to check

        Returns:
            True if a matching response exists in the player
        """
        if self._player is None:
            return False

        # Try to find a match without consuming it
        try:
            result = self._player.matcher.find_match(
                request,
                self._player.mappings,
                self._player.used_indices
            )
            return result is not None
        except Exception as e:
            self._intercepted_error = e
            return False

    def play_response(self, request: "HttpRequest") -> "HttpResponse":
        """
        Get the recorded response for a request.

        Args:
            request: The HTTP request to match

        Returns:
            The matching recorded response

        Raises:
            NoMatchingRecordingError: If no matching recording found
        """
        if self._player is None:
            from ._exceptions import NoMatchingRecordingError
            error = NoMatchingRecordingError(request=request, available_mappings=[])
            self._intercepted_error = error
            raise error

        # Capture used indices before the call to detect which index was just used
        before = self._player.used_indices.copy() if self.mode == "update" else None

        try:
            response = self._player.find_response(request)
        except Exception as e:
            self._intercepted_error = e
            raise

        # Track played-back index for update mode save
        if before is not None:
            new_indices = self._player.used_indices - before
            if new_indices:
                self._update_sequence.append(new_indices.pop())

        return response

    def record(self, request: "HttpRequest", response: "HttpResponse") -> None:
        """
        Record a request/response pair.

        Args:
            request: The HTTP request
            response: The HTTP response
        """
        if self._recorder is not None:
            try:
                self._recorder.record(request, response)
            except Exception as e:
                self._intercepted_error = e
                raise

        # Track new recording for update mode save
        if self.mode == "update":
            from ._models import HttpMapping
            self._update_sequence.append(HttpMapping(request=request, response=response))

    def is_host_excluded(self, url: str) -> bool:
        """
        Check if a URL's host is excluded from mocking.

        Args:
            url: The URL to check

        Returns:
            True if the host should not be mocked
        """
        try:
            return self.config.is_host_excluded(url)
        except Exception as e:
            self._intercepted_error = e
            raise
