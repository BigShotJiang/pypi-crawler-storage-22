"""JsonAssert module for JSON comparison assertions in testing."""

# Check for deepdiff dependency at import time
try:
    import deepdiff  # noqa: F401
except ImportError:
    raise ImportError(
        "JsonAssert requires 'deepdiff'. Install it with: pip install fixturify[json-assert]"
    )

from fixturify.json_assert._assert import JsonAssert

__all__ = ["JsonAssert"]
