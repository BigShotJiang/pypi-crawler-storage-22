"""Base deserializer class for all deserializers."""

import re
import sys
from abc import ABC, abstractmethod
from datetime import datetime, date, time, timedelta
from decimal import Decimal
from enum import Enum
from fractions import Fraction
from ipaddress import (
    IPv4Address,
    IPv4Network,
    IPv6Address,
    IPv6Network,
)
from pathlib import PurePath
from typing import Any, Dict, Tuple, Type, TypeVar, Union, cast, get_type_hints
from uuid import UUID

T = TypeVar("T")


class _BaseDeserializer(ABC):
    """Abstract base class for all deserializers."""

    @abstractmethod
    def deserialize(self, data: dict, target_class: Type[T]) -> T:
        """
        Convert a dictionary to an object of target_class.

        Args:
            data: Dictionary data to deserialize
            target_class: The class to create an instance of

        Returns:
            Instance of target_class
        """
        pass

    def _get_type_hints(self, cls: Type) -> Dict[str, Any]:
        """
        Get type hints for a class, resolving forward references.

        Args:
            cls: The class to get type hints for

        Returns:
            Dictionary of field names to their types
        """
        try:
            # Try to get type hints with the class's module globals
            module = sys.modules.get(cls.__module__, None)
            globalns = getattr(module, "__dict__", {}) if module else {}
            return get_type_hints(cls, globalns=globalns, localns=None)
        except Exception:
            # Fallback to __annotations__ if get_type_hints fails
            return getattr(cls, "__annotations__", {})

    def _convert_value(self, value: Any, target_type: Type) -> Any:
        """
        Convert a value to the target type.

        Args:
            value: The value to convert
            target_type: The target type

        Returns:
            Converted value
        """
        # Handle None
        if value is None:
            return None

        # Handle Any type
        if target_type is Any:
            return value

        # Get the origin type for generic types
        origin = getattr(target_type, "__origin__", None)
        args = getattr(target_type, "__args__", ())

        # Unwrap SQLAlchemy Mapped[T] → T
        if origin is not None and getattr(origin, "__name__", None) == "Mapped" and args:
            return self._convert_value(value, args[0])

        # Handle Optional (Union with None)
        if origin is Union:
            # Filter out NoneType from args
            non_none_args = [arg for arg in args if arg is not type(None)]
            if len(non_none_args) == 1:
                # This is Optional[T]
                return self._convert_value(value, non_none_args[0])
            # For Union with multiple types, try each one
            for arg in non_none_args:
                try:
                    return self._convert_value(value, arg)
                except (ValueError, TypeError):
                    continue
            return value

        # Handle List
        if origin is list or target_type is list:
            if not isinstance(value, list):
                return value
            item_type = args[0] if args else Any
            return [self._convert_value(item, item_type) for item in value]

        # Handle Set
        if origin is set or target_type is set:
            if not isinstance(value, (list, set)):
                return value
            item_type = args[0] if args else Any
            return {self._convert_value(item, item_type) for item in value}

        # Handle Tuple
        if origin is tuple or target_type is tuple:
            if not isinstance(value, (list, tuple)):
                return value
            if args:
                # Handle Tuple[T, ...] (variable-length homogeneous tuple)
                # In this case, args = (T, Ellipsis)
                if len(args) >= 2 and args[-1] is ...:
                    item_type = args[0]
                    return tuple(self._convert_value(item, item_type) for item in value)
                # Handle Tuple[T1, T2, ...] (fixed-length heterogeneous tuple)
                return tuple(
                    self._convert_value(item, args[i] if i < len(args) else args[-1])
                    for i, item in enumerate(value)
                )
            return tuple(value)

        # Handle Dict
        if origin is dict or target_type is dict:
            if not isinstance(value, dict):
                return value
            if len(args) >= 2:
                args_tuple = cast(Tuple[Any, Any], args)
                key_type, val_type = args_tuple[0], args_tuple[1]
                return {
                    self._convert_value(k, key_type): self._convert_value(v, val_type)
                    for k, v in value.items()
                }
            return value

        # Handle datetime
        if target_type is datetime:
            if isinstance(value, str):
                return datetime.fromisoformat(value)
            return value

        # Handle date
        if target_type is date:
            if isinstance(value, str):
                return date.fromisoformat(value)
            return value

        # Handle time
        if target_type is time:
            if isinstance(value, str):
                return time.fromisoformat(value)
            return value

        # Handle UUID
        if target_type is UUID:
            if isinstance(value, str):
                return UUID(value)
            return value

        # Handle Decimal
        if target_type is Decimal:
            return Decimal(str(value))

        # Handle complex
        if target_type is complex:
            if isinstance(value, dict) and "real" in value and "imag" in value:
                return complex(value["real"], value["imag"])
            if isinstance(value, (int, float)):
                return complex(value)
            return value

        # Handle Fraction
        if target_type is Fraction:
            if isinstance(value, dict) and "numerator" in value and "denominator" in value:
                return Fraction(value["numerator"], value["denominator"])
            if isinstance(value, (int, float, str)):
                return Fraction(value)
            return value

        # Handle timedelta
        if target_type is timedelta:
            if isinstance(value, (int, float)):
                return timedelta(seconds=value)
            return value

        # Handle pathlib types
        if isinstance(target_type, type) and issubclass(target_type, PurePath):
            if isinstance(value, str):
                return target_type(value)
            return value

        # Handle IP addresses and networks
        if target_type in (IPv4Address, IPv6Address, IPv4Network, IPv6Network):
            if isinstance(value, str):
                return target_type(value)
            return value

        # Handle bytes
        if target_type is bytes:
            if isinstance(value, str):
                return value.encode("utf-8")
            return value

        # Handle bytearray
        if target_type is bytearray:
            if isinstance(value, str):
                return bytearray(value.encode("utf-8"))
            return value

        # Handle re.Pattern
        if target_type is re.Pattern:
            if isinstance(value, str):
                return re.compile(value)
            return value

        # Handle Enum
        if isinstance(target_type, type) and issubclass(target_type, Enum):
            return target_type(value)

        # Handle primitives
        if target_type in (str, int, float, bool):
            if isinstance(value, target_type):
                return value
            try:
                return target_type(value)
            except (ValueError, TypeError):
                return value

        # Handle nested objects (dict to object)
        if isinstance(value, dict) and isinstance(target_type, type):
            return self._deserialize_nested(value, target_type)

        return value

    def _deserialize_nested(self, data: dict, target_class: Type[T]) -> T:
        """
        Deserialize a nested object. Override in subclasses for specific handling.

        Args:
            data: Dictionary data
            target_class: The target class

        Returns:
            Instance of target_class
        """
        # This will be overridden by subclasses
        # Default: try to instantiate with **data
        return target_class(**data)
