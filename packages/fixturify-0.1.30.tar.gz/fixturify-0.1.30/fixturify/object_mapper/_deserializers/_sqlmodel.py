"""SQLModel model deserializer."""

from typing import Type, TypeVar

from fixturify.object_mapper._deserializers._base import _BaseDeserializer

T = TypeVar("T")


class _SQLModelDeserializer(_BaseDeserializer):
    """Deserializer for SQLModel models."""

    def deserialize(self, data: dict, target_class: Type[T]) -> T:
        """
        Deserialize a dictionary to a SQLModel model.

        SQLModel combines Pydantic v2 and SQLAlchemy. For non-table models,
        Pydantic's model_validate handles everything including nested objects.
        For table models, Relationship fields are not in model_fields, so we
        must handle them separately via the SQLAlchemy mapper.

        Args:
            data: Dictionary data to deserialize
            target_class: The SQLModel model class

        Returns:
            Instance of target_class
        """
        if not hasattr(target_class, "model_validate"):
            return target_class(**data)

        mapper = getattr(target_class, "__mapper__", None)
        if mapper is None:
            # Non-table SQLModel — Pydantic handles nested objects
            return target_class.model_validate(data)  # type: ignore[attr-defined, no-any-return]

        # Table model: separate column data from relationship data
        rel_keys = {r.key for r in mapper.relationships}
        column_data = {k: v for k, v in data.items() if k not in rel_keys}

        instance = target_class.model_validate(column_data)  # type: ignore[attr-defined]

        # Deserialize relationships
        for relationship in mapper.relationships:
            rel_name = relationship.key
            if rel_name in data:
                rel_data = data[rel_name]
                rel_class = relationship.mapper.class_

                if isinstance(rel_data, list):
                    rel_instances = [
                        self._deserialize_nested(item, rel_class)
                        for item in rel_data
                    ]
                    setattr(instance, rel_name, rel_instances)
                elif isinstance(rel_data, dict):
                    rel_instance = self._deserialize_nested(rel_data, rel_class)
                    setattr(instance, rel_name, rel_instance)

        return instance  # type: ignore[no-any-return]

    def _deserialize_nested(self, data: dict, target_class: Type[T]) -> T:
        """Deserialize a nested SQLModel model."""
        # Check if it's a SQLModel model
        if hasattr(target_class, "__tablename__") and hasattr(
            target_class, "model_fields"
        ):
            return self.deserialize(data, target_class)

        # For non-SQLModel nested objects, try basic instantiation
        return target_class(**data)
