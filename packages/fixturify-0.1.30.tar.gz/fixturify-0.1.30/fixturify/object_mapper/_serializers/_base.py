"""Base serializer class for all serializers."""

from abc import ABC, abstractmethod
from datetime import datetime, date, time, timedelta
from decimal import Decimal
from enum import Enum
from fractions import Fraction
from ipaddress import (
    IPv4Address,
    IPv4Network,
    IPv6Address,
    IPv6Network,
)
from pathlib import PurePath
from typing import Any, Dict, TYPE_CHECKING
from uuid import UUID

from fixturify._utils._constants import MAX_DEPTH

if TYPE_CHECKING:
    pass


class _BaseSerializer(ABC):
    """Abstract base class for all serializers."""

    # Reference path delimiter for $ref
    REF_DELIMITER = "/"

    # Class-level serializer registry (set by ObjectMapper)
    _serializer_registry: Dict[Any, type] = {}

    def __init__(self):
        """Initialize the serializer with tracking state."""
        self._visited: Dict[int, str] = {}  # id -> json path
        self._current_depth: int = 0
        self._max_depth: int = MAX_DEPTH

    def reset(self):
        """Reset the serializer state for a new serialization."""
        self._visited.clear()
        self._current_depth = 0

    @classmethod
    def set_serializer_registry(cls, registry: Dict[Any, type]) -> None:
        """Set the serializer registry for nested object routing."""
        cls._serializer_registry = registry

    @abstractmethod
    def serialize(self, obj: Any) -> dict:
        """
        Convert an object to a dictionary.

        Args:
            obj: The object to serialize

        Returns:
            Dictionary representation of the object
        """
        pass

    def _serialize_with_path(self, obj: Any, path: str = "#") -> Any:
        """
        Serialize an object while tracking the JSON path for circular reference detection.

        Args:
            obj: The object to serialize
            path: Current JSON path (default: root "#")

        Returns:
            Serialized value (could be dict, list, primitive, or $ref)
        """
        return self._serialize_value(obj, path)

    def _serialize_value(self, value: Any, path: str) -> Any:
        """
        Serialize a single value, handling nested objects and collections.

        Args:
            value: The value to serialize
            path: Current JSON path

        Returns:
            Serialized value
        """
        # Handle None
        if value is None:
            return None

        # Handle primitives (no depth tracking needed)
        if isinstance(value, (str, int, float, bool)):
            return value

        # Handle numeric types → JSON number
        if isinstance(value, Decimal):
            # Use int if no fractional part, else float
            if value == value.to_integral_value():
                return int(value)
            return float(value)

        if isinstance(value, complex):
            return {"real": value.real, "imag": value.imag}

        if isinstance(value, Fraction):
            return {"numerator": value.numerator, "denominator": value.denominator}

        # Handle special types (no depth tracking needed)
        # datetime must be checked before date (datetime is subclass of date)
        if isinstance(value, datetime):
            return value.isoformat()

        if isinstance(value, date):
            return value.isoformat()

        if isinstance(value, time):
            return value.isoformat()

        if isinstance(value, timedelta):
            return value.total_seconds()

        if isinstance(value, UUID):
            return str(value)

        if isinstance(value, Enum):
            return value.value

        # Handle pathlib
        if isinstance(value, PurePath):
            return str(value)

        # Handle IP addresses and networks
        if isinstance(value, (IPv4Address, IPv6Address, IPv4Network, IPv6Network)):
            return str(value)

        # Handle bytes / bytearray / memoryview
        if isinstance(value, (bytes, bytearray)):
            return value.decode("utf-8", errors="replace")

        if isinstance(value, memoryview):
            return value.tobytes().decode("utf-8", errors="replace")

        # Handle re.Pattern
        if hasattr(value, "pattern") and hasattr(value, "flags") and hasattr(value, "match"):
            return value.pattern

        # Increment depth only for complex types (dict, list, objects)
        self._current_depth += 1

        if self._current_depth > self._max_depth:
            self._current_depth -= 1
            raise ValueError(
                f"Maximum serialization depth ({self._max_depth}) exceeded at path: {path}"
            )

        try:
            # Handle dict
            if isinstance(value, dict):
                return self._serialize_dict(value, path)

            # Handle collections (list, tuple, set, frozenset)
            if isinstance(value, (list, tuple, set, frozenset)):
                return self._serialize_collection(value, path)

            # Handle complex objects - check for circular reference
            obj_id = id(value)
            if obj_id in self._visited:
                # Return a JSON reference
                return {"$ref": self._visited[obj_id]}

            # Mark as visited with current path
            self._visited[obj_id] = path

            # Route to appropriate serializer based on object type
            return self._serialize_nested_object(value, path)
        finally:
            self._current_depth -= 1

    def _serialize_nested_object(self, value: Any, path: str) -> dict[Any, Any]:
        """
        Serialize a nested object using the appropriate type-specific serializer.

        This method detects the nested object's type and routes to the correct
        serializer, ensuring mixed-type object graphs are serialized correctly.

        Args:
            value: The nested object to serialize
            path: Current JSON path

        Returns:
            Dictionary representation of the nested object
        """
        # Import here to avoid circular imports
        from .._detectors import _TypeDetector

        # Detect the nested object's type
        obj_type = _TypeDetector.detect(value)

        # If we have a registry and this type has a specific serializer, use it
        if self._serializer_registry and obj_type in self._serializer_registry:
            serializer_class = self._serializer_registry[obj_type]
            # Create a new serializer but share state for circular reference detection
            nested_serializer = serializer_class()
            nested_serializer._visited = self._visited
            nested_serializer._current_depth = self._current_depth
            nested_serializer._max_depth = self._max_depth
            result: dict[Any, Any] = nested_serializer._serialize_object(value, path)
            return result

        # Fallback to current serializer's _serialize_object
        return self._serialize_object(value, path)

    def _serialize_dict(self, d: dict, path: str) -> dict:
        """Serialize a dictionary."""
        result = {}
        for key, value in d.items():
            item_path = f"{path}/{key}"
            result[key] = self._serialize_value(value, item_path)
        return result

    def _serialize_collection(self, collection: Any, path: str) -> list:
        """Serialize a collection (list, tuple, set, frozenset).

        For sets and frozensets, the output is sorted by serialized representation
        to ensure deterministic output for stable tests and diffs.
        """
        result = []
        for i, item in enumerate(collection):
            item_path = f"{path}/{i}"
            result.append(self._serialize_value(item, item_path))

        # Sort sets and frozensets for deterministic output
        if isinstance(collection, (set, frozenset)):
            try:
                # Try to sort by the serialized values
                # For primitives, this sorts them directly
                # For complex objects, this sorts by their string representation
                result = sorted(result, key=lambda x: (type(x).__name__, str(x)))
            except TypeError:
                # If items are not comparable at all, leave unsorted
                pass

        return result

    def _serialize_object(self, obj: Any, path: str) -> dict:
        """
        Serialize a complex object. Override in subclasses for specific handling.

        Args:
            obj: The object to serialize
            path: Current JSON path

        Returns:
            Dictionary representation
        """
        # Default implementation - get object attributes
        result = {}
        for attr_name in self._get_serializable_attributes(obj):
            value = getattr(obj, attr_name, None)
            item_path = f"{path}/{attr_name}"
            result[attr_name] = self._serialize_value(value, item_path)
        return result

    def _get_serializable_attributes(self, obj: Any) -> list:
        """
        Get list of attribute names that should be serialized.

        Rules:
        - Single underscore prefix (_attr): ARE serialized
        - Double underscore dunder (__attr__): ARE NOT serialized

        Args:
            obj: The object to inspect

        Returns:
            List of attribute names to serialize
        """
        attributes = []
        for attr_name in dir(obj):
            # Skip dunder attributes
            if attr_name.startswith("__") and attr_name.endswith("__"):
                continue

            # Skip methods and callables
            attr_value = getattr(obj, attr_name, None)
            if callable(attr_value) and not isinstance(attr_value, property):
                continue

            # Skip class-level attributes that are not instance-specific
            if not hasattr(obj, "__dict__") or attr_name not in obj.__dict__:
                # Also check __slots__ if present
                if hasattr(type(obj), "__slots__"):
                    if attr_name not in type(obj).__slots__:
                        continue
                else:
                    continue

            attributes.append(attr_name)

        return attributes

    def _is_dunder(self, name: str) -> bool:
        """Check if a name is a dunder (double underscore) attribute."""
        return name.startswith("__") and name.endswith("__")
