"""Strategy for aiomysql (MySQL async) driver."""

from typing import Any, TYPE_CHECKING

from ._base import AsyncSqlExecutionStrategy

if TYPE_CHECKING:
    from .._config import SqlTestConfig


class AiomysqlStrategy(AsyncSqlExecutionStrategy):
    """Execution strategy for aiomysql (MySQL async)."""

    driver_name = "aiomysql"
    is_async = True
    default_port = 3306
    param_mapping = {
        "host": "host",
        "database": "db",
        "user": "user",
        "password": "password",
        "port": "port",
    }

    async def execute_async(self, sql_content: str, config: "SqlTestConfig") -> None:
        """Execute SQL using aiomysql."""
        driver = self.get_driver_module()
        params = self.build_connection_params(config)

        connection = await self.get_cached_connection_async(
            config, lambda: driver.connect(**params)
        )
        try:
            async with connection.cursor() as cursor:
                # aiomysql doesn't support multi-statement by default
                await self._execute_statements(cursor, sql_content)
            await connection.commit()
        except Exception:
            await connection.rollback()
            raise

    async def _execute_statements(self, cursor: Any, sql_content: str) -> None:
        """Execute multiple SQL statements for aiomysql."""
        for statement in self.split_sql_statements(sql_content):
            await cursor.execute(statement)
            # Consume any results to avoid unread result issues
            try:
                await cursor.fetchall()
            except Exception:
                # No results to fetch (e.g., INSERT, UPDATE, DELETE, DDL)
                pass
