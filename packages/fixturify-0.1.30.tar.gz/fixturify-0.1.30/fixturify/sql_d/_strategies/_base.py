"""Base classes for SQL execution strategies."""

from abc import ABC, abstractmethod
from typing import Any, Callable, Dict, List, TYPE_CHECKING

if TYPE_CHECKING:
    from .._config import SqlTestConfig


class SqlExecutionStrategy(ABC):
    """
    Abstract base class for synchronous SQL execution strategies.

    Each strategy handles execution for a specific database driver.
    Strategies encapsulate driver-specific behavior like:
    - Connection handling
    - Multi-statement execution
    - Error handling
    """

    # Driver name (used for registration)
    driver_name: str = ""

    # Whether this is an async strategy
    is_async: bool = False

    # Default port for this driver
    default_port: int = 0

    # Parameter name mapping from SqlTestConfig to driver-specific names
    param_mapping: Dict[str, str] = {}

    @abstractmethod
    def execute(self, sql_content: str, config: "SqlTestConfig") -> None:
        """
        Execute SQL content against the database.

        Args:
            sql_content: SQL statements to execute
            config: Database connection configuration
        """
        pass

    @staticmethod
    def split_sql_statements(sql_content: str) -> List[str]:
        """Split SQL into statements, respecting quoted strings.

        Handles single-quoted strings (including escaped quotes '').
        Strips and skips empty statements and single-line comments.
        """
        statements: List[str] = []
        current: List[str] = []
        i = 0
        in_single_quote = False

        while i < len(sql_content):
            ch = sql_content[i]

            if in_single_quote:
                current.append(ch)
                if ch == "'" and i + 1 < len(sql_content) and sql_content[i + 1] == "'":
                    # Escaped quote ''
                    current.append("'")
                    i += 2
                    continue
                elif ch == "'":
                    in_single_quote = False
            elif ch == "'":
                in_single_quote = True
                current.append(ch)
            elif ch == "-" and i + 1 < len(sql_content) and sql_content[i + 1] == "-":
                # Line comment — skip to end of line
                while i < len(sql_content) and sql_content[i] != "\n":
                    i += 1
                continue
            elif ch == ";":
                stmt = "".join(current).strip()
                if stmt:
                    statements.append(stmt)
                current = []
            else:
                current.append(ch)
            i += 1

        # Last statement (no trailing semicolon)
        stmt = "".join(current).strip()
        if stmt:
            statements.append(stmt)

        return statements

    def build_connection_params(self, config: "SqlTestConfig") -> Dict[str, Any]:
        """
        Build connection parameters for this driver.

        Args:
            config: Database connection configuration

        Returns:
            Dictionary of driver-specific connection parameters
        """
        params: Dict[str, Any] = {}

        if "host" in self.param_mapping:
            params[self.param_mapping["host"]] = config.host

        if "database" in self.param_mapping:
            params[self.param_mapping["database"]] = config.database

        if "user" in self.param_mapping:
            params[self.param_mapping["user"]] = config.user

        if "password" in self.param_mapping:
            params[self.param_mapping["password"]] = config.password

        if "port" in self.param_mapping:
            port = config.port or self.default_port
            if port:  # Skip if port is 0 (e.g., SQLite)
                params[self.param_mapping["port"]] = port

        return params

    def get_driver_module(self) -> Any:
        """
        Import and return the driver module.

        Returns:
            The imported driver module

        Raises:
            ImportError: If driver is not installed
        """
        import importlib

        try:
            return importlib.import_module(self.driver_name)
        except ImportError as e:
            raise ImportError(
                f"Database driver '{self.driver_name}' is not installed. "
                f"Install it with: pip install {self.driver_name}"
            ) from e

    def get_cached_connection(
        self,
        config: "SqlTestConfig",
        connect_func: Callable[..., Any],
        connect_params: Dict[str, Any],
    ) -> Any:
        """
        Get a cached connection or create a new one.

        Args:
            config: Database configuration
            connect_func: Function to create connection
            connect_params: Parameters for connect_func

        Returns:
            Database connection (cached or newly created)
        """
        from .._connection_cache import get_connection_cache

        cache = get_connection_cache()
        return cache.get_sync(config, connect_func, connect_params)


class AsyncSqlExecutionStrategy(SqlExecutionStrategy):
    """
    Abstract base class for asynchronous SQL execution strategies.
    """

    is_async: bool = True

    @abstractmethod
    async def execute_async(self, sql_content: str, config: "SqlTestConfig") -> None:
        """
        Execute SQL content against the database asynchronously.

        Args:
            sql_content: SQL statements to execute
            config: Database connection configuration
        """
        pass

    def execute(self, sql_content: str, config: "SqlTestConfig") -> None:
        """Sync execute - raises error for async strategies."""
        raise RuntimeError(
            f"Strategy {self.driver_name} is async. Use execute_async() instead."
        )

    async def get_cached_connection_async(
        self,
        config: "SqlTestConfig",
        connect_factory: Any,
    ) -> Any:
        """
        Get a cached async connection or create a new one.

        Note: Async connections are tied to the event loop. For caching to work,
        pytest must use session-scoped event loop:

            [tool.pytest.ini_options]
            asyncio_default_fixture_loop_scope = "session"

        Args:
            config: Database configuration
            connect_factory: Callable that returns a coroutine when called

        Returns:
            Database connection (cached or newly created)
        """
        from .._connection_cache import get_connection_cache

        cache = get_connection_cache()
        return await cache.get_async(config, connect_factory)
