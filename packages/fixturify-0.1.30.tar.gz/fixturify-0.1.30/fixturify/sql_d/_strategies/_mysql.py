"""Strategy for mysql.connector (MySQL) driver."""

from typing import Any, TYPE_CHECKING

from ._base import SqlExecutionStrategy

if TYPE_CHECKING:
    from .._config import SqlTestConfig


class MysqlConnectorStrategy(SqlExecutionStrategy):
    """Execution strategy for mysql.connector (MySQL)."""

    driver_name = "mysql.connector"
    is_async = False
    default_port = 3306
    param_mapping = {
        "host": "host",
        "database": "database",
        "user": "user",
        "password": "password",
        "port": "port",
    }

    def execute(self, sql_content: str, config: "SqlTestConfig") -> None:
        """Execute SQL using mysql.connector."""
        driver = self.get_driver_module()
        params = self.build_connection_params(config)

        connection = self.get_cached_connection(config, driver.connect, params)
        cursor = connection.cursor()
        try:
            # MySQL connector doesn't support multi-statement by default
            self._execute_statements(cursor, sql_content, driver)
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            cursor.close()

    def _execute_statements(self, cursor: Any, sql_content: str, driver: Any) -> None:
        """
        Execute multiple SQL statements for MySQL.

        MySQL connector doesn't execute multiple statements by default.
        We split by semicolon and execute each statement separately.

        Args:
            cursor: Database cursor
            sql_content: SQL content with potentially multiple statements
            driver: The mysql.connector module
        """
        for statement in self.split_sql_statements(sql_content):
            cursor.execute(statement)
            # Consume any results to avoid "Unread result found" error
            try:
                cursor.fetchall()
            except driver.errors.InterfaceError:
                # No results to fetch (e.g., INSERT, UPDATE, DELETE, DDL)
                pass
