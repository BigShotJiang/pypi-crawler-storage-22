"""Strategy for psycopg2 (PostgreSQL) driver."""

from typing import TYPE_CHECKING

from ._base import SqlExecutionStrategy

if TYPE_CHECKING:
    from .._config import SqlTestConfig


class Psycopg2Strategy(SqlExecutionStrategy):
    """Execution strategy for psycopg2 (PostgreSQL)."""

    driver_name = "psycopg2"
    is_async = False
    default_port = 5432
    param_mapping = {
        "host": "host",
        "database": "dbname",
        "user": "user",
        "password": "password",
        "port": "port",
    }

    def execute(self, sql_content: str, config: "SqlTestConfig") -> None:
        """Execute SQL using psycopg2."""
        driver = self.get_driver_module()
        params = self.build_connection_params(config)

        connection = self.get_cached_connection(config, driver.connect, params)
        cursor = connection.cursor()
        try:
            # psycopg2 supports multi-statement execution
            cursor.execute(sql_content)
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            cursor.close()
