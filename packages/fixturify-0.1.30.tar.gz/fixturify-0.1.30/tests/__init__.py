"""Fixturify test suite."""
