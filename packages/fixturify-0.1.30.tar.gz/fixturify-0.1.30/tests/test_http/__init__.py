"""Tests for fixturify.http module."""
