"""Tests for update mode feature."""

import asyncio
import json
import pytest

from fixturify.http_d import HttpTestConfig, http
from fixturify.http_d._mock_context import HttpMockContext
from fixturify.http_d._models import HttpRequest, HttpResponse


API_BASE = "https://api.restful-api.dev"

# Check if requests is available
try:
    import requests

    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False

try:
    import httpx

    HAS_HTTPX = True
except ImportError:
    HAS_HTTPX = False

try:
    import aiohttp

    HAS_AIOHTTP = True
except ImportError:
    HAS_AIOHTTP = False


def _create_fixture(path, mappings):
    """Helper to create a fixture file with given mappings."""
    data = {"mappings": mappings}
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(data, f, indent=2)


def _read_fixture(path):
    """Helper to read a fixture file."""
    with open(path, "r") as f:
        return json.load(f)


class TestUpdateConfig:
    """Tests for update config field."""

    def test_default_is_false(self):
        config = HttpTestConfig()
        assert config.update is False

    def test_can_set_true(self):
        config = HttpTestConfig(update=True)
        assert config.update is True

    def test_merge_override(self):
        config = HttpTestConfig(update=False)
        merged = config.merge({"update": True})
        assert merged.update is True

    def test_is_valid_field(self):
        assert "update" in HttpTestConfig._VALID_FIELDS

    def test_is_bool_field(self):
        assert "update" in HttpTestConfig._BOOL_FIELDS


class TestUpdateMode:
    """Tests for update mode (update=True with existing fixture)."""

    def test_mode_is_update_when_file_exists_and_update(self, tmp_path):
        fixture = tmp_path / "test.json"
        _create_fixture(fixture, [])
        config = HttpTestConfig(update=True)

        ctx = HttpMockContext(fixture, config)
        assert ctx.mode == "update"

    def test_mode_is_record_when_file_missing(self, tmp_path):
        fixture = tmp_path / "test.json"
        config = HttpTestConfig(update=True)

        ctx = HttpMockContext(fixture, config)
        assert ctx.mode == "record"

    def test_mode_is_playback_without_update(self, tmp_path):
        fixture = tmp_path / "test.json"
        _create_fixture(fixture, [])
        config = HttpTestConfig(update=False)

        ctx = HttpMockContext(fixture, config)
        assert ctx.mode == "playback"

    def test_update_has_both_player_and_recorder(self, tmp_path):
        fixture = tmp_path / "test.json"
        _create_fixture(fixture, [])
        config = HttpTestConfig(update=True)

        ctx = HttpMockContext(fixture, config)
        assert ctx._player is not None
        assert ctx._recorder is not None

    def test_matching_request_returns_playback(self, tmp_path):
        """Matching request returns recorded response."""
        fixture = tmp_path / "test.json"
        _create_fixture(fixture, [
            {
                "request": {
                    "method": "GET",
                    "url": "https://example.com/api/1",
                    "headers": {},
                    "queryParameters": {},
                },
                "response": {
                    "status": 200,
                    "headers": {"Content-Type": "application/json"},
                    "body": {"id": 1, "name": "Existing"},
                },
            }
        ])
        config = HttpTestConfig(update=True)
        ctx = HttpMockContext(fixture, config)

        request = HttpRequest(method="GET", url="https://example.com/api/1")
        assert ctx.can_play_response_for(request) is True
        response = ctx.play_response(request)
        assert response.status == 200
        assert "Existing" in response.body


class TestUpdateSave:
    """Tests for how update mode saves the fixture file."""

    def test_used_stubs_kept(self, tmp_path):
        """Played-back stubs are kept in the fixture."""
        fixture = tmp_path / "test.json"
        _create_fixture(fixture, [
            {
                "request": {"method": "GET", "url": "https://example.com/a", "headers": {}, "queryParameters": {}},
                "response": {"status": 200, "headers": {}, "body": "a"},
            },
        ])
        config = HttpTestConfig(update=True)
        ctx = HttpMockContext(fixture, config)

        ctx.play_response(HttpRequest(method="GET", url="https://example.com/a"))
        ctx._save_update()

        data = _read_fixture(fixture)
        assert len(data["mappings"]) == 1
        assert data["mappings"][0]["request"]["url"] == "https://example.com/a"

    def test_unused_stubs_removed(self, tmp_path):
        """Unused stubs are removed from the fixture."""
        fixture = tmp_path / "test.json"
        _create_fixture(fixture, [
            {
                "request": {"method": "GET", "url": "https://example.com/a", "headers": {}, "queryParameters": {}},
                "response": {"status": 200, "headers": {}, "body": "a"},
            },
            {
                "request": {"method": "GET", "url": "https://example.com/stale", "headers": {}, "queryParameters": {}},
                "response": {"status": 200, "headers": {}, "body": "stale"},
            },
        ])
        config = HttpTestConfig(update=True)
        ctx = HttpMockContext(fixture, config)

        # Only use the first stub
        ctx.play_response(HttpRequest(method="GET", url="https://example.com/a"))
        ctx._save_update()

        data = _read_fixture(fixture)
        assert len(data["mappings"]) == 1
        assert data["mappings"][0]["request"]["url"] == "https://example.com/a"

    def test_new_recording_added(self, tmp_path):
        """New recordings (no matching stub) are added to the fixture."""
        fixture = tmp_path / "test.json"
        _create_fixture(fixture, [
            {
                "request": {"method": "GET", "url": "https://example.com/a", "headers": {}, "queryParameters": {}},
                "response": {"status": 200, "headers": {}, "body": "a"},
            },
        ])
        config = HttpTestConfig(update=True)
        ctx = HttpMockContext(fixture, config)

        # Play existing
        ctx.play_response(HttpRequest(method="GET", url="https://example.com/a"))

        # Record new
        ctx.record(
            HttpRequest(method="POST", url="https://example.com/b",
                       headers={"Content-Type": "application/json"}, body='{"x":1}'),
            HttpResponse(status=201, headers={"Content-Type": "application/json"}, body='{"id":2}'),
        )
        ctx._save_update()

        data = _read_fixture(fixture)
        assert len(data["mappings"]) == 2
        assert data["mappings"][0]["request"]["url"] == "https://example.com/a"
        assert data["mappings"][1]["request"]["url"] == "https://example.com/b"

    def test_mismatched_stub_replaced(self, tmp_path):
        """When request body changes, the old stub is replaced with the new recording."""
        fixture = tmp_path / "test.json"
        _create_fixture(fixture, [
            {
                "request": {"method": "GET", "url": "https://example.com/a", "headers": {}, "queryParameters": {}},
                "response": {"status": 200, "headers": {}, "body": "a"},
            },
            {
                "request": {
                    "method": "POST", "url": "https://example.com/b",
                    "headers": {}, "queryParameters": {},
                    "body": {"old": "body"},
                },
                "response": {"status": 200, "headers": {}, "body": "old response"},
            },
        ])
        config = HttpTestConfig(update=True)
        ctx = HttpMockContext(fixture, config)

        # Play matching stub
        ctx.play_response(HttpRequest(method="GET", url="https://example.com/a"))

        # Record replacement for the mismatched stub (same URL, different body)
        ctx.record(
            HttpRequest(method="POST", url="https://example.com/b",
                       headers={"Content-Type": "application/json"}, body='{"new":"body"}'),
            HttpResponse(status=200, headers={"Content-Type": "application/json"}, body='{"new":"response"}'),
        )
        ctx._save_update()

        data = _read_fixture(fixture)
        # Should have 2 mappings: kept original + replacement (not 3)
        assert len(data["mappings"]) == 2
        assert data["mappings"][0]["request"]["url"] == "https://example.com/a"
        # The second one is the NEW recording, not the old mismatched one
        assert data["mappings"][1]["request"]["url"] == "https://example.com/b"
        assert data["mappings"][1]["request"]["body"] == {"new": "body"}

    def test_order_follows_test_execution(self, tmp_path):
        """Final fixture order matches the test execution order."""
        fixture = tmp_path / "test.json"
        _create_fixture(fixture, [
            {
                "request": {"method": "GET", "url": "https://example.com/a", "headers": {}, "queryParameters": {}},
                "response": {"status": 200, "headers": {}, "body": "a"},
            },
            {
                "request": {"method": "GET", "url": "https://example.com/b", "headers": {}, "queryParameters": {}},
                "response": {"status": 200, "headers": {}, "body": "b"},
            },
        ])
        config = HttpTestConfig(update=True, strict_order=False)
        ctx = HttpMockContext(fixture, config)

        # Play in reverse order
        ctx.play_response(HttpRequest(method="GET", url="https://example.com/b"))
        ctx.play_response(HttpRequest(method="GET", url="https://example.com/a"))
        ctx._save_update()

        data = _read_fixture(fixture)
        assert len(data["mappings"]) == 2
        # Order follows test execution: b first, then a
        assert data["mappings"][0]["request"]["url"] == "https://example.com/b"
        assert data["mappings"][1]["request"]["url"] == "https://example.com/a"

    def test_no_unused_recordings_error(self, tmp_path):
        """Update mode does NOT raise UnusedRecordingsError."""
        fixture = tmp_path / "test.json"
        _create_fixture(fixture, [
            {
                "request": {"method": "GET", "url": "https://example.com/a", "headers": {}, "queryParameters": {}},
                "response": {"status": 200, "headers": {}, "body": "a"},
            },
            {
                "request": {"method": "GET", "url": "https://example.com/b", "headers": {}, "queryParameters": {}},
                "response": {"status": 200, "headers": {}, "body": "b"},
            },
        ])
        config = HttpTestConfig(update=True)
        ctx = HttpMockContext(fixture, config)

        ctx.__enter__()
        ctx.play_response(HttpRequest(method="GET", url="https://example.com/a"))
        # /b is unused — should NOT raise
        ctx.__exit__(None, None, None)

    def test_empty_fixture_after_no_interactions(self, tmp_path):
        """If no interactions happen, all stubs are removed."""
        fixture = tmp_path / "test.json"
        _create_fixture(fixture, [
            {
                "request": {"method": "GET", "url": "https://example.com/stale", "headers": {}, "queryParameters": {}},
                "response": {"status": 200, "headers": {}, "body": "stale"},
            },
        ])
        config = HttpTestConfig(update=True)
        ctx = HttpMockContext(fixture, config)

        # No interactions
        ctx._save_update()

        data = _read_fixture(fixture)
        assert len(data["mappings"]) == 0


class TestUpdateDecorator:
    """Tests for update via decorator kwargs."""

    @pytest.mark.skipif(not HAS_REQUESTS, reason="requests not installed")
    def test_decorator_with_update_kwarg(self, tmp_path):
        """Matching request returns playback via decorator."""
        fixture = tmp_path / "decorator_test.json"
        _create_fixture(fixture, [
            {
                "request": {
                    "method": "GET",
                    "url": f"{API_BASE}/objects/1",
                    "headers": {},
                    "queryParameters": {},
                },
                "response": {
                    "status": 200,
                    "headers": {"Content-Type": "application/json"},
                    "body": {"id": "1", "name": "Test Object"},
                },
            }
        ])

        @http(path=str(fixture), update=True)
        def test_func():
            response = requests.get(f"{API_BASE}/objects/1")
            assert response.status_code == 200
            data = response.json()
            assert data["name"] == "Test Object"

        test_func()

    @pytest.mark.skipif(not HAS_REQUESTS, reason="requests not installed")
    def test_decorator_with_config_update(self, tmp_path):
        """update works via config object."""
        fixture = tmp_path / "config_test.json"
        _create_fixture(fixture, [
            {
                "request": {
                    "method": "GET",
                    "url": f"{API_BASE}/objects/1",
                    "headers": {},
                    "queryParameters": {},
                },
                "response": {
                    "status": 200,
                    "headers": {"Content-Type": "application/json"},
                    "body": {"id": "1", "name": "Config Test"},
                },
            }
        ])

        config = HttpTestConfig(update=True)

        @http(path=str(fixture), config=config)
        def test_func():
            response = requests.get(f"{API_BASE}/objects/1")
            assert response.status_code == 200

        test_func()

    @pytest.mark.skipif(not HAS_REQUESTS, reason="requests not installed")
    def test_decorator_unused_stubs_removed_from_file(self, tmp_path):
        """After test, unused stubs are removed from the fixture file."""
        fixture = tmp_path / "cleanup_test.json"
        _create_fixture(fixture, [
            {
                "request": {
                    "method": "GET",
                    "url": f"{API_BASE}/objects/1",
                    "headers": {},
                    "queryParameters": {},
                },
                "response": {
                    "status": 200,
                    "headers": {"Content-Type": "application/json"},
                    "body": {"id": "1", "name": "Keep"},
                },
            },
            {
                "request": {
                    "method": "GET",
                    "url": f"{API_BASE}/objects/999",
                    "headers": {},
                    "queryParameters": {},
                },
                "response": {
                    "status": 200,
                    "headers": {"Content-Type": "application/json"},
                    "body": {"id": "999", "name": "Stale - should be removed"},
                },
            },
        ])

        @http(path=str(fixture), update=True)
        def test_func():
            # Only use the first stub
            response = requests.get(f"{API_BASE}/objects/1")
            assert response.status_code == 200

        test_func()

        # Verify stale stub was removed
        data = _read_fixture(fixture)
        assert len(data["mappings"]) == 1
        assert data["mappings"][0]["request"]["url"] == f"{API_BASE}/objects/1"


class TestUpdateWithAsyncioGather:
    """Tests for update mode with asyncio.gather (concurrent requests)."""

    def _make_mappings(self, task_count, calls_per_task):
        """Create mappings simulating N tasks, each calling M endpoints."""
        mappings = []
        for task_id in range(1, task_count + 1):
            for call_id in range(1, calls_per_task + 1):
                mappings.append({
                    "request": {
                        "method": "GET",
                        "url": f"https://example.com/task/{task_id}/call/{call_id}",
                        "headers": {},
                        "queryParameters": {},
                    },
                    "response": {
                        "status": 200,
                        "headers": {"Content-Type": "application/json"},
                        "body": {"task": task_id, "call": call_id},
                    },
                })
        return mappings

    @pytest.mark.skipif(not HAS_HTTPX, reason="httpx not installed")
    async def test_gather_5_tasks_2_calls_all_matching(self, tmp_path):
        """5 tasks x 2 calls = 10 calls, all matching existing stubs."""
        fixture = tmp_path / "gather_test.json"
        _create_fixture(fixture, self._make_mappings(5, 2))

        @http(path=str(fixture), update=True, strict_order=False)
        async def test_func():
            async with httpx.AsyncClient() as client:
                async def task(task_id):
                    r1 = await client.get(f"https://example.com/task/{task_id}/call/1")
                    r2 = await client.get(f"https://example.com/task/{task_id}/call/2")
                    return r1, r2

                results = await asyncio.gather(
                    task(1), task(2), task(3), task(4), task(5)
                )

                # All should return 200
                for r1, r2 in results:
                    assert r1.status_code == 200
                    assert r2.status_code == 200

        await test_func()

        # Verify fixture has exactly 10 mappings
        data = _read_fixture(fixture)
        assert len(data["mappings"]) == 10

    @pytest.mark.skipif(not HAS_HTTPX, reason="httpx not installed")
    async def test_gather_5_tasks_2_calls_some_new(self, tmp_path):
        """5 tasks x 2 calls = 10 calls, but only 6 have stubs (4 are new)."""
        fixture = tmp_path / "gather_partial.json"
        # Only create stubs for tasks 1-3 (6 stubs), tasks 4-5 are new
        _create_fixture(fixture, self._make_mappings(3, 2))

        @http(path=str(fixture), update=True, strict_order=False)
        async def test_func():
            async with httpx.AsyncClient() as client:
                async def task(task_id):
                    r1 = await client.get(
                        f"https://jsonplaceholder.typicode.com/posts/{task_id}"
                    )
                    r2 = await client.get(
                        f"https://jsonplaceholder.typicode.com/comments/{task_id}"
                    )
                    return r1, r2

                results = await asyncio.gather(
                    task(1), task(2), task(3), task(4), task(5)
                )

                for r1, r2 in results:
                    assert r1.status_code == 200
                    assert r2.status_code == 200

        await test_func()

        # Should have exactly 10 (6 played + 4 newly recorded)
        data = _read_fixture(fixture)
        assert len(data["mappings"]) == 10

    @pytest.mark.skipif(not HAS_HTTPX, reason="httpx not installed")
    async def test_gather_unused_stubs_removed(self, tmp_path):
        """Stubs for tasks that no longer exist are removed."""
        fixture = tmp_path / "gather_cleanup.json"
        # Create stubs for tasks 1-5 (10 stubs)
        _create_fixture(fixture, self._make_mappings(5, 2))

        @http(path=str(fixture), update=True, strict_order=False)
        async def test_func():
            async with httpx.AsyncClient() as client:
                # Only run tasks 1-3 (6 calls), tasks 4-5 stubs are unused
                async def task(task_id):
                    r1 = await client.get(f"https://example.com/task/{task_id}/call/1")
                    r2 = await client.get(f"https://example.com/task/{task_id}/call/2")
                    return r1, r2

                results = await asyncio.gather(task(1), task(2), task(3))
                for r1, r2 in results:
                    assert r1.status_code == 200
                    assert r2.status_code == 200

        await test_func()

        # Should have 6 (tasks 4-5 removed)
        data = _read_fixture(fixture)
        assert len(data["mappings"]) == 6

    @pytest.mark.skipif(not HAS_HTTPX, reason="httpx not installed")
    async def test_gather_correct_count_sequential_within_task(self, tmp_path):
        """Each task makes sequential calls — verify no double-counting."""
        fixture = tmp_path / "gather_seq.json"
        _create_fixture(fixture, self._make_mappings(3, 3))  # 9 stubs

        @http(path=str(fixture), update=True, strict_order=False)
        async def test_func():
            async with httpx.AsyncClient() as client:
                async def task(task_id):
                    responses = []
                    for call_id in range(1, 4):
                        r = await client.get(
                            f"https://example.com/task/{task_id}/call/{call_id}"
                        )
                        responses.append(r)
                    return responses

                all_results = await asyncio.gather(task(1), task(2), task(3))
                for results in all_results:
                    assert len(results) == 3
                    for r in results:
                        assert r.status_code == 200

        await test_func()

        data = _read_fixture(fixture)
        assert len(data["mappings"]) == 9


JSONPLACEHOLDER = "https://jsonplaceholder.typicode.com"


class TestGatherRecordMode:
    """Tests for asyncio.gather in pure record mode (no fixture file exists)."""

    @pytest.mark.skipif(not HAS_HTTPX, reason="httpx not installed")
    async def test_httpx_gather_record_from_scratch(self, tmp_path):
        """httpx: 5 tasks x 2 calls = 10 recorded mappings."""
        fixture = tmp_path / "httpx_gather_record.json"

        @http(path=str(fixture), strict_order=False)
        async def test_func():
            async with httpx.AsyncClient() as client:
                async def task(task_id):
                    r1 = await client.get(f"{JSONPLACEHOLDER}/posts/{task_id}")
                    r2 = await client.get(f"{JSONPLACEHOLDER}/comments/{task_id}")
                    return r1, r2

                results = await asyncio.gather(
                    task(1), task(2), task(3), task(4), task(5)
                )

                for r1, r2 in results:
                    assert r1.status_code == 200
                    assert r2.status_code == 200

        await test_func()

        data = _read_fixture(fixture)
        assert len(data["mappings"]) == 10

    @pytest.mark.skipif(not HAS_AIOHTTP, reason="aiohttp not installed")
    async def test_aiohttp_gather_record_from_scratch(self, tmp_path):
        """aiohttp: 5 tasks x 2 calls = 10 recorded mappings."""
        fixture = tmp_path / "aiohttp_gather_record.json"

        @http(path=str(fixture), strict_order=False)
        async def test_func():
            async with aiohttp.ClientSession() as session:
                async def task(task_id):
                    async with session.get(
                        f"{JSONPLACEHOLDER}/posts/{task_id}"
                    ) as r1:
                        await r1.read()
                        status1 = r1.status
                    async with session.get(
                        f"{JSONPLACEHOLDER}/comments/{task_id}"
                    ) as r2:
                        await r2.read()
                        status2 = r2.status
                    return status1, status2

                results = await asyncio.gather(
                    task(1), task(2), task(3), task(4), task(5)
                )

                for s1, s2 in results:
                    assert s1 == 200
                    assert s2 == 200

        await test_func()

        data = _read_fixture(fixture)
        assert len(data["mappings"]) == 10


class TestGatherUpdateModeAiohttp:
    """Tests for update mode with asyncio.gather using aiohttp."""

    def _make_mappings(self, task_count, calls_per_task):
        """Create mappings simulating N tasks, each calling M endpoints."""
        mappings = []
        for task_id in range(1, task_count + 1):
            for call_id in range(1, calls_per_task + 1):
                mappings.append({
                    "request": {
                        "method": "GET",
                        "url": f"https://example.com/task/{task_id}/call/{call_id}",
                        "headers": {},
                        "queryParameters": {},
                    },
                    "response": {
                        "status": 200,
                        "headers": {"Content-Type": "application/json"},
                        "body": {"task": task_id, "call": call_id},
                    },
                })
        return mappings

    @pytest.mark.skipif(not HAS_AIOHTTP, reason="aiohttp not installed")
    async def test_aiohttp_gather_all_matching(self, tmp_path):
        """aiohttp: 5 tasks x 2 calls, all stubs match."""
        fixture = tmp_path / "aiohttp_gather_all.json"
        _create_fixture(fixture, self._make_mappings(5, 2))

        @http(path=str(fixture), update=True, strict_order=False)
        async def test_func():
            async with aiohttp.ClientSession() as session:
                async def task(task_id):
                    async with session.get(
                        f"https://example.com/task/{task_id}/call/1"
                    ) as r1:
                        s1 = r1.status
                    async with session.get(
                        f"https://example.com/task/{task_id}/call/2"
                    ) as r2:
                        s2 = r2.status
                    return s1, s2

                results = await asyncio.gather(
                    task(1), task(2), task(3), task(4), task(5)
                )
                for s1, s2 in results:
                    assert s1 == 200
                    assert s2 == 200

        await test_func()

        data = _read_fixture(fixture)
        assert len(data["mappings"]) == 10

    @pytest.mark.skipif(not HAS_AIOHTTP, reason="aiohttp not installed")
    async def test_aiohttp_gather_unused_removed(self, tmp_path):
        """aiohttp: stubs for tasks that no longer exist are removed."""
        fixture = tmp_path / "aiohttp_gather_cleanup.json"
        _create_fixture(fixture, self._make_mappings(5, 2))

        @http(path=str(fixture), update=True, strict_order=False)
        async def test_func():
            async with aiohttp.ClientSession() as session:
                async def task(task_id):
                    async with session.get(
                        f"https://example.com/task/{task_id}/call/1"
                    ) as r1:
                        s1 = r1.status
                    async with session.get(
                        f"https://example.com/task/{task_id}/call/2"
                    ) as r2:
                        s2 = r2.status
                    return s1, s2

                results = await asyncio.gather(task(1), task(2), task(3))
                for s1, s2 in results:
                    assert s1 == 200
                    assert s2 == 200

        await test_func()

        data_aiohttp = _read_fixture(fixture)
        assert len(data_aiohttp["mappings"]) == 6


class TestSaveOnFailure:
    """Tests that recordings are saved even when the test fails.

    This is critical: record mode must persist captured HTTP interactions
    regardless of test outcome. Otherwise you get a chicken-and-egg problem
    where the test needs the fixture to pass, but the fixture is never saved
    because the test fails.
    """

    def test_record_mode_saves_on_exception(self, tmp_path):
        """Record mode saves fixture file even when test raises an exception."""
        fixture = tmp_path / "record_on_fail.json"
        config = HttpTestConfig()
        ctx = HttpMockContext(fixture, config)
        assert ctx.mode == "record"

        ctx.record(
            HttpRequest(method="GET", url="https://example.com/api/1"),
            HttpResponse(status=200, headers={"Content-Type": "application/json"}, body='{"id":1}'),
        )

        ctx.__exit__(AssertionError, AssertionError("assert 500 == 200"), None)

        assert fixture.exists(), "Fixture file was not saved on test failure"
        data = _read_fixture(fixture)
        assert len(data["mappings"]) == 1
        assert data["mappings"][0]["request"]["url"] == "https://example.com/api/1"

    def test_record_mode_saves_on_no_exception(self, tmp_path):
        """Record mode still saves when test passes (sanity check)."""
        fixture = tmp_path / "record_on_pass.json"
        config = HttpTestConfig()
        ctx = HttpMockContext(fixture, config)

        ctx.record(
            HttpRequest(method="GET", url="https://example.com/api/1"),
            HttpResponse(status=200, headers={}, body="ok"),
        )
        ctx.__exit__(None, None, None)

        assert fixture.exists()
        data = _read_fixture(fixture)
        assert len(data["mappings"]) == 1

    def test_update_mode_saves_on_exception(self, tmp_path):
        """Update mode saves fixture file even when test raises an exception."""
        fixture = tmp_path / "update_on_fail.json"
        _create_fixture(fixture, [
            {
                "request": {"method": "GET", "url": "https://example.com/a", "headers": {}, "queryParameters": {}},
                "response": {"status": 200, "headers": {}, "body": "a"},
            },
            {
                "request": {"method": "GET", "url": "https://example.com/stale", "headers": {}, "queryParameters": {}},
                "response": {"status": 200, "headers": {}, "body": "stale"},
            },
        ])
        config = HttpTestConfig(update=True)
        ctx = HttpMockContext(fixture, config)

        ctx.play_response(HttpRequest(method="GET", url="https://example.com/a"))
        ctx.__exit__(AssertionError, AssertionError("test failed"), None)

        data = _read_fixture(fixture)
        assert len(data["mappings"]) == 1
        assert data["mappings"][0]["request"]["url"] == "https://example.com/a"

    def test_intercepted_error_does_not_prevent_save(self, tmp_path):
        """Intercepted error in stubs does not prevent saving recordings."""
        fixture = tmp_path / "intercepted_save.json"
        config = HttpTestConfig()
        ctx = HttpMockContext(fixture, config)
        assert ctx.mode == "record"

        ctx.record(
            HttpRequest(method="GET", url="https://example.com/token"),
            HttpResponse(status=200, headers={}, body='{"token":"abc"}'),
        )

        from fixturify.http_d._exceptions import NoMatchingRecordingError
        ctx._intercepted_error = NoMatchingRecordingError(
            request=HttpRequest(method="GET", url="https://example.com/missing"),
            available_mappings=[],
        )

        with pytest.raises(NoMatchingRecordingError):
            ctx.__exit__(None, None, None)

        assert fixture.exists(), "Fixture not saved when intercepted error present"
        data = _read_fixture(fixture)
        assert len(data["mappings"]) == 1
        assert data["mappings"][0]["request"]["url"] == "https://example.com/token"

    def test_playback_skips_verify_on_exception(self, tmp_path):
        """Playback mode does not raise UnusedRecordingsError when test already failed."""
        fixture = tmp_path / "playback_skip_verify.json"
        _create_fixture(fixture, [
            {
                "request": {"method": "GET", "url": "https://example.com/a", "headers": {}, "queryParameters": {}},
                "response": {"status": 200, "headers": {}, "body": "a"},
            },
            {
                "request": {"method": "GET", "url": "https://example.com/b", "headers": {}, "queryParameters": {}},
                "response": {"status": 200, "headers": {}, "body": "b"},
            },
        ])
        config = HttpTestConfig()
        ctx = HttpMockContext(fixture, config)
        assert ctx.mode == "playback"

        ctx.play_response(HttpRequest(method="GET", url="https://example.com/a"))

        result = ctx.__exit__(AssertionError, AssertionError("test failed"), None)
        assert result is False

    def test_playback_skips_verify_on_intercepted_error(self, tmp_path):
        """Playback mode does not raise UnusedRecordingsError when intercepted error exists."""
        fixture = tmp_path / "playback_intercepted.json"
        _create_fixture(fixture, [
            {
                "request": {"method": "GET", "url": "https://example.com/a", "headers": {}, "queryParameters": {}},
                "response": {"status": 200, "headers": {}, "body": "a"},
            },
            {
                "request": {"method": "GET", "url": "https://example.com/b", "headers": {}, "queryParameters": {}},
                "response": {"status": 200, "headers": {}, "body": "b"},
            },
        ])
        config = HttpTestConfig()
        ctx = HttpMockContext(fixture, config)

        from fixturify.http_d._exceptions import NoMatchingRecordingError
        ctx._intercepted_error = NoMatchingRecordingError(
            request=HttpRequest(method="GET", url="https://example.com/wrong"),
            available_mappings=[],
        )

        with pytest.raises(NoMatchingRecordingError):
            ctx.__exit__(None, None, None)
