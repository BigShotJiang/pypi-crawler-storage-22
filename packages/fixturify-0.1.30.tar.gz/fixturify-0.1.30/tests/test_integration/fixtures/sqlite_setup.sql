DROP TABLE IF EXISTS items;
CREATE TABLE items (id INTEGER PRIMARY KEY, name TEXT NOT NULL);
INSERT INTO items (id, name) VALUES (1, 'Widget'), (2, 'Gadget');
