"""Tests for decorator stacking order: @sql, @read.fixture, @http in all permutations.

Uses sqlite (no Docker needed) to verify request propagation works
regardless of which decorator is on top/bottom/middle.
"""

from dataclasses import dataclass
import sqlite3

import pytest
import requests

from fixturify import Phase, SqlTestConfig, http, read, sql


DB_PATH = ":memory:"


@dataclass
class ItemConfig:
    item_id: int
    fetch_details: bool


@pytest.fixture
def sql_config(tmp_path) -> SqlTestConfig:
    """SQLite config using a temp file so all decorators share the same DB."""
    return SqlTestConfig(
        driver="sqlite3",
        host="",
        database=str(tmp_path / "test.db"),
        user="",
        password="",
    )


def _query_items(db_path: str):
    """Read all items from the DB."""
    conn = sqlite3.connect(db_path)
    try:
        rows = conn.execute("SELECT id, name FROM items ORDER BY id").fetchall()
        return [{"id": r[0], "name": r[1]} for r in rows]
    finally:
        conn.close()


class TestDecoratorOrder:
    """All permutations of @sql, @read.fixture, @http stacking."""

    # --- sql on top, read in middle, http on bottom ---

    @sql(path="./fixtures/sqlite_setup.sql")
    @sql(path="./fixtures/sqlite_cleanup.sql", phase=Phase.AFTER)
    @read.fixture(
        path="./fixtures/item_config.json",
        fixture_name="config",
        object_class=ItemConfig,
    )
    @http(path="./fixtures/item_api.json")
    def test_sql_read_http(self, config: ItemConfig, sql_config: SqlTestConfig):
        """@sql > @read > @http"""
        assert config.item_id == 1
        items = _query_items(sql_config.database)
        assert len(items) == 2
        if config.fetch_details:
            r = requests.get(f"https://api.example.com/items/{config.item_id}/details")
            assert r.status_code == 200
            assert r.json()["color"] == "red"

    # --- sql on top, http in middle, read on bottom ---

    @sql(path="./fixtures/sqlite_setup.sql")
    @sql(path="./fixtures/sqlite_cleanup.sql", phase=Phase.AFTER)
    @http(path="./fixtures/item_api.json")
    @read.fixture(
        path="./fixtures/item_config.json",
        fixture_name="config",
        object_class=ItemConfig,
    )
    def test_sql_http_read(self, config: ItemConfig, sql_config: SqlTestConfig):
        """@sql > @http > @read"""
        assert config.item_id == 1
        items = _query_items(sql_config.database)
        assert len(items) == 2
        r = requests.get("https://api.example.com/items/1/details")
        assert r.status_code == 200

    # --- read on top, sql in middle, http on bottom ---

    @read.fixture(
        path="./fixtures/item_config.json",
        fixture_name="config",
        object_class=ItemConfig,
    )
    @sql(path="./fixtures/sqlite_setup.sql")
    @sql(path="./fixtures/sqlite_cleanup.sql", phase=Phase.AFTER)
    @http(path="./fixtures/item_api.json")
    def test_read_sql_http(self, config: ItemConfig, sql_config: SqlTestConfig):
        """@read > @sql > @http"""
        assert config.item_id == 1
        items = _query_items(sql_config.database)
        assert len(items) == 2
        r = requests.get("https://api.example.com/items/1/details")
        assert r.status_code == 200

    # --- read on top, http in middle, sql on bottom ---

    @read.fixture(
        path="./fixtures/item_config.json",
        fixture_name="config",
        object_class=ItemConfig,
    )
    @http(path="./fixtures/item_api.json")
    @sql(path="./fixtures/sqlite_setup.sql")
    @sql(path="./fixtures/sqlite_cleanup.sql", phase=Phase.AFTER)
    def test_read_http_sql(self, config: ItemConfig, sql_config: SqlTestConfig):
        """@read > @http > @sql"""
        assert config.item_id == 1
        items = _query_items(sql_config.database)
        assert len(items) == 2
        r = requests.get("https://api.example.com/items/1/details")
        assert r.status_code == 200

    # --- http on top, sql in middle, read on bottom ---

    @http(path="./fixtures/item_api.json")
    @sql(path="./fixtures/sqlite_setup.sql")
    @sql(path="./fixtures/sqlite_cleanup.sql", phase=Phase.AFTER)
    @read.fixture(
        path="./fixtures/item_config.json",
        fixture_name="config",
        object_class=ItemConfig,
    )
    def test_http_sql_read(self, config: ItemConfig, sql_config: SqlTestConfig):
        """@http > @sql > @read"""
        assert config.item_id == 1
        items = _query_items(sql_config.database)
        assert len(items) == 2
        r = requests.get("https://api.example.com/items/1/details")
        assert r.status_code == 200

    # --- http on top, read in middle, sql on bottom ---

    @http(path="./fixtures/item_api.json")
    @read.fixture(
        path="./fixtures/item_config.json",
        fixture_name="config",
        object_class=ItemConfig,
    )
    @sql(path="./fixtures/sqlite_setup.sql")
    @sql(path="./fixtures/sqlite_cleanup.sql", phase=Phase.AFTER)
    def test_http_read_sql(self, config: ItemConfig, sql_config: SqlTestConfig):
        """@http > @read > @sql"""
        assert config.item_id == 1
        items = _query_items(sql_config.database)
        assert len(items) == 2
        r = requests.get("https://api.example.com/items/1/details")
        assert r.status_code == 200


    # --- sql on top, http, read, sql on bottom ---

    @sql(path="./fixtures/sqlite_cleanup.sql")
    @read.fixture(
        path="./fixtures/item_config.json",
        fixture_name="config2",
        object_class=ItemConfig,
    )
    @http(path="./fixtures/item_api.json")
    @read.fixture(
        path="./fixtures/item_config.json",
        fixture_name="config",
        object_class=ItemConfig,
    )
    @sql(path="./fixtures/sqlite_setup.sql")
    def test_sql_http_read_sql(self, config: ItemConfig, config2: ItemConfig, sql_config: SqlTestConfig):
        """Bottom-to-top: @sql > @read > @http > @sql"""
        assert config.item_id == 1
        items = _query_items(sql_config.database)
        assert len(items) == 2
        r = requests.get("https://api.example.com/items/1/details")
        assert r.status_code == 200


class TestDecoratorOrderAsync:
    """Same permutations but async."""

    @sql(path="./fixtures/sqlite_setup.sql")
    @sql(path="./fixtures/sqlite_cleanup.sql", phase=Phase.AFTER)
    @read.fixture(
        path="./fixtures/item_config.json",
        fixture_name="config",
        object_class=ItemConfig,
    )
    async def test_async_sql_read(self, config: ItemConfig, sql_config: SqlTestConfig):
        """Async: @sql > @read"""
        assert config.item_id == 1
        items = _query_items(sql_config.database)
        assert len(items) == 2

    @read.fixture(
        path="./fixtures/item_config.json",
        fixture_name="config",
        object_class=ItemConfig,
    )
    @sql(path="./fixtures/sqlite_setup.sql")
    @sql(path="./fixtures/sqlite_cleanup.sql", phase=Phase.AFTER)
    async def test_async_read_sql(self, config: ItemConfig, sql_config: SqlTestConfig):
        """Async: @read > @sql"""
        assert config.item_id == 1
        items = _query_items(sql_config.database)
        assert len(items) == 2

    @read.fixture(
        path="./fixtures/item_config.json",
        fixture_name="config",
        object_class=ItemConfig,
    )
    @http(path="./fixtures/item_api.json")
    async def test_async_read_http(self, config: ItemConfig):
        """Async: @read > @http"""
        assert config.item_id == 1
        import httpx
        async with httpx.AsyncClient() as client:
            r = await client.get("https://api.example.com/items/1/details")
            assert r.status_code == 200

    @http(path="./fixtures/item_api.json")
    @read.fixture(
        path="./fixtures/item_config.json",
        fixture_name="config",
        object_class=ItemConfig,
    )
    @sql(path="./fixtures/sqlite_setup.sql")
    @sql(path="./fixtures/sqlite_cleanup.sql", phase=Phase.AFTER)
    async def test_async_http_read_sql(self, config: ItemConfig, sql_config: SqlTestConfig):
        """Async: @http > @read > @sql"""
        assert config.item_id == 1
        items = _query_items(sql_config.database)
        assert len(items) == 2
        import httpx
        async with httpx.AsyncClient() as client:
            r = await client.get("https://api.example.com/items/1/details")
            assert r.status_code == 200
