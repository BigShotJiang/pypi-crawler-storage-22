"""
Full integration test demonstrating all fixturify features together.

This test shows how to use:
- @sql: Execute SQL setup/cleanup
- @read: Load test fixtures from JSON
- @http: Mock external API calls
- JsonAssert: Compare results to expected JSON
"""

from dataclasses import dataclass
import uuid
from typing import Optional

import pytest
import requests
from unittest.mock import patch

from fixturify import JsonAssert, Phase, SqlTestConfig, http, read, sql


# --- Models ---


@dataclass
class ApiRequest:
    user_id: int
    include_profile: bool
    include_settings: bool


@dataclass
class UserProfile:
    avatar: str
    bio: str
    location: str


@dataclass
class User:
    id: int
    email: str
    name: str
    profile: Optional[UserProfile] = None


# --- Database helpers ---


def _can_connect() -> bool:
    """Check if PostgreSQL is available."""
    try:
        import psycopg2

        conn = psycopg2.connect(
            host="localhost",
            port=5432,
            dbname="fixturify",
            user="postgres",
            password="postgres",
        )
        conn.close()
        return True
    except Exception:
        return False


def _get_user_from_db(user_id: int) -> dict:
    """Fetch user from database."""
    import psycopg2

    conn = psycopg2.connect(
        host="localhost",
        port=5432,
        dbname="fixturify",
        user="postgres",
        password="postgres",
    )
    try:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT id, email, name FROM users WHERE id = %s",
            (user_id,),
        )
        row = cursor.fetchone()
        cursor.close()
        if row:
            return {"id": row[0], "email": row[1], "name": row[2]}
        return {}
    finally:
        conn.close()


# --- Pytest fixtures ---


@pytest.fixture
def sql_config() -> SqlTestConfig:
    """Database configuration for @sql decorator."""
    return SqlTestConfig(
        driver="psycopg2",
        host="localhost",
        port=5432,
        database="fixturify",
        user="postgres",
        password="postgres",
    )


@pytest.fixture
def uuid_value() -> uuid.UUID:
    """Stable UUID fixture for patching tests."""
    return uuid.UUID("00000000-0000-0000-0000-000000000001")


# --- Tests ---


@pytest.mark.skipif(not _can_connect(), reason="PostgreSQL not available")
class TestFullIntegration:
    """
    Integration test demonstrating all fixturify decorators working together.

    Scenario:
    1. @sql sets up test data in the database
    2. @read loads the API request configuration
    3. @http mocks the external profile API
    4. Test fetches user from DB, enriches with external API data
    5. JsonAssert verifies the final result
    """

    @sql(path="./fixtures/setup.sql")
    @sql(path="./fixtures/cleanup.sql", phase=Phase.AFTER)
    @read.fixture(
        path="./fixtures/api_request.json",
        fixture_name="api_request",
        object_class=ApiRequest,
    )
    @http(path="./fixtures/external_api.json")
    def test_user_with_profile(self, api_request: ApiRequest):
        """Test fetching user from DB and enriching with external API data."""
        # 1. Get user from database (set up by @sql)
        user_data = _get_user_from_db(api_request.user_id)
        assert user_data, "User should exist in database"

        # 2. If profile requested, fetch from external API (mocked by @http)
        if api_request.include_profile:
            response = requests.get(
                f"https://api.example.com/users/{api_request.user_id}/profile"
            )
            assert response.status_code == 200
            profile_data = response.json()
            user_data["profile"] = {
                "avatar": profile_data["avatar"],
                "bio": profile_data["bio"],
                "location": profile_data["location"],
            }

        # 3. Verify final result with JsonAssert
        JsonAssert(user_data).compare_to_file("./fixtures/expected_result.json")

    @patch("uuid.uuid4")
    @http(path="./fixtures/external_api.json")
    @read.fixture(
        path="./fixtures/api_request.json",
        fixture_name="api_request",
        object_class=ApiRequest,
    )
    @sql(path="./fixtures/setup.sql")
    @sql(path="./fixtures/cleanup.sql", phase=Phase.AFTER)
    def test_decorators_with_patch_and_fixture(
        self,
        mock_uuid4,
        uuid_value: uuid.UUID,
        api_request: ApiRequest,
    ):
        """Ensure pytest fixtures and patch decorators work with stacked fixturify."""
        mock_uuid4.return_value = uuid_value
        assert uuid.uuid4() == uuid_value

        if api_request.include_profile:
            response = requests.get(
                f"https://api.example.com/users/{api_request.user_id}/profile"
            )
            assert response.status_code == 200

    @http(path="./fixtures/external_api.json")
    @read.fixture(
        path="./fixtures/api_request.json",
        fixture_name="api_request",
        object_class=ApiRequest,
    )
    @sql(path="./fixtures/cleanup.sql", phase=Phase.AFTER)
    @sql(path="./fixtures/setup.sql")
    def test_user_with_profile_reordered(self, api_request: ApiRequest):
        """Same scenario as above, with decorators in different order."""
        # 1. Get user from database (set up by @sql)
        user_data = _get_user_from_db(api_request.user_id)
        assert user_data, "User should exist in database"

        # 2. If profile requested, fetch from external API (mocked by @http)
        if api_request.include_profile:
            response = requests.get(
                f"https://api.example.com/users/{api_request.user_id}/profile"
            )
            assert response.status_code == 200
            profile_data = response.json()
            user_data["profile"] = {
                "avatar": profile_data["avatar"],
                "bio": profile_data["bio"],
                "location": profile_data["location"],
            }

        # 3. Verify final result with JsonAssert
        JsonAssert(user_data).compare_to_file("./fixtures/expected_result.json")
