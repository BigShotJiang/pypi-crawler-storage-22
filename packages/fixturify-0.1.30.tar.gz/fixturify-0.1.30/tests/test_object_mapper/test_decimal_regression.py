"""Regression tests for Decimal support across all ObjectMapper paths.

Decimal previously fell through to PlainObjectSerializer and produced {}.
These tests ensure Decimal works in every context: standalone, dict, list,
dataclass, Pydantic, SQLModel (table and non-table), SQLAlchemy, and nested.
"""

from dataclasses import dataclass
from decimal import Decimal
from typing import List, Optional

from pydantic import BaseModel
from sqlalchemy import Integer, Numeric, String
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from sqlmodel import Field, SQLModel

from fixturify.object_mapper import ObjectMapper


# ── Models ──────────────────────────────────────────────────────────────


@dataclass
class Product:
    name: str
    price: Decimal
    tax: Decimal


@dataclass
class Order:
    product: Product
    quantity: int
    discount: Decimal


class PydanticProduct(BaseModel):
    name: str
    price: Decimal
    tax: Optional[Decimal] = None


class PydanticOrder(BaseModel):
    items: List[PydanticProduct]
    total: Decimal


class SQLModelProduct(SQLModel, table=True):
    __tablename__ = "sm_products"

    id: Optional[int] = Field(default=None, primary_key=True)
    name: str
    price: Decimal
    tax: Decimal = Decimal("0")


class SQLModelInvoice(SQLModel):
    """Non-table SQLModel with Decimal."""

    subtotal: Decimal
    tax: Decimal
    total: Decimal


class SABase(DeclarativeBase):
    pass


class SAProduct(SABase):
    __tablename__ = "sa_products"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(100))
    price: Mapped[Decimal] = mapped_column(Numeric(10, 2))


# ── Tests ───────────────────────────────────────────────────────────────


class TestDecimalDirect:
    """Standalone Decimal values."""

    def test_serialize_decimal_float(self):
        assert ObjectMapper(Decimal("9.99")).to_json() == 9.99

    def test_serialize_decimal_integer(self):
        result = ObjectMapper(Decimal("100")).to_json()
        assert result == 100
        assert isinstance(result, int)

    def test_serialize_decimal_zero(self):
        result = ObjectMapper(Decimal("0")).to_json()
        assert result == 0

    def test_serialize_decimal_negative(self):
        assert ObjectMapper(Decimal("-5.50")).to_json() == -5.5

    def test_to_json_string(self):
        result = ObjectMapper(Decimal("19.99")).to_json_string()
        assert result == "19.99"


class TestDecimalInDict:
    """Decimal inside plain dicts."""

    def test_dict_with_decimal_values(self):
        data = {"price": Decimal("29.99"), "tax": Decimal("2.40")}
        result = ObjectMapper(data).to_json()

        assert result["price"] == 29.99
        assert result["tax"] == 2.4

    def test_nested_dict_with_decimal(self):
        data = {
            "product": {"name": "Widget", "price": Decimal("5.00")},
            "quantity": 3,
        }
        result = ObjectMapper(data).to_json()

        assert result["product"]["price"] == 5
        assert isinstance(result["product"]["price"], int)

    def test_list_in_dict_with_decimal(self):
        data = {"prices": [Decimal("1.50"), Decimal("2.75"), Decimal("3.00")]}
        result = ObjectMapper(data).to_json()

        assert result["prices"] == [1.5, 2.75, 3]


class TestDecimalInDataclass:
    """Decimal in dataclass models."""

    def test_serialize(self):
        p = Product(name="Widget", price=Decimal("19.99"), tax=Decimal("1.60"))
        result = ObjectMapper(p).to_json()

        assert result["price"] == 19.99
        assert result["tax"] == 1.6

    def test_deserialize(self):
        data = {"name": "Widget", "price": 19.99, "tax": 1.6}
        p = ObjectMapper(data).to_object(Product)

        assert isinstance(p.price, Decimal)
        assert isinstance(p.tax, Decimal)

    def test_round_trip(self):
        original = Product(name="Gadget", price=Decimal("49.95"), tax=Decimal("4.00"))
        data = ObjectMapper(original).to_json()
        restored = ObjectMapper(data).to_object(Product)

        assert isinstance(restored.price, Decimal)
        assert isinstance(restored.tax, Decimal)
        assert restored.name == original.name

    def test_nested_dataclass_with_decimal(self):
        order = Order(
            product=Product(name="X", price=Decimal("10.00"), tax=Decimal("0.80")),
            quantity=2,
            discount=Decimal("1.50"),
        )
        data = ObjectMapper(order).to_json()

        assert data["discount"] == 1.5
        assert data["product"]["price"] == 10
        assert data["product"]["tax"] == 0.8

    def test_nested_dataclass_round_trip(self):
        order = Order(
            product=Product(name="Y", price=Decimal("25.50"), tax=Decimal("2.04")),
            quantity=1,
            discount=Decimal("0.00"),
        )
        data = ObjectMapper(order).to_json()
        restored = ObjectMapper(data).to_object(Order)

        assert isinstance(restored.discount, Decimal)
        assert isinstance(restored.product.price, Decimal)
        assert isinstance(restored.product.tax, Decimal)


class TestDecimalInPydantic:
    """Decimal in Pydantic v2 models."""

    def test_serialize(self):
        p = PydanticProduct(name="Widget", price=Decimal("9.99"), tax=Decimal("0.80"))
        result = ObjectMapper(p).to_json()

        assert result["price"] == 9.99
        assert result["tax"] == 0.8

    def test_deserialize(self):
        data = {"name": "Widget", "price": 9.99, "tax": 0.8}
        p = ObjectMapper(data).to_object(PydanticProduct)

        assert isinstance(p.price, Decimal)

    def test_list_of_pydantic_models(self):
        products = [
            PydanticProduct(name="A", price=Decimal("1.50")),
            PydanticProduct(name="B", price=Decimal("2.75")),
            PydanticProduct(name="C", price=Decimal("100.00")),
        ]
        data = ObjectMapper(products).to_json()

        assert len(data) == 3
        assert data[0]["price"] == 1.5
        assert data[1]["price"] == 2.75
        assert data[2]["price"] == 100
        assert isinstance(data[2]["price"], int)

    def test_list_of_pydantic_models_round_trip(self):
        products = [
            PydanticProduct(name="A", price=Decimal("1.50")),
            PydanticProduct(name="B", price=Decimal("2.75")),
        ]
        data = ObjectMapper(products).to_json()
        restored = ObjectMapper(data).to_object(PydanticProduct)

        assert isinstance(restored, list)
        assert len(restored) == 2
        assert all(isinstance(p.price, Decimal) for p in restored)

    def test_nested_pydantic_with_decimal(self):
        order = PydanticOrder(
            items=[
                PydanticProduct(name="X", price=Decimal("10.00")),
                PydanticProduct(name="Y", price=Decimal("20.00")),
            ],
            total=Decimal("30.00"),
        )
        data = ObjectMapper(order).to_json()

        assert data["total"] == 30
        assert data["items"][0]["price"] == 10
        assert data["items"][1]["price"] == 20

    def test_nested_pydantic_round_trip(self):
        order = PydanticOrder(
            items=[PydanticProduct(name="Z", price=Decimal("7.77"))],
            total=Decimal("7.77"),
        )
        data = ObjectMapper(order).to_json()
        restored = ObjectMapper(data).to_object(PydanticOrder)

        assert isinstance(restored.total, Decimal)
        assert isinstance(restored.items[0].price, Decimal)


class TestDecimalInSQLModel:
    """Decimal in SQLModel (table=True and non-table)."""

    def test_table_model_serialize(self):
        p = SQLModelProduct(id=1, name="Widget", price=Decimal("19.99"), tax=Decimal("1.60"))
        result = ObjectMapper(p).to_json()

        assert result["price"] == 19.99
        assert result["tax"] == 1.6

    def test_table_model_deserialize(self):
        data = {"id": 1, "name": "Widget", "price": 19.99, "tax": 1.6}
        p = ObjectMapper(data).to_object(SQLModelProduct)

        assert isinstance(p, SQLModelProduct)
        assert isinstance(p.price, Decimal)
        assert isinstance(p.tax, Decimal)

    def test_table_model_round_trip(self):
        original = SQLModelProduct(id=1, name="X", price=Decimal("99.99"), tax=Decimal("8.00"))
        data = ObjectMapper(original).to_json()
        restored = ObjectMapper(data).to_object(SQLModelProduct)

        assert isinstance(restored.price, Decimal)
        assert isinstance(restored.tax, Decimal)

    def test_non_table_model_serialize(self):
        inv = SQLModelInvoice(
            subtotal=Decimal("100.00"), tax=Decimal("8.00"), total=Decimal("108.00")
        )
        result = ObjectMapper(inv).to_json()

        assert result["subtotal"] == 100
        assert result["tax"] == 8
        assert result["total"] == 108

    def test_non_table_model_deserialize(self):
        data = {"subtotal": 100, "tax": 8, "total": 108}
        inv = ObjectMapper(data).to_object(SQLModelInvoice)

        assert isinstance(inv.subtotal, Decimal)
        assert isinstance(inv.tax, Decimal)
        assert isinstance(inv.total, Decimal)

    def test_list_of_table_models(self):
        products = [
            SQLModelProduct(id=1, name="A", price=Decimal("1.11")),
            SQLModelProduct(id=2, name="B", price=Decimal("2.22")),
        ]
        data = ObjectMapper(products).to_json()

        assert data[0]["price"] == 1.11
        assert data[1]["price"] == 2.22

    def test_list_of_table_models_round_trip(self):
        products = [
            SQLModelProduct(id=1, name="A", price=Decimal("1.11")),
            SQLModelProduct(id=2, name="B", price=Decimal("2.22")),
        ]
        data = ObjectMapper(products).to_json()
        restored = ObjectMapper(data).to_object(SQLModelProduct)

        assert isinstance(restored, list)
        assert len(restored) == 2
        assert all(isinstance(p.price, Decimal) for p in restored)


class TestDecimalInSQLAlchemy:
    """Decimal in SQLAlchemy models."""

    def test_serialize(self):
        p = SAProduct(id=1, name="Widget", price=Decimal("19.99"))
        result = ObjectMapper(p).to_json()

        assert result["price"] == 19.99

    def test_deserialize(self):
        data = {"id": 1, "name": "Widget", "price": 19.99}
        p = ObjectMapper(data).to_object(SAProduct)

        assert isinstance(p, SAProduct)
        assert isinstance(p.price, Decimal)

    def test_round_trip(self):
        original = SAProduct(id=1, name="Gadget", price=Decimal("49.95"))
        data = ObjectMapper(original).to_json()
        restored = ObjectMapper(data).to_object(SAProduct)

        assert isinstance(restored.price, Decimal)

    def test_list_of_models(self):
        products = [
            SAProduct(id=1, name="A", price=Decimal("1.50")),
            SAProduct(id=2, name="B", price=Decimal("2.75")),
        ]
        data = ObjectMapper(products).to_json()

        assert data[0]["price"] == 1.5
        assert data[1]["price"] == 2.75

    def test_list_round_trip(self):
        products = [
            SAProduct(id=1, name="A", price=Decimal("10.00")),
            SAProduct(id=2, name="B", price=Decimal("20.00")),
        ]
        data = ObjectMapper(products).to_json()
        restored = ObjectMapper(data).to_object(SAProduct)

        assert isinstance(restored, list)
        assert all(isinstance(p.price, Decimal) for p in restored)


class TestDecimalInJSON:
    """Decimal deserialization from JSON strings."""

    def test_json_string_to_dataclass(self):
        json_str = '{"name": "Widget", "price": 19.99, "tax": 1.6}'
        p = ObjectMapper(json_str).to_object(Product)

        assert isinstance(p.price, Decimal)
        assert isinstance(p.tax, Decimal)

    def test_json_string_list_to_pydantic(self):
        json_str = '[{"name": "A", "price": 1.5}, {"name": "B", "price": 2.75}]'
        products = ObjectMapper(json_str).to_object(PydanticProduct)

        assert isinstance(products, list)
        assert len(products) == 2
        assert all(isinstance(p.price, Decimal) for p in products)

    def test_json_string_nested(self):
        json_str = '{"items": [{"name": "X", "price": 10.0}], "total": 10.0}'
        order = ObjectMapper(json_str).to_object(PydanticOrder)

        assert isinstance(order.total, Decimal)
        assert isinstance(order.items[0].price, Decimal)
