"""Tests for SQL statement splitting."""

from fixturify.sql_d._strategies._base import SqlExecutionStrategy


class TestSplitSqlStatements:
    """Tests for split_sql_statements static method."""

    def test_simple_split(self):
        sql = "SELECT 1; SELECT 2;"
        result = SqlExecutionStrategy.split_sql_statements(sql)
        assert result == ["SELECT 1", "SELECT 2"]

    def test_no_trailing_semicolon(self):
        sql = "SELECT 1; SELECT 2"
        result = SqlExecutionStrategy.split_sql_statements(sql)
        assert result == ["SELECT 1", "SELECT 2"]

    def test_semicolon_in_single_quoted_string(self):
        sql = "INSERT INTO t VALUES ('a;b;c'); SELECT 1"
        result = SqlExecutionStrategy.split_sql_statements(sql)
        assert result == ["INSERT INTO t VALUES ('a;b;c')", "SELECT 1"]

    def test_escaped_quote_in_string(self):
        sql = "INSERT INTO t VALUES ('it''s a test; really'); SELECT 1"
        result = SqlExecutionStrategy.split_sql_statements(sql)
        assert result == [
            "INSERT INTO t VALUES ('it''s a test; really')",
            "SELECT 1",
        ]

    def test_line_comments_skipped(self):
        sql = "-- setup\nSELECT 1; -- inline\nSELECT 2"
        result = SqlExecutionStrategy.split_sql_statements(sql)
        assert result == ["SELECT 1", "SELECT 2"]

    def test_empty_statements_skipped(self):
        sql = ";;SELECT 1;;;"
        result = SqlExecutionStrategy.split_sql_statements(sql)
        assert result == ["SELECT 1"]

    def test_multiline_statement(self):
        sql = "CREATE TABLE t (\n  id INT,\n  name VARCHAR(100)\n);\nINSERT INTO t VALUES (1, 'test;val')"
        result = SqlExecutionStrategy.split_sql_statements(sql)
        assert len(result) == 2
        assert result[0].startswith("CREATE TABLE")
        assert "'test;val'" in result[1]

    def test_empty_input(self):
        assert SqlExecutionStrategy.split_sql_statements("") == []
        assert SqlExecutionStrategy.split_sql_statements("  ") == []

    def test_only_comments(self):
        assert SqlExecutionStrategy.split_sql_statements("-- comment") == []
