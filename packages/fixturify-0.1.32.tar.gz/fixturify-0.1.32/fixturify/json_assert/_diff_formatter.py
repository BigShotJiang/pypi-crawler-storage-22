"""Diff formatter for human-readable comparison output."""

import sys
from typing import Any, Dict, List, Optional, Set, Union

from deepdiff import DeepDiff


class _DiffFormatter:
    """Formats DeepDiff results into human-readable tables."""

    MAX_VALUE_LENGTH = 50

    @staticmethod
    def format(
        diff: DeepDiff,
        expected_path: str,
        actual_saved_path: str,
        save_failed: bool = False,
    ) -> str:
        """
        Format DeepDiff result into human-readable table format.

        Args:
            diff: DeepDiff result object
            expected_path: Path to expected JSON file
            actual_saved_path: Path where actual JSON was saved
            save_failed: Whether saving the actual file failed

        Returns:
            Formatted string with tables showing all differences
        """
        lines = []

        # Header
        lines.append("=" * 80)
        lines.append("                           JSON COMPARISON FAILED")
        lines.append("=" * 80)
        lines.append("")
        lines.append(f"Expected file: {expected_path}")
        if save_failed:
            lines.append(f"Actual saved:  {actual_saved_path} (SAVE FAILED)")
        else:
            lines.append(f"Actual saved:  {actual_saved_path}")
        lines.append("")
        lines.append("-" * 80)
        lines.append("                              DIFFERENCES SUMMARY")
        lines.append("-" * 80)
        lines.append("")

        # Process different types of differences
        has_content = False

        # Changed values
        if "values_changed" in diff:
            has_content = True
            lines.append(_DiffFormatter._format_changed_values(diff["values_changed"]))
            lines.append("")

        # Items added (extra in actual)
        if "dictionary_item_added" in diff or "iterable_item_added" in diff:
            has_content = True
            added_paths: List[str] = []
            if "dictionary_item_added" in diff:
                added_paths.extend(
                    _DiffFormatter._extract_paths(diff["dictionary_item_added"])
                )
            if "iterable_item_added" in diff:
                added_paths.extend(
                    _DiffFormatter._extract_paths(diff["iterable_item_added"])
                )
            lines.append(_DiffFormatter._format_added_items(added_paths, diff))
            lines.append("")

        # Items removed (missing in actual)
        if "dictionary_item_removed" in diff or "iterable_item_removed" in diff:
            has_content = True
            removed_paths: List[str] = []
            if "dictionary_item_removed" in diff:
                removed_paths.extend(
                    _DiffFormatter._extract_paths(diff["dictionary_item_removed"])
                )
            if "iterable_item_removed" in diff:
                removed_paths.extend(
                    _DiffFormatter._extract_paths(diff["iterable_item_removed"])
                )
            lines.append(_DiffFormatter._format_removed_items(removed_paths, diff))
            lines.append("")

        if not has_content:
            lines.append("No specific differences to display.")
            lines.append("")

        lines.append("=" * 80)

        return "\n".join(lines)

    @staticmethod
    def _extract_paths(items: Union[Set, Dict, Any]) -> List[str]:
        """
        Extract paths from DeepDiff items.

        DeepDiff returns different types depending on version and diff type:
        - Sets of path strings (e.g., SetOrdered(["root['key']"]))
        - Dicts of path -> value
        """
        if items is None:
            return []

        # If it's a dict-like with items(), use keys
        if hasattr(items, "keys"):
            return list(items.keys())

        # If it's iterable (set-like), convert to list
        try:
            return list(items)
        except TypeError:
            return []

    @staticmethod
    def print_diff(formatted_output: str) -> None:
        """
        Print the formatted diff to stderr for test visibility.

        Args:
            formatted_output: The formatted diff string
        """
        print(formatted_output, file=sys.stderr)

    @staticmethod
    def _format_changed_values(changed: Dict[str, Any]) -> str:
        """Format changed values as a table."""
        lines = ["CHANGED VALUES:"]
        lines.append("-" * 70)
        lines.append(f"{'Path':<30} | {'Actual':<18} | {'Expected':<18}")
        lines.append("-" * 70)

        for path, change in changed.items():
            # old_value = expected (from file), new_value = actual (from data)
            expected_val = _DiffFormatter._truncate_value(
                change.get("old_value", change)
            )
            actual_val = _DiffFormatter._truncate_value(change.get("new_value", change))
            path_display = _DiffFormatter._truncate_value(path, 28)
            lines.append(f"{path_display:<30} | {actual_val:<18} | {expected_val:<18}")

        lines.append("-" * 70)
        return "\n".join(lines)


    @staticmethod
    def _format_added_items(paths: List[str], diff: DeepDiff) -> str:
        """Format items that are extra in actual (added)."""
        lines = ["EXTRA IN ACTUAL (found but not expected):"]
        lines.append("-" * 70)
        lines.append(f"{'Path':<30} | {'Actual Value':<38}")
        lines.append("-" * 70)

        for path in paths:
            path_display = _DiffFormatter._truncate_value(path, 28)
            # Try to get the value from DeepDiff if available
            value = _DiffFormatter._get_value_for_path(diff, path, "added")
            val_display = _DiffFormatter._truncate_value(value, 36)
            lines.append(f"{path_display:<30} | {val_display:<38}")

        lines.append("-" * 70)
        return "\n".join(lines)

    @staticmethod
    def _format_removed_items(paths: List[str], diff: DeepDiff) -> str:
        """Format items that are missing in actual (removed)."""
        lines = ["MISSING IN ACTUAL (expected but not found):"]
        lines.append("-" * 70)
        lines.append(f"{'Path':<30} | {'Expected Value':<38}")
        lines.append("-" * 70)

        for path in paths:
            path_display = _DiffFormatter._truncate_value(path, 28)
            # Try to get the value from DeepDiff if available
            value = _DiffFormatter._get_value_for_path(diff, path, "removed")
            val_display = _DiffFormatter._truncate_value(value, 36)
            lines.append(f"{path_display:<30} | {val_display:<38}")

        lines.append("-" * 70)
        return "\n".join(lines)

    # Sentinel value to distinguish "key not found" from "key exists with None value"
    _NOT_FOUND = object()

    @staticmethod
    def _get_value_for_path(diff: DeepDiff, path: str, change_type: str) -> Any:
        """
        Try to extract the actual value for a path from DeepDiff.

        Args:
            diff: The DeepDiff object
            path: The path string (e.g., "root['key']")
            change_type: Either "added" or "removed"

        Returns:
            The value if found (including None), or "<value not available>" placeholder
        """
        # DeepDiff stores values differently depending on version
        # Try to access via the verbose output or tree view
        try:
            # Check if diff has the value stored (depends on DeepDiff version/config)
            if change_type == "added":
                for key in ["dictionary_item_added", "iterable_item_added"]:
                    if key in diff:
                        items = diff[key]
                        # If it's a dict with path->value mapping, check if path exists
                        if hasattr(items, "get") and hasattr(items, "__contains__"):
                            if path in items:
                                return items[
                                    path
                                ]  # Returns the value, even if it's None
            elif change_type == "removed":
                for key in ["dictionary_item_removed", "iterable_item_removed"]:
                    if key in diff:
                        items = diff[key]
                        if hasattr(items, "get") and hasattr(items, "__contains__"):
                            if path in items:
                                return items[
                                    path
                                ]  # Returns the value, even if it's None
        except Exception:
            pass

        return "<value not available>"

    @staticmethod
    def _truncate_value(value: Any, max_length: Optional[int] = None) -> str:
        """Truncate long values for table display."""
        if max_length is None:
            max_length = _DiffFormatter.MAX_VALUE_LENGTH

        str_val = repr(value)
        if len(str_val) > max_length:
            return str_val[: max_length - 3] + "..."
        return str_val
