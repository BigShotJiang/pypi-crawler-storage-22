"""Dataclass serializer."""

from dataclasses import fields, is_dataclass
from typing import Any

from fixturify.object_mapper._serializers._base import CIRCULAR_REF, _BaseSerializer


class _DataclassSerializer(_BaseSerializer):
    """Serializer for dataclass objects."""

    def serialize(self, obj: Any) -> dict[Any, Any]:
        """
        Serialize a dataclass object to a dictionary.

        Args:
            obj: A dataclass instance

        Returns:
            Dictionary representation of the dataclass

        Raises:
            TypeError: If obj is not a dataclass instance
        """
        if not is_dataclass(obj) or isinstance(obj, type):
            raise TypeError(f"Expected a dataclass instance, got {type(obj)}")

        self.reset()
        result: dict[Any, Any] = self._serialize_with_path(obj, "#")
        return result

    def _serialize_object(self, obj: Any, path: str) -> dict:
        """Serialize a dataclass object."""
        # Check if this is a dataclass
        if is_dataclass(obj) and not isinstance(obj, type):
            return self._serialize_dataclass(obj, path)

        # Fall back to base implementation for nested non-dataclass objects
        return super()._serialize_object(obj, path)

    def _serialize_dataclass(self, obj: Any, path: str) -> dict:
        """Serialize a dataclass using its fields."""
        result = {}

        for field in fields(obj):
            field_name = field.name

            # Skip dunder fields (though unlikely in dataclasses)
            if self._is_dunder(field_name):
                continue

            value = getattr(obj, field_name)
            item_path = f"{path}/{field_name}"
            serialized = self._serialize_value(value, item_path)
            if serialized is not CIRCULAR_REF:
                result[field_name] = serialized

        return result
