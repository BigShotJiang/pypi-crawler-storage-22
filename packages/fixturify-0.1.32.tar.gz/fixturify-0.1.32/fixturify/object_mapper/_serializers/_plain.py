"""Plain Python object serializer."""

from typing import Any

from fixturify.object_mapper._serializers._base import CIRCULAR_REF, _BaseSerializer


class _PlainObjectSerializer(_BaseSerializer):
    """Serializer for plain Python objects."""

    def serialize(self, obj: Any) -> dict[Any, Any]:
        """
        Serialize a plain Python object to a dictionary.

        Args:
            obj: A plain Python object with __dict__ or __slots__

        Returns:
            Dictionary representation of the object
        """
        self.reset()
        result: dict[Any, Any] = self._serialize_with_path(obj, "#")
        return result

    def _serialize_object(self, obj: Any, path: str) -> dict:
        """Serialize a plain Python object."""
        result = {}

        # Try to get attributes from __dict__
        if hasattr(obj, "__dict__"):
            for attr_name, value in obj.__dict__.items():
                # Skip dunder attributes
                if self._is_dunder(attr_name):
                    continue
                item_path = f"{path}/{attr_name}"
                serialized = self._serialize_value(value, item_path)
                if serialized is not CIRCULAR_REF:
                    result[attr_name] = serialized

        # Also check __slots__ if present
        if hasattr(type(obj), "__slots__"):
            for slot_name in type(obj).__slots__:
                if self._is_dunder(slot_name):
                    continue
                if slot_name in result:
                    continue  # Already added from __dict__
                if hasattr(obj, slot_name):
                    value = getattr(obj, slot_name)
                    item_path = f"{path}/{slot_name}"
                    serialized = self._serialize_value(value, item_path)
                    if serialized is not CIRCULAR_REF:
                        result[slot_name] = serialized

        return result
