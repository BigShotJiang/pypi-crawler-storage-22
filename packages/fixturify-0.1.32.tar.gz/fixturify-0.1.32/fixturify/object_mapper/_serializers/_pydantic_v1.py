"""Pydantic v1 model serializer."""

from typing import Any

from fixturify.object_mapper._serializers._base import CIRCULAR_REF, _BaseSerializer


class _PydanticV1Serializer(_BaseSerializer):
    """Serializer for Pydantic v1 models."""

    def serialize(self, obj: Any) -> dict[Any, Any]:
        """
        Serialize a Pydantic v1 model to a dictionary.

        Args:
            obj: A Pydantic v1 model instance

        Returns:
            Dictionary representation of the model
        """
        self.reset()
        result: dict[Any, Any] = self._serialize_with_path(obj, "#")
        return result

    def _serialize_object(self, obj: Any, path: str) -> dict:
        """Serialize a Pydantic v1 model."""
        # Check if this is a Pydantic v1 model
        if hasattr(type(obj), "__fields__") and hasattr(type(obj), "schema"):
            return self._serialize_pydantic_v1(obj, path)

        # Fall back to base implementation for nested non-Pydantic objects
        return super()._serialize_object(obj, path)

    def _serialize_pydantic_v1(self, obj: Any, path: str) -> dict:
        """Serialize a Pydantic v1 model using its fields."""
        result = {}

        # Get fields from __fields__
        model_fields = getattr(type(obj), "__fields__", {})

        for field_name in model_fields:
            # Skip dunder fields
            if self._is_dunder(field_name):
                continue

            value = getattr(obj, field_name)
            item_path = f"{path}/{field_name}"
            serialized = self._serialize_value(value, item_path)
            if serialized is not CIRCULAR_REF:
                result[field_name] = serialized

        return result
