"""SQLModel model serializer."""

from typing import Any

from fixturify.object_mapper._serializers._base import CIRCULAR_REF, _BaseSerializer


class _SQLModelSerializer(_BaseSerializer):
    """Serializer for SQLModel models."""

    def serialize(self, obj: Any) -> dict[Any, Any]:
        """
        Serialize a SQLModel model to a dictionary.

        SQLModel combines Pydantic v2 and SQLAlchemy, so we use
        Pydantic's model_fields for serialization.

        Args:
            obj: A SQLModel model instance

        Returns:
            Dictionary representation of the model
        """
        self.reset()
        result: dict[Any, Any] = self._serialize_with_path(obj, "#")
        return result

    def _serialize_object(self, obj: Any, path: str) -> dict:
        """Serialize a SQLModel model."""
        obj_type = type(obj)

        # Check if this is a SQLModel model (has both __tablename__ and model_fields)
        if hasattr(obj_type, "__tablename__") and hasattr(obj_type, "model_fields"):
            return self._serialize_sqlmodel(obj, path)

        # Fall back to base implementation for nested non-SQLModel objects
        return super()._serialize_object(obj, path)

    def _serialize_sqlmodel(self, obj: Any, path: str) -> dict:
        """Serialize a SQLModel using its model_fields (Pydantic v2 style)."""
        result = {}

        # Get fields from model_fields (Pydantic v2)
        model_fields = getattr(type(obj), "model_fields", {})

        for field_name in model_fields:
            if self._is_dunder(field_name):
                continue

            value = getattr(obj, field_name)
            item_path = f"{path}/{field_name}"
            serialized = self._serialize_value(value, item_path)
            if serialized is not CIRCULAR_REF:
                result[field_name] = serialized

        # Handle relationships via SQLAlchemy mapper (if table model)
        mapper = getattr(type(obj), "__mapper__", None)
        if mapper is not None:
            for relationship in mapper.relationships:
                rel_name = relationship.key
                if self._is_dunder(rel_name):
                    continue
                # Only serialize if the relationship is loaded
                if rel_name in obj.__dict__:
                    value = getattr(obj, rel_name, None)
                    item_path = f"{path}/{rel_name}"
                    serialized = self._serialize_value(value, item_path)
                    if serialized is not CIRCULAR_REF:
                        result[rel_name] = serialized

        return result
