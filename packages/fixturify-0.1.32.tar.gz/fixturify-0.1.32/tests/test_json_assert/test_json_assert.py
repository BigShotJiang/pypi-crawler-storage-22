"""Tests for JsonAssert class."""

import pytest
import json
from dataclasses import dataclass
from enum import Enum
from pathlib import Path

from fixturify.json_assert import JsonAssert


class Status(Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"


class Priority(Enum):
    LOW = 1
    MEDIUM = 2
    HIGH = 3


@dataclass
class User:
    name: str
    age: int


@dataclass
class UserWithId:
    name: str
    age: int
    id: int


@dataclass
class Profile:
    age: int
    city: str


@dataclass
class UserWithProfile:
    name: str
    profile: Profile


class TestJsonAssertBasic:
    """Basic tests for JsonAssert."""

    def test_should_create_json_file(self):
        data = {"name": "John", "age": 30}
        fixture_path = Path(__file__).parent / "fixtures" / "created-file.json"

        # Ensure file doesn't exist before test
        if fixture_path.exists():
            fixture_path.unlink()

        JsonAssert(data).compare_to_file("./fixtures/created-file.json")

        # Read created-file, check if contains content from data
        assert fixture_path.exists(), "Fixture file was not created"

        actual_content = json.loads(fixture_path.read_text())
        assert actual_content == data, f"Content mismatch: expected {data}, got {actual_content}"

        # Clean up - remove the created file
        fixture_path.unlink()

    def test_dict_matches_file(self):
        """Test that matching dict passes."""
        data = {"name": "John", "age": 30}
        JsonAssert(data).compare_to_file("./fixtures/user.json")

    def test_dataclass_matches_file(self):
        """Test that matching dataclass passes."""
        user = User(name="John", age=30)
        JsonAssert(user).compare_to_file("./fixtures/user.json")

    def test_json_string_matches_file(self):
        """Test that matching JSON string passes."""
        json_str = '{"name": "John", "age": 30}'
        JsonAssert(json_str).compare_to_file("./fixtures/user.json")

    def test_list_matches_file(self):
        """Test that matching list passes."""
        users = [
            {"name": "John", "age": 30, "id": 1},
            {"name": "Jane", "age": 25, "id": 2},
        ]
        JsonAssert(users).compare_to_file("./fixtures/users.json")

    def test_mismatch_raises_assertion_error(self):
        """Test that mismatched data raises AssertionError."""
        data = {"name": "Jane", "age": 25}  # Different from expected

        with pytest.raises(AssertionError) as exc_info:
            JsonAssert(data).compare_to_file("./fixtures/user.json")

        assert "JSON COMPARISON FAILED" in str(exc_info.value)


class TestJsonAssertIgnore:
    """Tests for ignore() method."""

    def test_ignore_simple_field(self):
        """Test ignoring a simple top-level field."""
        data = {"name": "John", "age": 99}  # age is different

        JsonAssert(data).ignore("age").compare_to_file("./fixtures/user.json")

    def test_ignore_with_root_prefix(self):
        """Test ignoring with explicit root prefix."""
        data = {"name": "John", "age": 99}

        JsonAssert(data).ignore("root['age']").compare_to_file("./fixtures/user.json")

    def test_ignore_nested_field(self):
        """Test ignoring a nested field."""
        data = {
            "user": {
                "name": "John",
                "profile": {
                    "age": 99,  # Different
                    "city": "NYC",
                },
            },
            "tags": ["python", "testing"],
        }

        JsonAssert(data).ignore("user.profile.age").compare_to_file(
            "./fixtures/nested.json"
        )

    def test_ignore_multiple_fields(self):
        """Test ignoring multiple fields."""
        data = {"name": "Different", "age": 99}

        JsonAssert(data).ignore("name", "age").compare_to_file("./fixtures/user.json")

    def test_ignore_wildcard_in_list(self):
        """Test ignoring a field in all list items using wildcard."""
        users = [
            {"name": "John", "age": 30, "id": 999},  # id is different
            {"name": "Jane", "age": 25, "id": 888},  # id is different
        ]

        JsonAssert(users).ignore("root[*]['id']").compare_to_file(
            "./fixtures/users.json"
        )

    def test_ignore_accumulates(self):
        """Test that multiple ignore() calls accumulate."""
        data = {"name": "Different", "age": 99}

        JsonAssert(data).ignore("name").ignore("age").compare_to_file(
            "./fixtures/user.json"
        )


class TestJsonAssertIgnoreRegex:
    """Tests for ignore_regex() method."""

    def test_ignore_regex_pattern(self):
        """Test ignoring with regex pattern."""
        users = [
            {"name": "John", "age": 30, "id": 999},
            {"name": "Jane", "age": 25, "id": 888},
        ]

        # Ignore 'id' in any list item
        JsonAssert(users).ignore_regex(r"root\[\d+\]\['id'\]").compare_to_file(
            "./fixtures/users.json"
        )

    def test_ignore_regex_accumulates(self):
        """Test that multiple ignore_regex() calls accumulate."""
        users = [
            {"name": "JOHN", "age": 30, "id": 999},  # name uppercase, id different
            {"name": "JANE", "age": 25, "id": 888},
        ]

        JsonAssert(users).ignore_regex(r"root\[\d+\]\['id'\]").ignore_regex(
            r"root\[\d+\]\['name'\]"
        ).compare_to_file("./fixtures/users.json")


class TestJsonAssertOptions:
    """Tests for options() method."""

    def test_ignore_order(self):
        """Test ignoring list order."""
        data = {"tags": ["c", "b", "a"]}  # Different order

        JsonAssert(data).options(ignore_order=True).compare_to_file(
            "./fixtures/unordered_list.json"
        )

    def test_numeric_tolerance(self):
        """Test numeric tolerance for float comparison."""
        data = {"value": 3.14}  # Slightly different

        JsonAssert(data).options(numeric_tolerance=0.01).compare_to_file(
            "./fixtures/float_values.json"
        )

    def test_options_accumulate(self):
        """Test that multiple options() calls accumulate."""
        data = {"tags": ["c", "b", "a"]}

        JsonAssert(data).options(ignore_order=True).options().compare_to_file(
            "./fixtures/unordered_list.json"
        )


class TestJsonAssertCombined:
    """Tests for combining ignore and options."""

    def test_ignore_and_options_combined(self):
        """Test combining ignore() and options()."""
        users = [
            {"name": "John", "age": 30, "id": 999},
            {"name": "Jane", "age": 25, "id": 888},
        ]

        # Ignore id and allow any order
        JsonAssert(users).ignore("root[*]['id']").options(
            ignore_order=True
        ).compare_to_file("./fixtures/users.json")


class TestJsonAssertErrors:
    """Tests for error handling."""

    def test_file_not_found_creates_file(self):
        """Test that missing expected file is created with actual data."""
        data = {"name": "John"}
        fixture_path = Path(__file__).parent / "fixtures" / "nonexistent.json"

        # Ensure file doesn't exist before test
        if fixture_path.exists():
            fixture_path.unlink()

        JsonAssert(data).compare_to_file("./fixtures/nonexistent.json")

        # Verify file was created with correct content
        assert fixture_path.exists()
        actual_content = json.loads(fixture_path.read_text())
        assert actual_content == data

        # Clean up
        fixture_path.unlink()

    def test_invalid_json_file_raises_error(self, tmp_path: Path):
        """Test that invalid JSON file raises ValueError."""
        # Create invalid JSON file
        invalid_file = tmp_path / "invalid.json"
        invalid_file.write_text("{invalid json}")

        data = {"name": "John"}

        with pytest.raises(ValueError) as exc_info:
            # Need to use absolute path since compare_to_file uses caller location
            JsonAssert(data).compare_to_file(str(invalid_file))

        assert "Invalid JSON" in str(exc_info.value)


class TestJsonAssertActualSaving:
    """Tests for actual JSON saving on failure."""

    def test_actual_saved_on_failure(self, tmp_path: Path):
        """Test that actual JSON is saved to ACTUAL folder on failure."""
        # Create expected file
        expected_file = tmp_path / "expected.json"
        expected_file.write_text('{"name": "John", "age": 30}')

        data = {"name": "Jane", "age": 25}  # Different

        with pytest.raises(AssertionError):
            JsonAssert(data).compare_to_file(str(expected_file))

        # Check that ACTUAL file was created
        actual_file = tmp_path / "ACTUAL" / "expected.json"
        assert actual_file.exists()

        # Verify content
        actual_content = json.loads(actual_file.read_text())
        assert actual_content == {"name": "Jane", "age": 25}


class TestJsonAssertWithDataclasses:
    """Tests for JsonAssert with dataclass objects."""

    def test_dataclass_with_nested_object(self):
        """Test comparing nested dataclass."""
        user = UserWithProfile(name="John", profile=Profile(age=30, city="NYC"))

        # This should fail because structure is different
        with pytest.raises(AssertionError):
            JsonAssert(user).compare_to_file("./fixtures/nested.json")

    def test_list_of_dataclasses(self):
        """Test comparing list of dataclasses."""
        users = [
            UserWithId(name="John", age=30, id=1),
            UserWithId(name="Jane", age=25, id=2),
        ]

        JsonAssert(users).compare_to_file("./fixtures/users.json")


class TestJsonAssertEnums:
    """Tests for enum handling in JsonAssert."""

    def test_dict_with_string_enum_matches_file(self):
        data = {"name": "John", "age": 30, "status": Status.ACTIVE, "priority": 3}
        JsonAssert(data).compare_to_file("./fixtures/user_with_status.json")

    def test_dict_with_int_enum_matches_file(self):
        data = {"name": "John", "age": 30, "status": "active", "priority": Priority.HIGH}
        JsonAssert(data).compare_to_file("./fixtures/user_with_status.json")

    def test_dict_with_both_enums_matches_file(self):
        data = {
            "name": "John",
            "age": 30,
            "status": Status.ACTIVE,
            "priority": Priority.HIGH,
        }
        JsonAssert(data).compare_to_file("./fixtures/user_with_status.json")

    def test_enum_mismatch_raises_error(self):
        data = {
            "name": "John",
            "age": 30,
            "status": Status.INACTIVE,
            "priority": Priority.HIGH,
        }
        with pytest.raises(AssertionError) as exc_info:
            JsonAssert(data).compare_to_file("./fixtures/user_with_status.json")

        assert "CHANGED VALUES" in str(exc_info.value)

    def test_enum_with_ignore(self):
        data = {
            "name": "John",
            "age": 30,
            "status": Status.INACTIVE,
            "priority": Priority.LOW,
        }
        JsonAssert(data).ignore("status", "priority").compare_to_file(
            "./fixtures/user_with_status.json"
        )

    def test_actual_saved_with_enums(self, tmp_path: Path):
        """Test that ACTUAL folder saves enums as their values."""
        expected_file = tmp_path / "expected.json"
        expected_file.write_text('{"status": "inactive", "priority": 1}')

        data = {"status": Status.ACTIVE, "priority": Priority.HIGH}

        with pytest.raises(AssertionError):
            JsonAssert(data).compare_to_file(str(expected_file))

        actual_file = tmp_path / "ACTUAL" / "expected.json"
        assert actual_file.exists()

        content = json.loads(actual_file.read_text())
        assert content["status"] == "active"
        assert content["priority"] == 3
