"""Dataclass deserializer."""

from dataclasses import fields, is_dataclass, MISSING
from typing import Any, Type, TypeVar

from fixturify.object_mapper._deserializers._base import _BaseDeserializer, _NO_DEFAULT

T = TypeVar("T")


class _DataclassDeserializer(_BaseDeserializer):
    """Deserializer for dataclass objects."""

    def deserialize(self, data: dict, target_class: Type[T]) -> T:
        """
        Deserialize a dictionary to a dataclass.

        For fields missing from JSON that have no default, provides
        type-appropriate defaults.

        Args:
            data: Dictionary data to deserialize
            target_class: The dataclass to create an instance of

        Returns:
            Instance of target_class

        Raises:
            TypeError: If target_class is not a dataclass
        """
        if not is_dataclass(target_class):
            raise TypeError(f"Expected a dataclass, got {target_class}")

        # Get type hints for field type information
        type_hints = self._get_type_hints(target_class)

        # Build kwargs for dataclass constructor
        kwargs = {}
        dc_fields = fields(target_class)
        dataclass_field_names = {f.name for f in dc_fields}

        for field_name in dataclass_field_names:
            if field_name in data:
                value = data[field_name]
                target_type = type_hints.get(field_name, Any)
                kwargs[field_name] = self._convert_value(value, target_type)

        # Fill missing fields that have no default with type-based defaults
        for f in dc_fields:
            if f.name not in data and f.default is MISSING and f.default_factory is MISSING:
                target_type = type_hints.get(f.name, Any)
                default = self._get_type_default(target_type)
                if default is not _NO_DEFAULT:
                    kwargs[f.name] = default

        return target_class(**kwargs)

    def _deserialize_nested(self, data: dict, target_class: Type[T]) -> T:
        """Deserialize a nested object."""
        if is_dataclass(target_class):
            return self.deserialize(data, target_class)

        # For non-dataclass nested objects, try basic instantiation
        return target_class(**data)
