"""Pydantic v1 model deserializer."""

from typing import Any, Type, TypeVar

from fixturify.object_mapper._deserializers._base import _BaseDeserializer, _NO_DEFAULT

T = TypeVar("T")


class _PydanticV1Deserializer(_BaseDeserializer):
    """Deserializer for Pydantic v1 models."""

    def deserialize(self, data: dict, target_class: Type[T]) -> T:
        """
        Deserialize a dictionary to a Pydantic v1 model.

        Pydantic v1 models accept dict data directly in their constructor
        and handle validation/coercion internally. Missing fields that have
        no default get type-appropriate defaults.

        Args:
            data: Dictionary data to deserialize
            target_class: The Pydantic v1 model class

        Returns:
            Instance of target_class
        """
        type_hints = self._get_type_hints(target_class)
        filled_data = dict(data)
        for field_name in getattr(target_class, "__fields__", {}):
            if field_name not in filled_data:
                target_type = type_hints.get(field_name, Any)
                default = self._get_type_default(target_type)
                if default is not _NO_DEFAULT:
                    filled_data[field_name] = default
        return target_class(**filled_data)

    def _deserialize_nested(self, data: dict, target_class: Type[T]) -> T:
        """Deserialize a nested Pydantic v1 model."""
        # Check if it's a Pydantic v1 model
        if hasattr(target_class, "__fields__") and hasattr(target_class, "schema"):
            return self.deserialize(data, target_class)

        # For non-Pydantic nested objects, try basic instantiation
        return target_class(**data)
