"""Pydantic v2 model deserializer."""

from typing import Any, Type, TypeVar

from fixturify.object_mapper._deserializers._base import _BaseDeserializer, _NO_DEFAULT

T = TypeVar("T")


class _PydanticV2Deserializer(_BaseDeserializer):
    """Deserializer for Pydantic v2 models."""

    def deserialize(self, data: dict, target_class: Type[T]) -> T:
        """
        Deserialize a dictionary to a Pydantic v2 model.

        Pydantic v2 models accept dict data directly in their constructor
        and handle validation/coercion internally. Missing fields that have
        no default get type-appropriate defaults.

        Args:
            data: Dictionary data to deserialize
            target_class: The Pydantic v2 model class

        Returns:
            Instance of target_class
        """
        filled_data = self._fill_missing_pydantic_v2(data, target_class)

        # Pydantic v2 has model_validate for dict -> model conversion
        if hasattr(target_class, "model_validate"):
            return target_class.model_validate(filled_data)  # type: ignore[attr-defined, no-any-return]

        # Fallback to constructor
        return target_class(**filled_data)

    def _fill_missing_pydantic_v2(self, data: dict, target_class: Type) -> dict:
        """Fill missing model_fields with type-appropriate defaults."""
        model_fields = getattr(target_class, "model_fields", None)
        if not model_fields:
            return data
        type_hints = self._get_type_hints(target_class)
        filled_data = dict(data)
        for field_name in model_fields:
            if field_name not in filled_data:
                target_type = type_hints.get(field_name, Any)
                default = self._get_type_default(target_type)
                if default is not _NO_DEFAULT:
                    filled_data[field_name] = default
        return filled_data

    def _deserialize_nested(self, data: dict, target_class: Type[T]) -> T:
        """Deserialize a nested Pydantic v2 model."""
        # Check if it's a Pydantic v2 model
        if hasattr(target_class, "model_fields"):
            return self.deserialize(data, target_class)

        # For non-Pydantic nested objects, try basic instantiation
        return target_class(**data)
