"""SQLModel model deserializer."""

from typing import Any, Type, TypeVar

from fixturify.object_mapper._deserializers._base import _BaseDeserializer, _NO_DEFAULT

T = TypeVar("T")


class _SQLModelDeserializer(_BaseDeserializer):
    """Deserializer for SQLModel models."""

    def deserialize(self, data: dict, target_class: Type[T]) -> T:
        """
        Deserialize a dictionary to a SQLModel model.

        SQLModel combines Pydantic v2 and SQLAlchemy. For non-table models,
        Pydantic's model_validate handles everything including nested objects.
        For table models, Relationship fields are not in model_fields, so we
        must handle them separately via the SQLAlchemy mapper.

        Missing fields get type-appropriate defaults.

        Args:
            data: Dictionary data to deserialize
            target_class: The SQLModel model class

        Returns:
            Instance of target_class
        """
        if not hasattr(target_class, "model_validate"):
            return target_class(**data)

        mapper = getattr(target_class, "__mapper__", None)
        if mapper is None:
            # Non-table SQLModel — fill missing fields, then Pydantic handles nested objects
            filled_data = self._fill_missing_model_fields(data, target_class)
            return target_class.model_validate(filled_data)  # type: ignore[attr-defined, no-any-return]

        # Table model: separate column data from relationship data
        rel_keys = {r.key for r in mapper.relationships}
        column_data = {k: v for k, v in data.items() if k not in rel_keys}

        # Fill missing column fields with type-based defaults
        column_data = self._fill_missing_model_fields(column_data, target_class)

        instance = target_class.model_validate(column_data)  # type: ignore[attr-defined]

        # Deserialize relationships
        for relationship in mapper.relationships:
            rel_name = relationship.key
            if rel_name in data:
                rel_data = data[rel_name]
                rel_class = relationship.mapper.class_

                if isinstance(rel_data, list):
                    rel_instances = [
                        self._deserialize_nested(item, rel_class)
                        for item in rel_data
                    ]
                    setattr(instance, rel_name, rel_instances)
                elif isinstance(rel_data, dict):
                    rel_instance = self._deserialize_nested(rel_data, rel_class)
                    setattr(instance, rel_name, rel_instance)

        return instance  # type: ignore[no-any-return]

    def _fill_missing_model_fields(self, data: dict, target_class: Type) -> dict:
        """Fill missing model_fields with type-appropriate defaults."""
        model_fields = getattr(target_class, "model_fields", None)
        if not model_fields:
            return data
        type_hints = self._get_type_hints(target_class)
        filled_data = dict(data)
        for field_name in model_fields:
            if field_name not in filled_data:
                target_type = type_hints.get(field_name, Any)
                default = self._get_type_default(target_type)
                if default is not _NO_DEFAULT:
                    filled_data[field_name] = default
        return filled_data

    def _deserialize_nested(self, data: dict, target_class: Type[T]) -> T:
        """Deserialize a nested SQLModel model."""
        # Check if it's a SQLModel model
        if hasattr(target_class, "__tablename__") and hasattr(
            target_class, "model_fields"
        ):
            return self.deserialize(data, target_class)

        # For non-SQLModel nested objects, try basic instantiation
        return target_class(**data)
