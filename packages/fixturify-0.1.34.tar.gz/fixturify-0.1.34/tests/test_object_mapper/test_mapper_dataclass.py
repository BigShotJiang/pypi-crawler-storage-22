"""Tests for ObjectMapper with dataclasses."""

from dataclasses import dataclass
from datetime import datetime
from typing import List, Optional
from enum import Enum

from fixturify.object_mapper import ObjectMapper


class Status(Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"


@dataclass
class SimpleUser:
    name: str
    age: int


@dataclass
class Address:
    city: str
    country: str


@dataclass
class UserWithAddress:
    name: str
    address: Address


@dataclass
class UserWithOptional:
    name: str
    email: Optional[str] = None


@dataclass
class UserWithList:
    name: str
    tags: List[str]


@dataclass
class Company:
    name: str
    employees: List[SimpleUser]


@dataclass
class UserWithDatetime:
    name: str
    created_at: datetime


@dataclass
class UserWithStatus:
    name: str
    status: Status


@dataclass
class UserWithMissingFields:
    name: str
    tags: List[str]
    nickname: Optional[str]


class TestDataclassMissingFieldDefaults:
    """Tests that missing dataclass fields get type-appropriate defaults."""

    def test_missing_list_gets_empty_list(self):
        data = {"name": "John"}
        user = ObjectMapper(data).to_object(UserWithMissingFields)
        assert user.tags == []

    def test_missing_optional_gets_none(self):
        data = {"name": "John"}
        user = ObjectMapper(data).to_object(UserWithMissingFields)
        assert user.nickname is None

    def test_missing_scalar_not_filled(self):
        """Scalar types (str, int, float, bool) are not defaulted for missing fields."""
        data = {"tags": ["a"], "nickname": "J"}
        # str has no type default, so dataclass __init__ will raise TypeError
        # unless str is provided
        import pytest
        with pytest.raises(TypeError):
            ObjectMapper(data).to_object(UserWithMissingFields)

    def test_present_fields_not_overwritten(self):
        data = {"name": "John", "tags": ["x"], "nickname": "J"}
        user = ObjectMapper(data).to_object(UserWithMissingFields)
        assert user.name == "John"
        assert user.tags == ["x"]
        assert user.nickname == "J"

    def test_fields_with_existing_defaults_not_affected(self):
        """Fields with dataclass defaults should still use those defaults."""
        data = {"name": "John"}
        user = ObjectMapper(data).to_object(UserWithOptional)
        assert user.email is None


class TestDataclassSerialization:
    """Tests for serializing dataclasses to JSON."""

    def test_simple_dataclass_to_json(self):
        """Test serializing a simple dataclass."""
        user = SimpleUser(name="John", age=30)
        data = ObjectMapper(user).to_json()

        assert data == {"name": "John", "age": 30}

    def test_nested_dataclass_to_json(self):
        """Test serializing nested dataclasses."""
        user = UserWithAddress(name="John", address=Address(city="NYC", country="USA"))
        data = ObjectMapper(user).to_json()

        assert data == {"name": "John", "address": {"city": "NYC", "country": "USA"}}

    def test_dataclass_with_none_to_json(self):
        """Test that None values are serialized as null."""
        user = UserWithOptional(name="John", email=None)
        data = ObjectMapper(user).to_json()

        assert data == {"name": "John", "email": None}

    def test_dataclass_with_list_to_json(self):
        """Test serializing dataclass with list."""
        user = UserWithList(name="John", tags=["python", "testing"])
        data = ObjectMapper(user).to_json()

        assert data == {"name": "John", "tags": ["python", "testing"]}

    def test_dataclass_with_nested_list_to_json(self):
        """Test serializing dataclass with list of dataclasses."""
        company = Company(
            name="Acme",
            employees=[
                SimpleUser(name="John", age=30),
                SimpleUser(name="Jane", age=25),
            ],
        )
        data = ObjectMapper(company).to_json()

        assert data == {
            "name": "Acme",
            "employees": [{"name": "John", "age": 30}, {"name": "Jane", "age": 25}],
        }

    def test_dataclass_with_datetime_to_json(self):
        """Test serializing dataclass with datetime."""
        dt = datetime(2024, 1, 15, 10, 30, 0)
        user = UserWithDatetime(name="John", created_at=dt)
        data = ObjectMapper(user).to_json()

        assert data == {"name": "John", "created_at": "2024-01-15T10:30:00"}

    def test_dataclass_with_enum_to_json(self):
        """Test serializing dataclass with enum."""
        user = UserWithStatus(name="John", status=Status.ACTIVE)
        data = ObjectMapper(user).to_json()

        assert data == {"name": "John", "status": "active"}

    def test_list_of_dataclasses_to_json(self):
        """Test serializing a list of dataclasses."""
        users = [SimpleUser(name="John", age=30), SimpleUser(name="Jane", age=25)]
        data = ObjectMapper(users).to_json()

        assert data == [{"name": "John", "age": 30}, {"name": "Jane", "age": 25}]


class TestDataclassDeserialization:
    """Tests for deserializing JSON to dataclasses."""

    def test_json_to_simple_dataclass(self):
        """Test deserializing JSON to simple dataclass."""
        json_str = '{"name": "John", "age": 30}'
        user = ObjectMapper(json_str).to_object(SimpleUser)

        assert isinstance(user, SimpleUser)
        assert user.name == "John"
        assert user.age == 30

    def test_dict_to_simple_dataclass(self):
        """Test deserializing dict to simple dataclass."""
        data = {"name": "John", "age": 30}
        user = ObjectMapper(data).to_object(SimpleUser)

        assert isinstance(user, SimpleUser)
        assert user.name == "John"
        assert user.age == 30

    def test_json_to_nested_dataclass(self):
        """Test deserializing JSON to nested dataclass."""
        json_str = '{"name": "John", "address": {"city": "NYC", "country": "USA"}}'
        user = ObjectMapper(json_str).to_object(UserWithAddress)

        assert isinstance(user, UserWithAddress)
        assert user.name == "John"
        assert isinstance(user.address, Address)
        assert user.address.city == "NYC"
        assert user.address.country == "USA"

    def test_json_to_dataclass_with_list(self):
        """Test deserializing JSON with list to dataclass."""
        json_str = '{"name": "John", "tags": ["python", "testing"]}'
        user = ObjectMapper(json_str).to_object(UserWithList)

        assert isinstance(user, UserWithList)
        assert user.name == "John"
        assert user.tags == ["python", "testing"]

    def test_json_to_dataclass_with_nested_list(self):
        """Test deserializing JSON with nested list of objects."""
        json_str = """
        {
            "name": "Acme",
            "employees": [
                {"name": "John", "age": 30},
                {"name": "Jane", "age": 25}
            ]
        }
        """
        company = ObjectMapper(json_str).to_object(Company)

        assert isinstance(company, Company)
        assert company.name == "Acme"
        assert len(company.employees) == 2
        assert all(isinstance(e, SimpleUser) for e in company.employees)
        assert company.employees[0].name == "John"
        assert company.employees[1].name == "Jane"

    def test_json_list_to_dataclass_list(self):
        """Test deserializing JSON array to list of dataclasses."""
        json_str = '[{"name": "John", "age": 30}, {"name": "Jane", "age": 25}]'
        users = ObjectMapper(json_str).to_object(SimpleUser)

        assert isinstance(users, list)
        assert len(users) == 2
        assert all(isinstance(u, SimpleUser) for u in users)
        assert users[0].name == "John"
        assert users[1].name == "Jane"

    def test_json_to_dataclass_with_datetime(self):
        """Test deserializing JSON with datetime string."""
        json_str = '{"name": "John", "created_at": "2024-01-15T10:30:00"}'
        user = ObjectMapper(json_str).to_object(UserWithDatetime)

        assert isinstance(user, UserWithDatetime)
        assert user.name == "John"
        assert isinstance(user.created_at, datetime)
        assert user.created_at == datetime(2024, 1, 15, 10, 30, 0)

    def test_json_to_dataclass_with_enum(self):
        """Test deserializing JSON with enum value."""
        json_str = '{"name": "John", "status": "active"}'
        user = ObjectMapper(json_str).to_object(UserWithStatus)

        assert isinstance(user, UserWithStatus)
        assert user.name == "John"
        assert user.status == Status.ACTIVE


class TestRoundTrip:
    """Test serialization/deserialization round trips."""

    def test_simple_round_trip(self):
        """Test round trip for simple dataclass."""
        original = SimpleUser(name="John", age=30)
        data = ObjectMapper(original).to_json()
        restored = ObjectMapper(data).to_object(SimpleUser)

        assert restored.name == original.name
        assert restored.age == original.age

    def test_nested_round_trip(self):
        """Test round trip for nested dataclass."""
        original = UserWithAddress(
            name="John", address=Address(city="NYC", country="USA")
        )
        data = ObjectMapper(original).to_json()
        restored = ObjectMapper(data).to_object(UserWithAddress)

        assert restored.name == original.name
        assert restored.address.city == original.address.city
        assert restored.address.country == original.address.country

    def test_list_round_trip(self):
        """Test round trip for list of dataclasses."""
        original = [SimpleUser(name="John", age=30), SimpleUser(name="Jane", age=25)]
        data = ObjectMapper(original).to_json()
        restored = ObjectMapper(data).to_object(SimpleUser)

        assert len(restored) == len(original)
        for orig, rest in zip(original, restored):
            assert rest.name == orig.name
            assert rest.age == orig.age
