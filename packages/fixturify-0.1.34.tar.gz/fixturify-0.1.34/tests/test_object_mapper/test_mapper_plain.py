"""Tests for ObjectMapper with plain Python objects."""

from typing import Dict, List, Optional, Set, Tuple

from fixturify.object_mapper import ObjectMapper


class SimplePerson:
    """A simple plain Python class."""

    def __init__(self, name: str, age: int):
        self.name = name
        self.age = age


class PersonWithOptional:
    """A class with optional attributes."""

    def __init__(self, name: str, email: Optional[str] = None):
        self.name = name
        self.email = email


class PersonWithPrivate:
    """A class with private attributes."""

    def __init__(self, name: str, internal_id: str):
        self.name = name
        self._internal_id = internal_id  # Single underscore - should be serialized


class Address:
    """Address class for nested testing."""

    def __init__(self, city: str, country: str):
        self.city = city
        self.country = country


class PersonWithAddress:
    """A class with nested object."""

    def __init__(self, name: str, address: Address):
        self.name = name
        self.address = address


class ItemWithDefaults:
    """A class with various typed fields for testing missing-field defaults."""

    def __init__(self):
        pass

    name: str
    tags: list
    typed_tags: List[str]
    metadata: dict
    typed_metadata: Dict[str, int]
    ids: set
    typed_ids: Set[int]
    coords: tuple
    typed_coords: Tuple[float, ...]
    count: int
    score: float
    active: bool
    nickname: Optional[str]


class ItemWithNoInitKwargs:
    """A class whose __init__ doesn't accept kwargs — uses __new__ path."""

    name: str
    items: List[str]
    value: int
    label: Optional[str]


class TestPlainObjectMissingFieldDefaults:
    """Tests that missing annotated fields get type-appropriate defaults."""

    def test_missing_list_gets_empty_list(self):
        data = {"name": "test"}
        obj = ObjectMapper(data).to_object(ItemWithDefaults)
        assert obj.tags == []
        assert obj.typed_tags == []

    def test_missing_dict_gets_empty_dict(self):
        data = {"name": "test"}
        obj = ObjectMapper(data).to_object(ItemWithDefaults)
        assert obj.metadata == {}
        assert obj.typed_metadata == {}

    def test_missing_set_gets_empty_set(self):
        data = {"name": "test"}
        obj = ObjectMapper(data).to_object(ItemWithDefaults)
        assert obj.ids == set()
        assert obj.typed_ids == set()

    def test_missing_tuple_gets_empty_tuple(self):
        data = {"name": "test"}
        obj = ObjectMapper(data).to_object(ItemWithDefaults)
        assert obj.coords == ()
        assert obj.typed_coords == ()

    def test_missing_scalar_not_set(self):
        """Scalar types (str, int, float, bool) are not defaulted — field stays unset."""
        data = {"tags": []}
        obj = ObjectMapper(data).to_object(ItemWithDefaults)
        assert not hasattr(obj, "name")
        assert not hasattr(obj, "count")
        assert not hasattr(obj, "score")
        assert not hasattr(obj, "active")

    def test_missing_optional_gets_none(self):
        data = {"name": "test"}
        obj = ObjectMapper(data).to_object(ItemWithDefaults)
        assert obj.nickname is None

    def test_present_fields_not_overwritten(self):
        data = {"name": "hello", "count": 42, "tags": ["a", "b"]}
        obj = ObjectMapper(data).to_object(ItemWithDefaults)
        assert obj.name == "hello"
        assert obj.count == 42
        assert obj.tags == ["a", "b"]

    def test_new_path_missing_fields_filled(self):
        data = {"name": "test"}
        obj = ObjectMapper(data).to_object(ItemWithNoInitKwargs)
        assert obj.name == "test"
        assert obj.items == []
        assert not hasattr(obj, "value")
        assert obj.label is None


class TestPlainObjectSerialization:
    """Tests for serializing plain Python objects."""

    def test_simple_object_to_json(self):
        """Test serializing a simple plain object."""
        person = SimplePerson(name="John", age=30)
        data = ObjectMapper(person).to_json()

        assert data == {"name": "John", "age": 30}

    def test_object_with_none_to_json(self):
        """Test that None values are serialized."""
        person = PersonWithOptional(name="John", email=None)
        data = ObjectMapper(person).to_json()

        assert data == {"name": "John", "email": None}

    def test_object_with_single_underscore_to_json(self):
        """Test that single underscore attributes ARE serialized."""
        person = PersonWithPrivate(name="John", internal_id="abc123")
        data = ObjectMapper(person).to_json()

        assert "name" in data
        assert "_internal_id" in data
        assert data["_internal_id"] == "abc123"

    def test_nested_object_to_json(self):
        """Test serializing nested plain objects."""
        person = PersonWithAddress(
            name="John", address=Address(city="NYC", country="USA")
        )
        data = ObjectMapper(person).to_json()

        assert data == {"name": "John", "address": {"city": "NYC", "country": "USA"}}

    def test_list_of_objects_to_json(self):
        """Test serializing a list of plain objects."""
        people = [SimplePerson(name="John", age=30), SimplePerson(name="Jane", age=25)]
        data = ObjectMapper(people).to_json()

        assert data == [{"name": "John", "age": 30}, {"name": "Jane", "age": 25}]


class TestPlainObjectDeserialization:
    """Tests for deserializing JSON to plain Python objects."""

    def test_json_to_simple_object(self):
        """Test deserializing JSON to simple plain object."""
        json_str = '{"name": "John", "age": 30}'
        person = ObjectMapper(json_str).to_object(SimplePerson)

        assert isinstance(person, SimplePerson)
        assert person.name == "John"
        assert person.age == 30

    def test_dict_to_simple_object(self):
        """Test deserializing dict to simple plain object."""
        data = {"name": "John", "age": 30}
        person = ObjectMapper(data).to_object(SimplePerson)

        assert isinstance(person, SimplePerson)
        assert person.name == "John"
        assert person.age == 30

    def test_json_list_to_object_list(self):
        """Test deserializing JSON array to list of plain objects."""
        json_str = '[{"name": "John", "age": 30}, {"name": "Jane", "age": 25}]'
        people = ObjectMapper(json_str).to_object(SimplePerson)

        assert isinstance(people, list)
        assert len(people) == 2
        assert all(isinstance(p, SimplePerson) for p in people)
        assert people[0].name == "John"
        assert people[1].name == "Jane"


class TestPlainObjectRoundTrip:
    """Test serialization/deserialization round trips for plain objects."""

    def test_simple_round_trip(self):
        """Test round trip for simple plain object."""
        original = SimplePerson(name="John", age=30)
        data = ObjectMapper(original).to_json()
        restored = ObjectMapper(data).to_object(SimplePerson)

        assert restored.name == original.name
        assert restored.age == original.age

    def test_list_round_trip(self):
        """Test round trip for list of plain objects."""
        original = [
            SimplePerson(name="John", age=30),
            SimplePerson(name="Jane", age=25),
        ]
        data = ObjectMapper(original).to_json()
        restored = ObjectMapper(data).to_object(SimplePerson)

        assert len(restored) == len(original)
        for orig, rest in zip(original, restored):
            assert rest.name == orig.name
            assert rest.age == orig.age
