"""Tests for ObjectMapper with special types (datetime, UUID, Enum, etc.)."""

import re
from dataclasses import dataclass
from datetime import datetime, date, time, timedelta
from decimal import Decimal
from enum import Enum
from fractions import Fraction
from ipaddress import IPv4Address, IPv4Network, IPv6Address
from pathlib import Path
from typing import Optional
from uuid import UUID

from fixturify.object_mapper import ObjectMapper


class Status(Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"


class Priority(Enum):
    LOW = 1
    MEDIUM = 2
    HIGH = 3


@dataclass
class EntityWithDatetime:
    created_at: datetime
    updated_at: Optional[datetime] = None


@dataclass
class EntityWithDate:
    birth_date: date


@dataclass
class EntityWithTime:
    start_time: time


@dataclass
class EntityWithUUID:
    id: UUID
    name: str


@dataclass
class EntityWithEnum:
    status: Status
    priority: Priority


@dataclass
class EntityWithDecimal:
    price: Decimal
    tax_rate: Decimal


@dataclass
class EntityWithComplex:
    impedance: complex


@dataclass
class EntityWithFraction:
    ratio: Fraction


@dataclass
class EntityWithTimedelta:
    duration: timedelta


@dataclass
class EntityWithPath:
    config_path: Path


@dataclass
class EntityWithIPv4:
    address: IPv4Address
    network: IPv4Network


@dataclass
class EntityWithIPv6:
    address: IPv6Address


@dataclass
class EntityWithBytes:
    data: bytes


@dataclass
class EntityWithPattern:
    pattern: re.Pattern


@dataclass
class EntityWithMixed:
    price: Decimal
    duration: timedelta
    address: IPv4Address
    path: Path
    id: UUID


class TestDatetimeSerialization:
    """Tests for datetime type serialization."""

    def test_datetime_to_iso_format(self):
        """Test that datetime is serialized to ISO 8601 format."""
        dt = datetime(2024, 1, 15, 10, 30, 45)
        entity = EntityWithDatetime(created_at=dt)
        data = ObjectMapper(entity).to_json()

        assert data["created_at"] == "2024-01-15T10:30:45"

    def test_date_to_iso_format(self):
        """Test that date is serialized to ISO format."""
        d = date(2024, 1, 15)
        entity = EntityWithDate(birth_date=d)
        data = ObjectMapper(entity).to_json()

        assert data["birth_date"] == "2024-01-15"

    def test_time_to_iso_format(self):
        """Test that time is serialized to ISO format."""
        t = time(10, 30, 45)
        entity = EntityWithTime(start_time=t)
        data = ObjectMapper(entity).to_json()

        assert data["start_time"] == "10:30:45"


class TestDatetimeDeserialization:
    """Tests for datetime type deserialization."""

    def test_iso_format_to_datetime(self):
        """Test that ISO 8601 string is deserialized to datetime."""
        json_str = '{"created_at": "2024-01-15T10:30:45"}'
        entity = ObjectMapper(json_str).to_object(EntityWithDatetime)

        assert isinstance(entity.created_at, datetime)
        assert entity.created_at == datetime(2024, 1, 15, 10, 30, 45)

    def test_iso_format_to_date(self):
        """Test that ISO date string is deserialized to date."""
        json_str = '{"birth_date": "2024-01-15"}'
        entity = ObjectMapper(json_str).to_object(EntityWithDate)

        assert isinstance(entity.birth_date, date)
        assert entity.birth_date == date(2024, 1, 15)

    def test_iso_format_to_time(self):
        """Test that ISO time string is deserialized to time."""
        json_str = '{"start_time": "10:30:45"}'
        entity = ObjectMapper(json_str).to_object(EntityWithTime)

        assert isinstance(entity.start_time, time)
        assert entity.start_time == time(10, 30, 45)


class TestUUIDSerialization:
    """Tests for UUID type serialization."""

    def test_uuid_to_string(self):
        """Test that UUID is serialized to string."""
        uuid_val = UUID("550e8400-e29b-41d4-a716-446655440000")
        entity = EntityWithUUID(id=uuid_val, name="test")
        data = ObjectMapper(entity).to_json()

        assert data["id"] == "550e8400-e29b-41d4-a716-446655440000"

    def test_string_to_uuid(self):
        """Test that UUID string is deserialized to UUID."""
        json_str = '{"id": "550e8400-e29b-41d4-a716-446655440000", "name": "test"}'
        entity = ObjectMapper(json_str).to_object(EntityWithUUID)

        assert isinstance(entity.id, UUID)
        assert entity.id == UUID("550e8400-e29b-41d4-a716-446655440000")


class TestEnumSerialization:
    """Tests for Enum type serialization."""

    def test_string_enum_to_value(self):
        """Test that string enum is serialized by value."""
        entity = EntityWithEnum(status=Status.ACTIVE, priority=Priority.HIGH)
        data = ObjectMapper(entity).to_json()

        assert data["status"] == "active"
        assert data["priority"] == 3

    def test_value_to_string_enum(self):
        """Test that string value is deserialized to enum."""
        json_str = '{"status": "active", "priority": 3}'
        entity = ObjectMapper(json_str).to_object(EntityWithEnum)

        assert entity.status == Status.ACTIVE
        assert entity.priority == Priority.HIGH

    def test_standalone_enum_to_json(self):
        """Test serializing a standalone enum value."""
        data = ObjectMapper(Status.ACTIVE).to_json()
        assert data == "active"

    def test_json_to_standalone_enum(self):
        """Test deserializing to standalone enum."""
        result = ObjectMapper('"active"').to_object(Status)
        assert result == Status.ACTIVE


class TestSpecialTypeRoundTrips:
    """Test round trips for special types."""

    def test_datetime_round_trip(self):
        """Test datetime round trip."""
        original = EntityWithDatetime(
            created_at=datetime(2024, 1, 15, 10, 30, 45),
            updated_at=datetime(2024, 1, 16, 12, 0, 0),
        )
        data = ObjectMapper(original).to_json()
        restored = ObjectMapper(data).to_object(EntityWithDatetime)

        assert restored.created_at == original.created_at
        assert restored.updated_at == original.updated_at

    def test_uuid_round_trip(self):
        """Test UUID round trip."""
        original = EntityWithUUID(
            id=UUID("550e8400-e29b-41d4-a716-446655440000"), name="test"
        )
        data = ObjectMapper(original).to_json()
        restored = ObjectMapper(data).to_object(EntityWithUUID)

        assert restored.id == original.id
        assert restored.name == original.name

    def test_enum_round_trip(self):
        """Test enum round trip."""
        original = EntityWithEnum(status=Status.PENDING, priority=Priority.MEDIUM)
        data = ObjectMapper(original).to_json()
        restored = ObjectMapper(data).to_object(EntityWithEnum)

        assert restored.status == original.status
        assert restored.priority == original.priority


class TestDecimalSerialization:
    """Tests for Decimal type."""

    def test_decimal_to_json(self):
        entity = EntityWithDecimal(price=Decimal("19.99"), tax_rate=Decimal("0.23"))
        data = ObjectMapper(entity).to_json()

        assert data["price"] == 19.99
        assert data["tax_rate"] == 0.23

    def test_decimal_integer_to_json(self):
        entity = EntityWithDecimal(price=Decimal("100"), tax_rate=Decimal("0.00"))
        data = ObjectMapper(entity).to_json()

        assert data["price"] == 100.0
        assert isinstance(data["price"], float)

    def test_json_to_decimal(self):
        data = {"price": 19.99, "tax_rate": 0.23}
        entity = ObjectMapper(data).to_object(EntityWithDecimal)

        assert isinstance(entity.price, Decimal)
        assert entity.price == Decimal("19.99")

    def test_decimal_round_trip(self):
        original = EntityWithDecimal(price=Decimal("49.95"), tax_rate=Decimal("0.08"))
        data = ObjectMapper(original).to_json()
        restored = ObjectMapper(data).to_object(EntityWithDecimal)

        assert isinstance(restored.price, Decimal)
        assert isinstance(restored.tax_rate, Decimal)

    def test_standalone_decimal(self):
        data = ObjectMapper(Decimal("3.14")).to_json()
        assert data == 3.14


class TestComplexSerialization:
    """Tests for complex type."""

    def test_complex_to_json(self):
        entity = EntityWithComplex(impedance=complex(3, 4))
        data = ObjectMapper(entity).to_json()

        assert data["impedance"] == {"real": 3.0, "imag": 4.0}

    def test_json_to_complex(self):
        data = {"impedance": {"real": 3.0, "imag": 4.0}}
        entity = ObjectMapper(data).to_object(EntityWithComplex)

        assert isinstance(entity.impedance, complex)
        assert entity.impedance == complex(3, 4)

    def test_complex_round_trip(self):
        original = EntityWithComplex(impedance=complex(1.5, -2.5))
        data = ObjectMapper(original).to_json()
        restored = ObjectMapper(data).to_object(EntityWithComplex)

        assert restored.impedance == original.impedance


class TestFractionSerialization:
    """Tests for Fraction type."""

    def test_fraction_to_json(self):
        entity = EntityWithFraction(ratio=Fraction(3, 7))
        data = ObjectMapper(entity).to_json()

        assert data["ratio"] == {"numerator": 3, "denominator": 7}

    def test_json_to_fraction(self):
        data = {"ratio": {"numerator": 3, "denominator": 7}}
        entity = ObjectMapper(data).to_object(EntityWithFraction)

        assert isinstance(entity.ratio, Fraction)
        assert entity.ratio == Fraction(3, 7)

    def test_fraction_round_trip(self):
        original = EntityWithFraction(ratio=Fraction(22, 7))
        data = ObjectMapper(original).to_json()
        restored = ObjectMapper(data).to_object(EntityWithFraction)

        assert restored.ratio == original.ratio


class TestTimedeltaSerialization:
    """Tests for timedelta type."""

    def test_timedelta_to_json(self):
        entity = EntityWithTimedelta(duration=timedelta(hours=2, minutes=30))
        data = ObjectMapper(entity).to_json()

        assert data["duration"] == 9000.0

    def test_json_to_timedelta(self):
        data = {"duration": 9000.0}
        entity = ObjectMapper(data).to_object(EntityWithTimedelta)

        assert isinstance(entity.duration, timedelta)
        assert entity.duration == timedelta(hours=2, minutes=30)

    def test_timedelta_round_trip(self):
        original = EntityWithTimedelta(duration=timedelta(days=1, hours=5, seconds=30))
        data = ObjectMapper(original).to_json()
        restored = ObjectMapper(data).to_object(EntityWithTimedelta)

        assert restored.duration == original.duration


class TestPathSerialization:
    """Tests for pathlib.Path type."""

    def test_path_to_json(self):
        entity = EntityWithPath(config_path=Path("/etc/config.yaml"))
        data = ObjectMapper(entity).to_json()

        assert data["config_path"] == str(Path("/etc/config.yaml"))

    def test_json_to_path(self):
        data = {"config_path": "/etc/config.yaml"}
        entity = ObjectMapper(data).to_object(EntityWithPath)

        assert isinstance(entity.config_path, Path)
        assert str(entity.config_path) == str(Path("/etc/config.yaml"))

    def test_path_round_trip(self):
        original = EntityWithPath(config_path=Path("/home/user/data.json"))
        data = ObjectMapper(original).to_json()
        restored = ObjectMapper(data).to_object(EntityWithPath)

        assert restored.config_path == original.config_path


class TestIPAddressSerialization:
    """Tests for IP address types."""

    def test_ipv4_to_json(self):
        entity = EntityWithIPv4(
            address=IPv4Address("192.168.1.1"),
            network=IPv4Network("10.0.0.0/8"),
        )
        data = ObjectMapper(entity).to_json()

        assert data["address"] == "192.168.1.1"
        assert data["network"] == "10.0.0.0/8"

    def test_json_to_ipv4(self):
        data = {"address": "192.168.1.1", "network": "10.0.0.0/8"}
        entity = ObjectMapper(data).to_object(EntityWithIPv4)

        assert isinstance(entity.address, IPv4Address)
        assert isinstance(entity.network, IPv4Network)
        assert str(entity.address) == "192.168.1.1"

    def test_ipv6_to_json(self):
        entity = EntityWithIPv6(address=IPv6Address("::1"))
        data = ObjectMapper(entity).to_json()

        assert data["address"] == "::1"

    def test_json_to_ipv6(self):
        data = {"address": "::1"}
        entity = ObjectMapper(data).to_object(EntityWithIPv6)

        assert isinstance(entity.address, IPv6Address)

    def test_ipv4_round_trip(self):
        original = EntityWithIPv4(
            address=IPv4Address("172.16.0.1"),
            network=IPv4Network("192.168.0.0/16"),
        )
        data = ObjectMapper(original).to_json()
        restored = ObjectMapper(data).to_object(EntityWithIPv4)

        assert restored.address == original.address
        assert restored.network == original.network


class TestBytesSerialization:
    """Tests for bytes type."""

    def test_bytes_to_json(self):
        entity = EntityWithBytes(data=b"hello world")
        data = ObjectMapper(entity).to_json()

        assert data["data"] == "hello world"

    def test_json_to_bytes(self):
        data = {"data": "hello world"}
        entity = ObjectMapper(data).to_object(EntityWithBytes)

        assert isinstance(entity.data, bytes)
        assert entity.data == b"hello world"

    def test_bytearray_to_json(self):
        data = ObjectMapper(bytearray(b"test")).to_json()
        assert data == "test"


class TestPatternSerialization:
    """Tests for re.Pattern type."""

    def test_pattern_to_json(self):
        entity = EntityWithPattern(pattern=re.compile(r"\d+"))
        data = ObjectMapper(entity).to_json()

        assert data["pattern"] == r"\d+"

    def test_json_to_pattern(self):
        data = {"pattern": r"\d+"}
        entity = ObjectMapper(data).to_object(EntityWithPattern)

        assert isinstance(entity.pattern, re.Pattern)
        assert entity.pattern.pattern == r"\d+"

    def test_pattern_round_trip(self):
        original = EntityWithPattern(pattern=re.compile(r"[a-z]+@[a-z]+\.[a-z]+"))
        data = ObjectMapper(original).to_json()
        restored = ObjectMapper(data).to_object(EntityWithPattern)

        assert restored.pattern.pattern == original.pattern.pattern


class TestMixedSpecialTypes:
    """Tests for entities with multiple special types."""

    def test_mixed_round_trip(self):
        original = EntityWithMixed(
            price=Decimal("29.99"),
            duration=timedelta(hours=1, minutes=30),
            address=IPv4Address("10.0.0.1"),
            path=Path("/tmp/data"),
            id=UUID("550e8400-e29b-41d4-a716-446655440000"),
        )
        data = ObjectMapper(original).to_json()
        restored = ObjectMapper(data).to_object(EntityWithMixed)

        assert isinstance(restored.price, Decimal)
        assert isinstance(restored.duration, timedelta)
        assert isinstance(restored.address, IPv4Address)
        assert isinstance(restored.path, Path)
        assert isinstance(restored.id, UUID)
        assert restored.address == original.address
        assert restored.duration == original.duration
        assert restored.id == original.id
