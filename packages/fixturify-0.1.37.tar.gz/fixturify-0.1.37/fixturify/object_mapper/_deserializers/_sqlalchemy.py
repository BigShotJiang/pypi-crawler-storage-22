"""SQLAlchemy model deserializer."""

from typing import Any, Type, TypeVar

from fixturify.object_mapper._deserializers._base import _BaseDeserializer, _NO_DEFAULT

T = TypeVar("T")


class _SQLAlchemyDeserializer(_BaseDeserializer):
    """Deserializer for SQLAlchemy models."""

    def deserialize(self, data: dict, target_class: Type[T]) -> T:
        """
        Deserialize a dictionary to a SQLAlchemy model.

        Missing column fields get type-appropriate defaults.

        Args:
            data: Dictionary data to deserialize
            target_class: The SQLAlchemy model class

        Returns:
            Instance of target_class
        """
        # Get column information from mapper
        mapper = getattr(target_class, "__mapper__", None)
        if mapper is None:
            # Fallback to simple instantiation
            return target_class(**data)

        # Get type hints for nested object conversion
        type_hints = self._get_type_hints(target_class)

        # Build kwargs, filtering to only column names
        column_names = {col.key for col in mapper.columns}
        kwargs = {}

        for key, value in data.items():
            if key in column_names:
                target_type = type_hints.get(key, Any)
                kwargs[key] = self._convert_value(value, target_type)

        # Fill missing column fields with type-based defaults
        for col_name in column_names:
            if col_name not in data:
                target_type = type_hints.get(col_name, Any)
                default = self._get_type_default(target_type)
                if default is not _NO_DEFAULT:
                    kwargs[col_name] = default

        # Create instance
        instance = target_class(**kwargs)

        # Handle relationships if present in data
        for relationship in mapper.relationships:
            rel_name = relationship.key
            if rel_name in data:
                rel_data = data[rel_name]
                rel_class = relationship.mapper.class_

                if isinstance(rel_data, list):
                    rel_instances = [
                        self._deserialize_nested(item, rel_class) for item in rel_data
                    ]
                    setattr(instance, rel_name, rel_instances)
                elif isinstance(rel_data, dict):
                    rel_instance = self._deserialize_nested(rel_data, rel_class)
                    setattr(instance, rel_name, rel_instance)
            elif relationship.uselist:
                # Missing collection relationship → empty list
                setattr(instance, rel_name, [])

        return instance

    def _deserialize_nested(self, data: dict, target_class: Type[T]) -> T:
        """Deserialize a nested SQLAlchemy model."""
        # Check if it's a SQLAlchemy model
        if hasattr(target_class, "__tablename__") and hasattr(
            target_class, "__mapper__"
        ):
            return self.deserialize(data, target_class)

        # For non-SQLAlchemy nested objects, try basic instantiation
        return target_class(**data)
