"""SQLAlchemy model serializer."""

from typing import Any

from sqlalchemy import inspect as sa_inspect
from sqlalchemy.orm import MANYTOONE

from fixturify.object_mapper._serializers._base import CIRCULAR_REF, _BaseSerializer


class _SQLAlchemySerializer(_BaseSerializer):
    """Serializer for SQLAlchemy models."""

    def serialize(self, obj: Any) -> dict[Any, Any]:
        """
        Serialize a SQLAlchemy model to a dictionary.

        Args:
            obj: A SQLAlchemy model instance

        Returns:
            Dictionary representation of the model
        """
        self.reset()
        result: dict[Any, Any] = self._serialize_with_path(obj, "#")
        return result

    def _serialize_object(self, obj: Any, path: str) -> dict:
        """Serialize a SQLAlchemy model."""
        obj_type = type(obj)

        # Check if this is a SQLAlchemy model
        if hasattr(obj_type, "__tablename__") and hasattr(obj_type, "__mapper__"):
            return self._serialize_sqlalchemy(obj, path)

        # Fall back to base implementation for nested non-SQLAlchemy objects
        return super()._serialize_object(obj, path)

    def _serialize_sqlalchemy(self, obj: Any, path: str) -> dict[Any, Any]:
        """Serialize a SQLAlchemy model using its mapper columns."""
        result: dict[Any, Any] = {}

        # Get the mapper for column information
        mapper = getattr(type(obj), "__mapper__", None)
        if mapper is None:
            return result

        # Iterate over column properties
        for column in mapper.columns:
            column_name = column.key

            # Skip dunder fields
            if self._is_dunder(column_name):
                continue

            value = getattr(obj, column_name, None)
            item_path = f"{path}/{column_name}"
            serialized = self._serialize_value(value, item_path)
            if serialized is not CIRCULAR_REF:
                result[column_name] = serialized

        # Also handle relationships if loaded (not lazy)
        unloaded = sa_inspect(obj).unloaded
        for relationship in mapper.relationships:
            rel_name = relationship.key

            # Skip dunder fields
            if self._is_dunder(rel_name):
                continue

            # Keep collection relationship keys stable.
            if relationship.uselist and rel_name in unloaded:
                result[rel_name] = []
                continue

            # Keep singular relationship keys stable.
            if not relationship.uselist and rel_name in unloaded and relationship.direction is not MANYTOONE:
                result[rel_name] = None
                continue

            # Check if the relationship is loaded (not pending lazy load)
            if rel_name not in unloaded:
                value = getattr(obj, rel_name, None)
                item_path = f"{path}/{rel_name}"
                serialized = self._serialize_value(value, item_path)
                if serialized is not CIRCULAR_REF:
                    result[rel_name] = serialized

        return result
