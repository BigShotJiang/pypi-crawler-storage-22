"""
Integration test: empty list relationships appear in JsonAssert snapshots.

When a SQLModel/SQLAlchemy object has a list relationship (one-to-many) and
the input JSON does NOT contain that field, the deserialized object should
have an empty list, and JsonAssert should include it in the snapshot.
"""

from typing import List, Optional

from sqlalchemy import ForeignKey, String
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship
from sqlmodel import SQLModel, Field, Relationship

from fixturify import JsonAssert, read


# --- Models (table=True with one-to-many relationship) ---


class Department(SQLModel, table=True):
    __tablename__ = "snapshot_departments"

    id: Optional[int] = Field(default=None, primary_key=True)
    name: str
    description: Optional[str] = None

    employees: List["Employee"] = Relationship(back_populates="department")


class Employee(SQLModel, table=True):
    __tablename__ = "snapshot_employees"

    id: Optional[int] = Field(default=None, primary_key=True)
    name: str
    email: Optional[str] = None
    department_id: Optional[int] = Field(default=None, foreign_key="snapshot_departments.id")

    department: Optional["Department"] = Relationship(back_populates="employees")


# --- SQLModel one-to-one style models (singular relation) ---


class Scenario(SQLModel, table=True):
    __tablename__ = "snapshot_scenarios"

    id: Optional[int] = Field(default=None, primary_key=True)
    name: str

    operation: Optional["ScenarioOperation"] = Relationship(back_populates="scenario")


class ScenarioOperation(SQLModel, table=True):
    __tablename__ = "snapshot_scenario_operations"

    scenario_id: Optional[int] = Field(default=None, foreign_key="snapshot_scenarios.id", primary_key=True)
    value: float = 0.0

    scenario: Optional["Scenario"] = Relationship(back_populates="operation")


# --- SQLAlchemy models (collection + singular relation) ---


class SABase(DeclarativeBase):
    pass


class SADepartment(SABase):
    __tablename__ = "snapshot_sa_departments"

    id: Mapped[Optional[int]] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(200))
    description: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)

    employees: Mapped[List["SAEmployee"]] = relationship("SAEmployee", back_populates="department")


class SAEmployee(SABase):
    __tablename__ = "snapshot_sa_employees"

    id: Mapped[Optional[int]] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(200))
    email: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)
    department_id: Mapped[Optional[int]] = mapped_column(ForeignKey("snapshot_sa_departments.id"), nullable=True)

    department: Mapped[Optional["SADepartment"]] = relationship("SADepartment", back_populates="employees")


class SAScenario(SABase):
    __tablename__ = "snapshot_sa_scenarios"

    id: Mapped[Optional[int]] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(200))

    operation: Mapped[Optional["SAOperation"]] = relationship("SAOperation", back_populates="scenario", uselist=False)


class SAOperation(SABase):
    __tablename__ = "snapshot_sa_operations"

    scenario_id: Mapped[int] = mapped_column(ForeignKey("snapshot_sa_scenarios.id"), primary_key=True)
    value: Mapped[float] = mapped_column()

    scenario: Mapped[Optional["SAScenario"]] = relationship("SAScenario", back_populates="operation")


# --- Tests ---


class TestEmptyRelationSnapshot:
    """Empty list relationships must appear in JsonAssert output."""

    @read.fixture(
        path="./fixtures/team_no_members.json",
        fixture_name="team",
        object_class=Department,
    )
    def test_missing_list_relation_becomes_empty_list(self, team: Department):
        """@read loads model without 'employees' key → object gets employees=[]
        → JsonAssert snapshot includes 'employees': []."""
        # Deserializer should have filled the missing list relationship
        assert isinstance(team.employees, list)
        assert team.employees == []

        # JsonAssert must include the empty list in comparison
        JsonAssert(team).compare_to_file(
            "./fixtures/expected_team_with_empty_members.json"
        )

    @read.fixture(
        path="./fixtures/team_no_members.json",
        fixture_name="team",
        object_class=SADepartment,
    )
    def test_sqlalchemy_missing_list_relation_becomes_empty_list(self, team: SADepartment):
        """SQLAlchemy collection relation should be serialized as empty list."""
        assert isinstance(team.employees, list)
        assert team.employees == []

        JsonAssert(team).compare_to_file(
            "./fixtures/expected_sa_team_with_empty_members.json"
        )

    @read.fixture(
        path="./fixtures/scenario_no_operation.json",
        fixture_name="scenario",
        object_class=Scenario,
    )
    def test_sqlmodel_missing_singular_relation_becomes_null(self, scenario: Scenario):
        """Missing SQLModel singular relation should be serialized as null."""
        JsonAssert(scenario).compare_to_file(
            "./fixtures/expected_scenario_with_null_operation.json"
        )

    @read.fixture(
        path="./fixtures/scenario_no_operation.json",
        fixture_name="scenario",
        object_class=SAScenario,
    )
    def test_sqlalchemy_missing_singular_relation_becomes_null(self, scenario: SAScenario):
        """Missing SQLAlchemy singular relation should be serialized as null."""
        JsonAssert(scenario).compare_to_file(
            "./fixtures/expected_sa_scenario_with_null_operation.json"
        )
