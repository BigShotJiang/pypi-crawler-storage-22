"""Tests for @sql and @http decorators on pytest yield fixtures.

Verifies that:
1. @sql works on sync yield fixtures (generator wrappers)
2. @http works on sync yield fixtures (generator wrappers)
3. No ScopeMismatch when session-scoped yield fixture uses @sql
4. Stacked @sql + @http on yield fixtures
"""

import sqlite3

import pytest
import requests

from fixturify import Phase, SqlTestConfig, http, sql


# ---------------------------------------------------------------------------
# Shared config — single SqlTestConfig to avoid AmbiguousConfigFixtureError
# ---------------------------------------------------------------------------

@pytest.fixture(scope="session")
def session_db_path(tmp_path_factory: pytest.TempPathFactory) -> str:
    return str(tmp_path_factory.mktemp("db") / "test.db")


@pytest.fixture(scope="session")
def sql_config(session_db_path: str) -> SqlTestConfig:
    return SqlTestConfig(
        driver="sqlite3",
        host="",
        database=session_db_path,
        user="",
        password="",
    )


# ---------------------------------------------------------------------------
# Session-scoped yield fixture with @sql — SQL runs once at session start
# ---------------------------------------------------------------------------

@pytest.fixture(scope="session")
@sql(path="./fixtures/sqlite_setup.sql")
def session_db(session_db_path: str, sql_config: SqlTestConfig):
    """Session-scoped yield fixture: @sql sets up DB, fixture yields path."""
    yield session_db_path


class TestSessionInitWithFunctionCleanup:
    """Real-world pattern: session config + session init + function cleanup.

    - sql_config: session-scoped, provides DB connection details
    - session_db: session-scoped yield fixture with @sql(BEFORE), inserts
      initial data once at session start
    - _cleanup: function-scoped autouse yield fixture with @sql(AFTER),
      runs cleanup SQL after every test

    This is the ScopeMismatch scenario — session-scoped fixture discovery
    must not trigger ScopeMismatch when scanning for SqlTestConfig.
    """

    @pytest.fixture(scope="function", autouse=True)
    @sql(path="./fixtures/sqlite_cleanup.sql", phase=Phase.AFTER)
    def _cleanup(self, session_db: str, sql_config: SqlTestConfig):
        """Autouse: cleanup after each test."""
        yield

    def test_data_exists(self, session_db: str):
        """Session init inserted 2 rows — they should be present."""
        conn = sqlite3.connect(session_db)
        rows = conn.execute("SELECT COUNT(*) FROM items").fetchone()
        conn.close()
        assert rows[0] == 2

    def test_cleanup_ran(self, session_db: str):
        """After previous test's cleanup, table was dropped.

        session_db's @sql(BEFORE) only ran once at session start,
        so after cleanup the table is gone. This proves AFTER ran.
        """
        conn = sqlite3.connect(session_db)
        # Table was dropped by cleanup — querying should fail
        with pytest.raises(sqlite3.OperationalError, match="no such table"):
            conn.execute("SELECT COUNT(*) FROM items")


# ---------------------------------------------------------------------------
# Function-scoped yield fixture with @sql BEFORE + AFTER
# ---------------------------------------------------------------------------

@pytest.fixture
@sql(path="./fixtures/sqlite_setup.sql")
@sql(path="./fixtures/sqlite_cleanup.sql", phase=Phase.AFTER)
def func_db(sql_config: SqlTestConfig):
    """Function-scoped yield fixture: setup before, cleanup after."""
    yield sql_config.database


class TestFunctionScopedYieldFixture:
    """Function-scoped yield fixture with @sql BEFORE and AFTER."""

    def test_func_data_exists(self, func_db: str):
        conn = sqlite3.connect(func_db)
        rows = conn.execute("SELECT COUNT(*) FROM items").fetchone()
        conn.close()
        assert rows[0] == 2

    def test_func_data_independent(self, func_db: str):
        """Each invocation re-runs setup (BEFORE) and cleanup (AFTER)."""
        conn = sqlite3.connect(func_db)
        rows = conn.execute("SELECT COUNT(*) FROM items").fetchone()
        conn.close()
        assert rows[0] == 2


# ---------------------------------------------------------------------------
# Yield fixture with @http — HTTP mocking active during fixture yield
# ---------------------------------------------------------------------------

@pytest.fixture
@http(path="./fixtures/item_api.json")
def http_fixture():
    """Yield fixture with HTTP mocking active."""
    yield "ready"


class TestHttpYieldFixture:
    """@http on a yield fixture — mock context active during test."""

    def test_http_mock_active(self, http_fixture: str):
        assert http_fixture == "ready"
        r = requests.get("https://api.example.com/items/1/details")
        assert r.status_code == 200
        assert r.json()["color"] == "red"


# ---------------------------------------------------------------------------
# Combined: yield fixture with both @sql and @http
# ---------------------------------------------------------------------------

@pytest.fixture
@sql(path="./fixtures/sqlite_setup.sql")
@http(path="./fixtures/item_api.json")
def combined_fixture(sql_config: SqlTestConfig):
    """Yield fixture with both @sql and @http stacked."""
    yield sql_config.database


class TestCombinedYieldFixture:
    """Stacked @sql + @http on a yield fixture."""

    def test_both_active(self, combined_fixture: str):
        # SQL data present
        conn = sqlite3.connect(combined_fixture)
        rows = conn.execute("SELECT COUNT(*) FROM items").fetchone()
        conn.close()
        assert rows[0] == 2

        # HTTP mock active
        r = requests.get("https://api.example.com/items/1/details")
        assert r.status_code == 200
