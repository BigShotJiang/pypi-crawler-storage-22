"""Tests for diff formatter output granularity."""

from fixturify.json_assert._diff_formatter import _DiffFormatter


def test_format_changed_values_expands_nested_object_changes_to_leaf_paths():
    changed = {
        "root['vendors'][0]": {
            "old_value": {
                "vendor_base": {"id": 1, "name": "Vendor One"},
                "scores": [10, 20],
            },
            "new_value": {
                "vendor_base": {"id": 1, "name": "Vendor Uno"},
                "scores": [10, 21],
            },
        }
    }

    output = _DiffFormatter._format_changed_values(changed)

    assert "root['vendors'][0]['vendor_base']['name']" in output
    assert "root['vendors'][0]['scores'][1]" in output
    assert "Vendor Uno" in output
    assert "Vendor One" in output
