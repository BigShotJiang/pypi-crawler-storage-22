# pytools

A collection of Python testing utilities.

## Installation

```bash
pip install fixturify
```

## Modules

| Module | Description | Docs |
|--------|-------------|------|
| [sql](docs/sql.md) | Execute SQL files before/after tests | [docs/sql.md](docs/sql.md) |
| [read](docs/read.md) | Inject JSON fixtures into test functions | [docs/read.md](docs/read.md) |
| [http](docs/http.md) | Record and replay HTTP calls | [docs/http.md](docs/http.md) |
| [JsonAssert](docs/json_assert.md) | Compare objects to JSON files | [docs/json_assert.md](docs/json_assert.md) |
| [ObjectMapper](docs/object_mapper.md) | Bidirectional object-JSON mapping | [docs/object_mapper.md](docs/object_mapper.md) |

## Quick examples

### sql

```python
from fixturify import sql, Phase

@sql(path="./setup.sql")
@sql(path="./cleanup.sql", phase=Phase.AFTER)
def test_database():
    # SQL executed before and after test
    pass
```

### read

```python
from fixturify import read

@read.fixture(path="./fixtures/user.json", fixture_name="user", object_class=User)
def test_user(user: User):
    assert user.name == "John"
```

### http

```python
from fixturify import http

@http(path="./fixtures/api.json")
def test_api():
    # First run: records HTTP calls
    # Next runs: replays from file
    response = requests.get("https://api.example.com/users")
    assert response.status_code == 200
```

### JsonAssert

```python
from fixturify import JsonAssert

def test_response():
    data = {"name": "John", "age": 30}
    JsonAssert(data).ignore("age").compare_to_file("./expected.json")
```

### ObjectMapper

```python
from fixturify import ObjectMapper

# Object to JSON
user = User(name="John", age=30)
data = ObjectMapper(user).to_json()

# JSON to object
data = {"name": "John", "age": 30}
user = ObjectMapper(data).to_object(User)
```

## Public API

```python
from fixturify import (
    # Decorators
    sql,
    read,
    http,
    # Enums
    Phase,
    # Config
    SqlTestConfig,
    HttpTestConfig,
    # Classes
    JsonAssert,
    ObjectMapper,
)
```
