# http

Decorator for recording and replaying HTTP calls in tests.

## Import

```python
from fixturify import http, HttpTestConfig
```

## Basic usage

```python
import requests

@http(path="./fixtures/api_calls.json")
def test_api():
    response = requests.get("https://api.example.com/users")
    assert response.status_code == 200
```

**First run**: makes real HTTP calls and saves them to JSON file.

**Subsequent runs**: replays saved responses (no network calls).

## Supported HTTP libraries

- `requests` (sync)
- `httpx` (sync and async)

## Async functions

```python
import httpx

@http(path="./fixtures/api.json")
async def test_async_api():
    async with httpx.AsyncClient() as client:
        response = await client.get("https://api.example.com/users")
        assert response.status_code == 200
```

## Configuration

### Via pytest fixture (recommended)

```python
# conftest.py
import pytest
from fixturify import HttpTestConfig

@pytest.fixture
def http_config() -> HttpTestConfig:
    return HttpTestConfig(
        ignore_request_headers=["Authorization"],
        exclude_request_headers=["Authorization", "X-API-Key"],
    )
```

### Directly in decorator

```python
config = HttpTestConfig(
    ignore_request_headers=["Authorization"],
    strict_order=True,
)

@http(path="./fixtures/api.json", config=config)
def test_api():
    pass
```

## HttpTestConfig

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `ignore_request_headers` | `List[str]` | `[]` | Headers to ignore when matching requests |
| `ignore_response_headers` | `List[str]` | `[]` | Headers to ignore when comparing responses |
| `exclude_request_headers` | `List[str]` | `[]` | Headers to remove from recordings |
| `exclude_response_headers` | `List[str]` | `[]` | Headers to remove from response recordings |
| `exclude_hosts` | `List[str]` | `[]` | Hosts excluded from recording/playback |
| `match_request_body` | `bool` | `True` | Whether to match request body |
| `strict_order` | `bool` | `False` | Whether requests must occur in same order |

## Default ignored headers

**Request (ignored during matching)**:
- `user-agent`, `date`, `accept-encoding`, `content-length`, `connection`, `host`

**Request (excluded from recordings)**:
- `user-agent`, `accept-encoding`, `connection`, `host`

**Response (excluded from recordings)**:
- `date`, `server`, `x-request-id`, `x-correlation-id`, `set-cookie`, `transfer-encoding`, `content-length`

## Configuration examples

### Ignoring Authorization header

```python
config = HttpTestConfig(
    ignore_request_headers=["Authorization"],    # don't compare during playback
    exclude_request_headers=["Authorization"],   # don't save to file
)
```

### Enforcing request order

```python
config = HttpTestConfig(strict_order=True)

@http(path="./fixtures/api.json", config=config)
def test_ordered():
    requests.get("https://api.example.com/first")   # must be first
    requests.get("https://api.example.com/second")  # must be second
```

### Excluding host from mocking

```python
config = HttpTestConfig(
    exclude_hosts=["testserver", "localhost:8000"],
)

@http(path="./fixtures/api.json", config=config)
def test_with_local_server():
    # These calls go to real server:
    requests.get("http://testserver/api/health")

    # These are recorded/replayed:
    requests.get("https://external-api.com/data")
```

### Ignoring request body

```python
config = HttpTestConfig(match_request_body=False)
```

## Exceptions

| Exception | When |
|-----------|------|
| `NoMatchingRecordingError` | Request doesn't match any recording |
| `UnusedRecordingsError` | Some recordings were not used |
| `RequestMismatchError` | Details about request mismatch |

## Re-recording

Delete the JSON recordings file and run test again:

```bash
rm tests/fixtures/api_calls.json
pytest tests/test_api.py
```

## Recording file format

```json
{
  "mappings": [
    {
      "request": {
        "method": "GET",
        "url": "https://api.example.com/users",
        "headers": {"Accept": "application/json"},
        "queryParameters": {},
        "body": null
      },
      "response": {
        "statusCode": 200,
        "headers": {"Content-Type": "application/json"},
        "body": [{"id": 1, "name": "John"}]
      }
    }
  ]
}
```

## Path resolution

Paths are resolved relative to the test file:

```
tests/
  test_api.py            <- @http(path="./fixtures/api.json")
  fixtures/
    api.json             <- recordings saved here
```
