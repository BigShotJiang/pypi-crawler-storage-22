# JsonAssert

Compare Python objects to JSON files in tests.

## Import

```python
from fixturify import JsonAssert
```

## Required dependencies

```bash
pip install fixturify[json-assert]
# or
pip install deepdiff
```

## Basic usage

```python
data = {"name": "John", "age": 30}
JsonAssert(data).compare_to_file("./expected.json")
```

If data doesn't match, `AssertionError` is raised with detailed diff.

## Supported data types

```python
# dict
JsonAssert({"name": "John"}).compare_to_file("./expected.json")

# dataclass
user = User(name="John", age=30)
JsonAssert(user).compare_to_file("./expected.json")

# list
users = [{"name": "John"}, {"name": "Jane"}]
JsonAssert(users).compare_to_file("./expected.json")

# JSON string
json_str = '{"name": "John"}'
JsonAssert(json_str).compare_to_file("./expected.json")
```

## Ignoring fields

### Simple field

```python
data = {"name": "John", "age": 99}  # age differs
JsonAssert(data).ignore("age").compare_to_file("./expected.json")
```

### Nested field

```python
data = {"user": {"name": "John", "profile": {"age": 99, "city": "NYC"}}}
JsonAssert(data).ignore("user.profile.age").compare_to_file("./expected.json")
```

### With root prefix

```python
JsonAssert(data).ignore("root['age']").compare_to_file("./expected.json")
```

### Multiple fields

```python
JsonAssert(data).ignore("name", "age").compare_to_file("./expected.json")

# or chaining
JsonAssert(data).ignore("name").ignore("age").compare_to_file("./expected.json")
```

### Wildcard in lists

```python
users = [
    {"name": "John", "id": 999},
    {"name": "Jane", "id": 888}
]
JsonAssert(users).ignore("root[*]['id']").compare_to_file("./expected.json")
```

## Ignoring via regex

```python
users = [
    {"name": "John", "id": 999},
    {"name": "Jane", "id": 888}
]
JsonAssert(users).ignore_regex(r"root\[\d+\]\['id'\]").compare_to_file("./expected.json")
```

## Comparison options

```python
JsonAssert(data).options(
    ignore_order=True,              # ignore order in lists
    numeric_tolerance=0.001,        # tolerance for floats
    ignore_type_in_groups=[(int, float)],  # treat int and float as equal
).compare_to_file("./expected.json")
```

### ignore_order

```python
# Element order doesn't matter
data = {"tags": ["b", "a", "c"]}
# expected.json: {"tags": ["a", "b", "c"]}
JsonAssert(data).options(ignore_order=True).compare_to_file("./expected.json")
```

### numeric_tolerance

```python
data = {"value": 3.14159}
# expected.json: {"value": 3.14}
JsonAssert(data).options(numeric_tolerance=0.01).compare_to_file("./expected.json")
```

## Full example

```python
from dataclasses import dataclass
from fixturify import JsonAssert

@dataclass
class User:
    id: int
    name: str
    created_at: str

def test_user_response():
    user = User(id=123, name="John", created_at="2024-01-15T10:30:00Z")

    JsonAssert(user)\
        .ignore("id", "created_at")\
        .compare_to_file("./expected_user.json")
```

## ACTUAL output

When comparison fails, actual result is saved to `ACTUAL/` folder next to expected file:

```
tests/
  fixtures/
    expected.json
    ACTUAL/
      expected.json    <- actual result for debugging
```

## Error message

```
JSON COMPARISON FAILED

Expected: ./expected.json
Actual saved to: ./ACTUAL/expected.json

DIFFERENCES:
  Values changed:
    root['name']: 'John' → 'Jane'
    root['age']: 30 → 25
```

## Path resolution

Paths are resolved relative to the file calling `compare_to_file()`:

```
tests/
  test_users.py          <- JsonAssert(data).compare_to_file("./fixtures/expected.json")
  fixtures/
    expected.json        <- this file is used
```
