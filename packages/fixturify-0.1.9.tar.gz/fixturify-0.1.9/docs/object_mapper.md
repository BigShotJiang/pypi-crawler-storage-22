# ObjectMapper

Bidirectional object-to-JSON mapping.

## Import

```python
from fixturify import ObjectMapper
```

## Serialization (object to JSON)

### to_json()

Returns JSON-compatible dict/list:

```python
from dataclasses import dataclass

@dataclass
class User:
    name: str
    age: int

user = User(name="John", age=30)
data = ObjectMapper(user).to_json()
# {"name": "John", "age": 30}
```

### to_json_string()

Returns JSON string:

```python
json_str = ObjectMapper(user).to_json_string()
# '{"name": "John", "age": 30}'

# With indentation
json_str = ObjectMapper(user).to_json_string(indent=2)
```

## Deserialization (JSON to object)

### to_object()

```python
data = {"name": "John", "age": 30}
user = ObjectMapper(data).to_object(User)
# User(name="John", age=30)
```

### From JSON string

```python
json_str = '{"name": "John", "age": 30}'
user = ObjectMapper(json_str).to_object(User)
```

### List of objects

```python
data = [{"name": "John", "age": 30}, {"name": "Jane", "age": 25}]
users = ObjectMapper(data).to_object(User)
# [User(name="John", age=30), User(name="Jane", age=25)]
```

## Supported types

### dataclasses

```python
from dataclasses import dataclass

@dataclass
class User:
    name: str
    age: int

user = User(name="John", age=30)
ObjectMapper(user).to_json()  # {"name": "John", "age": 30}
```

### Pydantic v1/v2

```python
from pydantic import BaseModel

class User(BaseModel):
    name: str
    age: int

user = User(name="John", age=30)
ObjectMapper(user).to_json()
```

### SQLAlchemy

```python
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

class Base(DeclarativeBase):
    pass

class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str]

user = User(id=1, name="John")
ObjectMapper(user).to_json()  # {"id": 1, "name": "John"}
```

### SQLModel

```python
from sqlmodel import SQLModel, Field

class User(SQLModel, table=True):
    id: int = Field(primary_key=True)
    name: str

user = User(id=1, name="John")
ObjectMapper(user).to_json()
```

### Plain Python objects

```python
class User:
    def __init__(self, name: str, age: int):
        self.name = name
        self.age = age

user = User(name="John", age=30)
ObjectMapper(user).to_json()  # {"name": "John", "age": 30}
```

## Nested objects

```python
@dataclass
class Address:
    city: str
    country: str

@dataclass
class User:
    name: str
    address: Address

user = User(name="John", address=Address(city="NYC", country="USA"))
ObjectMapper(user).to_json()
# {"name": "John", "address": {"city": "NYC", "country": "USA"}}
```

## Lists and collections

```python
@dataclass
class Company:
    name: str
    employees: List[User]

company = Company(
    name="Acme",
    employees=[User(name="John", age=30), User(name="Jane", age=25)]
)
ObjectMapper(company).to_json()
# {"name": "Acme", "employees": [{"name": "John", "age": 30}, {"name": "Jane", "age": 25}]}
```

## Special types

### Enums

```python
from enum import Enum

class Status(Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"

@dataclass
class User:
    name: str
    status: Status

user = User(name="John", status=Status.ACTIVE)
ObjectMapper(user).to_json()
# {"name": "John", "status": "active"}

# Deserialization
data = {"name": "John", "status": "active"}
user = ObjectMapper(data).to_object(User)
# user.status == Status.ACTIVE
```

### datetime

```python
from datetime import datetime

@dataclass
class Event:
    name: str
    created_at: datetime

event = Event(name="Meeting", created_at=datetime(2024, 1, 15, 10, 30))
ObjectMapper(event).to_json()
# {"name": "Meeting", "created_at": "2024-01-15T10:30:00"}
```

### UUID

```python
from uuid import UUID

@dataclass
class User:
    id: UUID
    name: str

user = User(id=UUID("12345678-1234-5678-1234-567812345678"), name="John")
ObjectMapper(user).to_json()
# {"id": "12345678-1234-5678-1234-567812345678", "name": "John"}
```

## Circular references

ObjectMapper handles circular references using `$ref`:

```python
@dataclass
class Node:
    value: int
    next: Optional["Node"] = None

a = Node(value=1)
b = Node(value=2)
a.next = b
b.next = a  # circular reference

ObjectMapper(a).to_json()
# {"value": 1, "next": {"value": 2, "next": {"$ref": "#"}}}
```

## Optional fields

```python
@dataclass
class User:
    name: str
    email: Optional[str] = None

user = User(name="John", email=None)
ObjectMapper(user).to_json()
# {"name": "John", "email": null}
```
