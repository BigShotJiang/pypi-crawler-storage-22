# read

Decorator for injecting JSON file data into test functions.

## Import

```python
from fixturify import read
```

## Basic usage

### As dict

```python
@read.fixture(path="./fixtures/config.json", fixture_name="config")
def test_config(config: dict):
    assert config["timeout"] == 30
    assert config["debug"] is True
```

### As object

```python
from dataclasses import dataclass

@dataclass
class User:
    name: str
    age: int

@read.fixture(path="./fixtures/user.json", fixture_name="user", object_class=User)
def test_user(user: User):
    assert user.name == "John"
    assert user.age == 30
```

## Decorator parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `path` | `str` | Path to JSON file (relative to test file) |
| `fixture_name` | `str` | Name of parameter to inject |
| `object_class` | `Type \| None` | Class for deserialization (optional) |

## List of objects

```python
# fixtures/users.json: [{"name": "John", "age": 30}, {"name": "Jane", "age": 25}]

@read.fixture(path="./fixtures/users.json", fixture_name="users", object_class=User)
def test_users(users: List[User]):
    assert len(users) == 2
    assert users[0].name == "John"
```

## Multiple fixtures

```python
@read.fixture(path="./fixtures/user.json", fixture_name="user", object_class=User)
@read.fixture(path="./fixtures/config.json", fixture_name="config")
def test_multiple(user: User, config: dict):
    assert user.name == "John"
    assert config["debug"] is True
```

## With pytest.mark.parametrize

```python
@pytest.mark.parametrize("expected_age", [30])
@read.fixture(path="./fixtures/user.json", fixture_name="user", object_class=User)
def test_parametrized(user: User, expected_age: int):
    assert user.age == expected_age
```

## Async functions

```python
@read.fixture(path="./fixtures/user.json", fixture_name="user", object_class=User)
async def test_async(user: User):
    assert user.name == "John"
```

## Supported object types

Deserialization uses `ObjectMapper`, which supports:
- dataclasses
- Pydantic v1/v2
- SQLAlchemy models
- SQLModel
- Plain Python objects

## Nested objects

```python
@dataclass
class Address:
    city: str

@dataclass
class Company:
    name: str
    employees: List[User]

# fixtures/company.json:
# {"name": "Acme", "employees": [{"name": "John", "age": 30}]}

@read.fixture(path="./fixtures/company.json", fixture_name="company", object_class=Company)
def test_nested(company: Company):
    assert company.name == "Acme"
    assert len(company.employees) == 1
```

## Path resolution

Paths are resolved relative to the test file:

```
tests/
  test_users.py          <- @read.fixture(path="./fixtures/user.json", ...)
  fixtures/
    user.json            <- this file will be used
```
