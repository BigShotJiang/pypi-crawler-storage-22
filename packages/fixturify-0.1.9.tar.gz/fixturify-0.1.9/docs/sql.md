# sql

Decorator for executing SQL files before and/or after tests.

## Import

```python
from fixturify import sql, Phase, SqlTestConfig
```

## Basic usage

```python
@sql(path="./setup.sql")
def test_something():
    # SQL executed before test
    pass
```

## Execution phases

```python
from fixturify import sql, Phase

@sql(path="./setup.sql", phase=Phase.BEFORE)
@sql(path="./cleanup.sql", phase=Phase.AFTER)
def test_with_cleanup():
    # setup.sql executed before test
    # cleanup.sql executed after test (even if test fails)
    pass
```

- `Phase.BEFORE` (default) - execute SQL before test
- `Phase.AFTER` - execute SQL after test

## Database configuration

### Via pytest fixture (recommended)

```python
# conftest.py
import pytest
from fixturify import SqlTestConfig

@pytest.fixture
def sql_config() -> SqlTestConfig:
    return SqlTestConfig(
        driver="psycopg2",
        host="localhost",
        port=5432,
        database="testdb",
        user="postgres",
        password="postgres",
    )
```

Fixture is auto-discovered - no need to pass it to the decorator.

### Directly in decorator

```python
config = SqlTestConfig(
    driver="psycopg2",
    host="localhost",
    database="testdb",
    user="postgres",
    password="postgres",
)

@sql(path="./setup.sql", config=config)
def test_something():
    pass
```

## SqlTestConfig

| Field | Type | Description |
|-------|------|-------------|
| `driver` | `str` | Database driver name |
| `host` | `str` | Database host |
| `database` | `str` | Database name |
| `user` | `str` | Username |
| `password` | `str` | Password |
| `port` | `int \| None` | Port (optional, uses driver default) |

## Supported drivers

| Driver | Database | Type | Default port |
|--------|----------|------|--------------|
| `psycopg2` | PostgreSQL | sync | 5432 |
| `asyncpg` | PostgreSQL | async | 5432 |
| `mysql.connector` | MySQL | sync | 3306 |
| `aiomysql` | MySQL | async | 3306 |
| `sqlite3` | SQLite | sync | - |
| `aiosqlite` | SQLite | async | - |

## Async functions

Decorator automatically handles async functions:

```python
@sql(path="./setup.sql")
async def test_async():
    # Works with asyncpg, aiomysql, aiosqlite
    pass
```

## Multiple decorators

Decorators execute top-to-bottom for BEFORE, bottom-to-top for AFTER:

```python
@sql(path="./first.sql")   # 1st executed
@sql(path="./second.sql")  # 2nd executed
@sql(path="./cleanup.sql", phase=Phase.AFTER)  # 3rd executed after test
def test_order():
    pass
```

## Path resolution

Paths are resolved relative to the test file:

```
tests/
  test_users.py      <- @sql(path="./fixtures/setup.sql")
  fixtures/
    setup.sql        <- this file will be used
```
