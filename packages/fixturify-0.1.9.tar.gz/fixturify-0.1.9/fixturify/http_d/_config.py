"""HTTP mock configuration."""

from dataclasses import dataclass, field
from typing import List, Set


# Default headers to ignore during request matching
DEFAULT_IGNORE_REQUEST_HEADERS: Set[str] = {
    "user-agent",
    "date",
    "accept-encoding",
    "content-length",
    "connection",
    "host",
}

# AWS signing headers to ignore when aws_mode is enabled
# These headers are dynamically generated and differ between requests
DEFAULT_IGNORE_REQUEST_HEADERS_AWS: Set[str] = {
    "authorization",
    "x-amz-date",
    "x-amz-security-token",
    "x-amz-content-sha256",
    # SDK tracking headers - change with each request
    "amz-sdk-invocation-id",
    "amz-sdk-request",
    # Checksum headers - can vary between requests
    "x-amz-checksum-crc32",
    "x-amz-checksum-crc32c",
    "x-amz-checksum-sha1",
    "x-amz-checksum-sha256",
    "x-amz-sdk-checksum-algorithm",
    # Expect header used for large uploads
    "expect",
}

# Default headers to exclude from recording (not saved to file)
DEFAULT_EXCLUDE_REQUEST_HEADERS: Set[str] = {
    "user-agent",
    "accept-encoding",
    "connection",
    "host",
}

DEFAULT_EXCLUDE_RESPONSE_HEADERS: Set[str] = {
    "date",
    "server",
    "x-request-id",
    "x-correlation-id",
    "set-cookie",
    "transfer-encoding",
    "content-length",
}


@dataclass
class HttpTestConfig:
    """
    Configuration for HTTP mock decorator.

    Controls how requests are matched during playback and which headers
    are recorded/compared.

    Attributes:
        ignore_request_headers: Headers to ignore when matching requests.
            These headers can differ between actual and recorded requests.
            Default: User-Agent, Date, Accept-Encoding, Content-Length,
            Connection, Host.

        ignore_response_headers: Headers to ignore when comparing responses
            (for future use in response validation).

        exclude_request_headers: Headers to exclude from recordings entirely.
            These headers won't be saved to the JSON file.
            Default: User-Agent, Accept-Encoding, Connection, Host.

        exclude_response_headers: Headers to exclude from response recordings.
            These headers won't be saved to the JSON file.
            Default: Date, Server, X-Request-ID, X-Correlation-ID,
            Set-Cookie, Transfer-Encoding, Content-Length.

        exclude_hosts: Hosts to exclude from recording and playback entirely.
            Requests to these hosts will ALWAYS make real HTTP calls,
            bypassing recording and playback. Useful for local test servers
            like FastAPI's TestClient (host: "testserver").
            Example: ["testserver", "localhost:8000"]

        match_request_body: Whether to include request body in matching.
            Default: True.

        strict_order: Whether requests must occur in the same order as
            recorded. Default: False.

        redact_request_body: JSON fields to redact in request bodies during
            recording. Any matching field values are replaced with "*******".
            These fields are also ignored during request body comparison in
            playback. Default: [].

        redact_response_body: JSON fields to redact in response bodies during
            recording. Any matching field values are replaced with "*******".
            Default: [].

    Example:
        # Create config to ignore auth headers
        config = HttpTestConfig(
            ignore_request_headers=["Authorization", "X-API-Key"],
            exclude_request_headers=["Authorization"],  # Don't save to file
        )

        @http(path="./fixtures/api.json", config=config)
        def test_api():
            ...

        # Exclude local test server from mocking
        config = HttpTestConfig(
            exclude_hosts=["testserver", "localhost:8000"],
        )

        @http(path="./fixtures/api.json", config=config)
        def test_with_fastapi():
            # Calls to testserver go through normally (real calls)
            # Calls to other hosts are recorded/played back
            ...

        # Or use as a pytest fixture for auto-discovery:
        @pytest.fixture
        def http_config() -> HttpTestConfig:
            return HttpTestConfig(
                ignore_request_headers=["Authorization"],
            )

        @http(path="./fixtures/api.json")  # Config auto-discovered
        def test_api():
            ...
    """

    # Headers to ignore when matching (can differ between actual and recorded)
    ignore_request_headers: List[str] = field(default_factory=list)
    ignore_response_headers: List[str] = field(default_factory=list)

    # Headers to exclude from recording (not saved to file)
    exclude_request_headers: List[str] = field(default_factory=list)
    exclude_response_headers: List[str] = field(default_factory=list)

    # Hosts to exclude from recording/playback (always make real calls)
    exclude_hosts: List[str] = field(default_factory=list)

    # Matching options
    match_request_body: bool = True
    strict_order: bool = False

    # Redaction options
    redact_request_body: List[str] = field(default_factory=list)
    redact_response_body: List[str] = field(default_factory=list)

    # AWS mode: automatically ignore AWS signing headers
    aws_mode: bool = False

    def get_ignore_request_headers_set(self) -> Set[str]:
        """Get full set of headers to ignore during matching."""
        result = DEFAULT_IGNORE_REQUEST_HEADERS.copy()
        result.update(h.lower() for h in self.ignore_request_headers)
        if self.aws_mode:
            result.update(DEFAULT_IGNORE_REQUEST_HEADERS_AWS)
        return result

    def get_ignore_response_headers_set(self) -> Set[str]:
        """Get full set of response headers to ignore during matching."""
        return {h.lower() for h in self.ignore_response_headers}

    def get_exclude_request_headers_set(self) -> Set[str]:
        """Get full set of request headers to exclude from recording."""
        result = DEFAULT_EXCLUDE_REQUEST_HEADERS.copy()
        result.update(h.lower() for h in self.exclude_request_headers)
        if self.aws_mode:
            result.update(DEFAULT_IGNORE_REQUEST_HEADERS_AWS)
        return result

    def get_exclude_response_headers_set(self) -> Set[str]:
        """Get full set of response headers to exclude from recording."""
        result = DEFAULT_EXCLUDE_RESPONSE_HEADERS.copy()
        result.update(h.lower() for h in self.exclude_response_headers)
        return result

    def get_exclude_hosts_set(self) -> Set[str]:
        """Get set of hosts to exclude from recording/playback."""
        return {h.lower() for h in self.exclude_hosts}

    def is_host_excluded(self, url: str) -> bool:
        """
        Check if a URL's host is in the excluded hosts list.

        Args:
            url: Full URL string (e.g., "http://testserver/api/v1")

        Returns:
            True if the host should be excluded from recording/playback.
        """
        from urllib.parse import urlparse

        exclude_hosts = self.get_exclude_hosts_set()
        if not exclude_hosts:
            return False

        parsed = urlparse(url)
        # Check both host and host:port
        host = parsed.netloc.lower()
        hostname = parsed.hostname.lower() if parsed.hostname else ""

        return host in exclude_hosts or hostname in exclude_hosts


# Default config instance
DEFAULT_CONFIG = HttpTestConfig()
