"""Custom exceptions for HTTP mock decorator."""

from typing import Any, Dict, List, Optional

from fixturify.http_d._models import HttpMapping, HttpRequest


class HttpMockError(Exception):
    """Base exception for HTTP mock errors."""

    pass


class NoMatchingRecordingError(HttpMockError):
    """
    Raised when a request is made but no recording matches.

    This occurs during playback mode when an HTTP call is made that
    doesn't match any of the recorded request/response pairs.
    """

    def __init__(
        self,
        request: HttpRequest,
        available_mappings: Optional[List[HttpMapping]] = None,
        message: Optional[str] = None,
    ):
        self.request = request
        self.available_mappings = available_mappings or []

        if message is None:
            message = self._build_message()

        super().__init__(message)

    def _build_message(self) -> str:
        """Build a detailed error message."""
        lines = [
            "No recorded mapping matches the request:",
            f"  Method: {self.request.method}",
            f"  URL: {self.request.url}",
        ]

        if self.request.queryParameters:
            lines.append(f"  Query: {self.request.queryParameters}")

        if self.request.headers:
            # Show only relevant headers (not all)
            relevant_headers = {
                k: v
                for k, v in self.request.headers.items()
                if k.lower() not in ("user-agent", "accept-encoding", "connection")
            }
            if relevant_headers:
                lines.append(f"  Headers: {relevant_headers}")

        if self.request.body:
            body_preview = self.request.body[:100]
            if len(self.request.body) > 100:
                body_preview += "..."
            lines.append(f"  Body: {body_preview}")

        if self.available_mappings:
            lines.append("")
            lines.append(f"Available recordings ({len(self.available_mappings)}):")
            for i, mapping in enumerate(self.available_mappings[:5]):  # Show first 5
                lines.append(
                    f"  [{i + 1}] {mapping.request.method} {mapping.request.url}"
                )
            if len(self.available_mappings) > 5:
                lines.append(f"  ... and {len(self.available_mappings) - 5} more")

        return "\n".join(lines)


class UnusedRecordingsError(HttpMockError):
    """
    Raised when recorded mappings were never matched during playback.

    This indicates that the test's HTTP behavior has changed - it no longer
    makes certain calls that were previously recorded.
    """

    def __init__(
        self,
        unused_mappings: List[HttpMapping],
        message: Optional[str] = None,
    ):
        self.unused_mappings = unused_mappings

        if message is None:
            message = self._build_message()

        super().__init__(message)

    def _build_message(self) -> str:
        """Build a detailed error message."""
        lines = [
            f"Found {len(self.unused_mappings)} unused recording(s):",
            "These recorded HTTP calls were never made during the test:",
        ]

        for i, mapping in enumerate(self.unused_mappings):
            lines.append(f"  [{i + 1}] {mapping.request.method} {mapping.request.url}")

        lines.append("")
        lines.append("This may indicate:")
        lines.append("  - Test logic has changed and no longer makes these calls")
        lines.append("  - Recording file is out of date and should be regenerated")
        lines.append("  - A bug in the test that skips expected HTTP calls")

        return "\n".join(lines)


class RequestMismatchError(HttpMockError):
    """
    Raised when a request partially matches but has differences.

    This provides detailed information about what matched and what didn't,
    helping developers understand why a recording wasn't used.
    """

    def __init__(
        self,
        actual_request: HttpRequest,
        expected_request: HttpRequest,
        mismatches: Dict[str, Any],
        message: Optional[str] = None,
    ):
        self.actual_request = actual_request
        self.expected_request = expected_request
        self.mismatches = mismatches

        if message is None:
            message = self._build_message()

        super().__init__(message)

    def _build_message(self) -> str:
        """Build a detailed error message."""
        lines = [
            "Request does not match recording:",
            f"  URL: {self.actual_request.url}",
            "",
            "Differences found:",
        ]

        for field, (actual, expected) in self.mismatches.items():
            lines.append(f"  {field}:")
            lines.append(f"    Expected: {expected}")
            lines.append(f"    Actual:   {actual}")

        return "\n".join(lines)
