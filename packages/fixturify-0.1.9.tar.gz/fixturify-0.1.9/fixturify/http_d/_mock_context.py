"""HTTP mock context for recording and playback."""

from contextlib import ExitStack
from pathlib import Path
from typing import TYPE_CHECKING, Optional

from ._player import HttpPlayer
from ._recorder import HttpRecorder

if TYPE_CHECKING:
    from ._config import HttpTestConfig
    from ._models import HttpRequest, HttpResponse


class HttpMockContext:
    """
    Manages HTTP recording/playback for a single test.
    
    This is the main entry point for HTTP mocking. It handles:
    - Determining record vs playback mode
    - Installing/uninstalling patches on HTTP clients
    - Recording request/response pairs
    - Playing back recorded responses
    - Verifying all recordings were used
    
    Usage:
        with HttpMockContext(path, config):
            # HTTP calls are intercepted here
            response = requests.get("https://api.example.com")
    """
    
    def __init__(self, path: Path, config: "HttpTestConfig"):
        """
        Initialize the mock context.
        
        Args:
            path: Path to the fixture file for recording/playback
            config: Configuration for HTTP mocking behavior
        """
        self.path = path
        self.config = config
        self.mode = "playback" if path.exists() else "record"
        
        # Initialize recorder or player based on mode
        if self.mode == "record":
            self._recorder: Optional[HttpRecorder] = HttpRecorder(
                path,
                exclude_request_headers=config.get_exclude_request_headers_set(),
                exclude_response_headers=config.get_exclude_response_headers_set(),
                redact_request_body=config.redact_request_body,
                redact_response_body=config.redact_response_body,
            )
            self._player: Optional[HttpPlayer] = None
        else:
            self._recorder = None
            self._player = HttpPlayer(path, config=config)
        
        # Patch management
        self._exit_stack: Optional[ExitStack] = None
    
    def __enter__(self) -> "HttpMockContext":
        """Start HTTP interception by installing patches."""
        from ._patcher import PatcherBuilder
        
        self._exit_stack = ExitStack()
        
        # Build and start all patches
        patcher = PatcherBuilder(self)
        for patch in patcher.build():
            self._exit_stack.enter_context(patch)
        
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Stop HTTP interception and finalize recording/playback."""
        # Stop all patches
        if self._exit_stack:
            self._exit_stack.close()
            self._exit_stack = None
        
        # Handle recording/playback finalization
        if self.mode == "record" and self._recorder is not None:
            self._recorder.save()
        elif self.mode == "playback" and self._player and exc_type is None:
            # Only verify if no exception occurred (don't mask original error)
            self._player.verify_all_used()
        
        return False  # Don't suppress exceptions
    
    def can_play_response_for(self, request: "HttpRequest") -> bool:
        """
        Check if a recorded response exists for the given request.
        
        Args:
            request: The HTTP request to check
            
        Returns:
            True if in playback mode and a matching response exists
        """
        if self._player is None:
            return False
        
        # Try to find a match without consuming it
        try:
            result = self._player.matcher.find_match(
                request, 
                self._player.mappings, 
                self._player.used_indices
            )
            return result is not None
        except Exception:
            return False
    
    def play_response(self, request: "HttpRequest") -> "HttpResponse":
        """
        Get the recorded response for a request.
        
        Args:
            request: The HTTP request to match
            
        Returns:
            The matching recorded response
            
        Raises:
            NoMatchingRecordingError: If no matching recording found
        """
        if self._player is None:
            from ._exceptions import NoMatchingRecordingError
            raise NoMatchingRecordingError(request=request, available_mappings=[])
        
        return self._player.find_response(request)
    
    def record(self, request: "HttpRequest", response: "HttpResponse") -> None:
        """
        Record a request/response pair.
        
        Args:
            request: The HTTP request
            response: The HTTP response
        """
        if self._recorder is not None:
            self._recorder.record(request, response)
    
    def is_host_excluded(self, url: str) -> bool:
        """
        Check if a URL's host is excluded from mocking.
        
        Args:
            url: The URL to check
            
        Returns:
            True if the host should not be mocked
        """
        return self.config.is_host_excluded(url)
