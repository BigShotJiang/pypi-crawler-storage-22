"""Patcher builder for HTTP client mocking.

Uses unittest.mock.patch.object to patch HTTP clients at various levels:
- http.client (covers requests, urllib3, httplib2, boto3)
- httpcore (covers httpx sync and async)
- aiohttp (async HTTP client)
- tornado (async HTTP client)
"""

import contextlib
from typing import TYPE_CHECKING, Dict, Iterator, Type
from unittest import mock

if TYPE_CHECKING:
    from ._mock_context import HttpMockContext


# Save original classes at import time for force_reset()
_originals: Dict[str, object] = {}


def _save_originals():
    """Save original HTTP classes for later restoration."""
    import http.client as httplib
    _originals["httplib.HTTPConnection"] = httplib.HTTPConnection
    _originals["httplib.HTTPSConnection"] = httplib.HTTPSConnection
    
    # urllib3 has its own connection classes
    try:
        import urllib3.connection
        _originals["urllib3.HTTPConnection"] = urllib3.connection.HTTPConnection
        _originals["urllib3.HTTPSConnection"] = urllib3.connection.HTTPSConnection
    except ImportError:
        pass
    
    # urllib3 connection pools have ConnectionCls attribute
    try:
        from urllib3.connectionpool import HTTPConnectionPool, HTTPSConnectionPool
        _originals["urllib3.HTTPConnectionPool.ConnectionCls"] = HTTPConnectionPool.ConnectionCls
        _originals["urllib3.HTTPSConnectionPool.ConnectionCls"] = HTTPSConnectionPool.ConnectionCls
    except ImportError:
        pass
    
    # Also check requests.packages.urllib3 (bundled version)
    try:
        import requests.packages.urllib3.connection as req_urllib3_conn
        _originals["requests.urllib3.HTTPConnection"] = req_urllib3_conn.HTTPConnection
        _originals["requests.urllib3.HTTPSConnection"] = req_urllib3_conn.HTTPSConnection
    except ImportError:
        pass
    
    try:
        from requests.packages.urllib3.connectionpool import (
            HTTPConnectionPool as ReqHTTPConnectionPool,
            HTTPSConnectionPool as ReqHTTPSConnectionPool,
        )
        _originals["requests.urllib3.HTTPConnectionPool.ConnectionCls"] = ReqHTTPConnectionPool.ConnectionCls
        _originals["requests.urllib3.HTTPSConnectionPool.ConnectionCls"] = ReqHTTPSConnectionPool.ConnectionCls
    except ImportError:
        pass
    
    try:
        import httpcore
        _originals["httpcore.ConnectionPool.handle_request"] = (
            httpcore.ConnectionPool.handle_request
        )
        _originals["httpcore.AsyncConnectionPool.handle_async_request"] = (
            httpcore.AsyncConnectionPool.handle_async_request
        )
    except ImportError:
        pass
    
    try:
        import aiohttp.client
        _originals["aiohttp.ClientSession._request"] = (
            aiohttp.client.ClientSession._request
        )
    except ImportError:
        pass
    
    try:
        import tornado.simple_httpclient
        _originals["tornado.SimpleAsyncHTTPClient.fetch_impl"] = (
            tornado.simple_httpclient.SimpleAsyncHTTPClient.fetch_impl
        )
    except ImportError:
        pass
    
    try:
        import tornado.curl_httpclient
        _originals["tornado.CurlAsyncHTTPClient.fetch_impl"] = (
            tornado.curl_httpclient.CurlAsyncHTTPClient.fetch_impl
        )
    except ImportError:
        pass
    
    # httplib2 uses SCHEME_TO_CONNECTION dict
    try:
        import httplib2
        _originals["httplib2.SCHEME_TO_CONNECTION"] = dict(httplib2.SCHEME_TO_CONNECTION)
    except ImportError:
        pass
    
    # botocore has its own connection classes
    try:
        import botocore.awsrequest
        _originals["botocore.AWSHTTPConnectionPool.ConnectionCls"] = (
            botocore.awsrequest.AWSHTTPConnectionPool.ConnectionCls
        )
        _originals["botocore.AWSHTTPSConnectionPool.ConnectionCls"] = (
            botocore.awsrequest.AWSHTTPSConnectionPool.ConnectionCls
        )
    except ImportError:
        pass


# Save originals at module load
_save_originals()


@contextlib.contextmanager
def force_reset():
    """
    Context manager that temporarily restores original HTTP classes.
    
    Used when making real HTTP requests (e.g., in record mode) to avoid
    infinite recursion through our patched classes.
    """
    import http.client as httplib
    
    patchers = []
    
    # Always restore http.client
    patchers.append(mock.patch.object(
        httplib, "HTTPConnection", _originals["httplib.HTTPConnection"]
    ))
    patchers.append(mock.patch.object(
        httplib, "HTTPSConnection", _originals["httplib.HTTPSConnection"]
    ))
    
    # Restore urllib3 if available
    if "urllib3.HTTPConnection" in _originals:
        import urllib3.connection
        patchers.append(mock.patch.object(
            urllib3.connection, "HTTPConnection",
            _originals["urllib3.HTTPConnection"]
        ))
        patchers.append(mock.patch.object(
            urllib3.connection, "HTTPSConnection",
            _originals["urllib3.HTTPSConnection"]
        ))
    
    # Restore urllib3 ConnectionCls
    if "urllib3.HTTPConnectionPool.ConnectionCls" in _originals:
        from urllib3.connectionpool import HTTPConnectionPool, HTTPSConnectionPool
        patchers.append(mock.patch.object(
            HTTPConnectionPool, "ConnectionCls",
            _originals["urllib3.HTTPConnectionPool.ConnectionCls"]
        ))
        patchers.append(mock.patch.object(
            HTTPSConnectionPool, "ConnectionCls",
            _originals["urllib3.HTTPSConnectionPool.ConnectionCls"]
        ))
    
    # Restore requests.packages.urllib3 if available
    if "requests.urllib3.HTTPConnection" in _originals:
        import requests.packages.urllib3.connection as req_urllib3_conn
        patchers.append(mock.patch.object(
            req_urllib3_conn, "HTTPConnection",
            _originals["requests.urllib3.HTTPConnection"]
        ))
        patchers.append(mock.patch.object(
            req_urllib3_conn, "HTTPSConnection",
            _originals["requests.urllib3.HTTPSConnection"]
        ))
    
    # Restore requests.packages.urllib3 ConnectionCls
    if "requests.urllib3.HTTPConnectionPool.ConnectionCls" in _originals:
        from requests.packages.urllib3.connectionpool import (
            HTTPConnectionPool as ReqHTTPConnectionPool,
            HTTPSConnectionPool as ReqHTTPSConnectionPool,
        )
        patchers.append(mock.patch.object(
            ReqHTTPConnectionPool, "ConnectionCls",
            _originals["requests.urllib3.HTTPConnectionPool.ConnectionCls"]
        ))
        patchers.append(mock.patch.object(
            ReqHTTPSConnectionPool, "ConnectionCls",
            _originals["requests.urllib3.HTTPSConnectionPool.ConnectionCls"]
        ))
    
    # Restore httplib2 if available
    if "httplib2.SCHEME_TO_CONNECTION" in _originals:
        import httplib2
        patchers.append(mock.patch.dict(
            httplib2.SCHEME_TO_CONNECTION,
            _originals["httplib2.SCHEME_TO_CONNECTION"],
            clear=True
        ))
    
    # Restore botocore if available
    if "botocore.AWSHTTPConnectionPool.ConnectionCls" in _originals:
        import botocore.awsrequest
        patchers.append(mock.patch.object(
            botocore.awsrequest.AWSHTTPConnectionPool, "ConnectionCls",
            _originals["botocore.AWSHTTPConnectionPool.ConnectionCls"]
        ))
        patchers.append(mock.patch.object(
            botocore.awsrequest.AWSHTTPSConnectionPool, "ConnectionCls",
            _originals["botocore.AWSHTTPSConnectionPool.ConnectionCls"]
        ))
    
    # Restore httpcore if available
    if "httpcore.ConnectionPool.handle_request" in _originals:
        import httpcore
        patchers.append(mock.patch.object(
            httpcore.ConnectionPool, "handle_request",
            _originals["httpcore.ConnectionPool.handle_request"]
        ))
        patchers.append(mock.patch.object(
            httpcore.AsyncConnectionPool, "handle_async_request",
            _originals["httpcore.AsyncConnectionPool.handle_async_request"]
        ))
    
    # Restore aiohttp if available
    if "aiohttp.ClientSession._request" in _originals:
        import aiohttp.client
        patchers.append(mock.patch.object(
            aiohttp.client.ClientSession, "_request",
            _originals["aiohttp.ClientSession._request"]
        ))
    
    # Restore tornado if available
    if "tornado.SimpleAsyncHTTPClient.fetch_impl" in _originals:
        import tornado.simple_httpclient
        patchers.append(mock.patch.object(
            tornado.simple_httpclient.SimpleAsyncHTTPClient, "fetch_impl",
            _originals["tornado.SimpleAsyncHTTPClient.fetch_impl"]
        ))
    
    if "tornado.CurlAsyncHTTPClient.fetch_impl" in _originals:
        import tornado.curl_httpclient
        patchers.append(mock.patch.object(
            tornado.curl_httpclient.CurlAsyncHTTPClient, "fetch_impl",
            _originals["tornado.CurlAsyncHTTPClient.fetch_impl"]
        ))
    
    # Start all patchers
    for patcher in patchers:
        patcher.start()
    
    try:
        yield
    finally:
        # Stop all patchers in reverse order
        for patcher in reversed(patchers):
            patcher.stop()


class PatcherBuilder:
    """
    Builds mock.patch objects for all HTTP clients.
    
    The key insight is that we create dynamic subclasses of our stub classes
    with the mock_context attribute set. This allows the stubs to access
    the mock context without using thread-local storage or context variables.
    """
    
    def __init__(self, mock_context: "HttpMockContext"):
        """
        Initialize the patcher builder.
        
        Args:
            mock_context: The HttpMockContext to use for recording/playback
        """
        self._mock_context = mock_context
        self._class_cache: Dict[Type, Type] = {}
    
    def build(self) -> Iterator[mock._patch]:
        """
        Yield all patches to apply.
        
        Each patch is a context manager that can be entered/exited.
        """
        yield from self._httplib_patches()
        yield from self._urllib3_patches()
        yield from self._httplib2_patches()
        yield from self._botocore_patches()
        yield from self._httpcore_patches()
        yield from self._aiohttp_patches()
        yield from self._tornado_patches()
    
    def _get_stub_with_context(self, stub_class: Type) -> Type:
        """
        Create a subclass of stub_class with mock_context attribute set.
        
        This is the key mechanism for passing context to stubs without
        using thread-local storage. Each test gets its own subclass
        with its own mock_context.
        
        Args:
            stub_class: The stub class to subclass
            
        Returns:
            A new class with mock_context set to self._mock_context
        """
        if stub_class not in self._class_cache:
            # Create dynamic subclass with mock_context attribute
            self._class_cache[stub_class] = type(
                stub_class.__name__,
                (stub_class,),
                {"mock_context": self._mock_context}
            )
        return self._class_cache[stub_class]
    
    def _httplib_patches(self) -> Iterator[mock._patch]:
        """
        Patches for http.client (stdlib).
        
        This covers most HTTP libraries:
        - requests (uses urllib3 which uses http.client)
        - urllib3 (uses http.client)
        - httplib2 (uses http.client)
        - boto3/botocore (uses urllib3)
        """
        import http.client as httplib
        from ._stubs._connection import MockHTTPConnection, MockHTTPSConnection
        
        yield mock.patch.object(
            httplib, "HTTPConnection",
            self._get_stub_with_context(MockHTTPConnection)
        )
        yield mock.patch.object(
            httplib, "HTTPSConnection",
            self._get_stub_with_context(MockHTTPSConnection)
        )
    
    def _urllib3_patches(self) -> Iterator[mock._patch]:
        """
        Patches for urllib3 connection classes.
        
        urllib3 imports HTTPConnection at module load time, so we need
        to patch its own connection module in addition to http.client.
        
        This also covers requests, which uses urllib3 under the hood.
        """
        from ._stubs._connection import MockHTTPConnection, MockHTTPSConnection
        
        mock_http = self._get_stub_with_context(MockHTTPConnection)
        mock_https = self._get_stub_with_context(MockHTTPSConnection)
        
        # Patch urllib3.connection
        try:
            import urllib3.connection
            yield mock.patch.object(
                urllib3.connection, "HTTPConnection", mock_http
            )
            yield mock.patch.object(
                urllib3.connection, "HTTPSConnection", mock_https
            )
        except ImportError:
            pass
        
        # Patch urllib3 connection pool ConnectionCls
        try:
            from urllib3.connectionpool import HTTPConnectionPool, HTTPSConnectionPool
            yield mock.patch.object(
                HTTPConnectionPool, "ConnectionCls", mock_http
            )
            yield mock.patch.object(
                HTTPSConnectionPool, "ConnectionCls", mock_https
            )
        except ImportError:
            pass
        
        # Patch requests.packages.urllib3.connection (bundled urllib3)
        try:
            import requests.packages.urllib3.connection as req_urllib3_conn
            yield mock.patch.object(
                req_urllib3_conn, "HTTPConnection", mock_http
            )
            yield mock.patch.object(
                req_urllib3_conn, "HTTPSConnection", mock_https
            )
        except ImportError:
            pass
        
        # Patch requests.packages.urllib3 connection pool ConnectionCls
        try:
            from requests.packages.urllib3.connectionpool import (
                HTTPConnectionPool as ReqHTTPConnectionPool,
                HTTPSConnectionPool as ReqHTTPSConnectionPool,
            )
            yield mock.patch.object(
                ReqHTTPConnectionPool, "ConnectionCls", mock_http
            )
            yield mock.patch.object(
                ReqHTTPSConnectionPool, "ConnectionCls", mock_https
            )
        except ImportError:
            pass
    
    def _httplib2_patches(self) -> Iterator[mock._patch]:
        """
        Patches for httplib2 connection classes.
        
        httplib2 uses SCHEME_TO_CONNECTION dict to look up connection classes.
        We patch this dict to use our mock classes.
        """
        from ._stubs._connection import MockHTTPConnection, MockHTTPSConnection
        
        mock_http = self._get_stub_with_context(MockHTTPConnection)
        mock_https = self._get_stub_with_context(MockHTTPSConnection)
        
        try:
            import httplib2
            # Patch the scheme-to-connection mapping
            yield mock.patch.dict(
                httplib2.SCHEME_TO_CONNECTION,
                {"http": mock_http, "https": mock_https}
            )
        except ImportError:
            pass
    
    def _botocore_patches(self) -> Iterator[mock._patch]:
        """
        Patches for botocore (boto3) connection classes.
        
        botocore has its own connection pool classes that use
        AWSHTTPConnection and AWSHTTPSConnection.
        """
        from ._stubs._connection import MockHTTPConnection, MockHTTPSConnection
        
        mock_http = self._get_stub_with_context(MockHTTPConnection)
        mock_https = self._get_stub_with_context(MockHTTPSConnection)
        
        try:
            import botocore.awsrequest
            yield mock.patch.object(
                botocore.awsrequest.AWSHTTPConnectionPool, "ConnectionCls", mock_http
            )
            yield mock.patch.object(
                botocore.awsrequest.AWSHTTPSConnectionPool, "ConnectionCls", mock_https
            )
        except ImportError:
            pass
    
    def _httpcore_patches(self) -> Iterator[mock._patch]:
        """
        Patches for httpcore.
        
        This covers:
        - httpx (sync and async)
        - FastAPI TestClient (uses httpx internally)
        """
        try:
            import httpcore
        except ImportError:
            return
        
        from ._stubs._httpcore import make_sync_handler, make_async_handler
        
        yield mock.patch.object(
            httpcore.ConnectionPool, "handle_request",
            make_sync_handler(self._mock_context)
        )
        yield mock.patch.object(
            httpcore.AsyncConnectionPool, "handle_async_request",
            make_async_handler(self._mock_context)
        )
    
    def _aiohttp_patches(self) -> Iterator[mock._patch]:
        """
        Patches for aiohttp.
        
        aiohttp is an async HTTP client that doesn't use http.client.
        """
        try:
            import aiohttp.client
        except ImportError:
            return
        
        from ._stubs._aiohttp import make_aiohttp_request_handler
        
        yield mock.patch.object(
            aiohttp.client.ClientSession, "_request",
            make_aiohttp_request_handler(self._mock_context)
        )
    
    def _tornado_patches(self) -> Iterator[mock._patch]:
        """
        Patches for tornado HTTP clients.
        
        Tornado has multiple HTTP client implementations.
        """
        from ._stubs._tornado import make_tornado_fetch_handler
        
        # SimpleAsyncHTTPClient
        try:
            import tornado.simple_httpclient
            original = _originals.get(
                "tornado.SimpleAsyncHTTPClient.fetch_impl",
                tornado.simple_httpclient.SimpleAsyncHTTPClient.fetch_impl
            )
            yield mock.patch.object(
                tornado.simple_httpclient.SimpleAsyncHTTPClient, "fetch_impl",
                make_tornado_fetch_handler(self._mock_context, original)
            )
        except ImportError:
            pass
        
        # CurlAsyncHTTPClient
        try:
            import tornado.curl_httpclient
            original = _originals.get(
                "tornado.CurlAsyncHTTPClient.fetch_impl",
                tornado.curl_httpclient.CurlAsyncHTTPClient.fetch_impl
            )
            yield mock.patch.object(
                tornado.curl_httpclient.CurlAsyncHTTPClient, "fetch_impl",
                make_tornado_fetch_handler(self._mock_context, original)
            )
        except ImportError:
            pass
