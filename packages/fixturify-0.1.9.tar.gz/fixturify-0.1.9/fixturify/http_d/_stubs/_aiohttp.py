"""Stubs for aiohttp HTTP client.

aiohttp is an async HTTP client that doesn't use http.client,
so it needs its own patching strategy.
"""

import functools
import json
from typing import TYPE_CHECKING, Dict

from .._models import HttpRequest, HttpResponse
from .._recorder import create_request_from_aiohttp, create_response_from_aiohttp

if TYPE_CHECKING:
    from .._mock_context import HttpMockContext


class MockAiohttpStream:
    """Mock stream that wraps a BytesIO for aiohttp compatibility."""
    
    def __init__(self, data: bytes):
        from io import BytesIO
        self._content = BytesIO(data)
    
    async def read(self, n: int = -1) -> bytes:
        return self._content.read(n)
    
    def feed_data(self, data: bytes):
        pos = self._content.tell()
        self._content.seek(0, 2)  # End
        self._content.write(data)
        self._content.seek(pos)
    
    def feed_eof(self):
        pass


class MockAiohttpResponse:
    """Mock aiohttp ClientResponse for playback."""
    
    def __init__(self, request_model: HttpRequest, response_model: HttpResponse):
        self._request_model = request_model
        self._response_model = response_model
        self._body = response_model.get_body_bytes()
        self._read = False
        
        self.status = response_model.status
        self.reason = self._get_reason(response_model.status)
        self._headers = self._build_headers(response_model.headers)
        self._history = ()
        self.cookies = self._build_cookies()
    
    @staticmethod
    def _get_reason(status: int) -> str:
        from http import HTTPStatus
        try:
            return HTTPStatus(status).phrase
        except ValueError:
            return "Unknown"
    
    @staticmethod
    def _build_headers(headers_dict: Dict[str, str]):
        from multidict import CIMultiDict, CIMultiDictProxy
        headers = CIMultiDict()
        for k, v in headers_dict.items():
            headers.add(k, v)
        return CIMultiDictProxy(headers)
    
    def _build_cookies(self):
        from http.cookies import SimpleCookie
        cookies = SimpleCookie()
        for header_value in self._headers.getall("Set-Cookie", []):
            try:
                cookies.load(header_value)
            except Exception:
                pass
        return cookies
    
    @property
    def headers(self):
        return self._headers
    
    @property
    def content(self):
        stream = MockAiohttpStream(self._body)
        stream.feed_eof()
        return stream
    
    @property
    def url(self):
        from yarl import URL
        return URL(self._request_model.url)
    
    @property
    def request_info(self):
        from aiohttp import RequestInfo
        from yarl import URL
        return RequestInfo(
            url=URL(self._request_model.url),
            method=self._request_model.method,
            headers=self._build_headers(self._request_model.headers),
            real_url=URL(self._request_model.url),
        )
    
    @property
    def history(self):
        return self._history
    
    async def read(self) -> bytes:
        self._read = True
        return self._body
    
    async def text(self, encoding: str = "utf-8", errors: str = "strict") -> str:
        return self._body.decode(encoding, errors=errors)
    
    async def json(self, encoding: str = "utf-8", loads=json.loads, **kwargs):
        text = self._body.decode(encoding)
        stripped = text.strip()
        if not stripped:
            return None
        return loads(stripped)
    
    def release(self):
        pass
    
    def close(self):
        pass
    
    async def __aenter__(self):
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        return False


def _serialize_headers(headers) -> Dict[str, str]:
    """Serialize aiohttp headers to dict."""
    result = {}
    for k, v in headers.items():
        result.setdefault(str(k), v)
    return result


def make_aiohttp_request_handler(mock_context: "HttpMockContext"):
    """
    Create patched _request method for aiohttp.ClientSession.
    
    This intercepts all aiohttp requests.
    """
    import aiohttp.client
    original = aiohttp.client.ClientSession._request
    
    @functools.wraps(original)
    async def _request(self, method, url, **kwargs):
        from yarl import URL
        
        # Build URL with params
        str_url = str(url)
        params = kwargs.get("params")
        if params:
            url_obj = URL(str_url)
            url_obj = url_obj.update_query(params)
            str_url = str(url_obj)
        
        # Get headers
        headers = kwargs.get("headers") or {}
        headers = self._prepare_headers(headers)
        
        # Handle auth
        auth = kwargs.get("auth")
        if auth is not None:
            headers["AUTHORIZATION"] = auth.encode()
        
        # Get body
        data = kwargs.get("data")
        if data is None:
            data = kwargs.get("json")
            if data is not None:
                import json as json_module
                data = json_module.dumps(data)
                headers["Content-Type"] = "application/json"
        
        # Create request model
        http_request = create_request_from_aiohttp(
            method=method,
            url=str_url,
            data=data,
            headers=_serialize_headers(headers),
        )
        
        # Check for excluded hosts
        if mock_context.is_host_excluded(http_request.url):
            from .._patcher import force_reset
            with force_reset():
                return await original(self, method, url, **kwargs)
        
        # Check for recorded response
        if mock_context.can_play_response_for(http_request):
            response_model = mock_context.play_response(http_request)
            mock_response = MockAiohttpResponse(http_request, response_model)
            # Update cookies
            self._cookie_jar.update_cookies(mock_response.cookies, mock_response.url)
            return mock_response
        
        # Record mode - make real request and read body
        from .._patcher import force_reset
        with force_reset():
            response = await original(self, method, url, **kwargs)
            # Read response body inside force_reset (uses same connection)
            body = await response.read()
        
        # Create response model
        resp_model = create_response_from_aiohttp(response, body)
        
        # Record the interaction
        mock_context.record(http_request, resp_model)
        
        return response
    
    return _request
