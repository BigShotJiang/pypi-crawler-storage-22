"""Stubs for httpcore HTTP client.

httpcore is the low-level transport layer used by httpx.
By patching at this level, we intercept ALL httpx traffic,
including async requests in FastAPI TestClient.
"""

import functools
from typing import TYPE_CHECKING, Any

from .._models import HttpRequest, HttpResponse
from .._recorder import create_request_from_httpcore, create_response_from_httpcore

if TYPE_CHECKING:
    from .._mock_context import HttpMockContext


def _make_request(httpcore_request: Any) -> HttpRequest:
    """Create HttpRequest from httpcore Request object."""
    # httpcore Request has: method, url, headers, stream
    method = httpcore_request.method
    if isinstance(method, bytes):
        method = method.decode("ascii")
    
    url = bytes(httpcore_request.url).decode("ascii")
    
    # Read body from stream
    body_parts = []
    for chunk in httpcore_request.stream:
        body_parts.append(chunk)
    body = b"".join(body_parts)
    
    # Restore stream for potential real request
    from httpcore._models import ByteStream
    httpcore_request.stream = ByteStream(body)
    
    return create_request_from_httpcore(
        method=method,
        url=url,
        content=body,
        headers=httpcore_request.headers,
    )


async def _make_request_async(httpcore_request: Any) -> HttpRequest:
    """Create HttpRequest from httpcore Request object (async version)."""
    method = httpcore_request.method
    if isinstance(method, bytes):
        method = method.decode("ascii")
    
    url = bytes(httpcore_request.url).decode("ascii")
    
    # Read body from async stream
    body_parts = []
    async for chunk in httpcore_request.stream:
        body_parts.append(chunk)
    body = b"".join(body_parts)
    
    # Restore stream for potential real request
    from httpcore._models import ByteStream
    httpcore_request.stream = ByteStream(body)
    
    return create_request_from_httpcore(
        method=method,
        url=url,
        content=body,
        headers=httpcore_request.headers,
    )


def _build_response(response_model: HttpResponse) -> Any:
    """Build httpcore Response from HttpResponse model."""
    from httpcore import Response
    import gzip
    
    # Get content encoding before filtering headers
    content_encoding = response_model.headers.get(
        "content-encoding", 
        response_model.headers.get("Content-Encoding", "")
    ).lower()
    
    # Build headers as list of tuples
    headers = [
        (k.encode("ascii"), v.encode("ascii"))
        for k, v in response_model.headers.items()
        # Skip headers that cause issues
        if k.lower() not in ("transfer-encoding", "content-encoding")
    ]
    
    body = response_model.get_body_bytes()
    
    # Decompress gzip body if needed (since we removed content-encoding header)
    if content_encoding == "gzip" and body:
        try:
            body = gzip.decompress(body)
        except (gzip.BadGzipFile, OSError):
            pass  # Not actually gzip, use as-is
    
    return Response(
        status=response_model.status,
        headers=headers,
        content=body,
    )


def _serialize_response(httpcore_response: Any) -> HttpResponse:
    """Create HttpResponse from httpcore Response object.
    
    Handles gzip decompression before serialization to ensure
    body is stored as readable text, not binary.
    """
    import gzip
    from .._models import HttpResponse
    
    # Get body - should be available after read()/aread()
    body_bytes = httpcore_response.content
    
    # Convert headers
    headers_dict = {}
    content_encoding = ""
    for k, v in httpcore_response.headers:
        key = k.decode() if isinstance(k, bytes) else k
        val = v.decode() if isinstance(v, bytes) else v
        headers_dict[key] = val
        if key.lower() == "content-encoding":
            content_encoding = val.lower()
    
    # If gzip, decompress body before serialization
    if content_encoding == "gzip" and body_bytes:
        try:
            body_bytes = gzip.decompress(body_bytes)
            # Remove content-encoding header since we decompressed
            headers_dict = {
                k: v for k, v in headers_dict.items()
                if k.lower() != "content-encoding"
            }
        except (gzip.BadGzipFile, OSError):
            pass  # Not actually gzip, use as-is
    
    # Determine content type
    content_type = headers_dict.get("content-type", headers_dict.get("Content-Type", ""))
    
    # Try to decode as text/JSON
    body_str = None
    if body_bytes:
        try:
            body_str = body_bytes.decode("utf-8")
        except UnicodeDecodeError:
            # Binary content - store for file saving
            resp = HttpResponse(
                status=httpcore_response.status,
                headers=headers_dict,
                body=None,
            )
            resp._body_bytes = body_bytes
            return resp
    
    return HttpResponse(
        status=httpcore_response.status,
        headers=headers_dict,
        body=body_str,
    )


def _read_response_body(response: Any) -> bytes:
    """Read response body using httpcore's built-in method.
    
    This properly sets response._content so response.content works.
    """
    return response.read()


async def _read_response_body_async(response: Any) -> bytes:
    """Read response body using httpcore's built-in method (async version).
    
    This properly sets response._content so response.content works.
    """
    return await response.aread()


def make_sync_handler(mock_context: "HttpMockContext"):
    """
    Create patched handle_request for httpcore.ConnectionPool.
    
    This intercepts all synchronous httpx requests.
    """
    import httpcore
    original = httpcore.ConnectionPool.handle_request
    
    @functools.wraps(original)
    def handle_request(self, request):
        # Build our request model
        http_request = _make_request(request)
        
        # Check for excluded hosts
        if mock_context.is_host_excluded(http_request.url):
            from .._patcher import force_reset
            with force_reset():
                return original(self, request)
        
        # Playback mode - require a recorded response
        if mock_context.mode == "playback":
            return _build_response(mock_context.play_response(http_request))
        
        # Record mode - use recording if available
        if mock_context.can_play_response_for(http_request):
            return _build_response(mock_context.play_response(http_request))
        
        # Record mode - make real request and read body
        from .._patcher import force_reset
        with force_reset():
            response = original(self, request)
            # Read response body inside force_reset (uses same connection)
            _read_response_body(response)
        
        # Record the interaction
        resp_model = _serialize_response(response)
        mock_context.record(http_request, resp_model)
        
        # Return new response with body as content (original has consumed stream)
        return _build_response(resp_model)
    
    return handle_request


def make_async_handler(mock_context: "HttpMockContext"):
    """
    Create patched handle_async_request for httpcore.AsyncConnectionPool.
    
    This intercepts all asynchronous httpx requests, including those
    made from FastAPI endpoints via TestClient.
    """
    import httpcore
    original = httpcore.AsyncConnectionPool.handle_async_request
    
    @functools.wraps(original)
    async def handle_async_request(self, request):
        # Build our request model
        http_request = await _make_request_async(request)
        
        # Check for excluded hosts
        if mock_context.is_host_excluded(http_request.url):
            from .._patcher import force_reset
            with force_reset():
                return await original(self, request)
        
        # Playback mode - require a recorded response
        if mock_context.mode == "playback":
            return _build_response(mock_context.play_response(http_request))
        
        # Record mode - use recording if available
        if mock_context.can_play_response_for(http_request):
            return _build_response(mock_context.play_response(http_request))
        
        # Record mode - make real request and read body
        from .._patcher import force_reset
        with force_reset():
            response = await original(self, request)
            # Read response body inside force_reset (uses same connection)
            await _read_response_body_async(response)
        
        # Record the interaction
        resp_model = _serialize_response(response)
        mock_context.record(http_request, resp_model)
        
        # Return new response with body as content (original has consumed stream)
        return _build_response(resp_model)
    
    return handle_async_request
