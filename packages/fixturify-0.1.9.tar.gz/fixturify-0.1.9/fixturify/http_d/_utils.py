"""Utility functions for HTTP recording and playback."""

import json
import mimetypes
from typing import Any, Optional, Tuple, Union


# Content types that should be stored as separate binary files
BINARY_CONTENT_TYPES = (
    "image/",
    "audio/",
    "video/",
    "application/octet-stream",
    "application/pdf",
    "application/zip",
    "application/gzip",
    "application/x-tar",
    "application/x-rar",
    "application/x-7z-compressed",
    "application/vnd.ms-excel",
    "application/vnd.openxmlformats",
    "application/msword",
    "font/",
)


def normalize_content_type(content_type: Union[str, bytes, None]) -> str:
    """Normalize content type to string."""
    if content_type is None:
        return ""
    if isinstance(content_type, bytes):
        return content_type.decode("utf-8", errors="ignore")
    return content_type


def is_text_content_type(content_type: Union[str, bytes]) -> bool:
    """Check if content type indicates text content."""
    text_types = (
        "text/",
        "application/json",
        "application/xml",
        "application/javascript",
        "application/x-www-form-urlencoded",
    )
    content_str = normalize_content_type(content_type)
    return any(t in content_str.lower() for t in text_types)


def is_json_content_type(content_type: Union[str, bytes]) -> bool:
    """Check if content type indicates JSON content."""
    content_str = normalize_content_type(content_type)
    return "application/json" in content_str.lower()


def is_binary_content_type(content_type: Union[str, bytes]) -> bool:
    """Check if content type indicates binary content that should be stored as file."""
    content_str = normalize_content_type(content_type)
    content_lower = content_str.lower()
    return any(t in content_lower for t in BINARY_CONTENT_TYPES)


def try_parse_json(content: str) -> Any:
    """Try to parse string as JSON, return parsed or original string."""
    try:
        return json.loads(content)
    except (json.JSONDecodeError, TypeError):
        return content


def get_file_extension(content_type: Union[str, bytes]) -> str:
    """Get appropriate file extension for a content type."""
    extension_map = {
        "application/json": ".json",
        "application/pdf": ".pdf",
        "application/zip": ".zip",
        "application/gzip": ".gz",
        "application/xml": ".xml",
        "text/html": ".html",
        "text/plain": ".txt",
        "text/css": ".css",
        "text/javascript": ".js",
        "image/jpeg": ".jpg",
        "image/png": ".png",
        "image/gif": ".gif",
        "image/webp": ".webp",
        "image/svg+xml": ".svg",
        "audio/mpeg": ".mp3",
        "audio/wav": ".wav",
        "video/mp4": ".mp4",
        "video/webm": ".webm",
    }

    content_str = normalize_content_type(content_type)
    content_lower = content_str.lower().split(";")[0].strip()
    
    if content_lower in extension_map:
        return extension_map[content_lower]

    ext = mimetypes.guess_extension(content_lower)
    if ext:
        return ext

    return ".bin"


def serialize_body(
    body: Optional[Union[bytes, str]],
    content_type: Union[str, bytes] = "",
) -> Tuple[Any, Optional[str], bool]:
    """
    Serialize body for storage.

    For JSON content: returns parsed JSON object (not stringified)
    For text content: returns string
    For binary content: returns raw bytes and flag to save as file

    Args:
        body: Request or response body (bytes, string, or BytesIO)
        content_type: Content-Type header value (str or bytes)

    Returns:
        Tuple of (body_value, encoding, is_binary_file)
        - For text/JSON: (value, None, False)
        - For binary: (bytes, None, True)
    """
    if body is None:
        return None, None, False

    # Handle BytesIO and other file-like objects
    if hasattr(body, "read"):
        file_obj = body
        body = file_obj.read()
        if hasattr(file_obj, "seek"):
            file_obj.seek(0)

    # Normalize content_type to string
    content_type = normalize_content_type(content_type)

    # Check if this should be stored as a binary file
    if is_binary_content_type(content_type):
        if isinstance(body, bytes):
            return body, None, True
        elif isinstance(body, str):
            return body.encode("utf-8"), None, True
        else:
            return str(body).encode("utf-8"), None, True

    # Convert bytes to string if needed
    if isinstance(body, bytes):
        if is_text_content_type(content_type) or not content_type:
            try:
                body_str = body.decode("utf-8")
            except UnicodeDecodeError:
                return body, None, True
        else:
            try:
                body_str = body.decode("utf-8")
            except UnicodeDecodeError:
                return body, None, True
    else:
        body_str = body

    # Empty body
    if not body_str:
        return None, None, False

    # For JSON content, parse and store as native JSON
    if is_json_content_type(content_type):
        return try_parse_json(body_str), None, False

    # Return as string for non-JSON text content
    return body_str, None, False


def normalize_headers(headers: Any) -> dict:
    """
    Normalize headers to a dict with string keys and values.
    
    Handles:
    - Dict with bytes keys/values
    - List of tuples
    - Dict-like objects with items() method
    """
    result = {}
    if headers is None:
        return result
    
    items = headers.items() if hasattr(headers, "items") else headers
    for k, v in items:
        key = k.decode("utf-8") if isinstance(k, bytes) else str(k)
        val = v.decode("utf-8") if isinstance(v, bytes) else str(v)
        result[key] = val
    
    return result
