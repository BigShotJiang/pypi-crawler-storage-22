"""Main JsonAssert class with fluent API."""

import json
from typing import Any, Dict, List, Optional

from fixturify._utils._constants import ENCODING
from fixturify._utils._path_resolver import _PathResolver
from fixturify.json_assert._normalizer import _Normalizer
from fixturify.json_assert._comparator import _Comparator
from fixturify.json_assert._diff_formatter import _DiffFormatter
from fixturify.json_assert._actual_saver import _ActualSaver


class JsonAssert:
    """
    JSON comparison assertions for testing.

    Provides a fluent API for comparing Python objects/data to JSON files.

    Example:
        JsonAssert(user).compare_to_file("./expected.json")

        JsonAssert(response)
            .ignore("root['id']", "root['timestamp']")
            .options(ignore_order=True)
            .compare_to_file("./expected.json")
    """

    def __init__(self, data: Any) -> None:
        """
        Initialize JsonAssert with data to compare.

        Args:
            data: The actual data to compare against expected JSON file.
                  Can be: object, list of objects, dict, or JSON string.
        """
        self._data = data
        self._normalizer = _Normalizer()
        self._exclude_paths: List[str] = []
        self._exclude_regex_paths: List[str] = []
        self._ignore_order: bool = False
        self._numeric_tolerance: Optional[float] = None
        self._ignore_type_in_groups: Optional[List[tuple]] = None
        self._extra_options: Dict[str, Any] = {}

    def ignore(self, *paths: str) -> "JsonAssert":
        """
        Specify paths to ignore during comparison.

        Supports both bracket notation and dot notation:
        - "id" or "root['id']" - top-level field
        - "user.name" or "root['user']['name']" - nested field
        - "users[*].id" - field in all list items (wildcard)

        Args:
            *paths: Paths to ignore

        Returns:
            Self for method chaining (accumulates with previous calls)
        """
        self._exclude_paths.extend(paths)
        return self

    def ignore_regex(self, *patterns: str) -> "JsonAssert":
        """
        Specify regex patterns to ignore during comparison.

        Use this for ignoring fields across all list indices with complex patterns.

        Pattern syntax (regex):
        - r"root\\[\\d+\\]\\['id'\\]" - 'id' in any list item
        - r"root\\['users'\\]\\[\\d+\\]\\['email'\\]" - 'email' in any user

        Args:
            *patterns: Regex patterns to ignore

        Returns:
            Self for method chaining (accumulates with previous calls)
        """
        self._exclude_regex_paths.extend(patterns)
        return self

    def options(
        self,
        ignore_order: bool = False,
        numeric_tolerance: Optional[float] = None,
        ignore_type_in_groups: Optional[List[tuple]] = None,
        **kwargs,
    ) -> "JsonAssert":
        """
        Set comparison options.

        Args:
            ignore_order: If True, ignore order in lists/arrays
            numeric_tolerance: Tolerance for float comparisons (e.g., 0.001)
            ignore_type_in_groups: Type groups to treat as equal (e.g., [(int, float)])
            **kwargs: Additional deepdiff options

        Returns:
            Self for method chaining
        """
        if ignore_order:
            self._ignore_order = True

        if numeric_tolerance is not None:
            self._numeric_tolerance = numeric_tolerance

        if ignore_type_in_groups is not None:
            self._ignore_type_in_groups = ignore_type_in_groups

        self._extra_options.update(kwargs)
        return self

    def compare_to_file(self, relative_path: str) -> None:
        """
        Compare data to JSON file. Raises AssertionError if different.

        Args:
            relative_path: Path to JSON file, relative to caller's location

        Raises:
            AssertionError: If data doesn't match file content (with diff details)
            FileNotFoundError: If JSON file doesn't exist
            ValueError: If data can't be converted or file can't be parsed
        """
        # Resolve the path relative to the caller's file
        # Use centralized caller detection from _PathResolver
        caller_file = _PathResolver._get_caller_file(stack_level=1)
        expected_path = _PathResolver.resolve(relative_path, caller_file)

        # Read and parse the expected JSON file
        try:
            content = expected_path.read_text(encoding=ENCODING)
            expected_data = json.loads(content)
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON in expected file {expected_path}: {e}")

        # Normalize the actual data
        try:
            actual_data = self._normalizer.normalize(self._data)
        except ValueError as e:
            raise ValueError(f"Cannot normalize actual data: {e}")

        # Create comparator with accumulated options
        comparator = _Comparator(
            exclude_paths=self._exclude_paths,
            exclude_regex_paths=self._exclude_regex_paths,
            ignore_order=self._ignore_order,
            numeric_tolerance=self._numeric_tolerance,
            ignore_type_in_groups=self._ignore_type_in_groups,
            extra_options=self._extra_options,
        )

        # Perform comparison
        result = comparator.compare(actual_data, expected_data)

        if not result.is_equal:
            # Save actual data to ACTUAL folder
            actual_saved_path, save_ok = _ActualSaver.save(actual_data, expected_path)

            # Format the diff
            formatted = _DiffFormatter.format(
                result.diff,
                expected_path=str(relative_path),
                actual_saved_path=str(actual_saved_path),
                save_failed=not save_ok,
            )

            # Print to stderr for test visibility
            _DiffFormatter.print_diff(formatted)

            # Raise AssertionError with formatted message
            raise AssertionError(f"\n{formatted}")
