"""Comparator using deepdiff for JSON comparison."""

import re
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Union

from deepdiff import DeepDiff


@dataclass
class CompareResult:
    """Result of a comparison operation."""

    is_equal: bool
    diff: Optional[DeepDiff] = None


class _Comparator:
    """Handles the actual comparison using deepdiff."""

    def __init__(
        self,
        exclude_paths: List[str] = None,
        exclude_regex_paths: List[str] = None,
        ignore_order: bool = False,
        numeric_tolerance: Optional[float] = None,
        ignore_type_in_groups: Optional[List[tuple]] = None,
        extra_options: Dict[str, Any] = None,
    ):
        """
        Initialize the comparator with options.

        Args:
            exclude_paths: Exact paths to ignore (deepdiff exclude_paths)
            exclude_regex_paths: Regex patterns to ignore (deepdiff exclude_regex_paths)
            ignore_order: If True, ignore order in lists
            numeric_tolerance: Tolerance for float comparisons
            ignore_type_in_groups: Type groups to treat as equal
            extra_options: Additional deepdiff options
        """
        self._exclude_paths = exclude_paths or []
        self._exclude_regex_paths = exclude_regex_paths or []
        self._ignore_order = ignore_order
        self._numeric_tolerance = numeric_tolerance
        self._ignore_type_in_groups = ignore_type_in_groups
        self._extra_options = extra_options or {}

    def compare(
        self, actual: Union[dict, list], expected: Union[dict, list]
    ) -> CompareResult:
        """
        Compare actual vs expected data using DeepDiff.

        Args:
            actual: The actual data
            expected: The expected data

        Returns:
            CompareResult with is_equal bool and diff details
        """
        options = self._build_deepdiff_options()

        # Use verbose_level=2 to preserve actual values for added/removed items
        # This allows the diff formatter to show the values, not just the paths
        diff = DeepDiff(expected, actual, verbose_level=2, **options)

        return CompareResult(is_equal=not bool(diff), diff=diff if diff else None)

    def _build_deepdiff_options(self) -> Dict[str, Any]:
        """Build options dict for DeepDiff."""
        options = {}

        # Normalize and process exclude paths
        normalized_paths = []
        additional_regex_paths = list(self._exclude_regex_paths)

        for path in self._exclude_paths:
            normalized = self._normalize_path(path)
            if self._has_wildcard(normalized):
                # Convert wildcard to regex
                regex_pattern = self._convert_wildcard_to_regex(normalized)
                additional_regex_paths.append(regex_pattern)
            else:
                normalized_paths.append(normalized)

        if normalized_paths:
            options["exclude_paths"] = set(normalized_paths)

        if additional_regex_paths:
            options["exclude_regex_paths"] = [
                re.compile(p) for p in additional_regex_paths
            ]

        if self._ignore_order:
            options["ignore_order"] = True

        if self._numeric_tolerance is not None:
            options["math_epsilon"] = self._numeric_tolerance

        if self._ignore_type_in_groups:
            options["ignore_type_in_groups"] = self._ignore_type_in_groups

        # Add any extra options
        options.update(self._extra_options)

        return options

    def _normalize_path(self, path: str) -> str:
        """
        Normalize path to deepdiff format.

        Converts:
        - Simple field names to root['field']
        - Dot notation to bracket notation
        - Preserves [n] and [*] index notation

        Examples:
            "id" -> "root['id']"
            "user.name" -> "root['user']['name']"
            "users[0].name" -> "root['users'][0]['name']"
            "users[*].id" -> "root['users'][*]['id']"
            "root['users'][*].id" -> "root['users'][*]['id']"
        """
        # If already in pure bracket format (no dots after root), return as-is
        if path.startswith("root[") and "." not in path:
            return path

        # If it doesn't start with root, add it
        if not path.startswith("root"):
            path = f"root.{path}"

        # Convert dot notation to bracket notation
        # But preserve [n] and [*] indices
        result = ""
        i = 0
        while i < len(path):
            char = path[i]

            if char == ".":
                # Start of a new segment
                i += 1
                # Find the end of this segment (next . or [)
                segment_start = i
                while i < len(path) and path[i] not in ".[]":
                    i += 1
                segment = path[segment_start:i]
                if segment:
                    result += f"['{segment}']"
            elif char == "[":
                # Copy the bracket notation as-is
                bracket_start = i
                i += 1
                while i < len(path) and path[i] != "]":
                    i += 1
                i += 1  # Include the ]
                result += path[bracket_start:i]
            else:
                # Part of 'root' or other text before first . or [
                segment_start = i
                while i < len(path) and path[i] not in ".[]":
                    i += 1
                segment = path[segment_start:i]
                result += segment

        return result

    def _has_wildcard(self, path: str) -> bool:
        """Check if path contains [*] wildcard."""
        return "[*]" in path

    def _convert_wildcard_to_regex(self, path: str) -> str:
        r"""
        Convert wildcard [*] syntax to deepdiff regex pattern.

        Example:
            "root['users'][*]['id']" -> r"root\['users'\]\[\d+\]\['id'\]"
        """
        # Escape special regex characters
        escaped = re.escape(path)
        # Convert escaped [*] back to regex pattern for any index
        # re.escape turns [*] into \[\*\]
        regex = escaped.replace(r"\[\*\]", r"\[\d+\]")
        return regex
