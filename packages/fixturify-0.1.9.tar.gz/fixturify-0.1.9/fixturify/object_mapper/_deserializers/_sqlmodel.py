"""SQLModel model deserializer."""

from typing import Type, TypeVar

from fixturify.object_mapper._deserializers._base import _BaseDeserializer

T = TypeVar("T")


class _SQLModelDeserializer(_BaseDeserializer):
    """Deserializer for SQLModel models."""

    def deserialize(self, data: dict, target_class: Type[T]) -> T:
        """
        Deserialize a dictionary to a SQLModel model.

        SQLModel combines Pydantic v2 and SQLAlchemy. We use Pydantic's
        model_validate for deserialization as it handles validation.

        Args:
            data: Dictionary data to deserialize
            target_class: The SQLModel model class

        Returns:
            Instance of target_class
        """
        # SQLModel uses Pydantic v2's model_validate
        if hasattr(target_class, "model_validate"):
            return target_class.model_validate(data)

        # Fallback to constructor
        return target_class(**data)

    def _deserialize_nested(self, data: dict, target_class: Type[T]) -> T:
        """Deserialize a nested SQLModel model."""
        # Check if it's a SQLModel model
        if hasattr(target_class, "__tablename__") and hasattr(
            target_class, "model_fields"
        ):
            return self.deserialize(data, target_class)

        # For non-SQLModel nested objects, try basic instantiation
        return target_class(**data)
