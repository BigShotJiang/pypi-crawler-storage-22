"""Pydantic v2 model serializer."""

from typing import Any

from fixturify.object_mapper._serializers._base import _BaseSerializer


class _PydanticV2Serializer(_BaseSerializer):
    """Serializer for Pydantic v2 models."""

    def serialize(self, obj: Any) -> dict:
        """
        Serialize a Pydantic v2 model to a dictionary.

        Args:
            obj: A Pydantic v2 model instance

        Returns:
            Dictionary representation of the model
        """
        self.reset()
        return self._serialize_with_path(obj, "#")

    def _serialize_object(self, obj: Any, path: str) -> dict:
        """Serialize a Pydantic v2 model."""
        # Check if this is a Pydantic v2 model
        if hasattr(type(obj), "model_fields"):
            return self._serialize_pydantic_v2(obj, path)

        # Fall back to base implementation for nested non-Pydantic objects
        return super()._serialize_object(obj, path)

    def _serialize_pydantic_v2(self, obj: Any, path: str) -> dict:
        """Serialize a Pydantic v2 model using its model_fields."""
        result = {}

        # Get fields from model_fields
        model_fields = getattr(type(obj), "model_fields", {})

        for field_name in model_fields:
            # Skip dunder fields
            if self._is_dunder(field_name):
                continue

            value = getattr(obj, field_name)
            item_path = f"{path}/{field_name}"
            result[field_name] = self._serialize_value(value, item_path)

        return result
