"""SQLAlchemy model serializer."""

from typing import Any

from fixturify.object_mapper._serializers._base import _BaseSerializer


class _SQLAlchemySerializer(_BaseSerializer):
    """Serializer for SQLAlchemy models."""

    def serialize(self, obj: Any) -> dict:
        """
        Serialize a SQLAlchemy model to a dictionary.

        Args:
            obj: A SQLAlchemy model instance

        Returns:
            Dictionary representation of the model
        """
        self.reset()
        return self._serialize_with_path(obj, "#")

    def _serialize_object(self, obj: Any, path: str) -> dict:
        """Serialize a SQLAlchemy model."""
        obj_type = type(obj)

        # Check if this is a SQLAlchemy model
        if hasattr(obj_type, "__tablename__") and hasattr(obj_type, "__mapper__"):
            return self._serialize_sqlalchemy(obj, path)

        # Fall back to base implementation for nested non-SQLAlchemy objects
        return super()._serialize_object(obj, path)

    def _serialize_sqlalchemy(self, obj: Any, path: str) -> dict:
        """Serialize a SQLAlchemy model using its mapper columns."""
        result = {}

        # Get the mapper for column information
        mapper = getattr(type(obj), "__mapper__", None)
        if mapper is None:
            return result

        # Iterate over column properties
        for column in mapper.columns:
            column_name = column.key

            # Skip dunder fields
            if self._is_dunder(column_name):
                continue

            value = getattr(obj, column_name, None)
            item_path = f"{path}/{column_name}"
            result[column_name] = self._serialize_value(value, item_path)

        # Also handle relationships if loaded (not lazy)
        for relationship in mapper.relationships:
            rel_name = relationship.key

            # Skip dunder fields
            if self._is_dunder(rel_name):
                continue

            # Check if the relationship is loaded
            if rel_name in obj.__dict__:
                value = getattr(obj, rel_name, None)
                item_path = f"{path}/{rel_name}"
                result[rel_name] = self._serialize_value(value, item_path)

        return result
