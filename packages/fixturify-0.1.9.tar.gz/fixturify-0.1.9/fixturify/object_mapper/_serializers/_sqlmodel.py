"""SQLModel model serializer."""

from typing import Any

from fixturify.object_mapper._serializers._base import _BaseSerializer


class _SQLModelSerializer(_BaseSerializer):
    """Serializer for SQLModel models."""

    def serialize(self, obj: Any) -> dict:
        """
        Serialize a SQLModel model to a dictionary.

        SQLModel combines Pydantic v2 and SQLAlchemy, so we use
        Pydantic's model_fields for serialization.

        Args:
            obj: A SQLModel model instance

        Returns:
            Dictionary representation of the model
        """
        self.reset()
        return self._serialize_with_path(obj, "#")

    def _serialize_object(self, obj: Any, path: str) -> dict:
        """Serialize a SQLModel model."""
        obj_type = type(obj)

        # Check if this is a SQLModel model (has both __tablename__ and model_fields)
        if hasattr(obj_type, "__tablename__") and hasattr(obj_type, "model_fields"):
            return self._serialize_sqlmodel(obj, path)

        # Fall back to base implementation for nested non-SQLModel objects
        return super()._serialize_object(obj, path)

    def _serialize_sqlmodel(self, obj: Any, path: str) -> dict:
        """Serialize a SQLModel using its model_fields (Pydantic v2 style)."""
        result = {}

        # Get fields from model_fields (Pydantic v2)
        model_fields = getattr(type(obj), "model_fields", {})

        for field_name in model_fields:
            # Skip dunder fields
            if self._is_dunder(field_name):
                continue

            value = getattr(obj, field_name)
            item_path = f"{path}/{field_name}"
            result[field_name] = self._serialize_value(value, item_path)

        return result
