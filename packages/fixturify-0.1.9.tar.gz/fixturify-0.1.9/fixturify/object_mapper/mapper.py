"""Main ObjectMapper class for bidirectional object-to-JSON mapping."""

import json
from enum import Enum
from typing import Any, List, Optional, Type, TypeVar, Union

from fixturify.object_mapper._detectors import _TypeDetector, ObjectType
from fixturify.object_mapper._serializers import (
    _BaseSerializer,
    _DataclassSerializer,
    _PlainObjectSerializer,
    _PydanticV1Serializer,
    _PydanticV2Serializer,
    _SQLAlchemySerializer,
    _SQLModelSerializer,
)
from fixturify.object_mapper._deserializers import (
    _DataclassDeserializer,
    _PlainObjectDeserializer,
    _PydanticV1Deserializer,
    _PydanticV2Deserializer,
    _SQLAlchemyDeserializer,
    _SQLModelDeserializer,
)

T = TypeVar("T")


class ObjectMapper:
    """
    Universal object-to-JSON mapper supporting multiple object types.

    Supports:
    - Plain Python objects
    - Dataclasses
    - Pydantic v1 models
    - Pydantic v2 models
    - SQLAlchemy models
    - SQLModel models
    - Collections (list, tuple, set)
    - Dictionaries
    """

    # Serializer instances (lazy-loaded)
    _serializers = {
        ObjectType.DATACLASS: _DataclassSerializer,
        ObjectType.PYDANTIC_V1: _PydanticV1Serializer,
        ObjectType.PYDANTIC_V2: _PydanticV2Serializer,
        ObjectType.SQLALCHEMY: _SQLAlchemySerializer,
        ObjectType.SQLMODEL: _SQLModelSerializer,
        ObjectType.PLAIN_OBJECT: _PlainObjectSerializer,
    }

    # Deserializer instances (lazy-loaded)
    _deserializers = {
        ObjectType.DATACLASS: _DataclassDeserializer,
        ObjectType.PYDANTIC_V1: _PydanticV1Deserializer,
        ObjectType.PYDANTIC_V2: _PydanticV2Deserializer,
        ObjectType.SQLALCHEMY: _SQLAlchemyDeserializer,
        ObjectType.SQLMODEL: _SQLModelDeserializer,
        ObjectType.PLAIN_OBJECT: _PlainObjectDeserializer,
    }

    # Flag to track if serializer registry has been set
    _registry_initialized = False

    @classmethod
    def _ensure_registry_initialized(cls) -> None:
        """Initialize the serializer registry for nested object routing."""
        if not cls._registry_initialized:
            _BaseSerializer.set_serializer_registry(cls._serializers)
            cls._registry_initialized = True

    def __init__(self, data: Any) -> None:
        """
        Initialize ObjectMapper with data.

        Args:
            data: Any data - object, collection, dict, or JSON string
        """
        # Ensure serializer registry is initialized for nested type routing
        ObjectMapper._ensure_registry_initialized()

        self._data = data
        self._data_type = _TypeDetector.detect(data)

    def to_json(self) -> Any:
        """
        Convert stored object/collection to JSON-compatible value.

        Returns:
            JSON-compatible value: dict, list, or primitive (str, int, float, bool, None)

        Raises:
            ValueError: If serialization fails
        """
        try:
            return self._serialize(self._data)
        except Exception as e:
            raise ValueError(f"Serialization failed: {e}") from e

    def to_json_string(self, indent: Optional[int] = None) -> str:
        """
        Convert stored object/collection to JSON string.

        Args:
            indent: Optional indentation level for pretty printing

        Returns:
            JSON string representation

        Raises:
            ValueError: If serialization fails
        """
        try:
            serialized = self._serialize(self._data)
            return json.dumps(serialized, indent=indent, ensure_ascii=False)
        except Exception as e:
            raise ValueError(f"Serialization failed: {e}") from e

    def to_object(self, target_class: Type[T]) -> Union[T, List[T]]:
        """
        Convert stored JSON/dict to object or list of objects.

        Args:
            target_class: The class to deserialize into

        Returns:
            Instance of target_class, or list of instances if input is a list

        Raises:
            ValueError: If deserialization fails
            TypeError: If target_class is unsupported
        """
        try:
            # Parse JSON string if needed
            if self._data_type == ObjectType.JSON_STRING:
                data = json.loads(self._data)
                # If parsed data is a primitive (e.g., string for enum), handle it
                if not isinstance(data, (dict, list)):
                    return self._deserialize_primitive(data, target_class)
            elif self._data_type == ObjectType.DICT:
                data = self._data
            elif self._data_type == ObjectType.COLLECTION:
                # If it's already a collection, use it directly
                data = list(self._data)
            elif self._data_type == ObjectType.PRIMITIVE:
                # Handle primitive types (for Enum deserialization)
                return self._deserialize_primitive(self._data, target_class)
            else:
                raise ValueError(
                    f"to_object() requires JSON string, dict, or collection. "
                    f"Got: {self._data_type}"
                )

            # Handle list of objects
            if isinstance(data, list):
                return self._deserialize_list(data, target_class)

            # Handle single object
            return self._deserialize(data, target_class)

        except Exception as e:
            if isinstance(e, (ValueError, TypeError)):
                raise
            raise ValueError(f"Deserialization failed: {e}") from e

    def _serialize(self, data: Any) -> Any:
        """
        Serialize data to a JSON-compatible format.

        Uses a single serializer instance for the entire serialization to ensure
        shared reference tracking (via $ref) works correctly across all items
        in root-level dicts and collections.

        Args:
            data: Data to serialize

        Returns:
            JSON-compatible dict, list, or primitive
        """
        data_type = _TypeDetector.detect(data)

        # Handle primitives directly (no need for serializer)
        if data_type == ObjectType.PRIMITIVE:
            if isinstance(data, Enum):
                return data.value
            return data

        # Handle JSON string (return parsed)
        if data_type == ObjectType.JSON_STRING:
            return json.loads(data)

        # For dicts, collections, and objects, use a single serializer instance
        # to maintain shared visited state across the entire serialization tree.
        # This ensures $ref works correctly for shared objects in root collections/dicts.
        serializer = _PlainObjectSerializer()
        serializer.reset()
        return serializer._serialize_value(data, "#")

    def _deserialize(self, data: dict, target_class: Type[T]) -> T:
        """
        Deserialize a dict to an object.

        Args:
            data: Dictionary data
            target_class: Target class

        Returns:
            Instance of target_class
        """
        # Detect target class type
        class_type = _TypeDetector.detect_class(target_class)

        # Get appropriate deserializer
        deserializer_class = self._deserializers.get(class_type)
        if deserializer_class is None:
            raise TypeError(f"Unsupported target class type: {class_type}")

        deserializer = deserializer_class()
        return deserializer.deserialize(data, target_class)

    def _deserialize_list(self, data: list, target_class: Type[T]) -> List[T]:
        """
        Deserialize a list to a list of objects.

        Args:
            data: List of items (dicts for objects, or primitives for Enums)
            target_class: Target class for each item

        Returns:
            List of target_class instances
        """
        result = []
        for item in data:
            if isinstance(item, dict):
                result.append(self._deserialize(item, target_class))
            else:
                # Handle primitives (e.g., list of Enums or simple values)
                result.append(self._deserialize_primitive(item, target_class))
        return result

    def _deserialize_primitive(self, data: Any, target_class: Type[T]) -> T:
        """
        Deserialize a primitive value to a target class (e.g., Enum).

        Args:
            data: Primitive value
            target_class: Target class (e.g., Enum subclass)

        Returns:
            Instance of target_class
        """
        if isinstance(target_class, type) and issubclass(target_class, Enum):
            return target_class(data)
        return data
