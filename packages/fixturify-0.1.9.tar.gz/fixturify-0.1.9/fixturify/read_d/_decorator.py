"""Read decorator implementation for injecting test fixtures."""

import asyncio
import functools
import inspect
from typing import Callable, Optional, Type, TypeVar, List

from fixturify.read_d._fixture_loader import _FixtureLoader

T = TypeVar("T")


def _unwrap_func(func: Callable) -> Callable:
    """Return the original function by walking the __wrapped__ chain."""
    original = func
    while hasattr(original, "__wrapped__"):
        original = original.__wrapped__
    return original


def _get_base_signature(func: Callable) -> inspect.Signature:
    """Return the most accurate signature, honoring custom __signature__."""
    if hasattr(func, "__signature__"):
        return func.__signature__  # type: ignore
    return inspect.signature(func)


def _create_new_signature(
    original_sig: inspect.Signature, fixture_names: List[str]
) -> inspect.Signature:
    """
    Create a new signature that excludes the fixture parameter names.

    This prevents pytest from trying to inject these parameters as pytest fixtures.
    """
    new_params = [
        param
        for param in original_sig.parameters.values()
        if param.name not in fixture_names
    ]
    return original_sig.replace(parameters=new_params)


class read:
    """
    Namespace class for read decorators.

    Provides the @read.fixture() decorator for injecting JSON file data
    into test functions.
    """

    @staticmethod
    def fixture(
        path: str, fixture_name: str, object_class: Optional[Type[T]] = None
    ) -> Callable:
        """
        Decorator that injects a JSON file as a typed object into a test function.

        This decorator loads JSON data from a file and injects it as a named
        parameter into the decorated function. The path is resolved relative
        to the test file's location.

        Args:
            path: Relative path to JSON file (from test file location)
            fixture_name: Name of the parameter to inject
            object_class: Optional class to deserialize JSON into (via ObjectMapper).
                         If None, returns raw dict/list from JSON.

        Returns:
            Decorated function with fixture injected

        Example:
            @read.fixture(path="./fixtures/user.json", fixture_name="user", object_class=User)
            def test_user_creation(user: User):
                assert user.name == "John"

        Note:
            This is NOT a pytest fixture. It's a pure Python function wrapper
            that works with any test framework (pytest, unittest, nose, etc.).
        """

        def decorator(func: Callable) -> Callable:
            # Get the test file path at decoration time
            # If the function is already wrapped by another @read.fixture,
            # use the stored test file path from the first decorator
            if hasattr(func, "__pytools_test_file__"):
                test_file_path = func.__pytools_test_file__
            else:
                test_file_path = inspect.getfile(_unwrap_func(func))

            # Get the original function's signature for validation
            original_func = _unwrap_func(func)
            original_sig = inspect.signature(original_func)
            original_params = set(original_sig.parameters.keys())

            # Check if function accepts **kwargs (VAR_KEYWORD)
            has_var_keyword = any(
                param.kind == inspect.Parameter.VAR_KEYWORD
                for param in original_sig.parameters.values()
            )

            # Validate that fixture_name exists in the function signature
            # (excluding 'self' for methods, and skip if **kwargs is present)
            if not has_var_keyword:
                params_to_check = original_params - {"self", "cls"}
                if fixture_name not in params_to_check:
                    raise ValueError(
                        f"Fixture name '{fixture_name}' not found in function '{func.__name__}' signature. "
                        f"Available parameters: {', '.join(sorted(params_to_check)) or 'none'}"
                    )

            # Get or create fixtures list on the function
            if not hasattr(func, "__pytools_fixtures__"):
                func.__pytools_fixtures__ = []

            # Check for duplicate fixture names across stacked decorators
            existing_names = [
                loader.fixture_name
                for loader in getattr(func, "__pytools_fixtures__", [])
            ]
            if fixture_name in existing_names:
                raise ValueError(
                    f"Duplicate fixture name '{fixture_name}' in decorators "
                    f"for function '{func.__name__}'"
                )

            # Create and add the fixture loader
            loader = _FixtureLoader(
                path=path,
                fixture_name=fixture_name,
                object_class=object_class,
                test_file_path=test_file_path,
            )
            func.__pytools_fixtures__.append(loader)

            # Get all fixture names for signature modification
            all_fixture_names = [ldr.fixture_name for ldr in func.__pytools_fixtures__]

            # Check if the function is async
            if asyncio.iscoroutinefunction(func):

                @functools.wraps(func)
                async def async_wrapper(*args, **kwargs):
                    request = kwargs.pop("request", None)
                    if request is None:
                        request = kwargs.pop("_pytools_request", None)
                    if getattr(func, "__pytools_wrapper__", False) and request is not None:
                        kwargs["_pytools_request"] = request

                    # Load all fixtures (sync operation)
                    for fixture_loader in async_wrapper.__pytools_fixtures__:
                        kwargs[fixture_loader.fixture_name] = fixture_loader.load()
                    return await func(*args, **kwargs)

                async_wrapper.__pytools_fixtures__ = func.__pytools_fixtures__
                async_wrapper.__pytools_test_file__ = test_file_path
                async_wrapper.__pytools_wrapper__ = True  # type: ignore

                # Modify signature to exclude fixture parameters
                base_sig = _get_base_signature(func)
                async_wrapper.__signature__ = _create_new_signature(
                    base_sig, all_fixture_names
                )

                return async_wrapper
            else:

                @functools.wraps(func)
                def sync_wrapper(*args, **kwargs):
                    request = kwargs.pop("request", None)
                    if request is None:
                        request = kwargs.pop("_pytools_request", None)
                    if getattr(func, "__pytools_wrapper__", False) and request is not None:
                        kwargs["_pytools_request"] = request

                    # Load all fixtures
                    for fixture_loader in sync_wrapper.__pytools_fixtures__:
                        kwargs[fixture_loader.fixture_name] = fixture_loader.load()
                    return func(*args, **kwargs)

                sync_wrapper.__pytools_fixtures__ = func.__pytools_fixtures__
                sync_wrapper.__pytools_test_file__ = test_file_path
                sync_wrapper.__pytools_wrapper__ = True  # type: ignore

                # Modify signature to exclude fixture parameters
                base_sig = _get_base_signature(func)
                sync_wrapper.__signature__ = _create_new_signature(
                    base_sig, all_fixture_names
                )

                return sync_wrapper

        return decorator
