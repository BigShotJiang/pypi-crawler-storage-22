"""Fixture loading logic for reading JSON files and mapping to objects."""

import json
from typing import Optional, Type, TypeVar, Union, List

from fixturify._utils._constants import ENCODING
from fixturify._utils._path_resolver import _PathResolver
from fixturify.object_mapper import ObjectMapper

T = TypeVar("T")


class _FixtureLoader:
    """
    Loads JSON fixtures and optionally maps them to objects.

    Handles file reading, JSON parsing, and object conversion.
    Each call to load() reads the file fresh (no caching).
    """

    def __init__(
        self,
        path: str,
        fixture_name: str,
        object_class: Optional[Type[T]],
        test_file_path: str,
    ):
        """
        Initialize the fixture loader.

        Args:
            path: Relative path to the JSON file
            fixture_name: Name of the parameter to inject
            object_class: Optional class to deserialize JSON into
            test_file_path: Absolute path to the test file (for path resolution)
        """
        self._path = path
        self._fixture_name = fixture_name
        self._object_class = object_class
        self._test_file_path = test_file_path

    @property
    def fixture_name(self) -> str:
        """Return the fixture name for parameter injection."""
        return self._fixture_name

    def load(self) -> Union[T, List[T], dict, list]:
        """
        Load and optionally map the fixture.

        Each call reads the file fresh from disk.

        Returns:
            The loaded fixture data, either as raw dict/list or mapped object(s)

        Raises:
            FileNotFoundError: If the JSON file doesn't exist
            ValueError: If JSON parsing or object mapping fails
        """
        # Resolve the path relative to the test file
        try:
            resolved_path = _PathResolver.resolve(self._path, self._test_file_path)
        except FileNotFoundError as e:
            raise FileNotFoundError(
                f"Fixture file not found: {self._path} "
                f"(resolved from test file: {self._test_file_path})"
            ) from e

        # Read and parse the JSON file
        try:
            content = resolved_path.read_text(encoding=ENCODING)
            data = json.loads(content)
        except json.JSONDecodeError as e:
            raise ValueError(
                f"Invalid JSON in fixture file {resolved_path}: {e}"
            ) from e

        # If no object_class specified, return raw dict/list
        if self._object_class is None:
            return data

        # Map to object using ObjectMapper
        try:
            return ObjectMapper(data).to_object(self._object_class)
        except Exception as e:
            raise ValueError(
                f"Failed to convert fixture to {self._object_class.__name__}: {e}"
            ) from e
