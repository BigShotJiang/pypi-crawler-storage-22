"""SQL decorator for executing SQL files before/after tests."""

import atexit
import asyncio
import functools
import inspect
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Callable, List, Optional, Tuple, TypeVar

from fixturify._utils import ENCODING, _PathResolver

from fixturify.sql_d._config import SqlTestConfig
from fixturify.sql_d._executor import SqlExecutor
from fixturify.sql_d._fixture_discovery import (
    _find_config_from_request,
    _is_pytest_available,
)
from fixturify.sql_d._phase import Phase

F = TypeVar("F", bound=Callable[..., Any])


def _unwrap_func(func: Callable[..., Any]) -> Callable[..., Any]:
    """Return the original function by walking the __wrapped__ chain."""
    original = func
    while hasattr(original, "__wrapped__"):
        original = original.__wrapped__
    return original


def _get_test_file_path(func: Callable[..., Any]) -> str:
    """Get the test file path from a wrapped function."""
    if hasattr(func, "__pytools_test_file__"):
        return getattr(func, "__pytools_test_file__")
    return inspect.getfile(_unwrap_func(func))


def _unwrap_sql_wrappers(func: Callable[..., Any]) -> Callable[..., Any]:
    """Skip stacked SQL wrappers to avoid double execution."""
    current = func
    while hasattr(current, "__pytools_sql_wrapper__"):
        current = current.__wrapped__  # type: ignore[attr-defined]
    return current

# Thread pool for running sync executors in async context
_THREAD_POOL = ThreadPoolExecutor(max_workers=4)


def _cleanup_thread_pool() -> None:
    """Cleanup thread pool on interpreter shutdown."""
    _THREAD_POOL.shutdown(wait=False)


# Register cleanup handler
atexit.register(_cleanup_thread_pool)

# Attribute name for storing SQL decorator metadata on test functions
_SQL_DECORATORS_ATTR = "_sql_decorators"


def sql(
    path: str,
    phase: Phase = Phase.BEFORE,
    config: Optional[SqlTestConfig] = None,
) -> Callable[[F], F]:
    """
    Decorator to execute SQL file before or after test execution.

    Args:
        path: Relative path to SQL file (resolved from test file location)
        phase: When to execute - BEFORE (default) or AFTER the test
        config: Database configuration. If not provided, looks for pytest
                fixture returning SqlTestConfig type.

    Returns:
        Decorated test function

    Raises:
        FileNotFoundError: If SQL file doesn't exist
        ValueError: If config not provided and no pytest fixture found

    Example:
        @sql(path="./setup.sql")
        def test_something():
            pass

        @sql(path="./setup.sql", phase=Phase.BEFORE)
        @sql(path="./cleanup.sql", phase=Phase.AFTER)
        def test_with_cleanup():
            pass
    """

    def decorator(func: F) -> F:
        # Store decorator info for chaining support
        decorators: List[Tuple[str, Phase, Optional[SqlTestConfig]]] = getattr(
            func, _SQL_DECORATORS_ATTR, []
        ).copy()
        decorators.append((path, phase, config))

        # Get the original function if already wrapped
        original_func = _unwrap_func(func)
        is_async = asyncio.iscoroutinefunction(func)

        # Check if any decorator needs fixture discovery (config is None)
        needs_fixture_discovery = any(cfg is None for _, _, cfg in decorators)

        if is_async:
            wrapper = _create_async_wrapper(func, decorators, needs_fixture_discovery)
        else:
            wrapper = _create_sync_wrapper(func, decorators, needs_fixture_discovery)

        # Preserve function metadata
        functools.update_wrapper(wrapper, func)
        wrapper._original_func = original_func  # type: ignore
        wrapper._sql_decorators = decorators  # type: ignore
        wrapper.__pytools_test_file__ = _get_test_file_path(func)  # type: ignore
        wrapper.__pytools_wrapper__ = True  # type: ignore
        wrapper.__pytools_sql_wrapper__ = True  # type: ignore

        # If we need fixture discovery, add 'request' to signature
        if needs_fixture_discovery and _is_pytest_available():
            wrapper = _add_request_parameter(wrapper, func)

        return wrapper  # type: ignore

    return decorator


def _add_request_parameter(
    wrapper: Callable[..., Any], original_func: Callable[..., Any]
) -> Callable[..., Any]:
    """
    Add 'request' parameter to wrapper's signature for pytest fixture injection.

    Pytest inspects function signatures to determine which fixtures to inject.
    By adding 'request' to the signature, pytest will inject the FixtureRequest
    object, which we can use to discover SqlTestConfig fixtures.

    Args:
        wrapper: The wrapped function
        original_func: The original test function

    Returns:
        Wrapper with modified signature
    """
    if hasattr(wrapper, "__signature__"):
        sig = wrapper.__signature__  # type: ignore
    else:
        sig = inspect.signature(original_func)

    # Check if 'request' is already in the signature
    if "request" in sig.parameters:
        return wrapper

    # Create new signature with 'request' added as keyword-only parameter
    new_params = list(sig.parameters.values())
    request_param = inspect.Parameter(
        "request",
        inspect.Parameter.KEYWORD_ONLY,
    )
    new_params.append(request_param)
    new_sig = sig.replace(parameters=new_params)

    # Set the new signature on the wrapper
    wrapper.__signature__ = new_sig  # type: ignore

    return wrapper


def _create_sync_wrapper(
    func: Callable[..., Any],
    decorators: List[Tuple[str, Phase, Optional[SqlTestConfig]]],
    needs_fixture_discovery: bool,
) -> Callable[..., Any]:
    """Create wrapper for sync test functions."""
    func_to_call = _unwrap_sql_wrappers(func)

    def wrapper(*args: Any, **kwargs: Any) -> Any:
        # Extract and propagate request for stacked decorators
        request = kwargs.pop("request", None)
        if request is None:
            request = kwargs.pop("_pytools_request", None)

        if request is not None and getattr(func_to_call, "__pytools_wrapper__", False):
            kwargs["_pytools_request"] = request

        # Resolve all configs and paths
        before_tasks, after_tasks = _prepare_sql_tasks(func, decorators, request)

        # Track if any BEFORE script ran (for cleanup decision)
        before_started = False

        try:
            # Execute BEFORE phase (top to bottom)
            # Note: Python evaluates decorators bottom-to-top, so list is reversed
            for sql_content, resolved_config in reversed(before_tasks):
                before_started = True
                _execute_sql_sync(sql_content, resolved_config)

            # Run the actual test
            if not getattr(func_to_call, "__pytools_wrapper__", False):
                kwargs.pop("_pytools_request", None)
            result = func_to_call(*args, **kwargs)
            return result
        finally:
            # Execute AFTER phase if any BEFORE ran or test ran
            # This ensures cleanup runs even if BEFORE fails partway through
            if before_started or not before_tasks:
                for sql_content, resolved_config in after_tasks:
                    _execute_sql_sync(sql_content, resolved_config)

    return wrapper


def _create_async_wrapper(
    func: Callable[..., Any],
    decorators: List[Tuple[str, Phase, Optional[SqlTestConfig]]],
    needs_fixture_discovery: bool,
) -> Callable[..., Any]:
    """Create wrapper for async test functions."""
    func_to_call = _unwrap_sql_wrappers(func)

    async def wrapper(*args: Any, **kwargs: Any) -> Any:
        # Extract and propagate request for stacked decorators
        request = kwargs.pop("request", None)
        if request is None:
            request = kwargs.pop("_pytools_request", None)

        if request is not None and getattr(func_to_call, "__pytools_wrapper__", False):
            kwargs["_pytools_request"] = request

        # Resolve all configs and paths
        before_tasks, after_tasks = _prepare_sql_tasks(func, decorators, request)

        # Track if any BEFORE script ran (for cleanup decision)
        before_started = False

        try:
            # Execute BEFORE phase (top to bottom)
            # Note: Python evaluates decorators bottom-to-top, so list is reversed
            for sql_content, resolved_config in reversed(before_tasks):
                before_started = True
                await _execute_sql_async(sql_content, resolved_config)

            # Run the actual test
            if not getattr(func_to_call, "__pytools_wrapper__", False):
                kwargs.pop("_pytools_request", None)
            result = await func_to_call(*args, **kwargs)
            return result
        finally:
            # Execute AFTER phase if any BEFORE ran or test ran
            # This ensures cleanup runs even if BEFORE fails partway through
            if before_started or not before_tasks:
                for sql_content, resolved_config in after_tasks:
                    await _execute_sql_async(sql_content, resolved_config)

    return wrapper


def _prepare_sql_tasks(
    func: Callable[..., Any],
    decorators: List[Tuple[str, Phase, Optional[SqlTestConfig]]],
    request: Any = None,
) -> Tuple[List[Tuple[str, SqlTestConfig]], List[Tuple[str, SqlTestConfig]]]:
    """
    Prepare SQL tasks by resolving paths and configs.

    Args:
        func: The test function
        decorators: List of (path, phase, config) tuples
        request: Pytest FixtureRequest object (if available)

    Returns:
        Tuple of (before_tasks, after_tasks) where each task is (sql_content, config)
    """
    before_tasks: List[Tuple[str, SqlTestConfig]] = []
    after_tasks: List[Tuple[str, SqlTestConfig]] = []

    # Get the original test file for path resolution
    test_file = _get_test_file_path(func)

    for path, phase, config in decorators:
        # Resolve config
        resolved_config = _resolve_config(config, request)

        # Resolve path and read SQL content
        sql_path = _PathResolver.resolve(path, reference_file=test_file)
        with open(sql_path, "r", encoding=ENCODING) as f:
            sql_content = f.read()

        if phase == Phase.BEFORE:
            before_tasks.append((sql_content, resolved_config))
        else:
            after_tasks.append((sql_content, resolved_config))

    return before_tasks, after_tasks


def _resolve_config(
    config: Optional[SqlTestConfig],
    request: Any = None,
) -> SqlTestConfig:
    """
    Resolve database configuration.

    Priority:
    1. Direct config parameter
    2. Pytest fixture discovery via request

    Args:
        config: Direct config or None
        request: Pytest FixtureRequest object (if available)

    Returns:
        Resolved SqlTestConfig

    Raises:
        ValueError: If no config found
    """
    if config is not None:
        return config

    # Try fixture discovery via request
    if request is not None:
        discovered_config = _find_config_from_request(request)
        if discovered_config is not None:
            return discovered_config

    raise ValueError(
        "No database configuration provided. Either pass 'config' parameter "
        "to @sql decorator or define a pytest fixture returning SqlTestConfig."
    )


def _execute_sql_sync(sql_content: str, config: SqlTestConfig) -> None:
    """
    Execute SQL synchronously.

    Handles both sync and async drivers from sync context.

    Args:
        sql_content: SQL content to execute
        config: Database configuration
    """
    executor = SqlExecutor(config)

    if executor.is_async:
        # Async driver from sync context - use asyncio.run()
        asyncio.run(executor.execute_async(sql_content))
    else:
        # Sync driver - direct call
        executor.execute(sql_content)


async def _execute_sql_async(sql_content: str, config: SqlTestConfig) -> None:
    """
    Execute SQL asynchronously.

    Handles both sync and async drivers from async context.

    Args:
        sql_content: SQL content to execute
        config: Database configuration
    """
    executor = SqlExecutor(config)

    if executor.is_async:
        # Async driver - direct await
        await executor.execute_async(sql_content)
    else:
        # Sync driver from async context - run in thread pool
        loop = asyncio.get_running_loop()
        await loop.run_in_executor(_THREAD_POOL, executor.execute, sql_content)
