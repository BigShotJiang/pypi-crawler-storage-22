"""SQL execution using Strategy pattern (v2).

This is a cleaner implementation that delegates driver-specific
logic to individual strategy classes.
"""


from ._config import SqlTestConfig
from ._strategies import get_strategy_registry, AsyncSqlExecutionStrategy


class SqlExecutor:
    """
    Unified SQL executor using Strategy pattern.
    
    Automatically selects the appropriate strategy based on the driver
    and handles both sync and async execution.
    """

    def __init__(self, config: SqlTestConfig):
        """
        Initialize the executor.

        Args:
            config: Database connection configuration
        """
        self._config = config
        self._registry = get_strategy_registry()
        self._strategy = self._registry.get_or_raise(config.driver)

    @property
    def is_async(self) -> bool:
        """Check if this executor uses async execution."""
        return self._strategy.is_async

    def execute(self, sql_content: str) -> None:
        """
        Execute SQL content synchronously.

        Args:
            sql_content: SQL statements to execute

        Raises:
            RuntimeError: If strategy is async
        """
        if self._strategy.is_async:
            raise RuntimeError(
                f"Driver '{self._config.driver}' is async. "
                f"Use execute_async() instead."
            )
        self._strategy.execute(sql_content, self._config)

    async def execute_async(self, sql_content: str) -> None:
        """
        Execute SQL content asynchronously.

        Args:
            sql_content: SQL statements to execute

        Raises:
            RuntimeError: If strategy is sync
        """
        if not self._strategy.is_async:
            raise RuntimeError(
                f"Driver '{self._config.driver}' is sync. "
                f"Use execute() instead."
            )
        strategy: AsyncSqlExecutionStrategy = self._strategy
        await strategy.execute_async(sql_content, self._config)


def create_executor(config: SqlTestConfig) -> SqlExecutor:
    """
    Create an executor for the given configuration.

    Args:
        config: Database connection configuration

    Returns:
        SqlExecutor instance
    """
    return SqlExecutor(config)
