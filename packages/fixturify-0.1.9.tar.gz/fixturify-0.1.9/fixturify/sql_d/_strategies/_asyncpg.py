"""Strategy for asyncpg (PostgreSQL async) driver."""

from typing import TYPE_CHECKING

from ._base import AsyncSqlExecutionStrategy

if TYPE_CHECKING:
    from .._config import SqlTestConfig


class AsyncpgStrategy(AsyncSqlExecutionStrategy):
    """Execution strategy for asyncpg (PostgreSQL async)."""

    driver_name = "asyncpg"
    is_async = True
    default_port = 5432
    param_mapping = {
        "host": "host",
        "database": "database",
        "user": "user",
        "password": "password",
        "port": "port",
    }

    async def execute_async(self, sql_content: str, config: "SqlTestConfig") -> None:
        """Execute SQL using asyncpg."""
        driver = self.get_driver_module()
        params = self.build_connection_params(config)
        
        connection = await driver.connect(**params)
        try:
            await connection.execute(sql_content)
        finally:
            await connection.close()
