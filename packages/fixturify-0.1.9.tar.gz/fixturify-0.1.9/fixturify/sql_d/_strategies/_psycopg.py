"""Strategy for psycopg (PostgreSQL async) driver."""

from typing import TYPE_CHECKING

from ._base import AsyncSqlExecutionStrategy

if TYPE_CHECKING:
    from .._config import SqlTestConfig


class PsycopgStrategy(AsyncSqlExecutionStrategy):
    """Execution strategy for psycopg (PostgreSQL async)."""

    driver_name = "psycopg"
    is_async = True
    default_port = 5432
    param_mapping = {
        "host": "host",
        "database": "dbname",
        "user": "user",
        "password": "password",
        "port": "port",
    }

    async def execute_async(self, sql_content: str, config: "SqlTestConfig") -> None:
        """Execute SQL using psycopg async connection."""
        driver = self.get_driver_module()
        params = self.build_connection_params(config)

        connection = await driver.AsyncConnection.connect(**params)
        try:
            await connection.execute(sql_content)
            await connection.commit()
        finally:
            await connection.close()
