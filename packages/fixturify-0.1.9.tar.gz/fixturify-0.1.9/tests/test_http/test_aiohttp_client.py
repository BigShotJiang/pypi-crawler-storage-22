"""Integration tests for HTTP mock decorator using aiohttp.

These tests verify that the http_d module correctly intercepts
aiohttp async HTTP calls for recording and playback.
"""

import pytest

from fixturify.http_d import http, HttpTestConfig


# Check if aiohttp is available
try:
    import aiohttp

    HAS_AIOHTTP = True
except ImportError:
    HAS_AIOHTTP = False


# Base URL for the test API
API_BASE = "https://api.restful-api.dev"


@pytest.mark.skipif(not HAS_AIOHTTP, reason="aiohttp not installed")
class TestAiohttpIntegration:
    """Integration tests using aiohttp library."""

    @pytest.mark.asyncio
    @http(path="./fixtures/aiohttp_get_all_objects.json")
    async def test_get_all_objects(self):
        """Test async GET request to fetch all objects."""
        async with aiohttp.ClientSession() as session:
            async with session.get(f"{API_BASE}/objects") as response:
                assert response.status == 200
                data = await response.json()

                # Should return a list of objects
                assert isinstance(data, list)
                assert len(data) > 0

                # First object should have expected structure
                first_obj = data[0]
                assert "id" in first_obj
                assert "name" in first_obj

    @pytest.mark.asyncio
    @http(path="./fixtures/aiohttp_get_single_object.json")
    async def test_get_single_object(self):
        """Test async GET request to fetch a single object by ID."""
        async with aiohttp.ClientSession() as session:
            async with session.get(f"{API_BASE}/objects/1") as response:
                assert response.status == 200
                data = await response.json()

                assert data["id"] == "1"
                assert "name" in data

    @pytest.mark.asyncio
    @http(path="./fixtures/aiohttp_post_object.json")
    async def test_create_object(self):
        """Test async POST request to create a new object."""
        new_object = {"name": "Aiohttp Test Product", "data": {"color": "Purple"}}

        async with aiohttp.ClientSession() as session:
            async with session.post(
                f"{API_BASE}/objects",
                json=new_object,
            ) as response:
                assert response.status == 200
                data = await response.json()

                # Should return created object with ID
                assert "id" in data
                assert data["name"] == "Aiohttp Test Product"

    @pytest.mark.asyncio
    @http(path="./fixtures/aiohttp_multiple_requests.json")
    async def test_multiple_concurrent_requests(self):
        """Test multiple concurrent async requests."""
        import asyncio

        async with aiohttp.ClientSession() as session:
            tasks = [
                session.get(f"{API_BASE}/objects/1"),
                session.get(f"{API_BASE}/objects/2"),
                session.get(f"{API_BASE}/objects/3"),
            ]
            responses = await asyncio.gather(*tasks)

            # All should succeed
            for resp in responses:
                assert resp.status == 200

    @pytest.mark.asyncio
    @http(path="./fixtures/aiohttp_read_text.json")
    async def test_read_as_text(self):
        """Test reading response as text."""
        async with aiohttp.ClientSession() as session:
            async with session.get(f"{API_BASE}/objects/1") as response:
                assert response.status == 200
                text = await response.text()
                assert "id" in text
                assert "name" in text


@pytest.mark.skipif(not HAS_AIOHTTP, reason="aiohttp not installed")
class TestAiohttpWithConfig:
    """Tests with custom configuration."""

    @pytest.mark.asyncio
    @http(
        path="./fixtures/aiohttp_with_config.json",
        config=HttpTestConfig(
            ignore_request_headers=["X-Custom-Header"],
            exclude_request_headers=["X-Secret-Key"],
        ),
    )
    async def test_with_custom_headers(self):
        """Test with custom headers that should be filtered."""
        async with aiohttp.ClientSession() as session:
            async with session.get(
                f"{API_BASE}/objects/1",
                headers={
                    "X-Custom-Header": "custom-value",
                    "X-Secret-Key": "secret-123",
                },
            ) as response:
                assert response.status == 200
