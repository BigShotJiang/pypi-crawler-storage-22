"""Integration tests for HTTP mock decorator using boto3/botocore.

These tests verify that the http_d module correctly intercepts
boto3/botocore HTTP calls for recording and playback, with proper
handling of AWS signing headers.
"""

import pytest
import socket

from fixturify.http_d import http, HttpTestConfig


# Check if boto3/botocore is available
try:
    import boto3

    HAS_BOTO3 = True
except ImportError:
    HAS_BOTO3 = False


def is_localstack_running(host: str = "localhost", port: int = 4566) -> bool:
    """Check if localstack is running and accessible."""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(1)
        result = sock.connect_ex((host, port))
        sock.close()
        return result == 0
    except Exception:
        return False


# Check localstack availability once at module load
LOCALSTACK_AVAILABLE = is_localstack_running()
LOCALSTACK_ENDPOINT = "http://localhost:4566"


@pytest.mark.skipif(not HAS_BOTO3, reason="boto3 not installed")
class TestBoto3Integration:
    """Integration tests using boto3 library with localstack."""

    @pytest.mark.skipif(not LOCALSTACK_AVAILABLE, reason="localstack not running")
    @http(
        path="./fixtures/boto3_s3_list_buckets.json",
        config=HttpTestConfig(aws_mode=True),
    )
    def test_s3_list_buckets(self):
        """Test S3 ListBuckets operation with localstack."""
        s3 = boto3.client(
            "s3",
            endpoint_url=LOCALSTACK_ENDPOINT,
            aws_access_key_id="test",
            aws_secret_access_key="test",
            region_name="us-east-1",
        )
        response = s3.list_buckets()

        assert "Buckets" in response
        assert isinstance(response["Buckets"], list)

    @pytest.mark.skipif(not LOCALSTACK_AVAILABLE, reason="localstack not running")
    @http(
        path="./fixtures/boto3_sts_get_caller_identity.json",
        config=HttpTestConfig(aws_mode=True),
    )
    def test_sts_get_caller_identity(self):
        """Test STS GetCallerIdentity operation with localstack."""
        sts = boto3.client(
            "sts",
            endpoint_url=LOCALSTACK_ENDPOINT,
            aws_access_key_id="test",
            aws_secret_access_key="test",
            region_name="us-east-1",
        )
        response = sts.get_caller_identity()

        assert "Account" in response
        assert "Arn" in response
        assert "UserId" in response


@pytest.mark.skipif(not HAS_BOTO3, reason="boto3 not installed")
class TestBoto3AwsMode:
    """Tests for AWS mode configuration."""

    def test_aws_mode_ignores_signing_headers(self):
        """Test that aws_mode=True ignores AWS signing headers."""
        config = HttpTestConfig(aws_mode=True)

        ignore_headers = config.get_ignore_request_headers_set()

        # Should include standard ignored headers
        assert "user-agent" in ignore_headers
        assert "host" in ignore_headers

        # Should include AWS signing headers
        assert "authorization" in ignore_headers
        assert "x-amz-date" in ignore_headers
        assert "x-amz-security-token" in ignore_headers
        assert "x-amz-content-sha256" in ignore_headers

    def test_aws_mode_excludes_signing_headers_from_recording(self):
        """Test that aws_mode=True excludes AWS headers from recording."""
        config = HttpTestConfig(aws_mode=True)

        exclude_headers = config.get_exclude_request_headers_set()

        # Should include AWS signing headers
        assert "authorization" in exclude_headers
        assert "x-amz-date" in exclude_headers
        assert "x-amz-security-token" in exclude_headers
        assert "x-amz-content-sha256" in exclude_headers

    def test_aws_mode_default_off(self):
        """Test that aws_mode is off by default."""
        config = HttpTestConfig()

        ignore_headers = config.get_ignore_request_headers_set()

        # Should NOT include AWS signing headers by default
        assert "authorization" not in ignore_headers
        assert "x-amz-date" not in ignore_headers


@pytest.mark.skipif(not HAS_BOTO3, reason="boto3 not installed")
@pytest.mark.skipif(not LOCALSTACK_AVAILABLE, reason="localstack not running")
class TestBoto3WithLocalstack:
    """Tests using localstack for local AWS service mocking.

    These tests require localstack to be running:
        docker compose up -d localstack
    """

    @http(
        path="./fixtures/boto3_localstack_s3.json",
        config=HttpTestConfig(aws_mode=True),
    )
    def test_s3_create_and_list_buckets(self):
        """Test S3 create bucket and list operations with localstack."""
        s3 = boto3.client(
            "s3",
            endpoint_url=LOCALSTACK_ENDPOINT,
            aws_access_key_id="test",
            aws_secret_access_key="test",
            region_name="us-east-1",
        )

        # Create a unique bucket name for this test
        bucket_name = "pytools-test-bucket"

        # Try to create bucket (may already exist from previous run)
        try:
            s3.create_bucket(Bucket=bucket_name)
        except s3.exceptions.BucketAlreadyOwnedByYou:
            pass  # Bucket already exists, that's fine

        # List buckets
        response = s3.list_buckets()
        bucket_names = [b["Name"] for b in response["Buckets"]]

        assert bucket_name in bucket_names

    @http(
        path="./fixtures/boto3_localstack_s3_objects.json",
        config=HttpTestConfig(aws_mode=True, ignore_request_headers=["x-amz-checksum-crc32"]),
    )
    def test_s3_put_and_get_object(self):
        """Test S3 put and get object operations with localstack."""
        s3 = boto3.client(
            "s3",
            endpoint_url=LOCALSTACK_ENDPOINT,
            aws_access_key_id="test",
            aws_secret_access_key="test",
            region_name="us-east-1",
        )

        bucket_name = "pytools-objects-bucket"
        object_key = "test-object.txt"
        object_content = b"Hello from fixturify test!"

        # Create bucket
        try:
            s3.create_bucket(Bucket=bucket_name)
        except s3.exceptions.BucketAlreadyOwnedByYou:
            pass

        # Put object
        s3.put_object(
            Bucket=bucket_name,
            Key=object_key,
            Body=object_content,
        )

        # Get object
        response = s3.get_object(Bucket=bucket_name, Key=object_key)
        retrieved_content = response["Body"].read()

        assert retrieved_content == object_content

    @http(
        path="./fixtures/boto3_localstack_sts.json",
        config=HttpTestConfig(aws_mode=True),
    )
    def test_sts_operations(self):
        """Test STS operations with localstack."""
        sts = boto3.client(
            "sts",
            endpoint_url=LOCALSTACK_ENDPOINT,
            aws_access_key_id="test",
            aws_secret_access_key="test",
            region_name="us-east-1",
        )

        # Get caller identity
        response = sts.get_caller_identity()

        assert "Account" in response
        assert "Arn" in response
        assert "UserId" in response
