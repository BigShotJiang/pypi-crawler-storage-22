"""Tests for HTTP mock decorator."""

import json
import pytest
from unittest.mock import MagicMock

from fixturify.http_d import http, NoMatchingRecordingError, UnusedRecordingsError


class TestHttpDecoratorRecordingMode:
    """Tests for recording mode (file doesn't exist)."""

    def test_record_sync_request(self, tmp_path, monkeypatch):
        """Test recording a sync HTTP request."""
        recordings_file = tmp_path / "recordings.json"

        # Mock httpx
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.headers = {"Content-Type": "application/json"}
        mock_response.content = b'{"result": "success"}'

        mock_request = MagicMock()
        mock_request.method = "GET"
        mock_request.url = "https://api.example.com/test"
        mock_request.headers = {"Accept": "application/json"}
        mock_request.content = b""

        mock_client = MagicMock()
        mock_client.send = MagicMock(return_value=mock_response)

        # Patch path resolution
        monkeypatch.setattr(
            "fixturify.http_d._decorator._PathResolver.resolve_without_check",
            lambda path, reference_file: recordings_file,
        )

        @http(path="./fixtures/test.json")
        def test_func():
            # Simulate the test making an HTTP call
            # In real usage, this would use httpx or requests
            pass

        # File should not exist initially
        assert not recordings_file.exists()

    def test_decorator_preserves_function_metadata(self, tmp_path, monkeypatch):
        """Test that decorator preserves function name and docstring."""
        recordings_file = tmp_path / "recordings.json"

        monkeypatch.setattr(
            "fixturify.http_d._decorator._PathResolver.resolve_without_check",
            lambda path, reference_file: recordings_file,
        )

        @http(path="./fixtures/test.json")
        def my_test_function():
            """This is my test docstring."""
            pass

        assert my_test_function.__name__ == "my_test_function"
        assert my_test_function.__doc__ == "This is my test docstring."

    def test_decorator_on_async_function(self, tmp_path, monkeypatch):
        """Test decorator on async function."""
        import asyncio

        recordings_file = tmp_path / "recordings.json"

        monkeypatch.setattr(
            "fixturify.http_d._decorator._PathResolver.resolve_without_check",
            lambda path, reference_file: recordings_file,
        )

        @http(path="./fixtures/test.json")
        async def my_async_test():
            """Async test."""
            return "async result"

        # Should be async
        assert asyncio.iscoroutinefunction(my_async_test)
        assert my_async_test.__name__ == "my_async_test"


class TestHttpDecoratorPlaybackMode:
    """Tests for playback mode (file exists)."""

    @pytest.fixture
    def recordings_file(self, tmp_path):
        """Create test recordings file."""
        file_path = tmp_path / "recordings.json"
        data = {
            "mappings": [
                {
                    "request": {
                        "method": "GET",
                        "url": "https://api.example.com/users",
                        "headers": {},
                        "queryParameters": {},
                    },
                    "response": {
                        "status": 200,
                        "headers": {"Content-Type": "application/json"},
                        "body": {"users": []},
                    },
                }
            ]
        }

        with open(file_path, "w") as f:
            json.dump(data, f)

        return file_path

    def test_playback_mode_detected(self, recordings_file, monkeypatch):
        """Test that playback mode is detected when file exists."""
        monkeypatch.setattr(
            "fixturify.http_d._decorator._PathResolver.resolve_without_check",
            lambda path, reference_file: recordings_file,
        )

        captured_paths = []

        class MockHttpMockContext:
            def __init__(self, path, config):
                captured_paths.append(path)
                self.mode = "playback"

            def __enter__(self):
                return self

            def __exit__(self, *args):
                return False

        monkeypatch.setattr(
            "fixturify.http_d._decorator.HttpMockContext",
            MockHttpMockContext,
        )

        @http(path="./fixtures/test.json")
        def test_func():
            pass

        test_func()

        assert len(captured_paths) == 1
        assert captured_paths[0] == recordings_file


class TestHttpDecoratorOptions:
    """Tests for decorator options."""

    def test_ignore_headers_via_config(self, tmp_path, monkeypatch):
        """Test ignore_headers is passed via config object."""
        from fixturify.http_d import HttpTestConfig

        recordings_file = tmp_path / "recordings.json"

        monkeypatch.setattr(
            "fixturify.http_d._decorator._PathResolver.resolve_without_check",
            lambda path, reference_file: recordings_file,
        )

        captured_config = []

        class MockHttpMockContext:
            def __init__(self, path, config):
                captured_config.append(config)

            def __enter__(self):
                return self

            def __exit__(self, *args):
                return False

        monkeypatch.setattr(
            "fixturify.http_d._decorator.HttpMockContext",
            MockHttpMockContext,
        )

        config = HttpTestConfig(
            ignore_request_headers=["Authorization", "X-Request-ID"]
        )

        @http(path="./fixtures/test.json", config=config)
        def test_func():
            pass

        test_func()

        # Options are now passed via config object
        passed_config = captured_config[0]
        assert "authorization" in passed_config.get_ignore_request_headers_set()
        assert "x-request-id" in passed_config.get_ignore_request_headers_set()

    def test_strict_order_via_config(self, tmp_path, monkeypatch):
        """Test strict_order is passed via config object."""
        from fixturify.http_d import HttpTestConfig

        recordings_file = tmp_path / "recordings.json"

        monkeypatch.setattr(
            "fixturify.http_d._decorator._PathResolver.resolve_without_check",
            lambda path, reference_file: recordings_file,
        )

        captured_config = []

        class MockHttpMockContext:
            def __init__(self, path, config):
                captured_config.append(config)

            def __enter__(self):
                return self

            def __exit__(self, *args):
                return False

        monkeypatch.setattr(
            "fixturify.http_d._decorator.HttpMockContext",
            MockHttpMockContext,
        )

        config = HttpTestConfig(strict_order=True)

        @http(path="./fixtures/test.json", config=config)
        def test_func():
            pass

        test_func()

        passed_config = captured_config[0]
        assert passed_config.strict_order is True

    def test_match_body_via_config(self, tmp_path, monkeypatch):
        """Test match_body is passed via config object."""
        from fixturify.http_d import HttpTestConfig

        recordings_file = tmp_path / "recordings.json"

        monkeypatch.setattr(
            "fixturify.http_d._decorator._PathResolver.resolve_without_check",
            lambda path, reference_file: recordings_file,
        )

        captured_config = []

        class MockHttpMockContext:
            def __init__(self, path, config):
                captured_config.append(config)

            def __enter__(self):
                return self

            def __exit__(self, *args):
                return False

        monkeypatch.setattr(
            "fixturify.http_d._decorator.HttpMockContext",
            MockHttpMockContext,
        )

        config = HttpTestConfig(match_request_body=False)

        @http(path="./fixtures/test.json", config=config)
        def test_func():
            pass

        test_func()

        passed_config = captured_config[0]
        assert passed_config.match_request_body is False

    def test_config_object_passed_directly(self, tmp_path, monkeypatch):
        """Test that config object is passed directly when provided."""
        from fixturify.http_d import HttpTestConfig

        recordings_file = tmp_path / "recordings.json"

        monkeypatch.setattr(
            "fixturify.http_d._decorator._PathResolver.resolve_without_check",
            lambda path, reference_file: recordings_file,
        )

        captured_config = []

        class MockHttpMockContext:
            def __init__(self, path, config):
                captured_config.append(config)

            def __enter__(self):
                return self

            def __exit__(self, *args):
                return False

        monkeypatch.setattr(
            "fixturify.http_d._decorator.HttpMockContext",
            MockHttpMockContext,
        )

        custom_config = HttpTestConfig(
            ignore_request_headers=["X-Custom"],
            exclude_request_headers=["Authorization"],
            match_request_body=False,
            strict_order=True,
        )

        @http(path="./fixtures/test.json", config=custom_config)
        def test_func():
            pass

        test_func()

        # Config object should be the same instance
        assert captured_config[0] is custom_config


class TestHttpDecoratorExceptions:
    """Tests for exception scenarios."""

    def test_exception_details(self):
        """Test exception message details."""
        from fixturify.http_d import HttpRequest

        request = HttpRequest(
            method="POST",
            url="https://api.example.com/data",
            headers={"Content-Type": "application/json"},
            body='{"key": "value"}',
        )

        error = NoMatchingRecordingError(request)
        message = str(error)

        assert "POST" in message
        assert "api.example.com" in message

    def test_unused_recordings_exception(self):
        """Test unused recordings exception message."""
        from fixturify.http_d import HttpMapping, HttpRequest, HttpResponse

        unused = [
            HttpMapping(
                request=HttpRequest(method="GET", url="https://example.com/1"),
                response=HttpResponse(status=200),
            ),
            HttpMapping(
                request=HttpRequest(method="POST", url="https://example.com/2"),
                response=HttpResponse(status=201),
            ),
        ]

        error = UnusedRecordingsError(unused)
        message = str(error)

        assert "2" in message  # Count
        assert "example.com/1" in message
        assert "example.com/2" in message
