"""Tests for HTTP fixture discovery."""

import json

import pytest
from unittest.mock import MagicMock, patch

from fixturify.http_d import HttpTestConfig
from fixturify.http_d._fixture_discovery import (
    _find_config_from_request,
    _is_pytest_available,
)
from fixturify._utils._fixture_discovery import (
    _get_fixture_names_by_type,
)


class TestIsPytestAvailable:
    """Tests for pytest availability check."""

    def test_pytest_is_available(self):
        """Test that pytest is detected as available."""
        # We're running in pytest, so it should be available
        assert _is_pytest_available() is True

    def test_pytest_unavailable_when_import_fails(self):
        """Test that pytest is detected as unavailable when import fails."""
        with patch.dict("sys.modules", {"pytest": None}):

            def check_pytest_available() -> bool:
                try:
                    import pytest  # noqa: F401

                    return True
                except (ImportError, TypeError):
                    return False

            assert check_pytest_available() is False


class TestFindConfigFromRequest:
    """Tests for config discovery from request."""

    def test_returns_none_when_no_fixtures(self):
        """Test that None is returned when no fixtures are available."""
        mock_request = MagicMock()
        mock_request.fixturenames = []

        result = _find_config_from_request(mock_request)
        assert result is None

    def test_returns_none_when_no_http_config_fixture(self):
        """Test that None is returned when no HttpTestConfig fixture exists."""
        mock_request = MagicMock()
        mock_request.fixturenames = ["some_fixture", "another_fixture"]
        mock_request.getfixturevalue.side_effect = [
            "not a config",
            42,
        ]

        result = _find_config_from_request(mock_request)
        assert result is None

    def test_returns_config_when_found(self):
        """Test that HttpTestConfig is returned when fixture exists."""
        expected_config = HttpTestConfig(
            ignore_request_headers=["Authorization"],
            strict_order=True,
        )

        mock_request = MagicMock()
        mock_request.fixturenames = ["http_config"]
        mock_request.getfixturevalue.return_value = expected_config

        result = _find_config_from_request(mock_request)
        assert result is expected_config

    def test_finds_config_among_multiple_fixtures(self):
        """Test that HttpTestConfig is found among multiple fixtures."""
        expected_config = HttpTestConfig(
            ignore_request_headers=["X-API-Key"],
            match_request_body=False,
        )

        mock_request = MagicMock()
        mock_request.fixturenames = ["fixture1", "http_config", "fixture2"]

        def get_fixture(name: str):
            if name == "fixture1":
                return "string value"
            elif name == "http_config":
                return expected_config
            else:
                return {"key": "value"}

        mock_request.getfixturevalue.side_effect = get_fixture

        result = _find_config_from_request(mock_request)
        assert result is expected_config

    def test_handles_fixture_resolution_errors(self):
        """Test that fixture resolution errors are handled gracefully."""
        expected_config = HttpTestConfig(
            exclude_hosts=["testserver"],
        )

        mock_request = MagicMock()
        mock_request.fixturenames = ["failing_fixture", "good_fixture"]

        def get_fixture(name: str):
            if name == "failing_fixture":
                raise RuntimeError("Fixture failed to resolve")
            return expected_config

        mock_request.getfixturevalue.side_effect = get_fixture

        result = _find_config_from_request(mock_request)
        assert result is expected_config

    def test_returns_first_config_found(self):
        """Test that the first HttpTestConfig is returned when multiple exist."""
        first_config = HttpTestConfig(
            ignore_request_headers=["First"],
        )
        second_config = HttpTestConfig(
            ignore_request_headers=["Second"],
        )

        mock_request = MagicMock()
        mock_request.fixturenames = ["config1", "config2"]

        def get_fixture(name: str):
            if name == "config1":
                return first_config
            return second_config

        mock_request.getfixturevalue.side_effect = get_fixture

        result = _find_config_from_request(mock_request)
        assert result is first_config

    def test_find_config_with_real_request(self, request):
        """Test finding config using actual pytest request fixture."""
        # This test uses the actual pytest request fixture
        # No HttpTestConfig fixture defined here, so should return None
        result = _find_config_from_request(request)
        assert result is None


class TestGetFixtureNamesByType:
    """Tests for getting fixture names by type annotation."""

    def test_no_fixturemanager_returns_empty(self):
        """Test that empty list is returned when _fixturemanager is missing."""
        mock_request = MagicMock()
        del mock_request._fixturemanager
        result = _get_fixture_names_by_type(mock_request, HttpTestConfig)
        assert result == []

    def test_no_node_returns_empty(self):
        """Test that empty list is returned when node is missing."""
        mock_request = MagicMock()
        mock_request._fixturemanager = MagicMock()
        del mock_request.node
        result = _get_fixture_names_by_type(mock_request, HttpTestConfig)
        assert result == []

    def test_finds_annotated_fixture(self):
        """Test that fixture with HttpTestConfig annotation is found."""
        mock_request = MagicMock()
        mock_request.fixturenames = ["my_http_config", "other_fixture"]

        # Mock fixture info and manager
        mock_fixturedef = MagicMock()
        mock_fixturedef.func.__annotations__ = {"return": HttpTestConfig}

        mock_other_fixturedef = MagicMock()
        mock_other_fixturedef.func.__annotations__ = {"return": str}

        mock_request._fixturemanager = MagicMock()
        # Mock node as an object (not nodeid string)
        mock_request.node = MagicMock()

        # Mock _arg2fixturedefs - this is where all fixtures are registered
        mock_request._fixturemanager._arg2fixturedefs = {
            "my_http_config": [mock_fixturedef],
            "other_fixture": [mock_other_fixturedef],
        }

        def get_fixturedefs(name, node):
            if name == "my_http_config":
                return [mock_fixturedef]
            elif name == "other_fixture":
                return [mock_other_fixturedef]
            return None

        mock_request._fixturemanager.getfixturedefs.side_effect = get_fixturedefs

        result = _get_fixture_names_by_type(mock_request, HttpTestConfig)
        # Should find by TYPE (HttpTestConfig), not by name
        assert "my_http_config" in result
        assert "other_fixture" not in result

    def test_no_fixtures_returns_empty(self, request):
        """Test that empty list is returned when no matching fixtures."""
        result = _get_fixture_names_by_type(request, HttpTestConfig)
        # Should return empty list or list without HttpTestConfig fixtures
        for name in result:
            pass  # Just verify it's iterable


class TestAnnotationBasedDiscoveryErrorPropagation:
    """Tests for error propagation in annotation-based discovery."""

    def test_httpconfig_fixture_error_is_skipped(self):
        """Test that errors from HttpTestConfig fixtures are skipped (try next candidate)."""
        mock_request = MagicMock()
        mock_request.fixturenames = ["my_config"]

        # Mock fixture info and manager for annotation-based discovery
        mock_fixturedef = MagicMock()
        mock_fixturedef.func.__annotations__ = {"return": HttpTestConfig}

        mock_request._fixturemanager = MagicMock()
        mock_request.node = MagicMock()

        # Mock _arg2fixturedefs
        mock_request._fixturemanager._arg2fixturedefs = {
            "my_config": [mock_fixturedef],
        }
        mock_request._fixturemanager.getfixturedefs.return_value = [mock_fixturedef]

        # The fixture should raise an error when accessed
        mock_request.getfixturevalue.side_effect = RuntimeError("Configuration error")

        # The error should be caught and None returned (no config found)
        result = _find_config_from_request(mock_request)
        assert result is None

    def test_non_candidate_fixture_error_is_suppressed(self):
        """Test that errors from non-HttpTestConfig fixtures are suppressed."""
        expected_config = HttpTestConfig(
            ignore_request_headers=["Authorization"],
        )

        mock_request = MagicMock()
        mock_request.fixturenames = ["broken_fixture", "http_config"]

        # No annotation info, so fallback path is used
        mock_request._fixtureinfo = None

        def get_fixture(name: str):
            if name == "broken_fixture":
                raise RuntimeError("This fixture is broken")
            return expected_config

        mock_request.getfixturevalue.side_effect = get_fixture

        # Should find the config despite the broken fixture
        result = _find_config_from_request(mock_request)
        assert result is expected_config


class TestFixtureDiscoveryIntegration:
    """Integration tests for fixture discovery with decorator."""

    def test_decorator_uses_discovered_config(self, tmp_path, monkeypatch):
        """Test that decorator uses config from fixture when available."""
        from fixturify.http_d import http

        recordings_file = tmp_path / "recordings.json"

        # Create a recordings file for playback mode
        data = {
            "mappings": [
                {
                    "request": {
                        "method": "GET",
                        "url": "https://api.example.com/test",
                        "headers": {},
                        "queryParameters": {},
                    },
                    "response": {
                        "status": 200,
                        "headers": {},
                        "body": "OK",
                    },
                }
            ]
        }
        with open(recordings_file, "w") as f:
            json.dump(data, f)

        monkeypatch.setattr(
            "fixturify.http_d._decorator._PathResolver.resolve_without_check",
            lambda path, reference_file: recordings_file,
        )

        # Track what config was used
        used_configs = []

        class MockHttpMockContext:
            def __init__(self, path, config):
                used_configs.append(config)

            def __enter__(self):
                return self

            def __exit__(self, *args):
                return False

        monkeypatch.setattr(
            "fixturify.http_d._decorator.HttpMockContext",
            MockHttpMockContext,
        )

        # Mock the fixture discovery to return a specific config
        discovered_config = HttpTestConfig(
            ignore_request_headers=["X-Discovered"],
            strict_order=True,
        )

        monkeypatch.setattr(
            "fixturify.http_d._decorator._find_config_from_request",
            lambda request: discovered_config,
        )

        @http(path="./fixtures/test.json")
        def test_func():
            pass

        # Call the function (pytest would normally inject 'request')
        test_func(request=MagicMock())

        # Verify discovered config was used
        assert len(used_configs) == 1
        assert used_configs[0] is discovered_config

    def test_explicit_config_overrides_fixture(self, tmp_path, monkeypatch):
        """Test that explicit config parameter takes precedence."""
        from fixturify.http_d import http

        recordings_file = tmp_path / "recordings.json"

        monkeypatch.setattr(
            "fixturify.http_d._decorator._PathResolver.resolve_without_check",
            lambda path, reference_file: recordings_file,
        )

        used_configs = []

        class MockHttpMockContext:
            def __init__(self, path, config):
                used_configs.append(config)

            def __enter__(self):
                return self

            def __exit__(self, *args):
                return False

        monkeypatch.setattr(
            "fixturify.http_d._decorator.HttpMockContext",
            MockHttpMockContext,
        )

        # This should NOT be used because explicit config is provided
        fixture_config = HttpTestConfig(ignore_request_headers=["X-Fixture"])

        monkeypatch.setattr(
            "fixturify.http_d._decorator._find_config_from_request",
            lambda request: fixture_config,
        )

        # Explicit config
        explicit_config = HttpTestConfig(
            ignore_request_headers=["X-Explicit"],
            match_request_body=False,
        )

        @http(path="./fixtures/test.json", config=explicit_config)
        def test_func():
            pass

        test_func()

        # Explicit config should be used, not fixture config
        assert len(used_configs) == 1
        assert used_configs[0] is explicit_config
        assert "x-explicit" in used_configs[0].get_ignore_request_headers_set()

    def test_fallback_to_default_when_no_fixture(self, tmp_path, monkeypatch):
        """Test fallback to default config when no fixture found."""
        from fixturify.http_d import http

        recordings_file = tmp_path / "recordings.json"

        monkeypatch.setattr(
            "fixturify.http_d._decorator._PathResolver.resolve_without_check",
            lambda path, reference_file: recordings_file,
        )

        used_configs = []

        class MockHttpMockContext:
            def __init__(self, path, config):
                used_configs.append(config)

            def __enter__(self):
                return self

            def __exit__(self, *args):
                return False

        monkeypatch.setattr(
            "fixturify.http_d._decorator.HttpMockContext",
            MockHttpMockContext,
        )

        # No fixture found
        monkeypatch.setattr(
            "fixturify.http_d._decorator._find_config_from_request",
            lambda request: None,
        )

        @http(path="./fixtures/test.json")
        def test_func():
            pass

        test_func(request=MagicMock())

        # Default config should be created when no fixture found
        assert len(used_configs) == 1
        config = used_configs[0]
        # Default config should have default values
        assert config.strict_order is False
        assert config.match_request_body is True


class TestRealFixtureDiscovery:
    """Tests with real pytest fixtures to verify discovery works end-to-end."""

    @pytest.fixture
    def my_custom_http_settings(self) -> HttpTestConfig:
        """Fixture with custom name - discovery should work by TYPE, not name."""
        return HttpTestConfig(
            ignore_request_headers=["X-Test-Header"],
            exclude_hosts=["testserver"],
            strict_order=True,
        )

    def test_discovers_config_by_type_not_name(self, request):
        """Test that fixture is found by return TYPE annotation, not by name."""
        # The fixture is named 'my_custom_http_settings', NOT 'http_config'
        # Discovery should still find it because it returns HttpTestConfig
        result = _find_config_from_request(request)

        # Should find our fixture by type even though it has a custom name
        assert result is not None, "Expected to find HttpTestConfig fixture by type"
        assert isinstance(result, HttpTestConfig)
        assert "x-test-header" in result.get_ignore_request_headers_set()
        assert "testserver" in result.get_exclude_hosts_set()
        assert result.strict_order is True


class TestRealFixtureDiscoveryWithAnotherName:
    """Additional test class with differently named fixture."""

    @pytest.fixture
    def arbitrary_name_for_config(self) -> HttpTestConfig:
        """Fixture with completely arbitrary name."""
        return HttpTestConfig(
            match_request_body=False,
            ignore_request_headers=["Authorization"],
        )

    def test_finds_arbitrarily_named_fixture(self, request):
        """Verify discovery works with any fixture name."""
        result = _find_config_from_request(request)

        assert result is not None, "Should find fixture regardless of name"
        assert isinstance(result, HttpTestConfig)
        assert result.match_request_body is False
        assert "authorization" in result.get_ignore_request_headers_set()
