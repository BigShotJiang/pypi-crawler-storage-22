"""Tests for HTTP request matcher."""

from fixturify.http_d import HttpMapping, HttpRequest, HttpResponse
from fixturify.http_d._matcher import RequestMatcher


class TestRequestMatcherBasic:
    """Basic tests for RequestMatcher."""

    def test_match_exact_request(self):
        """Test matching identical requests."""
        matcher = RequestMatcher()

        request = HttpRequest(
            method="GET",
            url="https://api.example.com/users",
            headers={"Accept": "application/json"},
        )

        mapping = HttpMapping(
            request=HttpRequest(
                method="GET",
                url="https://api.example.com/users",
                headers={"Accept": "application/json"},
            ),
            response=HttpResponse(status=200),
        )

        result = matcher.find_match(request, [mapping], set())

        assert result is not None
        assert result[0] == 0

    def test_no_match_different_method(self):
        """Test no match when methods differ."""
        matcher = RequestMatcher()

        request = HttpRequest(method="POST", url="https://api.example.com/users")
        mapping = HttpMapping(
            request=HttpRequest(method="GET", url="https://api.example.com/users"),
            response=HttpResponse(status=200),
        )

        result = matcher.find_match(request, [mapping], set())

        assert result is None

    def test_no_match_different_url(self):
        """Test no match when URLs differ."""
        matcher = RequestMatcher()

        request = HttpRequest(method="GET", url="https://api.example.com/items")
        mapping = HttpMapping(
            request=HttpRequest(method="GET", url="https://api.example.com/users"),
            response=HttpResponse(status=200),
        )

        result = matcher.find_match(request, [mapping], set())

        assert result is None

    def test_method_case_insensitive(self):
        """Test that method matching is case-insensitive."""
        matcher = RequestMatcher()

        request = HttpRequest(method="get", url="https://api.example.com/users")
        mapping = HttpMapping(
            request=HttpRequest(method="GET", url="https://api.example.com/users"),
            response=HttpResponse(status=200),
        )

        result = matcher.find_match(request, [mapping], set())

        assert result is not None


class TestRequestMatcherHeaders:
    """Tests for header matching."""

    def test_ignore_default_headers(self):
        """Test that default headers are ignored."""
        matcher = RequestMatcher()

        request = HttpRequest(
            method="GET",
            url="https://api.example.com/users",
            headers={
                "User-Agent": "Test/1.0",  # Should be ignored
                "Accept": "application/json",
            },
        )

        mapping = HttpMapping(
            request=HttpRequest(
                method="GET",
                url="https://api.example.com/users",
                headers={
                    "User-Agent": "Different/2.0",  # Different but ignored
                    "Accept": "application/json",
                },
            ),
            response=HttpResponse(status=200),
        )

        result = matcher.find_match(request, [mapping], set())

        assert result is not None

    def test_custom_ignored_headers(self):
        """Test custom ignored headers."""
        matcher = RequestMatcher(ignore_headers=["Authorization", "X-Request-ID"])

        request = HttpRequest(
            method="GET",
            url="https://api.example.com/users",
            headers={
                "Authorization": "Bearer token123",
                "X-Request-ID": "abc-123",
            },
        )

        mapping = HttpMapping(
            request=HttpRequest(
                method="GET",
                url="https://api.example.com/users",
                headers={
                    "Authorization": "Bearer different",
                    "X-Request-ID": "xyz-789",
                },
            ),
            response=HttpResponse(status=200),
        )

        result = matcher.find_match(request, [mapping], set())

        assert result is not None

    def test_missing_required_header_no_match(self):
        """Test no match when required header is missing."""
        matcher = RequestMatcher()

        request = HttpRequest(
            method="GET",
            url="https://api.example.com/users",
            headers={},  # Missing Accept header
        )

        mapping = HttpMapping(
            request=HttpRequest(
                method="GET",
                url="https://api.example.com/users",
                headers={"Accept": "application/json"},
            ),
            response=HttpResponse(status=200),
        )

        result = matcher.find_match(request, [mapping], set())

        assert result is None

    def test_extra_headers_allowed(self):
        """Test that extra headers in actual request are allowed."""
        matcher = RequestMatcher()

        request = HttpRequest(
            method="GET",
            url="https://api.example.com/users",
            headers={
                "Accept": "application/json",
                "X-Custom": "value",  # Extra header
            },
        )

        mapping = HttpMapping(
            request=HttpRequest(
                method="GET",
                url="https://api.example.com/users",
                headers={"Accept": "application/json"},
            ),
            response=HttpResponse(status=200),
        )

        result = matcher.find_match(request, [mapping], set())

        assert result is not None


class TestRequestMatcherQueryParams:
    """Tests for query parameter matching."""

    def test_match_query_params(self):
        """Test matching with query parameters."""
        matcher = RequestMatcher()

        request = HttpRequest(
            method="GET",
            url="https://api.example.com/users",
            queryParameters={"page": "1", "limit": "10"},
        )

        mapping = HttpMapping(
            request=HttpRequest(
                method="GET",
                url="https://api.example.com/users",
                queryParameters={"page": "1", "limit": "10"},
            ),
            response=HttpResponse(status=200),
        )

        result = matcher.find_match(request, [mapping], set())

        assert result is not None

    def test_no_match_different_query_params(self):
        """Test no match when query params differ."""
        matcher = RequestMatcher()

        request = HttpRequest(
            method="GET",
            url="https://api.example.com/users",
            queryParameters={"page": "2"},  # Different value
        )

        mapping = HttpMapping(
            request=HttpRequest(
                method="GET",
                url="https://api.example.com/users",
                queryParameters={"page": "1"},
            ),
            response=HttpResponse(status=200),
        )

        result = matcher.find_match(request, [mapping], set())

        assert result is None

    def test_query_params_from_url(self):
        """Test extracting query params from URL."""
        matcher = RequestMatcher()

        request = HttpRequest(
            method="GET",
            url="https://api.example.com/users?page=1",
            queryParameters={},
        )

        mapping = HttpMapping(
            request=HttpRequest(
                method="GET",
                url="https://api.example.com/users?page=1",
                queryParameters={},
            ),
            response=HttpResponse(status=200),
        )

        result = matcher.find_match(request, [mapping], set())

        assert result is not None


class TestRequestMatcherBody:
    """Tests for body matching."""

    def test_match_json_body(self):
        """Test matching JSON body."""
        matcher = RequestMatcher(match_body=True)

        request = HttpRequest(
            method="POST",
            url="https://api.example.com/users",
            body='{"name": "John", "age": 30}',
        )

        mapping = HttpMapping(
            request=HttpRequest(
                method="POST",
                url="https://api.example.com/users",
                body='{"age": 30, "name": "John"}',  # Different key order
            ),
            response=HttpResponse(status=201),
        )

        result = matcher.find_match(request, [mapping], set())

        assert result is not None

    def test_no_match_different_json_body(self):
        """Test no match when JSON body differs."""
        matcher = RequestMatcher(match_body=True)

        request = HttpRequest(
            method="POST",
            url="https://api.example.com/users",
            body='{"name": "John"}',
        )

        mapping = HttpMapping(
            request=HttpRequest(
                method="POST",
                url="https://api.example.com/users",
                body='{"name": "Jane"}',
            ),
            response=HttpResponse(status=201),
        )

        result = matcher.find_match(request, [mapping], set())

        assert result is None

    def test_skip_body_matching(self):
        """Test skipping body matching when disabled."""
        matcher = RequestMatcher(match_body=False)

        request = HttpRequest(
            method="POST",
            url="https://api.example.com/users",
            body='{"name": "John"}',
        )

        mapping = HttpMapping(
            request=HttpRequest(
                method="POST",
                url="https://api.example.com/users",
                body='{"name": "Completely Different"}',
            ),
            response=HttpResponse(status=201),
        )

        result = matcher.find_match(request, [mapping], set())

        assert result is not None


class TestRequestMatcherStrictOrder:
    """Tests for strict order matching."""

    def test_strict_order_match_first(self):
        """Test strict order matches first unused."""
        matcher = RequestMatcher(strict_order=True)

        request = HttpRequest(method="GET", url="https://api.example.com/first")

        mappings = [
            HttpMapping(
                request=HttpRequest(method="GET", url="https://api.example.com/first"),
                response=HttpResponse(status=200),
            ),
            HttpMapping(
                request=HttpRequest(method="GET", url="https://api.example.com/second"),
                response=HttpResponse(status=200),
            ),
        ]

        result = matcher.find_match(request, mappings, set())

        assert result is not None
        assert result[0] == 0

    def test_strict_order_no_match_wrong_order(self):
        """Test strict order fails when order is wrong."""
        matcher = RequestMatcher(strict_order=True)

        # Request for second URL before first is used
        request = HttpRequest(method="GET", url="https://api.example.com/second")

        mappings = [
            HttpMapping(
                request=HttpRequest(method="GET", url="https://api.example.com/first"),
                response=HttpResponse(status=200),
            ),
            HttpMapping(
                request=HttpRequest(method="GET", url="https://api.example.com/second"),
                response=HttpResponse(status=200),
            ),
        ]

        result = matcher.find_match(request, mappings, set())

        assert result is None

    def test_non_strict_order_allows_any_order(self):
        """Test non-strict order allows matching any recording."""
        matcher = RequestMatcher(strict_order=False)

        request = HttpRequest(method="GET", url="https://api.example.com/second")

        mappings = [
            HttpMapping(
                request=HttpRequest(method="GET", url="https://api.example.com/first"),
                response=HttpResponse(status=200),
            ),
            HttpMapping(
                request=HttpRequest(method="GET", url="https://api.example.com/second"),
                response=HttpResponse(status=200),
            ),
        ]

        result = matcher.find_match(request, mappings, set())

        assert result is not None
        assert result[0] == 1


class TestRequestMatcherUsedIndices:
    """Tests for tracking used indices."""

    def test_skip_used_indices(self):
        """Test that used indices are skipped."""
        matcher = RequestMatcher()

        request = HttpRequest(method="GET", url="https://api.example.com/users")

        mappings = [
            HttpMapping(
                request=HttpRequest(method="GET", url="https://api.example.com/users"),
                response=HttpResponse(status=200, body="first"),
            ),
            HttpMapping(
                request=HttpRequest(method="GET", url="https://api.example.com/users"),
                response=HttpResponse(status=200, body="second"),
            ),
        ]

        # First match
        result1 = matcher.find_match(request, mappings, set())
        assert result1[0] == 0

        # Mark first as used
        used = {0}

        # Second match should skip index 0
        result2 = matcher.find_match(request, mappings, used)
        assert result2[0] == 1


class TestRequestMatcherMismatchDetails:
    """Tests for mismatch detail reporting."""

    def test_get_mismatch_details_method(self):
        """Test getting mismatch details for method."""
        matcher = RequestMatcher()

        actual = HttpRequest(method="POST", url="https://api.example.com/users")
        expected = HttpRequest(method="GET", url="https://api.example.com/users")

        details = matcher.get_mismatch_details(actual, expected)

        assert "method" in details
        assert details["method"] == ("POST", "GET")

    def test_get_mismatch_details_url(self):
        """Test getting mismatch details for URL."""
        matcher = RequestMatcher()

        actual = HttpRequest(method="GET", url="https://api.example.com/items")
        expected = HttpRequest(method="GET", url="https://api.example.com/users")

        details = matcher.get_mismatch_details(actual, expected)

        assert "url" in details

    def test_get_mismatch_details_body(self):
        """Test getting mismatch details for body."""
        matcher = RequestMatcher(match_body=True)

        actual = HttpRequest(
            method="POST",
            url="https://api.example.com/users",
            body='{"name": "John"}',
        )
        expected = HttpRequest(
            method="POST",
            url="https://api.example.com/users",
            body='{"name": "Jane"}',
        )

        details = matcher.get_mismatch_details(actual, expected)

        assert "body" in details
