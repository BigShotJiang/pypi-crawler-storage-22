"""Tests for HTTP recorder."""

import json

from fixturify.http_d import HttpRequest, HttpResponse
from fixturify.http_d._recorder import (
    HttpRecorder,
    _is_text_content_type,
    _is_json_content_type,
    _is_binary_content_type,
    _serialize_body,
    _get_file_extension,
)


class TestContentTypeDetection:
    """Tests for content type detection functions."""

    def test_is_text_content_type(self):
        """Test text content type detection."""
        assert _is_text_content_type("text/plain") is True
        assert _is_text_content_type("text/html") is True
        assert _is_text_content_type("application/json") is True
        assert _is_text_content_type("application/xml") is True
        assert _is_text_content_type("application/javascript") is True
        assert _is_text_content_type("image/png") is False
        assert _is_text_content_type("application/pdf") is False

    def test_is_json_content_type(self):
        """Test JSON content type detection."""
        assert _is_json_content_type("application/json") is True
        assert _is_json_content_type("application/json; charset=utf-8") is True
        assert _is_json_content_type("text/plain") is False
        assert _is_json_content_type("application/xml") is False

    def test_is_binary_content_type(self):
        """Test binary content type detection."""
        assert _is_binary_content_type("image/png") is True
        assert _is_binary_content_type("image/jpeg") is True
        assert _is_binary_content_type("application/pdf") is True
        assert _is_binary_content_type("application/zip") is True
        assert _is_binary_content_type("audio/mpeg") is True
        assert _is_binary_content_type("video/mp4") is True
        assert _is_binary_content_type("application/octet-stream") is True
        assert _is_binary_content_type("text/plain") is False
        assert _is_binary_content_type("application/json") is False


class TestSerializeBody:
    """Tests for body serialization."""

    def test_serialize_none_body(self):
        """Test serializing None body."""
        body, encoding, is_binary = _serialize_body(None, "")

        assert body is None
        assert encoding is None
        assert is_binary is False

    def test_serialize_json_body_string(self):
        """Test serializing JSON body from string."""
        body, encoding, is_binary = _serialize_body(
            '{"key": "value"}',
            "application/json",
        )

        assert body == {"key": "value"}  # Parsed JSON
        assert encoding is None
        assert is_binary is False

    def test_serialize_json_body_bytes(self):
        """Test serializing JSON body from bytes."""
        body, encoding, is_binary = _serialize_body(
            b'{"key": "value"}',
            "application/json",
        )

        assert body == {"key": "value"}
        assert encoding is None
        assert is_binary is False

    def test_serialize_text_body(self):
        """Test serializing plain text body."""
        body, encoding, is_binary = _serialize_body(
            "Hello, World!",
            "text/plain",
        )

        assert body == "Hello, World!"
        assert encoding is None
        assert is_binary is False

    def test_serialize_binary_body(self):
        """Test serializing binary body."""
        binary_data = b"\x89PNG\r\n\x1a\n"  # PNG header
        body, encoding, is_binary = _serialize_body(
            binary_data,
            "image/png",
        )

        assert body == binary_data
        assert encoding is None
        assert is_binary is True

    def test_serialize_empty_body(self):
        """Test serializing empty body."""
        body, encoding, is_binary = _serialize_body("", "text/plain")

        assert body is None
        assert is_binary is False


class TestGetFileExtension:
    """Tests for file extension detection."""

    def test_common_extensions(self):
        """Test common file extensions."""
        assert _get_file_extension("application/json") == ".json"
        assert _get_file_extension("application/pdf") == ".pdf"
        assert _get_file_extension("image/png") == ".png"
        assert _get_file_extension("image/jpeg") == ".jpg"
        assert _get_file_extension("text/html") == ".html"
        assert _get_file_extension("application/zip") == ".zip"

    def test_unknown_extension(self):
        """Test unknown content type."""
        assert _get_file_extension("application/x-unknown") == ".bin"


class TestHttpRecorder:
    """Tests for HttpRecorder class."""

    def test_create_recorder(self, tmp_path):
        """Test creating a recorder."""
        file_path = tmp_path / "recordings.json"
        recorder = HttpRecorder(file_path)

        assert len(recorder) == 0
        assert recorder.file_path == file_path

    def test_record_mapping(self, tmp_path):
        """Test recording a mapping."""
        file_path = tmp_path / "recordings.json"
        recorder = HttpRecorder(file_path)

        request = HttpRequest(method="GET", url="https://example.com")
        response = HttpResponse(status=200, body="OK")

        recorder.record(request, response)

        assert len(recorder) == 1

    def test_save_json_body(self, tmp_path):
        """Test saving recording with JSON body."""
        file_path = tmp_path / "recordings.json"
        recorder = HttpRecorder(file_path)

        request = HttpRequest(
            method="POST",
            url="https://api.example.com/data",
            headers={"Content-Type": "application/json"},
            body='{"name": "test"}',
        )
        response = HttpResponse(
            status=201,
            headers={"Content-Type": "application/json"},
            body='{"id": 123}',
        )

        recorder.record(request, response)
        recorder.save()

        # Verify file exists
        assert file_path.exists()

        # Verify JSON content
        with open(file_path) as f:
            data = json.load(f)

        assert len(data["mappings"]) == 1
        mapping = data["mappings"][0]

        # Bodies should be native JSON objects
        assert mapping["request"]["body"] == {"name": "test"}
        assert mapping["response"]["body"] == {"id": 123}

    def test_save_text_body(self, tmp_path):
        """Test saving recording with plain text body."""
        file_path = tmp_path / "recordings.json"
        recorder = HttpRecorder(file_path)

        request = HttpRequest(
            method="GET",
            url="https://example.com/hello",
        )
        response = HttpResponse(
            status=200,
            headers={"Content-Type": "text/plain"},
            body="Hello, World!",
        )

        recorder.record(request, response)
        recorder.save()

        with open(file_path) as f:
            data = json.load(f)

        # Text body should be a string
        assert data["mappings"][0]["response"]["body"] == "Hello, World!"

    def test_save_binary_body(self, tmp_path):
        """Test saving recording with binary body as file."""
        file_path = tmp_path / "recordings.json"
        recorder = HttpRecorder(file_path)

        request = HttpRequest(
            method="GET",
            url="https://example.com/image.png",
        )
        response = HttpResponse(
            status=200,
            headers={"Content-Type": "image/png"},
        )
        # Set binary body directly
        response._body_bytes = b"\x89PNG\r\n\x1a\n" + b"\x00" * 100

        recorder.record(request, response)
        recorder.save()

        # Verify JSON file
        with open(file_path) as f:
            data = json.load(f)

        # Should have bodyFileName, not inline body
        assert "bodyFileName" in data["mappings"][0]["response"]
        assert "body" not in data["mappings"][0]["response"]

        # Verify __files directory exists
        files_dir = tmp_path / "__files"
        assert files_dir.exists()

        # Verify binary file exists
        body_filename = data["mappings"][0]["response"]["bodyFileName"]
        binary_file = files_dir / body_filename
        assert binary_file.exists()

        # Verify content
        with open(binary_file, "rb") as f:
            content = f.read()
        assert content.startswith(b"\x89PNG")

    def test_save_multiple_mappings(self, tmp_path):
        """Test saving multiple mappings."""
        file_path = tmp_path / "recordings.json"
        recorder = HttpRecorder(file_path)

        for i in range(3):
            request = HttpRequest(
                method="GET",
                url=f"https://example.com/item/{i}",
            )
            response = HttpResponse(
                status=200,
                headers={"Content-Type": "application/json"},
                body=f'{{"id": {i}}}',
            )
            recorder.record(request, response)

        recorder.save()

        with open(file_path) as f:
            data = json.load(f)

        assert len(data["mappings"]) == 3

    def test_save_creates_parent_directories(self, tmp_path):
        """Test that save creates parent directories."""
        file_path = tmp_path / "deep" / "nested" / "recordings.json"
        recorder = HttpRecorder(file_path)

        request = HttpRequest(method="GET", url="https://example.com")
        response = HttpResponse(status=200)

        recorder.record(request, response)
        recorder.save()

        assert file_path.exists()
