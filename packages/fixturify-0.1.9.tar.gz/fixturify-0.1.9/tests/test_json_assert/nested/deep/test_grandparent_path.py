"""Tests for JsonAssert with grandparent directory paths (../../)."""

import pytest
from dataclasses import dataclass

from fixturify.json_assert import JsonAssert


@dataclass
class User:
    name: str
    age: int


@dataclass
class UserWithId:
    name: str
    age: int
    id: int


class TestJsonAssertGrandparentPath:
    """Tests for JsonAssert.compare_to_file() with ../../ path patterns."""

    def test_dict_with_grandparent_path(self):
        """Test comparing dict using ../../ path."""
        data = {"name": "John", "age": 30}
        JsonAssert(data).compare_to_file("../../fixtures/user.json")

    def test_dataclass_with_grandparent_path(self):
        """Test comparing dataclass using ../../ path."""
        user = User(name="John", age=30)
        JsonAssert(user).compare_to_file("../../fixtures/user.json")

    def test_list_with_grandparent_path(self):
        """Test comparing list using ../../ path."""
        users = [
            {"name": "John", "age": 30, "id": 1},
            {"name": "Jane", "age": 25, "id": 2},
        ]
        JsonAssert(users).compare_to_file("../../fixtures/users.json")

    def test_json_string_with_grandparent_path(self):
        """Test comparing JSON string using ../../ path."""
        json_str = '{"name": "John", "age": 30}'
        JsonAssert(json_str).compare_to_file("../../fixtures/user.json")


class TestJsonAssertGrandparentPathIgnore:
    """Tests for JsonAssert ignore with ../../ paths."""

    def test_ignore_simple_field_grandparent(self):
        """Test ignore() with ../../ path."""
        data = {"name": "John", "age": 99}
        JsonAssert(data).ignore("age").compare_to_file("../../fixtures/user.json")

    def test_ignore_multiple_fields_grandparent(self):
        """Test ignoring multiple fields with ../../ path."""
        data = {"name": "Different", "age": 99}
        JsonAssert(data).ignore("name", "age").compare_to_file(
            "../../fixtures/user.json"
        )

    def test_ignore_nested_field_grandparent(self):
        """Test ignoring nested field with ../../ path."""
        data = {
            "user": {
                "name": "John",
                "profile": {
                    "age": 99,  # Different
                    "city": "NYC",
                },
            },
            "tags": ["python", "testing"],
        }
        JsonAssert(data).ignore("user.profile.age").compare_to_file(
            "../../fixtures/nested.json"
        )

    def test_wildcard_ignore_grandparent(self):
        """Test wildcard ignore with ../../ path."""
        users = [
            {"name": "John", "age": 30, "id": 999},
            {"name": "Jane", "age": 25, "id": 888},
        ]
        JsonAssert(users).ignore("root[*]['id']").compare_to_file(
            "../../fixtures/users.json"
        )


class TestJsonAssertGrandparentPathOptions:
    """Tests for JsonAssert options with ../../ paths."""

    def test_ignore_order_grandparent(self):
        """Test ignore_order with ../../ path."""
        data = {"tags": ["c", "b", "a"]}
        JsonAssert(data).options(ignore_order=True).compare_to_file(
            "../../fixtures/unordered_list.json"
        )

    def test_numeric_tolerance_grandparent(self):
        """Test numeric_tolerance with ../../ path."""
        data = {"value": 3.14}
        JsonAssert(data).options(numeric_tolerance=0.01).compare_to_file(
            "../../fixtures/float_values.json"
        )

    def test_combined_ignore_and_options_grandparent(self):
        """Test combining ignore() and options() with ../../ path."""
        users = [
            {"name": "John", "age": 30, "id": 999},
            {"name": "Jane", "age": 25, "id": 888},
        ]
        JsonAssert(users).ignore("root[*]['id']").options(
            ignore_order=True
        ).compare_to_file("../../fixtures/users.json")


class TestJsonAssertGrandparentPathMismatch:
    """Tests for mismatch handling with ../../ paths."""

    def test_mismatch_raises_error_grandparent(self):
        """Test that mismatch raises AssertionError with ../../ path."""
        data = {"name": "Jane", "age": 25}

        with pytest.raises(AssertionError) as exc_info:
            JsonAssert(data).compare_to_file("../../fixtures/user.json")

        assert "JSON COMPARISON FAILED" in str(exc_info.value)

    def test_file_not_found_grandparent(self):
        """Test FileNotFoundError with ../../ path."""
        data = {"name": "John"}

        with pytest.raises(FileNotFoundError):
            JsonAssert(data).compare_to_file("../../fixtures/nonexistent.json")
