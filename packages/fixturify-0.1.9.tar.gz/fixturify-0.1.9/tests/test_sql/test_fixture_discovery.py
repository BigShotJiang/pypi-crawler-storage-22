"""Tests for fixture discovery functionality."""

from unittest.mock import MagicMock, patch

import pytest

from fixturify.sql_d import SqlTestConfig
from fixturify.sql_d._fixture_discovery import (
    _find_config_from_request,
    _is_pytest_available,
    _FixtureDiscovery,
)
from fixturify._utils._fixture_discovery import _get_fixture_names_by_type


class TestIsPytestAvailable:
    """Tests for _is_pytest_available function."""

    def test_pytest_is_available(self) -> None:
        """Test that pytest is detected as available in test environment."""
        # Since we're running tests with pytest, it should be available
        assert _is_pytest_available() is True

    def test_class_method_matches_function(self) -> None:
        """Test that class method returns same result as function."""
        assert _FixtureDiscovery.is_pytest_available() == _is_pytest_available()


class TestFindConfigFromRequest:
    """Tests for _find_config_from_request function."""

    def test_returns_none_when_no_fixtures(self) -> None:
        """Test that None is returned when no fixtures are available."""
        mock_request = MagicMock()
        mock_request.fixturenames = []

        result = _find_config_from_request(mock_request)
        assert result is None

    def test_returns_none_when_no_sql_config_fixture(self) -> None:
        """Test that None is returned when no SqlTestConfig fixture exists."""
        mock_request = MagicMock()
        mock_request.fixturenames = ["some_fixture", "another_fixture"]
        mock_request.getfixturevalue.side_effect = [
            "not a config",
            42,
        ]

        result = _find_config_from_request(mock_request)
        assert result is None

    def test_returns_config_when_found(self) -> None:
        """Test that SqlTestConfig is returned when fixture exists."""
        expected_config = SqlTestConfig(
            driver="psycopg2",
            host="localhost",
            database="test",
            user="test",
            password="test",
        )

        mock_request = MagicMock()
        mock_request.fixturenames = ["db_config"]
        mock_request.getfixturevalue.return_value = expected_config

        result = _find_config_from_request(mock_request)
        assert result is expected_config

    def test_finds_config_among_multiple_fixtures(self) -> None:
        """Test that SqlTestConfig is found among multiple fixtures."""
        expected_config = SqlTestConfig(
            driver="asyncpg",
            host="localhost",
            database="test",
            user="test",
            password="test",
        )

        mock_request = MagicMock()
        mock_request.fixturenames = ["fixture1", "db_config", "fixture2"]

        def get_fixture(name: str):
            if name == "fixture1":
                return "string value"
            elif name == "db_config":
                return expected_config
            else:
                return {"key": "value"}

        mock_request.getfixturevalue.side_effect = get_fixture

        result = _find_config_from_request(mock_request)
        assert result is expected_config

    def test_handles_fixture_resolution_errors(self) -> None:
        """Test that fixture resolution errors are handled gracefully."""
        expected_config = SqlTestConfig(
            driver="mysql.connector",
            host="localhost",
            database="test",
            user="test",
            password="test",
        )

        mock_request = MagicMock()
        mock_request.fixturenames = ["failing_fixture", "good_fixture"]

        def get_fixture(name: str):
            if name == "failing_fixture":
                raise RuntimeError("Fixture failed to resolve")
            return expected_config

        mock_request.getfixturevalue.side_effect = get_fixture

        result = _find_config_from_request(mock_request)
        assert result is expected_config

    def test_returns_first_config_found(self) -> None:
        """Test that the first SqlTestConfig is returned when multiple exist."""
        first_config = SqlTestConfig(
            driver="psycopg2",
            host="localhost",
            database="test1",
            user="test",
            password="test",
        )
        second_config = SqlTestConfig(
            driver="asyncpg",
            host="localhost",
            database="test2",
            user="test",
            password="test",
        )

        mock_request = MagicMock()
        mock_request.fixturenames = ["config1", "config2"]

        def get_fixture(name: str):
            if name == "config1":
                return first_config
            return second_config

        mock_request.getfixturevalue.side_effect = get_fixture

        result = _find_config_from_request(mock_request)
        assert result is first_config


class TestFixtureDiscoveryClass:
    """Tests for _FixtureDiscovery class."""

    def test_class_method_find_config_from_request(self) -> None:
        """Test that class method delegates to function correctly."""
        expected_config = SqlTestConfig(
            driver="psycopg2",
            host="localhost",
            database="test",
            user="test",
            password="test",
        )

        mock_request = MagicMock()
        mock_request.fixturenames = ["db_config"]
        mock_request.getfixturevalue.return_value = expected_config

        result = _FixtureDiscovery.find_config_from_request(mock_request)
        assert result is expected_config


class TestPytestAvailabilityMocking:
    """Tests for pytest availability with mocking."""

    def test_pytest_unavailable_when_import_fails(self) -> None:
        """Test that pytest is detected as unavailable when import fails."""
        # When pytest is set to None in sys.modules, import pytest will raise TypeError
        # which is converted to ImportError behavior
        with patch.dict("sys.modules", {"pytest": None}):
            # Creating the function inline to test with mocked modules
            def check_pytest_available() -> bool:
                try:
                    import pytest  # noqa: F401

                    return True
                except (ImportError, TypeError):
                    return False

            # With pytest mocked as None, it should return False
            assert check_pytest_available() is False

    def test_original_function_works(self) -> None:
        """Test that the original function works without mocking."""
        # Outside of mocking context, pytest should be available
        assert _is_pytest_available() is True


class TestAnnotationBasedDiscovery:
    """Tests for annotation-based fixture discovery."""

    def test_no_fixturemanager_returns_empty(self) -> None:
        """Test that empty list is returned when _fixturemanager is missing."""
        mock_request = MagicMock()
        del mock_request._fixturemanager
        result = _get_fixture_names_by_type(mock_request, SqlTestConfig)
        assert result == []

    def test_no_node_returns_empty(self) -> None:
        """Test that empty list is returned when node is missing."""
        mock_request = MagicMock()
        mock_request._fixturemanager = MagicMock()
        del mock_request.node
        result = _get_fixture_names_by_type(mock_request, SqlTestConfig)
        assert result == []

    def test_finds_fixture_by_type_not_name(self) -> None:
        """Test that fixture is found by return TYPE annotation, not by name."""
        mock_request = MagicMock()
        mock_request.fixturenames = ["my_custom_db_config", "other_fixture"]

        # Mock fixture definitions
        mock_fixturedef = MagicMock()
        mock_fixturedef.func.__annotations__ = {"return": SqlTestConfig}

        mock_other_fixturedef = MagicMock()
        mock_other_fixturedef.func.__annotations__ = {"return": str}

        mock_request._fixturemanager = MagicMock()
        mock_request.node = MagicMock()

        # Mock _arg2fixturedefs - this is where all fixtures are registered
        mock_request._fixturemanager._arg2fixturedefs = {
            "my_custom_db_config": [mock_fixturedef],
            "other_fixture": [mock_other_fixturedef],
        }

        def get_fixturedefs(name, node):
            if name == "my_custom_db_config":
                return [mock_fixturedef]
            elif name == "other_fixture":
                return [mock_other_fixturedef]
            return None

        mock_request._fixturemanager.getfixturedefs.side_effect = get_fixturedefs

        result = _get_fixture_names_by_type(mock_request, SqlTestConfig)
        # Should find by TYPE (SqlTestConfig), not by name
        assert "my_custom_db_config" in result
        assert "other_fixture" not in result


class TestFixtureDiscoveryErrorPropagation:
    """Tests for error propagation in fixture discovery."""

    def test_sqlconfig_fixture_error_is_skipped(self) -> None:
        """Test that errors from SqlTestConfig fixtures are skipped (try next candidate)."""
        mock_request = MagicMock()
        mock_request.fixturenames = ["my_db_config"]

        # Mock fixture info and manager
        mock_fixturedef = MagicMock()
        mock_fixturedef.func.__annotations__ = {"return": SqlTestConfig}

        mock_request._fixturemanager = MagicMock()
        mock_request.node = MagicMock()

        # Mock _arg2fixturedefs
        mock_request._fixturemanager._arg2fixturedefs = {
            "my_db_config": [mock_fixturedef],
        }
        mock_request._fixturemanager.getfixturedefs.return_value = [mock_fixturedef]

        # The fixture should raise an error when accessed
        mock_request.getfixturevalue.side_effect = RuntimeError(
            "Database connection failed"
        )

        # The error should be caught and None returned (no config found)
        result = _find_config_from_request(mock_request)
        assert result is None

    def test_non_candidate_fixture_error_is_suppressed(self) -> None:
        """Test that errors from non-SqlTestConfig fixtures are suppressed."""
        expected_config = SqlTestConfig(
            driver="psycopg2",
            host="localhost",
            database="test",
            user="test",
            password="test",
        )

        mock_request = MagicMock()
        mock_request.fixturenames = ["broken_fixture", "db_config"]

        # No annotation info, so fallback path is used
        mock_request._fixturemanager = None

        def get_fixture(name: str):
            if name == "broken_fixture":
                raise RuntimeError("This fixture is broken")
            return expected_config

        mock_request.getfixturevalue.side_effect = get_fixture

        # Should find the config despite the broken fixture
        result = _find_config_from_request(mock_request)
        assert result is expected_config


class TestRealFixtureDiscoveryByType:
    """Tests with real pytest fixtures to verify discovery works by TYPE, not name."""

    @pytest.fixture
    def my_custom_db_settings(self) -> SqlTestConfig:
        """Fixture with custom name - discovery should work by TYPE, not name."""
        return SqlTestConfig(
            driver="psycopg2",
            host="localhost",
            database="testdb",
            user="testuser",
            password="testpass",
        )

    def test_discovers_config_by_type_not_name(self, request) -> None:
        """Test that a SqlTestConfig fixture is found by TYPE annotation."""
        # Discovery finds fixtures by return TYPE, not by name
        # Multiple fixtures may return SqlTestConfig (including conftest.py ones)
        result = _find_config_from_request(request)

        # Should find a SqlTestConfig fixture
        assert result is not None, "Should find a SqlTestConfig fixture"
        assert isinstance(result, SqlTestConfig)
        # Verify it has the required SqlTestConfig attributes
        assert hasattr(result, "driver")
        assert hasattr(result, "host")
        assert hasattr(result, "database")


class TestRealFixtureDiscoveryWithAnotherName:
    """Additional test class with differently named fixture."""

    @pytest.fixture
    def arbitrary_database_config(self) -> SqlTestConfig:
        """Fixture with completely arbitrary name."""
        return SqlTestConfig(
            driver="asyncpg",
            host="remote-host",
            database="production",
            user="admin",
            password="secret",
        )

    def test_finds_arbitrarily_named_fixture(self, request) -> None:
        """Verify discovery finds a SqlTestConfig fixture."""
        result = _find_config_from_request(request)

        # Should find a SqlTestConfig fixture (may be from conftest or class fixture)
        assert result is not None, "Should find a SqlTestConfig fixture"
        assert isinstance(result, SqlTestConfig)
