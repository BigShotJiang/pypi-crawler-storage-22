"""FlagKit SDK for Python.

A feature flag evaluation and analytics SDK for Python applications.

Example:
    >>> from flagkit import FlagKit
    >>>
    >>> client = FlagKit.initialize(api_key="sdk_...")
    >>> client.wait_for_ready()
    >>>
    >>> # Identify user
    >>> client.identify("user-123", {"email": "user@example.com"})
    >>>
    >>> # Evaluate flags
    >>> dark_mode = client.get_boolean_value("dark-mode", default=False)
    >>>
    >>> # Track events
    >>> client.track("button_clicked", {"button": "signup"})
    >>>
    >>> # Cleanup
    >>> client.close()
"""

from flagkit.client import FlagKitClient
from flagkit.errors.flagkit_error import (
    AuthenticationError,
    EvaluationError,
    FlagKitError,
    InitializationError,
    NetworkError,
)
from flagkit.flagkit import FlagKit
from flagkit.http.http_client import SDK_VERSION
from flagkit.types.config import EvaluationJitterConfig, FlagKitOptions
from flagkit.types.context import EvaluationContext
from flagkit.types.flag import (
    EvaluationReason,
    EvaluationResult,
    FlagState,
    FlagType,
    FlagValue,
)

__version__ = SDK_VERSION
__all__ = [
    # Main classes
    "FlagKit",
    "FlagKitClient",
    # Types
    "FlagKitOptions",
    "EvaluationJitterConfig",
    "EvaluationContext",
    "FlagState",
    "FlagValue",
    "FlagType",
    "EvaluationResult",
    "EvaluationReason",
    # Errors
    "FlagKitError",
    "InitializationError",
    "AuthenticationError",
    "NetworkError",
    "EvaluationError",
    # Version
    "__version__",
]
