"""FlagKit SDK client implementation."""

import random
import time
from datetime import datetime, timedelta, timezone
from typing import Any, Optional, TypeVar

from flagkit.core.cache import CacheConfig, FlagCache
from flagkit.core.context_manager import ContextManager
from flagkit.core.event_queue import EventQueue, EventQueueOptions
from flagkit.core.polling_manager import PollingConfig, PollingManager
from flagkit.errors.flagkit_error import FlagKitError, InitializationError, SecurityError
from flagkit.http.circuit_breaker import CircuitBreakerConfig
from flagkit.http.http_client import SDK_VERSION, HttpClient, HttpClientConfig, get_base_url
from flagkit.http.retry import RetryConfig
from flagkit.types.config import (
    BootstrapConfig,
    FlagKitOptions,
    ResolvedConfig,
)
from flagkit.types.context import EvaluationContext
from flagkit.types.flag import (
    EvaluationResult,
    FlagState,
    FlagType,
    FlagValue,
    InitResponse,
    UpdatesResponse,
    create_default_result,
)
from flagkit.utils.logger import Logger, create_logger
from flagkit.utils.platform import generate_session_id
from flagkit.utils.security import check_for_potential_pii, verify_bootstrap_signature
from flagkit.utils.validators import is_valid_context, is_valid_flag_key, validate_options
from flagkit.utils.version import is_version_less_than

T = TypeVar("T", bound=FlagValue)


class FlagKitClient:
    """FlagKit SDK Client.

    Main interface for feature flag evaluation and event tracking.
    """

    def __init__(self, options: FlagKitOptions) -> None:
        # Validate options
        validate_options(options)

        # Build resolved config
        self._logger: Logger = create_logger(
            logger=options.logger,
            debug=options.debug,
        )

        # Determine base URL: local_port takes precedence over explicit base_url
        effective_base_url = get_base_url(options.local_port) if options.local_port else options.base_url

        self._config = ResolvedConfig(
            api_key=options.api_key,
            secondary_api_key=options.secondary_api_key,
            key_rotation_grace_period=options.key_rotation_grace_period,
            base_url=effective_base_url,
            local_port=options.local_port,
            polling_interval=options.polling_interval,
            enable_polling=options.enable_polling,
            cache_enabled=options.cache_enabled,
            cache_ttl=options.cache_ttl,
            encrypt_cache=options.encrypt_cache,
            offline=options.offline,
            timeout=options.timeout,
            retries=options.retries,
            logger=self._logger,
            bootstrap=options.bootstrap,
            bootstrap_verification=options.bootstrap_verification,
            persist_cache=options.persist_cache,
            cache_storage_key=options.cache_storage_key,
            on_ready=options.on_ready,
            on_error=options.on_error,
            on_update=options.on_update,
            debug=options.debug,
            enable_request_signing=options.enable_request_signing,
            strict_pii_mode=options.strict_pii_mode,
            persist_events=options.persist_events,
            event_storage_path=options.event_storage_path,
            max_persisted_events=options.max_persisted_events,
            persistence_flush_interval=options.persistence_flush_interval,
            evaluation_jitter=options.evaluation_jitter,
            error_sanitization=options.error_sanitization,
        )

        self._session_id = generate_session_id()
        self._is_ready = False
        self._is_closed = False
        self._last_update_time: Optional[str] = None
        self._bootstrap_rejected = False  # Track if bootstrap was rejected due to verification

        # Initialize components
        self._cache = FlagCache(
            config=CacheConfig(ttl=self._config.cache_ttl),
            logger=self._logger,
        )

        self._context_manager = ContextManager(self._logger)

        self._http_client = HttpClient(
            HttpClientConfig(
                base_url=self._config.base_url,
                api_key=self._config.api_key,
                secondary_api_key=self._config.secondary_api_key,
                key_rotation_grace_period=self._config.key_rotation_grace_period,
                timeout=self._config.timeout,
                retry=RetryConfig(max_attempts=self._config.retries),
                circuit_breaker=CircuitBreakerConfig(),
                logger=self._logger,
                enable_request_signing=self._config.enable_request_signing,
            )
        )

        self._event_queue = EventQueue(
            EventQueueOptions(
                http_client=self._http_client,
                logger=self._logger,
                session_id=self._session_id,
                environment_id="",  # Will be set after init
                sdk_version=SDK_VERSION,
            )
        )

        self._polling_manager: Optional[PollingManager] = None

        # Apply bootstrap values
        self._apply_bootstrap()

        self._logger.info(
            "FlagKit client created",
            base_url=self._config.base_url,
            offline=self._config.offline,
        )

    def initialize(self) -> None:
        """Initialize the SDK by fetching flag configurations.

        Raises:
            FlagKitError: If initialization fails.
        """
        if self._config.offline:
            self._logger.info("Offline mode enabled, skipping initialization")
            self._is_ready = True
            if self._config.on_ready:
                self._config.on_ready()
            return

        try:
            self._logger.debug("Initializing SDK")

            response = self._http_client.get("/sdk/init")
            data = InitResponse.from_dict(response.data)

            # Set environment ID for event tracking
            self._event_queue.set_environment_id(data.environment_id)

            # Check SDK version metadata and emit warnings
            self._check_version_metadata(data)

            # Update cache with flags
            self._cache.set_many(data.flags, self._config.cache_ttl)
            self._last_update_time = data.server_time

            # Start polling if enabled
            if self._config.enable_polling:
                self._start_polling(data.polling_interval_seconds)

            self._is_ready = True
            self._logger.info(
                "SDK initialized",
                flag_count=len(data.flags),
                environment=data.environment,
            )

            if self._config.on_ready:
                self._config.on_ready()

        except Exception as error:
            flagkit_error: FlagKitError
            if isinstance(error, FlagKitError):
                flagkit_error = error
            else:
                flagkit_error = InitializationError(
                    "INIT_FAILED",
                    str(error) if str(error) else "Unknown error",
                )

            self._logger.error("SDK initialization failed", error=str(flagkit_error))

            if self._config.on_error:
                self._config.on_error(flagkit_error)

            # Mark as ready anyway (will use cache/bootstrap/defaults)
            self._is_ready = True
            if self._config.on_ready:
                self._config.on_ready()

            raise flagkit_error from error

    def is_ready(self) -> bool:
        """Check if SDK is ready.

        Returns:
            True if the SDK is ready.
        """
        return self._is_ready

    def wait_for_ready(self) -> None:
        """Wait for SDK to be ready.

        In synchronous Python, this just initializes if not ready.
        """
        if not self._is_ready:
            try:
                self.initialize()
            except FlagKitError:
                # Ignore errors - SDK is still usable with defaults
                pass

    def get_boolean_value(
        self,
        key: str,
        default: bool,
        context: Optional[EvaluationContext] = None,
    ) -> bool:
        """Evaluate a boolean flag.

        Args:
            key: Flag key.
            default: Default value.
            context: Optional evaluation context.

        Returns:
            Flag value or default.
        """
        result = self._evaluate_flag(key, default, context, "boolean")
        return bool(result.value)

    def get_string_value(
        self,
        key: str,
        default: str,
        context: Optional[EvaluationContext] = None,
    ) -> str:
        """Evaluate a string flag.

        Args:
            key: Flag key.
            default: Default value.
            context: Optional evaluation context.

        Returns:
            Flag value or default.
        """
        result = self._evaluate_flag(key, default, context, "string")
        return str(result.value)

    def get_number_value(
        self,
        key: str,
        default: float,
        context: Optional[EvaluationContext] = None,
    ) -> float:
        """Evaluate a number flag.

        Args:
            key: Flag key.
            default: Default value.
            context: Optional evaluation context.

        Returns:
            Flag value or default.
        """
        result = self._evaluate_flag(key, default, context, "number")
        return float(result.value)

    def get_json_value(
        self,
        key: str,
        default: dict[str, Any],
        context: Optional[EvaluationContext] = None,
    ) -> dict[str, Any]:
        """Evaluate a JSON flag.

        Args:
            key: Flag key.
            default: Default value.
            context: Optional evaluation context.

        Returns:
            Flag value or default.
        """
        result = self._evaluate_flag(key, default, context, "json")
        return result.value if isinstance(result.value, dict) else default

    def evaluate(
        self,
        key: str,
        context: Optional[EvaluationContext] = None,
    ) -> EvaluationResult[FlagValue]:
        """Evaluate a flag and return full result details.

        Args:
            key: Flag key.
            context: Optional evaluation context.

        Returns:
            Full evaluation result.
        """
        return self._evaluate_flag(key, None, context)

    def evaluate_all(
        self,
        context: Optional[EvaluationContext] = None,
    ) -> dict[str, EvaluationResult[FlagValue]]:
        """Evaluate all flags.

        Args:
            context: Optional evaluation context.

        Returns:
            Dictionary of flag keys to evaluation results.
        """
        results: dict[str, EvaluationResult[FlagValue]] = {}
        for key in self.get_all_flag_keys():
            results[key] = self.evaluate(key, context)
        return results

    def _get_bootstrap_flags(self) -> dict[str, Any]:
        """Get flags from bootstrap configuration.

        Returns:
            Dictionary of flag keys to values.
            Returns empty dict if bootstrap was rejected due to verification failure.
        """
        # If bootstrap was rejected, return empty dict
        if self._bootstrap_rejected:
            return {}

        if isinstance(self._config.bootstrap, BootstrapConfig):
            return self._config.bootstrap.flags
        return self._config.bootstrap

    def has_flag(self, key: str) -> bool:
        """Check if a flag exists.

        Args:
            key: Flag key.

        Returns:
            True if the flag exists.
        """
        return self._cache.has(key) or key in self._get_bootstrap_flags()

    def get_all_flag_keys(self) -> list[str]:
        """Get all flag keys.

        Returns:
            List of flag keys.
        """
        cache_keys = set(self._cache.get_all_keys())
        bootstrap_keys = set(self._get_bootstrap_flags().keys())
        return list(cache_keys | bootstrap_keys)

    def set_context(self, context: EvaluationContext) -> None:
        """Set global evaluation context.

        Args:
            context: The context to set.

        Raises:
            SecurityError: If strict_pii_mode is enabled and PII is detected without private_attributes.
        """
        if not is_valid_context(context):
            self._logger.warn("Invalid context provided to set_context")
            return

        # Security: check for potential PII not marked as private
        if context.custom and not context.private_attributes:
            pii_result = check_for_potential_pii(context.custom, "context")

            if pii_result.has_pii:
                if self._config.strict_pii_mode:
                    raise SecurityError(
                        "SECURITY_PII_DETECTED",
                        f"PII detected in context without private_attributes: {', '.join(pii_result.fields)}. "
                        "Either add these fields to private_attributes or remove them from the context. "
                        "See: https://docs.flagkit.dev/sdk/security#pii-handling",
                    )
                else:
                    self._logger.warn(pii_result.message)

        self._context_manager.set_context(context)

    def get_context(self) -> Optional[EvaluationContext]:
        """Get current global context.

        Returns:
            Current context or None.
        """
        return self._context_manager.get_context()

    def clear_context(self) -> None:
        """Clear global context."""
        self._context_manager.clear_context()

    def identify(
        self,
        user_id: str,
        attributes: Optional[dict[str, Any]] = None,
    ) -> None:
        """Identify a user.

        Args:
            user_id: User identifier.
            attributes: Optional user attributes.

        Raises:
            SecurityError: If strict_pii_mode is enabled and PII is detected in attributes.
        """
        # Security: check for potential PII in attributes
        if attributes:
            pii_result = check_for_potential_pii(attributes, "context")

            if pii_result.has_pii:
                if self._config.strict_pii_mode:
                    raise SecurityError(
                        "SECURITY_PII_DETECTED",
                        f"PII detected in identify attributes: {', '.join(pii_result.fields)}. "
                        "Either add these fields to private_attributes or remove them. "
                        "See: https://docs.flagkit.dev/sdk/security#pii-handling",
                    )
                else:
                    self._logger.warn(pii_result.message)

        self._context_manager.identify(user_id, attributes)
        self._event_queue.track("context.identified", {"userId": user_id})

    def reset(self) -> None:
        """Reset to anonymous user."""
        self._context_manager.reset()
        self._event_queue.track("context.reset")

    def track(self, event_type: str, event_data: Optional[dict[str, Any]] = None) -> None:
        """Track a custom event.

        Args:
            event_type: Type of event.
            event_data: Optional event data.

        Raises:
            SecurityError: If strict_pii_mode is enabled and PII is detected in event data.
        """
        # Security: check for potential PII in event data
        if event_data:
            pii_result = check_for_potential_pii(event_data, "event")

            if pii_result.has_pii:
                if self._config.strict_pii_mode:
                    raise SecurityError(
                        "SECURITY_PII_DETECTED",
                        f"PII detected in event data: {', '.join(pii_result.fields)}. "
                        "Remove sensitive data from events before tracking. "
                        "See: https://docs.flagkit.dev/sdk/security#pii-handling",
                    )
                else:
                    self._logger.warn(pii_result.message)

        self._event_queue.track(event_type, event_data)

    def flush(self) -> None:
        """Flush pending events."""
        self._event_queue.flush()

    def refresh(self) -> None:
        """Force refresh flags from server."""
        if self._config.offline or self._is_closed:
            return

        try:
            since = self._last_update_time
            if since is None:
                since = (datetime.now(timezone.utc) - timedelta(hours=1)).isoformat()

            response = self._http_client.get(f"/sdk/updates?since={since}")
            data = UpdatesResponse.from_dict(response.data)

            if data.flags:
                self._cache.set_many(data.flags)
                self._last_update_time = data.checked_at

                self._logger.debug("Flags refreshed", count=len(data.flags))

                if self._config.on_update:
                    self._config.on_update(data.flags)

        except Exception as error:
            self._logger.warn("Failed to refresh flags", error=str(error))

    def close(self) -> None:
        """Close the SDK and cleanup resources."""
        if self._is_closed:
            return

        self._is_closed = True
        self._logger.debug("Closing SDK")

        # Stop polling
        if self._polling_manager:
            self._polling_manager.stop()
            self._polling_manager = None

        # Flush events
        try:
            self._event_queue.flush()
        except Exception as error:
            self._logger.warn("Failed to flush events on close", error=str(error))

        # Stop event queue
        self._event_queue.stop()

        # Close HTTP client
        self._http_client.close()

        self._logger.info("SDK closed")

    def _evaluate_flag(
        self,
        key: str,
        default_value: Any,
        context: Optional[EvaluationContext] = None,  # noqa: ARG002 (reserved for future use)
        expected_type: Optional[FlagType] = None,
    ) -> EvaluationResult[Any]:
        """Internal flag evaluation logic.

        Args:
            key: Flag key.
            default_value: Default value.
            context: Optional evaluation context.
            expected_type: Expected flag type.

        Returns:
            Evaluation result.
        """
        # Apply jitter at the start if enabled (timing attack protection)
        if self._config.evaluation_jitter.enabled:
            jitter_ms = random.uniform(
                self._config.evaluation_jitter.min_ms,
                self._config.evaluation_jitter.max_ms,
            )
            time.sleep(jitter_ms / 1000)

        # Validate key
        if not is_valid_flag_key(key):
            self._logger.warn("Invalid flag key", key=key)
            return create_default_result(key, default_value, "DEFAULT")

        # Try cache first
        cached = self._cache.get(key)
        if cached:
            # Type check if expected type provided
            if expected_type and cached.flag_type != expected_type:
                self._logger.warn(
                    f"Flag type mismatch: expected {expected_type}, got {cached.flag_type}",
                    key=key,
                )
                return create_default_result(key, default_value, "EVALUATION_ERROR")

            return EvaluationResult(
                flag_key=key,
                value=cached.value,
                enabled=cached.enabled,
                reason="CACHED",
                version=cached.version,
                timestamp=datetime.now(),
            )

        # Try stale cache
        stale = self._cache.get_stale(key)
        if stale:
            self._logger.debug("Using stale cached value", key=key)
            return EvaluationResult(
                flag_key=key,
                value=stale.value,
                enabled=stale.enabled,
                reason="STALE_CACHE",
                version=stale.version,
                timestamp=datetime.now(),
            )

        # Try bootstrap
        bootstrap_flags = self._get_bootstrap_flags()
        if key in bootstrap_flags:
            bootstrap_value = bootstrap_flags[key]
            self._logger.debug("Using bootstrap value", key=key)
            return create_default_result(key, bootstrap_value, "BOOTSTRAP")

        # Return default
        self._logger.debug("Flag not found, using default", key=key)
        return create_default_result(key, default_value, "FLAG_NOT_FOUND")

    def _apply_bootstrap(self) -> None:
        """Apply bootstrap values to cache.

        Handles both legacy dict format and new BootstrapConfig format.
        When BootstrapConfig has a signature, verification is performed
        according to bootstrap_verification options.
        """
        bootstrap = self._config.bootstrap
        flags: dict[str, Any] = {}

        # Determine if this is a BootstrapConfig or legacy dict
        if isinstance(bootstrap, BootstrapConfig):
            # Verify signature if present
            if bootstrap.signature is not None:
                valid, error_message = verify_bootstrap_signature(
                    bootstrap,
                    self._config.api_key,
                    self._config.bootstrap_verification,
                )

                if not valid:
                    on_failure = self._config.bootstrap_verification.on_failure

                    if on_failure == "error":
                        raise SecurityError(
                            "SECURITY_BOOTSTRAP_VERIFICATION_FAILED",
                            error_message or "Bootstrap signature verification failed",
                        )
                    elif on_failure == "warn":
                        self._logger.warn(
                            f"Bootstrap verification failed: {error_message}. "
                            "Using bootstrap values anyway."
                        )
                        flags = bootstrap.flags
                    elif on_failure == "ignore":
                        self._logger.debug(
                            f"Bootstrap verification failed: {error_message}. "
                            "Ignoring bootstrap values."
                        )
                        self._bootstrap_rejected = True
                        return  # Don't apply bootstrap values
                else:
                    flags = bootstrap.flags
            else:
                # No signature, use flags directly
                flags = bootstrap.flags
        else:
            # Legacy dict format
            flags = bootstrap

        # Apply flags to cache
        for key, value in flags.items():
            flag_state = FlagState(
                key=key,
                value=value,
                enabled=True,
                version=0,
                flag_type=self._infer_flag_type(value),
                last_modified=datetime.now(timezone.utc).isoformat(),
            )
            self._cache.set(key, flag_state, float("inf"))  # Bootstrap values don't expire

    def _infer_flag_type(self, value: Any) -> FlagType:
        """Infer flag type from value.

        Args:
            value: The value to infer type from.

        Returns:
            Inferred flag type.
        """
        if isinstance(value, bool):
            return "boolean"
        if isinstance(value, str):
            return "string"
        if isinstance(value, (int, float)):
            return "number"
        return "json"

    def _start_polling(self, interval_seconds: int) -> None:
        """Start background polling.

        Args:
            interval_seconds: Polling interval in seconds.
        """
        if self._polling_manager:
            return

        interval = max(float(interval_seconds), self._config.polling_interval)
        self._polling_manager = PollingManager(
            on_poll=self.refresh,
            config=PollingConfig(interval=interval),
            logger=self._logger,
        )
        self._polling_manager.start()

    def _check_version_metadata(self, response: InitResponse) -> None:
        """Check SDK version metadata from init response and emit appropriate warnings.

        Per spec, the SDK should parse and surface:
        - sdkVersionMin: Minimum required version (older versions may not work)
        - sdkVersionRecommended: Recommended version for optimal experience
        - sdkVersionLatest: Latest available SDK version
        - deprecationWarning: Server-provided deprecation message

        Args:
            response: The init response containing metadata.
        """
        metadata = response.metadata
        if not metadata:
            return

        # Check for server-provided deprecation warning first
        deprecation_warning = metadata.get("deprecationWarning")
        if deprecation_warning:
            self._logger.warn(f"[FlagKit] Deprecation Warning: {deprecation_warning}")

        # Check minimum version requirement
        sdk_version_min = metadata.get("sdkVersionMin")
        if sdk_version_min and is_version_less_than(SDK_VERSION, sdk_version_min):
            self._logger.error(
                f"[FlagKit] SDK version {SDK_VERSION} is below minimum required version {sdk_version_min}. "
                "Some features may not work correctly. Please upgrade the SDK."
            )

        # Check recommended version
        sdk_version_recommended = metadata.get("sdkVersionRecommended")
        if sdk_version_recommended and is_version_less_than(SDK_VERSION, sdk_version_recommended):
            self._logger.warn(
                f"[FlagKit] SDK version {SDK_VERSION} is below recommended version {sdk_version_recommended}. "
                "Consider upgrading for the best experience."
            )

        # Log if a newer version is available (info level, not a warning)
        sdk_version_latest = metadata.get("sdkVersionLatest")
        if sdk_version_latest and is_version_less_than(SDK_VERSION, sdk_version_latest):
            # Only log if we haven't already warned about recommended
            if not sdk_version_recommended or not is_version_less_than(
                SDK_VERSION, sdk_version_recommended
            ):
                self._logger.info(
                    f"[FlagKit] SDK version {SDK_VERSION} - a newer version {sdk_version_latest} is available."
                )

    def __enter__(self) -> "FlagKitClient":
        return self

    def __exit__(self, *_args: Any) -> None:
        self.close()
