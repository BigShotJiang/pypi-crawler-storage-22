"""FlagKit SDK in-memory cache implementation."""

import threading
import time
from dataclasses import dataclass
from typing import Any, Optional

from flagkit.types.flag import FlagState
from flagkit.utils.logger import Logger


@dataclass
class CacheEntry:
    """Cache entry with metadata.

    Attributes:
        flag: The flag state.
        fetched_at: Unix timestamp when fetched.
        expires_at: Unix timestamp when entry expires.
    """

    flag: FlagState
    fetched_at: float
    expires_at: float


@dataclass
class CacheConfig:
    """Cache configuration.

    Attributes:
        ttl: Time-to-live in seconds.
        max_size: Maximum number of entries.
    """

    ttl: float = 300.0  # 5 minutes
    max_size: int = 1000


# Default cache configuration
DEFAULT_CACHE_CONFIG = CacheConfig()


class FlagCache:
    """In-memory cache for flag states with TTL support.

    Thread-safe implementation using locks.
    """

    def __init__(
        self,
        config: Optional[CacheConfig] = None,
        logger: Optional[Logger] = None,
    ) -> None:
        self._config = config or DEFAULT_CACHE_CONFIG
        self._logger = logger
        self._cache: dict[str, CacheEntry] = {}
        self._lock = threading.Lock()

    def get(self, key: str) -> Optional[FlagState]:
        """Get a flag from cache.

        Args:
            key: The flag key.

        Returns:
            The cached flag state or None if not found/expired.
        """
        with self._lock:
            entry = self._cache.get(key)

            if entry is None:
                return None

            # Check if expired - don't delete, just return None
            # Entry stays for get_stale() to retrieve
            if time.time() > entry.expires_at:
                if self._logger:
                    self._logger.debug(f"Cache miss (expired): {key}")
                return None

            if self._logger:
                self._logger.debug(f"Cache hit: {key}")
            return entry.flag

    def get_entry(self, key: str) -> Optional[CacheEntry]:
        """Get a cache entry with metadata.

        Args:
            key: The flag key.

        Returns:
            The cache entry or None.
        """
        with self._lock:
            return self._cache.get(key)

    def is_stale(self, key: str) -> bool:
        """Check if a cached entry is stale (expired but still available).

        Args:
            key: The flag key.

        Returns:
            True if the entry is stale.
        """
        with self._lock:
            entry = self._cache.get(key)
            if entry is None:
                return False
            return time.time() > entry.expires_at

    def get_stale(self, key: str) -> Optional[FlagState]:
        """Get a stale value (even if expired).

        Useful for fallback when network is unavailable.

        Args:
            key: The flag key.

        Returns:
            The flag state or None.
        """
        with self._lock:
            entry = self._cache.get(key)
            return entry.flag if entry else None

    def set(self, key: str, flag: FlagState, ttl: Optional[float] = None) -> None:
        """Set a flag in cache.

        Args:
            key: The flag key.
            flag: The flag state.
            ttl: Optional TTL override in seconds.
        """
        with self._lock:
            # Enforce max size
            if len(self._cache) >= self._config.max_size and key not in self._cache:
                self._evict_oldest()

            now = time.time()
            entry = CacheEntry(
                flag=flag,
                fetched_at=now,
                expires_at=now + (ttl if ttl is not None else self._config.ttl),
            )

            self._cache[key] = entry
            if self._logger:
                self._logger.debug(
                    f"Cache set: {key}",
                    ttl=ttl if ttl is not None else self._config.ttl,
                )

    def set_many(self, flags: list[FlagState], ttl: Optional[float] = None) -> None:
        """Set multiple flags in cache.

        Args:
            flags: List of flag states.
            ttl: Optional TTL override in seconds.
        """
        for flag in flags:
            self.set(flag.key, flag, ttl)

    def delete(self, key: str) -> bool:
        """Delete a flag from cache.

        Args:
            key: The flag key.

        Returns:
            True if the entry was deleted.
        """
        with self._lock:
            if key in self._cache:
                del self._cache[key]
                if self._logger:
                    self._logger.debug(f"Cache delete: {key}")
                return True
            return False

    def clear(self) -> None:
        """Clear all entries from cache."""
        with self._lock:
            size = len(self._cache)
            self._cache.clear()
            if self._logger:
                self._logger.debug(f"Cache cleared: {size} entries removed")

    def get_all_keys(self) -> list[str]:
        """Get all cached flag keys.

        Returns:
            List of flag keys.
        """
        with self._lock:
            return list(self._cache.keys())

    def get_all_valid(self) -> list[FlagState]:
        """Get all valid (non-expired) flags.

        Returns:
            List of valid flag states.
        """
        now = time.time()
        valid: list[FlagState] = []
        to_remove: list[str] = []

        with self._lock:
            for key, entry in self._cache.items():
                if now <= entry.expires_at:
                    valid.append(entry.flag)
                else:
                    to_remove.append(key)

            # Clean up expired entries
            for key in to_remove:
                del self._cache[key]

        return valid

    def get_all(self) -> list[FlagState]:
        """Get all flags including stale ones.

        Returns:
            List of all flag states.
        """
        with self._lock:
            return [entry.flag for entry in self._cache.values()]

    def has(self, key: str) -> bool:
        """Check if flag exists in cache (valid or stale).

        Args:
            key: The flag key.

        Returns:
            True if the flag exists.
        """
        with self._lock:
            return key in self._cache

    def get_stats(self) -> dict[str, Any]:
        """Get cache statistics.

        Returns:
            Dictionary with size, valid_count, stale_count, max_size.
        """
        now = time.time()
        valid_count = 0
        stale_count = 0

        with self._lock:
            for entry in self._cache.values():
                if now <= entry.expires_at:
                    valid_count += 1
                else:
                    stale_count += 1

            return {
                "size": len(self._cache),
                "valid_count": valid_count,
                "stale_count": stale_count,
                "max_size": self._config.max_size,
            }

    def _evict_oldest(self) -> None:
        """Evict the oldest entry from cache."""
        oldest_key: Optional[str] = None
        oldest_time = float("inf")

        for key, entry in self._cache.items():
            if entry.fetched_at < oldest_time:
                oldest_time = entry.fetched_at
                oldest_key = key

        if oldest_key:
            del self._cache[oldest_key]
            if self._logger:
                self._logger.debug(f"Cache evicted oldest: {oldest_key}")

    def export(self) -> dict[str, dict[str, Any]]:
        """Export cache data for persistence.

        Returns:
            Dictionary of cache entries.
        """
        with self._lock:
            result: dict[str, dict[str, Any]] = {}
            for key, entry in self._cache.items():
                result[key] = {
                    "flag": {
                        "key": entry.flag.key,
                        "value": entry.flag.value,
                        "enabled": entry.flag.enabled,
                        "version": entry.flag.version,
                        "flag_type": entry.flag.flag_type,
                        "last_modified": entry.flag.last_modified,
                    },
                    "fetched_at": entry.fetched_at,
                    "expires_at": entry.expires_at,
                }
            return result

    def import_data(self, data: dict[str, dict[str, Any]]) -> None:
        """Import cache data from persistence.

        Args:
            data: Dictionary of cache entries.
        """
        now = time.time()

        with self._lock:
            for key, entry_data in data.items():
                # Only import non-expired entries
                if now <= entry_data["expires_at"]:
                    flag_data = entry_data["flag"]
                    flag = FlagState(
                        key=flag_data["key"],
                        value=flag_data["value"],
                        enabled=flag_data["enabled"],
                        version=flag_data["version"],
                        flag_type=flag_data["flag_type"],
                        last_modified=flag_data["last_modified"],
                    )
                    self._cache[key] = CacheEntry(
                        flag=flag,
                        fetched_at=entry_data["fetched_at"],
                        expires_at=entry_data["expires_at"],
                    )

            if self._logger:
                self._logger.debug(f"Cache imported: {len(self._cache)} entries")
