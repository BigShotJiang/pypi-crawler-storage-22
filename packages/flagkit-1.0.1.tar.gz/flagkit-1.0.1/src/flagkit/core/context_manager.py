"""FlagKit SDK context manager."""

import threading
from typing import Optional

from flagkit.types.context import EvaluationContext, merge_contexts
from flagkit.utils.logger import Logger


class ContextManager:
    """Manages evaluation context for the SDK.

    Thread-safe implementation for context get/set operations.
    """

    def __init__(self, logger: Optional[Logger] = None) -> None:
        self._logger = logger
        self._context: Optional[EvaluationContext] = None
        self._lock = threading.Lock()

    def get_context(self) -> Optional[EvaluationContext]:
        """Get the current global context.

        Returns:
            The current context or None.
        """
        with self._lock:
            return self._context

    def set_context(self, context: EvaluationContext) -> None:
        """Set the global evaluation context.

        Args:
            context: The context to set.
        """
        with self._lock:
            self._context = context
            if self._logger:
                self._logger.debug(
                    "Context set",
                    user_id=context.user_id,
                    has_custom=bool(context.custom),
                )

    def clear_context(self) -> None:
        """Clear the global context."""
        with self._lock:
            self._context = None
            if self._logger:
                self._logger.debug("Context cleared")

    def identify(
        self,
        user_id: str,
        attributes: Optional[dict[str, object]] = None,
    ) -> None:
        """Identify a user.

        Args:
            user_id: The user ID.
            attributes: Additional user attributes.
        """
        attrs = attributes or {}

        # Extract attributes with proper type checking
        email = attrs.get("email")
        name = attrs.get("name")
        country = attrs.get("country")
        custom = attrs.get("custom")

        new_context = EvaluationContext(
            user_id=user_id,
            email=str(email) if isinstance(email, str) else None,
            name=str(name) if isinstance(name, str) else None,
            anonymous=False,
            country=str(country) if isinstance(country, str) else None,
            custom=dict(custom) if isinstance(custom, dict) else {},
        )

        with self._lock:
            self._context = merge_contexts(self._context, new_context)
            if self._logger:
                self._logger.debug("User identified", user_id=user_id)

    def reset(self) -> None:
        """Reset to anonymous user."""
        with self._lock:
            self._context = EvaluationContext(anonymous=True)
            if self._logger:
                self._logger.debug("Context reset to anonymous")

    def merge_context(self, context: Optional[EvaluationContext]) -> Optional[EvaluationContext]:
        """Merge provided context with global context.

        Args:
            context: The context to merge.

        Returns:
            Merged context.
        """
        with self._lock:
            return merge_contexts(self._context, context)

    def get_user_id(self) -> Optional[str]:
        """Get the current user ID.

        Returns:
            User ID or None.
        """
        with self._lock:
            return self._context.user_id if self._context else None

    def is_anonymous(self) -> bool:
        """Check if current user is anonymous.

        Returns:
            True if anonymous or no context.
        """
        with self._lock:
            if self._context is None:
                return True
            return self._context.anonymous is True or self._context.user_id is None
