"""FlagKit SDK crash-resilient event persistence implementation.

This module implements write-ahead logging (WAL) for event persistence
to prevent analytics data loss during unexpected process termination.
"""

import json
import os
import secrets
import sys
import threading
import time
from dataclasses import dataclass
from typing import Any, Optional

from flagkit.types.config import LoggerProtocol

# File locking abstraction for cross-platform support
if sys.platform == "win32":
    # Windows fallback using msvcrt
    import msvcrt

    def _lock_file(file_handle: Any) -> None:
        """Acquire exclusive lock on Windows."""
        msvcrt.locking(file_handle.fileno(), msvcrt.LK_NBLCK, 1)

    def _unlock_file(file_handle: Any) -> None:
        """Release lock on Windows."""
        file_handle.seek(0)
        msvcrt.locking(file_handle.fileno(), msvcrt.LK_UNLCK, 1)
else:
    # Unix-like systems using fcntl
    import fcntl

    def _lock_file(file_handle: Any) -> None:
        """Acquire exclusive lock on Unix."""
        fcntl.flock(file_handle.fileno(), fcntl.LOCK_EX)

    def _unlock_file(file_handle: Any) -> None:
        """Release lock on Unix."""
        fcntl.flock(file_handle.fileno(), fcntl.LOCK_UN)


@dataclass
class PersistedEvent:
    """Represents a persisted event with its status.

    Attributes:
        id: Unique event identifier.
        type: Event type.
        data: Event data.
        timestamp: Event timestamp in milliseconds.
        status: Event status (pending, sending, sent, failed).
        sent_at: Timestamp when event was sent (if applicable).
    """

    id: str
    type: str
    data: Optional[dict[str, Any]]
    timestamp: int
    status: str = "pending"
    sent_at: Optional[int] = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        result: dict[str, Any] = {
            "id": self.id,
            "type": self.type,
            "data": self.data,
            "timestamp": self.timestamp,
            "status": self.status,
        }
        if self.sent_at is not None:
            result["sentAt"] = self.sent_at
        return result

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "PersistedEvent":
        """Create PersistedEvent from dictionary."""
        return cls(
            id=data["id"],
            type=data["type"],
            data=data.get("data"),
            timestamp=data["timestamp"],
            status=data.get("status", "pending"),
            sent_at=data.get("sentAt"),
        )


@dataclass
class EventPersistenceConfig:
    """Configuration for event persistence.

    Attributes:
        storage_path: Directory for event storage.
        max_events: Maximum number of events to persist.
        flush_interval: Interval between disk writes in milliseconds.
        buffer_size: Number of events to buffer before flushing.
        retention_days: Number of days to retain sent events.
    """

    storage_path: str
    max_events: int = 10000
    flush_interval: int = 1000
    buffer_size: int = 100
    retention_days: int = 7


class EventPersistence:
    """Manages crash-resilient event persistence using write-ahead logging.

    Features:
    - Write-ahead logging to prevent data loss on crash
    - File locking for multi-process safety
    - Batched writes for performance
    - Automatic cleanup of old events
    """

    def __init__(
        self,
        storage_path: str,
        max_events: int = 10000,
        flush_interval: int = 1000,
        logger: Optional[LoggerProtocol] = None,
    ) -> None:
        """Initialize event persistence.

        Args:
            storage_path: Directory for event storage.
            max_events: Maximum number of events to persist.
            flush_interval: Interval between disk writes in milliseconds.
            logger: Optional logger instance.
        """
        self._storage_path = storage_path
        self._max_events = max_events
        self._flush_interval = flush_interval / 1000.0  # Convert to seconds
        self._logger = logger

        self._buffer: list[PersistedEvent] = []
        self._buffer_size = 100
        self._lock = threading.Lock()
        self._flush_timer: Optional[threading.Timer] = None
        self._closed = False

        # Ensure storage directory exists
        self._ensure_storage_dir()

        # Start periodic flush timer
        self._start_flush_timer()

    @property
    def storage_path(self) -> str:
        """Get the storage path."""
        return self._storage_path

    @property
    def lock_file_path(self) -> str:
        """Get the lock file path."""
        return os.path.join(self._storage_path, "flagkit-events.lock")

    def _ensure_storage_dir(self) -> None:
        """Ensure storage directory exists with proper permissions."""
        try:
            os.makedirs(self._storage_path, mode=0o700, exist_ok=True)
        except OSError as e:
            if self._logger:
                self._logger.error("Failed to create storage directory", error=str(e))
            raise

    def _get_current_log_file(self) -> str:
        """Get the current log file path."""
        # Use a single file for simplicity, with timestamp for rotation
        return os.path.join(self._storage_path, "flagkit-events-current.jsonl")

    def _generate_event_id(self) -> str:
        """Generate a unique event ID."""
        return f"evt_{secrets.token_hex(12)}"

    def persist(self, event: PersistedEvent) -> None:
        """Add event to buffer and flush if buffer is full.

        Args:
            event: The event to persist.
        """
        if self._closed:
            return

        with self._lock:
            # Check max events limit
            if len(self._buffer) >= self._max_events:
                if self._logger:
                    self._logger.warn("Max persisted events reached, dropping oldest")
                self._buffer.pop(0)

            self._buffer.append(event)

            # Flush if buffer is full
            if len(self._buffer) >= self._buffer_size:
                self._flush_buffer()

    def persist_raw(
        self,
        event_type: str,
        event_data: Optional[dict[str, Any]] = None,
    ) -> str:
        """Persist a new event and return its ID.

        Args:
            event_type: Type of the event.
            event_data: Event data.

        Returns:
            The generated event ID.
        """
        event_id = self._generate_event_id()
        event = PersistedEvent(
            id=event_id,
            type=event_type,
            data=event_data,
            timestamp=int(time.time() * 1000),
            status="pending",
        )
        self.persist(event)
        return event_id

    def flush(self) -> None:
        """Write buffered events to disk with file locking."""
        with self._lock:
            self._flush_buffer()

    def _flush_buffer(self) -> None:
        """Internal method to flush buffer (must be called with lock held)."""
        if not self._buffer:
            return

        events_to_write = list(self._buffer)
        self._buffer = []

        try:
            self._write_events(events_to_write)
            if self._logger:
                self._logger.debug("Events persisted", count=len(events_to_write))
        except Exception as e:
            # Re-add events to buffer on failure
            self._buffer = events_to_write + self._buffer
            if self._logger:
                self._logger.error("Failed to persist events", error=str(e))

    def _write_events(self, events: list[PersistedEvent]) -> None:
        """Write events to disk with file locking.

        Args:
            events: Events to write.
        """
        if not events:
            return

        log_file = self._get_current_log_file()

        # Create lock file if it doesn't exist
        lock_file = self.lock_file_path
        with open(lock_file, "a") as lf:
            try:
                _lock_file(lf)
                try:
                    with open(log_file, "a") as f:
                        for event in events:
                            f.write(json.dumps(event.to_dict()) + "\n")
                        f.flush()
                        os.fsync(f.fileno())
                finally:
                    _unlock_file(lf)
            except OSError as e:
                if self._logger:
                    self._logger.error("Failed to acquire file lock", error=str(e))
                raise

    def mark_sent(self, event_ids: list[str]) -> None:
        """Mark events as sent.

        Args:
            event_ids: List of event IDs to mark as sent.
        """
        if not event_ids:
            return

        sent_time = int(time.time() * 1000)
        log_file = self._get_current_log_file()
        lock_file = self.lock_file_path

        with open(lock_file, "a") as lf:
            try:
                _lock_file(lf)
                try:
                    with open(log_file, "a") as f:
                        for event_id in event_ids:
                            status_update = {
                                "id": event_id,
                                "status": "sent",
                                "sentAt": sent_time,
                            }
                            f.write(json.dumps(status_update) + "\n")
                        f.flush()
                        os.fsync(f.fileno())
                finally:
                    _unlock_file(lf)
            except OSError as e:
                if self._logger:
                    self._logger.error("Failed to mark events as sent", error=str(e))

    def mark_sending(self, event_ids: list[str]) -> None:
        """Mark events as currently being sent.

        Args:
            event_ids: List of event IDs to mark as sending.
        """
        if not event_ids:
            return

        log_file = self._get_current_log_file()
        lock_file = self.lock_file_path

        with open(lock_file, "a") as lf:
            try:
                _lock_file(lf)
                try:
                    with open(log_file, "a") as f:
                        for event_id in event_ids:
                            status_update = {
                                "id": event_id,
                                "status": "sending",
                            }
                            f.write(json.dumps(status_update) + "\n")
                        f.flush()
                        os.fsync(f.fileno())
                finally:
                    _unlock_file(lf)
            except OSError as e:
                if self._logger:
                    self._logger.error("Failed to mark events as sending", error=str(e))

    def mark_pending(self, event_ids: list[str]) -> None:
        """Mark events as pending (revert from sending on failure).

        Args:
            event_ids: List of event IDs to mark as pending.
        """
        if not event_ids:
            return

        log_file = self._get_current_log_file()
        lock_file = self.lock_file_path

        with open(lock_file, "a") as lf:
            try:
                _lock_file(lf)
                try:
                    with open(log_file, "a") as f:
                        for event_id in event_ids:
                            status_update = {
                                "id": event_id,
                                "status": "pending",
                            }
                            f.write(json.dumps(status_update) + "\n")
                        f.flush()
                        os.fsync(f.fileno())
                finally:
                    _unlock_file(lf)
            except OSError as e:
                if self._logger:
                    self._logger.error("Failed to mark events as pending", error=str(e))

    def recover(self) -> list[PersistedEvent]:
        """Recover pending events on startup.

        Returns:
            List of pending or sending events (sending = crashed mid-send).
        """
        log_file = self._get_current_log_file()
        lock_file = self.lock_file_path

        if not os.path.exists(log_file):
            return []

        events: dict[str, PersistedEvent] = {}

        try:
            # Ensure lock file exists
            with open(lock_file, "a"):
                pass

            with open(lock_file, "r+") as lf:
                try:
                    _lock_file(lf)
                    try:
                        with open(log_file) as f:
                            for line in f:
                                line = line.strip()
                                if not line:
                                    continue
                                try:
                                    data = json.loads(line)
                                    event_id = data.get("id")
                                    if not event_id:
                                        continue

                                    # Check if this is a status update or full event
                                    if "type" in data:
                                        # Full event
                                        events[event_id] = PersistedEvent.from_dict(
                                            data
                                        )
                                    elif "status" in data and event_id in events:
                                        # Status update
                                        events[event_id].status = data["status"]
                                        if "sentAt" in data:
                                            events[event_id].sent_at = data[
                                                "sentAt"
                                            ]
                                except json.JSONDecodeError:
                                    if self._logger:
                                        self._logger.warn(
                                            "Corrupt line in event log, skipping"
                                        )
                                    continue
                    finally:
                        _unlock_file(lf)
                except OSError as e:
                    if self._logger:
                        self._logger.error(
                            "Failed to acquire lock for recovery", error=str(e)
                        )
                    return []

        except OSError as e:
            if self._logger:
                self._logger.error("Failed to recover events", error=str(e))
            return []

        # Filter for pending/sending events (sending = crashed mid-send)
        pending_events = [
            event
            for event in events.values()
            if event.status in ("pending", "sending")
        ]

        if self._logger and pending_events:
            self._logger.info("Recovered pending events", count=len(pending_events))

        return pending_events

    def cleanup(self, retention_days: int = 7) -> int:
        """Remove old sent events and compact the log file.

        Args:
            retention_days: Number of days to retain sent events.

        Returns:
            Number of events removed.
        """
        log_file = self._get_current_log_file()
        lock_file = self.lock_file_path

        if not os.path.exists(log_file):
            return 0

        cutoff_time = int((time.time() - retention_days * 86400) * 1000)
        events_to_keep: list[PersistedEvent] = []
        events: dict[str, PersistedEvent] = {}
        removed_count = 0

        try:
            with open(lock_file, "a") as lf:
                try:
                    _lock_file(lf)
                    try:
                        # Read all events
                        with open(log_file) as f:
                            for line in f:
                                line = line.strip()
                                if not line:
                                    continue
                                try:
                                    data = json.loads(line)
                                    event_id = data.get("id")
                                    if not event_id:
                                        continue

                                    if "type" in data:
                                        events[event_id] = PersistedEvent.from_dict(
                                            data
                                        )
                                    elif "status" in data and event_id in events:
                                        events[event_id].status = data["status"]
                                        if "sentAt" in data:
                                            events[event_id].sent_at = data[
                                                "sentAt"
                                            ]
                                except json.JSONDecodeError:
                                    continue

                        # Filter events to keep
                        for event in events.values():
                            if event.status == "sent" and (
                                event.sent_at is not None
                                and event.sent_at < cutoff_time
                            ):
                                removed_count += 1
                                continue
                            events_to_keep.append(event)

                        # Rewrite the file with kept events
                        with open(log_file, "w") as f:
                            for event in events_to_keep:
                                f.write(json.dumps(event.to_dict()) + "\n")
                            f.flush()
                            os.fsync(f.fileno())

                    finally:
                        _unlock_file(lf)
                except OSError as e:
                    if self._logger:
                        self._logger.error(
                            "Failed to acquire lock for cleanup", error=str(e)
                        )
                    return 0

        except OSError as e:
            if self._logger:
                self._logger.error("Failed to cleanup events", error=str(e))
            return 0

        if self._logger and removed_count > 0:
            self._logger.info("Cleaned up old events", count=removed_count)

        return removed_count

    def get_pending_count(self) -> int:
        """Get count of pending events (including buffer).

        Returns:
            Number of pending events.
        """
        with self._lock:
            buffer_count = len(self._buffer)

        # Count from file
        recovered = self.recover()
        return buffer_count + len(recovered)

    def _start_flush_timer(self) -> None:
        """Start periodic flush timer."""
        if self._flush_timer or self._closed:
            return

        def on_timer() -> None:
            if self._closed:
                return
            try:
                self.flush()
            except Exception:
                pass  # Errors already logged
            finally:
                if not self._closed:
                    self._flush_timer = threading.Timer(
                        self._flush_interval,
                        on_timer,
                    )
                    self._flush_timer.daemon = True
                    self._flush_timer.start()

        self._flush_timer = threading.Timer(
            self._flush_interval,
            on_timer,
        )
        self._flush_timer.daemon = True
        self._flush_timer.start()

    def close(self) -> None:
        """Close the persistence manager and flush remaining events."""
        self._closed = True

        if self._flush_timer:
            self._flush_timer.cancel()
            self._flush_timer = None

        # Final flush
        try:
            self.flush()
        except Exception:
            pass  # Best effort


def create_event_persistence(
    storage_path: Optional[str] = None,
    max_events: int = 10000,
    flush_interval: int = 1000,
    logger: Optional[LoggerProtocol] = None,
) -> EventPersistence:
    """Create an EventPersistence instance.

    Args:
        storage_path: Directory for event storage. Defaults to OS temp dir.
        max_events: Maximum number of events to persist.
        flush_interval: Interval between disk writes in milliseconds.
        logger: Optional logger instance.

    Returns:
        Configured EventPersistence instance.
    """
    import tempfile

    if storage_path is None:
        storage_path = os.path.join(tempfile.gettempdir(), "flagkit", "events")

    return EventPersistence(
        storage_path=storage_path,
        max_events=max_events,
        flush_interval=flush_interval,
        logger=logger,
    )
