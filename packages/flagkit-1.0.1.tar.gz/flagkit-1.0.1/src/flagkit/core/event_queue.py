"""FlagKit SDK event queue implementation."""

import random
import threading
from dataclasses import dataclass
from typing import Any, Optional

from flagkit.core.event_persistence import EventPersistence
from flagkit.http.http_client import HttpClient
from flagkit.types.events import (
    DEFAULT_EVENT_QUEUE_CONFIG,
    BaseEvent,
    EventQueueConfig,
)
from flagkit.utils.logger import Logger
from flagkit.utils.platform import get_current_timestamp
from flagkit.utils.validators import is_valid_event_data, is_valid_event_type


@dataclass
class EventQueueOptions:
    """Event queue options.

    Attributes:
        http_client: HTTP client instance.
        logger: Logger instance.
        session_id: Session identifier.
        environment_id: Environment identifier.
        sdk_version: SDK version.
        config: Event queue configuration.
        persist_events: Whether to persist events to disk for crash recovery.
        event_storage_path: Directory for event storage.
        max_persisted_events: Maximum number of events to persist.
        persistence_flush_interval: Interval between disk writes in milliseconds.
    """

    http_client: HttpClient
    session_id: str
    sdk_version: str
    logger: Optional[Logger] = None
    environment_id: str = ""
    config: Optional[EventQueueConfig] = None
    persist_events: bool = False
    event_storage_path: Optional[str] = None
    max_persisted_events: int = 10000
    persistence_flush_interval: int = 1000


class EventQueue:
    """Manages event batching and delivery.

    Features:
    - Batching (default: 10 events or 30 seconds)
    - Automatic retry on failure
    - Event sampling
    - Thread-safe operations
    - Crash-resilient event persistence (optional)
    """

    def __init__(self, options: EventQueueOptions) -> None:
        self._http_client = options.http_client
        self._logger = options.logger
        self._session_id = options.session_id
        self._sdk_version = options.sdk_version
        self._environment_id = options.environment_id
        self._config = options.config or DEFAULT_EVENT_QUEUE_CONFIG

        self._queue: list[BaseEvent] = []
        self._event_ids: dict[int, str] = {}  # Maps event id() to persisted event ID
        self._lock = threading.Lock()
        self._flush_timer: Optional[threading.Timer] = None
        self._is_flushing = False

        # Initialize persistence if enabled
        self._persistence: Optional[EventPersistence] = None
        if options.persist_events:
            self._persistence = self._create_persistence(options)
            # Recover any pending events from previous session
            self._recover_events()

        # Start flush timer
        self._start_flush_timer()

    def _create_persistence(self, options: EventQueueOptions) -> EventPersistence:
        """Create persistence manager.

        Args:
            options: Event queue options.

        Returns:
            Configured EventPersistence instance.
        """
        import os
        import tempfile

        storage_path = options.event_storage_path
        if storage_path is None:
            storage_path = os.path.join(tempfile.gettempdir(), "flagkit", "events")

        return EventPersistence(
            storage_path=storage_path,
            max_events=options.max_persisted_events,
            flush_interval=options.persistence_flush_interval,
            logger=self._logger,
        )

    def _recover_events(self) -> None:
        """Recover pending events from persistence on startup."""
        if not self._persistence:
            return

        try:
            recovered = self._persistence.recover()
            if recovered:
                # Convert recovered events to BaseEvents and add to queue
                for persisted in recovered:
                    event = BaseEvent(
                        event_type=persisted.type,
                        timestamp=self._timestamp_to_iso(persisted.timestamp),
                        sdk_version=self._sdk_version,
                        sdk_language="python",
                        session_id=self._session_id,
                        environment_id=self._environment_id,
                        event_data=persisted.data,
                    )
                    with self._lock:
                        self._queue.append(event)
                        self._event_ids[id(event)] = persisted.id

                if self._logger:
                    self._logger.info("Recovered events from persistence", count=len(recovered))
        except Exception as e:
            if self._logger:
                self._logger.error("Failed to recover events", error=str(e))

    def _timestamp_to_iso(self, timestamp_ms: int) -> str:
        """Convert millisecond timestamp to ISO 8601 string.

        Args:
            timestamp_ms: Timestamp in milliseconds.

        Returns:
            ISO 8601 formatted string.
        """
        from datetime import datetime, timezone

        dt = datetime.fromtimestamp(timestamp_ms / 1000.0, tz=timezone.utc)
        return dt.isoformat()

    def set_environment_id(self, environment_id: str) -> None:
        """Set environment ID (called after initialization).

        Args:
            environment_id: The environment ID.
        """
        self._environment_id = environment_id

    def track(self, event_type: str, event_data: Optional[dict[str, Any]] = None) -> None:
        """Track a custom event.

        Args:
            event_type: Type of the event.
            event_data: Additional event data.
        """
        # Validate event type
        if not is_valid_event_type(event_type):
            if self._logger:
                self._logger.warn("Invalid event type", event_type=event_type)
            return

        # Validate event data
        if not is_valid_event_data(event_data):
            if self._logger:
                self._logger.warn("Invalid event data", event_type=event_type)
            return

        # Check if event type is enabled
        if not self._is_event_type_enabled(event_type):
            return

        # Apply sampling
        if not self._should_sample():
            return

        # Persist event first if persistence is enabled (crash-safe)
        persisted_id: Optional[str] = None
        if self._persistence:
            try:
                persisted_id = self._persistence.persist_raw(event_type, event_data)
            except Exception as e:
                if self._logger:
                    self._logger.error("Failed to persist event", error=str(e))
                # Continue without persistence

        # Create event
        event = BaseEvent(
            event_type=event_type,
            timestamp=get_current_timestamp(),
            sdk_version=self._sdk_version,
            sdk_language="python",
            session_id=self._session_id,
            environment_id=self._environment_id,
            event_data=event_data,
        )

        # Store the persisted ID if available
        if persisted_id:
            self._event_ids[id(event)] = persisted_id

        # Add to queue
        self._add_to_queue(event)

    def flush(self) -> None:
        """Flush pending events immediately."""
        with self._lock:
            if len(self._queue) == 0 or self._is_flushing:
                return

            self._is_flushing = True
            events = list(self._queue)
            self._queue = []

        # Get persisted IDs for events
        event_persisted_ids = [
            self._event_ids.get(id(e)) for e in events
        ]
        valid_persisted_ids = [eid for eid in event_persisted_ids if eid is not None]

        # Mark events as sending in persistence
        if self._persistence and valid_persisted_ids:
            try:
                self._persistence.mark_sending(valid_persisted_ids)
            except Exception:
                pass  # Best effort

        try:
            self._send_events(events)

            # Mark events as sent in persistence
            if self._persistence and valid_persisted_ids:
                try:
                    self._persistence.mark_sent(valid_persisted_ids)
                except Exception as e:
                    if self._logger:
                        self._logger.error("Failed to mark events as sent", error=str(e))

            # Clean up event IDs
            for event in events:
                self._event_ids.pop(id(event), None)

            if self._logger:
                self._logger.debug("Events flushed", count=len(events))
        except Exception as error:
            # Mark events as pending again in persistence
            if self._persistence and valid_persisted_ids:
                try:
                    self._persistence.mark_pending(valid_persisted_ids)
                except Exception:
                    pass  # Best effort

            # Re-queue failed events (up to max size)
            with self._lock:
                requeue_count = min(
                    len(events),
                    self._config.max_queue_size - len(self._queue),
                )
                requeue = events[:requeue_count]
                self._queue = requeue + self._queue

            if self._logger:
                self._logger.warn(
                    "Failed to flush events",
                    error=str(error),
                    requeued=len(requeue) if "requeue" in dir() else 0,
                )
            raise
        finally:
            with self._lock:
                self._is_flushing = False

    def get_queued_events(self) -> list[BaseEvent]:
        """Get queued events (for debugging).

        Returns:
            Copy of queued events.
        """
        with self._lock:
            return list(self._queue)

    def clear_queue(self) -> None:
        """Clear the event queue."""
        with self._lock:
            self._queue = []
            self._event_ids = {}
            if self._logger:
                self._logger.debug("Event queue cleared")

    def get_queue_size(self) -> int:
        """Get queue size.

        Returns:
            Number of events in queue.
        """
        with self._lock:
            return len(self._queue)

    def stop(self) -> None:
        """Stop the event queue."""
        if self._flush_timer:
            self._flush_timer.cancel()
            self._flush_timer = None

        # Close persistence
        if self._persistence:
            try:
                self._persistence.close()
            except Exception:
                pass  # Best effort

    def _add_to_queue(self, event: BaseEvent) -> None:
        """Add event to queue.

        Args:
            event: The event to add.
        """
        with self._lock:
            # Enforce max queue size
            if len(self._queue) >= self._config.max_queue_size:
                # Drop oldest event
                dropped = self._queue.pop(0)
                self._event_ids.pop(id(dropped), None)
                if self._logger:
                    self._logger.warn("Event queue full, dropping oldest event")

            self._queue.append(event)
            if self._logger:
                self._logger.debug("Event queued", event_type=event.event_type)

            # Check if batch size reached
            should_flush = len(self._queue) >= self._config.batch_size

        # Flush if batch size reached (outside lock)
        if should_flush:
            try:
                self.flush()
            except Exception:
                pass  # Errors already logged in flush()

    def _send_events(self, events: list[BaseEvent]) -> None:
        """Send events to server.

        Args:
            events: Events to send.
        """
        if not events:
            return

        self._http_client.post(
            "/sdk/events/batch",
            body={"events": [e.to_dict() for e in events]},
        )

    def _is_event_type_enabled(self, event_type: str) -> bool:
        """Check if event type is enabled.

        Args:
            event_type: The event type.

        Returns:
            True if enabled.
        """
        # Check disabled list first
        if event_type in self._config.disabled_event_types:
            return False

        # Check enabled list
        if "*" in self._config.enabled_event_types:
            return True
        return event_type in self._config.enabled_event_types

    def _should_sample(self) -> bool:
        """Apply sampling to event.

        Returns:
            True if event should be tracked.
        """
        if self._config.sample_rate >= 1.0:
            return True
        if self._config.sample_rate <= 0.0:
            return False
        return random.random() < self._config.sample_rate

    def _start_flush_timer(self) -> None:
        """Start periodic flush timer."""
        if self._flush_timer:
            return

        def on_timer() -> None:
            try:
                self.flush()
            except Exception:
                pass  # Errors already logged
            finally:
                # Reschedule
                self._flush_timer = threading.Timer(
                    self._config.flush_interval,
                    on_timer,
                )
                self._flush_timer.daemon = True
                self._flush_timer.start()

        self._flush_timer = threading.Timer(
            self._config.flush_interval,
            on_timer,
        )
        self._flush_timer.daemon = True
        self._flush_timer.start()
