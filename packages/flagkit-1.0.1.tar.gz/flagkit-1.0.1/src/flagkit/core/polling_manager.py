"""FlagKit SDK polling manager."""

import random
import threading
from collections.abc import Awaitable
from dataclasses import dataclass
from typing import Callable, Optional, Union

from flagkit.utils.logger import Logger


@dataclass
class PollingConfig:
    """Polling configuration.

    Attributes:
        interval: Polling interval in seconds.
        jitter: Jitter in seconds.
        backoff_multiplier: Backoff multiplier for errors.
        max_interval: Maximum interval in seconds.
    """

    interval: float = 30.0
    jitter: float = 1.0
    backoff_multiplier: float = 2.0
    max_interval: float = 300.0  # 5 minutes


# Default polling configuration
DEFAULT_POLLING_CONFIG = PollingConfig()


class PollingManager:
    """Manages background polling for flag updates.

    Features:
    - Configurable polling interval
    - Jitter to prevent thundering herd
    - Exponential backoff on errors
    - Thread-safe start/stop
    """

    def __init__(
        self,
        on_poll: Callable[[], Union[None, Awaitable[None]]],
        config: Optional[PollingConfig] = None,
        logger: Optional[Logger] = None,
    ) -> None:
        self._on_poll = on_poll
        self._config = config or DEFAULT_POLLING_CONFIG
        self._logger = logger
        self._current_interval = self._config.interval
        self._timer: Optional[threading.Timer] = None
        self._is_running = False
        self._consecutive_errors = 0
        self._lock = threading.Lock()

    def start(self) -> None:
        """Start polling."""
        with self._lock:
            if self._is_running:
                return

            self._is_running = True
            self._schedule_next()
            if self._logger:
                self._logger.debug("Polling started", interval=self._current_interval)

    def stop(self) -> None:
        """Stop polling."""
        with self._lock:
            if not self._is_running:
                return

            self._is_running = False
            if self._timer:
                self._timer.cancel()
                self._timer = None
            if self._logger:
                self._logger.debug("Polling stopped")

    def is_active(self) -> bool:
        """Check if polling is active.

        Returns:
            True if polling is running.
        """
        with self._lock:
            return self._is_running

    def get_current_interval(self) -> float:
        """Get current polling interval.

        Returns:
            Current interval in seconds.
        """
        with self._lock:
            return self._current_interval

    def on_success(self) -> None:
        """Handle successful poll."""
        with self._lock:
            self._consecutive_errors = 0
            self._current_interval = self._config.interval

    def on_error(self) -> None:
        """Handle failed poll."""
        with self._lock:
            self._consecutive_errors += 1
            self._current_interval = min(
                self._current_interval * self._config.backoff_multiplier,
                self._config.max_interval,
            )
            if self._logger:
                self._logger.debug(
                    "Polling backoff",
                    interval=self._current_interval,
                    consecutive_errors=self._consecutive_errors,
                )

    def _get_next_delay(self) -> float:
        """Calculate next poll delay with jitter.

        Returns:
            Delay in seconds.
        """
        jitter = random.random() * self._config.jitter
        return self._current_interval + jitter

    def _schedule_next(self) -> None:
        """Schedule the next poll."""
        if not self._is_running:
            return

        delay = self._get_next_delay()
        self._timer = threading.Timer(delay, self._poll)
        self._timer.daemon = True  # Don't block program exit
        self._timer.start()

    def _poll(self) -> None:
        """Execute poll."""
        with self._lock:
            if not self._is_running:
                return

        try:
            result = self._on_poll()
            # Handle async callbacks
            if hasattr(result, "__await__"):
                import asyncio

                try:
                    loop = asyncio.get_event_loop()
                    if loop.is_running():
                        asyncio.ensure_future(result)  # type: ignore
                    else:
                        loop.run_until_complete(result)  # type: ignore
                except RuntimeError:
                    asyncio.run(result)  # type: ignore
            self.on_success()
        except Exception as error:
            self.on_error()
            if self._logger:
                self._logger.warn("Poll failed", error=str(error))
        finally:
            with self._lock:
                self._schedule_next()

    def poll_now(self) -> None:
        """Force an immediate poll."""
        with self._lock:
            # Cancel scheduled poll
            if self._timer:
                self._timer.cancel()
                self._timer = None

        # Execute poll immediately
        self._poll()

    def reset(self) -> None:
        """Reset the polling manager."""
        with self._lock:
            self._consecutive_errors = 0
            self._current_interval = self._config.interval

            if self._is_running:
                # Restart with reset interval
                if self._timer:
                    self._timer.cancel()
                self._schedule_next()
