"""FlagKit SDK streaming manager for real-time flag updates via SSE."""

import json
import threading
import time
from dataclasses import dataclass
from enum import Enum
from typing import Callable, Optional

import httpx

from flagkit.types.flag import FlagState
from flagkit.utils.logger import Logger


class StreamingState(Enum):
    """Connection states for streaming."""

    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    RECONNECTING = "reconnecting"
    FAILED = "failed"


class StreamErrorCode(Enum):
    """SSE error codes from server.

    Error codes:
    - TOKEN_INVALID: Re-authenticate completely
    - TOKEN_EXPIRED: Refresh token and reconnect
    - SUBSCRIPTION_SUSPENDED: Notify user, fall back to cached values
    - CONNECTION_LIMIT: Implement backoff or close other connections
    - STREAMING_UNAVAILABLE: Fall back to polling
    """

    TOKEN_INVALID = "TOKEN_INVALID"
    TOKEN_EXPIRED = "TOKEN_EXPIRED"
    SUBSCRIPTION_SUSPENDED = "SUBSCRIPTION_SUSPENDED"
    CONNECTION_LIMIT = "CONNECTION_LIMIT"
    STREAMING_UNAVAILABLE = "STREAMING_UNAVAILABLE"


@dataclass
class StreamErrorData:
    """SSE error event data structure."""

    code: str
    message: str

    def to_error_code(self) -> Optional[StreamErrorCode]:
        """Convert string code to StreamErrorCode enum."""
        try:
            return StreamErrorCode(self.code)
        except ValueError:
            return None


@dataclass
class StreamTokenResponse:
    """Response from the stream token endpoint."""

    token: str
    expires_in: int


@dataclass
class StreamingConfig:
    """Streaming configuration.

    Attributes:
        enabled: Whether streaming is enabled.
        reconnect_interval: Reconnection interval in seconds.
        max_reconnect_attempts: Maximum reconnection attempts before fallback.
        heartbeat_interval: Expected heartbeat interval in seconds.
    """

    enabled: bool = True
    reconnect_interval: float = 3.0
    max_reconnect_attempts: int = 3
    heartbeat_interval: float = 30.0


DEFAULT_STREAMING_CONFIG = StreamingConfig()


class StreamingManager:
    """Manages Server-Sent Events (SSE) connection for real-time flag updates.

    Security: Uses token exchange pattern to avoid exposing API keys in URLs.
    1. Fetches short-lived token via POST with API key in header
    2. Connects to SSE endpoint with disposable token in URL

    Features:
    - Secure token-based authentication
    - Automatic token refresh before expiry
    - Automatic reconnection with exponential backoff
    - Graceful degradation to polling after max failures
    - Heartbeat monitoring for connection health
    """

    def __init__(
        self,
        base_url: str,
        get_api_key: Callable[[], str],
        config: Optional[StreamingConfig],
        on_flag_update: Callable[[FlagState], None],
        on_flag_delete: Callable[[str], None],
        on_flags_reset: Callable[[list[FlagState]], None],
        on_fallback_to_polling: Callable[[], None],
        on_subscription_error: Optional[Callable[[str], None]] = None,
        on_connection_limit_error: Optional[Callable[[], None]] = None,
        logger: Optional[Logger] = None,
    ) -> None:
        self._base_url = base_url
        self._get_api_key = get_api_key
        self._config = config or DEFAULT_STREAMING_CONFIG
        self._on_flag_update = on_flag_update
        self._on_flag_delete = on_flag_delete
        self._on_flags_reset = on_flags_reset
        self._on_fallback_to_polling = on_fallback_to_polling
        self._on_subscription_error = on_subscription_error
        self._on_connection_limit_error = on_connection_limit_error
        self._logger = logger

        self._state = StreamingState.DISCONNECTED
        self._consecutive_failures = 0
        self._last_heartbeat = time.time()
        self._stop_event = threading.Event()
        self._connection_thread: Optional[threading.Thread] = None
        self._token_refresh_timer: Optional[threading.Timer] = None
        self._heartbeat_timer: Optional[threading.Timer] = None
        self._retry_timer: Optional[threading.Timer] = None
        self._lock = threading.Lock()
        self._client = httpx.Client(timeout=None)

    @property
    def state(self) -> StreamingState:
        """Get current connection state."""
        with self._lock:
            return self._state

    @property
    def is_connected(self) -> bool:
        """Check if streaming is connected."""
        return self.state == StreamingState.CONNECTED

    def connect(self) -> None:
        """Start streaming connection."""
        with self._lock:
            if self._state in (StreamingState.CONNECTED, StreamingState.CONNECTING):
                return
            self._state = StreamingState.CONNECTING
            self._stop_event.clear()

        self._connection_thread = threading.Thread(
            target=self._initiate_connection, daemon=True
        )
        self._connection_thread.start()

    def disconnect(self) -> None:
        """Stop streaming connection."""
        with self._lock:
            self._cleanup()
            self._state = StreamingState.DISCONNECTED
            self._consecutive_failures = 0

        if self._logger:
            self._logger.debug("Streaming disconnected")

    def retry_connection(self) -> None:
        """Retry streaming connection."""
        with self._lock:
            if self._state in (StreamingState.CONNECTED, StreamingState.CONNECTING):
                return
            self._consecutive_failures = 0

        self.connect()

    def _initiate_connection(self) -> None:
        """Initiate connection by fetching token first."""
        try:
            # Step 1: Fetch short-lived stream token
            token_response = self._fetch_stream_token()

            # Step 2: Schedule token refresh at 80% of TTL
            self._schedule_token_refresh(token_response.expires_in * 0.8)

            # Step 3: Create SSE connection with token
            self._create_connection(token_response.token)
        except Exception as e:
            if self._logger:
                self._logger.error("Failed to fetch stream token", error=str(e))
            self._handle_connection_failure()

    def _fetch_stream_token(self) -> StreamTokenResponse:
        """Fetch a short-lived stream token from the API."""
        token_url = f"{self._base_url}/sdk/stream/token"

        response = self._client.post(
            token_url,
            headers={
                "Content-Type": "application/json",
                "X-API-Key": self._get_api_key(),
            },
            json={},
        )
        response.raise_for_status()

        data = response.json()
        return StreamTokenResponse(
            token=data["token"],
            expires_in=data["expiresIn"],
        )

    def _schedule_token_refresh(self, delay: float) -> None:
        """Schedule token refresh before expiry."""
        with self._lock:
            if self._token_refresh_timer:
                self._token_refresh_timer.cancel()

            self._token_refresh_timer = threading.Timer(
                delay, self._refresh_token
            )
            self._token_refresh_timer.daemon = True
            self._token_refresh_timer.start()

    def _refresh_token(self) -> None:
        """Refresh the stream token."""
        try:
            token_response = self._fetch_stream_token()
            self._schedule_token_refresh(token_response.expires_in * 0.8)
        except Exception as e:
            if self._logger:
                self._logger.warn("Failed to refresh stream token, reconnecting", error=str(e))
            self.disconnect()
            self.connect()

    def _create_connection(self, token: str) -> None:
        """Create SSE connection with token."""
        stream_url = f"{self._base_url}/sdk/stream?token={token}"

        try:
            with self._client.stream(
                "GET",
                stream_url,
                headers={
                    "Accept": "text/event-stream",
                    "Cache-Control": "no-cache",
                },
            ) as response:
                response.raise_for_status()
                self._handle_open()
                self._read_events(response)
        except Exception as e:
            if self._stop_event.is_set():
                return  # Normal stop
            if self._logger:
                self._logger.error("SSE connection error", error=str(e))
            self._handle_connection_failure()

    def _handle_open(self) -> None:
        """Handle successful connection."""
        with self._lock:
            self._state = StreamingState.CONNECTED
            self._consecutive_failures = 0
            self._last_heartbeat = time.time()

        self._start_heartbeat_monitor()

        if self._logger:
            self._logger.info("Streaming connected")

    def _read_events(self, response: httpx.Response) -> None:
        """Read and process SSE events."""
        event_type: Optional[str] = None
        data_buffer: list[str] = []

        for line in response.iter_lines():
            if self._stop_event.is_set():
                return

            line = line.strip()

            # Empty line = end of event
            if not line:
                if event_type and data_buffer:
                    self._process_event(event_type, "".join(data_buffer))
                    event_type = None
                    data_buffer = []
                continue

            # Parse SSE format
            if line.startswith("event:"):
                event_type = line[6:].strip()
            elif line.startswith("data:"):
                data_buffer.append(line[5:].strip())

    def _process_event(self, event_type: str, data: str) -> None:
        """Process a parsed SSE event."""
        try:
            if event_type == "flag_updated":
                flag_data = json.loads(data)
                flag = FlagState(
                    key=flag_data["key"],
                    value=flag_data["value"],
                    enabled=flag_data.get("enabled", True),
                    version=flag_data.get("version", 0),
                    flag_type=flag_data.get("flagType"),
                    last_modified=flag_data.get("lastModified"),
                )
                self._on_flag_update(flag)

            elif event_type == "flag_deleted":
                delete_data = json.loads(data)
                self._on_flag_delete(delete_data["key"])

            elif event_type == "flags_reset":
                flags_data = json.loads(data)
                flags = [
                    FlagState(
                        key=f["key"],
                        value=f["value"],
                        enabled=f.get("enabled", True),
                        version=f.get("version", 0),
                        flag_type=f.get("flagType"),
                        last_modified=f.get("lastModified"),
                    )
                    for f in flags_data
                ]
                self._on_flags_reset(flags)

            elif event_type == "heartbeat":
                with self._lock:
                    self._last_heartbeat = time.time()

            elif event_type == "error":
                self._handle_stream_error(data)

        except Exception as e:
            if self._logger:
                self._logger.warn("Failed to process event", event_type=event_type, error=str(e))

    def _handle_stream_error(self, data: str) -> None:
        """Handle SSE error event from server.

        These are application-level errors sent as SSE events, not connection errors.

        Error codes:
        - TOKEN_INVALID: Re-authenticate completely
        - TOKEN_EXPIRED: Refresh token and reconnect
        - SUBSCRIPTION_SUSPENDED: Notify user, fall back to cached values
        - CONNECTION_LIMIT: Implement backoff or close other connections
        - STREAMING_UNAVAILABLE: Fall back to polling
        """
        try:
            error_data_dict = json.loads(data)
            error_data = StreamErrorData(
                code=error_data_dict.get("code", ""),
                message=error_data_dict.get("message", ""),
            )
            error_code = error_data.to_error_code()

            if self._logger:
                self._logger.warn(
                    "SSE error event received",
                    code=error_data.code,
                    error_message=error_data.message,
                )

            if error_code == StreamErrorCode.TOKEN_EXPIRED:
                # Token expired, refresh and reconnect
                if self._logger:
                    self._logger.info("Stream token expired, refreshing...")
                self._cleanup()
                self.connect()  # Will fetch new token

            elif error_code == StreamErrorCode.TOKEN_INVALID:
                # Token is invalid, need full re-authentication
                if self._logger:
                    self._logger.error("Stream token invalid, re-authenticating...")
                self._cleanup()
                self.connect()  # Will fetch new token

            elif error_code == StreamErrorCode.SUBSCRIPTION_SUSPENDED:
                # Subscription issue - notify and fall back
                if self._logger:
                    self._logger.error("Subscription suspended", error_message=error_data.message)
                if self._on_subscription_error:
                    self._on_subscription_error(error_data.message)
                self._cleanup()
                with self._lock:
                    self._state = StreamingState.FAILED
                self._on_fallback_to_polling()

            elif error_code == StreamErrorCode.CONNECTION_LIMIT:
                # Too many connections - implement backoff
                if self._logger:
                    self._logger.warn("Connection limit reached, backing off...")
                if self._on_connection_limit_error:
                    self._on_connection_limit_error()
                self._handle_connection_failure()

            elif error_code == StreamErrorCode.STREAMING_UNAVAILABLE:
                # Streaming not available - fall back to polling
                if self._logger:
                    self._logger.warn("Streaming service unavailable, falling back to polling")
                self._cleanup()
                with self._lock:
                    self._state = StreamingState.FAILED
                self._on_fallback_to_polling()

            else:
                if self._logger:
                    self._logger.warn("Unknown stream error code", code=error_data.code)
                self._handle_connection_failure()

        except json.JSONDecodeError as e:
            if self._logger:
                self._logger.warn("Failed to parse stream error", error=str(e))
            self._handle_connection_failure()

    def _handle_connection_failure(self) -> None:
        """Handle connection failure."""
        with self._lock:
            self._cleanup()
            self._consecutive_failures += 1
            failures = self._consecutive_failures
            max_attempts = self._config.max_reconnect_attempts

        if failures >= max_attempts:
            with self._lock:
                self._state = StreamingState.FAILED

            if self._logger:
                self._logger.warn("Streaming failed, falling back to polling", failures=failures)
            self._on_fallback_to_polling()
            self._schedule_streaming_retry()
        else:
            with self._lock:
                self._state = StreamingState.RECONNECTING
            self._schedule_reconnect()

    def _schedule_reconnect(self) -> None:
        """Schedule reconnection attempt."""
        delay = self._get_reconnect_delay()
        if self._logger:
            self._logger.debug("Scheduling reconnect", delay=delay, attempt=self._consecutive_failures)

        timer = threading.Timer(delay, self.connect)
        timer.daemon = True
        timer.start()

    def _get_reconnect_delay(self) -> float:
        """Calculate reconnection delay with exponential backoff."""
        base_delay = self._config.reconnect_interval
        backoff = 2 ** (self._consecutive_failures - 1)
        delay = base_delay * backoff
        # Cap at 30 seconds
        return min(delay, 30.0)

    def _schedule_streaming_retry(self) -> None:
        """Schedule retry after fallback to polling."""
        with self._lock:
            if self._retry_timer:
                self._retry_timer.cancel()

            self._retry_timer = threading.Timer(300, self._retry_streaming)  # 5 minutes
            self._retry_timer.daemon = True
            self._retry_timer.start()

    def _retry_streaming(self) -> None:
        """Retry streaming connection."""
        if self._logger:
            self._logger.info("Retrying streaming connection")
        self.retry_connection()

    def _start_heartbeat_monitor(self) -> None:
        """Start heartbeat monitoring."""
        self._stop_heartbeat_monitor()

        check_interval = self._config.heartbeat_interval * 1.5

        with self._lock:
            self._heartbeat_timer = threading.Timer(
                check_interval, self._check_heartbeat
            )
            self._heartbeat_timer.daemon = True
            self._heartbeat_timer.start()

    def _check_heartbeat(self) -> None:
        """Check heartbeat timeout."""
        with self._lock:
            time_since = time.time() - self._last_heartbeat
            threshold = self._config.heartbeat_interval * 2

        if time_since > threshold:
            if self._logger:
                self._logger.warn("Heartbeat timeout, reconnecting", time_since=time_since)
            self._handle_connection_failure()
        else:
            self._start_heartbeat_monitor()

    def _stop_heartbeat_monitor(self) -> None:
        """Stop heartbeat monitoring."""
        with self._lock:
            if self._heartbeat_timer:
                self._heartbeat_timer.cancel()
                self._heartbeat_timer = None

    def _cleanup(self) -> None:
        """Cleanup resources."""
        self._stop_event.set()

        if self._token_refresh_timer:
            self._token_refresh_timer.cancel()
            self._token_refresh_timer = None

        if self._heartbeat_timer:
            self._heartbeat_timer.cancel()
            self._heartbeat_timer = None

        if self._retry_timer:
            self._retry_timer.cancel()
            self._retry_timer = None

    def close(self) -> None:
        """Close the streaming manager."""
        self.disconnect()
        self._client.close()
