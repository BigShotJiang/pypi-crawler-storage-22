"""FlagKit SDK error types."""

from flagkit.errors.error_codes import (
    RETRYABLE_ERROR_CODES,
    ErrorCategory,
    ErrorCode,
    ErrorCodes,
    is_retryable_code,
)
from flagkit.errors.flagkit_error import (
    AuthenticationError,
    EvaluationError,
    FlagKitError,
    InitializationError,
    NetworkError,
    SecurityError,
    configure_error_sanitization,
    create_error_from_response,
    get_sanitization_config,
    is_flagkit_error,
    is_retryable_error,
)
from flagkit.errors.sanitizer import (
    SANITIZATION_PATTERNS,
    get_sanitization_patterns,
    sanitize_error_message,
)

__all__ = [
    # Error codes
    "ErrorCategory",
    "ErrorCodes",
    "ErrorCode",
    "RETRYABLE_ERROR_CODES",
    "is_retryable_code",
    # Error classes
    "FlagKitError",
    "InitializationError",
    "AuthenticationError",
    "NetworkError",
    "EvaluationError",
    "SecurityError",
    "create_error_from_response",
    "is_flagkit_error",
    "is_retryable_error",
    # Sanitization
    "configure_error_sanitization",
    "get_sanitization_config",
    "sanitize_error_message",
    "get_sanitization_patterns",
    "SANITIZATION_PATTERNS",
]
