"""FlagKit SDK error classes."""

from datetime import datetime
from typing import Any, Optional

from flagkit.errors.error_codes import ErrorCode, ErrorCodes, is_retryable_code
from flagkit.errors.sanitizer import sanitize_error_message
from flagkit.types.config import ErrorSanitizationConfig

# Module-level sanitization configuration
# This can be set via configure_error_sanitization()
_sanitization_config: Optional[ErrorSanitizationConfig] = ErrorSanitizationConfig()


def configure_error_sanitization(config: Optional[ErrorSanitizationConfig]) -> None:
    """Configure error message sanitization globally.

    Args:
        config: The sanitization configuration to use, or None to disable.
    """
    global _sanitization_config
    _sanitization_config = config


def get_sanitization_config() -> Optional[ErrorSanitizationConfig]:
    """Get the current sanitization configuration.

    Returns:
        The current sanitization configuration, or None if not set.
    """
    return _sanitization_config


class FlagKitError(Exception):
    """Base error class for all FlagKit SDK errors.

    Attributes:
        code: Error code string (e.g., "NETWORK_TIMEOUT").
        numeric_code: Numeric error code (e.g., 1301).
        status_code: HTTP status code if applicable.
        details: Additional error details.
        recoverable: Whether the operation can be retried.
        retry_after: Seconds to wait before retrying.
        request_id: Server request ID for debugging.
        timestamp: Timestamp when error occurred.
        original_message: Original unsanitized message (only if preserve_original is True).
    """

    def __init__(
        self,
        code: ErrorCode,
        message: Optional[str] = None,
        *,
        status_code: Optional[int] = None,
        details: Optional[dict[str, Any]] = None,
        retry_after: Optional[int] = None,
        request_id: Optional[str] = None,
        cause: Optional[Exception] = None,
    ) -> None:
        error_def = ErrorCodes[code]
        raw_message = message or error_def.message

        # Apply sanitization if configured
        config = _sanitization_config
        sanitized_message = sanitize_error_message(raw_message, config)
        super().__init__(sanitized_message)

        # Store original message if preserve_original is enabled
        self.original_message: Optional[str] = None
        if config is not None and config.preserve_original and raw_message != sanitized_message:
            self.original_message = raw_message

        self.code: ErrorCode = code
        self.numeric_code: int = error_def.numeric_code
        self.recoverable: bool = is_retryable_code(code)
        self.status_code: Optional[int] = status_code
        self.details: Optional[dict[str, Any]] = details
        self.retry_after: Optional[int] = retry_after
        self.request_id: Optional[str] = request_id
        self.timestamp: datetime = datetime.now()
        self.__cause__ = cause

    def __str__(self) -> str:
        return f"[{self.code}] {self.args[0]}"

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}("
            f"code={self.code!r}, "
            f"message={self.args[0]!r}, "
            f"status_code={self.status_code!r})"
        )

    def to_dict(self) -> dict[str, Any]:
        """Convert error to dictionary for logging/serialization."""
        return {
            "name": self.__class__.__name__,
            "code": self.code,
            "numeric_code": self.numeric_code,
            "message": str(self.args[0]),
            "status_code": self.status_code,
            "details": self.details,
            "recoverable": self.recoverable,
            "retry_after": self.retry_after,
            "request_id": self.request_id,
            "timestamp": self.timestamp.isoformat(),
        }


class InitializationError(FlagKitError):
    """Initialization error - SDK cannot start."""

    def __init__(
        self,
        code: ErrorCode,
        message: Optional[str] = None,
        *,
        details: Optional[dict[str, Any]] = None,
        cause: Optional[Exception] = None,
    ) -> None:
        super().__init__(code, message, details=details, cause=cause)


class AuthenticationError(FlagKitError):
    """Authentication error - API key issues."""

    def __init__(
        self,
        code: ErrorCode,
        message: Optional[str] = None,
        *,
        status_code: Optional[int] = None,
        details: Optional[dict[str, Any]] = None,
        retry_after: Optional[int] = None,
        request_id: Optional[str] = None,
    ) -> None:
        super().__init__(
            code,
            message,
            status_code=status_code,
            details=details,
            retry_after=retry_after,
            request_id=request_id,
        )


class NetworkError(FlagKitError):
    """Network error - connectivity issues."""

    def __init__(
        self,
        code: ErrorCode,
        message: Optional[str] = None,
        *,
        status_code: Optional[int] = None,
        details: Optional[dict[str, Any]] = None,
        retry_after: Optional[int] = None,
        request_id: Optional[str] = None,
        cause: Optional[Exception] = None,
    ) -> None:
        super().__init__(
            code,
            message,
            status_code=status_code,
            details=details,
            retry_after=retry_after,
            request_id=request_id,
            cause=cause,
        )


class EvaluationError(FlagKitError):
    """Evaluation error - flag evaluation issues."""

    def __init__(
        self,
        code: ErrorCode,
        message: Optional[str] = None,
        *,
        details: Optional[dict[str, Any]] = None,
    ) -> None:
        super().__init__(code, message, details=details)


class SecurityError(FlagKitError):
    """Security error - security policy violations."""

    def __init__(
        self,
        code: ErrorCode,
        message: Optional[str] = None,
        *,
        details: Optional[dict[str, Any]] = None,
    ) -> None:
        super().__init__(code, message, details=details)


def create_error_from_response(
    status_code: int,
    body: Optional[dict[str, Any]] = None,
    retry_after: Optional[int] = None,
) -> FlagKitError:
    """Create an error from an HTTP response.

    Args:
        status_code: HTTP status code.
        body: Response body with error details.
        retry_after: Retry-After header value in seconds.

    Returns:
        Appropriate FlagKitError subclass.
    """
    body = body or {}
    request_id = body.get("requestId")
    message = body.get("message") or body.get("error")

    if status_code == 400:
        return FlagKitError(
            "EVAL_INVALID_CONTEXT",
            message,
            status_code=status_code,
            request_id=request_id,
        )
    elif status_code == 401:
        return AuthenticationError(
            "AUTH_INVALID_KEY",
            message,
            status_code=status_code,
            request_id=request_id,
        )
    elif status_code == 403:
        return AuthenticationError(
            "AUTH_INSUFFICIENT_PERMISSIONS",
            message,
            status_code=status_code,
            request_id=request_id,
        )
    elif status_code == 404:
        return EvaluationError("EVAL_FLAG_NOT_FOUND", message)
    elif status_code == 429:
        return AuthenticationError(
            "AUTH_RATE_LIMITED",
            message,
            status_code=status_code,
            retry_after=retry_after,
            request_id=request_id,
        )
    elif status_code >= 500:
        return NetworkError(
            "NETWORK_SERVER_ERROR",
            message,
            status_code=status_code,
            retry_after=retry_after,
            request_id=request_id,
        )
    else:
        return FlagKitError(
            "UNKNOWN_ERROR",
            message,
            status_code=status_code,
            request_id=request_id,
        )


def is_flagkit_error(error: Any) -> bool:
    """Check if an error is a FlagKitError.

    Args:
        error: The error to check.

    Returns:
        True if the error is a FlagKitError.
    """
    return isinstance(error, FlagKitError)


def is_retryable_error(error: Any) -> bool:
    """Check if an error is retryable.

    Args:
        error: The error to check.

    Returns:
        True if the error is retryable.
    """
    if isinstance(error, FlagKitError):
        return error.recoverable
    return False
