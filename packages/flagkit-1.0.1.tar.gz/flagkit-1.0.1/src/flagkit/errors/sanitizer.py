"""Error message sanitization utilities.

This module provides utilities to remove sensitive information from error
messages to prevent information leakage in logs and error reporting.
"""

import re
from typing import Optional

from flagkit.types.config import ErrorSanitizationConfig

# Patterns for sanitizing sensitive information from error messages
# Each tuple contains (pattern, replacement)
SANITIZATION_PATTERNS: list[tuple[str, str]] = [
    # Unix-style file paths (e.g., /home/user/app/config.json)
    (r'/(?:[\w.-]+/)+[\w.-]+', '[PATH]'),
    # Windows-style file paths (e.g., C:\Users\user\app\config.json)
    (r'[A-Za-z]:\\(?:[\w\s.-]+\\)+[\w.-]*', '[PATH]'),
    # IPv4 addresses
    (r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b', '[IP]'),
    # SDK API keys (sdk_ prefix with 8+ chars)
    (r'sdk_[a-zA-Z0-9_-]{8,}', 'sdk_[REDACTED]'),
    # Server API keys (srv_ prefix with 8+ chars)
    (r'srv_[a-zA-Z0-9_-]{8,}', 'srv_[REDACTED]'),
    # CLI API keys (cli_ prefix with 8+ chars)
    (r'cli_[a-zA-Z0-9_-]{8,}', 'cli_[REDACTED]'),
    # Email addresses
    (r'[\w.+-]+@[\w.-]+\.\w+', '[EMAIL]'),
    # Database connection strings
    (r'(?:postgres|mysql|mongodb|redis)://[^\s]+', '[CONNECTION_STRING]'),
]

# Pre-compiled regex patterns for performance
_COMPILED_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    (re.compile(pattern), replacement)
    for pattern, replacement in SANITIZATION_PATTERNS
]


def sanitize_error_message(
    message: str,
    config: Optional[ErrorSanitizationConfig] = None,
) -> str:
    """Sanitize an error message by removing sensitive information.

    This function applies a series of regex patterns to replace sensitive
    data like file paths, IP addresses, API keys, emails, and connection
    strings with placeholder values.

    Args:
        message: The error message to sanitize.
        config: Optional sanitization configuration. If None or disabled,
            returns the original message unchanged.

    Returns:
        The sanitized message with sensitive information replaced by
        placeholders, or the original message if sanitization is disabled.

    Examples:
        >>> sanitize_error_message("Failed at /home/user/app/file.py")
        'Failed at [PATH]'

        >>> sanitize_error_message("Key sdk_abc123456789 is invalid")
        'Key sdk_[REDACTED] is invalid'

        >>> config = ErrorSanitizationConfig(enabled=False)
        >>> sanitize_error_message("Secret: sdk_abc123456789", config)
        'Secret: sdk_abc123456789'
    """
    # Handle edge cases
    if message is None:
        return ""

    if not isinstance(message, str):
        message = str(message)

    if not message:
        return message

    # Check if sanitization is enabled
    if config is None or not config.enabled:
        return message

    # Apply all sanitization patterns
    result = message
    for pattern, replacement in _COMPILED_PATTERNS:
        result = pattern.sub(replacement, result)

    return result


def get_sanitization_patterns() -> list[tuple[str, str]]:
    """Get the list of sanitization patterns.

    Returns:
        A list of tuples containing (pattern, replacement) pairs.
    """
    return SANITIZATION_PATTERNS.copy()
