"""FlagKit SDK HTTP layer."""

from flagkit.http.circuit_breaker import (
    DEFAULT_CIRCUIT_BREAKER_CONFIG,
    CircuitBreaker,
    CircuitBreakerConfig,
    CircuitOpenError,
    CircuitState,
)
from flagkit.http.http_client import (
    SDK_VERSION,
    HttpClient,
    HttpClientConfig,
    HttpResponse,
    RequestOptions,
)
from flagkit.http.retry import (
    DEFAULT_RETRY_CONFIG,
    RetryConfig,
    calculate_backoff,
    parse_retry_after,
    with_retry,
)

__all__ = [
    # Retry
    "RetryConfig",
    "DEFAULT_RETRY_CONFIG",
    "calculate_backoff",
    "with_retry",
    "parse_retry_after",
    # Circuit breaker
    "CircuitState",
    "CircuitBreakerConfig",
    "DEFAULT_CIRCUIT_BREAKER_CONFIG",
    "CircuitOpenError",
    "CircuitBreaker",
    # HTTP client
    "SDK_VERSION",
    "RequestOptions",
    "HttpResponse",
    "HttpClientConfig",
    "HttpClient",
]
