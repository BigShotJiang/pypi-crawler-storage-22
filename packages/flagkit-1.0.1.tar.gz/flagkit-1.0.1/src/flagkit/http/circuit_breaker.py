"""FlagKit SDK circuit breaker implementation."""

import threading
import time
from dataclasses import dataclass
from enum import Enum
from typing import Callable, Optional, TypeVar

from flagkit.utils.logger import Logger

T = TypeVar("T")


class CircuitState(Enum):
    """Circuit breaker states."""

    CLOSED = "CLOSED"  # Normal operation - requests are allowed
    OPEN = "OPEN"  # Circuit is open - requests are rejected
    HALF_OPEN = "HALF_OPEN"  # Testing recovery - limited requests allowed


@dataclass
class CircuitBreakerConfig:
    """Circuit breaker configuration.

    Attributes:
        failure_threshold: Number of failures before opening circuit.
        reset_timeout: Time in seconds before attempting recovery.
        success_threshold: Successful requests in half-open to close circuit.
    """

    failure_threshold: int = 5
    reset_timeout: float = 30.0
    success_threshold: int = 1


# Default circuit breaker configuration
DEFAULT_CIRCUIT_BREAKER_CONFIG = CircuitBreakerConfig()


class CircuitOpenError(Exception):
    """Error thrown when circuit is open."""

    def __init__(self, time_until_reset: float) -> None:
        super().__init__(f"Circuit breaker is open. Reset in {time_until_reset:.1f}s")
        self.time_until_reset = time_until_reset


class CircuitBreaker:
    """Circuit breaker for protecting against cascading failures.

    State transitions:
    - CLOSED -> OPEN: When failures >= failure_threshold
    - OPEN -> HALF_OPEN: After reset_timeout
    - HALF_OPEN -> CLOSED: After success_threshold successes
    - HALF_OPEN -> OPEN: On any failure
    """

    def __init__(
        self,
        config: Optional[CircuitBreakerConfig] = None,
        logger: Optional[Logger] = None,
    ) -> None:
        self._config = config or DEFAULT_CIRCUIT_BREAKER_CONFIG
        self._logger = logger
        self._state = CircuitState.CLOSED
        self._failures = 0
        self._successes = 0
        self._last_failure_time = 0.0
        self._lock = threading.Lock()

    def get_state(self) -> CircuitState:
        """Get current circuit state."""
        with self._lock:
            self._check_state_transition()
            return self._state

    def execute(self, operation: Callable[[], T]) -> T:
        """Execute an operation through the circuit breaker.

        Args:
            operation: The operation to execute.

        Returns:
            The result of the operation.

        Raises:
            CircuitOpenError: If circuit is open.
            Exception: Any exception from the operation.
        """
        with self._lock:
            self._check_state_transition()

            if self._state == CircuitState.OPEN:
                time_until_reset = max(
                    0.0,
                    self._config.reset_timeout - (time.time() - self._last_failure_time),
                )
                raise CircuitOpenError(time_until_reset)

        try:
            result = operation()
            self._on_success()
            return result
        except Exception as error:
            self._on_failure()
            raise error

    def on_success(self) -> None:
        """Record a success (thread-safe wrapper)."""
        self._on_success()

    def on_failure(self) -> None:
        """Record a failure (thread-safe wrapper)."""
        self._on_failure()

    def _on_success(self) -> None:
        """Record a success."""
        with self._lock:
            if self._state == CircuitState.HALF_OPEN:
                self._successes += 1
                if self._successes >= self._config.success_threshold:
                    self._transition_to(CircuitState.CLOSED)
                    self._reset_counters()
            elif self._state == CircuitState.CLOSED:
                # Reset failure count on success in closed state
                self._failures = 0

    def _on_failure(self) -> None:
        """Record a failure."""
        with self._lock:
            self._failures += 1
            self._last_failure_time = time.time()

            if self._state == CircuitState.HALF_OPEN:
                # Any failure in half-open state opens the circuit
                self._transition_to(CircuitState.OPEN)
                self._successes = 0
            elif (
                self._state == CircuitState.CLOSED
                and self._failures >= self._config.failure_threshold
            ):
                self._transition_to(CircuitState.OPEN)

    def reset(self) -> None:
        """Manually reset the circuit breaker."""
        with self._lock:
            self._state = CircuitState.CLOSED
            self._reset_counters()
            if self._logger:
                self._logger.debug("Circuit breaker reset")

    def _reset_counters(self) -> None:
        """Reset internal counters."""
        self._failures = 0
        self._successes = 0
        self._last_failure_time = 0.0

    def _check_state_transition(self) -> None:
        """Check if state should transition from OPEN to HALF_OPEN."""
        if self._state == CircuitState.OPEN:
            time_since_last_failure = time.time() - self._last_failure_time
            if time_since_last_failure >= self._config.reset_timeout:
                self._transition_to(CircuitState.HALF_OPEN)
                self._successes = 0

    def _transition_to(self, new_state: CircuitState) -> None:
        """Transition to a new state."""
        previous_state = self._state
        self._state = new_state

        if self._logger:
            self._logger.debug(
                f"Circuit breaker state: {previous_state.value} -> {new_state.value}",
                failures=self._failures,
                successes=self._successes,
            )

    def get_stats(self) -> dict[str, object]:
        """Get circuit breaker statistics.

        Returns:
            Dictionary with state, failures, successes, and last_failure_time.
        """
        with self._lock:
            return {
                "state": self._state.value,
                "failures": self._failures,
                "successes": self._successes,
                "last_failure_time": self._last_failure_time,
            }
