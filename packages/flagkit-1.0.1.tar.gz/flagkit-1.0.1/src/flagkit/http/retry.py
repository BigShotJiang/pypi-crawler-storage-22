"""FlagKit SDK retry logic with exponential backoff."""

import asyncio
import random
import time
from collections.abc import Awaitable
from dataclasses import dataclass
from datetime import datetime
from typing import Callable, Optional, TypeVar

from flagkit.errors.flagkit_error import is_retryable_error
from flagkit.utils.logger import Logger

T = TypeVar("T")


@dataclass
class RetryConfig:
    """Retry configuration.

    Attributes:
        max_attempts: Maximum number of retry attempts.
        base_delay: Base delay in seconds.
        max_delay: Maximum delay in seconds.
        backoff_multiplier: Backoff multiplier.
        jitter: Maximum jitter in seconds.
    """

    max_attempts: int = 3
    base_delay: float = 1.0
    max_delay: float = 30.0
    backoff_multiplier: float = 2.0
    jitter: float = 0.1


# Default retry configuration
DEFAULT_RETRY_CONFIG = RetryConfig()


def calculate_backoff(attempt: int, config: RetryConfig) -> float:
    """Calculate backoff delay with exponential backoff and jitter.

    Args:
        attempt: Current attempt number (1-indexed).
        config: Retry configuration.

    Returns:
        Delay in seconds.
    """
    # Exponential backoff: base_delay * (multiplier ^ (attempt - 1))
    exponential_delay = config.base_delay * (config.backoff_multiplier ** (attempt - 1))

    # Cap at max_delay
    capped_delay = min(exponential_delay, config.max_delay)

    # Add jitter to prevent thundering herd
    jitter = random.random() * config.jitter

    return capped_delay + jitter


def with_retry(
    operation: Callable[[], T],
    config: Optional[RetryConfig] = None,
    logger: Optional[Logger] = None,
    operation_name: str = "operation",
    should_retry: Optional[Callable[[Exception], bool]] = None,
    on_retry: Optional[Callable[[int, Exception, float], None]] = None,
) -> T:
    """Execute an operation with retry logic (synchronous).

    Args:
        operation: The operation to execute.
        config: Retry configuration.
        logger: Logger instance.
        operation_name: Name of the operation for logging.
        should_retry: Custom function to determine if error is retryable.
        on_retry: Callback when a retry occurs.

    Returns:
        The result of the operation.

    Raises:
        Exception: The last error if all retries fail.
    """
    resolved_config = config or DEFAULT_RETRY_CONFIG
    last_error: Optional[Exception] = None

    for attempt in range(1, resolved_config.max_attempts + 1):
        try:
            return operation()
        except Exception as error:
            last_error = error

            # Check if we should retry
            can_retry = should_retry(error) if should_retry else is_retryable_error(error)

            if not can_retry:
                if logger:
                    logger.debug(
                        f"{operation_name} failed with non-retryable error",
                        error=str(error),
                        attempt=attempt,
                    )
                raise

            # Check if we've exhausted retries
            if attempt >= resolved_config.max_attempts:
                if logger:
                    logger.warn(
                        f"{operation_name} failed after {attempt} attempts",
                        error=str(error),
                    )
                raise

            # Calculate and apply backoff
            delay = calculate_backoff(attempt, resolved_config)

            if logger:
                logger.debug(
                    f"{operation_name} failed, retrying in {delay:.2f}s",
                    attempt=attempt,
                    max_attempts=resolved_config.max_attempts,
                    error=str(error),
                    delay=delay,
                )

            # Call on_retry callback if provided
            if on_retry:
                on_retry(attempt, error, delay)

            # Wait before retrying
            time.sleep(delay)

    # Should never reach here, but TypeScript-style safety
    if last_error:
        raise last_error
    raise RuntimeError("Retry failed unexpectedly")


async def with_retry_async(
    operation: Callable[[], Awaitable[T]],
    config: Optional[RetryConfig] = None,
    logger: Optional[Logger] = None,
    operation_name: str = "operation",
    should_retry: Optional[Callable[[Exception], bool]] = None,
    on_retry: Optional[Callable[[int, Exception, float], None]] = None,
) -> T:
    """Execute an operation with retry logic (asynchronous).

    Args:
        operation: The async operation to execute.
        config: Retry configuration.
        logger: Logger instance.
        operation_name: Name of the operation for logging.
        should_retry: Custom function to determine if error is retryable.
        on_retry: Callback when a retry occurs.

    Returns:
        The result of the operation.

    Raises:
        Exception: The last error if all retries fail.
    """
    resolved_config = config or DEFAULT_RETRY_CONFIG
    last_error: Optional[Exception] = None

    for attempt in range(1, resolved_config.max_attempts + 1):
        try:
            return await operation()
        except Exception as error:
            last_error = error

            # Check if we should retry
            can_retry = should_retry(error) if should_retry else is_retryable_error(error)

            if not can_retry:
                if logger:
                    logger.debug(
                        f"{operation_name} failed with non-retryable error",
                        error=str(error),
                        attempt=attempt,
                    )
                raise

            # Check if we've exhausted retries
            if attempt >= resolved_config.max_attempts:
                if logger:
                    logger.warn(
                        f"{operation_name} failed after {attempt} attempts",
                        error=str(error),
                    )
                raise

            # Calculate and apply backoff
            delay = calculate_backoff(attempt, resolved_config)

            if logger:
                logger.debug(
                    f"{operation_name} failed, retrying in {delay:.2f}s",
                    attempt=attempt,
                    max_attempts=resolved_config.max_attempts,
                    error=str(error),
                    delay=delay,
                )

            # Call on_retry callback if provided
            if on_retry:
                on_retry(attempt, error, delay)

            # Wait before retrying
            await asyncio.sleep(delay)

    # Should never reach here, but TypeScript-style safety
    if last_error:
        raise last_error
    raise RuntimeError("Retry failed unexpectedly")


def parse_retry_after(value: Optional[str]) -> Optional[int]:
    """Parse Retry-After header value.

    Can be either a number of seconds or an HTTP date.

    Args:
        value: The Retry-After header value.

    Returns:
        Number of seconds to wait, or None.
    """
    if not value:
        return None

    # Try parsing as number of seconds
    try:
        seconds = int(value)
        if seconds > 0:
            return seconds
    except ValueError:
        pass

    # Try parsing as HTTP date
    try:
        from email.utils import parsedate_to_datetime

        date = parsedate_to_datetime(value)
        now = datetime.now(date.tzinfo)
        diff = (date - now).total_seconds()
        if diff > 0:
            return int(diff) + 1
    except (ValueError, TypeError):
        pass

    return None
