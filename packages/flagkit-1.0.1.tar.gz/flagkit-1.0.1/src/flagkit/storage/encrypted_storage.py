"""FlagKit SDK encrypted storage wrapper using AES-256-GCM.

Wraps another storage implementation and encrypts/decrypts data automatically.
Uses cryptography library for encryption operations.
"""

import base64
import hashlib
import json
import secrets
from dataclasses import dataclass
from typing import Any, Optional, Protocol

# Constants
ENCRYPTION_VERSION = 1
IV_LENGTH = 12  # 96 bits for GCM
TAG_LENGTH = 16  # 128 bits for GCM
SALT = b"FlagKit-v1-cache"  # Static salt for key derivation
PBKDF2_ITERATIONS = 100000


class Storage(Protocol):
    """Storage protocol."""

    def get(self, key: str) -> Optional[str]:
        ...

    def set(self, key: str, value: str) -> None:
        ...

    def delete(self, key: str) -> bool:
        ...

    def clear(self) -> None:
        ...


class Logger(Protocol):
    """Logger protocol."""

    def debug(self, message: str, **kwargs: Any) -> None:
        ...

    def info(self, message: str, **kwargs: Any) -> None:
        ...

    def warn(self, message: str, **kwargs: Any) -> None:
        ...

    def error(self, message: str, **kwargs: Any) -> None:
        ...


@dataclass
class EncryptedData:
    """Encrypted data format stored in underlying storage."""

    iv: str  # Base64-encoded initialization vector
    data: str  # Base64-encoded encrypted data
    tag: str  # Base64-encoded authentication tag (for GCM)
    version: int  # Version of encryption format


class EncryptedStorage:
    """Encrypted storage wrapper.

    Provides transparent encryption for cached data using AES-256-GCM.
    Falls back to unencrypted storage if encryption is unavailable.

    Uses PBKDF2 to derive an encryption key from the API key.
    """

    def __init__(
        self,
        storage: Storage,
        api_key: str,
        logger: Optional[Logger] = None,
    ) -> None:
        """Initialize encrypted storage.

        Args:
            storage: The underlying storage to wrap.
            api_key: API key used to derive encryption key.
            logger: Optional logger for debugging.
        """
        self._storage = storage
        self._api_key = api_key
        self._logger = logger
        self._derived_key: Optional[bytes] = None
        self._crypto_available: Optional[bool] = None

        # Derive key immediately
        self._derive_key()

    def _is_crypto_available(self) -> bool:
        """Check if cryptography library is available."""
        if self._crypto_available is not None:
            return self._crypto_available

        try:
            from cryptography.hazmat.primitives.ciphers.aead import AESGCM  # noqa: F401

            self._crypto_available = True
        except ImportError:
            self._crypto_available = False
            if self._logger:
                self._logger.warn(
                    "cryptography library not available, storage will be unencrypted"
                )

        return self._crypto_available

    def _derive_key(self) -> None:
        """Derive encryption key from API key using PBKDF2."""
        if not self._is_crypto_available():
            return

        try:
            self._derived_key = hashlib.pbkdf2_hmac(
                "sha256",
                self._api_key.encode("utf-8"),
                SALT,
                iterations=PBKDF2_ITERATIONS,
                dklen=32,  # 256 bits for AES-256
            )
            if self._logger:
                self._logger.debug("Encryption key derived successfully")
        except Exception as e:
            if self._logger:
                self._logger.warn(f"Failed to derive encryption key: {e}")
            self._derived_key = None

    def _encrypt(self, plaintext: str) -> Optional[str]:
        """Encrypt data using AES-256-GCM.

        Args:
            plaintext: The data to encrypt.

        Returns:
            JSON string of encrypted data, or None if encryption fails.
        """
        if not self._derived_key:
            return None

        try:
            from cryptography.hazmat.primitives.ciphers.aead import AESGCM

            # Generate random IV
            iv = secrets.token_bytes(IV_LENGTH)

            # Create cipher and encrypt
            aesgcm = AESGCM(self._derived_key)
            ciphertext = aesgcm.encrypt(iv, plaintext.encode("utf-8"), None)

            # GCM appends the tag to the ciphertext
            # Split ciphertext and tag
            data = ciphertext[:-TAG_LENGTH]
            tag = ciphertext[-TAG_LENGTH:]

            encrypted_data = EncryptedData(
                iv=base64.b64encode(iv).decode("utf-8"),
                data=base64.b64encode(data).decode("utf-8"),
                tag=base64.b64encode(tag).decode("utf-8"),
                version=ENCRYPTION_VERSION,
            )

            return json.dumps({
                "iv": encrypted_data.iv,
                "data": encrypted_data.data,
                "tag": encrypted_data.tag,
                "version": encrypted_data.version,
            })
        except Exception as e:
            if self._logger:
                self._logger.warn(f"Encryption failed: {e}")
            return None

    def _decrypt(self, encrypted: str) -> Optional[str]:
        """Decrypt data using AES-256-GCM.

        Args:
            encrypted: JSON string of encrypted data.

        Returns:
            Decrypted plaintext, or None if decryption fails.
        """
        if not self._derived_key:
            return None

        try:
            from cryptography.hazmat.primitives.ciphers.aead import AESGCM

            # Parse encrypted data
            parsed = json.loads(encrypted)
            encrypted_data = EncryptedData(
                iv=parsed["iv"],
                data=parsed["data"],
                tag=parsed["tag"],
                version=parsed["version"],
            )

            # Check version
            if encrypted_data.version != ENCRYPTION_VERSION:
                if self._logger:
                    self._logger.warn(
                        f"Unsupported encryption version: {encrypted_data.version}"
                    )
                return None

            # Decode base64 values
            iv = base64.b64decode(encrypted_data.iv)
            data = base64.b64decode(encrypted_data.data)
            tag = base64.b64decode(encrypted_data.tag)

            # Reconstruct ciphertext with tag appended
            ciphertext = data + tag

            # Create cipher and decrypt
            aesgcm = AESGCM(self._derived_key)
            plaintext = aesgcm.decrypt(iv, ciphertext, None)

            return plaintext.decode("utf-8")
        except json.JSONDecodeError:
            if self._logger:
                self._logger.warn("Failed to parse encrypted data JSON")
            return None
        except KeyError as e:
            if self._logger:
                self._logger.warn(f"Missing field in encrypted data: {e}")
            return None
        except Exception as e:
            if self._logger:
                self._logger.warn(f"Decryption failed: {e}")
            return None

    def _is_encrypted_format(self, data: str) -> bool:
        """Check if data looks like a complete encrypted format.

        Args:
            data: String to check.

        Returns:
            True if data appears to be properly encrypted with all required fields.
        """
        try:
            parsed = json.loads(data)
            # Must have all required encryption fields
            return (
                isinstance(parsed, dict)
                and "iv" in parsed
                and "data" in parsed
                and "tag" in parsed
                and "version" in parsed
                # Also verify the fields have string values (base64)
                and isinstance(parsed.get("iv"), str)
                and isinstance(parsed.get("data"), str)
                and isinstance(parsed.get("tag"), str)
                and isinstance(parsed.get("version"), int)
            )
        except (json.JSONDecodeError, TypeError):
            return False

    def get(self, key: str) -> Optional[str]:
        """Get a value from storage (with automatic decryption).

        Args:
            key: The storage key.

        Returns:
            The decrypted value, or None if not found or decryption fails.
        """
        encrypted = self._storage.get(key)
        if not encrypted:
            return None

        # Check if data is encrypted
        if self._is_encrypted_format(encrypted):
            decrypted = self._decrypt(encrypted)
            if decrypted is not None:
                return decrypted
            # Decryption failed, return None (don't expose encrypted data)
            return None

        # Not encrypted format, return as-is (legacy unencrypted data)
        return encrypted

    def set(self, key: str, value: str) -> None:
        """Set a value in storage (with automatic encryption).

        Args:
            key: The storage key.
            value: The value to store.
        """
        encrypted = self._encrypt(value)
        if encrypted:
            self._storage.set(key, encrypted)
        else:
            # Fallback to unencrypted if encryption fails
            self._storage.set(key, value)

    def delete(self, key: str) -> bool:
        """Delete a value from storage.

        Args:
            key: The storage key.

        Returns:
            True if the key was deleted.
        """
        return self._storage.delete(key)

    def clear(self) -> None:
        """Clear all values from storage."""
        self._storage.clear()

    def is_encryption_available(self) -> bool:
        """Check if encryption is available.

        Returns:
            True if encryption can be used.
        """
        return self._derived_key is not None
