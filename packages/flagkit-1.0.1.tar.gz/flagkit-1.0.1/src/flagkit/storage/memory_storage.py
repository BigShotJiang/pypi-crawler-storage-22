"""FlagKit SDK in-memory storage implementation."""

import threading
from typing import Optional


class MemoryStorage:
    """In-memory storage implementation.

    Thread-safe storage for testing and development.
    """

    def __init__(self) -> None:
        self._data: dict[str, str] = {}
        self._lock = threading.Lock()

    def get(self, key: str) -> Optional[str]:
        """Get a value from storage.

        Args:
            key: The storage key.

        Returns:
            The stored value or None.
        """
        with self._lock:
            return self._data.get(key)

    def set(self, key: str, value: str) -> None:
        """Set a value in storage.

        Args:
            key: The storage key.
            value: The value to store.
        """
        with self._lock:
            self._data[key] = value

    def delete(self, key: str) -> bool:
        """Delete a value from storage.

        Args:
            key: The storage key.

        Returns:
            True if the key was deleted.
        """
        with self._lock:
            if key in self._data:
                del self._data[key]
                return True
            return False

    def clear(self) -> None:
        """Clear all values from storage."""
        with self._lock:
            self._data.clear()
