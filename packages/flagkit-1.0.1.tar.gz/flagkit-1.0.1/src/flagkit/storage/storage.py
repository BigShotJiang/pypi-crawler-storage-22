"""FlagKit SDK storage protocol."""

from typing import Optional, Protocol


class Storage(Protocol):
    """Protocol for storage interface.

    Implementations can be file-based, Redis, etc.
    """

    def get(self, key: str) -> Optional[str]:
        """Get a value from storage.

        Args:
            key: The storage key.

        Returns:
            The stored value or None.
        """
        ...

    def set(self, key: str, value: str) -> None:
        """Set a value in storage.

        Args:
            key: The storage key.
            value: The value to store.
        """
        ...

    def delete(self, key: str) -> bool:
        """Delete a value from storage.

        Args:
            key: The storage key.

        Returns:
            True if the key was deleted.
        """
        ...

    def clear(self) -> None:
        """Clear all values from storage."""
        ...
