"""FlagKit SDK type definitions."""

from flagkit.types.config import ErrorSanitizationConfig, FlagKitOptions, ResolvedConfig
from flagkit.types.context import (
    EvaluationContext,
    ResolvedContext,
    merge_contexts,
    strip_private_attributes,
)
from flagkit.types.events import (
    DEFAULT_EVENT_QUEUE_CONFIG,
    BaseEvent,
    BatchEventsResponse,
    EventQueueConfig,
)
from flagkit.types.flag import (
    EvaluationReason,
    EvaluationResult,
    FlagState,
    FlagType,
    FlagValue,
    InitResponse,
    UpdatesResponse,
    create_default_result,
)

__all__ = [
    # Config
    "FlagKitOptions",
    "ResolvedConfig",
    "ErrorSanitizationConfig",
    # Context
    "EvaluationContext",
    "ResolvedContext",
    "merge_contexts",
    "strip_private_attributes",
    # Events
    "BaseEvent",
    "EventQueueConfig",
    "DEFAULT_EVENT_QUEUE_CONFIG",
    "BatchEventsResponse",
    # Flag
    "FlagState",
    "FlagValue",
    "FlagType",
    "EvaluationResult",
    "EvaluationReason",
    "InitResponse",
    "UpdatesResponse",
    "create_default_result",
]
