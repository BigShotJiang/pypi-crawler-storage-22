"""FlagKit SDK configuration types."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Callable, Literal, Optional, Protocol, Union

if TYPE_CHECKING:
    from flagkit.types.flag import FlagState


class LoggerProtocol(Protocol):
    """Protocol for logger interface."""

    def debug(self, message: str, **kwargs: Any) -> None: ...
    def info(self, message: str, **kwargs: Any) -> None: ...
    def warn(self, message: str, **kwargs: Any) -> None: ...
    def error(self, message: str, **kwargs: Any) -> None: ...


@dataclass
class BootstrapConfig:
    """Configuration for bootstrap flag values with optional signature.

    Attributes:
        flags: Dictionary of flag key to flag value.
        signature: Optional HMAC-SHA256 signature for verification.
        timestamp: Optional timestamp when the bootstrap was signed (in ms).
    """

    flags: dict[str, Any]
    signature: Optional[str] = None
    timestamp: Optional[int] = None


@dataclass
class BootstrapVerificationOptions:
    """Configuration for bootstrap signature verification.

    Attributes:
        enabled: Whether verification is enabled. Default: True.
        max_age: Maximum age of bootstrap in milliseconds. Default: 86400000 (24 hours).
        on_failure: Action to take on verification failure.
            - "warn": Log a warning but continue (default).
            - "error": Raise a SecurityError.
            - "ignore": Silently continue without using the bootstrap.
    """

    enabled: bool = True
    max_age: int = 86400000  # 24 hours in milliseconds
    on_failure: Literal["warn", "error", "ignore"] = "warn"


@dataclass
class EvaluationJitterConfig:
    """Configuration for evaluation timing jitter.

    Adds random delay to flag evaluations to protect against
    timing-based side-channel attacks.

    Attributes:
        enabled: Whether jitter is enabled. Default: False.
        min_ms: Minimum jitter delay in milliseconds. Default: 5.
        max_ms: Maximum jitter delay in milliseconds. Default: 15.
    """

    enabled: bool = False
    min_ms: int = 5
    max_ms: int = 15


@dataclass
class ErrorSanitizationConfig:
    """Configuration for error message sanitization.

    Controls whether sensitive information is removed from error messages
    to prevent information leakage in logs and error reporting.

    Attributes:
        enabled: Whether sanitization is enabled. Default: True.
        preserve_original: If True, store the original unsanitized message
            in a separate attribute for debugging. Default: False.
    """

    enabled: bool = True
    preserve_original: bool = False


@dataclass
class FlagKitOptions:
    """Configuration options for FlagKit SDK initialization.

    Attributes:
        api_key: Required API key for authentication.
        secondary_api_key: Secondary API key for key rotation failover.
        key_rotation_grace_period: Grace period for key rotation in seconds. Default: 300.
        base_url: Base URL for the FlagKit API.
        local_port: Local development port. When set, uses http://localhost:{port}/api/v1.
        polling_interval: Polling interval in seconds.
        enable_polling: Whether to enable background polling.
        cache_enabled: Whether to enable caching.
        cache_ttl: Cache time-to-live in seconds.
        encrypt_cache: Whether to encrypt cached data using AES-256-GCM. Default: False.
        offline: Whether to run in offline mode.
        timeout: Request timeout in seconds.
        retries: Number of retry attempts.
        logger: Custom logger instance.
        bootstrap: Initial flag values to use before initialization.
        persist_cache: Whether to persist cache to storage.
        cache_storage_key: Key for persisted cache storage.
        on_ready: Callback when SDK is ready.
        on_error: Callback when errors occur.
        on_update: Callback when flags are updated.
        debug: Enable debug logging.
        enable_request_signing: Whether to sign POST requests with HMAC-SHA256. Default: True.
        strict_pii_mode: When True, throws SecurityError when PII is detected
            without private_attributes. Default: False.
        persist_events: Whether to persist events to disk for crash recovery. Default: False.
        event_storage_path: Directory for event storage. Defaults to OS temp dir.
        max_persisted_events: Maximum number of events to persist. Default: 10000.
        persistence_flush_interval: Interval between disk writes in milliseconds. Default: 1000.
        error_sanitization: Configuration for error message sanitization. Default: enabled.
    """

    api_key: str
    secondary_api_key: Optional[str] = None
    key_rotation_grace_period: float = 300.0
    base_url: str = "https://api.flagkit.dev/api/v1"
    local_port: Optional[int] = None
    polling_interval: float = 30.0
    enable_polling: bool = True
    cache_enabled: bool = True
    cache_ttl: float = 300.0
    encrypt_cache: bool = False
    offline: bool = False
    timeout: float = 5.0
    retries: int = 3
    logger: Optional[LoggerProtocol] = None
    bootstrap: Union[dict[str, Any], BootstrapConfig] = field(default_factory=dict)
    bootstrap_verification: BootstrapVerificationOptions = field(
        default_factory=BootstrapVerificationOptions
    )
    persist_cache: bool = False
    cache_storage_key: str = "flagkit_cache"
    on_ready: Optional[Callable[[], None]] = None
    on_error: Optional[Callable[[Exception], None]] = None
    on_update: Optional[Callable[[list[FlagState]], None]] = None
    debug: bool = False
    enable_request_signing: bool = True
    strict_pii_mode: bool = False
    persist_events: bool = False
    event_storage_path: Optional[str] = None
    max_persisted_events: int = 10000
    persistence_flush_interval: int = 1000
    evaluation_jitter: EvaluationJitterConfig = field(default_factory=EvaluationJitterConfig)
    error_sanitization: ErrorSanitizationConfig = field(
        default_factory=ErrorSanitizationConfig
    )


@dataclass
class ResolvedConfig:
    """Resolved SDK configuration with all defaults applied.

    This is the internal configuration representation after
    processing FlagKitOptions with defaults.
    """

    api_key: str
    secondary_api_key: Optional[str]
    key_rotation_grace_period: float  # In seconds
    base_url: str
    local_port: Optional[int]
    polling_interval: float  # In seconds
    enable_polling: bool
    cache_enabled: bool
    cache_ttl: float  # In seconds
    encrypt_cache: bool
    offline: bool
    timeout: float  # In seconds
    retries: int
    logger: Optional[LoggerProtocol]
    bootstrap: Union[dict[str, Any], BootstrapConfig]
    bootstrap_verification: BootstrapVerificationOptions
    persist_cache: bool
    cache_storage_key: str
    on_ready: Optional[Callable[[], None]]
    on_error: Optional[Callable[[Exception], None]]
    on_update: Optional[Callable[[list[FlagState]], None]]
    debug: bool
    enable_request_signing: bool
    strict_pii_mode: bool
    persist_events: bool
    event_storage_path: Optional[str]
    max_persisted_events: int
    persistence_flush_interval: int  # In milliseconds
    evaluation_jitter: EvaluationJitterConfig
    error_sanitization: ErrorSanitizationConfig
