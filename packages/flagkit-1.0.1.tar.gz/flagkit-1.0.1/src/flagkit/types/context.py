"""FlagKit SDK evaluation context types."""

from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class EvaluationContext:
    """Evaluation context containing user and environment attributes.

    Used for targeting rules and personalization.

    Attributes:
        user_id: Unique user identifier.
        user_key: Alternative user key (e.g., email hash).
        email: User email address.
        name: User display name.
        anonymous: Whether the user is anonymous.
        country: ISO country code (e.g., "US", "GB").
        ip: User IP address.
        user_agent: Browser/device user agent string.
        custom: Custom attributes for targeting.
        private_attributes: List of attribute names that should not be sent to server.
    """

    user_id: Optional[str] = None
    user_key: Optional[str] = None
    email: Optional[str] = None
    name: Optional[str] = None
    anonymous: Optional[bool] = None
    country: Optional[str] = None
    ip: Optional[str] = None
    user_agent: Optional[str] = None
    custom: dict[str, Any] = field(default_factory=dict)
    private_attributes: list[str] = field(default_factory=list)


@dataclass
class ResolvedContext:
    """Context with all attributes resolved for sending to API.

    Private attributes have been stripped from this context.
    """

    user_id: Optional[str] = None
    user_key: Optional[str] = None
    email: Optional[str] = None
    name: Optional[str] = None
    anonymous: Optional[bool] = None
    country: Optional[str] = None
    ip: Optional[str] = None
    user_agent: Optional[str] = None
    custom: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API requests."""
        result: dict[str, Any] = {}
        if self.user_id is not None:
            result["userId"] = self.user_id
        if self.user_key is not None:
            result["userKey"] = self.user_key
        if self.email is not None:
            result["email"] = self.email
        if self.name is not None:
            result["name"] = self.name
        if self.anonymous is not None:
            result["anonymous"] = self.anonymous
        if self.country is not None:
            result["country"] = self.country
        if self.ip is not None:
            result["ip"] = self.ip
        if self.user_agent is not None:
            result["userAgent"] = self.user_agent
        if self.custom:
            result["custom"] = self.custom
        return result


def merge_contexts(
    base: Optional[EvaluationContext],
    override: Optional[EvaluationContext],
) -> Optional[EvaluationContext]:
    """Merge two contexts, with the second taking precedence.

    Args:
        base: The base context to merge.
        override: The override context (takes precedence).

    Returns:
        Merged context, or None if both inputs are None.
    """
    if base is None and override is None:
        return None
    if base is None:
        return override
    if override is None:
        return base

    return EvaluationContext(
        user_id=override.user_id if override.user_id is not None else base.user_id,
        user_key=override.user_key if override.user_key is not None else base.user_key,
        email=override.email if override.email is not None else base.email,
        name=override.name if override.name is not None else base.name,
        anonymous=override.anonymous if override.anonymous is not None else base.anonymous,
        country=override.country if override.country is not None else base.country,
        ip=override.ip if override.ip is not None else base.ip,
        user_agent=override.user_agent if override.user_agent is not None else base.user_agent,
        custom={**base.custom, **override.custom},
        private_attributes=list(set(base.private_attributes + override.private_attributes)),
    )


def strip_private_attributes(context: EvaluationContext) -> ResolvedContext:
    """Strip private attributes from context before sending to server.

    Args:
        context: The evaluation context with potential private attributes.

    Returns:
        A resolved context with private attributes stripped.
    """
    result = ResolvedContext(
        user_id=context.user_id,
        user_key=context.user_key,
        email=context.email,
        name=context.name,
        anonymous=context.anonymous,
        country=context.country,
        ip=context.ip,
        user_agent=context.user_agent,
        custom=dict(context.custom),
    )

    if context.private_attributes:
        for attr in context.private_attributes:
            if attr.startswith("custom.") and result.custom:
                custom_key = attr[7:]  # Remove "custom." prefix
                result.custom.pop(custom_key, None)
            elif attr == "user_id":
                result.user_id = None
            elif attr == "user_key":
                result.user_key = None
            elif attr == "email":
                result.email = None
            elif attr == "name":
                result.name = None
            elif attr == "country":
                result.country = None
            elif attr == "ip":
                result.ip = None
            elif attr == "user_agent":
                result.user_agent = None

    return result
