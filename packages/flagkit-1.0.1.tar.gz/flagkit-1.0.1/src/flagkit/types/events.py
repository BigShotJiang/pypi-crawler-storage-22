"""FlagKit SDK event types."""

from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class EventQueueConfig:
    """Configuration for event queue behavior.

    Attributes:
        batch_size: Number of events to batch before sending.
        flush_interval: Interval in seconds between automatic flushes.
        max_queue_size: Maximum number of events to queue.
        enabled_event_types: Event types to track ("*" for all).
        disabled_event_types: Event types to exclude.
        sample_rate: Sampling rate for events (0.0 to 1.0).
    """

    batch_size: int = 10
    flush_interval: float = 30.0
    max_queue_size: int = 1000
    enabled_event_types: list[str] = field(default_factory=lambda: ["*"])
    disabled_event_types: list[str] = field(default_factory=list)
    sample_rate: float = 1.0


# Default event queue configuration
DEFAULT_EVENT_QUEUE_CONFIG = EventQueueConfig()


@dataclass
class BaseEvent:
    """Base event structure for analytics.

    Attributes:
        event_type: Type of the event (e.g., "purchase", "page_view").
        timestamp: ISO 8601 timestamp when the event occurred.
        sdk_version: Version of the SDK.
        sdk_language: Programming language of the SDK.
        session_id: Session identifier.
        environment_id: Environment identifier.
        event_data: Additional event data.
        user_id: Optional user identifier.
        flag_key: Optional flag key if event is related to a flag.
    """

    event_type: str
    timestamp: str
    sdk_version: str
    sdk_language: str
    session_id: str
    environment_id: str
    event_data: Optional[dict[str, Any]] = None
    user_id: Optional[str] = None
    flag_key: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        """Convert event to dictionary for API request."""
        result: dict[str, Any] = {
            "eventType": self.event_type,
            "timestamp": self.timestamp,
            "sdkVersion": self.sdk_version,
            "sdkLanguage": self.sdk_language,
            "sessionId": self.session_id,
            "environmentId": self.environment_id,
        }
        if self.event_data:
            result["eventData"] = self.event_data
        if self.user_id:
            result["userId"] = self.user_id
        if self.flag_key:
            result["flagKey"] = self.flag_key
        return result


@dataclass
class BatchEventsResponse:
    """Response from the batch events endpoint.

    Attributes:
        success: Whether the batch was processed successfully.
        message: Response message.
        recorded: Number of events recorded.
        errors: Number of events that failed.
    """

    success: bool
    message: str
    recorded: int = 0
    errors: int = 0

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "BatchEventsResponse":
        """Create BatchEventsResponse from API response dictionary."""
        return cls(
            success=data.get("success", False),
            message=data.get("message", ""),
            recorded=data.get("recorded", 0),
            errors=data.get("errors", 0),
        )
