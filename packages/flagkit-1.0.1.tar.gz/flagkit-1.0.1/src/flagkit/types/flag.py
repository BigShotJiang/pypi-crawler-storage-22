"""FlagKit SDK flag types."""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Generic, Literal, Optional, TypeVar, Union

# Flag value types
FlagValue = Union[bool, str, int, float, dict[str, Any], None]
FlagType = Literal["boolean", "string", "number", "json"]
EvaluationReason = Literal[
    "FLAG_NOT_FOUND",
    "FLAG_DISABLED",
    "ENVIRONMENT_NOT_CONFIGURED",
    "FALLTHROUGH",
    "RULE_MATCH",
    "SEGMENT_MATCH",
    "DEFAULT",
    "EVALUATION_ERROR",
    "CACHED",
    "STALE_CACHE",
    "BOOTSTRAP",
]

T = TypeVar("T", bound=FlagValue)


@dataclass
class FlagState:
    """Flag state as returned from the server.

    Attributes:
        key: Unique flag identifier.
        value: Current flag value.
        enabled: Whether the flag is enabled.
        version: Flag configuration version.
        flag_type: Type of the flag value.
        last_modified: ISO timestamp of last modification.
    """

    key: str
    value: FlagValue
    enabled: bool
    version: int
    flag_type: FlagType
    last_modified: str

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "FlagState":
        """Create FlagState from API response dictionary."""
        return cls(
            key=data["key"],
            value=data["value"],
            enabled=data["enabled"],
            version=data["version"],
            flag_type=data.get("flagType", "boolean"),
            last_modified=data.get("lastModified", ""),
        )


@dataclass
class EvaluationResult(Generic[T]):
    """Result of a flag evaluation.

    Attributes:
        flag_key: The flag key that was evaluated.
        value: The evaluated value.
        enabled: Whether the flag is enabled.
        reason: The reason for this evaluation result.
        variation_id: ID of the matched variation.
        rule_id: ID of the matched rule.
        segment_id: ID of the matched segment.
        version: Flag configuration version.
        timestamp: Timestamp of evaluation.
    """

    flag_key: str
    value: T
    enabled: bool
    reason: EvaluationReason
    version: int = 0
    variation_id: Optional[str] = None
    rule_id: Optional[str] = None
    segment_id: Optional[str] = None
    timestamp: datetime = field(default_factory=datetime.now)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "EvaluationResult[Any]":
        """Create EvaluationResult from API response dictionary."""
        return cls(
            flag_key=data["flagKey"],
            value=data["value"],
            enabled=data.get("enabled", True),
            reason=data.get("reason", "FALLTHROUGH"),
            version=data.get("version", 0),
            variation_id=data.get("variationId"),
            rule_id=data.get("ruleId"),
            segment_id=data.get("segmentId"),
            timestamp=datetime.now(),
        )


def create_default_result(
    key: str,
    default_value: T,
    reason: EvaluationReason,
) -> EvaluationResult[T]:
    """Create a default evaluation result.

    Args:
        key: The flag key.
        default_value: The default value to use.
        reason: The reason for using the default.

    Returns:
        An EvaluationResult with the default value.
    """
    return EvaluationResult(
        flag_key=key,
        value=default_value,
        enabled=False,
        reason=reason,
        version=0,
        timestamp=datetime.now(),
    )


@dataclass
class InitResponse:
    """Response from the SDK initialization endpoint.

    Attributes:
        flags: List of flag states.
        environment: Environment name.
        environment_id: Environment UUID.
        project_id: Project UUID.
        organization_id: Organization UUID.
        server_time: Server timestamp.
        polling_interval_seconds: Recommended polling interval.
        streaming_url: URL for streaming updates (if available).
        metadata: Additional metadata.
    """

    flags: list[FlagState]
    environment: str
    environment_id: str
    project_id: str
    organization_id: str
    server_time: str
    polling_interval_seconds: int
    streaming_url: Optional[str] = None
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "InitResponse":
        """Create InitResponse from API response dictionary."""
        flags = [FlagState.from_dict(f) for f in data.get("flags", [])]
        return cls(
            flags=flags,
            environment=data.get("environment", ""),
            environment_id=data.get("environmentId", ""),
            project_id=data.get("projectId", ""),
            organization_id=data.get("organizationId", ""),
            server_time=data.get("serverTime", ""),
            polling_interval_seconds=data.get("pollingIntervalSeconds", 30),
            streaming_url=data.get("streamingUrl"),
            metadata=data.get("metadata", {}),
        )


@dataclass
class UpdatesResponse:
    """Response from the SDK updates endpoint.

    Attributes:
        flags: List of updated flag states.
        checked_at: Timestamp when updates were checked.
        since: The since timestamp from the request.
    """

    flags: list[FlagState]
    checked_at: str
    since: str

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "UpdatesResponse":
        """Create UpdatesResponse from API response dictionary."""
        flags = [FlagState.from_dict(f) for f in data.get("flags", [])]
        return cls(
            flags=flags,
            checked_at=data.get("checkedAt", ""),
            since=data.get("since", ""),
        )
