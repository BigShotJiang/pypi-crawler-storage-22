"""FlagKit SDK utilities."""

from flagkit.utils.logger import Logger, LogLevel, create_logger
from flagkit.utils.platform import (
    generate_session_id,
    get_current_timestamp,
    get_platform_info,
    get_sdk_user_agent,
)
from flagkit.utils.security import (
    DEFAULT_SECURITY_CONFIG,
    PIIDetectionResult,
    SecurityConfig,
    SignedPayload,
    check_for_potential_pii,
    create_request_signature,
    derive_encryption_key,
    detect_potential_pii,
    generate_hmac_sha256,
    get_key_id,
    is_client_key,
    is_potential_pii_field,
    is_production_environment,
    is_server_key,
    sign_payload,
    verify_signed_payload,
    warn_if_potential_pii,
    warn_if_server_key_in_browser,
)
from flagkit.utils.validators import (
    is_valid_context,
    is_valid_event_data,
    is_valid_event_type,
    is_valid_flag_key,
    validate_options,
)
from flagkit.utils.version import (
    ParsedVersion,
    compare_versions,
    is_version_at_least,
    is_version_less_than,
    parse_version,
)

__all__ = [
    # Logger
    "Logger",
    "create_logger",
    "LogLevel",
    # Platform
    "get_sdk_user_agent",
    "get_platform_info",
    "generate_session_id",
    "get_current_timestamp",
    # Security
    "is_potential_pii_field",
    "detect_potential_pii",
    "check_for_potential_pii",
    "PIIDetectionResult",
    "warn_if_potential_pii",
    "is_server_key",
    "is_client_key",
    "warn_if_server_key_in_browser",
    "is_production_environment",
    "get_key_id",
    "generate_hmac_sha256",
    "create_request_signature",
    "sign_payload",
    "verify_signed_payload",
    "derive_encryption_key",
    "SignedPayload",
    "SecurityConfig",
    "DEFAULT_SECURITY_CONFIG",
    # Validators
    "validate_options",
    "is_valid_flag_key",
    "is_valid_context",
    "is_valid_event_type",
    "is_valid_event_data",
    # Version
    "ParsedVersion",
    "parse_version",
    "compare_versions",
    "is_version_less_than",
    "is_version_at_least",
]
