"""FlagKit SDK logger interface."""

import logging
from enum import IntEnum
from typing import Any, Optional, Protocol


class LogLevel(IntEnum):
    """Log levels for the FlagKit SDK."""

    DEBUG = logging.DEBUG
    INFO = logging.INFO
    WARN = logging.WARNING
    ERROR = logging.ERROR


class Logger(Protocol):
    """Protocol for logger interface.

    Any logger that implements these methods can be used with the SDK.
    """

    def debug(self, message: str, **kwargs: Any) -> None:
        """Log a debug message."""
        ...

    def info(self, message: str, **kwargs: Any) -> None:
        """Log an info message."""
        ...

    def warn(self, message: str, **kwargs: Any) -> None:
        """Log a warning message."""
        ...

    def error(self, message: str, **kwargs: Any) -> None:
        """Log an error message."""
        ...


class DefaultLogger:
    """Default logger implementation using Python's logging module."""

    def __init__(
        self,
        name: str = "flagkit",
        level: LogLevel = LogLevel.INFO,
        debug: bool = False,
    ) -> None:
        self._logger = logging.getLogger(name)
        if debug:
            self._logger.setLevel(LogLevel.DEBUG)
        else:
            self._logger.setLevel(level)

        # Add handler if none exists
        if not self._logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                "[%(asctime)s] %(levelname)s [%(name)s] %(message)s",
                datefmt="%Y-%m-%d %H:%M:%S",
            )
            handler.setFormatter(formatter)
            self._logger.addHandler(handler)

    def _format_extras(self, **kwargs: Any) -> str:
        """Format extra arguments for logging."""
        if not kwargs:
            return ""
        parts = [f"{k}={v!r}" for k, v in kwargs.items()]
        return " | " + ", ".join(parts)

    def debug(self, message: str, **kwargs: Any) -> None:
        """Log a debug message."""
        self._logger.debug(f"{message}{self._format_extras(**kwargs)}")

    def info(self, message: str, **kwargs: Any) -> None:
        """Log an info message."""
        self._logger.info(f"{message}{self._format_extras(**kwargs)}")

    def warn(self, message: str, **kwargs: Any) -> None:
        """Log a warning message."""
        self._logger.warning(f"{message}{self._format_extras(**kwargs)}")

    def error(self, message: str, **kwargs: Any) -> None:
        """Log an error message."""
        self._logger.error(f"{message}{self._format_extras(**kwargs)}")


class NullLogger:
    """Null logger that discards all messages."""

    def debug(self, message: str, **kwargs: Any) -> None:  # noqa: ARG002
        pass

    def info(self, message: str, **kwargs: Any) -> None:  # noqa: ARG002
        pass

    def warn(self, message: str, **kwargs: Any) -> None:  # noqa: ARG002
        pass

    def error(self, message: str, **kwargs: Any) -> None:  # noqa: ARG002
        pass


def create_logger(
    logger: Optional[Logger] = None,
    debug: bool = False,
) -> Logger:
    """Create a logger instance.

    Args:
        logger: Custom logger instance to use.
        debug: Enable debug logging.

    Returns:
        A logger instance.
    """
    if logger is not None:
        return logger
    return DefaultLogger(debug=debug)
