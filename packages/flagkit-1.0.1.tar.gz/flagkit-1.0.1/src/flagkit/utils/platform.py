"""FlagKit SDK platform utilities."""

import platform
import uuid
from datetime import datetime, timezone
from typing import Any


def get_platform_info() -> dict[str, Any]:
    """Get information about the current platform.

    Returns:
        Dictionary with platform details.
    """
    return {
        "os": platform.system(),
        "os_version": platform.release(),
        "python_version": platform.python_version(),
        "python_implementation": platform.python_implementation(),
        "machine": platform.machine(),
    }


def get_sdk_user_agent(sdk_version: str) -> str:
    """Generate the SDK user agent string.

    Args:
        sdk_version: The SDK version.

    Returns:
        User agent string.
    """
    py_version = platform.python_version()
    py_impl = platform.python_implementation()
    os_name = platform.system()
    os_version = platform.release()

    return f"FlagKit-Python/{sdk_version} ({py_impl}/{py_version}; {os_name}/{os_version})"


def generate_session_id() -> str:
    """Generate a unique session ID.

    Returns:
        A UUID4 string.
    """
    return str(uuid.uuid4())


def get_current_timestamp() -> str:
    """Get the current timestamp in ISO 8601 format.

    Returns:
        ISO 8601 formatted timestamp string.
    """
    return datetime.now(timezone.utc).isoformat()


def is_main_thread() -> bool:
    """Check if we're running in the main thread.

    Returns:
        True if in main thread.
    """
    import threading

    return threading.current_thread() is threading.main_thread()
