"""FlagKit SDK security utilities."""

import hashlib
import hmac
import json
import os
import sys
import time
from dataclasses import dataclass
from typing import Any, Optional, Protocol, TypeVar

T = TypeVar("T")


class Logger(Protocol):
    """Logger protocol for type checking."""

    def debug(self, message: str, **kwargs: Any) -> None:
        ...

    def info(self, message: str, **kwargs: Any) -> None:
        ...

    def warn(self, message: str, **kwargs: Any) -> None:
        ...

    def error(self, message: str, **kwargs: Any) -> None:
        ...


# Common PII field patterns (case-insensitive)
PII_PATTERNS: set[str] = {
    "email",
    "phone",
    "telephone",
    "mobile",
    "ssn",
    "social_security",
    "socialsecurity",
    "credit_card",
    "creditcard",
    "card_number",
    "cardnumber",
    "cvv",
    "password",
    "passwd",
    "secret",
    "token",
    "api_key",
    "apikey",
    "private_key",
    "privatekey",
    "access_token",
    "accesstoken",
    "refresh_token",
    "refreshtoken",
    "auth_token",
    "authtoken",
    "address",
    "street",
    "zip_code",
    "zipcode",
    "postal_code",
    "postalcode",
    "date_of_birth",
    "dateofbirth",
    "dob",
    "birth_date",
    "birthdate",
    "passport",
    "driver_license",
    "driverlicense",
    "national_id",
    "nationalid",
    "bank_account",
    "bankaccount",
    "routing_number",
    "routingnumber",
    "iban",
    "swift",
}


def is_potential_pii_field(field_name: str) -> bool:
    """Check if a field name potentially contains PII.

    Args:
        field_name: The field name to check.

    Returns:
        True if the field name matches a PII pattern.
    """
    lower_name = field_name.lower().replace("-", "").replace("_", "")
    return any(pattern.replace("_", "") in lower_name for pattern in PII_PATTERNS)


def detect_potential_pii(data: dict[str, Any], prefix: str = "") -> list[str]:
    """Detect potential PII in an object and return the field names.

    Args:
        data: The data object to check.
        prefix: The prefix path for nested fields.

    Returns:
        List of field paths that may contain PII.
    """
    pii_fields: list[str] = []

    for key, value in data.items():
        full_path = f"{prefix}.{key}" if prefix else key

        if is_potential_pii_field(key):
            pii_fields.append(full_path)

        # Recursively check nested dicts
        if isinstance(value, dict):
            nested_pii = detect_potential_pii(value, full_path)
            pii_fields.extend(nested_pii)

    return pii_fields


@dataclass
class PIIDetectionResult:
    """Result of PII detection."""

    has_pii: bool
    fields: list[str]
    message: str


def check_for_potential_pii(
    data: Optional[dict[str, Any]],
    data_type: str,
) -> PIIDetectionResult:
    """Check for potential PII in data and return detailed result.

    Args:
        data: The data to check.
        data_type: The type of data ('context' or 'event').

    Returns:
        PIIDetectionResult with detection details.
    """
    if not data:
        return PIIDetectionResult(has_pii=False, fields=[], message="")

    pii_fields = detect_potential_pii(data)

    if not pii_fields:
        return PIIDetectionResult(has_pii=False, fields=[], message="")

    advice = (
        "Consider adding these to private_attributes."
        if data_type == "context"
        else "Consider removing sensitive data from events."
    )
    message = (
        f"[FlagKit Security] Potential PII detected in {data_type} data: "
        f"{', '.join(pii_fields)}. {advice}"
    )

    return PIIDetectionResult(has_pii=True, fields=pii_fields, message=message)


def warn_if_potential_pii(
    data: Optional[dict[str, Any]],
    data_type: str,
    logger: Optional[Logger] = None,
) -> None:
    """Warn about potential PII in data.

    Args:
        data: The data to check.
        data_type: The type of data ('context' or 'event').
        logger: Optional logger instance.
    """
    if not data or not logger:
        return

    result = check_for_potential_pii(data, data_type)

    if result.has_pii:
        logger.warn(result.message)


def is_server_key(api_key: str) -> bool:
    """Check if an API key is a server key.

    Args:
        api_key: The API key to check.

    Returns:
        True if this is a server key (srv_ prefix).
    """
    return api_key.startswith("srv_")


def is_client_key(api_key: str) -> bool:
    """Check if an API key is a client/SDK key.

    Args:
        api_key: The API key to check.

    Returns:
        True if this is a client key (sdk_ or cli_ prefix).
    """
    return api_key.startswith("sdk_") or api_key.startswith("cli_")


def is_browser_environment() -> bool:
    """Check if running in a browser-like environment.

    This checks for common browser/client environments like:
    - Brython (Python in browser)
    - Pyodide (WebAssembly Python)
    - Transcrypt

    Returns:
        True if running in a browser environment.
    """
    # Check for Brython
    if "brython" in sys.modules:
        return True

    # Check for Pyodide
    if "pyodide" in sys.modules:
        return True

    # Check for js module (available in browser Python)
    return "js" in sys.modules


def is_production_environment() -> bool:
    """Check if running in production environment.

    Returns:
        True if PYTHON_ENV or NODE_ENV is 'production'.
    """
    python_env = os.environ.get("PYTHON_ENV", "").lower()
    node_env = os.environ.get("NODE_ENV", "").lower()
    env = os.environ.get("ENV", "").lower()
    environment = os.environ.get("ENVIRONMENT", "").lower()

    return any(e == "production" for e in [python_env, node_env, env, environment])


def warn_if_server_key_in_browser(
    api_key: str, logger: Optional[Logger] = None
) -> None:
    """Warn if server key is used in a browser environment.

    Args:
        api_key: The API key being used.
        logger: Optional logger instance.
    """
    if is_browser_environment() and is_server_key(api_key):
        message = (
            "[FlagKit Security] WARNING: Server keys (srv_) should not be used "
            "in browser environments. This exposes your server key in client-side "
            "code, which is a security risk. Use SDK keys (sdk_) for client-side "
            "applications instead. See: https://docs.flagkit.dev/sdk/security#api-keys"
        )

        # Always print to stderr for visibility
        print(message, file=sys.stderr)

        # Also log through the SDK logger if available
        if logger:
            logger.warn(message)


def get_key_id(api_key: str) -> str:
    """Get the first 8 characters of an API key for identification.

    This is safe to expose as it doesn't reveal the full key.

    Args:
        api_key: The full API key.

    Returns:
        First 8 characters of the key.
    """
    return api_key[:8] if len(api_key) >= 8 else api_key


def generate_hmac_sha256(message: str, key: str) -> str:
    """Generate HMAC-SHA256 signature.

    Args:
        message: The message to sign.
        key: The secret key.

    Returns:
        Hex-encoded signature.
    """
    signature = hmac.new(
        key.encode("utf-8"),
        message.encode("utf-8"),
        hashlib.sha256,
    )
    return signature.hexdigest()


def create_request_signature(
    body: str,
    api_key: str,
    timestamp: Optional[int] = None,
) -> tuple[str, int]:
    """Create signature string for request headers.

    Format: timestamp.signature

    Args:
        body: The request body string.
        api_key: The API key to sign with.
        timestamp: Optional timestamp (defaults to current time in ms).

    Returns:
        Tuple of (signature, timestamp).
    """
    ts = timestamp if timestamp is not None else int(time.time() * 1000)
    message = f"{ts}.{body}"
    signature = generate_hmac_sha256(message, api_key)
    return signature, ts


@dataclass
class SignedPayload:
    """Signed payload structure for beacon requests."""

    data: Any
    signature: str
    timestamp: int
    key_id: str


def sign_payload(
    data: Any,
    api_key: str,
    timestamp: Optional[int] = None,
) -> SignedPayload:
    """Sign a payload with HMAC-SHA256.

    Args:
        data: The data to sign.
        api_key: The API key to sign with.
        timestamp: Optional timestamp (defaults to current time in ms).

    Returns:
        SignedPayload with signature details.
    """
    ts = timestamp if timestamp is not None else int(time.time() * 1000)
    payload = json.dumps(data, separators=(",", ":"), sort_keys=True)
    message = f"{ts}.{payload}"
    signature = generate_hmac_sha256(message, api_key)

    return SignedPayload(
        data=data,
        signature=signature,
        timestamp=ts,
        key_id=get_key_id(api_key),
    )


def verify_signed_payload(
    signed_payload: SignedPayload,
    api_key: str,
    max_age_ms: int = 300000,  # 5 minutes
) -> bool:
    """Verify a signed payload.

    Args:
        signed_payload: The signed payload to verify.
        api_key: The API key to verify with.
        max_age_ms: Maximum age of the signature in milliseconds.

    Returns:
        True if the signature is valid.
    """
    # Check timestamp age
    current_time = int(time.time() * 1000)
    age = current_time - signed_payload.timestamp

    if age > max_age_ms or age < 0:
        return False

    # Verify key ID matches
    if signed_payload.key_id != get_key_id(api_key):
        return False

    # Verify signature
    payload = json.dumps(signed_payload.data, separators=(",", ":"), sort_keys=True)
    message = f"{signed_payload.timestamp}.{payload}"
    expected_signature = generate_hmac_sha256(message, api_key)

    return hmac.compare_digest(signed_payload.signature, expected_signature)


def derive_encryption_key(api_key: str, salt: bytes = b"FlagKit-v1-cache") -> bytes:
    """Derive an encryption key from an API key using PBKDF2.

    Args:
        api_key: The API key to derive from.
        salt: Salt for key derivation.

    Returns:
        32-byte encryption key.
    """
    return hashlib.pbkdf2_hmac(
        "sha256",
        api_key.encode("utf-8"),
        salt,
        iterations=100000,
        dklen=32,
    )


class SecurityConfig:
    """Security configuration options."""

    def __init__(
        self,
        warn_on_potential_pii: Optional[bool] = None,
        warn_on_server_key_in_browser: bool = True,
        additional_pii_patterns: Optional[list[str]] = None,
        strict_pii_mode: bool = False,
    ):
        """Initialize security configuration.

        Args:
            warn_on_potential_pii: Whether to warn about potential PII.
                Defaults to True in non-production environments.
            warn_on_server_key_in_browser: Whether to warn when server keys
                are used in browser environments. Default: True.
            additional_pii_patterns: Custom PII patterns to detect.
            strict_pii_mode: When True, throws SecurityError instead of
                warning when PII is detected without private_attributes.
                Default: False.
        """
        if warn_on_potential_pii is None:
            # Default to True in non-production environments
            self.warn_on_potential_pii = not is_production_environment()
        else:
            self.warn_on_potential_pii = warn_on_potential_pii

        self.warn_on_server_key_in_browser = warn_on_server_key_in_browser
        self.additional_pii_patterns = additional_pii_patterns or []
        self.strict_pii_mode = strict_pii_mode

        # Add custom patterns to the global set
        if self.additional_pii_patterns:
            PII_PATTERNS.update(p.lower() for p in self.additional_pii_patterns)


# Default security configuration
DEFAULT_SECURITY_CONFIG = SecurityConfig()


def canonicalize_object(obj: Any) -> str:
    """Sort keys recursively and return minimal JSON string.

    This creates a canonical representation of an object for signature
    verification, ensuring consistent ordering of keys.

    Args:
        obj: The object to canonicalize.

    Returns:
        A minimal JSON string with sorted keys.
    """

    def _sort_recursive(item: Any) -> Any:
        """Recursively sort dict keys and list items."""
        if isinstance(item, dict):
            return {k: _sort_recursive(v) for k, v in sorted(item.items())}
        elif isinstance(item, list):
            return [_sort_recursive(elem) for elem in item]
        else:
            return item

    sorted_obj = _sort_recursive(obj)
    return json.dumps(sorted_obj, separators=(",", ":"), sort_keys=True)


def verify_bootstrap_signature(
    bootstrap: Any,  # BootstrapConfig type, but avoid circular import
    api_key: str,
    options: Optional[Any] = None,  # BootstrapVerificationOptions type
) -> tuple[bool, Optional[str]]:
    """Verify the HMAC-SHA256 signature of a bootstrap configuration.

    Args:
        bootstrap: The BootstrapConfig to verify.
        api_key: The API key to verify the signature with.
        options: Optional verification options (BootstrapVerificationOptions).

    Returns:
        A tuple of (valid, error_message). If valid is True, error_message
        will be None. If valid is False, error_message contains details.
    """
    # Import here to avoid circular imports
    from flagkit.types.config import BootstrapConfig, BootstrapVerificationOptions

    # Default options if not provided
    if options is None:
        options = BootstrapVerificationOptions()

    # If verification is disabled, always return valid
    if not options.enabled:
        return True, None

    # Ensure bootstrap is a BootstrapConfig
    if not isinstance(bootstrap, BootstrapConfig):
        return True, None  # Legacy dict format, no verification needed

    # If no signature provided, treat as unsigned (valid by default)
    if bootstrap.signature is None:
        return True, None

    # Verify timestamp if present
    if bootstrap.timestamp is not None:
        current_time = int(time.time() * 1000)
        age = current_time - bootstrap.timestamp

        if age < 0:
            return False, "Bootstrap timestamp is in the future"

        if age > options.max_age:
            return False, f"Bootstrap has expired (age: {age}ms, max: {options.max_age}ms)"

    # Create canonical representation of flags
    canonical_flags = canonicalize_object(bootstrap.flags)

    # Build message for signature verification
    if bootstrap.timestamp is not None:
        message = f"{bootstrap.timestamp}.{canonical_flags}"
    else:
        message = canonical_flags

    # Generate expected signature
    expected_signature = generate_hmac_sha256(message, api_key)

    # Constant-time comparison to prevent timing attacks
    if not hmac.compare_digest(bootstrap.signature, expected_signature):
        return False, "Bootstrap signature verification failed"

    return True, None
