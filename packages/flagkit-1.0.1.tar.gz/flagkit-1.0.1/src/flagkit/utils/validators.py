"""FlagKit SDK input validation utilities."""

import re
from typing import Any, Optional
from urllib.parse import urlparse

from flagkit.errors.flagkit_error import InitializationError, SecurityError
from flagkit.types.config import FlagKitOptions
from flagkit.types.context import EvaluationContext
from flagkit.utils.logger import Logger
from flagkit.utils.security import is_production_environment, warn_if_server_key_in_browser

# Valid flag key pattern: alphanumeric, hyphens, underscores
FLAG_KEY_PATTERN = re.compile(r"^[a-zA-Z0-9_-]+$")

# Valid event type pattern: alphanumeric, dots, hyphens, underscores
EVENT_TYPE_PATTERN = re.compile(r"^[a-zA-Z0-9._-]+$")

# API key prefixes
VALID_API_KEY_PREFIXES = ("sdk_", "srv_", "cli_")


def validate_options(options: FlagKitOptions, logger: Optional[Logger] = None) -> None:
    """Validate SDK configuration options.

    Args:
        options: The options to validate.
        logger: Optional logger for security warnings.

    Raises:
        InitializationError: If validation fails.
    """
    # Check API key
    if not options.api_key:
        raise InitializationError("INIT_MISSING_API_KEY", "API key is required")

    if not isinstance(options.api_key, str):
        raise InitializationError("INIT_INVALID_CONFIG", "API key must be a string")

    if not options.api_key.startswith(VALID_API_KEY_PREFIXES):
        raise InitializationError(
            "INIT_INVALID_CONFIG",
            f"API key must start with one of: {', '.join(VALID_API_KEY_PREFIXES)}",
        )

    # Security check: warn if server key is used in browser environment
    warn_if_server_key_in_browser(options.api_key, logger)

    # CRITICAL: Prevent local_port from being used in production
    if options.local_port is not None and is_production_environment():
        raise SecurityError(
            "SECURITY_LOCAL_PORT_IN_PRODUCTION",
            "local_port cannot be used in production environments. "
            "This option is only for local development. "
            "See: https://docs.flagkit.dev/sdk/security#local-development",
        )

    # Validate secondary API key format if provided
    if (
        hasattr(options, "secondary_api_key")
        and options.secondary_api_key
        and not options.secondary_api_key.startswith(VALID_API_KEY_PREFIXES)
    ):
        raise InitializationError(
            "INIT_INVALID_CONFIG",
            f"Secondary API key must start with one of: {', '.join(VALID_API_KEY_PREFIXES)}",
        )

    # Check base URL
    if options.base_url:
        try:
            parsed = urlparse(options.base_url)
            if not parsed.scheme or not parsed.netloc:
                raise InitializationError(
                    "INIT_INVALID_BASE_URL",
                    "Invalid base URL format",
                )
        except Exception as e:
            raise InitializationError(
                "INIT_INVALID_BASE_URL",
                f"Invalid base URL: {e}",
            ) from e

    # Check numeric options
    if options.polling_interval < 0:
        raise InitializationError(
            "INIT_INVALID_CONFIG",
            "Polling interval must be non-negative",
        )

    if options.cache_ttl < 0:
        raise InitializationError(
            "INIT_INVALID_CONFIG",
            "Cache TTL must be non-negative",
        )

    if options.timeout <= 0:
        raise InitializationError(
            "INIT_INVALID_CONFIG",
            "Timeout must be positive",
        )

    if options.retries < 0:
        raise InitializationError(
            "INIT_INVALID_CONFIG",
            "Retries must be non-negative",
        )


def is_valid_flag_key(key: Any) -> bool:
    """Check if a flag key is valid.

    Args:
        key: The flag key to validate.

    Returns:
        True if the key is valid.
    """
    if not isinstance(key, str):
        return False
    if not key or len(key) > 256:
        return False
    return bool(FLAG_KEY_PATTERN.match(key))


def is_valid_context(context: Optional[Any]) -> bool:
    """Check if an evaluation context is valid.

    Args:
        context: The context to validate.

    Returns:
        True if the context is valid.
    """
    if context is None:
        return True

    if isinstance(context, EvaluationContext):
        return True

    if isinstance(context, dict):
        # Check for valid attribute types
        for key, value in context.items():
            if not isinstance(key, str):
                return False
            # Values should be primitives, lists, or dicts
            if value is not None and not isinstance(value, (str, int, float, bool, list, dict)):
                return False
        return True

    return False


def is_valid_event_type(event_type: Any) -> bool:
    """Check if an event type is valid.

    Args:
        event_type: The event type to validate.

    Returns:
        True if the event type is valid.
    """
    if not isinstance(event_type, str):
        return False
    if not event_type or len(event_type) > 128:
        return False
    return bool(EVENT_TYPE_PATTERN.match(event_type))


def is_valid_event_data(data: Optional[Any]) -> bool:
    """Check if event data is valid.

    Args:
        data: The event data to validate.

    Returns:
        True if the data is valid.
    """
    if data is None:
        return True

    if not isinstance(data, dict):
        return False

    # Check for valid keys and JSON-serializable values
    for key, value in data.items():
        if not isinstance(key, str):
            return False
        # Values should be JSON-serializable primitives
        if value is not None and not isinstance(value, (str, int, float, bool, list, dict)):
            return False

    return True
