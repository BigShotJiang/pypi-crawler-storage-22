"""Semantic version comparison utilities for SDK version metadata handling.

These utilities are used to compare the current SDK version against
server-provided version requirements (min, recommended, latest).
"""

from dataclasses import dataclass
from typing import Optional


@dataclass
class ParsedVersion:
    """Parsed semantic version components.

    Attributes:
        major: Major version number.
        minor: Minor version number.
        patch: Patch version number.
    """

    major: int
    minor: int
    patch: int


def parse_version(version: str) -> Optional[ParsedVersion]:
    """Parse a semantic version string into numeric components.

    Args:
        version: Version string (e.g., "1.2.3" or "v1.2.3").

    Returns:
        ParsedVersion with major, minor, patch components, or None if invalid.
    """
    if not version or not isinstance(version, str):
        return None

    # Trim whitespace
    trimmed = version.strip()
    if not trimmed:
        return None

    # Strip leading 'v' or 'V' if present
    normalized = trimmed[1:] if trimmed.startswith(("v", "V")) else trimmed

    # Match semver pattern (allows pre-release suffix but ignores it for comparison)
    parts = normalized.split(".")
    if len(parts) < 3:
        return None

    try:
        # Handle pre-release suffix (e.g., "1.2.3-beta.1")
        patch_part = parts[2].split("-")[0].split("+")[0]  # Also handle build metadata

        major = int(parts[0])
        minor = int(parts[1])
        patch = int(patch_part)

        # Reject negative values (defensive)
        if major < 0 or minor < 0 or patch < 0:
            return None

        # Reject unreasonably large version numbers (defensive against DoS)
        max_version = 999999999
        if major > max_version or minor > max_version or patch > max_version:
            return None

        return ParsedVersion(major=major, minor=minor, patch=patch)
    except (ValueError, IndexError, OverflowError):
        return None


def compare_versions(a: str, b: str) -> int:
    """Compare two semantic versions.

    Args:
        a: First version string.
        b: Second version string.

    Returns:
        - Negative number if a < b
        - 0 if a == b (or either is invalid)
        - Positive number if a > b
    """
    parsed_a = parse_version(a)
    parsed_b = parse_version(b)

    if not parsed_a or not parsed_b:
        return 0

    # Compare major
    if parsed_a.major != parsed_b.major:
        return parsed_a.major - parsed_b.major

    # Compare minor
    if parsed_a.minor != parsed_b.minor:
        return parsed_a.minor - parsed_b.minor

    # Compare patch
    return parsed_a.patch - parsed_b.patch


def is_version_less_than(a: str, b: str) -> bool:
    """Check if version a is less than version b.

    Args:
        a: First version string.
        b: Second version string.

    Returns:
        True if a < b.
    """
    return compare_versions(a, b) < 0


def is_version_at_least(a: str, b: str) -> bool:
    """Check if version a is greater than or equal to version b.

    Args:
        a: First version string.
        b: Second version string.

    Returns:
        True if a >= b.
    """
    return compare_versions(a, b) >= 0
