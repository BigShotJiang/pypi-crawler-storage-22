"""FlagKit SDK HTTP client implementation."""

import json
import time
from dataclasses import dataclass, field
from typing import Any, Optional, TypeVar

import httpx

from flagkit.errors.flagkit_error import (
    AuthenticationError,
    FlagKitError,
    NetworkError,
    create_error_from_response,
)
from flagkit.http.circuit_breaker import (
    CircuitBreaker,
    CircuitBreakerConfig,
    CircuitOpenError,
)
from flagkit.http.retry import (
    RetryConfig,
    parse_retry_after,
    with_retry,
)
from flagkit.utils.logger import Logger
from flagkit.utils.platform import get_sdk_user_agent
from flagkit.utils.security import create_request_signature, get_key_id

T = TypeVar("T")

# SDK version - should be updated with releases
SDK_VERSION = "1.0.8"

# Default base URL
BASE_URL = "https://api.flagkit.dev/api/v1"


def get_base_url(local_port: int | None = None) -> str:
    """Get the base URL for the FlagKit API.

    Args:
        local_port: Local development port. When set, uses http://localhost:{port}/api/v1.

    Returns:
        The base URL to use for API requests.
    """
    if local_port is not None:
        return f"http://localhost:{local_port}/api/v1"
    return BASE_URL


@dataclass
class RequestOptions:
    """HTTP request options.

    Attributes:
        method: HTTP method.
        headers: Request headers.
        body: Request body (will be JSON serialized).
        timeout: Request timeout in seconds.
        skip_retry: Skip retry logic.
        skip_circuit_breaker: Skip circuit breaker.
    """

    method: str = "GET"
    headers: dict[str, str] = field(default_factory=dict)
    body: Optional[Any] = None
    timeout: Optional[float] = None
    skip_retry: bool = False
    skip_circuit_breaker: bool = False


@dataclass
class UsageMetrics:
    """Usage metrics extracted from response headers.

    Attributes:
        api_usage_percent: Percentage of API call limit used (0-150+).
        evaluation_usage_percent: Percentage of evaluation limit used (0-150+).
        rate_limit_warning: Whether approaching rate limit threshold.
        subscription_status: Current subscription status.
    """

    api_usage_percent: Optional[float] = None
    evaluation_usage_percent: Optional[float] = None
    rate_limit_warning: bool = False
    subscription_status: Optional[str] = None


# Type alias for usage update callback
UsageUpdateCallback = Optional[Any]  # Callable[[UsageMetrics], None]


@dataclass
class HttpResponse:
    """HTTP response wrapper.

    Attributes:
        status: Response status code.
        headers: Response headers.
        data: Parsed response body.
        request_id: Server request ID if available.
        usage_metrics: Usage metrics from response headers.
    """

    status: int
    headers: dict[str, str]
    data: Any
    request_id: Optional[str] = None
    usage_metrics: Optional[UsageMetrics] = None


@dataclass
class HttpClientConfig:
    """HTTP client configuration.

    Attributes:
        base_url: Base URL for all requests.
        api_key: API key for authentication.
        secondary_api_key: Secondary API key for key rotation.
        key_rotation_grace_period: Grace period for key rotation in seconds.
        timeout: Default request timeout in seconds.
        retry: Retry configuration.
        circuit_breaker: Circuit breaker configuration.
        logger: Logger instance.
        enable_request_signing: Whether to sign POST requests. Default: True.
        on_usage_update: Callback for usage metrics updates.
    """

    base_url: str
    api_key: str
    secondary_api_key: Optional[str] = None
    key_rotation_grace_period: float = 300.0
    timeout: float = 5.0
    retry: Optional[RetryConfig] = None
    circuit_breaker: Optional[CircuitBreakerConfig] = None
    logger: Optional[Logger] = None
    enable_request_signing: bool = True
    on_usage_update: UsageUpdateCallback = None


class HttpClient:
    """HTTP client for FlagKit API communication.

    Features:
    - Automatic retry with exponential backoff
    - Circuit breaker for failure protection
    - Request timeout handling
    - Rate limit header parsing
    - HMAC-SHA256 request signing for POST requests
    - Key rotation support with automatic failover
    """

    def __init__(self, config: HttpClientConfig) -> None:
        self._config = config
        self._logger = config.logger
        self._current_api_key = config.api_key
        self._key_rotation_timestamp: Optional[float] = None
        self._circuit_breaker = CircuitBreaker(
            config=config.circuit_breaker,
            logger=config.logger,
        )
        self._client = httpx.Client(
            base_url=config.base_url,
            timeout=config.timeout,
        )

    def get_active_api_key(self) -> str:
        """Get the current active API key.

        Returns:
            The currently active API key.
        """
        return self._current_api_key

    def get_key_id(self) -> str:
        """Get the key identifier (first 8 chars) for the current key.

        Returns:
            First 8 characters of the active API key.
        """
        return get_key_id(self._current_api_key)

    def is_in_key_rotation(self) -> bool:
        """Check if key rotation is currently active.

        Returns:
            True if within the key rotation grace period.
        """
        if self._key_rotation_timestamp is None:
            return False
        elapsed = time.time() - self._key_rotation_timestamp
        return elapsed < self._config.key_rotation_grace_period

    def _rotate_to_secondary_key(self) -> bool:
        """Rotate to secondary API key.

        Returns:
            True if rotation was successful.
        """
        if not self._config.secondary_api_key:
            return False

        if self._current_api_key == self._config.secondary_api_key:
            # Already using secondary key
            return False

        if self._logger:
            self._logger.info("Rotating to secondary API key due to authentication failure")

        self._current_api_key = self._config.secondary_api_key
        self._key_rotation_timestamp = time.time()
        return True

    def get(
        self,
        path: str,
        headers: Optional[dict[str, str]] = None,
        timeout: Optional[float] = None,
        skip_retry: bool = False,
        skip_circuit_breaker: bool = False,
    ) -> HttpResponse:
        """Make a GET request.

        Args:
            path: Request path.
            headers: Additional headers.
            timeout: Request timeout.
            skip_retry: Skip retry logic.
            skip_circuit_breaker: Skip circuit breaker.

        Returns:
            HTTP response.
        """
        return self.request(
            path,
            RequestOptions(
                method="GET",
                headers=headers or {},
                timeout=timeout,
                skip_retry=skip_retry,
                skip_circuit_breaker=skip_circuit_breaker,
            ),
        )

    def post(
        self,
        path: str,
        body: Optional[Any] = None,
        headers: Optional[dict[str, str]] = None,
        timeout: Optional[float] = None,
        skip_retry: bool = False,
        skip_circuit_breaker: bool = False,
    ) -> HttpResponse:
        """Make a POST request with automatic signing.

        Args:
            path: Request path.
            body: Request body.
            headers: Additional headers.
            timeout: Request timeout.
            skip_retry: Skip retry logic.
            skip_circuit_breaker: Skip circuit breaker.

        Returns:
            HTTP response.
        """
        # Add signing headers for POST requests
        signing_headers: dict[str, str] = {}

        if self._config.enable_request_signing and body is not None:
            try:
                body_string = json.dumps(body, separators=(",", ":"), sort_keys=True)
                signature, timestamp = create_request_signature(
                    body_string,
                    self._current_api_key,
                )
                signing_headers["X-Signature"] = signature
                signing_headers["X-Timestamp"] = str(timestamp)
                signing_headers["X-Key-Id"] = self.get_key_id()
            except Exception as e:
                if self._logger:
                    self._logger.warn(
                        "Failed to sign request, proceeding without signature",
                        error=str(e),
                    )

        combined_headers = {**signing_headers, **(headers or {})}

        return self.request(
            path,
            RequestOptions(
                method="POST",
                headers=combined_headers,
                body=body,
                timeout=timeout,
                skip_retry=skip_retry,
                skip_circuit_breaker=skip_circuit_breaker,
            ),
        )

    def request(self, path: str, options: Optional[RequestOptions] = None) -> HttpResponse:
        """Make an HTTP request.

        Args:
            path: Request path.
            options: Request options.

        Returns:
            HTTP response.
        """
        opts = options or RequestOptions()

        def do_request() -> HttpResponse:
            return self._execute_request(path, opts)

        # Wrap with key rotation support
        def with_key_rotation() -> HttpResponse:
            try:
                return do_request()
            except AuthenticationError as e:
                # Handle 401 errors with key rotation
                if e.code == "AUTH_INVALID_KEY" and self._config.secondary_api_key:
                    rotated = self._rotate_to_secondary_key()
                    if rotated:
                        if self._logger:
                            self._logger.debug("Retrying request with secondary API key")
                        return do_request()
                raise

        # Wrap with circuit breaker if enabled
        if opts.skip_circuit_breaker:
            with_cb = with_key_rotation
        else:

            def with_cb() -> HttpResponse:
                return self._circuit_breaker.execute(with_key_rotation)

        # Wrap with retry if enabled
        if opts.skip_retry:
            return with_cb()

        return with_retry(
            with_cb,
            config=self._config.retry,
            logger=self._logger,
            operation_name=f"{opts.method} {path}",
            should_retry=self._should_retry,
        )

    def _execute_request(self, path: str, options: RequestOptions) -> HttpResponse:
        """Execute a single HTTP request.

        Args:
            path: Request path.
            options: Request options.

        Returns:
            HTTP response.
        """
        headers = self._build_headers(options.headers)
        timeout = options.timeout or self._config.timeout

        try:
            if self._logger:
                self._logger.debug(
                    f"HTTP {options.method} {path}",
                    has_body=options.body is not None,
                    timeout=timeout,
                )

            response = self._client.request(
                method=options.method,
                url=path,
                headers=headers,
                json=options.body if options.body is not None else None,
                timeout=timeout,
            )

            # Extract headers
            response_headers = {k.lower(): v for k, v in response.headers.items()}
            request_id = response_headers.get("x-request-id")

            # Parse response body
            content_type = response_headers.get("content-type", "")
            if "application/json" in content_type:
                data = response.json()
            else:
                data = response.text

            # Handle error responses
            if not response.is_success:
                retry_after = parse_retry_after(response_headers.get("retry-after"))
                raise create_error_from_response(
                    response.status_code,
                    data if isinstance(data, dict) else {"message": data},
                    retry_after,
                )

            # Extract usage metrics
            usage_metrics = self._extract_usage_metrics(response_headers)
            if usage_metrics and self._config.on_usage_update:
                self._config.on_usage_update(usage_metrics)

            if self._logger:
                self._logger.debug(
                    f"HTTP {options.method} {path} -> {response.status_code}",
                    request_id=request_id,
                )

            return HttpResponse(
                status=response.status_code,
                headers=response_headers,
                data=data,
                request_id=request_id,
                usage_metrics=usage_metrics,
            )

        except httpx.TimeoutException as e:
            raise NetworkError(
                "NETWORK_TIMEOUT",
                f"Request timed out after {timeout}s",
                cause=e,
            ) from e
        except httpx.ConnectError as e:
            raise NetworkError(
                "NETWORK_CONNECTION_REFUSED",
                str(e),
                cause=e,
            ) from e
        except httpx.RequestError as e:
            raise NetworkError(
                "NETWORK_ERROR",
                str(e),
                cause=e,
            ) from e

    def _build_headers(self, custom: Optional[dict[str, str]] = None) -> dict[str, str]:
        """Build request headers.

        Args:
            custom: Custom headers to include.

        Returns:
            Complete headers dictionary.
        """
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "X-API-Key": self._current_api_key,
            "User-Agent": get_sdk_user_agent(SDK_VERSION),
            "X-FlagKit-SDK-Version": SDK_VERSION,
            "X-FlagKit-SDK-Language": "python",
        }
        if custom:
            headers.update(custom)
        return headers

    def _extract_usage_metrics(self, headers: dict[str, str]) -> Optional[UsageMetrics]:
        """Extract usage metrics from response headers.

        Args:
            headers: Response headers.

        Returns:
            UsageMetrics if any usage headers present, None otherwise.
        """
        api_usage = headers.get("x-api-usage-percent")
        eval_usage = headers.get("x-evaluation-usage-percent")
        rate_limit_warning = headers.get("x-rate-limit-warning")
        subscription_status = headers.get("x-subscription-status")

        # Return None if no usage headers present
        if not any([api_usage, eval_usage, rate_limit_warning, subscription_status]):
            return None

        metrics = UsageMetrics(
            rate_limit_warning=rate_limit_warning == "true",
        )

        if api_usage:
            try:
                metrics.api_usage_percent = float(api_usage)
            except ValueError:
                pass

        if eval_usage:
            try:
                metrics.evaluation_usage_percent = float(eval_usage)
            except ValueError:
                pass

        if subscription_status:
            valid_statuses = ["active", "trial", "past_due", "suspended", "cancelled"]
            if subscription_status in valid_statuses:
                metrics.subscription_status = subscription_status

        # Log warnings for high usage
        if metrics.api_usage_percent is not None and metrics.api_usage_percent >= 80:
            if self._logger:
                self._logger.warn(f"[FlagKit] API usage at {metrics.api_usage_percent}%")
        if metrics.evaluation_usage_percent is not None and metrics.evaluation_usage_percent >= 80:
            if self._logger:
                self._logger.warn(f"[FlagKit] Evaluation usage at {metrics.evaluation_usage_percent}%")
        if metrics.subscription_status == "suspended":
            if self._logger:
                self._logger.error("[FlagKit] Subscription suspended - service degraded")

        return metrics

    def _should_retry(self, error: Exception) -> bool:
        """Determine if an error should be retried.

        Args:
            error: The error to check.

        Returns:
            True if the error should be retried.
        """
        # Don't retry circuit open errors
        if isinstance(error, CircuitOpenError):
            return False
        # Don't retry auth errors (key rotation already attempted)
        if isinstance(error, AuthenticationError):
            return False
        # Retry network errors and other FlagKit errors based on recoverable flag
        if isinstance(error, FlagKitError):
            return error.recoverable
        return False

    def get_circuit_state(self) -> str:
        """Get circuit breaker state.

        Returns:
            Circuit state string.
        """
        return self._circuit_breaker.get_state().value

    def reset_circuit(self) -> None:
        """Reset circuit breaker."""
        self._circuit_breaker.reset()

    def close(self) -> None:
        """Close the HTTP client."""
        self._client.close()

    def __enter__(self) -> "HttpClient":
        return self

    def __exit__(self, *_args: Any) -> None:
        self.close()
