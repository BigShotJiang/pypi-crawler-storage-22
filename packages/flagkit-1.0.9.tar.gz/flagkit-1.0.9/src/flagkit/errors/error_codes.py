"""FlagKit SDK error codes.

Based on the error specification at docs/spec/errors.spec.md.
"""

from dataclasses import dataclass
from typing import Literal

# Error categories with their numeric ranges
ErrorCategory = {
    "INIT": 1000,
    "AUTH": 1100,
    "EVAL": 1200,
    "NETWORK": 1300,
    "CACHE": 1400,
    "EVENT": 1500,
    "CONFIG": 1600,
    "SECURITY": 1700,
    "STREAMING": 1800,
    "INTERNAL": 1900,
}


@dataclass(frozen=True)
class ErrorDefinition:
    """Definition of an error code."""

    code: str
    numeric_code: int
    message: str
    recoverable: bool


# All error codes with their numeric values and default messages
ErrorCodes: dict[str, ErrorDefinition] = {
    # Initialization Errors (1000-1099)
    "INIT_FAILED": ErrorDefinition(
        code="INIT_FAILED",
        numeric_code=1000,
        message="SDK initialization failed",
        recoverable=False,
    ),
    "INIT_TIMEOUT": ErrorDefinition(
        code="INIT_TIMEOUT",
        numeric_code=1001,
        message="Initialization timed out",
        recoverable=True,
    ),
    "INIT_INVALID_CONFIG": ErrorDefinition(
        code="INIT_INVALID_CONFIG",
        numeric_code=1002,
        message="Invalid SDK configuration",
        recoverable=False,
    ),
    "INIT_MISSING_API_KEY": ErrorDefinition(
        code="INIT_MISSING_API_KEY",
        numeric_code=1003,
        message="API key is required",
        recoverable=False,
    ),
    "INIT_INVALID_BASE_URL": ErrorDefinition(
        code="INIT_INVALID_BASE_URL",
        numeric_code=1004,
        message="Invalid base URL format",
        recoverable=False,
    ),
    "INIT_ALREADY_INITIALIZED": ErrorDefinition(
        code="INIT_ALREADY_INITIALIZED",
        numeric_code=1005,
        message="SDK already initialized",
        recoverable=False,
    ),
    # Authentication Errors (1100-1199)
    "AUTH_INVALID_KEY": ErrorDefinition(
        code="AUTH_INVALID_KEY",
        numeric_code=1100,
        message="Invalid API key",
        recoverable=False,
    ),
    "AUTH_EXPIRED_KEY": ErrorDefinition(
        code="AUTH_EXPIRED_KEY",
        numeric_code=1101,
        message="API key has expired",
        recoverable=False,
    ),
    "AUTH_REVOKED_KEY": ErrorDefinition(
        code="AUTH_REVOKED_KEY",
        numeric_code=1102,
        message="API key has been revoked",
        recoverable=False,
    ),
    "AUTH_INSUFFICIENT_PERMISSIONS": ErrorDefinition(
        code="AUTH_INSUFFICIENT_PERMISSIONS",
        numeric_code=1103,
        message="API key lacks required permissions",
        recoverable=False,
    ),
    "AUTH_RATE_LIMITED": ErrorDefinition(
        code="AUTH_RATE_LIMITED",
        numeric_code=1104,
        message="Rate limit exceeded",
        recoverable=True,
    ),
    "AUTH_PROJECT_MISMATCH": ErrorDefinition(
        code="AUTH_PROJECT_MISMATCH",
        numeric_code=1105,
        message="API key not valid for this project",
        recoverable=False,
    ),
    "AUTH_ENVIRONMENT_MISMATCH": ErrorDefinition(
        code="AUTH_ENVIRONMENT_MISMATCH",
        numeric_code=1106,
        message="API key not valid for this environment",
        recoverable=False,
    ),
    "AUTH_IP_RESTRICTED": ErrorDefinition(
        code="AUTH_IP_RESTRICTED",
        numeric_code=1107,
        message="IP address not allowed for this API key",
        recoverable=False,
    ),
    "AUTH_ORGANIZATION_REQUIRED": ErrorDefinition(
        code="AUTH_ORGANIZATION_REQUIRED",
        numeric_code=1108,
        message="Organization context missing from token",
        recoverable=False,
    ),
    "AUTH_SUBSCRIPTION_SUSPENDED": ErrorDefinition(
        code="AUTH_SUBSCRIPTION_SUSPENDED",
        numeric_code=1109,
        message="Subscription is suspended",
        recoverable=False,
    ),
    # Evaluation Errors (1200-1299)
    "EVAL_FLAG_NOT_FOUND": ErrorDefinition(
        code="EVAL_FLAG_NOT_FOUND",
        numeric_code=1200,
        message="Flag does not exist",
        recoverable=False,
    ),
    "EVAL_FLAG_DISABLED": ErrorDefinition(
        code="EVAL_FLAG_DISABLED",
        numeric_code=1201,
        message="Flag is disabled",
        recoverable=False,
    ),
    "EVAL_TYPE_MISMATCH": ErrorDefinition(
        code="EVAL_TYPE_MISMATCH",
        numeric_code=1202,
        message="Flag value type mismatch",
        recoverable=False,
    ),
    "EVAL_INVALID_CONTEXT": ErrorDefinition(
        code="EVAL_INVALID_CONTEXT",
        numeric_code=1203,
        message="Invalid evaluation context",
        recoverable=False,
    ),
    "EVAL_RULE_ERROR": ErrorDefinition(
        code="EVAL_RULE_ERROR",
        numeric_code=1204,
        message="Error evaluating targeting rule",
        recoverable=True,
    ),
    "EVAL_SEGMENT_ERROR": ErrorDefinition(
        code="EVAL_SEGMENT_ERROR",
        numeric_code=1205,
        message="Error evaluating segment",
        recoverable=True,
    ),
    "EVAL_DEFAULT_USED": ErrorDefinition(
        code="EVAL_DEFAULT_USED",
        numeric_code=1206,
        message="Using default value",
        recoverable=False,
    ),
    "EVAL_CACHED_VALUE": ErrorDefinition(
        code="EVAL_CACHED_VALUE",
        numeric_code=1207,
        message="Using cached value",
        recoverable=False,
    ),
    "EVAL_STALE_VALUE": ErrorDefinition(
        code="EVAL_STALE_VALUE",
        numeric_code=1208,
        message="Using stale cached value",
        recoverable=False,
    ),
    # Network Errors (1300-1399)
    "NETWORK_ERROR": ErrorDefinition(
        code="NETWORK_ERROR",
        numeric_code=1300,
        message="Network request failed",
        recoverable=True,
    ),
    "NETWORK_TIMEOUT": ErrorDefinition(
        code="NETWORK_TIMEOUT",
        numeric_code=1301,
        message="Request timed out",
        recoverable=True,
    ),
    "NETWORK_DNS_ERROR": ErrorDefinition(
        code="NETWORK_DNS_ERROR",
        numeric_code=1302,
        message="DNS resolution failed",
        recoverable=True,
    ),
    "NETWORK_CONNECTION_REFUSED": ErrorDefinition(
        code="NETWORK_CONNECTION_REFUSED",
        numeric_code=1303,
        message="Connection refused",
        recoverable=True,
    ),
    "NETWORK_SSL_ERROR": ErrorDefinition(
        code="NETWORK_SSL_ERROR",
        numeric_code=1304,
        message="SSL/TLS error",
        recoverable=False,
    ),
    "NETWORK_OFFLINE": ErrorDefinition(
        code="NETWORK_OFFLINE",
        numeric_code=1305,
        message="Device is offline",
        recoverable=True,
    ),
    "NETWORK_SERVER_ERROR": ErrorDefinition(
        code="NETWORK_SERVER_ERROR",
        numeric_code=1306,
        message="Server error",
        recoverable=True,
    ),
    "NETWORK_INVALID_RESPONSE": ErrorDefinition(
        code="NETWORK_INVALID_RESPONSE",
        numeric_code=1307,
        message="Invalid server response",
        recoverable=True,
    ),
    "NETWORK_SERVICE_UNAVAILABLE": ErrorDefinition(
        code="NETWORK_SERVICE_UNAVAILABLE",
        numeric_code=1308,
        message="Service unavailable",
        recoverable=True,
    ),
    # Cache Errors (1400-1499)
    "CACHE_READ_ERROR": ErrorDefinition(
        code="CACHE_READ_ERROR",
        numeric_code=1400,
        message="Failed to read from cache",
        recoverable=True,
    ),
    "CACHE_WRITE_ERROR": ErrorDefinition(
        code="CACHE_WRITE_ERROR",
        numeric_code=1401,
        message="Failed to write to cache",
        recoverable=True,
    ),
    "CACHE_EXPIRED": ErrorDefinition(
        code="CACHE_EXPIRED",
        numeric_code=1402,
        message="Cache has expired",
        recoverable=True,
    ),
    "CACHE_CORRUPT": ErrorDefinition(
        code="CACHE_CORRUPT",
        numeric_code=1403,
        message="Cache data is corrupted",
        recoverable=True,
    ),
    "CACHE_STORAGE_FULL": ErrorDefinition(
        code="CACHE_STORAGE_FULL",
        numeric_code=1404,
        message="Storage quota exceeded",
        recoverable=True,
    ),
    # Event Errors (1500-1599)
    "EVENT_SEND_FAILED": ErrorDefinition(
        code="EVENT_SEND_FAILED",
        numeric_code=1500,
        message="Failed to send event",
        recoverable=True,
    ),
    "EVENT_INVALID_TYPE": ErrorDefinition(
        code="EVENT_INVALID_TYPE",
        numeric_code=1501,
        message="Invalid event type",
        recoverable=False,
    ),
    "EVENT_INVALID_DATA": ErrorDefinition(
        code="EVENT_INVALID_DATA",
        numeric_code=1502,
        message="Invalid event data",
        recoverable=False,
    ),
    "EVENT_QUEUE_FULL": ErrorDefinition(
        code="EVENT_QUEUE_FULL",
        numeric_code=1503,
        message="Event queue is full",
        recoverable=True,
    ),
    "EVENT_BATCH_PARTIAL": ErrorDefinition(
        code="EVENT_BATCH_PARTIAL",
        numeric_code=1504,
        message="Some events failed to send",
        recoverable=True,
    ),
    # Configuration Errors (1600-1699)
    "CONFIG_INVALID_OPTION": ErrorDefinition(
        code="CONFIG_INVALID_OPTION",
        numeric_code=1600,
        message="Invalid configuration option",
        recoverable=False,
    ),
    "CONFIG_MISSING_REQUIRED": ErrorDefinition(
        code="CONFIG_MISSING_REQUIRED",
        numeric_code=1601,
        message="Missing required configuration",
        recoverable=False,
    ),
    "CONFIG_TYPE_ERROR": ErrorDefinition(
        code="CONFIG_TYPE_ERROR",
        numeric_code=1602,
        message="Configuration type mismatch",
        recoverable=False,
    ),
    "CONFIG_DEPRECATED": ErrorDefinition(
        code="CONFIG_DEPRECATED",
        numeric_code=1603,
        message="Configuration option deprecated",
        recoverable=False,
    ),
    # Security Errors (1700-1799)
    "SECURITY_PII_DETECTED": ErrorDefinition(
        code="SECURITY_PII_DETECTED",
        numeric_code=1701,
        message="Potential PII detected without private_attributes",
        recoverable=False,
    ),
    "SECURITY_SIGNATURE_FAILED": ErrorDefinition(
        code="SECURITY_SIGNATURE_FAILED",
        numeric_code=1702,
        message="Request signature generation failed",
        recoverable=True,
    ),
    "SECURITY_ENCRYPTION_FAILED": ErrorDefinition(
        code="SECURITY_ENCRYPTION_FAILED",
        numeric_code=1703,
        message="Cache encryption failed",
        recoverable=True,
    ),
    "SECURITY_DECRYPTION_FAILED": ErrorDefinition(
        code="SECURITY_DECRYPTION_FAILED",
        numeric_code=1704,
        message="Cache decryption failed",
        recoverable=True,
    ),
    "SECURITY_BOOTSTRAP_VERIFICATION_FAILED": ErrorDefinition(
        code="SECURITY_BOOTSTRAP_VERIFICATION_FAILED",
        numeric_code=1705,
        message="Bootstrap signature verification failed",
        recoverable=False,
    ),
    # Streaming Errors (1800-1899)
    "STREAMING_TOKEN_INVALID": ErrorDefinition(
        code="STREAMING_TOKEN_INVALID",
        numeric_code=1800,
        message="Stream token is invalid",
        recoverable=True,
    ),
    "STREAMING_TOKEN_EXPIRED": ErrorDefinition(
        code="STREAMING_TOKEN_EXPIRED",
        numeric_code=1801,
        message="Stream token has expired",
        recoverable=True,
    ),
    "STREAMING_SUBSCRIPTION_SUSPENDED": ErrorDefinition(
        code="STREAMING_SUBSCRIPTION_SUSPENDED",
        numeric_code=1802,
        message="Organization subscription suspended",
        recoverable=False,
    ),
    "STREAMING_CONNECTION_LIMIT": ErrorDefinition(
        code="STREAMING_CONNECTION_LIMIT",
        numeric_code=1803,
        message="Too many concurrent streaming connections",
        recoverable=True,
    ),
    "STREAMING_UNAVAILABLE": ErrorDefinition(
        code="STREAMING_UNAVAILABLE",
        numeric_code=1804,
        message="Streaming service not available",
        recoverable=True,
    ),
    # Internal Errors (1900-1999)
    "INTERNAL_ERROR": ErrorDefinition(
        code="INTERNAL_ERROR",
        numeric_code=1900,
        message="Internal SDK error",
        recoverable=False,
    ),
    "INTERNAL_STATE_ERROR": ErrorDefinition(
        code="INTERNAL_STATE_ERROR",
        numeric_code=1901,
        message="Invalid internal state",
        recoverable=False,
    ),
    "UNKNOWN_ERROR": ErrorDefinition(
        code="UNKNOWN_ERROR",
        numeric_code=1999,
        message="Unknown error occurred",
        recoverable=False,
    ),
}

# Type alias for error codes
ErrorCode = Literal[
    "INIT_FAILED",
    "INIT_TIMEOUT",
    "INIT_INVALID_CONFIG",
    "INIT_MISSING_API_KEY",
    "INIT_INVALID_BASE_URL",
    "INIT_ALREADY_INITIALIZED",
    "AUTH_INVALID_KEY",
    "AUTH_EXPIRED_KEY",
    "AUTH_REVOKED_KEY",
    "AUTH_INSUFFICIENT_PERMISSIONS",
    "AUTH_RATE_LIMITED",
    "AUTH_PROJECT_MISMATCH",
    "AUTH_ENVIRONMENT_MISMATCH",
    "AUTH_IP_RESTRICTED",
    "AUTH_ORGANIZATION_REQUIRED",
    "AUTH_SUBSCRIPTION_SUSPENDED",
    "EVAL_FLAG_NOT_FOUND",
    "EVAL_FLAG_DISABLED",
    "EVAL_TYPE_MISMATCH",
    "EVAL_INVALID_CONTEXT",
    "EVAL_RULE_ERROR",
    "EVAL_SEGMENT_ERROR",
    "EVAL_DEFAULT_USED",
    "EVAL_CACHED_VALUE",
    "EVAL_STALE_VALUE",
    "NETWORK_ERROR",
    "NETWORK_TIMEOUT",
    "NETWORK_DNS_ERROR",
    "NETWORK_CONNECTION_REFUSED",
    "NETWORK_SSL_ERROR",
    "NETWORK_OFFLINE",
    "NETWORK_SERVER_ERROR",
    "NETWORK_INVALID_RESPONSE",
    "NETWORK_SERVICE_UNAVAILABLE",
    "CACHE_READ_ERROR",
    "CACHE_WRITE_ERROR",
    "CACHE_EXPIRED",
    "CACHE_CORRUPT",
    "CACHE_STORAGE_FULL",
    "EVENT_SEND_FAILED",
    "EVENT_INVALID_TYPE",
    "EVENT_INVALID_DATA",
    "EVENT_QUEUE_FULL",
    "EVENT_BATCH_PARTIAL",
    "CONFIG_INVALID_OPTION",
    "CONFIG_MISSING_REQUIRED",
    "CONFIG_TYPE_ERROR",
    "CONFIG_DEPRECATED",
    "SECURITY_PII_DETECTED",
    "SECURITY_SIGNATURE_FAILED",
    "SECURITY_ENCRYPTION_FAILED",
    "SECURITY_DECRYPTION_FAILED",
    "SECURITY_BOOTSTRAP_VERIFICATION_FAILED",
    "STREAMING_TOKEN_INVALID",
    "STREAMING_TOKEN_EXPIRED",
    "STREAMING_SUBSCRIPTION_SUSPENDED",
    "STREAMING_CONNECTION_LIMIT",
    "STREAMING_UNAVAILABLE",
    "INTERNAL_ERROR",
    "INTERNAL_STATE_ERROR",
    "UNKNOWN_ERROR",
]

# Error codes that can be retried
RETRYABLE_ERROR_CODES: list[ErrorCode] = [
    "INIT_TIMEOUT",
    "AUTH_RATE_LIMITED",
    "EVAL_RULE_ERROR",
    "EVAL_SEGMENT_ERROR",
    "NETWORK_ERROR",
    "NETWORK_TIMEOUT",
    "NETWORK_DNS_ERROR",
    "NETWORK_CONNECTION_REFUSED",
    "NETWORK_OFFLINE",
    "NETWORK_SERVER_ERROR",
    "NETWORK_INVALID_RESPONSE",
    "NETWORK_SERVICE_UNAVAILABLE",
    "CACHE_READ_ERROR",
    "CACHE_WRITE_ERROR",
    "CACHE_EXPIRED",
    "CACHE_CORRUPT",
    "CACHE_STORAGE_FULL",
    "EVENT_SEND_FAILED",
    "EVENT_QUEUE_FULL",
    "EVENT_BATCH_PARTIAL",
    "SECURITY_SIGNATURE_FAILED",
    "SECURITY_ENCRYPTION_FAILED",
    "SECURITY_DECRYPTION_FAILED",
    "STREAMING_TOKEN_INVALID",
    "STREAMING_TOKEN_EXPIRED",
    "STREAMING_CONNECTION_LIMIT",
    "STREAMING_UNAVAILABLE",
]


def is_retryable_code(code: ErrorCode) -> bool:
    """Check if an error code is retryable.

    Args:
        code: The error code to check.

    Returns:
        True if the error code is retryable.
    """
    return code in RETRYABLE_ERROR_CODES
