"""FlagKit SDK factory class."""

import threading
from typing import Any, Optional

from flagkit.client import FlagKitClient
from flagkit.errors.flagkit_error import InitializationError
from flagkit.types.config import FlagKitOptions
from flagkit.types.context import EvaluationContext
from flagkit.types.flag import EvaluationResult, FlagValue


class FlagKit:
    """Static factory class for FlagKit SDK.

    Provides singleton pattern for SDK initialization.

    Example:
        >>> client = FlagKit.initialize(api_key="sdk_...")
        >>> client.wait_for_ready()
        >>> dark_mode = client.get_boolean_value("dark-mode", default=False)
    """

    _instance: Optional[FlagKitClient] = None
    _lock = threading.Lock()

    @classmethod
    def initialize(
        cls,
        api_key: str,
        *,
        base_url: str = "https://api.flagkit.dev/api/v1",
        polling_interval: float = 30.0,
        enable_polling: bool = True,
        cache_enabled: bool = True,
        cache_ttl: float = 300.0,
        offline: bool = False,
        timeout: float = 5.0,
        retries: int = 3,
        logger: Any = None,
        bootstrap: Optional[dict[str, Any]] = None,
        debug: bool = False,
        on_ready: Optional[Any] = None,
        on_error: Optional[Any] = None,
        on_update: Optional[Any] = None,
    ) -> FlagKitClient:
        """Initialize the FlagKit SDK.

        Creates a new client instance if one doesn't exist, or returns
        the existing instance (singleton pattern).

        Args:
            api_key: API key for authentication.
            base_url: Base URL for the FlagKit API.
            polling_interval: Polling interval in seconds.
            enable_polling: Whether to enable background polling.
            cache_enabled: Whether to enable caching.
            cache_ttl: Cache time-to-live in seconds.
            offline: Whether to run in offline mode.
            timeout: Request timeout in seconds.
            retries: Number of retry attempts.
            logger: Custom logger instance.
            bootstrap: Initial flag values.
            debug: Enable debug logging.
            on_ready: Callback when SDK is ready.
            on_error: Callback when errors occur.
            on_update: Callback when flags are updated.

        Returns:
            FlagKitClient instance.

        Raises:
            InitializationError: If SDK is already initialized with different options.
        """
        with cls._lock:
            if cls._instance is not None:
                raise InitializationError(
                    "INIT_ALREADY_INITIALIZED",
                    "SDK already initialized. Use FlagKit.get_client() to get the instance.",
                )

            options = FlagKitOptions(
                api_key=api_key,
                base_url=base_url,
                polling_interval=polling_interval,
                enable_polling=enable_polling,
                cache_enabled=cache_enabled,
                cache_ttl=cache_ttl,
                offline=offline,
                timeout=timeout,
                retries=retries,
                logger=logger,
                bootstrap=bootstrap or {},
                debug=debug,
                on_ready=on_ready,
                on_error=on_error,
                on_update=on_update,
            )

            instance = FlagKitClient(options)
            instance.initialize()
            cls._instance = instance
            return instance

    @classmethod
    def get_client(cls) -> FlagKitClient:
        """Get the current SDK client instance.

        Returns:
            FlagKitClient instance.

        Raises:
            InitializationError: If SDK is not initialized.
        """
        with cls._lock:
            if cls._instance is None:
                raise InitializationError(
                    "INIT_FAILED",
                    "SDK not initialized. Call FlagKit.initialize() first.",
                )
            return cls._instance

    @classmethod
    def is_initialized(cls) -> bool:
        """Check if SDK is initialized.

        Returns:
            True if SDK is initialized.
        """
        with cls._lock:
            return cls._instance is not None

    @classmethod
    def close(cls) -> None:
        """Close the SDK and release resources."""
        with cls._lock:
            if cls._instance is not None:
                cls._instance.close()
                cls._instance = None

    @classmethod
    def reset(cls) -> None:
        """Reset the SDK instance (for testing).

        This closes the current instance and allows re-initialization.
        """
        cls.close()

    # Convenience methods that delegate to the client instance

    @classmethod
    def get_boolean_value(
        cls,
        key: str,
        default: bool,
        context: Optional[EvaluationContext] = None,
    ) -> bool:
        """Evaluate a boolean flag.

        Args:
            key: Flag key.
            default: Default value.
            context: Optional evaluation context.

        Returns:
            Flag value or default.
        """
        return cls.get_client().get_boolean_value(key, default, context)

    @classmethod
    def get_string_value(
        cls,
        key: str,
        default: str,
        context: Optional[EvaluationContext] = None,
    ) -> str:
        """Evaluate a string flag.

        Args:
            key: Flag key.
            default: Default value.
            context: Optional evaluation context.

        Returns:
            Flag value or default.
        """
        return cls.get_client().get_string_value(key, default, context)

    @classmethod
    def get_number_value(
        cls,
        key: str,
        default: float,
        context: Optional[EvaluationContext] = None,
    ) -> float:
        """Evaluate a number flag.

        Args:
            key: Flag key.
            default: Default value.
            context: Optional evaluation context.

        Returns:
            Flag value or default.
        """
        return cls.get_client().get_number_value(key, default, context)

    @classmethod
    def get_json_value(
        cls,
        key: str,
        default: dict[str, Any],
        context: Optional[EvaluationContext] = None,
    ) -> dict[str, Any]:
        """Evaluate a JSON flag.

        Args:
            key: Flag key.
            default: Default value.
            context: Optional evaluation context.

        Returns:
            Flag value or default.
        """
        return cls.get_client().get_json_value(key, default, context)

    @classmethod
    def evaluate(
        cls,
        key: str,
        context: Optional[EvaluationContext] = None,
    ) -> EvaluationResult[FlagValue]:
        """Evaluate a flag and return full result.

        Args:
            key: Flag key.
            context: Optional evaluation context.

        Returns:
            Full evaluation result.
        """
        return cls.get_client().evaluate(key, context)

    @classmethod
    def identify(
        cls,
        user_id: str,
        attributes: Optional[dict[str, Any]] = None,
    ) -> None:
        """Identify a user.

        Args:
            user_id: User identifier.
            attributes: Optional user attributes.
        """
        cls.get_client().identify(user_id, attributes)

    @classmethod
    def track(
        cls,
        event_type: str,
        event_data: Optional[dict[str, Any]] = None,
    ) -> None:
        """Track a custom event.

        Args:
            event_type: Type of event.
            event_data: Optional event data.
        """
        cls.get_client().track(event_type, event_data)

    @classmethod
    def flush(cls) -> None:
        """Flush pending events."""
        cls.get_client().flush()
