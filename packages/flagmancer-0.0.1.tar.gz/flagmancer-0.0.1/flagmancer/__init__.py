"""Flagmancer - Autonomous AI Hacking Agent for pentesters and CTF players."""

__version__ = "0.0.1"
