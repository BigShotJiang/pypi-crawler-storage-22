"""flash-eeg: GPU-accelerated EEG preprocessing transforms."""
import torch
from typing import Optional
from functools import lru_cache

__version__ = "0.1.0"
__all__ = ["spectrogram", "morlet", "connectivity", "reshape",
           "Spectrogram", "Morlet", "Connectivity", "Reshape"]

# High-end GPUs that benefit from torch.compile
_COMPILE_GPUS = ("A100", "H100", "H200", "L40", "RTX 4090", "RTX 5090")


def _should_auto_compile() -> bool:
    if not torch.cuda.is_available():
        return False
    name = torch.cuda.get_device_name()
    return any(gpu in name for gpu in _COMPILE_GPUS)


@lru_cache(maxsize=32)
def _get_spectrogram_module(
    sfreq: float, n_fft: int, hop_length: int, freq_min: float, freq_max: float,
    freq_breakpoint: float, n_freqs_out: int, output_size: int, device: str, compile: bool
):
    from .transforms import SpectrogramSTFT
    m = SpectrogramSTFT(
        sfreq=sfreq, n_fft=n_fft, hop_length=hop_length, freq_min=freq_min,
        freq_max=freq_max, freq_breakpoint=freq_breakpoint, n_freqs_out=n_freqs_out,
        target_size=output_size, device=device
    ).to(device)
    if compile:
        m = torch.compile(m, mode="max-autotune")
    return m


@lru_cache(maxsize=32)
def _get_morlet_module(
    sfreq: float, freq_min: float, freq_max: float, n_freqs: int,
    n_samples: int, decim: int, output_size: int, device: str, compile: bool
):
    from .transforms import SpectrogramMorlet
    m = SpectrogramMorlet(
        sfreq=sfreq, freq_min=freq_min, freq_max=freq_max, n_freqs=n_freqs,
        n_samples=n_samples, decim=decim, target_size=output_size, device=device
    ).to(device)
    if compile:
        m = torch.compile(m, mode="max-autotune")
    return m


@lru_cache(maxsize=32)
def _get_connectivity_module(
    sfreq: float, n_channels: int, n_samples: int, n_fft: int,
    NW: float, num_tapers: int, output_size: int, device: str, compile: bool
):
    from .transforms import ConnectivityWPLI
    m = ConnectivityWPLI(
        sfreq=sfreq, n_channels=n_channels, n_samples=n_samples, n_fft=n_fft,
        NW=NW, num_tapers=num_tapers, target_size=output_size, device=device
    ).to(device)
    if compile:
        m = torch.compile(m, mode="max-autotune")
    return m


@lru_cache(maxsize=32)
def _get_reshape_module(
    n_samples: int, n_channels: int, output_size: int, block_size: int, device: str, compile: bool
):
    from .transforms import ReshapeSquare
    m = ReshapeSquare(
        n_samples=n_samples, n_channels=n_channels, target_size=output_size,
        block_size=block_size, device=device
    ).to(device)
    if compile:
        m = torch.compile(m, mode="max-autotune")
    return m


def spectrogram(
    x: torch.Tensor,
    sfreq: float = 250.0,
    n_fft: int = 1024,
    hop_length: int = 128,
    freq_min: float = 1.0,
    freq_max: float = 100.0,
    freq_breakpoint: float = 30.0,
    n_freqs_out: int = 224,
    output_size: int = 224,
    compile: Optional[bool] = None,
) -> torch.Tensor:
    """STFT-based spectrogram transform.

    Args:
        x: Input [B, C, T] on any device
        sfreq: Sampling frequency (Hz)
        n_fft: FFT window size
        hop_length: STFT hop length
        freq_min: Min frequency
        freq_max: Max frequency
        freq_breakpoint: Log-to-linear transition frequency
        n_freqs_out: Frequency bins before resize
        output_size: Output image size (output_size x output_size)
        compile: Use torch.compile (None = auto-detect GPU)

    Returns:
        Spectrogram [B, C, output_size, output_size]
    """
    device = str(x.device)
    if compile is None:
        compile = _should_auto_compile() and "cuda" in device
    m = _get_spectrogram_module(
        sfreq, n_fft, hop_length, freq_min, freq_max, freq_breakpoint,
        n_freqs_out, output_size, device, compile
    )
    with torch.no_grad():
        return m(x)


def morlet(
    x: torch.Tensor,
    sfreq: float = 250.0,
    freq_min: float = 1.0,
    freq_max: float = 100.0,
    n_freqs: int = 50,
    decim: int = 4,
    output_size: int = 224,
    compile: Optional[bool] = None,
) -> torch.Tensor:
    """Morlet wavelet spectrogram transform.

    Args:
        x: Input [B, C, T] on any device
        sfreq: Sampling frequency (Hz)
        freq_min: Min frequency
        freq_max: Max frequency
        n_freqs: Number of frequencies (log-spaced)
        decim: Time decimation factor
        output_size: Output image size
        compile: Use torch.compile (None = auto-detect GPU)

    Returns:
        Spectrogram [B, C, output_size, output_size]
    """
    device = str(x.device)
    n_samples = x.shape[-1]
    if compile is None:
        compile = _should_auto_compile() and "cuda" in device
    m = _get_morlet_module(
        sfreq, freq_min, freq_max, n_freqs, n_samples, decim, output_size, device, compile
    )
    with torch.no_grad():
        return m(x)


def connectivity(
    x: torch.Tensor,
    sfreq: float = 250.0,
    n_fft: int = 512,
    NW: float = 2.0,
    num_tapers: int = 3,
    output_size: int = 224,
    compile: Optional[bool] = None,
) -> torch.Tensor:
    """WPLI connectivity transform.

    Args:
        x: Input [B, C, T] on any device
        sfreq: Sampling frequency (Hz)
        n_fft: FFT size for spectral estimation
        NW: Time-bandwidth product for DPSS tapers
        num_tapers: Number of DPSS tapers
        output_size: Output image size
        compile: Use torch.compile (None = auto-detect GPU)

    Returns:
        Connectivity [B, 1, output_size, output_size]
    """
    device = str(x.device)
    n_channels, n_samples = x.shape[1], x.shape[2]
    if compile is None:
        compile = _should_auto_compile() and "cuda" in device
    m = _get_connectivity_module(
        sfreq, n_channels, n_samples, n_fft, NW, num_tapers, output_size, device, compile
    )
    with torch.no_grad():
        return m(x)


def reshape(
    x: torch.Tensor,
    output_size: int = 224,
    block_size: int = 32,
    compile: Optional[bool] = None,
) -> torch.Tensor:
    """Signal-to-image reshape transform.

    Args:
        x: Input [B, C, T] on any device
        output_size: Output image size
        block_size: Block size for shuffle
        compile: Use torch.compile (None = auto-detect GPU)

    Returns:
        Image [B, C, output_size, output_size]
    """
    device = str(x.device)
    n_channels, n_samples = x.shape[1], x.shape[2]
    if compile is None:
        compile = _should_auto_compile() and "cuda" in device
    m = _get_reshape_module(
        n_samples, n_channels, output_size, block_size, device, compile
    )
    with torch.no_grad():
        return m(x)


# --- Reusable class-based API ---

class Spectrogram:
    """Reusable STFT spectrogram transform."""
    def __init__(self, sfreq=250.0, n_fft=1024, hop_length=128, freq_min=1.0, freq_max=100.0,
                 freq_breakpoint=30.0, n_freqs_out=224, output_size=224, device="cuda", compile=None):
        if compile is None:
            compile = _should_auto_compile() and "cuda" in device
        from .transforms import SpectrogramSTFT
        self._m = SpectrogramSTFT(sfreq=sfreq, n_fft=n_fft, hop_length=hop_length, freq_min=freq_min,
                                   freq_max=freq_max, freq_breakpoint=freq_breakpoint,
                                   n_freqs_out=n_freqs_out, target_size=output_size, device=device).to(device)
        if compile:
            self._m = torch.compile(self._m, mode="max-autotune")

    def __call__(self, x):
        with torch.no_grad():
            return self._m(x)


class Morlet:
    """Reusable Morlet wavelet spectrogram transform."""
    def __init__(self, sfreq=250.0, freq_min=1.0, freq_max=100.0, n_freqs=50,
                 n_samples=7500, decim=4, output_size=224, device="cuda", compile=None):
        if compile is None:
            compile = _should_auto_compile() and "cuda" in device
        from .transforms import SpectrogramMorlet
        self._m = SpectrogramMorlet(sfreq=sfreq, freq_min=freq_min, freq_max=freq_max, n_freqs=n_freqs,
                                     n_samples=n_samples, decim=decim, target_size=output_size, device=device).to(device)
        if compile:
            self._m = torch.compile(self._m, mode="max-autotune")

    def __call__(self, x):
        with torch.no_grad():
            return self._m(x)


class Connectivity:
    """Reusable WPLI connectivity transform."""
    def __init__(self, sfreq=250.0, n_channels=8, n_samples=7500, n_fft=512,
                 NW=2.0, num_tapers=3, output_size=224, device="cuda", compile=None):
        if compile is None:
            compile = _should_auto_compile() and "cuda" in device
        from .transforms import ConnectivityWPLI
        self._m = ConnectivityWPLI(sfreq=sfreq, n_channels=n_channels, n_samples=n_samples, n_fft=n_fft,
                                    NW=NW, num_tapers=num_tapers, target_size=output_size, device=device).to(device)
        if compile:
            self._m = torch.compile(self._m, mode="max-autotune")

    def __call__(self, x):
        with torch.no_grad():
            return self._m(x)


class Reshape:
    """Reusable signal-to-image reshape transform."""
    def __init__(self, n_samples=7500, n_channels=8, output_size=224, block_size=32, device="cuda", compile=None):
        if compile is None:
            compile = _should_auto_compile() and "cuda" in device
        from .transforms import ReshapeSquare
        self._m = ReshapeSquare(n_samples=n_samples, n_channels=n_channels, target_size=output_size,
                                 block_size=block_size, device=device).to(device)
        if compile:
            self._m = torch.compile(self._m, mode="max-autotune")

    def __call__(self, x):
        with torch.no_grad():
            return self._m(x)
