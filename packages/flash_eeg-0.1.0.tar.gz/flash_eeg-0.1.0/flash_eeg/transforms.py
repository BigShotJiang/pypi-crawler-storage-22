"""Internal transform modules. Use flash_eeg.spectrogram/morlet/connectivity/reshape instead."""
import math
import torch
from torch import nn
import torch.nn.functional as F
from scipy.signal import windows


class SpectrogramSTFT(nn.Module):
    def __init__(self, sfreq=250.0, n_fft=1024, hop_length=128, freq_min=1.0, freq_max=100.0,
                 freq_breakpoint=30.0, n_freqs_out=224, target_size=224, device="cuda", dtype=torch.float32):
        super().__init__()
        self.n_fft, self.hop_length, self.n_freqs_out, self.target_size = n_fft, hop_length, n_freqs_out, target_size
        self.register_buffer("window", torch.hann_window(n_fft, device=device, dtype=dtype))

        freq_resolution = sfreq / n_fft
        self.bin_min = int((freq_min / freq_resolution) + 0.999)
        self.bin_max = int(freq_max / freq_resolution)
        self.n_freqs_orig = self.bin_max - self.bin_min + 1

        scaled_positions = torch.linspace(0, 2, n_freqs_out, device=device, dtype=dtype)
        freqs_target = torch.empty_like(scaled_positions)
        mask1 = scaled_positions < 1.0
        if mask1.any():
            log_ratio = torch.log10(torch.tensor(freq_breakpoint / freq_min, device=device, dtype=dtype))
            freqs_target[mask1] = freq_min * torch.pow(10.0, scaled_positions[mask1] * log_ratio)
        mask2 = ~mask1
        if mask2.any():
            freqs_target[mask2] = freq_breakpoint + (scaled_positions[mask2] - 1.0) * (freq_max - freq_breakpoint)

        indices = (freqs_target - freq_min) / (freq_max - freq_min) * (self.n_freqs_orig - 1)
        self.register_buffer("indices_floor", torch.clamp(torch.floor(indices).long(), 0, self.n_freqs_orig - 1))
        self.register_buffer("indices_ceil", torch.clamp(torch.ceil(indices).long(), 0, self.n_freqs_orig - 1))
        self.register_buffer("indices_frac", (indices - self.indices_floor.float()).to(dtype))

    def forward(self, x):
        B, C, T = x.shape
        x_flat = x.reshape(B * C, T)
        stft = torch.stft(x_flat, n_fft=self.n_fft, hop_length=self.hop_length,
                          window=self.window, return_complex=True, center=True, normalized=False)
        spec_db = 10.0 * torch.log10(stft.real.pow(2) + stft.imag.pow(2) + 1e-10)
        spec_db_filtered = spec_db[:, self.bin_min:self.bin_max + 1, :]
        BC, _, T_frames = spec_db_filtered.shape

        spec_db_t = spec_db_filtered.permute(0, 2, 1)
        indices_floor_exp = self.indices_floor.view(1, 1, -1).expand(BC, T_frames, -1)
        indices_ceil_exp = self.indices_ceil.view(1, 1, -1).expand(BC, T_frames, -1)
        frac_exp = self.indices_frac.view(1, 1, -1).expand(BC, T_frames, -1)

        vals_low = torch.gather(spec_db_t, dim=2, index=indices_floor_exp)
        vals_high = torch.gather(spec_db_t, dim=2, index=indices_ceil_exp)
        spec_resampled = ((1 - frac_exp) * vals_low + frac_exp * vals_high).permute(0, 2, 1)
        spec_resampled = spec_resampled.reshape(B, C, self.n_freqs_out, T_frames)

        spec_flat = spec_resampled.reshape(B, C, -1)
        spec_min, spec_max = torch.aminmax(spec_flat, dim=2, keepdim=True)
        spec_min, spec_max = spec_min.unsqueeze(-1), spec_max.unsqueeze(-1)
        spec_norm = (spec_resampled - spec_min) / (spec_max - spec_min + 1e-8)
        return F.interpolate(spec_norm, size=(self.target_size, self.target_size), mode="bilinear", align_corners=False)


class SpectrogramMorlet(nn.Module):
    def __init__(self, sfreq=250.0, freq_min=1.0, freq_max=100.0, n_freqs=50,
                 n_samples=7500, decim=4, target_size=224, device="cuda", dtype=torch.float32):
        super().__init__()
        self.n_freqs, self.decim, self.target_size, self.n_samples = n_freqs, decim, target_size, n_samples

        freqs = torch.logspace(math.log10(freq_min), math.log10(freq_max), n_freqs, device=device, dtype=dtype)
        n_cycles = freqs / 2.0
        fft_freqs = torch.fft.rfftfreq(n_samples, d=1.0/sfreq, device=device).to(dtype)
        sigma_f = freqs / n_cycles
        f_diff = fft_freqs.unsqueeze(0) - freqs.unsqueeze(1)
        wavelets_fft = torch.exp(-0.5 * (f_diff / sigma_f.unsqueeze(1)) ** 2)
        wavelets_fft = wavelets_fft / wavelets_fft.sum(dim=1, keepdim=True)
        self.register_buffer("wavelets_fft", wavelets_fft)

    def forward(self, x):
        B, C, T = x.shape
        x_fft = torch.fft.rfft(x, dim=-1)
        conv_fft = x_fft.unsqueeze(2) * self.wavelets_fft.unsqueeze(0).unsqueeze(0)
        conv = torch.fft.irfft(conv_fft, n=T, dim=-1)
        power = conv ** 2
        power = power[:, :, :, ::self.decim]
        power_db = 10.0 * torch.log10(power + 1e-10)

        flat = power_db.reshape(B, C, -1)
        p_min, p_max = torch.aminmax(flat, dim=2, keepdim=True)
        p_min, p_max = p_min.unsqueeze(-1), p_max.unsqueeze(-1)
        power_norm = (power_db - p_min) / (p_max - p_min + 1e-8)
        return F.interpolate(power_norm, size=(self.target_size, self.target_size), mode="bilinear", align_corners=False)


class ConnectivityWPLI(nn.Module):
    def __init__(self, sfreq=250.0, n_channels=8, n_samples=7500, n_fft=512,
                 NW=2.0, num_tapers=3, target_size=224, device="cuda", dtype=torch.float32):
        super().__init__()
        self.target_size, self.n_channels, self.n_fft = target_size, n_channels, n_fft

        tapers_np = windows.dpss(n_samples, NW, num_tapers, return_ratios=False)
        self.register_buffer("tapers", torch.from_numpy(tapers_np.copy()).to(device=device, dtype=dtype))

        freqs = torch.fft.rfftfreq(n_fft, d=1.0 / sfreq)
        bands = [(1, 4), (4, 8), (8, 13), (13, 30), (30, 60), (60, 100), (1, 40), (1, 100)]
        for i, (fmin, fmax) in enumerate(bands):
            self.register_buffer(f"band_idx_{i}", torch.where((freqs >= fmin) & (freqs <= fmax))[0].to(device))
        self.register_buffer("diag_mask", torch.eye(n_channels, dtype=torch.bool, device=device))

    def _wpli_band(self, csd_imag, band_indices):
        csd_band = torch.index_select(csd_imag, -1, band_indices)
        num = csd_band.mean(dim=-1).abs()
        den = csd_band.abs().mean(dim=-1)
        wpli = num / (den + 1e-10)
        wpli_flat = wpli.reshape(wpli.shape[0], -1)
        wmin, wmax = torch.aminmax(wpli_flat, dim=1, keepdim=True)
        wmin, wmax = wmin.unsqueeze(-1), wmax.unsqueeze(-1)
        return (wpli - wmin) / (wmax - wmin + 1e-8)

    def _combine_bands(self, upper, lower):
        combined = torch.triu(upper.transpose(-2, -1), diagonal=0) + torch.tril(lower, diagonal=-1)
        return torch.where(self.diag_mask.unsqueeze(0), torch.ones_like(combined), combined)

    def forward(self, signal):
        B, C, T = signal.shape
        tapered = signal.unsqueeze(2) * self.tapers.unsqueeze(0).unsqueeze(0)
        fft_result = torch.fft.rfft(tapered, n=self.n_fft, dim=-1)
        csd = (fft_result.unsqueeze(2) * fft_result.unsqueeze(1).conj()).mean(dim=3)
        csd_imag = csd.imag

        w = [self._wpli_band(csd_imag, getattr(self, f"band_idx_{i}")) for i in range(8)]
        c0 = self._combine_bands(w[0], w[1])
        c1 = self._combine_bands(w[2], w[3])
        c2 = self._combine_bands(w[4], w[5])
        c3 = self._combine_bands(w[6], w[7])

        top = torch.cat([c0, c1], dim=2)
        bot = torch.cat([c2, c3], dim=2)
        stacked = torch.cat([top, bot], dim=1).unsqueeze(1)
        return F.interpolate(stacked, size=(self.target_size, self.target_size), mode="nearest")


SHUFFLE_PERM = torch.tensor([4, 1, 6, 0, 3, 5, 2])


class ReshapeSquare(nn.Module):
    def __init__(self, n_samples=7500, n_channels=8, target_size=224, block_size=32, device="cuda"):
        super().__init__()
        self.square_size = int(n_samples ** 0.5)
        self.n_keep = self.square_size ** 2
        self.target_size, self.block_size = target_size, block_size
        self.n_blocks = target_size // block_size
        self.register_buffer("shuffle_perm", SHUFFLE_PERM.to(device))

    def forward(self, x):
        B, C, T = x.shape
        x_sq = x[:, :, :self.n_keep].reshape(B, C, self.square_size, self.square_size)
        x_flat = x_sq.reshape(B, C, -1)
        x_min, x_max = torch.aminmax(x_flat, dim=2, keepdim=True)
        x_min, x_max = x_min.unsqueeze(-1), x_max.unsqueeze(-1)
        x_norm = (x_sq - x_min) / (x_max - x_min + 1e-8)
        x_resized = F.interpolate(x_norm, size=(self.target_size, self.target_size), mode="nearest")
        x_blocks = x_resized.reshape(B, C, self.n_blocks, self.block_size, self.target_size)
        x_shuffled = x_blocks[:, :, self.shuffle_perm, :, :]
        return x_shuffled.reshape(B, C, self.target_size, self.target_size)
