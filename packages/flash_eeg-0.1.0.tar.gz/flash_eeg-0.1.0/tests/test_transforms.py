"""Tests for flash-eeg transforms."""
import pytest
import torch
import flash_eeg as feeg


@pytest.fixture
def sample_input():
    return torch.randn(2, 8, 7500)


class TestFunctionalAPI:
    def test_spectrogram_shape(self, sample_input):
        out = feeg.spectrogram(sample_input, compile=False)
        assert out.shape == (2, 8, 224, 224)

    def test_spectrogram_custom_size(self, sample_input):
        out = feeg.spectrogram(sample_input, output_size=128, compile=False)
        assert out.shape == (2, 8, 128, 128)

    def test_morlet_shape(self, sample_input):
        out = feeg.morlet(sample_input, compile=False)
        assert out.shape == (2, 8, 224, 224)

    def test_morlet_custom_freqs(self, sample_input):
        out = feeg.morlet(sample_input, n_freqs=30, freq_max=50.0, compile=False)
        assert out.shape == (2, 8, 224, 224)

    def test_connectivity_shape(self, sample_input):
        out = feeg.connectivity(sample_input, compile=False)
        assert out.shape == (2, 1, 224, 224)

    def test_reshape_shape(self, sample_input):
        out = feeg.reshape(sample_input, compile=False)
        assert out.shape == (2, 8, 224, 224)


class TestClassAPI:
    def test_spectrogram(self, sample_input):
        spec = feeg.Spectrogram(device='cpu', compile=False)
        out = spec(sample_input)
        assert out.shape == (2, 8, 224, 224)

    def test_morlet(self, sample_input):
        morlet = feeg.Morlet(device='cpu', n_samples=7500, compile=False)
        out = morlet(sample_input)
        assert out.shape == (2, 8, 224, 224)

    def test_connectivity(self, sample_input):
        conn = feeg.Connectivity(device='cpu', n_samples=7500, compile=False)
        out = conn(sample_input)
        assert out.shape == (2, 1, 224, 224)

    def test_reshape(self, sample_input):
        reshape = feeg.Reshape(device='cpu', compile=False)
        out = reshape(sample_input)
        assert out.shape == (2, 8, 224, 224)


class TestOutputRange:
    def test_spectrogram_normalized(self, sample_input):
        out = feeg.spectrogram(sample_input, compile=False)
        assert out.min() >= 0.0
        assert out.max() <= 1.0

    def test_morlet_normalized(self, sample_input):
        out = feeg.morlet(sample_input, compile=False)
        assert out.min() >= 0.0
        assert out.max() <= 1.0

    def test_connectivity_normalized(self, sample_input):
        out = feeg.connectivity(sample_input, compile=False)
        assert out.min() >= 0.0
        assert out.max() <= 1.0


class TestDifferentBatchSizes:
    @pytest.mark.parametrize("batch_size", [1, 4, 16])
    def test_spectrogram_batches(self, batch_size):
        x = torch.randn(batch_size, 8, 7500)
        out = feeg.spectrogram(x, compile=False)
        assert out.shape == (batch_size, 8, 224, 224)

    @pytest.mark.parametrize("batch_size", [1, 4, 16])
    def test_morlet_batches(self, batch_size):
        x = torch.randn(batch_size, 8, 7500)
        out = feeg.morlet(x, compile=False)
        assert out.shape == (batch_size, 8, 224, 224)
