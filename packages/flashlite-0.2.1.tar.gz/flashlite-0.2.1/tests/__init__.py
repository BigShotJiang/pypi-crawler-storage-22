"""Tests for flashlite."""
