# FlashSketch

# Install

`pip install flashsketch`

