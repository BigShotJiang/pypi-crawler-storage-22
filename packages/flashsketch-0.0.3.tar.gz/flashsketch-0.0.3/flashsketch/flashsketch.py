def sketch():
    print("This is flashsketch!")
