from setuptools import setup, find_packages
from pathlib import Path


this_dir = Path(__file__).parent
readme = (
    (this_dir / "README.md").read_text(encoding="utf8")
    if (this_dir / "README.md").exists()
    else ""
)


setup(
    name="flashsketch",
    version="0.0.3",
    description="FlashSketch",
    long_description=readme,
    long_description_content_type="text/markdown",
    author="rajatvd",
    author_email="rajatvd@gmail.com",
    url="",
    packages=find_packages(),
    python_requires=">=3.9",
    install_requires=[
        "gitbud",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3 :: Only",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
