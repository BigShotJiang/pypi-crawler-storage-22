"""Extended SQLAlchemy + SQL Server guide for flask-exp users.

This guide is focused on practical SQLAlchemy usage with `sessionmaker`, including SQL Server
connectivity via `pyodbc`.

Sections
--------
1) Why `sessionmaker`
2) Canonical setup
3) CRUD patterns
4) SQL Server setup
5) Flask integration patterns
6) Common pitfalls

1) Why `sessionmaker`
---------------------
`sessionmaker` creates sessions with consistent configuration.

Benefits:
- one central session configuration;
- predictable transaction behavior;
- easier test and environment setup;
- safer integration into request lifecycle.

Canonical pattern:

    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker

    engine = create_engine("sqlite:///app.db", echo=False, pool_pre_ping=True)
    SessionLocal = sessionmaker(
        bind=engine,
        autoflush=False,
        autocommit=False,
        expire_on_commit=False,
    )

2) Canonical model setup
------------------------

    from sqlalchemy import String
    from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

    class Base(DeclarativeBase):
        pass

    class User(Base):
        __tablename__ = "users"
        id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
        email: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
        name: Mapped[str] = mapped_column(String(255), nullable=False)

Always call:
    Base.metadata.create_all(engine)

3) CRUD patterns with explicit session lifecycle
------------------------------------------------

Create:

    session = SessionLocal()
    try:
        user = User(email="anna@example.com", name="Anna")
        session.add(user)
        session.commit()
        session.refresh(user)
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()

Read:

    session = SessionLocal()
    try:
        rows = session.query(User).all()
        item = session.get(User, 1)
    finally:
        session.close()

Update/Delete follow the same pattern:
- mutate entity;
- commit;
- rollback on error;
- close in finally.

4) SQL Server with `pyodbc`
---------------------------
System prerequisites on macOS:

    brew install unixodbc
    brew tap microsoft/mssql-release https://github.com/Microsoft/homebrew-mssql-release
    HOMEBREW_ACCEPT_EULA=Y brew install msodbcsql18 mssql-tools18

Username/password connection string:

    from urllib.parse import quote_plus
    from sqlalchemy import create_engine

    params = quote_plus(
        "DRIVER={ODBC Driver 18 for SQL Server};"
        "SERVER=localhost,1433;"
        "DATABASE=my_db;"
        "UID=sa;"
        "PWD=StrongPassword!;"
        "Encrypt=yes;"
        "TrustServerCertificate=yes;"
    )

    engine = create_engine(
        f"mssql+pyodbc:///?odbc_connect={params}",
        pool_pre_ping=True,
        fast_executemany=True,
    )

Then create session factory from that engine.

5) Flask integration patterns
-----------------------------
Recommended request lifecycle:
- open session in `before_request`;
- use it inside handlers via `g.db`;
- rollback/close in `teardown_request`.

When using flask-exp:
- `exp.exports.import_to_model(..., session=g.db)` for request-scoped imports;
- `exp.create_crud_routes(...)` currently accepts a session object directly.

6) Common pitfalls
------------------
- Driver not found:
  verify `ODBC Driver 18 for SQL Server` installation.
- Login timeout:
  validate server/port/firewall.
- TLS issues:
  use `TrustServerCertificate=yes` only for local/dev.
- DetachedInstanceError:
  avoid using ORM entities after session close unless serialized.
- Hidden transaction leaks:
  always use `try/except/finally` with rollback on failure.

Operational checklist:
- [ ] test connection with a minimal SELECT;
- [ ] verify session close on every request;
- [ ] monitor DB pool and timeout metrics;
- [ ] run integration tests against target DB engine.
"""

SQLALCHEMY_GUIDE = __doc__ or ""
