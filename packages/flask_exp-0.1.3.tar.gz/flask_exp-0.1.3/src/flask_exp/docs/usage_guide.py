"""Extended usage guide for flask-exp.

This guide explains what flask-exp is, why it exists, and how to use each feature in real projects.
It is intentionally verbose and written as an in-code reference so it can be opened directly from VS Code.

Sections
--------
1) What flask-exp solves
2) Installation and quick start
3) Core API (`FlaskExp`)
4) Data import (`exp.exports.import_to_model`)
5) Auto CRUD route generation
6) Error handling strategy
7) Production recommendations
8) Practical rollout checklist

1) What flask-exp solves
------------------------
Typical Flask projects repeat many patterns:
- health endpoint implementation;
- converting dict payloads into JSON responses;
- repetitive CRUD route wiring;
- loading tabular files into SQLAlchemy models.

flask-exp provides a compact extension API that removes this repeated boilerplate.

2) Installation and quick start
-------------------------------
Install:
    pip install flask-exp

Minimal app:

    from flask import Flask
    from flask_exp import FlaskExp

    app = Flask(__name__)
    exp = FlaskExp(app)

    @exp.route_with_json(app, "/info")
    def info():
        return {"service": "demo", "status": "running"}

After startup you get:
- GET /health
- GET /info

3) Core API (`FlaskExp`)
------------------------
Constructor:
    FlaskExp(app: Flask | None = None, *, health_endpoint: str = "/health")

Key methods:
- init_app(app): delayed extension initialization;
- json_response(payload, status_code=200): consistent JSON response helper;
- route_with_json(app, rule, **options): auto-converts dict return value to JSON;
- create_crud_routes(app, model, session, ...): registers CRUD endpoints.

Notes:
- For factory pattern, prefer `exp = FlaskExp(); exp.init_app(app)`.
- Health endpoint can be customized via `health_endpoint`.

4) Data import (CSV/XLSX -> SQLAlchemy)
---------------------------------------
Method:
    exp.exports.import_to_model(
        file_path=..., model=..., mapping=..., session=...,
        strict=True, dry_run=False, commit=True, encoding="utf-8-sig"
    )

Parameters explained:
- file_path: path to `.csv` or `.xlsx`;
- model: SQLAlchemy model class;
- mapping: explicit map `{ "Header Name": "model_field" }`;
- session: SQLAlchemy session instance;
- strict:
    True  -> fail-fast on first broken row;
    False -> collect row-level errors and continue;
- dry_run: validates import logic without writing to DB;
- commit: toggles final transaction commit;
- encoding: CSV encoding.

Return object: ImportReport
- created: imported rows count;
- failed: rows with errors;
- skipped: skipped rows count;
- dry_run: whether run was dry run;
- errors: details (`row_number`, `error`, `row`, `payload`).

Recommended flow:
1. run with dry_run=True and strict=False;
2. inspect report.errors;
3. fix source file / mapping;
4. run real import.

5) Auto CRUD route generation
-----------------------------
Method:
    routes = exp.create_crud_routes(app, User, db_session)

Default routes for model with `__tablename__ = "users"`:
- POST   /users
- GET    /users
- GET    /users/<item_id>
- PUT    /users/<item_id>
- PATCH  /users/<item_id>
- DELETE /users/<item_id>

Customization:
- base_route="/api/v1/users"
- endpoint_prefix="api_v1_users"

Current limitation:
- one primary key model is supported.

6) Error handling strategy
--------------------------
Import errors:
- missing headers in file mapping -> ValueError;
- unknown model fields in mapping -> ValueError;
- unsupported format -> ValueError;
- DB integrity errors -> row errors (strict=False) or fail-fast (strict=True).

CRUD errors:
- invalid JSON body -> 400;
- missing entity -> 404;
- commit error -> 400 with rollback.

7) Production recommendations
-----------------------------
- secure all CRUD and import endpoints with auth;
- prefer request-scoped SQLAlchemy sessions;
- avoid exposing raw DB error messages in public APIs;
- run import in dry-run mode before real import;
- log and archive import reports for auditability.

8) Practical rollout checklist
------------------------------
- [ ] pin package version in deployment;
- [ ] add tests for CRUD routes generated from each model;
- [ ] add tests for file import mappings;
- [ ] verify health endpoint in liveness checks;
- [ ] verify DB session lifecycle (open/close/rollback) per request.
"""

USAGE_GUIDE = __doc__ or ""
