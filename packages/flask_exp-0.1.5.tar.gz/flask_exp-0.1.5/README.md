# flask-exp

`flask-exp` — это библиотека, расширяющая возможности Flask.

Она добавляет полезные функции, которые ускоряют разработку:
- автоматический health-check endpoint;
- удобные JSON-ответы;
- декоратор для маршрутов, автоматически конвертирующий `dict` в JSON.
- импорт данных из `CSV/XLSX` в SQLAlchemy-модели по явному сопоставлению заголовков.
- автогенерацию CRUD API-роутов по SQLAlchemy-модели.

## Установка

```bash
pip install flask-exp
```

Подробная документация по использованию (Python doc file): [src/flask_exp/docs/usage_guide.py](src/flask_exp/docs/usage_guide.py)
Шпаргалка по SQLAlchemy и SQL Server (Python doc file): [src/flask_exp/docs/sqlalchemy_guide.py](src/flask_exp/docs/sqlalchemy_guide.py)
Шпаргалка по обычному REST CRUD + SQLAlchemy: [src/flask_exp/docs/rest_crud_sqlalchemy_guide.py](src/flask_exp/docs/rest_crud_sqlalchemy_guide.py)

## Быстрый старт

```python
from flask import Flask
from flask_exp import FlaskExp

app = Flask(__name__)
exp = FlaskExp(app)


@exp.route_with_json(app, "/info")
def info():
    return {"service": "demo", "status": "running"}


if __name__ == "__main__":
    app.run(debug=True)
```

После запуска:
- `GET /health` вернёт служебный статус;
- `GET /info` вернёт JSON.

## Импорт CSV/XLSX в SQLAlchemy

Пользователь задаёт явное сопоставление `заголовок -> поле модели`.

```python
from flask import Flask
from flask_exp import FlaskExp

app = Flask(__name__)
exp = FlaskExp(app)

report = exp.exports.import_to_model(
    file_path="users.csv",  # или users.xlsx
    model=User,
    mapping={
        "Email": "email",
        "Full Name": "name",
    },
    session=db_session,
    strict=False,  # True: остановка на первой ошибке
)

print(report.created, report.failed, report.errors)
```

## Авто-CRUD API по модели

Можно сгенерировать полный CRUD по SQLAlchemy-модели одной командой.

```python
routes = exp.create_crud_routes(app, User, db_session)
```

По умолчанию для модели `User` с `__tablename__ = "users"` создаются маршруты:
- `POST /users` — create
- `GET /users` — list
- `GET /users/<item_id>` — get by id
- `PUT /users/<item_id>` и `PATCH /users/<item_id>` — update
- `DELETE /users/<item_id>` — delete

Можно переопределить базовый путь:

```python
exp.create_crud_routes(app, User, db_session, base_route="/api/users")
```

## Разработка

```bash
poetry install
poetry run pytest
```

## Публикация в PyPI

```bash
poetry build
poetry publish
```

Для публикации через токен:

```bash
poetry config pypi-token.pypi <YOUR_PYPI_TOKEN>
poetry publish --build
```
