# SQLAlchemy docs moved to Python module

Подробная SQLAlchemy + SQL Server документация перенесена в Python-файл:

- [src/flask_exp/docs/sqlalchemy_guide.py](src/flask_exp/docs/sqlalchemy_guide.py)

Плюсы нового подхода:
- документация хранится рядом с кодом библиотеки;
- удобно открывать через Cmd+Click в VS Code;
- текст попадает в wheel как часть пакета.
