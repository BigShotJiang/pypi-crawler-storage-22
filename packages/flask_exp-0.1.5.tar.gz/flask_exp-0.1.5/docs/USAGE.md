# Usage docs moved to Python module

Основной подробный документ перенесён в Python-файл:

- [src/flask_exp/docs/usage_guide.py](../src/flask_exp/docs/usage_guide.py)

Почему так:
- документация теперь живёт рядом с кодом пакета;
- удобно открывать через Cmd+Click из VS Code;
- текст включается в wheel как часть самого пакета.
