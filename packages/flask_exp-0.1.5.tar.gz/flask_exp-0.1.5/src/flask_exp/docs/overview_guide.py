"""Обзор flask-exp: README в формате Python-документа.

Что это
-------
`flask-exp` — библиотека, расширяющая Flask для ускоренной разработки API.

Что входит
----------
- автоматический health-check endpoint;
- helper для JSON-ответов;
- декоратор маршрутов с автоконвертацией `dict` в JSON;
- импорт CSV/XLSX в SQLAlchemy по явному mapping;
- автоматическая генерация CRUD API по SQLAlchemy-модели.

Установка
---------

    pip install flask-exp

Быстрый старт
-------------

    from flask import Flask
    from flask_exp import FlaskExp

    app = Flask(__name__)
    exp = FlaskExp(app)

    @exp.route_with_json(app, "/info")
    def info():
        return {"service": "demo", "status": "running"}

После запуска:
- GET /health
- GET /info

Импорт данных
-------------

    report = exp.exports.import_to_model(
        file_path="users.csv",
        model=User,
        mapping={
            "Email": "email",
            "Full Name": "name",
        },
        session=db_session,
        strict=False,
    )

Auto-CRUD
---------

    routes = exp.create_crud_routes(app, User, db_session)

Для модели `User` с `__tablename__ = "users"` по умолчанию:
- POST /users
- GET /users
- GET /users/<item_id>
- PUT/PATCH /users/<item_id>
- DELETE /users/<item_id>

Разработка
----------

    poetry install
    poetry run pytest

Публикация
----------

    poetry build
    poetry publish

Для токена:

    poetry config pypi-token.pypi <YOUR_PYPI_TOKEN>
    poetry publish --build

Где подробная документация
--------------------------
- Полный гайд по использованию: `src/flask_exp/docs/usage_guide.py`
- Шпаргалка по SQLAlchemy + SQL Server: `src/flask_exp/docs/sqlalchemy_guide.py`
"""

OVERVIEW_GUIDE = __doc__ or ""
