"""Шпаргалка: обычный CRUD через REST API на Flask + SQLAlchemy.

Назначение
----------
Этот документ показывает классический (ручной) CRUD-подход без автогенерации роутов.
Подходит, когда нужен полный контроль над валидацией, ответами и бизнес-логикой.

Что получим
-----------
Роуты для сущности `User`:
- POST   /api/users         -> create
- GET    /api/users         -> list
- GET    /api/users/<id>    -> read one
- PUT    /api/users/<id>    -> full update
- PATCH  /api/users/<id>    -> partial update
- DELETE /api/users/<id>    -> delete

1) База: engine, sessionmaker, модель
-------------------------------------

    from flask import Flask, g, request, jsonify
    from sqlalchemy import String, create_engine
    from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker

    app = Flask(__name__)

    engine = create_engine("sqlite:///app.db", echo=False, pool_pre_ping=True)
    SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, expire_on_commit=False)

    class Base(DeclarativeBase):
        pass

    class User(Base):
        __tablename__ = "users"

        id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
        email: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
        name: Mapped[str] = mapped_column(String(255), nullable=False)

    Base.metadata.create_all(engine)

2) Жизненный цикл сессии на запрос
----------------------------------

    @app.before_request
    def open_session():
        g.db = SessionLocal()


    @app.teardown_request
    def close_session(exc):
        db = getattr(g, "db", None)
        if db is None:
            return
        if exc:
            db.rollback()
        db.close()

Почему это важно:
- нет утечек соединений;
- rollback при исключении;
- каждый запрос изолирован в своей сессии.

3) Вспомогательные функции
--------------------------

    def user_to_dict(user: User) -> dict:
        return {"id": user.id, "email": user.email, "name": user.name}


    def require_json_object(payload):
        if not isinstance(payload, dict):
            return jsonify({"error": "JSON body must be an object"}), 400
        return None

4) CREATE (POST /api/users)
---------------------------

    @app.post("/api/users")
    def create_user():
        payload = request.get_json(silent=True)
        bad = require_json_object(payload)
        if bad:
            return bad

        email = payload.get("email")
        name = payload.get("name")
        if not email or not name:
            return jsonify({"error": "email and name are required"}), 400

        user = User(email=email, name=name)

        try:
            g.db.add(user)
            g.db.commit()
            g.db.refresh(user)
        except Exception as exc:
            g.db.rollback()
            return jsonify({"error": str(exc)}), 400

        return jsonify(user_to_dict(user)), 201

5) LIST (GET /api/users)
-------------------------

    @app.get("/api/users")
    def list_users():
        users = g.db.query(User).all()
        return jsonify({"items": [user_to_dict(u) for u in users]})

6) READ ONE (GET /api/users/<id>)
---------------------------------

    @app.get("/api/users/<int:user_id>")
    def get_user(user_id: int):
        user = g.db.get(User, user_id)
        if user is None:
            return jsonify({"error": "Not found"}), 404
        return jsonify(user_to_dict(user))

7) UPDATE FULL (PUT /api/users/<id>)
------------------------------------

    @app.put("/api/users/<int:user_id>")
    def update_user(user_id: int):
        payload = request.get_json(silent=True)
        bad = require_json_object(payload)
        if bad:
            return bad

        user = g.db.get(User, user_id)
        if user is None:
            return jsonify({"error": "Not found"}), 404

        email = payload.get("email")
        name = payload.get("name")
        if not email or not name:
            return jsonify({"error": "email and name are required"}), 400

        user.email = email
        user.name = name

        try:
            g.db.commit()
        except Exception as exc:
            g.db.rollback()
            return jsonify({"error": str(exc)}), 400

        return jsonify(user_to_dict(user))

8) UPDATE PARTIAL (PATCH /api/users/<id>)
-----------------------------------------

    @app.patch("/api/users/<int:user_id>")
    def patch_user(user_id: int):
        payload = request.get_json(silent=True)
        bad = require_json_object(payload)
        if bad:
            return bad

        user = g.db.get(User, user_id)
        if user is None:
            return jsonify({"error": "Not found"}), 404

        if "email" in payload:
            user.email = payload["email"]
        if "name" in payload:
            user.name = payload["name"]

        try:
            g.db.commit()
        except Exception as exc:
            g.db.rollback()
            return jsonify({"error": str(exc)}), 400

        return jsonify(user_to_dict(user))

9) DELETE (DELETE /api/users/<id>)
----------------------------------

    @app.delete("/api/users/<int:user_id>")
    def delete_user(user_id: int):
        user = g.db.get(User, user_id)
        if user is None:
            return jsonify({"error": "Not found"}), 404

        g.db.delete(user)
        g.db.commit()
        return jsonify({"status": "deleted"})

10) Минимальный запуск
----------------------

    if __name__ == "__main__":
        app.run(debug=True)

11) Быстрый smoke-тест через curl
---------------------------------

Create:

    curl -X POST http://127.0.0.1:5000/api/users \
      -H "Content-Type: application/json" \
      -d '{"email":"anna@example.com","name":"Anna"}'

List:

    curl http://127.0.0.1:5000/api/users

Get:

    curl http://127.0.0.1:5000/api/users/1

Put:

    curl -X PUT http://127.0.0.1:5000/api/users/1 \
      -H "Content-Type: application/json" \
      -d '{"email":"anna2@example.com","name":"Anna 2"}'

Patch:

    curl -X PATCH http://127.0.0.1:5000/api/users/1 \
      -H "Content-Type: application/json" \
      -d '{"name":"Anna Patched"}'

Delete:

    curl -X DELETE http://127.0.0.1:5000/api/users/1

12) Рекомендации для продакшена
--------------------------------
- добавьте авторизацию и проверку прав доступа;
- не возвращайте наружу "сырые" ошибки БД;
- используйте схемы валидации (Pydantic/Marshmallow);
- вынесите бизнес-логику в сервисный слой;
- добавьте пагинацию и фильтры для list-эндпоинта.
"""

REST_CRUD_SQLALCHEMY_GUIDE = __doc__ or ""
