"""SQLAlchemy + SQL Server: подробная русскоязычная шпаргалка для flask-exp.

Цель документа
--------------
Дать практический шаблон работы с SQLAlchemy через `sessionmaker`, а также
пошаговую схему подключения к Microsoft SQL Server через `pyodbc`.

Почему `sessionmaker` — базовый паттерн
---------------------------------------
`sessionmaker` создаёт фабрику сессий с едиными настройками.
Это удобнее и безопаснее, чем создавать `Session(engine)` вразнобой по коду.

Плюсы:
- единая точка настройки транзакционного поведения;
- проще управлять жизненным циклом сессий;
- удобнее писать тесты;
- проще интегрировать в request lifecycle Flask.

Базовая настройка
-----------------

    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker

    engine = create_engine("sqlite:///app.db", echo=False, pool_pre_ping=True)
    SessionLocal = sessionmaker(
        bind=engine,
        autoflush=False,
        autocommit=False,
        expire_on_commit=False,
    )

Модель и метаданные
-------------------

    from sqlalchemy import String
    from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

    class Base(DeclarativeBase):
        pass

    class User(Base):
        __tablename__ = "users"

        id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
        email: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
        name: Mapped[str] = mapped_column(String(255), nullable=False)

    Base.metadata.create_all(engine)

Шаблон жизненного цикла сессии
------------------------------

    session = SessionLocal()
    try:
        # database operations
        ...
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()

CRUD примеры
------------

Create:

    session = SessionLocal()
    try:
        user = User(email="anna@example.com", name="Anna")
        session.add(user)
        session.commit()
        session.refresh(user)
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()

Read:

    session = SessionLocal()
    try:
        users = session.query(User).all()
        one = session.get(User, 1)
    finally:
        session.close()

Update:

    session = SessionLocal()
    try:
        user = session.get(User, 1)
        if user is not None:
            user.name = "Anna Updated"
            session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()

Delete:

    session = SessionLocal()
    try:
        user = session.get(User, 1)
        if user is not None:
            session.delete(user)
            session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()

SQL Server через pyodbc
-----------------------
Системные зависимости на macOS:

    brew install unixodbc
    brew tap microsoft/mssql-release https://github.com/Microsoft/homebrew-mssql-release
    HOMEBREW_ACCEPT_EULA=Y brew install msodbcsql18 mssql-tools18

Подключение по логину/паролю:

    from urllib.parse import quote_plus
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker

    params = quote_plus(
        "DRIVER={ODBC Driver 18 for SQL Server};"
        "SERVER=localhost,1433;"
        "DATABASE=my_db;"
        "UID=sa;"
        "PWD=StrongPassword!;"
        "Encrypt=yes;"
        "TrustServerCertificate=yes;"
    )

    engine = create_engine(
        f"mssql+pyodbc:///?odbc_connect={params}",
        pool_pre_ping=True,
        fast_executemany=True,
    )
    SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, expire_on_commit=False)

Trusted connection (где применимо):

    params = quote_plus(
        "DRIVER={ODBC Driver 18 for SQL Server};"
        "SERVER=localhost;"
        "DATABASE=my_db;"
        "Trusted_Connection=yes;"
        "Encrypt=yes;"
        "TrustServerCertificate=yes;"
    )
    engine = create_engine(f"mssql+pyodbc:///?odbc_connect={params}")

Интеграция с flask-exp
----------------------
1) Для импорта CSV/XLSX:

    report = exp.exports.import_to_model(
        file_path="users.xlsx",
        model=User,
        mapping={"Email": "email", "Full Name": "name"},
        session=db_session,
        strict=False,
    )

2) Для auto-CRUD:

    exp.create_crud_routes(app, User, db_session, base_route="/api/users")

Тонкости и ограничения
----------------------
- auto-CRUD в текущей реализации принимает объект session;
- для production лучше request-scoped сессии или обёртка-провайдер;
- не используйте ORM-объекты после закрытия сессии без сериализации.

Частые проблемы
---------------
1. Driver not found
   Проверьте установку `msodbcsql18` и имя драйвера в DSN строке.

2. Login timeout expired
   Проверьте host/port, доступность сервера и firewall.

3. TLS/SSL ошибки
   В dev часто помогает `TrustServerCertificate=yes`.
   В production используйте корректные сертификаты и строгие настройки.

4. Ошибка установки pyodbc
   Обычно отсутствует `unixodbc`.

Чеклист внедрения
-----------------
- [ ] установить ODBC-драйверы;
- [ ] проверить подключение простым запросом;
- [ ] настроить SessionLocal;
- [ ] описать модели и создать таблицы;
- [ ] подключить FlaskExp;
- [ ] добавить auto-CRUD;
- [ ] протестировать импорт CSV/XLSX;
- [ ] добавить интеграционные тесты.
"""

SQLALCHEMY_GUIDE = __doc__ or ""
