"""Подробная документация по использованию flask-exp (на русском).

Назначение
----------
`flask-exp` — это библиотека-расширение для Flask, которая убирает повторяющийся
служебный код в API-проектах. Она закрывает типовые задачи:

- health-check endpoint;
- единообразные JSON-ответы;
- удобная регистрация роутов, возвращающих dict;
- импорт CSV/XLSX в SQLAlchemy-модели по явному mapping;
- автоматическая генерация CRUD-роутов по модели.

Кому полезно
------------
- командам, где много CRUD-сущностей;
- внутренним сервисам и админ-панелям;
- MVP/прототипам, где важна скорость;
- проектам с регулярными загрузками данных из Excel/CSV.

Установка
---------

        pip install flask-exp

Быстрый старт
-------------

        from flask import Flask
        from flask_exp import FlaskExp

        app = Flask(__name__)
        exp = FlaskExp(app)

        @exp.route_with_json(app, "/info")
        def info():
                return {"service": "demo", "status": "running"}

После запуска доступны:
- GET /health
- GET /info

Архитектура
-----------
Основные сущности библиотеки:

1) FlaskExp
     Главный объект расширения. Отвечает за init_app, health, JSON helper,
     автоконвертацию dict в JSON и auto-CRUD.

2) Exports
     Модуль импорта табличных файлов (CSV/XLSX) в SQLAlchemy-модель.

3) ImportReport
     Структура результата импорта: сколько создано, сколько ошибок,
     какие строки не прошли и почему.

API FlaskExp
------------

Инициализация:

        exp = FlaskExp(app, health_endpoint="/health")

Либо отложенно:

        exp = FlaskExp()
        exp.init_app(app)

json_response:

        return exp.json_response({"message": "created"}, 201)

route_with_json:

        @exp.route_with_json(app, "/status")
        def status():
                return {"ok": True}

Если функция возвращает dict, библиотека сама делает JSON-ответ.
Если возвращается Response/tuple/string — поведение остаётся штатным Flask.

Импорт CSV/XLSX в SQLAlchemy
----------------------------
Метод:

        report = exp.exports.import_to_model(
                file_path="users.xlsx",
                model=User,
                mapping={"Email": "email", "Full Name": "name"},
                session=db_session,
                strict=False,
                dry_run=False,
                commit=True,
                encoding="utf-8-sig",
        )

Параметры подробно:
- file_path
    Путь к файлу (`.csv` или `.xlsx`).
- model
    SQLAlchemy-модель, в которую создаются объекты.
- mapping
    Явное сопоставление заголовков файла и полей модели:
    `{ "Header": "model_field" }`.
- session
    SQLAlchemy Session.
- strict
    True: останавливать импорт на первой ошибке.
    False: продолжать импорт и собирать ошибки по строкам.
- dry_run
    True: валидация без записи данных в БД.
- commit
    True: вызвать commit в конце.
    False: транзакцией управляет внешний код.
- encoding
    Кодировка CSV.

Возвращаемый отчёт ImportReport:
- created
- failed
- skipped
- dry_run
- errors (подробности по каждой строке)

Рекомендуемый безопасный процесс:
1. `dry_run=True`, `strict=False`;
2. анализ `report.errors`;
3. исправление файла или mapping;
4. повторный запуск уже с реальной записью.

Auto CRUD API
-------------
Метод:

        routes = exp.create_crud_routes(app, User, db_session)

По умолчанию для `__tablename__ = "users"` создаются:
- POST /users
- GET /users
- GET /users/<item_id>
- PUT /users/<item_id>
- PATCH /users/<item_id>
- DELETE /users/<item_id>

Настройки:

        exp.create_crud_routes(
                app,
                User,
                db_session,
                base_route="/api/v1/users",
                endpoint_prefix="api_v1_users",
        )

Текущее ограничение:
- поддерживается модель с одним primary key.

Ошибки и диагностика
--------------------
Импорт:
- `Headers not found in file`
    В mapping есть колонки, которых нет в файле.
- `Model fields not found`
    В mapping указаны несуществующие поля модели.
- `Only .csv and .xlsx files are supported`
    Неподдерживаемый формат.

CRUD:
- 400 `JSON body must be an object`
- 404 `Not found`
- ошибки DB constraints при commit.

Практические рекомендации (production)
--------------------------------------
- закрывайте CRUD и импорт авторизацией;
- используйте request-scoped SQLAlchemy sessions;
- не отдавайте «сырые» ошибки БД наружу в публичном API;
- логируйте результаты импорта и храните отчёты;
- добавьте автотесты для каждого auto-CRUD сценария.

Мини-чеклист запуска
--------------------
- [ ] подключён FlaskExp;
- [ ] health endpoint проверен;
- [ ] mapping для импорта протестирован в dry_run;
- [ ] CRUD роуты покрыты smoke-тестами;
- [ ] версия пакета зафиксирована в окружении.
"""

USAGE_GUIDE = __doc__ or ""
