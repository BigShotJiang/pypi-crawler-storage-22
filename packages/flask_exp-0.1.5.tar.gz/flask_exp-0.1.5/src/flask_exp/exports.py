from __future__ import annotations

import csv
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable

from openpyxl import load_workbook


@dataclass
class ImportReport:
    created: int = 0
    failed: int = 0
    skipped: int = 0
    dry_run: bool = False
    errors: list[dict[str, Any]] = field(default_factory=list)


class Exports:
    def import_to_model(
        self,
        *,
        file_path: str | Path,
        model: type,
        mapping: dict[str, str],
        session,
        strict: bool = True,
        dry_run: bool = False,
        commit: bool = True,
        encoding: str = "utf-8-sig",
    ) -> ImportReport:
        path = Path(file_path)
        headers, rows = self._read_rows(path, encoding=encoding)
        self._validate_mapping(headers=headers, model=model, mapping=mapping)

        report = ImportReport(dry_run=dry_run)

        for row_number, row in rows:
            payload = {model_field: row.get(source_header) for source_header, model_field in mapping.items()}
            try:
                if dry_run:
                    model(**payload)
                else:
                    with session.begin_nested():
                        instance = model(**payload)
                        session.add(instance)
                        session.flush()
                report.created += 1
            except Exception as exc:
                report.failed += 1
                report.skipped += 1
                report.errors.append(
                    {
                        "row_number": row_number,
                        "error": str(exc),
                        "row": row,
                        "payload": payload,
                    }
                )
                if strict:
                    if not dry_run:
                        session.rollback()
                    raise ValueError(f"Import failed on row {row_number}: {exc}") from exc

        if not dry_run and commit:
            session.commit()

        return report

    def _validate_mapping(self, *, headers: list[str], model: type, mapping: dict[str, str]) -> None:
        missing_headers = [header for header in mapping.keys() if header not in headers]
        if missing_headers:
            missing = ", ".join(missing_headers)
            raise ValueError(f"Headers not found in file: {missing}")

        missing_model_fields = [field_name for field_name in mapping.values() if not hasattr(model, field_name)]
        if missing_model_fields:
            missing = ", ".join(missing_model_fields)
            raise ValueError(f"Model fields not found: {missing}")

    def _read_rows(self, path: Path, *, encoding: str) -> tuple[list[str], Iterable[tuple[int, dict[str, Any]]]]:
        extension = path.suffix.lower()
        if extension == ".csv":
            return self._read_csv(path, encoding=encoding)
        if extension == ".xlsx":
            return self._read_xlsx(path)
        raise ValueError("Only .csv and .xlsx files are supported")

    def _read_csv(self, path: Path, *, encoding: str) -> tuple[list[str], Iterable[tuple[int, dict[str, Any]]]]:
        with path.open("r", encoding=encoding, newline="") as file:
            reader = csv.DictReader(file)
            if reader.fieldnames is None:
                raise ValueError("CSV file must contain a header row")
            headers = [str(field) for field in reader.fieldnames]
            rows = [(index, row) for index, row in enumerate(reader, start=2)]
        return headers, rows

    def _read_xlsx(self, path: Path) -> tuple[list[str], Iterable[tuple[int, dict[str, Any]]]]:
        workbook = load_workbook(path, read_only=True, data_only=True)
        worksheet = workbook.active
        raw_rows = worksheet.iter_rows(values_only=True)

        try:
            header_row = next(raw_rows)
        except StopIteration as exc:
            raise ValueError("XLSX file is empty") from exc

        if not header_row:
            raise ValueError("XLSX file must contain a header row")

        headers = [str(value).strip() if value is not None else "" for value in header_row]
        rows = []
        for row_number, values in enumerate(raw_rows, start=2):
            row = {header: value for header, value in zip(headers, values)}
            rows.append((row_number, row))

        workbook.close()
        return headers, rows