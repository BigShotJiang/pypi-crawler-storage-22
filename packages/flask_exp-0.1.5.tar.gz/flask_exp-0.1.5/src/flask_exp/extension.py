from __future__ import annotations

from functools import wraps
from typing import Any, Callable

from flask import Flask, jsonify, request
from sqlalchemy.inspection import inspect as sqlalchemy_inspect

from .exports import Exports


class FlaskExp:
    def __init__(self, app: Flask | None = None, *, health_endpoint: str = "/health") -> None:
        self.health_endpoint = health_endpoint
        self._initialized = False
        self.exports = Exports()
        if app is not None:
            self.init_app(app)

    def init_app(self, app: Flask) -> None:
        if self._initialized:
            return

        app.extensions["flask-exp"] = self
        self._register_health_endpoint(app)
        self._initialized = True

    def _register_health_endpoint(self, app: Flask) -> None:
        endpoint_name = "flask_exp_health"
        if endpoint_name in app.view_functions:
            return

        @app.get(self.health_endpoint)
        def flask_exp_health() -> tuple[dict[str, str], int]:
            return {"status": "ok", "library": "flask-exp"}, 200

    def json_response(self, payload: dict, status_code: int = 200):
        response = jsonify(payload)
        response.status_code = status_code
        return response

    def route_with_json(self, app: Flask, rule: str, **options):
        def decorator(func: Callable):
            @wraps(func)
            def wrapper(*args, **kwargs):
                result = func(*args, **kwargs)
                if isinstance(result, dict):
                    return self.json_response(result)
                return result

            app.add_url_rule(rule, endpoint=options.pop("endpoint", None), view_func=wrapper, **options)
            return wrapper

        return decorator

    def create_crud_routes(
        self,
        app: Flask,
        model: type,
        session,
        *,
        base_route: str | None = None,
        endpoint_prefix: str | None = None,
    ) -> dict[str, str]:
        mapper = sqlalchemy_inspect(model)
        primary_keys = [column.key for column in mapper.primary_key]
        if len(primary_keys) != 1:
            raise ValueError("CRUD auto-router supports models with a single primary key")

        primary_key = primary_keys[0]
        all_columns = [column.key for column in mapper.columns]
        writable_fields = [field for field in all_columns if field != primary_key]

        resource = base_route or f"/{model.__tablename__}"
        detail_resource = f"{resource}/<item_id>"
        endpoint_base = endpoint_prefix or model.__name__.lower()

        endpoints = {
            "create": f"{endpoint_base}_create",
            "list": f"{endpoint_base}_list",
            "get": f"{endpoint_base}_get",
            "update": f"{endpoint_base}_update",
            "delete": f"{endpoint_base}_delete",
        }

        def serialize(instance) -> dict[str, Any]:
            return {column: getattr(instance, column) for column in all_columns}

        @app.post(resource, endpoint=endpoints["create"])
        def create_item():
            payload = request.get_json(silent=True)
            if not isinstance(payload, dict):
                return self.json_response({"error": "JSON body must be an object"}, 400)

            data = {field: payload[field] for field in writable_fields if field in payload}
            instance = model(**data)
            try:
                session.add(instance)
                session.commit()
            except Exception as exc:
                session.rollback()
                return self.json_response({"error": str(exc)}, 400)

            return self.json_response(serialize(instance), 201)

        @app.get(resource, endpoint=endpoints["list"])
        def list_items():
            items = session.query(model).all()
            return self.json_response({"items": [serialize(item) for item in items]})

        @app.get(detail_resource, endpoint=endpoints["get"])
        def get_item(item_id):
            instance = session.get(model, item_id)
            if instance is None:
                return self.json_response({"error": "Not found"}, 404)
            return self.json_response(serialize(instance))

        @app.put(detail_resource, endpoint=endpoints["update"])
        @app.patch(detail_resource, endpoint=f"{endpoints['update']}_patch")
        def update_item(item_id):
            payload = request.get_json(silent=True)
            if not isinstance(payload, dict):
                return self.json_response({"error": "JSON body must be an object"}, 400)

            instance = session.get(model, item_id)
            if instance is None:
                return self.json_response({"error": "Not found"}, 404)

            for field in writable_fields:
                if field in payload:
                    setattr(instance, field, payload[field])

            try:
                session.commit()
            except Exception as exc:
                session.rollback()
                return self.json_response({"error": str(exc)}, 400)

            return self.json_response(serialize(instance))

        @app.delete(detail_resource, endpoint=endpoints["delete"])
        def delete_item(item_id):
            instance = session.get(model, item_id)
            if instance is None:
                return self.json_response({"error": "Not found"}, 404)

            session.delete(instance)
            session.commit()
            return self.json_response({"status": "deleted"})

        return {
            "resource": resource,
            "detail_resource": detail_resource,
            "endpoints": endpoints,
        }
