"""Flask-WooCommerce exception classes."""

from __future__ import annotations


class WooCommerceError(Exception):
    """Base exception for Flask-WooCommerce."""


class ConfigError(WooCommerceError):
    """Raised when the ``WOOCOMMERCE`` configuration is missing or invalid."""
