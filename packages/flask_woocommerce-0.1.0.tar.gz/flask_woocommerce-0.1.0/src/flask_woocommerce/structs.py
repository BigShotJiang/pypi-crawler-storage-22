"""Flask-WooCommerce configuration structures."""

from __future__ import annotations

from typing import Annotated

import msgspec


class Config(msgspec.Struct):
    """WooCommerce API client configuration.

    Validated from the ``WOOCOMMERCE`` key in the Flask application config.
    Required fields must be present; optional fields are left unset by default
    so that the upstream SDK uses its own defaults.

    Attributes:
        url: Base URL of the WooCommerce store (e.g. ``https://example.com``).
        consumer_key: WooCommerce REST API consumer key.
        consumer_secret: WooCommerce REST API consumer secret.
        wp_api: Enable the WP REST API integration.
        version: API version (e.g. ``wc/v3``).
        timeout: Request timeout in seconds.
        verify_ssl: Verify SSL certificates.
        query_string_auth: Use query string authentication instead of HTTP Basic.
        user_agent: Custom ``User-Agent`` header value.

    """

    url: Annotated[
        str,
        msgspec.Meta(
            pattern=r"^https?://[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+([:/].*)?$",
            description="WooCommerce store URL (http or https)",
        ),
    ]
    consumer_key: str
    consumer_secret: str
    wp_api: bool | msgspec.UnsetType = msgspec.UNSET
    version: str | msgspec.UnsetType = msgspec.UNSET
    timeout: float | msgspec.UnsetType = msgspec.UNSET
    verify_ssl: bool | msgspec.UnsetType = msgspec.UNSET
    query_string_auth: bool | msgspec.UnsetType = msgspec.UNSET
    user_agent: str | msgspec.UnsetType = msgspec.UNSET
