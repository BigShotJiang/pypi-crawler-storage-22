"""Tests for Fleet MCP."""
