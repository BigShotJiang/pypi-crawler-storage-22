library flet_permission_handler;

export "src/extension.dart" show Extension;
