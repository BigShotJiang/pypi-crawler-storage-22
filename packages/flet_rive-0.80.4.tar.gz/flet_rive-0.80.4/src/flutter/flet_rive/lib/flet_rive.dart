library flet_rive;

export "src/extension.dart" show Extension;
