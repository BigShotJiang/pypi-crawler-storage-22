"""
_version.py exists solely to track and update the semvar version number
"""

__version__ = "0.2.3"
