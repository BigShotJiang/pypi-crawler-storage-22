/* global angular */
(function () {
  'use strict';

  angular.module('components.auth', [
    'blocks.exception',
    'blocks.router',
    'components.toolbar',
  ]);
})();
