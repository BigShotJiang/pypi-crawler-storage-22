import subprocess

from const import (
    FORECAST_HORIZON_HOURS,
    FORECASTING_START,
    SCHEDULING_END,
    SIMULATION_STEP_HOURS,
    TUTORIAL_START_DATE,
    heating_name,
    pv_name,
    weather_station_name,
)
from utils.asset_utils import find_sensors_by_asset

from flexmeasures_client import FlexMeasuresClient


async def generate_sensor_forecasts(
    client: FlexMeasuresClient,
    sensor_name: str,
    asset_name: str,
    community_name: str,
    regressors: list[tuple[str, str]] | None = None,
):
    """Generate forecasts using FlexMeasures CLI for the second week."""
    print(f"Generating {sensor_name} forecasts for {asset_name}...")

    # Check if flexmeasures CLI is available
    check_cmd = ["which", "flexmeasures"]
    check_result = subprocess.run(check_cmd, capture_output=True, text=True)

    if check_result.returncode != 0:
        print("FlexMeasures CLI not found. Skipping forecast generation.")
        return False

    # Find sensors
    sensor_mappings = [
        # (key, sensor name, asset name)
        (sensor_name, sensor_name, asset_name),
    ]
    if regressors is not None:
        sensor_mappings.extend(
            [(regressor[0], regressor[0], regressor[1]) for regressor in regressors]
        )
    sensors = await find_sensors_by_asset(
        client=client,
        sensor_mappings=sensor_mappings,
        top_level_asset_name=community_name,
    )
    target_sensor = sensors[sensor_name]
    regressor_sensors = []
    if regressors is not None:
        for regressor in regressors:
            regressor_sensor = sensors[regressor[0]]
            regressor_sensors.append(regressor_sensor)

    if not target_sensor:
        print("Could not find required sensors for forecasting")
        return False

    # Run CLI command
    # NOTE: This uses the CLI because there is no public API yet.
    #       An API endpoint is coming soon, so this can later be done via the client.
    #       Requires FlexMeasures PR #1546.
    cmd = [
        "flexmeasures",
        "add",
        "forecasts",
        "--sensor",
        str(target_sensor["id"]),
        "--train-start",
        TUTORIAL_START_DATE,
        "--from-date",
        FORECASTING_START,
        "--to-date",
        SCHEDULING_END,
        "--max-forecast-horizon",
        f"PT{FORECAST_HORIZON_HOURS}H",
        "--forecast-frequency",
        f"PT{SIMULATION_STEP_HOURS}H",
        "--ensure-positive",
        "--model-save-dir",
        "forecaster_models",
    ]

    if regressor_sensors:
        cmd.extend(
            [
                "--past-regressors",
                ",".join([str(sensor["id"]) for sensor in regressor_sensors]),
            ]
        )  # TODO: to be changed to --regressors when the sensor has irradiance forecasts

    print(f"Running: {' '.join(cmd)}")
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)

    if result.returncode == 0:
        print(f"{sensor_name} forecasts for {asset_name} generated successfully")
        return True
    else:
        print(f"{sensor_name} forecasts for {asset_name} failed: {result.stderr}")
        return False


async def generate_forecasts(
    client: FlexMeasuresClient, community_name: str, site_names: list[str,]
):
    """Generate forecasts for sensors that need to be forecasted for tutorial."""

    forecast_configs = []
    for i, site_name in enumerate(site_names, start=1):
        forecast_configs.extend(
            [
                {
                    "community_name": community_name,
                    "asset_name": f"{pv_name} {i}",
                    "sensor_name": "electricity-production",
                    "regressors": [("irradiation", weather_station_name)],
                },
                {
                    "community_name": community_name,
                    "asset_name": site_name,
                    "sensor_name": "electricity-consumption",
                    "regressors": None,
                },
                {
                    "community_name": community_name,
                    "asset_name": f"{heating_name} {i}",
                    "sensor_name": "soc-usage",
                    "regressors": None,
                },
            ]
        )

    for config in forecast_configs:
        await generate_sensor_forecasts(
            client,
            sensor_name=config["sensor_name"],
            asset_name=config["asset_name"],
            community_name=config["community_name"],
            regressors=config.get("regressors", None),
        )
