from __future__ import annotations
from dataclasses import dataclass
from .label import Label
from .labelgroup import LabelGroup


@dataclass
class Slicer:
    labels: LabelGroup
    data: Table

    def __getattr__(self, name):
        label = self.labels[name]
        start = label.start if isinstance(label, Label) else label[0].start
        stop = label.stop if isinstance(label, Label) else label[1].stop
        res = self.data[start : stop]

        if isinstance(label, Label) and len(label.sublabels) > 0:
            res = res.label(label.sublabels)  

        return res

    def __getitem__(self, name):
        return self.__getattr__(name)

    @property
    def value(self):
        return self.labels.active(self.data.t[0])
    
    def __iter__(self):
        for k in self.labels.keys():
            yield self[k]

    def items(self):
        for k in self.labels.keys():
            yield k, self[k]

from .table import Table