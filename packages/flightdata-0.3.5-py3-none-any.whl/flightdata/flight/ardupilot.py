

flightmodes = {
    0: "MANUAL",
    1:	"CIRCLE",
    2:	"STABILIZE",
    3:	"TRAINING",
    4:	"ACRO",
    5:	"FBWA",
    6:	"FBWB",
    7:	"CRUISE",
    8:	"AUTOTUNE",
    10:	"Auto",
    11:	"RTL",
    12:	"Loiter",
    13:	"TAKEOFF",
    14:	"AVOID_ADSB",
    15:	"Guided",
    17:	"QSTABILIZE",
    18:	"QHOVER",
    19:	"QLOITER",
    20:	"QLAND",
    21:	"QRTL",
    22:	"QAUTOTUNE",
    23:	"QACRO",
    24:	"THERMAL",
    25:	"Loiter to QLand"
}