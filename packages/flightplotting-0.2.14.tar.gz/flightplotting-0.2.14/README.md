# plotting


This module contains utilities for plotting flight data using plotly


```bash
pip install plotting
```

```bash
pip install -e .
```