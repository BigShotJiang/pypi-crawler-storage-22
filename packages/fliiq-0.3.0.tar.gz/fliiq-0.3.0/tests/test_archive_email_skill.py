"""Tests for the archive_email skill."""

import imaplib
import os
from unittest.mock import MagicMock, call, patch

import pytest

from fliiq.runtime.package_data import bundled_skills_dir
from fliiq.runtime.skills.base import SkillBase

SKILLS_DIR = str(bundled_skills_dir())


def _load_skill() -> SkillBase:
    return SkillBase(os.path.join(SKILLS_DIR, "archive_email"))


def test_archive_email_schema():
    skill = _load_skill()
    schema = skill.schema()
    assert schema["name"] == "archive_email"
    assert "message_id" in schema["parameters"]["properties"]
    assert set(schema["parameters"]["required"]) == {"message_id"}


async def test_archive_email_missing_gmail_address(monkeypatch):
    monkeypatch.delenv("GMAIL_ADDRESS", raising=False)
    monkeypatch.delenv("GMAIL_APP_PASSWORD", raising=False)
    skill = _load_skill()
    with pytest.raises(ValueError, match="GMAIL_ADDRESS"):
        await skill.execute({"message_id": "123"})


async def test_archive_email_missing_app_password(monkeypatch):
    monkeypatch.setenv("GMAIL_ADDRESS", "test@gmail.com")
    monkeypatch.delenv("GMAIL_APP_PASSWORD", raising=False)
    skill = _load_skill()
    with pytest.raises(ValueError, match="GMAIL_APP_PASSWORD"):
        await skill.execute({"message_id": "123"})


async def test_archive_email_success(monkeypatch):
    monkeypatch.setenv("GMAIL_ADDRESS", "test@gmail.com")
    monkeypatch.setenv("GMAIL_APP_PASSWORD", "fake-password")
    skill = _load_skill()

    mock_conn = MagicMock()
    mock_conn.login.return_value = ("OK", [])
    mock_conn.select.return_value = ("OK", [b"1"])
    mock_conn.uid.return_value = ("OK", [])
    mock_conn.expunge.return_value = ("OK", [])
    mock_conn.logout.return_value = ("OK", [])

    with patch("imaplib.IMAP4_SSL", return_value=mock_conn):
        result = await skill.execute({"message_id": "456"})

    assert "456" in result["status"]
    assert "archived" in result["status"].lower()
    # Verify: copy to All Mail, then store \Deleted
    mock_conn.uid.assert_has_calls([
        call("copy", "456", '"[Gmail]/All Mail"'),
        call("store", "456", "+FLAGS", "\\Deleted"),
    ])
    mock_conn.expunge.assert_called_once()


async def test_archive_email_imap_error(monkeypatch):
    monkeypatch.setenv("GMAIL_ADDRESS", "test@gmail.com")
    monkeypatch.setenv("GMAIL_APP_PASSWORD", "fake-password")
    skill = _load_skill()

    mock_conn = MagicMock()
    mock_conn.login.return_value = ("OK", [])
    mock_conn.select.return_value = ("OK", [b"1"])
    mock_conn.uid.side_effect = imaplib.IMAP4.error("UID not found")
    mock_conn.logout.return_value = ("OK", [])

    with patch("imaplib.IMAP4_SSL", return_value=mock_conn):
        with pytest.raises(ValueError, match="IMAP error"):
            await skill.execute({"message_id": "999"})


async def test_archive_email_param_override(monkeypatch):
    """Multi-account: params override env vars."""
    monkeypatch.delenv("GMAIL_ADDRESS", raising=False)
    monkeypatch.delenv("GMAIL_APP_PASSWORD", raising=False)
    skill = _load_skill()

    mock_conn = MagicMock()
    mock_conn.login.return_value = ("OK", [])
    mock_conn.select.return_value = ("OK", [b"1"])
    mock_conn.uid.return_value = ("OK", [])
    mock_conn.expunge.return_value = ("OK", [])
    mock_conn.logout.return_value = ("OK", [])

    with patch("imaplib.IMAP4_SSL", return_value=mock_conn):
        result = await skill.execute({
            "message_id": "789",
            "gmail_address": "work@gmail.com",
            "gmail_app_password": "work-pass",
        })

    assert "789" in result["status"]
    mock_conn.login.assert_called_once_with("work@gmail.com", "work-pass")
