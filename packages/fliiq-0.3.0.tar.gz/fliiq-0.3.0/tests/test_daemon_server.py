"""Tests for the FastAPI daemon server."""

from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from fastapi.testclient import TestClient

from fliiq.runtime.scheduler.loader import save_job
from fliiq.runtime.scheduler.models import (
    JobDefinition,
    RunLogEntry,
    TriggerConfig,
)


def _make_job(name: str = "test-job", schedule: str = "0 9 * * *") -> JobDefinition:
    return JobDefinition(
        name=name,
        trigger=TriggerConfig(type="cron", schedule=schedule),
        prompt="Test prompt",
    )


@pytest.fixture()
def client(tmp_path, monkeypatch):
    """Create a TestClient with mocked LLM config and tmp project root."""
    jobs_dir = tmp_path / ".fliiq" / "jobs"
    jobs_dir.mkdir(parents=True)
    monkeypatch.setenv("FLIIQ_PROJECT_ROOT", str(tmp_path))

    with patch("fliiq.api.server.resolve_llm_config", return_value=MagicMock()):
        from fliiq.api.server import app

        with TestClient(app) as c:
            yield c


def test_health_endpoint(client):
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "ok"
    assert "jobs" in data
    assert "uptime_s" in data


def test_list_jobs_empty(client):
    response = client.get("/api/jobs")
    assert response.status_code == 200
    assert response.json() == []


def test_list_jobs_with_jobs(client, tmp_path):
    jobs_dir = tmp_path / ".fliiq" / "jobs"
    save_job(_make_job("job-aa"), jobs_dir)
    save_job(_make_job("job-bb"), jobs_dir)

    response = client.get("/api/jobs")
    assert response.status_code == 200
    data = response.json()
    assert len(data) == 2
    names = {j["name"] for j in data}
    assert names == {"job-aa", "job-bb"}


def test_trigger_job(client, tmp_path):
    jobs_dir = tmp_path / ".fliiq" / "jobs"
    save_job(_make_job("run-me"), jobs_dir)

    mock_entry = RunLogEntry(
        job_name="run-me",
        started_at=datetime.now(timezone.utc),
        completed_at=datetime.now(timezone.utc),
        status="success",
        duration_ms=100,
        iterations=2,
        stop_reason="end_turn",
    )

    with patch("fliiq.api.server.execute_job", new_callable=AsyncMock, return_value=mock_entry):
        response = client.post("/api/jobs/run-me/run")

    assert response.status_code == 200
    data = response.json()
    assert data["job_name"] == "run-me"
    assert data["status"] == "success"


def test_trigger_nonexistent_job(client):
    response = client.post("/api/jobs/ghost/run")
    assert response.status_code == 404
