"""Tests for the mark_email_read skill."""

import imaplib
import os
from unittest.mock import MagicMock, patch

import pytest

from fliiq.runtime.package_data import bundled_skills_dir
from fliiq.runtime.skills.base import SkillBase

SKILLS_DIR = str(bundled_skills_dir())


def _load_skill() -> SkillBase:
    return SkillBase(os.path.join(SKILLS_DIR, "mark_email_read"))


def test_mark_email_read_schema():
    skill = _load_skill()
    schema = skill.schema()
    assert schema["name"] == "mark_email_read"
    assert "message_id" in schema["parameters"]["properties"]
    assert set(schema["parameters"]["required"]) == {"message_id"}


async def test_mark_email_read_missing_gmail_address(monkeypatch):
    monkeypatch.delenv("GMAIL_ADDRESS", raising=False)
    monkeypatch.delenv("GMAIL_APP_PASSWORD", raising=False)
    skill = _load_skill()
    with pytest.raises(ValueError, match="GMAIL_ADDRESS"):
        await skill.execute({"message_id": "123"})


async def test_mark_email_read_missing_app_password(monkeypatch):
    monkeypatch.setenv("GMAIL_ADDRESS", "test@gmail.com")
    monkeypatch.delenv("GMAIL_APP_PASSWORD", raising=False)
    skill = _load_skill()
    with pytest.raises(ValueError, match="GMAIL_APP_PASSWORD"):
        await skill.execute({"message_id": "123"})


async def test_mark_email_read_success(monkeypatch):
    monkeypatch.setenv("GMAIL_ADDRESS", "test@gmail.com")
    monkeypatch.setenv("GMAIL_APP_PASSWORD", "fake-password")
    skill = _load_skill()

    mock_conn = MagicMock()
    mock_conn.login.return_value = ("OK", [])
    mock_conn.select.return_value = ("OK", [b"1"])
    mock_conn.uid.return_value = ("OK", [b"1 (FLAGS (\\Seen))"])
    mock_conn.logout.return_value = ("OK", [])

    with patch("imaplib.IMAP4_SSL", return_value=mock_conn):
        result = await skill.execute({"message_id": "456"})

    assert "456" in result["status"]
    assert "read" in result["status"].lower()
    mock_conn.uid.assert_called_once_with("store", "456", "+FLAGS", "\\Seen")


async def test_mark_email_read_imap_error(monkeypatch):
    monkeypatch.setenv("GMAIL_ADDRESS", "test@gmail.com")
    monkeypatch.setenv("GMAIL_APP_PASSWORD", "fake-password")
    skill = _load_skill()

    mock_conn = MagicMock()
    mock_conn.login.return_value = ("OK", [])
    mock_conn.select.return_value = ("OK", [b"1"])
    mock_conn.uid.side_effect = imaplib.IMAP4.error("UID not found")
    mock_conn.logout.return_value = ("OK", [])

    with patch("imaplib.IMAP4_SSL", return_value=mock_conn):
        with pytest.raises(ValueError, match="IMAP error"):
            await skill.execute({"message_id": "999"})


async def test_mark_email_read_param_override(monkeypatch):
    """Multi-account: params override env vars."""
    monkeypatch.delenv("GMAIL_ADDRESS", raising=False)
    monkeypatch.delenv("GMAIL_APP_PASSWORD", raising=False)
    skill = _load_skill()

    mock_conn = MagicMock()
    mock_conn.login.return_value = ("OK", [])
    mock_conn.select.return_value = ("OK", [b"1"])
    mock_conn.uid.return_value = ("OK", [b"1 (FLAGS (\\Seen))"])
    mock_conn.logout.return_value = ("OK", [])

    with patch("imaplib.IMAP4_SSL", return_value=mock_conn):
        result = await skill.execute({
            "message_id": "456",
            "gmail_address": "work@gmail.com",
            "gmail_app_password": "work-pass",
        })

    assert "456" in result["status"]
    mock_conn.login.assert_called_once_with("work@gmail.com", "work-pass")
