"""Archive an email via Gmail IMAP4_SSL (remove from Inbox, keep in All Mail)."""

import asyncio
import imaplib

from fliiq.runtime.google_auth import resolve_gmail_creds

IMAP_HOST = "imap.gmail.com"
IMAP_PORT = 993


def _archive_email(address: str, auth_method: str, credential: str, message_id: str) -> dict:
    """Blocking IMAP archive — runs in threadpool."""
    try:
        conn = imaplib.IMAP4_SSL(IMAP_HOST, IMAP_PORT, timeout=30)
    except Exception as e:
        raise ValueError(f"IMAP connection failed: {e}")

    try:
        if auth_method == "oauth2":
            auth_string = f"user={address}\x01auth=Bearer {credential}\x01\x01"
            conn.authenticate("XOAUTH2", lambda _: auth_string.encode())
        else:
            conn.login(address, credential)
    except imaplib.IMAP4.error as e:
        conn.logout()
        if auth_method == "oauth2":
            raise ValueError(
                f"Gmail IMAP OAuth failed for {address}: {e}. "
                "Try 'fliiq google auth' to re-authorize."
            )
        raise ValueError(
            "Gmail IMAP authentication failed. Check GMAIL_ADDRESS and GMAIL_APP_PASSWORD."
        )

    try:
        conn.select("INBOX")
        # Copy to All Mail (message already exists there in Gmail, but this ensures it)
        status, _data = conn.uid("copy", message_id, '"[Gmail]/All Mail"')
        if status != "OK":
            raise ValueError(f"Failed to copy email {message_id} to All Mail: {status}")
        # Remove from Inbox
        status, _data = conn.uid("store", message_id, "+FLAGS", "\\Deleted")
        if status != "OK":
            raise ValueError(f"Failed to remove email {message_id} from Inbox: {status}")
        conn.expunge()
        return {"status": f"Email {message_id} archived."}
    except imaplib.IMAP4.error as e:
        raise ValueError(f"IMAP error archiving email: {e}")
    finally:
        try:
            conn.logout()
        except Exception:
            pass


async def handler(params: dict) -> dict:
    """Archive an email by IMAP UID (remove from Inbox, keep in All Mail)."""
    address, auth_method, credential = await resolve_gmail_creds()

    message_id = params["message_id"]

    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(
        None, _archive_email, address, auth_method, credential, message_id
    )
