"""Tests for MemoryManager — filesystem CRUD for .fliiq/memory/."""

from fliiq.runtime.memory.manager import MemoryManager


def test_ensure_dirs(tmp_path):
    mgr = MemoryManager(tmp_path / "memory")
    mgr.ensure_dirs()
    assert (tmp_path / "memory").is_dir()
    assert (tmp_path / "memory" / "skills").is_dir()


def test_save_and_load_curated(tmp_path):
    mgr = MemoryManager(tmp_path / "memory")
    mgr.ensure_dirs()
    mgr.save_curated("User prefers dark mode.")
    assert mgr.load_curated() == "User prefers dark mode."


def test_save_and_load_memory(tmp_path):
    mgr = MemoryManager(tmp_path / "memory")
    mgr.ensure_dirs()
    mgr.save_memory("MEMORY", "long-term notes")
    assert mgr.load_memory("MEMORY") == "long-term notes"


def test_save_and_load_skill_memory(tmp_path):
    mgr = MemoryManager(tmp_path / "memory")
    mgr.ensure_dirs()
    mgr.save_memory("skills/fitness", "## Fitness Plan\n- Lose 15 lbs")
    content = mgr.load_memory("skills/fitness")
    assert "Fitness Plan" in content


def test_save_and_load_daily(tmp_path):
    mgr = MemoryManager(tmp_path / "memory")
    mgr.ensure_dirs()
    mgr.save_memory("2026-02-03", "Morning standup notes")
    assert mgr.load_memory("2026-02-03") == "Morning standup notes"


def test_append_daily(tmp_path):
    mgr = MemoryManager(tmp_path / "memory")
    mgr.ensure_dirs()
    mgr.append_daily("2026-02-03", "Morning entry")
    mgr.append_daily("2026-02-03", "Evening entry")
    content = mgr.load_memory("2026-02-03")
    assert "Morning entry" in content
    assert "Evening entry" in content
    assert "---" in content  # separator


def test_list_skill_memories(tmp_path):
    mgr = MemoryManager(tmp_path / "memory")
    mgr.ensure_dirs()
    mgr.save_memory("skills/cantonese", "lesson 1")
    mgr.save_memory("skills/fitness", "workout A")
    skills = mgr.list_skill_memories()
    assert skills == ["cantonese", "fitness"]


def test_list_skill_memories_empty(tmp_path):
    mgr = MemoryManager(tmp_path / "memory")
    mgr.ensure_dirs()
    assert mgr.list_skill_memories() == []


def test_load_nonexistent_returns_none(tmp_path):
    mgr = MemoryManager(tmp_path / "memory")
    mgr.ensure_dirs()
    assert mgr.load_memory("nonexistent") is None
    assert mgr.load_curated() is None


def test_from_project_root(tmp_path):
    mgr = MemoryManager.from_project_root(tmp_path)
    assert mgr.memory_dir == tmp_path / ".fliiq" / "memory"


def test_path_resolution_with_md_extension(tmp_path):
    mgr = MemoryManager(tmp_path / "memory")
    mgr.ensure_dirs()
    mgr.save_memory("MEMORY.md", "test content")
    assert mgr.load_memory("MEMORY") == "test content"
