def test_import_fliiq():
    import fliiq

    assert fliiq.__version__ == "0.1.0"
