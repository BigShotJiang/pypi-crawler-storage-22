import datetime

from google.protobuf import timestamp_pb2 as _timestamp_pb2
from third_party.google.rpc import status_pb2 as _status_pb2
from third_party.google.api import annotations_pb2 as _annotations_pb2
from third_party.google.gnostic.openapiv3 import annotations_pb2 as _annotations_pb2_1
from floke.connector import common_pb2 as _common_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class AuthMethod(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    AUTH_METHOD_UNSPECIFIED: _ClassVar[AuthMethod]
    AUTH_METHOD_BASIC: _ClassVar[AuthMethod]
    AUTH_METHOD_API_KEY: _ClassVar[AuthMethod]
    AUTH_METHOD_OAUTH2: _ClassVar[AuthMethod]
    AUTH_METHOD_JWT: _ClassVar[AuthMethod]
    AUTH_METHOD_CUSTOM: _ClassVar[AuthMethod]

class TokenType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    TOKEN_TYPE_UNSPECIFIED: _ClassVar[TokenType]
    TOKEN_TYPE_BEARER: _ClassVar[TokenType]
    TOKEN_TYPE_BASIC: _ClassVar[TokenType]
    TOKEN_TYPE_DIGEST: _ClassVar[TokenType]
    TOKEN_TYPE_MAC: _ClassVar[TokenType]
    TOKEN_TYPE_CUSTOM: _ClassVar[TokenType]
AUTH_METHOD_UNSPECIFIED: AuthMethod
AUTH_METHOD_BASIC: AuthMethod
AUTH_METHOD_API_KEY: AuthMethod
AUTH_METHOD_OAUTH2: AuthMethod
AUTH_METHOD_JWT: AuthMethod
AUTH_METHOD_CUSTOM: AuthMethod
TOKEN_TYPE_UNSPECIFIED: TokenType
TOKEN_TYPE_BEARER: TokenType
TOKEN_TYPE_BASIC: TokenType
TOKEN_TYPE_DIGEST: TokenType
TOKEN_TYPE_MAC: TokenType
TOKEN_TYPE_CUSTOM: TokenType

class BasicAuthCredentials(_message.Message):
    __slots__ = ("username", "password")
    USERNAME_FIELD_NUMBER: _ClassVar[int]
    PASSWORD_FIELD_NUMBER: _ClassVar[int]
    username: str
    password: str
    def __init__(self, username: _Optional[str] = ..., password: _Optional[str] = ...) -> None: ...

class ApiKeyCredentials(_message.Message):
    __slots__ = ("key", "header_name")
    KEY_FIELD_NUMBER: _ClassVar[int]
    HEADER_NAME_FIELD_NUMBER: _ClassVar[int]
    key: str
    header_name: str
    def __init__(self, key: _Optional[str] = ..., header_name: _Optional[str] = ...) -> None: ...

class OAuth2Credentials(_message.Message):
    __slots__ = ("client_id", "client_secret", "redirect_uri", "scopes", "authorization_code", "refresh_token")
    CLIENT_ID_FIELD_NUMBER: _ClassVar[int]
    CLIENT_SECRET_FIELD_NUMBER: _ClassVar[int]
    REDIRECT_URI_FIELD_NUMBER: _ClassVar[int]
    SCOPES_FIELD_NUMBER: _ClassVar[int]
    AUTHORIZATION_CODE_FIELD_NUMBER: _ClassVar[int]
    REFRESH_TOKEN_FIELD_NUMBER: _ClassVar[int]
    client_id: str
    client_secret: str
    redirect_uri: str
    scopes: _containers.RepeatedScalarFieldContainer[str]
    authorization_code: str
    refresh_token: str
    def __init__(self, client_id: _Optional[str] = ..., client_secret: _Optional[str] = ..., redirect_uri: _Optional[str] = ..., scopes: _Optional[_Iterable[str]] = ..., authorization_code: _Optional[str] = ..., refresh_token: _Optional[str] = ...) -> None: ...

class JwtCredentials(_message.Message):
    __slots__ = ("token",)
    TOKEN_FIELD_NUMBER: _ClassVar[int]
    token: str
    def __init__(self, token: _Optional[str] = ...) -> None: ...

class CustomCredentials(_message.Message):
    __slots__ = ("parameters",)
    class ParametersEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    parameters: _containers.ScalarMap[str, str]
    def __init__(self, parameters: _Optional[_Mapping[str, str]] = ...) -> None: ...

class AuthToken(_message.Message):
    __slots__ = ("access_token", "token_type", "expires_at", "refresh_token", "scopes")
    ACCESS_TOKEN_FIELD_NUMBER: _ClassVar[int]
    TOKEN_TYPE_FIELD_NUMBER: _ClassVar[int]
    EXPIRES_AT_FIELD_NUMBER: _ClassVar[int]
    REFRESH_TOKEN_FIELD_NUMBER: _ClassVar[int]
    SCOPES_FIELD_NUMBER: _ClassVar[int]
    access_token: str
    token_type: TokenType
    expires_at: _timestamp_pb2.Timestamp
    refresh_token: str
    scopes: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, access_token: _Optional[str] = ..., token_type: _Optional[_Union[TokenType, str]] = ..., expires_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., refresh_token: _Optional[str] = ..., scopes: _Optional[_Iterable[str]] = ...) -> None: ...

class RequestContext(_message.Message):
    __slots__ = ("base", "token")
    BASE_FIELD_NUMBER: _ClassVar[int]
    TOKEN_FIELD_NUMBER: _ClassVar[int]
    base: _common_pb2.BaseContext
    token: AuthToken
    def __init__(self, base: _Optional[_Union[_common_pb2.BaseContext, _Mapping]] = ..., token: _Optional[_Union[AuthToken, _Mapping]] = ...) -> None: ...

class AuthenticateRequest(_message.Message):
    __slots__ = ("base", "method", "basic", "api_key", "oauth2", "jwt", "custom")
    BASE_FIELD_NUMBER: _ClassVar[int]
    METHOD_FIELD_NUMBER: _ClassVar[int]
    BASIC_FIELD_NUMBER: _ClassVar[int]
    API_KEY_FIELD_NUMBER: _ClassVar[int]
    OAUTH2_FIELD_NUMBER: _ClassVar[int]
    JWT_FIELD_NUMBER: _ClassVar[int]
    CUSTOM_FIELD_NUMBER: _ClassVar[int]
    base: _common_pb2.BaseContext
    method: AuthMethod
    basic: BasicAuthCredentials
    api_key: ApiKeyCredentials
    oauth2: OAuth2Credentials
    jwt: JwtCredentials
    custom: CustomCredentials
    def __init__(self, base: _Optional[_Union[_common_pb2.BaseContext, _Mapping]] = ..., method: _Optional[_Union[AuthMethod, str]] = ..., basic: _Optional[_Union[BasicAuthCredentials, _Mapping]] = ..., api_key: _Optional[_Union[ApiKeyCredentials, _Mapping]] = ..., oauth2: _Optional[_Union[OAuth2Credentials, _Mapping]] = ..., jwt: _Optional[_Union[JwtCredentials, _Mapping]] = ..., custom: _Optional[_Union[CustomCredentials, _Mapping]] = ...) -> None: ...

class AuthenticateResponse(_message.Message):
    __slots__ = ("status", "token")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TOKEN_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    token: AuthToken
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., token: _Optional[_Union[AuthToken, _Mapping]] = ...) -> None: ...

class RefreshTokenRequest(_message.Message):
    __slots__ = ("base", "method", "refresh_token")
    BASE_FIELD_NUMBER: _ClassVar[int]
    METHOD_FIELD_NUMBER: _ClassVar[int]
    REFRESH_TOKEN_FIELD_NUMBER: _ClassVar[int]
    base: _common_pb2.BaseContext
    method: AuthMethod
    refresh_token: str
    def __init__(self, base: _Optional[_Union[_common_pb2.BaseContext, _Mapping]] = ..., method: _Optional[_Union[AuthMethod, str]] = ..., refresh_token: _Optional[str] = ...) -> None: ...

class RefreshTokenResponse(_message.Message):
    __slots__ = ("status", "token")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TOKEN_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    token: AuthToken
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., token: _Optional[_Union[AuthToken, _Mapping]] = ...) -> None: ...
