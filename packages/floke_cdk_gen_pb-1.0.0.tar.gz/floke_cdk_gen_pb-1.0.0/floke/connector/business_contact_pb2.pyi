from third_party.google.api import annotations_pb2 as _annotations_pb2
from third_party.google.gnostic.openapiv3 import annotations_pb2 as _annotations_pb2_1
from third_party.google.rpc import status_pb2 as _status_pb2
from floke.connector import authentication_pb2 as _authentication_pb2
from floke.internal import descriptor_pb2 as _descriptor_pb2
from floke.connector import common_pb2 as _common_pb2
from floke.connector import contact_pb2 as _contact_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class BusinessContact(_message.Message):
    __slots__ = ("audit_info", "id", "title", "first_name", "last_name", "emails", "phone_numbers", "position", "department", "primary", "business_partner_id", "address", "active")
    AUDIT_INFO_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    FIRST_NAME_FIELD_NUMBER: _ClassVar[int]
    LAST_NAME_FIELD_NUMBER: _ClassVar[int]
    EMAILS_FIELD_NUMBER: _ClassVar[int]
    PHONE_NUMBERS_FIELD_NUMBER: _ClassVar[int]
    POSITION_FIELD_NUMBER: _ClassVar[int]
    DEPARTMENT_FIELD_NUMBER: _ClassVar[int]
    PRIMARY_FIELD_NUMBER: _ClassVar[int]
    BUSINESS_PARTNER_ID_FIELD_NUMBER: _ClassVar[int]
    ADDRESS_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_FIELD_NUMBER: _ClassVar[int]
    audit_info: _common_pb2.AuditInfo
    id: str
    title: str
    first_name: str
    last_name: str
    emails: _containers.RepeatedScalarFieldContainer[str]
    phone_numbers: _containers.RepeatedCompositeFieldContainer[_contact_pb2.PhoneNumber]
    position: str
    department: str
    primary: bool
    business_partner_id: str
    address: _contact_pb2.Address
    active: bool
    def __init__(self, audit_info: _Optional[_Union[_common_pb2.AuditInfo, _Mapping]] = ..., id: _Optional[str] = ..., title: _Optional[str] = ..., first_name: _Optional[str] = ..., last_name: _Optional[str] = ..., emails: _Optional[_Iterable[str]] = ..., phone_numbers: _Optional[_Iterable[_Union[_contact_pb2.PhoneNumber, _Mapping]]] = ..., position: _Optional[str] = ..., department: _Optional[str] = ..., primary: bool = ..., business_partner_id: _Optional[str] = ..., address: _Optional[_Union[_contact_pb2.Address, _Mapping]] = ..., active: bool = ...) -> None: ...

class CreateBusinessContactRequest(_message.Message):
    __slots__ = ("request_context", "business_contact")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    BUSINESS_CONTACT_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    business_contact: BusinessContact
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., business_contact: _Optional[_Union[BusinessContact, _Mapping]] = ...) -> None: ...

class CreateBusinessContactResponse(_message.Message):
    __slots__ = ("status", "business_contact")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    BUSINESS_CONTACT_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    business_contact: BusinessContact
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., business_contact: _Optional[_Union[BusinessContact, _Mapping]] = ...) -> None: ...

class GetBusinessContactRequest(_message.Message):
    __slots__ = ("request_context", "id")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    id: str
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., id: _Optional[str] = ...) -> None: ...

class GetBusinessContactResponse(_message.Message):
    __slots__ = ("status", "business_contact")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    BUSINESS_CONTACT_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    business_contact: BusinessContact
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., business_contact: _Optional[_Union[BusinessContact, _Mapping]] = ...) -> None: ...

class UpdateBusinessContactRequest(_message.Message):
    __slots__ = ("request_context", "business_contact")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    BUSINESS_CONTACT_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    business_contact: BusinessContact
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., business_contact: _Optional[_Union[BusinessContact, _Mapping]] = ...) -> None: ...

class UpdateBusinessContactResponse(_message.Message):
    __slots__ = ("status", "business_contact")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    BUSINESS_CONTACT_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    business_contact: BusinessContact
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., business_contact: _Optional[_Union[BusinessContact, _Mapping]] = ...) -> None: ...

class DeleteBusinessContactRequest(_message.Message):
    __slots__ = ("request_context", "id")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    id: str
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., id: _Optional[str] = ...) -> None: ...

class DeleteBusinessContactResponse(_message.Message):
    __slots__ = ("status",)
    STATUS_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ...) -> None: ...

class ListBusinessContactsRequest(_message.Message):
    __slots__ = ("request_context", "pagination", "business_partner_id", "active_only", "search_term")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    PAGINATION_FIELD_NUMBER: _ClassVar[int]
    BUSINESS_PARTNER_ID_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_ONLY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_TERM_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    pagination: _common_pb2.PaginationRequest
    business_partner_id: str
    active_only: bool
    search_term: str
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., pagination: _Optional[_Union[_common_pb2.PaginationRequest, _Mapping]] = ..., business_partner_id: _Optional[str] = ..., active_only: bool = ..., search_term: _Optional[str] = ...) -> None: ...

class ListBusinessContactsResponse(_message.Message):
    __slots__ = ("status", "pagination", "business_contacts")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    PAGINATION_FIELD_NUMBER: _ClassVar[int]
    BUSINESS_CONTACTS_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    pagination: _common_pb2.PaginationResponse
    business_contacts: _containers.RepeatedCompositeFieldContainer[BusinessContact]
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., pagination: _Optional[_Union[_common_pb2.PaginationResponse, _Mapping]] = ..., business_contacts: _Optional[_Iterable[_Union[BusinessContact, _Mapping]]] = ...) -> None: ...
