from third_party.google.api import annotations_pb2 as _annotations_pb2
from third_party.google.gnostic.openapiv3 import annotations_pb2 as _annotations_pb2_1
from third_party.google.rpc import status_pb2 as _status_pb2
from floke.connector import authentication_pb2 as _authentication_pb2
from floke.internal import descriptor_pb2 as _descriptor_pb2
from floke.connector import common_pb2 as _common_pb2
from floke.connector import business_contact_pb2 as _business_contact_pb2
from floke.connector import contact_pb2 as _contact_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class BusinessPartner(_message.Message):
    __slots__ = ("audit_info", "id", "group_id", "code", "name", "legal_name", "additional_name", "search_text", "tax_id", "website", "industry", "segment", "billing_addresses", "shipping_addresses", "active_for_sales", "active_for_purchase", "contact_ids", "contacts")
    AUDIT_INFO_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    GROUP_ID_FIELD_NUMBER: _ClassVar[int]
    CODE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    LEGAL_NAME_FIELD_NUMBER: _ClassVar[int]
    ADDITIONAL_NAME_FIELD_NUMBER: _ClassVar[int]
    SEARCH_TEXT_FIELD_NUMBER: _ClassVar[int]
    TAX_ID_FIELD_NUMBER: _ClassVar[int]
    WEBSITE_FIELD_NUMBER: _ClassVar[int]
    INDUSTRY_FIELD_NUMBER: _ClassVar[int]
    SEGMENT_FIELD_NUMBER: _ClassVar[int]
    BILLING_ADDRESSES_FIELD_NUMBER: _ClassVar[int]
    SHIPPING_ADDRESSES_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_FOR_SALES_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_FOR_PURCHASE_FIELD_NUMBER: _ClassVar[int]
    CONTACT_IDS_FIELD_NUMBER: _ClassVar[int]
    CONTACTS_FIELD_NUMBER: _ClassVar[int]
    audit_info: _common_pb2.AuditInfo
    id: str
    group_id: str
    code: str
    name: str
    legal_name: str
    additional_name: str
    search_text: str
    tax_id: str
    website: str
    industry: str
    segment: str
    billing_addresses: _containers.RepeatedCompositeFieldContainer[_contact_pb2.Address]
    shipping_addresses: _containers.RepeatedCompositeFieldContainer[_contact_pb2.Address]
    active_for_sales: bool
    active_for_purchase: bool
    contact_ids: _containers.RepeatedScalarFieldContainer[str]
    contacts: _containers.RepeatedCompositeFieldContainer[_business_contact_pb2.BusinessContact]
    def __init__(self, audit_info: _Optional[_Union[_common_pb2.AuditInfo, _Mapping]] = ..., id: _Optional[str] = ..., group_id: _Optional[str] = ..., code: _Optional[str] = ..., name: _Optional[str] = ..., legal_name: _Optional[str] = ..., additional_name: _Optional[str] = ..., search_text: _Optional[str] = ..., tax_id: _Optional[str] = ..., website: _Optional[str] = ..., industry: _Optional[str] = ..., segment: _Optional[str] = ..., billing_addresses: _Optional[_Iterable[_Union[_contact_pb2.Address, _Mapping]]] = ..., shipping_addresses: _Optional[_Iterable[_Union[_contact_pb2.Address, _Mapping]]] = ..., active_for_sales: bool = ..., active_for_purchase: bool = ..., contact_ids: _Optional[_Iterable[str]] = ..., contacts: _Optional[_Iterable[_Union[_business_contact_pb2.BusinessContact, _Mapping]]] = ...) -> None: ...

class CreateBusinessPartnerRequest(_message.Message):
    __slots__ = ("request_context", "business_partner")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    BUSINESS_PARTNER_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    business_partner: BusinessPartner
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., business_partner: _Optional[_Union[BusinessPartner, _Mapping]] = ...) -> None: ...

class CreateBusinessPartnerResponse(_message.Message):
    __slots__ = ("status", "business_partner")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    BUSINESS_PARTNER_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    business_partner: BusinessPartner
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., business_partner: _Optional[_Union[BusinessPartner, _Mapping]] = ...) -> None: ...

class GetBusinessPartnerRequest(_message.Message):
    __slots__ = ("request_context", "id")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    id: str
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., id: _Optional[str] = ...) -> None: ...

class GetBusinessPartnerResponse(_message.Message):
    __slots__ = ("status", "business_partner")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    BUSINESS_PARTNER_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    business_partner: BusinessPartner
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., business_partner: _Optional[_Union[BusinessPartner, _Mapping]] = ...) -> None: ...

class UpdateBusinessPartnerRequest(_message.Message):
    __slots__ = ("request_context", "business_partner")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    BUSINESS_PARTNER_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    business_partner: BusinessPartner
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., business_partner: _Optional[_Union[BusinessPartner, _Mapping]] = ...) -> None: ...

class UpdateBusinessPartnerResponse(_message.Message):
    __slots__ = ("status", "business_partner")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    BUSINESS_PARTNER_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    business_partner: BusinessPartner
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., business_partner: _Optional[_Union[BusinessPartner, _Mapping]] = ...) -> None: ...

class DeleteBusinessPartnerRequest(_message.Message):
    __slots__ = ("request_context", "id")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    id: str
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., id: _Optional[str] = ...) -> None: ...

class DeleteBusinessPartnerResponse(_message.Message):
    __slots__ = ("status",)
    STATUS_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ...) -> None: ...

class ListBusinessPartnersRequest(_message.Message):
    __slots__ = ("request_context", "pagination", "active_only", "search_term")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    PAGINATION_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_ONLY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_TERM_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    pagination: _common_pb2.PaginationRequest
    active_only: bool
    search_term: str
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., pagination: _Optional[_Union[_common_pb2.PaginationRequest, _Mapping]] = ..., active_only: bool = ..., search_term: _Optional[str] = ...) -> None: ...

class ListBusinessPartnersResponse(_message.Message):
    __slots__ = ("status", "pagination", "business_partners")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    PAGINATION_FIELD_NUMBER: _ClassVar[int]
    BUSINESS_PARTNERS_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    pagination: _common_pb2.PaginationResponse
    business_partners: _containers.RepeatedCompositeFieldContainer[BusinessPartner]
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., pagination: _Optional[_Union[_common_pb2.PaginationResponse, _Mapping]] = ..., business_partners: _Optional[_Iterable[_Union[BusinessPartner, _Mapping]]] = ...) -> None: ...
