import datetime

from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class FlokeErrorReason(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    UNDEFINED: _ClassVar[FlokeErrorReason]
    CONNECTOR_UNIMPLEMENTED: _ClassVar[FlokeErrorReason]
    ERP_UNSUPPORTED: _ClassVar[FlokeErrorReason]
UNDEFINED: FlokeErrorReason
CONNECTOR_UNIMPLEMENTED: FlokeErrorReason
ERP_UNSUPPORTED: FlokeErrorReason

class AuditInfo(_message.Message):
    __slots__ = ("created_at", "updated_at", "metadata")
    class MetadataEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    created_at: _timestamp_pb2.Timestamp
    updated_at: _timestamp_pb2.Timestamp
    metadata: _containers.ScalarMap[str, str]
    def __init__(self, created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., updated_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., metadata: _Optional[_Mapping[str, str]] = ...) -> None: ...

class BaseContext(_message.Message):
    __slots__ = ("request_id", "correlation_id", "tenant_id", "connector_defined_fields")
    class ConnectorDefinedFieldsEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    CORRELATION_ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    CONNECTOR_DEFINED_FIELDS_FIELD_NUMBER: _ClassVar[int]
    request_id: str
    correlation_id: str
    tenant_id: str
    connector_defined_fields: _containers.ScalarMap[str, str]
    def __init__(self, request_id: _Optional[str] = ..., correlation_id: _Optional[str] = ..., tenant_id: _Optional[str] = ..., connector_defined_fields: _Optional[_Mapping[str, str]] = ...) -> None: ...

class PaginationRequest(_message.Message):
    __slots__ = ("cursor", "page_size", "sort_by", "sort_desc")
    CURSOR_FIELD_NUMBER: _ClassVar[int]
    PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    SORT_BY_FIELD_NUMBER: _ClassVar[int]
    SORT_DESC_FIELD_NUMBER: _ClassVar[int]
    cursor: str
    page_size: int
    sort_by: str
    sort_desc: bool
    def __init__(self, cursor: _Optional[str] = ..., page_size: _Optional[int] = ..., sort_by: _Optional[str] = ..., sort_desc: bool = ...) -> None: ...

class PaginationResponse(_message.Message):
    __slots__ = ("next_page_cursor", "previous_page_cursor", "total_items", "page_size")
    NEXT_PAGE_CURSOR_FIELD_NUMBER: _ClassVar[int]
    PREVIOUS_PAGE_CURSOR_FIELD_NUMBER: _ClassVar[int]
    TOTAL_ITEMS_FIELD_NUMBER: _ClassVar[int]
    PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    next_page_cursor: str
    previous_page_cursor: str
    total_items: int
    page_size: int
    def __init__(self, next_page_cursor: _Optional[str] = ..., previous_page_cursor: _Optional[str] = ..., total_items: _Optional[int] = ..., page_size: _Optional[int] = ...) -> None: ...
