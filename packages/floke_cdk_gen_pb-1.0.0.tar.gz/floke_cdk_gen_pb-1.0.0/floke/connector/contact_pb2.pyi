from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class PhoneNumberType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    MOBILE: _ClassVar[PhoneNumberType]
    LANDLINE: _ClassVar[PhoneNumberType]
MOBILE: PhoneNumberType
LANDLINE: PhoneNumberType

class Address(_message.Message):
    __slots__ = ("street_line1", "street_line2", "city", "state", "postal_code", "country", "supplements", "id", "gln", "is_default")
    STREET_LINE1_FIELD_NUMBER: _ClassVar[int]
    STREET_LINE2_FIELD_NUMBER: _ClassVar[int]
    CITY_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    POSTAL_CODE_FIELD_NUMBER: _ClassVar[int]
    COUNTRY_FIELD_NUMBER: _ClassVar[int]
    SUPPLEMENTS_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    GLN_FIELD_NUMBER: _ClassVar[int]
    IS_DEFAULT_FIELD_NUMBER: _ClassVar[int]
    street_line1: str
    street_line2: str
    city: str
    state: str
    postal_code: str
    country: str
    supplements: _containers.RepeatedScalarFieldContainer[str]
    id: str
    gln: str
    is_default: bool
    def __init__(self, street_line1: _Optional[str] = ..., street_line2: _Optional[str] = ..., city: _Optional[str] = ..., state: _Optional[str] = ..., postal_code: _Optional[str] = ..., country: _Optional[str] = ..., supplements: _Optional[_Iterable[str]] = ..., id: _Optional[str] = ..., gln: _Optional[str] = ..., is_default: bool = ...) -> None: ...

class PhoneNumber(_message.Message):
    __slots__ = ("number", "type")
    NUMBER_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    number: str
    type: PhoneNumberType
    def __init__(self, number: _Optional[str] = ..., type: _Optional[_Union[PhoneNumberType, str]] = ...) -> None: ...
