from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class CurrencyAmount(_message.Message):
    __slots__ = ("currency_code", "amount")
    CURRENCY_CODE_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_FIELD_NUMBER: _ClassVar[int]
    currency_code: str
    amount: float
    def __init__(self, currency_code: _Optional[str] = ..., amount: _Optional[float] = ...) -> None: ...
