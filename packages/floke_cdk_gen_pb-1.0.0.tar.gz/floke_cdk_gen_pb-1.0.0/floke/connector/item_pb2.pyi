from third_party.google.api import annotations_pb2 as _annotations_pb2
from third_party.google.gnostic.openapiv3 import annotations_pb2 as _annotations_pb2_1
from third_party.google.rpc import status_pb2 as _status_pb2
from google.protobuf import struct_pb2 as _struct_pb2
from floke.internal import descriptor_pb2 as _descriptor_pb2
from floke.connector import authentication_pb2 as _authentication_pb2
from floke.connector import common_pb2 as _common_pb2
from floke.connector import unit_of_measure_pb2 as _unit_of_measure_pb2
from floke.connector import packing_unit_pb2 as _packing_unit_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ItemUnitOfMeasure(_message.Message):
    __slots__ = ("uom", "base_conversion_factor", "weight", "volume", "size", "is_atomic", "is_custom", "business_partner_ids", "additional_attributes")
    UOM_FIELD_NUMBER: _ClassVar[int]
    BASE_CONVERSION_FACTOR_FIELD_NUMBER: _ClassVar[int]
    WEIGHT_FIELD_NUMBER: _ClassVar[int]
    VOLUME_FIELD_NUMBER: _ClassVar[int]
    SIZE_FIELD_NUMBER: _ClassVar[int]
    IS_ATOMIC_FIELD_NUMBER: _ClassVar[int]
    IS_CUSTOM_FIELD_NUMBER: _ClassVar[int]
    BUSINESS_PARTNER_IDS_FIELD_NUMBER: _ClassVar[int]
    ADDITIONAL_ATTRIBUTES_FIELD_NUMBER: _ClassVar[int]
    uom: _unit_of_measure_pb2.UnitOfMeasure
    base_conversion_factor: float
    weight: float
    volume: float
    size: str
    is_atomic: bool
    is_custom: bool
    business_partner_ids: _containers.RepeatedScalarFieldContainer[str]
    additional_attributes: _struct_pb2.Struct
    def __init__(self, uom: _Optional[_Union[_unit_of_measure_pb2.UnitOfMeasure, _Mapping]] = ..., base_conversion_factor: _Optional[float] = ..., weight: _Optional[float] = ..., volume: _Optional[float] = ..., size: _Optional[str] = ..., is_atomic: bool = ..., is_custom: bool = ..., business_partner_ids: _Optional[_Iterable[str]] = ..., additional_attributes: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ...) -> None: ...

class ItemUnitOfMeasures(_message.Message):
    __slots__ = ("uoms",)
    UOMS_FIELD_NUMBER: _ClassVar[int]
    uoms: _containers.RepeatedCompositeFieldContainer[ItemUnitOfMeasure]
    def __init__(self, uoms: _Optional[_Iterable[_Union[ItemUnitOfMeasure, _Mapping]]] = ...) -> None: ...

class ItemPackingUnit(_message.Message):
    __slots__ = ("packing_unit", "business_partner_ids", "additional_attributes")
    PACKING_UNIT_FIELD_NUMBER: _ClassVar[int]
    BUSINESS_PARTNER_IDS_FIELD_NUMBER: _ClassVar[int]
    ADDITIONAL_ATTRIBUTES_FIELD_NUMBER: _ClassVar[int]
    packing_unit: _packing_unit_pb2.PackingUnit
    business_partner_ids: _containers.RepeatedScalarFieldContainer[str]
    additional_attributes: _struct_pb2.Struct
    def __init__(self, packing_unit: _Optional[_Union[_packing_unit_pb2.PackingUnit, _Mapping]] = ..., business_partner_ids: _Optional[_Iterable[str]] = ..., additional_attributes: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ...) -> None: ...

class ItemPackingUnits(_message.Message):
    __slots__ = ("packing_units",)
    PACKING_UNITS_FIELD_NUMBER: _ClassVar[int]
    packing_units: _containers.RepeatedCompositeFieldContainer[ItemPackingUnit]
    def __init__(self, packing_units: _Optional[_Iterable[_Union[ItemPackingUnit, _Mapping]]] = ...) -> None: ...

class Item(_message.Message):
    __slots__ = ("audit_info", "id", "code", "name", "description", "category", "subcategory", "brand", "model", "sku", "barcode", "provenance", "active_for_sales", "active_for_purchase", "is_sellable", "is_purchasable", "base_uom", "sales_uoms", "purchase_uoms", "min_order_quantity", "packing_units", "short_name", "are_fractional_quantities_allowed")
    AUDIT_INFO_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    CODE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    CATEGORY_FIELD_NUMBER: _ClassVar[int]
    SUBCATEGORY_FIELD_NUMBER: _ClassVar[int]
    BRAND_FIELD_NUMBER: _ClassVar[int]
    MODEL_FIELD_NUMBER: _ClassVar[int]
    SKU_FIELD_NUMBER: _ClassVar[int]
    BARCODE_FIELD_NUMBER: _ClassVar[int]
    PROVENANCE_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_FOR_SALES_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_FOR_PURCHASE_FIELD_NUMBER: _ClassVar[int]
    IS_SELLABLE_FIELD_NUMBER: _ClassVar[int]
    IS_PURCHASABLE_FIELD_NUMBER: _ClassVar[int]
    BASE_UOM_FIELD_NUMBER: _ClassVar[int]
    SALES_UOMS_FIELD_NUMBER: _ClassVar[int]
    PURCHASE_UOMS_FIELD_NUMBER: _ClassVar[int]
    MIN_ORDER_QUANTITY_FIELD_NUMBER: _ClassVar[int]
    PACKING_UNITS_FIELD_NUMBER: _ClassVar[int]
    SHORT_NAME_FIELD_NUMBER: _ClassVar[int]
    ARE_FRACTIONAL_QUANTITIES_ALLOWED_FIELD_NUMBER: _ClassVar[int]
    audit_info: _common_pb2.AuditInfo
    id: str
    code: str
    name: str
    description: str
    category: str
    subcategory: str
    brand: str
    model: str
    sku: str
    barcode: str
    provenance: str
    active_for_sales: bool
    active_for_purchase: bool
    is_sellable: bool
    is_purchasable: bool
    base_uom: ItemUnitOfMeasure
    sales_uoms: ItemUnitOfMeasures
    purchase_uoms: ItemUnitOfMeasures
    min_order_quantity: float
    packing_units: ItemPackingUnits
    short_name: str
    are_fractional_quantities_allowed: bool
    def __init__(self, audit_info: _Optional[_Union[_common_pb2.AuditInfo, _Mapping]] = ..., id: _Optional[str] = ..., code: _Optional[str] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., category: _Optional[str] = ..., subcategory: _Optional[str] = ..., brand: _Optional[str] = ..., model: _Optional[str] = ..., sku: _Optional[str] = ..., barcode: _Optional[str] = ..., provenance: _Optional[str] = ..., active_for_sales: bool = ..., active_for_purchase: bool = ..., is_sellable: bool = ..., is_purchasable: bool = ..., base_uom: _Optional[_Union[ItemUnitOfMeasure, _Mapping]] = ..., sales_uoms: _Optional[_Union[ItemUnitOfMeasures, _Mapping]] = ..., purchase_uoms: _Optional[_Union[ItemUnitOfMeasures, _Mapping]] = ..., min_order_quantity: _Optional[float] = ..., packing_units: _Optional[_Union[ItemPackingUnits, _Mapping]] = ..., short_name: _Optional[str] = ..., are_fractional_quantities_allowed: bool = ...) -> None: ...

class CreateItemRequest(_message.Message):
    __slots__ = ("request_context", "item")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    ITEM_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    item: Item
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., item: _Optional[_Union[Item, _Mapping]] = ...) -> None: ...

class CreateItemResponse(_message.Message):
    __slots__ = ("status", "item")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    ITEM_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    item: Item
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., item: _Optional[_Union[Item, _Mapping]] = ...) -> None: ...

class GetItemRequest(_message.Message):
    __slots__ = ("request_context", "id")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    id: str
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., id: _Optional[str] = ...) -> None: ...

class GetItemResponse(_message.Message):
    __slots__ = ("status", "item")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    ITEM_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    item: Item
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., item: _Optional[_Union[Item, _Mapping]] = ...) -> None: ...

class UpdateItemRequest(_message.Message):
    __slots__ = ("request_context", "item")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    ITEM_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    item: Item
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., item: _Optional[_Union[Item, _Mapping]] = ...) -> None: ...

class UpdateItemResponse(_message.Message):
    __slots__ = ("status", "item")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    ITEM_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    item: Item
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., item: _Optional[_Union[Item, _Mapping]] = ...) -> None: ...

class DeleteItemRequest(_message.Message):
    __slots__ = ("request_context", "id")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    id: str
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., id: _Optional[str] = ...) -> None: ...

class DeleteItemResponse(_message.Message):
    __slots__ = ("status",)
    STATUS_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ...) -> None: ...

class ListItemsRequest(_message.Message):
    __slots__ = ("request_context", "pagination", "active_only", "category", "search_term")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    PAGINATION_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_ONLY_FIELD_NUMBER: _ClassVar[int]
    CATEGORY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_TERM_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    pagination: _common_pb2.PaginationRequest
    active_only: bool
    category: str
    search_term: str
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., pagination: _Optional[_Union[_common_pb2.PaginationRequest, _Mapping]] = ..., active_only: bool = ..., category: _Optional[str] = ..., search_term: _Optional[str] = ...) -> None: ...

class ListItemsResponse(_message.Message):
    __slots__ = ("status", "pagination", "items")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    PAGINATION_FIELD_NUMBER: _ClassVar[int]
    ITEMS_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    pagination: _common_pb2.PaginationResponse
    items: _containers.RepeatedCompositeFieldContainer[Item]
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., pagination: _Optional[_Union[_common_pb2.PaginationResponse, _Mapping]] = ..., items: _Optional[_Iterable[_Union[Item, _Mapping]]] = ...) -> None: ...
