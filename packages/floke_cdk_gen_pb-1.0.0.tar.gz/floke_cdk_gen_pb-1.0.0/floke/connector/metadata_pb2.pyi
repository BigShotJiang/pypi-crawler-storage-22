from third_party.google.api import annotations_pb2 as _annotations_pb2
from third_party.google.gnostic.openapiv3 import annotations_pb2 as _annotations_pb2_1
from floke.common import semver_pb2 as _semver_pb2
from floke.connector import common_pb2 as _common_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class FeatureFlag(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    AUTH_AUTHENTICATE_BASIC: _ClassVar[FeatureFlag]
    AUTH_AUTHENTICATE_API_KEY: _ClassVar[FeatureFlag]
    AUTH_AUTHENTICATE_OAUTH2: _ClassVar[FeatureFlag]
    AUTH_AUTHENTICATE_JWT: _ClassVar[FeatureFlag]
    AUTH_AUTHENTICATE_CUSTOM: _ClassVar[FeatureFlag]
    AUTH_REFRESH: _ClassVar[FeatureFlag]
    BUSINESS_CONTACT_CREATE: _ClassVar[FeatureFlag]
    BUSINESS_CONTACT_READ: _ClassVar[FeatureFlag]
    BUSINESS_CONTACT_UPDATE: _ClassVar[FeatureFlag]
    BUSINESS_CONTACT_DELETE: _ClassVar[FeatureFlag]
    BUSINESS_CONTACT_LIST: _ClassVar[FeatureFlag]
    BUSINESS_PARTNER_CREATE: _ClassVar[FeatureFlag]
    BUSINESS_PARTNER_READ: _ClassVar[FeatureFlag]
    BUSINESS_PARTNER_UPDATE: _ClassVar[FeatureFlag]
    BUSINESS_PARTNER_DELETE: _ClassVar[FeatureFlag]
    BUSINESS_PARTNER_LIST: _ClassVar[FeatureFlag]
    ITEM_CREATE: _ClassVar[FeatureFlag]
    ITEM_READ: _ClassVar[FeatureFlag]
    ITEM_UPDATE: _ClassVar[FeatureFlag]
    ITEM_DELETE: _ClassVar[FeatureFlag]
    ITEM_LIST: _ClassVar[FeatureFlag]
    PRICE_CREATE: _ClassVar[FeatureFlag]
    PRICE_READ: _ClassVar[FeatureFlag]
    PRICE_UPDATE: _ClassVar[FeatureFlag]
    PRICE_DELETE: _ClassVar[FeatureFlag]
    PRICE_LIST: _ClassVar[FeatureFlag]
    SALES_ORDER_CREATE: _ClassVar[FeatureFlag]
    SALES_ORDER_READ: _ClassVar[FeatureFlag]
    SALES_ORDER_UPDATE: _ClassVar[FeatureFlag]
    SALES_ORDER_DELETE: _ClassVar[FeatureFlag]
    SALES_ORDER_LIST: _ClassVar[FeatureFlag]
    SALES_ORDER_LINE_CREATE: _ClassVar[FeatureFlag]
    SALES_ORDER_LINE_READ: _ClassVar[FeatureFlag]
    SALES_ORDER_LINE_UPDATE: _ClassVar[FeatureFlag]
    SALES_ORDER_LINE_DELETE: _ClassVar[FeatureFlag]
    SALES_ORDER_LINE_LIST: _ClassVar[FeatureFlag]
    SALES_QUOTATION_CREATE: _ClassVar[FeatureFlag]
    SALES_QUOTATION_READ: _ClassVar[FeatureFlag]
    SALES_QUOTATION_UPDATE: _ClassVar[FeatureFlag]
    SALES_QUOTATION_DELETE: _ClassVar[FeatureFlag]
    SALES_QUOTATION_LIST: _ClassVar[FeatureFlag]
    SALES_QUOTATION_CONVERT: _ClassVar[FeatureFlag]
    UNIT_OF_MEASUREMENT_CREATE: _ClassVar[FeatureFlag]
    UNIT_OF_MEASUREMENT_READ: _ClassVar[FeatureFlag]
    UNIT_OF_MEASUREMENT_UPDATE: _ClassVar[FeatureFlag]
    UNIT_OF_MEASUREMENT_DELETE: _ClassVar[FeatureFlag]
    UNIT_OF_MEASUREMENT_LIST: _ClassVar[FeatureFlag]
AUTH_AUTHENTICATE_BASIC: FeatureFlag
AUTH_AUTHENTICATE_API_KEY: FeatureFlag
AUTH_AUTHENTICATE_OAUTH2: FeatureFlag
AUTH_AUTHENTICATE_JWT: FeatureFlag
AUTH_AUTHENTICATE_CUSTOM: FeatureFlag
AUTH_REFRESH: FeatureFlag
BUSINESS_CONTACT_CREATE: FeatureFlag
BUSINESS_CONTACT_READ: FeatureFlag
BUSINESS_CONTACT_UPDATE: FeatureFlag
BUSINESS_CONTACT_DELETE: FeatureFlag
BUSINESS_CONTACT_LIST: FeatureFlag
BUSINESS_PARTNER_CREATE: FeatureFlag
BUSINESS_PARTNER_READ: FeatureFlag
BUSINESS_PARTNER_UPDATE: FeatureFlag
BUSINESS_PARTNER_DELETE: FeatureFlag
BUSINESS_PARTNER_LIST: FeatureFlag
ITEM_CREATE: FeatureFlag
ITEM_READ: FeatureFlag
ITEM_UPDATE: FeatureFlag
ITEM_DELETE: FeatureFlag
ITEM_LIST: FeatureFlag
PRICE_CREATE: FeatureFlag
PRICE_READ: FeatureFlag
PRICE_UPDATE: FeatureFlag
PRICE_DELETE: FeatureFlag
PRICE_LIST: FeatureFlag
SALES_ORDER_CREATE: FeatureFlag
SALES_ORDER_READ: FeatureFlag
SALES_ORDER_UPDATE: FeatureFlag
SALES_ORDER_DELETE: FeatureFlag
SALES_ORDER_LIST: FeatureFlag
SALES_ORDER_LINE_CREATE: FeatureFlag
SALES_ORDER_LINE_READ: FeatureFlag
SALES_ORDER_LINE_UPDATE: FeatureFlag
SALES_ORDER_LINE_DELETE: FeatureFlag
SALES_ORDER_LINE_LIST: FeatureFlag
SALES_QUOTATION_CREATE: FeatureFlag
SALES_QUOTATION_READ: FeatureFlag
SALES_QUOTATION_UPDATE: FeatureFlag
SALES_QUOTATION_DELETE: FeatureFlag
SALES_QUOTATION_LIST: FeatureFlag
SALES_QUOTATION_CONVERT: FeatureFlag
UNIT_OF_MEASUREMENT_CREATE: FeatureFlag
UNIT_OF_MEASUREMENT_READ: FeatureFlag
UNIT_OF_MEASUREMENT_UPDATE: FeatureFlag
UNIT_OF_MEASUREMENT_DELETE: FeatureFlag
UNIT_OF_MEASUREMENT_LIST: FeatureFlag

class GetFeatureFlagsRequest(_message.Message):
    __slots__ = ("request_context",)
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    request_context: _common_pb2.BaseContext
    def __init__(self, request_context: _Optional[_Union[_common_pb2.BaseContext, _Mapping]] = ...) -> None: ...

class GetFeatureFlagsResponse(_message.Message):
    __slots__ = ("feature_flags",)
    FEATURE_FLAGS_FIELD_NUMBER: _ClassVar[int]
    feature_flags: _containers.RepeatedScalarFieldContainer[FeatureFlag]
    def __init__(self, feature_flags: _Optional[_Iterable[_Union[FeatureFlag, str]]] = ...) -> None: ...

class GetVersionsRequest(_message.Message):
    __slots__ = ("request_context",)
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    request_context: _common_pb2.BaseContext
    def __init__(self, request_context: _Optional[_Union[_common_pb2.BaseContext, _Mapping]] = ...) -> None: ...

class GetVersionsResponse(_message.Message):
    __slots__ = ("connector_version", "target_versions")
    CONNECTOR_VERSION_FIELD_NUMBER: _ClassVar[int]
    TARGET_VERSIONS_FIELD_NUMBER: _ClassVar[int]
    connector_version: _semver_pb2.SemanticVersion
    target_versions: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, connector_version: _Optional[_Union[_semver_pb2.SemanticVersion, _Mapping]] = ..., target_versions: _Optional[_Iterable[str]] = ...) -> None: ...

class GetMetadataRequest(_message.Message):
    __slots__ = ("request_context",)
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    request_context: _common_pb2.BaseContext
    def __init__(self, request_context: _Optional[_Union[_common_pb2.BaseContext, _Mapping]] = ...) -> None: ...

class GetMetadataResponse(_message.Message):
    __slots__ = ("connector_name", "feature_flags", "versions")
    CONNECTOR_NAME_FIELD_NUMBER: _ClassVar[int]
    FEATURE_FLAGS_FIELD_NUMBER: _ClassVar[int]
    VERSIONS_FIELD_NUMBER: _ClassVar[int]
    connector_name: str
    feature_flags: GetFeatureFlagsResponse
    versions: GetVersionsResponse
    def __init__(self, connector_name: _Optional[str] = ..., feature_flags: _Optional[_Union[GetFeatureFlagsResponse, _Mapping]] = ..., versions: _Optional[_Union[GetVersionsResponse, _Mapping]] = ...) -> None: ...
