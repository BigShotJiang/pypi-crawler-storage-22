from third_party.google.api import annotations_pb2 as _annotations_pb2
from third_party.google.gnostic.openapiv3 import annotations_pb2 as _annotations_pb2_1
from third_party.google.rpc import status_pb2 as _status_pb2
from floke.connector import authentication_pb2 as _authentication_pb2
from floke.internal import descriptor_pb2 as _descriptor_pb2
from floke.connector import common_pb2 as _common_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class PackingUnit(_message.Message):
    __slots__ = ("audit_info", "id", "code", "name", "capacity", "is_unbounded", "description", "base_uom_id", "base_uom_code", "active")
    AUDIT_INFO_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    CODE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    CAPACITY_FIELD_NUMBER: _ClassVar[int]
    IS_UNBOUNDED_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    BASE_UOM_ID_FIELD_NUMBER: _ClassVar[int]
    BASE_UOM_CODE_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_FIELD_NUMBER: _ClassVar[int]
    audit_info: _common_pb2.AuditInfo
    id: str
    code: str
    name: str
    capacity: float
    is_unbounded: bool
    description: str
    base_uom_id: str
    base_uom_code: str
    active: bool
    def __init__(self, audit_info: _Optional[_Union[_common_pb2.AuditInfo, _Mapping]] = ..., id: _Optional[str] = ..., code: _Optional[str] = ..., name: _Optional[str] = ..., capacity: _Optional[float] = ..., is_unbounded: bool = ..., description: _Optional[str] = ..., base_uom_id: _Optional[str] = ..., base_uom_code: _Optional[str] = ..., active: bool = ...) -> None: ...

class CreatePackingUnitRequest(_message.Message):
    __slots__ = ("request_context", "packing_unit")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    PACKING_UNIT_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    packing_unit: PackingUnit
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., packing_unit: _Optional[_Union[PackingUnit, _Mapping]] = ...) -> None: ...

class CreatePackingUnitResponse(_message.Message):
    __slots__ = ("status", "packing_unit")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    PACKING_UNIT_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    packing_unit: PackingUnit
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., packing_unit: _Optional[_Union[PackingUnit, _Mapping]] = ...) -> None: ...

class GetPackingUnitRequest(_message.Message):
    __slots__ = ("request_context", "id")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    id: str
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., id: _Optional[str] = ...) -> None: ...

class GetPackingUnitResponse(_message.Message):
    __slots__ = ("status", "packing_unit")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    PACKING_UNIT_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    packing_unit: PackingUnit
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., packing_unit: _Optional[_Union[PackingUnit, _Mapping]] = ...) -> None: ...

class UpdatePackingUnitRequest(_message.Message):
    __slots__ = ("request_context", "packing_unit")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    PACKING_UNIT_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    packing_unit: PackingUnit
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., packing_unit: _Optional[_Union[PackingUnit, _Mapping]] = ...) -> None: ...

class UpdatePackingUnitResponse(_message.Message):
    __slots__ = ("status", "packing_unit")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    PACKING_UNIT_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    packing_unit: PackingUnit
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., packing_unit: _Optional[_Union[PackingUnit, _Mapping]] = ...) -> None: ...

class DeletePackingUnitRequest(_message.Message):
    __slots__ = ("request_context", "id")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    id: str
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., id: _Optional[str] = ...) -> None: ...

class DeletePackingUnitResponse(_message.Message):
    __slots__ = ("status",)
    STATUS_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ...) -> None: ...

class ListPackingUnitsRequest(_message.Message):
    __slots__ = ("request_context", "pagination", "code", "active_only")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    PAGINATION_FIELD_NUMBER: _ClassVar[int]
    CODE_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_ONLY_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    pagination: _common_pb2.PaginationRequest
    code: str
    active_only: bool
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., pagination: _Optional[_Union[_common_pb2.PaginationRequest, _Mapping]] = ..., code: _Optional[str] = ..., active_only: bool = ...) -> None: ...

class ListPackingUnitsResponse(_message.Message):
    __slots__ = ("status", "pagination", "packing_units")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    PAGINATION_FIELD_NUMBER: _ClassVar[int]
    PACKING_UNITS_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    pagination: _common_pb2.PaginationResponse
    packing_units: _containers.RepeatedCompositeFieldContainer[PackingUnit]
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., pagination: _Optional[_Union[_common_pb2.PaginationResponse, _Mapping]] = ..., packing_units: _Optional[_Iterable[_Union[PackingUnit, _Mapping]]] = ...) -> None: ...
