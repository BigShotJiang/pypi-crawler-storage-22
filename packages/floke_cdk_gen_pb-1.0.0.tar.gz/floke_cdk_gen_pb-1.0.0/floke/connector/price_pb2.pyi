from third_party.google.api import annotations_pb2 as _annotations_pb2
from third_party.google.gnostic.openapiv3 import annotations_pb2 as _annotations_pb2_1
from third_party.google.rpc import status_pb2 as _status_pb2
from floke.connector import authentication_pb2 as _authentication_pb2
from floke.internal import descriptor_pb2 as _descriptor_pb2
from floke.connector import common_pb2 as _common_pb2
from floke.connector import currency_pb2 as _currency_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class Price(_message.Message):
    __slots__ = ("audit_info", "id", "item_id", "business_partner_id", "business_partner_group_id", "base_amount", "discount_percentage", "discount_amount", "discounted_amount", "uom_id", "active", "tax_percentage", "tax_amount", "amount_after_tax")
    AUDIT_INFO_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    BUSINESS_PARTNER_ID_FIELD_NUMBER: _ClassVar[int]
    BUSINESS_PARTNER_GROUP_ID_FIELD_NUMBER: _ClassVar[int]
    BASE_AMOUNT_FIELD_NUMBER: _ClassVar[int]
    DISCOUNT_PERCENTAGE_FIELD_NUMBER: _ClassVar[int]
    DISCOUNT_AMOUNT_FIELD_NUMBER: _ClassVar[int]
    DISCOUNTED_AMOUNT_FIELD_NUMBER: _ClassVar[int]
    UOM_ID_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_FIELD_NUMBER: _ClassVar[int]
    TAX_PERCENTAGE_FIELD_NUMBER: _ClassVar[int]
    TAX_AMOUNT_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_AFTER_TAX_FIELD_NUMBER: _ClassVar[int]
    audit_info: _common_pb2.AuditInfo
    id: str
    item_id: str
    business_partner_id: str
    business_partner_group_id: str
    base_amount: _currency_pb2.CurrencyAmount
    discount_percentage: float
    discount_amount: float
    discounted_amount: _currency_pb2.CurrencyAmount
    uom_id: str
    active: bool
    tax_percentage: float
    tax_amount: float
    amount_after_tax: _currency_pb2.CurrencyAmount
    def __init__(self, audit_info: _Optional[_Union[_common_pb2.AuditInfo, _Mapping]] = ..., id: _Optional[str] = ..., item_id: _Optional[str] = ..., business_partner_id: _Optional[str] = ..., business_partner_group_id: _Optional[str] = ..., base_amount: _Optional[_Union[_currency_pb2.CurrencyAmount, _Mapping]] = ..., discount_percentage: _Optional[float] = ..., discount_amount: _Optional[float] = ..., discounted_amount: _Optional[_Union[_currency_pb2.CurrencyAmount, _Mapping]] = ..., uom_id: _Optional[str] = ..., active: bool = ..., tax_percentage: _Optional[float] = ..., tax_amount: _Optional[float] = ..., amount_after_tax: _Optional[_Union[_currency_pb2.CurrencyAmount, _Mapping]] = ...) -> None: ...

class CreatePriceRequest(_message.Message):
    __slots__ = ("request_context", "price")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    PRICE_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    price: Price
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., price: _Optional[_Union[Price, _Mapping]] = ...) -> None: ...

class CreatePriceResponse(_message.Message):
    __slots__ = ("status", "price")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    PRICE_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    price: Price
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., price: _Optional[_Union[Price, _Mapping]] = ...) -> None: ...

class GetPriceRequest(_message.Message):
    __slots__ = ("request_context", "id")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    id: str
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., id: _Optional[str] = ...) -> None: ...

class GetPriceResponse(_message.Message):
    __slots__ = ("status", "price")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    PRICE_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    price: Price
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., price: _Optional[_Union[Price, _Mapping]] = ...) -> None: ...

class GetItemPriceRequest(_message.Message):
    __slots__ = ("request_context", "id", "business_partner_id", "business_partner_group_id")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    BUSINESS_PARTNER_ID_FIELD_NUMBER: _ClassVar[int]
    BUSINESS_PARTNER_GROUP_ID_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    id: str
    business_partner_id: str
    business_partner_group_id: str
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., id: _Optional[str] = ..., business_partner_id: _Optional[str] = ..., business_partner_group_id: _Optional[str] = ...) -> None: ...

class GetItemPriceResponse(_message.Message):
    __slots__ = ("status", "price")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    PRICE_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    price: Price
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., price: _Optional[_Union[Price, _Mapping]] = ...) -> None: ...

class UpdatePriceRequest(_message.Message):
    __slots__ = ("request_context", "price")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    PRICE_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    price: Price
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., price: _Optional[_Union[Price, _Mapping]] = ...) -> None: ...

class UpdatePriceResponse(_message.Message):
    __slots__ = ("status", "price")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    PRICE_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    price: Price
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., price: _Optional[_Union[Price, _Mapping]] = ...) -> None: ...

class DeletePriceRequest(_message.Message):
    __slots__ = ("request_context", "id")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    id: str
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., id: _Optional[str] = ...) -> None: ...

class DeletePriceResponse(_message.Message):
    __slots__ = ("status",)
    STATUS_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ...) -> None: ...

class ListPricesRequest(_message.Message):
    __slots__ = ("request_context", "pagination", "active_only", "item_id")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    PAGINATION_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_ONLY_FIELD_NUMBER: _ClassVar[int]
    ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    pagination: _common_pb2.PaginationRequest
    active_only: bool
    item_id: str
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., pagination: _Optional[_Union[_common_pb2.PaginationRequest, _Mapping]] = ..., active_only: bool = ..., item_id: _Optional[str] = ...) -> None: ...

class ListPricesResponse(_message.Message):
    __slots__ = ("status", "pagination", "prices")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    PAGINATION_FIELD_NUMBER: _ClassVar[int]
    PRICES_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    pagination: _common_pb2.PaginationResponse
    prices: _containers.RepeatedCompositeFieldContainer[Price]
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., pagination: _Optional[_Union[_common_pb2.PaginationResponse, _Mapping]] = ..., prices: _Optional[_Iterable[_Union[Price, _Mapping]]] = ...) -> None: ...
