from third_party.google.api import annotations_pb2 as _annotations_pb2
from third_party.google.gnostic.openapiv3 import annotations_pb2 as _annotations_pb2_1
from third_party.google.rpc import status_pb2 as _status_pb2
from floke.connector import authentication_pb2 as _authentication_pb2
from floke.internal import descriptor_pb2 as _descriptor_pb2
from floke.connector import common_pb2 as _common_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class Route(_message.Message):
    __slots__ = ("audit_info", "id", "name", "description", "is_active")
    AUDIT_INFO_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    IS_ACTIVE_FIELD_NUMBER: _ClassVar[int]
    audit_info: _common_pb2.AuditInfo
    id: str
    name: str
    description: str
    is_active: bool
    def __init__(self, audit_info: _Optional[_Union[_common_pb2.AuditInfo, _Mapping]] = ..., id: _Optional[str] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., is_active: bool = ...) -> None: ...

class CreateRouteRequest(_message.Message):
    __slots__ = ("request_context", "route")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    ROUTE_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    route: Route
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., route: _Optional[_Union[Route, _Mapping]] = ...) -> None: ...

class CreateRouteResponse(_message.Message):
    __slots__ = ("status", "route")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    ROUTE_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    route: Route
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., route: _Optional[_Union[Route, _Mapping]] = ...) -> None: ...

class GetRouteRequest(_message.Message):
    __slots__ = ("request_context", "id")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    id: str
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., id: _Optional[str] = ...) -> None: ...

class GetRouteResponse(_message.Message):
    __slots__ = ("status", "route")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    ROUTE_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    route: Route
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., route: _Optional[_Union[Route, _Mapping]] = ...) -> None: ...

class UpdateRouteRequest(_message.Message):
    __slots__ = ("request_context", "route")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    ROUTE_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    route: Route
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., route: _Optional[_Union[Route, _Mapping]] = ...) -> None: ...

class UpdateRouteResponse(_message.Message):
    __slots__ = ("status", "route")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    ROUTE_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    route: Route
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., route: _Optional[_Union[Route, _Mapping]] = ...) -> None: ...

class DeleteRouteRequest(_message.Message):
    __slots__ = ("request_context", "id")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    id: str
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., id: _Optional[str] = ...) -> None: ...

class DeleteRouteResponse(_message.Message):
    __slots__ = ("status",)
    STATUS_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ...) -> None: ...

class ListRoutesRequest(_message.Message):
    __slots__ = ("request_context", "pagination", "active_only", "business_id")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    PAGINATION_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_ONLY_FIELD_NUMBER: _ClassVar[int]
    BUSINESS_ID_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    pagination: _common_pb2.PaginationRequest
    active_only: bool
    business_id: str
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., pagination: _Optional[_Union[_common_pb2.PaginationRequest, _Mapping]] = ..., active_only: bool = ..., business_id: _Optional[str] = ...) -> None: ...

class ListRoutesResponse(_message.Message):
    __slots__ = ("status", "pagination", "routes")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    PAGINATION_FIELD_NUMBER: _ClassVar[int]
    ROUTES_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    pagination: _common_pb2.PaginationResponse
    routes: _containers.RepeatedCompositeFieldContainer[Route]
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., pagination: _Optional[_Union[_common_pb2.PaginationResponse, _Mapping]] = ..., routes: _Optional[_Iterable[_Union[Route, _Mapping]]] = ...) -> None: ...
