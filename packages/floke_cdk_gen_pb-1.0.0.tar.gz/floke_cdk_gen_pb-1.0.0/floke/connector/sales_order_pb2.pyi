import datetime

from google.protobuf import timestamp_pb2 as _timestamp_pb2
from third_party.google.rpc import status_pb2 as _status_pb2
from third_party.google.api import annotations_pb2 as _annotations_pb2
from third_party.google.gnostic.openapiv3 import annotations_pb2 as _annotations_pb2_1
from floke.internal import descriptor_pb2 as _descriptor_pb2
from floke.connector import authentication_pb2 as _authentication_pb2
from floke.connector import common_pb2 as _common_pb2
from floke.connector import currency_pb2 as _currency_pb2
from floke.connector import sales_pb2 as _sales_pb2
from floke.connector import item_pb2 as _item_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class SalesOrderStatus(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SO_DRAFT: _ClassVar[SalesOrderStatus]
    SO_CONFIRMED: _ClassVar[SalesOrderStatus]
    SO_SHIPPED: _ClassVar[SalesOrderStatus]
    SO_INVOICED: _ClassVar[SalesOrderStatus]
    SO_CLOSED: _ClassVar[SalesOrderStatus]
    SO_COMPLETED: _ClassVar[SalesOrderStatus]
SO_DRAFT: SalesOrderStatus
SO_CONFIRMED: SalesOrderStatus
SO_SHIPPED: SalesOrderStatus
SO_INVOICED: SalesOrderStatus
SO_CLOSED: SalesOrderStatus
SO_COMPLETED: SalesOrderStatus

class SalesOrderLine(_message.Message):
    __slots__ = ("audit_info", "id", "item_id", "quantity", "item_uom", "uom_id", "uom_code", "unit_price", "total_price", "total_price_discounted", "total_price_after_tax", "order_date", "requested_delivery_date", "expected_delivery_date", "notes", "item_code", "item_name", "external_id", "item", "packing_unit_id", "packing_unit_code")
    AUDIT_INFO_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    QUANTITY_FIELD_NUMBER: _ClassVar[int]
    ITEM_UOM_FIELD_NUMBER: _ClassVar[int]
    UOM_ID_FIELD_NUMBER: _ClassVar[int]
    UOM_CODE_FIELD_NUMBER: _ClassVar[int]
    UNIT_PRICE_FIELD_NUMBER: _ClassVar[int]
    TOTAL_PRICE_FIELD_NUMBER: _ClassVar[int]
    TOTAL_PRICE_DISCOUNTED_FIELD_NUMBER: _ClassVar[int]
    TOTAL_PRICE_AFTER_TAX_FIELD_NUMBER: _ClassVar[int]
    ORDER_DATE_FIELD_NUMBER: _ClassVar[int]
    REQUESTED_DELIVERY_DATE_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_DELIVERY_DATE_FIELD_NUMBER: _ClassVar[int]
    NOTES_FIELD_NUMBER: _ClassVar[int]
    ITEM_CODE_FIELD_NUMBER: _ClassVar[int]
    ITEM_NAME_FIELD_NUMBER: _ClassVar[int]
    EXTERNAL_ID_FIELD_NUMBER: _ClassVar[int]
    ITEM_FIELD_NUMBER: _ClassVar[int]
    PACKING_UNIT_ID_FIELD_NUMBER: _ClassVar[int]
    PACKING_UNIT_CODE_FIELD_NUMBER: _ClassVar[int]
    audit_info: _common_pb2.AuditInfo
    id: str
    item_id: str
    quantity: float
    item_uom: _item_pb2.ItemUnitOfMeasure
    uom_id: str
    uom_code: str
    unit_price: _currency_pb2.CurrencyAmount
    total_price: _currency_pb2.CurrencyAmount
    total_price_discounted: _currency_pb2.CurrencyAmount
    total_price_after_tax: _currency_pb2.CurrencyAmount
    order_date: _timestamp_pb2.Timestamp
    requested_delivery_date: _timestamp_pb2.Timestamp
    expected_delivery_date: _timestamp_pb2.Timestamp
    notes: _containers.RepeatedScalarFieldContainer[str]
    item_code: str
    item_name: str
    external_id: str
    item: _item_pb2.Item
    packing_unit_id: str
    packing_unit_code: str
    def __init__(self, audit_info: _Optional[_Union[_common_pb2.AuditInfo, _Mapping]] = ..., id: _Optional[str] = ..., item_id: _Optional[str] = ..., quantity: _Optional[float] = ..., item_uom: _Optional[_Union[_item_pb2.ItemUnitOfMeasure, _Mapping]] = ..., uom_id: _Optional[str] = ..., uom_code: _Optional[str] = ..., unit_price: _Optional[_Union[_currency_pb2.CurrencyAmount, _Mapping]] = ..., total_price: _Optional[_Union[_currency_pb2.CurrencyAmount, _Mapping]] = ..., total_price_discounted: _Optional[_Union[_currency_pb2.CurrencyAmount, _Mapping]] = ..., total_price_after_tax: _Optional[_Union[_currency_pb2.CurrencyAmount, _Mapping]] = ..., order_date: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., requested_delivery_date: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., expected_delivery_date: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., notes: _Optional[_Iterable[str]] = ..., item_code: _Optional[str] = ..., item_name: _Optional[str] = ..., external_id: _Optional[str] = ..., item: _Optional[_Union[_item_pb2.Item, _Mapping]] = ..., packing_unit_id: _Optional[str] = ..., packing_unit_code: _Optional[str] = ...) -> None: ...

class SalesOrder(_message.Message):
    __slots__ = ("audit_info", "id", "number", "business_partner", "business_contact", "status", "order_date", "requested_delivery_date", "expected_delivery_date", "shipping_address", "billing_address", "lines", "sub_total", "tax_total", "total", "notes", "external_id", "author_user_external_id", "transport_route_id")
    AUDIT_INFO_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    NUMBER_FIELD_NUMBER: _ClassVar[int]
    BUSINESS_PARTNER_FIELD_NUMBER: _ClassVar[int]
    BUSINESS_CONTACT_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    ORDER_DATE_FIELD_NUMBER: _ClassVar[int]
    REQUESTED_DELIVERY_DATE_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_DELIVERY_DATE_FIELD_NUMBER: _ClassVar[int]
    SHIPPING_ADDRESS_FIELD_NUMBER: _ClassVar[int]
    BILLING_ADDRESS_FIELD_NUMBER: _ClassVar[int]
    LINES_FIELD_NUMBER: _ClassVar[int]
    SUB_TOTAL_FIELD_NUMBER: _ClassVar[int]
    TAX_TOTAL_FIELD_NUMBER: _ClassVar[int]
    TOTAL_FIELD_NUMBER: _ClassVar[int]
    NOTES_FIELD_NUMBER: _ClassVar[int]
    EXTERNAL_ID_FIELD_NUMBER: _ClassVar[int]
    AUTHOR_USER_EXTERNAL_ID_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_ROUTE_ID_FIELD_NUMBER: _ClassVar[int]
    audit_info: _common_pb2.AuditInfo
    id: str
    number: str
    business_partner: _sales_pb2.SalesBusinessPartner
    business_contact: _sales_pb2.SalesBusinessContact
    status: SalesOrderStatus
    order_date: _timestamp_pb2.Timestamp
    requested_delivery_date: _timestamp_pb2.Timestamp
    expected_delivery_date: _timestamp_pb2.Timestamp
    shipping_address: _sales_pb2.SalesAddress
    billing_address: _sales_pb2.SalesAddress
    lines: _containers.RepeatedCompositeFieldContainer[SalesOrderLine]
    sub_total: _currency_pb2.CurrencyAmount
    tax_total: _currency_pb2.CurrencyAmount
    total: _currency_pb2.CurrencyAmount
    notes: _containers.RepeatedScalarFieldContainer[str]
    external_id: str
    author_user_external_id: str
    transport_route_id: str
    def __init__(self, audit_info: _Optional[_Union[_common_pb2.AuditInfo, _Mapping]] = ..., id: _Optional[str] = ..., number: _Optional[str] = ..., business_partner: _Optional[_Union[_sales_pb2.SalesBusinessPartner, _Mapping]] = ..., business_contact: _Optional[_Union[_sales_pb2.SalesBusinessContact, _Mapping]] = ..., status: _Optional[_Union[SalesOrderStatus, str]] = ..., order_date: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., requested_delivery_date: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., expected_delivery_date: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., shipping_address: _Optional[_Union[_sales_pb2.SalesAddress, _Mapping]] = ..., billing_address: _Optional[_Union[_sales_pb2.SalesAddress, _Mapping]] = ..., lines: _Optional[_Iterable[_Union[SalesOrderLine, _Mapping]]] = ..., sub_total: _Optional[_Union[_currency_pb2.CurrencyAmount, _Mapping]] = ..., tax_total: _Optional[_Union[_currency_pb2.CurrencyAmount, _Mapping]] = ..., total: _Optional[_Union[_currency_pb2.CurrencyAmount, _Mapping]] = ..., notes: _Optional[_Iterable[str]] = ..., external_id: _Optional[str] = ..., author_user_external_id: _Optional[str] = ..., transport_route_id: _Optional[str] = ...) -> None: ...

class CreateSalesOrderRequestOptions(_message.Message):
    __slots__ = ("dry_run",)
    DRY_RUN_FIELD_NUMBER: _ClassVar[int]
    dry_run: bool
    def __init__(self, dry_run: bool = ...) -> None: ...

class CreateSalesOrderRequest(_message.Message):
    __slots__ = ("request_context", "sales_order", "options")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    SALES_ORDER_FIELD_NUMBER: _ClassVar[int]
    OPTIONS_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    sales_order: SalesOrder
    options: CreateSalesOrderRequestOptions
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., sales_order: _Optional[_Union[SalesOrder, _Mapping]] = ..., options: _Optional[_Union[CreateSalesOrderRequestOptions, _Mapping]] = ...) -> None: ...

class CreateSalesOrderResponse(_message.Message):
    __slots__ = ("status", "sales_order")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    SALES_ORDER_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    sales_order: SalesOrder
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., sales_order: _Optional[_Union[SalesOrder, _Mapping]] = ...) -> None: ...

class GetSalesOrderRequest(_message.Message):
    __slots__ = ("request_context", "id")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    id: str
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., id: _Optional[str] = ...) -> None: ...

class GetSalesOrderResponse(_message.Message):
    __slots__ = ("status", "sales_order")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    SALES_ORDER_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    sales_order: SalesOrder
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., sales_order: _Optional[_Union[SalesOrder, _Mapping]] = ...) -> None: ...

class UpdateSalesOrderRequest(_message.Message):
    __slots__ = ("request_context", "sales_order")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    SALES_ORDER_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    sales_order: SalesOrder
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., sales_order: _Optional[_Union[SalesOrder, _Mapping]] = ...) -> None: ...

class UpdateSalesOrderResponse(_message.Message):
    __slots__ = ("status", "sales_order")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    SALES_ORDER_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    sales_order: SalesOrder
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., sales_order: _Optional[_Union[SalesOrder, _Mapping]] = ...) -> None: ...

class DeleteSalesOrderRequest(_message.Message):
    __slots__ = ("request_context", "id")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    id: str
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., id: _Optional[str] = ...) -> None: ...

class DeleteSalesOrderResponse(_message.Message):
    __slots__ = ("status",)
    STATUS_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ...) -> None: ...

class ListSalesOrdersRequest(_message.Message):
    __slots__ = ("request_context", "pagination", "business_partner_id", "status", "date_from", "date_to", "search_term")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    PAGINATION_FIELD_NUMBER: _ClassVar[int]
    BUSINESS_PARTNER_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    DATE_FROM_FIELD_NUMBER: _ClassVar[int]
    DATE_TO_FIELD_NUMBER: _ClassVar[int]
    SEARCH_TERM_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    pagination: _common_pb2.PaginationRequest
    business_partner_id: str
    status: SalesOrderStatus
    date_from: _timestamp_pb2.Timestamp
    date_to: _timestamp_pb2.Timestamp
    search_term: str
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., pagination: _Optional[_Union[_common_pb2.PaginationRequest, _Mapping]] = ..., business_partner_id: _Optional[str] = ..., status: _Optional[_Union[SalesOrderStatus, str]] = ..., date_from: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., date_to: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., search_term: _Optional[str] = ...) -> None: ...

class ListSalesOrdersResponse(_message.Message):
    __slots__ = ("status", "pagination", "sales_orders")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    PAGINATION_FIELD_NUMBER: _ClassVar[int]
    SALES_ORDERS_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    pagination: _common_pb2.PaginationResponse
    sales_orders: _containers.RepeatedCompositeFieldContainer[SalesOrder]
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., pagination: _Optional[_Union[_common_pb2.PaginationResponse, _Mapping]] = ..., sales_orders: _Optional[_Iterable[_Union[SalesOrder, _Mapping]]] = ...) -> None: ...
