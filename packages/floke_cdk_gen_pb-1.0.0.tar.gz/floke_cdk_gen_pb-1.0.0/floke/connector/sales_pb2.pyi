from floke.connector import contact_pb2 as _contact_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class SalesBusinessPartner(_message.Message):
    __slots__ = ("id", "code", "ship_locations", "bill_locations")
    ID_FIELD_NUMBER: _ClassVar[int]
    CODE_FIELD_NUMBER: _ClassVar[int]
    SHIP_LOCATIONS_FIELD_NUMBER: _ClassVar[int]
    BILL_LOCATIONS_FIELD_NUMBER: _ClassVar[int]
    id: str
    code: str
    ship_locations: _containers.RepeatedCompositeFieldContainer[SalesAddress]
    bill_locations: _containers.RepeatedCompositeFieldContainer[SalesAddress]
    def __init__(self, id: _Optional[str] = ..., code: _Optional[str] = ..., ship_locations: _Optional[_Iterable[_Union[SalesAddress, _Mapping]]] = ..., bill_locations: _Optional[_Iterable[_Union[SalesAddress, _Mapping]]] = ...) -> None: ...

class SalesBusinessContact(_message.Message):
    __slots__ = ("id", "code", "email", "phone_number")
    ID_FIELD_NUMBER: _ClassVar[int]
    CODE_FIELD_NUMBER: _ClassVar[int]
    EMAIL_FIELD_NUMBER: _ClassVar[int]
    PHONE_NUMBER_FIELD_NUMBER: _ClassVar[int]
    id: str
    code: str
    email: str
    phone_number: _contact_pb2.PhoneNumber
    def __init__(self, id: _Optional[str] = ..., code: _Optional[str] = ..., email: _Optional[str] = ..., phone_number: _Optional[_Union[_contact_pb2.PhoneNumber, _Mapping]] = ...) -> None: ...

class SalesAddress(_message.Message):
    __slots__ = ("id", "data", "text")
    ID_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    id: str
    data: _contact_pb2.Address
    text: str
    def __init__(self, id: _Optional[str] = ..., data: _Optional[_Union[_contact_pb2.Address, _Mapping]] = ..., text: _Optional[str] = ...) -> None: ...
