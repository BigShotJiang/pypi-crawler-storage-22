import datetime

from google.protobuf import timestamp_pb2 as _timestamp_pb2
from third_party.google.rpc import status_pb2 as _status_pb2
from third_party.google.api import annotations_pb2 as _annotations_pb2
from third_party.google.gnostic.openapiv3 import annotations_pb2 as _annotations_pb2_1
from floke.connector import authentication_pb2 as _authentication_pb2
from floke.internal import descriptor_pb2 as _descriptor_pb2
from floke.connector import common_pb2 as _common_pb2
from floke.connector import currency_pb2 as _currency_pb2
from floke.connector import sales_order_pb2 as _sales_order_pb2
from floke.connector import sales_pb2 as _sales_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class SalesQuotationStatus(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SQ_DRAFT: _ClassVar[SalesQuotationStatus]
    SQ_SUBMITTED: _ClassVar[SalesQuotationStatus]
    SQ_WON: _ClassVar[SalesQuotationStatus]
    SQ_CLOSED: _ClassVar[SalesQuotationStatus]
SQ_DRAFT: SalesQuotationStatus
SQ_SUBMITTED: SalesQuotationStatus
SQ_WON: SalesQuotationStatus
SQ_CLOSED: SalesQuotationStatus

class SalesQuotationLine(_message.Message):
    __slots__ = ("audit_info", "id", "number", "item_id", "quantity", "uom_id", "uom_code", "unit_price", "total_price", "total_price_discounted", "total_price_after_tax", "expected_delivery_date", "notes", "external_id")
    AUDIT_INFO_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    NUMBER_FIELD_NUMBER: _ClassVar[int]
    ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    QUANTITY_FIELD_NUMBER: _ClassVar[int]
    UOM_ID_FIELD_NUMBER: _ClassVar[int]
    UOM_CODE_FIELD_NUMBER: _ClassVar[int]
    UNIT_PRICE_FIELD_NUMBER: _ClassVar[int]
    TOTAL_PRICE_FIELD_NUMBER: _ClassVar[int]
    TOTAL_PRICE_DISCOUNTED_FIELD_NUMBER: _ClassVar[int]
    TOTAL_PRICE_AFTER_TAX_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_DELIVERY_DATE_FIELD_NUMBER: _ClassVar[int]
    NOTES_FIELD_NUMBER: _ClassVar[int]
    EXTERNAL_ID_FIELD_NUMBER: _ClassVar[int]
    audit_info: _common_pb2.AuditInfo
    id: str
    number: str
    item_id: str
    quantity: float
    uom_id: str
    uom_code: str
    unit_price: _currency_pb2.CurrencyAmount
    total_price: _currency_pb2.CurrencyAmount
    total_price_discounted: _currency_pb2.CurrencyAmount
    total_price_after_tax: _currency_pb2.CurrencyAmount
    expected_delivery_date: _timestamp_pb2.Timestamp
    notes: _containers.RepeatedScalarFieldContainer[str]
    external_id: str
    def __init__(self, audit_info: _Optional[_Union[_common_pb2.AuditInfo, _Mapping]] = ..., id: _Optional[str] = ..., number: _Optional[str] = ..., item_id: _Optional[str] = ..., quantity: _Optional[float] = ..., uom_id: _Optional[str] = ..., uom_code: _Optional[str] = ..., unit_price: _Optional[_Union[_currency_pb2.CurrencyAmount, _Mapping]] = ..., total_price: _Optional[_Union[_currency_pb2.CurrencyAmount, _Mapping]] = ..., total_price_discounted: _Optional[_Union[_currency_pb2.CurrencyAmount, _Mapping]] = ..., total_price_after_tax: _Optional[_Union[_currency_pb2.CurrencyAmount, _Mapping]] = ..., expected_delivery_date: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., notes: _Optional[_Iterable[str]] = ..., external_id: _Optional[str] = ...) -> None: ...

class SalesQuotation(_message.Message):
    __slots__ = ("audit_info", "id", "number", "business_partner", "business_contact", "status", "quotation_date", "valid_until_date", "acceptance_date", "shipping_address", "billing_address", "lines", "sub_total", "tax_total", "total", "notes", "external_id")
    AUDIT_INFO_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    NUMBER_FIELD_NUMBER: _ClassVar[int]
    BUSINESS_PARTNER_FIELD_NUMBER: _ClassVar[int]
    BUSINESS_CONTACT_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    QUOTATION_DATE_FIELD_NUMBER: _ClassVar[int]
    VALID_UNTIL_DATE_FIELD_NUMBER: _ClassVar[int]
    ACCEPTANCE_DATE_FIELD_NUMBER: _ClassVar[int]
    SHIPPING_ADDRESS_FIELD_NUMBER: _ClassVar[int]
    BILLING_ADDRESS_FIELD_NUMBER: _ClassVar[int]
    LINES_FIELD_NUMBER: _ClassVar[int]
    SUB_TOTAL_FIELD_NUMBER: _ClassVar[int]
    TAX_TOTAL_FIELD_NUMBER: _ClassVar[int]
    TOTAL_FIELD_NUMBER: _ClassVar[int]
    NOTES_FIELD_NUMBER: _ClassVar[int]
    EXTERNAL_ID_FIELD_NUMBER: _ClassVar[int]
    audit_info: _common_pb2.AuditInfo
    id: str
    number: str
    business_partner: _sales_pb2.SalesBusinessPartner
    business_contact: _sales_pb2.SalesBusinessContact
    status: SalesQuotationStatus
    quotation_date: _timestamp_pb2.Timestamp
    valid_until_date: _timestamp_pb2.Timestamp
    acceptance_date: _timestamp_pb2.Timestamp
    shipping_address: _sales_pb2.SalesAddress
    billing_address: _sales_pb2.SalesAddress
    lines: _containers.RepeatedCompositeFieldContainer[SalesQuotationLine]
    sub_total: _currency_pb2.CurrencyAmount
    tax_total: _currency_pb2.CurrencyAmount
    total: _currency_pb2.CurrencyAmount
    notes: _containers.RepeatedScalarFieldContainer[str]
    external_id: str
    def __init__(self, audit_info: _Optional[_Union[_common_pb2.AuditInfo, _Mapping]] = ..., id: _Optional[str] = ..., number: _Optional[str] = ..., business_partner: _Optional[_Union[_sales_pb2.SalesBusinessPartner, _Mapping]] = ..., business_contact: _Optional[_Union[_sales_pb2.SalesBusinessContact, _Mapping]] = ..., status: _Optional[_Union[SalesQuotationStatus, str]] = ..., quotation_date: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., valid_until_date: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., acceptance_date: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., shipping_address: _Optional[_Union[_sales_pb2.SalesAddress, _Mapping]] = ..., billing_address: _Optional[_Union[_sales_pb2.SalesAddress, _Mapping]] = ..., lines: _Optional[_Iterable[_Union[SalesQuotationLine, _Mapping]]] = ..., sub_total: _Optional[_Union[_currency_pb2.CurrencyAmount, _Mapping]] = ..., tax_total: _Optional[_Union[_currency_pb2.CurrencyAmount, _Mapping]] = ..., total: _Optional[_Union[_currency_pb2.CurrencyAmount, _Mapping]] = ..., notes: _Optional[_Iterable[str]] = ..., external_id: _Optional[str] = ...) -> None: ...

class CreateSalesQuotationRequest(_message.Message):
    __slots__ = ("request_context", "sales_quotation")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    SALES_QUOTATION_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    sales_quotation: SalesQuotation
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., sales_quotation: _Optional[_Union[SalesQuotation, _Mapping]] = ...) -> None: ...

class CreateSalesQuotationResponse(_message.Message):
    __slots__ = ("status", "sales_quotation")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    SALES_QUOTATION_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    sales_quotation: SalesQuotation
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., sales_quotation: _Optional[_Union[SalesQuotation, _Mapping]] = ...) -> None: ...

class GetSalesQuotationRequest(_message.Message):
    __slots__ = ("request_context", "id")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    id: str
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., id: _Optional[str] = ...) -> None: ...

class GetSalesQuotationResponse(_message.Message):
    __slots__ = ("status", "sales_quotation")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    SALES_QUOTATION_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    sales_quotation: SalesQuotation
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., sales_quotation: _Optional[_Union[SalesQuotation, _Mapping]] = ...) -> None: ...

class UpdateSalesQuotationRequest(_message.Message):
    __slots__ = ("request_context", "sales_quotation")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    SALES_QUOTATION_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    sales_quotation: SalesQuotation
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., sales_quotation: _Optional[_Union[SalesQuotation, _Mapping]] = ...) -> None: ...

class UpdateSalesQuotationResponse(_message.Message):
    __slots__ = ("status", "sales_quotation")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    SALES_QUOTATION_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    sales_quotation: SalesQuotation
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., sales_quotation: _Optional[_Union[SalesQuotation, _Mapping]] = ...) -> None: ...

class DeleteSalesQuotationRequest(_message.Message):
    __slots__ = ("request_context", "id")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    id: str
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., id: _Optional[str] = ...) -> None: ...

class DeleteSalesQuotationResponse(_message.Message):
    __slots__ = ("status",)
    STATUS_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ...) -> None: ...

class ListSalesQuotationsRequest(_message.Message):
    __slots__ = ("request_context", "pagination", "business_partner_id", "status", "date_from", "date_to", "search_term")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    PAGINATION_FIELD_NUMBER: _ClassVar[int]
    BUSINESS_PARTNER_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    DATE_FROM_FIELD_NUMBER: _ClassVar[int]
    DATE_TO_FIELD_NUMBER: _ClassVar[int]
    SEARCH_TERM_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    pagination: _common_pb2.PaginationRequest
    business_partner_id: str
    status: SalesQuotationStatus
    date_from: _timestamp_pb2.Timestamp
    date_to: _timestamp_pb2.Timestamp
    search_term: str
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., pagination: _Optional[_Union[_common_pb2.PaginationRequest, _Mapping]] = ..., business_partner_id: _Optional[str] = ..., status: _Optional[_Union[SalesQuotationStatus, str]] = ..., date_from: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., date_to: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., search_term: _Optional[str] = ...) -> None: ...

class ListSalesQuotationsResponse(_message.Message):
    __slots__ = ("status", "pagination", "sales_quotations")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    PAGINATION_FIELD_NUMBER: _ClassVar[int]
    SALES_QUOTATIONS_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    pagination: _common_pb2.PaginationResponse
    sales_quotations: _containers.RepeatedCompositeFieldContainer[SalesQuotation]
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., pagination: _Optional[_Union[_common_pb2.PaginationResponse, _Mapping]] = ..., sales_quotations: _Optional[_Iterable[_Union[SalesQuotation, _Mapping]]] = ...) -> None: ...

class ConvertQuotationToOrderRequest(_message.Message):
    __slots__ = ("request_context", "id")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    id: str
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., id: _Optional[str] = ...) -> None: ...

class ConvertQuotationToOrderResponse(_message.Message):
    __slots__ = ("status", "sales_order")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    SALES_ORDER_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    sales_order: _sales_order_pb2.SalesOrder
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., sales_order: _Optional[_Union[_sales_order_pb2.SalesOrder, _Mapping]] = ...) -> None: ...
