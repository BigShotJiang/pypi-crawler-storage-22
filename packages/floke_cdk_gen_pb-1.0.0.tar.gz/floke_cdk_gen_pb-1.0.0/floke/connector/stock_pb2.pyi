import datetime

from third_party.google.api import annotations_pb2 as _annotations_pb2
from third_party.google.gnostic.openapiv3 import annotations_pb2 as _annotations_pb2_1
from third_party.google.rpc import status_pb2 as _status_pb2
from floke.connector import authentication_pb2 as _authentication_pb2
from floke.internal import descriptor_pb2 as _descriptor_pb2
from floke.connector import common_pb2 as _common_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class StockLevel(_message.Message):
    __slots__ = ("audit_info", "id", "item_id", "quantity", "committed", "ordered", "uom", "uom_id", "warehouse_id", "warehouse_name", "updated_at")
    AUDIT_INFO_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    QUANTITY_FIELD_NUMBER: _ClassVar[int]
    COMMITTED_FIELD_NUMBER: _ClassVar[int]
    ORDERED_FIELD_NUMBER: _ClassVar[int]
    UOM_FIELD_NUMBER: _ClassVar[int]
    UOM_ID_FIELD_NUMBER: _ClassVar[int]
    WAREHOUSE_ID_FIELD_NUMBER: _ClassVar[int]
    WAREHOUSE_NAME_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    audit_info: _common_pb2.AuditInfo
    id: str
    item_id: str
    quantity: float
    committed: float
    ordered: float
    uom: str
    uom_id: str
    warehouse_id: str
    warehouse_name: str
    updated_at: _timestamp_pb2.Timestamp
    def __init__(self, audit_info: _Optional[_Union[_common_pb2.AuditInfo, _Mapping]] = ..., id: _Optional[str] = ..., item_id: _Optional[str] = ..., quantity: _Optional[float] = ..., committed: _Optional[float] = ..., ordered: _Optional[float] = ..., uom: _Optional[str] = ..., uom_id: _Optional[str] = ..., warehouse_id: _Optional[str] = ..., warehouse_name: _Optional[str] = ..., updated_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class CreateStockLevelsRequest(_message.Message):
    __slots__ = ("request_context", "stock_levels")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    STOCK_LEVELS_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    stock_levels: _containers.RepeatedCompositeFieldContainer[StockLevel]
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., stock_levels: _Optional[_Iterable[_Union[StockLevel, _Mapping]]] = ...) -> None: ...

class CreateStockLevelsResponse(_message.Message):
    __slots__ = ("status", "stock_levels")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    STOCK_LEVELS_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    stock_levels: _containers.RepeatedCompositeFieldContainer[StockLevel]
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., stock_levels: _Optional[_Iterable[_Union[StockLevel, _Mapping]]] = ...) -> None: ...

class GetStockLevelRequest(_message.Message):
    __slots__ = ("request_context", "id")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    id: str
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., id: _Optional[str] = ...) -> None: ...

class GetStockLevelResponse(_message.Message):
    __slots__ = ("status", "stock_level")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    STOCK_LEVEL_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    stock_level: StockLevel
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., stock_level: _Optional[_Union[StockLevel, _Mapping]] = ...) -> None: ...

class GetStockLevelsByItemIdRequest(_message.Message):
    __slots__ = ("request_context", "item_id")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    item_id: str
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., item_id: _Optional[str] = ...) -> None: ...

class GetStockLevelsByItemIdResponse(_message.Message):
    __slots__ = ("status", "stock_levels")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    STOCK_LEVELS_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    stock_levels: _containers.RepeatedCompositeFieldContainer[StockLevel]
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., stock_levels: _Optional[_Iterable[_Union[StockLevel, _Mapping]]] = ...) -> None: ...

class UpdateStockLevelRequest(_message.Message):
    __slots__ = ("request_context", "stock_level")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    STOCK_LEVEL_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    stock_level: StockLevel
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., stock_level: _Optional[_Union[StockLevel, _Mapping]] = ...) -> None: ...

class UpdateStockLevelResponse(_message.Message):
    __slots__ = ("status", "stock_level")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    STOCK_LEVEL_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    stock_level: StockLevel
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., stock_level: _Optional[_Union[StockLevel, _Mapping]] = ...) -> None: ...

class DeleteStockLevelRequest(_message.Message):
    __slots__ = ("request_context", "id")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    id: str
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., id: _Optional[str] = ...) -> None: ...

class DeleteStockLevelResponse(_message.Message):
    __slots__ = ("status",)
    STATUS_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ...) -> None: ...

class ListStockLevelsRequest(_message.Message):
    __slots__ = ("request_context", "pagination", "item_id", "warehouse_id")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    PAGINATION_FIELD_NUMBER: _ClassVar[int]
    ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    WAREHOUSE_ID_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    pagination: _common_pb2.PaginationRequest
    item_id: str
    warehouse_id: str
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., pagination: _Optional[_Union[_common_pb2.PaginationRequest, _Mapping]] = ..., item_id: _Optional[str] = ..., warehouse_id: _Optional[str] = ...) -> None: ...

class ListStockLevelsResponse(_message.Message):
    __slots__ = ("status", "pagination", "stock_levels")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    PAGINATION_FIELD_NUMBER: _ClassVar[int]
    STOCK_LEVELS_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    pagination: _common_pb2.PaginationResponse
    stock_levels: _containers.RepeatedCompositeFieldContainer[StockLevel]
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., pagination: _Optional[_Union[_common_pb2.PaginationResponse, _Mapping]] = ..., stock_levels: _Optional[_Iterable[_Union[StockLevel, _Mapping]]] = ...) -> None: ...
