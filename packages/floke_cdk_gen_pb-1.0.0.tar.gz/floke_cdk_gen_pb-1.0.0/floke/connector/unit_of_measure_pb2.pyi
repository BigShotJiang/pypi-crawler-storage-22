from third_party.google.api import annotations_pb2 as _annotations_pb2
from third_party.google.gnostic.openapiv3 import annotations_pb2 as _annotations_pb2_1
from third_party.google.rpc import status_pb2 as _status_pb2
from floke.connector import authentication_pb2 as _authentication_pb2
from floke.internal import descriptor_pb2 as _descriptor_pb2
from floke.connector import common_pb2 as _common_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class UnitOfMeasure(_message.Message):
    __slots__ = ("audit_info", "id", "code", "name", "description", "active")
    AUDIT_INFO_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    CODE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_FIELD_NUMBER: _ClassVar[int]
    audit_info: _common_pb2.AuditInfo
    id: str
    code: str
    name: str
    description: str
    active: bool
    def __init__(self, audit_info: _Optional[_Union[_common_pb2.AuditInfo, _Mapping]] = ..., id: _Optional[str] = ..., code: _Optional[str] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., active: bool = ...) -> None: ...

class CreateUnitOfMeasureRequest(_message.Message):
    __slots__ = ("request_context", "uom")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    UOM_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    uom: UnitOfMeasure
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., uom: _Optional[_Union[UnitOfMeasure, _Mapping]] = ...) -> None: ...

class CreateUnitOfMeasureResponse(_message.Message):
    __slots__ = ("status", "uom")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    UOM_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    uom: UnitOfMeasure
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., uom: _Optional[_Union[UnitOfMeasure, _Mapping]] = ...) -> None: ...

class GetUnitOfMeasureRequest(_message.Message):
    __slots__ = ("request_context", "id")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    id: str
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., id: _Optional[str] = ...) -> None: ...

class GetUnitOfMeasureResponse(_message.Message):
    __slots__ = ("status", "uom")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    UOM_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    uom: UnitOfMeasure
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., uom: _Optional[_Union[UnitOfMeasure, _Mapping]] = ...) -> None: ...

class UpdateUnitOfMeasureRequest(_message.Message):
    __slots__ = ("request_context", "uom")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    UOM_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    uom: UnitOfMeasure
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., uom: _Optional[_Union[UnitOfMeasure, _Mapping]] = ...) -> None: ...

class UpdateUnitOfMeasureResponse(_message.Message):
    __slots__ = ("status", "uom")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    UOM_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    uom: UnitOfMeasure
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., uom: _Optional[_Union[UnitOfMeasure, _Mapping]] = ...) -> None: ...

class DeleteUnitOfMeasureRequest(_message.Message):
    __slots__ = ("request_context", "id")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    id: str
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., id: _Optional[str] = ...) -> None: ...

class DeleteUnitOfMeasureResponse(_message.Message):
    __slots__ = ("status",)
    STATUS_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ...) -> None: ...

class ListUnitOfMeasuresRequest(_message.Message):
    __slots__ = ("request_context", "pagination", "code", "active_only")
    REQUEST_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    PAGINATION_FIELD_NUMBER: _ClassVar[int]
    CODE_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_ONLY_FIELD_NUMBER: _ClassVar[int]
    request_context: _authentication_pb2.RequestContext
    pagination: _common_pb2.PaginationRequest
    code: str
    active_only: bool
    def __init__(self, request_context: _Optional[_Union[_authentication_pb2.RequestContext, _Mapping]] = ..., pagination: _Optional[_Union[_common_pb2.PaginationRequest, _Mapping]] = ..., code: _Optional[str] = ..., active_only: bool = ...) -> None: ...

class ListUnitOfMeasuresResponse(_message.Message):
    __slots__ = ("status", "pagination", "uoms")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    PAGINATION_FIELD_NUMBER: _ClassVar[int]
    UOMS_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    pagination: _common_pb2.PaginationResponse
    uoms: _containers.RepeatedCompositeFieldContainer[UnitOfMeasure]
    def __init__(self, status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ..., pagination: _Optional[_Union[_common_pb2.PaginationResponse, _Mapping]] = ..., uoms: _Optional[_Iterable[_Union[UnitOfMeasure, _Mapping]]] = ...) -> None: ...
