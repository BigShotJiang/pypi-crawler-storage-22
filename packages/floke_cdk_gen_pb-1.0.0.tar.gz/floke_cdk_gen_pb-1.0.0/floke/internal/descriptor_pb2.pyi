from google.protobuf import descriptor_pb2 as _descriptor_pb2
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from typing import ClassVar as _ClassVar

DESCRIPTOR: _descriptor.FileDescriptor

class FieldDirection(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    UNSPECIFIED: _ClassVar[FieldDirection]
    IN: _ClassVar[FieldDirection]
    OUT: _ClassVar[FieldDirection]
    IN_OUT: _ClassVar[FieldDirection]
UNSPECIFIED: FieldDirection
IN: FieldDirection
OUT: FieldDirection
IN_OUT: FieldDirection
FIELD_DIRECTION_FIELD_NUMBER: _ClassVar[int]
field_direction: _descriptor.FieldDescriptor
