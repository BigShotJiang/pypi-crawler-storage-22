# coding: utf-8

"""
    Floke CDK Protobuf Bindings

    Generated protobuf and gRPC bindings for the Floke Connector API.
"""

from setuptools import setup, find_packages

NAME = "floke-cdk-gen-pb"
VERSION = "1.0.7"

REQUIRES = [
    "protobuf>=4.21.0",
    "grpcio>=1.50.0",
    "googleapis-common-protos>=1.56.0",
]

setup(
    name=NAME,
    version=VERSION,
    description="Floke CDK Protobuf Bindings",
    long_description="Generated protobuf and gRPC bindings for the Floke Connector API.",
    long_description_content_type="text/plain",
    author="Hoshii AI",
    author_email="support@hoshii.ai",
    url="https://github.com/hoshii-ai/floke",
    project_urls={
        "Documentation": "https://github.com/hoshii-ai/floke",
        "Source": "https://github.com/hoshii-ai/floke",
        "Bug Tracker": "https://github.com/hoshii-ai/floke/issues",
    },
    keywords=[],
    install_requires=REQUIRES,
    packages=find_packages(),
    include_package_data=True,
    python_requires=">=3.7",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
)
