# Floowguard Python SDK

A minimal Python client for the Floowguard policy engine, mirroring the Node.js SDK interface.

## Installation

This package depends on `requests`:

```bash
pip install requests
```

(If you package this as a library, include `requests` in your own dependency metadata.)

## Usage

```python
import os
from flowguard import FlowGuardApiClient

application_id = os.environ["FLOOWGUARD_APPLICATION_ID"]
client = FlowGuardApiClient(application_id)

identifier = "ACCOUNT_ID_OR_USER_ID"

# Check if this action should be allowed
allowed = client.has_access(
    policy_name="POST_CREATION_LIMIT_EXAMPLE",
    value=identifier,
)

if not allowed:
    raise RuntimeError("You reached your limit for post creation for today. Try tomorrow.")

# Record the successful action and get the latest count
result = client.increment_and_get_policy_count(
    policy_name="POST_CREATION_LIMIT_EXAMPLE",
    value=identifier,
)

print("Current decision:", result.get("response"))
```
