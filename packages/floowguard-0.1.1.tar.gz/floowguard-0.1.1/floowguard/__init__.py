"""Python client SDK for Floowguard.

Usage example:

    from flowguard import FlowGuardApiClient

    client = FlowGuardApiClient("YOUR_APPLICATION_ID")
    allowed = client.has_access(policy_name="POST_CREATION_LIMIT_EXAMPLE", value="identifier")
"""

from .client import FlowGuardApiClient, PolicyActions, RuleStatus  # noqa: F401
