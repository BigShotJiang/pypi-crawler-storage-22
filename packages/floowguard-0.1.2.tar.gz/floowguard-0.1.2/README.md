# Floowguard Python SDK

A minimal Python client for the Floowguard policy engine, mirroring the official Node.js SDK interface.

## Installation

Install the published package from PyPI:

```bash
pip install floowguard
```

This will also install the required `requests` dependency.

## Usage

```python
import os
from floowguard import FloowGuardApiClient

application_id = os.environ["FLOOWGUARD_APPLICATION_ID"]
client = FloowGuardApiClient(application_id)

identifier = "ACCOUNT_ID_OR_USER_ID"

# Check if this action should be allowed
allowed = client.has_access(
    policy_name="POST_CREATION_LIMIT_EXAMPLE",
    value=identifier,
)

if not allowed:
    raise RuntimeError("You reached your limit for post creation for today. Try tomorrow.")

# Record the successful action and get the latest count
result = client.increment_and_get_policy_count(
    policy_name="POST_CREATION_LIMIT_EXAMPLE",
    value=identifier,
)

print("Current decision:", result.get("response"))
```
