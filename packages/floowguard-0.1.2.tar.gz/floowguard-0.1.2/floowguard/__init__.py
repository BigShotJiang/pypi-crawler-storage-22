"""Python client SDK for Floowguard.

Usage example:

    from floowguard import FloowGuardApiClient

    client = FloowGuardApiClient("YOUR_APPLICATION_ID")
    allowed = client.has_access(policy_name="POST_CREATION_LIMIT_EXAMPLE", value="identifier")
"""

from .client import FloowGuardApiClient, PolicyActions, RuleStatus  # noqa: F401
