"""Input/output channel adapters."""
