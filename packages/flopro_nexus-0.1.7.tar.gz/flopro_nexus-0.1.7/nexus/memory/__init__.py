"""Memory modules for Nexus."""
