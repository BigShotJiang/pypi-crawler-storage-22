# windows
tshark_path = r"C:\Program Files\Wireshark\tshark.exe"

def get_default_tshark_path() -> str:
    return tshark_path