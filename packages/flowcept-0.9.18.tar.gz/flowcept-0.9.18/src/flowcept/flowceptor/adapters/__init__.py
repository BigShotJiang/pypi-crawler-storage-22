"""Adapters subpackage."""
