# flowchem-virtual

`flowchem-virtual` provides **virtual devices (digital twins)** for the hardware implemented in the main `flowchem` [package](https://github.com/automatedchemistry/flowchem).

It’s designed as a **drop-in replacement** for `flowchem` when you want to:

* Develop and debug flows

* Test configuration files

* Run CI pipelines

…without having the physical hardware connected.


# Installation

```bash
pip install flowchem-virtual
```

# Usage

If you already know how `flowchem` works, using `flowchem-virtual` is straightforward.

Normally, you would start a flowchem server with:

```bash
flowchem /path/to/configuration_file.toml
```

To use the virtual devices instead, simply run:

```bash
flowchem-virtual /path/to/configuration_file.toml
```

`flowchem-virtual` will:

* Read the same configuration file

* Expose **virtual counterparts** of all devices defined there

* Keep the same API and behavior as much as possible, but without touching real hardware

This makes it a convenient **simulation layer** for your existing setups.

# When should I use flowchem-virtual?

Typical scenarios:

* 💻 **Local development** of client code without access to the lab

* 🧪 **Unit tests / CI** where hardware is not available (or not desirable)

* 📦 **Trying out configuration changes** before deploying them to a real setup

* 📚 **Teaching and demos** of flowchem-based automation

# Tips

If you are **not yet familiar with flowchem**, it’s highly recommended to learn the basics there first.

👉 [flowchem documentation](https://flowchem.readthedocs.io/en/latest/)

Once you understand how devices and configuration files work in `flowchem`, switching to the virtual version is just a matter of changing the command from:
```bash
flowchem ...
```
to:
```bash
flowchem-virtual ...
```

# Limitations

* Virtual devices **do not control real hardware** (obviously 😄).

* Most part of device-specific behavior (e.g. exact timing, error states) may be simplified.

* If your code depends on very low-level hardware quirks, the virtual version might not reproduce them perfectly.

# Contributing

Pull requests, bug reports and feature requests are welcome!

# License

This project is licensed under the MIT License – see the LICENSE file for details.
