from flowchem.devices.biochem.solenoid_valve import (
    BioChemSolenoidValve,
    SolenoidValve,
    SolenoidValve2Way,
)
from flowchem.components.technical.relay import Relay

from loguru import logger
import asyncio


class VirtualBioChemSolenoidValve(BioChemSolenoidValve):
    async def initialize(self):
        n = 0
        while self.support_platform not in Relay.INSTANCES:
            await asyncio.sleep(0.5)
            n += 1
            if n > 6:
                raise Exception(
                    f"The relay support_platform '{self.support_platform}' was not declared or initialized. "
                    "The valve cannot be initialized without a support_platform "
                    f"(Please add '{self.support_platform}' to the configuration file!)."
                )

        self._io = Relay.INSTANCES[self.support_platform]
        # Register the standard SolenoidValve component/API on this device
        self.components.append(SolenoidValve("valve", self))
        conf_valve = "normally open" if self.normally_open else "normally closed"
        logger.info(
            f"Connected to Virtual BioChemSolenoidValve {conf_valve} on "
            f"'{self.support_platform}' channel {self.channel}!"
        )


class VirtualBioChemSolenoid2WayValve(VirtualBioChemSolenoidValve):
    async def initialize(self):
        n = 0
        while self.support_platform not in Relay.INSTANCES:
            await asyncio.sleep(0.5)
            n += 1
            if n > 6:
                raise Exception(
                    f"The relay support_platform '{self.support_platform}' was not declared or initialized. "
                    "The valve cannot be initialized without a support_platform "
                    f"(Please add '{self.support_platform}' to the configuration file!)."
                )

        self._io = Relay.INSTANCES[self.support_platform]
        # Register the standard SolenoidValve component/API on this device
        self.components.append(SolenoidValve2Way("valve", self))
        conf_valve = "normally open" if self.normally_open else "normally closed"
        logger.info(
            f"Connected to Virtual BioChemSolenoidValve {conf_valve} on "
            f"'{self.support_platform}' channel {self.channel}!"
        )
