"""custom devices__."""
from .virtual_peltier_cooler import VirtualPeltierCooler
from .virtual_mpikg_box import VirtualSwitchBoxMPIKG

__all__ = ["VirtualPeltierCooler", "VirtualSwitchBoxMPIKG"]
