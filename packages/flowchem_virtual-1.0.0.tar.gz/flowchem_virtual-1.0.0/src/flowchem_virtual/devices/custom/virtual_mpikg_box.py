from flowchem.devices.custom.mpikg_switch_box import SwitchBoxMPIKG
from flowchem.devices.custom.mpikg_switch_box_component import (
    SwitchBoxADC,
    SwitchBoxRelay,
    SwitchBoxDAC,
)
from pint.registry import Quantity
from loguru import logger


class VirtualSwitchBoxMPIKG(SwitchBoxMPIKG):
    """Switch Box MPIKG module class"""

    def __init__(self, box_io, name: str = "") -> None:
        super().__init__(box_io, name)

        self.rele = [0] * 32
        self.ADC = [0]
        self.DAC = [0]

    @classmethod
    def from_config(
        cls,
        port: str,
        name: str = "",
        **serial_kwargs,
    ):
        return cls(box_io="switch_io", name=name)

    async def initialize(self):
        self.device_info.version = "Virtual"
        self.components.extend(
            [
                SwitchBoxADC("adc", self),
                SwitchBoxDAC("dac", self),
                SwitchBoxRelay("relay-A", self, "a"),  # Channel 1 to 8
                SwitchBoxRelay("relay-B", self, "b"),  # Channel 9 to 16
                SwitchBoxRelay("relay-C", self, "c"),  # Channel 17 to 24
                SwitchBoxRelay("relay-D", self, "d"),  # Channel 25 to 32
            ]
        )

        logger.info("Connected to Virtual SwitchBoxMPIKG!")

    async def set_relay_port(self, values: list[int], port: str = "a"):
        map_ch = {"a": 0, "b": 7, "c": 15, "d": 23}
        n = len(values)
        if n >= 8:
            self.rele[map_ch[port] : map_ch[port] + 8] = values[:8]
        else:
            self.rele[map_ch[port] : map_ch[port] + 8] = values + [0] * (
                8 - len(values)
            )
        return True

    async def set_relay_single_channel(
        self,
        channel: int,
        value: int = 2,
        keep_port_status=True,
        port_identify: str = "a",
    ):
        if channel > 8:
            self.rele[channel] = value
        else:
            map_ch = {"a": 0, "b": 7, "c": 15, "d": 23}
            self.rele[map_ch[port_identify] + channel] = value
        return True

    async def get_relay_channels(self):
        return {
            "a": self.rele[:8],
            "b": self.rele[8:16],
            "c": self.rele[16:24],
            "d": self.rele[24:],
        }

    """ ADC/DAC Commands """

    async def get_adc(self):
        return {f"ADC{i}": v for i, v in enumerate(self.ADC)}

    async def get_dac(self, channel: int = 1, volts: bool = True):
        return self.DAC[channel - 1]

    async def set_dac(self, value: Quantity, channel: int = 1) -> bool:
        self.DAC[channel - 1] = value.to("V").magnitude
        return True
