"""Huber's devices__."""
from .virtual_chiller import VirtualHuberChiller

__all__ = ["VirtualHuberChiller"]
