"""Magritek Spinsolve."""
from .virtual_spinsolve import VirtualSpinsolve

__all__ = ["VirtualSpinsolve"]
