"""Manson devices__."""
from .virtual_manson_power import VirtualMansonPowerSupply

__all__ = ["VirtualMansonPowerSupply"]
