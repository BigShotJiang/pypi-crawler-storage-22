"""Phidget-based devices__."""
from .virtuals import (
    VirtualPhidgetPressureSensor,
    VirtualPhidgetBubbleSensor,
    VirtualPhidgetPowerSource5V,
)

__all__ = [
    "VirtualPhidgetBubbleSensor",
    "VirtualPhidgetPowerSource5V",
    "VirtualPhidgetPressureSensor",
]
