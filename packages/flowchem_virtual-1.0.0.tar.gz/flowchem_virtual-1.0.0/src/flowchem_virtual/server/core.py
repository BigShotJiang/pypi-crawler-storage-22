from flowchem.devices.list_known_device_type import is_device_class
from flowchem.devices.flowchem_device import FlowchemDevice
from flowchem.server.configuration_parser import parse_config, parse_device
from flowchem.server.core import Flowchem
import flowchem_virtual.devices
from pathlib import Path
from io import BytesIO
from loguru import logger
from copy import deepcopy
import asyncio
import inspect


def instantiate_device_from_config(config: dict) -> list[FlowchemDevice]:
    """Instantiate all devices__ defined in the provided config dict."""
    assert "device" in config, "The configuration file must include a device section"

    for name, __config in config["device"].items():
        config["device"][name]["type"] = "Virtual" + __config["type"]

    module = flowchem_virtual.devices
    # device_mapper is a dict mapping device type (str, as key) with the device class (obj, value).
    # e.g. device_mapper["Spinsolve"] = Spinsolve class
    device_classes = inspect.getmembers(module, is_device_class)
    logger.debug(f"Found {len(device_classes)} device type(s) in {module.__name__}")
    device_mapper = {obj_class[0]: obj_class[1] for obj_class in device_classes}

    # Iterate on all devices__, parse device-specific settings and instantiate the relevant objects
    return [
        parse_device(dev_settings, device_mapper)
        for dev_settings in config["device"].items()
    ]


class FlowchemVirtual(Flowchem):
    async def setup(self, config: BytesIO | Path):
        self.config = parse_config(config)
        self.http.configuration_dict = deepcopy(self.config)
        self.devices = instantiate_device_from_config(self.config)

        """Initialize connection to devices__ and create API endpoints."""
        logger.info("Initializing device connection(s)...")

        # Run `initialize` async method of all hw devices__ in parallel
        await asyncio.gather(*[dev.initialize() for dev in self.devices])
        logger.info("Device(s) connected")

        # Create entities for the configured devices__.
        for device in self.devices:
            # Advertise devices__ as services via mDNS
            await self.mdns.add_device(name=device.name)
            # Add device API to HTTP server
            self.http.add_device(device)
        logger.info("Server component(s) loaded successfully!")
