import { _ as _sfc_main } from "./SingleSelect.vue_vue_type_script_setup_true_lang-Rxht5Z5N.js";
import "./index-bcuE0Z0p.js";
export {
  _sfc_main as default
};
