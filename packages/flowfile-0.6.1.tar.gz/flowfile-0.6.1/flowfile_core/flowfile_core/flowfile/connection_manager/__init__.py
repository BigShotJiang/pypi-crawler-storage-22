from flowfile_core.flowfile.connection_manager._connection_manager import ConnectionManager

connection_manager = ConnectionManager()
