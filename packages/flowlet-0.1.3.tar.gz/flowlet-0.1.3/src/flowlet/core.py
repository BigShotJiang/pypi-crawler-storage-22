import asyncio
import atexit
import contextvars
import hashlib
import inspect
import json
import logging
import os
import queue
import sys
import textwrap
import threading
import time
import urllib.request
import uuid


class Input:
    def __init__(self, typ, desc=""):
        self.type = typ
        self.desc = desc
        self.name = None

    def __repr__(self):
        return f"Input(name={self.name!r}, type={self.type}, desc={self.desc!r})"


class _OutputRef:
    def __init__(self, node, key):
        self.node = node
        self.key = key

    def __repr__(self):
        return f"OutputRef(node={self.node.name!r}, key={self.key!r})"


class _OptionalRef:
    def __init__(self, src):
        self.src = src

    def __repr__(self):
        return f"OptionalRef(src={self.src!r})"


def optional(src):
    return _OptionalRef(src)


class _SkipValue:
    def __repr__(self):
        return "SKIP"


SKIP = _SkipValue()


class _Node:
    def __init__(self, func, inputs, outputs, when=None, name=None):
        self.func = func
        self.inputs = inputs or {}
        self.outputs = outputs or {}
        self.when = when
        if name is None:
            node_name = func.__name__
        else:
            if not isinstance(name, str):
                raise TypeError("node name must be a string")
            node_name = name.strip()
            if not node_name:
                raise ValueError("node name cannot be empty")
        self.name = node_name
        self.output_keys = list(self.outputs.keys())
        self.__name__ = func.__name__
        self.__doc__ = func.__doc__

    def __call__(self, *args, **kwargs):
        return self.func(*args, **kwargs)

    def __getattr__(self, item):
        if item in self.outputs:
            return _OutputRef(self, item)
        raise AttributeError(f"{self.name} has no output {item!r}")

    def __repr__(self):
        return f"Node(name={self.name!r})"


def node(inputs=None, outputs=None, when=None, name=None):
    def decorator(func):
        return _Node(func, inputs, outputs, when=when, name=name)
    return decorator


def _collect_inputs(inputs_cls):
    inputs = {}
    for name, value in inputs_cls.__dict__.items():
        if isinstance(value, Input):
            value.name = name
            inputs[name] = value
    return inputs


def _collect_nodes(namespace):
    return [value for value in namespace.values() if isinstance(value, _Node)]


class _WorkflowContext:
    def __init__(self, logger=None, trace_id=None, run_id=None):
        self.logger = logger or logging.getLogger("workflow")
        self.trace_id = trace_id or uuid.uuid4().hex
        self.run_id = run_id or uuid.uuid4().hex
        self.timings = {}
        self.skipped = {}
        self.results = {}
        self.outputs = {}
        self.logs = {}
        self.start_time = None
        self.end_time = None


_current_node = contextvars.ContextVar("workflow_current_node", default=None)


class _ContextLogHandler(logging.Handler):
    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx

    def emit(self, record):
        node_name = _current_node.get()
        if not node_name:
            return
        entry = {
            "time": record.created,
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        if record.pathname:
            entry["pathname"] = record.pathname
        if record.lineno:
            entry["lineno"] = record.lineno
        if record.exc_info:
            entry["exc_info"] = self.formatException(record.exc_info)
        self.ctx.logs.setdefault(node_name, []).append(entry)


def _attach_log_handler(ctx, level=logging.INFO):
    handler = _ContextLogHandler(ctx)
    handler.setLevel(logging.NOTSET)
    root = logging.getLogger()
    old_level = root.level
    if old_level > level:
        root.setLevel(level)
    root.addHandler(handler)
    return handler, root, old_level


def _detach_log_handler(handler, root, old_level=None):
    if handler and root:
        root.removeHandler(handler)
        if old_level is not None:
            root.setLevel(old_level)


_HOOK_ENV_URL = "FLOWLET_HOOK_URL"
_HOOK_ENV_TIMEOUT = "FLOWLET_HOOK_TIMEOUT"
_HOOK_ENV_MAX_QUEUE = "FLOWLET_HOOK_MAX_QUEUE"
_HOOK_ENV_WORKFLOW_ID = "FLOWLET_WORKFLOW_ID"
_HOOK_ENV_FLUSH_TIMEOUT = "FLOWLET_HOOK_FLUSH_TIMEOUT"

_HOOK_SENDER = None
_HOOK_SENDER_LOCK = threading.Lock()


def _env_float(name, default):
    value = os.environ.get(name)
    if value is None:
        return default
    try:
        return float(value)
    except ValueError:
        return default


def _env_int(name, default):
    value = os.environ.get(name)
    if value is None:
        return default
    try:
        return int(value)
    except ValueError:
        return default


def _to_jsonable(value):
    if value is SKIP:
        return "SKIP"
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {str(k): _to_jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_to_jsonable(v) for v in value]
    return repr(value)


def _post_json(url, payload, timeout):
    data = json.dumps(payload, ensure_ascii=True).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        resp.read()


class _HookSender:
    def __init__(self, url, timeout=1.0, max_queue=1000, flush_timeout=0.5):
        self.url = url
        self.timeout = timeout
        self.flush_timeout = flush_timeout
        self.queue = queue.Queue(maxsize=max_queue)
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()
        atexit.register(self.flush)

    def send(self, payload):
        try:
            self.queue.put_nowait(payload)
        except queue.Full:
            try:
                self.queue.get_nowait()
            except queue.Empty:
                return
            try:
                self.queue.put_nowait(payload)
            except queue.Full:
                return

    def _run(self):
        while True:
            payload = self.queue.get()
            try:
                _post_json(self.url, payload, self.timeout)
            except Exception:
                pass
            finally:
                self.queue.task_done()

    def flush(self, timeout=None):
        if timeout is None:
            timeout = self.flush_timeout
        try:
            timeout = float(timeout)
        except (TypeError, ValueError):
            timeout = self.flush_timeout
        if timeout is not None and timeout <= 0:
            return
        deadline = None
        if timeout is not None:
            deadline = time.time() + timeout
        while True:
            if deadline is not None and time.time() >= deadline:
                break
            try:
                payload = self.queue.get_nowait()
            except queue.Empty:
                break
            try:
                _post_json(self.url, payload, self.timeout)
            except Exception:
                pass
            finally:
                self.queue.task_done()


def _get_hook_sender():
    url = os.environ.get(_HOOK_ENV_URL)
    if not url:
        return None
    global _HOOK_SENDER
    if _HOOK_SENDER is None or _HOOK_SENDER.url != url:
        with _HOOK_SENDER_LOCK:
            if _HOOK_SENDER is None or _HOOK_SENDER.url != url:
                timeout = _env_float(_HOOK_ENV_TIMEOUT, 1.0)
                max_queue = _env_int(_HOOK_ENV_MAX_QUEUE, 1000)
                flush_timeout = _env_float(_HOOK_ENV_FLUSH_TIMEOUT, 0.5)
                _HOOK_SENDER = _HookSender(
                    url,
                    timeout=timeout,
                    max_queue=max_queue,
                    flush_timeout=flush_timeout,
                )
    return _HOOK_SENDER


def _get_workflow_id():
    return os.environ.get(_HOOK_ENV_WORKFLOW_ID)


def _workflow_path_from_inputs(inputs_cls):
    module = sys.modules.get(inputs_cls.__module__)
    path = None
    if module is not None:
        path = getattr(module, "__file__", None)
    if not path:
        try:
            path = inspect.getsourcefile(inputs_cls)
        except (TypeError, OSError):
            path = None
    if path:
        try:
            return os.path.abspath(path)
        except (OSError, ValueError):
            return path
    return None


def _hook_send(payload):
    sender = _get_hook_sender()
    if not sender:
        return
    sender.send(_to_jsonable(payload))


def _strip_decorators(source_text):
    if not source_text:
        return source_text
    lines = source_text.splitlines()
    start = 0
    for idx, line in enumerate(lines):
        stripped = line.lstrip()
        if stripped.startswith("def ") or stripped.startswith("async def "):
            start = idx
            break
    return "\n".join(lines[start:]).strip()


def _node_description(node):
    doc = node.__doc__ or ""
    return textwrap.dedent(doc).strip()


def _build_graph_payload(compiled, include_source=False):
    ordered_nodes = compiled.get("flat_order") or []
    inputs_payload = []
    for name, inp in compiled["inputs"].items():
        type_name = getattr(inp.type, "__name__", None) if inp.type else None
        if type_name is None and inp.type is not None:
            type_name = str(inp.type)
        inputs_payload.append({
            "name": name,
            "type": type_name,
            "description": inp.desc,
        })

    nodes_payload = []
    for node in ordered_nodes:
        description = _node_description(node)
        source = ""
        if include_source:
            try:
                source = textwrap.dedent(inspect.getsource(node.func)).strip()
                source = _strip_decorators(source)
            except (OSError, TypeError):
                source = ""
        nodes_payload.append({
            "name": node.name,
            "inputs": list(node.inputs.keys()),
            "outputs": _to_jsonable(dict(node.outputs)),
            "description": description,
            "source": source,
        })

    edges_payload = []
    for node in compiled["nodes"]:
        for input_name, src in node.inputs.items():
            optional_input = False
            if isinstance(src, _OptionalRef):
                optional_input = True
                src = src.src
            if isinstance(src, _OutputRef):
                edges_payload.append({
                    "source": src.node.name,
                    "target": node.name,
                    "source_output": src.key,
                    "target_input": input_name,
                    "optional": optional_input,
                })

    levels_payload = [
        [node.name for node in level]
        for level in compiled["order"]
    ]
    return {
        "inputs": inputs_payload,
        "nodes": nodes_payload,
        "edges": edges_payload,
        "levels": levels_payload,
    }


def _build_graph_core(compiled):
    inputs_payload = []
    for name, inp in compiled["inputs"].items():
        type_name = getattr(inp.type, "__name__", None) if inp.type else None
        if type_name is None and inp.type is not None:
            type_name = str(inp.type)
        inputs_payload.append({
            "name": name,
            "type": type_name,
            "description": inp.desc,
        })

    nodes_payload = []
    ordered_nodes = compiled.get("flat_order") or []
    for node in ordered_nodes:
        nodes_payload.append({
            "name": node.name,
            "inputs": list(node.inputs.keys()),
            "outputs": _to_jsonable(dict(node.outputs)),
        })

    edges_payload = []
    for node in compiled["nodes"]:
        for input_name, src in node.inputs.items():
            optional_input = False
            if isinstance(src, _OptionalRef):
                optional_input = True
                src = src.src
            if isinstance(src, _OutputRef):
                edges_payload.append({
                    "source": src.node.name,
                    "target": node.name,
                    "source_output": src.key,
                    "target_input": input_name,
                    "optional": optional_input,
                })

    levels_payload = [
        [node.name for node in level]
        for level in compiled["order"]
    ]

    return {
        "inputs": inputs_payload,
        "nodes": nodes_payload,
        "edges": edges_payload,
        "levels": levels_payload,
    }


def _ensure_graph_hash(compiled):
    if "graph_hash" in compiled:
        return compiled["graph_hash"]
    core = _build_graph_core(compiled)
    payload = json.dumps(core, sort_keys=True, separators=(",", ":"))
    compiled["graph_hash"] = hashlib.sha256(payload.encode("utf-8")).hexdigest()
    return compiled["graph_hash"]


def _maybe_send_graph_hook(compiled, inputs_cls):
    sender = _get_hook_sender()
    if not sender:
        return
    graph_hash = _ensure_graph_hash(compiled)
    graph = _build_graph_payload(compiled, include_source=True)
    workflow_id = compiled.get("workflow_id") or _get_workflow_id()
    workflow_path = compiled.get("workflow_path") or _workflow_path_from_inputs(inputs_cls)
    payload = {
        "event": "workflow.graph",
        "schema_version": 1,
        "workflow_hash": graph_hash,
        "workflow_id": workflow_id,
        "workflow_name": f"{inputs_cls.__module__}.{inputs_cls.__name__}",
        "workflow_path": workflow_path,
        "timestamp": time.time(),
        "graph": graph,
    }
    sender.send(_to_jsonable(payload))


def _build_graph(nodes):
    deps = {node: set() for node in nodes}
    adj = {node: set() for node in nodes}
    for node in nodes:
        for src in node.inputs.values():
            if isinstance(src, _OptionalRef):
                src = src.src
            if isinstance(src, _OutputRef):
                if src.node not in deps:
                    raise ValueError(f"Unknown node dependency: {src.node}")
                deps[node].add(src.node)
                adj[src.node].add(node)
    return deps, adj


def _toposort_levels(nodes, deps, adj):
    indeg = {node: len(deps[node]) for node in nodes}
    queue = [node for node in nodes if indeg[node] == 0]
    levels = []
    order = []
    while queue:
        level = list(queue)
        levels.append(level)
        queue = []
        for node in level:
            order.append(node)
            for nxt in adj[node]:
                indeg[nxt] -= 1
                if indeg[nxt] == 0:
                    queue.append(nxt)
    if len(order) != len(nodes):
        raise ValueError("Circular dependency detected.")
    return levels, order


def _validate_signatures(nodes):
    for node in nodes:
        sig = inspect.signature(node.func)
        params = sig.parameters
        param_names = set(params.keys())
        has_var_kw = any(p.kind == inspect.Parameter.VAR_KEYWORD for p in params.values())

        invalid_inputs = [name for name in node.inputs.keys() if name not in param_names]
        if invalid_inputs and not has_var_kw:
            raise ValueError(
                f"{node.name} has inputs {invalid_inputs} not present in "
                f"function signature {list(param_names)}"
            )

        missing_required = []
        for name, p in params.items():
            if p.kind in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD):
                continue
            if p.kind == inspect.Parameter.POSITIONAL_ONLY:
                if p.default is inspect._empty:
                    missing_required.append(name)
                continue
            if p.default is inspect._empty and name not in node.inputs:
                missing_required.append(name)

        if missing_required:
            raise ValueError(
                f"{node.name} is missing required inputs: {missing_required} "
                f"(signature: {sig})"
            )

        for name, p in params.items():
            if p.kind == inspect.Parameter.POSITIONAL_ONLY and name in node.inputs:
                raise ValueError(
                    f"{node.name} uses positional-only parameter {name}; "
                    "workflow injection only supports keyword arguments"
                )


def _validate_node_names(nodes):
    seen = set()
    for node in nodes:
        if node.name in seen:
            raise ValueError(f"Duplicate node name: {node.name!r}")
        seen.add(node.name)


def workflow_compile(inputs_cls, namespace=None):
    if namespace is None:
        module = sys.modules.get(inputs_cls.__module__)
        namespace = module.__dict__ if module else globals()
    inputs = _collect_inputs(inputs_cls)
    nodes = _collect_nodes(namespace)
    _validate_node_names(nodes)
    _validate_signatures(nodes)
    deps, adj = _build_graph(nodes)
    levels, order = _toposort_levels(nodes, deps, adj)
    compiled = {
        "inputs": inputs,
        "nodes": nodes,
        "order": levels,
        "flat_order": order,
        "workflow_id": _get_workflow_id(),
        "workflow_path": _workflow_path_from_inputs(inputs_cls),
    }
    _ensure_graph_hash(compiled)
    _maybe_send_graph_hook(compiled, inputs_cls)
    return compiled


def workflow_compile_graph(inputs_cls, namespace=None):
    compiled = workflow_compile(inputs_cls, namespace)
    return _build_graph_payload(compiled, include_source=True)


def _load_params_from_data(inputs, data):
    if data is None:
        data = {}
    if not isinstance(data, dict):
        raise ValueError("Parameters must be a JSON object.")
    params = {}
    for name, inp in inputs.items():
        if name not in data:
            raise ValueError(f"Missing input parameter: {name}")
        value = data[name]
        if inp.type is None:
            params[name] = value
            continue
        try:
            params[name] = inp.type(value)
        except Exception as exc:
            raise ValueError(
                f"Parameter {name} cannot be converted to {inp.type}: {value}"
            ) from exc
    return params


def _load_params(inputs):
    raw = os.environ.get("WORKFLOW_PARAM", "{}")
    try:
        data = json.loads(raw) if raw else {}
    except json.JSONDecodeError as exc:
        raise ValueError(f"WORKFLOW_PARAM is not valid JSON: {raw}") from exc
    return _load_params_from_data(inputs, data)


def _normalize_outputs(node, result):
    if not node.output_keys:
        return {}
    if len(node.output_keys) == 1:
        return {node.output_keys[0]: result}
    if isinstance(result, dict):
        missing = [key for key in node.output_keys if key not in result]
        if missing:
            raise ValueError(f"{node.name} is missing outputs: {missing}")
        return {key: result[key] for key in node.output_keys}
    if isinstance(result, (list, tuple)) and len(result) == len(node.output_keys):
        return dict(zip(node.output_keys, result))
    raise ValueError(f"{node.name} output does not match declared outputs")


def _resolve_kwargs(node, params, results):
    kwargs = {}
    missing_required = []
    for name, src in node.inputs.items():
        optional_input = False
        if isinstance(src, _OptionalRef):
            optional_input = True
            src = src.src
        if isinstance(src, Input):
            kwargs[name] = params[src.name]
        elif isinstance(src, _OutputRef):
            if src.node not in results:
                if optional_input:
                    kwargs[name] = None
                else:
                    missing_required.append(name)
                continue
            value = results[src.node].get(src.key, SKIP)
            if value is SKIP:
                if optional_input:
                    kwargs[name] = None
                else:
                    missing_required.append(name)
                continue
            kwargs[name] = value
        else:
            kwargs[name] = src
    return kwargs, missing_required


def _skip_outputs(node):
    if not node.output_keys:
        return {}
    return {key: SKIP for key in node.output_keys}


def _call_when(node, kwargs, ctx):
    if node.when is None:
        return True
    try:
        sig = inspect.signature(node.when)
    except (TypeError, ValueError):
        return bool(node.when(**kwargs))
    params = sig.parameters
    has_var_kw = any(p.kind == inspect.Parameter.VAR_KEYWORD for p in params.values())
    if has_var_kw:
        call_kwargs = dict(kwargs)
    else:
        call_kwargs = {k: v for k, v in kwargs.items() if k in params}
    if "ctx" in params:
        call_kwargs["ctx"] = ctx
    return bool(node.when(**call_kwargs))


def _final_output(compiled, results):
    last_node = None
    flat_order = compiled.get("flat_order") or []
    if flat_order:
        last_node = flat_order[-1]
    return results.get(last_node) if last_node else None


async def _workflow_run_async(compiled, params=None):
    ctx = _WorkflowContext()
    if params is None:
        params = _load_params(compiled["inputs"])
    else:
        params = _load_params_from_data(compiled["inputs"], params)
    results = {}
    levels = compiled.get("order") or []
    graph_hash = compiled.get("graph_hash") or _ensure_graph_hash(compiled)
    workflow_id = compiled.get("workflow_id") or _get_workflow_id()
    workflow_path = compiled.get("workflow_path")
    max_concurrency = max((len(level) for level in levels), default=0)
    sem = asyncio.Semaphore(max_concurrency) if max_concurrency else None
    ctx.start_time = time.perf_counter()
    log_handler, log_root, log_old_level = _attach_log_handler(ctx)
    error = None
    final_output = None
    ctx.logger.info(
        "workflow start trace_id=%s run_id=%s", ctx.trace_id, ctx.run_id
    )
    sender = _get_hook_sender()
    if sender:
        start_payload = {
            "event": "workflow.run_start",
            "schema_version": 1,
            "workflow_hash": graph_hash,
            "workflow_id": workflow_id,
            "trace_id": ctx.trace_id,
            "run_id": ctx.run_id,
            "workflow_path": workflow_path,
            "timestamp": time.time(),
            "params": _to_jsonable(params),
        }
        sender.send(_to_jsonable(start_payload))

    async def _run_node(node):
        token = _current_node.set(node.name)
        try:
            kwargs, missing_required = _resolve_kwargs(node, params, results)
            if missing_required:
                ctx.skipped[node.name] = f"missing inputs: {missing_required}"
                ctx.timings[node.name] = 0.0
                output = _skip_outputs(node)
                ctx.outputs[node.name] = output
                return node, output
            if not _call_when(node, kwargs, ctx):
                ctx.skipped[node.name] = "condition false"
                ctx.timings[node.name] = 0.0
                output = _skip_outputs(node)
                ctx.outputs[node.name] = output
                return node, output
            node_start = time.perf_counter()
            async def _call():
                result = await _execute_node(node, kwargs)
                return node, _normalize_outputs(node, result)
            if sem:
                async with sem:
                    node, output = await _call()
            else:
                node, output = await _call()
            ctx.timings[node.name] = time.perf_counter() - node_start
            ctx.outputs[node.name] = output
            ctx.logger.debug("node done name=%s elapsed=%.6fs", node.name, ctx.timings[node.name])
            return node, output
        finally:
            _current_node.reset(token)

    async def _execute_node(node, kwargs):
        if inspect.iscoroutinefunction(node.func):
            result = await node.func(**kwargs)
        else:
            result = node.func(**kwargs)
        if inspect.isawaitable(result):
            result = await result
        return result

    try:
        for level_index, level in enumerate(levels):
            tasks = [asyncio.create_task(_run_node(node)) for node in level]
            for node, output in await asyncio.gather(*tasks):
                results[node] = output
            sender = _get_hook_sender()
            if sender:
                nodes_payload = []
                for node in level:
                    status = "skipped" if node.name in ctx.skipped else "ok"
                    entry = {
                        "name": node.name,
                        "status": status,
                        "elapsed": ctx.timings.get(node.name, 0.0),
                    }
                    if status == "skipped":
                        entry["skipped_reason"] = ctx.skipped.get(node.name)
                    entry["outputs"] = _to_jsonable(ctx.outputs.get(node.name, {}))
                    entry["logs"] = _to_jsonable(ctx.logs.get(node.name, []))
                    nodes_payload.append(entry)
                payload = {
                    "event": "workflow.level_done",
                    "schema_version": 1,
                    "workflow_hash": graph_hash,
                    "workflow_id": workflow_id,
                    "trace_id": ctx.trace_id,
                    "run_id": ctx.run_id,
                    "level_index": level_index,
                    "workflow_path": workflow_path,
                    "timestamp": time.time(),
                    "nodes": nodes_payload,
                }
                sender.send(_to_jsonable(payload))
        final_output = _final_output(compiled, results)
    except Exception as exc:
        error = exc
        raise
    finally:
        ctx.end_time = time.perf_counter()
        ctx.logger.info(
            "workflow end trace_id=%s run_id=%s elapsed=%.6fs",
            ctx.trace_id,
            ctx.run_id,
            ctx.end_time - ctx.start_time,
        )
        sender = _get_hook_sender()
        if sender:
            end_payload = {
                "event": "workflow.run_end",
                "schema_version": 1,
                "workflow_hash": graph_hash,
                "workflow_id": workflow_id,
                "trace_id": ctx.trace_id,
                "run_id": ctx.run_id,
                "workflow_path": workflow_path,
                "timestamp": time.time(),
                "elapsed": ctx.end_time - ctx.start_time,
                "status": "error" if error else "ok",
                "error": repr(error) if error else None,
                "output": _to_jsonable(final_output),
            }
            sender.send(_to_jsonable(end_payload))
            try:
                sender.flush()
            except Exception:
                pass
        _detach_log_handler(log_handler, log_root, log_old_level)
    ctx.results = results
    return ctx, final_output


def workflow_run(compiled, params=None):
    return asyncio.run(
        _workflow_run_async(compiled, params=params)
    )

__all__ = ['workflow_run', 'node', 'Input', 'workflow_compile', 'workflow', 'optional', 'SKIP', 'workflow_compile_graph']
