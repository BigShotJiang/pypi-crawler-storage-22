import argparse
import json
import mimetypes
import os
import pkgutil
import threading
import time
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import unquote

from ..core import (
    workflow_compile,
    workflow_run,
    _build_graph_payload,
    _ensure_graph_hash,
    _to_jsonable,
)


def _read_json_body(handler):
    length = int(handler.headers.get("Content-Length", "0"))
    if length <= 0:
        return None
    raw = handler.rfile.read(length)
    try:
        return json.loads(raw.decode("utf-8"))
    except json.JSONDecodeError:
        return None


def _resource_path(rel_path):
    if not rel_path:
        return "ui/index.html"
    rel_path = rel_path.lstrip("/")
    rel_path = unquote(rel_path)
    if ".." in rel_path.split("/"):
        return None
    return f"ui/{rel_path}"


def workflow_server(
    inputs_cls,
    namespace=None,
    host="127.0.0.1",
    port=8777,
    auto_compile=True,
):
    state_lock = threading.Lock()
    state = {
        "graph": None,
        "graph_meta": None,
        "last_event": None,
        "last_run": None,
    }
    compiled_holder = {"compiled": None}
    workflow_name = f"{inputs_cls.__module__}.{inputs_cls.__name__}"

    def _update_graph(compiled):
        graph_hash = compiled.get("graph_hash") or _ensure_graph_hash(compiled)
        graph = _build_graph_payload(compiled, include_source=True)
        timestamp = time.time()
        meta = {
            "workflow_hash": graph_hash,
            "workflow_id": compiled.get("workflow_id"),
            "workflow_name": workflow_name,
            "workflow_path": compiled.get("workflow_path"),
            "schema_version": 1,
            "timestamp": timestamp,
        }
        last_event = {
            "event": "workflow.graph",
            "timestamp": timestamp,
            "workflow_hash": graph_hash,
        }
        with state_lock:
            state["graph"] = graph
            state["graph_meta"] = meta
            state["last_event"] = last_event
        return graph, meta

    def _compile():
        compiled = workflow_compile(inputs_cls, namespace)
        compiled_holder["compiled"] = compiled
        return _update_graph(compiled)

    def _run(params):
        if compiled_holder["compiled"] is None:
            _compile()
        compiled = compiled_holder["compiled"]
        ctx, output = workflow_run(compiled, params=params)
        elapsed = None
        if ctx.start_time and ctx.end_time:
            elapsed = ctx.end_time - ctx.start_time
        payload = {
            "status": "ok",
            "output": _to_jsonable(output),
            "ctx": {
                "trace_id": ctx.trace_id,
                "run_id": ctx.run_id,
                "timings": _to_jsonable(ctx.timings),
                "skipped": _to_jsonable(ctx.skipped),
                "outputs": _to_jsonable(ctx.outputs),
                "logs": _to_jsonable(ctx.logs),
                "elapsed": elapsed,
            },
        }
        timestamp = time.time()
        last_event = {
            "event": "workflow.run_end",
            "timestamp": timestamp,
            "workflow_hash": compiled.get("graph_hash"),
        }
        with state_lock:
            state["last_run"] = payload
            state["last_event"] = last_event
        return payload

    class DevHandler(BaseHTTPRequestHandler):
        server_version = "flowlet-dev/0.2"

        def _send_json(self, payload, status=HTTPStatus.OK):
            body = json.dumps(payload, ensure_ascii=True).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)

        def _send_text(self, text, status=HTTPStatus.OK, content_type="text/plain; charset=utf-8"):
            body = text.encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)

        def _serve_static(self, rel_path):
            resource_path = _resource_path(rel_path)
            if not resource_path:
                self._send_text("not found", status=HTTPStatus.NOT_FOUND)
                return
            try:
                data = pkgutil.get_data("flowlet.dev", resource_path)
            except FileNotFoundError:
                data = None
            if data is None:
                if resource_path.endswith("favicon.ico"):
                    self._send_text("", status=HTTPStatus.NO_CONTENT)
                    return
                self._send_text("not found", status=HTTPStatus.NOT_FOUND)
                return
            mime, _ = mimetypes.guess_type(resource_path)
            if not mime:
                mime = "application/octet-stream"
            self.send_response(HTTPStatus.OK)
            self.send_header("Content-Type", mime)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(data)

        def do_GET(self):
            if self.path.startswith("/api/graph"):
                if state["graph"] is None:
                    try:
                        _compile()
                    except Exception:
                        pass
                with state_lock:
                    graph = state["graph"]
                    meta = state["graph_meta"]
                    last_event = state["last_event"]
                    last_run = state["last_run"]
                self._send_json({
                    "graph": graph,
                    "meta": meta,
                    "last_event": last_event,
                    "last_run": last_run,
                })
                return
            if self.path.startswith("/api/status"):
                with state_lock:
                    last_event = state["last_event"]
                    last_run = state["last_run"]
                self._send_json({"last_event": last_event, "last_run": last_run})
                return
            rel_path = self.path
            if "?" in rel_path:
                rel_path = rel_path.split("?", 1)[0]
            if rel_path == "/":
                rel_path = "/index.html"
            self._serve_static(rel_path)

        def do_POST(self):
            if self.path.startswith("/api/compile"):
                try:
                    graph, meta = _compile()
                except Exception as exc:
                    self._send_json({"status": "error", "error": repr(exc)}, status=HTTPStatus.INTERNAL_SERVER_ERROR)
                    return
                self._send_json({"status": "ok", "graph": graph, "meta": meta})
                return
            if self.path.startswith("/api/run"):
                payload = _read_json_body(self)
                if payload is None:
                    self._send_json({"status": "error", "error": "invalid json"}, status=HTTPStatus.BAD_REQUEST)
                    return
                if not isinstance(payload, dict):
                    self._send_json({"status": "error", "error": "payload must be an object"}, status=HTTPStatus.BAD_REQUEST)
                    return
                params = payload.get("params")
                if params is None and isinstance(payload, dict):
                    params = payload
                try:
                    run_payload = _run(params)
                except Exception as exc:
                    error_payload = {"status": "error", "error": repr(exc)}
                    with state_lock:
                        state["last_run"] = error_payload
                        state["last_event"] = {
                            "event": "workflow.run_error",
                            "timestamp": time.time(),
                            "workflow_hash": None,
                        }
                    self._send_json(error_payload, status=HTTPStatus.INTERNAL_SERVER_ERROR)
                    return
                self._send_json(run_payload)
                return
            if self.path.startswith("/hook"):
                payload = _read_json_body(self)
                if payload is None:
                    self._send_text("invalid json", status=HTTPStatus.BAD_REQUEST)
                    return
                event = payload.get("event")
                with state_lock:
                    state["last_event"] = {
                        "event": event,
                        "timestamp": payload.get("timestamp"),
                        "workflow_hash": payload.get("workflow_hash"),
                    }
                    if event == "workflow.graph":
                        state["graph"] = payload.get("graph")
                        state["graph_meta"] = {
                            "workflow_hash": payload.get("workflow_hash"),
                            "workflow_id": payload.get("workflow_id"),
                            "workflow_name": payload.get("workflow_name"),
                            "workflow_path": payload.get("workflow_path"),
                            "schema_version": payload.get("schema_version"),
                            "timestamp": payload.get("timestamp"),
                        }
                self._send_text("ok", status=HTTPStatus.NO_CONTENT)
                return
            self._send_text("not found", status=HTTPStatus.NOT_FOUND)

        def log_message(self, fmt, *args):
            if os.environ.get("FLOWLET_DEV_SILENT"):
                return
            super().log_message(fmt, *args)

    if auto_compile:
        try:
            _compile()
        except Exception:
            pass

    server = ThreadingHTTPServer((host, port), DevHandler)
    print(f"Flowlet dev server: http://{host}:{port}")
    print("API endpoints: /api/graph, /api/compile, /api/run")
    print("Hook endpoint: /hook")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass


def main():
    parser = argparse.ArgumentParser(description="Flowlet dev server")
    parser.add_argument("workflow", nargs="?", help="module:InputsClass")
    parser.add_argument("--host", default="127.0.0.1", help="bind host (default: 127.0.0.1)")
    parser.add_argument("--port", type=int, default=8777, help="port (default: 8777)")
    args = parser.parse_args()

    if not args.workflow:
        raise SystemExit("workflow is required (example: your_module:Inputs)")

    module_name, _, attr = args.workflow.partition(":")
    if not module_name or not attr:
        raise SystemExit("workflow must look like module:InputsClass")

    module = __import__(module_name, fromlist=[attr])
    inputs_cls = getattr(module, attr, None)
    if inputs_cls is None:
        raise SystemExit(f"Inputs class {attr!r} not found in module {module_name!r}")

    workflow_server(inputs_cls, namespace=module.__dict__, host=args.host, port=args.port)


if __name__ == "__main__":
    main()
