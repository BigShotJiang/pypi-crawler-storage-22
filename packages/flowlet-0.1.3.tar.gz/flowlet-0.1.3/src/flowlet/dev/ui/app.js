const state = {
  graph: null,
  meta: null,
  lastEvent: null,
  selected: null,
  run: null,
  paramValues: {},
  lastRunKey: null,
};

const POLL_MS = 1200;

const statusEl = document.getElementById("status");
const graphEl = document.getElementById("graph");
const workflowNameEl = document.getElementById("workflow-name");
const workflowMetaEl = document.getElementById("workflow-meta");
const detailEl = document.getElementById("node-detail");
const lastUpdatedEl = document.getElementById("last-updated");
const compileBtn = document.getElementById("compile-btn");
const runBtn = document.getElementById("run-btn");
const paramsEl = document.getElementById("run-params");
const runStatusEl = document.getElementById("run-status");
const runSummaryEl = document.getElementById("run-summary");

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/\"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function formatTimestamp(ts) {
  if (!ts) return "";
  try {
    const date = new Date(ts * 1000);
    return date.toLocaleString();
  } catch (_) {
    return String(ts);
  }
}

function setStatus(text, ok = false) {
  statusEl.textContent = text;
  statusEl.style.background = ok
    ? "rgba(25, 100, 126, 0.12)"
    : "rgba(25, 100, 126, 0.06)";
}

function setRunStatus(text, ok = false) {
  if (!runStatusEl) {
    return;
  }
  runStatusEl.textContent = text;
  runStatusEl.style.background = ok
    ? "rgba(25, 100, 126, 0.12)"
    : "rgba(25, 100, 126, 0.06)";
}

function prettyJson(value) {
  try {
    return JSON.stringify(value, null, 2);
  } catch (_) {
    return String(value);
  }
}

function safeId(name) {
  return `param-${String(name).replace(/[^a-zA-Z0-9_-]/g, "-")}`;
}

function detectInputKind(typeName) {
  const raw = (typeName || "").toLowerCase();
  if (!raw) return { kind: "text", label: "text" };
  if (raw.includes("datetime")) return { kind: "datetime", label: typeName };
  if (raw.includes("date")) return { kind: "date", label: typeName };
  if (raw.includes("bool")) return { kind: "boolean", label: typeName };
  if (raw.includes("int")) return { kind: "number-int", label: typeName };
  if (raw.includes("float") || raw.includes("double") || raw.includes("number")) {
    return { kind: "number-float", label: typeName };
  }
  if (raw.includes("str") || raw.includes("string") || raw === "text") {
    return { kind: "text", label: typeName };
  }
  if (raw.includes("list") || raw.includes("array") || raw.includes("tuple") || raw.includes("set")) {
    return { kind: "json-array", label: typeName };
  }
  if (raw.includes("dict") || raw.includes("map") || raw.includes("object")) {
    return { kind: "json", label: typeName };
  }
  return { kind: "text", label: typeName };
}

function renderParamInputs(graph) {
  if (!paramsEl) return;
  paramsEl.innerHTML = "";
  if (!graph || !graph.inputs || !graph.inputs.length) {
    paramsEl.innerHTML = '<div class="detail-empty">No inputs declared.</div>';
    return;
  }

  graph.inputs.forEach((inp) => {
    const typeName = inp.type || "text";
    const kindInfo = detectInputKind(typeName);
    const row = document.createElement("div");
    row.className = "param-row";

    const label = document.createElement("label");
    label.className = "param-label";
    label.setAttribute("for", safeId(inp.name));
    const nameSpan = document.createElement("span");
    nameSpan.textContent = inp.name;
    const typeSpan = document.createElement("span");
    typeSpan.className = "param-type";
    typeSpan.textContent = typeName;
    label.appendChild(nameSpan);
    label.appendChild(typeSpan);

    const control = document.createElement("div");
    control.className = "param-control";

    let field;
    if (kindInfo.kind === "boolean") {
      field = document.createElement("input");
      field.type = "checkbox";
      field.className = "param-checkbox";
      field.checked = Boolean(state.paramValues[inp.name]);
    } else if (kindInfo.kind === "number-int" || kindInfo.kind === "number-float") {
      field = document.createElement("input");
      field.type = "number";
      field.step = kindInfo.kind === "number-int" ? "1" : "any";
      field.className = "param-input";
      if (state.paramValues[inp.name] !== undefined) {
        field.value = state.paramValues[inp.name];
      }
    } else if (kindInfo.kind === "date" || kindInfo.kind === "datetime") {
      field = document.createElement("input");
      field.type = kindInfo.kind === "date" ? "date" : "datetime-local";
      field.className = "param-input";
      if (state.paramValues[inp.name] !== undefined) {
        field.value = state.paramValues[inp.name];
      }
    } else if (kindInfo.kind === "json" || kindInfo.kind === "json-array") {
      field = document.createElement("textarea");
      field.className = "param-textarea";
      const defaultValue = kindInfo.kind === "json-array" ? "[]" : "{}";
      field.value = state.paramValues[inp.name] !== undefined ? state.paramValues[inp.name] : defaultValue;
    } else {
      field = document.createElement("input");
      field.type = "text";
      field.className = "param-input";
      if (state.paramValues[inp.name] !== undefined) {
        field.value = state.paramValues[inp.name];
      }
    }

    field.id = safeId(inp.name);
    field.dataset.param = inp.name;
    field.dataset.kind = kindInfo.kind;
    const updateValue = () => {
      if (kindInfo.kind === "boolean") {
        state.paramValues[inp.name] = field.checked;
      } else {
        state.paramValues[inp.name] = field.value;
      }
      field.classList.remove("param-error");
    };
    field.addEventListener("input", updateValue);
    field.addEventListener("change", updateValue);

    control.appendChild(field);
    if (inp.description) {
      const desc = document.createElement("div");
      desc.className = "param-desc";
      desc.textContent = inp.description;
      control.appendChild(desc);
    }

    row.appendChild(label);
    row.appendChild(control);
    paramsEl.appendChild(row);
  });
}

function collectParams() {
  const params = {};
  const errors = [];
  if (!paramsEl) return { params, errors };

  paramsEl.querySelectorAll("[data-param]").forEach((field) => {
    const name = field.dataset.param;
    const kind = field.dataset.kind || "text";
    field.classList.remove("param-error");

    if (kind === "boolean") {
      params[name] = field.checked;
      return;
    }

    const raw = field.value != null ? String(field.value) : "";
    if (kind === "number-int" || kind === "number-float") {
      if (!raw.trim()) {
        errors.push(`${name} is required`);
        field.classList.add("param-error");
        return;
      }
      const value = Number(raw);
      if (!Number.isFinite(value)) {
        errors.push(`${name} must be a number`);
        field.classList.add("param-error");
        return;
      }
      if (kind === "number-int" && !Number.isInteger(value)) {
        errors.push(`${name} must be an integer`);
        field.classList.add("param-error");
        return;
      }
      params[name] = value;
      return;
    }

    if (kind === "json" || kind === "json-array") {
      if (!raw.trim()) {
        errors.push(`${name} is required`);
        field.classList.add("param-error");
        return;
      }
      try {
        const parsed = JSON.parse(raw);
        if (kind === "json-array" && !Array.isArray(parsed)) {
          errors.push(`${name} must be a JSON array`);
          field.classList.add("param-error");
          return;
        }
        params[name] = parsed;
      } catch (err) {
        errors.push(`${name} has invalid JSON`);
        field.classList.add("param-error");
      }
      return;
    }

    if (kind === "date" || kind === "datetime") {
      if (!raw.trim()) {
        errors.push(`${name} is required`);
        field.classList.add("param-error");
        return;
      }
      params[name] = raw;
      return;
    }

    params[name] = raw;
  });

  return { params, errors };
}

function renderValue(value) {
  if (value === null || value === undefined) {
    return "<em>null</em>";
  }
  if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") {
    return `<span class="mono">${escapeHtml(String(value))}</span>`;
  }
  return `<pre>${escapeHtml(prettyJson(value))}</pre>`;
}

function renderOutputList(outputs) {
  if (!outputs || !Object.keys(outputs).length) {
    return "<em>No outputs</em>";
  }
  const rows = Object.entries(outputs).map(([key, value]) => `
    <div class="kv-row">
      <div class="kv-key">${escapeHtml(key)}</div>
      <div class="kv-value">${renderValue(value)}</div>
    </div>
  `);
  return `<div class="kv-list">${rows.join("")}</div>`;
}

function renderLogs(logs) {
  if (!logs || !logs.length) {
    return "<em>No logs</em>";
  }
  return logs.map((entry) => {
    const meta = [
      entry.time ? formatTimestamp(entry.time) : null,
      entry.level || null,
      entry.logger || null,
    ].filter(Boolean).join(" · ");
    const excInfo = entry.exc_info
      ? `<pre class="log-exc">${escapeHtml(entry.exc_info)}</pre>`
      : "";
    return `
      <div class="log-entry">
        <div class="log-meta">${escapeHtml(meta)}</div>
        <div class="log-message">${escapeHtml(entry.message || "")}</div>
        ${excInfo}
      </div>
    `;
  }).join("");
}

function renderRunDetail(nodeName) {
  if (!state.run) {
    return '<div class="detail-empty">No runs yet.</div>';
  }
  if (state.run.status === "error") {
    return `
      <div class="run-card">
        <div class="run-status error">run failed</div>
        <div>${escapeHtml(state.run.error || "Unknown error")}</div>
      </div>
    `;
  }
  const skippedReason = state.run.skipped && state.run.skipped[nodeName];
  const hasOutput = state.run.outputs && Object.prototype.hasOwnProperty.call(state.run.outputs, nodeName);
  const elapsed = state.run.timings ? state.run.timings[nodeName] : null;
  const statusLabel = skippedReason ? "skipped" : hasOutput ? "ok" : "not executed";
  const statusClass = skippedReason ? "skipped" : "";
  const outputs = hasOutput ? state.run.outputs[nodeName] : null;
  const logs = state.run.logs ? state.run.logs[nodeName] : null;

  return `
    <div class="run-card">
      <div class="run-status ${statusClass}">${statusLabel}</div>
      <div class="kv-list">
        <div class="kv-row">
          <div class="kv-key">Elapsed</div>
          <div class="kv-value">${elapsed != null ? `${elapsed.toFixed(3)}s` : "—"}</div>
        </div>
        ${skippedReason ? `
          <div class="kv-row">
            <div class="kv-key">Skipped</div>
            <div class="kv-value">${escapeHtml(skippedReason)}</div>
          </div>
        ` : ""}
      </div>
      <div class="detail-section">
        <div class="detail-title">Outputs</div>
        ${renderOutputList(outputs)}
      </div>
      <div class="detail-section">
        <div class="detail-title">Logs</div>
        ${renderLogs(logs)}
      </div>
    </div>
  `;
}

function renderDetail(node) {
  if (!detailEl) return;
  if (!node) {
    detailEl.classList.add("hidden");
    return;
  }
  const inputs = node.inputs || [];
  const outputs = node.outputs || {};
  const desc = node.description || "";
  const source = node.source || "";

  const outputKeys = Object.keys(outputs);
  const inputsHtml = inputs.length
    ? inputs.map((name) => `<span class="tag">${escapeHtml(name)}</span>`).join("")
    : "<em>None</em>";
  const outputsHtml = outputKeys.length
    ? outputKeys.map((name) => `<span class="tag">${escapeHtml(name)}</span>`).join("")
    : "<em>None</em>";

  detailEl.innerHTML = `
    <div class="node-detail-head">
      <div class="node-detail-title">${escapeHtml(node.name)}</div>
      <button class="node-detail-close" type="button" data-close>&times;</button>
    </div>
    <div><strong>Inputs:</strong> ${inputsHtml}</div>
    <div style="margin-top: 6px;"><strong>Outputs:</strong> ${outputsHtml}</div>
    <div class="detail-section">
      <div class="detail-title">Run</div>
      ${renderRunDetail(node.name)}
    </div>
    <div class="detail-section">
      <div class="detail-title">Description</div>
      <div>${desc ? escapeHtml(desc) : "<em>No description</em>"}</div>
    </div>
    <div class="detail-section">
      <div class="detail-title">Source</div>
      <pre>${source ? escapeHtml(source) : "# No source attached"}</pre>
    </div>
  `;

  const closeBtn = detailEl.querySelector("[data-close]");
  if (closeBtn) {
    closeBtn.addEventListener("click", () => {
      detailEl.classList.add("hidden");
      state.selected = null;
      applySelection();
    }, { once: true });
  }
  detailEl.classList.remove("hidden");
}

function renderMeta(meta) {
  if (!meta) {
    workflowNameEl.textContent = "No workflow yet";
    workflowMetaEl.textContent = "";
    return;
  }
  workflowNameEl.textContent = meta.workflow_name || "Unnamed workflow";
  const lines = [];
  if (meta.workflow_hash) lines.push(`hash ${meta.workflow_hash.slice(0, 10)}`);
  if (meta.workflow_id) lines.push(`id ${meta.workflow_id}`);
  if (meta.workflow_path) lines.push(meta.workflow_path);
  workflowMetaEl.innerHTML = lines.map(escapeHtml).join("<br>");
}

function renderGraph(graph) {
  graphEl.innerHTML = "";
  if (!graph) {
    graphEl.innerHTML = '<div class="detail-empty">Waiting for a workflow graph. Click <span class="mono">Compile</span> to generate.</div>';
    return;
  }

  const nodes = graph.nodes || [];
  const levels = graph.levels || [];
  const edges = graph.edges || [];
  const nodeMap = new Map(nodes.map((node) => [node.name, node]));

  const columnGap = 230;
  const rowGap = 110;
  const padding = 16;
  const nodeWidth = 200;
  const nodeHeight = 90;

  const positions = new Map();
  let maxRows = 0;

  levels.forEach((level, col) => {
    maxRows = Math.max(maxRows, level.length);
    level.forEach((name, row) => {
      positions.set(name, { x: col * columnGap, y: row * rowGap });
    });
  });

  const missing = nodes.filter((node) => !positions.has(node.name));
  if (missing.length) {
    const col = levels.length;
    maxRows = Math.max(maxRows, missing.length);
    missing.forEach((node, row) => {
      positions.set(node.name, { x: col * columnGap, y: row * rowGap });
    });
  }

  let maxX = 0;
  let maxY = 0;
  positions.forEach((pos) => {
    if (pos.x > maxX) maxX = pos.x;
    if (pos.y > maxY) maxY = pos.y;
  });
  const width = maxX + nodeWidth + padding * 2;
  const height = maxY + nodeHeight + padding * 2;

  graphEl.style.width = `${width}px`;
  graphEl.style.height = `${height}px`;

  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("width", width);
  svg.setAttribute("height", height);

  edges.forEach((edge) => {
    const source = positions.get(edge.source);
    const target = positions.get(edge.target);
    if (!source || !target) return;
    const startX = padding + source.x + nodeWidth;
    const startY = padding + source.y + nodeHeight / 2;
    const endX = padding + target.x;
    const endY = padding + target.y + nodeHeight / 2;
    const ctrlX = (startX + endX) / 2;

    const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
    const d = `M ${startX} ${startY} C ${ctrlX} ${startY}, ${ctrlX} ${endY}, ${endX} ${endY}`;
    path.setAttribute("d", d);
    path.setAttribute("fill", "none");
    path.setAttribute("stroke", "rgba(25, 100, 126, 0.35)");
    path.setAttribute("stroke-width", "2");
    if (edge.optional) {
      path.setAttribute("stroke-dasharray", "5 6");
    }
    svg.appendChild(path);
  });

  graphEl.appendChild(svg);

  nodes.forEach((node, index) => {
    const pos = positions.get(node.name) || { x: 0, y: 0 };
    const el = document.createElement("div");
    el.className = "node";
    el.dataset.node = node.name;
    el.style.left = `${padding + pos.x}px`;
    el.style.top = `${padding + pos.y}px`;
    el.style.animationDelay = `${index * 35}ms`;

    const inputsCount = (node.inputs || []).length;
    const outputsCount = node.outputs ? Object.keys(node.outputs).length : 0;

    el.innerHTML = `
      <div class="node-top">
        <div class="name">${escapeHtml(node.name)}</div>
        <div class="node-status" data-node-status>idle</div>
      </div>
      <div class="meta">
        <span class="chip">inputs ${inputsCount}</span>
        <span class="chip">outputs ${outputsCount}</span>
      </div>
      <div class="node-run" data-node-run>not run</div>
    `;

    el.addEventListener("click", () => {
      state.selected = node.name;
      renderDetail(node);
      applySelection();
    });

    graphEl.appendChild(el);
  });

  applySelection();
  updateGraphRunIndicators();

  if (state.selected && nodeMap.has(state.selected)) {
    renderDetail(nodeMap.get(state.selected));
  } else {
    renderDetail(null);
  }
}

function getSelectedNode() {
  if (!state.graph || !state.selected) return null;
  return (state.graph.nodes || []).find((node) => node.name === state.selected) || null;
}


function applySelection() {
  document.querySelectorAll(".node").forEach((nodeEl) => {
    nodeEl.classList.toggle("selected", nodeEl.dataset.node === state.selected);
  });
}

function updateGraphRunIndicators() {
  document.querySelectorAll(".node").forEach((nodeEl) => {
    const name = nodeEl.dataset.node;
    let status = "idle";
    let elapsed = null;
    if (state.run) {
      if (state.run.status === "error") {
        status = "error";
      } else {
        const skipped = state.run.skipped && state.run.skipped[name];
        const hasOutput = state.run.outputs && Object.prototype.hasOwnProperty.call(state.run.outputs, name);
        if (skipped) {
          status = "skipped";
        } else if (hasOutput) {
          status = "ok";
        }
      }
      elapsed = state.run.timings ? state.run.timings[name] : null;
    }

    nodeEl.classList.remove("node--ok", "node--skipped", "node--error", "node--idle");
    nodeEl.classList.add(`node--${status}`);

    const statusEl = nodeEl.querySelector("[data-node-status]");
    if (statusEl) {
      statusEl.textContent = status;
    }
    const runEl = nodeEl.querySelector("[data-node-run]");
    if (runEl) {
      if (elapsed != null) {
        runEl.textContent = `${elapsed.toFixed(3)}s`;
      } else if (state.run && state.run.status === "error") {
        runEl.textContent = "run failed";
      } else {
        runEl.textContent = "not run";
      }
    }
  });
}

function renderRunSummary() {
  if (!runSummaryEl) return;
  if (!state.run) {
    runSummaryEl.innerHTML = '<div class="summary-empty">No runs yet.</div>';
    return;
  }
  if (state.run.status === "error") {
    runSummaryEl.innerHTML = `
      <div class="summary-row">
        <span class="summary-label">Status</span>
        <span class="summary-value">error</span>
      </div>
      <div class="summary-row">
        <span class="summary-label">Error</span>
        <span class="summary-value">${escapeHtml(state.run.error || "Unknown error")}</span>
      </div>
    `;
    return;
  }
  const elapsed = state.run.elapsed != null ? `${state.run.elapsed.toFixed(3)}s` : "—";
  const trace = state.run.trace_id ? state.run.trace_id.slice(0, 8) : "—";
  const runId = state.run.run_id ? state.run.run_id.slice(0, 8) : "—";
  const outputHtml = state.run.output !== undefined
    ? `<div class="summary-output"><pre>${escapeHtml(prettyJson(state.run.output))}</pre></div>`
    : '<div class="summary-empty">No output.</div>';
  runSummaryEl.innerHTML = `
    <div class="summary-row">
      <span class="summary-label">Status</span>
      <span class="summary-value">${escapeHtml(state.run.status || "ok")}</span>
    </div>
    <div class="summary-row">
      <span class="summary-label">Elapsed</span>
      <span class="summary-value">${elapsed}</span>
    </div>
    <div class="summary-row">
      <span class="summary-label">Trace</span>
      <span class="summary-value mono">${escapeHtml(trace)}</span>
    </div>
    <div class="summary-row">
      <span class="summary-label">Run</span>
      <span class="summary-value mono">${escapeHtml(runId)}</span>
    </div>
    <div class="detail-section">
      <div class="detail-title">Workflow Output</div>
      ${outputHtml}
    </div>
  `;
}

function setupDetailAutoHide() {
  document.addEventListener("click", (event) => {
    if (!detailEl || detailEl.classList.contains("hidden")) {
      return;
    }
    const target = event.target;
    if (detailEl.contains(target)) {
      return;
    }
    const nodeEl = target.closest && target.closest(".node");
    if (nodeEl) {
      return;
    }
    detailEl.classList.add("hidden");
    state.selected = null;
    applySelection();
  });
}

function setRunData(payload) {
  if (!payload) {
    state.run = null;
    renderRunSummary();
    updateGraphRunIndicators();
    renderDetail(getSelectedNode());
    return;
  }
  if (payload.status === "error") {
    state.run = {
      status: "error",
      error: payload.error || "Run failed",
      outputs: {},
      timings: {},
      logs: {},
      skipped: {},
      output: null,
    };
  } else {
    const ctx = payload.ctx || {};
    state.run = {
      status: payload.status || "ok",
      error: null,
      elapsed: ctx.elapsed,
      trace_id: ctx.trace_id,
      run_id: ctx.run_id,
      outputs: ctx.outputs || {},
      timings: ctx.timings || {},
      logs: ctx.logs || {},
      skipped: ctx.skipped || {},
      output: payload.output,
    };
  }
  renderRunSummary();
  updateGraphRunIndicators();
  renderDetail(getSelectedNode());
}

function updateRunFromPayload(payload) {
  if (!payload) return;
  let key = null;
  if (payload.ctx && payload.ctx.run_id) {
    key = payload.ctx.run_id;
  } else {
    try {
      key = JSON.stringify(payload);
    } catch (_) {
      key = String(Date.now());
    }
  }
  if (state.lastRunKey === key) {
    return;
  }
  state.lastRunKey = key;
  setRunData(payload);
}

function clearRunState() {
  state.run = null;
  state.lastRunKey = null;
  renderRunSummary();
  updateGraphRunIndicators();
  renderDetail(getSelectedNode());
}

async function postJson(url, payload) {
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload || {}),
  });
  let data = null;
  try {
    data = await res.json();
  } catch (_) {
    data = null;
  }
  if (!res.ok) {
    const msg = data && data.error ? data.error : "Request failed";
    throw new Error(msg);
  }
  return data;
}

async function compileGraph() {
  setRunStatus("Compiling...");
  try {
    const payload = await postJson("/api/compile", {});
    state.graph = payload.graph;
    state.meta = payload.meta;
    renderMeta(state.meta);
    renderGraph(state.graph);
    renderParamInputs(state.graph);
    clearRunState();
    setRunStatus("Compiled", true);
    setStatus("Graph compiled", true);
    if (state.meta && state.meta.timestamp) {
      lastUpdatedEl.textContent = `Last update: ${formatTimestamp(state.meta.timestamp)}`;
    }
  } catch (err) {
    setRunStatus("Compile failed");
    setStatus("Compile failed");
  }
}

async function runWorkflow() {
  const { params, errors } = collectParams();
  if (errors.length) {
    setRunStatus("Invalid inputs");
    setStatus(errors[0] || "Invalid inputs");
    return;
  }
  setRunStatus("Running...");
  try {
    const payload = await postJson("/api/run", { params });
    updateRunFromPayload(payload);
    setRunStatus("Run ok", true);
    if (payload.ctx && payload.ctx.elapsed != null) {
      setStatus(`Run ok (${payload.ctx.elapsed.toFixed(3)}s)`, true);
    } else {
      setStatus("Run ok", true);
    }
  } catch (err) {
    setRunStatus("Run failed");
    setStatus("Run failed");
    updateRunFromPayload({ status: "error", error: String(err.message || err) });
  }
}

async function fetchGraph() {
  try {
    const res = await fetch("/api/graph", { cache: "no-store" });
    if (!res.ok) throw new Error("bad response");
    const payload = await res.json();
    const graphChanged = JSON.stringify(payload.graph) !== JSON.stringify(state.graph);
    state.graph = payload.graph;
    state.meta = payload.meta;
    state.lastEvent = payload.last_event;

    renderMeta(state.meta);
    if (graphChanged) {
      renderGraph(state.graph);
      renderParamInputs(state.graph);
    }
    if (payload.last_run) {
      updateRunFromPayload(payload.last_run);
    }
    if (state.selected) {
      renderDetail(getSelectedNode());
    }

    if (state.meta && state.meta.timestamp) {
      setStatus("Graph received", true);
      lastUpdatedEl.textContent = `Last update: ${formatTimestamp(state.meta.timestamp)}`;
    } else if (state.lastEvent) {
      setStatus(`Last event: ${state.lastEvent.event || "unknown"}`);
      lastUpdatedEl.textContent = state.lastEvent.timestamp
        ? `Last event: ${formatTimestamp(state.lastEvent.timestamp)}`
        : "";
    } else {
      setStatus("Waiting for graph...");
      lastUpdatedEl.textContent = "";
    }
  } catch (err) {
    setStatus("Server not reachable");
  }
}

let compileAttempted = false;

renderDetail(null);
renderGraph(null);
setupDetailAutoHide();
if (compileBtn) {
  compileBtn.addEventListener("click", compileGraph);
}
if (runBtn) {
  runBtn.addEventListener("click", runWorkflow);
}
fetchGraph();
setInterval(fetchGraph, POLL_MS);

if (!compileAttempted) {
  compileAttempted = true;
  compileGraph();
}
