"""Compute module for FlowQuery."""

from .runner import Runner

__all__ = ["Runner"]
