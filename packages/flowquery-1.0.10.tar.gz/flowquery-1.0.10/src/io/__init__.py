"""IO module for FlowQuery."""

from .command_line import CommandLine

__all__ = ["CommandLine"]
