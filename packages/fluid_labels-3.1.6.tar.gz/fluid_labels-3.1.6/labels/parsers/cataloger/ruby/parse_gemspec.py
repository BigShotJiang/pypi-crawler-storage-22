import re
from typing import NamedTuple

from gemfileparser import GemfileParser

from labels.model.file import Location, LocationReadCloser
from labels.model.package import Package
from labels.model.relationship import Relationship
from labels.model.release import Environment
from labels.model.resolver import Resolver
from labels.parsers.cataloger.ruby.package_builder import new_gemspec_package
from labels.parsers.cataloger.utils import get_enriched_location


class GemDependency(NamedTuple):
    name: str
    version_constraints: list[str]
    is_development: bool
    line: int


DEPENDENCY_PATTERN = re.compile(
    r"\w+\.add(_runtime|_development)?_dependency\s+"
    r"[\"']([^\"']+)[\"']"
    r"((?:\s*,\s*[\"'][^\"']+[\"'])*)"
)

VERSION_CONSTRAINT_PATTERN = re.compile(r"[\"']([^\"']+)[\"']")


def parse_gemspec(
    _resolver: Resolver | None,
    _environment: Environment | None,
    reader: LocationReadCloser,
) -> tuple[list[Package], list[Relationship]]:
    content = reader.read_closer.read()
    dependencies = _extract_dependencies_by_line(content)
    packages = _build_packages_from_dependencies(dependencies, reader.location)

    return packages, []


def _extract_dependencies_by_line(content: str) -> list[GemDependency]:  # noqa: PLR0915
    dependencies: list[GemDependency] = []
    lines = content.splitlines()
    continued_line = ""
    continued_line_number = 0

    for line_number, line in enumerate(lines, start=1):
        stripped = line.rstrip()
        is_continuation = stripped.endswith(("\\", ","))

        if continued_line:
            continued_line += " " + line.strip().lstrip("\\").rstrip("\\")
            if is_continuation:
                continue
            current_line = continued_line
            current_line_number = continued_line_number
            continued_line = ""
        elif is_continuation:
            continued_line = stripped.rstrip("\\")
            continued_line_number = line_number
            continue
        else:
            current_line = line
            current_line_number = line_number

        preprocessed = GemfileParser.preprocess(current_line)
        if not preprocessed:
            continue

        dependency = _parse_dependency_line(preprocessed, current_line_number)
        if dependency:
            dependencies.append(dependency)

    return dependencies


def _parse_dependency_line(line: str, line_number: int) -> GemDependency | None:
    match = DEPENDENCY_PATTERN.search(line)
    if not match:
        return None

    dep_type = match.group(1) or ""
    is_development = dep_type == "_development"
    name = match.group(2)
    version_part = match.group(3)

    version_constraints = VERSION_CONSTRAINT_PATTERN.findall(version_part)
    if not version_constraints:
        return None

    return GemDependency(name, version_constraints, is_development, line_number)


def _build_packages_from_dependencies(
    dependencies: list[GemDependency], base_location: Location
) -> list[Package]:
    packages: list[Package] = []

    for dep in dependencies:
        version = _format_version_from_constraints(dep.version_constraints)
        if not version:
            continue

        location = get_enriched_location(
            base_location,
            line=dep.line,
            is_transitive=False,
            is_dev=dep.is_development,
        )

        package = new_gemspec_package(name=dep.name, version=version, location=location)
        if package:
            packages.append(package)

    return packages


def _format_version_from_constraints(constraints: list[str]) -> str:
    if not constraints:
        return ""

    cleaned = [c.replace(" ", "") for c in constraints]
    first = cleaned[0]

    if "~>" in first:
        if len(cleaned) == 1:
            dot_count = first.count(".")
            if dot_count <= 1:
                return first.replace("~>", "^")
            return first.replace("~>", "~")
        if len(cleaned) >= 2:
            second = cleaned[1]
            if ">=" in second:
                return second.replace(">=", "^")
            if "!=" in second:
                first_ver = first.replace("~>", "")
                second_ver = second.replace("!=", "")
                return f">={first_ver} <{second_ver} || >{second_ver}"

    return " ".join(cleaned)
