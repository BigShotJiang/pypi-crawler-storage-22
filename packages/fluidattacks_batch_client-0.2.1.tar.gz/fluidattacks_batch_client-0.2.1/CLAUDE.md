# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

AWS Batch Python client library (`fluidattacks_batch_client`) for submitting and managing AWS Batch jobs. Part of the Fluid Attacks monorepo under `observes/common/batch-client`.

## Development Commands

```bash
# Enter development environment (uses Nix flakes)
direnv allow  # or: nix develop .#python311.devShell

# Run tests
pytest

# Run a single test
pytest tests/arch/test_arch.py::test_dag_completeness

# Type checking (strict mode enabled)
mypy fluidattacks_batch_client

# Linting
ruff check fluidattacks_batch_client

# CLI usage
batch-client submit-job --job job.json
batch-client submit-pipeline --pipeline pipeline.json
```

## Architecture

### Module Dependency DAG

The codebase enforces a strict dependency hierarchy via architecture tests (`tests/arch/`):

```
_cli (top-level CLI entry)
    ↓
decode, sender, api (parallel layer)
    ↓
core (domain types)
    ↓
_utils, _logger (utilities)
```

### Key Modules

- **`core.py`**: Domain types with validation (`JobRequest`, `JobName`, `Natural`, `Attempts`, `Timeout`, etc.). Uses private `_Private` inner classes to enforce construction through factory methods.
- **`api/`**: AWS Batch API client abstraction. `ApiClient` is a functional interface (dataclass with callable fields) created via `new_client()`.
- **`sender/`**: Job submission logic with duplicate detection and pipeline support. `BatchJobSender` wraps the API client.
- **`decode.py`**: JSON deserialization for job definitions using `fa_purity` JSON unfolder.
- **`_cli.py`**: Click-based CLI with `submit-job` and `submit-pipeline` commands.

### Functional Patterns

Uses `fa_purity` library extensively for:
- `Cmd[T]`: Effect wrapper for impure operations (IO monad)
- `Result[T, E]` / `ResultE[T]`: Error handling without exceptions
- `Maybe[T]`: Optional values
- `FrozenDict`, `FrozenList`, `NewFrozenList`: Immutable collections
- `Stream[T]`, `PureIter[T]`: Lazy iteration

All state mutations are wrapped in `Cmd`. Domain types are frozen dataclasses.

### Type Safety

Strict mypy configuration (`mypy.ini`) with all `disallow_*` flags enabled. No `Any` types allowed.

## Architecture Tests

The `tests/arch/` module validates:
- **DAG completeness**: All modules must be declared in the dependency graph
- **Private module access**: Modules prefixed with `_` are only importable by their parent
- **Forbidden imports**: Explicit allowlist for cross-boundary imports

To update the architecture, modify `tests/arch/arch.py`.
