from ._logger import (
    setup_logger,
)
from fa_purity import (
    Unsafe,
)

__version__ = "0.2.1"
Unsafe.compute(setup_logger(__name__))
