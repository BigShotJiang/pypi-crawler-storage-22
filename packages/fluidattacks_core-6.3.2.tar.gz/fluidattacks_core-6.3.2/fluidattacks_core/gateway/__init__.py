from .bedrock import make_bedrock_gateway_redirect

__all__ = ["make_bedrock_gateway_redirect"]
