import json
from collections.abc import Callable, MutableMapping
from typing import Protocol
from urllib.parse import urlparse, urlunparse

GATEWAY_HOST = "gateway.ai.cloudflare.com"


class RequestLike(Protocol):
    url: str
    headers: MutableMapping[str, str]


def make_bedrock_gateway_redirect(
    *,
    account_id: str,
    component_name: str,
    auth_token: str,
    region: str = "us-east-1",
) -> Callable[..., None]:
    bedrock_host = f"bedrock-runtime.{region}.amazonaws.com"
    gateway_path_prefix = (
        f"/v1/{account_id}/fluidattacks-apps-gateway/aws-bedrock/bedrock-runtime/{region}"
    )

    def redirect(request: RequestLike, **kwargs: object) -> None:  # noqa: ARG001
        parsed = urlparse(request.url)
        if parsed.hostname != bedrock_host:
            return

        gateway_path = f"{gateway_path_prefix}{parsed.path}"
        request.url = urlunparse(
            (
                "https",
                GATEWAY_HOST,
                gateway_path,
                parsed.params,
                parsed.query,
                parsed.fragment,
            ),
        )
        request.headers["cf-aig-authorization"] = f"Bearer {auth_token}"
        request.headers["cf-aig-metadata"] = json.dumps(
            {"component": component_name},
            separators=(",", ":"),
        )

    return redirect
