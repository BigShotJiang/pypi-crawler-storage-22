"""Tracks event resource."""

import asyncio
from collections.abc import AsyncGenerator, Mapping
from datetime import datetime
from typing import Literal, NotRequired, TypedDict

from pydantic import BaseModel

from fluidattacks_tracks.client import TracksClient
from fluidattacks_tracks.utils import fire_and_forget


class TracksEvent(BaseModel):
    """Tracks event."""

    action: str
    author: str
    date: datetime
    id: str
    mechanism: str
    metadata: Mapping[str, object]
    object_id: str


class PageInfo(BaseModel):
    """Tracks page info."""

    end_cursor: str
    has_next_page: bool


class TracksResponse(BaseModel):
    """Tracks response."""

    events: tuple[TracksEvent, ...]
    page_info: PageInfo


ActionType = Literal["CREATE", "READ", "UPDATE", "DELETE"]


MechanismType = Literal[
    "API",
    "DESKTOP",
    "EMAIL",
    "FIXES",
    "FORCES",
    "JIRA",
    "MCP",
    "MELTS",
    "MESSAGING",
    "MIGRATION",
    "RETRIEVES",
    "SCHEDULER",
    "SMELLS",
    "TASK",
    "WEB",
]

BATCH_READ_MAX_OBJECT_IDS = 50
BATCH_READ_MAX_LIMIT = 99  # Matches API Query(gt=0, lt=101)


class _BatchReadOptions(TypedDict):
    """Options for batch read requests."""

    end_date: datetime | None
    group_name: str
    object_: str
    page_limit: int
    start_date: datetime | None
    state_type: str | None


def _chunk_list(items: list[str], chunk_size: int) -> list[list[str]]:
    return [items[i : i + chunk_size] for i in range(0, len(items), chunk_size)]


def _build_batch_request_params(
    options: _BatchReadOptions,
    cursor_start_date: datetime | None,
) -> list[tuple[str, str | int]]:
    params: list[tuple[str, str | int]] = [
        ("object", options["object_"]),
        ("limit", options["page_limit"]),
    ]
    if options["state_type"] is not None:
        params.append(("state_type", options["state_type"]))
    if cursor_start_date is not None:
        params.append(("start_date", cursor_start_date.isoformat()))
    if options["end_date"] is not None:
        params.append(("end_date", options["end_date"].isoformat()))
    return params


class Event(TypedDict):
    """Tracks event."""

    action: ActionType
    author_anonymous: NotRequired[bool]
    author_ip: NotRequired[str]
    author_role: NotRequired[str]
    author_user_agent: NotRequired[str]
    author: str
    date: datetime
    mechanism: MechanismType
    metadata: Mapping[str, object]
    object_id: str
    object: str
    session_id: NotRequired[str]


class EventResource:
    """Tracks event resource."""

    def __init__(self, client: TracksClient) -> None:
        """Initialize the event resource."""
        self.client = client

    @fire_and_forget
    def create(self, event: Event) -> None:
        """Create an event."""
        self.client.post("/event", json=event)

    async def create_batch_async(self, events: list[Event]) -> None:
        """Create a batch of events."""
        await self.client.post_async("/events/batch", authenticated=True, json=events)

    async def read_pages(  # noqa: PLR0913
        self,
        *,
        after: str | None = None,
        end_date: datetime | None = None,
        group_name: str,
        limit: int = 100,
        object_: str,
        object_id: str | None = None,
        start_date: datetime | None = None,
        state_type: str | None = None,
    ) -> AsyncGenerator[TracksResponse]:
        """Read pages of events matching the given filters."""
        end_cursor = datetime.fromisoformat(after) if after else start_date
        has_next_page = True
        limit_with_offset = limit + 1  # Needed to check if there is a next page

        while has_next_page:
            response = await self.client.get_async(
                f"/groups/{group_name}/events",
                authenticated=True,
                params={
                    "limit": limit_with_offset,
                    "object": object_,
                    **({"end_date": end_date.isoformat()} if end_date else {}),
                    **({"object_id": object_id} if object_id else {}),
                    **({"start_date": end_cursor.isoformat()} if end_cursor else {}),
                    **({"state_type": state_type} if state_type else {}),
                },
            )
            response.raise_for_status()
            response_json: list[dict[str, object]] = await response.json()  # type: ignore[misc]
            has_next_page = len(response_json) == limit_with_offset
            events = tuple(TracksEvent.model_validate(event) for event in response_json)
            end_cursor = events[-1].date if events else None

            yield TracksResponse(
                events=events[:-1] if has_next_page else events,
                page_info=PageInfo(
                    has_next_page=has_next_page,
                    end_cursor=end_cursor.isoformat() if end_cursor else "",
                ),
            )

    async def read(  # noqa: PLR0913
        self,
        *,
        after: str | None = None,
        end_date: datetime | None = None,
        group_name: str,
        limit: int = 100,
        object_: str,
        object_id: str | None = None,
        start_date: datetime | None = None,
        state_type: str | None = None,
    ) -> TracksResponse:
        """Read all events matching the given filters."""
        pages = [
            page
            async for page in self.read_pages(
                after=after,
                end_date=end_date,
                group_name=group_name,
                limit=limit,
                object_=object_,
                object_id=object_id,
                start_date=start_date,
                state_type=state_type,
            )
        ]

        return TracksResponse(
            events=tuple(event for page in pages for event in page.events),
            page_info=pages[-1].page_info,
        )

    async def _fetch_batch_page(
        self,
        options: _BatchReadOptions,
        chunk: list[str],
        cursor_start_date: datetime | None,
    ) -> tuple[TracksEvent, ...]:
        params = _build_batch_request_params(options, cursor_start_date)
        body: dict[str, object] = {"object_ids": chunk}
        response = await self.client.post_async(
            f"/groups/{options['group_name']}/events/batch",
            authenticated=True,
            params=params,
            json=body,
        )
        response.raise_for_status()
        response_json: list[dict[str, object]] = await response.json()  # type: ignore[misc]
        return tuple(TracksEvent.model_validate(event) for event in response_json)

    async def _fetch_chunk_paginated(
        self, options: _BatchReadOptions, chunk: list[str]
    ) -> tuple[tuple[TracksEvent, ...], bool, datetime | None]:
        chunk_events: list[TracksEvent] = []
        seen_ids: set[str] = set()
        cursor: datetime | None = options["start_date"]
        has_next_page = False
        end_cursor: datetime | None = None
        limit_with_offset = options["page_limit"] + 1
        while True:
            page = await self._fetch_batch_page(
                {**options, "page_limit": limit_with_offset}, chunk, cursor
            )
            added_this_page = 0
            for event in page:
                if event.id not in seen_ids:
                    seen_ids.add(event.id)
                    chunk_events.append(event)
                    added_this_page += 1
            if len(chunk_events) >= limit_with_offset:
                has_next_page = True
                end_cursor = chunk_events[options["page_limit"]].date
                chunk_events = chunk_events[: options["page_limit"]]
                break
            if len(chunk_events) == 1 and options["page_limit"] == 1:
                break
            if len(page) < limit_with_offset or not page:
                break
            if added_this_page == 0 and len(page) == limit_with_offset:
                break
            cursor = page[-1].date
        return (tuple(chunk_events), has_next_page, end_cursor)

    async def read_batch(  # noqa: PLR0913
        self,
        *,
        end_date: datetime | None = None,
        group_name: str,
        limit: int = BATCH_READ_MAX_LIMIT,
        object_: str,
        object_ids: list[str],
        start_date: datetime | None = None,
        state_type: str | None = None,
    ) -> TracksResponse:
        """Read events for multiple object_ids via the batch API."""
        if not object_ids:
            return TracksResponse(
                events=(),
                page_info=PageInfo(has_next_page=False, end_cursor=""),
            )
        options: _BatchReadOptions = {
            "end_date": end_date,
            "group_name": group_name,
            "object_": object_,
            "page_limit": min(limit, BATCH_READ_MAX_LIMIT),
            "start_date": start_date,
            "state_type": state_type,
        }
        chunks = _chunk_list(object_ids, BATCH_READ_MAX_OBJECT_IDS)
        results = await asyncio.gather(*[self._fetch_chunk_paginated(options, c) for c in chunks])
        events = tuple(event for chunk_events, _, _ in results for event in chunk_events)
        any_has_next_page = any(has_more for _, has_more, _ in results)
        earliest_end_cursor = min(
            (
                end_cursor
                for _, has_more, end_cursor in results
                if has_more and end_cursor is not None
            ),
            default=None,
        )
        return TracksResponse(
            events=events,
            page_info=PageInfo(
                has_next_page=any_has_next_page,
                end_cursor=(
                    earliest_end_cursor.isoformat()
                    if any_has_next_page and earliest_end_cursor
                    else ""
                ),
            ),
        )
