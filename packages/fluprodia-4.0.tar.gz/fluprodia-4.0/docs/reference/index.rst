API
===

.. automodule:: fluprodia.fluid_property_diagram
    :members:
    :undoc-members:
    :show-inheritance:
