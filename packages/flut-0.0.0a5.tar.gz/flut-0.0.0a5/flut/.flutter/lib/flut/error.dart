class FlutRuntimeException implements Exception {
  final String message;
  FlutRuntimeException(this.message);

  @override
  String toString() => 'FlutRuntimeException: $message';
}

class FlutMissingRequiredParameterException extends FlutRuntimeException {
  final String widgetType;
  final String paramName;

  FlutMissingRequiredParameterException(this.widgetType, this.paramName)
    : super('$widgetType: missing required parameter "$paramName"');
}
