import 'runtime.dart';

/// Base class for immutable objects passed between Dart and Python.
/// These are simple data carriers - no bidirectional sync needed.
abstract class FlutImmutableObject {
  const FlutImmutableObject();

  /// Encode this object to JSON for Python.
  Map<String, dynamic> flutEncode();
}

class FlutAbstractObject extends Object {}

/// Mixin for objects that support realtime property sync with Python.
/// Use with classes that extend a Flutter class (e.g., TextEditingController).
mixin FlutRealtimeObject {
  late final FlutRuntime flutRuntime;
  late final int flutOid;

  void initFlutRealtimeObject({
    required FlutRuntime runtime,
    required int flutOid,
  }) {
    flutRuntime = runtime;
    this.flutOid = flutOid;
  }

  /// Encode this object to JSON for Python.
  Map<String, dynamic> flutEncode();

  /// Override to return raw Dart value for a property.
  dynamic getRawProperty(String property);

  /// Generic implementation - calls getRawProperty then encodes.
  dynamic getProperty(String property) {
    return flutRuntime.encodeValue(getRawProperty(property));
  }

  bool setProperty(String property, dynamic value);
  dynamic callMethod(String method, Map<String, dynamic> args);
}
