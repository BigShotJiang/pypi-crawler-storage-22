import 'package:flut/dart/ui.dart';
import 'package:flutter/material.dart';
import 'package:flut/flut/object.dart';
import 'package:flut/flut/native.dart';
import 'package:flut/flut/error.dart';
import 'package:flut/flut/widget.dart';
import 'package:flut/flutter/widgets/focus_manager.dart';
import 'package:flut/flutter/material/app_bar.dart';
import 'package:flut/flutter/widgets/basic.dart';
import 'package:flut/flutter/widgets/container.dart';
import 'package:flut/flutter/widgets/editable_text.dart';
import 'package:flut/flutter/widgets/framework.dart';
import 'package:flut/flutter/widgets/gesture_detector.dart';
import 'package:flut/flutter/widgets/icon.dart';
import 'package:flut/flutter/widgets/implicit_animations.dart';
import 'package:flut/flutter/widgets/scroll_controller.dart';
import 'package:flut/flutter/widgets/scroll_position.dart';
import 'package:flut/flutter/widgets/scroll_view.dart';
import 'package:flut/flutter/material/selectable_text.dart';
import 'package:flut/flutter/widgets/single_child_scroll_view.dart';
import 'package:flut/flutter/widgets/text.dart';
import 'package:flut/flutter/widgets/visibility.dart';
import 'package:flut/flutter/material/app.dart';
import 'package:flut/flutter/material/card.dart';
import 'package:flut/flutter/material/divider.dart';
import 'package:flut/flutter/material/elevated_button.dart';
import 'package:flut/flutter/material/floating_action_button.dart';
import 'package:flut/flutter/material/icon_button.dart';
import 'package:flut/flutter/material/ink_well.dart';
import 'package:flut/flutter/material/progress_indicator.dart';
import 'package:flut/flutter/material/scaffold.dart';
import 'package:flut/flutter/material/text_field.dart';
import 'package:flut/flutter/material/theme_data.dart';
import 'package:flut/flutter/painting/alignment.dart';
import 'package:flut/flutter/painting/border_radius.dart';
import 'package:flut/flutter/painting/borders.dart';
import 'package:flut/flutter/painting/box_decoration.dart';
import 'package:flut/flutter/painting/edge_insets.dart';
import 'package:flut/flutter/painting/text_style.dart';
import 'package:flut/flutter/widgets/media_query.dart';
import 'package:flut/flutter/material/theme.dart';
import 'package:flut/flutter/material/color_scheme.dart';
import 'package:flut/flutter/widgets/icon_data.dart';

class FlutRuntime {
  final FlutNative flutNative;

  /// Maps oid to FlutRealtimeObject.
  final Map<int, FlutRealtimeObject> objectRegistry = {};

  /// Maps Dart object identity hash to flut oid.
  final Map<int, int> _hashToOid = {};

  /// Registry for static function handlers (e.g., "Theme.of", "MediaQuery.of")
  final Map<String, Function> _staticRegistry = {};

  int _nextOid = 1;

  FlutRuntime(this.flutNative) {
    _registerStaticHandlers();
  }

  int generateOid() => _nextOid++;

  void _registerStaticHandlers() {
    // Register all static .of() and other static functions
    // TODO: auto register it by types.
    // something like
    // Runtime.register(FlutTheme)
    _staticRegistry['Theme.of'] = FlutTheme.of;
    _staticRegistry['MediaQuery.of'] = FlutMediaQuery.of;
  }

  void triggerAction(String actionId, {Map<String, dynamic>? payload}) {
    if (actionId.isEmpty) return;
    final data = <String, dynamic>{'id': actionId, ...?payload};
    flutNative.invokeNativeNoWaitSync('action', data);
  }

  /// Invoke an action synchronously and return the result.
  /// Used by FlutRealtimeObject subclasses that need sync callbacks (e.g., key events, buildTextSpan).
  Map<String, dynamic>? invokeAction(
    String actionId, {
    Map<String, dynamic>? payload,
  }) {
    if (actionId.isEmpty) return null;
    final data = <String, dynamic>{'id': actionId, ...?payload};
    return flutNative.invokeNativeSync('action', data);
  }

  /// Handle a static function call from Python.
  /// Args can contain oids (resolved to objects) or literal values.
  /// Handlers receive (runtime, ...args) - runtime is passed as first arg.
  Map<String, dynamic> handleStaticCall(
    String name,
    List<dynamic> args,
    Map<String, dynamic>? kwargs,
  ) {
    final handler = _staticRegistry[name];
    if (handler == null) {
      return {'error': 'Unknown static function', 'name': name};
    }

    final resolvedArgs = args.map(_resolveArg).toList();
    final resolvedKwargs = kwargs?.map((k, v) => MapEntry(k, _resolveArg(v)));

    try {
      Map<Symbol, dynamic>? namedArgs;
      if (resolvedKwargs != null && resolvedKwargs.isNotEmpty) {
        namedArgs = resolvedKwargs.map((k, v) => MapEntry(Symbol(k), v));
      }
      final result = Function.apply(handler, [
        this,
        ...resolvedArgs,
      ], namedArgs);
      return {'value': result};
    } catch (e) {
      return {'error': e.toString()};
    }
  }

  dynamic _resolveArg(dynamic arg) {
    if (arg is Map<String, dynamic> && arg.containsKey('oid')) {
      final oid = arg['oid'] as int;
      final obj = objectRegistry[oid];
      // Extract real BuildContext from wrapper
      if (obj is FlutBuildContext) {
        return obj.context;
      }
      return obj;
    }
    return arg;
  }

  Widget? decodeWidget(dynamic data, BuildContext context) {
    if (data == null) return null;
    if (data is! Map<String, dynamic>) {
      throw ArgumentError(
        'decodeWidget: expected Map, got ${data.runtimeType}',
      );
    }

    final type = data['type'] as String?;
    if (type == null) {
      throw ArgumentError('decodeWidget: missing "type" in $data');
    }

    switch (type) {
      case 'StatefulWidget':
        return FlutStatefulWidget(
          key: data['key'] != null ? ValueKey(data['key']) : null,
          flutId: data['id'],
          className: data['className'],
          native: flutNative,
          runtime: this,
        );
      case 'StatelessWidget':
        return FlutStatelessWidget(
          key: data['key'] != null ? ValueKey(data['key']) : null,
          flutId: data['id'],
          className: data['className'],
          native: flutNative,
          runtime: this,
        );
      // widgets/
      case 'AppBar':
        return FlutAppBar.flutDecode(data, this, context);
      case 'Text':
        return FlutText.flutDecode(data, this, context);
      case 'SelectableText':
        return FlutSelectableText.flutDecode(data, this, context);
      case 'Center':
        return FlutCenter.flutDecode(data, this, context);
      case 'Padding':
        return FlutPadding.flutDecode(data, this, context);
      case 'Align':
        return FlutAlign.flutDecode(data, this, context);
      case 'Opacity':
        return FlutOpacity.flutDecode(data, this, context);
      case 'ClipRRect':
        return FlutClipRRect.flutDecode(data, this, context);
      case 'SizedBox':
        return FlutSizedBox.flutDecode(data, this, context);
      case 'Expanded':
        return FlutExpanded.flutDecode(data, this, context);
      case 'Flexible':
        return FlutFlexible.flutDecode(data, this, context);
      case 'Spacer':
        return FlutSpacer.flutDecode(data, this, context);
      case 'Column':
        return FlutColumn.flutDecode(data, this, context);
      case 'Row':
        return FlutRow.flutDecode(data, this, context);
      case 'Stack':
        return FlutStack.flutDecode(data, this, context);
      case 'Positioned':
        return FlutPositioned.flutDecode(data, this, context);
      case 'Container':
        return FlutContainer.flutDecode(data, this, context);
      case 'Icon':
        return FlutIcon.flutDecode(data, this, context);
      case 'Visibility':
        return FlutVisibility.flutDecode(data, this, context);
      case 'ListView':
        return FlutListView.flutDecode(data, this, context);
      case 'SingleChildScrollView':
        return FlutSingleChildScrollView.flutDecode(data, this, context);
      case 'AnimatedOpacity':
        return FlutAnimatedOpacity.flutDecode(data, this, context);
      case 'MouseRegion':
        return FlutMouseRegion.flutDecode(data, this, context);
      case 'GestureDetector':
        return FlutGestureDetector.flutDecode(data, this, context);
      // material/
      case 'MaterialApp':
        return FlutMaterialApp.flutDecode(data, this, context);
      case 'Scaffold':
        return FlutScaffold.flutDecode(data, this, context);
      case 'Card':
        return FlutCard.flutDecode(data, this, context);
      case 'Divider':
        return FlutDivider.flutDecode(data, this, context);
      case 'CircularProgressIndicator':
        return FlutCircularProgressIndicator.flutDecode(data, this, context);
      case 'FloatingActionButton':
        return FlutFloatingActionButton.flutDecode(data, this, context);
      case 'ElevatedButton':
        return FlutElevatedButton.flutDecode(data, this, context);
      case 'IconButton':
        return FlutIconButton.flutDecode(data, this, context);
      case 'InkWell':
        return FlutInkWell.flutDecode(data, this, context);
      case 'TextField':
        return FlutTextField.flutDecode(data, this, context);
      case 'CustomPaint':
        return FlutCustomPaint.flutDecode(data, this, context);
      default:
        throw FlutRuntimeException('Unknown widget type: $type');
    }
  }

  /// Build a widget from JSON. This is the main entry point used by
  /// PythonProxyWidget and the root widget builder.
  /// Equivalent to decodeWidget but returns non-null.
  Widget buildWidgetFromJson(Map<String, dynamic> data, BuildContext context) {
    return decodeWidget(data, context)!;
  }

  /// Decode a Color from JSON value.
  /// Supports: int (0xAARRGGBB), Map with 'ref' for theme colors.
  Color? decodeColor(dynamic value, BuildContext context) {
    if (value == null) return null;
    if (value is int) return Color(value);
    if (value is Map && value['ref'] is String) {
      return _resolveThemeColorRef(context, value['ref'] as String);
    }
    return null;
  }

  Color? _resolveThemeColorRef(BuildContext context, String ref) {
    switch (ref) {
      case 'theme.colorScheme.inversePrimary':
        return Theme.of(context).colorScheme.inversePrimary;
      default:
        return null;
    }
  }

  /// Encode a value for return to Python.
  ///
  /// - null, num, String, bool: return as-is
  /// - List/Map: recursively encode
  /// - FlutImmutableObject: return flutEncode()
  /// - FlutRealtimeObject: return flutEncode()
  /// - Known Flutter types (Size, EdgeInsets, etc.): wrap and encode
  /// - Known wrappable types (e.g. ScrollPosition): wrap and return flutEncode()
  /// - Unknown types: throw error
  dynamic encodeValue(dynamic value) {
    if (value == null) return null;
    if (value is num || value is String || value is bool) return value;
    if (value is List) return value.map(encodeValue).toList();
    if (value is Map) {
      return value.map((k, v) => MapEntry(k, encodeValue(v)));
    }
    if (value is FlutImmutableObject) return value.flutEncode();
    if (value is FlutRealtimeObject) return value.flutEncode();

    // Known immutable Flutter types - wrap in FlutImmutableObject and encode
    if (value is Size) return FlutSize(value).flutEncode();
    if (value is EdgeInsets) return FlutEdgeInsets(value).flutEncode();
    if (value is ColorScheme) return FlutColorScheme(value).flutEncode();

    // Known wrappable Flutter types (mutable, need oid tracking)
    if (value is ScrollPosition) {
      final wrapper = wrapObject<FlutScrollPosition>(
        value,
        (oid) =>
            FlutScrollPosition(position: value, runtime: this, flutOid: oid),
      );
      return wrapper.flutEncode();
    }

    throw StateError('Cannot encode value of type ${value.runtimeType}');
  }

  /// Decode an IconData from JSON.
  IconData decodeIconData(Map<String, dynamic>? data) {
    return FlutIconData.flutDecode(data);
  }

  /// Wrap a Dart object in a FlutRealtimeObject.
  ///
  /// - If the object already has a wrapper, return it.
  /// - If [requestedOid] is provided (from Python), use it; error if object
  ///   already has a different oid.
  /// - Otherwise, generate a new oid.
  T wrapObject<T extends FlutRealtimeObject>(
    Object dartObj,
    T Function(int oid) factory, {
    int? requestedOid,
  }) {
    final hash = identityHashCode(dartObj);

    // Check if already wrapped
    final existingOid = _hashToOid[hash];
    if (existingOid != null) {
      final existing = objectRegistry[existingOid];
      if (existing != null) {
        // Validate oid if Python provided one
        if (requestedOid != null && existingOid != requestedOid) {
          throw StateError(
            'Object already has oid=$existingOid, '
            'but Python requested oid=$requestedOid',
          );
        }
        return existing as T;
      }
    }

    // Determine oid
    final oid = requestedOid ?? generateOid();

    // Check if oid already used
    if (objectRegistry.containsKey(oid)) {
      throw StateError('oid=$oid already in use by another object');
    }

    // Create wrapper
    final wrapper = factory(oid);
    objectRegistry[oid] = wrapper;
    _hashToOid[hash] = oid;

    return wrapper;
  }

  /// Remove an object from registries (called during GC).
  void releaseObject(int oid) {
    final wrapper = objectRegistry.remove(oid);
    if (wrapper != null) {
      // Find and remove from hash map
      _hashToOid.removeWhere((_, v) => v == oid);
    }
  }

  /// Parse a TextEditingController from JSON.
  /// Returns the controller directly (FlutTextEditingController IS a TextEditingController).
  TextEditingController? parseTextEditingController(
    Map<String, dynamic>? json,
  ) {
    final wrapper = _parseWrapper(json);
    if (wrapper is FlutTextEditingController) {
      return wrapper;
    }
    return null;
  }

  /// Parse a ScrollController from JSON.
  /// Returns the FlutScrollController (which IS a ScrollController).
  ScrollController? parseScrollController(Map<String, dynamic>? json) {
    final wrapper = _parseWrapper(json);
    if (wrapper is FlutScrollController) {
      return wrapper;
    }
    return null;
  }

  /// Parse a ThemeData from JSON.
  ThemeData? parseThemeData(Map<String, dynamic>? json) {
    return FlutThemeData.flutDecode(json);
  }

  /// Parse EdgeInsets from JSON.
  EdgeInsets? parseEdgeInsets(dynamic json) {
    return FlutEdgeInsets.flutDecode(json);
  }

  /// Parse TextStyle from JSON.
  TextStyle? parseTextStyle(dynamic json, BuildContext context) {
    return FlutTextStyle.flutDecode(json, context);
  }

  /// Parse Alignment from JSON.
  Alignment parseAlignment(dynamic json) {
    return FlutAlignment.flutDecode(json);
  }

  /// Parse Alignment from JSON (nullable).
  Alignment? parseAlignmentNullable(dynamic json) {
    return FlutAlignment.flutDecodeNullable(json);
  }

  /// Parse BorderRadius from JSON.
  BorderRadius parseBorderRadius(dynamic json) {
    return FlutBorderRadius.flutDecode(json);
  }

  /// Parse Border from JSON.
  Border? parseBorder(dynamic json) {
    return FlutBorder.flutDecode(json);
  }

  /// Parse BoxDecoration from JSON.
  BoxDecoration? parseBoxDecoration(dynamic json) {
    return FlutBoxDecoration.flutDecode(json, this);
  }

  /// Parse AppBar from JSON.
  AppBar? parseAppBar(Map<String, dynamic>? json, BuildContext context) {
    if (json == null) return null;
    return FlutAppBar.flutDecode(json, this, context);
  }

  /// Parse InputDecoration from JSON.
  InputDecoration? parseInputDecoration(dynamic json) {
    if (json == null) return null;
    if (json is! Map) return null;
    return InputDecoration(
      hintText: json['hintText'],
      border: parseInputBorder(json['border']),
      filled: json['filled'] ?? false,
      fillColor: json['fillColor'] != null ? Color(json['fillColor']) : null,
      contentPadding: parseEdgeInsets(json['contentPadding']),
    );
  }

  /// Parse InputBorder from JSON.
  InputBorder? parseInputBorder(dynamic json) {
    if (json == null) return null;
    if (json == 'none') return InputBorder.none;
    return null;
  }

  /// Parse JSON into a FlutRealtimeObject wrapper.
  /// Returns existing object if in registry, or creates new one.
  FlutRealtimeObject? _parseWrapper(Map<String, dynamic>? json) {
    if (json == null) return null;

    final oid = json['_flut_oid'] as int?;
    final type = json['_flut_type'] as String?;

    if (oid == null || type == null) return null;

    // Return existing object if already registered
    final existing = objectRegistry[oid];
    if (existing != null) {
      return existing;
    }

    // Create new object based on _flut_type
    final obj = _createRealtimeObject(type, json);
    if (obj != null) {
      objectRegistry[oid] = obj;
    }
    return obj;
  }

  /// Create a new FlutRealtimeObject based on type string.
  FlutRealtimeObject? _createRealtimeObject(
    String type,
    Map<String, dynamic> json,
  ) {
    switch (type) {
      case 'TextEditingController':
        return FlutTextEditingController.flutDecode(this, json);
      case 'ScrollController':
        return FlutScrollController.flutDecode(this, json);
      default:
        print('[FlutRuntime] Unknown _flut_type: $type');
        return null;
    }
  }

  FocusNode? parseFocusNode(Map<String, dynamic>? json, BuildContext context) {
    if (json == null) return null;

    final oid = json['_flut_oid'] as int?;
    if (oid == null) return null;

    final existing = objectRegistry[oid];
    if (existing is FlutFocusNode) {
      return existing;
    }

    final wrapper = FlutFocusNode.flutDecode(this, json);
    objectRegistry[oid] = wrapper;
    return wrapper;
  }
}
