import 'package:flutter/material.dart';
import 'package:flut/flut/native.dart';
import 'package:flut/flut/runtime.dart';
import 'package:flut/flutter/widgets/framework.dart';

class FlutStatefulWidget extends StatefulWidget {
  final String flutId;
  final String className;
  final FlutNative native;
  final FlutRuntime runtime;

  const FlutStatefulWidget({
    required this.flutId,
    required this.className,
    required this.native,
    required this.runtime,
    super.key,
  });

  @override
  State<FlutStatefulWidget> createState() => _FlutStatefulWidgetState();
}

class _FlutStatefulWidgetState extends State<FlutStatefulWidget>
    implements FlutState {
  Map<String, dynamic>? _cachedSubtree;
  bool _needsBuild = true;
  late final String _stableFlutId;

  @override
  void initState() {
    super.initState();
    _stableFlutId = widget.flutId;
    widget.native.stateRegistry[_stableFlutId] = this;
  }

  @override
  void dispose() {
    widget.native.stateRegistry.remove(_stableFlutId);
    super.dispose();
  }

  @override
  void updateFromPython(Map<String, dynamic>? newSubtree) {
    setState(() {
      if (newSubtree != null) {
        _cachedSubtree = newSubtree;
        _needsBuild = false;
      } else {
        _needsBuild = true;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_needsBuild) {
      final contextWrapper = widget.runtime.wrapObject<FlutBuildContext>(
        context,
        (oid) => FlutBuildContext(
          context: context,
          runtime: widget.runtime,
          flutOid: oid,
        ),
      );
      final contextOid = contextWrapper.flutOid;

      try {
        final request = <String, dynamic>{
          'id': _stableFlutId,
          'contextOid': contextOid,
        };
        if (widget.flutId != _stableFlutId) {
          request['newWidgetId'] = widget.flutId;
        }
        _cachedSubtree = widget.native.invokeNativeSync('widget_build', request);
        _needsBuild = false;
      } catch (e) {
        return Text('Build error: $e');
      } finally {
        widget.runtime.releaseObject(contextOid);
      }
    }

    if (_cachedSubtree == null) {
      return Text(
        'FlutStatefulWidget: widget_build returned null for $_stableFlutId',
      );
    }

    return widget.runtime.buildWidgetFromJson(_cachedSubtree!, context);
  }
}

class FlutStatelessWidget extends StatelessWidget {
  final String flutId;
  final String className;
  final FlutNative native;
  final FlutRuntime runtime;

  const FlutStatelessWidget({
    required this.flutId,
    required this.className,
    required this.native,
    required this.runtime,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final contextWrapper = runtime.wrapObject<FlutBuildContext>(
      context,
      (oid) => FlutBuildContext(
        context: context,
        runtime: runtime,
        flutOid: oid,
      ),
    );
    final contextOid = contextWrapper.flutOid;

    try {
      final subtree = native.invokeNativeSync('widget_build', {
        'id': flutId,
        'contextOid': contextOid,
      });

      if (subtree == null) {
        return Text(
          'StatelessWidget: widget_build returned null for $flutId',
        );
      }

      return runtime.buildWidgetFromJson(subtree, context);
    } catch (e) {
      return Text('Build error: $e');
    } finally {
      runtime.releaseObject(contextOid);
    }
  }
}
