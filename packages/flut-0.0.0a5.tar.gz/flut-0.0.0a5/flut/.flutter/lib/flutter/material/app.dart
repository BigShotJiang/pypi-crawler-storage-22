import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';

class FlutMaterialApp {
  FlutMaterialApp._();

  static MaterialApp flutDecode(
    Map<String, dynamic> data,
    FlutRuntime runtime,
    BuildContext context,
  ) {
    return MaterialApp(
      title: data['title'] ?? 'Flut',
      theme: runtime.parseThemeData(data['theme']),
      home: runtime.decodeWidget(data['home'], context),
    );
  }
}
