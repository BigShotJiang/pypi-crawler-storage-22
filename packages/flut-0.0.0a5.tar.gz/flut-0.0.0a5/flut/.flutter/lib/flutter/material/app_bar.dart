import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';

class FlutAppBar {
  FlutAppBar._();

  static AppBar flutDecode(
    Map<String, dynamic> data,
    FlutRuntime runtime,
    BuildContext context,
  ) {
    final backgroundColor = runtime.decodeColor(
      data['backgroundColor'],
      context,
    );
    final title = runtime.decodeWidget(data['title'], context);
    final scrolledUnderElevation = (data['scrolledUnderElevation'] as num?)
        ?.toDouble();

    return AppBar(
      backgroundColor: backgroundColor,
      title: title,
      scrolledUnderElevation: scrolledUnderElevation,
    );
  }
}
