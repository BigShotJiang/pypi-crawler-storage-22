import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';

class FlutCard {
  FlutCard._();

  static Card flutDecode(
    Map<String, dynamic> data,
    FlutRuntime runtime,
    BuildContext context,
  ) {
    return Card(
      color: data['color'] != null ? Color(data['color']) : null,
      elevation: (data['elevation'] as num?)?.toDouble(),
      margin: runtime.parseEdgeInsets(data['margin']),
      child: runtime.decodeWidget(data['child'], context),
    );
  }
}
