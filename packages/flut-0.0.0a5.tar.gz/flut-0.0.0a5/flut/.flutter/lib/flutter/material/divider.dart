import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';

class FlutDivider {
  FlutDivider._();

  static Divider flutDecode(
    Map<String, dynamic> data,
    FlutRuntime runtime,
    BuildContext context,
  ) {
    return Divider(
      height: (data['height'] as num?)?.toDouble(),
      thickness: (data['thickness'] as num?)?.toDouble(),
      color: data['color'] != null ? Color(data['color']) : null,
    );
  }
}
