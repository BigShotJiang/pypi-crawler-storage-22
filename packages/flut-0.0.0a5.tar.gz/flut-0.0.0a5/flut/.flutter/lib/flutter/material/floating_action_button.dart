import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';

class FlutFloatingActionButton {
  FlutFloatingActionButton._();

  static Widget flutDecode(
    Map<String, dynamic> data,
    FlutRuntime runtime,
    BuildContext context,
  ) {
    return FloatingActionButton(
      onPressed: () =>
          runtime.triggerAction(data['onPressedId'] ?? ''),
      child: runtime.decodeWidget(data['child'], context),
    );
  }
}
