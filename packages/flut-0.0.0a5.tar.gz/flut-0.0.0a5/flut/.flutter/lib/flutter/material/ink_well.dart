import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';

class FlutInkWell {
  FlutInkWell._();

  static Widget flutDecode(
    Map<String, dynamic> data,
    FlutRuntime runtime,
    BuildContext context,
  ) {
    return InkWell(
      onTap: data['onTapId'] != null
          ? () => runtime.triggerAction(data['onTapId'])
          : null,
      child: runtime.decodeWidget(data['child'], context),
    );
  }
}
