import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';

class FlutCircularProgressIndicator {
  FlutCircularProgressIndicator._();

  static CircularProgressIndicator flutDecode(
    Map<String, dynamic> data,
    FlutRuntime runtime,
    BuildContext context,
  ) {
    return CircularProgressIndicator(
      strokeWidth: (data['strokeWidth'] as num?)?.toDouble() ?? 4.0,
      color: data['color'] != null ? Color(data['color']) : null,
    );
  }
}
