import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';

class FlutScaffold {
  FlutScaffold._();

  static Scaffold flutDecode(
    Map<String, dynamic> data,
    FlutRuntime runtime,
    BuildContext context,
  ) {
    return Scaffold(
      appBar: runtime.parseAppBar(
        data['appBar'] as Map<String, dynamic>?,
        context,
      ),
      body: runtime.decodeWidget(data['body'], context),
      floatingActionButton: runtime.decodeWidget(
        data['floatingActionButton'],
        context,
      ),
    );
  }
}
