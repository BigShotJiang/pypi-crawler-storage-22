import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';

class FlutSelectableText {
  FlutSelectableText._();

  static SelectableText flutDecode(
    Map<String, dynamic> data,
    FlutRuntime runtime,
    BuildContext context,
  ) {
    final textData = data['data']?.toString() ?? '';
    final maxLines = data['maxLines'] as int?;
    final style = runtime.parseTextStyle(data['style'], context);

    return SelectableText(textData, style: style, maxLines: maxLines);
  }
}
