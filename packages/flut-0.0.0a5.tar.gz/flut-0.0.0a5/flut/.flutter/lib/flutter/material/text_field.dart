import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';

class FlutTextField {
  FlutTextField._();

  static Widget flutDecode(
    Map<String, dynamic> data,
    FlutRuntime runtime,
    BuildContext context,
  ) {
    final controllerData = data['controller'] as Map<String, dynamic>?;
    final focusNodeData = data['focusNode'] as Map<String, dynamic>?;

    final controller = runtime.parseTextEditingController(controllerData);
    final focusNode = runtime.parseFocusNode(focusNodeData, context);

    return TextField(
      controller: controller,
      focusNode: focusNode,
      readOnly: data['readOnly'] ?? false,
      maxLines: data['maxLines'],
      minLines: data['minLines'],
      decoration: runtime.parseInputDecoration(data['decoration']),
      style: runtime.parseTextStyle(data['style'], context),
      onChanged: data['onChangedId'] != null
          ? (value) => runtime.triggerAction(
                data['onChangedId'],
                payload: {'value': value},
              )
          : null,
      onSubmitted: data['onSubmittedId'] != null
          ? (value) => runtime.triggerAction(
                data['onSubmittedId'],
                payload: {'value': value},
              )
          : null,
    );
  }
}
