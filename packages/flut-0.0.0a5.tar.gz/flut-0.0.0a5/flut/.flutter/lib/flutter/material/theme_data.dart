import 'package:flutter/material.dart';

class FlutThemeData {
  FlutThemeData._();

  static ThemeData? flutDecode(Map<String, dynamic>? data) {
    if (data == null) return null;

    final useMaterial3 = (data['useMaterial3'] as bool?) ?? true;
    final colorSchemeData = data['colorScheme'];
    final seedColor = (colorSchemeData is Map)
        ? (colorSchemeData['seedColor'] as int?)
        : null;

    if (seedColor != null) {
      return ThemeData(
        colorSchemeSeed: Color(seedColor),
        useMaterial3: useMaterial3,
      );
    }

    return ThemeData(useMaterial3: useMaterial3);
  }
}
