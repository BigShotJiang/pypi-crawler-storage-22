import 'package:flutter/material.dart';

class FlutAlignment {
  FlutAlignment._();

  static Alignment flutDecode(dynamic data) {
    if (data == null) return Alignment.center;
    switch (data) {
      case 'topLeft':
        return Alignment.topLeft;
      case 'topCenter':
        return Alignment.topCenter;
      case 'topRight':
        return Alignment.topRight;
      case 'centerLeft':
        return Alignment.centerLeft;
      case 'center':
        return Alignment.center;
      case 'centerRight':
        return Alignment.centerRight;
      case 'bottomLeft':
        return Alignment.bottomLeft;
      case 'bottomCenter':
        return Alignment.bottomCenter;
      case 'bottomRight':
        return Alignment.bottomRight;
      default:
        return Alignment.center;
    }
  }

  static Alignment? flutDecodeNullable(dynamic data) {
    if (data == null) return null;
    return flutDecode(data);
  }
}
