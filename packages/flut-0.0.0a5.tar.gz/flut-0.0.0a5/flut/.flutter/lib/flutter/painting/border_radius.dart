import 'package:flutter/material.dart';

class FlutBorderRadius {
  FlutBorderRadius._();

  static BorderRadius flutDecode(dynamic data) {
    if (data == null) return BorderRadius.zero;
    if (data is num) return BorderRadius.circular(data.toDouble());
    if (data is Map) {
      return BorderRadius.only(
        topLeft: Radius.circular((data['topLeft'] as num?)?.toDouble() ?? 0),
        topRight: Radius.circular((data['topRight'] as num?)?.toDouble() ?? 0),
        bottomLeft: Radius.circular(
          (data['bottomLeft'] as num?)?.toDouble() ?? 0,
        ),
        bottomRight: Radius.circular(
          (data['bottomRight'] as num?)?.toDouble() ?? 0,
        ),
      );
    }
    return BorderRadius.zero;
  }
}
