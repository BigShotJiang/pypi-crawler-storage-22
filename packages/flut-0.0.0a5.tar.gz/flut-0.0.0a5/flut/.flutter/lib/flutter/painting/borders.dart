import 'package:flutter/material.dart';

class FlutBorder {
  FlutBorder._();

  static Border? flutDecode(dynamic data) {
    if (data == null) return null;
    if (data is Map) {
      return Border(
        left: _decodeSide(data['left']),
        top: _decodeSide(data['top']),
        right: _decodeSide(data['right']),
        bottom: _decodeSide(data['bottom']),
      );
    }
    return null;
  }

  static BorderSide _decodeSide(dynamic sideData) {
    if (sideData == null) return BorderSide.none;
    return BorderSide(
      color: sideData['color'] != null
          ? Color(sideData['color'])
          : Colors.black,
      width: (sideData['width'] as num?)?.toDouble() ?? 1.0,
    );
  }
}
