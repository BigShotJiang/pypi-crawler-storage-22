import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';

class FlutBoxDecoration {
  FlutBoxDecoration._();

  static BoxDecoration? flutDecode(dynamic data, FlutRuntime runtime) {
    if (data == null) return null;
    if (data is! Map) return null;
    return BoxDecoration(
      color: data['color'] != null ? Color(data['color']) : null,
      border: runtime.parseBorder(data['border']),
      borderRadius: runtime.parseBorderRadius(data['borderRadius']),
    );
  }
}
