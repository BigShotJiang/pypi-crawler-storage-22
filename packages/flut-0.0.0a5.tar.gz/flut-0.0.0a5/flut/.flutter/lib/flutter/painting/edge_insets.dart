import 'package:flutter/material.dart';
import 'package:flut/flut/object.dart';

/// Flut wrapper for EdgeInsets - supports both encoding and decoding.
class FlutEdgeInsets extends FlutImmutableObject {
  final EdgeInsets edgeInsets;

  const FlutEdgeInsets(this.edgeInsets);

  @override
  Map<String, dynamic> flutEncode() {
    return {
      'left': edgeInsets.left,
      'top': edgeInsets.top,
      'right': edgeInsets.right,
      'bottom': edgeInsets.bottom,
    };
  }

  static EdgeInsets? flutDecode(dynamic data) {
    if (data == null) return null;
    if (data is Map) {
      return EdgeInsets.only(
        left: (data['left'] as num?)?.toDouble() ?? 0,
        top: (data['top'] as num?)?.toDouble() ?? 0,
        right: (data['right'] as num?)?.toDouble() ?? 0,
        bottom: (data['bottom'] as num?)?.toDouble() ?? 0,
      );
    }
    return null;
  }
}
