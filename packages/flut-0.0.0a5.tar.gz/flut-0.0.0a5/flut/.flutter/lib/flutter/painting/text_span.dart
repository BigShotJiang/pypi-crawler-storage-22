import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';

class FlutTextSpan {
  FlutTextSpan._();

  static TextSpan flutDecode(
    Map<String, dynamic>? data,
    FlutRuntime runtime,
    BuildContext context,
  ) {
    if (data == null) {
      return const TextSpan();
    }

    final text = data['text'] as String?;
    final style = runtime.parseTextStyle(data['style'], context);

    List<InlineSpan>? children;
    if (data['children'] != null) {
      children = (data['children'] as List)
          .map((c) => flutDecode(c as Map<String, dynamic>?, runtime, context))
          .toList();
    }

    return TextSpan(text: text, style: style, children: children);
  }
}
