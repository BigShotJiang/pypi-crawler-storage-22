import 'package:flutter/material.dart';

class FlutTextStyle {
  FlutTextStyle._();

  static TextStyle? flutDecode(dynamic data, BuildContext context) {
    if (data == null) return null;

    if (data is Map && data['ref'] is String) {
      final ref = data['ref'] as String;
      if (ref.startsWith('theme.textTheme.')) {
        final name = ref.substring('theme.textTheme.'.length);
        final textTheme = Theme.of(context).textTheme;
        return switch (name) {
          'headlineMedium' => textTheme.headlineMedium,
          'headlineSmall' => textTheme.headlineSmall,
          'titleLarge' => textTheme.titleLarge,
          'bodyLarge' => textTheme.bodyLarge,
          'bodyMedium' => textTheme.bodyMedium,
          _ => null,
        };
      }
    }

    if (data is Map) {
      return TextStyle(
        fontSize: (data['fontSize'] as num?)?.toDouble(),
        fontWeight: _decodeFontWeight(data['fontWeight']),
        color: data['color'] != null ? Color(data['color']) : null,
        fontFamily: data['fontFamily'] as String?,
        height: (data['height'] as num?)?.toDouble(),
      );
    }

    return null;
  }

  static FontWeight? _decodeFontWeight(dynamic data) {
    if (data == null) return null;
    return switch (data) {
      'bold' => FontWeight.bold,
      'normal' => FontWeight.normal,
      'w100' => FontWeight.w100,
      'w200' => FontWeight.w200,
      'w300' => FontWeight.w300,
      'w400' => FontWeight.w400,
      'w500' => FontWeight.w500,
      'w600' => FontWeight.w600,
      'w700' => FontWeight.w700,
      'w800' => FontWeight.w800,
      'w900' => FontWeight.w900,
      _ => null,
    };
  }
}
