import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';
import 'package:flut/flut/error.dart';

class FlutCenter {
  FlutCenter._();

  static Center flutDecode(
    Map<String, dynamic> data,
    FlutRuntime runtime,
    BuildContext context,
  ) {
    return Center(child: runtime.decodeWidget(data['child'], context));
  }
}

class FlutPadding {
  FlutPadding._();

  static Padding flutDecode(
    Map<String, dynamic> data,
    FlutRuntime runtime,
    BuildContext context,
  ) {
    final padding = runtime.parseEdgeInsets(data['padding']);
    if (padding == null) {
      throw FlutMissingRequiredParameterException('Padding', 'padding');
    }
    return Padding(
      padding: padding,
      child: runtime.decodeWidget(data['child'], context),
    );
  }
}

class FlutAlign {
  FlutAlign._();

  static Align flutDecode(
    Map<String, dynamic> data,
    FlutRuntime runtime,
    BuildContext context,
  ) {
    return Align(
      alignment: runtime.parseAlignment(data['alignment']),
      child: runtime.decodeWidget(data['child'], context),
    );
  }
}

class FlutOpacity {
  FlutOpacity._();

  static Opacity flutDecode(
    Map<String, dynamic> data,
    FlutRuntime runtime,
    BuildContext context,
  ) {
    final opacity = data['opacity'];
    if (opacity == null) {
      throw FlutMissingRequiredParameterException('Opacity', 'opacity');
    }
    return Opacity(
      opacity: (opacity as num).toDouble(),
      child: runtime.decodeWidget(data['child'], context),
    );
  }
}

class FlutClipRRect {
  FlutClipRRect._();

  static ClipRRect flutDecode(
    Map<String, dynamic> data,
    FlutRuntime runtime,
    BuildContext context,
  ) {
    return ClipRRect(
      borderRadius: runtime.parseBorderRadius(data['borderRadius']),
      child: runtime.decodeWidget(data['child'], context),
    );
  }
}

class FlutSizedBox {
  FlutSizedBox._();

  static SizedBox flutDecode(
    Map<String, dynamic> data,
    FlutRuntime runtime,
    BuildContext context,
  ) {
    return SizedBox(
      width: (data['width'] as num?)?.toDouble(),
      height: (data['height'] as num?)?.toDouble(),
      child: runtime.decodeWidget(data['child'], context),
    );
  }
}

class FlutExpanded {
  FlutExpanded._();

  static Expanded flutDecode(
    Map<String, dynamic> data,
    FlutRuntime runtime,
    BuildContext context,
  ) {
    final child = runtime.decodeWidget(data['child'], context);
    if (child == null) {
      throw FlutMissingRequiredParameterException('Expanded', 'child');
    }
    return Expanded(flex: (data['flex'] as num?)?.toInt() ?? 1, child: child);
  }
}

class FlutFlexible {
  FlutFlexible._();

  static Flexible flutDecode(
    Map<String, dynamic> data,
    FlutRuntime runtime,
    BuildContext context,
  ) {
    final child = runtime.decodeWidget(data['child'], context);
    if (child == null) {
      throw FlutMissingRequiredParameterException('Flexible', 'child');
    }
    return Flexible(
      flex: (data['flex'] as num?)?.toInt() ?? 1,
      fit: data['fit'] == 'tight' ? FlexFit.tight : FlexFit.loose,
      child: child,
    );
  }
}

class FlutSpacer {
  FlutSpacer._();

  static Spacer flutDecode(
    Map<String, dynamic> data,
    FlutRuntime runtime,
    BuildContext context,
  ) {
    return Spacer(flex: (data['flex'] as num?)?.toInt() ?? 1);
  }
}

class FlutColumn {
  FlutColumn._();

  static Column flutDecode(
    Map<String, dynamic> data,
    FlutRuntime runtime,
    BuildContext context,
  ) {
    final children =
        (data['children'] as List?)
            ?.map((c) => runtime.decodeWidget(c, context))
            .whereType<Widget>()
            .toList() ??
        [];

    return Column(
      mainAxisAlignment: _parseMainAxisAlignment(data['mainAxisAlignment']),
      crossAxisAlignment: _parseCrossAxisAlignment(data['crossAxisAlignment']),
      children: children,
    );
  }
}

class FlutRow {
  FlutRow._();

  static Row flutDecode(
    Map<String, dynamic> data,
    FlutRuntime runtime,
    BuildContext context,
  ) {
    final children =
        (data['children'] as List?)
            ?.map((c) => runtime.decodeWidget(c, context))
            .whereType<Widget>()
            .toList() ??
        [];

    return Row(
      mainAxisAlignment: _parseMainAxisAlignment(data['mainAxisAlignment']),
      crossAxisAlignment: _parseCrossAxisAlignment(data['crossAxisAlignment']),
      children: children,
    );
  }
}

class FlutStack {
  FlutStack._();

  static Stack flutDecode(
    Map<String, dynamic> data,
    FlutRuntime runtime,
    BuildContext context,
  ) {
    final children =
        (data['children'] as List?)
            ?.map((c) => runtime.decodeWidget(c, context))
            .whereType<Widget>()
            .toList() ??
        [];

    return Stack(children: children);
  }
}

class FlutPositioned {
  FlutPositioned._();

  static Positioned flutDecode(
    Map<String, dynamic> data,
    FlutRuntime runtime,
    BuildContext context,
  ) {
    final child = runtime.decodeWidget(data['child'], context);
    if (child == null) {
      throw FlutMissingRequiredParameterException('Positioned', 'child');
    }
    return Positioned(
      left: (data['left'] as num?)?.toDouble(),
      top: (data['top'] as num?)?.toDouble(),
      right: (data['right'] as num?)?.toDouble(),
      bottom: (data['bottom'] as num?)?.toDouble(),
      width: (data['width'] as num?)?.toDouble(),
      height: (data['height'] as num?)?.toDouble(),
      child: child,
    );
  }
}

class FlutMouseRegion {
  FlutMouseRegion._();

  static Widget flutDecode(
    Map<String, dynamic> data,
    FlutRuntime runtime,
    BuildContext context,
  ) {
    final cursor = _parseMouseCursor(data['cursor'] as String?);

    return MouseRegion(
      cursor: cursor,
      onEnter: data['onEnterId'] != null
          ? (_) => runtime.triggerAction(data['onEnterId'])
          : null,
      onExit: data['onExitId'] != null
          ? (_) => runtime.triggerAction(data['onExitId'])
          : null,
      child: runtime.decodeWidget(data['child'], context),
    );
  }

  static MouseCursor _parseMouseCursor(String? cursor) {
    switch (cursor) {
      case 'basic':
        return SystemMouseCursors.basic;
      case 'click':
        return SystemMouseCursors.click;
      case 'text':
        return SystemMouseCursors.text;
      case 'resizeLeftRight':
        return SystemMouseCursors.resizeLeftRight;
      case 'resizeUpDown':
        return SystemMouseCursors.resizeUpDown;
      case 'resizeColumn':
        return SystemMouseCursors.resizeColumn;
      case 'resizeRow':
        return SystemMouseCursors.resizeRow;
      case 'grab':
        return SystemMouseCursors.grab;
      case 'grabbing':
        return SystemMouseCursors.grabbing;
      case 'move':
        return SystemMouseCursors.move;
      case 'forbidden':
        return SystemMouseCursors.forbidden;
      case 'wait':
        return SystemMouseCursors.wait;
      default:
        return MouseCursor.defer;
    }
  }
}

MainAxisAlignment _parseMainAxisAlignment(dynamic raw) {
  if (raw == 'start') return MainAxisAlignment.start;
  if (raw == 'end') return MainAxisAlignment.end;
  if (raw == 'spaceBetween') return MainAxisAlignment.spaceBetween;
  if (raw == 'spaceAround') return MainAxisAlignment.spaceAround;
  if (raw == 'spaceEvenly') return MainAxisAlignment.spaceEvenly;
  return MainAxisAlignment.start;
}

CrossAxisAlignment _parseCrossAxisAlignment(dynamic raw) {
  if (raw == 'start') return CrossAxisAlignment.start;
  if (raw == 'end') return CrossAxisAlignment.end;
  if (raw == 'center') return CrossAxisAlignment.center;
  if (raw == 'stretch') return CrossAxisAlignment.stretch;
  if (raw == 'baseline') return CrossAxisAlignment.baseline;
  return CrossAxisAlignment.center;
}

// =============================================================================
// CustomPaint
// =============================================================================

class FlutCustomPaint {
  FlutCustomPaint._();

  static CustomPaint flutDecode(
    Map<String, dynamic> data,
    FlutRuntime runtime,
    BuildContext context,
  ) {
    final size = data['size'] ?? [0, 0];
    return CustomPaint(
      size: Size(
        (size[0] as num?)?.toDouble() ?? 0,
        (size[1] as num?)?.toDouble() ?? 0,
      ),
      painter: _FlutJSONPainter(data['painter']),
      child: runtime.decodeWidget(data['child'], context),
    );
  }
}

class _FlutJSONPainter extends CustomPainter {
  final Map<String, dynamic>? data;
  _FlutJSONPainter(this.data);

  @override
  void paint(Canvas canvas, Size size) {
    if (data == null || data!['commands'] == null) return;

    final commands = data!['commands'] as List;
    for (final cmd in commands) {
      final type = cmd['cmd'];
      final paint = _parsePaint(cmd['paint']);

      if (type == 'drawLine') {
        final p1 = _parseOffset(cmd['p1']);
        final p2 = _parseOffset(cmd['p2']);
        canvas.drawLine(p1, p2, paint);
      } else if (type == 'drawCircle') {
        final c = _parseOffset(cmd['c']);
        final radius = (cmd['radius'] as num).toDouble();
        canvas.drawCircle(c, radius, paint);
      } else if (type == 'drawRect') {
        final r = cmd['rect'] as List;
        final rect = Rect.fromLTWH(
          (r[0] as num).toDouble(),
          (r[1] as num).toDouble(),
          (r[2] as num).toDouble(),
          (r[3] as num).toDouble(),
        );
        canvas.drawRect(rect, paint);
      }
    }
  }

  Offset _parseOffset(dynamic list) {
    final l = list as List;
    return Offset((l[0] as num).toDouble(), (l[1] as num).toDouble());
  }

  Paint _parsePaint(dynamic map) {
    final paint = Paint();
    if (map['color'] != null) paint.color = Color(map['color']);
    if (map['strokeWidth'] != null) {
      paint.strokeWidth = (map['strokeWidth'] as num).toDouble();
    }
    if (map['style'] == 'stroke') {
      paint.style = PaintingStyle.stroke;
    } else {
      paint.style = PaintingStyle.fill;
    }
    return paint;
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}
