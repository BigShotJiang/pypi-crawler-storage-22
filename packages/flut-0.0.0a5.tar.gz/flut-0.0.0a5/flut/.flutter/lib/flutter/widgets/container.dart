import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';

class FlutContainer {
  FlutContainer._();

  static Container flutDecode(
    Map<String, dynamic> data,
    FlutRuntime runtime,
    BuildContext context,
  ) {
    final decoration = runtime.parseBoxDecoration(data['decoration']);

    return Container(
      padding: runtime.parseEdgeInsets(data['padding']),
      margin: runtime.parseEdgeInsets(data['margin']),
      width: (data['width'] as num?)?.toDouble(),
      height: (data['height'] as num?)?.toDouble(),
      color: decoration == null && data['color'] != null
          ? Color(data['color'])
          : null,
      decoration: decoration,
      alignment: runtime.parseAlignmentNullable(data['alignment']),
      child: runtime.decodeWidget(data['child'], context),
    );
  }
}
