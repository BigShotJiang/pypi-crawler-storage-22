import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flut/flut/object.dart';
import 'package:flut/flut/runtime.dart';

class FlutFocusNode extends FocusNode with FlutRealtimeObject {
  FlutFocusNode._({
    required FlutRuntime runtime,
    required int flutOid,
    required String? onKeyEventId,
  }) {
    initFlutRealtimeObject(runtime: runtime, flutOid: flutOid);
    if (onKeyEventId != null) {
      onKeyEvent = (node, event) {
        String eventType;
        if (event is KeyDownEvent) {
          eventType = 'down';
        } else if (event is KeyUpEvent) {
          eventType = 'up';
        } else if (event is KeyRepeatEvent) {
          eventType = 'repeat';
        } else {
          return KeyEventResult.ignored;
        }

        final keyData = {
          'type': eventType,
          'logicalKeyId': event.logicalKey.keyId,
          'physicalKeyUsage': event.physicalKey.usbHidUsage,
          'character': event.character,
          'timeStamp': event.timeStamp.inMicroseconds / 1000000.0,
          'synthesized': event.synthesized,
        };

        final result = flutRuntime.invokeAction(
          onKeyEventId,
          payload: {'keyData': keyData},
        );
        String actionResult = 'ignored';
        if (result != null) {
          try {
            actionResult = result['result'] ?? 'ignored';
          } catch (_) {}
        }

        switch (actionResult) {
          case 'handled':
            return KeyEventResult.handled;
          case 'skipRemainingHandlers':
            return KeyEventResult.skipRemainingHandlers;
          default:
            return KeyEventResult.ignored;
        }
      };
    }
  }

  static FlutFocusNode flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> json,
  ) {
    final oid = json['_flut_oid'] as int;
    return FlutFocusNode._(
      runtime: runtime,
      flutOid: oid,
      onKeyEventId: json['onKeyEventId'] as String?,
    );
  }

  @override
  Map<String, dynamic> flutEncode() {
    return {'_flut_oid': flutOid, '_flut_type': 'FocusNode'};
  }

  @override
  dynamic getRawProperty(String property) {
    switch (property) {
      case 'hasFocus':
        return hasFocus;
      case 'hasPrimaryFocus':
        return hasPrimaryFocus;
    }
    throw StateError('Unknown property: $property');
  }

  @override
  bool setProperty(String property, dynamic value) {
    throw StateError('Unknown property: $property');
  }

  @override
  dynamic callMethod(String method, Map<String, dynamic> args) {
    switch (method) {
      case 'requestFocus':
        requestFocus();
        return true;
      case 'unfocus':
        unfocus();
        return true;
    }
    throw StateError('Unknown method: $method');
  }
}
