import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';

class FlutIcon {
  FlutIcon._();

  static Icon flutDecode(
    Map<String, dynamic> data,
    FlutRuntime runtime,
    BuildContext context,
  ) {
    final iconColor = data['color'] != null ? Color(data['color']) : null;
    final iconSize = (data['size'] as num?)?.toDouble();
    final iconData = runtime.decodeIconData(data['icon'] as Map<String, dynamic>?);

    return Icon(
      iconData,
      color: iconColor,
      size: iconSize,
    );
  }
}
