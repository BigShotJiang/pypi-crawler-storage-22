import 'package:flutter/material.dart';
import 'package:flut/flut/object.dart';

class FlutIconData extends FlutImmutableObject {
  final IconData iconData;

  const FlutIconData(this.iconData);

  @override
  Map<String, dynamic> flutEncode() {
    return {
      'codePoint': iconData.codePoint,
      'fontFamily': iconData.fontFamily,
      'fontPackage': iconData.fontPackage,
      'matchTextDirection': iconData.matchTextDirection,
    };
  }

  static IconData flutDecode(Map<String, dynamic>? data) {
    if (data == null) {
      return const IconData(0);
    }
    return IconData(
      (data['codePoint'] as num).toInt(),
      fontFamily: data['fontFamily'] as String?,
      fontPackage: data['fontPackage'] as String?,
      matchTextDirection: data['matchTextDirection'] as bool? ?? false,
    );
  }
}
