import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';
import 'package:flut/flut/error.dart';

class FlutAnimatedOpacity {
  FlutAnimatedOpacity._();

  static AnimatedOpacity flutDecode(
    Map<String, dynamic> data,
    FlutRuntime runtime,
    BuildContext context,
  ) {
    final opacity = data['opacity'];
    if (opacity == null) {
      throw FlutMissingRequiredParameterException('AnimatedOpacity', 'opacity');
    }
    final duration = data['duration'];
    if (duration == null) {
      throw FlutMissingRequiredParameterException('AnimatedOpacity', 'duration');
    }
    return AnimatedOpacity(
      opacity: (opacity as num).toDouble(),
      duration: Duration(milliseconds: (duration as num).toInt()),
      child: runtime.decodeWidget(data['child'], context),
    );
  }
}
