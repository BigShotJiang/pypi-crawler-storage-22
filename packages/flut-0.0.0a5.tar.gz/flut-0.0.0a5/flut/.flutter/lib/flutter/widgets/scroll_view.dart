import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';

class FlutListView {
  FlutListView._();

  static ListView flutDecode(
    Map<String, dynamic> data,
    FlutRuntime runtime,
    BuildContext context,
  ) {
    final controllerData = data['controller'] as Map<String, dynamic>?;
    final children =
        (data['children'] as List?)
            ?.map((c) => runtime.decodeWidget(c, context))
            .whereType<Widget>()
            .toList() ??
        [];
    final reverse = data['reverse'] as bool? ?? false;
    final controller = runtime.parseScrollController(controllerData);

    return ListView(
      controller: controller,
      padding: runtime.parseEdgeInsets(data['padding']),
      reverse: reverse,
      children: children,
    );
  }
}
