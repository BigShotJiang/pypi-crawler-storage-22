import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';

class FlutSingleChildScrollView {
  FlutSingleChildScrollView._();

  static SingleChildScrollView flutDecode(
    Map<String, dynamic> data,
    FlutRuntime runtime,
    BuildContext context,
  ) {
    return SingleChildScrollView(
      padding: runtime.parseEdgeInsets(data['padding']),
      scrollDirection: data['scrollDirection'] == 'horizontal'
          ? Axis.horizontal
          : Axis.vertical,
      child: runtime.decodeWidget(data['child'], context),
    );
  }
}
