import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';

class FlutVisibility {
  FlutVisibility._();

  static Visibility flutDecode(
    Map<String, dynamic> data,
    FlutRuntime runtime,
    BuildContext context,
  ) {
    final child = runtime.decodeWidget(data['child'], context);
    if (child == null) {
      throw ArgumentError('Visibility: missing required "child"');
    }
    return Visibility(visible: data['visible'] ?? true, child: child);
  }
}
