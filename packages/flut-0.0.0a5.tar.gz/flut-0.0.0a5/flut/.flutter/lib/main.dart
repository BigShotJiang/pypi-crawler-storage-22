import 'package:flutter/material.dart';
import 'flut/native.dart';
import 'flut/runtime.dart';

late final FlutNative flutNative;
late final FlutRuntime flutRuntime;

void main(List<String> args) {
  int? nativeCallbackAddr;
  for (final arg in args) {
    if (arg.startsWith('--native-callback=')) {
      nativeCallbackAddr = int.tryParse(
        arg.substring('--native-callback='.length),
      );
    }
  }

  flutNative = FlutFfiNative(nativeCallbackAddr ?? 0);
  flutRuntime = FlutRuntime(flutNative);

  Map<String, dynamic>? rootData;
  String? error;

  try {
    rootData = flutNative.invokeNativeSync("widget_build", {});
  } catch (e) {
    error = e.toString();
  }

  if (error != null) {
    runApp(
      MaterialApp(
        home: Scaffold(
          body: Center(
            child: Text(
              "Error: $error",
              style: const TextStyle(color: Colors.red),
            ),
          ),
        ),
      ),
    );
  } else {
    runApp(
      Builder(
        builder: (context) =>
            flutRuntime.buildWidgetFromJson(rootData!, context),
      ),
    );
  }
}
