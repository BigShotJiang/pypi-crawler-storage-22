

class _ThemeColorRef:
    def __init__(self, name: str):
        self.name = name

    def to_json(self):
        # Protocol value: Dart resolves this using Theme.of(context).colorScheme.<name>
        return {"ref": f"theme.colorScheme.{self.name}"}


class _ThemeTextStyleRef:
    def __init__(self, name: str):
        self.name = name

    def to_json(self):
        # Protocol value: Dart resolves this using Theme.of(context).textTheme.<name>
        return {"ref": f"theme.textTheme.{self.name}"}


