
from flut.flutter.widgets.framework import Widget


class MaterialApp(Widget):
    def __init__(self, home=None, title="Flutter Python", theme=None):
        super().__init__()
        self.home = home
        self.title = title
        self.theme = theme

    def to_json(self):
        return {
            "type": "MaterialApp",
            "title": self.title,
            "theme": self.theme.to_json() if self.theme else None,
            "home": self.home.to_json() if self.home else None,
        }
