
from flut.flutter.widgets.framework import Widget


class AppBar(Widget):
    def __init__(self, title=None, backgroundColor=None, scrolledUnderElevation=None):
        super().__init__()
        self.title = title
        self.backgroundColor = backgroundColor
        self.scrolledUnderElevation = scrolledUnderElevation

    def to_json(self):
        background = self.backgroundColor
        if hasattr(background, "to_json"):
            background = background.to_json()
        return {
            "type": "AppBar",
            "title": self.title.to_json() if self.title else None,
            "backgroundColor": background,
            "scrolledUnderElevation": self.scrolledUnderElevation,
        }
