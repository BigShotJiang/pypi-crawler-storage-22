from flut.flutter.widgets.framework import Widget


class Card(Widget):
    def __init__(self, child=None, color=None, elevation=None, margin=None):
        super().__init__()
        self.child = child
        self.color = color
        self.elevation = elevation
        self.margin = margin

    def to_json(self):
        return {
            "type": "Card",
            "child": self.child.to_json() if self.child else None,
            "color": self.color,
            "elevation": self.elevation,
            "margin": self.margin.to_json() if self.margin else None,
        }
