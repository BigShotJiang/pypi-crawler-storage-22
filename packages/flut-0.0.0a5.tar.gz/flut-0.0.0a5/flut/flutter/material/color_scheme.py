class ColorScheme:
    def __init__(
        self,
        seedColor=None,
        primary=None,
        onPrimary=None,
        secondary=None,
        onSecondary=None,
        surface=None,
        onSurface=None,
        error=None,
        onError=None,
        inversePrimary=None,
    ):
        self.seedColor = seedColor
        self.primary = primary
        self.onPrimary = onPrimary
        self.secondary = secondary
        self.onSecondary = onSecondary
        self.surface = surface
        self.onSurface = onSurface
        self.error = error
        self.onError = onError
        self.inversePrimary = inversePrimary

    @staticmethod
    def fromSeed(seedColor):
        return ColorScheme(seedColor=seedColor)

    def to_json(self):
        return {"seedColor": self.seedColor}