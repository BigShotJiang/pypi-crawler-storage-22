from flut.flutter.widgets.framework import Widget


class Divider(Widget):
    def __init__(self, height=1, thickness=1, color=None):
        super().__init__()
        self.height = height
        self.thickness = thickness
        self.color = color

    def to_json(self):
        return {
            "type": "Divider",
            "height": self.height,
            "thickness": self.thickness,
            "color": self.color,
        }
