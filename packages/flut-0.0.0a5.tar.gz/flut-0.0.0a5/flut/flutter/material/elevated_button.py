from flut._flut.engine import get_engine
from flut.flutter.widgets.framework import Widget


class ElevatedButton(Widget):
    def __init__(self, child, onPressed=None):
        super().__init__()
        self.child = child
        self.onPressed = onPressed

    def to_json(self):
        onPressedId = None
        if self.onPressed:
            onPressedId = get_engine().register_action(
                self._flut_id, 0, self.onPressed
            )

        return {
            "type": "ElevatedButton",
            "child": self.child.to_json() if self.child else None,
            "onPressedId": onPressedId,
        }
