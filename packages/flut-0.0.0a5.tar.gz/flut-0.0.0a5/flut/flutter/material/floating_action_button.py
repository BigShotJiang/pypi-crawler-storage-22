from flut._flut.engine import get_engine
from flut.flutter.widgets.framework import Widget


class FloatingActionButton(Widget):
    def __init__(self, child=None, onPressed=None, tooltip=None):
        super().__init__()
        self.child = child
        self.onPressed = onPressed
        self.tooltip = tooltip

    def to_json(self):
        action_id = None
        if self.onPressed:
            action_id = get_engine().register_action(self._flut_id, 0, self.onPressed)
        return {
            "type": "FloatingActionButton",
            "child": self.child.to_json() if self.child else None,
            "tooltip": self.tooltip,
            "onPressedId": action_id,
        }

