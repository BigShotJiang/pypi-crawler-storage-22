from flut._flut.engine import get_engine
from flut.flutter.widgets.framework import Widget


class IconButton(Widget):
    def __init__(
        self,
        icon,
        onPressed=None,
        color=None,
        iconSize=None,
        tooltip=None,
    ):
        super().__init__()
        self.icon = icon
        self.onPressed = onPressed
        self.color = color
        self.iconSize = iconSize
        self.tooltip = tooltip

    def to_json(self):
        engine = get_engine()
        on_pressed_id = None
        if self.onPressed:
            on_pressed_id = engine.register_action(self._flut_id, 0, self.onPressed)
        return {
            "type": "IconButton",
            "icon": self.icon.to_json() if hasattr(self.icon, "to_json") else self.icon,
            "onPressedId": on_pressed_id,
            "color": self.color,
            "iconSize": self.iconSize,
            "tooltip": self.tooltip,
        }
