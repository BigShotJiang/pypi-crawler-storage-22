from flut._flut.engine import get_engine
from flut.flutter.widgets.framework import Widget


class InkWell(Widget):
    def __init__(self, child=None, onTap=None):
        super().__init__()
        self.child = child
        self.onTap = onTap

    def to_json(self):
        engine = get_engine()
        on_tap_id = None
        if self.onTap:
            on_tap_id = engine.register_action(self._flut_id, 0, self.onTap)
        return {
            "type": "InkWell",
            "onTapId": on_tap_id,
            "child": self.child.to_json() if self.child else None,
        }
