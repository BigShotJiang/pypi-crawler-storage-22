class InputDecoration:
    def __init__(
        self,
        hintText=None,
        border=None,
        filled=False,
        fillColor=None,
        contentPadding=None,
    ):
        self.hintText = hintText
        self.border = border
        self.filled = filled
        self.fillColor = fillColor
        self.contentPadding = contentPadding

    def to_json(self):
        return {
            "hintText": self.hintText,
            "border": self.border,
            "filled": self.filled,
            "fillColor": self.fillColor,
            "contentPadding": (
                self.contentPadding.to_json() if self.contentPadding else None
            ),
        }
