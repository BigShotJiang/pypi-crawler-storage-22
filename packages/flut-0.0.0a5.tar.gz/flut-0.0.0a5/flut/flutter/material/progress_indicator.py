from flut.flutter.widgets.framework import Widget


class CircularProgressIndicator(Widget):
    def __init__(self, strokeWidth=4.0, color=None):
        super().__init__()
        self.strokeWidth = strokeWidth
        self.color = color

    def to_json(self):
        return {
            "type": "CircularProgressIndicator",
            "strokeWidth": self.strokeWidth,
            "color": self.color,
        }
