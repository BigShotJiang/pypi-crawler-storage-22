from flut.flutter.widgets.framework import Widget


class Scaffold(Widget):
    def __init__(self, body=None, appBar=None, floatingActionButton=None):
        super().__init__()
        self.body = body
        self.appBar = appBar
        self.floatingActionButton = floatingActionButton

    def to_json(self):
        return {
            "type": "Scaffold",
            "body": self.body.to_json() if self.body else None,
            "appBar": self.appBar.to_json() if self.appBar else None,
            "floatingActionButton": (
                self.floatingActionButton.to_json()
                if self.floatingActionButton
                else None
            ),
        }
