from ..widgets.framework import Widget


class SelectableText(Widget):
    def __init__(
        self,
        data,
        style=None,
        maxLines=None,
    ):
        super().__init__()
        self.data = data
        self.style = style
        self.maxLines = maxLines

    def to_json(self):
        style = self.style
        if style is not None and hasattr(style, "to_json"):
            style = style.to_json()
        return {
            "type": "SelectableText",
            "data": str(self.data),
            "style": style,
            "maxLines": self.maxLines,
        }
