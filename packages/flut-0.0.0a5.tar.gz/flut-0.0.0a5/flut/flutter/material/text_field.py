from flut._flut.engine import get_engine
from flut.flutter.widgets.framework import Widget


class TextField(Widget):
    def __init__(
        self,
        controller=None,
        focusNode=None,
        onChanged=None,
        onSubmitted=None,
        readOnly=False,
        maxLines=1,
        minLines=None,
        decoration=None,
        style=None,
    ):
        super().__init__()
        self.controller = controller
        self.focusNode = focusNode
        self.onChanged = onChanged
        self.onSubmitted = onSubmitted
        self.readOnly = readOnly
        self.maxLines = maxLines
        self.minLines = minLines
        self.decoration = decoration
        self.style = style

    def to_json(self):
        engine = get_engine()
        on_changed_id = None
        on_submitted_id = None
        if self.onChanged:
            on_changed_id = engine.register_action(self._flut_id, 0, self.onChanged)
        if self.onSubmitted:
            on_submitted_id = engine.register_action(self._flut_id, 1, self.onSubmitted)

        if self.focusNode:
            self.focusNode._register()

        return {
            "type": "TextField",
            "id": self._flut_id,
            "controller": self.controller.to_json() if self.controller else None,
            "focusNode": self.focusNode.to_json() if self.focusNode else None,
            "onChangedId": on_changed_id,
            "onSubmittedId": on_submitted_id,
            "readOnly": self.readOnly,
            "maxLines": self.maxLines,
            "minLines": self.minLines,
            "decoration": self.decoration.to_json() if self.decoration else None,
            "style": self.style.to_json() if self.style else None,
        }
