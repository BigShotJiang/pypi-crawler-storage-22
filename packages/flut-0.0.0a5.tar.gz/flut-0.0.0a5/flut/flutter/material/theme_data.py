from flut.flutter.material.text_theme import TextTheme


class ThemeData:
    def __init__(self, colorScheme=None, useMaterial3=True, textTheme=None):
        self.colorScheme = colorScheme
        self.useMaterial3 = useMaterial3
        self.textTheme = textTheme or TextTheme()

    def to_json(self):
        return {
            "colorScheme": self.colorScheme.to_json() if self.colorScheme else None,
            "useMaterial3": self.useMaterial3,
        }
