class BorderRadius:
    def __init__(self, topLeft=0, topRight=0, bottomLeft=0, bottomRight=0):
        self.topLeft = topLeft
        self.topRight = topRight
        self.bottomLeft = bottomLeft
        self.bottomRight = bottomRight

    @staticmethod
    def circular(radius):
        return BorderRadius(radius, radius, radius, radius)

    @staticmethod
    def all(radius):
        return BorderRadius.circular(radius)

    def to_json(self):
        return {
            "topLeft": self.topLeft,
            "topRight": self.topRight,
            "bottomLeft": self.bottomLeft,
            "bottomRight": self.bottomRight,
        }
