class BorderSide:
    def __init__(self, color=0xFF000000, width=1.0):
        self.color = color
        self.width = width

    def to_json(self):
        return {"color": self.color, "width": self.width}


class Border:
    def __init__(self, left=None, top=None, right=None, bottom=None):
        self.left = left
        self.top = top
        self.right = right
        self.bottom = bottom

    @staticmethod
    def all(width=1.0, color=0xFF000000):
        side = BorderSide(color, width)
        return Border(side, side, side, side)

    def to_json(self):
        return {
            "left": self.left.to_json() if self.left else None,
            "top": self.top.to_json() if self.top else None,
            "right": self.right.to_json() if self.right else None,
            "bottom": self.bottom.to_json() if self.bottom else None,
        }
