from .border_radius import BorderRadius


class BoxDecoration:
    def __init__(
        self,
        color=None,
        border=None,
        borderRadius=None,
    ):
        self.color = color
        self.border = border
        self.borderRadius = borderRadius

    def to_json(self):
        border_radius = self.borderRadius
        if isinstance(border_radius, (int, float)):
            border_radius = BorderRadius.circular(border_radius)
        return {
            "color": self.color,
            "border": self.border.to_json() if self.border else None,
            "borderRadius": border_radius.to_json() if border_radius else None,
        }
