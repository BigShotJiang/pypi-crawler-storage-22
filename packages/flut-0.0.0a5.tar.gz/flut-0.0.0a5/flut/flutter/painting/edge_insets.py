class EdgeInsets:
    def __init__(self, left=0, top=0, right=0, bottom=0):
        self.left = left
        self.top = top
        self.right = right
        self.bottom = bottom

    @staticmethod
    def all(value):
        return EdgeInsets(value, value, value, value)

    @staticmethod
    def symmetric(vertical=0, horizontal=0):
        return EdgeInsets(horizontal, vertical, horizontal, vertical)

    @staticmethod
    def only(left=0, top=0, right=0, bottom=0):
        return EdgeInsets(left, top, right, bottom)

    def to_json(self):
        return {
            "left": self.left,
            "top": self.top,
            "right": self.right,
            "bottom": self.bottom,
        }
