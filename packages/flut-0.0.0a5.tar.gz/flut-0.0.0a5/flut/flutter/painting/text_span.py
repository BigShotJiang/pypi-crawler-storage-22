class TextSpan:
    def __init__(self, text=None, children=None, style=None):
        self.text = text
        self.children = children
        self.style = style

    def to_json(self):
        style = self.style
        if style is not None and hasattr(style, "to_json"):
            style = style.to_json()

        children = None
        if self.children is not None:
            children = [child.to_json() for child in self.children]

        return {
            "text": self.text,
            "children": children,
            "style": style,
        }
