class FontWeight:
    bold = "bold"
    normal = "normal"
    w100 = "w100"
    w200 = "w200"
    w300 = "w300"
    w400 = "w400"
    w500 = "w500"
    w600 = "w600"
    w700 = "w700"
    w800 = "w800"
    w900 = "w900"


class TextStyle:
    def __init__(
        self,
        fontSize=None,
        fontWeight=None,
        color=None,
        fontFamily=None,
        height=None,
    ):
        self.fontSize = fontSize
        self.fontWeight = fontWeight
        self.color = color
        self.fontFamily = fontFamily
        self.height = height

    def to_json(self):
        return {
            "fontSize": self.fontSize,
            "fontWeight": self.fontWeight,
            "color": self.color,
            "fontFamily": self.fontFamily,
            "height": self.height,
        }
