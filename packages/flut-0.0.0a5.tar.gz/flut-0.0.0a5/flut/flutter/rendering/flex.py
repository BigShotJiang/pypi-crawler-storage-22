class MainAxisAlignment:
    center = "center"
    start = "start"
    end = "end"
    spaceBetween = "spaceBetween"
    spaceAround = "spaceAround"
    spaceEvenly = "spaceEvenly"


class CrossAxisAlignment:
    center = "center"
    start = "start"
    end = "end"
    stretch = "stretch"
    baseline = "baseline"
