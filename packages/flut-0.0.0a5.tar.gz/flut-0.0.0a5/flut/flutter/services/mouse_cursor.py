class SystemMouseCursors:

    basic = "basic"
    click = "click"
    text = "text"
    resizeLeftRight = "resizeLeftRight"
    resizeUpDown = "resizeUpDown"
    resizeColumn = "resizeColumn"
    resizeRow = "resizeRow"
    grab = "grab"
    grabbing = "grabbing"
    move = "move"
    forbidden = "forbidden"
    wait = "wait"
