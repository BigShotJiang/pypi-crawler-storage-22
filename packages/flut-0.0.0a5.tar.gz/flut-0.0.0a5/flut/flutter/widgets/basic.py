from flut._flut.engine import get_engine
from .framework import Widget


class ScrollMode:
    auto = "auto"
    always = "always"
    hidden = "hidden"
    adaptive = "adaptive"


class Center(Widget):
    def __init__(self, child):
        super().__init__()
        self.child = child

    def to_json(self):
        return {"type": "Center", "child": self.child.to_json() if self.child else None}


class Expanded(Widget):
    def __init__(self, child, flex=1):
        super().__init__()
        self.child = child
        self.flex = flex

    def to_json(self):
        return {
            "type": "Expanded",
            "flex": self.flex,
            "child": self.child.to_json() if self.child else None,
        }


class Flexible(Widget):
    def __init__(self, child, flex=1, fit=None):
        super().__init__()
        self.child = child
        self.flex = flex
        self.fit = fit

    def to_json(self):
        return {
            "type": "Flexible",
            "flex": self.flex,
            "fit": self.fit,
            "child": self.child.to_json() if self.child else None,
        }


class SizedBox(Widget):
    def __init__(self, width=None, height=None, child=None):
        super().__init__()
        self.width = width
        self.height = height
        self.child = child

    def to_json(self):
        return {
            "type": "SizedBox",
            "width": self.width,
            "height": self.height,
            "child": self.child.to_json() if self.child else None,
        }


class Column(Widget):
    def __init__(
        self,
        children,
        mainAxisAlignment=None,
        crossAxisAlignment=None,
        spacing=None,
    ):
        super().__init__()
        self.children = children
        self.mainAxisAlignment = mainAxisAlignment
        self.crossAxisAlignment = crossAxisAlignment
        self.spacing = spacing

    def to_json(self):
        return {
            "type": "Column",
            "mainAxisAlignment": self.mainAxisAlignment,
            "crossAxisAlignment": self.crossAxisAlignment,
            "spacing": self.spacing,
            "children": [c.to_json() for c in self.children],
        }


class Row(Widget):
    def __init__(
        self,
        children,
        mainAxisAlignment=None,
        crossAxisAlignment=None,
        spacing=None,
    ):
        super().__init__()
        self.children = children
        self.mainAxisAlignment = mainAxisAlignment
        self.crossAxisAlignment = crossAxisAlignment
        self.spacing = spacing

    def to_json(self):
        return {
            "type": "Row",
            "mainAxisAlignment": self.mainAxisAlignment,
            "crossAxisAlignment": self.crossAxisAlignment,
            "spacing": self.spacing,
            "children": [c.to_json() for c in self.children],
        }


class Stack(Widget):
    def __init__(self, children):
        super().__init__()
        self.children = children

    def to_json(self):
        return {
            "type": "Stack",
            "children": [c.to_json() for c in self.children],
        }


class Positioned(Widget):
    def __init__(
        self,
        child,
        left=None,
        top=None,
        right=None,
        bottom=None,
        width=None,
        height=None,
    ):
        super().__init__()
        self.child = child
        self.left = left
        self.top = top
        self.right = right
        self.bottom = bottom
        self.width = width
        self.height = height

    def to_json(self):
        return {
            "type": "Positioned",
            "left": self.left,
            "top": self.top,
            "right": self.right,
            "bottom": self.bottom,
            "width": self.width,
            "height": self.height,
            "child": self.child.to_json() if self.child else None,
        }


class MouseRegion(Widget):

    def __init__(self, child=None, cursor=None, onEnter=None, onExit=None):
        super().__init__()
        self.child = child
        self.cursor = cursor
        self.onEnter = onEnter
        self.onExit = onExit

    def to_json(self):
        engine = get_engine()
        on_enter_id = None
        on_exit_id = None
        if self.onEnter:
            on_enter_id = engine.register_action(self._flut_id, 0, self.onEnter)
        if self.onExit:
            on_exit_id = engine.register_action(self._flut_id, 1, self.onExit)
        return {
            "type": "MouseRegion",
            "cursor": self.cursor,
            "onEnterId": on_enter_id,
            "onExitId": on_exit_id,
            "child": self.child.to_json() if self.child else None,
        }


class Padding(Widget):
    def __init__(self, padding, child):
        super().__init__()
        self.padding = padding
        self.child = child

    def to_json(self):
        return {
            "type": "Padding",
            "padding": self.padding.to_json() if self.padding else None,
            "child": self.child.to_json() if self.child else None,
        }


class Align(Widget):
    def __init__(self, alignment, child):
        super().__init__()
        self.alignment = alignment
        self.child = child

    def to_json(self):
        return {
            "type": "Align",
            "alignment": self.alignment,
            "child": self.child.to_json() if self.child else None,
        }


class Opacity(Widget):
    def __init__(self, opacity, child):
        super().__init__()
        self.opacity = opacity
        self.child = child

    def to_json(self):
        return {
            "type": "Opacity",
            "opacity": self.opacity,
            "child": self.child.to_json() if self.child else None,
        }


class ClipRRect(Widget):
    def __init__(self, borderRadius, child):
        super().__init__()
        self.borderRadius = borderRadius
        self.child = child

    def to_json(self):
        return {
            "type": "ClipRRect",
            "borderRadius": self.borderRadius.to_json() if self.borderRadius else None,
            "child": self.child.to_json() if self.child else None,
        }


class Spacer(Widget):
    def __init__(self, flex=1):
        super().__init__()
        self.flex = flex

    def to_json(self):
        return {"type": "Spacer", "flex": self.flex}


# =============================================================================
# CustomPaint
# =============================================================================


class CustomPainter:
    def __init__(self):
        self.commands = []

    def drawLine(self, p1, p2, paint):
        self.commands.append(
            {"cmd": "drawLine", "p1": p1, "p2": p2, "paint": paint.to_json()}
        )

    def drawCircle(self, c, radius, paint):
        self.commands.append(
            {"cmd": "drawCircle", "c": c, "radius": radius, "paint": paint.to_json()}
        )

    def drawRect(self, rect, paint):
        self.commands.append({"cmd": "drawRect", "rect": rect, "paint": paint.to_json()})

    def to_json(self):
        return {"commands": self.commands}


class CustomPaint(Widget):
    def __init__(self, painter=None, child=None, size=(0, 0)):
        super().__init__()
        self.child = child
        self.painter = painter
        self.size = size

    def to_json(self):
        return {
            "type": "CustomPaint",
            "painter": self.painter.to_json() if self.painter else None,
            "child": self.child.to_json() if self.child else None,
            "size": [self.size[0], self.size[1]],
        }
