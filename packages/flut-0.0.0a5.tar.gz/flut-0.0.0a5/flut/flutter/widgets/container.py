from .framework import Widget


class Container(Widget):
    def __init__(
        self,
        child=None,
        padding=None,
        margin=None,
        color=None,
        width=None,
        height=None,
        decoration=None,
        alignment=None,
    ):
        super().__init__()
        self.child = child
        self.padding = padding
        self.margin = margin
        self.color = color
        self.width = width
        self.height = height
        self.decoration = decoration
        self.alignment = alignment

    def to_json(self):
        return {
            "type": "Container",
            "child": self.child.to_json() if self.child else None,
            "padding": self.padding.to_json() if self.padding else None,
            "margin": self.margin.to_json() if self.margin else None,
            "color": self.color,
            "width": self.width,
            "height": self.height,
            "decoration": self.decoration.to_json() if self.decoration else None,
            "alignment": self.alignment,
        }
