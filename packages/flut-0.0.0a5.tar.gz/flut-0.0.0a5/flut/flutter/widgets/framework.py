from typing import Generic, Optional, TypeVar
from flut._flut.engine import FlutObject, FlutRealtimeObject, get_engine


class BuildContext(FlutRealtimeObject):

    def __init__(self, oid: int):
        super().__init__(oid=oid)



class Widget(FlutObject):

    def __init__(self):
        super().__init__()

    def to_json(self):
        raise NotImplementedError


class StatelessWidget(Widget):

    def __init__(self, key=None):
        super().__init__()
        self._key = key

    def build(self, context):
        raise NotImplementedError

    def to_json(self):
        get_engine().widget_registry[self._flut_id] = self
        data = {
            "type": "StatelessWidget",
            "id": self._flut_id,
            "className": self.__class__.__name__,
        }
        if self._key is not None:
            data["key"] = self._key
        return data


TWidget = TypeVar("TWidget", bound="StatefulWidget")


class State(Generic[TWidget]):

    def __init__(self):
        self._flut_widget: Optional[TWidget] = None
        self._flut_id: Optional[str] = None
        self._flut_last_build_context: Optional[BuildContext] = None
        self._flut_registered_actions: list = []  # Actions registered during build

    @property
    def widget(self) -> TWidget:
        return self._flut_widget

    @property
    def context(self) -> Optional[BuildContext]:
        return self._flut_last_build_context

    def initState(self):
        pass

    def didUpdateWidget(self, oldWidget: TWidget):
        pass

    def build(self, context: BuildContext):
        raise NotImplementedError

    def setState(self, fn):
        if fn:
            fn()

        engine = get_engine()
        if engine:
            engine.notify_set_state(self._flut_id)


class StatefulWidget(Widget):

    def __init__(self, key=None):
        super().__init__()
        self._key = key

    def createState(self):
        raise NotImplementedError

    def to_json(self):
        get_engine().widget_registry[self._flut_id] = self

        data = {
            "type": "StatefulWidget",
            "id": self._flut_id,
            "className": self.__class__.__name__,
        }
        if self._key is not None:
            data["key"] = self._key
        return data
