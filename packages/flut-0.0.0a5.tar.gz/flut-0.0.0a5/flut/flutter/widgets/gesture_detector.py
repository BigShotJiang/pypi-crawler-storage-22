from flut._flut.engine import get_engine
from .framework import Widget


class GestureDetector(Widget):
    def __init__(self, child=None, onTap=None, onPanStart=None, onPanUpdate=None, onPanEnd=None):
        super().__init__()
        self.child = child
        self.onTap = onTap
        self.onPanStart = onPanStart
        self.onPanUpdate = onPanUpdate
        self.onPanEnd = onPanEnd

    def to_json(self):
        engine = get_engine()
        on_tap_id = None
        on_pan_start_id = None
        on_pan_update_id = None
        on_pan_end_id = None
        if self.onTap:
            on_tap_id = engine.register_action(self._flut_id, 0, self.onTap)
        if self.onPanStart:
            on_pan_start_id = engine.register_action(self._flut_id, 1, self.onPanStart)
        if self.onPanUpdate:
            on_pan_update_id = engine.register_action(
                self._flut_id, 2, self.onPanUpdate
            )
        if self.onPanEnd:
            on_pan_end_id = engine.register_action(self._flut_id, 3, self.onPanEnd)
        return {
            "type": "GestureDetector",
            "onTapId": on_tap_id,
            "onPanStartId": on_pan_start_id,
            "onPanUpdateId": on_pan_update_id,
            "onPanEndId": on_pan_end_id,
            "child": self.child.to_json() if self.child else None,
        }
