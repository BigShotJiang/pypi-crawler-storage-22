from .framework import Widget
from .icon_data import IconData


class Icon(Widget):

    def __init__(self, icon: IconData, color=None, size=None):
        super().__init__()
        self.icon = icon
        self.color = color
        self.size = size

    def to_json(self):
        return {
            "type": "Icon",
            "icon": self.icon.to_json() if self.icon else None,
            "color": self.color,
            "size": self.size,
        }
