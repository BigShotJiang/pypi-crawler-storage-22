class IconData:

    def __init__(
        self,
        codePoint: int,
        fontFamily: str = None,
        fontPackage: str = None,
        matchTextDirection: bool = False,
    ):
        self.codePoint = codePoint
        self.fontFamily = fontFamily
        self.fontPackage = fontPackage
        self.matchTextDirection = matchTextDirection

    def to_json(self):
        return {
            "codePoint": self.codePoint,
            "fontFamily": self.fontFamily,
            "fontPackage": self.fontPackage,
            "matchTextDirection": self.matchTextDirection,
        }
