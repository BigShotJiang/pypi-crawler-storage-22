from .framework import Widget


class ListView(Widget):
    def __init__(
        self,
        children,
        controller=None,
        padding=None,
        reverse=False,
    ):
        super().__init__()
        self.children = children
        self.controller = controller
        self.padding = padding
        self.reverse = reverse

    def to_json(self):
        return {
            "type": "ListView",
            "controller": self.controller.to_json() if self.controller else None,
            "padding": self.padding.to_json() if self.padding else None,
            "reverse": self.reverse,
            "children": [c.to_json() for c in self.children],
        }
