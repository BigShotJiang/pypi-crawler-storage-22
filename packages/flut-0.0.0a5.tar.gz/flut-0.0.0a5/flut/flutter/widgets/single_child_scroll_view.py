from .framework import Widget


class SingleChildScrollView(Widget):
    def __init__(self, child, controller=None, padding=None, scrollDirection=None):
        super().__init__()
        self.child = child
        self.controller = controller
        self.padding = padding
        self.scrollDirection = scrollDirection

    def to_json(self):
        return {
            "type": "SingleChildScrollView",
            "controller": self.controller.to_json() if self.controller else None,
            "padding": self.padding.to_json() if self.padding else None,
            "scrollDirection": self.scrollDirection,
            "child": self.child.to_json() if self.child else None,
        }
