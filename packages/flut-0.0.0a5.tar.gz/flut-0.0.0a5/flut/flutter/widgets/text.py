from .framework import Widget


class Text(Widget):
    def __init__(
        self,
        data,
        style=None,
        maxLines=None,
        overflow=None,
    ):
        super().__init__()
        self.data = data
        self.style = style
        self.maxLines = maxLines
        self.overflow = overflow

    def to_json(self):
        style = self.style
        if style is not None and hasattr(style, "to_json"):
            style = style.to_json()
        return {
            "type": "Text",
            "data": str(self.data),
            "style": style,
            "maxLines": self.maxLines,
            "overflow": self.overflow,
        }
