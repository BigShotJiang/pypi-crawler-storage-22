from .framework import Widget


class Visibility(Widget):
    def __init__(self, visible, child):
        super().__init__()
        self.visible = visible
        self.child = child

    def to_json(self):
        return {
            "type": "Visibility",
            "visible": self.visible,
            "child": self.child.to_json() if self.child else None,
        }
