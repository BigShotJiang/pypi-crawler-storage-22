import 'package:flut/flut/runtime.dart';

class FlutDuration {
  FlutDuration._();

  static Duration? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> data,
  ) {
    final microseconds = data['microseconds'] as int?;
    if (microseconds != null) {
      return Duration(microseconds: microseconds);
    }
    final milliseconds = data['milliseconds'] as int?;
    if (milliseconds != null) {
      return Duration(milliseconds: milliseconds);
    }
    final seconds = data['seconds'] as int?;
    if (seconds != null) {
      return Duration(seconds: seconds);
    }
    final minutes = data['minutes'] as int?;
    if (minutes != null) {
      return Duration(minutes: minutes);
    }
    final hours = data['hours'] as int?;
    if (hours != null) {
      return Duration(hours: hours);
    }
    final days = data['days'] as int?;
    if (days != null) {
      return Duration(days: days);
    }
    return Duration.zero;
  }
}
