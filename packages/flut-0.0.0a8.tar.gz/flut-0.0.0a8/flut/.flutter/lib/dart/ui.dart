import 'dart:ui';

import 'package:flut/flut/object.dart';

class FlutSize extends FlutImmutableObject {
  final Size size;

  const FlutSize(this.size);

  @override
  Map<String, dynamic> flutEncode() {
    return {'width': size.width, 'height': size.height};
  }
}

class FlutOffset extends FlutImmutableObject {
  final Offset offset;

  const FlutOffset(this.offset);

  @override
  Map<String, dynamic> flutEncode() {
    return {'dx': offset.dx, 'dy': offset.dy};
  }
}
