import 'package:flut/flut/runtime.dart';

/// Base class for immutable objects passed between Dart and Python.
/// These are simple data carriers - no bidirectional sync needed.
///
/// Subclasses must implement:
/// - flutEncode(): Convert to JSON for Python
/// - static flutDecode(dynamic data, FlutRuntime runtime): Decode from JSON
abstract class FlutImmutableObject {
  const FlutImmutableObject();

  /// Encode this object to JSON for Python.
  Map<String, dynamic> flutEncode();
}

class FlutAbstractObject extends Object {}

/// Mixin for objects that support realtime property sync with Python.
/// Use with classes that extend a Flutter class (e.g., TextEditingController).
///
/// Subclasses must implement:
/// - flutEncode(): Return JSON with _flut_oid and _flut_type
/// - static flutDecode(FlutRuntime runtime, Map data): Decode from JSON
mixin FlutRealtimeObject {
  late final FlutRuntime flutRuntime;
  late final int flutOid;

  void initFlutRealtimeObject({
    required FlutRuntime runtime,
    required int flutOid,
  }) {
    flutRuntime = runtime;
    this.flutOid = flutOid;
  }

  /// Encode this object to JSON for Python.
  Map<String, dynamic> flutEncode();

  /// Override to return raw Dart value for a property.
  dynamic getRawProperty(String property);

  /// Generic implementation - calls getRawProperty then encodes.
  dynamic getProperty(String property) {
    return flutRuntime.encodeValue(getRawProperty(property));
  }

  bool setProperty(String property, dynamic value);
  dynamic callMethod(String method, Map<String, dynamic> args);
}
