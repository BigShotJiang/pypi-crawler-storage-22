import 'package:flut/dart/ui.dart';
import 'package:flut/dart/core.dart';
import 'package:flutter/material.dart';
import 'package:flut/flut/object.dart';
import 'package:flut/flut/native.dart';
import 'package:flut/flut/error.dart';
import 'package:flut/flut/widget.dart';
import 'package:flut/flutter/widgets/focus_manager.dart';
import 'package:flut/flutter/material/app_bar.dart';
import 'package:flut/flutter/widgets/basic.dart';
import 'package:flut/flutter/widgets/container.dart';
import 'package:flut/flutter/widgets/editable_text.dart';
import 'package:flut/flutter/widgets/framework.dart';
import 'package:flut/flutter/widgets/gesture_detector.dart';
import 'package:flut/flutter/widgets/icon.dart';
import 'package:flut/flutter/widgets/implicit_animations.dart';
import 'package:flut/flutter/widgets/scroll_controller.dart';
import 'package:flut/flutter/widgets/scroll_position.dart';
import 'package:flut/flutter/widgets/scroll_view.dart';
import 'package:flut/flutter/material/selectable_text.dart';
import 'package:flut/flutter/widgets/single_child_scroll_view.dart';
import 'package:flut/flutter/widgets/text.dart';
import 'package:flut/flutter/widgets/visibility.dart';
import 'package:flut/flutter/material/app.dart';
import 'package:flut/flutter/material/card.dart';
import 'package:flut/flutter/material/divider.dart';
import 'package:flut/flutter/material/elevated_button.dart';
import 'package:flut/flutter/material/floating_action_button.dart';
import 'package:flut/flutter/material/icon_button.dart';
import 'package:flut/flutter/material/ink_well.dart';
import 'package:flut/flutter/material/progress_indicator.dart';
import 'package:flut/flutter/material/scaffold.dart';
import 'package:flut/flutter/material/text_field.dart';
import 'package:flut/flutter/material/theme_data.dart';
import 'package:flut/flutter/painting/alignment.dart';
import 'package:flut/flutter/painting/border_radius.dart';
import 'package:flut/flutter/painting/borders.dart';
import 'package:flut/flutter/painting/box_decoration.dart';
import 'package:flut/flutter/painting/edge_insets.dart';
import 'package:flut/flutter/painting/text_style.dart';
import 'package:flut/flutter/widgets/media_query.dart';
import 'package:flut/flutter/material/theme.dart';
import 'package:flut/flutter/material/color_scheme.dart';
import 'package:flut/flutter/widgets/icon_data.dart';
import 'package:flut/flutter/material/input_decorator.dart';
import 'package:flut/flutter/material/input_border.dart';
import 'package:flut/flutter/rendering/flex.dart';
import 'package:flut/flutter/services/mouse_cursor.dart';

class FlutRuntime {
  final FlutNative flutNative;

  final Map<int, FlutRealtimeObject> objectRegistry = {};
  final Map<int, int> _hashToOid = {};
  final Map<String, Function> _staticRegistry = {};

  int _nextOid = 1;

  FlutRuntime(this.flutNative) {
    _registerStaticHandlers();
  }

  int generateOid() => _nextOid++;

  /// Decode a key from JSON data. Returns ValueKey if key is present.
  Key? decodeKey(Map<String, dynamic> data) {
    final key = data['key'];
    if (key == null) return null;
    return ValueKey(key);
  }

  void _registerStaticHandlers() {
    _staticRegistry['Theme.of'] = FlutTheme.of;
    _staticRegistry['MediaQuery.of'] = FlutMediaQuery.of;
  }

  void triggerAction(String actionId, {Map<String, dynamic>? payload}) {
    if (actionId.isEmpty) return;
    final data = <String, dynamic>{'id': actionId, ...?payload};
    flutNative.invokeNativeNoWaitSync('action', data);
  }

  Map<String, dynamic>? invokeAction(
    String actionId, {
    Map<String, dynamic>? payload,
  }) {
    if (actionId.isEmpty) return null;
    final data = <String, dynamic>{'id': actionId, ...?payload};
    return flutNative.invokeNativeSync('action', data);
  }

  Map<String, dynamic> handleStaticCall(
    String name,
    List<dynamic> args,
    Map<String, dynamic>? kwargs,
  ) {
    final handler = _staticRegistry[name];
    if (handler == null) {
      return {'error': 'Unknown static function', 'name': name};
    }

    final resolvedArgs = args.map(_resolveArg).toList();
    final resolvedKwargs = kwargs?.map((k, v) => MapEntry(k, _resolveArg(v)));

    try {
      Map<Symbol, dynamic>? namedArgs;
      if (resolvedKwargs != null && resolvedKwargs.isNotEmpty) {
        namedArgs = resolvedKwargs.map((k, v) => MapEntry(Symbol(k), v));
      }
      final result = Function.apply(handler, [
        this,
        ...resolvedArgs,
      ], namedArgs);
      return {'value': result};
    } catch (e) {
      return {'error': e.toString()};
    }
  }

  dynamic _resolveArg(dynamic arg) {
    if (arg is Map<String, dynamic> && arg.containsKey('oid')) {
      final oid = arg['oid'] as int;
      final obj = objectRegistry[oid];
      if (obj is FlutBuildContext) {
        return obj.context;
      }
      return obj;
    }
    return arg;
  }

  // ===========================================================================
  // decodeWidget - Decodes Widget types using 'type' field
  // ===========================================================================

  Widget? decodeWidget(dynamic data, BuildContext context) {
    if (data == null) return null;
    if (data is! Map<String, dynamic>) {
      throw FlutInvalidValueException('Widget', data);
    }

    final type = data['_flut_type'] as String?;
    if (type == null) {
      throw FlutRuntimeException('Missing _flut_type field');
    }

    switch (type) {
      case 'StatefulWidget':
        return FlutStatefulWidget(
          key: data['key'] != null ? ValueKey(data['key']) : null,
          flutId: data['_flut_id'],
          className: data['className'],
          native: flutNative,
          runtime: this,
        );
      case 'StatelessWidget':
        return FlutStatelessWidget(
          key: data['key'] != null ? ValueKey(data['key']) : null,
          flutId: data['_flut_id'],
          className: data['className'],
          native: flutNative,
          runtime: this,
        );
      case 'AppBar':
        return FlutAppBar.flutDecode(this, data, context);
      case 'Text':
        return FlutText.flutDecode(this, data, context);
      case 'SelectableText':
        return FlutSelectableText.flutDecode(this, data, context);
      case 'Center':
        return FlutCenter.flutDecode(this, data, context);
      case 'Padding':
        return FlutPadding.flutDecode(this, data, context);
      case 'Align':
        return FlutAlign.flutDecode(this, data, context);
      case 'Opacity':
        return FlutOpacity.flutDecode(this, data, context);
      case 'ClipRRect':
        return FlutClipRRect.flutDecode(this, data, context);
      case 'SizedBox':
        return FlutSizedBox.flutDecode(this, data, context);
      case 'Expanded':
        return FlutExpanded.flutDecode(this, data, context);
      case 'Flexible':
        return FlutFlexible.flutDecode(this, data, context);
      case 'Spacer':
        return FlutSpacer.flutDecode(this, data, context);
      case 'Column':
        return FlutColumn.flutDecode(this, data, context);
      case 'Row':
        return FlutRow.flutDecode(this, data, context);
      case 'Stack':
        return FlutStack.flutDecode(this, data, context);
      case 'Positioned':
        return FlutPositioned.flutDecode(this, data, context);
      case 'Container':
        return FlutContainer.flutDecode(this, data, context);
      case 'Icon':
        return FlutIcon.flutDecode(this, data, context);
      case 'Visibility':
        return FlutVisibility.flutDecode(this, data, context);
      case 'ListView':
        return FlutListView.flutDecode(this, data, context);
      case 'SingleChildScrollView':
        return FlutSingleChildScrollView.flutDecode(this, data, context);
      case 'AnimatedOpacity':
        return FlutAnimatedOpacity.flutDecode(this, data, context);
      case 'MouseRegion':
        return FlutMouseRegion.flutDecode(this, data, context);
      case 'GestureDetector':
        return FlutGestureDetector.flutDecode(this, data, context);
      case 'MaterialApp':
        return FlutMaterialApp.flutDecode(this, data, context);
      case 'Scaffold':
        return FlutScaffold.flutDecode(this, data, context);
      case 'Card':
        return FlutCard.flutDecode(this, data, context);
      case 'Divider':
        return FlutDivider.flutDecode(this, data, context);
      case 'CircularProgressIndicator':
        return FlutCircularProgressIndicator.flutDecode(this, data, context);
      case 'FloatingActionButton':
        return FlutFloatingActionButton.flutDecode(this, data, context);
      case 'ElevatedButton':
        return FlutElevatedButton.flutDecode(this, data, context);
      case 'IconButton':
        return FlutIconButton.flutDecode(this, data, context);
      case 'InkWell':
        return FlutInkWell.flutDecode(this, data, context);
      case 'TextField':
        return FlutTextField.flutDecode(this, data, context);
      case 'CustomPaint':
        return FlutCustomPaint.flutDecode(this, data, context);
      default:
        throw FlutUnknownTypeException(type);
    }
  }

  Widget buildWidgetFromJson(Map<String, dynamic> data, BuildContext context) {
    final widget = decodeWidget(data, context);
    if (widget == null) {
      throw FlutRuntimeException('Failed to decode widget');
    }
    return widget;
  }

  // ===========================================================================
  // decodeObject<T> - Generic decoder using '_flut_type' field
  // ===========================================================================

  T? decodeObject<T>(dynamic data, [BuildContext? context]) {
    if (data == null) return null;

    if (data is! Map<String, dynamic>) {
      throw FlutInvalidValueException(T.toString(), data);
    }

    final type = data['_flut_type'] as String?;
    if (type == null) {
      throw throw FlutRuntimeException('Missing _flut_type field');
    }

    final oid = data['_flut_oid'] as int?;
    if (oid != null) {
      final existing = objectRegistry[oid];
      if (existing != null) {
        return existing as T;
      }
    }

    final result = _decodeByType(type, data, context);
    if (result is! T) {
      throw FlutInvalidValueException(T.toString(), result);
    }

    if (result is FlutRealtimeObject && oid != null) {
      objectRegistry[oid] = result;
    }

    return result;
  }

  dynamic _decodeByType(
    String type,
    Map<String, dynamic> data,
    BuildContext? context,
  ) {
    switch (type) {
      case 'TextEditingController':
        return FlutTextEditingController.flutDecode(this, data);
      case 'ScrollController':
        return FlutScrollController.flutDecode(this, data);
      case 'FocusNode':
        return FlutFocusNode.flutDecode(this, data);
      case 'EdgeInsets':
        return FlutEdgeInsets.flutDecode(this, data);
      case 'Alignment':
        return FlutAlignment.flutDecode(this, data);
      case 'BorderRadius':
        return FlutBorderRadius.flutDecode(this, data);
      case 'Border':
        return FlutBorder.flutDecode(this, data);
      case 'BoxDecoration':
        return FlutBoxDecoration.flutDecode(this, data);
      case 'TextStyle':
        if (context == null)
          throw FlutRuntimeException(
            'Missing BuildContext for TextStyle decoding',
          );
        return FlutTextStyle.flutDecode(this, data, context);
      case 'IconData':
        return FlutIconData.flutDecode(this, data);
      case 'ThemeData':
        return FlutThemeData.flutDecode(this, data);
      case 'InputDecoration':
        return FlutInputDecoration.flutDecode(this, data);
      case 'InputBorder':
        return FlutInputBorder.flutDecode(this, data);
      case 'Duration':
        return FlutDuration.flutDecode(this, data);
      case 'MainAxisAlignment':
        return FlutMainAxisAlignment.flutDecode(data['value'] as String?);
      case 'CrossAxisAlignment':
        return FlutCrossAxisAlignment.flutDecode(data['value'] as String?);
      case 'MouseCursor':
        return FlutSystemMouseCursors.flutDecode(data['value'] as String?);
      default:
        throw FlutUnknownTypeException(type);
    }
  }

  // ===========================================================================
  // decodeColor - Special handling for Color (supports ref)
  // ===========================================================================

  Color? decodeColor(dynamic value, BuildContext context) {
    if (value == null) return null;
    if (value is int) return Color(value);
    if (value is Map && value['ref'] is String) {
      return _resolveThemeColorRef(context, value['ref'] as String);
    }
    return null;
  }

  Color? _resolveThemeColorRef(BuildContext context, String ref) {
    switch (ref) {
      case 'theme.colorScheme.inversePrimary':
        return Theme.of(context).colorScheme.inversePrimary;
      default:
        return null;
    }
  }

  // ===========================================================================
  // encodeValue - Encode Dart values for Python
  // ===========================================================================

  dynamic encodeValue(dynamic value) {
    if (value == null) return null;
    if (value is num || value is String || value is bool) return value;
    if (value is List) return value.map(encodeValue).toList();
    if (value is Map) {
      return value.map((k, v) => MapEntry(k, encodeValue(v)));
    }
    if (value is FlutImmutableObject) return value.flutEncode();
    if (value is FlutRealtimeObject) return value.flutEncode();

    if (value is Size) return FlutSize(value).flutEncode();
    if (value is EdgeInsets) return FlutEdgeInsets(value).flutEncode();
    if (value is ColorScheme) return FlutColorScheme(value).flutEncode();

    if (value is ScrollPosition) {
      final wrapper = wrapObject<FlutScrollPosition>(
        value,
        (oid) =>
            FlutScrollPosition(position: value, runtime: this, flutOid: oid),
      );
      return wrapper.flutEncode();
    }

    throw FlutEncodeException(value.runtimeType);
  }

  // ===========================================================================
  // wrapObject - Wrap Dart objects in FlutRealtimeObject
  // ===========================================================================

  T wrapObject<T extends FlutRealtimeObject>(
    Object dartObj,
    T Function(int oid) factory, {
    int? requestedOid,
  }) {
    final hash = identityHashCode(dartObj);

    final existingOid = _hashToOid[hash];
    if (existingOid != null) {
      final existing = objectRegistry[existingOid];
      if (existing != null) {
        if (requestedOid != null && existingOid != requestedOid) {
          throw FlutOidConflictException(existingOid, requestedOid);
        }
        return existing as T;
      }
    }

    final oid = requestedOid ?? generateOid();

    if (objectRegistry.containsKey(oid)) {
      throw FlutOidInUseException(oid);
    }

    final wrapper = factory(oid);
    objectRegistry[oid] = wrapper;
    _hashToOid[hash] = oid;

    return wrapper;
  }

  void releaseObject(int oid) {
    final wrapper = objectRegistry.remove(oid);
    if (wrapper != null) {
      _hashToOid.removeWhere((_, v) => v == oid);
    }
  }

  /// Release objects piggybacked in a widget_build response.
  ///
  /// Python collects garbage-collected object IDs and includes them in
  /// the response JSON as '_flut_release_oids'. This avoids sync calls
  /// during builds that could cause reentrancy.
  void releaseOidsFromResponse(Map<String, dynamic> response) {
    final oids = response['_flut_release_oids'] as List<dynamic>?;
    if (oids == null || oids.isEmpty) return;

    for (final oid in oids) {
      if (oid is int) {
        releaseObject(oid);
      }
    }
  }
}
