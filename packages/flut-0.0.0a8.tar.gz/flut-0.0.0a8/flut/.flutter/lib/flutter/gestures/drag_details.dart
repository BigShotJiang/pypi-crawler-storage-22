import 'package:flutter/gestures.dart';
import 'package:flut/flut/object.dart';
import 'package:flut/dart/ui.dart';

/// Wrapper around DragStartDetails for Python.
class FlutDragStartDetails extends FlutImmutableObject {
  final DragStartDetails details;

  const FlutDragStartDetails(this.details);

  @override
  Map<String, dynamic> flutEncode() {
    return {
      '_flut_type': 'DragStartDetails',
      'globalPosition': FlutOffset(details.globalPosition).flutEncode(),
      'localPosition': FlutOffset(details.localPosition).flutEncode(),
    };
  }
}

/// Wrapper around DragUpdateDetails for Python.
class FlutDragUpdateDetails extends FlutImmutableObject {
  final DragUpdateDetails details;

  const FlutDragUpdateDetails(this.details);

  @override
  Map<String, dynamic> flutEncode() {
    return {
      '_flut_type': 'DragUpdateDetails',
      'globalPosition': FlutOffset(details.globalPosition).flutEncode(),
      'localPosition': FlutOffset(details.localPosition).flutEncode(),
      'delta': FlutOffset(details.delta).flutEncode(),
    };
  }
}

/// Wrapper around DragEndDetails for Python.
class FlutDragEndDetails extends FlutImmutableObject {
  final DragEndDetails details;

  const FlutDragEndDetails(this.details);

  @override
  Map<String, dynamic> flutEncode() {
    return {
      '_flut_type': 'DragEndDetails',
      'velocity': FlutOffset(details.velocity.pixelsPerSecond).flutEncode(),
    };
  }
}
