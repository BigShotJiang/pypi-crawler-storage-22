import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';

class FlutMaterialApp {
  FlutMaterialApp._();

  static MaterialApp? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> data,
    BuildContext context,
  ) {
    return MaterialApp(
      key: runtime.decodeKey(data),
      title: data['title'] as String?,
      theme: runtime.decodeObject<ThemeData>(data['theme']),
      home: runtime.decodeWidget(data['home'], context),
    );
  }
}
