import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';

class FlutAppBar {
  FlutAppBar._();

  static AppBar? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> data,
    BuildContext context,
  ) {
    final backgroundColor = runtime.decodeColor(
      data['backgroundColor'],
      context,
    );
    final title = runtime.decodeWidget(data['title'], context);
    final scrolledUnderElevation = (data['scrolledUnderElevation'] as num?)
        ?.toDouble();

    return AppBar(
      key: runtime.decodeKey(data),
      backgroundColor: backgroundColor,
      title: title,
      scrolledUnderElevation: scrolledUnderElevation,
    );
  }
}
