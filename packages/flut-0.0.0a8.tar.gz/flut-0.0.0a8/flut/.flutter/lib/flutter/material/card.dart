import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';

class FlutCard {
  FlutCard._();

  static Card? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> data,
    BuildContext context,
  ) {
    return Card(
      key: runtime.decodeKey(data),
      color: data['color'] != null ? Color(data['color'] as int) : null,
      elevation: (data['elevation'] as num?)?.toDouble(),
      margin: runtime.decodeObject<EdgeInsets>(data['margin']),
      child: runtime.decodeWidget(data['child'], context),
    );
  }
}
