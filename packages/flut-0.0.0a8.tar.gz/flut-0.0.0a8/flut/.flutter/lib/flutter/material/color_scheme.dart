import 'package:flutter/material.dart';
import 'package:flut/flut/object.dart';

class FlutColorScheme extends FlutImmutableObject {
  final ColorScheme colorScheme;

  const FlutColorScheme(this.colorScheme);

  @override
  Map<String, dynamic> flutEncode() {
    return {
      'inversePrimary': colorScheme.inversePrimary.value,
      'primary': colorScheme.primary.value,
      'onPrimary': colorScheme.onPrimary.value,
      'secondary': colorScheme.secondary.value,
      'onSecondary': colorScheme.onSecondary.value,
      'surface': colorScheme.surface.value,
      'onSurface': colorScheme.onSurface.value,
      'error': colorScheme.error.value,
      'onError': colorScheme.onError.value,
    };
  }
}
