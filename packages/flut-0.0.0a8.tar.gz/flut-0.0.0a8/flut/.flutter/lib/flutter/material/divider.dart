import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';

class FlutDivider {
  FlutDivider._();

  static Divider? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> data,
    BuildContext context,
  ) {
    return Divider(
      key: runtime.decodeKey(data),
      height: (data['height'] as num?)?.toDouble(),
      thickness: (data['thickness'] as num?)?.toDouble(),
      color: data['color'] != null ? Color(data['color']) : null,
    );
  }
}
