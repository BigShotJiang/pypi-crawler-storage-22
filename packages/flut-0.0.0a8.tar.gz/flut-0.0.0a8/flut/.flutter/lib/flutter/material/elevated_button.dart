import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';
import 'package:flut/flut/error.dart';

class FlutElevatedButton {
  FlutElevatedButton._();

  static Widget? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> data,
    BuildContext context,
  ) {
    final child = runtime.decodeWidget(data['child'], context);
    if (child == null) {
      throw FlutMissingRequiredParameterException('ElevatedButton', 'child');
    }
    return ElevatedButton(
      key: runtime.decodeKey(data),
      onPressed: data['onPressedId'] == null
          ? null
          : () => runtime.triggerAction(data['onPressedId']),
      child: child,
    );
  }
}
