import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';
import 'package:flut/flut/error.dart';

class FlutFloatingActionButton {
  FlutFloatingActionButton._();

  static Widget? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> data,
    BuildContext context,
  ) {
    final onPressedId = data['onPressedId'] as String?;
    if (onPressedId == null) {
      throw FlutMissingRequiredParameterException(
        'FloatingActionButton',
        'onPressedId',
      );
    }
    return FloatingActionButton(
      key: runtime.decodeKey(data),
      onPressed: () => runtime.triggerAction(onPressedId),
      child: runtime.decodeWidget(data['child'], context),
    );
  }
}
