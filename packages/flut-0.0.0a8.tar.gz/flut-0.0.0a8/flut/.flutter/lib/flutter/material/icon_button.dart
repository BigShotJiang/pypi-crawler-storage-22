import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';
import 'package:flut/flut/error.dart';

class FlutIconButton {
  FlutIconButton._();

  static Widget? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> data,
    BuildContext context,
  ) {
    final icon = data['icon'];
    if (icon == null || icon is! Map<String, dynamic>) {
      throw FlutMissingRequiredParameterException('IconButton', 'icon');
    }
    final iconWidget = runtime.decodeWidget(icon, context);
    if (iconWidget == null) {
      throw FlutRuntimeException('IconButton: failed to decode icon widget');
    }

    final color = data['color'] != null ? Color(data['color']) : null;

    return IconButton(
      key: runtime.decodeKey(data),
      icon: iconWidget,
      onPressed: data['onPressedId'] == null
          ? null
          : () => runtime.triggerAction(data['onPressedId']),
      color: color,
      iconSize: (data['iconSize'] as num?)?.toDouble(),
      tooltip: data['tooltip'],
    );
  }
}
