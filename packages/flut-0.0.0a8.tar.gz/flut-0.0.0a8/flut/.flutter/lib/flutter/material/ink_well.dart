import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';

class FlutInkWell {
  FlutInkWell._();

  static Widget? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> data,
    BuildContext context,
  ) {
    return InkWell(
      key: runtime.decodeKey(data),
      onTap: data['onTapId'] != null
          ? () => runtime.triggerAction(data['onTapId'])
          : null,
      child: runtime.decodeWidget(data['child'], context),
    );
  }
}
