import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';

class FlutInputBorder {
  FlutInputBorder._();

  static InputBorder? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> data,
  ) {
    final value = data['value'] as String?;
    if (value == 'none') return InputBorder.none;
    throw ArgumentError('Unknown InputBorder value: $value');
  }
}
