import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';

class FlutInputDecoration {
  FlutInputDecoration._();

  static InputDecoration? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> data,
  ) {
    return InputDecoration(
      hintText: data['hintText'] as String?,
      border: runtime.decodeObject<InputBorder>(data['border']),
      filled: data['filled'] as bool?,
      fillColor: data['fillColor'] != null
          ? Color(data['fillColor'] as int)
          : null,
      contentPadding: runtime.decodeObject<EdgeInsets>(data['contentPadding']),
    );
  }
}
