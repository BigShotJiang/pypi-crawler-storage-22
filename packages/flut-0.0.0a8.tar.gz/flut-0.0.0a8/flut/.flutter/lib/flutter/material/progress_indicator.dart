import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';

class FlutCircularProgressIndicator {
  FlutCircularProgressIndicator._();

  static CircularProgressIndicator? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> data,
    BuildContext context,
  ) {
    return CircularProgressIndicator(
      key: runtime.decodeKey(data),
      strokeWidth: (data['strokeWidth'] as num?)?.toDouble() ?? 4.0,
      color: data['color'] != null ? Color(data['color']) : null,
    );
  }
}
