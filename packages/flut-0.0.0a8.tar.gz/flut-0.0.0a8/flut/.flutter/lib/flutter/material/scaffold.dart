import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';

class FlutScaffold {
  FlutScaffold._();

  static Scaffold? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> data,
    BuildContext context,
  ) {
    final appBar = runtime.decodeWidget(data['appBar'], context);
    return Scaffold(
      key: runtime.decodeKey(data),
      appBar: appBar is PreferredSizeWidget ? appBar : null,
      body: runtime.decodeWidget(data['body'], context),
      floatingActionButton: runtime.decodeWidget(
        data['floatingActionButton'],
        context,
      ),
    );
  }
}
