import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';
import 'package:flut/flut/error.dart';

class FlutSelectableText {
  FlutSelectableText._();

  static SelectableText? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> data,
    BuildContext context,
  ) {
    final textData = data['data'] as String?;
    if (textData == null) {
      throw FlutMissingRequiredParameterException('SelectableText', 'data');
    }
    final maxLines = data['maxLines'] as int?;
    final style = runtime.decodeObject<TextStyle>(data['style'], context);

    return SelectableText(
      textData,
      key: runtime.decodeKey(data),
      style: style,
      maxLines: maxLines,
    );
  }
}
