import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';

class FlutTextField {
  FlutTextField._();

  static Widget? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> data,
    BuildContext context,
  ) {
    final controller = runtime.decodeObject<TextEditingController>(
      data['controller'],
    );
    final focusNode = runtime.decodeObject<FocusNode>(data['focusNode']);

    return TextField(
      key: runtime.decodeKey(data),
      controller: controller,
      focusNode: focusNode,
      readOnly: data['readOnly'] as bool? ?? false,
      maxLines: data['maxLines'] as int?,
      minLines: data['minLines'] as int?,
      decoration: runtime.decodeObject<InputDecoration>(data['decoration']),
      style: runtime.decodeObject<TextStyle>(data['style'], context),
      onChanged: data['onChangedId'] != null
          ? (value) => runtime.triggerAction(
              data['onChangedId'] as String,
              payload: {'value': value},
            )
          : null,
      onSubmitted: data['onSubmittedId'] != null
          ? (value) => runtime.triggerAction(
              data['onSubmittedId'] as String,
              payload: {'value': value},
            )
          : null,
    );
  }
}
