import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';

class FlutTheme {
  FlutTheme._();

  static Map<String, dynamic> of(FlutRuntime runtime, BuildContext context) {
    final theme = Theme.of(context);
    return {
      'useMaterial3': theme.useMaterial3,
      'colorScheme': runtime.encodeValue(theme.colorScheme),
    };
  }
}
