import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';

class FlutThemeData {
  FlutThemeData._();

  static ThemeData? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> data,
  ) {
    final useMaterial3 = (data['useMaterial3'] as bool?) ?? true;
    final colorSchemeData = data['colorScheme'] as Map<String, dynamic>?;
    final seedColor = colorSchemeData?['seedColor'] as int?;

    if (seedColor != null) {
      return ThemeData(
        colorSchemeSeed: Color(seedColor),
        useMaterial3: useMaterial3,
      );
    }

    return ThemeData(useMaterial3: useMaterial3);
  }
}
