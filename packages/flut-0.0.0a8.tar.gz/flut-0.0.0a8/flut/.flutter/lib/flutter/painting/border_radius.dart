import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';

class FlutBorderRadius {
  FlutBorderRadius._();

  static BorderRadius? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> data,
  ) {
    final circular = data['circular'] as num?;
    if (circular != null) {
      return BorderRadius.circular(circular.toDouble());
    }
    return BorderRadius.only(
      topLeft: Radius.circular((data['topLeft'] as num?)?.toDouble() ?? 0),
      topRight: Radius.circular((data['topRight'] as num?)?.toDouble() ?? 0),
      bottomLeft: Radius.circular(
        (data['bottomLeft'] as num?)?.toDouble() ?? 0,
      ),
      bottomRight: Radius.circular(
        (data['bottomRight'] as num?)?.toDouble() ?? 0,
      ),
    );
  }
}
