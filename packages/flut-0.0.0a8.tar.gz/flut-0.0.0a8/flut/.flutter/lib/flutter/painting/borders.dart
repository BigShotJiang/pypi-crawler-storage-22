import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';

class FlutBorder {
  FlutBorder._();

  static Border? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> data,
  ) {
    return Border(
      left: _decodeSide(data['left'] as Map<String, dynamic>?),
      top: _decodeSide(data['top'] as Map<String, dynamic>?),
      right: _decodeSide(data['right'] as Map<String, dynamic>?),
      bottom: _decodeSide(data['bottom'] as Map<String, dynamic>?),
    );
  }

  static BorderSide _decodeSide(Map<String, dynamic>? sideData) {
    if (sideData == null) return BorderSide.none;
    return BorderSide(
      color: sideData['color'] != null
          ? Color(sideData['color'] as int)
          : Colors.black,
      width: (sideData['width'] as num?)?.toDouble() ?? 1.0,
    );
  }
}
