import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';

class FlutBoxDecoration {
  FlutBoxDecoration._();

  static BoxDecoration? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> data,
  ) {
    return BoxDecoration(
      color: data['color'] != null ? Color(data['color'] as int) : null,
      border: runtime.decodeObject<Border>(data['border']),
      borderRadius: runtime.decodeObject<BorderRadius>(data['borderRadius']),
    );
  }
}
