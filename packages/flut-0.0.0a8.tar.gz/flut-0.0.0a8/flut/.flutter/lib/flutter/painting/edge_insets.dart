import 'package:flutter/material.dart';
import 'package:flut/flut/object.dart';
import 'package:flut/flut/runtime.dart';

class FlutEdgeInsets extends FlutImmutableObject {
  final EdgeInsets edgeInsets;

  const FlutEdgeInsets(this.edgeInsets);

  @override
  Map<String, dynamic> flutEncode() {
    return {
      '_flut_type': 'EdgeInsets',
      'left': edgeInsets.left,
      'top': edgeInsets.top,
      'right': edgeInsets.right,
      'bottom': edgeInsets.bottom,
    };
  }

  static EdgeInsets? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> data,
  ) {
    return EdgeInsets.only(
      left: (data['left'] as num?)?.toDouble() ?? 0,
      top: (data['top'] as num?)?.toDouble() ?? 0,
      right: (data['right'] as num?)?.toDouble() ?? 0,
      bottom: (data['bottom'] as num?)?.toDouble() ?? 0,
    );
  }
}
