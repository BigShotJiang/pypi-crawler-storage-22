import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';

class FlutTextSpan {
  FlutTextSpan._();

  static TextSpan? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic>? data,
    BuildContext context,
  ) {
    if (data == null) {
      return const TextSpan();
    }

    final text = data['text'] as String?;
    final style = runtime.decodeObject<TextStyle>(data['style'], context);

    List<InlineSpan>? children;
    if (data['children'] != null) {
      children = (data['children'] as List)
          .map((c) => flutDecode(runtime, c as Map<String, dynamic>?, context))
          .whereType<TextSpan>()
          .toList();
    }

    return TextSpan(text: text, style: style, children: children);
  }
}
