import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';
import 'package:flut/flut/error.dart';

class FlutTextStyle {
  FlutTextStyle._();

  static TextStyle? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> data,
    BuildContext context,
  ) {
    if (data['ref'] is String) {
      final ref = data['ref'] as String;
      if (ref.startsWith('theme.textTheme.')) {
        final name = ref.substring('theme.textTheme.'.length);
        final textTheme = Theme.of(context).textTheme;
        final style = switch (name) {
          'headlineMedium' => textTheme.headlineMedium,
          'headlineSmall' => textTheme.headlineSmall,
          'titleLarge' => textTheme.titleLarge,
          'bodyLarge' => textTheme.bodyLarge,
          'bodyMedium' => textTheme.bodyMedium,
          _ => null,
        };
        if (style == null) {
          throw FlutInvalidValueException('TextStyle', ref);
        }
        return style;
      }
      throw FlutInvalidValueException('TextStyle', ref);
    }

    return TextStyle(
      fontSize: (data['fontSize'] as num?)?.toDouble(),
      fontWeight: _decodeFontWeight(data['fontWeight'] as String?),
      color: data['color'] != null ? Color(data['color'] as int) : null,
      fontFamily: data['fontFamily'] as String?,
      height: (data['height'] as num?)?.toDouble(),
    );
  }

  static FontWeight? _decodeFontWeight(String? data) {
    if (data == null) return null;
    return switch (data) {
      'bold' => FontWeight.bold,
      'normal' => FontWeight.normal,
      'w100' => FontWeight.w100,
      'w200' => FontWeight.w200,
      'w300' => FontWeight.w300,
      'w400' => FontWeight.w400,
      'w500' => FontWeight.w500,
      'w600' => FontWeight.w600,
      'w700' => FontWeight.w700,
      'w800' => FontWeight.w800,
      'w900' => FontWeight.w900,
      _ => null,
    };
  }
}
