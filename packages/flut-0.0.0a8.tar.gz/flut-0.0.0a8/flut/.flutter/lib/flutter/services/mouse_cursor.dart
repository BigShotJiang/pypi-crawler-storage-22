import 'package:flutter/material.dart';

class FlutSystemMouseCursors {
  FlutSystemMouseCursors._();

  static MouseCursor flutDecode(String? value) {
    switch (value) {
      case 'basic':
        return SystemMouseCursors.basic;
      case 'click':
        return SystemMouseCursors.click;
      case 'text':
        return SystemMouseCursors.text;
      case 'resizeLeftRight':
        return SystemMouseCursors.resizeLeftRight;
      case 'resizeUpDown':
        return SystemMouseCursors.resizeUpDown;
      case 'resizeColumn':
        return SystemMouseCursors.resizeColumn;
      case 'resizeRow':
        return SystemMouseCursors.resizeRow;
      case 'grab':
        return SystemMouseCursors.grab;
      case 'grabbing':
        return SystemMouseCursors.grabbing;
      case 'move':
        return SystemMouseCursors.move;
      case 'forbidden':
        return SystemMouseCursors.forbidden;
      case 'wait':
        return SystemMouseCursors.wait;
      default:
        return MouseCursor.defer;
    }
  }
}
