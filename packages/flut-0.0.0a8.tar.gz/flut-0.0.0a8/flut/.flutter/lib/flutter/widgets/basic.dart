import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';
import 'package:flut/flut/error.dart';

class FlutCenter {
  FlutCenter._();

  static Center? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> data,
    BuildContext context,
  ) {
    return Center(
      key: runtime.decodeKey(data),
      child: runtime.decodeWidget(data['child'], context),
    );
  }
}

class FlutPadding {
  FlutPadding._();

  static Padding? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> data,
    BuildContext context,
  ) {
    final padding = runtime.decodeObject<EdgeInsets>(data['padding']);
    if (padding == null) {
      throw FlutMissingRequiredParameterException('Padding', 'padding');
    }
    return Padding(
      key: runtime.decodeKey(data),
      padding: padding,
      child: runtime.decodeWidget(data['child'], context),
    );
  }
}

class FlutAlign {
  FlutAlign._();

  static Align? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> data,
    BuildContext context,
  ) {
    final alignment = runtime.decodeObject<Alignment>(data['alignment']);
    if (alignment == null) {
      throw FlutMissingRequiredParameterException('Align', 'alignment');
    }
    return Align(
      key: runtime.decodeKey(data),
      alignment: alignment,
      child: runtime.decodeWidget(data['child'], context),
    );
  }
}

class FlutOpacity {
  FlutOpacity._();

  static Opacity? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> data,
    BuildContext context,
  ) {
    final opacity = data['opacity'];
    if (opacity == null) {
      throw FlutMissingRequiredParameterException('Opacity', 'opacity');
    }
    return Opacity(
      key: runtime.decodeKey(data),
      opacity: (opacity as num).toDouble(),
      child: runtime.decodeWidget(data['child'], context),
    );
  }
}

class FlutClipRRect {
  FlutClipRRect._();

  static ClipRRect? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> data,
    BuildContext context,
  ) {
    return ClipRRect(
      key: runtime.decodeKey(data),
      borderRadius:
          runtime.decodeObject<BorderRadius>(data['borderRadius']) ??
          BorderRadius.zero,
      child: runtime.decodeWidget(data['child'], context),
    );
  }
}

class FlutSizedBox {
  FlutSizedBox._();

  static SizedBox? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> data,
    BuildContext context,
  ) {
    return SizedBox(
      key: runtime.decodeKey(data),
      width: (data['width'] as num?)?.toDouble(),
      height: (data['height'] as num?)?.toDouble(),
      child: runtime.decodeWidget(data['child'], context),
    );
  }
}

class FlutExpanded {
  FlutExpanded._();

  static Expanded? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> data,
    BuildContext context,
  ) {
    final child = runtime.decodeWidget(data['child'], context);
    if (child == null) {
      throw FlutMissingRequiredParameterException('Expanded', 'child');
    }
    return Expanded(
      key: runtime.decodeKey(data),
      flex: (data['flex'] as num?)?.toInt() ?? 1,
      child: child,
    );
  }
}

class FlutFlexible {
  FlutFlexible._();

  static Flexible? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> data,
    BuildContext context,
  ) {
    final child = runtime.decodeWidget(data['child'], context);
    if (child == null) {
      throw FlutMissingRequiredParameterException('Flexible', 'child');
    }
    return Flexible(
      key: runtime.decodeKey(data),
      flex: (data['flex'] as num?)?.toInt() ?? 1,
      fit: data['fit'] == 'tight' ? FlexFit.tight : FlexFit.loose,
      child: child,
    );
  }
}

class FlutSpacer {
  FlutSpacer._();

  static Spacer? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> data,
    BuildContext context,
  ) {
    return Spacer(
      key: runtime.decodeKey(data),
      flex: (data['flex'] as num?)?.toInt() ?? 1,
    );
  }
}

class FlutColumn {
  FlutColumn._();

  static Column? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> data,
    BuildContext context,
  ) {
    final children =
        (data['children'] as List?)
            ?.map((c) => runtime.decodeWidget(c, context))
            .whereType<Widget>()
            .toList() ??
        [];

    return Column(
      key: runtime.decodeKey(data),
      mainAxisAlignment: runtime.decodeObject<MainAxisAlignment>(data['mainAxisAlignment']) ?? MainAxisAlignment.start,
      crossAxisAlignment: runtime.decodeObject<CrossAxisAlignment>(data['crossAxisAlignment']) ?? CrossAxisAlignment.center,
      children: children,
    );
  }
}

class FlutRow {
  FlutRow._();

  static Row? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> data,
    BuildContext context,
  ) {
    final children =
        (data['children'] as List?)
            ?.map((c) => runtime.decodeWidget(c, context))
            .whereType<Widget>()
            .toList() ??
        [];

    return Row(
      key: runtime.decodeKey(data),
      mainAxisAlignment: runtime.decodeObject<MainAxisAlignment>(data['mainAxisAlignment']) ?? MainAxisAlignment.start,
      crossAxisAlignment: runtime.decodeObject<CrossAxisAlignment>(data['crossAxisAlignment']) ?? CrossAxisAlignment.center,
      children: children,
    );
  }
}

class FlutStack {
  FlutStack._();

  static Stack? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> data,
    BuildContext context,
  ) {
    final children =
        (data['children'] as List?)
            ?.map((c) => runtime.decodeWidget(c, context))
            .whereType<Widget>()
            .toList() ??
        [];

    return Stack(
      key: runtime.decodeKey(data),
      children: children,
    );
  }
}

class FlutPositioned {
  FlutPositioned._();

  static Positioned? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> data,
    BuildContext context,
  ) {
    final child = runtime.decodeWidget(data['child'], context);
    if (child == null) {
      throw FlutMissingRequiredParameterException('Positioned', 'child');
    }
    return Positioned(
      key: runtime.decodeKey(data),
      left: (data['left'] as num?)?.toDouble(),
      top: (data['top'] as num?)?.toDouble(),
      right: (data['right'] as num?)?.toDouble(),
      bottom: (data['bottom'] as num?)?.toDouble(),
      width: (data['width'] as num?)?.toDouble(),
      height: (data['height'] as num?)?.toDouble(),
      child: child,
    );
  }
}

class FlutMouseRegion {
  FlutMouseRegion._();

  static Widget? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> data,
    BuildContext context,
  ) {
    final cursor = runtime.decodeObject<MouseCursor>(data['cursor']) ?? MouseCursor.defer;

    return MouseRegion(
      key: runtime.decodeKey(data),
      cursor: cursor,
      onEnter: data['onEnterId'] != null
          ? (_) => runtime.triggerAction(data['onEnterId'])
          : null,
      onExit: data['onExitId'] != null
          ? (_) => runtime.triggerAction(data['onExitId'])
          : null,
      child: runtime.decodeWidget(data['child'], context),
    );
  }
}

class FlutCustomPaint {
  FlutCustomPaint._();

  static CustomPaint? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> data,
    BuildContext context,
  ) {
    final sizeData = data['size'] as List?;
    final size = sizeData != null
        ? Size((sizeData[0] as num).toDouble(), (sizeData[1] as num).toDouble())
        : null;
    return CustomPaint(
      key: runtime.decodeKey(data),
      size: size ?? Size.zero,
      painter: _FlutJSONPainter(data['painter']),
      child: runtime.decodeWidget(data['child'], context),
    );
  }
}

class _FlutJSONPainter extends CustomPainter {
  final Map<String, dynamic>? data;
  _FlutJSONPainter(this.data);

  @override
  void paint(Canvas canvas, Size size) {
    if (data == null || data!['commands'] == null) return;

    final commands = data!['commands'] as List;
    for (final cmd in commands) {
      final type = cmd['cmd'];
      final paint = _parsePaint(cmd['paint']);

      if (type == 'drawLine') {
        final p1 = _parseOffset(cmd['p1']);
        final p2 = _parseOffset(cmd['p2']);
        canvas.drawLine(p1, p2, paint);
      } else if (type == 'drawCircle') {
        final c = _parseOffset(cmd['c']);
        final radius = (cmd['radius'] as num).toDouble();
        canvas.drawCircle(c, radius, paint);
      } else if (type == 'drawRect') {
        final r = cmd['rect'] as List;
        final rect = Rect.fromLTWH(
          (r[0] as num).toDouble(),
          (r[1] as num).toDouble(),
          (r[2] as num).toDouble(),
          (r[3] as num).toDouble(),
        );
        canvas.drawRect(rect, paint);
      }
    }
  }

  Offset _parseOffset(dynamic list) {
    final l = list as List;
    return Offset((l[0] as num).toDouble(), (l[1] as num).toDouble());
  }

  Paint _parsePaint(dynamic map) {
    final paint = Paint();
    if (map['color'] != null) paint.color = Color(map['color']);
    if (map['strokeWidth'] != null) {
      paint.strokeWidth = (map['strokeWidth'] as num).toDouble();
    }
    if (map['style'] == 'stroke') {
      paint.style = PaintingStyle.stroke;
    } else {
      paint.style = PaintingStyle.fill;
    }
    return paint;
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}
