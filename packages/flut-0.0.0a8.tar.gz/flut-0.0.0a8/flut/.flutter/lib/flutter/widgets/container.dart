import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';

class FlutContainer {
  FlutContainer._();

  static Container? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> data,
    BuildContext context,
  ) {
    final decoration = runtime.decodeObject<BoxDecoration>(data['decoration']);

    return Container(
      key: runtime.decodeKey(data),
      padding: runtime.decodeObject<EdgeInsets>(data['padding']),
      margin: runtime.decodeObject<EdgeInsets>(data['margin']),
      width: (data['width'] as num?)?.toDouble(),
      height: (data['height'] as num?)?.toDouble(),
      color: decoration == null && data['color'] != null
          ? Color(data['color'] as int)
          : null,
      decoration: decoration,
      alignment: runtime.decodeObject<Alignment>(data['alignment']),
      child: runtime.decodeWidget(data['child'], context),
    );
  }
}
