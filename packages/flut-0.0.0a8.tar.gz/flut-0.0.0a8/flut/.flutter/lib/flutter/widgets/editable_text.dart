import 'package:flutter/material.dart';
import 'package:flut/flut/object.dart';
import 'package:flut/flut/runtime.dart';
import 'package:flut/flut/error.dart';
import 'package:flut/flutter/painting/text_span.dart';

class FlutTextEditingController extends TextEditingController
    with FlutRealtimeObject {
  final String? _buildTextSpanId;

  FlutTextEditingController._({
    required FlutRuntime runtime,
    required int flutOid,
    String? text,
    String? buildTextSpanId,
  }) : _buildTextSpanId = buildTextSpanId,
       super(text: text) {
    initFlutRealtimeObject(runtime: runtime, flutOid: flutOid);
  }

  static FlutTextEditingController flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> json,
  ) {
    final oid = json['_flut_oid'] as int;
    return FlutTextEditingController._(
      runtime: runtime,
      flutOid: oid,
      text: json['text'] as String?,
      buildTextSpanId: json['buildTextSpanId'] as String?,
    );
  }

  @override
  TextSpan buildTextSpan({
    required BuildContext context,
    TextStyle? style,
    required bool withComposing,
  }) {
    final buildTextSpanId = _buildTextSpanId;
    if (buildTextSpanId != null) {
      final result = flutRuntime.invokeAction(buildTextSpanId);
      final innerResult = result?['result'];
      if (innerResult != null && innerResult['textSpan'] != null) {
        final decoded = FlutTextSpan.flutDecode(
          flutRuntime,
          innerResult['textSpan'] as Map<String, dynamic>,
          context,
        );
        if (decoded != null) {
          return TextSpan(style: style, children: [decoded]);
        }
      }
    }
    return super.buildTextSpan(
      context: context,
      style: style,
      withComposing: withComposing,
    );
  }

  @override
  Map<String, dynamic> flutEncode() {
    return {'_flut_oid': flutOid, '_flut_type': 'TextEditingController'};
  }

  @override
  dynamic getRawProperty(String property) {
    switch (property) {
      case 'text':
        return text;
    }
    throw FlutUnknownPropertyException('TextEditingController', property);
  }

  @override
  bool setProperty(String property, dynamic value) {
    switch (property) {
      case 'text':
        text = (value as String?) ?? '';
        return true;
    }
    throw FlutUnknownPropertyException('TextEditingController', property);
  }

  @override
  dynamic callMethod(String method, Map<String, dynamic> args) {
    throw FlutUnknownMethodException(method);
  }
}
