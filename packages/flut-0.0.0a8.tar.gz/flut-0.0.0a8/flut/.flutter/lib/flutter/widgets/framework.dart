import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';
import 'package:flut/flut/object.dart';

/// Flut's BuildContext wrapper - a FlutRealtimeObject that wraps a real Flutter BuildContext.
///
/// Unlike controllers (which live across rebuilds), BuildContext is short-lived:
/// - Created at start of Python build request
/// - Valid only during the build call
/// - Released immediately after build returns
///
/// Python accesses Theme.of(context), MediaQuery.of(context) via FFI "of" calls.
/// This wrapper just holds the reference so Dart can look it up by oid.
class FlutBuildContext extends Object with FlutRealtimeObject {
  final BuildContext context;

  FlutBuildContext({
    required this.context,
    required FlutRuntime runtime,
    required int flutOid,
  }) {
    initFlutRealtimeObject(runtime: runtime, flutOid: flutOid);
  }

  @override
  Map<String, dynamic> flutEncode() {
    // BuildContext is passed by oid reference, not serialized
    return {'oid': flutOid};
  }

  @override
  dynamic getRawProperty(String property) {
    // No property access - use Theme.of, MediaQuery.of instead
    return null;
  }

  @override
  bool setProperty(String property, dynamic value) {
    // BuildContext is read-only
    return false;
  }

  @override
  dynamic callMethod(String method, Map<String, dynamic> args) {
    // No methods - use static .of() calls instead
    return null;
  }
}
