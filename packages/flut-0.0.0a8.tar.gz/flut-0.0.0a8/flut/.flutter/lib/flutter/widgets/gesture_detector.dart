import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';
import 'package:flut/flutter/gestures/drag_details.dart';

class FlutGestureDetector {
  FlutGestureDetector._();

  static Widget? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> data,
    BuildContext context,
  ) {
    return GestureDetector(
      key: runtime.decodeKey(data),
      onTap: data['onTapId'] != null
          ? () => runtime.triggerAction(data['onTapId'])
          : null,
      onPanStart: data['onPanStartId'] != null
          ? (details) => runtime.triggerAction(
              data['onPanStartId'],
              payload: FlutDragStartDetails(details).flutEncode(),
            )
          : null,
      onPanUpdate: data['onPanUpdateId'] != null
          ? (details) => runtime.triggerAction(
              data['onPanUpdateId'],
              payload: FlutDragUpdateDetails(details).flutEncode(),
            )
          : null,
      onPanEnd: data['onPanEndId'] != null
          ? (details) => runtime.triggerAction(
              data['onPanEndId'],
              payload: FlutDragEndDetails(details).flutEncode(),
            )
          : null,
      child: runtime.decodeWidget(data['child'], context),
    );
  }
}
