import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';

class FlutIcon {
  FlutIcon._();

  static Icon? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> data,
    BuildContext context,
  ) {
    final iconColor = data['color'] != null
        ? Color(data['color'] as int)
        : null;
    final iconSize = (data['size'] as num?)?.toDouble();
    final iconData = runtime.decodeObject<IconData>(data['icon']);

    return Icon(
      iconData,
      key: runtime.decodeKey(data),
      color: iconColor,
      size: iconSize,
    );
  }
}
