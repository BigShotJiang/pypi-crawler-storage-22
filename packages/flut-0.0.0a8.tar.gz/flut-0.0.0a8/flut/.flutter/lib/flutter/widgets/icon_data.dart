import 'package:flutter/material.dart';
import 'package:flut/flut/object.dart';
import 'package:flut/flut/runtime.dart';
import 'package:flut/flut/error.dart';

class FlutIconData extends FlutImmutableObject {
  final IconData iconData;

  const FlutIconData(this.iconData);

  @override
  Map<String, dynamic> flutEncode() {
    return {
      '_flut_type': 'IconData',
      'codePoint': iconData.codePoint,
      'fontFamily': iconData.fontFamily,
      'fontPackage': iconData.fontPackage,
      'matchTextDirection': iconData.matchTextDirection,
    };
  }

  static IconData? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> data,
  ) {
    final codePoint = data['codePoint'] as int?;
    if (codePoint == null) {
      throw FlutMissingRequiredParameterException('IconData', 'codePoint');
    }
    return IconData(
      codePoint,
      fontFamily: data['fontFamily'] as String?,
      fontPackage: data['fontPackage'] as String?,
      matchTextDirection: data['matchTextDirection'] as bool? ?? false,
    );
  }
}
