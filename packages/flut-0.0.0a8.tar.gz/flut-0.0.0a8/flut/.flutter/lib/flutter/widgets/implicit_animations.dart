import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';
import 'package:flut/flut/error.dart';

class FlutAnimatedOpacity {
  FlutAnimatedOpacity._();

  static AnimatedOpacity? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> data,
    BuildContext context,
  ) {
    final opacity = data['opacity'];
    if (opacity == null) {
      throw FlutMissingRequiredParameterException('AnimatedOpacity', 'opacity');
    }
    final duration = data['duration'];
    if (duration == null) {
      throw FlutMissingRequiredParameterException(
        'AnimatedOpacity',
        'duration',
      );
    }
    return AnimatedOpacity(
      key: runtime.decodeKey(data),
      opacity: (opacity as num).toDouble(),
      duration: Duration(milliseconds: (duration as num).toInt()),
      child: runtime.decodeWidget(data['child'], context),
    );
  }
}
