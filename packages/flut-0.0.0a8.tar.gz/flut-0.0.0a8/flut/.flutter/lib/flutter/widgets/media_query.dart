import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';

class FlutMediaQuery {
  FlutMediaQuery._();

  static Map<String, dynamic> of(FlutRuntime runtime, BuildContext context) {
    final mq = MediaQuery.of(context);
    return {
      'size': runtime.encodeValue(mq.size),
      'padding': runtime.encodeValue(mq.padding),
      'viewInsets': runtime.encodeValue(mq.viewInsets),
      'viewPadding': runtime.encodeValue(mq.viewPadding),
      'devicePixelRatio': mq.devicePixelRatio,
    };
  }
}
