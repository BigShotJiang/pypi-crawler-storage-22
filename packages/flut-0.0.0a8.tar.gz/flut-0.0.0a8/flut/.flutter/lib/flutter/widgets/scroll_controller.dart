import 'package:flutter/material.dart';
import 'package:flut/flut/object.dart';
import 'package:flut/flut/runtime.dart';
import 'package:flut/flut/error.dart';

class FlutScrollController extends ScrollController with FlutRealtimeObject {
  FlutScrollController._({
    required FlutRuntime runtime,
    required int flutOid,
    double initialScrollOffset = 0.0,
  }) : super(initialScrollOffset: initialScrollOffset) {
    initFlutRealtimeObject(runtime: runtime, flutOid: flutOid);
  }

  static FlutScrollController flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> json,
  ) {
    final oid = json['_flut_oid'] as int;
    return FlutScrollController._(
      runtime: runtime,
      flutOid: oid,
      initialScrollOffset:
          (json['initialScrollOffset'] as num?)?.toDouble() ?? 0.0,
    );
  }

  @override
  Map<String, dynamic> flutEncode() {
    return {'_flut_oid': flutOid, '_flut_type': 'ScrollController'};
  }

  @override
  dynamic getRawProperty(String property) {
    switch (property) {
      case 'offset':
        return offset;
      case 'hasClients':
        return hasClients;
      case 'position':
        return position;
    }
    throw FlutUnknownPropertyException('ScrollController', property);
  }

  @override
  bool setProperty(String property, dynamic value) {
    throw FlutUnknownPropertyException('ScrollController', property);
  }

  @override
  dynamic callMethod(String method, Map<String, dynamic> args) {
    switch (method) {
      case 'jumpTo':
        final offset = (args['offset'] as num).toDouble();
        jumpTo(offset);
        return true;
      case 'animateTo':
        final offset = (args['offset'] as num).toDouble();
        final duration = flutRuntime.decodeObject<Duration>(args['duration'])!;
        animateTo(offset, duration: duration, curve: Curves.easeInOut);
        return true;
    }
    throw FlutUnknownMethodException(method);
  }
}
