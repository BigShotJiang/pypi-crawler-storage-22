import 'package:flutter/material.dart';
import 'package:flut/flut/object.dart';
import 'package:flut/flut/runtime.dart';
import 'package:flut/flut/error.dart';

class FlutScrollPosition extends Object with FlutRealtimeObject {
  final ScrollPosition position;

  FlutScrollPosition({
    required this.position,
    required FlutRuntime runtime,
    required int flutOid,
  }) {
    initFlutRealtimeObject(runtime: runtime, flutOid: flutOid);
  }

  @override
  Map<String, dynamic> flutEncode() {
    return {'_flut_oid': flutOid, '_flut_type': 'ScrollPosition'};
  }

  @override
  dynamic getRawProperty(String property) {
    switch (property) {
      case 'pixels':
        return position.pixels;
      case 'minScrollExtent':
        return position.minScrollExtent;
      case 'maxScrollExtent':
        return position.maxScrollExtent;
      case 'viewportDimension':
        return position.viewportDimension;
      case 'hasContentDimensions':
        return position.hasContentDimensions;
      case 'hasPixels':
        return position.hasPixels;
      case 'atEdge':
        return position.atEdge;
    }
    throw FlutUnknownPropertyException('ScrollPosition', property);
  }

  @override
  bool setProperty(String property, dynamic value) {
    throw FlutUnknownPropertyException('ScrollPosition', property);
  }

  @override
  dynamic callMethod(String method, Map<String, dynamic> args) {
    switch (method) {
      case 'jumpTo':
        final offset = (args['offset'] as num).toDouble();
        position.jumpTo(offset);
        return true;
      case 'animateTo':
        final offset = (args['offset'] as num).toDouble();
        final duration = flutRuntime.decodeObject<Duration>(args['duration'])!;
        position.animateTo(offset, duration: duration, curve: Curves.easeInOut);
        return true;
    }
    throw FlutUnknownMethodException(method);
  }
}
