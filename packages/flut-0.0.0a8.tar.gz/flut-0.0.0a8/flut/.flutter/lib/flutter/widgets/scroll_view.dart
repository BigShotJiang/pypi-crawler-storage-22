import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';

class FlutListView {
  FlutListView._();

  static ListView? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> data,
    BuildContext context,
  ) {
    final children =
        (data['children'] as List?)
            ?.map((c) => runtime.decodeWidget(c, context))
            .whereType<Widget>()
            .toList() ??
        [];
    final reverse = data['reverse'] as bool? ?? false;
    final controller = runtime.decodeObject<ScrollController>(
      data['controller'],
    );
    final cacheExtent = (data['cacheExtent'] as num?)?.toDouble();

    return ListView(
      key: runtime.decodeKey(data),
      controller: controller,
      padding: runtime.decodeObject<EdgeInsets>(data['padding']),
      reverse: reverse,
      cacheExtent: cacheExtent,
      children: children,
    );
  }
}
