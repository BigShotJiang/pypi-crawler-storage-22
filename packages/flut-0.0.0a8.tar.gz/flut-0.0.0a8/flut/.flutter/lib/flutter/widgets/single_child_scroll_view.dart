import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';

class FlutSingleChildScrollView {
  FlutSingleChildScrollView._();

  static SingleChildScrollView? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> data,
    BuildContext context,
  ) {
    return SingleChildScrollView(
      key: runtime.decodeKey(data),
      padding: runtime.decodeObject<EdgeInsets>(data['padding']),
      scrollDirection: data['scrollDirection'] == 'horizontal'
          ? Axis.horizontal
          : Axis.vertical,
      child: runtime.decodeWidget(data['child'], context),
    );
  }
}
