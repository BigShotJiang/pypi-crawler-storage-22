import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';
import 'package:flut/flut/error.dart';

class FlutVisibility {
  FlutVisibility._();

  static Visibility? flutDecode(
    FlutRuntime runtime,
    Map<String, dynamic> data,
    BuildContext context,
  ) {
    final child = runtime.decodeWidget(data['child'], context);
    if (child == null) {
      throw FlutMissingRequiredParameterException('Visibility', 'child');
    }
    return Visibility(
      key: runtime.decodeKey(data),
      visible: data['visible'] as bool? ?? true,
      child: child,
    );
  }
}
