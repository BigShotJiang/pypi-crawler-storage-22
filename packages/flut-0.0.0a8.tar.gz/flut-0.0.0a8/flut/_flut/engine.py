import os
import sys
import json
import asyncio
import uuid
from typing import override

from flut._flut.runtime import flut_unpack


# The single global engine instance - all other modules only need this
_engine = None


def get_engine():
    """Get the current FlutterEngine instance."""
    return _engine


class FlutterEngine:
    """Flutter Engine built on top of FlutNative."""

    def __init__(self, native, root_widget):
        global _engine

        self._native = native
        self._root_widget = root_widget
        self._dart_call_fn = None
        self._notify_set_state_fn = None
        self._action_context = None
        self._event_loop = None  # Stored when running in async mode

        # Registries - all owned by the engine
        self.action_registry = {}  # Maps action IDs → Python callbacks
        self.state_registry = {}  # Maps stable IDs → State objects (StatefulWidget)
        self.widget_registry = {}  # Maps widget IDs → Widget (pending first build)

        # Build scope tracking for action cleanup
        self._current_build_scope = (
            None  # State currently building (for action registration)
        )

        # Set global engine reference
        _engine = self

    def call_dart(self, call_type, data):
        """Call Dart synchronously. Returns response dict or None.

        Safe to call from any action callback since all actions now run on
        the UI thread (main thread).
        """
        if self._dart_call_fn is None:
            return None

        return self._dart_call_fn(call_type, data)

    def _setup_dart_call_callback(self, callback_addr):
        """Set up FFI callback for calling Dart via native layer."""
        self._dart_call_fn = self._native.setup_call_dart(callback_addr)

    def _setup_set_state_notification(self, callback_addr):
        """Set up FFI callback for notifying Dart via native layer."""
        self._notify_set_state_fn = self._native.setup_notify_dart(callback_addr)

    def notify_set_state(self, state_id):
        """Send set state notification to Dart."""
        if self._notify_set_state_fn is not None:
            try:
                ids_json = json.dumps(state_id)
                self._notify_set_state_fn(ids_json.encode("utf-8"))
            except Exception as e:
                print(f"Error notifying Dart: {e}")

    def register_action(self, callback) -> str:
        """Register an action callback that Dart can invoke.

        Must be called during a State's build() method.
        """
        if self._current_build_scope is None:
            raise RuntimeError(
                "register_action called outside build scope. "
                "Actions must be registered during a State's build() method."
            )

        action_id = self._current_build_scope._allocate_action_id()
        self.action_registry[action_id] = callback
        return action_id

    def confirm_action(self, action_id: str):
        """Confirm an action was executed, removing it from the registry."""
        self.action_registry.pop(action_id, None)

    def initialize(self):
        self._native.initialize()

    def run(self, assets_path, width, height, title):
        self._native.run(self._handle_method_call, assets_path, width, height, title)

    async def run_async(self, assets_path, width, height, title, loop=None):
        self._event_loop = loop or asyncio.get_running_loop()
        await self._native.run_async(
            self._handle_method_call,
            assets_path,
            width,
            height,
            title,
            self._event_loop,
        )

    def shutdown(self):
        self._native.shutdown()

    def _process_single_action(self, action_data):
        """Process a single action event from Dart.

        Returns the callback result if any (used for key events that need sync return).
        """
        action_id = action_data.get("id")
        self._action_context = action_data.get("context") or None
        result = None

        if action_id in self.action_registry:
            cb = self.action_registry[action_id]
            value = action_data.get("value")
            key_data = action_data.get("keyData")

            # Prepare arguments
            if key_data is not None:
                # Key event - pass the key data dict
                args = (key_data,)
            elif value is not None:
                args = (value,)
            else:
                # Try generic _flut_type decoder
                decoded = flut_unpack(action_data)
                if decoded is not None:
                    args = (decoded,)
                else:
                    args = ()

            # Run callback
            # Note: We don't auto-delete actions because repeatable events like
            # onPanUpdate fire multiple times. Cleanup is handled when widgets
            # rebuild and register new actions (old IDs become orphaned but the
            # memory impact is minimal for typical apps).
            if asyncio.iscoroutinefunction(cb):
                # Async callback - schedule on stored event loop
                if self._event_loop is not None:
                    self._event_loop.create_task(cb(*args))
                else:
                    print(
                        f"Warning: async callback for {action_id} ignored (no event loop - use run_app_async)"
                    )
            else:
                result = cb(*args)
        else:
            print(f"No callback found for {action_id}")

        self._action_context = None
        return result

    def _handle_method_call(self, request_json):
        """
        Generic handler for method calls from Dart.
        request_json is a dict like {"type": "...", "data": ...}
        Returns JSON bytes or None.
        """
        try:
            req_type = request_json.get("type")
            data = request_json.get("data") or {}

            if req_type == "widget_build":
                from flut.flutter.widgets.framework import (
                    BuildContext,
                    StatefulWidget,
                    StatelessWidget,
                )

                widget_id = data.get("id")
                context_oid = data.get("contextOid")
                new_widget_id = data.get("newWidgetId")

                context = BuildContext(context_oid) if context_oid else None

                if widget_id is None:
                    if self._root_widget is not None:
                        resp = self._root_widget._flut_pack()
                        release_oids = collect_deleted_objects()
                        if release_oids:
                            resp["_flut_release_oids"] = release_oids
                        return json.dumps(resp).encode("utf-8")
                    return json.dumps(None).encode("utf-8")

                # Check state_registry for existing State (StatefulWidget only)
                state = self.state_registry.get(widget_id)

                if state is None:
                    # First build - check widget_registry
                    widget = self.widget_registry.get(widget_id)
                    if widget is not None:
                        # Don't delete - widget may be needed for didUpdateWidget later
                        if isinstance(widget, StatefulWidget):
                            # StatefulWidget - create State
                            state = widget.createState()
                            state._flut_widget = widget
                            state._flut_id = widget_id
                            state.initState()
                            self.state_registry[widget_id] = state
                        elif isinstance(widget, StatelessWidget):
                            # StatelessWidget - build directly, then cleanup
                            built = widget.build(context)
                            del self.widget_registry[widget_id]
                            subtree_json = built._flut_pack() if built else None
                            release_oids = collect_deleted_objects()
                            if release_oids:
                                if subtree_json is None:
                                    subtree_json = {}
                                subtree_json["_flut_release_oids"] = release_oids
                            return json.dumps(subtree_json).encode("utf-8")
                        else:
                            raise TypeError(
                                f"Unknown widget type: {type(widget).__name__}"
                            )

                if state is not None:
                    # Check if widget was replaced (Dart State persisted)
                    if new_widget_id and new_widget_id != widget_id:
                        new_widget = self.widget_registry.get(new_widget_id)
                        if new_widget is not None:
                            old_widget = state._flut_widget
                            state._flut_widget = new_widget
                            state.didUpdateWidget(old_widget)
                            self.widget_registry.pop(widget_id, None)
                            state._flut_current_widget_id = new_widget_id
                        else:
                            print(
                                f"Warning: newWidgetId '{new_widget_id}' not in widget_registry"
                            )

                    state._flut_last_build_context = context

                    # Clear previous build's actions before rebuilding
                    for action_id in state._flut_registered_actions:
                        self.action_registry.pop(action_id, None)
                    state._flut_registered_actions = []

                    # Set build scope so child widgets register to this State
                    self._current_build_scope = state
                    state._flut_action_counter = (
                        0  # Reset counter for stable action IDs
                    )
                    try:
                        built = state.build(context)
                        subtree_json = built._flut_pack() if built else None
                    finally:
                        self._current_build_scope = None

                    release_oids = collect_deleted_objects()
                    if release_oids:
                        if subtree_json is None:
                            subtree_json = {}
                        subtree_json["_flut_release_oids"] = release_oids
                    return json.dumps(subtree_json).encode("utf-8")

                print(
                    f"Warning: Widget '{widget_id}' not found in state_registry or widget_registry"
                )
                return json.dumps(None).encode("utf-8")

            elif req_type == "register_dart_callback":
                # Dart is registering its callback address for Python to call
                callback_addr = data.get("callback_addr")
                if callback_addr:
                    self._setup_dart_call_callback(callback_addr)
                    return json.dumps({"success": True}).encode("utf-8")
                return json.dumps({"error": "No callback_addr"}).encode("utf-8")

            elif req_type == "register_set_state_callback":
                # Dart is registering its notification callback address
                callback_addr = data.get("callback_addr")
                if callback_addr:
                    self._setup_set_state_notification(callback_addr)
                    return json.dumps({"success": True}).encode("utf-8")
                return json.dumps({"error": "No callback_addr"}).encode("utf-8")

            elif req_type == "action":
                # Direct action processing on main thread
                # All actions now use this path (including key events)
                result = self._process_single_action(data)

                # Return result if callback returned something (e.g., key events)
                # Dart can check for 'result' field if it needs the return value
                if result is not None:
                    # Handle Enum values (like KeyEventResult)
                    result_value = result.value if hasattr(result, "value") else result
                    return json.dumps({"result": result_value}).encode("utf-8")

                return json.dumps({"status": "ok"}).encode("utf-8")

            elif req_type == "state_dispose":
                # Dart State disposed - clean up Python state but keep widget
                # Widget must remain for scroll resurrection (child may re-mount)
                widget_id = data.get("id")
                if widget_id:
                    # Clean up state only (not widget)
                    state = self.state_registry.pop(widget_id, None)
                    if state:
                        # Clear actions registered by this state
                        for action_id in state._flut_registered_actions:
                            self.action_registry.pop(action_id, None)
                        # Call State.dispose()
                        state.dispose()
                return json.dumps({"status": "ok"}).encode("utf-8")

        except Exception as e:
            import traceback

            traceback.print_exc()
            return json.dumps({"_flut_error": str(e)}).encode("utf-8")


def _get_native_and_assets(assets_path):
    """Get native implementation and resolve assets path for current platform."""
    from .native.native import FlutNative

    native = FlutNative._create()

    if assets_path is None:
        assets_path = native.get_default_assets_path()
        if len(sys.argv) > 1:
            assets_path = sys.argv[1]

    if not os.path.exists(assets_path):
        print(f"ERROR: Assets not found at: {assets_path}")
        print()
        print("Build your Flutter app first.")
        return None, None

    print("=" * 60)
    print(f"Flutter via Python - {sys.platform}")
    print("=" * 60)
    print()
    print(f"Assets: {assets_path}")
    print()

    return native, assets_path


def run_app(widget, assets_path=None, width=800, height=600, title="Flut"):
    """Run the app (sync mode)."""
    native, assets_path = _get_native_and_assets(assets_path)
    if native is None:
        return None

    engine = FlutterEngine(native, widget)
    engine.initialize()

    try:
        engine.run(assets_path, width, height, title)
    finally:
        engine.shutdown()

    return engine


async def run_app_async(widget, assets_path=None, width=800, height=600, title="Flut"):
    """
    Run the app with asyncio integration (Windows, Linux, and macOS).

    Integrates platform's UI loop with asyncio:
    - Windows: Win32 messages + IOCP via MsgWaitForMultipleObjectsEx
    - Linux: GTK events + epoll via eventfd + g_unix_fd_add
    - macOS: CFRunLoop + kqueue via pipe + CFFileDescriptor

    Single-threaded, event-driven.

    Usage:
        async def main():
            # Start background async tasks
            asyncio.create_task(my_background_task())

            # Run Flutter app (this drives the event loop)
            await run_app_async(MyWidget())

        asyncio.run(main())

    Args:
        widget: The root widget for the app.
        assets_path: Path to flutter_assets (auto-detected if None).
        width: Initial window width.
        height: Initial window height.
        title: Window title.

    Returns:
        The FlutterEngine instance after the app closes.
    """
    native, assets_path = _get_native_and_assets(assets_path)
    if native is None:
        return None

    engine = FlutterEngine(native, widget)
    engine.initialize()

    try:
        await engine.run_async(assets_path, width, height, title)
    finally:
        engine.shutdown()

    return engine


def generate_flut_id() -> str:
    """Generate a unique ID for Flut objects."""
    return str(uuid.uuid4())


class FlutObject:
    def __init__(self, flut_type: str):
        if not flut_type:
            raise ValueError("flut_type must not be null or empty")
        self._flut_type = flut_type

    def _flut_base_props(self) -> dict:
        return {"_flut_type": self._flut_type}

    def _flut_pack(self) -> dict:
        raise NotImplementedError(f"{type(self).__name__} must implement _flut_pack()")


# Realtime object system - for objects that sync properties with Dart
_deleted_object_ids = []  # list of oids pending release to Dart


def _generate_oid() -> int:
    """Generate a unique int ID for realtime objects from Dart (single authority)."""
    engine = get_engine()
    if engine:
        result = engine.call_dart("generateOid", {})
        if result and "oid" in result:
            return result["oid"]
    # Fallback if engine not ready (shouldn't happen in practice)
    raise RuntimeError("Cannot generate oid: engine not initialized")


def collect_deleted_objects() -> list:
    """Collect deleted object IDs for piggybacking in response.

    Returns oids to include in the response JSON. Dart processes these
    after handling the widget tree, avoiding sync calls during builds.
    """
    global _deleted_object_ids
    if not _deleted_object_ids:
        return []
    oids = _deleted_object_ids
    _deleted_object_ids = []
    return oids


class FlutRealtimeObject(FlutObject):
    """Base class for objects that have realtime property sync with Dart.

    Uses integer _flut_oid for Dart-side lookup. When garbage collected,
    the oid is added to _deleted_object_ids for batch release to Dart.

    If oid is provided (Dart-created object), uses that.
    If oid is None (Python-created object), generates new oid from Dart.
    """

    def __init__(self, flut_type: str, oid: int | None = None):
        super().__init__(flut_type)
        self._flut_oid = oid if oid is not None else _generate_oid()

    @override
    def _flut_base_props(self) -> dict:
        """Return base realtime object properties."""
        return {
            **super()._flut_base_props(),
            "_flut_oid": self._flut_oid,
        }

    def __del__(self):
        # Guard against interpreter shutdown (globals may be None)
        try:
            if _deleted_object_ids is not None:
                _deleted_object_ids.append(self._flut_oid)
        except (TypeError, AttributeError):
            pass  # Interpreter shutting down
