def flut_unpack(data: dict):
    """Decode a dict with _flut_type to its Python object.
    
    Uses inline imports to avoid circular import issues.
    Returns the decoded object, or None if no _flut_type or unknown type.
    """
    if not isinstance(data, dict):
        return None
    
    flut_type = data.get("_flut_type")
    if not flut_type:
        return None

    match flut_type:
        case "DragStartDetails":
            from flut.flutter.gestures.drag_details import DragStartDetails
            return DragStartDetails.from_json(data)
        case "DragUpdateDetails":
            from flut.flutter.gestures.drag_details import DragUpdateDetails
            return DragUpdateDetails.from_json(data)
        case "DragEndDetails":
            from flut.flutter.gestures.drag_details import DragEndDetails
            return DragEndDetails.from_json(data)
        case _:
            return None
