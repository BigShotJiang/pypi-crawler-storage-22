from typing import override
from flut._flut.engine import FlutObject


class Duration(FlutObject):

    def __init__(
        self,
        *,
        days: int = 0,
        hours: int = 0,
        minutes: int = 0,
        seconds: int = 0,
        milliseconds: int = 0,
        microseconds: int = 0,
    ):
        super().__init__("Duration")
        self._microseconds = (
            days * 86400000000
            + hours * 3600000000
            + minutes * 60000000
            + seconds * 1000000
            + milliseconds * 1000
            + microseconds
        )

    @property
    def inMicroseconds(self) -> int:
        return self._microseconds

    @property
    def inMilliseconds(self) -> int:
        return self._microseconds // 1000

    @property
    def inSeconds(self) -> int:
        return self._microseconds // 1000000

    @property
    def inMinutes(self) -> int:
        return self._microseconds // 60000000

    @property
    def inHours(self) -> int:
        return self._microseconds // 3600000000

    @property
    def inDays(self) -> int:
        return self._microseconds // 86400000000

    @override
    def _flut_pack(self) -> dict:
        return {
            **self._flut_base_props(),
            "microseconds": self._microseconds,
        }

    def __repr__(self):
        return f"Duration(microseconds={self._microseconds})"

    def __eq__(self, other):
        if isinstance(other, Duration):
            return self._microseconds == other._microseconds
        return False

    def __hash__(self):
        return hash(self._microseconds)


Duration.zero = Duration()
