from typing import override
from flut._flut.engine import FlutObject


class Size:

    def __init__(self, width: float = 0, height: float = 0):
        self.width = width
        self.height = height


class Offset:
    def __init__(self, dx: float = 0, dy: float = 0):
        self.dx = dx
        self.dy = dy


class Paint(FlutObject):
    def __init__(self, color=0xFF000000, strokeWidth=1.0, style="fill"):
        super().__init__("Paint")
        self.color = color
        self.strokeWidth = strokeWidth
        self.style = style

    @override
    def _flut_pack(self) -> dict:
        return {
            **self._flut_base_props(),
            "color": self.color,
            "strokeWidth": self.strokeWidth,
            "style": self.style,
        }
