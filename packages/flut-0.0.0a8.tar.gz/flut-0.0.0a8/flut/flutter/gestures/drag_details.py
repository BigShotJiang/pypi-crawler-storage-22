from flut.dart.ui import Offset


class DragStartDetails:
    def __init__(
        self,
        globalPosition: Offset = None,
        localPosition: Offset = None,
    ):
        self.globalPosition = globalPosition or Offset()
        self.localPosition = localPosition or Offset()

    @staticmethod
    def from_json(data: dict) -> "DragStartDetails":
        return DragStartDetails(
            globalPosition=Offset(**data.get("globalPosition", {})),
            localPosition=Offset(**data.get("localPosition", {})),
        )


class DragUpdateDetails:
    def __init__(
        self,
        globalPosition: Offset = None,
        localPosition: Offset = None,
        delta: Offset = None,
    ):
        self.globalPosition = globalPosition or Offset()
        self.localPosition = localPosition or Offset()
        self.delta = delta or Offset()

    @staticmethod
    def from_json(data: dict) -> "DragUpdateDetails":
        return DragUpdateDetails(
            globalPosition=Offset(**data.get("globalPosition", {})),
            localPosition=Offset(**data.get("localPosition", {})),
            delta=Offset(**data.get("delta", {})),
        )


class DragEndDetails:

    def __init__(
        self,
        velocity: Offset = None,
    ):
        self.velocity = velocity or Offset()

    @staticmethod
    def from_json(data: dict) -> "DragEndDetails":
        return DragEndDetails(
            velocity=Offset(**data.get("velocity", {})),
        )
