from typing import Optional, override

from flut.flutter.widgets.framework import Widget


class MaterialApp(Widget):

    def __init__(
        self,
        *,
        key=None,
        home: Optional[Widget] = None,
        title: Optional[str] = None,
        theme=None,
    ):
        super().__init__("MaterialApp", key=key)
        self.home = home
        self.title = title
        self.theme = theme

    @override
    def _flut_pack(self) -> dict:
        result = {**self._flut_base_props()}
        if self.title is not None:
            result["title"] = self.title
        if self.theme is not None:
            result["theme"] = self.theme._flut_pack()
        if self.home is not None:
            result["home"] = self.home._flut_pack()
        return result
