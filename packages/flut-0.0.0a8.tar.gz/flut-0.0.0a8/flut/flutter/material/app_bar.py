from typing import Optional, override

from flut.flutter.widgets.framework import Widget


class AppBar(Widget):

    def __init__(
        self,
        *,
        key=None,
        title: Optional[Widget] = None,
        backgroundColor=None,
        scrolledUnderElevation: Optional[float] = None,
    ):
        super().__init__("AppBar", key=key)
        self.title = title
        self.backgroundColor = backgroundColor
        self.scrolledUnderElevation = scrolledUnderElevation

    @override
    def _flut_pack(self) -> dict:
        result = {**self._flut_base_props()}
        if self.title is not None:
            result["title"] = self.title._flut_pack()
        if self.backgroundColor is not None:
            result["backgroundColor"] = self.backgroundColor
        if self.scrolledUnderElevation is not None:
            result["scrolledUnderElevation"] = self.scrolledUnderElevation
        return result
