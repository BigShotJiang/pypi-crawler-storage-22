from typing import Optional, override

from flut.flutter.widgets.framework import Widget


class Card(Widget):
    def __init__(
        self,
        *,
        key=None,
        child: Optional[Widget] = None,
        color=None,
        elevation: Optional[float] = None,
        margin=None,
    ):
        super().__init__("Card", key=key)
        self.child = child
        self.color = color
        self.elevation = elevation
        self.margin = margin

    @override
    def _flut_pack(self) -> dict:
        result = {**self._flut_base_props()}
        if self.child is not None:
            result["child"] = self.child._flut_pack()
        if self.color is not None:
            result["color"] = self.color
        if self.elevation is not None:
            result["elevation"] = self.elevation
        if self.margin is not None:
            result["margin"] = self.margin._flut_pack()
        return result
