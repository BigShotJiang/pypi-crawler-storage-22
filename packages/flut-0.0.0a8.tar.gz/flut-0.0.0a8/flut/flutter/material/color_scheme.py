from typing import Optional, override
from flut._flut.engine import FlutObject


class ColorScheme(FlutObject):
    def __init__(
        self,
        *,
        seedColor=None,
        primary=None,
        onPrimary=None,
        secondary=None,
        onSecondary=None,
        surface=None,
        onSurface=None,
        error=None,
        onError=None,
        inversePrimary=None,
    ):
        super().__init__("ColorScheme")
        self.seedColor = seedColor
        self.primary = primary
        self.onPrimary = onPrimary
        self.secondary = secondary
        self.onSecondary = onSecondary
        self.surface = surface
        self.onSurface = onSurface
        self.error = error
        self.onError = onError
        self.inversePrimary = inversePrimary

    @staticmethod
    def fromSeed(*, seedColor):
        return ColorScheme(seedColor=seedColor)

    @override
    def _flut_pack(self) -> dict:
        result = {**self._flut_base_props()}
        if self.seedColor is not None:
            result["seedColor"] = self.seedColor
        if self.primary is not None:
            result["primary"] = self.primary
        if self.onPrimary is not None:
            result["onPrimary"] = self.onPrimary
        if self.secondary is not None:
            result["secondary"] = self.secondary
        if self.onSecondary is not None:
            result["onSecondary"] = self.onSecondary
        if self.surface is not None:
            result["surface"] = self.surface
        if self.onSurface is not None:
            result["onSurface"] = self.onSurface
        if self.error is not None:
            result["error"] = self.error
        if self.onError is not None:
            result["onError"] = self.onError
        if self.inversePrimary is not None:
            result["inversePrimary"] = self.inversePrimary
        return result