from typing import Optional, override

from flut.flutter.widgets.framework import Widget


class Divider(Widget):
    def __init__(
        self,
        *,
        key=None,
        height: Optional[float] = None,
        thickness: Optional[float] = None,
        color=None,
    ):
        super().__init__("Divider", key=key)
        self.height = height
        self.thickness = thickness
        self.color = color

    @override
    def _flut_pack(self) -> dict:
        result = {**self._flut_base_props()}
        if self.height is not None:
            result["height"] = self.height
        if self.thickness is not None:
            result["thickness"] = self.thickness
        if self.color is not None:
            result["color"] = self.color
        return result
