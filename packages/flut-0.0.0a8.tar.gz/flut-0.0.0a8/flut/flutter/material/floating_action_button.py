from typing import Optional, override

from flut._flut.engine import get_engine
from flut.flutter.widgets.framework import Widget


class FloatingActionButton(Widget):
    def __init__(
        self,
        *,
        key=None,
        child: Optional[Widget] = None,
        onPressed=None,
        tooltip: Optional[str] = None,
    ):
        super().__init__("FloatingActionButton", key=key)
        self.child = child
        self.onPressed = onPressed
        self.tooltip = tooltip

    @override
    def _flut_pack(self) -> dict:
        result = {**self._flut_base_props()}
        if self.child is not None:
            result["child"] = self.child._flut_pack()
        if self.tooltip is not None:
            result["tooltip"] = self.tooltip
        if self.onPressed is not None:
            result["onPressedId"] = get_engine().register_action(self.onPressed)
        return result

