from typing import Optional, override

from flut._flut.engine import get_engine
from flut.flutter.widgets.framework import Widget


class IconButton(Widget):
    def __init__(
        self,
        *,
        key=None,
        icon: Optional[Widget] = None,
        onPressed=None,
        color=None,
        iconSize: Optional[float] = None,
        tooltip: Optional[str] = None,
    ):
        super().__init__("IconButton", key=key)
        self.icon = icon
        self.onPressed = onPressed
        self.color = color
        self.iconSize = iconSize
        self.tooltip = tooltip

    @override
    def _flut_pack(self) -> dict:
        result = {**self._flut_base_props()}
        if self.icon is not None:
            result["icon"] = self.icon._flut_pack()
        if self.onPressed is not None:
            result["onPressedId"] = get_engine().register_action(self.onPressed)
        if self.color is not None:
            result["color"] = self.color
        if self.iconSize is not None:
            result["iconSize"] = self.iconSize
        if self.tooltip is not None:
            result["tooltip"] = self.tooltip
        return result
