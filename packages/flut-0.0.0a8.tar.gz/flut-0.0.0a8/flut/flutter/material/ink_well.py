from typing import Optional, override

from flut._flut.engine import get_engine
from flut.flutter.widgets.framework import Widget


class InkWell(Widget):
    def __init__(self, *, key=None, child: Optional[Widget] = None, onTap=None):
        super().__init__("InkWell", key=key)
        self.child = child
        self.onTap = onTap

    @override
    def _flut_pack(self) -> dict:
        result = {**self._flut_base_props()}
        if self.onTap is not None:
            result["onTapId"] = get_engine().register_action(self.onTap)
        if self.child is not None:
            result["child"] = self.child._flut_pack()
        return result
