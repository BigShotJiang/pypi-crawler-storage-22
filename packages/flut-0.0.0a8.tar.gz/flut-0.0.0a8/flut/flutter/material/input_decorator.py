from typing import Optional, override
from flut._flut.engine import FlutObject


class InputBorder(FlutObject):
    none = None

    def __init__(self):
        super().__init__("InputBorder")

    @staticmethod
    def _get_none():
        if InputBorder.none is None:
            InputBorder.none = _InputBorderNone()
        return InputBorder.none


class _InputBorderNone(InputBorder):
    @override
    def _flut_pack(self) -> dict:
        return {**self._flut_base_props(), "value": "none"}


InputBorder.none = _InputBorderNone()


class InputDecoration(FlutObject):
    def __init__(
        self,
        *,
        hintText: Optional[str] = None,
        border=None,
        filled: Optional[bool] = None,
        fillColor=None,
        contentPadding=None,
    ):
        super().__init__("InputDecoration")
        self.hintText = hintText
        self.border = border
        self.filled = filled
        self.fillColor = fillColor
        self.contentPadding = contentPadding

    @override
    def _flut_pack(self) -> dict:
        result = {**self._flut_base_props()}
        if self.hintText is not None:
            result["hintText"] = self.hintText
        if self.border is not None:
            result["border"] = self.border._flut_pack()
        if self.filled is not None:
            result["filled"] = self.filled
        if self.fillColor is not None:
            result["fillColor"] = self.fillColor
        if self.contentPadding is not None:
            result["contentPadding"] = self.contentPadding._flut_pack()
        return result
