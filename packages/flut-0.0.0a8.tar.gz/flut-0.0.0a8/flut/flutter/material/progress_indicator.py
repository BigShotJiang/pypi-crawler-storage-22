from typing import Optional, override

from flut.flutter.widgets.framework import Widget


class CircularProgressIndicator(Widget):
    def __init__(
        self,
        *,
        key=None,
        strokeWidth: Optional[float] = None,
        color=None,
    ):
        super().__init__("CircularProgressIndicator", key=key)
        self.strokeWidth = strokeWidth
        self.color = color

    @override
    def _flut_pack(self) -> dict:
        result = {**self._flut_base_props()}
        if self.strokeWidth is not None:
            result["strokeWidth"] = self.strokeWidth
        if self.color is not None:
            result["color"] = self.color
        return result
