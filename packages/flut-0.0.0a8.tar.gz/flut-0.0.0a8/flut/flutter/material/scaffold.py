from typing import Optional, override

from flut.flutter.widgets.framework import Widget


class Scaffold(Widget):

    def __init__(
        self,
        *,
        key=None,
        body: Optional[Widget] = None,
        appBar: Optional[Widget] = None,
        floatingActionButton: Optional[Widget] = None,
    ):
        super().__init__("Scaffold", key=key)
        self.body = body
        self.appBar = appBar
        self.floatingActionButton = floatingActionButton

    @override
    def _flut_pack(self) -> dict:
        result = {**self._flut_base_props()}
        if self.body is not None:
            result["body"] = self.body._flut_pack()
        if self.appBar is not None:
            result["appBar"] = self.appBar._flut_pack()
        if self.floatingActionButton is not None:
            result["floatingActionButton"] = self.floatingActionButton._flut_pack()
        return result
