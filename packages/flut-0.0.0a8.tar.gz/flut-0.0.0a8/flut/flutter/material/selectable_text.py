from typing import Optional, override

from ..widgets.framework import Widget
from ..painting.text_style import TextStyle


class SelectableText(Widget):
    def __init__(
        self,
        data: str,
        *,
        key=None,
        style: Optional[TextStyle] = None,
        maxLines: Optional[int] = None,
    ):
        super().__init__("SelectableText", key=key)
        self.data = data
        self.style = style
        self.maxLines = maxLines

    @override
    def _flut_pack(self) -> dict:
        result = {
            **self._flut_base_props(),
            "data": str(self.data) if self.data is not None else None,
        }
        if self.style is not None:
            result["style"] = self.style._flut_pack()
        if self.maxLines is not None:
            result["maxLines"] = self.maxLines
        return result
