from typing import Optional, override

from flut._flut.engine import get_engine
from flut.flutter.widgets.framework import Widget


class TextField(Widget):
    def __init__(
        self,
        *,
        key=None,
        controller=None,
        focusNode=None,
        onChanged=None,
        onSubmitted=None,
        readOnly: Optional[bool] = None,
        maxLines: Optional[int] = None,
        minLines: Optional[int] = None,
        decoration=None,
        style=None,
    ):
        super().__init__("TextField", key=key)
        self.controller = controller
        self.focusNode = focusNode
        self.onChanged = onChanged
        self.onSubmitted = onSubmitted
        self.readOnly = readOnly
        self.maxLines = maxLines
        self.minLines = minLines
        self.decoration = decoration
        self.style = style

    @override
    def _flut_pack(self) -> dict:
        engine = get_engine()
        result = {**self._flut_base_props()}

        if self.controller is not None:
            result["controller"] = self.controller._flut_pack()
        if self.focusNode is not None:
            self.focusNode._register()
            result["focusNode"] = self.focusNode._flut_pack()
        if self.onChanged is not None:
            result["onChangedId"] = engine.register_action(self.onChanged)
        if self.onSubmitted is not None:
            result["onSubmittedId"] = engine.register_action(self.onSubmitted)
        if self.readOnly is not None:
            result["readOnly"] = self.readOnly
        if self.maxLines is not None:
            result["maxLines"] = self.maxLines
        if self.minLines is not None:
            result["minLines"] = self.minLines
        if self.decoration is not None:
            result["decoration"] = self.decoration._flut_pack()
        if self.style is not None:
            result["style"] = self.style._flut_pack()

        return result

