class TextTheme:
    def __init__(self, headlineMedium=None):
        self.headlineMedium = headlineMedium