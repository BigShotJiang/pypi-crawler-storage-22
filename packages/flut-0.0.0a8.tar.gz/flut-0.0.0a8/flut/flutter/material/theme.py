from flut._flut.engine import get_engine
from flut.flutter.material.theme_data import ThemeData
from flut.flutter.material.color_scheme import ColorScheme


class Theme:

    @staticmethod
    def of(context) -> ThemeData:
        engine = get_engine()
        if engine is None or context is None:
            return ThemeData()

        result = engine.call_dart("static", {
            "name": "Theme.of",
            "args": [{"oid": context._flut_oid}],
        })

        if result and "value" in result:
            data = result["value"]
            scheme_data = data.get("colorScheme", {})
            scheme = ColorScheme(
                primary=scheme_data.get("primary"),
                onPrimary=scheme_data.get("onPrimary"),
                secondary=scheme_data.get("secondary"),
                onSecondary=scheme_data.get("onSecondary"),
                surface=scheme_data.get("surface"),
                onSurface=scheme_data.get("onSurface"),
                error=scheme_data.get("error"),
                onError=scheme_data.get("onError"),
                inversePrimary=scheme_data.get("inversePrimary"),
            )
            return ThemeData(
                colorScheme=scheme,
                useMaterial3=data.get("useMaterial3", True),
            )

        return ThemeData()