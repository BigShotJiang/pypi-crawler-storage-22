from typing import Optional, override
from flut._flut.engine import FlutObject
from flut.flutter.material.text_theme import TextTheme


class ThemeData(FlutObject):
    def __init__(
        self,
        *,
        colorScheme=None,
        useMaterial3: Optional[bool] = None,
        textTheme: Optional[TextTheme] = None,
    ):
        super().__init__("ThemeData")
        self.colorScheme = colorScheme
        self.useMaterial3 = useMaterial3
        self.textTheme = textTheme

    @override
    def _flut_pack(self) -> dict:
        result = {**self._flut_base_props()}
        if self.colorScheme is not None:
            result["colorScheme"] = self.colorScheme._flut_pack()
        if self.useMaterial3 is not None:
            result["useMaterial3"] = self.useMaterial3
        if self.textTheme is not None:
            result["textTheme"] = self.textTheme._flut_pack()
        return result
