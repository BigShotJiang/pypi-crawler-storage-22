from typing import override
from flut._flut.engine import FlutObject


class Alignment(FlutObject):
    def __init__(self, value: str):
        super().__init__("Alignment")
        self.value = value

    @override
    def _flut_pack(self) -> dict:
        return {
            **self._flut_base_props(),
            "value": self.value,
        }

    # Pre-defined alignments
    topLeft = None
    topCenter = None
    topRight = None
    centerLeft = None
    center = None
    centerRight = None
    bottomLeft = None
    bottomCenter = None
    bottomRight = None


# Initialize class-level constants after class definition
Alignment.topLeft = Alignment("topLeft")
Alignment.topCenter = Alignment("topCenter")
Alignment.topRight = Alignment("topRight")
Alignment.centerLeft = Alignment("centerLeft")
Alignment.center = Alignment("center")
Alignment.centerRight = Alignment("centerRight")
Alignment.bottomLeft = Alignment("bottomLeft")
Alignment.bottomCenter = Alignment("bottomCenter")
Alignment.bottomRight = Alignment("bottomRight")
