from typing import Optional, override
from flut._flut.engine import FlutObject


class BorderRadius(FlutObject):
    def __init__(
        self,
        *,
        topLeft: Optional[float] = None,
        topRight: Optional[float] = None,
        bottomLeft: Optional[float] = None,
        bottomRight: Optional[float] = None,
    ):
        super().__init__("BorderRadius")
        self.topLeft = topLeft
        self.topRight = topRight
        self.bottomLeft = bottomLeft
        self.bottomRight = bottomRight

    @staticmethod
    def circular(radius):
        return BorderRadius(
            topLeft=radius, topRight=radius, bottomLeft=radius, bottomRight=radius
        )

    @staticmethod
    def all(radius):
        return BorderRadius.circular(radius)

    @override
    def _flut_pack(self) -> dict:
        result = {**self._flut_base_props()}
        if self.topLeft is not None:
            result["topLeft"] = self.topLeft
        if self.topRight is not None:
            result["topRight"] = self.topRight
        if self.bottomLeft is not None:
            result["bottomLeft"] = self.bottomLeft
        if self.bottomRight is not None:
            result["bottomRight"] = self.bottomRight
        return result
