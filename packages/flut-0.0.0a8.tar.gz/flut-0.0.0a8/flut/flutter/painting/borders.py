from typing import Optional, override
from flut._flut.engine import FlutObject


class BorderSide(FlutObject):
    def __init__(self, *, color=None, width: Optional[float] = None):
        super().__init__("BorderSide")
        self.color = color
        self.width = width

    @override
    def _flut_pack(self) -> dict:
        result = {**self._flut_base_props()}
        if self.color is not None:
            result["color"] = self.color
        if self.width is not None:
            result["width"] = self.width
        return result


class Border(FlutObject):
    def __init__(
        self,
        *,
        left: Optional[BorderSide] = None,
        top: Optional[BorderSide] = None,
        right: Optional[BorderSide] = None,
        bottom: Optional[BorderSide] = None,
    ):
        super().__init__("Border")
        self.left = left
        self.top = top
        self.right = right
        self.bottom = bottom

    @staticmethod
    def all(*, width: float = 1.0, color=0xFF000000):
        side = BorderSide(color=color, width=width)
        return Border(left=side, top=side, right=side, bottom=side)

    @override
    def _flut_pack(self) -> dict:
        result = {**self._flut_base_props()}
        if self.left is not None:
            result["left"] = self.left._flut_pack()
        if self.top is not None:
            result["top"] = self.top._flut_pack()
        if self.right is not None:
            result["right"] = self.right._flut_pack()
        if self.bottom is not None:
            result["bottom"] = self.bottom._flut_pack()
        return result
