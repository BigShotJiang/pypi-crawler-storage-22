from typing import Optional, override
from flut._flut.engine import FlutObject
from .border_radius import BorderRadius


class BoxDecoration(FlutObject):
    def __init__(
        self,
        *,
        color=None,
        border=None,
        borderRadius=None,
    ):
        super().__init__("BoxDecoration")
        self.color = color
        self.border = border
        self.borderRadius = borderRadius

    @override
    def _flut_pack(self) -> dict:
        result = {**self._flut_base_props()}
        if self.color is not None:
            result["color"] = self.color
        if self.border is not None:
            result["border"] = self.border._flut_pack()
        if self.borderRadius is not None:
            border_radius = self.borderRadius
            if isinstance(border_radius, (int, float)):
                border_radius = BorderRadius.circular(border_radius)
            result["borderRadius"] = border_radius._flut_pack()
        return result
