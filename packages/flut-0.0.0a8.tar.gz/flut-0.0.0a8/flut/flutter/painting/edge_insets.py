from typing import Optional, override
from flut._flut.engine import FlutObject


class EdgeInsets(FlutObject):
    def __init__(
        self,
        left: Optional[float] = None,
        top: Optional[float] = None,
        right: Optional[float] = None,
        bottom: Optional[float] = None,
    ):
        super().__init__("EdgeInsets")
        self.left = left
        self.top = top
        self.right = right
        self.bottom = bottom

    @staticmethod
    def all(value):
        return EdgeInsets(value, value, value, value)

    @staticmethod
    def symmetric(*, vertical: float = 0, horizontal: float = 0):
        return EdgeInsets(horizontal, vertical, horizontal, vertical)

    @staticmethod
    def only(
        *,
        left: float = 0,
        top: float = 0,
        right: float = 0,
        bottom: float = 0,
    ):
        return EdgeInsets(left, top, right, bottom)

    @override
    def _flut_pack(self) -> dict:
        result = {**self._flut_base_props()}
        if self.left is not None:
            result["left"] = self.left
        if self.top is not None:
            result["top"] = self.top
        if self.right is not None:
            result["right"] = self.right
        if self.bottom is not None:
            result["bottom"] = self.bottom
        return result
