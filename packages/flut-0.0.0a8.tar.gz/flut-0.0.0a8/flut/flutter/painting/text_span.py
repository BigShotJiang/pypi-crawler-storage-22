from typing import override
from flut._flut.engine import FlutObject


class TextSpan(FlutObject):
    def __init__(self, text=None, children=None, style=None):
        super().__init__("TextSpan")
        self.text = text
        self.children = children
        self.style = style

    @override
    def _flut_pack(self) -> dict:
        children = None
        if self.children is not None:
            children = [child._flut_pack() for child in self.children]

        return {
            **self._flut_base_props(),
            "text": self.text,
            "children": children,
            "style": self.style._flut_pack() if self.style else None,
        }
