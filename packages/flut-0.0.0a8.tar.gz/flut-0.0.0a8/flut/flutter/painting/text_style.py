from typing import Optional, override
from flut._flut.engine import FlutObject


class FontWeight:
    bold = "bold"
    normal = "normal"
    w100 = "w100"
    w200 = "w200"
    w300 = "w300"
    w400 = "w400"
    w500 = "w500"
    w600 = "w600"
    w700 = "w700"
    w800 = "w800"
    w900 = "w900"


class TextStyle(FlutObject):
    def __init__(
        self,
        *,
        fontSize: Optional[float] = None,
        fontWeight: Optional[str] = None,
        color=None,
        fontFamily: Optional[str] = None,
        height: Optional[float] = None,
    ):
        super().__init__("TextStyle")
        self.fontSize = fontSize
        self.fontWeight = fontWeight
        self.color = color
        self.fontFamily = fontFamily
        self.height = height

    @override
    def _flut_pack(self) -> dict:
        result = {**self._flut_base_props()}
        if self.fontSize is not None:
            result["fontSize"] = self.fontSize
        if self.fontWeight is not None:
            result["fontWeight"] = self.fontWeight
        if self.color is not None:
            result["color"] = self.color
        if self.fontFamily is not None:
            result["fontFamily"] = self.fontFamily
        if self.height is not None:
            result["height"] = self.height
        return result
