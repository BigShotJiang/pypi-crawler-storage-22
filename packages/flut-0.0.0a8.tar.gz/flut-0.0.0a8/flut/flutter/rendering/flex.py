from typing import override
from flut._flut.engine import FlutObject


class MainAxisAlignment(FlutObject):
    def __init__(self, value: str):
        super().__init__("MainAxisAlignment")
        self.value = value

    @override
    def _flut_pack(self) -> dict:
        return {
            **self._flut_base_props(),
            "value": self.value,
        }

    center = None
    start = None
    end = None
    spaceBetween = None
    spaceAround = None
    spaceEvenly = None


MainAxisAlignment.center = MainAxisAlignment("center")
MainAxisAlignment.start = MainAxisAlignment("start")
MainAxisAlignment.end = MainAxisAlignment("end")
MainAxisAlignment.spaceBetween = MainAxisAlignment("spaceBetween")
MainAxisAlignment.spaceAround = MainAxisAlignment("spaceAround")
MainAxisAlignment.spaceEvenly = MainAxisAlignment("spaceEvenly")


class CrossAxisAlignment(FlutObject):
    def __init__(self, value: str):
        super().__init__("CrossAxisAlignment")
        self.value = value

    @override
    def _flut_pack(self) -> dict:
        return {
            **self._flut_base_props(),
            "value": self.value,
        }

    center = None
    start = None
    end = None
    stretch = None
    baseline = None


CrossAxisAlignment.center = CrossAxisAlignment("center")
CrossAxisAlignment.start = CrossAxisAlignment("start")
CrossAxisAlignment.end = CrossAxisAlignment("end")
CrossAxisAlignment.stretch = CrossAxisAlignment("stretch")
CrossAxisAlignment.baseline = CrossAxisAlignment("baseline")
