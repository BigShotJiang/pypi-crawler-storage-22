from typing import Optional, Set

from .keyboard_key import (
    LogicalKeyboardKey,
    PhysicalKeyboardKey,
    findKeyByKeyId,
    findPhysicalKeyByUsage,
)


class KeyEvent:

    def __init__(
        self,
        physicalKey: PhysicalKeyboardKey,
        logicalKey: LogicalKeyboardKey,
        timeStamp: float,
        character: Optional[str] = None,
        synthesized: bool = False,
    ):
        self.physicalKey = physicalKey
        self.logicalKey = logicalKey
        self.timeStamp = timeStamp
        self.character = character
        self.synthesized = synthesized

    def __repr__(self):
        return (
            f"{self.__class__.__name__}("
            f"physicalKey={self.physicalKey}, "
            f"logicalKey={self.logicalKey}, "
            f"character={self.character!r})"
        )


class KeyDownEvent(KeyEvent):
    pass


class KeyUpEvent(KeyEvent):
    pass


class KeyRepeatEvent(KeyEvent):
    pass


class HardwareKeyboard:

    _instance: Optional["HardwareKeyboard"] = None

    def __init__(self):
        self._pressedKeys: Set[PhysicalKeyboardKey] = set()
        self._logicalKeysPressed: Set[LogicalKeyboardKey] = set()
        self._lockModes: Set[int] = set()

    @classmethod
    def instance(cls) -> "HardwareKeyboard":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    @property
    def physicalKeysPressed(self) -> Set[PhysicalKeyboardKey]:
        return self._pressedKeys.copy()

    @property
    def logicalKeysPressed(self) -> Set[LogicalKeyboardKey]:
        return self._logicalKeysPressed.copy()

    def isPhysicalKeyPressed(self, key: PhysicalKeyboardKey) -> bool:
        return key in self._pressedKeys

    def isLogicalKeyPressed(self, key: LogicalKeyboardKey) -> bool:
        return key in self._logicalKeysPressed

    @property
    def isShiftPressed(self) -> bool:
        return (
            LogicalKeyboardKey.shiftLeft in self._logicalKeysPressed
            or LogicalKeyboardKey.shiftRight in self._logicalKeysPressed
        )

    @property
    def isControlPressed(self) -> bool:
        return (
            LogicalKeyboardKey.controlLeft in self._logicalKeysPressed
            or LogicalKeyboardKey.controlRight in self._logicalKeysPressed
        )

    @property
    def isAltPressed(self) -> bool:
        return (
            LogicalKeyboardKey.altLeft in self._logicalKeysPressed
            or LogicalKeyboardKey.altRight in self._logicalKeysPressed
        )

    @property
    def isMetaPressed(self) -> bool:
        return (
            LogicalKeyboardKey.metaLeft in self._logicalKeysPressed
            or LogicalKeyboardKey.metaRight in self._logicalKeysPressed
        )

    @property
    def lockModesEnabled(self) -> Set[int]:
        return self._lockModes.copy()

    def _updateKeyState(self, event: KeyEvent) -> None:
        if isinstance(event, KeyDownEvent):
            self._pressedKeys.add(event.physicalKey)
            self._logicalKeysPressed.add(event.logicalKey)
        elif isinstance(event, KeyUpEvent):
            self._pressedKeys.discard(event.physicalKey)
            self._logicalKeysPressed.discard(event.logicalKey)


def createKeyEventFromData(data: dict) -> KeyEvent:
    event_type = data.get("type", "down")
    logical_key_id = data.get("logicalKeyId", 0)
    physical_key_usage = data.get("physicalKeyUsage", 0)
    character = data.get("character")
    time_stamp = data.get("timeStamp", 0.0)
    synthesized = data.get("synthesized", False)

    logical_key = findKeyByKeyId(logical_key_id)
    physical_key = findPhysicalKeyByUsage(physical_key_usage)

    if event_type == "up":
        return KeyUpEvent(
            physicalKey=physical_key,
            logicalKey=logical_key,
            timeStamp=time_stamp,
            character=character,
            synthesized=synthesized,
        )
    elif event_type == "repeat":
        return KeyRepeatEvent(
            physicalKey=physical_key,
            logicalKey=logical_key,
            timeStamp=time_stamp,
            character=character,
            synthesized=synthesized,
        )
    else:  # "down" or default
        return KeyDownEvent(
            physicalKey=physical_key,
            logicalKey=logical_key,
            timeStamp=time_stamp,
            character=character,
            synthesized=synthesized,
        )
