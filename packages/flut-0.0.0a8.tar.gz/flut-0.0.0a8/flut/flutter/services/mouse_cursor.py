from typing import override
from flut._flut.engine import FlutObject


class MouseCursor(FlutObject):
    def __init__(self, value: str):
        super().__init__("MouseCursor")
        self.value = value

    @override
    def _flut_pack(self) -> dict:
        return {
            **self._flut_base_props(),
            "value": self.value,
        }

    defer = None


MouseCursor.defer = MouseCursor("defer")


class SystemMouseCursors:
    basic = MouseCursor("basic")
    click = MouseCursor("click")
    text = MouseCursor("text")
    resizeLeftRight = MouseCursor("resizeLeftRight")
    resizeUpDown = MouseCursor("resizeUpDown")
    resizeColumn = MouseCursor("resizeColumn")
    resizeRow = MouseCursor("resizeRow")
    grab = MouseCursor("grab")
    grabbing = MouseCursor("grabbing")
    move = MouseCursor("move")
    forbidden = MouseCursor("forbidden")
    wait = MouseCursor("wait")
