from typing import List, Optional, override

from flut._flut.engine import get_engine
from .framework import Widget


class ScrollMode:
    auto = "auto"
    always = "always"
    hidden = "hidden"
    adaptive = "adaptive"


class Center(Widget):
    def __init__(self, *, key=None, child: Optional[Widget] = None):
        super().__init__("Center", key=key)
        self.child = child

    @override
    def _flut_pack(self) -> dict:
        result = {**self._flut_base_props()}
        if self.child is not None:
            result["child"] = self.child._flut_pack()
        return result


class Expanded(Widget):
    def __init__(
        self,
        *,
        key=None,
        child: Optional[Widget] = None,
        flex: Optional[int] = None,
    ):
        super().__init__("Expanded", key=key)
        self.child = child
        self.flex = flex

    @override
    def _flut_pack(self) -> dict:
        result = {**self._flut_base_props()}
        if self.flex is not None:
            result["flex"] = self.flex
        if self.child is not None:
            result["child"] = self.child._flut_pack()
        return result


class Flexible(Widget):
    def __init__(
        self,
        *,
        key=None,
        child: Optional[Widget] = None,
        flex: Optional[int] = None,
        fit=None,
    ):
        super().__init__("Flexible", key=key)
        self.child = child
        self.flex = flex
        self.fit = fit

    @override
    def _flut_pack(self) -> dict:
        result = {**self._flut_base_props()}
        if self.flex is not None:
            result["flex"] = self.flex
        if self.fit is not None:
            result["fit"] = self.fit
        if self.child is not None:
            result["child"] = self.child._flut_pack()
        return result


class SizedBox(Widget):
    def __init__(
        self,
        *,
        key=None,
        width: Optional[float] = None,
        height: Optional[float] = None,
        child: Optional[Widget] = None,
    ):
        super().__init__("SizedBox", key=key)
        self.width = width
        self.height = height
        self.child = child

    @override
    def _flut_pack(self) -> dict:
        result = {**self._flut_base_props()}
        if self.width is not None:
            result["width"] = self.width
        if self.height is not None:
            result["height"] = self.height
        if self.child is not None:
            result["child"] = self.child._flut_pack()
        return result


class Column(Widget):
    def __init__(
        self,
        *,
        key=None,
        children: Optional[List[Widget]] = None,
        mainAxisAlignment=None,
        crossAxisAlignment=None,
        spacing: Optional[float] = None,
    ):
        super().__init__("Column", key=key)
        self.children = children or []
        self.mainAxisAlignment = mainAxisAlignment
        self.crossAxisAlignment = crossAxisAlignment
        self.spacing = spacing

    @override
    def _flut_pack(self) -> dict:
        result = {
            **self._flut_base_props(),
            "children": [c._flut_pack() for c in self.children],
        }
        if self.mainAxisAlignment is not None:
            result["mainAxisAlignment"] = self.mainAxisAlignment._flut_pack()
        if self.crossAxisAlignment is not None:
            result["crossAxisAlignment"] = self.crossAxisAlignment._flut_pack()
        if self.spacing is not None:
            result["spacing"] = self.spacing
        return result


class Row(Widget):
    def __init__(
        self,
        *,
        key=None,
        children: Optional[List[Widget]] = None,
        mainAxisAlignment=None,
        crossAxisAlignment=None,
        spacing: Optional[float] = None,
    ):
        super().__init__("Row", key=key)
        self.children = children or []
        self.mainAxisAlignment = mainAxisAlignment
        self.crossAxisAlignment = crossAxisAlignment
        self.spacing = spacing

    @override
    def _flut_pack(self) -> dict:
        result = {
            **self._flut_base_props(),
            "children": [c._flut_pack() for c in self.children],
        }
        if self.mainAxisAlignment is not None:
            result["mainAxisAlignment"] = self.mainAxisAlignment._flut_pack()
        if self.crossAxisAlignment is not None:
            result["crossAxisAlignment"] = self.crossAxisAlignment._flut_pack()
        if self.spacing is not None:
            result["spacing"] = self.spacing
        return result


class Stack(Widget):
    def __init__(self, *, key=None, children: Optional[List[Widget]] = None):
        super().__init__("Stack", key=key)
        self.children = children or []

    @override
    def _flut_pack(self) -> dict:
        return {
            **self._flut_base_props(),
            "children": [c._flut_pack() for c in self.children],
        }


class Positioned(Widget):
    def __init__(
        self,
        *,
        key=None,
        child: Optional[Widget] = None,
        left: Optional[float] = None,
        top: Optional[float] = None,
        right: Optional[float] = None,
        bottom: Optional[float] = None,
        width: Optional[float] = None,
        height: Optional[float] = None,
    ):
        super().__init__("Positioned", key=key)
        self.child = child
        self.left = left
        self.top = top
        self.right = right
        self.bottom = bottom
        self.width = width
        self.height = height

    @override
    def _flut_pack(self) -> dict:
        result = {**self._flut_base_props()}
        if self.left is not None:
            result["left"] = self.left
        if self.top is not None:
            result["top"] = self.top
        if self.right is not None:
            result["right"] = self.right
        if self.bottom is not None:
            result["bottom"] = self.bottom
        if self.width is not None:
            result["width"] = self.width
        if self.height is not None:
            result["height"] = self.height
        if self.child is not None:
            result["child"] = self.child._flut_pack()
        return result


class MouseRegion(Widget):

    def __init__(
        self,
        *,
        key=None,
        child: Optional[Widget] = None,
        cursor=None,
        onEnter=None,
        onExit=None,
    ):
        super().__init__("MouseRegion", key=key)
        self.child = child
        self.cursor = cursor
        self.onEnter = onEnter
        self.onExit = onExit

    @override
    def _flut_pack(self) -> dict:
        engine = get_engine()
        result = {**self._flut_base_props()}
        if self.cursor is not None:
            result["cursor"] = self.cursor._flut_pack()
        if self.onEnter is not None:
            result["onEnterId"] = engine.register_action(self.onEnter)
        if self.onExit is not None:
            result["onExitId"] = engine.register_action(self.onExit)
        if self.child is not None:
            result["child"] = self.child._flut_pack()
        return result


class Padding(Widget):
    def __init__(self, *, key=None, padding=None, child: Optional[Widget] = None):
        super().__init__("Padding", key=key)
        self.padding = padding
        self.child = child

    @override
    def _flut_pack(self) -> dict:
        result = {**self._flut_base_props()}
        if self.padding is not None:
            result["padding"] = self.padding._flut_pack()
        if self.child is not None:
            result["child"] = self.child._flut_pack()
        return result


class Align(Widget):
    def __init__(self, *, key=None, alignment=None, child: Optional[Widget] = None):
        super().__init__("Align", key=key)
        self.alignment = alignment
        self.child = child

    @override
    def _flut_pack(self) -> dict:
        result = {**self._flut_base_props()}
        if self.alignment is not None:
            result["alignment"] = self.alignment._flut_pack()
        if self.child is not None:
            result["child"] = self.child._flut_pack()
        return result


class Opacity(Widget):
    def __init__(
        self,
        *,
        key=None,
        opacity: Optional[float] = None,
        child: Optional[Widget] = None,
    ):
        super().__init__("Opacity", key=key)
        self.opacity = opacity
        self.child = child

    @override
    def _flut_pack(self) -> dict:
        result = {**self._flut_base_props()}
        if self.opacity is not None:
            result["opacity"] = self.opacity
        if self.child is not None:
            result["child"] = self.child._flut_pack()
        return result


class ClipRRect(Widget):
    def __init__(self, *, key=None, borderRadius=None, child: Optional[Widget] = None):
        super().__init__("ClipRRect", key=key)
        self.borderRadius = borderRadius
        self.child = child

    @override
    def _flut_pack(self) -> dict:
        result = {**self._flut_base_props()}
        if self.borderRadius is not None:
            result["borderRadius"] = self.borderRadius._flut_pack()
        if self.child is not None:
            result["child"] = self.child._flut_pack()
        return result


class Spacer(Widget):
    def __init__(self, *, key=None, flex: Optional[int] = None):
        super().__init__("Spacer", key=key)
        self.flex = flex

    @override
    def _flut_pack(self) -> dict:
        result = {**self._flut_base_props()}
        if self.flex is not None:
            result["flex"] = self.flex
        return result


# =============================================================================
# CustomPaint
# =============================================================================


class CustomPainter:
    def __init__(self):
        self.commands = []

    def drawLine(self, p1, p2, paint):
        self.commands.append(
            {"cmd": "drawLine", "p1": p1, "p2": p2, "paint": paint._flut_pack()}
        )

    def drawCircle(self, c, radius, paint):
        self.commands.append(
            {"cmd": "drawCircle", "c": c, "radius": radius, "paint": paint._flut_pack()}
        )

    def drawRect(self, rect, paint):
        self.commands.append({"cmd": "drawRect", "rect": rect, "paint": paint._flut_pack()})

    @override
    def _flut_pack(self) -> dict:
        return {"commands": self.commands}


class CustomPaint(Widget):
    def __init__(
        self,
        *,
        key=None,
        painter: Optional[CustomPainter] = None,
        child: Optional[Widget] = None,
        size=None,
    ):
        super().__init__("CustomPaint", key=key)
        self.child = child
        self.painter = painter
        self.size = size

    @override
    def _flut_pack(self) -> dict:
        result = {**self._flut_base_props()}
        if self.painter is not None:
            result["painter"] = self.painter._flut_pack()
        if self.child is not None:
            result["child"] = self.child._flut_pack()
        if self.size is not None:
            result["size"] = [self.size[0], self.size[1]]
        return result
