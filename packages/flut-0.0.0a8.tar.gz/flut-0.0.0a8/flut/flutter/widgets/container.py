from typing import Optional, override

from .framework import Widget


class Container(Widget):
    def __init__(
        self,
        *,
        key=None,
        child: Optional[Widget] = None,
        padding=None,
        margin=None,
        color=None,
        width: Optional[float] = None,
        height: Optional[float] = None,
        decoration=None,
        alignment=None,
    ):
        super().__init__("Container", key=key)
        self.child = child
        self.padding = padding
        self.margin = margin
        self.color = color
        self.width = width
        self.height = height
        self.decoration = decoration
        self.alignment = alignment

    @override
    def _flut_pack(self) -> dict:
        result = {**self._flut_base_props()}
        if self.child is not None:
            result["child"] = self.child._flut_pack()
        if self.padding is not None:
            result["padding"] = self.padding._flut_pack()
        if self.margin is not None:
            result["margin"] = self.margin._flut_pack()
        if self.color is not None:
            result["color"] = self.color
        if self.width is not None:
            result["width"] = self.width
        if self.height is not None:
            result["height"] = self.height
        if self.decoration is not None:
            result["decoration"] = self.decoration._flut_pack()
        if self.alignment is not None:
            result["alignment"] = self.alignment._flut_pack()
        return result
