from typing import override
from flut._flut.engine import FlutRealtimeObject, get_engine


class TextEditingController(FlutRealtimeObject):

    def __init__(self, text=""):
        super().__init__("TextEditingController")
        self._flut_text = text

    @property
    def text(self):
        engine = get_engine()
        if engine:
            result = engine.call_dart(
                "get", {"oid": self._flut_oid, "property": "text"}
            )
            if result is not None and "value" in result:
                return result["value"]
        return self._flut_text

    @text.setter
    def text(self, value):
        engine = get_engine()
        if engine:
            engine.call_dart(
                "set", {"oid": self._flut_oid, "property": "text", "value": value}
            )
        self._flut_text = value

    def clear(self):
        self.text = ""

    def buildTextSpan(self, text):
        raise NotImplementedError()

    def _handle_build_text_span(self):
        result = self.buildTextSpan(self.text)
        if result is not None:
            return {"textSpan": result._flut_pack()}
        return {"textSpan": None}

    def _has_build_text_span_override(self):
        return type(self).buildTextSpan is not TextEditingController.buildTextSpan

    @override
    def _flut_pack(self) -> dict:
        engine = get_engine()
        build_text_span_id = None
        if self._has_build_text_span_override() and engine:
            build_text_span_id = engine.register_action(self._handle_build_text_span)
        return {
            **self._flut_base_props(),
            "text": self._flut_text,
            "buildTextSpanId": build_text_span_id,
        }
