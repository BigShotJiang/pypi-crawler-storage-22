from enum import Enum
from typing import override

from flut._flut.engine import FlutRealtimeObject, get_engine


class KeyEventResult(Enum):
    handled = "handled"
    ignored = "ignored"
    skipRemainingHandlers = "skipRemainingHandlers"


class FocusNode(FlutRealtimeObject):

    def __init__(self, onKeyEvent=None):
        super().__init__("FocusNode")
        self.onKeyEvent = onKeyEvent

    def _register(self):
        pass

    def _handle_key_event(self, key_data):
        from flut.flutter.services.hardware_keyboard import (
            createKeyEventFromData,
            HardwareKeyboard,
        )

        key_event = createKeyEventFromData(key_data)
        HardwareKeyboard.instance()._updateKeyState(key_event)

        if self.onKeyEvent:
            result = self.onKeyEvent(key_event)
            if result is None:
                return KeyEventResult.ignored
            return result
        return KeyEventResult.ignored

    @override
    def _flut_pack(self) -> dict:
        on_key_event_id = None
        if self.onKeyEvent:
            on_key_event_id = get_engine().register_action(self._handle_key_event)
        return {
            **self._flut_base_props(),
            "onKeyEventId": on_key_event_id,
        }
