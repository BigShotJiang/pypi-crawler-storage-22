from typing import Optional, override

from flut._flut.engine import get_engine
from .framework import Widget


class GestureDetector(Widget):
    def __init__(
        self,
        *,
        key=None,
        child: Optional[Widget] = None,
        onTap=None,
        onPanStart=None,
        onPanUpdate=None,
        onPanEnd=None,
    ):
        super().__init__("GestureDetector", key=key)
        self.child = child
        self.onTap = onTap
        self.onPanStart = onPanStart
        self.onPanUpdate = onPanUpdate
        self.onPanEnd = onPanEnd

    @override
    def _flut_pack(self) -> dict:
        engine = get_engine()
        result = {**self._flut_base_props()}
        if self.onTap is not None:
            result["onTapId"] = engine.register_action(self.onTap)
        if self.onPanStart is not None:
            result["onPanStartId"] = engine.register_action(self.onPanStart)
        if self.onPanUpdate is not None:
            result["onPanUpdateId"] = engine.register_action(self.onPanUpdate)
        if self.onPanEnd is not None:
            result["onPanEndId"] = engine.register_action(self.onPanEnd)
        if self.child is not None:
            result["child"] = self.child._flut_pack()
        return result
