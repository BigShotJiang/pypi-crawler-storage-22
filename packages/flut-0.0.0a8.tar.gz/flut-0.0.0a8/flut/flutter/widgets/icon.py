from typing import Optional, override

from .framework import Widget
from .icon_data import IconData


class Icon(Widget):

    def __init__(
        self,
        icon: Optional[IconData] = None,
        *,
        key=None,
        color=None,
        size: Optional[float] = None,
    ):
        super().__init__("Icon", key=key)
        self.icon = icon
        self.color = color
        self.size = size

    @override
    def _flut_pack(self) -> dict:
        result = {**self._flut_base_props()}
        if self.icon is not None:
            result["icon"] = self.icon._flut_pack()
        if self.color is not None:
            result["color"] = self.color
        if self.size is not None:
            result["size"] = self.size
        return result
