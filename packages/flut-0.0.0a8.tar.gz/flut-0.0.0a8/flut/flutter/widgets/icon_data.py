from typing import Optional, override
from flut._flut.engine import FlutObject


class IconData(FlutObject):

    def __init__(
        self,
        codePoint: int,
        *,
        fontFamily: Optional[str] = None,
        fontPackage: Optional[str] = None,
        matchTextDirection: Optional[bool] = None,
    ):
        super().__init__("IconData")
        self.codePoint = codePoint
        self.fontFamily = fontFamily
        self.fontPackage = fontPackage
        self.matchTextDirection = matchTextDirection

    @override
    def _flut_pack(self) -> dict:
        result = {
            **self._flut_base_props(),
            "codePoint": self.codePoint,
        }
        if self.fontFamily is not None:
            result["fontFamily"] = self.fontFamily
        if self.fontPackage is not None:
            result["fontPackage"] = self.fontPackage
        if self.matchTextDirection is not None:
            result["matchTextDirection"] = self.matchTextDirection
        return result
