from typing import Optional, override

from .framework import Widget


class AnimatedOpacity(Widget):
    def __init__(
        self,
        *,
        key=None,
        opacity: Optional[float] = None,
        duration: Optional[int] = None,
        child: Optional[Widget] = None,
    ):
        super().__init__("AnimatedOpacity", key=key)
        self.opacity = opacity
        self.duration = duration
        self.child = child

    @override
    def _flut_pack(self) -> dict:
        result = {**self._flut_base_props()}
        if self.opacity is not None:
            result["opacity"] = self.opacity
        if self.duration is not None:
            result["duration"] = self.duration
        if self.child is not None:
            result["child"] = self.child._flut_pack()
        return result
