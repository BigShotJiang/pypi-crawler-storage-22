from flut._flut.engine import get_engine
from flut.dart.ui import Size
from flut.flutter.painting import EdgeInsets


class MediaQueryData:

    def __init__(
        self,
        size: Size = None,
        padding: EdgeInsets = None,
        viewInsets: EdgeInsets = None,
        viewPadding: EdgeInsets = None,
        devicePixelRatio: float = 1.0,
    ):
        self.size = size or Size(0, 0)
        self.padding = padding or EdgeInsets(0, 0, 0, 0)
        self.viewInsets = viewInsets or EdgeInsets(0, 0, 0, 0)
        self.viewPadding = viewPadding or EdgeInsets(0, 0, 0, 0)
        self.devicePixelRatio = devicePixelRatio


def _parse_size(data: dict) -> Size:
    return Size(
        width=data.get("width", 0),
        height=data.get("height", 0),
    )


def _parse_edge_insets(data: dict) -> EdgeInsets:
    return EdgeInsets(
        left=data.get("left", 0),
        top=data.get("top", 0),
        right=data.get("right", 0),
        bottom=data.get("bottom", 0),
    )


class MediaQuery:

    @staticmethod
    def of(context) -> MediaQueryData:
        engine = get_engine()
        if engine is None or context is None:
            return MediaQueryData()

        result = engine.call_dart("static", {
            "name": "MediaQuery.of",
            "args": [{"oid": context._flut_oid}],
        })

        if result and "value" in result:
            data = result["value"]
            return MediaQueryData(
                size=_parse_size(data.get("size", {})),
                padding=_parse_edge_insets(data.get("padding", {})),
                viewInsets=_parse_edge_insets(data.get("viewInsets", {})),
                viewPadding=_parse_edge_insets(data.get("viewPadding", {})),
                devicePixelRatio=data.get("devicePixelRatio", 1.0),
            )

        return MediaQueryData()

        return MediaQueryData()
