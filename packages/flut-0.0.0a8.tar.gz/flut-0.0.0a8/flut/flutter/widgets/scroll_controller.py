from typing import override
from flut._flut.engine import FlutRealtimeObject, get_engine
from flut.dart import Duration


class ScrollPosition(FlutRealtimeObject):

    def __init__(self, oid: int):
        super().__init__("ScrollPosition", oid=oid)

    def _get(self, property: str):
        engine = get_engine()
        if engine:
            result = engine.call_dart(
                "get", {"oid": self._flut_oid, "property": property}
            )
            if result and "value" in result:
                return result["value"]
        return None

    def _call(self, method: str, **args):
        engine = get_engine()
        if engine:
            result = engine.call_dart(
                "call", {"oid": self._flut_oid, "method": method, "args": args}
            )
            if result and "value" in result:
                return result["value"]
        return None

    @property
    def pixels(self) -> float:
        return self._get("pixels") or 0.0

    @property
    def minScrollExtent(self) -> float:
        return self._get("minScrollExtent") or 0.0

    @property
    def maxScrollExtent(self) -> float:
        return self._get("maxScrollExtent") or 0.0

    @property
    def viewportDimension(self) -> float:
        return self._get("viewportDimension") or 0.0

    @property
    def hasContentDimensions(self) -> bool:
        return self._get("hasContentDimensions") or False

    @property
    def hasPixels(self) -> bool:
        return self._get("hasPixels") or False

    @property
    def atEdge(self) -> bool:
        return self._get("atEdge") or False

    def jumpTo(self, offset: float):
        return self._call("jumpTo", offset=offset)

    def animateTo(self, offset: float, duration: Duration):
        return self._call("animateTo", offset=offset, duration=duration._flut_pack())


class ScrollController(FlutRealtimeObject):

    def __init__(self, initialScrollOffset: float = 0.0):
        super().__init__("ScrollController")
        self._flut_initialScrollOffset = initialScrollOffset
        self._position: ScrollPosition | None = None

    def _get(self, property: str):
        engine = get_engine()
        if engine:
            result = engine.call_dart(
                "get", {"oid": self._flut_oid, "property": property}
            )
            if result and "value" in result:
                return result["value"]
        return None

    def _call(self, method: str, **args):
        engine = get_engine()
        if engine:
            result = engine.call_dart(
                "call", {"oid": self._flut_oid, "method": method, "args": args}
            )
            if result and "value" in result:
                return result["value"]
        return None

    @property
    def offset(self) -> float:
        return self._get("offset") or 0.0

    @property
    def hasClients(self) -> bool:
        return self._get("hasClients") or False

    @property
    def position(self) -> ScrollPosition | None:
        pos_data = self._get("position")
        if pos_data is None or "_flut_oid" not in pos_data:
            self._position = None
            return None

        current_oid = pos_data["_flut_oid"]

        if self._position is not None and self._position._flut_oid == current_oid:
            return self._position

        self._position = ScrollPosition(current_oid)
        return self._position

    def releasePosition(self):
        self._position = None

    def jumpTo(self, offset: float):
        return self._call("jumpTo", offset=offset)

    def animateTo(self, offset: float, duration: Duration):
        return self._call("animateTo", offset=offset, duration=duration._flut_pack())

    @override
    def _flut_pack(self) -> dict:
        return {
            **self._flut_base_props(),
            "initialScrollOffset": self._flut_initialScrollOffset,
        }
