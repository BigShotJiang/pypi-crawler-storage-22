from typing import List, Optional, override

from .framework import Widget


class ListView(Widget):
    def __init__(
        self,
        *,
        key=None,
        children: Optional[List[Widget]] = None,
        controller=None,
        padding=None,
        reverse: Optional[bool] = None,
        cacheExtent: Optional[float] = None,
    ):
        super().__init__("ListView", key=key)
        self.children = children or []
        self.controller = controller
        self.padding = padding
        self.reverse = reverse
        self.cacheExtent = cacheExtent

    @override
    def _flut_pack(self) -> dict:
        result = {
            **self._flut_base_props(),
            "children": [c._flut_pack() for c in self.children],
        }
        if self.controller is not None:
            result["controller"] = self.controller._flut_pack()
        if self.padding is not None:
            result["padding"] = self.padding._flut_pack()
        if self.reverse is not None:
            result["reverse"] = self.reverse
        if self.cacheExtent is not None:
            result["cacheExtent"] = self.cacheExtent
        return result
