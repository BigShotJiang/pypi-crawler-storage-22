from typing import Optional, override

from .framework import Widget


class SingleChildScrollView(Widget):
    def __init__(
        self,
        *,
        key=None,
        child: Optional[Widget] = None,
        controller=None,
        padding=None,
        scrollDirection=None,
    ):
        super().__init__("SingleChildScrollView", key=key)
        self.child = child
        self.controller = controller
        self.padding = padding
        self.scrollDirection = scrollDirection

    @override
    def _flut_pack(self) -> dict:
        result = {**self._flut_base_props()}
        if self.controller is not None:
            result["controller"] = self.controller._flut_pack()
        if self.padding is not None:
            result["padding"] = self.padding._flut_pack()
        if self.scrollDirection is not None:
            result["scrollDirection"] = self.scrollDirection
        if self.child is not None:
            result["child"] = self.child._flut_pack()
        return result
