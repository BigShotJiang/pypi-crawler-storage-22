from typing import Optional, override

from .framework import Widget
from ..painting.text_style import TextStyle


class Text(Widget):
    def __init__(
        self,
        data: str,
        *,
        key=None,
        style: Optional[TextStyle] = None,
        maxLines: Optional[int] = None,
        overflow: Optional[str] = None,
    ):
        super().__init__("Text", key=key)
        self.data = data
        self.style = style
        self.maxLines = maxLines
        self.overflow = overflow

    @override
    def _flut_pack(self) -> dict:
        result = {
            **self._flut_base_props(),
            "data": str(self.data) if self.data is not None else None,
        }
        if self.style is not None:
            result["style"] = self.style._flut_pack()
        if self.maxLines is not None:
            result["maxLines"] = self.maxLines
        if self.overflow is not None:
            result["overflow"] = self.overflow
        return result
