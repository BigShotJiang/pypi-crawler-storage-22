from typing import Optional, override

from .framework import Widget


class Visibility(Widget):
    def __init__(
        self,
        *,
        key=None,
        visible: Optional[bool] = None,
        child: Optional[Widget] = None,
    ):
        super().__init__("Visibility", key=key)
        self.visible = visible
        self.child = child

    @override
    def _flut_pack(self) -> dict:
        result = {**self._flut_base_props()}
        if self.visible is not None:
            result["visible"] = self.visible
        if self.child is not None:
            result["child"] = self.child._flut_pack()
        return result
