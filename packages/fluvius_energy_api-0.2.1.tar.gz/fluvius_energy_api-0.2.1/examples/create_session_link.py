#!/usr/bin/env python3
"""Create a client session link for consumption data."""

from datetime import datetime

from fluvius_energy_api import (
    ClientSessionDataService,
    ConfigurationError,
    DataServiceType,
    Environment,
    FluviusAPIError,
    FluviusCredentials,
    FluviusEnergyClient,
)


def main() -> None:
    """Create a client session for consumption data."""
    print("Creating client session for Consumption Data")
    print("=" * 60)

    try:
        # Load credentials from default FLUVIUS_ prefix (production)
        credentials = FluviusCredentials.from_env()
        print(f"Contract number: {credentials.data_access_contract_number}")

        with FluviusEnergyClient(
            credentials=credentials,
            environment=Environment.PRODUCTION,
        ) as client:
            response = client.create_client_session(
                data_access_contract_number=credentials.data_access_contract_number,
                reference_number=f"vh-test-{datetime.now().strftime('%Y%m%d%H%M%S')}",
                flow="B2C",
                data_services=[
                    # VH_ONBEPAALD = undefined granularity (covers both daily and quarter-hourly)
                    ClientSessionDataService(
                        data_service_type=DataServiceType.VH_ONBEPAALD,
                    ),
                ],
                number_of_eans=1,
            )

            print(f"\nStatus: {response.data.status}")
            if response.data.short_url_identifier:
                print(f"\nSession URL:")
                print(f"  https://mijn.fluvius.be/verbruik/dienstverlener?id={response.data.short_url_identifier}")
            if response.data.valid_to:
                print(f"\nValid until: {response.data.valid_to}")

    except ConfigurationError as e:
        print(f"\nConfiguration error: {e}")

    except FluviusAPIError as e:
        print(f"\nAPI error: {e}")
        if hasattr(e, "validation_errors") and e.validation_errors:
            for err in e.validation_errors:
                print(f"  - {err}")


if __name__ == "__main__":
    main()
