#!/usr/bin/env python3
"""Sample script demonstrating usage of the Fluvius Energy API client.

Before running this script, set the required environment variables:
    export FLUVIUS_SUBSCRIPTION_KEY="your-subscription-key"
    export FLUVIUS_CLIENT_ID="your-client-id"
    export FLUVIUS_TENANT_ID="your-tenant-id"
    export FLUVIUS_SCOPE="api://your-scope/.default"
    export FLUVIUS_CERTIFICATE_THUMBPRINT="your-thumbprint"
    export FLUVIUS_PRIVATE_KEY="-----BEGIN RSA PRIVATE KEY-----..."

Or use a .env file with python-dotenv.
"""

from datetime import datetime

from fluvius_energy_api import (
    ClientSessionDataService,
    ConfigurationError,
    DataServiceType,
    Environment,
    FluviusAPIError,
    FluviusCredentials,
    FluviusEnergyClient,
    MandateStatus,
    PeriodType,
)


def demo_get_mandates(client: FluviusEnergyClient) -> None:
    """Demonstrate fetching mandates."""
    print("\n" + "=" * 60)
    print("FETCHING MANDATES")
    print("=" * 60)

    # Get all mandates
    response = client.get_mandates()
    print(f"\nFound {len(response.data.mandates)} mandate(s)")

    for mandate in response.data.mandates:
        print(f"\n  EAN: {mandate.ean}")
        print(f"  Reference: {mandate.reference_number}")
        print(f"  Status: {mandate.status}")
        print(f"  Energy type: {mandate.energy_type}")
        print(f"  Data service: {mandate.data_service_type}")
        if mandate.data_period_from:
            print(f"  Data period from: {mandate.data_period_from}")
        if mandate.data_period_to:
            print(f"  Data period to: {mandate.data_period_to}")

    # Get filtered mandates (example)
    # Note: Some filter combinations may not be supported by the API
    print("\n--- Filtering for approved mandates ---")
    try:
        response = client.get_mandates(status=MandateStatus.APPROVED)
        print(f"Found {len(response.data.mandates)} approved mandate(s)")
    except FluviusAPIError as e:
        print(f"Filter not supported: {e}")


def _print_daily_energy(daily_energy: list, label: str = "") -> None:
    """Print daily energy measurements."""
    if not daily_energy:
        return

    prefix = f"  {label}" if label else "  "
    print(f"\n{prefix}Daily measurements ({len(daily_energy)} days):")

    for entry in daily_energy[:5]:  # Show first 5 days
        print(f"\n    Period: {entry.start} to {entry.end}")
        if entry.measurements:
            for measurement in entry.measurements:
                if hasattr(measurement, "offtake") and measurement.offtake:
                    if hasattr(measurement.offtake, "day") and measurement.offtake.day:
                        print(f"      Offtake (day): {measurement.offtake.day.value} {measurement.offtake.day.unit}")
                    if hasattr(measurement.offtake, "night") and measurement.offtake.night:
                        print(f"      Offtake (night): {measurement.offtake.night.value} {measurement.offtake.night.unit}")
                if hasattr(measurement, "injection") and measurement.injection:
                    if hasattr(measurement.injection, "day") and measurement.injection.day:
                        print(f"      Injection (day): {measurement.injection.day.value} {measurement.injection.day.unit}")
                    if hasattr(measurement.injection, "night") and measurement.injection.night:
                        print(f"      Injection (night): {measurement.injection.night.value} {measurement.injection.night.unit}")


def demo_get_energy(client: FluviusEnergyClient, ean: str) -> None:
    """Demonstrate fetching daily energy data with actual measurements."""
    print("\n" + "=" * 60)
    print(f"FETCHING DAILY ENERGY DATA FOR EAN: {ean}")
    print("=" * 60)

    try:
        response = client.get_energy(
            ean=ean,
            period_type=PeriodType.READ_TIME,
            granularity="daily",
            from_date=datetime(2024, 1, 1),
            to_date=datetime(2024, 1, 10),
        )

        headpoint = response.data.headpoint
        print(f"\n  EAN: {headpoint.ean}")
        print(f"  Energy type: {headpoint.energy_type}")
        print(f"  Meter type: {headpoint.type_discriminator}")

        # Handle metering-on-meter (data is per physical meter)
        if headpoint.type_discriminator == "metering-on-meter":
            if hasattr(headpoint, "physical_meters") and headpoint.physical_meters:
                for meter in headpoint.physical_meters:
                    print(f"\n  Meter ID: {meter.meter_id}")
                    if hasattr(meter, "daily_energy") and meter.daily_energy:
                        _print_daily_energy(meter.daily_energy)
            else:
                print("\n  No physical meters found")

        # Handle metering-on-headpoint (data is directly on headpoint)
        elif headpoint.type_discriminator == "metering-on-headpoint":
            if hasattr(headpoint, "daily_energy") and headpoint.daily_energy:
                _print_daily_energy(headpoint.daily_energy)
            else:
                print("\n  No daily energy data found")

        # Handle metering-on-headpoint-and-meter (both levels)
        elif headpoint.type_discriminator == "metering-on-headpoint-and-meter":
            if hasattr(headpoint, "daily_energy") and headpoint.daily_energy:
                print("\n  Headpoint level:")
                _print_daily_energy(headpoint.daily_energy)
            if hasattr(headpoint, "physical_meters") and headpoint.physical_meters:
                for meter in headpoint.physical_meters:
                    print(f"\n  Meter ID: {meter.meter_id}")
                    if hasattr(meter, "daily_energy") and meter.daily_energy:
                        _print_daily_energy(meter.daily_energy)

    except FluviusAPIError as e:
        print(f"\n  Error fetching energy data: {e}")
        if hasattr(e, "validation_errors") and e.validation_errors:
            for err in e.validation_errors:
                print(f"    - {err}")


def demo_create_session(client: FluviusEnergyClient, contract_number: str) -> None:
    """Demonstrate creating a client session."""
    print("\n" + "=" * 60)
    print("CREATING CLIENT SESSION")
    print("=" * 60)

    response = client.create_client_session(
        data_access_contract_number=contract_number,
        reference_number=f"demo-{datetime.now().strftime('%Y%m%d%H%M%S')}",
        flow="B2B",
        data_services=[
            ClientSessionDataService(
                data_service_type=DataServiceType.VH_DAG,
                data_period_from="2024-01-01T00:00:00Z",
            ),
        ],
        number_of_eans=1,
    )

    print(f"\n  Status: {response.data.status}")
    if response.data.short_url_identifier:
        print(f"  URL Identifier: {response.data.short_url_identifier}")
    if response.data.valid_to:
        print(f"  Valid until: {response.data.valid_to}")


def main() -> None:
    """Run the demo."""
    print("Fluvius Energy API - Sample Script")
    print("===================================")

    try:
        # Load credentials from environment
        credentials = FluviusCredentials.from_env()

        print(f"\nData access contract number: {credentials.data_access_contract_number}")

        # Use production environment (change to SANDBOX for testing)
        with FluviusEnergyClient(credentials=credentials, environment=Environment.PRODUCTION) as client:
            # Demo: Get mandates
            demo_get_mandates(client)

            # Demo: Get energy data for the first approved mandate
            response = client.get_mandates(status=MandateStatus.APPROVED)
            approved_mandates = response.data.mandates
            if approved_mandates:
                first_mandate = approved_mandates[0]
                demo_get_energy(client, first_mandate.ean)
            else:
                print("\n" + "=" * 60)
                print("No approved mandates found - skipping energy data demo")
                print("=" * 60)

            # Demo: Create a client session
            demo_create_session(client, credentials.data_access_contract_number)

    except ConfigurationError as e:
        print(f"\nConfiguration error: {e}")
        print("\nMake sure all required environment variables are set:")
        print("  - FLUVIUS_SUBSCRIPTION_KEY")
        print("  - FLUVIUS_CLIENT_ID")
        print("  - FLUVIUS_TENANT_ID")
        print("  - FLUVIUS_SCOPE")
        print("  - FLUVIUS_DATA_ACCESS_CONTRACT_NUMBER")
        print("  - FLUVIUS_CERTIFICATE_THUMBPRINT")
        print("  - FLUVIUS_PRIVATE_KEY (or FLUVIUS_PRIVATE_KEY_PATH)")

    except FluviusAPIError as e:
        print(f"\nAPI error: {e}")
        if hasattr(e, "error_response") and e.error_response:
            print(f"  Type: {e.error_response.type}")
            print(f"  Code: {e.error_response.code}")
        if hasattr(e, "validation_errors") and e.validation_errors:
            print("  Validation errors:")
            for err in e.validation_errors:
                print(f"    - {err}")


if __name__ == "__main__":
    main()
