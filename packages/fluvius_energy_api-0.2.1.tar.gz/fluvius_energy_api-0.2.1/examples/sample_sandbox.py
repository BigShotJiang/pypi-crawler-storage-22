#!/usr/bin/env python3
"""Sample script demonstrating all operations with the sandbox environment.

Sandbox uses client secret authentication (simpler than certificate-based).
Common values like subscription_key, client_id, tenant_id, scope are shared
with production and will fall back to FLUVIUS_* if not set with FLUVIUS_SANDBOX_*.

Required environment variables:
    # Common (shared with production, set once with FLUVIUS_* prefix)
    export FLUVIUS_SUBSCRIPTION_KEY="your-subscription-key"
    export FLUVIUS_CLIENT_ID="your-client-id"
    export FLUVIUS_TENANT_ID="your-tenant-id"
    export FLUVIUS_SCOPE="api://your-scope/.default"
    export FLUVIUS_DATA_ACCESS_CONTRACT_NUMBER="your-contract-number"

    # Sandbox-specific (client secret instead of certificate)
    export FLUVIUS_SANDBOX_CLIENT_SECRET="your-sandbox-client-secret"
"""

from datetime import datetime

from fluvius_energy_api import (
    ClientSessionDataService,
    ConfigurationError,
    DataServiceType,
    Environment,
    FluviusAPIError,
    FluviusCredentials,
    FluviusEnergyClient,
    MandateStatus,
    PeriodType,
)


def demo_get_mandates(client: FluviusEnergyClient) -> None:
    """Demonstrate fetching mandates."""
    print("\n" + "=" * 60)
    print("FETCHING MANDATES")
    print("=" * 60)

    response = client.get_mandates()
    print(f"\nFound {len(response.data.mandates)} mandate(s)")

    for mandate in response.data.mandates[:5]:  # Show first 5
        print(f"\n  EAN: {mandate.ean}")
        print(f"  Reference: {mandate.reference_number}")
        print(f"  Status: {mandate.status}")
        print(f"  Energy type: {mandate.energy_type}")
        print(f"  Data service: {mandate.data_service_type}")
        if mandate.data_period_from:
            print(f"  Data period: {mandate.data_period_from} to {mandate.data_period_to}")

    if len(response.data.mandates) > 5:
        print(f"\n  ... and {len(response.data.mandates) - 5} more")


def demo_get_energy(client: FluviusEnergyClient, ean: str) -> None:
    """Demonstrate fetching daily energy data with actual measurements."""
    print("\n" + "=" * 60)
    print(f"FETCHING DAILY ENERGY DATA FOR EAN: {ean}")
    print("=" * 60)

    try:
        response = client.get_energy(
            ean=ean,
            period_type=PeriodType.READ_TIME,
            granularity="daily",
            from_date=datetime(2024, 1, 1),
            to_date=datetime(2024, 1, 10),
        )

        headpoint = response.data.headpoint
        print(f"\n  EAN: {headpoint.ean}")
        print(f"  Energy type: {headpoint.energy_type}")
        print(f"  Meter type: {headpoint.type_discriminator}")

        # Show daily measurements if available
        if hasattr(headpoint, "daily_energy") and headpoint.daily_energy:
            print(f"\n  Daily measurements ({len(headpoint.daily_energy)} days):")
            for entry in headpoint.daily_energy[:5]:  # Show first 5 days
                print(f"\n    Period: {entry.start} to {entry.end}")
                if entry.measurements:
                    for measurement in entry.measurements:
                        if hasattr(measurement, "offtake") and measurement.offtake:
                            if hasattr(measurement.offtake, "day") and measurement.offtake.day:
                                print(f"      Offtake: {measurement.offtake.day.value} {measurement.offtake.day.unit}")
                        if hasattr(measurement, "injection") and measurement.injection:
                            if hasattr(measurement.injection, "day") and measurement.injection.day:
                                print(f"      Injection: {measurement.injection.day.value} {measurement.injection.day.unit}")

    except FluviusAPIError as e:
        print(f"\n  Error fetching energy data: {e}")
        if hasattr(e, "validation_errors") and e.validation_errors:
            for err in e.validation_errors:
                print(f"    - {err}")


def demo_create_mock_mandate(client: FluviusEnergyClient, ean: str) -> None:
    """Demonstrate creating a mock mandate (sandbox only)."""
    print("\n" + "=" * 60)
    print("CREATING MOCK MANDATE")
    print("=" * 60)

    try:
        reference = f"mock-daily-{datetime.now().strftime('%Y%m%d%H%M%S')}"
        response = client.create_mock_mandate(
            reference_number=reference,
            ean=ean,
            data_service_type=DataServiceType.VH_DAG,
            data_period_from="2024-01-01T00:00:00Z",
            data_period_to="2026-12-31T23:59:59Z",
            status=MandateStatus.APPROVED,
        )
        print(f"\n  Mandate created:")
        print(f"    EAN: {ean}")
        print(f"    Reference: {reference}")
        print(f"    Data service: VH_dag (daily)")
        print(f"    Status: {response.data.status}")

    except FluviusAPIError as e:
        print(f"\n  Error creating mandate: {e}")
        if hasattr(e, "validation_errors") and e.validation_errors:
            for err in e.validation_errors:
                print(f"    - {err}")


def demo_create_session(client: FluviusEnergyClient, contract_number: str) -> None:
    """Demonstrate creating a client session."""
    print("\n" + "=" * 60)
    print("CREATING CLIENT SESSION")
    print("=" * 60)

    try:
        response = client.create_client_session(
            data_access_contract_number=contract_number,
            reference_number=f"sandbox-demo-{datetime.now().strftime('%Y%m%d%H%M%S')}",
            flow="B2B",
            data_services=[
                ClientSessionDataService(
                    data_service_type=DataServiceType.VH_DAG,
                    data_period_from="2024-01-01T00:00:00Z",
                ),
            ],
            number_of_eans=1,
        )

        print(f"\n  Status: {response.data.status}")
        if response.data.short_url_identifier:
            print(f"  URL Identifier: {response.data.short_url_identifier}")
        if response.data.valid_to:
            print(f"  Valid until: {response.data.valid_to}")

    except FluviusAPIError as e:
        print(f"\n  Error creating session: {e}")
        if hasattr(e, "validation_errors") and e.validation_errors:
            for err in e.validation_errors:
                print(f"    - {err}")


def main() -> None:
    """Run the sandbox demo with all operations."""
    print("Fluvius Energy API - Sandbox Demo")
    print("=" * 60)

    # Sandbox test EAN - must match pattern: 5414[4-5][0-1][0-2][0-2][0-2]000000[0-9][0-9][0-9]
    TEST_EAN = "541450000000000001"

    try:
        # Load credentials with FLUVIUS_SANDBOX prefix
        sandbox_credentials = FluviusCredentials.from_env(prefix="FLUVIUS_SANDBOX")

        print(f"\nAuthentication: {'certificate' if sandbox_credentials.uses_certificate else 'client_secret'}")
        print(f"Contract number: {sandbox_credentials.data_access_contract_number}")

        with FluviusEnergyClient(
            credentials=sandbox_credentials,
            environment=Environment.SANDBOX,
        ) as client:
            print(f"Connected to: {Environment.SANDBOX.value}")

            # 1. Create a mock mandate (so we have data to work with)
            demo_create_mock_mandate(client, TEST_EAN)

            # 2. Get mandates
            demo_get_mandates(client)

            # 3. Get daily energy data
            demo_get_energy(client, TEST_EAN)

            # 4. Create client session
            demo_create_session(client, sandbox_credentials.data_access_contract_number)

            print("\n" + "=" * 60)
            print("SANDBOX DEMO COMPLETE")
            print("=" * 60)

    except ConfigurationError as e:
        print(f"\nConfiguration error: {e}")
        print("\nRequired environment variables:")
        print("  FLUVIUS_SUBSCRIPTION_KEY")
        print("  FLUVIUS_CLIENT_ID")
        print("  FLUVIUS_TENANT_ID")
        print("  FLUVIUS_SCOPE")
        print("  FLUVIUS_DATA_ACCESS_CONTRACT_NUMBER")
        print("  FLUVIUS_SANDBOX_CLIENT_SECRET")

    except FluviusAPIError as e:
        print(f"\nAPI error: {e}")
        if hasattr(e, "validation_errors") and e.validation_errors:
            for err in e.validation_errors:
                print(f"  - {err}")


if __name__ == "__main__":
    main()
