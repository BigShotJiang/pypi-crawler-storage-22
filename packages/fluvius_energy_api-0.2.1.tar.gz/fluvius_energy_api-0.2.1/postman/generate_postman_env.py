#!/usr/bin/env python3
"""Generate Postman environment files for the Fluvius Energy API.

Reads credentials from the .env file in the project root (falling back to
os.environ for each variable) and generates two Postman environment files:

- fluvius-sandbox.postman_environment.json  (client-secret auth)
- fluvius-production.postman_environment.json  (certificate / JWT auth)

The production environment includes an auto-generated RS256 client assertion
that is valid for 1 hour.

Usage:
    python postman/generate_postman_env.py
"""

from __future__ import annotations

import base64
import json
import os
import time
import uuid
from pathlib import Path

import jwt

POSTMAN_DIR = Path(__file__).resolve().parent
ENV_FILE = POSTMAN_DIR.parent / ".env"
TOKEN_LIFETIME_SECONDS = 3600

SANDBOX_BASE_URL = "https://apihub.fluvius.be/esco-sbx/v3"
PRODUCTION_BASE_URL = "https://apihub.fluvius.be/esco-live/v3"


# ---------------------------------------------------------------------------
# .env helpers
# ---------------------------------------------------------------------------

def _load_dotenv(path: Path) -> dict[str, str]:
    """Parse a .env file into a dict (ignores comments and blank lines)."""
    env: dict[str, str] = {}
    if not path.exists():
        return env
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, _, value = line.partition("=")
        env[key.strip()] = value.strip()
    return env


def _get_var(dotenv: dict[str, str], name: str, *fallback_names: str) -> str:
    """Return the value of *name* from dotenv / os.environ.

    Falls back to *fallback_names* in order if the primary key is missing.
    """
    for key in (name, *fallback_names):
        val = dotenv.get(key) or os.environ.get(key, "")
        if val:
            return val
    return ""


# ---------------------------------------------------------------------------
# JWT helpers (reused from auth.py / generate_assertion.py)
# ---------------------------------------------------------------------------

def _decode_private_key(key: str) -> str:
    if key.startswith("-----BEGIN"):
        return key
    cleaned = key.replace(" ", "").replace("\n", "").replace("\r", "")
    return base64.b64decode(cleaned, validate=True).decode("utf-8")


def _encode_thumbprint(thumbprint: str) -> str:
    return base64.urlsafe_b64encode(bytes.fromhex(thumbprint)).rstrip(b"=").decode("ascii")


def _create_client_assertion(
    tenant_id: str,
    client_id: str,
    thumbprint: str,
    private_key: str,
) -> str:
    now = int(time.time())
    headers = {
        "alg": "RS256",
        "typ": "JWT",
        "x5t": _encode_thumbprint(thumbprint),
    }
    payload = {
        "aud": f"https://login.microsoftonline.com/{tenant_id}/v2.0",
        "iss": client_id,
        "sub": client_id,
        "jti": str(uuid.uuid4()),
        "nbf": now,
        "exp": now + TOKEN_LIFETIME_SECONDS,
    }
    return jwt.encode(payload, private_key, algorithm="RS256", headers=headers)


# ---------------------------------------------------------------------------
# Environment file generation
# ---------------------------------------------------------------------------

def _make_env(env_id: str, name: str, values: list[tuple[str, str, str]]) -> dict:
    """Build a Postman environment dict.

    *values* is a list of (key, value, type) tuples.
    """
    return {
        "id": env_id,
        "name": name,
        "values": [
            {"key": k, "value": v, "type": t, "enabled": True}
            for k, v, t in values
        ],
        "_postman_variable_scope": "environment",
    }


def _write_env(path: Path, data: dict) -> None:
    path.write_text(json.dumps(data, indent="\t") + "\n")


def main() -> None:
    dotenv = _load_dotenv(ENV_FILE)

    tenant_id = _get_var(dotenv, "FLUVIUS_TENANT_ID")
    scope = _get_var(dotenv, "FLUVIUS_SCOPE")
    subscription_key = _get_var(dotenv, "FLUVIUS_SUBSCRIPTION_KEY")
    data_access_contract_number = _get_var(dotenv, "FLUVIUS_DATA_ACCESS_CONTRACT_NUMBER")

    # -- Sandbox --
    sandbox_client_id = _get_var(dotenv, "FLUVIUS_SANDBOX_CLIENT_ID", "FLUVIUS_CLIENT_ID")
    sandbox_client_secret = _get_var(dotenv, "FLUVIUS_SANDBOX_CLIENT_SECRET", "FLUVIUS_CLIENT_SECRET")

    sandbox = _make_env("fluvius-sandbox-env", "Fluvius Sandbox", [
        ("base_url", SANDBOX_BASE_URL, "default"),
        ("tenant_id", tenant_id, "default"),
        ("client_id", sandbox_client_id, "default"),
        ("client_secret", sandbox_client_secret, "secret"),
        ("scope", scope, "default"),
        ("subscription_key", subscription_key, "secret"),
        ("data_access_contract_number", data_access_contract_number, "default"),
        ("access_token", "", "secret"),
        ("token_expiry", "", "default"),
    ])

    sandbox_path = POSTMAN_DIR / "fluvius-sandbox.postman_environment.json"
    _write_env(sandbox_path, sandbox)

    # -- Production --
    prod_client_id = _get_var(dotenv, "FLUVIUS_CLIENT_ID")
    thumbprint = _get_var(dotenv, "FLUVIUS_CERTIFICATE_THUMBPRINT")
    private_key_raw = _get_var(dotenv, "FLUVIUS_PRIVATE_KEY")

    client_assertion = ""
    assertion_note = ""
    if prod_client_id and thumbprint and private_key_raw:
        private_key = _decode_private_key(private_key_raw)
        client_assertion = _create_client_assertion(
            tenant_id, prod_client_id, thumbprint, private_key,
        )
        assertion_note = f"(valid for {TOKEN_LIFETIME_SECONDS // 60} min)"
    else:
        assertion_note = "(skipped -- missing FLUVIUS_CLIENT_ID, FLUVIUS_CERTIFICATE_THUMBPRINT, or FLUVIUS_PRIVATE_KEY)"

    production = _make_env("fluvius-production-env", "Fluvius Production", [
        ("base_url", PRODUCTION_BASE_URL, "default"),
        ("tenant_id", tenant_id, "default"),
        ("client_id", prod_client_id, "default"),
        ("scope", scope, "default"),
        ("subscription_key", subscription_key, "secret"),
        ("data_access_contract_number", data_access_contract_number, "default"),
        ("client_assertion", client_assertion, "secret"),
        ("access_token", "", "secret"),
        ("token_expiry", "", "default"),
    ])

    production_path = POSTMAN_DIR / "fluvius-production.postman_environment.json"
    _write_env(production_path, production)

    # -- Summary --
    print("Generated Postman environment files:")
    print(f"  {sandbox_path.name}")
    print(f"  {production_path.name}")
    print()
    if client_assertion:
        print(f"client_assertion (valid for {TOKEN_LIFETIME_SECONDS // 60} min):")
        print(client_assertion)
    else:
        print(f"client_assertion {assertion_note}")


if __name__ == "__main__":
    main()
