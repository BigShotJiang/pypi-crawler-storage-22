"""Internal HTTP client wrapper for the Fluvius Energy API."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import httpx

from .exceptions import (
    AuthenticationError,
    FluviusAPIError,
    ForbiddenError,
    NotFoundError,
    ServerError,
    ServiceUnavailableError,
    ValidationError,
)
from .models.base import ErrorResponse, ErrorValidationResponse

if TYPE_CHECKING:
    from .auth import TokenProvider


class HTTPClient:
    """Internal HTTP client with authentication and error handling."""

    def __init__(
        self,
        base_url: str,
        token_provider: TokenProvider,
        timeout: float = 30.0,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._token_provider = token_provider
        self._timeout = timeout
        self._client: httpx.Client | None = None

    def _get_client(self) -> httpx.Client:
        """Get or create the HTTP client."""
        if self._client is None:
            self._client = httpx.Client(
                base_url=self._base_url,
                timeout=self._timeout,
            )
        return self._client

    def _get_headers(self) -> dict[str, str]:
        """Get headers for API requests, including fresh auth token."""
        headers = self._token_provider.get_authorization_headers()
        headers["Content-Type"] = "application/json"
        headers["Accept"] = "application/json"
        return headers

    def close(self) -> None:
        """Close the HTTP client."""
        if self._client is not None:
            self._client.close()
            self._client = None
        self._token_provider.close()

    def _handle_error_response(self, response: httpx.Response) -> None:
        """Handle error responses from the API."""
        error_response: ErrorResponse | ErrorValidationResponse | None = None

        try:
            error_data = response.json()
            # Check for validation errors (API returns PascalCase)
            if "validationErrorMessages" in error_data or "ValidationErrorMessages" in error_data:
                error_response = ErrorValidationResponse.model_validate(error_data)
            else:
                error_response = ErrorResponse.model_validate(error_data)
        except Exception:
            pass

        message = (
            error_response.message
            if error_response and error_response.message
            else response.text or f"HTTP {response.status_code}"
        )

        match response.status_code:
            case 400:
                raise ValidationError(
                    message=message,
                    error_response=error_response
                    if isinstance(error_response, ErrorValidationResponse)
                    else None,
                )
            case 401:
                raise AuthenticationError(message=message, error_response=error_response)
            case 403:
                raise ForbiddenError(message=message, error_response=error_response)
            case 404:
                raise NotFoundError(message=message, error_response=error_response)
            case 500:
                raise ServerError(message=message, error_response=error_response)
            case 503:
                raise ServiceUnavailableError(
                    message=message, error_response=error_response
                )
            case _:
                raise FluviusAPIError(
                    message=message,
                    status_code=response.status_code,
                    error_response=error_response,
                )

    def get(self, path: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
        """Make a GET request."""
        client = self._get_client()
        response = client.get(path, params=params, headers=self._get_headers())

        if not response.is_success:
            self._handle_error_response(response)

        return response.json()

    def post(
        self, path: str, json_data: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        """Make a POST request."""
        client = self._get_client()
        response = client.post(path, json=json_data, headers=self._get_headers())

        if not response.is_success:
            self._handle_error_response(response)

        return response.json()
