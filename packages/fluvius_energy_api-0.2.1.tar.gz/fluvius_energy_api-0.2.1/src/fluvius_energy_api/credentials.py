"""Credentials configuration for Fluvius API authentication."""

from __future__ import annotations

import base64
import os
from dataclasses import dataclass
from pathlib import Path

from .exceptions import ConfigurationError


@dataclass(frozen=True)
class FluviusCredentials:
    """OAuth2 credentials for Fluvius API authentication.

    Supports two authentication methods:
    1. Certificate-based (production): Uses certificate_thumbprint + private_key
    2. Client secret-based (sandbox): Uses client_secret

    Attributes:
        subscription_key: Azure API Management subscription key.
        client_id: Azure AD application (client) ID.
        tenant_id: Azure AD tenant ID.
        scope: OAuth2 scope for the Fluvius API.
        certificate_thumbprint: Hexadecimal thumbprint of the certificate (for certificate auth).
        private_key: RSA private key in PEM format (for certificate auth).
        client_secret: Client secret (for secret-based auth, typically sandbox).

    Example:
        ```python
        # Production with certificate
        prod_creds = FluviusCredentials(
            subscription_key="...",
            client_id="...",
            tenant_id="...",
            scope="...",
            certificate_thumbprint="...",
            private_key="-----BEGIN RSA PRIVATE KEY-----...",
        )

        # Sandbox with client secret
        sandbox_creds = FluviusCredentials(
            subscription_key="...",
            client_id="...",
            tenant_id="...",
            scope="...",
            client_secret="...",
        )
        ```
    """

    subscription_key: str
    client_id: str
    tenant_id: str
    scope: str
    data_access_contract_number: str
    # Certificate-based auth (production)
    certificate_thumbprint: str | None = None
    private_key: str | None = None
    # Client secret auth (sandbox)
    client_secret: str | None = None

    def __post_init__(self) -> None:
        """Validate that all required fields are non-empty."""
        # Decode private key if it's base64-encoded
        if self.private_key:
            decoded = _decode_private_key(self.private_key)
            if decoded != self.private_key:
                object.__setattr__(self, "private_key", decoded)

        # Always required
        for field_name in ["subscription_key", "client_id", "tenant_id", "scope", "data_access_contract_number"]:
            value = getattr(self, field_name)
            if not value or not value.strip():
                raise ConfigurationError(
                    f"Missing required credential: {field_name}"
                )

        # Must have either certificate-based or secret-based auth
        has_certificate = (
            self.certificate_thumbprint
            and self.certificate_thumbprint.strip()
            and self.private_key
            and self.private_key.strip()
        )
        has_secret = self.client_secret and self.client_secret.strip()

        if not has_certificate and not has_secret:
            raise ConfigurationError(
                "Missing authentication credentials: provide either "
                "(certificate_thumbprint + private_key) or client_secret"
            )

    @property
    def uses_certificate(self) -> bool:
        """Return True if using certificate-based authentication."""
        return bool(
            self.certificate_thumbprint
            and self.certificate_thumbprint.strip()
            and self.private_key
            and self.private_key.strip()
        )

    @classmethod
    def from_env(cls, prefix: str = "FLUVIUS") -> FluviusCredentials:
        """Load credentials from environment variables.

        Args:
            prefix: Environment variable prefix. Defaults to "FLUVIUS".
                Use "FLUVIUS_SANDBOX" for sandbox-specific credentials.
                Common values (subscription_key, client_id, tenant_id, scope)
                will fall back to FLUVIUS_* if not found with the prefix.

        Environment Variables:
            {PREFIX}_SUBSCRIPTION_KEY: Azure API Management subscription key.
            {PREFIX}_CLIENT_ID: Azure AD application (client) ID.
            {PREFIX}_TENANT_ID: Azure AD tenant ID.
            {PREFIX}_SCOPE: OAuth2 scope for the Fluvius API.

            For certificate auth (production):
            {PREFIX}_CERTIFICATE_THUMBPRINT: Hexadecimal certificate thumbprint.
            {PREFIX}_PRIVATE_KEY: RSA private key (PEM format or base64-encoded).
            {PREFIX}_PRIVATE_KEY_PATH: Path to private key file (alternative).

            For client secret auth (sandbox):
            {PREFIX}_CLIENT_SECRET: Client secret.

            Always required:
            {PREFIX}_DATA_ACCESS_CONTRACT_NUMBER: Data access contract number.

        Example:
            ```python
            # Production (certificate auth)
            prod_creds = FluviusCredentials.from_env()

            # Sandbox (client secret auth, falls back to FLUVIUS_* for common values)
            sandbox_creds = FluviusCredentials.from_env(prefix="FLUVIUS_SANDBOX")
            ```

        Returns:
            FluviusCredentials: The loaded credentials.

        Raises:
            ConfigurationError: If required environment variables are missing.
        """
        private_key = cls._load_private_key(prefix)

        # Helper to get env var with fallback to default prefix
        def get_env(name: str, fallback_prefix: str = "FLUVIUS") -> str:
            value = os.environ.get(f"{prefix}_{name}", "")
            if not value and prefix != fallback_prefix:
                value = os.environ.get(f"{fallback_prefix}_{name}", "")
            return value

        return cls(
            subscription_key=get_env("SUBSCRIPTION_KEY"),
            client_id=get_env("CLIENT_ID"),
            tenant_id=get_env("TENANT_ID"),
            scope=get_env("SCOPE"),
            certificate_thumbprint=get_env("CERTIFICATE_THUMBPRINT") or None,
            private_key=private_key or None,
            client_secret=get_env("CLIENT_SECRET") or None,
            data_access_contract_number=get_env("DATA_ACCESS_CONTRACT_NUMBER"),
        )

    @staticmethod
    def _load_private_key(prefix: str = "FLUVIUS") -> str:
        """Load the private key from environment variable or file.

        Args:
            prefix: Environment variable prefix.

        Returns:
            The private key in PEM format, or empty string if not found.
        """
        private_key = os.environ.get(f"{prefix}_PRIVATE_KEY")
        private_key_path = os.environ.get(f"{prefix}_PRIVATE_KEY_PATH")

        # Fall back to default prefix if using custom prefix
        if not private_key and not private_key_path and prefix != "FLUVIUS":
            private_key = os.environ.get("FLUVIUS_PRIVATE_KEY")
            private_key_path = os.environ.get("FLUVIUS_PRIVATE_KEY_PATH")

        if private_key:
            return _decode_private_key(private_key)

        if private_key_path:
            path = Path(private_key_path)
            if not path.exists():
                raise ConfigurationError(
                    f"Private key file not found: {private_key_path}"
                )
            try:
                return path.read_text()
            except OSError as e:
                raise ConfigurationError(
                    f"Failed to read private key file: {e}"
                ) from e

        return ""


def _decode_private_key(key: str) -> str:
    """Decode a private key that may be base64-encoded.

    Args:
        key: The private key, either in PEM format or base64-encoded.

    Returns:
        The private key in PEM format.
    """
    if key.startswith("-----BEGIN"):
        return key

    try:
        cleaned = key.replace(" ", "").replace("\n", "").replace("\r", "").replace("\t", "")
        decoded = base64.b64decode(cleaned, validate=True).decode("utf-8")
        return decoded
    except (ValueError, UnicodeDecodeError):
        return key
