"""Custom exceptions for the Fluvius Energy API."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .models.base import ErrorResponse, ErrorValidationResponse


class FluviusAPIError(Exception):
    """Base exception for Fluvius API errors."""

    def __init__(
        self,
        message: str,
        status_code: int | None = None,
        error_response: ErrorResponse | ErrorValidationResponse | None = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.error_response = error_response

    def __str__(self) -> str:
        if self.status_code:
            return f"[{self.status_code}] {self.message}"
        return self.message


class ConfigurationError(FluviusAPIError):
    """Raised when credentials or configuration is missing or invalid."""

    def __init__(self, message: str) -> None:
        super().__init__(message)


class AuthenticationError(FluviusAPIError):
    """Raised when authentication fails (401 Unauthorized)."""

    def __init__(
        self,
        message: str = "Authentication failed. Check your bearer token.",
        error_response: ErrorResponse | ErrorValidationResponse | None = None,
    ) -> None:
        super().__init__(message, status_code=401, error_response=error_response)


class ForbiddenError(FluviusAPIError):
    """Raised when access is forbidden (403 Forbidden)."""

    def __init__(
        self,
        message: str = "Access forbidden. You don't have permission to access this resource.",
        error_response: ErrorResponse | ErrorValidationResponse | None = None,
    ) -> None:
        super().__init__(message, status_code=403, error_response=error_response)


class NotFoundError(FluviusAPIError):
    """Raised when a resource is not found (404 Not Found)."""

    def __init__(
        self,
        message: str = "Resource not found.",
        error_response: ErrorResponse | ErrorValidationResponse | None = None,
    ) -> None:
        super().__init__(message, status_code=404, error_response=error_response)


class ValidationError(FluviusAPIError):
    """Raised when request validation fails (400 Bad Request)."""

    def __init__(
        self,
        message: str = "Request validation failed.",
        error_response: ErrorValidationResponse | None = None,
    ) -> None:
        super().__init__(message, status_code=400, error_response=error_response)
        self.validation_errors = (
            error_response.validation_error_messages if error_response else None
        )


class ServerError(FluviusAPIError):
    """Raised when a server error occurs (500 Internal Server Error)."""

    def __init__(
        self,
        message: str = "Internal server error.",
        error_response: ErrorResponse | ErrorValidationResponse | None = None,
    ) -> None:
        super().__init__(message, status_code=500, error_response=error_response)


class ServiceUnavailableError(FluviusAPIError):
    """Raised when the service is unavailable (503 Service Unavailable)."""

    def __init__(
        self,
        message: str = "Service unavailable. Please try again later.",
        error_response: ErrorResponse | ErrorValidationResponse | None = None,
    ) -> None:
        super().__init__(message, status_code=503, error_response=error_response)
