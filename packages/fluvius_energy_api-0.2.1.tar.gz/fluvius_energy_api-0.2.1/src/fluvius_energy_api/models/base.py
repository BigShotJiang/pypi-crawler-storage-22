"""Base model classes for the Fluvius Energy API."""

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class FluviusBaseModel(BaseModel):
    """Base model with camelCase alias configuration."""

    model_config = ConfigDict(
        populate_by_name=True,
        use_enum_values=True,
    )


class ResponseMetadata(FluviusBaseModel):
    """Represents metadata for a response."""

    fetch_time: datetime | None = Field(default=None, alias="fetchTime")


class ErrorResponse(FluviusBaseModel):
    """Represents an error response from the API."""

    type: str | None = Field(default=None, alias="Type")
    code: str | None = Field(default=None, alias="Code")
    message: str | None = Field(default=None, alias="Message")


class ErrorValidationResponse(ErrorResponse):
    """Represents a response when validation has failed during the request."""

    validation_error_messages: list[str] | None = Field(
        default=None, alias="ValidationErrorMessages"
    )
