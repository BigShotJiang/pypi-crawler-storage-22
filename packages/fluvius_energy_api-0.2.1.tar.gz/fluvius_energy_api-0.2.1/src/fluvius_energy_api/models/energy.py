"""Energy measurement models for the Fluvius Energy API."""

from datetime import datetime
from typing import Annotated, Literal
from pydantic import Field

from .base import FluviusBaseModel, ResponseMetadata
from .enums import (
    EnergyType,
    GasConversionFactor,
    LocalProductionInstallationType,
    MeasurementValidationState,
    Unit,
)


class MeasurementValue(FluviusBaseModel):
    """Represents a single measurement value."""

    value: float | None = None
    unit: Unit | None = None
    validation_state: MeasurementValidationState | None = Field(
        default=None, alias="validationState"
    )
    gas_conversion_factor: GasConversionFactor | None = Field(
        default=None, alias="gasConversionFactor"
    )


class MeasurementValueSet(FluviusBaseModel):
    """Represents a measurement value set for different registers."""

    total: MeasurementValue | None = None
    day: MeasurementValue | None = None
    night: MeasurementValue | None = None
    reactive: MeasurementValue | None = None
    inductive: MeasurementValue | None = None
    capacitive: MeasurementValue | None = None


class MeasurementDirection(FluviusBaseModel):
    """Represents a measurement set for different energy directions."""

    offtake: MeasurementValueSet | None = None
    injection: MeasurementValueSet | None = None
    production: MeasurementValueSet | None = None
    auxiliary: MeasurementValueSet | None = None


class MeasurementTimeSlice(FluviusBaseModel):
    """Represents a measurement set within a given period (time slice)."""

    start: datetime | None = None
    end: datetime | None = None
    measurements: list[MeasurementDirection] | None = None


class PhysicalMeter(FluviusBaseModel):
    """Represents a physical meter."""

    seq_number: str | None = Field(default=None, alias="seqNumber")
    meter_id: str | None = Field(default=None, alias="meterID")
    daily_energy: list[MeasurementTimeSlice] | None = Field(
        default=None, alias="dailyEnergy"
    )
    hourly_energy: list[MeasurementTimeSlice] | None = Field(
        default=None, alias="hourlyEnergy"
    )
    quarter_hourly_energy: list[MeasurementTimeSlice] | None = Field(
        default=None, alias="quarterHourlyEnergy"
    )


class SubHeadpoint(FluviusBaseModel):
    """Base response for different kinds of submetering installations."""

    type_discriminator: str = Field(alias="$type")
    ean: str | None = None
    seq_number: str | None = Field(default=None, alias="seqNumber")
    vreg_id: str | None = Field(default=None, alias="vregId")
    type: LocalProductionInstallationType | None = None
    daily_energy: list[MeasurementTimeSlice] | None = Field(
        default=None, alias="dailyEnergy"
    )
    hourly_energy: list[MeasurementTimeSlice] | None = Field(
        default=None, alias="hourlyEnergy"
    )
    quarter_hourly_energy: list[MeasurementTimeSlice] | None = Field(
        default=None, alias="quarterHourlyEnergy"
    )


class AuxiliarySubHeadpoint(SubHeadpoint):
    """Represents a submetering installation for auxiliary energy."""

    type_discriminator: Literal["submetering-auxiliary"] = Field(
        default="submetering-auxiliary", alias="$type"
    )


class OfftakeSubHeadpoint(SubHeadpoint):
    """Represents a submetering installation for offtake energy."""

    type_discriminator: Literal["submetering-offtake"] = Field(
        default="submetering-offtake", alias="$type"
    )


class ProductionSubHeadpoint(SubHeadpoint):
    """Represents a submetering installation for produced energy."""

    type_discriminator: Literal["submetering-production"] = Field(
        default="submetering-production", alias="$type"
    )


SubHeadpointUnion = Annotated[
    AuxiliarySubHeadpoint | OfftakeSubHeadpoint | ProductionSubHeadpoint,
    Field(discriminator="type_discriminator"),
]


class Headpoint(FluviusBaseModel):
    """Base response for different kinds of installations."""

    type_discriminator: str = Field(alias="$type")
    ean: str | None = None
    energy_type: EnergyType | None = Field(default=None, alias="energyType")


class MeteringOnHeadpoint(Headpoint):
    """Response containing an installation where metering is done on headpoint level (AMR)."""

    type_discriminator: Literal["metering-on-headpoint"] = Field(
        default="metering-on-headpoint", alias="$type"
    )
    daily_energy: list[MeasurementTimeSlice] | None = Field(
        default=None, alias="dailyEnergy"
    )
    hourly_energy: list[MeasurementTimeSlice] | None = Field(
        default=None, alias="hourlyEnergy"
    )
    quarter_hourly_energy: list[MeasurementTimeSlice] | None = Field(
        default=None, alias="quarterHourlyEnergy"
    )
    sub_headpoints: list[SubHeadpointUnion] | None = Field(
        default=None, alias="subHeadpoints"
    )


class MeteringOnMeter(Headpoint):
    """Response containing an installation where metering is done on meter level (DM)."""

    type_discriminator: Literal["metering-on-meter"] = Field(
        default="metering-on-meter", alias="$type"
    )
    physical_meters: list[PhysicalMeter] | None = Field(
        default=None, alias="physicalMeters"
    )


class MeteringOnHeadpointAndMeter(Headpoint):
    """Response containing an installation where metering is done on both headpoint and meter level."""

    type_discriminator: Literal["metering-on-headpoint-and-meter"] = Field(
        default="metering-on-headpoint-and-meter", alias="$type"
    )
    physical_meters: list[PhysicalMeter] | None = Field(
        default=None, alias="physicalMeters"
    )
    daily_energy: list[MeasurementTimeSlice] | None = Field(
        default=None, alias="dailyEnergy"
    )
    hourly_energy: list[MeasurementTimeSlice] | None = Field(
        default=None, alias="hourlyEnergy"
    )
    quarter_hourly_energy: list[MeasurementTimeSlice] | None = Field(
        default=None, alias="quarterHourlyEnergy"
    )
    sub_headpoints: list[SubHeadpointUnion] | None = Field(
        default=None, alias="subHeadpoints"
    )


HeadpointUnion = Annotated[
    MeteringOnHeadpoint | MeteringOnMeter | MeteringOnHeadpointAndMeter,
    Field(discriminator="type_discriminator"),
]


class GetEnergyResponse(FluviusBaseModel):
    """Represents a response containing energy for a single installation."""

    headpoint: HeadpointUnion | None = None


class GetEnergyResponseApiDataResponse(FluviusBaseModel):
    """Represents a successful response from the server containing data."""

    meta: ResponseMetadata | None = Field(default=None, alias="_meta")
    data: GetEnergyResponse | None = None
