"""Enum definitions for the Fluvius Energy API."""

from enum import Enum


class CreateClientSessionStatus(str, Enum):
    """Defines all client session creation statuses."""

    SUCCESS = "success"
    FAILED = "failed"


class DataServiceType(str, Enum):
    """Defines the available data service types."""

    VH_ONBEPAALD = "VH_onbepaald"
    VH_KWARTIER_UUR = "VH_kwartier_uur"
    VH_DAG = "VH_dag"
    IG = "IG"


class EnergyType(str, Enum):
    """Defines all supported disciplines (energy types)."""

    ELECTRICITY = "E"
    GAS = "G"


class EstimatedVolumeType(str, Enum):
    """Defines the supported types of estimated volume."""

    EAV = "EAV"


class Flow(str, Enum):
    """Defines all possible flows."""

    B2C = "B2C"
    B2B = "B2B"


class GasConversionFactor(str, Enum):
    """Defines all possible values for gas conversion factor."""

    PREDICTIVE = "P"
    DEFINITIVE = "D"
    CONSTANT = "C"


class LocalProductionInstallationType(str, Enum):
    """Defines the types of local production installation."""

    UNKNOWN = "?"
    NDGR = "NDGR"
    NDGR2 = "NDGR2"
    PV = "PV"
    WKKB = "WKKB"
    WKKD = "WKKD"
    WKKA = "WKKA"
    WTR = "WTR"
    WND = "WND"
    TBJT = "TBJT"
    ORC = "ORC"
    BC = "BC"
    BIOM = "BIOM"
    DSL = "DSL"
    FOSM = "FOSM"
    PPPV = "PPPV"
    PPBAT = "PPBAT"
    BAT = "BAT"


class MandateRenewalStatus(str, Enum):
    """Defines all mandate renewal statuses."""

    TO_BE_RENEWED = "ToBeRenewed"
    RENEWAL_REQUESTED = "RenewalRequested"
    EXPIRED = "Expired"


class MandateStatus(str, Enum):
    """Defines all mandate statuses."""

    REQUESTED = "Requested"
    APPROVED = "Approved"
    REJECTED = "Rejected"
    FINISHED = "Finished"


class MeasurementValidationState(str, Enum):
    """Defines all possible values for validation states of measurements."""

    READ = "READ"
    EST = "EST"
    VAL = "VAL"
    NVAL = "NVAL"


class MeterType(str, Enum):
    """Defines all possible meter types."""

    KM = "KM"
    DM = "DM"


class PeriodType(str, Enum):
    """Defines the type of period for which will be queried."""

    READ_TIME = "readTime"
    INSERT_TIME = "insertTime"


class Register(str, Enum):
    """Represents a register."""

    UNKNOWN = "Unknown"
    OFFTAKE_TOTAL_HOURS = "OfftakeTotalHours"
    OFFTAKE_HIGH = "OfftakeHigh"
    OFFTAKE_LOW = "OfftakeLow"
    OFFTAKE_EXCLUSIVE_NIGHT = "OfftakeExclusiveNight"
    COMPENSATED_OFFTAKE_TOTAL_HOURS = "CompensatedOfftakeTotalHours"
    COMPENSATED_OFFTAKE_HIGH = "CompensatedOfftakeHigh"
    COMPENSATED_OFFTAKE_LOW = "CompensatedOfftakeLow"
    INJECTION_TOTAL_HOURS = "InjectionTotalHours"
    INJECTION_HIGH = "InjectionHigh"
    INJECTION_LOW = "InjectionLow"


class Unit(str, Enum):
    """Defines all supported units."""

    UNKNOWN = "?"
    KVA = "kVA"
    KVARH = "kVArh"
    KWH = "kWh"
    KW = "kW"
    M3 = "m3"
