"""Installation models for the Fluvius Energy API."""

from datetime import datetime
from pydantic import Field

from .base import FluviusBaseModel, ResponseMetadata
from .enums import (
    EnergyType,
    EstimatedVolumeType,
    LocalProductionInstallationType,
    MeterType,
    Register,
    Unit,
)


class LocalProductionInstallation(FluviusBaseModel):
    """Represents a single local production installation."""

    vreg_id: str | None = Field(default=None, alias="vregId")
    type: LocalProductionInstallationType | None = None
    converter_power: float | None = Field(default=None, alias="converterPower")
    converter_power_unit: Unit | None = Field(default=None, alias="converterPowerUnit")
    inspection_date: datetime | None = Field(default=None, alias="inspectionDate")


class EstimatedVolume(FluviusBaseModel):
    """Represents a response containing an estimated volume."""

    type: EstimatedVolumeType | None = None
    calculated_register: Register | None = Field(
        default=None, alias="calculatedRegister"
    )
    value: int | None = None
    unit: Unit | None = None
    consumption_start_date: datetime | None = Field(
        default=None, alias="consumptionStartDate"
    )
    consumption_end_date: datetime | None = Field(
        default=None, alias="consumptionEndDate"
    )


class Installation(FluviusBaseModel):
    """Represents a single installation."""

    energy_type: EnergyType | None = Field(default=None, alias="energyType")
    meter_type: MeterType | None = Field(default=None, alias="meterType")
    smr3: bool | None = None
    local_production_installations: list[LocalProductionInstallation] | None = Field(
        default=None, alias="localProductionInstallations"
    )
    estimated_volumes: list[EstimatedVolume] | None = Field(
        default=None, alias="estimatedVolumes"
    )


class GetInstallationResponse(FluviusBaseModel):
    """Represents a response containing installation data."""

    installation: Installation | None = None


class GetInstallationResponseApiDataResponse(FluviusBaseModel):
    """Represents a successful response from the server containing data."""

    meta: ResponseMetadata | None = Field(default=None, alias="_meta")
    data: GetInstallationResponse | None = None
