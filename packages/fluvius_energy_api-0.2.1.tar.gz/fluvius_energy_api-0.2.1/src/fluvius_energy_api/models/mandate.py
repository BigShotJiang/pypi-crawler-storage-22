"""Mandate models for the Fluvius Energy API."""

from datetime import datetime
from pydantic import Field

from .base import FluviusBaseModel, ResponseMetadata
from .enums import DataServiceType, EnergyType, MandateRenewalStatus, MandateStatus


class Mandate(FluviusBaseModel):
    """Represents a single mandate."""

    reference_number: str | None = Field(default=None, alias="referenceNumber")
    status: MandateStatus | None = None
    ean: str | None = None
    energy_type: EnergyType | None = Field(default=None, alias="energyType")
    data_period_from: datetime | None = Field(default=None, alias="dataPeriodFrom")
    data_period_to: datetime | None = Field(default=None, alias="dataPeriodTo")
    data_service_type: DataServiceType | None = Field(
        default=None, alias="dataServiceType"
    )
    mandate_expiration_date: datetime | None = Field(
        default=None, alias="mandateExpirationDate"
    )
    renewal_status: MandateRenewalStatus | None = Field(
        default=None, alias="renewalStatus"
    )


class GetMandatesResponse(FluviusBaseModel):
    """Represents a response containing multiple mandates."""

    mandates: list[Mandate] | None = None


class GetMandatesResponseApiDataResponse(FluviusBaseModel):
    """Represents a successful response from the server containing data."""

    meta: ResponseMetadata | None = Field(default=None, alias="_meta")
    data: GetMandatesResponse | None = None


class CreateMandateRequest(FluviusBaseModel):
    """Request to create a mock mandate in the sandbox environment.

    This endpoint is only available in the sandbox environment.
    """

    reference_number: str = Field(..., alias="referenceNumber")
    ean: str
    data_service_type: DataServiceType = Field(..., alias="dataServiceType")
    data_period_from: str | None = Field(default=None, alias="dataPeriodFrom")
    data_period_to: str | None = Field(default=None, alias="dataPeriodTo")
    status: MandateStatus | None = None
    mandate_expiration_date: str | None = Field(
        default=None, alias="mandateExpirationDate"
    )
    renewal_status: MandateRenewalStatus | None = Field(
        default=None, alias="renewalStatus"
    )


class CreateMandateResponse(FluviusBaseModel):
    """Response from creating a mock mandate."""

    status: str | None = None


class CreateMandateResponseApiDataResponse(FluviusBaseModel):
    """Represents a successful response from the mock mandate creation."""

    meta: ResponseMetadata | None = Field(default=None, alias="_meta")
    data: CreateMandateResponse | None = None
