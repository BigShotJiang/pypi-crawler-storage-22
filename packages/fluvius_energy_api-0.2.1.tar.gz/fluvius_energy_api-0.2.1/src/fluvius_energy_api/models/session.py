"""Client session models for the Fluvius Energy API."""

from datetime import datetime
from pydantic import Field

from .base import FluviusBaseModel, ResponseMetadata
from .enums import CreateClientSessionStatus, DataServiceType, Flow


class ClientSessionDataService(FluviusBaseModel):
    """Represents a data service on a request to create a client session."""

    data_service_type: DataServiceType = Field(alias="dataServiceType")
    data_period_from: str | None = Field(default=None, alias="dataPeriodFrom")
    data_period_to: str | None = Field(default=None, alias="dataPeriodTo")


class CreateClientSessionRequest(FluviusBaseModel):
    """Represents a request to create a client session."""

    data_access_contract_number: str = Field(alias="dataAccessContractNumber")
    reference_number: str = Field(alias="referenceNumber")
    flow: Flow
    data_services: list[ClientSessionDataService] | None = Field(
        default=None, alias="dataServices"
    )
    number_of_eans: int | None = Field(default=None, alias="numberOfEans")
    return_url_success: str | None = Field(default=None, alias="returnUrlSuccess")
    return_url_failed: str | None = Field(default=None, alias="returnUrlFailed")
    sso: bool | None = None
    enterprise_number: str | None = Field(default=None, alias="enterpriseNumber")


class CreateClientSessionResponse(FluviusBaseModel):
    """Represents a response containing a new client session."""

    status: CreateClientSessionStatus | None = None
    short_url_identifier: str | None = Field(default=None, alias="shortUrlIdentifier")
    valid_to: datetime | None = Field(default=None, alias="validTo")


class CreateClientSessionResponseApiDataResponse(FluviusBaseModel):
    """Represents a successful response from the server containing data."""

    meta: ResponseMetadata | None = Field(default=None, alias="_meta")
    data: CreateClientSessionResponse | None = None
