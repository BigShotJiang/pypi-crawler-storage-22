"""Tests for the Fluvius Energy API wrapper."""
