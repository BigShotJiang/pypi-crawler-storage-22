"""Tests for OAuth2 token management."""

import time
from unittest.mock import MagicMock, patch

import pytest
from pytest_httpx import HTTPXMock

from fluvius_energy_api import FluviusCredentials, TokenProvider, AuthenticationError
from fluvius_energy_api.auth import AccessToken


# Use a real RSA key for JWT signing tests
SAMPLE_PRIVATE_KEY = """-----BEGIN RSA PRIVATE KEY-----
MIIEpAIBAAKCAQEArvybc5ow0qR/rIEQGz3RpVjgY7rP4Gj4d+ByQVJWxKuTsYuO
FpjVWXb5EvNC2q0A/AYGMj24B8IAp/jSaQRO5JLmzKdxIE2uWAqhWr49EdcDpZMA
EvuAcuyi/sOSSmskFC/PcdH3eTTZ33VfSoFUD9m9cIB37VHTKr8q6DjusvuFctCR
Xn2UFCd0xYkvTxhmvyaFt86R2VdSurmnY+OGW+ehD99MkBY3GNXrjleJ/8lojELo
FLCU5MCgrY42F7/zSn6bfV+HbNxmRY8jeKKmiate61PQ9nQbIbJS1Nu42V3eJeBQ
EdqXmgAif+1IHgUTwX4poQ7Ve7zNlpevg1R6OQIDAQABAoIBAAbnKCq99mxuLisx
RuAMPEJNk0Hb6L9tj1ULTEvkt6TihTJdKFRz4Fa7KXA58HU38JtV5tYB4Un3uUGR
wJsr9FYdWsV6sC0aDg/4Zg0dBsO2u7TDFnRT6j6eXypgWgZdhlAq4qrBdwXCXqXr
YhWfrHVDna7bzTSrea0XWtX2XlQ+eaX2X6Ks4/FLgE5Tg8AuGkCnBMi3FeM6MK9r
irDq5nf9KLhOB8oqT8AtGWvM8xxT9L2BFuhnh9G3KaKmGVxyzw2fuE0SctnBt3d/
nQBWeV8pKfNhgoWzd4sROcYPDodrfn+1qvjT/d9IHk4MW3Hyl/uBaAsnylCM4x9S
gAQ56AECgYEA9O1+BmUA21nIB09SLe/ntRCX99vmISXG728UjHa1LOHe+F4U+N81
U9jnCL5snYq57/1sCJHSeUisHDRjMEYsFiGr0F4hMhR4QmPZUFnhaj3DvEK+++wm
rA3+GWfBmSkwxzCJa2HYIz9GwsYhS6uy1sDkVJJG/dyuqo+N6Yiu53kCgYEAtuWz
KQnwP/icyybibz+VlfKOiz6tTG3YnX3st/4v3NJDvJ4cLJd0CjcinUbnM+Oox8Lw
13ERDE2gAIf7OmCLukL0RQlRnfCP2hcj4rRC2T8cd9PwiM6PuF1uTIJGsM3yJdL+
9kOWDqI3stH1S282+08mv+C4P+OGLn460h6huMECgYEAtQRhQ/CaNYOhZmWlYvYP
1a4x4qnO52i4InWCRl3lgQpedEl0TosJKrL/7WJve+/vhANUOPEtER44tY+yTxdN
tf2kshcfiZe/WbHaBpynEJIde6II7L+XxUmCJtycJMpglpa0uXxS9ZnqfkFYkkiP
oFBncGm7thvHq571T0gJnGECgYA1jfD2FVjqAmw2+D3ZgW7Vp16h20p3VLrW8uZ7
wcxWBqOa+VkanYZ270oNb5OHmCP1ylknXI43Ygt13Ftt7pM7iRtpk574dlZI7/ms
CkiAwIAffkmyZXmj7Ie9k3ALmWJMPQo3JfcsdceFbwE6g2hAEh8wlCafXooN1xx2
Jk4IgQKBgQC/0LiJEVVHJQ6Fjs7UgqxTj6Mb9mW5TM66+GDd5TiHajUtPhU+mBPf
v26qcizM9vYilXzR37u6srYdQMhi2xd0JdxkI/U4J29pr5d/tpLLE3ArWJmTwPhr
gYbIR6Hty8dKqMfoIDN0G94KAm6leZwU2aRJMR3r4eOY50uvJ6OIFw==
-----END RSA PRIVATE KEY-----"""


@pytest.fixture
def credentials():
    """Create test credentials."""
    return FluviusCredentials(
        subscription_key="test-subscription-key",
        client_id="test-client-id",
        tenant_id="test-tenant-id",
        scope="api://test-scope/.default",
        certificate_thumbprint="AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",
        private_key=SAMPLE_PRIVATE_KEY,
        data_access_contract_number="1234567890",
    )


class TestAccessToken:
    def test_expires_at_calculation(self):
        token = AccessToken(
            access_token="test-token",
            token_type="Bearer",
            expires_in=3600,
            obtained_at=1000.0,
        )
        assert token.expires_at == 4600.0

    def test_is_expired_when_past_expiry(self):
        token = AccessToken(
            access_token="test-token",
            token_type="Bearer",
            expires_in=3600,
            obtained_at=time.time() - 4000,  # Obtained 4000 seconds ago
        )
        assert token.is_expired() is True

    def test_is_not_expired_when_fresh(self):
        token = AccessToken(
            access_token="test-token",
            token_type="Bearer",
            expires_in=3600,
            obtained_at=time.time(),
        )
        assert token.is_expired() is False

    def test_is_expired_within_margin(self):
        # Token expires in 30 seconds, but margin is 60 seconds
        token = AccessToken(
            access_token="test-token",
            token_type="Bearer",
            expires_in=30,
            obtained_at=time.time(),
        )
        assert token.is_expired(margin_seconds=60) is True

    def test_custom_margin(self):
        # Token expires in 100 seconds, margin is 50 seconds
        token = AccessToken(
            access_token="test-token",
            token_type="Bearer",
            expires_in=100,
            obtained_at=time.time(),
        )
        assert token.is_expired(margin_seconds=50) is False
        assert token.is_expired(margin_seconds=150) is True


class TestTokenProvider:
    def test_get_authorization_headers(self, credentials: FluviusCredentials):
        provider = TokenProvider(credentials)
        # Mock the token acquisition
        provider._token = AccessToken(
            access_token="test-access-token",
            token_type="Bearer",
            expires_in=3600,
            obtained_at=time.time(),
        )

        headers = provider.get_authorization_headers()

        assert headers["Authorization"] == "Bearer test-access-token"
        assert headers["Ocp-Apim-Subscription-Key"] == "test-subscription-key"
        provider.close()

    def test_token_caching(self, credentials: FluviusCredentials, httpx_mock: HTTPXMock):
        httpx_mock.add_response(
            method="POST",
            url="https://login.microsoftonline.com/test-tenant-id/oauth2/v2.0/token",
            json={
                "access_token": "first-token",
                "token_type": "Bearer",
                "expires_in": 3600,
            },
        )

        provider = TokenProvider(credentials)

        # First call should acquire token
        token1 = provider.get_access_token()
        assert token1 == "first-token"

        # Second call should return cached token
        token2 = provider.get_access_token()
        assert token2 == "first-token"

        # Should have only made one HTTP request
        assert len(httpx_mock.get_requests()) == 1

        provider.close()

    def test_token_refresh_when_expired(
        self, credentials: FluviusCredentials, httpx_mock: HTTPXMock
    ):
        httpx_mock.add_response(
            method="POST",
            url="https://login.microsoftonline.com/test-tenant-id/oauth2/v2.0/token",
            json={
                "access_token": "new-token",
                "token_type": "Bearer",
                "expires_in": 3600,
            },
        )

        provider = TokenProvider(credentials)
        # Set an expired token
        provider._token = AccessToken(
            access_token="old-token",
            token_type="Bearer",
            expires_in=3600,
            obtained_at=time.time() - 4000,  # Expired
        )

        # Should acquire new token
        token = provider.get_access_token()
        assert token == "new-token"

        provider.close()

    def test_authentication_error_on_failure(
        self, credentials: FluviusCredentials, httpx_mock: HTTPXMock
    ):
        httpx_mock.add_response(
            method="POST",
            url="https://login.microsoftonline.com/test-tenant-id/oauth2/v2.0/token",
            status_code=401,
            json={
                "error": "invalid_client",
                "error_description": "Client authentication failed",
            },
        )

        provider = TokenProvider(credentials)

        with pytest.raises(AuthenticationError) as exc_info:
            provider.get_access_token()

        assert "Client authentication failed" in str(exc_info.value)

        provider.close()

    def test_encode_thumbprint(self, credentials: FluviusCredentials):
        provider = TokenProvider(credentials)

        # Test with known thumbprint
        thumbprint = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
        encoded = provider._encode_thumbprint(thumbprint)

        # The encoded value should be base64url without padding
        assert "=" not in encoded
        assert "+" not in encoded
        assert "/" not in encoded

        provider.close()


class TestTokenProviderIntegration:
    def test_full_token_flow(
        self, credentials: FluviusCredentials, httpx_mock: HTTPXMock
    ):
        httpx_mock.add_response(
            method="POST",
            url="https://login.microsoftonline.com/test-tenant-id/oauth2/v2.0/token",
            json={
                "access_token": "integration-test-token",
                "token_type": "Bearer",
                "expires_in": 3600,
            },
        )

        provider = TokenProvider(credentials)

        # Get token
        token = provider.get_access_token()
        assert token == "integration-test-token"

        # Verify request was made correctly
        request = httpx_mock.get_requests()[0]
        assert request.method == "POST"
        assert "client_id=test-client-id" in request.content.decode()
        assert "grant_type=client_credentials" in request.content.decode()
        assert "client_assertion_type=urn" in request.content.decode()

        provider.close()
