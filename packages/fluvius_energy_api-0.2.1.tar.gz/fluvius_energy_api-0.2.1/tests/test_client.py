"""Tests for the Fluvius Energy API client."""

import time
from datetime import datetime
from unittest.mock import patch

import pytest
from pytest_httpx import HTTPXMock

from fluvius_energy_api import (
    AuthenticationError,
    ClientSessionDataService,
    DataServiceType,
    EnergyType,
    Environment,
    FluviusCredentials,
    FluviusEnergyClient,
    ForbiddenError,
    MandateStatus,
    NotFoundError,
    PeriodType,
    ServerError,
    ServiceUnavailableError,
    ValidationError,
)
from fluvius_energy_api.auth import AccessToken


SAMPLE_PRIVATE_KEY = """-----BEGIN RSA PRIVATE KEY-----
MIIEpAIBAAKCAQEArvybc5ow0qR/rIEQGz3RpVjgY7rP4Gj4d+ByQVJWxKuTsYuO
FpjVWXb5EvNC2q0A/AYGMj24B8IAp/jSaQRO5JLmzKdxIE2uWAqhWr49EdcDpZMA
EvuAcuyi/sOSSmskFC/PcdH3eTTZ33VfSoFUD9m9cIB37VHTKr8q6DjusvuFctCR
Xn2UFCd0xYkvTxhmvyaFt86R2VdSurmnY+OGW+ehD99MkBY3GNXrjleJ/8lojELo
FLCU5MCgrY42F7/zSn6bfV+HbNxmRY8jeKKmiate61PQ9nQbIbJS1Nu42V3eJeBQ
EdqXmgAif+1IHgUTwX4poQ7Ve7zNlpevg1R6OQIDAQABAoIBAAbnKCq99mxuLisx
RuAMPEJNk0Hb6L9tj1ULTEvkt6TihTJdKFRz4Fa7KXA58HU38JtV5tYB4Un3uUGR
wJsr9FYdWsV6sC0aDg/4Zg0dBsO2u7TDFnRT6j6eXypgWgZdhlAq4qrBdwXCXqXr
YhWfrHVDna7bzTSrea0XWtX2XlQ+eaX2X6Ks4/FLgE5Tg8AuGkCnBMi3FeM6MK9r
irDq5nf9KLhOB8oqT8AtGWvM8xxT9L2BFuhnh9G3KaKmGVxyzw2fuE0SctnBt3d/
nQBWeV8pKfNhgoWzd4sROcYPDodrfn+1qvjT/d9IHk4MW3Hyl/uBaAsnylCM4x9S
gAQ56AECgYEA9O1+BmUA21nIB09SLe/ntRCX99vmISXG728UjHa1LOHe+F4U+N81
U9jnCL5snYq57/1sCJHSeUisHDRjMEYsFiGr0F4hMhR4QmPZUFnhaj3DvEK+++wm
rA3+GWfBmSkwxzCJa2HYIz9GwsYhS6uy1sDkVJJG/dyuqo+N6Yiu53kCgYEAtuWz
KQnwP/icyybibz+VlfKOiz6tTG3YnX3st/4v3NJDvJ4cLJd0CjcinUbnM+Oox8Lw
13ERDE2gAIf7OmCLukL0RQlRnfCP2hcj4rRC2T8cd9PwiM6PuF1uTIJGsM3yJdL+
9kOWDqI3stH1S282+08mv+C4P+OGLn460h6huMECgYEAtQRhQ/CaNYOhZmWlYvYP
1a4x4qnO52i4InWCRl3lgQpedEl0TosJKrL/7WJve+/vhANUOPEtER44tY+yTxdN
tf2kshcfiZe/WbHaBpynEJIde6II7L+XxUmCJtycJMpglpa0uXxS9ZnqfkFYkkiP
oFBncGm7thvHq571T0gJnGECgYA1jfD2FVjqAmw2+D3ZgW7Vp16h20p3VLrW8uZ7
wcxWBqOa+VkanYZ270oNb5OHmCP1ylknXI43Ygt13Ftt7pM7iRtpk574dlZI7/ms
CkiAwIAffkmyZXmj7Ie9k3ALmWJMPQo3JfcsdceFbwE6g2hAEh8wlCafXooN1xx2
Jk4IgQKBgQC/0LiJEVVHJQ6Fjs7UgqxTj6Mb9mW5TM66+GDd5TiHajUtPhU+mBPf
v26qcizM9vYilXzR37u6srYdQMhi2xd0JdxkI/U4J29pr5d/tpLLE3ArWJmTwPhr
gYbIR6Hty8dKqMfoIDN0G94KAm6leZwU2aRJMR3r4eOY50uvJ6OIFw==
-----END RSA PRIVATE KEY-----"""


@pytest.fixture
def test_credentials():
    """Create test credentials."""
    return FluviusCredentials(
        subscription_key="test-subscription-key",
        client_id="test-client-id",
        tenant_id="test-tenant-id",
        scope="api://test-scope/.default",
        certificate_thumbprint="AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",
        private_key=SAMPLE_PRIVATE_KEY,
        data_access_contract_number="1234567890",
    )


@pytest.fixture
def mock_token():
    """Create a mock access token that won't expire during tests."""
    return AccessToken(
        access_token="test-access-token",
        token_type="Bearer",
        expires_in=3600,
        obtained_at=time.time(),
    )


@pytest.fixture
def client_with_mock_token(test_credentials, mock_token):
    """Create a client with a pre-set mock token (no HTTP call for token)."""
    client = FluviusEnergyClient(credentials=test_credentials)
    # Pre-set the token to avoid calling Azure AD
    client._token_provider._token = mock_token
    yield client
    client.close()


class TestEnvironment:
    def test_production_url(self):
        assert Environment.PRODUCTION.value == "https://apihub.fluvius.be/esco-live/v3"

    def test_sandbox_url(self):
        assert Environment.SANDBOX.value == "https://apihub.fluvius.be/esco-sbx/v3"


class TestFluviusEnergyClientInit:
    def test_default_environment_is_sandbox(self, test_credentials, mock_token):
        client = FluviusEnergyClient(credentials=test_credentials)
        client._token_provider._token = mock_token
        assert client._http._base_url == Environment.SANDBOX.value
        client.close()

    def test_production_environment(self, test_credentials, mock_token):
        client = FluviusEnergyClient(
            credentials=test_credentials, environment=Environment.PRODUCTION
        )
        client._token_provider._token = mock_token
        assert client._http._base_url == Environment.PRODUCTION.value
        client.close()

    def test_context_manager(self, test_credentials, mock_token):
        with FluviusEnergyClient(credentials=test_credentials) as client:
            client._token_provider._token = mock_token
            assert client._http._base_url == Environment.SANDBOX.value


class TestCreateClientSession:
    def test_create_client_session_success(
        self, client_with_mock_token, httpx_mock: HTTPXMock
    ):
        httpx_mock.add_response(
            method="POST",
            url="https://apihub.fluvius.be/esco-sbx/v3/api/shortUrlIdentifier",
            json={
                "data": {
                    "status": "success",
                    "shortUrlIdentifier": "abc123",
                    "validTo": "2026-01-28T00:00:00Z",
                },
                "_meta": {"fetchTime": "2026-01-27T15:15:57Z"},
            },
        )

        response = client_with_mock_token.create_client_session(
            data_access_contract_number="3599900040",
            reference_number="ref123",
            flow="B2B",
        )

        assert response.data.status == "success"
        assert response.data.short_url_identifier == "abc123"

    def test_create_client_session_with_data_services(
        self, client_with_mock_token, httpx_mock: HTTPXMock
    ):
        httpx_mock.add_response(
            method="POST",
            url="https://apihub.fluvius.be/esco-sbx/v3/api/shortUrlIdentifier",
            json={
                "data": {"status": "success", "shortUrlIdentifier": "abc123"},
                "_meta": {"fetchTime": "2026-01-27T15:15:57Z"},
            },
        )

        response = client_with_mock_token.create_client_session(
            data_access_contract_number="3599900040",
            reference_number="ref123",
            flow="B2B",
            data_services=[
                ClientSessionDataService(
                    data_service_type=DataServiceType.VH_DAG,
                    data_period_from="2020-03-01T23:00:00Z",
                )
            ],
            number_of_eans=2,
        )

        assert response.data.status == "success"

    def test_create_client_session_failed(
        self, client_with_mock_token, httpx_mock: HTTPXMock
    ):
        httpx_mock.add_response(
            method="POST",
            url="https://apihub.fluvius.be/esco-sbx/v3/api/shortUrlIdentifier",
            json={
                "data": {"status": "failed"},
                "_meta": {"fetchTime": "2026-01-27T15:15:57Z"},
            },
        )

        response = client_with_mock_token.create_client_session(
            data_access_contract_number="3599900040",
            reference_number="ref123",
            flow="B2B",
        )

        assert response.data.status == "failed"
        assert response.data.short_url_identifier is None


class TestGetMandates:
    def test_get_mandates_no_filters(
        self, client_with_mock_token, httpx_mock: HTTPXMock
    ):
        httpx_mock.add_response(
            method="GET",
            url="https://apihub.fluvius.be/esco-sbx/v3/api/mandate",
            json={
                "data": {
                    "mandates": [
                        {
                            "referenceNumber": "ref123",
                            "status": "Approved",
                            "ean": "541448800000004312",
                            "energyType": "E",
                            "dataServiceType": "VH_dag",
                        }
                    ]
                },
                "_meta": {"fetchTime": "2024-07-01T16:38:10Z"},
            },
        )

        response = client_with_mock_token.get_mandates()

        assert len(response.data.mandates) == 1
        assert response.data.mandates[0].ean == "541448800000004312"

    def test_get_mandates_with_filters(
        self, client_with_mock_token, httpx_mock: HTTPXMock
    ):
        httpx_mock.add_response(
            method="GET",
            url="https://apihub.fluvius.be/esco-sbx/v3/api/mandate?ean=541448800000004312&energyType=E&status=Approved",
            json={
                "data": {"mandates": []},
                "_meta": {"fetchTime": "2024-07-01T16:38:10Z"},
            },
        )

        response = client_with_mock_token.get_mandates(
            ean="541448800000004312",
            energy_type=EnergyType.ELECTRICITY,
            status=MandateStatus.APPROVED,
        )

        assert response.data.mandates == []

    def test_get_mandates_with_data_service_types(
        self, client_with_mock_token, httpx_mock: HTTPXMock
    ):
        httpx_mock.add_response(
            method="GET",
            url="https://apihub.fluvius.be/esco-sbx/v3/api/mandate?dataServiceTypes=VH_dag%2CVH_kwartier_uur",
            json={
                "data": {"mandates": []},
                "_meta": {"fetchTime": "2024-07-01T16:38:10Z"},
            },
        )

        response = client_with_mock_token.get_mandates(
            data_service_types=[
                DataServiceType.VH_DAG,
                DataServiceType.VH_KWARTIER_UUR,
            ]
        )

        assert response.data.mandates == []


class TestGetEnergy:
    def test_get_energy_required_params(
        self, client_with_mock_token, httpx_mock: HTTPXMock
    ):
        httpx_mock.add_response(
            method="GET",
            url="https://apihub.fluvius.be/esco-sbx/v3/api/mandate/energy?ean=541448800000004312&periodType=readTime",
            json={
                "data": {
                    "headpoint": {
                        "$type": "metering-on-meter",
                        "ean": "541448800000004312",
                        "energyType": "E",
                        "physicalMeters": [],
                    }
                },
                "_meta": {"fetchTime": "2024-07-01T16:38:10Z"},
            },
        )

        response = client_with_mock_token.get_energy(
            ean="541448800000004312",
            period_type=PeriodType.READ_TIME,
        )

        assert response.data.headpoint.ean == "541448800000004312"

    def test_get_energy_with_all_params(
        self, client_with_mock_token, httpx_mock: HTTPXMock
    ):
        httpx_mock.add_response(
            method="GET",
            url="https://apihub.fluvius.be/esco-sbx/v3/api/mandate/energy?ean=541448800000004312&periodType=readTime&granularity=daily&complexEnergyTypes=active&from=2024-01-01T00%3A00%3A00Z&to=2024-06-01T00%3A00%3A00Z",
            json={
                "data": {
                    "headpoint": {
                        "$type": "metering-on-headpoint",
                        "ean": "541448800000004312",
                        "energyType": "E",
                        "dailyEnergy": [],
                    }
                },
                "_meta": {"fetchTime": "2024-07-01T16:38:10Z"},
            },
        )

        response = client_with_mock_token.get_energy(
            ean="541448800000004312",
            period_type=PeriodType.READ_TIME,
            granularity="daily",
            complex_energy_types="active",
            from_date=datetime(2024, 1, 1),
            to_date=datetime(2024, 6, 1),
        )

        assert response.data.headpoint.type_discriminator == "metering-on-headpoint"


class TestErrorHandling:
    def test_authentication_error(
        self, client_with_mock_token, httpx_mock: HTTPXMock
    ):
        httpx_mock.add_response(
            method="GET",
            url="https://apihub.fluvius.be/esco-sbx/v3/api/mandate",
            status_code=401,
        )

        with pytest.raises(AuthenticationError):
            client_with_mock_token.get_mandates()

    def test_forbidden_error(self, client_with_mock_token, httpx_mock: HTTPXMock):
        httpx_mock.add_response(
            method="GET",
            url="https://apihub.fluvius.be/esco-sbx/v3/api/mandate",
            status_code=403,
        )

        with pytest.raises(ForbiddenError):
            client_with_mock_token.get_mandates()

    def test_not_found_error(self, client_with_mock_token, httpx_mock: HTTPXMock):
        httpx_mock.add_response(
            method="GET",
            url="https://apihub.fluvius.be/esco-sbx/v3/api/mandate",
            status_code=404,
        )

        with pytest.raises(NotFoundError):
            client_with_mock_token.get_mandates()

    def test_validation_error(self, client_with_mock_token, httpx_mock: HTTPXMock):
        httpx_mock.add_response(
            method="POST",
            url="https://apihub.fluvius.be/esco-sbx/v3/api/shortUrlIdentifier",
            status_code=400,
            json={
                "ValidationErrorMessages": [
                    "Property 'dataAccessContractNumber' is mandatory."
                ],
                "Type": "AppValidationException",
                "Code": "ModelValidation.Failed",
                "Message": "Model validation failed.",
            },
        )

        with pytest.raises(ValidationError) as exc_info:
            client_with_mock_token.create_client_session(
                data_access_contract_number="",
                reference_number="ref123",
                flow="B2B",
            )

        assert exc_info.value.validation_errors is not None
        assert len(exc_info.value.validation_errors) == 1

    def test_server_error(self, client_with_mock_token, httpx_mock: HTTPXMock):
        httpx_mock.add_response(
            method="GET",
            url="https://apihub.fluvius.be/esco-sbx/v3/api/mandate",
            status_code=500,
            json={
                "type": "InternalServerException",
                "code": "Server.Error",
                "message": "An internal error occurred.",
            },
        )

        with pytest.raises(ServerError):
            client_with_mock_token.get_mandates()

    def test_service_unavailable_error(
        self, client_with_mock_token, httpx_mock: HTTPXMock
    ):
        httpx_mock.add_response(
            method="GET",
            url="https://apihub.fluvius.be/esco-sbx/v3/api/mandate",
            status_code=503,
            json={
                "type": "MarketResourceUnavailableException",
                "code": "DependentResource.Market.Unavailable",
                "message": "Resource 'Market' is unavailable.",
            },
        )

        with pytest.raises(ServiceUnavailableError):
            client_with_mock_token.get_mandates()


class TestAuthorizationHeaders:
    def test_bearer_token_is_sent(self, client_with_mock_token, httpx_mock: HTTPXMock):
        httpx_mock.add_response(
            method="GET",
            url="https://apihub.fluvius.be/esco-sbx/v3/api/mandate",
            json={
                "data": {"mandates": []},
                "_meta": {"fetchTime": "2024-07-01T16:38:10Z"},
            },
        )

        client_with_mock_token.get_mandates()

        request = httpx_mock.get_requests()[0]
        assert request.headers["Authorization"] == "Bearer test-access-token"

    def test_subscription_key_is_sent(
        self, client_with_mock_token, httpx_mock: HTTPXMock
    ):
        httpx_mock.add_response(
            method="GET",
            url="https://apihub.fluvius.be/esco-sbx/v3/api/mandate",
            json={
                "data": {"mandates": []},
                "_meta": {"fetchTime": "2024-07-01T16:38:10Z"},
            },
        )

        client_with_mock_token.get_mandates()

        request = httpx_mock.get_requests()[0]
        assert request.headers["Ocp-Apim-Subscription-Key"] == "test-subscription-key"
