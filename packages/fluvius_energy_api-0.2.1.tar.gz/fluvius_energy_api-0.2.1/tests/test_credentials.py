"""Tests for FluviusCredentials configuration."""

import os
from pathlib import Path
from unittest.mock import patch
import base64

import pytest

from fluvius_energy_api import FluviusCredentials, ConfigurationError


SAMPLE_PRIVATE_KEY = """-----BEGIN RSA PRIVATE KEY-----
MIIEpAIBAAKCAQEArvybc5ow0qR/rIEQGz3RpVjgY7rP4Gj4d+ByQVJWxKuTsYuO
FpjVWXb5EvNC2q0A/AYGMj24B8IAp/jSaQRO5JLmzKdxIE2uWAqhWr49EdcDpZMA
EvuAcuyi/sOSSmskFC/PcdH3eTTZ33VfSoFUD9m9cIB37VHTKr8q6DjusvuFctCR
Xn2UFCd0xYkvTxhmvyaFt86R2VdSurmnY+OGW+ehD99MkBY3GNXrjleJ/8lojELo
FLCU5MCgrY42F7/zSn6bfV+HbNxmRY8jeKKmiate61PQ9nQbIbJS1Nu42V3eJeBQ
EdqXmgAif+1IHgUTwX4poQ7Ve7zNlpevg1R6OQIDAQABAoIBAAbnKCq99mxuLisx
RuAMPEJNk0Hb6L9tj1ULTEvkt6TihTJdKFRz4Fa7KXA58HU38JtV5tYB4Un3uUGR
wJsr9FYdWsV6sC0aDg/4Zg0dBsO2u7TDFnRT6j6eXypgWgZdhlAq4qrBdwXCXqXr
YhWfrHVDna7bzTSrea0XWtX2XlQ+eaX2X6Ks4/FLgE5Tg8AuGkCnBMi3FeM6MK9r
irDq5nf9KLhOB8oqT8AtGWvM8xxT9L2BFuhnh9G3KaKmGVxyzw2fuE0SctnBt3d/
nQBWeV8pKfNhgoWzd4sROcYPDodrfn+1qvjT/d9IHk4MW3Hyl/uBaAsnylCM4x9S
gAQ56AECgYEA9O1+BmUA21nIB09SLe/ntRCX99vmISXG728UjHa1LOHe+F4U+N81
U9jnCL5snYq57/1sCJHSeUisHDRjMEYsFiGr0F4hMhR4QmPZUFnhaj3DvEK+++wm
rA3+GWfBmSkwxzCJa2HYIz9GwsYhS6uy1sDkVJJG/dyuqo+N6Yiu53kCgYEAtuWz
KQnwP/icyybibz+VlfKOiz6tTG3YnX3st/4v3NJDvJ4cLJd0CjcinUbnM+Oox8Lw
13ERDE2gAIf7OmCLukL0RQlRnfCP2hcj4rRC2T8cd9PwiM6PuF1uTIJGsM3yJdL+
9kOWDqI3stH1S282+08mv+C4P+OGLn460h6huMECgYEAtQRhQ/CaNYOhZmWlYvYP
1a4x4qnO52i4InWCRl3lgQpedEl0TosJKrL/7WJve+/vhANUOPEtER44tY+yTxdN
tf2kshcfiZe/WbHaBpynEJIde6II7L+XxUmCJtycJMpglpa0uXxS9ZnqfkFYkkiP
oFBncGm7thvHq571T0gJnGECgYA1jfD2FVjqAmw2+D3ZgW7Vp16h20p3VLrW8uZ7
wcxWBqOa+VkanYZ270oNb5OHmCP1ylknXI43Ygt13Ftt7pM7iRtpk574dlZI7/ms
CkiAwIAffkmyZXmj7Ie9k3ALmWJMPQo3JfcsdceFbwE6g2hAEh8wlCafXooN1xx2
Jk4IgQKBgQC/0LiJEVVHJQ6Fjs7UgqxTj6Mb9mW5TM66+GDd5TiHajUtPhU+mBPf
v26qcizM9vYilXzR37u6srYdQMhi2xd0JdxkI/U4J29pr5d/tpLLE3ArWJmTwPhr
gYbIR6Hty8dKqMfoIDN0G94KAm6leZwU2aRJMR3r4eOY50uvJ6OIFw==
-----END RSA PRIVATE KEY-----"""


class TestFluviusCredentialsInit:
    def test_valid_credentials(self):
        credentials = FluviusCredentials(
            subscription_key="test-key",
            client_id="test-client-id",
            tenant_id="test-tenant-id",
            scope="api://test-scope/.default",
            certificate_thumbprint="AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",
            private_key=SAMPLE_PRIVATE_KEY,
            data_access_contract_number="1234567890",
        )
        assert credentials.subscription_key == "test-key"
        assert credentials.client_id == "test-client-id"
        assert credentials.private_key == SAMPLE_PRIVATE_KEY
        assert credentials.data_access_contract_number == "1234567890"

    def test_missing_subscription_key(self):
        with pytest.raises(ConfigurationError) as exc_info:
            FluviusCredentials(
                subscription_key="",
                client_id="test-client-id",
                tenant_id="test-tenant-id",
                scope="api://test-scope/.default",
                certificate_thumbprint="thumbprint",
                private_key=SAMPLE_PRIVATE_KEY,
                data_access_contract_number="1234567890",
            )
        assert "subscription_key" in str(exc_info.value)

    def test_missing_client_id(self):
        with pytest.raises(ConfigurationError) as exc_info:
            FluviusCredentials(
                subscription_key="test-key",
                client_id="",
                tenant_id="test-tenant-id",
                scope="api://test-scope/.default",
                certificate_thumbprint="thumbprint",
                private_key=SAMPLE_PRIVATE_KEY,
                data_access_contract_number="1234567890",
            )
        assert "client_id" in str(exc_info.value)

    def test_missing_private_key(self):
        with pytest.raises(ConfigurationError) as exc_info:
            FluviusCredentials(
                subscription_key="test-key",
                client_id="test-client-id",
                tenant_id="test-tenant-id",
                scope="api://test-scope/.default",
                certificate_thumbprint="thumbprint",
                private_key="",
                data_access_contract_number="1234567890",
            )
        assert "private_key" in str(exc_info.value)

    def test_missing_data_access_contract_number(self):
        with pytest.raises(ConfigurationError) as exc_info:
            FluviusCredentials(
                subscription_key="test-key",
                client_id="test-client-id",
                tenant_id="test-tenant-id",
                scope="api://test-scope/.default",
                certificate_thumbprint="thumbprint",
                private_key=SAMPLE_PRIVATE_KEY,
                data_access_contract_number="",
            )
        assert "data_access_contract_number" in str(exc_info.value)

    def test_whitespace_only_values(self):
        with pytest.raises(ConfigurationError) as exc_info:
            FluviusCredentials(
                subscription_key="   ",
                client_id="test-client-id",
                tenant_id="test-tenant-id",
                scope="api://test-scope/.default",
                certificate_thumbprint="thumbprint",
                private_key=SAMPLE_PRIVATE_KEY,
                data_access_contract_number="1234567890",
            )
        assert "subscription_key" in str(exc_info.value)


class TestFluviusCredentialsFromEnv:
    def test_load_from_env_variables(self):
        env_vars = {
            "FLUVIUS_SUBSCRIPTION_KEY": "env-subscription-key",
            "FLUVIUS_CLIENT_ID": "env-client-id",
            "FLUVIUS_TENANT_ID": "env-tenant-id",
            "FLUVIUS_SCOPE": "api://env-scope/.default",
            "FLUVIUS_CERTIFICATE_THUMBPRINT": "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",
            "FLUVIUS_PRIVATE_KEY": SAMPLE_PRIVATE_KEY,
            "FLUVIUS_DATA_ACCESS_CONTRACT_NUMBER": "1234567890",
        }
        with patch.dict(os.environ, env_vars, clear=False):
            credentials = FluviusCredentials.from_env()

        assert credentials.subscription_key == "env-subscription-key"
        assert credentials.client_id == "env-client-id"
        assert credentials.tenant_id == "env-tenant-id"
        assert credentials.scope == "api://env-scope/.default"
        assert credentials.certificate_thumbprint == "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
        assert credentials.private_key == SAMPLE_PRIVATE_KEY
        assert credentials.data_access_contract_number == "1234567890"

    def test_missing_env_variable(self):
        env_vars = {
            "FLUVIUS_SUBSCRIPTION_KEY": "env-subscription-key",
            "FLUVIUS_CLIENT_ID": "env-client-id",
            # Missing FLUVIUS_TENANT_ID
            "FLUVIUS_SCOPE": "api://env-scope/.default",
            "FLUVIUS_CERTIFICATE_THUMBPRINT": "thumbprint",
            "FLUVIUS_PRIVATE_KEY": SAMPLE_PRIVATE_KEY,
            "FLUVIUS_DATA_ACCESS_CONTRACT_NUMBER": "1234567890",
        }
        # Clear any existing env vars
        for key in ["FLUVIUS_TENANT_ID", "FLUVIUS_PRIVATE_KEY_PATH"]:
            if key in os.environ:
                del os.environ[key]

        with patch.dict(os.environ, env_vars, clear=False):
            with pytest.raises(ConfigurationError) as exc_info:
                FluviusCredentials.from_env()
        assert "tenant_id" in str(exc_info.value)

    def test_missing_data_access_contract_number_env(self):
        env_vars = {
            "FLUVIUS_SUBSCRIPTION_KEY": "env-subscription-key",
            "FLUVIUS_CLIENT_ID": "env-client-id",
            "FLUVIUS_TENANT_ID": "env-tenant-id",
            "FLUVIUS_SCOPE": "api://env-scope/.default",
            "FLUVIUS_CLIENT_SECRET": "test-secret",
        }
        with patch.dict(os.environ, env_vars, clear=False):
            os.environ.pop("FLUVIUS_DATA_ACCESS_CONTRACT_NUMBER", None)
            with pytest.raises(ConfigurationError) as exc_info:
                FluviusCredentials.from_env()
        assert "data_access_contract_number" in str(exc_info.value)

    def test_load_base64_encoded_key(self):
        encoded_key = base64.b64encode(SAMPLE_PRIVATE_KEY.encode()).decode()
        env_vars = {
            "FLUVIUS_SUBSCRIPTION_KEY": "env-subscription-key",
            "FLUVIUS_CLIENT_ID": "env-client-id",
            "FLUVIUS_TENANT_ID": "env-tenant-id",
            "FLUVIUS_SCOPE": "api://env-scope/.default",
            "FLUVIUS_CERTIFICATE_THUMBPRINT": "thumbprint",
            "FLUVIUS_PRIVATE_KEY": encoded_key,
            "FLUVIUS_DATA_ACCESS_CONTRACT_NUMBER": "1234567890",
        }
        with patch.dict(os.environ, env_vars, clear=False):
            credentials = FluviusCredentials.from_env()

        assert credentials.private_key == SAMPLE_PRIVATE_KEY

    def test_load_key_from_file(self, tmp_path: Path):
        key_file = tmp_path / "private_key.pem"
        key_file.write_text(SAMPLE_PRIVATE_KEY)

        env_vars = {
            "FLUVIUS_SUBSCRIPTION_KEY": "env-subscription-key",
            "FLUVIUS_CLIENT_ID": "env-client-id",
            "FLUVIUS_TENANT_ID": "env-tenant-id",
            "FLUVIUS_SCOPE": "api://env-scope/.default",
            "FLUVIUS_CERTIFICATE_THUMBPRINT": "thumbprint",
            "FLUVIUS_PRIVATE_KEY_PATH": str(key_file),
            "FLUVIUS_DATA_ACCESS_CONTRACT_NUMBER": "1234567890",
        }
        # Remove FLUVIUS_PRIVATE_KEY if set
        env_to_clear = {k: v for k, v in env_vars.items()}
        with patch.dict(os.environ, env_to_clear, clear=False):
            # Ensure FLUVIUS_PRIVATE_KEY is not set
            os.environ.pop("FLUVIUS_PRIVATE_KEY", None)
            credentials = FluviusCredentials.from_env()

        assert credentials.private_key == SAMPLE_PRIVATE_KEY

    def test_key_file_not_found(self):
        env_vars = {
            "FLUVIUS_SUBSCRIPTION_KEY": "env-subscription-key",
            "FLUVIUS_CLIENT_ID": "env-client-id",
            "FLUVIUS_TENANT_ID": "env-tenant-id",
            "FLUVIUS_SCOPE": "api://env-scope/.default",
            "FLUVIUS_CERTIFICATE_THUMBPRINT": "thumbprint",
            "FLUVIUS_PRIVATE_KEY_PATH": "/nonexistent/path/key.pem",
            "FLUVIUS_DATA_ACCESS_CONTRACT_NUMBER": "1234567890",
        }
        with patch.dict(os.environ, env_vars, clear=False):
            os.environ.pop("FLUVIUS_PRIVATE_KEY", None)
            with pytest.raises(ConfigurationError) as exc_info:
                FluviusCredentials.from_env()
        assert "not found" in str(exc_info.value)

    def test_inline_key_takes_precedence_over_file(self, tmp_path: Path):
        key_file = tmp_path / "private_key.pem"
        key_file.write_text("file key content")

        env_vars = {
            "FLUVIUS_SUBSCRIPTION_KEY": "env-subscription-key",
            "FLUVIUS_CLIENT_ID": "env-client-id",
            "FLUVIUS_TENANT_ID": "env-tenant-id",
            "FLUVIUS_SCOPE": "api://env-scope/.default",
            "FLUVIUS_CERTIFICATE_THUMBPRINT": "thumbprint",
            "FLUVIUS_PRIVATE_KEY": SAMPLE_PRIVATE_KEY,
            "FLUVIUS_PRIVATE_KEY_PATH": str(key_file),
            "FLUVIUS_DATA_ACCESS_CONTRACT_NUMBER": "1234567890",
        }
        with patch.dict(os.environ, env_vars, clear=False):
            credentials = FluviusCredentials.from_env()

        # Inline key should take precedence
        assert credentials.private_key == SAMPLE_PRIVATE_KEY

    def test_custom_prefix_for_sandbox(self):
        env_vars = {
            "FLUVIUS_SANDBOX_SUBSCRIPTION_KEY": "sandbox-subscription-key",
            "FLUVIUS_SANDBOX_CLIENT_ID": "sandbox-client-id",
            "FLUVIUS_SANDBOX_TENANT_ID": "sandbox-tenant-id",
            "FLUVIUS_SANDBOX_SCOPE": "api://sandbox-scope/.default",
            "FLUVIUS_SANDBOX_CERTIFICATE_THUMBPRINT": "sandbox-thumbprint",
            "FLUVIUS_SANDBOX_PRIVATE_KEY": SAMPLE_PRIVATE_KEY,
            "FLUVIUS_SANDBOX_DATA_ACCESS_CONTRACT_NUMBER": "1234567890",
        }
        with patch.dict(os.environ, env_vars, clear=False):
            credentials = FluviusCredentials.from_env(prefix="FLUVIUS_SANDBOX")

        assert credentials.subscription_key == "sandbox-subscription-key"
        assert credentials.client_id == "sandbox-client-id"
        assert credentials.tenant_id == "sandbox-tenant-id"
        assert credentials.scope == "api://sandbox-scope/.default"
        assert credentials.certificate_thumbprint == "sandbox-thumbprint"

    def test_both_prefixes_can_coexist(self):
        env_vars = {
            # Production credentials
            "FLUVIUS_SUBSCRIPTION_KEY": "prod-subscription-key",
            "FLUVIUS_CLIENT_ID": "prod-client-id",
            "FLUVIUS_TENANT_ID": "prod-tenant-id",
            "FLUVIUS_SCOPE": "api://prod-scope/.default",
            "FLUVIUS_CERTIFICATE_THUMBPRINT": "prod-thumbprint",
            "FLUVIUS_PRIVATE_KEY": SAMPLE_PRIVATE_KEY,
            "FLUVIUS_DATA_ACCESS_CONTRACT_NUMBER": "1234567890",
            # Sandbox credentials
            "FLUVIUS_SANDBOX_SUBSCRIPTION_KEY": "sandbox-subscription-key",
            "FLUVIUS_SANDBOX_CLIENT_ID": "sandbox-client-id",
            "FLUVIUS_SANDBOX_TENANT_ID": "sandbox-tenant-id",
            "FLUVIUS_SANDBOX_SCOPE": "api://sandbox-scope/.default",
            "FLUVIUS_SANDBOX_CERTIFICATE_THUMBPRINT": "sandbox-thumbprint",
            "FLUVIUS_SANDBOX_PRIVATE_KEY": SAMPLE_PRIVATE_KEY,
            "FLUVIUS_SANDBOX_DATA_ACCESS_CONTRACT_NUMBER": "sandbox-contract",
        }
        with patch.dict(os.environ, env_vars, clear=False):
            prod_creds = FluviusCredentials.from_env()
            sandbox_creds = FluviusCredentials.from_env(prefix="FLUVIUS_SANDBOX")

        assert prod_creds.subscription_key == "prod-subscription-key"
        assert sandbox_creds.subscription_key == "sandbox-subscription-key"


class TestClientSecretAuth:
    def test_client_secret_credentials(self):
        credentials = FluviusCredentials(
            subscription_key="test-key",
            client_id="test-client-id",
            tenant_id="test-tenant-id",
            scope="api://test-scope/.default",
            client_secret="test-secret",
            data_access_contract_number="1234567890",
        )
        assert credentials.client_secret == "test-secret"
        assert credentials.uses_certificate is False

    def test_certificate_credentials(self):
        credentials = FluviusCredentials(
            subscription_key="test-key",
            client_id="test-client-id",
            tenant_id="test-tenant-id",
            scope="api://test-scope/.default",
            certificate_thumbprint="AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",
            private_key=SAMPLE_PRIVATE_KEY,
            data_access_contract_number="1234567890",
        )
        assert credentials.uses_certificate is True

    def test_missing_both_auth_methods(self):
        with pytest.raises(ConfigurationError) as exc_info:
            FluviusCredentials(
                subscription_key="test-key",
                client_id="test-client-id",
                tenant_id="test-tenant-id",
                scope="api://test-scope/.default",
                data_access_contract_number="1234567890",
            )
        assert "certificate_thumbprint" in str(exc_info.value) or "client_secret" in str(exc_info.value)

    def test_sandbox_with_client_secret_from_env(self):
        env_vars = {
            "FLUVIUS_SUBSCRIPTION_KEY": "shared-subscription-key",
            "FLUVIUS_CLIENT_ID": "shared-client-id",
            "FLUVIUS_TENANT_ID": "shared-tenant-id",
            "FLUVIUS_SCOPE": "api://shared-scope/.default",
            "FLUVIUS_DATA_ACCESS_CONTRACT_NUMBER": "1234567890",
            "FLUVIUS_SANDBOX_CLIENT_SECRET": "sandbox-secret",
        }
        with patch.dict(os.environ, env_vars, clear=False):
            credentials = FluviusCredentials.from_env(prefix="FLUVIUS_SANDBOX")

        assert credentials.subscription_key == "shared-subscription-key"
        assert credentials.client_secret == "sandbox-secret"
        assert credentials.uses_certificate is False


class TestDataAccessContractNumber:
    def test_data_access_contract_number_from_env(self):
        env_vars = {
            "FLUVIUS_SUBSCRIPTION_KEY": "env-subscription-key",
            "FLUVIUS_CLIENT_ID": "env-client-id",
            "FLUVIUS_TENANT_ID": "env-tenant-id",
            "FLUVIUS_SCOPE": "api://env-scope/.default",
            "FLUVIUS_CLIENT_SECRET": "test-secret",
            "FLUVIUS_DATA_ACCESS_CONTRACT_NUMBER": "1234567890",
        }
        with patch.dict(os.environ, env_vars, clear=False):
            credentials = FluviusCredentials.from_env()

        assert credentials.data_access_contract_number == "1234567890"

    def test_data_access_contract_number_with_prefix_fallback(self):
        env_vars = {
            "FLUVIUS_SUBSCRIPTION_KEY": "shared-subscription-key",
            "FLUVIUS_CLIENT_ID": "shared-client-id",
            "FLUVIUS_TENANT_ID": "shared-tenant-id",
            "FLUVIUS_SCOPE": "api://shared-scope/.default",
            "FLUVIUS_DATA_ACCESS_CONTRACT_NUMBER": "shared-contract",
            "FLUVIUS_SANDBOX_CLIENT_SECRET": "sandbox-secret",
        }
        with patch.dict(os.environ, env_vars, clear=False):
            credentials = FluviusCredentials.from_env(prefix="FLUVIUS_SANDBOX")

        # Should fall back to FLUVIUS_DATA_ACCESS_CONTRACT_NUMBER
        assert credentials.data_access_contract_number == "shared-contract"


class TestCredentialsImmutability:
    def test_credentials_are_frozen(self):
        credentials = FluviusCredentials(
            subscription_key="test-key",
            client_id="test-client-id",
            tenant_id="test-tenant-id",
            scope="api://test-scope/.default",
            certificate_thumbprint="thumbprint",
            private_key=SAMPLE_PRIVATE_KEY,
            data_access_contract_number="1234567890",
        )
        with pytest.raises(AttributeError):
            credentials.subscription_key = "new-key"
