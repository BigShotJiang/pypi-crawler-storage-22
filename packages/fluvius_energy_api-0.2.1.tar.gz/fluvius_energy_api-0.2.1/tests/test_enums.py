"""Tests for enum definitions."""


from fluvius_energy_api import (
    CreateClientSessionStatus,
    DataServiceType,
    EnergyType,
    EstimatedVolumeType,
    Flow,
    GasConversionFactor,
    LocalProductionInstallationType,
    MandateRenewalStatus,
    MandateStatus,
    MeasurementValidationState,
    MeterType,
    PeriodType,
    Register,
    Unit,
)


class TestCreateClientSessionStatus:
    def test_values(self):
        assert CreateClientSessionStatus.SUCCESS.value == "success"
        assert CreateClientSessionStatus.FAILED.value == "failed"

    def test_all_values_exist(self):
        assert len(CreateClientSessionStatus) == 2


class TestDataServiceType:
    def test_values(self):
        assert DataServiceType.VH_ONBEPAALD.value == "VH_onbepaald"
        assert DataServiceType.VH_KWARTIER_UUR.value == "VH_kwartier_uur"
        assert DataServiceType.VH_DAG.value == "VH_dag"
        assert DataServiceType.IG.value == "IG"

    def test_all_values_exist(self):
        assert len(DataServiceType) == 4


class TestEnergyType:
    def test_values(self):
        assert EnergyType.ELECTRICITY.value == "E"
        assert EnergyType.GAS.value == "G"

    def test_all_values_exist(self):
        assert len(EnergyType) == 2


class TestEstimatedVolumeType:
    def test_values(self):
        assert EstimatedVolumeType.EAV.value == "EAV"

    def test_all_values_exist(self):
        assert len(EstimatedVolumeType) == 1


class TestFlow:
    def test_values(self):
        assert Flow.B2C.value == "B2C"
        assert Flow.B2B.value == "B2B"

    def test_all_values_exist(self):
        assert len(Flow) == 2


class TestGasConversionFactor:
    def test_values(self):
        assert GasConversionFactor.PREDICTIVE.value == "P"
        assert GasConversionFactor.DEFINITIVE.value == "D"
        assert GasConversionFactor.CONSTANT.value == "C"

    def test_all_values_exist(self):
        assert len(GasConversionFactor) == 3


class TestLocalProductionInstallationType:
    def test_common_values(self):
        assert LocalProductionInstallationType.UNKNOWN.value == "?"
        assert LocalProductionInstallationType.PV.value == "PV"
        assert LocalProductionInstallationType.BAT.value == "BAT"
        assert LocalProductionInstallationType.WND.value == "WND"

    def test_all_values_exist(self):
        assert len(LocalProductionInstallationType) == 18


class TestMandateRenewalStatus:
    def test_values(self):
        assert MandateRenewalStatus.TO_BE_RENEWED.value == "ToBeRenewed"
        assert MandateRenewalStatus.RENEWAL_REQUESTED.value == "RenewalRequested"
        assert MandateRenewalStatus.EXPIRED.value == "Expired"

    def test_all_values_exist(self):
        assert len(MandateRenewalStatus) == 3


class TestMandateStatus:
    def test_values(self):
        assert MandateStatus.REQUESTED.value == "Requested"
        assert MandateStatus.APPROVED.value == "Approved"
        assert MandateStatus.REJECTED.value == "Rejected"
        assert MandateStatus.FINISHED.value == "Finished"

    def test_all_values_exist(self):
        assert len(MandateStatus) == 4


class TestMeasurementValidationState:
    def test_values(self):
        assert MeasurementValidationState.READ.value == "READ"
        assert MeasurementValidationState.EST.value == "EST"
        assert MeasurementValidationState.VAL.value == "VAL"
        assert MeasurementValidationState.NVAL.value == "NVAL"

    def test_all_values_exist(self):
        assert len(MeasurementValidationState) == 4


class TestMeterType:
    def test_values(self):
        assert MeterType.KM.value == "KM"
        assert MeterType.DM.value == "DM"

    def test_all_values_exist(self):
        assert len(MeterType) == 2


class TestPeriodType:
    def test_values(self):
        assert PeriodType.READ_TIME.value == "readTime"
        assert PeriodType.INSERT_TIME.value == "insertTime"

    def test_all_values_exist(self):
        assert len(PeriodType) == 2


class TestRegister:
    def test_common_values(self):
        assert Register.UNKNOWN.value == "Unknown"
        assert Register.OFFTAKE_HIGH.value == "OfftakeHigh"
        assert Register.OFFTAKE_LOW.value == "OfftakeLow"
        assert Register.INJECTION_HIGH.value == "InjectionHigh"

    def test_all_values_exist(self):
        assert len(Register) == 11


class TestUnit:
    def test_values(self):
        assert Unit.UNKNOWN.value == "?"
        assert Unit.KVA.value == "kVA"
        assert Unit.KVARH.value == "kVArh"
        assert Unit.KWH.value == "kWh"
        assert Unit.KW.value == "kW"
        assert Unit.M3.value == "m3"

    def test_all_values_exist(self):
        assert len(Unit) == 6
