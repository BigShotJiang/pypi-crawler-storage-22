"""Tests for custom exceptions."""


from fluvius_energy_api import (
    FluviusAPIError,
    AuthenticationError,
    ConfigurationError,
    ForbiddenError,
    NotFoundError,
    ValidationError,
    ServerError,
    ServiceUnavailableError,
    ErrorResponse,
    ErrorValidationResponse,
)


class TestFluviusAPIError:
    def test_basic_error(self):
        error = FluviusAPIError("Something went wrong")
        assert str(error) == "Something went wrong"
        assert error.message == "Something went wrong"
        assert error.status_code is None
        assert error.error_response is None

    def test_error_with_status_code(self):
        error = FluviusAPIError("Not found", status_code=404)
        assert str(error) == "[404] Not found"
        assert error.status_code == 404

    def test_error_with_response(self):
        error_response = ErrorResponse(
            type="TestException",
            code="Test.Error",
            message="Test message",
        )
        error = FluviusAPIError(
            "Error occurred", status_code=500, error_response=error_response
        )
        assert error.error_response.type == "TestException"


class TestAuthenticationError:
    def test_default_message(self):
        error = AuthenticationError()
        assert error.status_code == 401
        assert "Authentication failed" in str(error)

    def test_custom_message(self):
        error = AuthenticationError("Invalid token")
        assert str(error) == "[401] Invalid token"


class TestForbiddenError:
    def test_default_message(self):
        error = ForbiddenError()
        assert error.status_code == 403
        assert "forbidden" in str(error).lower()

    def test_custom_message(self):
        error = ForbiddenError("Access denied")
        assert str(error) == "[403] Access denied"


class TestNotFoundError:
    def test_default_message(self):
        error = NotFoundError()
        assert error.status_code == 404
        assert "not found" in str(error).lower()

    def test_custom_message(self):
        error = NotFoundError("Resource does not exist")
        assert str(error) == "[404] Resource does not exist"


class TestValidationError:
    def test_default_message(self):
        error = ValidationError()
        assert error.status_code == 400
        assert error.validation_errors is None

    def test_with_validation_errors(self):
        error_response = ErrorValidationResponse(
            type="AppValidationException",
            code="ModelValidation.Failed",
            message="Validation failed",
            validation_error_messages=[
                "Field 'ean' is required",
                "Field 'referenceNumber' is required",
            ],
        )
        error = ValidationError("Validation failed", error_response=error_response)
        assert error.status_code == 400
        assert len(error.validation_errors) == 2
        assert "Field 'ean' is required" in error.validation_errors


class TestServerError:
    def test_default_message(self):
        error = ServerError()
        assert error.status_code == 500
        assert "server error" in str(error).lower()

    def test_custom_message(self):
        error = ServerError("Database connection failed")
        assert str(error) == "[500] Database connection failed"


class TestServiceUnavailableError:
    def test_default_message(self):
        error = ServiceUnavailableError()
        assert error.status_code == 503
        assert "unavailable" in str(error).lower()

    def test_custom_message(self):
        error = ServiceUnavailableError("Maintenance in progress")
        assert str(error) == "[503] Maintenance in progress"


class TestConfigurationError:
    def test_message(self):
        error = ConfigurationError("Missing required credential")
        assert str(error) == "Missing required credential"
        assert error.status_code is None

    def test_inherits_from_base(self):
        error = ConfigurationError("test")
        assert isinstance(error, FluviusAPIError)


class TestExceptionHierarchy:
    def test_all_exceptions_inherit_from_base(self):
        assert issubclass(AuthenticationError, FluviusAPIError)
        assert issubclass(ConfigurationError, FluviusAPIError)
        assert issubclass(ForbiddenError, FluviusAPIError)
        assert issubclass(NotFoundError, FluviusAPIError)
        assert issubclass(ValidationError, FluviusAPIError)
        assert issubclass(ServerError, FluviusAPIError)
        assert issubclass(ServiceUnavailableError, FluviusAPIError)

    def test_can_catch_all_with_base(self):
        exceptions = [
            AuthenticationError(),
            ForbiddenError(),
            NotFoundError(),
            ValidationError(),
            ServerError(),
            ServiceUnavailableError(),
        ]
        for exc in exceptions:
            try:
                raise exc
            except FluviusAPIError as e:
                assert e.status_code is not None
