"""Tests for Pydantic models."""


from fluvius_energy_api import (
    # Session models
    ClientSessionDataService,
    CreateClientSessionRequest,
    CreateClientSessionResponse,
    CreateClientSessionResponseApiDataResponse,
    # Mandate models
    Mandate,
    GetMandatesResponse,
    GetMandatesResponseApiDataResponse,
    # Energy models
    MeasurementValue,
    MeasurementValueSet,
    MeasurementDirection,
    MeasurementTimeSlice,
    PhysicalMeter,
    MeteringOnMeter,
    MeteringOnHeadpoint,
    MeteringOnHeadpointAndMeter,
    GetEnergyResponse,
    GetEnergyResponseApiDataResponse,
    # Installation models
    LocalProductionInstallation,
    EstimatedVolume,
    Installation,
    GetInstallationResponse,
    GetInstallationResponseApiDataResponse,
    # Base models
    ResponseMetadata,
    ErrorResponse,
    ErrorValidationResponse,
    # Enums
    DataServiceType,
    Flow,
    CreateClientSessionStatus,
    MandateStatus,
    EnergyType,
    MeasurementValidationState,
    Unit,
)


class TestResponseMetadata:
    def test_parse_from_json(self):
        data = {"fetchTime": "2024-07-01T16:38:10Z"}
        meta = ResponseMetadata.model_validate(data)
        assert meta.fetch_time is not None

    def test_empty(self):
        meta = ResponseMetadata()
        assert meta.fetch_time is None


class TestErrorResponse:
    def test_parse_from_json(self):
        data = {
            "Type": "ClientSessionCreationException",
            "Code": "ClientSession.CreateFailed",
            "Message": "Unable to create a client session.",
        }
        error = ErrorResponse.model_validate(data)
        assert error.type == "ClientSessionCreationException"
        assert error.code == "ClientSession.CreateFailed"
        assert error.message == "Unable to create a client session."


class TestErrorValidationResponse:
    def test_parse_from_json(self):
        data = {
            "ValidationErrorMessages": [
                "Property 'dataAccessContractNumber' is mandatory."
            ],
            "Type": "AppValidationException",
            "Code": "ModelValidation.Failed",
            "Message": "Model validation failed.",
        }
        error = ErrorValidationResponse.model_validate(data)
        assert error.type == "AppValidationException"
        assert len(error.validation_error_messages) == 1


class TestClientSessionDataService:
    def test_parse_from_json(self):
        data = {
            "dataServiceType": "VH_dag",
            "dataPeriodFrom": "2020-03-01T23:00:00Z",
            "dataPeriodTo": "2023-03-01T23:00:00Z",
        }
        service = ClientSessionDataService.model_validate(data)
        assert service.data_service_type == DataServiceType.VH_DAG
        assert service.data_period_from == "2020-03-01T23:00:00Z"

    def test_serialize_to_json(self):
        service = ClientSessionDataService(
            data_service_type=DataServiceType.VH_DAG,
            data_period_from="2020-03-01T23:00:00Z",
        )
        data = service.model_dump(by_alias=True, exclude_none=True)
        assert data["dataServiceType"] == "VH_dag"
        assert data["dataPeriodFrom"] == "2020-03-01T23:00:00Z"


class TestCreateClientSessionRequest:
    def test_serialize_to_json(self):
        request = CreateClientSessionRequest(
            data_access_contract_number="3599900040",
            reference_number="edv6841D1C2E41344109EC1C5B41F2CBCCC",
            flow=Flow.B2B,
            number_of_eans=2,
        )
        data = request.model_dump(by_alias=True, exclude_none=True)
        assert data["dataAccessContractNumber"] == "3599900040"
        assert data["referenceNumber"] == "edv6841D1C2E41344109EC1C5B41F2CBCCC"
        assert data["flow"] == "B2B"
        assert data["numberOfEans"] == 2

    def test_serialize_with_data_services(self):
        request = CreateClientSessionRequest(
            data_access_contract_number="3599900040",
            reference_number="ref123",
            flow=Flow.B2C,
            data_services=[
                ClientSessionDataService(
                    data_service_type=DataServiceType.VH_KWARTIER_UUR,
                )
            ],
        )
        data = request.model_dump(by_alias=True, exclude_none=True)
        assert len(data["dataServices"]) == 1
        assert data["dataServices"][0]["dataServiceType"] == "VH_kwartier_uur"


class TestCreateClientSessionResponse:
    def test_parse_success_response(self):
        data = {
            "data": {
                "status": "success",
                "shortUrlIdentifier": "ed9bfb8018408059853b1b29949d3cbcedb5b2ba672eb8dadadc68d2828be824",
                "validTo": "2026-01-28T00:00:00Z",
            },
            "_meta": {"fetchTime": "2026-01-27T15:15:57Z"},
        }
        response = CreateClientSessionResponseApiDataResponse.model_validate(data)
        assert response.data.status == CreateClientSessionStatus.SUCCESS
        assert response.data.short_url_identifier is not None
        assert response.data.valid_to is not None

    def test_parse_failed_response(self):
        data = {
            "data": {"status": "failed"},
            "_meta": {"fetchTime": "2026-01-27T15:15:57Z"},
        }
        response = CreateClientSessionResponseApiDataResponse.model_validate(data)
        assert response.data.status == CreateClientSessionStatus.FAILED
        assert response.data.short_url_identifier is None


class TestMandate:
    def test_parse_from_json(self):
        data = {
            "referenceNumber": "edv6841D1C2E41344109EC1C5B41F2CBCCC",
            "status": "Approved",
            "ean": "541448800000004312",
            "energyType": "E",
            "dataPeriodFrom": "2025-01-26T22:00:00Z",
            "dataPeriodTo": "2024-07-26T22:00:00Z",
            "dataServiceType": "VH_dag",
            "mandateExpirationDate": "2024-08-26T22:00:00Z",
            "renewalStatus": "ToBeRenewed",
        }
        mandate = Mandate.model_validate(data)
        assert mandate.reference_number == "edv6841D1C2E41344109EC1C5B41F2CBCCC"
        assert mandate.status == MandateStatus.APPROVED
        assert mandate.ean == "541448800000004312"
        assert mandate.energy_type == EnergyType.ELECTRICITY


class TestGetMandatesResponseApiDataResponse:
    def test_parse_from_json(self):
        data = {
            "data": {
                "mandates": [
                    {
                        "referenceNumber": "ref123",
                        "status": "Approved",
                        "ean": "541448800000004312",
                        "energyType": "E",
                        "dataServiceType": "VH_dag",
                    },
                    {
                        "referenceNumber": "ref123",
                        "status": "Approved",
                        "ean": "541448800000004312",
                        "energyType": "E",
                        "dataServiceType": "VH_kwartier_uur",
                    },
                ]
            },
            "_meta": {"fetchTime": "2024-07-01T16:38:10Z"},
        }
        response = GetMandatesResponseApiDataResponse.model_validate(data)
        assert len(response.data.mandates) == 2
        assert response.meta is not None


class TestMeasurementModels:
    def test_measurement_value(self):
        data = {"value": 12.580, "unit": "kWh", "validationState": "READ"}
        mv = MeasurementValue.model_validate(data)
        assert mv.value == 12.580
        assert mv.unit == Unit.KWH
        assert mv.validation_state == MeasurementValidationState.READ

    def test_measurement_value_set(self):
        data = {
            "day": {"value": 12.580, "unit": "kWh", "validationState": "READ"},
            "night": {"value": 20.140, "unit": "kWh", "validationState": "READ"},
        }
        mvs = MeasurementValueSet.model_validate(data)
        assert mvs.day.value == 12.580
        assert mvs.night.value == 20.140

    def test_measurement_direction(self):
        data = {
            "offtake": {
                "day": {"value": 12.580, "unit": "kWh"},
            },
            "injection": {
                "day": {"value": 4.800, "unit": "kWh"},
            },
        }
        md = MeasurementDirection.model_validate(data)
        assert md.offtake.day.value == 12.580
        assert md.injection.day.value == 4.800


class TestMeteringOnMeter:
    def test_parse_from_json(self):
        data = {
            "$type": "metering-on-meter",
            "ean": "541448800000004312",
            "energyType": "E",
            "physicalMeters": [
                {
                    "seqNumber": "1",
                    "meterID": "1SAG2120063032",
                    "dailyEnergy": [
                        {
                            "start": "2024-07-02T22:00:00Z",
                            "end": "2024-07-03T22:00:00Z",
                            "measurements": [
                                {
                                    "offtake": {
                                        "day": {"value": 12.580, "unit": "kWh"}
                                    }
                                }
                            ],
                        }
                    ],
                }
            ],
        }
        metering = MeteringOnMeter.model_validate(data)
        assert metering.type_discriminator == "metering-on-meter"
        assert metering.ean == "541448800000004312"
        assert len(metering.physical_meters) == 1
        assert metering.physical_meters[0].meter_id == "1SAG2120063032"


class TestMeteringOnHeadpoint:
    def test_parse_from_json(self):
        data = {
            "$type": "metering-on-headpoint",
            "ean": "541448800000004312",
            "energyType": "E",
            "dailyEnergy": [
                {
                    "start": "2024-07-02T22:00:00Z",
                    "end": "2024-07-03T22:00:00Z",
                    "measurements": [],
                }
            ],
        }
        metering = MeteringOnHeadpoint.model_validate(data)
        assert metering.type_discriminator == "metering-on-headpoint"
        assert len(metering.daily_energy) == 1


class TestGetEnergyResponseApiDataResponse:
    def test_parse_metering_on_meter(self):
        data = {
            "data": {
                "headpoint": {
                    "$type": "metering-on-meter",
                    "ean": "541448800000004312",
                    "energyType": "E",
                    "physicalMeters": [],
                }
            },
            "_meta": {"fetchTime": "2024-07-01T16:38:10Z"},
        }
        response = GetEnergyResponseApiDataResponse.model_validate(data)
        assert response.data.headpoint.type_discriminator == "metering-on-meter"

    def test_parse_metering_on_headpoint(self):
        data = {
            "data": {
                "headpoint": {
                    "$type": "metering-on-headpoint",
                    "ean": "541448800000004312",
                    "energyType": "G",
                    "dailyEnergy": [],
                }
            },
            "_meta": {"fetchTime": "2024-07-01T16:38:10Z"},
        }
        response = GetEnergyResponseApiDataResponse.model_validate(data)
        assert response.data.headpoint.type_discriminator == "metering-on-headpoint"


class TestInstallationModels:
    def test_local_production_installation(self):
        data = {
            "vregId": "G10345678",
            "type": "PV",
            "converterPower": 5.604,
            "converterPowerUnit": "kVA",
        }
        lpi = LocalProductionInstallation.model_validate(data)
        assert lpi.vreg_id == "G10345678"
        assert lpi.converter_power == 5.604

    def test_estimated_volume(self):
        data = {
            "type": "EAV",
            "calculatedRegister": "OfftakeHigh",
            "value": 1013,
            "unit": "kWh",
        }
        ev = EstimatedVolume.model_validate(data)
        assert ev.value == 1013

    def test_installation(self):
        data = {
            "energyType": "E",
            "meterType": "DM",
            "smr3": True,
            "localProductionInstallations": [{"vregId": "G10345678", "type": "PV"}],
            "estimatedVolumes": [{"type": "EAV", "value": 1013, "unit": "kWh"}],
        }
        installation = Installation.model_validate(data)
        assert installation.smr3 is True
        assert len(installation.local_production_installations) == 1
        assert len(installation.estimated_volumes) == 1
