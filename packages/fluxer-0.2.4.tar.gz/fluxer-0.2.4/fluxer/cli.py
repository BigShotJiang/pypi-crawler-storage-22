import sys
from pathlib import Path
from importlib.resources import files


# Dictionary of available commands and their templates
COMMANDS = {
    "init-api-db": ("api-db.py.txt", "api-db.py"),
    "init-api-main": ("api-main.py.txt", "api-main.py"),
    "init-api-security": ("api-security.py.txt", "api-security.py"),
    "init-form1": ("Form1.cs.txt", "Form1.cs"),
    "init-form1-designer": ("Form1.Designer.cs.txt", "Form1.Designer.cs"),
    "init-form2": ("Form2.cs.txt", "Form2.cs"),
    "init-form2-designer": ("Form2.Designer.cs.txt", "Form2.Designer.cs"),
    "init-form3": ("Form3.cs.txt", "Form3.cs"),
    "init-form3-designer": ("Form3.Designer.cs.txt", "Form3.Designer.cs"),
    "init-postman": ("postman.txt", "postman.json"),
    "init-program": ("Program.cs.txt", "Program.cs"),
    "init-toast-form": ("ToastForm.cs.txt", "ToastForm.cs"),
    "init-toast-form-designer": ("ToastForm.Designer.cs.txt", "ToastForm.Designer.cs"),
    "init-usercontrol1": ("UserControl1.cs.txt", "UserControl1.cs"),
    "init-usercontrol1-designer": ("UserControl1.Designer.cs.txt", "UserControl1.Designer.cs"),
    "init-usercontrol2": ("UserControl2.cs.txt", "UserControl2.cs"),
    "init-usercontrol2-designer": ("UserControl2.Designer.cs.txt", "UserControl2.Designer.cs"),
    "init-usercontrol3": ("UserControl3.cs.txt", "UserControl3.cs"),
    "init-usercontrol3-designer": ("UserControl3.Designer.cs.txt", "UserControl3.Designer.cs"),
    "init-web-index": ("web-index.txt", "web-index.html"),
    "init-web-js": ("web-js.txt", "web-js.js"),
}


def write_template(name, target_name):
    template_path = files("fluxer").joinpath(f"templates/{name}")
    content = template_path.read_text(encoding='utf-8')

    Path(target_name).write_text(content, encoding='utf-8')
    print(f"Создан файл: {target_name}")


def show_help():
    print("Использование: fluxer [команда]\n")
    print("Доступные команды:")
    print("-" * 50)
    for cmd, (template, output) in sorted(COMMANDS.items()):
        print(f"  {cmd:<30} → {output}")
    print("-" * 50)
    print("\nПримеры:")
    print("  fluxer init-web-js")
    print("  fluxer init-api-main")
    print("  fluxer -help")


def main():
    if len(sys.argv) < 2:
        show_help()
        return

    cmd = sys.argv[1]

    if cmd in ("-help", "--help", "-h", "help"):
        show_help()
    elif cmd in COMMANDS:
        template, output = COMMANDS[cmd]
        write_template(template, output)
    else:
        print(f"Неизвестная команда: {cmd}")
        print("Используйте 'fluxer -help' для справки")


if __name__ == "__main__":
    main()
