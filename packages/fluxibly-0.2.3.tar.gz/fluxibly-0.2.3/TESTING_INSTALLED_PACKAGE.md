# Testing Installed Fluxibly Package

This guide explains how to test fluxibly after installing from TestPyPI or PyPI, including reproducing the RAG template filling example.

## Quick Start

### 1. Install from TestPyPI

```bash
# Create a fresh environment
python3 -m venv test-env
source test-env/bin/activate  # On Windows: test-env\Scripts\activate

# Install fluxibly
pip install --index-url https://test.pypi.org/simple/ \
            --extra-index-url https://pypi.org/simple/ \
            fluxibly

# Install optional dependencies for testing
pip install python-dotenv
```

### 2. Set Up API Key

```bash
# Set environment variable
export ANTHROPIC_API_KEY="your-key-here"
# Or
export OPENAI_API_KEY="your-key-here"

# Or create a .env file
echo "ANTHROPIC_API_KEY=your-key-here" > .env
```

### 3. Run Tests

```bash
# Quick sanity check (no API key needed)
python scripts/quick_test.py

# RAG template filling test (requires API key)
python scripts/test_pypi_rag_example.py

# Comprehensive installation test
python tests/test_testpypi_install.py
```

## Understanding Config Files and Installed Packages

**Important**: When you install fluxibly from PyPI/TestPyPI, **config files are NOT included** in the package. This is by design - config files are development/runtime files, not package code.

### What's Included in the Package

✅ **Included:**
- Python source code (`fluxibly/` directory)
- `__init__.py` with public API
- All Python modules and classes
- Package metadata

❌ **Not Included:**
- `config/` directory (profiles, MCP server configs)
- `examples/` directory
- `tests/` directory
- Development files (`.gitignore`, etc.)

### Testing Without Config Files

The test scripts handle this gracefully:

1. **Basic Tests** (no config needed):
   - Import testing
   - Object creation
   - API verification

2. **Advanced Tests** (config needed):
   - Will fail gracefully with helpful messages
   - Indicate this is expected behavior
   - Suggest running from source for full testing

## Test Scripts Overview

### 1. Quick Test (`scripts/quick_test.py`)

**No API key required** - Tests basic installation:

```bash
python scripts/quick_test.py
```

**What it tests:**
- Package import
- Core components import
- Config creation
- Engine creation

**Expected output:**
```
✓ Package imported successfully
✓ Version: 0.1.0
✓ WorkflowEngine imported
✓ Config created: test
✓ All tests passed! Installation is working correctly.
```

### 2. RAG Example Test (`scripts/test_pypi_rag_example.py`)

**Requires API key** - Reproduces RAG template filling workflow:

```bash
python scripts/test_pypi_rag_example.py
```

**What it tests:**
- Simple RAG workflow
- Template filling workflow
- Basic workflow (fallback)

**Expected behavior:**

**Case 1: Config files available (testing from source)**
```
✓ Fluxibly installed: version 0.1.0
✓ API key found
✓ Found template files
✓ Simple RAG workflow test passed!
✓ Template filling workflow test passed!
✓ All tests passed!
```

**Case 2: No config files (testing installed package)**
```
✓ Fluxibly installed: version 0.1.0
✓ API key found
⚠ Template files not found, will use inline examples
✗ Configuration file not found
💡 This is expected when testing installed package
✓ Basic Workflow test passed!
⚠ 2 test(s) failed
💡 Some failures are expected when testing installed package
```

### 3. Comprehensive Test (`tests/test_testpypi_install.py`)

**Requires API key (optional)** - Full installation verification:

```bash
python tests/test_testpypi_install.py
```

**What it tests:**
- All imports
- Version checking
- Config creation
- Engine creation
- Workflow execution (if API key present)
- MCP client manager
- Package metadata

## Reproducing the RAG Template Filling Example

To fully reproduce `examples/rag_template_filling.py` with an installed package, you need to provide the config files:

### Option 1: Copy Config Files (Recommended)

```bash
# After installing from TestPyPI, copy config files from source
mkdir -p config/profiles
cp /path/to/source/config/framework.yaml config/
cp /path/to/source/config/mcp_servers.yaml config/
cp /path/to/source/config/profiles/rag_assistant.yaml config/profiles/

# Copy template files if testing RAG
mkdir -p examples/resources
cp /path/to/source/examples/resources/outline.md examples/resources/
cp /path/to/source/examples/resources/example_oneshot.md examples/resources/

# Now run the test
python scripts/test_pypi_rag_example.py
```

### Option 2: Use Path-Based Profiles

```python
import asyncio
from fluxibly import WorkflowSession

async def main():
    # Use absolute path to profile
    profile_path = "/path/to/source/config/profiles/rag_assistant.yaml"

    async with WorkflowSession(profile=profile_path) as session:
        response = await session.execute("Your task here")
        print(response)

asyncio.run(main())
```

### Option 3: Test from Source Directory

```bash
# Clone the repository
git clone https://github.com/Lavaflux/fluxibly.git
cd fluxibly

# Create virtual environment
python3 -m venv test-env
source test-env/bin/activate

# Install from TestPyPI
pip install --index-url https://test.pypi.org/simple/ \
            --extra-index-url https://pypi.org/simple/ \
            fluxibly

# Config files are already present in source
python scripts/test_pypi_rag_example.py
```

## Creating Custom Test Scripts

Here's a minimal example for testing installed package:

```python
#!/usr/bin/env python3
"""Minimal test for installed fluxibly package."""

import asyncio
import os

async def main():
    # Check installation
    try:
        import fluxibly
        print(f"✓ Fluxibly {fluxibly.__version__} installed")
    except ImportError as e:
        print(f"✗ Import failed: {e}")
        return 1

    # Check API key
    api_key = os.getenv("ANTHROPIC_API_KEY") or os.getenv("OPENAI_API_KEY")
    if not api_key:
        print("✗ No API key found")
        return 1

    # Test basic workflow
    from fluxibly import run_workflow

    try:
        response = await run_workflow(
            "What is 2+2?",
            profile="default"  # Use built-in profile
        )
        print(f"✓ Workflow executed: {response[:50]}...")
        return 0
    except FileNotFoundError:
        print("✗ Config files not found (expected for installed package)")
        return 1

if __name__ == "__main__":
    import sys
    sys.exit(asyncio.run(main()))
```

## Troubleshooting

### Issue: "FileNotFoundError: Framework configuration not found"

**Cause**: Config files are not included in the installed package.

**Solutions:**
1. Test basic features that don't require config
2. Copy config files from source repository
3. Create minimal config files
4. Use path-based profiles with absolute paths

### Issue: "Profile not found: rag_assistant"

**Cause**: Custom profiles are not included in package.

**Solutions:**
1. Use "default" profile instead
2. Copy profile files from source
3. Create custom profile in your project

### Issue: Workflow execution fails

**Cause**: May be related to missing config or invalid API key.

**Check:**
```bash
# Verify API key
echo $ANTHROPIC_API_KEY

# Verify fluxibly installation
python -c "import fluxibly; print(fluxibly.__version__)"

# Check what config files exist
ls -la config/
```

## Expected Test Results

### From Installed Package (No Config Files)

```
Results: 1/3 tests passed
✗ FAIL: Simple RAG Workflow (config not found)
✗ FAIL: Template Filling Workflow (config not found)
✓ PASS: Basic Workflow

💡 Some failures are expected when testing installed package
```

### From Source Directory (With Config Files)

```
Results: 3/3 tests passed
✓ PASS: Simple RAG Workflow
✓ PASS: Template Filling Workflow
✓ PASS: Basic Workflow

✓ All tests passed! RAG features working correctly.
```

## Production Usage

For production usage of an installed fluxibly package:

1. **Create your own config files** in your project
2. **Use path-based profiles** for custom configurations
3. **Bundle required configs** with your application
4. **Use environment variables** for sensitive settings

Example project structure:
```
my-project/
├── config/
│   ├── framework.yaml
│   ├── mcp_servers.yaml
│   └── profiles/
│       └── my_profile.yaml
├── main.py
└── requirements.txt
```

## Summary

- ✅ **Basic testing works** without config files
- ✅ **Advanced features require** config files from source
- ✅ **This is expected behavior** for installed packages
- ✅ **Production apps should** bundle their own configs

For full testing including RAG features, either:
1. Test from source directory
2. Copy config files to test environment
3. Create minimal configs for testing
