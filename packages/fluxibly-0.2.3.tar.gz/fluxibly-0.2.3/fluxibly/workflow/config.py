"""Workflow configuration models.

This module provides Pydantic models for configuring workflow execution.
"""

from typing import Literal

from pydantic import BaseModel, Field


class WorkflowConfig(BaseModel):
    """Configuration for workflow execution.

    Attributes:
        name: Workflow identifier for logging and tracking
        agent_type: Type of agent to use ("agent" or "orchestrator")
        profile: Name of configuration profile to load (or path to profile file)
        execution_mode: Execution mode ("single" for one task, "batch" for multiple)
        stateful: Whether to maintain conversation history across calls
        mcp_config_path: Path to MCP servers configuration file (can be absolute or relative)
        config_dir: Base configuration directory path

    Example:
        >>> # Basic config
        >>> config = WorkflowConfig(
        ...     name="my_workflow",
        ...     agent_type="orchestrator",
        ...     profile="development_assistant",
        ...     stateful=True
        ... )
        >>>
        >>> # With custom MCP config path
        >>> config = WorkflowConfig(
        ...     name="my_workflow",
        ...     profile="default",
        ...     mcp_config_path="/path/to/my_mcp_servers.yaml"
        ... )
        >>>
        >>> # With custom config directory
        >>> config = WorkflowConfig(
        ...     name="my_workflow",
        ...     profile="default",
        ...     mcp_config_path="custom/mcp_servers.yaml",
        ...     config_dir="/path/to/configs"
        ... )
    """

    name: str = Field(..., description="Workflow identifier")
    agent_type: Literal["agent", "orchestrator"] = Field(default="agent", description="Type of agent to use")
    profile: str = Field(default="default", description="Configuration profile name")
    execution_mode: Literal["single", "batch"] = Field(
        default="single", description="Execution mode: single task or batch processing"
    )
    stateful: bool = Field(default=True, description="Maintain conversation history across calls")
    mcp_config_path: str = Field(default="config/mcp_servers.yaml", description="Path to MCP servers configuration")
    config_dir: str = Field(default="config", description="Configuration directory path")
