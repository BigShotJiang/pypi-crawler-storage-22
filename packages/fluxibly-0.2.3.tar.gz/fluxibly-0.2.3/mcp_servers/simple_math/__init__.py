"""Simple Math MCP Server."""
