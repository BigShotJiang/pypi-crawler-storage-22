"""
Flyto Core - Atomic workflow automation modules
Configuration is in pyproject.toml, this file is for backwards compatibility.
"""
from setuptools import setup

# All configuration is in pyproject.toml
setup()
