"""
Workflow Engine CLI Package

Provides command-line interface for workflow automation.
"""
__version__ = "1.0.0"

from .main import main

__all__ = ['main']
