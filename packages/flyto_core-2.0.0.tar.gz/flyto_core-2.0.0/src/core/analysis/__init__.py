"""
Core Analysis Package - Stub for OSS version

Full implementation available in Flyto Pro.
"""

from .html_analyzer import HTMLAnalyzer

__all__ = ["HTMLAnalyzer"]
