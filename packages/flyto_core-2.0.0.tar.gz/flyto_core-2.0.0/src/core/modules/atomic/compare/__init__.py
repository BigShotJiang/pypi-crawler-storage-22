"""
Compare Modules
Value comparison and change detection utilities.
"""
from .change import compare_change

__all__ = ['compare_change']
