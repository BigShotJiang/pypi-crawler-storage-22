#[allow(clippy::module_inception)]
pub(crate) mod fm_index;
pub(crate) mod iter_locate;
