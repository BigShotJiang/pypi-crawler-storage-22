pub(crate) mod fm_index;
pub(crate) mod multi_fm_index;
