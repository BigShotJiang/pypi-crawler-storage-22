"""
Not yet implemented.

added FMC v6.5.0
Appears to only be valid for Firepower 1010 devices.
"""
