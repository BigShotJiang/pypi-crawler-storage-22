# fmtconv

Convert between JSON, YAML, TOML, and INI config formats from the command line.

## Install

```bash
pip install fmtconv-cli
```

## Usage

```bash
# Convert between formats
fmtconv to-yaml config.json
fmtconv to-json config.yaml
fmtconv to-toml config.json
fmtconv to-ini config.json
cat config.yaml | fmtconv to-json

# Auto-detect format
fmtconv detect config.yaml          # → yaml

# Validate
fmtconv validate config.json        # → Valid JSON

# Pretty-print in place
fmtconv prettify messy.json

# Write to file
fmtconv to-yaml config.json -o config.yaml

# Sort keys
fmtconv to-json config.yaml --sort-keys

# Machine-readable output
fmtconv detect config.yaml --json   # → {"format": "yaml"}
```

## Commands

| Command | Description |
|---------|-------------|
| `to-json` | Convert to JSON |
| `to-yaml` | Convert to YAML |
| `to-toml` | Convert to TOML |
| `to-ini` | Convert to INI |
| `detect` | Auto-detect format |
| `validate` | Check if input is valid |
| `prettify` | Pretty-print in same format |

All commands accept a file argument or stdin, and support `--json` for machine-readable output.

## For AI Agents

See [SKILL.md](SKILL.md) for agent-optimized documentation.

## License

MIT
