"""fmtconv - Convert between JSON, YAML, TOML, and INI config formats."""
__version__ = "0.1.0"
