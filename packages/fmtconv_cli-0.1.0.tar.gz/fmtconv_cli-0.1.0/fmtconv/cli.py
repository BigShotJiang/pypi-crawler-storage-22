"""CLI interface for fmtconv."""

import sys
import json
import click

from .converter import convert, parse, detect_format, serialize, FORMATS


def read_input(file_arg):
    """Read from file or stdin."""
    if file_arg and file_arg != "-":
        with open(file_arg, "r") as f:
            return f.read()
    if not sys.stdin.isatty():
        return sys.stdin.read()
    click.echo("Error: No input. Provide a file or pipe from stdin.", err=True)
    sys.exit(1)


@click.group()
@click.version_option()
def cli():
    """Convert between JSON, YAML, TOML, and INI config formats.

    \b
    Examples:
      fmtconv to-yaml config.json
      fmtconv to-json config.yaml
      fmtconv to-toml config.json -o config.toml
      cat config.ini | fmtconv to-json
      fmtconv detect config.yaml
      fmtconv validate config.json --format json
    """
    pass


def make_convert_command(target_fmt):
    """Factory for to-X commands."""
    @click.argument("file", required=False)
    @click.option("-f", "--from", "from_fmt", type=click.Choice(FORMATS), help="Source format (auto-detected if omitted)")
    @click.option("-o", "--output", help="Write to file instead of stdout")
    @click.option("--indent", type=int, default=2, help="Indentation (JSON only)")
    @click.option("--sort-keys", is_flag=True, help="Sort object keys")
    @click.option("--json", "as_json", is_flag=True, help="Output as JSON metadata wrapper")
    def cmd(file, from_fmt, output, indent, sort_keys, as_json):
        text = read_input(file)
        try:
            result, detected_from, data = convert(text, from_fmt, target_fmt, indent=indent, sort_keys=sort_keys)
        except Exception as e:
            click.echo(f"Error: {e}", err=True)
            sys.exit(1)

        if as_json:
            click.echo(json.dumps({
                "from": detected_from,
                "to": target_fmt,
                "output": result,
            }, indent=2))
        elif output:
            with open(output, "w") as f:
                f.write(result + "\n")
            click.echo(f"Written to {output}", err=True)
        else:
            click.echo(result)

    cmd.__doc__ = f"Convert input to {target_fmt.upper()}."
    return cmd


for fmt in FORMATS:
    cli.command(f"to-{fmt}")(make_convert_command(fmt))


@cli.command()
@click.argument("file", required=False)
@click.option("--json", "as_json", is_flag=True, help="JSON output")
def detect(file, as_json):
    """Detect the format of input."""
    text = read_input(file)
    try:
        fmt = detect_format(text)
    except ValueError as e:
        if as_json:
            click.echo(json.dumps({"error": str(e)}))
        else:
            click.echo(f"Error: {e}", err=True)
        sys.exit(1)

    if as_json:
        click.echo(json.dumps({"format": fmt}))
    else:
        click.echo(fmt)


@cli.command()
@click.argument("file", required=False)
@click.option("-f", "--format", "fmt", type=click.Choice(FORMATS), help="Expected format (auto-detected if omitted)")
@click.option("--json", "as_json", is_flag=True, help="JSON output")
def validate(file, fmt, as_json):
    """Validate that input is parseable."""
    text = read_input(file)
    try:
        if fmt is None:
            fmt = detect_format(text)
        parse(text, fmt)
        if as_json:
            click.echo(json.dumps({"valid": True, "format": fmt}))
        else:
            click.echo(f"Valid {fmt.upper()}")
    except Exception as e:
        if as_json:
            click.echo(json.dumps({"valid": False, "error": str(e)}))
        else:
            click.echo(f"Invalid: {e}", err=True)
        sys.exit(1)


@cli.command()
@click.argument("file", required=False)
@click.option("-f", "--format", "fmt", type=click.Choice(FORMATS), help="Format (auto-detected if omitted)")
@click.option("--indent", type=int, default=2, help="Indentation")
@click.option("--sort-keys", is_flag=True, help="Sort keys")
def prettify(file, fmt, indent, sort_keys):
    """Pretty-print input in its own format."""
    text = read_input(file)
    try:
        if fmt is None:
            fmt = detect_format(text)
        data = parse(text, fmt)
        result = serialize(data, fmt, indent=indent, sort_keys=sort_keys)
        click.echo(result)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
