"""Core conversion logic between formats."""

import json
import configparser
import io
from collections import OrderedDict

import yaml
import toml


FORMATS = ("json", "yaml", "toml", "ini")


def detect_format(text: str) -> str:
    """Best-effort format detection from content."""
    stripped = text.strip()
    # JSON: starts with { or [
    if stripped and stripped[0] in ('{', '['):
        try:
            json.loads(stripped)
            return "json"
        except json.JSONDecodeError:
            pass
    # INI: has [section] headers
    if any(line.strip().startswith('[') and line.strip().endswith(']') and '=' not in line.split(']')[0]
           for line in stripped.split('\n') if line.strip()):
        try:
            cp = configparser.ConfigParser()
            cp.read_string(stripped)
            if cp.sections():
                return "ini"
        except Exception:
            pass
    # TOML: try parse (before YAML since YAML is very permissive)
    try:
        toml.loads(stripped)
        # Only call it TOML if it has TOML-ish markers
        if any(c in stripped for c in ['[', '=', '"""', "'''"]):
            return "toml"
    except Exception:
        pass
    # YAML: last resort (YAML parses almost anything)
    try:
        result = yaml.safe_load(stripped)
        if isinstance(result, (dict, list)):
            return "yaml"
    except Exception:
        pass
    raise ValueError("Could not detect format")


def parse(text: str, fmt: str) -> dict:
    """Parse text in given format to a Python dict."""
    if fmt == "json":
        return json.loads(text)
    elif fmt == "yaml":
        return yaml.safe_load(text)
    elif fmt == "toml":
        return toml.loads(text)
    elif fmt == "ini":
        cp = configparser.ConfigParser()
        cp.read_string(text)
        result = {}
        for section in cp.sections():
            result[section] = dict(cp[section])
        return result
    else:
        raise ValueError(f"Unknown format: {fmt}")


def serialize(data, fmt: str, indent: int = 2, sort_keys: bool = False) -> str:
    """Serialize a Python dict to the given format."""
    if fmt == "json":
        return json.dumps(data, indent=indent, sort_keys=sort_keys, ensure_ascii=False)
    elif fmt == "yaml":
        return yaml.dump(data, default_flow_style=False, sort_keys=sort_keys, allow_unicode=True).rstrip()
    elif fmt == "toml":
        return toml.dumps(data).rstrip()
    elif fmt == "ini":
        cp = configparser.ConfigParser()
        for key, value in data.items():
            if isinstance(value, dict):
                cp[key] = {k: str(v) for k, v in value.items()}
            else:
                # Put top-level scalars under DEFAULT
                cp.setdefault("DEFAULT", {})[key] = str(value)
        buf = io.StringIO()
        cp.write(buf)
        return buf.getvalue().rstrip()
    else:
        raise ValueError(f"Unknown format: {fmt}")


def convert(text: str, from_fmt: str | None, to_fmt: str, **kwargs) -> str:
    """Convert text from one format to another."""
    if from_fmt is None:
        from_fmt = detect_format(text)
    data = parse(text, from_fmt)
    return serialize(data, to_fmt, **kwargs), from_fmt, data
