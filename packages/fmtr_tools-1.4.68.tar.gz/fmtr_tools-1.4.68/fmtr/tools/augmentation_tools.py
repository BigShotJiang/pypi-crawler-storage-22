import sre_yield


to_generator = sre_yield.AllStrings
