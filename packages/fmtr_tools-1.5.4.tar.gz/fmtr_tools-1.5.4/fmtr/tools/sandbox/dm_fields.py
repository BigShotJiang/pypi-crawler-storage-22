



class ProductCode(FieldInfo):
    DESCRIPTION = '{title} code. It will look like {example}'
    ANNOTATION = str


class ASIN(ProductCode):
    FILLS=dict(example='BO...')




class SKU(ProductCode):
    FILLS=dict(example='NN...')

class Store(FieldInfo):
    ...



class MyBase(BaseModel):

    FIELDS: ClassVar[List[FieldInfo] | Dict[str,FieldInfo]] = []

    def __init_subclass__(cls, **kwargs):
        """

        Fetch aggregated fields metadata from the hierarchy and set annotations and FieldInfo objects in the class.

        """
        super().__init_subclass__(**kwargs)

        fields = {}
        for base in reversed(cls.__mro__):

            try:
                raw = base.FIELDS
            except AttributeError:
                raw={}

            if isinstance(raw, dict):
                fields |= raw
            else:
                fields |= get_class_lookup(*raw,name_function=str.lower)

        cls.FIELDS = fields

        for name,FieldInfoType in fields.items():
            if name in cls.__annotations__:
                continue

            field=FieldInfoType()
            setattr(cls, name, field)

            annotation = FieldInfoType.ANNOTATION
            cls.__annotations__[name] = annotation


class InvBase(MyBase):

    FIELDS: ClassVar=[ASIN, SKU]

class SKU(SKU):
    ANNOTATION=str|None

class InvDisplay(InvBase):
    FIELDS=[SKU]

#
# class InvAmazon(InvDisplay):
#     asin: str
#     sku: str|None
#
#
# class InvStore(InvDisplay):
#     asin: str|None
#    sku: str|None=Store(description='special desc voerrite')





if __name__ == '__main__':

    sch_base=InvBase.model_json_schema()
    sch_base

    disp_sch = InvDisplay.model_json_schema()
    am_sch=InvAmazon.model_json_schema()
    st_sch = InvStore.model_json_schema()
    am_sch

    Field