"""Routes related to handling data from SMDA."""
