class NotConnectedError(Exception):
    """当FnosClient未连接到服务器时抛出的异常"""
    pass