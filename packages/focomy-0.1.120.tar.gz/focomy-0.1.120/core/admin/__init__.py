"""Admin - HTMX-powered admin interface."""

from .routes import router

__all__ = ["router"]
