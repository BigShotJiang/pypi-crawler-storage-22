# Core content type definitions (YAML files)
