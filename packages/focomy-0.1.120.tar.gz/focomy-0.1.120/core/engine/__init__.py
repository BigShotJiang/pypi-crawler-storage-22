"""Template rendering engine."""

from .routes import router

__all__ = ["router"]
