"""Scaffold templates for focomy init command."""
