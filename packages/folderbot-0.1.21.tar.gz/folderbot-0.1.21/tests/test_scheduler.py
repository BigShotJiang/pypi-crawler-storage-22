"""Tests for the task scheduler engine."""

import asyncio
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

from folderbot.scheduler.models import (
    Schedule,
    ScheduleType,
    TaskPlan,
    TaskStatus,
    TaskStep,
)
from folderbot.scheduler.persistence import TaskStore
from folderbot.scheduler.scheduler import TaskScheduler
from folderbot.tools.base import ToolResult


@pytest.fixture
def task_store(tmp_path: Path) -> TaskStore:
    db_path = tmp_path / "test_tasks.db"
    return TaskStore(db_path)


@pytest.fixture
def send_message() -> AsyncMock:
    return AsyncMock()


@pytest.fixture
def summarize() -> AsyncMock:
    return AsyncMock(return_value="Test summary")


@pytest.fixture
def folder_tools() -> MagicMock:
    tools = MagicMock()
    tools.execute.return_value = ToolResult(content="tool output")
    return tools


@pytest.fixture
def scheduler(
    task_store: TaskStore,
    send_message: AsyncMock,
    summarize: AsyncMock,
    folder_tools: MagicMock,
) -> TaskScheduler:
    s = TaskScheduler(
        task_store=task_store,
        send_message=send_message,
        summarize=summarize,
    )
    s.set_folder_tools(folder_tools)
    return s


def _make_plan(
    task_id: str = "task001",
    schedule_type: ScheduleType = ScheduleType.once,
    **kwargs,
) -> TaskPlan:
    defaults = dict(
        chat_id=100,
        user_id=200,
        description="Test task",
        steps=(TaskStep(tool_name="read_file", tool_input={"path": "a.md"}),),
        schedule=Schedule(schedule_type=schedule_type),
        created_at="2025-01-01T00:00:00+00:00",
    )
    defaults.update(kwargs)
    return TaskPlan(task_id=task_id, **defaults)


class TestCreateTask:
    async def test_creates_and_tracks_task(self, scheduler: TaskScheduler):
        plan = _make_plan()
        task_id = await scheduler.create_task(plan)

        assert task_id == "task001"
        assert "task001" in scheduler._task_plans
        assert "task001" in scheduler._running_tasks

        # Let the task execute
        await asyncio.sleep(0.1)

    async def test_task_persisted_to_store(
        self, scheduler: TaskScheduler, task_store: TaskStore
    ):
        plan = _make_plan()
        await scheduler.create_task(plan)
        await asyncio.sleep(0.1)

        # Verify it was saved to the store
        tasks = task_store.load_user_tasks(user_id=200)
        assert len(tasks) >= 1


class TestListTasks:
    async def test_list_empty(self, scheduler: TaskScheduler):
        tasks = scheduler.list_tasks(user_id=200)
        assert tasks == []

    async def test_list_filters_by_user(self, scheduler: TaskScheduler):
        plan1 = _make_plan(task_id="t1", user_id=100)
        plan2 = _make_plan(task_id="t2", user_id=200)

        # Add plans directly to avoid async execution complexity
        scheduler._task_plans["t1"] = plan1
        scheduler._task_plans["t2"] = plan2

        tasks = scheduler.list_tasks(user_id=200)

        assert len(tasks) == 1
        assert tasks[0].task_id == "t2"

    async def test_list_filters_by_status(self, scheduler: TaskScheduler):
        plan1 = _make_plan(task_id="t1", status=TaskStatus.pending)
        plan2 = _make_plan(task_id="t2", status=TaskStatus.running)

        scheduler._task_plans["t1"] = plan1
        scheduler._task_plans["t2"] = plan2

        tasks = scheduler.list_tasks(user_id=200, status_filter="running")

        assert len(tasks) == 1
        assert tasks[0].task_id == "t2"


class TestCancelTask:
    async def test_cancel_existing_task(self, scheduler: TaskScheduler):
        plan = _make_plan(
            schedule_type=ScheduleType.repeating,
            schedule=Schedule(
                schedule_type=ScheduleType.repeating,
                interval_seconds=1,
                max_iterations=100,
            ),
        )
        await scheduler.create_task(plan)
        await asyncio.sleep(0.1)

        cancelled = await scheduler.cancel_task("task001", user_id=200)

        assert cancelled is True
        assert scheduler._task_plans["task001"].status == TaskStatus.cancelled

    async def test_cancel_nonexistent_task(self, scheduler: TaskScheduler):
        cancelled = await scheduler.cancel_task("nonexistent", user_id=200)
        assert cancelled is False

    async def test_cancel_wrong_user(self, scheduler: TaskScheduler):
        plan = _make_plan(user_id=200)
        scheduler._task_plans["task001"] = plan

        cancelled = await scheduler.cancel_task("task001", user_id=999)
        assert cancelled is False


class TestGetTaskResults:
    async def test_get_results(self, scheduler: TaskScheduler):
        plan = _make_plan()
        scheduler._task_plans["task001"] = plan

        result = scheduler.get_task_results("task001", user_id=200)

        assert result is not None
        assert result.task_id == "task001"

    async def test_get_results_not_found(self, scheduler: TaskScheduler):
        result = scheduler.get_task_results("nonexistent", user_id=200)
        assert result is None

    async def test_get_results_wrong_user(self, scheduler: TaskScheduler):
        plan = _make_plan(user_id=200)
        scheduler._task_plans["task001"] = plan

        result = scheduler.get_task_results("task001", user_id=999)
        assert result is None


class TestRunOnce:
    async def test_once_executes_and_completes(
        self,
        scheduler: TaskScheduler,
        folder_tools: MagicMock,
        send_message: AsyncMock,
    ):
        plan = _make_plan(schedule_type=ScheduleType.once)
        await scheduler.create_task(plan)
        await asyncio.sleep(0.2)

        folder_tools.execute.assert_called_once_with("read_file", {"path": "a.md"})

        final_plan = scheduler._task_plans["task001"]
        assert final_plan.status == TaskStatus.completed
        assert final_plan.current_iteration == 1

    async def test_once_with_delay(
        self,
        scheduler: TaskScheduler,
        folder_tools: MagicMock,
    ):
        plan = _make_plan(
            schedule=Schedule(
                schedule_type=ScheduleType.once,
                delay_seconds=0,  # Use 0 for test speed
            ),
        )
        await scheduler.create_task(plan)
        await asyncio.sleep(0.2)

        folder_tools.execute.assert_called_once()


class TestRunTimeLimited:
    async def test_time_limited_runs_multiple_iterations(
        self,
        scheduler: TaskScheduler,
        folder_tools: MagicMock,
    ):
        # Minimum interval is 1s, so duration=3 gives ~3 iterations
        plan = _make_plan(
            schedule=Schedule(
                schedule_type=ScheduleType.time_limited,
                duration_seconds=3,
                interval_seconds=1,
            ),
        )
        await scheduler.create_task(plan)
        await asyncio.sleep(3.5)

        assert folder_tools.execute.call_count >= 2

        final_plan = scheduler._task_plans["task001"]
        assert final_plan.status == TaskStatus.completed

    async def test_time_limited_respects_max_iterations(
        self,
        scheduler: TaskScheduler,
        folder_tools: MagicMock,
    ):
        # Minimum interval is 1s; max_iterations=2 should stop after 2
        plan = _make_plan(
            schedule=Schedule(
                schedule_type=ScheduleType.time_limited,
                duration_seconds=10,
                interval_seconds=1,
                max_iterations=2,
            ),
        )
        await scheduler.create_task(plan)
        await asyncio.sleep(2.5)

        final_plan = scheduler._task_plans["task001"]
        assert final_plan.current_iteration == 2
        assert final_plan.status == TaskStatus.completed


class TestExecuteIteration:
    async def test_error_tracking(
        self,
        scheduler: TaskScheduler,
        folder_tools: MagicMock,
    ):
        folder_tools.execute.return_value = ToolResult(
            content="some error", is_error=True
        )

        plan = _make_plan(
            schedule=Schedule(
                schedule_type=ScheduleType.repeating,
                interval_seconds=0,
                max_iterations=2,
            ),
            max_consecutive_errors=10,
        )
        await scheduler.create_task(plan)
        await asyncio.sleep(0.5)

        final_plan = scheduler._task_plans["task001"]
        assert final_plan.consecutive_errors > 0

    async def test_max_consecutive_errors_fails_task(
        self,
        scheduler: TaskScheduler,
        folder_tools: MagicMock,
        send_message: AsyncMock,
    ):
        folder_tools.execute.return_value = ToolResult(
            content="persistent error", is_error=True
        )

        plan = _make_plan(
            schedule=Schedule(
                schedule_type=ScheduleType.repeating,
                interval_seconds=0,
                max_iterations=100,
            ),
            max_consecutive_errors=3,
        )
        await scheduler.create_task(plan)
        await asyncio.sleep(0.5)

        final_plan = scheduler._task_plans["task001"]
        assert final_plan.status == TaskStatus.failed

    async def test_success_resets_consecutive_errors(
        self,
        scheduler: TaskScheduler,
        folder_tools: MagicMock,
    ):
        call_count = 0

        def alternate_results(tool_name, tool_input):
            nonlocal call_count
            call_count += 1
            if call_count % 2 == 1:
                return ToolResult(content="error", is_error=True)
            return ToolResult(content="success")

        folder_tools.execute.side_effect = alternate_results

        plan = _make_plan(
            schedule=Schedule(
                schedule_type=ScheduleType.repeating,
                interval_seconds=0,
                max_iterations=4,
            ),
            max_consecutive_errors=5,
        )
        await scheduler.create_task(plan)
        await asyncio.sleep(0.5)

        final_plan = scheduler._task_plans["task001"]
        # Should complete since errors alternate with successes
        assert final_plan.status == TaskStatus.completed

    async def test_results_capped(
        self,
        scheduler: TaskScheduler,
        folder_tools: MagicMock,
    ):
        plan = _make_plan(
            schedule=Schedule(
                schedule_type=ScheduleType.repeating,
                interval_seconds=0,
                max_iterations=10,
            ),
            max_results_kept=5,
            progress_interval=0,
        )
        await scheduler.create_task(plan)
        await asyncio.sleep(1.0)

        final_plan = scheduler._task_plans["task001"]
        assert len(final_plan.results) <= 5


class TestProgressMessages:
    async def test_sends_progress(
        self,
        scheduler: TaskScheduler,
        send_message: AsyncMock,
    ):
        plan = _make_plan(
            schedule=Schedule(
                schedule_type=ScheduleType.repeating,
                interval_seconds=0,
                max_iterations=3,
            ),
            progress_interval=1,
            summarize_on_complete=False,
        )
        await scheduler.create_task(plan)
        await asyncio.sleep(0.5)

        # Should have progress messages + completion message
        assert send_message.call_count >= 1

    async def test_progress_interval_controls_frequency(
        self,
        scheduler: TaskScheduler,
        send_message: AsyncMock,
    ):
        plan = _make_plan(
            schedule=Schedule(
                schedule_type=ScheduleType.repeating,
                interval_seconds=0,
                max_iterations=4,
            ),
            progress_interval=2,
            summarize_on_complete=False,
        )
        await scheduler.create_task(plan)
        await asyncio.sleep(0.5)

        # With progress_interval=2 and 4 iterations: progress at 2, 4 + completion
        # Exact count depends on timing, but should be less than with interval=1
        assert send_message.call_count >= 1


class TestSummary:
    async def test_generates_summary_on_complete(
        self,
        scheduler: TaskScheduler,
        summarize: AsyncMock,
        send_message: AsyncMock,
    ):
        plan = _make_plan(
            schedule_type=ScheduleType.once,
            summarize_on_complete=True,
        )
        await scheduler.create_task(plan)
        await asyncio.sleep(0.3)

        summarize.assert_called_once()
        # Summary should be sent via send_message
        assert any(
            "Summary" in str(call) or "summary" in str(call)
            for call in send_message.call_args_list
        )

    async def test_no_summary_when_disabled(
        self,
        scheduler: TaskScheduler,
        summarize: AsyncMock,
        send_message: AsyncMock,
    ):
        plan = _make_plan(
            schedule_type=ScheduleType.once,
            summarize_on_complete=False,
        )
        await scheduler.create_task(plan)
        await asyncio.sleep(0.3)

        summarize.assert_not_called()
        # Should still get a completion message
        assert send_message.call_count >= 1


class TestShutdown:
    async def test_shutdown_cancels_tasks(
        self,
        scheduler: TaskScheduler,
    ):
        plan = _make_plan(
            schedule=Schedule(
                schedule_type=ScheduleType.repeating,
                interval_seconds=1,
                max_iterations=100,
            ),
        )
        await scheduler.create_task(plan)
        await asyncio.sleep(0.1)

        await scheduler.shutdown()

        assert len(scheduler._running_tasks) == 0 or all(
            t.cancelled() for t in scheduler._running_tasks.values()
        )


class TestStartRestore:
    async def test_restores_persisted_tasks(
        self,
        task_store: TaskStore,
        send_message: AsyncMock,
        summarize: AsyncMock,
        folder_tools: MagicMock,
    ):
        # Save a pending task to the store
        plan = _make_plan(status=TaskStatus.pending)
        task_store.save_task(plan)

        # Create a new scheduler and start it
        new_scheduler = TaskScheduler(
            task_store=task_store,
            send_message=send_message,
            summarize=summarize,
        )
        new_scheduler.set_folder_tools(folder_tools)
        await new_scheduler.start()

        # Task should be restored and running
        assert "task001" in new_scheduler._task_plans
        assert "task001" in new_scheduler._running_tasks

        await new_scheduler.shutdown()
