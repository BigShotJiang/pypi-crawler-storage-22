"""Self-bot: Telegram bot for talking to your folder."""

__version__ = "0.1.23"
