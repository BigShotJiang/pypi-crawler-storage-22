"""Tests for folderbot package."""
