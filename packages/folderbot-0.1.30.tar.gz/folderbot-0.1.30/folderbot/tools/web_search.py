"""Web search tool."""

import logging

from pydantic import BaseModel, Field

from ..bot import BotContext
from .base import ToolResult
from .registry import folder_bot

logger = logging.getLogger(__name__)

# Check if web search is available
_WEB_AVAILABLE = False
try:
    from duckduckgo_search import DDGS

    _WEB_AVAILABLE = True
except ImportError:
    DDGS = None  # type: ignore[assignment, misc]


class WebSearchRequest(BaseModel, frozen=True):
    """Request for searching the web."""

    query: str = Field(description="Search query to look up on the web")
    max_results: int = Field(
        default=5,
        description="Maximum number of search results to return (1-10)",
    )


@folder_bot.tool(
    name="web_search",
    request_type=WebSearchRequest,
    response_type=ToolResult,
)
def web_search(
    request: WebSearchRequest, _context: BotContext | None = None
) -> ToolResult:
    """Search the web using DuckDuckGo.

    Returns titles, URLs, and snippets for the top results.
    Use this to find information online.
    """
    if not _WEB_AVAILABLE:
        return ToolResult(
            content="Web search not available. Install with: pip install folderbot[web]",
            is_error=True,
        )

    max_results = min(max(1, request.max_results), 10)

    try:
        with DDGS() as ddgs:
            results = list(ddgs.text(request.query, max_results=max_results))

        if not results:
            return ToolResult(content=f"No results found for: {request.query}")

        lines = []
        for i, r in enumerate(results, 1):
            title = r.get("title", "No title")
            url = r.get("href", r.get("link", ""))
            snippet = r.get("body", r.get("snippet", ""))
            lines.append(f"{i}. {title}\n   {url}\n   {snippet}\n")

        return ToolResult(content="\n".join(lines))

    except Exception as e:
        logger.exception("Web search error")
        return ToolResult(content=f"Search error: {e}", is_error=True)


def is_available() -> bool:
    """Check if web search is available."""
    return _WEB_AVAILABLE


# Backward compatibility alias
WebSearchInput = WebSearchRequest
