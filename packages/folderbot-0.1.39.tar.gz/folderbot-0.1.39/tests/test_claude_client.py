"""Tests for Claude client history management."""

from folderbot.claude_client import trim_history_to_budget
from folderbot.session_manager import Message


def _msg(role: str, content: str) -> Message:
    """Create a test message."""
    return {"role": role, "content": content, "timestamp": "2026-01-01T00:00:00"}


class TestTrimHistoryToBudget:
    def test_empty_history_returns_empty(self):
        assert trim_history_to_budget([], max_chars=1000) == []

    def test_history_within_budget_unchanged(self):
        history = [_msg("user", "Hello"), _msg("assistant", "Hi!")]
        result = trim_history_to_budget(history, max_chars=1000)
        assert result == history

    def test_history_exceeding_budget_drops_oldest_first(self):
        history = [
            _msg("user", "First"),  # old
            _msg("assistant", "Reply1"),  # old
            _msg("user", "Second"),  # recent
            _msg("assistant", "Reply2"),  # recent
        ]
        # Budget that fits only the last pair
        budget = len("Second") + len("Reply2") + 1
        result = trim_history_to_budget(history, max_chars=budget)

        assert len(result) == 2
        assert result[0]["content"] == "Second"
        assert result[1]["content"] == "Reply2"

    def test_drops_in_pairs_to_avoid_orphaned_messages(self):
        """History should be trimmed in user/assistant pairs, not individual messages."""
        history = [
            _msg("user", "A" * 100),
            _msg("assistant", "B" * 100),
            _msg("user", "C" * 50),
            _msg("assistant", "D" * 50),
        ]
        # Budget fits last pair + part of first pair, but we drop full pairs
        budget = 150
        result = trim_history_to_budget(history, max_chars=budget)

        assert len(result) == 2
        assert result[0]["content"] == "C" * 50
        assert result[1]["content"] == "D" * 50

    def test_budget_zero_returns_empty(self):
        history = [_msg("user", "Hello"), _msg("assistant", "Hi!")]
        result = trim_history_to_budget(history, max_chars=0)
        assert result == []

    def test_single_pair_exceeding_budget_still_included(self):
        """If even the most recent pair exceeds the budget, include it anyway.

        The user's current message must always have context from the last exchange.
        """
        history = [
            _msg("user", "A" * 500),
            _msg("assistant", "B" * 500),
        ]
        result = trim_history_to_budget(history, max_chars=100)
        # Include the last pair even if it exceeds budget
        assert len(result) == 2

    def test_preserves_message_order(self):
        history = [
            _msg("user", "1"),
            _msg("assistant", "2"),
            _msg("user", "3"),
            _msg("assistant", "4"),
            _msg("user", "5"),
            _msg("assistant", "6"),
        ]
        result = trim_history_to_budget(history, max_chars=10000)
        contents = [m["content"] for m in result]
        assert contents == ["1", "2", "3", "4", "5", "6"]

    def test_odd_number_of_messages_handles_gracefully(self):
        """If history has an odd number of messages, don't crash."""
        history = [
            _msg("user", "A" * 100),
            _msg("assistant", "B" * 100),
            _msg("user", "C" * 50),  # no assistant reply yet
        ]
        budget = 100
        result = trim_history_to_budget(history, max_chars=budget)
        # Should keep the trailing user message
        assert result[-1]["content"] == "C" * 50
