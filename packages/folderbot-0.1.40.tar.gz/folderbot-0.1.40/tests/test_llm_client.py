"""Tests for the LLM client (instructor-based, provider-agnostic)."""

from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from folderbot.config import Config, ReadRules, WatchConfig
from folderbot.llm_client import (
    AgentResponse,
    LLMClient,
    ToolCallRequest,
    trim_history_to_budget,
)
from folderbot.session_manager import Message
from folderbot.tools.base import ToolResult


def _msg(role: str, content: str) -> Message:
    """Create a test message."""
    return {"role": role, "content": content, "timestamp": "2026-01-01T00:00:00"}


# ---------- Model tests ----------


class TestToolCallRequest:
    def test_basic(self):
        tc = ToolCallRequest(name="read_file", arguments={"path": "test.md"})
        assert tc.name == "read_file"
        assert tc.arguments == {"path": "test.md"}

    def test_empty_arguments_default(self):
        tc = ToolCallRequest(name="list_files")
        assert tc.arguments == {}

    def test_frozen(self):
        tc = ToolCallRequest(name="read_file", arguments={})
        with pytest.raises(Exception):
            tc.name = "other"


class TestAgentResponse:
    def test_direct_answer(self):
        r = AgentResponse(answer="Hello!")
        assert r.answer == "Hello!"
        assert r.tool_calls == []

    def test_tool_calls_only(self):
        r = AgentResponse(
            tool_calls=[ToolCallRequest(name="list_files", arguments={"path": "/"})]
        )
        assert r.answer is None
        assert len(r.tool_calls) == 1
        assert r.tool_calls[0].name == "list_files"

    def test_both_answer_and_tools(self):
        """LLM can return tool calls alongside a partial answer."""
        r = AgentResponse(
            answer="Let me check...",
            tool_calls=[ToolCallRequest(name="list_files")],
        )
        assert r.answer == "Let me check..."
        assert len(r.tool_calls) == 1

    def test_frozen(self):
        r = AgentResponse(answer="Hi")
        with pytest.raises(Exception):
            r.answer = "Changed"


# ---------- trim_history_to_budget tests (moved from test_claude_client.py) ----------


class TestTrimHistoryToBudget:
    def test_empty_history_returns_empty(self):
        assert trim_history_to_budget([], max_chars=1000) == []

    def test_history_within_budget_unchanged(self):
        history = [_msg("user", "Hello"), _msg("assistant", "Hi!")]
        result = trim_history_to_budget(history, max_chars=1000)
        assert result == history

    def test_history_exceeding_budget_drops_oldest_first(self):
        history = [
            _msg("user", "First"),
            _msg("assistant", "Reply1"),
            _msg("user", "Second"),
            _msg("assistant", "Reply2"),
        ]
        budget = len("Second") + len("Reply2") + 1
        result = trim_history_to_budget(history, max_chars=budget)
        assert len(result) == 2
        assert result[0]["content"] == "Second"
        assert result[1]["content"] == "Reply2"

    def test_drops_in_pairs_to_avoid_orphaned_messages(self):
        history = [
            _msg("user", "A" * 100),
            _msg("assistant", "B" * 100),
            _msg("user", "C" * 50),
            _msg("assistant", "D" * 50),
        ]
        budget = 150
        result = trim_history_to_budget(history, max_chars=budget)
        assert len(result) == 2
        assert result[0]["content"] == "C" * 50
        assert result[1]["content"] == "D" * 50

    def test_budget_zero_returns_empty(self):
        history = [_msg("user", "Hello"), _msg("assistant", "Hi!")]
        result = trim_history_to_budget(history, max_chars=0)
        assert result == []

    def test_single_pair_exceeding_budget_still_included(self):
        history = [
            _msg("user", "A" * 500),
            _msg("assistant", "B" * 500),
        ]
        result = trim_history_to_budget(history, max_chars=100)
        assert len(result) == 2

    def test_preserves_message_order(self):
        history = [
            _msg("user", "1"),
            _msg("assistant", "2"),
            _msg("user", "3"),
            _msg("assistant", "4"),
            _msg("user", "5"),
            _msg("assistant", "6"),
        ]
        result = trim_history_to_budget(history, max_chars=10000)
        contents = [m["content"] for m in result]
        assert contents == ["1", "2", "3", "4", "5", "6"]

    def test_odd_number_of_messages_handles_gracefully(self):
        history = [
            _msg("user", "A" * 100),
            _msg("assistant", "B" * 100),
            _msg("user", "C" * 50),
        ]
        budget = 100
        result = trim_history_to_budget(history, max_chars=budget)
        assert result[-1]["content"] == "C" * 50


# ---------- LLMClient tests ----------


@pytest.fixture
def mock_config(tmp_path: Path) -> Config:
    """Create a mock config for testing."""
    config = MagicMock(spec=Config)
    config.telegram_token = "test_token"
    config.anthropic_api_key = "test_api_key"
    config.root_folder = tmp_path
    config.allowed_user_ids = [12345, 67890]
    config.read_rules = ReadRules()
    config.watch_config = WatchConfig()
    config.db_path = tmp_path / "sessions.db"
    config.model = "anthropic/claude-sonnet-4-20250514"
    config.max_context_chars = 10000
    config.max_history_chars = 50000
    config.user_name = "User"
    return config


@pytest.fixture
def llm_client(mock_config: Config) -> LLMClient:
    """Create an LLMClient with mocked instructor."""
    with patch("folderbot.llm_client.instructor") as mock_instr:
        mock_async_client = AsyncMock()
        mock_instr.from_provider.return_value = mock_async_client
        client = LLMClient(mock_config)
        return client


class TestLLMClientChat:
    @pytest.mark.asyncio
    async def test_simple_answer_no_tools(self, llm_client: LLMClient):
        """When LLM returns a direct answer, chat() returns it."""
        llm_client._client.create = AsyncMock(
            return_value=AgentResponse(answer="Hello there!")
        )
        mock_context = MagicMock()

        response, tools_used = await llm_client.chat("Hi", mock_context, history=[])

        assert response == "Hello there!"
        assert tools_used == []

    @pytest.mark.asyncio
    async def test_tool_call_then_answer(self, llm_client: LLMClient):
        """LLM requests a tool, gets result, then gives final answer."""
        llm_client._client.create = AsyncMock(
            side_effect=[
                AgentResponse(
                    tool_calls=[
                        ToolCallRequest(name="list_files", arguments={"path": "/"})
                    ]
                ),
                AgentResponse(answer="Your folder has 2 files: a.md and b.md"),
            ]
        )
        with patch.object(
            llm_client.tools,
            "execute_async",
            return_value=ToolResult(content="a.md\nb.md"),
        ):
            mock_context = MagicMock()
            response, tools_used = await llm_client.chat(
                "What's in my folder?", mock_context, history=[]
            )

        assert response == "Your folder has 2 files: a.md and b.md"
        assert tools_used == ["list_files"]

    @pytest.mark.asyncio
    async def test_multiple_tool_calls_in_sequence(self, llm_client: LLMClient):
        """LLM calls multiple tools across iterations."""
        llm_client._client.create = AsyncMock(
            side_effect=[
                AgentResponse(
                    tool_calls=[ToolCallRequest(name="list_files", arguments={})]
                ),
                AgentResponse(
                    tool_calls=[
                        ToolCallRequest(
                            name="read_file", arguments={"path": "notes.md"}
                        )
                    ]
                ),
                AgentResponse(answer="Your notes say: buy groceries"),
            ]
        )
        with patch.object(
            llm_client.tools,
            "execute_async",
            side_effect=[
                ToolResult(content="notes.md"),
                ToolResult(content="buy groceries"),
            ],
        ):
            mock_context = MagicMock()
            response, tools_used = await llm_client.chat(
                "What do my notes say?", mock_context, history=[]
            )

        assert response == "Your notes say: buy groceries"
        assert tools_used == ["list_files", "read_file"]

    @pytest.mark.asyncio
    async def test_parallel_tool_calls_in_single_response(self, llm_client: LLMClient):
        """LLM requests multiple tools in a single response."""
        llm_client._client.create = AsyncMock(
            side_effect=[
                AgentResponse(
                    tool_calls=[
                        ToolCallRequest(name="read_file", arguments={"path": "a.md"}),
                        ToolCallRequest(name="read_file", arguments={"path": "b.md"}),
                    ]
                ),
                AgentResponse(answer="Both files are notes."),
            ]
        )
        with patch.object(
            llm_client.tools,
            "execute_async",
            side_effect=[
                ToolResult(content="Content of a"),
                ToolResult(content="Content of b"),
            ],
        ):
            mock_context = MagicMock()
            response, tools_used = await llm_client.chat(
                "Read both files", mock_context, history=[]
            )

        assert response == "Both files are notes."
        assert tools_used == ["read_file", "read_file"]

    @pytest.mark.asyncio
    async def test_on_tool_use_callback(self, llm_client: LLMClient):
        """The on_tool_use callback is called for each tool."""
        llm_client._client.create = AsyncMock(
            side_effect=[
                AgentResponse(
                    tool_calls=[ToolCallRequest(name="list_files", arguments={})]
                ),
                AgentResponse(answer="Done."),
            ]
        )
        callback = AsyncMock()

        with patch.object(
            llm_client.tools,
            "execute_async",
            return_value=ToolResult(content="files"),
        ):
            mock_context = MagicMock()
            await llm_client.chat(
                "List files", mock_context, history=[], on_tool_use=callback
            )

        callback.assert_called_once_with("list_files")

    @pytest.mark.asyncio
    async def test_max_iterations_limit(self, llm_client: LLMClient):
        """Agent loop stops after MAX_TOOL_ITERATIONS."""
        # Always return tool calls, never an answer
        llm_client._client.create = AsyncMock(
            return_value=AgentResponse(
                tool_calls=[ToolCallRequest(name="list_files", arguments={})]
            )
        )
        with patch.object(
            llm_client.tools,
            "execute_async",
            return_value=ToolResult(content="files"),
        ):
            mock_context = MagicMock()
            response, tools_used = await llm_client.chat(
                "Loop forever", mock_context, history=[]
            )

        # Should have called tools MAX_TOOL_ITERATIONS times
        assert len(tools_used) == llm_client.MAX_TOOL_ITERATIONS
        # Should return empty string (no answer was given)
        assert response == ""

    @pytest.mark.asyncio
    async def test_tool_error_included_in_context(self, llm_client: LLMClient):
        """Tool errors are fed back to the LLM."""
        llm_client._client.create = AsyncMock(
            side_effect=[
                AgentResponse(
                    tool_calls=[
                        ToolCallRequest(
                            name="read_file", arguments={"path": "missing.md"}
                        )
                    ]
                ),
                AgentResponse(answer="That file doesn't exist."),
            ]
        )
        with patch.object(
            llm_client.tools,
            "execute_async",
            return_value=ToolResult(content="File not found", is_error=True),
        ):
            mock_context = MagicMock()
            response, tools_used = await llm_client.chat(
                "Read missing.md", mock_context, history=[]
            )

        assert response == "That file doesn't exist."
        assert tools_used == ["read_file"]
        # Verify the error was included in the messages to the LLM
        second_call_messages = llm_client._client.create.call_args_list[1].kwargs[
            "messages"
        ]
        user_msg = second_call_messages[-1]["content"]
        assert "Error" in user_msg
        assert "File not found" in user_msg

    @pytest.mark.asyncio
    async def test_hallucination_guard_triggers_retry(self, llm_client: LLMClient):
        """If LLM claims action without tools, it retries with a warning."""
        llm_client._client.create = AsyncMock(
            side_effect=[
                # First: claims action without calling tools
                AgentResponse(answer="I've updated your file with the new content."),
                # Second: corrects itself and uses a tool
                AgentResponse(
                    tool_calls=[
                        ToolCallRequest(
                            name="write_file",
                            arguments={"path": "test.md", "content": "new content"},
                        )
                    ]
                ),
                # Third: confirms with answer
                AgentResponse(answer="File updated."),
            ]
        )
        with patch.object(
            llm_client.tools,
            "execute_async",
            return_value=ToolResult(content="Written successfully"),
        ):
            mock_context = MagicMock()
            response, tools_used = await llm_client.chat(
                "Update my file", mock_context, history=[]
            )

        assert response == "File updated."
        assert "write_file" in tools_used
        # Should have been called 3 times (guard triggered retry)
        assert llm_client._client.create.call_count == 3

    @pytest.mark.asyncio
    async def test_history_passed_to_llm(self, llm_client: LLMClient):
        """Conversation history is included in messages to the LLM."""
        llm_client._client.create = AsyncMock(
            return_value=AgentResponse(answer="I remember you said hello!")
        )
        history = [
            _msg("user", "Hello"),
            _msg("assistant", "Hi!"),
        ]
        mock_context = MagicMock()
        await llm_client.chat("Do you remember?", mock_context, history=history)

        call_messages = llm_client._client.create.call_args.kwargs["messages"]
        # Should include history messages (user, assistant) + new user message
        # System is passed separately via system kwarg
        user_msgs = [m for m in call_messages if m["role"] == "user"]
        assistant_msgs = [m for m in call_messages if m["role"] == "assistant"]
        assert len(user_msgs) >= 2  # history + new
        assert len(assistant_msgs) >= 1  # from history


class TestClaimsToolUse:
    """Test the hallucination detection heuristic."""

    def test_detects_file_write_claim(self, llm_client: LLMClient):
        assert llm_client._claims_tool_use("I've updated your notes.md file")

    def test_detects_schedule_claim(self, llm_client: LLMClient):
        assert llm_client._claims_tool_use("I've scheduled a daily reminder for you")

    def test_detects_file_creation(self, llm_client: LLMClient):
        assert llm_client._claims_tool_use("I've created a new file for you")

    def test_allows_informational_response(self, llm_client: LLMClient):
        assert not llm_client._claims_tool_use("Your folder contains 5 markdown files")

    def test_allows_suggestion(self, llm_client: LLMClient):
        assert not llm_client._claims_tool_use(
            "I suggest you create a new file for this"
        )

    def test_allows_explanation(self, llm_client: LLMClient):
        assert not llm_client._claims_tool_use("Here's what that means:")


class TestFormatToolsForPrompt:
    def test_formats_tool_descriptions(self, llm_client: LLMClient):
        """Tool descriptions are formatted for the system prompt."""
        tool_defs = [
            {
                "name": "list_files",
                "description": "List files in a directory",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "path": {
                            "type": "string",
                            "description": "Directory path",
                        }
                    },
                    "required": ["path"],
                },
            }
        ]
        result = llm_client._format_tools_for_prompt(tool_defs)
        assert "list_files" in result
        assert "List files in a directory" in result
        assert "path" in result
