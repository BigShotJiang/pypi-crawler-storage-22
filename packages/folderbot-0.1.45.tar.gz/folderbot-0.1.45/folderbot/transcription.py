"""Audio transcription via whisper.cpp (pywhispercpp)."""

import asyncio
import tempfile
from dataclasses import dataclass

from pywhispercpp.model import Model

_model_cache: dict[str, Model] = {}


def _get_model(model_name: str) -> Model:
    """Load a whisper.cpp model, caching it for reuse."""
    if model_name not in _model_cache:
        _model_cache[model_name] = Model(
            model_name, print_realtime=False, print_progress=False
        )
    return _model_cache[model_name]


@dataclass(frozen=True)
class TranscriptionResult:
    text: str


def _transcribe_sync(audio_bytes: bytes, model_name: str) -> str:
    """Synchronous transcription — runs whisper.cpp on a temp file."""
    model = _get_model(model_name)
    with tempfile.NamedTemporaryFile(suffix=".ogg", delete=True) as tmp:
        tmp.write(audio_bytes)
        tmp.flush()
        segments = model.transcribe(tmp.name)
    return " ".join(seg.text.strip() for seg in segments).strip()


async def transcribe_audio(
    audio_bytes: bytes, model_name: str = "base"
) -> TranscriptionResult:
    """Transcribe audio bytes using whisper.cpp.

    Args:
        audio_bytes: Raw audio file bytes.
        model_name: Whisper model size (tiny, base, small, medium, large).

    Returns:
        TranscriptionResult with the transcribed text.
    """
    text = await asyncio.to_thread(_transcribe_sync, audio_bytes, model_name)
    return TranscriptionResult(text=text)
