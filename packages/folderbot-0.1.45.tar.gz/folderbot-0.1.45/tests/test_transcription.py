"""Tests for audio transcription via whisper.cpp."""

from unittest.mock import MagicMock, patch

import pytest

from folderbot.transcription import TranscriptionResult, transcribe_audio


def _make_segment(text: str) -> MagicMock:
    """Create a mock whisper.cpp segment with a .text attribute."""
    seg = MagicMock()
    seg.text = text
    return seg


class TestTranscriptionResult:
    def test_frozen_dataclass(self):
        result = TranscriptionResult(text="hello world")
        assert result.text == "hello world"
        with pytest.raises(AttributeError):
            result.text = "changed"


class TestTranscribeAudio:
    @pytest.fixture(autouse=True)
    def _clear_model_cache(self):
        """Clear the model cache before each test to avoid leaking mocks."""
        with patch.dict("folderbot.transcription._model_cache", clear=True):
            yield

    @pytest.mark.asyncio
    async def test_transcribes_audio_bytes(self):
        mock_model = MagicMock()
        mock_model.transcribe.return_value = [
            _make_segment("Hello, this is a test."),
        ]

        with patch("folderbot.transcription.Model", return_value=mock_model):
            result = await transcribe_audio(
                audio_bytes=b"fake audio data",
                model_name="base",
            )

        assert result == TranscriptionResult(text="Hello, this is a test.")
        mock_model.transcribe.assert_called_once()

    @pytest.mark.asyncio
    async def test_loads_requested_model(self):
        mock_model = MagicMock()
        mock_model.transcribe.return_value = [_make_segment("transcribed")]

        with patch(
            "folderbot.transcription.Model", return_value=mock_model
        ) as mock_cls:
            await transcribe_audio(
                audio_bytes=b"data",
                model_name="small",
            )

        mock_cls.assert_called_with("small", print_realtime=False, print_progress=False)

    @pytest.mark.asyncio
    async def test_joins_multiple_segments(self):
        mock_model = MagicMock()
        mock_model.transcribe.return_value = [
            _make_segment(" hello "),
            _make_segment(" world "),
        ]

        with patch("folderbot.transcription.Model", return_value=mock_model):
            result = await transcribe_audio(
                audio_bytes=b"data",
                model_name="base",
            )

        assert result.text == "hello world"

    @pytest.mark.asyncio
    async def test_propagates_error(self):
        mock_model = MagicMock()
        mock_model.transcribe.side_effect = RuntimeError("decode failed")

        with patch("folderbot.transcription.Model", return_value=mock_model):
            with pytest.raises(RuntimeError, match="decode failed"):
                await transcribe_audio(
                    audio_bytes=b"data",
                    model_name="base",
                )

    @pytest.mark.asyncio
    async def test_caches_model_across_calls(self):
        mock_model = MagicMock()
        mock_model.transcribe.return_value = [_make_segment("hello")]

        with patch(
            "folderbot.transcription.Model", return_value=mock_model
        ) as mock_cls:
            await transcribe_audio(audio_bytes=b"a", model_name="base")
            await transcribe_audio(audio_bytes=b"b", model_name="base")

        # Model should only be loaded once for the same name
        assert mock_cls.call_count == 1
