"""Tests for CLI module."""

import argparse
from unittest.mock import patch, MagicMock

import yaml

from folderbot import cli
from folderbot.cli import (
    cmd_config_show,
    cmd_config_set,
    cmd_config_folder,
    cmd_init,
    cmd_status,
    cmd_run,
    cmd_update,
    cmd_service_install,
    cmd_service_uninstall,
    cmd_service_enable,
    cmd_service_disable,
    cmd_service_start,
    cmd_service_stop,
    cmd_service_restart,
    cmd_service_status,
    cmd_service_logs,
    load_config_yaml,
    save_config_yaml,
)
from folderbot.config import Config
from folderbot.updater import UpdateError


class TestLoadSaveConfigYaml:
    def test_load_nonexistent_returns_empty(self, monkeypatch, tmp_path):
        monkeypatch.setattr(cli, "CONFIG_PATH", tmp_path / "nonexistent.yaml")
        assert load_config_yaml() == {}

    def test_load_existing_config(self, monkeypatch, tmp_path):
        config_path = tmp_path / "config.yaml"
        config_path.write_text(yaml.dump({"model": "test-model"}))
        monkeypatch.setattr(cli, "CONFIG_PATH", config_path)

        assert load_config_yaml() == {"model": "test-model"}

    def test_save_config(self, monkeypatch, tmp_path):
        config_path = tmp_path / "config.yaml"
        monkeypatch.setattr(cli, "CONFIG_PATH", config_path)

        save_config_yaml({"model": "new-model", "allowed_user_ids": [123]})

        loaded = yaml.safe_load(config_path.read_text())
        assert loaded == {"model": "new-model", "allowed_user_ids": [123]}

    def test_save_config_creates_parent_directory(self, monkeypatch, tmp_path):
        """Test that save_config_yaml creates parent directories if they don't exist."""
        config_path = tmp_path / "nested" / "dir" / "config.yaml"
        monkeypatch.setattr(cli, "CONFIG_PATH", config_path)

        # Parent directory doesn't exist yet
        assert not config_path.parent.exists()

        save_config_yaml({"model": "test"})

        # Now parent should exist and file should be saved
        assert config_path.parent.exists()
        assert config_path.exists()
        loaded = yaml.safe_load(config_path.read_text())
        assert loaded == {"model": "test"}


class TestCmdConfigShow:
    def test_no_config_file(self, monkeypatch, tmp_path, capsys):
        monkeypatch.setattr(cli, "CONFIG_PATH", tmp_path / "nonexistent.yaml")

        result = cmd_config_show(argparse.Namespace())

        assert result == 1
        assert "No configuration file found" in capsys.readouterr().out

    def test_masks_sensitive_values(self, monkeypatch, tmp_path, capsys):
        config_path = tmp_path / "config.yaml"
        config_path.write_text(
            yaml.dump(
                {
                    "telegram_token": "1234567890abcdef",
                    "anthropic_api_key": "sk-ant-key-secret123",
                }
            )
        )
        monkeypatch.setattr(cli, "CONFIG_PATH", config_path)

        cmd_config_show(argparse.Namespace())

        output = capsys.readouterr().out
        assert "1234567890abcdef" not in output  # Full token not shown
        assert "123456" in output  # Partial shown
        assert "cdef" in output


class TestCmdConfigSet:
    def test_set_simple_value(self, monkeypatch, tmp_path):
        config_path = tmp_path / "config.yaml"
        config_path.write_text(yaml.dump({}))
        monkeypatch.setattr(cli, "CONFIG_PATH", config_path)

        cmd_config_set(argparse.Namespace(key="model", value="new-model"))

        assert yaml.safe_load(config_path.read_text())["model"] == "new-model"

    def test_set_allowed_user_ids_parses_list(self, monkeypatch, tmp_path):
        config_path = tmp_path / "config.yaml"
        config_path.write_text(yaml.dump({}))
        monkeypatch.setattr(cli, "CONFIG_PATH", config_path)

        cmd_config_set(argparse.Namespace(key="allowed_user_ids", value="123,456"))

        assert yaml.safe_load(config_path.read_text())["allowed_user_ids"] == [123, 456]

    def test_set_nested_value(self, monkeypatch, tmp_path):
        config_path = tmp_path / "config.yaml"
        config_path.write_text(yaml.dump({}))
        monkeypatch.setattr(cli, "CONFIG_PATH", config_path)

        cmd_config_set(argparse.Namespace(key="read_rules.include", value="*.py,*.md"))

        loaded = yaml.safe_load(config_path.read_text())
        assert loaded["read_rules"]["include"] == ["*.py", "*.md"]


class TestCmdConfigFolder:
    def test_set_existing_folder(self, monkeypatch, tmp_path):
        config_path = tmp_path / "config.yaml"
        config_path.write_text(yaml.dump({}))
        monkeypatch.setattr(cli, "CONFIG_PATH", config_path)

        folder = tmp_path / "my_folder"
        folder.mkdir()

        result = cmd_config_folder(argparse.Namespace(path=str(folder)))

        assert result == 0
        assert yaml.safe_load(config_path.read_text())["root_folder"] == str(folder)

    def test_nonexistent_folder_rejected(self, monkeypatch, tmp_path):
        config_path = tmp_path / "config.yaml"
        config_path.write_text(yaml.dump({}))
        monkeypatch.setattr(cli, "CONFIG_PATH", config_path)
        monkeypatch.setattr("builtins.input", lambda _: "n")

        result = cmd_config_folder(argparse.Namespace(path="/nonexistent"))

        assert result == 1


class TestCmdInit:
    def test_creates_config_with_inputs(self, monkeypatch, tmp_path):
        config_path = tmp_path / "config.yaml"
        monkeypatch.setattr(cli, "CONFIG_PATH", config_path)

        # Inputs: user_id, user_name, folder_path, google_api_key, google_cx
        regular_inputs = iter(["123456", "TestUser", "", "", ""])
        # Getpass inputs: telegram_token, anthropic_api_key
        getpass_inputs = iter(["test_token", "test_key"])
        monkeypatch.setattr(cli, "getpass", lambda _: next(getpass_inputs))
        monkeypatch.setattr("builtins.input", lambda _: next(regular_inputs))

        result = cmd_init(argparse.Namespace())

        assert result == 0
        loaded = yaml.safe_load(config_path.read_text())
        assert loaded["telegram_token"] == "test_token"
        assert loaded["anthropic_api_key"] == "test_key"
        assert loaded["allowed_user_ids"] == [123456]
        assert loaded["user_name"] == "TestUser"

    def test_fails_without_token(self, monkeypatch, tmp_path):
        monkeypatch.setattr(cli, "CONFIG_PATH", tmp_path / "config.yaml")
        monkeypatch.setattr(cli, "getpass", lambda _: "")

        result = cmd_init(argparse.Namespace())

        assert result == 1

    def test_saves_default_folder_when_user_presses_enter(self, monkeypatch, tmp_path):
        """Test that pressing Enter for folder saves cwd to config, not leaving it empty."""
        config_path = tmp_path / "config.yaml"
        monkeypatch.setattr(cli, "CONFIG_PATH", config_path)

        # Simulate user's working directory
        work_dir = tmp_path / "my_notes"
        work_dir.mkdir()
        monkeypatch.chdir(work_dir)

        # Inputs: user_id, user_name, folder_path (empty = default), google_api_key, google_cx
        regular_inputs = iter(["123456", "TestUser", "", "", ""])
        getpass_inputs = iter(["test_token", "test_key"])
        monkeypatch.setattr(cli, "getpass", lambda _: next(getpass_inputs))
        monkeypatch.setattr("builtins.input", lambda _: next(regular_inputs))

        result = cmd_init(argparse.Namespace())

        assert result == 0
        loaded = yaml.safe_load(config_path.read_text())
        # root_folder should be saved explicitly, not missing
        assert "root_folder" in loaded, (
            "root_folder should be saved even when user presses Enter"
        )
        assert loaded["root_folder"] == str(work_dir)


class TestCmdStatus:
    def test_no_config(self, monkeypatch, tmp_path, capsys):
        monkeypatch.setattr(cli, "CONFIG_PATH", tmp_path / "nonexistent.yaml")

        result = cmd_status(argparse.Namespace())

        assert result == 1
        assert "NOT CONFIGURED" in capsys.readouterr().out

    def test_with_valid_config(self, monkeypatch, tmp_path, capsys):
        config_path = tmp_path / "config.yaml"
        root_folder = tmp_path / "root"
        root_folder.mkdir()
        (root_folder / "test.md").write_text("# Test")

        config_data = {
            "telegram_token": "test_token",
            "anthropic_api_key": "test_key",
            "allowed_user_ids": [123],
            "root_folder": str(root_folder),
        }
        config_path.write_text(yaml.dump(config_data))
        monkeypatch.setattr(cli, "CONFIG_PATH", config_path)

        # Mock Config.load to use our test config
        mock_config = Config(
            telegram_token="test_token",
            anthropic_api_key="test_key",
            allowed_user_ids=[123],
            root_folder=root_folder,
        )
        monkeypatch.setattr(Config, "load", lambda path=None: mock_config)

        result = cmd_status(argparse.Namespace())

        assert result == 0
        output = capsys.readouterr().out
        assert "Status: OK" in output
        assert "Files in context:" in output


class TestCmdRun:
    def test_invalid_config_fails(self, monkeypatch, tmp_path, capsys):
        config_path = tmp_path / "config.yaml"
        config_path.write_text(yaml.dump({}))
        monkeypatch.setattr(cli, "CONFIG_PATH", config_path)

        def raise_error(path=None, bot_name=None):
            raise ValueError("TELEGRAM_BOT_TOKEN not set")

        monkeypatch.setattr(Config, "load", raise_error)

        result = cmd_run(argparse.Namespace(bot=None))

        assert result == 1
        assert "Configuration error" in capsys.readouterr().err

    def test_valid_config_starts_bot(self, monkeypatch, tmp_path):
        config_path = tmp_path / "config.yaml"
        config_path.write_text(
            yaml.dump(
                {
                    "telegram_token": "test",
                    "anthropic_api_key": "test",
                    "allowed_user_ids": [123],
                    "root_folder": str(tmp_path),
                }
            )
        )
        monkeypatch.setattr(cli, "CONFIG_PATH", config_path)

        mock_config = Config(
            telegram_token="test",
            anthropic_api_key="test",
            allowed_user_ids=[123],
            root_folder=tmp_path,
        )
        monkeypatch.setattr(
            Config, "load", lambda path=None, bot_name=None: mock_config
        )

        mock_bot = MagicMock()
        with patch("folderbot.telegram_handler.TelegramBot", return_value=mock_bot):
            result = cmd_run(argparse.Namespace(bot=None))

        assert result == 0
        mock_bot.run.assert_called_once()

    def test_run_with_bot_argument(self, monkeypatch, tmp_path):
        """Test that --bot argument is passed to Config.load."""
        config_path = tmp_path / "config.yaml"
        config_path.write_text(
            yaml.dump(
                {
                    "anthropic_api_key": "test_key",
                    "bots": {
                        "work": {
                            "telegram_token": "work_token",
                            "allowed_user_ids": [123],
                            "root_folder": str(tmp_path),
                        }
                    },
                }
            )
        )
        monkeypatch.setattr(cli, "CONFIG_PATH", config_path)

        # Track what arguments Config.load was called with
        load_calls = []

        def mock_load(path=None, bot_name=None):
            load_calls.append({"path": path, "bot_name": bot_name})
            return Config(
                telegram_token="work_token",
                anthropic_api_key="test_key",
                allowed_user_ids=[123],
                root_folder=tmp_path,
            )

        monkeypatch.setattr(Config, "load", mock_load)

        mock_bot = MagicMock()
        with patch("folderbot.telegram_handler.TelegramBot", return_value=mock_bot):
            result = cmd_run(argparse.Namespace(bot="work"))

        assert result == 0
        assert len(load_calls) == 1
        assert load_calls[0]["bot_name"] == "work"


class TestServiceInstall:
    def test_install_creates_service_file(self, monkeypatch, tmp_path, capsys):
        config_path = tmp_path / "config.yaml"
        config_path.write_text(
            yaml.dump(
                {
                    "telegram_token": "test",
                    "anthropic_api_key": "test",
                    "allowed_user_ids": [123],
                    "root_folder": str(tmp_path),
                }
            )
        )
        monkeypatch.setattr(cli, "CONFIG_PATH", config_path)

        service_path = tmp_path / "folderbot.service"
        update_service_path = tmp_path / "folderbot-update.service"
        update_timer_path = tmp_path / "folderbot-update.timer"
        monkeypatch.setattr(
            cli, "_get_service_path", lambda bot_name=None: service_path
        )
        monkeypatch.setattr(
            cli, "_get_update_service_path", lambda bot_name=None: update_service_path
        )
        monkeypatch.setattr(
            cli, "_get_update_timer_path", lambda bot_name=None: update_timer_path
        )
        monkeypatch.setattr("shutil.which", lambda _: "/usr/bin/folderbot")
        monkeypatch.setattr(cli, "_run_systemctl", lambda *args: (0, ""))

        # Mock subprocess.run for linger check
        mock_result = MagicMock()
        mock_result.stdout = "Linger=yes"
        monkeypatch.setattr("subprocess.run", lambda *args, **kwargs: mock_result)

        result = cmd_service_install(argparse.Namespace())

        assert result == 0
        assert service_path.exists()
        content = service_path.read_text()
        assert "ExecStart=/usr/bin/folderbot run" in content
        assert f"WorkingDirectory={tmp_path}" in content

    def test_install_fails_without_config(self, monkeypatch, tmp_path, capsys):
        monkeypatch.setattr(cli, "CONFIG_PATH", tmp_path / "nonexistent.yaml")
        monkeypatch.setattr("shutil.which", lambda _: "/usr/bin/folderbot")

        result = cmd_service_install(argparse.Namespace())

        assert result == 1
        assert "No configuration found" in capsys.readouterr().err

    def test_install_fails_without_folderbot_in_path(
        self, monkeypatch, tmp_path, capsys
    ):
        monkeypatch.setattr("shutil.which", lambda _: None)

        result = cmd_service_install(argparse.Namespace())

        assert result == 1
        assert "'folderbot' not found" in capsys.readouterr().err


class TestServiceUninstall:
    def test_uninstall_removes_service_file(self, monkeypatch, tmp_path, capsys):
        service_path = tmp_path / "folderbot.service"
        service_path.write_text("[Unit]\nDescription=Test")
        monkeypatch.setattr(
            cli, "_get_service_path", lambda bot_name=None: service_path
        )
        monkeypatch.setattr(cli, "_run_systemctl", lambda *args: (0, ""))

        result = cmd_service_uninstall(argparse.Namespace())

        assert result == 0
        assert not service_path.exists()
        assert "Service uninstalled" in capsys.readouterr().out

    def test_uninstall_when_not_installed(self, monkeypatch, tmp_path, capsys):
        service_path = tmp_path / "nonexistent.service"
        monkeypatch.setattr(
            cli, "_get_service_path", lambda bot_name=None: service_path
        )

        result = cmd_service_uninstall(argparse.Namespace())

        assert result == 0
        assert "not installed" in capsys.readouterr().out


class TestServiceEnable:
    def test_enable_calls_systemctl(self, monkeypatch, tmp_path, capsys):
        service_path = tmp_path / "folderbot.service"
        service_path.write_text("[Unit]\nDescription=Test")
        monkeypatch.setattr(
            cli, "_get_service_path", lambda bot_name=None: service_path
        )

        called_with = []
        monkeypatch.setattr(
            cli, "_run_systemctl", lambda *args: (called_with.append(args), (0, ""))[1]
        )

        result = cmd_service_enable(argparse.Namespace())

        assert result == 0
        assert ("enable", "folderbot") in called_with
        assert "enabled" in capsys.readouterr().out

    def test_enable_fails_without_service(self, monkeypatch, tmp_path, capsys):
        service_path = tmp_path / "nonexistent.service"
        monkeypatch.setattr(
            cli, "_get_service_path", lambda bot_name=None: service_path
        )

        result = cmd_service_enable(argparse.Namespace())

        assert result == 1
        assert "not installed" in capsys.readouterr().out


class TestServiceDisable:
    def test_disable_calls_systemctl(self, monkeypatch, capsys):
        called_with = []
        monkeypatch.setattr(
            cli, "_run_systemctl", lambda *args: (called_with.append(args), (0, ""))[1]
        )

        result = cmd_service_disable(argparse.Namespace())

        assert result == 0
        assert ("disable", "folderbot") in called_with
        assert "disabled" in capsys.readouterr().out


class TestServiceStart:
    def test_start_calls_systemctl(self, monkeypatch, tmp_path, capsys):
        service_path = tmp_path / "folderbot.service"
        service_path.write_text("[Unit]\nDescription=Test")
        monkeypatch.setattr(
            cli, "_get_service_path", lambda bot_name=None: service_path
        )

        called_with = []
        monkeypatch.setattr(
            cli, "_run_systemctl", lambda *args: (called_with.append(args), (0, ""))[1]
        )

        result = cmd_service_start(argparse.Namespace())

        assert result == 0
        assert ("start", "folderbot") in called_with
        assert "started" in capsys.readouterr().out

    def test_start_fails_without_service(self, monkeypatch, tmp_path, capsys):
        service_path = tmp_path / "nonexistent.service"
        monkeypatch.setattr(
            cli, "_get_service_path", lambda bot_name=None: service_path
        )

        result = cmd_service_start(argparse.Namespace())

        assert result == 1
        assert "not installed" in capsys.readouterr().out


class TestServiceStop:
    def test_stop_calls_systemctl(self, monkeypatch, capsys):
        called_with = []
        monkeypatch.setattr(
            cli, "_run_systemctl", lambda *args: (called_with.append(args), (0, ""))[1]
        )

        result = cmd_service_stop(argparse.Namespace())

        assert result == 0
        assert ("stop", "folderbot") in called_with
        assert "stopped" in capsys.readouterr().out


class TestServiceRestart:
    def test_restart_calls_systemctl(self, monkeypatch, tmp_path, capsys):
        service_path = tmp_path / "folderbot.service"
        service_path.write_text("[Unit]\nDescription=Test")
        monkeypatch.setattr(
            cli, "_get_service_path", lambda bot_name=None: service_path
        )

        called_with = []
        monkeypatch.setattr(
            cli, "_run_systemctl", lambda *args: (called_with.append(args), (0, ""))[1]
        )

        result = cmd_service_restart(argparse.Namespace())

        assert result == 0
        assert ("restart", "folderbot") in called_with
        assert "restarted" in capsys.readouterr().out


class TestServiceStatus:
    def test_status_when_not_installed(self, monkeypatch, tmp_path, capsys):
        service_path = tmp_path / "nonexistent.service"
        monkeypatch.setattr(
            cli, "_get_service_path", lambda bot_name=None: service_path
        )

        result = cmd_service_status(argparse.Namespace())

        assert result == 0
        output = capsys.readouterr().out
        assert "not installed" in output

    def test_status_when_installed(self, monkeypatch, tmp_path, capsys):
        service_path = tmp_path / "folderbot.service"
        service_path.write_text("[Unit]\nDescription=Test")
        monkeypatch.setattr(
            cli, "_get_service_path", lambda bot_name=None: service_path
        )
        monkeypatch.setattr(
            cli, "_run_systemctl", lambda *args: (0, "● folderbot.service - Folderbot")
        )

        result = cmd_service_status(argparse.Namespace())

        assert result == 0
        assert "folderbot.service" in capsys.readouterr().out


class TestServiceLogs:
    def test_logs_runs_journalctl(self, monkeypatch):
        import subprocess

        called_with = []

        def mock_run(cmd, *args, **kwargs):
            called_with.append(cmd)

        monkeypatch.setattr(subprocess, "run", mock_run)

        result = cmd_service_logs(argparse.Namespace(follow=False))

        assert result == 0
        assert any("journalctl" in str(cmd) for cmd in called_with)

    def test_logs_follow_mode(self, monkeypatch):
        import subprocess

        called_with = []

        def mock_run(cmd, *args, **kwargs):
            called_with.append(cmd)

        monkeypatch.setattr(subprocess, "run", mock_run)

        result = cmd_service_logs(argparse.Namespace(follow=True))

        assert result == 0
        assert any("-f" in cmd for cmd in called_with)


class TestCmdUpdate:
    def test_already_up_to_date(self, monkeypatch, capsys):
        monkeypatch.setattr(cli, "__version__", "0.1.50")
        monkeypatch.setattr("folderbot.updater.fetch_pypi_version", lambda *a: "0.1.50")

        result = cmd_update(argparse.Namespace())

        assert result == 0
        assert "up to date" in capsys.readouterr().out.lower()

    def test_update_available_and_succeeds(self, monkeypatch, tmp_path, capsys):
        monkeypatch.setattr(cli, "__version__", "0.1.50")
        monkeypatch.setattr("folderbot.updater.fetch_pypi_version", lambda *a: "0.1.51")
        monkeypatch.setattr(
            "folderbot.updater.run_pip_upgrade", lambda *a: (0, "Success")
        )
        # No service file -> no restart
        monkeypatch.setattr(
            cli,
            "_get_service_path",
            lambda bot_name=None: tmp_path / "nonexistent.service",
        )

        result = cmd_update(argparse.Namespace())

        assert result == 0
        output = capsys.readouterr().out
        assert "0.1.51" in output

    def test_update_available_but_pip_fails(self, monkeypatch, capsys):
        monkeypatch.setattr(cli, "__version__", "0.1.50")
        monkeypatch.setattr("folderbot.updater.fetch_pypi_version", lambda *a: "0.1.51")
        monkeypatch.setattr(
            "folderbot.updater.run_pip_upgrade", lambda *a: (1, "pip error")
        )

        result = cmd_update(argparse.Namespace())

        assert result == 1
        assert "pip error" in capsys.readouterr().err

    def test_network_error(self, monkeypatch, capsys):
        monkeypatch.setattr(cli, "__version__", "0.1.50")

        def raise_error(*a):
            raise UpdateError("Connection refused")

        monkeypatch.setattr("folderbot.updater.fetch_pypi_version", raise_error)

        result = cmd_update(argparse.Namespace())

        assert result == 1
        assert "Connection refused" in capsys.readouterr().err

    def test_restarts_service_if_running(self, monkeypatch, tmp_path, capsys):
        monkeypatch.setattr(cli, "__version__", "0.1.50")
        monkeypatch.setattr("folderbot.updater.fetch_pypi_version", lambda *a: "0.1.51")
        monkeypatch.setattr(
            "folderbot.updater.run_pip_upgrade", lambda *a: (0, "Success")
        )

        service_path = tmp_path / "folderbot.service"
        service_path.write_text("[Unit]\nDescription=Test")
        monkeypatch.setattr(
            cli, "_get_service_path", lambda bot_name=None: service_path
        )

        systemctl_calls = []

        def mock_systemctl(*args):
            systemctl_calls.append(args)
            return (0, "active")

        monkeypatch.setattr(cli, "_run_systemctl", mock_systemctl)

        result = cmd_update(argparse.Namespace())

        assert result == 0
        assert ("is-active", "folderbot") in systemctl_calls
        assert ("restart", "folderbot") in systemctl_calls

    def test_skips_restart_if_service_not_installed(
        self, monkeypatch, tmp_path, capsys
    ):
        monkeypatch.setattr(cli, "__version__", "0.1.50")
        monkeypatch.setattr("folderbot.updater.fetch_pypi_version", lambda *a: "0.1.51")
        monkeypatch.setattr(
            "folderbot.updater.run_pip_upgrade", lambda *a: (0, "Success")
        )
        monkeypatch.setattr(
            cli,
            "_get_service_path",
            lambda bot_name=None: tmp_path / "nonexistent.service",
        )

        systemctl_calls = []
        monkeypatch.setattr(
            cli,
            "_run_systemctl",
            lambda *a: (systemctl_calls.append(a), (0, ""))[1],
        )

        cmd_update(argparse.Namespace())

        # No systemctl calls since service doesn't exist
        assert not systemctl_calls

    def test_skips_restart_if_service_not_active(self, monkeypatch, tmp_path, capsys):
        monkeypatch.setattr(cli, "__version__", "0.1.50")
        monkeypatch.setattr("folderbot.updater.fetch_pypi_version", lambda *a: "0.1.51")
        monkeypatch.setattr(
            "folderbot.updater.run_pip_upgrade", lambda *a: (0, "Success")
        )

        service_path = tmp_path / "folderbot.service"
        service_path.write_text("[Unit]\nDescription=Test")
        monkeypatch.setattr(
            cli, "_get_service_path", lambda bot_name=None: service_path
        )

        systemctl_calls = []

        def mock_systemctl(*args):
            systemctl_calls.append(args)
            if args == ("is-active", "folderbot"):
                return (3, "inactive")  # not running
            return (0, "")

        monkeypatch.setattr(cli, "_run_systemctl", mock_systemctl)

        cmd_update(argparse.Namespace())

        assert ("is-active", "folderbot") in systemctl_calls
        assert ("restart", "folderbot") not in systemctl_calls


class TestServiceInstallWithTimer:
    def test_install_creates_update_timer_and_service(
        self, monkeypatch, tmp_path, capsys
    ):
        config_path = tmp_path / "config.yaml"
        config_path.write_text(
            yaml.dump(
                {
                    "telegram_token": "test",
                    "anthropic_api_key": "test",
                    "allowed_user_ids": [123],
                    "root_folder": str(tmp_path),
                }
            )
        )
        monkeypatch.setattr(cli, "CONFIG_PATH", config_path)

        service_path = tmp_path / "folderbot.service"
        update_service_path = tmp_path / "folderbot-update.service"
        update_timer_path = tmp_path / "folderbot-update.timer"
        monkeypatch.setattr(
            cli, "_get_service_path", lambda bot_name=None: service_path
        )
        monkeypatch.setattr(
            cli, "_get_update_service_path", lambda bot_name=None: update_service_path
        )
        monkeypatch.setattr(
            cli, "_get_update_timer_path", lambda bot_name=None: update_timer_path
        )
        monkeypatch.setattr("shutil.which", lambda _: "/usr/bin/folderbot")
        monkeypatch.setattr(cli, "_run_systemctl", lambda *args: (0, ""))

        mock_result = MagicMock()
        mock_result.stdout = "Linger=yes"
        monkeypatch.setattr("subprocess.run", lambda *args, **kwargs: mock_result)

        result = cmd_service_install(argparse.Namespace())

        assert result == 0
        assert service_path.exists()
        assert update_service_path.exists()
        assert update_timer_path.exists()

    def test_update_service_has_correct_exec_start(self, monkeypatch, tmp_path, capsys):
        config_path = tmp_path / "config.yaml"
        config_path.write_text(
            yaml.dump(
                {
                    "telegram_token": "test",
                    "anthropic_api_key": "test",
                    "allowed_user_ids": [123],
                    "root_folder": str(tmp_path),
                }
            )
        )
        monkeypatch.setattr(cli, "CONFIG_PATH", config_path)

        service_path = tmp_path / "folderbot.service"
        update_service_path = tmp_path / "folderbot-update.service"
        update_timer_path = tmp_path / "folderbot-update.timer"
        monkeypatch.setattr(
            cli, "_get_service_path", lambda bot_name=None: service_path
        )
        monkeypatch.setattr(
            cli, "_get_update_service_path", lambda bot_name=None: update_service_path
        )
        monkeypatch.setattr(
            cli, "_get_update_timer_path", lambda bot_name=None: update_timer_path
        )
        monkeypatch.setattr("shutil.which", lambda _: "/usr/bin/folderbot")
        monkeypatch.setattr(cli, "_run_systemctl", lambda *args: (0, ""))

        mock_result = MagicMock()
        mock_result.stdout = "Linger=yes"
        monkeypatch.setattr("subprocess.run", lambda *args, **kwargs: mock_result)

        cmd_service_install(argparse.Namespace())

        content = update_service_path.read_text()
        assert "ExecStart=/usr/bin/folderbot update" in content

    def test_update_timer_has_correct_interval(self, monkeypatch, tmp_path, capsys):
        config_path = tmp_path / "config.yaml"
        config_path.write_text(
            yaml.dump(
                {
                    "telegram_token": "test",
                    "anthropic_api_key": "test",
                    "allowed_user_ids": [123],
                    "root_folder": str(tmp_path),
                }
            )
        )
        monkeypatch.setattr(cli, "CONFIG_PATH", config_path)

        service_path = tmp_path / "folderbot.service"
        update_service_path = tmp_path / "folderbot-update.service"
        update_timer_path = tmp_path / "folderbot-update.timer"
        monkeypatch.setattr(
            cli, "_get_service_path", lambda bot_name=None: service_path
        )
        monkeypatch.setattr(
            cli, "_get_update_service_path", lambda bot_name=None: update_service_path
        )
        monkeypatch.setattr(
            cli, "_get_update_timer_path", lambda bot_name=None: update_timer_path
        )
        monkeypatch.setattr("shutil.which", lambda _: "/usr/bin/folderbot")
        monkeypatch.setattr(cli, "_run_systemctl", lambda *args: (0, ""))

        mock_result = MagicMock()
        mock_result.stdout = "Linger=yes"
        monkeypatch.setattr("subprocess.run", lambda *args, **kwargs: mock_result)

        cmd_service_install(argparse.Namespace())

        content = update_timer_path.read_text()
        assert "OnUnitActiveSec=5min" in content


class TestServiceUninstallWithTimer:
    def test_uninstall_removes_timer_files(self, monkeypatch, tmp_path, capsys):
        service_path = tmp_path / "folderbot.service"
        service_path.write_text("[Unit]\nDescription=Test")
        update_service_path = tmp_path / "folderbot-update.service"
        update_service_path.write_text("[Unit]\nDescription=Update")
        update_timer_path = tmp_path / "folderbot-update.timer"
        update_timer_path.write_text("[Timer]\nOnUnitActiveSec=5min")

        monkeypatch.setattr(
            cli, "_get_service_path", lambda bot_name=None: service_path
        )
        monkeypatch.setattr(
            cli, "_get_update_service_path", lambda bot_name=None: update_service_path
        )
        monkeypatch.setattr(
            cli, "_get_update_timer_path", lambda bot_name=None: update_timer_path
        )
        monkeypatch.setattr(cli, "_run_systemctl", lambda *args: (0, ""))

        result = cmd_service_uninstall(argparse.Namespace())

        assert result == 0
        assert not service_path.exists()
        assert not update_service_path.exists()
        assert not update_timer_path.exists()


class TestServiceEnableWithTimer:
    def test_enable_also_enables_timer(self, monkeypatch, tmp_path, capsys):
        service_path = tmp_path / "folderbot.service"
        service_path.write_text("[Unit]\nDescription=Test")
        monkeypatch.setattr(
            cli, "_get_service_path", lambda bot_name=None: service_path
        )

        called_with = []
        monkeypatch.setattr(
            cli,
            "_run_systemctl",
            lambda *args: (called_with.append(args), (0, ""))[1],
        )

        cmd_service_enable(argparse.Namespace())

        assert ("enable", "folderbot") in called_with
        assert ("enable", "folderbot-update.timer") in called_with


class TestServiceDisableWithTimer:
    def test_disable_also_disables_timer(self, monkeypatch, capsys):
        called_with = []
        monkeypatch.setattr(
            cli,
            "_run_systemctl",
            lambda *args: (called_with.append(args), (0, ""))[1],
        )

        cmd_service_disable(argparse.Namespace())

        assert ("disable", "folderbot") in called_with
        assert ("disable", "folderbot-update.timer") in called_with


class TestServiceStartWithTimer:
    def test_start_also_starts_timer(self, monkeypatch, tmp_path, capsys):
        service_path = tmp_path / "folderbot.service"
        service_path.write_text("[Unit]\nDescription=Test")
        monkeypatch.setattr(
            cli, "_get_service_path", lambda bot_name=None: service_path
        )

        called_with = []
        monkeypatch.setattr(
            cli,
            "_run_systemctl",
            lambda *args: (called_with.append(args), (0, ""))[1],
        )

        cmd_service_start(argparse.Namespace())

        assert ("start", "folderbot") in called_with
        assert ("start", "folderbot-update.timer") in called_with


class TestServiceStopWithTimer:
    def test_stop_also_stops_timer(self, monkeypatch, capsys):
        called_with = []
        monkeypatch.setattr(
            cli,
            "_run_systemctl",
            lambda *args: (called_with.append(args), (0, ""))[1],
        )

        cmd_service_stop(argparse.Namespace())

        assert ("stop", "folderbot") in called_with
        assert ("stop", "folderbot-update.timer") in called_with


class TestMultiBotServiceInstall:
    def test_install_with_bot_creates_named_service(
        self, monkeypatch, tmp_path, capsys
    ):
        config_path = tmp_path / "config.yaml"
        config_path.write_text(
            yaml.dump(
                {
                    "telegram_token": "test",
                    "anthropic_api_key": "test",
                    "allowed_user_ids": [123],
                    "root_folder": str(tmp_path),
                }
            )
        )
        monkeypatch.setattr(cli, "CONFIG_PATH", config_path)

        service_path = tmp_path / "folderbot-notes.service"
        monkeypatch.setattr(
            cli, "_get_service_path", lambda bot_name=None: service_path
        )
        monkeypatch.setattr(
            cli,
            "_get_update_service_path",
            lambda bot_name=None: tmp_path / "folderbot-update.service",
        )
        monkeypatch.setattr(
            cli,
            "_get_update_timer_path",
            lambda bot_name=None: tmp_path / "folderbot-update.timer",
        )
        monkeypatch.setattr("shutil.which", lambda _: "/usr/bin/folderbot")
        monkeypatch.setattr(cli, "_run_systemctl", lambda *args: (0, ""))

        mock_result = MagicMock()
        mock_result.stdout = "Linger=yes"
        monkeypatch.setattr("subprocess.run", lambda *args, **kwargs: mock_result)

        result = cmd_service_install(argparse.Namespace(bot="notes"))

        assert result == 0
        assert service_path.exists()
        content = service_path.read_text()
        assert "ExecStart=/usr/bin/folderbot run --bot notes" in content

    def test_install_without_bot_no_bot_flag(self, monkeypatch, tmp_path, capsys):
        config_path = tmp_path / "config.yaml"
        config_path.write_text(
            yaml.dump(
                {
                    "telegram_token": "test",
                    "anthropic_api_key": "test",
                    "allowed_user_ids": [123],
                    "root_folder": str(tmp_path),
                }
            )
        )
        monkeypatch.setattr(cli, "CONFIG_PATH", config_path)

        service_path = tmp_path / "folderbot.service"
        monkeypatch.setattr(
            cli, "_get_service_path", lambda bot_name=None: service_path
        )
        monkeypatch.setattr(
            cli,
            "_get_update_service_path",
            lambda bot_name=None: tmp_path / "folderbot-update.service",
        )
        monkeypatch.setattr(
            cli,
            "_get_update_timer_path",
            lambda bot_name=None: tmp_path / "folderbot-update.timer",
        )
        monkeypatch.setattr("shutil.which", lambda _: "/usr/bin/folderbot")
        monkeypatch.setattr(cli, "_run_systemctl", lambda *args: (0, ""))

        mock_result = MagicMock()
        mock_result.stdout = "Linger=yes"
        monkeypatch.setattr("subprocess.run", lambda *args, **kwargs: mock_result)

        result = cmd_service_install(argparse.Namespace(bot=None))

        assert result == 0
        content = service_path.read_text()
        assert "ExecStart=/usr/bin/folderbot run\n" in content
        assert "--bot" not in content


class TestMultiBotServiceName:
    def test_service_name_default(self):
        from folderbot.cli import _service_name

        assert _service_name() == "folderbot"

    def test_service_name_with_bot(self):
        from folderbot.cli import _service_name

        assert _service_name("notes") == "folderbot-notes"

    def test_service_name_none(self):
        from folderbot.cli import _service_name

        assert _service_name(None) == "folderbot"


class TestMultiBotServicePaths:
    def test_get_service_path_default(self):
        path = cli._get_service_path()
        assert path.name == "folderbot.service"

    def test_get_service_path_with_bot(self):
        path = cli._get_service_path("notes")
        assert path.name == "folderbot-notes.service"

    def test_get_update_service_path_default(self):
        path = cli._get_update_service_path()
        assert path.name == "folderbot-update.service"

    def test_get_update_timer_path_default(self):
        path = cli._get_update_timer_path()
        assert path.name == "folderbot-update.timer"


class TestMultiBotServiceEnable:
    def test_enable_with_bot(self, monkeypatch, tmp_path, capsys):
        service_path = tmp_path / "folderbot-notes.service"
        service_path.write_text("[Unit]\nDescription=Test")
        monkeypatch.setattr(
            cli, "_get_service_path", lambda bot_name=None: service_path
        )

        called_with = []
        monkeypatch.setattr(
            cli,
            "_run_systemctl",
            lambda *args: (called_with.append(args), (0, ""))[1],
        )

        result = cmd_service_enable(argparse.Namespace(bot="notes"))

        assert result == 0
        assert ("enable", "folderbot-notes") in called_with
        assert ("enable", "folderbot-update.timer") in called_with


class TestMultiBotServiceDisable:
    def test_disable_with_bot(self, monkeypatch, capsys):
        called_with = []
        monkeypatch.setattr(
            cli,
            "_run_systemctl",
            lambda *args: (called_with.append(args), (0, ""))[1],
        )

        result = cmd_service_disable(argparse.Namespace(bot="notes"))

        assert result == 0
        assert ("disable", "folderbot-notes") in called_with
        assert ("disable", "folderbot-update.timer") in called_with


class TestMultiBotServiceStart:
    def test_start_with_bot(self, monkeypatch, tmp_path, capsys):
        service_path = tmp_path / "folderbot-notes.service"
        service_path.write_text("[Unit]\nDescription=Test")
        monkeypatch.setattr(
            cli, "_get_service_path", lambda bot_name=None: service_path
        )

        called_with = []
        monkeypatch.setattr(
            cli,
            "_run_systemctl",
            lambda *args: (called_with.append(args), (0, ""))[1],
        )

        result = cmd_service_start(argparse.Namespace(bot="notes"))

        assert result == 0
        assert ("start", "folderbot-notes") in called_with
        assert ("start", "folderbot-update.timer") in called_with


class TestMultiBotServiceStop:
    def test_stop_with_bot(self, monkeypatch, capsys):
        called_with = []
        monkeypatch.setattr(
            cli,
            "_run_systemctl",
            lambda *args: (called_with.append(args), (0, ""))[1],
        )

        result = cmd_service_stop(argparse.Namespace(bot="notes"))

        assert result == 0
        assert ("stop", "folderbot-notes") in called_with
        assert ("stop", "folderbot-update.timer") in called_with


class TestMultiBotServiceRestart:
    def test_restart_with_bot(self, monkeypatch, tmp_path, capsys):
        service_path = tmp_path / "folderbot-notes.service"
        service_path.write_text("[Unit]\nDescription=Test")
        monkeypatch.setattr(
            cli, "_get_service_path", lambda bot_name=None: service_path
        )

        called_with = []
        monkeypatch.setattr(
            cli,
            "_run_systemctl",
            lambda *args: (called_with.append(args), (0, ""))[1],
        )

        result = cmd_service_restart(argparse.Namespace(bot="notes"))

        assert result == 0
        assert ("restart", "folderbot-notes") in called_with


class TestMultiBotServiceStatus:
    def test_status_with_bot(self, monkeypatch, tmp_path, capsys):
        service_path = tmp_path / "folderbot-notes.service"
        service_path.write_text("[Unit]\nDescription=Test")
        monkeypatch.setattr(
            cli, "_get_service_path", lambda bot_name=None: service_path
        )
        monkeypatch.setattr(
            cli,
            "_run_systemctl",
            lambda *args: (0, "● folderbot-notes.service - Folderbot"),
        )

        result = cmd_service_status(argparse.Namespace(bot="notes"))

        assert result == 0
        assert "folderbot-notes" in capsys.readouterr().out


class TestMultiBotServiceLogs:
    def test_logs_with_bot(self, monkeypatch):
        import subprocess

        called_with = []

        def mock_run(cmd, *args, **kwargs):
            called_with.append(cmd)

        monkeypatch.setattr(subprocess, "run", mock_run)

        result = cmd_service_logs(argparse.Namespace(follow=False, bot="notes"))

        assert result == 0
        assert any("folderbot-notes" in str(cmd) for cmd in called_with)


class TestMultiBotServiceParser:
    def test_service_install_has_bot_arg(self):
        from folderbot.cli import create_parser

        parser = create_parser()
        args = parser.parse_args(["service", "install", "--bot", "notes"])
        assert args.bot == "notes"

    def test_service_start_has_bot_arg(self):
        from folderbot.cli import create_parser

        parser = create_parser()
        args = parser.parse_args(["service", "start", "--bot", "notes"])
        assert args.bot == "notes"

    def test_service_stop_has_bot_arg(self):
        from folderbot.cli import create_parser

        parser = create_parser()
        args = parser.parse_args(["service", "stop", "--bot", "notes"])
        assert args.bot == "notes"


class TestCreateParserUpdate:
    def test_update_command_registered(self):
        from folderbot.cli import create_parser

        parser = create_parser()
        args = parser.parse_args(["update"])
        assert hasattr(args, "func")
        assert args.func == cmd_update
