from followthemoney.mapping.query import QueryMapping

__all__ = ["QueryMapping"]
