.. highlight:: python
.. module:: fontParts.base

BPoint
******

Must Override
-------------

May Override
------------
.. automethod:: BaseBPoint._get_anchor
.. automethod:: BaseBPoint._get_bcpIn
.. automethod:: BaseBPoint._get_bcpOut
.. automethod:: BaseBPoint._get_index
.. automethod:: BaseBPoint._get_type
.. automethod:: BaseBPoint._init
.. automethod:: BaseBPoint._moveBy
.. automethod:: BaseBPoint._rotateBy
.. automethod:: BaseBPoint._scaleBy
.. automethod:: BaseBPoint._set_anchor
.. automethod:: BaseBPoint._set_bcpIn
.. automethod:: BaseBPoint._set_bcpOut
.. automethod:: BaseBPoint._set_type
.. automethod:: BaseBPoint._skewBy
.. automethod:: BaseBPoint._transformBy
.. automethod:: BaseBPoint.copyData