.. highlight:: python
.. module:: fontParts.base

Features
********

Must Override
-------------
.. automethod:: BaseFeatures._get_text
.. automethod:: BaseFeatures._set_text

May Override
------------
.. automethod:: BaseFeatures._init
.. automethod:: BaseFeatures.copyData