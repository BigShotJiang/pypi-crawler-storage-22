from typing import Optional

from pydantic import BaseModel, Field


class OptionsChildDTOForCorrections(BaseModel):
    id: int
    name: str
    qty: int


class ModifiersChildDTOForCorrections(BaseModel):
    id: int
    name: str
    options: list[OptionsChildDTOForCorrections]
    modifiers_id: Optional[int] = None
    modifiers_name: Optional[str] = None
    options_id: Optional[int] = None
    options_name: Optional[str] = None
    modifiers_child_id: Optional[int] = None
    modifiers_child_name: Optional[str] = None
    options_child_id: Optional[int] = None
    options_child_name: Optional[str] = None


class OptionsDTOForCorrections(BaseModel):
    id: int
    name: str
    modifiers: Optional[list[ModifiersChildDTOForCorrections]] = []
    qty: int


class ModifiersDTOForCorrections(BaseModel):
    modifiers_id: int
    id: Optional[int] = None
    name: Optional[str] = None
    options: list[OptionsDTOForCorrections] = Field(default_factory=list)
    modifiers_name: Optional[str] = None
    options_id: Optional[int] = None
    options_name: Optional[str] = None
    modifiers_child_id: Optional[int] = None
    modifiers_child_name: Optional[str] = None
    options_child_id: Optional[int] = None
    options_child_name: Optional[str] = None


class RequestsTableDTOForCorrections(BaseModel):
    qty: int
    product_id: int
    id: int
    modifiers: list[ModifiersDTOForCorrections] = Field(default_factory=list)
    product_name: str
