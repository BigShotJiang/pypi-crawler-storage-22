from dataclasses import dataclass

from copy import deepcopy

from foodeo_core.commands.entities.corrections.corrections_dto import OptionsChildDTOForCorrections, \
    ModifiersChildDTOForCorrections
from foodeo_core.commands.services.corrections.utils import _index_by, _neg_qty
from foodeo_core.shared.entities.irequests import IModifierChildRequest, \
    IOptionChildRequest


@dataclass(frozen=True)
class OptionsChildDeltaService:
    def diff(self, db: list[OptionsChildDTOForCorrections] | None, cmd: list[IOptionChildRequest] | None) -> \
            list[
                OptionsChildDTOForCorrections]:
        db_by: dict[int, OptionsChildDTOForCorrections] = _index_by(db, lambda x: x.id)
        cmd_by: dict[int, IOptionChildRequest] = _index_by(cmd, lambda x: x.id)
        out: list[OptionsChildDTOForCorrections] = []

        for oid, db_item in db_by.items():
            cmd_item: IOptionChildRequest = cmd_by.get(oid)

            # deleted
            if cmd_item is None:
                d = deepcopy(db_item)
                d.qty = _neg_qty(db_item.qty)
                out.append(d)
                continue

            # reduced
            if cmd_item.qty < db_item.qty:
                d = deepcopy(db_item)
                d.qty = _neg_qty(db_item.qty - cmd_item.qty)
                out.append(d)

        return out


@dataclass(frozen=True)
class ModifierChildDeltaService:
    option_child_service: OptionsChildDeltaService

    def diff(self, db: list[ModifiersChildDTOForCorrections] | None,
             cmd: list[IModifierChildRequest] | None) -> list[
        ModifiersChildDTOForCorrections]:
        db_by: dict[int, ModifiersChildDTOForCorrections] = _index_by(db, lambda x: x.id)
        cmd_by: dict[int, IModifierChildRequest] = _index_by(cmd, lambda x: x.id)
        out: list[ModifiersChildDTOForCorrections] = []

        for mid, db_item in db_by.items():
            cmd_item: IModifierChildRequest = cmd_by.get(mid)

            # deleted child => negate all option_children
            if cmd_item is None:
                option_deltas: list[OptionsChildDTOForCorrections] = []
                for oc in (db_item.options or []):
                    d: OptionsChildDTOForCorrections = deepcopy(oc)
                    d.qty = _neg_qty(oc.qty)
                    option_deltas.append(d)
                if option_deltas:
                    dchild = deepcopy(db_item)
                    dchild.options = option_deltas
                    out.append(dchild)
                continue

            option_deltas: list[
                OptionsChildDTOForCorrections] = self.option_child_service.diff(db_item.options, cmd_item.options)
            if option_deltas:
                dchild = deepcopy(db_item)
                dchild.options = option_deltas
                out.append(dchild)
        return out
