from copy import deepcopy
from dataclasses import dataclass

from foodeo_core.commands.entities.corrections.corrections_dto import ModifiersDTOForCorrections, \
    OptionsDTOForCorrections
from foodeo_core.commands.services.corrections.modifiers_child_delta import ModifierChildDeltaService, \
    OptionsChildDeltaService
from foodeo_core.commands.services.corrections.utils import _index_by, _neg_qty
from foodeo_core.shared.entities.corrections import ModifierInCorrections
from foodeo_core.shared.entities.irequests import ModifiersRequest, IOptionRequest


@dataclass(frozen=True)
class OptionDeltaService:
    modifier_child_service: ModifierChildDeltaService

    def diff(self, db: list[OptionsDTOForCorrections] | None, cmd: list[IOptionRequest] | None) -> list[
        OptionsDTOForCorrections]:
        db_by: dict[int, OptionsDTOForCorrections] = _index_by(db, lambda x: x.id)
        cmd_by: dict[int, IOptionRequest] = _index_by(cmd, lambda x: x.id)
        out: list[OptionsDTOForCorrections] = []

        for oid, db_item in db_by.items():
            cmd_item: IOptionRequest = cmd_by.get(oid)

            # deleted option => qty negative total + (opcional) nested deletions en child tree
            if cmd_item is None:
                dopt = deepcopy(db_item)
                dopt.qty = _neg_qty(db_item.qty)

                # si querés ser estricto: al borrar la opción, también borrar su nested
                # (si tu motor ya entiende que borrar opción borra todo, podés dejar modifiers=[]).
                child_deltas = self.modifier_child_service.diff(db_item.modifiers, None)
                dopt.modifiers = child_deltas
                out.append(dopt)
                continue

            qty_delta = 0
            if cmd_item.qty < db_item.qty:
                qty_delta = _neg_qty(db_item.qty - cmd_item.qty)

            child_deltas = self.modifier_child_service.diff(db_item.modifiers, cmd_item.modifiers)

            if qty_delta != 0 or child_deltas:
                dopt = deepcopy(db_item)
                # contrato contextual: si solo cambió nested, mandamos qty vigente de option
                dopt.qty = qty_delta if qty_delta != 0 else cmd_item.qty
                dopt.modifiers = child_deltas
                out.append(dopt)

        return out


@dataclass(frozen=True)
class ModifierDeltaService:
    option_service: OptionDeltaService

    def diff(self, db: list[ModifiersDTOForCorrections] | None, cmd: list[ModifiersRequest] | None) -> list[
        ModifierInCorrections]:
        db_by: dict[int, ModifiersDTOForCorrections] = _index_by(db, lambda x: x.modifiers_id)
        cmd_by: dict[int, ModifiersRequest] = _index_by(cmd, lambda x: x.modifiers_id)
        out: list[ModifierInCorrections] = []

        for mid, db_item in db_by.items():
            cmd_item: ModifiersRequest = cmd_by.get(mid)

            # deleted modifier => negate ALL options in that modifier (and nested)
            if cmd_item is None:
                option_deltas = self.option_service.diff(db_item.options, None)
                out.extend(_flatten_modifier_options(db_item, option_deltas))
                continue

            option_deltas = self.option_service.diff(db_item.options, cmd_item.options)
            if option_deltas:
                out.extend(_flatten_modifier_options(db_item, option_deltas))

        return out


def _flatten_modifier_options(
        modifier: ModifiersDTOForCorrections,
        option_deltas: list[OptionsDTOForCorrections],
) -> list[ModifierInCorrections]:
    out: list[ModifierInCorrections] = []
    for opt in option_deltas:
        if opt.qty < 0:
            out.append(
                ModifierInCorrections(
                    modifiers_id=modifier.modifiers_id,
                    modifiers_name=modifier.modifiers_name,
                    options_id=opt.id,
                    options_name=opt.name,
                    qty=opt.qty,
                )
            )

        for child in (opt.modifiers or []):
            for child_opt in (child.options or []):
                out.append(
                    ModifierInCorrections(
                        modifiers_id=modifier.modifiers_id,
                        modifiers_name=modifier.modifiers_name,
                        options_id=opt.id,
                        options_name=opt.name,
                        modifiers_child_id=child.id,
                        modifiers_child_name=child.name,
                        options_child_id=child_opt.id,
                        options_child_name=child_opt.name,
                        qty_child=child_opt.qty,
                    )
                )
    return out


def build_modifiers_tree_negative_delta_service() -> ModifierDeltaService:
    oc = OptionsChildDeltaService()
    mc = ModifierChildDeltaService(option_child_service=oc)
    op = OptionDeltaService(modifier_child_service=mc)
    mo = ModifierDeltaService(option_service=op)
    return mo
