from typing import Callable, TypeVar

from foodeo_core.commands.entities.corrections.corrections_dto import ModifiersDTOForCorrections
from foodeo_core.shared.entities.corrections import ModifierInCorrections

T = TypeVar("T")


def _index_by(items: list[T] | None, key_fn: Callable[[T], int | None]) -> dict[int, T]:
    out: dict[int, T] = {}
    for it in (items or []):
        k = key_fn(it)
        if k is None:
            continue
        out[k] = it
    return out


def _neg_qty(qty: int) -> int:
    return -abs(int(qty))


def _map_modifier(modifier: ModifiersDTOForCorrections) -> ModifierInCorrections:
    return ModifierInCorrections(
        id=modifier.id,
        modifiers_id=modifier.modifiers_id,
        modifiers_name=modifier.modifiers_name,
        options_id=modifier.options_id,
        options_name=modifier.options_name,
        modifiers_child_id=modifier.modifiers_child_id,
        modifiers_child_name=modifier.modifiers_child_name,
        options_child_id=modifier.options_child_id,
        options_child_name=modifier.options_child_name,
    )


def _map_modifier_flat(modifier: ModifiersDTOForCorrections) -> list[ModifierInCorrections]:
    if modifier.options:
        out: list[ModifierInCorrections] = []
        for opt in modifier.options:
            out.append(
                ModifierInCorrections(
                    modifiers_id=modifier.modifiers_id,
                    modifiers_name=modifier.modifiers_name,
                    options_id=opt.id,
                    options_name=opt.name,
                )
            )
        return out
    return [_map_modifier(modifier)]
