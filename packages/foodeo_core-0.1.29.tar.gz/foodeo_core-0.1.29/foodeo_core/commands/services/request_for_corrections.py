from foodeo_core.commands.entities.corrections.corrections_dto import (
    RequestsTableDTOForCorrections,
    ModifiersDTOForCorrections,
)
from foodeo_core.commands.repositories.interfaces import IRequestsTableRepository
from foodeo_core.dataclasses.result import ResultWithValue
from foodeo_core.shared.entities import ProductInRequest, LocalRequest, ProductInCommand
from foodeo_core.shared.entities.commands import LocalCommand
from foodeo_core.shared.entities.irequests import ModifiersRequest, IModifierRequest
from foodeo_core.shared.enums import RequestEnum, FromClientEnum


class CreateRequestForCorrectionsFromCommand:
    def __init__(self, repository: IRequestsTableRepository):
        self.repository = repository

    def create_request(self, command_model: LocalCommand) -> ResultWithValue[LocalRequest | None]:
        existing_request_tables: list[
            RequestsTableDTOForCorrections] = self._get_requests_tables(command_model)
        request: LocalRequest | None = self._get_request(command_model, existing_request_tables)
        return ResultWithValue.success_value(request)

    def _get_requests_tables(self, command_model: LocalCommand) -> list[
        RequestsTableDTOForCorrections]:
        existing_request_tables: list[
            RequestsTableDTOForCorrections] = self.repository.get_requests_tables_by_command(
            command_model.id)
        return existing_request_tables

    def _get_request(self, command_model: LocalCommand,
                     existing_request_tables: list[
                         RequestsTableDTOForCorrections]) -> LocalRequest | None:

        list_product: list[ProductInRequest] = self._get_requests_products(command_model,
                                                                           existing_request_tables)
        if not list_product:
            return None
        local_request: LocalRequest = LocalRequest(qr=command_model.qr,
                                                   command_guests=command_model.command_guests,
                                                   type=RequestEnum.local,
                                                   command_id=command_model.id,
                                                   from_client=FromClientEnum.web,
                                                   details=command_model.details,
                                                   products=list_product)
        return local_request

    def _get_requests_products(self, local_request: LocalCommand,
                               existing_request_tables_in_database: list[
                                   RequestsTableDTOForCorrections]) -> list[ProductInRequest]:
        list_products: list[ProductInRequest] = []
        products_sent_in_command: list[ProductInCommand] = local_request.products
        existing_request_table_ids = {row.id for row in existing_request_tables_in_database}

        sent_by_request_table: dict[int, ProductInCommand] = {
            product.request_table: product
            for product in products_sent_in_command
            if product.request_table is not None
        }

        for item_in_database in existing_request_tables_in_database:
            item_data: ProductInCommand = sent_by_request_table.get(item_in_database.id)
            if not item_data:
                continue
            if item_in_database.qty < item_data.qty:
                qty_diff: int = item_data.qty - item_in_database.qty
                products_in_requests = ProductInRequest(qty=qty_diff, name=item_data.name,
                                                        id=item_in_database.product_id, price=item_data.price,
                                                        amount=item_data.amount, total_price=item_data.total_price,
                                                        unit_price=item_data.unit_price, )
                list_products.append(products_in_requests)

            option_qty_by_key, child_qty_by_key = self._index_command_modifiers(item_data.modifiers)
            list_modifier_by_product: list[IModifierRequest] = []
            db_option_keys: set[tuple[int, int]] = set()
            db_child_keys: set[tuple[int, int, int, int]] = set()
            for modifier_in_database in item_in_database.modifiers:
                modifiers_id = modifier_in_database.modifiers_id
                if modifiers_id is None:
                    continue

                is_child = modifier_in_database.options_child_id is not None or modifier_in_database.modifiers_child_id is not None
                if is_child:
                    if modifier_in_database.options_id is None or modifier_in_database.modifiers_child_id is None or modifier_in_database.options_child_id is None:
                        continue
                    db_option_keys.add((modifiers_id, modifier_in_database.options_id))
                    key = (
                        modifiers_id,
                        modifier_in_database.options_id,
                        modifier_in_database.modifiers_child_id,
                        modifier_in_database.options_child_id,
                    )
                    db_child_keys.add(key)
                    modifier_db_qty = modifier_in_database.qty_child
                    if modifier_db_qty is None:
                        continue
                    modifier_cmd_qty = child_qty_by_key.get(key)
                    if modifier_cmd_qty is None:
                        continue
                    if modifier_db_qty < modifier_cmd_qty:
                        qty_diff = modifier_cmd_qty - modifier_db_qty
                        list_modifier_by_product.append(
                            self._build_modifier_request(modifier_in_database, qty_child=qty_diff)
                        )
                else:
                    if modifier_in_database.options_id is None:
                        continue
                    key = (modifiers_id, modifier_in_database.options_id)
                    db_option_keys.add(key)
                    modifier_db_qty = modifier_in_database.qty
                    if modifier_db_qty is None:
                        continue
                    modifier_cmd_qty = option_qty_by_key.get(key)
                    if modifier_cmd_qty is None:
                        continue
                    if modifier_db_qty < modifier_cmd_qty:
                        qty_diff = modifier_cmd_qty - modifier_db_qty
                        list_modifier_by_product.append(
                            self._build_modifier_request(modifier_in_database, qty=qty_diff)
                        )
            for (modifiers_id, options_id), modifier_cmd_qty in option_qty_by_key.items():
                if (modifiers_id, options_id) in db_option_keys:
                    continue
                list_modifier_by_product.append(
                    ModifiersRequest.model_construct(
                        modifiers_id=modifiers_id,
                        options_id=options_id,
                        qty=modifier_cmd_qty,
                    )
                )

            for (
                modifiers_id,
                options_id,
                modifiers_child_id,
                options_child_id,
            ), modifier_cmd_qty in child_qty_by_key.items():
                key = (modifiers_id, options_id, modifiers_child_id, options_child_id)
                if key in db_child_keys:
                    continue
                list_modifier_by_product.append(
                    ModifiersRequest.model_construct(
                        modifiers_id=modifiers_id,
                        options_id=options_id,
                        modifiers_child_id=modifiers_child_id,
                        options_child_id=options_child_id,
                        qty_child=modifier_cmd_qty,
                    )
                )
            if list_modifier_by_product:
                products_in_requests = ProductInRequest(qty=item_in_database.qty, name=item_data.name,
                                                        id=item_in_database.product_id, price=item_data.price,
                                                        amount=item_data.amount, total_price=item_data.total_price,
                                                        unit_price=item_data.unit_price,
                                                        modifiers=list_modifier_by_product)
                list_products.append(products_in_requests)

        for cmd_product in products_sent_in_command:
            if cmd_product.request_table is None or cmd_product.request_table not in existing_request_table_ids:
                list_products.append(
                    ProductInRequest(
                        qty=cmd_product.qty,
                        name=cmd_product.name,
                        id=cmd_product.id,
                        price=cmd_product.price,
                        amount=cmd_product.amount,
                        total_price=cmd_product.total_price,
                        unit_price=cmd_product.unit_price,
                        modifiers=cmd_product.modifiers,
                    )
                )

        return list_products

    @staticmethod
    def _index_command_modifiers(
            modifiers: list[ModifiersRequest] | None,
    ) -> tuple[
        dict[tuple[int, int], int],
        dict[tuple[int, int, int, int], int],
    ]:
        option_qty_by_key: dict[tuple[int, int], int] = {}
        child_qty_by_key: dict[tuple[int, int, int, int], int] = {}
        for modifier in modifiers or []:
            modifiers_id = modifier.modifiers_id or modifier.id
            if modifiers_id is None:
                continue
            options = modifier.options or []
            if options:
                for option in options:
                    if option.id is None:
                        continue
                    key = (modifiers_id, option.id)
                    option_qty_by_key[key] = option_qty_by_key.get(key, 0) + option.qty
                    for modifier_child in option.modifiers or []:
                        if modifier_child.id is None:
                            continue
                        for option_child in modifier_child.options or []:
                            if option_child.id is None:
                                continue
                            child_key = (modifiers_id, option.id, modifier_child.id, option_child.id)
                            child_qty_by_key[child_key] = child_qty_by_key.get(child_key, 0) + option_child.qty
                continue

            if modifier.options_id is not None and modifier.qty is not None:
                key = (modifiers_id, modifier.options_id)
                option_qty_by_key[key] = option_qty_by_key.get(key, 0) + modifier.qty

            if (
                modifier.options_id is not None
                and modifier.modifiers_child_id is not None
                and modifier.options_child_id is not None
                and modifier.qty_child is not None
            ):
                child_key = (
                    modifiers_id,
                    modifier.options_id,
                    modifier.modifiers_child_id,
                    modifier.options_child_id,
                )
                child_qty_by_key[child_key] = child_qty_by_key.get(child_key, 0) + modifier.qty_child
        return option_qty_by_key, child_qty_by_key

    @staticmethod
    def _build_modifier_request(
            modifier: ModifiersDTOForCorrections,
            *,
            qty: int | None = None,
            qty_child: int | None = None,
    ) -> ModifiersRequest:
        return ModifiersRequest.model_construct(
            id=modifier.id,
            modifiers_id=modifier.modifiers_id,
            modifiers_name=modifier.modifiers_name,
            options_id=modifier.options_id,
            options_name=modifier.options_name,
            modifiers_child_id=modifier.modifiers_child_id,
            modifiers_child_name=modifier.modifiers_child_name,
            options_child_id=modifier.options_child_id,
            options_child_name=modifier.options_child_name,
            qty=qty,
            qty_child=qty_child,
        )
