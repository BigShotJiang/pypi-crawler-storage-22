Para correr los test:
-  source ~/venv/foodeo-core/bin/activate
-  python3 -m unittest