"""
OAuth 2.0 Device Authorization Grant (RFC 8628) client.

Provides agent-friendly authentication for the `ate` CLI.
The device flow allows headless/CLI clients to authenticate
by having the user authorize on a separate device with a browser.
"""

import time
from dataclasses import dataclass

import requests


class DeviceFlowError(Exception):
    """General device flow error."""
    pass


class DeviceFlowTimeout(DeviceFlowError):
    """Polling timed out waiting for user authorization."""
    pass


class DeviceFlowDenied(DeviceFlowError):
    """User denied the authorization request."""
    pass


@dataclass
class DeviceCodeResponse:
    """Response from the device authorization endpoint."""
    device_code: str
    user_code: str           # e.g. "ABCD-1234" — human types this
    verification_uri: str    # e.g. "https://kindly.fyi/device"
    expires_in: int          # seconds (default 600)
    interval: int            # polling interval seconds (default 5)


@dataclass
class TokenResponse:
    """Token response from the token endpoint."""
    access_token: str
    refresh_token: str
    expires_in: int          # seconds
    token_type: str          # "Bearer"


class DeviceFlowClient:
    """OAuth 2.0 Device Authorization Grant (RFC 8628) client."""

    def __init__(self, server_url: str = "https://kindly.fyi"):
        self.server_url = server_url

    def request_code(self) -> DeviceCodeResponse:
        """POST /api/auth/device/code → DeviceCodeResponse.

        Raises DeviceFlowError on HTTP or network errors.
        """
        try:
            resp = requests.post(
                f"{self.server_url}/api/auth/device/code",
                json={"client_id": "ate-cli"},
                timeout=10,
            )
            resp.raise_for_status()
            data = resp.json()
            return DeviceCodeResponse(
                device_code=data["device_code"],
                user_code=data["user_code"],
                verification_uri=data["verification_uri"],
                expires_in=data["expires_in"],
                interval=data["interval"],
            )
        except Exception as e:
            if isinstance(e, DeviceFlowError):
                raise
            raise DeviceFlowError(f"Failed to request device code: {e}") from e

    def poll_for_token(
        self,
        device_code: str,
        interval: int = 5,
        expires_in: int = 600,
    ) -> TokenResponse:
        """Poll POST /api/auth/device/token until authorized or expired.

        Returns TokenResponse on success.
        Raises DeviceFlowTimeout if expires_in exceeded.
        Raises DeviceFlowDenied if user denied.
        """
        current_interval = interval
        start_time = time.time()

        while True:
            time.sleep(current_interval)

            elapsed = time.time() - start_time
            if elapsed > expires_in:
                raise DeviceFlowTimeout(
                    f"Device authorization timed out after {expires_in}s"
                )

            resp = requests.post(
                f"{self.server_url}/api/auth/device/token",
                json={
                    "client_id": "ate-cli",
                    "device_code": device_code,
                    "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
                },
                timeout=10,
            )

            if resp.status_code == 200:
                data = resp.json()
                return TokenResponse(
                    access_token=data["access_token"],
                    refresh_token=data["refresh_token"],
                    expires_in=data["expires_in"],
                    token_type=data["token_type"],
                )

            # Handle error responses (400-level)
            try:
                error_data = resp.json()
            except Exception:
                continue

            error = error_data.get("error", "")

            if error == "authorization_pending":
                continue
            elif error == "slow_down":
                current_interval += 5
                continue
            elif error == "access_denied":
                raise DeviceFlowDenied("User denied the authorization request")
            elif error == "expired_token":
                raise DeviceFlowTimeout("Device code expired")
            else:
                continue
