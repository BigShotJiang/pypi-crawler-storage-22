"""
FoodforThought API Client.

HTTP client for interacting with the FoodforThought API.
"""

import json
import os
import sys
from pathlib import Path
from typing import Optional, Dict

import requests

BASE_URL = os.getenv("ATE_API_URL", "https://www.kindly.fyi/api")
API_KEY = os.getenv("ATE_API_KEY", "")
CONFIG_DIR = Path.home() / ".ate"
CONFIG_FILE = CONFIG_DIR / "config.json"


class ATEClient:
    """Client for interacting with FoodforThought API."""

    def __init__(self, base_url: str = BASE_URL, api_key: Optional[str] = None):
        self.base_url = base_url
        self.headers = {
            "Content-Type": "application/json",
        }
        self._config = {}
        self._device_id = None

        # Try to load from config file first (device auth flow)
        if CONFIG_FILE.exists():
            try:
                with open(CONFIG_FILE) as f:
                    self._config = json.load(f)

                    # Prefer access_token from device auth flow
                    access_token = self._config.get("access_token")
                    if access_token:
                        self.headers["Authorization"] = f"Bearer {access_token}"
                        self._device_id = self._config.get("device_id")
                    else:
                        # Fall back to legacy api_key
                        stored_key = self._config.get("api_key")
                        if stored_key:
                            self.headers["Authorization"] = f"Bearer {stored_key}"
            except Exception:
                pass

        # Override with explicit api_key or env var if provided
        if api_key is None:
            api_key = os.getenv("ATE_API_KEY", API_KEY)

        if api_key:
            self.headers["Authorization"] = f"Bearer {api_key}"

        if "Authorization" not in self.headers:
            print("Warning: Not logged in. Run 'ate login' to authenticate.", file=sys.stderr)

    def _request(self, method: str, endpoint: str, **kwargs) -> Dict:
        """Make HTTP request to API."""
        url = f"{self.base_url}{endpoint}"
        try:
            # Handle params for GET requests
            if method == "GET" and "params" in kwargs:
                response = requests.get(url, headers=self.headers, params=kwargs["params"])
            else:
                response = requests.request(method, url, headers=self.headers, **kwargs)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            print(f"Error: {e}", file=sys.stderr)
            sys.exit(1)

    def get(self, endpoint: str, **kwargs) -> Dict:
        """Make GET request."""
        return self._request("GET", endpoint, **kwargs)

    def post(self, endpoint: str, data: Dict = None, **kwargs) -> Dict:
        """Make POST request."""
        return self._request("POST", endpoint, json=data, **kwargs)

    def put(self, endpoint: str, data: Dict = None, **kwargs) -> Dict:
        """Make PUT request."""
        return self._request("PUT", endpoint, json=data, **kwargs)

    def delete(self, endpoint: str, **kwargs) -> Dict:
        """Make DELETE request."""
        return self._request("DELETE", endpoint, **kwargs)
