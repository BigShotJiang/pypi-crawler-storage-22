"""
Authentication commands for FoodforThought CLI.

Commands:
- ate login  - Authenticate with FoodforThought via browser
- ate logout - Log out and remove stored credentials
- ate whoami - Show current logged-in user
"""

import json
import os
import sys
import time
from pathlib import Path

import requests

from ate.auth.device_flow import DeviceFlowClient, DeviceFlowTimeout, DeviceFlowDenied, DeviceFlowError
from ate.auth.token_store import TokenStore

BASE_URL = os.getenv("ATE_API_URL", "https://kindly.fyi/api")
CONFIG_DIR = Path.home() / ".ate"
CONFIG_FILE = CONFIG_DIR / "config.json"


def _generate_pkce():
    """Generate PKCE code verifier and challenge."""
    import hashlib
    import base64
    import secrets

    # Generate code verifier (43-128 chars, URL-safe)
    code_verifier = secrets.token_urlsafe(32)

    # Generate code challenge (SHA256 hash of verifier, base64url encoded)
    digest = hashlib.sha256(code_verifier.encode()).digest()
    code_challenge = base64.urlsafe_b64encode(digest).rstrip(b'=').decode()

    return code_verifier, code_challenge


def _generate_device_id():
    """Generate a unique device ID for this CLI installation."""
    import platform
    import hashlib

    # Create a stable device ID based on machine info
    machine_info = f"{platform.node()}-{platform.system()}-{platform.machine()}"
    return f"cli-{hashlib.sha256(machine_info.encode()).hexdigest()[:16]}"


def login_command():
    """Interactive login via browser (GitHub-style device flow)."""
    import webbrowser

    print("Authenticating with FoodforThought...")
    print()

    # Generate PKCE
    code_verifier, code_challenge = _generate_pkce()
    device_id = _generate_device_id()

    # Step 1: Initiate device auth
    try:
        response = requests.post(
            f"{BASE_URL}/device-auth/initiate",
            json={
                "codeChallenge": code_challenge,
                "deviceId": device_id,
                "deviceName": "FoodforThought CLI",
            },
            timeout=10,
        )
        response.raise_for_status()
        data = response.json()
    except requests.RequestException as e:
        print(f"Error: Failed to initiate login: {e}", file=sys.stderr)
        sys.exit(1)

    if not data.get("success"):
        print(f"Error: {data.get('error', 'Unknown error')}", file=sys.stderr)
        sys.exit(1)

    auth_url = data["authUrl"]
    state = data["state"]

    # Step 2: Open browser
    print("Opening browser for authentication...")
    print(f"If browser doesn't open, visit: {auth_url}")
    print()

    try:
        webbrowser.open(auth_url)
    except Exception:
        pass  # Browser open is best-effort

    # Step 3: Poll for authorization
    print("Waiting for authorization...", end="", flush=True)

    max_attempts = 120  # 2 minutes with 1s intervals
    poll_interval = 1.0
    callback_token = None

    for attempt in range(max_attempts):
        time.sleep(poll_interval)

        try:
            poll_response = requests.post(
                f"{BASE_URL}/device-auth/poll",
                json={"state": state, "deviceId": device_id},
                timeout=10,
            )
            poll_data = poll_response.json()
        except requests.RequestException:
            print(".", end="", flush=True)
            continue

        status = poll_data.get("status")

        if status == "pending":
            print(".", end="", flush=True)
            continue
        elif status == "authorized":
            print(" authorized!")
            callback_token = poll_data.get("token")
            break
        elif status == "expired":
            print("\nError: Authorization request expired. Please try again.", file=sys.stderr)
            sys.exit(1)
        elif status == "exchanged":
            print("\nError: This authorization was already used. Please try again.", file=sys.stderr)
            sys.exit(1)
        else:
            print(".", end="", flush=True)
    else:
        print("\nError: Timeout waiting for authorization.", file=sys.stderr)
        sys.exit(1)

    # Step 4: Exchange for access token
    print("Exchanging for access token...")

    try:
        exchange_response = requests.post(
            f"{BASE_URL}/device-auth/exchange",
            json={
                "token": callback_token,
                "state": state,
                "codeVerifier": code_verifier,
                "deviceId": device_id,
            },
            timeout=10,
        )
        exchange_response.raise_for_status()
        exchange_data = exchange_response.json()
    except requests.RequestException as e:
        print(f"Error: Failed to exchange token: {e}", file=sys.stderr)
        sys.exit(1)

    if not exchange_data.get("success"):
        print(f"Error: {exchange_data.get('error', 'Unknown error')}", file=sys.stderr)
        sys.exit(1)

    access_token = exchange_data["accessToken"]
    refresh_token = exchange_data["refreshToken"]
    user = exchange_data.get("user", {})
    expires_at = exchange_data.get("expiresAt")

    # Step 5: Save credentials
    try:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)

        config = {}
        if CONFIG_FILE.exists():
            try:
                with open(CONFIG_FILE) as f:
                    config = json.load(f)
            except Exception:
                pass

        config["access_token"] = access_token
        config["refresh_token"] = refresh_token
        config["device_id"] = device_id
        config["expires_at"] = expires_at
        config["user"] = {
            "id": user.get("id"),
            "email": user.get("email"),
            "name": user.get("name"),
        }

        with open(CONFIG_FILE, "w") as f:
            json.dump(config, f, indent=2)

        # Set restrictive permissions
        CONFIG_FILE.chmod(0o600)

    except Exception as e:
        print(f"Error saving credentials: {e}", file=sys.stderr)
        sys.exit(1)

    print()
    print(f"✓ Logged in as {user.get('name') or user.get('email')}")
    print(f"  Credentials saved to {CONFIG_FILE}")


def logout_command():
    """Log out and remove stored credentials."""
    if not CONFIG_FILE.exists():
        print("Not logged in.")
        return

    try:
        # Load config to get device_id for revoking
        with open(CONFIG_FILE) as f:
            config = json.load(f)

        access_token = config.get("access_token")
        device_id = config.get("device_id")

        # Try to revoke the session on the server
        if access_token and device_id:
            try:
                requests.post(
                    f"{BASE_URL}/device-auth/revoke",
                    json={"accessToken": access_token, "deviceId": device_id},
                    timeout=5,
                )
            except Exception:
                pass  # Best effort

        # Remove local credentials
        CONFIG_FILE.unlink()
        print("✓ Logged out successfully.")

    except Exception as e:
        print(f"Error during logout: {e}", file=sys.stderr)
        # Still try to remove the file
        try:
            CONFIG_FILE.unlink()
        except Exception:
            pass


def whoami_command():
    """Show current logged-in user."""
    if not CONFIG_FILE.exists():
        print("Not logged in. Run 'ate login' to authenticate.")
        sys.exit(1)

    try:
        with open(CONFIG_FILE) as f:
            config = json.load(f)

        user = config.get("user", {})
        access_token = config.get("access_token")
        expires_at = config.get("expires_at")

        if not access_token:
            # Legacy api_key mode
            if config.get("api_key"):
                print("Authenticated via API key (legacy mode)")
                print("Run 'ate login' to upgrade to device authentication.")
                return
            else:
                print("Not logged in. Run 'ate login' to authenticate.")
                sys.exit(1)

        print(f"Logged in as: {user.get('name') or 'Unknown'}")
        print(f"Email: {user.get('email') or 'Unknown'}")
        if expires_at:
            print(f"Session expires: {expires_at}")

    except Exception as e:
        print(f"Error reading credentials: {e}", file=sys.stderr)
        sys.exit(1)


def device_login_command(args):
    """Handle device-login subcommand: start device flow, check status, or logout."""
    store = TokenStore()

    # --logout: clear stored tokens
    if getattr(args, "logout", False):
        store.clear()
        print("Device flow credentials cleared.")
        return

    # --status: show token info
    if getattr(args, "status", False):
        token = store.load()
        if token is None:
            print("Not authenticated via device flow.")
            sys.exit(1)

        expired = store.is_expired()
        needs_refresh = store.needs_refresh()
        info = {
            "authenticated": True,
            "token_type": token.token_type,
            "expired": expired,
            "needs_refresh": needs_refresh,
        }
        if getattr(args, "format", None) == "json":
            print(json.dumps(info))
        else:
            status = "expired" if expired else ("needs refresh" if needs_refresh else "valid")
            print(f"Authenticated via device flow (status: {status})")
        return

    # Default: start device flow
    server = getattr(args, "server", "https://kindly.fyi")
    output_format = getattr(args, "format", None)

    client = DeviceFlowClient(server_url=server)

    try:
        code_resp = client.request_code()
    except DeviceFlowError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    if output_format == "json":
        print(json.dumps({
            "user_code": code_resp.user_code,
            "verification_uri": code_resp.verification_uri,
            "expires_in": code_resp.expires_in,
        }))
    else:
        print(f"Visit {code_resp.verification_uri} and enter code: {code_resp.user_code}")

    try:
        token_resp = client.poll_for_token(
            code_resp.device_code,
            interval=code_resp.interval,
            expires_in=code_resp.expires_in,
        )
    except DeviceFlowTimeout:
        print("Error: Authorization timed out.", file=sys.stderr)
        sys.exit(1)
    except DeviceFlowDenied:
        print("Error: Authorization denied.", file=sys.stderr)
        sys.exit(1)

    store.save(token_resp)

    if output_format == "json":
        print(json.dumps({"status": "authenticated", "token_type": token_resp.token_type}))
    else:
        print("✓ Authenticated successfully via device flow.")


def register_parser(subparsers):
    """Register auth commands with argparse."""
    subparsers.add_parser("login", help="Authenticate with FoodforThought via browser")
    subparsers.add_parser("logout", help="Log out and remove stored credentials")
    subparsers.add_parser("whoami", help="Show current logged-in user")

    # Device flow subcommand
    device_parser = subparsers.add_parser(
        "device-login",
        help="Authenticate via OAuth 2.0 Device Flow (agent-friendly)",
    )
    device_parser.add_argument(
        "--server", default="https://kindly.fyi",
        help="Server URL (default: https://kindly.fyi)",
    )
    device_parser.add_argument(
        "--format", choices=["json"], default=None,
        help="Output format (default: human-readable)",
    )
    device_parser.add_argument(
        "--status", action="store_true",
        help="Check current device flow token status",
    )
    device_parser.add_argument(
        "--logout", action="store_true",
        help="Clear stored device flow tokens",
    )


def handle(client, args):
    """Handle auth commands. Note: these don't need the client."""
    if args.command == "login":
        login_command()
    elif args.command == "logout":
        logout_command()
    elif args.command == "whoami":
        whoami_command()
    elif args.command == "device-login":
        device_login_command(args)
