"""
Cloud client for FoodforThought memory API.

Handles push (upload), pull (download), list, and delete of .mv2 memory files.
"""

import os
from dataclasses import dataclass
from typing import List

import requests


# ---------------------------------------------------------------------------
# Result dataclasses
# ---------------------------------------------------------------------------

@dataclass
class PushResult:
    id: str
    name: str
    project: str
    size_bytes: int
    url: str
    created_at: str


@dataclass
class PullResult:
    path: str
    size_bytes: int
    name: str
    project: str


@dataclass
class MemoryListItem:
    id: str
    name: str
    project: str
    size_bytes: int
    created_at: str
    updated_at: str


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class CloudError(Exception):
    """Base exception for cloud operations."""
    pass


class CloudAuthError(CloudError):
    """Raised when authentication is missing or invalid."""
    pass


class CloudNotFoundError(CloudError):
    """Raised when a requested resource is not found (404)."""
    pass


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------

class CloudClient:
    """Client for FoodforThought memory cloud API."""

    def __init__(self, server_url: str = "https://kindly.fyi", token: str = None):
        self.server_url = server_url.rstrip("/")
        self.token = token

    # -- public API --------------------------------------------------------

    def push(self, local_path: str, project: str, name: str = None) -> PushResult:
        """Upload .mv2 file to cloud.

        POST /api/memory/upload (multipart/form-data)

        Args:
            local_path: Path to the local .mv2 file.
            project: Project identifier (e.g. "kindly/memories").
            name: Optional name override; defaults to the file's basename.

        Returns:
            PushResult with upload details.

        Raises:
            CloudAuthError: If no token is set.
            CloudError: On server error.
        """
        headers = self._auth_headers()
        resolved_name = name or os.path.basename(local_path)

        url = f"{self.server_url}/api/memory/upload"

        with open(local_path, "rb") as f:
            resp = requests.post(
                url,
                headers=headers,
                files={"file": (resolved_name, f)},
                data={"project": project, "name": resolved_name},
            )

        if resp.status_code == 401:
            raise CloudAuthError("Invalid or expired token")
        if resp.status_code >= 400:
            raise CloudError(f"Push failed ({resp.status_code}): {resp.text}")

        body = resp.json()
        return PushResult(
            id=body["id"],
            name=body["name"],
            project=body["project"],
            size_bytes=body["size_bytes"],
            url=body["url"],
            created_at=body["created_at"],
        )

    def pull(self, project: str, name: str, output_path: str) -> PullResult:
        """Download .mv2 file from cloud.

        GET /api/memory/{project}/{name}

        Args:
            project: Project identifier.
            name: Memory file name.
            output_path: Local path to write the downloaded file.

        Returns:
            PullResult with download details.

        Raises:
            CloudAuthError: If no token is set.
            CloudNotFoundError: If the file is not found (404).
            CloudError: On server error.
        """
        headers = self._auth_headers()
        url = f"{self.server_url}/api/memory/{project}/{name}"

        resp = requests.get(url, headers=headers)

        if resp.status_code == 404:
            raise CloudNotFoundError(f"Not found: {project}/{name}")
        if resp.status_code == 401:
            raise CloudAuthError("Invalid or expired token")
        if resp.status_code >= 400:
            raise CloudError(f"Pull failed ({resp.status_code}): {resp.text}")

        # Write content to disk
        parent = os.path.dirname(output_path)
        if parent:
            os.makedirs(parent, exist_ok=True)

        with open(output_path, "wb") as f:
            f.write(resp.content)

        size = len(resp.content)
        return PullResult(
            path=output_path,
            size_bytes=size,
            name=name,
            project=project,
        )

    def list(self, project: str) -> List[MemoryListItem]:
        """List memory files in a project.

        GET /api/memory/list?project={project}

        Args:
            project: Project identifier.

        Returns:
            List of MemoryListItem.

        Raises:
            CloudAuthError: If no token is set.
            CloudError: On server error.
        """
        headers = self._auth_headers()
        url = f"{self.server_url}/api/memory/list"

        resp = requests.get(url, headers=headers, params={"project": project})

        if resp.status_code == 401:
            raise CloudAuthError("Invalid or expired token")
        if resp.status_code >= 400:
            raise CloudError(f"List failed ({resp.status_code}): {resp.text}")

        body = resp.json()
        return [
            MemoryListItem(
                id=item["id"],
                name=item["name"],
                project=item["project"],
                size_bytes=item["size_bytes"],
                created_at=item["created_at"],
                updated_at=item["updated_at"],
            )
            for item in body.get("items", [])
        ]

    def delete(self, project: str, name: str) -> bool:
        """Delete a memory file from cloud.

        DELETE /api/memory/{project}/{name}

        Args:
            project: Project identifier.
            name: Memory file name.

        Returns:
            True on success.

        Raises:
            CloudAuthError: If no token is set.
            CloudNotFoundError: If the file is not found (404).
            CloudError: On server error.
        """
        headers = self._auth_headers()
        url = f"{self.server_url}/api/memory/{project}/{name}"

        resp = requests.delete(url, headers=headers)

        if resp.status_code == 404:
            raise CloudNotFoundError(f"Not found: {project}/{name}")
        if resp.status_code == 401:
            raise CloudAuthError("Invalid or expired token")
        if resp.status_code >= 400:
            raise CloudError(f"Delete failed ({resp.status_code}): {resp.text}")

        return True

    # -- internal ----------------------------------------------------------

    def _auth_headers(self) -> dict:
        """Build authorization headers."""
        if not self.token:
            raise CloudAuthError("Not authenticated. Run: ate device-login")
        return {"Authorization": f"Bearer {self.token}"}
