"""FoodforThought CLI (ATE) - GitHub-like interface for robotics repositories"""

__version__ = "0.2.7"

# LLM Proxy for metered AI access
try:
    from .llm_proxy import LLMProxy, LLMProxyError, LLMResponse, get_proxy
except ImportError:
    pass  # Optional dependency

