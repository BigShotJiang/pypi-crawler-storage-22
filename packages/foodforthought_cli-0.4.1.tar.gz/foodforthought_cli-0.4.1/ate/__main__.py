#!/usr/bin/env python3
"""
Enable running ate as a module: python -m ate

This allows the CLI to be invoked via:
    python -m ate --help
    python -m ate robot upload mechdog --dry-run
    python -m ate login

Instead of requiring the installed entry point.
"""

from ate.cli import main

if __name__ == "__main__":
    main()
