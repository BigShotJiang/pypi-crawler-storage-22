"""OAuth 2.0 Device Authorization Grant (RFC 8628) auth package."""
