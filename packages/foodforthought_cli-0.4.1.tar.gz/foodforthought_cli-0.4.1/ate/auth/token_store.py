"""
Token persistence for OAuth 2.0 device flow credentials.

Stores tokens at ~/.ate/credentials.json with expiry tracking.
"""

import json
import os
import time
from typing import Optional

from ate.auth.device_flow import TokenResponse


class TokenStore:
    """Manages token persistence at ~/.ate/credentials.json."""

    def __init__(self, path: str = None):
        self.path = path or os.path.expanduser("~/.ate/credentials.json")

    def save(self, token_response: TokenResponse) -> None:
        """Save tokens to disk (creates parent dirs).

        Records saved_at timestamp for expiry calculations.
        """
        parent = os.path.dirname(self.path)
        if parent:
            os.makedirs(parent, exist_ok=True)

        data = {
            "access_token": token_response.access_token,
            "refresh_token": token_response.refresh_token,
            "expires_in": token_response.expires_in,
            "token_type": token_response.token_type,
            "saved_at": time.time(),
        }

        with open(self.path, "w") as f:
            json.dump(data, f, indent=2)

    def load(self) -> Optional[TokenResponse]:
        """Load tokens from disk. Returns None if no credentials or invalid."""
        if not os.path.exists(self.path):
            return None

        try:
            with open(self.path) as f:
                data = json.load(f)
            return TokenResponse(
                access_token=data["access_token"],
                refresh_token=data["refresh_token"],
                expires_in=data["expires_in"],
                token_type=data["token_type"],
            )
        except (json.JSONDecodeError, KeyError, TypeError):
            return None

    def clear(self) -> None:
        """Delete stored credentials."""
        try:
            os.remove(self.path)
        except FileNotFoundError:
            pass

    def _load_raw(self) -> Optional[dict]:
        """Load raw JSON data including saved_at."""
        if not os.path.exists(self.path):
            return None
        try:
            with open(self.path) as f:
                return json.load(f)
        except (json.JSONDecodeError, TypeError):
            return None

    def _expires_at(self) -> Optional[float]:
        """Calculate the absolute expiry time."""
        data = self._load_raw()
        if data is None:
            return None
        saved_at = data.get("saved_at", 0)
        expires_in = data.get("expires_in", 0)
        return saved_at + expires_in

    def is_expired(self) -> bool:
        """Check if the access token has expired."""
        expires_at = self._expires_at()
        if expires_at is None:
            return True
        return time.time() >= expires_at

    def needs_refresh(self) -> bool:
        """Check if token is within 5 minutes of expiry."""
        expires_at = self._expires_at()
        if expires_at is None:
            return True
        return time.time() >= (expires_at - 300)
