#!/usr/bin/env python3
"""
FoodforThought CLI - Main entry point.

A command-line interface for the FoodforThought robotics platform.
"""

import argparse
import sys

from ate.client import ATEClient
from ate.commands import register_all_parsers, handle_command


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        description="FoodforThought CLI - Robotics skill development platform",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  ate login                     # Authenticate with FoodforThought
  ate init my-skill             # Initialize a new skill repository
  ate deploy unitree-r1         # Deploy to robot
  ate record start -r my-robot  # Start recording telemetry
  ate marketplace search "pick" # Search skill marketplace
  ate robot setup               # Interactive robot setup wizard

For more information, visit: https://kindly.fyi/docs/cli
"""
    )

    subparsers = parser.add_subparsers(dest="command", help="Command to run")

    # Register all standard command parsers from ate/commands/
    register_all_parsers(subparsers)

    # Try to register robot commands (needs cv2, bleak, numpy, PIL, etc.)
    try:
        from ate.robot.commands import register_robot_parser
        register_robot_parser(subparsers)
    except (ImportError, NameError, AttributeError):
        pass  # Robot deps not installed — skip registration

    # Try to register URDF generation commands (needs cv2, etc.)
    try:
        from ate.urdf.commands import register_parser as register_urdf_parser
        register_urdf_parser(subparsers)
    except (ImportError, NameError, AttributeError):
        pass  # URDF deps not installed — skip registration

    # Register additional specialized commands
    _register_specialized_parsers(subparsers)

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    # Handle the command
    _dispatch_command(args)


def _register_specialized_parsers(subparsers):
    """Register specialized commands that aren't in the standard modules."""

    # robot-setup command - Interactive wizard
    robot_setup_parser = subparsers.add_parser(
        "robot-setup",
        help="Interactive wizard to discover robot and generate primitive skills"
    )
    robot_setup_parser.add_argument("-p", "--port", help="Serial port (skip device selection)")
    robot_setup_parser.add_argument("-o", "--output", default="./robot",
                                    help="Output directory for generated files")
    robot_setup_parser.add_argument("--skip-labeling", action="store_true",
                                    help="Skip labeling entirely")
    robot_setup_parser.add_argument("--robot-type",
                                    choices=["quadruped", "quadruped_with_arm", "hexapod",
                                            "6dof_arm", "humanoid_basic", "humanoid",
                                            "humanoid_advanced", "humanoid_full", "custom"],
                                    help="Force robot type for AI-suggested labels")
    robot_setup_parser.add_argument("--non-interactive", action="store_true",
                                    help="Run without user prompts")
    robot_setup_parser.add_argument("--push", action="store_true",
                                    help="Auto-push generated primitives")
    robot_setup_parser.add_argument("--api-url", help="FoodforThought API URL")
    robot_setup_parser.add_argument("--scan-only", action="store_true",
                                    help="Only scan for devices")

    # marketplace command - Skill Marketplace
    marketplace_parser = subparsers.add_parser(
        "marketplace",
        help="Skill Marketplace - discover, install, and publish robot skills",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    marketplace_subparsers = marketplace_parser.add_subparsers(
        dest="marketplace_action", help="Marketplace action"
    )

    # marketplace search
    marketplace_search_parser = marketplace_subparsers.add_parser(
        "search", help="Search for skills in the marketplace"
    )
    marketplace_search_parser.add_argument("query", help="Search query")
    marketplace_search_parser.add_argument("-c", "--category",
        choices=["manipulation", "navigation", "perception", "locomotion",
                 "interaction", "inspection", "assembly", "pick_and_place",
                 "cleaning", "logistics", "other"],
        help="Filter by category")
    marketplace_search_parser.add_argument("-r", "--robot-type", help="Filter by robot type")
    marketplace_search_parser.add_argument("-l", "--license", help="Filter by license")
    marketplace_search_parser.add_argument("-p", "--pricing", choices=["free", "paid"])
    marketplace_search_parser.add_argument("-s", "--sort", default="downloads",
        choices=["downloads", "rating", "recent", "executions", "installs"])
    marketplace_search_parser.add_argument("--limit", type=int, default=20)

    # marketplace show
    marketplace_show_parser = marketplace_subparsers.add_parser(
        "show", help="Show detailed information about a skill"
    )
    marketplace_show_parser.add_argument("slug", help="Skill slug/name")

    # marketplace install
    marketplace_install_parser = marketplace_subparsers.add_parser(
        "install", help="Install a skill from the marketplace"
    )
    marketplace_install_parser.add_argument("skill_name", help="Skill name or slug")
    marketplace_install_parser.add_argument("-v", "--version", help="Specific version")
    marketplace_install_parser.add_argument("-r", "--robot", help="Target robot ID")
    marketplace_install_parser.add_argument("-o", "--output", help="Output directory")

    # marketplace publish
    marketplace_publish_parser = marketplace_subparsers.add_parser(
        "publish", help="Publish a skill to the marketplace"
    )
    marketplace_publish_parser.add_argument("path", help="Path to skill directory")
    marketplace_publish_parser.add_argument("--no-public", action="store_true",
        help="Keep skill private")

    # marketplace report
    marketplace_report_parser = marketplace_subparsers.add_parser(
        "report", help="Report skill compatibility with a robot"
    )
    marketplace_report_parser.add_argument("skill_name", help="Skill name or slug")
    marketplace_report_parser.add_argument("robot", help="Robot ID")
    marketplace_report_parser.add_argument("--works", dest="works", action="store_true")
    marketplace_report_parser.add_argument("--no-works", dest="works", action="store_false")
    marketplace_report_parser.add_argument("-n", "--notes", help="Additional notes")
    marketplace_report_parser.add_argument("-v", "--version", help="Version tested")
    marketplace_report_parser.set_defaults(works=None)

    # marketplace installed
    marketplace_subparsers.add_parser("installed", help="List installed skills")

    # transport command - Unified robot communication
    transport_parser = subparsers.add_parser(
        "transport",
        help="Unified robot communication layer (BLE, USB, WiFi)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        description="""Transport Abstraction Layer for robot communication.

Provides a unified interface for connecting to robots regardless of
physical transport (BLE, USB Serial, WiFi).

The key insight: You shouldn't need to know HOW a robot communicates,
only WHAT you want it to do.

EXAMPLES:
    ate transport discover           # Find all robots (BLE + Serial)
    ate transport connect            # Connect to first found robot
    ate transport connect --ble AA:BB:CC:DD  # Connect via BLE
    ate transport connect --serial /dev/cu.usbmodem  # Connect via USB
    ate transport test               # Test connected robot capabilities
    ate transport demo               # Run interactive demo
"""
    )
    transport_subparsers = transport_parser.add_subparsers(
        dest="transport_action", help="Transport action"
    )

    # transport discover
    transport_discover = transport_subparsers.add_parser(
        "discover", help="Discover robots across all transports"
    )
    transport_discover.add_argument("--timeout", type=float, default=5.0,
                                    help="Scan timeout (default: 5s)")
    transport_discover.add_argument("--ble-only", action="store_true",
                                    help="Only scan BLE")
    transport_discover.add_argument("--serial-only", action="store_true",
                                    help="Only scan serial ports")
    transport_discover.add_argument("--json", action="store_true", dest="json_output",
                                    help="Output as JSON")

    # transport connect
    transport_connect = transport_subparsers.add_parser(
        "connect", help="Connect to a robot and test"
    )
    transport_connect.add_argument("--ble", dest="ble_address",
                                   help="BLE device address")
    transport_connect.add_argument("--serial", dest="serial_port",
                                   help="Serial port path")
    transport_connect.add_argument("--name", help="Robot name filter")

    # transport capabilities
    transport_caps = transport_subparsers.add_parser(
        "capabilities", help="Probe and display robot capabilities"
    )
    transport_caps.add_argument("--ble", dest="ble_address",
                                help="BLE device address")
    transport_caps.add_argument("--serial", dest="serial_port",
                                help="Serial port path")

    # transport test
    transport_test = transport_subparsers.add_parser(
        "test", help="Run transport layer tests"
    )
    transport_test.add_argument("--ble", dest="ble_address",
                                help="BLE device address")
    transport_test.add_argument("--serial", dest="serial_port",
                                help="Serial port path")
    transport_test.add_argument("--command",
                                help="Send specific command (e.g., 'CMD|6|$')")

    # transport demo
    transport_demo = transport_subparsers.add_parser(
        "demo", help="Interactive demo of transport capabilities"
    )
    transport_demo.add_argument("--ble", dest="ble_address",
                                help="BLE device address")
    transport_demo.add_argument("--serial", dest="serial_port",
                                help="Serial port path")
    transport_demo.add_argument("--action",
                                choices=["walk", "sensors", "all"],
                                default="all",
                                help="Demo to run (default: all)")

    # ble command - BLE-specific operations
    ble_parser = subparsers.add_parser(
        "ble",
        help="Bluetooth Low Energy operations (scan, enumerate, analyze)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        description="""BLE operations for robot discovery and protocol analysis.

Provides tools to discover BLE devices, enumerate their GATT services
and characteristics, and probe command protocols.

EXAMPLES:
    ate ble scan                  # Scan for nearby BLE devices
    ate ble enumerate ADDR        # Full enumeration of device
    ate ble enumerate mechdog_00  # Enumerate by device name
    ate ble probe ADDR CMD        # Test a specific command
"""
    )
    ble_subparsers = ble_parser.add_subparsers(
        dest="ble_action", help="BLE action"
    )

    # ble scan
    ble_scan = ble_subparsers.add_parser(
        "scan", help="Scan for nearby BLE devices"
    )
    ble_scan.add_argument("--timeout", type=float, default=5.0,
                          help="Scan timeout in seconds (default: 5)")
    ble_scan.add_argument("--filter", dest="name_filter",
                          help="Filter devices by name (case-insensitive)")
    ble_scan.add_argument("--json", action="store_true", dest="json_output",
                          help="Output as JSON")

    # ble enumerate
    ble_enumerate = ble_subparsers.add_parser(
        "enumerate", help="Comprehensive BLE device enumeration"
    )
    ble_enumerate.add_argument("address",
                               help="Device address (MAC/UUID) or name")
    ble_enumerate.add_argument("-o", "--output",
                               help="Save JSON report to file")
    ble_enumerate.add_argument("--timeout", type=float, default=15.0,
                               help="Connection timeout (default: 15s)")
    ble_enumerate.add_argument("-q", "--quiet", action="store_true",
                               help="Minimal output")

    # ble probe
    ble_probe = ble_subparsers.add_parser(
        "probe", help="Probe a specific command"
    )
    ble_probe.add_argument("address",
                           help="Device address or name")
    ble_probe.add_argument("ble_command",
                           help="Command to send (e.g., 'CMD|6|$')")
    ble_probe.add_argument("--hex", action="store_true",
                           help="Interpret command as hex string")
    ble_probe.add_argument("--repeat", type=int, default=1,
                           help="Number of times to send command")
    ble_probe.add_argument("--delay", type=float, default=0.5,
                           help="Delay between commands (default: 0.5s)")


def _dispatch_command(args):
    """Dispatch command to the appropriate handler."""

    # Handle robot command (needs cv2, bleak, pyserial)
    if args.command == "robot":
        try:
            from ate.robot.commands import handle_robot_command
            handle_robot_command(args)
        except (ImportError, NameError, AttributeError):
            print("Error: Robot commands require additional dependencies. "
                  "Install with: pip install opencv-python bleak pyserial",
                  file=sys.stderr)
            sys.exit(1)
        return

    # Handle urdf command (needs cv2, etc.)
    if args.command == "urdf":
        try:
            from ate.urdf.commands import handle as handle_urdf_command
            client = ATEClient()
            handle_urdf_command(client, args)
        except (ImportError, NameError, AttributeError):
            print("Error: URDF commands require additional dependencies. "
                  "Install with: pip install opencv-python",
                  file=sys.stderr)
            sys.exit(1)
        return

    # Handle robot-setup command
    if args.command == "robot-setup":
        try:
            _handle_robot_setup(args)
        except (ImportError, NameError, AttributeError):
            print("Error: Robot-setup commands require additional dependencies. "
                  "Install with: pip install opencv-python bleak pyserial",
                  file=sys.stderr)
            sys.exit(1)
        return

    # Handle marketplace command
    if args.command == "marketplace":
        _handle_marketplace(args)
        return

    # Handle transport command (needs bleak, pyserial)
    if args.command == "transport":
        try:
            _handle_transport(args)
        except (ImportError, NameError, AttributeError):
            print("Error: Transport commands require additional dependencies. "
                  "Install with: pip install bleak pyserial",
                  file=sys.stderr)
            sys.exit(1)
        return

    # Handle BLE command (needs bleak)
    if args.command == "ble":
        try:
            _handle_ble(args)
        except (ImportError, NameError, AttributeError):
            print("Error: BLE commands require additional dependencies. "
                  "Install with: pip install bleak",
                  file=sys.stderr)
            sys.exit(1)
        return

    # Handle all other commands through the central dispatcher
    client = ATEClient()

    if not handle_command(args.command, client, args):
        print(f"Unknown command: {args.command}", file=sys.stderr)
        sys.exit(1)


def _handle_robot_setup(args):
    """Handle the robot-setup wizard command."""
    from ate.robot_setup import run_wizard

    if args.scan_only:
        # Just scan for devices
        try:
            import serial.tools.list_ports
            print("\nScanning for serial ports...\n")
            ports = list(serial.tools.list_ports.comports())

            if not ports:
                print("No serial ports found.")
            else:
                print(f"Found {len(ports)} port(s):\n")
                for port in ports:
                    print(f"  Port: {port.device}")
                    if port.description:
                        print(f"    Description: {port.description}")
                    if port.manufacturer:
                        print(f"    Manufacturer: {port.manufacturer}")
                    if port.vid and port.pid:
                        print(f"    VID:PID: {port.vid:04x}:{port.pid:04x}")
                    if port.serial_number:
                        print(f"    Serial: {port.serial_number}")
                    print()
        except (ImportError, NameError, AttributeError):
            print("Error: pyserial not installed. Run: pip install pyserial")
            sys.exit(1)
    else:
        # Run full wizard
        success = run_wizard(
            port=args.port,
            output=args.output,
            skip_labeling=args.skip_labeling,
            robot_type=getattr(args, 'robot_type', None),
            non_interactive=getattr(args, 'non_interactive', False),
            push=getattr(args, 'push', False),
            api_url=getattr(args, 'api_url', None)
        )
        sys.exit(0 if success else 1)


def _handle_marketplace(args):
    """Handle marketplace commands."""
    from ate.marketplace import (
        search_skills, show_skill, install_skill,
        publish_skill, report_compatibility, list_installed
    )

    if args.marketplace_action == "search":
        search_skills(
            query=args.query,
            category=args.category,
            robot_type=getattr(args, 'robot_type', None),
            license_type=args.license,
            pricing=args.pricing,
            sort=args.sort,
            limit=args.limit,
        )
    elif args.marketplace_action == "show":
        show_skill(args.slug)
    elif args.marketplace_action == "install":
        install_skill(
            skill_name=args.skill_name,
            version=args.version,
            robot=args.robot,
            output_dir=args.output,
        )
    elif args.marketplace_action == "publish":
        publish_skill(
            path=args.path,
            public=not args.no_public,
        )
    elif args.marketplace_action == "report":
        if args.works is None:
            print("Error: Must specify --works or --no-works", file=sys.stderr)
            sys.exit(1)
        report_compatibility(
            skill_name=args.skill_name,
            robot=args.robot,
            works=args.works,
            notes=args.notes,
            version=args.version,
        )
    elif args.marketplace_action == "installed":
        list_installed()
    else:
        print("Usage: ate marketplace {search|show|install|publish|report|installed}")
        sys.exit(1)


def _handle_transport(args):
    """Handle transport layer commands."""
    import asyncio
    import json as json_module

    if args.transport_action == "discover":
        _transport_discover(args)
    elif args.transport_action == "connect":
        _transport_connect(args)
    elif args.transport_action == "capabilities":
        _transport_capabilities(args)
    elif args.transport_action == "test":
        _transport_test(args)
    elif args.transport_action == "demo":
        _transport_demo(args)
    else:
        print("Usage: ate transport {discover|connect|capabilities|test|demo}")
        sys.exit(1)


def _transport_discover(args):
    """Discover robots across transports."""
    import asyncio
    import json as json_module

    async def run():
        from ate.transports import BLETransport, SerialTransport

        print("=" * 60)
        print("TRANSPORT DISCOVERY")
        print("=" * 60)

        all_devices = []

        # BLE discovery
        if not args.serial_only:
            print("\nScanning BLE...")
            try:
                ble_devices = await BLETransport.discover(timeout=args.timeout)
                for d in ble_devices:
                    print(f"  [BLE] {d.name or 'Unknown'}")
                    print(f"        Address: {d.address}")
                    if d.rssi:
                        print(f"        RSSI: {d.rssi} dBm")
                    all_devices.append(d)
            except Exception as e:
                print(f"  BLE scan error: {e}")

        # Serial discovery
        if not args.ble_only:
            print("\nScanning Serial ports...")
            try:
                serial_devices = await SerialTransport.discover(timeout=args.timeout)
                for d in serial_devices:
                    print(f"  [Serial] {d.name or 'Unknown'}")
                    print(f"           Port: {d.address}")
                    if d.metadata:
                        vid = d.metadata.get('vid')
                        pid = d.metadata.get('pid')
                        if vid and pid:
                            print(f"           VID:PID: {vid:04x}:{pid:04x}")
                    all_devices.append(d)
            except Exception as e:
                print(f"  Serial scan error: {e}")

        print(f"\nFound {len(all_devices)} device(s)")

        if args.json_output:
            output = [{
                "type": d.transport_type,
                "address": d.address,
                "name": d.name,
                "rssi": d.rssi,
                "metadata": d.metadata,
            } for d in all_devices]
            print("\nJSON Output:")
            print(json_module.dumps(output, indent=2))

    asyncio.run(run())


def _transport_connect(args):
    """Connect to a robot and verify."""
    import asyncio

    async def run():
        from ate.transports import HybridTransport

        robot = HybridTransport()
        print("=" * 60)
        print("TRANSPORT CONNECTION TEST")
        print("=" * 60)

        # Connect BLE if specified
        if args.ble_address:
            print(f"\nConnecting to BLE: {args.ble_address}")
            if await robot.connect_ble(args.ble_address, name=args.name):
                print("  ✓ BLE connected!")
            else:
                print("  ✗ BLE connection failed")

        # Connect Serial if specified
        if args.serial_port:
            print(f"\nConnecting to Serial: {args.serial_port}")
            if await robot.connect_serial(args.serial_port):
                print("  ✓ Serial connected!")
            else:
                print("  ✗ Serial connection failed")

        # Auto-discover if neither specified
        if not args.ble_address and not args.serial_port:
            print("\nAuto-discovering robots...")
            connections = await HybridTransport.discover(timeout=5.0)

            for conn in connections:
                if args.name and conn.name and args.name.lower() not in conn.name.lower():
                    continue

                print(f"  Found: [{conn.transport_type}] {conn.name} @ {conn.address}")

                if conn.transport_type == "ble":
                    if await robot.connect_ble(conn.address):
                        print("  ✓ Connected!")
                        break
                elif conn.transport_type == "serial":
                    if await robot.connect_serial(conn.address):
                        print("  ✓ Connected!")
                        break

        # Test connection
        if robot.is_connected:
            print("\n--- Connection Test ---")
            battery = await robot.get_battery()
            if battery:
                print(f"  Battery: {battery}V")
            else:
                print("  Battery: Unable to read")

            # Probe capabilities
            print("\n--- Probing Capabilities ---")
            caps = await robot.probe_capabilities()
            for cap in sorted(caps, key=lambda c: c.name):
                print(f"  ✓ {cap.name}")

        await robot.disconnect()
        print("\nDone.")

    asyncio.run(run())


def _transport_capabilities(args):
    """Probe and display capabilities."""
    import asyncio
    from ate.transports import TransportCapability

    async def run():
        from ate.transports import HybridTransport

        robot = HybridTransport()
        print("=" * 60)
        print("CAPABILITY PROBE")
        print("=" * 60)

        # Connect
        if args.ble_address:
            await robot.connect_ble(args.ble_address)
        if args.serial_port:
            await robot.connect_serial(args.serial_port)

        if not robot.is_connected:
            print("\nNo robot connected. Use --ble or --serial to specify.")
            return

        # Probe
        print("\nProbing capabilities...")
        caps = await robot.probe_capabilities()

        # Group by category
        categories = {
            "Locomotion": [TransportCapability.WALK, TransportCapability.TURN,
                          TransportCapability.STAND, TransportCapability.SIT,
                          TransportCapability.POSTURE],
            "Manipulation": [TransportCapability.ARM_POSITION,
                            TransportCapability.GRIPPER,
                            TransportCapability.RAW_SERVO],
            "Sensors": [TransportCapability.ULTRASONIC, TransportCapability.IMU,
                       TransportCapability.BATTERY],
            "Visual": [TransportCapability.RGB_LED],
            "Other": [TransportCapability.ACTION_GROUPS,
                     TransportCapability.BIDIRECTIONAL,
                     TransportCapability.STREAMING],
        }

        for cat_name, cat_caps in categories.items():
            matched = [c for c in cat_caps if c in caps]
            if matched:
                print(f"\n{cat_name}:")
                for cap in matched:
                    print(f"  ✓ {cap.name}")

        # Transport breakdown
        print("\n--- By Transport ---")
        if robot.ble and robot.ble.is_connected:
            ble_caps = robot.ble.capabilities
            print(f"BLE: {', '.join(c.name for c in ble_caps) or 'none'}")
        if robot.serial_transport and robot.serial_transport.is_connected:
            serial_caps = robot.serial_transport.capabilities
            print(f"Serial: {', '.join(c.name for c in serial_caps) or 'none'}")

        await robot.disconnect()

    asyncio.run(run())


def _transport_test(args):
    """Run transport tests."""
    import asyncio

    async def run():
        from ate.transports import HybridTransport

        robot = HybridTransport()
        print("=" * 60)
        print("TRANSPORT TEST")
        print("=" * 60)

        # Connect
        if args.ble_address:
            print(f"\nConnecting BLE: {args.ble_address}")
            await robot.connect_ble(args.ble_address)
        if args.serial_port:
            print(f"\nConnecting Serial: {args.serial_port}")
            await robot.connect_serial(args.serial_port)

        if not robot.is_connected:
            print("\nNo robot connected. Use --ble or --serial.")
            return

        # Run command if specified
        if args.command:
            print(f"\nSending: {args.command}")
            result = await robot.send_command(args.command)
            print(f"  Success: {result.success}")
            if result.response:
                print(f"  Response: {result.response}")
            if result.error:
                print(f"  Error: {result.error}")
            if result.latency_ms:
                print(f"  Latency: {result.latency_ms:.1f}ms")
        else:
            # Default test sequence
            print("\n--- Running Test Sequence ---")

            # Battery
            print("\n1. Battery query...")
            battery = await robot.get_battery()
            if battery:
                print(f"   ✓ Battery: {battery}V")
            else:
                print("   ✗ Battery: No response")

            # Ultrasonic
            print("\n2. Ultrasonic query...")
            distance = await robot.get_ultrasonic()
            if distance:
                print(f"   ✓ Distance: {distance}mm ({distance/10:.1f}cm)")
            else:
                print("   ✗ Ultrasonic: No response")

            # Stand command
            print("\n3. Stand command...")
            result = await robot.stand()
            print(f"   {'✓' if result.success else '✗'} Stand: {result.error or 'OK'}")

        await robot.disconnect()
        print("\nDone.")

    asyncio.run(run())


def _transport_demo(args):
    """Run interactive demo."""
    import asyncio
    import time

    async def run():
        from ate.transports import HybridTransport

        robot = HybridTransport()
        print("=" * 60)
        print("TRANSPORT LAYER DEMO")
        print("=" * 60)
        print("\nThis demonstrates the unified transport abstraction.")
        print("Commands automatically route to the right transport.")

        # Connect
        if args.ble_address:
            await robot.connect_ble(args.ble_address)
        if args.serial_port:
            await robot.connect_serial(args.serial_port)

        if not robot.is_connected:
            # Auto-discover
            print("\nDiscovering robots...")
            connections = await HybridTransport.discover(timeout=5.0)
            for conn in connections:
                if conn.transport_type == "ble":
                    if await robot.connect_ble(conn.address):
                        print(f"  Connected to {conn.name}")
                        break

        if not robot.is_connected:
            print("\nNo robot found. Please connect a robot.")
            return

        # Show capabilities
        print("\n--- Detected Capabilities ---")
        caps = await robot.probe_capabilities()
        for cap in sorted(caps, key=lambda c: c.name):
            print(f"  ✓ {cap.name}")

        # Run demos based on action
        if args.action in ("all", "sensors"):
            print("\n--- Sensor Demo ---")
            print("Reading sensors (press Ctrl+C to stop)...")
            try:
                for _ in range(5):
                    battery = await robot.get_battery()
                    ultrasonic = await robot.get_ultrasonic()
                    print(f"  Battery: {battery or '?'}V  |  Distance: {ultrasonic or '?'}mm")
                    await asyncio.sleep(1)
            except KeyboardInterrupt:
                pass

        if args.action in ("all", "walk"):
            print("\n--- Walk Demo ---")
            print("Walking forward for 2 seconds...")

            await robot.stand()
            await asyncio.sleep(0.5)

            # Walk forward
            for _ in range(4):
                await robot.walk_forward(80)
                await asyncio.sleep(0.5)

            await robot.stop()
            await robot.stand()
            print("Walk complete!")

        await robot.disconnect()
        print("\n✓ Demo complete!")

    asyncio.run(run())


def _handle_ble(args):
    """Handle BLE commands."""
    import asyncio

    if args.ble_action == "scan":
        _ble_scan(args)
    elif args.ble_action == "enumerate":
        _ble_enumerate(args)
    elif args.ble_action == "probe":
        _ble_probe(args)
    else:
        print("Usage: ate ble {scan|enumerate|probe}")
        sys.exit(1)


def _ble_scan(args):
    """Scan for BLE devices."""
    import asyncio
    import json as json_module

    async def run():
        from bleak import BleakScanner

        print("=" * 60)
        print("BLE DEVICE SCAN")
        print("=" * 60)
        print(f"\nScanning for {args.timeout} seconds...")

        devices = await BleakScanner.discover(timeout=args.timeout)

        # Filter if specified
        if args.name_filter:
            devices = [d for d in devices if d.name and
                      args.name_filter.lower() in d.name.lower()]

        # Sort by RSSI (strongest first) - handle different bleak versions
        def get_rssi(d):
            if hasattr(d, 'rssi'):
                return d.rssi or -100
            if hasattr(d, 'advertisement_data') and d.advertisement_data:
                return d.advertisement_data.rssi or -100
            return -100

        devices.sort(key=get_rssi, reverse=True)

        if args.json_output:
            output = [{
                "name": d.name,
                "address": d.address,
                "rssi": get_rssi(d),
            } for d in devices]
            print(json_module.dumps(output, indent=2))
        else:
            print(f"\nFound {len(devices)} device(s):\n")
            for d in devices:
                rssi = get_rssi(d)
                rssi_bar = "█" * max(0, (rssi + 100) // 5)
                print(f"  {d.name or '(unknown)':30}  {d.address}")
                print(f"    RSSI: {rssi:4} dBm  [{rssi_bar:20}]")
                print()

    asyncio.run(run())


def _ble_enumerate(args):
    """Comprehensive BLE enumeration."""
    import asyncio
    from pathlib import Path

    async def run():
        from ate.robot.ble_enumerate import enumerate_ble_device

        output_path = Path(args.output) if args.output else None
        verbose = not args.quiet

        try:
            report = await enumerate_ble_device(
                address=args.address,
                output_path=output_path,
                verbose=verbose,
            )

            if args.quiet:
                # Minimal summary
                print(f"Device: {report.device_name}")
                print(f"Address: {report.device_address}")
                print(f"Services: {len(report.services)}")
                print(f"Working commands: {len(report.working_commands)}")
                protocols = [p.name for p in report.protocols if p.working]
                if protocols:
                    print(f"Protocols: {', '.join(protocols)}")

        except Exception as e:
            print(f"Error: {e}", file=sys.stderr)
            sys.exit(1)

    asyncio.run(run())


def _ble_probe(args):
    """Probe a specific BLE command."""
    import asyncio

    async def run():
        from bleak import BleakClient, BleakScanner

        print("=" * 60)
        print("BLE COMMAND PROBE")
        print("=" * 60)

        # Find device
        print(f"\nSearching for: {args.address}")
        devices = await BleakScanner.discover(timeout=5.0)

        device = None
        for d in devices:
            if d.address == args.address or (d.name and args.address.lower() in d.name.lower()):
                device = d
                break

        if not device:
            print(f"Device not found: {args.address}")
            sys.exit(1)

        print(f"Found: {device.name} ({device.address})")

        # Parse command
        if args.hex:
            cmd = bytes.fromhex(args.ble_command)
        else:
            cmd = args.ble_command.encode()

        print(f"Command: {cmd}")

        async with BleakClient(device, timeout=15.0) as client:
            # Find write and notify characteristics
            write_char = None
            notify_char = None

            for service in client.services:
                for char in service.characteristics:
                    if "write" in char.properties:
                        write_char = char.uuid
                    if "notify" in char.properties:
                        notify_char = char.uuid

            if not write_char:
                print("Error: No writable characteristic found")
                sys.exit(1)

            print(f"\nWrite characteristic: {write_char}")
            print(f"Notify characteristic: {notify_char or '(none)'}")

            responses = []

            def handler(sender, data):
                responses.append(data)
                try:
                    print(f"  << {data.decode('ascii', errors='replace')}")
                except:
                    print(f"  << {data.hex()}")

            # Start notifications
            if notify_char:
                await client.start_notify(notify_char, handler)
                await asyncio.sleep(0.5)

            # Send command(s)
            print(f"\nSending command {args.repeat} time(s)...")
            for i in range(args.repeat):
                responses.clear()
                print(f"\n  >> {cmd}")
                await client.write_gatt_char(write_char, cmd)
                await asyncio.sleep(args.delay)

                if not responses:
                    print("     (no response)")

            if notify_char:
                await client.stop_notify(notify_char)

        print("\nDone!")

    asyncio.run(run())


if __name__ == "__main__":
    main()
