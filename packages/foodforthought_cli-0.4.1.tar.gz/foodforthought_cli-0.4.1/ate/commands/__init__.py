"""
FoodforThought CLI Commands Registry.

This module provides centralized registration and dispatch for all CLI commands.
"""


def register_all_parsers(subparsers):
    """Register all command parsers with the main argparse parser."""
    from . import auth
    from . import repo
    from . import simulation
    from . import skills
    from . import recording
    from . import parts
    from . import deps
    from . import protocol
    from . import primitive
    from . import skill
    from . import bridge
    from . import generate
    from . import workflow
    from . import team
    from . import data
    from . import memory

    # Register each module's parsers
    auth.register_parser(subparsers)
    repo.register_parser(subparsers)
    simulation.register_parser(subparsers)
    skills.register_parser(subparsers)
    recording.register_parser(subparsers)
    parts.register_parser(subparsers)
    deps.register_parser(subparsers)
    protocol.register_parser(subparsers)
    primitive.register_parser(subparsers)
    skill.register_parser(subparsers)
    bridge.register_parser(subparsers)
    generate.register_parser(subparsers)
    workflow.register_parser(subparsers)
    team.register_parser(subparsers)
    data.register_parser(subparsers)
    memory.register_parser(subparsers)


# Command to module mapping
_COMMAND_HANDLERS = {
    # Auth commands
    "login": "auth",
    "logout": "auth",
    "whoami": "auth",
    "device-login": "auth",
    # Repo commands
    "init": "repo",
    "clone": "repo",
    "commit": "repo",
    "push": "repo",
    # Simulation commands
    "deploy": "simulation",
    "test": "simulation",
    "benchmark": "simulation",
    # Skills commands
    "adapt": "skills",
    "validate": "skills",
    "stream": "skills",
    "pull": "skills",
    "upload": "skills",
    "check-transfer": "skills",
    "labeling-status": "skills",
    # Recording commands
    "record": "recording",
    # Parts commands
    "parts": "parts",
    # Deps commands
    "deps": "deps",
    # Protocol commands
    "protocol": "protocol",
    # Primitive commands
    "primitive": "primitive",
    # Skill commands
    "skill": "skill",
    # Bridge commands
    "bridge": "bridge",
    # Generate commands
    "generate": "generate",
    "compile": "generate",
    "test-skill": "generate",
    "publish-skill": "generate",
    "check-compatibility": "generate",
    "publish-protocol": "generate",
    # Workflow commands
    "workflow": "workflow",
    # Team commands
    "team": "team",
    # Data commands
    "data": "data",
    # Memory commands
    "memory": "memory",
}


def handle_command(command: str, client, args):
    """
    Dispatch command to the appropriate handler.

    Args:
        command: The command name from args.command
        client: The ATEClient instance
        args: The parsed argparse namespace
    """
    module_name = _COMMAND_HANDLERS.get(command)

    if module_name is None:
        return False

    # Import the specific module and call its handle function
    if module_name == "auth":
        from . import auth
        auth.handle(client, args)
    elif module_name == "repo":
        from . import repo
        repo.handle(client, args)
    elif module_name == "simulation":
        from . import simulation
        simulation.handle(client, args)
    elif module_name == "skills":
        from . import skills
        skills.handle(client, args)
    elif module_name == "recording":
        from . import recording
        recording.handle(client, args)
    elif module_name == "parts":
        from . import parts
        parts.handle(client, args)
    elif module_name == "deps":
        from . import deps
        deps.handle(client, args)
    elif module_name == "protocol":
        from . import protocol
        protocol.handle(client, args)
    elif module_name == "primitive":
        from . import primitive
        primitive.handle(client, args)
    elif module_name == "skill":
        from . import skill
        skill.handle(client, args)
    elif module_name == "bridge":
        from . import bridge
        bridge.handle(client, args)
    elif module_name == "generate":
        from . import generate
        generate.handle(client, args)
    elif module_name == "workflow":
        from . import workflow
        workflow.handle(client, args)
    elif module_name == "team":
        from . import team
        team.handle(client, args)
    elif module_name == "data":
        from . import data
        data.handle(client, args)
    elif module_name == "memory":
        from . import memory
        memory.handle(client, args)
    else:
        return False

    return True
