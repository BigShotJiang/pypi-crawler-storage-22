"""
Bridge commands for FoodforThought CLI.

Commands:
- ate bridge connect  - Connect to robot interactively
- ate bridge send     - Send single command
- ate bridge record   - Record session for primitive creation
- ate bridge replay   - Replay a recorded session
- ate bridge serve    - Start WebSocket server for Artifex integration
"""

import json
import sys
import time
from pathlib import Path
from typing import Optional


def bridge_connect(client, port: str, transport: str,
                   baud_rate: int, protocol_id: Optional[str]) -> None:
    """Connect to a robot via serial or BLE and start interactive session."""
    print(f"\n{'=' * 60}")
    print("FoodForThought Bridge - Robot Communication Interface")
    print(f"{'=' * 60}\n")

    if transport == "serial":
        try:
            import serial
        except ImportError:
            print("Error: pyserial is required. Install with: pip install pyserial", file=sys.stderr)
            sys.exit(1)

        print(f"Connecting to {port} at {baud_rate} baud...")
        try:
            ser = serial.Serial(port, baud_rate, timeout=1)
            print(f"✓ Connected to {port}")
            print(f"\nInteractive mode. Type commands to send to robot.")
            print("Special commands:")
            print("  .quit     - Exit bridge")
            print("  .record   - Start recording for primitive creation")
            print("  .stop     - Stop recording")
            print("  .save     - Save recorded session")
            print("  .protocol - Show loaded protocol info")
            print("-" * 60 + "\n")

            recording = False
            recorded_commands = []

            while True:
                try:
                    cmd = input("bridge> ").strip()
                    if not cmd:
                        continue

                    if cmd == ".quit":
                        break
                    elif cmd == ".record":
                        recording = True
                        recorded_commands = []
                        print("Recording started...")
                        continue
                    elif cmd == ".stop":
                        recording = False
                        print(f"Recording stopped. {len(recorded_commands)} commands recorded.")
                        continue
                    elif cmd == ".save":
                        if recorded_commands:
                            filename = f"session_{int(time.time())}.json"
                            with open(filename, "w") as f:
                                json.dump({
                                    "port": port,
                                    "baud_rate": baud_rate,
                                    "commands": recorded_commands
                                }, f, indent=2)
                            print(f"Session saved to {filename}")
                        else:
                            print("No commands recorded yet.")
                        continue
                    elif cmd == ".protocol":
                        if protocol_id:
                            from . import protocol
                            protocol.protocol_get(client, protocol_id)
                        else:
                            print("No protocol loaded. Use --protocol flag to specify.")
                        continue

                    # Send command to robot
                    ser.write((cmd + "\n").encode())
                    if recording:
                        recorded_commands.append({
                            "command": cmd,
                            "timestamp": time.time()
                        })

                    # Read response
                    time.sleep(0.1)
                    response = ser.read_all().decode("utf-8", errors="replace").strip()
                    if response:
                        print(f"< {response}")
                        if recording:
                            recorded_commands[-1]["response"] = response

                except KeyboardInterrupt:
                    break

            ser.close()
            print("\n✓ Disconnected")

        except Exception as e:
            print(f"Error connecting to {port}: {e}", file=sys.stderr)
            sys.exit(1)

    elif transport == "ble":
        print("BLE bridge requires async operation. Starting BLE session...")
        _bridge_ble_connect(port)


def _bridge_ble_connect(address: str) -> None:
    """Connect to robot via BLE (requires bleak)."""
    try:
        import asyncio
        from bleak import BleakClient
    except ImportError:
        print("Error: bleak is required for BLE. Install with: pip install bleak", file=sys.stderr)
        sys.exit(1)

    async def ble_session():
        print(f"Connecting to BLE device {address}...")
        try:
            async with BleakClient(address) as client:
                print(f"✓ Connected to {address}")

                print("\nAvailable services:")
                for service in client.services:
                    print(f"  {service.uuid}: {service.description or 'Unknown'}")
                    for char in service.characteristics:
                        props = ", ".join(char.properties)
                        print(f"    └─ {char.uuid} [{props}]")

                print("\nInteractive mode. Commands:")
                print("  read <uuid>         - Read characteristic")
                print("  write <uuid> <hex>  - Write to characteristic")
                print("  notify <uuid>       - Subscribe to notifications")
                print("  .quit               - Exit")
                print("-" * 60 + "\n")

                while True:
                    try:
                        cmd = input("ble> ").strip()
                        if not cmd:
                            continue

                        if cmd == ".quit":
                            break

                        parts = cmd.split()
                        if parts[0] == "read" and len(parts) >= 2:
                            uuid = parts[1]
                            try:
                                data = await client.read_gatt_char(uuid)
                                print(f"< {data.hex()} ({data})")
                            except Exception as e:
                                print(f"Error reading: {e}")

                        elif parts[0] == "write" and len(parts) >= 3:
                            uuid = parts[1]
                            hex_data = parts[2]
                            try:
                                data = bytes.fromhex(hex_data)
                                await client.write_gatt_char(uuid, data)
                                print(f"✓ Written {hex_data}")
                            except Exception as e:
                                print(f"Error writing: {e}")

                        elif parts[0] == "notify" and len(parts) >= 2:
                            uuid = parts[1]

                            def callback(sender, data):
                                print(f"[{sender}] {data.hex()}")

                            try:
                                await client.start_notify(uuid, callback)
                                print(f"✓ Subscribed to {uuid}")
                            except Exception as e:
                                print(f"Error subscribing: {e}")

                        else:
                            print("Unknown command. Use read/write/notify or .quit")

                    except KeyboardInterrupt:
                        break

                print("\n✓ Disconnected")

        except Exception as e:
            print(f"Error connecting to BLE device: {e}", file=sys.stderr)
            sys.exit(1)

    asyncio.run(ble_session())


def bridge_send(client, port: str, command: str, transport: str,
                baud_rate: int, wait: float) -> None:
    """Send a single command to robot and print response."""
    if transport == "serial":
        try:
            import serial
        except ImportError:
            print("Error: pyserial is required. Install with: pip install pyserial", file=sys.stderr)
            sys.exit(1)

        try:
            ser = serial.Serial(port, baud_rate, timeout=1)
            ser.write((command + "\n").encode())
            time.sleep(wait)
            response = ser.read_all().decode("utf-8", errors="replace").strip()
            if response:
                print(response)
            ser.close()
        except Exception as e:
            print(f"Error: {e}", file=sys.stderr)
            sys.exit(1)
    else:
        print("BLE send not yet implemented. Use bridge connect for BLE.", file=sys.stderr)


def bridge_record(client, port: str, output: str, transport: str,
                  baud_rate: int, primitive_name: Optional[str]) -> None:
    """Record a command session for creating a primitive skill."""
    print(f"\n{'=' * 60}")
    print("FoodForThought Bridge - Recording Mode")
    print(f"{'=' * 60}\n")

    if transport != "serial":
        print("Recording currently only supports serial connections", file=sys.stderr)
        sys.exit(1)

    try:
        import serial
    except ImportError:
        print("Error: pyserial is required. Install with: pip install pyserial", file=sys.stderr)
        sys.exit(1)

    print(f"Connecting to {port} at {baud_rate} baud...")
    try:
        ser = serial.Serial(port, baud_rate, timeout=1)
        print(f"✓ Connected and recording to {output}")
        print(f"\nType commands to send. Ctrl+C to stop and save.\n")

        recorded = {
            "name": primitive_name or f"recorded_skill_{int(time.time())}",
            "port": port,
            "baud_rate": baud_rate,
            "start_time": time.time(),
            "commands": []
        }

        while True:
            try:
                cmd = input(f"[REC] bridge> ").strip()
                if not cmd:
                    continue

                timestamp = time.time()
                ser.write((cmd + "\n").encode())
                time.sleep(0.1)
                response = ser.read_all().decode("utf-8", errors="replace").strip()

                entry = {
                    "command": cmd,
                    "timestamp": timestamp - recorded["start_time"],
                    "response": response
                }
                recorded["commands"].append(entry)

                if response:
                    print(f"< {response}")

            except KeyboardInterrupt:
                break

        ser.close()
        recorded["end_time"] = time.time()
        recorded["duration"] = recorded["end_time"] - recorded["start_time"]

        with open(output, "w") as f:
            json.dump(recorded, f, indent=2)

        print(f"\n✓ Recorded {len(recorded['commands'])} commands")
        print(f"✓ Saved to {output}")
        print(f"\nTo create a primitive from this recording:")
        print(f"  ate primitive init --from-recording {output}")

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def bridge_replay(client, recording_file: str, port: str, transport: str,
                  baud_rate: int, speed: float) -> None:
    """Replay a recorded session."""
    if not Path(recording_file).exists():
        print(f"Error: Recording file not found: {recording_file}", file=sys.stderr)
        sys.exit(1)

    with open(recording_file) as f:
        recording = json.load(f)

    if transport != "serial":
        print("Replay currently only supports serial connections", file=sys.stderr)
        sys.exit(1)

    try:
        import serial
    except ImportError:
        print("Error: pyserial is required. Install with: pip install pyserial", file=sys.stderr)
        sys.exit(1)

    print(f"\n{'=' * 60}")
    print(f"Replaying: {recording.get('name', recording_file)}")
    print(f"Commands: {len(recording.get('commands', []))}")
    print(f"Speed: {speed}x")
    print(f"{'=' * 60}\n")

    try:
        ser = serial.Serial(port, baud_rate, timeout=1)
        commands = recording.get("commands", [])

        prev_timestamp = 0
        for i, entry in enumerate(commands):
            timestamp = entry.get("timestamp", 0)
            delay = (timestamp - prev_timestamp) / speed
            if delay > 0 and i > 0:
                time.sleep(delay)
            prev_timestamp = timestamp

            cmd = entry.get("command", "")
            print(f"[{i + 1}/{len(commands)}] > {cmd}")
            ser.write((cmd + "\n").encode())

            time.sleep(0.1)
            response = ser.read_all().decode("utf-8", errors="replace").strip()
            if response:
                print(f"            < {response}")

        ser.close()
        print(f"\n✓ Replay complete")

    except Exception as e:
        print(f"Error during replay: {e}", file=sys.stderr)
        sys.exit(1)


def bridge_serve(port: int, verbose: bool) -> None:
    """Start WebSocket server for Artifex Desktop integration."""
    from ate.bridge_server import run_bridge_server
    run_bridge_server(port=port, verbose=verbose)


def register_parser(subparsers):
    """Register bridge commands with argparse."""
    import argparse

    bridge_parser = subparsers.add_parser("bridge", help="Interactive robot communication bridge")
    bridge_subparsers = bridge_parser.add_subparsers(dest="bridge_action", help="Bridge action")

    # bridge connect
    bridge_connect_parser = bridge_subparsers.add_parser("connect",
                                                          help="Connect to robot interactively")
    bridge_connect_parser.add_argument("port", help="Serial port or BLE address")
    bridge_connect_parser.add_argument("-t", "--transport", default="serial",
                                       choices=["serial", "ble"],
                                       help="Transport type (default: serial)")
    bridge_connect_parser.add_argument("-b", "--baud", type=int, default=115200,
                                       help="Baud rate for serial (default: 115200)")
    bridge_connect_parser.add_argument("-p", "--protocol", help="Protocol ID for command hints")

    # bridge send
    bridge_send_parser = bridge_subparsers.add_parser("send", help="Send single command")
    bridge_send_parser.add_argument("port", help="Serial port or BLE address")
    bridge_send_parser.add_argument("command", help="Command to send")
    bridge_send_parser.add_argument("-t", "--transport", default="serial",
                                    choices=["serial", "ble"],
                                    help="Transport type (default: serial)")
    bridge_send_parser.add_argument("-b", "--baud", type=int, default=115200,
                                    help="Baud rate for serial (default: 115200)")
    bridge_send_parser.add_argument("-w", "--wait", type=float, default=0.5,
                                    help="Wait time for response in seconds (default: 0.5)")

    # bridge record
    bridge_record_parser = bridge_subparsers.add_parser("record",
                                                         help="Record session for primitive creation")
    bridge_record_parser.add_argument("port", help="Serial port or BLE address")
    bridge_record_parser.add_argument("-o", "--output", default="./recording.json",
                                      help="Output file (default: ./recording.json)")
    bridge_record_parser.add_argument("-t", "--transport", default="serial",
                                      choices=["serial", "ble"],
                                      help="Transport type (default: serial)")
    bridge_record_parser.add_argument("-b", "--baud", type=int, default=115200,
                                      help="Baud rate for serial (default: 115200)")
    bridge_record_parser.add_argument("-n", "--name", help="Primitive skill name")

    # bridge replay
    bridge_replay_parser = bridge_subparsers.add_parser("replay", help="Replay a recorded session")
    bridge_replay_parser.add_argument("recording", help="Path to recording file")
    bridge_replay_parser.add_argument("port", help="Serial port or BLE address")
    bridge_replay_parser.add_argument("-t", "--transport", default="serial",
                                      choices=["serial", "ble"],
                                      help="Transport type (default: serial)")
    bridge_replay_parser.add_argument("-b", "--baud", type=int, default=115200,
                                      help="Baud rate for serial (default: 115200)")
    bridge_replay_parser.add_argument("-s", "--speed", type=float, default=1.0,
                                      help="Playback speed multiplier (default: 1.0)")

    # bridge serve
    bridge_serve_parser = bridge_subparsers.add_parser("serve",
        help="Start WebSocket server for Artifex Desktop integration",
        description="""Start the ATE Bridge Server for Artifex Desktop integration.

This server enables sim-to-real transfer by bridging Artifex Desktop to physical robot hardware.

WORKFLOW:
1. Start this server: ate bridge serve -v
2. Connect your robot via USB serial
3. In Artifex Desktop, use the Hardware panel or AI tools to connect
4. Control your robot directly from the Artifex interface""",
        formatter_class=argparse.RawDescriptionHelpFormatter)
    bridge_serve_parser.add_argument("-p", "--port", type=int, default=8765,
                                     help="WebSocket port (default: 8765)")
    bridge_serve_parser.add_argument("-v", "--verbose", action="store_true",
                                     help="Enable verbose logging")


def handle(client, args):
    """Handle bridge commands."""
    if args.bridge_action == "connect":
        bridge_connect(client, args.port, args.transport, args.baud, args.protocol)
    elif args.bridge_action == "send":
        bridge_send(client, args.port, args.command, args.transport, args.baud, args.wait)
    elif args.bridge_action == "record":
        bridge_record(client, args.port, args.output, args.transport, args.baud, args.name)
    elif args.bridge_action == "replay":
        bridge_replay(client, args.recording, args.port, args.transport, args.baud, args.speed)
    elif args.bridge_action == "serve":
        bridge_serve(args.port, args.verbose)
    else:
        print("Usage: ate bridge {connect|send|record|replay|serve}")
        sys.exit(1)
