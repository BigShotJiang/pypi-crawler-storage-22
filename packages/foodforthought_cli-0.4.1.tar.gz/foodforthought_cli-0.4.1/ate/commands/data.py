"""
Data management commands for FoodforThought CLI.

Commands:
- ate data upload   - Upload dataset/sensor logs
- ate data list     - List datasets
- ate data promote  - Promote dataset to next stage
- ate data export   - Export dataset in specified format
"""

import json
import sys
from pathlib import Path
from typing import Optional


def data_upload(client, path: str, skill: str, stage: str) -> None:
    """Upload dataset/sensor logs."""
    data_path = Path(path)

    if not data_path.exists():
        print(f"Error: Path not found: {path}", file=sys.stderr)
        sys.exit(1)

    print(f"Uploading data...")
    print(f"  Path: {path}")
    print(f"  Skill: {skill}")
    print(f"  Stage: {stage}")

    # Count files
    if data_path.is_dir():
        files = list(data_path.rglob("*"))
        file_count = len([f for f in files if f.is_file()])
        total_size = sum(f.stat().st_size for f in files if f.is_file())
    else:
        file_count = 1
        total_size = data_path.stat().st_size

    print(f"  Files: {file_count}")
    print(f"  Size: {total_size / 1024 / 1024:.1f} MB")

    try:
        response = client._request("POST", "/datasets/upload", json={
            "skillId": skill,
            "stage": stage,
            "fileCount": file_count,
            "totalSize": total_size,
        })

        dataset = response.get("dataset", {})
        print(f"\n✓ Dataset uploaded!")
        print(f"  Dataset ID: {dataset.get('id')}")
        print(f"  Stage: {dataset.get('stage')}")

    except Exception as e:
        print(f"\n✗ Upload failed: {e}", file=sys.stderr)
        sys.exit(1)


def data_list(client, skill: Optional[str], stage: Optional[str]) -> None:
    """List datasets."""
    print("Fetching datasets...")

    params = {}
    if skill:
        params["skill"] = skill
    if stage:
        params["stage"] = stage

    try:
        response = client._request("GET", "/datasets", params=params)
        datasets = response.get("datasets", [])

        if not datasets:
            print("\nNo datasets found.")
            return

        print(f"\n{'=' * 70}")
        print(f"{'Name':<30} {'Stage':<15} {'Size':<15} {'Created':<15}")
        print(f"{'=' * 70}")

        for ds in datasets:
            name = ds.get("name", "Unnamed")[:28]
            ds_stage = ds.get("stage", "unknown")[:13]
            size = f"{ds.get('size', 0) / 1024 / 1024:.1f} MB"
            created = ds.get("createdAt", "")[:10]
            print(f"{name:<30} {ds_stage:<15} {size:<15} {created:<15}")

    except Exception as e:
        print(f"\n✗ Failed to list: {e}", file=sys.stderr)
        sys.exit(1)


def data_promote(client, dataset_id: str, to_stage: str) -> None:
    """Promote dataset to next stage."""
    print(f"Promoting dataset...")
    print(f"  Dataset: {dataset_id}")
    print(f"  New Stage: {to_stage}")

    try:
        client._request("PATCH", f"/datasets/{dataset_id}/promote", json={
            "stage": to_stage,
        })

        print(f"\n✓ Dataset promoted to {to_stage}!")

    except Exception as e:
        print(f"\n✗ Promotion failed: {e}", file=sys.stderr)
        sys.exit(1)


def data_export(client, dataset_id: str, format: str, output: str) -> None:
    """Export dataset in specified format."""
    print(f"Exporting dataset...")
    print(f"  Dataset: {dataset_id}")
    print(f"  Format: {format}")
    print(f"  Output: {output}")

    try:
        response = client._request("GET", f"/datasets/{dataset_id}/export",
                                  params={"format": format})

        # Save export
        output_path = Path(output)
        output_path.mkdir(parents=True, exist_ok=True)

        export_file = output_path / f"{dataset_id}.{format}"
        with open(export_file, 'w') as f:
            json.dump(response, f, indent=2)

        print(f"\n✓ Exported to: {export_file}")

    except Exception as e:
        print(f"\n✗ Export failed: {e}", file=sys.stderr)
        sys.exit(1)


def register_parser(subparsers):
    """Register data commands with argparse."""
    data_parser = subparsers.add_parser("data", help="Dataset and telemetry management")
    data_subparsers = data_parser.add_subparsers(dest="data_action", help="Data action")

    # data upload
    data_upload_parser = data_subparsers.add_parser("upload", help="Upload sensor data")
    data_upload_parser.add_argument("path", help="Path to data directory or file")
    data_upload_parser.add_argument("-s", "--skill", required=True, help="Associated skill ID")
    data_upload_parser.add_argument("--stage", default="raw",
                                   choices=["raw", "annotated", "skill-abstracted", "production"],
                                   help="Data stage (default: raw)")

    # data list
    data_list_parser = data_subparsers.add_parser("list", help="List datasets")
    data_list_parser.add_argument("-s", "--skill", help="Filter by skill ID")
    data_list_parser.add_argument("--stage", help="Filter by stage")

    # data promote
    data_promote_parser = data_subparsers.add_parser("promote", help="Promote dataset stage")
    data_promote_parser.add_argument("dataset_id", help="Dataset ID")
    data_promote_parser.add_argument("--to", required=True, dest="to_stage",
                                    choices=["annotated", "skill-abstracted", "production"],
                                    help="Target stage")

    # data export
    data_export_parser = data_subparsers.add_parser("export", help="Export dataset")
    data_export_parser.add_argument("dataset_id", help="Dataset ID")
    data_export_parser.add_argument("-f", "--format", default="rlds",
                                   choices=["json", "rlds", "lerobot", "hdf5"],
                                   help="Export format (default: rlds)")
    data_export_parser.add_argument("-o", "--output", default="./export",
                                   help="Output directory")


def handle(client, args):
    """Handle data commands."""
    if args.data_action == "upload":
        data_upload(client, args.path, args.skill, args.stage)
    elif args.data_action == "list":
        data_list(client, args.skill, args.stage)
    elif args.data_action == "promote":
        data_promote(client, args.dataset_id, args.to_stage)
    elif args.data_action == "export":
        data_export(client, args.dataset_id, args.format, args.output)
    else:
        print("Usage: ate data {upload|list|promote|export}")
        sys.exit(1)
