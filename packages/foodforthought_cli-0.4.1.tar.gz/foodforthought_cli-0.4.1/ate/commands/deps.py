"""
Dependency management commands for FoodforThought CLI.

Commands:
- ate deps audit  - Verify all dependencies are compatible
"""

import json
import sys
from pathlib import Path
from typing import Optional


def deps_audit(client, skill_id: Optional[str]) -> None:
    """Verify all dependencies are compatible."""
    if skill_id:
        skills_to_check = [skill_id]
        print(f"Auditing dependencies for skill: {skill_id}")
    else:
        # Check current repository
        ate_dir = Path(".ate")
        if not ate_dir.exists():
            print("Error: Not a FoodforThought repository. Specify --skill or run from repo.",
                  file=sys.stderr)
            sys.exit(1)

        with open(ate_dir / "config.json") as f:
            config = json.load(f)
        skills_to_check = [config["id"]]
        print(f"Auditing dependencies for repository: {config['name']}")

    all_passed = True
    issues = []

    for sid in skills_to_check:
        try:
            response = client._request("GET", f"/skills/{sid}/parts", params={"required": "true"})
            parts = response.get("parts", [])

            for part_data in parts:
                part = part_data.get("part", {})

                # Check if part is available
                try:
                    part_check = client._request("GET", f"/parts/{part.get('id')}")
                    if not part_check.get("part"):
                        issues.append({
                            "skill": sid,
                            "part": part.get("name"),
                            "issue": "Part not found in catalog",
                            "severity": "error"
                        })
                        all_passed = False
                except Exception:
                    issues.append({
                        "skill": sid,
                        "part": part.get("name"),
                        "issue": "Could not verify part availability",
                        "severity": "warning"
                    })

        except Exception as e:
            issues.append({
                "skill": sid,
                "part": "N/A",
                "issue": f"Failed to fetch dependencies: {e}",
                "severity": "error"
            })
            all_passed = False

    print(f"\n{'=' * 60}")
    print("Dependency Audit Results")
    print(f"{'=' * 60}")

    if not issues:
        print("\n✓ All dependencies verified successfully!")
        print("  - All required parts are available")
        print("  - Version constraints are satisfied")
    else:
        for issue in issues:
            icon = "✗" if issue["severity"] == "error" else "⚠"
            print(f"\n{icon} {issue['part']} ({issue['skill']})")
            print(f"  {issue['issue']}")

        errors = len([i for i in issues if i["severity"] == "error"])
        warnings = len([i for i in issues if i["severity"] == "warning"])
        print(f"\n{'=' * 60}")
        print(f"Summary: {errors} errors, {warnings} warnings")

        if not all_passed:
            sys.exit(1)


def register_parser(subparsers):
    """Register deps commands with argparse."""
    deps_parser = subparsers.add_parser("deps", help="Dependency management")
    deps_subparsers = deps_parser.add_subparsers(dest="deps_action", help="Deps action")

    # deps audit
    deps_audit_parser = deps_subparsers.add_parser("audit",
                                                   help="Verify all dependencies compatible")
    deps_audit_parser.add_argument("-s", "--skill", help="Skill ID (default: current repo)")


def handle(client, args):
    """Handle deps commands."""
    if args.deps_action == "audit":
        deps_audit(client, args.skill)
    else:
        print("Usage: ate deps audit")
        sys.exit(1)
