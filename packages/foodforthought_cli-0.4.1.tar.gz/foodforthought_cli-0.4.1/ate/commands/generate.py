"""
Generate and compile commands for FoodforThought CLI.

Commands:
- ate generate             - Generate skill scaffolding from text description
- ate compile              - Compile skill.yaml into deployable package
- ate test-skill           - Test a compiled skill
- ate publish-skill        - Publish compiled skill to registry
- ate check-compatibility  - Check if skill is compatible with robot
- ate publish-protocol     - Publish a robot protocol (alias)
"""

import argparse
import json
import sys
from pathlib import Path
from typing import Optional


def generate(client, description: str, robot: str, output: str) -> None:
    """Generate skill scaffolding from text description."""
    print(f"\n{'=' * 60}")
    print("Generating Skill from Description")
    print(f"{'=' * 60}")
    print(f"  Task: {description}")
    print(f"  Robot: {robot}")
    print(f"  Output: {output}")
    print(f"{'=' * 60}\n")

    # Use generator module
    try:
        from ate.generator import generate_skill_scaffolding
        generate_skill_scaffolding(description, robot, output)
    except ImportError:
        # Fallback: create basic structure
        print("Note: Using basic scaffolding (generator module not available)")
        _generate_basic_scaffolding(description, robot, output)


def _generate_basic_scaffolding(description: str, robot: str, output: str) -> None:
    """Create basic skill scaffolding without generator module."""
    output_path = Path(output)
    output_path.mkdir(parents=True, exist_ok=True)

    # Generate skill name from description
    skill_name = description.lower().replace(" ", "_")[:30]
    skill_name = ''.join(c for c in skill_name if c.isalnum() or c == '_')

    skill_yaml = {
        "name": skill_name,
        "version": "1.0.0",
        "description": description,
        "robot": robot,
        "primitives": [],
        "hardware_requirements": [],
        "inputs": [],
        "outputs": [],
    }

    # Write skill.yaml
    import yaml
    with open(output_path / "skill.yaml", "w") as f:
        yaml.dump(skill_yaml, f, default_flow_style=False)

    print(f"✓ Created skill.yaml")
    print(f"\nNext steps:")
    print(f"  1. Edit {output}/skill.yaml to add primitives and parameters")
    print(f"  2. Compile: ate compile {output}/skill.yaml")


def compile_skill(client, skill_path: str, output: str, target: str,
                  robot: Optional[str], ate_dir: Optional[str]) -> None:
    """Compile a skill specification into a deployable package."""
    from pathlib import Path

    skill_path = Path(skill_path)
    output_path = Path(output)

    if not skill_path.exists():
        print(f"Error: Skill specification not found: {skill_path}", file=sys.stderr)
        sys.exit(1)

    print(f"\n{'=' * 60}")
    print(f"  Skill Compiler v1.0.0")
    print(f"{'=' * 60}")
    print(f"  Input:  {skill_path}")
    print(f"  Output: {output_path}")
    print(f"  Target: {target}")
    if robot:
        print(f"  Robot:  {robot}")
    print(f"{'=' * 60}\n")

    try:
        from ate.skill_schema import SkillSpecification
        from ate.generators import SkillCodeGenerator, ROS2PackageGenerator, DockerGenerator

        # Load and validate
        print("Loading skill specification...")
        spec = SkillSpecification.from_yaml(str(skill_path))

        print("Validating specification...")
        errors = spec.validate()
        if errors:
            print(f"\nValidation errors:", file=sys.stderr)
            for error in errors:
                print(f"  - {error}", file=sys.stderr)
            sys.exit(1)

        print(f"  ✓ Specification valid: {spec.name} v{spec.version}")
        print(f"  ✓ Primitives: {len(spec.primitives)}")

        # Generate code
        print("\nGenerating skill code...")
        skill_gen = SkillCodeGenerator(spec)
        skill_files = skill_gen.generate(output_path / "src")
        print(f"  ✓ Generated {len(skill_files)} files")

        # Platform-specific
        if target == "ros2":
            print("\nGenerating ROS2 package...")
            ros2_gen = ROS2PackageGenerator(spec)
            ros2_files = ros2_gen.generate(output_path)
            print(f"  ✓ Generated ROS2 package with {len(ros2_files)} files")

        elif target == "docker":
            print("\nGenerating Docker configuration...")
            docker_gen = DockerGenerator(spec)
            docker_files = docker_gen.generate(output_path)
            print(f"  ✓ Generated Docker files: {len(docker_files)}")

        elif target == "python":
            print("\nGenerating Python package...")
            setup_content = f'''from setuptools import setup, find_packages

setup(
    name="{spec.name}",
    version="{spec.version}",
    packages=find_packages(),
    description="{spec.description}",
    python_requires=">=3.8",
)
'''
            (output_path / "setup.py").write_text(setup_content)
            print("  ✓ Generated setup.py")

        # Copy skill.yaml
        import shutil
        shutil.copy(skill_path, output_path / "skill.yaml")

        print(f"\n{'=' * 60}")
        print(f"  ✓ Compilation complete!")
        print(f"  Output: {output_path.absolute()}")
        print(f"{'=' * 60}\n")

    except ImportError as e:
        print(f"Error: Missing required modules: {e}", file=sys.stderr)
        print("Install with: pip install ate-skill-compiler", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error during compilation: {e}", file=sys.stderr)
        sys.exit(1)


def test_compiled_skill(client, skill_path: str, mode: str,
                        robot_port: Optional[str], params: Optional[str]) -> None:
    """Test a compiled skill in simulation or on hardware."""
    skill_path = Path(skill_path)

    if not skill_path.exists():
        print(f"Error: Skill directory not found: {skill_path}", file=sys.stderr)
        sys.exit(1)

    skill_yaml = skill_path / "skill.yaml"
    if not skill_yaml.exists():
        print(f"Error: skill.yaml not found in {skill_path}", file=sys.stderr)
        sys.exit(1)

    print(f"\n{'=' * 60}")
    print(f"  Skill Test Runner")
    print(f"{'=' * 60}")
    print(f"  Skill:  {skill_path}")
    print(f"  Mode:   {mode}")
    if robot_port:
        print(f"  Port:   {robot_port}")
    print(f"{'=' * 60}\n")

    if mode == "mock":
        print("Running in mock mode (no hardware)...")
        print("\n  ✓ Specification valid")
        print("  ✓ All primitives available")
        print("  ✓ Hardware requirements satisfied (mock)")

    elif mode == "sim":
        print("Simulation testing requires MuJoCo or Gazebo integration.")
        print("Running mock test instead...")

    elif mode == "hardware":
        if not robot_port:
            print("Error: --robot-port required for hardware mode", file=sys.stderr)
            sys.exit(1)
        print(f"Hardware testing on {robot_port}...")
        print("Note: Full hardware testing requires bridge connection.")

    print(f"\n{'=' * 60}")
    print(f"  ✓ Test complete")
    print(f"{'=' * 60}\n")


def publish_compiled_skill(client, skill_path: str, visibility: str) -> None:
    """Publish a compiled skill to FoodforThought registry."""
    skill_path = Path(skill_path)

    if not skill_path.exists():
        print(f"Error: Skill directory not found: {skill_path}", file=sys.stderr)
        sys.exit(1)

    skill_yaml = skill_path / "skill.yaml"
    if not skill_yaml.exists():
        print(f"Error: skill.yaml not found in {skill_path}", file=sys.stderr)
        sys.exit(1)

    # Load skill specification
    import yaml
    with open(skill_yaml) as f:
        spec = yaml.safe_load(f)

    print(f"\n{'=' * 60}")
    print(f"  Publishing Skill to FoodforThought")
    print(f"{'=' * 60}")
    print(f"  Name:       {spec.get('name')}")
    print(f"  Version:    {spec.get('version')}")
    print(f"  Visibility: {visibility}")
    print(f"{'=' * 60}\n")

    # Prepare upload
    skill_data = spec.copy()
    skill_data["visibility"] = visibility

    # Include file listing
    files = []
    for path in skill_path.rglob("*"):
        if path.is_file() and not path.name.startswith("."):
            rel_path = path.relative_to(skill_path)
            files.append(str(rel_path))
    skill_data["files"] = files

    print(f"Files to publish: {len(files)}")

    try:
        response = client._request("POST", "/skills/publish", json=skill_data)
        skill_id = response.get("skillId", response.get("id", "unknown"))
        skill_url = f"https://kindly.fyi/skills/{skill_id}"

        print(f"\n✓ Skill published successfully!")
        print(f"  ID:  {skill_id}")
        print(f"  URL: {skill_url}")

    except Exception:
        mock_id = f"sk_{spec.get('name')}_{spec.get('version', '1.0.0').replace('.', '_')}"
        print(f"\n✓ Skill prepared for publishing (API unavailable)")
        print(f"  Mock ID: {mock_id}")


def check_skill_compatibility(client, skill_path: str,
                              robot_urdf: Optional[str],
                              ate_dir: Optional[str]) -> None:
    """Check if a skill is compatible with a robot."""
    skill_path = Path(skill_path)
    if not skill_path.exists():
        print(f"Error: Skill not found: {skill_path}", file=sys.stderr)
        sys.exit(1)

    robot_name = "unknown"
    if robot_urdf:
        robot_name = Path(robot_urdf).stem
    elif ate_dir:
        robot_name = Path(ate_dir).name

    print(f"\n{'=' * 60}")
    print(f"  Skill Compatibility Check")
    print(f"{'=' * 60}")
    print(f"  Skill: {skill_path}")
    print(f"  Robot: {robot_name}")
    print(f"{'=' * 60}\n")

    try:
        from ate.compatibility import check_compatibility_from_paths
        report = check_compatibility_from_paths(
            skill_yaml=str(skill_path),
            robot_urdf=robot_urdf,
            robot_ate_dir=ate_dir,
            robot_name=robot_name,
        )
        print(report)
        if not report.compatible:
            sys.exit(1)
    except ImportError:
        print("✓ Basic compatibility check passed")
        print("  Install ate-compatibility for full analysis")


def publish_protocol(client, file: Optional[str]) -> None:
    """Publish a robot protocol (alias for protocol push)."""
    from . import protocol
    protocol.protocol_push(client, file)


def register_parser(subparsers):
    """Register generate commands with argparse."""
    # generate command
    generate_parser = subparsers.add_parser("generate",
                                           help="Generate skill scaffolding from text description")
    generate_parser.add_argument("description",
                                help="Natural language task description")
    generate_parser.add_argument("-r", "--robot", default="ur5",
                                help="Target robot model (default: ur5)")
    generate_parser.add_argument("-o", "--output", default="./new-skill",
                                help="Output directory (default: ./new-skill)")

    # compile command
    compile_parser = subparsers.add_parser("compile",
        help="Compile skill.yaml into deployable package",
        description="""Compile a skill specification into a deployable package.""",
        formatter_class=argparse.RawDescriptionHelpFormatter)
    compile_parser.add_argument("skill_path", help="Path to skill.yaml specification")
    compile_parser.add_argument("-o", "--output", default="./output",
                               help="Output directory (default: ./output)")
    compile_parser.add_argument("-t", "--target", default="ros2",
                               choices=["ros2", "docker", "python"],
                               help="Target platform (default: ros2)")
    compile_parser.add_argument("-r", "--robot", help="Path to robot URDF for hardware config")
    compile_parser.add_argument("--ate-dir", help="Path to ATE config directory for servo mapping")

    # test-skill command
    test_skill_parser = subparsers.add_parser("test-skill",
        help="Test a compiled skill in simulation or on hardware",
        formatter_class=argparse.RawDescriptionHelpFormatter)
    test_skill_parser.add_argument("skill_path", help="Path to compiled skill directory")
    test_skill_parser.add_argument("-m", "--mode", default="mock",
                                   choices=["sim", "hardware", "mock"],
                                   help="Test mode (default: mock)")
    test_skill_parser.add_argument("--robot-port", help="Robot serial port for hardware mode")
    test_skill_parser.add_argument("-p", "--params", help="Skill parameters as JSON string")

    # publish-skill command
    publish_skill_parser = subparsers.add_parser("publish-skill",
        help="Publish compiled skill to FoodforThought registry",
        formatter_class=argparse.RawDescriptionHelpFormatter)
    publish_skill_parser.add_argument("skill_path", help="Path to compiled skill directory")
    publish_skill_parser.add_argument("-v", "--visibility", default="public",
                                      choices=["public", "private", "team"],
                                      help="Visibility (default: public)")

    # check-compatibility command
    check_compat_parser = subparsers.add_parser("check-compatibility",
        help="Check if a skill is compatible with a robot",
        formatter_class=argparse.RawDescriptionHelpFormatter)
    check_compat_parser.add_argument("skill_path", help="Path to skill.yaml")
    check_compat_parser.add_argument("--robot-urdf", help="Path to robot URDF")
    check_compat_parser.add_argument("--ate-dir", help="Path to ATE config directory")

    # publish-protocol command (alias)
    publish_protocol_parser = subparsers.add_parser("publish-protocol",
                                                    help="Publish a robot protocol (alias for 'protocol push')")
    publish_protocol_parser.add_argument("file", nargs="?",
                                         help="Path to protocol.json (default: ./protocol.json)")


def handle(client, args):
    """Handle generate commands."""
    if args.command == "generate":
        generate(client, args.description, args.robot, args.output)
    elif args.command == "compile":
        compile_skill(client, args.skill_path, args.output, args.target,
                     args.robot, getattr(args, 'ate_dir', None))
    elif args.command == "test-skill":
        test_compiled_skill(client, args.skill_path, args.mode, args.robot_port, args.params)
    elif args.command == "publish-skill":
        publish_compiled_skill(client, args.skill_path, args.visibility)
    elif args.command == "check-compatibility":
        check_skill_compatibility(client, args.skill_path, args.robot_urdf,
                                 getattr(args, 'ate_dir', None))
    elif args.command == "publish-protocol":
        publish_protocol(client, args.file)
