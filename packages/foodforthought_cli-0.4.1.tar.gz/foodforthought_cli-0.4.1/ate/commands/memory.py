"""
Memory management commands for FoodforThought CLI.

Commands:
- ate memory init    - Create a new .mv2 memory file
- ate memory add     - Add content (single text or bulk JSONL)
- ate memory search  - Search memory by query
- ate memory info    - Show memory store statistics
- ate memory export  - Export all content to JSONL
- ate memory merge   - Merge multiple .mv2 files
"""

import json
import os
import sys
from dataclasses import asdict
from pathlib import Path

from ate.memory import MemoryStore, merge_memories, EmbeddingConfig, EmbeddingManager
from ate.memory.cloud import CloudClient, CloudAuthError, CloudError, CloudNotFoundError, CloudForbiddenError
from ate.auth.token_store import TokenStore

# Capsule imports are lazy — loaded inside handler functions to avoid
# import errors when capsule module dependencies are missing.


# ---------------------------------------------------------------------------
# Arg-parser registration
# ---------------------------------------------------------------------------

def register_parser(subparsers):
    """Register memory commands with argparse."""
    mem_parser = subparsers.add_parser("memory", help="Memory file management (.mv2)")
    mem_subs = mem_parser.add_subparsers(dest="memory_action", help="Memory action")

    # --- init ---
    p_init = mem_subs.add_parser("init", help="Create a new .mv2 memory file")
    p_init.add_argument("path", help="Path for the new .mv2 file")
    p_init.add_argument("--embedding-provider", dest="embedding_provider", default=None,
                        choices=["openai", "cohere", "voyage", "ollama", "none"],
                        help="Embedding provider to use")
    p_init.add_argument("--embedding-model", dest="embedding_model", default=None,
                        help="Embedding model override")
    p_init.add_argument("--format", dest="format", default=None,
                        choices=["json"], help="Output format (default: human-readable)")

    # --- add ---
    p_add = mem_subs.add_parser("add", help="Add content to a memory file")
    p_add.add_argument("path", help="Path to the .mv2 file")
    p_add.add_argument("--text", default=None, help="Text content to add")
    p_add.add_argument("--file", default=None, help="JSONL file for bulk add")
    p_add.add_argument("--tags", default=None, help="Comma-separated tags")
    p_add.add_argument("--title", default=None, help="Title for the entry")
    p_add.add_argument("--metadata", default=None, help="JSON metadata string")
    p_add.add_argument("--embed", action="store_true", default=False,
                        help="Force embedding even if not default")
    p_add.add_argument("--agent-id", dest="agent_id", default=None, help="Agent identifier for safe concurrent access")
    p_add.add_argument("--wait", type=float, default=10.0, help="Max seconds to wait for lock (default: 10)")
    p_add.add_argument("--lock-timeout", dest="lock_timeout", type=float, default=30.0, help="Lock auto-release timeout (default: 30)")
    p_add.add_argument("--format", dest="format", default=None,
                        choices=["json"], help="Output format")

    # --- search ---
    p_search = mem_subs.add_parser("search", help="Search memory")
    p_search.add_argument("path", help="Path to the .mv2 file")
    p_search.add_argument("query", help="Search query")
    p_search.add_argument("--top-k", type=int, default=5, help="Max results (default 5)")
    p_search.add_argument("--engine", dest="engine", default=None,
                          choices=["auto", "vec", "lex", "hybrid", "rerank"],
                          help="Search engine to use (default: auto)")
    p_search.add_argument("--rerank-provider", dest="rerank_provider", default=None,
                          choices=["anthropic", "openai", "google", "ollama"],
                          help="LLM provider for reranking")
    p_search.add_argument("--rerank-model", dest="rerank_model", default=None,
                          help="LLM model for reranking")
    p_search.add_argument("--format", dest="format", default=None,
                          choices=["json"], help="Output format")

    # --- info ---
    p_info = mem_subs.add_parser("info", help="Show memory store statistics")
    p_info.add_argument("path", help="Path to the .mv2 file")
    p_info.add_argument("--format", dest="format", default=None,
                        choices=["json"], help="Output format")

    # --- export ---
    p_export = mem_subs.add_parser("export", help="Export memory content")
    p_export.add_argument("path", help="Path to the .mv2 file")
    p_export.add_argument("--output", required=True, help="Output file path")
    p_export.add_argument("--format", dest="format", default=None,
                          choices=["json", "jsonl", "markdown"], help="Output format (json, jsonl, or markdown)")

    # --- merge ---
    p_merge = mem_subs.add_parser("merge", help="Merge multiple .mv2 files")
    p_merge.add_argument("paths", nargs="+", help="Source .mv2 file paths")
    p_merge.add_argument("--output", required=True, help="Output .mv2 file path")
    p_merge.add_argument("--no-dedup", action="store_true", default=False,
                         help="Disable deduplication")
    p_merge.add_argument("--format", dest="format", default=None,
                         choices=["json"], help="Output format")

    # --- think (context-aware) ---
    p_think = mem_subs.add_parser("think", help="Add a thought to active memory")
    p_think.add_argument("text", help="Text content to add")
    p_think.add_argument("--memory", default=None, help="Override active memory")
    p_think.add_argument("--tags", default=None, help="Comma-separated tags")
    p_think.add_argument("--title", default=None, help="Title for the entry")
    p_think.add_argument("--metadata", default=None, help="JSON metadata string")
    p_think.add_argument("--embed", action="store_true", default=False,
                        help="Force embedding even if not default")
    p_think.add_argument("--format", dest="format", default=None,
                        choices=["json"], help="Output format")

    # --- recall (context-aware) ---
    p_recall = mem_subs.add_parser("recall", help="Search active memory")
    p_recall.add_argument("query", help="Search query")
    p_recall.add_argument("--memory", default=None, help="Override active memory")
    p_recall.add_argument("--top-k", type=int, default=5, help="Max results (default 5)")
    p_recall.add_argument("--engine", dest="engine", default=None,
                          choices=["auto", "vec", "lex", "hybrid", "rerank"],
                          help="Search engine to use (default: auto)")
    p_recall.add_argument("--all-trains", action="store_true", default=False,
                          help="Search across all trains in current memory")
    p_recall.add_argument("--format", dest="format", default=None,
                          choices=["json"], help="Output format")

    # --- train (context switching) ---
    p_train = mem_subs.add_parser("train", help="Manage trains of thought")
    p_train.add_argument("name", nargs="?", help="Train name to switch to")
    p_train.add_argument("--delete", default=None, help="Delete a train")
    p_train.add_argument("--rename", nargs=2, metavar=("OLD", "NEW"), 
                        help="Rename a train")
    p_train.add_argument("--format", dest="format", default=None,
                        choices=["json"], help="Output format")

    # --- status (context info) ---
    p_status = mem_subs.add_parser("status", help="Show current memory context")
    p_status.add_argument("--format", dest="format", default=None,
                         choices=["json"], help="Output format")

    # --- new (memory creation) ---
    p_new = mem_subs.add_parser("new", help="Create a new memory")
    p_new.add_argument("name", help="Memory name")
    p_new.add_argument("--description", default="", help="Memory description")
    p_new.add_argument("--format", dest="format", default=None,
                      choices=["json"], help="Output format")

    # --- use (memory switching) ---
    p_use = mem_subs.add_parser("use", help="Switch to a different memory")
    p_use.add_argument("name", help="Memory name")
    p_use.add_argument("--format", dest="format", default=None,
                      choices=["json"], help="Output format")

    # --- list-memories (local memories) ---
    p_list_memories = mem_subs.add_parser("list-memories", help="List all local memories")
    p_list_memories.add_argument("--format", dest="format", default=None,
                                choices=["json"], help="Output format")

    # --- push (cloud) ---
    p_push = mem_subs.add_parser("push", help="Upload .mv2 file to cloud")
    p_push.add_argument("path", help="Path to the .mv2 file to upload")
    p_push.add_argument("--name", default=None, help="Memory name (defaults to filename sans extension)")
    p_push.add_argument("--project", default=None, help="(deprecated, ignored) Project identifier")
    p_push.add_argument("--train", default="main", help="Train name (default: main)")
    p_push.add_argument("--description", default=None, help="Memory description")
    p_push.add_argument("--visibility", default="private",
                        choices=["private", "unlisted", "public"],
                        help="Memory visibility (default: private)")
    p_push.add_argument("--format", dest="format", default=None,
                        choices=["json"], help="Output format")

    # --- pull (cloud) ---
    p_pull = mem_subs.add_parser("pull", help="Download .mv2 file from cloud")
    p_pull.add_argument("ref", help="Memory name (or project/name for backward compat)")
    p_pull.add_argument("--output", required=True, help="Output file path")
    p_pull.add_argument("--train", default=None, help="Specific train to download (default: first)")
    p_pull.add_argument("--format", dest="format", default=None,
                        choices=["json"], help="Output format")

    # --- list (cloud) ---
    p_list = mem_subs.add_parser("list", help="List your cloud memories")
    p_list.add_argument("--project", default=None, help="(deprecated, ignored) Project identifier")
    p_list.add_argument("--format", dest="format", default=None,
                        choices=["json"], help="Output format")

    # --- delete (cloud) ---
    p_delete = mem_subs.add_parser("delete", help="Delete a memory file from cloud")
    p_delete.add_argument("ref", help="Project/name reference (e.g. kindly/memories/old.mv2)")
    p_delete.add_argument("--format", dest="format", default=None,
                          choices=["json"], help="Output format")

    # --- providers ---
    p_providers = mem_subs.add_parser("providers", help="List detected embedding providers")
    p_providers.add_argument("--format", dest="format", default=None,
                            choices=["json"], help="Output format")

    # --- keygen (crypto) ---
    p_keygen = mem_subs.add_parser("keygen", help="Generate a new Ed25519 or X25519 keypair")
    p_keygen.add_argument("--name", default="default", help="Key name (default: default)")
    p_keygen.add_argument("--type", default="ed25519", choices=["ed25519", "x25519"], 
                         help="Key type (default: ed25519)")
    p_keygen.add_argument("--format", dest="format", default=None,
                         choices=["json"], help="Output format")

    # --- keys (crypto) ---
    p_keys = mem_subs.add_parser("keys", help="List available keys and fingerprints")
    p_keys.add_argument("--format", dest="format", default=None,
                       choices=["json"], help="Output format")

    # --- sign (crypto) ---
    p_sign = mem_subs.add_parser("sign", help="Sign active memory with Ed25519")
    p_sign.add_argument("--key", default="default", help="Key name to use (default: default)")
    p_sign.add_argument("--path", default=None, help="Path to .mv2 file (default: active memory)")
    p_sign.add_argument("--format", dest="format", default=None,
                       choices=["json"], help="Output format")

    # --- verify (crypto) ---
    p_verify = mem_subs.add_parser("verify", help="Verify signature of active memory")
    p_verify.add_argument("--fingerprint", default=None, help="Fingerprint of expected signer (optional)")
    p_verify.add_argument("--path", default=None, help="Path to .mv2 file (default: active memory)")
    p_verify.add_argument("--format", dest="format", default=None,
                         choices=["json"], help="Output format")

    # --- audit (crypto) ---
    p_audit = mem_subs.add_parser("audit", help="Verify integrity chain of active memory")
    p_audit.add_argument("--verbose", action="store_true", default=False, help="Show detailed audit info")
    p_audit.add_argument("--path", default=None, help="Path to .mv2 file (default: active memory)")
    p_audit.add_argument("--format", dest="format", default=None,
                        choices=["json"], help="Output format")

    # --- seal (crypto) ---
    p_seal = mem_subs.add_parser("seal", help="Encrypt active memory with passphrase")
    p_seal.add_argument("--passphrase", required=True, help="Encryption passphrase")
    p_seal.add_argument("--path", default=None, help="Path to .mv2 file (default: active memory)")
    p_seal.add_argument("--format", dest="format", default=None,
                       choices=["json"], help="Output format")

    # --- unseal (crypto) ---
    p_unseal = mem_subs.add_parser("unseal", help="Decrypt active memory")
    p_unseal.add_argument("--passphrase", required=True, help="Decryption passphrase")
    p_unseal.add_argument("--path", default=None, help="Path to .mv2 file (default: active memory)")
    p_unseal.add_argument("--format", dest="format", default=None,
                         choices=["json"], help="Output format")

    # --- lock-status (concurrency) ---
    p_lock_status = mem_subs.add_parser("lock-status", help="Show lock status of memory file")
    p_lock_status.add_argument("--path", default=None, help="Path to .mv2 file (default: active memory)")
    p_lock_status.add_argument("--format", dest="format", default=None,
                              choices=["json"], help="Output format")

    # --- force-unlock (concurrency) ---
    p_force_unlock = mem_subs.add_parser("force-unlock", help="Force-release a stale lock (admin operation)")
    p_force_unlock.add_argument("--path", default=None, help="Path to .mv2 file (default: active memory)")
    p_force_unlock.add_argument("--format", dest="format", default=None,
                               choices=["json"], help="Output format")

    # --- import (markdown → mv2) ---
    p_import = mem_subs.add_parser("import", help="Import a Markdown file into a .mv2 memory")
    p_import.add_argument("path", help="Path to the .mv2 file (created if missing)")
    p_import.add_argument("--markdown", default=None, help="Path to Markdown file to import")
    p_import.add_argument("--clear", action="store_true", default=False,
                          help="Reinitialize .mv2 before importing (full sync)")
    p_import.add_argument("--agent-id", dest="agent_id", default=None,
                          help="Agent ID for concurrent access locking")
    p_import.add_argument("--wait", type=float, default=10.0,
                          help="Max seconds to wait for lock (default: 10)")
    p_import.add_argument("--lock-timeout", dest="lock_timeout", type=float, default=30.0,
                          help="Lock auto-release timeout (default: 30)")
    p_import.add_argument("--format", dest="format", default=None,
                          choices=["json"], help="Output format")

    # --- capsule (memory capsules) ---
    p_capsule = mem_subs.add_parser("capsule", help="Memory capsule operations")
    capsule_subs = p_capsule.add_subparsers(dest="capsule_action", help="Capsule action")

    # capsule create
    p_capsule_create = capsule_subs.add_parser("create", help="Create a memory capsule")
    p_capsule_create.add_argument("name", help="Capsule name")
    p_capsule_create.add_argument("--memory", action="append", required=True, help="Memory file(s) to include")
    p_capsule_create.add_argument("--train", action="append", default=[], help="Train files (path or path:name)")
    p_capsule_create.add_argument("--description", default="", help="Capsule description")
    p_capsule_create.add_argument("--tags", default=[], help="Comma-separated tags")
    p_capsule_create.add_argument("--license", default="private", help="License (default: private)")
    p_capsule_create.add_argument("--sign", default=None, help="Sign with Ed25519 key")
    p_capsule_create.add_argument("--readme", default=None, help="README text or @file.md")
    p_capsule_create.add_argument("--output", required=True, help="Output .capsule file")
    p_capsule_create.add_argument("--format", dest="format", default=None,
                                 choices=["json"], help="Output format")

    # capsule inspect
    p_capsule_inspect = capsule_subs.add_parser("inspect", help="Inspect a capsule")
    p_capsule_inspect.add_argument("capsule_path", help="Path to .capsule file")
    p_capsule_inspect.add_argument("--verify", default=None, help="Verify signature with Ed25519 key")
    p_capsule_inspect.add_argument("--format", dest="format", default=None,
                                  choices=["json"], help="Output format")

    # capsule ingest
    p_capsule_ingest = capsule_subs.add_parser("ingest", help="Ingest a capsule")
    p_capsule_ingest.add_argument("capsule_path", help="Path to .capsule file")
    p_capsule_ingest.add_argument("--target", required=True, help="Target .mv2 file")
    p_capsule_ingest.add_argument("--mode", default="merge", choices=["merge", "extract"], help="Ingest mode")
    p_capsule_ingest.add_argument("--verify", default=None, help="Verify signature with Ed25519 key")
    p_capsule_ingest.add_argument("--agent-id", dest="agent_id", default=None, help="Agent ID for locking")
    p_capsule_ingest.add_argument("--format", dest="format", default=None,
                                 choices=["json"], help="Output format")

    # capsule extract
    p_capsule_extract = capsule_subs.add_parser("extract", help="Extract capsule to directory")
    p_capsule_extract.add_argument("capsule_path", help="Path to .capsule file")
    p_capsule_extract.add_argument("--output-dir", dest="output_dir", required=True, help="Output directory")
    p_capsule_extract.add_argument("--format", dest="format", default=None,
                                  choices=["json"], help="Output format")


# ---------------------------------------------------------------------------
# Dispatcher
# ---------------------------------------------------------------------------

def handle(client, args):
    """Handle memory commands."""
    action = getattr(args, "memory_action", None)
    if action == "init":
        _handle_init(args)
    elif action == "add":
        _handle_add(args)
    elif action == "search":
        _handle_search(args)
    elif action == "info":
        _handle_info(args)
    elif action == "export":
        _handle_export(args)
    elif action == "merge":
        _handle_merge(args)
    elif action == "think":
        _handle_think(args)
    elif action == "recall":
        _handle_recall(args)
    elif action == "train":
        _handle_train(args)
    elif action == "status":
        _handle_status(args)
    elif action == "new":
        _handle_new(args)
    elif action == "use":
        _handle_use(args)
    elif action == "list-memories":
        _handle_list_memories(args)
    elif action == "push":
        _handle_push(args)
    elif action == "pull":
        _handle_pull(args)
    elif action == "list":
        _handle_list(args)
    elif action == "delete":
        _handle_delete(args)
    elif action == "providers":
        _handle_providers(args)
    elif action == "keygen":
        _handle_keygen(args)
    elif action == "keys":
        _handle_keys(args)
    elif action == "sign":
        _handle_sign(args)
    elif action == "verify":
        _handle_verify(args)
    elif action == "audit":
        _handle_audit(args)
    elif action == "seal":
        _handle_seal(args)
    elif action == "unseal":
        _handle_unseal(args)
    elif action == "lock-status":
        _handle_lock_status(args)
    elif action == "force-unlock":
        _handle_force_unlock(args)
    elif action == "import":
        _handle_import(args)
    elif action == "capsule":
        _handle_capsule(args)
    else:
        print("Usage: ate memory {init|add|search|info|export|merge|think|recall|train|status|new|use|list-memories|push|pull|list|delete|providers|keygen|keys|sign|verify|audit|seal|unseal|lock-status|force-unlock|import|capsule}", file=sys.stderr)
        sys.exit(1)


# ---------------------------------------------------------------------------
# Individual handlers
# ---------------------------------------------------------------------------

def _handle_init(args):
    """Create a new .mv2 memory file."""
    path = args.path
    
    # Handle embedding configuration
    embedding_config = None
    if args.embedding_provider:
        embedding_config = EmbeddingConfig(
            provider=args.embedding_provider,
            model=args.embedding_model
        )
    
    try:
        store = MemoryStore.create(path, embedding_config=embedding_config)
        store.close()
    except Exception as e:
        print(f"Error: Failed to create memory file: {e}", file=sys.stderr)
        sys.exit(2)

    if args.format == "json":
        print(json.dumps({"path": path, "created": True}))
    else:
        print(f"✅ Created memory file: {path}")


def _execute_add_logic(args, store):
    """Execute the add logic with the given store."""
    text = args.text
    file_path = args.file
    
    if file_path:
        # Bulk add from JSONL
        items = []
        with open(file_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    items.append(json.loads(line))
        frame_ids = store.add_batch(items)

        if args.format == "json":
            print(json.dumps({"count": len(frame_ids), "frame_ids": frame_ids}))
        else:
            print(f"✅ Added {len(frame_ids)} entries from {file_path}")
    else:
        # Single add
        tags = [t.strip() for t in args.tags.split(",")] if args.tags else None
        metadata = json.loads(args.metadata) if args.metadata else None
        title = args.title
        enable_embedding = True if args.embed else None

        frame_id = store.add(text=text, tags=tags, metadata=metadata, 
                           title=title, enable_embedding=enable_embedding)

        if args.format == "json":
            print(json.dumps({"frame_id": frame_id}))
        else:
            print(f"✅ Added entry {frame_id}")


def _handle_add(args):
    """Add content to a memory file."""
    path = args.path
    text = args.text
    file_path = args.file

    if not text and not file_path:
        print("Error: Provide --text or --file", file=sys.stderr)
        sys.exit(1)

    if text is not None and text.strip() == "":
        print("Error: Text cannot be empty", file=sys.stderr)
        sys.exit(1)

    try:
        # Use SafeMemoryStore if agent_id is provided for concurrent safety
        if getattr(args, 'agent_id', None):
            from ate.memory.concurrency.safe_store import SafeMemoryStore
            from ate.memory.concurrency.lock import LockError
            
            wait_seconds = getattr(args, 'wait', 10.0)
            lock_timeout = getattr(args, 'lock_timeout', 30.0)
            
            try:
                with SafeMemoryStore.open(path, args.agent_id, writable=True,
                                        wait_seconds=wait_seconds, 
                                        lock_timeout=lock_timeout) as store:
                    _execute_add_logic(args, store)
            except LockError as e:
                print(f"Error: {e}", file=sys.stderr)
                sys.exit(1)
        else:
            # Use regular MemoryStore (backward compatible)
            with MemoryStore.open(path) as store:
                _execute_add_logic(args, store)
    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(2)


def _handle_search(args):
    """Search memory."""
    path = args.path
    query = args.query
    top_k = args.top_k
    engine = args.engine

    if not query.strip():
        print("Error: Query cannot be empty", file=sys.stderr)
        sys.exit(1)

    try:
        with MemoryStore.open(path) as store:
            results = store.search(query, top_k=top_k, engine=engine)

            if args.format == "json":
                out = {
                    "query": query,
                    "results": [
                        {
                            "frame_id": r.frame_id,
                            "text": r.text,
                            "title": r.title,
                            "score": r.score,
                            "tags": r.tags,
                            "metadata": r.metadata,
                            "engine": r.engine,
                        }
                        for r in results
                    ],
                }
                print(json.dumps(out))
            else:
                if not results:
                    print("No results found.")
                else:
                    print(f"🔍 {len(results)} result(s) for \"{query}\":\n")
                    for i, r in enumerate(results, 1):
                        title_str = f" — {r.title}" if r.title else ""
                        print(f"  {i}. [{r.score:.2f}] {r.text}{title_str}")
                        if r.tags:
                            print(f"     Tags: {', '.join(r.tags)}")
    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(2)


def _handle_info(args):
    """Show memory store statistics."""
    path = args.path
    try:
        with MemoryStore.open(path) as store:
            info = store.info()

            if args.format == "json":
                print(json.dumps({
                    "path": info.path,
                    "frame_count": info.frame_count,
                    "size_bytes": info.size_bytes,
                    "has_lex_index": info.has_lex_index,
                    "has_vec_index": info.has_vec_index,
                    "has_time_index": info.has_time_index,
                    "created_at": getattr(info, "created_at", None),
                }))
            else:
                size_kb = info.size_bytes / 1024
                print(f"📦 Memory: {info.path}")
                print(f"   Frames:     {info.frame_count}")
                print(f"   Size:       {size_kb:.1f} KB")
                print(f"   Lex index:  {'✅' if info.has_lex_index else '❌'}")
                print(f"   Vec index:  {'✅' if info.has_vec_index else '❌'}")
                print(f"   Time index: {'✅' if info.has_time_index else '❌'}")
    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(2)


def _handle_export(args):
    """Export memory content to JSONL or Markdown."""
    path = args.path
    output = args.output
    try:
        if args.format == "markdown":
            # Markdown export — reconstruct .md from frames
            import tempfile
            from ate.memory.markdown import sections_to_markdown, MarkdownSection

            # Export to temp JSONL, then parse into sections
            with tempfile.NamedTemporaryFile(mode="w", suffix=".jsonl",
                                             delete=False) as tmp:
                tmp_path = tmp.name

            try:
                with MemoryStore.open(path) as store:
                    store.export_jsonl(tmp_path)

                sections = []
                with open(tmp_path, "r", encoding="utf-8") as f:
                    for line in f:
                        line = line.strip()
                        if line:
                            entry = json.loads(line)
                            sections.append(MarkdownSection(
                                title=entry.get("title", "Untitled"),
                                text=entry.get("text", ""),
                                tags=entry.get("tags", []),
                                metadata=entry.get("metadata", {}),
                            ))
            finally:
                os.unlink(tmp_path)

            md_content = sections_to_markdown(sections)

            with open(output, "w", encoding="utf-8") as f:
                f.write(md_content)

            print(f"✅ Exported {len(sections)} sections to {output} (markdown)")
        else:
            with MemoryStore.open(path) as store:
                count = store.export_jsonl(output)

                if args.format == "json":
                    print(json.dumps({"output": output, "count": count}))
                else:
                    print(f"✅ Exported {count} entries to {output}")
    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(2)


def _handle_merge(args):
    """Merge multiple .mv2 files."""
    source_paths = args.paths
    output = args.output
    dedup = not args.no_dedup

    try:
        info = merge_memories(source_paths, output, dedup=dedup)

        if args.format == "json":
            print(json.dumps({
                "output": info.path,
                "frame_count": info.frame_count,
                "size_bytes": info.size_bytes,
                "dedup": dedup,
            }))
        else:
            print(f"✅ Merged {len(source_paths)} files → {info.path}")
            print(f"   Frames: {info.frame_count}")
            print(f"   Size:   {info.size_bytes / 1024:.1f} KB")
            if dedup:
                print(f"   Dedup:  enabled")
    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(2)


# ---------------------------------------------------------------------------
# Context-aware handlers (think / recall / train / status / new / use / list-memories)
# ---------------------------------------------------------------------------

def _handle_think(args):
    """Add a thought to active memory."""
    text = args.text
    memory_path = getattr(args, 'memory', None)
    
    if not text.strip():
        print("Error: Text cannot be empty", file=sys.stderr)
        sys.exit(1)

    try:
        with MemoryStore.from_context_or_path(memory_path) as store:
            tags = [t.strip() for t in args.tags.split(",")] if args.tags else None
            metadata = json.loads(args.metadata) if args.metadata else None
            title = args.title
            enable_embedding = True if args.embed else None

            frame_id = store.add(text=text, tags=tags, metadata=metadata, 
                               title=title, enable_embedding=enable_embedding)

            if args.format == "json":
                # Get current context for output
                from ate.memory.context import ContextManager
                context = ContextManager.get_context()
                print(json.dumps({
                    "frame_id": frame_id, 
                    "memory": context.active_memory,
                    "train": context.active_train
                }))
            else:
                print(f"💭 Stored thought (frame {frame_id})")
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(2)


def _handle_recall(args):
    """Search active memory."""
    query = args.query
    memory_path = getattr(args, 'memory', None)
    top_k = args.top_k
    engine = args.engine

    if not query.strip():
        print("Error: Query cannot be empty", file=sys.stderr)
        sys.exit(1)

    try:
        # TODO: Implement --all-trains functionality
        if getattr(args, 'all_trains', False):
            print("Error: --all-trains not yet implemented", file=sys.stderr)
            sys.exit(1)

        with MemoryStore.from_context_or_path(memory_path) as store:
            results = store.search(query, top_k=top_k, engine=engine)

            if args.format == "json":
                # Get current context for output
                from ate.memory.context import ContextManager
                context = ContextManager.get_context()
                out = {
                    "query": query,
                    "memory": context.active_memory,
                    "train": context.active_train,
                    "results": [
                        {
                            "frame_id": r.frame_id,
                            "text": r.text,
                            "title": r.title,
                            "score": r.score,
                            "tags": r.tags,
                            "metadata": r.metadata,
                            "engine": r.engine,
                        }
                        for r in results
                    ],
                }
                print(json.dumps(out))
            else:
                if not results:
                    print("🔍 No results found.")
                else:
                    print(f"🔍 {len(results)} result(s) for \"{query}\":\n")
                    for i, r in enumerate(results, 1):
                        title_str = f" — {r.title}" if r.title else ""
                        print(f"  {i}. [{r.score:.2f}] {r.text}{title_str}")
                        if r.tags:
                            print(f"     Tags: {', '.join(r.tags)}")
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(2)


def _handle_train(args):
    """Manage trains of thought."""
    from ate.memory.context import ContextManager
    
    try:
        # List trains if no name provided
        if not args.name:
            context = ContextManager.get_context()
            trains = ContextManager.list_trains(context.active_memory)
            
            if args.format == "json":
                print(json.dumps({
                    "memory": context.active_memory,
                    "trains": trains,
                    "active": context.active_train
                }))
            else:
                print(f"🚂 Trains of thought in \"{context.active_memory}\":")
                for train in trains:
                    marker = " ← active" if train == context.active_train else ""
                    print(f"  {'→' if train == context.active_train else ' '} {train}{marker}")
            return

        # Handle delete
        if args.delete:
            print("Error: --delete not yet implemented", file=sys.stderr)
            sys.exit(1)

        # Handle rename
        if args.rename:
            print("Error: --rename not yet implemented", file=sys.stderr)
            sys.exit(1)

        # Switch to train
        context = ContextManager.get_context()
        new_context = ContextManager.set_context(context.active_memory, args.name)
        
        if args.format == "json":
            print(json.dumps({
                "memory": new_context.active_memory,
                "train": new_context.active_train,
                "path": new_context.path
            }))
        else:
            print(f"🚂 Switched to train \"{args.name}\"")
            
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(2)


def _handle_status(args):
    """Show current memory context."""
    from ate.memory.context import ContextManager
    
    try:
        context = ContextManager.get_context()
        
        # Get memory info
        with MemoryStore.open(context.path) as store:
            info = store.info()

        if args.format == "json":
            print(json.dumps({
                "memory": context.active_memory,
                "train": context.active_train,
                "frames": info.frame_count,
                "size_bytes": info.size_bytes,
                "has_vec_index": info.has_vec_index,
                "has_lex_index": info.has_lex_index,
                "has_time_index": info.has_time_index,
                "path": context.path,
                "visibility": "private"  # Default for now
            }))
        else:
            size_kb = info.size_bytes / 1024
            print(f"🧠 Memory: {context.active_memory} (private)")
            print(f"🚂 Train:  {context.active_train}")
            print(f"📦 Frames: {info.frame_count} ({size_kb:.1f} KB)")
            print(f"🔍 Search: {'lex' if info.has_lex_index else ''}" + 
                  f"{' + vec' if info.has_vec_index else ''}")
            print(f"📁 Path:   {context.path}")
            
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(2)


def _handle_new(args):
    """Create a new memory."""
    from ate.memory.context import ContextManager
    
    try:
        path = ContextManager.ensure_memory(args.name)
        
        # Update memory.json with description if provided
        if args.description:
            memory_dir = os.path.dirname(path)
            memory_json_path = os.path.join(memory_dir, "memory.json")
            
            with open(memory_json_path, 'r') as f:
                data = json.load(f)
            data["description"] = args.description
            with open(memory_json_path, 'w') as f:
                json.dump(data, f, indent=2)
        
        if args.format == "json":
            print(json.dumps({
                "name": args.name,
                "path": path,
                "description": args.description,
                "created": True
            }))
        else:
            print(f"✅ Created memory \"{args.name}\"")
            if args.description:
                print(f"   Description: {args.description}")
                
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(2)


def _handle_use(args):
    """Switch to a different memory."""
    from ate.memory.context import ContextManager
    
    try:
        # Verify memory exists
        memories = ContextManager.list_memories()
        memory_names = [m.name for m in memories]
        
        if args.name not in memory_names:
            print(f"Error: Memory '{args.name}' does not exist. Use 'ate memory list-memories' to see available memories.", file=sys.stderr)
            sys.exit(1)
        
        # Find the default train for this memory
        memory_metadata = next(m for m in memories if m.name == args.name)
        default_train = memory_metadata.default_train
        
        context = ContextManager.set_context(args.name, default_train)
        
        if args.format == "json":
            print(json.dumps({
                "memory": context.active_memory,
                "train": context.active_train,
                "path": context.path
            }))
        else:
            print(f"🧠 Switched to memory \"{args.name}\"")
            
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(2)


def _handle_list_memories(args):
    """List all local memories."""
    from ate.memory.context import ContextManager
    
    try:
        memories = ContextManager.list_memories()
        
        if args.format == "json":
            print(json.dumps({
                "memories": [
                    {
                        "name": m.name,
                        "visibility": m.visibility,
                        "trains": m.trains,
                        "default_train": m.default_train,
                        "description": m.description,
                        "created_at": m.created_at,
                        "remote": m.remote
                    }
                    for m in memories
                ]
            }))
        else:
            if not memories:
                print("No local memories found.")
                print("Create one with: ate memory new <name>")
            else:
                print(f"🧠 {len(memories)} local memor{'y' if len(memories) == 1 else 'ies'}:")
                for memory in memories:
                    trains_str = f"{len(memory.trains)} train{'s' if len(memory.trains) != 1 else ''}"
                    desc_str = f" — {memory.description}" if memory.description else ""
                    print(f"  • {memory.name} ({trains_str}){desc_str}")
                    
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(2)


# ---------------------------------------------------------------------------
# Cloud handlers (push / pull / list / delete)
# ---------------------------------------------------------------------------

def _get_cloud_client(args=None):
    """Create a CloudClient with token from TokenStore.

    Exits with code 1 if no valid token is found.
    """
    store = TokenStore()
    token_resp = store.load()
    if token_resp is None:
        print("Error: Not authenticated. Run: ate device-login", file=sys.stderr)
        sys.exit(1)
    return CloudClient(token=token_resp.access_token)


def _parse_ref(ref: str) -> str:
    """Parse a reference to extract the memory name.

    Accepts:
      - "research" → "research"
      - "kindly/research" → "research"  (backward compat: project/name)
      - "kindly/memories/test" → "test"  (backward compat: project/sub/name)

    Returns the memory name (last path component).
    """
    if "/" in ref:
        return ref.rsplit("/", 1)[1]
    return ref


def _handle_push(args):
    """Upload .mv2 file to cloud."""
    client = _get_cloud_client(args)

    # Resolve memory name: explicit --name or derive from filename
    resolved_name = args.name
    if not resolved_name:
        basename = os.path.basename(args.path)
        resolved_name = os.path.splitext(basename)[0]

    try:
        result = client.push(
            args.path,
            name=resolved_name,
            train_name=getattr(args, "train", "main") or "main",
            description=getattr(args, "description", None),
            visibility=getattr(args, "visibility", "private") or "private",
        )

        if args.format == "json":
            print(json.dumps(asdict(result)))
        else:
            print(f"✅ Pushed {result.memory_name} (train: {result.train_name})")
            print(f"   Memory ID: {result.memory_id}")
            print(f"   Train ID:  {result.train_id}")
            print(f"   Size:      {result.size_bytes} bytes")
    except CloudAuthError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except (CloudNotFoundError, CloudForbiddenError) as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except CloudError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(2)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(2)


def _handle_pull(args):
    """Download .mv2 file from cloud."""
    client = _get_cloud_client(args)
    name = _parse_ref(args.ref)
    try:
        result = client.pull(
            name=name,
            output_path=args.output,
            train_name=getattr(args, "train", None),
        )

        if args.format == "json":
            print(json.dumps(asdict(result)))
        else:
            print(f"✅ Pulled {result.memory_name} (train: {result.train_name})")
            print(f"   Saved: {result.path}")
            print(f"   Size:  {result.size_bytes} bytes")
    except CloudNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except CloudAuthError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except (CloudForbiddenError,) as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except CloudError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(2)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(2)


def _handle_list(args):
    """List cloud memories."""
    client = _get_cloud_client(args)
    try:
        items = client.list()

        if args.format == "json":
            print(json.dumps({
                "memories": [asdict(item) for item in items],
            }))
        else:
            if not items:
                print("No memories found in cloud.")
            else:
                print(f"☁️  {len(items)} memor{'y' if len(items) == 1 else 'ies'} in cloud:\n")
                for item in items:
                    size_kb = item.total_size / 1024
                    trains = f"{item.train_count} train{'s' if item.train_count != 1 else ''}"
                    vis = f" [{item.visibility}]" if item.visibility != "private" else ""
                    desc = f" — {item.description}" if item.description else ""
                    print(f"  • {item.name}  ({trains}, {size_kb:.1f} KB){vis}{desc}")
    except CloudAuthError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except (CloudForbiddenError,) as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except CloudError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(2)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(2)


def _handle_delete(args):
    """Delete a memory from cloud."""
    client = _get_cloud_client(args)
    name = _parse_ref(args.ref)
    try:
        client.delete(name=name)

        if args.format == "json":
            print(json.dumps({"name": name, "deleted": True}))
        else:
            print(f"✅ Deleted memory '{name}'")
    except CloudNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except CloudAuthError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except (CloudForbiddenError,) as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except CloudError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(2)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(2)


def _handle_providers(args):
    """List detected embedding providers."""
    try:
        providers = EmbeddingManager.available_providers()
        
        # Determine active provider
        active_config = EmbeddingManager.detect()
        active = active_config.provider if active_config.provider != "none" else None
        
        if args.format == "json":
            print(json.dumps({
                "providers": providers,
                "active": active
            }))
        else:
            print("🤖 Embedding Providers:\n")
            for provider in providers:
                status = "✅" if provider["available"] else "❌"
                name = provider["name"]
                
                if provider["available"]:
                    model = provider.get("model", "default")
                    source = provider.get("source", "unknown")
                    print(f"  {status} {name} ({model}) - {source}")
                else:
                    reason = provider.get("reason", "unknown")
                    print(f"  {status} {name} - {reason}")
            
            if active:
                print(f"\n🎯 Active provider: {active}")
            else:
                print(f"\n⚠️ No embedding providers available - using BM25 lexical search only")
                
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(2)


# ---------------------------------------------------------------------------
# Crypto handlers (keygen / keys / sign / verify / audit / seal / unseal)
# ---------------------------------------------------------------------------

def _handle_keygen(args):
    """Generate a new Ed25519 or X25519 keypair."""
    try:
        if args.type == "ed25519":
            from ate.memory.crypto.signing import KeyManager
            keypair = KeyManager.generate(args.name)
            fingerprint = KeyManager.fingerprint(keypair.public_key)
        else:  # x25519
            from ate.memory.crypto.encryption import X25519KeyManager
            keypair = X25519KeyManager.generate(args.name)
            fingerprint = X25519KeyManager.fingerprint(keypair.public_key)
            
    except ImportError:
        print("Crypto features require: pip install cryptography", file=sys.stderr)
        sys.exit(2)
    except FileExistsError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(2)

    if args.format == "json":
        print(json.dumps({
            "name": args.name,
            "type": args.type,
            "fingerprint": fingerprint
        }))
    else:
        print(f"✅ Generated {args.type} keypair '{args.name}'")
        print(f"   Fingerprint: {fingerprint}")


def _handle_keys(args):
    """List available keys and fingerprints."""
    try:
        from ate.memory.crypto.signing import KeyManager
        from ate.memory.crypto.encryption import X25519KeyManager
        
        ed25519_keys = KeyManager.list_keys()
        x25519_keys = X25519KeyManager.list_keys()
        
        keys = []
        
        # Add Ed25519 keys
        for name in ed25519_keys:
            try:
                public_key = KeyManager.load_public(name)
                fingerprint = KeyManager.fingerprint(public_key)
                keys.append({
                    "name": name,
                    "type": "ed25519",
                    "fingerprint": fingerprint
                })
            except Exception:
                pass  # Skip broken keys
        
        # Add X25519 keys
        for name in x25519_keys:
            try:
                public_key = X25519KeyManager.load_public(name)
                fingerprint = X25519KeyManager.fingerprint(public_key)
                keys.append({
                    "name": name,
                    "type": "x25519", 
                    "fingerprint": fingerprint
                })
            except Exception:
                pass  # Skip broken keys
                
    except ImportError:
        print("Crypto features require: pip install cryptography", file=sys.stderr)
        sys.exit(2)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(2)

    if args.format == "json":
        print(json.dumps({"keys": keys}))
    else:
        if not keys:
            print("No keys found.")
            print("Generate one with: ate memory keygen --name mykey")
        else:
            print(f"🔑 {len(keys)} key{'s' if len(keys) != 1 else ''}:")
            for key in keys:
                print(f"  {key['type']:<8} {key['name']:<12} {key['fingerprint']}")


def _handle_sign(args):
    """Sign active memory with Ed25519."""
    try:
        from ate.memory.crypto.signing import KeyManager, MemorySigner
        from ate.memory.context import ContextManager
        
        # Get memory path
        if hasattr(args, 'path') and args.path:
            mv2_path = args.path
            # For direct path, we don't have context info
            memory_name = os.path.basename(mv2_path)
        else:
            context = ContextManager.get_context()
            mv2_path = context.path
            memory_name = context.active_memory
        
        # Load key
        try:
            keypair = KeyManager.load(args.key)
        except FileNotFoundError:
            if args.format == "json":
                print(json.dumps({"error": f"Key '{args.key}' not found"}))
            else:
                print(f"Error: Key '{args.key}' not found", file=sys.stderr)
            sys.exit(1)
        
        # Sign memory
        sig_info = MemorySigner.sign(mv2_path, keypair)
        
    except ImportError:
        print("Crypto features require: pip install cryptography", file=sys.stderr)
        sys.exit(2)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(2)

    if args.format == "json":
        print(json.dumps({
            "memory": memory_name,
            "path": mv2_path,
            "signer": args.key,
            "fingerprint": sig_info.signer_id,
            "file_hash": sig_info.file_hash
        }))
    else:
        print(f"✅ Signed memory '{memory_name}'")
        print(f"   Key: {args.key}")
        print(f"   Fingerprint: {sig_info.signer_id}")


def _handle_verify(args):
    """Verify signature of active memory."""
    try:
        from ate.memory.crypto.signing import KeyManager, MemorySigner
        from ate.memory.context import ContextManager
        
        # Get memory path
        if hasattr(args, 'path') and args.path:
            mv2_path = args.path
            memory_name = os.path.basename(mv2_path)
        else:
            context = ContextManager.get_context()
            mv2_path = context.path
            memory_name = context.active_memory
        
        # Check if signature exists
        if not MemorySigner.has_signature(mv2_path):
            if args.format == "json":
                print(json.dumps({"error": "No signature found", "valid": False}))
            else:
                print("Error: No signature found", file=sys.stderr)
            sys.exit(1)
        
        # Load expected public key if provided
        expected_public_key = None
        if args.fingerprint:
            # args.fingerprint is a fingerprint, we need to find the matching public key
            keys = KeyManager.list_keys()
            for name in keys:
                try:
                    public_key = KeyManager.load_public(name)
                    fingerprint = KeyManager.fingerprint(public_key)
                    if fingerprint == args.fingerprint:
                        expected_public_key = public_key
                        break
                except Exception:
                    continue
            
            if expected_public_key is None:
                if args.format == "json":
                    print(json.dumps({"error": f"Key with fingerprint '{args.fingerprint}' not found", "valid": False}))
                else:
                    print(f"Error: Key with fingerprint '{args.fingerprint}' not found", file=sys.stderr)
                sys.exit(1)
        
        # Verify signature
        sig_info = MemorySigner.verify(mv2_path, expected_public_key)
        
    except ImportError:
        print("Crypto features require: pip install cryptography", file=sys.stderr)
        sys.exit(2)
    except FileNotFoundError as e:
        if args.format == "json":
            print(json.dumps({"error": str(e), "valid": False}))
        else:
            print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(2)

    if args.format == "json":
        print(json.dumps({
            "memory": memory_name,
            "path": mv2_path,
            "valid": sig_info.valid,
            "signer_id": sig_info.signer_id,
            "file_hash": sig_info.file_hash
        }))
    else:
        if sig_info.valid:
            print(f"✅ Signature valid")
            print(f"   Memory: {memory_name}")
            print(f"   Signer: {sig_info.signer_id}")
        else:
            print(f"❌ Signature invalid")
            print(f"   Memory: {memory_name}")
            print(f"   Signer: {sig_info.signer_id}")

    # Exit with 1 if verification failed
    if not sig_info.valid:
        sys.exit(1)


def _handle_audit(args):
    """Verify integrity chain of active memory."""
    try:
        from ate.memory.crypto.integrity import IntegrityChain
        from ate.memory.context import ContextManager
        
        # Get memory path
        if hasattr(args, 'path') and args.path:
            mv2_path = args.path
            memory_name = os.path.basename(mv2_path)
        else:
            context = ContextManager.get_context()
            mv2_path = context.path
            memory_name = context.active_memory
        
        # Check if chain file exists
        chain_path = mv2_path + ".chain"
        if not os.path.exists(chain_path):
            if args.format == "json":
                print(json.dumps({"error": "No integrity chain found", "valid": False}))
            else:
                print("No integrity chain found", file=sys.stderr)
            sys.exit(1)
        
        # Load integrity chain
        chain = IntegrityChain.for_memory(mv2_path)
        audit_result = chain.audit()
        
    except ImportError:
        print("Crypto features require: pip install cryptography", file=sys.stderr)
        sys.exit(2)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(2)

    if args.format == "json":
        print(json.dumps({
            "memory": memory_name,
            "path": mv2_path,
            "valid": audit_result.valid,
            "total_entries": audit_result.total_entries,
            "verified_entries": audit_result.verified_entries,
            "broken_at": audit_result.broken_at,
            "root_hash": audit_result.root_hash
        }))
    else:
        print(f"🔍 Integrity audit: {memory_name}")
        if audit_result.valid:
            print(f"✅ Chain valid ({audit_result.total_entries} entries)")
        else:
            print(f"❌ Chain broken at entry {audit_result.broken_at}")
            print(f"   Verified: {audit_result.verified_entries}/{audit_result.total_entries}")
        
        if args.verbose:
            print(f"   Root hash: {audit_result.root_hash}")

    # Exit with 1 if audit failed
    if not audit_result.valid:
        sys.exit(1)


def _handle_seal(args):
    """Encrypt active memory with passphrase."""
    try:
        from ate.memory.crypto.encryption import MemoryEncryptor
        from ate.memory.context import ContextManager
        
        # Get memory path
        if hasattr(args, 'path') and args.path:
            mv2_path = args.path
            memory_name = os.path.basename(mv2_path)
        else:
            context = ContextManager.get_context()
            mv2_path = context.path
            memory_name = context.active_memory
        
        # Check if already encrypted (after seal, .mv2 is deleted and .enc exists)
        enc_path = mv2_path + ".enc"
        if not os.path.exists(mv2_path) and os.path.exists(enc_path):
            if args.format == "json":
                print(json.dumps({"error": "Memory is already encrypted"}))
            else:
                print("Error: Memory is already encrypted", file=sys.stderr)
            sys.exit(1)
        
        # Encrypt memory
        seal_result = MemoryEncryptor.seal_with_passphrase(mv2_path, args.passphrase)
        
    except ImportError:
        print("Crypto features require: pip install cryptography", file=sys.stderr)
        sys.exit(2)
    except ValueError as e:
        if args.format == "json":
            print(json.dumps({"error": str(e)}))
        else:
            print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(2)

    if args.format == "json":
        print(json.dumps({
            "memory": memory_name,
            "encrypted_path": seal_result.encrypted_path,
            "algorithm": seal_result.algorithm,
            "kdf": seal_result.kdf,
            "original_hash": seal_result.original_hash
        }))
    else:
        print(f"🔒 Sealed memory '{memory_name}'")
        print(f"   Encrypted: {seal_result.encrypted_path}")
        print(f"   Algorithm: {seal_result.algorithm}")


def _handle_unseal(args):
    """Decrypt active memory."""
    try:
        from ate.memory.crypto.encryption import MemoryEncryptor
        from ate.memory.context import ContextManager
        
        # Get memory path and determine enc path
        if hasattr(args, 'path') and args.path:
            mv2_path = args.path
            memory_name = os.path.basename(mv2_path)
        else:
            context = ContextManager.get_context()
            mv2_path = context.path
            memory_name = context.active_memory
            
        # Determine encrypted file path
        enc_path = mv2_path + ".enc"
        
        # Check if encrypted
        if not MemoryEncryptor.is_encrypted(enc_path):
            if args.format == "json":
                print(json.dumps({"error": "Memory is not encrypted"}))
            else:
                print("Error: Memory is not encrypted", file=sys.stderr)
            sys.exit(1)
        
        # Decrypt memory
        unseal_result = MemoryEncryptor.unseal_with_passphrase(enc_path, args.passphrase)
        
    except ImportError:
        print("Crypto features require: pip install cryptography", file=sys.stderr)
        sys.exit(2)
    except ValueError as e:
        if args.format == "json":
            print(json.dumps({"error": str(e)}))
        else:
            print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(2)

    if args.format == "json":
        print(json.dumps({
            "memory": memory_name,
            "decrypted_path": unseal_result.decrypted_path,
            "original_hash": unseal_result.original_hash,
            "verified": unseal_result.verified
        }))
    else:
        print(f"🔓 Unsealed memory '{memory_name}'")
        print(f"   Decrypted: {unseal_result.decrypted_path}")
        if unseal_result.verified:
            print(f"   ✅ Hash verified")
        else:
            print(f"   ❌ Hash verification failed")


# ---------------------------------------------------------------------------
# Concurrency handlers
# ---------------------------------------------------------------------------

def _handle_lock_status(args):
    """Show lock status of a memory file."""
    import time
    from ate.memory.concurrency.lock import LockManager

    path = getattr(args, 'path', None)
    if not path:
        from ate.memory.context import ContextManager
        context = ContextManager.get_context()
        path = context.path

    try:
        lock_info = LockManager.status(path)

        if getattr(args, 'format', None) == "json":
            if lock_info:
                is_stale = LockManager.is_stale(path)
                print(json.dumps({
                    "status": "locked",
                    "agent_id": lock_info.agent_id,
                    "mode": lock_info.mode,
                    "pid": lock_info.pid,
                    "acquired_at": lock_info.acquired_at,
                    "timeout_seconds": lock_info.timeout_seconds,
                    "heartbeat_at": lock_info.heartbeat_at,
                    "stale": is_stale,
                    "duration_seconds": round(time.time() - lock_info.acquired_at, 1)
                }))
            else:
                print(json.dumps({"status": "unlocked"}))
        else:
            if lock_info:
                is_stale = LockManager.is_stale(path)
                duration = time.time() - lock_info.acquired_at
                stale_str = " (STALE)" if is_stale else ""
                print(f"🔒 Lock held by: {lock_info.agent_id}")
                print(f"   Mode: {lock_info.mode}")
                print(f"   PID: {lock_info.pid}")
                print(f"   Duration: {duration:.1f}s{stale_str}")
            else:
                print("🔓 No active lock")
    except Exception as e:
        if getattr(args, 'format', None) == "json":
            print(json.dumps({"error": str(e)}))
        else:
            print(f"Error: {e}", file=sys.stderr)
        sys.exit(2)


def _handle_force_unlock(args):
    """Force-release a lock on a memory file."""
    from ate.memory.concurrency.lock import LockManager

    path = getattr(args, 'path', None)
    if not path:
        from ate.memory.context import ContextManager
        context = ContextManager.get_context()
        path = context.path

    try:
        released = LockManager.force_release(path)

        if getattr(args, 'format', None) == "json":
            print(json.dumps({"released": released, "path": path}))
        else:
            if released:
                print(f"🔓 Lock released for {path}")
            else:
                print(f"🔓 No lock to release for {path}")
    except Exception as e:
        if getattr(args, 'format', None) == "json":
            print(json.dumps({"error": str(e)}))
        else:
            print(f"Error: {e}", file=sys.stderr)
        sys.exit(2)


# ---------------------------------------------------------------------------
# Import handler
# ---------------------------------------------------------------------------

def _handle_import(args):
    """Import a Markdown file into a .mv2 memory store."""
    md_path = getattr(args, "markdown", None)
    if not md_path:
        print("Error: --markdown is required", file=sys.stderr)
        sys.exit(1)

    if not os.path.isfile(md_path):
        print(f"Error: File not found: {md_path}", file=sys.stderr)
        sys.exit(1)

    # Lazy import to avoid loading at module level
    from ate.memory.markdown import parse_markdown

    # Read and parse the markdown
    with open(md_path, "r", encoding="utf-8") as f:
        content = f.read()

    source_file = os.path.basename(md_path)
    sections = parse_markdown(content, source_file=source_file)

    if not sections:
        print("Error: No sections found in markdown file", file=sys.stderr)
        sys.exit(1)

    mv2_path = args.path
    clear = getattr(args, "clear", False)

    # Create or recreate the .mv2 file — close the returned store
    # so we can reopen it (or use SafeMemoryStore) below
    if not os.path.isfile(mv2_path) or clear:
        created_store = MemoryStore.create(mv2_path)
        created_store.close()

    # Convert sections to dicts for add_batch
    batch = [s.to_dict() for s in sections]

    # Add sections to the store
    def _do_import(store):
        frame_ids = store.add_batch(batch)
        if args.format == "json":
            print(json.dumps({
                "count": len(frame_ids),
                "sections": [{"title": s.title, "tags": s.tags} for s in sections],
            }))
        else:
            print(f"✅ Imported {len(frame_ids)} sections from {source_file} into {mv2_path}")

    try:
        if getattr(args, "agent_id", None):
            try:
                from ate.memory.concurrency.safe_store import SafeMemoryStore
                from ate.memory.concurrency.lock import LockError
            except (ImportError, NameError, AttributeError):
                print("Error: Concurrency dependencies not available", file=sys.stderr)
                sys.exit(2)

            wait_seconds = getattr(args, "wait", 10.0)
            lock_timeout = getattr(args, "lock_timeout", 30.0)

            try:
                with SafeMemoryStore.open(mv2_path, args.agent_id, writable=True,
                                          wait_seconds=wait_seconds,
                                          lock_timeout=lock_timeout) as store:
                    _do_import(store)
            except LockError as e:
                print(f"Error: {e}", file=sys.stderr)
                sys.exit(1)
        else:
            with MemoryStore.open(mv2_path) as store:
                _do_import(store)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(2)


# ---------------------------------------------------------------------------
# Capsule handlers
# ---------------------------------------------------------------------------

def _handle_capsule(args):
    """Handle capsule subcommands.""" 
    action = getattr(args, "capsule_action", None)
    if action == "create":
        capsule_create(args)
    elif action == "inspect":
        capsule_inspect(args)
    elif action == "ingest":
        capsule_ingest(args)
    elif action == "extract":
        capsule_extract(args)
    else:
        print("Usage: ate memory capsule {create|inspect|ingest|extract}", file=sys.stderr)
        sys.exit(1)


def capsule_create(args):
    """Create a memory capsule."""
    from ate.memory.capsule.builder import CapsuleBuilder
    
    if not args.memory:
        raise ValueError("At least one --memory file is required")
    
    try:
        # Parse tags
        tags = []
        if hasattr(args, 'tags') and args.tags:
            if isinstance(args.tags, str):
                tags = [tag.strip() for tag in args.tags.split(",") if tag.strip()]
            else:
                tags = args.tags
        
        # Initialize builder
        builder = CapsuleBuilder(args.name, "", args.description, args.license)
        
        # Add memories
        for memory_path in args.memory:
            builder.add_memory(memory_path, include_sig=True, include_chain=True)
        
        # Add trains
        for train_spec in args.train:
            if ":" in train_spec:
                train_path, train_name = train_spec.split(":", 1)
                builder.add_train(train_path, train_name)
            else:
                builder.add_train(train_spec)
        
        # Set options
        if args.description:
            builder.set_description(args.description)
        
        if tags:
            builder.add_tags(tags)
        
        if args.sign:
            builder.sign(args.sign)
        
        # Handle README
        if args.readme:
            if args.readme.startswith("@"):
                # Read from file
                readme_path = args.readme[1:]
                with open(readme_path, "r", encoding="utf-8") as f:
                    readme_text = f.read()
                builder.add_readme(readme_text)
            else:
                # Use as literal text
                builder.add_readme(args.readme)
        
        # Build capsule
        result = builder.build(args.output)
        
        if args.format == "json":
            output = {
                "path": result.path,
                "name": result.name,
                "total_memories": result.total_memories,
                "total_trains": result.total_trains,
                "size_bytes": result.size_bytes,
                "signed": result.signed
            }
            print(json.dumps(output))
        else:
            print(f"✅ Created capsule: {result.path}")
            print(f"   Name: {result.name}")
            print(f"   Memories: {result.total_memories}")
            print(f"   Trains: {result.total_trains}")
            print(f"   Size: {result.size_bytes} bytes")
            if result.signed:
                print("   🔒 Signed")
    
    except Exception as e:
        if args.format == "json":
            print(json.dumps({"error": str(e)}))
        else:
            print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def capsule_inspect(args):
    """Inspect a memory capsule."""
    from ate.memory.capsule.reader import CapsuleReader
    
    try:
        info = CapsuleReader.inspect(args.capsule_path, verify_key=args.verify)
        
        if args.format == "json":
            output = {
                "manifest": {
                    "name": info.manifest.name,
                    "author": info.manifest.author,
                    "description": info.manifest.description,
                    "format_version": info.manifest.format_version,
                    "created_at": info.manifest.created_at,
                    "tags": info.manifest.tags,
                    "license": info.manifest.license,
                    "memories": info.manifest.memories,
                    "trains": info.manifest.trains,
                    "signature": info.manifest.signature,
                    "author_fingerprint": info.manifest.author_fingerprint
                },
                "is_valid_zip": info.is_valid_zip,
                "is_signed": info.is_signed,
                "signature_valid": info.signature_valid,
                "total_size_bytes": info.total_size_bytes,
                "file_count": info.file_count
            }
            print(json.dumps(output))
        else:
            print(f"📦 Capsule: {info.manifest.name}")
            print(f"   Author: {info.manifest.author}")
            print(f"   Description: {info.manifest.description}")
            print(f"   Format: {info.manifest.format_version}")
            print(f"   Size: {info.total_size_bytes} bytes")
            print(f"   Files: {info.file_count}")
            print(f"   Memories: {len(info.manifest.memories)}")
            print(f"   Trains: {len(info.manifest.trains)}")
            print(f"   Tags: {', '.join(info.manifest.tags)}")
            print(f"   License: {info.manifest.license}")
            
            if info.is_signed:
                if info.signature_valid is True:
                    print("   🔒 Signature: Valid")
                elif info.signature_valid is False:
                    print("   ❌ Signature: Invalid")
                else:
                    print("   🔒 Signature: Present (not verified)")
            else:
                print("   🔓 Unsigned")
    
    except Exception as e:
        if args.format == "json":
            print(json.dumps({"error": str(e)}))
        else:
            print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def capsule_ingest(args):
    """Ingest a memory capsule."""
    from ate.memory.capsule.ingest import CapsuleIngestor
    
    try:
        result = CapsuleIngestor.ingest(
            args.capsule_path,
            args.target,
            mode=args.mode,
            verify_key=args.verify,
            agent_id=args.agent_id
        )
        
        if args.format == "json":
            output = {
                "memories_ingested": result.memories_ingested,
                "trains_ingested": result.trains_ingested,
                "frames_added": result.frames_added,
                "signature_verified": result.signature_verified,
                "source_author": result.source_author,
                "source_name": result.source_name
            }
            print(json.dumps(output))
        else:
            print(f"✅ Ingested capsule: {result.source_name}")
            print(f"   Author: {result.source_author}")
            print(f"   Memories: {result.memories_ingested}")
            print(f"   Trains: {result.trains_ingested}")
            print(f"   Frames added: {result.frames_added}")
            
            if result.signature_verified is True:
                print("   🔒 Signature verified")
            elif result.signature_verified is False:
                print("   ❌ Signature verification failed")
    
    except Exception as e:
        if args.format == "json":
            print(json.dumps({"error": str(e)}))
        else:
            print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def capsule_extract(args):
    """Extract a memory capsule to directory."""
    from ate.memory.capsule.ingest import CapsuleIngestor
    
    try:
        result = CapsuleIngestor.extract(args.capsule_path, args.output_dir)
        
        if args.format == "json":
            print(json.dumps(result))
        else:
            print(f"✅ Extracted capsule to: {args.output_dir}")
            print(f"   Memories: {len(result['memories'])}")
            print(f"   Trains: {len(result['trains'])}")
            
            if result['manifest']:
                print(f"   Manifest: {os.path.basename(result['manifest'])}")
            if result['readme']:
                print(f"   README: {os.path.basename(result['readme'])}")
    
    except Exception as e:
        if args.format == "json":
            print(json.dumps({"error": str(e)}))
        else:
            print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
