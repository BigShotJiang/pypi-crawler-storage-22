"""
Parts catalog commands for FoodforThought CLI.

Commands:
- ate parts list     - List available parts
- ate parts check    - Check part compatibility for skill
- ate parts require  - Add part dependency to skill
"""

import sys
from typing import Optional


def parts_list(client, category: Optional[str], manufacturer: Optional[str],
               search: Optional[str]) -> None:
    """List available parts."""
    print("Fetching parts catalog...")

    params = {}
    if category:
        params["category"] = category
        print(f"  Category: {category}")
    if manufacturer:
        params["manufacturer"] = manufacturer
        print(f"  Manufacturer: {manufacturer}")
    if search:
        params["search"] = search
        print(f"  Search: {search}")

    try:
        response = client._request("GET", "/parts", params=params)
        parts = response.get("parts", [])
        pagination = response.get("pagination", {})

        if not parts:
            print("\nNo parts found matching criteria.")
            return

        print(f"\n{'=' * 70}")
        print(f"{'Part Name':<30} {'Category':<15} {'Manufacturer':<20}")
        print(f"{'=' * 70}")

        for part in parts:
            name = part.get("name", "")[:28]
            cat = part.get("category", "")[:13]
            mfr = part.get("manufacturer", "")[:18]
            print(f"{name:<30} {cat:<15} {mfr:<20}")

        total = pagination.get("total", len(parts))
        print(f"{'=' * 70}")
        print(f"Showing {len(parts)} of {total} parts")

    except Exception as e:
        print(f"\n✗ Failed to list parts: {e}", file=sys.stderr)
        sys.exit(1)


def parts_check(client, skill_id: str) -> None:
    """Check part compatibility for a skill."""
    print(f"Checking parts for skill: {skill_id}")

    try:
        response = client._request("GET", f"/skills/{skill_id}/parts")

        skill = response.get("skill", {})
        parts = response.get("parts", [])
        summary = response.get("summary", {})
        by_category = response.get("byCategory", {})

        print(f"\nSkill: {skill.get('name', skill_id)}")
        print(f"Type: {skill.get('type', 'unknown')}")

        if not parts:
            print("\n✓ No part dependencies declared for this skill.")
            return

        print(f"\n{'=' * 70}")
        print(f"Part Dependencies ({summary.get('total', 0)} total)")
        print(f"{'=' * 70}")

        for category, cat_parts in by_category.items():
            print(f"\n{category.upper()}:")
            for p in cat_parts:
                part = p.get("part", {})
                required = "REQUIRED" if p.get("required") else "optional"
                version = p.get("minVersion", "any")
                if p.get("maxVersion"):
                    version += f" - {p['maxVersion']}"

                icon = "●" if p.get("required") else "○"
                print(f"  {icon} {part.get('name'):<30} [{required}] v{version}")

        print(f"\n{'=' * 70}")
        print(f"Summary: {summary.get('required', 0)} required, {summary.get('optional', 0)} optional")

    except Exception as e:
        print(f"\n✗ Failed to check parts: {e}", file=sys.stderr)
        sys.exit(1)


def parts_require(client, part_id: str, skill_id: str, version: str,
                  required: bool) -> None:
    """Add part dependency to skill."""
    print(f"Adding part dependency...")
    print(f"  Part ID: {part_id}")
    print(f"  Skill ID: {skill_id}")
    print(f"  Min Version: {version}")
    print(f"  Required: {required}")

    try:
        response = client._request("POST", f"/parts/{part_id}/compatibility", json={
            "skillId": skill_id,
            "minVersion": version,
            "required": required,
        })

        compat = response.get("compatibility", {})
        print(f"\n✓ Part dependency added!")
        print(f"  Compatibility ID: {compat.get('id')}")

    except Exception as e:
        print(f"\n✗ Failed to add part dependency: {e}", file=sys.stderr)
        sys.exit(1)


def register_parser(subparsers):
    """Register parts commands with argparse."""
    parts_parser = subparsers.add_parser("parts", help="Manage hardware parts catalog")
    parts_subparsers = parts_parser.add_subparsers(dest="parts_action", help="Parts action")

    # parts list
    parts_list_parser = parts_subparsers.add_parser("list", help="List available parts")
    parts_list_parser.add_argument("-c", "--category",
                                   choices=["gripper", "sensor", "actuator", "controller",
                                           "end-effector", "camera", "lidar", "force-torque"],
                                   help="Filter by category")
    parts_list_parser.add_argument("-m", "--manufacturer", help="Filter by manufacturer")
    parts_list_parser.add_argument("-s", "--search", help="Search by name or part number")

    # parts check
    parts_check_parser = parts_subparsers.add_parser("check",
                                                     help="Check part compatibility for skill")
    parts_check_parser.add_argument("skill_id", help="Skill ID to check")

    # parts require
    parts_require_parser = parts_subparsers.add_parser("require",
                                                       help="Add part dependency to skill")
    parts_require_parser.add_argument("part_id", help="Part ID to require")
    parts_require_parser.add_argument("-s", "--skill", required=True, help="Skill ID")
    parts_require_parser.add_argument("-v", "--version", default="1.0.0",
                                      help="Minimum version (default: 1.0.0)")
    parts_require_parser.add_argument("--required", action="store_true",
                                      help="Mark as required (not optional)")


def handle(client, args):
    """Handle parts commands."""
    if args.parts_action == "list":
        parts_list(client, args.category, args.manufacturer, args.search)
    elif args.parts_action == "check":
        parts_check(client, args.skill_id)
    elif args.parts_action == "require":
        parts_require(client, args.part_id, args.skill, args.version, args.required)
    else:
        print("Usage: ate parts {list|check|require}")
        sys.exit(1)
