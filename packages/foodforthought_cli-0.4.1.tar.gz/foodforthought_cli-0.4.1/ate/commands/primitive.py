"""
Primitive skills commands for FoodforThought CLI.

Commands:
- ate primitive list     - List primitive skills
- ate primitive get      - Get primitive details
- ate primitive test     - Submit test result for primitive
- ate primitive init     - Initialize primitive skill template
- ate primitive push     - Publish primitive to FoodforThought
- ate primitive deps     - Manage primitive dependencies
"""

import json
import sys
import time
from pathlib import Path
from typing import Optional


def primitive_list(client, robot: Optional[str], category: Optional[str],
                   status: Optional[str], tested: bool) -> None:
    """List primitive skills."""
    print("Fetching primitives...")

    params = {}
    if robot:
        params["robot"] = robot
    if category:
        params["category"] = category
    if status:
        params["status"] = status
    if tested:
        params["status"] = "tested,verified"

    try:
        response = client._request("GET", "/primitives", params=params)
        primitives = response.get("primitives", [])

        if not primitives:
            print("\nNo primitives found.")
            return

        print(f"\n{'=' * 70}")
        print(f"{'Name':<25} {'Category':<15} {'Status':<12} {'Reliability'}")
        print(f"{'=' * 70}")

        for prim in primitives:
            name = prim.get("name", "")[:23]
            cat = prim.get("category", "")[:13]
            prim_status = prim.get("status", "")[:10]
            reliability = prim.get("reliabilityScore", 0)
            reliability_str = f"{reliability:.0%}" if reliability else "N/A"
            print(f"{name:<25} {cat:<15} {prim_status:<12} {reliability_str}")

    except Exception as e:
        print(f"\n✗ Failed to list primitives: {e}", file=sys.stderr)
        sys.exit(1)


def primitive_get(client, primitive_id: str) -> None:
    """Get detailed information about a primitive."""
    try:
        response = client._request("GET", f"/primitives/{primitive_id}")
        prim = response.get("primitive", {})

        print(f"\n{'=' * 60}")
        print(f"Primitive: {prim.get('displayName') or prim.get('name')}")
        print(f"{'=' * 60}")

        print(f"\nCategory: {prim.get('category', '?')}")
        print(f"Status: {prim.get('status', '?')}")

        if prim.get('reliabilityScore'):
            print(f"Reliability: {prim.get('reliabilityScore'):.1%}")

        if prim.get('description'):
            print(f"\nDescription: {prim.get('description')}")

        print(f"\nCommand Type: {prim.get('commandType')}")
        print(f"Command Template:")
        print(f"  {prim.get('commandTemplate')}")

        # Parameters
        params = prim.get('parameters', [])
        if params:
            print(f"\nParameters:")
            for p in params:
                range_str = ""
                if p.get('min') is not None and p.get('max') is not None:
                    range_str = f" (range: {p.get('min')}-{p.get('max')})"
                unit = f" {p.get('unit')}" if p.get('unit') else ""
                default = f", default: {p.get('default')}" if p.get('default') is not None else ""
                print(f"  - {p.get('name')}: {p.get('type')}{range_str}{unit}{default}")

        # Timing
        if any([prim.get('executionTimeMs'), prim.get('settleTimeMs'), prim.get('cooldownMs')]):
            print(f"\nTiming:")
            if prim.get('executionTimeMs'):
                print(f"  Execution: {prim.get('executionTimeMs')}ms")
            if prim.get('settleTimeMs'):
                print(f"  Settle: {prim.get('settleTimeMs')}ms")
            if prim.get('cooldownMs'):
                print(f"  Cooldown: {prim.get('cooldownMs')}ms")

        # Safety
        if prim.get('safetyNotes'):
            print(f"\nSafety Notes:")
            print(f"  {prim.get('safetyNotes')}")

    except Exception as e:
        print(f"\n✗ Failed to get primitive: {e}", file=sys.stderr)
        sys.exit(1)


def primitive_test(client, primitive_id: str, params_json: str,
                   result: str, notes: Optional[str], video: Optional[str]) -> None:
    """Submit a test result for a primitive skill."""
    try:
        parameters = json.loads(params_json)
    except json.JSONDecodeError as e:
        print(f"Error: Invalid JSON for parameters: {e}", file=sys.stderr)
        sys.exit(1)

    data = {
        "parameters": parameters,
        "result": result,
    }
    if notes:
        data["resultNotes"] = notes
    if video:
        data["videoUrl"] = video

    try:
        response = client._request("POST", f"/primitives/{primitive_id}/test", json=data)
        update = response.get("primitiveUpdate", {})

        print(f"\n✓ Test result submitted!")
        print(f"  Result: {result}")
        print(f"  New Reliability Score: {update.get('reliabilityScore', 0):.1%}")

        if update.get('statusChanged'):
            print(f"  Status upgraded to: {update.get('status')}")

    except Exception as e:
        print(f"\n✗ Failed to submit test: {e}", file=sys.stderr)
        sys.exit(1)


def primitive_init(client, name: str, protocol_id: Optional[str],
                   from_recording: Optional[str], category: str, output: str) -> None:
    """Initialize a new primitive skill definition locally."""
    print(f"\n{'=' * 60}")
    print("Initializing Primitive Skill")
    print(f"{'=' * 60}\n")

    out_path = Path(output)
    out_path.mkdir(parents=True, exist_ok=True)

    primitive_data = {
        "name": name,
        "displayName": name.replace("_", " ").title(),
        "category": category,
        "description": "",
        "protocolId": protocol_id,
        "commandType": "single",
        "commandTemplate": "",
        "responsePattern": "",
        "parameters": [],
        "executionTimeMs": None,
        "settleTimeMs": None,
        "cooldownMs": None,
        "safetyNotes": "",
        "status": "experimental",
        "version": "1.0.0",
    }

    # If importing from a recording, populate command data
    if from_recording:
        recording_path = Path(from_recording)
        if recording_path.exists():
            with open(recording_path) as f:
                recording = json.load(f)

            commands = recording.get("commands", [])
            if commands:
                primitive_data["commandTemplate"] = commands[0].get("command", "")
                if len(commands) > 1:
                    primitive_data["commandType"] = "sequence"
                    primitive_data["commandSequence"] = [
                        {"command": c.get("command"), "delayMs": int((c.get("timestamp", 0) * 1000))}
                        for c in commands
                    ]

                responses = [c.get("response") for c in commands if c.get("response")]
                if responses:
                    primitive_data["responsePattern"] = responses[0]

                print(f"✓ Imported {len(commands)} commands from recording")
        else:
            print(f"Warning: Recording file not found: {from_recording}", file=sys.stderr)

    # Write primitive file
    primitive_file = out_path / f"{name}.primitive.json"
    with open(primitive_file, "w") as f:
        json.dump(primitive_data, f, indent=2)

    print(f"✓ Created: {primitive_file}")
    print(f"\nNext steps:")
    print(f"  1. Edit {primitive_file} to define command template and parameters")
    print(f"  2. Test with: ate primitive test <primitive_id> --params '{{...}}'")
    print(f"  3. Publish with: ate primitive push {primitive_file}")


def primitive_push(client, primitive_file: str) -> None:
    """Push a primitive skill definition to FoodforThought."""
    file_path = Path(primitive_file)
    if not file_path.exists():
        print(f"Error: Primitive file not found: {primitive_file}", file=sys.stderr)
        sys.exit(1)

    print(f"\n{'=' * 60}")
    print("Publishing Primitive Skill")
    print(f"{'=' * 60}\n")

    with open(file_path) as f:
        primitive_data = json.load(f)

    print(f"Name: {primitive_data.get('displayName') or primitive_data.get('name')}")
    print(f"Category: {primitive_data.get('category')}")

    # Validate required fields
    if not primitive_data.get("name"):
        print("Error: Primitive must have a name", file=sys.stderr)
        sys.exit(1)

    if not primitive_data.get("commandTemplate") and not primitive_data.get("commandSequence"):
        print("Error: Primitive must have a commandTemplate or commandSequence", file=sys.stderr)
        sys.exit(1)

    try:
        response = client._request("POST", "/primitives", json=primitive_data)
        prim = response.get("primitive", {})
        print(f"\n✓ Primitive published successfully!")
        print(f"  ID: {prim.get('id')}")
        print(f"  Status: {prim.get('status')}")
    except Exception as e:
        print(f"\n✗ Failed to publish: {e}", file=sys.stderr)
        sys.exit(1)


def primitive_deps_show(client, primitive_id: str) -> None:
    """Show dependencies for a primitive skill."""
    try:
        response = client._request("GET", f"/primitives/{primitive_id}/dependencies")
        deps = response.get("dependencies", [])
        dependents = response.get("dependents", [])
        deployment_ready = response.get("deploymentReady", False)

        print(f"\n{'=' * 60}")
        print("Dependency Graph")
        print(f"{'=' * 60}")

        print(f"\nDeployment Ready: {'✓ Yes' if deployment_ready else '✗ No'}")

        if deps:
            print(f"\nDepends On ({len(deps)}):")
            for dep in deps:
                req = dep.get("requiredSkill", {})
                status_ok = req.get("status") in ["tested", "verified"]
                icon = "✓" if status_ok else "✗"
                print(f"  {icon} {req.get('name')} ({req.get('status')})")
        else:
            print(f"\nNo dependencies (this is a root primitive)")

        if dependents:
            print(f"\nRequired By ({len(dependents)}):")
            for dep in dependents:
                skill = dep.get("dependentSkill", {})
                print(f"  - {skill.get('name')}")

    except Exception as e:
        print(f"\n✗ Failed to fetch dependencies: {e}", file=sys.stderr)
        sys.exit(1)


def primitive_deps_add(client, primitive_id: str, required_id: str,
                       dependency_type: str, min_status: str) -> None:
    """Add a dependency to a primitive skill."""
    data = {
        "requiredSkillId": required_id,
        "dependencyType": dependency_type,
        "requiredMinStatus": min_status,
    }

    try:
        response = client._request("POST", f"/primitives/{primitive_id}/dependencies", json=data)
        cross_robot = response.get("crossRobot", False)

        print(f"\n✓ Dependency added!")
        if cross_robot:
            print(f"  ⚠ Note: This is a cross-robot dependency")

    except Exception as e:
        print(f"\n✗ Failed to add dependency: {e}", file=sys.stderr)
        sys.exit(1)


def register_parser(subparsers):
    """Register primitive commands with argparse."""
    primitive_parser = subparsers.add_parser("primitive", help="Manage primitive skills")
    primitive_subparsers = primitive_parser.add_subparsers(dest="primitive_action", help="Primitive action")

    # primitive list
    primitive_list_parser = primitive_subparsers.add_parser("list", help="List primitive skills")
    primitive_list_parser.add_argument("-r", "--robot", help="Filter by robot model")
    primitive_list_parser.add_argument("-c", "--category",
                                       choices=["body_pose", "arm", "gripper", "locomotion",
                                               "head", "sensing", "manipulation", "navigation"],
                                       help="Filter by category")
    primitive_list_parser.add_argument("--status",
                                       choices=["experimental", "tested", "verified", "deprecated"],
                                       help="Filter by status")
    primitive_list_parser.add_argument("--tested", action="store_true",
                                       help="Show only tested/verified primitives")

    # primitive get
    primitive_get_parser = primitive_subparsers.add_parser("get", help="Get primitive details")
    primitive_get_parser.add_argument("primitive_id", help="Primitive ID")

    # primitive test
    primitive_test_parser = primitive_subparsers.add_parser("test", help="Submit test result")
    primitive_test_parser.add_argument("primitive_id", help="Primitive ID to test")
    primitive_test_parser.add_argument("-p", "--params", required=True,
                                       help="Parameters used in test as JSON")
    primitive_test_parser.add_argument("-r", "--result", required=True,
                                       choices=["pass", "fail", "partial"],
                                       help="Test result")
    primitive_test_parser.add_argument("-n", "--notes", help="Test notes")
    primitive_test_parser.add_argument("-v", "--video", help="Video URL of test")

    # primitive deps
    primitive_deps_parser = primitive_subparsers.add_parser("deps", help="Manage primitive dependencies")
    primitive_deps_subparsers = primitive_deps_parser.add_subparsers(dest="primitive_deps_action",
                                                                     help="Dependency action")

    # primitive deps show
    primitive_deps_show_parser = primitive_deps_subparsers.add_parser("show", help="Show dependencies")
    primitive_deps_show_parser.add_argument("primitive_id", help="Primitive ID")

    # primitive deps add
    primitive_deps_add_parser = primitive_deps_subparsers.add_parser("add", help="Add dependency")
    primitive_deps_add_parser.add_argument("primitive_id", help="Primitive ID (the one that depends)")
    primitive_deps_add_parser.add_argument("required_id", help="Required primitive ID")
    primitive_deps_add_parser.add_argument("-t", "--type", default="requires",
                                           choices=["requires", "extends", "overrides", "optional"],
                                           help="Dependency type (default: requires)")
    primitive_deps_add_parser.add_argument("--min-status", default="tested",
                                           choices=["experimental", "tested", "verified"],
                                           help="Minimum required status (default: tested)")

    # primitive init
    primitive_init_parser = primitive_subparsers.add_parser("init", help="Initialize primitive skill template")
    primitive_init_parser.add_argument("name", help="Primitive name (e.g., move_joint, grip_close)")
    primitive_init_parser.add_argument("-p", "--protocol", help="Protocol ID to link to")
    primitive_init_parser.add_argument("-r", "--from-recording", help="Import from recording file")
    primitive_init_parser.add_argument("-c", "--category", default="motion",
                                       choices=["body_pose", "arm", "gripper", "locomotion",
                                               "head", "sensing", "manipulation", "navigation"],
                                       help="Primitive category (default: motion)")
    primitive_init_parser.add_argument("-o", "--output", default=".", help="Output directory")

    # primitive push
    primitive_push_parser = primitive_subparsers.add_parser("push", help="Publish primitive to FoodforThought")
    primitive_push_parser.add_argument("primitive_file", help="Path to .primitive.json file")


def handle(client, args):
    """Handle primitive commands."""
    if args.primitive_action == "list":
        primitive_list(client, args.robot, args.category, args.status, args.tested)
    elif args.primitive_action == "get":
        primitive_get(client, args.primitive_id)
    elif args.primitive_action == "test":
        primitive_test(client, args.primitive_id, args.params, args.result, args.notes, args.video)
    elif args.primitive_action == "init":
        primitive_init(client, args.name, args.protocol, args.from_recording, args.category, args.output)
    elif args.primitive_action == "push":
        primitive_push(client, args.primitive_file)
    elif args.primitive_action == "deps":
        if args.primitive_deps_action == "show":
            primitive_deps_show(client, args.primitive_id)
        elif args.primitive_deps_action == "add":
            primitive_deps_add(client, args.primitive_id, args.required_id, args.type, args.min_status)
        else:
            print("Usage: ate primitive deps {show|add}")
            sys.exit(1)
    else:
        print("Usage: ate primitive {list|get|test|init|push|deps}")
        sys.exit(1)
