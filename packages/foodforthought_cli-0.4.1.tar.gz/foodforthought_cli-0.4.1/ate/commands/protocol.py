"""
Protocol registry commands for FoodforThought CLI.

Commands:
- ate protocol list       - List protocols
- ate protocol get        - Get protocol details
- ate protocol init       - Initialize new protocol template
- ate protocol push       - Upload protocol to FoodForThought
- ate protocol scan-serial - Scan for serial ports
- ate protocol scan-ble   - Scan for BLE devices
"""

import json
import sys
from pathlib import Path
from typing import Optional


def protocol_list(client, robot: Optional[str], transport: Optional[str],
                  verified: bool, search: Optional[str]) -> None:
    """List protocols from the registry."""
    print("Fetching protocols...")

    params = {}
    if robot:
        params["robot"] = robot
    if transport:
        params["transport"] = transport
    if verified:
        params["verified"] = "true"
    if search:
        params["search"] = search

    try:
        response = client._request("GET", "/protocols", params=params)
        protocols = response.get("protocols", [])

        if not protocols:
            print("\nNo protocols found matching criteria.")
            return

        print(f"\n{'=' * 70}")
        print(f"{'Robot Model':<25} {'Transport':<12} {'Status':<12} {'Commands'}")
        print(f"{'=' * 70}")

        for proto in protocols:
            robot_model = proto.get("robotModel", "")[:23]
            transport_type = proto.get("transport", "")[:10]
            status = "✓ Verified" if proto.get("verified") else "○ Community"
            cmd_count = len(proto.get("commands", []))
            print(f"{robot_model:<25} {transport_type:<12} {status:<12} {cmd_count}")

    except Exception as e:
        print(f"\n✗ Failed to list protocols: {e}", file=sys.stderr)
        sys.exit(1)


def protocol_get(client, protocol_id: str) -> None:
    """Get detailed information about a protocol."""
    try:
        response = client._request("GET", f"/protocols/{protocol_id}")
        proto = response.get("protocol", {})

        print(f"\n{'=' * 60}")
        print(f"Protocol: {proto.get('robotModel')}")
        print(f"{'=' * 60}")

        print(f"\nTransport: {proto.get('transport')}")
        print(f"Verified: {'Yes' if proto.get('verified') else 'No'}")
        print(f"Format: {proto.get('commandFormat')}")

        # Connection info
        if proto.get("connectionInfo"):
            info = proto["connectionInfo"]
            print(f"\nConnection:")
            if info.get("baudRate"):
                print(f"  Baud Rate: {info['baudRate']}")
            if info.get("serviceUuid"):
                print(f"  Service UUID: {info['serviceUuid']}")
            if info.get("charUuid"):
                print(f"  Characteristic UUID: {info['charUuid']}")

        # Commands
        commands = proto.get("commands", [])
        if commands:
            print(f"\nCommands ({len(commands)}):")
            for cmd in commands[:10]:  # Show first 10
                print(f"  • {cmd.get('name')}: {cmd.get('template')}")
            if len(commands) > 10:
                print(f"  ... and {len(commands) - 10} more")

    except Exception as e:
        print(f"\n✗ Failed to get protocol: {e}", file=sys.stderr)
        sys.exit(1)


def protocol_init(client, robot_model: str, transport: str, output: str) -> None:
    """Initialize a new protocol template."""
    print(f"Initializing protocol for {robot_model}")
    print(f"  Transport: {transport}")
    print(f"  Output: {output}")

    output_path = Path(output)
    output_path.mkdir(parents=True, exist_ok=True)

    # Create protocol template
    protocol_template = {
        "robotModel": robot_model,
        "transport": transport,
        "commandFormat": "ascii" if transport == "serial" else "binary",
        "connectionInfo": {},
        "commands": [
            {
                "name": "example_command",
                "template": "CMD {param1}",
                "description": "Example command - replace with actual commands",
                "parameters": [
                    {"name": "param1", "type": "int", "range": [0, 100]}
                ]
            }
        ],
        "version": "1.0.0"
    }

    # Add transport-specific defaults
    if transport == "serial":
        protocol_template["connectionInfo"]["baudRate"] = 115200
        protocol_template["connectionInfo"]["dataBits"] = 8
        protocol_template["connectionInfo"]["stopBits"] = 1
    elif transport == "ble":
        protocol_template["connectionInfo"]["serviceUuid"] = ""
        protocol_template["connectionInfo"]["charUuid"] = ""
    elif transport == "wifi":
        protocol_template["connectionInfo"]["port"] = 8080

    # Write protocol file
    protocol_file = output_path / "protocol.json"
    with open(protocol_file, 'w') as f:
        json.dump(protocol_template, f, indent=2)

    print(f"\n✓ Created: {protocol_file}")
    print(f"\nNext steps:")
    print(f"  1. Edit {protocol_file} with your robot's commands")
    print(f"  2. Test connection with: ate bridge connect <port>")
    print(f"  3. Publish with: ate protocol push {protocol_file}")


def protocol_push(client, file: Optional[str]) -> None:
    """Upload protocol to FoodForThought."""
    protocol_file = Path(file or "./protocol.json")

    if not protocol_file.exists():
        print(f"Error: Protocol file not found: {protocol_file}", file=sys.stderr)
        sys.exit(1)

    with open(protocol_file) as f:
        protocol_data = json.load(f)

    print(f"Uploading protocol: {protocol_data.get('robotModel')}")

    try:
        response = client._request("POST", "/protocols", json=protocol_data)
        proto = response.get("protocol", {})

        print(f"\n✓ Protocol uploaded!")
        print(f"  ID: {proto.get('id')}")
        print(f"  Status: Pending review")

    except Exception as e:
        print(f"\n✗ Upload failed: {e}", file=sys.stderr)
        sys.exit(1)


def protocol_scan_serial() -> None:
    """Scan for available serial ports."""
    try:
        import serial.tools.list_ports
    except ImportError:
        print("Error: pyserial is required. Install with: pip install pyserial", file=sys.stderr)
        sys.exit(1)

    print("Scanning for serial ports...\n")

    ports = list(serial.tools.list_ports.comports())

    if not ports:
        print("No serial ports found.")
        return

    print(f"Found {len(ports)} port(s):\n")

    for port in ports:
        print(f"  {port.device}")
        if port.description and port.description != "n/a":
            print(f"    Description: {port.description}")
        if port.manufacturer:
            print(f"    Manufacturer: {port.manufacturer}")
        if port.vid and port.pid:
            print(f"    VID:PID: {port.vid:04x}:{port.pid:04x}")
        print()


def protocol_scan_ble() -> None:
    """Scan for BLE devices."""
    try:
        import asyncio
        from bleak import BleakScanner
    except ImportError:
        print("Error: bleak is required. Install with: pip install bleak", file=sys.stderr)
        sys.exit(1)

    async def scan():
        print("Scanning for BLE devices (5 seconds)...\n")

        devices = await BleakScanner.discover(timeout=5.0)

        if not devices:
            print("No BLE devices found.")
            return

        print(f"Found {len(devices)} device(s):\n")

        for device in sorted(devices, key=lambda d: d.rssi or -100, reverse=True):
            rssi = f"{device.rssi} dBm" if device.rssi else "N/A"
            print(f"  {device.address}")
            if device.name:
                print(f"    Name: {device.name}")
            print(f"    RSSI: {rssi}")
            print()

    asyncio.run(scan())


def register_parser(subparsers):
    """Register protocol commands with argparse."""
    protocol_parser = subparsers.add_parser("protocol", help="Manage protocol registry")
    protocol_subparsers = protocol_parser.add_subparsers(dest="protocol_action", help="Protocol action")

    # protocol list
    protocol_list_parser = protocol_subparsers.add_parser("list", help="List protocols")
    protocol_list_parser.add_argument("-r", "--robot", help="Filter by robot model")
    protocol_list_parser.add_argument("-t", "--transport",
                                      choices=["ble", "serial", "wifi", "can", "i2c", "spi", "mqtt", "ros2"],
                                      help="Filter by transport type")
    protocol_list_parser.add_argument("--verified", action="store_true", help="Show only verified protocols")
    protocol_list_parser.add_argument("-s", "--search", help="Search in command format and notes")

    # protocol get
    protocol_get_parser = protocol_subparsers.add_parser("get", help="Get protocol details")
    protocol_get_parser.add_argument("protocol_id", help="Protocol ID")

    # protocol init
    protocol_init_parser = protocol_subparsers.add_parser("init", help="Initialize new protocol template")
    protocol_init_parser.add_argument("robot_model", help="Robot model name (e.g., hiwonder-mechdog-pro)")
    protocol_init_parser.add_argument("-t", "--transport", required=True,
                                      choices=["ble", "serial", "wifi", "can", "i2c", "spi", "mqtt", "ros2"],
                                      help="Transport type")
    protocol_init_parser.add_argument("-o", "--output", default="./protocol",
                                      help="Output directory (default: ./protocol)")

    # protocol push
    protocol_push_parser = protocol_subparsers.add_parser("push", help="Upload protocol to FoodForThought")
    protocol_push_parser.add_argument("file", nargs="?", help="Path to protocol.json (default: ./protocol.json)")

    # protocol scan-serial
    protocol_subparsers.add_parser("scan-serial", help="Scan for serial ports")

    # protocol scan-ble
    protocol_subparsers.add_parser("scan-ble", help="Scan for BLE devices")


def handle(client, args):
    """Handle protocol commands."""
    if args.protocol_action == "list":
        protocol_list(client, args.robot, args.transport, args.verified, args.search)
    elif args.protocol_action == "get":
        protocol_get(client, args.protocol_id)
    elif args.protocol_action == "init":
        protocol_init(client, args.robot_model, args.transport, args.output)
    elif args.protocol_action == "push":
        protocol_push(client, args.file)
    elif args.protocol_action == "scan-serial":
        protocol_scan_serial()
    elif args.protocol_action == "scan-ble":
        protocol_scan_ble()
    else:
        print("Usage: ate protocol {list|get|init|push|scan-serial|scan-ble}")
        sys.exit(1)
