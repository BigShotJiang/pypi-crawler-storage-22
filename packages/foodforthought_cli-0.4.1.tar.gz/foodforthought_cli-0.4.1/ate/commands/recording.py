"""
Recording commands for FoodforThought CLI.

Commands:
- ate record start  - Start recording telemetry
- ate record stop   - Stop recording and upload
- ate record status - Get current recording status
- ate record demo   - Record a timed demonstration
- ate record list   - List telemetry recordings
- ate record local  - Record from a connected robot
"""

import json
import sys
import time
from pathlib import Path
from typing import Optional, List

CONFIG_DIR = Path.home() / ".ate"


def record_start(client, robot_id: str, skill_id: str, task_description: Optional[str] = None) -> None:
    """Start recording telemetry from a robot."""
    import uuid

    # Store recording state in a file
    recording_file = CONFIG_DIR / "active_recording.json"
    CONFIG_DIR.mkdir(exist_ok=True)

    if recording_file.exists():
        print("Error: Recording already in progress. Run 'ate record stop' first.", file=sys.stderr)
        sys.exit(1)

    recording_id = str(uuid.uuid4())
    recording_state = {
        "id": recording_id,
        "robot_id": robot_id,
        "skill_id": skill_id,
        "task_description": task_description or "",
        "start_time": time.time(),
        "frames": [],
    }

    with open(recording_file, "w") as f:
        json.dump(recording_state, f, indent=2)

    print(f"Recording started!")
    print(f"  Recording ID: {recording_id}")
    print(f"  Robot: {robot_id}")
    print(f"  Skill: {skill_id}")
    if task_description:
        print(f"  Task: {task_description}")
    print(f"\nRun 'ate record stop' when finished.")


def record_stop(client, success: bool = True, notes: Optional[str] = None,
                upload: bool = True, create_labeling_task: bool = False) -> None:
    """Stop recording and optionally upload to FoodforThought."""
    from datetime import datetime

    recording_file = CONFIG_DIR / "active_recording.json"

    if not recording_file.exists():
        print("Error: No active recording. Start one with 'ate record start'.", file=sys.stderr)
        sys.exit(1)

    with open(recording_file, "r") as f:
        recording_state = json.load(f)

    # Calculate duration
    end_time = time.time()
    duration = end_time - recording_state["start_time"]
    frame_count = len(recording_state.get("frames", []))

    print(f"Recording stopped!")
    print(f"  Recording ID: {recording_state['id']}")
    print(f"  Duration: {duration:.1f}s")
    print(f"  Frames: {frame_count}")
    print(f"  Success: {'Yes' if success else 'No'}")

    if upload:
        print(f"\nUploading to FoodforThought...")

        try:
            recording_data = {
                "recording": {
                    "id": recording_state["id"],
                    "robotId": recording_state["robot_id"],
                    "skillId": recording_state["skill_id"],
                    "source": "hardware",
                    "startTime": datetime.fromtimestamp(recording_state["start_time"]).isoformat(),
                    "endTime": datetime.fromtimestamp(end_time).isoformat(),
                    "success": success,
                    "metadata": {
                        "duration": duration,
                        "frameRate": frame_count / duration if duration > 0 else 0,
                        "totalFrames": frame_count,
                        "tags": ["edge_recording", "cli"],
                        "notes": notes,
                    },
                    "frames": recording_state.get("frames", []),
                    "events": [],
                },
            }

            if create_labeling_task:
                recording_data["createLabelingTask"] = True

            response = client._request("POST", "/telemetry/ingest", json=recording_data)

            artifact_id = response.get("data", {}).get("artifactId", "")
            print(f"\n✓ Uploaded successfully!")
            print(f"  Artifact ID: {artifact_id}")
            print(f"  View at: https://foodforthought.kindly.fyi/artifacts/{artifact_id}")

            if create_labeling_task:
                task_id = response.get("data", {}).get("taskId", "")
                if task_id:
                    print(f"  Labeling Task: https://foodforthought.kindly.fyi/labeling/{task_id}")

        except Exception as e:
            print(f"\n✗ Upload failed: {e}", file=sys.stderr)
            print("Recording saved locally. You can upload later.", file=sys.stderr)

    if notes:
        print(f"\nNotes: {notes}")

    # Remove recording state file
    recording_file.unlink()


def record_status(client) -> None:
    """Get current recording status."""
    recording_file = CONFIG_DIR / "active_recording.json"

    if not recording_file.exists():
        print("No active recording session.")
        return

    with open(recording_file, "r") as f:
        recording_state = json.load(f)

    elapsed = time.time() - recording_state["start_time"]
    frame_count = len(recording_state.get("frames", []))

    print(f"Recording in progress")
    print(f"  Recording ID: {recording_state['id']}")
    print(f"  Robot: {recording_state['robot_id']}")
    print(f"  Skill: {recording_state['skill_id']}")
    print(f"  Elapsed: {elapsed:.1f}s")
    print(f"  Frames: {frame_count}")
    if recording_state.get("task_description"):
        print(f"  Task: {recording_state['task_description']}")


def record_demo(client, robot_id: str, skill_id: str, task_description: str,
                duration_seconds: float = 30.0, create_labeling_task: bool = True) -> None:
    """Record a timed demonstration."""
    import uuid
    from datetime import datetime

    recording_id = str(uuid.uuid4())
    print(f"Recording demonstration...")
    print(f"  Recording ID: {recording_id}")
    print(f"  Robot: {robot_id}")
    print(f"  Skill: {skill_id}")
    print(f"  Task: {task_description}")
    print(f"  Duration: {duration_seconds}s")
    print()

    start_time = time.time()

    # Show a countdown/progress indicator
    elapsed = 0
    while elapsed < duration_seconds:
        remaining = duration_seconds - elapsed
        print(f"\rRecording... {remaining:.0f}s remaining", end="", flush=True)
        time.sleep(min(1.0, remaining))
        elapsed = time.time() - start_time

    end_time = time.time()
    actual_duration = end_time - start_time
    print(f"\rRecording complete!{' ' * 20}")

    print(f"\nUploading to FoodforThought...")

    try:
        recording_data = {
            "recording": {
                "id": recording_id,
                "robotId": robot_id,
                "skillId": skill_id,
                "source": "hardware",
                "startTime": datetime.fromtimestamp(start_time).isoformat(),
                "endTime": datetime.fromtimestamp(end_time).isoformat(),
                "success": True,
                "metadata": {
                    "duration": actual_duration,
                    "frameRate": 0,
                    "totalFrames": 0,
                    "tags": ["demonstration", "cli"],
                    "task_description": task_description,
                },
                "frames": [],
                "events": [],
            },
        }

        if create_labeling_task:
            recording_data["createLabelingTask"] = True

        response = client._request("POST", "/telemetry/ingest", json=recording_data)

        artifact_id = response.get("data", {}).get("artifactId", "")
        print(f"\n✓ Uploaded successfully!")
        print(f"  Artifact ID: {artifact_id}")
        print(f"  View at: https://foodforthought.kindly.fyi/artifacts/{artifact_id}")

        if create_labeling_task:
            task_id = response.get("data", {}).get("taskId", "")
            if task_id:
                print(f"  Labeling Task: https://foodforthought.kindly.fyi/labeling/{task_id}")

    except Exception as e:
        print(f"\n✗ Upload failed: {e}", file=sys.stderr)


def record_list(client, robot_id: Optional[str] = None, skill_id: Optional[str] = None,
                success_only: bool = False, limit: int = 20) -> None:
    """List telemetry recordings from FoodforThought."""
    print("Fetching recordings...")

    params = {
        "type": "trajectory",
        "limit": limit,
    }

    if robot_id:
        params["robotModel"] = robot_id
    if skill_id:
        params["task"] = skill_id

    try:
        response = client._request("GET", "/artifacts", params=params)
        artifacts = response.get("artifacts", [])

        if not artifacts:
            print("No recordings found.")
            return

        print(f"\nFound {len(artifacts)} recording(s):\n")

        for artifact in artifacts:
            metadata = artifact.get("metadata", {})

            # Skip failed recordings if success_only
            if success_only and not metadata.get("success", True):
                continue

            success_marker = "✓" if metadata.get("success", True) else "✗"
            print(f"{success_marker} {artifact.get('name', 'Unnamed')}")
            print(f"    ID: {artifact.get('id')}")
            print(f"    Robot: {metadata.get('robotId', 'Unknown')}")
            print(f"    Skill: {metadata.get('skillId', 'Unknown')}")
            print(f"    Duration: {metadata.get('duration', 0):.1f}s")
            print(f"    Frames: {metadata.get('frameCount', 0)}")
            print(f"    Source: {metadata.get('source', 'Unknown')}")
            print()

    except Exception as e:
        print(f"Error fetching recordings: {e}", file=sys.stderr)
        sys.exit(1)


def record_local(
    client,
    profile_name: str,
    duration: float = 30.0,
    name: Optional[str] = None,
    fps: float = 5.0,
    detect_trash: bool = False,
    detect_colors: Optional[List[str]] = None,
    output_path: Optional[str] = None,
    upload: bool = True,
) -> None:
    """Record from a connected robot with visual capture and detection."""
    from ate.robot.profiles import load_profile, list_profiles
    from ate.robot.manager import RobotManager
    from ate.recording import VisualRecordingSession

    # Load profile
    profile = load_profile(profile_name)
    if not profile:
        available = list_profiles()
        print(f"Profile '{profile_name}' not found.", file=sys.stderr)
        if available:
            print(f"Available profiles: {', '.join(p.name for p in available)}")
        else:
            print("Run 'ate robot setup' to create a profile first.")
        sys.exit(1)

    recording_name = name or f"{profile.name}_recording"
    output = output_path or f"{recording_name}.demonstration"

    print(f"Local Recording")
    print(f"{'=' * 40}")
    print(f"Profile: {profile.name}")
    print(f"Robot type: {profile.robot_type}")
    print(f"Duration: {duration}s")
    print(f"Visual capture: {fps} fps")
    print()

    # Connect to robot
    print("Connecting to robot...")
    try:
        manager = RobotManager()
        managed = manager.load(profile_name)
        if not managed:
            print(f"Failed to load profile: {profile_name}", file=sys.stderr)
            sys.exit(1)
        if not manager.connect(profile_name):
            print(f"Failed to connect to robot", file=sys.stderr)
            sys.exit(1)
        driver = manager.get(profile_name)
        print(f"  Connected to {driver.get_info().name}")
    except Exception as e:
        print(f"Failed to connect: {e}", file=sys.stderr)
        sys.exit(1)

    # Setup detector
    detector = None
    if detect_trash:
        try:
            from ate.detection import TrashDetector
            detector = TrashDetector()
            print(f"  Trash detection enabled")
        except ImportError:
            print("  Warning: Trash detection requires Pillow. Run: pip install 'foodforthought-cli[detection]'")
    elif detect_colors:
        try:
            from ate.detection import ColorDetector
            detector = ColorDetector()
            print(f"  Color detection enabled: {', '.join(detect_colors)}")
        except ImportError:
            print("  Warning: Color detection requires Pillow. Run: pip install 'foodforthought-cli[detection]'")

    # Check if camera is available
    has_camera = hasattr(driver, 'get_image')
    if has_camera:
        print(f"  Camera available")
    else:
        print(f"  No camera available (recording actions only)")

    print()
    print("Starting recording in 3 seconds...")
    print("(Control the robot manually during recording)")
    time.sleep(3)

    # Record
    print()
    print("RECORDING - Press Ctrl+C to stop early")
    print("-" * 40)

    session = None
    try:
        with VisualRecordingSession(
            driver,
            name=recording_name,
            capture_fps=fps,
            detector=detector,
        ) as session:
            start_time = time.time()
            elapsed = 0

            while elapsed < duration:
                remaining = duration - elapsed
                frame_info = f", {session.frame_count} frames" if has_camera else ""
                det_info = f", {session.detection_count} detections" if detector else ""
                print(f"\rRecording... {remaining:.0f}s remaining{frame_info}{det_info}  ", end="", flush=True)
                time.sleep(0.5)
                elapsed = time.time() - start_time

    except KeyboardInterrupt:
        print("\n\nRecording stopped by user")

    if session is None:
        print("No recording session created.", file=sys.stderr)
        manager.disconnect_all()
        sys.exit(1)

    print("\n")
    print("Recording complete!")
    print("-" * 40)
    print(session.summary())

    # Save locally
    print()
    print(f"Saving to {output}...")
    session.save(output)

    if has_camera and session.frame_count > 0:
        frames_path = output.replace(".demonstration", "_frames.json")
        session.save_frames(frames_path, include_data=True)
        print(f"Saved {session.frame_count} frames to {frames_path}")

    # Upload if requested
    if upload:
        print()
        print("Uploading to FoodforThought...")
        try:
            recording_data = session.to_dict()
            response = client._request("POST", "/telemetry/ingest", json={"recording": recording_data})
            artifact_id = response.get("data", {}).get("artifactId", "")
            print(f"Uploaded successfully!")
            print(f"  Artifact ID: {artifact_id}")
            print(f"  View at: https://foodforthought.kindly.fyi/artifacts/{artifact_id}")
        except Exception as e:
            print(f"Upload failed: {e}")
            print("Recording saved locally - you can upload later with 'ate upload'")

    # Disconnect
    manager.disconnect_all()
    print()
    print("Done!")


def register_parser(subparsers):
    """Register recording commands with argparse."""
    record_parser = subparsers.add_parser("record",
        help="Record robot telemetry and demonstrations",
        description="""Record robot telemetry for the data flywheel.

EXAMPLES:
    ate record start my-robot-id my-skill-id
    ate record stop --success --notes "Good demo"
    ate record demo my-robot-id pick-object "Pick up the red ball" --duration 60
    ate record local my_robot_profile --duration 30 --detect-trash
""")
    record_subparsers = record_parser.add_subparsers(dest="record_action")

    # record start
    record_start_parser = record_subparsers.add_parser("start", help="Start recording telemetry")
    record_start_parser.add_argument("robot", help="Robot ID")
    record_start_parser.add_argument("skill", help="Skill ID being demonstrated")
    record_start_parser.add_argument("-t", "--task", help="Task description")

    # record stop
    record_stop_parser = record_subparsers.add_parser("stop", help="Stop recording and upload")
    record_stop_parser.add_argument("--success", dest="success", action="store_true",
        default=True, help="Mark recording as successful (default)")
    record_stop_parser.add_argument("--failure", dest="success", action="store_false",
        help="Mark recording as failed")
    record_stop_parser.add_argument("-n", "--notes", help="Recording notes")
    record_stop_parser.add_argument("--no-upload", action="store_true",
        help="Skip uploading to FoodforThought")
    record_stop_parser.add_argument("--create-task", action="store_true",
        help="Create labeling task from this recording")

    # record status
    record_subparsers.add_parser("status", help="Get current recording status")

    # record demo
    record_demo_parser = record_subparsers.add_parser("demo", help="Record a timed demonstration")
    record_demo_parser.add_argument("robot", help="Robot ID")
    record_demo_parser.add_argument("skill", help="Skill ID")
    record_demo_parser.add_argument("task", help="Task description")
    record_demo_parser.add_argument("-d", "--duration", type=float, default=30.0,
        help="Recording duration in seconds")
    record_demo_parser.add_argument("--create-task", dest="create_task", action="store_true",
        default=True, help="Create labeling task (default)")

    # record list
    record_list_parser = record_subparsers.add_parser("list", help="List telemetry recordings")
    record_list_parser.add_argument("-r", "--robot", help="Filter by robot")
    record_list_parser.add_argument("-s", "--skill", help="Filter by skill")
    record_list_parser.add_argument("--success-only", action="store_true",
        help="Only show successful recordings")
    record_list_parser.add_argument("-l", "--limit", type=int, default=20,
        help="Max number of recordings to show")

    # record local
    record_local_parser = record_subparsers.add_parser("local",
        help="Record from a connected robot with visual capture")
    record_local_parser.add_argument("profile", help="Robot profile name")
    record_local_parser.add_argument("-d", "--duration", type=float, default=30.0,
        help="Recording duration in seconds")
    record_local_parser.add_argument("-n", "--name", help="Recording name")
    record_local_parser.add_argument("--fps", type=float, default=5.0,
        help="Frame capture rate")
    record_local_parser.add_argument("--detect-trash", action="store_true",
        help="Enable trash detection during recording")
    record_local_parser.add_argument("--detect-colors", nargs="+",
        help="Enable color detection (specify colors)")
    record_local_parser.add_argument("-o", "--output", help="Output file path")
    record_local_parser.add_argument("--no-upload", action="store_true",
        help="Skip uploading to FoodforThought")


def handle(client, args):
    """Handle recording commands."""
    if not hasattr(args, 'record_action') or not args.record_action:
        print("Usage: ate record <start|stop|status|demo|list|local>")
        sys.exit(1)

    if args.record_action == "start":
        record_start(client, args.robot, args.skill, getattr(args, 'task', None))
    elif args.record_action == "stop":
        success = args.success
        upload_flag = not getattr(args, 'no_upload', False)
        record_stop(client, success, getattr(args, 'notes', None),
                    upload_flag, getattr(args, 'create_task', False))
    elif args.record_action == "status":
        record_status(client)
    elif args.record_action == "demo":
        record_demo(client, args.robot, args.skill, args.task,
                    args.duration, getattr(args, 'create_task', True))
    elif args.record_action == "list":
        record_list(client, getattr(args, 'robot', None), getattr(args, 'skill', None),
                    getattr(args, 'success_only', False), getattr(args, 'limit', 20))
    elif args.record_action == "local":
        record_local(client, args.profile, args.duration, getattr(args, 'name', None),
                     args.fps, getattr(args, 'detect_trash', False),
                     getattr(args, 'detect_colors', None), getattr(args, 'output', None),
                     not getattr(args, 'no_upload', False))
