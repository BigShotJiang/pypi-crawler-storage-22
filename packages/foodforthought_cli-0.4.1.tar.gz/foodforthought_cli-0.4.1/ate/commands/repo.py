"""
Repository commands for FoodforThought CLI.

Commands:
- ate init   - Initialize a new repository
- ate clone  - Clone a repository
- ate commit - Create a commit
- ate push   - Push commits to remote
"""

import json
import sys
from pathlib import Path
from typing import Optional, List, Dict

import requests


def init_repo(client, name: str, description: str = "", visibility: str = "public") -> Dict:
    """Initialize a new repository."""
    data = {
        "name": name,
        "description": description,
        "visibility": visibility,
        "robotModels": [],
        "taskDomain": None,
    }
    return client._request("POST", "/repositories", json=data)


def clone_repo(client, repo_id: str, target_dir: Optional[str] = None) -> None:
    """Clone a repository."""
    repo = client._request("GET", f"/repositories/{repo_id}")
    repo_data = repo["repository"]

    if target_dir is None:
        target_dir = repo_data["name"]

    target_path = Path(target_dir)
    target_path.mkdir(exist_ok=True)

    # Create .ate directory
    ate_dir = target_path / ".ate"
    ate_dir.mkdir(exist_ok=True)

    # Save repository metadata
    metadata = {
        "id": repo_data["id"],
        "name": repo_data["name"],
        "owner": repo_data["owner"]["email"],
        "url": f"{client.base_url}/repositories/{repo_data['id']}",
    }
    with open(ate_dir / "config.json", "w") as f:
        json.dump(metadata, f, indent=2)

    # Download files
    items = repo_data.get("items", [])
    for item in items:
        if item.get("fileStorage"):
            file_url = item["fileStorage"]["url"]
            file_path = target_path / item["filePath"]

            # Create directory if needed
            file_path.parent.mkdir(parents=True, exist_ok=True)

            # Download file
            file_response = requests.get(file_url)
            file_response.raise_for_status()
            with open(file_path, "wb") as f:
                f.write(file_response.content)

    print(f"Cloned repository '{repo_data['name']}' to '{target_dir}'")


def commit(client, message: str, files: Optional[List[str]] = None) -> Dict:
    """Create a commit."""
    # Find .ate directory
    ate_dir = Path(".ate")
    if not ate_dir.exists():
        print("Error: Not a FoodforThought repository. Run 'ate init' first.", file=sys.stderr)
        sys.exit(1)

    with open(ate_dir / "config.json") as f:
        config = json.load(f)

    repo_id = config["id"]

    # Get current files if not specified
    if files is None:
        # This would need to track changes - simplified for now
        files = []

    # For now, return a placeholder
    # In a full implementation, this would:
    # 1. Track file changes
    # 2. Upload new/modified files
    # 3. Create commit via API
    print(f"Creating commit: {message}")
    print("Note: Full commit functionality requires file tracking implementation")
    return {}


def push(client, branch: str = "main") -> None:
    """Push commits to remote."""
    ate_dir = Path(".ate")
    if not ate_dir.exists():
        print("Error: Not a FoodforThought repository.", file=sys.stderr)
        sys.exit(1)

    with open(ate_dir / "config.json") as f:
        config = json.load(f)

    repo_id = config["id"]
    print(f"Pushing to {branch} branch...")
    print("Note: Full push functionality requires commit tracking implementation")


def register_parser(subparsers):
    """Register repo commands with argparse."""
    # init command
    init_parser = subparsers.add_parser("init", help="Initialize a new repository")
    init_parser.add_argument("name", help="Repository name")
    init_parser.add_argument("-d", "--description", default="", help="Repository description")
    init_parser.add_argument(
        "-v", "--visibility", choices=["public", "private"], default="public",
        help="Repository visibility"
    )

    # clone command
    clone_parser = subparsers.add_parser("clone", help="Clone a repository")
    clone_parser.add_argument("repo_id", help="Repository ID")
    clone_parser.add_argument("target_dir", nargs="?", help="Target directory")

    # commit command
    commit_parser = subparsers.add_parser("commit", help="Create a commit")
    commit_parser.add_argument("-m", "--message", required=True, help="Commit message")
    commit_parser.add_argument("files", nargs="*", help="Files to commit")

    # push command
    push_parser = subparsers.add_parser("push", help="Push commits to remote")
    push_parser.add_argument("-b", "--branch", default="main", help="Branch name")


def handle(client, args):
    """Handle repo commands."""
    if args.command == "init":
        result = init_repo(client, args.name, args.description, args.visibility)
        print(f"Created repository: {result['repository']['id']}")
    elif args.command == "clone":
        clone_repo(client, args.repo_id, args.target_dir)
    elif args.command == "commit":
        commit(client, args.message, args.files)
    elif args.command == "push":
        push(client, args.branch)
