"""
Skill abstraction commands for FoodforThought CLI.

Commands:
- ate skill init     - Initialize a new skill abstraction
- ate skill compose  - Add primitives to skill
- ate skill list     - List skill abstractions
- ate skill get      - Get skill details
- ate skill push     - Publish skill to FoodforThought
- ate skill test     - Test a skill
"""

import json
import sys
import time
from pathlib import Path
from typing import Optional, List


def skill_init(client, name: str, robot: Optional[str],
               template: str, output: str) -> None:
    """Initialize a new skill abstraction (composes primitives)."""
    print(f"\n{'=' * 60}")
    print("Initializing Skill Abstraction")
    print(f"{'=' * 60}\n")

    out_path = Path(output)
    out_path.mkdir(parents=True, exist_ok=True)

    skill_data = {
        "name": name,
        "displayName": name.replace("_", " ").title(),
        "description": "",
        "robotModel": robot,
        "version": "1.0.0",
        "status": "experimental",
        "primitives": [],
        "sequence": [],
        "parameters": [],
        "preconditions": [],
        "postconditions": [],
        "errorHandling": {
            "retryCount": 3,
            "retryDelayMs": 1000,
            "fallbackAction": None,
        },
        "metadata": {
            "author": "",
            "license": "MIT",
            "tags": [],
        }
    }

    skill_file = out_path / f"{name}.skill.json"
    with open(skill_file, "w") as f:
        json.dump(skill_data, f, indent=2)

    print(f"✓ Created: {skill_file}")
    print(f"\nNext steps:")
    print(f"  1. Add primitives: ate skill compose {skill_file} <primitive_ids...>")
    print(f"  2. Edit {skill_file} to define sequence and parameters")
    print(f"  3. Test with: ate skill test {skill_file}")
    print(f"  4. Publish with: ate skill push {skill_file}")


def skill_compose(client, skill_file: str, primitives: List[str]) -> None:
    """Add primitives to a skill's composition."""
    file_path = Path(skill_file)
    if not file_path.exists():
        print(f"Error: Skill file not found: {skill_file}", file=sys.stderr)
        sys.exit(1)

    with open(file_path) as f:
        skill_data = json.load(f)

    print(f"\n{'=' * 60}")
    print(f"Composing Skill: {skill_data.get('name')}")
    print(f"{'=' * 60}\n")

    for prim_id in primitives:
        try:
            response = client._request("GET", f"/primitives/{prim_id}")
            prim = response.get("primitive", {})
            print(f"  ✓ Adding: {prim.get('name')} ({prim.get('category')})")

            if prim_id not in skill_data.get("primitives", []):
                skill_data.setdefault("primitives", []).append(prim_id)

            skill_data.setdefault("sequence", []).append({
                "primitiveId": prim_id,
                "primitiveName": prim.get("name"),
                "parameterMapping": {},
                "conditionCheck": None,
                "onError": "abort",
            })

        except Exception as e:
            print(f"  ✗ Failed to fetch {prim_id}: {e}", file=sys.stderr)

    with open(file_path, "w") as f:
        json.dump(skill_data, f, indent=2)

    print(f"\n✓ Updated {skill_file}")
    print(f"   Primitives: {len(skill_data.get('primitives', []))}")
    print(f"   Sequence steps: {len(skill_data.get('sequence', []))}")


def skill_list(client, robot: Optional[str], status: Optional[str]) -> None:
    """List skill abstractions."""
    params = {}
    if robot:
        params["robotModel"] = robot
    if status:
        params["status"] = status

    try:
        response = client._request("GET", "/skills", params=params)
        skills = response.get("skills", [])

        print(f"\n{'=' * 70}")
        print(f"Skill Abstractions ({len(skills)} total)")
        print(f"{'=' * 70}")

        if not skills:
            print("\nNo skills found. Create one with: ate skill init <name>")
            return

        for skill in skills:
            status_icons = {"verified": "✓", "tested": "○", "experimental": "◌"}
            icon = status_icons.get(skill.get("status", "experimental"), "?")
            prim_count = len(skill.get("primitives", []))
            print(f"\n{icon} {skill.get('name')}")
            print(f"   Robot: {skill.get('robotModel', 'Any')}")
            print(f"   Primitives: {prim_count}")
            print(f"   ID: {skill.get('id')}")

    except Exception as e:
        print(f"\n✗ Failed to list skills: {e}", file=sys.stderr)
        sys.exit(1)


def skill_get(client, skill_id: str) -> None:
    """Get detailed information about a skill."""
    try:
        response = client._request("GET", f"/skills/{skill_id}")
        skill = response.get("skill", {})

        print(f"\n{'=' * 70}")
        print(f"Skill: {skill.get('displayName') or skill.get('name')}")
        print(f"{'=' * 70}")

        print(f"\nDescription: {skill.get('description') or 'No description'}")
        print(f"Robot: {skill.get('robotModel', 'Any')}")
        print(f"Status: {skill.get('status')}")
        print(f"Version: {skill.get('version')}")

        sequence = skill.get("sequence", [])
        if sequence:
            print(f"\nExecution Sequence ({len(sequence)} steps):")
            for i, step in enumerate(sequence, 1):
                print(f"  {i}. {step.get('primitiveName', step.get('primitiveId'))}")
                if step.get("conditionCheck"):
                    print(f"      Condition: {step.get('conditionCheck')}")

        params = skill.get("parameters", [])
        if params:
            print(f"\nParameters:")
            for p in params:
                print(f"  - {p.get('name')}: {p.get('type')}")

    except Exception as e:
        print(f"\n✗ Failed to get skill: {e}", file=sys.stderr)
        sys.exit(1)


def skill_push(client, skill_file: str) -> None:
    """Push a skill abstraction to FoodforThought."""
    file_path = Path(skill_file)
    if not file_path.exists():
        print(f"Error: Skill file not found: {skill_file}", file=sys.stderr)
        sys.exit(1)

    print(f"\n{'=' * 60}")
    print("Publishing Skill Abstraction")
    print(f"{'=' * 60}\n")

    with open(file_path) as f:
        skill_data = json.load(f)

    print(f"Name: {skill_data.get('displayName') or skill_data.get('name')}")
    print(f"Primitives: {len(skill_data.get('primitives', []))}")

    if not skill_data.get("name"):
        print("Error: Skill must have a name", file=sys.stderr)
        sys.exit(1)

    if not skill_data.get("primitives"):
        print("Warning: Skill has no primitives. Add with: ate skill compose", file=sys.stderr)

    try:
        response = client._request("POST", "/skills", json=skill_data)
        skill = response.get("skill", {})
        print(f"\n✓ Skill published successfully!")
        print(f"  ID: {skill.get('id')}")
        print(f"  Status: {skill.get('status')}")
    except Exception as e:
        print(f"\n✗ Failed to publish: {e}", file=sys.stderr)
        sys.exit(1)


def skill_test(client, skill_file_or_id: str, params_json: Optional[str],
               dry_run: bool) -> None:
    """Test a skill (simulated or real execution)."""
    print(f"\n{'=' * 60}")
    print("Testing Skill")
    print(f"{'=' * 60}\n")

    # Check if it's a file or ID
    if Path(skill_file_or_id).exists():
        with open(skill_file_or_id) as f:
            skill_data = json.load(f)
        print(f"Testing local skill: {skill_data.get('name')}")
    else:
        response = client._request("GET", f"/skills/{skill_file_or_id}")
        skill_data = response.get("skill", {})
        print(f"Testing remote skill: {skill_data.get('name')}")

    params = json.loads(params_json) if params_json else {}

    sequence = skill_data.get("sequence", [])
    print(f"\nSequence ({len(sequence)} steps):")

    for i, step in enumerate(sequence, 1):
        prim_name = step.get("primitiveName", step.get("primitiveId"))
        if dry_run:
            print(f"  [{i}/{len(sequence)}] Would execute: {prim_name}")
        else:
            print(f"  [{i}/{len(sequence)}] Executing: {prim_name}...")
            time.sleep(0.5)
            print(f"           ✓ Complete")

    print(f"\n{'✓ Dry run complete' if dry_run else '✓ Execution complete'}")


def register_parser(subparsers):
    """Register skill commands with argparse."""
    skill_parser = subparsers.add_parser("skill", help="Manage skill abstractions (Layer 2)")
    skill_subparsers = skill_parser.add_subparsers(dest="skill_action", help="Skill action")

    # skill init
    skill_init_parser = skill_subparsers.add_parser("init", help="Initialize a new skill abstraction")
    skill_init_parser.add_argument("name", help="Skill name (e.g., pick_and_place)")
    skill_init_parser.add_argument("-r", "--robot", help="Target robot model")
    skill_init_parser.add_argument("-t", "--template", default="basic",
                                   choices=["basic", "pick_place", "navigation", "inspection"],
                                   help="Skill template (default: basic)")
    skill_init_parser.add_argument("-o", "--output", default=".", help="Output directory")

    # skill compose
    skill_compose_parser = skill_subparsers.add_parser("compose", help="Add primitives to skill")
    skill_compose_parser.add_argument("skill_file", help="Path to .skill.json file")
    skill_compose_parser.add_argument("primitives", nargs="+", help="Primitive IDs to add")

    # skill list
    skill_list_parser = skill_subparsers.add_parser("list", help="List skill abstractions")
    skill_list_parser.add_argument("-r", "--robot", help="Filter by robot model")
    skill_list_parser.add_argument("--status",
                                   choices=["experimental", "tested", "verified"],
                                   help="Filter by status")

    # skill get
    skill_get_parser = skill_subparsers.add_parser("get", help="Get skill details")
    skill_get_parser.add_argument("skill_id", help="Skill ID")

    # skill push
    skill_push_parser = skill_subparsers.add_parser("push", help="Publish skill to FoodforThought")
    skill_push_parser.add_argument("skill_file", help="Path to .skill.json file")

    # skill test
    skill_test_parser = skill_subparsers.add_parser("test", help="Test a skill")
    skill_test_parser.add_argument("skill", help="Skill file or ID")
    skill_test_parser.add_argument("-p", "--params", help="Skill parameters as JSON")
    skill_test_parser.add_argument("--execute", action="store_true",
                                   help="Actually execute (default is dry run)")


def handle(client, args):
    """Handle skill commands."""
    if args.skill_action == "init":
        skill_init(client, args.name, args.robot, args.template, args.output)
    elif args.skill_action == "compose":
        skill_compose(client, args.skill_file, args.primitives)
    elif args.skill_action == "list":
        skill_list(client, args.robot, args.status)
    elif args.skill_action == "get":
        skill_get(client, args.skill_id)
    elif args.skill_action == "push":
        skill_push(client, args.skill_file)
    elif args.skill_action == "test":
        skill_test(client, args.skill, args.params, not args.execute)
    else:
        print("Usage: ate skill {init|compose|list|get|push|test}")
        sys.exit(1)
