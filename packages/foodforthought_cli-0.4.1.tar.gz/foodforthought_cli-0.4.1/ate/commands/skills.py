"""
Skill management commands for FoodforThought CLI.

Commands:
- ate adapt           - Adapt skills between robots
- ate validate        - Validate safety and compliance
- ate stream          - Stream sensor data
- ate pull            - Pull skill data for training
- ate upload          - Upload demonstrations for labeling
- ate check-transfer  - Check skill transfer compatibility
- ate labeling-status - Check labeling job status
"""

import json
import sys
import time
from pathlib import Path
from typing import Optional, List

import requests


def adapt(client, source_robot: str, target_robot: str, repo_id: Optional[str],
          analyze_only: bool) -> None:
    """Adapt skills between robots."""
    if not repo_id:
        ate_dir = Path(".ate")
        if ate_dir.exists():
            with open(ate_dir / "config.json") as f:
                config = json.load(f)
                repo_id = config["id"]
        else:
            print("Error: Repository ID required.", file=sys.stderr)
            sys.exit(1)

    print(f"Analyzing adaptation from {source_robot} to {target_robot}...")

    # Get adaptation plan
    try:
        response = client._request("POST", "/skills/adapt", json={
            "sourceRobotId": source_robot,
            "targetRobotId": target_robot,
            "repositoryId": repo_id,
        })
        plan = response.get("adaptationPlan", {})
        compatibility = response.get("compatibility", {})
    except Exception:
        # Mock response
        compatibility = {
            "overallScore": 0.85,
            "adaptationType": "parametric",
            "estimatedEffort": "low"
        }
        plan = {
            "overview": "Direct joint mapping possible with scaling for link lengths.",
            "kinematicAdaptation": {
                "Joint limits": "Compatible (95% overlap)",
                "Workspace": "Target workspace encompasses source workspace"
            },
            "codeModifications": [
                {"file": "config/robot.yaml", "changes": ["Update URDF path", "Adjust joint gains"]}
            ]
        }

    if compatibility:
        print(f"\nCompatibility Score: {compatibility.get('overallScore', 0) * 100:.1f}%")
        print(f"Adaptation Type: {compatibility.get('adaptationType', 'unknown')}")
        print(f"Estimated Effort: {compatibility.get('estimatedEffort', 'unknown')}")

    print(f"\nAdaptation Overview:")
    print(plan.get("overview", "No overview available"))

    if plan.get("kinematicAdaptation"):
        print("\nKinematic Adaptations:")
        for key, value in plan["kinematicAdaptation"].items():
            print(f"  - {key}: {value}")

    if plan.get("codeModifications"):
        print("\nRequired Code Modifications:")
        for mod in plan["codeModifications"]:
            print(f"  File: {mod.get('file')}")
            for change in mod.get("changes", []):
                print(f"    - {change}")

    if not analyze_only and compatibility.get("adaptationType") != "impossible":
        if input("\nProceed with adaptation? (y/N): ").lower() == "y":
            print("Generating adapted code...")
            time.sleep(1.5)
            print("Adaptation complete. Created new branch 'adapt/franka-panda'.")


def validate(client, checks: List[str], strict: bool, files: Optional[List[str]]) -> None:
    """Validate safety and compliance."""
    ate_dir = Path(".ate")
    if not ate_dir.exists():
        print("Error: Not a FoodforThought repository.", file=sys.stderr)
        sys.exit(1)

    with open(ate_dir / "config.json") as f:
        config = json.load(f)

    print(f"Running safety validation...")
    print(f"  Repository: {config['name']}")
    print(f"  Checks: {', '.join(checks)}")
    print(f"  Mode: {'strict' if strict else 'standard'}")

    if files:
        print(f"  Files: {', '.join(files)}")

    print("\nAnalyzing codebase...", end="", flush=True)
    time.sleep(1.0)
    print(" Done")

    # Mock Safety validation checks
    validation_results = {
        "collision": {"status": "pass", "details": "No self-collision risks detected in trajectories"},
        "speed": {"status": "pass", "details": "Velocity limits (2.0 m/s) respected"},
        "workspace": {"status": "warning", "details": "End-effector approaches workspace boundary (< 2cm) in 2 files"},
        "force": {"status": "pass", "details": "Torque estimates within limits"},
    }

    print("\nValidation Results:")
    has_issues = False

    if "all" in checks:
        checks = list(validation_results.keys())

    for check in checks:
        if check in validation_results:
            result = validation_results[check]
            status_icon = "✓" if result["status"] == "pass" else "⚠" if result["status"] == "warning" else "✗"
            print(f"  {status_icon} {check.capitalize()}: {result['details']}")

            if result["status"] != "pass":
                has_issues = True

    if has_issues and strict:
        print("\nValidation FAILED in strict mode")
        sys.exit(1)
    elif has_issues:
        print("\nValidation completed with warnings")
    else:
        print("\nValidation PASSED")


def stream(client, action: str, sensors: Optional[List[str]], output: Optional[str],
           format: str) -> None:
    """Stream sensor data."""
    if action == "start":
        if not sensors:
            print("Error: No sensors specified.", file=sys.stderr)
            sys.exit(1)

        print(f"Starting sensor stream...")
        print(f"  Sensors: {', '.join(sensors)}")
        print(f"  Format: {format}")
        if output:
            print(f"  Output: {output}")

        print("\nInitializing stream connection...")
        time.sleep(1)
        print("Stream active.")
        print("Press Ctrl+C to stop.")

        try:
            start_time = time.time()
            frames = 0
            while True:
                time.sleep(1)
                frames += 30
                elapsed = time.time() - start_time
                # Overwrite line with status
                sys.stdout.write(f"\rStreaming: {int(elapsed)}s | Frames: {frames} | Rate: 30fps")
                sys.stdout.flush()
        except KeyboardInterrupt:
            print("\nStream stopped.")

    elif action == "stop":
        print("Stopping sensor stream...")
        # This would stop any active streams

    elif action == "status":
        print("Stream Status:")
        print("  Active streams: None")
        print("  Data rate: 0 MB/s")
        print("\nNo active streams")


def pull(client, skill_id: str, robot: Optional[str], format: str,
         output: str) -> None:
    """Pull skill data for training."""
    print(f"Pulling skill data...")
    print(f"  Skill: {skill_id}")
    if robot:
        print(f"  Robot: {robot}")
    print(f"  Format: {format}")
    print(f"  Output: {output}")

    # Build request params
    params = {"format": format}
    if robot:
        params["robot"] = robot

    try:
        # Get skill data
        response = client._request("GET", f"/skills/{skill_id}/download", params=params)

        skill = response.get("skill", {})
        episodes = response.get("episodes", [])

        # Create output directory
        output_path = Path(output)
        output_path.mkdir(parents=True, exist_ok=True)

        # Save based on format
        if format == "json":
            file_path = output_path / f"{skill_id}.json"
            with open(file_path, "w") as f:
                json.dump(response, f, indent=2)
            print(f"\n✓ Saved to {file_path}")
        else:
            # For RLDS/LeRobot, save the JSON and show instructions
            file_path = output_path / f"{skill_id}.json"
            with open(file_path, "w") as f:
                json.dump(response, f, indent=2)
            print(f"\n✓ Saved JSON data to {file_path}")

            if response.get("instructions"):
                print(f"\nTo load as {format.upper()}:")
                print(response["instructions"].get("python", "See documentation"))

        print(f"\nSkill: {skill.get('name', skill_id)}")
        print(f"Episodes: {len(episodes)}")
        print(f"Actions: {', '.join(skill.get('actionTypes', []))}")

    except Exception as e:
        print(f"\n✗ Failed to pull skill: {e}", file=sys.stderr)
        sys.exit(1)


def upload(client, path: str, robot: str, task: str,
           project: Optional[str]) -> None:
    """Upload demonstrations for labeling."""
    video_path = Path(path)

    if not video_path.exists():
        print(f"Error: File not found: {path}", file=sys.stderr)
        sys.exit(1)

    if not video_path.is_file():
        print(f"Error: Path is not a file: {path}", file=sys.stderr)
        sys.exit(1)

    print(f"Uploading demonstration...")
    print(f"  File: {video_path.name}")
    print(f"  Robot: {robot}")
    print(f"  Task: {task}")
    if project:
        print(f"  Project: {project}")

    # Check file size
    file_size = video_path.stat().st_size
    print(f"  Size: {file_size / 1024 / 1024:.1f} MB")

    try:
        # Upload the file
        with open(video_path, "rb") as f:
            files = {"video": (video_path.name, f, "video/mp4")}
            data = {
                "robot": robot,
                "task": task,
            }
            if project:
                data["projectId"] = project

            # Make multipart request
            url = f"{client.base_url}/labeling/submit"
            response = requests.post(
                url,
                headers={"Authorization": client.headers.get("Authorization", "")},
                files=files,
                data=data,
            )
            response.raise_for_status()
            result = response.json()

        job = result.get("job", {})
        print(f"\n✓ Uploaded successfully!")
        print(f"\nJob ID: {job.get('id')}")
        print(f"Status: {job.get('status')}")
        print(f"\nTrack progress:")
        print(f"  ate labeling-status {job.get('id')}")
        print(f"  https://kindly.fyi/foodforthought/labeling/{job.get('id')}")

    except requests.exceptions.HTTPError as e:
        if e.response.status_code == 401:
            print("\n✗ Error: API key required for uploads.", file=sys.stderr)
            print("  Set ATE_API_KEY environment variable.", file=sys.stderr)
        else:
            print(f"\n✗ Upload failed: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"\n✗ Upload failed: {e}", file=sys.stderr)
        sys.exit(1)


def check_transfer(client, skill: Optional[str], source: str, target: str,
                   min_score: float) -> None:
    """Check skill transfer compatibility between robots."""
    print(f"Checking skill transfer compatibility...")
    print(f"  Source: {source}")
    print(f"  Target: {target}")
    if skill:
        print(f"  Skill: {skill}")

    try:
        body = {
            "sourceRobot": source,
            "targetRobot": target,
        }
        if skill:
            body["skillId"] = skill

        response = client._request("POST", "/skills/check-compatibility", json=body)

        overall = response.get("overallScore", 0)
        adaptation = response.get("adaptationType", "unknown")
        effort = response.get("estimatedEffort", "unknown")
        notes = response.get("adaptationNotes", "")

        # Display results
        print(f"\n{'=' * 50}")
        print(f"Compatibility Results")
        print(f"{'=' * 50}")

        # Color-coded score
        score_pct = overall * 100
        if adaptation == "direct":
            icon = "✓"
        elif adaptation == "retrain":
            icon = "~"
        elif adaptation == "manual":
            icon = "!"
        else:
            icon = "✗"

        print(f"\n{icon} Overall Score: {score_pct:.1f}%")
        print(f"  Adaptation Type: {adaptation}")
        print(f"  Estimated Effort: {effort}")

        print(f"\nScore Breakdown:")
        print(f"  Kinematic: {response.get('kinematicScore', 0) * 100:.1f}%")
        print(f"  Sensor: {response.get('sensorScore', 0) * 100:.1f}%")
        print(f"  Compute: {response.get('computeScore', 0) * 100:.1f}%")

        if notes:
            print(f"\nNotes:")
            for note in notes.split("\n"):
                print(f"  {note}")

        # Check against minimum
        if overall < min_score:
            print(f"\n✗ Score {score_pct:.1f}% is below minimum {min_score * 100:.1f}%")
            sys.exit(1)

    except Exception as e:
        # Mock response for demo
        print(f"\n{'=' * 50}")
        print(f"Compatibility Results (simulated)")
        print(f"{'=' * 50}")
        print(f"\n✓ Overall Score: 85.0%")
        print(f"  Adaptation Type: parametric")
        print(f"  Estimated Effort: low")


def labeling_status(client, job_id: str) -> None:
    """Check the status of a labeling job."""
    print(f"Checking labeling job status...")
    print(f"  Job ID: {job_id}")

    try:
        response = client._request("GET", f"/labeling/{job_id}/status")
        job = response.get("job", {})

        status = job.get("status", "unknown")
        progress = job.get("progress", 0) * 100

        print(f"\nStatus: {status}")
        print(f"Progress: {progress:.0f}%")

        stats = job.get("stats", {})
        if stats:
            print(f"\nLabels: {stats.get('approvedLabels', 0)}/{stats.get('consensusTarget', 3)} needed")
            print(f"Total submissions: {stats.get('totalLabels', 0)}")

        if status == "completed":
            skill_id = job.get("resultSkillId")
            print(f"\n✓ Labeling complete!")
            print(f"Skill ID: {skill_id}")
            print(f"\nPull the labeled data:")
            print(f"  ate pull {skill_id} --format rlds --output ./data/")
        elif status == "in_progress":
            print(f"\n~ Labeling in progress...")
            print(f"View on web: https://kindly.fyi/foodforthought/labeling/{job_id}")

    except Exception as e:
        print(f"\n✗ Failed to get status: {e}", file=sys.stderr)
        sys.exit(1)


def register_parser(subparsers):
    """Register skill commands with argparse."""
    # adapt command
    adapt_parser = subparsers.add_parser("adapt", help="Adapt skills between robots")
    adapt_parser.add_argument("source_robot", help="Source robot")
    adapt_parser.add_argument("target_robot", help="Target robot")
    adapt_parser.add_argument("-r", "--repo-id", help="Repository ID")
    adapt_parser.add_argument("--analyze-only", action="store_true",
        help="Only analyze, don't modify")

    # validate command
    validate_parser = subparsers.add_parser("validate", help="Validate safety and compliance")
    validate_parser.add_argument("-c", "--checks", nargs="+",
        default=["all"], choices=["all", "collision", "speed", "workspace", "force"],
        help="Checks to run")
    validate_parser.add_argument("--strict", action="store_true",
        help="Fail on any warning")
    validate_parser.add_argument("-f", "--files", nargs="+", help="Specific files to check")

    # stream command
    stream_parser = subparsers.add_parser("stream", help="Stream sensor data")
    stream_parser.add_argument("action", choices=["start", "stop", "status"],
        help="Stream action")
    stream_parser.add_argument("-s", "--sensors", nargs="+",
        help="Sensors to stream (for start)")
    stream_parser.add_argument("-o", "--output", help="Output file")
    stream_parser.add_argument("--format", default="json",
        choices=["json", "mcap", "ros2bag"], help="Output format")

    # pull command
    pull_parser = subparsers.add_parser("pull", help="Pull skill data for training")
    pull_parser.add_argument("skill_id", help="Skill ID to pull")
    pull_parser.add_argument("-r", "--robot", help="Filter by robot")
    pull_parser.add_argument("--format", default="json",
        choices=["json", "rlds", "lerobot"], help="Output format")
    pull_parser.add_argument("-o", "--output", default="./data",
        help="Output directory")

    # upload command
    upload_parser = subparsers.add_parser("upload", help="Upload demonstrations for labeling")
    upload_parser.add_argument("path", help="Path to video file")
    upload_parser.add_argument("-r", "--robot", required=True, help="Robot model")
    upload_parser.add_argument("-t", "--task", required=True, help="Task being demonstrated")
    upload_parser.add_argument("-p", "--project", help="Project ID")

    # check-transfer command
    check_transfer_parser = subparsers.add_parser("check-transfer",
        help="Check skill transfer compatibility")
    check_transfer_parser.add_argument("-s", "--skill", help="Specific skill ID")
    check_transfer_parser.add_argument("--source", required=True, help="Source robot")
    check_transfer_parser.add_argument("--target", required=True, help="Target robot")
    check_transfer_parser.add_argument("--min-score", type=float, default=0.0,
        help="Minimum acceptable score")

    # labeling-status command
    labeling_status_parser = subparsers.add_parser("labeling-status",
        help="Check labeling job status")
    labeling_status_parser.add_argument("job_id", help="Job ID")


def handle(client, args):
    """Handle skill commands."""
    if args.command == "adapt":
        adapt(client, args.source_robot, args.target_robot,
              getattr(args, 'repo_id', None), args.analyze_only)
    elif args.command == "validate":
        validate(client, args.checks, args.strict, args.files)
    elif args.command == "stream":
        stream(client, args.action, args.sensors, args.output, args.format)
    elif args.command == "pull":
        pull(client, args.skill_id, args.robot, args.format, args.output)
    elif args.command == "upload":
        upload(client, args.path, args.robot, args.task, args.project)
    elif args.command == "check-transfer":
        check_transfer(client, args.skill, args.source, args.target, args.min_score)
    elif args.command == "labeling-status":
        labeling_status(client, args.job_id)
