"""
Team collaboration commands for FoodforThought CLI.

Commands:
- ate team create  - Create a new team
- ate team invite  - Invite a user to a team
- ate team list    - List teams you belong to
- ate team share   - Share a skill with a team
"""

import sys
from typing import Optional


def team_create(client, name: str, description: Optional[str]) -> None:
    """Create a new team."""
    print(f"Creating team: {name}")

    try:
        # Generate slug from name
        slug = name.lower().replace(" ", "-")
        slug = ''.join(c for c in slug if c.isalnum() or c == '-')

        response = client._request("POST", "/teams", json={
            "name": name,
            "slug": slug,
            "description": description,
        })

        team = response.get("team", {})
        print(f"\n✓ Team created!")
        print(f"  Name: {team.get('name')}")
        print(f"  Slug: {team.get('slug')}")
        print(f"  ID: {team.get('id')}")

    except Exception as e:
        print(f"\n✗ Failed to create team: {e}", file=sys.stderr)
        sys.exit(1)


def team_invite(client, email: str, team_slug: str, role: str) -> None:
    """Invite a user to a team."""
    print(f"Inviting {email} to team...")
    print(f"  Team: {team_slug}")
    print(f"  Role: {role}")

    try:
        client._request("POST", f"/teams/{team_slug}/members", json={
            "email": email,
            "role": role,
        })

        print(f"\n✓ Invitation sent!")

    except Exception as e:
        print(f"\n✗ Failed to invite: {e}", file=sys.stderr)
        sys.exit(1)


def team_list(client) -> None:
    """List teams the user belongs to."""
    print("Fetching teams...")

    try:
        response = client._request("GET", "/teams")
        teams = response.get("teams", [])

        if not teams:
            print("\nYou are not a member of any teams.")
            print("Create one with: ate team create <name>")
            return

        print(f"\n{'=' * 60}")
        print(f"{'Team Name':<25} {'Role':<15} {'Members':<10}")
        print(f"{'=' * 60}")

        for team in teams:
            name = team.get("name", "")[:23]
            role = team.get("role", "member")[:13]
            members = team.get("memberCount", 0)
            print(f"{name:<25} {role:<15} {members:<10}")

        print(f"{'=' * 60}")

    except Exception as e:
        print(f"\n✗ Failed to list teams: {e}", file=sys.stderr)
        sys.exit(1)


def team_share(client, skill_id: str, team_slug: str) -> None:
    """Share a skill with a team."""
    print(f"Sharing skill with team...")
    print(f"  Skill: {skill_id}")
    print(f"  Team: {team_slug}")

    try:
        client._request("POST", f"/skills/{skill_id}/share", json={
            "teamSlug": team_slug,
        })

        print(f"\n✓ Skill shared with team!")

    except Exception as e:
        print(f"\n✗ Failed to share: {e}", file=sys.stderr)
        sys.exit(1)


def register_parser(subparsers):
    """Register team commands with argparse."""
    team_parser = subparsers.add_parser("team", help="Team collaboration management")
    team_subparsers = team_parser.add_subparsers(dest="team_action", help="Team action")

    # team create
    team_create_parser = team_subparsers.add_parser("create", help="Create a new team")
    team_create_parser.add_argument("name", help="Team name")
    team_create_parser.add_argument("-d", "--description", help="Team description")

    # team invite
    team_invite_parser = team_subparsers.add_parser("invite", help="Invite user to team")
    team_invite_parser.add_argument("email", help="Email of user to invite")
    team_invite_parser.add_argument("-t", "--team", required=True, help="Team slug")
    team_invite_parser.add_argument("-r", "--role", default="member",
                                   choices=["owner", "admin", "member", "viewer"],
                                   help="Role to assign (default: member)")

    # team list
    team_subparsers.add_parser("list", help="List teams you belong to")

    # team share (skill share with team)
    team_share_parser = team_subparsers.add_parser("share", help="Share skill with team")
    team_share_parser.add_argument("skill_id", help="Skill ID to share")
    team_share_parser.add_argument("-t", "--team", required=True, help="Team slug")


def handle(client, args):
    """Handle team commands."""
    if args.team_action == "create":
        team_create(client, args.name, args.description)
    elif args.team_action == "invite":
        team_invite(client, args.email, args.team, args.role)
    elif args.team_action == "list":
        team_list(client)
    elif args.team_action == "share":
        team_share(client, args.skill_id, args.team)
    else:
        print("Usage: ate team {create|invite|list|share}")
        sys.exit(1)
