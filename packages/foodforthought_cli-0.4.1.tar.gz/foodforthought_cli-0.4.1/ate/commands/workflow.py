"""
Workflow commands for FoodforThought CLI.

Commands:
- ate workflow validate  - Validate a workflow YAML file
- ate workflow run       - Run a workflow
- ate workflow export    - Export workflow to different formats
"""

import json
import random
import sys
import time
from pathlib import Path
from typing import Optional, Dict


def workflow_validate(client, path: str) -> None:
    """Validate a workflow YAML file."""
    import yaml

    workflow_path = Path(path)
    if not workflow_path.exists():
        print(f"Error: File not found: {path}", file=sys.stderr)
        sys.exit(1)

    print(f"Validating workflow: {path}")

    try:
        with open(workflow_path) as f:
            workflow_data = yaml.safe_load(f)

        # Basic validation
        errors = []
        warnings = []

        # Required fields
        if not workflow_data.get("name"):
            errors.append("Missing required field: name")
        if not workflow_data.get("steps"):
            errors.append("Missing required field: steps")
        elif not isinstance(workflow_data["steps"], list):
            errors.append("Steps must be an array")
        elif len(workflow_data["steps"]) == 0:
            errors.append("Workflow must have at least one step")

        # Validate steps
        step_ids = set()
        for i, step in enumerate(workflow_data.get("steps", [])):
            step_id = step.get("id", f"step_{i}")

            if not step.get("id"):
                errors.append(f"Step {i+1}: Missing required field 'id'")
            elif step["id"] in step_ids:
                errors.append(f"Duplicate step ID: {step['id']}")
            step_ids.add(step_id)

            if not step.get("skill"):
                errors.append(f"Step '{step_id}': Missing required field 'skill'")

        # Check dependency references
        for step in workflow_data.get("steps", []):
            for dep in step.get("depends_on", []):
                if dep not in step_ids:
                    errors.append(f"Step '{step.get('id')}' depends on unknown step '{dep}'")

        # Print results
        print(f"\n{'=' * 50}")
        print(f"Validation Results")
        print(f"{'=' * 50}")

        print(f"\nWorkflow: {workflow_data.get('name', 'Unnamed')}")
        print(f"Version: {workflow_data.get('version', '1.0.0')}")
        print(f"Steps: {len(workflow_data.get('steps', []))}")

        if errors:
            print(f"\n✗ Validation FAILED")
            print(f"\nErrors ({len(errors)}):")
            for error in errors:
                print(f"  ✗ {error}")
            sys.exit(1)
        else:
            print(f"\n✓ Workflow is valid!")
            if warnings:
                print(f"\nWarnings ({len(warnings)}):")
                for warning in warnings:
                    print(f"  ⚠ {warning}")

    except Exception as e:
        if "yaml" in str(type(e).__module__):
            print(f"\n✗ Invalid YAML syntax: {e}", file=sys.stderr)
        else:
            print(f"\n✗ Validation failed: {e}", file=sys.stderr)
        sys.exit(1)


def workflow_run(client, path: str, sim: bool, dry_run: bool) -> None:
    """Run a workflow."""
    import yaml

    workflow_path = Path(path)
    if not workflow_path.exists():
        print(f"Error: File not found: {path}", file=sys.stderr)
        sys.exit(1)

    with open(workflow_path) as f:
        workflow_data = yaml.safe_load(f)

    print(f"Running workflow: {workflow_data.get('name', 'Unnamed')}")
    print(f"  Mode: {'Simulation' if sim else 'Real Robot'}")
    print(f"  Dry Run: {dry_run}")

    if dry_run:
        print("\n[DRY RUN] Execution plan:")
        for i, step in enumerate(workflow_data.get("steps", [])):
            deps = step.get("depends_on", [])
            deps_str = f" (after: {', '.join(deps)})" if deps else ""
            print(f"  {i+1}. {step.get('id')}: {step.get('skill')}{deps_str}")
        print("\n✓ Dry run complete. No actions taken.")
        return

    # Simulate execution
    print("\n" + "=" * 50)
    print("Executing workflow...")
    print("=" * 50)

    for i, step in enumerate(workflow_data.get("steps", [])):
        step_id = step.get("id", f"step_{i}")
        skill = step.get("skill", "unknown")

        print(f"\n[{i+1}/{len(workflow_data.get('steps', []))}] {step_id}")
        print(f"  Skill: {skill}")

        if sim:
            print(f"  Mode: Simulation")
            time.sleep(random.uniform(0.5, 1.5))

            # Simulate result
            success = random.random() > 0.1
            if success:
                print(f"  Status: ✓ Completed")
            else:
                print(f"  Status: ✗ Failed")
                if step.get("on_failure") == "fail":
                    print("\nWorkflow FAILED")
                    sys.exit(1)
        else:
            print(f"  Status: Would execute on real robot")

    print("\n" + "=" * 50)
    print("✓ Workflow completed successfully!")


def workflow_export(client, path: str, format: str, output: Optional[str]) -> None:
    """Export workflow to different formats."""
    import yaml

    workflow_path = Path(path)
    if not workflow_path.exists():
        print(f"Error: File not found: {path}", file=sys.stderr)
        sys.exit(1)

    with open(workflow_path) as f:
        workflow_data = yaml.safe_load(f)

    print(f"Exporting workflow: {workflow_data.get('name', 'Unnamed')}")
    print(f"  Format: {format}")

    if format == "ros2":
        # Generate ROS2 launch file
        launch_content = _generate_ros2_launch(workflow_data)
        output_file = output or f"{workflow_data.get('name', 'workflow').replace(' ', '_').lower()}_launch.py"

        with open(output_file, 'w') as f:
            f.write(launch_content)

        print(f"\n✓ Exported to: {output_file}")

    elif format == "json":
        output_file = output or f"{workflow_data.get('name', 'workflow').replace(' ', '_').lower()}.json"
        with open(output_file, 'w') as f:
            json.dump(workflow_data, f, indent=2)
        print(f"\n✓ Exported to: {output_file}")

    else:
        print(f"Unsupported format: {format}", file=sys.stderr)
        sys.exit(1)


def _generate_ros2_launch(workflow: Dict) -> str:
    """Generate ROS2 launch file from workflow."""
    steps_code = ""
    for step in workflow.get("steps", []):
        step_id = step.get("id", "step")
        skill = step.get("skill", "unknown")
        inputs = step.get("inputs", {})

        inputs_str = ", ".join([f"'{k}': '{v}'" for k, v in inputs.items()])

        steps_code += f'''
    # Step: {step_id}
    {step_id}_node = Node(
        package='skill_executor',
        executable='run_skill',
        name='{step_id}',
        parameters=[{{
            'skill_id': '{skill}',
            'inputs': {{{inputs_str}}},
        }}],
    )
    ld.add_action({step_id}_node)
'''

    return f'''#!/usr/bin/env python3
"""
ROS2 Launch File - {workflow.get('name', 'Workflow')}
Generated by FoodforThought CLI

Version: {workflow.get('version', '1.0.0')}
"""

from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    ld = LaunchDescription()
{steps_code}
    return ld
'''


def register_parser(subparsers):
    """Register workflow commands with argparse."""
    workflow_parser = subparsers.add_parser("workflow", help="Manage skill workflows/pipelines")
    workflow_subparsers = workflow_parser.add_subparsers(dest="workflow_action", help="Workflow action")

    # workflow validate
    workflow_validate_parser = workflow_subparsers.add_parser("validate",
                                                              help="Validate workflow YAML")
    workflow_validate_parser.add_argument("path", help="Path to workflow YAML file")

    # workflow run
    workflow_run_parser = workflow_subparsers.add_parser("run", help="Run a workflow")
    workflow_run_parser.add_argument("path", help="Path to workflow YAML file")
    workflow_run_parser.add_argument("--sim", action="store_true",
                                    help="Run in simulation mode")
    workflow_run_parser.add_argument("--dry-run", action="store_true",
                                    help="Show execution plan without running")

    # workflow export
    workflow_export_parser = workflow_subparsers.add_parser("export",
                                                           help="Export workflow to other formats")
    workflow_export_parser.add_argument("path", help="Path to workflow YAML file")
    workflow_export_parser.add_argument("-f", "--format", default="ros2",
                                       choices=["ros2", "json"],
                                       help="Export format (default: ros2)")
    workflow_export_parser.add_argument("-o", "--output", help="Output file path")


def handle(client, args):
    """Handle workflow commands."""
    if args.workflow_action == "validate":
        workflow_validate(client, args.path)
    elif args.workflow_action == "run":
        workflow_run(client, args.path, args.sim, args.dry_run)
    elif args.workflow_action == "export":
        workflow_export(client, args.path, args.format, args.output)
    else:
        print("Usage: ate workflow {validate|run|export}")
        sys.exit(1)
