"""
Object detection for robotics.

Provides:
- Simple color-based detection (no ML dependencies)
- Cloud vision API integration (optional)
- Local model inference (requires additional setup)

Example:
    from ate.detection import ColorDetector, detect_objects
    from ate.drivers import MechDogDriver

    dog = MechDogDriver(config=config)
    dog.connect()

    # Get image from camera
    image = dog.get_image()

    # Detect colored objects (no ML required)
    detector = ColorDetector()
    detections = detector.detect(image, target_colors=["red", "blue", "green"])

    for det in detections:
        print(f"Found {det.label} at ({det.x}, {det.y})")
"""

from .color_detector import ColorDetector, ColorRange
from .base import DetectorBase, Detection, BoundingBox
from .trash_detector import TrashDetector

__all__ = [
    "ColorDetector",
    "ColorRange",
    "DetectorBase",
    "Detection",
    "BoundingBox",
    "TrashDetector",
]
