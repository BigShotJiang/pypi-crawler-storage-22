"""
Base classes for object detection.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import List, Optional, Tuple, Any
from enum import Enum, auto


@dataclass
class BoundingBox:
    """Bounding box for detected object."""
    x: int          # Top-left x
    y: int          # Top-left y
    width: int      # Box width
    height: int     # Box height

    @property
    def center(self) -> Tuple[int, int]:
        """Get center point."""
        return (self.x + self.width // 2, self.y + self.height // 2)

    @property
    def area(self) -> int:
        """Get area in pixels."""
        return self.width * self.height

    def to_tuple(self) -> Tuple[int, int, int, int]:
        """Convert to (x, y, w, h) tuple."""
        return (self.x, self.y, self.width, self.height)

    def contains(self, x: int, y: int) -> bool:
        """Check if point is inside box."""
        return (self.x <= x <= self.x + self.width and
                self.y <= y <= self.y + self.height)


@dataclass
class Detection:
    """A detected object."""
    label: str              # Object class label
    confidence: float       # Detection confidence (0-1)
    bbox: BoundingBox       # Bounding box
    mask: Optional[Any] = None  # Optional segmentation mask
    metadata: dict = field(default_factory=dict)

    @property
    def center(self) -> Tuple[int, int]:
        """Get center of detection."""
        return self.bbox.center

    @property
    def area(self) -> int:
        """Get area of detection."""
        return self.bbox.area


class DetectorBase(ABC):
    """
    Abstract base class for object detectors.

    Subclasses implement different detection strategies:
    - ColorDetector: Simple color-based detection
    - YOLODetector: Neural network based
    - CloudDetector: Cloud vision API
    """

    @abstractmethod
    def detect(self, image: Any, **kwargs) -> List[Detection]:
        """
        Detect objects in image.

        Args:
            image: Input image (RGB bytes, PIL Image, or numpy array)
            **kwargs: Detector-specific options

        Returns:
            List of Detection objects
        """
        pass

    @abstractmethod
    def detect_class(self, image: Any, class_name: str, **kwargs) -> List[Detection]:
        """
        Detect objects of a specific class.

        Args:
            image: Input image
            class_name: Class to detect (e.g., "trash", "person", "bottle")
            **kwargs: Detector-specific options

        Returns:
            List of Detection objects matching the class
        """
        pass

    def find_nearest(self, image: Any, class_name: str, reference_point: Tuple[int, int] = None) -> Optional[Detection]:
        """
        Find the nearest object of a class.

        Args:
            image: Input image
            class_name: Class to find
            reference_point: Reference point (default: image center)

        Returns:
            Nearest Detection or None
        """
        detections = self.detect_class(image, class_name)
        if not detections:
            return None

        # Default to image center if no reference point
        if reference_point is None:
            # Estimate from first detection's image size
            reference_point = (320, 240)  # Default VGA center

        # Find nearest
        def distance(det):
            cx, cy = det.center
            rx, ry = reference_point
            return ((cx - rx) ** 2 + (cy - ry) ** 2) ** 0.5

        return min(detections, key=distance)

    def find_largest(self, image: Any, class_name: str) -> Optional[Detection]:
        """
        Find the largest object of a class.

        Args:
            image: Input image
            class_name: Class to find

        Returns:
            Largest Detection or None
        """
        detections = self.detect_class(image, class_name)
        if not detections:
            return None

        return max(detections, key=lambda d: d.area)
