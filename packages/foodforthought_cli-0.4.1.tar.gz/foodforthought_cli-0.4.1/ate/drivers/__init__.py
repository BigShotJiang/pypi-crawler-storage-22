"""
Hardware drivers for specific robots.

Each driver implements the appropriate interfaces from ate.interfaces.

Example:
    from ate.drivers import MechDogDriver, MechDogConfig

    # Connect to MechDog with camera
    config = MechDogConfig(
        port="/dev/cu.usbserial-10",
        has_camera=True,
        camera_ip="192.168.1.100"
    )
    dog = MechDogDriver(config=config)
    dog.connect()

    # Use through abstract interface
    dog.stand()
    dog.walk(Vector3.forward(), speed=0.3)
    dog.set_body_height(0.15)

    # Capture image from visual module
    image = dog.get_image()

    dog.stop()
    dog.disconnect()
"""

from .mechdog import MechDogDriver, MechDogConfig
from .wifi_camera import WiFiCamera, WiFiCameraConfig, discover_cameras

__all__ = [
    "MechDogDriver",
    "MechDogConfig",
    "WiFiCamera",
    "WiFiCameraConfig",
    "discover_cameras",
]
