"""
Sensor interfaces for robot perception.

These interfaces abstract different sensor types so behaviors
can work across robots with different sensor configurations.

Design principle: A behavior that needs distance sensing can use
ANY implementation of DistanceSensorInterface - ultrasonic, lidar,
depth camera, or even visual estimation.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Optional, List, Tuple
from enum import Enum, auto

from .types import ActionResult


class DistanceSensorType(Enum):
    """Type of distance sensor."""
    ULTRASONIC = auto()      # HC-SR04, etc.
    INFRARED = auto()        # IR proximity
    LIDAR_SINGLE = auto()    # Single-point lidar
    LIDAR_2D = auto()        # 2D scanning lidar
    DEPTH_CAMERA = auto()    # Depth camera center point
    VISUAL_ESTIMATION = auto()  # Estimated from RGB camera


@dataclass
class DistanceReading:
    """A distance measurement."""
    distance: float          # Distance in meters
    valid: bool = True       # Whether reading is valid
    sensor_type: DistanceSensorType = DistanceSensorType.ULTRASONIC
    timestamp: float = 0.0   # Seconds since epoch
    confidence: float = 1.0  # Confidence in reading (0-1)

    @classmethod
    def invalid(cls) -> "DistanceReading":
        """Create an invalid reading."""
        return cls(distance=0.0, valid=False)


class DistanceSensorInterface(ABC):
    """
    Interface for distance/proximity sensing.

    Can be implemented by:
    - Ultrasonic sensors (HC-SR04, etc.)
    - IR proximity sensors
    - Single-point lidar
    - Depth camera (center pixel or ROI average)
    - Visual estimation (object size in image)

    This abstraction allows behaviors like "approach target" to work
    on any robot with any distance sensing capability.

    Example:
        # Works with any implementation
        sensor: DistanceSensorInterface = robot.get_distance_sensor()

        while True:
            reading = sensor.get_distance()
            if reading.valid and reading.distance < 0.15:
                robot.stop()
                break
            robot.walk_forward(speed=0.1)
    """

    @abstractmethod
    def get_distance(self) -> DistanceReading:
        """
        Get current distance reading.

        Returns:
            DistanceReading with distance in meters
        """
        pass

    @abstractmethod
    def get_min_range(self) -> float:
        """
        Get minimum measurable range in meters.

        Returns below this distance are unreliable.
        """
        pass

    @abstractmethod
    def get_max_range(self) -> float:
        """
        Get maximum measurable range in meters.

        Returns above this distance are unreliable.
        """
        pass

    def get_sensor_type(self) -> DistanceSensorType:
        """Get the type of distance sensor."""
        return DistanceSensorType.ULTRASONIC  # Default

    def is_obstacle_detected(self, threshold: float = 0.20) -> bool:
        """
        Check if an obstacle is within threshold distance.

        Args:
            threshold: Distance threshold in meters

        Returns:
            True if obstacle detected within threshold
        """
        reading = self.get_distance()
        return reading.valid and reading.distance < threshold


class VisualDistanceEstimator(DistanceSensorInterface):
    """
    Estimate distance from visual object size.

    When no hardware distance sensor is available, we can estimate
    distance based on the apparent size of a detected object.

    This uses the pinhole camera model:
        distance = (known_size * focal_length) / apparent_size

    For unknown objects, we use heuristics based on object category.
    """

    # Typical object sizes in meters (width)
    TYPICAL_SIZES = {
        "bottle": 0.07,
        "can": 0.065,
        "wrapper": 0.10,
        "paper": 0.20,
        "plastic": 0.10,
        "metal": 0.08,
        "unknown": 0.10,
    }

    def __init__(
        self,
        image_width: int = 640,
        image_height: int = 480,
        fov_horizontal: float = 60.0,  # Degrees
    ):
        """
        Initialize visual distance estimator.

        Args:
            image_width: Camera image width in pixels
            image_height: Camera image height in pixels
            fov_horizontal: Horizontal field of view in degrees
        """
        self.image_width = image_width
        self.image_height = image_height
        self.fov_horizontal = fov_horizontal

        # Calculate focal length in pixels
        import math
        self.focal_length = image_width / (2 * math.tan(math.radians(fov_horizontal / 2)))

        self._last_reading: Optional[DistanceReading] = None

    def estimate_from_detection(
        self,
        bbox_width: int,
        object_type: str = "unknown",
        known_size: Optional[float] = None,
    ) -> DistanceReading:
        """
        Estimate distance from detected object bounding box.

        Args:
            bbox_width: Width of bounding box in pixels
            object_type: Type of object (for size lookup)
            known_size: Known real-world size in meters (overrides lookup)

        Returns:
            DistanceReading with estimated distance
        """
        import time

        if bbox_width <= 0:
            return DistanceReading.invalid()

        # Get object size
        real_size = known_size or self.TYPICAL_SIZES.get(object_type, 0.10)

        # Estimate distance using pinhole model
        distance = (real_size * self.focal_length) / bbox_width

        # Confidence decreases with smaller bounding boxes (more uncertainty)
        confidence = min(1.0, bbox_width / 50.0)

        reading = DistanceReading(
            distance=distance,
            valid=True,
            sensor_type=DistanceSensorType.VISUAL_ESTIMATION,
            timestamp=time.time(),
            confidence=confidence,
        )

        self._last_reading = reading
        return reading

    def get_distance(self) -> DistanceReading:
        """Get last estimated distance."""
        if self._last_reading:
            return self._last_reading
        return DistanceReading.invalid()

    def get_min_range(self) -> float:
        return 0.1  # 10cm minimum

    def get_max_range(self) -> float:
        return 5.0  # 5m maximum (very rough beyond this)

    def get_sensor_type(self) -> DistanceSensorType:
        return DistanceSensorType.VISUAL_ESTIMATION


@dataclass
class ProximitySensorReading:
    """Reading from proximity/bump sensors."""
    triggered: bool          # Whether sensor is triggered
    sensor_id: str           # Sensor identifier
    timestamp: float = 0.0


class ProximitySensorInterface(ABC):
    """
    Interface for proximity/bump sensors.

    These are simple binary sensors that detect contact or very close proximity.
    Common on wheeled robots and robot vacuums.
    """

    @abstractmethod
    def get_proximity_sensors(self) -> List[ProximitySensorReading]:
        """Get readings from all proximity sensors."""
        pass

    @abstractmethod
    def is_any_triggered(self) -> bool:
        """Check if any proximity sensor is triggered."""
        pass
