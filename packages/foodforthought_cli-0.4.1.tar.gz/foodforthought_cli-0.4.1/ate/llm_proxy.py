"""
LLM Proxy - Routes AI requests through FoodforThought edge function.

Benefits:
- No API keys needed on client
- Automatic usage metering per user
- Rate limiting (50/week free, 500/week pro)
- Billing integration via usage_logs table

Usage:
    from ate.llm_proxy import LLMProxy

    proxy = LLMProxy()
    response = proxy.chat(
        messages=[{"role": "user", "content": "Hello"}],
        model="claude-3-5-haiku-20241022",
        max_tokens=150,
    )
"""

import json
from pathlib import Path
from typing import Dict, Any, List, Optional
from dataclasses import dataclass

try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False


# Configuration
EDGE_FUNCTION_URL = "https://tbkczrruqxopscwqxntr.supabase.co/functions/v1/chat-proxy"
CONFIG_DIR = Path.home() / ".ate"
CONFIG_FILE = CONFIG_DIR / "config.json"


@dataclass
class LLMResponse:
    """Parsed response from LLM."""
    content: str
    input_tokens: int
    output_tokens: int
    model: str
    stop_reason: str


class LLMProxyError(Exception):
    """Error from LLM proxy."""
    def __init__(self, message: str, status_code: Optional[int] = None, details: Optional[str] = None):
        super().__init__(message)
        self.status_code = status_code
        self.details = details


class LLMProxy:
    """
    Proxy for LLM requests through FoodforThought edge function.

    Handles authentication, rate limiting, and usage tracking automatically.
    """

    def __init__(self, access_token: Optional[str] = None):
        """
        Initialize proxy.

        Args:
            access_token: Optional auth token. If not provided, reads from CLI config.
        """
        if not HAS_REQUESTS:
            raise ImportError("requests module required. Install with: pip install requests")

        self.access_token = access_token or self._load_token()
        self.base_url = EDGE_FUNCTION_URL

    def _load_token(self) -> Optional[str]:
        """Load access token from CLI config file."""
        if not CONFIG_FILE.exists():
            return None

        try:
            with open(CONFIG_FILE) as f:
                config = json.load(f)
                return config.get("access_token")
        except Exception:
            return None

    def chat(
        self,
        messages: List[Dict[str, Any]],
        model: str = "claude-3-5-haiku-20241022",
        max_tokens: int = 1024,
        temperature: float = 0.7,
        system: Optional[str] = None,
        stream: bool = False,
    ) -> LLMResponse:
        """
        Send chat completion request through edge function.

        Args:
            messages: List of message dicts with 'role' and 'content'
            model: Model to use (default: claude-3-5-haiku-20241022)
            max_tokens: Maximum tokens in response
            temperature: Sampling temperature
            system: Optional system prompt
            stream: Whether to stream (not yet supported)

        Returns:
            LLMResponse with content and token usage

        Raises:
            LLMProxyError: On API errors or auth issues
        """
        if stream:
            raise NotImplementedError("Streaming not yet implemented in proxy")

        # Build request
        all_messages = []
        if system:
            all_messages.append({"role": "system", "content": system})
        all_messages.extend(messages)

        payload = {
            "messages": all_messages,
            "model": model,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "stream": False,
        }

        headers = {
            "Content-Type": "application/json",
        }

        # Add auth header if we have a token
        if self.access_token:
            headers["Authorization"] = f"Bearer {self.access_token}"
        else:
            raise LLMProxyError(
                "Not authenticated. Run 'ate login' first.",
                status_code=401,
            )

        # Make request
        try:
            response = requests.post(
                self.base_url,
                json=payload,
                headers=headers,
                timeout=60,
            )
        except requests.RequestException as e:
            raise LLMProxyError(f"Request failed: {e}")

        # Parse response
        if response.status_code == 401:
            raise LLMProxyError(
                "Authentication failed. Try 'ate login' to re-authenticate.",
                status_code=401,
            )

        if response.status_code == 402:
            # Rate limit exceeded
            data = response.json()
            usage = data.get("usage", {})
            raise LLMProxyError(
                f"Rate limit exceeded: {usage.get('current', '?')}/{usage.get('limit', '?')} requests this week. "
                f"Resets at {usage.get('resetsAt', 'next week')}. "
                f"Upgrade at {data.get('upgrade_url', 'https://artifex.kindly.fyi/upgrade')}",
                status_code=402,
                details=json.dumps(data),
            )

        if response.status_code != 200:
            try:
                error_data = response.json()
                error_msg = error_data.get("message") or error_data.get("error") or "Unknown error"
                details = error_data.get("details")
            except Exception:
                error_msg = response.text or "Unknown error"
                details = None

            raise LLMProxyError(
                f"LLM request failed: {error_msg}",
                status_code=response.status_code,
                details=details,
            )

        # Parse successful response (Anthropic format)
        data = response.json()

        # Extract content from Anthropic response format
        content = ""
        if "content" in data:
            # Anthropic format: {"content": [{"type": "text", "text": "..."}]}
            for block in data["content"]:
                if block.get("type") == "text":
                    content += block.get("text", "")
        elif "choices" in data:
            # OpenAI format
            content = data["choices"][0]["message"]["content"]
        else:
            content = str(data)

        # Extract usage
        usage = data.get("usage", {})
        input_tokens = usage.get("input_tokens", 0)
        output_tokens = usage.get("output_tokens", 0)

        return LLMResponse(
            content=content,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            model=data.get("model", model),
            stop_reason=data.get("stop_reason", "unknown"),
        )

    def is_authenticated(self) -> bool:
        """Check if we have a valid access token."""
        return bool(self.access_token)


def get_proxy() -> LLMProxy:
    """
    Get a configured LLM proxy instance.

    Returns:
        LLMProxy instance ready to use

    Raises:
        LLMProxyError: If not authenticated
    """
    proxy = LLMProxy()
    if not proxy.is_authenticated():
        raise LLMProxyError(
            "Not authenticated. Run 'ate login' to authenticate with FoodforThought."
        )
    return proxy
