"""ATE Memory Library - Core memory operations with memvid-sdk backend."""

from .store import MemoryStore
from .search import SearchResult
from .export import MemoryInfo
from .merge import merge_memories
from .embeddings import EmbeddingConfig, EmbeddingManager
from .reranker import RerankConfig, LLMReranker
from .context import ContextManager, MemoryContext, MemoryMetadata

# Cryptography functionality (lazy imported)
from . import crypto

# Migration module imports
from . import migrate
from .migrate import (
    VectorRecord,
    MigrationEstimate,
    MigrationResult,
    MigrationCheckpoint,
    MigrationSource,
    MigrationPipeline,
    PineconeMigrationSource,
    QdrantMigrationSource,
    WeaviateMigrationSource,
    ChromaMigrationSource
)

__all__ = [
    'MemoryStore', 'SearchResult', 'MemoryInfo', 'merge_memories',
    'EmbeddingConfig', 'EmbeddingManager', 'RerankConfig', 'LLMReranker',
    'ContextManager', 'MemoryContext', 'MemoryMetadata',
    # Migration exports
    'migrate', 'VectorRecord', 'MigrationEstimate', 'MigrationResult', 
    'MigrationCheckpoint', 'MigrationSource', 'MigrationPipeline',
    'PineconeMigrationSource', 'QdrantMigrationSource', 'WeaviateMigrationSource',
    'ChromaMigrationSource',
    # Cryptography exports
    'crypto'
]