"""Memory capsule functionality."""

def get_builder():
    """Lazy import for CapsuleBuilder."""
    from .builder import CapsuleBuilder
    return CapsuleBuilder

def get_reader():
    """Lazy import for CapsuleReader."""
    from .reader import CapsuleReader
    return CapsuleReader

def get_ingestor():
    """Lazy import for CapsuleIngestor.""" 
    from .ingest import CapsuleIngestor
    return CapsuleIngestor


# get_transfer() reserved for future NoChat capsule transfer (Layer 5)