"""Capsule builder functionality."""

import json
import os
import time
import zipfile
from dataclasses import dataclass, field
from typing import Optional
from enum import Enum


class CapsuleFormat(Enum):
    """Capsule format version."""
    V1 = "1.0"


@dataclass
class CapsuleManifest:
    """Metadata about a capsule's contents and origin."""
    format_version: str = "1.0"
    name: str = ""                          
    description: str = ""                   
    author: str = ""                        
    author_fingerprint: Optional[str] = None
    created_at: float = 0.0                 
    memories: list[dict] = field(default_factory=list)
    trains: list[dict] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)
    license: str = "private"                
    signature: Optional[str] = None         


@dataclass
class CapsuleBuildResult:
    """Result of building a capsule."""
    path: str                   
    name: str                   
    total_memories: int         
    total_trains: int           
    size_bytes: int             
    signed: bool                


class CapsuleBuilder:
    """Build a .capsule archive from local memories and trains.
    
    Usage:
        builder = CapsuleBuilder(name="python-knowledge", author="agent-alice")
        builder.add_memory("/path/to/python.mv2")
        builder.add_train("/path/to/tips.mv2", name="tips")
        builder.set_description("Everything I know about Python")
        builder.add_tags(["python", "programming", "tips"])
        result = builder.build("/output/python-knowledge.capsule")
    """
    
    def __init__(self, name: str, author: str = "",
                 description: str = "", license: str = "private"):
        """Initialize a capsule builder.
        
        Args:
            name: Human-readable capsule name.
            author: Author identifier (agent name or human name).
            description: What this capsule contains.
            license: License string (default: private).
        """
        self.name = name
        self.author = author
        self.description = description
        self.license = license
        self.memories = []  # List of (path, include_sig, include_chain) tuples
        self.trains = []    # List of (path, name) tuples
        self.readme_text = None
        self.tags = []
        self.sign_key = None
    
    def add_memory(self, mv2_path: str, include_sig: bool = True,
                   include_chain: bool = True) -> 'CapsuleBuilder':
        """Add a .mv2 memory file to the capsule.
        
        Automatically includes .sig and .chain sidecars if they exist
        and include flags are True.
        
        Args:
            mv2_path: Path to the .mv2 file.
            include_sig: Include .mv2.sig if it exists.
            include_chain: Include .mv2.chain if it exists.
        
        Returns:
            self (for chaining).
        
        Raises:
            FileNotFoundError: If mv2_path doesn't exist.
        """
        if not os.path.exists(mv2_path):
            raise FileNotFoundError(f"Memory file not found: {mv2_path}")
        
        self.memories.append((mv2_path, include_sig, include_chain))
        return self
    
    def add_train(self, mv2_path: str, name: Optional[str] = None) -> 'CapsuleBuilder':
        """Add a train of thought .mv2 file.
        
        Args:
            mv2_path: Path to the train .mv2 file.
            name: Optional name override (default: filename stem).
        
        Returns:
            self (for chaining).
        """
        if not os.path.exists(mv2_path):
            raise FileNotFoundError(f"Train file not found: {mv2_path}")
        
        if name is None:
            name = os.path.splitext(os.path.basename(mv2_path))[0]
        
        self.trains.append((mv2_path, name))
        return self
    
    def add_readme(self, text: str) -> 'CapsuleBuilder':
        """Add a README.md to the capsule.
        
        Args:
            text: Markdown content.
        
        Returns:
            self (for chaining).
        """
        self.readme_text = text
        return self
    
    def set_description(self, description: str) -> 'CapsuleBuilder':
        """Set capsule description."""
        self.description = description
        return self
    
    def add_tags(self, tags: list[str]) -> 'CapsuleBuilder':
        """Add searchable tags."""
        self.tags.extend(tags)
        return self
    
    def sign(self, key_name: str) -> 'CapsuleBuilder':
        """Sign the manifest with an Ed25519 key (from Phase 8 KeyManager).
        
        Args:
            key_name: Name of the Ed25519 key to sign with.
        
        Returns:
            self (for chaining).
        """
        self.sign_key = key_name
        return self
    
    @staticmethod
    def _read_frame_count(mv2_path: str) -> int:
        """Try to read the frame count from an .mv2 file via MemoryStore.
        
        Returns 0 if the file can't be read (e.g. not a real .mv2).
        """
        try:
            from ate.memory import MemoryStore
            store = MemoryStore(mv2_path)
            return store.count()
        except Exception:
            return 0
    
    def build(self, output_path: str) -> CapsuleBuildResult:
        """Build the .capsule ZIP archive.
        
        Args:
            output_path: Where to write the .capsule file.
        
        Returns:
            CapsuleBuildResult with build details.
        
        Raises:
            ValueError: If no memories added.
            FileNotFoundError: If referenced files missing.
        """
        if not self.memories:
            raise ValueError("Cannot build capsule with no memories")
        
        # Build manifest data
        manifest = CapsuleManifest(
            format_version="1.0",
            name=self.name,
            description=self.description,
            author=self.author,
            created_at=time.time(),
            memories=[],
            trains=[],
            tags=self.tags.copy(),
            license=self.license
        )
        
        # Calculate memory metadata
        for mv2_path, include_sig, include_chain in self.memories:
            basename = os.path.basename(mv2_path)
            size_bytes = os.path.getsize(mv2_path)
            
            # Check for sidecars
            sig_path = mv2_path + ".sig"
            chain_path = mv2_path + ".chain"
            has_sig = include_sig and os.path.exists(sig_path)
            has_chain = include_chain and os.path.exists(chain_path)
            
            # Try to read actual frame count from .mv2 file
            frame_count = self._read_frame_count(mv2_path)
            
            manifest.memories.append({
                "name": basename,
                "frames": frame_count,
                "size_bytes": size_bytes,
                "signed": has_sig,
                "has_chain": has_chain
            })
        
        # Calculate train metadata
        for train_path, train_name in self.trains:
            size_bytes = os.path.getsize(train_path)
            frame_count = self._read_frame_count(train_path)
            manifest.trains.append({
                "name": f"{train_name}.mv2",
                "frames": frame_count,
                "size_bytes": size_bytes
            })
        
        # Sign manifest if key provided
        signed = False
        if self.sign_key:
            # Lazy import to avoid circular dependencies
            from ate.memory.crypto.signing import KeyManager
            
            # Build manifest dict without signature
            manifest_data = {k: v for k, v in manifest.__dict__.items() if k != 'signature'}
            manifest_bytes = json.dumps(manifest_data, sort_keys=True).encode()
            
            # Sign with Ed25519
            keypair = KeyManager.load(self.sign_key)
            signature_bytes = keypair.private_key.sign(manifest_bytes)
            manifest.signature = signature_bytes.hex()
            manifest.author_fingerprint = keypair.public_key_fingerprint
            signed = True
        
        # Build ZIP archive (after manifest + signing are finalized)
        with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zf:
            # Write manifest
            manifest_json = json.dumps(manifest.__dict__, indent=2)
            zf.writestr('manifest.json', manifest_json)
            
            # Write memories and sidecars
            for mv2_path, include_sig, include_chain in self.memories:
                basename = os.path.basename(mv2_path)
                zf.write(mv2_path, f'memories/{basename}')
                
                # Include sidecars if they exist and are requested
                if include_sig:
                    sig_path = mv2_path + ".sig"
                    if os.path.exists(sig_path):
                        zf.write(sig_path, f'memories/{basename}.sig')
                
                if include_chain:
                    chain_path = mv2_path + ".chain"
                    if os.path.exists(chain_path):
                        zf.write(chain_path, f'memories/{basename}.chain')
            
            # Write trains
            for train_path, train_name in self.trains:
                zf.write(train_path, f'trains/{train_name}.mv2')
            
            # Write README if provided
            if self.readme_text:
                zf.writestr('README.md', self.readme_text)
        
        # Calculate final size
        size_bytes = os.path.getsize(output_path)
        
        return CapsuleBuildResult(
            path=output_path,
            name=self.name,
            total_memories=len(self.memories),
            total_trains=len(self.trains),
            size_bytes=size_bytes,
            signed=signed
        )