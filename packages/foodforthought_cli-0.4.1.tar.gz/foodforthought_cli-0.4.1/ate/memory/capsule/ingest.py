"""Capsule ingestion functionality."""

import os
import shutil
import tempfile
import zipfile
from dataclasses import dataclass
from typing import Optional

from .reader import CapsuleReader


@dataclass
class IngestResult:
    """Result of ingesting a capsule into local memory."""
    memories_ingested: int
    trains_ingested: int
    frames_added: int
    signature_verified: Optional[bool]
    source_author: str
    source_name: str


class CapsuleIngestor:
    """Ingest a .capsule into local memory storage.
    
    Usage:
        # Merge capsule contents into existing memory
        result = CapsuleIngestor.ingest(
            "knowledge.capsule",
            target_path="/path/to/my-memory.mv2",
            verify_key="alice"
        )
        
        # Extract capsule to a new memory
        result = CapsuleIngestor.ingest(
            "knowledge.capsule",
            target_path="/path/to/new-memory.mv2",
            mode="extract"
        )
    """
    
    @classmethod
    def ingest(cls, capsule_path: str, target_path: str,
               mode: str = "merge",
               verify_key: Optional[str] = None,
               agent_id: Optional[str] = None) -> IngestResult:
        """Ingest a capsule into local memory.
        
        Args:
            capsule_path: Path to .capsule file.
            target_path: Path to target .mv2 file (created if doesn't exist).
            mode: "merge" (combine with existing) or "extract" (copy as-is).
            verify_key: Optional Ed25519 key name — reject if signature invalid.
            agent_id: Optional agent_id for concurrency locking (Phase 9).
        
        Returns:
            IngestResult with ingestion details.
        
        Raises:
            ValueError: If signature verification fails when verify_key provided.
            FileNotFoundError: If capsule_path doesn't exist.
        """
        if not os.path.exists(capsule_path):
            raise FileNotFoundError(f"Capsule not found: {capsule_path}")
        
        # Read and verify the capsule
        info = CapsuleReader.inspect(capsule_path, verify_key=verify_key)
        
        # Check signature verification if required
        signature_verified = None
        if verify_key:
            signature_verified = info.signature_valid
            if info.is_signed and info.signature_valid is False:
                raise ValueError("Signature verification failed")
            elif info.is_signed and info.signature_valid is True:
                signature_verified = True
        
        # Choose appropriate memory store based on agent_id
        if agent_id:
            from ate.memory.concurrency.safe_store import SafeMemoryStore as MemoryStore
        else:
            from ate.memory.store import MemoryStore
        
        frames_added = 0
        memories_ingested = 0
        trains_ingested = 0
        
        with tempfile.TemporaryDirectory() as temp_dir:
            # Extract capsule to temp directory
            with zipfile.ZipFile(capsule_path, 'r') as zf:
                zf.extractall(temp_dir)
            
            # Process memories
            for memory_info in info.manifest.memories:
                memory_file = os.path.join(temp_dir, 'memories', memory_info['name'])
                if os.path.exists(memory_file):
                    if mode == "extract":
                        # In extract mode, copy the .mv2 directly
                        shutil.copy2(memory_file, target_path)
                    else:
                        # In merge mode, merge via MemoryStore
                        frames_added += cls._merge_memory_file(
                            memory_file, target_path, MemoryStore
                        )
                    memories_ingested += 1
            
            # Process trains (always as separate files in merge mode)
            for train_info in info.manifest.trains:
                train_file = os.path.join(temp_dir, 'trains', train_info['name'])
                if os.path.exists(train_file):
                    if mode == "extract":
                        # Extract trains to target directory
                        target_dir = os.path.dirname(target_path)
                        train_target = os.path.join(target_dir, train_info['name'])
                        shutil.copy2(train_file, train_target)
                    else:
                        # Merge train as separate memory file
                        target_dir = os.path.dirname(target_path)
                        train_target = os.path.join(target_dir, f"train_{train_info['name']}")
                        frames_added += cls._merge_memory_file(
                            train_file, train_target, MemoryStore
                        )
                    trains_ingested += 1
        
        return IngestResult(
            memories_ingested=memories_ingested,
            trains_ingested=trains_ingested,
            frames_added=frames_added,
            signature_verified=signature_verified,
            source_author=info.manifest.author,
            source_name=info.manifest.name
        )
    
    @classmethod
    def extract(cls, capsule_path: str, output_dir: str) -> dict:
        """Extract capsule contents to a directory (no merging).
        
        Args:
            capsule_path: Path to .capsule file.
            output_dir: Directory to extract into.
        
        Returns:
            Dict with extracted file paths.
        """
        if not os.path.exists(capsule_path):
            raise FileNotFoundError(f"Capsule not found: {capsule_path}")
        
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
        
        extracted_files = {
            'memories': [],
            'trains': [],
            'manifest': None,
            'readme': None
        }
        
        with zipfile.ZipFile(capsule_path, 'r') as zf:
            # Extract files, flattening the directory structure for memories and trains
            for file_path in zf.namelist():
                if file_path.startswith('memories/') or file_path.startswith('trains/'):
                    # Extract memory/train files to root of output directory
                    filename = os.path.basename(file_path)
                    if filename:  # Skip directory entries
                        target_path = os.path.join(output_dir, filename)
                        with zf.open(file_path) as source, open(target_path, 'wb') as target:
                            shutil.copyfileobj(source, target)
                        
                        if file_path.startswith('memories/'):
                            extracted_files['memories'].append(target_path)
                        else:
                            extracted_files['trains'].append(target_path)
                
                elif file_path == 'manifest.json':
                    # Extract manifest to output directory
                    target_path = os.path.join(output_dir, 'manifest.json')
                    with zf.open(file_path) as source, open(target_path, 'wb') as target:
                        shutil.copyfileobj(source, target)
                    extracted_files['manifest'] = target_path
                    
                elif file_path == 'README.md':
                    # Extract README to output directory
                    target_path = os.path.join(output_dir, 'README.md')
                    with zf.open(file_path) as source, open(target_path, 'wb') as target:
                        shutil.copyfileobj(source, target)
                    extracted_files['readme'] = target_path
        
        return extracted_files
    
    @classmethod
    def _merge_memory_file(cls, source_path: str, target_path: str, MemoryStore) -> int:
        """Merge a .mv2 file into target using MemoryStore.
        
        Args:
            source_path: Path to source .mv2 file.
            target_path: Path to target .mv2 file.
            MemoryStore: MemoryStore class to use.
        
        Returns:
            Number of frames added.
        """
        # Open target (create if doesn't exist)
        target_store = MemoryStore.open(target_path)
        
        # Open source
        source_store = MemoryStore.open(source_path)
        
        # Export source to JSONL and import each entry to target
        frames_added = 0
        jsonl_entries = source_store.export_jsonl()
        for entry in jsonl_entries:
            target_store.import_entry(entry)
            frames_added += 1
        
        return frames_added