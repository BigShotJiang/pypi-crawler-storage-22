"""Capsule reader functionality."""

import json
import os
import zipfile
from dataclasses import dataclass
from typing import Optional

from .builder import CapsuleManifest


@dataclass
class CapsuleInfo:
    """Information about a capsule's contents."""
    manifest: CapsuleManifest
    is_valid_zip: bool
    is_signed: bool
    signature_valid: Optional[bool]  # None if no signature, True/False if verified
    total_size_bytes: int
    file_count: int
    

class CapsuleReader:
    """Read, inspect, and verify .capsule archives.
    
    Usage:
        info = CapsuleReader.inspect("knowledge.capsule")
        print(info.manifest.name)
        print(info.manifest.author)
        
        # Verify signature
        info = CapsuleReader.inspect("knowledge.capsule", verify_key="alice")
        assert info.signature_valid == True
    """
    
    @classmethod
    def inspect(cls, capsule_path: str,
                verify_key: Optional[str] = None) -> CapsuleInfo:
        """Inspect a capsule without extracting.
        
        Args:
            capsule_path: Path to .capsule file.
            verify_key: Optional Ed25519 key name to verify signature.
        
        Returns:
            CapsuleInfo with manifest and verification status.
        
        Raises:
            FileNotFoundError: If capsule_path doesn't exist.
            ValueError: If not a valid capsule (missing manifest).
        """
        if not os.path.exists(capsule_path):
            raise FileNotFoundError(f"Capsule not found: {capsule_path}")
        
        try:
            # Check if it's a valid ZIP
            with zipfile.ZipFile(capsule_path, 'r') as zf:
                files = zf.namelist()
                
                # Must have manifest.json
                if 'manifest.json' not in files:
                    raise ValueError("Invalid capsule: missing manifest.json")
                
                # Read and parse manifest
                manifest_data = json.loads(zf.read('manifest.json').decode('utf-8'))
                manifest = CapsuleManifest(**manifest_data)
                
                # Check if signed
                is_signed = manifest.signature is not None
                signature_valid = None
                
                # Verify signature if requested and signature exists
                if verify_key and is_signed:
                    try:
                        signature_valid = cls._verify_signature(manifest, verify_key)
                    except Exception:
                        signature_valid = False
                
                # Calculate file info
                total_size_bytes = os.path.getsize(capsule_path)
                file_count = len(files)
                
                return CapsuleInfo(
                    manifest=manifest,
                    is_valid_zip=True,
                    is_signed=is_signed,
                    signature_valid=signature_valid,
                    total_size_bytes=total_size_bytes,
                    file_count=file_count
                )
                
        except zipfile.BadZipFile:
            raise ValueError(f"Invalid ZIP file: {capsule_path}")
    
    @classmethod
    def read_manifest(cls, capsule_path: str) -> CapsuleManifest:
        """Read just the manifest from a capsule.
        
        Args:
            capsule_path: Path to .capsule file.
        
        Returns:
            CapsuleManifest parsed from manifest.json.
        """
        if not os.path.exists(capsule_path):
            raise FileNotFoundError(f"Capsule not found: {capsule_path}")
        
        try:
            with zipfile.ZipFile(capsule_path, 'r') as zf:
                if 'manifest.json' not in zf.namelist():
                    raise ValueError("Invalid capsule: missing manifest.json")
                
                manifest_data = json.loads(zf.read('manifest.json').decode('utf-8'))
                return CapsuleManifest(**manifest_data)
                
        except zipfile.BadZipFile:
            raise ValueError(f"Invalid ZIP file: {capsule_path}")
    
    @classmethod
    def read_readme(cls, capsule_path: str) -> Optional[str]:
        """Read the README.md from a capsule, if present.
        
        Returns:
            README content as string, or None if no README.
        """
        if not os.path.exists(capsule_path):
            raise FileNotFoundError(f"Capsule not found: {capsule_path}")
        
        try:
            with zipfile.ZipFile(capsule_path, 'r') as zf:
                if 'README.md' in zf.namelist():
                    return zf.read('README.md').decode('utf-8')
                return None
                
        except zipfile.BadZipFile:
            raise ValueError(f"Invalid ZIP file: {capsule_path}")
    
    @classmethod
    def list_contents(cls, capsule_path: str) -> list[str]:
        """List all files in the capsule archive.
        
        Returns:
            List of file paths within the archive.
        """
        if not os.path.exists(capsule_path):
            raise FileNotFoundError(f"Capsule not found: {capsule_path}")
        
        try:
            with zipfile.ZipFile(capsule_path, 'r') as zf:
                return zf.namelist()
                
        except zipfile.BadZipFile:
            raise ValueError(f"Invalid ZIP file: {capsule_path}")
    
    @classmethod
    def _verify_signature(cls, manifest: CapsuleManifest, key_name: str) -> bool:
        """Verify the manifest signature.
        
        Args:
            manifest: CapsuleManifest to verify.
            key_name: Ed25519 key name to verify with.
        
        Returns:
            True if signature is valid, False otherwise.
        """
        if not manifest.signature:
            return False
        
        try:
            # Lazy import to avoid circular dependencies
            from ate.memory.crypto.signing import KeyManager
            
            # Build manifest dict without signature field
            manifest_data = {k: v for k, v in manifest.__dict__.items() if k != 'signature'}
            manifest_bytes = json.dumps(manifest_data, sort_keys=True).encode()
            
            # Verify signature with Ed25519
            keypair = KeyManager.load(key_name)
            signature_bytes = bytes.fromhex(manifest.signature)
            keypair.public_key.verify(signature_bytes, manifest_bytes)
            return True
            
        except Exception:
            # Any verification error means invalid signature
            return False