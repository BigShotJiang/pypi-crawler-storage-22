"""
Cloud client for FoodforThought memory API.

Handles push (upload), pull (download), list, and delete of .mv2 memory files.

Routes (Memory API):
  POST   /api/memory                          — create memory
  GET    /api/memory                          — list own memories
  GET    /api/memory/[id]                     — get memory + trains
  PATCH  /api/memory/[id]                     — update memory
  DELETE /api/memory/[id]                     — delete memory
  POST   /api/memory/[id]/trains              — upload train (.mv2)
  GET    /api/memory/[id]/trains/[trainId]    — download train
  DELETE /api/memory/[id]/trains/[trainId]    — delete train
"""

import os
from dataclasses import dataclass
from typing import List, Optional

import requests


# ---------------------------------------------------------------------------
# Result dataclasses
# ---------------------------------------------------------------------------

@dataclass
class PushResult:
    memory_id: str
    memory_name: str
    train_id: str
    train_name: str
    size_bytes: int
    checksum: str


@dataclass
class PullResult:
    path: str
    size_bytes: int
    memory_name: str
    train_name: str
    checksum: str


@dataclass
class MemoryListItem:
    id: str
    name: str
    description: Optional[str]
    visibility: str
    train_count: int
    total_size: int
    created_at: str
    updated_at: str


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class CloudError(Exception):
    """Base exception for cloud operations."""
    pass


class CloudAuthError(CloudError):
    """Raised when authentication is missing or invalid (401)."""
    pass


class CloudNotFoundError(CloudError):
    """Raised when a requested resource is not found (404)."""
    pass


class CloudForbiddenError(CloudError):
    """Raised when access is denied (403)."""
    pass


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------

class CloudClient:
    """Client for FoodforThought memory cloud API.

    All routes require Bearer token authentication.
    """

    def __init__(self, server_url: str = "https://www.kindly.fyi", token: str = None):
        self.server_url = server_url.rstrip("/")
        self.token = token

    # -- public API --------------------------------------------------------

    def push(
        self,
        local_path: str,
        name: str,
        train_name: str = "main",
        description: str = None,
        visibility: str = "private",
    ) -> PushResult:
        """Upload .mv2 file to cloud.

        Flow:
          1. POST /api/memory — create memory (or find existing on 409)
          2. POST /api/memory/{id}/trains — upload train .mv2 file

        Args:
            local_path: Path to the local .mv2 file.
            name: Memory name (2-64 chars, lowercase alphanumeric + hyphens).
            train_name: Train name (default "main").
            description: Optional memory description.
            visibility: Memory visibility: "private", "unlisted", or "public".

        Returns:
            PushResult with memory and train details.
        """
        headers = self._auth_headers()

        # Step 1: Create memory (or find existing)
        create_resp = requests.post(
            f"{self.server_url}/api/memory",
            headers={**headers, "Content-Type": "application/json"},
            json={"name": name, "description": description, "visibility": visibility},
        )

        if create_resp.status_code == 201:
            memory = create_resp.json()["memory"]
            memory_id = memory["id"]
            memory_name = memory["name"]
        elif create_resp.status_code == 409:
            # Memory already exists — find it by name
            found = self._find_memory_by_name(name)
            memory_id = found["id"]
            memory_name = found["name"]
        else:
            self._handle_error(create_resp, "Create memory")
            return  # unreachable, but keeps type checker happy

        # Step 2: Upload train
        with open(local_path, "rb") as f:
            upload_resp = requests.post(
                f"{self.server_url}/api/memory/{memory_id}/trains",
                headers=headers,
                files={"file": (os.path.basename(local_path), f, "application/octet-stream")},
                data={"train": train_name},
            )

        if upload_resp.status_code not in (200, 201):
            self._handle_error(upload_resp, "Upload train")

        train = upload_resp.json()["train"]
        return PushResult(
            memory_id=memory_id,
            memory_name=memory_name,
            train_id=train["id"],
            train_name=train["name"],
            size_bytes=train["sizeBytes"],
            checksum=train.get("checksum", ""),
        )

    def pull(
        self,
        name: str,
        output_path: str,
        train_name: str = None,
    ) -> PullResult:
        """Download .mv2 file from cloud.

        Flow:
          1. GET /api/memory?search={name} — find memory by name
          2. GET /api/memory/{id} — get memory with trains list
          3. GET /api/memory/{id}/trains/{trainId} — download .mv2 file

        Args:
            name: Memory name to download.
            output_path: Local path to write the downloaded file.
            train_name: Specific train to download (default: first/latest).

        Returns:
            PullResult with download details.
        """
        headers = self._auth_headers()

        # Step 1: Find memory by name
        memory = self._find_memory_by_name(name)
        memory_id = memory["id"]

        # Step 2: Get memory details (includes trains)
        detail_resp = requests.get(
            f"{self.server_url}/api/memory/{memory_id}",
            headers=headers,
        )
        if detail_resp.status_code != 200:
            self._handle_error(detail_resp, "Get memory")

        memory_data = detail_resp.json()["memory"]
        trains = memory_data.get("trains", [])

        if not trains:
            raise CloudNotFoundError(f"Memory '{name}' has no trains")

        # Select the target train
        if train_name:
            target_train = next(
                (t for t in trains if t["name"] == train_name), None
            )
            if not target_train:
                raise CloudNotFoundError(
                    f"Train '{train_name}' not found in memory '{name}'"
                )
        else:
            target_train = trains[0]

        # Step 3: Download train file
        download_resp = requests.get(
            f"{self.server_url}/api/memory/{memory_id}/trains/{target_train['id']}",
            headers=headers,
        )
        if download_resp.status_code != 200:
            self._handle_error(download_resp, "Download train")

        # Write to disk
        parent = os.path.dirname(output_path)
        if parent:
            os.makedirs(parent, exist_ok=True)

        with open(output_path, "wb") as f:
            f.write(download_resp.content)

        return PullResult(
            path=output_path,
            size_bytes=len(download_resp.content),
            memory_name=name,
            train_name=target_train["name"],
            checksum=target_train.get("checksum", ""),
        )

    def list(self) -> List[MemoryListItem]:
        """List the authenticated user's memories.

        GET /api/memory

        Returns:
            List of MemoryListItem with name, train count, size, visibility.
        """
        headers = self._auth_headers()

        resp = requests.get(
            f"{self.server_url}/api/memory",
            headers=headers,
        )

        if resp.status_code != 200:
            self._handle_error(resp, "List")

        body = resp.json()
        return [
            MemoryListItem(
                id=m["id"],
                name=m["name"],
                description=m.get("description"),
                visibility=m.get("visibility", "private"),
                train_count=m.get("trainCount", 0),
                total_size=m.get("totalSize", 0),
                created_at=m.get("createdAt", ""),
                updated_at=m.get("updatedAt", ""),
            )
            for m in body.get("memories", [])
        ]

    def delete(self, name: str) -> bool:
        """Delete a memory by name.

        Flow:
          1. GET /api/memory?search={name} — find memory by name
          2. DELETE /api/memory/{id} — delete it

        Args:
            name: Memory name to delete.

        Returns:
            True on success.
        """
        headers = self._auth_headers()

        # Find memory by name
        memory = self._find_memory_by_name(name)
        memory_id = memory["id"]

        # Delete it
        resp = requests.delete(
            f"{self.server_url}/api/memory/{memory_id}",
            headers=headers,
        )

        if resp.status_code != 200:
            self._handle_error(resp, "Delete")

        return True

    # -- internal ----------------------------------------------------------

    def _find_memory_by_name(self, name: str) -> dict:
        """Find a memory by exact name match.

        Uses GET /api/memory?search={name} (case-insensitive contains),
        then filters client-side for an exact name match.

        Returns:
            Memory dict from the API response.

        Raises:
            CloudNotFoundError: If no exact match is found.
        """
        headers = self._auth_headers()

        resp = requests.get(
            f"{self.server_url}/api/memory",
            headers=headers,
            params={"search": name},
        )

        if resp.status_code != 200:
            self._handle_error(resp, "Search")

        memories = resp.json().get("memories", [])
        match = next((m for m in memories if m["name"] == name), None)

        if not match:
            raise CloudNotFoundError(f"Memory '{name}' not found")

        return match

    def _auth_headers(self) -> dict:
        """Build authorization headers.

        Raises:
            CloudAuthError: If no token is set.
        """
        if not self.token:
            raise CloudAuthError("Not authenticated. Run: ate device-login")
        return {"Authorization": f"Bearer {self.token}"}

    def _handle_error(self, resp, operation: str):
        """Map HTTP status codes to exceptions.

        Raises:
            CloudAuthError: On 401.
            CloudForbiddenError: On 403.
            CloudNotFoundError: On 404.
            CloudError: On any other error status.
        """
        if resp.status_code == 401:
            raise CloudAuthError("Invalid or expired token. Run: ate device-login")
        if resp.status_code == 403:
            raise CloudForbiddenError("Access denied")
        if resp.status_code == 404:
            raise CloudNotFoundError("Not found")

        # Try to extract error message from JSON response
        try:
            body = resp.json()
            msg = body.get("error", resp.text)
        except Exception:
            msg = resp.text

        raise CloudError(f"{operation} failed ({resp.status_code}): {msg}")
