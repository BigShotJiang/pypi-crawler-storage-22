"""
Concurrency module for ate.memory package.

Provides file locking and safe store wrappers for concurrent multi-agent
access to .mv2 memory files.

Usage:
    from ate.memory.concurrency import get_lock_manager, get_safe_store

    # File-level locking
    LockManager = get_lock_manager()
    with LockManager.lock("memory.mv2", LockMode.EXCLUSIVE, "agent-1"):
        ...

    # Automatic locking via SafeMemoryStore
    SafeMemoryStore = get_safe_store()
    with SafeMemoryStore.open("memory.mv2", agent_id="agent-1", writable=True) as store:
        store.add("content")
"""


def get_lock_manager():
    """Lazily import and return the LockManager class."""
    from ate.memory.concurrency.lock import LockManager
    return LockManager


def get_safe_store():
    """Lazily import and return the SafeMemoryStore class."""
    from ate.memory.concurrency.safe_store import SafeMemoryStore
    return SafeMemoryStore


def get_lock_mode():
    """Lazily import and return the LockMode enum."""
    from ate.memory.concurrency.lock import LockMode
    return LockMode


def get_lock_error():
    """Lazily import and return the LockError exception class."""
    from ate.memory.concurrency.lock import LockError
    return LockError
