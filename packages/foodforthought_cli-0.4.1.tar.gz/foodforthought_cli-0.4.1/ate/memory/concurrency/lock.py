"""
File locking functionality for concurrent multi-agent access to .mv2 memory files.

This module provides LockManager for OS-level file locking with fcntl.flock(),
stale detection, heartbeat mechanisms, and metadata tracking.
"""

import os
import json
import time
from dataclasses import dataclass
from enum import Enum
from typing import Optional, IO
from contextlib import contextmanager

# Windows compatibility - fcntl doesn't exist on Windows
try:
    import fcntl
    HAS_FLOCK = True
except ImportError:
    HAS_FLOCK = False


class LockMode(Enum):
    """Lock modes for memory access."""
    SHARED = "shared"        # Multiple readers allowed
    EXCLUSIVE = "exclusive"  # Single writer, no readers


@dataclass
class LockInfo:
    """Metadata about who holds a lock."""
    agent_id: str           # Identifier for the locking agent
    mode: str               # "shared" or "exclusive"
    pid: int                # Process ID
    acquired_at: float      # Unix timestamp
    timeout_seconds: float  # Auto-release after this duration (0 = no timeout)
    heartbeat_at: float     # Last heartbeat timestamp


@dataclass
class LockResult:
    """Result of a lock acquisition attempt."""
    acquired: bool
    lock_info: Optional[LockInfo]  # Info about the acquired lock, or current holder if blocked
    waited_seconds: float          # How long we waited


class LockError(Exception):
    """Raised when a lock cannot be acquired."""
    pass


class LockManager:
    """File-based locking for .mv2 memory files.
    
    Uses OS-level flock() for actual mutual exclusion, plus a .lock metadata
    file for visibility (who holds it, when, timeout).
    
    Lock files: {mv2_path}.lock (JSON metadata) + OS flock on the .lock file.
    """
    
    DEFAULT_TIMEOUT = 30.0      # Default lock timeout in seconds
    STALE_THRESHOLD = 60.0      # Lock is considered stale after this many seconds without heartbeat
    POLL_INTERVAL = 0.1         # Seconds between lock acquisition attempts
    
    # Active file descriptors: (mv2_path, agent_id) -> open file descriptor
    _active_locks: dict[tuple[str, str], IO[str]] = {}
    
    @classmethod
    def acquire(cls, mv2_path: str, mode: LockMode, agent_id: str,
                timeout_seconds: float = DEFAULT_TIMEOUT,
                wait_seconds: float = 0.0) -> LockResult:
        """Acquire a lock on a memory file.
        
        Args:
            mv2_path: Path to the .mv2 file.
            mode: SHARED (read) or EXCLUSIVE (write).
            agent_id: Identifier for the requesting agent.
            timeout_seconds: Auto-release timeout (0 = no auto-release).
            wait_seconds: Max time to wait for lock (0 = fail immediately).
        
        Returns:
            LockResult with acquired=True/False.
        """
        lock_path = f"{mv2_path}.lock"
        start_time = time.time()
        
        while True:
            # Check if lock exists and if it's stale
            if os.path.exists(lock_path):
                existing_info = cls._read_lock_info(lock_path)
                if existing_info and cls._is_lock_stale(existing_info):
                    # Remove stale lock
                    try:
                        os.remove(lock_path)
                    except OSError:
                        pass  # May have been removed by another process
            
            # Try to acquire lock
            lock_fd = None
            try:
                # Create/open lock file
                lock_fd = open(lock_path, 'w')
                
                if HAS_FLOCK:
                    # Use OS-level flock for mutual exclusion
                    flock_mode = fcntl.LOCK_SH if mode == LockMode.SHARED else fcntl.LOCK_EX
                    fcntl.flock(lock_fd.fileno(), flock_mode | fcntl.LOCK_NB)
                
                # Write lock metadata
                now = time.time()
                lock_info = LockInfo(
                    agent_id=agent_id,
                    mode=mode.value,
                    pid=os.getpid(),
                    acquired_at=now,
                    timeout_seconds=timeout_seconds,
                    heartbeat_at=now
                )
                
                lock_data = {
                    "version": 1,
                    "agent_id": lock_info.agent_id,
                    "mode": lock_info.mode,
                    "pid": lock_info.pid,
                    "acquired_at": lock_info.acquired_at,
                    "timeout_seconds": lock_info.timeout_seconds,
                    "heartbeat_at": lock_info.heartbeat_at
                }
                
                lock_fd.write(json.dumps(lock_data))
                lock_fd.flush()
                
                # Store the open fd in _active_locks (don't close it)
                cls._active_locks[(mv2_path, agent_id)] = lock_fd
                
                waited_seconds = time.time() - start_time
                return LockResult(acquired=True, lock_info=lock_info, waited_seconds=waited_seconds)
                
            except (BlockingIOError, OSError):
                # Lock is held by someone else
                if lock_fd:
                    lock_fd.close()
                
                # Check if we should wait or give up
                elapsed = time.time() - start_time
                if elapsed >= wait_seconds:
                    # Get info about current holder
                    current_holder = cls._read_lock_info(lock_path) if os.path.exists(lock_path) else None
                    return LockResult(acquired=False, lock_info=current_holder, waited_seconds=elapsed)
                
                # Wait and try again
                time.sleep(cls.POLL_INTERVAL)

    @classmethod
    def release(cls, mv2_path: str, agent_id: str) -> bool:
        """Release a lock held by this agent.
        
        Args:
            mv2_path: Path to the .mv2 file.
            agent_id: Identifier for the releasing agent.
        
        Returns:
            True if lock was released, False if not held by this agent.
        """
        lock_path = f"{mv2_path}.lock"
        
        if not os.path.exists(lock_path):
            return False
        
        lock_info = cls._read_lock_info(lock_path)
        if not lock_info or lock_info.agent_id != agent_id:
            return False
        
        # Close the active file descriptor if it exists
        key = (mv2_path, agent_id)
        if key in cls._active_locks:
            fd = cls._active_locks.pop(key)
            fd.close()  # This releases the OS flock
        
        # Remove lock file
        try:
            os.remove(lock_path)
            return True
        except OSError:
            return False
    
    @classmethod
    def heartbeat(cls, mv2_path: str, agent_id: str) -> bool:
        """Update heartbeat timestamp to prevent stale detection.
        
        Long-running operations should call this periodically.
        
        Args:
            mv2_path: Path to the .mv2 file.
            agent_id: Identifier for the agent.
        
        Returns:
            True if heartbeat updated, False if lock not held.
        """
        import tempfile
        
        lock_path = f"{mv2_path}.lock"
        
        if not os.path.exists(lock_path):
            return False
        
        lock_info = cls._read_lock_info(lock_path)
        if not lock_info or lock_info.agent_id != agent_id:
            return False
        
        # Update heartbeat timestamp
        lock_data = {
            "version": 1,
            "agent_id": lock_info.agent_id,
            "mode": lock_info.mode,
            "pid": lock_info.pid,
            "acquired_at": lock_info.acquired_at,
            "timeout_seconds": lock_info.timeout_seconds,
            "heartbeat_at": time.time()
        }
        
        # Atomic write: write to temp file, then replace
        lock_dir = os.path.dirname(lock_path) or '.'
        try:
            fd, tmp_path = tempfile.mkstemp(dir=lock_dir, suffix='.lock.tmp')
            try:
                os.write(fd, json.dumps(lock_data).encode())
                os.close(fd)
                os.replace(tmp_path, lock_path)
                return True
            except OSError:
                try:
                    os.unlink(tmp_path)
                except OSError:
                    pass
                return False
        except OSError:
            return False

    @classmethod
    def status(cls, mv2_path: str) -> Optional[LockInfo]:
        """Check current lock status without acquiring.
        
        Returns:
            LockInfo if locked, None if unlocked.
        """
        lock_path = f"{mv2_path}.lock"
        
        if not os.path.exists(lock_path):
            return None
        
        return cls._read_lock_info(lock_path)
    
    @classmethod
    def force_release(cls, mv2_path: str) -> bool:
        """Force-release a lock (admin operation). Use when lock is stale.
        
        Returns:
            True if lock was released.
        """
        lock_path = f"{mv2_path}.lock"
        
        if not os.path.exists(lock_path):
            return False
        
        # Close any active fds for this path
        keys_to_remove = [k for k in cls._active_locks if k[0] == mv2_path]
        for key in keys_to_remove:
            cls._active_locks.pop(key).close()
        
        try:
            os.remove(lock_path)
            return True
        except OSError:
            return False
    
    @classmethod
    def is_stale(cls, mv2_path: str) -> bool:
        """Check if current lock is stale (no heartbeat within threshold).
        
        Returns:
            True if lock exists and is stale.
        """
        lock_path = f"{mv2_path}.lock"
        
        if not os.path.exists(lock_path):
            return False
        
        lock_info = cls._read_lock_info(lock_path)
        if not lock_info:
            return False
        
        return cls._is_lock_stale(lock_info)

    @classmethod
    def _read_lock_info(cls, lock_path: str) -> Optional[LockInfo]:
        """Read lock info from lock file."""
        try:
            with open(lock_path, 'r') as f:
                data = json.loads(f.read())
            
            return LockInfo(
                agent_id=data["agent_id"],
                mode=data["mode"],
                pid=data["pid"],
                acquired_at=data["acquired_at"],
                timeout_seconds=data["timeout_seconds"],
                heartbeat_at=data["heartbeat_at"]
            )
        except (OSError, json.JSONDecodeError, KeyError):
            return None
    
    @classmethod
    def _is_lock_stale(cls, lock_info: LockInfo) -> bool:
        """Check if a lock is stale based on PID, timeout, and heartbeat."""
        now = time.time()
        
        # 1. Check if PID is dead
        try:
            os.kill(lock_info.pid, 0)  # Signal 0 checks if process exists
        except ProcessLookupError:
            return True  # Process doesn't exist
        except PermissionError:
            pass  # Process exists but we can't signal it
        
        # 2. Check if timeout expired
        if lock_info.timeout_seconds > 0:
            if now - lock_info.acquired_at > lock_info.timeout_seconds:
                return True
        
        # 3. Check if heartbeat is stale
        if now - lock_info.heartbeat_at > cls.STALE_THRESHOLD:
            return True
        
        return False
    
    @classmethod
    @contextmanager
    def lock(cls, mv2_path: str, mode: LockMode, agent_id: str,
             timeout_seconds: float = DEFAULT_TIMEOUT,
             wait_seconds: float = 10.0):
        """Context manager for lock acquisition with auto-release.
        
        Usage:
            with LockManager.lock("memory.mv2", LockMode.EXCLUSIVE, "agent-1"):
                store = MemoryStore.open("memory.mv2")
                store.add("new content")
                store.close()
        
        Raises:
            LockError: If lock cannot be acquired within wait_seconds.
        """
        result = cls.acquire(mv2_path, mode, agent_id, timeout_seconds, wait_seconds)
        if not result.acquired:
            raise LockError(f"Could not acquire {mode.value} lock within {wait_seconds}s")
        
        try:
            yield
        finally:
            cls.release(mv2_path, agent_id)