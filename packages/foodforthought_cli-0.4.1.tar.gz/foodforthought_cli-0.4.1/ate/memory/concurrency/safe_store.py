"""
SafeMemoryStore wrapper for automatic locking around MemoryStore operations.

This module provides thread-safe wrapper around MemoryStore with automatic
lock acquisition and release.
"""

import os
from contextlib import contextmanager
from typing import Optional

from ate.memory.concurrency.lock import LockManager, LockMode, LockError
from ate.memory import MemoryStore


class SafeMemoryStore:
    """Thread-safe wrapper around MemoryStore with automatic locking.
    
    Usage:
        # Read-only (shared lock)
        with SafeMemoryStore.open("memory.mv2", agent_id="agent-1") as store:
            results = store.search("query")
        
        # Read-write (exclusive lock)
        with SafeMemoryStore.open("memory.mv2", agent_id="agent-1", writable=True) as store:
            store.add("new content")
            results = store.search("query")
    """
    
    def __init__(self, store: 'MemoryStore', mv2_path: str, agent_id: str, 
                 mode: LockMode):
        self._store = store
        self._mv2_path = mv2_path
        self._agent_id = agent_id
        self._mode = mode
    
    @classmethod
    @contextmanager  
    def open(cls, path: str, agent_id: str, writable: bool = False,
             wait_seconds: float = 10.0, lock_timeout: float = 30.0):
        """Open a memory store with automatic locking.
        
        Args:
            path: Path to .mv2 file.
            agent_id: Unique identifier for this agent.
            writable: If True, acquires exclusive lock. If False, shared lock.
            wait_seconds: Max time to wait for lock.
            lock_timeout: Lock auto-release timeout.
        
        Yields:
            SafeMemoryStore instance.
        
        Raises:
            LockError: If lock cannot be acquired.
        """
        mode = LockMode.EXCLUSIVE if writable else LockMode.SHARED
        
        # Acquire lock
        result = LockManager.acquire(path, mode, agent_id, lock_timeout, wait_seconds)
        if not result.acquired:
            raise LockError(f"Could not acquire {mode.value} lock within {wait_seconds}s")
        
        # Open memory store
        store = MemoryStore.open(path)
        safe_store = cls(store, path, agent_id, mode)
        
        try:
            yield safe_store
        finally:
            # Always release lock
            LockManager.release(path, agent_id)
            store.close()
    
    def add(self, text: str, **kwargs) -> str:
        """Add content (requires writable=True)."""
        if self._mode != LockMode.EXCLUSIVE:
            raise LockError("Cannot write: store opened in read-only mode")
        
        # Send heartbeat before long operation
        LockManager.heartbeat(self._mv2_path, self._agent_id)
        
        # Add content
        result = self._store.add(text, **kwargs)
        
        # Invalidate signatures (delete .sig files)
        sig_path = f"{self._mv2_path}.sig"
        if os.path.exists(sig_path):
            try:
                os.remove(sig_path)
            except OSError:
                pass
        
        # Auto-append to integrity chain if it exists
        chain_path = f"{self._mv2_path}.chain"
        if os.path.exists(chain_path):
            try:
                # Import Phase 7/8 chain class lazily
                from ate.memory.crypto.integrity import IntegrityChain
                chain = IntegrityChain(chain_path)
                chain.append(text)
            except ImportError:
                # Chain function not available, skip
                pass
        
        return result
    
    def add_batch(self, items, **kwargs):
        """Add batch (requires writable=True)."""
        if self._mode != LockMode.EXCLUSIVE:
            raise LockError("Cannot write: store opened in read-only mode")
        
        # Send heartbeat before long operation
        LockManager.heartbeat(self._mv2_path, self._agent_id)
        
        # Add batch
        result = self._store.add_batch(items, **kwargs)
        
        # Invalidate signatures
        sig_path = f"{self._mv2_path}.sig"
        if os.path.exists(sig_path):
            try:
                os.remove(sig_path)
            except OSError:
                pass
        
        # Auto-append to integrity chain for each item if chain exists
        chain_path = f"{self._mv2_path}.chain"
        if os.path.exists(chain_path) and items:
            try:
                from ate.memory.crypto.integrity import IntegrityChain
                chain = IntegrityChain(chain_path)
                # Append each item to the chain
                for item in items:
                    if isinstance(item, dict) and 'text' in item:
                        chain.append(item['text'])
                    elif hasattr(item, 'text'):
                        chain.append(item.text)
                    else:
                        chain.append(str(item))
            except ImportError:
                pass
        
        return result
    
    def search(self, query: str, **kwargs):
        """Search (works in both shared and exclusive mode)."""
        return self._store.search(query, **kwargs)
    
    def info(self):
        """Get info (works in both modes)."""
        return self._store.info()
    
    def export_jsonl(self, output_path: str):
        """Export (works in both modes)."""
        return self._store.export_jsonl(output_path)