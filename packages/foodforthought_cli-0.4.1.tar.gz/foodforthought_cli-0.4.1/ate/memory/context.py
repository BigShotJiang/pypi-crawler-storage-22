"""Context management for git-like memory operations.

This module provides the ContextManager that tracks the active memory and train 
of thought, similar to how git tracks the current repository and branch.
"""

import json
import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Dict, Any

from .store import MemoryStore


@dataclass
class MemoryContext:
    """Tracks active memory and train of thought."""
    active_memory: str
    active_train: str
    path: str


@dataclass
class MemoryMetadata:
    """Metadata for a memory."""
    name: str
    visibility: str
    trains: List[str]
    default_train: str
    description: str = ""
    created_at: Optional[str] = None
    remote: Optional[str] = None


class ContextManager:
    """Manages the active memory context (~/.ate/context.json)."""

    CONFIG_DIR = os.path.expanduser("~/.ate")
    CONTEXT_FILE = os.path.expanduser("~/.ate/context.json")
    MEMORIES_DIR = os.path.expanduser("~/.ate/memories")

    @classmethod
    def get_context(cls) -> MemoryContext:
        """Get current context. Auto-initializes on first use."""
        if os.path.exists(cls.CONTEXT_FILE):
            try:
                with open(cls.CONTEXT_FILE, 'r') as f:
                    data = json.load(f)
                
                # Provide defaults for missing fields
                active_memory = data.get("active_memory", "default")
                active_train = data.get("active_train", "main")
                path = data.get("path")
                
                if not path:
                    path = cls._train_to_path(active_memory, active_train)
                
                return MemoryContext(
                    active_memory=active_memory,
                    active_train=active_train,
                    path=path
                )
            except (json.JSONDecodeError, KeyError):
                pass  # Fall through to auto-init
        
        # Auto-initialize on first use
        return cls._auto_initialize()

    @classmethod
    def set_context(cls, memory: str, train: str) -> MemoryContext:
        """Set active context."""
        # Validate memory name
        if not cls._is_valid_memory_name(memory):
            raise ValueError(f"Invalid memory name '{memory}'. Use lowercase alphanumeric and hyphens only.")
        
        # Ensure directories exist
        os.makedirs(cls.CONFIG_DIR, exist_ok=True)
        os.makedirs(cls.MEMORIES_DIR, exist_ok=True)
        memory_dir = os.path.join(cls.MEMORIES_DIR, memory)
        os.makedirs(memory_dir, exist_ok=True)
        
        # Create path
        path = cls._train_to_path(memory, train)
        
        # Create .mv2 file if it doesn't exist (auto-create new trains)
        if not os.path.exists(path):
            try:
                store = MemoryStore.create(path)
                store.close()
            except Exception:
                pass
            # Ensure file exists on disk (memvid create may not touch filesystem)
            if not os.path.exists(path):
                Path(path).touch()
            
            # Update memory.json trains list
            safe_train = train.replace('/', '-')
            memory_json = os.path.join(memory_dir, "memory.json")
            if os.path.exists(memory_json):
                try:
                    with open(memory_json, 'r') as f:
                        data = json.load(f)
                    if safe_train not in data.get("trains", []):
                        data.setdefault("trains", []).append(safe_train)
                        with open(memory_json, 'w') as f:
                            json.dump(data, f, indent=2)
                except (json.JSONDecodeError, KeyError):
                    pass
        
        # Create context
        context = MemoryContext(
            active_memory=memory,
            active_train=train,
            path=path
        )
        
        # Write context file
        context_data = {
            "active_memory": memory,
            "active_train": train,
            "path": path
        }
        
        with open(cls.CONTEXT_FILE, 'w') as f:
            json.dump(context_data, f, indent=2)
        
        return context

    @classmethod
    def resolve_path(cls, memory: Optional[str] = None, train: Optional[str] = None) -> str:
        """Resolve .mv2 path from context or explicit args."""
        if memory is not None and train is not None:
            return cls._train_to_path(memory, train)
        
        context = cls.get_context()
        if memory is not None:
            return cls._train_to_path(memory, context.active_train)
        if train is not None:
            return cls._train_to_path(context.active_memory, train)
        
        return context.path

    @classmethod
    def ensure_memory(cls, name: str) -> str:
        """Create memory dir + default train if doesn't exist."""
        if not cls._is_valid_memory_name(name):
            raise ValueError(f"Invalid memory name '{name}'. Use lowercase alphanumeric and hyphens only.")
        
        # Create config and memories directories
        os.makedirs(cls.CONFIG_DIR, exist_ok=True)
        os.makedirs(cls.MEMORIES_DIR, exist_ok=True)
        
        # Create memory directory
        memory_dir = os.path.join(cls.MEMORIES_DIR, name)
        os.makedirs(memory_dir, exist_ok=True)
        
        # Create default train (main.mv2) if it doesn't exist
        main_path = cls._train_to_path(name, "main")
        if not os.path.exists(main_path):
            try:
                store = MemoryStore.create(main_path)
                store.close()
            except Exception:
                pass
            # Ensure file exists on disk
            if not os.path.exists(main_path):
                Path(main_path).touch()
        
        # Create memory.json if it doesn't exist
        memory_json_path = os.path.join(memory_dir, "memory.json")
        if not os.path.exists(memory_json_path):
            metadata = {
                "name": name,
                "visibility": "private",
                "trains": ["main"],
                "default_train": "main",
                "description": ""
            }
            with open(memory_json_path, 'w') as f:
                json.dump(metadata, f, indent=2)
        
        return main_path

    @classmethod
    def list_memories(cls) -> List[MemoryMetadata]:
        """List all local memories."""
        memories = []
        
        if not os.path.exists(cls.MEMORIES_DIR):
            return memories
        
        for item in os.listdir(cls.MEMORIES_DIR):
            memory_dir = os.path.join(cls.MEMORIES_DIR, item)
            if os.path.isdir(memory_dir):
                memory_json_path = os.path.join(memory_dir, "memory.json")
                if os.path.exists(memory_json_path):
                    try:
                        with open(memory_json_path, 'r') as f:
                            data = json.load(f)
                        
                        metadata = MemoryMetadata(
                            name=data["name"],
                            visibility=data.get("visibility", "private"),
                            trains=data.get("trains", ["main"]),
                            default_train=data.get("default_train", "main"),
                            description=data.get("description", ""),
                            created_at=data.get("created_at"),
                            remote=data.get("remote")
                        )
                        memories.append(metadata)
                    except (json.JSONDecodeError, KeyError):
                        continue  # Skip malformed memory.json files
        
        return memories

    @classmethod
    def list_trains(cls, memory: Optional[str] = None) -> List[str]:
        """List trains of thought in a memory."""
        if memory is None:
            context = cls.get_context()
            memory = context.active_memory
        
        memory_dir = os.path.join(cls.MEMORIES_DIR, memory)
        if not os.path.exists(memory_dir):
            raise FileNotFoundError(f"Memory '{memory}' does not exist")
        
        trains = set()
        
        # Source 1: .mv2 files on disk
        for item in os.listdir(memory_dir):
            if item.endswith('.mv2'):
                train_name = item[:-4]  # Remove .mv2 extension
                trains.add(train_name)
        
        # Source 2: memory.json trains list (in case files haven't been created yet)
        memory_json = os.path.join(memory_dir, "memory.json")
        if os.path.exists(memory_json):
            try:
                with open(memory_json, 'r') as f:
                    data = json.load(f)
                for t in data.get("trains", []):
                    trains.add(t)
            except (json.JSONDecodeError, KeyError):
                pass
        
        return sorted(trains)

    @classmethod
    def _auto_initialize(cls) -> MemoryContext:
        """Auto-initialize default memory on first use."""
        # Ensure default memory exists
        cls.ensure_memory("default")
        
        # Set context to default/main
        return cls.set_context("default", "main")

    @classmethod
    def _train_to_path(cls, memory: str, train: str) -> str:
        """Convert memory + train to .mv2 file path."""
        # Convert train name to filename-safe format (slashes to hyphens)
        safe_train = train.replace('/', '-')
        return os.path.join(cls.MEMORIES_DIR, memory, f"{safe_train}.mv2")

    @classmethod
    def _is_valid_memory_name(cls, name: str) -> bool:
        """Check if memory name is valid (alphanumeric + hyphens only)."""
        return bool(re.match(r'^[a-z0-9-]+$', name))