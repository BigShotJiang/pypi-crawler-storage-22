"""ATE Memory Cryptography - Signing, integrity chains, and encryption.

Lazy imports for cryptographic features to avoid dependencies when not needed.
"""

# Layer 1: Signed Memories
def get_key_manager():
    """Lazy import KeyManager."""
    from .signing import KeyManager
    return KeyManager

def get_memory_signer():
    """Lazy import MemorySigner."""
    from .signing import MemorySigner
    return MemorySigner

# Layer 2: Integrity Chains  
def get_integrity_chain():
    """Lazy import IntegrityChain."""
    from .integrity import IntegrityChain
    return IntegrityChain

def get_merkle_tree():
    """Lazy import MerkleTree."""
    from .integrity import MerkleTree
    return MerkleTree

# Layer 3: Encrypted Memories
def get_memory_encryptor():
    """Lazy import MemoryEncryptor.""" 
    from .encryption import MemoryEncryptor
    return MemoryEncryptor

def get_x25519_key_manager():
    """Lazy import X25519KeyManager."""
    from .encryption import X25519KeyManager
    return X25519KeyManager

# Check if cryptography library is available
def check_crypto_available():
    """Check if cryptography library is available."""
    try:
        import cryptography
        return True
    except ImportError:
        return False

__all__ = [
    'get_key_manager', 'get_memory_signer', 'get_integrity_chain', 'get_merkle_tree',
    'get_memory_encryptor', 'get_x25519_key_manager', 'check_crypto_available'
]