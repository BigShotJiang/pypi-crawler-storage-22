"""Shared utilities for cryptographic operations.

Common functions for hashing, timestamps, and error handling.
"""

import hashlib
import os
from datetime import datetime, timezone
from typing import Union


def hash_file(path: str) -> str:
    """Return 'sha256:<hex>' digest of a file.
    
    Args:
        path: Path to the file to hash.
        
    Returns:
        SHA-256 hash with 'sha256:' prefix.
        
    Raises:
        FileNotFoundError: If file doesn't exist.
    """
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(8192), b''):
            h.update(chunk)
    return f"sha256:{h.hexdigest()}"


def hash_content(content: Union[str, bytes]) -> str:
    """Return 'sha256:<hex>' digest of content.
    
    Args:
        content: Content to hash (string or bytes).
        
    Returns:
        SHA-256 hash with 'sha256:' prefix.
    """
    if isinstance(content, str):
        content = content.encode('utf-8')
    return f"sha256:{hashlib.sha256(content).hexdigest()}"


def current_timestamp() -> str:
    """Return current timestamp in ISO8601 format.
    
    Returns:
        ISO8601 timestamp string.
    """
    return datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')


def ensure_directory(path: str) -> None:
    """Ensure directory exists, creating it if necessary.
    
    Args:
        path: Directory path to create.
    """
    os.makedirs(path, exist_ok=True)


def secure_file_permissions(path: str) -> None:
    """Set secure permissions on a file (0o600 - owner read/write only).
    
    Args:
        path: Path to the file to secure.
    """
    os.chmod(path, 0o600)


def check_cryptography_available():
    """Check if cryptography library is available and import it.
    
    Returns:
        True if available, False otherwise.
    """
    try:
        import cryptography
        return True
    except ImportError:
        return False


def require_cryptography():
    """Ensure cryptography library is available, raise helpful error if not.
    
    Raises:
        ImportError: With helpful message if cryptography not available.
    """
    try:
        import cryptography
    except ImportError:
        raise ImportError(
            "Cryptographic features require the 'cryptography' library.\n"
            "Install with: pip install 'cryptography'\n"
            "Or install ate-memory with crypto support: pip install 'ate-memory[crypto]'"
        )
