"""Layer 3: Encrypted Memories — AES-256-GCM + X25519 for confidential memories.

Provides passphrase-based and key exchange-based encryption for .mv2 files.
"""

import json
import os
import secrets
from dataclasses import dataclass
from enum import Enum
from typing import Optional

from ._utils import hash_file, current_timestamp, ensure_directory, secure_file_permissions, require_cryptography
from .signing import KeyPair


class KDFType(Enum):
    PASSPHRASE = "pbkdf2"
    X25519 = "x25519"


@dataclass
class EncryptionHeader:
    """Metadata stored in .mv2.enc sidecar."""
    version: int
    algorithm: str          # "aes-256-gcm"
    kdf: str                # "pbkdf2" or "x25519"
    salt: bytes             # KDF salt (16 bytes)
    nonce: bytes            # AES-GCM nonce (12 bytes)
    sender_public: Optional[bytes]  # X25519 sender public key (for key exchange)
    original_hash: str      # SHA-256 of original .mv2 file
    encrypted_at: str       # ISO8601


@dataclass
class SealResult:
    """Result of sealing (encrypting) a memory."""
    encrypted_path: str     # path to .mv2.enc
    original_hash: str
    algorithm: str
    kdf: str


@dataclass
class UnsealResult:
    """Result of unsealing (decrypting) a memory."""
    decrypted_path: str
    original_hash: str
    verified: bool          # hash matches after decryption


class MemoryEncryptor:
    """Encrypt and decrypt .mv2 files."""
    
    @staticmethod
    def seal_with_passphrase(mv2_path: str, passphrase: str) -> SealResult:
        """Encrypt .mv2 file with a passphrase.
        
        Creates {mv2_path}.enc (encrypted file) and removes original .mv2.
        The .enc file has a JSON header line followed by encrypted bytes.
        
        Args:
            mv2_path: Path to the .mv2 file to encrypt.
            passphrase: User-provided passphrase.
        
        Returns:
            SealResult with encryption details.
        
        Raises:
            FileNotFoundError: If .mv2 file doesn't exist.
            ValueError: If passphrase is empty.
        """
        require_cryptography()
        
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
        from cryptography.hazmat.primitives import hashes
        
        if not passphrase or passphrase.strip() == "":
            raise ValueError("Passphrase cannot be empty")
        
        if not os.path.exists(mv2_path):
            raise FileNotFoundError(f"File not found: {mv2_path}")
        
        # Read original file
        with open(mv2_path, "rb") as f:
            original_content = f.read()
        
        # Hash original file
        original_hash = hash_file(mv2_path)
        
        # Generate salt and nonce
        salt = secrets.token_bytes(16)
        nonce = secrets.token_bytes(12)
        
        # Derive key from passphrase using PBKDF2
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,  # 256-bit key
            salt=salt,
            iterations=600000,  # High iteration count for security
        )
        key = kdf.derive(passphrase.encode('utf-8'))
        
        # Encrypt with AES-GCM
        aesgcm = AESGCM(key)
        ciphertext = aesgcm.encrypt(nonce, original_content, None)
        
        # Create header
        header = {
            "version": 1,
            "algorithm": "aes-256-gcm",
            "kdf": "pbkdf2",  # Using PBKDF2 instead of Argon2id for wider compatibility
            "salt": salt.hex(),
            "nonce": nonce.hex(),
            "original_hash": original_hash,
            "encrypted_at": current_timestamp()
        }
        
        # Write encrypted file
        enc_path = mv2_path + ".enc"
        with open(enc_path, "wb") as f:
            # Write header as first line
            f.write(json.dumps(header).encode('utf-8') + b'\n')
            # Write encrypted content
            f.write(ciphertext)
        
        # Remove original file
        os.remove(mv2_path)
        
        return SealResult(
            encrypted_path=enc_path,
            original_hash=original_hash,
            algorithm="aes-256-gcm",
            kdf="pbkdf2"
        )
    
    @staticmethod
    def unseal_with_passphrase(enc_path: str, passphrase: str) -> UnsealResult:
        """Decrypt .mv2.enc file with passphrase.
        
        Recreates the original .mv2 file and removes .enc.
        
        Args:
            enc_path: Path to the .mv2.enc file.
            passphrase: The passphrase used to encrypt.
        
        Returns:
            UnsealResult with decryption details.
        
        Raises:
            FileNotFoundError: If .enc file doesn't exist.
            ValueError: If passphrase is wrong (AEAD tag mismatch).
        """
        require_cryptography()
        
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
        from cryptography.hazmat.primitives import hashes
        from cryptography.exceptions import InvalidTag
        
        if not os.path.exists(enc_path):
            raise FileNotFoundError(f"Encrypted file not found: {enc_path}")
        
        # Read encrypted file
        with open(enc_path, "rb") as f:
            header_line = f.readline()
            ciphertext = f.read()
        
        # Parse header
        header = json.loads(header_line.decode('utf-8'))
        salt = bytes.fromhex(header["salt"])
        nonce = bytes.fromhex(header["nonce"])
        original_hash = header["original_hash"]
        
        # Derive key from passphrase
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=600000,
        )
        key = kdf.derive(passphrase.encode('utf-8'))
        
        # Decrypt with AES-GCM
        try:
            aesgcm = AESGCM(key)
            plaintext = aesgcm.decrypt(nonce, ciphertext, None)
        except InvalidTag:
            raise ValueError("Invalid passphrase or corrupted file")
        
        # Determine output path
        if enc_path.endswith(".enc"):
            decrypted_path = enc_path[:-4]  # Remove .enc
        else:
            decrypted_path = enc_path + ".decrypted"
        
        # Write decrypted file
        with open(decrypted_path, "wb") as f:
            f.write(plaintext)
        
        # Verify hash
        decrypted_hash = hash_file(decrypted_path)
        verified = (decrypted_hash == original_hash)
        
        # Remove encrypted file
        os.remove(enc_path)
        
        return UnsealResult(
            decrypted_path=decrypted_path,
            original_hash=original_hash,
            verified=verified
        )
    
    @staticmethod
    def seal_with_key(mv2_path: str, recipient_public: bytes, 
                      sender_key: KeyPair) -> SealResult:
        """Encrypt .mv2 for a specific recipient using X25519 key exchange.
        
        Uses ECDH: sender_private × recipient_public → shared_secret
        Then AES-256-GCM with HKDF(shared_secret).
        
        Args:
            mv2_path: Path to the .mv2 file.
            recipient_public: Recipient's X25519 public key.
            sender_key: Sender's X25519 keypair.
        
        Returns:
            SealResult with encryption details.
        """
        require_cryptography()
        
        from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey, X25519PublicKey
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        from cryptography.hazmat.primitives.kdf.hkdf import HKDF
        from cryptography.hazmat.primitives import hashes
        
        if not os.path.exists(mv2_path):
            raise FileNotFoundError(f"File not found: {mv2_path}")
        
        # Read original file
        with open(mv2_path, "rb") as f:
            original_content = f.read()
        
        # Hash original file
        original_hash = hash_file(mv2_path)
        
        # Create X25519 keys from raw bytes
        sender_private = X25519PrivateKey.from_private_bytes(sender_key.private_key)
        recipient_public_key = X25519PublicKey.from_public_bytes(recipient_public)
        
        # Perform key exchange
        shared_secret = sender_private.exchange(recipient_public_key)
        
        # Derive encryption key using HKDF
        derived_key = HKDF(
            algorithm=hashes.SHA256(),
            length=32,
            salt=None,
            info=b"ate-memory-encryption"
        ).derive(shared_secret)
        
        # Generate nonce
        nonce = secrets.token_bytes(12)
        
        # Encrypt with AES-GCM
        aesgcm = AESGCM(derived_key)
        ciphertext = aesgcm.encrypt(nonce, original_content, None)
        
        # Create header
        header = {
            "version": 1,
            "algorithm": "aes-256-gcm", 
            "kdf": "x25519",
            "salt": "",  # Not used for X25519
            "nonce": nonce.hex(),
            "sender_public": sender_key.public_key.hex(),
            "original_hash": original_hash,
            "encrypted_at": current_timestamp()
        }
        
        # Write encrypted file
        enc_path = mv2_path + ".enc"
        with open(enc_path, "wb") as f:
            f.write(json.dumps(header).encode('utf-8') + b'\n')
            f.write(ciphertext)
        
        # Remove original file
        os.remove(mv2_path)
        
        return SealResult(
            encrypted_path=enc_path,
            original_hash=original_hash,
            algorithm="aes-256-gcm",
            kdf="x25519"
        )
    
    @staticmethod
    def unseal_with_key(enc_path: str, recipient_key: KeyPair) -> UnsealResult:
        """Decrypt .mv2.enc using X25519 key exchange.
        
        Reads sender_public from header, computes shared secret.
        
        Args:
            enc_path: Path to the .mv2.enc file.
            recipient_key: Recipient's X25519 keypair.
        
        Returns:
            UnsealResult with decryption details.
        """
        require_cryptography()
        
        from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey, X25519PublicKey
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        from cryptography.hazmat.primitives.kdf.hkdf import HKDF
        from cryptography.hazmat.primitives import hashes
        from cryptography.exceptions import InvalidTag
        
        if not os.path.exists(enc_path):
            raise FileNotFoundError(f"Encrypted file not found: {enc_path}")
        
        # Read encrypted file
        with open(enc_path, "rb") as f:
            header_line = f.readline()
            ciphertext = f.read()
        
        # Parse header
        header = json.loads(header_line.decode('utf-8'))
        sender_public = bytes.fromhex(header["sender_public"])
        nonce = bytes.fromhex(header["nonce"])
        original_hash = header["original_hash"]
        
        # Create X25519 keys
        recipient_private = X25519PrivateKey.from_private_bytes(recipient_key.private_key)
        sender_public_key = X25519PublicKey.from_public_bytes(sender_public)
        
        # Perform key exchange
        shared_secret = recipient_private.exchange(sender_public_key)
        
        # Derive encryption key
        derived_key = HKDF(
            algorithm=hashes.SHA256(),
            length=32,
            salt=None,
            info=b"ate-memory-encryption"
        ).derive(shared_secret)
        
        # Decrypt with AES-GCM
        try:
            aesgcm = AESGCM(derived_key)
            plaintext = aesgcm.decrypt(nonce, ciphertext, None)
        except InvalidTag:
            raise ValueError("Invalid key or corrupted file")
        
        # Determine output path
        if enc_path.endswith(".enc"):
            decrypted_path = enc_path[:-4]
        else:
            decrypted_path = enc_path + ".decrypted"
        
        # Write decrypted file
        with open(decrypted_path, "wb") as f:
            f.write(plaintext)
        
        # Verify hash
        decrypted_hash = hash_file(decrypted_path)
        verified = (decrypted_hash == original_hash)
        
        # Remove encrypted file
        os.remove(enc_path)
        
        return UnsealResult(
            decrypted_path=decrypted_path,
            original_hash=original_hash,
            verified=verified
        )
    
    @staticmethod
    def is_encrypted(path: str) -> bool:
        """Check if a file is an encrypted .mv2.enc file.
        
        Args:
            path: Path to check.
            
        Returns:
            True if file appears to be encrypted.
        """
        if not os.path.exists(path):
            return False
        
        try:
            with open(path, "rb") as f:
                header_line = f.readline()
                header = json.loads(header_line.decode('utf-8'))
                return header.get("version") == 1 and header.get("algorithm") == "aes-256-gcm"
        except (json.JSONDecodeError, UnicodeDecodeError, KeyError):
            return False


class X25519KeyManager:
    """Manages X25519 keypairs for encryption (separate from Ed25519 signing keys).
    
    Stored at ~/.ate/keys/{name}.x25519.key and {name}.x25519.pub
    """
    
    KEYS_DIR = os.path.expanduser("~/.ate/keys")
    
    @classmethod
    def generate(cls, name: str = "default") -> KeyPair:
        """Generate X25519 keypair.
        
        Args:
            name: Name of the keypair.
            
        Returns:
            Generated KeyPair.
            
        Raises:
            FileExistsError: If key already exists.
        """
        require_cryptography()
        
        from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey
        
        # Check if key exists
        key_path = os.path.join(cls.KEYS_DIR, f"{name}.x25519.key")
        pub_path = os.path.join(cls.KEYS_DIR, f"{name}.x25519.pub")
        
        if os.path.exists(key_path) or os.path.exists(pub_path):
            raise FileExistsError(f"X25519 key '{name}' already exists")
        
        # Generate keypair
        private_key = X25519PrivateKey.generate()
        public_key = private_key.public_key()
        
        # Get raw bytes
        private_bytes = private_key.private_bytes_raw()
        public_bytes = public_key.public_bytes_raw()
        
        # Ensure directory
        ensure_directory(cls.KEYS_DIR)
        
        # Save keys
        with open(key_path, "wb") as f:
            f.write(private_bytes)
        secure_file_permissions(key_path)
        
        with open(pub_path, "wb") as f:
            f.write(public_bytes)
        
        return KeyPair(private_key=private_bytes, public_key=public_bytes)
    
    @classmethod
    def load(cls, name: str = "default") -> KeyPair:
        """Load existing X25519 keypair.
        
        Args:
            name: Name of the keypair.
            
        Returns:
            Loaded KeyPair.
            
        Raises:
            FileNotFoundError: If key doesn't exist.
        """
        key_path = os.path.join(cls.KEYS_DIR, f"{name}.x25519.key")
        pub_path = os.path.join(cls.KEYS_DIR, f"{name}.x25519.pub")
        
        if not os.path.exists(key_path):
            raise FileNotFoundError(f"X25519 private key '{name}' not found")
        if not os.path.exists(pub_path):
            raise FileNotFoundError(f"X25519 public key '{name}' not found")
        
        with open(key_path, "rb") as f:
            private_bytes = f.read()
        
        with open(pub_path, "rb") as f:
            public_bytes = f.read()
        
        return KeyPair(private_key=private_bytes, public_key=public_bytes)
    
    @classmethod
    def load_public(cls, name: str = "default") -> bytes:
        """Load only public key.
        
        Args:
            name: Name of the keypair.
            
        Returns:
            Public key bytes.
            
        Raises:
            FileNotFoundError: If public key doesn't exist.
        """
        pub_path = os.path.join(cls.KEYS_DIR, f"{name}.x25519.pub")
        
        if not os.path.exists(pub_path):
            raise FileNotFoundError(f"X25519 public key '{name}' not found")
        
        with open(pub_path, "rb") as f:
            return f.read()
    
    @classmethod
    def list_keys(cls) -> list[str]:
        """List available X25519 key names.
        
        Returns:
            Sorted list of X25519 key names.
        """
        if not os.path.exists(cls.KEYS_DIR):
            return []
        
        names = set()
        for filename in os.listdir(cls.KEYS_DIR):
            if filename.endswith('.x25519.key'):
                names.add(filename[:-11])  # Remove .x25519.key extension
            elif filename.endswith('.x25519.pub'):
                names.add(filename[:-11])  # Remove .x25519.pub extension
        
        return sorted(names)
    
    @classmethod
    def fingerprint(cls, public_key: bytes) -> str:
        """Return hex-encoded SHA-256 fingerprint of X25519 public key.
        
        Args:
            public_key: X25519 public key bytes.
            
        Returns:
            64-character hex fingerprint.
        """
        import hashlib
        return hashlib.sha256(public_key).hexdigest()
