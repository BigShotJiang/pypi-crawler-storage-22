"""Layer 2: Integrity Chains — Merkle tree audit trail for tamper detection.

Provides JSONL-based integrity chains and Merkle tree verification for .mv2 files.
"""

import hashlib
import json
import os
from dataclasses import dataclass
from typing import List, Optional

from ._utils import hash_content, current_timestamp


@dataclass
class ChainEntry:
    """Single entry in the integrity chain."""
    index: int
    frame_hash: str       # SHA-256 of frame content
    prev_hash: str        # hash of previous entry (or "0" * 64 for genesis)
    chain_hash: str       # SHA-256(index + frame_hash + prev_hash)
    timestamp: str        # ISO8601


@dataclass
class AuditResult:
    """Result of auditing an integrity chain."""
    valid: bool
    total_entries: int
    verified_entries: int
    broken_at: Optional[int]   # index where chain breaks, or None
    root_hash: str             # Merkle root


class IntegrityChain:
    """Manages the .mv2.chain sidecar file.
    
    The chain file is a newline-delimited JSON file (JSONL).
    Each line is a ChainEntry serialized as JSON.
    """
    
    def __init__(self, chain_path: str):
        """Initialize integrity chain.
        
        Args:
            chain_path: Path to the .chain file.
        """
        self.chain_path = chain_path
    
    @classmethod
    def for_memory(cls, mv2_path: str) -> 'IntegrityChain':
        """Create/open chain for an .mv2 file ({mv2_path}.chain).
        
        Args:
            mv2_path: Path to the .mv2 memory file.
            
        Returns:
            IntegrityChain instance.
        """
        chain_path = mv2_path + ".chain"
        return cls(chain_path)
    
    def append(self, content: str, metadata: Optional[dict] = None) -> ChainEntry:
        """Append a new entry to the chain.
        
        Args:
            content: The text content being added (hashed, not stored).
            metadata: Optional metadata (included in hash computation).
        
        Returns:
            The new ChainEntry.
        """
        # Get current chain length
        entries = self.entries()
        index = len(entries)
        
        # Compute frame hash
        frame_content = content
        if metadata:
            frame_content += json.dumps(metadata, sort_keys=True)
        frame_hash = hash_content(frame_content)
        
        # Get previous hash
        if index == 0:
            prev_hash = "0" * 64  # Genesis entry
        else:
            prev_hash = entries[-1].chain_hash
        
        # Compute chain hash
        chain_data = f"{index}{frame_hash}{prev_hash}"
        chain_hash = hashlib.sha256(chain_data.encode('utf-8')).hexdigest()
        
        # Create entry
        entry = ChainEntry(
            index=index,
            frame_hash=frame_hash,
            prev_hash=prev_hash,
            chain_hash=chain_hash,
            timestamp=current_timestamp()
        )
        
        # Append to file
        with open(self.chain_path, "a", encoding="utf-8") as f:
            entry_data = {
                "index": entry.index,
                "frame_hash": entry.frame_hash,
                "prev_hash": entry.prev_hash,
                "chain_hash": entry.chain_hash,
                "timestamp": entry.timestamp
            }
            f.write(json.dumps(entry_data) + "\n")
        
        return entry
    
    def audit(self) -> AuditResult:
        """Verify the entire chain from genesis to tip.
        
        Checks:
        1. Genesis entry has prev_hash of "0" * 64
        2. Each entry's prev_hash matches previous entry's chain_hash
        3. Each entry's chain_hash is correctly computed
        4. Indices are sequential
        
        Returns:
            AuditResult with validation details.
        """
        entries = self.entries()
        
        if not entries:
            return AuditResult(
                valid=True,
                total_entries=0,
                verified_entries=0,
                broken_at=None,
                root_hash="0" * 64
            )
        
        verified_count = 0
        broken_at = None
        
        for i, entry in enumerate(entries):
            # Check index is sequential
            if entry.index != i:
                broken_at = i
                break
            
            # Check genesis entry
            if i == 0:
                if entry.prev_hash != "0" * 64:
                    broken_at = i
                    break
            else:
                # Check prev_hash matches previous entry's chain_hash
                if entry.prev_hash != entries[i-1].chain_hash:
                    broken_at = i
                    break
            
            # Verify chain_hash computation
            chain_data = f"{entry.index}{entry.frame_hash}{entry.prev_hash}"
            expected_hash = hashlib.sha256(chain_data.encode('utf-8')).hexdigest()
            if entry.chain_hash != expected_hash:
                broken_at = i
                break
            
            verified_count += 1
        
        # Determine final state
        valid = (broken_at is None)
        root_hash = entries[-1].chain_hash if entries else "0" * 64
        
        return AuditResult(
            valid=valid,
            total_entries=len(entries),
            verified_entries=verified_count,
            broken_at=broken_at,
            root_hash=root_hash
        )
    
    def entries(self) -> List[ChainEntry]:
        """Read all chain entries.
        
        Returns:
            List of ChainEntry objects.
        """
        if not os.path.exists(self.chain_path):
            return []
        
        entries = []
        with open(self.chain_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    data = json.loads(line)
                    entry = ChainEntry(
                        index=data["index"],
                        frame_hash=data["frame_hash"],
                        prev_hash=data["prev_hash"],
                        chain_hash=data["chain_hash"],
                        timestamp=data["timestamp"]
                    )
                    entries.append(entry)
        
        return entries
    
    @property
    def length(self) -> int:
        """Number of entries in the chain.
        
        Returns:
            Number of entries.
        """
        return len(self.entries())
    
    @property
    def root_hash(self) -> str:
        """Current root hash (chain_hash of last entry, or "0"*64 if empty).
        
        Returns:
            Root hash string.
        """
        entries = self.entries()
        if not entries:
            return "0" * 64
        return entries[-1].chain_hash


class MerkleTree:
    """Build a Merkle tree from chain entries for efficient verification."""
    
    @staticmethod
    def build(entries: List[ChainEntry]) -> str:
        """Build Merkle tree and return root hash.
        
        Args:
            entries: List of chain entries.
            
        Returns:
            Merkle root hash.
        """
        if not entries:
            return "0" * 64
        
        if len(entries) == 1:
            return entries[0].chain_hash
        
        # Build tree bottom-up
        level = [entry.chain_hash for entry in entries]
        
        while len(level) > 1:
            next_level = []
            for i in range(0, len(level), 2):
                left = level[i]
                right = level[i + 1] if i + 1 < len(level) else left
                
                # Hash left + right
                combined = left + right
                parent_hash = hashlib.sha256(combined.encode('utf-8')).hexdigest()
                next_level.append(parent_hash)
            
            level = next_level
        
        return level[0]
    
    @staticmethod
    def verify_inclusion(entry: ChainEntry, proof: List[str], root: str) -> bool:
        """Verify that an entry is included in the tree with the given proof.
        
        Args:
            entry: Entry to verify inclusion for.
            proof: List of proof hashes.
            root: Expected root hash.
            
        Returns:
            True if entry is included with valid proof.
        """
        # For simple case with empty proof (single entry tree)
        if not proof:
            return entry.chain_hash == root
        
        # For multi-entry tree, reconstruct path to root
        current = entry.chain_hash
        for proof_hash in proof:
            # Hash current with proof_hash (order matters)
            combined = current + proof_hash
            current = hashlib.sha256(combined.encode('utf-8')).hexdigest()
        
        return current == root
