"""Layer 1: Signed Memories — Ed25519 signatures for authorship proof.

Provides Ed25519 key management and .mv2 file signing/verification with .sig sidecars.
"""

import hashlib
import json
import os
from dataclasses import dataclass
from typing import Optional

from ._utils import hash_file, current_timestamp, ensure_directory, secure_file_permissions, require_cryptography


@dataclass
class KeyPair:
    """Ed25519 key pair."""
    private_key: bytes   # 32-byte Ed25519 seed
    public_key: bytes    # 32-byte Ed25519 public key


@dataclass 
class SignatureInfo:
    """Result of signing or verifying."""
    public_key: bytes
    signature: bytes
    file_hash: str       # SHA-256 hex digest of the .mv2 file
    valid: bool
    signer_id: str       # hex-encoded public key (fingerprint)


class KeyManager:
    """Manages Ed25519 keypairs stored at ~/.ate/keys/."""
    
    KEYS_DIR = os.path.expanduser("~/.ate/keys")
    
    @classmethod
    def generate(cls, name: str = "default") -> KeyPair:
        """Generate a new Ed25519 keypair and save to KEYS_DIR.
        
        Files created:
          ~/.ate/keys/{name}.key     — 32-byte private seed
          ~/.ate/keys/{name}.pub     — 32-byte public key
        
        Args:
            name: Name of the keypair.
            
        Returns:
            Generated KeyPair.
            
        Raises:
            FileExistsError: If key with that name already exists.
        """
        require_cryptography()
        
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
        
        # Check if key already exists
        key_path = os.path.join(cls.KEYS_DIR, f"{name}.key")
        pub_path = os.path.join(cls.KEYS_DIR, f"{name}.pub")
        
        if os.path.exists(key_path) or os.path.exists(pub_path):
            raise FileExistsError(f"Key '{name}' already exists")
        
        # Generate Ed25519 keypair
        private_key = Ed25519PrivateKey.generate()
        public_key = private_key.public_key()
        
        # Extract raw bytes
        private_bytes = private_key.private_bytes_raw()
        public_bytes = public_key.public_bytes_raw()
        
        # Ensure directory exists
        ensure_directory(cls.KEYS_DIR)
        
        # Save private key (secure permissions)
        with open(key_path, "wb") as f:
            f.write(private_bytes)
        secure_file_permissions(key_path)
        
        # Save public key
        with open(pub_path, "wb") as f:
            f.write(public_bytes)
        
        return KeyPair(private_key=private_bytes, public_key=public_bytes)

    @classmethod
    def load(cls, name: str = "default") -> KeyPair:
        """Load an existing keypair by name.
        
        Args:
            name: Name of the keypair.
            
        Returns:
            Loaded KeyPair.
            
        Raises:
            FileNotFoundError: If key doesn't exist.
        """
        key_path = os.path.join(cls.KEYS_DIR, f"{name}.key")
        pub_path = os.path.join(cls.KEYS_DIR, f"{name}.pub")
        
        if not os.path.exists(key_path):
            raise FileNotFoundError(f"Private key '{name}' not found at {key_path}")
        if not os.path.exists(pub_path):
            raise FileNotFoundError(f"Public key '{name}' not found at {pub_path}")
        
        # Load raw bytes
        with open(key_path, "rb") as f:
            private_bytes = f.read()
        
        with open(pub_path, "rb") as f:
            public_bytes = f.read()
        
        return KeyPair(private_key=private_bytes, public_key=public_bytes)
    
    @classmethod
    def load_public(cls, name: str = "default") -> bytes:
        """Load only the public key (for verification without private key).
        
        Args:
            name: Name of the keypair.
            
        Returns:
            Public key bytes.
            
        Raises:
            FileNotFoundError: If public key doesn't exist.
        """
        pub_path = os.path.join(cls.KEYS_DIR, f"{name}.pub")
        
        if not os.path.exists(pub_path):
            raise FileNotFoundError(f"Public key '{name}' not found at {pub_path}")
        
        with open(pub_path, "rb") as f:
            return f.read()
    
    @classmethod
    def list_keys(cls) -> list[str]:
        """List available key names.
        
        Returns:
            Sorted list of key names.
        """
        if not os.path.exists(cls.KEYS_DIR):
            return []
        
        names = set()
        for filename in os.listdir(cls.KEYS_DIR):
            if filename.endswith('.key'):
                names.add(filename[:-4])  # Remove .key extension
            elif filename.endswith('.pub'):
                names.add(filename[:-4])  # Remove .pub extension
        
        return sorted(names)
    
    @classmethod
    def fingerprint(cls, public_key: bytes) -> str:
        """Return hex-encoded SHA-256 fingerprint of public key.
        
        Args:
            public_key: Public key bytes.
            
        Returns:
            64-character hex fingerprint.
        """
        return hashlib.sha256(public_key).hexdigest()


class MemorySigner:
    """Sign and verify .mv2 files using Ed25519."""
    
    @staticmethod
    def sign(mv2_path: str, key: KeyPair) -> SignatureInfo:
        """Sign an .mv2 file. Creates {mv2_path}.sig sidecar.
        
        The .sig file format (JSON):
        {
            "version": 1,
            "algorithm": "ed25519",
            "public_key": "<hex>",
            "file_hash": "sha256:<hex>",
            "signature": "<hex>",
            "signed_at": "<ISO8601>"
        }
        
        Args:
            mv2_path: Path to the .mv2 file to sign.
            key: KeyPair to use for signing.
            
        Returns:
            SignatureInfo with signature details.
        
        Raises:
            FileNotFoundError: If .mv2 file doesn't exist.
        """
        require_cryptography()
        
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
        
        if not os.path.exists(mv2_path):
            raise FileNotFoundError(f"File not found: {mv2_path}")
        
        # Hash the file
        file_hash = hash_file(mv2_path)
        
        # Create Ed25519 private key from raw bytes
        private_key = Ed25519PrivateKey.from_private_bytes(key.private_key)
        
        # Sign the file hash (without the 'sha256:' prefix)
        hash_bytes = bytes.fromhex(file_hash[7:])  # Remove 'sha256:'
        signature = private_key.sign(hash_bytes)
        
        # Create signature info
        signer_id = KeyManager.fingerprint(key.public_key)
        sig_info = SignatureInfo(
            public_key=key.public_key,
            signature=signature,
            file_hash=file_hash,
            valid=True,
            signer_id=signer_id
        )
        
        # Create .sig file
        sig_path = mv2_path + ".sig"
        sig_data = {
            "version": 1,
            "algorithm": "ed25519",
            "public_key": key.public_key.hex(),
            "file_hash": file_hash,
            "signature": signature.hex(),
            "signed_at": current_timestamp()
        }
        
        with open(sig_path, "w", encoding="utf-8") as f:
            json.dump(sig_data, f)
        
        return sig_info
    
    @staticmethod
    def verify(mv2_path: str, public_key: Optional[bytes] = None) -> SignatureInfo:
        """Verify an .mv2 file's signature.
        
        If public_key is None, reads it from the .sig file.
        
        Args:
            mv2_path: Path to the .mv2 file.
            public_key: Public key bytes, or None to read from .sig file.
            
        Returns:
            SignatureInfo with valid=True/False.
        
        Raises:
            FileNotFoundError: If .mv2 or .sig file doesn't exist.
        """
        require_cryptography()
        
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
        from cryptography.exceptions import InvalidSignature
        
        if not os.path.exists(mv2_path):
            raise FileNotFoundError(f"File not found: {mv2_path}")
        
        sig_path = mv2_path + ".sig"
        if not os.path.exists(sig_path):
            raise FileNotFoundError(f"Signature file not found: {sig_path}")
        
        # Load signature file
        with open(sig_path, "r", encoding="utf-8") as f:
            sig_data = json.load(f)
        
        # Use provided public key or read from sig file
        if public_key is None:
            public_key = bytes.fromhex(sig_data["public_key"])
        
        signature = bytes.fromhex(sig_data["signature"])
        stored_hash = sig_data["file_hash"]
        
        # Hash the current file
        current_hash = hash_file(mv2_path)
        
        # Check if file was tampered with
        file_valid = (current_hash == stored_hash)
        
        # Verify signature
        signature_valid = False
        if file_valid:
            try:
                ed25519_public_key = Ed25519PublicKey.from_public_bytes(public_key)
                hash_bytes = bytes.fromhex(current_hash[7:])  # Remove 'sha256:'
                ed25519_public_key.verify(signature, hash_bytes)
                signature_valid = True
            except (InvalidSignature, ValueError):
                signature_valid = False
        
        valid = file_valid and signature_valid
        signer_id = KeyManager.fingerprint(public_key)
        
        return SignatureInfo(
            public_key=public_key,
            signature=signature,
            file_hash=current_hash,
            valid=valid,
            signer_id=signer_id
        )
    
    @staticmethod
    def has_signature(mv2_path: str) -> bool:
        """Check if a .sig sidecar exists for the .mv2 file.
        
        Args:
            mv2_path: Path to the .mv2 file.
            
        Returns:
            True if .sig file exists.
        """
        sig_path = mv2_path + ".sig"
        return os.path.exists(sig_path)
