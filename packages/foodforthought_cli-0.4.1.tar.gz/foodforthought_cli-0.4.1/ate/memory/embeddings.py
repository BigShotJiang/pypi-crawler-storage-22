"""Embedding configuration and management for ate memory."""

import os
import requests
from dataclasses import dataclass
from typing import Optional, List, Dict, Any

import memvid_sdk


@dataclass
class EmbeddingConfig:
    """Embedding provider configuration."""
    provider: str = "none"
    model: Optional[str] = None
    api_key: Optional[str] = None

    def __post_init__(self):
        """Validate provider after initialization."""
        valid_providers = ["openai", "cohere", "voyage", "ollama", "none"]
        if self.provider not in valid_providers:
            raise ValueError(f"Invalid provider: {self.provider}. Must be one of {valid_providers}")

        # Set default models based on provider
        if self.model is None:
            if self.provider == "openai":
                self.model = "text-embedding-3-small"
            elif self.provider == "cohere":
                self.model = "embed-english-v3.0"
            elif self.provider == "voyage":
                self.model = "voyage-2"
            elif self.provider == "ollama":
                self.model = "nomic-embed-text"


class EmbeddingManager:
    """Detects and manages embedding providers for ate memory."""

    @staticmethod
    def detect() -> EmbeddingConfig:
        """Auto-detect best available embedding provider from env.
        
        Detection order: OpenAI → Cohere → Voyage → Ollama → BM25-only
        
        Returns:
            EmbeddingConfig with detected provider and settings
        """
        # Check OpenAI first (highest priority)
        openai_key = os.environ.get('OPENAI_API_KEY')
        if openai_key:
            return EmbeddingConfig(
                provider="openai",
                api_key=openai_key
            )

        # Check Cohere second
        cohere_key = os.environ.get('COHERE_API_KEY')
        if cohere_key:
            return EmbeddingConfig(
                provider="cohere",
                api_key=cohere_key
            )

        # Check Voyage third
        voyage_key = os.environ.get('VOYAGE_API_KEY')
        if voyage_key:
            return EmbeddingConfig(
                provider="voyage",
                api_key=voyage_key
            )

        # Check Ollama fourth (local service)
        ollama_host = os.environ.get('OLLAMA_HOST', 'http://localhost:11434')
        if EmbeddingManager._is_ollama_available(ollama_host):
            return EmbeddingConfig(
                provider="ollama",
                model="nomic-embed-text"
            )

        # No providers available
        return EmbeddingConfig(provider="none")

    @staticmethod
    def _is_ollama_available(host: str) -> bool:
        """Check if Ollama is reachable at the given host."""
        try:
            response = requests.get(f'{host}/api/tags', timeout=2)
            return response.status_code == 200
        except:
            return False

    @staticmethod
    def get_provider(config: EmbeddingConfig):
        """Get a memvid_sdk EmbeddingProvider from config.
        
        Args:
            config: EmbeddingConfig instance
            
        Returns:
            EmbeddingProvider instance or None if provider is "none"
        """
        if config.provider == "none":
            return None

        return memvid_sdk.embeddings.get_embedder(
            provider=config.provider,
            model=config.model,
            api_key=config.api_key
        )

    @staticmethod
    def available_providers() -> List[Dict[str, Any]]:
        """List all detected providers with status.
        
        Returns:
            List of provider status dictionaries
        """
        providers = []

        # Check OpenAI
        openai_key = os.environ.get('OPENAI_API_KEY')
        if openai_key:
            providers.append({
                "name": "openai",
                "available": True,
                "model": "text-embedding-3-small",
                "source": "OPENAI_API_KEY"
            })
        else:
            providers.append({
                "name": "openai",
                "available": False,
                "reason": "OPENAI_API_KEY not set"
            })

        # Check Cohere
        cohere_key = os.environ.get('COHERE_API_KEY')
        if cohere_key:
            providers.append({
                "name": "cohere",
                "available": True,
                "model": "embed-english-v3.0",
                "source": "COHERE_API_KEY"
            })
        else:
            providers.append({
                "name": "cohere",
                "available": False,
                "reason": "COHERE_API_KEY not set"
            })

        # Check Voyage
        voyage_key = os.environ.get('VOYAGE_API_KEY')
        if voyage_key:
            providers.append({
                "name": "voyage",
                "available": True,
                "model": "voyage-2",
                "source": "VOYAGE_API_KEY"
            })
        else:
            providers.append({
                "name": "voyage",
                "available": False,
                "reason": "VOYAGE_API_KEY not set"
            })

        # Check Ollama
        ollama_host = os.environ.get('OLLAMA_HOST', 'http://localhost:11434')
        if EmbeddingManager._is_ollama_available(ollama_host):
            providers.append({
                "name": "ollama",
                "available": True,
                "model": "nomic-embed-text",
                "source": ollama_host
            })
        else:
            providers.append({
                "name": "ollama",
                "available": False,
                "reason": "OLLAMA_HOST not set, localhost:11434 not reachable"
            })

        return providers