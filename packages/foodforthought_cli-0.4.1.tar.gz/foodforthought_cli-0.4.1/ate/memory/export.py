"""Export operations and info structures."""

from dataclasses import dataclass
from typing import Optional


@dataclass
class MemoryInfo:
    """Information about a memory store.
    
    Attributes:
        path: Path to the .mv2 file
        frame_count: Number of memory frames stored
        size_bytes: Total size in bytes
        has_lex_index: Whether lexical indexing is enabled
        has_vec_index: Whether vector indexing is enabled  
        has_time_index: Whether time indexing is enabled
        created_at: ISO timestamp when created (optional)
    """
    path: str
    frame_count: int
    size_bytes: int
    has_lex_index: bool
    has_vec_index: bool
    has_time_index: bool
    created_at: Optional[str] = None