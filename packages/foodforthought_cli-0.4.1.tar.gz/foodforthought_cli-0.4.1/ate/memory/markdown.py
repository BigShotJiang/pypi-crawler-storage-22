"""Markdown parser for importing .md files into .mv2 memory stores.

Splits a Markdown document by H2 (##) headers into logical sections,
each becoming a memory frame with title, text, tags, and metadata.
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class MarkdownSection:
    """A parsed section from a Markdown file."""

    title: str
    text: str
    tags: list[str] = field(default_factory=list)
    metadata: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        """Convert to dict compatible with MemoryStore.add_batch()."""
        return {
            "title": self.title,
            "text": self.text,
            "tags": self.tags,
            "metadata": self.metadata,
        }


def parse_markdown(
    content: str,
    source_file: Optional[str] = None,
) -> list[MarkdownSection]:
    """Parse a Markdown string into sections split by H2 headers.

    Args:
        content: The full Markdown text.
        source_file: Optional filename for metadata (e.g. "MEMORY.md").

    Returns:
        A list of MarkdownSection objects in document order.
        Empty sections (no body text) are skipped.
    """
    if not content or not content.strip():
        return []

    lines = content.split("\n")

    # Extract the first H1 title for use as a top-level tag
    h1_title: Optional[str] = None
    for line in lines:
        m = re.match(r"^#\s+(.+)$", line)
        if m:
            h1_title = m.group(1).strip()
            break

    # Split into sections by H2 headers
    sections_raw: list[tuple[Optional[str], list[str]]] = []
    current_title: Optional[str] = None
    current_lines: list[str] = []

    for line in lines:
        m = re.match(r"^##\s+(.+)$", line)
        if m:
            # Save the previous section
            sections_raw.append((current_title, current_lines))
            current_title = m.group(1).strip()
            current_lines = []
        else:
            current_lines.append(line)

    # Don't forget the last section
    sections_raw.append((current_title, current_lines))

    # Build MarkdownSection objects
    result: list[MarkdownSection] = []
    base_metadata = {"source": "markdown"}
    if source_file:
        base_metadata["source_file"] = source_file

    for title, body_lines in sections_raw:
        # Clean body: strip H1 lines from intro (they become the title)
        if title is None:
            # This is frontmatter / intro
            cleaned = []
            for bl in body_lines:
                if re.match(r"^#\s+", bl):
                    continue  # Skip H1 lines — already captured
                cleaned.append(bl)
            body = "\n".join(cleaned).strip()
            if not body:
                continue
            sec_title = h1_title or "Introduction"
        else:
            body = "\n".join(body_lines).strip()
            if not body:
                continue
            sec_title = title

        # Build tags
        tags: list[str] = []
        if h1_title and title is not None:
            tags.append(h1_title)
        if title is not None:
            tags.append(title)

        result.append(
            MarkdownSection(
                title=sec_title,
                text=body,
                tags=tags,
                metadata=dict(base_metadata),
            )
        )

    return result


def sections_to_markdown(
    sections: list[MarkdownSection],
    h1_title: Optional[str] = None,
) -> str:
    """Reconstruct a Markdown document from parsed sections.

    Args:
        sections: List of MarkdownSection objects.
        h1_title: Explicit H1 title. If None, auto-detected from
                  the most common first tag across sections.

    Returns:
        A Markdown string with H1 (if applicable) and H2 sections.
    """
    if not sections:
        return ""

    # Auto-detect H1 from shared first tag
    if h1_title is None:
        first_tags = [s.tags[0] for s in sections if s.tags]
        if first_tags:
            from collections import Counter
            tag_counts = Counter(first_tags)
            most_common_tag, count = tag_counts.most_common(1)[0]
            if count > len(sections) // 2:
                h1_title = most_common_tag

    parts: list[str] = []

    # Write H1 if we have one
    if h1_title:
        parts.append(f"# {h1_title}\n")

    for section in sections:
        # If section title matches H1, render as intro text (no H2)
        if h1_title and section.title == h1_title:
            parts.append(section.text + "\n")
        else:
            parts.append(f"## {section.title}\n{section.text}\n")

    return "\n".join(parts)
