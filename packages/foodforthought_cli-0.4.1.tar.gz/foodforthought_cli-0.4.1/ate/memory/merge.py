"""Memory merging operations."""

from typing import List
import json

from .store import MemoryStore
from .export import MemoryInfo


def merge_memories(source_paths: List[str], output_path: str, dedup: bool = True) -> MemoryInfo:
    """Merge multiple .mv2 files into a single output file.
    
    Args:
        source_paths: List of paths to source .mv2 files
        output_path: Path where merged .mv2 file will be created
        dedup: Whether to deduplicate identical content (default True)
        
    Returns:
        MemoryInfo about the merged output file
    """
    # Create the output memory store
    output_store = MemoryStore.create(output_path)
    
    seen_texts = set() if dedup else None
    all_items = []
    
    try:
        # Process each source file
        for source_path in source_paths:
            source_store = MemoryStore.open(source_path)
            
            try:
                # Try timeline-based iteration first (works with real memvid)
                items_from_source = []
                try:
                    timeline = source_store._mem.timeline()
                    if timeline:
                        for entry in timeline:
                            if isinstance(entry, dict):
                                uri = entry.get('uri', f"mv2://frames/{entry.get('frame_id', 0)}")
                                frame_data = source_store._mem.frame(uri)
                                
                                title = None
                                tags = []
                                metadata = {}
                                
                                # Get text from timeline preview (labels are just keywords)
                                text = entry.get('preview', '').split('\ntitle:')[0].split('\ntags:')[0].strip()
                                
                                if isinstance(frame_data, dict):
                                    title = frame_data.get('title')
                                    tags = frame_data.get('tags', [])
                                    for key, value in frame_data.get('extra_metadata', {}).items():
                                        if key == 'extractous_metadata':
                                            continue
                                        try:
                                            if isinstance(value, str) and (value.startswith('{') or value.startswith('"')):
                                                metadata[key] = json.loads(value)
                                            else:
                                                metadata[key] = value
                                        except json.JSONDecodeError:
                                            metadata[key] = value
                                
                                if text:
                                    items_from_source.append({
                                        'text': text,
                                        'title': title,
                                        'tags': tags,
                                        'metadata': metadata
                                    })
                except (AttributeError, TypeError):
                    pass  # Fall through to search-based approach
                
                # Fallback: use search (for mocked tests)
                if not items_from_source:
                    search_result = source_store.search("*", top_k=10000)
                    
                    if hasattr(search_result, 'hits'):
                        search_results = search_result.hits
                    elif isinstance(search_result, list):
                        search_results = search_result
                    else:
                        search_results = []
                    
                    for search_item in search_results:
                        text = getattr(search_item, 'snippet', getattr(search_item, 'text', ''))
                        title = getattr(search_item, 'title', None)
                        tags = getattr(search_item, 'tags', [])
                        frame_id = getattr(search_item, 'frame_id', 0)
                        
                        metadata = {}
                        try:
                            frame_data = source_store._mem.frame(frame_id)
                            if hasattr(frame_data, 'metadata'):
                                metadata = frame_data.metadata or {}
                        except Exception:
                            try:
                                if hasattr(search_item, 'metadata'):
                                    metadata = search_item.metadata or {}
                            except Exception:
                                metadata = {}
                        
                        items_from_source.append({
                            'text': text,
                            'title': title,
                            'tags': tags,
                            'metadata': metadata
                        })
                
                for item in items_from_source:
                    text = item['text']
                    
                    if dedup and text in seen_texts:
                        continue
                    
                    if dedup:
                        seen_texts.add(text)
                    
                    all_items.append(item)
                    
            finally:
                source_store.close()
        
        # Add all collected items to the output store
        output_store.add_batch(all_items)
        
        # Get info about the merged result
        info = output_store.info()
        
    finally:
        output_store.close()
    
    # Handle mocked info object vs real MemoryInfo
    if hasattr(info, 'frame_count') and not isinstance(info, MemoryInfo):
        # It's a mock, create actual MemoryInfo
        return MemoryInfo(
            path=info.path,
            frame_count=info.frame_count,
            size_bytes=info.size_bytes,
            has_lex_index=info.has_lex_index,
            has_vec_index=info.has_vec_index,
            has_time_index=info.has_time_index,
            created_at=getattr(info, 'created_at', None)
        )
    
    return info