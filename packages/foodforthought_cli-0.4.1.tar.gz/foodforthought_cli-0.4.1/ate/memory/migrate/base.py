"""Base classes and data structures for migration."""
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any, Tuple


@dataclass
class VectorRecord:
    """A vector record with metadata."""
    id: str
    vector: List[float]
    text: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class MigrationEstimate:
    """Estimation of migration resources and time."""
    total_vectors: int
    dimensions: int
    estimated_mv2_bytes: int
    estimated_seconds: float
    source_size_bytes: Optional[int] = None
    compression_ratio: Optional[float] = None


@dataclass
class MigrationResult:
    """Result of a migration operation."""
    source_type: str
    source_name: str
    output_path: str
    total_migrated: int
    total_skipped: int
    duration_seconds: float
    output_size_bytes: int
    compression_ratio: Optional[float] = None
    errors: List[str] = field(default_factory=list)


@dataclass
class MigrationCheckpoint:
    """Migration checkpoint for resuming."""
    source_type: str
    source_name: str
    output_path: str
    last_cursor: Optional[str]
    records_completed: int
    started_at: str


class MigrationSource(ABC):
    """Abstract base class for migration sources."""
    
    @property
    @abstractmethod
    def source_type(self) -> str:
        """Return the source type (e.g., 'pinecone', 'qdrant')."""
        pass
    
    @property
    @abstractmethod
    def source_name(self) -> str:
        """Return the source name (e.g., index name, collection name)."""
        pass
    
    @abstractmethod
    def connect(self) -> None:
        """Connect to the source."""
        pass
    
    @abstractmethod
    def estimate(self) -> MigrationEstimate:
        """Estimate migration size and time."""
        pass
    
    @abstractmethod
    def fetch_batch(self, batch_size: int = 10000, cursor: Optional[str] = None) -> Tuple[List[VectorRecord], Optional[str]]:
        """Fetch a batch of records.
        
        Returns:
            Tuple of (records, next_cursor). next_cursor is None if this is the last batch.
        """
        pass
    
    @abstractmethod
    def close(self) -> None:
        """Close the connection and clean up resources."""
        pass