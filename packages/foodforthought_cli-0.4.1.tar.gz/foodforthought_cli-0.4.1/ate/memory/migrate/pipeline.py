"""Migration pipeline for orchestrating the migration process."""
import json
import os
import time
from typing import Optional, Callable, Any

from .base import MigrationSource, MigrationResult, MigrationCheckpoint


class MigrationPipeline:
    """Pipeline for orchestrating vector database migrations."""
    
    def __init__(self, source: MigrationSource, output_path: str, 
                 batch_size: int = 10000, checkpoint_path: Optional[str] = None):
        """Initialize the migration pipeline.
        
        Args:
            source: The migration source to read from
            output_path: Path to write the .mv2 output file
            batch_size: Number of records to fetch per batch
            checkpoint_path: Optional path for checkpoint file
        """
        self.source = source
        self.output_path = output_path
        self.batch_size = batch_size
        self.checkpoint_path = checkpoint_path
        self.progress_callbacks = []
    
    def on_progress(self, callback: Callable[[int, int], None]) -> None:
        """Register a progress callback function.
        
        Args:
            callback: Function called with (records_done, total_estimate)
        """
        self.progress_callbacks.append(callback)
    
    def run(self, dry_run: bool = False) -> MigrationResult:
        """Run the migration.
        
        Args:
            dry_run: If True, only estimate without migrating
            
        Returns:
            MigrationResult with operation details
        """
        start_time = time.time()
        
        try:
            self.source.connect()
            
            # Get estimate
            estimate = self.source.estimate()
            
            if dry_run:
                # For dry run, return early with estimate-based result
                return MigrationResult(
                    source_type=self.source.source_type,
                    source_name=self.source.source_name,
                    output_path=self.output_path,
                    total_migrated=0,
                    total_skipped=0,
                    duration_seconds=time.time() - start_time,
                    output_size_bytes=0
                )
            
            # Create output .mv2 using MemoryStore
            parent_dir = os.path.dirname(self.output_path)
            if parent_dir:
                os.makedirs(parent_dir, exist_ok=True)
            
            from ..store import MemoryStore
            output_store = MemoryStore.create(self.output_path)
            
            total_migrated = 0
            total_skipped = 0
            errors = []
            cursor = None
            
            try:
                while True:
                    try:
                        records, next_cursor = self.source.fetch_batch(self.batch_size, cursor)
                        
                        if not records:
                            break
                        
                        # Write records to .mv2 via MemoryStore
                        for record in records:
                            text = record.text or f"[vector-only record id={record.id}]"
                            metadata = dict(record.metadata) if record.metadata else {}
                            metadata['_source_id'] = record.id
                            metadata['_source_type'] = self.source.source_type
                            
                            try:
                                output_store.add(
                                    text=text,
                                    metadata=metadata
                                )
                                total_migrated += 1
                            except Exception as e:
                                total_skipped += 1
                                errors.append(f"Record {record.id}: {str(e)}")
                        
                        # Update checkpoint
                        if self.checkpoint_path:
                            checkpoint = MigrationCheckpoint(
                                source_type=self.source.source_type,
                                source_name=self.source.source_name,
                                output_path=self.output_path,
                                last_cursor=cursor,
                                records_completed=total_migrated,
                                started_at=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(start_time))
                            )
                            self._write_checkpoint(checkpoint)
                        
                        # Call progress callbacks
                        for callback in self.progress_callbacks:
                            callback(total_migrated, estimate.total_vectors)
                        
                        cursor = next_cursor
                        if cursor is None:
                            break
                            
                    except Exception as e:
                        errors.append(str(e))
                        break
            finally:
                output_store.close()
            
            # Calculate output file size
            output_size = os.path.getsize(self.output_path) if os.path.exists(self.output_path) else 0
            
            return MigrationResult(
                source_type=self.source.source_type,
                source_name=self.source.source_name,
                output_path=self.output_path,
                total_migrated=total_migrated,
                total_skipped=total_skipped,
                duration_seconds=time.time() - start_time,
                output_size_bytes=output_size,
                errors=errors
            )
            
        except Exception as e:
            return MigrationResult(
                source_type=self.source.source_type,
                source_name=self.source.source_name,
                output_path=self.output_path,
                total_migrated=0,
                total_skipped=0,
                duration_seconds=time.time() - start_time,
                output_size_bytes=0,
                errors=[str(e)]
            )
        finally:
            try:
                self.source.close()
            except:
                pass
    
    def resume(self) -> MigrationResult:
        """Resume migration from checkpoint.
        
        Raises:
            NotImplementedError: Resume is not yet implemented.
        """
        raise NotImplementedError(
            "Resume not yet implemented — use run() to restart migration"
        )
    
    def _write_checkpoint(self, checkpoint: MigrationCheckpoint) -> None:
        """Write checkpoint to file."""
        if not self.checkpoint_path:
            return
            
        checkpoint_data = {
            'source_type': checkpoint.source_type,
            'source_name': checkpoint.source_name,
            'output_path': checkpoint.output_path,
            'last_cursor': checkpoint.last_cursor,
            'records_completed': checkpoint.records_completed,
            'started_at': checkpoint.started_at
        }
        
        parent = os.path.dirname(self.checkpoint_path)
        if parent:
            os.makedirs(parent, exist_ok=True)
        with open(self.checkpoint_path, 'w') as f:
            json.dump(checkpoint_data, f)