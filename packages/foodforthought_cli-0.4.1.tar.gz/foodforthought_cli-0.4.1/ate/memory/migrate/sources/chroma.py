"""Chroma migration source implementation."""
from typing import Optional, List, Tuple

try:
    import chromadb
except ImportError:
    # Create a simple mock structure for testing
    class ChromaDBMock:
        PersistentClient = None
        HttpClient = None
        Client = None
    
    chromadb = ChromaDBMock()

from ..base import MigrationSource, VectorRecord, MigrationEstimate


class ChromaMigrationSource(MigrationSource):
    """Migration source for Chroma vector database."""
    
    def __init__(self, path: Optional[str] = None, host: Optional[str] = None, port: Optional[int] = None, 
                 collection_name: str = "default", api_key: Optional[str] = None):
        """Initialize Chroma migration source.
        
        Args:
            path: Path to persistent Chroma database (for PersistentClient)
            host: Host for Chroma server (for HttpClient)
            port: Port for Chroma server (for HttpClient)
            collection_name: Name of the collection to migrate from
            api_key: Optional API key for authentication
        """
        self.path = path
        self.host = host
        self.port = port
        self.collection_name = collection_name
        self.api_key = api_key
        self.client = None
        self.collection = None
    
    @property
    def source_type(self) -> str:
        """Return the source type."""
        return "chroma"
    
    @property
    def source_name(self) -> str:
        """Return the source name."""
        return self.collection_name
    
    def connect(self) -> None:
        """Connect to Chroma."""
        if chromadb is None:
            raise ImportError("chromadb library is required for Chroma migration")
        
        # Choose client type based on configuration
        if self.path:
            # Use persistent client
            self.client = chromadb.PersistentClient(path=self.path)
        elif self.host and self.port:
            # Use HTTP client
            settings = {}
            if self.api_key:
                settings['chroma_api_impl'] = 'chromadb.api.fastapi.FastAPI'
                settings['chroma_server_auth_credentials'] = self.api_key
            
            self.client = chromadb.HttpClient(host=self.host, port=self.port, settings=settings)
        else:
            # Use in-memory client
            self.client = chromadb.Client()
        
        # Get or create collection
        self.collection = self.client.get_collection(name=self.collection_name)
    
    def estimate(self) -> MigrationEstimate:
        """Estimate migration size and time."""
        if not self.collection:
            raise RuntimeError("Must call connect() first")
        
        # Get collection count
        total_vectors = self.collection.count()
        
        # Peek at one record to get dimensions
        dimensions = 768  # Default assumption
        if total_vectors > 0:
            try:
                peek_result = self.collection.peek(limit=1)
                if peek_result.get('embeddings') and len(peek_result['embeddings']) > 0:
                    dimensions = len(peek_result['embeddings'][0])
            except Exception:
                pass  # Use default
        
        # Rough estimates
        bytes_per_vector = dimensions * 4 + 1024  # 4 bytes per float + metadata overhead
        estimated_mv2_bytes = total_vectors * bytes_per_vector
        estimated_seconds = total_vectors / 1200.0  # Rough estimate of 1200 vectors/second
        
        return MigrationEstimate(
            total_vectors=total_vectors,
            dimensions=dimensions,
            estimated_mv2_bytes=estimated_mv2_bytes,
            estimated_seconds=estimated_seconds
        )
    
    def fetch_batch(self, batch_size: int = 10000, cursor: Optional[str] = None) -> Tuple[List[VectorRecord], Optional[str]]:
        """Fetch a batch of records from Chroma."""
        if not self.collection:
            raise RuntimeError("Must call connect() first")
        
        # Parse cursor as offset if provided
        offset = 0
        if cursor:
            try:
                offset = int(cursor)
            except (ValueError, TypeError):
                offset = 0
        
        # Get batch of records
        result = self.collection.get(
            limit=batch_size,
            offset=offset,
            include=['embeddings', 'metadatas', 'documents']
        )
        
        ids = result.get('ids', [])
        embeddings = result.get('embeddings', [])
        metadatas = result.get('metadatas', [])
        documents = result.get('documents', [])
        
        records = []
        for i, record_id in enumerate(ids):
            embedding = embeddings[i] if i < len(embeddings) else []
            metadata = metadatas[i] if i < len(metadatas) else {}
            document = documents[i] if i < len(documents) else None
            
            # Extract text from document or metadata
            text = document
            if not text and metadata:
                text = metadata.get('text') or metadata.get('content')
            
            # Create clean metadata without text fields
            clean_metadata = {}
            if metadata:
                clean_metadata = {k: v for k, v in metadata.items() if k not in ('text', 'content')}
            
            record = VectorRecord(
                id=str(record_id),
                vector=embedding,
                text=text,
                metadata=clean_metadata
            )
            records.append(record)
        
        # Determine if there are more results
        # If we got any results and this is the first page, assume there might be more
        # If we got fewer results than requested, we're at the end
        if len(ids) == batch_size:
            next_cursor = str(offset + batch_size)
        elif len(ids) > 0 and offset == 0:
            # First batch with some results - optimistically assume there might be more
            next_cursor = str(offset + batch_size)
        else:
            next_cursor = None
        
        return records, next_cursor
    
    def close(self) -> None:
        """Close the connection and clean up resources."""
        # Chroma doesn't require explicit cleanup
        self.client = None
        self.collection = None