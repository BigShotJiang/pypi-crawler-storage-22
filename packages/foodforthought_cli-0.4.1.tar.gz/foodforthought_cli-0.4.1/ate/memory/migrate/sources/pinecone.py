"""Pinecone migration source implementation."""
from typing import Optional, List, Tuple

try:
    import pinecone
except ImportError:
    pinecone = None

from ..base import MigrationSource, VectorRecord, MigrationEstimate


class PineconeMigrationSource(MigrationSource):
    """Migration source for Pinecone vector database."""
    
    def __init__(self, api_key: str, index_name: str, environment: str, namespace: Optional[str] = None):
        """Initialize Pinecone migration source.
        
        Args:
            api_key: Pinecone API key
            index_name: Name of the Pinecone index
            environment: Pinecone environment
            namespace: Optional namespace to migrate from
        """
        self.api_key = api_key
        self.index_name = index_name
        self.environment = environment
        self.namespace = namespace
        self.index = None
    
    @property
    def source_type(self) -> str:
        """Return the source type."""
        return "pinecone"
    
    @property
    def source_name(self) -> str:
        """Return the source name."""
        return self.index_name
    
    def connect(self) -> None:
        """Connect to Pinecone."""
        if pinecone is None:
            raise ImportError("pinecone library is required for Pinecone migration")
        
        pinecone.init(api_key=self.api_key, environment=self.environment)
        self.index = pinecone.Index(self.index_name)
    
    def estimate(self) -> MigrationEstimate:
        """Estimate migration size and time."""
        if not self.index:
            raise RuntimeError("Must call connect() first")
        
        stats = self.index.describe_index_stats()
        
        # If namespace is specified, use namespace count, otherwise use total
        if self.namespace and 'namespaces' in stats and self.namespace in stats['namespaces']:
            total_vectors = stats['namespaces'][self.namespace]['vector_count']
        else:
            total_vectors = stats.get('total_vector_count', 0)
        
        dimensions = stats.get('dimension', 768)
        
        # Rough estimates
        bytes_per_vector = dimensions * 4 + 1024  # 4 bytes per float + metadata overhead
        estimated_mv2_bytes = total_vectors * bytes_per_vector
        estimated_seconds = total_vectors / 1000.0  # Rough estimate of 1000 vectors/second
        
        return MigrationEstimate(
            total_vectors=total_vectors,
            dimensions=dimensions,
            estimated_mv2_bytes=estimated_mv2_bytes,
            estimated_seconds=estimated_seconds
        )
    
    def fetch_batch(self, batch_size: int = 10000, cursor: Optional[str] = None) -> Tuple[List[VectorRecord], Optional[str]]:
        """Fetch a batch of records from Pinecone."""
        if not self.index:
            raise RuntimeError("Must call connect() first")
        
        # List vector IDs with pagination
        list_response = self.index.list(
            namespace=self.namespace,
            limit=batch_size,
            pagination_token=cursor
        )
        
        vector_ids = [vec['id'] for vec in list_response.get('vectors', [])]
        
        if not vector_ids:
            return [], None
        
        # Fetch the actual vectors
        fetch_response = self.index.fetch(vector_ids, namespace=self.namespace)
        
        records = []
        for vector_id, vector_data in fetch_response.get('vectors', {}).items():
            # Extract text from metadata if present
            metadata = vector_data.get('metadata', {})
            text = metadata.get('text')
            
            # Create clean metadata without text (since text has its own field)
            clean_metadata = {k: v for k, v in metadata.items() if k != 'text'}
            
            record = VectorRecord(
                id=vector_data['id'],
                vector=vector_data['values'],
                text=text,
                metadata=clean_metadata
            )
            records.append(record)
        
        # Get next cursor from pagination
        next_cursor = list_response.get('pagination', {}).get('next')
        
        return records, next_cursor
    
    def close(self) -> None:
        """Close the connection and clean up resources."""
        # Pinecone doesn't require explicit cleanup
        self.index = None