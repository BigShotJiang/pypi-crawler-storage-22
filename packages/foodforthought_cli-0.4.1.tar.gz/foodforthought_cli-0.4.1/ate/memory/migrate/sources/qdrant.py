"""Qdrant migration source implementation."""
from typing import Optional, List, Tuple

try:
    from qdrant_client import QdrantClient
except ImportError:
    QdrantClient = None

from ..base import MigrationSource, VectorRecord, MigrationEstimate


class QdrantMigrationSource(MigrationSource):
    """Migration source for Qdrant vector database."""
    
    def __init__(self, url: str, collection_name: str, api_key: Optional[str] = None):
        """Initialize Qdrant migration source.
        
        Args:
            url: Qdrant server URL
            collection_name: Name of the collection to migrate from
            api_key: Optional API key for authentication
        """
        self.url = url
        self.collection_name = collection_name
        self.api_key = api_key
        self.client = None
    
    @property
    def source_type(self) -> str:
        """Return the source type."""
        return "qdrant"
    
    @property
    def source_name(self) -> str:
        """Return the source name."""
        return self.collection_name
    
    def connect(self) -> None:
        """Connect to Qdrant."""
        if QdrantClient is None:
            raise ImportError("qdrant-client library is required for Qdrant migration")
        
        self.client = QdrantClient(url=self.url, api_key=self.api_key)
    
    def estimate(self) -> MigrationEstimate:
        """Estimate migration size and time."""
        if not self.client:
            raise RuntimeError("Must call connect() first")
        
        collection_info = self.client.get_collection(self.collection_name)
        
        total_vectors = collection_info.points_count
        dimensions = collection_info.config.params.vectors.size
        
        # Rough estimates
        bytes_per_vector = dimensions * 4 + 1024  # 4 bytes per float + metadata overhead
        estimated_mv2_bytes = total_vectors * bytes_per_vector
        estimated_seconds = total_vectors / 1000.0  # Rough estimate of 1000 vectors/second
        
        return MigrationEstimate(
            total_vectors=total_vectors,
            dimensions=dimensions,
            estimated_mv2_bytes=estimated_mv2_bytes,
            estimated_seconds=estimated_seconds
        )
    
    def fetch_batch(self, batch_size: int = 10000, cursor: Optional[str] = None) -> Tuple[List[VectorRecord], Optional[str]]:
        """Fetch a batch of records from Qdrant."""
        if not self.client:
            raise RuntimeError("Must call connect() first")
        
        # Use cursor directly as offset (Qdrant handles different offset types)
        offset = cursor
        
        # Scroll through points
        points, next_page_offset = self.client.scroll(
            collection_name=self.collection_name,
            limit=batch_size,
            offset=offset,
            with_payload=True,
            with_vectors=True
        )
        
        records = []
        for point in points:
            # Extract text from payload if present
            payload = point.payload or {}
            text = payload.get('text')
            
            # Create clean metadata without text
            clean_metadata = {k: v for k, v in payload.items() if k != 'text'}
            
            record = VectorRecord(
                id=str(point.id),
                vector=point.vector,
                text=text,
                metadata=clean_metadata
            )
            records.append(record)
        
        # Convert next_page_offset to cursor string
        next_cursor = str(next_page_offset) if next_page_offset is not None else None
        
        return records, next_cursor
    
    def close(self) -> None:
        """Close the connection and clean up resources."""
        if self.client:
            self.client.close()
            self.client = None