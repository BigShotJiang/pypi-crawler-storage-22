"""Weaviate migration source implementation."""
from typing import Optional, List, Tuple, Dict, Any

try:
    import weaviate
    WEAVIATE_AVAILABLE = True
except ImportError:
    # Create a simple mock structure for testing
    class WeaviateMock:
        class Client:
            pass
        class auth:
            class AuthApiKey:
                def __init__(self, **kwargs):
                    pass
    
    weaviate = WeaviateMock()
    WEAVIATE_AVAILABLE = False

from ..base import MigrationSource, VectorRecord, MigrationEstimate


class WeaviateMigrationSource(MigrationSource):
    """Migration source for Weaviate vector database."""
    
    def __init__(self, host: str, class_name: str, api_key: Optional[str] = None, auth_config: Optional[Dict[str, Any]] = None):
        """Initialize Weaviate migration source.
        
        Args:
            host: Weaviate server host URL
            class_name: Name of the class to migrate from
            api_key: Optional API key for authentication
            auth_config: Optional authentication configuration
        """
        self.host = host
        self.class_name = class_name
        self.api_key = api_key
        self.auth_config = auth_config or {}
        self.client = None
    
    @property
    def source_type(self) -> str:
        """Return the source type."""
        return "weaviate"
    
    @property
    def source_name(self) -> str:
        """Return the source name."""
        return self.class_name
    
    def connect(self) -> None:
        """Connect to Weaviate."""
        if weaviate.Client is None:
            raise ImportError("weaviate-client library is required for Weaviate migration")
        
        # Build client configuration
        if self.api_key:
            auth = weaviate.auth.AuthApiKey(api_key=self.api_key)
            self.client = weaviate.Client(url=self.host, auth_client_secret=auth)
        else:
            self.client = weaviate.Client(url=self.host)
    
    def estimate(self) -> MigrationEstimate:
        """Estimate migration size and time."""
        if not self.client:
            raise RuntimeError("Must call connect() first")
        
        # Get aggregate count using fluent API
        result = (self.client.query
                     .aggregate(self.class_name)
                     .with_meta_count()
                     .do())
        
        aggregate_data = result.get('data', {}).get('Aggregate', {}).get(self.class_name, [])
        
        if aggregate_data:
            total_vectors = aggregate_data[0].get('meta', {}).get('count', 0)
        else:
            total_vectors = 0
        
        # Get class schema to determine vector dimensions
        schema = self.client.schema.get()
        dimensions = 768  # Default assumption
        
        for class_def in schema.get('classes', []):
            if class_def['class'] == self.class_name:
                # Look for vectorizer configuration
                if 'vectorizer' in class_def:
                    # This is a simplified assumption; real implementation would inspect vectorizer config
                    dimensions = 1536 if 'openai' in class_def['vectorizer'].lower() else 768
                break
        
        # Rough estimates
        bytes_per_vector = dimensions * 4 + 2048  # 4 bytes per float + metadata overhead
        estimated_mv2_bytes = total_vectors * bytes_per_vector
        estimated_seconds = total_vectors / 800.0  # Rough estimate of 800 vectors/second
        
        return MigrationEstimate(
            total_vectors=total_vectors,
            dimensions=dimensions,
            estimated_mv2_bytes=estimated_mv2_bytes,
            estimated_seconds=estimated_seconds
        )
    
    def fetch_batch(self, batch_size: int = 10000, cursor: Optional[str] = None) -> Tuple[List[VectorRecord], Optional[str]]:
        """Fetch a batch of records from Weaviate."""
        if not self.client:
            raise RuntimeError("Must call connect() first")
        
        # Parse cursor as offset if provided
        offset = 0
        if cursor:
            try:
                offset = int(cursor)
            except (ValueError, TypeError):
                offset = 0
        
        # Query with additional vector data
        result = (self.client.query
                 .get(self.class_name)
                 .with_additional(['id', 'vector'])
                 .with_limit(batch_size)
                 .with_offset(offset)
                 .do())
        
        if 'errors' in result:
            raise Exception(f"Weaviate query error: {result['errors']}")
        
        objects = result.get('data', {}).get('Get', {}).get(self.class_name, [])
        
        records = []
        for obj in objects:
            additional = obj.get('_additional', {})
            obj_id = additional.get('id', 'unknown')
            vector = additional.get('vector', [])
            
            # Extract text and metadata
            properties = {k: v for k, v in obj.items() if not k.startswith('_')}
            text = properties.get('text') or properties.get('content')
            
            # Create clean metadata without text
            clean_metadata = {k: v for k, v in properties.items() if k not in ('text', 'content')}
            
            record = VectorRecord(
                id=obj_id,
                vector=vector,
                text=text,
                metadata=clean_metadata
            )
            records.append(record)
        
        # Determine if there are more results
        next_cursor = str(offset + batch_size) if len(objects) == batch_size else None
        
        return records, next_cursor
    
    def close(self) -> None:
        """Close the connection and clean up resources."""
        # Weaviate client doesn't require explicit cleanup
        self.client = None