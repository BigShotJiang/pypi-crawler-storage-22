"""Search operations and result structures."""

from dataclasses import dataclass
from typing import List, Dict, Any, Optional


@dataclass
class SearchResult:
    """Result from a memory search operation.
    
    Attributes:
        frame_id: Unique identifier for the memory frame
        text: The original content text
        title: Title of the content (if provided)
        score: Relevance score (higher = more relevant)
        tags: List of tags associated with this content
        metadata: Dictionary of additional metadata
        engine: Search engine used ("lex" | "vec" | "hybrid")
    """
    frame_id: int
    text: str
    title: Optional[str]
    score: float
    tags: List[str]
    metadata: Dict[str, Any]
    engine: str = "lex"