"""
Telemetry recording system for capturing robot demonstrations.

Records all interface method calls as transferable data that can be:
- Uploaded to FoodforThought
- Labeled by humans (task segmentation)
- Used to train policies
- Replayed on different hardware

Example - Basic recording:
    from ate.drivers import MechDogDriver
    from ate.recording import RecordingSession

    dog = MechDogDriver(port="/dev/cu.usbserial-10")
    dog.connect()

    # Record a demonstration
    with RecordingSession(dog, name="pickup_toy") as session:
        dog.stand()
        dog.walk(Vector3.forward(), speed=0.3)
        time.sleep(2)
        dog.stop()

    # Save the recording
    session.save("pickup_toy.demonstration")

Example - Visual recording with object detection:
    from ate.drivers import MechDogDriver
    from ate.recording import VisualRecordingSession
    from ate.detection import TrashDetector

    dog = MechDogDriver(port="/dev/cu.usbserial-10", config=config)
    dog.connect()

    # Create detector for automatic object detection
    detector = TrashDetector()

    # Record with visual capture at 5 fps
    with VisualRecordingSession(
        dog,
        name="trash_pickup",
        capture_fps=5.0,
        detector=detector,
    ) as session:
        dog.stand()
        dog.walk(Vector3.forward(), speed=0.2)
        time.sleep(5)

    # Save recording and visual frames separately
    session.save("trash_pickup.demonstration")
    session.save_frames("trash_pickup_frames.json")

    print(session.summary())
"""

from .session import RecordingSession, RecordedCall
from .wrapper import RecordingWrapper
from .demonstration import Demonstration, load_demonstration
from .upload import DemonstrationUploader, upload_demonstration
from .visual import (
    VisualRecordingSession,
    RecordedFrame,
    DetectionResult,
    load_frames,
)

__all__ = [
    # Core recording
    "RecordingSession",
    "RecordedCall",
    "RecordingWrapper",
    # Demonstrations
    "Demonstration",
    "load_demonstration",
    # Upload
    "DemonstrationUploader",
    "upload_demonstration",
    # Visual recording with detection
    "VisualRecordingSession",
    "RecordedFrame",
    "DetectionResult",
    "load_frames",
]
