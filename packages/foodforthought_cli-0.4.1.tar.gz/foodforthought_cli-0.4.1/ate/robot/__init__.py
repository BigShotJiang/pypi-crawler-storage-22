"""
Robot management system for ATE.

Provides:
- Auto-discovery of robots on network and USB
- Robot profiles for easy configuration
- Capability introspection
- Interactive setup wizard

Example usage:
    from ate.robot import RobotManager, discover_robots

    # Auto-discover robots
    found = discover_robots()
    # > [DiscoveredRobot(type='mechdog', port='/dev/cu.usbserial-10', camera_ip='192.168.1.100')]

    # Load saved profile
    manager = RobotManager()
    dog = manager.get_robot("my_mechdog")

    # Introspect capabilities
    info = manager.get_capabilities(dog)
    # > {'locomotion': ['walk', 'turn', 'stand'], 'camera': ['get_image']}
"""

from .discovery import (
    DiscoveredRobot,
    discover_robots,
    discover_serial_robots,
    discover_network_cameras,
)

from .profiles import (
    RobotProfile,
    load_profile,
    save_profile,
    list_profiles,
    delete_profile,
)

from .registry import (
    RobotRegistry,
    KNOWN_ROBOTS,
    get_robot_info,
)

from .introspection import (
    get_capabilities,
    get_methods,
    test_capability,
)

from .manager import (
    RobotManager,
)

from .primitives import (
    PrimitiveLibrary,
    Primitive,
    CompoundSkill,
    Behavior,
    HardwareRequirement,
    create_mechdog_primitives,
)

from .perception import (
    PerceptionSystem,
    PerceptionResult,
    LivePerceptionExecutor,
)

from .behaviors import (
    BehaviorExecutor,
    BehaviorResult,
    DetectionResult,
)

from .visual_servoing import (
    VisualServoController,
    GreenBallDetector,
    TargetDetection,
    ServoState,
    create_mechdog_servo_controller,
)

from .agentic_servo import (
    AgenticServoController,
    HaikuServoAgent,
    AgentDecision,
    run_agentic_pickup,
    run_agentic_pickup_wifi,
)

from .servo_mapper import (
    ServoProbe,
    ServoMapperAgent,
    ServoMapping,
    ServoRange,
    ServoType,
    PrimitiveGenerator,
    run_servo_mapping,
)

from .calibration_state import (
    CalibrationState,
    DirectionMapping,
    check_prerequisite,
    require_direction_calibration,
)

from .direction_calibration import (
    DirectionCalibrator,
    TwitchResult,
    run_direction_calibration,
    load_direction_calibration,
    get_toward_direction,
)

from .visual_servo_loop import (
    VisualServoLoop,
    ServoConfig,
    ServoRole,
    ServoState,
    ServoResult,
    ServoIteration,
    load_direction_calibration_for_servos,
)

from .target_calibration import (
    TargetProfile,
    TargetCalibrator,
    HSVRange,
    run_target_calibration,
    list_target_profiles,
    detect_with_profile,
)

__all__ = [
    # Discovery
    "DiscoveredRobot",
    "discover_robots",
    "discover_serial_robots",
    "discover_network_cameras",
    # Profiles
    "RobotProfile",
    "load_profile",
    "save_profile",
    "list_profiles",
    "delete_profile",
    # Registry
    "RobotRegistry",
    "KNOWN_ROBOTS",
    "get_robot_info",
    # Introspection
    "get_capabilities",
    "get_methods",
    "test_capability",
    # Manager
    "RobotManager",
    # Primitives
    "PrimitiveLibrary",
    "Primitive",
    "CompoundSkill",
    "Behavior",
    "HardwareRequirement",
    "create_mechdog_primitives",
    # Perception
    "PerceptionSystem",
    "PerceptionResult",
    "LivePerceptionExecutor",
    # Behaviors
    "BehaviorExecutor",
    "BehaviorResult",
    "DetectionResult",
    # Visual Servoing
    "VisualServoController",
    "GreenBallDetector",
    "TargetDetection",
    "ServoState",
    "create_mechdog_servo_controller",
    # Agentic Servoing
    "AgenticServoController",
    "HaikuServoAgent",
    "AgentDecision",
    "run_agentic_pickup",
    "run_agentic_pickup_wifi",
    # Servo Mapping
    "ServoProbe",
    "ServoMapperAgent",
    "ServoMapping",
    "ServoRange",
    "ServoType",
    "PrimitiveGenerator",
    "run_servo_mapping",
    # Calibration State Machine
    "CalibrationState",
    "DirectionMapping",
    "check_prerequisite",
    "require_direction_calibration",
    # Direction Calibration (Twitch Test)
    "DirectionCalibrator",
    "TwitchResult",
    "run_direction_calibration",
    "load_direction_calibration",
    "get_toward_direction",
    # Visual Servo Loop
    "VisualServoLoop",
    "ServoConfig",
    "ServoRole",
    "ServoState",
    "ServoResult",
    "ServoIteration",
    "load_direction_calibration_for_servos",
    # Target Detection Calibration
    "TargetProfile",
    "TargetCalibrator",
    "HSVRange",
    "run_target_calibration",
    "list_target_profiles",
    "detect_with_profile",
]
