"""
Upload skill libraries and calibrations to FoodforThought.

Creates artifacts with proper lineage:
- Raw: pose images from dual cameras
- Processed: servo calibration data
- Labeled: named poses with semantic labels
- Skill: generated Python skill code
"""

import os
import json
import base64
import requests
from datetime import datetime
from typing import Optional, Dict, Any, List
from pathlib import Path

from .calibration import RobotCalibration, load_calibration
from .visual_labeler import SkillLibrary, load_skill_library


# API configuration
BASE_URL = os.getenv("ATE_API_URL", "https://www.kindly.fyi/api")
CONFIG_FILE = Path.home() / ".ate" / "config.json"


class APIError(Exception):
    """
    Custom exception for API errors with helpful context.

    Provides:
    - Status code and reason
    - Parsed error message from API response
    - Suggestions for fixing common issues
    """

    def __init__(
        self,
        message: str,
        status_code: int = 0,
        response_body: Optional[Dict] = None,
        suggestions: Optional[List[str]] = None,
    ):
        self.status_code = status_code
        self.response_body = response_body or {}
        self.suggestions = suggestions or []

        # Build helpful error message
        parts = [message]

        if self.response_body:
            # Try to extract error details from response
            error_detail = (
                self.response_body.get("error") or
                self.response_body.get("message") or
                self.response_body.get("detail") or
                self.response_body.get("errors")
            )
            if error_detail:
                if isinstance(error_detail, list):
                    error_detail = "; ".join(str(e) for e in error_detail)
                parts.append(f"Details: {error_detail}")

        if self.suggestions:
            parts.append("Suggestions:")
            for s in self.suggestions:
                parts.append(f"  - {s}")

        super().__init__("\n".join(parts))


def parse_api_error(response: requests.Response, endpoint: str) -> APIError:
    """
    Parse API error response and return helpful APIError.

    Analyzes common error patterns and provides actionable suggestions.
    """
    status = response.status_code
    suggestions = []

    # Try to parse response body
    try:
        body = response.json()
    except Exception:
        body = {"raw": response.text[:500] if response.text else "No response body"}

    # Common error patterns and suggestions
    if status == 400:
        error_text = str(body).lower()

        if "project" in endpoint:
            suggestions.append("Use --project-id to specify an existing project")
            suggestions.append("Check project name doesn't contain special characters")
        elif "calibration" in endpoint:
            suggestions.append("Ensure calibration file contains required fields: name, version, method")
            suggestions.append("Check robot slug exists: ate robot identify --search <robot-name>")

    elif status == 401:
        suggestions.append("Session may have expired. Run: ate login")
        suggestions.append("Check ATE_API_KEY environment variable if using API key auth")

    elif status == 403:
        suggestions.append("You may not have permission for this operation")
        suggestions.append("Check if the project/resource is owned by another user")

    elif status == 404:
        error_text = str(body).lower()

        if "robot" in error_text and "not found" in error_text:
            suggestions.append("Robot slug may not exist in the database")
            suggestions.append("Search for robots: ate robot identify --search <partial-name>")
            suggestions.append("List available robots: ate robot list")

        elif "project" in endpoint:
            suggestions.append("Project ID may be invalid or deleted")
            suggestions.append("List your projects to find valid IDs")

    elif status == 422:
        suggestions.append("Request data validation failed")
        if body.get("errors"):
            for field, errors in body.get("errors", {}).items():
                suggestions.append(f"Field '{field}': {errors}")

    elif status >= 500:
        suggestions.append("Server error - this is likely temporary")
        suggestions.append("Try again in a few minutes")
        suggestions.append("Report persistent issues at: https://github.com/kindlyrobotics/monorepo/issues")

    return APIError(
        message=f"API request failed: {status} {response.reason} for {endpoint}",
        status_code=status,
        response_body=body,
        suggestions=suggestions,
    )


class SkillLibraryUploader:
    """
    Uploads skill libraries to FoodforThought.

    Creates a complete data lineage:
    raw (images) → processed (calibration) → labeled (poses) → skill (code)
    """

    def __init__(
        self,
        base_url: str = BASE_URL,
        api_key: Optional[str] = None,
    ):
        self.base_url = base_url
        self.headers = {
            "Content-Type": "application/json",
        }

        token = None

        # Load from config file (device auth flow)
        if CONFIG_FILE.exists():
            try:
                with open(CONFIG_FILE) as f:
                    config = json.load(f)
                    token = config.get("access_token") or config.get("api_key")
            except Exception:
                pass

        # Override with explicit api_key or env var
        if api_key:
            token = api_key
        elif os.getenv("ATE_API_KEY"):
            token = os.getenv("ATE_API_KEY")

        if token:
            self.headers["Authorization"] = f"Bearer {token}"
        else:
            raise ValueError(
                "Not logged in. Run 'ate login' to authenticate."
            )

    def _request(self, method: str, endpoint: str, **kwargs) -> Dict:
        """
        Make HTTP request to API with improved error handling.

        Raises APIError with helpful suggestions on failure.
        """
        url = f"{self.base_url}{endpoint}"
        response = requests.request(method, url, headers=self.headers, **kwargs)

        if not response.ok:
            raise parse_api_error(response, endpoint)

        try:
            return response.json()
        except json.JSONDecodeError:
            return {"raw": response.text}

    def get_or_create_project(self, name: str, description: str = "") -> str:
        """Get existing project or create a new one."""
        # Try to find existing project
        try:
            projects = self._request("GET", "/projects")
            for project in projects.get("projects", []):
                if project.get("name") == name:
                    return project["id"]
        except Exception:
            pass

        # Create new project
        response = self._request("POST", "/projects", json={
            "name": name,
            "description": description or f"Robot skill library for {name}",
            "visibility": "private",
        })
        return response.get("project", {}).get("id")

    def upload_skill_library(
        self,
        library: SkillLibrary,
        calibration: RobotCalibration,
        project_id: Optional[str] = None,
        include_images: bool = True,
    ) -> Dict[str, Any]:
        """
        Upload a complete skill library to FoodforThought.

        Creates artifacts with lineage:
        1. Raw: pose images
        2. Processed: servo calibration
        3. Labeled: poses with semantic labels
        4. Skill: generated Python code

        Args:
            library: SkillLibrary to upload
            calibration: RobotCalibration with servo data
            project_id: Optional project ID (will create if not provided)
            include_images: Whether to upload pose images

        Returns:
            Dict with artifact IDs and URLs
        """
        result = {
            "project_id": None,
            "artifacts": [],
            "lineage": [],
        }

        # Get or create project
        if not project_id:
            project_id = self.get_or_create_project(
                f"{library.robot_name}_skills",
                f"Skill library for {library.robot_model}",
            )
        result["project_id"] = project_id

        # 1. Upload pose images as raw artifacts
        image_artifact_ids = []
        if include_images:
            images_dir = Path.home() / ".ate" / "skill_images" / library.robot_name
            if images_dir.exists():
                for img_path in images_dir.glob("*.jpg"):
                    try:
                        artifact_id = self._upload_image_artifact(
                            project_id=project_id,
                            image_path=img_path,
                            robot_name=library.robot_name,
                        )
                        image_artifact_ids.append(artifact_id)
                        result["artifacts"].append({
                            "id": artifact_id,
                            "stage": "raw",
                            "name": img_path.stem,
                        })
                    except Exception as e:
                        print(f"Warning: Failed to upload {img_path.name}: {e}")

        # 2. Upload calibration as processed artifact
        calibration_artifact_id = self._upload_calibration_artifact(
            project_id=project_id,
            calibration=calibration,
            parent_ids=image_artifact_ids[:5] if image_artifact_ids else None,  # Link to some images
        )
        result["artifacts"].append({
            "id": calibration_artifact_id,
            "stage": "processed",
            "name": f"{library.robot_name}_calibration",
        })

        # 3. Upload poses as labeled artifacts
        pose_artifact_ids = []
        for pose_name, pose in calibration.poses.items():
            pose_artifact_id = self._upload_pose_artifact(
                project_id=project_id,
                pose_name=pose_name,
                pose=pose,
                calibration=calibration,
                parent_id=calibration_artifact_id,
            )
            pose_artifact_ids.append(pose_artifact_id)
            result["artifacts"].append({
                "id": pose_artifact_id,
                "stage": "labeled",
                "name": pose_name,
            })

        # 4. Upload skills as skill artifacts
        for action_name, action in library.actions.items():
            skill_artifact_id = self._upload_skill_artifact(
                project_id=project_id,
                action_name=action_name,
                action=action,
                library=library,
                calibration=calibration,
                trained_on=pose_artifact_ids,  # Skills trained on poses
            )
            result["artifacts"].append({
                "id": skill_artifact_id,
                "stage": "skill",
                "name": action_name,
            })

        return result

    def _upload_image_artifact(
        self,
        project_id: str,
        image_path: Path,
        robot_name: str,
    ) -> str:
        """Upload an image as a raw artifact."""
        # Read and encode image
        with open(image_path, "rb") as f:
            image_data = base64.b64encode(f.read()).decode("utf-8")

        response = self._request("POST", "/artifacts", json={
            "projectId": project_id,
            "name": image_path.stem,
            "stage": "raw",
            "type": "dataset",
            "metadata": {
                "robot_name": robot_name,
                "image_type": "pose_capture",
                "filename": image_path.name,
                "format": "jpeg",
                "source": "visual_labeler",
                "captured_at": datetime.now().isoformat(),
            },
        })
        return response.get("artifact", {}).get("id")

    def _upload_calibration_artifact(
        self,
        project_id: str,
        calibration: RobotCalibration,
        parent_ids: Optional[List[str]] = None,
    ) -> str:
        """Upload servo calibration as a processed artifact."""
        # Serialize calibration
        calibration_data = {
            "robot_model": calibration.robot_model,
            "robot_name": calibration.robot_name,
            "serial_port": calibration.serial_port,
            "baud_rate": calibration.baud_rate,
            "camera_url": calibration.camera_url,
            "servos": {
                str(sid): {
                    "servo_id": s.servo_id,
                    "name": s.name,
                    "joint_type": s.joint_type.value,
                    "min_value": s.min_value,
                    "max_value": s.max_value,
                    "center_value": s.center_value,
                    "positions": s.positions,
                }
                for sid, s in calibration.servos.items()
            },
            "calibrated_at": calibration.calibrated_at,
        }

        response = self._request("POST", "/artifacts", json={
            "projectId": project_id,
            "name": f"{calibration.robot_name}_calibration",
            "stage": "processed",
            "type": "dataset",
            "metadata": {
                "robot_model": calibration.robot_model,
                "robot_name": calibration.robot_name,
                "servo_count": len(calibration.servos),
                "pose_count": len(calibration.poses),
                "calibration_data": calibration_data,
                "source": "visual_labeler",
            },
        })
        return response.get("artifact", {}).get("id")

    def _upload_pose_artifact(
        self,
        project_id: str,
        pose_name: str,
        pose,
        calibration: RobotCalibration,
        parent_id: str,
    ) -> str:
        """Upload a named pose as a labeled artifact."""
        # Build pose data with semantic labels
        servo_labels = {}
        for sid, value in pose.servo_positions.items():
            servo_cal = calibration.servos.get(sid)
            if servo_cal:
                servo_labels[str(sid)] = {
                    "name": servo_cal.name,
                    "joint_type": servo_cal.joint_type.value,
                    "value": value,
                    "normalized": (value - servo_cal.min_value) / max(1, servo_cal.max_value - servo_cal.min_value),
                }

        response = self._request("POST", "/artifacts", json={
            "projectId": project_id,
            "name": pose_name,
            "stage": "labeled",
            "type": "dataset",
            "parentArtifactId": parent_id,
            "transformationType": "labeling",
            "transformationNotes": f"Pose '{pose_name}' labeled from calibration",
            "metadata": {
                "robot_name": calibration.robot_name,
                "pose_name": pose_name,
                "description": pose.description,
                "servo_positions": pose.servo_positions,
                "servo_labels": servo_labels,
                "transition_time_ms": pose.transition_time_ms,
                "image_path": pose.image_path,
                "source": "visual_labeler",
            },
        })
        return response.get("artifact", {}).get("id")

    def _upload_skill_artifact(
        self,
        project_id: str,
        action_name: str,
        action,
        library: SkillLibrary,
        calibration: RobotCalibration,
        trained_on: List[str],
    ) -> str:
        """Upload a generated skill as a skill artifact."""
        # Generate skill code
        from .visual_labeler import DualCameraLabeler
        labeler = DualCameraLabeler(
            serial_port=calibration.serial_port or "",
            robot_name=library.robot_name,
            robot_model=library.robot_model,
        )
        labeler.calibrator.calibration = calibration
        skill_code = labeler.generate_skill_code(action)

        # Determine skill type based on action structure
        skill_type = "primitive"  # Default
        dependencies = []
        hardware_requirements = []

        # Infer hardware requirements from servo usage
        servo_ids = set()
        for step in action.steps:
            if hasattr(step, 'pose_name') and step.pose_name:
                pose = calibration.poses.get(step.pose_name)
                if pose:
                    servo_ids.update(pose.servo_positions.keys())

        # Map servo IDs to hardware requirements
        for sid in servo_ids:
            servo = calibration.servos.get(sid)
            if servo:
                if "gripper" in servo.name.lower():
                    if "gripper" not in hardware_requirements:
                        hardware_requirements.append("gripper")
                elif "arm" in servo.name.lower() or "shoulder" in servo.name.lower() or "elbow" in servo.name.lower():
                    if "arm" not in hardware_requirements:
                        hardware_requirements.append("arm")
                elif "leg" in servo.name.lower() or "hip" in servo.name.lower() or "thigh" in servo.name.lower():
                    if "legs" not in hardware_requirements:
                        hardware_requirements.append("legs")

        # Determine skill type based on complexity
        if len(action.steps) == 1:
            skill_type = "primitive"
        elif len(action.steps) <= 5:
            skill_type = "compound"
        else:
            skill_type = "sequence"

        # If action has perception tags, it's a behavior
        if action.tags:
            if any(t in ["perception", "detection", "visual", "feedback"] for t in action.tags):
                skill_type = "behavior"
                if "camera" not in hardware_requirements:
                    hardware_requirements.append("camera")

        response = self._request("POST", "/artifacts", json={
            "projectId": project_id,
            "name": action_name,
            "stage": "skill",
            "type": "code",
            "trainedOn": trained_on,
            "trainingNotes": f"Skill '{action_name}' generated from {len(action.steps)} poses",
            "metadata": {
                "robot_model": library.robot_model,
                "robot_name": library.robot_name,
                "action_type": action.action_type.value,
                "description": action.description,
                "steps": [s.to_dict() for s in action.steps],
                "skill_code": skill_code,
                "tags": action.tags,
                "source": "visual_labeler",
                "generated_at": datetime.now().isoformat(),
                # New skill hierarchy fields
                "skill_type": skill_type,  # "primitive", "compound", "behavior"
                "dependencies": dependencies,  # List of skill names this depends on
                "hardware_requirements": hardware_requirements,  # ["arm", "gripper", "legs", "camera"]
                "servo_count": len(servo_ids),
            },
        })
        return response.get("artifact", {}).get("id")


def upload_primitives(
    robot_name: str,
    project_id: Optional[str] = None,
    api_key: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Upload programmatic primitives from PrimitiveLibrary.

    These are the cleanly-generated skills from primitives.py with proper
    skill_type, dependencies, and hardware_requirements.

    Args:
        robot_name: Name of the robot
        project_id: Optional project ID
        api_key: Optional API key

    Returns:
        Dict with upload results
    """
    from .primitives import PrimitiveLibrary

    uploader = SkillLibraryUploader(api_key=api_key)

    # Get or create project
    if not project_id:
        project_id = uploader.get_or_create_project(
            f"{robot_name}_primitives",
            f"Primitive skill library for {robot_name}",
        )

    result = {
        "project_id": project_id,
        "artifacts": [],
    }

    # Create primitive library (without robot for now)
    lib = PrimitiveLibrary(robot_interface=None)

    # Upload primitives
    for name, prim in lib.primitives.items():
        response = uploader._request("POST", "/artifacts", json={
            "projectId": project_id,
            "name": name,
            "stage": "skill",
            "type": "code",
            "metadata": {
                "robot_name": robot_name,
                "skill_type": "primitive",
                "description": prim.description,
                "servo_targets": {str(k): v for k, v in prim.servo_targets.items()},
                "duration_ms": prim.duration_ms,
                "hardware_requirements": [r.value for r in prim.hardware],
                "dependencies": [],
                "source": "primitives_library",
            },
        })
        result["artifacts"].append({
            "id": response.get("artifact", {}).get("id"),
            "stage": "skill",
            "name": name,
            "skill_type": "primitive",
        })

    # Upload compound skills
    for name, compound in lib.compounds.items():
        response = uploader._request("POST", "/artifacts", json={
            "projectId": project_id,
            "name": name,
            "stage": "skill",
            "type": "code",
            "metadata": {
                "robot_name": robot_name,
                "skill_type": "compound",
                "description": compound.description,
                "steps": compound.steps,
                "hardware_requirements": [r.value for r in compound.hardware],
                "dependencies": compound.steps,  # Each step is a dependency
                "source": "primitives_library",
            },
        })
        result["artifacts"].append({
            "id": response.get("artifact", {}).get("id"),
            "stage": "skill",
            "name": name,
            "skill_type": "compound",
        })

    # Upload behaviors
    for name, behavior in lib.behaviors.items():
        response = uploader._request("POST", "/artifacts", json={
            "projectId": project_id,
            "name": name,
            "stage": "skill",
            "type": "code",
            "metadata": {
                "robot_name": robot_name,
                "skill_type": "behavior",
                "description": behavior.description,
                "steps": behavior.steps,
                "hardware_requirements": [r.value for r in behavior.hardware],
                "dependencies": [],  # Behaviors infer deps from steps
                "requires_perception": True,
                "source": "primitives_library",
            },
        })
        result["artifacts"].append({
            "id": response.get("artifact", {}).get("id"),
            "stage": "skill",
            "name": name,
            "skill_type": "behavior",
        })

    return result


def upload_skill_library(
    robot_name: str,
    project_id: Optional[str] = None,
    include_images: bool = True,
    api_key: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Convenience function to upload a skill library.

    Args:
        robot_name: Name of the robot (matches calibration/library filenames)
        project_id: Optional project ID
        include_images: Whether to upload pose images
        api_key: Optional API key

    Returns:
        Dict with upload results
    """
    # Load calibration
    calibration = load_calibration(robot_name)
    if not calibration:
        raise ValueError(f"No calibration found for: {robot_name}")

    # Load skill library
    library = load_skill_library(robot_name)
    if not library:
        raise ValueError(f"No skill library found for: {robot_name}")

    uploader = SkillLibraryUploader(api_key=api_key)
    return uploader.upload_skill_library(
        library=library,
        calibration=calibration,
        project_id=project_id,
        include_images=include_images,
    )
