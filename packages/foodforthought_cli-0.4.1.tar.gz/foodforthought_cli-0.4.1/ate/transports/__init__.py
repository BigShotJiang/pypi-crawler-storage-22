"""
Transport Abstraction Layer for Robot Communication.

This module provides a unified interface for communicating with robots
across different physical transports (BLE, USB Serial, WiFi, etc.).

The key insight: Users shouldn't need to know HOW a robot communicates,
only WHAT they want it to do.

Example:
    from ate.transports import connect

    # Auto-discovers available transports
    robot = await connect("mechdog")

    # These work regardless of underlying transport
    await robot.walk_forward()
    await robot.gripper_open()  # Automatically routes to USB if BLE can't do it
"""

from typing import Optional

from .base import (
    RobotTransport,
    TransportCapability,
    TransportState,
    ConnectionInfo,
    CommandResult,
    HiWonderProtocol,
)
from .ble import BLETransport
from .serial import SerialTransport
from .hybrid import HybridTransport


async def connect(
    address: Optional[str] = None,
    name: Optional[str] = None,
    transport_type: str = "auto"
) -> HybridTransport:
    """
    Connect to a robot with automatic transport detection.

    This is the main entry point for the transport layer.
    It discovers available transports and creates a hybrid connection.

    Args:
        address: Specific address to connect to (BLE MAC/UUID or serial port)
        name: Robot name hint for discovery (e.g., "mechdog")
        transport_type: "auto", "ble", "serial", or "hybrid"

    Returns:
        Connected HybridTransport instance

    Example:
        # Auto-discover and connect
        robot = await connect(name="mechdog")
        await robot.walk_forward()

        # Connect to specific BLE device
        robot = await connect(address="FAF198B6-D9A4-CC27-7BBA-3159F63A61A9")

        # Connect to specific serial port
        robot = await connect(address="/dev/cu.usbmodem1234")
    """
    robot = HybridTransport()

    if address:
        # Direct address provided
        await robot.connect(address, name=name)
    else:
        # Discover and connect to first matching device
        connections = await HybridTransport.discover(timeout=5.0)

        ble_device = None
        serial_device = None

        for conn in connections:
            if name and conn.name and name.lower() not in conn.name.lower():
                continue

            if conn.transport_type == "ble" and not ble_device:
                ble_device = conn
            elif conn.transport_type == "serial" and not serial_device:
                serial_device = conn

        if ble_device:
            await robot.connect_ble(ble_device.address)
        if serial_device:
            await robot.connect_serial(serial_device.address)

    return robot


async def discover(timeout: float = 5.0) -> list[ConnectionInfo]:
    """
    Discover all available robots across all transports.

    Returns:
        List of discovered robot connections
    """
    return await HybridTransport.discover(timeout)


__all__ = [
    # Core types
    "RobotTransport",
    "TransportCapability",
    "TransportState",
    "ConnectionInfo",
    "CommandResult",
    # Protocol adapters
    "HiWonderProtocol",
    # Transport implementations
    "BLETransport",
    "SerialTransport",
    "HybridTransport",
    # Convenience functions
    "connect",
    "discover",
]
