"""
Serial Transport Implementation.

Uses pyserial for USB serial communication with robots.
This is needed for capabilities that BLE can't handle (like arm control
on MechDog, which requires MicroPython REPL access).

Key learnings:
- MechDog exposes MicroPython REPL over USB-C serial
- ARM control uses servo library: `arm.arm_move([(id, angle), ...])`
- Gripper is typically servo ID 10-12 depending on mounting
- Must handle REPL prompts (>>>) and async output
"""

import asyncio
from typing import Optional
from dataclasses import dataclass
import re

try:
    import serial
    import serial.tools.list_ports
    SERIAL_AVAILABLE = True
except ImportError:
    SERIAL_AVAILABLE = False
    serial = None

from .base import (
    RobotTransport,
    TransportState,
    TransportCapability,
    ConnectionInfo,
    CommandResult,
)


@dataclass
class SerialConfig:
    """Configuration for serial transport."""
    baudrate: int = 115200
    timeout: float = 1.0
    write_timeout: float = 1.0
    response_wait: float = 0.5
    repl_prompt: str = ">>>"


class SerialTransport(RobotTransport):
    """
    USB Serial transport for robot communication.

    Handles both raw serial protocols and MicroPython REPL connections.

    Example:
        async with SerialTransport() as transport:
            if await transport.connect("/dev/cu.usbmodem1234"):
                # MicroPython command
                result = await transport.send_command(
                    "arm.arm_move([(1, 90), (2, 45)])"
                )
    """

    def __init__(self, config: Optional[SerialConfig] = None):
        super().__init__()

        if not SERIAL_AVAILABLE:
            raise ImportError(
                "pyserial is required for serial transport. "
                "Install with: pip install pyserial"
            )

        self.config = config or SerialConfig()
        self._serial: Optional[serial.Serial] = None
        self._read_task: Optional[asyncio.Task] = None
        self._response_buffer: bytes = b""
        self._is_repl = False

    async def connect(self, address: str, **kwargs) -> bool:
        """
        Connect to a serial port.

        Args:
            address: Serial port path (e.g., /dev/cu.usbmodem1234)
            **kwargs: baudrate, timeout, repl_mode

        Returns:
            True if connected successfully
        """
        self._state = TransportState.CONNECTING

        try:
            baudrate = kwargs.get("baudrate", self.config.baudrate)

            self._serial = serial.Serial(
                port=address,
                baudrate=baudrate,
                timeout=self.config.timeout,
                write_timeout=self.config.write_timeout,
            )

            if not self._serial.is_open:
                self._serial.open()

            # Clear any pending data
            self._serial.reset_input_buffer()
            self._serial.reset_output_buffer()

            # Check if this is a REPL
            self._is_repl = await self._detect_repl()

            self._state = TransportState.CONNECTED
            self._connection_info = ConnectionInfo(
                transport_type="serial",
                address=address,
                name=kwargs.get("name", "USB Serial"),
                metadata={
                    "baudrate": baudrate,
                    "is_repl": self._is_repl,
                }
            )

            # Start background reader
            self._read_task = asyncio.create_task(self._read_loop())

            return True

        except Exception as e:
            print(f"Serial connect error: {e}")
            self._state = TransportState.ERROR
            return False

    async def disconnect(self) -> None:
        """Disconnect from serial port."""
        if self._read_task:
            self._read_task.cancel()
            try:
                await self._read_task
            except asyncio.CancelledError:
                pass
            self._read_task = None

        if self._serial and self._serial.is_open:
            self._serial.close()

        self._serial = None
        self._state = TransportState.DISCONNECTED
        self._connection_info = None

    async def send(self, data: bytes) -> CommandResult:
        """Send raw bytes to the robot."""
        if not self.is_connected or not self._serial:
            return CommandResult(success=False, error="Not connected")

        import time
        start = time.perf_counter()

        try:
            # Clear buffer
            self._response_buffer = b""
            self._serial.reset_input_buffer()

            # Send data
            self._serial.write(data)
            self._serial.flush()

            # Wait for response
            await asyncio.sleep(self.config.response_wait)

            # Read response
            response = b""
            while self._serial.in_waiting > 0:
                response += self._serial.read(self._serial.in_waiting)
                await asyncio.sleep(0.05)

            latency = (time.perf_counter() - start) * 1000

            return CommandResult(
                success=True,
                response=response.decode('utf-8', errors='replace'),
                raw_data=response,
                latency_ms=latency
            )

        except Exception as e:
            return CommandResult(success=False, error=str(e))

    async def send_command(self, command: str) -> CommandResult:
        """
        Send a command string.

        If connected to REPL, wraps appropriately.
        """
        if self._is_repl:
            # MicroPython REPL - add newline
            data = (command.strip() + "\r\n").encode('utf-8')
        else:
            data = command.encode('utf-8')

        return await self.send(data)

    @classmethod
    async def discover(cls, timeout: float = 5.0) -> list[ConnectionInfo]:
        """Discover available serial ports."""
        if not SERIAL_AVAILABLE:
            return []

        ports = serial.tools.list_ports.comports()
        results = []

        for port in ports:
            # Filter for likely robot connections
            # MechDog typically appears as "USB Modem" or similar
            desc = (port.description or "").lower()
            is_robot = any(kw in desc for kw in [
                "modem", "serial", "uart", "esp32", "micropython",
                "ch340", "cp210", "ftdi"
            ])

            if is_robot or port.vid:  # Has vendor ID = USB device
                results.append(ConnectionInfo(
                    transport_type="serial",
                    address=port.device,
                    name=port.description,
                    metadata={
                        "vid": port.vid,
                        "pid": port.pid,
                        "serial_number": port.serial_number,
                    }
                ))

        return results

    async def probe_capabilities(self) -> set[TransportCapability]:
        """Probe what this serial connection can do."""
        caps = set()

        if not self.is_connected:
            return caps

        if self._is_repl:
            # MicroPython REPL - check what modules exist
            result = await self.send_command("dir()")
            if result.success and result.response:
                response = result.response.lower()

                # Check for arm control
                if "arm" in response or "servo" in response:
                    caps.add(TransportCapability.ARM_POSITION)
                    caps.add(TransportCapability.GRIPPER)
                    caps.add(TransportCapability.RAW_SERVO)

                # Check for locomotion
                if "gait" in response or "motion" in response:
                    caps.add(TransportCapability.WALK)
                    caps.add(TransportCapability.POSTURE)

                # Check for sensors
                if "ultrasonic" in response or "sensor" in response:
                    caps.add(TransportCapability.ULTRASONIC)

                if "imu" in response:
                    caps.add(TransportCapability.IMU)

        caps.add(TransportCapability.BIDIRECTIONAL)
        return caps

    async def _detect_repl(self) -> bool:
        """Detect if this is a MicroPython REPL."""
        if not self._serial:
            return False

        try:
            # Send Ctrl+C to interrupt any running code
            self._serial.write(b"\x03")
            await asyncio.sleep(0.3)

            # Send empty line to trigger prompt
            self._serial.write(b"\r\n")
            await asyncio.sleep(0.3)

            # Read response
            response = b""
            while self._serial.in_waiting > 0:
                response += self._serial.read(self._serial.in_waiting)
                await asyncio.sleep(0.05)

            text = response.decode('utf-8', errors='replace')
            return self.config.repl_prompt in text or "MicroPython" in text

        except Exception:
            return False

    async def _read_loop(self) -> None:
        """Background loop to read incoming data."""
        while self.is_connected and self._serial:
            try:
                if self._serial.in_waiting > 0:
                    data = self._serial.read(self._serial.in_waiting)
                    self._response_buffer += data
                    await self._notify_handlers(data)
                await asyncio.sleep(0.1)
            except asyncio.CancelledError:
                break
            except Exception:
                await asyncio.sleep(0.1)

    # ========== MicroPython REPL Commands ==========
    # These are specific to MechDog's MicroPython firmware

    async def arm_move(self, positions: list[tuple[int, int]]) -> CommandResult:
        """
        Move arm servos to specified positions.

        Args:
            positions: List of (servo_id, angle) tuples
                       MechDog arm: servos 1-5 typically
                       Gripper: servo 10-12 depending on mount

        Example:
            await transport.arm_move([(1, 90), (2, 45), (3, 60)])
        """
        pos_str = ", ".join(f"({sid}, {angle})" for sid, angle in positions)
        cmd = f"arm.arm_move([{pos_str}])"
        return await self.send_command(cmd)

    async def gripper_open(self) -> CommandResult:
        """Open the gripper (assumes servo ID 10)."""
        return await self.send_command("arm.gripper_open()")

    async def gripper_close(self) -> CommandResult:
        """Close the gripper."""
        return await self.send_command("arm.gripper_close()")

    async def get_servo_position(self, servo_id: int) -> Optional[int]:
        """Read current position of a servo."""
        result = await self.send_command(f"arm.read_servo({servo_id})")
        if result.success and result.response:
            # Parse response like "90" or ">>> 90"
            match = re.search(r"(\d+)", result.response)
            if match:
                return int(match.group(1))
        return None

    async def execute_python(self, code: str) -> CommandResult:
        """Execute arbitrary Python code on the robot."""
        return await self.send_command(code)
