"""
Markerless URDF Generation Module.

This module provides tools for generating URDF robot descriptions from
webcam video without physical markers, using foundation computer vision
models (SAM 2, Depth Anything V2) for perception.

Main commands:
- ate urdf scan capture    - Capture video and annotate links
- ate urdf scan segment    - Generate segmented point clouds
- ate urdf scan optimize   - Fit kinematic parameters
- ate urdf scan mesh       - Generate visual/collision meshes
- ate urdf scan synthesize - Generate final URDF
- ate urdf scan            - Run full pipeline

Usage:
    ate urdf scan --output ./my_robot/ --name my_robot --scale-ref "gripper:85mm"
"""

from .scan_session import ScanSession, ScanSessionError
from .scale import parse_scale_ref, parse_measurement

__version__ = "0.1.0"

__all__ = [
    "ScanSession",
    "ScanSessionError",
    "parse_scale_ref",
    "parse_measurement",
]
