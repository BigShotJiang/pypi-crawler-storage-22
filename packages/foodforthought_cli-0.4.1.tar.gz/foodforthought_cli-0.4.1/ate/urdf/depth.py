"""
Depth estimation for URDF generation using Depth Anything V2.

This module handles Phase 2b of the pipeline:
1. Load Depth Anything V2 model (with caching)
2. Estimate depth for each video frame
3. Apply scale factor from reference measurement

Output: Per-frame metric depth maps.
"""

import logging
from typing import Dict, Generator, List, Optional, Tuple
from pathlib import Path

logger = logging.getLogger(__name__)

try:
    import numpy as np
    import cv2
    DEPS_AVAILABLE = True
except ImportError:
    DEPS_AVAILABLE = False
    np = None
    cv2 = None


class DepthError(Exception):
    """Error during depth estimation."""
    pass


class DepthProcessor:
    """
    Depth estimation processor using Depth Anything V2.

    Provides metric depth maps from RGB video frames.
    """

    def __init__(self, device: str = "cpu"):
        """
        Initialize processor.

        Args:
            device: Compute device ("cuda" or "cpu")
        """
        if not DEPS_AVAILABLE:
            raise DepthError(
                "Required dependencies not installed. "
                "Run: pip install numpy opencv-python"
            )

        self.device = device
        self._estimator = None

    def _get_estimator(self):
        """Get or load the depth estimator."""
        if self._estimator is None:
            from .models import ModelCache
            ModelCache.set_device(self.device)
            self._estimator = ModelCache.get_depth_model()
        return self._estimator

    def estimate_frame(
        self,
        frame: "np.ndarray",
        scale_factor: float = 1.0,
    ) -> "np.ndarray":
        """
        Estimate metric depth for a single frame.

        Args:
            frame: BGR image from OpenCV
            scale_factor: Scale factor to convert to meters

        Returns:
            Depth map (H, W) in meters
        """
        estimator = self._get_estimator()
        return estimator.estimate_metric(frame, scale_factor)

    def process_video(
        self,
        video_path: str,
        scale_factor: float = 1.0,
        frame_skip: int = 1,
        progress_callback: Optional[callable] = None,
    ) -> Generator[Tuple[int, "np.ndarray", "np.ndarray"], None, None]:
        """
        Process video frames and yield depth maps.

        Args:
            video_path: Path to video file
            scale_factor: Scale factor for metric depth
            frame_skip: Process every Nth frame (1 = all frames)
            progress_callback: Optional callback(current, total)

        Yields:
            Tuple of (frame_idx, rgb_frame, depth_map)
        """
        cap = cv2.VideoCapture(video_path)
        if not cap.isOpened():
            raise DepthError(f"Could not open video: {video_path}")

        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        frame_idx = 0

        try:
            while True:
                ret, frame = cap.read()
                if not ret:
                    break

                if frame_idx % frame_skip == 0:
                    depth = self.estimate_frame(frame, scale_factor)
                    yield frame_idx, frame, depth

                    if progress_callback:
                        progress_callback(frame_idx + 1, total_frames)

                frame_idx += 1

        finally:
            cap.release()

    def process_video_batch(
        self,
        video_path: str,
        scale_factor: float = 1.0,
        frame_skip: int = 1,
        progress_callback: Optional[callable] = None,
    ) -> Dict[int, "np.ndarray"]:
        """
        Process all video frames and return depth maps.

        Args:
            video_path: Path to video file
            scale_factor: Scale factor for metric depth
            frame_skip: Process every Nth frame
            progress_callback: Optional progress callback

        Returns:
            Dict mapping frame_idx -> depth_map
        """
        result = {}
        for frame_idx, _, depth in self.process_video(
            video_path, scale_factor, frame_skip, progress_callback
        ):
            result[frame_idx] = depth

        logger.info(f"Processed {len(result)} depth frames")
        return result


def compute_scale_from_mask(
    depth: "np.ndarray",
    mask: "np.ndarray",
    reference_meters: float,
    dimension: str = "width",
) -> float:
    """
    Compute scale factor from a masked region and known dimension.

    This implements the Kalib method for scale calibration:
    Correlate a known physical dimension with its measured size
    in the depth map.

    Args:
        depth: Depth map (H, W)
        mask: Binary mask for the reference object
        reference_meters: Known physical dimension in meters
        dimension: "width" or "height" of the masked region

    Returns:
        Scale factor (meters per depth unit)
    """
    if not DEPS_AVAILABLE:
        raise DepthError("NumPy not available")

    # Get bounding box of mask
    coords = np.where(mask)
    if len(coords[0]) == 0:
        raise DepthError("Empty mask - cannot compute scale")

    y_min, y_max = coords[0].min(), coords[0].max()
    x_min, x_max = coords[1].min(), coords[1].max()

    # Compute dimension in pixels
    if dimension == "width":
        pixel_size = x_max - x_min
    else:
        pixel_size = y_max - y_min

    if pixel_size == 0:
        raise DepthError(f"Zero {dimension} in mask - cannot compute scale")

    # Get median depth in the mask
    masked_depth = depth[mask]
    median_depth = np.median(masked_depth)

    if median_depth == 0:
        raise DepthError("Zero depth in masked region")

    # Compute scale: physical_size / (pixel_size * depth)
    # This gives us a factor to convert depth * pixels to meters
    scale = reference_meters / (pixel_size * median_depth)

    logger.info(
        f"Scale computed: {scale:.6f} m/unit "
        f"(ref={reference_meters}m, pixels={pixel_size}, depth={median_depth:.2f})"
    )

    return scale


def calibrate_depth_scale(
    depth_processor: DepthProcessor,
    video_path: str,
    masks: Dict[str, Dict[int, "np.ndarray"]],
    reference_link: str,
    reference_meters: float,
    dimension: str = "width",
) -> float:
    """
    Calibrate global depth scale from a reference link.

    Args:
        depth_processor: DepthProcessor instance
        video_path: Path to video
        masks: Segmentation masks from segmentation phase
        reference_link: Name of the link with known dimension
        reference_meters: Known dimension in meters
        dimension: "width" or "height"

    Returns:
        Calibrated scale factor
    """
    if reference_link not in masks:
        raise DepthError(
            f"Reference link '{reference_link}' not found in masks. "
            f"Available: {list(masks.keys())}"
        )

    # Get first frame's data
    link_masks = masks[reference_link]
    first_frame_idx = min(link_masks.keys())
    mask = link_masks[first_frame_idx]

    # Get depth for first frame
    cap = cv2.VideoCapture(video_path)
    cap.set(cv2.CAP_PROP_POS_FRAMES, first_frame_idx)
    ret, frame = cap.read()
    cap.release()

    if not ret:
        raise DepthError(f"Could not read frame {first_frame_idx}")

    # Estimate depth without scaling
    depth = depth_processor.estimate_frame(frame, scale_factor=1.0)

    # Compute scale
    scale = compute_scale_from_mask(depth, mask, reference_meters, dimension)

    return scale


def visualize_depth(
    depth: "np.ndarray",
    colormap: int = cv2.COLORMAP_VIRIDIS,
    min_depth: Optional[float] = None,
    max_depth: Optional[float] = None,
) -> "np.ndarray":
    """
    Visualize a depth map as a colored image.

    Args:
        depth: Depth map (H, W)
        colormap: OpenCV colormap
        min_depth: Minimum depth for normalization
        max_depth: Maximum depth for normalization

    Returns:
        BGR visualization image
    """
    if not DEPS_AVAILABLE:
        raise DepthError("OpenCV not available")

    # Normalize
    if min_depth is None:
        min_depth = depth.min()
    if max_depth is None:
        max_depth = depth.max()

    normalized = (depth - min_depth) / (max_depth - min_depth + 1e-8)
    normalized = np.clip(normalized * 255, 0, 255).astype(np.uint8)

    # Apply colormap
    colored = cv2.applyColorMap(normalized, colormap)

    return colored


def run_depth_estimation(
    session: "ScanSession",
    masks: Dict[str, Dict[int, "np.ndarray"]],
    frame_skip: int = 1,
    progress_callback: Optional[callable] = None,
) -> Tuple[Dict[int, "np.ndarray"], float]:
    """
    Run depth estimation phase on a scan session.

    Args:
        session: ScanSession with video
        masks: Segmentation masks from Phase 2a
        frame_skip: Process every Nth frame
        progress_callback: Optional progress callback

    Returns:
        Tuple of (depth_maps, scale_factor)
    """
    # Initialize processor
    processor = DepthProcessor(device=session.metadata.device)

    # Calibrate scale if reference provided
    scale_factor = 1.0
    if session.metadata.scale_ref:
        from .scale import parse_scale_ref
        ref_link, ref_meters = parse_scale_ref(session.metadata.scale_ref)

        logger.info(f"Calibrating scale from '{ref_link}' = {ref_meters}m")
        scale_factor = calibrate_depth_scale(
            processor,
            str(session.video_path),
            masks,
            ref_link,
            ref_meters,
        )
        session.metadata.scale_factor = scale_factor
        session.save_metadata()

    # Process all frames
    depth_maps = processor.process_video_batch(
        str(session.video_path),
        scale_factor=scale_factor,
        frame_skip=frame_skip,
        progress_callback=progress_callback,
    )

    logger.info(f"Depth estimation complete: {len(depth_maps)} frames, scale={scale_factor:.6f}")
    return depth_maps, scale_factor


__all__ = [
    "DepthError",
    "DepthProcessor",
    "compute_scale_from_mask",
    "calibrate_depth_scale",
    "visualize_depth",
    "run_depth_estimation",
]
