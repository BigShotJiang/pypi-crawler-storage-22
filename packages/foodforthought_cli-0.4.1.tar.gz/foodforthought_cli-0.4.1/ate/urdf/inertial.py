"""
Inertial property estimation for URDF generation.

This module handles Phase 5a of the pipeline:
1. Compute mesh volume from visual/collision meshes
2. Estimate mass from assumed material density
3. Calculate center of mass and inertia tensor

Video cannot measure mass directly, so we use geometric estimation
with configurable material density assumptions.
"""

import logging
from typing import Dict, List, Optional, Tuple
from pathlib import Path
from dataclasses import dataclass

logger = logging.getLogger(__name__)

try:
    import numpy as np
    NUMPY_AVAILABLE = True
except ImportError:
    NUMPY_AVAILABLE = False
    np = None

try:
    import trimesh
    TRIMESH_AVAILABLE = True
except ImportError:
    TRIMESH_AVAILABLE = False
    trimesh = None


class InertialError(Exception):
    """Error during inertial estimation."""
    pass


# Common material densities in kg/m^3
MATERIAL_DENSITIES = {
    "pla": 1250.0,          # PLA plastic
    "abs": 1040.0,          # ABS plastic
    "petg": 1270.0,         # PETG plastic
    "nylon": 1150.0,        # Nylon
    "aluminum": 2700.0,     # Aluminum
    "steel": 7850.0,        # Steel
    "carbon_fiber": 1600.0, # Carbon fiber composite
    "wood": 700.0,          # Average wood
    "foam": 100.0,          # Foam/hollow structures
    "default": 1200.0,      # Default (generic plastic)
}


@dataclass
class InertialProperties:
    """Inertial properties for a single link."""
    link_name: str
    mass: float  # kg
    center_of_mass: List[float]  # [x, y, z] meters
    inertia: Dict[str, float]  # ixx, ixy, ixz, iyy, iyz, izz (kg*m^2)

    def to_dict(self) -> Dict:
        return {
            "link_name": self.link_name,
            "mass": self.mass,
            "center_of_mass": self.center_of_mass,
            "inertia": self.inertia,
        }

    @property
    def inertia_tensor(self) -> "np.ndarray":
        """Get 3x3 inertia tensor matrix."""
        return np.array([
            [self.inertia["ixx"], self.inertia["ixy"], self.inertia["ixz"]],
            [self.inertia["ixy"], self.inertia["iyy"], self.inertia["iyz"]],
            [self.inertia["ixz"], self.inertia["iyz"], self.inertia["izz"]],
        ])


def compute_mesh_volume(mesh: "trimesh.Trimesh") -> float:
    """
    Compute volume of a mesh.

    Args:
        mesh: Trimesh object (should be watertight)

    Returns:
        Volume in cubic meters
    """
    if not TRIMESH_AVAILABLE:
        raise InertialError("trimesh not available")

    if not mesh.is_watertight:
        logger.warning("Mesh is not watertight, volume may be inaccurate")
        # Attempt to fix
        mesh.fill_holes()

    return abs(mesh.volume)


def compute_inertia_tensor(
    mesh: "trimesh.Trimesh",
    density: float,
) -> Tuple[float, "np.ndarray", "np.ndarray"]:
    """
    Compute mass, center of mass, and inertia tensor.

    Uses trimesh's built-in moment_inertia calculation.

    Args:
        mesh: Trimesh object
        density: Material density (kg/m^3)

    Returns:
        Tuple of (mass, center_of_mass, inertia_tensor)
    """
    if not TRIMESH_AVAILABLE:
        raise InertialError("trimesh not available")

    # Compute volume and mass
    volume = compute_mesh_volume(mesh)
    mass = volume * density

    # Ensure minimum mass for stability
    MIN_MASS = 0.001  # 1 gram
    if mass < MIN_MASS:
        logger.warning(f"Very small mass {mass:.6f}kg, clamping to {MIN_MASS}kg")
        mass = MIN_MASS

    # Get center of mass
    com = mesh.center_mass

    # Get inertia tensor at center of mass
    # trimesh returns inertia in mesh units, we need to scale by density
    inertia = mesh.moment_inertia * density

    return mass, com, inertia


def estimate_inertial_from_mesh(
    mesh_path: Path,
    density: float = 1200.0,
) -> InertialProperties:
    """
    Estimate inertial properties from a mesh file.

    Args:
        mesh_path: Path to mesh file (OBJ, STL, etc.)
        density: Material density (kg/m^3)

    Returns:
        InertialProperties for the mesh
    """
    if not TRIMESH_AVAILABLE:
        raise InertialError("trimesh not available")

    # Load mesh
    mesh = trimesh.load(str(mesh_path))

    if not isinstance(mesh, trimesh.Trimesh):
        if hasattr(mesh, 'geometry'):
            meshes = list(mesh.geometry.values())
            if meshes:
                mesh = meshes[0]
            else:
                raise InertialError(f"No geometry in {mesh_path}")
        else:
            raise InertialError(f"Invalid mesh in {mesh_path}")

    # Compute inertial properties
    mass, com, inertia = compute_inertia_tensor(mesh, density)

    # Extract link name from path
    link_name = mesh_path.stem.replace("_visual", "").replace("_collision", "")

    return InertialProperties(
        link_name=link_name,
        mass=float(mass),
        center_of_mass=com.tolist(),
        inertia={
            "ixx": float(inertia[0, 0]),
            "ixy": float(inertia[0, 1]),
            "ixz": float(inertia[0, 2]),
            "iyy": float(inertia[1, 1]),
            "iyz": float(inertia[1, 2]),
            "izz": float(inertia[2, 2]),
        },
    )


def estimate_inertial_box(
    dimensions: List[float],
    density: float = 1200.0,
    link_name: str = "link",
) -> InertialProperties:
    """
    Estimate inertial properties for a box shape.

    Useful for simple approximations or fallback.

    Args:
        dimensions: [width, height, depth] in meters
        density: Material density
        link_name: Name for the link

    Returns:
        InertialProperties
    """
    if not NUMPY_AVAILABLE:
        raise InertialError("NumPy not available")

    w, h, d = dimensions
    volume = w * h * d
    mass = volume * density

    # Box inertia formulas
    ixx = (1/12) * mass * (h**2 + d**2)
    iyy = (1/12) * mass * (w**2 + d**2)
    izz = (1/12) * mass * (w**2 + h**2)

    return InertialProperties(
        link_name=link_name,
        mass=mass,
        center_of_mass=[0.0, 0.0, 0.0],
        inertia={
            "ixx": ixx, "ixy": 0.0, "ixz": 0.0,
            "iyy": iyy, "iyz": 0.0,
            "izz": izz,
        },
    )


def estimate_all_inertials(
    session: "ScanSession",
    density: float = 1200.0,
    use_collision_mesh: bool = True,
    progress_callback: Optional[callable] = None,
) -> Dict[str, InertialProperties]:
    """
    Estimate inertial properties for all links.

    Args:
        session: ScanSession with meshes
        density: Material density
        use_collision_mesh: Use collision (simpler) or visual mesh
        progress_callback: Optional progress callback

    Returns:
        Dict mapping link_name -> InertialProperties
    """
    meshes_dir = session.meshes_dir

    # Find meshes
    suffix = "_collision.obj" if use_collision_mesh else "_visual.obj"
    mesh_files = list(meshes_dir.glob(f"*{suffix}"))

    if not mesh_files:
        # Fall back to other type
        alt_suffix = "_visual.obj" if use_collision_mesh else "_collision.obj"
        mesh_files = list(meshes_dir.glob(f"*{alt_suffix}"))

    if not mesh_files:
        raise InertialError(f"No mesh files found in {meshes_dir}")

    result = {}
    total = len(mesh_files)

    for i, mesh_path in enumerate(mesh_files):
        try:
            props = estimate_inertial_from_mesh(mesh_path, density)
            result[props.link_name] = props

            logger.info(
                f"Estimated inertial for '{props.link_name}': "
                f"mass={props.mass:.4f}kg, com={props.center_of_mass}"
            )
        except Exception as e:
            logger.error(f"Failed to estimate inertial for {mesh_path}: {e}")

        if progress_callback:
            progress_callback(i + 1, total)

    logger.info(f"Estimated inertials for {len(result)} links")
    return result


def get_density_for_material(material: str) -> float:
    """
    Get density for a material name.

    Args:
        material: Material name (e.g., "pla", "aluminum")

    Returns:
        Density in kg/m^3
    """
    material = material.lower().replace(" ", "_").replace("-", "_")
    return MATERIAL_DENSITIES.get(material, MATERIAL_DENSITIES["default"])


__all__ = [
    "InertialError",
    "MATERIAL_DENSITIES",
    "InertialProperties",
    "compute_mesh_volume",
    "compute_inertia_tensor",
    "estimate_inertial_from_mesh",
    "estimate_inertial_box",
    "estimate_all_inertials",
    "get_density_for_material",
]
