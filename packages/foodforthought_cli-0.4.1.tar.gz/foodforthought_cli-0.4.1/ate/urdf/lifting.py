"""
2D to 3D lifting utilities for point cloud generation.

This module handles Phase 2c of the pipeline:
1. Back-project masked pixels to 3D using depth and intrinsics
2. Aggregate per-frame point clouds
3. Save point clouds in PLY format

Uses the standard pinhole camera model for projection.
"""

import logging
from typing import Dict, List, Optional, Tuple
from pathlib import Path

logger = logging.getLogger(__name__)

try:
    import numpy as np
    NUMPY_AVAILABLE = True
except ImportError:
    NUMPY_AVAILABLE = False
    np = None


class LiftingError(Exception):
    """Error during 2D to 3D lifting."""
    pass


def lift_to_3d(
    rgb: "np.ndarray",
    depth: "np.ndarray",
    mask: "np.ndarray",
    intrinsics: Tuple[float, float, float, float],
) -> Tuple["np.ndarray", "np.ndarray"]:
    """
    Back-project masked pixels to 3D points.

    Uses the standard pinhole camera model:
        X = (u - cx) * Z / fx
        Y = (v - cy) * Z / fy
        Z = depth

    Args:
        rgb: RGB image (H, W, 3)
        depth: Depth map (H, W) in meters
        mask: Binary mask (H, W)
        intrinsics: (fx, fy, cx, cy) camera intrinsics

    Returns:
        Tuple of (points, colors):
        - points: (N, 3) XYZ coordinates in meters
        - colors: (N, 3) RGB values [0-255]
    """
    if not NUMPY_AVAILABLE:
        raise LiftingError("NumPy not available")

    fx, fy, cx, cy = intrinsics

    # Get masked pixel coordinates
    v, u = np.where(mask)  # v = row = y, u = col = x

    if len(u) == 0:
        return np.zeros((0, 3)), np.zeros((0, 3), dtype=np.uint8)

    # Get depth values
    z = depth[v, u]

    # Filter out invalid depths
    valid = (z > 0.01) & (z < 100.0)  # 1cm to 100m
    u, v, z = u[valid], v[valid], z[valid]

    if len(u) == 0:
        return np.zeros((0, 3)), np.zeros((0, 3), dtype=np.uint8)

    # Back-project to 3D
    x = (u - cx) * z / fx
    y = (v - cy) * z / fy

    points = np.stack([x, y, z], axis=1)

    # Get colors
    colors = rgb[v, u]

    return points.astype(np.float32), colors.astype(np.uint8)


def save_ply(
    path: Path,
    points: "np.ndarray",
    colors: Optional["np.ndarray"] = None,
) -> None:
    """
    Save point cloud to PLY file.

    Args:
        path: Output file path
        points: (N, 3) XYZ coordinates
        colors: Optional (N, 3) RGB colors [0-255]
    """
    if not NUMPY_AVAILABLE:
        raise LiftingError("NumPy not available")

    n_points = len(points)

    with open(path, 'w') as f:
        # Header
        f.write("ply\n")
        f.write("format ascii 1.0\n")
        f.write(f"element vertex {n_points}\n")
        f.write("property float x\n")
        f.write("property float y\n")
        f.write("property float z\n")
        if colors is not None:
            f.write("property uchar red\n")
            f.write("property uchar green\n")
            f.write("property uchar blue\n")
        f.write("end_header\n")

        # Data
        for i in range(n_points):
            x, y, z = points[i]
            if colors is not None:
                r, g, b = colors[i]
                f.write(f"{x:.6f} {y:.6f} {z:.6f} {int(r)} {int(g)} {int(b)}\n")
            else:
                f.write(f"{x:.6f} {y:.6f} {z:.6f}\n")

    logger.debug(f"Saved {n_points} points to {path}")


def load_ply(path: Path) -> Tuple["np.ndarray", Optional["np.ndarray"]]:
    """
    Load point cloud from PLY file.

    Args:
        path: Path to PLY file

    Returns:
        Tuple of (points, colors) or (points, None)
    """
    if not NUMPY_AVAILABLE:
        raise LiftingError("NumPy not available")

    points = []
    colors = []
    has_color = False
    in_header = True
    n_vertices = 0

    with open(path, 'r') as f:
        for line in f:
            line = line.strip()

            if in_header:
                if line.startswith("element vertex"):
                    n_vertices = int(line.split()[-1])
                elif "property" in line and "red" in line:
                    has_color = True
                elif line == "end_header":
                    in_header = False
            else:
                parts = line.split()
                x, y, z = float(parts[0]), float(parts[1]), float(parts[2])
                points.append([x, y, z])

                if has_color and len(parts) >= 6:
                    r, g, b = int(parts[3]), int(parts[4]), int(parts[5])
                    colors.append([r, g, b])

    points = np.array(points, dtype=np.float32)
    colors = np.array(colors, dtype=np.uint8) if colors else None

    return points, colors


def aggregate_point_clouds(
    clouds: List["np.ndarray"],
    colors_list: Optional[List["np.ndarray"]] = None,
    voxel_size: Optional[float] = None,
) -> Tuple["np.ndarray", Optional["np.ndarray"]]:
    """
    Aggregate multiple point clouds into one.

    Args:
        clouds: List of (N, 3) point clouds
        colors_list: Optional list of (N, 3) color arrays
        voxel_size: Optional voxel size for downsampling

    Returns:
        Tuple of (aggregated_points, aggregated_colors)
    """
    if not NUMPY_AVAILABLE:
        raise LiftingError("NumPy not available")

    if not clouds:
        return np.zeros((0, 3)), None

    # Concatenate all clouds
    points = np.vstack(clouds)

    colors = None
    if colors_list:
        colors = np.vstack(colors_list)

    # Optional voxel downsampling
    if voxel_size and voxel_size > 0:
        points, colors = voxel_downsample(points, colors, voxel_size)

    return points, colors


def voxel_downsample(
    points: "np.ndarray",
    colors: Optional["np.ndarray"],
    voxel_size: float,
) -> Tuple["np.ndarray", Optional["np.ndarray"]]:
    """
    Downsample point cloud using voxel grid.

    Args:
        points: (N, 3) point cloud
        colors: Optional (N, 3) colors
        voxel_size: Voxel edge length

    Returns:
        Downsampled (points, colors)
    """
    if len(points) == 0:
        return points, colors

    # Compute voxel indices
    voxel_indices = np.floor(points / voxel_size).astype(np.int32)

    # Hash voxels
    unique_voxels, inverse_indices = np.unique(
        voxel_indices, axis=0, return_inverse=True
    )

    # Average points in each voxel
    n_voxels = len(unique_voxels)
    new_points = np.zeros((n_voxels, 3))
    new_colors = np.zeros((n_voxels, 3)) if colors is not None else None
    counts = np.zeros(n_voxels)

    for i, idx in enumerate(inverse_indices):
        new_points[idx] += points[i]
        if colors is not None:
            new_colors[idx] += colors[i]
        counts[idx] += 1

    new_points /= counts[:, np.newaxis]
    if new_colors is not None:
        new_colors /= counts[:, np.newaxis]
        new_colors = new_colors.astype(np.uint8)

    logger.debug(f"Voxel downsampled: {len(points)} -> {len(new_points)} points")
    return new_points.astype(np.float32), new_colors


def generate_link_clouds(
    session: "ScanSession",
    masks: Dict[str, Dict[int, "np.ndarray"]],
    depth_maps: Dict[int, "np.ndarray"],
    intrinsics: Optional[Tuple[float, float, float, float]] = None,
    frame_skip: int = 1,
    voxel_size: float = 0.005,
    progress_callback: Optional[callable] = None,
) -> Dict[str, Path]:
    """
    Generate and save point clouds for each link.

    Args:
        session: ScanSession with video
        masks: Segmentation masks
        depth_maps: Depth maps from depth estimation
        intrinsics: Camera intrinsics (fx, fy, cx, cy)
        frame_skip: Use every Nth frame
        voxel_size: Voxel size for downsampling (meters)
        progress_callback: Optional progress callback

    Returns:
        Dict mapping link_name -> cloud_path
    """
    import cv2

    # Get intrinsics
    if intrinsics is None:
        from .scale import estimate_intrinsics_from_resolution
        w, h = session.metadata.resolution
        intrinsics = estimate_intrinsics_from_resolution(w, h)
        logger.info(f"Estimated intrinsics: fx={intrinsics[0]:.1f}, fy={intrinsics[1]:.1f}")

    # Open video
    cap = cv2.VideoCapture(str(session.video_path))
    if not cap.isOpened():
        raise LiftingError(f"Could not open video: {session.video_path}")

    # Generate clouds for each link
    link_clouds = {name: [] for name in masks.keys()}
    link_colors = {name: [] for name in masks.keys()}

    total_frames = len(depth_maps)
    processed = 0

    try:
        for frame_idx in sorted(depth_maps.keys()):
            if frame_idx % frame_skip != 0:
                continue

            # Read frame
            cap.set(cv2.CAP_PROP_POS_FRAMES, frame_idx)
            ret, frame = cap.read()
            if not ret:
                continue

            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            depth = depth_maps[frame_idx]

            # Lift each link's masked region
            for link_name, link_masks in masks.items():
                if frame_idx not in link_masks:
                    continue

                mask = link_masks[frame_idx]
                points, colors = lift_to_3d(rgb, depth, mask, intrinsics)

                if len(points) > 0:
                    link_clouds[link_name].append(points)
                    link_colors[link_name].append(colors)

            processed += 1
            if progress_callback:
                progress_callback(processed, total_frames)

    finally:
        cap.release()

    # Aggregate and save each link's cloud
    result = {}
    clouds_dir = session.clouds_dir
    clouds_dir.mkdir(parents=True, exist_ok=True)

    for link_name in masks.keys():
        if not link_clouds[link_name]:
            logger.warning(f"No points generated for link '{link_name}'")
            continue

        # Aggregate
        points, colors = aggregate_point_clouds(
            link_clouds[link_name],
            link_colors[link_name],
            voxel_size=voxel_size,
        )

        # Save
        cloud_path = clouds_dir / f"{link_name}.ply"
        save_ply(cloud_path, points, colors)
        result[link_name] = cloud_path

        logger.info(f"Saved cloud for '{link_name}': {len(points)} points")

    return result


def run_lifting(
    session: "ScanSession",
    masks: Dict[str, Dict[int, "np.ndarray"]],
    depth_maps: Dict[int, "np.ndarray"],
    frame_skip: int = 1,
    voxel_size: float = 0.005,
    progress_callback: Optional[callable] = None,
) -> Dict[str, Path]:
    """
    Run the lifting phase to generate point clouds.

    Args:
        session: ScanSession
        masks: Segmentation masks
        depth_maps: Depth maps
        frame_skip: Process every Nth frame
        voxel_size: Voxel grid size for downsampling
        progress_callback: Optional progress callback

    Returns:
        Dict mapping link_name -> cloud_path
    """
    cloud_paths = generate_link_clouds(
        session,
        masks,
        depth_maps,
        frame_skip=frame_skip,
        voxel_size=voxel_size,
        progress_callback=progress_callback,
    )

    # Update session metadata
    session.metadata.segment_complete = True
    session.save_metadata()

    logger.info(f"Lifting complete: {len(cloud_paths)} point clouds generated")
    return cloud_paths


__all__ = [
    "LiftingError",
    "lift_to_3d",
    "save_ply",
    "load_ply",
    "aggregate_point_clouds",
    "voxel_downsample",
    "generate_link_clouds",
    "run_lifting",
]
