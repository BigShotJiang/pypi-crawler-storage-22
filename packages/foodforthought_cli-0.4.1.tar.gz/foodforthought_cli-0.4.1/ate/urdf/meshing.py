"""
Mesh generation from point clouds for URDF.

This module handles Phase 4a of the pipeline:
1. Aggregate per-frame point clouds into canonical link shapes
2. Generate visual meshes via surface reconstruction
3. Support multiple reconstruction methods (Poisson, SuGaR)

Output: Visual mesh files (OBJ format) for each link.
"""

import logging
from typing import Dict, List, Optional, Tuple
from pathlib import Path

logger = logging.getLogger(__name__)

try:
    import numpy as np
    NUMPY_AVAILABLE = True
except ImportError:
    NUMPY_AVAILABLE = False
    np = None

try:
    import trimesh
    TRIMESH_AVAILABLE = True
except ImportError:
    TRIMESH_AVAILABLE = False
    trimesh = None


class MeshingError(Exception):
    """Error during mesh generation."""
    pass


def poisson_reconstruct(
    points: "np.ndarray",
    colors: Optional["np.ndarray"] = None,
    depth: int = 8,
) -> "trimesh.Trimesh":
    """
    Reconstruct mesh using Poisson surface reconstruction.

    Requires Open3D for the actual Poisson reconstruction.
    Falls back to convex hull if Open3D is not available.

    Args:
        points: (N, 3) point cloud
        colors: Optional (N, 3) RGB colors
        depth: Octree depth for Poisson (higher = more detail)

    Returns:
        Trimesh mesh object
    """
    if not NUMPY_AVAILABLE:
        raise MeshingError("NumPy not available")

    if len(points) < 4:
        raise MeshingError("Need at least 4 points for mesh reconstruction")

    try:
        import open3d as o3d

        # Create Open3D point cloud
        pcd = o3d.geometry.PointCloud()
        pcd.points = o3d.utility.Vector3dVector(points)

        if colors is not None:
            pcd.colors = o3d.utility.Vector3dVector(colors / 255.0)

        # Estimate normals
        pcd.estimate_normals(
            search_param=o3d.geometry.KDTreeSearchParamHybrid(radius=0.05, max_nn=30)
        )
        pcd.orient_normals_consistent_tangent_plane(k=15)

        # Poisson reconstruction
        mesh, densities = o3d.geometry.TriangleMesh.create_from_point_cloud_poisson(
            pcd, depth=depth
        )

        # Remove low-density vertices (artifacts)
        densities = np.asarray(densities)
        density_threshold = np.quantile(densities, 0.1)
        vertices_to_remove = densities < density_threshold
        mesh.remove_vertices_by_mask(vertices_to_remove)

        # Convert to trimesh
        vertices = np.asarray(mesh.vertices)
        faces = np.asarray(mesh.triangles)

        result = trimesh.Trimesh(vertices=vertices, faces=faces)
        logger.debug(f"Poisson mesh: {len(result.vertices)} vertices, {len(result.faces)} faces")
        return result

    except ImportError:
        logger.warning("Open3D not available, falling back to convex hull")
        return convex_hull_mesh(points)


def convex_hull_mesh(points: "np.ndarray") -> "trimesh.Trimesh":
    """
    Generate mesh using convex hull.

    Simple fallback when more sophisticated methods aren't available.

    Args:
        points: (N, 3) point cloud

    Returns:
        Trimesh mesh object
    """
    if not TRIMESH_AVAILABLE:
        raise MeshingError("trimesh not available. Run: pip install trimesh")

    if len(points) < 4:
        raise MeshingError("Need at least 4 points for convex hull")

    from scipy.spatial import ConvexHull

    hull = ConvexHull(points)
    mesh = trimesh.Trimesh(vertices=points[hull.vertices], faces=hull.simplices)

    logger.debug(f"Convex hull mesh: {len(mesh.vertices)} vertices")
    return mesh


def alpha_shape_mesh(
    points: "np.ndarray",
    alpha: float = 0.1,
) -> "trimesh.Trimesh":
    """
    Generate mesh using alpha shapes.

    Good for non-convex shapes when Poisson isn't available.

    Args:
        points: (N, 3) point cloud
        alpha: Alpha value (smaller = tighter fit)

    Returns:
        Trimesh mesh object
    """
    if not TRIMESH_AVAILABLE:
        raise MeshingError("trimesh not available")

    # Use trimesh's built-in alpha shape
    cloud = trimesh.PointCloud(points)
    mesh = cloud.convex_hull  # Start with convex hull

    # TODO: Implement proper alpha shape when scipy supports it
    # For now, fall back to convex hull

    return mesh


def simplify_mesh(
    mesh: "trimesh.Trimesh",
    target_faces: int = 5000,
) -> "trimesh.Trimesh":
    """
    Simplify mesh to reduce face count.

    Args:
        mesh: Input mesh
        target_faces: Target number of faces

    Returns:
        Simplified mesh
    """
    if not TRIMESH_AVAILABLE:
        raise MeshingError("trimesh not available")

    if len(mesh.faces) <= target_faces:
        return mesh

    try:
        # Try quadric decimation
        simplified = mesh.simplify_quadric_decimation(target_faces)
        logger.debug(f"Simplified mesh: {len(mesh.faces)} -> {len(simplified.faces)} faces")
        return simplified
    except Exception as e:
        logger.warning(f"Mesh simplification failed: {e}")
        return mesh


def generate_visual_mesh(
    cloud_path: Path,
    output_path: Path,
    method: str = "auto",
    simplify_to: int = 5000,
) -> Path:
    """
    Generate visual mesh from point cloud file.

    Args:
        cloud_path: Path to PLY point cloud
        output_path: Path to output OBJ file
        method: "poisson", "hull", or "auto"
        simplify_to: Target face count for simplification

    Returns:
        Path to generated mesh file
    """
    from .lifting import load_ply

    # Load point cloud
    points, colors = load_ply(cloud_path)

    if len(points) < 4:
        raise MeshingError(f"Insufficient points in {cloud_path}: {len(points)}")

    # Generate mesh
    if method == "auto":
        try:
            mesh = poisson_reconstruct(points, colors)
        except Exception as e:
            logger.warning(f"Poisson failed, using convex hull: {e}")
            mesh = convex_hull_mesh(points)
    elif method == "poisson":
        mesh = poisson_reconstruct(points, colors)
    elif method == "hull":
        mesh = convex_hull_mesh(points)
    else:
        raise MeshingError(f"Unknown meshing method: {method}")

    # Simplify if needed
    if simplify_to > 0 and len(mesh.faces) > simplify_to:
        mesh = simplify_mesh(mesh, simplify_to)

    # Ensure mesh is watertight
    if not mesh.is_watertight:
        logger.warning(f"Mesh is not watertight, attempting repair")
        mesh.fill_holes()

    # Export
    output_path.parent.mkdir(parents=True, exist_ok=True)
    mesh.export(str(output_path))

    logger.info(f"Generated visual mesh: {output_path} ({len(mesh.faces)} faces)")
    return output_path


def generate_all_visual_meshes(
    session: "ScanSession",
    method: str = "auto",
    simplify_to: int = 5000,
    progress_callback: Optional[callable] = None,
) -> Dict[str, Path]:
    """
    Generate visual meshes for all links in a session.

    Args:
        session: ScanSession with point clouds
        method: Meshing method
        simplify_to: Target face count
        progress_callback: Optional progress callback

    Returns:
        Dict mapping link_name -> mesh_path
    """
    clouds_dir = session.clouds_dir
    meshes_dir = session.meshes_dir
    meshes_dir.mkdir(parents=True, exist_ok=True)

    cloud_files = list(clouds_dir.glob("*.ply"))
    if not cloud_files:
        raise MeshingError(f"No point clouds found in {clouds_dir}")

    result = {}
    total = len(cloud_files)

    for i, cloud_path in enumerate(cloud_files):
        link_name = cloud_path.stem
        output_path = meshes_dir / f"{link_name}_visual.obj"

        try:
            generate_visual_mesh(cloud_path, output_path, method, simplify_to)
            result[link_name] = output_path
        except Exception as e:
            logger.error(f"Failed to generate mesh for {link_name}: {e}")

        if progress_callback:
            progress_callback(i + 1, total)

    logger.info(f"Generated {len(result)} visual meshes")
    return result


__all__ = [
    "MeshingError",
    "poisson_reconstruct",
    "convex_hull_mesh",
    "alpha_shape_mesh",
    "simplify_mesh",
    "generate_visual_mesh",
    "generate_all_visual_meshes",
]
