"""
Model loading and caching for URDF scan pipeline.

Provides lazy loading and caching for large ML models:
- SAM 2 (Segment Anything Model 2) for temporal segmentation
- Depth Anything V2 for metric depth estimation
"""

from typing import Optional
import logging

logger = logging.getLogger(__name__)


class ModelCache:
    """
    Singleton cache for expensive ML models.

    Models are loaded lazily on first access and cached for reuse.
    This prevents redundant loading when processing multiple sessions.
    """

    _sam2_model = None
    _sam2_predictor = None
    _depth_model = None
    _device: str = "cpu"

    @classmethod
    def set_device(cls, device: str) -> None:
        """Set the device for model inference (cuda or cpu)."""
        cls._device = device
        # Clear cached models if device changes
        if cls._sam2_model is not None or cls._depth_model is not None:
            logger.info(f"Device changed to {device}, clearing model cache")
            cls.clear()

    @classmethod
    def get_device(cls) -> str:
        """Get the current device setting."""
        return cls._device

    @classmethod
    def get_sam2(cls):
        """
        Get SAM 2 model, loading if necessary.

        Returns:
            SAM 2 predictor ready for video inference
        """
        if cls._sam2_predictor is None:
            from .sam2 import load_sam2_predictor
            logger.info(f"Loading SAM 2 model on {cls._device}...")
            cls._sam2_predictor = load_sam2_predictor(cls._device)
            logger.info("SAM 2 model loaded")
        return cls._sam2_predictor

    @classmethod
    def get_depth_model(cls):
        """
        Get Depth Anything V2 model, loading if necessary.

        Returns:
            Depth Anything V2 model ready for inference
        """
        if cls._depth_model is None:
            from .depth_anything import load_depth_model
            logger.info(f"Loading Depth Anything V2 on {cls._device}...")
            cls._depth_model = load_depth_model(cls._device)
            logger.info("Depth Anything V2 loaded")
        return cls._depth_model

    @classmethod
    def clear(cls) -> None:
        """Clear all cached models to free memory."""
        cls._sam2_model = None
        cls._sam2_predictor = None
        cls._depth_model = None
        logger.info("Model cache cleared")

    @classmethod
    def is_loaded(cls, model_name: str) -> bool:
        """Check if a specific model is loaded."""
        if model_name == "sam2":
            return cls._sam2_predictor is not None
        elif model_name == "depth":
            return cls._depth_model is not None
        return False


def check_cuda_available() -> bool:
    """Check if CUDA is available for GPU acceleration."""
    try:
        import torch
        return torch.cuda.is_available()
    except ImportError:
        return False


def get_recommended_device() -> str:
    """Get the recommended device based on available hardware."""
    if check_cuda_available():
        return "cuda"
    return "cpu"


__all__ = [
    "ModelCache",
    "check_cuda_available",
    "get_recommended_device",
]
