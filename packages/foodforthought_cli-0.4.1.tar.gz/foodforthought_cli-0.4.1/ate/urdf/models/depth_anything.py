"""
Depth Anything V2 wrapper for metric depth estimation.

This module provides:
- load_depth_model: Load the Depth Anything V2 model
- DepthEstimator: Wrapper for depth inference

When Depth Anything V2 is not installed, a mock implementation
is used that generates synthetic depth maps for testing.

Installation:
    pip install depth-anything-v2

References:
    https://github.com/DepthAnything/Depth-Anything-V2
"""

import logging
from typing import Optional, Tuple
from pathlib import Path

logger = logging.getLogger(__name__)

try:
    import numpy as np
    NUMPY_AVAILABLE = True
except ImportError:
    NUMPY_AVAILABLE = False
    np = None

try:
    import torch
    import torch.nn.functional as F
    from depth_anything_v2.dpt import DepthAnythingV2
    DEPTH_ANYTHING_AVAILABLE = True
except ImportError:
    DEPTH_ANYTHING_AVAILABLE = False
    torch = None


class DepthEstimator:
    """
    Wrapper for Depth Anything V2 model.

    Provides metric depth estimation from single RGB images.
    """

    def __init__(self, model, device: str = "cpu"):
        """
        Initialize estimator wrapper.

        Args:
            model: Depth Anything V2 model instance
            device: Compute device
        """
        self.model = model
        self.device = device

    def estimate(self, image: "np.ndarray") -> "np.ndarray":
        """
        Estimate depth from an RGB image.

        Args:
            image: BGR image from OpenCV (H, W, 3)

        Returns:
            Depth map (H, W) in relative units
        """
        import cv2

        # Convert BGR to RGB
        rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

        # Prepare input
        h, w = rgb.shape[:2]

        # Resize to model input size (typically 518x518 for ViT)
        input_size = 518
        rgb_resized = cv2.resize(rgb, (input_size, input_size))

        # Normalize
        rgb_tensor = torch.from_numpy(rgb_resized).float().permute(2, 0, 1)
        rgb_tensor = rgb_tensor / 255.0
        rgb_tensor = rgb_tensor.unsqueeze(0).to(self.device)

        # Inference
        with torch.no_grad():
            depth = self.model(rgb_tensor)

        # Resize back to original
        depth = F.interpolate(
            depth.unsqueeze(1),
            size=(h, w),
            mode="bilinear",
            align_corners=False,
        )

        depth_np = depth.squeeze().cpu().numpy()
        return depth_np

    def estimate_metric(
        self,
        image: "np.ndarray",
        scale_factor: float = 1.0,
    ) -> "np.ndarray":
        """
        Estimate metric depth with scale correction.

        Args:
            image: BGR image from OpenCV
            scale_factor: Scale factor to convert to meters

        Returns:
            Depth map (H, W) in meters
        """
        depth = self.estimate(image)
        return depth * scale_factor


class MockDepthEstimator:
    """
    Mock depth estimator for testing without the real model.

    Generates synthetic depth maps based on image brightness,
    simulating closer objects being brighter (like typical indoor lighting).
    """

    def __init__(self, device: str = "cpu"):
        """Initialize mock estimator."""
        self.device = device

    def estimate(self, image: "np.ndarray") -> "np.ndarray":
        """
        Generate mock depth from image brightness.

        Args:
            image: BGR image

        Returns:
            Mock depth map
        """
        import cv2

        # Convert to grayscale
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY).astype(np.float32)

        # Invert: brighter = closer = smaller depth
        depth = 255.0 - gray

        # Normalize to [0.5, 5.0] meters range (typical indoor scene)
        depth = 0.5 + (depth / 255.0) * 4.5

        # Add some noise for realism
        noise = np.random.normal(0, 0.1, depth.shape).astype(np.float32)
        depth = depth + noise
        depth = np.clip(depth, 0.3, 6.0)

        return depth

    def estimate_metric(
        self,
        image: "np.ndarray",
        scale_factor: float = 1.0,
    ) -> "np.ndarray":
        """Generate mock metric depth."""
        depth = self.estimate(image)
        # Scale factor adjusts the overall scale
        return depth * scale_factor


def load_depth_model(device: str = "cpu") -> DepthEstimator:
    """
    Load Depth Anything V2 model.

    Args:
        device: Compute device ("cuda" or "cpu")

    Returns:
        DepthEstimator instance (or mock if unavailable)
    """
    if DEPTH_ANYTHING_AVAILABLE:
        try:
            logger.info("Loading Depth Anything V2 model...")

            # Model configurations
            model_configs = {
                "vits": {"encoder": "vits", "features": 64, "out_channels": [48, 96, 192, 384]},
                "vitb": {"encoder": "vitb", "features": 128, "out_channels": [96, 192, 384, 768]},
                "vitl": {"encoder": "vitl", "features": 256, "out_channels": [256, 512, 1024, 1024]},
            }

            # Try to find checkpoint
            checkpoint_paths = [
                Path.home() / ".cache" / "depth_anything_v2" / "depth_anything_v2_vitl.pth",
                Path.home() / ".cache" / "depth_anything_v2" / "depth_anything_v2_vitb.pth",
                Path.home() / ".cache" / "depth_anything_v2" / "depth_anything_v2_vits.pth",
                Path("./checkpoints/depth_anything_v2_vitb.pth"),
            ]

            checkpoint = None
            config_name = None
            for path in checkpoint_paths:
                if path.exists():
                    checkpoint = str(path)
                    # Infer config from filename
                    if "vitl" in path.name:
                        config_name = "vitl"
                    elif "vitb" in path.name:
                        config_name = "vitb"
                    else:
                        config_name = "vits"
                    break

            if checkpoint is None:
                logger.warning(
                    "Depth Anything V2 checkpoint not found. Using mock estimator. "
                    "Download from: https://github.com/DepthAnything/Depth-Anything-V2"
                )
                return MockDepthEstimator(device)

            # Build model
            config = model_configs[config_name]
            model = DepthAnythingV2(**config)
            model.load_state_dict(torch.load(checkpoint, map_location=device))
            model.to(device)
            model.eval()

            logger.info(f"Loaded Depth Anything V2 ({config_name}) on {device}")
            return DepthEstimator(model, device)

        except Exception as e:
            logger.warning(f"Failed to load Depth Anything V2: {e}. Using mock estimator.")
            return MockDepthEstimator(device)

    else:
        logger.warning(
            "Depth Anything V2 not installed. Using mock estimator. "
            "Install with: pip install depth-anything-v2"
        )
        return MockDepthEstimator(device)


def check_depth_anything_available() -> bool:
    """Check if Depth Anything V2 is available."""
    return DEPTH_ANYTHING_AVAILABLE


__all__ = [
    "DepthEstimator",
    "MockDepthEstimator",
    "load_depth_model",
    "check_depth_anything_available",
]
