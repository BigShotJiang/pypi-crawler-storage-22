"""
SAM 2 (Segment Anything Model 2) wrapper for temporal segmentation.

This module provides:
- load_sam2_predictor: Load the SAM 2 video predictor
- SAM2VideoPredictor: Wrapper for video segmentation

When SAM 2 is not installed, a mock implementation is used that
generates simple masks based on color clustering for testing.

Installation:
    pip install segment-anything-2

References:
    https://github.com/facebookresearch/segment-anything-2
"""

import logging
from typing import Dict, List, Optional, Tuple
from pathlib import Path

logger = logging.getLogger(__name__)

try:
    import numpy as np
    NUMPY_AVAILABLE = True
except ImportError:
    NUMPY_AVAILABLE = False
    np = None

try:
    import torch
    from sam2.build_sam import build_sam2_video_predictor
    SAM2_AVAILABLE = True
except ImportError:
    SAM2_AVAILABLE = False
    torch = None


class SAM2VideoPredictor:
    """
    Wrapper for SAM 2 video segmentation.

    Provides temporal mask propagation from initial point prompts.
    """

    def __init__(self, predictor, device: str = "cpu"):
        """
        Initialize predictor wrapper.

        Args:
            predictor: SAM 2 video predictor instance
            device: Compute device
        """
        self.predictor = predictor
        self.device = device
        self._state = None

    def initialize(self, video_path: str) -> None:
        """
        Initialize predictor with a video.

        Args:
            video_path: Path to video file
        """
        import cv2
        import tempfile
        import shutil
        from pathlib import Path

        # Extract frames using OpenCV (works on Apple Silicon)
        # SAM 2's init_state can use an image directory instead of video
        self._temp_dir = tempfile.mkdtemp(prefix="sam2_frames_")
        
        cap = cv2.VideoCapture(video_path)
        frame_idx = 0
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            # Save as JPEG with zero-padded frame numbers
            frame_path = Path(self._temp_dir) / f"{frame_idx:06d}.jpg"
            cv2.imwrite(str(frame_path), frame)
            frame_idx += 1
        cap.release()
        
        logger.info(f"Extracted {frame_idx} frames to {self._temp_dir}")
        
        # Use image directory mode instead of video mode
        self._state = self.predictor.init_state(video_path=self._temp_dir)
        logger.info(f"SAM 2 initialized with {frame_idx} frames")

    def add_point_prompt(
        self,
        frame_idx: int,
        obj_id: int,
        point: Tuple[float, float],
        label: int = 1,
    ) -> "np.ndarray":
        """
        Add a point prompt to initialize tracking.

        Args:
            frame_idx: Frame index (usually 0)
            obj_id: Unique object ID for this link
            point: (x, y) coordinates in frame
            label: 1 for foreground, 0 for background

        Returns:
            Initial mask for the object
        """
        points = np.array([[point[0], point[1]]], dtype=np.float32)
        labels = np.array([label], dtype=np.int32)

        _, _, mask_logits = self.predictor.add_new_points_or_box(
            inference_state=self._state,
            frame_idx=frame_idx,
            obj_id=obj_id,
            points=points,
            labels=labels,
        )

        # Convert logits to binary mask
        mask = (mask_logits > 0).cpu().numpy().squeeze()
        return mask

    def propagate(self) -> Dict[int, Dict[int, "np.ndarray"]]:
        """
        Propagate masks across all video frames.

        Returns:
            Dict mapping frame_idx -> {obj_id: mask}
        """
        results = {}

        for frame_idx, obj_ids, mask_logits in self.predictor.propagate_in_video(
            self._state
        ):
            frame_masks = {}
            for i, obj_id in enumerate(obj_ids):
                mask = (mask_logits[i] > 0).cpu().numpy().squeeze()
                frame_masks[obj_id] = mask
            results[frame_idx] = frame_masks

        logger.info(f"SAM 2 propagated masks across {len(results)} frames")
        return results

    def reset(self) -> None:
        """Reset predictor state."""
        if self._state is not None:
            self.predictor.reset_state(self._state)
        self._state = None


class MockSAM2Predictor:
    """
    Mock SAM 2 predictor for testing without the real model.

    Uses simple color-based region growing from seed points.
    This is NOT accurate but allows pipeline testing.
    """

    def __init__(self, device: str = "cpu"):
        """Initialize mock predictor."""
        self.device = device
        self._video_path: Optional[str] = None
        self._prompts: Dict[int, Tuple[float, float]] = {}  # obj_id -> point
        self._frame_count: int = 0
        self._resolution: Tuple[int, int] = (720, 1280)

    def initialize(self, video_path: str) -> None:
        """Initialize with video."""
        import cv2

        self._video_path = video_path
        cap = cv2.VideoCapture(video_path)
        self._frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        self._resolution = (height, width)
        cap.release()

        logger.info(f"Mock SAM 2 initialized: {self._frame_count} frames")

    def add_point_prompt(
        self,
        frame_idx: int,
        obj_id: int,
        point: Tuple[float, float],
        label: int = 1,
    ) -> "np.ndarray":
        """Add point prompt and return initial mask."""
        self._prompts[obj_id] = point

        # Generate simple circular mask around point
        mask = self._generate_circular_mask(point, radius=50)
        return mask

    def _generate_circular_mask(
        self,
        center: Tuple[float, float],
        radius: int = 50,
    ) -> "np.ndarray":
        """Generate a circular mask around a point."""
        h, w = self._resolution
        mask = np.zeros((h, w), dtype=bool)

        cx, cy = int(center[0]), int(center[1])
        y, x = np.ogrid[:h, :w]
        dist = np.sqrt((x - cx) ** 2 + (y - cy) ** 2)
        mask[dist <= radius] = True

        return mask

    def propagate(self) -> Dict[int, Dict[int, "np.ndarray"]]:
        """
        Generate mock masks for all frames.

        Creates slightly varying masks to simulate motion tracking.
        """
        results = {}

        for frame_idx in range(self._frame_count):
            frame_masks = {}

            for obj_id, point in self._prompts.items():
                # Add small random offset to simulate motion
                offset_x = np.random.uniform(-5, 5)
                offset_y = np.random.uniform(-5, 5)
                moved_point = (point[0] + offset_x, point[1] + offset_y)

                # Vary radius slightly
                radius = 50 + np.random.randint(-10, 10)
                mask = self._generate_circular_mask(moved_point, radius)
                frame_masks[obj_id] = mask

            results[frame_idx] = frame_masks

        logger.info(f"Mock SAM 2 generated masks for {len(results)} frames")
        return results

    def reset(self) -> None:
        """Reset state."""
        self._prompts = {}


def load_sam2_predictor(device: str = "cpu") -> SAM2VideoPredictor:
    """
    Load SAM 2 video predictor.

    Args:
        device: Compute device ("cuda" or "cpu")

    Returns:
        SAM2VideoPredictor instance (or mock if unavailable)
    """
    if SAM2_AVAILABLE:
        try:
            # Try to load the real model
            logger.info("Loading SAM 2 model...")

            # SAM 2 model checkpoint paths
            # Users should download from:
            # https://github.com/facebookresearch/segment-anything-2#model-checkpoints
            checkpoint_paths = [
                Path.home() / ".cache" / "sam2" / "sam2_hiera_large.pt",
                Path.home() / ".cache" / "sam2" / "sam2_hiera_base_plus.pt",
                Path.home() / ".cache" / "sam2" / "sam2_hiera_base.pt",
                Path("./checkpoints/sam2_hiera_large.pt"),
                Path("./checkpoints/sam2_hiera_base_plus.pt"),
            ]

            checkpoint = None
            for path in checkpoint_paths:
                if path.exists():
                    checkpoint = str(path)
                    break

            if checkpoint is None:
                logger.warning(
                    "SAM 2 checkpoint not found. Using mock predictor. "
                    "Download from: https://github.com/facebookresearch/segment-anything-2"
                )
                return MockSAM2Predictor(device)

            # Select config file based on checkpoint
            if "base_plus" in checkpoint:
                config_file = "sam2_hiera_b+.yaml"
            elif "base" in checkpoint:
                config_file = "sam2_hiera_b.yaml"
            else:
                config_file = "sam2_hiera_l.yaml"

            predictor = build_sam2_video_predictor(
                config_file=config_file,
                checkpoint=checkpoint,
                device=device,
            )

            return SAM2VideoPredictor(predictor, device)

        except Exception as e:
            logger.warning(f"Failed to load SAM 2: {e}. Using mock predictor.")
            return MockSAM2Predictor(device)

    else:
        logger.warning(
            "SAM 2 not installed. Using mock predictor. "
            "Install with: pip install segment-anything-2"
        )
        return MockSAM2Predictor(device)


def check_sam2_available() -> bool:
    """Check if SAM 2 is available."""
    return SAM2_AVAILABLE


__all__ = [
    "SAM2VideoPredictor",
    "MockSAM2Predictor",
    "load_sam2_predictor",
    "check_sam2_available",
]
