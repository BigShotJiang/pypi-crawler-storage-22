"""
Scale calibration for markerless URDF generation.

In a markerless setting, the global scale factor (sim2real gap) must be
determined from a known physical measurement. This module provides:

- parse_scale_ref: Parse "part:measurement" strings (e.g., "gripper:85mm")
- parse_measurement: Parse measurement values with units
- ScaleCalibrator: Compute scale factor from reference measurements

The Kalib method uses a single known dimension to normalize depth estimates
from monocular depth models like Depth Anything V2.
"""

import re
from typing import Tuple, Optional
from dataclasses import dataclass


class ScaleError(Exception):
    """Error in scale parsing or calibration."""
    pass


# Unit conversion factors to meters
UNIT_CONVERSIONS = {
    # Metric
    "m": 1.0,
    "meter": 1.0,
    "meters": 1.0,
    "cm": 0.01,
    "centimeter": 0.01,
    "centimeters": 0.01,
    "mm": 0.001,
    "millimeter": 0.001,
    "millimeters": 0.001,
    # Imperial
    "in": 0.0254,
    "inch": 0.0254,
    "inches": 0.0254,
    '"': 0.0254,
    "ft": 0.3048,
    "foot": 0.3048,
    "feet": 0.3048,
    "'": 0.3048,
}


def parse_measurement(measurement: str) -> float:
    """
    Parse a measurement string with units to meters.

    Args:
        measurement: Value with unit (e.g., "85mm", "3.5in", "0.15m")

    Returns:
        Value in meters

    Raises:
        ScaleError: If format is invalid or unit is unknown

    Examples:
        >>> parse_measurement("85mm")
        0.085
        >>> parse_measurement("3.5in")
        0.0889
        >>> parse_measurement("150cm")
        1.5
    """
    if not measurement:
        raise ScaleError("Empty measurement string")

    # Normalize: strip whitespace, lowercase
    measurement = measurement.strip().lower()

    # Pattern: number (with optional decimal) followed by unit
    pattern = r"^([\d.]+)\s*([a-z\"']+)$"
    match = re.match(pattern, measurement)

    if not match:
        raise ScaleError(
            f"Invalid measurement format: '{measurement}'. "
            f"Expected format like '85mm', '3.5in', '0.15m'"
        )

    value_str, unit = match.groups()

    try:
        value = float(value_str)
    except ValueError:
        raise ScaleError(f"Invalid numeric value: '{value_str}'")

    if value <= 0:
        raise ScaleError(f"Measurement must be positive: {value}")

    if unit not in UNIT_CONVERSIONS:
        valid_units = sorted(set(UNIT_CONVERSIONS.keys()) - {'"', "'"})
        raise ScaleError(
            f"Unknown unit: '{unit}'. Valid units: {', '.join(valid_units)}"
        )

    return value * UNIT_CONVERSIONS[unit]


def parse_scale_ref(ref: str) -> Tuple[str, float]:
    """
    Parse a scale reference string.

    Format: "part_name:measurement"

    Args:
        ref: Scale reference (e.g., "gripper:85mm", "base_width:150mm")

    Returns:
        Tuple of (part_name, value_in_meters)

    Raises:
        ScaleError: If format is invalid

    Examples:
        >>> parse_scale_ref("gripper:85mm")
        ('gripper', 0.085)
        >>> parse_scale_ref("base_width:6in")
        ('base_width', 0.1524)
    """
    if not ref:
        raise ScaleError("Empty scale reference")

    if ":" not in ref:
        raise ScaleError(
            f"Invalid scale reference format: '{ref}'. "
            f"Expected 'part:measurement' (e.g., 'gripper:85mm')"
        )

    parts = ref.split(":", 1)
    if len(parts) != 2:
        raise ScaleError(f"Invalid scale reference: '{ref}'")

    part_name = parts[0].strip()
    measurement = parts[1].strip()

    if not part_name:
        raise ScaleError("Part name cannot be empty in scale reference")

    value_meters = parse_measurement(measurement)

    return part_name, value_meters


@dataclass
class ScaleCalibration:
    """Result of scale calibration."""
    part_name: str
    reference_meters: float
    measured_pixels: float
    scale_factor: float  # meters per pixel (or depth unit)

    def apply(self, depth_value: float) -> float:
        """Apply scale factor to convert raw depth to meters."""
        return depth_value * self.scale_factor


class ScaleCalibrator:
    """
    Calibrate global scale from a known physical measurement.

    Uses the Kalib method: correlate a known physical dimension with
    its measured size in the depth map or point cloud.

    Usage:
        calibrator = ScaleCalibrator("gripper:85mm")
        # Measure gripper width in depth units
        measured = compute_dimension_from_cloud(gripper_cloud)
        calibration = calibrator.calibrate(measured)
        # Apply to all depth values
        scaled_depth = calibration.apply(raw_depth)
    """

    def __init__(self, scale_ref: str):
        """
        Initialize calibrator with a scale reference.

        Args:
            scale_ref: Scale reference string (e.g., "gripper:85mm")
        """
        self.part_name, self.reference_meters = parse_scale_ref(scale_ref)

    def calibrate(self, measured_value: float) -> ScaleCalibration:
        """
        Compute scale factor from measured value.

        Args:
            measured_value: Size of reference part in raw depth units

        Returns:
            ScaleCalibration with computed scale factor
        """
        if measured_value <= 0:
            raise ScaleError(
                f"Measured value must be positive: {measured_value}. "
                f"Check that the reference part '{self.part_name}' is visible."
            )

        scale_factor = self.reference_meters / measured_value

        return ScaleCalibration(
            part_name=self.part_name,
            reference_meters=self.reference_meters,
            measured_pixels=measured_value,
            scale_factor=scale_factor,
        )


def estimate_intrinsics_from_resolution(
    width: int,
    height: int,
    fov_degrees: float = 60.0,
) -> Tuple[float, float, float, float]:
    """
    Estimate camera intrinsics from resolution and assumed FOV.

    This is a fallback when actual camera calibration is not available.
    Most webcams have FOV between 55-75 degrees.

    Args:
        width: Image width in pixels
        height: Image height in pixels
        fov_degrees: Assumed horizontal field of view

    Returns:
        Tuple of (fx, fy, cx, cy) camera intrinsics
    """
    import math

    # Compute focal length from FOV
    fov_rad = math.radians(fov_degrees)
    fx = (width / 2) / math.tan(fov_rad / 2)

    # Assume square pixels
    fy = fx

    # Principal point at image center
    cx = width / 2
    cy = height / 2

    return fx, fy, cx, cy


__all__ = [
    "ScaleError",
    "parse_measurement",
    "parse_scale_ref",
    "ScaleCalibration",
    "ScaleCalibrator",
    "estimate_intrinsics_from_resolution",
]
