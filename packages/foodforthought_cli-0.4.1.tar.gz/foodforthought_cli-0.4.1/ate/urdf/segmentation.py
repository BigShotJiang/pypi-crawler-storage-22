"""
Temporal segmentation for URDF generation using SAM 2.

This module handles Phase 2a of the pipeline:
1. Load SAM 2 model (with caching)
2. Initialize masks from user click points
3. Propagate masks across all video frames

Output: Per-frame binary masks for each annotated link.
"""

import logging
from typing import Dict, List, Optional, Tuple
from pathlib import Path

logger = logging.getLogger(__name__)

try:
    import numpy as np
    import cv2
    DEPS_AVAILABLE = True
except ImportError:
    DEPS_AVAILABLE = False
    np = None
    cv2 = None


class SegmentationError(Exception):
    """Error during segmentation."""
    pass


class LinkSegmenter:
    """
    Temporal segmentation of robot links using SAM 2.

    Given a video and initial click points, propagates segmentation
    masks for each link across all frames.
    """

    def __init__(self, device: str = "cpu"):
        """
        Initialize segmenter.

        Args:
            device: Compute device ("cuda" or "cpu")
        """
        if not DEPS_AVAILABLE:
            raise SegmentationError(
                "Required dependencies not installed. "
                "Run: pip install numpy opencv-python"
            )

        self.device = device
        self._predictor = None

    def _get_predictor(self):
        """Get or load the SAM 2 predictor."""
        if self._predictor is None:
            from .models import ModelCache
            ModelCache.set_device(self.device)
            self._predictor = ModelCache.get_sam2()
        return self._predictor

    def segment_video(
        self,
        video_path: str,
        links: List[Tuple[str, List[float], bool]],
        progress_callback: Optional[callable] = None,
    ) -> Dict[str, Dict[int, "np.ndarray"]]:
        """
        Segment a video given initial link annotations.

        Args:
            video_path: Path to video file
            links: List of (name, [x, y], is_fixed) tuples
            progress_callback: Optional callback(current, total)

        Returns:
            Dict mapping link_name -> {frame_idx: mask}
        """
        predictor = self._get_predictor()

        # Initialize predictor with video
        predictor.initialize(video_path)

        # Add point prompts for each link
        logger.info(f"Initializing {len(links)} link masks...")
        for obj_id, (name, point, is_fixed) in enumerate(links):
            predictor.add_point_prompt(
                frame_idx=0,
                obj_id=obj_id,
                point=(point[0], point[1]),
                label=1,  # Foreground
            )
            logger.debug(f"Added prompt for '{name}' at {point}")

        # Propagate masks
        logger.info("Propagating masks across video frames...")
        all_masks = predictor.propagate()

        # Reorganize by link name
        link_names = [name for name, _, _ in links]
        result = {name: {} for name in link_names}

        for frame_idx, frame_masks in all_masks.items():
            for obj_id, mask in frame_masks.items():
                if obj_id < len(link_names):
                    link_name = link_names[obj_id]
                    result[link_name][frame_idx] = mask

            if progress_callback:
                progress_callback(frame_idx + 1, len(all_masks))

        # Validate results
        for name in link_names:
            if not result[name]:
                raise SegmentationError(
                    f"No masks generated for link '{name}'. "
                    "Check that the click point is on the robot."
                )

        logger.info(f"Segmentation complete: {len(all_masks)} frames")
        return result

    def extract_masked_regions(
        self,
        video_path: str,
        masks: Dict[str, Dict[int, "np.ndarray"]],
        output_dir: Path,
    ) -> Dict[str, List[Path]]:
        """
        Extract masked RGB regions from video frames.

        Args:
            video_path: Path to video file
            masks: Dict from segment_video()
            output_dir: Directory to save extracted regions

        Returns:
            Dict mapping link_name -> list of image paths
        """
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        cap = cv2.VideoCapture(video_path)
        if not cap.isOpened():
            raise SegmentationError(f"Could not open video: {video_path}")

        result = {name: [] for name in masks.keys()}
        frame_idx = 0

        try:
            while True:
                ret, frame = cap.read()
                if not ret:
                    break

                for link_name, link_masks in masks.items():
                    if frame_idx in link_masks:
                        mask = link_masks[frame_idx]

                        # Apply mask to frame
                        masked = frame.copy()
                        masked[~mask] = 0

                        # Crop to bounding box
                        coords = np.where(mask)
                        if len(coords[0]) > 0:
                            y_min, y_max = coords[0].min(), coords[0].max()
                            x_min, x_max = coords[1].min(), coords[1].max()
                            cropped = masked[y_min:y_max, x_min:x_max]

                            # Save
                            out_path = output_dir / f"{link_name}_frame_{frame_idx:04d}.png"
                            cv2.imwrite(str(out_path), cropped)
                            result[link_name].append(out_path)

                frame_idx += 1

        finally:
            cap.release()

        logger.info(f"Extracted masked regions to {output_dir}")
        return result


def visualize_masks(
    frame: "np.ndarray",
    masks: Dict[str, "np.ndarray"],
    alpha: float = 0.5,
) -> "np.ndarray":
    """
    Visualize segmentation masks overlaid on a frame.

    Args:
        frame: BGR image
        masks: Dict mapping link_name -> mask
        alpha: Overlay transparency

    Returns:
        Visualization image
    """
    if not DEPS_AVAILABLE:
        raise SegmentationError("OpenCV not available")

    display = frame.copy()

    # Color palette for different links
    colors = [
        (255, 0, 0),    # Blue
        (0, 255, 0),    # Green
        (0, 0, 255),    # Red
        (255, 255, 0),  # Cyan
        (255, 0, 255),  # Magenta
        (0, 255, 255),  # Yellow
        (128, 0, 128),  # Purple
        (255, 165, 0),  # Orange
    ]

    for i, (name, mask) in enumerate(masks.items()):
        color = colors[i % len(colors)]

        # Create colored overlay
        overlay = display.copy()
        overlay[mask] = color

        # Blend
        display = cv2.addWeighted(overlay, alpha, display, 1 - alpha, 0)

        # Draw contour
        contours, _ = cv2.findContours(
            mask.astype(np.uint8),
            cv2.RETR_EXTERNAL,
            cv2.CHAIN_APPROX_SIMPLE,
        )
        cv2.drawContours(display, contours, -1, color, 2)

        # Label
        if contours:
            M = cv2.moments(contours[0])
            if M["m00"] > 0:
                cx = int(M["m10"] / M["m00"])
                cy = int(M["m01"] / M["m00"])
                cv2.putText(
                    display, name, (cx - 30, cy),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2
                )
                cv2.putText(
                    display, name, (cx - 30, cy),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 1
                )

    return display


def run_segmentation(
    session: "ScanSession",
    progress_callback: Optional[callable] = None,
) -> Dict[str, Dict[int, "np.ndarray"]]:
    """
    Run segmentation phase on a scan session.

    Args:
        session: ScanSession with captured video and link annotations
        progress_callback: Optional progress callback

    Returns:
        Dict mapping link_name -> {frame_idx: mask}
    """
    from .scan_session import ScanSession

    # Check prerequisites
    session.check_prerequisites("segment")

    # Prepare link data
    links = [
        (link.name, link.point, link.is_fixed)
        for link in session.links
    ]

    # Run segmentation
    segmenter = LinkSegmenter(device=session.metadata.device)
    masks = segmenter.segment_video(
        str(session.video_path),
        links,
        progress_callback,
    )

    logger.info(f"Segmentation complete for {len(masks)} links")
    return masks


__all__ = [
    "SegmentationError",
    "LinkSegmenter",
    "visualize_masks",
    "run_segmentation",
]
