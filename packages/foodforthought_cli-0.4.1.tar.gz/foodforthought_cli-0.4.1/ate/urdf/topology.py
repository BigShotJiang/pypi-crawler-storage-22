"""
Kinematic topology discovery for URDF generation.

This module handles discovering the parent-child relationships
between robot links based on their motion patterns:
- Links that move together are likely connected
- The link with least motion is likely the base
- Parent-child relationships form a tree structure
"""

import logging
from typing import Dict, List, Optional, Tuple, Set
from dataclasses import dataclass

logger = logging.getLogger(__name__)

try:
    import numpy as np
    NUMPY_AVAILABLE = True
except ImportError:
    NUMPY_AVAILABLE = False
    np = None


class TopologyError(Exception):
    """Error during topology discovery."""
    pass


@dataclass
class LinkNode:
    """Node in the kinematic tree."""
    name: str
    parent: Optional[str]
    children: List[str]
    is_fixed: bool = False  # Base link


@dataclass
class KinematicTree:
    """Kinematic tree structure."""
    nodes: Dict[str, LinkNode]
    root: str

    def get_parent(self, link_name: str) -> Optional[str]:
        """Get parent of a link."""
        if link_name in self.nodes:
            return self.nodes[link_name].parent
        return None

    def get_children(self, link_name: str) -> List[str]:
        """Get children of a link."""
        if link_name in self.nodes:
            return self.nodes[link_name].children
        return []

    def get_chain_to_root(self, link_name: str) -> List[str]:
        """Get chain of links from given link to root."""
        chain = []
        current = link_name
        while current is not None:
            chain.append(current)
            current = self.get_parent(current)
        return chain

    def get_ordered_links(self) -> List[str]:
        """Get links in depth-first order from root."""
        ordered = []
        visited = set()

        def dfs(node_name: str):
            if node_name in visited:
                return
            visited.add(node_name)
            ordered.append(node_name)
            for child in self.get_children(node_name):
                dfs(child)

        dfs(self.root)
        return ordered

    def validate(self) -> bool:
        """Validate tree structure."""
        # Check that all nodes are reachable from root
        ordered = self.get_ordered_links()
        return len(ordered) == len(self.nodes)


def compute_motion_correlation(
    trajectory1: "LinkTrajectory",
    trajectory2: "LinkTrajectory",
) -> float:
    """
    Compute motion correlation between two link trajectories.

    High correlation indicates the links move together (likely connected).

    Args:
        trajectory1: First link trajectory
        trajectory2: Second link trajectory

    Returns:
        Correlation coefficient [0, 1]
    """
    if not NUMPY_AVAILABLE:
        raise TopologyError("NumPy not available")

    from .motion_analysis import LinkTrajectory

    # Find common frames
    frames1 = set(trajectory1.frame_indices)
    frames2 = set(trajectory2.frame_indices)
    common = sorted(frames1 & frames2)

    if len(common) < 3:
        return 0.0

    # Get velocities at common frames
    vel1 = trajectory1.get_velocity()
    vel2 = trajectory2.get_velocity()

    # Align to common frames
    idx1 = [trajectory1.frame_indices.index(f) for f in common[:-1]]
    idx2 = [trajectory2.frame_indices.index(f) for f in common[:-1]]

    v1 = vel1[idx1] if len(vel1) > 0 else np.zeros((len(common)-1, 3))
    v2 = vel2[idx2] if len(vel2) > 0 else np.zeros((len(common)-1, 3))

    # Compute correlation of velocity magnitudes
    mag1 = np.linalg.norm(v1, axis=1)
    mag2 = np.linalg.norm(v2, axis=1)

    if np.std(mag1) < 1e-6 or np.std(mag2) < 1e-6:
        return 0.5  # No motion variance

    corr = np.corrcoef(mag1, mag2)[0, 1]
    return float(np.clip(corr, 0, 1))


def identify_base_link(
    trajectories: Dict[str, "LinkTrajectory"],
    fixed_hints: Optional[Set[str]] = None,
) -> str:
    """
    Identify the base (fixed) link of the robot.

    The base link typically has:
    - Least total motion
    - Or is explicitly marked as fixed by the user

    Args:
        trajectories: Dict of link trajectories
        fixed_hints: Optional set of link names marked as fixed by user

    Returns:
        Name of the base link
    """
    if not NUMPY_AVAILABLE:
        raise TopologyError("NumPy not available")

    # If user marked a link as fixed, use that
    if fixed_hints:
        for name in fixed_hints:
            if name in trajectories:
                logger.info(f"Using user-marked base link: {name}")
                return name

    # Otherwise, find link with least motion
    motion_scores = {}
    for name, traj in trajectories.items():
        motion_scores[name] = traj.get_total_displacement()

    base = min(motion_scores, key=motion_scores.get)
    logger.info(f"Identified base link: {base} (displacement: {motion_scores[base]:.4f}m)")

    return base


def build_kinematic_tree(
    trajectories: Dict[str, "LinkTrajectory"],
    fixed_hints: Optional[Set[str]] = None,
    adjacency_hints: Optional[Dict[str, str]] = None,
) -> KinematicTree:
    """
    Build kinematic tree from link trajectories.

    Uses motion correlation to determine parent-child relationships:
    - Base link has no parent
    - Each other link's parent is the most correlated link that has less motion

    Args:
        trajectories: Dict of link trajectories
        fixed_hints: Links marked as fixed/base by user
        adjacency_hints: Optional dict of link -> parent hints

    Returns:
        KinematicTree structure
    """
    if not NUMPY_AVAILABLE:
        raise TopologyError("NumPy not available")

    link_names = list(trajectories.keys())
    n_links = len(link_names)

    if n_links == 0:
        raise TopologyError("No links to build tree from")

    # Identify base
    base_name = identify_base_link(trajectories, fixed_hints)

    # Compute pairwise correlations
    correlations = np.zeros((n_links, n_links))
    for i, name1 in enumerate(link_names):
        for j, name2 in enumerate(link_names):
            if i != j:
                correlations[i, j] = compute_motion_correlation(
                    trajectories[name1],
                    trajectories[name2],
                )

    # Compute motion magnitudes
    motion_magnitudes = {
        name: traj.get_total_displacement()
        for name, traj in trajectories.items()
    }

    # Build tree using Prim's algorithm variant
    # Start from base, add links in order of decreasing correlation
    nodes = {}
    added = {base_name}
    nodes[base_name] = LinkNode(
        name=base_name,
        parent=None,
        children=[],
        is_fixed=True,
    )

    while len(added) < n_links:
        best_child = None
        best_parent = None
        best_score = -1

        for parent_name in added:
            parent_idx = link_names.index(parent_name)

            for child_idx, child_name in enumerate(link_names):
                if child_name in added:
                    continue

                # Use adjacency hints if available
                if adjacency_hints and child_name in adjacency_hints:
                    if adjacency_hints[child_name] == parent_name:
                        best_child = child_name
                        best_parent = parent_name
                        best_score = 1.0
                        break

                # Score = correlation * preference for closer motion magnitude
                corr = correlations[parent_idx, child_idx]
                parent_motion = motion_magnitudes[parent_name]
                child_motion = motion_magnitudes[child_name]

                # Prefer parent with less motion than child
                if parent_motion < child_motion:
                    score = corr * 1.1
                else:
                    score = corr * 0.9

                if score > best_score:
                    best_score = score
                    best_child = child_name
                    best_parent = parent_name

            if best_score >= 1.0:  # Hint matched
                break

        if best_child is None:
            # Fallback: add remaining links to base
            for name in link_names:
                if name not in added:
                    best_child = name
                    best_parent = base_name
                    break

        # Add child node
        nodes[best_child] = LinkNode(
            name=best_child,
            parent=best_parent,
            children=[],
            is_fixed=False,
        )
        nodes[best_parent].children.append(best_child)
        added.add(best_child)

        logger.debug(f"Added {best_child} as child of {best_parent} (score: {best_score:.3f})")

    tree = KinematicTree(nodes=nodes, root=base_name)

    if not tree.validate():
        raise TopologyError("Built tree is invalid (disconnected nodes)")

    logger.info(f"Built kinematic tree: {tree.get_ordered_links()}")
    return tree


def infer_joint_names(tree: KinematicTree) -> Dict[Tuple[str, str], str]:
    """
    Generate joint names from parent-child pairs.

    Args:
        tree: KinematicTree structure

    Returns:
        Dict mapping (parent, child) -> joint_name
    """
    joint_names = {}

    for link_name, node in tree.nodes.items():
        if node.parent is not None:
            parent = node.parent
            child = link_name
            joint_name = f"{parent}_to_{child}_joint"
            joint_names[(parent, child)] = joint_name

    return joint_names


__all__ = [
    "TopologyError",
    "LinkNode",
    "KinematicTree",
    "compute_motion_correlation",
    "identify_base_link",
    "build_kinematic_tree",
    "infer_joint_names",
]
