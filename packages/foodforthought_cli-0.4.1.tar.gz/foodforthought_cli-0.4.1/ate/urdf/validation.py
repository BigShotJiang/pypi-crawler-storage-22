"""
URDF validation for generated robot descriptions.

This module provides validation checks for URDF files:
- XML syntax validation
- Structural validation (links, joints, tree structure)
- Physics validation (mass, inertia positivity)
- Mesh file existence checks
"""

import logging
from typing import Dict, List, Optional, Tuple
from pathlib import Path
import xml.etree.ElementTree as ET
from dataclasses import dataclass

logger = logging.getLogger(__name__)


class ValidationError(Exception):
    """Error during URDF validation."""
    pass


@dataclass
class ValidationResult:
    """Result of URDF validation."""
    valid: bool
    errors: List[str]
    warnings: List[str]
    info: Dict

    def __bool__(self) -> bool:
        return self.valid

    def summary(self) -> str:
        lines = []
        if self.valid:
            lines.append("URDF is valid")
        else:
            lines.append("URDF has errors")

        if self.errors:
            lines.append(f"\nErrors ({len(self.errors)}):")
            for err in self.errors:
                lines.append(f"  - {err}")

        if self.warnings:
            lines.append(f"\nWarnings ({len(self.warnings)}):")
            for warn in self.warnings:
                lines.append(f"  - {warn}")

        lines.append(f"\nInfo:")
        for key, value in self.info.items():
            lines.append(f"  {key}: {value}")

        return "\n".join(lines)


def validate_xml_syntax(urdf_content: str) -> Tuple[bool, Optional[str]]:
    """
    Validate XML syntax.

    Args:
        urdf_content: URDF XML string

    Returns:
        Tuple of (valid, error_message)
    """
    try:
        ET.fromstring(urdf_content)
        return True, None
    except ET.ParseError as e:
        return False, f"XML parse error: {e}"


def validate_structure(root: ET.Element) -> Tuple[List[str], List[str]]:
    """
    Validate URDF structure (links, joints, tree).

    Args:
        root: Root XML element

    Returns:
        Tuple of (errors, warnings)
    """
    errors = []
    warnings = []

    # Check root element
    if root.tag != "robot":
        errors.append(f"Root element should be 'robot', got '{root.tag}'")
        return errors, warnings

    if "name" not in root.attrib:
        warnings.append("Robot element has no 'name' attribute")

    # Collect links and joints
    links = {}
    joints = []

    for link in root.findall("link"):
        name = link.get("name")
        if not name:
            errors.append("Link element missing 'name' attribute")
            continue
        if name in links:
            errors.append(f"Duplicate link name: {name}")
        links[name] = link

    for joint in root.findall("joint"):
        name = joint.get("name")
        jtype = joint.get("type")
        parent = joint.find("parent")
        child = joint.find("child")

        if not name:
            errors.append("Joint element missing 'name' attribute")
            continue
        if not jtype:
            errors.append(f"Joint '{name}' missing 'type' attribute")

        if parent is None:
            errors.append(f"Joint '{name}' missing 'parent' element")
        elif parent.get("link") not in links:
            errors.append(f"Joint '{name}' references unknown parent link: {parent.get('link')}")

        if child is None:
            errors.append(f"Joint '{name}' missing 'child' element")
        elif child.get("link") not in links:
            errors.append(f"Joint '{name}' references unknown child link: {child.get('link')}")

        joints.append({
            "name": name,
            "type": jtype,
            "parent": parent.get("link") if parent is not None else None,
            "child": child.get("link") if child is not None else None,
        })

    # Check for valid joint types
    VALID_JOINT_TYPES = ["revolute", "prismatic", "continuous", "fixed", "floating", "planar"]
    for joint in joints:
        if joint["type"] and joint["type"] not in VALID_JOINT_TYPES:
            errors.append(f"Joint '{joint['name']}' has invalid type: {joint['type']}")

    # Check for tree structure (no cycles, single root)
    children = set()
    for joint in joints:
        if joint["child"]:
            if joint["child"] in children:
                errors.append(f"Link '{joint['child']}' has multiple parent joints")
            children.add(joint["child"])

    roots = set(links.keys()) - children
    if len(roots) == 0:
        errors.append("No root link found (cycle detected)")
    elif len(roots) > 1:
        warnings.append(f"Multiple root links found: {roots}")

    # Check for required elements
    for link_name, link in links.items():
        inertial = link.find("inertial")
        if inertial is None:
            warnings.append(f"Link '{link_name}' has no inertial element")
        else:
            mass = inertial.find("mass")
            if mass is None:
                errors.append(f"Link '{link_name}' inertial missing mass")

    return errors, warnings


def validate_physics(root: ET.Element) -> Tuple[List[str], List[str]]:
    """
    Validate physics properties (mass, inertia).

    Args:
        root: Root XML element

    Returns:
        Tuple of (errors, warnings)
    """
    errors = []
    warnings = []

    for link in root.findall("link"):
        name = link.get("name", "unnamed")
        inertial = link.find("inertial")

        if inertial is None:
            continue

        # Check mass
        mass_elem = inertial.find("mass")
        if mass_elem is not None:
            try:
                mass = float(mass_elem.get("value", "0"))
                if mass <= 0:
                    warnings.append(f"Link '{name}' has non-positive mass: {mass}")
                elif mass < 0.001:
                    warnings.append(f"Link '{name}' has very small mass: {mass}kg")
            except ValueError:
                errors.append(f"Link '{name}' has invalid mass value")

        # Check inertia
        inertia = inertial.find("inertia")
        if inertia is not None:
            try:
                ixx = float(inertia.get("ixx", "0"))
                iyy = float(inertia.get("iyy", "0"))
                izz = float(inertia.get("izz", "0"))

                # Diagonal elements must be positive
                if ixx <= 0 or iyy <= 0 or izz <= 0:
                    warnings.append(
                        f"Link '{name}' has non-positive inertia diagonal: "
                        f"ixx={ixx}, iyy={iyy}, izz={izz}"
                    )

                # Triangle inequality for principal moments
                if ixx + iyy < izz or ixx + izz < iyy or iyy + izz < ixx:
                    warnings.append(f"Link '{name}' inertia violates triangle inequality")

            except ValueError:
                errors.append(f"Link '{name}' has invalid inertia values")

    return errors, warnings


def validate_meshes(
    root: ET.Element,
    base_path: Path,
) -> Tuple[List[str], List[str]]:
    """
    Validate mesh file existence.

    Args:
        root: Root XML element
        base_path: Base path for resolving mesh paths

    Returns:
        Tuple of (errors, warnings)
    """
    errors = []
    warnings = []

    for link in root.findall("link"):
        name = link.get("name", "unnamed")

        for geom_type in ["visual", "collision"]:
            geom = link.find(geom_type)
            if geom is None:
                continue

            mesh = geom.find("geometry/mesh")
            if mesh is not None:
                filename = mesh.get("filename")
                if filename:
                    mesh_path = base_path / filename
                    if not mesh_path.exists():
                        warnings.append(
                            f"Link '{name}' {geom_type} mesh not found: {filename}"
                        )

    return errors, warnings


def validate_urdf(
    urdf_path: Path,
    check_meshes: bool = True,
) -> ValidationResult:
    """
    Validate a URDF file.

    Args:
        urdf_path: Path to URDF file
        check_meshes: Whether to check mesh file existence

    Returns:
        ValidationResult with errors/warnings
    """
    errors = []
    warnings = []
    info = {"path": str(urdf_path)}

    # Read file
    try:
        with open(urdf_path, 'r') as f:
            content = f.read()
    except Exception as e:
        return ValidationResult(
            valid=False,
            errors=[f"Failed to read file: {e}"],
            warnings=[],
            info=info,
        )

    # Validate XML
    xml_valid, xml_error = validate_xml_syntax(content)
    if not xml_valid:
        return ValidationResult(
            valid=False,
            errors=[xml_error],
            warnings=[],
            info=info,
        )

    # Parse XML
    root = ET.fromstring(content)
    info["robot_name"] = root.get("name", "unnamed")

    # Validate structure
    struct_errors, struct_warnings = validate_structure(root)
    errors.extend(struct_errors)
    warnings.extend(struct_warnings)

    # Validate physics
    physics_errors, physics_warnings = validate_physics(root)
    errors.extend(physics_errors)
    warnings.extend(physics_warnings)

    # Validate meshes
    if check_meshes:
        base_path = urdf_path.parent
        mesh_errors, mesh_warnings = validate_meshes(root, base_path)
        errors.extend(mesh_errors)
        warnings.extend(mesh_warnings)

    # Gather info
    info["links"] = len(root.findall("link"))
    info["joints"] = len(root.findall("joint"))

    return ValidationResult(
        valid=(len(errors) == 0),
        errors=errors,
        warnings=warnings,
        info=info,
    )


def run_validation(session: "ScanSession") -> ValidationResult:
    """
    Run validation on session's generated URDF.

    Args:
        session: ScanSession with generated URDF

    Returns:
        ValidationResult
    """
    if not session.has_urdf():
        return ValidationResult(
            valid=False,
            errors=["No URDF file generated yet"],
            warnings=[],
            info={},
        )

    return validate_urdf(session.urdf_path, check_meshes=True)


__all__ = [
    "ValidationError",
    "ValidationResult",
    "validate_xml_syntax",
    "validate_structure",
    "validate_physics",
    "validate_meshes",
    "validate_urdf",
    "run_validation",
]
