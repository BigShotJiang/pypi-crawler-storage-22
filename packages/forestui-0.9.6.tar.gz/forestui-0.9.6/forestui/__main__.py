"""Entry point for forestui."""

from forestui.app import main

if __name__ == "__main__":
    main()
