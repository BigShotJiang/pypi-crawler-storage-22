try:
    from ._version import __version__, __version_tuple__, version, version_tuple
except ImportError:
    __version__ = version = None
    __version_tuple__ = version_tuple = ()

from .GeologicalModel3D import GeologicalModel

__all__ = ["GeologicalModel"]
