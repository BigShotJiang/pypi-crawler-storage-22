from dataclasses import dataclass

from .pyarchitecture import *


@dataclass
class NodeInfo:
    name: str
    color: tuple = None


def export_model_without_leaves(model):
    """Converts a geological architecture to python dictionnary.
    This is suboptimal because underlying functors are wrapped several times.
    """

    def build(node):
        if node is None:
            return None
        interface = model.interface(node)
        if interface is None:  # leaf
            return None
        return {
            "interface": interface,
            "below": build(model.below(node)),
            "above": build(model.above(node)),
        }

    return build(model.root)


def _from_GeoModeller(
    model,
    add_interface_node,
    add_formation_node,
    add_topography_node=False,
    topography_color=None,
    keep_info=False,  # FIXME: C++ does not store node information
):
    """Converts a GeoModeller model to architecture.
    This is suboptimal because underlying functors are wrapped several times.
    """
    fields = model.fields
    values = model.values
    relations = model.relations
    formations = model.pile_formations
    formation_color = model.formation_colors
    pile_reference = model.pile.reference
    assert len(fields) == len(values)
    assert len(fields) == len(relations)
    assert len(fields) + 1 == len(formations)
    assert set(relations).issubset({"onlap", "erode"})

    def build_onlap_range(first, last):
        assert 0 <= first <= last
        # We add 1 to formations to leave 0 for the default formation (above topography)
        node = add_formation_node(last + 1)
        for k in range(first, last)[::-1]:
            below = add_formation_node(k + 1)
            name = formations[k]
            info = (
                NodeInfo(f"{pile_reference}-{name}", formation_color[name])
                if keep_info
                else None
            )
            node = add_interface_node(fields[k], values[k], below, node, info)
        return node

    erosions = [k for k, relation in enumerate(relations) if relation == "erode"]
    erosions.append(len(relations))
    node = build_onlap_range(0, erosions[0])
    for e, next_e in zip(erosions[:-1], erosions[1:]):
        name = formations[e]
        info = (
            NodeInfo(f"erosion-{pile_reference}-{name}", formation_color[name])
            if keep_info
            else None
        )
        node = add_interface_node(
            fields[e], values[e], node, build_onlap_range(e + 1, next_e), info
        )
    if add_topography_node:
        node = add_interface_node(
            model.topography,
            0,
            node,
            None,
            NodeInfo("topography", topography_color) if keep_info else None,
        )
    return node


def from_GeoModeller(model, **kwargs):
    """Converts a GeoModeller model to architecture.
    This is suboptimal because underlying functors are wrapped several times.
    """
    architecture = Model()

    def add_interface(field, value, below, above, info=None):
        return architecture.add_interface_node(Field(field), value, below, above, info)

    def add_formation(formation):
        return architecture.add_formation_node(formation)

    architecture.set_root_node(
        _from_GeoModeller(model, add_interface, add_formation, **kwargs)
    )
    return architecture


@dataclass
class ArchitectureNode:
    interface: tuple
    below: "typing.Callable" = None
    above: "typing.Callable" = None
    info: NodeInfo = None


def simple_tree_from_GeoModeller(model, **kwargs):
    """Converts a GeoModeller model to architecture.
    This is suboptimal because underlying functors are wrapped several times.
    """

    def add_interface(field, value, below, above, info=None):
        return ArchitectureNode((field, value), below, above, info)

    def add_formation(formation):
        return None

    return _from_GeoModeller(model, add_interface, add_formation, **kwargs)
