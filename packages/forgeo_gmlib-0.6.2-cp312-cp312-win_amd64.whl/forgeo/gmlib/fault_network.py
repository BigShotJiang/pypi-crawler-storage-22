#
# This file is part of gmlib. It is free software.
# You can redistribute it and/or modify it under the terms of the GNU Affero General Public License version 3.
#

from collections import namedtuple
from itertools import product

import numpy as np

Fault_node = namedtuple("Fault_node", ["fault", "negative", "positive"])


def _build_family_tree(limits):
    nbf = len(limits)
    assert all(all(fk < nbf for fk in limit) for limit in limits)
    fault_ancestors = [set() for _ in range(nbf)]
    fault_progeny = [set() for _ in range(nbf)]
    for fk, data in enumerate(zip(limits, fault_ancestors)):
        stops_on, ancestors = data
        for limit in stops_on:
            ancestors.add(limit)
            fault_progeny[limit].add(fk)
    progenyless = [k for k, progeny in enumerate(fault_progeny) if not progeny]
    ancestorless = [k for k, ancestors in enumerate(fault_ancestors) if not ancestors]

    # FIXME: we do not check there are no cycles
    # OPTIMIZE: this may not be usefull...
    # we complete the set of all ancestors to eventually keep only direct ancestors
    # the problem is that we don't have the guarantee the set of all ancestors
    # and complete progeny are correct from the begining
    # here are the big recursive loops :-(
    def add_progeny(progeny, ancestors):
        for ancestor in ancestors:
            family = fault_progeny[ancestor]
            family |= progeny
            add_progeny(family, fault_ancestors[ancestor])

    def add_ancestors(ancestors, progeny):
        for descendant in progeny:
            family = fault_ancestors[descendant]
            family |= ancestors
            add_ancestors(family, fault_progeny[descendant])

    for alone in progenyless:
        assert not fault_progeny[alone]
        add_progeny({alone}, fault_ancestors[alone])
    for orphan in ancestorless:
        assert not fault_ancestors[orphan]
        add_ancestors({orphan}, fault_progeny[orphan])

    # we now keep only direct links
    def test_set_intersection(S1, S2):
        return any(x in S1 for x in S2)

    for descendant in range(nbf):
        ancestors = fault_ancestors[descendant]
        all_ancestors = list(ancestors)
        for ancestor in all_ancestors:
            if test_set_intersection(ancestors, fault_progeny[ancestor]):
                fault_progeny[ancestor].remove(descendant)
                ancestors.remove(ancestor)
    return fault_progeny, fault_ancestors


def _build_fault_node(faults, fk, progeny):
    fault = faults[fk]
    assert fk not in progeny
    positive = []
    negative = []
    for fl in progeny:
        # FIXME: this is a legacy test which is bugprone
        gravity_center = faults[fl].data_centroid()
        if fault(gravity_center) > 0:
            positive.append(fl)
        else:
            negative.append(fl)
    return Fault_node(fault, tuple(sorted(negative)), tuple(sorted(positive)))


def _build_fault_nodes(faults, limits):
    assert all(all(fk < len(faults) for fk in limit) for limit in limits)
    fault_progeny, fault_ancestors = _build_family_tree(limits)
    ancestorless = [k for k, ancestors in enumerate(fault_ancestors) if not ancestors]
    nodes = [
        _build_fault_node(faults, k, progeny) for k, progeny in enumerate(fault_progeny)
    ]
    roots = tuple(sorted(ancestorless))
    return nodes, roots


def build(faults, limits):
    assert len(faults) == len(limits)
    if not faults:
        return None
    nodes, roots = _build_fault_nodes(faults, limits)
    assert roots
    # TODO: all of the following could be grouped into a iterator class
    # yielding evaluation values
    nbf = len(faults)
    evaluations = []
    evaluation = np.zeros(nbf, dtype=np.int8)
    check = np.zeros(nbf, dtype=bool)
    level = nbf
    iterators = []
    exploration = [roots]

    # NB: we use numpy.put method because given an array a
    #     a[tuple()] = 1 will set all the array to one
    #     whereas a.pu(tuple(), 1) will do nothing wich
    #     is the expected behavior here
    def explore_progeny(progeny, sides, level):
        for fk, side in zip(progeny, sides):
            nk = nodes[fk]
            if side < 0:
                deeper = nk.negative
                nullify = nk.positive
            else:
                assert side == 1
                deeper = nk.positive
                nullify = nk.negative
            assert not (nullify and np.any(check[nullify]))
            if nullify:
                check.put(nullify, True)
                evaluation.put(nullify, 0)
                level -= len(nullify)
                iterators.append((nullify, iter([])))
            if deeper:
                exploration.append(deeper)
        return level

    while iterators or exploration:
        if level == 0:
            assert not exploration
            assert np.all(check)
            faults, it = iterators.pop()
            while True:
                try:
                    evaluations.append(np.copy(evaluation))
                    evaluation.put(faults, next(it))
                except StopIteration:
                    break
            check.put(faults, False)
            level += len(faults)
            while iterators:
                faults, it = iterators[-1]
                try:
                    assert faults
                    assert np.all(check[faults])
                    sides = next(it)
                    evaluation.put(faults, sides)
                    level = explore_progeny(faults, sides, level)
                    break
                except StopIteration:
                    check.put(faults, False)
                    level += len(faults)
                    iterators.pop()
        while exploration:
            explore = exploration.pop()
            it = iter(product((-1, 1), repeat=len(explore)))
            sides = next(it)
            assert explore
            assert not np.any(check[explore])
            check.put(explore, True)
            evaluation.put(explore, sides)
            iterators.append((explore, it))
            level -= len(explore)
            level = explore_progeny(explore, sides, level)
        assert level in (0, nbf)
        assert np.all(check) or np.all(np.logical_not(check))
    return nodes, roots, evaluations
