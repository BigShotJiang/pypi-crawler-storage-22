#
# This file is part of gmlib. It is free software.
# You can redistribute it and/or modify it under the terms of the GNU Affero General Public License version 3.
#


import os
from collections import namedtuple

import numpy as np
from lxml.builder import ElementMaker

from forgeo.gmlib import myxmltools as mx
from forgeo.gmlib import topography_reader
from forgeo.gmlib.geomodeller_data import (
    CovarianceModel,
    FaultData,
    GradientData,
    Pile,
    PotentialData,
    SeriesData,
)

Formation = namedtuple("Formation", ["name", "color", "is_dummy"])
GmlCoord = namedtuple("GmlCoord", ["x", "y", "z"])
DrillHole = namedtuple("DrillHole", ["name", "total_depth", "collar"])

# FIXME: this sould not be static
nsmap = {"geo": "http://www.geomodeller.com/geo", "gml": "http://www.opengis.net/gml"}
geo = ElementMaker(namespace=nsmap["geo"])
gml = ElementMaker(namespace=nsmap["gml"])


def extract_coord(node, tag):
    pts = []
    coords = node.find(tag)
    if coords is not None:
        for coord in coords:
            P = GmlCoord(
                *tuple(
                    np.double(coord.find(axis).text)
                    for axis in (gml.X().tag, gml.Y().tag, gml.Z().tag)
                )
            )
            pts.append(P)
    return pts


def extract_crs(xml_root):
    assert xml_root.tag == geo.Project3DEdit().tag
    try:
        gmcrs = xml_root.attrib["CoordSystem"]
    except KeyError:
        gmcrs = None
    try:
        qgiscrs = xml_root.attrib["QGisCRS"]
    except KeyError:
        qgiscrs = None
    return gmcrs, qgiscrs


def read_box(xml_root):
    extent = xml_root.find(geo.Extent3DOfProject().tag)
    extentbox = extent.find(geo.ExtentBox3D().tag)
    extent3D = extentbox.find(geo.Extent3D().tag)
    xy = extent3D.find(geo.ExtentXY().tag)
    limits = {}
    for s, val in xy.items():
        limits[s] = float(val)
    z = extent3D.find(geo.ExtentZ().tag)
    for s, val in z.items():
        limits[s] = float(val)
    return limits


def read_color(root):
    color = None
    graphic = root.find(geo.Graphic().tag)
    if graphic is not None:
        shading = graphic.find(geo.ColorShading().tag)
        color = tuple(
            int(shading.attrib[name]) / 255.0  # convert to float RGB
            for name in ("Red", "Green", "Blue")
        )
    return color


def read_formations(xml_root):
    formations = xml_root.find(geo.Formations().tag)
    result = []

    def extract_formation(formation, is_dummy=False):
        name = formation.attrib["Name"]
        color = read_color(formation)
        return Formation(name, color, is_dummy)

    if formations is not None:
        for formation in formations.findall(geo.Formation().tag):
            result.append(extract_formation(formation))
        for formation in formations.findall(geo.DummyFormation().tag):
            result.append(extract_formation(formation, True))
    return result


def find_topography_sections(xml_root):
    topography_sections = []
    sections = xml_root.find(geo.Sections().tag)
    if sections is not None:
        for section in sections.findall(geo.Section().tag):
            if "IsTopography" in section:
                if section.attrib["IsTopography"] == "true":
                    topography_sections.append(section)
    return topography_sections


def extract_drillholes(xml_root):
    drillholes = []
    dhs = xml_root.find(geo.DrillHoles().tag)
    if dhs is not None:
        for dh in dhs.findall(geo.DrillholeWithFields().tag):
            name = dh.attrib["Name"]
            total_depth = float(dh.attrib["TotalDepth"])
            collar_pos = extract_coord(dh, geo.Collar().tag)
            assert len(collar_pos) == 1
            drillholes.append(DrillHole(name, total_depth, collar_pos[0]))
    return drillholes


def read_topography_info(xml_root):
    topography_sections = find_topography_sections(xml_root)
    if not topography_sections:
        return None
    assert len(topography_sections) == 1  # only one topography section!!!
    section = topography_sections[0]
    shape = section.find(geo.Shape3DOfSection().tag)
    return section.attrib["Name"], shape.attrib["FileName"]


def read_data(xml_root):
    data = xml_root.findall(geo.Data().tag)
    return [d.attrib["Name"] for d in data]


def read_potential_data(xml_root, box, scalardt, maximum_number_of_interfaces=None):
    field = xml_root.find(geo.PotentialField().tag)
    if field is None:
        return None
    glocs = []
    gvals = []
    interfaces = []
    covariance_model = CovarianceModel(field.find(geo.covariance().tag), box)
    constraints = field.find(geo.Constraints().tag)
    if constraints is not None:
        if any(constraint.attrib["value"] != "0" for constraint in constraints):
            mess = "inequality constraints are not handled for now"
            raise NotImplementedError(mess)
    gradients = field.find(geo.Gradients().tag)
    if gradients is not None:
        for gradient in gradients.iterfind(geo.Gradient().tag):
            V = tuple(scalardt.type(gradient.attrib[s]) for s in ("Gx", "Gy", "Gz"))
            gvals.append(V)
            P = tuple(scalardt.type(gradient.attrib[s]) for s in ("XGr", "YGr", "ZGr"))
            glocs.append(P)
    pts = extract_coord(field, geo.Points().tag)
    interface_points = field.find(geo.InterfacePoints().tag)
    for interface in interface_points:

        def attr_as_int(s):
            return int(interface.attrib[s])

        interfaces.append((attr_as_int("pnt"), attr_as_int("npnt")))
    if maximum_number_of_interfaces is not None:
        assert len(interfaces) >= maximum_number_of_interfaces, (
            "Not enough interfaces read."
        )
        del interfaces[maximum_number_of_interfaces:]

    def array_of_scalars(v):
        return np.array(v, dtype=scalardt)

    potdata = PotentialData()
    potdata.covariance_model = covariance_model
    potdata.gradients = GradientData(array_of_scalars(glocs), array_of_scalars(gvals))
    pts = array_of_scalars(pts)
    potdata.interfaces = [pts[start : start + nb] for start, nb in interfaces]
    return potdata


def extract_raw_faults_data(root, scalardt):
    faults_data = {}
    faults = root.find(geo.Faults().tag)
    if faults is not None:
        for fault in faults.findall(geo.Fault().tag):
            data = FaultData(fault.attrib["Name"])
            geology = fault.find(geo.FaultGeology().tag).attrib
            if int(geology["FAULT_TYPE"]) == 1:  # finite fault
                data.infinite = False
                data.center_type = None
                center_type = geology["CENTER_TYPE"]
                if center_type == "0":
                    data.center_type = "mean_center"
                elif center_type == "1":
                    data.center_type = "databox_center"
                else:
                    assert center_type == "2"
                    data.center_type = (
                        scalardt.type(geology["CENTERX"]),
                        scalardt.type(geology["CENTERY"]),
                        scalardt.type(geology["CENTERZ"]),
                    )
                data.lateral_extent = scalardt.type(geology["LATERAL_EXTENT"])
                data.vertical_extent = scalardt.type(geology["VERTICAL_EXTENT"])
                data.influence_radius = scalardt.type(geology["RADIUS_OF_INFLUENCE"])
            for other in fault.iterfind(geo.StopsOnFault().tag):
                data.stops_on.append(other.attrib["Name"])
            data.color = read_color(fault)
            faults_data[data.name] = data
    return faults_data


def read_modeled_faults_data(root, box, scalardt):
    faults_data = extract_raw_faults_data(root, scalardt)
    if faults_data:
        model = root.find(geo.GeologicalModel().tag)
        if model is not None:
            modelfaults = model.find(geo.ModelFaults().tag)
            if modelfaults is not None:
                faultpotentials = modelfaults.findall(geo.PotentialFault().tag)
                for fault in faultpotentials:
                    data = read_data(fault)
                    assert len(data) == 1
                    name = data[0]
                    potdata = read_potential_data(fault, box, scalardt)
                    faults_data[name].potential_data = potdata
    deleted_faults = [
        name for name, data in faults_data.items() if data.potential_data is None
    ]
    for name in deleted_faults:
        del faults_data[name]
    return faults_data


def read_pile(root, box, scalardt):
    pile = None
    model = root.find(geo.GeologicalModel().tag)
    if model is not None:
        project_column = model.find(geo.ProjectStratigraphicColumn().tag)
        #   modelseries = model.find(geo.ModelStratigraphicColumn().tag)
        #   for serie in modelseries:
        #       modelseries.find('geo:Data',ns)
        #       name = serie.attrib['Name']
        #       print (name)

        reference = {"true": "base", "false": "top"}[project_column.attrib["IsBase"]]
        pile = Pile(reference)
        all_series = []
        for serie in project_column:
            # read data
            name = serie.attrib["name"]
            serie_data = SeriesData(name)
            serie_data.relation = {"1": "onlap", "2": "erode"}[serie.attrib["relation"]]
            serie_data.formations = read_data(serie)
            all_influencing_faults = serie.findall(geo.InfluencedByFault().tag)
            influenced_by_fault = [f.attrib["Name"] for f in all_influencing_faults]
            if influenced_by_fault:
                serie_data.influenced_by_fault = influenced_by_fault
            serie_data.potential_data = read_potential_data(serie, box, scalardt)
            if serie_data.potential_data is not None:
                if len(serie_data.potential_data.interfaces) > len(
                    serie_data.formations
                ):
                    if len(serie_data.formations) == 1:
                        pass
                    else:
                        pass
                    serie_data.potential_data = read_potential_data(
                        serie, box, scalardt, len(serie_data.formations)
                    )
            assert serie_data.potential_data is None or len(
                serie_data.potential_data.interfaces
            ) == len(serie_data.formations), f"Inconsitent {name} series."
            all_series.append(serie_data)
        model_column = model.find(geo.ModelStratigraphicColumn().tag)
        if model_column is not None:
            selection = [data.attrib["Name"] for data in model_column]
            series_selection = [
                serie for serie in all_series if serie.name in selection
            ]
            for ref, loc in (("base", 0), ("top", -1)):
                if pile.reference == ref:
                    dummy_serie = all_series[loc]
                    if (
                        dummy_serie.name not in selection
                        and dummy_serie.potential_data is None
                    ):
                        series_selection.insert(loc, dummy_serie)
            all_series = series_selection
        pile.all_series = all_series
    return pile


def extract_tree(filepath):
    if os.path.islink(filepath):
        filepath = os.readlink(filepath)
    filepath = os.path.realpath(filepath)
    tree = mx.parse(filepath)
    root = tree.getroot()
    for ns, uri in nsmap.items():
        assert ns in root.nsmap
        assert root.nsmap[ns] == uri
    return tree


def extract_project_data(filepath, scalardt=np.dtype("d"), skip_topography=False):
    root = extract_tree(filepath).getroot()
    crs = extract_crs(root)
    box = read_box(root)
    faults_data = read_modeled_faults_data(root, box, scalardt)
    pile = read_pile(root, box, scalardt)
    topography_info = None if skip_topography else read_topography_info(root)
    if topography_info is None:
        topography = topography_reader.ImplicitHorizontalPlane(box["Zmax"])
    else:
        _name, filename = topography_info
        project_directory = os.path.split(filepath)[0]
        topography = topography_reader.sec_extract(
            os.path.join(project_directory, filename)
        )
    formations = read_formations(root)
    return {
        "box": box,
        "crs": crs,
        "pile": pile,
        "faults_data": faults_data,
        "topography": topography,
        "formations": formations,
    }


def extract_project_drillholes(filepath):
    root = extract_tree(filepath).getroot()
    return extract_drillholes(root)


def make_center(aSerie, xmin, xmax, ymin, ymax, zmin, zmax):
    cx = (xmin + xmax) / 2
    cy = (ymin + ymax) / 2
    cz = (zmin + zmax) / 2
    Themax = xmax - xmin
    pts = aSerie.potential_data.interfaces.points
    # interfaces
    for p in pts:
        x = 0.5 + (p[0] - cx) / Themax
        y = 0.5 + (p[1] - cy) / Themax
        z = 0.5 + (p[2] - cz) / Themax
        p[0] = x
        p[1] = y
        p[2] = z

    gpts = aSerie.potential_data.gradients.locations
    # gradients
    for p in gpts:
        x = 0.5 + (p[0] - cx) / Themax
        y = 0.5 + (p[1] - cy) / Themax
        z = 0.5 + (p[2] - cz) / Themax
        p[0] = x
        p[1] = y
        p[2] = z

    cov = aSerie.potential_data.covariance_model
    cov.range = cov.range / Themax


if __name__ == "__main__":
    import sys

    from matplotlib import pyplot as plt

    if len(sys.argv) > 1:
        projectfile = sys.argv[1]
        if os.path.exists(projectfile):
            assert not os.path.islink(projectfile)
            data = extract_project_data(projectfile)
            box, pile, faults_data, topography, fcolors = data
            nx, ny = 200, 200
            xmin, xmax = box["Xmin"], box["Xmax"]
            ymin, ymax = box["Ymin"], box["Ymax"]
            xy = np.meshgrid(
                np.linspace(xmin, xmax, nx), np.linspace(ymin, ymax, ny), indexing="ij"
            )
            x, y = (a.ravel() for a in xy)
            z = np.array([topography.evaluate_z((xi, yi)) for xi, yi in zip(x, y)])
            z.shape = nx, ny
            plt.gca().set_aspect("equal")
            box = (xmin, xmax, ymin, ymax)
            plt.imshow(np.transpose(z)[::-1], extent=box)
