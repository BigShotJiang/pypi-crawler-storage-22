#
# This file is part of gmlib. It is free software.
# You can redistribute it and/or modify it under the terms of the GNU Affero General Public License version 3.
#

"""
Created on Mon Jul 18 12:12:46 2016

@author: lopez
"""

import os

from lxml import etree


def parse(filename):
    assert os.path.exists(filename)
    # cf. https://lxml.de/FAQ.html#why-doesn-t-the-pretty-print-option-reformat-my-xml-output
    parser = etree.XMLParser(remove_blank_text=True)
    return etree.parse(filename, parser)


def create_child_if_needed(parent, tag):
    """The parent namespace will be used."""
    qname = etree.QName(etree.QName(parent).namespace, tag)
    child = parent.find(qname)
    if child is None:
        child = etree.SubElement(parent, qname)
    return child
