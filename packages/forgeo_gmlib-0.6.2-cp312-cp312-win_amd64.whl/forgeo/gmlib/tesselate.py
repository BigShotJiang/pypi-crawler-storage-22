import contextlib
from collections import defaultdict
from pathlib import Path

import numpy as np
from pycgal.Polygon_mesh_processing import (
    border_halfedges,
    connected_components,
    extract_zmap_corners_and_borders,
    isotropic_remeshing,
    remove_connected_components,
    split,
    split_long_edges,
    triangulate_faces,
)
from pycgal.Surface_mesh import Edges, Surface_mesh
from skimage.measure import marching_cubes

from .GeologicalModel3D import GeologicalModel


def _remove_unvalid_side(S, limit, valid_side):
    connected_components(S, "f:component")
    components = S.face_property("f:component")
    values = set()
    faces = []
    for f in S.faces():
        compf = components[f]
        if compf not in values:
            values.add(compf)
            face_center = np.array(S.centroid(f), copy=False)[None, :]
            if valid_side * limit(face_center) <= 0:
                faces.append(f)
    remove_connected_components(S, faces)


def _split_border_edges(S, ds2):
    """
    Check that border edges are compliant for isotropic remeshing.
    """
    border_edges = Edges(S, border_halfedges(S))
    split_long_edges(S, (4 / 3) * ds2, border_edges)


def _tesselate_horizontal_plane(box, z, target_squared_edge=None):
    if box.zmin > z or box.zmax < z:
        return Surface_mesh()
    vertices = np.array(
        [
            (box.xmin, box.ymin, box.zmax),
            (box.xmax, box.ymin, box.zmax),
            (box.xmax, box.ymax, box.zmax),
            (box.xmin, box.ymax, box.zmax),
        ]
    )
    square = np.array([[0, 1, 2, 3]])
    mesh = Surface_mesh(vertices, square)
    corners, _borders = extract_zmap_corners_and_borders(mesh)
    assert len(corners) == 4
    triangulate_faces(mesh)
    if target_squared_edge:
        isotropic_remeshing(mesh, target_squared_edge, constrained_vertices=corners)
    return mesh


class FaultTesselator:
    def __init__(self, box, shape, model):
        self.shape = nx, ny, nz = shape
        self.ds2 = min(
            (box.xmax - box.xmin) / nx,
            (box.ymax - box.ymin) / ny,
            (box.zmax - box.zmin) / nz,
        )
        steps = (
            np.linspace(box.xmin, box.xmax, nx),
            np.linspace(box.ymin, box.ymax, ny),
            np.linspace(box.zmin, box.zmax, nz),
        )
        coordinates = np.meshgrid(*steps, indexing="ij")
        grid_points = np.stack(coordinates, axis=-1)
        grid_points.shape = (-1, 3)
        self.model = model
        self.box = box
        self.grid_points = grid_points
        self.fault_surfaces = None
        self.tesselate()

    def rescale_into_box(self, pts):
        box = self.box
        nx, ny, nz = self.shape
        return pts * np.array(
            [
                (box.xmax - box.xmin) / (nx - 1),
                (box.ymax - box.ymin) / (ny - 1),
                (box.zmax - box.zmin) / (nz - 1),
            ]
        ) + np.array([box.xmin, box.ymin, box.zmin])

    def tesselate_functor(self, f, target_level=0):
        """Will tesellate the target_level isolevel surface of the scalar functor f
        using the discretization parameters of the self instance (grid_points, ds2...).
        :param target_level: defaults to 0
        """
        field_value = f(self.grid_points)
        if np.all(field_value < target_level) or np.all(field_value > target_level):
            return Surface_mesh()
        field_value.shape = self.shape
        isocontour = marching_cubes(field_value, level=target_level)
        vertices, faces, *_ = isocontour
        vertices = self.rescale_into_box(vertices)
        S = Surface_mesh(vertices, faces)
        _split_border_edges(S, self.ds2)
        isotropic_remeshing(S, self.ds2, do_project=True, protect_constraints=True)
        return S

    def sort_faults(self):
        """
        Will sort faults from the most subordinated to the major ones.
        There is only a partial order relation between faults.
        """
        # find the faults that a given fault limits (reverse of stops on)
        fault_limits = defaultdict(set)
        model = self.model
        for name, fault_data in model.faults_data.items():
            fault_limits[name].update(set())
            for limit in fault_data.stops_on:
                fault_limits[limit].add(name)
        sorted_faults = []
        faults = set(model.faults.keys())
        while len(faults) > 0:
            subordinated_faults = {
                fault for fault, limits in fault_limits.items() if len(limits) == 0
            }
            for limits in fault_limits.values():
                limits -= subordinated_faults
            for fault in subordinated_faults:
                fault_limits.pop(fault)
            sorted_faults.extend(subordinated_faults)
            faults -= subordinated_faults
        return sorted_faults

    def tesselate_topography(self):
        model = self.model
        # Retrieve the exact DTM
        # topography = Surface_mesh(*model.topography.underlying_dtm())
        # or use a topography approximation
        try:
            z_plane = model.topography.z
        except AttributeError:
            z_plane = None
        if type(z_plane) is float:
            topography = _tesselate_horizontal_plane(self.box, z_plane, self.ds2)
        else:
            topography = self.tesselate_functor(model.topography)
        self.topography = topography

    def tesselate(self):
        self.tesselate_topography()
        topography = self.topography
        model = self.model

        fault_surfaces = {}

        for name, field in model.faults.items():
            fault_surfaces[name] = self.tesselate_functor(field)

        for name in self.sort_faults():
            fault_data = model.faults_data[name]
            S = fault_surfaces[name]
            if S.is_empty():
                continue
            points = fault_data.potential_data.interfaces[0]
            # Clip with topography
            split(S, topography)
            # FIXME: as defined here the depth functor maybe inaccurate
            #        we should project the point onto the tesselated DTM surface
            _remove_unvalid_side(S, model.topography, -1)
            # Clip with limiting faults
            for limit in fault_data.stops_on:
                FL = model.faults[limit]
                SL = fault_surfaces[limit]
                if SL.is_empty():
                    continue
                split(S, SL)
                _remove_unvalid_side(S, FL, np.mean(FL(points)))
            # Clip finite faults at the end
            # that makes that the *infinite extension of finite faults*
            # can limit other faults
            if not fault_data.infinite:
                assert model.is_finite_fault(name)
                ellipsoid = model.fault_ellipsoids[name]
                E = self.tesselate_functor(ellipsoid)
                if not E.is_empty():
                    split(S, E)
                    _remove_unvalid_side(S, ellipsoid, -1)

        self.fault_surfaces = fault_surfaces


def tesselate_faults(box, shape, model, with_topography=False):
    tesselator = FaultTesselator(box, shape, model)
    if with_topography:
        return tesselator.fault_surfaces, tesselator.topography
    return tesselator.fault_surfaces


if __name__ == "__main__":
    import sys

    filepath = Path(sys.argv[1])
    if filepath.exists():
        model = GeologicalModel(str(filepath.absolute()))
    else:
        msg = f"{filepath} not found!"
        raise OSError(msg)

    shape = (20,) * 3
    fault_surfaces, topography = tesselate_faults(
        model.getbox(), shape, model, with_topography=True
    )

    vtkw = None
    with contextlib.suppress(ModuleNotFoundError):
        import vtkwriters as vtkw

    if vtkw is not None:

        def to_vtu(S, name):
            if S.number_of_faces() == 0:
                return
            v, t = S.as_arrays()
            vtkw.write_vtu(vtkw.vtu_doc(v, t[0]), f"{name}.vtu")

        to_vtu(topography, f"{filepath.stem}_topography")
        for name, S in fault_surfaces.items():
            to_vtu(S, f"{filepath.stem}_fault_surface_{name}")
