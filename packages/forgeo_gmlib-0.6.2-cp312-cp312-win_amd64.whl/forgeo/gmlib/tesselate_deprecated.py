#
# This file is part of gmlib. It is free software.
# You can redistribute it and/or modify it under the terms of the GNU Affero General Public License version 3.
#

import copy

import numpy as np

import forgeo.gmlib.pypotential3D as potential
from forgeo.gmlib.common import OrientedEvaluation

try:
    from skimage.measure import marching_cubes
except ImportError:
    raise

try:
    from pycgal.Polygon_mesh_processing import corefine
    from pycgal.Surface_mesh import Surface_mesh
except ImportError:
    raise


# FIXME: to be moved elsewhere
def zmap_to_tsurf(zmap, origin, steps):
    nx, ny = zmap.shape
    assert nx > 1
    assert ny > 1
    xy = np.vstack(
        [
            a.ravel()
            for a in np.meshgrid(
                origin[0] + steps[0] * np.arange(0, nx),
                origin[1] + steps[1] * np.arange(0, ny),
            )
        ]
    )
    vertices = np.vstack([xy, zmap.ravel(order="F")])
    vertices = np.transpose(vertices)
    tmp = np.hstack(
        [
            np.reshape(a, (-1, 1))
            for a in [
                np.arange(0, nx - 1),
                np.arange(1, nx),
                nx + np.arange(0, nx - 1),  # triangle 1
                np.arange(1, nx),
                nx + np.arange(1, nx),
                nx + np.arange(0, nx - 1),  # triangle 2
            ]
        ]
    )
    triangles = np.vstack([tmp + k * nx for k in range(ny - 1)])
    triangles.shape = (-1, 3)
    return Surface_mesh(vertices, triangles)


def _remove_faces_on_side(surface, side, centroid_value):
    if side < 0:
        removed_faces = [f for f, cv in zip(surface.faces(), centroid_value) if cv > 0]
    else:
        removed_faces = [f for f, cv in zip(surface.faces(), centroid_value) if cv < 0]
    for f in removed_faces:
        surface.remove_face(f)


class TopographyClipper:
    def __init__(self, field, tesselation):
        self.field = field
        self.tesselation = tesselation

    def clip(self, surface):
        corefine(self.tesselation, surface)
        self.field(surface.centroids())
        _remove_faces_on_side(surface, 1, self.field(surface.centroids()))
        return surface


class Tesselator:
    def __init__(self, box, shape):
        self.reset(box, shape)

    def reset(self, box, shape):
        assert all(n > 0 for n in shape)
        nx, ny, nz = shape
        steps = (
            np.linspace(box.xmin, box.xmax, nx),
            np.linspace(box.ymin, box.ymax, ny),
            np.linspace(box.zmin, box.zmax, nz),
        )
        coordinates = np.meshgrid(*steps, indexing="ij")
        points = np.stack(coordinates, axis=-1)
        points.shape = (-1, 3)
        self.box = box
        self.shape = shape
        self.points = points

    def rescale(self, pts):
        box = self.box
        nx, ny, nz = self.shape
        return pts * np.array(
            [
                (box.xmax - box.xmin) / (nx - 1),
                (box.ymax - box.ymin) / (ny - 1),
                (box.zmax - box.zmin) / (nz - 1),
            ]
        ) + np.array([box.xmin, box.ymin, box.zmin])

    def tesselate(f, v):
        return self(f, v)

    def __call__(self, f, v):
        field_value = f(self.points)
        field_value.shape = self.shape
        isocontour = marching_cubes(field_value, level=v)
        verts, faces, _normals, _values = isocontour
        verts = self.rescale(verts)
        return Surface_mesh(verts, faces)

    def tesselate_topography(self, model):
        assert model.topography is not None
        topography = model.topography
        zmap = topography.z
        if hasattr(zmap, "shape"):
            return zmap_to_tsurf(zmap, topography.origin, topography.steps)
        return self(topography, 0)

    def tesselate_faults(self, model, topography=None):
        fault_tesselations = {
            name: self(field, 0) for name, field in model.faults.items()
        }
        for name, surface in fault_tesselations.items():
            if topography:
                surface = topography.clip(surface)
            data = model.faults_data[name]
            assert len(data.potential_data.interfaces) == 1
            fault_points = data.potential_data.interfaces[0]
            for limit_name in data.stops_on:
                try:
                    limit_surface = fault_tesselations[limit_name]
                    corefine(surface, limit_surface)
                    limit_fault = model.faults[limit_name]
                    _remove_faces_on_side(
                        surface,
                        np.mean(limit_fault(fault_points)),
                        limit_fault(surface.centroids()),
                    )
                except KeyError:
                    pass
        return fault_tesselations

    def tesselate_interfaces(self, model, topography=None):
        fault_tesselations = self.tesselate_faults(model, topography)
        interface_tesselations = {}
        for serie in model.series_info:
            sinfo = model.series_info[serie]
            serie_faults_names = list(sinfo.active_faults)
            serie_faults = [model.faults[name] for name in serie_faults_names]
            faults_limits = [
                [
                    serie_faults_names.index(limit)
                    for limit in model.faults_data[name].stops_on
                ]
                for name in serie_faults_names
            ]
            fault_network = gmlib.fault_network.build(serie_faults, faults_limits)
            # for interface in sinfo.interfaces:
            #    name, _ = interface
            #    interface_tesselations[name] = []
            if fault_network is not None:
                nodes, _roots, evaluations = fault_network
                node_tesselation = [
                    fault_tesselations[fault] for fault in serie_faults_names
                ]
                # fault drift indexes
                fdi = [sinfo.active_faults[fault] for fault in serie_faults_names]
                interface_patches = {name: [] for name, _ in sinfo.interfaces}
                for evaluation in evaluations:
                    drifts = copy.copy(sinfo.drifts)
                    for fk, side in enumerate(evaluation):
                        if side > 0:
                            orientation = OrientedEvaluation.always_positive
                        elif side < 0:
                            orientation = OrientedEvaluation.always_negative
                        else:
                            assert side == 0
                            orientation = OrientedEvaluation.always_outside
                        drifts[fdi[fk]] = potential.make_drift(
                            nodes[fk].fault, orientation
                        )
                    S = potential.alternate_drifts(sinfo.field, drifts)
                    for interface in sinfo.interfaces:
                        interface_name, interface_value = interface
                        patch_tesselation = self(S, interface_value)
                        if topography:
                            topography.clip(patch_tesselation)
                        for fk, side in enumerate(evaluation):
                            if side != 0:
                                corefine(patch_tesselation, node_tesselation[fk])
                                nk = nodes[fk]
                                _remove_faces_on_side(
                                    patch_tesselation,
                                    side,
                                    nk.fault(patch_tesselation.centroids()),
                                )
                        interface_patches[interface_name].append(patch_tesselation)
                for interface_name, patches in interface_patches.items():
                    assert patches
                    tesselation = Surface_mesh(patches[0])
                    for patch in patches[1:]:
                        tesselation.join(patch)
                    interface_tesselations[interface_name] = tesselation
            else:  # serie is not affected by faults
                for interface in sinfo.interfaces:
                    interface_name, interface_value = interface
                    tesselation = self(sinfo.field, interface_value)
                    if topography:
                        topography.clip(tesselation)
                    interface_tesselations[interface_name] = tesselation
        return fault_tesselations, interface_tesselations


def tesselate_topography(box, shape, model):
    return Tesselator(box, shape).tesselate_topography(model)


def tesselate_faults(box, shape, model, clip_topography=True):
    tesselator = Tesselator(box, shape)
    topography = (
        TopographyClipper(model.topography, tesselator.tesselate_topography(model))
        if clip_topography
        else None
    )
    return tesselator.tesselate_faults(model, topography)


def tesselate_interfaces(box, shape, model, clip_topography=True):
    tesselator = Tesselator(box, shape)
    topography = (
        TopographyClipper(model.topography, tesselator.tesselate_topography(model))
        if clip_topography
        else None
    )
    faults, interfaces = tesselator.tesselate_interfaces(model, topography)
    if topography:
        assert "topography" not in interfaces
        interfaces["topography"] = topography.tesselation
    return faults, interfaces
