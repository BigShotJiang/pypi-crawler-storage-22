#
# This file is part of gmlib. It is free software.
# You can redistribute it and/or modify it under the terms of the GNU Affero General Public License version 3.
#

import os

import numpy as np

from .utils.tools import BBox3


class ImplicitElevationSurface:
    def __call__(self, P):
        P = np.reshape(np.asarray(P), (-1, 3))
        res = P[:, 2] - self.evaluate_z(P[:, :2])
        assert res.shape[0] > 0
        if res.shape[0] == 1:
            return res[0]
        return res

    def underlying_dtm(self):
        return None


class ImplicitHorizontalPlane(ImplicitElevationSurface):
    def __init__(self, zvalue):
        self.z = float(zvalue)

    def evaluate_z(self, P):
        P = np.reshape(np.asarray(P), (-1, 2))
        assert P.shape[0] > 0
        if P.shape[0] == 1:
            return self.z
        return np.tile(self.z, P.shape[0])

    def bbox(self):
        return BBox3(zmin=self.z, zmax=self.z)


class ImplicitDTM(ImplicitElevationSurface):
    def __init__(self, origin, steps, zmap):
        self.origin = np.array(origin, dtype="d")
        assert self.origin.shape == (2,)
        self.steps = np.array(steps, copy=True, dtype="d")
        self.invsteps = np.array([(1.0 / ds) for ds in steps], dtype="d")
        assert self.invsteps.shape == (2,)
        self.z = np.array(zmap, copy=True, dtype="d")

    def bbox(self):
        Ox, Oy = self.origin
        ny, nx = self.z.shape
        dx, dy = self.steps
        return BBox3(Ox, Ox + nx * dx, Oy, Oy + ny * dy, self.z.min(), self.z.max())

    def in_square_interpolation(self, P):
        P = np.asarray(P, dtype="d")
        assert P.shape == (2,)
        DX = P - self.origin
        DX *= self.invsteps
        DX[DX < 0] = 0
        i, j = DX
        zmap = self.z
        nx, ny = zmap.shape
        i = min(i, nx - 1)
        j = min(j, ny - 1)
        ii, ij = int(i), int(j)
        i -= ii
        j -= ij
        if j == 0:
            if i == 0:
                return zmap[ii, ij]
            zl, zr = zmap[ii : ii + 2, ij]
            return (1 - i) * zl + i * zr
        if i == 0:
            zl, zr = zmap[ii, ij : ij + 2]
            return (1 - j) * zl + j * zr
        # We divide the square into two triangles
        # to be consistent with the DTM 3D representation
        # and possible topography clipping
        assert 0 < i < 1
        assert 0 < j < 1
        if i + j <= 1:  # lower triangle
            z = (1 - i - j) * zmap[ii, ij]
            z += i * zmap[ii + 1, ij]
            z += j * zmap[ii, ij + 1]
        else:  # upper triangle
            z = (i + j - 1) * zmap[ii + 1, ij + 1]
            z += (1 - i) * zmap[ii, ij + 1]
            z += (1 - j) * zmap[ii + 1, ij]
        return z
        raise AssertionError()

    def underlying_dtm(self):
        zmap = self.z
        nx, ny = zmap.shape
        dx, dy = self.steps
        x = np.arange(0, nx * dx, dx) + self.origin[0]
        y = np.arange(0, ny * dy, dy) + self.origin[1]
        xy = np.meshgrid(x, y, indexing="ij")
        vertices = np.empty((nx * ny, 3), dtype=zmap.dtype)
        for i, xi in enumerate(xy):
            vertices[:, i] = xi.ravel()
        vertices[:, -1] = zmap.ravel()
        # Two triangles in the lower left cell
        llc = np.array([[0, ny, 1], [ny, ny + 1, 1]], dtype=np.int64)
        # Triangles stip on the left side
        strip = np.vstack([llc + k for k in range(ny - 1)])
        triangles = np.vstack([strip + ny * k for k in range(nx - 1)])
        return vertices, triangles

    def evaluate_z(self, P):
        P = np.reshape(np.asarray(P), (-1, 2))
        res = np.array([self.in_square_interpolation(xy) for xy in P])
        try:
            return float(res)
        except TypeError:
            pass
        return res


def extract_plane(f):
    # we already have read the code character (first character on the line)
    l = f.readline().strip().split()
    point = tuple(float(s) for s in l[:3])
    normal = tuple(float(s) for s in l[3:6])
    #    ux = tuple(float(s) for s in l[6:9])
    #    uy = tuple(float(s) for s in l[9:]:)
    return point, normal


def extract_mnt(f, decimals=8):
    # we already have read the code character (first character on the line)
    l = f.readline().strip().split()
    nx, ny = (int(s) for s in l[6:8])
    assert int(l[8]) + 2 == nx
    assert int(l[9]) + 2 == ny
    zmap = []
    line = l[10:]
    while line:
        zmap.append(np.array([float(s) for s in line]))
        line = f.readline().strip().split()
    zmap = np.array(zmap)
    x, y, z = (zmap[:, k::3] for k in range(3))

    def clean(a):
        a = np.delete(a, [1, nx - 2], axis=0)
        return np.delete(a, [1, ny - 2], axis=1)

    x, y, z = (clean(a) for a in (x, y, z))
    dx = np.unique(np.round(x[1:, :] - x[:-1, :], decimals))
    assert dx.shape == (1,)
    dy = np.unique(np.round(y[:, 1:] - y[:, :-1], decimals))
    assert dy.shape == (1,)
    xmin, ymin = x.min(), y.min()
    return (xmin, ymin), (float(dx), float(dy)), z


def sec_extract(filename):
    if os.path.exists(filename):
        with open(filename) as f:
            line = f.readline()
            while not line.startswith("Surfaces"):
                line = f.readline()
            code = int(f.read(1))
            if code == 1:
                point, normal = extract_plane(f)
                assert normal[0] == 0
                assert normal[1] == 0
                return ImplicitHorizontalPlane(point[2])
            if code == 9:
                return ImplicitDTM(*extract_mnt(f))
    raise OSError(filename + " not found")


if __name__ == "__main__":
    from matplotlib import pyplot as plt

    zmap = np.array([[0, 1], [0, 2]])
    origin = (1, 1)
    steps = (2, 2)
    dtm = ImplicitDTM(origin, steps, zmap)
    nx, ny = 20, 20
    xmin, xmax = 0, 4
    ymin, ymax = 0, 4
    xy = np.meshgrid(np.linspace(xmin, xmax, nx), np.linspace(ymin, ymax, ny))
    x, y = (a.ravel() for a in xy)
    z = np.array([dtm.evaluate_z((xi, yi)) for xi, yi in zip(x, y)])
    z.shape = nx, ny
    plt.gca().set_aspect("equal")
    box = (xmin, xmax, ymin, ymax)
    plt.imshow(np.transpose(z)[::-1], extent=box)
    O = origin
    d = steps
    cell = np.array(
        [O, (O[0] + d[0], O[0]), (O[0] + d[0], O[0] + d[1]), (O[0], O[0] + d[1]), O]
    )
    plt.plot(cell[:, 0], cell[:, 1], "r")
