#
# This file is part of gmlib. It is free software.
# You can redistribute it and/or modify it under the terms of the GNU Affero General Public License version 3.
#

import os
import shutil
from collections import defaultdict, namedtuple
from optparse import OptionParser

import numpy as np
from lxml import etree

from forgeo.gmlib import geomodeller_project as gmp
from forgeo.gmlib import myxmltools as mx
from forgeo.gmlib.geomodeller_project import geo, gml


def data_attribs(uid, provenance=None):
    attribs = {"ObservationID": uid}
    if provenance is not None:
        attribs["Provenance"] = "%d" % provenance
    return attribs


def coordinates_node(pt):
    return gml.coordinates("{:f},{:f}".format(*pt), cs=",", decimal=".", ts=" ")


def create_contact_node(uid, provenance, pt, formation):
    return geo.Interface(
        geo.Data(Name=formation),
        gml.LineString(coordinates_node(pt)),
        **data_attribs(uid, provenance),
    )


def create_orientation_node(uid, provenance, pt, orientation, formation):
    dip, direction, polarity = orientation
    assert polarity in ("normal", "reverse")
    return geo.Foliation(
        geo.Data(Name=formation),
        geo.FoliationObservation(
            gml.Point(coordinates_node(pt)),
            Azimuth=f"{direction:f}",
            Dip=f"{dip:f}",
            NormalPolarity="true" if polarity == "normal" else "false",
        ),
        **data_attribs(uid, provenance),
    )


Contact = namedtuple("Contact", ["uid", "provenance", "point", "attribution"])
Orientation = namedtuple(
    "Contact", ["uid", "provenance", "point", "orientation", "attribution"]
)
OrientationMeasurement = namedtuple(
    "OrientationMeasurement", ["dip", "direction", "polarity"]
)


def extract_structural_roots(root):
    topography_sections = gmp.find_topography_sections(root)
    assert len(topography_sections) == 1, "one and only one topography section"
    section = topography_sections[0]
    structdata = mx.create_child_if_needed(section, "Structural2DData")
    interfaces = mx.create_child_if_needed(structdata, "Interfaces")
    foliations = mx.create_child_if_needed(structdata, "Foliations")
    return interfaces, foliations


def select_data_to_remove(root, uids):
    interfaces, foliations = extract_structural_roots(root)
    removed = []
    for dataset, tag in [
        (interfaces, geo.Interface().tag),
        (foliations, geo.Foliation().tag),
    ]:
        for child in dataset.findall(tag):
            if "ObservationID" in child.attrib:
                obsid = child.attrib["ObservationID"]
                if obsid in uids:
                    removed.append((obsid, dataset, child))
    return removed


def locate_superimposed_data(root):
    interfaces, foliations = extract_structural_roots(root)
    data = defaultdict(list)
    for dataset, tag in [
        (interfaces, geo.Interface().tag),
        (foliations, geo.Foliation().tag),
    ]:
        for child in dataset.findall(tag):
            formation = child.find(geo.Data().tag).attrib["Name"]
            xy = child.find(".//" + gml.coordinates().tag)
            assert xy is not None
            x, y = [float(s.strip()) for s in xy.text.split(xy.attrib["cs"])]
            data[(formation, x, y)].append(child)
    superimposed = []
    for key, elts in data.items():
        if len(elts) > 1:
            natures = [etree.QName(elt).localname for elt in elts]
            assert natures.count("Interface") <= 1, (
                "several superimposed contact points for at {1:f}, {2:f} for "
                "formation {0}"
            ).format(*key)
            superimposed.append(
                (key, [(nature, elt) for nature, elt in zip(natures, elts)])
            )
    return superimposed


def update_provenances(provenances, new):
    rankmax = max(provenances.values()) + 1
    provenances.update({p: rankmax + k for k, p in enumerate(set(new))})
    return provenances


def filter_superimposed_orientations(superimposed, average_provenance, joinsep="+"):
    new_orientations = []
    removed_orientations = []
    for key, elts in superimposed:
        natures = [elt[0] for elt in elts]
        if natures.count("Foliation") > 1:
            uids = []
            dipdir = []
            polarities = set()
            for i, elt in enumerate([v[1] for v in elts]):
                if natures[i] == "Foliation":
                    uids.append(elt.attrib["ObservationID"])
                    obs = elt.find(geo.FoliationObservation().tag)
                    dipdir.append(
                        tuple(float(obs.attrib[s]) for s in ["Dip", "Azimuth"])
                    )
                    polarities.add(obs.attrib["NormalPolarity"])
                    removed_orientations.append(elt)
            assert len(polarities) == 1, "inconsistent polarities for data {}".format(
                " ".join(uids)
            )
            dipdir = np.mean(dipdir, axis=0)
            polarity = {"true": "normal", "false": "reverse"}[polarities.pop().lower()]
            formation, x, y = key
            new_orientations.append(
                create_orientation_node(
                    joinsep.join(uids),
                    average_provenance,
                    (x, y),
                    (*dipdir, polarity),
                    formation,
                )
            )
    return new_orientations, removed_orientations


def append_data(root, data, provenances):
    formations = gmp.read_formation_colors(root)
    formation_names = formations.keys()
    faults = gmp.extract_raw_faults_data(root)
    fault_names = faults.keys()
    assert not formation_names & fault_names
    attributions = formation_names | fault_names
    #    print('possible attributions:', attributions)
    interfaces, foliations = extract_structural_roots(root)
    for item in data:
        attribution = item.attribution
        assert attribution in attributions, (
            f"not a valid attribution: {attribution} for {item.uid}"
        )
        provenance = item.provenance
        if provenance is not None:
            provenance = provenances[provenance]
        if type(item) is Contact:
            interfaces.append(
                create_contact_node(item.uid, provenance, item.point, attribution)
            )
        else:
            assert type(item) is Orientation
            foliations.append(
                create_orientation_node(
                    item.uid, provenance, item.point, item.orientation, attribution
                )
            )
    return root


def collect_data(datafile, idsep, idcols, skip, has_provenance, csvsep=";"):
    lines = []
    with open(datafile) as f:
        for line in f:
            l = line.strip()
            if l:
                lines.append(l.split(csvsep))
    data = []
    uids = set()
    assert skip >= 0
    assert idcols > 0
    provenance = None
    for item in lines[skip:]:
        uid = idsep.join(item[:idcols])
        assert uid not in uids, "duplicate item: " + uid
        uids.add(uid)
        pos = idcols
        if has_provenance:
            provenance = item[pos]
            pos += 1
        point = tuple(float(s) for s in item[pos : pos + 2])
        pos += 2
        nature = item[pos]
        assert nature in ["interface", "orientation"], (
            f"unknown nature: {nature} for {uid}"
        )
        pos += 1
        attribution = item[pos]
        if nature == "interface":
            data.append(Contact(uid, provenance, point, attribution))
        else:
            assert nature == "orientation"
            pos += 1
            dip, direction, polarity = item[pos:]
            try:
                dip, direction = float(dip), float(direction)
            except ValueError as ve:
                raise ve
            assert 0 <= dip <= 90, f"{uid}: not a dip value: {dip:f}"
            assert 0 <= direction < 360, f"{uid}: not a dir value: {direction:f}"
            if not polarity:
                polarity = "normal"
            data.append(
                Orientation(
                    uid,
                    provenance,
                    point,
                    OrientationMeasurement(dip, direction, polarity),
                    attribution,
                )
            )
    return uids, data


def setup_parser():
    parser = OptionParser(
        usage="""usage: %prog path_to_model_file

    This scripts modifies a geomodeller xml project file."""
    )

    parser.add_option(
        "-i",
        "-d",
        "--data",
        action="store",
        type="string",
        dest="datafile",
        default="",
        help="path to the data file as csv",
    )
    parser.add_option(
        "--csv",
        action="store",
        type="string",
        dest="csvsep",
        default=";",
        help="symbol used to separate columns in csv (defaults to ;)",
    )
    parser.add_option(
        "-o",
        "--output",
        action="store",
        type="string",
        dest="output_file",
        default="",
        help="path to the new geomodeller file",
    )
    parser.add_option(
        "-l",
        "--log",
        action="store",
        type="string",
        dest="logfilename",
        default="",
        help="path to a file to log warning - this desactivate quiet",
    )
    parser.add_option(
        "--skip",
        action="store",
        type="int",
        dest="header_rows",
        default=1,
        help=("number of lines of header files (to be skipped) : defaults to 1"),
    )
    parser.add_option(
        "--id-sep",
        action="store",
        type="string",
        dest="idsep",
        default="-",
        help=("separator used to generate unique id from id columns(defaults to -)"),
    )
    parser.add_option(
        "--id-cols",
        action="store",
        type="int",
        dest="idcols",
        default=4,
        help=("number of columns to be used to generate unique id(defaults to 4)"),
    )
    parser.add_option(
        "-q",
        "--quiet",
        action="store_true",
        dest="quiet",
        default=False,
        help="does not output warnings and information",
    )
    parser.add_option(
        "--no-provenance",
        action="store_true",
        dest="no_provenance",
        default=False,
        help=(
            "provenances are given in the column, after the "
            "first idcols columns, "
            "if no provenance is given, use this flag"
        ),
    )
    parser.add_option(
        "-p",
        "--provenance",
        action="append",
        type="string",
        dest="provenances",
        default=[],
        help=(
            "adds a blank provenance field, "
            "other provenance fields can be collected from provenance "
            "column (cf. --no-provenance)"
        ),
    )
    parser.add_option(
        "-c",
        "--correct",
        action="store_true",
        dest="correct",
        default=False,
        help=(
            "correct superimposed contact and orientation data by slightly offseting "
            "orientation data (this is due to a bug in GeoModeller that affects "
            "potential fields with one contact data with superimposed orientation data "
            "and only one formation... typically such as planar faults - the correction "
            "will affect all superpimposed data and orientation, regardless of these "
            "conditions)"
        ),
    )

    return parser


def load_project_xml(projectfile):
    assert os.path.exists(projectfile), "could not find file: " + projectfile
    tree = gmp.extract_tree(projectfile)
    return tree, tree.getroot()


def load_project(projectfile, additional_provenances):
    tree, root = load_project_xml(projectfile)
    provenance_group = root.find(geo.ProvenanceGroup().tag)
    provenances = {
        item.attrib["id"]: int(item.attrib["rank"])
        for item in provenance_group.findall(geo.Provenance().tag)
    }
    update_provenances(provenances, [*additional_provenances, "Average"])
    return (tree, root), provenances


def process(project, provenances, options):
    warnings = []

    def warn(message):
        warnings.append("WARNING: " + message)

    tree, root = project

    datafile = options.datafile
    if len(datafile.strip()) == 0:
        warn("no data file provided!")
    else:
        assert os.path.exists(datafile), "could not find file: " + datafile
        uids, data = collect_data(
            datafile,
            options.idsep,
            options.idcols,
            options.header_rows,
            not options.no_provenance,
            options.csvsep,
        )
        removed = select_data_to_remove(root, uids)
        for uid, parent, child in removed:
            warn(f"{uid} is overwritten")
            parent.remove(child)
        update_provenances(
            provenances,
            [item.provenance for item in data if item.provenance is not None],
        )
        append_data(root, data, provenances)

    # Average duplicate orientation data
    joinsep = "+"
    locate_superimposed_data(root)
    new_orientations, removed_orientations = filter_superimposed_orientations(
        locate_superimposed_data(root), provenances["Average"], joinsep=joinsep
    )
    orientations = root.find(".//" + geo.Foliations().tag)
    assert orientations is not None
    for elt in removed_orientations:
        orientations.remove(elt)
    for elt in new_orientations:
        warn(
            "average orientation replacing: "
            + " and ".join(elt.attrib["ObservationID"].split(joinsep))
        )
        orientations.append(elt)

    if options.correct:
        epsilon = 1e-3  # 1 mm !!!
        for key, elts in locate_superimposed_data(root):
            assert len(elts) == 2
            natures = [elt[0] for elt in elts]
            assert natures.count("Interface") == 1
            assert natures.count("Foliation") == 1
            orientation = elts[1][1] if natures[0] == "Interface" else elts[0][1]
            observation = orientation.find(geo.FoliationObservation().tag)
            assert observation is not None
            azimuth = (90.0 - float(observation.attrib["Azimuth"])) * 2 * np.pi / 360.0
            u = np.array([np.cos(azimuth), np.sin(azimuth)])
            coordinates = observation.find(".//" + gml.coordinates().tag)
            formation, x, y = key
            cs = coordinates.attrib["cs"]
            assert (x, y) == tuple(float(s) for s in coordinates.text.split(cs))
            P = np.array([x, y]) + epsilon * u
            coordinates.text = f"{P[0]:f}{cs}{P[1]:f}"
            warnings.append(
                "slightly offseting {} orientation for data {} at ({:f}, {:f})".format(
                    formation, orientation.attrib["ObservationID"], x, y
                )
            )

    provenance_group.clear()
    for key, rank in provenances.items():
        provenance_group.append(geo.Provenance(id=key, rank="%d" % rank))

    outputfile = options.output_file.strip()
    if len(outputfile) > 0:
        backup = projectfile + ".bak"
        warn(f"overwriting existing project file (backup in: {backup})")
        shutil.copy(projectfile, backup)
        outputfile = projectfile
    if not outputfile.endswith(".xml"):
        outputfile += ".xml"
    tree.write(
        outputfile,
        xml_declaration=True,
        encoding="utf-8",
        method="xml",
        pretty_print=True,
    )

    logfilename = options.logfilename.strip()
    if len(logfilename) > 0:
        with open(logfilename, "w") as logfile:
            logfile.writelines(warnings)
    elif not options.quiet:
        pass


def append_crs_info(projectfile, crsinfo):
    tree, root = load_project_xml(projectfile)
    gmcrs, qgiscrs = crsinfo
    if gmcrs is not None:
        assert "CoordSystem" in root.attrib
        assert root.attrib["CoordSystem"] == gmcrs
    if qgiscrs is not None:
        assert "QGisCRS" not in root.attrib or root.attrib["QGisCRS"] == qgiscrs
        if gmcrs is None:
            root.attrib["CoordSystem"] = "local"
        root.attrib["QGisCRS"] = qgiscrs
        # Overwriting file
        tree.write(
            projectfile,
            xml_declaration=True,
            encoding="utf-8",
            method="xml",
            pretty_print=True,
        )


if __name__ == "__main__":
    parser = setup_parser()
    options, args = parser.parse_args()
    projectfile = args[0]
    if len(args) > 1:
        print(
            "WARNING: The following arguments will not be processed: "
            + " ".join(args[1:]),
            file=sys.stderr,
        )
    project, provenances = load_project(projectfile, options.provenances)
    process(project, provenances, options)
