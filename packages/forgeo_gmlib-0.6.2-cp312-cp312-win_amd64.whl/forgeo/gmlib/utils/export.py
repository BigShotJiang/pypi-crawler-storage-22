#
# This file is part of gmlib. It is free software.
# You can redistribute it and/or modify it under the terms of the GNU Affero General Public License version 3.
#

from pathlib import Path

from forgeo.gmlib.GeologicalModel3D import GeologicalModel


class Data_dumper:
    def __init__(self, f, *headers):
        self.f = f
        self.line_length = len(headers)
        self(*headers)

    def _line(self, items):
        if len(items) < self.line_length:
            items = items + ("",) * (self.line_length - len(items))
        return ";".join([s if isinstance(s, str) else f"{s:.18e}" for s in items])

    def __call__(self, *items):
        print(self._line(items), file=self.f)


def fault_data_from_model(filepath):
    filename = Path(filepath)
    if filename.exists():
        data = GeologicalModel.extract_data(str(filename))
    else:
        raise OSError(str(filename) + " not found!")

    data = data["faults_data"]

    with Path(f"{filename.stem}-faults-data.csv").open("w") as f:
        dump = Data_dumper(f, "name", "x", "y", "z", "gx", "gy", "gz")
        for name, fdata in data.items():
            potdata = fdata.potential_data
            interfaces = potdata.interfaces
            assert len(interfaces) == 1
            for M in interfaces[0]:
                dump(name, *M)
            gradients = potdata.gradients
            for M, G in zip(gradients.locations, gradients.values):
                dump(name, *M, *G)
