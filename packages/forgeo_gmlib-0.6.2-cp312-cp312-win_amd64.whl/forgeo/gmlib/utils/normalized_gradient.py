import numpy as np


def normalized_gradient(azimuth, dip, polarity, degrees=False):
    """
    Compute a GeoModeller unit gradient that corresponds to dip dir measures.

    :param degrees: boolean to tell if angular data are measured in degrees,
                    defaults to False
    """
    azimuth = np.asarray(azimuth, dtype=np.double)
    dip = np.asarray(dip, dtype=np.double)
    polarity = np.asarray(polarity, np.double)
    if degrees:
        azimuth = azimuth * (np.pi / 180.0)
        dip = dip * (np.pi / 180.0)
    assert np.all((azimuth >= 0) & (azimuth <= 2 * np.pi))
    azimuth = 0.5 * np.pi - azimuth  # North is at pi/2 and counter clock wise
    assert np.all((dip >= 0) & (dip <= 0.5 * np.pi))
    assert np.all((polarity == -1) | (polarity == 1))
    assert azimuth.shape == dip.shape == polarity.shape
    assert azimuth.ndim == 1
    # unit dip vector
    u = np.vstack(
        np.broadcast(
            np.cos(dip) * np.cos(azimuth), np.cos(dip) * np.sin(azimuth), -np.sin(dip)
        )
    )
    # unit normal horizontal vector
    v = np.vstack(np.broadcast(np.sin(azimuth), -np.cos(azimuth), 0))
    assert np.allclose(np.sum(u * v, axis=1), 0)
    # return gradient vector
    return polarity[:, None] * np.cross(u, v, axis=1)


if __name__ == "__main__":
    dip = [45, 90, 0, 45]
    azimuth = [0, 90, 45, 45]
    polarity = [1, 1, 1, -1]
    g = normalized_gradient(azimuth, dip, polarity, degrees=True)
