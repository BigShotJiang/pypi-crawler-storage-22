from dataclasses import dataclass


@dataclass
class BBox3:
    xmin: float = None
    xmax: float = None
    ymin: float = None
    ymax: float = None
    zmin: float = None
    zmax: float = None

    # backward compatibility
    def __getitem__(self, name):
        try:
            return getattr(self, name.lower())
        except AttributeError:
            msg = f"BBox3 has no {name} field"
            raise KeyError(msg)

    @property
    def is_consistent(self):
        return (
            ((self.xmin is None and self.xmax is None) or (self.xmin <= self.xmax))
            and ((self.ymin is None and self.ymax is None) or (self.ymin <= self.ymax))
            and ((self.zmin is None and self.zmax is None) or (self.zmin <= self.zmax))
        )

    @property
    def origin(self):
        return self.xmin, self.ymin, self.zmin

    @property
    def extent(self):
        return self.xmax - self.xmin, self.ymax - self.ymin, self.zmax - self.zmin
