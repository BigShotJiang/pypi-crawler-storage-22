try:
    from ._version import __version__, __version_tuple__, version, version_tuple
except ImportError:
    __version__ = version = None
    __version_tuple__ = version_tuple = ()

from .rigs import BSPTree, Discontinuities, Side, all_intersections, which_domain

__all__ = ["BSPTree", "Discontinuities", "Side", "all_intersections", "which_domain"]
