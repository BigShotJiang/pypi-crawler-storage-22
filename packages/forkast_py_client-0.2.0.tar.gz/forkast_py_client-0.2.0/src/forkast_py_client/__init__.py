"""
Forkast Python SDK
==================

Public entrypoint for the Forkast SDK.
"""

import logging
import aiohttp
from web3 import AsyncWeb3
from web3.providers.rpc import AsyncHTTPProvider

# --------------------
# Services
# --------------------
from forkast_py_client.services.base import (
    ForkastAPIError,
    ForkastAuthError,
    ForkastHTTPError,
)
from forkast_py_client.services.market import MarketService
from forkast_py_client.services.account import AccountService
from forkast_py_client.services.balances import BalancesService
from forkast_py_client.services.order import OrderService

# --------------------
# Types
# --------------------
from forkast_py_client.types import (
    WalletDetails,
    LoginResponse,
    TokenApprovalResponse,
    UserProfile,
    BalanceResponse,
    OutcomeBalanceResponse,
    Event,
    Market,
    MarketOutcome,
    MarketPosition,
    MarketsResponse,
    MarketStatus,
    OutcomeType,
    OrderBook,
    TokenPrices,
)

# --------------------
# Config / constants
# --------------------
from forkast_py_client.config import Network, ENDPOINTS, RPC_URLS, PREPARE_APPROVE_TOKEN

# --------------------
# Utils
# --------------------
from forkast_py_client.utils import load_abi, create_provider_without_signer

logger = logging.getLogger(__name__)


# --------------------
# Main SDK facade
# --------------------
class ForkastSDK:
    """
    Main entrypoint for the Forkast SDK.

    Provides access to all Forkast services with shared
    network and API key configuration.
    """

    def __init__(
        self,
        network: Network = Network.TESTNET,
        api_key: str = "",
    ):
        self._network = network
        self._api_key = api_key
        self._session: aiohttp.ClientSession | None = None
        self._provider: AsyncWeb3 | None = None
        self._is_approved_for_trading: bool = False
        self._cached_proxy_wallet: str | None = None

        self._account = None
        self._balances = None
        self._market = None
        self._order = None

    async def open(self):
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                base_url=ENDPOINTS[self._network]["BASE_URL"],
                timeout=aiohttp.ClientTimeout(total=30),
            )
        if self._provider is None:
            rpc_url = RPC_URLS[self._network]
            self._provider = AsyncWeb3(AsyncHTTPProvider(rpc_url))

    async def close(self):
        if self._provider:
            await self._provider.provider.disconnect()
            self._provider = None
        if self._session and not self._session.closed:
            await self._session.close()

    async def __aenter__(self):
        await self.open()
        return self

    async def __aexit__(self, exc_type, exc, tb):
        await self.close()

    def _ensure_session(self):
        if self._session is None or self._session.closed:
            raise RuntimeError(
                "SDK session is not initialized. "
                "Use `async with ForkastSDK(...)` or call `await sdk.open()`."
            )

    def _ensure_provider(self):
        if self._provider is None:
            raise RuntimeError(
                "SDK provider is not initialized. "
                "Use `async with ForkastSDK(...)` or call `await sdk.open()`."
            )

    async def check_allowances(self, proxy_wallet: str) -> bool:
        """
        Check if the proxy wallet has approved PC tokens and Conditional Tokens
        for trading on the CTF Exchange.

        :param proxy_wallet: Gnosis Safe proxy wallet address
        :return: True if both approvals are in place, False otherwise
        """
        self._ensure_provider()
        from web3 import Web3
        proxy_wallet = Web3.to_checksum_address(proxy_wallet)
        exchange = PREPARE_APPROVE_TOKEN[self._network]["CTF_EXCHANGE"]

        # Load ABIs
        pc_token_abi = load_abi("PCToken.abi.json")
        conditional_token_abi = load_abi("ConditionalTokens.abi.json")

        # Create contract instances
        pc_token = self._provider.eth.contract(
            address=PREPARE_APPROVE_TOKEN[self._network]["PC_TOKEN"],
            abi=pc_token_abi,
        )
        conditional_tokens = self._provider.eth.contract(
            address=PREPARE_APPROVE_TOKEN[self._network]["CONDITIONAL_TOKENS"],
            abi=conditional_token_abi,
        )

        # Check PC token allowance
        try:
            pc_allowance = await pc_token.functions.allowance(proxy_wallet, exchange).call()
            pc_approved = pc_allowance > 0
        except Exception as e:
            logger.warning("Failed to check PC allowance: %s", e)
            pc_approved = False

        # Check Conditional Token approval
        try:
            ctf_approved = await conditional_tokens.functions.isApprovedForAll(
                proxy_wallet, exchange
            ).call()
        except Exception as e:
            logger.warning("Failed to check CTF approval: %s", e)
            ctf_approved = False

        # Set combined flag
        self._is_approved_for_trading = pc_approved and ctf_approved
        self._cached_proxy_wallet = proxy_wallet

        logger.info(
            "Allowance check for %s: PC=%s, CTF=%s, combined=%s",
            proxy_wallet, pc_approved, ctf_approved, self._is_approved_for_trading
        )

        return self._is_approved_for_trading

    @property
    def is_approved_for_trading(self) -> bool:
        """Returns whether the cached proxy wallet is approved for trading."""
        return self._is_approved_for_trading

    def get_market_service(self) -> MarketService:
        """
        Get MarketService instance.
        """
        self._ensure_session()
        if not self._market:
            self._market = MarketService(self._session, self._network, self._api_key)
        return self._market

    def get_account_service(self) -> AccountService:
        """
        Get AccountService instance.
        """
        self._ensure_session()
        self._ensure_provider()
        if not self._account:
            self._account = AccountService(
                self._session, self._network, self._api_key, self._provider
            )
        return self._account

    def get_balances_service(self) -> BalancesService:
        """
        Get BalancesService instance.
        """
        self._ensure_session()
        if not self._balances:
            self._balances = BalancesService(
                self._session, self._network, self._api_key
            )
        return self._balances

    def get_order_service(self) -> OrderService:
        """
        Get OrderService instance.
        """
        self._ensure_session()
        if not self._order:
            self._order = OrderService(
                self._session,
                self.get_market_service(),
                self.get_balances_service(),
                self._network,
                self._api_key,
                self,  # Pass SDK reference for allowance flag access
            )
        return self._order


__all__ = [
    # SDK
    "ForkastSDK",
    "ForkastAPIError",
    "ForkastAuthError",
    "ForkastHTTPError",
    # Services
    "MarketService",
    "AccountService",
    "BalancesService",
    "OrderService",
    # Types
    "WalletDetails",
    "LoginResponse",
    "TokenApprovalResponse",
    "UserProfile",
    "BalanceResponse",
    "OutcomeBalanceResponse",
    "Event",
    "Market",
    "MarketOutcome",
    "MarketPosition",
    "MarketsResponse",
    "MarketStatus",
    "OutcomeType",
    "OrderBook",
    "TokenPrices",
    # Config
    "Network",
    "ENDPOINTS",
    # Utils
    "load_abi",
    "create_provider_without_signer",
]
