import aiohttp
import logging
from typing import Any
from forkast_py_client.config import Network

logger = logging.getLogger(__name__)


class ForkastAPIError(RuntimeError):
    """Base error for Forkast API."""


class ForkastAuthError(ForkastAPIError):
    """Authentication / authorization error."""


class ForkastHTTPError(ForkastAPIError):
    """Generic HTTP error."""


class BaseService:
    def __init__(
        self,
        session: aiohttp.ClientSession,
        network: Network = Network.TESTNET,
        api_key: str = "",
    ):
        self.network = network
        self.api_key = api_key
        self.session = session

    # --------------------
    # Headers
    # --------------------
    def _headers(
        self,
        access_token: str | None = None,
        extra: dict | None = None,
    ) -> dict:
        headers: dict[str, str] = {}

        if self.api_key:
            headers["x-api-key"] = self.api_key

        if access_token:
            headers["Authorization"] = f"Bearer {access_token}"

        if extra:
            headers.update(extra)

        return headers

    # --------------------
    # Core request handler
    # --------------------
    async def _request(
        self,
        method: str,
        url: str,
        *,
        headers: dict | None = None,
        json: dict | None = None,
    ) -> Any:
        try:
            async with self.session.request(
                method,
                url,
                headers=headers,
                json=json,
            ) as resp:
                # Handle auth errors explicitly
                if resp.status in (401, 403):
                    text = await resp.text()
                    raise ForkastAuthError(
                        f"{method} {url} unauthorized ({resp.status}): {text}"
                    )

                # Other HTTP errors
                if resp.status >= 400:
                    text = await resp.text()
                    raise ForkastHTTPError(
                        f"{method} {url} failed ({resp.status}): {text}"
                    )

                # Empty response body
                if resp.content_length == 0:
                    logger.debug("Empty response body from %s %s", method, url)
                    return None

                return await resp.json()

        except aiohttp.ClientError as e:
            logger.exception("Network error calling %s %s", method, url)
            raise ForkastAPIError("Network error while calling Forkast API") from e

    # --------------------
    # Convenience methods
    # --------------------
    async def _get(self, url: str, headers: dict | None = None):
        return await self._request("GET", url, headers=headers)

    async def _post(
        self,
        url: str,
        data: dict | None = None,
        headers: dict | None = None,
    ):
        return await self._request("POST", url, json=data, headers=headers)
