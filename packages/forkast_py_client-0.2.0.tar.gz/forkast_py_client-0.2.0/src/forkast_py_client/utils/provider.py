import asyncio
import logging
from aiohttp import ClientResponseError
from web3 import AsyncWeb3
from web3.providers.rpc import AsyncHTTPProvider
from forkast_py_client.config.constants import RPC_URLS, Network

logger = logging.getLogger(__name__)

# Default retry settings for rate-limited requests
DEFAULT_MAX_RETRIES = 3
DEFAULT_RETRY_DELAY = 2.0


async def create_provider_without_signer(
    network: Network = Network.TESTNET,
    max_retries: int = DEFAULT_MAX_RETRIES,
    retry_delay: float = DEFAULT_RETRY_DELAY,
) -> AsyncWeb3:
    """
    Creates an async Web3 provider without attaching a signer.

    :param network: Whether to use mainnet or testnet
    :param max_retries: Maximum number of retries for rate-limited requests
    :param retry_delay: Base delay in seconds between retries (exponential backoff)
    :return: AsyncWeb3 instance
    """
    rpc_url = RPC_URLS[network]
    last_error = None

    for attempt in range(max_retries):
        try:
            provider = AsyncWeb3(AsyncHTTPProvider(rpc_url))

            if not await provider.is_connected():
                raise RuntimeError("Failed to connect to RPC provider")

            return provider

        except ClientResponseError as e:
            if e.status == 429:
                last_error = e
                delay = retry_delay * (2 ** attempt)
                logger.warning("Rate limited (429), retrying in %ss (attempt %d/%d)", delay, attempt + 1, max_retries)
                await asyncio.sleep(delay)
                continue
            logger.exception("Failed to create async provider")
            raise
        except Exception:
            logger.exception("Failed to create async provider")
            raise

    # All retries exhausted
    logger.error(f"Failed to create async provider after {max_retries} retries")
    if last_error:
        raise last_error
    raise RuntimeError("Failed to create async provider")
