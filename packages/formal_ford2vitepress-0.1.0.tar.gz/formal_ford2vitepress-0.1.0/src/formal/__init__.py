"""FORMAL: Fortran FORD VitePress Markdown Documentation HTML generator.

Generate VitePress-ready API documentation from FORD-parsed Fortran sources.
"""

__version__ = "0.1.0"
__author__ = "Stefano Zaghi"
__license__ = "MIT"
