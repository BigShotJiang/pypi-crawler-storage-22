"""
Tests for FormoSpeech G2P Hakka module.

Based on examples from README.md
"""

import pytest

from formog2p.hakka import (
    G2PResult,
    apply_variant_map,
    clear_tokenizer_cache,
    g2p,
    get_cached_tokenizers,
    get_pronunciation,
    normalize,
    run_jieba,
    text_to_pronunciation,
)

# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture(autouse=True)
def clear_cache():
    """Clear tokenizer cache before each test to ensure isolation."""
    clear_tokenizer_cache()
    yield
    clear_tokenizer_cache()


# =============================================================================
# Basic G2P Tests
# =============================================================================


class TestBasicG2P:
    """Tests for basic G2P functionality."""

    def test_g2p_basic_conversion(self):
        """Test basic G2P conversion returns correct structure."""
        result = g2p("天公落水", "hak_sx", "ipa")

        assert isinstance(result, G2PResult)
        assert isinstance(result.pronunciations, list)
        assert len(result.pronunciations) == 2
        assert result.pronunciations == ["tʰ-ien_24 k-uŋ_24", "l-ok_5 s-ui_31"]

    def test_g2p_returns_g2presult(self):
        """Test that g2p returns a G2PResult object."""
        result = g2p("天公", "hak_sx", "ipa")

        assert isinstance(result, G2PResult)
        assert hasattr(result, "pronunciations")
        assert hasattr(result, "unknown_words")
        assert hasattr(result, "details")
        assert hasattr(result, "has_unknown")

    def test_g2p_unknown_words_detection(self):
        """Test detection of unknown words."""
        result = g2p("天公落水XYZ", "hak_sx", "ipa")

        assert result.has_unknown is True
        assert "XYZ" in result.unknown_words

    def test_g2p_no_unknown_words(self):
        """Test when there are no unknown words."""
        result = g2p("天公落水", "hak_sx", "ipa")

        assert result.has_unknown is False
        assert result.unknown_words == []


# =============================================================================
# Text to Pronunciation Tests
# =============================================================================


class TestTextToPronunciation:
    """Tests for text_to_pronunciation function."""

    def test_text_to_pronunciation_basic(self):
        """Test basic text to pronunciation conversion."""
        pron_str = text_to_pronunciation("天公落水", "hak_sx")

        assert isinstance(pron_str, str)
        assert pron_str == "tʰ-ien_24 k-uŋ_24 l-ok_5 s-ui_31"

    def test_text_to_pronunciation_with_unknown(self):
        """Test text to pronunciation with unknown words."""
        pron_str = text_to_pronunciation("天公XYZ", "hak_sx")

        # Unknown words should be replaced with "?" by default
        assert "?" in pron_str


# =============================================================================
# Mixed Chinese-English Tests
# =============================================================================


class TestMixedChineseEnglish:
    """Tests for mixed Chinese-English G2P."""

    def test_g2p_with_english_enabled(self):
        """Test G2P with English pronunciation enabled."""
        result = g2p("天公落水Hello World", "hak_sx", "ipa", include_eng=True)

        assert isinstance(result.pronunciations, list)
        # Should have pronunciations for both Chinese and English
        assert len(result.pronunciations) >= 2

    def test_g2p_english_as_unknown_when_disabled(self):
        """Test that English words are treated as unknown when include_eng=False."""
        result = g2p("天公落水Hello", "hak_sx", "ipa", include_eng=False)

        assert "HELLO" in result.unknown_words


# =============================================================================
# Text Normalization Tests
# =============================================================================


class TestTextNormalization:
    """Tests for text normalization functions."""

    def test_normalize_half_to_fullwidth_punctuation(self):
        """Test half-width to full-width punctuation conversion."""
        normalized = normalize("天公落水!")

        assert "！" in normalized
        assert "!" not in normalized

    def test_normalize_variant_characters(self):
        """Test variant character conversion."""
        normalized = normalize("台灣真好")

        assert "臺" in normalized

    def test_normalize_uppercase_conversion(self):
        """Test uppercase conversion for English."""
        normalized = normalize("Hello", use_variant_map=True)

        assert normalized == "HELLO"

    def test_apply_variant_map(self):
        """Test apply_variant_map function."""
        result = apply_variant_map("台灣")

        assert result == "臺灣"

    def test_apply_variant_map_onsen(self):
        """Test variant map for 温泉."""
        result = apply_variant_map("温泉")

        assert result == "溫泉"


# =============================================================================
# Punctuation Handling Tests
# =============================================================================


class TestPunctuationHandling:
    """Tests for punctuation handling in G2P."""

    def test_punctuation_preserved_in_output(self):
        """Test that punctuation marks are preserved in output."""
        result = g2p("天公落水，好靚！", "hak_sx", "ipa")

        assert "，" in result.pronunciations
        assert "！" in result.pronunciations


# =============================================================================
# Tokenization Tests
# =============================================================================


class TestTokenization:
    """Tests for tokenization functions."""

    def test_run_jieba_basic(self):
        """Test basic jieba tokenization."""
        words, oovs = run_jieba("天公落水", "hak_sx")

        assert words == ["天公", "落水"]
        assert oovs == []

    def test_run_jieba_with_english(self):
        """Test jieba tokenization with English."""
        words, oovs = run_jieba("天公落水ABC", "hak_sx", include_eng=True)

        assert "天公" in words
        assert "落水" in words
        assert "ABC" in words


# =============================================================================
# Pronunciation Lookup Tests
# =============================================================================


class TestPronunciationLookup:
    """Tests for pronunciation lookup functions."""

    def test_get_pronunciation_known_word(self):
        """Test pronunciation lookup for a known word."""
        pron = get_pronunciation("天公", "hak_sx", "ipa")

        assert pron is not None
        assert isinstance(pron, list)
        assert pron == ["tʰ-ien_24 k-uŋ_24"]

    def test_get_pronunciation_unknown_word(self):
        """Test pronunciation lookup for an unknown word."""
        pron = get_pronunciation("XYZABC", "hak_sx", "ipa")

        assert pron is None


# =============================================================================
# Cache Management Tests
# =============================================================================


class TestCacheManagement:
    """Tests for tokenizer cache management."""

    def test_get_cached_tokenizers_initially_empty(self):
        """Test that cache is empty after clearing."""
        clear_tokenizer_cache()
        cached = get_cached_tokenizers()

        assert cached == []

    def test_get_cached_tokenizers_after_use(self):
        """Test that tokenizers are cached after use."""
        clear_tokenizer_cache()

        # Trigger tokenizer loading
        g2p("天公", "hak_sx", "ipa")

        cached = get_cached_tokenizers()
        assert "hak_sx" in cached

    def test_clear_tokenizer_cache(self):
        """Test clearing the tokenizer cache."""
        # First, load a tokenizer
        g2p("天公", "hak_sx", "ipa")
        assert len(get_cached_tokenizers()) > 0

        # Clear cache
        clear_tokenizer_cache()
        assert get_cached_tokenizers() == []


# =============================================================================
# Dialect Support Tests
# =============================================================================


class TestDialectSupport:
    """Tests for different Hakka dialect support."""

    @pytest.mark.parametrize(
        "lang_group",
        [
            "hak_sx",  # 四縣
            "hak_nsx",  # 南四縣
            "hak_hl",  # 海陸
            "hak_dp",  # 大埔
            "hak_rp",  # 饒平
            "hak_za",  # 詔安
        ],
    )
    def test_g2p_supports_all_dialects(self, lang_group):
        """Test that G2P works for all supported dialects."""
        result = g2p("天公", lang_group, "ipa")

        assert isinstance(result, G2PResult)
        assert isinstance(result.pronunciations, list)


# =============================================================================
# Pronunciation Type Tests
# =============================================================================


class TestPronunciationType:
    """Tests for different pronunciation types."""

    def test_g2p_ipa_output(self):
        """Test G2P with IPA pronunciation type."""
        result = g2p("天公", "hak_sx", "ipa")

        assert len(result.pronunciations) > 0

    def test_g2p_pinyin_output(self):
        """Test G2P with pinyin pronunciation type."""
        result = g2p("天公", "hak_sx", "pinyin")

        assert len(result.pronunciations) > 0


# =============================================================================
# G2PResult Object Tests
# =============================================================================


class TestG2PResultObject:
    """Tests for G2PResult dataclass."""

    def test_g2presult_str_method(self):
        """Test G2PResult __str__ method."""
        result = g2p("天公落水", "hak_sx", "ipa")
        result_str = str(result)

        assert isinstance(result_str, str)
        assert "tʰ-ien_24 k-uŋ_24" in result_str

    def test_g2presult_details(self):
        """Test G2PResult details attribute."""
        result = g2p("天公", "hak_sx", "ipa")

        assert len(result.details) > 0
        assert "word" in result.details[0]
        assert "pronunciation" in result.details[0]


# =============================================================================
# Edge Cases
# =============================================================================


class TestEdgeCases:
    """Tests for edge cases."""

    def test_empty_string(self):
        """Test G2P with empty string."""
        result = g2p("", "hak_sx", "ipa")

        assert result.pronunciations == []
        assert result.unknown_words == []

    def test_whitespace_only(self):
        """Test G2P with whitespace only."""
        result = g2p("   ", "hak_sx", "ipa")

        assert result.pronunciations == []

    def test_invalid_lang_group(self):
        """Test G2P with invalid language group."""
        with pytest.raises(ValueError):
            g2p("天公", "invalid_lang", "ipa")
