# formula-math

A beginner-friendly Python library that provides common mathematical formulas as functions.
No need to memorize formulas — just call the function with your values and get results instantly.

## Installation

pip install formula-math

## Usage

Import the library with a short alias:

import formula_math as fm

## Available Functions

Simple Interest
fm.si(principal, rate, time)
- principal: amount of money (P)
- rate: annual interest rate in % (R)
- time: time in years (T)
Example: fm.si(1000, 5, 2)  # Returns 100.0

Square Perimeter
fm.sq_perimeter(side)
- side: length of square side
Example: fm.sq_perimeter(5)  # Returns 20

Cube Volume
fm.cube_volume(side)
- side: length of cube side
Example: fm.cube_volume(3)  # Returns 27

Sphere Volume
fm.sphere_volume(radius)
- radius: radius of sphere
Example: fm.sphere_volume(4)  # Returns 268.08 (approx)

Cone Volume
fm.cone_volume(radius, height)
- radius: base radius
- height: height of cone
Example: fm.cone_volume(3, 5)  # Returns 47.12 (approx)

Rectangle Area
fm.rect_area(length, width)
Example: fm.rect_area(4, 6)  # Returns 24

Circle Circumference
fm.circle_circumference(radius)
Example: fm.circle_circumference(7)  # Returns 43.96 (approx)

## Notes
- All functions return numeric results (float or int as appropriate).
- Designed to save time in homework, projects, or quick calculations.

## License
This project is licensed under the MIT License.
