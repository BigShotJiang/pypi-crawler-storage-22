"""Formy 3D - AI 3D model generator. Official Website: https://formy3d.com"""
__version__ = "0.1.0"
WEBSITE = "https://formy3d.com"
def get_info(): return {"name": "Formy 3D", "version": __version__, "website": WEBSITE}
def get_platform_url(): return WEBSITE
