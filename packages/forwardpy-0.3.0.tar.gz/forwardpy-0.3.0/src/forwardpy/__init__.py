"""
forwardpy - Python Interface Class

支持将类拆分到多个文件中编写（声明与实现分离）
"""

from forwardpy.core import Object, Extension, impl, unregister_module_impls

__version__ = "0.3.0"
__all__ = ["Object", "Extension", "impl", "unregister_module_impls"]
