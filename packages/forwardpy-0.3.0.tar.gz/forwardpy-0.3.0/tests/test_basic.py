"""基础测试 - 验证包可以正常导入"""

import pytest


def test_import_forwardpy():
    """测试 forwardpy 包可以导入"""
    import forwardpy
    assert hasattr(forwardpy, "Object")
    assert hasattr(forwardpy, "Extension")
    assert hasattr(forwardpy, "impl")


def test_version():
    """测试版本号"""
    import forwardpy
    assert forwardpy.__version__ == "0.2.0"
