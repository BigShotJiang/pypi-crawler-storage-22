from __future__ import annotations

import contextlib
import socket
import threading
import time
from typing import Callable


def _send_request(sock: socket.socket, headers: dict[str, str]) -> None:
    req = [
        "GET /events HTTP/1.1\r\n",
        "Host: localhost\r\n",
        "Accept: text/event-stream\r\n",
        "Cache-Control: no-cache\r\n",
    ]
    for k, v in headers.items():
        req.append(f"{k}: {v}\r\n")
    req.append("\r\n")
    sock.sendall("".join(req).encode("latin-1"))


def _read_until(sock: socket.socket, token: bytes) -> tuple[bytes, bytes]:
    data = bytearray()
    while token not in data:
        chunk = sock.recv(1024)
        if not chunk:
            break
        data += chunk
    raw = bytes(data)
    idx = raw.find(token)
    if idx == -1:
        return raw, b""
    split_at = idx + len(token)
    return raw[:split_at], raw[split_at:]


def _parse_events(
    buffer: str,
    chunk: str,
    handler: Callable[[dict[str, object]], None],
    current_event: dict[str, object] | None = None,
) -> tuple[str, dict[str, object]]:
    buffer += chunk
    lines = buffer.split("\n")
    buffer = lines.pop() or ""
    event: dict[str, object] = current_event if current_event is not None else {}
    for raw in lines:
        line = raw.rstrip("\r")
        if line == "":
            # dispatch
            if "data" in event and isinstance(event["data"], str):
                import json

                with contextlib.suppress(Exception):
                    event["data"] = json.loads(event["data"])
            if event.get("event"):
                handler(event)
            event = {}
        elif line.startswith("data: "):
            prev = event.get("data")
            prev_str = prev if isinstance(prev, str) else ""
            event["data"] = prev_str + line[6:]
        elif line.startswith("event: "):
            event["event"] = line[7:]
        elif line.startswith("id: "):
            with contextlib.suppress(Exception):
                event["timestamp"] = int(line[4:])
    if current_event is None:
        return buffer, {}
    return buffer, event


class SSEThread(threading.Thread):
    def __init__(
        self, headers: dict[str, str], on_event: Callable[[dict[str, object]], None]
    ) -> None:
        super().__init__(daemon=True)
        self._headers = headers
        self._on_event = on_event
        self._stop_event = threading.Event()

    def stop(self) -> None:
        self._stop_event.set()

    def run(self) -> None:
        while not self._stop_event.is_set():
            buffer = ""
            event: dict[str, object] = {}
            sock: socket.socket | None = None
            try:
                sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
                sock.connect("/tmp/fostrom/agent.sock")
                _send_request(sock, self._headers)
                # read headers, preserving any SSE data that arrived in the same read
                _, leftover = _read_until(sock, b"\r\n\r\n")
                if leftover:
                    decoded = leftover.decode("utf-8", errors="ignore")
                    buffer, event = _parse_events(buffer, decoded, self._on_event, event)
                # stream body
                while not self._stop_event.is_set():
                    chunk = sock.recv(2048)
                    if not chunk:
                        break
                    decoded = chunk.decode("utf-8", errors="ignore")
                    buffer, event = _parse_events(buffer, decoded, self._on_event, event)
            except Exception:
                time.sleep(0.5)
            finally:
                with contextlib.suppress(Exception):
                    if sock is not None:
                        sock.close()
