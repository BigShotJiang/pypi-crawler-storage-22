"""Tests for foundry-mcp."""
