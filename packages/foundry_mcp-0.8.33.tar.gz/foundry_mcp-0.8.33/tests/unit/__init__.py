"""Unit tests for foundry-mcp."""
