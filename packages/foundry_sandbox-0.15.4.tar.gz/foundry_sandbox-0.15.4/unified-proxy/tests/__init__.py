"""Unified proxy test suite."""
