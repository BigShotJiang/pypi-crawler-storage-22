.. automodule:: foxglove.schemas
   :members:
