//! Foxglove protocol v2 types.

pub mod client;
mod message;
pub mod server;
