from .leads import LeadsResource, AsyncLeadsResource
from .campaigns import CampaignsResource, AsyncCampaignsResource
from .templates import TemplatesResource, AsyncTemplatesResource
from .email_accounts import EmailAccountsResource, AsyncEmailAccountsResource
from .inbox import InboxResource, AsyncInboxResource
from .analytics import AnalyticsResource, AsyncAnalyticsResource

__all__ = [
    "LeadsResource",
    "AsyncLeadsResource",
    "CampaignsResource",
    "AsyncCampaignsResource",
    "TemplatesResource",
    "AsyncTemplatesResource",
    "EmailAccountsResource",
    "AsyncEmailAccountsResource",
    "InboxResource",
    "AsyncInboxResource",
    "AnalyticsResource",
    "AsyncAnalyticsResource",
]
