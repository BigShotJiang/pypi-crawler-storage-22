# FoxReach CLI

Command-line interface for the [FoxReach](https://foxreach.io) cold email outreach API.

## Installation

```bash
pip install foxreach-cli
```

## Setup

```bash
# Save your API key
foxreach config set-key
# Enter: otr_your_api_key

# Verify
foxreach config show
```

You can also use environment variables:

```bash
export FOXREACH_API_KEY=otr_your_api_key
export FOXREACH_BASE_URL=https://api.foxreach.io/api/v1  # optional
```

## Usage

### Leads

```bash
foxreach leads list
foxreach leads list --search "jane" --status active
foxreach leads get cld_abc123
foxreach leads create --email jane@example.com --first-name Jane --company "Acme"
foxreach leads update cld_abc123 --company "New Corp"
foxreach leads delete cld_abc123
```

### Campaigns

```bash
foxreach campaigns list
foxreach campaigns list --status active
foxreach campaigns get cmp_xyz789
foxreach campaigns create --name "Q1 Outreach" --daily-limit 100
foxreach campaigns update cmp_xyz789 --daily-limit 200
foxreach campaigns start cmp_xyz789
foxreach campaigns pause cmp_xyz789
foxreach campaigns add-leads cmp_xyz789 --lead-ids cld_1,cld_2,cld_3
foxreach campaigns add-accounts cmp_xyz789 --account-ids acc_1
foxreach campaigns delete cmp_xyz789
```

### Sequences

```bash
foxreach sequences list --campaign cmp_xyz789
foxreach sequences create --campaign cmp_xyz789 --subject "Hi {{firstName}}" --body "Hello!"
foxreach sequences update --campaign cmp_xyz789 --sequence seq_1 --delay-days 3
foxreach sequences delete --campaign cmp_xyz789 --sequence seq_1
```

### Templates

```bash
foxreach templates list
foxreach templates get tpl_abc123
foxreach templates create --name "Follow-up" --body "Hi {{firstName}}, just checking in."
foxreach templates update tpl_abc123 --name "New Follow-up"
foxreach templates delete tpl_abc123
```

### Email Accounts

```bash
foxreach accounts list
foxreach accounts get acc_abc123
foxreach accounts delete acc_abc123
```

### Inbox

```bash
foxreach inbox list
foxreach inbox list --unread --category interested
foxreach inbox get rpl_abc123
foxreach inbox update rpl_abc123 --read --category qualified
```

### Analytics

```bash
foxreach analytics overview
foxreach analytics campaign cmp_xyz789
```

## JSON Output

Add `--json` to any command to get raw JSON output for scripting:

```bash
foxreach leads list --json | jq '.data[].email'
foxreach campaigns get cmp_xyz789 --json
```

## Configuration

Config is stored at `~/.foxreach/config.json`. Environment variables take precedence:

| Setting | Env Var | Config Key |
|---------|---------|------------|
| API Key | `FOXREACH_API_KEY` | `api_key` |
| Base URL | `FOXREACH_BASE_URL` | `base_url` |
