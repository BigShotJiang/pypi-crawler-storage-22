"""FoxReach CLI — command-line interface for the FoxReach API."""

__version__ = "0.1.0"
