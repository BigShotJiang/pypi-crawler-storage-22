from __future__ import annotations

import sys

from foxreach import FoxReach

from . import config as cfg
from .output import print_error


def get_client() -> FoxReach:
    api_key = cfg.get_api_key()
    if not api_key:
        print_error("No API key configured. Run: foxreach config set-key")
        sys.exit(1)

    kwargs = {"api_key": api_key}
    base_url = cfg.get_base_url()
    if base_url:
        kwargs["base_url"] = base_url

    return FoxReach(**kwargs)
