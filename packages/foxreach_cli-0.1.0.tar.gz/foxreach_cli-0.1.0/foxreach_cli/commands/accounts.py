from __future__ import annotations

import sys
from dataclasses import asdict

import click

from foxreach import FoxReachError

from ..client_factory import get_client
from ..output import print_detail, print_error, print_json, print_meta, print_success, print_table


@click.group()
def accounts() -> None:
    """Manage email accounts."""


@accounts.command("list")
@click.option("--page", default=1, type=int)
@click.option("--limit", default=50, type=int)
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def accounts_list(page: int, limit: int, as_json: bool) -> None:
    """List email accounts."""
    client = get_client()
    try:
        result = client.email_accounts.list(page=page, page_size=limit)
    except FoxReachError as e:
        print_error(str(e))
        sys.exit(1)

    if as_json:
        print_json({"data": [asdict(a) for a in result.data], "meta": asdict(result.meta)})
        return

    if not result.data:
        click.echo("No email accounts found.")
        return

    print_table(
        result.data,
        ["ID", "Email", "Display Name", "Active", "Daily Limit", "Sent Today", "Health"],
        {
            "ID": "id", "Email": "email", "Display Name": "display_name",
            "Active": "is_active", "Daily Limit": "daily_limit",
            "Sent Today": "sent_today", "Health": "health_score",
        },
    )
    print_meta(result.meta)


@accounts.command("get")
@click.argument("account_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def accounts_get(account_id: str, as_json: bool) -> None:
    """Get an email account by ID."""
    client = get_client()
    try:
        account = client.email_accounts.get(account_id)
    except FoxReachError as e:
        print_error(str(e))
        sys.exit(1)

    if as_json:
        print_json(account)
        return

    print_detail(account, [
        "id", "email", "display_name", "provider", "is_active",
        "daily_limit", "sent_today", "warmup_enabled",
        "health_score", "bounce_rate", "reply_rate",
        "connection_status", "created_at",
    ])


@accounts.command("delete")
@click.argument("account_id")
@click.confirmation_option(prompt="Are you sure you want to delete this email account?")
def accounts_delete(account_id: str) -> None:
    """Delete an email account."""
    client = get_client()
    try:
        client.email_accounts.delete(account_id)
    except FoxReachError as e:
        print_error(str(e))
        sys.exit(1)
    print_success(f"Email account deleted: {account_id}")
