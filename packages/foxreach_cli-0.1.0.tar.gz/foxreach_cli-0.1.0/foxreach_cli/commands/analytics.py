from __future__ import annotations

import sys
from dataclasses import asdict

import click

from foxreach import FoxReachError

from ..client_factory import get_client
from ..output import print_detail, print_error, print_json, print_table


@click.group()
def analytics() -> None:
    """View analytics and stats."""


@analytics.command("overview")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def analytics_overview(as_json: bool) -> None:
    """Show dashboard overview stats."""
    client = get_client()
    try:
        stats = client.analytics.overview()
    except FoxReachError as e:
        print_error(str(e))
        sys.exit(1)

    if as_json:
        print_json(stats)
        return

    print_detail(stats, [
        "total_accounts", "active_accounts",
        "total_campaigns", "active_campaigns",
        "total_leads", "total_sent", "total_replies",
        "reply_rate", "account_health_avg",
    ])


@analytics.command("campaign")
@click.argument("campaign_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def analytics_campaign(campaign_id: str, as_json: bool) -> None:
    """Show campaign analytics."""
    client = get_client()
    try:
        stats = client.analytics.campaign(campaign_id)
    except FoxReachError as e:
        print_error(str(e))
        sys.exit(1)

    if as_json:
        print_json(stats)
        return

    print_detail(stats, [
        "sent", "delivered", "bounced", "replied", "opened",
        "reply_rate", "bounce_rate",
    ])

    if stats.daily_stats:
        click.echo("\nDaily Stats:")
        print_table(
            stats.daily_stats,
            ["Date", "Sent", "Delivered", "Bounced", "Replied", "Opened"],
            {"Date": "date", "Sent": "sent", "Delivered": "delivered", "Bounced": "bounced", "Replied": "replied", "Opened": "opened"},
        )
