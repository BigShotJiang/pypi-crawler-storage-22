from __future__ import annotations

import sys
from dataclasses import asdict
from typing import Optional

import click

from foxreach import CampaignCreate, CampaignUpdate, FoxReachError

from ..client_factory import get_client
from ..output import print_detail, print_error, print_json, print_meta, print_success, print_table


@click.group()
def campaigns() -> None:
    """Manage campaigns."""


@campaigns.command("list")
@click.option("--status", default=None, type=click.Choice(["draft", "active", "paused", "completed"]))
@click.option("--page", default=1, type=int)
@click.option("--limit", default=50, type=int)
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def campaigns_list(status: Optional[str], page: int, limit: int, as_json: bool) -> None:
    """List campaigns."""
    client = get_client()
    try:
        result = client.campaigns.list(page=page, page_size=limit, status=status)
    except FoxReachError as e:
        print_error(str(e))
        sys.exit(1)

    if as_json:
        print_json({"data": [asdict(c) for c in result.data], "meta": asdict(result.meta)})
        return

    if not result.data:
        click.echo("No campaigns found.")
        return

    print_table(
        result.data,
        ["ID", "Name", "Status", "Sent", "Replied", "Leads", "Daily Limit"],
        {
            "ID": "id", "Name": "name", "Status": "status",
            "Sent": "total_sent", "Replied": "total_replied",
            "Leads": "total_leads", "Daily Limit": "daily_limit",
        },
    )
    print_meta(result.meta)


@campaigns.command("get")
@click.argument("campaign_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def campaigns_get(campaign_id: str, as_json: bool) -> None:
    """Get a campaign by ID."""
    client = get_client()
    try:
        campaign = client.campaigns.get(campaign_id)
    except FoxReachError as e:
        print_error(str(e))
        sys.exit(1)

    if as_json:
        print_json(campaign)
        return

    print_detail(campaign, [
        "id", "name", "status", "timezone", "sending_days",
        "sending_start_hour", "sending_end_hour", "daily_limit",
        "total_leads", "total_sent", "total_delivered",
        "total_bounced", "total_replied", "total_opened",
        "created_at", "started_at", "completed_at",
    ])


@campaigns.command("create")
@click.option("--name", required=True, help="Campaign name")
@click.option("--timezone", default=None, help="IANA timezone (e.g. America/New_York)")
@click.option("--daily-limit", default=None, type=int, help="Max emails per day")
@click.option("--start-hour", default=None, type=int, help="Sending start hour (0-23)")
@click.option("--end-hour", default=None, type=int, help="Sending end hour (0-23)")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def campaigns_create(
    name: str,
    timezone: Optional[str],
    daily_limit: Optional[int],
    start_hour: Optional[int],
    end_hour: Optional[int],
    as_json: bool,
) -> None:
    """Create a new campaign."""
    client = get_client()
    try:
        campaign = client.campaigns.create(CampaignCreate(
            name=name,
            timezone=timezone or "UTC",
            daily_limit=daily_limit,
            sending_start_hour=start_hour,
            sending_end_hour=end_hour,
        ))
    except FoxReachError as e:
        print_error(str(e))
        sys.exit(1)

    if as_json:
        print_json(campaign)
    else:
        print_success(f"Campaign created: {campaign.id}")


@campaigns.command("update")
@click.argument("campaign_id")
@click.option("--name", default=None, help="Campaign name")
@click.option("--timezone", default=None, help="IANA timezone")
@click.option("--daily-limit", default=None, type=int, help="Max emails per day")
@click.option("--start-hour", default=None, type=int, help="Sending start hour")
@click.option("--end-hour", default=None, type=int, help="Sending end hour")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def campaigns_update(
    campaign_id: str,
    name: Optional[str],
    timezone: Optional[str],
    daily_limit: Optional[int],
    start_hour: Optional[int],
    end_hour: Optional[int],
    as_json: bool,
) -> None:
    """Update a campaign."""
    client = get_client()
    try:
        campaign = client.campaigns.update(campaign_id, CampaignUpdate(
            name=name,
            timezone=timezone,
            daily_limit=daily_limit,
            sending_start_hour=start_hour,
            sending_end_hour=end_hour,
        ))
    except FoxReachError as e:
        print_error(str(e))
        sys.exit(1)

    if as_json:
        print_json(campaign)
    else:
        print_success(f"Campaign updated: {campaign.id}")


@campaigns.command("delete")
@click.argument("campaign_id")
@click.confirmation_option(prompt="Are you sure you want to delete this campaign?")
def campaigns_delete(campaign_id: str) -> None:
    """Delete a campaign (must be in draft status)."""
    client = get_client()
    try:
        client.campaigns.delete(campaign_id)
    except FoxReachError as e:
        print_error(str(e))
        sys.exit(1)
    print_success(f"Campaign deleted: {campaign_id}")


@campaigns.command("start")
@click.argument("campaign_id")
def campaigns_start(campaign_id: str) -> None:
    """Start a campaign."""
    client = get_client()
    try:
        campaign = client.campaigns.start(campaign_id)
    except FoxReachError as e:
        print_error(str(e))
        sys.exit(1)
    print_success(f"Campaign started: {campaign.name} ({campaign.id})")


@campaigns.command("pause")
@click.argument("campaign_id")
def campaigns_pause(campaign_id: str) -> None:
    """Pause a running campaign."""
    client = get_client()
    try:
        campaign = client.campaigns.pause(campaign_id)
    except FoxReachError as e:
        print_error(str(e))
        sys.exit(1)
    print_success(f"Campaign paused: {campaign.name} ({campaign.id})")


@campaigns.command("add-leads")
@click.argument("campaign_id")
@click.option("--lead-ids", required=True, help="Comma-separated lead IDs")
def campaigns_add_leads(campaign_id: str, lead_ids: str) -> None:
    """Add leads to a campaign."""
    ids = [i.strip() for i in lead_ids.split(",") if i.strip()]
    client = get_client()
    try:
        result = client.campaigns.add_leads(campaign_id, ids)
    except FoxReachError as e:
        print_error(str(e))
        sys.exit(1)
    print_success(f"Added {result.get('added', len(ids))} leads to campaign {campaign_id}")


@campaigns.command("add-accounts")
@click.argument("campaign_id")
@click.option("--account-ids", required=True, help="Comma-separated account IDs")
def campaigns_add_accounts(campaign_id: str, account_ids: str) -> None:
    """Assign email accounts to a campaign."""
    ids = [i.strip() for i in account_ids.split(",") if i.strip()]
    client = get_client()
    try:
        result = client.campaigns.add_accounts(campaign_id, ids)
    except FoxReachError as e:
        print_error(str(e))
        sys.exit(1)
    print_success(f"Added {result.get('added', len(ids))} accounts to campaign {campaign_id}")
