from __future__ import annotations

import sys
from dataclasses import asdict
from typing import Optional

import click

from foxreach import FoxReachError, ThreadUpdate

from ..client_factory import get_client
from ..output import print_detail, print_error, print_json, print_meta, print_success, print_table


@click.group()
def inbox() -> None:
    """Manage inbox threads."""


@inbox.command("list")
@click.option("--category", default=None, help="Filter by category")
@click.option("--unread", is_flag=True, default=False, help="Show only unread")
@click.option("--starred", is_flag=True, default=False, help="Show only starred")
@click.option("--campaign", default=None, help="Filter by campaign ID")
@click.option("--account", default=None, help="Filter by account ID")
@click.option("--search", default=None, help="Search threads")
@click.option("--page", default=1, type=int)
@click.option("--limit", default=50, type=int)
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def inbox_list(
    category: Optional[str],
    unread: bool,
    starred: bool,
    campaign: Optional[str],
    account: Optional[str],
    search: Optional[str],
    page: int,
    limit: int,
    as_json: bool,
) -> None:
    """List inbox threads."""
    client = get_client()
    try:
        result = client.inbox.list_threads(
            page=page,
            page_size=limit,
            category=category,
            is_read=False if unread else None,
            is_starred=True if starred else None,
            campaign_id=campaign,
            account_id=account,
            search=search,
        )
    except FoxReachError as e:
        print_error(str(e))
        sys.exit(1)

    if as_json:
        print_json({"data": [asdict(t) for t in result.data], "meta": asdict(result.meta)})
        return

    if not result.data:
        click.echo("No threads found.")
        return

    print_table(
        result.data,
        ["ID", "From", "Subject", "Category", "Read", "Starred", "Received"],
        {
            "ID": "id", "From": "from_email", "Subject": "subject",
            "Category": "category", "Read": "is_read",
            "Starred": "is_starred", "Received": "received_at",
        },
    )
    print_meta(result.meta)


@inbox.command("get")
@click.argument("reply_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def inbox_get(reply_id: str, as_json: bool) -> None:
    """Get a thread by ID."""
    client = get_client()
    try:
        thread = client.inbox.get(reply_id)
    except FoxReachError as e:
        print_error(str(e))
        sys.exit(1)

    if as_json:
        print_json(thread)
        return

    print_detail(thread, [
        "id", "from_email", "to_email", "subject",
        "body_plain", "category", "is_read", "is_starred",
        "campaign_id", "lead_id", "received_at",
    ])


@inbox.command("update")
@click.argument("reply_id")
@click.option("--read/--unread", default=None, help="Mark as read or unread")
@click.option("--starred/--unstarred", default=None, help="Star or unstar")
@click.option("--category", default=None, help="Set category")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def inbox_update(reply_id: str, read: Optional[bool], starred: Optional[bool], category: Optional[str], as_json: bool) -> None:
    """Update a thread (read status, star, category)."""
    client = get_client()
    try:
        thread = client.inbox.update(reply_id, ThreadUpdate(
            is_read=read,
            is_starred=starred,
            category=category,
        ))
    except FoxReachError as e:
        print_error(str(e))
        sys.exit(1)

    if as_json:
        print_json(thread)
    else:
        print_success(f"Thread updated: {reply_id}")
