from __future__ import annotations

import sys
from dataclasses import asdict
from typing import Optional

import click

from foxreach import FoxReachError, LeadCreate, LeadUpdate

from ..client_factory import get_client
from ..output import print_detail, print_error, print_json, print_meta, print_success, print_table


@click.group()
def leads() -> None:
    """Manage leads."""


@leads.command("list")
@click.option("--search", default=None, help="Search by email, name, or company")
@click.option("--status", default=None, type=click.Choice(["active", "bounced", "unsubscribed", "replied"]))
@click.option("--page", default=1, type=int, help="Page number")
@click.option("--limit", default=50, type=int, help="Results per page")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def leads_list(search: Optional[str], status: Optional[str], page: int, limit: int, as_json: bool) -> None:
    """List leads."""
    client = get_client()
    try:
        result = client.leads.list(page=page, page_size=limit, search=search, status=status)
    except FoxReachError as e:
        print_error(str(e))
        sys.exit(1)

    if as_json:
        print_json({"data": [asdict(l) for l in result.data], "meta": asdict(result.meta)})
        return

    if not result.data:
        click.echo("No leads found.")
        return

    print_table(
        result.data,
        ["ID", "Email", "First Name", "Last Name", "Company", "Status"],
        {"ID": "id", "Email": "email", "First Name": "first_name", "Last Name": "last_name", "Company": "company", "Status": "status"},
    )
    print_meta(result.meta)


@leads.command("get")
@click.argument("lead_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def leads_get(lead_id: str, as_json: bool) -> None:
    """Get a lead by ID."""
    client = get_client()
    try:
        lead = client.leads.get(lead_id)
    except FoxReachError as e:
        print_error(str(e))
        sys.exit(1)

    if as_json:
        print_json(lead)
        return

    print_detail(lead, [
        "id", "email", "first_name", "last_name", "company", "title",
        "phone", "linkedin_url", "website", "status", "source",
        "tags", "notes", "created_at", "updated_at",
    ])


@leads.command("create")
@click.option("--email", required=True, help="Lead email address")
@click.option("--first-name", default=None, help="First name")
@click.option("--last-name", default=None, help="Last name")
@click.option("--company", default=None, help="Company name")
@click.option("--title", default=None, help="Job title")
@click.option("--phone", default=None, help="Phone number")
@click.option("--linkedin", default=None, help="LinkedIn URL")
@click.option("--website", default=None, help="Website URL")
@click.option("--notes", default=None, help="Notes")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def leads_create(
    email: str,
    first_name: Optional[str],
    last_name: Optional[str],
    company: Optional[str],
    title: Optional[str],
    phone: Optional[str],
    linkedin: Optional[str],
    website: Optional[str],
    notes: Optional[str],
    as_json: bool,
) -> None:
    """Create a new lead."""
    client = get_client()
    try:
        lead = client.leads.create(LeadCreate(
            email=email,
            first_name=first_name,
            last_name=last_name,
            company=company,
            title=title,
            phone=phone,
            linkedin_url=linkedin,
            website=website,
            notes=notes,
        ))
    except FoxReachError as e:
        print_error(str(e))
        sys.exit(1)

    if as_json:
        print_json(lead)
    else:
        print_success(f"Lead created: {lead.id}")


@leads.command("update")
@click.argument("lead_id")
@click.option("--first-name", default=None, help="First name")
@click.option("--last-name", default=None, help="Last name")
@click.option("--company", default=None, help="Company name")
@click.option("--title", default=None, help="Job title")
@click.option("--phone", default=None, help="Phone number")
@click.option("--linkedin", default=None, help="LinkedIn URL")
@click.option("--website", default=None, help="Website URL")
@click.option("--notes", default=None, help="Notes")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def leads_update(
    lead_id: str,
    first_name: Optional[str],
    last_name: Optional[str],
    company: Optional[str],
    title: Optional[str],
    phone: Optional[str],
    linkedin: Optional[str],
    website: Optional[str],
    notes: Optional[str],
    as_json: bool,
) -> None:
    """Update a lead."""
    client = get_client()
    try:
        lead = client.leads.update(lead_id, LeadUpdate(
            first_name=first_name,
            last_name=last_name,
            company=company,
            title=title,
            phone=phone,
            linkedin_url=linkedin,
            website=website,
            notes=notes,
        ))
    except FoxReachError as e:
        print_error(str(e))
        sys.exit(1)

    if as_json:
        print_json(lead)
    else:
        print_success(f"Lead updated: {lead.id}")


@leads.command("delete")
@click.argument("lead_id")
@click.confirmation_option(prompt="Are you sure you want to delete this lead?")
def leads_delete(lead_id: str) -> None:
    """Delete a lead."""
    client = get_client()
    try:
        client.leads.delete(lead_id)
    except FoxReachError as e:
        print_error(str(e))
        sys.exit(1)
    print_success(f"Lead deleted: {lead_id}")
