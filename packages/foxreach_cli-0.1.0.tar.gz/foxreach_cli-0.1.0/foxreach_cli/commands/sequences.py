from __future__ import annotations

import sys
from dataclasses import asdict
from typing import Optional

import click

from foxreach import FoxReachError, SequenceCreate, SequenceUpdate

from ..client_factory import get_client
from ..output import print_detail, print_error, print_json, print_success, print_table


@click.group()
def sequences() -> None:
    """Manage campaign sequences (email steps)."""


@sequences.command("list")
@click.option("--campaign", required=True, help="Campaign ID")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def sequences_list(campaign: str, as_json: bool) -> None:
    """List sequences for a campaign."""
    client = get_client()
    try:
        items = client.campaigns.sequences.list(campaign)
    except FoxReachError as e:
        print_error(str(e))
        sys.exit(1)

    if as_json:
        print_json([asdict(s) for s in items])
        return

    if not items:
        click.echo("No sequences found.")
        return

    print_table(
        items,
        ["ID", "Step", "Subject", "Delay Days", "Type"],
        {"ID": "id", "Step": "step_number", "Subject": "subject", "Delay Days": "delay_days", "Type": "template_type"},
    )


@sequences.command("create")
@click.option("--campaign", required=True, help="Campaign ID")
@click.option("--body", required=True, help="Email body (supports {{variables}})")
@click.option("--subject", default=None, help="Email subject")
@click.option("--delay-days", default=1, type=int, help="Days to wait before sending")
@click.option("--step", default=None, type=int, help="Step number")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def sequences_create(
    campaign: str,
    body: str,
    subject: Optional[str],
    delay_days: int,
    step: Optional[int],
    as_json: bool,
) -> None:
    """Add a sequence step to a campaign."""
    client = get_client()
    try:
        seq = client.campaigns.sequences.create(campaign, SequenceCreate(
            body=body,
            subject=subject,
            delay_days=delay_days,
            step_number=step,
        ))
    except FoxReachError as e:
        print_error(str(e))
        sys.exit(1)

    if as_json:
        print_json(seq)
    else:
        print_success(f"Sequence created: {seq.id} (step {seq.step_number})")


@sequences.command("update")
@click.option("--campaign", required=True, help="Campaign ID")
@click.option("--sequence", "sequence_id", required=True, help="Sequence ID")
@click.option("--body", default=None, help="Email body")
@click.option("--subject", default=None, help="Email subject")
@click.option("--delay-days", default=None, type=int, help="Days to wait before sending")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def sequences_update(
    campaign: str,
    sequence_id: str,
    body: Optional[str],
    subject: Optional[str],
    delay_days: Optional[int],
    as_json: bool,
) -> None:
    """Update a sequence step."""
    client = get_client()
    try:
        seq = client.campaigns.sequences.update(campaign, sequence_id, SequenceUpdate(
            body=body,
            subject=subject,
            delay_days=delay_days,
        ))
    except FoxReachError as e:
        print_error(str(e))
        sys.exit(1)

    if as_json:
        print_json(seq)
    else:
        print_success(f"Sequence updated: {seq.id}")


@sequences.command("delete")
@click.option("--campaign", required=True, help="Campaign ID")
@click.option("--sequence", "sequence_id", required=True, help="Sequence ID")
@click.confirmation_option(prompt="Are you sure you want to delete this sequence?")
def sequences_delete(campaign: str, sequence_id: str) -> None:
    """Delete a sequence step."""
    client = get_client()
    try:
        client.campaigns.sequences.delete(campaign, sequence_id)
    except FoxReachError as e:
        print_error(str(e))
        sys.exit(1)
    print_success(f"Sequence deleted: {sequence_id}")
