from __future__ import annotations

import sys
from dataclasses import asdict
from typing import Optional

import click

from foxreach import FoxReachError, TemplateCreate, TemplateUpdate

from ..client_factory import get_client
from ..output import print_detail, print_error, print_json, print_meta, print_success, print_table


@click.group()
def templates() -> None:
    """Manage email templates."""


@templates.command("list")
@click.option("--page", default=1, type=int)
@click.option("--limit", default=50, type=int)
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def templates_list(page: int, limit: int, as_json: bool) -> None:
    """List templates."""
    client = get_client()
    try:
        result = client.templates.list(page=page, page_size=limit)
    except FoxReachError as e:
        print_error(str(e))
        sys.exit(1)

    if as_json:
        print_json({"data": [asdict(t) for t in result.data], "meta": asdict(result.meta)})
        return

    if not result.data:
        click.echo("No templates found.")
        return

    print_table(
        result.data,
        ["ID", "Name", "Subject", "Type", "Created At"],
        {"ID": "id", "Name": "name", "Subject": "subject", "Type": "template_type", "Created At": "created_at"},
    )
    print_meta(result.meta)


@templates.command("get")
@click.argument("template_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def templates_get(template_id: str, as_json: bool) -> None:
    """Get a template by ID."""
    client = get_client()
    try:
        template = client.templates.get(template_id)
    except FoxReachError as e:
        print_error(str(e))
        sys.exit(1)

    if as_json:
        print_json(template)
        return

    print_detail(template, [
        "id", "name", "subject", "body", "template_type",
        "send_as_html", "created_at", "updated_at",
    ])


@templates.command("create")
@click.option("--name", required=True, help="Template name")
@click.option("--body", required=True, help="Email body (supports {{variables}})")
@click.option("--subject", default=None, help="Email subject")
@click.option("--html", is_flag=True, help="Send as HTML")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def templates_create(name: str, body: str, subject: Optional[str], html: bool, as_json: bool) -> None:
    """Create a new template."""
    client = get_client()
    try:
        template = client.templates.create(TemplateCreate(
            name=name,
            body=body,
            subject=subject,
            send_as_html=html,
        ))
    except FoxReachError as e:
        print_error(str(e))
        sys.exit(1)

    if as_json:
        print_json(template)
    else:
        print_success(f"Template created: {template.id}")


@templates.command("update")
@click.argument("template_id")
@click.option("--name", default=None, help="Template name")
@click.option("--body", default=None, help="Email body")
@click.option("--subject", default=None, help="Email subject")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def templates_update(template_id: str, name: Optional[str], body: Optional[str], subject: Optional[str], as_json: bool) -> None:
    """Update a template."""
    client = get_client()
    try:
        template = client.templates.update(template_id, TemplateUpdate(
            name=name,
            body=body,
            subject=subject,
        ))
    except FoxReachError as e:
        print_error(str(e))
        sys.exit(1)

    if as_json:
        print_json(template)
    else:
        print_success(f"Template updated: {template.id}")


@templates.command("delete")
@click.argument("template_id")
@click.confirmation_option(prompt="Are you sure you want to delete this template?")
def templates_delete(template_id: str) -> None:
    """Delete a template."""
    client = get_client()
    try:
        client.templates.delete(template_id)
    except FoxReachError as e:
        print_error(str(e))
        sys.exit(1)
    print_success(f"Template deleted: {template_id}")
