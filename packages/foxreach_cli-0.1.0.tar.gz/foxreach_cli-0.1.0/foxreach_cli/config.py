from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, Optional

_CONFIG_DIR = Path.home() / ".foxreach"
_CONFIG_FILE = _CONFIG_DIR / "config.json"


def _load() -> Dict[str, Any]:
    if _CONFIG_FILE.exists():
        return json.loads(_CONFIG_FILE.read_text())
    return {}


def _save(data: Dict[str, Any]) -> None:
    _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    _CONFIG_FILE.write_text(json.dumps(data, indent=2) + "\n")


def get_api_key() -> Optional[str]:
    env = os.environ.get("FOXREACH_API_KEY")
    if env:
        return env
    return _load().get("api_key")


def get_base_url() -> Optional[str]:
    env = os.environ.get("FOXREACH_BASE_URL")
    if env:
        return env
    return _load().get("base_url")


def set_api_key(key: str) -> None:
    data = _load()
    data["api_key"] = key
    _save(data)


def set_base_url(url: str) -> None:
    data = _load()
    data["base_url"] = url
    _save(data)


def get_all() -> Dict[str, Any]:
    data = _load()
    if os.environ.get("FOXREACH_API_KEY"):
        data["api_key"] = os.environ["FOXREACH_API_KEY"]
        data["_api_key_source"] = "env"
    if os.environ.get("FOXREACH_BASE_URL"):
        data["base_url"] = os.environ["FOXREACH_BASE_URL"]
        data["_base_url_source"] = "env"
    return data


def mask_key(key: str) -> str:
    if len(key) <= 8:
        return key[:4] + "****"
    return key[:4] + "*" * (len(key) - 8) + key[-4:]
