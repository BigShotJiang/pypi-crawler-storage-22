from __future__ import annotations

import sys

import click

from foxreach import FoxReachError

from . import config as cfg
from .output import console, print_error, print_success


@click.group()
@click.version_option(package_name="foxreach-cli")
def cli() -> None:
    """FoxReach CLI — manage your cold email outreach from the terminal."""


# ── Config ────────────────────────────────────────────────────────────────

@cli.group()
def config() -> None:
    """Manage CLI configuration."""


@config.command("set-key")
@click.option("--key", prompt="API Key", hide_input=True, help="Your FoxReach API key (otr_...)")
def config_set_key(key: str) -> None:
    """Save your API key."""
    if not key.startswith("otr_"):
        print_error('API key must start with "otr_"')
        sys.exit(1)
    cfg.set_api_key(key)
    print_success("API key saved.")


@config.command("set-url")
@click.argument("url")
def config_set_url(url: str) -> None:
    """Override the API base URL."""
    cfg.set_base_url(url)
    print_success(f"Base URL set to {url}")


@config.command("show")
def config_show() -> None:
    """Show current configuration."""
    data = cfg.get_all()
    key = data.get("api_key")
    if key:
        source = data.get("_api_key_source", "config file")
        console.print(f"API Key:  {cfg.mask_key(key)}  [dim]({source})[/dim]")
    else:
        console.print("API Key:  [dim]not set[/dim]")

    url = data.get("base_url")
    if url:
        source = data.get("_base_url_source", "config file")
        console.print(f"Base URL: {url}  [dim]({source})[/dim]")
    else:
        console.print("Base URL: [dim]default[/dim]")


# ── Register command groups ───────────────────────────────────────────────

from .commands.leads import leads
from .commands.campaigns import campaigns
from .commands.sequences import sequences
from .commands.templates import templates
from .commands.accounts import accounts
from .commands.inbox import inbox
from .commands.analytics import analytics

cli.add_command(leads)
cli.add_command(campaigns)
cli.add_command(sequences)
cli.add_command(templates)
cli.add_command(accounts)
cli.add_command(inbox)
cli.add_command(analytics)


def main() -> None:
    try:
        cli()
    except FoxReachError as e:
        print_error(str(e))
        sys.exit(1)


if __name__ == "__main__":
    main()
