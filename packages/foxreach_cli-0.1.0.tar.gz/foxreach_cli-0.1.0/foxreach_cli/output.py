from __future__ import annotations

import json
import sys
from dataclasses import asdict
from typing import Any, Dict, List, Optional, Sequence

import click
from rich.console import Console
from rich.table import Table

console = Console()
err_console = Console(stderr=True)


def print_json(data: Any) -> None:
    if hasattr(data, "__dataclass_fields__"):
        data = asdict(data)
    click.echo(json.dumps(data, indent=2, default=str))


def print_table(rows: Sequence[Any], columns: List[str], field_map: Optional[Dict[str, str]] = None) -> None:
    """Print a rich table. field_map maps column headers to dataclass field names."""
    table = Table(show_header=True, header_style="bold cyan")
    for col in columns:
        table.add_column(col)

    for row in rows:
        values = []
        for col in columns:
            field = (field_map or {}).get(col, col.lower().replace(" ", "_"))
            val = getattr(row, field, "") if hasattr(row, field) else ""
            values.append(str(val) if val is not None else "")
        table.add_row(*values)

    console.print(table)


def print_detail(obj: Any, fields: List[str]) -> None:
    """Print a single object as key-value pairs."""
    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("Field", style="bold")
    table.add_column("Value")

    for field in fields:
        val = getattr(obj, field, None)
        label = field.replace("_", " ").title()
        table.add_row(label, str(val) if val is not None else "-")

    console.print(table)


def print_success(message: str) -> None:
    console.print(f"[green]{message}[/green]")


def print_error(message: str) -> None:
    err_console.print(f"[red]Error:[/red] {message}")


def print_meta(meta: Any) -> None:
    if meta and hasattr(meta, "total"):
        console.print(
            f"\n[dim]Page {meta.page}/{meta.total_pages} "
            f"({meta.total} total)[/dim]"
        )
