# Fantasy Premier League MCP Server

A comprehensive **Model Context Protocol (MCP)** server for Fantasy Premier League analysis and strategy. This server provides AI assistants with powerful tools, resources, and prompts to help you dominate your FPL mini-leagues with data-driven insights.

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.13+](https://img.shields.io/badge/python-3.13+-blue.svg)](https://www.python.org/downloads/)
[![MCP](https://img.shields.io/badge/MCP-compatible-green.svg)](https://modelcontextprotocol.io)

## Features

This MCP server provides comprehensive FPL analysis capabilities through:

- **17 Interactive Tools** - Search players, analyze fixtures, compare managers, track transfers, and more
- **4 Data Resources** - access to players, teams, and gameweeks bootstrap data
- **9 Strategy Prompts** - Structured templates for gameweek analysis, squad analysis, transfer planning, chip strategy, and captain selection
- **Smart Caching** - 4-hour cache for bootstrap data to minimize API calls while keeping data fresh
- **Fuzzy Matching** - Find players even with spelling variations or nicknames
- **Live Transfer Trends** - Track the most transferred in/out players for current gameweek
- **Manager Insights** - Analyze squads, transfers, and chip usage (supports 2025/26 half-season system)
- **Fixture Analysis** - Assess team fixtures and plan transfers around favorable runs

## Quick Start

### Option 1: uvx (Recommended)

The fastest way to get started - no installation required:

```json
{
  "mcpServers": {
    "fpl": {
      "command": "uvx",
      "args": ["fpl-mcp-server"],
      "type": "stdio"
    }
  }
}
```

### Option 2: Docker

Use the official Docker image from GitHub Container Registry:

```json
{
  "mcpServers": {
    "fpl": {
      "command": "docker",
      "args": [
        "run",
        "--rm",
        "-i",
        "ghcr.io/nguyenanhducs/fpl-mcp:latest"
      ],
      "type": "stdio"
    }
  }
}
```

### Option 3: From Source

For development or local customization:

```bash
git clone https://github.com/nguyenanhducs/fpl-mcp.git
cd fpl-mcp
uv sync
```

Then configure:

```json
{
  "mcpServers": {
    "fpl": {
      "command": "uv",
      "args": [
        "--directory",
        "/absolute/path/to/fpl-mcp",
        "run",
        "python",
        "-m",
        "src.main"
      ],
      "type": "stdio"
    }
  }
}
```

For detailed installation instructions and more options, see **[Installation Guide](./docs/installation.md)**.

## Usage & Documentation

Once configured, you can interact with the FPL MCP server through Claude Desktop using natural language.

For detailed guidance, see:

- **[Usage Examples](./docs/usage-examples.md)** - Natural language query examples for player analysis, fixtures, leagues, and strategy
- **[Tool Selection Guide](./docs/tool-selection-guide.md)** - Choose the right tool for your analysis task

## Configuration

The server works out-of-the-box with sensible defaults, but you can customize cache durations, timeouts, and logging levels through environment variables.

For detailed configuration instructions for both Docker and uv deployments, see **[Configuration Guide](./docs/configuration.md)**.

## Data Sources

This server uses the official **Fantasy Premier League API**, see [here](./docs/fpl-api.md) for more details.

## Contributing

We welcome contributions! Please see [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.
