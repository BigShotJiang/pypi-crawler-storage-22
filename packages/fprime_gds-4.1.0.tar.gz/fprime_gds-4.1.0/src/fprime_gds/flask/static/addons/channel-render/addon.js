/**
 * Add-on entry file for channel-render, delegates to implementation files.
 */
import "./channel-render.js"