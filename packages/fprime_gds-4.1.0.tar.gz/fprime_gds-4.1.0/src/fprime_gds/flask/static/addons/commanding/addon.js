// Addon is composed of the following parts
import "./arguments.js" // Argument and display processing
import "./command-string.js" // Command string input box
import "./command-history.js" // Command history list
import "./command-input.js" // Command input form