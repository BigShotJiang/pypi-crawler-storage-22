# FPSQL
An easy to use SQLite package
#### Change log:
###### v.1.2.0:
Breaking change!!!
async renamed to asyncio
###### v.1.1.0:
Breaking change!!!
async is now in its own file
###### v.1.0.7:
Critical bug fixes, pylint
###### v.1.0.6:
Add AsyncSql, start working on dict actions
###### v.1.0.5:
Double check mypy problems and resolve them
###### v.1.0.4:
Fix all mypy stub issues
###### v.1.0.3:
Provide a mypy stub file
###### v.1.0.2:
Fix internal vars
###### v.1.0.1:
Actual release
###### v.1.0.0:
Initial Release!
###### v.1.0.26:
Mistake release :facepalm:
