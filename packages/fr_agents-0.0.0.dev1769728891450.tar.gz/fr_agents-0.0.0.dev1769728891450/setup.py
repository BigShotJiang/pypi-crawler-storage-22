from distutils.core import setup

setup(
    name='fr_agents',
    version='0.0.0.dev1769728891450',
    py_modules=["module"],
)