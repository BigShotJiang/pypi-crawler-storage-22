"""Snapshot data provider for algorithm runtime."""
