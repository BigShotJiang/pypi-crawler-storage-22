"""Workbench UI packaged with the Fraclab SDK."""

# Export a helper so callers can invoke programmatically without the CLI.
from fraclab_sdk.workbench.__main__ import main as run_workbench  # noqa: F401
