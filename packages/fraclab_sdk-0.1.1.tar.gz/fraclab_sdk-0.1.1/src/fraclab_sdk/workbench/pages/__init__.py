"""Streamlit multipage registry for the workbench."""
