"""Anonymization strategy tests."""
