"""Tests for tenant isolation linting."""
