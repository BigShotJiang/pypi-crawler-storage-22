# ruff: noqa
from framework_m_standard.adapters.auth.local_identity import *
import sys

sys.modules[__name__] = sys.modules["framework_m_standard.adapters.auth.local_identity"]
