# ruff: noqa
from framework_m_standard.adapters.events.nats_event_bus import *
import sys

sys.modules[__name__] = sys.modules[
    "framework_m_standard.adapters.events.nats_event_bus"
]
