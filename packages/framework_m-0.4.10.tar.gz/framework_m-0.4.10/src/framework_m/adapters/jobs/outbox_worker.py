# ruff: noqa
from framework_m_standard.adapters.jobs.outbox_worker import *
import sys

sys.modules[__name__] = sys.modules["framework_m_standard.adapters.jobs.outbox_worker"]
