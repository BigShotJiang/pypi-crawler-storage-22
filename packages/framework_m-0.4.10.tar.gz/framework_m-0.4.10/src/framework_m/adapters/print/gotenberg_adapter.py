# ruff: noqa
from framework_m_standard.adapters.print.gotenberg_adapter import *
import sys

sys.modules[__name__] = sys.modules[
    "framework_m_standard.adapters.print.gotenberg_adapter"
]
