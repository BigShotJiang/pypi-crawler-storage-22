# ruff: noqa
from framework_m_standard.adapters.storage import *
import sys

sys.modules[__name__] = sys.modules["framework_m_standard.adapters.storage"]
