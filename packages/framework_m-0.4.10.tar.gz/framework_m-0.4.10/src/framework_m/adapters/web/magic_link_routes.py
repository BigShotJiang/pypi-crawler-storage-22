# ruff: noqa
from framework_m_standard.adapters.web.magic_link_routes import *
import sys

sys.modules[__name__] = sys.modules[
    "framework_m_standard.adapters.web.magic_link_routes"
]
