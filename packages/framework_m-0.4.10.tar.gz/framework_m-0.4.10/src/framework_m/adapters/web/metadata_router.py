# ruff: noqa
from framework_m_standard.adapters.web.metadata_router import *
import sys

sys.modules[__name__] = sys.modules["framework_m_standard.adapters.web.metadata_router"]
