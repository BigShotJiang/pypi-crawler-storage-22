# ruff: noqa
from framework_m_standard.adapters.web.middleware import *
import sys

sys.modules[__name__] = sys.modules["framework_m_standard.adapters.web.middleware"]
