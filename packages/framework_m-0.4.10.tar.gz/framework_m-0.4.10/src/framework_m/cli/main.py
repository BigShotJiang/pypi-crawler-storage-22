from framework_m_core.cli.main import app

if __name__ == "__main__":
    app()
