# ruff: noqa: F403
from framework_m_core.doctypes import *
