# ruff: noqa
from framework_m_core.doctypes.activity_log import *
import sys

sys.modules[__name__] = sys.modules["framework_m_core.doctypes.activity_log"]
