# ruff: noqa
from framework_m_core.doctypes.email_queue import *
import sys

sys.modules[__name__] = sys.modules["framework_m_core.doctypes.email_queue"]
