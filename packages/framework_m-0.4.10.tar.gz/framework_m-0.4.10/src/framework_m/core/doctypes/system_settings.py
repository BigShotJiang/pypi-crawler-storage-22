# ruff: noqa
from framework_m_core.doctypes.system_settings import *
import sys

sys.modules[__name__] = sys.modules["framework_m_core.doctypes.system_settings"]
