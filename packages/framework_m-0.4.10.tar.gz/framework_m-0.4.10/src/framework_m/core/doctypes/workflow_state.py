# ruff: noqa
from framework_m_core.doctypes.workflow_state import *
import sys

sys.modules[__name__] = sys.modules["framework_m_core.doctypes.workflow_state"]
