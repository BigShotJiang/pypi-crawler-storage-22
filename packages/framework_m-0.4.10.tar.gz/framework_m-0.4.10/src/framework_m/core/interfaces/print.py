# ruff: noqa
from framework_m_core.interfaces.print import *
import sys

sys.modules[__name__] = sys.modules["framework_m_core.interfaces.print"]
