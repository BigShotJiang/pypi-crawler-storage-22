# ruff: noqa
from framework_m_core.interfaces.socket import *
import sys

sys.modules[__name__] = sys.modules["framework_m_core.interfaces.socket"]
