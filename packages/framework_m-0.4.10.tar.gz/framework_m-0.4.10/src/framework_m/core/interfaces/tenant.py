# ruff: noqa
from framework_m_core.interfaces.tenant import *
import sys

sys.modules[__name__] = sys.modules["framework_m_core.interfaces.tenant"]
