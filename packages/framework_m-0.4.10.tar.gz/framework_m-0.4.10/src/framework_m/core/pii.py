# ruff: noqa
from framework_m_core.pii import *
import sys

sys.modules[__name__] = sys.modules["framework_m_core.pii"]
