/**
 * Framework M Desk - Main Application
 *
 * Minimal Refine setup for Framework M backend.
 * Customize this file to add your own routes and resources.
 */

import { Refine } from "@refinedev/core";
import routerProvider from "@refinedev/react-router";
import { BrowserRouter, Route, Routes } from "react-router-dom";

import {
  authProvider,
  frameworkMDataProvider,
  liveProvider,
} from "@framework-m/desk";

/**
 * Example: Simple Dashboard component
 */
function Dashboard() {
  return (
    <div>
      <h1>Framework M Desk</h1>
      <p>Welcome! Your custom Desk UI is running.</p>
      <p>
        Edit <code>src/App.tsx</code> to add your resources and routes.
      </p>
    </div>
  );
}

/**
 * Example: Simple Login component
 */
function Login() {
  return (
    <div>
      <h1>Login</h1>
      <form
        onSubmit={async e => {
          e.preventDefault();
          const formData = new FormData(e.currentTarget);
          const result = await authProvider.login?.({
            email: formData.get("email") as string,
            password: formData.get("password") as string,
          });
          if (result?.success) {
            window.location.href = "/";
          } else {
            alert(result?.error?.message || "Login failed");
          }
        }}
      >
        <input name="email" type="email" placeholder="Email" required />
        <input
          name="password"
          type="password"
          placeholder="Password"
          required
        />
        <button type="submit">Login</button>
      </form>
    </div>
  );
}

/**
 * Main App Component
 *
 * Note: When deployed, the app is served at /desk/ path.
 * In development with Vite, it's served at root (/).
 * React Router handles both scenarios automatically.
 */
export function App() {
  return (
    <BrowserRouter>
      <Refine
        dataProvider={frameworkMDataProvider}
        authProvider={authProvider}
        liveProvider={liveProvider}
        routerProvider={routerProvider}
        options={{
          liveMode: "auto", // Enable real-time updates
          syncWithLocation: true,
        }}
        resources={
          [
            // Example: Add your DocTypes as resources
            // {
            //   name: "User",
            //   list: "/users",
            //   create: "/users/create",
            //   edit: "/users/edit/:id",
            //   show: "/users/show/:id",
            // },
          ]
        }
      >
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/login" element={<Login />} />
          {/* Add your custom routes here */}
        </Routes>
      </Refine>
    </BrowserRouter>
  );
}
