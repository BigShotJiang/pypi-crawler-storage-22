"""Core module - Domain logic and interfaces."""

import importlib.metadata

from framework_m_core.container import Container
from framework_m_core.domain.base_doctype import BaseDocType as DocType
from framework_m_core.domain.base_doctype import Field
from framework_m_core.interfaces.base_doctype import BaseDocTypeProtocol
from framework_m_core.interfaces.bootstrap import BootstrapProtocol
from framework_m_core.interfaces.controller import BaseControllerProtocol
from framework_m_core.interfaces.schema_mapper import SchemaMapperProtocol
from framework_m_core.registry import MetaRegistry

try:
    __version__ = importlib.metadata.version("framework-m-core")
except importlib.metadata.PackageNotFoundError:
    __version__ = "0.0.0"

__all__ = [
    "BaseControllerProtocol",
    "BaseDocTypeProtocol",
    "BootstrapProtocol",
    "Container",
    "DocType",
    "Field",
    "MetaRegistry",
    "SchemaMapperProtocol",
    "__version__",
]
