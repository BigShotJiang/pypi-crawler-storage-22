"""Configuration Management CLI Commands.

This module provides CLI commands for managing Framework M configuration:
- m config:show: Display current configuration
- m config:set <key> <value>: Update configuration value

Usage:
    m config:show                 # Show all config
    m config:set framework.name myapp
"""

from __future__ import annotations

from pathlib import Path
from typing import Annotated, Any

import cyclopts

from framework_m_core.config import (
    CONFIG_FILE_NAME,
    DEFAULT_CONFIG,
    find_config_file,
    format_config,
    get_nested_value,
    load_config,
    save_config,
    set_nested_value,
)

# =============================================================================
# CLI Commands
# =============================================================================


def config_show_command(
    key: Annotated[
        str | None,
        cyclopts.Parameter(help="Specific key to show (e.g., framework.name)"),
    ] = None,
    config_file: Annotated[
        Path | None,
        cyclopts.Parameter(name="--config", help="Path to config file"),
    ] = None,
) -> None:
    """Display current configuration.

    Shows the current Framework M configuration from framework_config.toml.

    Examples:
        m config:show                    # Show all config
        m config:show framework.name     # Show specific key
    """
    config_path = config_file or find_config_file()
    config = load_config(config_path)

    if not config:
        print(f"No config found at: {config_path}")
        print()
        print("Create a config file with default values:")
        print("  m config:set framework.name myapp")
        return

    print(f"Config file: {config_path}")
    print()

    if key:
        value = get_nested_value(config, key)
        if value is not None:
            print(f"{key} = {value}")
        else:
            print(f"Key not found: {key}")
            raise SystemExit(1)
    else:
        print(format_config(config))


def config_set_command(
    key: Annotated[str, cyclopts.Parameter(help="Key to set (e.g., framework.name)")],
    value: Annotated[str, cyclopts.Parameter(help="Value to set")],
    config_file: Annotated[
        Path | None,
        cyclopts.Parameter(name="--config", help="Path to config file"),
    ] = None,
) -> None:
    """Set a configuration value.

    Updates a value in framework_config.toml, creating the file if needed.

    Examples:
        m config:set framework.name myapp
        m config:set apps.installed "myapp,otherapp"
    """
    config_path = config_file or find_config_file()
    config = load_config(config_path) or DEFAULT_CONFIG.copy()

    # Parse value (handle lists)
    if "," in value:
        parsed_value: Any = [v.strip() for v in value.split(",")]
    else:
        parsed_value = value

    old_value = get_nested_value(config, key)
    set_nested_value(config, key, parsed_value)

    save_config(config_path, config)

    print(f"Config file: {config_path}")
    print()
    if old_value is not None:
        print(f"  {key}: {old_value} -> {parsed_value}")
    else:
        print(f"  {key} = {parsed_value}")
    print()
    print("✓ Configuration updated")


__all__ = [
    "CONFIG_FILE_NAME",
    "DEFAULT_CONFIG",
    "config_set_command",
    "config_show_command",
    "find_config_file",
    "format_config",
    "get_nested_value",
    "load_config",
    "save_config",
    "set_nested_value",
]
