import cyclopts

from framework_m_core import __version__
from framework_m_core.cli.config import config_set_command, config_show_command
from framework_m_core.cli.plugin_loader import load_plugins
from framework_m_core.cli.utility import info_command

app = cyclopts.App(
    name="m",
    version=__version__,
    help="Framework M CLI",
)

# Register core commands
app.command(info_command, name="info")

# Config commands
app.command(config_show_command, name="config:show")
app.command(config_set_command, name="config:set")

# Load plugins
load_plugins(app)


def main() -> None:
    app()


if __name__ == "__main__":
    main()
