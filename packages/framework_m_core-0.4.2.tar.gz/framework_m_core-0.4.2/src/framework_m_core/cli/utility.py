"""Utility commands for Framework M CLI."""

from __future__ import annotations

import platform
import sys
from typing import Annotated

import cyclopts
from rich.console import Console
from rich.table import Table

from framework_m_core import __version__

console = Console()


def get_python_version() -> str:
    """Get Python version string."""
    return platform.python_version()


def get_framework_version() -> str:
    """Get Framework M version string."""
    return __version__


def get_pythonpath() -> str:
    """Get PYTHONPATH."""
    return sys.path[0]


def info_command(
    verbose: Annotated[
        bool, cyclopts.Parameter(name="--verbose", help="Show detailed info")
    ] = False,
) -> None:
    """Show system and framework information."""
    table = Table(title="Framework M Information")
    table.add_column("Key", style="cyan")
    table.add_column("Value", style="green")

    table.add_row("Framework M", get_framework_version())
    table.add_row("Python", get_python_version())

    if verbose:
        table.add_row("Platform", platform.platform())
        table.add_row("Services", "None (Mock)")

    console.print(table)


__all__ = [
    "get_framework_version",
    "get_python_version",
    "get_pythonpath",
    "info_command",
]
