"""Core Configuration Management.

This module provides utilities for finding and loading the framework configuration.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

# Default config file name
CONFIG_FILE_NAME = "framework_config.toml"

# Default config structure
DEFAULT_CONFIG = {
    "framework": {
        "name": "my_app",
        "version": "0.1.0",
    },
    "apps": {
        "installed": [],
    },
}


def find_config_file() -> Path:
    """Find the config file in current directory or parents.

    Returns:
        Path to config file (may not exist)
    """
    for path in [Path.cwd(), *Path.cwd().parents]:
        config_path = path / CONFIG_FILE_NAME
        if config_path.exists():
            return config_path

    # Default to cwd if not found
    return Path.cwd() / CONFIG_FILE_NAME


def load_config(config_path: Path | None = None) -> dict[str, Any]:
    """Load configuration from TOML file.

    Args:
        config_path: Path to config file (auto-detect if None)

    Returns:
        Configuration dict
    """
    if config_path is None:
        config_path = find_config_file()

    if not config_path.exists():
        return {}

    try:
        import tomllib

        return tomllib.loads(config_path.read_text())
    except Exception:
        return {}


def get_nested_value(config: dict[str, Any], key: str) -> Any | None:
    """Get a nested value from config using dot notation.

    Args:
        config: Configuration dict
        key: Dot-separated key (e.g., "framework.name")

    Returns:
        Value or None if not found
    """
    parts = key.split(".")
    current = config

    for part in parts:
        if isinstance(current, dict) and part in current:
            current = current[part]
        else:
            return None

    return current


def set_nested_value(config: dict[str, Any], key: str, value: Any) -> None:
    """Set a nested value in config using dot notation.

    Args:
        config: Configuration dict to modify
        key: Dot-separated key (e.g., "framework.name")
        value: Value to set
    """
    parts = key.split(".")
    current = config

    # Navigate/create nested dicts
    for part in parts[:-1]:
        if part not in current:
            current[part] = {}
        current = current[part]

    # Set the final value
    current[parts[-1]] = value


def save_config(config_path: Path, config: dict[str, Any]) -> None:
    """Save configuration to TOML file.

    Args:
        config_path: Path to config file
        config: Configuration dict to save
    """
    # Simple TOML writing (no external dependencies)
    lines: list[str] = []
    for section, values in config.items():
        lines.append(f"[{section}]")
        if isinstance(values, dict):
            for key, value in values.items():
                if isinstance(value, str):
                    lines.append(f'{key} = "{value}"')
                elif isinstance(value, list):
                    items = ", ".join(f'"{v}"' for v in value)
                    lines.append(f"{key} = [{items}]")
                elif isinstance(value, bool):
                    lines.append(f"{key} = {str(value).lower()}")
                elif isinstance(value, (int, float)):
                    lines.append(f"{key} = {value}")
                else:
                    lines.append(f'{key} = "{value}"')
        lines.append("")

    config_path.write_text("\n".join(lines))


def format_config(config: dict[str, Any], indent: int = 0) -> str:
    """Format config dict for display.

    Args:
        config: Configuration dict
        indent: Indentation level

    Returns:
        Formatted string
    """
    lines = []
    prefix = "  " * indent

    for key, value in config.items():
        if isinstance(value, dict):
            lines.append(f"{prefix}[{key}]")
            lines.append(format_config(value, indent + 1))
        elif isinstance(value, list):
            items = ", ".join(str(v) for v in value)
            lines.append(f"{prefix}{key} = [{items}]")
        else:
            lines.append(f"{prefix}{key} = {value}")

    return "\n".join(lines)


__all__ = [
    "CONFIG_FILE_NAME",
    "DEFAULT_CONFIG",
    "find_config_file",
    "format_config",
    "get_nested_value",
    "load_config",
    "save_config",
    "set_nested_value",
]
