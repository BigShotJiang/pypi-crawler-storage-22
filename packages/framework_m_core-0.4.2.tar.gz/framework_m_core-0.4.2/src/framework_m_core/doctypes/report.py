"""Report DocType - CQRS reporting configuration.

Stores report configurations that define scalable reporting
capabilities from indie (Code Reports) to enterprise (Analytics).

Example:
    # Create a code report for indie mode
    report = Report(
        name="profit_and_loss",
        report_type="Code Report",
        query="reports/profit_and_loss.sql",
    )

    # Create an analytics report for enterprise mode
    report = Report(
        name="sales_dashboard",
        report_type="Analytics Report",
        data_source="ClickHouse",
        query="SELECT date, sum(amount) FROM sales_events GROUP BY date",
    )
"""

from __future__ import annotations

from typing import ClassVar

from pydantic import Field

from framework_m_core.domain.base_doctype import BaseDocType


class Report(BaseDocType):
    """CQRS report configuration.

    Defines reports that support zero-cliff scalability from
    startup (Code Reports) to enterprise (Analytics with OLAP).

    Attributes:
        name: Unique report identifier
        report_type: Report execution mode (Code Report or Analytics Report)
        data_source: Data source adapter (SQL, Elastic, ClickHouse)
        query: Report query (SQL file path, SQL query, or Elastic DSL)
        enabled: Whether the report is active
    """

    # Report identification
    name: str = Field(
        ...,
        description="Unique report identifier",
        min_length=1,
        max_length=255,
    )

    # Report type (Zero-cliff scalability)
    report_type: str = Field(
        ...,
        description="Report execution mode: 'Code Report' (indie) or 'Analytics Report' (enterprise)",
    )

    # Data source configuration
    data_source: str | None = Field(
        default=None,
        description="Data source adapter: SQL, Elastic, ClickHouse (for Analytics Reports)",
    )

    # Query configuration
    query: str | None = Field(
        default=None,
        description="Report query: SQL file path, SQL query, or Elastic DSL JSON",
    )

    # Status
    enabled: bool = Field(
        default=True,
        description="Whether the report is active",
    )

    class Meta:
        """DocType metadata configuration."""

        # Authentication and authorization
        requires_auth: ClassVar[bool] = True
        apply_rls: ClassVar[bool] = True

        # Permissions (reports can be sensitive)
        permissions: ClassVar[dict[str, list[str]]] = {
            "read": ["Employee", "Manager", "Admin"],
            "write": ["Manager", "Admin"],
            "create": ["Manager", "Admin"],
            "delete": ["Admin"],
        }


__all__ = ["Report"]
