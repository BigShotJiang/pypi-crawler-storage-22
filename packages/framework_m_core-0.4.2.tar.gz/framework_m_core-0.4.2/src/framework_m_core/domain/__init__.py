"""Framework M Core - Domain Package."""
