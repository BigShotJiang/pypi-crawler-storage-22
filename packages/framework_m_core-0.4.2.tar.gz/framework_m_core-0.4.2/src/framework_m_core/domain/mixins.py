"""Mixins - Reusable components for DocTypes.

This module provides mixins that add common functionality to DocTypes:
- SubmittableMixin: For documents with workflow states (draft/submitted/cancelled)
- BlameMixin: Adds ownership and tracking fields (owner, modified_by, etc.)
- NestedSetMixin: Adds nested set path fields for tree structures
- StatusMixin: Adds standard status field
- TimelineMixin: Adds timeline/comment support
"""

from datetime import UTC, datetime
from enum import IntEnum
from typing import ClassVar

from pydantic import Field


def _utc_now() -> datetime:
    """Return current UTC time as timezone-aware datetime."""
    return datetime.now(UTC)


class DocStatus(IntEnum):
    """Document status for submittable DocTypes.

    Follows the standard workflow:
    DRAFT (0) -> SUBMITTED (1) -> CANCELLED (2)

    Submitted documents are immutable. Cancelled documents can be amended
    to create a new draft.
    """

    DRAFT = 0
    SUBMITTED = 1
    CANCELLED = 2


class SubmittableMixin:
    """
    Mixin for DocTypes that support submit/cancel workflow.

    Add this mixin to DocTypes that need to be "submitted" (locked)
    after approval and can be "cancelled" later.

    Example:
        class Invoice(DocType, SubmittableMixin):
            customer: str
            total: float

        invoice = Invoice(customer="Acme Corp", total=1000)
        invoice.can_edit()  # True (draft)

        invoice.docstatus = DocStatus.SUBMITTED
        invoice.can_edit()  # False (submitted)
    """

    docstatus: DocStatus = Field(default=DocStatus.DRAFT)

    def is_submitted(self) -> bool:
        """Check if document is in submitted state."""
        return self.docstatus == DocStatus.SUBMITTED

    def is_cancelled(self) -> bool:
        """Check if document is in cancelled state."""
        return self.docstatus == DocStatus.CANCELLED

    def can_edit(self) -> bool:
        """
        Check if document can be edited.

        Only draft documents can be edited. Submitted and cancelled
        documents are immutable.
        """
        return self.docstatus == DocStatus.DRAFT


class BlameMixin:
    """
    Mixin for tracking ownership and modification history.

    Included by default in BaseDocType, but available as mixin for
    other Pydantic models that need tracking.
    """

    owner: str | None = Field(default=None, description="User who created the document")
    modified_by: str | None = Field(
        default=None, description="User who last modified the document"
    )
    creation: datetime = Field(
        default_factory=_utc_now, description="Document creation timestamp"
    )
    modified: datetime = Field(
        default_factory=_utc_now, description="Last modification timestamp"
    )


class NestedSetMixin:
    """
    Mixin for tree-structured documents using Nested Set Model.
    """

    lft: int = Field(default=0, description="Left bound")
    rgt: int = Field(default=0, description="Right bound")
    is_group: bool = Field(default=False, description="Is a group node")
    parent_value: str | None = Field(default=None, description="Parent document name")


class StatusMixin:
    """
    Mixin for documents with a simple status field.
    """

    status: str = Field(default="Draft", description="Document status")


class TimelineMixin:
    """
    Mixin for documents that show a timeline of activity.
    """

    _timeline_enabled: ClassVar[bool] = True


__all__ = [
    "BlameMixin",
    "DocStatus",
    "NestedSetMixin",
    "StatusMixin",
    "SubmittableMixin",
    "TimelineMixin",
]
