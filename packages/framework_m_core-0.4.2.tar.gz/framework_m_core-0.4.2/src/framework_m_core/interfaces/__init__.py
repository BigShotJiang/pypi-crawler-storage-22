"""Framework M Core - Interfaces Package."""

from framework_m_core.interfaces.base_doctype import BaseDocTypeProtocol
from framework_m_core.interfaces.bootstrap import BootstrapProtocol
from framework_m_core.interfaces.controller import BaseControllerProtocol
from framework_m_core.interfaces.identity import (
    Credentials,
    IdentityProtocol,
    PasswordCredentials,
    Token,
)
from framework_m_core.interfaces.schema_mapper import SchemaMapperProtocol

__all__ = [
    "BaseControllerProtocol",
    "BaseDocTypeProtocol",
    "BootstrapProtocol",
    "Credentials",
    "IdentityProtocol",
    "PasswordCredentials",
    "SchemaMapperProtocol",
    "Token",
]
