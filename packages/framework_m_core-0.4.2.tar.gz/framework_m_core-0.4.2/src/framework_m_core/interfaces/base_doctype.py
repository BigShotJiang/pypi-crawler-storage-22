"""BaseDocType Protocol - Core interface for all document types.

This module defines the BaseDocTypeProtocol which is the minimal interface
that all DocTypes must implement in the hexagonal architecture.

Unlike the concrete BaseDocType class in domain/, this is a pure Protocol.
MX packages (MongoDB, Cassandra, etc.) can provide their own BaseDocType
implementations as long as they satisfy this protocol.
"""

from datetime import datetime
from typing import Protocol, runtime_checkable
from uuid import UUID


@runtime_checkable
class BaseDocTypeProtocol(Protocol):
    """
    Protocol defining the minimal interface for all DocTypes.

    This is the core contract that all document types must satisfy.
    MX packages can provide their own implementations with additional fields.

    Required fields:
        id: Unique identifier (UUID)
        name: Human-readable identifier (optional)
        creation: Creation timestamp
        modified: Last modification timestamp

    Example - Standard implementation:
        class Todo(BaseDocType):  # BaseDocType implements BaseDocTypeProtocol
            title: str
            is_completed: bool = False

    Example - MX custom implementation:
        class MongoDocType(BaseModel):  # Custom base for MongoDB MX
            id: UUID
            name: str | None
            creation: datetime
            modified: datetime
            _id: ObjectId  # MongoDB-specific field

        class Task(MongoDocType):  # Satisfies BaseDocTypeProtocol
            title: str
            done: bool = False
    """

    id: UUID
    name: str | None
    creation: datetime
    modified: datetime


__all__ = ["BaseDocTypeProtocol"]
