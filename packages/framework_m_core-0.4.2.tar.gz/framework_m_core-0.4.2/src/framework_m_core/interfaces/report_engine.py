"""Report Engine Protocol - Core interface for scalable reporting.

This module defines the ReportEngineProtocol for executing reports
across different data sources (SQL, Elastic, ClickHouse) with
zero-cliff scalability from indie to enterprise.

The framework supports:
- Code Reports: SQL files or Python classes (indie mode)
- Analytics Reports: OLAP queries on read models (enterprise mode)

Example flow:
    1. Report DocType defines query and data source
    2. ReportEngine adapter executes query
    3. Returns structured ReportResult
"""

from typing import Any, Protocol

from pydantic import BaseModel


class ReportResult(BaseModel):
    """Result container for report execution.

    Wraps report results with metadata for rendering and processing.

    Attributes:
        rows: List of result rows as dictionaries
        columns: Optional list of column names
        metadata: Optional metadata (execution time, data source, etc.)
    """

    rows: list[dict[str, Any]]
    columns: list[str] | None = None
    metadata: dict[str, Any] | None = None


class ReportEngineProtocol(Protocol):
    """Protocol defining the contract for report engine implementations.

    Report engines execute queries against various data sources
    and return structured results for display or export.

    Key concepts:
    - **Execute**: Run a query and return results
    - **Validate**: Check query syntax before execution
    - **Zero-cliff**: Same protocol for SQL, Elastic, ClickHouse

    Implementations:
    - SQLReportEngine: Executes SQL queries
    - ElasticReportEngine: Executes Elasticsearch DSL
    - ClickHouseReportEngine: Executes ClickHouse OLAP queries
    """

    async def execute(
        self,
        query: str,
        parameters: dict[str, Any] | None = None,
    ) -> ReportResult:
        """Execute a report query and return results.

        Args:
            query: The query string (SQL, Elastic DSL JSON, etc.)
            parameters: Optional query parameters for parameterized queries

        Returns:
            ReportResult containing rows and metadata

        Raises:
            QueryExecutionError: If query execution fails
            ValidationError: If query is invalid
        """
        ...

    async def validate(self, query: str) -> bool:
        """Validate query syntax without executing.

        Args:
            query: The query string to validate

        Returns:
            True if query is syntactically valid, False otherwise
        """
        ...


__all__ = [
    "ReportEngineProtocol",
    "ReportResult",
]
