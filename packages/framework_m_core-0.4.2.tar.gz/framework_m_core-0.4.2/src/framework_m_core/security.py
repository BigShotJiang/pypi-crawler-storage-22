"""Security Utilities - Password hashing and verification.

This module provides utilities for secure password management using Argon2.
"""

from __future__ import annotations

from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError

# Password hasher instance (singleton)
_password_hasher = PasswordHasher()


def hash_password(password: str) -> str:
    """Hash a password using argon2id.

    Args:
        password: Plain-text password to hash

    Returns:
        Argon2-formatted hash string
    """
    return _password_hasher.hash(password)


def verify_password(password: str, hash: str) -> bool:
    """Verify a password against its hash.

    Args:
        password: Plain-text password to verify
        hash: Argon2 hash to verify against

    Returns:
        True if password matches, False otherwise
    """
    try:
        _password_hasher.verify(hash, password)
        return True
    except VerifyMismatchError:
        return False


__all__ = ["hash_password", "verify_password"]
