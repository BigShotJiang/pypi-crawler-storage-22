"""Tests for CLI main entry point.

This module tests the main CLI application including:
- Version flag
- Help documentation
- Command registration
- Plugin loading integration
"""

from __future__ import annotations

import subprocess
import sys

import framework_m_core


class TestVersionCommand:
    """Tests for --version flag."""

    def test_version_flag_outputs_version(self) -> None:
        """--version should output the framework version."""
        result = subprocess.run(
            [sys.executable, "-m", "framework_m_core.cli.main", "--version"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert framework_m_core.__version__ in result.stdout

    def test_help_flag(self) -> None:
        """--help should show help text."""
        result = subprocess.run(
            [sys.executable, "-m", "framework_m_core.cli.main", "--help"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "Framework M CLI" in result.stdout


class TestCoreCommands:
    """Tests for core CLI commands."""

    def test_info_command(self) -> None:
        """info command should show version and Python info."""
        result = subprocess.run(
            [sys.executable, "-m", "framework_m_core.cli.main", "info"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert framework_m_core.__version__ in result.stdout
        assert "Python" in result.stdout
