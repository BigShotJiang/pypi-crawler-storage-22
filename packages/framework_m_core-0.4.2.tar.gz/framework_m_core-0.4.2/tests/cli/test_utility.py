"""Tests for Utility CLI Commands - Comprehensive Coverage."""

from __future__ import annotations

import subprocess
import sys

import pytest


class TestUtilityImport:
    """Tests for utility module imports."""

    def test_import_info_command(self) -> None:
        """info_command should be importable."""
        from framework_m_core.cli.utility import info_command

        assert info_command is not None


class TestVersionFunctions:
    """Tests for version helper functions."""

    def test_get_python_version(self) -> None:
        """get_python_version should return version string."""
        from framework_m_core.cli.utility import get_python_version

        result = get_python_version()
        assert isinstance(result, str)
        assert "." in result

    def test_get_framework_version(self) -> None:
        """get_framework_version should return version string."""
        from framework_m_core.cli.utility import get_framework_version

        result = get_framework_version()
        assert isinstance(result, str)


class TestGetPythonPath:
    """Tests for get_pythonpath function."""

    def test_get_pythonpath_returns_string(self) -> None:
        """get_pythonpath should return a string."""
        from framework_m_core.cli.utility import get_pythonpath

        result = get_pythonpath()
        assert isinstance(result, str)


class TestInfoCommand:
    """Tests for info_command function."""

    def test_info_command_is_callable(self) -> None:
        """info_command should be callable."""
        from framework_m_core.cli.utility import info_command

        assert callable(info_command)

    def test_info_command_basic(self, capsys: pytest.CaptureFixture[str]) -> None:
        """info_command should display system info."""
        from framework_m_core.cli.utility import info_command

        info_command(verbose=False)

        captured = capsys.readouterr()
        assert "Framework M" in captured.out
        assert "Python" in captured.out

    def test_info_command_verbose(self, capsys: pytest.CaptureFixture[str]) -> None:
        """info_command with verbose should show more info."""
        from framework_m_core.cli.utility import info_command

        info_command(verbose=True)

        captured = capsys.readouterr()
        assert "Platform" in captured.out
        assert "Services" in captured.out


class TestCommandExecution:
    """Tests for command execution."""

    def test_info_help(self) -> None:
        """info --help should work."""
        result = subprocess.run(
            [sys.executable, "-m", "framework_m_core.cli.main", "info", "--help"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0


class TestUtilityExports:
    """Tests for utility module exports."""

    def test_all_exports(self) -> None:
        """utility module should export expected items."""
        from framework_m_core.cli import utility

        assert "info_command" in utility.__all__
