from typing import Any

import pytest
from framework_m_core import DocType, Field
from framework_m_core.container import Container
from framework_m_core.domain.base_controller import BaseController
from framework_m_core.registry import MetaRegistry


class TestTodo(DocType):
    """Sample Todo DocType for testing."""

    title: str = Field(description="Task title")
    is_completed: bool = False
    priority: int = 1


class TestTodoController(BaseController[TestTodo]):
    """Sample controller for TestTodo."""

    async def validate(self, context: Any = None) -> None:
        """Validate todo has non-empty title."""
        if not self.doc.title.strip():
            raise ValueError("Title cannot be empty")


@pytest.fixture
def sample_todo() -> TestTodo:
    """Create a sample TestTodo instance."""
    return TestTodo(
        title="Test Task",
        is_completed=False,
        priority=1,
        name="TODO-001",
        owner="test@example.com",
    )


@pytest.fixture
def sample_todo_controller(sample_todo: TestTodo) -> TestTodoController:
    """Create a sample TestTodoController instance."""
    return TestTodoController(sample_todo)


@pytest.fixture
def container() -> Container:
    """Create a fresh Container instance for testing."""
    return Container()


@pytest.fixture
def clean_registry() -> MetaRegistry:
    """Get a clean MetaRegistry instance for testing."""
    registry = MetaRegistry()
    registry.clear()
    return registry
