"""Tests for Report DocType."""

# =============================================================================
# Test: Report DocType Import
# =============================================================================


class TestReportImport:
    """Tests for Report DocType import."""

    def test_import_report(self) -> None:
        """Report should be importable from doctypes."""
        from framework_m_core.doctypes.report import Report

        assert Report is not None

    def test_report_in_all_exports(self) -> None:
        """Report should be in __all__."""
        from framework_m_core.doctypes import report

        assert "Report" in report.__all__


# =============================================================================
# Test: Report Creation
# =============================================================================


class TestReportCreation:
    """Tests for Report DocType creation."""

    def test_create_report_with_required_fields(self) -> None:
        """Report should be creatable with required fields."""
        from framework_m_core.doctypes.report import Report

        report = Report(
            name="sales_report",
            report_type="Code Report",
        )

        assert report.name == "sales_report"
        assert report.report_type == "Code Report"

    def test_report_type_code_report(self) -> None:
        """Report should accept 'Code Report' type."""
        from framework_m_core.doctypes.report import Report

        report = Report(
            name="inventory_report",
            report_type="Code Report",
        )

        assert report.report_type == "Code Report"

    def test_report_type_analytics_report(self) -> None:
        """Report should accept 'Analytics Report' type."""
        from framework_m_core.doctypes.report import Report

        report = Report(
            name="sales_analytics",
            report_type="Analytics Report",
        )

        assert report.report_type == "Analytics Report"

    def test_report_with_data_source_sql(self) -> None:
        """Report should accept SQL data source."""
        from framework_m_core.doctypes.report import Report

        report = Report(
            name="customer_report",
            report_type="Analytics Report",
            data_source="SQL",
        )

        assert report.data_source == "SQL"

    def test_report_with_data_source_elastic(self) -> None:
        """Report should accept Elastic data source."""
        from framework_m_core.doctypes.report import Report

        report = Report(
            name="log_analytics",
            report_type="Analytics Report",
            data_source="Elastic",
        )

        assert report.data_source == "Elastic"

    def test_report_with_data_source_clickhouse(self) -> None:
        """Report should accept ClickHouse data source."""
        from framework_m_core.doctypes.report import Report

        report = Report(
            name="event_analytics",
            report_type="Analytics Report",
            data_source="ClickHouse",
        )

        assert report.data_source == "ClickHouse"

    def test_report_data_source_defaults_to_none(self) -> None:
        """Report data_source should default to None for Code Reports."""
        from framework_m_core.doctypes.report import Report

        report = Report(
            name="custom_report",
            report_type="Code Report",
        )

        assert report.data_source is None

    def test_report_with_query(self) -> None:
        """Report should accept a query string."""
        from framework_m_core.doctypes.report import Report

        query = "SELECT * FROM customers WHERE status = 'active'"
        report = Report(
            name="active_customers",
            report_type="Analytics Report",
            data_source="SQL",
            query=query,
        )

        assert report.query == query

    def test_report_query_defaults_to_none(self) -> None:
        """Report query should default to None."""
        from framework_m_core.doctypes.report import Report

        report = Report(
            name="test_report",
            report_type="Code Report",
        )

        assert report.query is None

    def test_report_enabled_defaults_to_true(self) -> None:
        """Report enabled should default to True."""
        from framework_m_core.doctypes.report import Report

        report = Report(
            name="test_report",
            report_type="Code Report",
        )

        assert report.enabled is True


# =============================================================================
# Test: Report Phase 10 Fields (CQRS)
# =============================================================================


class TestReportPhase10Fields:
    """Tests for Phase 10 CQRS reporting fields."""

    def test_code_report_for_indie_mode(self) -> None:
        """Code Report should support indie mode with SQL file or Python class."""
        from framework_m_core.doctypes.report import Report

        report = Report(
            name="profit_and_loss",
            report_type="Code Report",
            query="reports/profit_and_loss.sql",
        )

        assert report.report_type == "Code Report"
        assert "profit_and_loss.sql" in report.query

    def test_analytics_report_for_enterprise_mode(self) -> None:
        """Analytics Report should support enterprise mode with OLAP."""
        from framework_m_core.doctypes.report import Report

        report = Report(
            name="sales_dashboard",
            report_type="Analytics Report",
            data_source="ClickHouse",
            query="SELECT date, sum(amount) FROM sales_events GROUP BY date",
        )

        assert report.report_type == "Analytics Report"
        assert report.data_source == "ClickHouse"
        assert "GROUP BY" in report.query

    def test_report_with_all_phase10_fields(self) -> None:
        """Report should accept all Phase 10 fields together."""
        from framework_m_core.doctypes.report import Report

        report = Report(
            name="customer_analytics",
            report_type="Analytics Report",
            data_source="Elastic",
            query='{"query": {"match": {"status": "active"}}}',
            enabled=True,
        )

        assert report.name == "customer_analytics"
        assert report.report_type == "Analytics Report"
        assert report.data_source == "Elastic"
        assert report.query is not None
        assert report.enabled is True
