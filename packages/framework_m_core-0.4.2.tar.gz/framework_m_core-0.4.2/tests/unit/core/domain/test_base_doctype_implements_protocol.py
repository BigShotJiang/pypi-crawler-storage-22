"""Tests verifying BaseDocType implements BaseDocTypeProtocol.

The concrete BaseDocType class should implement BaseDocTypeProtocol,
ensuring compatibility between the protocol and the standard implementation.
"""

from datetime import UTC, datetime
from uuid import uuid4


class TestBaseDocTypeImplementsProtocol:
    """Tests that the concrete BaseDocType class implements BaseDocTypeProtocol."""

    def test_base_doctype_satisfies_protocol(self) -> None:
        """BaseDocType should satisfy BaseDocTypeProtocol."""
        from framework_m_core.domain.base_doctype import BaseDocType
        from framework_m_core.interfaces.base_doctype import BaseDocTypeProtocol

        # Create instance
        class TestDoc(BaseDocType):
            pass

        doc = TestDoc()

        # Should satisfy protocol at runtime
        assert isinstance(doc, BaseDocTypeProtocol)

    def test_custom_doctype_satisfies_protocol(self) -> None:
        """Custom DocTypes inheriting from BaseDocType should satisfy the protocol."""
        from framework_m_core import DocType
        from framework_m_core.interfaces.base_doctype import BaseDocTypeProtocol

        class Todo(DocType):
            title: str = "Test"
            is_completed: bool = False

        todo = Todo()

        # Should satisfy protocol
        assert isinstance(todo, BaseDocTypeProtocol)

    def test_protocol_fields_accessible(self) -> None:
        """BaseDocType instances should have all protocol-required fields."""
        from framework_m_core.domain.base_doctype import BaseDocType

        class TestDoc(BaseDocType):
            pass

        doc = TestDoc()

        # All protocol fields should be accessible
        assert hasattr(doc, "id")
        assert hasattr(doc, "name")
        assert hasattr(doc, "creation")
        assert hasattr(doc, "modified")

        # Fields should have correct types
        from uuid import UUID

        assert isinstance(doc.id, UUID)
        assert doc.name is None or isinstance(doc.name, str)
        assert isinstance(doc.creation, datetime)
        assert isinstance(doc.modified, datetime)


class TestBaseDocTypeExtendsProtocol:
    """Tests that BaseDocType extends beyond the minimal protocol.

    The concrete BaseDocType provides additional fields beyond the protocol,
    which is allowed and expected for the standard implementation.
    """

    def test_base_doctype_has_additional_fields(self) -> None:
        """BaseDocType should have additional fields beyond the protocol."""
        from framework_m_core.domain.base_doctype import BaseDocType

        class TestDoc(BaseDocType):
            pass

        doc = TestDoc()

        # Protocol fields
        assert hasattr(doc, "id")
        assert hasattr(doc, "name")
        assert hasattr(doc, "creation")
        assert hasattr(doc, "modified")

        # Additional fields (framework-m-standard implementation)
        assert hasattr(doc, "modified_by")
        assert hasattr(doc, "owner")
        assert hasattr(doc, "deleted_at")

    def test_additional_fields_are_optional(self) -> None:
        """Additional fields in BaseDocType should be optional (not required by protocol)."""
        from framework_m_core.domain.base_doctype import BaseDocType

        class TestDoc(BaseDocType):
            pass

        doc = TestDoc()

        # Additional fields should default to None
        assert doc.modified_by is None
        assert doc.owner is None
        assert doc.deleted_at is None


class TestProtocolAllowsVariance:
    """Tests that different implementations can satisfy the protocol.

    This demonstrates the MX pattern - different packages can provide
    their own BaseDocType implementations.
    """

    def test_minimal_implementation_satisfies_protocol(self) -> None:
        """A minimal class with just protocol fields should satisfy it."""
        from datetime import datetime
        from uuid import UUID

        from framework_m_core.interfaces.base_doctype import BaseDocTypeProtocol
        from pydantic import BaseModel

        class MinimalDoc(BaseModel):
            id: UUID
            name: str | None
            creation: datetime
            modified: datetime

        doc = MinimalDoc(
            id=uuid4(),
            name="test",
            creation=datetime.now(UTC),
            modified=datetime.now(UTC),
        )

        assert isinstance(doc, BaseDocTypeProtocol)

    def test_extended_implementation_satisfies_protocol(self) -> None:
        """A class with additional fields beyond protocol should still satisfy it."""
        from datetime import datetime
        from uuid import UUID

        from framework_m_core.interfaces.base_doctype import BaseDocTypeProtocol
        from pydantic import BaseModel

        class ExtendedDoc(BaseModel):
            # Protocol fields
            id: UUID
            name: str | None
            creation: datetime
            modified: datetime
            # Additional fields
            tenant_id: str = "default"
            custom_field: int = 42

        doc = ExtendedDoc(
            id=uuid4(),
            name="test",
            creation=datetime.now(UTC),
            modified=datetime.now(UTC),
        )

        assert isinstance(doc, BaseDocTypeProtocol)
