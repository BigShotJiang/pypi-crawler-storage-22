"""Tests for BaseDocTypeProtocol.

The BaseDocTypeProtocol defines the minimal interface that all DocTypes must implement.
This allows MX packages to provide their own BaseDocType implementations.
"""

from datetime import datetime
from typing import Protocol, get_type_hints
from uuid import UUID


class TestBaseDocTypeProtocolExists:
    """Tests that BaseDocTypeProtocol is defined and importable."""

    def test_import_from_interfaces(self) -> None:
        """BaseDocTypeProtocol should be importable from interfaces module."""
        from framework_m_core.interfaces.base_doctype import BaseDocTypeProtocol

        assert BaseDocTypeProtocol is not None

    def test_is_protocol(self) -> None:
        """BaseDocTypeProtocol should be a Protocol."""
        from framework_m_core.interfaces.base_doctype import BaseDocTypeProtocol

        # Check it's a Protocol subclass
        assert issubclass(BaseDocTypeProtocol, Protocol)

    def test_is_runtime_checkable(self) -> None:
        """BaseDocTypeProtocol should be runtime_checkable for isinstance checks."""
        from framework_m_core.interfaces.base_doctype import BaseDocTypeProtocol

        # Verify @runtime_checkable decorator was applied
        assert hasattr(BaseDocTypeProtocol, "__protocol_attrs__")


class TestBaseDocTypeProtocolStructure:
    """Tests that BaseDocTypeProtocol has the required fields."""

    def test_has_id_field(self) -> None:
        """Protocol should define id field as UUID."""
        from framework_m_core.interfaces.base_doctype import BaseDocTypeProtocol

        hints = get_type_hints(BaseDocTypeProtocol)
        assert "id" in hints
        assert hints["id"] == UUID

    def test_has_name_field(self) -> None:
        """Protocol should define name field as optional str."""
        from framework_m_core.interfaces.base_doctype import BaseDocTypeProtocol

        hints = get_type_hints(BaseDocTypeProtocol)
        assert "name" in hints
        # name can be str | None
        assert hints["name"] == str | None

    def test_has_creation_field(self) -> None:
        """Protocol should define creation field as datetime."""
        from framework_m_core.interfaces.base_doctype import BaseDocTypeProtocol

        hints = get_type_hints(BaseDocTypeProtocol)
        assert "creation" in hints
        assert hints["creation"] == datetime

    def test_has_modified_field(self) -> None:
        """Protocol should define modified field as datetime."""
        from framework_m_core.interfaces.base_doctype import BaseDocTypeProtocol

        hints = get_type_hints(BaseDocTypeProtocol)
        assert "modified" in hints
        assert hints["modified"] == datetime

    def test_only_required_fields(self) -> None:
        """Protocol should ONLY define the minimal required fields.

        This ensures MX packages have maximum freedom in their implementations.
        Fields like owner, modified_by, deleted_at are adapter-specific.
        """
        from framework_m_core.interfaces.base_doctype import BaseDocTypeProtocol

        hints = get_type_hints(BaseDocTypeProtocol)
        # Only 4 required fields in the protocol
        expected_fields = {"id", "name", "creation", "modified"}
        assert set(hints.keys()) == expected_fields


class TestBaseDocTypeProtocolCompliance:
    """Tests that classes can implement BaseDocTypeProtocol."""

    def test_pydantic_model_satisfies_protocol(self) -> None:
        """A Pydantic model with required fields should satisfy the protocol."""
        from datetime import UTC, datetime
        from uuid import uuid4

        from framework_m_core.interfaces.base_doctype import BaseDocTypeProtocol
        from pydantic import BaseModel

        class MinimalDoc(BaseModel):
            """Minimal implementation of BaseDocTypeProtocol."""

            id: UUID
            name: str | None
            creation: datetime
            modified: datetime

        # Create instance
        doc = MinimalDoc(
            id=uuid4(),
            name="test",
            creation=datetime.now(UTC),
            modified=datetime.now(UTC),
        )

        # Should satisfy protocol at runtime
        assert isinstance(doc, BaseDocTypeProtocol)

    def test_mx_custom_implementation(self) -> None:
        """MX packages can provide their own BaseDocType implementation.

        This test simulates a MongoDB-based MX package that doesn't use
        UUID for id (uses MongoDB's ObjectId instead).
        """
        from datetime import UTC, datetime

        from framework_m_core.interfaces.base_doctype import BaseDocTypeProtocol
        from pydantic import BaseModel

        class MongoDoc(BaseModel):
            """MongoDB-style DocType (simulated)."""

            id: UUID  # In real MX, this might be ObjectId converted to UUID
            name: str | None
            creation: datetime
            modified: datetime
            # MX can add their own fields
            mongo_id: str = "507f1f77bcf86cd799439011"  # ObjectId as string

        doc = MongoDoc(
            id=UUID("12345678-1234-5678-1234-567812345678"),
            name="mongo-doc",
            creation=datetime.now(UTC),
            modified=datetime.now(UTC),
        )

        # Should satisfy protocol
        assert isinstance(doc, BaseDocTypeProtocol)

    def test_missing_field_fails_protocol(self) -> None:
        """Classes missing required fields should NOT satisfy protocol."""
        from framework_m_core.interfaces.base_doctype import BaseDocTypeProtocol
        from pydantic import BaseModel

        class IncompleteDoc(BaseModel):
            """Missing 'modified' field."""

            id: UUID
            name: str | None
            creation: datetime
            # missing: modified

        doc = IncompleteDoc(
            id=UUID("12345678-1234-5678-1234-567812345678"),
            name="incomplete",
            creation=datetime.now(),
        )

        # Should NOT satisfy protocol
        assert not isinstance(doc, BaseDocTypeProtocol)


class TestBaseDocTypeProtocolExports:
    """Tests that BaseDocTypeProtocol is exported correctly."""

    def test_exported_from_interfaces_init(self) -> None:
        """BaseDocTypeProtocol should be exported from interfaces package."""
        from framework_m_core.interfaces import BaseDocTypeProtocol

        assert BaseDocTypeProtocol is not None

    def test_exported_from_framework_m_core_init(self) -> None:
        """BaseDocTypeProtocol should be exported from framework_m_core."""
        from framework_m_core import BaseDocTypeProtocol

        assert BaseDocTypeProtocol is not None
