"""Tests for BootstrapProtocol.

The BootstrapProtocol defines the interface for startup steps.
This allows MX packages to provide their own bootstrap sequences
via entry points.
"""

from typing import Any, Protocol, get_type_hints

import pytest


class TestBootstrapProtocolExists:
    """Tests that BootstrapProtocol is defined and importable."""

    def test_import_from_interfaces(self) -> None:
        """BootstrapProtocol should be importable from interfaces module."""
        from framework_m_core.interfaces.bootstrap import BootstrapProtocol

        assert BootstrapProtocol is not None

    def test_is_protocol(self) -> None:
        """BootstrapProtocol should be a Protocol."""
        from framework_m_core.interfaces.bootstrap import BootstrapProtocol

        assert issubclass(BootstrapProtocol, Protocol)

    def test_is_runtime_checkable(self) -> None:
        """BootstrapProtocol should be runtime_checkable."""
        from framework_m_core.interfaces.bootstrap import BootstrapProtocol

        assert hasattr(BootstrapProtocol, "__protocol_attrs__")


class TestBootstrapProtocolStructure:
    """Tests that BootstrapProtocol has the required fields and methods."""

    def test_has_run_method(self) -> None:
        """Protocol should define async run method."""
        from framework_m_core.interfaces.bootstrap import BootstrapProtocol

        assert hasattr(BootstrapProtocol, "run")

    def test_run_method_signature(self) -> None:
        """Run method should accept container parameter."""
        from framework_m_core.interfaces.bootstrap import BootstrapProtocol

        hints = get_type_hints(BootstrapProtocol.run)
        # Should have 'container' parameter
        assert "container" in hints


class TestBootstrapProtocolCompliance:
    """Tests that classes can implement BootstrapProtocol."""

    @pytest.mark.asyncio
    async def test_simple_bootstrap_step(self) -> None:
        """Simple bootstrap step should satisfy protocol."""
        from framework_m_core.interfaces.bootstrap import BootstrapProtocol

        class InitEngine:
            """Bootstrap step to initialize database engine."""

            name = "init_engine"
            order = 10

            async def run(self, container: Any) -> None:
                """Initialize SQLAlchemy engine."""
                # Would create engine and bind to container
                pass

        step = InitEngine()

        # Should satisfy protocol
        assert isinstance(step, BootstrapProtocol)

        # Should work
        await step.run({})
        assert step.name == "init_engine"
        assert step.order == 10

    @pytest.mark.asyncio
    async def test_mx_mongo_bootstrap(self) -> None:
        """MX MongoDB package can provide custom bootstrap steps."""
        from framework_m_core.interfaces.bootstrap import BootstrapProtocol

        class InitMongoClient:
            """MongoDB-specific bootstrap step."""

            name = "init_mongo"
            order = 10

            def __init__(self, connection_string: str = "mongodb://localhost") -> None:
                self.connection_string = connection_string

            async def run(self, container: Any) -> None:
                """Initialize MongoDB client."""
                # Would create Motor client and bind to container
                # container.bind(MongoClient, client)
                pass

        step = InitMongoClient()

        # Should satisfy protocol
        assert isinstance(step, BootstrapProtocol)

        await step.run({})
        assert step.order == 10

    @pytest.mark.asyncio
    async def test_bootstrap_step_with_dependencies(self) -> None:
        """Bootstrap step can depend on container services."""
        from framework_m_core.interfaces.bootstrap import BootstrapProtocol

        class SyncSchema:
            """Bootstrap step to sync database schema."""

            name = "sync_schema"
            order = 30  # Runs after init_engine (10) and init_registries (20)

            async def run(self, container: Any) -> None:
                """Run schema sync using SchemaMapper."""
                # Would get SchemaMapper from container
                # mapper = container.get(SchemaMapper)
                # await mapper.sync_all()
                pass

        step = SyncSchema()

        # Should satisfy protocol
        assert isinstance(step, BootstrapProtocol)

        # Order determines execution sequence
        assert step.order == 30

    @pytest.mark.asyncio
    async def test_multiple_steps_ordered(self) -> None:
        """Multiple bootstrap steps should be sortable by order."""
        from framework_m_core.interfaces.bootstrap import BootstrapProtocol

        class InitEngine:
            name = "init_engine"
            order = 10

            async def run(self, container: Any) -> None:
                pass

        class InitRegistries:
            name = "init_registries"
            order = 20

            async def run(self, container: Any) -> None:
                pass

        class SyncSchema:
            name = "sync_schema"
            order = 30

            async def run(self, container: Any) -> None:
                pass

        steps = [SyncSchema(), InitEngine(), InitRegistries()]

        # All satisfy protocol
        for step in steps:
            assert isinstance(step, BootstrapProtocol)

        # Can be sorted by order
        sorted_steps = sorted(steps, key=lambda s: s.order)

        assert sorted_steps[0].name == "init_engine"
        assert sorted_steps[1].name == "init_registries"
        assert sorted_steps[2].name == "sync_schema"


class TestBootstrapProtocolExports:
    """Tests that BootstrapProtocol is exported correctly."""

    def test_exported_from_interfaces_init(self) -> None:
        """BootstrapProtocol should be exported from interfaces package."""
        from framework_m_core.interfaces import BootstrapProtocol

        assert BootstrapProtocol is not None

    def test_exported_from_framework_m_core_init(self) -> None:
        """BootstrapProtocol should be exported from framework_m_core."""
        from framework_m_core import BootstrapProtocol

        assert BootstrapProtocol is not None
