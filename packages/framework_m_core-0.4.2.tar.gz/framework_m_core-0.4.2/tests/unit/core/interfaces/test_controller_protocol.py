"""Tests for BaseControllerProtocol.

The BaseControllerProtocol defines the interface for document lifecycle hooks.
This allows MX packages to provide their own controller implementations.
"""

from typing import Any, Protocol, get_type_hints

import pytest


class TestBaseControllerProtocolExists:
    """Tests that BaseControllerProtocol is defined and importable."""

    def test_import_from_interfaces(self) -> None:
        """BaseControllerProtocol should be importable from interfaces module."""
        from framework_m_core.interfaces.controller import BaseControllerProtocol

        assert BaseControllerProtocol is not None

    def test_is_protocol(self) -> None:
        """BaseControllerProtocol should be a Protocol."""
        from framework_m_core.interfaces.controller import BaseControllerProtocol

        assert issubclass(BaseControllerProtocol, Protocol)

    def test_is_runtime_checkable(self) -> None:
        """BaseControllerProtocol should be runtime_checkable."""
        from framework_m_core.interfaces.controller import BaseControllerProtocol

        assert hasattr(BaseControllerProtocol, "__protocol_attrs__")


class TestBaseControllerProtocolStructure:
    """Tests that BaseControllerProtocol has the required lifecycle hooks."""

    REQUIRED_HOOKS = [
        "validate",
        "before_insert",
        "after_insert",
        "before_save",
        "after_save",
        "before_delete",
        "after_delete",
        "on_submit",
        "on_cancel",
    ]

    def test_has_all_lifecycle_hooks(self) -> None:
        """Protocol should define all documented lifecycle hooks."""
        from framework_m_core.interfaces.controller import BaseControllerProtocol

        for hook in self.REQUIRED_HOOKS:
            assert hasattr(BaseControllerProtocol, hook), f"Missing hook: {hook}"

    def test_hooks_are_async(self) -> None:
        """All lifecycle hooks should be async methods."""

        from framework_m_core.interfaces.controller import BaseControllerProtocol

        for hook in self.REQUIRED_HOOKS:
            method = getattr(BaseControllerProtocol, hook)
            # For protocols, we check the annotations
            assert callable(method), f"{hook} should be callable"

    def test_hooks_accept_context(self) -> None:
        """All lifecycle hooks should accept optional context parameter."""

        from framework_m_core.interfaces.controller import BaseControllerProtocol

        for hook in self.REQUIRED_HOOKS:
            method = getattr(BaseControllerProtocol, hook)
            hints = get_type_hints(method)
            # Should have 'context' parameter
            assert "context" in hints, f"{hook} should have context parameter"
            # context should be Any | None
            assert hints["context"] == Any | None, (
                f"{hook} context should be Any | None"
            )


class TestBaseControllerProtocolCompliance:
    """Tests that classes can implement BaseControllerProtocol."""

    @pytest.mark.asyncio
    async def test_concrete_base_controller_satisfies_protocol(self) -> None:
        """The concrete BaseController should satisfy the protocol."""
        from framework_m_core.domain.base_controller import BaseController
        from framework_m_core.domain.base_doctype import BaseDocType
        from framework_m_core.interfaces.controller import BaseControllerProtocol

        class TestDoc(BaseDocType):
            pass

        doc = TestDoc()
        controller = BaseController(doc)

        # Should satisfy protocol
        assert isinstance(controller, BaseControllerProtocol)

    @pytest.mark.asyncio
    async def test_custom_controller_satisfies_protocol(self) -> None:
        """Custom controller implementations should satisfy the protocol."""
        from typing import Any

        from framework_m_core.domain.base_doctype import BaseDocType
        from framework_m_core.interfaces.controller import BaseControllerProtocol

        class TestDoc(BaseDocType):
            pass

        class CustomController:
            """Custom controller implementation."""

            def __init__(self, doc: TestDoc) -> None:
                self.doc = doc

            async def validate(self, context: Any | None = None) -> None:
                pass

            async def before_insert(self, context: Any | None = None) -> None:
                pass

            async def after_insert(self, context: Any | None = None) -> None:
                pass

            async def before_save(self, context: Any | None = None) -> None:
                pass

            async def after_save(self, context: Any | None = None) -> None:
                pass

            async def before_delete(self, context: Any | None = None) -> None:
                pass

            async def after_delete(self, context: Any | None = None) -> None:
                pass

            async def on_submit(self, context: Any | None = None) -> None:
                pass

            async def on_cancel(self, context: Any | None = None) -> None:
                pass

        doc = TestDoc()
        controller = CustomController(doc)

        # Should satisfy protocol
        assert isinstance(controller, BaseControllerProtocol)

    @pytest.mark.asyncio
    async def test_mx_mongo_controller_example(self) -> None:
        """Demonstrate MX package providing custom controller.

        A MongoDB MX package might want different hook behavior.
        """
        from typing import Any

        from framework_m_core.interfaces.controller import BaseControllerProtocol
        from pydantic import BaseModel

        class MongoDoc(BaseModel):
            """Simulated MongoDB document."""

            id: Any
            name: str | None = None

        class MongoController:
            """MongoDB-specific controller with custom hooks."""

            def __init__(self, doc: MongoDoc) -> None:
                self.doc = doc
                self.hooks_called: list[str] = []

            async def validate(self, context: Any | None = None) -> None:
                self.hooks_called.append("validate")

            async def before_insert(self, context: Any | None = None) -> None:
                # MongoDB-specific: Generate ObjectId here
                self.hooks_called.append("before_insert")

            async def after_insert(self, context: Any | None = None) -> None:
                self.hooks_called.append("after_insert")

            async def before_save(self, context: Any | None = None) -> None:
                self.hooks_called.append("before_save")

            async def after_save(self, context: Any | None = None) -> None:
                # MongoDB-specific: Update indexes
                self.hooks_called.append("after_save")

            async def before_delete(self, context: Any | None = None) -> None:
                self.hooks_called.append("before_delete")

            async def after_delete(self, context: Any | None = None) -> None:
                self.hooks_called.append("after_delete")

            async def on_submit(self, context: Any | None = None) -> None:
                self.hooks_called.append("on_submit")

            async def on_cancel(self, context: Any | None = None) -> None:
                self.hooks_called.append("on_cancel")

        doc = MongoDoc(id="507f1f77bcf86cd799439011")
        controller = MongoController(doc)

        # Should satisfy protocol
        assert isinstance(controller, BaseControllerProtocol)

        # Hooks should work
        await controller.validate()
        await controller.before_insert()
        assert "validate" in controller.hooks_called
        assert "before_insert" in controller.hooks_called


class TestBaseControllerProtocolExports:
    """Tests that BaseControllerProtocol is exported correctly."""

    def test_exported_from_interfaces_init(self) -> None:
        """BaseControllerProtocol should be exported from interfaces package."""
        from framework_m_core.interfaces import BaseControllerProtocol

        assert BaseControllerProtocol is not None

    def test_exported_from_framework_m_core_init(self) -> None:
        """BaseControllerProtocol should be exported from framework_m_core."""
        from framework_m_core import BaseControllerProtocol

        assert BaseControllerProtocol is not None
