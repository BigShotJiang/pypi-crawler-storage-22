"""Tests for SchemaMapperProtocol.

The SchemaMapperProtocol defines the interface for mapping Pydantic models
to storage schemas. This allows MX packages to provide their own schema mappers
for different databases (MongoDB, Cassandra, etc.).
"""

from typing import Any, Protocol


class TestSchemaMapperProtocolExists:
    """Tests that SchemaMapperProtocol is defined and importable."""

    def test_import_from_interfaces(self) -> None:
        """SchemaMapperProtocol should be importable from interfaces module."""
        from framework_m_core.interfaces.schema_mapper import SchemaMapperProtocol

        assert SchemaMapperProtocol is not None

    def test_is_protocol(self) -> None:
        """SchemaMapperProtocol should be a Protocol."""
        from framework_m_core.interfaces.schema_mapper import SchemaMapperProtocol

        assert issubclass(SchemaMapperProtocol, Protocol)

    def test_is_runtime_checkable(self) -> None:
        """SchemaMapperProtocol should be runtime_checkable."""
        from framework_m_core.interfaces.schema_mapper import SchemaMapperProtocol

        assert hasattr(SchemaMapperProtocol, "__protocol_attrs__")


class TestSchemaMapperProtocolStructure:
    """Tests that SchemaMapperProtocol has the required methods."""

    def test_has_create_table_method(self) -> None:
        """Protocol should define create_table method."""
        from framework_m_core.interfaces.schema_mapper import SchemaMapperProtocol

        assert hasattr(SchemaMapperProtocol, "create_table")

    def test_has_create_tables_method(self) -> None:
        """Protocol should define create_tables method for child tables."""
        from framework_m_core.interfaces.schema_mapper import SchemaMapperProtocol

        assert hasattr(SchemaMapperProtocol, "create_tables")

    def test_has_detect_schema_changes_method(self) -> None:
        """Protocol should define detect_schema_changes method."""
        from framework_m_core.interfaces.schema_mapper import SchemaMapperProtocol

        assert hasattr(SchemaMapperProtocol, "detect_schema_changes")


class TestSchemaMapperProtocolCompliance:
    """Tests that classes can implement SchemaMapperProtocol."""

    def test_sqlalchemy_mapper_satisfies_protocol(self) -> None:
        """The SQLAlchemy SchemaMapper should satisfy the protocol."""
        from framework_m_core.interfaces.schema_mapper import SchemaMapperProtocol
        from framework_m_standard.adapters.db.schema_mapper import SchemaMapper

        mapper = SchemaMapper()

        # Should satisfy protocol
        assert isinstance(mapper, SchemaMapperProtocol)

    def test_custom_mapper_satisfies_protocol(self) -> None:
        """Custom mapper implementations should satisfy the protocol."""

        from framework_m_core.interfaces.base_doctype import BaseDocTypeProtocol
        from framework_m_core.interfaces.schema_mapper import SchemaMapperProtocol

        class MongoSchemaMapper:
            """MongoDB-specific schema mapper."""

            def create_table(
                self, model: type[BaseDocTypeProtocol], metadata: Any
            ) -> Any:
                """Create MongoDB collection schema."""
                return {"collection": model.__name__.lower()}

            def create_tables(
                self, model: type[BaseDocTypeProtocol], metadata: Any
            ) -> list[Any]:
                """Create MongoDB collection schemas (parent + children)."""
                return [self.create_table(model, metadata)]

            def detect_schema_changes(
                self,
                old_model: type[BaseDocTypeProtocol],
                new_model: type[BaseDocTypeProtocol],
            ) -> dict[str, Any]:
                """Detect schema changes between models."""
                return {"added_fields": [], "removed_fields": []}

        mapper = MongoSchemaMapper()

        # Should satisfy protocol
        assert isinstance(mapper, SchemaMapperProtocol)

    def test_mx_cassandra_mapper_example(self) -> None:
        """Demonstrate MX package providing Cassandra schema mapper."""

        from framework_m_core.interfaces.base_doctype import BaseDocTypeProtocol
        from framework_m_core.interfaces.schema_mapper import SchemaMapperProtocol

        class CassandraSchemaMapper:
            """Cassandra-specific schema mapper."""

            def create_table(
                self, model: type[BaseDocTypeProtocol], metadata: Any
            ) -> Any:
                """Create Cassandra table schema."""
                # In real implementation, would return CQL CREATE TABLE statement
                return {
                    "table_name": model.__name__.lower(),
                    "keyspace": "default",
                    "columns": [],
                }

            def create_tables(
                self, model: type[BaseDocTypeProtocol], metadata: Any
            ) -> list[Any]:
                """Create Cassandra table schemas."""
                return [self.create_table(model, metadata)]

            def detect_schema_changes(
                self,
                old_model: type[BaseDocTypeProtocol],
                new_model: type[BaseDocTypeProtocol],
            ) -> dict[str, Any]:
                """Detect schema changes for Cassandra migrations."""
                return {
                    "added_fields": [],
                    "removed_fields": [],
                    "type_changes": [],
                }

        mapper = CassandraSchemaMapper()

        # Should satisfy protocol
        assert isinstance(mapper, SchemaMapperProtocol)

        # Should work
        result = mapper.create_table(type("TestDoc", (), {}), None)  # type: ignore
        assert result["keyspace"] == "default"


class TestSchemaMapperProtocolExports:
    """Tests that SchemaMapperProtocol is exported correctly."""

    def test_exported_from_interfaces_init(self) -> None:
        """SchemaMapperProtocol should be exported from interfaces package."""
        from framework_m_core.interfaces import SchemaMapperProtocol

        assert SchemaMapperProtocol is not None

    def test_exported_from_framework_m_core_init(self) -> None:
        """SchemaMapperProtocol should be exported from framework_m_core."""
        from framework_m_core import SchemaMapperProtocol

        assert SchemaMapperProtocol is not None
