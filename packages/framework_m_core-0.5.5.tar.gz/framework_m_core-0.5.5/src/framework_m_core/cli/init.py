"""Init CLI Command - Scaffold frontend from template.

This module provides commands to initialize new components of Framework M.

Architecture:
- No global state - all paths passed explicitly
- Template resources via importlib.resources (Python 3.9+)
- Explicit error handling for file operations
- User feedback with print statements

Usage:
    m init:frontend                      # Initialize in ./frontend
    m init:frontend ../my-frontend       # Initialize in custom location
"""

from __future__ import annotations

import shutil
import subprocess
from importlib.resources import files
from pathlib import Path
from typing import Annotated

import cyclopts


def _copy_template(source_template: Path, target: Path) -> None:
    """Copy template directory to target location.

    Args:
        source_template: Source template directory
        target: Target directory

    Raises:
        FileExistsError: If target already exists
        RuntimeError: If copy fails
    """
    if target.exists():
        msg = f"Target directory already exists: {target}"
        raise FileExistsError(msg)

    try:
        shutil.copytree(source_template, target)
        print(f"✓ Copied template to {target}")
    except Exception as e:
        msg = f"Failed to copy template: {e}"
        raise RuntimeError(msg) from e


def _install_dependencies(target: Path) -> None:
    """Install pnpm dependencies in target directory.

    Args:
        target: Frontend directory

    Raises:
        RuntimeError: If pnpm install fails
    """
    print("\nInstalling dependencies with pnpm...")
    try:
        subprocess.run(
            ["pnpm", "install"],
            cwd=str(target),
            check=True,
        )
        print("✓ Dependencies installed")
    except subprocess.CalledProcessError as e:
        msg = f"Failed to install dependencies: {e}"
        raise RuntimeError(msg) from e


def init_frontend_command(
    target: Annotated[
        Path | None,
        cyclopts.Parameter(
            name=["target"],
            help="Target directory for frontend (default: ./frontend)",
        ),
    ] = None,
) -> None:
    """Initialize a new frontend from template.

    This scaffolds the bundled Desk frontend template to a target directory
    and installs dependencies. The template includes:
    - React + TypeScript + Vite
    - @framework-m/desk npm package integration
    - Refine.dev setup with authProvider, dataProvider, liveProvider
    - Tailwind CSS + shadcn/ui components

    Examples:
        m init:frontend                      # Initialize in ./frontend
        m init:frontend ../my-frontend       # Custom location

    Architecture Notes:
        - Uses apps/studio/frontend as template source
        - No global state - all paths explicit
        - Validates target doesn't exist (prevents overwrites)
        - Runs pnpm install automatically
    """
    # Default to ./frontend
    if target is None:
        target = Path("frontend")

    # Resolve to absolute path
    target = target.resolve()

    # Find template source from framework_m package
    try:
        template_resource = files("framework_m") / "templates" / "frontend"
        if not template_resource.is_dir():
            msg = "Frontend template not found in framework_m package"
            raise RuntimeError(msg)

        # Convert to Path for file operations
        template_source = Path(str(template_resource))
    except Exception as e:
        msg = f"Failed to locate template: {e}"
        raise RuntimeError(msg) from e

    print(f"Initializing frontend at {target}")
    print(f"Template source: {template_source}")

    # Copy template
    _copy_template(template_source, target)

    # Install dependencies
    _install_dependencies(target)

    print("\n✓ Frontend initialized successfully!")
    print("\nNext steps:")
    print(f"  cd {target}")
    print("  pnpm dev")
    print("\nOr start with:")
    print("  m start --with-frontend")


__all__ = ["init_frontend_command"]
