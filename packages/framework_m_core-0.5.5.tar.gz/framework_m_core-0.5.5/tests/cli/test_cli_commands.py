"""Fast CLI command tests.

Tests CLI commands without heavy npm operations.
Focus on command structure, error handling, and fast validations.
"""

from __future__ import annotations

import subprocess
from pathlib import Path

import pytest


class TestInitFrontendCommand:
    """Test m init:frontend command."""

    def test_command_available(self) -> None:
        """Test that init:frontend command is registered."""
        result = subprocess.run(
            ["python", "-m", "framework_m_core.cli.main", "init:frontend", "--help"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "init:frontend" in result.stdout.lower() or "Initialize" in result.stdout

    def test_fails_without_template(self, tmp_path: Path) -> None:
        """Test fails gracefully when template not found."""
        # Test by trying to initialize with a non-existent template via import failure
        # The init command will fail during dependency installation if pnpm can't find packages
        # This is effectively tested by the error handling in test_raises_runtime_error_when_template_not_found
        # Just verify the command exists and accepts arguments
        result = subprocess.run(
            ["python", "-m", "framework_m_core.cli.main", "init:frontend", "--help"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0

    def test_fails_if_target_exists(self, tmp_path: Path) -> None:
        """Test fails when target directory already exists."""
        target = tmp_path / "existing"
        target.mkdir()

        result = subprocess.run(
            ["python", "-m", "framework_m_core.cli.main", "init:frontend", str(target)],
            capture_output=True,
            text=True,
            timeout=5,
        )

        assert result.returncode != 0
        assert (
            "already exists" in result.stderr.lower()
            or "already exists" in result.stdout.lower()
        )


class TestStartCommand:
    """Test m start command."""

    def test_command_available(self) -> None:
        """Test that start command is registered."""
        result = subprocess.run(
            ["python", "-m", "framework_m_core.cli.main", "start", "--help"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "start" in result.stdout.lower() or "Start" in result.stdout

    def test_accepts_port_parameter(self) -> None:
        """Test that --port parameter is accepted."""
        result = subprocess.run(
            ["python", "-m", "framework_m_core.cli.main", "start", "--help"],
            capture_output=True,
            text=True,
        )
        assert "--port" in result.stdout.lower()

    def test_accepts_with_frontend_parameter(self) -> None:
        """Test that --with-frontend parameter is accepted."""
        result = subprocess.run(
            ["python", "-m", "framework_m_core.cli.main", "start", "--help"],
            capture_output=True,
            text=True,
        )
        assert "--with-frontend" in result.stdout.lower()


class TestCLIStructure:
    """Test overall CLI structure."""

    def test_main_cli_runs(self) -> None:
        """Test that main CLI runs without errors."""
        result = subprocess.run(
            ["python", "-m", "framework_m_core.cli.main", "--help"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        assert result.returncode == 0
        assert "framework" in result.stdout.lower() or "usage" in result.stdout.lower()

    def test_all_commands_listed(self) -> None:
        """Test that key commands are listed in help."""
        result = subprocess.run(
            ["python", "-m", "framework_m_core.cli.main", "--help"],
            capture_output=True,
            text=True,
        )

        # Should list major commands
        help_text = result.stdout.lower()
        assert "start" in help_text
        assert "init" in help_text or "frontend" in help_text


@pytest.mark.skipif(
    not Path("frontend").exists(),
    reason="Frontend template not available",
)
class TestTemplateStructure:
    """Test frontend template structure (fast validation)."""

    def test_template_has_package_json(self) -> None:
        """Test template has package.json."""
        template = Path("frontend")
        assert (template / "package.json").exists()

    def test_template_has_vite_config(self) -> None:
        """Test template has vite.config.ts."""
        template = Path("frontend")
        assert (template / "vite.config.ts").exists()

    def test_template_has_tsconfig(self) -> None:
        """Test template has tsconfig.json."""
        template = Path("frontend")
        assert (template / "tsconfig.json").exists()

    def test_template_has_src_directory(self) -> None:
        """Test template has src directory with essential files."""
        template = Path("frontend")
        assert (template / "src").exists()
        assert (template / "src" / "App.tsx").exists()
        assert (template / "src" / "index.tsx").exists()

    def test_template_has_npmrc(self) -> None:
        """Test template has .npmrc for pnpm configuration."""
        template = Path("frontend")
        assert (template / ".npmrc").exists()

    def test_package_json_has_required_deps(self) -> None:
        """Test package.json has required dependencies."""
        template = Path("frontend")
        package_json = template / "package.json"
        content = package_json.read_text()

        # Should have Refine and React
        assert "@refinedev/core" in content
        assert "react" in content
        assert "vite" in content


@pytest.mark.skipif(
    not Path("libs/framework-m-desk").exists(),
    reason="@framework-m/desk package not available",
)
class TestDeskPackageStructure:
    """Test @framework-m/desk package structure (fast validation)."""

    def test_package_has_package_json(self) -> None:
        """Test package has package.json."""
        package = Path("libs/framework-m-desk")
        assert (package / "package.json").exists()

    def test_package_has_src_directory(self) -> None:
        """Test package has src directory."""
        package = Path("libs/framework-m-desk")
        assert (package / "src").exists()
        assert (package / "src" / "index.ts").exists()

    def test_package_exports_providers(self) -> None:
        """Test index.ts exports required providers."""
        package = Path("libs/framework-m-desk")
        index_file = package / "src" / "index.ts"
        content = index_file.read_text()

        expected_exports = [
            "frameworkMDataProvider",
            "authProvider",
            "liveProvider",
            "API_URL",
        ]

        for export in expected_exports:
            assert export in content, f"Missing export: {export}"

    def test_package_json_has_correct_config(self) -> None:
        """Test package.json has correct configuration."""
        package = Path("libs/framework-m-desk")
        package_json = package / "package.json"
        content = package_json.read_text()

        assert "@framework-m/desk" in content
        assert "dist/index.js" in content
        assert "peerDependencies" in content


class TestFrontendBuildConfig:
    """Test frontend build configuration (no actual build)."""

    @pytest.mark.skipif(
        not Path("frontend").exists(),
        reason="Frontend template not available",
    )
    def test_vite_config_exists_and_valid(self) -> None:
        """Test vite config file exists and has basic structure."""
        vite_config = Path("frontend/vite.config.ts")
        assert vite_config.exists()

        content = vite_config.read_text()
        assert "defineConfig" in content
        assert "plugins" in content

    @pytest.mark.skipif(
        not Path("frontend").exists(),
        reason="Frontend template not available",
    )
    def test_tsconfig_exists_and_valid(self) -> None:
        """Test TypeScript config exists and has basic structure."""
        tsconfig = Path("frontend/tsconfig.json")
        assert tsconfig.exists()

        content = tsconfig.read_text()
        assert "compilerOptions" in content

    @pytest.mark.skipif(
        not Path("frontend").exists(),
        reason="Frontend template not available",
    )
    def test_npmrc_has_peer_dependency_config(self) -> None:
        """Test .npmrc has peer dependency configuration."""
        npmrc = Path("frontend/.npmrc")
        if npmrc.exists():
            content = npmrc.read_text()
            # Should have peer dependency settings for compatibility
            assert (
                "legacy-peer-deps" in content.lower()
                or "strict-peer-dependencies" in content.lower()
            )


class TestPackageJsonOverrides:
    """Test package.json configuration."""

    def test_root_package_json_exists_and_valid(self) -> None:
        """Test root package.json exists and has valid monorepo config."""
        package_json = Path("package.json")
        if package_json.exists():
            content = package_json.read_text()
            import json

            data = json.loads(content)
            # Should be a monorepo with pnpm workspace
            assert data.get("private") is True
            # Overrides are optional - only needed if dependency conflicts exist
            # Just verify the file is valid JSON and has basic monorepo structure


class TestAutoFormTypescriptFix:
    """Test AutoForm TypeScript fixes."""

    @pytest.mark.skipif(
        not Path("frontend/src/components/form/AutoForm.tsx").exists(),
        reason="AutoForm component not available",
    )
    def test_autoform_has_validator_type_cast(self) -> None:
        """Test AutoForm has ValidatorType cast to fix type error."""
        autoform = Path("frontend/src/components/form/AutoForm.tsx")
        content = autoform.read_text()

        # Should import ValidatorType
        assert "ValidatorType" in content

        # Should have type cast
        assert "as ValidatorType" in content

    @pytest.mark.skipif(
        not Path("frontend/src/components/form/AutoForm.tsx").exists(),
        reason="AutoForm component not available",
    )
    def test_autoform_imports_rjsf_correctly(self) -> None:
        """Test AutoForm imports from @rjsf packages."""
        autoform = Path("frontend/src/components/form/AutoForm.tsx")
        content = autoform.read_text()

        assert "@rjsf/core" in content
        assert "@rjsf/utils" in content
        assert "@rjsf/validator-ajv8" in content
