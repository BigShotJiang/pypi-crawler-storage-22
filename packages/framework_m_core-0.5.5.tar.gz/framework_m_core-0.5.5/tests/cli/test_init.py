"""Tests for init CLI command.

This module tests the m init:frontend command:
- Template copying
- Dependency installation
- Error handling
- Path resolution
"""

from __future__ import annotations

import subprocess
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from framework_m_core.cli.init import (
    _copy_template,
    _install_dependencies,
    init_frontend_command,
)


class TestCopyTemplate:
    """Tests for _copy_template helper."""

    def test_copies_template_successfully(self, tmp_path: Path) -> None:
        """Should copy template directory to target."""
        source = tmp_path / "source"
        source.mkdir()
        (source / "package.json").write_text("{}")
        (source / "README.md").write_text("# Template")

        target = tmp_path / "target"

        _copy_template(source, target)

        assert target.exists()
        assert (target / "package.json").exists()
        assert (target / "README.md").exists()

    def test_raises_file_exists_error_when_target_exists(self, tmp_path: Path) -> None:
        """Should raise FileExistsError if target exists."""
        source = tmp_path / "source"
        source.mkdir()

        target = tmp_path / "target"
        target.mkdir()

        with pytest.raises(FileExistsError, match="already exists"):
            _copy_template(source, target)

    def test_raises_runtime_error_on_copy_failure(self, tmp_path: Path) -> None:
        """Should raise RuntimeError if copy fails."""
        source = tmp_path / "source"
        # Don't create source - will fail

        target = tmp_path / "target"

        with pytest.raises(RuntimeError, match="Failed to copy template"):
            _copy_template(source, target)


class TestInstallDependencies:
    """Tests for _install_dependencies helper."""

    @patch("framework_m_core.cli.init.subprocess.run")
    def test_runs_pnpm_install(self, mock_run: MagicMock, tmp_path: Path) -> None:
        """Should execute pnpm install in target directory."""
        target = tmp_path / "frontend"
        target.mkdir()

        _install_dependencies(target)

        mock_run.assert_called_once_with(
            ["pnpm", "install"],
            cwd=str(target),
            check=True,
        )

    @patch("framework_m_core.cli.init.subprocess.run")
    def test_raises_runtime_error_on_install_failure(
        self, mock_run: MagicMock, tmp_path: Path
    ) -> None:
        """Should raise RuntimeError if pnpm install fails."""
        mock_run.side_effect = subprocess.CalledProcessError(1, "pnpm")
        target = tmp_path / "frontend"
        target.mkdir()

        with pytest.raises(RuntimeError, match="Failed to install dependencies"):
            _install_dependencies(target)


class TestInitFrontendCommand:
    """Tests for init_frontend_command entry point."""

    def test_initializes_frontend_with_custom_path(self, tmp_path: Path) -> None:
        """Should initialize frontend at custom path."""
        custom_target = tmp_path / "custom-frontend"

        # Mock only the install step (let copy run to validate structure)
        with patch("framework_m_core.cli.init._install_dependencies"):
            init_frontend_command(target=custom_target)

            # Verify files were copied
            assert custom_target.exists()
            assert (custom_target / "package.json").exists()


class TestInitCLIIntegration:
    """Integration tests for m init:frontend command."""

    def test_init_frontend_command_available(self) -> None:
        """m init:frontend command should be registered."""
        result = subprocess.run(
            ["python", "-m", "framework_m_core.cli.main", "init:frontend", "--help"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "Initialize a new frontend from template" in result.stdout

    def test_init_frontend_command_shows_target_parameter(self) -> None:
        """m init:frontend --help should show target parameter."""
        result = subprocess.run(
            ["python", "-m", "framework_m_core.cli.main", "init:frontend", "--help"],
            capture_output=True,
            text=True,
        )
        assert "target" in result.stdout.lower()
        assert "frontend" in result.stdout.lower()


class TestTemplateStructure:
    """Tests for template validation."""

    def test_template_source_exists_in_workspace(self) -> None:
        """apps/studio/frontend template should exist in workspace."""
        workspace_root = Path(__file__).parents[5]
        template_source = workspace_root / "apps" / "studio" / "frontend"

        # Only validate if we're in the actual workspace
        if workspace_root.name == "m":
            assert template_source.exists(), "Template source should exist"
            assert (template_source / "package.json").exists(), (
                "Template should have package.json"
            )
            assert (template_source / "vite.config.ts").exists(), (
                "Template should have vite config"
            )
