# Changelog

## framework-m-standard v0.2.13

### Bug Fixes

- trigger doc builds on studio changes (d1a2a7b)
- synchronize pages rules with build-docs (3b2d9b7)
- aggressive filtering and dependency decoupling (6b8dbf0)
- global dummy assets and artifact integrity (f6d39f2)
- dual-track artifacts and tag optimization (6b9cdfb)
- optimize tag pipeline and kill duplication (d9154ae)
- use hatch artifacts to resolve duplicate filenames (e499457)


## framework-m-standard v0.2.12

### Bug Fixes

- robustly detect existing tags in auto_tag_release (8aeef39)


## framework-m-standard v0.2.11

### Bug Fixes

- bulletproof tagging and gitlab pypi upload idempotency (530466b)
- make auto_tag_release script idempotent (c211ab5)


## framework-m-standard v0.2.10

### Bug Fixes

- remove unsupported --skip-existing from gitlab twine upload (a1b6a96)


## framework-m-standard v0.2.9

### Bug Fixes

- make test-workspace needs optional (96450fc)
- restore gitlint general section header (7131edc)
- adjust gitlint limits and script for long release titles (1a1371e)
- resolve duplicate filenames in wheel and improve CI robustness (e24c0ef)


## framework-m-standard v0.2.8

### Bug Fixes

- add ruff code style badge to README (3bd7674)


## framework-m-standard v0.2.7

### Bug Fixes

- add pipeline status badge to README (c2dc70f)


## framework-m-standard v0.2.6

### Bug Fixes

- enforce timezone-aware datetimes and fix test (b68332a)

