"""Socket adapters package.

Provides socket adapters for real-time WebSocket communication.
"""

from framework_m_standard.adapters.socket.nats_socket import NatsSocketAdapter

__all__ = ["NatsSocketAdapter"]
