"""Litestar Application Factory.

This module provides the application factory for creating the Litestar
web application with all required configuration.

Features:
- CORS configuration for development
- Exception handlers for domain exceptions
- OpenAPI documentation (Swagger/ReDoc)
- Application lifecycle management
- Dependency injection container integration

Example:
    from framework_m_standard.adapters.web.app import create_app

    app = create_app()

    # Run with uvicorn
    # uvicorn framework_m_standard.adapters.web.app:create_app --factory
"""

# ruff: noqa: E402 - Module imports must come after dotenv loading

import os
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from importlib.resources import files
from pathlib import Path
from typing import Any

# Load environment variables from .env files (searches up the directory tree)
from dotenv import load_dotenv

# Search for .env file from current directory up to root
_cwd = Path.cwd()
for _parent in [_cwd, *_cwd.parents]:
    _env_file = _parent / ".env"
    if _env_file.exists():
        load_dotenv(_env_file)
        break

from framework_m_core.config import load_config
from framework_m_core.container import Container
from framework_m_core.exceptions import (
    DocTypeNotFoundError,
    DuplicateNameError,
    EntityNotFoundError,
    FrameworkError,
    PermissionDeniedError,
    ValidationError,
)
from litestar import Litestar, get
from litestar.config.cors import CORSConfig
from litestar.openapi import OpenAPIConfig
from litestar.openapi.plugins import RedocRenderPlugin, SwaggerRenderPlugin
from litestar.openapi.spec import Components, SecurityScheme
from litestar.response import Redirect, Response
from litestar.static_files import StaticFilesConfig

from framework_m_standard.adapters.db.connection import ConnectionFactory
from framework_m_standard.adapters.db.session import SessionFactory
from framework_m_standard.adapters.web.auth_routes import auth_routes_router
from framework_m_standard.adapters.web.meta_router import create_meta_router
from framework_m_standard.adapters.web.metadata_router import metadata_router
from framework_m_standard.adapters.web.middleware import create_auth_middleware
from framework_m_standard.adapters.web.socket import create_websocket_router
from framework_m_standard.adapters.web.workflow_router import workflow_router

# =============================================================================
# Exception Handlers
# =============================================================================


def validation_error_handler(
    request: Any, exc: ValidationError
) -> Response[dict[str, Any]]:
    """Handle validation errors with 400 Bad Request.

    Args:
        request: The incoming request
        exc: The validation exception

    Returns:
        JSON response with error details
    """
    return Response(
        content={
            "error": "ValidationError",
            "message": str(exc),
            "details": getattr(exc, "details", None),
        },
        status_code=400,
    )


def permission_denied_handler(
    request: Any, exc: PermissionDeniedError
) -> Response[dict[str, str]]:
    """Handle permission denied errors with 403 Forbidden.

    Args:
        request: The incoming request
        exc: The permission exception

    Returns:
        JSON response with error details
    """
    return Response(
        content={
            "error": "PermissionDenied",
            "message": str(exc),
        },
        status_code=403,
    )


def not_found_handler(
    request: Any, exc: DocTypeNotFoundError | EntityNotFoundError
) -> Response[dict[str, str]]:
    """Handle not found errors with 404 Not Found.

    Args:
        request: The incoming request
        exc: The not found exception

    Returns:
        JSON response with error details
    """
    return Response(
        content={
            "error": "NotFound",
            "message": str(exc),
        },
        status_code=404,
    )


def duplicate_name_handler(
    request: Any, exc: DuplicateNameError
) -> Response[dict[str, str]]:
    """Handle duplicate name errors with 409 Conflict.

    Args:
        request: The incoming request
        exc: The duplicate name exception

    Returns:
        JSON response with error details
    """
    return Response(
        content={
            "error": "Conflict",
            "message": str(exc),
            "doctype": exc.doctype_name,
            "name": exc.name,
        },
        status_code=409,
    )


def framework_error_handler(
    request: Any, exc: FrameworkError
) -> Response[dict[str, str]]:
    """Handle generic framework errors with 500 Internal Server Error.

    Args:
        request: The incoming request
        exc: The framework exception

    Returns:
        JSON response with error details
    """
    return Response(
        content={
            "error": "InternalError",
            "message": str(exc),
        },
        status_code=500,
    )


# =============================================================================
# Route Handlers
# =============================================================================


@get("/health", sync_to_thread=False)
def health_check() -> dict[str, str]:
    """Health check endpoint.

    Returns basic health status for load balancers and monitoring.

    Returns:
        Dict with status information
    """
    return {"status": "healthy"}


@get("/", sync_to_thread=False, include_in_schema=False)
def root_redirect() -> Redirect:
    """Redirect root to /desk/.

    This ensures the Desk UI is accessed at a dedicated path,
    avoiding conflicts with API routes.

    Returns:
        Redirect response to /desk/
    """
    return Redirect(path="/desk/")


@get(["desk", "/desk/"], sync_to_thread=False, include_in_schema=False)
def serve_desk_root() -> Response[bytes]:
    """Serve bundled Desk UI index.html at /desk/.

    This is the entry point for the Desk UI.

    Returns:
        HTML response with Desk UI or 404 error
    """
    return _get_desk_html_response()


@get("/desk/{path:path}", sync_to_thread=False, include_in_schema=False)
def serve_desk_spa(path: str) -> Response[bytes]:
    """Serve Desk SPA with client-side routing support.

    This catchall route ensures that React Router paths like /desk/doctypes/User
    work correctly when the user refreshes or enters the URL directly.

    Args:
        path: The requested path (ignored, always serves index.html)

    Returns:
        HTML response with Desk UI index.html
    """
    # Always serve index.html for client-side routing
    # The React app will handle the actual routing
    return _get_desk_html_response()


def _get_desk_html_response() -> Response[bytes]:
    """Get the Desk UI HTML response.

    Helper function to serve index.html from bundled static or local dev.

    Returns:
        HTML response with Desk UI or 404 error
    """
    static_path = _get_bundled_static_path()
    if static_path:
        index_file = static_path / "index.html"
        if index_file.exists():
            return Response(
                content=index_file.read_bytes(),
                media_type="text/html",
            )

    # Fallback to local development
    local_dirs = [
        Path.cwd() / "frontend" / "dist" / "index.html",
        Path.cwd() / "dist" / "index.html",
    ]
    for index_file in local_dirs:
        if index_file.exists():
            return Response(
                content=index_file.read_bytes(),
                media_type="text/html",
            )

    return Response(
        content=b"Desk UI not available. Run 'pnpm build' in frontend/ or install framework-m with bundled UI.",
        status_code=404,
    )


# =============================================================================
# Application Lifecycle
# =============================================================================


@asynccontextmanager
async def app_lifespan(app: Litestar) -> AsyncGenerator[None, None]:
    """Application lifespan context manager.

    Handles startup and shutdown tasks:
    - Startup: Initialize container, database connections, discover DocTypes
    - Shutdown: Close database connections, cleanup resources

    Args:
        app: The Litestar application instance

    Yields:
        None during the application's running state
    """
    # ==========================================================================
    # Startup
    # ==========================================================================
    container = Container()
    connection_factory = ConnectionFactory()
    session_factory = SessionFactory()

    # Configure database if DATABASE_URL is set
    database_url = os.environ.get("DATABASE_URL")
    if database_url:
        connection_factory.configure({"default": database_url})
        session_factory.configure(connection_factory)

        # Create tables for all registered DocTypes
        from framework_m_core.registry import MetaRegistry
        from sqlalchemy import MetaData

        from framework_m_standard.adapters.db.repository_factory import (
            RepositoryFactory,
        )
        from framework_m_standard.adapters.db.schema_mapper import SchemaMapper

        registry = MetaRegistry.get_instance()
        metadata = MetaData()
        schema_mapper = SchemaMapper()

        # Create table definitions for each registered DocType
        for doctype_name in registry.list_doctypes():
            try:
                doctype_class = registry.get_doctype(doctype_name)
                if doctype_class is not None and doctype_class.get_api_resource():
                    schema_mapper.create_tables(doctype_class, metadata)
            except Exception:
                pass  # Skip doctype if it fails

        # Create all tables in the database
        engine = connection_factory.get_engine("default")
        async with engine.begin() as conn:
            await conn.run_sync(metadata.create_all)

        # Create RepositoryFactory with metadata and session_factory
        repo_factory = RepositoryFactory(metadata, session_factory)
        app.state.repository_factory = repo_factory
    else:
        app.state.repository_factory = None

    # Store container in app state for access in routes
    app.state.container = container

    # Note: DocTypes are registered in create_app() before route creation

    yield

    # ==========================================================================
    # Shutdown
    # ==========================================================================
    # Close database connections
    if database_url:
        await connection_factory.dispose_all()


# =============================================================================
# Application Factory
# =============================================================================


def create_app() -> Litestar:
    """Create and configure the Litestar application.

    This factory function creates a fully configured Litestar app with:
    - CORS configured for development (allows all origins)
    - Exception handlers for domain exceptions
    - OpenAPI documentation with Swagger UI
    - Health check endpoint
    - Application lifecycle management

    Returns:
        Configured Litestar application instance

    Example:
        app = create_app()

        # For production, configure via environment:
        # CORS_ORIGINS=https://example.com
    """
    # CORS Configuration (development defaults)
    cors_config = CORSConfig(
        allow_origins=["*"],  # TODO: Configure from environment for production
        allow_methods=["*"],
        allow_headers=["*"],
        allow_credentials=True,
    )

    # OpenAPI Configuration
    openapi_config = OpenAPIConfig(
        title="Framework M API",
        version="0.2.0",
        description="A modern, metadata-driven business application framework",
        path="/schema",
        render_plugins=[
            SwaggerRenderPlugin(),
            RedocRenderPlugin(),
        ],
        # Security scheme for header-based authentication
        components=Components(
            security_schemes={
                "HeaderAuth": SecurityScheme(
                    type="apiKey",
                    name="x-user-id",
                    security_scheme_in="header",
                    description="User ID for authentication. Required for protected endpoints.",
                ),
                "RolesHeader": SecurityScheme(
                    type="apiKey",
                    name="x-roles",
                    security_scheme_in="header",
                    description="Comma-separated list of roles (e.g., 'Manager,Employee').",
                ),
            },
        ),
    )

    # Exception Handlers - type: ignore needed for union return types
    exception_handlers = {
        ValidationError: validation_error_handler,
        PermissionDeniedError: permission_denied_handler,
        DocTypeNotFoundError: not_found_handler,
        EntityNotFoundError: not_found_handler,
        DuplicateNameError: duplicate_name_handler,
        FrameworkError: framework_error_handler,
    }

    # Static Files Configuration
    static_files_config = _create_static_files_config()

    # Auto-discover DocTypes from installed apps via entry points
    from importlib.metadata import entry_points

    from framework_m_core.registry import MetaRegistry

    registry = MetaRegistry.get_instance()

    # First, discover framework's core DocTypes
    core_count = registry.discover_doctypes("framework_m_core.doctypes")
    if core_count > 0:
        print(f"Discovered {core_count} core DocType(s) from framework")

    # Then discover DocTypes from all installed apps registered via entry points
    eps = entry_points(group="framework_m.apps")
    for ep in eps:
        try:
            # Load the app module (returns the app dict with metadata)
            ep.load()

            # Get the module path (e.g., "my_app" from "my_app:app")
            module_path = ep.module.split(":")[0]

            # Try namespaced structure first: <app_name>.doctypes
            doctypes_package = f"{module_path}.doctypes"
            count = registry.discover_doctypes(doctypes_package)

            if count == 0:
                # Fallback: scan the entire module (legacy flat structure)
                count = registry.discover_doctypes(module_path)

            if count > 0:
                print(f"Discovered {count} DocType(s) from app '{ep.name}'")
        except Exception as e:
            # Log but don't fail startup if an app fails to load
            print(f"Warning: Failed to load app '{ep.name}': {e}")

    # Build route handlers list
    route_handlers: list[Any] = [
        root_redirect,  # Redirect / to /desk/
        serve_desk_root,  # Serve Desk UI at /desk/
        serve_desk_spa,  # Catchall for Desk SPA routing
        health_check,
        auth_routes_router,
        metadata_router,
        workflow_router,
    ]

    # Add auto-CRUD routes for DocTypes with api_resource=True
    try:
        crud_router = create_meta_router()
        route_handlers.append(crud_router)
    except Exception:
        # No DocTypes registered yet, skip CRUD routes
        pass

    # Add WebSocket router for real-time streaming
    websocket_router = create_websocket_router()
    route_handlers.append(websocket_router)

    # Create and return app
    app = Litestar(
        route_handlers=route_handlers,
        middleware=[
            create_auth_middleware(
                require_auth=False,  # Don't require auth by default (for development)
                excluded_paths=["/health", "/schema", "/api/meta"],
            ),
        ],
        cors_config=cors_config,
        openapi_config=openapi_config,
        exception_handlers=exception_handlers,  # type: ignore[arg-type]
        lifespan=[app_lifespan],
        static_files_config=static_files_config,
        debug=True,  # TODO: Configure from environment
    )

    return app


def _get_bundled_static_path() -> Path | None:
    """Get path to bundled Desk static files from package.

    Checks if framework-m package includes bundled static files
    (pre-built Desk UI from CI pipeline).

    Returns:
        Path to bundled static directory, or None if not available
    """
    try:
        # Try to get bundled static files from framework_m package
        static_dir = files("framework_m") / "static"
        # Check if it's a directory with files
        if static_dir.is_dir():
            return Path(str(static_dir))
    except Exception:
        # Package not installed or static/ doesn't exist
        pass
    return None


def _create_static_files_config() -> list[StaticFilesConfig]:
    """Create static files configuration.

    Serves static assets (JS/CSS/images) at /desk/assets/* to avoid conflicts
    with API routes. HTML is served via route handlers for SPA routing support.

    Priority order:
    1. Bundled static files from framework-m package (pre-built Desk)
    2. Local development static directories (frontend/dist, dist/, etc.)

    Returns:
        List of StaticFilesConfig instances
    """
    from pathlib import Path

    configs: list[StaticFilesConfig] = []

    # Check for bundled static files first (from PyPI package)
    bundled_path = _get_bundled_static_path()
    if bundled_path:
        # Serve static assets (JS/CSS/images) at /desk/assets/*
        # DO NOT use html_mode=True here - HTML is handled by route handlers
        assets_dir = bundled_path / "assets"
        if assets_dir.exists():
            configs.append(
                StaticFilesConfig(
                    path="/desk/assets",
                    directories=[assets_dir],
                    html_mode=False,
                )
            )
        return configs

    # Fallback to local development directories
    static_dirs = [
        Path.cwd() / "frontend" / "dist",
        Path.cwd() / "dist",
        Path.cwd() / "static" / "dist",
    ]

    # Find first existing directory
    static_path: Path | None = None
    for d in static_dirs:
        if d.exists() and d.is_dir():
            static_path = d
            break

    if static_path is None:
        # No static files found, return empty config
        return []

    # Serve local development static assets at /desk/assets/*
    assets_dir = static_path / "assets"
    if assets_dir.exists():
        configs.append(
            StaticFilesConfig(
                path="/desk/assets",
                directories=[assets_dir],
                html_mode=False,
            )
        )

    return configs


def get_asset_url(asset_path: str) -> str:
    """Get the URL for a static asset.

    If CDN is configured, returns CDN URL. Otherwise returns local URL.
    This function can be used in templates to generate asset URLs.

    Args:
        asset_path: Path to the asset (e.g., 'js/main.js')

    Returns:
        Full URL to the asset

    Example:
        >>> get_asset_url('js/main.js')
        'https://cdn.example.com/assets/js/main.js'  # if CDN configured
        '/assets/js/main.js'  # if no CDN
    """
    config = load_config()
    frontend_config = config.get("frontend", {})
    cdn_url = frontend_config.get("cdn_url")

    if cdn_url:
        # Ensure trailing slash
        if not cdn_url.endswith("/"):
            cdn_url += "/"
        return f"{cdn_url}{asset_path.lstrip('/')}"

    return f"/assets/{asset_path.lstrip('/')}"


__all__ = ["create_app"]
