"""Serve CLI Command - Enhanced m start with frontend dev server support.

This module extends the basic `m start` command to support frontend development
with automatic scaffolding and concurrent backend+frontend servers.

Architecture:
- No global state - all paths passed explicitly
- Process management via subprocess (Popen for concurrent servers)
- Explicit error handling and cleanup
- Frappe-like developer experience: m start shows UI immediately

Usage:
    m start                      # Backend + bundled Desk UI
    m start --with-frontend      # Backend + Vite dev server (auto-scaffold)
    m start --reload             # Backend with auto-reload
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path
from typing import Annotated

import cyclopts


def _check_frontend_exists(frontend_dir: Path) -> bool:
    """Check if frontend directory exists and is valid.

    Args:
        frontend_dir: Path to frontend directory

    Returns:
        True if directory exists and has package.json

    Example:
        >>> _check_frontend_exists(Path("frontend"))
        True
    """
    return frontend_dir.exists() and (frontend_dir / "package.json").exists()


def _scaffold_frontend(target: Path) -> None:
    """Scaffold frontend from template using init_frontend_command.

    Args:
        target: Target directory for frontend

    Raises:
        RuntimeError: If scaffolding fails
    """
    from framework_m_core.cli.init import init_frontend_command

    print(f"No frontend found at {target}")
    print("Scaffolding frontend from template...")
    try:
        init_frontend_command(target=target)
    except Exception as e:
        msg = f"Failed to scaffold frontend: {e}"
        raise RuntimeError(msg) from e


def _start_backend_only(
    port: int,
    reload: bool,
    host: str,
    app: str | None,
) -> None:
    """Start backend serving bundled static Desk.

    Delegates to framework-m-standard's start command.

    Args:
        port: Port to bind to
        reload: Enable auto-reload
        host: Host to bind to
        app: Explicit app path

    Example:
        >>> _start_backend_only(8000, False, "127.0.0.1", None)
        # Starts uvicorn on port 8000
    """
    from framework_m_standard.cli.start import start_command as std_start

    std_start(
        app=app,
        host=host,
        port=port,
        reload=reload,
    )


def _start_with_frontend(
    port: int,
    reload: bool,
    host: str,
    app: str | None,
    frontend_dir: Path,
) -> None:
    """Start backend + frontend dev server concurrently.

    Creates two processes:
    1. Backend (uvicorn) - serves API and proxies to frontend
    2. Frontend (pnpm dev) - Vite dev server with HMR

    Args:
        port: Backend port
        reload: Backend auto-reload
        host: Backend host
        app: Explicit app path
        frontend_dir: Path to frontend directory

    Raises:
        RuntimeError: If frontend setup fails
    """
    # Auto-scaffold if frontend doesn't exist
    if not _check_frontend_exists(frontend_dir):
        _scaffold_frontend(frontend_dir)

    # Find app path for backend
    from framework_m_standard.cli.start import find_app, get_pythonpath

    app_path = find_app(app)

    # Build backend command
    import os

    env = os.environ.copy()
    env["PYTHONPATH"] = get_pythonpath()

    backend_cmd = [
        sys.executable,
        "-m",
        "uvicorn",
        app_path,
        "--host",
        host,
        "--port",
        str(port),
    ]

    if reload:
        backend_cmd.append("--reload")

    # Start backend process
    print(f"Starting backend: {app_path}")
    print(f"  URL: http://{host}:{port}")
    backend = subprocess.Popen(backend_cmd, env=env)

    # Start frontend process
    print(f"\nStarting frontend dev server: {frontend_dir}")
    print("  Vite will show the frontend URL")
    frontend = subprocess.Popen(
        ["pnpm", "dev"],
        cwd=str(frontend_dir),
    )

    # Wait for both processes
    try:
        print("\n✓ Servers running. Press Ctrl+C to stop.\n")
        backend.wait()
        frontend.wait()
    except KeyboardInterrupt:
        print("\n\nStopping servers...")
        backend.terminate()
        frontend.terminate()
        backend.wait()
        frontend.wait()
        print("✓ Servers stopped.")


def serve_command(
    port: Annotated[
        int,
        cyclopts.Parameter(name="--port", help="Backend port (default: 8000)"),
    ] = 8000,
    reload: Annotated[
        bool,
        cyclopts.Parameter(name="--reload", help="Enable backend auto-reload"),
    ] = False,
    with_frontend: Annotated[
        bool,
        cyclopts.Parameter(
            name="--with-frontend",
            help="Start Vite dev server for frontend customization",
        ),
    ] = False,
    host: Annotated[
        str,
        cyclopts.Parameter(name="--host", help="Host to bind to (default: 127.0.0.1)"),
    ] = "127.0.0.1",
    app: Annotated[
        str | None,
        cyclopts.Parameter(name="--app", help="App path (module:attribute format)"),
    ] = None,
    frontend_dir: Annotated[
        Path,
        cyclopts.Parameter(
            name="--frontend-dir",
            help="Frontend directory path (default: ./frontend)",
        ),
    ] = Path("frontend"),
) -> None:
    """Start Framework M application.

    By default, starts backend serving bundled Desk UI.
    Use --with-frontend to start concurrent backend + Vite dev server.

    Examples:
        m start                      # Backend + bundled Desk
        m start --with-frontend      # Backend + Vite dev (auto-scaffold)
        m start --reload             # Backend with auto-reload
        m start --port 3000          # Custom port

    Architecture Notes:
        - No global state - all paths passed explicitly
        - Process cleanup on Ctrl+C (no orphaned processes)
        - Auto-scaffolds frontend if missing (Frappe-like DX)
    """
    if with_frontend:
        _start_with_frontend(
            port=port,
            reload=reload,
            host=host,
            app=app,
            frontend_dir=frontend_dir,
        )
    else:
        _start_backend_only(
            port=port,
            reload=reload,
            host=host,
            app=app,
        )


__all__ = ["serve_command"]
