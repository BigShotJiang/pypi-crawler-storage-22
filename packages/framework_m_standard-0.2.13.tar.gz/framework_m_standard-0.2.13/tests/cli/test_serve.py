"""Tests for serve CLI command.

This module tests the enhanced m start command with frontend support:
- Backend-only mode
- Frontend dev server mode
- Auto-scaffolding
- Process management
"""

from __future__ import annotations

import subprocess
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from framework_m_standard.cli.serve import (
    _check_frontend_exists,
    _scaffold_frontend,
    _start_backend_only,
    _start_with_frontend,
    serve_command,
)


class TestCheckFrontendExists:
    """Tests for _check_frontend_exists helper."""

    def test_returns_true_when_frontend_valid(self, tmp_path: Path) -> None:
        """Should return True when frontend dir has package.json."""
        frontend_dir = tmp_path / "frontend"
        frontend_dir.mkdir()
        (frontend_dir / "package.json").write_text("{}")

        assert _check_frontend_exists(frontend_dir) is True

    def test_returns_false_when_no_package_json(self, tmp_path: Path) -> None:
        """Should return False when package.json missing."""
        frontend_dir = tmp_path / "frontend"
        frontend_dir.mkdir()

        assert _check_frontend_exists(frontend_dir) is False

    def test_returns_false_when_dir_not_exists(self, tmp_path: Path) -> None:
        """Should return False when directory doesn't exist."""
        frontend_dir = tmp_path / "frontend"

        assert _check_frontend_exists(frontend_dir) is False


class TestScaffoldFrontend:
    """Tests for _scaffold_frontend helper."""

    @patch("framework_m_core.cli.init.init_frontend_command")
    def test_calls_init_frontend_command(
        self, mock_init: MagicMock, tmp_path: Path
    ) -> None:
        """Should delegate to init_frontend_command."""
        target = tmp_path / "frontend"

        _scaffold_frontend(target)

        mock_init.assert_called_once_with(target=target)

    @patch("framework_m_core.cli.init.init_frontend_command")
    def test_raises_runtime_error_on_failure(
        self, mock_init: MagicMock, tmp_path: Path
    ) -> None:
        """Should raise RuntimeError if init fails."""
        mock_init.side_effect = Exception("Init failed")
        target = tmp_path / "frontend"

        with pytest.raises(RuntimeError, match="Failed to scaffold frontend"):
            _scaffold_frontend(target)


class TestStartBackendOnly:
    """Tests for _start_backend_only helper."""

    @patch("framework_m_standard.cli.start.start_command")
    def test_delegates_to_standard_start(self, mock_std_start: MagicMock) -> None:
        """Should call framework-m-standard's start command."""
        _start_backend_only(
            port=8000,
            reload=True,
            host="0.0.0.0",
            app="custom:app",
        )

        mock_std_start.assert_called_once_with(
            app="custom:app",
            host="0.0.0.0",
            port=8000,
            reload=True,
        )


class TestStartWithFrontend:
    """Tests for _start_with_frontend helper."""

    @patch("framework_m_standard.cli.serve.subprocess.Popen")
    @patch("framework_m_standard.cli.start.get_pythonpath")
    @patch("framework_m_standard.cli.start.find_app")
    @patch("framework_m_standard.cli.serve._check_frontend_exists")
    def test_starts_both_processes(
        self,
        mock_check: MagicMock,
        mock_find_app: MagicMock,
        mock_get_pythonpath: MagicMock,
        mock_popen: MagicMock,
        tmp_path: Path,
    ) -> None:
        """Should start backend and frontend processes."""
        # Setup mocks
        mock_check.return_value = True
        mock_find_app.return_value = "app:app"
        mock_get_pythonpath.return_value = "/project/src"

        backend_proc = MagicMock()
        frontend_proc = MagicMock()
        # First call raises KeyboardInterrupt, subsequent calls return None
        backend_proc.wait.side_effect = [KeyboardInterrupt, None]
        frontend_proc.wait.return_value = None
        mock_popen.side_effect = [backend_proc, frontend_proc]

        frontend_dir = tmp_path / "frontend"

        # Execute
        _start_with_frontend(
            port=8000,
            reload=True,
            host="127.0.0.1",
            app=None,
            frontend_dir=frontend_dir,
        )

        # Verify backend started
        assert mock_popen.call_count == 2
        backend_call = mock_popen.call_args_list[0]
        assert "uvicorn" in backend_call[0][0]
        assert "--port" in backend_call[0][0]
        assert "8000" in backend_call[0][0]
        assert "--reload" in backend_call[0][0]

        # Verify frontend started
        frontend_call = mock_popen.call_args_list[1]
        assert frontend_call[0][0] == ["pnpm", "dev"]
        assert frontend_call[1]["cwd"] == str(frontend_dir)

    @patch("framework_m_standard.cli.serve._scaffold_frontend")
    @patch("framework_m_standard.cli.serve._check_frontend_exists")
    def test_scaffolds_frontend_if_missing(
        self,
        mock_check: MagicMock,
        mock_scaffold: MagicMock,
        tmp_path: Path,
    ) -> None:
        """Should scaffold frontend if it doesn't exist."""
        # Prevent actual process starting
        mock_check.return_value = False

        frontend_dir = tmp_path / "frontend"

        with (
            patch("framework_m_standard.cli.start.find_app"),
            patch("framework_m_standard.cli.start.get_pythonpath"),
            patch("framework_m_standard.cli.serve.subprocess.Popen") as mock_popen,
        ):
            backend_proc = MagicMock()
            frontend_proc = MagicMock()
            # First call raises KeyboardInterrupt, subsequent calls return None
            backend_proc.wait.side_effect = [KeyboardInterrupt, None]
            frontend_proc.wait.return_value = None
            mock_popen.side_effect = [backend_proc, frontend_proc]

            _start_with_frontend(
                port=8000,
                reload=False,
                host="127.0.0.1",
                app=None,
                frontend_dir=frontend_dir,
            )

            mock_scaffold.assert_called_once_with(frontend_dir)

    @patch("framework_m_standard.cli.serve.subprocess.Popen")
    @patch("framework_m_standard.cli.start.get_pythonpath")
    @patch("framework_m_standard.cli.start.find_app")
    @patch("framework_m_standard.cli.serve._check_frontend_exists")
    def test_handles_keyboard_interrupt_gracefully(
        self,
        mock_check: MagicMock,
        mock_find_app: MagicMock,
        mock_get_pythonpath: MagicMock,
        mock_popen: MagicMock,
        tmp_path: Path,
    ) -> None:
        """Should terminate both processes on Ctrl+C."""
        mock_check.return_value = True
        mock_find_app.return_value = "app:app"
        mock_get_pythonpath.return_value = "/project/src"

        backend_proc = MagicMock()
        frontend_proc = MagicMock()
        # First call raises KeyboardInterrupt, subsequent calls return None
        backend_proc.wait.side_effect = [KeyboardInterrupt, None]
        frontend_proc.wait.return_value = None
        mock_popen.side_effect = [backend_proc, frontend_proc]

        frontend_dir = tmp_path / "frontend"

        _start_with_frontend(
            port=8000,
            reload=False,
            host="127.0.0.1",
            app=None,
            frontend_dir=frontend_dir,
        )

        # Verify both processes terminated
        backend_proc.terminate.assert_called_once()
        frontend_proc.terminate.assert_called_once()
        assert backend_proc.wait.call_count == 2  # Initial wait + cleanup wait
        frontend_proc.wait.assert_called_once()


class TestServeCommand:
    """Tests for serve_command entry point."""

    @patch("framework_m_standard.cli.serve._start_backend_only")
    def test_backend_only_mode(self, mock_backend: MagicMock) -> None:
        """Should start backend only when with_frontend=False."""
        serve_command(
            port=3000,
            reload=True,
            with_frontend=False,
            host="0.0.0.0",
            app="custom:app",
            frontend_dir=Path("frontend"),
        )

        mock_backend.assert_called_once_with(
            port=3000,
            reload=True,
            host="0.0.0.0",
            app="custom:app",
        )

    @patch("framework_m_standard.cli.serve._start_with_frontend")
    def test_with_frontend_mode(self, mock_with_frontend: MagicMock) -> None:
        """Should start backend+frontend when with_frontend=True."""
        serve_command(
            port=3000,
            reload=True,
            with_frontend=True,
            host="0.0.0.0",
            app="custom:app",
            frontend_dir=Path("frontend"),
        )

        mock_with_frontend.assert_called_once_with(
            port=3000,
            reload=True,
            host="0.0.0.0",
            app="custom:app",
            frontend_dir=Path("frontend"),
        )


class TestServeCLIIntegration:
    """Integration tests for m start command."""

    def test_start_command_available(self) -> None:
        """m start command should be registered."""
        result = subprocess.run(
            ["python", "-m", "framework_m_core.cli.main", "start", "--help"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "Start Framework M application" in result.stdout
        assert "--with-frontend" in result.stdout

    def test_start_command_shows_default_values(self) -> None:
        """m start --help should show default port 8000."""
        result = subprocess.run(
            ["python", "-m", "framework_m_core.cli.main", "start", "--help"],
            capture_output=True,
            text=True,
        )
        assert "8000" in result.stdout
        assert "127.0.0.1" in result.stdout
