# Changelog

## framework-m-standard v0.2.8

### Bug Fixes

- add ruff code style badge to README (3bd7674)


## framework-m-standard v0.2.7

### Bug Fixes

- add pipeline status badge to README (c2dc70f)


## framework-m-standard v0.2.6

### Bug Fixes

- enforce timezone-aware datetimes and fix test (b68332a)

