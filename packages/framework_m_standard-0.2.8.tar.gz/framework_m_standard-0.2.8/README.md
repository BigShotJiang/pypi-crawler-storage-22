# Framework M Standard

[![PyPI version](https://badge.fury.io/py/framework-m-standard.svg)](https://badge.fury.io/py/framework-m-standard)
[![Python 3.12+](https://img.shields.io/badge/python-3.12+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![GitLab Pipeline Status](https://gitlab.com/castlecraft/framework-m/badges/main/pipeline.svg)](https://gitlab.com/castlecraft/framework-m/-/pipelines)
[![Code style: ruff](https://img.shields.io/badge/code%20style-ruff-000000.svg)](https://github.com/astral-sh/ruff)

Default adapters for Framework M - batteries included.

## Installation

```bash
pip install framework-m-standard
```

Or with `uv`:

```bash
uv add framework-m-standard
```

## What's Included

### Database Adapters

- **SQLAlchemy Repository** - Generic repository implementation with async support
- **Schema Mapper** - Automatic Pydantic → SQLAlchemy table generation
- **Migration System** - Alembic integration with auto-migration detection
- **Unit of Work** - Transaction management with optimistic concurrency control

### Web Framework

- **Litestar Integration** - REST API with automatic OpenAPI docs
- **Auth Guards** - JWT authentication and permission checking
- **Exception Handlers** - Consistent error responses

### Cache & Events

- **Redis Cache** - Distributed caching with TTL support
- **Redis Event Bus** - Pub/sub for domain events

### Background Jobs

- **Taskiq Integration** - Background job processing with NATS JetStream
- **Outbox Pattern** - Reliable event publishing

## Supported Databases

| Database | Status |
|----------|--------|
| PostgreSQL | ✅ Full support |
| SQLite | ✅ For testing |
| MySQL | 🔜 Planned |

## Usage

This package is typically used as a dependency of `framework-m`.
For most applications, install the full `framework-m` package instead.

```python
from framework_m_standard.adapters.db import GenericRepository
from framework_m_standard.adapters.cache import RedisCache
from framework_m_standard.adapters.web import create_litestar_app
```

## License

MIT License - see [LICENSE](https://gitlab.com/castlecraft/framework-m/blob/main/LICENSE) for details.
