"""Framework M Standard - Default Adapters Package."""
