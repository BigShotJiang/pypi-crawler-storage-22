"""InitEngine - Initialize SQLAlchemy database engine.

This bootstrap step creates the SQLAlchemy async engine from
container configuration. It runs first (order=10) to ensure
the database connection is available for subsequent steps.
"""

from typing import Any

from framework_m_core.interfaces.bootstrap import BootstrapProtocol


class InitEngine:
    """
    Initialize SQLAlchemy engine from container configuration.

    This step reads the database URL from container.config and creates
    an async SQLAlchemy engine. The engine is bound to the DI container
    for use by other services.

    Order: 10 (runs first)

    Example configuration:
        container.config.from_dict({
            "database_url": "postgresql+asyncpg://user:pass@localhost/db",
            "echo": True,  # Optional: log SQL statements
            "pool_size": 5,  # Optional: connection pool size
        })

    After this step runs:
        - container.engine() returns the SQLAlchemy engine
        - Database connections are ready for schema sync and queries

    MX Override Example (MongoDB):
        class InitMongoEngine:
            name = "init_engine"  # Same name overrides default
            order = 10

            async def run(self, container: Container) -> None:
                from motor.motor_asyncio import AsyncIOMotorClient

                client = AsyncIOMotorClient(container.config.mongo_uri())
                container.db_client.override(client)
    """

    name = "init_engine"
    order = 10

    async def run(self, container: Any) -> None:
        """
        Initialize SQLAlchemy engine and bind to container.

        Args:
            container: DI container with config.database_url

        Raises:
            ValueError: If database_url not configured
        """
        from sqlalchemy.ext.asyncio import create_async_engine

        # Get database URL from config
        database_url = container.config.database_url()
        if not database_url:
            msg = "database_url must be configured before running InitEngine"
            raise ValueError(msg)

        # Optional engine configuration
        echo = container.config.get("echo", default=False)
        pool_size = container.config.get("pool_size", default=5)

        # Create async engine
        engine = create_async_engine(
            database_url,
            echo=echo,
            pool_size=pool_size,
            # Future mode for SQLAlchemy 2.0+ compatibility
            future=True,
        )

        # Bind engine to container
        # This makes it available to other services via dependency injection
        if hasattr(container, "engine"):
            container.engine.override(engine)
        else:
            # Fallback: store in config for manual access
            container.config.engine.from_value(engine)


# Verify protocol compliance
assert isinstance(InitEngine(), BootstrapProtocol)
