"""Bootstrap runner - Discovers and executes bootstrap steps from entry points.

This module provides the BootstrapRunner class which discovers bootstrap steps
from the framework_m.bootstrap entry point group, handles overrides by name,
sorts steps by order, and executes them sequentially.
"""

from __future__ import annotations

from typing import Any

from framework_m_core.interfaces.bootstrap import BootstrapProtocol


class BootstrapRunner:
    """
    Discovers and executes bootstrap steps from entry points.

    The runner discovers all registered bootstrap steps from the
    framework_m.bootstrap entry point group, allows MX packages to
    override default steps by name (last registered wins), sorts
    steps by order property, and executes them sequentially.

    Example Usage:
        from framework_m_core.container import Container
        from framework_m_standard.bootstrap.runner import BootstrapRunner

        # Create container with config
        container = Container()
        container.config.from_dict({
            "database_url": "postgresql+asyncpg://localhost/db"
        })

        # Run bootstrap sequence
        runner = BootstrapRunner()
        await runner.run(container)

    MX Override Example:
        # In framework-mx-mongo's pyproject.toml:
        [project.entry-points."framework_m.bootstrap"]
        init_engine = "framework_mx_mongo.bootstrap:MongoInitEngine"  # Overrides default

        # The MongoInitEngine has same name as default InitEngine,
        # so it replaces the SQLAlchemy version in the sequence.

    Entry Point Discovery:
        The runner uses importlib.metadata.entry_points() to discover
        all registered bootstrap steps. Steps are grouped by name,
        and the last registered step wins (allowing overrides).

    Execution Order:
        Steps are sorted by their order property (ascending).
        Default sequence: 10, 20, 30, 40
        MX packages can insert at 15, 25, 35, etc.
    """

    def __init__(self) -> None:
        """Initialize bootstrap runner."""
        self._steps: dict[str, BootstrapProtocol] = {}

    def discover_steps(self) -> dict[str, BootstrapProtocol]:
        """
        Discover bootstrap steps from entry points.

        Scans the framework_m.bootstrap entry point group and loads
        all registered steps. If multiple steps have the same name,
        the last one registered wins (allowing MX overrides).

        Returns:
            Dictionary mapping step name to step instance.
            Later registrations override earlier ones with same name.

        Example:
            runner = BootstrapRunner()
            steps = runner.discover_steps()
            # steps = {
            #     "init_engine": InitEngine(),
            #     "init_registries": InitRegistries(),
            #     "sync_schema": SyncSchema(),
            #     "init_adapters": InitAdapters(),
            # }
        """
        try:
            from importlib.metadata import entry_points
        except ImportError:
            # Python < 3.8 fallback
            return {}

        steps: dict[str, BootstrapProtocol] = {}

        try:
            # Get all bootstrap entry points
            eps = entry_points(group="framework_m.bootstrap")

            # Load each entry point
            for ep in eps:
                try:
                    # Load the step class
                    step_class = ep.load()

                    # Instantiate the step
                    step = step_class()

                    # Verify it implements the protocol
                    if not isinstance(step, BootstrapProtocol):
                        print(
                            f"[BootstrapRunner] Warning: {ep.name} does not implement BootstrapProtocol, skipping"
                        )
                        continue

                    # Store by step name (allows override by name)
                    # If multiple packages register same name, last one wins
                    if step.name in steps:
                        print(
                            f"[BootstrapRunner] Override: {step.name} (was: {steps[step.name].__class__.__name__}, "
                            f"now: {step.__class__.__name__})"
                        )

                    steps[step.name] = step

                except Exception as e:
                    print(f"[BootstrapRunner] Error loading {ep.name}: {e}, skipping")
                    continue

        except Exception as e:
            print(f"[BootstrapRunner] Error discovering entry points: {e}")

        self._steps = steps
        return steps

    def get_sorted_steps(self) -> list[BootstrapProtocol]:
        """
        Get bootstrap steps sorted by order property.

        Returns steps in execution order (sorted by order ascending).
        Lower order values run first (e.g., 10 before 20).

        Returns:
            List of bootstrap steps sorted by order property.

        Example:
            runner = BootstrapRunner()
            runner.discover_steps()
            steps = runner.get_sorted_steps()
            # steps = [
            #     InitEngine(order=10),
            #     InitRegistries(order=20),
            #     SyncSchema(order=30),
            #     InitAdapters(order=40),
            # ]
        """
        if not self._steps:
            self.discover_steps()

        # Sort by order property
        sorted_steps = sorted(self._steps.values(), key=lambda s: s.order)
        return sorted_steps

    async def run(self, container: Any, *, verbose: bool = True) -> None:
        """
        Discover and execute all bootstrap steps in order.

        This is the main entry point for the bootstrap process.
        It discovers steps from entry points, sorts them by order,
        and executes each step's run() method sequentially.

        Args:
            container: DI container to pass to each bootstrap step
            verbose: Whether to print progress messages (default: True)

        Example:
            container = Container()
            container.config.from_dict({"database_url": "postgresql://..."})

            runner = BootstrapRunner()
            await runner.run(container)
        """
        # Discover steps from entry points
        steps_dict = self.discover_steps()

        if not steps_dict:
            if verbose:
                print("[BootstrapRunner] No bootstrap steps found")
            return

        # Get sorted steps
        sorted_steps = self.get_sorted_steps()

        if verbose:
            print(f"[BootstrapRunner] Executing {len(sorted_steps)} bootstrap steps...")

        # Execute each step in order
        for step in sorted_steps:
            if verbose:
                print(f"[BootstrapRunner] [{step.order:2d}] Running {step.name}...")

            try:
                await step.run(container)

                if verbose:
                    print(f"[BootstrapRunner] [{step.order:2d}] ✓ {step.name} complete")

            except Exception as e:
                print(f"[BootstrapRunner] [{step.order:2d}] ✗ {step.name} failed: {e}")
                # Continue with remaining steps
                # In production, you might want to stop on error
                continue

        if verbose:
            print("[BootstrapRunner] Bootstrap sequence complete")

    def get_step(self, name: str) -> BootstrapProtocol | None:
        """
        Get a specific bootstrap step by name.

        Args:
            name: Name of the bootstrap step

        Returns:
            Bootstrap step instance or None if not found

        Example:
            runner = BootstrapRunner()
            runner.discover_steps()
            engine_step = runner.get_step("init_engine")
        """
        if not self._steps:
            self.discover_steps()

        return self._steps.get(name)

    def list_steps(self) -> list[tuple[int, str]]:
        """
        List all discovered bootstrap steps.

        Returns:
            List of (order, name) tuples sorted by order

        Example:
            runner = BootstrapRunner()
            runner.discover_steps()
            steps = runner.list_steps()
            # [(10, 'init_engine'), (20, 'init_registries'), ...]
        """
        if not self._steps:
            self.discover_steps()

        sorted_steps = self.get_sorted_steps()
        return [(step.order, step.name) for step in sorted_steps]
