"""SyncSchema - Create/update database tables for registered DocTypes.

This bootstrap step runs the SchemaMapper to create database tables
for all registered DocTypes. It runs after registries are initialized
(order=30) and before adapters are bound.
"""

from typing import Any

from framework_m_core.interfaces.bootstrap import BootstrapProtocol


class SyncSchema:
    """
    Create/update database schema for all registered DocTypes.

    This step runs SchemaMapper.create_tables() to ensure that all
    registered DocTypes have corresponding database tables. It uses
    SQLAlchemy's create_all() which is safe to run multiple times
    (it won't recreate existing tables).

    Order: 30 (after registries, before adapters)

    What this step does:
        1. Get MetaRegistry with all registered DocTypes
        2. Get SchemaMapper instance
        3. Create SQLAlchemy MetaData and tables
        4. Run engine.create_all() to create tables
        5. Register tables in TableRegistry

    After this step runs:
        - All DocType tables exist in the database
        - TableRegistry has mapping of DocType name -> Table object
        - Schema changes are detected (future: migrations)

    Configuration:
        - Set config.auto_sync_schema=False to skip this step
        - Useful for production where migrations are managed externally

    MX Override Example (MongoDB):
        class SyncMongoSchema:
            name = "sync_schema"
            order = 30

            async def run(self, container: Container) -> None:
                from framework_mx_mongo.schema_mapper import MongoSchemaMapper

                registry = container.meta_registry()
                mapper = MongoSchemaMapper()

                # Create collections for each DocType
                for doctype_name in registry.list_doctypes():
                    doctype_class = registry.get_doctype(doctype_name)
                    await mapper.create_collection(doctype_class)
    """

    name = "sync_schema"
    order = 30

    async def run(self, container: Any) -> None:
        """
        Create database tables for all registered DocTypes.

        Args:
            container: DI container with engine, meta_registry, field_registry
        """
        # Check if auto_sync_schema is disabled
        auto_sync = container.config.get("auto_sync_schema", default=True)
        if not auto_sync:
            print("[SyncSchema] Skipped (auto_sync_schema=False)")
            return

        from framework_m_core.registry import MetaRegistry
        from sqlalchemy import MetaData

        from framework_m_standard.adapters.db.schema_mapper import SchemaMapper
        from framework_m_standard.adapters.db.table_registry import TableRegistry

        # Get registries
        meta_registry = MetaRegistry.get_instance()
        table_registry = TableRegistry()

        # Get engine from container
        engine = None
        if hasattr(container, "engine"):
            engine = container.engine()
        elif hasattr(container.config, "engine"):
            engine = container.config.engine()

        if not engine:
            print("[SyncSchema] Warning: No engine available, skipping schema sync")
            return

        # Create metadata for tables
        metadata = MetaData()

        # Get schema mapper
        schema_mapper = SchemaMapper()

        # Create tables for all registered DocTypes
        doctype_names = meta_registry.list_doctypes()
        if not doctype_names:
            print("[SyncSchema] No DocTypes registered, skipping schema sync")
            return

        print(f"[SyncSchema] Creating tables for {len(doctype_names)} DocTypes...")

        for doctype_name in doctype_names:
            try:
                doctype_class = meta_registry.get_doctype(doctype_name)

                # Use create_table (single) instead of create_tables (multi)
                # This returns the Table object which we can register
                table = schema_mapper.create_table(doctype_class, metadata)

                # Register table in TableRegistry
                table_registry.register_table(doctype_name, table)

                print(f"[SyncSchema]   ✓ {doctype_name} -> {table.name}")

            except Exception as e:
                print(f"[SyncSchema]   ✗ {doctype_name} - Error: {e}")
                # Continue with other DocTypes even if one fails

        # Create all tables in database
        async with engine.begin() as conn:
            await conn.run_sync(metadata.create_all)

        print(f"[SyncSchema] Schema sync complete ({len(doctype_names)} DocTypes)")


# Verify protocol compliance
assert isinstance(SyncSchema(), BootstrapProtocol)
