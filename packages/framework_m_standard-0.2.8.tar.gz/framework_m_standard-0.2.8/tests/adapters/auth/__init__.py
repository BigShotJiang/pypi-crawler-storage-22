"""Tests for auth adapters."""
