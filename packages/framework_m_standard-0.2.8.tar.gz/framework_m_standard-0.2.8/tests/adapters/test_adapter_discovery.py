"""Tests for adapter entry point discovery and auto-binding.

Following TDD methodology: Write failing tests first, then implement.

This module tests:
1. Adapter entry point registration (repository, schema_mapper, unit_of_work)
2. Adapter auto-discovery from entry points
3. DI container auto-binding with priority: Explicit > Entry Point > Default
4. MX package override scenarios
"""

from unittest.mock import MagicMock, patch

import pytest


class TestAdapterEntryPointGroups:
    """Test that adapter entry point groups are defined."""

    def test_repository_entry_point_group_exists(self) -> None:
        """framework_m.adapters.repository entry point group should exist."""
        try:
            from importlib.metadata import entry_points

            eps = entry_points(group="framework_m.adapters.repository")
            # Should not raise, even if empty
            assert eps is not None

        except ImportError:
            pytest.skip("importlib.metadata not available")

    def test_schema_mapper_entry_point_group_exists(self) -> None:
        """framework_m.adapters.schema_mapper entry point group should exist."""
        try:
            from importlib.metadata import entry_points

            eps = entry_points(group="framework_m.adapters.schema_mapper")
            assert eps is not None

        except ImportError:
            pytest.skip("importlib.metadata not available")

    def test_unit_of_work_entry_point_group_exists(self) -> None:
        """framework_m.adapters.unit_of_work entry point group should exist."""
        try:
            from importlib.metadata import entry_points

            eps = entry_points(group="framework_m.adapters.unit_of_work")
            assert eps is not None

        except ImportError:
            pytest.skip("importlib.metadata not available")

    def test_permission_entry_point_group_exists(self) -> None:
        """framework_m.adapters.permission entry point group should exist."""
        try:
            from importlib.metadata import entry_points

            eps = entry_points(group="framework_m.adapters.permission")
            assert eps is not None

        except ImportError:
            pytest.skip("importlib.metadata not available")

    def test_event_bus_entry_point_group_exists(self) -> None:
        """framework_m.adapters.event_bus entry point group should exist."""
        try:
            from importlib.metadata import entry_points

            eps = entry_points(group="framework_m.adapters.event_bus")
            assert eps is not None

        except ImportError:
            pytest.skip("importlib.metadata not available")


class TestDefaultAdapterRegistration:
    """Test that default adapters are registered via entry points."""

    def test_default_repository_registered(self) -> None:
        """Default repository adapter should be registered."""
        try:
            from importlib.metadata import entry_points

            eps = entry_points(group="framework_m.adapters.repository")
            ep_dict = {ep.name: ep for ep in eps}

            # Should have a default entry
            assert "default" in ep_dict

            # Should load to a repository adapter (may be overridden by MX packages)
            adapter_class = ep_dict["default"].load()
            # Check it's a valid class with expected repository methods
            assert hasattr(adapter_class, "__name__")
            # MX packages can override, so accept either GenericRepository or MongoGenericRepository
            assert "Repository" in adapter_class.__name__

        except ImportError:
            pytest.skip("importlib.metadata not available")

    def test_default_schema_mapper_registered(self) -> None:
        """Default schema mapper adapter should be registered."""
        try:
            from importlib.metadata import entry_points

            eps = entry_points(group="framework_m.adapters.schema_mapper")
            ep_dict = {ep.name: ep for ep in eps}

            assert "default" in ep_dict

            adapter_class = ep_dict["default"].load()
            # MX packages can override, so accept either SchemaMapper or MongoSchemaMapper
            assert "SchemaMapper" in adapter_class.__name__

        except ImportError:
            pytest.skip("importlib.metadata not available")

    def test_default_unit_of_work_registered(self) -> None:
        """Default unit of work adapter should be registered."""
        try:
            from importlib.metadata import entry_points

            eps = entry_points(group="framework_m.adapters.unit_of_work")
            ep_dict = {ep.name: ep for ep in eps}

            assert "default" in ep_dict

            adapter_class = ep_dict["default"].load()
            # MX packages can override, so accept SessionFactory or MongoSessionFactory
            assert (
                "SessionFactory" in adapter_class.__name__
                or "Factory" in adapter_class.__name__
            )

        except ImportError:
            pytest.skip("importlib.metadata not available")

    def test_default_permission_registered(self) -> None:
        """Default CitadelPolicyAdapter should be registered."""
        try:
            from importlib.metadata import entry_points

            eps = entry_points(group="framework_m.adapters.permission")
            ep_dict = {ep.name: ep for ep in eps}

            assert "default" in ep_dict

            adapter_class = ep_dict["default"].load()
            assert adapter_class.__name__ == "CitadelPolicyAdapter"

        except ImportError:
            pytest.skip("importlib.metadata not available")

    def test_default_event_bus_registered(self) -> None:
        """Default InMemoryEventBus should be registered."""
        try:
            from importlib.metadata import entry_points

            eps = entry_points(group="framework_m.adapters.event_bus")
            ep_dict = {ep.name: ep for ep in eps}

            assert "default" in ep_dict

            adapter_class = ep_dict["default"].load()
            assert adapter_class.__name__ == "InMemoryEventBus"

        except ImportError:
            pytest.skip("importlib.metadata not available")


class TestInitAdaptersAutoDiscovery:
    """Test InitAdapters discovers and binds adapters from entry points."""

    @pytest.mark.asyncio
    async def test_init_adapters_discovers_repository(self) -> None:
        """InitAdapters should discover and bind repository from entry points."""
        from framework_m_standard.bootstrap import InitAdapters

        # Create mock container
        container = MagicMock()
        container.repository = MagicMock()

        # Mock entry points
        class MockRepository:
            pass

        mock_ep = MagicMock(name="custom", load=lambda: MockRepository)

        with patch("importlib.metadata.entry_points", return_value=[mock_ep]):
            InitAdapters()
            # Should not raise
            # Will be implemented in next iteration

    @pytest.mark.asyncio
    async def test_init_adapters_discovers_schema_mapper(self) -> None:
        """InitAdapters should discover and bind schema_mapper from entry points."""
        from framework_m_standard.bootstrap import InitAdapters

        container = MagicMock()
        container.schema_mapper = MagicMock()

        class MockSchemaMapper:
            pass

        mock_ep = MagicMock(name="custom", load=lambda: MockSchemaMapper)

        with patch("importlib.metadata.entry_points", return_value=[mock_ep]):
            InitAdapters()
            # Implementation pending

    @pytest.mark.asyncio
    async def test_init_adapters_discovers_unit_of_work(self) -> None:
        """InitAdapters should discover and bind unit_of_work from entry points."""
        from framework_m_standard.bootstrap import InitAdapters

        container = MagicMock()
        container.unit_of_work = MagicMock()

        class MockUnitOfWork:
            pass

        mock_ep = MagicMock(name="custom", load=lambda: MockUnitOfWork)

        with patch("importlib.metadata.entry_points", return_value=[mock_ep]):
            InitAdapters()
            # Implementation pending


class TestAdapterBindingPriority:
    """Test adapter binding priority: Explicit > Entry Point > Default."""

    @pytest.mark.asyncio
    async def test_explicit_config_overrides_entry_point(self) -> None:
        """Explicit container override should take precedence over entry points."""
        # This tests the priority: Explicit > Entry Point
        # If user explicitly sets container.repository.override(CustomRepo),
        # entry points should not override it

        container = MagicMock()
        explicitly_set_adapter = MagicMock()
        container.repository = MagicMock()
        container.repository.override = MagicMock()

        # User explicitly sets adapter BEFORE InitAdapters runs
        container.repository.override(explicitly_set_adapter)

        # Now InitAdapters runs and discovers entry points
        # It should NOT override the explicit setting

        # Test pending implementation

    @pytest.mark.asyncio
    async def test_entry_point_overrides_default(self) -> None:
        """Entry point adapter should override default if no explicit config."""
        # This tests: Entry Point > Default

        container = MagicMock()
        container.repository = MagicMock()

        # No explicit override set
        # Entry point discovered
        # Should use entry point over default

        # Test pending implementation

    @pytest.mark.asyncio
    async def test_default_used_if_no_entry_point_or_explicit(self) -> None:
        """Default adapter should be used if no entry point or explicit config."""
        # This tests the fallback to Default

        container = MagicMock()
        container.repository = MagicMock()

        # No explicit override
        # No entry points discovered
        # Should use default SQLAlchemy adapter

        # Test pending implementation


class TestMXPackageOverrideScenario:
    """Test MX package override scenarios (integration tests)."""

    def test_mx_mongo_can_register_repository(self) -> None:
        """MX package should be able to register custom repository."""
        # Simulates framework-mx-mongo registering MongoRepository

        class MongoRepository:
            """Mock MongoDB repository."""

            pass

        # Mock entry point registration with proper name attribute
        mock_ep = MagicMock()
        mock_ep.name = "mongo"
        mock_ep.load = lambda: MongoRepository

        with patch("importlib.metadata.entry_points", return_value=[mock_ep]):
            from importlib.metadata import entry_points

            eps = entry_points(group="framework_m.adapters.repository")
            ep_dict = {ep.name: ep for ep in eps}

            # MX package registered
            assert "mongo" in ep_dict

            # Can load MX adapter
            adapter = ep_dict["mongo"].load()
            assert adapter is MongoRepository

    def test_mx_package_can_override_default_by_name(self) -> None:
        """MX package can override default by using 'default' name."""
        # If MX package registers with name="default", it overrides the default

        class MongoRepository:
            pass

        class SQLAlchemyRepository:
            pass

        # Simulate two packages registering with same name
        mock_eps = [
            MagicMock(name="default", load=lambda: SQLAlchemyRepository),
            MagicMock(name="default", load=lambda: MongoRepository),  # MX override
        ]

        with patch("importlib.metadata.entry_points", return_value=mock_eps):
            from importlib.metadata import entry_points

            entry_points(group="framework_m.adapters.repository")

            # Last one wins (standard Python entry point behavior)
            # This is how MX packages can override defaults

            # Test will verify override logic


class TestAdapterDiscoveryErrorHandling:
    """Test error handling during adapter discovery."""

    @pytest.mark.asyncio
    async def test_handles_invalid_entry_point_gracefully(self) -> None:
        """Should skip invalid entry points without crashing."""
        from framework_m_standard.bootstrap import InitAdapters

        container = MagicMock()

        # Mock entry point that raises on load
        mock_ep = MagicMock(name="broken")
        mock_ep.load.side_effect = ImportError("Module not found")

        with patch("importlib.metadata.entry_points", return_value=[mock_ep]):
            step = InitAdapters()
            # Should not raise, just skip broken entry point
            await step.run(container)

    @pytest.mark.asyncio
    async def test_handles_missing_container_attribute_gracefully(self) -> None:
        """Should handle containers without expected attributes."""
        from framework_m_standard.bootstrap import InitAdapters

        # Container missing repository attribute
        container = MagicMock(spec=[])  # No attributes

        step = InitAdapters()
        # Should not raise, just skip binding
        await step.run(container)


class TestAdapterEntryPointDocumentation:
    """Test that entry points are documented."""

    def test_init_adapters_has_entry_point_documentation(self) -> None:
        """InitAdapters docstring should document entry point usage."""
        from framework_m_standard.bootstrap import InitAdapters

        assert InitAdapters.__doc__ is not None
        # Should mention entry points
        assert (
            "entry point" in InitAdapters.__doc__.lower()
            or "entry_point" in InitAdapters.__doc__.lower()
        )
