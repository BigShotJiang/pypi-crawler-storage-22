"""Tests for BootstrapRunner - Discovery, ordering, and override logic.

This module tests the bootstrap runner's ability to:
1. Discover steps from entry points
2. Sort steps by order property
3. Allow MX packages to override steps by name
4. Execute steps in correct sequence
"""

from typing import Any
from unittest.mock import MagicMock, patch

import pytest
from framework_m_core.interfaces.bootstrap import BootstrapProtocol
from framework_m_standard.bootstrap import BootstrapRunner


class TestBootstrapRunnerImports:
    """Test that BootstrapRunner is importable."""

    def test_import_from_bootstrap_module(self) -> None:
        """BootstrapRunner should be importable from bootstrap module."""
        from framework_m_standard.bootstrap import BootstrapRunner

        assert BootstrapRunner is not None

    def test_import_from_runner_module(self) -> None:
        """BootstrapRunner should be importable from runner module."""
        from framework_m_standard.bootstrap.runner import BootstrapRunner

        assert BootstrapRunner is not None


class TestBootstrapRunnerInstantiation:
    """Test BootstrapRunner instantiation."""

    def test_can_create_runner(self) -> None:
        """Should be able to create BootstrapRunner instance."""
        runner = BootstrapRunner()
        assert runner is not None

    def test_runner_starts_with_empty_steps(self) -> None:
        """Runner should start with no discovered steps."""
        runner = BootstrapRunner()
        assert runner._steps == {}


class TestBootstrapRunnerDiscovery:
    """Test bootstrap step discovery from entry points."""

    def test_discover_steps_returns_dict(self) -> None:
        """discover_steps should return dictionary of steps."""
        runner = BootstrapRunner()
        steps = runner.discover_steps()

        assert isinstance(steps, dict)

    def test_discover_steps_finds_default_steps(self) -> None:
        """discover_steps should find the 4 default steps."""
        runner = BootstrapRunner()
        steps = runner.discover_steps()

        # Should find default steps
        assert "init_engine" in steps
        assert "init_registries" in steps
        assert "sync_schema" in steps
        assert "init_adapters" in steps

    def test_discovered_steps_implement_protocol(self) -> None:
        """All discovered steps should implement BootstrapProtocol."""
        runner = BootstrapRunner()
        steps = runner.discover_steps()

        for name, step in steps.items():
            assert isinstance(step, BootstrapProtocol), (
                f"{name} does not implement BootstrapProtocol"
            )

    def test_discover_steps_populates_internal_cache(self) -> None:
        """discover_steps should populate _steps cache."""
        runner = BootstrapRunner()
        runner.discover_steps()

        assert len(runner._steps) > 0


class TestBootstrapRunnerSorting:
    """Test bootstrap step sorting by order."""

    def test_get_sorted_steps_returns_list(self) -> None:
        """get_sorted_steps should return list of steps."""
        runner = BootstrapRunner()
        steps = runner.get_sorted_steps()

        assert isinstance(steps, list)

    def test_get_sorted_steps_sorts_by_order(self) -> None:
        """get_sorted_steps should sort by order property ascending."""
        runner = BootstrapRunner()
        steps = runner.get_sorted_steps()

        # Verify order is ascending
        orders = [step.order for step in steps]
        assert orders == sorted(orders)

    def test_default_steps_in_correct_order(self) -> None:
        """Default steps should be in order 10, 20, 30, 40."""
        runner = BootstrapRunner()
        steps = runner.get_sorted_steps()

        # Get default step names in order
        names = [step.name for step in steps]

        # Should include framework-m-standard steps (MX packages may add more)
        expected_steps = [
            "init_engine",
            "init_registries",
            "sync_schema",
            "init_adapters",
        ]

        # Verify all expected steps are present (MX packages like framework-mx-mongo may add init_mongo)
        for expected_step in expected_steps:
            assert expected_step in names, f"Expected step '{expected_step}' not found"

        # Verify order is correct for the expected steps we care about
        standard_steps = [name for name in names if name in expected_steps]
        assert standard_steps == expected_steps, (
            f"Standard steps order mismatch: {standard_steps} != {expected_steps}"
        )

    def test_list_steps_returns_order_name_tuples(self) -> None:
        """list_steps should return list of (order, name) tuples."""
        runner = BootstrapRunner()
        steps = runner.list_steps()

        assert isinstance(steps, list)
        assert all(isinstance(item, tuple) for item in steps)
        assert all(len(item) == 2 for item in steps)

        # Verify format
        for order, name in steps:
            assert isinstance(order, int)
            assert isinstance(name, str)


class TestBootstrapRunnerGetStep:
    """Test getting individual steps by name."""

    def test_get_step_returns_step_by_name(self) -> None:
        """get_step should return step with matching name."""
        runner = BootstrapRunner()
        runner.discover_steps()

        step = runner.get_step("init_engine")

        assert step is not None
        assert step.name == "init_engine"

    def test_get_step_returns_none_for_unknown_name(self) -> None:
        """get_step should return None for unknown step name."""
        runner = BootstrapRunner()
        runner.discover_steps()

        step = runner.get_step("nonexistent_step")

        assert step is None

    def test_get_step_auto_discovers_if_needed(self) -> None:
        """get_step should auto-discover if steps not loaded."""
        runner = BootstrapRunner()
        # Don't call discover_steps()

        step = runner.get_step("init_engine")

        assert step is not None
        assert len(runner._steps) > 0


class TestBootstrapRunnerExecution:
    """Test bootstrap step execution."""

    @pytest.mark.asyncio
    async def test_run_executes_all_steps(self) -> None:
        """run should execute all discovered steps."""
        # Create mock container
        container = MagicMock()

        # Track which steps were executed
        executed_steps = []

        # Create mock step class
        class MockStep:
            def __init__(self, name: str, order: int) -> None:
                self.name = name
                self.order = order

            async def run(self, container: Any) -> None:
                executed_steps.append(self.name)

        # Mock entry points to return our test steps
        mock_eps = [
            MagicMock(name="step1", load=lambda: lambda: MockStep("step1", 10)),
            MagicMock(name="step2", load=lambda: lambda: MockStep("step2", 20)),
        ]

        with patch("importlib.metadata.entry_points", return_value=mock_eps):
            runner = BootstrapRunner()
            await runner.run(container, verbose=False)

        # Verify both steps executed
        assert "step1" in executed_steps
        assert "step2" in executed_steps

    @pytest.mark.asyncio
    async def test_run_executes_steps_in_order(self) -> None:
        """run should execute steps in order by order property."""
        container = MagicMock()
        executed_order = []

        class OrderedMockStep:
            def __init__(self, name: str, order: int) -> None:
                self.name = name
                self.order = order

            async def run(self, container: Any) -> None:
                executed_order.append(self.order)

        # Create steps out of order
        mock_eps = [
            MagicMock(name="step3", load=lambda: lambda: OrderedMockStep("step3", 30)),
            MagicMock(name="step1", load=lambda: lambda: OrderedMockStep("step1", 10)),
            MagicMock(name="step2", load=lambda: lambda: OrderedMockStep("step2", 20)),
        ]

        with patch("importlib.metadata.entry_points", return_value=mock_eps):
            runner = BootstrapRunner()
            await runner.run(container, verbose=False)

        # Verify execution order is sorted
        assert executed_order == [10, 20, 30]

    @pytest.mark.asyncio
    async def test_run_continues_on_step_failure(self) -> None:
        """run should continue executing remaining steps if one fails."""
        container = MagicMock()
        executed_steps = []

        class FailingMockStep:
            def __init__(
                self, name: str, order: int, should_fail: bool = False
            ) -> None:
                self.name = name
                self.order = order
                self.should_fail = should_fail

            async def run(self, container: Any) -> None:
                if self.should_fail:
                    raise RuntimeError(f"{self.name} failed")
                executed_steps.append(self.name)

        mock_eps = [
            MagicMock(
                name="step1", load=lambda: lambda: FailingMockStep("step1", 10, False)
            ),
            MagicMock(
                name="step2", load=lambda: lambda: FailingMockStep("step2", 20, True)
            ),  # Fails
            MagicMock(
                name="step3", load=lambda: lambda: FailingMockStep("step3", 30, False)
            ),
        ]

        with patch("importlib.metadata.entry_points", return_value=mock_eps):
            runner = BootstrapRunner()
            await runner.run(container, verbose=False)

        # Verify steps 1 and 3 executed despite step 2 failure
        assert "step1" in executed_steps
        assert "step2" not in executed_steps  # Failed
        assert "step3" in executed_steps


class TestBootstrapRunnerOverrides:
    """Test MX package override behavior."""

    def test_override_by_name_last_wins(self) -> None:
        """When multiple steps have same name, last one wins."""

        class DefaultStep:
            name = "my_step"
            order = 10

            async def run(self, container: Any) -> None:
                pass

        class OverrideStep:
            name = "my_step"  # Same name
            order = 10

            async def run(self, container: Any) -> None:
                pass

        # Mock entry points - override comes after default
        mock_eps = [
            MagicMock(name="my_step", load=lambda: DefaultStep),
            MagicMock(name="my_step", load=lambda: OverrideStep),  # Override
        ]

        with patch("importlib.metadata.entry_points", return_value=mock_eps):
            runner = BootstrapRunner()
            steps = runner.discover_steps()

            # Should have the override version
            step = steps["my_step"]
            assert step.__class__.__name__ == "OverrideStep"

    def test_mx_can_insert_steps_between_defaults(self) -> None:
        """MX packages can insert steps with intermediate order values."""

        class Step10:
            name = "step10"
            order = 10

            async def run(self, container: Any) -> None:
                pass

        class Step15:
            name = "step15"
            order = 15  # Inserted between 10 and 20

            async def run(self, container: Any) -> None:
                pass

        class Step20:
            name = "step20"
            order = 20

            async def run(self, container: Any) -> None:
                pass

        mock_eps = [
            MagicMock(name="step10", load=lambda: Step10),
            MagicMock(name="step15", load=lambda: Step15),
            MagicMock(name="step20", load=lambda: Step20),
        ]

        with patch("importlib.metadata.entry_points", return_value=mock_eps):
            runner = BootstrapRunner()
            sorted_steps = runner.get_sorted_steps()

            # Verify order
            names = [step.name for step in sorted_steps]
            assert names == ["step10", "step15", "step20"]


class TestBootstrapRunnerEdgeCases:
    """Test edge cases and error handling."""

    def test_handles_no_entry_points_gracefully(self) -> None:
        """Should handle case with no entry points registered."""
        with patch("importlib.metadata.entry_points", return_value=[]):
            runner = BootstrapRunner()
            steps = runner.discover_steps()

            assert steps == {}

    @pytest.mark.asyncio
    async def test_run_with_no_steps_does_nothing(self) -> None:
        """run with no steps should complete without error."""
        container = MagicMock()

        with patch("importlib.metadata.entry_points", return_value=[]):
            runner = BootstrapRunner()
            await runner.run(container, verbose=False)

        # Should complete successfully

    def test_handles_invalid_step_class_gracefully(self) -> None:
        """Should skip steps that don't implement BootstrapProtocol."""

        class InvalidStep:
            # Missing name, order, run
            pass

        mock_eps = [
            MagicMock(name="invalid", load=lambda: InvalidStep),
        ]

        with patch("importlib.metadata.entry_points", return_value=mock_eps):
            runner = BootstrapRunner()
            steps = runner.discover_steps()

            # Invalid step should be skipped
            assert "invalid" not in steps
