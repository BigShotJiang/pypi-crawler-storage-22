# Changelog

## framework-m-studio v0.3.0

### Features

- support namespaced app, test directory and dev.py moved to studio (37beae6)


## framework-m-studio v0.2.8

### Bug Fixes

- add ruff code style badge to README (c2482ea)


## framework-m-studio v0.2.7

### Bug Fixes

- add Python version and license badges to README (90d1adf)


## framework-m-studio v0.2.6

### Bug Fixes

- format and lint (090018f)


## framework-m-studio v0.2.3

### Bug Fixes

- ensure static assets are bundled in the wheel (ce0a0e1)


## framework-m-studio v0.2.2

### Bug Fixes

- add badges to readme (012333b)


## framework-m-studio v0.2.1

### Bug Fixes

- modernize aesthetics (300cdda)


## framework-m-studio 0.2.0

### Features

- implement path prefix architecture for UI/API separation (7a8d2d2)
- add cloud workspace & git adapter, controller scaffolding and sandbox (a7a4a3e)
- implement Studio backend and frontend (abf5d03)

### Bug Fixes

- include static files in package for PyPI publishing (565bcb8)

