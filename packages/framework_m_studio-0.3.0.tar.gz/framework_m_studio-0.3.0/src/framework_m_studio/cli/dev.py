"""Dev CLI Command - Development server with hot reload.

This module provides the `m dev` command for running the full development
stack with automatic hot reload using honcho for process management.

Architecture:
- Uses honcho.manager.Manager for concurrent process management
- Generates Procfile entries dynamically
- All processes have hot reload enabled
- Graceful shutdown on Ctrl+C

Usage:
    m dev                           # Backend + Frontend
    m dev --studio                  # + Studio on port 9999
    m dev --app myapp:app           # Custom backend module
    m dev --frontend-dir ./ui       # Custom frontend path
    m dev --no-frontend             # Backend only
"""

from __future__ import annotations

import os
import signal
import sys
from pathlib import Path
from typing import Annotated

import cyclopts
from honcho.manager import Manager
from honcho.printer import Printer

from framework_m_studio.cli.studio import DEFAULT_STUDIO_APP

# Default ports
DEFAULT_BACKEND_PORT = 8888
DEFAULT_FRONTEND_PORT = 5173
DEFAULT_STUDIO_PORT = 9999


def _get_pythonpath() -> str:
    """Get PYTHONPATH with src/ directory included."""
    cwd = Path.cwd()
    src_path = cwd / "src"

    paths = []
    if src_path.exists():
        paths.append(str(src_path))
    paths.append(str(cwd))

    existing = os.environ.get("PYTHONPATH", "")
    if existing:
        paths.append(existing)

    return os.pathsep.join(paths)


def _find_app(explicit_app: str | None = None) -> str:
    """Find the Litestar app to run."""
    if explicit_app:
        return explicit_app

    cwd = Path.cwd()

    if (cwd / "app.py").exists():
        return "app:app"
    if (cwd / "app" / "__init__.py").exists():
        return "app:app"
    if (cwd / "src" / "app" / "__init__.py").exists():
        return "src.app:app"
    if (cwd / "main.py").exists():
        return "main:app"

    return "framework_m_standard.adapters.web.app:create_app"


def _check_frontend_exists(frontend_dir: Path) -> bool:
    """Check if frontend directory exists and is valid."""
    return frontend_dir.exists() and (frontend_dir / "package.json").exists()


def dev_command(
    app: Annotated[
        str | None,
        cyclopts.Parameter(
            name="--app",
            help="Backend app path (module:attribute format)",
        ),
    ] = None,
    host: Annotated[
        str,
        cyclopts.Parameter(name="--host", help="Host to bind to"),
    ] = "127.0.0.1",
    port: Annotated[
        int,
        cyclopts.Parameter(name="--port", help="Backend port"),
    ] = DEFAULT_BACKEND_PORT,
    frontend_dir: Annotated[
        Path,
        cyclopts.Parameter(
            name="--frontend-dir",
            help="Frontend directory path",
        ),
    ] = Path("frontend"),
    frontend_port: Annotated[
        int,
        cyclopts.Parameter(name="--frontend-port", help="Frontend dev server port"),
    ] = DEFAULT_FRONTEND_PORT,
    studio: Annotated[
        bool,
        cyclopts.Parameter(
            name="--studio",
            help="Also start Studio on port 9999",
        ),
    ] = False,
    studio_port: Annotated[
        int,
        cyclopts.Parameter(name="--studio-port", help="Studio port"),
    ] = DEFAULT_STUDIO_PORT,
    no_frontend: Annotated[
        bool,
        cyclopts.Parameter(
            name="--no-frontend",
            help="Skip frontend, run backend only",
        ),
    ] = False,
) -> None:
    """Start development servers with hot reload.

    Runs backend (uvicorn --reload) and frontend (pnpm dev) concurrently
    using honcho for process management.

    Examples:
        m dev                           # Backend + Frontend
        m dev --studio                  # + Studio
        m dev --app myapp:create_app    # Custom backend
        m dev --no-frontend             # Backend only
    """
    # Find app path
    app_path = _find_app(app)

    # Set up environment
    env = os.environ.copy()
    env["PYTHONPATH"] = _get_pythonpath()

    # Build process commands
    processes: dict[str, str] = {}

    # Backend with hot reload
    backend_cmd = (
        f"{sys.executable} -m uvicorn {app_path} --host {host} --port {port} --reload"
    )
    processes["backend"] = backend_cmd

    # Frontend dev server
    if not no_frontend:
        if _check_frontend_exists(frontend_dir):
            # Use VITE_PORT env var to set port
            frontend_cmd = f"cd {frontend_dir} && pnpm dev --port {frontend_port}"
            processes["frontend"] = frontend_cmd
        else:
            print(f"⚠ Frontend not found at {frontend_dir}, skipping...")
            print("  Run 'm init:frontend' to scaffold frontend\n")

    # Studio (optional)
    if studio:
        studio_cmd = (
            f"{sys.executable} -m uvicorn {DEFAULT_STUDIO_APP} "
            f"--host {host} --port {studio_port} --reload"
        )
        processes["studio"] = studio_cmd

    if not processes:
        print("No processes to run!")
        return

    # Print startup info
    print("=" * 50)
    print("  Framework M Development Server")
    print("=" * 50)
    print()
    for name, _cmd in processes.items():
        if name == "backend":
            print(f"  🚀 Backend:  http://{host}:{port}")
        elif name == "frontend":
            print(f"  🎨 Frontend: http://{host}:{frontend_port}")
        elif name == "studio":
            print(f"  🎯 Studio:   http://{host}:{studio_port}")
    print()
    print("  Press Ctrl+C to stop all servers")
    print("=" * 50)
    print()

    # Create honcho manager with correct v2.0 API
    manager = Manager(Printer(output=sys.stdout))

    # Add processes
    for name, cmd in processes.items():
        manager.add_process(name, cmd, env=env)

    # Handle graceful shutdown
    def signal_handler(signum: int, frame: object) -> None:
        print("\n\nStopping all servers...")
        manager.terminate()

    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    # Run all processes
    manager.loop()

    print("\n✓ All servers stopped.")


__all__ = ["dev_command"]
