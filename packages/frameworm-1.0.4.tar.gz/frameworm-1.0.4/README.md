# FRAMEWORM

**Complete Machine Learning Framework for Production**

[![PyPI](https://img.shields.io/pypi/v/frameworm)](https://pypi.org/project/frameworm/)
[![Python](https://img.shields.io/pypi/pyversions/frameworm)](https://python.org)
[![Tests](https://img.shields.io/github/workflow/status/Aakash0440/frameworm/tests)](https://github.com/Aakash0440/frameworm/actions)
[![Coverage](https://img.shields.io/codecov/c/github/Aakash0440/frameworm)](https://codecov.io/gh/Aakash0440/frameworm)
[![Documentation](https://img.shields.io/badge/docs-mkdocs-blue)](https://frameworm.readthedocs.io)
[![License](https://img.shields.io/github/license/Aakash0440/frameworm)](https://github.com/Aakash0440/frameworm/blob/main/LICENSE)
[![Discord](https://img.shields.io/discord/123456789)](https://discord.gg/frameworm)

---

## Features

- 🚀 **Simple API** - Train models in minutes
- 📊 **Experiment Tracking** - Built-in, no external servers
- 🔍 **Hyperparameter Search** - Grid, random, Bayesian
- 🎯 **Production Ready** - Export, serve, deploy
- ⚡ **Fast** - Multi-GPU, distributed, mixed precision
- 🎨 **Web Dashboard** - Beautiful UI for tracking

---

## Quick Start
```bash
pip install frameworm
frameworm init my-project
cd my-project
frameworm train --config config.yaml
```

See [documentation](https://frameworm.readthedocs.io) for more.

---

## Why FRAMEWORM?

| Feature | FRAMEWORM | PyTorch Lightning | Others |
|---------|-----------|-------------------|--------|
| Training | ✅ | ✅ | ✅ |
| Experiment Tracking | ✅ Built-in | ⚠️ External | ⚠️ External |
| Hyperparameter Search | ✅ Built-in | ❌ | ⚠️ Limited |
| Deployment | ✅ Built-in | ❌ | ⚠️ Limited |
| Web UI | ✅ Built-in | ❌ | ❌ |
| Complexity | Low | Medium | High |

---

## Documentation

- [Quick Start](https://frameworm.readthedocs.io/getting-started/quickstart/)
- [User Guide](https://frameworm.readthedocs.io/user-guide/training/)
- [Tutorials](https://frameworm.readthedocs.io/tutorials/vae-tutorial/)
- [API Reference](https://frameworm.readthedocs.io/api-reference/core/)
- [Examples](https://frameworm.readthedocs.io/examples/basic-training/)

---

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md)

---

## License

MIT License - see [LICENSE](LICENSE)

---

## Citation
```bibtex
@software{frameworm2024,
  title = {FRAMEWORM: Complete Machine Learning Framework},
  author = {Aakash Ali},
  year = {2026},
  url = {https://github.com/Aakash0440/frameworm}
}
```