# CHANGELOG

<!-- version list -->

## v1.7.0 (2026-02-06)

### Features

- Implement JSON parsing for partenaires and liste_complements
  ([`e813c8c`](https://github.com/cmnemoi/france-travail-api/commit/e813c8cce97060362501fbd34833b6d8bc211fd1))


## v1.6.0 (2026-02-06)

### Features

- Add `client.offres.referentiel.appellations()` and
  `client.offres.referentiel.appellations_async()` methods
  ([`86acd13`](https://github.com/cmnemoi/france-travail-api/commit/86acd13a0b1097ca81023cefc67b79d89193b4e9))


## v1.5.0 (2026-01-25)

### Features

- Add `client.offres.referentiel.metiers()` and `client.offres.referentiel.metiers_async()` methods
  ([`79f33a2`](https://github.com/cmnemoi/france-travail-api/commit/79f33a2aa28e74b3154866abfc760250f6ba8a68))


## v1.4.0 (2026-01-25)

### Features

- Add `client.offres.get` and `client.offres.get_async` methods
  ([`3ea67d4`](https://github.com/cmnemoi/france-travail-api/commit/3ea67d44590f67620aad31cedb266642e8c26d40))


## v1.3.0 (2026-01-24)

### Continuous Integration

- Add mkdocs documentation
  ([`995f989`](https://github.com/cmnemoi/france-travail-api/commit/995f989b331043cc7cda464f7261725d6271bbfe))

- Update workflow triggers and correct typo in Ubuntu version
  ([`acf6295`](https://github.com/cmnemoi/france-travail-api/commit/acf6295310b61bb70343650def6830061366a7ee))

### Documentation

- Add PyPi badge and update AGENTS.md
  ([`ed59d86`](https://github.com/cmnemoi/france-travail-api/commit/ed59d867844e42eea400472aaca794676c40a3aa))

### Features

- Add `client.offres.search_async` method
  ([`bf7ea41`](https://github.com/cmnemoi/france-travail-api/commit/bf7ea41c90c74b8fdae60df23ed0c26eb8666312))

### Testing

- Refactor test to DSL
  ([`f5d79ec`](https://github.com/cmnemoi/france-travail-api/commit/f5d79ec746f6573867c52566bd42a75837c37acc))


## v1.2.0 (2026-01-13)

### Documentation

- Add documentation
  ([`fab8af6`](https://github.com/cmnemoi/france-travail-api/commit/fab8af6094cf646decfeecf518f651236ba8a0a6))

- Update README with usage example
  ([`42811ad`](https://github.com/cmnemoi/france-travail-api/commit/42811adb677b4c11247f4de9b1576affabd3fca5))

### Features

- Add typing for some search parameters for job offers
  ([`caeb4e5`](https://github.com/cmnemoi/france-travail-api/commit/caeb4e5ce37c3377d45307a1366f9231b85977d2))


## v1.1.0 (2026-01-10)

### Chores

- Remove dead code
  ([`b3f585e`](https://github.com/cmnemoi/france-travail-api/commit/b3f585e436633a589e9bb69ab65c181cd575c627))

### Features

- First client to search for some job offers
  ([`029e061`](https://github.com/cmnemoi/france-travail-api/commit/029e061a28fe339ad4babf1231946a32a51a3e76))


## v1.0.0 (2026-01-03)

- Initial Release
