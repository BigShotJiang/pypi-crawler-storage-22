"""
Franka Desk API 综合控制演示程序
集智联机器人（苏州）有限公司
"""

import time
import os
from deskapi import create_franka_api_from_args

class RobotControlDemo:
    def __init__(self):
        self.franka_api = None
        self.args = None
        self.running = False
        self.control_thread = None
        self.current_mode = "IDLE"
        self.connected = False
        self.session_open = False
        self.menu_displayed = False
        self.last_status_line = "" 
        
        
    def connect_robot(self):
        """连接机器人"""
        try:
            print("正在连接 Franka 机器人...")
            self.franka_api, self.args = create_franka_api_from_args("Franka 机器人desk 控制台")
            
            if self.franka_api:
                self.franka_api.open()
                self.session_open = True
                self.connected = True
                print("✅ 机器人连接成功！")
                return True
            else:
                print("❌ 机器人连接失败：API对象为None")
                return False
        except Exception as e:
            print(f"❌ 连接失败: {e}")
            return False
    
    def close_connection(self):
        """关闭连接"""
        if self.session_open and self.franka_api:
            try:
                self.franka_api.close()
                self.session_open = False
                self.connected = False
                print("✅ 连接已关闭")
            except Exception as e:
                print(f"❌ 关闭连接失败: {e}")
    
    def check_connection_status(self):
        """检查机器人连接状态"""
        if not self.connected or not self.franka_api or not self.session_open:
            print("❌ 未连接到机器人或会话未打开")
            return False
            
        try:
            self.franka_api.get_system_state()
            print(f"✅ 系统信息: 已连接")
            return True
        except Exception as e:
            print(f"❌ 状态检查失败: {e}")
            return False
    
    def safe_api_call(self, method_name, method_call, *args, **kwargs):
        """安全地调用API方法"""
        if not self.connected or not self.franka_api or not self.session_open:
            print(f"❌ 无法执行 {method_name}：未连接到机器人或会话未打开")
            return False
        
        try:
            result = method_call(*args, **kwargs)
            return True
        except Exception as e:
            print(f"❌ {method_name} 失败: {e}")
            return False
    
    def take_control(self, force=False):
        """获取控制权限"""
        return self.safe_api_call("获取控制权限", self.franka_api.take_control, force=True)
    
    def release_control(self):
        """释放控制权限"""
        return self.safe_api_call("释放控制权限", self.franka_api.release_control)
    
    def unlock_brakes(self):
        """解锁关节刹车"""
        return self.safe_api_call("解锁刹车", self.franka_api.unlock_brakes)
    
    def lock_brakes(self):
        """锁定关节刹车"""
        return self.safe_api_call("锁定刹车", self.franka_api.lock_brakes)
    
    def set_mode_programming(self):
        """设置为编程模式"""
        return self.safe_api_call("设置编程模式", self.franka_api.set_mode_programming)
    
    def set_mode_execution(self):
        """设置为执行模式"""
        return self.safe_api_call("设置执行模式", self.franka_api.set_mode_execution)
    
    def activate_fci(self):
        """激活 FCI"""
        return self.safe_api_call("激活FCI", self.franka_api.activate_fci)
    
    def deactivate_fci(self):
        """取消激活 FCI"""
        return self.safe_api_call("取消激活FCI", self.franka_api.deactivate_fci)
    
    def shutdown(self):
        """关机"""
        return self.safe_api_call("关机", self.franka_api.shutdown)
    
    def reboot(self):
        """重启"""
        return self.safe_api_call("重启", self.franka_api.reboot)
    def move_to_pack_pose(self):
        """移动到打包姿势"""
        return self.safe_api_call("移动到打包姿势", self.franka_api.move_to_pack_pose)
    
    
    def execute_start_sequence(self):
        """执行启动流程"""
        if not self.connected:
            return False
            
        if not self.take_control():
            return False
        
        if not self.unlock_brakes():
            self.release_control()
            return False
        
        if not self.set_mode_execution():
            self.release_control()
            return False
        
        if not self.activate_fci():
            self.release_control()
            return False
        
        self.current_mode = "EXECUTION"
        return True
    
    def execute_programming_mode(self):
        """执行编程模式设置"""
        if not self.connected:
            return False
            
        if not self.take_control():
            return False
        
        if not self.set_mode_programming():
            self.release_control()
            return False
        
        self.current_mode = "PROGRAMMING"
        return True
    
    def clear_line(self):
        print("\r" + " " * 100 + "\r", end="", flush=True)
    
    def update_display(self, result_message=""):
        self.clear_line()
        
        if result_message:
            display_text = f"{result_message} | 请输入指令: "
        else:
            display_text = "请输入指令: "
        
        print(display_text, end="", flush=True)
    
    def reconnect(self):
        """重新连接机器人"""
        print("\n🔄 尝试重新连接机器人...")
        self.close_connection()
        time.sleep(1)
        return self.connect_robot()
    
    def get_menu_options(self):
        """返回菜单选项字典"""
        return {
            'S': {
                'name': '启动流程',
                'description': '解锁刹车 → 执行模式 → 激活FCI',
                'handler': self.execute_start_sequence
            },
            'P': {
                'name': '编程模式',
                'description': '设置为编程模式',
                'handler': self.execute_programming_mode
            },
            'E': {
                'name': '执行模式',
                'description': '设置为执行模式',
                'handler': lambda: self.take_control() and self.set_mode_execution() and self.set_current_mode("EXECUTION")
            },
            'U': {
                'name': '解锁刹车',
                'description': '解锁关节刹车',
                'handler': lambda: self.take_control() and self.unlock_brakes()
            },
            'L': {
                'name': '锁定刹车',
                'description': '锁定关节刹车',
                'handler': lambda: self.take_control() and self.lock_brakes()
            },
            'A': {
                'name': '激活 FCI',
                'description': '激活 FCI',
                'handler': lambda: self.take_control() and self.activate_fci()
            },
            'D': {
                'name': '取消激活 FCI',
                'description': '取消激活 FCI',
                'handler': lambda: self.take_control() and self.deactivate_fci()
            },
            'R': {
                'name': '重启机器人',
                'description': '重启机器人',
                'handler': lambda: self.take_control() and self.reboot()
            },
            'X': {
                'name': '关机机器人',
                'description': '关机机器人',
                'handler': lambda: self.take_control() and self.shutdown()
            },
            'B': {
                'name': '打包姿势',
                'description': '移动到打包姿势',
                'handler': lambda: self.take_control() and self.unlock_brakes() and self.set_mode_execution() and self.move_to_pack_pose()
            },
            'C': {
                'name': '检查状态',
                'description': '检查机器人连接状态',
                'handler': self.check_connection_status
            },
            'T': {
                'name': '获取控制权限',
                'description': '获取控制权限',
                'handler': self.take_control
            },
            'F': {
                'name': '释放控制权限',
                'description': '释放控制权限',
                'handler': self.release_control
            },
            'Z': {
                'name': '重新连接',
                'description': '重新连接机器人',
                'handler': self.reconnect
            },
            'Q': {
                'name': '退出程序',
                'description': '退出程序',
                'handler': None
            }
        }
    
    def set_current_mode(self, mode):
        """设置当前模式"""
        self.current_mode = mode
        return True
    
    def show_header(self):
        if not self.menu_displayed:
            os.system('clear' if os.name == 'posix' else 'cls')
            print("="*70)
            print("    Franka 机器人desk 控制台 (来自 集智联机器人（苏州）有限公司)    ")
            print("="*70)
            print(f"连接状态: {'✅ 已连接' if self.connected else '❌ 未连接'}")
            print(f"会话状态: {'✅ 已打开' if self.session_open else '❌ 未打开'}")
            print(f"当前模式: {self.current_mode}")
            print("="*70)
            
            menu_options = self.get_menu_options()
            options_list = list(menu_options.items())

            half = (len(options_list) + 1) // 2
            
            for i in range(half):
                key1, option1 = options_list[i]
                line1 = f"{key1} - {option1['name']}: {option1['description']}"
                
                if i + half < len(options_list):
                    key2, option2 = options_list[i + half]
                    line2 = f"{key2} - {option2['name']}: {option2['description']}"
                    print(f"{line1:<45} {line2}")
                else:
                    print(line1)
            print("="*70)
            print("💡 提示: 请勿关闭此程序，输入命令后ENTER确认")
            print("      使用 Ctrl+C 或输入 Q 退出程序")
            print("="*70)
            print()  
            self.menu_displayed = True
    
    def update_status_line(self, message):
        """更新状态行（在固定位置显示）"""
        print(f"\r{message}", end="", flush=True)
    
    def run(self):
        """运行主程序"""
        print("Franka Desk API 控制实例")
        print("集智联机器人（苏州）有限公司")        
        if not self.connect_robot():
            print("⚠️  机器人连接失败")
            print("💡 提示: 可以执行重新连接(Z)来尝试连接")
        
        menu_options = self.get_menu_options()
        
        self.show_header()
        last_result_message = ""
        
        try:
            while True:
                self.update_display(last_result_message)
                
                choice = input().strip().upper()
                
                if choice == 'Q':
                    print("\n👋 退出程序")
                    break
                
                self.clear_line()
                
                if choice in menu_options:
                    option = menu_options[choice]
                    if option['handler']:
                        result = option['handler']()
                        if result:
                            last_result_message = f"✅ {option['name']} 执行成功"
                        else:
                            last_result_message = f"❌ {option['name']} 执行失败"
                    else:
                        last_result_message = "❌ 该选项没有对应的处理函数"
                else:
                    last_result_message = "❌ 无效指令，请重新输入"
                
                self.update_display(last_result_message)
                
        except KeyboardInterrupt:
            print("\n\n🛑 检测到 Ctrl+C，正在退出...")
        except Exception as e:
            print(f"\n❌ 程序运行出错: {e}")
        finally:
            self.close_connection()
            print("👋 程序已退出")
def main():
    try:
        demo = RobotControlDemo()
        demo.run()
    except Exception as e:
        print(f"❌ 程序运行出错: {e}")

if __name__ == "__main__":
    main()