"""
Franka Desk API Comprehensive Control Demo Program
Plug and Play Robotics (Suzhou) Co., Ltd.
"""

import time
import os
from deskapi import create_franka_api_from_args

class RobotControlDemo:
    def __init__(self):
        self.franka_api = None
        self.args = None
        self.running = False
        self.control_thread = None
        self.current_mode = "IDLE"
        self.connected = False
        self.session_open = False
        self.menu_displayed = False
        self.last_status_line = "" 
        
        
    def connect_robot(self):
        """connect to the Franka robot"""
        try:
            print("Connecting to Franka robot...")
            self.franka_api, self.args = create_franka_api_from_args("Franka Robot Desk Console")
            
            if self.franka_api:
                self.franka_api.open()
                self.session_open = True
                self.connected = True
                print("✅ Robot connected successfully!")
                return True
            else:
                print("❌ Robot connection failed: API object is None")
                return False
        except Exception as e:
            print(f"❌ Connection failed: {e}")
            return False
    
    def close_connection(self):
        """close the connection to the Franka robot"""
        if self.session_open and self.franka_api:
            try:
                self.franka_api.close()
                self.session_open = False
                self.connected = False
                print("✅ Connection closed")
            except Exception as e:
                print(f"❌ Failed to close connection: {e}")
    
    def check_connection_status(self):
        """check the connection status to the Franka robot"""
        if not self.connected or not self.franka_api or not self.session_open:
            print("❌ Not connected to robot or session not open")
            return False
            
        try:
            self.franka_api.get_system_state()
            print(f"✅ System information: Connected")
            return True
        except Exception as e:
            print(f"❌ Status check failed: {e}")
            return False
    
    def safe_api_call(self, method_name, method_call, *args, **kwargs):
        """execute a safe API call to the Franka robot"""
        if not self.connected or not self.franka_api or not self.session_open:
            print(f"❌ Cannot execute {method_name}: Not connected to robot or session not open")
            return False
        
        try:
            result = method_call(*args, **kwargs)
            return True
        except Exception as e:
            print(f"❌ {method_name} failed: {e}")
            return False
    
    def take_control(self, force=False):
        """acquire control permission from the Franka robot"""
        return self.safe_api_call("Take control", self.franka_api.take_control, force=True)
    
    def release_control(self):
        """release control permission from the Franka robot"""
        return self.safe_api_call("Release control", self.franka_api.release_control)
    
    def unlock_brakes(self):
        """unlock the brakes of the Franka robot"""
        return self.safe_api_call("Unlock brakes", self.franka_api.unlock_brakes)
    
    def lock_brakes(self):
        """lock the brakes of the Franka robot"""
        return self.safe_api_call("Lock brakes", self.franka_api.lock_brakes)
    
    def set_mode_programming(self):
        """set the Franka robot to programming mode"""
        return self.safe_api_call("Set programming mode", self.franka_api.set_mode_programming)
    
    def set_mode_execution(self):
        """set the Franka robot to execution mode"""
        return self.safe_api_call("Set execution mode", self.franka_api.set_mode_execution)
    
    def activate_fci(self):
        """activate FCI"""
        return self.safe_api_call("Activate FCI", self.franka_api.activate_fci)
    
    def deactivate_fci(self):
        """deactivate FCI"""
        return self.safe_api_call("Deactivate FCI", self.franka_api.deactivate_fci)
    
    def shutdown(self):
        """shutdown the Franka robot"""
        return self.safe_api_call("Shutdown", self.franka_api.shutdown)
        
    def reboot(self):
        """reboot the Franka robot"""
        return self.safe_api_call("Reboot", self.franka_api.reboot)
    def move_to_pack_pose(self):
        """move the Franka robot to the pack pose"""
        return self.safe_api_call("Move to pack pose", self.franka_api.move_to_pack_pose)
    
    
    def execute_start_sequence(self):
        """execute the startup sequence of the Franka robot"""
        if not self.connected:
            return False
            
        if not self.take_control():
            return False
        
        if not self.unlock_brakes():
            self.release_control()
            return False
        
        if not self.set_mode_execution():
            self.release_control()
            return False
        
        if not self.activate_fci():
            self.release_control()
            return False
        
        self.current_mode = "EXECUTION"
        return True
    
    def execute_programming_mode(self):
        """set the Franka robot to programming mode"""
        if not self.connected:
            return False
            
        if not self.take_control():
            return False
        
        if not self.set_mode_programming():
            self.release_control()
            return False
        
        self.current_mode = "PROGRAMMING"
        return True
    
    def clear_line(self):
        print("\r" + " " * 100 + "\r", end="", flush=True)
    
    def update_display(self, result_message=""):
        self.clear_line()
        
        if result_message:
            display_text = f"{result_message} | Please enter command: "
        else:
            display_text = "Please enter command: "
        
        print(display_text, end="", flush=True)
    
    def reconnect(self):
        """reconnect to the Franka robot"""
        print("\n🔄 Attempting to reconnect to robot...")
        self.close_connection()
        time.sleep(1)
        return self.connect_robot()
    
    def get_menu_options(self):
        """return the menu options dictionary"""
        return {
            'S': {
                'name': 'Startup',
                'description': 'Unlock & Exec → Activate FCI',
                'handler': self.execute_start_sequence
            },
            'P': {
                'name': 'Programming Mode',
                'description': 'Set to programming',
                'handler': self.execute_programming_mode
            },
            'E': {
                'name': 'Execution Mode',
                'description': 'Set to execution',
                'handler': lambda: self.take_control() and self.set_mode_execution() and self.set_current_mode("EXECUTION")
            },
            'U': {
                'name': 'Unlock Brakes',
                'description': 'Unlock joint brakes',
                'handler': lambda: self.take_control() and self.unlock_brakes()
            },
            'L': {
                'name': 'Lock Brakes',
                'description': 'Lock joint brakes',
                'handler': lambda: self.take_control() and self.lock_brakes()
            },
            'A': {
                'name': 'Activate FCI',
                'description': 'Activate FCI',
                'handler': lambda: self.take_control() and self.activate_fci()
            },
            'D': {
                'name': 'Deactivate FCI',
                'description': 'Deactivate FCI',
                'handler': lambda: self.take_control() and self.deactivate_fci()
            },
            'R': {
                'name': 'Reboot Robot',
                'description': 'Reboot the robot',
                'handler': lambda: self.take_control() and self.reboot()
            },
            'X': {
                'name': 'Shutdown Robot',
                'description': 'Shutdown the robot',
                'handler': lambda: self.take_control() and self.shutdown()
            },
            'B': {
                'name': 'Pack Pose',
                'description': 'Move to pack pose',
                'handler': lambda: self.take_control() and self.unlock_brakes() and self.set_mode_execution() and self.move_to_pack_pose()
            },
            'C': {
                'name': 'Check Status',
                'description': 'Check robot connection status',
                'handler': self.check_connection_status
            },
            'T': {
                'name': 'Take Control',
                'description': 'Take control of the robot',
                'handler': self.take_control
            },
            'F': {
                'name': 'Release Control',
                'description': 'Release control of the robot',
                'handler': self.release_control
            },
            'Z': {
                'name': 'Reconnect',
                'description': 'Reconnect to the robot',
                'handler': self.reconnect
            },
            'Q': {
                'name': 'Quit Program',
                'description': 'Exit the program',
                'handler': None
            }
        }
    
    def set_current_mode(self, mode):
        """set the current mode of the Franka robot"""
        self.current_mode = mode
        return True
    
    def show_header(self):
        if not self.menu_displayed:
            os.system('clear' if os.name == 'posix' else 'cls')
            print("="*100)
            print("    Franka Robot Desk Console (by Plug and Play Robotics (Suzhou) Co., Ltd.)    ")
            print("="*100)
            print(f"Connection Status: {'✅ Connected' if self.connected else '❌ Disconnected'}")
            print(f"Session Status: {'✅ Open' if self.session_open else '❌ Closed'}")
            print(f"Current Mode: {self.current_mode}")
            print("="*100)
            
            menu_options = self.get_menu_options()
            options_list = list(menu_options.items())

            half = (len(options_list) + 1) // 2
            
            for i in range(half):
                key1, option1 = options_list[i]
                line1 = f"{key1} - {option1['name']}: {option1['description']}"
                
                if i + half < len(options_list):
                    key2, option2 = options_list[i + half]
                    line2 = f"{key2} - {option2['name']}: {option2['description']}"
                    print(f"{line1:<45} {line2}")
                else:
                    print(line1)
            print("="*100)
            print("💡 Tip: Do not close this program, press ENTER after entering a command")
            print("      Use Ctrl+C or enter Q to exit the program")
            print("="*100)
            print()  
            self.menu_displayed = True
    
    def update_status_line(self, message):
        """update the status line (displayed at a fixed position)"""
        print(f"\r{message}", end="", flush=True)
    
    def run(self):
        """run the main program"""
        print("Franka Desk API Control Instance")
        print("Plug and Play Robotics (Suzhou) Co., Ltd.")        
        if not self.connect_robot():
            print("⚠️  Robot connection failed")
            print("💡 Tip: You can try to reconnect using Z command")
        
        menu_options = self.get_menu_options()
        
        self.show_header()
        last_result_message = ""
        
        try:
            while True:
                self.update_display(last_result_message)
                
                choice = input().strip().upper()
                
                if choice == 'Q':
                    print("\n👋 Exiting program")
                    break
                
                self.clear_line()
                
                if choice in menu_options:
                    option = menu_options[choice]
                    if option['handler']:
                        result = option['handler']()
                        if result:
                            last_result_message = f"✅ {option['name']} executed successfully"
                        else:
                            last_result_message = f"❌ {option['name']} execution failed"
                    else:
                        last_result_message = "❌ This option has no corresponding handler function"
                else:
                    last_result_message = "❌ Invalid command, please re-enter"
                
                self.update_display(last_result_message)
                
        except KeyboardInterrupt:
            print("\n\n🛑 Ctrl+C detected, exiting...")
        except Exception as e:
            print(f"\n❌ Program error: {e}")
        finally:
            self.close_connection()
            print("👋 Program exited")
def main():
    try:
        demo = RobotControlDemo()
        demo.run()
    except Exception as e:
        print(f"❌ Program error: {e}")

if __name__ == "__main__":
    main()