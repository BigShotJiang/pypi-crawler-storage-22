"""Decorator module initialization."""

from frappe_auth_bridge.decorators.auth import frappe_auth_required

__all__ = ["frappe_auth_required"]
