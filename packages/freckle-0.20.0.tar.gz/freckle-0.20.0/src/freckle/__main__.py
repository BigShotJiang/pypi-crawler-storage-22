"""Allow running freckle as a module: python -m freckle"""

from .cli import main

if __name__ == "__main__":
    main()
