# freefiregen/__init__.py

import os
import sys

# إضافة مجلد .libs إلى PATH لتحميل DLLs (Python 3.8+)
if sys.platform == 'win32' and sys.version_info >= (3, 8):
    libs_dir = os.path.join(os.path.dirname(__file__), '.libs')
    if os.path.exists(libs_dir):
        os.add_dll_directory(libs_dir)

from .freefiregen import create_bot_account

__version__ = "2.0.4"
__all__ = ["create_bot_account"]