# freefiregen/__init__.py

import os
import sys

# تحميل DLLs قبل استيراد الموديول
if sys.platform == 'win32':
    # أضف مجلد .libs للبحث عن DLLs
    libs_dir = os.path.join(os.path.dirname(__file__), '.libs')
    if os.path.exists(libs_dir):
        # Python 3.8+
        if hasattr(os, 'add_dll_directory'):
            os.add_dll_directory(libs_dir)
        else:
            # Python 3.7 وأقدم
            os.environ['PATH'] = libs_dir + os.pathsep + os.environ.get('PATH', '')

# الآن استورد
from .freefiregen import create_bot_account

__version__ = "2.0.5"
__all__ = ["create_bot_account"]