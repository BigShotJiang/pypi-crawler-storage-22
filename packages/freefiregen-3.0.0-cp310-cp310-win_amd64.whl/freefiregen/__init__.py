#free fire guest gen by @m2_byte
import os
import sys

if sys.platform == 'win32':
    libs_dir = os.path.join(os.path.dirname(__file__), '.libs')
    if os.path.exists(libs_dir):
        if hasattr(os, 'add_dll_directory'):
            os.add_dll_directory(libs_dir)
        else:
            os.environ['PATH'] = libs_dir + os.pathsep + os.environ.get('PATH', '')
from .freefiregen import create_bot_account
#FOR MORE INFO MESSAGE @m2_byte on telegram
__version__ = "3.0.0"
__all__ = ["create_bot_account"]