"""
Setup script для FreeKassa Python Library
"""

from setuptools import setup, find_packages
import os

# Читаем README
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

# Читаем requirements
# Читаем requirements (с обработкой пустого файла)
try:
    with open("requirements.txt", "r", encoding="utf-8") as fh:
        requirements = [line.strip() for line in fh if line.strip() and not line.startswith("#")]
except FileNotFoundError:
    print("Предупреждение: requirements.txt не найден, использую пустой список")
    requirements = []

# Если requirements пустой, установите значения по умолчанию
if not requirements:
    requirements = [
        "requests>=2.25.0",
    ]
    print(f"Использую зависимости по умолчанию: {requirements}")

# Читаем версию из __init__.py
version = {}
with open(os.path.join("src", "freekassa", "__init__.py"), "r", encoding="utf-8") as fh:
    for line in fh:
        if line.startswith("__version__"):
            exec(line, version)
            break

setup(
    name="freekassa-no-off",
    version=version.get("__version__", "1.0.0"),
    author="FreeKassa Library",
    author_email="",
    description="Профессиональная Python библиотека для работы с платежной системой FreeKassa",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/nloveuser/freekassa-no-off",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Office/Business :: Financial",
        "Topic :: Internet :: WWW/HTTP :: Dynamic Content",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: OS Independent",
    ],
    
    python_requires=">=3.7",
    install_requires=requirements,
    
    keywords=[
        "freekassa",
        "payment",
        "gateway",
        "api",
        "sci",
        "webhook",
        "russia",
        "payment-processing",
        "online-payments",
        "ecommerce"
    ],
    
    project_urls={
        "Bug Reports": "https://github.com/nloveuser/freekassa-no-off/issues",
        "Documentation": "https://docs.freekassa.net/",
        "Source": "https://github.com/nloveuser/freekassa-no-off",
    },
)
