"""
FreeKassa Python Library
Профессиональная библиотека для работы с платежной системой FreeKassa
"""

__version__ = "1.0.0"
__author__ = "FreeKassa Library"
__license__ = "MIT"

from .api.client import FreeKassaAPI
from .sci.forms import FreeKassaSCI
from .sci.webhook import FreeKassaWebhookHandler
from .models.currency import FreeKassaCurrency
from .models.status import OrderStatus, RecurrentPeriod
from .exceptions import FreeKassaException

__all__ = [
    'FreeKassaAPI',
    'FreeKassaSCI',
    'FreeKassaWebhookHandler',
    'FreeKassaCurrency',
    'OrderStatus',
    'RecurrentPeriod',
    'FreeKassaException',
]
