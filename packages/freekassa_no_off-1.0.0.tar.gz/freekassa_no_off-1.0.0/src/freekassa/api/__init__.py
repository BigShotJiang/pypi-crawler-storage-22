"""
API модуль FreeKassa
"""

from .client import FreeKassaAPI

__all__ = ['FreeKassaAPI']
