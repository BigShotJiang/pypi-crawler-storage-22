"""
Базовый клиент для работы с API FreeKassa
"""

import time
import json
from typing import Dict, Any
import requests

from ..exceptions import FreeKassaAPIException, FreeKassaNetworkException
from ..utils.crypto import generate_hmac_sha256_signature


class BaseAPIClient:
    """Базовый класс для API клиента"""
    
    API_URL = "https://api.fk.life/v1"
    
    def __init__(self, shop_id: int, api_key: str):
        """
        Инициализация API клиента
        
        Args:
            shop_id: ID магазина
            api_key: API ключ
        """
        self.shop_id = shop_id
        self.api_key = api_key
        self._last_nonce = int(time.time())
    
    def _get_nonce(self) -> int:
        """
        Получение уникального nonce
        
        Returns:
            Уникальный nonce (монотонно возрастающий)
        """
        current_nonce = int(time.time())
        if current_nonce <= self._last_nonce:
            current_nonce = self._last_nonce + 1
        self._last_nonce = current_nonce
        return current_nonce
    
    def _generate_signature(self, data: Dict[str, Any]) -> str:
        """
        Генерация подписи для запроса
        
        Args:
            data: Данные запроса
            
        Returns:
            Подпись
        """
        return generate_hmac_sha256_signature(data, self.api_key)
    
    def _make_request(self, endpoint: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Выполнение API запроса
        
        Args:
            endpoint: Endpoint API
            data: Данные запроса
            
        Returns:
            Ответ от API
            
        Raises:
            FreeKassaAPIException: При ошибке API
            FreeKassaNetworkException: При ошибке сети
        """
        # Добавляем обязательные параметры
        data['shopId'] = self.shop_id
        data['nonce'] = self._get_nonce()
        
        # Генерируем подпись
        data['signature'] = self._generate_signature(data)
        
        url = f"{self.API_URL}/{endpoint}"
        
        try:
            response = requests.post(url, json=data, timeout=30)
            response.raise_for_status()
            
            result = response.json()
            
            # Проверяем тип ответа
            if result.get('type') == 'error':
                raise FreeKassaAPIException(result.get('message', 'Unknown error'))
            
            return result
            
        except requests.exceptions.Timeout:
            raise FreeKassaNetworkException("Превышено время ожидания ответа")
        except requests.exceptions.ConnectionError:
            raise FreeKassaNetworkException("Ошибка соединения с API")
        except requests.exceptions.RequestException as e:
            raise FreeKassaNetworkException(f"Ошибка сети: {str(e)}")
        except json.JSONDecodeError:
            raise FreeKassaAPIException("Невалидный JSON ответ от API")
