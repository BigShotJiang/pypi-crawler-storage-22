"""
Главный API клиент FreeKassa
"""

from .base import BaseAPIClient
from .orders import OrdersMixin
from .withdrawals import WithdrawalsMixin
from .info import InfoMixin


class FreeKassaAPI(BaseAPIClient, OrdersMixin, WithdrawalsMixin, InfoMixin):
    """
    Полный API клиент FreeKassa
    
    Объединяет все методы для работы с API:
    - Заказы (создание, получение, возврат)
    - Выплаты (создание, получение списка)
    - Информация (баланс, валюты, магазины)
    
    Examples:
        >>> api = FreeKassaAPI(shop_id=777, api_key='your_key')
        >>> 
        >>> # Создание заказа
        >>> order = api.create_order(
        ...     currency_id=4,
        ...     email='customer@example.com',
        ...     ip='192.168.1.1',
        ...     amount=1000.00,
        ...     currency='RUB'
        ... )
        >>> print(order['location'])
        >>> 
        >>> # Получение баланса
        >>> balance = api.get_balance()
        >>> 
        >>> # Список заказов
        >>> orders = api.get_orders(order_status=1)
    """
    
    def __init__(self, shop_id: int, api_key: str):
        """
        Инициализация API клиента
        
        Args:
            shop_id: ID магазина из личного кабинета
            api_key: API ключ из настроек магазина
        """
        super().__init__(shop_id, api_key)
