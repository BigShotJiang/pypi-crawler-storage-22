"""
Информационные методы API
"""

from typing import Dict, Any


class InfoMixin:
    """Миксин с информационными методами"""
    
    def get_balance(self) -> Dict[str, Any]:
        """
        Получение баланса магазина
        
        Returns:
            Баланс по валютам
        """
        return self._make_request('balance', {})
    
    def get_currencies(self) -> Dict[str, Any]:
        """
        Получение списка доступных платежных систем
        
        Returns:
            Список платежных систем
        """
        return self._make_request('currencies', {})
    
    def check_currency_status(self, currency_id: int) -> Dict[str, Any]:
        """
        Проверка доступности платежной системы
        
        Args:
            currency_id: ID платежной системы
            
        Returns:
            Статус доступности
        """
        return self._make_request(f'currencies/{currency_id}/status', {})
    
    def get_shops(self) -> Dict[str, Any]:
        """
        Получение списка магазинов
        
        Returns:
            Список магазинов пользователя
        """
        return self._make_request('shops', {})
