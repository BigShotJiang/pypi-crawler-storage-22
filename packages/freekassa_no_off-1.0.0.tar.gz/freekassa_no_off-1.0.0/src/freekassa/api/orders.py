"""
Методы для работы с заказами
"""

from typing import Optional, Dict, Any
from ..utils.validators import (
    validate_amount,
    validate_currency,
    validate_email,
    validate_order_id
)


class OrdersMixin:
    """Миксин с методами для работы с заказами"""
    
    def get_orders(
        self,
        order_id: Optional[int] = None,
        payment_id: Optional[str] = None,
        order_status: Optional[int] = None,
        date_from: Optional[str] = None,
        date_to: Optional[str] = None,
        page: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        Получение списка заказов
        
        Args:
            order_id: Номер заказа FreeKassa
            payment_id: Номер заказа в магазине
            order_status: Статус заказа
            date_from: Дата с (формат: 2021-01-01 13:45:21)
            date_to: Дата по (формат: 2021-01-02 13:45:21)
            page: Номер страницы
            
        Returns:
            Список заказов
        """
        data = {}
        
        if order_id is not None:
            data['orderId'] = order_id
        if payment_id is not None:
            data['paymentId'] = payment_id
        if order_status is not None:
            data['orderStatus'] = order_status
        if date_from is not None:
            data['dateFrom'] = date_from
        if date_to is not None:
            data['dateTo'] = date_to
        if page is not None:
            data['page'] = page
        
        return self._make_request('orders', data)
    
    def create_order(
        self,
        currency_id: int,
        email: str,
        ip: str,
        amount: float,
        currency: str,
        payment_id: Optional[str] = None,
        tel: Optional[str] = None,
        success_url: Optional[str] = None,
        failure_url: Optional[str] = None,
        notification_url: Optional[str] = None,
        recurrent: bool = False,
        recurrent_period: Optional[str] = None,
        recurrent_description: Optional[str] = None,
        recurrent_order_id: Optional[int] = None,
        **extra_fields
    ) -> Dict[str, Any]:
        """
        Создание заказа и получение ссылки на оплату
        
        Args:
            currency_id: ID платежной системы
            email: Email покупателя
            ip: IP адрес покупателя
            amount: Сумма оплаты
            currency: Валюта оплаты (RUB, USD, EUR, UAH, KZT)
            payment_id: Номер заказа в магазине
            tel: Телефон плательщика
            success_url: Переопределение URL успеха
            failure_url: Переопределение URL ошибки
            notification_url: Переопределение URL уведомлений
            recurrent: Флаг рекуррентного платежа
            recurrent_period: Периодичность (day, week, month, year)
            recurrent_description: Описание рекуррентного платежа
            recurrent_order_id: ID рекуррентного платежа для повторной оплаты
            **extra_fields: Дополнительные поля
            
        Returns:
            Информация о созданном заказе с ссылкой на оплату
            
        Raises:
            FreeKassaValidationException: При ошибке валидации
        """
        # Валидация
        validate_amount(amount)
        validate_currency(currency)
        validate_email(email)
        
        data = {
            'i': currency_id,
            'email': email,
            'ip': ip,
            'amount': amount,
            'currency': currency
        }
        
        if payment_id is not None:
            validate_order_id(payment_id)
            data['paymentId'] = payment_id
        if tel is not None:
            data['tel'] = tel
        if success_url is not None:
            data['success_url'] = success_url
        if failure_url is not None:
            data['failure_url'] = failure_url
        if notification_url is not None:
            data['notification_url'] = notification_url
        
        # Рекуррентные платежи
        if recurrent:
            data['recurrent'] = 'Y'
            if recurrent_period:
                data['recurrent_period'] = recurrent_period
            if recurrent_description:
                data['recurrent_description'] = recurrent_description
        
        if recurrent_order_id is not None:
            data['recurrent_order_id'] = recurrent_order_id
        
        # Добавляем дополнительные поля
        data.update(extra_fields)
        
        return self._make_request('orders/create', data)
    
    def refund_order(
        self,
        order_id: Optional[int] = None,
        payment_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Возврат средств по заказу
        
        Args:
            order_id: Номер заказа FreeKassa
            payment_id: Номер заказа в магазине
            
        Returns:
            Информация о возврате
            
        Raises:
            ValueError: Если не указан ни один ID
        """
        if order_id is None and payment_id is None:
            raise ValueError("Необходимо указать order_id или payment_id")
        
        data = {}
        if order_id is not None:
            data['orderId'] = order_id
        if payment_id is not None:
            data['paymentId'] = payment_id
        
        return self._make_request('orders/refund', data)
