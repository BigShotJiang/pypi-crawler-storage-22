"""
Методы для работы с выплатами
"""

from typing import Optional, Dict, Any
from ..utils.validators import validate_amount, validate_currency


class WithdrawalsMixin:
    """Миксин с методами для работы с выплатами"""
    
    def get_withdrawals(
        self,
        order_id: Optional[int] = None,
        payment_id: Optional[str] = None,
        order_status: Optional[int] = None,
        date_from: Optional[str] = None,
        date_to: Optional[str] = None,
        page: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        Получение списка выплат
        
        Args:
            order_id: Номер заказа FreeKassa
            payment_id: Номер заказа в магазине
            order_status: Статус заказа
            date_from: Дата с
            date_to: Дата по
            page: Номер страницы
            
        Returns:
            Список выплат
        """
        data = {}
        
        if order_id is not None:
            data['orderId'] = order_id
        if payment_id is not None:
            data['paymentId'] = payment_id
        if order_status is not None:
            data['orderStatus'] = order_status
        if date_from is not None:
            data['dateFrom'] = date_from
        if date_to is not None:
            data['dateTo'] = date_to
        if page is not None:
            data['page'] = page
        
        return self._make_request('withdrawals', data)
    
    def create_withdrawal(
        self,
        currency_id: int,
        account: str,
        amount: float,
        currency: str,
        payment_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Создание выплаты
        
        Args:
            currency_id: ID платежной системы
            account: Кошелек для зачисления
            amount: Сумма выплаты
            currency: Валюта
            payment_id: Номер заказа в магазине
            
        Returns:
            Информация о выплате
            
        Raises:
            FreeKassaValidationException: При ошибке валидации
        """
        # Валидация
        validate_amount(amount)
        validate_currency(currency)
        
        data = {
            'i': currency_id,
            'account': account,
            'amount': amount,
            'currency': currency
        }
        
        if payment_id is not None:
            data['paymentId'] = payment_id
        
        return self._make_request('withdrawals/create', data)
    
    def get_withdrawal_currencies(self) -> Dict[str, Any]:
        """
        Получение списка платежных систем для вывода
        
        Returns:
            Список платежных систем для вывода
        """
        return self._make_request('withdrawals/currencies', {})
