"""
Исключения для FreeKassa
"""


class FreeKassaException(Exception):
    """Базовое исключение для всех ошибок FreeKassa"""
    pass


class FreeKassaAPIException(FreeKassaException):
    """Ошибка при работе с API"""
    pass


class FreeKassaValidationException(FreeKassaException):
    """Ошибка валидации данных"""
    pass


class FreeKassaSignatureException(FreeKassaException):
    """Ошибка проверки подписи"""
    pass


class FreeKassaIPException(FreeKassaException):
    """Ошибка проверки IP адреса"""
    pass


class FreeKassaNetworkException(FreeKassaException):
    """Ошибка сетевого соединения"""
    pass
