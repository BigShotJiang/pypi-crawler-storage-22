"""
Модель валют и платежных систем FreeKassa
"""


class FreeKassaCurrency:
    """Константы ID платежных систем FreeKassa"""
    
    # Электронные кошельки FreeKassa
    FK_WALLET_RUB = 1
    FK_WALLET_USD = 2
    FK_WALLET_EUR = 3
    
    # Банковские карты
    VISA_RUB = 4
    VISA_UAH = 7
    VISA_EUR = 11
    VISA_USD = 32
    VISA_MASTERCARD_KZT = 41
    
    MASTERCARD_RUB = 8
    MASTERCARD_UAH = 9
    
    MIR = 12
    
    # Российские платежные системы
    YOOMONEY = 6
    QIWI = 10
    QIWI_API = 35
    SBP = 42
    SBP_API = 44
    ONLINE_BANK = 13
    CARD_RUB_API = 36
    
    # Мобильные платежи
    GOOGLE_PAY = 37
    APPLE_PAY = 38
    MEGAFON = 28
    
    # Международные системы
    PERFECT_MONEY_USD = 33
    WEBMONEY_WMZ = 40
    
    # Криптовалюты - Bitcoin и форки
    BITCOIN = 24
    BITCOIN_CASH = 16
    LITECOIN = 25
    DOGECOIN = 19
    DASH = 18
    ZCASH = 20
    
    # Ethereum и ERC-20
    ETHEREUM = 26
    USDT_ERC20 = 14
    
    # Tron и TRC-20
    TRON = 39
    USDT_TRC20 = 15
    
    # Другие криптовалюты
    BNB = 17
    MONERO = 21
    WAVES = 22
    RIPPLE = 23
    SHIBA_INU = 34
    
    # Специальные
    STEAMPAY = 27
    
    @classmethod
    def get_name(cls, currency_id: int) -> str:
        """
        Получить название платежной системы по ID
        
        Args:
            currency_id: ID платежной системы
            
        Returns:
            Название платежной системы
        """
        currency_map = {
            1: "FK Wallet RUB",
            2: "FK Wallet USD",
            3: "FK Wallet EUR",
            4: "VISA RUB",
            6: "Yoomoney",
            7: "VISA UAH",
            8: "MasterCard RUB",
            9: "MasterCard UAH",
            10: "QIWI",
            11: "VISA EUR",
            12: "МИР",
            13: "Онлайн банк",
            14: "USDT (ERC20)",
            15: "USDT (TRC20)",
            16: "Bitcoin Cash",
            17: "BNB",
            18: "DASH",
            19: "Dogecoin",
            20: "ZCash",
            21: "Monero",
            22: "Waves",
            23: "Ripple",
            24: "Bitcoin",
            25: "Litecoin",
            26: "Ethereum",
            27: "SteamPay",
            28: "Мегафон",
            32: "VISA USD",
            33: "Perfect Money USD",
            34: "Shiba Inu",
            35: "QIWI API",
            36: "Card RUB API",
            37: "Google Pay",
            38: "Apple Pay",
            39: "Tron",
            40: "Webmoney WMZ",
            41: "VISA/MasterCard KZT",
            42: "СБП",
            44: "СБП (API)",
        }
        return currency_map.get(currency_id, f"Unknown ({currency_id})")
    
    @classmethod
    def get_all(cls) -> dict:
        """
        Получить словарь всех валют
        
        Returns:
            Словарь {ID: название}
        """
        return {
            value: cls.get_name(value)
            for name, value in vars(cls).items()
            if isinstance(value, int) and not name.startswith('_')
        }
