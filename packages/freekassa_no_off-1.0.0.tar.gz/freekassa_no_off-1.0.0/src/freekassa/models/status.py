"""
Модели статусов и периодов
"""


class OrderStatus:
    """Статусы заказов FreeKassa"""
    
    NEW = 0
    PAID = 1
    REFUND = 6
    ERROR = 8
    CANCELLED = 9
    
    @classmethod
    def get_name(cls, status: int) -> str:
        """
        Получить название статуса
        
        Args:
            status: Код статуса
            
        Returns:
            Название статуса
        """
        status_map = {
            0: "Новый",
            1: "Оплачен",
            6: "Возврат",
            8: "Ошибка",
            9: "Отмена",
        }
        return status_map.get(status, f"Неизвестный ({status})")


class RecurrentPeriod:
    """Периоды для рекуррентных платежей"""
    
    DAY = "day"
    WEEK = "week"
    MONTH = "month"
    YEAR = "year"
    
    @classmethod
    def get_all(cls) -> list:
        """Получить список всех периодов"""
        return [cls.DAY, cls.WEEK, cls.MONTH, cls.YEAR]
    
    @classmethod
    def validate(cls, period: str) -> bool:
        """
        Проверить валидность периода
        
        Args:
            period: Период для проверки
            
        Returns:
            True если период валиден
        """
        return period in cls.get_all()
