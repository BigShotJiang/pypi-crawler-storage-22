"""
Модуль для работы с платежными формами SCI
"""

from typing import Optional, Dict
from ..utils.crypto import generate_md5_signature
from ..utils.validators import validate_amount, validate_currency, validate_order_id


class FreeKassaSCI:
    """
    Класс для работы с SCI (Shop Cart Interface)
    Генерация платежных форм и URL
    """
    
    PAYMENT_URL = "https://pay.fk.money/"
    
    def __init__(self, merchant_id: int, secret_word: str, secret_word_2: str):
        """
        Инициализация SCI
        
        Args:
            merchant_id: ID магазина
            secret_word: Секретное слово для формы оплаты
            secret_word_2: Секретное слово 2 для проверки уведомлений
        """
        self.merchant_id = merchant_id
        self.secret_word = secret_word
        self.secret_word_2 = secret_word_2
    
    def generate_payment_signature(
        self,
        amount: float,
        currency: str,
        order_id: str
    ) -> str:
        """
        Генерация подписи для платежной формы
        
        Args:
            amount: Сумма платежа
            currency: Валюта платежа
            order_id: Номер заказа
            
        Returns:
            MD5 подпись
            
        Raises:
            FreeKassaValidationException: При ошибке валидации
        """
        validate_amount(amount)
        validate_currency(currency)
        validate_order_id(order_id)
        
        sign_string = f"{self.merchant_id}:{amount}:{self.secret_word}:{currency}:{order_id}"
        return generate_md5_signature(sign_string)
    
    def generate_payment_url(
        self,
        amount: float,
        currency: str,
        order_id: str,
        currency_id: Optional[int] = None,
        phone: Optional[str] = None,
        email: Optional[str] = None,
        lang: str = 'ru',
        custom_params: Optional[Dict[str, str]] = None
    ) -> str:
        """
        Генерация URL для оплаты
        
        Args:
            amount: Сумма платежа
            currency: Валюта платежа (RUB, USD, EUR, UAH, KZT)
            order_id: Номер заказа
            currency_id: Предлагаемая валюта платежа (ID)
            phone: Телефон плательщика
            email: Email плательщика
            lang: Язык интерфейса (ru/en)
            custom_params: Дополнительные параметры с префиксом us_
            
        Returns:
            URL для оплаты
        """
        signature = self.generate_payment_signature(amount, currency, order_id)
        
        params = {
            'm': self.merchant_id,
            'oa': amount,
            'currency': currency,
            'o': order_id,
            's': signature,
            'lang': lang
        }
        
        if currency_id is not None:
            params['i'] = currency_id
        if phone is not None:
            params['phone'] = phone
        if email is not None:
            params['em'] = email
        
        # Добавляем пользовательские параметры
        if custom_params:
            for key, value in custom_params.items():
                if not key.startswith('us_'):
                    key = f'us_{key}'
                params[key] = value
        
        # Формируем query string
        query_string = '&'.join([f"{k}={v}" for k, v in params.items()])
        
        return f"{self.PAYMENT_URL}?{query_string}"
    
    def generate_payment_form_html(
        self,
        amount: float,
        currency: str,
        order_id: str,
        currency_id: Optional[int] = None,
        phone: Optional[str] = None,
        email: Optional[str] = None,
        lang: str = 'ru',
        custom_params: Optional[Dict[str, str]] = None,
        button_text: str = 'Оплатить'
    ) -> str:
        """
        Генерация HTML формы для оплаты
        
        Args:
            amount: Сумма платежа
            currency: Валюта платежа
            order_id: Номер заказа
            currency_id: Предлагаемая валюта платежа
            phone: Телефон плательщика
            email: Email плательщика
            lang: Язык интерфейса
            custom_params: Дополнительные параметры
            button_text: Текст кнопки оплаты
            
        Returns:
            HTML код формы
        """
        signature = self.generate_payment_signature(amount, currency, order_id)
        
        html_parts = [
            f"<form method='get' action='{self.PAYMENT_URL}'>",
            f"  <input type='hidden' name='m' value='{self.merchant_id}'>",
            f"  <input type='hidden' name='oa' value='{amount}'>",
            f"  <input type='hidden' name='o' value='{order_id}'>",
            f"  <input type='hidden' name='s' value='{signature}'>",
            f"  <input type='hidden' name='currency' value='{currency}'>",
            f"  <input type='hidden' name='lang' value='{lang}'>"
        ]
        
        if currency_id is not None:
            html_parts.append(f"  <input type='hidden' name='i' value='{currency_id}'>")
        if phone is not None:
            html_parts.append(f"  <input type='hidden' name='phone' value='{phone}'>")
        if email is not None:
            html_parts.append(f"  <input type='hidden' name='em' value='{email}'>")
        
        # Добавляем пользовательские параметры
        if custom_params:
            for key, value in custom_params.items():
                if not key.startswith('us_'):
                    key = f'us_{key}'
                html_parts.append(f"  <input type='hidden' name='{key}' value='{value}'>")
        
        html_parts.append(f"  <input type='submit' value='{button_text}'>")
        html_parts.append("</form>")
        
        return '\n'.join(html_parts)
