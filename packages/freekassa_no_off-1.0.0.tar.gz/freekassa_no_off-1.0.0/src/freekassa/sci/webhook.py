"""
Модуль для обработки webhook уведомлений
"""

from typing import Dict, Any, Optional
from ..utils.crypto import generate_md5_signature, verify_signature
from ..utils.validators import validate_ip, ALLOWED_IPS
from ..exceptions import FreeKassaSignatureException, FreeKassaIPException


class WebhookParser:
    """Парсер webhook уведомлений"""
    
    def __init__(self, merchant_id: int, secret_word_2: str):
        """
        Инициализация парсера
        
        Args:
            merchant_id: ID магазина
            secret_word_2: Секретное слово 2
        """
        self.merchant_id = merchant_id
        self.secret_word_2 = secret_word_2
    
    def generate_notification_signature(
        self,
        merchant_id: int,
        amount: float,
        merchant_order_id: str
    ) -> str:
        """
        Генерация подписи для уведомления
        
        Args:
            merchant_id: ID магазина
            amount: Сумма платежа
            merchant_order_id: Номер заказа
            
        Returns:
            MD5 подпись
        """
        sign_string = f"{merchant_id}:{amount}:{self.secret_word_2}:{merchant_order_id}"
        return generate_md5_signature(sign_string)
    
    def verify_notification_signature(
        self,
        merchant_id: int,
        amount: float,
        merchant_order_id: str,
        sign: str
    ) -> bool:
        """
        Проверка подписи уведомления
        
        Args:
            merchant_id: ID магазина из уведомления
            amount: Сумма из уведомления
            merchant_order_id: Номер заказа из уведомления
            sign: Подпись из уведомления
            
        Returns:
            True если подпись верна
        """
        expected_sign = self.generate_notification_signature(
            merchant_id, amount, merchant_order_id
        )
        return verify_signature(expected_sign, sign)
    
    def parse_notification(self, request_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Парсинг данных уведомления
        
        Args:
            request_data: Данные из POST/GET запроса
            
        Returns:
            Распарсенные данные уведомления
            
        Raises:
            FreeKassaSignatureException: При ошибке проверки подписи
        """
        notification = {
            'merchant_id': int(request_data.get('MERCHANT_ID', 0)),
            'amount': float(request_data.get('AMOUNT', 0)),
            'intid': int(request_data.get('intid', 0)),
            'merchant_order_id': request_data.get('MERCHANT_ORDER_ID', ''),
            'email': request_data.get('P_EMAIL', ''),
            'phone': request_data.get('P_PHONE', ''),
            'currency_id': int(request_data.get('CUR_ID', 0)),
            'sign': request_data.get('SIGN', ''),
            'payer_account': request_data.get('payer_account', ''),
            'commission': float(request_data.get('commission', 0)),
            'custom_params': {}
        }
        
        # Извлекаем пользовательские параметры
        for key, value in request_data.items():
            if key.startswith('us_'):
                notification['custom_params'][key] = value
        
        # Проверяем подпись
        if not self.verify_notification_signature(
            notification['merchant_id'],
            notification['amount'],
            notification['merchant_order_id'],
            notification['sign']
        ):
            raise FreeKassaSignatureException("Невалидная подпись уведомления")
        
        return notification


class FreeKassaWebhookHandler:
    """
    Обработчик webhook уведомлений
    
    Examples:
        >>> handler = FreeKassaWebhookHandler(sci)
        >>> 
        >>> # В вашем веб-обработчике
        >>> notification = handler.handle_notification(
        ...     request_data=request.POST,
        ...     client_ip=request.remote_addr,
        ...     verify_ip=True
        ... )
        >>> 
        >>> print(f"Заказ {notification['merchant_order_id']} оплачен!")
        >>> return handler.get_success_response()
    """
    
    ALLOWED_IPS = ALLOWED_IPS
    
    def __init__(self, sci):
        """
        Инициализация обработчика
        
        Args:
            sci: Экземпляр FreeKassaSCI
        """
        self.parser = WebhookParser(sci.merchant_id, sci.secret_word_2)
    
    def verify_ip(self, ip_address: str) -> bool:
        """
        Проверка IP адреса
        
        Args:
            ip_address: IP адрес для проверки
            
        Returns:
            True если IP разрешен
        """
        return validate_ip(ip_address)
    
    def handle_notification(
        self,
        request_data: Dict[str, Any],
        client_ip: Optional[str] = None,
        verify_ip: bool = True
    ) -> Dict[str, Any]:
        """
        Обработка webhook уведомления
        
        Args:
            request_data: Данные из запроса
            client_ip: IP адрес клиента
            verify_ip: Проверять ли IP адрес
            
        Returns:
            Распарсенные данные уведомления
            
        Raises:
            FreeKassaIPException: При невалидном IP
            FreeKassaSignatureException: При невалидной подписи
        """
        # Проверяем IP
        if verify_ip and client_ip:
            if not self.verify_ip(client_ip):
                raise FreeKassaIPException(f"Невалидный IP адрес: {client_ip}")
        
        # Парсим и валидируем уведомление
        notification = self.parser.parse_notification(request_data)
        
        return notification
    
    @staticmethod
    def get_success_response() -> str:
        """
        Получение ответа об успешной обработке
        
        Returns:
            Строка 'YES' для подтверждения
        """
        return 'YES'
