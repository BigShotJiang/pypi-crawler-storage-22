"""
Утилиты для работы с криптографией и подписями
"""

import hashlib
import hmac
from typing import Dict, Any


def generate_md5_signature(data: str) -> str:
    """
    Генерация MD5 подписи
    
    Args:
        data: Данные для подписи
        
    Returns:
        MD5 хеш
    """
    return hashlib.md5(data.encode('utf-8')).hexdigest()


def generate_hmac_sha256_signature(data: Dict[str, Any], secret_key: str) -> str:
    """
    Генерация HMAC SHA256 подписи
    
    Args:
        data: Словарь данных для подписи
        secret_key: Секретный ключ
        
    Returns:
        HMAC SHA256 подпись
    """
    # Сортируем данные по ключам
    sorted_data = dict(sorted(data.items()))
    
    # Объединяем значения с разделителем |
    values = [str(v) for v in sorted_data.values()]
    message = '|'.join(values)
    
    # Создаем HMAC SHA256 подпись
    signature = hmac.new(
        secret_key.encode('utf-8'),
        message.encode('utf-8'),
        hashlib.sha256
    ).hexdigest()
    
    return signature


def verify_signature(expected: str, actual: str) -> bool:
    """
    Проверка подписи
    
    Args:
        expected: Ожидаемая подпись
        actual: Полученная подпись
        
    Returns:
        True если подписи совпадают
    """
    return expected == actual
