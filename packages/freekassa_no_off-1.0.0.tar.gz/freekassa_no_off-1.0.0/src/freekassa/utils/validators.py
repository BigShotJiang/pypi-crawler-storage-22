"""
Утилиты для валидации данных
"""

import re
from typing import Optional
from ..exceptions import FreeKassaValidationException


# IP адреса серверов FreeKassa
ALLOWED_IPS = ['168.119.157.136', '168.119.60.227', '178.154.197.79', '51.250.54.238']


def validate_ip(ip_address: str) -> bool:
    """
    Проверка IP адреса FreeKassa
    
    Args:
        ip_address: IP адрес для проверки
        
    Returns:
        True если IP разрешен
    """
    return ip_address in ALLOWED_IPS


def validate_amount(amount: float) -> None:
    """
    Валидация суммы платежа
    
    Args:
        amount: Сумма для проверки
        
    Raises:
        FreeKassaValidationException: Если сумма невалидна
    """
    if amount <= 0:
        raise FreeKassaValidationException("Сумма должна быть больше нуля")
    
    if amount > 1000000000:
        raise FreeKassaValidationException("Сумма слишком большая")


def validate_currency(currency: str) -> None:
    """
    Валидация валюты
    
    Args:
        currency: Код валюты
        
    Raises:
        FreeKassaValidationException: Если валюта невалидна
    """
    allowed_currencies = ['RUB', 'USD', 'EUR', 'UAH', 'KZT']
    
    if currency not in allowed_currencies:
        raise FreeKassaValidationException(
            f"Невалидная валюта: {currency}. Разрешены: {', '.join(allowed_currencies)}"
        )


def validate_email(email: str) -> None:
    """
    Валидация email адреса
    
    Args:
        email: Email для проверки
        
    Raises:
        FreeKassaValidationException: Если email невалиден
    """
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    
    if not re.match(pattern, email):
        raise FreeKassaValidationException(f"Невалидный email: {email}")


def validate_order_id(order_id: str) -> None:
    """
    Валидация ID заказа
    
    Args:
        order_id: ID заказа
        
    Raises:
        FreeKassaValidationException: Если ID невалиден
    """
    if not order_id or len(order_id) > 255:
        raise FreeKassaValidationException("ID заказа должен быть от 1 до 255 символов")


def validate_phone(phone: Optional[str]) -> None:
    """
    Валидация телефона
    
    Args:
        phone: Номер телефона
        
    Raises:
        FreeKassaValidationException: Если телефон невалиден
    """
    if phone is None:
        return
    
    # Простая проверка: только цифры и +
    pattern = r'^\+?\d{10,15}$'
    
    if not re.match(pattern, phone):
        raise FreeKassaValidationException(
            f"Невалидный телефон: {phone}. Формат: +71234567890"
        )
