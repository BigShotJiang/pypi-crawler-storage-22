"""
Тесты для FreeKassa библиотеки
"""

import unittest
import sys
import os

# Добавляем путь к src
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from unittest.mock import Mock, patch
from freekassa import (
    FreeKassaAPI,
    FreeKassaSCI,
    FreeKassaWebhookHandler,
    FreeKassaCurrency,
    OrderStatus,
    RecurrentPeriod,
    FreeKassaException
)
from freekassa.exceptions import (
    FreeKassaSignatureException,
    FreeKassaValidationException,
    FreeKassaIPException
)


class TestFreeKassaCurrency(unittest.TestCase):
    """Тесты для модели валют"""
    
    def test_currency_constants(self):
        """Тест констант валют"""
        self.assertEqual(FreeKassaCurrency.VISA_RUB, 4)
        self.assertEqual(FreeKassaCurrency.BITCOIN, 24)
        self.assertEqual(FreeKassaCurrency.SBP, 42)
    
    def test_get_name(self):
        """Тест получения имени валюты"""
        self.assertEqual(FreeKassaCurrency.get_name(4), "VISA RUB")
        self.assertEqual(FreeKassaCurrency.get_name(24), "Bitcoin")
    
    def test_get_all(self):
        """Тест получения всех валют"""
        currencies = FreeKassaCurrency.get_all()
        self.assertIsInstance(currencies, dict)
        self.assertIn(4, currencies)
        self.assertIn(24, currencies)


class TestOrderStatus(unittest.TestCase):
    """Тесты для статусов заказов"""
    
    def test_status_constants(self):
        """Тест констант статусов"""
        self.assertEqual(OrderStatus.NEW, 0)
        self.assertEqual(OrderStatus.PAID, 1)
        self.assertEqual(OrderStatus.REFUND, 6)
    
    def test_get_name(self):
        """Тест получения имени статуса"""
        self.assertEqual(OrderStatus.get_name(0), "Новый")
        self.assertEqual(OrderStatus.get_name(1), "Оплачен")


class TestRecurrentPeriod(unittest.TestCase):
    """Тесты для периодов рекуррентных платежей"""
    
    def test_period_constants(self):
        """Тест констант периодов"""
        self.assertEqual(RecurrentPeriod.DAY, "day")
        self.assertEqual(RecurrentPeriod.MONTH, "month")
    
    def test_validate(self):
        """Тест валидации периода"""
        self.assertTrue(RecurrentPeriod.validate("day"))
        self.assertTrue(RecurrentPeriod.validate("month"))
        self.assertFalse(RecurrentPeriod.validate("invalid"))
    
    def test_get_all(self):
        """Тест получения всех периодов"""
        periods = RecurrentPeriod.get_all()
        self.assertEqual(len(periods), 4)
        self.assertIn("day", periods)


class TestFreeKassaAPI(unittest.TestCase):
    """Тесты для API клиента"""
    
    def setUp(self):
        """Настройка тестов"""
        self.api = FreeKassaAPI(shop_id=777, api_key='test_key')
    
    def test_initialization(self):
        """Тест инициализации"""
        self.assertEqual(self.api.shop_id, 777)
        self.assertEqual(self.api.api_key, 'test_key')
    
    def test_nonce_generation(self):
        """Тест генерации nonce"""
        nonce1 = self.api._get_nonce()
        nonce2 = self.api._get_nonce()
        self.assertGreater(nonce2, nonce1)
    
    @patch('requests.post')
    def test_make_request_success(self, mock_post):
        """Тест успешного запроса"""
        mock_response = Mock()
        mock_response.json.return_value = {'type': 'success', 'data': {}}
        mock_response.raise_for_status = Mock()
        mock_post.return_value = mock_response
        
        result = self.api._make_request('test', {})
        self.assertEqual(result['type'], 'success')
    
    def test_create_order_validation(self):
        """Тест валидации при создании заказа"""
        with self.assertRaises(FreeKassaValidationException):
            self.api.create_order(
                currency_id=4,
                email='invalid-email',
                ip='192.168.1.1',
                amount=1000,
                currency='RUB'
            )


class TestFreeKassaSCI(unittest.TestCase):
    """Тесты для SCI"""
    
    def setUp(self):
        """Настройка тестов"""
        self.sci = FreeKassaSCI(777, 'secret1', 'secret2')
    
    def test_initialization(self):
        """Тест инициализации"""
        self.assertEqual(self.sci.merchant_id, 777)
        self.assertEqual(self.sci.secret_word, 'secret1')
    
    def test_generate_payment_url(self):
        """Тест генерации URL"""
        url = self.sci.generate_payment_url(
            amount=1000.00,
            currency='RUB',
            order_id='TEST-123'
        )
        
        self.assertTrue(url.startswith(self.sci.PAYMENT_URL))
        self.assertIn('m=777', url)
        self.assertIn('oa=1000.0', url)
    
    def test_generate_payment_form_html(self):
        """Тест генерации HTML формы"""
        html = self.sci.generate_payment_form_html(
            amount=1000.00,
            currency='RUB',
            order_id='TEST-123'
        )
        
        self.assertIn('<form', html)
        self.assertIn('</form>', html)
        self.assertIn('name=\'m\'', html)


class TestWebhookHandler(unittest.TestCase):
    """Тесты для обработчика webhook"""
    
    def setUp(self):
        """Настройка тестов"""
        self.sci = FreeKassaSCI(777, 'secret1', 'secret2')
        self.handler = FreeKassaWebhookHandler(self.sci)
    
    def test_verify_ip_valid(self):
        """Тест валидного IP"""
        self.assertTrue(self.handler.verify_ip('168.119.157.136'))
    
    def test_verify_ip_invalid(self):
        """Тест невалидного IP"""
        self.assertFalse(self.handler.verify_ip('192.168.1.1'))
    
    def test_get_success_response(self):
        """Тест ответа успеха"""
        response = self.handler.get_success_response()
        self.assertEqual(response, 'YES')
    
    def test_handle_notification_invalid_ip(self):
        """Тест обработки с невалидным IP"""
        # Генерируем правильную подпись
        from freekassa.utils.crypto import generate_md5_signature
        sign_string = f"777:1000.0:secret2:TEST-123"
        sign = generate_md5_signature(sign_string)
        
        request_data = {
            'MERCHANT_ID': '777',
            'AMOUNT': '1000.0',
            'intid': '12345',
            'MERCHANT_ORDER_ID': 'TEST-123',
            'P_EMAIL': 'test@test.com',
            'CUR_ID': '4',
            'SIGN': sign
        }
        
        with self.assertRaises(FreeKassaIPException):
            self.handler.handle_notification(
                request_data=request_data,
                client_ip='192.168.1.1',
                verify_ip=True
            )


if __name__ == '__main__':
    unittest.main()
