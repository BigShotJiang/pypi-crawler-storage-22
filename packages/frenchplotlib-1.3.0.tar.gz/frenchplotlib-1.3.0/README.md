# 🥖 frenchplotlib

Une bibliothèque Python pour ajouter une touche française à vos visualisations matplotlib avec des marqueurs personnalisés et des palettes de couleurs inspirées de la France.

## 📝 Description

**frenchplotlib** enrichit vos graphiques matplotlib avec :

- 🥐 **17 marqueurs personnalisés** en forme d'icônes françaises (baguette, croissant, vin, fromage, etc.)
- 🎨 **16 palettes de couleurs** inspirées de la culture française (tricolore, lavande de Provence, Bordeaux, etc.)

## 🚀 Installation

```bash
pip install frenchplotlib
```

## 📦 Prérequis

- Python >= 3.6
- matplotlib
- numpy

### Pour les marqueurs SVG personnalisés (optionnel)

Si vous souhaitez utiliser `load_svg_marker()` pour charger vos propres fichiers SVG :

```bash
pip install svgpathtools svgpath2mpl
```

## 💡 Utilisation

### Marqueurs personnalisés prédéfinis

```python
import matplotlib.pyplot as plt
import numpy as np
from frenchplotlib import tapisseries

# Données d'exemple
x = np.linspace(-1, 1, 20)
y = np.sin(x)

# Utilisation d'un marqueur en forme de boule de pain
plt.figure(figsize=(10, 6))
plt.scatter(x, y, marker=tapisseries.boule, s=500)
plt.title("Graphique avec marqueur français")
plt.show()
```

### Marqueurs personnalisés depuis SVG

Vous pouvez également charger vos propres marqueurs SVG ou utiliser les marqueurs fournis dans le dossier `assets/` :

```python
import matplotlib.pyplot as plt
import numpy as np
from frenchplotlib.custom_marker import load_svg_marker

# Charger un marqueur SVG personnalisé
marker = load_svg_marker('frenchplotlib/assets/baguette.svg')

# Ou utilisez votre propre fichier SVG
# marker = load_svg_marker('chemin/vers/votre/fichier.svg')

# Données d'exemple
x = np.linspace(-1, 1, 20)
y = np.sin(x)

# Utilisation du marqueur personnalisé
plt.figure(figsize=(10, 6))
plt.scatter(x, y, marker=marker, s=500)
plt.title("Graphique avec marqueur SVG personnalisé")
plt.show()
```

**Avantages des marqueurs SVG personnalisés :**
- 🎨 Utilisez n'importe quel fichier SVG comme marqueur
- 🔧 Plus de flexibilité pour créer vos propres designs
- 📦 Tous les marqueurs français sont disponibles en SVG dans `frenchplotlib/assets/`
- 🎯 Le marqueur est automatiquement centré et mis à l'échelle

**Fichiers SVG disponibles :**
- `baguette.svg`, `boule.svg`, `bretzel.svg`, `brioche.svg`
- `camembert.svg`, `croissant.svg`, `eclair.svg`, `escargot.svg`
- `fougasse.svg`, `fromage.svg`, `macaron.svg`, `madeleine.svg`
- `pain_au_chocolat.svg`, `pain_de_mie.svg`, `pita.svg`
- `religieuse.svg`, `vin.svg`

### Palettes de couleurs

```python
import matplotlib.pyplot as plt
import numpy as np
from frenchplotlib import tapisseries, dorures

# Données d'exemple
x = np.linspace(-1, 1, 20)
y = np.sin(x)

# Combinaison marqueur + palette de couleurs
plt.figure(figsize=(12, 6))
plt.scatter(x, y, c=y, marker=tapisseries.boule, s=1000, cmap=dorures.escargot_persil)
plt.colorbar(label='Valeurs')
plt.title("Visualisation à la française")
plt.show()
```

## 🥐 Marqueurs disponibles (tapisseries)

- `baguette` - Une baguette traditionnelle
- `pain_de_mie` - Pain de mie
- `croissant` - Croissant doré
- `pain_au_chocolat` - Pain au chocolat (ou chocolatine 😉)
- `boule` - Boule de pain
- `brioche` - Brioche dorée
- `bretzel` - Bretzel alsacien
- `fougasse` - Fougasse provençale
- `pita` - Pain pita
- `vin` - Verre de vin
- `fromage` - Morceau de fromage
- `eclair` - Éclair au chocolat
- `macaron` - Macaron parisien
- `camembert` - Camembert de Normandie
- `madeleine` - Madeleine de Proust
- `religieuse` - Religieuse au chocolat
- `escargot` - Escargot de Bourgogne

## 🎨 Palettes de couleurs (dorures)

### Palettes gourmandes

- `pain_dore` - Du blanc crème au brun doré
- `baguette_bien_cuite` - Dégradé de cuisson parfaite
- `croissant_beurre` - Or brillant et miel
- `fromage` - Palette des fromages français
- `macaron` - Couleurs pastel gourmandes

### Palettes régionales

- `tricolore` - Drapeau français (bleu, blanc, rouge)
- `lavande` - Lavande de Provence
- `cote_azur` - Mer et ciel méditerranéens
- `bourgogne` - Couleurs d'automne bourguignonnes
- `versailles` - Or et splendeur royale
- `nuit_parisienne` - Bleu nuit et lumières dorées

### Palettes viticoles

- `bordeaux` - Du rosé au rouge profond
- `champagne` - Pétillant et doré

### Palettes spéciales

- `escargot_persil` - Marron gris-vert
- `french_kiss` - Rouge passionnel
- `je_m_en_fous` - Gris perle élégant

## 📊 Exemples avancés

### Graphique multi-marqueurs

```python
import matplotlib.pyplot as plt
import numpy as np
from frenchplotlib import tapisseries, dorures

fig, ax = plt.subplots(figsize=(12, 8))

# Différents marqueurs
marqueurs = [tapisseries.croissant, tapisseries.vin, tapisseries.fromage, tapisseries.macaron]
couleurs = ['#FFD700', '#8B0000', '#F5DEB3', '#FFB6C1']
labels = ['Croissant', 'Vin', 'Fromage', 'Macaron']

for i, (marker, color, label) in enumerate(zip(marqueurs, couleurs, labels)):
    x = np.random.randn(10) + i*2
    y = np.random.randn(10) + i
    ax.scatter(x, y, marker=marker, s=800, c=color, label=label, alpha=0.7)

ax.legend(loc='best')
ax.set_title('Les délices de France', fontsize=16)
plt.show()
```

### Heatmap avec palette française

```python
import matplotlib.pyplot as plt
import numpy as np
from frenchplotlib import dorures

# Données aléatoires
data = np.random.rand(10, 10)

plt.figure(figsize=(10, 8))
plt.imshow(data, cmap=dorures.tricolore, aspect='auto')
plt.colorbar(label='Intensité')
plt.title('Heatmap tricolore')
plt.show()
```

## 🛠️ Développement

### Installation en mode développement

```bash
git clone https://github.com/PhilZPhaZ/frenchplotlib.git
cd frenchplotlib
pip install -e .
```

### Structure du projet

```
frenchplotlib/
├── frenchplotlib/
│   ├── __init__.py
│   ├── tapisseries.py       # Marqueurs personnalisés prédéfinis
│   ├── dorures.py            # Palettes de couleurs
│   ├── custom_marker.py      # Chargement de marqueurs SVG personnalisés
│   ├── converter.py          # Conversion de marqueurs
│   ├── tete.py               # Fonctionnalités de tête
│   └── assets/               # Fichiers SVG des marqueurs
│       ├── baguette.svg
│       ├── boule.svg
│       ├── croissant.svg
│       └── ...
├── test/                     # Exemples de tests
├── setup.py
├── pyproject.toml
└── README.md
```

## 📄 Licence

Ce projet est sous licence MIT.

## 🤝 Contribution

Les contributions sont les bienvenues ! N'hésitez pas à :

- Signaler des bugs
- Proposer de nouvelles fonctionnalités
- Ajouter de nouveaux marqueurs ou palettes
- Améliorer la documentation

## 🙏 Remerciements

Merci à matplotlib pour son excellente bibliothèque de visualisation qui rend tout cela possible.

---

*Créé avec ❤️ et 🥖 en France*
