from setuptools import setup, find_packages
from setuptools.command.install import install

class CustomInstall(install):
    def run(self):
        from installer import setup_env
        setup_env()
        super().run()

setup(
    name = "friday_neural_os",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        "python-dotenv"
    ],
    cmdclass={
        "install": CustomInstall,
    },
    entry_points={
        "console_scripts": [
            "friday-run=friday.cli:main",
            "jarvis-run=friday.cli:main",
        ]
    },
)
