# 🌐 PROJECT FRIDAY: Strategic Intelligence & Autonomous Control System

> **Classification:** TOP SECRET / LEVEL 5 ACCESS ONLY  
> **Status:** Operational  
> **Unit:** Advanced Agentic Systems (DeepMind-Class)

---

## 👁️ Overview
Project Friday is an autonomous, high-fidelity AI agentic platform designed for strategic intelligence, system automation, and cross-device synchronization. Born from the fusion of advanced LLMs and sovereign system-level control, Friday acts as a digital sentinel, providing the user with unprecedented control over their digital and physical environment.

## 🚀 Key Strategic Capabilities

### 🛡️ Defense & Intelligence
- **Intelligence Briefing Engine:** Synthesizes global real-time data into authoritative strategic reports.
- **SIGINT (Signal Intelligence):** Scans the wireless spectrum for vulnerabilities and secure communication paths.
- **Satellite Reconnaissance:** Direct link to orbital imaging for rapid geographical assessment.
- **Defense Protocol Alpha:** Instantaneous "Dark-Mode" system lockdown and data shielding.

### 🧩 Autonomous Workflows
- **GitHub Sovereign Control:** Creates repositories, manages commits, and pushes production code without human intervention.
- **Visual Intelligence:** Uses Gemini Vision to "see" the screen, analyze UI patterns, and troubleshoot errors.
- **Phone Unlocker V2:** Forensic-grade Android unlocking via wireless debugging and cryptographic hash analysis.

### 🧠 Cognitive Architecture
- **Mem0 Long-Term Memory:** Remembers personal events, meetings, and preferences across sessions.
- **Proactive Engagement:** Greets the user based on previous context (e.g., "How did your meeting go, Sir?").
- **Gmail & OTP Automation:** Intercepts authentication tokens from encrypted email streams for hands-free login.

## 🛠️ Technology Stack
- **Core Brain:** Google Gemini 1.5/2.0 Pro (via Realtime API)
- **Voice/Comms:** LiveKit Agents SDK
- **Memory Engine:** Mem0 (Neural memory graph)
- **System Layer:** Python 3.13, PowerShell 7, ADB (Android Debug Bridge)
- **Computer Vision:** PyAutoGUI + Gemini Vision
 

2. **Initialize Environment:**
   Fill in `.env` with the following:
   - `LIVEKIT_URL`, `LIVEKIT_API_KEY`, `LIVEKIT_API_SECRET`
   - `GOOGLE_API_KEY`
   - `MEM0_API_KEY`
   - `GITHUB_TOKEN`
   - `GMAIL_USER`, `GMAIL_APP_PASSWORD`

3. **Deploy:**
   ```powershell
   python agent.py dev
   ``` 