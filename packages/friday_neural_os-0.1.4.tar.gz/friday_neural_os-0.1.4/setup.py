from setuptools import setup, find_packages
from setuptools.command.install import install
import os
import sys

class CustomInstall(install):
    def run(self):
        # We try to run the setup but handle cases where it's not possible
        try:
            # Add the 'friday' directory to sys.path to import installer
            sys.path.append(os.path.join(os.getcwd(), "friday"))
            from installer import setup as friday_setup
            friday_setup()
        except Exception as e:
            print(f"Note: Could not run first-time setup during installation: {e}")
            print("You can run it later using: friday config setup")
        
        super().run()

setup(
    name="friday_neural_os",
    version="0.1.4",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "python-dotenv",
        "requests",
        "psutil",
        "pillow",
        "opencv-python",
        "livekit-agents",
        "livekit-plugins-silero",
        "livekit-plugins-google",
        "livekit-plugins-noise-cancellation",
        "mem0ai",
        "duckduckgo-search",
        "langchain_community",
        "google-genai",
        "pyautogui",
        "truecallerpy",
        "phonenumbers",
        "opencage",
        "folium",
        "pywebostv",
        "pywin32; platform_system=='Windows'",
        "win10toast; platform_system=='Windows'",
        "screen-brightness-control; platform_system=='Windows'",
    ],
    extras_require={
        "hacking": ["scapy", "impacket"],
    },
    cmdclass={
        "install": CustomInstall,
    },
    entry_points={
        "console_scripts": [
            "friday-run=friday.cli:main",
            "friday=friday.cli:main",
            "jarvis-run=friday.cli:main",
        ]
    },
)
