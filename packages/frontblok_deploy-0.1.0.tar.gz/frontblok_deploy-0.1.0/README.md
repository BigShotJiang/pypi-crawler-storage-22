# frontblok-deploy

Deployment engine for React SPA frontends. Extracts all reusable deployment infrastructure into one Python package.

**One package. One pattern. Every frontend.**

## What it owns

- **Dockerfile** — Multi-stage node:20-alpine → nginx:1.25-alpine build
- **nginx.conf** — Security-hardened config with parameterized CSP
- **k8s/deployment.yaml** — Full Kubernetes manifest with placeholder replacement
- **Deploy engine** — The 10-step chain: env → validate → generate files → git sha → docker build → push → namespace → secret → apply → rollout

## What each app provides

Each frontend repo's `deploy.py` is pure config — declaring what makes THIS app different:

```python
#!/usr/bin/env python3
from frontblok_deploy import FrontendDeployer

FrontendDeployer(
    vite_args=[
        "VITE_DATABASE_API_URL",
        "VITE_BUSINESS_LOGIC_API_URL",
        "VITE_GOOGLE_CLIENT_ID",
    ],
    required_vars=[
        "VITE_DATABASE_API_URL",
        "VITE_GOOGLE_CLIENT_ID",
    ],
    csp_sources={
        "script_src": "https://js.stripe.com https://accounts.google.com https://apis.google.com https://cdn.jsdelivr.net",
        "style_src": "https://fonts.googleapis.com https://accounts.google.com https://cdn.jsdelivr.net",
        "font_src": "https://fonts.gstatic.com https://fonts.googleapis.com",
        "frame_src": "https://js.stripe.com https://hooks.stripe.com https://accounts.google.com",
    },
).deploy()
```

That's it. No Dockerfile, no nginx.conf, no K8s manifest needed in the repo. The package generates them at deploy time.

## Install

```bash
pip install frontblok-deploy
# or for development
pip install -e /path/to/frontblok-deploy
```
