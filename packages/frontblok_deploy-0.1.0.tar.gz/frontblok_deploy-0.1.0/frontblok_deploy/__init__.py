"""
frontblok-deploy — Deployment engine for React SPA frontends.
Docker + GHCR + Kubernetes. Zero dependencies.
"""

from frontblok_deploy.deployer import FrontendDeployer

__version__ = "0.1.0"
__all__ = ["FrontendDeployer"]
