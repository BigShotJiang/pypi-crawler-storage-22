"""
FrontendDeployer — The deployment chain.

One class. One method. One try/except.
Each step must succeed before the next starts.
If any step fails, the entire chain fails.
"""

import os
import sys
import subprocess
from pathlib import Path
from datetime import datetime

from frontblok_deploy.env_loader import load_env
from frontblok_deploy.files import generate_dockerfile, generate_nginx_conf, generate_k8s_manifest


class FrontendDeployer:
    """Deploy a React SPA to Kubernetes via Docker + GHCR.

    Args:
        vite_args: List of VITE_ env var names to pass as Docker build-args.
        required_vars: Env var names that MUST be non-empty (in addition to
            GITHUB_TOKEN, DEPLOY_GITHUB_OWNER, DEPLOY_DOMAIN which are always required).
        csp_sources: CSP source overrides for nginx.conf. Keys:
            script_src, style_src, font_src, connect_src, frame_src, img_src.
        project_dir: Path to the project root. Defaults to cwd.
        default_service_name: Fallback if DEPLOY_SERVICE_NAME not in env.

    Usage:
        FrontendDeployer(
            vite_args=["VITE_DATABASE_API_URL", "VITE_GOOGLE_CLIENT_ID"],
            required_vars=["VITE_DATABASE_API_URL", "VITE_GOOGLE_CLIENT_ID"],
            csp_sources={"script_src": "https://js.stripe.com", "frame_src": "https://js.stripe.com"},
        ).deploy()
    """

    CORE_REQUIRED = ["GITHUB_TOKEN", "DEPLOY_GITHUB_OWNER", "DEPLOY_DOMAIN"]

    def __init__(
        self,
        vite_args: list[str],
        required_vars: list[str] | None = None,
        csp_sources: dict[str, str] | None = None,
        project_dir: str | Path | None = None,
        default_service_name: str = "frontend",
    ):
        self.vite_arg_names = vite_args
        self.csp_sources = csp_sources
        self.project_dir = Path(project_dir) if project_dir else Path.cwd()
        self.default_service_name = default_service_name
        self.required_vars = list(dict.fromkeys(self.CORE_REQUIRED + (required_vars or [])))

    def deploy(self) -> None:
        """Execute the full deployment chain. If any step fails, everything fails."""

        # ── STEP 0: Load environment ──────────────────────────────────
        if not load_env(self.project_dir):
            print("FATAL: No .env file found")
            print("Create .env in project root or set DEPLOY_VPS_ENV_PATH")
            sys.exit(1)

        # ── Read config ───────────────────────────────────────────────
        service_name = os.getenv("DEPLOY_SERVICE_NAME", self.default_service_name)
        namespace = os.getenv("DEPLOY_NAMESPACE", service_name)
        domain = os.getenv("DEPLOY_DOMAIN", "")
        github_owner = os.getenv("DEPLOY_GITHUB_OWNER", "")
        registry = os.getenv("DEPLOY_REGISTRY", f"ghcr.io/{github_owner}")
        image_name = f"{registry}/{service_name}"
        github_token = os.getenv("GITHUB_TOKEN", "")

        # Read VITE_ vars
        vite_vars = {name: os.getenv(name, "") for name in self.vite_arg_names}

        # ── Validate ──────────────────────────────────────────────────
        all_vals = {
            "GITHUB_TOKEN": github_token,
            "DEPLOY_GITHUB_OWNER": github_owner,
            "DEPLOY_DOMAIN": domain,
            **vite_vars,
        }
        missing = [k for k in self.required_vars if not all_vals.get(k, "")]
        if missing:
            print(f"FATAL: Required variables not set: {', '.join(missing)}")
            print("Check your .env file or DEPLOY_VPS_ENV_PATH")
            sys.exit(1)

        # ── THE CHAIN ─────────────────────────────────────────────────
        print("=" * 80)
        print(f"{service_name.upper()} DEPLOYMENT - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print("=" * 80)

        try:
            # STEP 1: Generate infrastructure files
            print(f"\n▶ Generating infrastructure files")
            self.project_dir.joinpath("Dockerfile").write_text(
                generate_dockerfile(self.vite_arg_names)
            )
            self.project_dir.joinpath("nginx.conf").write_text(
                generate_nginx_conf(self.csp_sources)
            )
            k8s_dir = self.project_dir / "k8s"
            k8s_dir.mkdir(exist_ok=True)
            k8s_dir.joinpath("deployment.yaml").write_text(generate_k8s_manifest())
            print("✓ Dockerfile, nginx.conf, k8s/deployment.yaml written")

            # STEP 2: Get Git SHA for image tag
            result = subprocess.run(
                "git rev-parse --short HEAD",
                shell=True, capture_output=True, text=True, check=True,
                cwd=str(self.project_dir),
            )
            git_sha = result.stdout.strip()
            image_tag = f"{image_name}:{git_sha}"
            image_latest = f"{image_name}:latest"

            print(f"\nConfiguration:")
            print(f"  Service: {service_name}")
            print(f"  Image: {image_tag}")
            print(f"  Namespace: {namespace}")
            print(f"  Domain: {domain}")
            for name, value in vite_vars.items():
                label = name.replace("VITE_", "").replace("_", " ").title()
                print(f"  {label}: {value or '[NOT SET]'}")

            # STEP 3: Build Docker image (--no-cache, visible output)
            print(f"\n▶ Building Docker image (no-cache)")
            build_arg_parts = [
                f"--build-arg {k}='{v}'" for k, v in vite_vars.items() if v
            ]
            build_cmd = (
                f"docker build --no-cache --platform linux/amd64 "
                f"{' '.join(build_arg_parts)} "
                f"-t {image_tag} -t {image_latest} ."
            )
            masked = " ".join(f"--build-arg {k}=***" for k in vite_vars if vite_vars[k])
            print(f"  docker build --no-cache --platform linux/amd64 {masked}")
            subprocess.run(build_cmd, shell=True, check=True, cwd=str(self.project_dir))
            print("✓ Image built")

            # STEP 4: Login to GHCR
            print(f"\n▶ Logging in to GHCR")
            subprocess.run(
                f"echo {github_token} | docker login ghcr.io -u {github_owner} --password-stdin",
                shell=True, check=True, capture_output=True,
            )
            print("✓ Logged in")

            # STEP 5: Push images
            print(f"\n▶ Pushing images to GHCR")
            subprocess.run(f"docker push {image_tag}", shell=True, check=True, capture_output=True)
            subprocess.run(f"docker push {image_latest}", shell=True, check=True, capture_output=True)
            print("✓ Images pushed")

            # STEP 6: Create namespace (idempotent)
            print(f"\n▶ Creating namespace")
            subprocess.run(
                f"kubectl create namespace {namespace} --dry-run=client -o yaml | kubectl apply -f -",
                shell=True, check=True, capture_output=True,
            )
            print("✓ Namespace ready")

            # STEP 7: Create GHCR pull secret (idempotent)
            print(f"\n▶ Creating GHCR pull secret")
            subprocess.run(
                f"kubectl create secret docker-registry ghcr-login-secret "
                f"-n {namespace} "
                f"--docker-server=ghcr.io "
                f"--docker-username={github_owner} "
                f"--docker-password={github_token} "
                f"--dry-run=client -o yaml | kubectl apply -f -",
                shell=True, check=True, capture_output=True,
            )
            print("✓ Secret ready")

            # STEP 8: Apply K8s manifest (replace placeholders, apply)
            print(f"\n▶ Applying Kubernetes manifest")
            manifest = (self.project_dir / "k8s" / "deployment.yaml").read_text()
            manifest = manifest.replace("DEPLOY_SERVICE_NAME", service_name)
            manifest = manifest.replace("DEPLOY_NAMESPACE", namespace)
            manifest = manifest.replace("CONTAINER_IMAGE", image_tag)
            manifest = manifest.replace("DEPLOY_DOMAIN", domain)
            subprocess.run(
                "kubectl apply -f -",
                shell=True, input=manifest, text=True, check=True, capture_output=True,
            )
            print("✓ Manifest applied")

            # STEP 9: Wait for rollout
            print(f"\n▶ Waiting for deployment rollout")
            subprocess.run(
                f"kubectl rollout status deployment/{service_name}-app -n {namespace} --timeout=5m",
                shell=True, check=True, capture_output=True,
            )
            print("✓ Rollout complete")

            # ── SUCCESS ───────────────────────────────────────────────
            print("\n" + "=" * 80)
            print("✅ DEPLOYMENT COMPLETE")
            print("=" * 80)
            print(f"\nDeployed successfully!")
            print(f"  URL: https://{domain}")
            print(f"  Image: {image_tag}")
            print(f"  Namespace: {namespace}")
            print(f"\nCert-manager will provision SSL automatically.")
            print(f"Check: kubectl get certificate -n {namespace}")

        except subprocess.CalledProcessError as e:
            print(f"\n❌ DEPLOYMENT FAILED")
            print(f"Command failed: {e.cmd}")
            if e.stderr:
                print(f"Error: {e.stderr}")
            sys.exit(1)
        except FileNotFoundError as e:
            print(f"\n❌ DEPLOYMENT FAILED: {e}")
            sys.exit(1)
