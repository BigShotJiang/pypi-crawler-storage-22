"""
Environment loading with 3-tier priority.

Priority order (later overrides earlier):
    1. Local .env in project root
    2. VPS override from DEPLOY_VPS_ENV_PATH (FATAL if set but file missing)
    3. Default VPS path /etc/<service>/.env
"""

import os
import sys
from pathlib import Path


def load_env_file(path: str | Path) -> None:
    """Parse a .env file and load key=value pairs into os.environ."""
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip().replace("\r", "")
            if line and not line.startswith("#") and "=" in line:
                key, value = line.split("=", 1)
                value = value.strip()
                # Strip surrounding quotes (single or double)
                if len(value) >= 2 and value[0] == value[-1] and value[0] in ('"', "'"):
                    value = value[1:-1]
                os.environ[key.strip()] = value


def load_env(project_dir: str | Path | None = None) -> bool:
    """Load environment variables with 3-tier priority. Returns True if any env loaded.

    Args:
        project_dir: Directory containing the local .env file. Defaults to cwd.
    """
    if project_dir is None:
        project_dir = Path.cwd()
    else:
        project_dir = Path(project_dir)

    local_env = project_dir / ".env"

    # Layer 1: Local .env
    if local_env.exists():
        load_env_file(local_env)
        print(f"[env] Loaded local: {local_env}")

    # Layer 2: VPS override — explicit path, FATAL if set but missing
    vps_env_path = os.getenv("DEPLOY_VPS_ENV_PATH", "")
    if vps_env_path:
        vps_env = Path(vps_env_path)
        if vps_env.exists():
            load_env_file(vps_env)
            print(f"[env] Loaded VPS override: {vps_env}")
            return True
        else:
            print(f"FATAL: DEPLOY_VPS_ENV_PATH={vps_env_path} does not exist")
            sys.exit(1)

    # Layer 3: Default VPS path based on service name
    service_name = os.getenv("DEPLOY_SERVICE_NAME", "frontend")
    default_vps_env = Path(f"/etc/{service_name}/.env")
    if default_vps_env.exists():
        load_env_file(default_vps_env)
        print(f"[env] Loaded VPS default: {default_vps_env}")
        return True

    return local_env.exists()
