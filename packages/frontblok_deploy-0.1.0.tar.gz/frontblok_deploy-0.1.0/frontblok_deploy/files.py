"""
Infrastructure file generators.

Pure Python f-strings — no Jinja2, no dependencies.
Each function returns the file content as a string.
"""


# ============================================================================
# DOCKERFILE
# ============================================================================

def generate_dockerfile(vite_args: list[str]) -> str:
    """Generate a multi-stage Dockerfile for a Vite React SPA.

    Args:
        vite_args: List of VITE_ env var names (e.g. ["VITE_DATABASE_API_URL"]).
    """
    # Group all ARGs first, then all ENVs (canonical Docker pattern)
    arg_declarations = [f"ARG {arg}" for arg in vite_args]
    env_declarations = [f"ENV {arg}=${{{arg}}}" for arg in vite_args]
    arg_block = "\n".join(arg_declarations) + "\n" + "\n".join(env_declarations)

    return f"""# ============================================================================
# FRONTEND DOCKER BUILD (managed by frontblok-deploy)
# ============================================================================
# Multi-stage build: React SPA with Vite, served by nginx
# Stateless frontend consuming backend APIs
# ============================================================================


# ============================================================================
# BUILD STAGE
# ============================================================================
FROM node:20-alpine AS build

WORKDIR /app

# Install dependencies
COPY package*.json ./
RUN npm ci

# Copy source and build with VITE_* env vars
COPY . .

{arg_block}

RUN npm run build


# ============================================================================
# PRODUCTION STAGE
# ============================================================================
FROM nginx:1.25-alpine

LABEL description="React Frontend SPA"
LABEL version="1.0.0"

# Install curl for health checks
RUN apk add --no-cache curl

# Create nginx user (consistency across environments)
RUN addgroup -g 101 -S nginx || true && \\
    adduser -S -D -H -u 101 -h /var/cache/nginx -s /sbin/nologin -G nginx -g nginx nginx 2>/dev/null || true

# Copy built files from build stage
COPY --from=build /app/dist /usr/share/nginx/html

# Copy nginx config
COPY nginx.conf /etc/nginx/nginx.conf

# Create directories with proper permissions
RUN mkdir -p /var/cache/nginx /var/run /var/log/nginx && \\
    chown -R nginx:nginx /var/cache/nginx /var/run /var/log/nginx /usr/share/nginx/html && \\
    chmod -R 755 /var/cache/nginx /var/run /var/log/nginx && \\
    chmod -R 644 /usr/share/nginx/html/* && \\
    find /usr/share/nginx/html -type d -exec chmod 755 {{}} \\;

# Remove default nginx config
RUN rm -f /etc/nginx/conf.d/default.conf

# Non-root user
USER nginx

EXPOSE 80

HEALTHCHECK --interval=30s --timeout=3s --start-period=5s --retries=3 \\
    CMD curl -f http://localhost/health || exit 1

CMD ["nginx", "-g", "daemon off;"]
"""


# ============================================================================
# NGINX.CONF
# ============================================================================

def _build_csp(csp_sources: dict[str, str] | None = None) -> str:
    """Build a Content-Security-Policy string from source components.

    Args:
        csp_sources: Dict with optional keys: script_src, style_src, font_src,
            connect_src, frame_src, img_src. Values are space-separated origins.
    """
    s = csp_sources or {}

    # " ".join(x.split()) normalizes whitespace — collapses doubles when optional sources are empty
    script = " ".join(f"'self' 'unsafe-inline' 'unsafe-eval' blob: {s.get('script_src', '')}".split())
    style = " ".join(f"'self' 'unsafe-inline' {s.get('style_src', '')}".split())
    img = " ".join(f"'self' data: {s.get('img_src', '')} https:".split())
    font = " ".join(f"'self' data: {s.get('font_src', '')}".split())
    connect = " ".join(f"'self' {s.get('connect_src', 'https:')}".split())
    frame = s.get("frame_src", "'none'")

    return (
        f"default-src 'self'; "
        f"script-src {script}; "
        f"style-src {style}; "
        f"img-src {img}; "
        f"font-src {font}; "
        f"connect-src {connect}; "
        f"frame-src {frame}; "
        f"object-src 'none'; "
        f"base-uri 'self'; "
        f"worker-src 'self' blob:;"
    )


def generate_nginx_conf(csp_sources: dict[str, str] | None = None) -> str:
    """Generate a security-hardened nginx.conf for a React SPA.

    Args:
        csp_sources: CSP source overrides. See _build_csp() for keys.
    """
    csp = _build_csp(csp_sources)

    return f"""# ============================================================================
# NGINX CONFIGURATION - SECURITY HARDENED (managed by frontblok-deploy)
# ============================================================================
# Serves React SPA with security headers and optimizations
# ============================================================================

user nginx;
worker_processes auto;
pid /var/run/nginx.pid;
error_log /var/log/nginx/error.log warn;

events {{
    worker_connections 1024;
    use epoll;
}}

http {{
    include /etc/nginx/mime.types;
    default_type application/octet-stream;
    
    # Logging
    log_format main '$remote_addr - $remote_user [$time_local] "$request" '
                    '$status $body_bytes_sent "$http_referer" '
                    '"$http_user_agent" "$http_x_forwarded_for"';
    
    access_log /var/log/nginx/access.log main;
    
    # Performance optimizations
    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;
    keepalive_timeout 65;
    types_hash_max_size 2048;
    client_max_body_size 10M;
    
    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_types text/plain text/css text/xml text/javascript 
               application/json application/javascript application/xml+rss 
               application/rss+xml font/truetype font/opentype 
               application/vnd.ms-fontobject image/svg+xml;
    
    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;
    add_header Content-Security-Policy "{csp}" always;
    add_header Permissions-Policy "geolocation=(), microphone=(), camera=()" always;
    
    # Hide nginx version
    server_tokens off;
    
    # Rate limiting zones
    limit_req_zone $binary_remote_addr zone=general:10m rate=10r/s;
    limit_req_zone $binary_remote_addr zone=api:10m rate=30r/s;
    
    server {{
        listen 80;
        server_name _;
        
        root /usr/share/nginx/html;
        index index.html;
        
        # Rate limiting
        limit_req zone=general burst=20 nodelay;
        
        # Main location - SPA routing
        location / {{
            try_files $uri $uri/ /index.html;
            
            # Security headers
            add_header X-Frame-Options "SAMEORIGIN" always;
            add_header X-Content-Type-Options "nosniff" always;
            add_header X-XSS-Protection "1; mode=block" always;
            add_header Referrer-Policy "strict-origin-when-cross-origin" always;
            add_header Content-Security-Policy "{csp}" always;
            add_header Permissions-Policy "geolocation=(), microphone=(), camera=()" always;
            add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
            
            # Cache control for HTML (no caching)
            location = /index.html {{
                add_header Cache-Control "no-cache, no-store, must-revalidate";
                add_header Pragma "no-cache";
                add_header Expires "0";
                # Security headers for index.html
                add_header X-Frame-Options "SAMEORIGIN" always;
                add_header X-Content-Type-Options "nosniff" always;
                add_header X-XSS-Protection "1; mode=block" always;
                add_header Referrer-Policy "strict-origin-when-cross-origin" always;
                add_header Content-Security-Policy "{csp}" always;
                add_header Permissions-Policy "geolocation=(), microphone=(), camera=()" always;
                add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
            }}
        }}
        
        # Cache static assets (Vite generates hashed filenames)
        location ~* \\.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {{
            expires 1y;
            add_header Cache-Control "public, immutable";
            # Security headers for static assets
            add_header X-Frame-Options "SAMEORIGIN" always;
            add_header X-Content-Type-Options "nosniff" always;
            add_header X-XSS-Protection "1; mode=block" always;
            add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
        }}
        
        # Health check endpoint
        location /health {{
            access_log off;
            return 200 "healthy\\n";
            add_header Content-Type text/plain;
            add_header X-Content-Type-Options "nosniff" always;
        }}
        
        # Deny access to hidden files
        location ~ /\\. {{
            deny all;
        }}
        
        # Deny access to sensitive files
        location ~ \\.(env|git|md)$ {{
            deny all;
        }}
        
        # Block source map files in production
        location ~ \\.map$ {{
            deny all;
            return 404;
        }}
    }}
}}
"""


# ============================================================================
# K8S DEPLOYMENT MANIFEST
# ============================================================================

def generate_k8s_manifest() -> str:
    """Generate the Kubernetes deployment manifest.

    Uses DEPLOY_* placeholders that the deployer replaces at apply time.
    This is 100% static — no parameters needed.
    """
    return """# ============================================================================
# FRONTEND KUBERNETES DEPLOYMENT (managed by frontblok-deploy)
# ============================================================================
# Placeholders (replaced by FrontendDeployer at deployment time):
#   DEPLOY_SERVICE_NAME  - Service name
#   DEPLOY_NAMESPACE     - K8s namespace
#   DEPLOY_DOMAIN        - Primary domain (app.example.com)
#   CONTAINER_IMAGE      - Full image path with tag
# ============================================================================


# ============================================================================
# NAMESPACE
# ============================================================================
apiVersion: v1
kind: Namespace
metadata:
  name: DEPLOY_NAMESPACE
  labels:
    name: DEPLOY_NAMESPACE
---


# ============================================================================
# SERVICE ACCOUNT
# ============================================================================
apiVersion: v1
kind: ServiceAccount
metadata:
  name: DEPLOY_SERVICE_NAME-sa
  namespace: DEPLOY_NAMESPACE
automountServiceAccountToken: false
---


# ============================================================================
# DEPLOYMENT
# ============================================================================
apiVersion: apps/v1
kind: Deployment
metadata:
  name: DEPLOY_SERVICE_NAME-app
  namespace: DEPLOY_NAMESPACE
spec:
  replicas: 2
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxUnavailable: 1
      maxSurge: 1
  selector:
    matchLabels:
      app: DEPLOY_SERVICE_NAME-app
  template:
    metadata:
      labels:
        app: DEPLOY_SERVICE_NAME-app
    spec:
      serviceAccountName: DEPLOY_SERVICE_NAME-sa
      securityContext:
        runAsNonRoot: true
        runAsUser: 101
        fsGroup: 101
      imagePullSecrets:
      - name: ghcr-login-secret
      containers:
      - name: nginx-server
        image: CONTAINER_IMAGE
        imagePullPolicy: Always
        securityContext:
          allowPrivilegeEscalation: false
          readOnlyRootFilesystem: true
          runAsNonRoot: true
          runAsUser: 101
          capabilities:
            drop: [ALL]
            add: [NET_BIND_SERVICE]
        ports:
        - containerPort: 80
          name: http
        livenessProbe:
          httpGet:
            path: /health
            port: http
          initialDelaySeconds: 10
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /health
            port: http
          initialDelaySeconds: 5
          periodSeconds: 5
        resources:
          requests:
            memory: "256Mi"
            cpu: "200m"
          limits:
            memory: "512Mi"
            cpu: "500m"
        volumeMounts:
        - name: cache
          mountPath: /var/cache/nginx
        - name: run
          mountPath: /var/run
        - name: tmp
          mountPath: /tmp
        - name: log
          mountPath: /var/log/nginx
      volumes:
      - name: cache
        emptyDir: {}
      - name: run
        emptyDir: {}
      - name: tmp
        emptyDir: {}
      - name: log
        emptyDir: {}
---


# ============================================================================
# SERVICE
# ============================================================================
apiVersion: v1
kind: Service
metadata:
  name: DEPLOY_SERVICE_NAME-service
  namespace: DEPLOY_NAMESPACE
spec:
  type: ClusterIP
  ports:
  - port: 80
    targetPort: http
  selector:
    app: DEPLOY_SERVICE_NAME-app
---


# ============================================================================
# INGRESS
# ============================================================================
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: DEPLOY_SERVICE_NAME-ingress
  namespace: DEPLOY_NAMESPACE
  annotations:
    cert-manager.io/cluster-issuer: "letsencrypt-prod"
    traefik.ingress.kubernetes.io/redirect-entry-point: "https"
spec:
  tls:
  - hosts:
    - DEPLOY_DOMAIN
    secretName: DEPLOY_SERVICE_NAME-tls
  rules:
  - host: DEPLOY_DOMAIN
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: DEPLOY_SERVICE_NAME-service
            port:
              number: 80
"""
