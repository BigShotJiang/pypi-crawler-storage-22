# frozendict-secure-x ❄️

An immutable, hashable dictionary for Python.

Python has `tuple` and `frozenset`, but no built-in immutable dictionary.
This package provides a **safe, simple, and hashable `frozendict`**.

---

## ✨ Features
- ✅ Immutable (cannot be modified)
- ✅ Hashable (usable as dict keys & set items)
- ✅ Lightweight & fast
- ✅ Pythonic API
- ✅ Clear license & author attribution

---

## 📦 Installation

```bash
pip install frozendict-secure-x