from .core import frozendict

__all__ = ["frozendict"]