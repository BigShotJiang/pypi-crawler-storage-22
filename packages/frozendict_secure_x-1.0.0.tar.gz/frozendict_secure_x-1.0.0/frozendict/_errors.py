"""
Custom errors for frozendict_secure
Author: sastha prasanth ramakrishnan
License: MIT
"""

class ImmutableError(TypeError):
    pass