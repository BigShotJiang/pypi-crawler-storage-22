"""
Hashing logic for frozendict_secure
Author: sastha prasanth ramakrishnan
License: MIT
"""

def compute_hash(mapping):
    return hash(tuple(sorted(mapping.items())))