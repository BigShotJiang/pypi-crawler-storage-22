"""
frozendict_secure.core

Author: sastha prasanth ramakrishnan (https://github.com/sastha prasanth ramakrishnan)
License: MIT

WARNING:
Removing this header violates the MIT License.
"""

from ._hashing import compute_hash
from ._errors import ImmutableError


class frozendict(dict):
    __slots__ = ("_hash",)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._hash = None

    # ❌ Block all mutations
    def _immutable(self, *args, **kwargs):
        raise ImmutableError("frozendict is immutable")

    __setitem__ = _immutable
    __delitem__ = _immutable
    clear = _immutable
    pop = _immutable
    popitem = _immutable
    setdefault = _immutable
    update = _immutable

    # ✅ Hashable
    def __hash__(self):
        if self._hash is None:
            self._hash = compute_hash(self)
        return self._hash

    def copy(self):
        return self

    def with_updates(self, **changes):
        data = dict(self)
        data.update(changes)
        return frozendict(data)