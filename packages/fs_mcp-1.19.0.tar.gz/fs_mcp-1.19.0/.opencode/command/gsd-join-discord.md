---
description: Join the GSD Discord community
---

<objective>
Display the Discord invite link for the GSD community server.
</objective>

<output>
# Join the GSD Discord

Connect with other GSD users, get help, share what you're building, and stay updated.

**Invite link:** https://discord.gg/5JJgD5svVS

Click the link or paste it into your browser to join.
</output>
