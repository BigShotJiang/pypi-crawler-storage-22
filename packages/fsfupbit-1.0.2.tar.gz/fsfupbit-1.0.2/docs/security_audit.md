# fsfupbit 보안 검사 보고서

> fsfupbit 프로젝트 보안 취약점 분석 및 수정

**Date**: 2026-01-29
**Version**: 1.0.0

---

## 개요

fsfupbit 프로젝트의 모든 파일을 검사하여 보안 문제(하드코딩된 키, 비밀번호, 토큰 등)를 확인하고 수정했습니다.

---

## ✅ 검사 결과: 안전함

### 1. 소스 코드 파일

검사한 모든 Python 소스 파일에 하드코딩된 자격 증명이 없습니다:

| 파일 | 상태 | 비고 |
|------|------|------|
| `fsfupbit/__init__.py` | ✅ 안전 | |
| `fsfupbit/errors.py` | ✅ 안전 | 예외 클래스만 정의 |
| `fsfupbit/exchange_api.py` | ✅ 안전 | 사용자 입력만 사용 |
| `fsfupbit/quotation_api.py` | ✅ 안전 | API 호출만 |
| `fsfupbit/request_api.py` | ✅ 안전 | HTTP 요청 래퍼 |
| `fsfupbit/websocket_api.py` | ✅ 안전 | Docstring에 예시만 포함 |

### 2. 테스트 파일

테스트 파일은 목 데이터(mock data)만 사용합니다:

```python
# 테스트 코드 예시 (안전함)
access = "test_access_key"   # 테스트용 가짜 키
secret = "test_secret_key"   # 테스트용 가짜 키
```

---

## 🔧 수정 사항

### 예제 파일 보안 강화

**문제**: 예제 파일들이 `../upbit.txt` 파일에서 API 키를 읽고 있었음

**수정 전:**
```python
# 보안 취약점: 외부 파일에서 키 읽기
f = open("../upbit.txt", "r")
lines = f.readlines()
f.close()
access = lines[0].strip()
secret = lines[1].strip()
```

**수정 후:**
```python
# 보안 안전: 환경 변수 사용
import os

access = os.getenv("UPBIT_ACCESS_KEY")
secret = os.getenv("UPBIT_SECRET_KEY")

if not access or not secret:
    print("환경 변수를 설정해주세요.")
    exit(1)
```

### 수정된 파일

- `example/10_buy_limit.py` - 환경 변수 사용으로 변경
- `example/12_cancel.py` - 환경 변수 사용으로 변경

---

## 🛡️ .gitignore 업데이트

### 추가된 제외 항목

```gitignore
.env
.env.local
.env.*.local
```

이제 `.env` 파일 및 모든 환경 변수 파일이 git에서 제외됩니다.

---

## 📋 보안 체크리스트

### ✅ 구현된 보안 조치

- [x] 하드코딩된 API 키 없음
- [x] 하드코딩된 비밀번호 없음
- [x] 하드코딩된 토큰 없음
- [x] 예제 파일에서 환경 변수 사용
- [x] `.env` 파일을 `.gitignore`에 추가
- [x] `.env.example` 파일 제공 (템플릿)
- [x] README에 보안 섹션 추가

### ⚠️ 사용자 주의 사항

1. **`.env` 파일 관리**
   - `.env` 파일은 절대 git에 커밋하지 마세요
   - `.gitignore`에 이미 포함되어 있습니다

2. **API 키 보관**
   - Upbit 개발자 사이트에서만 키를 발급 받으세요
   - 주기적으로 키를 변경하세요 (rotation)

3. **예제 코드 실행 시**
   ```bash
   # .env 파일 생성
   cp .env.example .env

   # .env 파일에 실제 키 입력
   vi .env

   # 예제 실행
   python example/10_buy_limit.py
   ```

---

## 🔍 추가 검사 사항

### 1. JWT 토큰 처리

JWT 토큰은 런타임에 사용자 키로 생성되며 저장되지 않습니다:

```python
# exchange_api.py
jwt_token = jwt.encode(payload, self.secret, algorithm="HS256")
# 토큰은 메모리에만 존재하고 종료 시 소멸
```

### 2. WebSocket 인증

WebSocket 연결도 매번 JWT 토큰을 새로 생성합니다:

```python
# websocket_api.py
def _generate_jwt_token(self) -> str:
    payload = {
        "access_key": self.access_key,
        "nonce": str(uuid.uuid4())  # 매번 새로운 nonce
    }
    jwt_token = jwt.encode(payload, self.secret, algorithm="HS256")
    return f'Bearer {jwt_token}'
```

### 3. HTTP 요청

모든 HTTP 요청은 `requests` 라이브러리를 통해 안전하게 처리됩니다.

---

## 📞 보안 문제 신고

보안 문제를 발견하시면:

- **GitHub Issues**: https://github.com/urstory/fsfupbit/issues

---

## ✅ 결론

fsfupbit 프로젝트는 보안 모범 사례를 따릅니다:

1. **소스 코드에 자격 증명 없음** ✅
2. **환경 변수 사용 권장** ✅
3. **.gitignore로 민감한 파일 보호** ✅
4. **JWT 토큰 안전하게 처리** ✅
5. **보안 문서화 완료** ✅

**fsfupbit는 안전하게 사용할 수 있습니다.**

---

**© 2026 풀스택패밀리 연구소**
