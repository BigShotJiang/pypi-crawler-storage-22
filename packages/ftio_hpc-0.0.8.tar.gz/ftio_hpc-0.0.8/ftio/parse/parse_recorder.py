"""
Author: Ahmad Tarraf
Copyright (c) 2026 TU Darmstadt, Germany
Version: v0.0.8
Date: Feb 2024

Licensed under the BSD 3-Clause License.
For more information, see the LICENSE file in the project root:
https://github.com/tuda-parallel/FTIO/blob/main/LICENSE
"""

from ftio.parse.recorder_reader import extract
from ftio.parse.simrun import Simrun


class ParseRecorder:

    def __init__(self, path):
        self.path = path
        if self.path[-1] == "/":
            self.path = self.path[:-1]

    def to_simrun(self, args):
        """Convert to Simrun class
        Args:
            ts (double): [optional] desired start time
        Returns:
            Simrun: Simrun object
        """
        data, ranks = extract(self.path, args)

        return Simrun(data, "recorder", str(ranks), args)
