"""
Author: Ahmad Tarraf
Copyright (c) 2026 TU Darmstadt, Germany
Version: v0.0.8
Date: Sep 2024

Licensed under the BSD 3-Clause License.
For more information, see the LICENSE file in the project root:
https://github.com/tuda-parallel/FTIO/blob/main/LICENSE
"""

from __future__ import annotations

from argparse import Namespace

from ftio.freq._analysis_figures import AnalysisFigures
from ftio.freq.prediction import Prediction


def convert_and_plot(
    args: Namespace,
    list_predictions: list[Prediction],
    list_analysis_figures: list[AnalysisFigures],
) -> None:
    """Convert data from ftio and plot the results.

    Args:
        args (Namespace): Command line arguments.
       list_analysis_figures (list[AnalysisFigures]): List of AnalysisFigures containing the data to plot.
    """

    for analysis_figures in list_analysis_figures:
        analysis_figures.show()
