"""Test helper utilities for FTL test suite.

Provides reusable type-safe assertion helpers for AST testing.
"""

from __future__ import annotations

__all__ = []
