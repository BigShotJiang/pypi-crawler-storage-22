---
afad: "3.1"
version: "0.109.0"
domain: "architecture"
updated: "2026-02-16"
route: "/docs/data-integrity"
---

# Data Integrity Architecture

This document describes the architectural design for data integrity in FTLLexEngine.

## Design Principle: Fail-Fast Data Safety

For financial applications, silent data corruption is catastrophic. The system is designed to **fail loudly and immediately** rather than propagate incorrect data.

| Failure Mode | Non-Financial App | Financial App |
|:-------------|:------------------|:--------------|
| Missing translation | Show fallback | Unacceptable |
| Cache corruption | Return stale data | Unacceptable |
| Error mutation | Log and continue | Unacceptable |

**Rationale:** A bank displaying "$1,000" when the actual value is "$10,000" due to a silent fallback is worse than displaying an error. Financial applications must know immediately when something is wrong.

## Architecture Overview

```
+------------------------------------------------------------------+
|                   FluentBundle / FluentLocalization                |
|  +------------------------------------------------------------+  |
|  |                     Strict Mode Layer                       |  |
|  |  Responsibility: Fail-fast on ANY formatting error         |  |
|  |  Raises: FormattingIntegrityError                          |  |
|  |  Scope: Both FluentBundle AND FluentLocalization            |  |
|  +------------------------------------------------------------+  |
|                               |                                   |
|  +------------------------------------------------------------+  |
|  |                     Error Layer                             |  |
|  |  Responsibility: Immutable, verifiable error objects       |  |
|  |  Type: FrozenFluentError (sealed, content-addressed)       |  |
|  +------------------------------------------------------------+  |
|                               |                                   |
|  +------------------------------------------------------------+  |
|  |                     Cache Layer                             |  |
|  |  Responsibility: Checksum-verified format result caching   |  |
|  |  Type: IntegrityCache (BLAKE2b-128, write-once option)     |  |
|  |  Integrity: Independent of strict mode (always-on default) |  |
|  +------------------------------------------------------------+  |
|                               |                                   |
|  +------------------------------------------------------------+  |
|  |                  Integrity Exception Layer                  |  |
|  |  Responsibility: System failure signaling (not Fluent)     |  |
|  |  Types: DataIntegrityError hierarchy                       |  |
|  +------------------------------------------------------------+  |
+------------------------------------------------------------------+
```

## Component Responsibilities

### Strict Mode Layer

**Responsibility:** Provide fail-fast behavior at both bundle and localization levels.

**Design Decision:** Strict mode is opt-in (`strict=False` default), not the only mode.

**Why not fail-fast by default?**

The Fluent specification itself defines fallback behavior. When formatting fails, you get a result (with placeholder like `{$amount}`) AND errors returned as data. This is intentional:

| Consideration | Rationale |
|:--------------|:----------|
| Fluent philosophy | "Errors as data" - caller decides severity, not the library |
| Development workflow | Seeing `{$missing}` in UI identifies issues without crashing the app |
| Graceful degradation | Some apps prefer "something shows" over "nothing shows" |
| Domain-specific severity | Missing greeting is annoying; missing balance is catastrophic |

**Why offer strict mode at all?**

Some applications cannot tolerate silent fallbacks. A missing variable returning `{$amount}` could display wrong data to users. These apps need a guarantee: if `format_pattern()` returns, the result is correct.

**Activation:**
- `FluentBundle(..., strict=True)` - explicit opt-in
- `FluentLocalization(..., strict=True)` - propagates to all bundles
- Combine with `cache=CacheConfig()` for caching

**Invariant:** When `strict=True`, NO formatting operation returns a fallback value. Every error path raises `FormattingIntegrityError`. This invariant holds at both levels:
- `FluentBundle.format_pattern()` - raises on resolver errors
- `FluentLocalization.format_value()` / `format_pattern()` - raises on missing messages across all locales

### Strict Mode vs Cache Integrity

These are independent concerns controlled by separate parameters:

| Parameter | Controls | Default |
|:----------|:---------|:--------|
| `FluentBundle(strict=...)` | Formatting error handling (raise vs return fallback) | `False` |
| `FluentLocalization(strict=...)` | Propagated to each bundle | `False` |
| `CacheConfig(integrity_strict=...)` | Cache corruption response (raise vs evict) | `True` |

**Rationale:** Cache corruption is a system-level integrity failure independent of how an application handles formatting errors. A non-strict application (returning fallbacks for missing translations) should still detect and report cache corruption. The default `integrity_strict=True` ensures this.

### Error Layer (FrozenFluentError)

**Responsibility:** Provide immutable, verifiable error objects.

**Design Decisions:**

| Decision | Rationale |
|:---------|:----------|
| Sealed class (`@final`) | Prevents subclass invariant violations |
| Content-addressed (BLAKE2b-128) | Enables corruption detection |
| Slots-only | Memory efficiency, prevents dynamic attributes |
| Composition over inheritance | `ErrorCategory` enum replaces class hierarchy |

**Content Hash Composition:**

The BLAKE2b-128 content hash includes ALL error fields for complete audit trail integrity:

1. **Core fields:** `message`, `category.value`
2. **Diagnostic (if present):**
   - Core: `code.name`, `message`
   - Location: `span` (start, end, line, column as 4-byte big-endian)
   - Context: `hint`, `help_url`, `function_name`, `argument_name`, `expected_type`, `received_type`, `ftl_location`
   - Metadata: `severity`, `resolution_path` (each element)
3. **Context (if present):** `input_value`, `locale_code`, `parse_type`, `fallback_value`

**Length-Prefixing:** All string fields are length-prefixed (4-byte big-endian UTF-8 byte length) before hashing. This prevents collision attacks where concatenating different field sequences produces identical byte streams (e.g., `("ab", "c")` vs `("a", "bc")`).

**Sentinel Bytes:** None values are distinguished from empty values using sentinel bytes, preventing collision between `span=None` and `span=SourceSpan(0, 0, 0, 0)`.

**Freeze Ordering:** `Exception.__init__` is called before `_frozen` is set to `True`. This ensures compatibility with alternative Python runtimes (PyPy, free-threaded builds) where `Exception.__init__` may route through `__setattr__`.

**Invariants:**
- All attributes frozen after `__init__` completes
- `verify_integrity()` always returns True for uncorrupted errors
- Hash is stable for object lifetime

**Security Properties:**
- Constant-time hash comparison (`hmac.compare_digest`) prevents timing attacks
- Surrogate handling (`errors="surrogatepass"`) prevents Unicode exploits
- Complete field coverage prevents metadata tampering

### Cache Layer (IntegrityCache)

**Responsibility:** Provide checksum-verified caching of format results.

**Design Decisions:**

| Decision | Rationale |
|:---------|:----------|
| BLAKE2b-128 checksums | Fast cryptographic hash, 16-byte overhead per entry |
| Write-once option | Prevents data races from overwriting cached results |
| Independent integrity_strict | Cache corruption detection decoupled from formatting strict mode |
| Audit logging | Compliance and debugging for financial systems |
| Sequence numbers | Monotonic ordering for audit trail integrity |
| Idempotent write detection | Content-hash comparison for thundering herd tolerance |
| Node budget protection | `_MAX_HASHABLE_NODES` prevents DAG expansion attacks on all paths |

**Configuration via CacheConfig:**

`CacheConfig` validates all parameters at construction time (fail-fast). Invalid values raise `ValueError` immediately rather than deferring to `IntegrityCache.__init__`.

```python
config = CacheConfig(
    size=500,
    write_once=True,
    integrity_strict=True,   # Cache corruption: raise (default)
    enable_audit=True,
)
bundle = FluentBundle("en", cache=config, strict=True)
```

**Checksum Composition:**

The BLAKE2b-128 checksum includes ALL entry fields for complete audit trail integrity:

1. **Content:** `formatted` (UTF-8 encoded, length-prefixed message output)
2. **Errors:** Each error's `content_hash` (or length-prefixed message string if unavailable)
3. **Metadata:**
   - `created_at`: 8-byte IEEE 754 double (monotonic timestamp)
   - `sequence`: 8-byte signed big-endian integer (audit trail ordering)

**Length-Prefixing:** All variable-length fields (formatted string, error messages) are length-prefixed (4-byte big-endian UTF-8 byte length) before hashing, preventing collision attacks from field concatenation.

This means different entries with identical content will have different checksums if their metadata differs. This is correct behavior: the checksum protects the complete entry, not just its content.

**Idempotent Write Detection:**

In write-once mode, concurrent writes of the same message pose a challenge: multiple threads may resolve the same message simultaneously (thundering herd). Without idempotent detection, all but the first thread would trigger `WriteConflictError`, even though all produced identical results.

The cache computes a **content-only hash** (excluding metadata like `created_at` and `sequence`) to detect idempotent writes:

1. Second write arrives for an existing key
2. Cache computes content hash of new entry: `BLAKE2b-128(formatted, errors)`
3. Compares with existing entry's content hash (constant-time via `hmac.compare_digest`)
4. If identical: increment `idempotent_writes` counter, return silently (benign race)
5. If different: TRUE conflict - raise `WriteConflictError` (integrity_strict) or log (non-strict)

This allows write-once mode to work correctly under load without false-positive conflicts.

**Type-Tagging for Cache Keys:**

Cache keys must distinguish between values that hash identically but have different types. The `_make_hashable()` function applies type-tagging to prevent collisions:

| Type | Tag Format | Purpose |
|:-----|:-----------|:--------|
| `bool` | `("__bool__", value)` | Distinguish `True` from `1` |
| `int` | `("__int__", value)` | Distinguish `1` from `1.0` |
| `float` | `("__float__", value)` | Distinguish `1.0` from `1` |
| `Decimal` | `("__decimal__", str(value))` | Preserve scale for CLDR plural rules (`Decimal("1.0")` vs `Decimal("1.00")`) |
| `FluentNumber` | `("__fluentnumber__", type, value, formatted, precision)` | Preserve underlying type and formatting info |
| `list` | `("__list__", tuple(...))` | Distinguish from tuple in formatted output |
| `tuple` | `("__tuple__", tuple(...))` | Distinguish from list |

**CLDR Plural Rule Preservation:** Decimal type-tagging uses `str(value)` instead of the numeric value. This preserves scale information critical for CLDR plural rules: `Decimal("1.0")` and `Decimal("1.00")` must cache separately because some locales have scale-dependent plural forms.

**Recursive Verification:**

The `IntegrityCacheEntry.verify()` method performs recursive integrity verification:

1. Recomputes entry checksum from current field values
2. For each `FrozenFluentError` in the errors tuple, calls `verify_integrity()`
3. Returns `True` only if ALL checks pass (entry checksum AND all error content hashes)

This defense-in-depth approach detects corruption at any level of the data hierarchy.

**Invariants:**
- Every `get()` verifies checksum before returning
- Corrupted entries are never returned (either raise or evict)
- Sequence numbers never decrease, even after `clear()`
- Metadata tampering is detected by checksum verification
- Node budget enforced on all recursive `_make_hashable` paths (including Mapping ABC)

**Trade-offs:**
- Checksum verification adds ~0.1 microseconds per `get()` - acceptable for financial correctness
- Write-once mode prevents legitimate cache updates - use only when data race prevention is critical
- Different timestamps produce different checksums - not suitable for content-only comparison
- Idempotent detection adds hash comparison on cache hit - negligible for concurrent workloads

### Integrity Exception Layer

**Responsibility:** Signal system failures distinct from Fluent errors.

**Design Decision:** Separate hierarchy from `FrozenFluentError` because:
1. Different error domains (system failure vs. translation issue)
2. Different handling requirements (escalate vs. fallback)
3. Prevents confusion when catching exceptions

**Hierarchy:**
```
DataIntegrityError (base - immutable after construction)
+-- CacheCorruptionError       - Checksum mismatch detected
+-- FormattingIntegrityError   - Strict mode formatting failure
+-- ImmutabilityViolationError - Mutation attempt on frozen object
+-- IntegrityCheckFailedError  - Generic verification failure
+-- SyntaxIntegrityError       - Strict mode syntax error during resource loading
+-- WriteConflictError         - Write-once cache violation
```

**Invariant:** All integrity exceptions carry `IntegrityContext` for post-mortem analysis.

## Concurrency Model

### Lock Architecture

| Component | Lock Type | Rationale |
|:----------|:----------|:----------|
| `FluentBundle._rwlock` | Custom `RWLock` | High-concurrency format operations; read-heavy; writer-preference |
| `FluentLocalization._lock` | Custom `RWLock` | Concurrent format reads; exclusive writes for add_resource/add_function |
| `IntegrityCache._lock` | `threading.RLock` | Short operations; LRU requires mutation on every read hit |
| `LocaleContext._cache_lock` | `threading.RLock` | Class-level LRU cache; infrequent writes |

### Context Manager Semantics

Both `FluentBundle` and `FluentLocalization` use identical context manager semantics: cache invalidation tracking.

```python
with bundle_or_l10n:
    bundle_or_l10n.add_resource(...)   # Sets _modified_in_context = True
    bundle_or_l10n.format_pattern(...) # Read-only, no flag change
# On exit: caches cleared only if modified (conditional invalidation)
```

This avoids unnecessary cache invalidation for read-only contexts while ensuring consistency after mutations.

## Security Model

### Attack Vectors Mitigated

| Attack | Mitigation |
|:-------|:-----------|
| Error mutation after logging | `__setattr__` raises after freeze |
| Subclass overrides | `@final` + `__init_subclass__` raises |
| Dynamic attribute injection | `__slots__` only, no `__dict__` |
| Hash tampering | Constant-time comparison |
| Cache poisoning | Checksum verification on every read |
| Data race overwrites | Write-once semantics option |
| Metadata tampering | Complete field coverage in checksums/hashes |
| Diagnostic field tampering | All 11 Diagnostic fields included in error hash |
| Timestamp/sequence forgery | Metadata included in cache checksum |
| Field concatenation collision | Length-prefixing prevents `("ab","c")` = `("a","bc")` |
| Type confusion in cache keys | Type-tagging distinguishes `1` from `1.0` from `True` |
| Decimal scale loss | `str(Decimal)` preserves scale for CLDR plural rules |
| Nested error corruption | Recursive verification checks entry AND all contained errors |
| DAG expansion in cache keys | Node budget (`_MAX_HASHABLE_NODES`) on all recursive paths |

### Trust Boundaries

1. **External input** (FTL source, format arguments): Validated at parser/bundle boundary
2. **Cached data**: Verified on every read via checksum
3. **Error objects**: Immutable after construction
4. **Configuration**: Validated at `CacheConfig` construction (fail-fast)

## Performance Characteristics

| Operation | Overhead | Acceptable Because |
|:----------|:---------|:-------------------|
| Error hash computation | ~0.1 microseconds | One-time at construction |
| Cache checksum verification | ~0.1 microseconds | Correctness over speed for financial |
| Slots vs dict | ~200 bytes saved per error | Net memory reduction |
| RWLock vs RLock | Negligible for writes, better for reads | Concurrent format operations scale linearly |

## References

- [FrozenFluentError API](DOC_05_Errors.md)
- [ErrorCategory Enum](DOC_05_Errors.md)
- [FluentBundle strict mode](DOC_01_Core.md)
- [Thread Safety](THREAD_SAFETY.md)
- [BLAKE2 Specification](https://www.blake2.net/)
