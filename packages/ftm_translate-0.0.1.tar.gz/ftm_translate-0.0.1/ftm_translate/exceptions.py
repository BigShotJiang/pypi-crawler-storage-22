class ProcessingException(Exception):
    "A data-related error occuring during file processing."

    pass
