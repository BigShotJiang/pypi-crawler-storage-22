# -*- coding: utf-8 -*-
"""
Geopackage Extension
"""


if __name__ == '__main__':  # pragma: no cover
    pass
