"""API Module - REST API endpoints for health checks and future API functionality."""
