"""PWA (Progressive Web App) tests."""
