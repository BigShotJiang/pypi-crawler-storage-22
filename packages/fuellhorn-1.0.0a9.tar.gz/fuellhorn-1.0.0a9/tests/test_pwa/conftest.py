"""PWA-Test spezifische Konfiguration.

NiceGUI Testing Plugin wird hier geladen für HTTP Client Tests.
"""

pytest_plugins = ["nicegui.testing.plugin"]
