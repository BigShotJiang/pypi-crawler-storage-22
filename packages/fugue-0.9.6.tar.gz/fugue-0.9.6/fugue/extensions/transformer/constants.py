OUTPUT_TRANSFORMER_DUMMY_SCHEMA = "__output_no_data__:int"
