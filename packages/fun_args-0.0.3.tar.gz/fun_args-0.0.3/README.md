# Fun Args Package

Simple argument passing library inspired by Typer

```python
from fun_args import argumentize

# Your main with explicitly defined parameters
def main(name: str, age: int = 25, smart = False):
    print(f"Hi, {name}")

# Don't forget to call my function
argumentize(main)
```

Now you in your terminal you can run:
`python filename.py --name Max --age 22`

Supports both flagged and ordered parameters. E.g.

```python
def main(a, b):
    print(a + b)

```

You could run in with
`python filename.py 2 7`

And get 27, because by default everything's converted to strings
