import inspect
import sys


def convert(value, to_type):
    try:
        if to_type == bool:
            return True
        if to_type == int:
            return int(value)
        if to_type == float:
            return float(value)
        return value
    except ValueError:
        print(f"Invalid value: {value} for type: {to_type}")
        return None


def argumentize(main):
    sig = inspect.signature(main)
    params = list(sig.parameters.values())

    argv = sys.argv[1:]
    parsed = {}
    positionals = []

    i = 0
    while i < len(argv):
        arg = argv[i]

        if arg.startswith("--"):
            key = arg[2:]
            param = sig.parameters[key]

            if param.annotation == bool:
                parsed[key] = True
                i += 1
            else:
                value = argv[i + 1]
                parsed[key] = convert(value, param.annotation)
                i += 2
        else:
            positionals.append(arg)
            i += 1

    # fill positional parameters
    for param, value in zip(params, positionals):
        if param.name not in parsed:
            parsed[param.name] = convert(value, param.annotation)

    # fill defaults
    for param in params:
        if param.name not in parsed:
            if param.default != inspect._empty:
                parsed[param.name] = param.default
            elif param.annotation == bool:
                parsed[param.name] = False

    return main(**parsed)
