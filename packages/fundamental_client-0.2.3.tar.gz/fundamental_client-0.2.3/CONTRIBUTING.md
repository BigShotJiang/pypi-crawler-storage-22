# Contributing to Fundamental Python SDK

We welcome contributions to the Fundamental Python SDK! Whether it's a bug fix, documentation improvement, or additional tests, your help is appreciated.

## Reporting Issues

Go to this repository's [issues page](https://github.com/fundamental/fundamental-python/issues) and click "New Issue". Please check if the issue has already been reported before creating a new one.

Include the following information:

- Describe what you expected to happen
- If possible, include a [minimal reproducible example](https://stackoverflow.com/help/minimal-reproducible-example)
- Describe what actually happened, including the full traceback if there was an exception
- List your Python version and SDK version

## Development Setup

Fork the repository and clone it locally:

```bash
git clone https://github.com/YOUR-USERNAME/fundamental-python
cd fundamental-python
git checkout -b my-feature-branch main
```

### Quick Setup

We recommend using our bootstrap script for easy setup:

```bash
./scripts/bootstrap
```

## Making Changes

1. Make your changes
2. Format code: `./scripts/format`
3. Check linting: `./scripts/lint`
4. Run tests: `./scripts/test`

## Testing

We use [pytest](https://docs.pytest.org/) for testing. To run tests:

```bash
# Run all tests
uv run nox

# Run specific test file
uv run pytest tests/unit/test_estimators.py -v

# Run tests for specific Python version
uv run nox -s tests-3.10
```

When adding new tests, place them in the `tests/` directory following the same structure as the source code.

## Opening a Pull Request

Push your branch and open a pull request against the `main` branch. Include:

- Clear title following Conventional Commits format
- Description of what you changed and why
- Reference any related issues

Make sure all CI checks pass before requesting review.

## Getting Help

- **Issues**: For bugs and feature requests
- **Email**: support@fundamental.tech for questions
- **Documentation**: See README.md for usage examples

We appreciate all contributions and will provide constructive feedback on pull requests. Thank you for helping improve the Fundamental Python SDK!
