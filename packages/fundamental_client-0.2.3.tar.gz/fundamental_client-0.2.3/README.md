# Fundamental Python SDK

[![PyPI version](https://img.shields.io/pypi/v/fundamental-client.svg?label=pypi%20package)](https://pypi.org/project/fundamental-client/)
[![Python Versions](https://img.shields.io/pypi/pyversions/fundamental-client?color=%2334D058)](https://pypi.org/project/fundamental-client)
[![License](https://img.shields.io/badge/License-Apache_2.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)

A scikit-learn compatible Python SDK for NEXUS, Fundamental's large model for tabular data.

## Table of Contents

- [Installation](#installation)
- [Usage](#usage)
  - [Quick Start](#quick-start)
  - [Using Pre-trained Models](#using-pre-trained-models)
  - [Async Training](#async-training)
  - [Model Management](#model-management)
  - [Explainability & Insights](#explainability--insights)
    - [Feature Importance](#feature-importance)
- [Configuration](#configuration)
  - [Client Configuration](#client-configuration)
    - [API Key](#api-key)
    - [Private Deployment (EC2)](#private-deployment-ec2)
    - [Timeouts and Retries](#timeouts-and-retries)
  - [Model Configuration](#model-configuration)
    - [Mode](#mode)
- [Supported Data Types](#supported-data-types)
- [Handling Errors](#handling-errors)
  - [Diagnostics and Support Information](#diagnostics-and-support-information)
  - [Exception Types](#exception-types)
- [Development](#development)
  - [Installation](#installation-1)
  - [Running Tests](#running-tests)
  - [Code Quality](#code-quality)
  - [Generating API Models](#generating-api-models)
- [Versioning](#versioning)
  - [Release Flow](#release-flow)
  - [Determining the Installed Version](#determining-the-installed-version)
- [Requirements](#requirements)
- [Contributing](#contributing)
- [License](#license)
- [Support](#support)
- [Acknowledgments](#acknowledgments)

## Installation

```sh
# install from PyPI
pip install fundamental-client
```

## Usage

The Fundamental SDK provides scikit-learn compatible estimators for classification and regression tasks, along with a flexible client for API interactions.


### Quick Start

```python
from sklearn.datasets import load_breast_cancer, load_diabetes
from sklearn.model_selection import train_test_split
from fundamental import Fundamental, NEXUSClassifier, NEXUSRegressor

# Load classifaction data
X, y = load_breast_cancer(return_X_y=True)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.5, random_state=42)

# Classification
classifier = NEXUSClassifier()
classifier.fit(X_train, y_train)

# After fitting, the model ID can be saved and used later
print(f"Trained model ID: {classifier.trained_model_id_}")

predictions = classifier.predict(X_test)
probabilities = classifier.predict_proba(X_test)

# Load regression data
X, y = load_diabetes(return_X_y=True)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.5, random_state=42)

# Regression
regressor = NEXUSRegressor()
regressor.fit(X_train, y_train)
predictions = regressor.predict(X_test)
```

### Using Pre-trained Models

If you have a trained model from a previous session, you can use it directly without retraining:

```python
from fundamental import Fundamental, NEXUSClassifier, NEXUSRegressor

classifier = NEXUSClassifier().load_model(trained_model_id="model_abc123")
predictions = classifier.predict(X_test)
probabilities = classifier.predict_proba(X_test)

regressor  = NEXUSRegressor().load_model(trained_model_id="model_def456")
predictions = regressor.predict(X_test)
```

### Async Training

Model training is often a long-running operation. To support non-blocking workflows, fit() can be executed asynchronously. Once submitted, the training job runs in the background and its status can be queried at any time.

```python
from fundamental import NEXUSClassifier
import time

classifier = NEXUSClassifier()

# Submit training task without waiting
task_id = classifier.submit_fit_task(X_train, y_train)
print(f"Training task submitted: {task_id}")

# Poll status periodically
result = None
while result is None:
    result = classifier.poll_fit_result(task_id)
    if result is None:
        print("Training in progress...")
        time.sleep(10)  # Wait before polling again

# Model is now fitted and ready for predictions
predictions = classifier.predict(X_test)
```

### Model Management

The client provides methods for managing your trained models:

```python
from fundamental import Fundamental

# Create a client
client = Fundamental()

# List all available models
models = client.models.list()
print(f"Available models: {models}")

# Get information about a specific model
model_info = client.models.get("model_id_123")
print(f"Model info: {model_info}")
print(f"Attributes: {model_info.attributes}")

# Delete a model
client.models.delete("model_id_123")
```

#### Model Attributes

You can set attributes on your models to help organize and identify them.
We recommend always setting a `name` attribute; if omitted, the name will default to
`<model_version> [id:<model_id_suffix>]`.

```python
# Set attributes directly on a fitted model
classifier.set_attributes({"name": "Breast Cancer Classifier", "stage": "prod"})

# Or using the client
client.models.set_attributes(
    "model_id_123",
    attributes={"name": "Breast Cancer Classifier", "description": "Production model v1"}
)
```

### Explainability & Insights

#### Feature Importance

After fitting a model, you can compute feature importance to quantify the contribution of each input feature to the model's output:

```python
from fundamental import NEXUSClassifier


# Load data
X, y = load_breast_cancer(return_X_y=True)
X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.5, random_state=42)
# Fit the model
classifier = NEXUSClassifier()
classifier.fit(X_train, y_train)
# Get feature importance (waits for computation to complete)
feature_importance = classifier.get_feature_importance(X_val)
print(f"Feature importance: {feature_importance}")
```

Feature importance computation can take a significant amount of time. If you prefer to submit the task and check its status periodically, you can use the asynchronous approach:

```python
# Submit task without waiting
task_id = classifier.submit_feature_importance_task(X_val)

# Poll status later
result = classifier.poll_feature_importance_result(task_id)
if result is not None:
    print(f"Feature importance: {result}")
```

## Configuration

### Client Configuration

Configure the SDK client through environment variables or programmatically.

#### API Key

You can provide your API key in two ways:

```python
# 1. Programmatic
import fundamental
from fundamental import Fundamental, NEXUSClassifier

fundamental.set_client(Fundamental(api_key="your_api_key_here"))
classifier = NEXUSClassifier()
```

```bash
# 2. Environment variable
export FUNDAMENTAL_API_KEY="your_api_key_here"
```

#### Private Deployment (EC2)

For private deployments running on AWS EC2/ECS/EKS, use the `FundamentalEC2Client` which authenticates using AWS IAM roles via SigV4 signing instead of API keys:

```python
import fundamental
from fundamental import FundamentalEC2Client, FTMClassifier

# Set the EC2 client with your private deployment URL and AWS region
fundamental.set_client(FundamentalEC2Client(
    aws_region="us-west-2",  # Required
    api_url="http://your-private-server:8000"
))

# Use the SDK as normal
classifier = FTMClassifier()
classifier.fit(X_train, y_train)
predictions = classifier.predict(X_test)
```

The `FundamentalEC2Client` automatically uses AWS credentials from the environment (IAM role, environment variables, or AWS config file) to sign requests. No API key is needed.

You can also configure using environment variables:

```bash
export FUNDAMENTAL_API_URL="http://your-private-server:8000"
```

```python
fundamental.set_client(FundamentalEC2Client(
    aws_region="us-west-2"  # Required; api_url from env var
))
```

#### Timeouts and Retries

Configure timeouts and retries when creating a client:

> **Note**: Timeouts apply only to the processing phase, starting after the dataset upload has completed.

```python
import fundamental
from fundamental import Fundamental, NEXUSClassifier

# Create and set a client with custom timeouts and retries
fundamental.set_client(Fundamental(
    fit_timeout=600,  # 10 minutes for training (default: 1 hour)
    predict_timeout=30,  # 30 seconds for predictions (default: 1 hour)
    retries=0  # Number of retries (default: 2)
))

# Estimators will use the global client
classifier = NEXUSClassifier()
```

### Model Configuration

Configure model behavior and training parameters.

#### Mode

NEXUS offers two training modes to balance between speed and accuracy:

- **`quality` mode (default)**: Optimizes for the highest accuracy. This mode uses more comprehensive training processes and may take longer to complete.
- **`speed` mode**: Optimizes for faster training times while maintaining good accuracy.

```python
import fundamental
from fundamental import NEXUSClassifier, NEXUSRegressor

# Use quality mode (default)
classifier = NEXUSClassifier(mode="quality")
classifier.fit(X_train, y_train)

# Use speed mode for faster training
classifier_fast = NEXUSClassifier(mode="speed")
classifier_fast.fit(X_train, y_train)

# Same for regression
regressor = NEXUSRegressor(mode="speed")
regressor.fit(X_train, y_train)
```

## Supported Data Types

The SDK supports flexible input formats:

- **Input features (X)**:
  - `pandas.DataFrame`
  - `numpy.ndarray`

- **Target values (y)**:
  - `numpy.ndarray`
  - `pandas.Series`

> **Note**: Data must contain numeric types only. Object dtypes (strings, mixed types) and complex numbers are not supported. Please convert categorical data to numeric encoding before fitting.

## Handling Errors

The SDK provides detailed error handling with specific exception types:

```python
from fundamental import NEXUSClassifier
from fundamental.exceptions import (
    NEXUSError,
    ValidationError,
    AuthenticationError,
    RateLimitError,
    ServerError
)

classifier = NEXUSClassifier()

try:
    classifier.fit(X_train, y_train)
except ValidationError as e:
    print(f"Invalid input data: {e}")
    print(f"Status code: {e.status_code}")
except AuthenticationError as e:
    print("Authentication failed - check your API key")
except RateLimitError as e:
    print("Rate limit exceeded - please wait before retrying")
except ServerError as e:
    print("Server error - please try again later")
except NEXUSError as e:
    print(f"An error occurred: {e}")
```

### Diagnostics and Support Information

All exceptions include a `trace_id` attribute that you can share with Fundamental support to help diagnose issues more quickly.

```python
except ServerError as e:
    if e.trace_id:
        print(f"Error trace_id: {e.trace_id}")
```

### Exception Types

| Error Type | Description | Status Code |
| ---------- | ----------- | ----------- |
| `ValidationError` | Input validation failed (bad request) | 400 |
| `AuthenticationError` | Authentication failed (missing/invalid API key) | 401 |
| `AuthorizationError` | Authorization failed (insufficient permissions) | 403 |
| `NotFoundError` | Resource not found | 404 |
| `RateLimitError` | API rate limit exceeded | 429 |
| `ServerError` | Server-side error | 500+ |
| `NetworkError` | Network connectivity issues | 503 |
| `RequestTimeoutError` | Request timed out | 504 |


## Development

### Installation

```bash
# Clone the repository
git clone https://github.com/fundamental/fundamental-python.git
cd fundamental-python

# Install with development dependencies using UV
uv sync --group dev

# Or with pip
pip install -e ".[dev]"
```

### Running Tests

```bash
# Run all tests using the test script
./scripts/test

# Or run directly with nox for all Python versions
uv run nox -s tests

# Run tests for specific Python version
uv run nox -s tests-3.10

# Run tests with minimum dependencies
uv run nox -s tests-3.10 -- minimum

# Run specific test file directly
uv run pytest tests/unit/test_estimators.py
```

### Code Quality

```bash
# Format code using the format script
./scripts/format

# Run all linting checks using the lint script
./scripts/lint

# Or run individual checks:
# Ruff check
uv run ruff check .

# Type checking with pyright
uv run pyright

# Type checking with mypy
uv run mypy .

# Run all pre-commit hooks
uv run pre-commit run --all-files
```

### Generating API Models

The SDK uses auto-generated Pydantic models from the Fundamental API's OpenAPI specification. This ensures type safety and keeps the client in sync with the API.

```bash
# Regenerate models from the OpenAPI spec
./scripts/generate-models

# Use a different OpenAPI URL (e.g., production)
OPENAPI_URL=https://api.fundamental-dev.tech/openapi.json ./scripts/generate-models
```

Generated models are placed in `src/fundamental/models/generated.py` and can be imported from `fundamental.models`:

```python
from fundamental.models import (
    FitRequest,
    FitResponse,
    TaskStatus,
    TaskStatusResponse,
)
```

When the API changes, simply re-run the generation script to update the models.

## Versioning

This package follows [SemVer](https://semver.org/spec/v2.0.0.html) conventions. We use [Release Please](https://github.com/googleapis/release-please) for automated versioning and changelog generation.

### Release Flow

**Main Branch (Stable Releases):**
1. Push to `main` triggers Release Please to create/update a Release PR
2. Merging the Release PR creates a GitHub Release
3. The GitHub Release triggers publishing to CodeArtifact and TestPyPI

**Feature Branches (Dev Releases):**
1. Push to any non-main branch publishes a dev version to CodeArtifact
2. Dev version format: `X.Y.Z.dev0+<commit-hash>`

> **Note:** CodeArtifact may show dev versions as "Latest", but `pip install fundamental-client` will install the stable version. Use `--pre` to install dev versions.

### Determining the Installed Version

```python
import fundamental
print(fundamental.__version__)
```

## Requirements

- Python 3.10 or higher
- See [pyproject.toml](pyproject.toml) for full dependency list

## Contributing

We welcome contributions! Please see our [Contributing Guidelines](CONTRIBUTING.md) for details on how to get started.

For quick setup, run:
```bash
./scripts/bootstrap
```

## License

This project is licensed under the Apache License 2.0 - see the [LICENSE](LICENSE) file for details.

## Support

- **Documentation**: [fundamental.tech/docs](https://fundamental.tech/docs)
- **Issues**: [GitHub Issues](https://github.com/fundamental/fundamental-python/issues)
- **Email**: [support@fundamental.tech](mailto:support@fundamental.tech)

## Acknowledgments

Built with ❤️ by Fundamental Tech
