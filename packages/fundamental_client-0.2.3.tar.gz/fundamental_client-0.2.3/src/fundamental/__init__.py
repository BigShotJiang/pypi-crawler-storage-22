"""Fundamental Python SDK for tabular machine learning."""

from typing import Optional

from fundamental.clients import BaseClient, Fundamental, FundamentalEC2Client

# Deprecated aliases
from fundamental.deprecated import FTMClassifier, FTMRegressor
from fundamental.estimator import NEXUSClassifier, NEXUSRegressor

__version__ = "0.1.4"

_global_client: Optional[BaseClient] = None


def set_client(client: BaseClient) -> None:
    global _global_client
    _global_client = client


def get_client() -> BaseClient:
    return _global_client or Fundamental()


__all__ = [
    "FTMClassifier",
    "FTMRegressor",
    "Fundamental",
    "FundamentalEC2Client",
    "NEXUSClassifier",
    "NEXUSRegressor",
    "get_client",
    "set_client",
]
