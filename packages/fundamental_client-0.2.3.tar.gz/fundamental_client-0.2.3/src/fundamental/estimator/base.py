"""
Base classes and model registry for NEXUS estimators.

This module contains the ModelRegistry for managing available models and
the abstract BaseNEXUSEstimator class that provides common functionality
for both classification and regression tasks.
"""

import logging
from abc import ABC
from typing import Any, ClassVar, Literal, Optional

import numpy.typing as npt
from sklearn.base import BaseEstimator
from sklearn.utils.validation import check_is_fitted
from typing_extensions import Self

import fundamental
from fundamental.clients import BaseClient
from fundamental.services import poll_fit_result, remote_fit, remote_predict, submit_fit_task
from fundamental.services.models import ModelsService
from fundamental.utils.data import (
    XType,
    YType,
    check_n_features_compat,
    validate_data,
    validate_inputs_type,
)

logger = logging.getLogger(__name__)


class BaseNEXUSEstimator(BaseEstimator, ABC):  # type: ignore[misc]
    """
    Abstract base class for NEXUS estimators.

    Provides common functionality and interface for both classification
    and regression estimators.
    """

    _task_type: ClassVar[Literal["classification", "regression"]]

    def __init__(
        self,
        mode: Literal["quality", "speed"] = "quality",
    ):
        """Initialize the estimator.

        Args:
            mode: Training mode - "quality" for best performance, "speed" for faster training.
        """
        self.mode: Literal["quality", "speed"] = mode

    def _get_client(self) -> BaseClient:
        return fundamental.get_client()

    def _set_n_features_in(self, X: XType) -> None:
        """Set n_features_in_ attribute for sklearn compatibility.

        Args:
            X: Input features array or dataframe.
        """
        self.n_features_in_ = X.shape[1]

    def load_model(self, trained_model_id: str) -> Self:
        """
        Load a trained model.
        """
        self._load_trained_model(trained_model_id)
        self.fitted_ = True
        return self

    def fit(self, X: XType, y: YType) -> Self:
        """
        Fit the model to training data.

        Parameters
        ----------
        X : XType
            Training features as numpy array, pandas DataFrame.
        y : YType
            Training targets as numpy array, pandas Series.

        Returns
        -------
        Self
            Self for method chaining.
        """
        validate_inputs_type(X=X, y=y)
        validate_data(X=X, y=y)

        response = remote_fit(
            X=X,
            y=y,
            task=type(self)._task_type,
            mode=self.mode,
            client=self._get_client(),
        )
        self._load_estimator_fields(response.estimator_fields)
        self.trained_model_id_ = response.trained_model_id
        self.fitted_ = True
        self._set_n_features_in(X)
        return self

    def set_attributes(
        self,
        attributes: dict[str, str],
    ) -> Self:
        """
        Set attributes on the fitted model.

        Parameters
        ----------
        attributes : dict[str, str]
            Dictionary of key-value pairs to set as model attributes.

        Returns
        -------
        Self
            Self for method chaining.

        Raises
        ------
        NotFittedError
            If the model has not been fitted yet.

        Examples
        --------
        >>> clf.set_attributes({"stage": "prod", "owner": "lital"})
        """
        check_is_fitted(self)
        assert self.trained_model_id_ is not None

        models_service = ModelsService(client=self._get_client())
        models_service.set_attributes(
            model_id=self.trained_model_id_,
            attributes=attributes,
        )
        return self

    def submit_fit_task(self, X: XType, y: YType) -> str:
        """
        Submit a fit task without waiting for completion.

        Parameters
        ----------
        X : XType
            Training features as numpy array, pandas DataFrame.
        y : YType
            Training targets as numpy array, pandas Series.

        Returns
        -------
        str
            Task ID for polling with poll_fit_result.
        """
        validate_inputs_type(X=X, y=y)
        validate_data(X=X, y=y)
        result = submit_fit_task(
            X=X,
            y=y,
            task=type(self)._task_type,
            mode=self.mode,
            client=self._get_client(),
        )
        # Store for poll_fit_result to use
        self._pending_trained_model_id = result.trained_model_id
        self._pending_n_features_in = X.shape[1]
        return result.task_id

    def poll_fit_result(self, task_id: str) -> Optional[Self]:
        """
        Check fit task status and load model if complete.

        Parameters
        ----------
        task_id : str
            The task ID returned by submit_fit_task.

        Returns
        -------
        Optional[Self]
            Self if fitting completed (for method chaining), None if still in progress.
        """
        result = poll_fit_result(
            task_id=task_id,
            trained_model_id=self._pending_trained_model_id,
            client=self._get_client(),
        )
        if result is not None:
            self._load_estimator_fields(result.estimator_fields)
            self.trained_model_id_ = result.trained_model_id
            self.fitted_ = True
            self.n_features_in_ = self._pending_n_features_in
            # Clean up pending attributes
            del self._pending_n_features_in
            del self._pending_trained_model_id
            return self
        return None

    def predict(self, X: XType) -> npt.NDArray[Any]:
        """
        Predict preds function.

        Parameters
        ----------
        X : XType
            Input features as numpy array, pandas DataFrame.


        Returns
        -------
        np.ndarray
            Model predictions.

        Raises
        ------
        NotFittedError
            If the model has not been fitted yet.
        """
        return self._predict(X=X, output_type="preds")

    def _predict(
        self,
        X: XType,
        output_type: Literal["preds", "probas"],
    ) -> npt.NDArray[Any]:
        """Internal prediction method with configurable output type."""
        validate_inputs_type(X=X)
        validate_data(X=X)
        check_is_fitted(self)

        # Validate n_features_in_ for sklearn compatibility
        check_n_features_compat(self, X, reset=False)

        assert self.trained_model_id_ is not None
        return remote_predict(
            X=X,
            output_type=output_type,
            trained_model_id=self.trained_model_id_,
            client=self._get_client(),
        )

    def _load_trained_model(self, model_id: str) -> None:
        try:
            models_service = ModelsService(client=self._get_client())
            response = models_service.load(
                trained_model_id=model_id,
            )
            self._load_estimator_fields(response.estimator_fields)
            self.trained_model_id_ = model_id
        except Exception as e:
            logger.error(f"Failed to load model {model_id}: {e}")
            raise e

    def _load_estimator_fields(self, estimator_fields: dict[str, Any]) -> None:
        for field, value in estimator_fields.items():
            try:
                # Keep private attrs as-is, add underscore to public attrs (sklearn convention)
                field_name = field if field.endswith("_") or field.startswith("_") else f"{field}_"
                setattr(self, field_name, value)
            except AttributeError:
                logger.warning(f"Field {field} is not a valid attribute in the current estimator")
