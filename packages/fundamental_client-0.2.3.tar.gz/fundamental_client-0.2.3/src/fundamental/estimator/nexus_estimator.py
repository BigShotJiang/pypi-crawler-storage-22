"""
NEXUS Estimator with public API methods.

This module contains NEXUSEstimator which extends BaseNEXUSEstimator with public API methods.
"""

from abc import ABC
from typing import Optional

import numpy as np
from sklearn.utils.validation import check_is_fitted

from fundamental.estimator.base import BaseNEXUSEstimator
from fundamental.services import remote_get_feature_importance
from fundamental.services.feature_importance import (
    poll_feature_importance_result,
    submit_feature_importance_task,
)
from fundamental.utils.data import XType, validate_data, validate_inputs_type


class NEXUSEstimator(BaseNEXUSEstimator, ABC):
    """
    NEXUS Estimator with public API methods.

    Extends BaseNEXUSEstimator with advanced operations.
    """

    def get_feature_importance(
        self,
        X: XType,
    ) -> np.ndarray:
        """
        Get feature importance for the fitted model.

        Submits the task and waits for completion.

        Parameters
        ----------
        X : XType
            Input features for feature importance computation.

        Returns
        -------
        np.ndarray
            Feature importance values.

        Raises
        ------
        NotFittedError
            If the model has not been fitted yet.
        """
        validate_inputs_type(X=X)
        validate_data(X=X)
        check_is_fitted(self)
        assert self.trained_model_id_ is not None
        return remote_get_feature_importance(
            X=X,
            trained_model_id=self.trained_model_id_,
            client=self._get_client(),
        )

    def submit_feature_importance_task(
        self,
        X: XType,
    ) -> str:
        """
        Submit a feature importance computation task without waiting for completion.

        Parameters
        ----------
        X : XType
            Input features for feature importance computation.

        Returns
        -------
        str
            The task ID to use with poll_feature_importance_result.

        Raises
        ------
        NotFittedError
            If the model has not been fitted yet.
        """
        validate_inputs_type(X=X)
        validate_data(X=X)
        check_is_fitted(self)
        assert self.trained_model_id_ is not None
        return submit_feature_importance_task(
            X=X,
            trained_model_id=self.trained_model_id_,
            client=self._get_client(),
        )

    def poll_feature_importance_result(self, task_id: str) -> Optional[np.ndarray]:
        """
        Check the status of a feature importance task.

        Parameters
        ----------
        task_id : str
            The task ID returned by submit_feature_importance_task.

        Returns
        -------
        Optional[np.ndarray]
            Feature importance values if completed, None if still in progress.

        Raises
        ------
        NotFittedError
            If the model has not been fitted yet.
        """
        check_is_fitted(self)
        assert self.trained_model_id_ is not None
        return poll_feature_importance_result(
            task_id=task_id,
            trained_model_id=self.trained_model_id_,
            client=self._get_client(),
        )
