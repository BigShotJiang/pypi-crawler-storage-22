"""NEXUS Regression estimator."""

import logging
from typing import Literal

from sklearn.base import RegressorMixin

from fundamental.estimator.nexus_estimator import NEXUSEstimator

logger = logging.getLogger(__name__)


class NEXUSRegressor(RegressorMixin, NEXUSEstimator):
    """NEXUS Model for Regression Tasks."""

    _task_type = "regression"  # type: ignore[assignment]

    def __init__(
        self,
        mode: Literal["quality", "speed"] = "quality",
    ):
        super().__init__(mode=mode)
