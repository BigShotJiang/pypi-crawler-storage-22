"""
Tests for data utilities and validation functions.
"""

import io

import numpy as np
import pandas as pd
import pytest

from fundamental.utils.data import (
    FileUpload,
    serialize_df_to_parquet_bytes,
    to_httpx_post_file_format,
    validate_data,
    validate_inputs_type,
)


class TestDataValidation:
    """Test data validation functions."""

    def test_validate_inputs_type_valid_dataframe(self, sample_classification_data):
        """Test validation with valid DataFrame input."""
        X, y = sample_classification_data
        # Should not raise any exception
        validate_inputs_type(X=X, y=y)

    def test_validate_inputs_type_valid_array(self, sample_classification_data):
        """Test validation with numpy array input."""
        X, y = sample_classification_data
        X_array = X.values
        y_array = y
        # Should not raise any exception
        validate_inputs_type(X=X_array, y=y_array)

    def test_validate_inputs_type_invalid_x(self):
        """Test validation with invalid X type."""
        with pytest.raises(TypeError):
            validate_inputs_type(X="invalid", y=np.array([1, 2, 3]))

    def test_validate_inputs_type_invalid_y(self, sample_classification_data):
        """Test validation with invalid y type."""
        X, _ = sample_classification_data
        with pytest.raises(TypeError):
            validate_inputs_type(X=X, y="invalid")

    def test_validate_data_mismatched_lengths(self):
        """Test validation with mismatched X and y lengths."""
        X = pd.DataFrame({"col1": [1, 2, 3]})
        y = np.array([1, 2])  # Different length

        with pytest.raises(ValueError):  # noqa: PT011
            validate_data(X=X, y=y)

    def test_validate_data_empty_dataframe(self):
        """Test validation with empty DataFrame."""
        X = pd.DataFrame()
        y = np.array([])

        with pytest.raises(ValueError):  # noqa: PT011
            validate_data(X=X, y=y)


class TestDataSerialization:
    """Test data serialization functions."""

    def test_serialize_df_to_parquet_bytes(self, sample_classification_data):
        """Test DataFrame serialization to parquet bytes."""
        X, _ = sample_classification_data
        result = serialize_df_to_parquet_bytes(X)

        assert isinstance(result, bytes)
        assert len(result) > 0

        # Verify we can read it back
        df_restored = pd.read_parquet(io.BytesIO(result))
        pd.testing.assert_frame_equal(df_restored, X)

    def test_serialize_series_to_parquet_bytes(self, sample_classification_data):
        """Test Series serialization to parquet bytes."""
        _, y = sample_classification_data
        y_series = pd.Series(y)
        result = serialize_df_to_parquet_bytes(y_series)

        assert isinstance(result, bytes)
        assert len(result) > 0

    def test_serialize_numpy_array_to_parquet_bytes(self):
        """Test numpy array serialization to parquet bytes."""
        arr = np.array([[1, 2, 3], [4, 5, 6]])
        result = serialize_df_to_parquet_bytes(arr)

        assert isinstance(result, bytes)
        assert len(result) > 0

        # Verify we can read it back
        df_restored = pd.read_parquet(io.BytesIO(result))
        np.testing.assert_array_equal(df_restored.values, arr)


class TestFileUpload:
    """Test FileUpload data model."""

    def test_file_upload_creation(self):
        """Test FileUpload model creation."""
        content = b"test content"
        upload = FileUpload(file_name="test.txt", file_type="text", content=content)

        assert upload.file_name == "test.txt"
        assert upload.file_type == "text"
        assert upload.content == content

    def test_to_httpx_post_file_format(self):
        """Test conversion to httpx file format."""
        uploads = [
            FileUpload(file_name="file1", file_type="txt", content=b"content1"),
            FileUpload(file_name="file2", file_type="txt", content=b"content2"),
        ]

        result = to_httpx_post_file_format(uploads)

        assert len(result) == 2
        assert "file1" in result
        assert "file2" in result

        # Check format is correct for httpx
        file1_data = result["file1"]
        assert len(file1_data) == 2  # (filename, content)
        assert file1_data[0] == "file1.txt"
        assert file1_data[1] == b"content1"
