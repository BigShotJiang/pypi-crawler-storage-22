"""
funtrack - 微生物轨迹跟踪和分析工具包

提供视频中微生物（如细菌、草履虫等）的轨迹跟踪、数据分析和可视化功能。
"""

from funtrack.analyzer import (
    TrajectoryDataTask,
    analyze_and_visualize,
    analyze_tracks,
    calculate_angle,
    calculate_angular_velocity,
    calculate_velocity,
    filter_tracks,
    smooth_tracks,
)
from funtrack.base import BaseTask
from funtrack.circle import CircleRegionTask, analyze_circle_trajectories, plot_trajectory_segment
from funtrack.kinematics import KINEMATICS_COLUMNS, ParticleKinematicsTask
from funtrack.tracker import (
    BacteriaTracker,
    TrajectoryTrackingTask,
    estimate_detection_params,
)
from funtrack.video_info import VideoInfoTask, extract_video_info

__all__ = [
    # Base
    "BaseTask",
    # Video Info
    "VideoInfoTask",
    "extract_video_info",
    # Tracker
    "BacteriaTracker",
    "TrajectoryTrackingTask",
    "estimate_detection_params",
    # Kinematics (canonical base for downstream)
    "KINEMATICS_COLUMNS",
    "ParticleKinematicsTask",
    # Trajectory Data
    "TrajectoryDataTask",
    "analyze_and_visualize",
    "analyze_tracks",
    "calculate_velocity",
    "calculate_angle",
    "calculate_angular_velocity",
    "filter_tracks",
    "smooth_tracks",
    # Circle
    "CircleRegionTask",
    "analyze_circle_trajectories",
    "plot_trajectory_segment",
    # Video Info
    "VideoInfoTask",
    "extract_video_info",
]
