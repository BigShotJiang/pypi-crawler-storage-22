"""
轨迹分析模块：基于颗粒运动学结果文件（*_particle_kinematics.csv），
统计与可视化速度、角速度的关系（散点图、热力图等）。
运动学文件由 kinematics 模块产出，含 speed、angular_velocity 等列。
"""

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from nltlog import getLogger
from scipy import signal
from scipy.ndimage import uniform_filter1d

from funtrack.base import BaseTask, output_base_name

logger = getLogger("funtrack")

plt.rcParams["font.sans-serif"] = ["Arial Unicode MS", "SimHei", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False

# 运动学结果文件必需列（用于本模块的统计与绘图）
KINEMATICS_REQUIRED_FOR_ANALYZER = ["idx", "frame", "time", "speed", "angular_velocity"]


# ---------- 以下供 kinematics 模块导入：从轨迹 CSV 计算速度/角度/角速度 ----------


def smooth_tracks(df, method="moving_average", window_size=5, alpha=0.3):
    """对轨迹进行平滑（供 kinematics 使用）。"""
    df = df.copy()
    df = df.sort_values(by=["idx", "frame"])
    df["x_raw"] = df["x"].copy()
    df["y_raw"] = df["y"].copy()
    for track_id in df["idx"].unique():
        track_mask = df["idx"] == track_id
        track_data = df[track_mask].copy()
        if len(track_data) < 3:
            continue
        if method == "moving_average":
            window = min(window_size, len(track_data))
            if window % 2 == 0:
                window += 1
            df.loc[track_mask, "x"] = uniform_filter1d(
                track_data["x"].values, size=window, mode="nearest"
            )
            df.loc[track_mask, "y"] = uniform_filter1d(
                track_data["y"].values, size=window, mode="nearest"
            )
        elif method == "exponential":
            df.loc[track_mask, "x"] = track_data["x"].ewm(alpha=alpha, adjust=False).mean().values
            df.loc[track_mask, "y"] = track_data["y"].ewm(alpha=alpha, adjust=False).mean().values
        elif method == "savgol":
            window = min(window_size, len(track_data))
            if window % 2 == 0:
                window += 1
            polyorder = min(3, window - 1)
            if len(track_data) >= window:
                df.loc[track_mask, "x"] = signal.savgol_filter(
                    track_data["x"].values, window, polyorder, mode="nearest"
                )
                df.loc[track_mask, "y"] = signal.savgol_filter(
                    track_data["y"].values, window, polyorder, mode="nearest"
                )
    return df


def calculate_velocity(df):
    """计算速度 vx, vy, speed（供 kinematics 使用）。"""
    df = df.copy()
    df = df.sort_values(by=["idx", "frame"])
    df["dx"] = df.groupby("idx")["x"].diff()
    df["dy"] = df.groupby("idx")["y"].diff()
    df["dt"] = df.groupby("idx")["time"].diff()
    df["vx"] = df["dx"] / df["dt"].replace(0, np.nan)
    df["vy"] = df["dy"] / df["dt"].replace(0, np.nan)
    df["speed"] = np.sqrt(df["vx"] ** 2 + df["vy"] ** 2)
    df["vx"] = df["vx"].fillna(0)
    df["vy"] = df["vy"].fillna(0)
    df["speed"] = df["speed"].fillna(0)
    return df


def calculate_angle(df):
    """计算朝向 angle（弧度，供 kinematics 使用）。"""
    df = df.copy()
    df["angle"] = np.arctan2(df["vy"], df["vx"])
    df["angle"] = df["angle"] % (2 * np.pi)
    return df


def calculate_angular_velocity(df):
    """计算角速度 angular_velocity（供 kinematics 使用）。"""
    df = df.copy()
    df = df.sort_values(by=["idx", "frame"])
    df["dangle"] = df.groupby("idx")["angle"].diff()
    df["dangle"] = df["dangle"].apply(
        lambda x: (
            x - 2 * np.pi
            if x > np.pi
            else (x + 2 * np.pi if x < -np.pi else x)
            if pd.notna(x)
            else 0
        )
    )
    df["dt"] = df.groupby("idx")["time"].diff()
    df["angular_velocity"] = df["dangle"] / df["dt"].replace(0, np.nan)
    df["angular_velocity"] = df["angular_velocity"].fillna(0)
    return df


def filter_tracks(df, min_points=100, max_speed=None, max_angular_velocity=None):
    """
    按轨迹点数、速度、角速度过滤（输入需含 idx, speed, angular_velocity）。
    返回: (df_filtered, removed_track_ids).
    """
    df = df.copy()
    track_counts = df.groupby("idx").size()
    valid_tracks = track_counts[track_counts >= min_points].index
    df_filtered = df[df["idx"].isin(valid_tracks)].copy()
    removed_tracks = track_counts[track_counts < min_points].index.tolist()
    if removed_tracks:
        logger.info(
            f"过滤短轨迹: 移除了 {len(removed_tracks)} 条轨迹（少于 {min_points} 个数据点）"
        )
    if max_speed is not None:
        before = len(df_filtered)
        df_filtered = df_filtered[df_filtered["speed"] <= max_speed]
        if before - len(df_filtered) > 0:
            logger.info(
                f"过滤异常速度: 移除了 {before - len(df_filtered)} 个数据点（速度 > {max_speed}）"
            )
    if max_angular_velocity is not None:
        before = len(df_filtered)
        df_filtered = df_filtered[df_filtered["angular_velocity"].abs() <= max_angular_velocity]
        if before - len(df_filtered) > 0:
            logger.info(f"过滤异常角速度: 移除了 {before - len(df_filtered)} 个数据点")
    return df_filtered, removed_tracks


# ---------- 基于运动学结果文件的统计与可视化 ----------


def load_kinematics(csv_path):
    """
    读取颗粒运动学结果文件，校验必需列。
    必需列: idx, frame, time, speed, angular_velocity。
    返回: DataFrame（列名去空格）。
    """
    df = pd.read_csv(csv_path)
    df.columns = df.columns.str.strip()
    missing = [c for c in KINEMATICS_REQUIRED_FOR_ANALYZER if c not in df.columns]
    if missing:
        raise ValueError(
            f"运动学结果文件缺少列: {missing}。当前列: {list(df.columns)}。"
            "请使用 kinematics 产出的 *_particle_kinematics.csv。"
        )
    return df


def compute_speed_angular_stats(df):
    """基于运动学 DataFrame 计算速度与角速度的统计量（含相关系数）。"""
    valid = df[(df["speed"].notna()) & (df["angular_velocity"].notna()) & (df["speed"] >= 0)].copy()
    if len(valid) == 0:
        return {}
    speed = valid["speed"]
    ang = valid["angular_velocity"]
    corr = np.corrcoef(speed, ang)[0, 1] if len(valid) > 1 else np.nan
    return {
        "n_points": len(valid),
        "n_tracks": int(valid["idx"].nunique()),
        "speed_mean": float(speed.mean()),
        "speed_std": float(speed.std()),
        "speed_max": float(speed.max()),
        "angular_velocity_mean_abs": float(ang.abs().mean()),
        "angular_velocity_std": float(ang.std()),
        "angular_velocity_max_abs": float(ang.abs().max()),
        "correlation_speed_angular": float(corr) if not np.isnan(corr) else None,
    }


def analyze_tracks(
    csv_path,
    output_dir=None,
    output_prefix: str = "",
    min_points=100,
    max_speed=None,
    max_angular_velocity=None,
):
    """
    基于颗粒运动学结果文件：读取、过滤，可选保存过滤后 CSV。
    csv_path: *_particle_kinematics.csv
    返回: (df_filtered, removed_tracks).
    """
    logger.info(f"读取运动学结果: {csv_path}")
    df = load_kinematics(csv_path)
    logger.info(f"原始: {len(df)} 条记录, {df['idx'].nunique()} 条轨迹")
    df, removed_tracks = filter_tracks(
        df,
        min_points=min_points,
        max_speed=max_speed,
        max_angular_velocity=max_angular_velocity,
    )
    if output_dir is not None:
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        base = output_base_name(csv_path, from_trajectory_csv=True)
        prefix = output_prefix or ""
        out_csv = output_dir / f"{prefix}{base}_analyzed.csv"
        df.to_csv(out_csv, index=False, float_format="%.6f")
        logger.info(f"过滤后结果已保存: {out_csv}")
    return df, removed_tracks


def plot_scatter(df, output_path=None):
    """速度 vs 角速度 散点图。"""
    plot_df = df[
        (df["speed"].notna()) & (df["angular_velocity"].notna()) & (df["speed"] > 0)
    ].copy()
    if len(plot_df) == 0:
        logger.warning("无有效数据可绘制散点图")
        return
    plt.figure(figsize=(10, 8))
    plt.scatter(
        plot_df["speed"],
        plot_df["angular_velocity"],
        alpha=0.5,
        s=10,
        edgecolors="none",
    )
    plt.xlabel("速度 (像素/秒)", fontsize=12)
    plt.ylabel("角速度 (弧度/秒)", fontsize=12)
    plt.title("角速度 vs 速度", fontsize=14, fontweight="bold")
    plt.grid(True, alpha=0.3)
    stats = compute_speed_angular_stats(plot_df)
    txt = f"点数: {stats.get('n_points', 0)}\n"
    txt += f"速度均值: {stats.get('speed_mean', 0):.2f} px/s\n"
    txt += f"角速度均值(|·|): {stats.get('angular_velocity_mean_abs', 0):.2f} rad/s\n"
    if stats.get("correlation_speed_angular") is not None:
        txt += f"相关系数: {stats['correlation_speed_angular']:.3f}"
    plt.text(
        0.05,
        0.95,
        txt,
        transform=plt.gca().transAxes,
        verticalalignment="top",
        bbox=dict(boxstyle="round", facecolor="wheat", alpha=0.5),
    )
    plt.tight_layout()
    if output_path:
        plt.savefig(output_path, dpi=300, bbox_inches="tight")
        logger.info(f"散点图已保存: {output_path}")
    else:
        plt.show()
    plt.close()


def plot_heatmap(df, output_path=None, bins=50):
    """速度 vs 角速度 hexbin 热力图。"""
    plot_df = df[
        (df["speed"].notna()) & (df["angular_velocity"].notna()) & (df["speed"] > 0)
    ].copy()
    if len(plot_df) == 0:
        logger.warning("无有效数据可绘制热力图")
        return
    plt.figure(figsize=(10, 8))
    hb = plt.hexbin(
        plot_df["speed"],
        plot_df["angular_velocity"],
        gridsize=bins,
        cmap="YlOrRd",
        mincnt=1,
    )
    plt.colorbar(hb, label="密度")
    plt.xlabel("速度 (像素/秒)", fontsize=12)
    plt.ylabel("角速度 (弧度/秒)", fontsize=12)
    plt.title("角速度 vs 速度 热力图", fontsize=14, fontweight="bold")
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    if output_path:
        plt.savefig(output_path, dpi=300, bbox_inches="tight")
        logger.info(f"热力图已保存: {output_path}")
    else:
        plt.show()
    plt.close()


def plot_heatmap_2dhist(df, output_path=None, bins=50):
    """速度 vs 角速度 2D 直方图热力图。"""
    plot_df = df[
        (df["speed"].notna()) & (df["angular_velocity"].notna()) & (df["speed"] > 0)
    ].copy()
    if len(plot_df) == 0:
        logger.warning("无有效数据可绘制 2D 直方图")
        return
    plt.figure(figsize=(10, 8))
    h = plt.hist2d(
        plot_df["speed"],
        plot_df["angular_velocity"],
        bins=bins,
        cmap="YlOrRd",
    )
    plt.colorbar(h[3], label="数量")
    plt.xlabel("速度 (像素/秒)", fontsize=12)
    plt.ylabel("角速度 (弧度/秒)", fontsize=12)
    plt.title("角速度 vs 速度 2D 直方图", fontsize=14, fontweight="bold")
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    if output_path:
        plt.savefig(output_path, dpi=300, bbox_inches="tight")
        logger.info(f"2D 直方图已保存: {output_path}")
    else:
        plt.show()
    plt.close()


def analyze_and_visualize(
    csv_path,
    output_dir=None,
    output_prefix: str = "",
    min_points=100,
    max_speed=None,
    max_angular_velocity=None,
    heatmap_bins=50,
):
    """
    基于颗粒运动学结果文件：读取、过滤、保存过滤后 CSV、绘制速度-角速度散点图与热力图。
    csv_path: *_particle_kinematics.csv
    返回: (df_filtered, removed_tracks).
    """
    output_dir = Path(output_dir) if output_dir else Path(csv_path).parent
    output_dir.mkdir(parents=True, exist_ok=True)
    df, removed_tracks = analyze_tracks(
        csv_path,
        output_dir=output_dir,
        output_prefix=output_prefix,
        min_points=min_points,
        max_speed=max_speed,
        max_angular_velocity=max_angular_velocity,
    )
    base = output_base_name(csv_path, from_trajectory_csv=True)
    prefix = output_prefix or ""

    scatter_path = output_dir / f"{prefix}{base}_scatter.png"
    plot_scatter(df, scatter_path)
    heatmap_path = output_dir / f"{prefix}{base}_heatmap_hexbin.png"
    plot_heatmap(df, heatmap_path, bins=heatmap_bins)
    heatmap2d_path = output_dir / f"{prefix}{base}_heatmap_2dhist.png"
    plot_heatmap_2dhist(df, heatmap2d_path, bins=heatmap_bins)

    logger.info("速度-角速度统计与可视化完成")
    return df, removed_tracks


# ---------- Task：基于运动学结果文件的统计分析 ----------


class TrajectoryDataTask(BaseTask):
    """
    轨迹数据分析任务：基于颗粒运动学结果文件（*_particle_kinematics.csv），
    过滤后统计速度与角速度关系并生成散点图、热力图。
    """

    task_name = "data_analysis"

    def __init__(
        self,
        csv_path: str,
        output_dir=None,
        output_prefix: str = "",
        *,
        min_points=100,
        max_speed=None,
        max_angular_velocity=None,
        heatmap_bins=50,
        **kwargs,
    ):
        output_dir_path = Path(output_dir) if output_dir else None
        super().__init__(output_dir_path, output_prefix=output_prefix)
        self.csv_path = Path(csv_path)
        self.min_points = min_points
        self.max_speed = max_speed
        self.max_angular_velocity = max_angular_velocity
        self.heatmap_bins = heatmap_bins
        self.output_csv = None

    def validate_inputs(self) -> bool:
        if not self.csv_path.exists():
            logger.error(f"运动学结果文件不存在: {self.csv_path}")
            return False
        return True

    def get_output_paths(self):
        base = output_base_name(self.csv_path, from_trajectory_csv=True)
        prefix = self.output_prefix or ""
        return {
            "analyzed_csv": self.output_dir / f"{prefix}{base}_analyzed.csv",
            "scatter": self.output_dir / f"{prefix}{base}_scatter.png",
            "heatmap_hexbin": self.output_dir / f"{prefix}{base}_heatmap_hexbin.png",
            "heatmap_2dhist": self.output_dir / f"{prefix}{base}_heatmap_2dhist.png",
        }

    def get_task_inputs(self):
        return {
            "csv_path": str(self.csv_path),
            "min_points": self.min_points,
            "max_speed": self.max_speed,
            "max_angular_velocity": self.max_angular_velocity,
            "heatmap_bins": self.heatmap_bins,
        }

    def get_task_results(self):
        if not self.results:
            return None
        df = self.results.get("df")
        removed = self.results.get("removed_tracks", [])
        if df is None:
            return {"removed_tracks_count": len(removed)}
        return {
            "data_points": len(df),
            "tracks": int(df["idx"].nunique()) if len(df) > 0 else 0,
            "removed_tracks_count": len(removed),
        }

    def apply_output_paths(self, paths):
        self.output_csv = paths.get("analyzed_csv")

    def get_skip_return_value(self, record):
        return (None, [])

    def _run(self, **kwargs):
        params = {
            "min_points": self.min_points,
            "max_speed": self.max_speed,
            "max_angular_velocity": self.max_angular_velocity,
            "heatmap_bins": self.heatmap_bins,
        }
        params.update(kwargs)
        self.print_info(
            Input_CSV=str(self.csv_path),
            Output_Directory=str(self.output_dir),
        )
        df, removed_tracks = analyze_and_visualize(
            str(self.csv_path),
            output_dir=str(self.output_dir),
            output_prefix=self.output_prefix,
            **params,
        )
        self.results = {"df": df, "removed_tracks": removed_tracks}
        return df, removed_tracks

    def print_summary(self):
        df = None
        if self.output_csv and Path(self.output_csv).exists():
            try:
                df = pd.read_csv(self.output_csv)
            except (OSError, Exception):
                pass
        if df is None and self.results and self.results.get("df") is not None:
            df = self.results["df"]
        if df is None or len(df) == 0:
            return
        removed_tracks = self.results.get("removed_tracks", []) if self.results else []

        logger.info("=" * 60)
        logger.info("Speed vs Angular Velocity Analysis Summary")
        logger.info("=" * 60)
        logger.info(f"Data Points: {len(df)}, Tracks: {df['idx'].nunique()}")
        if removed_tracks:
            logger.info(f"Filtered Tracks: {len(removed_tracks)}")

        if "speed" not in df.columns or "angular_velocity" not in df.columns:
            logger.warning("Missing speed/angular_velocity columns")
            logger.info("=" * 60)
            return

        stats = compute_speed_angular_stats(df)
        logger.info(
            "Speed: mean=%.4f px/s, std=%.4f, max=%.4f"
            % (stats.get("speed_mean", 0), stats.get("speed_std", 0), stats.get("speed_max", 0))
        )
        logger.info(
            "Angular velocity (|·|): mean=%.4f rad/s, max=%.4f"
            % (stats.get("angular_velocity_mean_abs", 0), stats.get("angular_velocity_max_abs", 0))
        )
        if stats.get("correlation_speed_angular") is not None:
            logger.info(
                "Correlation(speed, angular_velocity): %.4f" % stats["correlation_speed_angular"]
            )
        logger.info("=" * 60)
