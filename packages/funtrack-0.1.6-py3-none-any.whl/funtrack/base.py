"""
任务基类模块
定义统一的任务接口，执行后将入参、结果、时间、输出路径等写入 output_dir/.task/<task_name>.json
输出文件命名约定：统一为「原视频文件名（base）+ 后缀」，轨迹 CSV 为 {base}_tracks.csv，
后续分析输出为 {base}_analyzed.csv、{base}_scatter.png 等。
"""

import json
from abc import ABC, abstractmethod
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

from nltlog import getLogger

logger = getLogger("funtrack")


def output_base_name(path, from_trajectory_csv: bool = False) -> str:
    """
    从文件路径得到输出文件名基名（无扩展名）。
    约定：轨迹 CSV 为 {video_stem}_tracks.csv，运动学 CSV 为 {video_stem}_particle_kinematics.csv，
    由该类路径推导基名时去掉对应后缀得到原视频基名。

    参数:
        path: 文件路径（视频、轨迹 CSV 或运动学 CSV）
        from_trajectory_csv: 若为 True，且 stem 以 _tracks 或 _particle_kinematics 结尾，则去掉后缀得到原视频基名
    返回:
        用于拼接输出文件名的基名，如 "demo"
    """
    stem = Path(path).stem
    if from_trajectory_csv:
        if stem.endswith("_tracks"):
            return stem[: -len("_tracks")]
        if stem.endswith("_particle_kinematics"):
            return stem[: -len("_particle_kinematics")]
    return stem


class BaseTask(ABC):
    """任务基类：执行后自动将入参、结果、开始/结束时间、运行时间、输出路径写入 .task/<task_name>.json"""

    task_name: str = "task"

    def __init__(self, output_dir: Optional[Path] = None, output_prefix: str = ""):
        """
        初始化任务

        参数:
            output_dir: 输出目录，如果为None则使用默认目录
            output_prefix: 输出文件前缀，例如 "step01-"，默认为空字符串
        """
        self.output_dir = output_dir or Path("output")
        self.output_dir.mkdir(exist_ok=True, parents=True)
        self.output_prefix = output_prefix
        self.results = None

    @abstractmethod
    def validate_inputs(self) -> bool:
        """
        验证输入数据

        返回:
            bool: 输入是否有效
        """
        pass

    def run(self, overwrite: bool = False, **kwargs) -> Any:
        """
        执行任务（带异常处理与 overwrite 逻辑）。
        若 overwrite=False 且 .task/<task_name>.json 存在且其中记录的输出文件均存在，则跳过执行；
        否则校验输入、调用子类 _run()，并将执行记录写入 .task/<task_name>.json。

        参数:
            overwrite: 为 True 时强制重新执行，不检查 .task 与输出文件
            **kwargs: 任务参数，传给子类 _run()

        返回:
            任务结果；跳过或异常时返回子类 get_skip_return_value(record) 或 None
        """
        if not self.validate_inputs():
            return None
        task_name = getattr(self.__class__, "task_name", self.__class__.__name__)
        task_dir = self.output_dir / ".task"
        task_json_path = task_dir / f"{task_name}.json"

        if not overwrite and task_json_path.exists():
            try:
                with open(task_json_path, encoding="utf-8") as f:
                    record = json.load(f)
                output_paths = record.get("output_paths") or {}
                if output_paths and all(Path(p).exists() for p in output_paths.values()):
                    self.results = self._results_from_skip_record(record)
                    self.apply_output_paths(self.get_output_paths())
                    return self.get_skip_return_value(record)
            except (json.JSONDecodeError, OSError) as e:
                logger.warning(f"读取任务记录失败，将重新执行: {e}")
        start_dt = datetime.now()
        try:
            ret = self._run(**kwargs)
        except Exception as e:
            logger.error(f"任务执行异常: {e}", exc_info=True)
            return None
        end_dt = datetime.now()
        duration_sec = (end_dt - start_dt).total_seconds()
        task_dir.mkdir(exist_ok=True)
        paths = self.get_output_paths()
        output_paths = {k: str(p) for k, p in paths.items()}
        record = {
            "task": task_name,
            "start_time": start_dt.isoformat(),
            "end_time": end_dt.isoformat(),
            "duration_sec": round(duration_sec, 2),
            "inputs": self.get_task_inputs(),
            "output_paths": output_paths,
            "results": self.get_task_results() or {},
        }
        with open(task_json_path, "w", encoding="utf-8") as f:
            json.dump(record, f, ensure_ascii=False, indent=2)
        return ret

    @abstractmethod
    def _run(self, **kwargs) -> Any:
        """子类实现：实际执行逻辑。"""
        pass

    @abstractmethod
    def get_output_paths(self) -> Dict[str, Path]:
        """获取本任务输出文件路径字典。"""
        pass

    def get_task_inputs(self) -> Dict[str, Any]:
        """子类可覆盖：返回可序列化的入参摘要，用于写入 .task JSON。默认空 dict。"""
        return {}

    def get_task_results(self) -> Optional[Dict[str, Any]]:
        """子类可覆盖：返回可序列化的结果摘要，用于写入 .task JSON。默认 None。"""
        return None

    def apply_output_paths(self, paths: Dict[str, Path]) -> None:
        """子类可覆盖：根据输出路径字典设置 self.output_* 等属性，用于跳过执行时仍能提供输出路径。默认无操作。"""
        pass

    def _results_from_skip_record(self, record: Dict[str, Any]) -> Dict[str, Any]:
        """子类可覆盖：根据 .task 记录构造跳过时的 self.results，供 print_summary 等使用。默认返回 record['results']。"""
        return record.get("results") or {}

    def get_skip_return_value(self, record: Dict[str, Any]) -> Any:
        """子类可覆盖：跳过执行时 run() 的返回值，由 .task JSON 中的 record 提供。默认 None。"""
        return None

    def print_summary(self):
        """打印任务摘要（可选实现）"""
        pass

    def print_info(self, **kwargs):
        """打印信息"""
        for key, value in kwargs.items():
            logger.info(f"{key}: {value}")
        logger.info("=" * 60)
