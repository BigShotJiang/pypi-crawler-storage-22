"""
轨迹圆形区域分析模块
在指定时刻，以某个颗粒的速度方向为方向，前方指定距离为圆心画圆，
分析所有进入该圆形区域的轨迹段
"""

import random
from pathlib import Path

import numpy as np
import pandas as pd
from nltlog import getLogger
from tqdm import tqdm

from funtrack.base import BaseTask, output_base_name

logger = getLogger("funtrack")


def calculate_angle(x1, y1, x2, y2):
    """
    计算从点1到点2的角度（弧度，0-2π）

    参数:
        x1, y1: 起点坐标
        x2, y2: 终点坐标

    返回:
        angle: 角度（弧度）
    """
    dx = x2 - x1
    dy = y2 - y1
    angle = np.arctan2(dy, dx)
    # 转换为0-2π范围
    if angle < 0:
        angle += 2 * np.pi
    return angle


def calculate_speed(df_row, prev_row):
    """
    计算速度（像素/秒）

    参数:
        df_row: 当前行数据
        prev_row: 前一行数据

    返回:
        speed: 速度（像素/秒）
    """
    if prev_row is None:
        return 0.0

    dx = df_row["x"] - prev_row["x"]
    dy = df_row["y"] - prev_row["y"]
    dt = df_row["time"] - prev_row["time"]

    if dt <= 0:
        return 0.0

    speed = np.sqrt(dx**2 + dy**2) / dt
    return speed


def point_in_circle(x, y, center_x, center_y, radius):
    """
    判断点是否在圆内

    参数:
        x, y: 点坐标
        center_x, center_y: 圆心坐标
        radius: 半径

    返回:
        bool: 是否在圆内
    """
    dist = np.sqrt((x - center_x) ** 2 + (y - center_y) ** 2)
    return dist <= radius


def line_circle_intersection(x1, y1, x2, y2, center_x, center_y, radius):
    """
    计算线段与圆的交点

    参数:
        x1, y1: 线段起点坐标
        x2, y2: 线段终点坐标
        center_x, center_y: 圆心坐标
        radius: 圆的半径

    返回:
        tuple: (intersection_x, intersection_y, t) 或 None
            intersection_x, intersection_y: 交点坐标
            t: 交点在线段上的参数位置 (0-1之间)，用于按比例计算时间和帧数
            如果没有交点或交点不在线段上，返回None
    """
    # 线段方向向量
    dx = x2 - x1
    dy = y2 - y1

    # 起点到圆心的向量
    vx = x1 - center_x
    vy = y1 - center_y

    # 二次方程系数：a*t^2 + b*t + c = 0
    a = dx * dx + dy * dy
    b = 2 * (vx * dx + vy * dy)
    c = vx * vx + vy * vy - radius * radius

    # 判别式
    discriminant = b * b - 4 * a * c

    if discriminant < 0 or a == 0:
        # 无交点或线段长度为0
        return None

    sqrt_discriminant = np.sqrt(discriminant)

    # 两个可能的t值
    t1 = (-b - sqrt_discriminant) / (2 * a)
    t2 = (-b + sqrt_discriminant) / (2 * a)

    # 找到线段与圆的交点：取「出圆」的那个（0 < t <= 1 中较大的 t）
    # 这样从圆内/圆上到圆外时，得到的是离开圆边界的点
    valid_t = None
    for t in [t1, t2]:
        if 0 < t <= 1:
            # 取较大的 t，对应离开圆边界的出射点
            if valid_t is None or t > valid_t:
                valid_t = t

    if valid_t is None:
        return None

    # 计算交点坐标（保证在圆上）
    intersection_x = x1 + valid_t * dx
    intersection_y = y1 + valid_t * dy

    return intersection_x, intersection_y, valid_t


def analyze_circle_trajectories(
    csv_path, target_idx=None, circle_radius=50, output_path=None, target_frame=None
):
    """
    分析圆形区域的轨迹

    参数:
        csv_path: 颗粒运动学结果文件路径（*_particle_kinematics.csv，含 idx, frame, x, y 等）
        target_idx: 目标轨迹ID（用于确定方向和位置）
            - 单个整数：分析指定的轨迹
            - 列表：分析列表中的所有轨迹
            - None：分析所有轨迹
        circle_radius: 圆的半径（像素），同时也是圆心在速度方向前方的距离，默认50
        output_path: 输出文件路径（可选）
        target_frame: 目标时刻（帧号，可选）。如果为None，则遍历目标轨迹的所有帧

    返回:
        results_df: 分析结果DataFrame
    """
    logger.info(f"读取颗粒运动学结果: {csv_path}")
    df = pd.read_csv(csv_path)
    # 列名去空格/BOM，避免读入异常格式
    df.columns = df.columns.str.strip()
    # 运动学/轨迹表需含 idx, frame, x, y
    required = ["idx", "frame", "x", "y"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(
            f"颗粒运动学结果文件缺少列: {missing}，当前列: {list(df.columns)}。"
            "请重新运行颗粒运动学任务（overwrite=True 或删除旧文件）以生成包含 idx, frame, time, x, y 等列的结果文件。"
        )
    # 按轨迹ID和帧号排序
    df = df.sort_values(by=["idx", "frame"])

    # 确定要分析的目标轨迹ID列表
    if target_idx is None:
        # 分析所有轨迹
        target_indices = df["idx"].unique().tolist()
        logger.info(f"将分析所有 {len(target_indices)} 条轨迹")
    elif isinstance(target_idx, (list, tuple)):
        # 分析列表中的轨迹
        target_indices = list(target_idx)
        logger.info(f"将分析 {len(target_indices)} 条指定轨迹: {target_indices}")
    else:
        # 单个轨迹ID
        target_indices = [target_idx]
        logger.info(f"将分析轨迹 {target_idx}")

    # 验证目标轨迹是否存在
    available_indices = df["idx"].unique().tolist()
    missing_indices = [idx for idx in target_indices if idx not in available_indices]
    if missing_indices:
        logger.warning(f"以下轨迹ID不存在: {missing_indices}")
        target_indices = [idx for idx in target_indices if idx in available_indices]
        if len(target_indices) == 0:
            logger.error("没有可用的目标轨迹")
            return None

    # 分析所有轨迹，找出进入圆内的轨迹段
    all_results = []
    processed_segments = set()  # 用于去重：避免同一轨迹段被多次记录

    # 确定要分析的轨迹列表（如果指定了target_idx，只分析这些轨迹；否则分析所有轨迹）
    if target_idx is None:
        # 分析所有轨迹
        track_ids_to_analyze = df["idx"].unique().tolist()
    elif isinstance(target_idx, (list, tuple)):
        # 分析列表中的轨迹
        track_ids_to_analyze = [tid for tid in target_idx if tid in df["idx"].unique()]
    else:
        # 单个轨迹ID
        track_ids_to_analyze = [target_idx] if target_idx in df["idx"].unique() else []

    # 使用进度条遍历要分析的轨迹
    pbar = tqdm(
        track_ids_to_analyze,
        desc="分析轨迹",
        unit="轨迹",
        disable=len(track_ids_to_analyze) <= 1,
        miniters=1,
        mininterval=0.5,
        smoothing=0.1,
    )

    last_segment_count = 0
    for track_id in pbar:
        track = df[df["idx"] == track_id].copy()
        track = track.sort_values(by="frame")

        if len(track) < 2:
            # 轨迹数据点太少，无法计算速度方向，跳过
            continue

        # 更新进度条描述（只在段数变化时更新，减少抖动）
        if len(track_ids_to_analyze) > 1 and len(all_results) != last_segment_count:
            pbar.set_postfix({"当前轨迹": track_id, "已找到段数": len(all_results)})
            last_segment_count = len(all_results)

        # 遍历轨迹的每一帧，寻找可能的入射点
        # 对于每个点，基于该点的位置和速度方向计算圆
        for i in range(1, len(track)):
            enter_idx = track.index[i]
            enter_row = track.loc[enter_idx]
            enter_prev_idx = track.index[i - 1]
            enter_prev_row = track.loc[enter_prev_idx]

            # 计算入射点的速度方向（从进入点前一点到进入点，即运动方向）
            enter_dx = enter_row["x"] - enter_prev_row["x"]
            enter_dy = enter_row["y"] - enter_prev_row["y"]
            enter_dir_mag = np.sqrt(enter_dx**2 + enter_dy**2)

            if enter_dir_mag <= 0:
                # 位置没有变化，跳过
                continue

            # 归一化方向向量
            enter_dx /= enter_dir_mag
            enter_dy /= enter_dir_mag

            # 基于入射点位置和速度方向计算圆心
            # 圆心在入射点速度方向前方circle_radius处（向前找距离为R的点）
            enter_circle_center_x = enter_row["x"] + enter_dx * circle_radius
            enter_circle_center_y = enter_row["y"] + enter_dy * circle_radius

            # 验证入射点是否在圆上（应该正好在圆上，距离为circle_radius）
            dist_to_center = np.sqrt(
                (enter_row["x"] - enter_circle_center_x) ** 2
                + (enter_row["y"] - enter_circle_center_y) ** 2
            )
            # 允许小的数值误差（1像素）
            if abs(dist_to_center - circle_radius) > 1.0:
                continue

            # 检查该轨迹是否真的进入了这个圆
            # 检查进入点前一点是否在圆外，当前点（入射点）是否在圆上
            prev_dist = np.sqrt(
                (enter_prev_row["x"] - enter_circle_center_x) ** 2
                + (enter_prev_row["y"] - enter_circle_center_y) ** 2
            )
            curr_dist = np.sqrt(
                (enter_row["x"] - enter_circle_center_x) ** 2
                + (enter_row["y"] - enter_circle_center_y) ** 2
            )

            # 前一点应该在圆外（距离 > radius），当前点应该在圆上（距离 ≈ radius）
            # 允许小的数值误差
            if prev_dist <= circle_radius + 1.0 or abs(curr_dist - circle_radius) > 1.0:
                continue

            # 找到对应的离开点
            # 如果第N帧在圆内，第N+1帧在圆外，计算线段与圆的交点作为出射点
            exit_idx = None
            exit_row = None
            exit_x = None
            exit_y = None
            exit_frame = None
            exit_time = None

            for j in range(i + 1, len(track)):
                exit_candidate_idx = track.index[j]
                exit_candidate_row = track.loc[exit_candidate_idx]
                exit_candidate_dist = np.sqrt(
                    (exit_candidate_row["x"] - enter_circle_center_x) ** 2
                    + (exit_candidate_row["y"] - enter_circle_center_y) ** 2
                )

                if exit_candidate_dist > circle_radius:
                    # 找到第一个在圆外的点，用「最后在圆内/圆上的点」到「该点」的线段与圆求交点
                    # 这样出射点一定在圆上
                    if j > i + 1:
                        prev_candidate_idx = track.index[j - 1]
                        prev_candidate_row = track.loc[prev_candidate_idx]
                        seg_x1, seg_y1 = prev_candidate_row["x"], prev_candidate_row["y"]
                    else:
                        # 前一个点就是入射点（在圆上），线段从入射点到当前圆外点
                        prev_candidate_idx = enter_idx
                        prev_candidate_row = enter_row
                        seg_x1, seg_y1 = enter_row["x"], enter_row["y"]

                    intersection = line_circle_intersection(
                        seg_x1,
                        seg_y1,
                        exit_candidate_row["x"],
                        exit_candidate_row["y"],
                        enter_circle_center_x,
                        enter_circle_center_y,
                        circle_radius,
                    )

                    if intersection is not None:
                        exit_x, exit_y, t = intersection
                        prev_frame = prev_candidate_row["frame"]
                        next_frame = exit_candidate_row["frame"]
                        prev_time = prev_candidate_row["time"]
                        next_time = exit_candidate_row["time"]

                        exit_frame = prev_frame + t * (next_frame - prev_frame)
                        exit_time = prev_time + t * (next_time - prev_time)

                        exit_idx = prev_candidate_idx
                        exit_row = prev_candidate_row.copy()
                        exit_row["x"] = exit_x
                        exit_row["y"] = exit_y
                        exit_row["frame"] = exit_frame
                        exit_row["time"] = exit_time
                        break
                    else:
                        # 数值上无解时退化为用圆外点（不应常见）
                        exit_idx = exit_candidate_idx
                        exit_row = exit_candidate_row
                        exit_x = exit_candidate_row["x"]
                        exit_y = exit_candidate_row["y"]
                        exit_frame = exit_candidate_row["frame"]
                        exit_time = exit_candidate_row["time"]
                        break

            if exit_idx is None or exit_row is None:
                # 如果没有离开点（最终颗粒都没有出这个圆），跳过
                continue

            # 使用 (track_id, enter_frame, exit_frame) 作为唯一标识去重
            # 注意：exit_frame可能是小数，需要四舍五入或使用字符串表示
            segment_key = (track_id, enter_row["frame"], round(exit_frame, 4))

            # 如果这个轨迹段已经被处理过，跳过
            if segment_key in processed_segments:
                continue
            processed_segments.add(segment_key)

            # 计算起点速度
            enter_speed = calculate_speed(enter_row, enter_prev_row)

            # 确定出射点的最终坐标、帧数和时间
            # 如果出射点是交点，使用计算出的值；否则使用实际轨迹点的值
            is_intersection = (
                exit_x is not None
                and exit_y is not None
                and exit_frame is not None
                and exit_time is not None
            )

            if is_intersection:
                exit_x_final = exit_x
                exit_y_final = exit_y
                exit_frame_final = exit_frame
                exit_time_final = exit_time
            else:
                exit_x_final = exit_row["x"]
                exit_y_final = exit_row["y"]
                exit_frame_final = exit_row["frame"]
                exit_time_final = exit_row["time"]

            # 计算终点速度
            # 如果出射点是交点，使用出射点前后的点来计算速度
            exit_next_idx = (
                track.index[track.index.get_loc(exit_idx) + 1]
                if track.index.get_loc(exit_idx) < len(track) - 1
                else None
            )
            exit_next_row = track.loc[exit_next_idx] if exit_next_idx is not None else None

            if is_intersection and exit_next_row is not None:
                # 出射点是交点，使用出射点和下一个点计算速度
                exit_speed = calculate_speed(exit_next_row, exit_row)
            elif exit_next_row is not None:
                # 出射点是实际轨迹点，使用后一点计算速度
                exit_speed = calculate_speed(exit_next_row, exit_row)
            else:
                exit_speed = 0.0

            # 计算进入时的运动方向（入射角）
            enter_motion_angle = calculate_angle(
                enter_prev_row["x"], enter_prev_row["y"], enter_row["x"], enter_row["y"]
            )

            # 计算离开时的运动方向（出射角）
            if is_intersection:
                # 出射点是交点，使用出射点和下一个点计算方向
                if exit_next_row is not None:
                    exit_motion_angle = calculate_angle(
                        exit_x_final, exit_y_final, exit_next_row["x"], exit_next_row["y"]
                    )
                else:
                    # 如果没有后一点，使用离开点和圆心的方向
                    exit_motion_angle = calculate_angle(
                        exit_x_final, exit_y_final, enter_circle_center_x, enter_circle_center_y
                    )
            else:
                # 出射点是实际轨迹点
                if exit_next_row is not None:
                    exit_motion_angle = calculate_angle(
                        exit_row["x"], exit_row["y"], exit_next_row["x"], exit_next_row["y"]
                    )
                else:
                    # 如果没有后一点，使用离开点和圆心的方向
                    exit_motion_angle = calculate_angle(
                        exit_row["x"], exit_row["y"], enter_circle_center_x, enter_circle_center_y
                    )

            # 计算从圆心指向进入点和离开点的角度（用于参考）
            enter_angle_from_center = calculate_angle(
                enter_circle_center_x, enter_circle_center_y, enter_row["x"], enter_row["y"]
            )
            exit_angle_from_center = calculate_angle(
                enter_circle_center_x, enter_circle_center_y, exit_x_final, exit_y_final
            )

            # 保存结果
            result = {
                "trajectory_id": track_id,
                "circle_center_x": enter_circle_center_x,  # 使用基于入射点计算的圆心
                "circle_center_y": enter_circle_center_y,  # 使用基于入射点计算的圆心
                "circle_radius": circle_radius,
                # 起点信息
                "enter_frame": enter_row["frame"],
                "enter_time": enter_row["time"],
                "enter_x": enter_row["x"],
                "enter_y": enter_row["y"],
                "enter_speed": enter_speed,
                "enter_angle": enter_motion_angle,  # 进入时的运动方向（入射角）
                "enter_angle_from_center": enter_angle_from_center,  # 从圆心指向进入点的角度
                # 终点信息（使用实际的出射点坐标，可能是交点）
                "exit_frame": exit_frame_final,
                "exit_time": exit_time_final,
                "exit_x": exit_x_final,
                "exit_y": exit_y_final,
                "exit_speed": exit_speed,
                "exit_angle": exit_motion_angle,  # 离开时的运动方向（出射角）
                "exit_angle_from_center": exit_angle_from_center,  # 从圆心指向离开点的角度
            }
            all_results.append(result)

    # 关闭进度条
    if len(target_indices) > 1:
        pbar.close()

    if len(all_results) == 0:
        logger.warning("未找到进入圆形区域的轨迹")
        return None

    results_df = pd.DataFrame(all_results)

    # 保存结果
    if output_path:
        results_df.to_csv(output_path, index=False, float_format="%.4f")
        logger.success(f"分析结果已保存到: {output_path} (共 {len(results_df)} 条记录)")

    logger.info(f"找到 {len(results_df)} 条进入圆形区域的轨迹段（去重后）")
    logger.info(f"分析了 {len(track_ids_to_analyze)} 条轨迹")

    return results_df


def plot_trajectory_segment(csv_path, result_row, output_path=None):
    """
    根据分析结果绘制单条轨迹段

    参数:
        csv_path: 颗粒运动学结果文件路径（或含 idx, frame, x, y 的轨迹文件）
        result_row: 分析结果的一行（Series或dict）
        output_path: 输出图片路径（可选）
    """
    import matplotlib.pyplot as plt

    # 读取轨迹数据
    df = pd.read_csv(csv_path)

    track_id = result_row["trajectory_id"]
    enter_frame = result_row["enter_frame"]
    exit_frame = result_row["exit_frame"]
    circle_center_x = result_row["circle_center_x"]
    circle_center_y = result_row["circle_center_y"]
    circle_radius = result_row["circle_radius"]

    # 该轨迹在进入和离开之间的点（左图用）
    track = df[
        (df["idx"] == track_id) & (df["frame"] >= enter_frame) & (df["frame"] <= exit_frame)
    ].copy()
    track = track.sort_values(by="frame")

    if len(track) == 0:
        logger.warning(f"未找到轨迹 {track_id} 在帧 {enter_frame}-{exit_frame} 的数据")
        return

    # 该颗粒在原图尺寸下的完整轨迹（右图用）
    full_track = df[df["idx"] == track_id].copy()
    full_track = full_track.sort_values(by="frame")

    # 左右两个子图
    fig, (ax_left, ax_right) = plt.subplots(1, 2, figsize=(16, 8))

    # ========== 左图：轨迹段 + 圆 ==========
    ax_left.plot(track["x"], track["y"], "b-", linewidth=2, label="Trajectory")
    enter_x_plot = result_row["enter_x"]
    enter_y_plot = result_row["enter_y"]
    ax_left.plot(enter_x_plot, enter_y_plot, "go", markersize=10, label="Enter Point")
    exit_x_plot = result_row["exit_x"]
    exit_y_plot = result_row["exit_y"]
    ax_left.plot(exit_x_plot, exit_y_plot, "ro", markersize=10, label="Exit Point")
    if len(track) > 0:
        last_x, last_y = track["x"].iloc[-1], track["y"].iloc[-1]
        if abs(last_x - exit_x_plot) > 1e-6 or abs(last_y - exit_y_plot) > 1e-6:
            ax_left.plot([last_x, exit_x_plot], [last_y, exit_y_plot], "b-", linewidth=2)

    circle_left = plt.Circle(
        (circle_center_x, circle_center_y),
        circle_radius,
        fill=False,
        color="r",
        linestyle="--",
        linewidth=2,
        label="Circle Region",
    )
    ax_left.add_patch(circle_left)
    ax_left.plot(circle_center_x, circle_center_y, "r*", markersize=15, label="Circle Center")

    enter_x = result_row["enter_x"]
    enter_y = result_row["enter_y"]
    arrow_length = circle_radius * 0.8
    dx = circle_center_x - enter_x
    dy = circle_center_y - enter_y
    arrow_mag = np.sqrt(dx**2 + dy**2)
    if arrow_mag > 0:
        dx = dx / arrow_mag * arrow_length
        dy = dy / arrow_mag * arrow_length
        ax_left.arrow(
            enter_x,
            enter_y,
            dx,
            dy,
            head_width=5,
            head_length=5,
            fc="orange",
            ec="orange",
            label="Velocity Direction",
        )

    ax_left.set_xlabel("X (pixels)", fontsize=12)
    ax_left.set_ylabel("Y (pixels)", fontsize=12)
    ax_left.set_title(f"Segment (Frame {enter_frame}-{exit_frame})", fontsize=14)
    ax_left.legend()
    ax_left.grid(True, alpha=0.3)
    ax_left.set_aspect("equal")

    # ========== 右图：原图尺寸下该颗粒的完整轨迹 + 同一个圆 ==========
    ax_right.plot(
        full_track["x"], full_track["y"], "b-", linewidth=1.5, alpha=0.8, label="Full Trajectory"
    )
    # 标出本段的入射、出射点
    ax_right.plot(enter_x_plot, enter_y_plot, "go", markersize=8, label="Enter")
    ax_right.plot(exit_x_plot, exit_y_plot, "ro", markersize=8, label="Exit")

    circle_right = plt.Circle(
        (circle_center_x, circle_center_y),
        circle_radius,
        fill=False,
        color="r",
        linestyle="--",
        linewidth=2,
        label="Circle",
    )
    ax_right.add_patch(circle_right)
    ax_right.plot(circle_center_x, circle_center_y, "r*", markersize=12)

    ax_right.set_xlabel("X (pixels)", fontsize=12)
    ax_right.set_ylabel("Y (pixels)", fontsize=12)
    ax_right.set_title(f"Full Trajectory (ID {track_id})", fontsize=14)
    ax_right.legend()
    ax_right.grid(True, alpha=0.3)
    ax_right.set_aspect("equal")

    plt.tight_layout()
    if output_path:
        plt.savefig(output_path, dpi=300, bbox_inches="tight")
    else:
        plt.show()
    plt.close()


class CircleRegionTask(BaseTask):
    """圆形区域分析任务：分析进入指定圆形区域的轨迹段。输入为颗粒运动学结果文件。"""

    task_name = "circle"

    def __init__(
        self,
        csv_path: str,
        target_idx=None,
        circle_radius: float = 50,
        output_dir=None,
        target_frame=None,
        output_prefix: str = "",
    ):
        """
        初始化圆形区域分析任务

        参数:
            csv_path: 颗粒运动学结果文件路径（*_particle_kinematics.csv，含 idx, frame, x, y 等）
            target_idx: 目标轨迹ID
                - 单个整数：分析指定的轨迹
                - 列表：分析列表中的所有轨迹
                - None：分析所有轨迹（默认）
            circle_radius: 圆的半径（像素），同时也是圆心在速度方向前方的距离
            output_dir: 输出目录
            target_frame: 目标时刻（帧号，可选）。如果为None，则遍历目标轨迹的所有帧
            output_prefix: 输出文件前缀，例如 "step01-"，默认为空字符串
        """
        from pathlib import Path

        # 调用基类初始化
        output_dir_path = Path(output_dir) if output_dir else None
        super().__init__(output_dir_path, output_prefix=output_prefix)

        self.csv_path = Path(csv_path)
        self.target_frame = target_frame
        self.target_idx = target_idx
        self.circle_radius = circle_radius
        self.output_csv = None

    def validate_inputs(self) -> bool:
        """验证输入运动学结果文件是否存在"""
        if not self.csv_path.exists():
            logger.error(f"颗粒运动学结果文件不存在: {self.csv_path}")
            return False
        return True

    def get_output_paths(self):
        """获取输出文件路径"""
        if self.target_frame is not None:
            frame_suffix = f"frame_{self.target_frame}"
        else:
            frame_suffix = "all_frames"

        # 生成目标轨迹ID的字符串表示
        if self.target_idx is None:
            idx_suffix = "all"
        elif isinstance(self.target_idx, (list, tuple)):
            idx_suffix = "_".join(map(str, self.target_idx))
        else:
            idx_suffix = str(self.target_idx)

        base = output_base_name(self.csv_path, from_trajectory_csv=True)
        prefix = self.output_prefix if self.output_prefix else ""
        return {
            "analysis_csv": self.output_dir
            / f"{prefix}{base}_circle_analysis_{frame_suffix}_idx_{idx_suffix}.csv",
            "plot_prefix": self.output_dir
            / f"{prefix}{base}_trajectory_segment_{frame_suffix}_idx_{idx_suffix}",
        }

    def get_task_inputs(self):
        return {
            "csv_path": str(self.csv_path),
            "target_idx": self.target_idx,
            "circle_radius": self.circle_radius,
            "target_frame": self.target_frame,
        }

    def get_task_results(self):
        if not self.results or "df" not in self.results:
            return None
        df = self.results["df"]
        return {"segments_count": len(df) if df is not None else 0}

    def apply_output_paths(self, paths):
        self.output_csv = paths.get("analysis_csv")

    def get_skip_return_value(self, record):
        return None

    def _run(self, plot_count: int = 50, **kwargs):
        """
        执行圆形区域分析（由 BaseTask.run 调用，已含输入校验与异常处理）

        参数:
            plot_count: 要绘制的轨迹段数量，默认10，随机选取
            **kwargs: 额外的分析参数

        返回:
            results_df: 分析结果DataFrame
        """
        paths = self.get_output_paths()
        self.output_csv = paths["analysis_csv"]

        # 打印信息
        frame_info = f"Frame {self.target_frame}" if self.target_frame is not None else "All frames"
        if self.target_idx is None:
            target_info = "All trajectories"
        elif isinstance(self.target_idx, (list, tuple)):
            target_info = f"Trajectories {self.target_idx}"
        else:
            target_info = f"Trajectory {self.target_idx}"

        self.print_info(
            Input_CSV=str(self.csv_path),
            Target_Frame=frame_info,
            Target_Trajectory_ID=target_info,
            Circle_Radius=f"{self.circle_radius} pixels",
            Output_CSV=str(self.output_csv),
        )

        # 执行分析
        results_df = analyze_circle_trajectories(
            str(self.csv_path),
            self.target_idx,
            circle_radius=self.circle_radius,
            output_path=str(self.output_csv),
            target_frame=self.target_frame,
        )

        if results_df is not None and len(results_df) > 0:
            # 绘制轨迹段：随机选取 plot_count 条
            if plot_count > 0:
                n_plot = min(plot_count, len(results_df))
                indices = random.sample(range(len(results_df)), n_plot)
                for idx, i in enumerate(tqdm(indices, desc="轨迹段图", unit="张")):
                    plot_path = (
                        paths["plot_prefix"].parent / f"{paths['plot_prefix'].name}_{idx}.png"
                    )
                    plot_trajectory_segment(str(self.csv_path), results_df.iloc[i], str(plot_path))
                logger.success(f"轨迹段图已保存 {n_plot} 张至: {paths['plot_prefix'].parent}")

        self.results = {"df": results_df}
        return results_df

    def print_summary(self):
        """打印分析摘要；若结果已存在则从保存的 circle 分析 CSV 读取"""
        n_segments = None
        if self.output_csv and Path(self.output_csv).exists():
            try:
                results_df = pd.read_csv(self.output_csv)
                n_segments = len(results_df)
            except (OSError, Exception):
                pass
        if n_segments is None and self.results and self.results.get("df") is not None:
            n_segments = len(self.results["df"])
        if n_segments is not None:
            if n_segments > 0:
                logger.info(f"Analysis Complete! Found {n_segments} trajectory segments")
            else:
                logger.warning("No trajectory segments found in the circle region")
                logger.info("Try adjusting parameters:")
                logger.info("  - Different target trajectory ID")
                logger.info("  - Different target frame")
                logger.info("  - Larger circle radius or forward distance")
