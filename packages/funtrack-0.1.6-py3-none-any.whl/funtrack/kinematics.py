"""
颗粒运动学模块：由轨迹 CSV 生成「每颗粒每时刻」运动学基础表，供后续分析统一使用。

输出 CSV 列为规范基础字段，后续分析（轨迹数据分析、圆形区域分析等）均基于此文件。
"""

from pathlib import Path

import pandas as pd
from nltlog import getLogger

from funtrack.analyzer import (
    calculate_angle,
    calculate_angular_velocity,
    calculate_velocity,
    smooth_tracks,
)
from funtrack.base import BaseTask, output_base_name

logger = getLogger("funtrack")

# 运动学表规范列（供下游校验或文档）
KINEMATICS_COLUMNS = [
    "idx",
    "frame",
    "time",
    "x",
    "y",
    "angle",  # 朝向（弧度，0～2π）
    "cumulative_angle_rad",
    "speed",  # 速度大小（像素/秒，恒非负）
    "vx",
    "vy",
    "angular_velocity",  # 角速度（弧度/秒），正=逆时针、负=顺时针；需大小时用 .abs()
]


class ParticleKinematicsTask(BaseTask):
    """
    颗粒运动学任务：由轨迹 CSV 生成每颗粒每时刻的运动学基础表。
    输入为轨迹 CSV（frame, time, idx, x, y），输出为 {base}_particle_kinematics.csv。
    输出列见 KINEMATICS_COLUMNS，后续分析（TrajectoryDataTask、CircleRegionTask 等）均基于此文件。
    """

    task_name = "particle_kinematics"

    def __init__(
        self,
        csv_path: str,
        output_dir=None,
        output_prefix: str = "",
        *,
        smooth: bool = False,
        smooth_method: str = "moving_average",
        smooth_window: int = 5,
        smooth_alpha: float = 0.3,
        **kwargs,
    ):
        output_dir_path = Path(output_dir) if output_dir else None
        super().__init__(output_dir_path, output_prefix=output_prefix)
        self.csv_path = Path(csv_path)
        self.smooth = smooth
        self.smooth_method = smooth_method
        self.smooth_window = smooth_window
        self.smooth_alpha = smooth_alpha
        self.output_csv = None

    def validate_inputs(self) -> bool:
        if not self.csv_path.exists():
            logger.error(f"轨迹文件不存在: {self.csv_path}")
            return False
        return True

    def get_output_paths(self):
        base = output_base_name(self.csv_path, from_trajectory_csv=True)
        prefix = self.output_prefix if self.output_prefix else ""
        return {
            "kinematics_csv": self.output_dir / f"{prefix}{base}_particle_kinematics.csv",
        }

    def get_task_inputs(self):
        return {
            "csv_path": str(self.csv_path),
            "smooth": self.smooth,
            "smooth_method": self.smooth_method,
            "smooth_window": self.smooth_window,
            "smooth_alpha": self.smooth_alpha,
        }

    def get_task_results(self):
        if not self.results or self.results.get("df") is None:
            return None
        df = self.results["df"]
        return {
            "data_points": len(df),
            "tracks": int(df["idx"].nunique()) if len(df) > 0 else 0,
        }

    def apply_output_paths(self, paths):
        self.output_csv = paths.get("kinematics_csv")

    def _results_from_skip_record(self, record):
        return record.get("results") or {}

    def get_skip_return_value(self, record):
        if self.results and self.results.get("df") is not None:
            return self.results["df"]
        if self.output_csv and Path(self.output_csv).exists():
            try:
                return pd.read_csv(self.output_csv)
            except Exception:
                pass
        return None

    def _run(self, **kwargs):
        df = pd.read_csv(self.csv_path)
        for col in ["frame", "idx", "x", "y"]:
            if col not in df.columns:
                logger.error(f"轨迹 CSV 缺少列: {col}")
                return None
        if "time" not in df.columns:
            df["time"] = df["frame"]
        df = df.sort_values(by=["idx", "frame"])

        if self.smooth:
            df = smooth_tracks(
                df,
                method=self.smooth_method,
                window_size=self.smooth_window,
                alpha=self.smooth_alpha,
            )
        else:
            df["x_raw"] = df["x"].copy()
            df["y_raw"] = df["y"].copy()

        df = calculate_velocity(df)
        df = calculate_angle(df)
        df = calculate_angular_velocity(df)

        df["cumulative_angle_rad"] = df.groupby("idx")["dangle"].fillna(0).cumsum()

        out = df[["idx", "frame", "time", "x", "y"]].copy()
        out["angle"] = df["angle"].values  # 朝向（弧度，0～2π）
        out["cumulative_angle_rad"] = df["cumulative_angle_rad"].values
        out["speed"] = df["speed"].values
        out["vx"] = df["vx"].values
        out["vy"] = df["vy"].values
        out["angular_velocity"] = df["angular_velocity"].values

        paths = self.get_output_paths()
        out_path = paths["kinematics_csv"]
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out.to_csv(out_path, index=False, float_format="%.6f")
        logger.info(f"颗粒运动学已保存: {out_path}")

        self.results = {"df": out}
        return out

    def print_summary(self):
        df = None
        if self.output_csv and Path(self.output_csv).exists():
            try:
                df = pd.read_csv(self.output_csv)
            except (OSError, Exception):
                pass
        if df is None and self.results and self.results.get("df") is not None:
            df = self.results["df"]
        if df is None or len(df) == 0:
            return
        logger.info("=" * 60)
        logger.info(
            "Particle Kinematics Summary (坐标, 朝向/累积角, 速度/绝对值/vx/vy, 角速度/绝对值)"
        )
        logger.info("=" * 60)
        logger.info(f"Data points: {len(df)}, Tracks: {df['idx'].nunique()}")
        if "speed" in df.columns:
            logger.info(
                f"  Mean speed: {df['speed'].mean():.4f} px/s, Max: {df['speed'].max():.4f} px/s"
            )
        if "vx" in df.columns and "vy" in df.columns:
            logger.info(
                f"  vx range: [{df['vx'].min():.2f}, {df['vx'].max():.2f}], vy: [{df['vy'].min():.2f}, {df['vy'].max():.2f}]"
            )
        if "angular_velocity" in df.columns:
            logger.info(
                f"  Mean |angular_velocity|: {df['angular_velocity'].abs().mean():.4f} rad/s"
            )
        if "cumulative_angle_rad" in df.columns:
            logger.info(
                f"  Cumulative angle (rad) range: [{df['cumulative_angle_rad'].min():.2f}, {df['cumulative_angle_rad'].max():.2f}]"
            )
        logger.info("=" * 60)
