"""
大肠杆菌轨迹跟踪系统
使用计算机视觉技术检测和跟踪视频中每一帧的大肠杆菌

模糊视频优化建议：
- 开启帧预处理：preprocess_sharpen=True（锐化）、preprocess_denoise=True（去噪）、preprocess_clahe=True（对比度增强）
- 设 bg_learning_rate=0.001 等较小值，减缓背景更新，避免运动物体被吸收进背景
- 适当提高 bg_threshold，减少模糊带来的前景噪声；或略降低以保留弱目标
- 增大 max_age（如 15~20），允许轨迹在漏检几帧后仍可续接
- 适当增大 min_area，过滤模糊产生的碎斑
- 后处理已支持轨迹平滑（analyzer 中 smooth=True），可减轻位置抖动
"""

from pathlib import Path

import cv2
import numpy as np
import pandas as pd
from nltlog import getLogger
from tqdm import tqdm

from funtrack.base import BaseTask

logger = getLogger("funtrack")


class Track:
    """单个轨迹对象，包含位置、速度、面积等信息"""

    def __init__(self, track_id, x, y, area, frame_num):
        self.track_id = track_id
        self.frame_num = frame_num

        # 卡尔曼滤波器（用于预测位置和速度）
        self.kalman = cv2.KalmanFilter(4, 2)  # 4个状态（x, y, vx, vy），2个观测（x, y）
        self.kalman.measurementMatrix = np.array([[1, 0, 0, 0], [0, 1, 0, 0]], np.float32)
        self.kalman.transitionMatrix = np.array(
            [[1, 0, 1, 0], [0, 1, 0, 1], [0, 0, 1, 0], [0, 0, 0, 1]], np.float32
        )
        self.kalman.processNoiseCov = 0.03 * np.eye(4, dtype=np.float32)
        self.kalman.measurementNoiseCov = 0.1 * np.eye(2, dtype=np.float32)
        self.kalman.errorCovPost = np.eye(4, dtype=np.float32)

        # 初始化状态
        self.kalman.statePre = np.array([x, y, 0, 0], dtype=np.float32)
        self.kalman.statePost = np.array([x, y, 0, 0], dtype=np.float32)

        # 轨迹历史
        self.positions = [(frame_num, x, y)]
        self.areas = [area]

        # 轨迹特征
        self.avg_area = area
        self.age = 0
        self.hit_streak = 1  # 连续匹配次数
        self.time_since_update = 0

    def predict(self):
        """预测下一帧的位置"""
        prediction = self.kalman.predict()
        return prediction[0], prediction[1]

    def update(self, x, y, area, frame_num):
        """更新轨迹"""
        measurement = np.array([[x], [y]], dtype=np.float32)
        self.kalman.correct(measurement)

        self.positions.append((frame_num, x, y))
        self.areas.append(area)

        # 更新平均面积（使用指数移动平均）
        self.avg_area = 0.7 * self.avg_area + 0.3 * area

        self.age += 1
        self.hit_streak += 1
        self.time_since_update = 0
        self.frame_num = frame_num

    def get_velocity(self):
        """获取当前速度"""
        if len(self.positions) < 2:
            return 0, 0
        # 使用最近几帧计算速度
        recent = min(5, len(self.positions))
        if recent < 2:
            return 0, 0

        x1, y1 = self.positions[-recent][1], self.positions[-recent][2]
        x2, y2 = self.positions[-1][1], self.positions[-1][2]
        frames_diff = self.positions[-1][0] - self.positions[-recent][0]
        if frames_diff == 0:
            return 0, 0
        return (x2 - x1) / frames_diff, (y2 - y1) / frames_diff

    def get_position(self):
        """获取当前位置"""
        return self.positions[-1][1], self.positions[-1][2]


def _preprocess_frame(frame, sharpen=False, denoise=False, clahe=False):
    """
    可选帧预处理，用于模糊或低对比度视频。

    参数:
        frame: BGR 图像
        sharpen: 是否锐化（拉普拉斯）
        denoise: 是否轻度去噪（双边滤波，保边）
        clahe: 是否做 CLAHE 对比度增强（仅对亮度通道）
    返回:
        处理后的 BGR 图像
    """
    out = frame
    if denoise:
        out = cv2.bilateralFilter(out, d=5, sigmaColor=50, sigmaSpace=50)
    if sharpen:
        kernel = np.array([[-1, -1, -1], [-1, 9, -1], [-1, -1, -1]], dtype=np.float32)
        out = cv2.filter2D(out, -1, kernel)
        out = np.clip(out, 0, 255).astype(np.uint8)
    if clahe:
        lab = cv2.cvtColor(out, cv2.COLOR_BGR2LAB)
        l, a, b = cv2.split(lab)
        clahe_obj = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        l = clahe_obj.apply(l)
        out = cv2.merge([l, a, b])
        out = cv2.cvtColor(out, cv2.COLOR_LAB2BGR)
    return out


class BacteriaTracker:
    """大肠杆菌跟踪器"""

    def __init__(
        self,
        video_path,
        min_area=5,
        max_area=500,
        max_distance=50,
        area_weight=0.3,
        velocity_weight=0.2,
        trail_length=300,
        bg_history=500,
        bg_threshold=None,
        bg_learning_rate=None,
        debug=False,
        preprocess_sharpen=False,
        preprocess_denoise=False,
        preprocess_clahe=False,
        max_age=10,
    ):
        """
        初始化跟踪器

        参数:
            video_path: 视频文件路径
            min_area: 检测到的最小细菌面积（像素）
            max_area: 检测到的最大细菌面积（像素）
            max_distance: 帧间最大跟踪距离（像素）
            area_weight: 面积匹配权重
            velocity_weight: 速度匹配权重
            trail_length: 绘制历史轨迹的长度（帧数），默认300
            bg_history: 背景减除器历史帧数，默认500
            bg_threshold: 背景减除器阈值，如果为None则根据目标大小自动调整
            bg_learning_rate: 背景模型学习率，None 表示默认(-1)；模糊视频可设为较小值(如 0.001) 减缓背景更新
            debug: 是否启用调试模式，显示检测过程
            preprocess_sharpen: 是否对每帧锐化（模糊视频可设为 True）
            preprocess_denoise: 是否对每帧去噪（模糊视频可设为 True）
            preprocess_clahe: 是否对每帧做 CLAHE 对比度增强（模糊/暗视频可设为 True）
            max_age: 轨迹最大未匹配帧数，超过则不再视为活跃；模糊视频可适当增大（如 15）
        """
        self.video_path = video_path
        self.min_area = min_area
        self.max_area = max_area
        self.max_distance = max_distance
        self.area_weight = area_weight
        self.velocity_weight = velocity_weight
        self.trail_length = trail_length
        self.debug = debug
        self.preprocess_sharpen = preprocess_sharpen
        self.preprocess_denoise = preprocess_denoise
        self.preprocess_clahe = preprocess_clahe
        self.max_age = max_age
        self.bg_learning_rate = bg_learning_rate

        # 根据目标大小自动调整背景减除阈值（阈值越低越敏感，小目标需更敏感）
        if bg_threshold is None:
            if max_area > 2000:
                bg_threshold = 30  # 大目标
            elif max_area > 1000:
                bg_threshold = 40
            elif max_area > 200:
                bg_threshold = 50
            else:
                bg_threshold = 25  # 小目标（如大肠杆菌）用更低阈值，提高灵敏度

        # 背景减除器
        self.bg_subtractor = cv2.createBackgroundSubtractorMOG2(
            history=bg_history, varThreshold=bg_threshold, detectShadows=False
        )

        # 跟踪数据
        self.tracks = {}  # {track_id: Track对象}
        self.next_id = 0
        self.fps = None  # 视频帧率，在处理视频时设置

    def detect_bacteria(self, frame, fg_mask):
        """
        从前景掩码中检测细菌/草履虫等目标

        参数:
            frame: 当前帧
            fg_mask: 前景掩码

        返回:
            detections: [(x, y, area), ...] 检测到的目标中心点和面积
        """
        # 根据目标大小调整形态学操作核大小
        # 小目标（如大肠杆菌）用更小核，避免开运算把颗粒抹掉
        if self.max_area > 2000:
            kernel_size = 9
        elif self.max_area > 1000:
            kernel_size = 7
        elif self.max_area > 500:
            kernel_size = 5
        elif self.max_area > 100:
            kernel_size = 3
        else:
            kernel_size = 2  # 很小目标：核尽量小，保留小斑点（2x2 用矩形核）

        kernel_size = max(2, kernel_size)
        if kernel_size >= 3:
            kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (kernel_size, kernel_size))
        else:
            kernel = np.ones((2, 2), np.uint8)

        # 先闭运算连接断开的区域
        fg_mask = cv2.morphologyEx(fg_mask, cv2.MORPH_CLOSE, kernel)
        # 小目标（max_area<=100）不做开运算，避免把颗粒当噪声去掉
        if self.max_area > 100:
            fg_mask = cv2.morphologyEx(fg_mask, cv2.MORPH_OPEN, kernel)

        # 查找轮廓
        contours, _ = cv2.findContours(fg_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        detections = []
        all_areas = []
        for contour in contours:
            area = cv2.contourArea(contour)
            all_areas.append(area)
            if self.min_area <= area <= self.max_area:
                # 计算质心
                M = cv2.moments(contour)
                if M["m00"] != 0:
                    cx = int(M["m10"] / M["m00"])
                    cy = int(M["m01"] / M["m00"])
                    detections.append((cx, cy, area))

        # 调试信息
        if self.debug and len(all_areas) > 0:
            logger.debug(
                f"检测到 {len(contours)} 个轮廓, "
                f"面积范围: {min(all_areas):.0f}-{max(all_areas):.0f}, "
                f"有效检测: {len(detections)} (范围: {self.min_area}-{self.max_area})"
            )

        return detections

    def compute_cost_matrix(self, tracks, detections):
        """
        计算轨迹和检测之间的代价矩阵
        使用多特征匹配：位置、速度、面积

        参数:
            tracks: Track对象列表
            detections: [(x, y, area), ...]

        返回:
            cost_matrix: 代价矩阵，值越小表示匹配越好
        """
        n_tracks = len(tracks)
        n_detections = len(detections)
        cost_matrix = np.full((n_tracks, n_detections), np.inf)

        for i, track in enumerate(tracks):
            # 预测位置
            pred_x, pred_y = track.predict()
            track_x, track_y = track.get_position()
            vx, vy = track.get_velocity()

            for j, (det_x, det_y, det_area) in enumerate(detections):
                # 1. 位置距离（使用预测位置）
                pos_dist = np.sqrt((pred_x - det_x) ** 2 + (pred_y - det_y) ** 2)

                # 2. 速度一致性（如果轨迹有速度，检查方向是否一致）
                vel_score = 0
                if abs(vx) > 0.1 or abs(vy) > 0.1:  # 如果轨迹在移动
                    # 计算检测点相对于预测点的方向
                    dx = det_x - pred_x
                    dy = det_y - pred_y
                    # 计算速度方向一致性（点积）
                    vel_mag = np.sqrt(vx**2 + vy**2)
                    det_mag = np.sqrt(dx**2 + dy**2)
                    if det_mag > 0.1:
                        cos_angle = (vx * dx + vy * dy) / (vel_mag * det_mag)
                        # 如果方向相反，惩罚
                        if cos_angle < 0:
                            vel_score = 100  # 大惩罚
                        else:
                            vel_score = (1 - cos_angle) * 20  # 方向不一致的惩罚

                # 3. 面积相似性
                area_ratio = abs(track.avg_area - det_area) / max(track.avg_area, det_area, 1)
                area_score = area_ratio * 30

                # 4. 位置跳跃检查（如果距离预测位置太远，可能是错误匹配）
                if pos_dist > self.max_distance:
                    cost_matrix[i, j] = np.inf
                else:
                    # 综合代价：位置距离 + 速度惩罚 + 面积惩罚
                    cost = (
                        pos_dist + vel_score * self.velocity_weight + area_score * self.area_weight
                    )
                    cost_matrix[i, j] = cost

        return cost_matrix

    def associate_detections_to_tracks(self, cost_matrix, threshold=0.5):
        """
        使用贪心算法将检测匹配到轨迹
        优先匹配代价最小的对

        参数:
            cost_matrix: 代价矩阵
            threshold: 最大匹配代价阈值（相对于max_distance）

        返回:
            matches: [(track_idx, det_idx), ...]
            unmatched_tracks: [track_idx, ...]
            unmatched_detections: [det_idx, ...]
        """
        matches = []
        unmatched_tracks = list(range(cost_matrix.shape[0]))
        unmatched_detections = list(range(cost_matrix.shape[1]))

        # 找到所有有效的匹配对（代价不是无穷大）
        valid_pairs = []
        for i in range(cost_matrix.shape[0]):
            for j in range(cost_matrix.shape[1]):
                if cost_matrix[i, j] < np.inf:
                    valid_pairs.append((i, j, cost_matrix[i, j]))

        # 按代价排序
        valid_pairs.sort(key=lambda x: x[2])

        # 贪心匹配
        max_cost = self.max_distance * threshold
        for i, j, cost in valid_pairs:
            if i in unmatched_tracks and j in unmatched_detections and cost <= max_cost:
                matches.append((i, j))
                unmatched_tracks.remove(i)
                unmatched_detections.remove(j)

        return matches, unmatched_tracks, unmatched_detections

    def update_tracks(self, detections, frame_num):
        """
        更新跟踪轨迹

        参数:
            detections: 当前帧检测到的细菌 [(x, y, area), ...]
            frame_num: 当前帧号
        """
        # 预测所有轨迹的下一帧位置
        active_tracks = [
            track for track in self.tracks.values() if track.time_since_update < self.max_age
        ]

        if len(active_tracks) == 0:
            # 如果没有活跃轨迹，为所有检测创建新轨迹
            for x, y, area in detections:
                track = Track(self.next_id, x, y, area, frame_num)
                self.tracks[self.next_id] = track
                self.next_id += 1
            return

        if len(detections) == 0:
            # 如果没有检测，更新所有轨迹的时间
            for track in active_tracks:
                track.time_since_update += 1
                track.age += 1
            return

        # 计算代价矩阵
        cost_matrix = self.compute_cost_matrix(active_tracks, detections)

        # 匹配检测到轨迹
        matches, unmatched_tracks, unmatched_detections = self.associate_detections_to_tracks(
            cost_matrix, threshold=0.8
        )

        # 更新匹配的轨迹
        for track_idx, det_idx in matches:
            track = active_tracks[track_idx]
            det_x, det_y, det_area = detections[det_idx]

            # 检查是否可能是两个细菌合并（面积突然增大很多）
            if det_area > track.avg_area * 1.8:
                # 可能是合并，但先更新，后续可以改进
                pass

            track.update(det_x, det_y, det_area, frame_num)

        # 处理未匹配的轨迹
        for track_idx in unmatched_tracks:
            track = active_tracks[track_idx]
            track.time_since_update += 1
            track.age += 1

        # 为未匹配的检测创建新轨迹
        for det_idx in unmatched_detections:
            det_x, det_y, det_area = detections[det_idx]
            track = Track(self.next_id, det_x, det_y, det_area, frame_num)
            self.tracks[self.next_id] = track
            self.next_id += 1

        # 注意：不再删除过期的轨迹，保留所有轨迹的历史数据
        # 这样可以确保保存CSV时包含所有轨迹信息
        # 如果需要在可视化时过滤过期轨迹，可以在可视化部分进行判断

    def process_video(self, output_path=None, visualize=True):
        """
        处理视频并跟踪细菌

        参数:
            output_path: 输出视频路径（可选）
            visualize: 是否可视化结果

        返回:
            tracks: 所有轨迹数据
        """
        cap = cv2.VideoCapture(self.video_path)

        if not cap.isOpened():
            error_msg = f"无法打开视频文件: {self.video_path}"
            logger.error(error_msg)
            logger.error("请检查:")
            logger.error("  1. 文件路径是否正确")
            logger.error("  2. 文件是否存在")
            logger.error("  3. 文件格式是否支持")
            logger.error("  4. 是否有读取权限")
            raise ValueError(error_msg)

        # 获取视频属性
        fps = cap.get(cv2.CAP_PROP_FPS)
        if fps <= 0:
            fps = 30.0  # 默认帧率
        self.fps = fps
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

        logger.info(f"视频信息: {width}x{height}, {fps:.2f} FPS, {total_frames} 帧")

        # 设置输出视频
        out = None
        if output_path:
            fourcc = cv2.VideoWriter_fourcc(*"mp4v")
            out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))

        frame_num = 0

        # 颜色列表，用于可视化不同轨迹
        colors = self._generate_colors(100)

        # 使用tqdm显示进度条，设置miniters和mininterval减少刷新频率
        pbar = tqdm(
            total=total_frames,
            desc="处理视频",
            unit="帧",
            miniters=10,
            mininterval=0.5,
            smoothing=0.1,
        )

        # 用于缓存活跃轨迹数，减少计算频率
        last_active_tracks_count = 0
        last_detections_count = 0

        while True:
            ret, frame = cap.read()
            if not ret:
                break

            # 模糊/低对比度视频：可选帧预处理
            if self.preprocess_sharpen or self.preprocess_denoise or self.preprocess_clahe:
                frame = _preprocess_frame(
                    frame,
                    sharpen=self.preprocess_sharpen,
                    denoise=self.preprocess_denoise,
                    clahe=self.preprocess_clahe,
                )

            # 背景减除（模糊视频可设 bg_learning_rate 较小值，减缓背景吸收运动物体）
            if self.bg_learning_rate is not None:
                fg_mask = self.bg_subtractor.apply(frame, None, self.bg_learning_rate)
            else:
                fg_mask = self.bg_subtractor.apply(frame)

            # 检测细菌
            detections = self.detect_bacteria(frame, fg_mask)

            # 更新跟踪
            self.update_tracks(detections, frame_num)

            # 可视化
            if visualize or output_path:
                vis_frame = frame.copy()

                # 绘制所有活跃轨迹
                active_tracks = [
                    track
                    for track in self.tracks.values()
                    if track.time_since_update < self.max_age
                ]

                for track in active_tracks:
                    color = colors[track.track_id % len(colors)]
                    x, y = track.get_position()

                    # 计算当前速度（像素/帧）
                    vx, vy = track.get_velocity()
                    speed = np.sqrt(vx**2 + vy**2)

                    # 如果有FPS，转换为像素/秒
                    if self.fps and self.fps > 0:
                        speed_per_sec = speed * self.fps
                        speed_text = f"{speed_per_sec:.1f} px/s"
                    else:
                        speed_text = f"{speed:.2f} px/f"

                    # 绘制当前位置
                    cv2.circle(vis_frame, (int(x), int(y)), 5, color, -1)
                    cv2.putText(
                        vis_frame,
                        f"ID:{track.track_id} {speed_text}",
                        (int(x) + 10, int(y) - 10),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.4,
                        color,
                        1,
                    )

                    # 绘制轨迹历史，使用颜色深浅表示速度
                    if len(track.positions) > 1:
                        trail_positions = track.positions[-self.trail_length :]
                        points = [(int(p[1]), int(p[2])) for p in trail_positions]

                        # 计算每个点的速度
                        speeds = []
                        for i in range(len(trail_positions)):
                            if i == 0:
                                speeds.append(0)
                            else:
                                # 计算相邻两点的速度
                                prev_frame, prev_x, prev_y = trail_positions[i - 1]
                                curr_frame, curr_x, curr_y = trail_positions[i]
                                frame_diff = curr_frame - prev_frame
                                if frame_diff > 0:
                                    dx = curr_x - prev_x
                                    dy = curr_y - prev_y
                                    speed = np.sqrt(dx**2 + dy**2) / frame_diff
                                    if self.fps and self.fps > 0:
                                        speed = speed * self.fps  # 转换为像素/秒
                                else:
                                    speed = 0
                                speeds.append(speed)

                        # 归一化速度到0-1范围（用于颜色映射）
                        if len(speeds) > 0 and max(speeds) > 0:
                            max_speed = max(speeds)
                            normalized_speeds = [s / max_speed for s in speeds]
                        else:
                            normalized_speeds = [0] * len(speeds)

                        # 将基础颜色转换为HSV
                        base_color_bgr = np.uint8([[color]])
                        base_color_hsv = cv2.cvtColor(base_color_bgr, cv2.COLOR_BGR2HSV)[0][0]
                        base_hue = base_color_hsv[0]
                        base_saturation = base_color_hsv[1]

                        # 绘制轨迹线段，根据速度调整颜色深浅
                        for i in range(1, len(points)):
                            # 使用当前点和前一个点的平均速度
                            avg_speed = (normalized_speeds[i] + normalized_speeds[i - 1]) / 2

                            # 速度越大，颜色越亮（增加亮度）
                            # 速度越小，颜色越暗（减少亮度）
                            brightness = int(50 + avg_speed * 200)  # 亮度范围：50-250
                            brightness = np.clip(brightness, 50, 255)

                            # 创建HSV颜色，保持色相和饱和度，调整亮度
                            speed_color_hsv = np.uint8([[[base_hue, base_saturation, brightness]]])
                            speed_color_bgr = cv2.cvtColor(speed_color_hsv, cv2.COLOR_HSV2BGR)[0][0]
                            speed_color = tuple(map(int, speed_color_bgr))

                            cv2.line(vis_frame, points[i - 1], points[i], speed_color, 2)

                    # 绘制预测位置（可选，用于调试）
                    pred_x, pred_y = track.predict()
                    cv2.circle(vis_frame, (int(pred_x), int(pred_y)), 3, (255, 255, 255), 1)

                # 显示检测数量
                cv2.putText(
                    vis_frame,
                    f"Frame: {frame_num}/{total_frames}",
                    (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.7,
                    (0, 255, 0),
                    2,
                )
                cv2.putText(
                    vis_frame,
                    f"Detections: {len(detections)}",
                    (10, 60),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.7,
                    (0, 255, 0),
                    2,
                )
                cv2.putText(
                    vis_frame,
                    f"Active Tracks: {len(active_tracks)}",
                    (10, 90),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.7,
                    (0, 255, 0),
                    2,
                )

                if visualize:
                    cv2.imshow("Bacteria Tracking", vis_frame)
                    if cv2.waitKey(1) & 0xFF == ord("q"):
                        break

                if out:
                    out.write(vis_frame)

            frame_num += 1
            pbar.update(1)

            # 每10帧更新一次描述信息，减少抖动
            # 检测数：当前帧检测到的目标个数（本帧前景中符合面积范围的斑点数量）
            # 轨迹数：当前活跃轨迹条数（最近 max_age 帧内有过匹配的轨迹数量）
            if frame_num % 10 == 0:
                active_tracks_count = len(
                    [t for t in self.tracks.values() if t.time_since_update < self.max_age]
                )
                # 只在数值变化时更新，进一步减少抖动
                if (
                    active_tracks_count != last_active_tracks_count
                    or len(detections) != last_detections_count
                ):
                    pbar.set_postfix({"检测数": len(detections), "轨迹数": active_tracks_count})
                    last_active_tracks_count = active_tracks_count
                    last_detections_count = len(detections)

        pbar.close()

        cap.release()
        if out:
            out.release()
        if visualize:
            cv2.destroyAllWindows()

        logger.success(f"处理完成！共跟踪到 {len(self.tracks)} 条轨迹")
        return self.tracks

    def _generate_colors(self, n):
        """生成n个不同的颜色"""
        colors = []
        for i in range(n):
            hue = int(180 * i / n)
            color = cv2.cvtColor(np.uint8([[[hue, 255, 255]]]), cv2.COLOR_HSV2BGR)[0][0]
            colors.append(tuple(map(int, color)))
        return colors

    def save_tracks_csv(self, output_path):
        """
        保存轨迹数据到CSV文件
        列名: frame, time, idx, x, y

        参数:
            output_path: 输出文件路径
        """
        if self.fps is None or self.fps <= 0:
            logger.warning("警告: 无法获取视频FPS，使用默认值30.0")
            fps = 30.0
        else:
            fps = self.fps

        # 收集所有轨迹数据
        data = []
        for track_id, track in self.tracks.items():
            for frame_num, x, y in track.positions:
                time = round(frame_num / fps, 4)  # 计算时间（秒），保留4位小数
                data.append({"frame": frame_num, "time": time, "idx": track_id, "x": x, "y": y})

        # 使用pandas创建DataFrame
        df = pd.DataFrame(data)

        # 按帧号和轨迹ID排序
        df = df.sort_values(by=["frame", "idx"])

        # 保存为CSV文件
        df.to_csv(output_path, index=False, encoding="utf-8", float_format="%.4f")
        logger.success(f"轨迹CSV数据已保存到: {output_path} (共 {len(df)} 条记录)")

    def get_tracks_summary(self):
        """
        获取轨迹摘要信息

        返回:
            summary: 轨迹摘要字典
        """
        summary = {"total_tracks": len(self.tracks), "tracks_info": []}

        for track_id, track in self.tracks.items():
            if len(track.positions) > 0:
                track_info = {
                    "track_id": track_id,
                    "frame_count": len(track.positions),
                    "start_frame": track.positions[0][0],
                    "end_frame": track.positions[-1][0],
                    "total_distance": 0,
                    "avg_area": track.avg_area,
                }

                # 计算总移动距离
                for i in range(1, len(track.positions)):
                    x1, y1 = track.positions[i - 1][1], track.positions[i - 1][2]
                    x2, y2 = track.positions[i][1], track.positions[i][2]
                    track_info["total_distance"] += np.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)

                summary["tracks_info"].append(track_info)

        return summary


def _estimate_min_max_area(areas, min_floor=2, max_ceiling=20000):
    """
    从面积分布自动估算 min_area / max_area，兼顾大颗粒和小颗粒。
    - 使用较宽分位数（1%/99%）并留余量，避免单一阈值把大小颗粒裁掉。
    - 若检测到双峰（小+大两簇），则范围覆盖两簇。
    """
    areas = np.asarray(areas, dtype=np.float64)
    areas = np.sort(areas[areas >= min_floor])
    if len(areas) == 0:
        return min_floor, min(max_ceiling, 5000)
    n = len(areas)
    # 宽分位数，尽量包含小颗粒和大颗粒
    p_low = np.percentile(areas, 1)
    p_high = np.percentile(areas, 99)
    min_suggested = max(min_floor, int(p_low * 0.8))
    max_suggested = min(max_ceiling, int(p_high * 1.4))
    # 双峰检测：log 空间直方图，若存在明显两峰则扩大范围以覆盖两峰
    log_a = np.log10(areas + 1)
    hist, bin_edges = np.histogram(log_a, bins=min(50, max(10, n // 20)))
    peaks = []
    for i in range(1, len(hist) - 1):
        if hist[i] >= hist[i - 1] and hist[i] >= hist[i + 1] and hist[i] > 0:
            peaks.append((bin_edges[i] + bin_edges[i + 1]) / 2)
    if len(peaks) >= 2:
        peaks = sorted(peaks)
        low_log = min(peaks[0], np.log10(areas.min() + 1))
        high_log = max(peaks[-1], np.log10(areas.max() + 1))
        min_suggested = max(min_floor, min(min_suggested, int(10**low_log)))
        max_suggested = min(max_ceiling, max(max_suggested, int(10**high_log * 1.2)))
    if max_suggested <= min_suggested:
        max_suggested = min(max_ceiling, min_suggested + max(int(p_high * 0.5), 1))
    return min_suggested, max_suggested


def estimate_detection_params(video_path, sample_frames=15):
    """
    分析视频，自动估算检测参数，兼顾大颗粒和小颗粒。
    - 使用多组背景减除阈值和形态学，合并轮廓面积，再根据面积分布自动定 min_area / max_area。
    - 若分布呈双峰（小+大），则范围覆盖两峰；否则用宽分位数（1%/99%）加余量。
    """
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise ValueError(f"无法打开视频文件: {video_path}")
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    sample_interval = max(1, total_frames // max(sample_frames, 1))
    # 先采样帧到内存，避免多次读视频
    sampled = []
    for i in range(0, total_frames, sample_interval):
        cap.set(cv2.CAP_PROP_POS_FRAMES, i)
        ret, frame = cap.read()
        if ret:
            sampled.append(frame)
    cap.release()
    if not sampled:
        logger.warning("未能读取视频帧")
        return {"min_area": 2, "max_area": 5000, "max_distance": 100}

    # 多阈值：低阈值抓小/暗目标，高阈值抓大/亮目标；两种形态学（小核仅闭、小核闭+开）兼顾大小颗粒
    bg_thresholds = [20, 30, 45]
    morph_small = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2, 2))
    morph_open = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
    areas = []
    for var_t in bg_thresholds:
        bg = cv2.createBackgroundSubtractorMOG2(
            history=500, varThreshold=var_t, detectShadows=False
        )
        for frame in sampled:
            fg = bg.apply(frame)
            for do_open, k in [(False, morph_small), (True, morph_open)]:
                m = cv2.morphologyEx(fg, cv2.MORPH_CLOSE, k)
                if do_open:
                    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, k)
                contours, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
                for c in contours:
                    a = cv2.contourArea(c)
                    if a >= 2:
                        areas.append(a)
    if len(areas) == 0:
        logger.warning("未能检测到目标，请检查视频或手动调整参数")
        return {
            "min_area": 2,
            "max_area": 5000,
            "max_distance": 100,
        }
    areas = np.array(areas)
    min_area_suggested, max_area_suggested = _estimate_min_max_area(areas)
    if max_area_suggested > 2000:
        max_distance_suggested = 150
    elif max_area_suggested > 1000:
        max_distance_suggested = 100
    else:
        max_distance_suggested = 50
    suggested_params = {
        "min_area": int(min_area_suggested),
        "max_area": int(max_area_suggested),
        "max_distance": max_distance_suggested,
    }
    logger.info(
        f"检测到的目标面积范围: {areas.min():.0f} - {areas.max():.0f} 像素, "
        f"建议 min_area={suggested_params['min_area']}, max_area={suggested_params['max_area']}, "
        f"max_distance={suggested_params['max_distance']}"
    )
    return suggested_params


class TrajectoryTrackingTask(BaseTask):
    """轨迹识别任务：从视频中识别和跟踪轨迹"""

    task_name = "tracking"

    def __init__(
        self,
        video_path: str,
        output_dir=None,
        output_prefix: str = "",
        *,
        min_area: int = 5,
        max_area: int = 500,
        max_distance: int = 50,
        area_weight: float = 0.3,
        velocity_weight: float = 0.2,
        trail_length: int = 300,
        bg_history: int = 500,
        bg_threshold=None,
        bg_learning_rate=None,
        debug: bool = False,
        preprocess_sharpen: bool = False,
        preprocess_denoise: bool = False,
        preprocess_clahe: bool = False,
        max_age: int = 10,
        visualize: bool = False,
        overwrite: bool = False,
        **kwargs,
    ):
        """
        初始化轨迹跟踪任务

        参数:
            video_path: 视频文件路径
            output_dir: 输出目录
            output_prefix: 输出文件前缀，例如 "step01-"，默认为空字符串
            min_area: 检测最小面积（像素），默认 5
            max_area: 检测最大面积（像素），默认 500
            max_distance: 帧间最大跟踪距离（像素），默认 50
            area_weight: 面积匹配权重，默认 0.3
            velocity_weight: 速度匹配权重，默认 0.2
            trail_length: 绘制历史轨迹长度（帧数），默认 300
            bg_history: 背景减除器历史帧数，默认 500
            bg_threshold: 背景减除阈值，None 时按目标大小自动设置
            bg_learning_rate: 背景学习率，None 为默认；模糊视频可设 0.001
            debug: 是否调试模式，默认 False
            preprocess_sharpen: 是否锐化，默认 False
            preprocess_denoise: 是否去噪，默认 False
            preprocess_clahe: 是否 CLAHE 对比度增强，默认 False
            max_age: 轨迹最大未匹配帧数，默认 10；模糊视频可增大
            visualize: 是否输出带标注视频并显示，默认 False
            overwrite: 是否覆盖已有 CSV/视频（任务层 overwrite 由 run(overwrite=) 控制）
            **kwargs: 其余参数会合并进 tracking_params 传给跟踪器
        """
        output_dir_path = Path(output_dir) if output_dir else None
        super().__init__(output_dir_path, output_prefix=output_prefix)

        self.video_path = Path(video_path)
        self.tracking_params = {
            "min_area": min_area,
            "max_area": max_area,
            "max_distance": max_distance,
            "area_weight": area_weight,
            "velocity_weight": velocity_weight,
            "trail_length": trail_length,
            "bg_history": bg_history,
            "bg_threshold": bg_threshold,
            "bg_learning_rate": bg_learning_rate,
            "debug": debug,
            "preprocess_sharpen": preprocess_sharpen,
            "preprocess_denoise": preprocess_denoise,
            "preprocess_clahe": preprocess_clahe,
            "max_age": max_age,
            "visualize": visualize,
            "overwrite": overwrite,
            **kwargs,
        }
        self.output_csv = None
        self.output_video = None

    def validate_inputs(self) -> bool:
        """验证输入视频文件是否存在"""
        if not self.video_path.exists():
            logger.error(f"视频文件不存在: {self.video_path}")
            return False
        return True

    def get_output_paths(self):
        """获取输出文件路径"""
        video_stem = self.video_path.stem
        prefix = self.output_prefix if self.output_prefix else ""
        return {
            "csv": self.output_dir / f"{prefix}{video_stem}_tracks.csv",
            "video": self.output_dir / f"{prefix}{video_stem}_tracked.mp4",
        }

    def get_task_inputs(self):
        return {"video_path": str(self.video_path), "params": self.tracking_params}

    def get_task_results(self):
        if not self.results or "summary" not in self.results:
            return None
        s = self.results["summary"]
        return {
            "total_tracks": s.get("total_tracks"),
            "tracks_info_count": len(s.get("tracks_info", [])),
        }

    def apply_output_paths(self, paths):
        self.output_csv = paths.get("csv")
        self.output_video = paths.get("video")

    def _results_from_skip_record(self, record):
        r = record.get("results") or {}
        return {"tracker": None, "summary": r}

    def get_skip_return_value(self, record):
        return (None, record.get("results", {}))

    def _run(self, **kwargs):
        """
        执行轨迹跟踪（由 BaseTask.run 调用，已含输入校验与异常处理）

        返回:
            (tracker, summary): 跟踪器对象和摘要
        """
        params = {**self.tracking_params, **kwargs}
        paths = self.get_output_paths()
        self.output_csv = paths["csv"]
        self.output_video = paths["video"]

        self.print_info(
            Input_Video=str(self.video_path),
            Output_CSV=str(self.output_csv),
            Output_Video=str(self.output_video),
        )

        params.pop("overwrite", False)
        visualize = params.pop("visualize", False)

        tracker = BacteriaTracker(video_path=str(self.video_path), **params)
        tracker.process_video(output_path=str(self.output_video), visualize=visualize)
        tracker.save_tracks_csv(str(self.output_csv))
        summary = tracker.get_tracks_summary()

        self.results = {"tracker": tracker, "summary": summary}
        return tracker, summary

    def print_summary(self):
        """打印跟踪摘要；若结果已存在则从保存的 CSV 读取"""
        total_tracks = None
        if self.output_csv and Path(self.output_csv).exists():
            try:
                df = pd.read_csv(self.output_csv)
                total_tracks = df["idx"].nunique() if "idx" in df.columns else 0
            except (OSError, Exception):
                pass
        if total_tracks is None and self.results:
            summary = (self.results or {}).get("summary") or (
                self.results
                if isinstance(self.results, dict) and "total_tracks" in (self.results or {})
                else None
            )
            total_tracks = summary.get("total_tracks") if summary else None
        if total_tracks is not None:
            logger.info("=" * 60)
            logger.info("Tracking Summary")
            logger.info("=" * 60)
            logger.info(f"Total Tracks: {total_tracks}")
            logger.info("=" * 60)
