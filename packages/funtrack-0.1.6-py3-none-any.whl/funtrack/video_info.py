"""
视频基础信息分析模块
分析原始视频的元数据（路径、文件大小、尺寸、高宽比、帧数等），结果保存为 JSON。
"""

import json
from pathlib import Path
from typing import Any, Dict

import cv2
from nltlog import getLogger

from funtrack.base import BaseTask

logger = getLogger("funtrack")


def extract_video_info(video_path: str) -> Dict[str, Any]:
    """
    从视频文件提取基础信息（路径、文件大小、尺寸、高宽比、帧数、帧率等）。

    参数:
        video_path: 视频文件路径

    返回:
        包含视频元数据的字典，可直接序列化为 JSON
    """
    path = Path(video_path).resolve()
    info: Dict[str, Any] = {
        "path": str(path),
        "filename": path.name,
        "stem": path.stem,
        "file_size_bytes": path.stat().st_size if path.exists() else None,
    }

    cap = cv2.VideoCapture(str(path))
    if not cap.isOpened():
        info["error"] = "无法打开视频文件"
        return info

    try:
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        fps = cap.get(cv2.CAP_PROP_FPS)
        duration_sec = frame_count / fps if fps and fps > 0 else None

        info["width"] = width
        info["height"] = height
        info["aspect_ratio"] = round(width / height, 4) if height else None
        info["frame_count"] = frame_count
        info["fps"] = round(fps, 2) if fps is not None else None
        info["duration_sec"] = round(duration_sec, 2) if duration_sec is not None else None
    finally:
        cap.release()

    return info


class VideoInfoTask(BaseTask):
    """视频基础信息任务：提取路径、文件大小、尺寸、高宽比、帧数等，保存为 JSON"""

    task_name = "video_info"

    def __init__(self, video_path: str, output_dir=None, output_prefix: str = ""):
        """
        初始化视频信息任务

        参数:
            video_path: 视频文件路径
            output_dir: 输出目录
            output_prefix: 输出文件前缀，例如 "step00-"，默认为空字符串
        """
        output_dir_path = Path(output_dir) if output_dir else None
        super().__init__(output_dir_path, output_prefix=output_prefix)
        self.video_path = Path(video_path)
        self.output_json = None

    def validate_inputs(self) -> bool:
        """验证输入视频文件是否存在"""
        if not self.video_path.exists():
            logger.error(f"视频文件不存在: {self.video_path}")
            return False
        return True

    def get_output_paths(self) -> Dict[str, Path]:
        """获取输出文件路径（统一为原视频文件名 + 后缀）"""
        base = self.video_path.stem
        prefix = self.output_prefix if self.output_prefix else ""
        return {
            "json": self.output_dir / f"{prefix}{base}_video_info.json",
        }

    def get_task_inputs(self):
        return {"video_path": str(self.video_path)}

    def get_task_results(self):
        return self.results.get("info") if self.results else None

    def apply_output_paths(self, paths):
        self.output_json = paths.get("json")

    def _results_from_skip_record(self, record):
        return {"info": record.get("results")}

    def get_skip_return_value(self, record):
        return record.get("results")

    def _run(self, **kwargs) -> Dict[str, Any]:
        """
        执行视频信息提取（由 BaseTask.run 调用）。

        返回:
            视频信息字典；失败时返回带 error 键的字典
        """
        paths = self.get_output_paths()
        self.output_json = paths["json"]

        self.print_info(Input_Video=str(self.video_path), Output_JSON=str(self.output_json))

        info = extract_video_info(str(self.video_path))
        if "error" in info:
            logger.warning(f"视频信息提取不完整: {info['error']}")

        with open(self.output_json, "w", encoding="utf-8") as f:
            json.dump(info, f, ensure_ascii=False, indent=2)

        logger.info(f"视频信息已保存: {self.output_json}")
        self.results = {"info": info}
        return info

    def print_summary(self):
        """打印视频信息摘要；若结果已存在则从保存的 JSON 读取"""
        info = None
        if self.output_json and Path(self.output_json).exists():
            try:
                with open(self.output_json, encoding="utf-8") as f:
                    info = json.load(f)
            except (json.JSONDecodeError, OSError):
                pass
        if info is None and self.results and "info" in self.results:
            info = self.results["info"]
        if not info:
            return
        if "error" in info:
            logger.warning(f"视频信息异常: {info['error']}")
            return
        logger.info("=" * 60)
        logger.info("Video Info Summary")
        logger.info("=" * 60)
        logger.info(f"  path: {info.get('path', '')}")
        logger.info(f"  file_size_bytes: {info.get('file_size_bytes')}")
        logger.info(f"  width x height: {info.get('width')} x {info.get('height')}")
        logger.info(f"  aspect_ratio: {info.get('aspect_ratio')}")
        logger.info(f"  frame_count: {info.get('frame_count')}")
        logger.info(f"  fps: {info.get('fps')}")
        logger.info(f"  duration_sec: {info.get('duration_sec')}")
        logger.info("=" * 60)
