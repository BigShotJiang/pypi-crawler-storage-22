from .submitit import SubmititAdapter

__all__ = ["SubmititAdapter"]
