"""Entry point for running the dashboard as a module: python -m furu.dashboard"""

from .main import cli

if __name__ == "__main__":
    cli()

