import asyncio
from fury import Agent, HistoryManager


agent = Agent(
    model="unsloth/GLM-4.6V-Flash-GGUF:Q8_0",
    system_prompt="You are a helpful assistant.",
)

history_manager = HistoryManager(agent=agent)


async def main():
    while True:

        # Add the user's input to the history.
        await history_manager.add({"role": "user", "content": input("> ")})

        # history = agent.add_image_to_history(history, "image.jpg") Optionally add a image to the last message of the history.
        # history = agent.add_voice_message_to_history(history, base64_audio_bytes) Optionally add a voice message to the last message of the history.

        buffer = ""

        print()
        async for event in agent.chat(history_manager.history, reasoning=False):
            if event.content:
                buffer += event.content
                print(event.content, end="", flush=True)

        await history_manager.add({"role": "assistant", "content": buffer})


asyncio.run(main())
