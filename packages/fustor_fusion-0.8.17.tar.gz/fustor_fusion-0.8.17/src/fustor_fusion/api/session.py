# fusion/src/fustor_fusion/api/session.py
"""
Session management API for creating, maintaining, and closing pipesessions.
"""
from fastapi import APIRouter, Depends, status, HTTPException, Header, Query, Request
from pydantic import BaseModel
import logging
from typing import List, Dict, Any, Optional
import time
import uuid

from ..auth.dependencies import get_view_id_from_api_key


from ..config.unified import fusion_config
from ..core.session_manager import session_manager
from ..view_state_manager import view_state_manager
from ..view_manager.manager import reset_views, on_session_start, on_session_close
from .. import runtime_objects


logger = logging.getLogger(__name__)
session_router = APIRouter(tags=["Session Management"])

# Default configuration values
DEFAULT_SESSION_TIMEOUT = 30
DEFAULT_ALLOW_CONCURRENT_PUSH = False
DEFAULT_AUDIT_INTERVAL = 600.0
DEFAULT_SENTINEL_INTERVAL = 120.0


class CreateSessionPayload(BaseModel):
    """Payload for creating a new session"""
    task_id: str
    client_info: Optional[Dict[str, Any]] = None
    session_timeout_seconds: Optional[int] = None


def _get_session_config(pipe_id: str) -> Dict[str, Any]:
    """Get session configuration from fusion config (pipes configuration)."""
    # In unified config, pipe config holds session parameters
    pipe = fusion_config.get_pipe(pipe_id)
    
    if pipe:
        return {
            "session_timeout_seconds": pipe.session_timeout_seconds,
            "allow_concurrent_push": pipe.allow_concurrent_push,
            "audit_interval_sec": pipe.audit_interval_sec,
            "sentinel_interval_sec": pipe.sentinel_interval_sec,
        }
        
    return {
        "session_timeout_seconds": DEFAULT_SESSION_TIMEOUT,
        "allow_concurrent_push": DEFAULT_ALLOW_CONCURRENT_PUSH,
        "audit_interval_sec": DEFAULT_AUDIT_INTERVAL,
        "sentinel_interval_sec": DEFAULT_SENTINEL_INTERVAL,
    }


async def _should_allow_new_session(
    allow_concurrent_push: bool, 
    view_id: str, 
    task_id: str, 
    session_id: str
) -> bool:
    """
    Determine if a new session should be allowed based on configuration and current active sessions.
    """
    view_id = str(view_id)
    sessions = await session_manager.get_view_sessions(view_id)
    active_session_ids = set(sessions.keys())
    
    # NEW: Even if concurrent push is allowed, we don't allow duplicate task_id
    # for different sessions. This prevents confusion in state management.
    for si in sessions.values():
        if si.task_id == task_id:
            logger.warning(f"Task {task_id} already has an active session {si.session_id} on view {view_id}")
            return False

    if allow_concurrent_push:
        return True
    else:
        locked_session_id = await view_state_manager.get_locked_session_id(view_id)
        logger.debug(f"View {view_id} is locked by session: {locked_session_id}")

        if not locked_session_id:
            logger.debug(f"View {view_id} is not locked. Allowing new session.")
            return True

        if locked_session_id not in active_session_ids:
            logger.warning(f"View {view_id} is locked by a stale session {locked_session_id} that is no longer active. Unlocking automatically.")
            await view_state_manager.unlock_for_session(view_id, locked_session_id)
            return True
        else:
            logger.warning(f"View {view_id} is locked by an active session {locked_session_id}. Denying new session {session_id}.")
            return False


@session_router.post("/", summary="Create new pipesession")
async def create_session(
    payload: CreateSessionPayload,
    request: Request,
    view_id: str = Depends(get_view_id_from_api_key),
):
    view_id = str(view_id)
    session_id = str(uuid.uuid4())
    client_ip = request.client.host
    
    # Use client-requested timeout if provided, otherwise fallback to server config
    session_config = _get_session_config(view_id)
    session_timeout_seconds = payload.session_timeout_seconds or session_config["session_timeout_seconds"]

    if runtime_objects.pipe_manager:
        # In the new architecture, we delegate to PipeManager to ensure correct routing
        try:
            client_info = payload.client_info or {}
            client_info["client_ip"] = client_ip
            
            session_info = await runtime_objects.pipe_manager._on_session_created(
                session_id=session_id,
                task_id=payload.task_id,
                pipe_id=view_id, # view_id as the pipe_id
                client_info=client_info,
                session_timeout_seconds=session_timeout_seconds
            )
            
            return {
                "session_id": session_id,
                "role": session_info.role,
                "is_leader": (session_info.role == "leader"),
                "session_timeout_seconds": session_timeout_seconds,
                "audit_interval_sec": session_info.audit_interval_sec,
                "sentinel_interval_sec": session_info.sentinel_interval_sec,
            }
        except ValueError as e:
            # Handle concurrency/locking conflicts correctly
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(e))
        except Exception as e:
            logger.error(f"PipeManager failed to create session: {e}", exc_info=True)
            raise HTTPException(status_code=500, detail=str(e))

    # --- Legacy Fallback (If PipeManager not fully active) ---
    allow_concurrent_push = session_config["allow_concurrent_push"]
    should_allow = await _should_allow_new_session(
        allow_concurrent_push, view_id, payload.task_id, session_id
    )
    if not should_allow:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="New session cannot be created due to current active sessions"
        )
    
    is_leader = await view_state_manager.try_become_leader(view_id, session_id)
    if is_leader:
        await view_state_manager.set_authoritative_session(view_id, session_id)

    try:
        await on_session_start(view_id)
    except Exception as e:
        logger.error(f"Failed to trigger on_session_start: {e}")

    await session_manager.create_session_entry(
        view_id, 
        session_id, 
        task_id=payload.task_id,
        client_ip=client_ip,
        allow_concurrent_push=allow_concurrent_push,
        session_timeout_seconds=session_timeout_seconds,
        source_uri=payload.client_info.get("source_uri") if payload.client_info else None
    )
    
    if not allow_concurrent_push:
        await view_state_manager.lock_for_session(view_id, session_id)
    
    role = "leader" if is_leader else "follower"
    return {
        "session_id": session_id,
        "role": role,
        "is_leader": is_leader,
        "session_timeout_seconds": session_timeout_seconds,
        "audit_interval_sec": session_config.get("audit_interval_sec"),
        "sentinel_interval_sec": session_config.get("sentinel_interval_sec"),
    }


@session_router.post("/{session_id}/heartbeat", tags=["Session Management"], summary="Session heartbeat keepalive")
async def heartbeat(
    session_id: str,
    request: Request,
    view_id: str = Depends(get_view_id_from_api_key),
):
    view_id = str(view_id)
    si = await session_manager.get_session_info(view_id, session_id)
    
    if not si:
        raise HTTPException(
            status_code=419,  # Session Obsoleted
            detail=f"Session {session_id} not found"
        )
    
    is_locked_by_session = await view_state_manager.is_locked_by_session(view_id, session_id)
    if not is_locked_by_session:
        await view_state_manager.lock_for_session(view_id, session_id)
    
    payload = await request.json()
    can_realtime = payload.get("can_realtime", False)
    
    success, commands = await session_manager.keep_session_alive(view_id, session_id, client_ip=request.client.host, can_realtime=can_realtime)
    if not success:  # Should match session existence check above, but for safety
        logger.warning(f"Session {session_id} not found during heartbeat update (race condition?)")
    
    is_leader = await view_state_manager.try_become_leader(view_id, session_id)
    
    if is_leader:
        await view_state_manager.set_authoritative_session(view_id, session_id)
        
    role = "leader" if is_leader else "follower"

    return {
        "status": "ok", 
        "message": f"Session {session_id} heartbeat updated successfully",
        "role": role,
        "is_leader": is_leader,
        "commands": commands
    }


@session_router.delete("/{session_id}", tags=["Session Management"], summary="End session")
async def end_session(
    session_id: str,
    view_id: str = Depends(get_view_id_from_api_key),
):
    view_id = str(view_id)
    success = await session_manager.terminate_session(view_id, session_id)
    
    if not success:
        # Session labels as "not found" but the goal of ending it is achieved
        logger.info(f"Session {session_id} not found or already terminated. Treating as success.")
        return {
            "status": "ok",
            "message": f"Session {session_id} already terminated"
        }
    
    await view_state_manager.unlock_for_session(view_id, session_id)
    await view_state_manager.release_leader(view_id, session_id)
    
    try:
        await on_session_close(view_id)
    except Exception as e:
        logger.warning(f"Failed to notify view driver instances of session close: {e}")
    
    return {
        "status": "ok",
        "message": f"Session {session_id} terminated successfully",
    }


@session_router.get("/", tags=["Session Management"], summary="Get current view_id for API Key")
async def get_authorized_view_info(
    view_id: str = Depends(get_view_id_from_api_key),
):
    """
    Returns the view_id associated with the provided API key.
    This replaces the legacy session listing which has been moved to /api/v1/views/{view_id}/sessions
    """
    return {
        "view_id": view_id,
        "status": "authorized"
    }
