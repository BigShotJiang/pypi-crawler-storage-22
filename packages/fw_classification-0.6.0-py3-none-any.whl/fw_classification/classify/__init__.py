"""Classification init module."""

import typing as t
from pathlib import Path

from dotty_dict import Dotty

from .block import Block
from .profile import Profile
from .rule import Action, Match, Rule

__all__ = ["Action", "Block", "Profile", "Match", "Rule", "run_classification"]


def run_classification(
    profile_or_path: t.Union[Path, Profile],
    i_dict: t.Dict[str, t.Any],
    include_blocks: bool = False,
) -> t.Union[t.Tuple[bool, Dotty], t.Tuple[bool, Dotty, t.Dict[str, bool]]]:
    """Run classification and generate dictionary.

    Args:
        profile_or_path (Path, Profile): Path to profile or instantiated Profile.
        i_dict (Dict[str, Any]): Input dictionary.
        include_blocks (bool): If True, return block execution results.

    Returns:
        (bool): True if any block executed, False otherwise.
        (Dotty): Output Dotty dictionary.
        (Dict[str, bool]): (Optional) Block execution results.
    """
    if hasattr(profile_or_path, "evaluate"):
        profile = profile_or_path
        return profile.evaluate(i_dict, include_blocks=include_blocks)  # type: ignore
    profile = Profile(Path(profile_or_path))  # type: ignore
    return profile.evaluate(i_dict, include_blocks=include_blocks)  # type: ignore
