# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- Initial project structure
- CLI skeleton with Typer and Rich
- Basic testing infrastructure
- GitHub Actions CI/CD
- Development scripts
- Documentation

## [0.0.1] - 2026-02-15

### Added
- PyPI package registration
- Project initialization
