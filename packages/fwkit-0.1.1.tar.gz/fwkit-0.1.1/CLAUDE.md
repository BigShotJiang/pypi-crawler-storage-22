# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Context

**fwkit** is an open-source, public repository for firmware development automation tools.

- Repository: https://github.com/AcenoTecnologia/fwkit
- License: MIT (public)
- Audience: General embedded developers, multiple companies, open community

## Important: Do NOT Reference Internal Projects

⚠️ **NEVER mention internal project names in code, commits, or documentation.**

Examples of what to AVOID:
- ❌ "Migrating from XYZ script..."
- ❌ "Based on Company X internal tool..."
- ❌ "Replaces ProjectName implementation..."

Instead, use generic terms:
- ✅ "Migrating from proprietary scripts..."
- ✅ "Based on existing automation patterns..."
- ✅ "Replaces custom implementation..."
- ✅ "Inspired by common embedded workflows..."

## Commit Message Guidelines

When writing commit messages:
- Focus on WHAT changed and WHY
- Describe the feature/fix generically
- DO NOT mention where the idea came from
- DO NOT reference internal projects by name
- Keep it professional and vendor-neutral

Good commit examples:
```
feat: add targetDirectory support for flexible project layouts

Implemented support for organizing linked files in custom directories.

Benefits:
- Files can be organized with custom folder names
- Supports both direct access and symlinked files
- Fully configurable via YAML
```

Bad commit examples:
```
feat: add support for A7000 workflow
fix: make it work like ProjectX does
docs: how to migrate from CompanyY tool
```

## Documentation Guidelines

When creating documentation:
- Use generic company/project names: "your project", "your firmware", "your repository"
- Focus on the tool's capabilities, not its origin
- Don't mention specific internal use cases unless they're generic patterns

## Code Comments

Inline comments should:
- Explain technical decisions
- NOT reference where the pattern came from
- Focus on the "what" and "why", not the history

## Why This Matters

This is a PUBLIC repository. Any reference to internal projects:
- Exposes internal project structure
- May violate NDAs or confidentiality
- Looks unprofessional
- Limits adoption (feels company-specific)

## Summary

✅ DO: Write generic, professional, vendor-neutral content
❌ DON'T: Mention internal project names, ever
🎯 FOCUS: On the tool's value, not its origins
