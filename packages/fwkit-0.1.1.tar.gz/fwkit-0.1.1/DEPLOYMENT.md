# Deployment Guide

This guide covers how to deploy fwkit documentation to GitHub Pages and publish releases to PyPI.

## 📚 GitHub Pages (Documentation)

The documentation is automatically built and deployed when changes are pushed to the `main` branch.

### Initial Setup (One-time)

1. Go to repository Settings → Pages
2. Under "Build and deployment":
   - **Source**: Deploy from a branch
   - Change to: **GitHub Actions**
3. Save

That's it! The documentation will be available at:
- https://acenotecnologia.github.io/fwkit/

### Manual Deployment

You can manually trigger a documentation build:
1. Go to Actions tab
2. Select "Documentation" workflow
3. Click "Run workflow" → "Run workflow"

### Local Preview

```bash
# Serve locally
uv run mkdocs serve

# Build and verify
uv run mkdocs build --strict
```

---

## 📦 PyPI Publishing

Publishing to PyPI happens automatically when you create a GitHub Release.

### Prerequisites (One-time Setup)

The workflow uses **Trusted Publishing** (no API tokens needed):

1. Go to [PyPI](https://pypi.org) and create an account
2. Register the project name (if first release):
   - Go to https://pypi.org/manage/account/publishing/
   - Add a new pending publisher:
     - **PyPI Project Name**: `fwkit`
     - **Owner**: `AcenoTecnologia`
     - **Repository name**: `fwkit`
     - **Workflow name**: `publish.yml`
     - **Environment name**: `pypi`
3. Click "Add"

For TestPyPI (optional, for testing):
1. Go to https://test.pypi.org/manage/account/publishing/
2. Repeat the same process with environment name: `testpypi`

### Creating a Release

#### 1. Update Version

Edit `pyproject.toml`:
```toml
version = "0.1.0"  # Remove "-dev" suffix
```

Commit the change:
```bash
git add pyproject.toml
git commit -m "chore: bump version to 0.1.0"
git push
```

#### 2. Create Git Tag

```bash
git tag v0.1.0
git push origin v0.1.0
```

#### 3. Create GitHub Release

1. Go to repository Releases page
2. Click "Draft a new release"
3. **Tag**: Select `v0.1.0`
4. **Title**: `v0.1.0`
5. **Description**: Write release notes (what's new, breaking changes, etc.)
6. Click "Publish release"

The workflow will automatically:
- Run tests
- Build the package
- Publish to PyPI

#### 4. Verify Publication

After ~2-5 minutes, check:
- https://pypi.org/project/fwkit/

Users can now install with:
```bash
pip install fwkit
```

### Testing Before Release (Optional)

To test publishing without creating a release:

1. Go to Actions tab
2. Select "Publish to PyPI" workflow
3. Click "Run workflow" → "Run workflow"
4. This will publish to **TestPyPI** only

Install from TestPyPI:
```bash
pip install --index-url https://test.pypi.org/simple/ fwkit
```

### Version Numbering

Follow [Semantic Versioning](https://semver.org/):
- **MAJOR** (1.0.0): Breaking changes
- **MINOR** (0.1.0): New features, backward compatible
- **PATCH** (0.0.1): Bug fixes

Development versions:
- Use `-dev` suffix: `0.1.0-dev`
- Use `-alpha`, `-beta`, `-rc1` for pre-releases

---

## 🔄 Release Checklist

Before creating a release:

- [ ] All tests passing (`uv run pytest`)
- [ ] Code quality checks passing (`uv run ruff check`, `uv run mypy`)
- [ ] Version updated in `pyproject.toml`
- [ ] CHANGELOG updated (if you have one)
- [ ] Documentation up to date
- [ ] Git tag created (`git tag v0.1.0`)
- [ ] Git tag pushed (`git push origin v0.1.0`)
- [ ] GitHub Release created with release notes

After release:

- [ ] Verify package on PyPI
- [ ] Test installation: `pip install fwkit`
- [ ] Bump version to next dev version: `0.2.0-dev`
- [ ] Update documentation if needed

---

## 🛠️ Troubleshooting

### GitHub Pages not updating

- Check Actions tab for workflow errors
- Verify Pages settings use "GitHub Actions" as source
- Check workflow permissions in Settings → Actions → General

### PyPI publish fails

- Verify Trusted Publishing is configured on PyPI
- Check workflow logs for specific errors
- Ensure tag matches version in `pyproject.toml`

### Build fails

```bash
# Test build locally
uv build

# Check dist/ folder
ls -lh dist/
```

---

## 📖 Additional Resources

- [GitHub Pages Documentation](https://docs.github.com/en/pages)
- [PyPI Trusted Publishing](https://docs.pypi.org/trusted-publishers/)
- [Semantic Versioning](https://semver.org/)
- [GitHub Releases Guide](https://docs.github.com/en/repositories/releasing-projects-on-github)
