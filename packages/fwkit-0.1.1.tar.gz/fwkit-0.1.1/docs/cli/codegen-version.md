# fwkit codegen version

Generate version header from Git repository information.

## Synopsis

```bash
fwkit codegen version [OPTIONS]
```

## Description

The `codegen version` command extracts version information from your Git repository and generates a C/C++ header file with version definitions. It uses Git tags for semantic versioning and repository metadata (commit hash, branch, dirty state) to create comprehensive version information.

This command is particularly useful for:

- Embedding build metadata into firmware binaries
- Tracking which exact code revision is deployed
- Automatically updating version strings from Git tags
- Including build timestamps in your application

The command uses **dunamai** internally to parse Git version information according to semantic versioning standards.

## Options

### Optional Options

| Option | Short | Type | Default | Description |
|--------|-------|------|---------|-------------|
| `--output` | `-o` | Path | `version.h` | Output file path for generated header |
| `--version-file` | `-v` | Path | None | Path to VERSION.txt file (uses Git tags if not provided) |
| `--repo-path` | `-r` | Path | Current directory | Path to Git repository root |
| `--template` | `-t` | Path | None | Custom template file (uses built-in template if not provided) |
| `--template-dir` | | Path | None | Directory containing custom templates |
| `--force` | `-f` | Boolean | False | Overwrite output file if it exists |

**Notes:**

- If `--version-file` is not provided, version is extracted from Git tags
- If `--template` is not provided, uses built-in `version.h.j2` template
- The command will fail if output file exists unless `--force` is used

## How It Works

**Implementation:** `fwkit/codegen/cli.py` + `fwkit/codegen/version.py`

1. **Version Extraction:** Uses `dunamai` to extract version from Git tags or VERSION.txt file
2. **Git Metadata:** Collects additional information (commit hash, branch, dirty state, timestamp)
3. **Template Rendering:** Processes Jinja2 template with version context
4. **Header Generation:** Writes C/C++ header file with version macros

### Version Information Collected

The following information is extracted and made available to templates:

- `major` - Major version number (from tag)
- `minor` - Minor version number (from tag)
- `patch` - Patch version number (from tag)
- `prerelease` - Prerelease identifier (e.g., "beta.1")
- `base` - Base version string (e.g., "1.2.3")
- `full` - Full version string with metadata (e.g., "1.2.3+42.abc123")
- `commit_hash_short` - Short commit hash (8 chars)
- `tag` - Git tag name
- `branch` - Current Git branch
- `is_dirty` - Boolean indicating uncommitted changes
- `describe` - Output of `git describe`
- `timestamp` - Build timestamp (ISO 8601 format)

### Template Variables

Templates receive all version information as context variables. The built-in template generates macros like:

```c
#define FW_VERSION_MAJOR 1
#define FW_VERSION_MINOR 2
#define FW_VERSION_PATCH 3
#define FW_VERSION_STRING "1.2.3"
#define FW_VERSION_STRING_FULL "1.2.3+42.abc123"
#define FW_GIT_COMMIT_HASH "abc12345"
#define FW_GIT_BRANCH "main"
#define FW_GIT_IS_DIRTY 0
#define FW_BUILD_TIMESTAMP "2026-02-16T10:30:00"
```

## VERSION.txt Format

When using `--version-file`, the file should contain a single line with semantic version format:

```
MAJOR.MINOR.PATCH[-PRERELEASE][+BUILD]
```

**Valid examples:**
```
1.2.3
1.2.3-beta.1
1.2.3+20240101
2.0.0-rc.1+build.123
```

**Invalid examples:**
```
1.2          # Missing patch
v1.2.3       # No 'v' prefix
1.2.3 beta   # Use dash: 1.2.3-beta
```

## Custom Templates

You can create custom Jinja2 templates to generate version files in different formats.

### Available Variables

| Variable | Example | Description |
|----------|---------|-------------|
| `major`, `minor`, `patch` | `1`, `2`, `3` | Version numbers |
| `base` | `"1.2.3"` | Base version string |
| `full` | `"1.2.3+42.abc123"` | Full version with metadata |
| `commit_hash_short` | `"abc12345"` | Short commit hash |
| `branch` | `"main"` | Git branch name |
| `tag` | `"v1.2.3"` | Git tag |
| `is_dirty` | `True`/`False` | Has uncommitted changes |
| `timestamp` | `"2026-02-16T10:30:00"` | Build timestamp |

### Example Templates

**Python module:**
```jinja2
__version__ = "{{ full }}"
__version_info__ = ({{ major }}, {{ minor }}, {{ patch }})

GIT_COMMIT = "{{ commit_hash_short }}"
BUILD_TIMESTAMP = "{{ timestamp }}"
```

**JSON format:**
```jinja2
{
  "version": "{{ base }}",
  "commit": "{{ commit_hash_short }}",
  "timestamp": "{{ timestamp }}"
}
```

**Custom C header:**
```jinja2
#ifndef MY_VERSION_H
#define MY_VERSION_H

#define VERSION "{{ base }}"
#define BUILD "{{ commit_hash_short }}"
{% if is_dirty %}
#warning "Built from dirty working directory"
{% endif %}

#endif
```

### Usage

```bash
# Create custom template
echo '#define APP_VERSION "{{ base }}"' > my_version.h.j2

# Generate with custom template
fwkit codegen version --template my_version.h.j2 --output version.h
```

## Examples

### Basic Usage

```bash
fwkit codegen version
```

Generates `version.h` in the current directory using Git tags from the repository.

### Custom Output Path

```bash
fwkit codegen version --output src/include/version.h
```

Generates the header file at a specific location in your project.

### Using VERSION.txt File

```bash
fwkit codegen version --version-file VERSION.txt --output version.h
```

Uses VERSION.txt as the base version instead of Git tags. Useful for projects without Git tags or non-Git repositories.

### Custom Template

```bash
fwkit codegen version --template my_version.h.j2 --output version.h
```

Uses a custom Jinja2 template to generate the header file with your own format.

### Force Overwrite

```bash
fwkit codegen version --output version.h --force
```

Overwrites existing version.h without prompting.

### Complete Example with All Options

```bash
fwkit codegen version \
  --output firmware/version.h \
  --repo-path /path/to/repo \
  --template custom_templates/version.h.j2 \
  --template-dir custom_templates \
  --force
```

## Output

### Console Output

The command displays extracted version information:

```
Extracting version information...

╭─ 📋 Version Info ──────────────────────────────╮
│                                                 │
│ Version Information:                            │
│   Base Version:   1.2.3                         │
│   Full Version:   1.2.3+42.abc12345             │
│   Git Describe:   v1.2.3-42-gabc12345           │
│   Commit:         abc12345                      │
│   Branch:         main                          │
│   Tag:            v1.2.3                        │
│   Dirty:          No                            │
│   Timestamp:      2026-02-16T10:30:00           │
│                                                 │
╰─────────────────────────────────────────────────╯

Generating header file...
✓ Version header generated: version.h
```

### Generated Header File

Example output `version.h`:

```c
/* Auto-generated version header */
/* DO NOT EDIT - Generated by fwkit codegen version */

#ifndef VERSION_H
#define VERSION_H

#define FW_VERSION_MAJOR 1
#define FW_VERSION_MINOR 2
#define FW_VERSION_PATCH 3
#define FW_VERSION_STRING "1.2.3"
#define FW_VERSION_STRING_FULL "1.2.3+42.abc12345"

#define FW_GIT_COMMIT_HASH "abc12345"
#define FW_GIT_BRANCH "main"
#define FW_GIT_TAG "v1.2.3"
#define FW_GIT_IS_DIRTY 0
#define FW_GIT_DESCRIBE "v1.2.3-42-gabc12345"

#define FW_BUILD_TIMESTAMP "2026-02-16T10:30:00"

#endif /* VERSION_H */
```

### Exit Codes

- `0` - Success
- `1` - Error (file exists without --force, template not found, Git error, etc.)

## Related Commands

- [fwkit ti ccs generate](ti-ccs-generate.md) - Often uses version headers in pre-build steps

## Common Issues

**Issue:** `Error: Not a git repository`
**Solution:** Run the command from within a Git repository or use `--repo-path` to specify the repository location.

**Issue:** `Error: No Git tags found`
**Solution:** Create a Git tag (e.g., `git tag v1.0.0`) or use `--version-file` with a VERSION.txt file instead.

**Issue:** `Warning: Output file already exists`
**Solution:** Use `--force` to overwrite the existing file, or specify a different `--output` path.

**Issue:** Custom template variables not working
**Solution:** Ensure your template uses the correct variable names (see Template Variables section). All variables are lowercase with underscores (e.g., `{{ major }}`, `{{ commit_hash_short }}`).
