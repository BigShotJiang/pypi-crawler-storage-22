# fwkit ti ccs build

Build a CCS project in workspace.

## Synopsis

```bash
fwkit ti ccs build --project <project_name> --workspace <workspace_path> [OPTIONS]
```

## Description

The `ti ccs build` command builds a Code Composer Studio project using the `ccs-server-cli` tool. This command provides a convenient command-line interface for building CCS projects without opening the IDE, making it ideal for automation, CI/CD pipelines, and scripted builds.

The command supports different build types (full, incremental, clean) and build configurations (Debug, Release, or custom configurations).

Key features:

- **Multiple build types:** Full rebuild, incremental build, or clean
- **Configuration support:** Build Debug, Release, or custom configurations
- **Intelligent error detection:** Parses CCS output for build failures
- **Auto-import:** Automatically imports projects not yet in workspace
- **Auto-discovery:** Finds CCS CLI installation automatically

## Options

### Required Options

| Option | Short | Type | Description |
|--------|-------|------|-------------|
| `--project` | `-p` | String | Project name in workspace |
| `--workspace` | `-w` | Path | Path to CCS workspace directory |

### Optional Options

| Option | Short | Type | Default | Description |
|--------|-------|------|---------|-------------|
| `--config` | `-c` | String | `Debug` | Build configuration (Debug, Release, or custom) |
| `--type` | `-t` | String | `full` | Build type: `full`, `incremental`, or `clean` |
| `--ccs-cli` | | Path | Auto-detected | Path to ccs-server-cli executable |

**Valid Build Types:**

- `full` - Complete rebuild (cleans then builds)
- `incremental` - Build only changed files
- `clean` - Clean build artifacts only (no build)

**Notes:**

- Project must exist in workspace (use [`fwkit ti ccs import`](ti-ccs-import.md) first)
- Configuration names are case-sensitive (usually `Debug` or `Release`)
- If `--ccs-cli` not specified, uses `CCS_SERVER_CLI` env var or searches common paths

## How It Works

**Implementation:** `fwkit/vendors/ti/cli.py` + `fwkit/vendors/ti/ccs_builder.py`

### Build Flow

1. **Validate Build Type:** Ensure build type is one of: full, incremental, clean
2. **Locate CCS CLI:** Check `--ccs-cli`, then `CCS_SERVER_CLI` env var, then common paths
3. **Verify Workspace:** Ensure workspace directory exists
4. **Execute Build:** Call `ccs-server-cli` with build parameters
   - Uses `-ccs.autoImport` to import projects not yet in workspace
   - Specifies project, configuration, and build type
5. **Monitor Output:** Capture stdout/stderr from CCS
6. **Error Detection:** Parse output for error patterns and build failure indicators
7. **Report Results:** Display success or detailed error information

### Error Detection

The builder detects various failure modes that may not be reflected in exit codes:

**Explicit Errors:**

- `!error:` - CCS explicit error marker
- `Build failed` - Build compilation/linking failure
- `An error has occurred` - Internal CCS error

**Workspace Issues:**

- `Project '...' was not found in the workspace` - Project not imported
- `0 out of 0 projects have errors` - No projects were built (wrong name/path)

**Summary Analysis:**

- Parses "X out of Y projects have errors" to detect failures
- Checks if any projects were actually built

### Build Type Behavior

**`full` (default):**

- Performs complete rebuild
- Equivalent to "Clean" + "Build" in CCS IDE
- Safest option, always produces fresh artifacts

**`incremental`:**

- Builds only files changed since last build
- Faster than full rebuild
- May miss changes to headers or build options

**`clean`:**

- Removes build artifacts only
- Does not compile/link
- Useful for cleanup without rebuilding

## Environment Variables

**CCS_SERVER_CLI**

- Path to `ccs-server-cli.sh` (Linux/macOS) or `ccs-server-cli.bat` (Windows)
- Used if `--ccs-cli` option is not provided

See [Installation](../installation.md#texas-instruments-ccs-setup) for setup instructions.

## Examples

### Basic Build (Debug Configuration)

```bash
fwkit ti ccs build \
  --project my_project_cc26x2r1 \
  --workspace ~/ccs-workspace
```

Performs full build of `my_project_cc26x2r1` in Debug configuration.

### Build Release Configuration

```bash
fwkit ti ccs build \
  --project my_project_cc26x2r1 \
  --workspace ~/ccs-workspace \
  --config Release
```

Builds Release configuration instead of Debug.

### Incremental Build

```bash
fwkit ti ccs build \
  --project my_project_cc26x2r1 \
  --workspace ~/ccs-workspace \
  --type incremental
```

Builds only changed files (faster for iterative development).

### Clean Build Artifacts

```bash
fwkit ti ccs build \
  --project my_project_cc26x2r1 \
  --workspace ~/ccs-workspace \
  --type clean
```

Removes build artifacts without rebuilding. Useful for cleanup or freeing disk space.

### Complete Example with All Options

```bash
fwkit ti ccs build \
  --project my_project_cc26x2r1 \
  --workspace ~/projects/ccs-workspace \
  --config Release \
  --type full \
  --ccs-cli /opt/ti/ccs1260/ccs/eclipse/ccs-server-cli.sh
```

## Output

### Console Output (Success)

```
Using CCS CLI: /opt/ti/ccs1260/ccs/eclipse/ccs-server-cli.sh
Building: my_project_cc26x2r1 (Debug - full)

✓ Build completed successfully!
```

### Console Output (Build Failure)

```
Using CCS CLI: /opt/ti/ccs1260/ccs/eclipse/ccs-server-cli.sh
Building: my_project_cc26x2r1 (Debug - full)

Build failed: ccs-server-cli returned code 0 but reported errors:
CCS summary reported project build errors (error: undefined reference to 'main')
```

### Build Artifacts

After successful build, artifacts are created in the workspace:

```
~/ccs-workspace/my_project_cc26x2r1/
├── Debug/                    # Build configuration directory
│   ├── my_project_cc26x2r1.out      # ELF executable
│   ├── my_project_cc26x2r1.hex      # Intel HEX file
│   ├── my_project_cc26x2r1.map      # Linker map file
│   ├── syscfg/                      # SysConfig generated files
│   └── ...                          # Object files and dependencies
└── ...
```

### Exit Codes

- `0` - Build succeeded
- `1` - Build failed (compilation error, linker error, CCS error, invalid build type, etc.)

## Related Commands

- [fwkit ti ccs import](ti-ccs-import.md) - Import project before building
- [fwkit ti ccs batch-build](ti-ccs-batch-build.md) - Build multiple variants in batch
- [fwkit ti ccs generate](ti-ccs-generate.md) - Generate projectspec files

## Common Issues

**Issue:** `Error: CCS server CLI not found`
**Solution:** Set `CCS_SERVER_CLI` environment variable or use `--ccs-cli` option. See [Installation Guide](../installation.md#texas-instruments-ccs-setup).

**Issue:** `Error: Project '...' was not found in the workspace`
**Solution:** The project hasn't been imported into the workspace. Import it first:
```bash
fwkit ti ccs import --projectspec my_project.projectspec --workspace ~/ccs-workspace
```

**Issue:** `Error: Invalid build type '...'`
**Solution:** Build type must be exactly one of: `full`, `incremental`, or `clean` (case-sensitive, lowercase).

**Issue:** Build fails with "undefined reference" errors
**Solution:** Check that:

- All source files are included in the project
- Libraries are correctly linked (check linker_build_options in YAML)
- Linker command file (.cmd) is correct

**Issue:** Incremental build doesn't pick up changes
**Solution:** Incremental builds may miss header changes or build option changes. Use `--type full` to force complete rebuild.

**Issue:** `Error: Workspace not found`
**Solution:** Ensure the workspace path is correct and exists. The workspace directory should contain a `.metadata` folder (created by CCS or import command).

**Issue:** Build succeeds but no .hex file generated
**Solution:** Check post-build steps in your YAML configuration. The hex file generation is typically done via a post-build step like:
```yaml
post_build_step: "${CG_TOOL_HEX} -order MS --memwidth=8 --romwidth=8 --intel \"${ProjName}.out\" \"${ProjName}.hex\""
```

**Issue:** Cannot open display error
**Solution:** CCS requires a display even for CLI builds. Use Xvfb in headless environments:
```bash
xvfb-run fwkit ti ccs build --project my_project --workspace ~/ccs-workspace
```
