# fwkit ti ccs generate

Generate TI CCS `.projectspec` files from YAML configuration.

## Synopsis

```bash
fwkit ti ccs generate --platforms <platforms.yaml> [OPTIONS]
```

## Description

The `ti ccs generate` command reads a platforms YAML configuration file and generates Code Composer Studio `.projectspec` XML files for importing projects into CCS.

This command enables configuration-driven project generation where you define your project settings once in YAML and generate project files for multiple hardware platforms, build configurations, and variants. It supports:

- **Multi-platform generation:** Generate projects for multiple MCU platforms from a single configuration
- **Default inheritance:** Define common settings once, override per-platform as needed
- **Flexible file management:** Copy, link, or exclude files with granular control
- **Custom templates:** Use your own Jinja2 templates for projectspec generation
- **Automatic FPU handling:** Cleanly manages floating-point compiler flags

## Options

### Required Options

| Option | Short | Type | Description |
|--------|-------|------|-------------|
| `--platforms` | `-p` | Path | Path to platforms YAML configuration file |

### Optional Options

| Option | Short | Type | Default | Description |
|--------|-------|------|---------|-------------|
| `--output` | `-o` | Path | `.` (current dir) | Output directory for generated .projectspec files |
| `--platform-id` | `-i` | String | None | Generate only for specific platform (default: all platforms) |
| `--subdirs` | `-s` | Boolean | False | Create subdirectory for each platform |
| `--template` | `-t` | Path | None | Custom projectspec template (uses built-in if not provided) |
| `--template-dir` | | Path | None | Directory containing custom templates |
| `--force` | `-f` | Boolean | False | Overwrite existing files |

**Notes:**

- Without `--platform-id`, generates projectspec files for ALL platforms defined in YAML
- `--subdirs` creates structure: `output/platform_id/platform_id.projectspec`
- Built-in template is `projectspec.xml.j2` if `--template` not specified

## How It Works

**Implementation:** `fwkit/vendors/ti/cli.py` + `fwkit/vendors/ti/projectspec_generator.py`

### Generation Flow

1. **Load Configuration:** Parse YAML file using Pydantic schemas (`PlatformsConfig`)
2. **Validate Platforms:** List all platforms and validate platform IDs
3. **Merge Defaults:** Combine platform-specific settings with defaults
4. **FPU Flag Cleanup:** Remove old `-mfloat-abi` and `-mfpu` flags, add new ones consistently
5. **Render Template:** Process Jinja2 template with merged configuration
6. **Write Projectspec:** Generate `.projectspec` XML file(s)

### Configuration Inheritance

The command uses a **defaults + overrides** pattern:

- `defaults` section defines common settings (compiler version, flags, files, etc.)
- Each platform inherits all defaults
- Platform-specific sections override defaults as needed
- Lists (compiler_build_options, files) are **merged** (defaults + platform)
- Scalars (compiler_version, device) are **replaced** by platform value

### FPU Handling

The generator automatically manages floating-point unit flags:

1. Removes any existing `-mfloat-abi=*` and `-mfpu=*` flags from compiler options
2. Adds clean FPU flags based on `mfloat_abi` and `mfpu` fields
3. Platform-specific FPU settings override defaults

This prevents duplicate or conflicting FPU flags in generated projects.

## Configuration File Format

The platforms YAML file must follow this structure:

```yaml
defaults:
  compiler_version: "4.0.4.LTS"
  tool_chain: "TICLANG"
  products: "com.ti.SIMPLELINK_CC13XX_CC26XX_SDK;sysconfig"
  mfloat_abi: "hard"
  mfpu: "fpv4-sp-d16"
  compiler_build_options:
    - "-mcpu=cortex-m4"
    - "-mthumb"
  linker_build_options:
    - "-l${COM_TI_SIMPLELINK_CC13XX_CC26XX_SDK_INSTALL_DIR}/source/ti/drivers/lib/drivers_cc26x2r1.lib"
  files:
    - path: "src/main.c"
      action: "link"

platform_id:  # e.g., cc26x2r1
  platform: "cc26x2r1"
  project_title: "My Project - CC26X2R1"
  project_name: "my_project_cc26x2r1"
  device: "Cortex M.CC2652R1F"
  link_file_path: "linker/cc26x2r1.cmd"
  # Optional overrides:
  compiler_build_options:  # Merged with defaults
    - "-DPLATFORM_CC26X2R1"
```

See [YAML Reference](../configuration/yaml-reference.md) for complete schema documentation.

## Examples

### Generate All Platforms

```bash
fwkit ti ccs generate --platforms platforms.yaml
```

Generates `.projectspec` files for all platforms in the current directory:

- `cc26x2r1.projectspec`
- `cc1352p7.projectspec`
- ...

### Generate Specific Platform

```bash
fwkit ti ccs generate --platforms platforms.yaml --platform-id cc26x2r1
```

Generates only `cc26x2r1.projectspec`.

### Generate with Subdirectories

```bash
fwkit ti ccs generate --platforms platforms.yaml --subdirs
```

Creates organized structure:
```
./
├── cc26x2r1/
│   └── cc26x2r1.projectspec
├── cc1352p7/
│   └── cc1352p7.projectspec
└── ...
```

### Custom Output Directory

```bash
fwkit ti ccs generate \
  --platforms config/platforms.yaml \
  --output build/projects \
  --subdirs
```

Generates projects in `build/projects/` with subdirectories.

### Custom Template

```bash
fwkit ti ccs generate \
  --platforms platforms.yaml \
  --template my_templates/custom.projectspec.j2 \
  --template-dir my_templates
```

Uses custom Jinja2 template instead of built-in.

### Force Overwrite

```bash
fwkit ti ccs generate --platforms platforms.yaml --force
```

Overwrites existing `.projectspec` files without prompting.

## Output

### Console Output

```
Loading platforms configuration...
✓ Loaded 3 platform(s)

┏━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━┓
┃ Platform ID ┃ Device          ┃ Project Name          ┃
┡━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━┩
│ cc26x2r1    │ Cortex M.CC26...│ my_project_cc26x2r1   │
│ cc1352p7    │ Cortex M.CC13...│ my_project_cc1352p7   │
│ cc2674p10   │ Cortex M.CC26...│ my_project_cc2674p10  │
└─────────────┴─────────────────┴───────────────────────┘

Generating .projectspec file(s)...
✓ Generated [cc26x2r1]: cc26x2r1.projectspec
✓ Generated [cc1352p7]: cc1352p7.projectspec
✓ Generated [cc2674p10]: cc2674p10.projectspec

✓ Generation complete!
Output directory: /home/user/project
```

### Generated Files

Each `.projectspec` file is an XML document compatible with CCS. Example structure:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<projectSpec>
    <applicability>
        <when>
            <context deviceFamily="ARM" deviceId="Cortex M.CC2652R1F"/>
        </when>
    </applicability>
    <project name="my_project_cc26x2r1" ...>
        <!-- Build options, files, configurations -->
    </project>
</projectSpec>
```

### Exit Codes

- `0` - Success
- `1` - Error (invalid YAML, platform not found, file exists without --force, etc.)

## Related Commands

- [fwkit ti ccs import](ti-ccs-import.md) - Import generated projectspec into CCS workspace
- [fwkit ti ccs build](ti-ccs-build.md) - Build imported projects

## Common Issues

**Issue:** `Error: Invalid configuration: missing required field 'compiler_version'`
**Solution:** Ensure your YAML has a `defaults` section with `compiler_version` specified.

**Issue:** `Error: Platform 'xyz' not found in configuration`
**Solution:** Check that the platform ID passed to `--platform-id` exactly matches a key in your YAML file (case-sensitive).

**Issue:** Generated projectspec has duplicate compiler flags
**Solution:** The generator automatically deduplicates FPU flags. If you see other duplicates, check that defaults and platform sections aren't both defining the same flag.

**Issue:** `Warning: Output file already exists`
**Solution:** Use `--force` to overwrite, or use `--subdirs` to organize outputs in separate directories.

**Issue:** YAML validation errors
**Solution:** Use a YAML linter to check syntax. Ensure required fields (`platform`, `project_title`, `project_name`, `device`) are present for each platform. See [YAML Reference](../configuration/yaml-reference.md) for the complete schema.
