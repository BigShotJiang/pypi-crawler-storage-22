# fwkit ti ccs import

Import `.projectspec` file into CCS workspace.

## Synopsis

```bash
fwkit ti ccs import --projectspec <file.projectspec> --workspace <workspace_path> [OPTIONS]
```

## Description

The `ti ccs import` command imports a Code Composer Studio `.projectspec` file into a CCS workspace using the `ccs-server-cli` tool. This command is a convenient wrapper around CCS's command-line interface that handles path resolution, workspace creation, and error detection.

After generation with [`fwkit ti ccs generate`](ti-ccs-generate.md), this command brings the project into CCS where it can be built, debugged, and modified.

Key features:

- **Automatic workspace creation:** Creates workspace directory if it doesn't exist
- **Intelligent error detection:** Parses CCS output for common error patterns
- **Auto-discovery of CCS CLI:** Searches common installation paths if not specified
- **Project location control:** Optionally specify where project files are created

## Options

### Required Options

| Option | Short | Type | Description |
|--------|-------|------|-------------|
| `--projectspec` | `-p` | Path | Path to .projectspec file to import |
| `--workspace` | `-w` | Path | Path to CCS workspace directory |

### Optional Options

| Option | Short | Type | Default | Description |
|--------|-------|------|---------|-------------|
| `--location` | `-l` | Path | Projectspec directory | Project location (directory where project files are created) |
| `--ccs-cli` | | Path | Auto-detected | Path to ccs-server-cli executable |

**Notes:**

- If `--location` is not specified, uses the directory containing the `.projectspec` file
- If `--ccs-cli` is not specified, uses `CCS_SERVER_CLI` environment variable or searches common paths

## How It Works

**Implementation:** `fwkit/vendors/ti/cli.py` + `fwkit/vendors/ti/ccs_project.py`

### Import Flow

1. **Locate CCS CLI:** Check `--ccs-cli`, then `CCS_SERVER_CLI` env var, then common paths
2. **Validate Inputs:** Ensure `.projectspec` file exists
3. **Create Workspace:** Create workspace directory if it doesn't exist
4. **Determine Project Location:** Use `--location` or default to projectspec directory
5. **Execute CCS Import:** Call `ccs-server-cli` with import parameters
6. **Error Detection:** Parse stdout/stderr for error patterns (CCS sometimes returns exit code 0 even on failure)
7. **Report Results:** Display success or detailed error information

### CCS CLI Auto-Detection

If `--ccs-cli` is not provided, the command searches for `ccs-server-cli` in this order:

1. **Environment variable:** `CCS_SERVER_CLI`
2. **Common Linux paths:**
   - `~/ti/ccs*/ccs/eclipse/ccs-server-cli.sh`
   - `/opt/ti/ccs*/ccs/eclipse/ccs-server-cli.sh`
3. **Common Windows paths:**
   - `C:\ti\ccs*\ccs\eclipse\ccs-server-cli.bat`
4. **Common macOS paths:**
   - `/Applications/ti/ccs*/ccs/eclipse/ccs-server-cli.sh`

Glob patterns (`ccs*`) match multiple CCS versions and use the most recent.

### Error Detection Patterns

The command detects CCS errors that don't propagate via exit codes:

- `!error:` - Explicit CCS error
- `An error has occurred. See the log file` - Internal CCS error
- `Error reading configuration` - Configuration problem
- `Cannot open display` - Display unavailable (common in headless/CI environments)

## Environment Variables

**CCS_SERVER_CLI**

- Path to `ccs-server-cli.sh` (Linux/macOS) or `ccs-server-cli.bat` (Windows)
- Used if `--ccs-cli` option is not provided
- Example: `export CCS_SERVER_CLI="/opt/ti/ccs1260/ccs/eclipse/ccs-server-cli.sh"`

See [Installation](../installation.md#texas-instruments-ccs-setup) for setup instructions.

## Examples

### Basic Import

```bash
fwkit ti ccs import \
  --projectspec my_project.projectspec \
  --workspace ~/ccs-workspace
```

Imports project into `~/ccs-workspace`. Project files are created in the same directory as the `.projectspec` file.

### Import with Custom Project Location

```bash
fwkit ti ccs import \
  --projectspec build/projects/cc26x2r1.projectspec \
  --workspace ~/ccs-workspace \
  --location ~/projects/my_firmware
```

Imports the project but creates project files in `~/projects/my_firmware` instead of `build/projects/`.

### Import with Explicit CCS CLI Path

```bash
fwkit ti ccs import \
  --projectspec my_project.projectspec \
  --workspace ~/ccs-workspace \
  --ccs-cli /opt/ti/ccs1260/ccs/eclipse/ccs-server-cli.sh
```

Uses specific CCS installation when multiple versions are installed or auto-detection fails.

### Import Multiple Projects (Shell Loop)

```bash
for spec in build/projects/*.projectspec; do
  fwkit ti ccs import \
    --projectspec "$spec" \
    --workspace ~/ccs-workspace
done
```

Imports all `.projectspec` files from a directory.

## Output

### Console Output (Success)

```
Using CCS CLI: /opt/ti/ccs1260/ccs/eclipse/ccs-server-cli.sh
Importing: my_project.projectspec into workspace

✓ Project imported successfully!
Workspace: /home/user/ccs-workspace
```

### Console Output (Error)

```
Using CCS CLI: /opt/ti/ccs1260/ccs/eclipse/ccs-server-cli.sh
Importing: my_project.projectspec into workspace

Error importing project: ccs-server-cli returned code 0 but reported errors:
CCS reported an explicit error (!error: Project already exists)
```

### CCS Workspace Structure

After import, the workspace contains:

```
~/ccs-workspace/
├── .metadata/          # CCS workspace metadata
├── my_project/         # Imported project (if using default location)
│   ├── .project
│   ├── .cproject
│   ├── .settings/
│   └── src/
└── ...
```

If you used `--location`, the project directory is created at that location (can be outside workspace).

### Exit Codes

- `0` - Success
- `1` - Error (projectspec not found, CCS CLI not found, import failed, etc.)

## Related Commands

- [fwkit ti ccs generate](ti-ccs-generate.md) - Generate projectspec files before importing
- [fwkit ti ccs build](ti-ccs-build.md) - Build imported projects

## Common Issues

**Issue:** `Error: CCS server CLI not found`
**Solution:** Set `CCS_SERVER_CLI` environment variable or use `--ccs-cli` option. See [Installation Guide](../installation.md#texas-instruments-ccs-setup).

**Issue:** `Error: Cannot open display`
**Solution:** This occurs when running in headless environments (CI/CD, SSH without X11). CCS requires a display even for CLI operations. Solutions:

- Use Xvfb: `xvfb-run fwkit ti ccs import ...`
- Configure X11 forwarding for SSH sessions
- Run on a system with a display

**Issue:** `Error: Project already exists in workspace`
**Solution:** The project name conflicts with an existing project. Either:

- Delete the existing project from CCS
- Use a different workspace with `--workspace`
- Rename the project in your YAML configuration

**Issue:** Import succeeds but project files are in wrong location
**Solution:** Use `--location` to explicitly specify where project files should be created. By default, they are created in the same directory as the `.projectspec` file.

**Issue:** `Error reading configuration` or workspace corruption
**Solution:** The workspace metadata may be corrupted. Try:

- Create a new workspace directory
- Delete `.metadata` folder from workspace (WARNING: loses workspace settings)
- Ensure workspace path doesn't contain special characters or spaces
