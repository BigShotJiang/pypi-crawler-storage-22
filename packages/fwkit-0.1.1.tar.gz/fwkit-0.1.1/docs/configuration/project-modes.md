# Project Modes

Two approaches for organizing CCS projects with fwkit: Root Project Mode and Build Subdirectory Mode.

## Overview

fwkit supports two different project organization patterns, each suited for different workflows:

1. **Root Project Mode** - For local development in IDE
2. **Build Subdirectory Mode** - For CI/CD and multi-platform builds

The choice affects where `.projectspec` files are generated, how files are accessed (direct vs linked), and how build artifacts are organized.

---

## Root Project Mode

Generate CCS project directly in your repository root with direct access to source files.

### When to Use

- 👨‍💻 **Local development** in CCS IDE
- 🔍 All source files visible in Project Explorer
- 🎯 Working on **one platform** at a time
- ⚡ Direct file editing without symbolic links
- 🚀 Simple project structure for beginners

### How It Works

The `.projectspec` file is generated in your **repository root**. When imported into CCS, the project accesses files **directly** from their actual locations.

**Repository Structure:**
```
my-firmware/
├── .project              ← CCS creates this
├── .cproject             ← CCS creates this
├── my_device.projectspec ← Generated here
├── src/
│   ├── main.c           ← Accessed directly
│   └── system.c         ← Accessed directly
├── platforms/
│   └── cc2652r1/
│       └── config.syscfg ← Copied to root
└── scripts/
    └── gen_version.py
```

### Configuration Example

```yaml
# File: platforms/dev.yaml
defaults:
  compiler_version: "4.0.4.LTS"

  # PROJECT_LOC is repository root
  compiler_build_options:
    - "-I${PROJECT_LOC}/src"
    - "-I${PROJECT_LOC}/src/api"

  pre_build_step: "${PYTHON_CMD} ${PROJECT_LOC}/scripts/gen_version.py --output ${PROJECT_LOC}/src/version.h"

  files:
    # Exclude folders from build (but they exist in filesystem)
    - path: "platforms"
      action: "copy"
      exclude_from_build: true

    - path: "test"
      action: "copy"
      exclude_from_build: true

    - path: "build"
      action: "copy"
      exclude_from_build: true

    # Copy platform-specific files to root
    - path: "platforms/cc2652r1/config.syscfg"
      action: "copy"

    - path: "platforms/cc2652r1/linker.cmd"
      action: "copy"

cc2652r1_dev:
  platform: "cc2652r1_dev"
  project_title: "My Project - Development"
  project_name: "my_project_dev"
  device: "Cortex M.CC2652R1F"
  link_file_path: "linker.cmd"
```

### Usage

```bash
# Generate .projectspec in repository root
cd ~/my-firmware
fwkit ti ccs generate \
  --platforms platforms/dev.yaml \
  --output .

# Import into CCS
fwkit ti ccs import \
  --projectspec my_project_dev.projectspec \
  --workspace ~/ccs-workspace
```

### Advantages

✅ **Simple project structure** - All files in one place
✅ **Direct file access** - No symbolic links to understand
✅ **IDE integration** - Autocomplete and navigation work naturally
✅ **Debugging friendly** - Source files shown at actual locations
✅ **Beginner friendly** - Minimal cognitive overhead

### Disadvantages

❌ **CCS files in repository** - `.project`, `.cproject` clutter root directory
❌ **One platform at a time** - Can't work on multiple platforms simultaneously
❌ **Gitignore required** - Must ignore CCS project files
❌ **No artifact isolation** - Debug/Release folders mix with source

---

## Build Subdirectory Mode

Generate separate CCS projects in subdirectories for each platform with linked source files.

### When to Use

- 🏗️ **CI/CD builds** for multiple platforms
- 📦 Multiple platform variants in same workspace
- 🧹 Build artifacts isolated per platform
- 🔗 Comfortable with symbolic links
- 🚀 Production build automation

### How It Works

Each platform gets its own subdirectory (e.g., `build/cc2652r1/`), and source files are **linked** from the repository using relative paths (`../../`).

**Repository Structure:**
```
my-firmware/
├── src/
│   ├── main.c
│   └── system.c
├── platforms/
│   ├── cc2652r1/
│   │   ├── config.syscfg
│   │   └── linker.cmd
│   └── cc2652r7/
│       ├── config.syscfg
│       └── linker.cmd
├── scripts/
│   └── gen_version.py
└── build/
    ├── cc2652r1/               ← Platform 1 project
    │   ├── .project
    │   ├── .cproject
    │   ├── cc2652r1.projectspec
    │   ├── src@ → ../../src    ← Symbolic link
    │   └── scripts@ → ../../scripts
    └── cc2652r7/               ← Platform 2 project
        ├── .project
        ├── .cproject
        ├── cc2652r7.projectspec
        ├── src@ → ../../src
        └── scripts@ → ../../scripts
```

### Configuration Example

```yaml
# File: platforms/ci.yaml
defaults:
  compiler_version: "4.0.4.LTS"

  # PROJECT_LOC is build/platform_name/ so use ../../ to reach root
  compiler_build_options:
    - "-I${PROJECT_LOC}/../../src"
    - "-I${PROJECT_LOC}/../../src/api"

  pre_build_step: "${PYTHON_CMD} ${PROJECT_LOC}/../../scripts/gen_version.py --output ${PROJECT_LOC}/../../src/version.h"

  files:
    # Link entire source directory
    - path: "../../src"
      action: "link"
      target_directory: "src"

    # Link scripts directory
    - path: "../../scripts"
      action: "link"
      target_directory: "scripts"

    # Link individual files
    - path: "../../VERSION.txt"
      action: "link"

    - path: "../../README.md"
      action: "link"
      exclude_from_build: true

cc2652r1_ci:
  platform: "cc2652r1_ci"
  project_title: "My Project - CC2652R1"
  project_name: "cc2652r1_ci"
  device: "Cortex M.CC2652R1F"

  files:
    # Link platform-specific files with target_directory
    - path: "../../platforms/cc2652r1/config.syscfg"
      action: "copy"

    - path: "../../platforms/cc2652r1/linker.cmd"
      action: "copy"

cc2652r7_ci:
  platform: "cc2652r7_ci"
  project_title: "My Project - CC2652R7"
  project_name: "cc2652r7_ci"
  device: "Cortex M.CC2652R7"

  files:
    - path: "../../platforms/cc2652r7/config.syscfg"
      action: "copy"

    - path: "../../platforms/cc2652r7/linker.cmd"
      action: "copy"
```

### Usage

```bash
# Generate .projectspec files in build subdirectories
cd ~/my-firmware
fwkit ti ccs generate \
  --platforms platforms/ci.yaml \
  --output build/ \
  --subdirs

# This creates:
#   build/cc2652r1_ci/cc2652r1_ci.projectspec
#   build/cc2652r7_ci/cc2652r7_ci.projectspec

# Import all into same workspace
fwkit ti ccs import \
  --projectspec build/cc2652r1_ci/cc2652r1_ci.projectspec \
  --workspace ~/ccs-workspace

fwkit ti ccs import \
  --projectspec build/cc2652r7_ci/cc2652r7_ci.projectspec \
  --workspace ~/ccs-workspace

# Build all platforms
fwkit ti ccs build \
  --project cc2652r1_ci \
  --workspace ~/ccs-workspace

fwkit ti ccs build \
  --project cc2652r7_ci \
  --workspace ~/ccs-workspace
```

### Advantages

✅ **Multiple platforms** - Work on all platforms in same workspace
✅ **Artifact isolation** - Each platform has separate Debug/Release
✅ **Clean repository** - Build files stay in `build/`, not root
✅ **CI/CD friendly** - Easy to automate multi-platform builds
✅ **Source sharing** - Changes reflect across all platform projects

### Disadvantages

❌ **Symbolic links** - Files shown as links (`→`) in Project Explorer
❌ **Path complexity** - Must understand relative paths (`../../`)
❌ **More directories** - Slightly more complex structure
❌ **Link management** - Need to ensure symlinks are created correctly

---

## Path Variables Reference

Both modes use CCS path variables. Understanding these is critical:

| Variable | Root Mode | Subdirectory Mode | Description |
|----------|-----------|-------------------|-------------|
| `${PROJECT_LOC}` | Repository root | `build/platform/` | Location where `.projectspec` resides |
| `${PROJECT_ROOT}` | Workspace | Workspace | CCS workspace location |
| `${ConfigName}` | `Debug`/`Release` | `Debug`/`Release` | Build configuration name |
| `${ProjName}` | Project name | Project name | Project name |
| `${COM_TI_*}` | SDK path | SDK path | TI SDK installation directory |

### Path Examples

**Root Mode:**
```yaml
compiler_build_options:
  - "-I${PROJECT_LOC}/src"                    # → /my-firmware/src
  - "-I${PROJECT_LOC}/platforms/cc2652r1"     # → /my-firmware/platforms/cc2652r1

pre_build_step: "${PYTHON_CMD} ${PROJECT_LOC}/scripts/build.py"
```

**Subdirectory Mode:**
```yaml
compiler_build_options:
  - "-I${PROJECT_LOC}/../../src"              # → /my-firmware/src
  - "-I${PROJECT_LOC}/../../platforms/cc2652r1"  # → /my-firmware/platforms/cc2652r1

pre_build_step: "${PYTHON_CMD} ${PROJECT_LOC}/../../scripts/build.py"
```

---

## File Actions by Mode

### Root Mode File Actions

**Copy platform-specific files:**
```yaml
files:
  - path: "platforms/cc2652r1/config.syscfg"
    action: "copy"  # Copied to project root

  - path: "platforms/cc2652r1/linker.cmd"
    action: "copy"
```

**Exclude directories from build:**
```yaml
files:
  - path: "test"
    action: "copy"
    exclude_from_build: true

  - path: "build"
    action: "copy"
    exclude_from_build: true
```

### Subdirectory Mode File Actions

**Link source directories:**
```yaml
files:
  - path: "../../src"
    action: "link"
    target_directory: "src"

  - path: "../../scripts"
    action: "link"
    target_directory: "scripts"
```

**Copy platform-specific configs:**
```yaml
files:
  - path: "../../platforms/cc2652r1/config.syscfg"
    action: "copy"  # Platform-specific, should be copied

  - path: "../../platforms/cc2652r1/linker.cmd"
    action: "copy"
```

---

## Comparison Table

| Aspect | Root Mode | Subdirectory Mode |
|--------|-----------|-------------------|
| **Projectspec location** | Repository root | `build/platform/` |
| **Source file access** | Direct | Symbolic links |
| **Multiple platforms** | ❌ One at a time | ✅ All in workspace |
| **Repository cleanliness** | ❌ CCS files in root | ✅ Build files isolated |
| **Path complexity** | ✅ Simple paths | ⚠️ Relative paths (`../../`) |
| **IDE experience** | ✅ Natural | ⚠️ Links shown |
| **CI/CD suitability** | ⚠️ Manual switching | ✅ Batch builds |
| **Beginner friendly** | ✅ Easy to understand | ⚠️ Requires understanding |

---

## Best Practices

### For Root Mode (Development)

1. **Add CCS files to `.gitignore`:**
   ```gitignore
   .project
   .cproject
   .settings/
   Debug/
   Release/
   *.projectspec
   ```

2. **Use separate YAML for development**
   - `platforms/dev.yaml` for local development
   - `platforms/ci.yaml` for CI/CD builds

3. **Exclude non-source directories**
   ```yaml
   files:
     - { path: "test", action: "copy", exclude_from_build: true }
     - { path: "docs", action: "copy", exclude_from_build: true }
     - { path: "build", action: "copy", exclude_from_build: true }
   ```

4. **Copy platform-specific files**
   ```yaml
   files:
     - { path: "platforms/cc2652r1/config.syscfg", action: "copy" }
   ```

### For Subdirectory Mode (CI/CD)

1. **Add `build/` directory to `.gitignore`:**
   ```gitignore
   build/
   ```

2. **Use `link` action for shared source**
   ```yaml
   files:
     - { path: "../../src", action: "link", target_directory: "src" }
     - { path: "../../scripts", action: "link", target_directory: "scripts" }
   ```

3. **Use `target_directory` for organization**
   ```yaml
   files:
     - path: "../../platforms/cc2652r1"
       action: "link"
       target_directory: "platform_config"
   ```

4. **Keep relative paths consistent**
   - Always use `../../` to reach repository root from `build/platform/`
   - Test paths by checking generated `.projectspec`

5. **Test each platform independently**
   ```bash
   fwkit ti ccs build --project platform1 --workspace ~/workspace
   fwkit ti ccs build --project platform2 --workspace ~/workspace
   ```

### General Best Practices

- ✅ Use descriptive project names (e.g., `my_project_cc26x2r1_dev`, `my_project_cc26x2r1_ci`)
- ✅ Comment complex path configurations in YAML
- ✅ Keep platform-specific files in `platforms/` directory
- ✅ Test import before committing YAML changes
- ✅ Document platform-specific compiler defines

---

## Migration Between Modes

### From Root Mode to Subdirectory Mode

1. Create new YAML configuration with subdirectory paths
2. Update `compiler_build_options` paths: `/src` → `/../../src`
3. Update `pre_build_step`/`post_build_step` paths
4. Change `files` action from `copy` to `link` for source files
5. Add `../../` prefix to all file paths
6. Generate with `--subdirs` flag

### From Subdirectory Mode to Root Mode

1. Create new YAML configuration without subdirectory paths
2. Update `compiler_build_options` paths: `/../../src` → `/src`
3. Update build steps to remove `../../`
4. Change source `files` from `link` to `exclude_from_build: true`
5. Remove `../../` prefix from file paths
6. Generate without `--subdirs` flag

---

## Troubleshooting

**Issue:** File not found errors during build (Root Mode)
**Solution:** Verify `${PROJECT_LOC}` paths don't include `../../`:
```yaml
# Correct for root mode
- "-I${PROJECT_LOC}/src"

# Wrong (subdirectory mode path)
- "-I${PROJECT_LOC}/../../src"
```

**Issue:** File not found errors during build (Subdirectory Mode)
**Solution:** Verify `${PROJECT_LOC}` paths include `../../`:
```yaml
# Correct for subdirectory mode
- "-I${PROJECT_LOC}/../../src"

# Wrong (root mode path)
- "-I${PROJECT_LOC}/src"
```

**Issue:** Linked files show "broken link" in CCS
**Solution:** If `.projectspec` is in `build/platform_name/`, paths must be `../../`:
```yaml
files:
  - path: "../../src"  # Not ../src or src
    action: "link"
```

**Issue:** Can't see source files in Project Explorer (Subdirectory Mode)
**Solution:** Add source directory to linked files:
```yaml
files:
  - path: "../../src"
    action: "link"
    target_directory: "src"
```

**Issue:** Multiple platforms conflict with same project name
**Solution:** Use unique `project_name` per platform:
```yaml
cc2652r1:
  project_name: "myapp_cc2652r1"

cc2652r7:
  project_name: "myapp_cc2652r7"
```

---

## Examples

See complete working examples:

- [`ti_ccs_root_project.yaml`](https://github.com/AcenoTecnologia/fwkit/tree/main/examples/ti_ccs_root_project.yaml) - Root project mode
- [`ti_ccs_build_subdirs.yaml`](https://github.com/AcenoTecnologia/fwkit/tree/main/examples/ti_ccs_build_subdirs.yaml) - Subdirectory mode

---

## Related Documentation

- [YAML Reference](yaml-reference.md) - Complete schema documentation
- [Target Directory](target-directory.md) - Organizing linked files
- [fwkit ti ccs generate](../cli/ti-ccs-generate.md) - Generate command reference
