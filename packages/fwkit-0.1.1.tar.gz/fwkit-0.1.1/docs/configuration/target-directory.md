# Target Directory

Organize linked files in custom directories within CCS projects.

## Overview

The `target_directory` feature allows you to organize linked files into custom directory structures within your CCS project, rather than placing all linked files flat in the project root.

**When to use:**

- Organizing linked source files by category (platform, drivers, config, shared)
- Maintaining clean project structure in CCS IDE
- Separating build subdirectory mode linked files into logical folders
- Matching source repository directory structure in CCS

**Available since:** fwkit 0.1.0+

## How It Works

When you specify `target_directory` for a file with `action: "link"`:

1. CCS creates the target directory path in the project
2. Symlink is created inside that directory
3. File appears in the directory tree in CCS IDE
4. Build system correctly resolves the linked file

**Without `target_directory`:**
```
Project/
├── main.c (link)
├── config.c (link)
├── driver.c (link)
└── ...
```

**With `target_directory`:**
```
Project/
├── config/
│   └── config.c (link)
├── drivers/
│   └── driver.c (link)
└── src/
    └── main.c (link)
```

## Configuration

Add `target_directory` to files with `action: "link"` in your YAML configuration:

```yaml
files:
  - path: "src/main.c"
    action: "link"
    target_directory: "src"

  - path: "config/app_config.c"
    action: "link"
    target_directory: "config"

  - path: "drivers/uart.c"
    action: "link"
    target_directory: "drivers"
```

### Field Specification

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `target_directory` | String | No | Directory path where linked file will appear in CCS project |

**Notes:**

- Only applies when `action: "link"`
- Path is relative to project root
- Can include multiple levels (e.g., "platform/cc26x2r1")
- Directory is created automatically if it doesn't exist
- Use forward slashes (`/`) even on Windows

## Use Cases

### Use Case 1: Build Subdirectory Mode

When using [build subdirectory mode](project-modes.md#build-subdirectory-mode), all source files are linked from the parent directory. Use `target_directory` to organize them:

**Repository structure:**
```
my_firmware/
├── src/
│   ├── main.c
│   ├── system.c
│   └── config.c
├── drivers/
│   ├── uart.c
│   └── spi.c
└── build/
    └── cc26x2r1/        ← CCS project here
```

**Configuration:**
```yaml
defaults:
  files:
    # Organize source files
    - path: "../src/main.c"
      action: "link"
      target_directory: "src"

    - path: "../src/system.c"
      action: "link"
      target_directory: "src"

    - path: "../src/config.c"
      action: "link"
      target_directory: "src"

    # Organize drivers
    - path: "../drivers/uart.c"
      action: "link"
      target_directory: "drivers"

    - path: "../drivers/spi.c"
      action: "link"
      target_directory: "drivers"
```

**Resulting CCS project structure:**
```
build/cc26x2r1/
├── src/
│   ├── main.c → ../../src/main.c
│   ├── system.c → ../../src/system.c
│   └── config.c → ../../src/config.c
├── drivers/
│   ├── uart.c → ../../drivers/uart.c
│   └── spi.c → ../../drivers/spi.c
└── .projectspec
```

### Use Case 2: Platform-Specific Organization

Separate platform-specific files from shared code:

```yaml
defaults:
  # Shared application code
  files:
    - path: "src/app/main.c"
      action: "link"
      target_directory: "app"

    - path: "src/app/logic.c"
      action: "link"
      target_directory: "app"

cc26x2r1:
  platform: "cc26x2r1"
  # ...
  files:
    # Platform-specific initialization
    - path: "src/platform/cc26x2r1/init.c"
      action: "link"
      target_directory: "platform/cc26x2r1"

    - path: "src/platform/cc26x2r1/board.c"
      action: "link"
      target_directory: "platform/cc26x2r1"

cc1352p7:
  platform: "cc1352p7"
  # ...
  files:
    # Different platform-specific files
    - path: "src/platform/cc1352p7/init.c"
      action: "link"
      target_directory: "platform/cc1352p7"
```

**Result in cc26x2r1 project:**
```
cc26x2r1/
├── app/
│   ├── main.c (link)
│   └── logic.c (link)
└── platform/
    └── cc26x2r1/
        ├── init.c (link)
        └── board.c (link)
```

### Use Case 3: Matching Source Repository Structure

Mirror your repository structure in CCS:

**Repository:**
```
firmware/
├── application/
│   └── main.c
├── middleware/
│   └── protocol.c
├── hal/
│   └── gpio.c
└── config/
    └── app_config.c
```

**Configuration:**
```yaml
files:
  - path: "application/main.c"
    action: "link"
    target_directory: "application"

  - path: "middleware/protocol.c"
    action: "link"
    target_directory: "middleware"

  - path: "hal/gpio.c"
    action: "link"
    target_directory: "hal"

  - path: "config/app_config.c"
    action: "link"
    target_directory: "config"
```

**CCS project mirrors repository structure:**
```
Project/
├── application/
│   └── main.c (link)
├── middleware/
│   └── protocol.c (link)
├── hal/
│   └── gpio.c (link)
└── config/
    └── app_config.c (link)
```

### Use Case 4: SDK Files Organization

Organize TI SDK files separately from application code:

```yaml
files:
  # Application code
  - path: "src/main.c"
    action: "link"
    target_directory: "src"

  # SDK startup files
  - path: "${COM_TI_SIMPLELINK_CC13XX_CC26XX_SDK_INSTALL_DIR}/source/ti/devices/cc13x2_cc26x2/startup_files/startup_ticlang.c"
    action: "link"
    target_directory: "ti/startup"

  # SDK drivers
  - path: "${COM_TI_SIMPLELINK_CC13XX_CC26XX_SDK_INSTALL_DIR}/source/ti/drivers/UART2.c"
    action: "link"
    target_directory: "ti/drivers"
```

**Result:**
```
Project/
├── src/
│   └── main.c (link)
└── ti/
    ├── startup/
    │   └── startup_ticlang.c (link to SDK)
    └── drivers/
        └── UART2.c (link to SDK)
```

## Comparison: With vs Without target_directory

### Without target_directory (Flat Structure)

```yaml
files:
  - { path: "src/main.c", action: "link" }
  - { path: "src/config.c", action: "link" }
  - { path: "drivers/uart.c", action: "link" }
  - { path: "drivers/spi.c", action: "link" }
```

**CCS Project View:**
```
Project/
├── main.c
├── config.c
├── uart.c
└── spi.c
```

All files flat in root - hard to navigate with many files.

### With target_directory (Organized Structure)

```yaml
files:
  - { path: "src/main.c", action: "link", target_directory: "src" }
  - { path: "src/config.c", action: "link", target_directory: "src" }
  - { path: "drivers/uart.c", action: "link", target_directory: "drivers" }
  - { path: "drivers/spi.c", action: "link", target_directory: "drivers" }
```

**CCS Project View:**
```
Project/
├── src/
│   ├── main.c
│   └── config.c
└── drivers/
    ├── uart.c
    └── spi.c
```

Organized by category - easier navigation and understanding.

## Inline Format Example

Using compact inline YAML format:

```yaml
files:
  # Source files
  - { path: "src/main.c", action: "link", target_directory: "src" }
  - { path: "src/system.c", action: "link", target_directory: "src" }
  - { path: "src/event.c", action: "link", target_directory: "src" }

  # Configuration
  - { path: "config/app_config.c", action: "link", target_directory: "config" }
  - { path: "config/board_config.c", action: "link", target_directory: "config" }

  # Platform abstraction
  - { path: "hal/gpio.c", action: "link", target_directory: "hal" }
  - { path: "hal/uart.c", action: "link", target_directory: "hal" }
  - { path: "hal/spi.c", action: "link", target_directory: "hal" }

  # Middleware
  - { path: "middleware/protocol.c", action: "link", target_directory: "middleware" }

  # Documentation (excluded from build)
  - { path: "README.md", action: "link", target_directory: "docs", exclude_from_build: true }
```

## Best Practices

### 1. Use Consistent Directory Names

```yaml
# Good: Consistent across all platforms
files:
  - { path: "src/main.c", action: "link", target_directory: "src" }
  - { path: "drivers/uart.c", action: "link", target_directory: "drivers" }

# Avoid: Inconsistent naming
files:
  - { path: "src/main.c", action: "link", target_directory: "source" }  # "source"
  - { path: "src/config.c", action: "link", target_directory: "src" }   # "src"
```

### 2. Match Source Repository Structure

Keeps mental model consistent between repository and CCS IDE.

### 3. Group by Function, Not File Type

```yaml
# Good: Functional grouping
- "drivers/"     # All driver code
- "middleware/"  # All middleware
- "application/" # All app logic

# Avoid: File type grouping (less useful)
- "headers/"     # Mix of all .h files
- "sources/"     # Mix of all .c files
```

### 4. Use Shallow Hierarchies

```yaml
# Good: Easy to navigate
target_directory: "drivers"
target_directory: "config"
target_directory: "platform/cc26x2r1"

# Avoid: Too deep
target_directory: "src/application/subsystem/module/drivers"
```

### 5. Platform-Specific Subdirectories

```yaml
# Platform-specific files get platform subdirectory
- { path: "platform/cc26x2r1/init.c", action: "link", target_directory: "platform/cc26x2r1" }
- { path: "platform/cc1352p7/init.c", action: "link", target_directory: "platform/cc1352p7" }

# Shared files don't need platform subdirectory
- { path: "shared/utils.c", action: "link", target_directory: "shared" }
```

## Limitations

1. **Only works with `action: "link"`**
   - Does not apply to `action: "copy"` (file is copied to project root)
   - Does not apply to `action: "exclude"`

2. **CCS-specific feature**
   - Relies on CCS support for linked files in subdirectories
   - Not applicable to copied files

3. **Path separators**
   - Always use forward slashes (`/`) in YAML, even on Windows
   - CCS handles platform-specific path conversion

## Troubleshooting

**Issue:** Linked file doesn't appear in target directory

**Solution:** Verify:

- `action` is set to `"link"` (not `"copy"`)
- `target_directory` path uses forward slashes
- Path is relative to project root (no leading `/`)

**Issue:** Build can't find linked file

**Solution:** Check:

- Include paths (`-I`) in compiler_build_options point to correct directories
- CCS project was regenerated after changing target_directory
- Symlink was created correctly (check filesystem)

**Issue:** Directory structure looks wrong in CCS

**Solution:**

- Refresh CCS project (F5)
- Regenerate projectspec and re-import
- Check that target_directory doesn't have trailing slash

## Related Documentation

- [YAML Reference](yaml-reference.md) - Complete ProjectFile field documentation
- [Project Modes](project-modes.md) - Root vs Build Subdirectory modes (common use case)
- [fwkit ti ccs generate](../cli/ti-ccs-generate.md) - Generate projects with target_directory
