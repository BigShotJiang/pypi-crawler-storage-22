# YAML Reference

Complete reference for fwkit platform configuration YAML files.

## Overview

The platform configuration YAML file defines Code Composer Studio project settings for multiple hardware platforms. It uses a **defaults + overrides** pattern where common settings are defined once and platform-specific sections override as needed.

**Schema Implementation:** `fwkit/vendors/ti/schemas.py` (Pydantic models)

## File Structure

```yaml
defaults:
  # Common settings shared by all platforms
  compiler_version: "4.0.4.LTS"
  tool_chain: "TICLANG"
  # ... more defaults

platform_id:
  # Platform-specific settings
  platform: "platform_id"
  project_title: "My Project"
  project_name: "my_project"
  device: "Cortex M.CC2652R1F"
  # ... overrides

another_platform_id:
  # Another platform
  ...
```

## Top-Level Structure

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `defaults` | Object | **Yes** | Default configuration values (see [PlatformDefaults](#platformdefaults)) |
| `{platform_id}` | Object | **Yes** | Platform-specific configurations (see [PlatformConfig](#platformconfig)) |

**Notes:**

- At least one platform must be defined
- Platform IDs (keys) can be any valid YAML key (alphanumeric + underscores recommended)
- Platform IDs are used as filenames for generated `.projectspec` files

---

## PlatformDefaults

Default configuration values shared across all platforms. Platforms inherit these values and can override them individually.

### Basic Settings

| Field | Type | Required | Default | Description |
|-------|------|----------|---------|-------------|
| `project_description` | String | No | `""` | Default project description |
| `compiler_version` | String | **Yes** | - | TI compiler version (e.g., "4.0.4.LTS", "3.2.2.LTS") |
| `tool_chain` | String | No | `"TICLANG"` | Toolchain identifier (TICLANG, GCC) |
| `products` | String | No | `"com.ti.SIMPLELINK_CC13XX_CC26XX_SDK;sysconfig"` | Required products (semicolon-separated) |
| `output_type` | String | No | `"executable"` | Output type (executable, library) |

### Floating Point Settings

| Field | Type | Values | Default | Description |
|-------|------|--------|---------|-------------|
| `mfloat_abi` | String | `hard`, `soft`, `softfp` | `"hard"` | Floating point ABI |
| `mfpu` | String | `fpv4-sp-d16`, `none`, etc. | `null` | FPU type (device-specific) |

**Notes:**

- Set `mfloat_abi: "soft"` and `mfpu: null` for devices without FPU (e.g., CC2651R3)
- These values are automatically converted to `-mfloat-abi=` and `-mfpu=` compiler flags
- Old flags are removed during generation to prevent conflicts

### File Paths

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `sysconfig_file_path` | String | `null` | Path to `.syscfg` file (e.g., "app.syscfg") |
| `link_file_path` | String | `null` | Path to linker command file (e.g., "cc26x2.cmd") |

**Notes:**

- Paths can use CCS variables like `${PROJECT_LOC}`, `${COM_TI_*}`
- Relative paths are resolved relative to project directory

### Build Options

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `compiler_build_options` | Array[String] | `[]` | Default compiler flags (one per line) |
| `linker_build_options` | Array[String] | `[]` | Default linker flags (one per line) |
| `sysconfig_build_options` | Array[String] | `[]` | Default SysConfig options (one per line) |

**Merging Behavior:**

- Platform-specific options are **appended** to defaults (not replaced)
- This allows platforms to add specific flags while keeping common flags

**Example:**
```yaml
defaults:
  compiler_build_options:
    - "-mcpu=cortex-m4"
    - "-mthumb"
    - "-Oz"

platform:
  compiler_build_options:
    - "-DPLATFORM_SPECIFIC"  # Results in: mcpu, mthumb, Oz, PLATFORM_SPECIFIC
```

### Pre/Post Build Steps

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `pre_build_step` | String | `null` | Command executed before build |
| `post_build_step` | String | `null` | Command executed after build |

**Notes:**

- Can use CCS variables: `${PROJECT_ROOT}`, `${ProjName}`, `${CG_TOOL_ROOT}`, etc.
- Multi-line commands can use YAML literal block scalar (`|`)
- Platform-specific steps **replace** (not append) defaults

**Example:**
```yaml
defaults:
  pre_build_step: |
    python ${PROJECT_ROOT}/scripts/generate_version.py
  post_build_step: |
    ${CG_TOOL_HEX} -order MS --memwidth=8 --romwidth=8 --intel "${ProjName}.out" "${ProjName}.hex"
```

### Default Files

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `files` | Array[[ProjectFile](#projectfile)] | `[]` | Default project files (inherited by all platforms) |

**Merging Behavior:**

- Platform-specific files are **merged** with defaults
- Both default files and platform files appear in generated project

### Default Properties

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `properties` | Array[[ProjectProperty](#projectproperty)] | `[]` | Default project properties |

**Merging Behavior:**

- Platform can override properties with the same `name`
- Properties not overridden are inherited

### Default Build Variables

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `build_variables` | Array[[BuildVariable](#buildvariable)] | `[]` | Default build variables |

**Merging Behavior:**

- Platform can override variables with the same `name`
- Variables not overridden are inherited

---

## PlatformConfig

Configuration for a single platform/hardware variant. Inherits all defaults and can override specific values.

### Required Fields

| Field | Type | Description |
|-------|------|-------------|
| `platform` | String | Platform identifier (should match the YAML key) |
| `project_title` | String | Project title displayed in CCS IDE |
| `project_name` | String | Project name (used for filenames, e.g., "my_project_cc26x2r1") |
| `device` | String | TI device name (e.g., "Cortex M.CC2652R1F", "Cortex M.CC1352P7") |

### Optional Overrides

All fields from `PlatformDefaults` can be overridden:

| Field | Type | Description |
|-------|------|-------------|
| `device_id` | String | Device ID for applicability (defaults to `device` if not specified) |
| `project_description` | String | Override project description |
| `compiler_version` | String | Override compiler version |
| `tool_chain` | String | Override toolchain |
| `products` | String | Override required products |
| `mfloat_abi` | String | Override floating point ABI |
| `mfpu` | String | Override FPU type |
| `output_type` | String | Override output type |
| `sysconfig_file_path` | String | Override SysConfig file path |
| `link_file_path` | String | Override linker command file |
| `compiler_build_options` | Array[String] | **Merged** with defaults (appended) |
| `linker_build_options` | Array[String] | **Merged** with defaults (appended) |
| `sysconfig_build_options` | Array[String] | **Merged** with defaults (appended) |
| `pre_build_step` | String | **Replaces** default pre-build step |
| `post_build_step` | String | **Replaces** default post-build step |
| `files` | Array[[ProjectFile](#projectfile)] | **Merged** with default files |
| `properties` | Array[[ProjectProperty](#projectproperty)] | **Merged** with defaults (can override by name) |
| `build_variables` | Array[[BuildVariable](#buildvariable)] | **Merged** with defaults (can override by name) |

**Example:**
```yaml
cc26x2r1:
  platform: "cc26x2r1"
  project_title: "My CC26X2R1 Project"
  project_name: "my_project_cc26x2r1"
  device: "Cortex M.CC2652R1F"
  link_file_path: "cc26x2_tirtos7.cmd"

  # Override FPU settings
  mfloat_abi: "hard"
  mfpu: "fpv4-sp-d16"

  # Add platform-specific compiler flags
  compiler_build_options:
    - "-DPLATFORM_CC26X2R1"
    - "-DDEVICE_FAMILY_CC26X2"
```

---

## ProjectFile

Defines a file to include in the project.

### Fields

| Field | Type | Required | Default | Values | Description |
|-------|------|----------|---------|--------|-------------|
| `path` | String | **Yes** | - | - | File path (can use CCS variables like `${PROJECT_LOC}`) |
| `action` | String | No | `"copy"` | `copy`, `link`, `exclude` | File action |
| `open_on_creation` | Boolean | No | `false` | - | Open file automatically when project is created |
| `exclude_from_build` | Boolean | No | `false` | - | Exclude file from build (e.g., documentation files) |
| `target_directory` | String | No | `null` | - | Target directory for linked files (see [Target Directory](target-directory.md)) |

### File Actions

**`copy`:**

- Copies file into project directory
- File becomes part of the project (changes are local)
- Use for files that may be modified per-project

**`link`:**

- Creates symbolic link to file
- File remains in original location
- Changes affect all projects using the file
- Useful for shared source code

**`exclude`:**

- File is visible in CCS but not compiled
- Useful for documentation, scripts, configuration

### Path Variables

Common CCS variables usable in `path`:

- `${PROJECT_LOC}` - Project location
- `${PROJECT_ROOT}` - Project root directory
- `${COM_TI_SIMPLELINK_CC13XX_CC26XX_SDK_INSTALL_DIR}` - SDK installation
- `${CG_TOOL_ROOT}` - Compiler tools root
- `${ProjName}` - Project name

### Examples

**Inline Format (Compact):**
```yaml
files:
  - { path: "src/main.c", action: "copy" }
  - { path: "src/config.c", action: "link", target_directory: "config" }
  - { path: "README.md", action: "exclude", open_on_creation: true }
```

**Block Format (Verbose):**
```yaml
files:
  - path: "src/main.c"
    action: "copy"
    open_on_creation: true

  - path: "${PROJECT_ROOT}/shared/utils.c"
    action: "link"
    target_directory: "shared/utils"

  - path: "docs/README.md"
    action: "exclude"
    exclude_from_build: true
```

See [Target Directory](target-directory.md) for detailed `target_directory` usage.

---

## ProjectProperty

Defines a project property (key-value pair for CCS project settings).

### Fields

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `name` | String | **Yes** | Property name |
| `value` | String | **Yes** | Property value |

### Common Properties

| Name | Values | Description |
|------|--------|-------------|
| `buildProfile` | `debug`, `release` | Build profile |
| `isHybrid` | `true`, `false` | Hybrid project (managed + makefile) |
| `enableHexTool` | `true`, `false` | Enable hex conversion tool |

**Example:**
```yaml
properties:
  - { name: "buildProfile", value: "release" }
  - { name: "isHybrid", value: "true" }
  - { name: "enableHexTool", value: "true" }
```

---

## BuildVariable

Defines a build variable for the project.

### Fields

| Field | Type | Required | Default | Description |
|-------|------|----------|---------|-------------|
| `name` | String | **Yes** | - | Variable name |
| `value` | String | **Yes** | - | Variable value (can use CCS variables) |
| `type` | String | No | `"string"` | Variable type (`string`, `PATH`, etc.) |
| `scope` | String | No | `"project"` | Variable scope (`project`, `workspace`) |

**Example:**
```yaml
build_variables:
  - name: "SDK_DIR"
    value: "${COM_TI_SIMPLELINK_CC13XX_CC26XX_SDK_INSTALL_DIR}"
    type: "PATH"
    scope: "project"

  - name: "VERSION"
    value: "1.2.3"
    type: "string"
```

---

## Complete Example

Full YAML demonstrating all features:

```yaml
defaults:
  # Basic settings
  project_description: "My Multi-Platform Firmware"
  compiler_version: "4.0.4.LTS"
  tool_chain: "TICLANG"
  products: "com.ti.SIMPLELINK_CC13XX_CC26XX_SDK;sysconfig"

  # FPU settings (for devices with FPU)
  mfloat_abi: "hard"
  mfpu: "fpv4-sp-d16"

  # Compiler options
  compiler_build_options:
    - "-I${PROJECT_ROOT}"
    - "-I${PROJECT_ROOT}/include"
    - "-Oz"
    - "-gdwarf-3"
    - "-mcpu=cortex-m4"
    - "-march=armv7e-m"
    - "-mthumb"

  # Linker options
  linker_build_options:
    - "-Wl,-m,${ProjName}.map"
    - "-Wl,--rom_model"
    - "-Wl,--warn_sections"
    - "-L${COM_TI_SIMPLELINK_CC13XX_CC26XX_SDK_INSTALL_DIR}/source"

  # SysConfig options
  sysconfig_build_options:
    - "--product ${COM_TI_SIMPLELINK_CC13XX_CC26XX_SDK_INSTALL_DIR}/.metadata/product.json"
    - "--compiler ticlang"

  # Build steps
  pre_build_step: |
    python ${PROJECT_ROOT}/scripts/generate_version.py --output ${PROJECT_ROOT}/src/version.h

  post_build_step: |
    ${CG_TOOL_HEX} -order MS --memwidth=8 --romwidth=8 --intel "${ProjName}.out" "${ProjName}.hex"

  # Common files
  files:
    - { path: "src/main.c", action: "link" }
    - { path: "src/system.c", action: "link" }
    - { path: "project.syscfg", action: "copy" }

  # Common properties
  properties:
    - { name: "buildProfile", value: "release" }
    - { name: "isHybrid", value: "true" }

# Platform 1: CC26X2R1 with FPU
cc26x2r1:
  platform: "cc26x2r1"
  project_title: "My Firmware - CC26X2R1"
  project_name: "my_firmware_cc26x2r1"
  device: "Cortex M.CC2652R1F"
  link_file_path: "cc26x2_tirtos7.cmd"

  # Add platform-specific defines
  compiler_build_options:
    - "-DPLATFORM_CC26X2R1"
    - "-DDEVICE_FAMILY_CC26X2"

  # Platform-specific files
  files:
    - path: "src/platform/cc26x2r1_init.c"
      action: "link"
      target_directory: "platform"

# Platform 2: CC2651R3 without FPU
cc2651r3:
  platform: "cc2651r3"
  project_title: "My Firmware - CC2651R3"
  project_name: "my_firmware_cc2651r3"
  device: "Cortex M.CC2651R3"
  link_file_path: "cc26x1_tirtos7.cmd"

  # Override FPU settings (no FPU on this device)
  mfloat_abi: "soft"
  mfpu: null

  # Platform-specific defines
  compiler_build_options:
    - "-DPLATFORM_CC2651R3"
    - "-DDEVICE_FAMILY_CC26X1"
    - "-DNO_FPU"

  # Platform-specific files
  files:
    - path: "src/platform/cc2651r3_init.c"
      action: "link"
      target_directory: "platform"

# Platform 3: CC1352P7 with custom settings
cc1352p7:
  platform: "cc1352p7"
  project_title: "My Firmware - CC1352P7"
  project_name: "my_firmware_cc1352p7"
  device: "Cortex M.CC1352P7"
  link_file_path: "cc13x2x7_cc26x2x7_tirtos7.cmd"

  # Custom compiler version for this platform
  compiler_version: "4.0.4.LTS"

  # Platform-specific defines
  compiler_build_options:
    - "-DPLATFORM_CC1352P7"
    - "-DDEVICE_FAMILY_CC13X2"
    - "-DSUPPORT_SUB_GHZ"

  # Additional linker options
  linker_build_options:
    - "-l:ti_drivers_rf_cc13x2p7.lib"

  # Platform-specific SysConfig
  sysconfig_build_options:
    - "--board /ti/boards/CC1352P_2_LAUNCHXL"

  # Platform files
  files:
    - path: "src/platform/cc1352p7_init.c"
      action: "link"
      target_directory: "platform"
    - path: "src/platform/cc1352p7_rf_config.c"
      action: "link"
      target_directory: "platform"
```

---

## Inheritance and Merging Rules

### Scalar Fields (Single Values)

Platform value **replaces** default value:

- `compiler_version`, `tool_chain`, `device`, `mfloat_abi`, `mfpu`
- `pre_build_step`, `post_build_step`

### Array Fields (Lists)

Platform values are **appended** to defaults:

- `compiler_build_options`
- `linker_build_options`
- `sysconfig_build_options`
- `files`

### Named Collections

Platform can override by name:

- `properties` - Matched by `name` field
- `build_variables` - Matched by `name` field

**Example:**
```yaml
defaults:
  properties:
    - { name: "buildProfile", value: "debug" }
    - { name: "isHybrid", value: "false" }

platform:
  properties:
    - { name: "buildProfile", value: "release" }  # Overrides default
    # isHybrid="false" is inherited
```

Result: `buildProfile=release`, `isHybrid=false`

---

## Validation

The YAML file is validated using Pydantic schemas on load. Common validation errors:

**Missing required fields:**
```
Error: field required (defaults.compiler_version)
```

**Invalid field value:**
```
Error: mfloat_abi must be one of: hard, soft, softfp
```

**Invalid file action:**
```
Error: action must be one of: copy, link, exclude
```

**YAML syntax error:**
```
Error: Invalid YAML: mapping values are not allowed here
```

Use [`fwkit ti ccs generate`](../cli/ti-ccs-generate.md) to validate your configuration.

---

## Related Documentation

- [Project Modes](project-modes.md) - Root vs Subdirectory project organization
- [Target Directory](target-directory.md) - Organizing linked files in custom directories
- [fwkit ti ccs generate](../cli/ti-ccs-generate.md) - Generate projects from YAML
- [Examples](https://github.com/AcenoTecnologia/fwkit/tree/main/examples) - Real-world YAML examples
