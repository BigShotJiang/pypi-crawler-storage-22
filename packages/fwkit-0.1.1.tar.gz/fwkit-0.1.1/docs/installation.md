# Installation

This guide covers installing fwkit and setting up your development environment.

## Requirements

- **Python**: 3.10 or higher
- **Git**: Required for version management features
- **Texas Instruments Code Composer Studio**: Required for TI CCS commands (optional if only using version management)

## Installing fwkit

### Using pip

```bash
pip install fwkit
```

### From Source

```bash
# Clone the repository
git clone https://github.com/AcenoTecnologia/fwkit.git
cd fwkit

# Install in development mode
pip install -e .
```

### Using uv (Recommended for Development)

```bash
# Install uv if not already installed
pip install uv

# Clone and install
git clone https://github.com/AcenoTecnologia/fwkit.git
cd fwkit
uv sync --all-extras
```

## Verify Installation

After installation, verify that fwkit is available:

```bash
fwkit --version
```

You should see output similar to:

```
fwkit, version 0.1.0
```

## Environment Configuration

### Texas Instruments CCS Setup

If you plan to use the TI CCS commands, you need to configure the path to the CCS command-line interface.

#### Set CCS_SERVER_CLI Environment Variable

**Linux/macOS:**

```bash
export CCS_SERVER_CLI="/path/to/ccs/eclipse/ccsvXXXX/ccs_base/scripting/bin/ccs-server-cli"
```

Add this to your `.bashrc` or `.zshrc` for persistence.

**Windows:**

```cmd
set CCS_SERVER_CLI=C:\ti\ccs\eclipse\ccsvXXXX\ccs_base\scripting\bin\ccs-server-cli.bat
```

Or set it permanently via System Properties → Environment Variables.

#### Common CCS Installation Paths

fwkit automatically searches these common paths if `CCS_SERVER_CLI` is not set:

**Linux:**

- `/opt/ti/ccs*/ccs/eclipse/ccsvXXXX/ccs_base/scripting/bin/ccs-server-cli`
- `~/ti/ccs*/ccs/eclipse/ccsvXXXX/ccs_base/scripting/bin/ccs-server-cli`

**Windows:**

- `C:\ti\ccs*\ccs\eclipse\ccsvXXXX\ccs_base\scripting\bin\ccs-server-cli.bat`

**macOS:**

- `/Applications/ti/ccs*/ccs/eclipse/ccsvXXXX/ccs_base/scripting/bin/ccs-server-cli`

!!! tip
    If CCS is installed in a standard location, you may not need to set `CCS_SERVER_CLI` manually.

## Verify CCS Integration

To verify that fwkit can find your CCS installation:

```bash
fwkit ti ccs --help
```

This should display the available TI CCS subcommands without errors.

## First Steps

Now that fwkit is installed, try these basic commands:

### Generate a Version Header

```bash
# In a Git repository
fwkit codegen version --output version.h
cat version.h
```

### Generate CCS Projects

```bash
# Create a sample YAML configuration (see examples/)
fwkit ti ccs generate my_platforms.yaml
```

## Next Steps

- Learn about [CLI Commands](cli/codegen-version.md) to understand what fwkit can do
- Read the [YAML Reference](configuration/yaml-reference.md) to create your first project configuration
- Check [Troubleshooting](troubleshooting.md) if you encounter issues

## Updating fwkit

To update to the latest version:

```bash
pip install --upgrade fwkit
```

Or with uv:

```bash
uv sync --upgrade
```

## Uninstalling

To remove fwkit:

```bash
pip uninstall fwkit
```
