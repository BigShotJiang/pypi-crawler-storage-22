# Troubleshooting

Common issues and solutions when using fwkit.

## Installation Issues

### CCS Server CLI Not Found

**Symptoms:**
```
Error: CCS server CLI not found.
Set CCS_SERVER_CLI environment variable or use --ccs-cli option.
```

**Causes:**

- CCS not installed
- `CCS_SERVER_CLI` environment variable not set
- CCS installed in non-standard location

**Solutions:**

1. **Set environment variable:**
   ```bash
   # Linux/macOS
   export CCS_SERVER_CLI="/opt/ti/ccs1260/ccs/eclipse/ccs-server-cli.sh"

   # Windows
   set CCS_SERVER_CLI=C:\ti\ccs1260\ccs\eclipse\ccs-server-cli.bat
   ```

2. **Use `--ccs-cli` option:**
   ```bash
   fwkit ti ccs import --projectspec file.projectspec \
     --workspace ~/workspace \
     --ccs-cli /path/to/ccs-server-cli.sh
   ```

3. **Check common paths:**
   - Linux: `/opt/ti/ccs*/ccs/eclipse/ccs-server-cli.sh`
   - Linux (user): `~/ti/ccs*/ccs/eclipse/ccs-server-cli.sh`
   - Windows: `C:\ti\ccs*\ccs\eclipse\ccs-server-cli.bat`
   - macOS: `/Applications/ti/ccs*/ccs/eclipse/ccs-server-cli.sh`

See [Installation Guide](installation.md#texas-instruments-ccs-setup) for detailed setup.

### Python Version Too Old

**Symptoms:**
```
ERROR: Python 3.10 or higher is required
```

**Solution:**
Install Python 3.10 or newer:
```bash
# Check version
python --version

# Ubuntu/Debian
sudo apt update
sudo apt install python3.10

# macOS (Homebrew)
brew install python@3.10

# Windows
# Download from https://www.python.org/downloads/
```

---

## YAML Configuration Issues

### Missing Required Fields

**Symptoms:**
```
Error: Invalid configuration: field required (defaults.compiler_version)
```

**Cause:**
Required fields missing from YAML configuration.

**Solution:**
Ensure your YAML has all required fields:

**Required in `defaults`:**

- `compiler_version`

**Required in each platform:**

- `platform`
- `project_title`
- `project_name`
- `device`

**Example:**
```yaml
defaults:
  compiler_version: "4.0.4.LTS"  # REQUIRED

cc26x2r1:
  platform: "cc26x2r1"                     # REQUIRED
  project_title: "My Project - CC26X2R1"  # REQUIRED
  project_name: "my_project_cc26x2r1"     # REQUIRED
  device: "Cortex M.CC2652R1F"            # REQUIRED
```

### Invalid Field Values

**Symptoms:**
```
Error: mfloat_abi must be one of: hard, soft, softfp
Error: action must be one of: copy, link, exclude
```

**Cause:**
Field value doesn't match allowed values.

**Solution:**
Check allowed values:

- `mfloat_abi`: `"hard"`, `"soft"`, `"softfp"`
- `action`: `"copy"`, `"link"`, `"exclude"`
- Build type: `"full"`, `"incremental"`, `"clean"`

### YAML Syntax Errors

**Symptoms:**
```
Error: Invalid YAML: mapping values are not allowed here
```

**Cause:**
YAML syntax error (indentation, colons, quotes).

**Solution:**
1. Validate YAML syntax using online validator (yamllint.com)
2. Check indentation (use spaces, not tabs)
3. Quote strings containing special characters
4. Ensure lists use `- ` prefix

**Common mistakes:**
```yaml
# Wrong: No space after colon
compiler_version:"4.0.4.LTS"

# Correct:
compiler_version: "4.0.4.LTS"

# Wrong: Tab indentation
defaults:
	compiler_version: "4.0.4.LTS"

# Correct: Space indentation
defaults:
  compiler_version: "4.0.4.LTS"
```

### Platform Not Found

**Symptoms:**
```
Error: Platform 'cc26x2r1' not found in configuration
Available platforms: cc2652r1, cc1352p7
```

**Cause:**
Platform ID passed to `--platform-id` doesn't exist in YAML.

**Solution:**
1. Check platform ID spelling (case-sensitive)
2. List available platforms:
   ```bash
   fwkit ti ccs generate --platforms file.yaml
   # Shows table of all platforms
   ```
3. Verify YAML key matches `--platform-id`:
   ```yaml
   cc2652r1:  # This is the platform ID
     platform: "cc2652r1"  # This should match
   ```

---

## Build Issues

### Build Fails with Undefined References

**Symptoms:**
```
error: undefined reference to 'main'
error: undefined reference to 'functionName'
```

**Causes:**

- Source files not included in project
- Linker can't find object files
- Library not linked

**Solutions:**

1. **Check files are included:**
   ```yaml
   files:
     - { path: "src/main.c", action: "link" }  # Must be included
   ```

2. **Check linker options:**
   ```yaml
   linker_build_options:
     - "-l:ti_drivers.lib"  # Ensure libraries are linked
     - "-L${SDK_PATH}/lib"  # Library search path
   ```

3. **Verify linker command file:**
   ```yaml
   link_file_path: "cc26x2_tirtos7.cmd"  # Must exist
   ```

### Build Fails: File Not Found

**Symptoms:**
```
fatal error: 'header.h' file not found
```

**Causes:**

- Include paths not configured
- File not linked/copied to project
- Wrong path in `#include`

**Solutions:**

1. **Add include paths:**
   ```yaml
   compiler_build_options:
     - "-I${PROJECT_LOC}/src"
     - "-I${PROJECT_LOC}/include"
   ```

2. **Check file is included:**
   ```yaml
   files:
     - { path: "include/header.h", action: "link" }
   ```

3. **Verify path mode (root vs subdirectory):**
   ```yaml
   # Root mode
   - "-I${PROJECT_LOC}/src"

   # Subdirectory mode
   - "-I${PROJECT_LOC}/../../src"
   ```

### Incremental Build Doesn't Pick Up Changes

**Symptoms:**

- Code changes don't affect build output
- Old behavior persists after fixes

**Cause:**
Incremental builds cache object files and may miss header changes or `.opt` file modifications.

**Solution:**
Use full rebuild:
```bash
fwkit ti ccs build \
  --project my_project \
  --workspace ~/workspace \
  --type full
```

Or clean + build:
```bash
fwkit ti ccs build --project my_project --workspace ~/workspace --type clean
fwkit ti ccs build --project my_project --workspace ~/workspace --type full
```

### Batch Build: .opt File Issues

**Symptoms:**
```
Warning: .opt file not found: /path/to/project/compiler.opt
```

**Cause:**
Batch build configuration references non-existent `.opt` file.

**Solution:**
1. **Verify .opt file path in config:**
   ```yaml
   projects:
     - name: "my_project"
       opt_file: "compiler.opt"  # Check this exists in project
   ```

2. **Check project directory:**
   ```bash
   ls workspace/my_project/compiler.opt
   ```

3. **Create .opt file if missing:**
   ```bash
   touch workspace/my_project/compiler.opt
   ```

---

## Import Issues

### Project Already Exists in Workspace

**Symptoms:**
```
Error: Project already exists in workspace
```

**Cause:**
Project with same name already imported.

**Solutions:**

1. **Use different project name:**
   ```yaml
   platform:
     project_name: "my_project_v2"  # Change name
   ```

2. **Delete existing project from CCS:**
   - Open CCS
   - Right-click project → Delete
   - Select "Delete project contents on disk"

3. **Use different workspace:**
   ```bash
   fwkit ti ccs import \
     --projectspec file.projectspec \
     --workspace ~/workspace_new
   ```

### Cannot Open Display

**Symptoms:**
```
Error: Cannot open display
```

**Cause:**
Running in headless environment (CI/CD, SSH without X11). CCS requires display even for CLI operations.

**Solutions:**

1. **Use Xvfb (virtual framebuffer):**
   ```bash
   xvfb-run fwkit ti ccs import \
     --projectspec file.projectspec \
     --workspace ~/workspace
   ```

2. **Configure X11 forwarding (SSH):**
   ```bash
   ssh -X user@server
   fwkit ti ccs import ...
   ```

3. **Set DISPLAY variable:**
   ```bash
   export DISPLAY=:0
   fwkit ti ccs import ...
   ```

### Workspace Corruption

**Symptoms:**
```
Error reading configuration
Error: Workspace metadata corrupted
```

**Cause:**
CCS workspace `.metadata` directory is corrupted.

**Solutions:**

1. **Create new workspace:**
   ```bash
   fwkit ti ccs import \
     --projectspec file.projectspec \
     --workspace ~/workspace_fresh
   ```

2. **Delete `.metadata` (WARNING: loses settings):**
   ```bash
   rm -rf ~/ccs-workspace/.metadata
   # Then re-import projects
   ```

3. **Ensure workspace path is valid:**
   - No special characters or spaces in path
   - Path is writable
   - Sufficient disk space

---

## Version Generation Issues

### No Git Tags Found

**Symptoms:**
```
Error: No Git tags found
```

**Cause:**
Repository has no tags, and no `VERSION.txt` file provided.

**Solutions:**

1. **Create Git tag:**
   ```bash
   git tag v1.0.0
   fwkit codegen version --output version.h
   ```

2. **Use VERSION.txt file:**
   ```bash
   echo "1.0.0" > VERSION.txt
   fwkit codegen version --version-file VERSION.txt --output version.h
   ```

### Version Not Extracted in Batch Build

**Symptoms:**

- Hex filenames missing version: `project_variant.hex` instead of `project_variant_1.2.3.hex`

**Cause:**
Batch builder can't find `FW_VERSION_STRING_FULL` define.

**Solutions:**

1. **Ensure version header is generated:**
   ```yaml
   pre_build_step: "fwkit codegen version --output ${PROJECT_LOC}/src/version.h"
   ```

2. **Check version header location:**
   Batch builder looks in:
   - `Debug/syscfg/version.h`
   - `src/version.h`

   Ensure pre-build step writes to one of these locations.

3. **Verify version header format:**
   ```c
   #define FW_VERSION_STRING_FULL "1.2.3+42.abc123"
   ```

---

## Path and Link Issues

### Linked Files Show Broken Link in CCS

**Symptoms:**
Files in CCS show broken link icon (⚠️ symbol).

**Cause:**
Symbolic link path is incorrect.

**Solutions:**

1. **Check relative paths (subdirectory mode):**
   ```yaml
   # If .projectspec is in build/platform/
   files:
     - path: "../../src"  # Correct
       action: "link"

   # Not:
     - path: "../src"     # Wrong
     - path: "src"        # Wrong
   ```

2. **Verify symlink on filesystem:**
   ```bash
   ls -la workspace/my_project/
   # Should show: src -> ../../src
   ```

3. **Regenerate and re-import:**
   ```bash
   fwkit ti ccs generate --platforms file.yaml --output build/ --subdirs
   fwkit ti ccs import --projectspec build/platform/platform.projectspec --workspace ~/workspace
   ```

### File Not Found Errors (Path Mode Issue)

**Symptoms:**
```
fatal error: file not found
```

**Cause:**
Mixing root mode and subdirectory mode path styles.

**Solution:**
Verify `${PROJECT_LOC}` paths match your mode:

**Root mode (projectspec in repository root):**
```yaml
compiler_build_options:
  - "-I${PROJECT_LOC}/src"
pre_build_step: "${PROJECT_LOC}/scripts/build.py"
```

**Subdirectory mode (projectspec in `build/platform/`):**
```yaml
compiler_build_options:
  - "-I${PROJECT_LOC}/../../src"
pre_build_step: "${PROJECT_LOC}/../../scripts/build.py"
```

See [Project Modes](configuration/project-modes.md) for detailed explanation.

---

## Performance Issues

### Batch Build Very Slow

**Cause:**
Each variant requires full rebuild (removes Debug/ directory).

**Solutions:**

1. **Use filters during development:**
   ```bash
   # Build only one project
   fwkit ti ccs batch-build --config build.yaml --workspace ~/workspace --project my_project

   # Build only one variant
   fwkit ti ccs batch-build --config build.yaml --workspace ~/workspace --variant A7133
   ```

2. **Build in parallel (separate terminals):**
   ```bash
   # Terminal 1
   fwkit ti ccs batch-build --config build.yaml --workspace ~/ws1 --project project1

   # Terminal 2
   fwkit ti ccs batch-build --config build.yaml --workspace ~/ws2 --project project2
   ```

3. **Use faster build machine:**
   - More CPU cores
   - SSD instead of HDD
   - More RAM

### CCS Commands Hang or Timeout

**Cause:**
CCS is busy, unresponsive, or waiting for user input.

**Solutions:**

1. **Check CCS isn't running:**
   ```bash
   # Close CCS GUI before running fwkit commands
   pkill -9 ccsvXX
   ```

2. **Increase timeout (if supported):**
   Some operations may take longer on large projects.

3. **Check system resources:**
   ```bash
   # Linux
   top
   htop

   # Check disk space
   df -h
   ```

---

## Getting Help

If you encounter issues not covered here:

1. **Check command help:**
   ```bash
   fwkit --help
   fwkit ti ccs generate --help
   ```

2. **Validate configuration:**
   ```bash
   fwkit ti ccs generate --platforms file.yaml
   # Shows table of platforms (validates YAML)
   ```

3. **Enable verbose output:**
   Check exit codes and error messages carefully.

4. **Report bugs:**
   [GitHub Issues](https://github.com/AcenoTecnologia/fwkit/issues)
   - Include fwkit version (`fwkit --version`)
   - Include minimal YAML reproduction case
   - Include error message and command used

5. **Read related documentation:**
   - [CLI Commands](cli/codegen-version.md)
   - [YAML Reference](configuration/yaml-reference.md)
   - [Project Modes](configuration/project-modes.md)
