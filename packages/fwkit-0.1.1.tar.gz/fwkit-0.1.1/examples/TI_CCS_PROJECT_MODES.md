# TI CCS Project Modes Guide

This guide explains the two different ways to configure CCS projects using fwkit:
1. **Root Project Mode** (for development)
2. **Build Subdirectory Mode** (for CI/CD and multi-platform builds)

---

## Mode 1: Root Project (Development)

### When to use
- 👨‍💻 **Local development** in IDE
- 🔍 Want **all files visible** in CCS Project Explorer
- 🎯 Working on **one platform** at a time
- ⚡ **Direct file editing** without symbolic links

### How it works
The `.projectspec` is generated in your **repository root**, and when imported into CCS, the project accesses files **directly** from their actual locations.

```
my-firmware/
├── .project              ← CCS creates this
├── .cproject             ← CCS creates this
├── my_device.projectspec ← Generated here
├── src/
│   ├── main.c           ← Accessed directly
│   └── system.c         ← Accessed directly
├── platforms/
│   └── cc2652r1/
│       └── config.syscfg ← Copied to root
└── scripts/
```

### Example YAML configuration

```yaml
# File: platforms/dev.yaml
defaults:
  compiler_build_options:
    - "-I${PROJECT_LOC}/src"        # PROJECT_LOC is repository root
    - "-I${PROJECT_LOC}/src/api"
  
  pre_build_step: "${PYTHON_CMD} ${PROJECT_LOC}/scripts/gen_version.py ..."
  
  files:
    # Exclude folders from the build (but they still exist)
    - path: "platforms"
      action: "copy"
      exclude_from_build: true
    
    - path: "test"
      action: "copy"
      exclude_from_build: true
    
    - path: "build"
      action: "copy"
      exclude_from_build: true
    
    # Copy platform-specific files to root
    - path: "platforms/cc2652r1/config.syscfg"
      action: "copy"
    
    - path: "platforms/cc2652r1/linker.cmd"
      action: "copy"

cc2652r1_dev:
  project_name: "my_project_dev"
  device: "Cortex M.CC2652R1F"
```

### Usage

```bash
# Generate .projectspec in repository root
cd ~/my-firmware
fwkit ti ccs generate \
  --platforms platforms/dev.yaml \
  --output .

# Import into CCS
fwkit ti ccs import \
  --projectspec my_project_dev.projectspec \
  --workspace ~/ccs-workspace
```

### ✅ Advantages
- All source files visible in Project Explorer
- Direct editing in IDE (no link confusion)
- Simpler for debugging and navigation
- Autocomplete works naturally

### ❌ Disadvantages
- CCS project files (`.project`, `.cproject`) in repository root
- Can only work on one platform at a time
- Need to `.gitignore` CCS project files

---

## Mode 2: Build Subdirectories (CI/CD)

### When to use
- 🏗️ **CI/CD builds** for multiple platforms
- 📦 Want **multiple platform variants** in same workspace
- 🧹 Keep **build artifacts isolated** per platform
- 🔗 Don't mind **symbolic links** in IDE

### How it works
Each platform gets its own subdirectory (e.g., `build/cc2652r1/`), and source files are **linked** from the repository root using relative paths.

```
my-firmware/
├── src/
│   ├── main.c
│   └── system.c
├── platforms/
│   ├── cc2652r1/
│   └── cc2652r7/
├── scripts/
└── build/
    ├── cc2652r1/               ← Platform 1 project
    │   ├── .project
    │   ├── .cproject
    │   ├── cc2652r1.projectspec
    │   ├── src@ → ../../src    ← Symbolic link
    │   └── scripts@ → ../../scripts
    └── cc2652r7/               ← Platform 2 project
        ├── .project
        ├── .cproject
        ├── cc2652r7.projectspec
        ├── src@ → ../../src
        └── scripts@ → ../../scripts
```

### Example YAML configuration

```yaml
# File: platforms/ci.yaml
defaults:
  compiler_build_options:
    # PROJECT_LOC is build/platform_name/ so use ../../ to reach root
    - "-I${PROJECT_LOC}/../../src"
    - "-I${PROJECT_LOC}/../../src/api"
  
  pre_build_step: "${PYTHON_CMD} ${PROJECT_LOC}/../../scripts/gen_version.py ..."
  
  files:
    # Link entire source directory
    - path: "../../src"
      action: "link"
    
    # Link scripts directory
    - path: "../../scripts"
      action: "link"
    
    # Link individual files
    - path: "../../VERSION.txt"
      action: "link"
    
    - path: "../../README.md"
      action: "link"

cc2652r1_ci:
  project_name: "cc2652r1_ci"
  device: "Cortex M.CC2652R1F"
  
  files:
    # Link platform folder with custom target directory name
    - path: "../../platforms/cc2652r1"
      action: "link"
      target_directory: "platform_config"

cc2652r7_ci:
  project_name: "cc2652r7_ci"
  device: "Cortex M.CC2652R7"
  
  files:
    - path: "../../platforms/cc2652r7"
      action: "link"
      target_directory: "platform_config"
```

### Usage

```bash
# Generate .projectspec files in build subdirectories
cd ~/my-firmware
fwkit ti ccs generate \
  --platforms platforms/ci.yaml \
  --output build/ \
  --subdirs

# This creates:
#   build/cc2652r1_ci/cc2652r1_ci.projectspec
#   build/cc2652r7_ci/cc2652r7_ci.projectspec

# Import all into same workspace
fwkit ti ccs import \
  --projectspec build/cc2652r1_ci/cc2652r1_ci.projectspec \
  --workspace ~/ccs-workspace

fwkit ti ccs import \
  --projectspec build/cc2652r7_ci/cc2652r7_ci.projectspec \
  --workspace ~/ccs-workspace

# Now you have both platforms in the same workspace!
```

### ✅ Advantages
- Multiple platforms in same workspace
- Build artifacts isolated per platform
- Clean separation for CI/CD pipelines
- Repository root stays clean (no CCS files)
- Source changes reflect across all platforms

### ❌ Disadvantages
- Files shown as links `→` in Project Explorer
- Slightly more complex directory structure
- Need to understand relative paths (`../../`)

---

## Path Variables Reference

Both modes use CCS path variables. Understanding these is key:

| Variable | Root Mode | Subdirectory Mode | Notes |
|----------|-----------|-------------------|-------|
| `${PROJECT_LOC}` | Repository root | `build/platform/` | Location of `.projectspec` |
| `${PROJECT_ROOT}` | CCS workspace | CCS workspace | Same in both modes |
| `${ConfigName}` | `Debug` or `Release` | `Debug` or `Release` Same in both modes |
| `${COM_TI_*}` | SDK install dir | SDK install dir | Same in both modes |

### Examples

**Root Mode:**
```yaml
compiler_build_options:
  - "-I${PROJECT_LOC}/src"                    # → /my-firmware/src
  - "-I${PROJECT_LOC}/platforms/cc2652r1"     # → /my-firmware/platforms/cc2652r1

pre_build_step: "${PYTHON_CMD} ${PROJECT_LOC}/scripts/build.py"
```

**Subdirectory Mode:**
```yaml
compiler_build_options:
  - "-I${PROJECT_LOC}/../../src"              # → /my-firmware/src
  - "-I${PROJECT_LOC}/../../platforms/cc2652r1"  # → /my-firmware/platforms/cc2652r1

pre_build_step: "${PYTHON_CMD} ${PROJECT_LOC}/../../scripts/build.py"
```

---

## File Actions Reference

Both modes support these file actions:

### `action: "copy"`
- Copies file to project location
- File becomes independent from original
- Use for: Platform-specific configs that vary

```yaml
# Root mode
- path: "platforms/cc2652r1/config.syscfg"
  action: "copy"

# Subdirectory mode (still copies, but from relative path)
- path: "../../platforms/cc2652r1/config.syscfg"
  action: "copy"
```

### `action: "link"`
- Creates symbolic link to original file
- Changes to original reflect in project
- Use for: Source code, shared configs

```yaml
# Only makes sense in subdirectory mode
- path: "../../src"
  action: "link"

- path: "../../scripts/build.py"
  action: "link"
  target_directory: "tools"  # Shows as tools/build.py in project
```

### `action: "copy"` + `exclude_from_build: true`
- File/folder exists in project but not compiled
- Use for: Documentation, tests, build artifacts

```yaml
# Root mode - exclude folders from build
- path: "test"
  action: "copy"
  exclude_from_build: true

- path: ".git"
  action: "copy"
  exclude_from_build: true
```

---

## Migration from Custom Scripts

If you're migrating from custom project generation scripts:

### Traditional approach:
```bash
# Root mode - separate flag
python gen_project.py template.j2 platforms.yaml --output_dir .

# Subdirectory mode - CLI flag for relative paths
python gen_project.py template.j2 platforms.yaml \
  --root_relative_path ../.. \
  --output_dir build/variant_x \
  --create_platform_folders
```

### fwkit approach:
```bash
# Root mode - paths configured in YAML
fwkit ti ccs generate --platforms platforms_dev.yaml --output .

# Subdirectory mode - relative paths in YAML
fwkit ti ccs generate --platforms platforms_ci.yaml --output build/ --subdirs
```

**Key difference:** Instead of CLI flags for path handling, you configure paths **directly in the YAML**. This is more flexible, explicit, and self-documenting.

---

## Complete Examples

See example configurations:
- [`ti_ccs_root_project.yaml`](ti_ccs_root_project.yaml) - Root project mode (development)
- [`ti_ccs_build_subdirs.yaml`](ti_ccs_build_subdirs.yaml) - Subdirectory mode (CI/CD)

Both files contain complete, working configurations with detailed comments.

---

## Best Practices

### For Development (Root Mode)
1. Add CCS files to `.gitignore`:
   ```gitignore
   .project
   .cproject
   .settings/
   Debug/
   Release/
   *.projectspec
   ```

2. Use separate YAML for dev (`platforms/dev.yaml`) vs production
3. Exclude non-source folders explicitly
4. Use `copy` action for platform-specific files

### For CI/CD (Subdirectory Mode)
1. Create `build/` directory in `.gitignore`
2. Use `link` action for shared source code
3. Use `target_directory` to organize linked files
4. Keep relative paths consistent (`../../`)
5. Test each platform build independently

### General
- ✅ Use descriptive `target_directory` names
- ✅ Comment complex path configurations
- ✅ Keep platform files organized in `platforms/`
- ✅ Test imports before committing YAML changes
- ✅ Document platform-specific defines

---

## Troubleshooting

### "File not found" errors during build
**Problem:** Paths in compiler flags don't match actual file structure  
**Solution:** Check that `${PROJECT_LOC}` paths match your mode:
- Root mode: `${PROJECT_LOC}/src`
- Subdir mode: `${PROJECT_LOC}/../../src`

### Linked files show "broken link" in CCS
**Problem:** Relative paths are incorrect  
**Solution:** If `.projectspec` is in `build/platform_name/`, paths should be `../../`

### Can't see source files in Project Explorer (Subdirectory mode)
**Problem:** Forgot to link source directory  
**Solution:** Add to `files:`:
```yaml
- path: "../../src"
  action: "link"
```

### Multiple platforms have same project name
**Problem:** `project_name` conflicts between platforms  
**Solution:** Use unique names per platform:
```yaml
cc2652r1: { project_name: "myapp_cc2652r1" }
cc2652r7: { project_name: "myapp_cc2652r7" }
```
