# Guia: Formatos YAML - Compacto vs Expandido

## Formato Compacto (Inline/Flow) - RECOMENDADO para muitos arquivos

```yaml
files:
  - { path: "src/main.c", action: "copy" }
  - { path: "src/system.c", action: "copy", open_on_creation: true }
  - { path: "include/config.h", action: "link", target_directory: "include" }
  - { path: "test.c", action: "copy", exclude_from_build: true }
```

**Vantagens:**
- ✅ 1 arquivo = 1 linha
- ✅ Fácil de adicionar/remover arquivos
- ✅ Fácil de comparar diffs no Git
- ✅ Cabe dezenas de arquivos em poucas linhas
- ✅ Copy-paste entre plataformas simplificado

---

## Formato Expandido (Block) - Melhor para poucos arquivos

```yaml
files:
  - path: "src/main.c"
    action: "copy"
  
  - path: "src/system.c"
    action: "copy"
    open_on_creation: true
  
  - path: "include/config.h"
    action: "link"
    target_directory: "include"
  
  - path: "test.c"
    action: "copy"
    exclude_from_build: true
```

**Vantagens:**
- ✅ Mais legível quando há POUCOS arquivos
- ✅ Permite comentários por campo
- ✅ Alinhamento visual dos campos

---

## Comparação de Tamanho

### 50 arquivos no formato EXPANDIDO: ~200 linhas
```yaml
files:
  - path: "file1.c"
    action: "copy"
  
  - path: "file2.c"
    action: "copy"
  
  # ... mais 48 arquivos ...
```

### 50 arquivos no formato COMPACTO: ~50 linhas
```yaml
files:
  - { path: "file1.c", action: "copy" }
  - { path: "file2.c", action: "copy" }
  # ... mais 48 linhas ...
```

**75% menor!** 🎉

---

## Quando usar cada formato?

### Use COMPACTO quando:
- 🎯 Você tem **5+ arquivos** na lista
- 🎯 Precisa de **copy-paste rápido** entre plataformas
- 🎯 Quer **diff limpo** no Git (1 linha mudou = 1 arquivo mudou)
- 🎯 A maioria dos arquivos usa valores padrão (action: "copy")

### Use EXPANDIDO quando:
- 🎯 Você tem **poucos arquivos** (1-4)
- 🎯 Cada arquivo tem **muitos parâmetros diferentes**
- 🎯 Você prefere **legibilidade** a compacidade
- 🎯 Está **documentando** a configuração para outros

---

## Formato Híbrido (Recomendado!)

Você pode misturar os dois:

```yaml
files:
  # Maioria dos arquivos: compacto
  - { path: "src/main.c", action: "copy" }
  - { path: "src/system.c", action: "copy" }
  - { path: "src/config.c", action: "copy" }
  
  # Arquivo especial: expandido com comentário
  - path: "src/platform_specific.c"
    action: "copy"
    open_on_creation: true
    # Este arquivo é especial porque...
  
  # Resto: compacto novamente
  - { path: "src/utils.c", action: "copy" }
  - { path: "src/log.c", action: "copy" }
```

---

## Outros campos também aceitam formato compacto

### Properties
```yaml
# Compacto
properties:
  - { name: "buildProfile", value: "release" }
  - { name: "isHybrid", value: "true" }

# Expandido
properties:
  - name: "buildProfile"
    value: "release"
  - name: "isHybrid"
    value: "true"
```

### Build Variables
```yaml
# Compacto
build_variables:
  - { name: "SDK_DIR", value: "${SDK_INSTALL_DIR}", type: "PATH" }
  - { name: "VERSION", value: "1.0.0", type: "string" }

# Expandido
build_variables:
  - name: "SDK_DIR"
    value: "${SDK_INSTALL_DIR}"
    type: "PATH"
  - name: "VERSION"
    value: "1.0.0"
    type: "string"
```

---

## Exemplos Reais

Ver:
- [ti_ccs_compact.yaml](ti_ccs_compact.yaml) - Projeto com 60+ arquivos em formato compacto
- [ti_ccs_platforms.yaml](ti_ccs_platforms.yaml) - Vários exemplos mostrando ambos os formatos
- [ti_ccs_minimal.yaml](ti_ccs_minimal.yaml) - Configuração mínima
