"""
fwkit - Firmware Development Toolkit

Build, generate, and manage embedded projects.
"""

__version__ = "0.1.0-dev"
__author__ = "Aceno Tecnologia"
__license__ = "MIT"

from fwkit.cli import app

__all__ = ["app", "__version__"]
