"""Main CLI application entry point."""

from fwkit.cli import app

if __name__ == "__main__":
    app()
