"""Main CLI application using Typer."""

import typer

from fwkit import __version__

# Import subcommands
from fwkit.codegen.cli import app as codegen_app
from fwkit.common.console import console
from fwkit.vendors.ti_cli import app as ti_app

app = typer.Typer(
    name="fwkit",
    help="Firmware Development Toolkit - Build, generate, and manage embedded projects",
    add_completion=True,
    rich_markup_mode="rich",
)

# Add subcommands
app.add_typer(codegen_app, name="codegen")
app.add_typer(ti_app, name="ti")


def version_callback(value: bool) -> None:
    """Print version and exit."""
    if value:
        console.print(f"[bold cyan]fwkit[/bold cyan] version [green]{__version__}[/green]")
        raise typer.Exit()


@app.callback()
def main(
    version: bool | None = typer.Option(
        None,
        "--version",
        "-v",
        help="Show version and exit",
        callback=version_callback,
        is_eager=True,
    ),
) -> None:
    """
    fwkit - Firmware Development Toolkit

    Manage embedded firmware projects with ease.
    """
    pass


@app.command()
def hello() -> None:
    """Test command - prints a welcome message."""
    console.print("[bold green]Welcome to fwkit![/bold green]")
    console.print("The Firmware Development Toolkit is ready to use.")
    console.print("\nTry: [cyan]fwkit --help[/cyan] to see available commands.")


if __name__ == "__main__":
    app()
