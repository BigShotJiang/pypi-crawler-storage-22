"""Code generation package."""

__all__: list[str] = []
