"""Code generation CLI commands."""

from pathlib import Path

import typer
from rich.panel import Panel

from fwkit.codegen.template_renderer import TemplateRenderer
from fwkit.codegen.version import VersionGenerator
from fwkit.common.console import console
from fwkit.common.exceptions import FwkitError

app = typer.Typer(
    name="codegen",
    help="Code generation commands",
    rich_markup_mode="rich",
)


@app.command(name="version")
def generate_version(
    output: Path = typer.Option(
        Path("version.h"),
        "--output",
        "-o",
        help="Output file path for generated header",
    ),
    version_file: Path | None = typer.Option(
        None,
        "--version-file",
        "-v",
        help="Path to VERSION.txt file (optional, uses Git tags if not provided)",
    ),
    repo_path: Path = typer.Option(
        Path.cwd(),
        "--repo-path",
        "-r",
        help="Path to Git repository root",
    ),
    template: Path | None = typer.Option(
        None,
        "--template",
        "-t",
        help="Custom template file (uses built-in template if not provided)",
    ),
    template_dir: Path | None = typer.Option(
        None,
        "--template-dir",
        help="Directory containing custom templates",
    ),
    force: bool = typer.Option(
        False,
        "--force",
        "-f",
        help="Overwrite output file if it exists",
    ),
) -> None:
    """
    Generate version header from Git repository information.

    This command extracts version information from Git tags and repository
    metadata, then generates a C header file with version definitions.

    [bold green]Examples:[/bold green]

    \b
    # Generate version.h in current directory
    $ fwkit codegen version

    \b
    # Generate with custom output path
    $ fwkit codegen version --output src/version.h

    \b
    # Use VERSION.txt file as base version
    $ fwkit codegen version --version-file VERSION.txt

    \b
    # Use custom template
    $ fwkit codegen version --template my_version.h.j2
    """
    try:
        # Check if output file exists
        if output.exists() and not force:
            console.print(
                f"[yellow]Warning:[/yellow] Output file [cyan]{output}[/cyan] already exists."
            )
            console.print("Use [bold]--force[/bold] to overwrite.")
            raise typer.Exit(1)

        # Validate inputs
        if version_file and not version_file.exists():
            console.print(f"[red]Error:[/red] Version file [cyan]{version_file}[/cyan] not found.")
            raise typer.Exit(1)

        if template and not template.exists():
            console.print(f"[red]Error:[/red] Template file [cyan]{template}[/cyan] not found.")
            raise typer.Exit(1)

        if template_dir and not template_dir.is_dir():
            console.print(
                f"[red]Error:[/red] Template directory [cyan]{template_dir}[/cyan] not found."
            )
            raise typer.Exit(1)

        # Generate version info
        console.print("[bold]Extracting version information...[/bold]")
        generator = VersionGenerator(repo_path=repo_path)
        version_info = generator.get_version_info(version_file=version_file)

        # Display version info
        info_text = f"""
[bold]Version Information:[/bold]
  Base Version:   [cyan]{version_info.base}[/cyan]
  Full Version:   [cyan]{version_info.full}[/cyan]
  Git Describe:   [cyan]{version_info.describe}[/cyan]
  Commit:         [cyan]{version_info.commit_hash_short}[/cyan]
  Branch:         [cyan]{version_info.branch}[/cyan]
  Tag:            [cyan]{version_info.tag}[/cyan]
  Dirty:          [cyan]{"Yes" if version_info.is_dirty else "No"}[/cyan]
  Timestamp:      [cyan]{version_info.timestamp}[/cyan]
"""
        console.print(Panel(info_text.strip(), title="📋 Version Info", border_style="blue"))

        # Prepare template context
        context = {
            "major": version_info.major,
            "minor": version_info.minor,
            "patch": version_info.patch,
            "prerelease": version_info.prerelease,
            "base": version_info.base,
            "full": version_info.full,
            "commit_hash_short": version_info.commit_hash_short,
            "tag": version_info.tag,
            "branch": version_info.branch,
            "is_dirty": version_info.is_dirty,
            "describe": version_info.describe,
            "timestamp": version_info.timestamp,
        }

        # Render template
        console.print("[bold]Generating header file...[/bold]")
        renderer = TemplateRenderer(template_dir=template_dir)

        # Determine template name
        if template:
            # If custom template is provided, copy it to a temp location
            # or use it directly if template_dir is set
            if not template_dir:
                # Use template file directly by creating temporary renderer
                renderer = TemplateRenderer(template_dir=template.parent)
                template_name = template.name
            else:
                template_name = template.name
        else:
            template_name = "version.h.j2"

        renderer.render(template_name, context, output_file=output)

        console.print(f"[bold green]✓[/bold green] Version header generated: [cyan]{output}[/cyan]")

    except FwkitError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)
    except Exception as e:
        console.print(f"[red]Unexpected error:[/red] {e}")
        raise typer.Exit(1)
