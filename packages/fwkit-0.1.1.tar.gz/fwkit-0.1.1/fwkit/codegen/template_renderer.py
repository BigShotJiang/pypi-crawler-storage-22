"""Template renderer for code generation."""

from pathlib import Path
from typing import Any

from jinja2 import (
    BaseLoader,
    ChoiceLoader,
    Environment,
    FileSystemLoader,
    PackageLoader,
    select_autoescape,
)


class TemplateRenderer:
    """Render Jinja2 templates for code generation."""

    def __init__(
        self,
        template_dir: Path | None = None,
        use_builtin: bool = True,
    ):
        """
        Initialize template renderer.

        Args:
            template_dir: Optional custom template directory. If not provided,
                         uses built-in templates from fwkit.codegen.templates.
            use_builtin: Whether to load built-in templates as fallback.
        """
        loaders: list[BaseLoader] = []

        # Add custom template directory if provided
        if template_dir:
            loaders.append(FileSystemLoader(str(template_dir)))

        # Add built-in templates
        if use_builtin:
            loaders.append(PackageLoader("fwkit.codegen", "templates"))

        # Create Jinja2 environment
        self.env = Environment(
            loader=ChoiceLoader(loaders) if len(loaders) > 1 else loaders[0],
            autoescape=select_autoescape(["html", "xml"]),
            keep_trailing_newline=True,
            trim_blocks=True,
            lstrip_blocks=True,
        )

    def render(
        self,
        template_name: str,
        context: dict[str, Any],
        output_file: Path | None = None,
    ) -> str:
        """
        Render a template with given context.

        Args:
            template_name: Name of the template file.
            context: Context dictionary for template rendering.
            output_file: Optional path to write rendered output to file.

        Returns:
            Rendered template content as string.

        Raises:
            RuntimeError: If template cannot be loaded or rendered.
        """
        try:
            template = self.env.get_template(template_name)
            content = template.render(context)

            # Write to file if output path is provided
            if output_file:
                output_file.parent.mkdir(parents=True, exist_ok=True)
                output_file.write_text(content)

            return content

        except Exception as e:
            raise RuntimeError(f"Failed to render template '{template_name}': {e}") from e
