"""
Version code generation module.

This module provides functionality to generate version headers from Git
repository information using dunamai for version extraction.
"""

from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from dunamai import Style, Version


@dataclass
class VersionInfo:
    """Version information extracted from Git repository."""

    major: int
    minor: int
    patch: int
    prerelease: str
    base: str
    full: str
    commit_hash_short: str
    tag: str
    branch: str
    is_dirty: bool
    describe: str
    timestamp: str


class VersionGenerator:
    """Generate version information from Git repository."""

    def __init__(self, repo_path: Path | None = None):
        """
        Initialize version generator.

        Args:
            repo_path: Path to Git repository root. Defaults to current directory.
        """
        self.repo_path = repo_path or Path.cwd()

    def get_version_info(
        self,
        version_file: Path | None = None,
        style: Style = Style.SemVer,
    ) -> VersionInfo:
        """
        Extract version information from Git repository.

        Args:
            version_file: Optional path to VERSION.txt file to use as base version.
                         If not provided, uses Git tags only.
            style: Version style (SemVer, PEP440, etc.). Defaults to SemVer.

        Returns:
            VersionInfo object with complete version data.

        Raises:
            RuntimeError: If Git repository is not found or version cannot be determined.
        """
        import os
        import subprocess

        try:
            # Get version from Git using dunamai
            # Change to repo directory to ensure dunamai uses the correct repo
            original_cwd = os.getcwd()
            try:
                os.chdir(str(self.repo_path))
                version = Version.from_git()
            finally:
                os.chdir(original_cwd)

            # If version_file is provided, read base version from it
            if version_file and version_file.exists():
                with open(version_file) as f:
                    base_version = f.readline().strip()
            else:
                # Use Git version as base
                base_version = version.serialize(style=style, dirty=False)

            # Parse base version
            parts = base_version.lstrip("v").split("-")[0].split(".")
            major = int(parts[0]) if len(parts) > 0 else 0
            minor = int(parts[1]) if len(parts) > 1 else 0
            patch = int(parts[2]) if len(parts) > 2 else 0

            # Extract prerelease info
            prerelease = ""
            if "-" in base_version:
                prerelease_parts = base_version.split("-", 1)
                if len(prerelease_parts) > 1:
                    prerelease = prerelease_parts[1]

            # Get Git metadata first
            commit_hash = version.commit[:7] if version.commit else "N/A"
            is_dirty = version.dirty

            # Get current branch (dunamai doesn't provide this, use git command)
            try:
                branch = subprocess.check_output(
                    ["git", "rev-parse", "--abbrev-ref", "HEAD"],
                    cwd=str(self.repo_path),
                    universal_newlines=True,
                    stderr=subprocess.DEVNULL,
                ).strip()
            except subprocess.CalledProcessError:
                branch = "N/A"

            # Get exact tag if on a tagged commit
            try:
                tag = subprocess.check_output(
                    ["git", "describe", "--tags", "--exact-match"],
                    cwd=str(self.repo_path),
                    universal_newlines=True,
                    stderr=subprocess.DEVNULL,
                ).strip()
            except subprocess.CalledProcessError:
                tag = "N/A"

            # Get git describe output
            try:
                describe = subprocess.check_output(
                    ["git", "describe", "--tags", "--always", "--dirty=-dirty"],
                    cwd=str(self.repo_path),
                    universal_newlines=True,
                    stderr=subprocess.DEVNULL,
                ).strip()
            except subprocess.CalledProcessError:
                describe = commit_hash

            # Build full version string
            # If on exact tag matching base_version, use git describe
            # Otherwise, build: base_version-commit_hash[-dirty]
            normalized_base = base_version.lstrip("v")
            normalized_tag = tag.lstrip("v")
            normalized_describe = describe.lstrip("v")

            if tag != "N/A" and normalized_tag == normalized_base:
                # On exact tag matching base version
                full_version = describe
                # Ensure dirty flag is added if needed
                if is_dirty and not full_version.endswith("-dirty"):
                    full_version += "-dirty"
            elif (
                normalized_describe == normalized_base
                or normalized_describe == f"{normalized_base}-dirty"
            ):
                # Git describe matches base version
                full_version = describe
            else:
                # Build version string: base-commit[-dirty]
                full_version = f"{base_version}-{commit_hash}"
                if is_dirty:
                    full_version += "-dirty"

            # Build timestamp
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

            return VersionInfo(
                major=major,
                minor=minor,
                patch=patch,
                prerelease=prerelease,
                base=base_version,
                full=full_version,
                commit_hash_short=commit_hash,
                tag=tag,
                branch=branch,
                is_dirty=is_dirty or False,
                describe=describe,
                timestamp=timestamp,
            )

        except Exception as e:
            raise RuntimeError(
                f"Failed to extract version information from {self.repo_path}: {e}"
            ) from e
