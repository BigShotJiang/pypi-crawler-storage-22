"""Rich console singleton for consistent terminal output."""

from rich.console import Console

# Global console instance used throughout the application
console = Console()

__all__ = ["console"]
