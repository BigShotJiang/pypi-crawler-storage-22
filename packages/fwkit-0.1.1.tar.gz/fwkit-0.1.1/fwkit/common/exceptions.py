"""Custom exceptions for fwkit."""


class FwkitError(Exception):
    """Base exception for all fwkit errors."""

    def __init__(self, message: str, details: str | None = None) -> None:
        self.message = message
        self.details = details
        super().__init__(self.message)


class ConfigurationError(FwkitError):
    """Raised when configuration is invalid or missing."""

    pass


class BuildError(FwkitError):
    """Raised when build fails."""

    pass


class ValidationError(FwkitError):
    """Raised when validation fails."""

    pass


class FileNotFoundError(FwkitError):
    """Raised when a required file is not found."""

    pass
