#!/bin/bash
# Lint and format code

set -e

echo "🎨 Formatting code with Ruff..."
uv run ruff format .

echo ""
echo "🔍 Linting with Ruff..."
uv run ruff check . --fix

echo ""
echo "🔎 Type checking with mypy..."
uv run mypy fwkit/

echo ""
echo "✅ All checks passed!"
