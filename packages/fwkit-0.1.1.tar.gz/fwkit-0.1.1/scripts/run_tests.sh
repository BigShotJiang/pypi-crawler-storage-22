#!/bin/bash
# Run all tests with coverage

set -e

echo "🧪 Running tests..."

uv run pytest \
    --cov=fwkit \
    --cov-report=html \
    --cov-report=term-missing \
    --verbose

echo ""
echo "✅ Tests complete!"
echo "📊 Coverage report: htmlcov/index.html"
