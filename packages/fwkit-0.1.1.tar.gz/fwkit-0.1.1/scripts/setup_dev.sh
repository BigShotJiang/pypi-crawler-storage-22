#!/bin/bash
# Development setup script

set -e

echo "🚀 Setting up fwkit development environment..."

# Check if uv is installed
if ! command -v uv &> /dev/null; then
    echo "❌ uv not found. Installing uv..."
    curl -LsSf https://astral.sh/uv/install.sh | sh
    export PATH="$HOME/.local/bin:$PATH"
fi

echo "✓ uv found"

# Install dependencies
echo "📦 Installing dependencies..."
uv sync --all-extras

echo "✓ Dependencies installed"

# Run tests to verify setup
echo "🧪 Running tests to verify setup..."
uv run pytest

echo ""
echo "✅ Setup complete!"
echo ""
echo "Next steps:"
echo "  source .venv/bin/activate # Activate virtual environment"
echo "  fwkit --help              # Run CLI"
echo "  uv run fwkit --help       # Run CLI with uv"
echo "  uv run pytest             # Run tests"
echo "  uv run ruff format .      # Format code"
echo "  uv run ruff check .       # Lint code"
