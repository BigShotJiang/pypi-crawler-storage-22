#!/usr/bin/env bash
# Script de validação local - roda os mesmos checks do CI/CD
# Use antes de fazer commit para evitar falhas no CI

set -e  # Exit on error

echo "🔍 Running local validation checks..."
echo ""

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check 1: Ruff format
echo "📝 Checking code formatting with ruff..."
if uv run ruff format --check .; then
    echo -e "${GREEN}✓ Format check passed${NC}"
else
    echo -e "${RED}✗ Format check failed${NC}"
    echo -e "${YELLOW}Run: uv run ruff format .${NC}"
    exit 1
fi
echo ""

# Check 2: Ruff linting
echo "🔎 Checking code quality with ruff..."
if uv run ruff check .; then
    echo -e "${GREEN}✓ Lint check passed${NC}"
else
    echo -e "${RED}✗ Lint check failed${NC}"
    echo -e "${YELLOW}Run: uv run ruff check --fix .${NC}"
    exit 1
fi
echo ""

# Check 3: Type checking
echo "🔬 Checking types with mypy..."
if uv run mypy fwkit/; then
    echo -e "${GREEN}✓ Type check passed${NC}"
else
    echo -e "${RED}✗ Type check failed${NC}"
    exit 1
fi
echo ""

# Check 4: Tests
echo "🧪 Running tests with pytest..."
if uv run pytest tests/ -q; then
    echo -e "${GREEN}✓ All tests passed${NC}"
else
    echo -e "${RED}✗ Tests failed${NC}"
    exit 1
fi
echo ""

echo -e "${GREEN}✨ All validation checks passed! Safe to commit.${NC}"
