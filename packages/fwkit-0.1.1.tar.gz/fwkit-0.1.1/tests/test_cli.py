"""Basic tests for the CLI."""

from typer.testing import CliRunner

from fwkit import __version__
from fwkit.cli import app

runner = CliRunner()


def test_cli_version() -> None:
    """Test --version flag."""
    result = runner.invoke(app, ["--version"])
    assert result.exit_code == 0
    assert __version__ in result.stdout


def test_cli_help() -> None:
    """Test --help flag."""
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "fwkit" in result.stdout.lower()


def test_hello_command() -> None:
    """Test hello command."""
    result = runner.invoke(app, ["hello"])
    assert result.exit_code == 0
    assert "Welcome" in result.stdout
