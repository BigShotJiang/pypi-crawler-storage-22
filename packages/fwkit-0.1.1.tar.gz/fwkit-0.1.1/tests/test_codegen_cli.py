"""Tests for codegen CLI commands."""

import subprocess

import pytest
from typer.testing import CliRunner

from fwkit.codegen.cli import app

runner = CliRunner()


@pytest.fixture
def git_repo(tmp_path):
    """Create a temporary Git repository for testing."""
    # Initialize git repo
    subprocess.run(["git", "init"], cwd=tmp_path, check=True, capture_output=True)
    subprocess.run(
        ["git", "config", "user.email", "test@example.com"],
        cwd=tmp_path,
        check=True,
        capture_output=True,
    )
    subprocess.run(
        ["git", "config", "user.name", "Test User"],
        cwd=tmp_path,
        check=True,
        capture_output=True,
    )

    # Create a dummy file and commit
    dummy_file = tmp_path / "test.txt"
    dummy_file.write_text("test")
    subprocess.run(["git", "add", "."], cwd=tmp_path, check=True, capture_output=True)
    subprocess.run(
        ["git", "commit", "-m", "Initial commit"],
        cwd=tmp_path,
        check=True,
        capture_output=True,
    )

    # Create a tag
    subprocess.run(
        ["git", "tag", "v1.0.0"],
        cwd=tmp_path,
        check=True,
        capture_output=True,
    )

    return tmp_path


class TestCodegenVersionCommand:
    """Test 'fwkit codegen version' command."""

    def test_version_help(self):
        """Test version command help."""
        result = runner.invoke(app, ["--help"])
        assert result.exit_code == 0
        assert "Generate version header" in result.stdout

    def test_version_basic(self, git_repo):
        """Test basic version generation."""
        output_file = git_repo / "version.h"

        result = runner.invoke(
            app,
            [
                "--output",
                str(output_file),
                "--repo-path",
                str(git_repo),
            ],
        )

        assert result.exit_code == 0
        assert output_file.exists()
        assert "Version header generated" in result.stdout

        # Verify content
        content = output_file.read_text()
        assert "#ifndef FIRMWARE_VERSION_H" in content
        assert "#define FW_VERSION_MAJOR" in content

    def test_version_with_version_file(self, git_repo):
        """Test version generation with VERSION.txt file."""
        version_file = git_repo / "VERSION.txt"
        version_file.write_text("2.5.7\n")

        output_file = git_repo / "version.h"

        result = runner.invoke(
            app,
            [
                "--output",
                str(output_file),
                "--version-file",
                str(version_file),
                "--repo-path",
                str(git_repo),
            ],
        )

        assert result.exit_code == 0
        assert output_file.exists()

        content = output_file.read_text()
        assert "#define FW_VERSION_MAJOR         2" in content
        assert "#define FW_VERSION_MINOR         5" in content
        assert "#define FW_VERSION_PATCH         7" in content

    def test_version_with_custom_template(self, git_repo, tmp_path):
        """Test version generation with custom template."""
        # Create custom template
        template_file = tmp_path / "custom.h.j2"
        template_file.write_text(
            "#define VERSION_MAJOR {{ major }}\n"
            "#define VERSION_MINOR {{ minor }}\n"
            "#define VERSION_PATCH {{ patch }}\n"
        )

        output_file = git_repo / "version.h"

        result = runner.invoke(
            app,
            [
                "--output",
                str(output_file),
                "--repo-path",
                str(git_repo),
                "--template",
                str(template_file),
                "--template-dir",
                str(tmp_path),
            ],
        )

        assert result.exit_code == 0
        assert output_file.exists()

        content = output_file.read_text()
        assert "#define VERSION_MAJOR" in content
        assert "#define VERSION_MINOR" in content
        assert "#define VERSION_PATCH" in content

    def test_version_without_force_fails_if_exists(self, git_repo):
        """Test that command fails if output exists and --force not used."""
        output_file = git_repo / "version.h"
        output_file.write_text("existing content")

        result = runner.invoke(
            app,
            [
                "--output",
                str(output_file),
                "--repo-path",
                str(git_repo),
            ],
        )

        assert result.exit_code == 1
        # Rich console may wrap long lines, so check for key parts separately
        assert "already" in result.stdout and "exists" in result.stdout
        assert "--force" in result.stdout
        assert "existing content" == output_file.read_text()

    def test_version_with_force_overwrites(self, git_repo):
        """Test that --force flag allows overwriting existing file."""
        output_file = git_repo / "version.h"
        output_file.write_text("existing content")

        result = runner.invoke(
            app,
            [
                "--output",
                str(output_file),
                "--repo-path",
                str(git_repo),
                "--force",
            ],
        )

        assert result.exit_code == 0
        content = output_file.read_text()
        assert "existing content" not in content
        assert "#ifndef FIRMWARE_VERSION_H" in content

    def test_version_with_nonexistent_version_file(self, git_repo):
        """Test error handling for non-existent VERSION.txt."""
        version_file = git_repo / "nonexistent.txt"
        output_file = git_repo / "version.h"

        result = runner.invoke(
            app,
            [
                "--output",
                str(output_file),
                "--version-file",
                str(version_file),
                "--repo-path",
                str(git_repo),
            ],
        )

        assert result.exit_code == 1
        assert "not found" in result.stdout

    def test_version_with_nonexistent_template(self, git_repo):
        """Test error handling for non-existent template file."""
        template_file = git_repo / "nonexistent.j2"
        output_file = git_repo / "version.h"

        result = runner.invoke(
            app,
            [
                "--output",
                str(output_file),
                "--repo-path",
                str(git_repo),
                "--template",
                str(template_file),
            ],
        )

        assert result.exit_code == 1
        assert "not found" in result.stdout

    def test_version_displays_info_panel(self, git_repo):
        """Test that version info is displayed in a panel."""
        output_file = git_repo / "version.h"

        result = runner.invoke(
            app,
            [
                "--output",
                str(output_file),
                "--repo-path",
                str(git_repo),
            ],
        )

        assert result.exit_code == 0
        assert "Version Information:" in result.stdout
        assert "Base Version:" in result.stdout
        assert "Full Version:" in result.stdout
        assert "Git Describe:" in result.stdout
        assert "Commit:" in result.stdout
        assert "Branch:" in result.stdout
