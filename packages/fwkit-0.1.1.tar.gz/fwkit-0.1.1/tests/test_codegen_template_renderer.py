"""Tests for template renderer module."""

import pytest

from fwkit.codegen.template_renderer import TemplateRenderer


class TestTemplateRenderer:
    """Test TemplateRenderer class."""

    def test_init_with_builtin_templates(self):
        """Test initialization with built-in templates."""
        renderer = TemplateRenderer()
        assert renderer.env is not None

    def test_init_with_custom_template_dir(self, tmp_path):
        """Test initialization with custom template directory."""
        renderer = TemplateRenderer(template_dir=tmp_path)
        assert renderer.env is not None

    def test_render_builtin_template(self):
        """Test rendering built-in version.h.j2 template."""
        renderer = TemplateRenderer()

        context = {
            "major": 1,
            "minor": 2,
            "patch": 3,
            "prerelease": "rc1",
            "base": "1.2.3-rc1",
            "full": "1.2.3-rc1+abc1234",
            "commit_hash_short": "abc1234",
            "tag": "v1.2.3-rc1",
            "branch": "main",
            "is_dirty": False,
            "describe": "v1.2.3-rc1-0-gabc1234",
            "timestamp": "2026-02-15 12:00:00",
        }

        content = renderer.render("version.h.j2", context)

        # Verify content contains expected defines
        assert "#ifndef FIRMWARE_VERSION_H" in content
        assert "#define FW_VERSION_MAJOR         1" in content
        assert "#define FW_VERSION_MINOR         2" in content
        assert "#define FW_VERSION_PATCH         3" in content
        assert '#define FW_VERSION_PRERELEASE    "rc1"' in content
        assert '#define FW_VERSION_BASE_STRING   "1.2.3-rc1"' in content
        assert '#define FW_GIT_COMMIT_HASH_SHORT "abc1234"' in content
        assert '#define FW_GIT_BRANCH            "main"' in content
        assert "#define FW_GIT_IS_DIRTY          0" in content
        assert "#endif // FIRMWARE_VERSION_H" in content

    def test_render_custom_template(self, tmp_path):
        """Test rendering custom template."""
        # Create custom template
        template_file = tmp_path / "custom.j2"
        template_file.write_text("Version: {{ major }}.{{ minor }}.{{ patch }}\n")

        renderer = TemplateRenderer(template_dir=tmp_path)

        context = {"major": 2, "minor": 5, "patch": 7}
        content = renderer.render("custom.j2", context)

        assert content == "Version: 2.5.7\n"

    def test_render_to_file(self, tmp_path):
        """Test rendering template to file."""
        renderer = TemplateRenderer()

        context = {
            "major": 1,
            "minor": 0,
            "patch": 0,
            "prerelease": "",
            "base": "1.0.0",
            "full": "1.0.0",
            "commit_hash_short": "1234567",
            "tag": "v1.0.0",
            "branch": "main",
            "is_dirty": False,
            "describe": "v1.0.0",
            "timestamp": "2026-02-15 12:00:00",
        }

        output_file = tmp_path / "output" / "version.h"
        content = renderer.render("version.h.j2", context, output_file=output_file)

        # Verify file was created
        assert output_file.exists()
        assert output_file.read_text() == content
        assert "#define FW_VERSION_MAJOR         1" in content

    def test_render_dirty_flag(self, tmp_path):
        """Test rendering with dirty flag set."""
        renderer = TemplateRenderer()

        context = {
            "major": 1,
            "minor": 0,
            "patch": 0,
            "prerelease": "",
            "base": "1.0.0",
            "full": "1.0.0-dirty",
            "commit_hash_short": "1234567",
            "tag": "N/A",
            "branch": "develop",
            "is_dirty": True,
            "describe": "v1.0.0-1-g1234567-dirty",
            "timestamp": "2026-02-15 12:00:00",
        }

        content = renderer.render("version.h.j2", context)

        assert "#define FW_GIT_IS_DIRTY          1" in content
        assert '#define FW_VERSION_STRING_FULL   "1.0.0-dirty"' in content

    def test_render_nonexistent_template_raises_error(self):
        """Test that rendering non-existent template raises error."""
        renderer = TemplateRenderer()

        with pytest.raises(RuntimeError) as exc_info:
            renderer.render("nonexistent.j2", {})

        assert "Failed to render template" in str(exc_info.value)

    def test_render_with_missing_context_variable(self):
        """Test rendering with missing context variable."""
        # Create template with undefined variable
        renderer = TemplateRenderer()

        # Built-in template expects all variables, so missing ones will render as empty
        # This is actually expected behavior for Jinja2 in non-strict mode
        context = {
            "major": 1,
            "minor": 0,
            "patch": 0,
            # Missing other required variables
        }

        # This should not raise an error, but will have empty/undefined values
        content = renderer.render("version.h.j2", context)
        assert content is not None
