"""Tests for version generation module."""

import subprocess
from pathlib import Path

import pytest

from fwkit.codegen.version import VersionGenerator, VersionInfo


class TestVersionGenerator:
    """Test VersionGenerator class."""

    def test_init_default_path(self):
        """Test initialization with default repo path."""
        generator = VersionGenerator()
        assert generator.repo_path == Path.cwd()

    def test_init_custom_path(self, tmp_path):
        """Test initialization with custom repo path."""
        generator = VersionGenerator(repo_path=tmp_path)
        assert generator.repo_path == tmp_path

    def test_get_version_info_in_git_repo(self, tmp_path):
        """Test version extraction from a Git repository."""
        # Initialize a git repo
        subprocess.run(["git", "init"], cwd=tmp_path, check=True, capture_output=True)
        subprocess.run(
            ["git", "config", "user.email", "test@example.com"],
            cwd=tmp_path,
            check=True,
            capture_output=True,
        )
        subprocess.run(
            ["git", "config", "user.name", "Test User"],
            cwd=tmp_path,
            check=True,
            capture_output=True,
        )

        # Create a dummy file and commit
        dummy_file = tmp_path / "test.txt"
        dummy_file.write_text("test")
        subprocess.run(["git", "add", "."], cwd=tmp_path, check=True, capture_output=True)
        subprocess.run(
            ["git", "commit", "-m", "Initial commit"],
            cwd=tmp_path,
            check=True,
            capture_output=True,
        )

        # Create a tag
        subprocess.run(
            ["git", "tag", "v1.2.3"],
            cwd=tmp_path,
            check=True,
            capture_output=True,
        )

        # Generate version info
        generator = VersionGenerator(repo_path=tmp_path)
        version_info = generator.get_version_info()

        # Verify version info
        assert isinstance(version_info, VersionInfo)
        assert version_info.major == 1
        assert version_info.minor == 2
        assert version_info.patch == 3
        assert version_info.tag == "v1.2.3"
        assert version_info.branch in ["main", "master"]  # Git default branch
        assert not version_info.is_dirty
        assert len(version_info.commit_hash_short) == 7

    def test_get_version_info_with_version_file(self, tmp_path):
        """Test version extraction with VERSION.txt file."""
        # Initialize git repo
        subprocess.run(["git", "init"], cwd=tmp_path, check=True, capture_output=True)
        subprocess.run(
            ["git", "config", "user.email", "test@example.com"],
            cwd=tmp_path,
            check=True,
            capture_output=True,
        )
        subprocess.run(
            ["git", "config", "user.name", "Test User"],
            cwd=tmp_path,
            check=True,
            capture_output=True,
        )

        # Create VERSION.txt
        version_file = tmp_path / "VERSION.txt"
        version_file.write_text("2.5.7\n")

        # Create dummy commit
        subprocess.run(["git", "add", "."], cwd=tmp_path, check=True, capture_output=True)
        subprocess.run(
            ["git", "commit", "-m", "Initial commit"],
            cwd=tmp_path,
            check=True,
            capture_output=True,
        )

        # Generate version info with version file
        generator = VersionGenerator(repo_path=tmp_path)
        version_info = generator.get_version_info(version_file=version_file)

        assert version_info.major == 2
        assert version_info.minor == 5
        assert version_info.patch == 7
        assert version_info.base == "2.5.7"

    def test_get_version_info_dirty_repo(self, tmp_path):
        """Test version extraction from dirty repository."""
        # Initialize git repo
        subprocess.run(["git", "init"], cwd=tmp_path, check=True, capture_output=True)
        subprocess.run(
            ["git", "config", "user.email", "test@example.com"],
            cwd=tmp_path,
            check=True,
            capture_output=True,
        )
        subprocess.run(
            ["git", "config", "user.name", "Test User"],
            cwd=tmp_path,
            check=True,
            capture_output=True,
        )

        # Create and commit a file
        file1 = tmp_path / "file1.txt"
        file1.write_text("content1")
        subprocess.run(["git", "add", "."], cwd=tmp_path, check=True, capture_output=True)
        subprocess.run(
            ["git", "commit", "-m", "Initial commit"],
            cwd=tmp_path,
            check=True,
            capture_output=True,
        )
        subprocess.run(
            ["git", "tag", "v1.0.0"],
            cwd=tmp_path,
            check=True,
            capture_output=True,
        )

        # Create an uncommitted file (dirty repo)
        file2 = tmp_path / "file2.txt"
        file2.write_text("content2")

        # Generate version info
        generator = VersionGenerator(repo_path=tmp_path)
        version_info = generator.get_version_info()

        assert version_info.is_dirty
        assert "dirty" in version_info.full.lower()

    def test_get_version_info_with_prerelease(self, tmp_path):
        """Test version extraction with prerelease tag."""
        # Initialize git repo
        subprocess.run(["git", "init"], cwd=tmp_path, check=True, capture_output=True)
        subprocess.run(
            ["git", "config", "user.email", "test@example.com"],
            cwd=tmp_path,
            check=True,
            capture_output=True,
        )
        subprocess.run(
            ["git", "config", "user.name", "Test User"],
            cwd=tmp_path,
            check=True,
            capture_output=True,
        )

        # Create VERSION.txt with prerelease
        version_file = tmp_path / "VERSION.txt"
        version_file.write_text("1.0.0-rc1\n")

        # Create dummy commit
        subprocess.run(["git", "add", "."], cwd=tmp_path, check=True, capture_output=True)
        subprocess.run(
            ["git", "commit", "-m", "Initial commit"],
            cwd=tmp_path,
            check=True,
            capture_output=True,
        )

        # Generate version info
        generator = VersionGenerator(repo_path=tmp_path)
        version_info = generator.get_version_info(version_file=version_file)

        assert version_info.major == 1
        assert version_info.minor == 0
        assert version_info.patch == 0
        assert version_info.prerelease == "rc1"

    def test_get_version_info_non_git_repo_raises_error(self, tmp_path):
        """Test that non-git repository raises error."""
        generator = VersionGenerator(repo_path=tmp_path)

        with pytest.raises(RuntimeError) as exc_info:
            generator.get_version_info()

        assert "Failed to extract version" in str(exc_info.value)
