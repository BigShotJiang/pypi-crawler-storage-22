"""Tests for common exceptions."""

from fwkit.common.exceptions import (
    BuildError,
    ConfigurationError,
    FwkitError,
    ValidationError,
)


def test_base_exception() -> None:
    """Test base FwkitError."""
    error = FwkitError("Test error", "Details here")
    assert str(error) == "Test error"
    assert error.details == "Details here"


def test_configuration_error() -> None:
    """Test ConfigurationError."""
    error = ConfigurationError("Invalid config")
    assert isinstance(error, FwkitError)
    assert str(error) == "Invalid config"


def test_build_error() -> None:
    """Test BuildError."""
    error = BuildError("Build failed")
    assert isinstance(error, FwkitError)
    assert str(error) == "Build failed"


def test_validation_error() -> None:
    """Test ValidationError."""
    error = ValidationError("Validation failed")
    assert isinstance(error, FwkitError)
    assert str(error) == "Validation failed"
