"""Test the package imports."""

import fwkit


def test_version_exists() -> None:
    """Test that __version__ is defined."""
    assert hasattr(fwkit, "__version__")
    assert isinstance(fwkit.__version__, str)
    assert len(fwkit.__version__) > 0


def test_app_exists() -> None:
    """Test that app is importable."""
    assert hasattr(fwkit, "app")
    assert fwkit.app is not None
