"""Tests for TI CCS build automation."""

from unittest.mock import MagicMock, patch

import pytest

from fwkit.vendors.ti.ccs_builder import CCSBuilder


class TestCCSBuilder:
    """Test CCS build automation."""

    def test_init_with_valid_path(self, tmp_path):
        """Test initialization with valid CCS CLI path."""
        # Create fake ccs-server-cli
        ccs_cli = tmp_path / "ccs-server-cli.sh"
        ccs_cli.write_text("#!/bin/bash\necho 'test'")

        builder = CCSBuilder(ccs_cli)
        assert builder.ccs_cli_path == ccs_cli

    def test_init_with_nonexistent_path(self, tmp_path):
        """Test initialization with non-existent CCS CLI path."""
        ccs_cli = tmp_path / "nonexistent.sh"

        with pytest.raises(FileNotFoundError, match="CCS server CLI not found"):
            CCSBuilder(ccs_cli)

    @patch("subprocess.run")
    def test_build_project_default_settings(self, mock_run, tmp_path):
        """Test building project with default settings."""
        # Setup
        ccs_cli = tmp_path / "ccs-server-cli.sh"
        ccs_cli.write_text("#!/bin/bash")

        workspace = tmp_path / "workspace"
        workspace.mkdir()

        mock_run.return_value = MagicMock(returncode=0)

        # Execute
        builder = CCSBuilder(ccs_cli)
        result = builder.build_project("my_project", workspace)

        # Verify
        assert result is True
        mock_run.assert_called_once()

        # Check command structure
        call_args = mock_run.call_args[0][0]
        assert str(ccs_cli) in call_args
        assert "-workspace" in call_args
        assert "com.ti.ccs.apps.buildProject" in call_args
        assert "my_project" in call_args
        assert "Debug" in call_args
        assert "full" in call_args

    @patch("subprocess.run")
    def test_build_project_release_config(self, mock_run, tmp_path):
        """Test building project with Release configuration."""
        # Setup
        ccs_cli = tmp_path / "ccs-server-cli.sh"
        ccs_cli.write_text("#!/bin/bash")

        workspace = tmp_path / "workspace"
        workspace.mkdir()

        mock_run.return_value = MagicMock(returncode=0)

        # Execute
        builder = CCSBuilder(ccs_cli)
        result = builder.build_project("my_project", workspace, configuration="Release")

        # Verify
        assert result is True
        call_args = mock_run.call_args[0][0]
        assert "Release" in call_args

    @patch("subprocess.run")
    def test_build_project_incremental(self, mock_run, tmp_path):
        """Test incremental build."""
        # Setup
        ccs_cli = tmp_path / "ccs-server-cli.sh"
        ccs_cli.write_text("#!/bin/bash")

        workspace = tmp_path / "workspace"
        workspace.mkdir()

        mock_run.return_value = MagicMock(returncode=0)

        # Execute
        builder = CCSBuilder(ccs_cli)
        result = builder.build_project("my_project", workspace, build_type="incremental")

        # Verify
        assert result is True
        call_args = mock_run.call_args[0][0]
        assert "incremental" in call_args

    @patch("subprocess.run")
    def test_clean_project(self, mock_run, tmp_path):
        """Test cleaning project."""
        # Setup
        ccs_cli = tmp_path / "ccs-server-cli.sh"
        ccs_cli.write_text("#!/bin/bash")

        workspace = tmp_path / "workspace"
        workspace.mkdir()

        mock_run.return_value = MagicMock(returncode=0)

        # Execute
        builder = CCSBuilder(ccs_cli)
        result = builder.clean_project("my_project", workspace)

        # Verify
        assert result is True
        call_args = mock_run.call_args[0][0]
        assert "clean" in call_args

    def test_build_nonexistent_workspace(self, tmp_path):
        """Test building with non-existent workspace."""
        ccs_cli = tmp_path / "ccs-server-cli.sh"
        ccs_cli.write_text("#!/bin/bash")

        workspace = tmp_path / "nonexistent_workspace"

        builder = CCSBuilder(ccs_cli)

        with pytest.raises(FileNotFoundError, match="Workspace not found"):
            builder.build_project("my_project", workspace)

    @patch("subprocess.run")
    def test_build_project_all_configurations(self, mock_run, tmp_path):
        """Test building with all supported build types."""
        # Setup
        ccs_cli = tmp_path / "ccs-server-cli.sh"
        ccs_cli.write_text("#!/bin/bash")

        workspace = tmp_path / "workspace"
        workspace.mkdir()

        mock_run.return_value = MagicMock(returncode=0)

        builder = CCSBuilder(ccs_cli)

        # Test all build types
        for build_type in ["full", "incremental", "clean"]:
            result = builder.build_project("my_project", workspace, build_type=build_type)
            assert result is True

    @patch("subprocess.run")
    def test_build_project_fails_on_nonzero_return_code(self, mock_run, tmp_path):
        """Test build failure when ccs-server-cli returns non-zero."""
        ccs_cli = tmp_path / "ccs-server-cli.sh"
        ccs_cli.write_text("#!/bin/bash")

        workspace = tmp_path / "workspace"
        workspace.mkdir()

        mock_run.return_value = MagicMock(returncode=1, stdout="", stderr="Build failed")

        builder = CCSBuilder(ccs_cli)
        with pytest.raises(RuntimeError, match="exited with code 1"):
            builder.build_project("my_project", workspace)

    @patch("subprocess.run")
    def test_build_project_fails_on_error_output_with_zero_return_code(self, mock_run, tmp_path):
        """Test build failure when CCS reports error but exits with code 0."""
        ccs_cli = tmp_path / "ccs-server-cli.sh"
        ccs_cli.write_text("#!/bin/bash")

        workspace = tmp_path / "workspace"
        workspace.mkdir()

        mock_run.return_value = MagicMock(
            returncode=0,
            stdout="Ccs-server:\nAn error has occurred. See the log file\nnull.\n",
            stderr="",
        )

        builder = CCSBuilder(ccs_cli)
        with pytest.raises(RuntimeError, match="returned code 0 but reported errors"):
            builder.build_project("my_project", workspace)

    @patch("subprocess.run")
    def test_build_project_fails_when_requested_project_is_missing(self, mock_run, tmp_path):
        """Test build failure when CCS warns project was not found."""
        ccs_cli = tmp_path / "ccs-server-cli.sh"
        ccs_cli.write_text("#!/bin/bash")

        workspace = tmp_path / "workspace"
        workspace.mkdir()

        mock_run.return_value = MagicMock(
            returncode=0,
            stdout="!WARNING: Project '__missing__' was not found in the workspace - ignoring...\n",
            stderr="",
        )

        builder = CCSBuilder(ccs_cli)
        with pytest.raises(RuntimeError, match="Requested project was not found"):
            builder.build_project("__missing__", workspace)

    @patch("subprocess.run")
    def test_build_project_fails_when_ccs_summary_reports_errors(self, mock_run, tmp_path):
        """Test build failure when CCS summary reports projects with errors."""
        ccs_cli = tmp_path / "ccs-server-cli.sh"
        ccs_cli.write_text("#!/bin/bash")

        workspace = tmp_path / "workspace"
        workspace.mkdir()

        mock_run.return_value = MagicMock(
            returncode=0,
            stdout="# [date]: CCS headless build complete - 1 out of 1 projects have errors\n",
            stderr="",
        )

        builder = CCSBuilder(ccs_cli)
        with pytest.raises(RuntimeError, match="summary reported project build errors"):
            builder.build_project("my_project", workspace)
