"""Tests for TI CCS project management."""

from unittest.mock import MagicMock, patch

import pytest

from fwkit.vendors.ti.ccs_project import CCSProject


class TestCCSProject:
    """Test CCS project management."""

    def test_init_with_valid_path(self, tmp_path):
        """Test initialization with valid CCS CLI path."""
        # Create fake ccs-server-cli
        ccs_cli = tmp_path / "ccs-server-cli.sh"
        ccs_cli.write_text("#!/bin/bash\necho 'test'")

        project = CCSProject(ccs_cli)
        assert project.ccs_cli_path == ccs_cli

    def test_init_with_nonexistent_path(self, tmp_path):
        """Test initialization with non-existent CCS CLI path."""
        ccs_cli = tmp_path / "nonexistent.sh"

        with pytest.raises(FileNotFoundError, match="CCS server CLI not found"):
            CCSProject(ccs_cli)

    @patch("subprocess.run")
    def test_import_project(self, mock_run, tmp_path):
        """Test importing a project."""
        # Setup
        ccs_cli = tmp_path / "ccs-server-cli.sh"
        ccs_cli.write_text("#!/bin/bash")

        projectspec = tmp_path / "test.projectspec"
        projectspec.write_text("<projectspec></projectspec>")

        workspace = tmp_path / "workspace"

        mock_run.return_value = MagicMock(returncode=0)

        # Execute
        project = CCSProject(ccs_cli)
        result = project.import_project(projectspec, workspace)

        # Verify
        assert result is True
        assert workspace.exists()
        mock_run.assert_called_once()

        # Check command structure
        call_args = mock_run.call_args[0][0]
        assert str(ccs_cli) in call_args
        assert "-workspace" in call_args
        assert "com.ti.ccs.apps.createProject" in call_args
        assert str(projectspec) in call_args

    def test_import_nonexistent_projectspec(self, tmp_path):
        """Test importing non-existent projectspec."""
        ccs_cli = tmp_path / "ccs-server-cli.sh"
        ccs_cli.write_text("#!/bin/bash")

        projectspec = tmp_path / "nonexistent.projectspec"
        workspace = tmp_path / "workspace"

        project = CCSProject(ccs_cli)

        with pytest.raises(FileNotFoundError, match="Projectspec file not found"):
            project.import_project(projectspec, workspace)

    @patch.dict("os.environ", {"CCS_SERVER_CLI": "/fake/path/ccs-server-cli.sh"})
    def test_get_default_ccs_cli_from_env(self, tmp_path):
        """Test getting default CCS CLI path from environment."""
        # Create the path that env var points to
        fake_cli = tmp_path / "ccs-server-cli.sh"
        fake_cli.write_text("#!/bin/bash")

        with patch.dict("os.environ", {"CCS_SERVER_CLI": str(fake_cli)}):
            path = CCSProject.get_default_ccs_cli_path()
            assert path == fake_cli

    @patch.dict("os.environ", {}, clear=True)
    def test_get_default_ccs_cli_not_found(self):
        """Test when no default CCS CLI path is found."""
        with patch("glob.glob", return_value=[]):
            path = CCSProject.get_default_ccs_cli_path()
            assert path is None

    @patch("subprocess.run")
    def test_import_with_custom_location(self, mock_run, tmp_path):
        """Test importing with custom project location."""
        # Setup
        ccs_cli = tmp_path / "ccs-server-cli.sh"
        ccs_cli.write_text("#!/bin/bash")

        projectspec = tmp_path / "test.projectspec"
        projectspec.write_text("<projectspec></projectspec>")

        workspace = tmp_path / "workspace"
        custom_location = tmp_path / "custom_project_location"

        mock_run.return_value = MagicMock(returncode=0)

        # Execute
        project = CCSProject(ccs_cli)
        result = project.import_project(projectspec, workspace, project_location=custom_location)

        # Verify
        assert result is True
        call_args = mock_run.call_args[0][0]
        assert str(custom_location) in call_args

    @patch("subprocess.run")
    def test_import_project_fails_on_nonzero_return_code(self, mock_run, tmp_path):
        """Test import failure when ccs-server-cli returns non-zero."""
        ccs_cli = tmp_path / "ccs-server-cli.sh"
        ccs_cli.write_text("#!/bin/bash")

        projectspec = tmp_path / "test.projectspec"
        projectspec.write_text("<projectspec></projectspec>")
        workspace = tmp_path / "workspace"

        mock_run.return_value = MagicMock(returncode=1, stdout="", stderr="Import failed")

        project = CCSProject(ccs_cli)
        with pytest.raises(RuntimeError, match="exited with code 1"):
            project.import_project(projectspec, workspace)

    @patch("subprocess.run")
    def test_import_project_fails_on_error_output_with_zero_return_code(self, mock_run, tmp_path):
        """Test import failure when CCS reports !ERROR but exits with code 0."""
        ccs_cli = tmp_path / "ccs-server-cli.sh"
        ccs_cli.write_text("#!/bin/bash")

        projectspec = tmp_path / "test.projectspec"
        projectspec.write_text("<projectspec></projectspec>")
        workspace = tmp_path / "workspace"

        mock_run.return_value = MagicMock(
            returncode=0,
            stdout="!ERROR: A file or directory already exists at location '/tmp/test'\n",
            stderr="",
        )

        project = CCSProject(ccs_cli)
        with pytest.raises(RuntimeError, match="returned code 0 but reported errors"):
            project.import_project(projectspec, workspace)
