"""Tests for TI CCS ProjectSpecGenerator."""

import pytest

from fwkit.vendors.ti.projectspec_generator import ProjectSpecGenerator
from fwkit.vendors.ti.schemas import ProjectSpecConfig


class TestProjectSpecGenerator:
    """Test ProjectSpecGenerator."""

    @pytest.fixture
    def sample_config(self) -> ProjectSpecConfig:
        """Create a sample ProjectSpecConfig for testing."""
        config = ProjectSpecConfig(
            device_id="Cortex M.CC2652R1F",
            title="Test Project",
            name="test_project",
            cgt_version="4.0.4.LTS",
            device="Cortex M.CC2652R1F",
            description="A test project",
            connection="TIXDS110_Connection.xml",
            compiler_build_options=["-O2", "-g", "-DTEST=1"],
            linker_build_options=["-lm", "-l:test.cmd"],
            sysconfig_build_options=[
                "--product ${COM_TI_SIMPLELINK_CC13XX_CC26XX_SDK_INSTALL_DIR}/"
                ".metadata/product.json"
            ],
            pre_build_step="echo 'Pre-build'",
            post_build_step="echo 'Post-build'",
        )

        config.add_file("main.c")
        config.add_file("test.c", action="link")
        config.add_property("customProp", "customValue")

        return config

    def test_generate_basic(self, sample_config: ProjectSpecConfig, tmp_path):
        """Test generating a basic projectspec file."""
        output_file = tmp_path / "test.projectspec"

        generator = ProjectSpecGenerator()
        result = generator.generate(sample_config, output_file)

        assert result == output_file
        assert output_file.exists()

        content = output_file.read_text()

        # Check XML structure
        assert '<?xml version="1.0" encoding="UTF-8"?>' in content
        assert "<projectSpec>" in content
        assert "</projectSpec>" in content

        # Check applicability
        assert "<applicability>" in content
        assert 'deviceId="Cortex M.CC2652R1F"' in content

        # Check project attributes
        assert 'name="test_project"' in content
        assert 'cgtVersion="4.0.4.LTS"' in content

        # Check build options
        assert "-O2" in content
        assert "-g" in content
        assert "-DTEST=1" in content
        assert "-lm" in content

        # Check pre/post build
        assert "echo 'Pre-build'" in content
        assert "echo 'Post-build'" in content

        # Check files
        assert "main.c" in content
        assert "test.c" in content

    def test_generate_with_custom_template(self, sample_config: ProjectSpecConfig, tmp_path):
        """Test generating with a custom template."""
        # Create custom template
        custom_template = tmp_path / "custom.xml.j2"
        custom_template.write_text("""
<?xml version="1.0" encoding="UTF-8"?>
<projectSpec>
    <project name="{{ name }}" title="{{ title }}">
        <description>{{ description }}</description>
    </project>
</projectSpec>
""")

        output_file = tmp_path / "custom.projectspec"

        generator = ProjectSpecGenerator(template_dir=tmp_path)
        result = generator.generate(sample_config, output_file, "custom.xml.j2")

        assert result == output_file
        assert output_file.exists()

        content = output_file.read_text()
        assert 'name="test_project"' in content
        assert 'title="Test Project"' in content
        assert "A test project" in content

    def test_generate_from_platform(self, tmp_path):
        """Test generating from platforms.yaml."""
        yaml_content = """
defaults:
  project_description: "Test Description"
  compiler_version: "4.0.4.LTS"
  sysconfig_file_path: "test.syscfg"

test_platform:
  platform: "test_platform"
  project_title: "Test Platform"
  project_name: "test_platform"
  device: "Cortex M.CC2652R1F"
  device_id: "Cortex M.CC2652R1F"
  link_file_path: "test.cmd"
"""

        platforms_file = tmp_path / "platforms.yaml"
        platforms_file.write_text(yaml_content)

        output_file = tmp_path / "test_platform.projectspec"

        generator = ProjectSpecGenerator()
        result = generator.generate_from_platform(platforms_file, "test_platform", output_file)

        assert result == output_file
        assert output_file.exists()

        content = output_file.read_text()
        assert 'name="test_platform"' in content
        assert "Test Platform" in content

    def test_generate_all_platforms(self, tmp_path):
        """Test generating all platforms."""
        yaml_content = """
defaults:
  project_description: "Test Description"
  compiler_version: "4.0.4.LTS"
  sysconfig_file_path: "test.syscfg"

platform1:
  platform: "platform1"
  project_title: "Platform 1"
  project_name: "platform1"
  device: "Cortex M.CC2652R1F"
  device_id: "Cortex M.CC2652R1F"
  link_file_path: "test1.cmd"

platform2:
  platform: "platform2"
  project_title: "Platform 2"
  project_name: "platform2"
  device: "Cortex M.CC2652R7"
  device_id: "Cortex M.CC2652R7"
  link_file_path: "test2.cmd"
"""

        platforms_file = tmp_path / "platforms.yaml"
        platforms_file.write_text(yaml_content)

        output_dir = tmp_path / "output"

        generator = ProjectSpecGenerator()
        results = generator.generate_all_platforms(platforms_file, output_dir, create_subdirs=False)

        assert len(results) == 2
        assert all(f.exists() for f in results.values())

        # Check filenames
        filenames = {f.name for f in results.values()}
        assert "platform1.projectspec" in filenames
        assert "platform2.projectspec" in filenames

    def test_generate_all_platforms_with_subdirs(self, tmp_path):
        """Test generating all platforms with subdirectories."""
        yaml_content = """
defaults:
  project_description: "Test Description"
  compiler_version: "4.0.4.LTS"
  sysconfig_file_path: "test.syscfg"

platform1:
  platform: "platform1"
  project_title: "Platform 1"
  project_name: "platform1"
  device: "Cortex M.CC2652R1F"
  device_id: "Cortex M.CC2652R1F"
  link_file_path: "test1.cmd"

platform2:
  platform: "platform2"
  project_title: "Platform 2"
  project_name: "platform2"
  device: "Cortex M.CC2652R7"
  device_id: "Cortex M.CC2652R7"
  link_file_path: "test2.cmd"
"""

        platforms_file = tmp_path / "platforms.yaml"
        platforms_file.write_text(yaml_content)

        output_dir = tmp_path / "output"

        generator = ProjectSpecGenerator()
        results = generator.generate_all_platforms(platforms_file, output_dir, create_subdirs=True)

        assert len(results) == 2
        assert all(f.exists() for f in results.values())

        # Check that files are in subdirectories
        for result in results.values():
            assert result.parent != output_dir
            assert result.parent.parent == output_dir

    def test_generate_platform_not_found(self, tmp_path):
        """Test error when platform not found."""
        yaml_content = """
defaults:
  project_description: "Test Description"
  compiler_version: "4.0.4.LTS"
  sysconfig_file_path: "test.syscfg"

platform1:
  platform: "platform1"
  project_title: "Platform 1"
  project_name: "platform1"
  device: "Cortex M.CC2652R1F"
  device_id: "Cortex M.CC2652R1F"
  link_file_path: "test1.cmd"
"""

        platforms_file = tmp_path / "platforms.yaml"
        platforms_file.write_text(yaml_content)

        output_file = tmp_path / "nonexistent.projectspec"

        generator = ProjectSpecGenerator()

        with pytest.raises(RuntimeError, match="Platform 'nonexistent' not found"):
            generator.generate_from_platform(platforms_file, "nonexistent", output_file)

    def test_generate_minimal_config(self, tmp_path):
        """Test generating with minimal configuration."""
        config = ProjectSpecConfig(
            device_id="Cortex M.CC2652R1F",
            title="Minimal Project",
            name="minimal",
            cgt_version="4.0.4.LTS",
            device="Cortex M.CC2652R1F",
        )

        output_file = tmp_path / "minimal.projectspec"

        generator = ProjectSpecGenerator()
        result = generator.generate(config, output_file)

        assert result == output_file
        assert output_file.exists()

        content = output_file.read_text()

        # Should have basic structure even with minimal config
        assert "<projectSpec>" in content
        assert 'name="minimal"' in content
        assert "Cortex M.CC2652R1F" in content

    def test_generate_with_build_variables(self, sample_config: ProjectSpecConfig, tmp_path):
        """Test generating with build variables."""
        from fwkit.vendors.ti.schemas import BuildVariable

        sample_config.build_variables = [
            BuildVariable(name="MY_VAR", value="my_value"),
            BuildVariable(name="MY_PATH", value="/path/to/something", type="PATH"),
        ]

        output_file = tmp_path / "with_vars.projectspec"

        generator = ProjectSpecGenerator()
        result = generator.generate(sample_config, output_file)

        assert result == output_file
        content = output_file.read_text()

        assert "MY_VAR" in content
        assert "my_value" in content
        assert "MY_PATH" in content
