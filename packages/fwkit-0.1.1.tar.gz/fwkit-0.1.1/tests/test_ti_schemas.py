"""Tests for TI CCS schemas."""

import pytest

from fwkit.vendors.ti.schemas import (
    PlatformConfig,
    PlatformDefaults,
    PlatformsConfig,
    ProjectFile,
    ProjectProperty,
    ProjectSpecConfig,
)


class TestProjectFile:
    """Test ProjectFile model."""

    def test_create_with_defaults(self):
        """Test creating ProjectFile with default values."""
        file = ProjectFile(path="test.c")
        assert file.path == "test.c"
        assert file.action == "copy"
        assert file.open_on_creation is False
        assert file.exclude_from_build is False
        assert file.target_directory is None

    def test_create_with_all_fields(self):
        """Test creating ProjectFile with all fields."""
        file = ProjectFile(
            path="src/main.c",
            action="link",
            open_on_creation=True,
            exclude_from_build=False,
            target_directory="src",
        )
        assert file.path == "src/main.c"
        assert file.action == "link"
        assert file.open_on_creation is True
        assert file.target_directory == "src"

    def test_validate_action(self):
        """Test action validation."""
        with pytest.raises(ValueError, match="action must be one of"):
            ProjectFile(path="test.c", action="invalid")


class TestProjectProperty:
    """Test ProjectProperty model."""

    def test_create_property(self):
        """Test creating property."""
        prop = ProjectProperty(name="buildProfile", value="release")
        assert prop.name == "buildProfile"
        assert prop.value == "release"


class TestProjectSpecConfig:
    """Test ProjectSpecConfig model."""

    def test_create_minimal_config(self):
        """Test creating minimal configuration."""
        config = ProjectSpecConfig(
            device_id="Cortex M.CC2652R1F",
            title="Test Project",
            name="test_project",
            cgt_version="4.0.4.LTS",
            device="Cortex M.CC2652R1F",
        )
        assert config.title == "Test Project"
        assert config.name == "test_project"
        assert config.device == "Cortex M.CC2652R1F"
        assert config.tool_chain == "TICLANG"  # default

    def test_add_file(self):
        """Test adding files to config."""
        config = ProjectSpecConfig(
            device_id="Cortex M.CC2652R1F",
            title="Test",
            name="test",
            cgt_version="4.0.4.LTS",
            device="Cortex M.CC2652R1F",
        )

        config.add_file("main.c")
        config.add_file("test.c", action="link", open_on_creation=True)

        assert len(config.files) == 2
        assert config.files[0].path == "main.c"
        assert config.files[0].action == "copy"
        assert config.files[1].path == "test.c"
        assert config.files[1].action == "link"

    def test_add_property(self):
        """Test adding properties."""
        config = ProjectSpecConfig(
            device_id="Cortex M.CC2652R1F",
            title="Test",
            name="test",
            cgt_version="4.0.4.LTS",
            device="Cortex M.CC2652R1F",
        )

        config.add_property("key", "value")

        # Should have default properties + new one
        assert len(config.properties) >= 3
        assert any(p.name == "key" and p.value == "value" for p in config.properties)

    def test_to_dict(self):
        """Test converting to dictionary."""
        config = ProjectSpecConfig(
            device_id="Cortex M.CC2652R1F",
            title="Test",
            name="test",
            cgt_version="4.0.4.LTS",
            device="Cortex M.CC2652R1F",
        )

        data = config.to_dict()
        assert isinstance(data, dict)
        assert data["title"] == "Test"
        assert data["device"] == "Cortex M.CC2652R1F"


class TestPlatformDefaults:
    """Test PlatformDefaults model."""

    def test_create_defaults(self):
        """Test creating defaults."""
        defaults = PlatformDefaults(
            project_description="Test Project", compiler_version="4.0.4.LTS"
        )
        assert defaults.project_description == "Test Project"
        assert defaults.compiler_version == "4.0.4.LTS"
        assert defaults.mfloat_abi == "hard"  # default

    def test_validate_mfloat_abi(self):
        """Test mfloat_abi validation."""
        defaults = PlatformDefaults(
            project_description="Test", compiler_version="4.0.4.LTS", mfloat_abi="soft"
        )
        assert defaults.mfloat_abi == "soft"

        with pytest.raises(ValueError, match="mfloat_abi must be one of"):
            PlatformDefaults(
                project_description="Test", compiler_version="4.0.4.LTS", mfloat_abi="invalid"
            )


class TestPlatformConfig:
    """Test PlatformConfig model."""

    def test_merge_with_defaults(self):
        """Test merging platform config with defaults."""
        defaults = PlatformDefaults(
            project_description="Default Description",
            compiler_version="4.0.4.LTS",
            compiler_build_options=["-O2", "-g"],
            linker_build_options=["-lm"],
        )

        platform = PlatformConfig(
            platform="test_platform",
            project_title="Test Platform",
            project_name="test_platform",
            device="Cortex M.CC2652R1F",
            device_id="Cortex M.CC2652R1F",
            compiler_build_options=["-DTEST"],
        )

        merged = platform.merge_with_defaults(defaults)

        assert isinstance(merged, ProjectSpecConfig)
        assert merged.title == "Test Platform"
        assert merged.cgt_version == "4.0.4.LTS"  # from defaults
        # Should have both default and platform-specific compiler options
        assert "-O2" in merged.compiler_build_options
        assert "-DTEST" in merged.compiler_build_options


class TestPlatformsConfig:
    """Test PlatformsConfig model."""

    def test_from_yaml_file(self, tmp_path):
        """Test loading from YAML file."""
        yaml_content = """
defaults:
  project_description: "Test Project"
  compiler_version: "4.0.4.LTS"
  sysconfig_file_path: "test.syscfg"

platform1:
  platform: "platform1"
  project_title: "Platform 1"
  project_name: "platform1"
  device: "Cortex M.CC2652R1F"
  device_id: "Cortex M.CC2652R1F"
  link_file_path: "test.cmd"

platform2:
  platform: "platform2"
  project_title: "Platform 2"
  project_name: "platform2"
  device: "Cortex M.CC2652R7"
  device_id: "Cortex M.CC2652R7"
  link_file_path: "test2.cmd"
"""

        yaml_file = tmp_path / "platforms.yaml"
        yaml_file.write_text(yaml_content)

        config = PlatformsConfig.from_yaml_file(yaml_file)

        assert config.defaults.compiler_version == "4.0.4.LTS"
        assert len(config.platforms) == 2
        assert "platform1" in config.platforms
        assert "platform2" in config.platforms

    def test_list_platforms(self, tmp_path):
        """Test listing platforms."""
        yaml_content = """
defaults:
  project_description: "Test"
  compiler_version: "4.0.4.LTS"
  sysconfig_file_path: "test.syscfg"

p1:
  platform: "p1"
  project_title: "P1"
  project_name: "p1"
  device: "Cortex M.CC2652R1F"
  device_id: "Cortex M.CC2652R1F"
  link_file_path: "test.cmd"

p2:
  platform: "p2"
  project_title: "P2"
  project_name: "p2"
  device: "Cortex M.CC2652R7"
  device_id: "Cortex M.CC2652R7"
  link_file_path: "test2.cmd"
"""

        yaml_file = tmp_path / "platforms.yaml"
        yaml_file.write_text(yaml_content)

        config = PlatformsConfig.from_yaml_file(yaml_file)
        platforms = config.list_platforms()

        assert len(platforms) == 2
        assert "p1" in platforms
        assert "p2" in platforms

    def test_get_platform(self, tmp_path):
        """Test getting specific platform."""
        yaml_content = """
defaults:
  project_description: "Test"
  compiler_version: "4.0.4.LTS"
  sysconfig_file_path: "test.syscfg"

myplatform:
  platform: "myplatform"
  project_title: "My Platform"
  project_name: "myplatform"
  device: "Cortex M.CC2652R1F"
  device_id: "Cortex M.CC2652R1F"
  link_file_path: "test.cmd"
"""

        yaml_file = tmp_path / "platforms.yaml"
        yaml_file.write_text(yaml_content)

        config = PlatformsConfig.from_yaml_file(yaml_file)
        platform = config.get_platform("myplatform")

        assert platform is not None
        assert platform.project_title == "My Platform"

        # Non-existent platform
        assert config.get_platform("nonexistent") is None

    def test_get_project_spec_config(self, tmp_path):
        """Test getting ProjectSpecConfig for platform."""
        yaml_content = """
defaults:
  project_description: "Test Project"
  compiler_version: "4.0.4.LTS"
  sysconfig_file_path: "test.syscfg"
  compiler_build_options:
    - "-O2"

myplatform:
  platform: "myplatform"
  project_title: "My Platform"
  project_name: "myplatform"
  device: "Cortex M.CC2652R1F"
  device_id: "Cortex M.CC2652R1F"
  link_file_path: "test.cmd"
  compiler_build_options:
    - "-DTEST"
"""

        yaml_file = tmp_path / "platforms.yaml"
        yaml_file.write_text(yaml_content)

        config = PlatformsConfig.from_yaml_file(yaml_file)
        spec_config = config.get_project_spec_config("myplatform")

        assert spec_config is not None
        assert isinstance(spec_config, ProjectSpecConfig)
        assert spec_config.title == "My Platform"
        assert "-O2" in spec_config.compiler_build_options
        assert "-DTEST" in spec_config.compiler_build_options
