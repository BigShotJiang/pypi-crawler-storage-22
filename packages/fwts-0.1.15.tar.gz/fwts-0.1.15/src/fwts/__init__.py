"""Featurebox - Git worktree workflow manager for feature development."""

__version__ = "0.1.15"
