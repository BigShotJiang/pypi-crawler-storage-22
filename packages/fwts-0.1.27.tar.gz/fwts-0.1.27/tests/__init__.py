"""Tests for fwts."""
