"""g-gremlin HubSpot MCP server — breaks the 10k ceiling."""

__version__ = "0.1.2"

MIN_GREMLIN_VERSION = "0.1.14"
