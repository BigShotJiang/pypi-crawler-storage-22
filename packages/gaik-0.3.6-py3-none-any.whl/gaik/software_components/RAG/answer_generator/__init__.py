"""Answer generator building block."""

from .generator import AnswerGenerator

__all__ = [
    "AnswerGenerator",
]

__version__ = "0.1.0"
