"""Vector store building block."""

from .vector_store import VectorStore

__all__ = [
    "VectorStore",
]

__version__ = "0.1.0"
