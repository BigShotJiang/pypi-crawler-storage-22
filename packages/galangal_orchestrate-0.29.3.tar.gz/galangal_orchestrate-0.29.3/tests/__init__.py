"""Tests for galangal-orchestrate."""
