from galtea.application.services.evaluation_service import MetricInput
from galtea.domain.models.trace import NodeType, TraceType
from galtea.galtea import Galtea
from galtea.infrastructure.telemetry.processors.galtea_processor import GalteaSpanProcessor
from galtea.utils.agent import Agent, AgentInput, AgentResponse, ConversationMessage
from galtea.utils.custom_score_metric import CustomScoreEvaluationMetric
from galtea.utils.tracing import (
    GalteaSpan,
    clear_context,
    get_inference_result_id,
    get_session_id,
    set_context,
    start_trace,
    trace,
)

__all__ = [
    "Agent",
    "AgentInput",
    "AgentResponse",
    "ConversationMessage",
    "CustomScoreEvaluationMetric",
    "Galtea",
    "GalteaSpan",
    "GalteaSpanProcessor",
    "MetricInput",
    "NodeType",  # Deprecated, use TraceType instead. Will be removed in a future version.
    "TraceType",
    "clear_context",
    "get_inference_result_id",
    "get_session_id",
    "set_context",
    "start_trace",
    "trace",
]
