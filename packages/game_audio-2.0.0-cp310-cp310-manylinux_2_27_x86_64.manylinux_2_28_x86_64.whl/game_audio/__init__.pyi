"""
Python bindings for the Game Audio Module
"""
from __future__ import annotations
import datetime
import typing
__all__: list[str] = ['AudioException', 'AudioManager', 'AudioSession', 'FileLoadException', 'GroupHandle', 'InvalidHandleException', 'LogLevel', 'NotInitializedException', 'RandomSoundContainer', 'RandomSoundContainerConfig', 'SoundHandle', 'TrackHandle']
class AudioException(RuntimeError):
    pass
class AudioManager:
    """
    Central manager for all audio functionality.
    
    The AudioManager class provides a singleton interface for all audio operations.
    It manages audio tracks, groups, and individual sounds.
    
    All methods may raise exceptions:
    - InvalidHandleException: When using an invalid handle
    - FileLoadException: When a file cannot be loaded
    - AudioException: For general audio errors
    """
    @staticmethod
    def get_instance() -> AudioManager:
        """
        Get the singleton instance of the AudioManager.
        
        Returns:
            AudioManager: The singleton instance
        """
    @staticmethod
    def get_log_level() -> LogLevel:
        """
        Get the current audio log level.
        
        Returns:
            LogLevel: Current logging level
        """
    @staticmethod
    def set_log_level(level: LogLevel) -> None:
        """
        Set the global audio log level.
        
        Args:
            level (LogLevel): Desired logging level
        """
    def add_layer(self, track: TrackHandle, layer_name: str, filepath: str, group: GroupHandle = ...) -> None:
        """
        Add an audio layer to a track.
        
        Layers are individual sounds that play simultaneously within a track.
        
        Args:
            track (TrackHandle): Handle to the track
            layer_name (str): Name identifier for the layer
            filepath (str): Path to the audio file
            group (GroupHandle, optional): Group handle to route the layer through (invalid = default/master)
        
        Raises:
            InvalidHandleException: If track handle is invalid
            FileLoadException: If audio file cannot be loaded
        """
    def create_group(self) -> GroupHandle:
        """
        Create a new audio group.
        
        Groups allow collective control of multiple sounds.
        
        Returns:
            GroupHandle: Handle to the newly created group
        
        Raises:
            AudioException: If group creation fails
        """
    def create_track(self) -> TrackHandle:
        """
        Create a new audio track.
        
        Tracks can contain multiple synchronized audio layers.
        
        Returns:
            TrackHandle: Handle to the newly created track
        
        Raises:
            AudioException: If track creation fails
        """
    def destroy_group(self, group: GroupHandle) -> None:
        """
        Destroy an audio group.
        
        Args:
            group (GroupHandle): Handle to the group to destroy
        """
    def destroy_sound(self, sound: SoundHandle) -> None:
        """
        Destroy a previously loaded sound.
        
        Args:
            sound (SoundHandle): Handle to the sound to destroy
        """
    def destroy_track(self, track: TrackHandle) -> None:
        """
        Destroy an audio track.
        
        Args:
            track (TrackHandle): Handle to the track to destroy
        """
    def fade_group(self, group: GroupHandle, target_volume: typing.SupportsFloat, duration: datetime.timedelta) -> None:
        """
        Fade a group's volume to a target value over time.
        
        Args:
            group (GroupHandle): Handle to the group
            target_volume (float): Target volume level (0.0 to 1.0)
            duration (timedelta): Duration of the fade
        """
    def fade_layer(self, track: TrackHandle, layer_name: str, target_volume: typing.SupportsFloat, duration: datetime.timedelta) -> None:
        """
        Fade a layer's volume to a target value over time.
        
        Args:
            track (TrackHandle): Handle to the track
            layer_name (str): Name of the layer
            target_volume (float): Target volume level (0.0 to 1.0)
            duration (timedelta): Duration of the fade
        """
    def get_group_volume(self, group: GroupHandle) -> float:
        """
        Get the current volume for an audio group.
        
        Args:
            group (GroupHandle): Handle to the group
        
        Returns:
            float: Current volume level (0.0 to 1.0)
        """
    def get_master_volume(self) -> float:
        """
        Get the current master volume level.
        
        Returns:
            float: Current master volume (0.0 to 1.0)
        """
    def initialize(self) -> bool:
        """
        Initialize the audio system.
        
        Must be called before any other audio operations.
        
        Returns:
            bool: True if initialization was successful, False if already initialized
        
        Raises:
            AudioException: If audio engine initialization fails
        """
    def is_initialized(self) -> bool:
        """
        Check if the audio system is initialized and running.
        
        Returns:
            bool: True if the system is initialized, False otherwise
        """
    def is_sound_playing(self, sound: SoundHandle) -> bool:
        """
        Check if a sound is currently playing.
        
        Args:
            sound (SoundHandle): Handle to the sound
        
        Returns:
            bool: True if the sound is playing, False otherwise
        """
    @typing.overload
    def load_sound(self, filepath: str) -> SoundHandle:
        """
        Load a sound from a file.
        
        Args:
            filepath (str): Path to the audio file
        
        Returns:
            SoundHandle: Handle to the loaded sound
        
        Raises:
            FileLoadException: If the file cannot be loaded
        """
    @typing.overload
    def load_sound(self, filepath: str, group: GroupHandle) -> SoundHandle:
        """
        Load a sound from a file and assign it to a group.
        
        Args:
            filepath (str): Path to the audio file
            group (GroupHandle): Handle to the audio group
        
        Returns:
            SoundHandle: Handle to the loaded sound
        
        Raises:
            FileLoadException: If the file cannot be loaded
        """
    def play_random_sound_from_folder(self, folder_path: str, group: GroupHandle = ...) -> None:
        """
        Play a random sound from a folder.
        
        Loads all .wav files from the specified folder and plays one randomly.
        Sounds are cached after first load for efficiency.
        
        Args:
            folder_path (str): Path to the folder containing sound files
            group (GroupHandle, optional): Group handle to assign the sounds to
        """
    def play_sound(self, sound: SoundHandle) -> None:
        """
        Play a sound.
        
        Args:
            sound (SoundHandle): Handle to the sound to play
        
        Raises:
            InvalidHandleException: If sound handle is invalid
        """
    def play_track(self, track: TrackHandle) -> None:
        """
        Start playing an audio track.
        
        All layers in the track will begin playing.
        
        Args:
            track (TrackHandle): Handle to the track to play
        
        Raises:
            InvalidHandleException: If track handle is invalid
        """
    def remove_layer(self, track: TrackHandle, layer_name: str) -> None:
        """
        Remove a layer from a track.
        
        Args:
            track (TrackHandle): Handle to the track
            layer_name (str): Name of the layer to remove
        """
    def set_group_volume(self, group: GroupHandle, volume: typing.SupportsFloat) -> None:
        """
        Set the volume for an entire audio group.
        
        Affects all sounds assigned to this group.
        
        Args:
            group (GroupHandle): Handle to the group
            volume (float): Volume level (0.0 to 1.0)
        
        Raises:
            InvalidHandleException: If group handle is invalid
        """
    def set_layer_volume(self, track: TrackHandle, layer_name: str, volume: typing.SupportsFloat) -> None:
        """
        Set the volume of a specific layer.
        
        Args:
            track (TrackHandle): Handle to the track
            layer_name (str): Name of the layer
            volume (float): Volume level (0.0 to 1.0)
        """
    def set_master_volume(self, volume: typing.SupportsFloat) -> None:
        """
        Set the master volume for all audio.
        
        Args:
            volume (float): Volume level (0.0 = silence, 1.0 = full volume)
        """
    def set_sound_pitch(self, sound: SoundHandle, pitch: typing.SupportsFloat) -> None:
        """
        Set the pitch of a sound for its next playback.
        
        Args:
            sound (SoundHandle): Handle to the sound
            pitch (float): Pitch multiplier (1.0 = normal, 0.5 = half speed, 2.0 = double speed)
        """
    def set_sound_volume(self, sound: SoundHandle, volume: typing.SupportsFloat) -> None:
        """
        Set the volume of a sound.
        
        Args:
            sound (SoundHandle): Handle to the sound
            volume (float): Volume level (0.0 to 1.0)
        
        Raises:
            InvalidHandleException: If sound handle is invalid
        """
    def shutdown(self) -> None:
        """
        Shut down the audio system.
        
        Cleans up all audio resources and stops all playback.
        Should be called before application exit.
        """
    def stop_sound(self, sound: SoundHandle) -> None:
        """
        Stop a currently playing sound.
        
        Args:
            sound (SoundHandle): Handle to the sound to stop
        
        Raises:
            InvalidHandleException: If sound handle is invalid
        """
    def stop_track(self, track: TrackHandle) -> None:
        """
        Stop playing an audio track.
        
        All layers in the track will stop playing.
        
        Args:
            track (TrackHandle): Handle to the track to stop
        
        Raises:
            InvalidHandleException: If track handle is invalid
        """
class AudioSession:
    """
    RAII helper that initializes audio on creation and shuts down on close/destruction.
    """
    def __enter__(self) -> AudioSession:
        ...
    def __exit__(self, arg0: typing.Any, arg1: typing.Any, arg2: typing.Any) -> bool:
        ...
    def __init__(self) -> None:
        ...
    def close(self) -> None:
        """
        Shut down the audio system if this session owns initialization.
        """
class FileLoadException(AudioException):
    pass
class GroupHandle:
    @staticmethod
    def invalid() -> GroupHandle:
        """
        Get an invalid handle.
        
        Returns:
            GroupHandle: An invalid handle (value = 0)
        """
    def __bool__(self) -> bool:
        ...
    def __eq__(self, arg0: GroupHandle) -> bool:
        ...
    def __hash__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt = 0) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, arg0: GroupHandle) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def is_valid(self) -> bool:
        """
        Check if the handle is valid.
        
        Returns:
            bool: True if the handle is valid, False otherwise
        """
    @property
    def value(self) -> int:
        ...
class InvalidHandleException(AudioException):
    pass
class LogLevel:
    """
    Members:
    
      Off
    
      Error
    
      Warn
    
      Info
    
      Debug
    """
    Debug: typing.ClassVar[LogLevel]  # value = <LogLevel.Debug: 4>
    Error: typing.ClassVar[LogLevel]  # value = <LogLevel.Error: 1>
    Info: typing.ClassVar[LogLevel]  # value = <LogLevel.Info: 3>
    Off: typing.ClassVar[LogLevel]  # value = <LogLevel.Off: 0>
    Warn: typing.ClassVar[LogLevel]  # value = <LogLevel.Warn: 2>
    __members__: typing.ClassVar[dict[str, LogLevel]]  # value = {'Off': <LogLevel.Off: 0>, 'Error': <LogLevel.Error: 1>, 'Warn': <LogLevel.Warn: 2>, 'Info': <LogLevel.Info: 3>, 'Debug': <LogLevel.Debug: 4>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class NotInitializedException(AudioException):
    pass
class RandomSoundContainer:
    """
    Container for playing randomized sounds with pitch variation.
    
    Similar to Wwise random containers, this class manages a collection
    of sound variants and plays them randomly with optional pitch shifts
    and repeat avoidance.
    """
    def __init__(self, name: str, config: RandomSoundContainerConfig = ...) -> None:
        """
        Construct a random sound container.
        
        Args:
            name (str): Name identifier for this container
            config (RandomSoundContainerConfig, optional): Configuration settings
        """
    def add_sound(self, filepath: str) -> None:
        """
        Add a sound to the container.
        
        Args:
            filepath (str): Path to the audio file
        
        Raises:
            FileLoadException: If the file cannot be loaded
        """
    def get_name(self) -> str:
        """
        Get the name of this container.
        
        Returns:
            str: Container name
        """
    def load_from_folder(self, folder_path: str) -> None:
        """
        Load all .wav files from a folder.
        
        Args:
            folder_path (str): Path to the folder containing sound files
        """
    def play(self) -> None:
        """
        Play a random sound from the container.
        
        Automatically applies pitch variation within the configured range
        and avoids repeats if enabled.
        """
    def play_with_volume(self, volume: typing.SupportsFloat) -> None:
        """
        Play a random sound with specific volume.
        
        Args:
            volume (float): Volume level (0.0 to 1.0)
        """
    def set_avoid_repeat(self, avoid: bool) -> None:
        """
        Enable or disable repeat avoidance.
        
        Args:
            avoid (bool): True to avoid playing the same sound twice in a row
        """
    def set_pitch_range(self, min_pitch: typing.SupportsFloat, max_pitch: typing.SupportsFloat) -> None:
        """
        Set the pitch range for randomization.
        
        Args:
            min_pitch (float): Minimum pitch multiplier (e.g., 0.95 for 5% lower)
            max_pitch (float): Maximum pitch multiplier (e.g., 1.05 for 5% higher)
        """
    def stop_all(self) -> None:
        """
        Stop all currently playing sounds from this container.
        """
class RandomSoundContainerConfig:
    """
    Configuration for random sound containers.
    
    Controls randomization behavior including pitch variation and repeat avoidance.
    """
    def __init__(self) -> None:
        ...
    @property
    def avoid_repeat(self) -> bool:
        """
        bool: Avoid playing the same sound twice in a row
        """
    @avoid_repeat.setter
    def avoid_repeat(self, arg0: bool) -> None:
        ...
    @property
    def group(self) -> GroupHandle:
        """
        GroupHandle: Audio group handle to assign sounds to
        """
    @group.setter
    def group(self, arg0: GroupHandle) -> None:
        ...
    @property
    def max_duration(self) -> float:
        """
        float: Maximum duration in seconds (0 = no limit)
        """
    @max_duration.setter
    def max_duration(self, arg0: typing.SupportsFloat) -> None:
        ...
    @property
    def pitch_max(self) -> float:
        """
        float: Maximum pitch shift (1.0 = normal pitch)
        """
    @pitch_max.setter
    def pitch_max(self, arg0: typing.SupportsFloat) -> None:
        ...
    @property
    def pitch_min(self) -> float:
        """
        float: Minimum pitch shift (1.0 = normal pitch)
        """
    @pitch_min.setter
    def pitch_min(self, arg0: typing.SupportsFloat) -> None:
        ...
class SoundHandle:
    @staticmethod
    def invalid() -> SoundHandle:
        """
        Get an invalid handle.
        
        Returns:
            SoundHandle: An invalid handle (value = 0)
        """
    def __bool__(self) -> bool:
        ...
    def __eq__(self, arg0: SoundHandle) -> bool:
        ...
    def __hash__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt = 0) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, arg0: SoundHandle) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def is_valid(self) -> bool:
        """
        Check if the handle is valid.
        
        Returns:
            bool: True if the handle is valid, False otherwise
        """
    @property
    def value(self) -> int:
        ...
class TrackHandle:
    @staticmethod
    def invalid() -> TrackHandle:
        """
        Get an invalid handle.
        
        Returns:
            TrackHandle: An invalid handle (value = 0)
        """
    def __bool__(self) -> bool:
        ...
    def __eq__(self, arg0: TrackHandle) -> bool:
        ...
    def __hash__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt = 0) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, arg0: TrackHandle) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def is_valid(self) -> bool:
        """
        Check if the handle is valid.
        
        Returns:
            bool: True if the handle is valid, False otherwise
        """
    @property
    def value(self) -> int:
        ...
