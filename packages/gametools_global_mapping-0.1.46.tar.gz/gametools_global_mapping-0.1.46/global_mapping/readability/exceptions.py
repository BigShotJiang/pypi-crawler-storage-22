class NotFoundException(Exception):
    pass
