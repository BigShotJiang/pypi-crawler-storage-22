# gapi-requests-auth

## Install
pip install gapi-requests-auth

## Usage
```python
import requests
from gapi_requests_auth import AKSKAuth

s = requests.Session()
s.auth = AKSKAuth(ak="xxx", sk="yyy")

r = s.get("https://example.com/api?x=1")
print(r.status_code, r.text)
```