# Created by Ci Song @ Damo of Alibaba at 15:57 2026/2/3 using PyCharm

import hashlib
import hmac
import time
import uuid
from urllib.parse import urlsplit, parse_qs

import requests
from requests.auth import AuthBase


def _coalesce(x):
    return "" if x is None else x


def _sha256_hex_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


class AKSKAuth(AuthBase):

    def __init__(self, ak: str, sk: str, nonce_factory=None, ts_factory=None):
        self.ak = ak
        self.sk = sk
        self.nonce_factory = nonce_factory or (lambda: uuid.uuid4().hex)
        self.ts_factory = ts_factory or (lambda: str(int(time.time())))

    def __call__(self, r: requests.PreparedRequest):
        # ---- timestamp：优先用请求里已有的 x-request-ts，否则自动补上
        timestamp = r.headers.get("x-request-ts")
        if not timestamp:
            timestamp = self.ts_factory()
            r.headers["x-request-ts"] = timestamp

        # ---- nonce：每次请求生成
        nonce = self.nonce_factory()

        # 放 header
        r.headers.setdefault("x-request-ak", self.ak)
        r.headers.setdefault("x-request-nonce", nonce)

        # ---- path
        u = urlsplit(r.url)
        path = _coalesce(u.path)

        # ---- parameters：取 query 参数，按 key 排序；同 key 多值用逗号拼接
        params = parse_qs(u.query, keep_blank_values=True)

        if not params:
            parameter_string_repr = ""
        else:
            items = []
            for k in sorted(params.keys()):
                v_list = params.get(k) or [""]
                v_joined = ",".join([str(v) for v in v_list])
                items.append(f"{k}={v_joined}")
            parameter_string_repr = "&".join(items)

        # ---- bodyHash：sha256Hex(coalesce(body))
        body = r.body
        if body is None:
            body_bytes = b""
        elif isinstance(body, bytes):
            body_bytes = body
        else:
            body_bytes = str(body).encode("utf-8")

        body_hash = _sha256_hex_bytes(body_bytes)

        # ---- method
        method = (r.method or "").upper()

        # ---- repr 拼接并整体 lower
        repr_str = (
            f"{path}\n"
            f"{parameter_string_repr}\n"
            f"{body_hash}\n"
            f"{method}\n"
            f"{self.ak}\n"
            f"{nonce}\n"
            f"{timestamp}\n"
            f"{self.sk}"
        ).lower()

        # ---- HMAC-SHA256(key=sk, msg=repr) 然后对 hmacResult 再 sha256Hex
        hmac_bytes = hmac.new(self.sk.encode("utf-8"), repr_str.encode("utf-8"), hashlib.sha256).digest()
        signature = hashlib.sha256(hmac_bytes).hexdigest()

        r.headers["Authorization"] = "GAPI-SIMPLE-HMAC-SHA256 " + signature

        return r
