# Copyright 2024 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Handles query parsing."""

from __future__ import annotations

import datetime
import hashlib
import json
import logging
import re
from typing import Generator, Union

import jinja2
import pydantic
from dateutil import relativedelta
from garf.core import query_parser
from typing_extensions import Self, TypeAlias

logger = logging.getLogger(__name__)

QueryParameters: TypeAlias = dict[str, Union[str, float, int, list]]


class GarfQueryParameters(pydantic.BaseModel):
  """Parameters for dynamically changing text of a query."""

  macro: QueryParameters = pydantic.Field(default_factory=dict)
  template: QueryParameters = pydantic.Field(default_factory=dict)

  @property
  def hash(self) -> str:
    hash_fields = self.model_dump(exclude_none=True)
    return hashlib.md5(json.dumps(hash_fields).encode('utf-8')).hexdigest()


class GarfMacroError(query_parser.GarfQueryError):
  """Specifies incorrect macro in Garf query."""


class GarfResourceError(query_parser.GarfQueryError):
  """Specifies incorrect resource name in the query."""


class GarfBuiltInQueryError(query_parser.GarfQueryError):
  """Specifies non-existing builtin query."""


class BaseQueryElements(pydantic.BaseModel):
  """Contains raw query and parsed elements.

  Attributes:
    title: Title of the query that needs to be parsed.
    text: Text of the query that needs to be parsed.
    resource_name: Name of Google Ads API reporting resource.
    fields: Ads API fields that need to be fetched.
    column_names: Friendly names for fields which are used when saving data
    column_names: Friendly names for fields which are used when saving data
    customizers: Attributes of fields that need to be be extracted.
    virtual_columns: Attributes of fields that need to be be calculated.
    is_builtin_query: Whether query is built-in.
  """

  title: str | None
  text: str
  resource_name: str | None = None
  fields: list[str] = pydantic.Field(default_factory=list)
  filters: list[str] = pydantic.Field(default_factory=list)
  sorts: list[str] = pydantic.Field(default_factory=list)
  column_names: list[str] = pydantic.Field(default_factory=list)
  customizers: dict[str, query_parser.Customizer] = pydantic.Field(
    default_factory=dict
  )
  virtual_columns: dict[str, query_parser.VirtualColumn] = pydantic.Field(
    default_factory=dict
  )
  is_builtin_query: bool = False

  def __eq__(self, other: BaseQueryElements) -> bool:  # noqa: D105
    return (
      self.column_names,
      self.fields,
      self.filters,
      self.sorts,
      self.resource_name,
      self.customizers,
      self.virtual_columns,
    ) == (
      other.column_names,
      other.fields,
      other.filters,
      other.sorts,
      other.resource_name,
      other.customizers,
      other.virtual_columns,
    )

  @property
  def request(self) -> str:
    """API request."""
    return ','.join(self.fields)

  @property
  def hash(self) -> str:
    hash_fields = self.model_dump(exclude_none=True, exclude={'title', 'text'})
    return hashlib.md5(json.dumps(hash_fields).encode('utf-8')).hexdigest()


class CommonParametersMixin:
  """Helper mixin to inject set of common parameters to all queries."""

  _common_params = {
    'date_iso': lambda: datetime.date.today().strftime('%Y%m%d'),
    'yesterday_iso': lambda: (
      datetime.date.today() - relativedelta.relativedelta(days=1)
    ).strftime('%Y%m%d'),
    'current_date': lambda: datetime.date.today().strftime('%Y-%m-%d'),
    'current_datetime': lambda: datetime.datetime.today().strftime(
      '%Y-%m-%d %H:%M:%S'
    ),
  }

  @property
  def common_params(self):
    """Instantiates common parameters to the current values."""
    return {key: value() for key, value in self._common_params.items()}


class SafeDict(dict):
  def __missing__(self, key: str):
    logger.warning('Not processed macro found: %s', key)
    return '{' + key + '}'


def expand_jinja(
  query_text: str, template_params: QueryParameters | None = None
) -> str:
  file_inclusions = ('% include', '% import', '% extend')
  if any(file_inclusion in query_text for file_inclusion in file_inclusions):
    template = jinja2.Environment(loader=jinja2.FileSystemLoader('.'))
    query = template.from_string(query_text)
  else:
    query = jinja2.Template(query_text)
  if not template_params:
    return query.render()
  for key, value in template_params.items():
    if value:
      if isinstance(value, list):
        template_params[key] = value
      elif len(splitted_param := value.split(',')) > 1:
        template_params[key] = splitted_param
      else:
        template_params[key] = value
    else:
      template_params = ''
  return query.render(template_params)


class QuerySpecification(CommonParametersMixin):
  """Simplifies fetching data from API and its further parsing.

  Attributes:
    text: Query text.
    title: Query title.
    args: Optional parameters to be dynamically injected into query text.
    api_version: Version of Google Ads API.
  """

  allowed_tags: tuple[str, ...] = ('unsafe_macro',)

  def __init__(
    self,
    text: str,
    title: str | None = None,
    args: GarfQueryParameters | None = None,
    unsafe_macro: bool = False,
    **kwargs: str,
  ) -> None:
    """Instantiates QuerySpecification based on text, title and optional args.

    Args:
      text: Query text.
      title: Query title.
      args: Optional parameters to be dynamically injected into query text.
      api_version: Version of Google Ads API.
    """
    if not args:
      self.args = GarfQueryParameters()
    elif isinstance(args, GarfQueryParameters):
      self.args = args
    else:
      self.args = GarfQueryParameters(**args)
    self.query = BaseQueryElements(title=title, text=text)
    self.unsafe_macro = unsafe_macro

  @property
  def macros(self) -> QueryParameters:
    """Returns macros with injected common parameters."""
    common_params = dict(self.common_params)
    if macros := self.args.macro:
      converted_macros = {
        key: convert_date(value) for key, value in macros.items()
      }
      common_params.update(converted_macros)
    return common_params

  def generate(self) -> BaseQueryElements:
    self.remove_comments().expand().extract_resource_name()
    (
      self.remove_trailing_comma()
      .extract_fields()
      .extract_filters()
      .extract_sorts()
      .extract_column_names()
      .extract_virtual_columns()
      .extract_customizers()
    )
    if self.query.resource_name and self.query.resource_name.startswith(
      'builtin'
    ):
      self.query.title = self.query.resource_name.replace('builtin.', '')
      self.query.is_builtin_query = True
    return self.query

  def expand(self) -> Self:
    """Applies necessary transformations to query."""
    query_text = expand_jinja(self.query.text, self.args.template)
    try:
      if self.unsafe_macro:
        self.query.text = query_text.format_map(SafeDict(**self.macros)).strip()
      else:
        self.query.text = query_text.format(**self.macros).strip()
    except KeyError as e:
      raise GarfMacroError(f'No value provided for macro {str(e)}.') from e
    return self

  def remove_comments(self) -> Self:
    """Removes comments and converts text to lines."""
    result: list[str] = []
    multiline_comment = False
    for raw_line in self.query.text.split('\n'):
      line = raw_line.strip()
      if re.match('\\*/', line):
        multiline_comment = False
        continue
      if re.match('/\\*', line) or multiline_comment:
        multiline_comment = True
        continue
      if re.match('^(#|--|//)garf:', line):
        _, tag = line.split(':', maxsplit=1)
        tag = tag.replace('-', '_')
        action, tag_name = tag.split('_', maxsplit=1)
        if tag_name in self.allowed_tags:
          if action == 'allow':
            setattr(self, tag_name, True)
          elif action == 'disable':
            setattr(self, tag_name, False)

        continue
      if re.match('^(#|--|//) ', line) or line in ('--', '#', '//'):
        continue
      cleaned_query_line = re.sub(
        ';$', '', re.sub('(--|//) .*$', '', line).strip()
      )
      result.append(cleaned_query_line)
    self.query.text = ' '.join(result)
    return self

  def remove_trailing_comma(self) -> Self:
    self.text = re.sub(
      r',\s+from', ' FROM', self.query.text, count=0, flags=re.IGNORECASE
    )
    return self

  def extract_resource_name(self) -> Self:
    """Finds resource_name in query_text.

    Returns:
      Found resource.
    """
    if resource_name := re.findall(
      r'FROM\s+([\w.]+)', self.query.text, flags=re.IGNORECASE
    ):
      self.query.resource_name = str(resource_name[0]).strip()
    else:
      self.query.resource_name = None
    return self

  def extract_fields(self) -> Self:
    for line in self._extract_query_lines():
      line_elements = query_parser.ExtractedLineElements.from_query_line(line)
      if field := line_elements.field:
        self.query.fields.append(field)
    return self

  def extract_filters(self) -> Self:
    if filters := re.findall(
      r'WHERE\s+(.+)(ORDER BY|LIMIT|PARAMETERS)?',
      self.query.text,
      flags=re.IGNORECASE,
    ):
      in_pattern = r'\((.*?)\)'

      def create_replacer():
        count = 0

        def replacer(match):
          nonlocal count
          count += 1
          return f'({{group_{count}}})'

        return replacer

      joined_filters = ' '.join(filters[0])
      in_groups = re.findall(in_pattern, joined_filters)
      group_replacements = {
        f'group_{i}': group for i, group in enumerate(in_groups, 1)
      }

      final_filters = re.sub(in_pattern, create_replacer(), joined_filters)
      if self.unsafe_macro:
        found_filters = [
          f.strip().format_map(SafeDict(**group_replacements))
          for f in re.split(' AND ', final_filters, flags=re.IGNORECASE)
        ]
      else:
        found_filters = [
          f.strip().format(**group_replacements)
          for f in re.split(' AND ', final_filters, flags=re.IGNORECASE)
        ]
      self.query.filters = found_filters
    return self

  def extract_sorts(self) -> Self:
    if sorts := re.findall(
      r'ORDER BY\s+(.+)(LIMIT|PARAMETERS)?',
      self.query.text,
      flags=re.IGNORECASE,
    ):
      self.query.sorts = re.split('AND', sorts[0][0], flags=re.IGNORECASE)
    return self

  def extract_column_names(self) -> Self:
    for line in self._extract_query_lines():
      line_elements = query_parser.ExtractedLineElements.from_query_line(line)
      self.query.column_names.append(line_elements.alias)
      if set(self.query.column_names) == {
        '_',
      } and len(self.query.fields) == len(self.query.column_names):
        raise query_parser.GarfQueryError(
          'At least one column should be included into a query.'
        )
    return self

  def extract_virtual_columns(self) -> Self:
    for line in self._extract_query_lines():
      line_elements = query_parser.ExtractedLineElements.from_query_line(line)
      if virtual_column := line_elements.virtual_column:
        self.query.virtual_columns[line_elements.alias] = virtual_column
        if fields := virtual_column.fields:
          for field in fields:
            if field not in self.query.fields:
              self.query.fields.append(field)
    return self

  def extract_customizers(self) -> Self:
    for line in self._extract_query_lines():
      line_elements = query_parser.ExtractedLineElements.from_query_line(line)
      if customizer := line_elements.customizer:
        self.query.customizers[line_elements.alias] = customizer
    return self

  def _extract_query_lines(self) -> Generator[str, None, None]:
    """Helper for extracting fields with aliases from query text.

    Yields:
      Line in query between SELECT and FROM statements.
    """
    selected_rows = re.sub(
      r'\bSELECT\b|FROM .*', '', self.text, flags=re.IGNORECASE
    ).split(',')
    for row in selected_rows:
      if row.strip() == '*':
        return
      if non_empty_row := row.strip():
        yield non_empty_row


def convert_date(date_string: str) -> str:
  """Converts specific dates parameters to actual dates.

  Returns:
    Date string in YYYY-MM-DD format.

  Raises:
    GarfMacroError:
     If dynamic lookback value (:YYYYMMDD-N) is incorrect.
  """
  if isinstance(date_string, list) or str(date_string).find(':Y') == -1:
    return date_string
  current_date = datetime.date.today()
  base_date, *date_customizer = re.split('\\+|-', date_string)
  if len(date_customizer) > 1:
    raise GarfMacroError(
      'Invalid format for date macro, should be in :YYYYMMDD-N format'
    )
  if not date_customizer:
    days_lookback = 0
  else:
    try:
      days_lookback = int(date_customizer[0])
    except ValueError as e:
      raise GarfMacroError(
        'Must provide numeric value for a number lookback period, '
        'i.e. :YYYYMMDD-1'
      ) from e
  if base_date == ':YYYY':
    new_date = datetime.datetime(current_date.year, 1, 1)
    delta = relativedelta.relativedelta(years=days_lookback)
  elif base_date == ':YYYYMM':
    new_date = datetime.datetime(current_date.year, current_date.month, 1)
    delta = relativedelta.relativedelta(months=days_lookback)
  elif base_date == ':YYYYMMDD':
    new_date = current_date
    delta = relativedelta.relativedelta(days=days_lookback)
  else:
    raise GarfMacroError(
      'Invalid format for date macro, should be in :YYYYMMDD-N format'
    )

  if '-' in date_string:
    return (new_date - delta).strftime('%Y-%m-%d')
  return (new_date + delta).strftime('%Y-%m-%d')
