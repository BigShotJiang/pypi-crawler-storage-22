def load_config() -> dict:
    return {}
