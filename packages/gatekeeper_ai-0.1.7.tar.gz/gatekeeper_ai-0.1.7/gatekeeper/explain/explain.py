def explain(reason: str) -> str:
    return f"Gatekeeper blocked: {reason}"
