def format_failure(message: str) -> str:
    return f"❌ {message}"
