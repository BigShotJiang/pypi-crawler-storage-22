"""Example."""
def example(n: int) -> int:
    return 2 * n if n > 0 else 0
print(example(5))
