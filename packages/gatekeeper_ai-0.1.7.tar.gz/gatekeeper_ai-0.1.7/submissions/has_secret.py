# File with hardcoded credential
API_KEY = "sk-1234567890abcdefghijk"
TOKEN = "ghp_XxXxXxXxXxXxXxXxXxXx"

def get_token():
    return TOKEN
