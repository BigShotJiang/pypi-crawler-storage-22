def broken_function(
    x this is a syntax error
    return x
