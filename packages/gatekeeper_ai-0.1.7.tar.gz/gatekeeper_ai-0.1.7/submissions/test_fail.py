def fail(): 1/0 # Triggers auto-judge
