def process(x):
    return undefined_var + x  # NameError

process(5)
