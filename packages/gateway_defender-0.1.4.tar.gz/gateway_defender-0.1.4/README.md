# gateway-defender

gateway-defender is a small, reusable Django app that provides authentication helpers (login/logout views), a protected portal view, session timeout handling, and packaged templates/static assets. The PyPI distribution name is `gateway-defender`; the importable Python package is `gateway_defender`.

---

## Install

Install from PyPI with pip:

```bash
pip install gateway-defender
```

---

## Quick start

1. Add to `INSTALLED_APPS` in your Django settings:

```py
INSTALLED_APPS = [
    # ...
    "django.contrib.sites",
    "gateway_defender",
]
```

2. Add the middleware (required for multi-site support):

```py
MIDDLEWARE = [
    # ...
    "django.contrib.sites.middleware.CurrentSiteMiddleware",
]
```

3. Include the URLs in your project `urls.py`:

```py
from django.urls import include, path

urlpatterns = [
    path("", include("gateway_defender.urls")),
]
```

4. Configure the portal template to render after successful login:<br/>
Add this inside your settings.py

```py
# Defaults to "gateway_defender/portal.html"
GATEWAY_PORTAL_TEMPLATE = "your_app/portal.html"
```

Ensure the template exists within one of the template directories defined in `TEMPLATES` in your settings.

5. Run migrations:

```bash
python manage.py migrate
```

6. Routes provided by the app:
- `GET /` — login page (uses `gateway_defender/gateway.html`)
- `GET /portal/` — protected portal page
- `GET /logout/` — logout and redirect to `index`

---

## Multi-site configuration (v0.1.4+)

The app uses Django's Sites framework so you can configure different authentication settings per domain while sharing a single database.

1. Create a Site in the admin panel for each domain you want to support (e.g., `localhost:8000` in development, or your production domain).
2. In the admin panel, when creating an `AuthToggle`, assign it to the appropriate Site.

**Important:** You must have at least one Site configured. Either create the Site record(s) in the admin panel. Without a valid Site, Django's Sites framework can raise a `Site.DoesNotExist` error when resolving the current site.

If no matching Site is found for the current request, the first `AuthToggle` entry is used as a fallback.

---


## API / Files included

Key modules included in the package:

- `gateway_defender.models` — `AuthToggle`, `PassPhrase`
- `gateway_defender.views` — `Gateway` (login view) and `EndSession` (logout view)
- `gateway_defender.urls` — URL patterns included above
- `gateway_defender.custom_decorator` — `protected_redirect` decorator
- `gateway_defender/templates/` — packaged templates (gateway_defender/gateway.html, gateway_defender/logged_out.html)
- `gateway_defender/static/` — CSS and images

Refer to module docstrings and the source for details.

---

## Compatibility

- Python: 3.10 — 3.13
- Django: >= 4.2 (tested with Django 5.2)

---

## Development

Run tests and linters in your development environment. For local development:

```bash
pip install -r requirements-dev.txt  # if you create one
pytest
```

When preparing a release:

1. Update `pyproject.toml` version and metadata.
2. Build with `python -m build`.
3. Upload with `twine upload dist/*`.

---

## Contributing

Contributions are welcome. Please open issues or PRs and include tests for new behavior. Keep public APIs stable where possible.

---

## License

MIT — see the `LICENSE` file included in the repository.

---

## Project & PyPI

PyPI package name: `gateway-defender`  
Python package (import): `gateway_defender`  

Update the repository or PyPI URLs here if you host the project on GitHub or another platform.

