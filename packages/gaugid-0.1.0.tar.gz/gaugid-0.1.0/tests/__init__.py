"""Tests for Gaugid SDK."""
