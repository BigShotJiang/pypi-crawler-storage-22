"""Public package API for gaze tracker."""

from .ui.app import main as _ui_main

__version__ = "0.1.1"


def run_app() -> None:
    """Run the gaze tracker GUI application."""
    _ui_main()


def main() -> None:
    """Backward-compatible entrypoint alias."""
    run_app()


__all__ = ["run_app", "main", "__version__"]
