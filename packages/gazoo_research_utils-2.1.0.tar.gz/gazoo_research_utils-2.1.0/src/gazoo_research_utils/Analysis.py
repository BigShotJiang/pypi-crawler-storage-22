import json
from asyncio.unix_events import SelectorEventLoop
from datetime import datetime, timedelta
from pathlib import Path
from tkinter import constants
from typing import Any, Callable, List, Optional, Sequence
from uuid import uuid4

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from lifelines import KaplanMeierFitter, plotting
from pydantic import BaseModel, field_validator

from .constants import DOB_TAG_STRUCTURE, GAZOO_RESEARCH_COLUMNS
from .models.filter_model import Filter


def load_data(file_path: str | Path) -> pd.DataFrame:
    """
    Load the Gazoo Reserch data from csv to validated pd.DataFrame.
    """
    df = pd.read_csv(file_path, dtype=str)
    # Validate columns
    if sorted(df.columns) != sorted(GAZOO_RESEARCH_COLUMNS):
        raise ValueError(
            f"Invalid columns. Expected {GAZOO_RESEARCH_COLUMNS}, got {list(df.columns)}"
        )

    # Convert phi to boolean (1 -> True, 0 -> False)
    df["phi"] = df["phi"].astype(int).astype(bool)

    # Set value as object initially
    df["value"] = df["value"].astype(object)

    # Now convert value column based on data_type
    def _convert_value(row):
        data_type = row["data_type"]
        value = row["value"]

        if pd.isna(value):
            return value

        if data_type == "number":
            try:
                return float(value)
            except (ValueError, TypeError):
                return np.nan
        elif data_type == "date":
            try:
                return datetime.strptime(value, "%Y-%m-%d")
            except (ValueError, TypeError):
                return pd.NaT
        else:  # categorical, text
            return str(value) if value is not None else value

    # Apply conversion
    df["value"] = df.apply(_convert_value, axis=1)

    return df


def validate_gazoo_research_df(df: pd.DataFrame) -> None:
    """
    Validates that a pandas DataFrame has the correct structure for Gazoo Research data.

    Checks:
    - Required columns are present with correct names
    - 'phi' column is boolean
    - 'value' column is object type (for mixed types)
    - 'id', 'collection', 'tag', 'tag_id', 'field', 'data_type' columns are string type
    - 'data_type' column contains only valid values

    Note: Empty DataFrames are allowed if they have the correct column structure.

    Raises:
        ValueError: If any validation check fails
    """
    # Check required columns are present (even for empty DataFrames)
    missing_columns = set(GAZOO_RESEARCH_COLUMNS) - set(df.columns)
    if missing_columns:
        raise ValueError(
            f"Missing required columns: {missing_columns}. "
            f"Expected: {GAZOO_RESEARCH_COLUMNS}, Got: {list(df.columns)}"
        )

    extra_columns = set(df.columns) - set(GAZOO_RESEARCH_COLUMNS)
    if extra_columns:
        raise ValueError(
            f"Unexpected columns found: {extra_columns}. "
            f"Expected: {GAZOO_RESEARCH_COLUMNS}"
        )

    # Only validate column dtypes if DataFrame is not empty
    # Empty DataFrames with correct columns are valid
    if df.empty:
        return

    # Validate column dtypes
    # String columns - must be string dtype
    string_cols = ["id", "collection", "tag", "tag_id", "field", "data_type"]
    for col in string_cols:
        if not pd.api.types.is_string_dtype(df[col]):
            raise ValueError(f"Column '{col}' must be string type, got {df[col].dtype}")

    # 'phi' must be boolean
    if not pd.api.types.is_bool_dtype(df["phi"]):
        raise ValueError(f"Column 'phi' must be boolean type, got {df['phi'].dtype}")

    # 'value' must be object type (for mixed types: float, str, datetime)
    if not pd.api.types.is_object_dtype(df["value"]):
        raise ValueError(
            f"Column 'value' must be object type (for mixed types), got {df['value'].dtype}"
        )

    # Validate 'data_type' column contains only valid values
    valid_data_types = {"number", "categorical", "text", "date"}
    actual_data_types = set(df["data_type"].dropna())
    invalid_data_types = actual_data_types - valid_data_types
    if invalid_data_types:
        raise ValueError(
            f"Invalid data_type values found: {invalid_data_types}. "
            f"Valid values are: {valid_data_types}"
        )


def convert_to_filters(
    input_data: Sequence[dict[str, str]],
) -> Sequence[Filter]:
    """
    Converts a list of dictionary to Filter a objects.

    This function takes a list of dicts and converts them into
    the corresponding Pydantic Filter instances. The conversion validates the input
    against the Filter model's schema.

    Parameters:
        input_data (list[dict]): A list of dictionaries to convert. Each dictionary
            must conform to the Filter model's structure.

    Returns:
        list[Filter]: A Filter instance of a list of
            Filter instances if input is a list of dicts.

    Raises:
        TypeError: If input_data is neither a dict nor a list of dicts.
    """
    if isinstance(input_data, Sequence):
        return [Filter(**item) for item in input_data]
    else:
        raise TypeError("Input must be a list of dicts")


def convert_to_filter(
    input_data: dict[str, str],
) -> Filter:
    """
    Converts a dictionary to a Filter object0.

    This function takes a dict and converts it into
    the corresponding Pydantic Filter instances. The conversion validates the input
    against the Filter model's schema.

    Parameters:
        input_data (dict): A dictionary. Each dictionary
            must conform to the Filter model's structure.

    Returns:
        Filter: A Filter instance

    Raises:
        TypeError: If input_data is not a dict.
    """
    if isinstance(input_data, dict):
        return Filter(**input_data)
    else:
        raise TypeError("Input must be a dict")


# Applies Functions to patients
def patient_iterator(
    df: pd.DataFrame, patient_fn: Callable[[pd.DataFrame], pd.DataFrame]
) -> pd.DataFrame:
    """Applies functions to individual tags
    Parameters:
    df: pd.DataFrame -> Entire GazooResearch Database
    tag_fn: -> Function which intakes a tag in pd.DataFrame format and returns a pd.DataFrame format
    """
    assert isinstance(df, pd.DataFrame), f"df should be a pd.DataFrame, not {type(df)}"

    data = []
    # Loop through Patients
    for patient_id in df.id.unique():
        df_patient: pd.DataFrame = df.loc[df["id"] == patient_id].copy()
        # Apply Function
        rows: pd.DataFrame = patient_fn(df_patient)
        # Convert to dictionary
        rows = rows.to_dict("records")
        # Append data
        data.extend(rows)

    return pd.DataFrame.from_records(data)


# Applies Functions to tags
def tag_iterator(
    df: pd.DataFrame, tag_fn: Callable[[pd.DataFrame], pd.DataFrame]
) -> pd.DataFrame:
    """Applies functions to individual tags
    Parameters:
    df: pd.DataFrame -> Entire GazooResearch Database
    tag_fn: -> Function which intakes a tag in pd.DataFrame format and returns a pd.DataFrame format
    """
    assert isinstance(df, pd.DataFrame), f"df should be a pd.DataFrame, not {type(df)}"

    data = []
    # Loop through Patients
    for patient_id in df.id.unique():
        df_patient = df.loc[df["id"] == patient_id]
        # Loop through all tags
        for tag_id in df_patient.tag_id.unique():
            # Get Tag Data
            df_tag = df.loc[df["tag_id"] == tag_id].copy()
            # Skip if dataframe is empty
            if df_tag.empty:
                continue
            # Apply Function
            rows: pd.DataFrame = tag_fn(df_tag)
            # Convert to dictionary
            rows = rows.to_dict("records")
            # Append data
            data.extend(rows)

    return pd.DataFrame.from_records(data)


# Erases tags before anchors
def start_at_anchor(df: pd.DataFrame, anchors: pd.DataFrame) -> pd.DataFrame:
    """Function that removes all tags that have dates before the anchor
    Parameters:
        df: pd.DataFrame -> GazooResearch Database
        anchors: pd.DataFrame -> Anchors in pd.DataFrame format
    Return
        df:pd.DataFrame -> Removes all tags which occured before anchor
    """

    def start_at_anchor_iterator_fn(tag: pd.DataFrame):
        # Get id
        id = tag.loc[tag.first_valid_index()]["id"]

        # Get Anchor
        anchor = anchors[anchors["id"] == id]
        # Check if Anchor Exists for person
        if anchor.empty:
            return pd.DataFrame()
        # Get Anchor as Series
        anchor = anchor.loc[anchor.first_valid_index()]

        # Loop through fields
        for index, field in tag.iterrows():
            # Find start-date or date
            if field["data_type"] == "date" and (
                field["field"] == "start-date" or field["field"] == "date"
            ):
                # Comparea Anchor & Field
                try:
                    if datetime.strptime(field["value"], "%Y-%m-%d") < anchor["value"]:
                        return pd.DataFrame()
                except ValueError:
                    continue

        return tag

    return tag_iterator(df, start_at_anchor_iterator_fn)


# Calculates age
def calculate_age(df: pd.DataFrame, anchors: pd.DataFrame) -> pd.DataFrame:
    """Calculates age at the time of the anchor event for each patient.

    This function computes the age in years (with decimal precision accounting for
    leap years) for each patient based on their date of birth (DOB) and the anchor
    date. For each patient, it creates two new rows under a new 'age' tag:

    1. An 'anchor-name' field row containing the anchor tag name
    2. An 'anchor-date' field row containing the anchor date
    3. An 'age' field row containing the calculated age in years

    The age tag uses collection '0' and a generated UUID4 as tag_id.

    If a patient does not have a DOB or the anchor date is before the DOB, the
    function skips that patient and returns an empty DataFrame for them.

    Parameters:
        df: pd.DataFrame -> GazooResearch CSV data with columns:
            id, collection, tag, tag_id, field, data_type, value, phi
        anchors: pd.DataFrame -> Anchors for each patient, with at least 'id',
            'tag', and 'value' columns where 'value' contains datetime objects

    Returns:
        pd.DataFrame: Original data with age-related rows appended for patients
            who have both DOB and valid anchor dates
    """

    def calculate_age_iterator(patient: pd.DataFrame) -> pd.DataFrame:
        """Iterator function that calculates age for a single patient given anchors."""

        # Check if anchors DataFrame is valid and has required columns
        if anchors.empty or "id" not in anchors.columns:
            return pd.DataFrame()

        def _calculate_age(dob: datetime, anchor_date: datetime) -> float:
            """Calculate age in years accounting for leap years.

            Parameters:
                dob: Date of birth as datetime
                anchor_date: The reference date (anchor event) as datetime

            Returns:
                Age in years as a decimal (e.g., 65.5 for 65 years and 6 months)
            """
            age_in_days = (anchor_date - dob).days
            age_in_years_decimal = age_in_days / 365.25  # Accounts for leap years
            return round(age_in_years_decimal, 4)  # Round to 4 decimal places

        # Get patient ID
        patient_id = patient.loc[patient.first_valid_index()]["id"]

        # Get anchor for this patient
        anchor = anchors[anchors["id"] == patient_id]

        # Skip patient if no anchor found
        if anchor.empty:
            return pd.DataFrame()

        # Get anchor data
        anchor_row = anchor.loc[anchor.first_valid_index()]
        anchor_date = anchor_row["value"]
        anchor_tag = anchor_row.get("tag", "unknown")

        # Validate anchor_date is a datetime
        if pd.isna(anchor_date) or not isinstance(anchor_date, datetime):
            return pd.DataFrame()

        # Get DOB for this patient
        dob_tag = get_field_value_where_filter(patient, DOB_TAG_STRUCTURE)
        if dob_tag.empty or dob_tag.first_valid_index() is None:
            # Patient has no DOB, skip them
            return pd.DataFrame()

        dob_row = dob_tag.loc[dob_tag.first_valid_index()]
        dob_value = dob_row["value"]

        # Parse DOB - handle both datetime and string formats
        if isinstance(dob_value, datetime):
            date_of_birth = dob_value
        elif isinstance(dob_value, str):
            try:
                date_of_birth = datetime.strptime(dob_value, "%Y-%m-%d")
            except ValueError:
                # Invalid date format, skip patient
                return pd.DataFrame()
        else:
            # Unsupported DOB format, skip patient
            return pd.DataFrame()

        # Validate that anchor date is after DOB
        if anchor_date < date_of_birth:
            # Anchor date is before birth, invalid data
            return pd.DataFrame()

        # Calculate Age
        age = _calculate_age(date_of_birth, anchor_date)

        # Check if age tag already exists for this patient
        existing_age_mask = (patient["tag"] == "age") & (patient["id"] == patient_id)
        if existing_age_mask.any():
            # Check if anchor name and date match existing values
            existing_age_rows = patient[existing_age_mask]
            existing_anchor_name = existing_age_rows[
                existing_age_rows["field"] == "anchor-name"
            ]["value"].iloc[0]
            existing_anchor_date = existing_age_rows[
                existing_age_rows["field"] == "anchor-date"
            ]["value"].iloc[0]

            # Reuse existing tag_id if anchor info is the same
            if str(existing_anchor_name) == str(anchor_tag) and pd.Timestamp(
                existing_anchor_date
            ) == pd.Timestamp(anchor_date):
                # Anchor info unchanged, return patient without updates
                return patient
            else:
                # Anchor info changed, reuse existing tag_id
                age_tag_id = existing_age_rows.iloc[0]["tag_id"]
        else:
            # Generate new tag_id for age tag
            age_tag_id = f"#{uuid4()}"

        # Create age tag rows to append
        age_rows = []

        # Row 1: anchor-name field
        age_rows.append(
            {
                "id": patient_id,
                "collection": "0",
                "tag": "age",
                "tag_id": age_tag_id,
                "field": "anchor-name",
                "data_type": "text",
                "value": anchor_tag,
                "phi": False,
            }
        )

        # Row 2: date field (required for describe_fields to find the anchor date)
        age_rows.append(
            {
                "id": patient_id,
                "collection": "0",
                "tag": "age",
                "tag_id": age_tag_id,
                "field": "date",
                "data_type": "date",
                "value": anchor_date,
                "phi": False,
            }
        )

        # Row 3: anchor-date field
        age_rows.append(
            {
                "id": patient_id,
                "collection": "0",
                "tag": "age",
                "tag_id": age_tag_id,
                "field": "anchor-date",
                "data_type": "date",
                "value": anchor_date,
                "phi": False,
            }
        )

        # Row 4: value field
        age_rows.append(
            {
                "id": patient_id,
                "collection": "0",
                "tag": "age",
                "tag_id": age_tag_id,
                "field": "value",
                "data_type": "number",
                "value": age,
                "phi": False,
            }
        )

        # Remove existing age rows for this patient before appending new ones
        if existing_age_mask.any():
            patient = patient[~existing_age_mask]

        # Append age rows to patient data
        patient_with_age = pd.concat(
            [patient, pd.DataFrame(age_rows)], ignore_index=True
        )

        return patient_with_age

    return patient_iterator(df, calculate_age_iterator)


def pivot(df: pd.DataFrame) -> pd.DataFrame:
    """
    Pivots the Gazoo Research DataFrame for easy analysis.

    Converts long-format data (multiple rows per tag) to wide-format
    (one row per tag) where each column represents a unique
    collection:tag:field combination.

    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame with columns: id, collection, tag, tag_id,
        field, data_type, value, phi

    Returns
    -------
    pd.DataFrame
        Pivoted DataFrame with:
        - Index: patient id
        - Columns: 'collection:tag:field' combinations
        - Values: the corresponding measurement values

    Examples
    --------
    >>> df = load_data("data.csv")
    >>> pivoted = pivot(df)
    >>> # Access PSA values for all patients
    >>> psa_values = pivoted["c61:psa:value"]
    """
    # Validate gazoo research df
    validate_gazoo_research_df(df)

    # Create column name from collection:tag:field
    col_name = (
        df["collection"].astype(str)
        + ":"
        + df["tag"].astype(str)
        + ":"
        + df["field"].astype(str)
    )

    # Create intermediate DataFrame with pivot keys
    pivot_df = pd.DataFrame(
        {"mrn": df["id"], "id": df["tag_id"], "name": col_name, "value": df["value"]}
    )

    # Pivot to wide format
    pivoted = pivot_df.pivot_table(
        values="value", index=["mrn", "id"], columns="name", aggfunc="first"
    )

    # Remove the tag_id level from the index
    return pivoted.droplevel(1)


def multilesion_transforation(data):
    """
    Transforms from patient level analysis to multi-target level analysis

    Parameters:
    data (DataFrame): dataframe from csv data

    Returns:
    df (DataFrame): dataframe from csv data
    """
    # Transformed Dataframe
    df = pd.DataFrame()

    # Unique Targets
    targets = data.loc[data["field"] == "target-id"]
    targets = targets[["id", "value"]]
    targets.columns = ["id", "target-id"]
    targets = targets.drop_duplicates().reset_index()

    # Loop Through Targets
    for index, row in targets.iterrows():
        id = row["id"]
        target_id = row["target-id"]
        # Select Patients Tags
        pt = data.loc[data["id"] == id]
        # Remove Tags for other targets
        other_target_ids_tag_ids = (
            pt.loc[(pt["field"] == "target-id") & (pt["value"] != target_id)]["tag_id"]
            .unique()
            .tolist()
        )
        # Filter out Non Target-ids
        pt = pt[~pt["tag_id"].isin(other_target_ids_tag_ids)]
        # Rename id
        pt["id"] = pt["id"].astype(str) + "-" + str(target_id)

        # Concat
        df = pd.concat([df, pt])
    return df


def get_data_dictionary(data) -> pd.DataFrame:
    """
    Returns data dictionary.

    Parameters:
    data (DataFrame): dataframe with csv data

    Returns:
    dictionary (DataFrame): dataframe with options

    """

    data = data[["collection", "tag", "field", "data_type"]]
    # Remove Duplicates
    dictionary = data.drop_duplicates()
    # Sort
    dictionary = dictionary.sort_values(
        ["collection", "tag", "field"], ascending=[True, True, True]
    )

    return dictionary


def get_parameters(data):
    """
    Returns data parameters.

    Parameters:
    data (DataFrame): dataframe from csv data

    Returns:
    prameters (dict): dictionary with options
    """

    parameters = (
        data.groupby(["collection", "tag", "field", "data_type"])["value"]
        .unique()
        .reset_index()
    )

    # Rename column
    parameters.rename(columns={"value": "options"}, inplace=True)

    # Remove Empty Values
    parameters["options"] = parameters.apply(
        lambda row: [item for item in row["options"] if item != ""],
        axis=1,
    )

    # Rename number_field
    parameters["options"] = parameters.apply(
        lambda row: (
            [
                min(float(x) for x in row["options"]),
                max(float(x) for x in row["options"]),
            ]
            if row["data_type"] == "number"
            else row["options"]
        ),
        axis=1,
    )
    # # Rename date
    # parameters["options"] = parameters.apply(
    #     lambda row: [min(row["options"]), max(row["options"])]
    #     if row["data_type"] == "date"
    #     else row["options"],
    #     axis=1,
    # )

    # Sort
    parameters = parameters.sort_values(
        ["collection", "tag", "field"], ascending=[True, True, True]
    )

    # Add value column
    parameters["value"] = pd.NA  # 👈 Preferred for pandas nullable types

    return json.loads(parameters.to_json(orient="records"))


def pt_dates_and_events(df, start, event_tags):
    """
    Determines starting date, date of event occurence or data censoring, and whether
    event occured or data was censored

    Parameters:
    df (DataFrame): dataframe for patient
    start (datetime.datetime): datetime
    event_tags (list of dicts): list of possible filters. Structure of filter {'collection':str, 'tag': str, 'field': str, 'exact': [str, str,...], 'between': [float, float]}

    Returns:
    start (datetime.datetime): date of starting event; None if no starting event
    end (datetime.datetime): date of event occurence or latest known date; None if no
        starting event
    event (int): 1 if event occurred, 0 if data censored; None if no starting event
    """
    validate_gazoo_research_df(df)

    # Convert String to Date
    def convert_date(date_value):
        """Convert date value to datetime object."""
        if pd.isna(date_value):
            return None
        if isinstance(date_value, datetime):
            return date_value
        try:
            return datetime.strptime(str(date_value), "%Y-%m-%d")
        except (ValueError, TypeError):
            return None

    # Get Event Dates
    event_dates = []
    for event_tag in event_tags:
        test = get_tags_where_filter(df, event_tag)
        events = test.loc[
            ((test["field"] == "date") | (test["field"] == "start-date"))
        ]["value"].to_numpy()
        events = [convert_date(d) for d in events]
        # Append Dates
        event_dates.extend([d for d in events if d is not None])

    # Remove None values and convert to array
    event_dates = [d for d in event_dates if d is not None]
    event_dates = np.array(event_dates) if event_dates else np.array([])

    # Only Keep Event Dates after Start Date
    if len(event_dates) >= 1:
        # Filter events that are after the start date
        event_dates = event_dates[event_dates > start]

    # Return Event or Censor
    if len(event_dates) >= 1:
        # Events - use the last (most recent) event date
        last = event_dates[-1]
        event = 1
        return start, last, event
    else:
        # Return Censor - find the latest date in the dataframe
        censor_dates = df.loc[(df["field"] == "date")]["value"].to_numpy()
        censor_dates = [convert_date(d) for d in censor_dates]
        censor_dates = [d for d in censor_dates if d is not None]

        if censor_dates:
            # Sort and get the latest censor date
            censor_dates = np.array(sorted(censor_dates))
            last = censor_dates[-1]
            event = 0
            return start, last, event
        else:
            # No dates available - return None for all
            return None, None, None


def get_field_value_where_filter(df, filter):
    """
    Get value where filter criteria exists

    Parameters:
    data (DataFrame): dataframe
    filter (dicts): Structure of filter {'collection':str, 'tag': str, 'field': str, 'exact': [str, str,...], 'between': [float, float]}

    Returns:
    data (DataFrame): dataframe with tags where filter criteria exist

    """

    if "collection" in filter and "tag" in filter and "field" in filter:
        test = df.loc[
            (df["collection"].astype(str) == filter["collection"])
            & (df["tag"].astype(str) == filter["tag"])
            & (df["field"].astype(str) == filter["field"])
        ]
    elif "tag" in filter and "field" in filter:
        test = df.loc[
            (df["tag"].astype(str) == filter["tag"])
            & (df["field"].astype(str) == filter["field"])
        ]
    else:
        assert False, f"Filter must have tag, and field"

    return test


def get_tags_where_filter(
    df: pd.DataFrame, filter: Filter | dict[str, str]
) -> pd.DataFrame:
    """
    Get tags where filter criteria exists

    Parameters:
        df (DataFrame):  dataframe
        filter (Filter): Filter object with criteria

    Returns:
        data (DataFrame): dataframe with tags where filter criteria exist

    """
    assert isinstance(df, pd.DataFrame), f"pt should be a pd.DataFrame, not {type(df)}"
    # Validate gazoo research df
    validate_gazoo_research_df(df)
    assert isinstance(filter, Filter | dict), (
        f"filter should be a Filter or dict, not a {type(filter)}"
    )

    if isinstance(filter, dict):
        # Convert filter: dict -> Filter
        filter = convert_to_filter(filter)

    # Build base conditions
    conditions = []

    if filter.collection is not None:
        conditions.append(df["collection"].astype(str) == filter.collection)
    if filter.tag is not None:
        conditions.append(df["tag"].astype(str) == filter.tag)
    if filter.field is not None:
        conditions.append(df["field"].astype(str) == filter.field)

    # Apply base conditions
    if conditions:
        base_mask = pd.concat(conditions, axis=1).all(axis=1)
        filtered_data = df[base_mask]
    else:
        filtered_data = df

    # Apply value-based filters
    if filter.exact is not None:
        exact_mask = filtered_data["value"].isin(filter.exact)
        result = filtered_data[exact_mask]
    elif filter.between is not None:
        numeric_values = pd.to_numeric(filtered_data["value"], errors="coerce")
        between_mask = numeric_values.between(filter.between[0], filter.between[1])
        result = filtered_data[between_mask]
    else:
        result = filtered_data

    return result


def filter(
    data: pd.DataFrame,
    filters: Sequence[Filter] | Sequence[dict[str, str]],
    label: str = "",
) -> pd.DataFrame:
    """
    Filter patients based on multiple criteria.

    Parameters:
    data (DataFrame): GazooResearch DataFrame
    filters (list[dict[str,str]] | list[Filter]): list of dict or list of Filters.
    label (str): label to assign to filtered patients

    Returns:
    DataFrame: filtered data with 'label' column added
    """
    # Validate gazoo research df
    validate_gazoo_research_df(data)

    # Convert filters to pydantic
    if isinstance(filters, Sequence) and all(
        isinstance(item, dict) for item in filters
    ):
        filters = convert_to_filters(filters)

    # Start with all patient IDs
    all_patients = set(data["id"].unique())
    current_patients = all_patients

    for f in filters:
        # Use helper function to filter rows for this single filter
        filtered_rows = get_tags_where_filter(data, f)

        # Extract patient IDs from filtered rows
        filter_patients = set(filtered_rows["id"].unique())
        current_patients &= filter_patients  # Intersect with previous results

    # Filter data to only patients meeting all criteria
    filtered_data: pd.DataFrame = data[data["id"].isin(current_patients)]

    if label:
        filtered_data["label"] = label

    return filtered_data


def kaplan_meier(
    data: pd.DataFrame,
    df_anchors: pd.DataFrame,
    event_tags: Sequence[dict[str, Any] | Filter],
    time_unit: str = "months",
) -> pd.DataFrame:
    """
    Calculate Kaplan-Meier survival analysis dataframe.

    This function computes time-to-event data for Kaplan-Meier analysis, handling
    both event occurrences and censored data. It calculates the time from an anchor
    date (e.g., surgery) to either an event (e.g., progression, death) or censoring.

    Parameters:
    -----------
    data : pd.DataFrame
        Gazoo Research DataFrame with columns: id, collection, tag, tag_id,
        field, data_type, value, phi. Must contain anchor dates and event data.
    df_anchors : pd.DataFrame
        DataFrame containing anchor dates for each patient. Must have columns
        'id' and 'value' where 'value' contains datetime objects or date strings.
    event_tags : Sequence[dict[str, Any] | Filter]
        List of filters or Filter objects specifying which tags represent events.
        Each filter can have the following keys:
        - collection: The collection name (optional)
        - tag: The tag name to match (required)
        - field: The field to match against (e.g., "date", "start-date")
        - exact: List of exact values to match (optional)
        - between: List of [min, max] values to match (optional)
    time_unit : str, optional
        Unit for the time column in the output. Options are "days" or "months".
        Default is "months".

    Returns:
    --------
    pd.DataFrame
        DataFrame with columns:
        - id: Patient identifier
        - time: Time from anchor to event/censoring in specified time_unit
        - event: 1 if event occurred, 0 if censored
        - start_date: Anchor date (datetime)
        - end_date: Event or censoring date (datetime)

    Notes:
    ------
    - If a patient has no anchor date, they are excluded from the analysis
    - If a patient has no event dates after the anchor, they are censored using
      the latest date available in their record
    - If a patient has neither events nor censoring dates, they are excluded
    - For time_unit="months", fractional months are calculated based on average
      days per month (30.44 days/month)

    Examples:
    --------
    >>> km = kaplan_meier(data, df_anchors, event_tags)
    >>> # For time in months:
    >>> km = kaplan_meier(data, df_anchors, event_tags, time_unit="months")
    """
    # Validate inputs
    validate_gazoo_research_df(data)
    if "id" not in df_anchors.columns or "value" not in df_anchors.columns:
        raise ValueError("df_anchors must contain 'id' and 'value' columns")

    # Validate time_unit parameter
    if time_unit not in ["days", "months"]:
        raise ValueError(f"time_unit must be 'days' or 'months', got '{time_unit}'")

    # Collect data in a list for efficient DataFrame creation
    km_data = []

    # Loop through patients with anchors
    for patient_id in df_anchors["id"].unique():
        # Get patient's anchor date
        patient_anchors = df_anchors[df_anchors["id"] == patient_id]

        # Handle case where patient might have multiple anchor instances
        if len(patient_anchors) == 0:
            continue

        start_date = patient_anchors["value"].iloc[0]

        # Skip if start_date is NaT or None
        if pd.isna(start_date):
            continue

        # Get patient's data from the main dataframe
        pt = data[data["id"] == patient_id]

        # Get Event/Censored information
        start, last, event = pt_dates_and_events(pt, start_date, event_tags)

        # Only include patients where we have valid anchor and endpoint
        if start is not None and last is not None and event is not None:
            # Calculate time in specified unit from anchor to event/censor
            if isinstance(start, datetime) and isinstance(last, datetime):
                time_delta = last - start

                if time_unit == "days":
                    time_value = time_delta.days
                else:  # months
                    # Calculate months with fractional component
                    days = time_delta.days
                    time_value = days / 30.44  # Average days per month
            else:
                # Handle string dates
                try:
                    if isinstance(start, str):
                        start_dt = datetime.strptime(str(start), "%Y-%m-%d")
                    else:
                        start_dt = start
                    if isinstance(last, str):
                        last_dt = datetime.strptime(str(last), "%Y-%m-%d")
                    else:
                        last_dt = last

                    time_delta = last_dt - start_dt

                    if time_unit == "days":
                        time_value = time_delta.days
                    else:  # months
                        days = time_delta.days
                        time_value = days / 30.44
                except (ValueError, TypeError):
                    time_value = None

            km_data.append(
                {
                    "id": patient_id,
                    "time": time_value,
                    "event": event,
                    "start_date": start,
                    "end_date": last,
                }
            )

    # Create and return DataFrame
    if km_data:
        km_df = pd.DataFrame(km_data)
        # Ensure correct column order
        return km_df[["id", "time", "event", "start_date", "end_date"]]
    else:
        # Return empty DataFrame with expected columns
        return pd.DataFrame(columns=["id", "time", "event", "start_date", "end_date"])


def time_in_months(start, end):
    """
    Calculate the number of months between start and end dates.

    Parameters:
    start_date (datetime.datetime): starting date in the format YYYY-MM-DD
    end_date (datetime.datetime): end date in the format YYYY-MM-DD

    Returns:
    months (int): number of months (rounded down) between start and end dates
    Exceptions:


    """
    months = (end.year - start.year) * 12 + end.month - start.month
    if start.day > end.day:
        months -= 1  # round down if not a full month

    return months


def plot_km_curves(
    km: pd.DataFrame, time_column: str = "time", event_column: str = "event"
):
    """
    Creates a Kaplan-Meier plot.

    Parameters:
    km (DataFrame): dataframe for kaplan meier with columns for time and event
    time_column (str): Name of the column containing time values (default: "time")
    event_column (str): Name of the column containing event/censoring indicators (default: "event")

    The time values can be in days or months depending on how kaplan_meier was called.
    For proper time interpretation, ensure consistency with the time unit used in kaplan_meier.

    Examples:
    >>> km = kaplan_meier(data, df_anchors, event_tags)
    >>> fig = plot_km_curves(km)
    >>> # For time in months:
    >>> km = kaplan_meier(data, df_anchors, event_tags, time_unit="months")
    >>> fig = plot_km_curves(km)
    """
    fig = plt.figure()
    ax = plt.subplot(111)

    durations = km[time_column].to_numpy()
    events = km[event_column].to_numpy()

    kmf = KaplanMeierFitter()
    kmf.fit(durations, event_observed=events)
    kmf.plot_survival_function(ax=ax)

    plt.xlabel("Time")
    plt.ylabel("Event Probability")
    plt.title("Kaplan-Meier Curve")
    return fig


def get_field_value(tag: pd.DataFrame, fields: List[dict]):
    """
    Gets Field Values

    Parameters:
    tag (DataFrame): dataframe with csv tag
    fields (list of dicts): list of possible fields. Structure of fields {'collection':str, 'tag': str, 'field': str}

    Returns:
    data (Array): dataframe with columns: id, collection, tag, field, data_type, value date
    """

    df = pd.DataFrame()

    # Loop Through MRNs
    for mrn in tag.id.unique():
        # print("mrn",mrn)
        # Select mrn specific Information
        pt = tag.loc[(tag["id"] == mrn)]
        # Loop through fields
        for field in fields:
            # Get Field Value
            test_a = pt.loc[
                (pt["collection"].astype(str) == field["collection"])
                & (pt["tag"].astype(str) == field["tag"])
                & (pt["field"].astype(str) == field["field"])
            ]
            test_a = pt.loc[(pt["tag_id"].astype(str).isin(test_a.tag_id))]

            # Loop through tags
            for tag_id in test_a.tag_id.unique():
                test_b = test_a.loc[test_a["tag_id"].astype(str) == tag_id]

                # Get Date
                date = test_b.loc[
                    test_b["data_type"].astype(str) == "date"
                ].value.tolist()
                if len(date) == 0:
                    date = None
                else:
                    date = date[0]

                # Get Field
                test_b = test_b.loc[test_b["field"].astype(str) == field["field"]]

                #
                test_c = test_b[
                    ["id", "collection", "tag", "field", "data_type", "value"]
                ].copy()
                # Add Date Column
                test_c["date"] = date

                # Append Value
                df = pd.concat([df, test_c])

    return df


def get_tag_time_series(
    df: pd.DataFrame, tag: str, anchors: Optional[pd.DataFrame] = None
):
    """
    Calculates time-series data for a tag.
    The time-delta will be normalizing from the first instance of the tag, or to the anchor's date.
    The tag must have a date or start-date field.

    The function:
    1. Filters data for the specified tag
    2. Pivots the data so each field becomes a column
    3. Normalizes timestamps by calculating time delta from each patient's first measurement
    4. Returns a consolidated dataframe with all patients' data

    Parameters:
        df (DataFrame): dataframe with raw CSV data containing tag measurements
        tag (str): tag name.
        anchors (DataFrame | None): Anchors for each patient

    Returns:
        df_plot (DataFrame): dataframe with pivoted tag data including:
            - id column
            - Date column (renamed to 'date' or 'start-date')
            - Value column (renamed to the field name)
            - Additional columns (e.g., 'units', 'mrn')
            - 'time-delta' column showing days from the first measurement

    Raises:
        AssertionError: if tag does not contain 'tag'  key

    Example:
        df_plot = get_tag_time_series(data, "psa")
        # Result includes: id, date, value, units, time-delta columns
    """
    assert isinstance(df, pd.DataFrame), f"pt should be a pd.DataFrame, not {type(df)}"
    # Validate gazoo research df
    validate_gazoo_research_df(df)
    assert isinstance(df, pd.DataFrame), f"df should be a pd.DataFrame, not {type(df)}"
    assert isinstance(tag, str), f"tag should be a str, not {type(tag)}"

    # Isolates tag
    df = get_tags_where_filter(df, {"tag": tag})

    df_plot = pd.DataFrame()
    # Loop through patients
    for patient in df["id"].unique():
        df_patient = df.loc[df["id"] == patient]
        df_patient = pivot(df_patient)
        # Rename Column to field name. There shouldn't be collisions
        df_patient.columns = [
            col_name.split(":")[-1] for col_name in df_patient.columns.values
        ]

        # Set Date Field Name
        if "date" in df_patient.columns:
            date = "date"
        elif "start-date" in df_patient.columns:
            date = "start-date"
        else:
            continue

        if isinstance(anchors, pd.DataFrame):
            # Get patient's anchor
            anchor = anchors.loc[anchors["id"] == patient]
            if anchor.empty:
                continue
            anchor = anchor.iloc[0]  # Gets 1st anchor
            # Append Anchor to patient data
            anchor = {"id": anchor["id"], "date": anchor["value"]}

            anchor = pd.Series(
                [anchor.get(col, np.nan) for col in df_patient.columns],
                index=df_patient.columns,
            )
            df_patient = pd.concat([anchor.to_frame().T, df_patient], ignore_index=True)

        df_patient[date] = pd.to_datetime(
            df_patient[date]
        )  # Convert Date Column to Date Time
        df_patient = df_patient.sort_values(by=date)  # Sort by Datetime
        df_patient = df_patient.reset_index(drop=True)
        start_date = df_patient[date][0]
        df_patient["time-delta"] = df_patient[date] - start_date  # Calculate DateDiff

        # Create a new column with pateint id
        df_patient.insert(loc=0, column="id", value=patient)

        # Append
        df_plot = pd.concat([df_plot, df_patient])

    return df_plot


def line_plot(
    df: pd.DataFrame, field, x_scale="day", xlabel="", ylabel="", loc="upper right"
):
    """
    Creates A line plots from the output of functions like "get_tag_time_series".

    Parameters:
        df (DataFrame): dataframe output from functions like "get_tag_time_series"
        field: str -> Column name to plot
        x_scale (str): Should the x-axis be in years or days. ['day' or 'year']
        xlabel: (str): X-Axis label
        ylabel: (str): Y-Axis label
        loc: str -> Location of legend

    Return:
        fig (DataFrame): dataframe of line plot data
    """
    assert isinstance(df, pd.DataFrame), f"df should be a pd.DataFrame, not {type(df)}"
    assert isinstance(x_scale, str), f"y_scale should be a str, not {type(x_scale)}"
    assert x_scale in ["day", "year"], (
        f"y_scale should be ['day','year'], not {x_scale}"
    )
    # Create Figure
    fig, ax = plt.subplots()

    # Plot Tumor Height
    for patient_id in df["id"].unique():
        df_patient = df.loc[df["id"] == patient_id].copy()
        # Convert to years or days
        if x_scale == "year":
            df_patient["time-delta"] = df_patient.apply(
                lambda row: row["time-delta"].days / 365.25, axis=1
            )
        else:
            df_patient["time-delta"] = df_patient.apply(
                lambda row: row["time-delta"].days, axis=1
            )

        # Check to see if field exists.
        if field not in df_patient.columns.values:
            continue

        # Convert to numbers
        values = []
        for value in df_patient[field].values:
            try:
                value = float(value)
            except:
                value = None
            values.append(value)

        # Plot
        ax.plot(df_patient["time-delta"].values, values, linestyle="-", marker=".")

    # ax.legend(df.mrn.unique(), loc='upper right')  # Add Legend
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_xlim(0)
    return fig


def categorical_plot(
    df,
    field,
    y_scale: list[str],
    x_scale="day",
    xlabel="",
    ylabel="",
    loc="upper right",
):
    """
    Creates A categorical plot from the output of functions like "plot_data_from_anchor" or "plot_data".

    Parameters:
        df (DataFrame): dataframe output from functions like "plot_data_from_anchor" or "plot_data"
        field: str -> Column name to plot
        y_scale: list[str] -> Order of y-axis
        x_scale (str): Should the x-axis be in years or days. ['day' or 'year']
        xlabel: (str): X-Axis label
        ylabel: (str): Y-Axis label
        loc: str -> Location of legend

    Return:
        fig (DataFrame): dataframe of line plot data
    """
    assert isinstance(df, pd.DataFrame), f"df should be a pd.DataFrame, not {type(df)}"
    assert isinstance(x_scale, str), f"y_scale should be a str, not {type(x_scale)}"
    assert x_scale in ["day", "year"], (
        f"y_scale should be ['day','year'], not {x_scale}"
    )
    # Create Figure
    fig, ax = plt.subplots()

    # Plot Tumor Height
    for patient_id in df.mrn.unique():
        df_patient = df.loc[df["mrn"] == patient_id].copy()
        # Convert to years or days
        if x_scale == "year":
            df_patient["time-delta"] = df_patient.apply(
                lambda row: row["time-delta"].days / 365.25, axis=1
            )
        else:
            df_patient["time-delta"] = df_patient.apply(
                lambda row: row["time-delta"].days, axis=1
            )

        # Check to see if field exists.
        if field not in df_patient.columns.values:
            continue

        # print(df_patient[field].values, df_patient["time-delta"].values)

        # # Convert to numbers
        # values = []
        # for value in df_patient[field].values:
        #     try:
        #         value = float(value)
        #     except:
        #         value = None
        #     values.append(value)

        # Plot
        ax.plot(
            df_patient["time-delta"].values,
            df_patient[field].values,
            linestyle="-",
            marker=".",
        )

    ax.legend(df.mrn.unique(), loc="upper right")  # Add Legend
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_xlim(0)
    plt.show()
    plt.clf()

    return fig


def get_anchors(
    df: pd.DataFrame,
    anchors: Sequence[dict[str, str]] | Sequence[Filter],
    time_delta: float | timedelta,
    instance: int,
) -> pd.DataFrame:
    """
    Get anchor dates for each patient based on specified anchor sequences.

    An anchor is a reference point used for time-based analysis. It can be a single tag
    (e.g., surgery date) or a sequence of ordered tags that must all occur within the
    specified time_delta (e.g., surgery followed by radiation on the same day).

    ## Anchor Structure
    Anchors follow the same structure as filters. Each anchor is a dictionary with:
        - collection: The collection name (optional)
        - tag: The tag name to match (required)
        - field: The field to match against (e.g., "date")
        - exact: List of exact values to match (optional)
        - between: List of [min, max] values to match (optional)

    Single anchor example:
        {'collection': 'oncology', 'tag': 'surgery', 'field': 'date'}

    Tag sequence example (all tags must occur within time_delta):
        [
            {'tag': 'surgery', 'field': 'date'},
            {'tag': 'radiation', 'field': 'date'}
        ]

    Parameters
    ----------
    df : pd.DataFrame
        A Gazoo Research DataFrame with columns: id, collection, tag, tag_id,
        field, data_type, value, phi.
    anchors : Sequence[dict[str, str]] | Sequence[Filter]
        A list of anchor definitions. Can be a list of Filter objects or dicts.
        Each anchor specifies tag(s) to find in the patient data.
    time_delta : float | timedelta
        Maximum allowed time between consecutive anchors in a sequence.
        Can be a float (number of days, for backward compatibility) or a
        datetime.timedelta object for more precise time durations.

        Examples:
        - `90.0` (float, 90 days)
        - `timedelta(days=90)` (90 days)
        - `timedelta(days=5, hours=3)` (5 days and 3 hours)
        - `timedelta(hours=24)` (24 hours)
    instance : int
        Zero-based index to select which instance of a matched anchor to return
        when multiple matches exist for a patient.

    Returns
    -------
    pd.DataFrame
        A DataFrame containing the matching anchor tags for each patient.
        Returns one row per matched anchor instance. Columns conform to the
        Gazoo Research DataFrame standard.

    Examples
    --------
    Find all patients who had surgery:
        >>> anchors = [{'tag': 'surgery', 'field': 'date'}]
        >>> result = get_anchors(df, anchors, time_delta=0, instance=0)

    Find patients who had surgery followed by radiation within 1 day:
        >>> anchors = [
        ...     {'tag': 'surgery', 'field': 'date'},
        ...     {'tag': 'radiation', 'field': 'date'}
        ... ]
        >>> result = get_anchors(df, anchors, time_delta=1, instance=0)

    Using timedelta for more precise durations:
        >>> from datetime import timedelta
        >>> anchors = [{'tag': 'surgery', 'field': 'date'}]
        >>> result = get_anchors(df, anchors, time_delta=timedelta(days=5, hours=3), instance=0)
    """
    assert isinstance(df, pd.DataFrame), f"pt should be a pd.DataFrame, not {type(df)}"
    validate_gazoo_research_df(df)

    # Convert float to timedelta for backward compatibility
    if isinstance(time_delta, float) or isinstance(time_delta, int):
        time_delta = timedelta(days=time_delta)

    # Convert filters to pydantic
    if isinstance(anchors, Sequence):
        anchors = [
            convert_to_filter(anchor) if isinstance(anchor, dict) else anchor
            for anchor in anchors
        ]

    def chunker(seq, size):
        return (seq[pos : pos + size] for pos in range(0, len(seq), size))

    def rolling_assessment(data, pattern):
        """Calculates the assessment mean of a NumPy array.
        data: Dataframe
        """
        window_size = len(pattern)

        data["sequence_match"] = False

        if len(data) < window_size:
            # print("Window size cannot exceed the data length")
            return data

        for i in range(len(data) - window_size + 1):
            window = data[i : i + window_size]
            if (window["tag"] == pattern).all():
                data.loc[i : i + window_size - 1, "sequence_match"] = True
            elif set(window["tag"]) == set(pattern) and window[
                "date_diff"
            ].sum() == timedelta(days=0):
                data.loc[i : i + window_size - 1, "sequence_match"] = True
        return data

    # Get anchors
    df_anchor_tags = pd.DataFrame()
    for anchor in anchors:
        # Get Tags and append
        df_anchor_tags = pd.concat([df_anchor_tags, get_tags_where_filter(df, anchor)])
    df = df_anchor_tags.copy(deep=True)

    # Check if any anchors exist
    df_anchors = pd.DataFrame()
    # Only keep dates values
    df = df.loc[(df["data_type"] == "date")]
    df = df.loc[(df["field"] == "date") | (df["field"] == "start-date")]
    # Loop through patients
    for patient in df["id"].unique():
        # Get Patient Data
        df_patient = df[df["id"] == patient].copy(deep=True)
        # Sort By Dates
        df_patient["value"] = pd.to_datetime(
            df_patient["value"]
        )  # Convert value column to Date Time
        df_patient = df_patient.sort_values(by=["value", "tag_id"])  # Sort by Datetime
        df_patient = df_patient.reset_index(drop=True)

        # Match anchor
        pattern = np.asarray([anchor.tag for anchor in anchors])
        df_anchor = pd.DataFrame()
        if len(pattern) >= 2:
            # Create Time Diff
            grouping_columns = ["id"]
            df_patient["date_diff"] = df_patient.groupby(grouping_columns)[
                "value"
            ].diff()
            # Create tag_number used for rolling
            df_patient = rolling_assessment(df_patient, pattern)
            df_patient = df_patient.drop("date_diff", axis=1)

            # Only keep tags where sequence match is true
            df_patient = df_patient.loc[df_patient["sequence_match"] == True]

            # Loop through anchors
            for df_ in chunker(df_patient, len(pattern)):
                df_ = df_.copy(deep=True)
                # Calculate Time Delta
                df_["delta"] = df_["value"].diff()

                if df_["delta"].max() <= time_delta:
                    df_ = df_.drop(columns=["sequence_match", "delta"])
                    df_anchor = pd.concat([df_anchor, df_])
        else:
            df_anchor = df_patient

        # Remove Duplicates - keep first occurrence of each unique date
        df_anchor = df_anchor.drop_duplicates(subset="value", keep="first")

        # Break loop if anchor is empty
        if df_anchor.empty:
            continue

        # Get Tag ID
        if instance >= len(df_anchor["tag_id"].values):
            # No anchor found
            tag_id = None
        else:
            # Anchor found
            tag_id = df_anchor["tag_id"].values[instance]
        df_anchor = df_anchor[df_anchor["tag_id"] == tag_id]

        # Append To Dataframe
        df_anchors = pd.concat([df_anchors, df_anchor])

    return df_anchors.copy(deep=True)


def describe_fields(
    df: pd.DataFrame,
    df_anchors: pd.DataFrame,
    fields: Sequence[dict | Filter],
    search_range: list[float | int],
) -> list[pd.DataFrame]:
    """
    Extract field values around anchor dates for each patient.

    This function analyzes patient data around specified anchor dates (e.g., surgery date)
    and extracts values for specified fields within a given time window. It's useful for
    creating patient summaries at specific timepoints of interest.

    Parameters
    ----------
    df : pd.DataFrame
        A Gazoo Research DataFrame with columns: id, collection, tag, tag_id,
        field, data_type, value, phi.
    df_anchors : pd.DataFrame
        A DataFrame containing anchor dates for each patient. Must contain 'id' and 'value'
        columns where 'value' contains datetime values.
    fields : Sequence[dict | Filter]
        List of field specifications to extract. Each can be:
        - A dictionary with keys like 'collection', 'tag', 'field'
        - A Filter object with similar properties
    search_range : list[float | int]
        A two-element list [min_days, max_days] specifying the time window relative to
        each anchor date. Negative values look backwards (before anchor), positive values
        look forwards (after anchor).

        Example: [-90.0, 1.0] searches 90 days before to 1 day after the anchor.

    Returns
    -------
    list[pd.DataFrame]
        A list of DataFrames, one for each field specified. Each DataFrame contains:
        - id: Patient identifier
        - collection: Data collection name (if specified)
        - tag: Tag name
        - field: Field name
        - data_type: Type of data (e.g., 'date', 'number', 'categorical')
        - value: The extracted value
        - Other metadata columns from the original data

    Notes
    -----
    - For each patient and field, only the value closest to the anchor date within
      the search range is returned
    - If no values are found within the search range, an empty DataFrame is returned
      for that field (patients without matching data are simply excluded)
    - Anchor dates are used as the reference point (day 0) for the time window

    Examples
    --------
    Basic usage with dict specifications:

        >>> anchors = get_anchors(df, [{'tag': 'surgery'}], time_delta=90.0, instance=0)
        >>> fields = [
        ...     {'collection': 'c61', 'tag': 'psa', 'field': 'value'},
        ...     {'tag': 'pT', 'field': 'T'}
        ... ]
        >>> results = describe_fields(df, anchors, fields, [-90.0, 1.0])

    Using Filter objects:

        >>> from gazoo_research_utils.models.filter_model import Filter
        >>> fields = [
        ...     Filter(collection='c61', tag='psa', field='value'),
        ...     Filter(tag='psa', field='units')
        ... ]
        >>> results = describe_fields(df, anchors, fields, [-30.0, 30.0])
    """
    # Input validation
    if not isinstance(df, pd.DataFrame):
        raise TypeError(f"df should be a pd.DataFrame, not {type(df)}")
    validate_gazoo_research_df(df)
    if not isinstance(df_anchors, pd.DataFrame):
        raise TypeError(f"df_anchors should be a pd.DataFrame, not {type(df_anchors)}")
    if not isinstance(search_range, list):
        raise TypeError(f"search_range should be a list, not {type(search_range)}")
    if len(search_range) != 2:
        raise ValueError(
            f"search_range should have exactly 2 elements, got {len(search_range)}"
        )
    for i, x in enumerate(search_range):
        if not isinstance(x, (float, int)):
            raise TypeError(f"search_range[{i}] should be float or int, not {type(x)}")
    if not isinstance(fields, list):
        raise TypeError(f"fields should be a list, not {type(fields)}")

    df_describe: list[pd.DataFrame] = []

    # Convert Filter objects to dicts for consistent processing
    processed_fields: list[dict] = []
    for field in fields:
        if isinstance(field, Filter):
            field_dict = {k: v for k, v in field.model_dump().items() if v is not None}
            processed_fields.append(field_dict)
        elif isinstance(field, dict):
            processed_fields.append(field)
        else:
            raise TypeError(f"field should be dict or Filter, not {type(field)}")

    # Loop through fields
    for field in processed_fields:
        df_field_values = pd.DataFrame()

        # Validate field has required keys
        if "tag" not in field or "field" not in field:
            raise ValueError(
                f"field must have 'tag' and 'field' keys, got {field.keys()}"
            )

        # Loop through patients
        for patient_id in df["id"].unique():
            # Get patient specific dataframe
            df_patient = df[df["id"] == patient_id].copy(deep=True)
            df_anchor = df_anchors[df_anchors["id"] == patient_id].copy(deep=True)

            # Skip if no anchor for this patient
            if df_anchor.empty:
                continue

            # Get anchor date (use first valid anchor)
            anchor_value = df_anchor["value"].iloc[0]

            # Find all tag_ids for this tag that have a date field
            # First get rows with data_type == "date" and field == "date" or "start-date"
            date_filter = {k: v for k, v in field.items() if k in ("collection", "tag")}
            # Look for date, start-date, or end-date fields (for timespans)
            date_filter["field"] = "date"
            df_date_rows = get_tags_where_filter(df_patient, date_filter)

            # Also get rows with start-date or end-date for timespan tags
            date_filter_start = {
                k: v for k, v in field.items() if k in ("collection", "tag")
            }
            date_filter_start["field"] = "start-date"
            df_date_rows_start = get_tags_where_filter(df_patient, date_filter_start)

            date_filter_end = {
                k: v for k, v in field.items() if k in ("collection", "tag")
            }
            date_filter_end["field"] = "end-date"
            df_date_rows_end = get_tags_where_filter(df_patient, date_filter_end)

            # Combine all date rows
            df_date_rows = pd.concat(
                [df_date_rows, df_date_rows_start, df_date_rows_end]
            )

            # Get tag_ids that have dates
            tag_ids_with_dates = df_date_rows["tag_id"].unique()

            # Now get all rows for these tag_ids
            df_all_rows = df_patient[df_patient["tag_id"].isin(tag_ids_with_dates)]

            # Filter to matching tag and (optionally) collection
            # Also handle the case where we're filtering for a specific field like 'value'
            tag_mask = df_all_rows["tag"].astype(str) == field["tag"]
            if "collection" in field:
                tag_mask = tag_mask & (
                    df_all_rows["collection"].astype(str) == field["collection"]
                )
            df_filtered = df_all_rows[tag_mask]

            # Also get the value field rows for this tag
            if "field" in field:
                value_mask = df_all_rows["field"].astype(str) == field["field"]
                df_value_rows = df_all_rows[value_mask]
                # Combine filtered rows with value rows to ensure we capture all relevant data
                df_filtered = pd.concat([df_filtered, df_value_rows])

            # If field is specified, filter to that field (and get associated dates)
            if "field" in field:
                # Get rows matching the field
                field_mask = df_filtered["field"].astype(str) == field["field"]
                df_field = df_filtered[field_mask]

                # For each tag_id, find the associated date
                for tag_id in df_field["tag_id"].unique():
                    df_tag = df_field[df_field["tag_id"] == tag_id]

                    # Get the date for this tag_id (from data_type == "date" row)
                    date_row = df_patient[
                        (df_patient["tag_id"] == tag_id)
                        & (df_patient["data_type"] == "date")
                        & (
                            (df_patient["field"] == "date")
                            | (df_patient["field"] == "start-date")
                        )
                    ]
                    if date_row.empty:
                        continue

                    tag_date = date_row["value"].iloc[0]
                    if pd.isna(tag_date):
                        continue

                    # Calculate delta from anchor
                    if isinstance(tag_date, str):
                        tag_date = pd.to_datetime(tag_date)
                    delta_days = (tag_date - anchor_value).days

                    # Check if within search range
                    if not (search_range[0] <= delta_days <= search_range[1]):
                        continue

                    # Get the field value
                    value_row = df_patient[
                        (df_patient["tag_id"] == tag_id)
                        & (df_patient["field"] == field["field"])
                    ]
                    if value_row.empty:
                        continue

                    # Create result row with all relevant data
                    result_row = value_row.iloc[0:1].copy()
                    result_row["delta_days"] = delta_days

                    # Append to results
                    df_field_values = pd.concat(
                        [df_field_values, result_row], ignore_index=True
                    )
            else:
                # No specific field - use the first field found for each tag_id
                for tag_id in df_filtered["tag_id"].unique():
                    df_tag = df_filtered[df_filtered["tag_id"] == tag_id]

                    # Get the date for this tag_id
                    date_row = df_patient[
                        (df_patient["tag_id"] == tag_id)
                        & (df_patient["data_type"] == "date")
                        & (
                            (df_patient["field"] == "date")
                            | (df_patient["field"] == "start-date")
                        )
                    ]
                    if date_row.empty:
                        continue

                    tag_date = date_row["value"].iloc[0]
                    if pd.isna(tag_date):
                        continue

                    # Calculate delta from anchor
                    if isinstance(tag_date, str):
                        tag_date = pd.to_datetime(tag_date)
                    delta_days = (tag_date - anchor_value).days

                    # Check if within search range
                    if not (search_range[0] <= delta_days <= search_range[1]):
                        continue

                    # Get the first field value
                    value_row = df_tag.iloc[0:1].copy()
                    value_row["delta_days"] = delta_days

                    # Append to results
                    df_field_values = pd.concat(
                        [df_field_values, value_row], ignore_index=True
                    )

        # Remove duplicates (keep closest to anchor)
        if not df_field_values.empty and "delta_days" in df_field_values.columns:
            df_field_values = df_field_values.sort_values(
                ["id", "tag_id", "delta_days"], ascending=[True, True, True]
            )
            df_field_values = df_field_values.drop_duplicates(
                subset=["id", "tag_id"], keep="first"
            )
            # Remove delta_days from output
            df_field_values = df_field_values.drop(columns=["delta_days"])

        # Append result for this field
        df_describe.append(df_field_values)

    return df_describe


# Plot Table 1
def plot_table1(
    df_describes: list[list[pd.DataFrame]],
    figsize: float = 10,
    normalize: bool = True,
    alpha: float = 0.6,
) -> plt.Figure:
    """
    Create Table 1 visualization from described field data.

    This function generates publication-ready plots for baseline patient characteristics,
    displaying continuous variables as histograms and categorical/text variables as bar charts.

    Parameters
    ----------
    df_describes : list[list[pd.DataFrame]]
        A list of result sets from describe_fields().
        Each result set is a list of DataFrames, one per field.
        Each DataFrame contains field values for patients around anchor dates.

        Example structure:
            [
                [df_field1, df_field2],  # Result set 1
                [df_field3, df_field4],  # Result set 2
            ]

        Each DataFrame should have columns:
        - id: Patient identifier
        - collection: Data collection name (optional)
        - tag: Tag name
        - field: Field name
        - data_type: Type of data ('number', 'categorical', 'text', 'date')
        - value: The field value

    figsize : float, optional
        Base figure size (width and height). Default is 10.
        The actual height scales with the number of fields to ensure readability.

    normalize : bool, optional
        Whether to normalize histograms and bar charts to show proportions
        rather than counts. Default is True.

    alpha : float, optional
        Transparency value for plot elements (0.0 to 1.0).
        Lower values make elements more transparent. Default is 0.6.

    Returns
    -------
    matplotlib.figure.Figure
        A matplotlib Figure object containing the subplots.

    Notes
    -----
    - Continuous variables (data_type='number') are displayed as histograms
    - Categorical/text variables are displayed as bar charts showing value counts
    - Missing data count is displayed as a text box on histogram plots
    - The function can handle multiple result sets for comparison
    - When multiple result sets are provided, they are overlaid in each subplot

    Examples
    --------
    Basic usage:

        >>> anchors = get_anchors(df, [{'tag': 'surgery'}], time_delta=90.0, instance=0)
        >>> fields = [
        ...     {'tag': 'psa', 'field': 'value'},
        ...     {'tag': 'pT', 'field': 'T'}
        ... ]
        >>> results = describe_fields(df, anchors, fields, [-90.0, 1.0])
        >>> fig = plot_table1([results])

    Compare two different cohorts:

        >>> results_cohort1 = describe_fields(df1, anchors, fields, [-90.0, 1.0])
        >>> results_cohort2 = describe_fields(df2, anchors, fields, [-90.0, 1.0])
        >>> fig = plot_table1([results_cohort1, results_cohort2])
    """

    # Validate input
    if not isinstance(df_describes, list):
        raise TypeError(f"df_describes should be a list, not {type(df_describes)}")

    if len(df_describes) == 0:
        raise ValueError("df_describes should contain at least one result set")

    # Handle empty first result set
    if len(df_describes[0]) == 0:
        # Create an empty figure with just a title
        fig, ax = plt.subplots(figsize=(figsize, figsize * 0.5))
        ax.text(
            0.5,
            0.5,
            "No data to display",
            ha="center",
            va="center",
            transform=ax.transAxes,
        )
        ax.axis("off")
        fig.suptitle("Table 1: Patient Characteristics", fontsize=14)
        return fig

    # Calculate figure height based on number of fields in first result set
    num_fields = len(df_describes[0])
    fig_height = figsize * max(1, num_fields) / 2

    # Create figure with appropriate number of subplots
    fig, axs = plt.subplots(
        num_fields,
        1,
        figsize=(figsize, fig_height),
        sharey=False,
        tight_layout=True,
    )

    # Handle single subplot case (axs is not a list)
    if num_fields == 1:
        axs = [axs]

    # Loop through each result set (for overlaying multiple comparisons)
    for result_idx, df_describe in enumerate(df_describes):
        # Validate each result set
        if not isinstance(df_describe, list):
            raise TypeError(
                f"Each element in df_describes should be a list, "
                f"got {type(df_describe)} at index {result_idx}"
            )

        # Get label for this result set
        label = f"Result {result_idx + 1}"

        # Loop through fields in this result set
        for field_idx, df_field_values in enumerate(df_describe):
            # Skip if no data
            if df_field_values.empty:
                continue

            ax = axs[field_idx]

            # Get data type
            data_types = df_field_values["data_type"].unique()
            if len(data_types) == 0:
                continue
            data_type = data_types[0]

            # Get tag and field for labeling
            if "tag" in df_field_values.columns and len(df_field_values) > 0:
                tag = df_field_values["tag"].iloc[0]
            else:
                tag = "Unknown"

            if "field" in df_field_values.columns and len(df_field_values) > 0:
                field = df_field_values["field"].iloc[0]
            else:
                field = "Unknown"

            # Plot based on data type
            if data_type == "number":
                # Get values and handle missing data
                values = df_field_values["value"].to_numpy().flatten()
                values = [float(v) if v is not None else None for v in values]
                missing_count = sum(v is None for v in values)
                valid_values = [v for v in values if v is not None]

                # Add text box for missing data count
                textstr = f"n={len(valid_values)}\nMissing: {missing_count}"
                props = dict(boxstyle="round", facecolor="wheat", alpha=0.5)
                ax.text(
                    0.95,
                    0.95,
                    textstr,
                    transform=ax.transAxes,
                    fontsize=10,
                    verticalalignment="top",
                    horizontalalignment="right",
                    bbox=props,
                )

                # Plot histogram
                if valid_values:
                    ax.hist(
                        valid_values,
                        label=label,
                        density=normalize,
                        alpha=alpha,
                        bins=20,
                        edgecolor="black",
                        linewidth=0.5,
                    )

            elif data_type in ("categorical", "text"):
                # Get value counts
                value_counts = df_field_values["value"].value_counts()
                value_counts = value_counts.sort_values()

                variables = value_counts.index
                counts = value_counts.values

                # Normalize if requested
                if normalize and len(counts) > 0:
                    total = np.sum(counts)
                    if total > 0:
                        counts = counts / total

                # Plot bar chart
                ax.bar(
                    [str(v) for v in variables],
                    counts,
                    label=label,
                    alpha=alpha,
                    edgecolor="black",
                    linewidth=0.5,
                )

            # Set x-axis label (only for first result set to avoid clutter)
            if result_idx == 0:
                ax.set_xlabel(f"{tag}:{field}")
                ax.set_ylabel("Proportion" if normalize else "Count")

    # Add legend if multiple result sets
    if len(df_describes) > 1:
        axs[0].legend(
            loc="upper right",
            bbox_to_anchor=(1.0, 1.0),
            framealpha=0.9,
            fontsize=9,
        )

    # Add title
    fig.suptitle("Table 1: Patient Characteristics", fontsize=14, y=1.02)

    return fig


def link_by_field_value(df: pd.DataFrame, tag_link: dict[str, str], instance: int = 0):
    """Gets tags which have the same field value as the link

    Parameters:
        pt: pd.DataFrame -> dataframe
        tag_link: dict -> Structure of tag_link {'collection':str, 'tag': str, 'field': str}
        instance: int -> In the event that the tag_link is present multiple times, this specifies which tag to use.
    Return:
        df: pd.DataFrame
    """
    df_linked = pd.DataFrame()
    # Loop through patients
    for patient in df["id"].unique():
        # Get Patient Data
        df_patient = df[df["id"] == patient].copy(deep=True)
        # Get Origin Tags
        df_tags = get_tags_where_filter(df_patient, tag_link)
        # Get Field Value
        df_link = df_tags.loc[(df_tags["field"] == tag_link["field"])]

        if len(df_link) >= 1:
            # Get instance of link
            df_link = df_link.iloc[instance]
            # Get tag_ids where tags tags with field
            tag_ids = df_patient.loc[
                (df_patient["field"] == df_link["field"])
                & (df_patient["value"] == df_link["value"])
            ]["tag_id"]
            df_patient = df_patient.loc[df_patient["tag_id"].isin(tag_ids)].copy(
                deep=True
            )
            # print(df_patient)
            df_linked = pd.concat([df_linked, df_patient])

    return df_linked


def filter_around_anchor(
    df: pd.DataFrame,
    df_anchors: pd.DataFrame,
    filters: Sequence[dict[str, Any] | Filter],
    search_range: List[float | int],
) -> pd.DataFrame:
    """
    Filters patients that have tags matching the filter around anchor dates.

    For each patient, finds anchor dates and checks if matching tags exist within
    the specified time range around each anchor. Returns only patients where all
    filters find matching data within the search range.

    The function:
    1. Gets anchor dates for each patient from df_anchors
    2. For each filter, finds matching tags in the patient's data
    3. Checks if any matching tag dates fall within [days_before, days_after] of any anchor
    4. Returns all rows for patients where ALL filters find matches within the range

    Parameters:
        df: DataFrame with all patient data (must be validated Gazoo Research DataFrame)
        df_anchors: DataFrame containing anchor tags with at least 'id' and 'value' columns
            where 'value' contains datetime objects or date strings
        filters: Sequence of filter dictionaries or Filter objects. Each filter can have:
            - collection: optional collection name to match
            - tag: optional tag name to match
            - field: optional field name to match (required for exact/between filters)
            - exact: list of exact value matches to filter on
            - between: [min, max] range to filter numeric values
        search_range: [days_before, days_after] range around anchor to search for matches.
            Negative values look backwards (before anchor), positive values look forwards.

    Returns:
        DataFrame with all rows from patients that meet ALL filter criteria around anchors.
        The returned DataFrame maintains the same structure as the input df.

    Raises:
        AssertionError: If inputs are not the expected types

    Examples:
        >>> # Get patients with PSA value within 30 days before to 7 days after surgery
        >>> anchors = get_anchors(df, [{'tag': 'surgery'}], time_delta=0, instance=0)
        >>> filters = [
        ...     {'collection': 'c61', 'tag': 'psa', 'field': 'value'},
        ... ]
        >>> result = filter_around_anchor(df, anchors, filters, [-30.0, 7.0])

        >>> # Get patients with pT category within 1 day of surgery
        >>> anchors = get_anchors(df, [{'tag': 'surgery'}], time_delta=0, instance=0)
        >>> filters = [
        ...     {'collection': 'c61', 'tag': 'pT', 'field': 'T', 'exact': ['2a', '2b']},
        ... ]
        >>> result = filter_around_anchor(df, anchors, filters, [-1.0, 1.0])

        >>> # Using Filter objects
        >>> from gazoo_research_utils.models.filter_model import Filter
        >>> filters = [
        ...     Filter(collection='c61', tag='psa', field='value'),
        ...     Filter(tag='pT', field='T', exact=['2a', '2b'])
        ... ]
        >>> result = filter_around_anchor(df, anchors, filters, [-30.0, 7.0])
    """
    assert isinstance(df, pd.DataFrame), f"df should be a pd.DataFrame, not {type(df)}"
    validate_gazoo_research_df(df)
    assert isinstance(df_anchors, pd.DataFrame), (
        f"df_anchors should be a pd.DataFrame, not {type(df_anchors)}"
    )
    assert isinstance(search_range, list), (
        f"search_range should be type list, not {type(search_range)}"
    )
    for x in search_range:
        assert isinstance(x, (float, int)), (
            f"search_range values should be float or int, not {type(x)}"
        )
    assert isinstance(filters, list), (
        f"filters should be type list, not {type(filters)}"
    )
    if not filters:
        # Return all rows for patients with anchors
        if df_anchors.empty or "id" not in df_anchors.columns:
            return df.iloc[0:0].copy(deep=True)
        patients_with_anchors = set(df_anchors["id"].unique())
        return df[df["id"].isin(patients_with_anchors)].copy(deep=True)

    # Convert filters to Filter objects for consistent processing
    processed_filters = []
    for f in filters:
        if isinstance(f, dict):
            processed_filters.append(convert_to_filter(f))
        elif isinstance(f, Filter):
            processed_filters.append(f)
        else:
            raise TypeError(
                f"filter items must be dict or Filter, got {type(f)} instead"
            )

    # Convert search range to integers for day-based comparison
    search_start = int(search_range[0])
    search_end = int(search_range[1])

    # Prepare anchor data with date conversion (only once)
    df_anchors = df_anchors.copy(deep=True)

    # Handle empty anchors or missing required columns
    if df_anchors.empty or "value" not in df_anchors.columns:
        return df.iloc[0:0].copy(deep=True)

    df_anchors["value"] = pd.to_datetime(df_anchors["value"], errors="coerce")

    # Get anchor dates per patient (only patients with valid anchors)
    valid_anchors = df_anchors[df_anchors["value"].notna()]
    patient_anchors = valid_anchors.groupby("id")["value"].apply(list).to_dict()

    # Track patients that pass all filters
    passing_patients = set()

    # Loop through patients
    for patient_id in df["id"].unique():
        # Get patient specific dataframe
        df_patient = df[df["id"] == patient_id].copy(deep=True)

        # Skip patients without anchors
        if patient_id not in patient_anchors:
            continue

        anchor_dates = patient_anchors[patient_id]

        # Check if all filters are satisfied for this patient
        all_filters_passed = True

        for filter_obj in processed_filters:
            # Get matching tags using the filter
            filtered_tags = get_tags_where_filter(df_patient, filter_obj)

            # Check if any matching tags exist
            if filtered_tags.empty:
                all_filters_passed = False
                break

            # Get tag_ids from filtered tags - these are the tags we're interested in
            tag_ids = filtered_tags["tag_id"].unique()

            # Find date rows for these tag_ids
            # Look for date, start-date, or end-date fields across all rows for these tag_ids
            date_fields = ["date", "start-date", "end-date"]

            # Get all rows for the tag_ids, then filter for date fields
            all_rows_for_tag_ids = df_patient[df_patient["tag_id"].isin(tag_ids)]
            date_rows = all_rows_for_tag_ids[
                (all_rows_for_tag_ids["field"].isin(date_fields))
                & (all_rows_for_tag_ids["data_type"] == "date")
            ]

            # Check if any date rows exist
            if date_rows.empty:
                all_filters_passed = False
                break

            # Convert tag date values to datetime
            tag_dates = pd.to_datetime(date_rows["value"], errors="coerce")
            tag_dates = tag_dates[tag_dates.notna()]

            if tag_dates.empty:
                all_filters_passed = False
                break

            # Calculate time delta from each anchor date
            # Find if any tag date falls within the search range of ANY anchor
            matched = False
            for anchor_date in anchor_dates:
                if pd.isna(anchor_date):
                    continue

                # Calculate delta in days from anchor to each tag date
                deltas = (tag_dates - anchor_date).dt.days

                # Check if any delta falls within search range (inclusive)
                if ((deltas >= search_start) & (deltas <= search_end)).any():
                    matched = True
                    break

            if not matched:
                all_filters_passed = False
                break

        # Only include patient if all filters passed
        if all_filters_passed:
            passing_patients.add(patient_id)

    # Filter to only patients that passed all filters
    if passing_patients:
        return df[df["id"].isin(passing_patients)].copy(deep=True)
    else:
        # Return empty DataFrame with same structure
        return df.iloc[0:0].copy(deep=True)
