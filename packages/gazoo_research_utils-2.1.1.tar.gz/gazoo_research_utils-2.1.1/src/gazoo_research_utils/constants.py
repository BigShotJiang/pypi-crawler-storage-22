GAZOO_RESEARCH_COLUMNS = [
    "id",
    "collection",
    "tag",
    "tag_id",
    "field",
    "data_type",
    "value",
    "phi",
]
# DOB Tag Structure - standard Gazoo format for date of birth
DOB_TAG_STRUCTURE = {"collection": "0", "tag": "dob", "field": "date"}
