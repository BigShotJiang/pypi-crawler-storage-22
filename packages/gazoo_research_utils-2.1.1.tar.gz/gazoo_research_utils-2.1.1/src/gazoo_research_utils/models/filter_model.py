from typing import List, Optional

from pydantic import BaseModel, ValidationInfo, field_validator


class Filter(BaseModel):
    collection: Optional[str] = None
    tag: Optional[str] = None
    field: Optional[str] = None
    exact: Optional[List[str]] = None
    between: Optional[List[float]] = None

    @field_validator("between")
    def validate_between(cls, v):
        if v is not None and len(v) != 2:
            raise ValueError("between must contain exactly two numeric values")
        return v

    @field_validator("exact", "between")
    def require_field(cls, v, info: ValidationInfo):
        if (v is not None) and (info.data.get("field") is None):
            raise ValueError("field is required when using exact or between filters")
        return v
