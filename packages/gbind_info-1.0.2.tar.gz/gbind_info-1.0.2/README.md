Garena Bind Info SDK 🚀

gbind-info is a powerful and secure Python library designed to help developers easily retrieve binding information (current email, pending email, and request countdown) for Garena accounts.

Features ✨
Secure Requests: Automatically rotates User-Agents to prevent request blocking and detection.
Human-Readable Time: Converts raw countdown seconds into an easy-to-read Day Hour Min Sec format.
Session Management: Utilizes requests.Session for faster performance and persistent connections.
Developer Friendly: Clean API design that can be integrated into Flask, Django, or standalone scripts in seconds.


installation 🛠️
Install the library via pip:
pip install gbind_info


Quick Start 💻
Here is a simple example of how to use the library in your project:

```python```
from gbind_info import InfoClient

# Initialize the client
client = InfoClient()

# Provide the Garena Access Token
ACCESS_TOKEN = "YOUR_GARENA_ACCESS_TOKEN"

# Fetch binding data
result = client.get_bind_info(ACCESS_TOKEN)

if result["status"] == "success":
    print(f"Summary: {result['summary']}")
    print(f"Current Email: {result['data']['current_email']}")
    print(f"Human Countdown: {result['data']['countdown_human']}")
else:
    print(f"Error: {result['message']}")


API Response Structure 📊
The library returns a structured dictionary for every request:

```json```
{
    "status": "success",
    "data": {
        "current_email": "user***@gmail.com",
        "pending_email": "new***@gmail.com",
        "countdown_human": "6 Day 23 Hour 59 Min 50 Sec",
        "raw": { "original_api_response_here": "..." }
    },
    "summary": "Pending email confirmation: new***@gmail.com - Confirms in: 6 Day 23 Hour ..."
}


Technical Workflow


Security & Disclaimer 🛡️

This library is intended for educational and research purposes only. Accessing account information without explicit permission may violate Garena's Terms of Service. The developer is not responsible for any misuse, account bans, or legal issues resulting from the use of this software. Use it responsibly.


License 📄

Distributed under the MIT License. See LICENSE for more information.