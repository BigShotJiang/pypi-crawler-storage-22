import random

def format_seconds(s):
  
    if not s or s <= 0: return "0"
    d, h = divmod(s, 86400)
    h, m = divmod(h, 3600)
    m, s = divmod(m, 60)
    return f"{d} Day {h} Hour {m} Min {s} Sec"

def get_random_ua():
    
    agents = [
        "GarenaMSDK/4.0.19P9(Redmi Note 5;Android 9;en;US;)",
        "GarenaMSDK/4.1.0(Samsung S21;Android 12;en;US;)",
        "GarenaMSDK/3.8.5(Pixel 4;Android 11;en;GB;)",
        "GarenaMSDK/4.0.5(OnePlus 8;Android 10;en;IN;)"
    ]
    return random.choice(agents)
