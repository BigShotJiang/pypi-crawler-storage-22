# gbkomi

[![PyPI version](https://img.shields.io/pypi/v/gbkomi)](https://pypi.org/project/gbkomi/)
[![License](https://img.shields.io/pypi/l/gbkomi)](https://pypi.org/project/gbkomi/)
[![Downloads](https://img.shields.io/pypi/dm/gbkomi)](https://pypi.org/project/gbkomi/)

**gbkomi** is a Python library for **encrypting, decrypting, and hashing data** with extremely high security.  
It is designed for sensitive projects and **Telegram bots**.

---

## 🔹 Features

- Encrypt text, files, and binary data with **AES-256-GCM** and **ChaCha20-Poly1305**  
- Secure user key management and strong random key generation  
- SHA-256 and SHA-512 hashing, HMAC for message authentication  
- Argon2id KDF for deriving keys from passwords  
- Secure streaming encryption for large files  
- Telegram-specific encryption utilities (text, files, binary)  
- Professional Exception Handling  

---

## 🔹 Installation

```bash
pip install gbkomi
