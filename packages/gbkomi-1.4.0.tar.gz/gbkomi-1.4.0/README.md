# gbkomi v1.4.0

**gbkomi** is a high-security Python library for encryption, hashing, secure database storage, and Telegram bot token management. Designed for both small and large projects, it provides **industrial-strength encryption** and is tailored for **Telegram bots**.  

---

## 🔹 Key Features

1. **Context-aware Message Encryption**
   - Encrypt messages with additional metadata like `chat_id`, `message_id`, `timestamp`.
   - Prevents replay attacks and ensures message security per context.

2. **Streaming Secure File Encryption**
   - Encrypt and decrypt large files chunk-by-chunk without loading the entire file into memory.
   - Supports files >100MB efficiently.

3. **Secure Database Layer**
   - Store all database records securely with AES-256-GCM and HMAC verification.
   - Works with SQLite, PostgreSQL, MySQL.
   - Tamper-proof and safe even if the database is compromised.

4. **Secure Telegram Bot Token Management**
   - `.gbtoken` file replaces `.env` for bot token storage.
   - Encrypted with AES-256-GCM and verified with HMAC.
   - Context-aware: tokens can be limited per project/user.

5. **Full Backward Compatibility**
   - All functions from previous versions are preserved.
   - Easy upgrade path for existing projects.

---

## 🔹 Installation

```bash
pip install gbkomi==1.4.0
🔹 Basic Usage Examples
1. Context-aware message encryption
from gbkomi import context_encrypt, context_decrypt, generate_secure_key

key = generate_secure_key()
message = b"Sensitive message"
context = {"chat_id": 12345, "message_id": 678, "timestamp": 1700000000}

cipher = context_encrypt(message, key, context)
plain = context_decrypt(cipher, key, context)
print(plain.decode())
2. Streaming file encryption
from gbkomi import encrypt_file_stream, decrypt_file_stream, generate_secure_key

key = generate_secure_key()
encrypt_file_stream("video.mp4", "video.enc", key)
decrypt_file_stream("video.enc", "video_decoded.mp4", key)
3. Secure database storage
from gbkomi import db_encrypt, db_decrypt, generate_secure_key

key = generate_secure_key()
data = {"balance": 1000, "settings": {"theme": "dark"}}

cipher = db_encrypt(data, key)
plain = db_decrypt(cipher, key)
print(plain)
4. Secure Telegram bot token management
from gbkomi import gbtoken_create, gbtoken_read, generate_secure_key

key = generate_secure_key()
gbtoken_create(".gbtoken", key, {"telegram_bot_token": "123456:ABC-DEF"})

tokens = gbtoken_read(".gbtoken", key)
bot_token = tokens["telegram_bot_token"]
print(bot_token)
🔹 Supported Python Versions
Python 3.8+

Tested on 3.11