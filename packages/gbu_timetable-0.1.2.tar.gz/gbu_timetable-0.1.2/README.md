# 📅 GBU Timetable CLI

A **terminal-based interactive timetable viewer** for **Gautam Buddha University**, built with Python and Rich.
Browse departments, select sections, save preferences, and view **G1/G2 lab splits** cleanly inside your terminal.

---

## ✨ Features

* 🎯 Interactive keyboard-driven CLI
* 🏫 Browse by **School → Department → Code → Section**
* 💾 Save default section (auto-load on next run)
* 🧪 Smart **G1 / G2 lab stacking** in the same period
* ⏰ Automatic **12-hour AM/PM time slots**
* 🎨 Clean, readable UI using `rich`
* ⚡ Zero configuration after first setup

---

## 📦 Installation

```bash
pip install gbu-timetable
```

> Requires **Python 3.8+**

---

## 🚀 Usage

Run directly from terminal:

```bash
timetable
```

No flags, no arguments — fully interactive.

---

## 🧭 Navigation Controls

| Key | Action                    |
| --- | ------------------------- |
| `1` | View saved timetable      |
| `2` | Browse & select section   |
| `3` | Enter section ID directly |
| `b` | Go back                   |
| `m` | Return to main menu       |
| `q` | Quit                      |

---

## 🗂️ Saved Configuration

Your selected section is stored locally at:

```
~/.timetable_cli.json
```

Example:

```json
{
  "section_id": "1278",
  "section_name": "B.Tech CSE (A)"
}
```

This allows instant access next time using **“View Saved Timetable”**.

---

## 🧪 G1 / G2 Lab Handling

When multiple entries exist in the same period:

* G1 and G2 are automatically detected
* Displayed as **stacked panels** inside the same cell
* Color-coded for quick differentiation

No manual filtering required.

---

## 🕒 Time Slot Logic

* Default start time: **08:30 AM**
* Each period: **60 minutes**
* Automatically adapts to timetable length
* Displayed in **12-hour format**

Example:

```
P3
10:30 AM – 11:30 AM
```

---

## 🌐 Data Source

Timetable data is fetched from:

```
https://samay.mygbu.in/api.php
```

Data is fetched once per run for performance and simplicity.

---

## 🧱 Project Structure

```
gbu-timetable/
│
├── timetable/
│   ├── __init__.py
│   └── cli.py
│
├── pyproject.toml
├── README.md
└── LICENSE
```

---

## 🛠️ Development Setup

```bash
git clone https://github.com/shashaaankkkkk/gbu-timetable
cd gbu-timetable
pip install -e .
```

Run locally:

```bash
timetable
```

---

## 📚 Dependencies

* `requests`
* `readchar`
* `rich`

Installed automatically via pip.

---

## 👨‍💻 Author

**Shashank Shekhar**
Full Stack Developer & CLI Tool Builder

🔗 GitHub: [https://github.com/shashaaankkkkk/](https://github.com/shashaaankkkkk/)

---

## 📄 License

MIT License — free to use, modify, and distribute.

---
