import logging
from pydantic import (
    BaseModel,
    field_validator,
)
from google.cloud import logging as cloud_logging
import re


#  Set up Google Cloud Logging
gcp_client = cloud_logging.Client()
gcp_client.setup_logging()

#  Configure the logger
logger = logging.getLogger("uvicorn")
logger.setLevel(logging.INFO)


class RequesterModel(BaseModel):
    email: str

    @field_validator("email")
    @classmethod
    def validate_email(cls, v: str) -> str:
        logger.info("validating requester email")

        # Basic email validation
        email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        if not re.match(email_pattern, v):
            logger.error("invalid email format")
            raise ValueError("invalid email format")
        
        logger.info(f"validated requester email: {v}")
        return v
