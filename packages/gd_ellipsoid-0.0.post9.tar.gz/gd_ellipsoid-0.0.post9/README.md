# [**gdellipsoid**](https://gd-ellipsoid-42bbb6.gitlabpages.inria.fr/)

Build an ellipsoidal cardiac geometry: tetrahedral mesh, endo/epicardial surfaces, transmural fibers, and a Purkinje network.

![overview](overview.png)

## Install

```bash
pip install gd-ellipsoid
```

## Docs

See [docs]([docs/index.md](https://gd-ellipsoid-42bbb6.gitlabpages.inria.fr/)) for the API and more details.
