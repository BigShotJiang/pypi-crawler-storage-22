# API Reference

Public entry points and main modules.

## Package

::: gdellipsoid

## Main pipeline

::: gdellipsoid.main
    options:
      members:
        - generate_ellipsoid
        - create_data
        - Discretisation

## Fibers

::: gdellipsoid.fibers
    options:
      members:
        - create_fibers

## Purkinje network

::: gdellipsoid.purkinje
    options:
      members:
        - create_purkinje
        - plot_purk

## Plotting

::: gdellipsoid.plot
    options:
      members:
        - plot_all

## Utilities

::: gdellipsoid.utils
    options:
      members:
        - Labels
        - N
