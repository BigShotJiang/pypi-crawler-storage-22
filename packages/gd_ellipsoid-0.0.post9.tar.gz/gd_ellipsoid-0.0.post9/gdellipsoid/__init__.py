"""Build ellipsoidal cardiac geometry: tetrahedral mesh, surfaces, fibers, Purkinje network."""

from gdellipsoid.main import generate_ellipsoid
from gdellipsoid.fibers import create_fibers
from gdellipsoid.purkinje import create_purkinje
from gdellipsoid.plot import plot_all
from pathlib import Path


def make_ellipsoid(dname: str, h: float = 2):
    out = Path(dname)
    generate_ellipsoid(out, off_screen=True, h=h)
    create_fibers(out)
    create_purkinje(out, show_plot=False)
    plot_all(out, off_screen=True)


def make_all_ellipsoids(dname: str, hs: [float] = None):
    for x in hs:
        ss = Path(dname) / f"ell_h={x}"
        ss.mkdir(exist_ok=True)
        make_ellipsoid(ss, x)


__all__ = [
    "generate_ellipsoid",
    "create_fibers",
    "create_purkinje",
    "plot_all",
    "make_ellipsoid",
    "make_all_ellipsoids",
]
