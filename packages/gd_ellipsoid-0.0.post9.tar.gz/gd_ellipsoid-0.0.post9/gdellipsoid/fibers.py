import os
import tempfile

import numpy as np
from scipy.spatial.transform import Rotation as R
import gdutils as gd
from gdmesh import Mesh, load_mesh

from gdellipsoid.skfem_lap_utils import get_transmural_info
from gdellipsoid.utils import Labels, N


def _sync_point_data_to_pv(mesh: Mesh) -> None:
    """Sync mesh.point_data to underlying pyvista for sampling/interpolation."""
    for key, values in mesh.point_data.items():
        mesh.pv_mesh.point_data[key] = np.asarray(values)


def create_fibers(out, angles=(80, -80)):
    with gd.Container(out) as ct:
        m = load_mesh(ct.tetra)

    n_points = m.points.shape[0]
    m.point_data["labels"] = np.zeros(n_points, dtype=np.float64)
    endo_epi = m.point_data[Labels.ENDOS_EPI]
    m.point_data["labels"][np.where(endo_epi == Labels.Endos_Epi.ENDO)] = 1
    m.point_data["labels"][np.where(endo_epi == Labels.Endos_Epi.EPI)] = 2

    with tempfile.NamedTemporaryFile(suffix=".vtk", delete=False) as f:
        try:
            m.save(f.name)
            res = get_transmural_info(f.name)
        finally:
            os.unlink(f.name)

    pts = res.points
    gradr = res.point_data["gradr"]
    gradr[np.where(np.isclose(pts[:, 2], pts[:, 2].max()))] = 0

    angles_rad = np.deg2rad(angles)
    fiber, sheet = [], []
    r_arr = res.point_data["r"]
    for i in range(res.points.shape[0]):
        r = r_arr[i]
        ang = angles_rad[0] * (1 - r) + r * angles_rad[1]
        r_ = N(gradr[i])
        t_ = -N(np.cross(r_, [0, 0, 1]))
        rot = R.from_rotvec(ang * r_)
        t_ = rot.apply(t_)
        fiber.append(t_)
        sheet.append(r_)

    res.point_data["fiber"] = np.array(fiber, dtype=float)
    res.point_data["sheet"] = np.array(sheet, dtype=float)

    _sync_point_data_to_pv(res)
    pv_centers = m.pv_mesh.cell_centers()
    pv_centers = pv_centers.sample(res.pv_mesh)

    n_cells = pv_centers.n_points
    vertices = np.arange(n_cells, dtype=np.int64).reshape(-1, 1)
    mcenters = Mesh(
        points=np.asarray(pv_centers.points),
        cells={"vertex": vertices},
        point_data={k: np.asarray(v) for k, v in pv_centers.point_data.items()},
    )
    with gd.Container(out) as ct:
        pv_centers.save(ct / "mesh_cell_fibers.vtk")
        fibs_np = pv_centers.point_data["fiber"]
        Mesh(fibs_np[:, :3], {}).save(ct / "fibs_tetra.obj")
        

    return res, mcenters
