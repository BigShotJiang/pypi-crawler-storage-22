import logging
from collections import defaultdict
from typing import NamedTuple

import gdutils as gd
import numpy as np
import pyvista as pv
from gdmesh import Mesh, MmgOptions, Plotter
from vtkmodules.vtkCommonDataModel import vtkPlane
from vtkmodules.vtkCommonTransforms import vtkTransform
from vtkmodules.vtkFiltersCore import (
    vtkCleanPolyData,
    vtkClipPolyData,
    vtkConnectivityFilter,
    vtkTriangleFilter,
)
from vtkmodules.vtkFiltersGeneral import vtkTransformPolyDataFilter
from vtkmodules.vtkFiltersSources import vtkSphereSource

from gdellipsoid.utils import Labels
from gdellipsoid.fibers import create_fibers
from gdellipsoid.purkinje import create_purkinje
from gdellipsoid.plot import plot_all


def _sync_point_data(mesh: Mesh) -> Mesh:
    for key, values in mesh.point_data.items():
        mesh.pv_mesh.point_data[key] = np.asarray(values)
    return mesh


def _point_mesh(points: np.ndarray, point_data: dict | None = None) -> Mesh:
    points = np.asarray(points, dtype=float).reshape(-1, 3)
    vertices = np.arange(points.shape[0], dtype=np.int64).reshape(-1, 1)
    point_data = point_data or {}
    return _sync_point_data(
        Mesh(points=points, cells={"vertex": vertices}, point_data=point_data)
    )


def _tetra_from_structured_shell(n: "Discretisation", nr: int = 13) -> Mesh:
    nu, nv = n.nu, n.nv
    r_vals = np.linspace(0.0, 1.0, nr)
    points = []
    labels = []

    def node_idx(ir: int, iu: int, iv: int) -> int:
        return (ir * nu + iu) * nv + iv

    # Build a smooth parametric shell exactly matching ellipsoid dimensions.
    for ir, r in enumerate(r_vals):
        rs = 7.0 + 3.0 * r
        rl = 17.0 + 3.0 * r
        u_min = -np.pi
        u_max = -np.arccos(5.0 / rl)
        u_vals = np.linspace(u_min, u_max, nu)
        v_vals = np.linspace(-np.pi, np.pi, nv, endpoint=False)
        for iu, u in enumerate(u_vals):
            su, cu = np.sin(u), np.cos(u)
            for iv, v in enumerate(v_vals):
                cv, sv = np.cos(v), np.sin(v)
                points.append([rs * su * cv, rs * su * sv, rl * cu])
                if ir == 0:
                    labels.append(Labels.Endos_Epi.ENDO)
                elif ir == nr - 1:
                    labels.append(Labels.Endos_Epi.EPI)
                else:
                    labels.append(Labels.Endos_Epi.MYO)

    points = np.asarray(points, dtype=float)
    labels = np.asarray(labels, dtype=np.int8)

    # Split each structured hexa cell into 6 tetra.
    tets = []
    for ir in range(nr - 1):
        for iu in range(nu - 1):
            for iv in range(nv):
                ivn = (iv + 1) % nv
                a = node_idx(ir, iu, iv)
                b = node_idx(ir + 1, iu, iv)
                c = node_idx(ir + 1, iu + 1, iv)
                d = node_idx(ir, iu + 1, iv)
                e = node_idx(ir, iu, ivn)
                f = node_idx(ir + 1, iu, ivn)
                g = node_idx(ir + 1, iu + 1, ivn)
                h = node_idx(ir, iu + 1, ivn)
                tets.extend(
                    [
                        (a, b, c, g),
                        (a, c, d, g),
                        (a, d, h, g),
                        (a, h, e, g),
                        (a, e, f, g),
                        (a, f, b, g),
                    ]
                )

    tets = np.asarray(tets, dtype=np.int64)

    # Merge duplicate points (e.g. south pole u=-pi gives same (0,0,-rl) for all v).
    decimals = 10
    rounded = np.round(points, decimals=decimals)
    _, unique_idx, old_to_new = np.unique(
        rounded.view(rounded.dtype.descr * 3),
        axis=0,
        return_index=True,
        return_inverse=True,
    )
    old_to_new = old_to_new.astype(np.int64)
    points = points[unique_idx]
    labels = labels[unique_idx]
    tets = old_to_new[tets]

    # Drop tets that became degenerate (repeated vertex indices).
    valid_cell = np.array([len(np.unique(t)) == 4 for t in tets])
    tets = tets[valid_cell]

    # Fix orientation (positive volume) and drop any remaining degenerate tets.
    p0 = points[tets[:, 0]]
    p1 = points[tets[:, 1]]
    p2 = points[tets[:, 2]]
    p3 = points[tets[:, 3]]
    vol6 = np.einsum("ij,ij->i", np.cross(p1 - p0, p2 - p0), p3 - p0)
    neg = vol6 < 0
    if np.any(neg):
        tets[neg, 1], tets[neg, 2] = tets[neg, 2].copy(), tets[neg, 1].copy()
        vol6[neg] = -vol6[neg]
    keep = vol6 > 1e-14
    tets = tets[keep]

    return _sync_point_data(
        Mesh(
            points=points,
            cells={"tetra": tets},
            point_data={Labels.ENDOS_EPI: labels},
        )
    )


def _remesh_tetra_volume(mesh: Mesh, h: float = 2.0) -> Mesh:
    # Target edge length h everywhere (strict size map).
    opts = MmgOptions(hmin=h, hmax=h, hausd=0.1, hgrad=1.05)
    remeshed = mesh.remesh_volume(mmg_args=opts)
    if "tetra" not in remeshed.cells:
        raise RuntimeError("Volume remeshing returned no tetra cells.")
    tetra_only = Mesh(points=remeshed.points, cells={"tetra": remeshed.cells["tetra"]})
    return tetra_only


def _label_tetra_points(tetra: Mesh, endo: Mesh, epi: Mesh) -> Mesh:
    labels = np.full(tetra.points.shape[0], Labels.Endos_Epi.MYO, dtype=np.int8)
    boundary = tetra.pv_mesh.extract_surface(pass_pointid=True)
    if "vtkOriginalPointIds" in boundary.point_data:
        boundary_ids = np.unique(boundary.point_data["vtkOriginalPointIds"]).astype(
            np.int64
        )
    else:
        boundary_ids = np.array(
            [tetra.closestPoint(p).idx for p in boundary.points], dtype=np.int64
        )

    endo.buildPointLocator()
    epi.buildPointLocator()
    for idx in boundary_ids:
        pt = tetra.points[int(idx)]
        d_endo = float(np.linalg.norm(endo.closestPoint(pt).coord - pt))
        d_epi = float(np.linalg.norm(epi.closestPoint(pt).coord - pt))
        labels[int(idx)] = (
            Labels.Endos_Epi.ENDO if d_endo <= d_epi else Labels.Endos_Epi.EPI
        )

    point_data = dict(tetra.point_data)
    point_data[Labels.ENDOS_EPI] = labels
    return _sync_point_data(
        Mesh(
            points=tetra.points,
            cells=tetra.cells,
            point_data=point_data,
            cell_data=tetra.cell_data,
        )
    )


def create_data(off_screen: bool = False, h: float = 2.0):
    n = Discretisation(31, 31)
    # Ellipsoid dimensions (kept unchanged)
    m1 = ell([7, 7, 17], n)
    m2 = ell([10, 10, 20], n)
    mf = merge(m1, m2)

    mmg = MmgOptions(hmin=1.0, hmax=2.0, hausd=0.01, hgrad=1)
    m1 = m1.remesh_surface(mmg_args=mmg)
    m2 = m2.remesh_surface(mmg_args=mmg)

    mt = _tetra_from_structured_shell(n, nr=13)
    mt = _remesh_tetra_volume(mt, h=h)
    mt = _label_tetra_points(mt, m1, m2)

    layers, labels = [], defaultdict(list)
    nu = 10
    for r in (0.1, 0.5, 0.9):
        for i, _iu in enumerate(range(nu)):
            u1 = -np.pi
            u2 = -np.arccos(5 / (17 + 3 * r))
            u = u1 + (u2 - u1) / nu * (i + 1) * 0.95
            layers.append(get_pts_r(r, u, 0))
            labels["r"].append(r)
            labels["u"].append(u)
            labels["v"].append(0)
            labels["group"].append(0)

            v = np.pi / 10
            layers.append(get_pts_r(r, u, v))
            labels["r"].append(r)
            labels["u"].append(u)
            labels["v"].append(v)
            labels["group"].append(1)

    r, v = 0.5, 0
    for u in np.linspace(-np.pi, -np.arccos(5 / (17 + 3 * r)), 30):
        layers.append(get_pts_r(r, u, v))
        labels["r"].append(r)
        labels["u"].append(u)
        labels["v"].append(v)
        labels["group"].append(2)

    u = -np.pi
    for r in (0, 1):
        layers.append(get_pts_r(r, u, v))
        labels["r"].append(r)
        labels["u"].append(u)
        labels["v"].append(v)
        labels["group"].append(3)

    mfp_pts = np.vstack(layers)
    mfp = _point_mesh(
        mfp_pts,
        point_data={
            "r": np.asarray(labels["r"], dtype=float),
            "u": np.asarray(labels["u"], dtype=float),
            "v": np.asarray(labels["v"], dtype=float),
            "group": np.asarray(labels["group"], dtype=np.int8),
        },
    )

    ring_mask = (mf.points[:, 2] >= 4.95) & (mf.points[:, 2] <= 10.0)
    mrings = _point_mesh(mf.points[ring_mask])

    # Only plot if not in offscreen mode (plotting causes segfaults in headless CI)
    if not off_screen:
        with Plotter(off_screen=False) as p:
            p.add_mesh(mt, scalars=Labels.ENDOS_EPI)

    return {
        "regular_surf": mf,
        "points": mfp,
        "tetra": mt,
        "rings": mrings,
        "endo": m1,
        "epi": m2,
    }


class Discretisation(NamedTuple):
    nu: int
    nv: int


# def ell(radiuses, n: Discretisation) -> Mesh:
#     ellipsoid = vtkParametricEllipsoid()
#     ellipsoid.SetXRadius(radiuses[0])
#     ellipsoid.SetYRadius(radiuses[1])
#     ellipsoid.SetZRadius(radiuses[2])
#     ellipsoid.JoinUOn()

#     source = vtkParametricFunctionSource()
#     source.SetUResolution(2 * n.nu)
#     source.SetVResolution(2 * n.nv)
#     source.SetParametricFunction(ellipsoid)
#     source.Update()

#     plane = vtkPlane()
#     plane.SetNormal(0, 0, -1)
#     plane.SetOrigin(0, 0, 5)

#     clip = vtkClipPolyData()
#     clip.SetClipFunction(plane)
#     clip.SetInputData(source.GetOutput())
#     clip.GenerateClippedOutputOff()
#     clip.Update()
#     clipped_endo = clip.GetOutput(0)

#     conn = vtkConnectivityFilter()
#     conn.SetInputConnection(clip.GetOutputPort())
#     conn.SetExtractionModeToLargestRegion()
#     conn.Update()

#     tri = vtkTriangleFilter()
#     tri.SetInputConnection(conn.GetOutputPort())
#     tri.Update()

#     clean = vtkCleanPolyData()
#     clean.SetInputConnection(tri.GetOutputPort())
#     clean.PointMergingOn()
#     clean.Update()

#     clipped_endo = clean.GetOutput()

#     m = Mesh(clipped_endo)
#     # m.TriangleFilter()
#     # m.Delaunay3D()
#     # m.make_manifold()
#     # m.plot()
#     # tris = m.cells.as_np()
#     # tris_top = np.all(np.isclose(m.pts[tris, 2], 5), axis=1)
#     # m.addCellData(tris_top.astype(float), "z")
#     # m.threshold((0, 0.1), "z", method="cell")
#     # m.triangulate(m.mmg_options(hmin=0.4, hmax=0.4, nr=False))
#     # print(m)
#     m.plot()
#     e1 = m.get_boundary_edges()[0]
#     breakpoint()
#     return m


def ell(radiuses, n: Discretisation) -> Mesh:
    rx, ry, rz = radiuses

    sphere = vtkSphereSource()
    sphere.SetRadius(1)
    sphere.SetThetaResolution(n.nu)
    sphere.SetPhiResolution(n.nv)
    sphere.Update()

    transform = vtkTransform()
    transform.Scale(rx, ry, rz)

    tf = vtkTransformPolyDataFilter()
    tf.SetTransform(transform)
    tf.SetInputConnection(sphere.GetOutputPort())
    tf.Update()

    ellipsoid_poly = tf.GetOutput()

    plane = vtkPlane()
    plane.SetNormal(0, 0, -1)
    plane.SetOrigin(0, 0, 5)

    clip = vtkClipPolyData()
    clip.SetClipFunction(plane)
    clip.SetInputData(ellipsoid_poly)
    clip.GenerateClippedOutputOff()
    clip.Update()

    conn = vtkConnectivityFilter()
    conn.SetInputConnection(clip.GetOutputPort())
    conn.SetExtractionModeToLargestRegion()
    conn.Update()

    tri = vtkTriangleFilter()
    tri.SetInputConnection(conn.GetOutputPort())
    tri.Update()

    clean = vtkCleanPolyData()
    clean.SetInputConnection(tri.GetOutputPort())
    clean.PointMergingOn()
    clean.Update()

    clipped = clean.GetOutput()

    poly = pv.wrap(clipped).triangulate().clean()
    return Mesh.triangle_faces_from_pv(poly)


def get_pts(k, n: Discretisation):
    rs, rl = (7, 17) if k == "endo" else (10, 20)

    def f(u, v):
        return np.array(
            [rs * np.sin(u) * np.cos(v), rs * np.sin(u) * np.sin(v), rl * np.cos(u)]
        )

    pts = []
    for u in np.linspace(-np.pi, -np.arccos(5 / rl), n.nu):
        for v in np.linspace(-np.pi, np.pi, n.nv):
            pts.append(f(u, v))
    return pts


def get_pts_r(r, u, v):
    return np.array(
        [
            (7 + 3 * r) * np.sin(u) * np.cos(v),
            (7 + 3 * r) * np.sin(u) * np.sin(v),
            (17 + 3 * r) * np.cos(u),
        ]
    )


def all_top(pts, ids):
    for x in ids:
        if pts[x, 2] < 5:
            return False
    return True


def merge(m1, m2):
    def _loop_to_vertices(loop: list[list[int]]) -> list[int]:
        if not loop:
            return []
        verts = [int(loop[0][0])]
        for edge in loop:
            verts.append(int(edge[1]))
        if verts[0] == verts[-1]:
            verts.pop()
        return verts

    def _sorted_by_theta(mesh: Mesh, ids: list[int]) -> list[int]:
        if not ids:
            return ids
        pts = mesh.points[np.asarray(ids, dtype=np.int64)]
        theta = np.arctan2(pts[:, 1], pts[:, 0])
        order = np.argsort(theta)
        return [ids[int(i)] for i in order]

    def _rotate(seq: list[int], shift: int) -> list[int]:
        shift %= len(seq)
        return seq[shift:] + seq[:shift]

    n1 = m1.points.shape[0]
    points = np.vstack([m1.points, m2.points])

    tri1 = np.asarray(m1.cells["triangle"], dtype=np.int64)
    tri2 = np.asarray(m2.cells["triangle"], dtype=np.int64) + n1
    cells = [tri1, tri2]

    loops1 = m1.boundary_edges(mesh_for_ids=m1)
    loops2 = m2.boundary_edges(mesh_for_ids=m2)
    if loops1 and loops2:
        v1 = _sorted_by_theta(m1, _loop_to_vertices(loops1[0]))
        v2 = _sorted_by_theta(m2, _loop_to_vertices(loops2[0]))
        if len(v1) != len(v2):
            raise ValueError("Boundary loops between endo/epi surfaces do not match.")

        ref = m1.points[v1[0]]
        shift = int(np.argmin(np.linalg.norm(m2.points[v2] - ref, axis=1)))
        v2f = _rotate(v2, shift)
        v2r = list(reversed(v2f))
        err_f = float(np.mean(np.linalg.norm(m1.points[v1] - m2.points[v2f], axis=1)))
        err_r = float(np.mean(np.linalg.norm(m1.points[v1] - m2.points[v2r], axis=1)))
        v2a = v2f if err_f <= err_r else v2r

        bridge = []
        n = len(v1)
        for i in range(n):
            a = v1[i]
            b = v1[(i + 1) % n]
            c = v2a[i] + n1
            d = v2a[(i + 1) % n] + n1
            bridge.append((a, b, c))
            bridge.append((b, c, d))
        cells.append(np.asarray(bridge, dtype=np.int64))

    merged_triangles = np.vstack(cells)
    endos_epi = np.hstack(
        [
            np.full(n1, Labels.Endos_Epi.ENDO, dtype=np.int8),
            np.full(m2.points.shape[0], Labels.Endos_Epi.EPI, dtype=np.int8),
        ]
    )
    return _sync_point_data(
        Mesh(
            points=points,
            cells={"triangle": merged_triangles},
            point_data={Labels.ENDOS_EPI: endos_epi},
        )
    )


def _clip_mesh_at_z(mesh: Mesh, z_value: float = 0.0, keep_below: bool = True) -> Mesh:
    """Clip a mesh at a given z value.
    
    Args:
        mesh: Input mesh to clip
        z_value: Z coordinate to clip at
        keep_below: If True, keep z < z_value; if False, keep z > z_value
    
    Returns:
        Clipped mesh
    """
    # Ensure point_data is synced
    _sync_point_data(mesh)
    
    # Get the PolyData using the existing function
    poly = _mesh_to_polydata(mesh)
    
    # Clip the mesh using origin and normal directly
    # Normal points upward (0, 0, 1) to clip below, or downward (0, 0, -1) to clip above
    origin = (0, 0, z_value)
    normal = (0, 0, 1 if keep_below else -1)
    
    clipped_poly = poly.clip(origin=origin, normal=normal)#, invert=not keep_below)
    
    # Clean the clipped mesh
    clipped_poly = clipped_poly.clean()
    
    # Convert back to Mesh using triangle_faces_from_pv
    if clipped_poly.n_cells > 0:
        return Mesh.triangle_faces_from_pv(clipped_poly)
    
    # If no faces after clipping, return empty mesh
    return Mesh(points=np.empty((0, 3), dtype=float), cells={"triangle": np.empty((0, 3), dtype=np.int64)})


def _mesh_to_polydata(mesh: Mesh) -> pv.PolyData:
    """Convert Mesh to PyVista PolyData, preserving point_data and correct topology.
    
    Creates a clean PolyData from triangle cells to ensure consistent topology
    for SOFA compatibility.
    """
    # Ensure point_data is synced
    _sync_point_data(mesh)
    
    # Create PolyData directly from triangle cells to ensure clean topology
    if "triangle" in mesh.cells:
        triangles = np.asarray(mesh.cells["triangle"], dtype=np.int32)
        # Create faces array in VTK format: [n, v0, v1, v2, n, v0, v1, v2, ...]
        faces = np.empty((len(triangles), 4), dtype=np.int32)
        faces[:, 0] = 3  # Number of vertices per face
        faces[:, 1:] = triangles
        poly = pv.PolyData(mesh.points, faces=faces.ravel())
    elif isinstance(mesh.pv_mesh, pv.PolyData):
        # If already PolyData, use it but clean it to ensure consistent topology
        poly = mesh.pv_mesh.clean()
    elif isinstance(mesh.pv_mesh, pv.UnstructuredGrid):
        # Extract surface from volume mesh
        poly = mesh.pv_mesh.extract_surface().clean()
    else:
        # Fallback: create empty PolyData
        poly = pv.PolyData(mesh.points)
    
    # Copy point_data, converting integers to float for VTK compatibility
    for key, values in mesh.point_data.items():
        arr = np.asarray(values)
        if np.issubdtype(arr.dtype, np.integer):
            poly.point_data[key] = arr.astype(np.float32)
        else:
            poly.point_data[key] = arr
    
    return poly


def _convert_int_to_float(mesh: Mesh) -> Mesh:
    """Convert integer point_data arrays to float for VTK compatibility.
    
    Some VTK readers don't support integer types, so we convert
    all integer arrays to float32 to ensure compatibility.
    """
    converted_point_data = {}
    for key, values in mesh.point_data.items():
        arr = np.asarray(values)
        if np.issubdtype(arr.dtype, np.integer):
            converted_point_data[key] = arr.astype(np.float32)
        else:
            converted_point_data[key] = arr
    return _sync_point_data(
        Mesh(
            points=mesh.points,
            cells=mesh.cells,
            point_data=converted_point_data,
            cell_data=mesh.cell_data,
        )
    )


def generate_ellipsoid(out, off_screen=False, h: float = 2.0):
    meshes = create_data(off_screen=off_screen, h=h)

    with gd.Container(out) as ct:
        # Convert integer arrays to float before saving to VTK for compatibility
        # SOFA's VTK reader doesn't support integer types
        meshes["regular_surf"] = _convert_int_to_float(meshes["regular_surf"])
        meshes["tetra"] = _convert_int_to_float(meshes["tetra"])
        meshes["points"] = _convert_int_to_float(meshes["points"])
        
        meshes["regular_surf"].save(ct / "regular_surf.vtk")
        meshes["tetra"].save(ct / "tetra.vtk")
        meshes["points"].save(ct / "points.vtk")
        pv.PolyData(meshes["points"].points).save(ct / "points_obj.obj")
        pv.PolyData(meshes["rings"].points).save(ct / "rings.obj")
        # Force PolyData format for endo and epi (surface meshes) while keeping .vtk extension
        _mesh_to_polydata(meshes["endo"]).save(ct / "endo.vtk")
        _mesh_to_polydata(meshes["epi"]).save(ct / "epi.vtk")
        
        # Create clipped_endo (clipped at z=0, keep z<0)
        clipped_endo = _clip_mesh_at_z(meshes["endo"], z_value=0.0, keep_below=True)
        clipped_endo = _convert_int_to_float(clipped_endo)
        _mesh_to_polydata(clipped_endo).save(ct / "clipped_endo.vtk")


log = logging.getLogger(__name__)

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    log = gd.get_logger()

    out = gd.fPath(__file__, "out")
    generate_ellipsoid(out, off_screen=True)
    # create_fibers(out)
    # create_purkinje(out)
    # plot_all(out)