"""Plot mesh, surfaces, Purkinje network, and fibers in a single view."""

from pathlib import Path

import numpy as np
import pyvista as pv
import gdutils as gd
from gdmesh import Mesh, Plotter


def _load_optional(base, name: str):
    """Load mesh from base / name if file exists, else return None.
    VTK PolyData (e.g. endo.vtk, epi.vtk) is loaded via PyVista and converted to Mesh;
    other VTK (UnstructuredGrid) is loaded via Mesh.load (meshio).
    """
    path = base / name
    if not Path(path).exists():
        return None
    try:
        data = pv.read(str(path))
        if isinstance(data, pv.PolyData) and data.n_cells > 0:
            return Mesh.triangle_faces_from_pv(data)
    except Exception:
        pass
    return Mesh.load(path)


def _camera_flip_x(cam_pos):
    """Rotation 180° dans le plan horizontal : inverse l'axe x (caméra et focus)."""
    cam, focus, up = cam_pos
    return [(-cam[0], cam[1], cam[2]), (-focus[0], focus[1], focus[2]), up]


CAM_POS = [
    (-1.1595738243163594, 46.538819561602594, 22.50360565589066),
    (0.22252651372572285, -1.0438502611150022, -5.7394267181562935),
    (0.014201034910607768, -0.5100595903845738, 0.8600218281323959),
]


def plot_all(out, off_screen=False):
    """Plot in one image: mesh, surfaces, Purkinje, and fibers."""
    with gd.Container(out) as ct:
        # Required: tetra and at least one surface
        tetra = Mesh.load(ct / "tetra.vtk")
        regular_surf = Mesh.load(ct / "regular_surf.vtk")

        # Optional: endo, epi, points, fibers, purkinje
        endo = _load_optional(ct, "endo.vtk")
        epi = _load_optional(ct, "epi.vtk")
        points_mesh = _load_optional(ct, "points.vtk")
        purkinje = _load_optional(ct, "purkinje_mesh.vtk")
        # mesh_cell_fibers.vtk is PolyData (point cloud); load with PyVista
        mesh_cell_fibers_pv = None
        if Path(ct / "mesh_cell_fibers.vtk").exists():
            mesh_cell_fibers_pv = pv.read(str(ct / "mesh_cell_fibers.vtk"))

        with Plotter(off_screen=off_screen) as p:
            # Volume mesh: transparent or wireframe so interior is visible
            p.add_mesh(tetra, opacity=0.12, show_edges=False, color="lightgray")

            # Surfaces: combined regular surface + optional endo/epi
            p.add_mesh(regular_surf, opacity=0.5, show_edges=False, color="white")

            if endo is not None:
                p.add_mesh(endo, opacity=0.6, show_edges=False, color="coral")
            if epi is not None:
                p.add_mesh(epi, opacity=0.6, show_edges=False, color="lightblue")

            p.camera_position = CAM_POS
            p.render()
            if not off_screen:
                p.show()
            p.screenshot(ct / "surfaces_img.png")

        # Purkinje network
        if purkinje is not None:
            with Plotter(off_screen=off_screen) as p:
                p.add_mesh(endo)
                p.add_mesh(purkinje, color="red", line_width=3)

                p.camera_position = [
                    (0.6051986645911922, -0.46423570086746, 37.204488072156266),
                    (
                        -0.0003440849696247916,
                        -5.655034101526013e-05,
                        -5.999310324980369,
                    ),
                    (0.004839410606533647, -0.9999298485328891, -0.010811018359763551),
                ]
                p.render()
                if not off_screen:
                    p.show()
                p.screenshot(ct / "purkinje_img.png")

        # Fibers: vectors at cell centers (subsample for clarity)
        if (
            mesh_cell_fibers_pv is not None
            and "fiber" in mesh_cell_fibers_pv.point_data
        ):
            with Plotter(off_screen=off_screen) as p:
                p.add_mesh(tetra, opacity=0.12, show_edges=False, color="lightgray")
                if endo is not None:
                    p.add_mesh(endo, opacity=0.6, show_edges=False, color="coral")
                if epi is not None:
                    p.add_mesh(epi, opacity=0.6, show_edges=False, color="lightblue")

                pf = mesh_cell_fibers_pv
                n_pts = pf.n_points
                step = max(1, n_pts // 800)
                subsampled = pf.copy()
                subsampled.points = np.asarray(pf.points)[::step]
                for key in ("fiber", "sheet"):
                    if key in pf.point_data.keys():
                        subsampled.point_data[key] = np.asarray(pf.point_data[key])[
                            ::step
                        ]
                subsampled.set_active_vectors("fiber")
                arrows = subsampled.glyph(orient="fiber", factor=0.4, geom=pv.Arrow())
                p.add_mesh(arrows, color="darkred", opacity=0.8)

                p.camera_position = CAM_POS
                p.render()
                if not off_screen:
                    p.show()
                p.screenshot(ct / "fibers_img.png")

        # Points (group 0,1 = blue, 2 = red line, 3 = green)
        if points_mesh is not None and "group" in points_mesh.point_data:
            with Plotter(off_screen=off_screen) as p:
                p.add_mesh(tetra, opacity=0.12, show_edges=False, color="lightgray")
                pts = points_mesh.points
                grp = points_mesh.point_data["group"]
                for g, color in ((0, "blue"), (1, "blue"), (3, "green")):
                    mask = grp == g
                    if np.any(mask):
                        p.add_mesh(
                            pv.PolyData(pts[mask]),
                            color=color,
                            point_size=12,
                            render_points_as_spheres=True,
                        )
                red_mask = grp == 2
                if np.sum(red_mask) >= 2:
                    red_pts = pts[red_mask]
                    n = len(red_pts)
                    # PyVista lines: flat array [n_pts, i, j, n_pts, i, j, ...] per segment
                    lines = np.column_stack(
                        [np.full(n - 1, 2), np.arange(n - 1), np.arange(1, n)]
                    ).ravel()
                    line_mesh = pv.PolyData(red_pts, lines=lines)
                    p.add_mesh(line_mesh, color="red", line_width=5)

                p.camera_position = CAM_POS
                p.render()
                if not off_screen:
                    p.show()
                p.screenshot(ct / "points_img.png")

        with Plotter(off_screen=off_screen) as p:
            p.add_mesh(tetra)
            p.camera_position = CAM_POS
            p.render()
            if not off_screen:
                p.show()
            p.screenshot(ct / "mesh_img.png")
