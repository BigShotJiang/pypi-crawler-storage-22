import meshio
import numpy as np
import pyvista as pv
from fractal_tree import (
    generate_fractal_tree,
    FractalTreeParameters,
    Mesh as FMesh,
)
from fractal_tree.tree import FractalTreeResult
import gdutils as gd
from gdmesh import Mesh, Plotter


def plot_purk(mesh, res, show=True):
    # Skip plotting when show=False to avoid segfaults in headless CI
    if not show:
        return
    surface = Mesh(
        points=np.asarray(mesh.verts),
        cells={"triangle": np.asarray(mesh.connectivity, dtype=np.int64)},
    )
    tree = Mesh(
        points=res.nodes,
        cells={"line": np.array(res.lines, dtype=np.int64)},
    )
    with Plotter(off_screen=False) as p:
        p.add_mesh(surface, opacity=0.4, show_edges=True)
        p.add_mesh(tree, color="red", line_width=2)


def _polydata_to_meshio(endo_path):
    """Load VTK PolyData (endo.vtk) and return a meshio.Mesh; meshio cannot read POLYDATA."""
    poly = pv.read(str(endo_path))
    points = np.asarray(poly.points)
    # PyVista faces: [n, v0, v1, v2, n, v0, v1, v2, ...] for triangles
    faces = np.asarray(poly.faces)
    n_cells = poly.n_cells
    tri = np.empty((n_cells, 3), dtype=np.int64)
    off = 0
    for i in range(n_cells):
        nv = faces[off]
        off += 1
        tri[i] = faces[off : off + nv]
        off += nv
    return meshio.Mesh(points, [meshio.CellBlock("triangle", tri)])


def create_purkinje(out, show_plot=True):
    with gd.Container(out) as ct:
        endo_path = ct / "endo.vtk"
        msh = _polydata_to_meshio(endo_path)
        print(msh)
        tri_cells = next(c for c in msh.cells if c.type == "triangle")
        n_points = msh.points.shape[0]
        init_idx = min(1308, n_points - 1)
        second_idx = min(3327, n_points - 1)
        if second_idx == init_idx:
            second_idx = (init_idx + 1) % n_points
        mesh = FMesh(
            verts=msh.points,
            connectivity=tri_cells.data,
            init_node=msh.points[init_idx],
        )
        param = FractalTreeParameters(
            filename=out / "purkinje_lv",
            second_node=msh.points[second_idx],
            N_it=10,
            init_length=15,
            length=10,
            l_segment=5,
            branch_angle=np.deg2rad(30),
            repulsitivity=0.3,
            generate_fascicles=True,
            fascicles_angles=(np.deg2rad(0),),
            fascicles_length=(5,),
            save=True,
            save_paraview=True,
        )
        res: FractalTreeResult = generate_fractal_tree(mesh, param)
        print(res)
        plot_purk(mesh, res, show=show_plot)
        tree_mesh = Mesh(
            points=res.nodes,
            cells={"line": np.array(res.lines, dtype=np.int64)},
        )
        tree_mesh.save(ct / "purkinje_mesh.vtk")


if __name__ == "__main__":
    out = gd.fPath(__file__, "out")
    create_purkinje(out)