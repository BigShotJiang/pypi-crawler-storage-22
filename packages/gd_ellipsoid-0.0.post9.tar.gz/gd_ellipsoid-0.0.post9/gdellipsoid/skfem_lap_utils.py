import logging

import numpy as np
from gdmesh import Mesh

import skfem as fem
from skfem.helpers import dot, grad

log = logging.getLogger(__name__)


@fem.BilinearForm
def a(u, v, _):
    return dot(grad(u), grad(v))


@fem.LinearForm
def l(v, w):
    return 0


def get_transmural_info(fname: str) -> Mesh:
    m = Mesh.load(fname)
    log.debug("%s", m)

    n_points = m.points.shape[0]
    m.point_data["bc_mask"] = np.zeros(n_points)
    m.point_data["bc_mask"][np.where(m.point_data["labels"] == 1)] = 1
    m.point_data["bc_mask"][np.where(m.point_data["labels"] == 2)] = 2
    m.point_data["bc_values"] = np.zeros(n_points)
    m.point_data["bc_values"][np.where(m.point_data["bc_mask"] == 2)] = 1

    r1, grad_nodal = _solve(m, with_grad=True)

    m.point_data["bc_values"] = np.zeros(n_points)
    m.point_data["bc_values"][np.where(m.point_data["bc_mask"] == 1)] = 1
    r2 = _solve(m)

    thickness = 0.5 * (r1 + r2)
    result_point_data = {
        **{k: np.asarray(v).copy() for k, v in m.point_data.items()},
        "thickness": thickness,
        "r": r1,
        "gradr": grad_nodal,
    }
    return Mesh(
        points=m.points.copy(),
        cells={k: np.asarray(v).copy() for k, v in m.cells.items()},
        point_data=result_point_data,
    )


def _solve(m: Mesh, with_grad=False):
    tetra = m.cells["tetra"]
    mesh = fem.MeshTet(m.points.T, tetra.T)
    Vh = fem.Basis(mesh, fem.ElementTetP1())

    A = a.assemble(Vh)
    b = l.assemble(Vh)

    # BC
    D = Vh.get_dofs(nodes=np.where(m.point_data["bc_mask"] != 0)[0]).flatten()
    x_bc = m.point_data["bc_values"]

    # Solve
    x = fem.solve(*fem.condense(A, b, D=D, x=x_bc))

    if with_grad:
        uh = Vh.interpolate(x)  # champ scalaire aux points de quadrature
        # projeter chaque composante du gradient dans P1 (nodal)
        gx = Vh.project(uh.grad[0])  # ∂r/∂x
        gy = Vh.project(uh.grad[1])  # ∂r/∂y
        gz = Vh.project(uh.grad[2])  # ∂r/∂z
        # assembler en champ vectoriel nodal (n_nodes, 3)
        grad_nodal = np.vstack([gx, gy, gz]).T
        return x, grad_nodal
    return x

