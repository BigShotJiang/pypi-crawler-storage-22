import numpy as np


class Labels:
    ENDOS_EPI = "Endos_Epi"

    class Endos_Epi:
        LV = 1
        ENDO = LV
        EPI = 2
        MYO = 3


def N(x):
    x = np.asarray(x, float)
    n = np.linalg.norm(x, axis=-1, keepdims=True)
    return x / np.where(n == 0, 1, n)
