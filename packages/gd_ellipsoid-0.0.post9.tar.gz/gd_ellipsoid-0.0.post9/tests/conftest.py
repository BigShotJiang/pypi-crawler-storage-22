"""Pytest configuration for headless rendering in CI environments."""

import os

# Configure pyvista for headless rendering before any imports
# This must be done before pyvista/VTK modules are imported
os.environ.setdefault("PYVISTA_OFF_SCREEN", "true")
os.environ.setdefault("DISPLAY", ":99")

# Set Qt platform to offscreen if available
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
