"""Integration tests (require full pipeline: mmg remesh, etc.)."""

import numpy as np
import pyvista as pv
import pytest
from gdmesh import Mesh, load_mesh

from gdellipsoid.main import generate_ellipsoid
from gdellipsoid.fibers import create_fibers
from gdellipsoid.purkinje import create_purkinje


def _tetra_volumes(points, tets):
    """Signed volume * 6 for each tetra (same convention as main._tetra_from_structured_shell)."""
    p0 = points[tets[:, 0]]
    p1 = points[tets[:, 1]]
    p2 = points[tets[:, 2]]
    p3 = points[tets[:, 3]]
    vol6 = np.einsum("ij,ij->i", np.cross(p1 - p0, p2 - p0), p3 - p0)
    return vol6


def _assert_remeshed_ellipsoid_valid(out):
    """Load tetra.vtk and assert it is a valid tetrahedral mesh (loadable, positive volumes)."""
    m = load_mesh(out / "tetra.vtk")
    assert m.points.ndim == 2 and m.points.shape[1] == 3
    assert "tetra" in m.cells
    tets = np.asarray(m.cells["tetra"], dtype=np.int64)
    assert tets.ndim == 2 and tets.shape[1] == 4
    n_cells = tets.shape[0]
    assert n_cells > 0
    # All vertex indices in range
    assert tets.min() >= 0 and tets.max() < m.points.shape[0]
    vol6 = _tetra_volumes(m.points, tets)
    # All tetrahedra must have positive volume (valid elements)
    assert np.all(vol6 > 1e-12), f"Found {np.sum(vol6 <= 1e-12)} non-positive volume tetrahedra"
    # Sanity: total volume is reasonable (ellipsoid ~ few thousands)
    total_vol = np.sum(vol6) / 6.0
    assert total_vol > 100 and total_vol < 1e6


def _assert_purkinje_has_enough_points(out, min_points=50, min_lines=40):
    """Load purkinje_mesh.vtk and assert it has enough nodes and line segments."""
    m = Mesh.load(out / "purkinje_mesh.vtk")
    n_points = m.points.shape[0]
    assert n_points >= min_points, f"Purkinje has {n_points} points, expected at least {min_points}"
    assert "line" in m.cells
    lines = np.asarray(m.cells["line"], dtype=np.int64)
    n_lines = lines.shape[0]
    assert n_lines >= min_lines, f"Purkinje has {n_lines} line segments, expected at least {min_lines}"
    # Line connectivity: each segment references valid point indices
    assert lines.min() >= 0 and lines.max() < n_points


def _assert_fibers_well_oriented(out, min_norm=1e-6, ortho_tol=0.5, min_ortho_ratio=0.99):
    """Load mesh_cell_fibers.vtk and assert fiber/sheet exist and are well oriented (mostly orthogonal)."""
    path = out / "mesh_cell_fibers.vtk"
    assert path.exists(), "mesh_cell_fibers.vtk not found (run create_fibers)"
    mesh = pv.read(str(path))
    assert "fiber" in mesh.point_data, "Missing 'fiber' point data"
    assert "sheet" in mesh.point_data, "Missing 'sheet' point data"
    fiber = np.asarray(mesh.point_data["fiber"], dtype=float)
    sheet = np.asarray(mesh.point_data["sheet"], dtype=float)
    assert fiber.shape == sheet.shape and fiber.shape[1] == 3
    n = fiber.shape[0]
    assert n > 0
    # Cell-center interpolation may not preserve unit norm; require non-zero
    fiber_norms = np.linalg.norm(fiber, axis=1)
    sheet_norms = np.linalg.norm(sheet, axis=1)
    valid = (fiber_norms >= min_norm) & (sheet_norms >= min_norm)
    assert np.sum(valid) >= 0.9 * n, "Too many degenerate fiber/sheet vectors after interpolation"
    # Where valid, fiber and sheet should be mostly orthogonal (interpolation can create outliers)
    fiber_u = fiber / np.where(fiber_norms >= min_norm, fiber_norms, 1)[:, np.newaxis]
    sheet_u = sheet / np.where(sheet_norms >= min_norm, sheet_norms, 1)[:, np.newaxis]
    dots = np.abs(np.einsum("ij,ij->i", fiber_u, sheet_u))
    ortho_ok = dots[valid] <= ortho_tol
    ratio = np.sum(ortho_ok) / np.sum(valid)
    assert ratio >= min_ortho_ratio, (
        f"Only {ratio:.2%} of fiber/sheet pairs are orthogonal (|dot| <= {ortho_tol}), "
        f"expected >= {min_ortho_ratio:.0%}"
    )


@pytest.mark.slow
def test_generate_ellipsoid_runs_and_writes_outputs(tmp_path):
    """generate_ellipsoid runs with off_screen=True and writes expected files."""
    generate_ellipsoid(tmp_path, off_screen=True)

    assert (tmp_path / "tetra.vtk").exists()
    assert (tmp_path / "endo.vtk").exists()
    # endo (and epi) are VTK PolyData surface meshes
    endo = pv.read(str(tmp_path / "endo.vtk"))
    assert endo.n_cells > 0 and endo.points.shape[1] == 3
    assert (tmp_path / "epi.vtk").exists()
    assert (tmp_path / "regular_surf.vtk").exists()
    assert (tmp_path / "points.vtk").exists()
    assert (tmp_path / "points_obj.obj").exists()
    assert (tmp_path / "rings.obj").exists()


@pytest.mark.slow
def test_full_pipeline_validations(tmp_path):
    """Run full pipeline (ellipsoid + fibers + Purkinje) and validate outputs."""
    generate_ellipsoid(tmp_path, off_screen=True)
    create_fibers(tmp_path)
    create_purkinje(tmp_path, show_plot=False)

    _assert_remeshed_ellipsoid_valid(tmp_path)
    _assert_purkinje_has_enough_points(tmp_path)
    _assert_fibers_well_oriented(tmp_path)
