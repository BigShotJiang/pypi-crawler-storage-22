"""Tests for pure helper functions in gdellipsoid.main."""

import numpy as np
import pytest

from gdellipsoid.main import Discretisation, all_top, get_pts, get_pts_r


class TestDiscretisation:
    def test_named_tuple(self):
        n = Discretisation(5, 7)
        assert n.nu == 5
        assert n.nv == 7


class TestGetPtsR:
    """Parametric point on ellipsoid shell at (r, u, v)."""

    def test_shape(self):
        pt = get_pts_r(0.0, -np.pi / 2, 0.0)
        assert pt.shape == (3,)
        assert pt.dtype == np.float64 or pt.dtype == np.float_

    def test_endo_radius_at_r0(self):
        # r=0 -> rs=7, rl=17
        pt = get_pts_r(0.0, -np.pi / 2, 0.0)
        # u=-pi/2: sin(u)=-1, cos(u)=0 -> x=7*(-1)*cos(v), y=7*(-1)*sin(v), z=0
        np.testing.assert_allclose(pt, [-7, 0, 0], atol=1e-14)

    def test_epi_radius_at_r1(self):
        # r=1 -> rs=10, rl=20
        pt = get_pts_r(1.0, -np.pi / 2, 0.0)
        np.testing.assert_allclose(pt, [-10, 0, 0], atol=1e-14)

    def test_pole_z(self):
        # u=0 -> north pole (z positive for rl)
        pt = get_pts_r(0.5, 0.0, 0.0)
        np.testing.assert_allclose(pt[0:2], [0, 0])
        assert pt[2] == 17 + 3 * 0.5  # 18.5


class TestGetPts:
    """Grid of points on endo or epi surface."""

    def test_endo_count(self):
        n = Discretisation(4, 6)
        pts = get_pts("endo", n)
        assert isinstance(pts, list)
        assert len(pts) == n.nu * n.nv
        assert all(len(p) == 3 for p in pts)

    def test_epi_count(self):
        n = Discretisation(3, 5)
        pts = get_pts("epi", n)
        assert len(pts) == n.nu * n.nv

    def test_endo_vs_epi_radii(self):
        n = Discretisation(2, 2)
        endo = np.array(get_pts("endo", n))
        epi = np.array(get_pts("epi", n))
        r_endo = np.linalg.norm(endo[:, :2], axis=1)  # radial in xy
        r_epi = np.linalg.norm(epi[:, :2], axis=1)
        assert np.all(r_epi >= r_endo)


class TestAllTop:
    """Check if all given point indices have z >= 5."""

    def test_all_above(self):
        pts = np.array([[0, 0, 6], [1, 1, 5], [2, 2, 10]])
        assert all_top(pts, [0, 1, 2]) is True

    def test_one_below(self):
        pts = np.array([[0, 0, 6], [1, 1, 4.9]])
        assert all_top(pts, [0, 1]) is False

    def test_empty_ids(self):
        pts = np.array([[0, 0, 0]])
        assert all_top(pts, []) is True
