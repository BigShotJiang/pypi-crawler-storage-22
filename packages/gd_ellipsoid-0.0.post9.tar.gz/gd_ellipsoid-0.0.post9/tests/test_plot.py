"""Tests for gdellipsoid.plot."""

from pathlib import Path

import numpy as np
from gdmesh import Mesh

from gdellipsoid.plot import _load_optional


def test_load_optional_missing_returns_none(tmp_path):
    """When the file does not exist, _load_optional returns None."""
    assert _load_optional(tmp_path, "nonexistent.vtk") is None
    assert _load_optional(tmp_path, "endo.vtk") is None


def test_load_optional_existing_file(tmp_path):
    """When the file exists and is a valid mesh, _load_optional returns a Mesh."""
    points = np.array([[0.0, 0.0, 0.0], [1.0, 0.0, 0.0], [0.5, 1.0, 0.0]])
    cells = np.array([[0, 1, 2]], dtype=np.int64)
    mesh = Mesh(points=points, cells={"triangle": cells})
    mesh_path = tmp_path / "tri.vtk"
    mesh.save(mesh_path)

    loaded = _load_optional(tmp_path, "tri.vtk")
    assert loaded is not None
    assert loaded.points.shape == (3, 3)
    assert "triangle" in loaded.cells
    assert loaded.cells["triangle"].shape == (1, 3)
