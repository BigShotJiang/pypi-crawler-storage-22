"""Tests for gdellipsoid.utils."""

import numpy as np
import pytest

from gdellipsoid.utils import Labels, N


class TestLabels:
    """Labels and Endos_Epi constants."""

    def test_endos_epi_key(self):
        assert Labels.ENDOS_EPI == "Endos_Epi"

    def test_endo_epi_myo_values(self):
        assert Labels.Endos_Epi.ENDO == 1
        assert Labels.Endos_Epi.EPI == 2
        assert Labels.Endos_Epi.MYO == 3

    def test_lv_alias(self):
        assert Labels.Endos_Epi.LV == Labels.Endos_Epi.ENDO


class TestN:
    """Normalize vector(s) to unit length."""

    def test_single_vector(self):
        x = np.array([3.0, 4.0, 0.0])
        out = N(x)
        np.testing.assert_allclose(np.linalg.norm(out), 1.0)
        np.testing.assert_allclose(out, [0.6, 0.8, 0.0])

    def test_zero_vector_does_not_divide_by_zero(self):
        x = np.array([0.0, 0.0, 0.0])
        out = N(x)
        assert np.all(np.isfinite(out))
        np.testing.assert_array_equal(out, [0.0, 0.0, 0.0])

    def test_batch_vectors(self):
        x = np.array([[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [1.0, 1.0, 0.0]])
        out = N(x)
        norms = np.linalg.norm(out, axis=1)
        np.testing.assert_allclose(norms, [1.0, 1.0, 1.0])
        np.testing.assert_allclose(out[2], [1 / np.sqrt(2), 1 / np.sqrt(2), 0.0])

    def test_list_input(self):
        out = N([1.0, 0.0, 0.0])
        assert isinstance(out, np.ndarray)
        np.testing.assert_allclose(out, [1.0, 0.0, 0.0])
