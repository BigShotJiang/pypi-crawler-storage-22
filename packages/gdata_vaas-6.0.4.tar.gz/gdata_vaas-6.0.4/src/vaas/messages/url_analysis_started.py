from pydantic import BaseModel

class UrlAnalysisStarted(BaseModel):
    id: str