# gdscript-code-graph

Python CLI tool that analyzes GDScript (Godot Engine) codebases and produces a structured JSON graph describing files, metrics, and inter-file relationships. This is the analyzer half of a two-part system -- the companion `metrics-viewer` consumes the output JSON.

## Quick Reference

```bash
# Install (editable, with dev dependencies)
pip install -e ".[dev]"

# Run all tests
pytest tests/ -v

# Run a single test file
pytest tests/test_discovery.py -v

# Run a single test
pytest tests/test_graph.py::TestLinks::test_link_count -v

# Analyze a Godot project (output to stdout)
gdscript-code-graph analyze <project-dir>

# Analyze with file output
gdscript-code-graph analyze <project-dir> --out graph.json

# Analyze with custom repo name
gdscript-code-graph analyze <project-dir> --out graph.json --repo-name my-game

# Exclude directories from analysis (repeatable)
gdscript-code-graph analyze <project-dir> --exclude addons --exclude test

# Short flags
gdscript-code-graph analyze <project-dir> -o graph.json -e addons -e test
```

## Tech Stack

- **Language:** Python 3.11+ (modern type hints: `int | None`, `list[str]`)
- **Build system:** hatchling (PEP 517), `src/` layout
- **GDScript parsing:** `gdtoolkit>=4.0` (Lark-based AST parser)
- **CLI framework:** `click>=8.0`
- **Testing:** `pytest>=7.0`, `pytest-cov`
- **Data models:** stdlib `@dataclass` (no Pydantic)

## Architecture

The core is a linear processing pipeline. Each stage is its own module with well-defined inputs and outputs:

```
discovery.py -> parsing.py -> metrics.py -> relationships.py -> graph.py -> cli.py
```

### Pipeline Stages

1. **`discovery.py`** -- Find `project.godot`, glob `*.gd` files, compute `res://` paths. Always excludes `.godot/` directory; supports additional exclusions via `exclude_dirs` parameter (matches against any path component). Returns `ProjectFiles` dataclass.
2. **`parsing.py`** -- Parse each `.gd` file via `gdtoolkit` with `gather_metadata=True`. Returns `list[ParseResult]` (tree or error per file). One broken file never aborts the pipeline.
3. **`metrics.py`** -- Compute LOC (non-empty, non-comment lines), per-function cyclomatic complexity, Halstead volume, and maintainability index from AST. All metrics are computed per function (each `func_def` subtree): CC, LOC (from source line range via AST metadata), Halstead volume, and MI. CC is aggregated into `max_cc` (hotspot detection) and `median_cc` (typical complexity). Per-function MI is aggregated into `mi_min` (worst maintainability) and `mi_median`. File-level MI uses whole-file Halstead volume and `max_cc`. MI formula: `171 − 5.2×ln(V) − 0.23×CC − 16.2×ln(LOC)`, clamped to `[0, 171]`. Returns `FileMetrics` with aggregates and full per-function detail. CC, MI, and per-function metrics are `None`/empty if parse failed; MI is also `None` if LOC=0 or Halstead volume=0.
4. **`relationships.py`** -- Extract `extends`, `preloads`, `loads`, `typed_dependency`, and `returns` relationships from ASTs. Build class name table. Resolve class names to `res://` paths. Built-in Godot classes (e.g., `Node2D`, `Area2D`) are filtered out during resolution (class name not in the table).
5. **`graph.py`** -- Orchestrate the full pipeline. Assemble `Graph` dataclass with nodes, links (deduplicated with evidence arrays), and metadata. Serialize to JSON.
6. **`cli.py`** -- Click CLI entry point with `analyze` subcommand. Options: `--out`/`-o` (file output), `--repo-name` (override repo name), `--exclude`/`-e` (repeatable directory exclusion).

### Supporting Modules

- **`schema.py`** -- All dataclass definitions for the output graph: `Graph`, `GraphNode`, `GraphLink`, `NodeMetrics`, `FunctionMetrics`, `Evidence`, `Meta`.

## Output Schema (v1.0)

```json
{
  "schema_version": "1.0",
  "meta": {
    "repo": "my-game",
    "generated_at": "2026-02-12T19:20:00+00:00"
  },
  "nodes": [
    {
      "id": "res://actors/player.gd",
      "kind": "script",
      "language": "gdscript",
      "name": "Player",
      "metrics": {
        "loc": 420, "max_cc": 8, "median_cc": 3.0,
        "mi": 94.25, "mi_min": 78.50, "mi_median": 112.30,
        "functions": [
          { "name": "_process", "line": 10, "cc": 3, "loc": 7, "mi": 111.08 },
          { "name": "shoot", "line": 18, "cc": 1, "loc": 4, "mi": 138.52 }
        ]
      },
      "tags": []
    }
  ],
  "links": [
    {
      "source": "res://actors/player.gd",
      "target": "res://actors/character.gd",
      "kind": "extends",
      "weight": 1,
      "evidence": [{ "file": "res://actors/player.gd", "line": 1 }]
    }
  ]
}
```

### v1 Constraints

- `max_cc` and `median_cc` replace the former single `cc` field (per-function CC analysis)
- `max_cc` is the highest per-function CC in the file (int), `median_cc` is the median (float, 1 decimal)
- Files with no functions get baseline `max_cc=1`, `median_cc=1.0`
- `mi` (file-level maintainability index) is a float for valid files with code, `null` for parse errors or empty files; uses `max_cc` and whole-file Halstead volume
- `mi_min` is the lowest per-function MI (worst maintainability), `mi_median` is the median per-function MI (both float, 2 decimals); `null` if no functions have MI
- `functions` is a list of per-function detail objects (`name`, `line`, `cc`, `loc`, `mi`); empty list for parse errors and files with no functions
- Per-function MI uses per-function Halstead volume and per-function LOC (source lines within the function range)
- UI-computed thresholds (e.g. `cc_over_10`, `mi_low < 65`, `cc_p90`) can be derived from the `functions` array
- `tags` is always `[]`
- `kind` on nodes is always `"script"`
- `language` on nodes is always `"gdscript"`
- Link kinds: `"extends"`, `"preloads"`, `"loads"`, `"typed_dependency"`, `"returns"`

## Key Design Rules

- **Per-file error resilience:** One broken `.gd` file never aborts the pipeline. Parse errors produce a node with metrics from raw source but no outgoing links.
- **Deterministic output:** Files are always sorted for reproducible results.
- **`res://` paths as stable identifiers:** All node IDs and link references use Godot's `res://` path convention.
- **Evidence-based relationships:** Every link carries an `evidence` array with file and line number.
- **Link deduplication:** Links are deduplicated by `(source, target, kind)` tuple. Weight equals the occurrence count; evidence arrays are merged.
- **Node naming:** If a file declares `class_name Foo`, the node name is `"Foo"`. Otherwise, it is the filename stem (e.g., `player.gd` becomes `"player"`).

## Testing

- One test file per source module: `test_discovery.py`, `test_parsing.py`, `test_metrics.py`, `test_relationships.py`, `test_graph.py`, `test_cli.py`
- Shared fixtures in `tests/conftest.py`
- Test fixture files in `tests/fixtures/` -- a minimal synthetic Godot project with 7 `.gd` files and a `project.godot`
- Expected output from fixtures: 7 nodes, 7 links
- CLI tests use Click's `CliRunner` for isolated testing

## Project Layout

```
src/gdscript_code_graph/
    __init__.py
    cli.py              # Click CLI entry point
    discovery.py        # File discovery and res:// path computation
    graph.py            # Pipeline orchestration and JSON serialization
    metrics.py          # LOC and cyclomatic complexity computation
    parsing.py          # GDScript parsing via gdtoolkit
    relationships.py    # Relationship extraction and resolution
    schema.py           # Dataclass definitions for output schema
tests/
    conftest.py         # Shared pytest fixtures
    fixtures/           # Synthetic Godot project for testing
    test_cli.py
    test_discovery.py
    test_graph.py
    test_metrics.py
    test_parsing.py
    test_relationships.py
```
