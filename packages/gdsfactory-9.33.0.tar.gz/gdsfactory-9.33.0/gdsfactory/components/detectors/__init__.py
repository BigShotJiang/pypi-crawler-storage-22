from .detector_ge import *

__all__ = ["ge_detector_straight_si_contacts"]
