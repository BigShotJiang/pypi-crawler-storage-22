# GDSFactory+ 1.4.4

Adds powerful features such as foundry PDKs, simulations, and verification tools like
DRC and LVS.

## Documentation

- Documentation is publicly hosted at [gdsfactory.com/plus](https://gdsfactory.com/plus/)
