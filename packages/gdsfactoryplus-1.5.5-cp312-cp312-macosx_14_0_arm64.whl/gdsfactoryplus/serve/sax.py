"""SAX simulation viewer routes."""

from __future__ import annotations

from collections.abc import Iterable
from pathlib import Path
from typing import TYPE_CHECKING, Any, NoReturn, cast

import orjson
import yaml
from fastapi import HTTPException
from fastapi.responses import HTMLResponse
from jinja2 import Environment, FileSystemLoader

from .app import app

if TYPE_CHECKING:
    import networkx as nx
    import numpy as np
    import sax
    from sax.circuits import (
        patch_netlist_array_instances,
        resolve_array_instances,
    )
    from sax.netlists import netlist as into_recnet
    from sax.netlists import remove_unused_instances

    import gdsfactoryplus.core.pdk as gfp_pdk
    from gdsfactoryplus.core.database import (
        get_factory_sources_by_name,
    )
    from gdsfactoryplus.core.models import register_models
    from gdsfactoryplus.core.simulation_storage import (
        get_simulation_file_path,
        save_simulation_result,
    )
    from gdsfactoryplus.models import SimulationHyperparameters
    from gdsfactoryplus.settings import get_project_dir
else:
    from gdsfactoryplus.core.lazy import lazy_import

    nx = lazy_import("networkx")
    np = lazy_import("numpy")
    sax = lazy_import("sax")
    gfp_pdk = lazy_import("gdsfactoryplus.core.pdk")
    into_recnet = lazy_import("sax.netlists", "netlist")
    remove_unused_instances = lazy_import("sax.netlists", "remove_unused_instances")
    patch_netlist_array_instances = lazy_import(
        "sax.circuits", "patch_netlist_array_instances"
    )
    resolve_array_instances = lazy_import("sax.circuits", "resolve_array_instances")
    get_factory_sources_by_name = lazy_import(
        "gdsfactoryplus.core.database", "get_factory_sources_by_name"
    )
    register_models = lazy_import("gdsfactoryplus.core.models", "register_models")
    get_project_dir = lazy_import("gdsfactoryplus.settings", "get_project_dir")
    get_simulation_file_path = lazy_import(
        "gdsfactoryplus.core.simulation_storage", "get_simulation_file_path"
    )
    save_simulation_result = lazy_import(
        "gdsfactoryplus.core.simulation_storage", "save_simulation_result"
    )
    SimulationHyperparameters = lazy_import(
        "gdsfactoryplus.models", "SimulationHyperparameters"
    )


# Template directory and Jinja2 environment
TEMPLATES_DIR = Path(__file__).resolve().parent.parent / "assets" / "templates" / "sax"
_jinja_env = Environment(
    loader=FileSystemLoader(TEMPLATES_DIR),
    autoescape=True,
)


def _render_template(template_name: str, **kwargs: Any) -> str:
    """Render a Jinja2 template."""
    template = _jinja_env.get_template(template_name)
    return template.render(**kwargs)


def _get_model_ports(model: Any) -> list[str] | None:
    """Get the port names from a SAX model function."""
    try:
        result = model()
        ports = list(sax.get_ports(result))
        return sorted(set(ports))
    except (TypeError, ValueError, AttributeError, KeyError):
        return None


def _get_component_ports(component_name: str) -> list[str] | None:
    """Get the port names from a GDSFactory component."""
    try:
        pdk = gfp_pdk.get_pdk()
        component = pdk.get_component(component_name)
        if component and component.ports:
            return sorted(str(p.name) for p in component.ports)
    except (TypeError, ValueError, AttributeError, KeyError):
        pass
    return None


def _get_model_parameters(model: Any) -> dict[str, Any]:
    """Get the parameters from a SAX model function signature."""
    import inspect

    excluded = {"kwargs", "args", "wl", "f", "cross_section"}

    try:
        sig = inspect.signature(model)
        params = {}
        for name, param in sig.parameters.items():
            if name in excluded:
                continue
            if param.kind in (
                inspect.Parameter.VAR_POSITIONAL,
                inspect.Parameter.VAR_KEYWORD,
            ):
                continue

            if param.default is inspect.Parameter.empty:
                params[name] = None
            else:
                default = param.default
                if hasattr(default, "item"):
                    default = default.item()
                params[name] = default
    except (TypeError, ValueError):
        return {}
    else:
        return params


def _expand_probes_if_available(
    recnet: dict[str, Any], probes: dict[str, str]
) -> dict[str, Any]:
    """Expand probes in the recnet if sax supports it."""
    try:
        import sax.netlists as sax_netlists

        _expand_probes = getattr(sax_netlists, "expand_probes", None)
        if _expand_probes is None:
            return recnet
        result: dict[str, Any] = _expand_probes(recnet, probes)
    except ImportError:
        return recnet
    else:
        return result


def _get_required_models(
    netlist: dict[str, Any],
    probes: dict[str, str] | None = None,
) -> list[str]:
    """Get the list of model names required for a netlist."""
    recnet = into_recnet(netlist)
    patch_netlist_array_instances(recnet)

    if probes:
        recnet = _expand_probes_if_available(recnet, probes)

    recnet = resolve_array_instances(recnet)
    recnet = remove_unused_instances(recnet)

    g = nx.DiGraph()
    for model_name, subnetlist in recnet.items():
        g.add_node(model_name)
        for instance in subnetlist.get("instances", {}).values():
            component = instance["component"]
            g.add_node(component)
            g.add_edge(model_name, component)

    parent_node = next(iter(recnet.keys()))
    nodes = [parent_node, *nx.descendants(g, parent_node)]
    g = nx.subgraph(g, nodes).copy()

    required = [n for n, d in g.out_degree() if d == 0]
    return sorted([m for m in required if m != "_ideal_probe"])


def _get_sax_version() -> tuple[int, int, int]:
    """Get the SAX version as a tuple (major, minor, patch)."""
    try:
        version_str = sax.__version__
        parts = version_str.split(".")
        major = int(parts[0]) if len(parts) > 0 else 0
        minor = int(parts[1]) if len(parts) > 1 else 0
        patch_str = parts[2].split("+")[0].split("-")[0] if len(parts) > 2 else "0"
        patch = int(patch_str)
    except (ValueError, IndexError, AttributeError):
        return (0, 0, 0)
    else:
        return (major, minor, patch)


def _get_gdsfactory_version() -> tuple[int, int, int]:
    """Get the gdsfactory version as a tuple (major, minor, patch)."""
    try:
        import gdsfactory

        version_str = gdsfactory.__version__
        parts = version_str.split(".")
        major = int(parts[0]) if len(parts) > 0 else 0
        minor = int(parts[1]) if len(parts) > 1 else 0
        patch_str = parts[2].split("+")[0].split("-")[0] if len(parts) > 2 else "0"
        patch = int(patch_str)
    except (ValueError, IndexError, AttributeError):
        return (0, 0, 0)
    else:
        return (major, minor, patch)


def _get_netlist_kwargs(
    *,
    recursive: bool = True,
    on_multi_connect: str | None = None,
) -> dict[str, Any]:
    """Build kwargs for .get_netlist().

    The ``on_multi_connect`` parameter is only supported in gdsfactory >= 9.34.
    When supported and no explicit value is given, defaults to ``"warn"``.
    """
    kwargs: dict[str, Any] = {"recursive": recursive}
    if _get_gdsfactory_version() >= (9, 34, 0):
        kwargs["on_multi_connect"] = on_multi_connect or "warn"
    return kwargs


def _get_config_path(name: str) -> Path | None:
    """Get the config file path for a factory.

    All .sim.yml files are stored in the scripts/ directory.
    """
    project_dir = get_project_dir()
    if project_dir is None:
        return None
    scripts_dir = project_dir / "scripts"
    scripts_dir.mkdir(parents=True, exist_ok=True)
    return scripts_dir / f"{name}.sim.yml"


@app.get("/api/sax/{name}/config")
def sax_get_config(name: str) -> dict[str, Any]:
    """Load simulation configuration for a factory."""
    try:
        config_path = _get_config_path(name)
        if config_path is None or not config_path.exists():
            return {"config": None}

        config = yaml.safe_load(config_path.read_text()) or {}
        return {"config": config, "path": str(config_path)}
    except (OSError, yaml.YAMLError) as e:
        return {"detail": str(e)}


@app.post("/api/sax/{name}/config")
def sax_save_config(name: str, request: dict[str, Any]) -> dict[str, Any]:
    """Save simulation configuration for a factory."""
    try:
        config_path = _get_config_path(name)
        if config_path is None:
            return {"detail": f"Source file not found for factory '{name}'"}

        config: dict[str, Any] = {}
        if "x" in request:
            config["x"] = request["x"]
        if "options" in request:
            config["options"] = request["options"]
        if request.get("probes"):
            config["probes"] = request["probes"]
        if request.get("models"):
            config["models"] = request["models"]
        if request.get("parameters"):
            config["parameters"] = request["parameters"]

        config_path.write_text(
            yaml.dump(config, default_flow_style=False, sort_keys=False)
        )
        return {"success": True, "path": str(config_path)}
    except (OSError, yaml.YAMLError) as e:
        return {"detail": str(e)}


@app.get("/api/sax/version")
def sax_get_version() -> dict[str, Any]:
    """Get the SAX version information."""
    try:
        version = _get_sax_version()
        return {
            "version": sax.__version__,
            "major": version[0],
            "minor": version[1],
            "patch": version[2],
            "supports_probes": version >= (0, 16, 0),
            "supports_on_multi_connect": _get_gdsfactory_version() >= (9, 34, 0),
        }
    except AttributeError as e:
        return {"detail": str(e)}


def _is_netlist_source(name: str) -> bool:
    """Check if the factory source is a .pic.yml netlist file."""
    sources = get_factory_sources_by_name(name)
    if name not in sources:
        return False
    source_path = sources[name]
    return source_path.suffix == ".yml" and source_path.stem.endswith(".pic")


def _get_pic_yml_source(name: str) -> Path | None:
    """Get the .pic.yml source path for a factory, or None if not a .pic.yml."""
    sources = get_factory_sources_by_name(name)
    if name not in sources:
        return None
    source_path = sources[name]
    if source_path.suffix == ".yml" and source_path.stem.endswith(".pic"):
        return source_path
    return None


def _convert_pic_yml_to_netlist(pic_yml: dict[str, Any]) -> dict[str, Any]:
    """Convert a .pic.yml dict to SAX netlist format.

    Transforms connections and routes into nets format expected by SAX.
    """
    nets: set[tuple[str, str]] = set()

    # Extract nets from connections
    for p, q in pic_yml.get("connections", {}).items():
        nets.add((p, q))

    # Extract nets from routes
    for bundle in pic_yml.get("routes", {}).values():
        for p, q in bundle.get("links", {}).items():
            nets.add((p, q))

    # Build the netlist with only the keys SAX needs
    netlist: dict[str, Any] = {
        "instances": pic_yml.get("instances", {}),
        "ports": pic_yml.get("ports", {}),
        "nets": [{"p1": p, "p2": q} for p, q in nets],
    }

    return netlist


def get_schematic_netlist(name: str) -> dict[str, Any] | None:
    """Get a non-recursive schematic netlist from a .pic.yml file.

    Args:
        name: Name of the factory.

    Returns:
        Netlist dict with the top-level component, or None if not a .pic.yml source.
    """
    source_path = _get_pic_yml_source(name)
    if source_path is None:
        return None

    pic_yml = yaml.safe_load(source_path.read_text())
    netlist = _convert_pic_yml_to_netlist(pic_yml)

    return {name: netlist}


def get_schematic_recnet(
    name: str,
    pdk: Any | None = None,
    on_multi_connect: str | None = None,
) -> dict[str, Any] | None:
    """Get a recursive schematic netlist from .pic.yml files.

    Recursively traverses all instances and builds the complete netlist,
    loading from .pic.yml files or falling back to layout netlists.

    Args:
        name: Name of the factory.
        pdk: PDK instance to use for layout fallback. If None, gets current PDK.
        on_multi_connect: How to handle multi-connections ('ignore', 'warn', or
            'error'). Only supported with gdsfactory >= 9.34.

    Returns:
        Recursive netlist dict, or None if the top-level is not a .pic.yml source.
    """
    # Check if top-level is a .pic.yml
    if _get_pic_yml_source(name) is None:
        return None

    if pdk is None:
        pdk = gfp_pdk.get_pdk()

    recnet: dict[str, Any] = {}

    def _add_netlists(
        prev_name: str,
        prev_inst_name: str,
        component_name: str,
        **kwargs: Any,
    ) -> None:
        """Recursively add netlists for a component and its instances."""
        # Check if this component has a .pic.yml source
        source_path = _get_pic_yml_source(component_name)

        if source_path is not None:
            # Load from .pic.yml
            pic_yml = yaml.safe_load(source_path.read_text())
            recnet[component_name] = _convert_pic_yml_to_netlist(pic_yml)
        else:
            # Fall back to layout netlist
            if component_name not in pdk.cells:
                # Base component without source - skip
                return

            cell = pdk.get_component(component_name, **kwargs)
            netlist = cell.get_netlist(
                **_get_netlist_kwargs(
                    recursive=False,
                    on_multi_connect=on_multi_connect,
                )
            )

            if not netlist.get("instances"):
                # Leaf component - no instances to recurse into
                return

            # Use the actual cell name (may differ due to settings)
            actual_name = cell.name
            recnet[actual_name] = netlist

            # Update parent's instance to point to actual name
            if prev_name and prev_inst_name:
                parent_inst = recnet[prev_name]["instances"][prev_inst_name]
                parent_inst["component"] = actual_name

            component_name = actual_name

        # Recursively process instances
        instances = recnet.get(component_name, {}).get("instances", {})
        for inst_name, inst in instances.items():
            if isinstance(inst, str):
                inst = {"component": inst}
            child_component = inst["component"]
            child_settings = cast(dict[str, Any], inst.get("settings", {}))
            _add_netlists(component_name, inst_name, child_component, **child_settings)

    _add_netlists("", "", name)
    return recnet


@app.get("/sax/{name}")
def sax_viewer(name: str) -> HTMLResponse:
    """Display SAX simulation viewer for a factory."""
    from gdsfactoryplus.settings import get_settings

    settings = get_settings()
    x_spec = settings.get("sim", {}).get("x", {})
    x_name = x_spec.get("name", "wl")
    x_min = x_spec.get("min", 1.5)
    x_max = x_spec.get("max", 1.6)
    x_num = x_spec.get("num", 1000)

    if x_name == "f":
        # Settings specify frequency in GHz; convert to wavelength in μm.
        # c = 299.792458 μm·THz, and 1 GHz = 1e-3 THz.
        # Min frequency → max wavelength and vice versa.
        c = 299.792458
        wl_min = c / (x_max * 1e-3)
        wl_max = c / (x_min * 1e-3)
        is_frequency = True
    else:
        wl_min = x_min
        wl_max = x_max
        is_frequency = False

    has_netlist_source = _is_netlist_source(name)

    html = _render_template(
        "base.html",
        name=name,
        wl_min=wl_min,
        wl_max=wl_max,
        wl_num=x_num,
        is_frequency=is_frequency,
        has_netlist_source=has_netlist_source,
    )

    return HTMLResponse(html)


def _raise_not_found(name: str) -> NoReturn:
    """Raise 404 for missing factory."""
    raise HTTPException(status_code=404, detail=f"Factory '{name}' not found")


def _raise_no_netlist_source(name: str) -> NoReturn:
    """Raise 400 for missing netlist source."""
    raise HTTPException(
        status_code=400,
        detail=f"Factory '{name}' does not have a .pic.yml source",
    )


def _load_netlist_for_request(
    name: str,
    pdk: Any,
    *,
    from_netlist: bool,
    recursive: bool,
    on_multi_connect: str | None = None,
) -> dict[str, Any]:
    """Load netlist from YAML or generate from factory."""
    if from_netlist:
        if recursive:
            netlist = get_schematic_recnet(name, pdk, on_multi_connect=on_multi_connect)
        else:
            netlist = get_schematic_netlist(name)
        if netlist is None:
            _raise_no_netlist_source(name)
        return netlist

    if name not in pdk.cells:
        _raise_not_found(name)

    factory = pdk.cells[name]
    cell = factory()
    return cell.get_netlist(
        **_get_netlist_kwargs(
            recursive=recursive,
            on_multi_connect=on_multi_connect,
        )
    )


def _add_custom_ports(
    netlist: dict[str, Any],
    name: str,
    ports_config: dict[str, str],
) -> None:
    """Add custom ports to the netlist in-place."""
    top_netlist = netlist.get(name, netlist.get(next(iter(netlist.keys())), {}))
    existing_ports = dict(top_netlist.get("ports", {}))
    existing_ports.update({k: v for k, v in ports_config.items() if "," in v})
    top_netlist["ports"] = existing_ports


@app.post("/api/sax/{name}/models")
def sax_get_models(name: str, request: dict[str, Any] | None = None) -> dict[str, Any]:
    """Get required models and available PDK models for a factory."""
    try:
        register_models(reload=True)

        request = request or {}
        ports_config = request.get("ports", {})
        probes_config = request.get("probes", {})
        from_netlist = request.get("from_netlist", False)
        recursive = request.get("recursive", True)
        on_multi_connect = request.get("on_multi_connect")

        pdk = gfp_pdk.get_pdk()
        netlist = _load_netlist_for_request(
            name,
            pdk,
            from_netlist=from_netlist,
            recursive=recursive,
            on_multi_connect=on_multi_connect,
        )

        if ports_config:
            _add_custom_ports(netlist, name, ports_config)

        required = _get_required_models(netlist, probes=probes_config or None)

        pdk_models = dict(pdk.models) if hasattr(pdk, "models") and pdk.models else {}
        available = sorted(pdk_models.keys())

        models_config = {
            model_name: {
                "default": model_name if model_name in pdk_models else None,
                "selected": model_name if model_name in pdk_models else None,
                "available": model_name in pdk_models,
                "ports": None,
            }
            for model_name in required
        }

        top_netlist = netlist if not recursive else netlist[next(iter(netlist))]
        no_ports = len(top_netlist.get("ports", {})) + len(probes_config) < 2
        no_instances = len(top_netlist.get("instances", {})) == 0
        if no_ports and no_instances and not from_netlist:
            no_ports = not bool(_get_component_ports(name))
            models_config = {
                name: {
                    "default": name if name in pdk_models else None,
                    "selected": name if name in pdk_models else None,
                    "available": name in pdk_models,
                    "ports": None,
                }
            }

    except HTTPException:
        raise
    except (TypeError, ValueError, KeyError, AttributeError) as e:
        return {"detail": str(e)}
    else:
        return {
            "required": required,
            "available": available,
            "config": models_config,
            "circuit_name": name,
            "no_ports": no_ports,
        }


@app.get("/api/sax/ports/component/{component_name}")
def sax_get_component_ports(component_name: str) -> dict[str, Any]:
    """Get ports for a GDSFactory component."""
    try:
        ports = _get_component_ports(component_name)
    except (TypeError, ValueError, AttributeError) as e:
        return {"name": component_name, "ports": None, "error": str(e)}
    else:
        return {"name": component_name, "ports": ports}


@app.get("/api/sax/ports/model/{model_name}")
def sax_get_model_ports(model_name: str) -> dict[str, Any]:
    """Get ports for a SAX model."""
    try:
        pdk = gfp_pdk.get_pdk()
        pdk_models = dict(pdk.models) if hasattr(pdk, "models") and pdk.models else {}

        if model_name not in pdk_models:
            return {"name": model_name, "ports": None}

        ports = _get_model_ports(pdk_models[model_name])
    except (TypeError, ValueError, AttributeError) as e:
        return {"name": model_name, "ports": None, "error": str(e)}
    else:
        return {"name": model_name, "ports": ports}


def _get_connected_ports(subnetlist: Any) -> set[str]:
    """Collect all ports that appear in connections, nets, or port mappings."""
    connected: set[str] = set()
    for p1, p2 in subnetlist.get("connections", {}).items():
        connected.add(p1)
        connected.add(p2)
    for net in subnetlist.get("nets", []):
        connected.add(net["p1"])
        connected.add(net["p2"])
    for internal_port in subnetlist.get("ports", {}).values():
        connected.add(internal_port)
    return connected


@app.get("/api/sax/{name}/ports")
def sax_get_ports(name: str, *, on_multi_connect: str | None = None) -> dict[str, Any]:
    """Get the ports of a top-level component and dangling internal ports."""
    try:
        pdk = gfp_pdk.get_pdk()

        if name not in pdk.cells:
            _raise_not_found(name)

        factory = pdk.cells[name]
        cell = factory()
        external_ports = sorted(str(p.name) for p in cell.ports) if cell.ports else []

        netlist = cell.get_netlist(
            **_get_netlist_kwargs(
                recursive=False,
                on_multi_connect=on_multi_connect,
            )
        )
        recnet = into_recnet(netlist)
        patch_netlist_array_instances(recnet)
        recnet = resolve_array_instances(recnet)

        top_name = next(iter(recnet.keys()))
        top_netlist = recnet[top_name]

        all_instance_ports: set[str] = set()
        for inst_name, inst_info in top_netlist.get("instances", {}).items():
            ports = _get_component_ports(inst_info.get("component", ""))
            if ports:
                for port in ports:
                    all_instance_ports.add(f"{inst_name},{port}")

        dangling_ports = sorted(all_instance_ports - _get_connected_ports(top_netlist))

    except HTTPException:
        raise
    except (TypeError, ValueError, KeyError, AttributeError) as e:
        return {"detail": str(e)}
    else:
        return {
            "external": external_ports,
            "dangling": dangling_ports,
        }


@app.get("/api/sax/{name}/instances")
def sax_get_instances(
    name: str,
    *,
    from_netlist: bool = False,
    on_multi_connect: str | None = None,
) -> dict[str, Any]:
    """Get the instances in a top-level component for probing."""
    try:
        if from_netlist:
            netlist = get_schematic_netlist(name)
            if netlist is None:
                _raise_no_netlist_source(name)
        else:
            pdk = gfp_pdk.get_pdk()
            if name not in pdk.cells:
                _raise_not_found(name)
            factory = pdk.cells[name]
            cell = factory()
            netlist = cell.get_netlist(
                **_get_netlist_kwargs(
                    recursive=False,
                    on_multi_connect=on_multi_connect,
                )
            )

        recnet = into_recnet(netlist)
        patch_netlist_array_instances(recnet)
        recnet = resolve_array_instances(recnet)

        top_name = next(iter(recnet.keys()))
        top_netlist = recnet[top_name]

        instances_data = top_netlist.get("instances", {})
        instances = {}

        for inst_name, inst_info in instances_data.items():
            component_name = inst_info.get("component", "")
            ports = _get_component_ports(component_name)
            instances[inst_name] = {
                "component": component_name,
                "ports": ports,
            }

    except HTTPException:
        raise
    except (TypeError, ValueError, KeyError, AttributeError) as e:
        return {"detail": str(e)}
    else:
        return {"instances": instances}


@app.get("/api/sax/{name}/parameters")
def sax_get_parameters(
    name: str,
    *,
    recursive: bool = True,
    on_multi_connect: str | None = None,
) -> dict[str, Any]:
    """Get available parameters for a circuit simulation."""
    try:
        register_models(reload=True)
        pdk = gfp_pdk.get_pdk()

        if name not in pdk.cells:
            _raise_not_found(name)

        factory = pdk.cells[name]
        cell = factory()
        netlist = cell.get_netlist(
            **_get_netlist_kwargs(
                recursive=recursive,
                on_multi_connect=on_multi_connect,
            )
        )

        required = _get_required_models(netlist)
        pdk_models = dict(pdk.models) if hasattr(pdk, "models") and pdk.models else {}

        all_params: dict[str, dict[str, Any]] = {}
        for model_name in required:
            if model_name not in pdk_models:
                continue
            model = pdk_models[model_name]
            params = _get_model_parameters(model)
            for param_name, default in params.items():
                if param_name not in all_params:
                    all_params[param_name] = {"default": default, "models": []}
                all_params[param_name]["models"].append(model_name)
                if all_params[param_name]["default"] is None and default is not None:
                    all_params[param_name]["default"] = default

        sorted_params = dict(
            sorted(all_params.items(), key=lambda x: -len(x[1]["models"]))
        )

    except HTTPException:
        raise
    except (TypeError, ValueError, KeyError, AttributeError) as e:
        return {"detail": str(e)}
    else:
        return {
            "parameters": sorted_params,
            "required_models": required,
        }


def _build_enabled_ports_set(
    ports_config: dict[str, str],
    probes_config: dict[str, str],
) -> set[str]:
    """Build the set of enabled port names for filtering."""
    enabled: set[str] = set()
    enabled.update(ports_config.keys())
    for probe_name in probes_config:
        enabled.add(f"{probe_name}_fwd")
        enabled.add(f"{probe_name}_bwd")
    return enabled


def _serialize_sdict(
    sdict: dict[tuple[str, str], Any],
    enabled_set: set[str],
) -> dict[str, dict[str, dict[str, Iterable[float]]]]:
    """Serialize the S-dict to JSON-compatible format."""
    serialized = {}
    for (p_in, p_out), values in sdict.items():
        if enabled_set and p_in not in enabled_set and p_out not in enabled_set:
            continue
        if p_in not in serialized:
            serialized[p_in] = {}
        if (np.abs(values) < 1e-10).all():
            continue
        serialized[p_in][p_out] = {
            "real": np.asarray(values, dtype=np.complex128).real.copy(),
            "imag": np.asarray(values, dtype=np.complex128).imag.copy(),
        }
    return serialized


def _build_models_with_overrides(
    pdk: Any,
    model_overrides: dict[str, str],
) -> dict[str, Any]:
    """Build models dict with overrides applied."""
    pdk_models = dict(pdk.models) if hasattr(pdk, "models") and pdk.models else {}
    models = dict(pdk_models)
    for component, model_name in model_overrides.items():
        if model_name and model_name in pdk_models:
            models[component] = pdk_models[model_name]
    return models


def _build_hyperparameters(request: dict[str, Any]) -> SimulationHyperparameters:
    """Build SimulationHyperparameters from request."""
    return SimulationHyperparameters(
        wavelength_start=request.get("wl_min", 1.5),
        wavelength_stop=request.get("wl_max", 1.6),
        wavelength_points=request.get("wl_num", 1000),
        solver_settings={
            "models": request.get("models", {}),
            "ports": request.get("ports", {}),
            "probes": request.get("probes", {}),
            "from_netlist": request.get("from_netlist", False),
            "recursive": request.get("recursive", True),
            "ignore_impossible_connections": request.get(
                "ignore_impossible_connections", True
            ),
            **(
                {"on_multi_connect": request["on_multi_connect"]}
                if "on_multi_connect" in request
                else {}
            ),
        },
    )


def _load_netlist_and_layout(
    name: str,
    request: dict[str, Any],
    pdk: Any,
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Load the netlist and layout info for simulation."""
    layout_args = request.get("layout", {})
    from_netlist = request.get("from_netlist", False)
    recursive = request.get("recursive", True)
    on_multi_connect = request.get("on_multi_connect")

    if from_netlist:
        layout_info = dict(layout_args)
        if recursive:
            netlist = get_schematic_recnet(name, pdk, on_multi_connect=on_multi_connect)
        else:
            netlist = get_schematic_netlist(name)
        if netlist is None:
            _raise_no_netlist_source(name)
    else:
        if name not in pdk.cells:
            _raise_not_found(name)
        factory = pdk.cells[name]
        cell = factory(**layout_args)
        netlist = cell.get_netlist(
            **_get_netlist_kwargs(
                recursive=recursive,
                on_multi_connect=on_multi_connect,
            )
        )
        layout_info = {
            **cell.info.model_dump(),
            **cell.settings.model_dump(),
        }

    return netlist, layout_info


def _run_simulation(
    name: str,
    request: dict[str, Any],
) -> dict[str, Any]:
    """Core simulation logic."""
    register_models(reload=True)

    wl_min = request.get("wl_min", 1.5)
    wl_max = request.get("wl_max", 1.6)
    wl_num = request.get("wl_num", 1000)
    model_args = request.get("model", {})
    model_overrides = request.get("models", {})
    ports_config = request.get("ports", {})
    probes_config = request.get("probes", {})
    ignore_impossible = request.get("ignore_impossible_connections", True)

    speed_of_light = 299.792458
    wl = np.linspace(wl_min, wl_max, wl_num)
    f = speed_of_light / wl

    pdk = gfp_pdk.get_pdk()
    netlist, layout_info = _load_netlist_and_layout(name, request, pdk)

    if ports_config:
        _add_custom_ports(netlist, name, ports_config)

    models = _build_models_with_overrides(pdk, model_overrides)

    circuit_kwargs: dict[str, Any] = {
        "models": models,
        "ignore_impossible_connections": ignore_impossible,
    }
    if probes_config:
        circuit_kwargs["probes"] = probes_config

    recnet = into_recnet(netlist)
    call_args = {**layout_info, **model_args, "wl": wl, "f": f * 1e12}  # THz -> Hz

    if name in models:
        circuit = models[name]
        call_args = {
            k: v for k, v in call_args.items() if k in sax.get_settings(circuit)
        }
    else:
        circuit, _ = sax.circuit(cast(dict[str, Any], recnet), **circuit_kwargs)

    result = circuit(**call_args)
    sdict = sax.sdict(result)

    enabled_set = _build_enabled_ports_set(ports_config, probes_config)
    serialized = _serialize_sdict(sdict, enabled_set)

    return {
        "wavelengths": wl.tolist(),
        "sdict": serialized,
    }


def _run_simulation_and_store(
    name: str,
    request: dict[str, Any],
) -> dict[str, Any]:
    """Run simulation and store the result."""
    import time

    layout_args = request.get("layout", {})
    model_args = request.get("model", {})
    hyperparameters = _build_hyperparameters(request)

    # Always run simulation (no cache lookup)
    start_time = time.perf_counter()
    result = _unnumpy(_run_simulation(name, request))
    execution_time = time.perf_counter() - start_time

    # Store result for history
    stored = save_simulation_result(
        component_name=str(name),
        factory_name=str(name),
        component_settings=_unnumpy(layout_args),
        model_parameters=_unnumpy(model_args),
        hyperparameters=hyperparameters,
        simulation_type="sax",
        result=result["sdict"],
        wavelengths=result["wavelengths"],
        execution_time_seconds=execution_time,
        status="success",
    )

    file_path = get_simulation_file_path("sax", name, stored.simulation_id)
    return _unnumpy(
        {
            **result,
            "simulation_id": stored.simulation_id,
            "file_path": str(file_path),
        },
    )


@app.post("/api/sax/{name}/simulate")
def sax_simulate(name: str, request: dict[str, Any]) -> dict[str, Any]:
    """Run SAX simulation for a factory."""
    try:
        return _run_simulation_and_store(name, request)
    except HTTPException:
        raise
    except (TypeError, ValueError, KeyError, AttributeError) as e:
        return {"detail": str(e)}


def _unnumpy(dct: dict[str, Any]) -> dict[str, Any]:
    return orjson.loads(orjson.dumps(dct, option=orjson.OPT_SERIALIZE_NUMPY))
