"""Simulation API."""

from __future__ import annotations

import secrets
import sys
import tarfile
import tempfile
import time
import zipfile
from collections.abc import Iterable
from datetime import datetime
from enum import StrEnum
from pathlib import Path
from typing import TYPE_CHECKING, Any
from urllib.parse import unquote, urlparse

import httpx
from pydantic import BaseModel

if TYPE_CHECKING:
    from gdsfactoryplus import settings
else:
    from gdsfactoryplus.core.lazy import lazy_import

    settings = lazy_import("gdsfactoryplus.settings")

__all__ = []

TIMEOUT = 30.0


class SimStatus(StrEnum):
    """Simulation job status."""

    CREATED = "created"
    QUEUED = "queued"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


class JobDefinition(StrEnum):
    """Available job definition types."""

    MEEP = "meep"
    PALACE = "palace"
    FEMWELL = "femwell"


class JobQueue(StrEnum):
    """Available job queue priority levels."""

    LOW_PRIORITY = "low-priority"
    STANDARD = "standard"
    HIGH_PRIORITY = "high-priority"


class Job(BaseModel):
    """Simulation job data."""

    id: str
    job_name: str
    status: SimStatus
    container_image: str
    submitted_by: str
    organization_id: str
    created_at: datetime
    job_definition_revision: int
    output_size_bytes: int
    job_def_name: str
    queue_name: str | None = None
    exit_code: int | None = None
    finished_at: datetime | None = None
    started_at: datetime | None = None
    status_reason: str | None = None
    detail_reason: str | None = None
    requested_cpu: float | None = None
    requested_memory_mb: int | None = None
    download_urls: dict[str, str] | None = None


class PrepareJobResponse(BaseModel):
    """Response for job prepare request."""

    upload_url: str
    job_id: str


class OutputDownloadResponse(BaseModel):
    """Response for output download URLs."""

    total_size_bytes: int
    download_urls: dict[str, str]


class UploadFileResponse(BaseModel):
    """Response for file upload to S3."""

    key: str
    etag: str
    content_length: int


class PreJob(BaseModel):
    """Result from upload_simulation."""

    job_id: str
    job_name: str


def upload_simulation(
    path: str | Path,
    job_definition: str | JobDefinition,
    job_name: str | None = None,
    job_queue_name: str | JobQueue | None = None,
) -> PreJob:
    """Upload simulation input file and return upload result.

    Args:
        path: Path to the simulation input file
        job_definition: Job definition type
            e.g., JobDefinition.MEEP, "meep", "palace", "femwell"
        job_name: Optional custom job name
        job_queue_name: Optional job queue priority
            e.g., JobQueue.STANDARD, "low-priority", "high-priority"

    Returns:
        PreJob containing job_id and job_name
    """
    path = Path(path)
    job_definition_name = _build_job_definition_name(job_definition)
    if not job_name:
        simulator_name = (
            job_definition.value
            if isinstance(job_definition, JobDefinition)
            else job_definition
        )
        job_name = f"{simulator_name}-{secrets.token_hex(4)}"

    # Build queue name if provided
    queue_name = _build_job_queue_name(job_queue_name) if job_queue_name else None

    prepare_response = _prepare_job(
        job_name, path.name, job_definition_name, queue_name
    )
    _upload_file(prepare_response.upload_url, path)
    return PreJob(
        job_id=prepare_response.job_id,
        job_name=job_name,
    )


def start_simulation(pre_job: PreJob) -> Job:
    """Start a simulation job with the uploaded input."""
    return _submit_job(pre_job.job_id)


def wait_for_simulation(job: Job, poll_interval: float = 5.0) -> Job:
    """Wait for simulation to complete, polling at the specified interval."""
    last_len = 0
    while job.status not in (SimStatus.COMPLETED, SimStatus.FAILED):
        created = job.created_at.strftime("%H:%M:%S")
        now = datetime.now(job.created_at.tzinfo).strftime("%H:%M:%S")
        msg = f"Created: {created} | Now: {now} | Status: {job.status.value}"
        print(f"\r{msg.ljust(last_len)}", end="", flush=True)  # noqa: T201
        last_len = len(msg)
        time.sleep(poll_interval)
        job = get_job(job.id)
    created = job.created_at.strftime("%H:%M:%S")
    now = datetime.now(job.created_at.tzinfo).strftime("%H:%M:%S")
    msg = f"Created: {created} | Now: {now} | Status: {job.status.value}"
    print(f"\r{msg.ljust(last_len)}")  # noqa: T201

    return job


def download_results(
    job: Job,
    output_dir: str | Path | None = None,
    keep: Iterable[str] = (),
    skip: Iterable[str] = (),
) -> dict[str, Path]:
    """Download and extract simulation output files."""
    output_dir = Path(output_dir or job.job_name).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    # Logic for URLs remains the same
    download_urls = job.download_urls or _get_output_download_urls(job.id).download_urls

    downloaded_files: dict[str, Path] = {}

    for name, url in download_urls.items():
        if keep and name not in keep:
            continue
        if skip and name in skip:
            continue

        parsed = urlparse(url)
        filename = Path(unquote(parsed.path)).name
        archive_path = output_dir / filename

        # 1. Stream the download to disk
        _download_file(url, archive_path)

        # 2. Extract if it's a ZIP
        if _is_archive_file(archive_path):
            sys.stdout.write(f"Extracting {filename}...\n")
            # We extract into a subfolder named after the archive (.tar.gz) or directly
            # into output_dir
            # Recommendation: extract into a folder to avoid file collisions
            # we peel twice (use .stem twice) because the output will be tar.gz
            extraction_target = output_dir / Path(archive_path.stem).stem
            extraction_target.mkdir(exist_ok=True)

            with tarfile.open(archive_path, "r:gz") as tar:
                # The 'data' filter is the ultimate protection for Tar files
                tar.extractall(path=extraction_target, filter="data")

            # Optional: Remove the zip after extraction to save space
            archive_path.unlink()
            downloaded_files[name] = extraction_target
        else:
            downloaded_files[name] = archive_path

    return downloaded_files


def run_simulation(
    path: str | Path,
    job_definition: str | JobDefinition,
    output_dir: str | Path | None = None,
    job_name: str | None = None,
    job_queue_name: str | JobQueue | None = None,
    poll_interval: float = 5.0,
) -> dict[str, Path]:
    """Run a complete simulation: upload, start, wait, and download.

    Args:
        path: Path to the simulation input file
        job_definition: Job definition type
            e.g., JobDefinition.MEEP, "meep", "palace", "femwell"
        output_dir: Optional output directory for results
        job_name: Optional custom job name
        job_queue_name: Optional job queue priority
            e.g., JobQueue.STANDARD, "low-priority", "high-priority"
        poll_interval: Polling interval in seconds

    Returns:
        Dictionary mapping output names to their local paths
    """
    pre_job = upload_simulation(path, job_definition, job_name, job_queue_name)
    job = start_simulation(pre_job)
    job = wait_for_simulation(job, poll_interval)
    return download_results(job, output_dir)


def get_job(job_id: str) -> Job:
    """Get a simulation job by ID."""
    with httpx.Client(timeout=TIMEOUT) as client:
        response = client.get(
            f"{_base_url()}/job/{job_id}",
            headers=_headers(),
        )
        response.raise_for_status()
        data = response.json()
    job = Job.model_validate(data["data"])
    if job.status == SimStatus.COMPLETED:
        download_response = _get_output_download_urls(job.id)
        job.download_urls = download_response.download_urls
    return job


def _base_url() -> str:
    """Get the simulation API base URL from settings."""
    api_host = settings.get_settings()["api"]["host"]
    return f"{api_host}/api/simulation/sdk/v1"


def _headers() -> dict[str, str]:
    api_key = settings.get_settings()["api"]["key"]
    return {
        "X-Api-Key": api_key,
        "Content-Type": "application/json",
    }


def _build_job_definition_name(job_definition: str | JobDefinition) -> str:
    """Build the job definition name from the simulator type.

    Args:
        job_definition: The job definition type (e.g., "meep", "palace", "femwell")

    Returns:
        Job definition name (e.g., "meep", "palace", "femwell")
    """
    simulator = (
        job_definition.value
        if isinstance(job_definition, JobDefinition)
        else job_definition
    ).lower()
    return simulator


def _build_job_queue_name(job_queue: str | JobQueue) -> str:
    """Build the job queue name from the priority level.

    Args:
        job_queue: The job queue priority
            e.g., "low-priority", "standard", "high-priority"

    Returns:
        Job queue name (e.g., "low-priority", "standard", "high-priority")
    """
    priority = (
        job_queue.value if isinstance(job_queue, JobQueue) else job_queue
    ).lower()
    return priority


def _prepare_job(
    job_name: str,
    original_file_name: str,
    job_definition_name: str,
    job_queue_name: str | None = None,
) -> PrepareJobResponse:
    """Prepare a simulation job and get presigned upload URL."""
    payload: dict[str, Any] = {
        "job_name": job_name,
        "original_file_name": original_file_name,
        "job_definition_name": job_definition_name,
    }
    if job_queue_name:
        payload["job_queue_name"] = job_queue_name
    with httpx.Client(timeout=TIMEOUT) as client:
        response = client.post(
            f"{_base_url()}/job/prepare",
            headers=_headers(),
            json=payload,
        )
        response.raise_for_status()
        data = response.json()
        return PrepareJobResponse.model_validate(data["data"])


def _submit_job(job_id: str) -> Job:
    """Submit a simulation job for execution."""
    payload = {"job_id": job_id}
    with httpx.Client(timeout=TIMEOUT) as client:
        response = client.post(
            f"{_base_url()}/job/submit",
            headers=_headers(),
            json=payload,
        )
        response.raise_for_status()
        data = response.json()
        return Job.model_validate(data["data"])


def _get_output_download_urls(job_id: str) -> OutputDownloadResponse:
    """Get presigned download URLs for simulation job output."""
    with httpx.Client(timeout=TIMEOUT) as client:
        response = client.get(
            f"{_base_url()}/job/{job_id}/output/download-url",
            headers=_headers(),
        )
        response.raise_for_status()
        data = response.json()["data"]
        data["download_urls"] = {
            Path(url.split("?")[0]).name: url for url in data.get("download_urls", [])
        }
        return OutputDownloadResponse.model_validate(data)


def _upload_file(upload_url: str, path: str | Path) -> UploadFileResponse:
    """Upload a file to S3 using a presigned URL, zipping and streaming the content."""
    path = Path(path)
    if not path.exists():
        msg = f"Source path does not exist: {path}"
        raise FileNotFoundError(msg)

    # Use context manager for auto-cleanup of the temp file
    # This is safer than manually unlinking in 'finally'
    with tempfile.NamedTemporaryFile(suffix=".zip", delete=True) as tmp_file:
        tmp_path = Path(tmp_file.name)

        # 1. Create the Zip on disk
        with zipfile.ZipFile(tmp_path, "w", zipfile.ZIP_DEFLATED) as zip_file:
            if path.is_file():
                zip_file.write(path, path.name)
            else:
                for file_path in path.rglob("*"):
                    # Optimization: Skip sockets, pipes,
                    # and the zip itself if in the same dir
                    if file_path.is_file():
                        arcname = file_path.relative_to(path)
                        zip_file.write(file_path, arcname)

        # 2. Get file size for metadata
        content_length = tmp_path.stat().st_size

        # 3. Stream Upload using httpx
        # We open the file in binary mode and pass the file object directly
        with tmp_path.open("rb") as f, httpx.Client(timeout=TIMEOUT) as client:
            response = client.put(
                upload_url,
                content=f,  # httpx handles file-like objects as streams
                headers={
                    "Content-Type": "application/zip",
                    "Content-Length": str(content_length),  # Recommended for S3
                },
            )
            response.raise_for_status()

        # 4. Parse the key from the URL safely
        parsed = urlparse(upload_url)
        # S3 paths can be complex; this handles bucket-in-path or virtual-host styles
        key = unquote(parsed.path.lstrip("/"))

        return UploadFileResponse(
            key=key,
            etag=response.headers.get("ETag", "").strip('"'),
            content_length=content_length,
        )


def _download_file(download_url: str, path: Path) -> None:
    """Download a file using streaming to handle large payloads."""
    with httpx.stream("GET", download_url, timeout=TIMEOUT) as response:
        response.raise_for_status()
        with path.open("wb") as f:
            for chunk in response.iter_bytes(chunk_size=8192):
                f.write(chunk)


def _is_archive_file(path: Path) -> bool:
    """Returns True if the file is a ZIP or a Gzip-compressed TAR file."""
    if not path.exists():
        return False
    return tarfile.is_tarfile(path)
