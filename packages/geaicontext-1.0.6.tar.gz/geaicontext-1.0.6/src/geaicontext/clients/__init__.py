"""Client wrappers for Redis and MongoDB."""
