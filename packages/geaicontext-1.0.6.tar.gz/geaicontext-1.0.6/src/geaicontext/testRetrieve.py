"""Test script for retrieve_user_context functionality.

This module provides a simple test to verify the retrieve_user_context tool works correctly.
"""
# pylint: disable=invalid-name
# Module name testRetrieve doesn't conform to snake_case but kept for compatibility

import asyncio
from .tools.retrieve import retrieve_user_context


async def retrieve_ctx() -> None:
    """Retrieve test context from the database via the retrieve_user_context tool."""
    customer_id = "CUST-123456"

    data = await retrieve_user_context(customer_id)
    print(data)
    data = await retrieve_user_context(customer_id)
    print(data)


def main() -> None:
    """Entry point for the test script."""
    asyncio.run(retrieve_ctx())


if __name__ == "__main__":
    main()
