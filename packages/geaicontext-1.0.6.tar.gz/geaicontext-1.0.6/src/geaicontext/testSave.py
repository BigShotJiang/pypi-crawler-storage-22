"""Test script for save_user_context functionality.

This module provides a simple test to verify the save_user_context tool works correctly.
"""
# pylint: disable=invalid-name
# Module name testSave doesn't conform to snake_case but kept for compatibility

import asyncio
import random
from .tools.save import save_user_context


async def save_dict_to_mongodb() -> None:
    """Save a test dictionary to MongoDB via the save_user_context tool."""
    customer_id = "CUST-243524"

    # Dictionary to save
    my_dict = {
        "name": "John Doe",
        "age": random.randint(25, 45),
        "email": "john@example.com",
        "city": "New York"
    }
    data = await save_user_context(customer_id, my_dict)
    print(data)


def main() -> None:
    """Entry point for the test script."""
    asyncio.run(save_dict_to_mongodb())


if __name__ == "__main__":
    main()
