"""Tests for test scripts (testRetrieve.py and testSave.py)."""

import pytest
from unittest.mock import AsyncMock, patch, MagicMock


class TestTestRetrieveScript:
    """Test cases for testRetrieve.py script."""

    @pytest.mark.asyncio
    async def test_retrieve_ctx_function(self):
        """Test retrieve_ctx function calls retrieve_user_context twice."""
        from src.geaicontext.testRetrieve import retrieve_ctx
        
        mock_context = {"name": "John Doe", "age": 30}
        
        with patch(
            "src.geaicontext.testRetrieve.retrieve_user_context",
            AsyncMock(return_value=mock_context)
        ) as mock_retrieve:
            await retrieve_ctx()
            
            # Should be called twice with the same customer_id
            assert mock_retrieve.call_count == 2
            mock_retrieve.assert_any_call("CUST-123456")

    def test_main_function_runs_asyncio(self):
        """Test main function runs the async retrieve_ctx."""
        from src.geaicontext.testRetrieve import main
        
        with patch(
            "src.geaicontext.testRetrieve.asyncio.run"
        ) as mock_run:
            main()
            mock_run.assert_called_once()


class TestTestSaveScript:
    """Test cases for testSave.py script."""

    @pytest.mark.asyncio
    async def test_save_dict_to_mongodb_function(self):
        """Test save_dict_to_mongodb function calls save_user_context."""
        from src.geaicontext.testSave import save_dict_to_mongodb
        
        with patch(
            "src.geaicontext.testSave.save_user_context",
            AsyncMock(return_value=(True, "Success"))
        ) as mock_save:
            await save_dict_to_mongodb()
            
            mock_save.assert_called_once()
            # Verify customer_id
            call_args = mock_save.call_args
            assert call_args[0][0] == "CUST-243524"
            # Verify context has expected keys
            context = call_args[0][1]
            assert "name" in context
            assert "age" in context
            assert "email" in context
            assert "city" in context

    @pytest.mark.asyncio
    async def test_save_dict_context_values(self):
        """Test that save_dict_to_mongodb creates correct context structure."""
        from src.geaicontext.testSave import save_dict_to_mongodb
        
        with patch(
            "src.geaicontext.testSave.save_user_context",
            AsyncMock(return_value=(True, "Success"))
        ) as mock_save:
            await save_dict_to_mongodb()
            
            context = mock_save.call_args[0][1]
            assert context["name"] == "John Doe"
            assert context["email"] == "john@example.com"
            assert context["city"] == "New York"
            # Age is random between 25-45
            assert 25 <= context["age"] <= 45

    def test_main_function_runs_asyncio(self):
        """Test main function runs the async save_dict_to_mongodb."""
        from src.geaicontext.testSave import main
        
        with patch(
            "src.geaicontext.testSave.asyncio.run"
        ) as mock_run:
            main()
            mock_run.assert_called_once()


class TestScriptModuleImports:
    """Test that script modules can be imported without errors."""

    def test_import_test_retrieve(self):
        """Test testRetrieve module can be imported."""
        from src.geaicontext import testRetrieve
        assert hasattr(testRetrieve, "retrieve_ctx")
        assert hasattr(testRetrieve, "main")

    def test_import_test_save(self):
        """Test testSave module can be imported."""
        from src.geaicontext import testSave
        assert hasattr(testSave, "save_dict_to_mongodb")
        assert hasattr(testSave, "main")
