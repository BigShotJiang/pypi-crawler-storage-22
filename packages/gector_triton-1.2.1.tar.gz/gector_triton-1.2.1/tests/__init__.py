"""Tests for GECToR package."""
