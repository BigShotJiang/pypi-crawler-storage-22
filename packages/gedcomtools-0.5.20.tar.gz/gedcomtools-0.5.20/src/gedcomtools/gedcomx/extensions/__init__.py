from .rs10 import rsLink

