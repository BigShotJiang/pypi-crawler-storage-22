"""
Resource Share models.

Geek Cafe, LLC
MIT License. See Project Root for the license information.
"""

from .resource_share import ResourceShare

__all__ = [
    "ResourceShare",
]
