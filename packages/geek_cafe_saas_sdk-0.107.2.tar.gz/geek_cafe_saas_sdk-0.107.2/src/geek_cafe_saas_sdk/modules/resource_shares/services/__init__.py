"""
Resource Share services.

Geek Cafe, LLC
MIT License. See Project Root for the license information.
"""

from .resource_share_service import ResourceShareService

__all__ = [
    "ResourceShareService",
]
