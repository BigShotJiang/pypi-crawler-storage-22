# Summarize votes

This lambda handler will summarize votes for a given target id.  You should run this on a schedule (e.g. every hour) to keep the summaries up to date.  Run via event bridge.