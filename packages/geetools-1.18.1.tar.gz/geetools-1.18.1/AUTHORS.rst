Thanks goes to these wonderful people (`emoji key <https://allcontributors.org/docs/en/emoji-key>`_):

.. raw:: html

    <table class="table table-bordered">
      <tr>
        <!-- ALL-CONTRIBUTORS-LIST:START - Do not remove or modify this section -->
        <td align="center">
            <a href="https://github.com/fitoprincipe">
               <img src="https://github.com/fitoprincipe.png" width="70px;" alt="fitoprincipe"/><br />
               <sub><b>Rodrigo E. Principe </b></sub>
            </a>
         </td>
        <td align="center">
            <a href="https://github.com/12rambau">
               <img src="https://github.com/12rambau.png" width="70px;" alt="12rambau"/><br />
               <sub><b>Pierrick Rambaud</b></sub>
            </a>
         </td>
         <td align="center">
            <a href="https://github.com/MarcCoru">
               <img src="https://github.com/MarcCoru.png" width="70px;" alt="MarcCoru"/><br />
               <sub><b>Marc Rußwurm</b></sub>
            </a>
         </td>
        </tr>
        <tr>
         <td align="center">
            <a href="https://github.com/hubert-crea">
               <img src="https://github.com/hubert-crea.png" width="70px;" alt="hubert-crea"/><br />
               <sub><b>hubert-crea</b></sub>
            </a>
         </td>
         <td align="center">
            <a href="https://github.com/samsammurphy">
               <img src="https://github.com/samsammurphy.png" width="70px;" alt="samsammurphy"/><br />
               <sub><b>Sam Murphy</b></sub>
            </a>
         </td>
         <td align="center">
            <a href="https://github.com/lumbric">
               <img src="https://github.com/lumbric.png" width="70px;" alt="lumbric"/><br />
               <sub><b>lumbric</b></sub>
            </a>
         </td>
      </tr>
      <tr>
         <td align="center">
            <a href="https://github.com/emmanuel-ferdman">
               <img src="https://github.com/emmanuel-ferdman.png" width="70px;" alt="emmanuel-ferdman"/><br />
               <sub><b>emmanuel-ferdman</b></sub>
            </a>
         </td>
         <td align="center">
            <a href="https://github.com/framunoz">
               <img src="https://github.com/framunoz.png" width="70px;" alt="framunoz"/><br />
               <sub><b>Francisco Muñoz</b></sub>
            </a>
         </td>
        <!-- ALL-CONTRIBUTORS-LIST:END -->
      </tr>
    </table>

This project follows the `all-contributors <https://allcontributors.org>`_ specification.

Contributions of any kind are welcome!
