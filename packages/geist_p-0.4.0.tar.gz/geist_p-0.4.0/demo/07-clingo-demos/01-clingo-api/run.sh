#!/usr/bin/env bash

# ------------------------------------------------------------------------------

bash_cell 'ex1: create an ASP dataset in memory using geist.Connection and export as a Pandas data frame' << END_CELL

python3 << END_PYTHON

import geist

csv_str = """
arg1,arg2
a,b
b,c
"""

# create a Connection object
connection = geist.Connection(datastore='clingo', dataset=':memory:')
connection.create(inputfile=csv_str, inputformat="csv", isinputpath=False, config={"predicate": "friends"})

# query the dataset
res = connection.export(hasoutput=False)
# show exported data
print(f"List of data frames: {res}")

# query the dataset and show the exported facts directly
print(f"Facts:")
connection.export(hasoutput=True)

# close the connection
connection.close()

END_PYTHON

END_CELL

# ------------------------------------------------------------------------------

bash_cell 'ex2: create a ASP dataset in memory using create and export as a Pandas data frame' << END_CELL

python3 << END_PYTHON

import geist

csv_str = """
arg1,arg2
a,b
b,c
"""

# create a Connection object
conn = geist.create(datastore='clingo', dataset=':memory:', inputfile=csv_str, inputformat="csv", isinputpath=False, config={"predicate": "friends"})
connection = geist.Connection(datastore='clingo', dataset=':memory:', conn=conn)

# query the dataset
df = connection.export(hasoutput=False, config={'predicate': 'friends'})
# show exported data
print(df)

# close the connection
connection.close()

END_PYTHON

END_CELL

# ------------------------------------------------------------------------------

bash_cell 'ex3: create and store an ASP dataset using Connection and query it' << END_CELL

python3 << END_PYTHON

from geist import Connection

csv_str = """
arg1,arg2
a,b
b,c
"""

# create a Connection object
connection = Connection(datastore='clingo', dataset='ex3')
connection.create(inputfile=csv_str, inputformat="csv", isinputpath=False, config={"predicate": "friends"})

# query the dataset
res = connection.query(
    inputfile="friends(X,Z) :- friends(X, Y), friends(Y, Z).",
    isinputpath=False,
    hasoutput=False
)
print(res)

# close the connection
connection.close()

END_PYTHON

echo "Stored Geist Datasets:"
find .geistdata/ -type f | sort

END_CELL

# ------------------------------------------------------------------------------

bash_cell 'ex4: create and store an ASP dataset using create and query it' << END_CELL

python3 << END_PYTHON

import geist

csv_str = """
arg1,arg2
a,b
b,c
"""

# create an ASP dataset directly
conn = geist.create(datastore='clingo', dataset='ex4', inputfile=csv_str, inputformat='csv', isinputpath=False, config={'predicate': 'friends'})
# use the above connection to initialize a Connection object
connection = geist.Connection(datastore='clingo', dataset='ex4', conn=conn)

# query the dataset
res = connection.query(
    inputfile="friends(X,Z) :- friends(X, Y), friends(Y, Z).",
    isinputpath=False,
    hasoutput=False
)
print(res)

# close the connection
connection.close()

END_PYTHON

echo "Stored Geist Datasets:"
find .geistdata/ -type f | sort

END_CELL

# ------------------------------------------------------------------------------

bash_cell 'ex5: connect to the dataset created in ex3 and ex4 and delete it' << END_CELL

python3 << END_PYTHON

from geist import Connection

# connect to a Connection object
connection_ex3 = Connection.connect(datastore='clingo', dataset='ex3')
connection_ex4 = Connection.connect(datastore='clingo', dataset='ex4')

# close the connection and delete the connected dataset
connection_ex3.destroy()
connection_ex4.destroy()

END_PYTHON

echo "Stored Geist Datasets:"
find .geistdata/ -type f | sort

END_CELL

# ------------------------------------------------------------------------------
