# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

---

## [0.1.0] - 2026-02-16

Initial alpha release. Full CLI and MCP server for the Gemini web interface with
chat, image generation, video generation, deep research, gems management, and
multi-profile support.

### Added

#### Core Infrastructure
- **Response parser** with UTF-16 frame decoding, JSONP prefix stripping, and nested JSON extraction (`core/parser.py`)
- **RPC transport** with batchexecute and StreamGenerate for direct HTTP to Gemini API (`core/rpc.py`)
- **Auth manager** with CDP login, cookie management, and 3-layer token refresh (`core/auth.py`)
- **Profile manager** with multi-profile support and cross-product profile sharing with NotebookLM MCP (`core/profiles.py`)
- **Constants module** with RPC IDs, endpoints, model hashes, and error codes (`core/constants.py`)
- **Exception hierarchy**: `GeminiError` base with `AuthError`, `APIError`, `UsageLimitExceeded` (1037), `ModelInvalid` (1050/1052), `TemporarilyBlocked` (1060), `TimeoutError`, `ImageGenerationError`, `VideoGenerationError`, `ResearchError`, `ProfileError`
- **Pydantic data models**: `RPCPayload`, `ConversationMetadata`, `StreamResponse`, `BatchResult`, `AuthTokens`, `AuthState`
- **GeminiClient** session manager wrapping transport, auth, and parser (`core/client.py`)

#### Service Layer
- **ChatService** — send messages, stream responses, track conversation metadata
- **ImageService** — generate images via Nano Banana / Imagen, download results
- **VideoService** — generate videos via Veo 3.1, poll status, download results
- **ResearchService** — start Deep Research queries, poll progress, retrieve reports
- **GemsService** — CRUD operations for custom system prompts (Gems)

#### CLI (`gemcli`)
- **Chat command** with model selection (`-m pro/flash/thinking`), output to file (`-o`), and conversation context
- **Interactive REPL** with slash commands: `/model`, `/verify`, `/new`, `/save`, `/history`, `/help`, `/quit`
- **Image generation** command with output path support
- **Video generation** command with output path support
- **Deep Research** command with report output
- **Gems management**: `gems list`, `gems create`, `gems delete`
- **Profile management**: `profile list`, `profile create`, `profile switch`, `profile delete`, `profile sources`
- **Configuration**: `config show`, `config get`, `config set`
- **Login**: `login` (automated CDP), `login --manual` (cookie paste), `login --check` (session validation)
- **Model shortcuts**: `-m pro`, `-m flash`, `-m thinking` with configurable default model
- **Shell completion**: `--install-completion` / `--show-completion`
- **`--version` flag** for version display
- **`--ai` flag** for AI-friendly documentation output
- **Verb-first aliases**: `gemcli list gems`, `gemcli list profiles`, `gemcli list skills`, `gemcli create gem`, `gemcli delete gem`, `gemcli install skill`, `gemcli update skill`

#### MCP Server (`gemini-web-mcp`)
- **8 consolidated MCP tools**: `chat`, `image`, `video`, `research`, `gems`, `canvas` (stub), `code` (stub), `file` (stub)
- Each tool uses action-based dispatch (e.g., `image` supports `generate` and `download` actions)

#### MCP Client Setup (`gemcli setup`)
- **`gemcli setup add <client>`** — one-command MCP configuration for AI tools
- **`gemcli setup remove <client>`** — remove MCP configuration
- **`gemcli setup list`** — show configuration status across all supported clients
- Supported clients: Claude Code, Claude Desktop, Gemini CLI, Cursor, Windsurf, Cline, Antigravity, Codex

#### Skill System (`gemcli skill`)
- **`gemcli skill install <tool>`** — install skill documentation for AI tools
- **`gemcli skill uninstall <tool>`** — remove installed skills
- **`gemcli skill list`** — show installation status across all tools with version info
- **`gemcli skill update [tool]`** — update outdated skill installations
- **`gemcli skill show`** — display full skill documentation
- Supported tools: claude-code, cursor, codex, opencode, gemini-cli, antigravity, cline, openclaw, other
- Two formats: SKILL.md (directory-based with references/) and AGENTS.md (marker-based append for Codex)
- Skill documentation includes: command reference, troubleshooting guide, workflow examples
- Version tracking with automatic injection into frontmatter and HTML comments

#### Diagnostics (`gemcli doctor`)
- **Installation checks**: gemcli and gemini-web-mcp binary detection
- **Chrome checks**: platform-aware Chrome binary detection (macOS/Windows/Linux), saved profile listing
- **Configuration checks**: config directory, profile listing, NotebookLM cross-product detection
- **Authentication checks**: cookie and token validation for active profile
- **MCP client checks**: configuration status across all registered clients (including Claude Code via subprocess)
- **Skill checks**: installation status summary
- **`--verbose` mode**: Python version, platform, Chrome binary path, cookie count, auth timestamps

#### Model Switching
- **Server-confirmed model verification** — extract and verify model hash from Gemini responses
- **Updated model hashes** from live Gemini UI (Feb 2026): Fast (`56fdd199312815e2`), Thinking (`e051ce1aa80aa576`), Pro (`e6fa609c3fa255c0`)
- **Deep recursive scan** for model hash in nested response sublists
- **Legacy model hash support** for backward compatibility
- **`preview` alias** for `fast` model (backward compatibility)
- **Token Factory** (experimental) — Chrome generates BotGuard tokens, Python replays HTTP with stolen token + all browser cookies for Pro/Thinking model access
- **BrowserTransport** — CDP-based Chrome automation for model switching via browser UI

#### Authentication
- **Automated Chrome login via CDP** with profile selection
- **First-run profile setup** with NLM profile reuse option
- **Login defaults to active profile** instead of hardcoded "default"
- **Wait for user login** instead of failing immediately on missing auth
- **NLM Chrome profile directory** support for CDP login
- **Token refresh warnings** suppressed to debug level (only shows with `--verbose`)

#### Documentation
- **README.md** with installation, quick start, profile management, MCP setup, architecture
- **CLAUDE.md** developer guide with architecture, model hashes, token factory details
- **Research documentation** (12 feature docs, auth docs, RPC reference)
- **Skill documentation** (SKILL.md, AGENTS_SECTION.md, command reference, troubleshooting, workflows)

#### Testing
- **203 unit tests** across 9 test files
- Core layer tests: auth, constants, parser, profiles, rpc
- Skill system tests: tool configs, data directory, version injection, install/uninstall, CLI commands
- Token factory tests
- Parser tests using real captured Gemini response data

#### Research & Protocol Documentation
- **Master RPC reference table** (`docs/research/known-rpcs.md`)
- **Authentication flow** documentation (cookie auth, token extraction, 3-layer refresh)
- **Cross-product profiles** documentation (NLM profile sharing)
- **Feature research docs**: chat + streaming, image generation, video generation, deep research, gems, canvas, code execution, file upload, extensions, model switching
- **BotGuard token capture** via fetch/XHR interception research
- **Model switching research** — signed request tokens, browser-driven solutions

---

## [0.1.1] - 2026-02-16

### Fixed
- Resolve all ruff lint errors across entire codebase (unused imports, f-strings without placeholders, line-too-long, import sorting)
- Fix GitHub Actions workflow to use `uv sync` instead of `uv pip install --system` (Ubuntu externally managed Python)

### Added
- GitHub Actions release workflow: automated testing (Python 3.11/3.12/3.13), PyPI publish, and GitHub Release on tag push
- Published to PyPI as `gemini-web-mcp-cli`

---

## [0.1.2] - 2026-02-16

### Changed
- Move `mcp[cli]` from optional extra into core dependencies — `uv tool install gemini-web-mcp-cli` now works without any extras
- Remove unused `api` (fastapi/uvicorn) and `mcp` optional dependency groups
- Simplify `[all]` extra to only include `[dev]` tools

### Fixed
- Installation instructions in README updated to reflect simplified install

---

## [Unreleased]

### Planned
- Token Factory integration into production code (currently experimental)
- Canvas, Code Execution, and File Upload service implementations
- Service/CLI/MCP integration tests

[0.1.2]: https://github.com/jacob-bd/gemini-web-mcp-cli/releases/tag/v0.1.2
[0.1.1]: https://github.com/jacob-bd/gemini-web-mcp-cli/releases/tag/v0.1.1
[0.1.0]: https://github.com/jacob-bd/gemini-web-mcp-cli/releases/tag/v0.1.0
[Unreleased]: https://github.com/jacob-bd/gemini-web-mcp-cli/compare/v0.1.2...HEAD
