# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Overview

MCP server and CLI for the Gemini web interface (gemini.google.com). Clean-room
rebuild using protocol knowledge from gemini-webapi as reference. No code copied.

## Development Commands

```bash
# Setup
uv venv && source .venv/bin/activate
uv pip install -e ".[all]"

# Run all tests (203 tests)
pytest tests/ -v

# Run a single test file
pytest tests/test_parser.py -v

# Run a single test
pytest tests/test_parser.py::TestParseFrames::test_single_frame -v

# Lint
ruff check src/ tests/

# Lint with auto-fix
ruff check --fix src/ tests/

# Reinstall after code changes (ALWAYS clean cache first)
uv cache clean && uv pip install -e ".[all]"

# If installed as a tool, reinstall with:
uv cache clean && uv tool install --force .
```

**Ruff config:** line-length=100, target py311, selects E/F/I/W rules.
**Pytest config:** asyncio_mode="auto" (no need for @pytest.mark.asyncio).

## Architecture

```
src/gemini_web_mcp_cli/
  core/           # Transport, auth, parsing (shared foundation)
  services/       # Business logic (single source of truth)
  cli.py          # CLI (Click) — thin wrapper over services
  mcp.py          # MCP server (FastMCP) — thin wrapper over services
  setup.py        # MCP client configuration helper
  skill.py        # Skill installer for AI tools (Claude Code, Cursor, Codex, etc.)
  data/           # Skill documentation (SKILL.md, AGENTS_SECTION.md, references/)
```

All interfaces (CLI, MCP, future API) consume the same service layer. When
Gemini changes an RPC, update one service file and everything works.

### Composition Flow

```
GeminiClient (core/client.py)
  ├── ProfileManager (core/profiles.py)   — multi-profile + NLM cross-product
  ├── AuthManager (core/auth.py)          — CDP login, cookies, 3-layer token refresh
  ├── RPCTransport (core/rpc.py)          — batchexecute + StreamGenerate (Flash)
  └── Parser (core/parser.py)             — UTF-16 frame decoder, JSONP stripping

Services (services/*.py)
  ├── ChatService     — wraps client.send(), tracks ConversationMetadata
  ├── ImageService    — image generation + download
  ├── VideoService    — Veo 3.1 video generation + polling
  ├── ResearchService — Deep Research + polling
  └── GemsService     — CRUD for custom system prompts

CLI/MCP → Service → GeminiClient → RPCTransport → Gemini API
```

### Model Switching via Token Factory (KEY BREAKTHROUGH)

Model switching requires BotGuard tokens that only a real browser can generate.
The **Token Factory** approach solves this: Chrome generates BotGuard tokens,
Python sends the actual HTTP request with the stolen token + ALL browser cookies.

**Proven working (Feb 2026):** Python HTTP replay with stolen BotGuard token
returns Pro (`e6fa609c3fa255c0`) when ALL 28 browser cookies are included.
Even Python-native TLS (httpx) works — TLS fingerprinting is NOT an issue.
The critical missing piece was cookies: auth.py only stored 2 cookies, but
BotGuard validation requires the full cookie set (SID, HSID, APISID, etc.).

```
Flash (default):  Direct HTTP via RPCTransport  (no browser needed)
Pro / Thinking:   Token Factory — Chrome generates BotGuard token,
                  Python sends HTTP with token + ALL cookies
```

- **RPCTransport** (`core/rpc.py`): Direct HTTP to StreamGenerate. Fast, lightweight.
  Server ignores model header without BotGuard — always returns Flash.
- **Token Factory** (NOT YET BUILT into production code):
  1. Chrome sits on gemini.google.com (background, headless)
  2. XHR interceptor captures BotGuard token before request is sent
  3. ALL cookies grabbed via CDP `Network.getAllCookies`
  4. Python sends HTTP request with stolen token + all cookies + model header
  5. Validated in `experiments/botguard_all_cookies.py`
- **BrowserTransport** (`core/cdp.py`): Legacy approach. Controls headless Chrome
  via CDP to click UI elements. Works but heavy. Being replaced by Token Factory.

### Response Parsing (Non-Trivial)

Google uses UTF-16 length-prefixed frames. `parser.py` handles:
- JSONP prefix stripping (`)]}'` → `""`)
- UTF-16 code unit counting (BMP = 1 unit, supplementary = 2 via surrogates)
- Nested JSON extraction via safe path navigation

### Request Payload

StreamGenerate uses a 70-element `inner_req_list` array. Field purposes are
documented inline in `rpc.py::build_streamgenerate_body()`. Many fields are
reverse-engineered from the live Gemini UI.

## Model Hashes (confirmed from live UI, Feb 2026)

| UI Label   | Hash               |
|------------|-------------------|
| Fast       | 56fdd199312815e2  |
| Thinking   | e051ce1aa80aa576  |
| Pro        | e6fa609c3fa255c0  |

Direct HTTP without BotGuard token gets Flash (`fbb127bbb056c959`).
With stolen BotGuard token + ALL browser cookies, model header is respected.

## Data Models (core/models.py)

- `RPCPayload` — RPC call: rpc_id, payload JSON, identifier
- `ConversationMetadata` — Multi-turn: cid (conversation), rid (response), rcid (candidate)
- `StreamResponse` — Parsed response: metadata, candidates, model hash
- `BatchResult` — Single batchexecute result
- `AuthTokens` — snlm0e, cfb2h, fdrfje
- `AuthState` — Full auth: cookies, tokens, chrome_profile_path, last_refreshed

## Error Hierarchy (core/exceptions.py)

`GeminiError` base, with: `AuthError`, `APIError`, `UsageLimitExceeded` (1037),
`ModelInvalid` (1050/1052), `TemporarilyBlocked` (1060), `TimeoutError`,
`ImageGenerationError`, `VideoGenerationError`, `ResearchError`, `ProfileError`.

## Config Paths

- `~/.gemini-web-mcp-cli/config.json` — Active profile, default model
- `~/.gemini-web-mcp-cli/profiles/<name>/auth.json` — Per-profile auth
- Cross-product: reads `~/.notebooklm-mcp-cli/profiles/` (live, never copied)
- NLM Chrome profiles: `~/.notebooklm-mcp-cli/chrome-profiles/<name>/`

## Entry Points (pyproject.toml)

- `gemcli` → `gemini_web_mcp_cli.cli:main`
- `gemini-web-mcp` → `gemini_web_mcp_cli.mcp:main`

## Testing Patterns

- Unit tests only (no integration/live API tests)
- Tests cover core layer: auth, constants, parser, profiles, rpc
- Skill system tests: install/uninstall, version injection, CLI commands (40 tests)
- Parser tests use real captured Gemini response data

## Key Files for Resuming Work

- `experiments/botguard_all_cookies.py` — PROVEN: Token Factory works (Pro confirmed)
- `experiments/botguard_js_header_swap.py` — PROVEN: JS header swap works in browser
- `core/cdp.py` — CDP infrastructure + BrowserTransport (legacy, being replaced)
- `core/rpc.py` — RPCTransport (needs Token Factory integration for Pro/Thinking)
- `core/auth.py` — AuthManager (needs to store ALL cookies, not just 2)
- `cli.py` — Interactive chat (needs model routing)
- `services/chat.py` — ChatService (needs dual-transport logic)

### Token Factory Implementation TODO

1. Expand `AuthManager` to capture/store ALL browser cookies (28 total)
2. Build `TokenFactory` class: XHR intercept → capture BotGuard token
3. Integrate into `RPCTransport.send()`: if model != Flash, get token first
4. Wire model selection through CLI and services
