# Gemini Web MCP - Research Phase

## Overview

This directory contains the reverse-engineering research for the Gemini web interface
(gemini.google.com). The goal is to document every RPC call, endpoint, and protocol
detail needed to build the `gemini-web-mcp-cli` project.

## Reference Source

RPC knowledge extracted from [HanaokaYuzu/Gemini-API](https://github.com/HanaokaYuzu/Gemini-API)
(`gemini-webapi` on PyPI, ~2,143 stars). No code copied -- only protocol knowledge used
as reference for our clean-room rebuild.

## Research Status

### Known RPCs (from gemini-webapi)

| Feature | Status | Document |
|---------|--------|----------|
| Authentication | Documented | [auth/auth-flow.md](auth/auth-flow.md) |
| Cross-product profiles | Documented | [auth/cross-product-profiles.md](auth/cross-product-profiles.md) |
| Chat + Streaming | Documented | [features/chat.md](features/chat.md) |
| Image Generation | Documented | [features/image-generation.md](features/image-generation.md) |
| Video Generation (Veo) | Documented | [features/video-generation.md](features/video-generation.md) |
| Deep Research | Documented | [features/deep-research.md](features/deep-research.md) |
| Gems (CRUD) | Documented | [features/gems.md](features/gems.md) |
| File Upload | Documented | [features/file-upload.md](features/file-upload.md) |
| Extensions | Documented | [features/extensions.md](features/extensions.md) |
| Model Switching | Documented | [features/model-switching.md](features/model-switching.md) |

### Partially Captured (need more work)

| Feature | Status | Document |
|---------|--------|----------|
| Canvas | NOT CAPTURED | [features/canvas.md](features/canvas.md) |
| Code Execution | NOT CAPTURED | [features/code-execution.md](features/code-execution.md) |

## Capture Methodology

For missing features, use Chrome DevTools:

1. Open `gemini.google.com` in Chrome
2. Open DevTools > Network tab
3. Filter to `Fetch/XHR`
4. Perform the action in the Gemini UI
5. Right-click the request > Copy as cURL
6. Document the RPC ID, payload, and response in the feature markdown file

## Directory Structure

```
research/
  README.md                      # This file
  known-rpcs.md                  # Master RPC reference table
  auth/
    auth-flow.md                 # Cookie auth, token extraction, refresh
    cross-product-profiles.md    # Profile sharing with NotebookLM MCP
  features/
    chat.md                      # Chat + streaming protocol
    image-generation.md          # Image gen (Imagen)
    video-generation.md          # Video gen (Veo 3.1)
    deep-research.md             # Deep Research
    canvas.md                    # Canvas - TO CAPTURE
    code-execution.md            # Code execution - TO CAPTURE
    gems.md                      # Gems CRUD
    extensions.md                # Extensions (YouTube, Maps, etc.)
    file-upload.md               # File upload protocol
    model-switching.md           # Model switching via Token Factory
```
