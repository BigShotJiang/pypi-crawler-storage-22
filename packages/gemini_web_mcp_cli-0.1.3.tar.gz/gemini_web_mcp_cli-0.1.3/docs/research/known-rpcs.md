# Known RPC Reference

## Endpoints

| Name | URL | Method | Purpose |
|------|-----|--------|---------|
| INIT | `https://gemini.google.com/app` | GET | Init page, extract tokens |
| GENERATE | `https://gemini.google.com/_/BardChatUi/data/assistant.lamda.BardFrontendService/StreamGenerate` | POST | Streaming chat generation |
| BATCH_EXEC | `https://gemini.google.com/_/BardChatUi/data/batchexecute` | POST | Batch RPC execution |
| UPLOAD | `https://content-push.googleapis.com/upload` | POST | File upload |
| ROTATE_COOKIES | `https://accounts.google.com/RotateCookies` | POST | Refresh __Secure-1PSIDTS |
| GOOGLE | `https://www.google.com` | GET | Pre-fetch cookies |

## RPC IDs (batchexecute)

| RPC ID | Constant | Purpose | Payload Example |
|--------|----------|---------|-----------------|
| `MaZiqc` | LIST_CHATS | List all chat conversations | `[]` |
| `hNvQHb` | READ_CHAT | Read a specific chat | `[chat_id]` |
| `GzXR5e` | DELETE_CHAT | Delete a chat conversation | `[chat_id]` |
| `CNgdBe` | LIST_GEMS | List gems (system + custom) | `[null, 0]` (system) / `[null, 1]` (custom) |
| `oMH3Zd` | CREATE_GEM | Create a custom gem | `[name, description, prompt, ...]` |
| `kHv0Vd` | UPDATE_GEM | Update an existing gem | `[gem_id, [name, description, prompt, ...]]` |
| `UXcSJb` | DELETE_GEM | Delete a custom gem | `[gem_id]` |
| `ESY5D` | BARD_ACTIVITY | Enable Bard activity | `[1]` |

## RPCs To Capture

| Feature | Expected RPC ID | Status |
|---------|----------------|--------|
| Deep Research | TBD | Not captured |
| Video Generation (Veo) | TBD | Not captured |
| Canvas operations | TBD | Not captured |
| Code Execution | TBD | Not captured |

## Model Hashes

Model selection uses the `x-goog-ext-525001261-jspb` header:

```
[1,null,null,null,"<model_hash>",null,null,0,[4],null,null,1]
```

| Model | Hash | Name |
|-------|------|------|
| Gemini 3.0 Pro | `9d8ca3786ebdfbea` | `gemini-3.0-pro` |
| Gemini 3.0 Flash | `fbb127bbb056c959` | `gemini-3.0-flash` |
| Gemini 3.0 Flash Thinking | `5bf011840784117a` | `gemini-3.0-flash-thinking` |

Custom models: Provide `model_name` and `model_header` dict with the same header key.

## Error Codes

Returned in response at path `part[5][2][0][1][0]`:

| Code | Name | Description | Action |
|------|------|-------------|--------|
| 1013 | TEMPORARY_ERROR | Randomly raised with certain models | Retry (transient) |
| 1037 | USAGE_LIMIT_EXCEEDED | Usage limit hit | Back off, wait |
| 1050 | MODEL_INCONSISTENT | Model mismatch with conversation | Use correct model or new conversation |
| 1052 | MODEL_HEADER_INVALID | Model unavailable or bad header | Check model hash |
| 1060 | IP_TEMPORARILY_BLOCKED | IP blocked by Google | Wait, change IP |

## Request Headers

### Standard Headers (all requests to gemini.google.com)

```
Content-Type: application/x-www-form-urlencoded;charset=utf-8
Host: gemini.google.com
Origin: https://gemini.google.com
Referer: https://gemini.google.com/
User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36
X-Same-Domain: 1
```

### RotateCookies Headers

```
Content-Type: application/json
```

### File Upload Headers

```
Push-ID: feeds/mcudyrk2a4khkz
```

## batchexecute Request Format

**URL**: `POST {BATCH_EXEC}?rpcids={ids}&_reqid={reqid}&rt=c&source-path=/app&bl={build_label}&f.sid={session_id}`

**Body** (form-encoded):
- `at` = SNlM0e access token
- `f.req` = `json.dumps([[ [rpc_id, payload_json, null, "generic"], ... ]])`

**_reqid**: Random 5-digit integer, incremented by 100000 between batches.

## StreamGenerate Request Format

**URL**: `POST {GENERATE}?_reqid={reqid}&rt=c&bl={build_label}&f.sid={session_id}`

**Body** (form-encoded):
- `at` = SNlM0e access token
- `f.req` = `json.dumps([null, json.dumps(inner_req_list)])`

**inner_req_list** (69+ elements):
- `[0]` = `[prompt, 0, null, file_data, null, null, 0]`
- `[2]` = metadata (10-element list: `[cid, rid, rcid, ...]` for multi-turn)
- `[7]` = `1` (snapshot streaming)
- `[19]` = gem_id (optional)

## Response Parsing Protocol

### Frame Format (streaming)

Length-prefixed frames: `[length]\n[json_payload]\n`

- Length is in **UTF-16 code units** (JavaScript `String.length`)
- BMP chars (U+0000-U+FFFF) = 1 unit; supplementary (U+10000+) = 2 units
- Strip `)]}'` prefix before parsing

### Response Structure

For each parsed frame/part:
- `part[2]` = inner JSON (parse again)
- `part_json[1]` = metadata (conversation context: cid, rid, rcid, ...)
- `part_json[4]` = candidates list
- `part_json[25]` = completion indicator
- Per candidate:
  - `candidate_data[0]` = rcid
  - `candidate_data[1][0]` = text content
  - `candidate_data[37][0][0]` = thought process
  - `candidate_data[12][1]` = web images
  - `candidate_data[12][7][0]` = generated images
- Error: `part[5][2][0][1][0]` = error code
