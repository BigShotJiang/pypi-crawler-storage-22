"""GeminiClient: the main entry point that composes all core components.

Usage:
    client = GeminiClient(profile_name="default")
    await client.init()
    response = await client.send("Hello!")
    print(response.text)
"""

from __future__ import annotations

import asyncio

import httpx
from loguru import logger

from .auth import AuthManager
from .constants import DEFAULT_MODEL, GEMINI_HEADERS, TOKEN_FACTORY_MODELS, Model, get_model
from .exceptions import AuthError, TokenFactoryError
from .models import BatchResult, ConversationMetadata, RPCPayload, StreamResponse
from .profiles import ProfileManager
from .rpc import RPCTransport, build_stream_response


class GeminiClient:
    """High-level client that composes AuthManager, RPCTransport, and ProfileManager.

    Handles initialization, authentication, and provides simple methods for
    chat, batchexecute, and other operations.
    """

    def __init__(
        self,
        profile_name: str | None = None,
        proxy: str | None = None,
        timeout: float = 300.0,
    ):
        self.profile_manager = ProfileManager()
        self.auth_manager = AuthManager(
            profile_manager=self.profile_manager,
            profile_name=profile_name,
            proxy=proxy,
        )
        self.proxy = proxy
        self.timeout = timeout
        self._http_client: httpx.AsyncClient | None = None
        self._transport: RPCTransport | None = None
        self._token_factory = None  # Lazy-initialized TokenFactory
        self._browser_http_client: httpx.AsyncClient | None = None
        self._browser_cookies: dict[str, str] | None = None  # Full cookies from Token Factory
        self._raw_browser_cookies: list[dict] = []  # Raw CDP cookies with domain info
        self._initialized = False

    @property
    def transport(self) -> RPCTransport:
        if not self._transport:
            raise AuthError("Client not initialized. Call init() first.")
        return self._transport

    async def init(self) -> None:
        """Initialize the client: load auth, create HTTP client, set up transport."""
        # Load auth state from profile
        auth_state = self.auth_manager.load()

        if not auth_state.is_valid:
            raise AuthError(
                "No valid authentication found. Run `gemcli login` first."
            )

        # Refresh tokens to ensure they're current (non-fatal if it fails)
        try:
            await self.auth_manager.refresh_tokens()
        except AuthError:
            logger.debug("Token refresh failed, using cached tokens.")

        auth_state = self.auth_manager.state

        # Create HTTP client
        self._http_client = httpx.AsyncClient(
            http2=True,
            timeout=self.timeout,
            proxy=self.proxy,
            follow_redirects=True,
            headers=GEMINI_HEADERS,
            cookies=auth_state.cookies,
        )

        # Create transport
        self._transport = RPCTransport(
            client=self._http_client,
            access_token=auth_state.tokens.snlm0e,
            build_label=auth_state.tokens.cfb2h,
            session_id=auth_state.tokens.fdrfje,
        )

        self._initialized = True
        logger.info("GeminiClient initialized.")

    async def close(self) -> None:
        """Close the HTTP client, Token Factory, and clean up."""
        if self._http_client:
            await self._http_client.aclose()
            self._http_client = None
        if self._browser_http_client:
            await self._browser_http_client.aclose()
            self._browser_http_client = None
        if self._token_factory:
            self._token_factory.shutdown()
            self._token_factory = None
        self._transport = None
        self._initialized = False

    async def send(
        self,
        prompt: str,
        model: str | Model | None = None,
        metadata: ConversationMetadata | None = None,
        file_data: list | None = None,
        gem_id: str | None = None,
    ) -> StreamResponse:
        """Send a chat message via StreamGenerate.

        Routes through Token Factory for Pro/Thinking models (which need
        BotGuard tokens), or direct HTTP for Flash (default).
        """
        resolved_model = self._resolve_model(model)

        if self._needs_token_factory(resolved_model):
            return await self._send_via_token_factory(
                prompt=prompt,
                model=resolved_model,
                metadata=metadata,
            )

        return await self.transport.stream_generate(
            prompt=prompt,
            model=resolved_model,
            metadata=metadata,
            file_data=file_data,
            gem_id=gem_id,
        )

    async def execute_rpc(
        self,
        rpc_id: str,
        payload: str = "[]",
        source_path: str = "/app",
    ) -> list[BatchResult]:
        """Execute a single RPC via batchexecute."""
        return await self.transport.batchexecute(
            payloads=[RPCPayload(rpc_id=rpc_id, payload=payload)],
            source_path=source_path,
        )

    async def execute_rpcs(
        self,
        payloads: list[RPCPayload],
        source_path: str = "/app",
    ) -> list[BatchResult]:
        """Execute multiple RPCs in a single batchexecute call."""
        return await self.transport.batchexecute(
            payloads=payloads,
            source_path=source_path,
        )

    def get_cookies(self) -> dict[str, str]:
        """Get the best available cookies (full browser set if available, else auth-only)."""
        if self._browser_cookies:
            return self._browser_cookies
        return self.auth_manager.state.cookies

    def get_httpx_cookies(self) -> httpx.Cookies:
        """Get cookies as httpx.Cookies with proper domain handling for cross-domain downloads.

        Duplicates cookies for both .google.com and .googleusercontent.com
        to ensure authentication works across Google CDN redirect domains.
        This is required for downloading images from lh3.googleusercontent.com.
        """
        cookies = httpx.Cookies()

        if self._raw_browser_cookies:
            for c in self._raw_browser_cookies:
                name = c.get("name")
                value = c.get("value")
                domain = c.get("domain", "")
                path = c.get("path", "/")

                if not name or not value:
                    continue

                if "google.com" in domain:
                    cookies.set(name, value, domain=domain, path=path)
                    # Duplicate for .googleusercontent.com for CDN downloads
                    if domain == ".google.com":
                        cookies.set(
                            name, value, domain=".googleusercontent.com", path=path
                        )
        else:
            # Fallback: simple cookies without domain info — set for both domains
            for name, value in self.get_cookies().items():
                cookies.set(name, value, domain=".google.com")
                cookies.set(name, value, domain=".googleusercontent.com")

        return cookies

    def _needs_token_factory(self, model: Model) -> bool:
        """Check if this model requires BotGuard tokens (Pro/Thinking)."""
        return model.name in TOKEN_FACTORY_MODELS

    def _ensure_token_factory(self):
        """Lazy-initialize the Token Factory."""
        if self._token_factory is None:
            from .token_factory import TokenFactory

            auth_state = self.auth_manager.state
            if not auth_state.chrome_profile_path:
                raise TokenFactoryError(
                    "No Chrome profile configured. Run 'gemcli login' first."
                )
            self._token_factory = TokenFactory(
                chrome_profile_path=auth_state.chrome_profile_path,
                profile_name=self.auth_manager.profile_name or "default",
            )
        return self._token_factory

    async def _send_via_token_factory(
        self,
        prompt: str,
        model: Model,
        metadata: ConversationMetadata | None = None,
    ) -> StreamResponse:
        """Send via Token Factory: Chrome captures BotGuard token, Python sends HTTP."""
        factory = self._ensure_token_factory()

        # TokenFactory is sync (CDP uses sync websocket) — run in executor
        loop = asyncio.get_event_loop()
        captured = await loop.run_in_executor(
            None,
            lambda: factory.capture(prompt=prompt, model=model, metadata=metadata),
        )

        # Create a separate HTTP client for browser-replay requests
        # (no preset cookies — we use the captured cookies directly)
        if self._browser_http_client is None:
            self._browser_http_client = httpx.AsyncClient(
                http2=True,
                timeout=self.timeout,
                follow_redirects=True,
            )

        # Store browser cookies for use by other operations (e.g., image download)
        self._browser_cookies = captured.cookies
        self._raw_browser_cookies = factory.get_raw_cookies()

        logger.debug(f"Token Factory: sending via Python HTTP ({model.name})")
        response = await self._browser_http_client.post(
            captured.url,
            content=captured.body,
            headers=captured.headers,
            cookies=captured.cookies,
        )
        response.raise_for_status()

        return build_stream_response(response.text)

    def _resolve_model(self, model: str | Model | None) -> Model:
        """Resolve a model name string to a Model object."""
        if model is None:
            return DEFAULT_MODEL
        if isinstance(model, Model):
            return model
        return get_model(model)

    async def __aenter__(self):
        await self.init()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()
