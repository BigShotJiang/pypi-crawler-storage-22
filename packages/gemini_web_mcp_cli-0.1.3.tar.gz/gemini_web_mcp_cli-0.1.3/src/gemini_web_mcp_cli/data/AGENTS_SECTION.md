<!-- gemini-skill-start -->

## Gemini Web MCP - CLI & MCP Expert

**Triggers:** "gemcli", "gemini web mcp", "gemini chat", "image generation", "video generation", "deep research", "gems"

This section provides guidance for using Google Gemini via the `gemcli` CLI and `gemini-web-mcp` MCP server.

### Quick Reference

```bash
gemcli --ai                # Full AI-optimized documentation
gemcli --help              # List all commands
gemcli doctor              # Diagnose installation and auth
```

### Critical Rules

1. **Always authenticate first**: Run `gemcli login` before any operations
2. **Session expiry**: Re-run `gemcli login` if commands fail with auth errors
3. **Model selection**: Flash is default (no setup needed). Pro/Thinking require Token Factory
4. **Use `--help` when unsure**: `gemcli <command> --help`

### Key Commands

```bash
# Chat
gemcli chat "prompt"                    # Single message
gemcli chat "prompt" -m gemini-3.0-pro  # Use Pro model
gemcli chat                             # Interactive REPL

# Image Generation
gemcli image "A sunset" -o sunset.png

# Video Generation (Veo 3.1)
gemcli video "Ocean waves" -o video.mp4

# Deep Research
gemcli research "AI advances in 2026"

# Gems Management
gemcli gems list
gemcli gems create --name "Reviewer" --prompt "You are a code reviewer..."
gemcli gems delete <gem_id>

# Profile Management
gemcli profile list
gemcli profile switch <name>

# Diagnostics & Setup
gemcli doctor
gemcli setup add <tool>
gemcli skill install <tool>
```

### MCP Tools (when available)

| Tool | Actions | Key Parameters |
|------|---------|---------------|
| `chat` | send | prompt, model, conversation_id, extensions |
| `image` | generate, download | prompt, model, output_path, image_url |
| `video` | generate, status, download | prompt, model, output_path |
| `research` | start, status | query, model |
| `gems` | list, create, update, delete | gem_id, name, system_prompt |

### Common Workflows

**First-time setup:**
```bash
gemcli login && gemcli doctor
```

**Image generation pipeline:**
```bash
gemcli image "A futuristic cityscape" -o city.png
```

**Research pipeline:**
```bash
gemcli research "Latest breakthroughs in quantum computing"
```

### Error Recovery

| Error | Solution |
|-------|----------|
| Auth expired | `gemcli login` |
| Model invalid | Check model name: flash, pro, thinking |
| Rate limited | Wait 30s, retry |
| Chrome error | Close Chrome, retry or use `--manual` |

For full documentation, install the complete skill: `gemcli skill install <tool>`

<!-- gemini-skill-end -->
