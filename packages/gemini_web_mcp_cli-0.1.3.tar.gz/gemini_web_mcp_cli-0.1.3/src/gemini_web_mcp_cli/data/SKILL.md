---
name: gemini-skill
description: "Expert guide for the Gemini Web MCP CLI (`gemcli`) and MCP server - interfaces for Google Gemini (gemini.google.com). Use this skill when users want to interact with Gemini programmatically, including: chatting with models, generating images, generating videos, deep research, managing Gems (custom personas), or automating Gemini workflows. Triggers on mentions of \"gemcli\", \"gemini web mcp\", \"gemini chat\", \"image generation\", \"video generation\", \"deep research\", \"gems\", or any Gemini web-related automation task."
---

# Gemini Web MCP CLI & MCP Expert

This skill provides comprehensive guidance for using Google Gemini via both the `gemcli` CLI and MCP tools.

## Tool Detection (CRITICAL - Read First!)

**ALWAYS check which tools are available before proceeding:**

1. **Check for MCP tools**: Look for tools starting with `mcp__gemini-web-mcp__*`
2. **If BOTH MCP tools AND CLI are available**: **ASK the user** which they prefer
3. **If only MCP tools are available**: Use them directly (refer to tool docstrings for parameters)
4. **If only CLI is available**: Use `gemcli` CLI commands via Bash

**Decision Logic:**
```
has_mcp_tools = check_available_tools()  # Look for mcp__gemini-web-mcp__*
has_cli = check_bash_available()          # Can run gemcli commands

if has_mcp_tools and has_cli:
    # ASK USER: "I can use either MCP tools or the gemcli CLI. Which do you prefer?"
    user_preference = ask_user()
elif has_mcp_tools:
    # Use MCP tools directly
    mcp__gemini-web-mcp__chat(action="send", prompt="Hello")
else:
    # Use CLI via Bash
    bash("gemcli chat 'Hello'")
```

This skill documents BOTH approaches. Choose based on tool availability and **user preference**.

## Quick Reference

**Run `gemcli --ai` to get comprehensive AI-optimized documentation.**

```bash
gemcli --help              # List all commands
gemcli <command> --help    # Help for specific command
gemcli --ai                # Full AI-optimized documentation (RECOMMENDED)
gemcli --version           # Check installed version
gemcli doctor              # Diagnose installation and auth
```

## Critical Rules (Read First!)

1. **Always authenticate first**: Run `gemcli login` before any operations
2. **Session expiry**: Cookies can expire. Re-run `gemcli login` if commands fail with auth errors
3. **Model selection**: Default is Flash (fast, no special setup). Pro and Thinking require Token Factory (Chrome + BotGuard token)
4. **Image generation defaults to Pro**: The image command uses Pro model by default for quality
5. **Interactive chat**: `gemcli chat` without a prompt opens an interactive REPL with slash commands
6. **NotebookLM cross-product**: If you have NotebookLM MCP installed, gemcli can reuse its Chrome profiles
7. **Use `--help` when unsure**: Run `gemcli <command> --help` for available options

## Workflow Decision Tree

```
User wants to...
|
+--> Chat with Gemini
|    +--> Single message -> gemcli chat "prompt" [-m model]
|    +--> Interactive REPL -> gemcli chat (no prompt)
|    +--> With extensions -> gemcli chat "@youtube summarize ..."
|
+--> Generate images
|    +--> gemcli image "prompt" [-o output.png]
|
+--> Generate videos (Veo 3.1)
|    +--> gemcli video "prompt" [-o output.mp4]
|
+--> Deep Research
|    +--> gemcli research "query" [-m model]
|
+--> Manage Gems (custom personas)
|    +--> List gems -> gemcli gems list
|    +--> Create gem -> gemcli gems create --name "Name" --prompt "..."
|    +--> Delete gem -> gemcli gems delete <gem_id>
|
+--> First-time setup
|    +--> gemcli login -> gemcli doctor
|
+--> Configure AI tools
     +--> gemcli setup add <tool>    (MCP server)
     +--> gemcli skill install <tool> (skill docs)
```

## Command Categories

### 1. Authentication

#### CLI Authentication
```bash
gemcli login                    # Automated Chrome login via CDP
gemcli login --check            # Validate current session
gemcli login --manual           # Paste cookies manually
gemcli login --profile work     # Use named profile
```

#### MCP Authentication
If using MCP tools and encountering auth errors, run `gemcli login` from the CLI to refresh cookies.

### 2. Chat

#### MCP Tool
```python
mcp__gemini-web-mcp__chat(action="send", prompt="Hello", model="pro")
mcp__gemini-web-mcp__chat(action="send", prompt="Follow up", conversation_id="abc123")
mcp__gemini-web-mcp__chat(action="send", prompt="@youtube summarize this", extensions=["youtube"])
```

#### CLI Commands
```bash
gemcli chat "What is quantum computing?"          # Single message
gemcli chat "Explain this" -m gemini-3.0-pro      # Use Pro model
gemcli chat "Summarize" -o summary.md             # Save to file
gemcli chat                                        # Interactive REPL
```

**Interactive REPL Slash Commands:**
- `/model <name>` - Switch model
- `/verify` - Show server model hash
- `/new` - Start new conversation
- `/save <file>` - Export conversation
- `/history` - View turns
- `/help` - Show help
- `/quit` - Exit

### 3. Image Generation

#### MCP Tool
```python
mcp__gemini-web-mcp__image(action="generate", prompt="A sunset", output_path="sunset.png")
mcp__gemini-web-mcp__image(action="download", image_url="https://...", output_path="img.png")
```

#### CLI Commands
```bash
gemcli image "A red panda in bamboo"               # Generate and display
gemcli image "Futuristic city" -o city.png          # Generate and save
gemcli image "Logo design" -m gemini-3.0-pro        # Specify model
```

### 4. Video Generation (Veo 3.1)

#### MCP Tool
```python
mcp__gemini-web-mcp__video(action="generate", prompt="Ocean waves at sunset")
mcp__gemini-web-mcp__video(action="status")         # Check progress
```

#### CLI Commands
```bash
gemcli video "Ocean waves at sunset"
gemcli video "Dancing robot" -o robot.mp4
```

### 5. Deep Research

#### MCP Tool
```python
mcp__gemini-web-mcp__research(action="start", query="AI advances in 2026")
mcp__gemini-web-mcp__research(action="status")       # Check progress
```

#### CLI Commands
```bash
gemcli research "Latest AI advances in 2026"
gemcli research "Quantum computing breakthroughs" -m gemini-3.0-pro
```

### 6. Gems (Custom Personas)

#### MCP Tool
```python
mcp__gemini-web-mcp__gems(action="list")
mcp__gemini-web-mcp__gems(action="create", name="Reviewer", system_prompt="You are...")
mcp__gemini-web-mcp__gems(action="update", gem_id="abc", name="New Name")
mcp__gemini-web-mcp__gems(action="delete", gem_id="abc")
```

#### CLI Commands
```bash
gemcli gems list
gemcli gems create --name "Code Reviewer" --prompt "You are a senior code reviewer..."
gemcli gems delete <gem_id>
```

### 7. Profile Management

```bash
gemcli profile list              # List all profiles (gemcli + NLM shared)
gemcli profile switch <name>     # Switch active profile
gemcli profile create <name>     # Create new profile
gemcli profile delete <name>     # Delete profile
gemcli profile sources           # Show profile sources
```

### 8. Configuration

```bash
gemcli config show               # Show all settings
gemcli config get <key>          # Get specific value
gemcli config set <key> <value>  # Set a value
```

### 9. MCP Setup

```bash
gemcli setup list                # Show configured clients
gemcli setup add cursor          # Add to Cursor
gemcli setup add claude-desktop  # Add to Claude Desktop
gemcli setup add claude-code     # Add to Claude Code
gemcli setup add gemini-cli      # Add to Gemini CLI
gemcli setup remove <tool>       # Remove from tool
```

### 10. Skill Management

```bash
gemcli skill list                # Show installation status
gemcli skill install claude-code # Install for Claude Code
gemcli skill install cursor      # Install for Cursor
gemcli skill update              # Update all outdated skills
gemcli skill show                # Display skill content
```

### 11. Diagnostics

```bash
gemcli doctor                    # Check installation, auth, config
gemcli doctor --verbose          # Detailed diagnostics
```

## Model Selection Guide

| Model | CLI Flag | Notes |
|-------|----------|-------|
| Flash (default) | `-m gemini-3.0-flash` | Fast, direct HTTP, no special setup |
| Pro | `-m gemini-3.0-pro` | Requires Token Factory (Chrome + BotGuard) |
| Thinking | `-m gemini-3.0-flash-thinking` | Requires Token Factory (Chrome + BotGuard) |

**Token Factory**: Pro and Thinking models require a BotGuard token generated by Chrome. Flash works with direct HTTP (no browser needed).

## Error Recovery

| Error | Cause | Solution |
|-------|-------|----------|
| AuthError / expired cookies | Session timeout | `gemcli login` |
| UsageLimitExceeded (1037) | Too many requests | Wait, then retry |
| ModelInvalid (1050/1052) | Bad model name | Check model names above |
| TemporarilyBlocked (1060) | IP rate limited | Wait or use VPN |
| TokenFactoryError | Chrome/BotGuard issue | Check Chrome is installed, run `gemcli doctor` |
| Chrome doesn't launch | Port conflict | Close Chrome, retry |

## Advanced Reference

For detailed information, see:
- **[references/command_reference.md](references/command_reference.md)**: Complete command signatures
- **[references/troubleshooting.md](references/troubleshooting.md)**: Detailed error handling
- **[references/workflows.md](references/workflows.md)**: End-to-end task sequences
