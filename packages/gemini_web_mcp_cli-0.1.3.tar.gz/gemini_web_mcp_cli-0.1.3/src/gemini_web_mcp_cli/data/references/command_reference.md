# Gemini Web MCP CLI - Command Reference

Complete command signatures for `gemcli` and the `gemini-web-mcp` MCP server.

---

## Global Options

| Option | Short | Description |
|--------|-------|-------------|
| `--profile` | `-p` | Use a specific profile for this command |
| `--verbose` | `-v` | Enable debug logging |
| `--version` | | Show version |
| `--ai` | | Output AI-friendly documentation |
| `--install-completion` | | Install shell completion |
| `--show-completion` | | Display completion script |

---

## Authentication

### `gemcli login`

Authenticate with Google Gemini via Chrome CDP or manual cookie entry.

```bash
gemcli login                          # Automated Chrome login via CDP
gemcli login --check                  # Validate current session
gemcli login --manual                 # Paste cookies manually
gemcli login --profile <name>         # Authenticate a specific profile
```

| Option | Description |
|--------|-------------|
| `--check` | Validate current auth without re-authenticating |
| `--manual` | Manual cookie entry mode |
| `--profile, -p` | Profile to authenticate |

---

## Chat

### `gemcli chat [PROMPT]`

Send messages to Gemini. Without a prompt, opens interactive REPL.

```bash
gemcli chat "What is quantum computing?"
gemcli chat "Explain this" -m gemini-3.0-pro
gemcli chat "Summarize" -o summary.md
gemcli chat --new                     # Force new conversation
gemcli chat                           # Interactive REPL
```

| Option | Short | Description |
|--------|-------|-------------|
| `--model` | `-m` | Model to use (e.g., gemini-3.0-pro) |
| `--output` | `-o` | Save response to file |
| `--new` | | Start new conversation (discard context) |
| `--gem` | | Use a specific Gem by ID |

**Interactive REPL Slash Commands:**

| Command | Description |
|---------|-------------|
| `/model <name>` | Switch model |
| `/verify` | Show server model hash |
| `/new` | Start new conversation |
| `/save <file>` | Export conversation |
| `/history` | View conversation turns |
| `/help` | Show help |
| `/quit` | Exit REPL |

---

## Image Generation

### `gemcli image PROMPT`

Generate images using Gemini (Nano Banana / Imagen).

```bash
gemcli image "A red panda in bamboo"
gemcli image "Futuristic city" -o city.png
gemcli image "Logo design" -m gemini-3.0-pro
```

| Option | Short | Description |
|--------|-------|-------------|
| `--model` | `-m` | Model to use (default: pro for images) |
| `--output` | `-o` | Save generated image to file |

---

## Video Generation

### `gemcli video PROMPT`

Generate videos using Gemini (Veo 3.1). Videos take 1-2 minutes.

```bash
gemcli video "Ocean waves at sunset"
gemcli video "Dancing robot" -o robot.mp4
```

| Option | Short | Description |
|--------|-------|-------------|
| `--model` | `-m` | Model to use |
| `--output` | `-o` | Save generated video to file |

---

## Deep Research

### `gemcli research QUERY`

Run deep research queries with multi-source analysis.

```bash
gemcli research "Latest AI advances in 2026"
gemcli research "Quantum computing breakthroughs" -m gemini-3.0-pro
```

| Option | Short | Description |
|--------|-------|-------------|
| `--model` | `-m` | Model to use |
| `--output` | `-o` | Save research report to file |

---

## Gems Management

### `gemcli gems list`

List all custom Gems.

```bash
gemcli gems list
gemcli gems list --predefined        # Include predefined Gems
```

| Option | Description |
|--------|-------------|
| `--predefined` | Include system/predefined gems |

### `gemcli gems create`

Create a new custom Gem.

```bash
gemcli gems create --name "Code Reviewer" --prompt "You are a senior code reviewer..."
gemcli gems create --name "Writer" --description "Creative writing" --prompt "..."
```

| Option | Description |
|--------|-------------|
| `--name` | Display name (required) |
| `--description` | Short description |
| `--prompt` | System prompt text (required) |

### `gemcli gems delete GEM_ID`

Delete a Gem by ID.

```bash
gemcli gems delete abc123
```

---

## Profile Management

### `gemcli profile list`

List all profiles (gemcli-native + NotebookLM shared).

### `gemcli profile switch NAME`

Switch the active profile.

### `gemcli profile create NAME`

Create a new profile.

### `gemcli profile delete NAME`

Delete a profile (requires confirmation).

### `gemcli profile sources`

Show profile sources (gemcli-native vs NLM shared).

---

## Configuration

### `gemcli config show`

Display all current settings.

### `gemcli config get KEY`

Get a specific configuration value.

### `gemcli config set KEY VALUE`

Set a configuration value.

**Available Keys:**

| Key | Default | Description |
|-----|---------|-------------|
| `active_profile` | `default` | Active profile name |
| `default_model` | (none) | Default model for commands |

---

## MCP Setup

### `gemcli setup list`

Show all supported AI tools and their MCP configuration status.

### `gemcli setup add CLIENT`

Add Gemini Web MCP server to an AI tool.

```bash
gemcli setup add cursor
gemcli setup add claude-desktop
gemcli setup add claude-code
gemcli setup add gemini-cli
gemcli setup add windsurf
gemcli setup add cline
gemcli setup add antigravity
```

### `gemcli setup remove CLIENT`

Remove Gemini Web MCP server from an AI tool.

---

## Skill Management

### `gemcli skill list`

Show available tools and skill installation status.

### `gemcli skill install TOOL`

Install Gemini skill documentation for an AI tool.

```bash
gemcli skill install claude-code
gemcli skill install cursor
gemcli skill install codex
gemcli skill install gemini-cli
```

| Option | Short | Default | Description |
|--------|-------|---------|-------------|
| `--level` | `-l` | `user` | Install at user or project level |

### `gemcli skill uninstall TOOL`

Remove installed Gemini skill.

### `gemcli skill update [TOOL]`

Update outdated skills. If TOOL omitted, updates all.

### `gemcli skill show`

Display the full skill documentation content.

---

## Diagnostics

### `gemcli doctor`

Diagnose installation, authentication, and configuration.

```bash
gemcli doctor              # Standard diagnostics
gemcli doctor --verbose    # Detailed diagnostics with paths and timestamps
```

---

## MCP Server Tools

The `gemini-web-mcp` MCP server exposes these tools:

### `chat`

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `action` | string | yes | `"send"` |
| `prompt` | string | for send | Message to send |
| `model` | string | no | Model: "pro", "flash", "thinking" |
| `conversation_id` | string | no | Continue existing conversation |
| `extensions` | list[str] | no | Extensions: ["youtube", "maps"] |

### `image`

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `action` | string | yes | `"generate"` or `"download"` |
| `prompt` | string | for generate | Image description |
| `model` | string | no | Model (default: "pro") |
| `image_url` | string | for download | URL from generate response |
| `output_path` | string | for download | Local file path |

### `video`

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `action` | string | yes | `"generate"`, `"status"`, or `"download"` |
| `prompt` | string | for generate | Video description |
| `model` | string | no | Model to use |
| `output_path` | string | for download | Local file path |

### `research`

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `action` | string | yes | `"start"` or `"status"` |
| `query` | string | for start | Research question |
| `model` | string | no | Model to use |

### `gems`

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `action` | string | yes | `"list"`, `"create"`, `"update"`, `"delete"` |
| `gem_id` | string | for update/delete | Gem identifier |
| `name` | string | for create | Display name |
| `description` | string | no | Short description |
| `system_prompt` | string | for create | System prompt text |

### Stub Tools (Coming Soon)

- **`canvas`**: Collaborative document editing (actions: create, update, export)
- **`code`**: Python code execution in Gemini's sandbox (actions: execute, download)
- **`file`**: File upload for conversation context (actions: upload)

---

## Verb-First Aliases

These aliases provide an alternative command style:

```bash
gemcli list gems                 # = gemcli gems list
gemcli list profiles             # = gemcli profile list
gemcli list skills               # = gemcli skill list
gemcli create gem --name ...     # = gemcli gems create --name ...
gemcli delete gem <id>           # = gemcli gems delete <id>
gemcli install skill <tool>      # = gemcli skill install <tool>
gemcli update skill [tool]       # = gemcli skill update [tool]
```
