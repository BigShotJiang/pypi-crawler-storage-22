"""MCP server for the Gemini web interface.

Exposes 8 consolidated tools, each with an action parameter:
- chat: send, stream
- image: generate, edit, download
- video: generate, status, download
- research: start, status, report, download
- gems: list, create, update, delete
- canvas: create, update, export (stub)
- code: execute, download (stub)
- file: upload (stub)

All tools call the service layer directly.
"""

from __future__ import annotations

import json

from mcp.server.fastmcp import FastMCP

from gemini_web_mcp_cli.core.client import GeminiClient

mcp = FastMCP("gemini-web-mcp")

# Shared client instance (initialized on first tool call)
_client: GeminiClient | None = None


async def _get_client() -> GeminiClient:
    """Get or create the shared GeminiClient."""
    global _client
    if _client is None:
        _client = GeminiClient()
        await _client.init()
    return _client


# ── Chat tool ───────────────────────────────────────────────────────────────


@mcp.tool()
async def chat(
    action: str,
    prompt: str | None = None,
    model: str | None = None,
    conversation_id: str | None = None,
    extensions: list[str] | None = None,
) -> str:
    """Chat with Gemini models. Supports sending messages and streaming responses.

    Actions:
    - send: Send a message and get a complete response
      - prompt (required): The message to send
      - model (optional): Model to use ("pro", "flash", "thinking")
      - conversation_id (optional): Continue an existing conversation
      - extensions (optional): Extensions to enable (e.g., ["youtube", "maps"])
    """
    if action == "send":
        if not prompt:
            return json.dumps({"error": "prompt is required for send action"})

        # Prepend extension syntax if extensions specified
        final_prompt = prompt
        if extensions:
            ext_prefix = " ".join(f"@{e}" for e in extensions)
            final_prompt = f"{ext_prefix} {prompt}"

        client = await _get_client()
        from gemini_web_mcp_cli.services.chat import ChatService

        svc = ChatService(client)
        response = await svc.send(final_prompt, model=model, conversation_id=conversation_id)

        return json.dumps({
            "text": response.text,
            "conversation_id": response.metadata.cid if response.metadata else None,
            "model_used": model or "default",
            "has_images": response.has_images,
        })

    return json.dumps({"error": f"Unknown action: {action}. Available: send"})


# ── Image tool ──────────────────────────────────────────────────────────────


@mcp.tool()
async def image(
    action: str,
    prompt: str | None = None,
    model: str | None = None,
    image_url: str | None = None,
    output_path: str | None = None,
) -> str:
    """Generate, edit, and download images using Gemini (Nano Banana / Imagen).

    Actions:
    - generate: Create an image from a text prompt
      - prompt (required): Description of the image to generate
      - model (optional): Model to use ("pro", "flash", "thinking"; default: "pro")
      - output_path (optional): Save the generated image to this local file path
    - download: Download a generated image to a local file
      - image_url (required): The image URL from a previous generate response
      - output_path (required): Local file path to save the image
    """
    client = await _get_client()
    from gemini_web_mcp_cli.services.image import ImageService

    svc = ImageService(client)

    if action == "generate":
        if not prompt:
            return json.dumps({"error": "prompt is required for generate action"})

        # Default to pro for image generation (requires full browser cookies)
        response = await svc.generate(prompt, model=model or "pro")
        result = {
            "text": response.text,
            "has_images": response.has_images,
        }

        if response.has_images:
            images = response.candidates[0].generated_images
            result["image_count"] = len(images) if images else 0

            # Extract image URLs for the caller
            if images:
                urls = []
                for img in images:
                    try:
                        url = img[0][3][3] if isinstance(img, list) else str(img)
                        urls.append(url)
                    except (IndexError, TypeError):
                        pass
                result["image_urls"] = urls

            # Auto-download if output_path provided
            if output_path and images:
                try:
                    url = images[0][0][3][3] if isinstance(images[0], list) else str(images[0])
                    saved = await svc.download(url, output_path)
                    result["saved_to"] = str(saved)
                except Exception as e:
                    result["download_error"] = str(e)

        return json.dumps(result)

    elif action == "download":
        if not image_url:
            return json.dumps({"error": "image_url is required for download action"})
        if not output_path:
            return json.dumps({"error": "output_path is required for download action"})

        try:
            saved = await svc.download(image_url, output_path)
            return json.dumps({"saved_to": str(saved)})
        except Exception as e:
            return json.dumps({"error": f"Download failed: {e}"})

    return json.dumps({"error": f"Unknown action: {action}. Available: generate, download"})


# ── Video tool ──────────────────────────────────────────────────────────────


@mcp.tool()
async def video(
    action: str,
    prompt: str | None = None,
    model: str | None = None,
    task_id: str | None = None,
    output_path: str | None = None,
) -> str:
    """Generate videos using Gemini (Veo 3.1). Videos take 1-2 minutes to generate.

    Actions:
    - generate: Start video generation from a text prompt
      - prompt (required): Description of the video to create
      - model (optional): Model to use ("pro", "flash", "thinking")
    - status: Check video generation progress
    - download: Download a completed video to a local file
      - output_path (required): Local file path to save the video
    """
    client = await _get_client()
    from gemini_web_mcp_cli.services.video import VideoService

    svc = VideoService(client)

    if action == "generate":
        if not prompt:
            return json.dumps({"error": "prompt is required for generate action"})
        response = await svc.generate(prompt, model=model)
        return json.dumps({
            "text": response.text,
            "status": "generating",
            "message": "Video generation started. Use status action to check progress.",
        })

    elif action == "status":
        result = await svc.poll_status()
        return json.dumps(result)

    elif action == "download":
        if not output_path:
            return json.dumps({"error": "output_path is required for download action"})
        return json.dumps({"error": "download requires a video_url from a completed generation"})

    return json.dumps({"error": f"Unknown action: {action}. Available: generate, status, download"})


# ── Research tool ───────────────────────────────────────────────────────────


@mcp.tool()
async def research(
    action: str,
    query: str | None = None,
    model: str | None = None,
    output_path: str | None = None,
) -> str:
    """Deep Research: comprehensive multi-source research with structured reports.

    Actions:
    - start: Begin a deep research query (generates plan, then researches)
      - query (required): The research question or topic
      - model (optional): Model to use ("pro", "flash", "thinking")
    - status: Check research progress
    - report: Get the research report text
    - download: Save the report to a local file
      - output_path (required): Local file path to save the report
    """
    client = await _get_client()
    from gemini_web_mcp_cli.services.research import ResearchService

    svc = ResearchService(client)

    if action == "start":
        if not query:
            return json.dumps({"error": "query is required for start action"})
        plan = await svc.create_plan(query, model=model)
        return json.dumps({
            "text": plan.text,
            "status": "plan_created",
            "message": "Research plan created. The research will begin automatically.",
        })

    elif action == "status":
        result = await svc.poll_status()
        return json.dumps(result)

    return json.dumps({
        "error": f"Unknown action: {action}. Available: start, status, report, download"
    })


# ── Gems tool ───────────────────────────────────────────────────────────────


@mcp.tool()
async def gems(
    action: str,
    gem_id: str | None = None,
    name: str | None = None,
    description: str | None = None,
    system_prompt: str | None = None,
) -> str:
    """Manage Gemini Gems (custom AI personas with system prompts).

    Actions:
    - list: List all custom gems
    - create: Create a new gem
      - name (required): Display name
      - system_prompt (required): The system prompt text
      - description (optional): Short description
    - update: Update an existing gem
      - gem_id (required): ID of the gem to update
      - name, description, system_prompt: Fields to update
    - delete: Delete a gem
      - gem_id (required): ID of the gem to delete
    """
    client = await _get_client()
    from gemini_web_mcp_cli.services.gems import GemsService

    svc = GemsService(client)

    if action == "list":
        gem_list = await svc.list_gems()
        return json.dumps([
            {"id": g.id, "name": g.name, "description": g.description}
            for g in gem_list
        ])

    elif action == "create":
        if not name or not system_prompt:
            return json.dumps({"error": "name and system_prompt are required for create"})
        result = await svc.create(name, description or "", system_prompt)
        return json.dumps(result)

    elif action == "update":
        if not gem_id:
            return json.dumps({"error": "gem_id is required for update"})
        result = await svc.update(
            gem_id,
            name=name or "",
            description=description or "",
            prompt=system_prompt or "",
        )
        return json.dumps(result)

    elif action == "delete":
        if not gem_id:
            return json.dumps({"error": "gem_id is required for delete"})
        result = await svc.delete(gem_id)
        return json.dumps(result)

    return json.dumps({
        "error": f"Unknown action: {action}. Available: list, create, update, delete"
    })


# ── Canvas tool (stub) ──────────────────────────────────────────────────────


@mcp.tool()
async def canvas(
    action: str,
    canvas_id: str | None = None,
    content: str | None = None,
    output_path: str | None = None,
) -> str:
    """Canvas: collaborative document editing (coming soon).

    Actions:
    - create: Create a new canvas document
    - update: Update canvas content
    - export: Export canvas to file
    """
    return json.dumps({"error": "Canvas support is coming soon. Use chat for now."})


# ── Code tool (stub) ───────────────────────────────────────────────────────


@mcp.tool()
async def code(
    action: str,
    source_code: str | None = None,
    language: str | None = None,
    output_path: str | None = None,
) -> str:
    """Code execution: run Python code in Gemini's sandbox (coming soon).

    Actions:
    - execute: Run code in the sandbox
    - download: Download execution output
    """
    return json.dumps({"error": "Code execution support is coming soon. Use chat for now."})


# ── File tool (stub) ───────────────────────────────────────────────────────


@mcp.tool()
async def file(
    action: str,
    file_path: str | None = None,
) -> str:
    """Upload files to Gemini for context in conversations.

    Actions:
    - upload: Upload a file (image, PDF, document, audio)
      - file_path (required): Local path to the file
    """
    return json.dumps({"error": "File upload support is coming soon."})


# ── Server entry point ─────────────────────────────────────────────────────


def main():
    """Run the MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
