"""Image service: generate and download images via Gemini."""

from __future__ import annotations

from pathlib import Path

import httpx
from loguru import logger

from gemini_web_mcp_cli.core.client import GeminiClient
from gemini_web_mcp_cli.core.constants import CHROME_USER_AGENT
from gemini_web_mcp_cli.core.exceptions import GeminiError
from gemini_web_mcp_cli.core.models import StreamResponse
from gemini_web_mcp_cli.core.watermark import remove_watermark

# Headers that match a real browser for Google CDN downloads
_DOWNLOAD_HEADERS = {
    "User-Agent": CHROME_USER_AGENT,
    "Accept": "image/avif,image/webp,image/apng,image/*,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "Referer": "https://gemini.google.com/",
    "Sec-Fetch-Dest": "image",
    "Sec-Fetch-Mode": "no-cors",
    "Sec-Fetch-Site": "cross-site",
}


class ImageService:
    """Service for image generation and management.

    Image generation goes through the standard StreamGenerate endpoint.
    The model decides to generate images based on the prompt content.
    """

    def __init__(self, client: GeminiClient):
        self.client = client

    async def generate(self, prompt: str, model: str | None = None) -> StreamResponse:
        """Generate an image from a text prompt.

        The response will contain generated_images in the candidates
        if the model produces images.
        """
        return await self.client.send(prompt=prompt, model=model)

    async def download(
        self,
        image_url: str,
        output_path: str | Path,
    ) -> Path:
        """Download a generated image to a local file.

        Uses httpx.Cookies with domain duplication (.google.com + .googleusercontent.com)
        to ensure cookies are sent to Google's CDN during cross-domain downloads.
        This approach is proven in the NotebookLM MCP project.
        """
        output = Path(output_path)
        output.parent.mkdir(parents=True, exist_ok=True)

        # Append =s2048 for full-size if not already present
        if "=s" not in image_url:
            image_url = f"{image_url}=s2048"

        logger.debug(f"Downloading image: {image_url[:80]}...")

        # Get domain-aware cookies (duplicated for .google.com + .googleusercontent.com)
        cookies = self.client.get_httpx_cookies()

        timeout = httpx.Timeout(connect=10.0, read=30.0, write=30.0, pool=30.0)

        async with httpx.AsyncClient(
            http2=True,
            cookies=cookies,
            headers=_DOWNLOAD_HEADERS,
            follow_redirects=True,
            timeout=timeout,
        ) as client:
            response = await client.get(image_url)

            # Check for auth redirect (200 with HTML instead of image)
            content_type = response.headers.get("content-type", "").lower()
            if "text/html" in content_type:
                raise GeminiError(
                    "Image download redirected to login page. "
                    "Run 'gemcli login' to refresh credentials."
                )

            response.raise_for_status()
            cleaned = remove_watermark(response.content)
            output.write_bytes(cleaned)

        logger.info(f"Image saved to {output}")
        return output
