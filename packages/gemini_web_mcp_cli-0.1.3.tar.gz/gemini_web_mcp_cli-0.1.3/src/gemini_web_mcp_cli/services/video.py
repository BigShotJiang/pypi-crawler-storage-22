"""Video service: generate videos via Gemini (Veo)."""

from __future__ import annotations

from pathlib import Path

import httpx
from loguru import logger

from gemini_web_mcp_cli.core.client import GeminiClient
from gemini_web_mcp_cli.core.constants import CHROME_USER_AGENT, RPC
from gemini_web_mcp_cli.core.models import StreamResponse


class VideoService:
    """Service for video generation using Veo.

    Video generation goes through StreamGenerate (same as chat/images).
    It's async: initial response acknowledges, then kwDCne polls for completion.
    """

    def __init__(self, client: GeminiClient):
        self.client = client

    async def generate(self, prompt: str, model: str | None = None) -> StreamResponse:
        """Start video generation from a text prompt.

        Returns the initial acknowledgment. Poll with status() for completion.
        """
        return await self.client.send(prompt=prompt, model=model)

    async def poll_status(self, source_path: str = "/app") -> dict:
        """Poll for video generation completion using kwDCne RPC."""
        results = await self.client.execute_rpc(
            rpc_id=RPC.ASYNC_POLL,
            source_path=source_path,
        )
        if results:
            return {"status": "polled", "data": results[0].data}
        return {"status": "no_result"}

    async def download(
        self,
        video_url: str,
        output_path: str | Path,
        cookies: dict[str, str] | None = None,
    ) -> Path:
        """Download a generated video to a local file."""
        output = Path(output_path)
        output.parent.mkdir(parents=True, exist_ok=True)

        download_headers = {
            "User-Agent": CHROME_USER_AGENT,
            "Referer": "https://gemini.google.com/",
        }

        async with httpx.AsyncClient(
            http2=True,
            headers=download_headers,
            cookies=cookies or {},
            follow_redirects=True,
        ) as client:
            response = await client.get(video_url)
            response.raise_for_status()
            output.write_bytes(response.content)

        logger.info(f"Video saved to {output}")
        return output
