# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

GeminiLiveOTel is an OpenTelemetry sidecar-style instrumentation package for **Gemini Live API on Vertex AI** using the native audio model (`gemini-live-2.5-flash-native-audio`). It provides production observability (latency, tokens, VAD, audio compliance, quota) by hooking into live session events and exporting metrics to Google Cloud Monitoring.

## Commands

```bash
# Install all dependencies (production + dev)
uv sync

# Run all tests
uv run pytest tests/ -v

# Run a single test file
uv run pytest tests/test_sidecar_tdd.py -v

# Run a single test by name
uv run pytest tests/test_sidecar_tdd.py -k "test_name" -v

# Build the package
uv build
```

Python version: 3.11. Package manager: `uv` with `hatchling` build backend.

## Architecture

The package follows a **sidecar pattern** — non-invasive instrumentation that wraps existing `google.genai` live sessions.

### Module Responsibilities

- **`sidecar.py`** — Core. `LiveTelemetrySidecar` collects 28 metrics via hook methods (`on_session_started`, `on_client_request`, `on_server_message`, `on_tool_response`, `on_api_error`, `on_session_closed`). Contains `MetricDefinition`, `MetricSnapshot`, and internal `_MetricStore`/`_SessionState`/`_ToolCallState` classes. All metric names, units, and chart types are defined in `METRIC_DEFINITIONS` dict.
- **`integration.py`** — `InstrumentedLiveSession` wraps a native live session object, auto-calling sidecar hooks on `send_realtime_input()`, `send_client_content()`, `send_tool_response()`, `receive()`, and `close()`. Factory function: `instrument_live_session()`.
- **`exporter.py`** — `CloudMonitoringMetricExporter` creates metric descriptors in Cloud Monitoring and flushes `MetricSnapshot` data as TimeSeries in a background thread. Handles counter→CUMULATIVE, gauge→GAUGE, histogram→distribution conversions.
- **`dashboard.py`** — `build_dashboard_spec()` generates a Cloud Monitoring dashboard JSON (24 widgets, 48-column mosaic). Uses `timeSeriesFilter` queries (not MQL) for no-data-safe behavior.
- **`bootstrap.py`** — One-shot startup: `bootstrap_vertex_live_observability()` fetches concurrency quota from Quota API, creates sidecar + exporter + dashboard. Returns `BootstrapResult` dataclass.
- **`auto.py`** — Zero-code-change auto-instrumentation using `wrapt` to monkey-patch `google.genai.live`. Exposes `instrument()` and `uninstrument()`. Patches `AsyncLive.connect()` and six `AsyncSession` methods. Uses a shared singleton sidecar with automatic bootstrap (quota fetch, exporter, dashboard). Configured via environment variables. Activates on import (`import geminiliveotel.auto`).
- **`tool_ids.py`** — `stable_tool_call_id()` generates deterministic fallback IDs (`tc_{sha256[:12]}`) when Gemini Live doesn't provide explicit tool call IDs.

### Key Design Decisions

- **Model filtering**: Sidecar only instruments `gemini-live-2.5-flash-native-audio`. Other models are silently rejected.
- **Tool call correlation**: Uses explicit ID when available, falls back to stable hash of function_name + args.
- **Logical request counting**: Counts turn-start `realtime_input` and explicit `client_content` as separate requests; ignores subsequent streaming chunks.
- **VAD metric split**: Separate counters for server VAD (automatic mode) vs client activity signals (custom mode).
- **Session-grouped vs global metrics**: Most metrics are grouped by `session_id`. Exceptions: `concurrent_sessions` and `concurrency_quota_utilization_pct` are NOT session-grouped.
- **Audio compliance**: Chunks outside 20-100ms duration are counted as noncompliant.
- **Error classification**: Maps exceptions to gRPC-style error codes; distinguishes quota/rate-limit errors for separate alerting.
- **Fail-open**: Bootstrap logs warnings and continues if quota fetch or dashboard creation fails.
- **Deprecated SDK methods**: `send()` and `start_stream()` are not instrumented. Use `send_realtime_input()`, `send_client_content()`, and `send_tool_response()` instead.

### Public API Surface

All exports are in `__init__.py` (lazy-loaded): `LiveTelemetrySidecar`, `InstrumentedLiveSession`, `instrument_live_session`, `CloudMonitoringMetricExporter`, `build_dashboard_spec`, `generate_dashboard_display_name`, `bootstrap_vertex_live_observability`, `BootstrapResult`, `MetricDefinition`, `create_monitoring_dashboard`, `fetch_native_audio_concurrency_quota`, `instrument`, `uninstrument`.

## Testing

Tests follow TDD naming convention (`*_tdd.py`). No real GCP calls. Tests MUST use real SDK types (`google.genai.types`) — never fake/custom SDK classes. Test files mirror source modules:

| Source | Test |
|--------|------|
| `sidecar.py` | `test_sidecar_tdd.py` |
| `bootstrap.py` | `test_bootstrap_tdd.py` |
| `dashboard.py` | `test_dashboard_tdd.py` |
| `exporter.py` | `test_exporter_tdd.py` |
| `integration.py` | `test_integration_wrapper_tdd.py` |
| `auto.py` | `test_auto_tdd.py` |

## Environment Variables (auto-instrumentation)

When using `import geminiliveotel.auto` or calling `instrument()`:

| Variable | Default | Description |
|----------|---------|-------------|
| `GEMINI_OTEL_ENABLED` | `1` | Set to `0` or `false` to disable |
| `GEMINI_OTEL_PROJECT` | — | GCP project ID (required for export/dashboard) |
| `GEMINI_OTEL_REGION` | `us-central1` | GCP region |
| `GEMINI_OTEL_EXPORT` | `cloud_monitoring` | `cloud_monitoring`, `stdout`, or `none` |
| `GEMINI_OTEL_TARGET_MODEL` | `gemini-live-2.5-flash-native-audio` | Model to instrument |
| `GEMINI_OTEL_DASHBOARD` | `1` | Set to `0` to skip dashboard creation |
| `GEMINI_OTEL_QUOTA` | `1` | Set to `0` to skip quota fetch |
| `GEMINI_OTEL_FALLBACK_QUOTA` | `1000` | Fallback concurrency quota |
| `GEMINI_OTEL_FLUSH_INTERVAL` | `5` | Metric flush interval (seconds) |
| `GEMINI_OTEL_GROUP_BY_SESSION` | `0` | Set to `1` for session-grouped dashboard |
| `GEMINI_OTEL_CUMULATIVE_TOKENS` | `0` | Set to `1` if API reports cumulative token counts |
| `GEMINI_OTEL_RATE_WINDOW` | `60` | Sliding window size for QPS/throughput metrics (seconds) |
