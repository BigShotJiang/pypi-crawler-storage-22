# Gemini Live OTel Package Implementation Plan (Native Audio Only)

## Scope Guardrails
- [x] Instrument only `gemini-live-2.5-flash-native-audio` sessions.
- [x] Use only Gemini Live API session ID from `setup_complete.session_id`.
- [x] No generated replacement IDs for session-level grouping.
- [x] Support ADC or service account auth paths (no API key assumption).

## Phase 1: Project Bootstrap (uv)
- [x] Initialize a Python package using `uv`.
- [x] Create source layout and test layout.
- [x] Add dependency manifests with unpinned package names.
- [x] Add `requirements.txt` and `requirements-dev.txt` with no versions.

## Phase 2: Observability Contract Design
- [x] Define metric names, units, and label schema.
- [x] Encode native-audio model filter and session extraction rules.
- [x] Define VAD semantics split:
  - [x] server VAD events for automatic/built-in VAD mode.
  - [x] client activity signals for custom VAD mode.
  - [x] interruption metric for barge-in impact.
- [x] Define aggregation rules (session/model/region) and exceptions.

## Phase 3: Tests First (TDD Red)
- [x] Write tests for model filtering and session lifecycle tracking.
- [x] Write tests for API performance metrics:
  - [x] TTFAB
  - [x] turn end-to-end latency
  - [x] latency percentile export compatibility
- [x] Write tests for tool timing split:
  - [x] tool call roundtrip
  - [x] model wait after tool response
- [x] Write tests for audio chunk compliance:
  - [x] chunk duration distribution
  - [x] chunk bytes distribution
  - [x] noncompliant chunk counter (outside 20–100ms)
- [x] Write tests for token and modality metrics:
  - [x] total/prompt/response tokens
  - [x] modality token distribution (audio/video/image)
  - [x] token throughput (tokens/sec)
- [x] Write tests for turn and VAD metrics:
  - [x] turn complete total
  - [x] turns total
  - [x] server VAD event counts
  - [x] client activity signal counts
  - [x] interruptions total
- [x] Write tests for traffic/health metrics:
  - [x] request counters + derived QPS
  - [x] API errors
  - [x] quota/rate-limit errors
  - [x] successful model responses + success rate
  - [x] concurrent sessions + quota utilization (%)
- [x] Run tests and confirm expected failures.

## Phase 4: Implementation (TDD Green)
- [x] Implement metric registry abstraction (Counter/Gauge/Histogram).
- [x] Implement in-memory test meter for deterministic assertions.
- [x] Implement `LiveTelemetrySidecar` core hooks:
  - [x] connection/session setup hook
  - [x] outbound request hook
  - [x] inbound server message hook
  - [x] tool response hook
  - [x] session close/finalize hook
- [x] Implement rolling rate calculators (QPS/TPS) and gauges.
- [x] Implement concurrency tracker and quota utilization gauge.
- [x] Ensure all metrics include required labels and session grouping policy.
- [x] Ensure VAD metric behavior changes by mode (automatic vs custom).
- [x] Run tests until all pass.

## Phase 5: Integration and Packaging
- [x] Provide minimal setup API for existing projects (few lines).
- [x] Provide optional wrapper/helper around `google.genai` live session objects.
- [x] Add docs for Cloud Monitoring dashboard mapping and recommended charts.
- [x] Add README usage examples (ADC and service-account flows).
- [x] Verify lint/tests from clean environment with `uv` commands.
- [x] Ensure dashboard name is uniquely generated every creation.
- [x] Ensure dashboard charts are no-data-safe when metrics are temporarily absent.

## Phase 6: Final Validation
- [x] Run full test suite.
- [x] Validate sample instrumentation flow end-to-end with synthetic events.
- [x] Confirm dependency files have no version pins.
- [x] Summarize completed checklist and any follow-up items.

## Phase 7: Runtime Hardening (Live Project Validation)
- [x] Add Cloud Monitoring exporter tests and implementation for descriptor + timeseries export.
- [x] Ensure dashboard filter expressions always use valid `custom.googleapis.com/geminilive/*` metric types.
- [x] Harden integration wrapper to record API errors for all send/receive failure paths.
- [x] Improve quota auto-fetch to use Service Usage v1beta1 and prefer target-model + region quota buckets.
- [x] Verify dashboards and metric descriptors exist in Cloud Monitoring for the target project.
- [x] Expand dashboard widgets to cover all agreed production metrics (tokens, modality, VAD, turn_complete, request counters).

## Phase 8: Consistency Corrections (Logic + Visual)
- [x] Fix API request counting to represent logical turn-level requests (not per audio chunk flood).
- [x] Fix tool-call counting and roundtrip latency by correlating pending calls with stable fallback IDs.
- [x] Add tool-response telemetry hook for `send_client_content` integrations to capture roundtrip latency.
- [x] Count interruption signals from both `server_content.interrupted` and tool-call cancellation paths.
- [x] Update counter scorecards to `ALIGN_MAX + REDUCE_SUM` and remove sparkline to avoid fractional/compact rendering issues.
- [x] Validate fixes via automated tests and live Cloud Monitoring metric queries.
