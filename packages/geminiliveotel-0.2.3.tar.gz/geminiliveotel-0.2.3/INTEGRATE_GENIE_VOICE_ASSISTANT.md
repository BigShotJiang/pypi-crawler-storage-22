# Integrate GeminiLiveOTel into `genie-voice-assistant` (Lean Steps)

## 1. Install package in backend

```bash
cd /Users/krishnankumar/Documents/ResearchProjects/genie-voice-assistant/backend
uv add /Users/krishnankumar/Desktop/GeminiLiveOTel
```

## 2. Use ADC or service account auth (no API key)

Choose one:

```bash
gcloud auth application-default login
```

or

```bash
export GOOGLE_APPLICATION_CREDENTIALS="/absolute/path/to/service-account.json"
```

## 3. Add startup bootstrap (auto quota + auto dashboard)

In your server startup path (run once on process start):

```python
from geminiliveotel import bootstrap_vertex_live_observability

MODEL = "gemini-live-2.5-flash-native-audio"
REGION = "us-central1"
PROJECT_ID = "YOUR_PROJECT_ID"

obs = bootstrap_vertex_live_observability(
    project_id=PROJECT_ID,
    region=REGION,
    target_model=MODEL,
    fallback_concurrency_quota=1000,
    auto_fetch_quota=True,
    auto_create_dashboard=True,
)

telemetry = obs.sidecar
```

What this gives automatically:
- Tries Quota API first to resolve concurrency quota for Vertex AI Live.
- Falls back to `1000` with a warning if quota lookup fails.
- Creates a custom Cloud Monitoring dashboard with a unique name every restart.

## 4. Keep your live session logic, add lean wrapper

Where you already do `client.aio.live.connect(...)`:

```python
from geminiliveotel import instrument_live_session

async with client.aio.live.connect(model=MODEL, config=live_config) as raw_session:
    session = instrument_live_session(
        session=raw_session,
        sidecar=telemetry,
        model_id=MODEL,
        region=REGION,
        automatic_vad=True,  # set False only if you send custom activity_start/activity_end
    )

    await session.send_realtime_input(
        audio={"mime_type": "audio/pcm", "data": chunk_bytes},
        audio_chunk_duration_ms=chunk_duration_ms,
        audio_chunk_bytes=len(chunk_bytes),
    )

    async for message in session.receive():
        ...

    await session.close()
```

## 5. Behavior guarantees

- Session grouping uses Gemini Live `session_id` directly.
- Non-session global metrics (`concurrent_sessions`, `quota_utilization_pct`) are intentionally not session-grouped.
- Dashboard queries are no-data-safe: empty metrics render no data, not query errors.
