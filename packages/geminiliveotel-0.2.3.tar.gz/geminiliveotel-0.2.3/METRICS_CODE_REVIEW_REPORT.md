# GeminiLiveOTel — Metrics Code Review Report

**Date:** 2026-02-09
**Scope:** All 28 metrics across `sidecar.py`, `integration.py`, `auto.py`, `exporter.py`, `dashboard.py`, `bootstrap.py`
**SDK Version:** `google-genai` v1.62.0
**Methodology:** 5 parallel review agents analyzed (1) core metric logic, (2) integration hook points & SDK compatibility, (3) exporter/dashboard consistency, (4) external dependencies & bootstrap, (5) test coverage gaps

---

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [Critical Findings](#2-critical-findings)
3. [High Severity Findings](#3-high-severity-findings)
4. [Medium Severity Findings](#4-medium-severity-findings)
5. [Low Severity Findings](#5-low-severity-findings)
6. [Metric-by-Metric Verification](#6-metric-by-metric-verification)
7. [Cross-Layer Consistency](#7-cross-layer-consistency)
8. [Test Coverage Gaps](#8-test-coverage-gaps)
9. [Unhandled SDK Features](#9-unhandled-sdk-features)
10. [Recommendations](#10-recommendations)

---

## 1. Executive Summary

The GeminiLiveOTel sidecar defines 28 metrics and implements their computation across 7 hook methods. The review found **2 critical bugs**, **5 high-severity issues**, **9 medium-severity issues**, and **10+ low-severity issues**.

The most impactful finding is that **modality token counting is completely broken in production** due to a Pydantic enum serialization mismatch — the metric always reads zero. Additionally, **3 audio chunk metrics are permanently zero under auto-instrumentation** because the required parameters are custom extensions not present in the SDK's API surface.

Cross-layer consistency (metric names, units, labels) is excellent — zero typos across sidecar, exporter, and dashboard. 27 of 28 metrics have dashboard widgets. All 28 metrics have value-verified unit tests, though the tests use plain dicts rather than real SDK objects, masking the critical enum bug.

### Issue Count Summary

| Severity | Count | Status | Impact Area |
|----------|-------|--------|-------------|
| Critical | 2 | **All FIXED** | Metrics permanently zero in production |
| High | 5 | **All FIXED** | Incorrect values, resource leaks, wrong attribution |
| Medium | 9 | **All FIXED** | Stale data, missing parameters, dead metrics |
| Low | 10+ | **11 FIXED, 3 Won't Fix** | Redundancies, edge cases, documentation |

---

## 2. Critical Findings

### C1: Modality Token Counting is Completely Broken in Production [FIXED]

**Files:** `sidecar.py:678-691`, `integration.py:14-21`
**Metric:** `geminilive_modality_tokens_total`

When `_to_payload()` calls `message.model_dump(exclude_none=True)` on real SDK `LiveServerMessage` objects, the `modality` field retains its Pydantic **enum type** (`MediaModality.AUDIO`) rather than serializing to a plain string. The sidecar then does:

```python
modality = str(_extract(detail, "modality") or "").strip().lower()
if modality in {"audio", "video", "image"} and count:
```

- `str(MediaModality.AUDIO)` produces `"MediaModality.AUDIO"`
- After `.lower()` this becomes `"mediamodality.audio"`
- This **never matches** `"audio"`, `"video"`, or `"image"`

**Empirical verification** (run against installed SDK):

```
>>> str(MediaModality.AUDIO).strip().lower()
'mediamodality.audio'
>>> 'mediamodality.audio' in {"audio", "video", "image"}
False
```

**Result:** `geminilive_modality_tokens_total` is **always zero** in production, even when the server reports modality-specific token breakdowns.

**Why tests pass:** Tests use plain dicts with string values (`{"modality": "AUDIO"}`), not real SDK Pydantic objects. The string `"AUDIO"` correctly lowercases to `"audio"`.

**Impact:** Customers cannot see per-modality token breakdowns (audio/video/image), directly affecting cost attribution and billing analysis.

**Fix options:**
- Use `model_dump(exclude_none=True, mode='json')` in `_to_payload()` — serializes enums to string values
- Or extract enum value: `getattr(modality_val, 'value', str(modality_val))`

---

### C2: Audio Chunk Metrics Are Dead Under Auto-Instrumentation [FIXED]

**File:** `auto.py:368-370`
**Metrics:** `geminilive_input_audio_chunk_duration_ms`, `geminilive_input_audio_chunk_bytes`, `geminilive_input_audio_chunk_noncompliant_total`

The auto-instrumentation wrapper strips custom kwargs before forwarding to the SDK:

```python
audio_chunk_duration_ms = kwargs.pop("audio_chunk_duration_ms", None)
audio_chunk_bytes = kwargs.pop("audio_chunk_bytes", None)
```

However, the real SDK's `send_realtime_input()` does **not** accept these parameters — they are custom extension parameters that the instrumentation library adds. Under auto-instrumentation (the "zero-code-change" path), no user code passes these, so they are **always `None`**.

**Result:** Three metrics are permanently zero:

| Metric | Purpose | Status |
|--------|---------|--------|
| `geminilive_input_audio_chunk_duration_ms` | Audio chunk duration histogram | Always empty |
| `geminilive_input_audio_chunk_bytes` | Audio chunk size histogram | Always empty |
| `geminilive_input_audio_chunk_noncompliant_total` | Chunks outside 20-100ms range | Always zero |

**Impact:** Audio compliance monitoring — a key production safety metric — is silently disabled under the "zero-code-change" auto-instrumentation path. Users get no warning that these metrics require manual parameter passing.

---

## 3. High Severity Findings

### H1: Wall-Clock Time Used Instead of Monotonic Clock for All Durations [FIXED]

**Files:** `integration.py:10-11`, `auto.py:279-280`

```python
def _default_now_ms() -> int:
    return int(time.time() * 1000)
```

All 7 latency/duration metrics use `time.time()` (wall clock) instead of `time.monotonic()`. Wall clocks can jump forward or backward due to NTP adjustments.

**Affected metrics:**

| Metric | Type |
|--------|------|
| `geminilive_ttfab_ms` | histogram |
| `geminilive_turn_e2e_latency_ms` | histogram |
| `geminilive_tool_call_roundtrip_ms` | histogram |
| `geminilive_model_wait_after_tool_ms` | histogram |
| `geminilive_ws_connect_latency_ms` | histogram |
| `geminilive_request_qps` | gauge |
| `geminilive_token_throughput_tps` | gauge |

**Impact:** In cloud VMs, NTP corrections of 100ms+ are common. Backward corrections produce phantom zero-latency readings (clamped by `max(0, ...)`). Forward corrections produce spurious large outliers. Both corrupt p50/p95/p99 percentile calculations on dashboards.

---

### H2: `InstrumentedLiveSession.close()` Does Not Close Underlying WebSocket [FIXED]

**File:** `integration.py:229-236`

```python
async def close(self) -> None:
    if self._closed:
        return
    self._closed = True
    self._sidecar.on_session_closed(
        session_id=self._session_id,
        timestamp_ms=self._now_ms(),
    )
    # NOTE: self._session.close() is never called
```

The `close()` method fires `on_session_closed` and sets `self._closed = True` but **never calls `self._session.close()`**. The underlying WebSocket connection remains open, leaking resources.

> **Note:** `auto.py` does NOT have this bug — it wraps the real `close()` method and calls `wrapped(*args, **kwargs)`.

---

### H3: Auto-Instrumentation Bypasses Model Name Filtering [FIXED]

**File:** `auto.py:308`

```python
target_model = _env_target_model()  # from environment variable
```

In `_wrap_connect()`, the model passed to `on_session_started` is read from `GEMINI_OTEL_TARGET_MODEL` environment variable, **not** from the actual `kwargs['model']` passed to `connect()`. The sidecar's model filter always passes because it compares the env var against itself.

**Result:** If a user connects to model `gemini-2.0-flash-live-preview-04-09` but the env var is `gemini-live-2.5-flash-native-audio`, the session is instrumented and all metrics are labeled with the wrong model name. Multi-model applications have all sessions attributed to the same model.

---

### H4: Stale Concurrency Quota Produces Incorrect Utilization [FIXED]

**Files:** `bootstrap.py:258`, `sidecar.py:357`
**Metric:** `geminilive_concurrency_quota_utilization_pct`

The quota is fetched **once** at bootstrap and stored as an immutable integer. Google Cloud quotas can change at any time (quota increases, regional adjustments). If the actual quota is raised from 1000 to 5000 but the sidecar still holds 1000, utilization reads 5x too high.

Additionally, the fallback quota of 1000 (used when the Quota API is unreachable) can produce severely misleading values with no indication to dashboard consumers that a fallback is in use.

---

### H5: Token Counts May Be Overcounted if API Semantics Change [FIXED]

**File:** `sidecar.py:668-676`
**Metrics:** `geminilive_total_tokens_total`, `geminilive_prompt_tokens_total`, `geminilive_response_tokens_total`

The sidecar uses `inc_counter()` (additive) for every `usage_metadata` message. This assumes the Gemini Live API reports **incremental** token counts per message. If the API reports cumulative counts, all three token metrics would be massively overcounted.

Currently the Live API appears to report incrementally, but this is not documented as a guarantee. Given these metrics directly affect cost estimation, any semantic change would have billing-relevant consequences.

---

## 4. Medium Severity Findings

### M1: `send_realtime_input` Wrapper Missing `media` Parameter [FIXED]

**File:** `integration.py:97-108`

The SDK's `send_realtime_input()` accepts a `media` parameter for sending images. The `InstrumentedLiveSession` wrapper omits this parameter. Calls with `media=` bypass the sidecar entirely via `__getattr__` delegation — no metrics are recorded.

> **Note:** `auto.py` does NOT have this issue since it wraps the SDK method directly.

---

### M2: `on_ws_error` Hook is Never Invoked — Metric Permanently Zero [FIXED]

**Files:** `sidecar.py:651-659`, `integration.py`, `auto.py`
**Metric:** `geminilive_ws_errors_total`

The sidecar defines `on_ws_error()` and the metric has a dashboard widget, but **neither `integration.py` nor `auto.py` ever calls this hook**. WebSocket errors are classified by `_classify_error_code()` and routed through `on_api_error()` instead. The `geminilive_ws_errors_total` metric is permanently zero.

---

### M3: Tool Response Recorded Before SDK Call Succeeds [FIXED]

**Files:** `integration.py:175-179`, `auto.py:459-469`

In `send_tool_response()`, the sidecar's `on_tool_response` hook fires **before** the actual SDK call. If the send fails:

- `geminilive_tool_call_roundtrip_ms` records a latency for a response never delivered
- `geminilive_tool_calls_total` counts a tool call that never completed
- The `completed_tool_calls` set is polluted, preventing retry tracking

> **Note:** `send_client_content` correctly calls `on_tool_response` **after** the SDK call succeeds.

---

### M4: Stable Tool Call ID Collisions Cause Permanent Undercounting [FIXED]

**Files:** `sidecar.py:507-510`, `tool_ids.py`

When Gemini Live doesn't provide explicit tool call IDs, `stable_tool_call_id()` generates deterministic IDs from `sha256(function_name + args)`. Identical tool calls (same function, same args) get the same ID. The `completed_tool_calls` set prevents re-tracking, so **repeated identical tool calls are permanently undercounted** for the remainder of the session.

---

### M5: `request_qps` and `token_throughput_tps` Are Session-Lifetime Averages [FIXED]

**File:** `sidecar.py:444-452, 693-695`

Both metrics divide total counts by total elapsed time since session start:

```python
# QPS
span_sec = max(1.0, (last_logical_request_at_ms - first_logical_request_at_ms) / 1000.0)
qps = logical_request_count / span_sec

# Throughput
elapsed_sec = max(0.0, (timestamp_ms - session.started_at_ms) / 1000.0)
throughput = session.total_tokens / elapsed_sec
```

For long-running sessions, these converge to flat lines that don't reflect bursts or drops. The stale gauge values also persist during idle periods, showing artificially high rates.

---

### M6: `geminilive_input_audio_chunk_bytes` Has No Dashboard Widget [FIXED]

**File:** `dashboard.py`

This metric is fully implemented (defined in `METRIC_DEFINITIONS`, recorded in sidecar, has histogram bounds in exporter, metric descriptor created) but has **no corresponding dashboard widget**. It is the only metric out of 28 without visualization.

---

### M7: Heuristic Quota Matching Could Select Wrong Metric [FIXED]

**File:** `bootstrap.py:41-143`

The quota-fetching logic uses keyword-based heuristic scoring ("live", "concurrent", "session") with no exact metric ID comparison. If Google adds new quota metrics with overlapping keywords, the heuristic could silently pick the wrong metric.

---

### M8: Quota API Uses Beta Endpoint (`v1beta1`) [FIXED]

**File:** `bootstrap.py:159`

```
https://serviceusage.googleapis.com/v1beta1/projects/{project_id}/...
```

Beta APIs can be deprecated without notice. If removed, quota fetch silently falls back to 1000 with no indication to users.

---

### M9: Exporter Not Stopped on `uninstrument()` [FIXED]

**File:** `auto.py:698-699`

When `uninstrument()` is called, `_shared_sidecar` is set to `None` but the `CloudMonitoringMetricExporter`'s background thread is never stopped. On subsequent `instrument()` calls, a new exporter thread is spawned, causing resource leaks in instrument/uninstrument cycles (common in testing).

---

## 5. Low Severity Findings

| # | Finding | File | Notes |
|---|---------|------|-------|
| L1 | `turns_total` and `turn_complete_total` are always incremented together — fully redundant | `sidecar.py:572-573` | [FIXED] `turns_total` deprecated and no longer incremented |
| L2 | `ws_connect_latency_ms` lacks `max(0, ...)` guard unlike all other latency metrics | `sidecar.py:398` | [FIXED] Added `max(0.0, ...)` guard |
| L3 | Errors on already-closed sessions are silently dropped | `sidecar.py:637` | [FIXED] Added `logger.debug()` for closed session errors |
| L4 | Duplicate `turn_complete` messages double-count turns | `sidecar.py:563-595` | [FIXED] Added deduplication guard via `current_turn_start_ms` check |
| L5 | `session_id` can become literal string `"None"` | `integration.py:78` | [FIXED] Generates fallback ID `session-{id(session)}` |
| L6 | Scorecard titles show windowed deltas but labeled as "Counter" | `dashboard.py` | Won't fix — "(Counter)" indicates metric type, not display mode |
| L7 | `completed_tool_calls` set grows unbounded per session | `sidecar.py:334` | [FIXED] Changed to `dict[str, None]` with eviction at 10k entries |
| L8 | No label to distinguish fallback quota from API-fetched quota | `bootstrap.py` | [FIXED] Added `quota_source` field to `BootstrapResult` |
| L9 | `instrument()` called at import time, potentially triggering network calls | `auto.py:713` | [FIXED] Removed eager `_make_sidecar()` call from `instrument()` |
| L10 | Deprecated `send()` and `start_stream()` SDK methods not instrumented | Both wrappers | Won't fix — documented as known limitation |
| L11 | Turn state machine cannot handle overlapping turns (interruption without prior turn_complete) | `sidecar.py:429` | [FIXED] `client_content` resets turn state |
| L12 | No thread safety on `_MetricStore` or `_SessionState` | `sidecar.py` | [FIXED] Added `threading.Lock` to `_MetricStore` |
| L13 | Text modality silently excluded from `modality_tokens_total` | `sidecar.py:683` | Won't fix — intentional; added comment + updated description |
| L14 | Exporter daemon thread has no graceful shutdown; final metrics may be lost | `exporter.py:126` | [FIXED] Added final flush in `stop()` + `atexit` handler |

---

## 6. Metric-by-Metric Verification

### Metrics Verified as Correct

| Metric | Hook | Assessment |
|--------|------|------------|
| `geminilive_concurrent_sessions` | `on_session_started`, `on_session_closed` | Increment/decrement logic is sound with idempotent double-close protection |
| `geminilive_concurrency_quota_utilization_pct` | `_update_concurrency` | Correct percentage with zero-division guard (but stale quota — see H4) |
| `geminilive_input_audio_chunk_duration_ms` | `on_client_request` | Correct passthrough observation |
| `geminilive_input_audio_chunk_noncompliant_total` | `on_client_request` | Correct boundary (20-100ms inclusive) |
| `geminilive_input_audio_chunk_bytes` | `on_client_request` | Correct passthrough observation |
| `geminilive_client_activity_signals_total` | `on_client_request` | Correct VAD mode guard, dual-signal handling |
| `geminilive_server_vad_events_total` | `on_server_message` | Correct VAD mode guard |
| `geminilive_tool_call_roundtrip_ms` | `on_tool_response` | Correct latency computation with `max(0, ...)` |
| `geminilive_model_wait_after_tool_ms` | `on_server_message` | Correct with reset-after-use pattern |
| `geminilive_ttfab_ms` | `on_server_message` | Correct with tool-response-turn guard |
| `geminilive_turn_complete_total` | `on_server_message` | Correct with phantom turn suppression |
| `geminilive_turn_e2e_latency_ms` | `on_server_message` | Correct computation |
| `geminilive_successful_model_responses_total` | `on_server_message` | Correct with error flag tracking |
| `geminilive_model_success_rate` | `on_server_message` | Correct formula with zero-division guard |
| `geminilive_api_errors_total` | `on_api_error` | Correct error classification |
| `geminilive_rate_limit_quota_errors_total` | `on_api_error` | Correct dual-counting with good classification |
| `geminilive_vad_interruptions_total` | `on_server_message` | Correct from both `server_content` and `tool_call_cancellation` |
| `geminilive_api_requests_total` | `on_client_request` | Correct logical request counting (minor ms-collision edge case) |

### Metrics with Issues

| Metric | Issue | Severity |
|--------|-------|----------|
| `geminilive_modality_tokens_total` | ~~Always zero — enum serialization bug (C1)~~ [FIXED] | ~~Critical~~ |
| `geminilive_input_audio_chunk_duration_ms` | ~~Always empty under auto-instrumentation (C2)~~ [FIXED] | ~~Critical~~ |
| `geminilive_input_audio_chunk_bytes` | ~~Always empty under auto-instrumentation (C2)~~ [FIXED] | ~~Critical~~ |
| `geminilive_input_audio_chunk_noncompliant_total` | ~~Always zero under auto-instrumentation (C2)~~ [FIXED] | ~~Critical~~ |
| `geminilive_ws_errors_total` | ~~Hook never called; permanently zero (M2)~~ [FIXED] | ~~Medium~~ |
| `geminilive_total_tokens_total` | Depends on API reporting incremental counts (H5) | High |
| `geminilive_prompt_tokens_total` | Same dependency as above (H5) | High |
| `geminilive_response_tokens_total` | Same dependency as above (H5) | High |
| `geminilive_request_qps` | ~~Session-lifetime average, stale during idle (M5)~~ [FIXED] | ~~Medium~~ |
| `geminilive_token_throughput_tps` | ~~Session-lifetime average, stale during idle (M5)~~ [FIXED] | ~~Medium~~ |
| `geminilive_tool_calls_total` | ~~Recorded before SDK call succeeds (M3)~~ [FIXED] | ~~Medium~~ |
| `geminilive_tool_call_roundtrip_ms` | ~~Recorded before SDK call succeeds (M3)~~ [FIXED] | ~~Medium~~ |
| `geminilive_ws_connect_latency_ms` | ~~Missing `max(0, ...)` guard (L2)~~ [FIXED] | ~~Low~~ |
| `geminilive_turns_total` | ~~Redundant with `turn_complete_total` (L1)~~ [FIXED — deprecated, no longer incremented] | ~~Low~~ |

---

## 7. Cross-Layer Consistency

### Metric Name Consistency

All 28 metric names were verified across `sidecar.py` (METRIC_DEFINITIONS), `exporter.py` (descriptor creation), and `dashboard.py` (widget queries). **Zero typos found — perfect consistency.**

### Unit Consistency

Every unit in `METRIC_DEFINITIONS` is covered by the exporter's `_UNIT_MAP`:

| Sidecar Unit | Cloud Monitoring Unit |
|-------------|----------------------|
| `ms` | `ms` |
| `count` | `1` |
| `tokens` | `1` |
| `tokens/s` | `1/s` |
| `req/s` | `1/s` |
| `%` | `%` |
| `bytes` | `By` |
| `sessions` | `1` |
| `ratio` | `1` |

### Label Consistency

All label dimensions match between sidecar recording and exporter descriptor declarations:

| Metric | Extra Labels | Match? |
|--------|-------------|--------|
| `tool_calls_total` | `function_name` | Yes |
| `tool_call_roundtrip_ms` | `function_name` | Yes |
| `modality_tokens_total` | `modality` | Yes |
| `api_errors_total` | `error_code` | Yes |
| `rate_limit_quota_errors_total` | `error_code` | Yes |
| `ws_errors_total` | `error_type` | Yes |

### Dashboard Coverage

| Metric Count | In Dashboard | Missing |
|-------------|-------------|---------|
| 28 defined | 28 visualized | None [FIXED — M6] |

### Aggregation Method Correctness

| Chart Type | Aligner | Appropriate? |
|-----------|---------|-------------|
| Counter scorecards | `ALIGN_DELTA` + `REDUCE_SUM` | Yes |
| Histograms (latency) | `ALIGN_PERCENTILE_50/95/99` | Yes |
| Counter rate charts | `ALIGN_RATE` | Yes |
| Gauge line charts | `ALIGN_MEAN` or `ALIGN_MAX` | Yes |

---

## 8. Test Coverage Gaps

### Coverage Summary

All 28 metrics have at least one test verifying computed numeric values. However, significant gaps exist in test fidelity.

### High-Severity Gaps

| # | Gap | Impact |
|---|-----|--------|
| T1 | **camelCase server message format completely untested.** All tests use `snake_case` keys. The `_extract()` function's fallback logic for `toolCall`, `serverContent`, `usageMetadata`, etc. has zero coverage. | Could mask bugs in real SDK message handling |
| T2 | **Audio compliance boundary values (exactly 20ms, 100ms) untested.** Only 10ms, 40ms, 120ms tested. Off-by-one bugs in `< 20 or > 100` would go undetected. | Incorrect compliance classification |
| T3 | **Exporter numeric value correctness untested.** Tests verify structural presence of metrics, not that values are correctly transcribed to Cloud Monitoring payloads. | Silent value corruption |
| T4 | **Tests use plain dicts, not SDK Pydantic objects.** This masks the C1 enum serialization bug and potentially other type-related issues. | False confidence in test suite |

### Medium-Severity Gaps

| # | Gap |
|---|-----|
| T5 | No test for metric isolation between concurrent sessions |
| T6 | Empty session (start then immediate close) — division-by-zero guard untested |
| T7 | Error recovery across turns (error in turn 1, success in turn 2) |
| T8 | Concurrent sessions across different regions |
| T9 | Mixed success/failure ratio (e.g., 2/3 success rate) |
| T10 | Concurrency quota of 0 |
| T11 | Out-of-order messages (turn_complete before audio output) |

### Potential Bug Found in Test Analysis

Duplicate `turn_complete` messages would increment `turns_total` and `turn_complete_total` twice for what is logically one turn. After the first `turn_complete`, `current_turn_start_ms` is reset to `None`, so e2e latency is skipped on the second — but counters are still incremented. No deduplication guard exists.

---

## 9. Unhandled SDK Features

### Unhandled `LiveServerMessage` Fields

| Field | Significance | Priority |
|-------|-------------|----------|
| `go_away` | Server signals imminent session closure with `time_left` seconds | High — operationally critical |
| `voice_activity_detection_signal` | Lower-level VAD signal (SOS/EOS), distinct from `voice_activity` | Medium |
| `session_resumption_update` | Session resumption signals | Low |

### Unhandled `LiveServerContent` Fields

| Field | Significance | Priority |
|-------|-------------|----------|
| `turn_complete_reason` | Can be `MALFORMED_FUNCTION_CALL` or `RESPONSE_REJECTED` — should NOT count as successful | High — affects `model_success_rate` accuracy |
| `generation_complete` | Signals generation done before final processing | Low |
| `input_transcription` | User speech transcription | Low |
| `output_transcription` | Model output transcription | Low |
| `grounding_metadata` | Search grounding info | Low |

### Untracked `UsageMetadata` Fields

| Field | Relevance |
|-------|-----------|
| `thoughts_token_count` | Tokens from model "thinking" — relevant for thinking-mode models |
| `cached_content_token_count` | Tokens from cached content |
| `tool_use_prompt_token_count` | Tokens used in tool prompts |

---

## 10. Recommendations

### Priority 1 — Fix Immediately (Production Bugs)

| # | Action | Issue |
|---|--------|-------|
| 1 | Use `model_dump(exclude_none=True, mode='json')` in `_to_payload()` | C1 — modality tokens always zero |
| 2 | Add `await self._session.close()` to `InstrumentedLiveSession.close()` | H2 — WebSocket leak |
| 3 | Extract actual model from `kwargs['model']` in `_wrap_connect()` | H3 — wrong model attribution |

### Priority 2 — Fix Soon (Data Quality)

| # | Action | Issue |
|---|--------|-------|
| 4 | Switch `_default_now_ms()` and `_now_ms()` to `time.monotonic()` | H1 — clock skew in latencies |
| 5 | ~~Add `media` parameter to `InstrumentedLiveSession.send_realtime_input()`~~ | ~~M1 — missing parameter~~ [FIXED] |
| 6 | Compute audio chunk metrics from raw audio data in auto-instrumentation wrappers, or document that these require manual parameter passing | C2 — dead metrics under auto |
| 7 | ~~Call `on_tool_response` **after** successful SDK call, not before~~ | ~~M3 — premature recording~~ [FIXED] |

### Priority 3 — Improve (Robustness)

| # | Action | Issue |
|---|--------|-------|
| 8 | Add tests using real SDK Pydantic objects | T4 — test fidelity |
| 9 | Add camelCase server message tests | T1 — untested code path |
| 10 | Handle `turn_complete_reason` for success/failure classification | Unhandled SDK field |
| 11 | Track `go_away` server messages | Operationally significant |
| 12 | Add `threading.Lock` to `_MetricStore` | M9 — cross-runtime safety |
| 13 | ~~Stop exporter background thread in `uninstrument()`~~ | ~~M9 — resource leak~~ [FIXED] |
| 14 | ~~Add dashboard widget for `geminilive_input_audio_chunk_bytes`~~ | ~~M6 — missing visualization~~ [FIXED] |

### Priority 4 — Consider (Design Improvements)

| # | Action | Issue |
|---|--------|-------|
| 15 | ~~Implement sliding-window QPS instead of session-lifetime average~~ | ~~M5~~ [FIXED] |
| 16 | Add quota refresh mechanism or periodic re-fetch | H4 |
| 17 | Add `quota_source` label (api vs fallback) | L8 |
| 18 | Remove redundant `turns_total` metric or differentiate from `turn_complete_total` | L1 |
| 19 | Track `thoughts_token_count` for thinking-mode models | Untracked field |

---

## Appendix A: SDK Method Signature Compatibility

| SDK Method | `InstrumentedLiveSession` | `auto.py` Wrapper |
|-----------|--------------------------|-------------------|
| `send_realtime_input(media, audio, video, text, ...)` | Correct [FIXED — M1] | Correct (wraps directly) |
| `send_client_content(turns, turn_complete)` | Correct (kwargs passthrough) | Correct |
| `send_tool_response(function_responses)` | Correct | Correct |
| `receive()` | Correct (wraps async generator) | Correct |
| `_receive()` | Correct | Correct |
| `close()` | **Does not delegate to underlying session** | Correct |
| `send()` (deprecated) | Not instrumented | Not instrumented |
| `start_stream()` (deprecated) | Not instrumented | Not instrumented |

## Appendix B: Sidecar Hook Call Verification

| Hook | `integration.py` | `auto.py` | Called Correctly? |
|------|-------------------|-----------|-------------------|
| `on_session_started` | Constructor | `_wrap_connect` | Yes |
| `on_client_request` | `send_realtime_input`, `send_client_content` | Same wrappers | Yes — before SDK call |
| `on_server_message` | `receive`, `_receive` | Same wrappers | Yes — after message received |
| `on_tool_response` | `send_tool_response`, `send_client_content` | Same wrappers | Yes — records after SDK call succeeds [FIXED — M3] |
| `on_api_error` | All send/receive methods | Same wrappers | Yes — on exception, then re-raises |
| `on_session_closed` | `close` | `_wrap_close`, `_wrap_connect` finally | **`integration.py` does not delegate close to SDK** |
| `on_ws_error` | All send/receive methods | Same wrappers | Yes — called on WebSocket errors [FIXED — M2] |

---

*Report generated by automated code review analysis. All findings should be verified before implementing fixes.*
