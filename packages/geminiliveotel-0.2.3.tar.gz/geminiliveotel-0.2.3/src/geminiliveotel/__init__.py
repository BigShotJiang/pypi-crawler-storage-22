"""GeminiLiveOTel — Production observability for Gemini Live API on Vertex AI.

All public symbols are lazily imported to avoid pulling in heavy dependencies
(google.auth, google-genai, etc.) at package-load time.  This allows
``import geminiliveotel`` to succeed even when optional deps are missing and
keeps ``from geminiliveotel.auto import instrument`` fast.
"""

__all__ = [
    "LiveTelemetrySidecar",
    "MetricDefinition",
    "build_dashboard_spec",
    "generate_dashboard_display_name",
    "CloudMonitoringMetricExporter",
    "InstrumentedLiveSession",
    "instrument_live_session",
    "BootstrapResult",
    "bootstrap_vertex_live_observability",
    "create_monitoring_dashboard",
    "fetch_native_audio_concurrency_quota",
    "instrument",
    "uninstrument",
    "update_quota",
]

_LAZY_IMPORTS: dict[str, tuple[str, str]] = {
    "LiveTelemetrySidecar": ("geminiliveotel.sidecar", "LiveTelemetrySidecar"),
    "MetricDefinition": ("geminiliveotel.sidecar", "MetricDefinition"),
    "build_dashboard_spec": ("geminiliveotel.dashboard", "build_dashboard_spec"),
    "generate_dashboard_display_name": ("geminiliveotel.dashboard", "generate_dashboard_display_name"),
    "CloudMonitoringMetricExporter": ("geminiliveotel.exporter", "CloudMonitoringMetricExporter"),
    "InstrumentedLiveSession": ("geminiliveotel.integration", "InstrumentedLiveSession"),
    "instrument_live_session": ("geminiliveotel.integration", "instrument_live_session"),
    "BootstrapResult": ("geminiliveotel.bootstrap", "BootstrapResult"),
    "bootstrap_vertex_live_observability": ("geminiliveotel.bootstrap", "bootstrap_vertex_live_observability"),
    "create_monitoring_dashboard": ("geminiliveotel.bootstrap", "create_monitoring_dashboard"),
    "fetch_native_audio_concurrency_quota": ("geminiliveotel.bootstrap", "fetch_native_audio_concurrency_quota"),
    "instrument": ("geminiliveotel.auto", "instrument"),
    "uninstrument": ("geminiliveotel.auto", "uninstrument"),
    "update_quota": ("geminiliveotel.auto", "update_quota"),
}


def __getattr__(name: str):
    if name in _LAZY_IMPORTS:
        module_path, attr = _LAZY_IMPORTS[name]
        import importlib

        mod = importlib.import_module(module_path)
        val = getattr(mod, attr)
        # Cache on the module so __getattr__ is not called again
        globals()[name] = val
        return val
    raise AttributeError(f"module 'geminiliveotel' has no attribute {name!r}")
