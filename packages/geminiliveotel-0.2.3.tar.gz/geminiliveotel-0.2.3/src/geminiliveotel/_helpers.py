"""Shared helpers used by both integration.py and auto.py."""

from __future__ import annotations

import time
from collections.abc import Mapping
from typing import Any, Protocol


class HttpSession(Protocol):
    def get(self, url: str, *, params: dict | None = None, timeout: int = 30) -> Any: ...

    def post(self, url: str, *, json: dict | None = None, timeout: int = 30) -> Any: ...


def now_ms() -> int:
    return int(time.monotonic() * 1000)


def to_payload(message: Any) -> Mapping[str, Any]:
    if hasattr(message, "model_dump"):
        dumped = message.model_dump(exclude_none=True, mode="json")
        if isinstance(dumped, Mapping):
            return dumped
    if isinstance(message, Mapping):
        return message
    return {}


def extract_call_ids(function_responses: list[Any] | None) -> list[str]:
    if not function_responses:
        return []
    ids: list[str] = []
    for response in function_responses:
        if isinstance(response, Mapping):
            response_id = response.get("id")
        else:
            response_id = getattr(response, "id", None)
        if response_id is not None:
            ids.append(str(response_id))
    return ids


def classify_error_code(error: Exception) -> str:
    message = str(error)
    upper = message.upper()
    if "RESOURCE_EXHAUSTED" in upper:
        return "RESOURCE_EXHAUSTED"
    if "QUOTA" in upper:
        return "QUOTA_EXCEEDED"
    if "RATE LIMIT" in upper or "TOO MANY REQUESTS" in upper or "429" in upper:
        return "RATE_LIMIT_EXCEEDED"
    if "INVALID_ARGUMENT" in upper:
        return "INVALID_ARGUMENT"
    if "PERMISSION_DENIED" in upper:
        return "PERMISSION_DENIED"
    if "UNAUTHENTICATED" in upper:
        return "UNAUTHENTICATED"
    if "UNAVAILABLE" in upper:
        return "UNAVAILABLE"
    if "DEADLINE_EXCEEDED" in upper:
        return "DEADLINE_EXCEEDED"
    if "1011" in upper and "INSUFFICIENT MODEL RESOURCES" in upper:
        return "RESOURCE_EXHAUSTED"
    return error.__class__.__name__.upper()


def is_ws_error(error: Exception) -> tuple[bool, str]:
    class_name = type(error).__name__
    if class_name == "ConnectionClosed":
        return True, "CONNECTION_CLOSED"
    msg_lower = str(error).lower()
    if "websocket" in msg_lower or "connection closed abnormally" in msg_lower:
        return True, "WS_ERROR"
    if "1011" in str(error):
        return True, "WS_1011_SERVER_ERROR"
    return False, ""


def report_sidecar_error(
    sidecar: Any,
    session_id: str,
    exc: Exception,
    timestamp_ms: int,
) -> None:
    """Report an error to the sidecar (api error + optional ws error)."""
    sidecar.on_api_error(
        session_id=session_id,
        code=classify_error_code(exc),
        message=str(exc),
        timestamp_ms=timestamp_ms,
    )
    ws_err, ws_type = is_ws_error(exc)
    if ws_err:
        sidecar.on_ws_error(
            session_id=session_id,
            error_type=ws_type,
            timestamp_ms=timestamp_ms,
        )
