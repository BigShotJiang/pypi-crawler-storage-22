"""Zero-code-change auto-instrumentation for Gemini Live API sessions.

Uses ``wrapt`` to monkey-patch ``google.genai.live`` so that every
``AsyncLive.connect()`` session is transparently wrapped with a
:class:`LiveTelemetrySidecar`.

Usage -- explicit::

    from geminiliveotel.auto import instrument, uninstrument
    instrument()      # patches google.genai.live
    uninstrument()    # restores originals

Usage -- zero-code (import-time activation)::

    import geminiliveotel.auto  # patches on import

Configuration via environment variables:

* ``GEMINI_OTEL_ENABLED``       -- "0" or "false" to skip (default: enabled)
* ``GEMINI_OTEL_PROJECT``       -- GCP project ID for Cloud Monitoring exporter
* ``GEMINI_OTEL_REGION``        -- GCP region (default: us-central1)
* ``GEMINI_OTEL_EXPORT``        -- "cloud_monitoring" | "stdout" | "none"
* ``GEMINI_OTEL_TARGET_MODEL``  -- model to instrument (default: gemini-live-2.5-flash-native-audio)
"""

from __future__ import annotations

import logging
import os
import threading
from contextlib import asynccontextmanager
from typing import Any

from geminiliveotel._helpers import (
    extract_call_ids,
    now_ms,
    report_sidecar_error,
    to_payload,
)

logger = logging.getLogger("geminiliveotel.auto")

_lock = threading.Lock()
_instrumented = False

# ---- env-var helpers --------------------------------------------------------

_DEFAULT_TARGET_MODEL = "gemini-live-2.5-flash-native-audio"
_DEFAULT_REGION = "us-central1"


def _env_enabled() -> bool:
    val = os.environ.get("GEMINI_OTEL_ENABLED", "1").strip().lower()
    return val not in ("0", "false", "no")


def _env_project() -> str | None:
    return os.environ.get("GEMINI_OTEL_PROJECT") or None


def _env_region() -> str:
    return os.environ.get("GEMINI_OTEL_REGION", _DEFAULT_REGION).strip()


def _env_export_mode() -> str:
    return os.environ.get("GEMINI_OTEL_EXPORT", "cloud_monitoring").strip().lower()


def _env_target_model() -> str:
    return os.environ.get("GEMINI_OTEL_TARGET_MODEL", _DEFAULT_TARGET_MODEL).strip()


def _env_bool(key: str, default: bool = True) -> bool:
    val = os.environ.get(key, "1" if default else "0").strip().lower()
    return val not in ("0", "false", "no")


def _env_token_counting() -> str:
    val = os.environ.get("GEMINI_OTEL_CUMULATIVE_TOKENS", "0").strip().lower()
    return "cumulative" if val in ("1", "true", "yes") else "incremental"


def _env_int(key: str, default: int) -> int:
    try:
        return int(os.environ.get(key, str(default)))
    except (TypeError, ValueError):
        return default


# ---- shared sidecar (singleton bootstrap) ----------------------------------

_bootstrap_lock = threading.Lock()
_shared_sidecar: Any = None


def _ensure_http_session(http_session: Any, project: str | None) -> Any:
    """Return the existing http_session or create one if needed."""
    if http_session is not None or not project:
        return http_session
    from geminiliveotel.bootstrap import build_authorized_session
    return build_authorized_session()


def _make_sidecar() -> Any:
    """Return the shared sidecar, creating it (and running full bootstrap) on first call.

    The first invocation performs the same work as
    ``bootstrap_vertex_live_observability()``:

    1. Create a single ``LiveTelemetrySidecar`` (shared across all sessions)
    2. Fetch concurrency quota from the Quota API
    3. Start the Cloud Monitoring metric exporter
    4. Create the Cloud Monitoring dashboard

    Subsequent calls return the same sidecar instance.  All steps are
    fail-open -- errors are logged but never propagate.
    """
    global _shared_sidecar

    with _bootstrap_lock:
        if _shared_sidecar is not None:
            return _shared_sidecar

        from geminiliveotel.sidecar import LiveTelemetrySidecar

        target_model = _env_target_model()
        region = _env_region()
        project = _env_project()
        export_mode = _env_export_mode()
        auto_dashboard = _env_bool("GEMINI_OTEL_DASHBOARD")
        auto_quota = _env_bool("GEMINI_OTEL_QUOTA")
        fallback_quota = _env_int("GEMINI_OTEL_FALLBACK_QUOTA", 1000)
        flush_interval = _env_int("GEMINI_OTEL_FLUSH_INTERVAL", 5)
        group_by_session = _env_bool("GEMINI_OTEL_GROUP_BY_SESSION", default=False)
        token_counting = _env_token_counting()
        rate_window = _env_int("GEMINI_OTEL_RATE_WINDOW", 60)

        # ---- 1. Fetch concurrency quota ------------------------------------
        resolved_quota = fallback_quota
        http_session = None
        if auto_quota and project:
            try:
                from geminiliveotel.bootstrap import fetch_native_audio_concurrency_quota

                http_session = _ensure_http_session(http_session, project)
                resolved_quota = fetch_native_audio_concurrency_quota(
                    project_id=project,
                    region=region,
                    target_model=target_model,
                    fallback=fallback_quota,
                    session=http_session,
                )
                logger.info(
                    "Fetched concurrency quota: %s (project=%s, region=%s)",
                    resolved_quota, project, region,
                )
            except Exception:
                logger.warning(
                    "Failed to fetch concurrency quota; using fallback=%s",
                    fallback_quota,
                    exc_info=True,
                )

        # ---- 2. Create shared sidecar --------------------------------------
        sidecar = LiveTelemetrySidecar(
            target_model=target_model,
            region=region,
            concurrency_quota=resolved_quota,
            token_counting=token_counting,
            rate_window_sec=rate_window,
        )

        # ---- 3. Start metric exporter --------------------------------------
        if export_mode == "cloud_monitoring" and project:
            try:
                from geminiliveotel.exporter import CloudMonitoringMetricExporter

                http_session = _ensure_http_session(http_session, project)
                exporter = CloudMonitoringMetricExporter(
                    project_id=project,
                    session=http_session,
                    flush_interval_sec=flush_interval,
                )
                exporter.start(sidecar, start_background=True)
                sidecar.attach_exporter(exporter)
                import atexit
                atexit.register(exporter.stop)
                logger.info("Cloud Monitoring metric exporter started")
            except Exception:
                logger.warning(
                    "Failed to start Cloud Monitoring exporter; "
                    "continuing without metric export.",
                    exc_info=True,
                )
        elif export_mode == "stdout":
            logger.info("GEMINI_OTEL_EXPORT=stdout: metrics will be logged to stdout")

        # ---- 4. Create dashboard -------------------------------------------
        if auto_dashboard and project:
            try:
                from geminiliveotel.bootstrap import create_monitoring_dashboard
                from geminiliveotel.dashboard import build_dashboard_spec

                http_session = _ensure_http_session(http_session, project)
                dashboard_spec = build_dashboard_spec(
                    project_id=project,
                    region=region,
                    group_by_session_id=group_by_session,
                )
                dashboard_response = create_monitoring_dashboard(
                    project_id=project,
                    dashboard_spec=dashboard_spec,
                    session=http_session,
                )
                logger.info(
                    "Dashboard created: %s",
                    dashboard_response.get("displayName")
                    or dashboard_response.get("name"),
                )
            except Exception:
                logger.warning(
                    "Failed to create monitoring dashboard; continuing without dashboard.",
                    exc_info=True,
                )

        _shared_sidecar = sidecar
        return sidecar


# ---- wrapt wrappers --------------------------------------------------------


def _get_sidecar(session: Any) -> Any | None:
    """Retrieve the sidecar attached to a session, or None."""
    return getattr(session, "_otel_sidecar", None)


def _get_session_id(session: Any) -> str:
    return str(getattr(session, "session_id", id(session)))


def _safe_report_error(sidecar: Any, session_id: str, exc: Exception) -> None:
    """Wrapper around report_sidecar_error that swallows exceptions."""
    try:
        report_sidecar_error(sidecar, session_id, exc, now_ms())
    except Exception:
        logger.debug("sidecar error reporting failed", exc_info=True)


def _wrap_connect(wrapped: Any, instance: Any, args: tuple, kwargs: dict) -> Any:
    """Wrapper for AsyncLive.connect() async context manager."""

    @asynccontextmanager
    async def _instrumented_connect():
        connect_start_ms = now_ms()
        async with wrapped(*args, **kwargs) as session:
            connect_duration_ms = now_ms() - connect_start_ms
            try:
                sidecar = _make_sidecar()
                session._otel_sidecar = sidecar

                session_id = _get_session_id(session)
                actual_model = kwargs.get("model") or ""
                region = _env_region()

                # Determine VAD mode from the config if available
                config = kwargs.get("config", None)
                if config is None and args:
                    config = args[0] if args else None
                automatic_vad = True  # default
                if config is not None:
                    # config might be a dict or a Pydantic model
                    if isinstance(config, dict):
                        rt = config.get("realtime_input_config") or config.get("realtimeInputConfig") or {}
                        if isinstance(rt, dict):
                            automatic_vad = rt.get("automatic_activity_detection", {}).get("disabled", False) is False
                    elif hasattr(config, "realtime_input_config"):
                        rt = getattr(config, "realtime_input_config", None)
                        if rt and hasattr(rt, "automatic_activity_detection"):
                            aad = getattr(rt, "automatic_activity_detection", None)
                            if aad and getattr(aad, "disabled", False):
                                automatic_vad = False

                accepted = sidecar.on_session_started(
                    session_id=session_id,
                    model=actual_model,
                    region=region,
                    automatic_vad=automatic_vad,
                    timestamp_ms=now_ms(),
                    connect_duration_ms=float(connect_duration_ms),
                )
                if not accepted:
                    session._otel_sidecar = None
            except Exception:
                logger.warning(
                    "Failed to attach OTel sidecar to session; "
                    "continuing without instrumentation.",
                    exc_info=True,
                )
            try:
                yield session
            finally:
                sidecar = _get_sidecar(session)
                if sidecar is not None:
                    session_id = _get_session_id(session)
                    try:
                        sidecar.on_session_closed(
                            session_id=session_id,
                            timestamp_ms=now_ms(),
                        )
                    except Exception:
                        logger.debug("sidecar.on_session_closed failed", exc_info=True)

    return _instrumented_connect()


def _parse_sample_rate(mime_type: str) -> int | None:
    """Parse sample rate from MIME type like 'audio/pcm;rate=16000'."""
    for part in mime_type.split(";"):
        part = part.strip().lower()
        if part.startswith("rate="):
            try:
                return int(part[5:])
            except ValueError:
                return None
    return None


def _extract_audio_chunk_info(kwargs: dict) -> tuple[int | None, int | None]:
    """Extract audio chunk bytes and duration from send_realtime_input kwargs."""
    audio = kwargs.get("audio")
    if audio is None:
        return None, None
    # Extract raw bytes from Blob-like object or dict
    if isinstance(audio, bytes):
        data = audio
        mime_type = ""
    elif isinstance(audio, dict):
        data = audio.get("data", b"")
        mime_type = audio.get("mime_type", "") or ""
    else:
        data = getattr(audio, "data", None) or b""
        mime_type = getattr(audio, "mime_type", None) or ""
    if not isinstance(data, (bytes, bytearray)):
        return None, None
    chunk_bytes = len(data) if data else None
    # Try to compute duration from PCM sample rate
    chunk_duration_ms = None
    if chunk_bytes and mime_type:
        rate = _parse_sample_rate(mime_type)
        if rate and rate > 0:
            bytes_per_sample = 2  # 16-bit PCM
            chunk_duration_ms = int((chunk_bytes / (rate * bytes_per_sample)) * 1000)
    return chunk_bytes, chunk_duration_ms


def _wrap_send_realtime_input(wrapped: Any, instance: Any, args: tuple, kwargs: dict) -> Any:
    """Wrapper for AsyncSession.send_realtime_input()."""
    sidecar = _get_sidecar(instance)
    session_id = _get_session_id(instance) if sidecar is not None else None

    # Strip otel-specific kwargs that the original SDK method does not accept.
    audio_chunk_duration_ms = kwargs.pop("audio_chunk_duration_ms", None)
    audio_chunk_bytes = kwargs.pop("audio_chunk_bytes", None)

    # Auto-compute from raw audio when not explicitly provided
    if audio_chunk_bytes is None or audio_chunk_duration_ms is None:
        auto_bytes, auto_duration = _extract_audio_chunk_info(kwargs)
        if audio_chunk_bytes is None:
            audio_chunk_bytes = auto_bytes
        if audio_chunk_duration_ms is None:
            audio_chunk_duration_ms = auto_duration

    if sidecar is not None:
        activity_start = kwargs.get("activity_start") is not None
        activity_end = kwargs.get("activity_end") is not None
        try:
            sidecar.on_client_request(
                session_id=session_id,
                request_type="realtime_input",
                timestamp_ms=now_ms(),
                audio_chunk_duration_ms=audio_chunk_duration_ms,
                audio_chunk_bytes=audio_chunk_bytes,
                activity_start=activity_start,
                activity_end=activity_end,
            )
        except Exception:
            logger.debug("sidecar.on_client_request failed", exc_info=True)

    async def _call():
        try:
            return await wrapped(*args, **kwargs)
        except Exception as exc:
            if sidecar is not None:
                _safe_report_error(sidecar, session_id, exc)
            raise

    return _call()


def _wrap_send_client_content(wrapped: Any, instance: Any, args: tuple, kwargs: dict) -> Any:
    """Wrapper for AsyncSession.send_client_content()."""
    sidecar = _get_sidecar(instance)
    tool_call_ids = kwargs.pop("__otel_tool_call_ids", None)

    if sidecar is not None:
        session_id = _get_session_id(instance)
        try:
            sidecar.on_client_request(
                session_id=session_id,
                request_type="client_content",
                timestamp_ms=now_ms(),
            )
        except Exception:
            logger.debug("sidecar.on_client_request failed", exc_info=True)

    async def _call():
        try:
            result = await wrapped(*args, **kwargs)
            if sidecar is not None and tool_call_ids:
                normalized = [str(cid) for cid in tool_call_ids if cid is not None]
                if normalized:
                    try:
                        sidecar.on_tool_response(
                            session_id=session_id,
                            call_ids=normalized,
                            timestamp_ms=now_ms(),
                        )
                    except Exception:
                        logger.debug("sidecar.on_tool_response failed", exc_info=True)
            return result
        except Exception as exc:
            if sidecar is not None:
                _safe_report_error(sidecar, session_id, exc)
            raise

    return _call()


def _wrap_send_tool_response(wrapped: Any, instance: Any, args: tuple, kwargs: dict) -> Any:
    """Wrapper for AsyncSession.send_tool_response()."""
    sidecar = _get_sidecar(instance)
    session_id = _get_session_id(instance) if sidecar is not None else None

    call_ids: list[str] | None = None
    if sidecar is not None:
        function_responses = kwargs.get("function_responses") or (args[0] if args else None)
        call_ids = extract_call_ids(function_responses)

    async def _call():
        try:
            result = await wrapped(*args, **kwargs)
            if sidecar is not None and call_ids:
                try:
                    sidecar.on_tool_response(
                        session_id=session_id,
                        call_ids=call_ids,
                        timestamp_ms=now_ms(),
                    )
                except Exception:
                    logger.debug("sidecar.on_tool_response failed", exc_info=True)
            return result
        except Exception as exc:
            if sidecar is not None:
                _safe_report_error(sidecar, session_id, exc)
            raise

    return _call()


def _wrap_receive(wrapped: Any, instance: Any, args: tuple, kwargs: dict) -> Any:
    """Wrapper for AsyncSession.receive() -- wraps the async generator."""
    sidecar = _get_sidecar(instance)

    async def _instrumented_receive():
        try:
            async for message in wrapped(*args, **kwargs):
                if sidecar is not None:
                    session_id = _get_session_id(instance)
                    try:
                        payload = to_payload(message)
                        sidecar.on_server_message(
                            session_id=session_id,
                            message=payload,
                            timestamp_ms=now_ms(),
                        )
                    except Exception:
                        logger.debug("sidecar.on_server_message failed", exc_info=True)
                yield message
        except Exception as exc:
            if sidecar is not None:
                _safe_report_error(sidecar, _get_session_id(instance), exc)
            raise

    return _instrumented_receive()


def _wrap_receive_single(wrapped: Any, instance: Any, args: tuple, kwargs: dict) -> Any:
    """Wrapper for AsyncSession._receive() -- single-message receive."""
    sidecar = _get_sidecar(instance)

    async def _call():
        try:
            message = await wrapped(*args, **kwargs)
            if sidecar is not None and message is not None:
                session_id = _get_session_id(instance)
                try:
                    payload = to_payload(message)
                    sidecar.on_server_message(
                        session_id=session_id,
                        message=payload,
                        timestamp_ms=now_ms(),
                    )
                except Exception:
                    logger.debug("sidecar.on_server_message failed", exc_info=True)
            return message
        except Exception as exc:
            if sidecar is not None:
                _safe_report_error(sidecar, _get_session_id(instance), exc)
            raise

    return _call()


def _wrap_close(wrapped: Any, instance: Any, args: tuple, kwargs: dict) -> Any:
    """Wrapper for AsyncSession.close()."""
    sidecar = _get_sidecar(instance)
    if sidecar is not None:
        session_id = _get_session_id(instance)
        try:
            sidecar.on_session_closed(
                session_id=session_id,
                timestamp_ms=now_ms(),
            )
        except Exception:
            logger.debug("sidecar.on_session_closed failed", exc_info=True)

    return wrapped(*args, **kwargs)


# ---- public API -------------------------------------------------------------


def instrument() -> bool:
    """Patch ``google.genai.live`` to auto-instrument Gemini Live sessions.

    Returns True if patching was applied, False if skipped or already applied.
    """
    global _instrumented

    if not _env_enabled():
        logger.info("Auto-instrumentation disabled via GEMINI_OTEL_ENABLED")
        return False

    with _lock:
        if _instrumented:
            return False

        try:
            import wrapt  # noqa: F811
        except ImportError:
            logger.warning(
                "wrapt is not installed; auto-instrumentation unavailable. "
                "Install with: pip install wrapt"
            )
            return False

        try:
            import google.genai.live  # noqa: F401 -- ensure module is importable
        except ImportError:
            logger.warning(
                "google.genai.live is not importable; "
                "auto-instrumentation unavailable."
            )
            return False

        try:
            wrapt.wrap_function_wrapper(
                "google.genai.live", "AsyncLive.connect", _wrap_connect
            )
            wrapt.wrap_function_wrapper(
                "google.genai.live", "AsyncSession.send_realtime_input",
                _wrap_send_realtime_input,
            )
            wrapt.wrap_function_wrapper(
                "google.genai.live", "AsyncSession.send_client_content",
                _wrap_send_client_content,
            )
            wrapt.wrap_function_wrapper(
                "google.genai.live", "AsyncSession.send_tool_response",
                _wrap_send_tool_response,
            )
            wrapt.wrap_function_wrapper(
                "google.genai.live", "AsyncSession.receive",
                _wrap_receive,
            )
            wrapt.wrap_function_wrapper(
                "google.genai.live", "AsyncSession._receive",
                _wrap_receive_single,
            )
            wrapt.wrap_function_wrapper(
                "google.genai.live", "AsyncSession.close",
                _wrap_close,
            )
            _instrumented = True
            logger.info("Gemini Live auto-instrumentation applied")

            return True
        except Exception:
            logger.warning(
                "Failed to apply wrapt patches for Gemini Live; "
                "continuing without auto-instrumentation.",
                exc_info=True,
            )
            return False


def update_quota(new_quota: int) -> bool:
    """Update the concurrency quota on the shared sidecar.

    Returns True if the update was applied, False if no sidecar exists.
    """
    sidecar = _shared_sidecar
    if sidecar is None:
        return False
    sidecar.update_quota(new_quota)
    logger.info("Concurrency quota updated to %s", new_quota)
    return True


def uninstrument() -> bool:
    """Remove all wrapt patches applied by :func:`instrument`.

    Returns True if patches were removed, False if nothing was patched.
    """
    global _instrumented

    with _lock:
        if not _instrumented:
            return False

        try:
            import google.genai.live as live_module

            _targets = [
                (live_module.AsyncLive, "connect"),
                (live_module.AsyncSession, "send_realtime_input"),
                (live_module.AsyncSession, "send_client_content"),
                (live_module.AsyncSession, "send_tool_response"),
                (live_module.AsyncSession, "receive"),
                (live_module.AsyncSession, "_receive"),
                (live_module.AsyncSession, "close"),
            ]
            for cls, method_name in _targets:
                current = getattr(cls, method_name, None)
                if current is not None and hasattr(current, "__wrapped__"):
                    setattr(cls, method_name, current.__wrapped__)

            _instrumented = False

            # Stop the exporter before clearing the shared sidecar.
            global _shared_sidecar
            if _shared_sidecar is not None:
                exporter = getattr(_shared_sidecar, '_exporter', None)
                if exporter is not None and hasattr(exporter, 'stop'):
                    try:
                        exporter.stop()
                    except Exception:
                        logger.debug("Failed to stop exporter", exc_info=True)

            # Reset the shared sidecar so a subsequent instrument() call
            # creates a fresh bootstrap (new dashboard, new quota fetch).
            _shared_sidecar = None

            logger.info("Gemini Live auto-instrumentation removed")
            return True
        except Exception:
            logger.warning(
                "Failed to remove wrapt patches",
                exc_info=True,
            )
            return False


# ---- auto-activate on import ------------------------------------------------

instrument()
