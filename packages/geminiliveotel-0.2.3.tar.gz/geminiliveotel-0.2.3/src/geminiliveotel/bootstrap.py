from __future__ import annotations

import atexit
import logging
from dataclasses import dataclass
from typing import Any, Literal

import google.auth
from google.auth.transport.requests import AuthorizedSession

from geminiliveotel._helpers import HttpSession
from geminiliveotel.dashboard import TARGET_MODEL, build_dashboard_spec
from geminiliveotel.exporter import CloudMonitoringMetricExporter
from geminiliveotel.sidecar import LiveTelemetrySidecar


@dataclass(frozen=True)
class BootstrapResult:
    sidecar: LiveTelemetrySidecar
    resolved_concurrency_quota: int
    quota_source: str
    dashboard_name: str | None
    dashboard_display_name: str | None
    metrics_export_enabled: bool


def _default_logger() -> logging.Logger:
    return logging.getLogger("geminiliveotel.bootstrap")


def build_authorized_session() -> AuthorizedSession:
    credentials, _ = google.auth.default(
        scopes=["https://www.googleapis.com/auth/cloud-platform"]
    )
    return AuthorizedSession(credentials)


def _candidate_score(text: str) -> int:
    score = 0
    for token in ("live", "concurrent", "session", "request", "req"):
        if token in text:
            score += 3
    for token in ("native", "audio", "bidi", "base_model", "base model"):
        if token in text:
            score += 2
    for token in ("training", "pipeline", "batch_prediction", "automl"):
        if token in text:
            score -= 4
    return score


def _to_int(value: Any) -> int | None:
    try:
        converted = int(float(str(value)))
    except (TypeError, ValueError):
        return None
    return converted if converted > 0 else None


def _normalize_text(value: str | None) -> str:
    return str(value or "").strip().lower()


def _model_match_score(dimensions: dict[str, Any], target_model: str) -> int:
    if not target_model:
        return 0
    target = _normalize_text(target_model)
    if not target:
        return 0

    for key in ("base_model", "baseModel", "base_model_id", "baseModelId", "model", "model_id"):
        value = _normalize_text(str(dimensions.get(key) or ""))
        if not value:
            continue
        if value == target:
            return 100
        if target in value or value in target:
            return 60
        if "gemini-live" in value and "native-audio" in target:
            return -30
    return 0


def _extract_best_limit(
    payload: dict[str, Any],
    region: str,
    target_model: str,
    exact_metric_name: str | None = None,
) -> int | None:
    best_score = -1
    best_value: int | None = None
    metrics = payload.get("metrics") or []

    # Fast path: exact metric name match
    if exact_metric_name:
        for metric in metrics:
            metric_path = str(metric.get("metric", ""))
            if exact_metric_name not in metric_path:
                continue
            limits = metric.get("consumerQuotaLimits") or []
            for limit in limits:
                buckets = limit.get("quotaBuckets") or []
                for bucket in buckets:
                    limit_value = _to_int(bucket.get("effectiveLimit"))
                    if limit_value is not None:
                        return limit_value

    for metric in metrics:
        metric_text = " ".join(
            [
                str(metric.get("metric", "")),
                str(metric.get("displayName", "")),
                str(metric.get("unit", "")),
            ]
        ).lower()

        limits = metric.get("consumerQuotaLimits") or []
        for limit in limits:
            limit_text = (
                metric_text
                + " "
                + str(limit.get("displayName", ""))
                + " "
                + str(limit.get("name", ""))
                + " "
                + str(limit.get("unit", ""))
            ).lower()

            buckets = limit.get("quotaBuckets") or []
            for bucket in buckets:
                dimensions = bucket.get("dimensions") or {}
                bucket_region = str(
                    dimensions.get("region")
                    or dimensions.get("locations")
                    or dimensions.get("location")
                    or ""
                ).strip()
                if bucket_region and bucket_region not in {"*", region}:
                    continue

                score = _candidate_score(limit_text)
                if bucket_region == region:
                    score += 12
                elif bucket_region == "*":
                    score += 4

                score += _model_match_score(dimensions, target_model)
                if score < 9:
                    continue

                limit_value = _to_int(bucket.get("effectiveLimit"))
                if limit_value is None:
                    continue

                if score > best_score:
                    best_score = score
                    best_value = limit_value

    return best_value


def fetch_native_audio_concurrency_quota(
    *,
    project_id: str,
    region: str,
    target_model: str = TARGET_MODEL,
    fallback: int = 1000,
    session: HttpSession | None = None,
    logger: logging.Logger | None = None,
    metric_name: str | None = None,
    api_version: str = "v1beta1",
) -> int:
    resolved_logger = logger or _default_logger()
    http = session or build_authorized_session()

    base_url = (
        f"https://serviceusage.googleapis.com/{api_version}/projects/"
        f"{project_id}/services/aiplatform.googleapis.com/consumerQuotaMetrics"
    )
    page_token: str | None = None
    best_value: int | None = None

    try:
        while True:
            params = {
                "view": "FULL",
                "pageSize": "200",
            }
            if page_token:
                params["pageToken"] = page_token

            response = http.get(base_url, params=params, timeout=30)
            if response.status_code >= 400:
                raise RuntimeError(
                    f"Quota API returned {response.status_code}: {response.text}"
                )

            payload = response.json()
            candidate = _extract_best_limit(payload, region, target_model, exact_metric_name=metric_name)
            if candidate is not None:
                best_value = max(best_value or 0, candidate)

            page_token = payload.get("nextPageToken")
            if not page_token:
                break
    except Exception as exc:  # pragma: no cover - defensive warning path
        resolved_logger.warning(
            "Failed to fetch Vertex Live concurrency quota from Quota API; "
            "using fallback=%s. Error=%s",
            fallback,
            exc,
        )
        return fallback

    if best_value is None:
        resolved_logger.warning(
            "Could not resolve Vertex Live concurrency quota from Quota API; "
            "using fallback=%s.",
            fallback,
        )
        return fallback

    return best_value


def create_monitoring_dashboard(
    *,
    project_id: str,
    dashboard_spec: dict[str, Any],
    session: HttpSession | None = None,
) -> dict[str, Any]:
    http = session or build_authorized_session()
    url = f"https://monitoring.googleapis.com/v1/projects/{project_id}/dashboards"
    response = http.post(url, json=dashboard_spec, timeout=30)
    if response.status_code >= 400:
        raise RuntimeError(
            f"Dashboard create failed with {response.status_code}: {response.text}"
        )
    return response.json()


def bootstrap_vertex_live_observability(
    *,
    project_id: str,
    region: str,
    target_model: str = TARGET_MODEL,
    fallback_concurrency_quota: int = 1000,
    auto_fetch_quota: bool = True,
    auto_create_dashboard: bool = True,
    auto_export_metrics: bool = True,
    metrics_flush_interval_sec: int = 5,
    start_export_background: bool = True,
    group_by_session_id: bool = False,
    token_counting: Literal["incremental", "cumulative"] = "incremental",
    rate_window_sec: int = 60,
    display_name_prefix: str = "Gemini Live Native Audio OTel Dashboard",
    session: HttpSession | None = None,
    logger: logging.Logger | None = None,
) -> BootstrapResult:
    resolved_logger = logger or _default_logger()
    http = session or build_authorized_session()

    quota_source = "fallback"
    if auto_fetch_quota:
        resolved_quota = fetch_native_audio_concurrency_quota(
            project_id=project_id,
            region=region,
            target_model=target_model,
            fallback=fallback_concurrency_quota,
            session=http,
            logger=resolved_logger,
        )
        if resolved_quota != fallback_concurrency_quota:
            quota_source = "api"
    else:
        resolved_quota = fallback_concurrency_quota

    sidecar = LiveTelemetrySidecar(
        target_model=target_model,
        region=region,
        concurrency_quota=resolved_quota,
        token_counting=token_counting,
        rate_window_sec=rate_window_sec,
    )

    metrics_export_enabled = False
    if auto_export_metrics:
        try:
            exporter = CloudMonitoringMetricExporter(
                project_id=project_id,
                session=http,
                flush_interval_sec=metrics_flush_interval_sec,
                logger=resolved_logger,
            )
            exporter.start(sidecar, start_background=start_export_background)
            sidecar.attach_exporter(exporter)
            atexit.register(exporter.stop)
            metrics_export_enabled = True
        except Exception as exc:  # pragma: no cover - fail-open protection
            resolved_logger.warning(
                "Failed to initialize Cloud Monitoring metrics exporter; "
                "continuing without metric export. Error=%s",
                exc,
            )

    dashboard_name: str | None = None
    dashboard_display_name: str | None = None
    if auto_create_dashboard:
        try:
            dashboard_spec = build_dashboard_spec(
                project_id=project_id,
                region=region,
                display_name_prefix=display_name_prefix,
                group_by_session_id=group_by_session_id,
            )
            dashboard_response = create_monitoring_dashboard(
                project_id=project_id,
                dashboard_spec=dashboard_spec,
                session=http,
            )
            dashboard_name = dashboard_response.get("name")
            dashboard_display_name = dashboard_response.get("displayName")
        except Exception as exc:  # pragma: no cover - fail-open protection
            resolved_logger.warning(
                "Failed to auto-create monitoring dashboard; continuing without dashboard. Error=%s",
                exc,
            )

    return BootstrapResult(
        sidecar=sidecar,
        resolved_concurrency_quota=resolved_quota,
        quota_source=quota_source,
        dashboard_name=dashboard_name,
        dashboard_display_name=dashboard_display_name,
        metrics_export_enabled=metrics_export_enabled,
    )
