from __future__ import annotations

from datetime import datetime, timezone
from uuid import uuid4


TARGET_MODEL = "gemini-live-2.5-flash-native-audio"
SESSION_GROUP_FIELD = "metric.label.session_id"


def generate_dashboard_display_name(
    prefix: str = "Gemini Live Native Audio OTel Dashboard",
) -> str:
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    suffix = uuid4().hex[:8]
    return f"{prefix} {timestamp}-{suffix}"


def _filter_for(metric_name: str, region: str) -> str:
    return (
        f'metric.type = "custom.googleapis.com/geminilive/{metric_name}" '
        f'AND metric.label.model_id = "{TARGET_MODEL}" '
        f'AND metric.label.region = "{region}"'
    )


def _build_group_fields(
    *,
    group_by_session_id: bool,
    session_groupable: bool,
    extra_fields: list[str] | None = None,
) -> list[str]:
    fields = list(extra_fields or [])
    if group_by_session_id and session_groupable:
        fields.append(SESSION_GROUP_FIELD)
    return list(dict.fromkeys(fields))


def _aggregation(
    *,
    aligner: str,
    reducer: str,
    group_by_fields: list[str] | None = None,
) -> dict:
    return {
        "alignmentPeriod": "60s",
        "perSeriesAligner": aligner,
        "crossSeriesReducer": reducer,
        "groupByFields": group_by_fields or [],
    }


def _xy_tile(
    *,
    title: str,
    metric_name: str,
    region: str,
    session_groupable: bool,
    group_by_session_id: bool,
    plot_type: str = "LINE",
    aligner: str = "ALIGN_MEAN",
    reducer: str = "REDUCE_MEAN",
    legend: str | None = None,
    extra_group_by_fields: list[str] | None = None,
    x_pos: int = 0,
    y_pos: int = 0,
    width: int = 12,
    height: int = 8,
    unit_label: str | None = None,
) -> dict:
    group_fields = _build_group_fields(
        group_by_session_id=group_by_session_id,
        session_groupable=session_groupable,
        extra_fields=extra_group_by_fields,
    )
    return {
        "xPos": x_pos,
        "yPos": y_pos,
        "width": width,
        "height": height,
        "widget": {
            "title": title,
            "xyChart": {
                "dataSets": [
                    {
                        "plotType": plot_type,
                        "legendTemplate": legend or metric_name,
                        "timeSeriesQuery": {
                            "timeSeriesFilter": {
                                "filter": _filter_for(metric_name, region),
                                "aggregation": _aggregation(
                                    aligner=aligner,
                                    reducer=reducer,
                                    group_by_fields=group_fields,
                                ),
                                "secondaryAggregation": _aggregation(
                                    aligner="ALIGN_MEAN",
                                    reducer="REDUCE_MEAN",
                                    group_by_fields=group_fields,
                                ),
                            }
                        },
                    }
                ],
                "timeshiftDuration": "0s",
                "yAxis": {
                    "label": unit_label or title,
                    "scale": "LINEAR",
                },
            },
        },
    }


def _percentile_tile(
    *,
    title: str,
    metric_name: str,
    region: str,
    group_by_session_id: bool,
    x_pos: int,
    y_pos: int,
    width: int = 24,
    height: int = 8,
) -> dict:
    group_fields = _build_group_fields(
        group_by_session_id=group_by_session_id,
        session_groupable=True,
    )
    data_sets = [
        {
            "plotType": "LINE",
            "legendTemplate": quantile,
            "timeSeriesQuery": {
                "timeSeriesFilter": {
                    "filter": _filter_for(metric_name, region),
                    "aggregation": _aggregation(
                        aligner=aligner,
                        reducer="REDUCE_MEAN",
                        group_by_fields=group_fields,
                    ),
                    "secondaryAggregation": _aggregation(
                        aligner="ALIGN_MEAN",
                        reducer="REDUCE_MEAN",
                        group_by_fields=group_fields,
                    ),
                }
            },
        }
        for quantile, aligner in (
            ("p50", "ALIGN_PERCENTILE_50"),
            ("p95", "ALIGN_PERCENTILE_95"),
            ("p99", "ALIGN_PERCENTILE_99"),
        )
    ]

    return {
        "xPos": x_pos,
        "yPos": y_pos,
        "width": width,
        "height": height,
        "widget": {
            "title": title,
            "xyChart": {
                "dataSets": data_sets,
                "timeshiftDuration": "0s",
                "yAxis": {
                    "label": "ms",
                    "scale": "LINEAR",
                },
            },
        },
    }


def _section_header_tile(
    *,
    title: str,
    subtitle: str = "",
    x_pos: int = 0,
    y_pos: int = 0,
    width: int = 48,
    height: int = 4,
) -> dict:
    header: dict = {"dividerBelow": True}
    if subtitle:
        header["subtitle"] = subtitle
    return {
        "xPos": x_pos,
        "yPos": y_pos,
        "width": width,
        "height": height,
        "widget": {
            "title": title,
            "sectionHeader": header,
        },
    }


def _scorecard_tile(
    *,
    title: str,
    metric_name: str,
    region: str,
    x_pos: int,
    y_pos: int,
    width: int = 12,
    height: int = 6,
    sparkline: bool = False,
) -> dict:
    scorecard: dict = {
        "timeSeriesQuery": {
            "timeSeriesFilter": {
                "filter": _filter_for(metric_name, region),
                "aggregation": _aggregation(
                    aligner="ALIGN_DELTA",
                    reducer="REDUCE_SUM",
                    group_by_fields=[],
                ),
                "secondaryAggregation": _aggregation(
                    aligner="ALIGN_SUM",
                    reducer="REDUCE_SUM",
                    group_by_fields=[],
                ),
            }
        },
    }
    if sparkline:
        scorecard["sparkChartView"] = {"sparkChartType": "SPARK_LINE"}
    return {
        "xPos": x_pos,
        "yPos": y_pos,
        "width": width,
        "height": height,
        "widget": {
            "title": title,
            "scorecard": scorecard,
        },
    }


# ── Dashboard layout spec ──────────────────────────────────────────────────
# Each section: (header_title, header_subtitle, rows)
# Each row: (row_height, tile_specs)
# tile_spec: (type, {params...})

_SECTIONS = [
    ("Key Metrics", "Real-time overview", [
        (6, [
            ("scorecard", {"title": "Turns Completed (Counter)", "metric_name": "geminilive_turn_complete_total", "x_pos": 0, "width": 12, "sparkline": True}),
            ("scorecard", {"title": "Successful Responses (Counter)", "metric_name": "geminilive_successful_model_responses_total", "x_pos": 12, "width": 12, "sparkline": True}),
            ("scorecard", {"title": "API Errors (Counter)", "metric_name": "geminilive_api_errors_total", "x_pos": 24, "width": 12, "sparkline": True}),
            ("scorecard", {"title": "Tool Calls (Counter)", "metric_name": "geminilive_tool_calls_total", "x_pos": 36, "width": 12, "sparkline": True}),
        ]),
    ]),
    ("Latency", "Response time percentiles", [
        (8, [
            ("percentile", {"title": "TTFAB (p50/p95/p99)", "metric_name": "geminilive_ttfab_ms", "x_pos": 0}),
            ("percentile", {"title": "Turn End-to-End Latency (p50/p95/p99)", "metric_name": "geminilive_turn_e2e_latency_ms", "x_pos": 24}),
        ]),
        (8, [
            ("percentile", {"title": "WS Connect Latency (p50/p95/p99)", "metric_name": "geminilive_ws_connect_latency_ms", "x_pos": 0, "width": 24}),
        ]),
    ]),
    ("Tool & Audio", "Tool call performance and audio compliance", [
        (8, [
            ("xy", {"title": "Tool Call Roundtrip Latency", "metric_name": "geminilive_tool_call_roundtrip_ms", "session_groupable": True, "x_pos": 0, "width": 16, "aligner": "ALIGN_PERCENTILE_95", "reducer": "REDUCE_MEAN", "legend": "p95 latency", "extra_group_by_fields": ["metric.label.function_name"], "unit_label": "ms"}),
            ("xy", {"title": "Model Wait After Tool Response", "metric_name": "geminilive_model_wait_after_tool_ms", "session_groupable": True, "x_pos": 16, "width": 16, "aligner": "ALIGN_PERCENTILE_95", "reducer": "REDUCE_MEAN", "legend": "p95 wait", "unit_label": "ms"}),
            ("xy", {"title": "Audio Chunk Duration Distribution", "metric_name": "geminilive_input_audio_chunk_duration_ms", "session_groupable": True, "x_pos": 32, "width": 16, "aligner": "ALIGN_PERCENTILE_95", "reducer": "REDUCE_MEAN", "legend": "p95 duration", "unit_label": "ms"}),
        ]),
        (8, [
            ("xy", {"title": "Audio Chunk Size Distribution", "metric_name": "geminilive_input_audio_chunk_bytes", "session_groupable": True, "x_pos": 0, "width": 16, "aligner": "ALIGN_PERCENTILE_95", "reducer": "REDUCE_MEAN", "legend": "p95 chunk size", "unit_label": "bytes"}),
        ]),
    ]),
    ("Traffic & Health", "Throughput, concurrency and success rates", [
        (8, [
            ("xy", {"title": "Audio Chunk Noncompliance Rate", "metric_name": "geminilive_input_audio_chunk_noncompliant_total", "session_groupable": True, "x_pos": 0, "width": 12, "aligner": "ALIGN_RATE", "reducer": "REDUCE_SUM", "legend": "noncompliant chunks/s", "unit_label": "count/s"}),
            ("xy", {"title": "Token Throughput (tokens/sec)", "metric_name": "geminilive_token_throughput_tps", "session_groupable": True, "x_pos": 12, "width": 12, "aligner": "ALIGN_MEAN", "reducer": "REDUCE_MEAN", "legend": "tokens/s", "unit_label": "tokens/s"}),
            ("xy", {"title": "Request QPS", "metric_name": "geminilive_request_qps", "session_groupable": True, "x_pos": 24, "width": 12, "aligner": "ALIGN_MEAN", "reducer": "REDUCE_MEAN", "legend": "req/s", "unit_label": "req/s"}),
            ("xy", {"title": "Concurrent Sessions", "metric_name": "geminilive_concurrent_sessions", "session_groupable": False, "x_pos": 36, "width": 12, "aligner": "ALIGN_MAX", "reducer": "REDUCE_MAX", "legend": "sessions", "extra_group_by_fields": ["metric.label.model_id", "metric.label.region"], "unit_label": "sessions"}),
        ]),
        (8, [
            ("xy", {"title": "Quota Utilization (%)", "metric_name": "geminilive_concurrency_quota_utilization_pct", "session_groupable": False, "x_pos": 0, "width": 24, "aligner": "ALIGN_MAX", "reducer": "REDUCE_MAX", "legend": "quota %", "extra_group_by_fields": ["metric.label.model_id", "metric.label.region"], "unit_label": "%"}),
            ("xy", {"title": "Model Success Rate", "metric_name": "geminilive_model_success_rate", "session_groupable": True, "x_pos": 24, "width": 24, "aligner": "ALIGN_MEAN", "reducer": "REDUCE_MEAN", "legend": "success rate", "unit_label": "ratio"}),
        ]),
    ]),
    ("Counters", "Cumulative event totals", [
        (6, [
            ("scorecard", {"title": "Total Tokens (Counter)", "metric_name": "geminilive_total_tokens_total", "x_pos": 0, "width": 12}),
            ("scorecard", {"title": "Prompt Tokens (Counter)", "metric_name": "geminilive_prompt_tokens_total", "x_pos": 12, "width": 12}),
            ("scorecard", {"title": "Response Tokens (Counter)", "metric_name": "geminilive_response_tokens_total", "x_pos": 24, "width": 12}),
            ("scorecard", {"title": "Turn Complete Events (Counter)", "metric_name": "geminilive_turn_complete_total", "x_pos": 36, "width": 12}),
        ]),
        (6, [
            ("scorecard", {"title": "Server VAD Events (Counter)", "metric_name": "geminilive_server_vad_events_total", "x_pos": 0, "width": 12}),
            ("scorecard", {"title": "Client Activity Signals (Counter)", "metric_name": "geminilive_client_activity_signals_total", "x_pos": 12, "width": 12}),
            ("scorecard", {"title": "VAD Interruptions (Counter)", "metric_name": "geminilive_vad_interruptions_total", "x_pos": 24, "width": 12}),
            ("scorecard", {"title": "Rate Limit / Quota Errors (Counter)", "metric_name": "geminilive_rate_limit_quota_errors_total", "x_pos": 36, "width": 12}),
        ]),
        (6, [
            ("scorecard", {"title": "API Requests (Counter)", "metric_name": "geminilive_api_requests_total", "x_pos": 0, "width": 12}),
            ("scorecard", {"title": "WS Errors (Counter)", "metric_name": "geminilive_ws_errors_total", "x_pos": 12, "width": 12}),
        ]),
    ]),
    ("Distribution", "Token distribution by modality", [
        (8, [
            ("xy", {"title": "Modality Token Distribution", "metric_name": "geminilive_modality_tokens_total", "session_groupable": True, "x_pos": 0, "width": 24, "aligner": "ALIGN_DELTA", "reducer": "REDUCE_SUM", "legend": "tokens", "extra_group_by_fields": ["metric.label.modality"], "unit_label": "tokens"}),
        ]),
    ]),
]


def build_dashboard_spec(
    *,
    project_id: str,
    region: str,
    display_name_prefix: str = "Gemini Live Native Audio OTel Dashboard",
    group_by_session_id: bool = False,
) -> dict:
    del project_id
    y = 0
    tiles: list[dict] = []

    for section_title, section_subtitle, rows in _SECTIONS:
        tiles.append(_section_header_tile(title=section_title, subtitle=section_subtitle, y_pos=y))
        y += 4

        for row_height, tile_specs in rows:
            for tile_type, params in tile_specs:
                if tile_type == "scorecard":
                    tiles.append(_scorecard_tile(region=region, y_pos=y, **params))
                elif tile_type == "percentile":
                    tiles.append(_percentile_tile(region=region, group_by_session_id=group_by_session_id, y_pos=y, **params))
                elif tile_type == "xy":
                    tiles.append(_xy_tile(region=region, group_by_session_id=group_by_session_id, y_pos=y, **params))
            y += row_height

    return {
        "displayName": generate_dashboard_display_name(prefix=display_name_prefix),
        "dashboardFilters": [
            {
                "labelKey": "session_id",
                "filterType": "METRIC_LABEL",
                "templateVariable": "session_id",
            },
            {
                "labelKey": "model_id",
                "filterType": "METRIC_LABEL",
                "templateVariable": "model_id",
            },
            {
                "labelKey": "region",
                "filterType": "METRIC_LABEL",
                "templateVariable": "region",
            },
        ],
        "mosaicLayout": {
            "columns": 48,
            "tiles": tiles,
        },
    }
