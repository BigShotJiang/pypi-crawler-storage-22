from __future__ import annotations

import logging
import threading
from bisect import bisect_right
from datetime import datetime, timedelta, timezone
from typing import Any

from geminiliveotel._helpers import HttpSession
from geminiliveotel.sidecar import METRIC_DEFINITIONS, LiveTelemetrySidecar, MetricSnapshot


_TIME_SERIES_BATCH_SIZE = 200

_EXTRA_LABELS: dict[str, list[str]] = {
    "geminilive_tool_calls_total": ["function_name"],
    "geminilive_tool_call_roundtrip_ms": ["function_name"],
    "geminilive_modality_tokens_total": ["modality"],
    "geminilive_api_errors_total": ["error_code"],
    "geminilive_rate_limit_quota_errors_total": ["error_code"],
    "geminilive_ws_errors_total": ["error_type"],
}

_UNIT_MAP = {
    "ms": "ms",
    "count": "1",
    "tokens": "1",
    "tokens/s": "1/s",
    "req/s": "1/s",
    "%": "%",
    "bytes": "By",
    "sessions": "1",
    "ratio": "1",
}

_HISTOGRAM_BOUNDS: dict[str, list[float]] = {
    "geminilive_ttfab_ms": [10, 20, 40, 80, 120, 200, 300, 500, 800, 1200, 2000, 5000],
    "geminilive_turn_e2e_latency_ms": [50, 100, 200, 400, 800, 1200, 2000, 3000, 5000, 8000, 12000],
    "geminilive_tool_call_roundtrip_ms": [50, 100, 200, 500, 1000, 2000, 4000, 8000, 15000, 30000],
    "geminilive_model_wait_after_tool_ms": [50, 100, 200, 400, 800, 1200, 2000, 3000, 5000, 8000],
    "geminilive_input_audio_chunk_duration_ms": [10, 20, 40, 60, 80, 100, 120, 160, 200],
    "geminilive_input_audio_chunk_bytes": [160, 320, 640, 960, 1280, 1920, 2560, 3840, 5120, 8192, 16384],
    "geminilive_ws_connect_latency_ms": [50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000, 30000],
}


def _utc_now_rfc3339(offset_seconds: int = 0) -> str:
    return (
        (datetime.now(timezone.utc) + timedelta(seconds=offset_seconds))
        .isoformat(timespec="microseconds")
        .replace("+00:00", "Z")
    )


def _metric_type(metric_name: str) -> str:
    return f"custom.googleapis.com/geminilive/{metric_name}"


def _chunks(items: list[dict[str, Any]], size: int) -> list[list[dict[str, Any]]]:
    return [items[i : i + size] for i in range(0, len(items), size)]


def _distribution_from_samples(metric_name: str, samples: list[float]) -> dict[str, Any] | None:
    if not samples:
        return None
    bounds = _HISTOGRAM_BOUNDS.get(metric_name) or [10, 20, 50, 100, 200, 500, 1000, 5000]
    bucket_counts = [0] * (len(bounds) + 1)
    for value in samples:
        index = bisect_right(bounds, value)
        bucket_counts[index] += 1

    count = len(samples)
    total = sum(samples)
    mean = total / count
    ssd = sum((value - mean) ** 2 for value in samples)
    return {
        "count": str(count),
        "mean": mean,
        "sumOfSquaredDeviation": ssd,
        "bucketOptions": {
            "explicitBuckets": {
                "bounds": bounds,
            }
        },
        "bucketCounts": [str(value) for value in bucket_counts],
    }


class CloudMonitoringMetricExporter:
    def __init__(
        self,
        *,
        project_id: str,
        session: HttpSession,
        flush_interval_sec: int = 5,
        logger: logging.Logger | None = None,
    ) -> None:
        self._project_id = project_id
        self._session = session
        self._flush_interval_sec = max(1, flush_interval_sec)
        self._logger = logger or logging.getLogger("geminiliveotel.exporter")
        self._metric_descriptors_ready = False
        self._counter_start_times: dict[tuple[str, tuple[tuple[str, str], ...]], str] = {}
        self._histogram_offsets: dict[tuple[str, tuple[tuple[str, str], ...]], int] = {}
        self._last_gauge_emit_ts: dict[tuple[str, tuple[tuple[str, str], ...]], float] = {}
        self._lock = threading.Lock()
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None
        self._sidecar: LiveTelemetrySidecar | None = None

    def start(self, sidecar: LiveTelemetrySidecar, *, start_background: bool = True) -> None:
        self._sidecar = sidecar
        self.ensure_metric_descriptors()
        if not start_background:
            return
        if self._thread and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._run_loop,
            name="geminiliveotel-exporter",
            daemon=True,
        )
        self._thread.start()

    def stop(self) -> None:
        self._stop_event.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2)
        try:
            self.flush_once()
        except Exception:
            self._logger.debug("Final flush during stop() failed", exc_info=True)

    def ensure_metric_descriptors(self) -> None:
        with self._lock:
            if self._metric_descriptors_ready:
                return

        descriptor_url = (
            f"https://monitoring.googleapis.com/v3/projects/{self._project_id}/metricDescriptors"
        )
        for metric_name in METRIC_DEFINITIONS:
            descriptor = self._descriptor_payload(metric_name)
            response = self._session.post(descriptor_url, json=descriptor, timeout=30)
            if response.status_code in {200, 409}:
                continue
            self._logger.warning(
                "Failed to create metric descriptor for %s. status=%s body=%s",
                metric_name,
                response.status_code,
                response.text,
            )

        with self._lock:
            self._metric_descriptors_ready = True

    def flush_once(self) -> None:
        sidecar = self._sidecar
        if sidecar is None:
            return

        self.ensure_metric_descriptors()
        snapshot = sidecar.snapshot()
        series = self._series_from_snapshot(snapshot)
        if not series:
            return

        ts_url = f"https://monitoring.googleapis.com/v3/projects/{self._project_id}/timeSeries"
        for batch in _chunks(series, _TIME_SERIES_BATCH_SIZE):
            response = self._session.post(ts_url, json={"timeSeries": batch}, timeout=30)
            if response.status_code >= 400:
                self._logger.warning(
                    "Failed to write timeseries batch. status=%s body=%s",
                    response.status_code,
                    response.text,
                )

    def _run_loop(self) -> None:
        while not self._stop_event.wait(self._flush_interval_sec):
            try:
                self.flush_once()
            except Exception as exc:  # pragma: no cover - defensive runtime path
                self._logger.warning("Metrics exporter flush failed: %s", exc)

    def _descriptor_payload(self, metric_name: str) -> dict[str, Any]:
        definition = METRIC_DEFINITIONS[metric_name]
        metric_kind = "CUMULATIVE" if definition.kind == "counter" else "GAUGE"
        value_type = "DISTRIBUTION" if definition.kind == "histogram" else "DOUBLE"
        return {
            "type": _metric_type(metric_name),
            "displayName": metric_name,
            "description": definition.description,
            "metricKind": metric_kind,
            "valueType": value_type,
            "unit": _UNIT_MAP.get(definition.unit, "1"),
            "labels": [
                {
                    "key": label,
                    "valueType": "STRING",
                    "description": f"{label} label",
                }
                for label in self._label_keys(metric_name)
            ],
        }

    @staticmethod
    def _label_keys(metric_name: str) -> list[str]:
        definition = METRIC_DEFINITIONS[metric_name]
        keys = ["model_id", "region"]
        if definition.session_groupable:
            keys.append("session_id")
        keys.extend(_EXTRA_LABELS.get(metric_name, []))
        return list(dict.fromkeys(keys))

    def _normalized_labels(self, metric_name: str, labels: dict[str, str]) -> dict[str, str]:
        allowed = self._label_keys(metric_name)
        return {
            key: str(value)
            for key, value in labels.items()
            if key in allowed and value is not None and str(value) != ""
        }

    def _series_from_snapshot(self, snapshot: MetricSnapshot) -> list[dict[str, Any]]:
        now = _utc_now_rfc3339()
        now_ts = datetime.now(timezone.utc).timestamp()
        series: list[dict[str, Any]] = []

        for (metric_name, frozen_labels), value in snapshot.counters.items():
            labels = self._normalized_labels(metric_name, dict(frozen_labels))
            state_key = (metric_name, frozen_labels)
            with self._lock:
                start = self._counter_start_times.setdefault(state_key, _utc_now_rfc3339(offset_seconds=-1))
            series.append(
                self._time_series_payload(
                    metric_name=metric_name,
                    labels=labels,
                    point={
                        "interval": {
                            "startTime": start,
                            "endTime": now,
                        },
                        "value": {"doubleValue": float(value)},
                    },
                )
            )

        for (metric_name, frozen_labels), value in snapshot.gauges.items():
            state_key = (metric_name, frozen_labels)
            with self._lock:
                last_emit = self._last_gauge_emit_ts.get(state_key)
                if last_emit is not None and (now_ts - last_emit) < self._flush_interval_sec:
                    continue
                self._last_gauge_emit_ts[state_key] = now_ts
            labels = self._normalized_labels(metric_name, dict(frozen_labels))
            series.append(
                self._time_series_payload(
                    metric_name=metric_name,
                    labels=labels,
                    point={
                        "interval": {"endTime": now},
                        "value": {"doubleValue": float(value)},
                    },
                )
            )

        for (metric_name, frozen_labels), samples in snapshot.histograms.items():
            state_key = (metric_name, frozen_labels)
            with self._lock:
                offset = self._histogram_offsets.get(state_key, 0)
                self._histogram_offsets[state_key] = len(samples)
            delta_samples = samples[offset:]
            distribution = _distribution_from_samples(metric_name, delta_samples)
            if not distribution:
                continue
            labels = self._normalized_labels(metric_name, dict(frozen_labels))
            series.append(
                self._time_series_payload(
                    metric_name=metric_name,
                    labels=labels,
                    point={
                        "interval": {"endTime": now},
                        "value": {"distributionValue": distribution},
                    },
                )
            )
        return series

    def _time_series_payload(
        self,
        *,
        metric_name: str,
        labels: dict[str, str],
        point: dict[str, Any],
    ) -> dict[str, Any]:
        return {
            "metric": {
                "type": _metric_type(metric_name),
                "labels": labels,
            },
            "resource": {
                "type": "global",
                "labels": {"project_id": self._project_id},
            },
            "points": [point],
        }
