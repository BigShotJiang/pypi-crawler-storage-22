from __future__ import annotations

from collections.abc import AsyncIterator, Callable
from typing import Any

from geminiliveotel._helpers import (
    extract_call_ids,
    now_ms as _default_now_ms,
    report_sidecar_error,
    to_payload,
)
from geminiliveotel.sidecar import LiveTelemetrySidecar


class InstrumentedLiveSession:
    def __init__(
        self,
        *,
        session: Any,
        sidecar: LiveTelemetrySidecar,
        model_id: str,
        region: str,
        automatic_vad: bool,
        now_ms: Callable[[], int] = _default_now_ms,
        connect_duration_ms: float | None = None,
    ) -> None:
        self._session = session
        self._sidecar = sidecar
        self._now_ms = now_ms
        self._closed = False
        raw_id = getattr(session, "session_id", None)
        self._session_id = str(raw_id) if raw_id is not None else f"session-{id(session)}"

        self._sidecar.on_session_started(
            session_id=self._session_id,
            model=model_id,
            region=region,
            automatic_vad=automatic_vad,
            timestamp_ms=self._now_ms(),
            connect_duration_ms=connect_duration_ms,
        )

    @property
    def session_id(self) -> str:
        return self._session_id

    def __getattr__(self, name: str) -> Any:
        # Delegate unknown methods/attributes to the underlying SDK session.
        return getattr(self._session, name)

    def _report_error(self, exc: Exception) -> None:
        report_sidecar_error(
            self._sidecar, self._session_id, exc, self._now_ms(),
        )

    async def send_realtime_input(
        self,
        *,
        audio: Any = None,
        video: Any = None,
        media: Any = None,
        text: str | None = None,
        audio_stream_end: bool | None = None,
        activity_start: Any = None,
        activity_end: Any = None,
        audio_chunk_duration_ms: int | None = None,
        audio_chunk_bytes: int | None = None,
    ) -> None:
        activity_start_set = activity_start is not None
        activity_end_set = activity_end is not None
        self._sidecar.on_client_request(
            session_id=self._session_id,
            request_type="realtime_input",
            timestamp_ms=self._now_ms(),
            audio_chunk_duration_ms=audio_chunk_duration_ms,
            audio_chunk_bytes=audio_chunk_bytes,
            activity_start=activity_start_set,
            activity_end=activity_end_set,
        )
        kwargs: dict[str, Any] = {}
        if audio is not None:
            kwargs["audio"] = audio
        if video is not None:
            kwargs["video"] = video
        if media is not None:
            kwargs["media"] = media
        if text is not None:
            kwargs["text"] = text
        if audio_stream_end is not None:
            kwargs["audio_stream_end"] = audio_stream_end
        if activity_start_set:
            kwargs["activity_start"] = activity_start
        if activity_end_set:
            kwargs["activity_end"] = activity_end
        try:
            await self._session.send_realtime_input(**kwargs)
        except Exception as exc:
            self._report_error(exc)
            raise

    async def send_client_content(self, **kwargs: Any) -> None:
        tool_call_ids = kwargs.pop("__otel_tool_call_ids", None)
        self._sidecar.on_client_request(
            session_id=self._session_id,
            request_type="client_content",
            timestamp_ms=self._now_ms(),
        )
        try:
            await self._session.send_client_content(**kwargs)
            if tool_call_ids:
                normalized_ids = [str(call_id) for call_id in tool_call_ids if call_id is not None]
                if normalized_ids:
                    self._sidecar.on_tool_response(
                        session_id=self._session_id,
                        call_ids=normalized_ids,
                        timestamp_ms=self._now_ms(),
                    )
        except Exception as exc:
            self._report_error(exc)
            raise

    async def send_tool_response(
        self,
        *,
        function_responses: list[Any],
    ) -> None:
        call_ids = extract_call_ids(function_responses)
        try:
            await self._session.send_tool_response(function_responses=function_responses)
            self._sidecar.on_tool_response(
                session_id=self._session_id,
                call_ids=call_ids,
                timestamp_ms=self._now_ms(),
            )
        except Exception as exc:
            self._report_error(exc)
            raise

    async def receive(self) -> AsyncIterator[Any]:
        try:
            async for message in self._session.receive():
                payload = to_payload(message)
                self._sidecar.on_server_message(
                    session_id=self._session_id,
                    message=payload,
                    timestamp_ms=self._now_ms(),
                )
                yield message
        except Exception as exc:
            self._report_error(exc)
            raise

    async def _receive(self) -> Any:
        try:
            message = await self._session._receive()
            payload = to_payload(message)
            self._sidecar.on_server_message(
                session_id=self._session_id,
                message=payload,
                timestamp_ms=self._now_ms(),
            )
            return message
        except Exception as exc:
            self._report_error(exc)
            raise

    async def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        self._sidecar.on_session_closed(
            session_id=self._session_id,
            timestamp_ms=self._now_ms(),
        )
        await self._session.close()


def instrument_live_session(
    *,
    session: Any,
    sidecar: LiveTelemetrySidecar,
    model_id: str,
    region: str,
    automatic_vad: bool,
    now_ms: Callable[[], int] = _default_now_ms,
    connect_duration_ms: float | None = None,
) -> InstrumentedLiveSession:
    return InstrumentedLiveSession(
        session=session,
        sidecar=sidecar,
        model_id=model_id,
        region=region,
        automatic_vad=automatic_vad,
        now_ms=now_ms,
        connect_duration_ms=connect_duration_ms,
    )
