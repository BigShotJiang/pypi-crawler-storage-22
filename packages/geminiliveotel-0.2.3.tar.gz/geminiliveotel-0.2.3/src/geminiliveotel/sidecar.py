from __future__ import annotations

import logging
import threading
from collections import deque
from dataclasses import dataclass, field
from math import ceil
from typing import Any, Literal, Mapping

from geminiliveotel.tool_ids import stable_tool_call_id

logger = logging.getLogger("geminiliveotel.sidecar")


MetricLabels = dict[str, str]
MetricKey = tuple[str, tuple[tuple[str, str], ...]]


MetricKind = Literal["counter", "gauge", "histogram"]
ChartElement = Literal["line", "percentile_line", "scorecard", "distribution"]


@dataclass(frozen=True)
class MetricDefinition:
    unit: str
    kind: MetricKind
    session_groupable: bool
    recommended_chart: ChartElement
    description: str


METRIC_DEFINITIONS: dict[str, MetricDefinition] = {
    "geminilive_ttfab_ms": MetricDefinition(
        unit="ms",
        kind="histogram",
        session_groupable=True,
        recommended_chart="percentile_line",
        description="Time from turn start to first audio byte.",
    ),
    "geminilive_turn_e2e_latency_ms": MetricDefinition(
        unit="ms",
        kind="histogram",
        session_groupable=True,
        recommended_chart="percentile_line",
        description="Time from turn start to turn_complete.",
    ),
    "geminilive_tool_call_roundtrip_ms": MetricDefinition(
        unit="ms",
        kind="histogram",
        session_groupable=True,
        recommended_chart="percentile_line",
        description="Tool call to tool response roundtrip latency.",
    ),
    "geminilive_model_wait_after_tool_ms": MetricDefinition(
        unit="ms",
        kind="histogram",
        session_groupable=True,
        recommended_chart="percentile_line",
        description="Model wait time after tool response.",
    ),
    "geminilive_tool_calls_total": MetricDefinition(
        unit="count",
        kind="counter",
        session_groupable=True,
        recommended_chart="scorecard",
        description="Total tool calls requested.",
    ),
    "geminilive_input_audio_chunk_duration_ms": MetricDefinition(
        unit="ms",
        kind="histogram",
        session_groupable=True,
        recommended_chart="distribution",
        description="Input audio chunk duration.",
    ),
    "geminilive_input_audio_chunk_bytes": MetricDefinition(
        unit="bytes",
        kind="histogram",
        session_groupable=True,
        recommended_chart="distribution",
        description="Input audio chunk byte size.",
    ),
    "geminilive_input_audio_chunk_noncompliant_total": MetricDefinition(
        unit="count",
        kind="counter",
        session_groupable=True,
        recommended_chart="scorecard",
        description="Number of chunks outside 20-100ms.",
    ),
    "geminilive_total_tokens_total": MetricDefinition(
        unit="tokens",
        kind="counter",
        session_groupable=True,
        recommended_chart="scorecard",
        description="Total token count.",
    ),
    "geminilive_prompt_tokens_total": MetricDefinition(
        unit="tokens",
        kind="counter",
        session_groupable=True,
        recommended_chart="line",
        description="Prompt token count.",
    ),
    "geminilive_response_tokens_total": MetricDefinition(
        unit="tokens",
        kind="counter",
        session_groupable=True,
        recommended_chart="line",
        description="Response token count.",
    ),
    "geminilive_modality_tokens_total": MetricDefinition(
        unit="tokens",
        kind="counter",
        session_groupable=True,
        recommended_chart="line",
        description="Token count split by media modality (audio/video/image; text excluded).",
    ),
    "geminilive_turn_complete_total": MetricDefinition(
        unit="count",
        kind="counter",
        session_groupable=True,
        recommended_chart="scorecard",
        description="Turn complete event count.",
    ),
    "geminilive_server_vad_events_total": MetricDefinition(
        unit="count",
        kind="counter",
        session_groupable=True,
        recommended_chart="line",
        description="Server-side VAD events for automatic mode.",
    ),
    "geminilive_client_activity_signals_total": MetricDefinition(
        unit="count",
        kind="counter",
        session_groupable=True,
        recommended_chart="line",
        description="Client activity signals for custom VAD mode.",
    ),
    "geminilive_vad_interruptions_total": MetricDefinition(
        unit="count",
        kind="counter",
        session_groupable=True,
        recommended_chart="line",
        description="Interrupted turn count.",
    ),
    "geminilive_turns_total": MetricDefinition(
        unit="count",
        kind="counter",
        session_groupable=True,
        recommended_chart="scorecard",
        description="Deprecated: use geminilive_turn_complete_total instead.",
    ),
    "geminilive_api_requests_total": MetricDefinition(
        unit="count",
        kind="counter",
        session_groupable=True,
        recommended_chart="line",
        description="Total API requests on live stream.",
    ),
    "geminilive_request_qps": MetricDefinition(
        unit="req/s",
        kind="gauge",
        session_groupable=True,
        recommended_chart="line",
        description="Request throughput in requests per second.",
    ),
    "geminilive_concurrent_sessions": MetricDefinition(
        unit="sessions",
        kind="gauge",
        session_groupable=False,
        recommended_chart="line",
        description="Concurrent live sessions.",
    ),
    "geminilive_token_throughput_tps": MetricDefinition(
        unit="tokens/s",
        kind="gauge",
        session_groupable=True,
        recommended_chart="line",
        description="Token throughput in tokens per second.",
    ),
    "geminilive_api_errors_total": MetricDefinition(
        unit="count",
        kind="counter",
        session_groupable=True,
        recommended_chart="scorecard",
        description="API error count.",
    ),
    "geminilive_rate_limit_quota_errors_total": MetricDefinition(
        unit="count",
        kind="counter",
        session_groupable=True,
        recommended_chart="scorecard",
        description="Rate-limit and quota error count.",
    ),
    "geminilive_concurrency_quota_utilization_pct": MetricDefinition(
        unit="%",
        kind="gauge",
        session_groupable=False,
        recommended_chart="line",
        description="Concurrent session quota utilization.",
    ),
    "geminilive_successful_model_responses_total": MetricDefinition(
        unit="count",
        kind="counter",
        session_groupable=True,
        recommended_chart="scorecard",
        description="Successful model response count.",
    ),
    "geminilive_model_success_rate": MetricDefinition(
        unit="ratio",
        kind="gauge",
        session_groupable=True,
        recommended_chart="line",
        description="Successful responses / total turns.",
    ),
    "geminilive_ws_connect_latency_ms": MetricDefinition(
        unit="ms",
        kind="histogram",
        session_groupable=True,
        recommended_chart="percentile_line",
        description="Time to establish Gemini Live WebSocket connection.",
    ),
    "geminilive_ws_errors_total": MetricDefinition(
        unit="count",
        kind="counter",
        session_groupable=True,
        recommended_chart="scorecard",
        description="WebSocket-specific errors (connection failures, abnormal closures).",
    ),
}

AGREED_METRICS = set(METRIC_DEFINITIONS)


def _freeze_labels(labels: MetricLabels) -> tuple[tuple[str, str], ...]:
    return tuple(sorted((key, str(value)) for key, value in labels.items()))


def _extract(container: Any, *keys: str) -> Any:
    if container is None:
        return None
    for key in keys:
        if isinstance(container, Mapping) and key in container:
            return container[key]
        if hasattr(container, key):
            return getattr(container, key)
    return None


def _bool(container: Any, *keys: str) -> bool:
    return bool(_extract(container, *keys))


def _as_dict_labels(session_id: str, model_id: str, region: str) -> MetricLabels:
    return {
        "session_id": session_id,
        "model_id": model_id,
        "region": region,
    }


@dataclass
class MetricSnapshot:
    counters: dict[MetricKey, float]
    gauges: dict[MetricKey, float]
    histograms: dict[MetricKey, list[float]]

    def counter(self, name: str, **labels: str) -> float:
        return self.counters.get((name, _freeze_labels(labels)), 0.0)

    def gauge(self, name: str, **labels: str) -> float:
        return self.gauges.get((name, _freeze_labels(labels)), 0.0)

    def histogram_samples(self, name: str, **labels: str) -> list[float]:
        samples = self.histograms.get((name, _freeze_labels(labels)), [])
        return list(samples)

    def percentile(self, name: str, quantile: float, **labels: str) -> float:
        samples = self.histogram_samples(name, **labels)
        if not samples:
            return 0.0
        ordered = sorted(samples)
        index = max(0, min(len(ordered) - 1, ceil(quantile * len(ordered)) - 1))
        return ordered[index]

    def has_labels(self, name: str, **labels: str) -> bool:
        frozen = _freeze_labels(labels)
        return (
            (name, frozen) in self.counters
            or (name, frozen) in self.gauges
            or (name, frozen) in self.histograms
        )


class _MetricStore:
    def __init__(self) -> None:
        self._counters: dict[MetricKey, float] = {}
        self._gauges: dict[MetricKey, float] = {}
        self._histograms: dict[MetricKey, list[float]] = {}
        self._lock = threading.Lock()

    def inc_counter(self, name: str, labels: MetricLabels, value: float = 1.0) -> None:
        key = (name, _freeze_labels(labels))
        with self._lock:
            self._counters[key] = self._counters.get(key, 0.0) + value

    def set_gauge(self, name: str, labels: MetricLabels, value: float) -> None:
        key = (name, _freeze_labels(labels))
        with self._lock:
            self._gauges[key] = value

    def observe_histogram(self, name: str, labels: MetricLabels, value: float) -> None:
        key = (name, _freeze_labels(labels))
        with self._lock:
            self._histograms.setdefault(key, []).append(value)

    def snapshot(self) -> MetricSnapshot:
        with self._lock:
            return MetricSnapshot(
                counters=dict(self._counters),
                gauges=dict(self._gauges),
                histograms={key: list(values) for key, values in self._histograms.items()},
            )


@dataclass
class _ToolCallState:
    function_name: str
    sent_at_ms: int


@dataclass
class _SessionState:
    session_id: str
    model_id: str
    region: str
    automatic_vad: bool
    started_at_ms: int
    current_turn_start_ms: int | None = None
    current_turn_first_audio_seen: bool = False
    current_turn_had_error: bool = False
    turn_count: int = 0
    successful_turn_count: int = 0
    pending_tool_calls: dict[str, _ToolCallState] = field(default_factory=dict)
    completed_tool_calls: dict[str, None] = field(default_factory=dict)
    in_tool_response_turn: bool = False
    last_tool_response_at_ms: int | None = None
    total_tokens: int = 0
    logical_request_count: int = 0
    first_logical_request_at_ms: int | None = None
    last_logical_request_at_ms: int | None = None
    _last_reported_total_tokens: int = 0
    _last_reported_prompt_tokens: int = 0
    _last_reported_response_tokens: int = 0
    _tool_call_seq: int = 0
    _request_timestamps: deque[int] = field(default_factory=deque)
    _token_events: deque[tuple[int, int]] = field(default_factory=deque)

    @property
    def base_labels(self) -> MetricLabels:
        return _as_dict_labels(self.session_id, self.model_id, self.region)


class LiveTelemetrySidecar:
    def __init__(
        self,
        *,
        target_model: str,
        region: str,
        concurrency_quota: int = 1000,
        token_counting: Literal["incremental", "cumulative"] = "incremental",
        rate_window_sec: int = 60,
    ) -> None:
        self._target_model = target_model
        self._default_region = region
        self._concurrency_quota = concurrency_quota
        self._token_counting = token_counting
        self._rate_window_sec = rate_window_sec
        self._rate_window_ms = rate_window_sec * 1000
        self._metrics = _MetricStore()
        self._sessions: dict[str, _SessionState] = {}
        self._exporter: Any | None = None

    def attach_exporter(self, exporter: Any) -> None:
        self._exporter = exporter

    def update_quota(self, new_quota: int) -> None:
        if new_quota <= 0:
            return
        self._concurrency_quota = new_quota
        seen: set[tuple[str, str]] = set()
        for session in self._sessions.values():
            key = (session.model_id, session.region)
            if key not in seen:
                seen.add(key)
                self._update_concurrency(session.model_id, session.region)

    def metric_names(self) -> set[str]:
        return set(AGREED_METRICS)

    def metric_definitions(self) -> dict[str, MetricDefinition]:
        return dict(METRIC_DEFINITIONS)

    def snapshot(self) -> MetricSnapshot:
        return self._metrics.snapshot()

    def on_session_started(
        self,
        session_id: str,
        model: str,
        region: str | None,
        automatic_vad: bool,
        timestamp_ms: int,
        connect_duration_ms: float | None = None,
    ) -> bool:
        if model != self._target_model:
            return False

        session_region = region or self._default_region
        self._sessions[session_id] = _SessionState(
            session_id=session_id,
            model_id=model,
            region=session_region,
            automatic_vad=automatic_vad,
            started_at_ms=timestamp_ms,
        )
        self._update_concurrency(model, session_region)

        if connect_duration_ms is not None:
            session = self._sessions[session_id]
            self._metrics.observe_histogram(
                "geminilive_ws_connect_latency_ms",
                session.base_labels,
                max(0.0, float(connect_duration_ms)),
            )

        return True

    def on_session_closed(self, session_id: str, timestamp_ms: int) -> None:
        del timestamp_ms
        session = self._sessions.pop(session_id, None)
        if session is None:
            return
        self._update_concurrency(session.model_id, session.region)

    def on_client_request(
        self,
        session_id: str,
        request_type: str,
        timestamp_ms: int,
        audio_chunk_duration_ms: int | None = None,
        audio_chunk_bytes: int | None = None,
        activity_start: bool = False,
        activity_end: bool = False,
    ) -> None:
        session = self._sessions.get(session_id)
        if session is None:
            return

        labels = session.base_labels

        if session.current_turn_start_ms is None or request_type == "client_content":
            session.current_turn_start_ms = timestamp_ms
            session.current_turn_first_audio_seen = False
            session.current_turn_had_error = False

        is_turn_start = session.current_turn_start_ms == timestamp_ms
        should_count_request = request_type != "realtime_input" or is_turn_start
        if should_count_request:
            self._metrics.inc_counter("geminilive_api_requests_total", labels)

            session.logical_request_count += 1
            if session.first_logical_request_at_ms is None:
                session.first_logical_request_at_ms = timestamp_ms
            session.last_logical_request_at_ms = timestamp_ms

            session._request_timestamps.append(timestamp_ms)
            cutoff_ms = timestamp_ms - self._rate_window_ms
            while session._request_timestamps and session._request_timestamps[0] < cutoff_ms:
                session._request_timestamps.popleft()
            window_count = len(session._request_timestamps)
            window_sec = min(self._rate_window_sec, max(1.0, (timestamp_ms - session.started_at_ms) / 1000.0))
            self._metrics.set_gauge(
                "geminilive_request_qps",
                labels,
                window_count / window_sec,
            )

        if audio_chunk_duration_ms is not None:
            self._metrics.observe_histogram(
                "geminilive_input_audio_chunk_duration_ms",
                labels,
                float(audio_chunk_duration_ms),
            )
            if audio_chunk_duration_ms < 20 or audio_chunk_duration_ms > 100:
                self._metrics.inc_counter(
                    "geminilive_input_audio_chunk_noncompliant_total",
                    labels,
                )

        if audio_chunk_bytes is not None:
            self._metrics.observe_histogram(
                "geminilive_input_audio_chunk_bytes",
                labels,
                float(audio_chunk_bytes),
            )

        if not session.automatic_vad:
            if activity_start:
                self._metrics.inc_counter(
                    "geminilive_client_activity_signals_total",
                    labels,
                )
            if activity_end:
                self._metrics.inc_counter(
                    "geminilive_client_activity_signals_total",
                    labels,
                )

    def on_server_message(self, session_id: str, message: Mapping[str, Any], timestamp_ms: int) -> None:
        session = self._sessions.get(session_id)
        if session is None:
            return

        labels = session.base_labels

        tool_call = _extract(message, "tool_call", "toolCall")
        if tool_call:
            for call in _extract(tool_call, "function_calls", "functionCalls") or []:
                function_name = str(_extract(call, "name") or "unknown")
                function_args = _extract(call, "args")
                normalized_args = function_args if isinstance(function_args, Mapping) else {}
                call_id = _extract(call, "id")
                if call_id is not None and str(call_id).strip() != "":
                    normalized_call_id = str(call_id)
                else:
                    session._tool_call_seq += 1
                    normalized_call_id = stable_tool_call_id(
                        function_name=function_name,
                        function_args=normalized_args,
                        seq=session._tool_call_seq,
                    )
                if normalized_call_id in session.pending_tool_calls:
                    continue
                if normalized_call_id in session.completed_tool_calls:
                    continue
                session.pending_tool_calls[normalized_call_id] = _ToolCallState(
                    function_name=function_name,
                    sent_at_ms=timestamp_ms,
                )

        usage = _extract(message, "usage_metadata", "usageMetadata")
        if usage:
            self._record_usage_metrics(session, usage, timestamp_ms)

        voice_activity = _extract(message, "voice_activity", "voiceActivity")
        if voice_activity and session.automatic_vad:
            self._metrics.inc_counter("geminilive_server_vad_events_total", labels)

        server_content = _extract(message, "server_content", "serverContent")
        if not server_content:
            tool_call_cancellation = _extract(message, "tool_call_cancellation", "toolCallCancellation")
            cancelled_ids = _extract(tool_call_cancellation, "ids") or []
            if cancelled_ids:
                self._metrics.inc_counter(
                    "geminilive_vad_interruptions_total",
                    labels,
                    float(len(cancelled_ids)),
                )
            return

        if _bool(server_content, "interrupted") or _bool(message, "interrupted"):
            self._metrics.inc_counter("geminilive_vad_interruptions_total", labels)

        has_model_output = self._has_model_output(server_content)
        if has_model_output and session.last_tool_response_at_ms is not None:
            wait_ms = max(0, timestamp_ms - session.last_tool_response_at_ms)
            self._metrics.observe_histogram(
                "geminilive_model_wait_after_tool_ms",
                labels,
                float(wait_ms),
            )
            session.last_tool_response_at_ms = None

        if (
            self._has_audio_output(server_content)
            and session.current_turn_start_ms is not None
            and not session.current_turn_first_audio_seen
            and not session.in_tool_response_turn
        ):
            ttfab_ms = max(0, timestamp_ms - session.current_turn_start_ms)
            self._metrics.observe_histogram(
                "geminilive_ttfab_ms",
                labels,
                float(ttfab_ms),
            )
            session.current_turn_first_audio_seen = True

        if _bool(server_content, "turn_complete", "turnComplete"):
            if session.in_tool_response_turn:
                # Phantom turn from tool-result injection -- do not count as
                # a real conversational turn.  Reset turn state and the flag.
                session.current_turn_start_ms = None
                session.current_turn_first_audio_seen = False
                session.current_turn_had_error = False
                session.in_tool_response_turn = False
            else:
                if session.current_turn_start_ms is not None:
                    self._metrics.inc_counter("geminilive_turn_complete_total", labels)
                    session.turn_count += 1

                    e2e_ms = max(0, timestamp_ms - session.current_turn_start_ms)
                    self._metrics.observe_histogram(
                        "geminilive_turn_e2e_latency_ms",
                        labels,
                        float(e2e_ms),
                    )

                    if not session.current_turn_had_error:
                        self._metrics.inc_counter("geminilive_successful_model_responses_total", labels)
                        session.successful_turn_count += 1

                    success_rate = (
                        session.successful_turn_count / session.turn_count if session.turn_count else 0.0
                    )
                    self._metrics.set_gauge("geminilive_model_success_rate", labels, success_rate)

                # Always reset turn state (idempotent)
                session.current_turn_start_ms = None
                session.current_turn_first_audio_seen = False
                session.current_turn_had_error = False

    def on_tool_response(self, session_id: str, call_ids: list[str], timestamp_ms: int) -> None:
        session = self._sessions.get(session_id)
        if session is None:
            return

        labels = session.base_labels
        for call_id in call_ids:
            call_state = session.pending_tool_calls.pop(str(call_id), None)
            if call_state is None:
                continue
            session.completed_tool_calls[str(call_id)] = None
            if len(session.completed_tool_calls) > 10_000:
                keys = list(session.completed_tool_calls.keys())[:1000]
                for k in keys:
                    del session.completed_tool_calls[k]
            latency_ms = max(0, timestamp_ms - call_state.sent_at_ms)
            self._metrics.inc_counter(
                "geminilive_tool_calls_total",
                {
                    **labels,
                    "function_name": call_state.function_name,
                },
            )
            self._metrics.observe_histogram(
                "geminilive_tool_call_roundtrip_ms",
                {
                    **labels,
                    "function_name": call_state.function_name,
                },
                float(latency_ms),
            )
        session.last_tool_response_at_ms = timestamp_ms
        session.in_tool_response_turn = True

    def on_api_error(
        self,
        session_id: str,
        code: str,
        message: str,
        timestamp_ms: int,
    ) -> None:
        del timestamp_ms
        session = self._sessions.get(session_id)
        if session is None:
            logger.debug("on_api_error called for unknown/closed session %s (code=%s)", session_id, code)
            return

        labels = {
            **session.base_labels,
            "error_code": code,
        }
        self._metrics.inc_counter("geminilive_api_errors_total", labels)

        if self._is_quota_error(code, message):
            self._metrics.inc_counter("geminilive_rate_limit_quota_errors_total", labels)

        if session.current_turn_start_ms is not None:
            session.current_turn_had_error = True

    def on_ws_error(self, session_id: str, error_type: str, timestamp_ms: int) -> None:
        del timestamp_ms
        session = self._sessions.get(session_id)
        if session is None:
            logger.debug("on_ws_error called for unknown/closed session %s (error_type=%s)", session_id, error_type)
            return
        self._metrics.inc_counter(
            "geminilive_ws_errors_total",
            {**session.base_labels, "error_type": error_type},
        )

    def _record_usage_metrics(self, session: _SessionState, usage: Any, timestamp_ms: int) -> None:
        labels = session.base_labels

        raw_total = int(_extract(usage, "total_token_count", "totalTokenCount") or 0)
        raw_prompt = int(_extract(usage, "prompt_token_count", "promptTokenCount") or 0)
        raw_response = int(_extract(usage, "response_token_count", "responseTokenCount") or 0)

        if self._token_counting == "cumulative":
            total_tokens = max(0, raw_total - session._last_reported_total_tokens)
            prompt_tokens = max(0, raw_prompt - session._last_reported_prompt_tokens)
            response_tokens = max(0, raw_response - session._last_reported_response_tokens)
            if raw_total >= session._last_reported_total_tokens:
                session._last_reported_total_tokens = raw_total
            if raw_prompt >= session._last_reported_prompt_tokens:
                session._last_reported_prompt_tokens = raw_prompt
            if raw_response >= session._last_reported_response_tokens:
                session._last_reported_response_tokens = raw_response
        else:
            total_tokens = raw_total
            prompt_tokens = raw_prompt
            response_tokens = raw_response

        if total_tokens:
            self._metrics.inc_counter("geminilive_total_tokens_total", labels, total_tokens)
            session.total_tokens += total_tokens

        if prompt_tokens:
            self._metrics.inc_counter("geminilive_prompt_tokens_total", labels, prompt_tokens)

        if response_tokens:
            self._metrics.inc_counter("geminilive_response_tokens_total", labels, response_tokens)

        prompt_details = _extract(usage, "prompt_tokens_details", "promptTokensDetails") or []
        response_details = _extract(usage, "response_tokens_details", "responseTokensDetails") or []
        for detail in [*prompt_details, *response_details]:
            modality_raw = _extract(detail, "modality") or ""
            modality = (modality_raw.value if hasattr(modality_raw, "value") else str(modality_raw)).strip().lower()
            count = int(_extract(detail, "token_count", "tokenCount") or 0)
            # Text modality intentionally excluded — this metric tracks media-specific
            # (audio/video/image) token distribution only.
            if modality in {"audio", "video", "image"} and count:
                self._metrics.inc_counter(
                    "geminilive_modality_tokens_total",
                    {
                        **labels,
                        "modality": modality,
                    },
                    count,
                )

        session._token_events.append((timestamp_ms, total_tokens))
        cutoff_ms = timestamp_ms - self._rate_window_ms
        while session._token_events and session._token_events[0][0] < cutoff_ms:
            session._token_events.popleft()
        window_tokens = sum(t for _, t in session._token_events)
        window_sec = min(self._rate_window_sec, max(1.0, (timestamp_ms - session.started_at_ms) / 1000.0))
        throughput = window_tokens / window_sec
        self._metrics.set_gauge("geminilive_token_throughput_tps", labels, throughput)

    def _update_concurrency(self, model_id: str, region: str) -> None:
        count = sum(
            1
            for session in self._sessions.values()
            if session.model_id == model_id and session.region == region
        )
        labels = {
            "model_id": model_id,
            "region": region,
        }
        self._metrics.set_gauge("geminilive_concurrent_sessions", labels, float(count))
        utilization = (count / self._concurrency_quota) * 100 if self._concurrency_quota else 0.0
        self._metrics.set_gauge("geminilive_concurrency_quota_utilization_pct", labels, utilization)

    @staticmethod
    def _has_model_output(server_content: Any) -> bool:
        model_turn = _extract(server_content, "model_turn", "modelTurn")
        parts = _extract(model_turn, "parts") or []
        return len(parts) > 0

    @staticmethod
    def _has_audio_output(server_content: Any) -> bool:
        model_turn = _extract(server_content, "model_turn", "modelTurn")
        parts = _extract(model_turn, "parts") or []
        for part in parts:
            inline_data = _extract(part, "inline_data", "inlineData")
            mime_type = str(_extract(inline_data, "mime_type", "mimeType") or "").lower()
            if mime_type.startswith("audio/"):
                return True
        return False

    @staticmethod
    def _is_quota_error(code: str, message: str) -> bool:
        normalized = code.upper()
        text = message.lower()
        if normalized in {
            "RESOURCE_EXHAUSTED",
            "RATE_LIMIT_EXCEEDED",
            "QUOTA_EXCEEDED",
            "TOO_MANY_REQUESTS",
            "429",
        }:
            return True
        return "quota" in text or "rate limit" in text or "too many requests" in text
