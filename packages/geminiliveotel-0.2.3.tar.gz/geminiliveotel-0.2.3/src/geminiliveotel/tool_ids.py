from __future__ import annotations

import hashlib
import json
from typing import Any, Mapping


def stable_tool_call_id(
    *,
    function_name: str,
    function_args: Mapping[str, Any] | None = None,
    prefix: str = "tc",
    seq: int | None = None,
) -> str:
    """Derive a stable fallback tool-call ID from function name and args."""
    normalized_args = dict(function_args or {})
    payload: dict[str, Any] = {
        "function_name": str(function_name or "unknown"),
        "function_args": normalized_args,
    }
    if seq is not None:
        payload["seq"] = seq
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str)
    digest = hashlib.sha256(encoded.encode("utf-8")).hexdigest()[:12]
    return f"{prefix}_{digest}"
