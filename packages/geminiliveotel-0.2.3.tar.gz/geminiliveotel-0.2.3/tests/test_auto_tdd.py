"""Tests for geminiliveotel.auto -- wrapt-based auto-instrumentation."""

from __future__ import annotations

import asyncio
import sys
import types
from contextlib import asynccontextmanager
from typing import Any
from unittest import mock

import pytest

from google.genai.types import Blob, Content, LiveServerContent, LiveServerMessage, Part

TARGET_MODEL = "gemini-live-2.5-flash-native-audio"
REGION = "us-central1"


# ---- Fakes ------------------------------------------------------------------


class _FakeAsyncSession:
    """Minimal fake that mimics google.genai.live.AsyncSession."""

    def __init__(self, session_id: str = "sess-1") -> None:
        self.session_id = session_id
        self.sent_realtime: list[dict] = []
        self.sent_client: list[dict] = []
        self.sent_tool: list[dict] = []
        self.closed = False
        self._messages: list[LiveServerMessage] = [
            LiveServerMessage(
                server_content=LiveServerContent(
                    model_turn=Content(
                        parts=[Part(inline_data=Blob(mime_type="audio/pcm", data=b"x"))],
                    ),
                ),
            ),
            LiveServerMessage(
                server_content=LiveServerContent(turn_complete=True),
            ),
        ]

    async def send_realtime_input(self, **kwargs: Any) -> None:
        self.sent_realtime.append(kwargs)

    async def send_client_content(self, **kwargs: Any) -> None:
        self.sent_client.append(kwargs)

    async def send_tool_response(self, **kwargs: Any) -> None:
        self.sent_tool.append(kwargs)

    async def receive(self):
        for msg in self._messages:
            yield msg

    async def _receive(self):
        if self._messages:
            return self._messages.pop(0)
        return None

    async def close(self) -> None:
        self.closed = True


class _FailingAsyncSession(_FakeAsyncSession):
    async def send_realtime_input(self, **kwargs: Any) -> None:
        raise RuntimeError("RESOURCE_EXHAUSTED: quota exceeded")


class _FakeAsyncLive:
    """Minimal fake for google.genai.live.AsyncLive."""

    def __init__(self, session: _FakeAsyncSession | None = None) -> None:
        self._session = session or _FakeAsyncSession()

    @asynccontextmanager
    async def connect(self, **kwargs: Any):
        yield self._session


# ---- Helpers ----------------------------------------------------------------


def _install_fake_genai_module(
    async_live_cls: type | None = None,
    async_session_cls: type | None = None,
) -> types.ModuleType:
    """Build a fake google.genai.live module and register it in sys.modules.

    This must be called BEFORE importing geminiliveotel.auto so that the
    module-level instrument() call finds a patchable target.
    """
    live_mod = types.ModuleType("google.genai.live")
    live_mod.AsyncLive = async_live_cls or _FakeAsyncLive
    live_mod.AsyncSession = async_session_cls or _FakeAsyncSession

    # Ensure parent packages exist in sys.modules.
    # Preserve the real google package if available so that other modules
    # (bootstrap.py → google.auth) can still import from it.
    if "google" not in sys.modules:
        try:
            import google  # noqa: F401 — real namespace package
        except ImportError:
            google_mod = types.ModuleType("google")
            google_mod.__path__ = []
            sys.modules["google"] = google_mod
    if "google.genai" not in sys.modules:
        genai_mod = types.ModuleType("google.genai")
        genai_mod.__path__ = []
        sys.modules["google.genai"] = genai_mod

    sys.modules["google.genai.live"] = live_mod
    # Also update the parent package's attribute so that both
    # sys.modules and attribute-based lookups return the fake.
    genai_mod = sys.modules.get("google.genai")
    if genai_mod is not None:
        genai_mod.live = live_mod
    return live_mod


def _get_auto_mod():
    """Get the auto module directly (not through geminiliveotel.__init__).

    Uses importlib to load auto.py by file path, bypassing the package
    __init__.py which depends on google.auth and other heavy deps that
    are not available in the test environment.
    """
    if "geminiliveotel.auto" in sys.modules:
        return sys.modules["geminiliveotel.auto"]
    import importlib.util
    import pathlib

    auto_path = (
        pathlib.Path(__file__).resolve().parent.parent
        / "src"
        / "geminiliveotel"
        / "auto.py"
    )
    # Register a package stub so sub-module imports resolve correctly
    if "geminiliveotel" not in sys.modules:
        pkg = types.ModuleType("geminiliveotel")
        pkg.__path__ = [str(auto_path.parent)]
        sys.modules["geminiliveotel"] = pkg
    spec = importlib.util.spec_from_file_location("geminiliveotel.auto", auto_path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules["geminiliveotel.auto"] = mod
    spec.loader.exec_module(mod)
    return mod


def _reset_auto_state():
    """Uninstrument and reset the auto module's _instrumented flag."""
    auto_mod = _get_auto_mod()
    # Always uninstrument first to remove existing wraps
    auto_mod.uninstrument()
    with auto_mod._lock:
        auto_mod._instrumented = False


# Import real SDK Blob *before* fakes replace google.genai.live, so that
# tests can use the real type without polluting the fake module setup.
from google.genai.types import Blob as _SdkBlob

# Install fake modules at import time so the auto module's top-level
# instrument() call (triggered lazily) will have a patchable target.
_install_fake_genai_module()


@pytest.fixture(autouse=True)
def _auto_cleanup():
    """Ensure auto module is reset after each test."""
    # Re-install fresh fakes and uninstrument before each test
    _install_fake_genai_module()
    _reset_auto_state()
    yield
    # Uninstrument after each test
    _reset_auto_state()


# ---- Tests -------------------------------------------------------------------


def test_instrument_patches_all_methods():
    """instrument() wraps all 7 target methods on AsyncLive/AsyncSession."""
    live_mod = _install_fake_genai_module()
    auto_mod = _get_auto_mod()

    result = auto_mod.instrument()
    assert result is True

    # Each method should now be wrapped (have __wrapped__ attr from wrapt)
    assert hasattr(live_mod.AsyncLive.connect, "__wrapped__")
    assert hasattr(live_mod.AsyncSession.send_realtime_input, "__wrapped__")
    assert hasattr(live_mod.AsyncSession.send_client_content, "__wrapped__")
    assert hasattr(live_mod.AsyncSession.send_tool_response, "__wrapped__")
    assert hasattr(live_mod.AsyncSession.receive, "__wrapped__")
    assert hasattr(live_mod.AsyncSession._receive, "__wrapped__")
    assert hasattr(live_mod.AsyncSession.close, "__wrapped__")


def test_uninstrument_restores_originals():
    """uninstrument() reverses all patches."""
    from wrapt import BoundFunctionWrapper, FunctionWrapper

    live_mod = _install_fake_genai_module()
    auto_mod = _get_auto_mod()

    original_connect = _FakeAsyncLive.__dict__["connect"]
    original_receive = _FakeAsyncSession.__dict__["receive"]

    auto_mod.instrument()
    # After instrument, the class-level descriptor should be a FunctionWrapper
    assert isinstance(_FakeAsyncLive.__dict__["connect"], FunctionWrapper)

    result = auto_mod.uninstrument()
    assert result is True

    # After uninstrument, methods should be restored to originals
    assert _FakeAsyncLive.__dict__["connect"] is original_connect
    assert _FakeAsyncSession.__dict__["receive"] is original_receive


def test_double_instrument_is_idempotent():
    """Calling instrument() twice doesn't double-wrap."""
    _install_fake_genai_module()
    auto_mod = _get_auto_mod()

    first = auto_mod.instrument()
    assert first is True

    second = auto_mod.instrument()
    assert second is False  # already instrumented


def test_uninstrument_when_not_instrumented_returns_false():
    """uninstrument() returns False when nothing is patched."""
    auto_mod = _get_auto_mod()

    result = auto_mod.uninstrument()
    assert result is False


def test_connect_creates_sidecar_and_calls_on_session_started():
    """Wrapped connect() attaches a sidecar and calls on_session_started."""
    session = _FakeAsyncSession(session_id="test-sess")
    _install_fake_genai_module()
    auto_mod = _get_auto_mod()

    sidecar_calls: list[dict] = []
    mock_sidecar = mock.MagicMock()
    mock_sidecar.on_session_started = mock.MagicMock(return_value=True)

    original_make = auto_mod._make_sidecar

    def _tracked_make():
        sidecar_calls.append({"created": True})
        return mock_sidecar

    auto_mod._make_sidecar = _tracked_make
    try:
        auto_mod.instrument()

        live = _FakeAsyncLive(session=session)

        async def _run():
            async with live.connect(config={}) as sess:
                assert hasattr(sess, "_otel_sidecar")
                assert sess._otel_sidecar is mock_sidecar

        asyncio.run(_run())

        assert len(sidecar_calls) == 1
        mock_sidecar.on_session_started.assert_called_once()
        call_kwargs = mock_sidecar.on_session_started.call_args
        assert call_kwargs.kwargs["session_id"] == "test-sess"
    finally:
        auto_mod._make_sidecar = original_make


def test_send_realtime_input_calls_sidecar():
    """Wrapped send_realtime_input calls sidecar.on_client_request."""
    session = _FakeAsyncSession()
    mock_sidecar = mock.MagicMock()
    session._otel_sidecar = mock_sidecar

    _install_fake_genai_module()
    auto_mod = _get_auto_mod()
    auto_mod.instrument()

    async def _run():
        await session.send_realtime_input(
            audio=b"test",
            audio_chunk_duration_ms=40,
            audio_chunk_bytes=960,
        )

    asyncio.run(_run())

    mock_sidecar.on_client_request.assert_called_once()
    call_kwargs = mock_sidecar.on_client_request.call_args.kwargs
    assert call_kwargs["request_type"] == "realtime_input"
    assert call_kwargs["audio_chunk_duration_ms"] == 40
    assert call_kwargs["audio_chunk_bytes"] == 960


def test_send_client_content_calls_sidecar():
    """Wrapped send_client_content calls sidecar.on_client_request."""
    session = _FakeAsyncSession()
    mock_sidecar = mock.MagicMock()
    session._otel_sidecar = mock_sidecar

    _install_fake_genai_module()
    auto_mod = _get_auto_mod()
    auto_mod.instrument()

    async def _run():
        await session.send_client_content(
            turns={"parts": [{"text": "hello"}]},
            turn_complete=True,
        )

    asyncio.run(_run())

    mock_sidecar.on_client_request.assert_called_once()
    call_kwargs = mock_sidecar.on_client_request.call_args.kwargs
    assert call_kwargs["request_type"] == "client_content"


def test_send_client_content_with_tool_call_ids():
    """send_client_content with __otel_tool_call_ids calls sidecar.on_tool_response."""
    session = _FakeAsyncSession()
    mock_sidecar = mock.MagicMock()
    session._otel_sidecar = mock_sidecar

    _install_fake_genai_module()
    auto_mod = _get_auto_mod()
    auto_mod.instrument()

    async def _run():
        await session.send_client_content(
            turns={"parts": [{"text": "done"}]},
            __otel_tool_call_ids=["c1", "c2"],
        )

    asyncio.run(_run())

    mock_sidecar.on_tool_response.assert_called_once()
    call_kwargs = mock_sidecar.on_tool_response.call_args.kwargs
    assert call_kwargs["call_ids"] == ["c1", "c2"]


def test_send_tool_response_calls_sidecar():
    """Wrapped send_tool_response calls sidecar.on_tool_response with extracted IDs."""
    session = _FakeAsyncSession()
    mock_sidecar = mock.MagicMock()
    session._otel_sidecar = mock_sidecar

    _install_fake_genai_module()
    auto_mod = _get_auto_mod()
    auto_mod.instrument()

    async def _run():
        await session.send_tool_response(
            function_responses=[
                {"id": "tc1", "name": "lookup", "response": {}},
                {"id": "tc2", "name": "search", "response": {}},
            ]
        )

    asyncio.run(_run())

    mock_sidecar.on_tool_response.assert_called_once()
    call_kwargs = mock_sidecar.on_tool_response.call_args.kwargs
    assert call_kwargs["call_ids"] == ["tc1", "tc2"]


def test_receive_yields_messages_and_calls_sidecar():
    """Wrapped receive() yields all messages and calls on_server_message for each."""
    session = _FakeAsyncSession()
    mock_sidecar = mock.MagicMock()
    session._otel_sidecar = mock_sidecar

    _install_fake_genai_module()
    auto_mod = _get_auto_mod()
    auto_mod.instrument()

    received: list[Any] = []

    async def _run():
        async for msg in session.receive():
            received.append(msg)

    asyncio.run(_run())

    assert len(received) == 2
    assert mock_sidecar.on_server_message.call_count == 2


def test_close_calls_sidecar():
    """Wrapped close() calls sidecar.on_session_closed."""
    session = _FakeAsyncSession()
    mock_sidecar = mock.MagicMock()
    session._otel_sidecar = mock_sidecar

    _install_fake_genai_module()
    auto_mod = _get_auto_mod()
    auto_mod.instrument()

    async def _run():
        await session.close()

    asyncio.run(_run())

    mock_sidecar.on_session_closed.assert_called_once()
    assert session.closed is True  # original close still executed


def test_api_error_on_send_realtime_input():
    """API errors during send_realtime_input call sidecar.on_api_error."""
    session = _FailingAsyncSession()
    mock_sidecar = mock.MagicMock()
    session._otel_sidecar = mock_sidecar

    # Register the failing class so wrapt patches it directly
    _install_fake_genai_module(async_session_cls=_FailingAsyncSession)
    auto_mod = _get_auto_mod()
    auto_mod.instrument()

    async def _run():
        with pytest.raises(RuntimeError, match="RESOURCE_EXHAUSTED"):
            await session.send_realtime_input(audio=b"x")

    asyncio.run(_run())

    # on_client_request should still have been called before the error
    mock_sidecar.on_client_request.assert_called_once()
    # on_api_error should have been called with the error details
    mock_sidecar.on_api_error.assert_called_once()
    call_kwargs = mock_sidecar.on_api_error.call_args.kwargs
    assert call_kwargs["code"] == "RESOURCE_EXHAUSTED"


def test_api_error_on_receive():
    """API errors during receive() call sidecar.on_api_error."""

    class _FailingReceiveSession(_FakeAsyncSession):
        async def receive(self):
            raise RuntimeError("UNAVAILABLE: server down")
            yield  # noqa: unreachable -- makes it a generator

    session = _FailingReceiveSession()
    mock_sidecar = mock.MagicMock()
    session._otel_sidecar = mock_sidecar

    # Register the failing class so wrapt patches it directly
    _install_fake_genai_module(async_session_cls=_FailingReceiveSession)
    auto_mod = _get_auto_mod()
    auto_mod.instrument()

    async def _run():
        with pytest.raises(RuntimeError, match="UNAVAILABLE"):
            async for _ in session.receive():
                pass

    asyncio.run(_run())

    mock_sidecar.on_api_error.assert_called_once()
    call_kwargs = mock_sidecar.on_api_error.call_args.kwargs
    assert call_kwargs["code"] == "UNAVAILABLE"


def test_multiple_sessions_get_separate_sidecars():
    """Each connect() creates an independent sidecar."""
    sess1 = _FakeAsyncSession(session_id="s1")
    sess2 = _FakeAsyncSession(session_id="s2")

    sessions_iter = iter([sess1, sess2])

    class _MultiLive:
        @asynccontextmanager
        async def connect(self, **kwargs):
            yield next(sessions_iter)

    _install_fake_genai_module(async_live_cls=_MultiLive)
    auto_mod = _get_auto_mod()

    sidecars: list[mock.MagicMock] = []
    original_make = auto_mod._make_sidecar

    def _tracked_make():
        s = mock.MagicMock()
        s.on_session_started = mock.MagicMock(return_value=True)
        sidecars.append(s)
        return s

    auto_mod._make_sidecar = _tracked_make
    try:
        auto_mod.instrument()

        async def _run():
            live = _MultiLive()
            async with live.connect() as s1:
                pass
            async with live.connect() as s2:
                pass

        asyncio.run(_run())

        assert len(sidecars) == 2
        assert sidecars[0] is not sidecars[1]
    finally:
        auto_mod._make_sidecar = original_make


def test_env_disabled_skips_instrumentation():
    """GEMINI_OTEL_ENABLED=0 prevents patching."""
    _install_fake_genai_module()
    auto_mod = _get_auto_mod()

    with mock.patch.dict("os.environ", {"GEMINI_OTEL_ENABLED": "0"}):
        result = auto_mod.instrument()

    assert result is False


def test_env_disabled_false_string():
    """GEMINI_OTEL_ENABLED=false prevents patching."""
    _install_fake_genai_module()
    auto_mod = _get_auto_mod()

    with mock.patch.dict("os.environ", {"GEMINI_OTEL_ENABLED": "false"}):
        result = auto_mod.instrument()

    assert result is False


def test_env_project_and_region():
    """GEMINI_OTEL_PROJECT and GEMINI_OTEL_REGION are read correctly."""
    auto_mod = _get_auto_mod()

    with mock.patch.dict(
        "os.environ",
        {"GEMINI_OTEL_PROJECT": "my-proj", "GEMINI_OTEL_REGION": "europe-west1"},
    ):
        assert auto_mod._env_project() == "my-proj"
        assert auto_mod._env_region() == "europe-west1"


def test_env_target_model():
    """GEMINI_OTEL_TARGET_MODEL overrides default."""
    auto_mod = _get_auto_mod()

    with mock.patch.dict(
        "os.environ",
        {"GEMINI_OTEL_TARGET_MODEL": "gemini-2.0-flash"},
    ):
        assert auto_mod._env_target_model() == "gemini-2.0-flash"


def test_fail_open_when_genai_not_importable():
    """instrument() returns False gracefully when google.genai is not installed."""
    auto_mod = _get_auto_mod()

    # Temporarily remove google.genai.live from sys.modules
    saved = {}
    for key in list(sys.modules):
        if key.startswith("google.genai") or key == "google":
            saved[key] = sys.modules.pop(key)

    original_import = __import__

    def _failing_import(name, *args, **kwargs):
        if "google.genai" in name:
            raise ImportError("No module named 'google.genai'")
        return original_import(name, *args, **kwargs)

    try:
        with mock.patch("builtins.__import__", side_effect=_failing_import):
            result = auto_mod.instrument()
        assert result is False
    finally:
        sys.modules.update(saved)


def test_fail_open_when_wrapt_not_installed():
    """instrument() returns False gracefully when wrapt is not installed."""
    _install_fake_genai_module()
    auto_mod = _get_auto_mod()

    # Save wrapt and replace with None to simulate ImportError
    saved_wrapt = sys.modules.get("wrapt")
    sys.modules["wrapt"] = None  # type: ignore[assignment]
    try:
        result = auto_mod.instrument()
        assert result is False
    finally:
        if saved_wrapt is not None:
            sys.modules["wrapt"] = saved_wrapt
        else:
            sys.modules.pop("wrapt", None)


def test_no_sidecar_receive_still_yields():
    """When no sidecar is attached, receive() still yields messages normally."""
    session = _FakeAsyncSession()
    # No _otel_sidecar attached

    _install_fake_genai_module()
    auto_mod = _get_auto_mod()
    auto_mod.instrument()

    received: list[Any] = []

    async def _run():
        async for msg in session.receive():
            received.append(msg)

    asyncio.run(_run())

    assert len(received) == 2


def test_no_sidecar_close_still_works():
    """When no sidecar is attached, close() still calls the original."""
    session = _FakeAsyncSession()

    _install_fake_genai_module()
    auto_mod = _get_auto_mod()
    auto_mod.instrument()

    async def _run():
        await session.close()

    asyncio.run(_run())

    assert session.closed is True


def test_send_realtime_input_forwards_args():
    """Wrapped send_realtime_input forwards all kwargs to the original."""
    session = _FakeAsyncSession()
    mock_sidecar = mock.MagicMock()
    session._otel_sidecar = mock_sidecar

    _install_fake_genai_module()
    auto_mod = _get_auto_mod()
    auto_mod.instrument()

    async def _run():
        await session.send_realtime_input(
            audio=b"hello",
            video=None,
            text="hi",
        )

    asyncio.run(_run())

    assert len(session.sent_realtime) == 1
    assert session.sent_realtime[0]["audio"] == b"hello"
    assert session.sent_realtime[0]["text"] == "hi"


def test_send_tool_response_forwards_args():
    """Wrapped send_tool_response forwards function_responses to the original."""
    session = _FakeAsyncSession()
    mock_sidecar = mock.MagicMock()
    session._otel_sidecar = mock_sidecar

    _install_fake_genai_module()
    auto_mod = _get_auto_mod()
    auto_mod.instrument()

    responses = [{"id": "c1", "name": "fn", "response": {"result": 42}}]

    async def _run():
        await session.send_tool_response(function_responses=responses)

    asyncio.run(_run())

    assert len(session.sent_tool) == 1
    assert session.sent_tool[0]["function_responses"] == responses


def test_otel_tool_call_ids_stripped_from_kwargs():
    """__otel_tool_call_ids is consumed and not passed to the original method."""
    session = _FakeAsyncSession()
    mock_sidecar = mock.MagicMock()
    session._otel_sidecar = mock_sidecar

    _install_fake_genai_module()
    auto_mod = _get_auto_mod()
    auto_mod.instrument()

    async def _run():
        await session.send_client_content(
            turns={"parts": [{"text": "x"}]},
            __otel_tool_call_ids=["c1"],
        )

    asyncio.run(_run())

    # Original should not receive __otel_tool_call_ids
    assert len(session.sent_client) == 1
    assert "__otel_tool_call_ids" not in session.sent_client[0]


def test_sidecar_failure_does_not_break_receive():
    """If sidecar.on_server_message raises, messages are still yielded."""
    session = _FakeAsyncSession()
    mock_sidecar = mock.MagicMock()
    mock_sidecar.on_server_message.side_effect = ValueError("sidecar boom")
    session._otel_sidecar = mock_sidecar

    _install_fake_genai_module()
    auto_mod = _get_auto_mod()
    auto_mod.instrument()

    received: list[Any] = []

    async def _run():
        async for msg in session.receive():
            received.append(msg)

    asyncio.run(_run())

    # All messages should still be yielded despite sidecar failure
    assert len(received) == 2


def test_sidecar_failure_does_not_break_close():
    """If sidecar.on_session_closed raises, close() still proceeds."""
    session = _FakeAsyncSession()
    mock_sidecar = mock.MagicMock()
    mock_sidecar.on_session_closed.side_effect = ValueError("sidecar boom")
    session._otel_sidecar = mock_sidecar

    _install_fake_genai_module()
    auto_mod = _get_auto_mod()
    auto_mod.instrument()

    async def _run():
        await session.close()

    asyncio.run(_run())

    assert session.closed is True


def test_existing_instrumented_session_still_works():
    """Backward compat: InstrumentedLiveSession works alongside auto.py."""
    from geminiliveotel.integration import instrument_live_session
    from geminiliveotel.sidecar import LiveTelemetrySidecar

    sidecar = LiveTelemetrySidecar(
        target_model=TARGET_MODEL,
        region=REGION,
    )
    fake = _FakeAsyncSession(session_id="compat-sess")
    wrapper = instrument_live_session(
        session=fake,
        sidecar=sidecar,
        model_id=TARGET_MODEL,
        region=REGION,
        automatic_vad=True,
        now_ms=lambda: 100,
    )

    snap = sidecar.snapshot()
    assert snap.gauge("geminilive_concurrent_sessions", model_id=TARGET_MODEL, region=REGION) == 1

    async def _exercise():
        await wrapper.send_realtime_input(
            audio=b"x",
            audio_chunk_duration_ms=40,
            audio_chunk_bytes=960,
        )
        async for _ in wrapper.receive():
            pass
        await wrapper.close()

    asyncio.run(_exercise())

    snap = sidecar.snapshot()
    labels = {"session_id": "compat-sess", "model_id": TARGET_MODEL, "region": REGION}
    assert snap.counter("geminilive_api_requests_total", **labels) == 1
    assert snap.gauge("geminilive_concurrent_sessions", model_id=TARGET_MODEL, region=REGION) == 0


def test_env_export_none():
    """GEMINI_OTEL_EXPORT=none creates sidecar without exporter."""
    auto_mod = _get_auto_mod()

    with mock.patch.dict("os.environ", {"GEMINI_OTEL_EXPORT": "none"}):
        assert auto_mod._env_export_mode() == "none"


def test_make_sidecar_without_project_skips_exporter():
    """_make_sidecar with no project skips Cloud Monitoring exporter."""
    auto_mod = _get_auto_mod()

    env = {k: v for k, v in os.environ.items() if k != "GEMINI_OTEL_PROJECT"}
    with mock.patch.dict("os.environ", env, clear=True):
        sidecar = auto_mod._make_sidecar()
        assert sidecar is not None


def test_classify_error_code():
    """_classify_error_code maps exceptions to gRPC-style codes."""
    from geminiliveotel._helpers import classify_error_code

    assert classify_error_code(RuntimeError("RESOURCE_EXHAUSTED")) == "RESOURCE_EXHAUSTED"
    assert classify_error_code(RuntimeError("UNAVAILABLE")) == "UNAVAILABLE"
    assert classify_error_code(RuntimeError("PERMISSION_DENIED")) == "PERMISSION_DENIED"
    assert classify_error_code(RuntimeError("unknown error")) == "RUNTIMEERROR"


def test_extract_call_ids():
    """_extract_call_ids pulls IDs from function_responses."""
    from geminiliveotel._helpers import extract_call_ids

    assert extract_call_ids([{"id": "a"}, {"id": "b"}]) == ["a", "b"]
    assert extract_call_ids([]) == []
    assert extract_call_ids(None) == []


def test_to_payload_with_model_dump():
    """_to_payload handles objects with model_dump method."""
    from geminiliveotel._helpers import to_payload

    msg = LiveServerMessage(
        server_content=LiveServerContent(turn_complete=True),
    )
    payload = to_payload(msg)
    assert isinstance(payload, dict)
    assert "server_content" in payload

    assert to_payload({"direct": True}) == {"direct": True}
    assert to_payload("not a dict") == {}


def test_connect_measures_ws_connect_latency():
    """Wrapped connect() measures WebSocket connection latency."""
    session = _FakeAsyncSession(session_id="latency-test")
    live = _FakeAsyncLive(session=session)

    _install_fake_genai_module()
    auto_mod = _get_auto_mod()

    mock_sidecar = mock.MagicMock()
    mock_sidecar.on_session_started = mock.MagicMock(return_value=True)

    original_make = auto_mod._make_sidecar
    auto_mod._make_sidecar = lambda: mock_sidecar
    try:
        auto_mod.instrument()

        async def _run():
            async with live.connect() as sess:
                pass

        asyncio.run(_run())

        call_kwargs = mock_sidecar.on_session_started.call_args.kwargs
        assert "connect_duration_ms" in call_kwargs
        assert isinstance(call_kwargs["connect_duration_ms"], float)
    finally:
        auto_mod._make_sidecar = original_make


def test_api_error_on_send_client_content():
    """API errors during send_client_content call sidecar.on_api_error."""

    class _FailingClientContentSession(_FakeAsyncSession):
        async def send_client_content(self, **kwargs: Any) -> None:
            raise RuntimeError("INVALID_ARGUMENT: bad request")

    session = _FailingClientContentSession()
    mock_sidecar = mock.MagicMock()
    session._otel_sidecar = mock_sidecar

    # Register the failing class so wrapt patches it directly
    _install_fake_genai_module(async_session_cls=_FailingClientContentSession)
    auto_mod = _get_auto_mod()
    auto_mod.instrument()

    async def _run():
        with pytest.raises(RuntimeError, match="INVALID_ARGUMENT"):
            await session.send_client_content(turns={})

    asyncio.run(_run())

    mock_sidecar.on_api_error.assert_called_once()
    call_kwargs = mock_sidecar.on_api_error.call_args.kwargs
    assert call_kwargs["code"] == "INVALID_ARGUMENT"


def test_api_error_on_send_tool_response():
    """API errors during send_tool_response call sidecar.on_api_error."""

    class _FailingToolResponseSession(_FakeAsyncSession):
        async def send_tool_response(self, **kwargs: Any) -> None:
            raise RuntimeError("DEADLINE_EXCEEDED: timeout")

    session = _FailingToolResponseSession()
    mock_sidecar = mock.MagicMock()
    session._otel_sidecar = mock_sidecar

    # Register the failing class so wrapt patches it directly
    _install_fake_genai_module(async_session_cls=_FailingToolResponseSession)
    auto_mod = _get_auto_mod()
    auto_mod.instrument()

    async def _run():
        with pytest.raises(RuntimeError, match="DEADLINE_EXCEEDED"):
            await session.send_tool_response(
                function_responses=[{"id": "c1", "name": "fn", "response": {}}]
            )

    asyncio.run(_run())

    # on_tool_response should NOT have been called (send failed)
    mock_sidecar.on_tool_response.assert_not_called()
    # on_api_error should have been called with the error details
    mock_sidecar.on_api_error.assert_called_once()
    call_kwargs = mock_sidecar.on_api_error.call_args.kwargs
    assert call_kwargs["code"] == "DEADLINE_EXCEEDED"


def test_connect_cleanup_on_context_exit():
    """on_session_closed fires when the connect context manager exits."""
    session = _FakeAsyncSession(session_id="cleanup-test")
    live = _FakeAsyncLive(session=session)

    _install_fake_genai_module()
    auto_mod = _get_auto_mod()

    mock_sidecar = mock.MagicMock()
    mock_sidecar.on_session_started = mock.MagicMock(return_value=True)

    original_make = auto_mod._make_sidecar
    auto_mod._make_sidecar = lambda: mock_sidecar
    try:
        auto_mod.instrument()

        async def _run():
            async with live.connect() as sess:
                # Session is active here
                pass
            # Context manager has exited

        asyncio.run(_run())

        # on_session_closed should fire on context exit
        mock_sidecar.on_session_closed.assert_called()
        call_kwargs = mock_sidecar.on_session_closed.call_args.kwargs
        assert call_kwargs["session_id"] == "cleanup-test"
    finally:
        auto_mod._make_sidecar = original_make


def test_receive_single_calls_sidecar():
    """Wrapped _receive() calls sidecar.on_server_message for the returned message."""
    session = _FakeAsyncSession()
    mock_sidecar = mock.MagicMock()
    session._otel_sidecar = mock_sidecar

    _install_fake_genai_module()
    auto_mod = _get_auto_mod()
    auto_mod.instrument()

    async def _run():
        msg = await session._receive()
        return msg

    result = asyncio.run(_run())

    assert result is not None
    mock_sidecar.on_server_message.assert_called_once()


def test_receive_single_no_sidecar_still_works():
    """_receive() works normally without sidecar attached."""
    session = _FakeAsyncSession()

    _install_fake_genai_module()
    auto_mod = _get_auto_mod()
    auto_mod.instrument()

    async def _run():
        return await session._receive()

    result = asyncio.run(_run())
    assert result is not None


def test_audio_kwargs_stripped_before_forwarding():
    """audio_chunk_duration_ms and audio_chunk_bytes are stripped from kwargs."""
    session = _FakeAsyncSession()
    mock_sidecar = mock.MagicMock()
    session._otel_sidecar = mock_sidecar

    _install_fake_genai_module()
    auto_mod = _get_auto_mod()
    auto_mod.instrument()

    async def _run():
        await session.send_realtime_input(
            audio=b"test",
            audio_chunk_duration_ms=40,
            audio_chunk_bytes=960,
        )

    asyncio.run(_run())

    # Original method should NOT receive the otel kwargs
    assert len(session.sent_realtime) == 1
    assert "audio_chunk_duration_ms" not in session.sent_realtime[0]
    assert "audio_chunk_bytes" not in session.sent_realtime[0]
    assert session.sent_realtime[0]["audio"] == b"test"

    # Sidecar should have received them
    call_kwargs = mock_sidecar.on_client_request.call_args.kwargs
    assert call_kwargs["audio_chunk_duration_ms"] == 40
    assert call_kwargs["audio_chunk_bytes"] == 960


def test_instrument_patches_receive_single():
    """instrument() also patches _receive()."""
    live_mod = _install_fake_genai_module()
    auto_mod = _get_auto_mod()

    auto_mod.instrument()
    assert hasattr(live_mod.AsyncSession._receive, "__wrapped__")


def test_audio_chunk_bytes_auto_computed_from_raw_bytes():
    """audio_chunk_bytes is auto-computed from raw bytes audio data."""
    session = _FakeAsyncSession()
    mock_sidecar = mock.MagicMock()
    session._otel_sidecar = mock_sidecar

    _install_fake_genai_module()
    auto_mod = _get_auto_mod()
    auto_mod.instrument()

    audio_data = b"\x00" * 960  # 960 bytes

    async def _run():
        await session.send_realtime_input(audio=audio_data)

    asyncio.run(_run())

    call_kwargs = mock_sidecar.on_client_request.call_args.kwargs
    assert call_kwargs["audio_chunk_bytes"] == 960
    # No mime_type → duration cannot be computed
    assert call_kwargs["audio_chunk_duration_ms"] is None


def test_audio_chunk_duration_auto_computed_from_blob():
    """audio_chunk_duration_ms is auto-computed when mime_type includes rate=."""

    session = _FakeAsyncSession()
    mock_sidecar = mock.MagicMock()
    session._otel_sidecar = mock_sidecar

    _install_fake_genai_module()
    auto_mod = _get_auto_mod()
    auto_mod.instrument()

    # 16000 Hz, 16-bit (2 bytes/sample), mono
    # 30ms of audio = 16000 * 0.030 * 2 = 960 bytes
    audio_blob = _SdkBlob(data=b"\x00" * 960, mime_type="audio/pcm;rate=16000")

    async def _run():
        await session.send_realtime_input(audio=audio_blob)

    asyncio.run(_run())

    call_kwargs = mock_sidecar.on_client_request.call_args.kwargs
    assert call_kwargs["audio_chunk_bytes"] == 960
    assert call_kwargs["audio_chunk_duration_ms"] == 30


def test_audio_chunk_auto_computed_from_dict():
    """Audio chunk info is auto-computed from dict-style audio data."""
    session = _FakeAsyncSession()
    mock_sidecar = mock.MagicMock()
    session._otel_sidecar = mock_sidecar

    _install_fake_genai_module()
    auto_mod = _get_auto_mod()
    auto_mod.instrument()

    # 16000 Hz, 16-bit, mono: 640 bytes = 20ms
    audio_dict = {"data": b"\x00" * 640, "mime_type": "audio/pcm;rate=16000"}

    async def _run():
        await session.send_realtime_input(audio=audio_dict)

    asyncio.run(_run())

    call_kwargs = mock_sidecar.on_client_request.call_args.kwargs
    assert call_kwargs["audio_chunk_bytes"] == 640
    assert call_kwargs["audio_chunk_duration_ms"] == 20


def test_explicit_audio_chunk_values_take_precedence():
    """Explicit user-provided audio_chunk values override auto-computed ones."""
    session = _FakeAsyncSession()
    mock_sidecar = mock.MagicMock()
    session._otel_sidecar = mock_sidecar

    _install_fake_genai_module()
    auto_mod = _get_auto_mod()
    auto_mod.instrument()

    async def _run():
        await session.send_realtime_input(
            audio=b"\x00" * 960,
            audio_chunk_duration_ms=50,
            audio_chunk_bytes=1000,
        )

    asyncio.run(_run())

    call_kwargs = mock_sidecar.on_client_request.call_args.kwargs
    # Explicit values should be used, not auto-computed
    assert call_kwargs["audio_chunk_bytes"] == 1000
    assert call_kwargs["audio_chunk_duration_ms"] == 50


def test_now_ms_uses_monotonic_clock():
    """_now_ms() returns values consistent with time.monotonic(), not time.time()."""
    import time

    from geminiliveotel._helpers import now_ms

    mono_before = int(time.monotonic() * 1000)
    result = now_ms()
    mono_after = int(time.monotonic() * 1000)

    assert mono_before <= result <= mono_after


def test_connect_non_target_model_not_instrumented():
    """connect() with a non-target model sets _otel_sidecar to None."""
    session = _FakeAsyncSession(session_id="non-target-sess")
    live = _FakeAsyncLive(session=session)

    _install_fake_genai_module()
    auto_mod = _get_auto_mod()

    from geminiliveotel.sidecar import LiveTelemetrySidecar

    sidecar = LiveTelemetrySidecar(
        target_model=TARGET_MODEL,
        region=REGION,
        concurrency_quota=1000,
    )
    original_make = auto_mod._make_sidecar
    auto_mod._make_sidecar = lambda: sidecar
    try:
        auto_mod.instrument()

        async def _run():
            async with live.connect(model="gemini-2.0-flash-live") as sess:
                # Non-target model: sidecar should be set to None
                assert sess._otel_sidecar is None

        asyncio.run(_run())

        # Sidecar should have 0 concurrent sessions (rejected by model filter)
        snap = sidecar.snapshot()
        assert snap.gauge("geminilive_concurrent_sessions", model_id=TARGET_MODEL, region=REGION) == 0
    finally:
        auto_mod._make_sidecar = original_make


def test_connect_target_model_is_instrumented():
    """connect() with the target model attaches sidecar for instrumentation."""
    session = _FakeAsyncSession(session_id="target-sess")
    live = _FakeAsyncLive(session=session)

    _install_fake_genai_module()
    auto_mod = _get_auto_mod()

    from geminiliveotel.sidecar import LiveTelemetrySidecar

    sidecar = LiveTelemetrySidecar(
        target_model=TARGET_MODEL,
        region=REGION,
        concurrency_quota=1000,
    )
    original_make = auto_mod._make_sidecar
    auto_mod._make_sidecar = lambda: sidecar
    try:
        auto_mod.instrument()

        async def _run():
            async with live.connect(model=TARGET_MODEL) as sess:
                # Target model: sidecar should be attached
                assert sess._otel_sidecar is sidecar

        asyncio.run(_run())

        # Sidecar should have tracked the session (0 after context exit)
        snap = sidecar.snapshot()
        assert snap.gauge("geminilive_concurrent_sessions", model_id=TARGET_MODEL, region=REGION) == 0
    finally:
        auto_mod._make_sidecar = original_make


def test_env_cumulative_tokens():
    """GEMINI_OTEL_CUMULATIVE_TOKENS env var parsing."""
    auto_mod = _get_auto_mod()

    with mock.patch.dict("os.environ", {"GEMINI_OTEL_CUMULATIVE_TOKENS": "1"}):
        assert auto_mod._env_token_counting() == "cumulative"

    with mock.patch.dict("os.environ", {"GEMINI_OTEL_CUMULATIVE_TOKENS": "true"}):
        assert auto_mod._env_token_counting() == "cumulative"

    with mock.patch.dict("os.environ", {"GEMINI_OTEL_CUMULATIVE_TOKENS": "0"}):
        assert auto_mod._env_token_counting() == "incremental"

    # Default (not set)
    env = {k: v for k, v in os.environ.items() if k != "GEMINI_OTEL_CUMULATIVE_TOKENS"}
    with mock.patch.dict("os.environ", env, clear=True):
        assert auto_mod._env_token_counting() == "incremental"


def test_update_quota_on_shared_sidecar():
    """update_quota() updates the shared sidecar's concurrency quota."""
    _install_fake_genai_module()
    auto_mod = _get_auto_mod()

    from geminiliveotel.sidecar import LiveTelemetrySidecar

    sidecar = LiveTelemetrySidecar(
        target_model=TARGET_MODEL,
        region=REGION,
        concurrency_quota=1000,
    )
    auto_mod._shared_sidecar = sidecar
    try:
        result = auto_mod.update_quota(500)
        assert result is True
        assert sidecar._concurrency_quota == 500
    finally:
        auto_mod._shared_sidecar = None


def test_update_quota_returns_false_when_no_sidecar():
    """update_quota() returns False when no shared sidecar exists."""
    auto_mod = _get_auto_mod()
    auto_mod._shared_sidecar = None

    result = auto_mod.update_quota(500)
    assert result is False


def test_ws_error_calls_on_ws_error():
    """WebSocket errors call both on_api_error and on_ws_error."""

    class _WsErrorSession(_FakeAsyncSession):
        async def send_realtime_input(self, **kwargs: Any) -> None:
            raise RuntimeError("websocket connection closed abnormally")

    session = _WsErrorSession()
    mock_sidecar = mock.MagicMock()
    session._otel_sidecar = mock_sidecar

    _install_fake_genai_module(async_session_cls=_WsErrorSession)
    auto_mod = _get_auto_mod()
    auto_mod.instrument()

    async def _run():
        with pytest.raises(RuntimeError, match="websocket"):
            await session.send_realtime_input(audio=b"x")

    asyncio.run(_run())

    mock_sidecar.on_api_error.assert_called_once()
    mock_sidecar.on_ws_error.assert_called_once()
    ws_kwargs = mock_sidecar.on_ws_error.call_args.kwargs
    assert ws_kwargs["error_type"] == "WS_ERROR"


def test_uninstrument_stops_exporter():
    """uninstrument() calls exporter.stop() on the shared sidecar."""
    _install_fake_genai_module()
    auto_mod = _get_auto_mod()

    from geminiliveotel.sidecar import LiveTelemetrySidecar

    sidecar = LiveTelemetrySidecar(
        target_model=TARGET_MODEL,
        region=REGION,
        concurrency_quota=1000,
    )
    mock_exporter = mock.MagicMock()
    sidecar._exporter = mock_exporter

    auto_mod._shared_sidecar = sidecar
    auto_mod._instrumented = True

    auto_mod.uninstrument()

    mock_exporter.stop.assert_called_once()
    assert auto_mod._shared_sidecar is None


import os


def test_instrument_does_not_trigger_eager_bootstrap():
    """L9: instrument() should not eagerly call _make_sidecar()."""
    _install_fake_genai_module()
    auto_mod = _get_auto_mod()

    make_calls = []
    original_make = auto_mod._make_sidecar

    def _tracking_make():
        make_calls.append(True)
        return original_make()

    auto_mod._make_sidecar = _tracking_make
    try:
        with mock.patch.dict("os.environ", {"GEMINI_OTEL_PROJECT": "test-proj"}):
            result = auto_mod.instrument()

        assert result is True
        assert len(make_calls) == 0, "_make_sidecar should not be called during instrument()"
    finally:
        auto_mod._make_sidecar = original_make
