from __future__ import annotations

from dataclasses import dataclass

from geminiliveotel.bootstrap import (
    bootstrap_vertex_live_observability,
    fetch_native_audio_concurrency_quota,
)


@dataclass
class _Response:
    status_code: int
    payload: dict

    @property
    def text(self) -> str:
        return str(self.payload)

    def json(self) -> dict:
        return self.payload


class _FakeSession:
    def __init__(self, responses: list[_Response]) -> None:
        self._responses = responses
        self.calls: list[tuple[str, str, dict | None]] = []

    def get(self, url: str, *, params: dict | None = None, timeout: int = 30):
        del timeout
        self.calls.append(("GET", url, params))
        return self._responses.pop(0)

    def post(self, url: str, *, json: dict | None = None, timeout: int = 30):
        del timeout
        self.calls.append(("POST", url, json))
        return self._responses.pop(0)


class _AlwaysOkSession:
    def __init__(self) -> None:
        self.calls: list[tuple[str, str, dict | None]] = []

    def get(self, url: str, *, params: dict | None = None, timeout: int = 30):
        del timeout
        self.calls.append(("GET", url, params))
        return _Response(200, {"metrics": []})

    def post(self, url: str, *, json: dict | None = None, timeout: int = 30):
        del timeout
        self.calls.append(("POST", url, json))
        if "dashboards" in url:
            return _Response(
                200,
                {
                    "name": "projects/demo-project/dashboards/new123",
                    "displayName": "Gemini Live Native Audio OTel Dashboard 20260208-000000-feedface",
                },
            )
        return _Response(200, {})


def test_fetch_concurrency_quota_from_service_usage() -> None:
    session = _FakeSession(
        [
            _Response(
                200,
                {
                    "metrics": [
                        {
                            "metric": "aiplatform.googleapis.com/live_concurrent_sessions",
                            "displayName": "Live concurrent sessions",
                            "consumerQuotaLimits": [
                                {
                                    "unit": "1/{project}/{region}",
                                    "quotaBuckets": [
                                        {
                                            "effectiveLimit": "750",
                                            "dimensions": {"region": "us-central1"},
                                        }
                                    ],
                                }
                            ],
                        }
                    ]
                },
            )
        ]
    )

    value = fetch_native_audio_concurrency_quota(
        project_id="demo-project",
        region="us-central1",
        fallback=1000,
        session=session,
    )

    assert value == 750
    assert session.calls[0][0] == "GET"
    assert "serviceusage.googleapis.com" in session.calls[0][1]
    assert "/v1beta1/" in session.calls[0][1]


def test_fetch_concurrency_quota_prefers_target_model_and_region_bucket() -> None:
    session = _FakeSession(
        [
            _Response(
                200,
                {
                    "metrics": [
                        {
                            "metric": "aiplatform.googleapis.com/bidi_gen_concurrent_reqs_per_project_per_base_model",
                            "displayName": "Bidi generate content concurrent requests per project per region per base model",
                            "consumerQuotaLimits": [
                                {
                                    "unit": "1/10min/{project}/{region}/{base_model}",
                                    "quotaBuckets": [
                                        {
                                            "effectiveLimit": "5000",
                                            "dimensions": {
                                                "region": "us-central1",
                                                "base_model": "gemini-live-2.5-flash",
                                            },
                                        },
                                        {
                                            "effectiveLimit": "1000",
                                            "dimensions": {
                                                "region": "us-central1",
                                                "base_model": "gemini-live-2.5-flash-native-audio",
                                            },
                                        },
                                        {
                                            "effectiveLimit": "1000",
                                            "dimensions": {
                                                "region": "us-east1",
                                                "base_model": "gemini-live-2.5-flash-native-audio",
                                            },
                                        },
                                    ],
                                }
                            ],
                        }
                    ]
                },
            )
        ]
    )

    value = fetch_native_audio_concurrency_quota(
        project_id="demo-project",
        region="us-central1",
        target_model="gemini-live-2.5-flash-native-audio",
        fallback=1000,
        session=session,
    )

    assert value == 1000


def test_fetch_concurrency_quota_uses_model_aware_buckets_across_pages() -> None:
    session = _FakeSession(
        [
            _Response(
                200,
                {
                    "metrics": [
                        {
                            "metric": "aiplatform.googleapis.com/automl_tables_concurrent_model_training_jobs",
                            "displayName": "Unrelated concurrent jobs",
                            "consumerQuotaLimits": [
                                {
                                    "unit": "1/{project}/{region}",
                                    "quotaBuckets": [{"effectiveLimit": "3"}],
                                }
                            ],
                        }
                    ],
                    "nextPageToken": "next",
                },
            ),
            _Response(
                200,
                {
                    "metrics": [
                        {
                            "metric": "aiplatform.googleapis.com/bidi_gen_concurrent_reqs_per_project_per_base_model",
                            "displayName": "Bidi generate content concurrent requests per project per region per base model",
                            "consumerQuotaLimits": [
                                {
                                    "unit": "1/10min/{project}/{region}/{base_model}",
                                    "quotaBuckets": [
                                        {
                                            "effectiveLimit": "1000",
                                            "dimensions": {
                                                "region": "us-central1",
                                                "base_model": "gemini-live-2.5-flash-native-audio",
                                            },
                                        }
                                    ],
                                }
                            ],
                        }
                    ]
                },
            ),
        ]
    )

    value = fetch_native_audio_concurrency_quota(
        project_id="demo-project",
        region="us-central1",
        target_model="gemini-live-2.5-flash-native-audio",
        fallback=1000,
        session=session,
    )

    assert value == 1000


def test_fetch_concurrency_quota_falls_back_on_error_with_warning() -> None:
    session = _FakeSession([_Response(403, {"error": {"message": "permission denied"}})])

    warnings: list[str] = []

    class _Logger:
        def warning(self, message: str, *args) -> None:
            warnings.append(message % args if args else message)

    value = fetch_native_audio_concurrency_quota(
        project_id="demo-project",
        region="us-central1",
        fallback=1000,
        session=session,
        logger=_Logger(),
    )

    assert value == 1000
    assert warnings
    assert "fallback" in warnings[0].lower()


def test_bootstrap_auto_fetches_quota_and_auto_creates_dashboard() -> None:
    session = _FakeSession(
        [
            _Response(
                200,
                {
                    "metrics": [
                        {
                            "metric": "aiplatform.googleapis.com/live_concurrent_sessions",
                            "displayName": "Live concurrent sessions",
                            "consumerQuotaLimits": [
                                {
                                    "unit": "1/{project}/{region}",
                                    "quotaBuckets": [{"effectiveLimit": "880"}],
                                }
                            ],
                        }
                    ]
                },
            ),
            _Response(
                200,
                {
                    "name": "projects/demo-project/dashboards/abc123",
                    "displayName": "Gemini Live Native Audio OTel Dashboard 20260208-000000-deadbeef",
                },
            ),
        ]
    )

    result = bootstrap_vertex_live_observability(
        project_id="demo-project",
        region="us-central1",
        session=session,
        auto_export_metrics=False,
    )

    assert result.resolved_concurrency_quota == 880
    assert result.quota_source == "api"
    assert result.dashboard_name == "projects/demo-project/dashboards/abc123"
    assert "Gemini Live Native Audio OTel Dashboard" in (result.dashboard_display_name or "")

    methods = [call[0] for call in session.calls]
    assert methods == ["GET", "POST"]
    assert "serviceusage.googleapis.com" in session.calls[0][1]
    assert "monitoring.googleapis.com" in session.calls[1][1]


def test_bootstrap_dashboard_creation_fails_open_with_warning() -> None:
    session = _FakeSession(
        [
            _Response(
                200,
                {
                    "metrics": [
                        {
                            "metric": "aiplatform.googleapis.com/live_concurrent_sessions",
                            "displayName": "Live concurrent sessions",
                            "consumerQuotaLimits": [
                                {
                                    "unit": "1/{project}/{region}",
                                    "quotaBuckets": [{"effectiveLimit": "900"}],
                                }
                            ],
                        }
                    ]
                },
            ),
            _Response(500, {"error": {"message": "internal"}}),
        ]
    )

    warnings: list[str] = []

    class _Logger:
        def warning(self, message: str, *args) -> None:
            warnings.append(message % args if args else message)

    result = bootstrap_vertex_live_observability(
        project_id="demo-project",
        region="us-central1",
        session=session,
        logger=_Logger(),
        auto_export_metrics=False,
    )

    assert result.resolved_concurrency_quota == 900
    assert result.dashboard_name is None
    assert result.dashboard_display_name is None
    assert warnings
    assert "dashboard" in warnings[0].lower()


def test_bootstrap_defaults_group_by_session_id_to_false() -> None:
    session = _AlwaysOkSession()

    bootstrap_vertex_live_observability(
        project_id="demo-project",
        region="us-central1",
        auto_fetch_quota=False,
        auto_create_dashboard=True,
        auto_export_metrics=False,
        session=session,
    )

    # Find the POST to dashboards and inspect the spec
    dashboard_posts = [
        call for call in session.calls if call[0] == "POST" and "dashboards" in call[1]
    ]
    assert dashboard_posts, "Expected a POST to create a dashboard"
    dashboard_spec = dashboard_posts[0][2]
    for tile in dashboard_spec["mosaicLayout"]["tiles"]:
        widget = tile["widget"]
        if "xyChart" in widget:
            group_fields = widget["xyChart"]["dataSets"][0]["timeSeriesQuery"][
                "timeSeriesFilter"
            ]["aggregation"].get("groupByFields", [])
            assert "metric.label.session_id" not in group_fields, (
                f"Widget '{widget['title']}' should not group by session_id by default"
            )


def test_bootstrap_can_auto_enable_metric_exporter() -> None:
    session = _AlwaysOkSession()

    result = bootstrap_vertex_live_observability(
        project_id="demo-project",
        region="us-central1",
        auto_fetch_quota=False,
        auto_create_dashboard=False,
        auto_export_metrics=True,
        start_export_background=False,
        session=session,
    )

    assert result.resolved_concurrency_quota == 1000
    assert any("/metricDescriptors" in call[1] for call in session.calls if call[0] == "POST")


def test_bootstrap_standalone_creates_dashboard_before_any_sessions() -> None:
    session = _AlwaysOkSession()

    result = bootstrap_vertex_live_observability(
        project_id="demo-project",
        region="us-central1",
        auto_fetch_quota=False,
        auto_create_dashboard=True,
        auto_export_metrics=False,
        session=session,
    )

    assert result.dashboard_name is not None
    assert result.sidecar is not None

    # No sessions have been started
    snapshot = result.sidecar.snapshot()
    assert (
        snapshot.gauge(
            "geminilive_concurrent_sessions",
            model_id="gemini-live-2.5-flash-native-audio",
            region="us-central1",
        )
        == 0
    )

    # Dashboard spec was POSTed to the monitoring API
    dashboard_posts = [
        call for call in session.calls if call[0] == "POST" and "dashboards" in call[1]
    ]
    assert dashboard_posts


def test_exact_metric_name_matching() -> None:
    session = _FakeSession(
        [
            _Response(
                200,
                {
                    "metrics": [
                        {
                            "metric": "aiplatform.googleapis.com/live_concurrent_sessions",
                            "displayName": "Live concurrent sessions",
                            "consumerQuotaLimits": [
                                {
                                    "unit": "1/{project}/{region}",
                                    "quotaBuckets": [
                                        {"effectiveLimit": "999"},
                                    ],
                                }
                            ],
                        },
                        {
                            "metric": "aiplatform.googleapis.com/bidi_gen_concurrent",
                            "displayName": "Bidi generate concurrent",
                            "consumerQuotaLimits": [
                                {
                                    "unit": "1/{project}/{region}",
                                    "quotaBuckets": [
                                        {"effectiveLimit": "500"},
                                    ],
                                }
                            ],
                        },
                    ]
                },
            )
        ]
    )

    value = fetch_native_audio_concurrency_quota(
        project_id="demo-project",
        region="us-central1",
        fallback=1000,
        session=session,
        metric_name="bidi_gen_concurrent",
    )

    assert value == 500


def test_exact_metric_name_fallback_to_heuristic() -> None:
    session = _FakeSession(
        [
            _Response(
                200,
                {
                    "metrics": [
                        {
                            "metric": "aiplatform.googleapis.com/live_concurrent_sessions",
                            "displayName": "Live concurrent sessions",
                            "consumerQuotaLimits": [
                                {
                                    "unit": "1/{project}/{region}",
                                    "quotaBuckets": [
                                        {
                                            "effectiveLimit": "750",
                                            "dimensions": {"region": "us-central1"},
                                        },
                                    ],
                                }
                            ],
                        }
                    ]
                },
            )
        ]
    )

    value = fetch_native_audio_concurrency_quota(
        project_id="demo-project",
        region="us-central1",
        fallback=1000,
        session=session,
        metric_name="nonexistent_metric",
    )

    assert value == 750


def test_api_version_configurable() -> None:
    session = _FakeSession(
        [
            _Response(
                200,
                {
                    "metrics": [
                        {
                            "metric": "aiplatform.googleapis.com/live_concurrent_sessions",
                            "displayName": "Live concurrent sessions",
                            "consumerQuotaLimits": [
                                {
                                    "unit": "1/{project}/{region}",
                                    "quotaBuckets": [
                                        {
                                            "effectiveLimit": "750",
                                            "dimensions": {"region": "us-central1"},
                                        },
                                    ],
                                }
                            ],
                        }
                    ]
                },
            )
        ]
    )

    fetch_native_audio_concurrency_quota(
        project_id="demo-project",
        region="us-central1",
        fallback=1000,
        session=session,
        api_version="v2",
    )

    assert "/v2/" in session.calls[0][1]


def test_bootstrap_quota_source_is_fallback_when_api_skipped() -> None:
    """L8: quota_source should be 'fallback' when auto_fetch_quota=False."""
    session = _AlwaysOkSession()

    result = bootstrap_vertex_live_observability(
        project_id="demo-project",
        region="us-central1",
        auto_fetch_quota=False,
        auto_create_dashboard=False,
        auto_export_metrics=False,
        session=session,
    )

    assert result.quota_source == "fallback"
    assert result.resolved_concurrency_quota == 1000
