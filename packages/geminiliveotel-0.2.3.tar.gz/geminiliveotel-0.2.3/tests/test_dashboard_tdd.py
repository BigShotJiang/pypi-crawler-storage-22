from __future__ import annotations

from geminiliveotel.dashboard import build_dashboard_spec, generate_dashboard_display_name


def test_dashboard_name_is_unique_every_time() -> None:
    first = generate_dashboard_display_name(prefix="Gemini Live Native Audio")
    second = generate_dashboard_display_name(prefix="Gemini Live Native Audio")

    assert first != second
    assert first.startswith("Gemini Live Native Audio")
    assert second.startswith("Gemini Live Native Audio")


def test_dashboard_contains_expected_visuals_for_agreed_metrics() -> None:
    dashboard = build_dashboard_spec(project_id="demo-project", region="us-central1")

    titles = [tile["widget"]["title"] for tile in dashboard["mosaicLayout"]["tiles"]]

    assert "Turns Completed (Counter)" in titles
    assert "Successful Responses (Counter)" in titles
    assert "API Errors (Counter)" in titles
    assert "Tool Calls (Counter)" in titles
    assert "TTFAB (p50/p95/p99)" in titles
    assert "Turn End-to-End Latency (p50/p95/p99)" in titles
    assert "Tool Call Roundtrip Latency" in titles
    assert "Model Wait After Tool Response" in titles
    assert "Audio Chunk Duration Distribution" in titles
    assert "Audio Chunk Size Distribution" in titles
    assert "Audio Chunk Noncompliance Rate" in titles
    assert "Token Throughput (tokens/sec)" in titles
    assert "Request QPS" in titles
    assert "Concurrent Sessions" in titles
    assert "Quota Utilization (%)" in titles
    assert "Model Success Rate" in titles
    assert "Total Tokens (Counter)" in titles
    assert "Prompt Tokens (Counter)" in titles
    assert "Response Tokens (Counter)" in titles
    assert "Turn Complete Events (Counter)" in titles
    assert "Server VAD Events (Counter)" in titles
    assert "Client Activity Signals (Counter)" in titles
    assert "VAD Interruptions (Counter)" in titles
    assert "Rate Limit / Quota Errors (Counter)" in titles
    assert "Modality Token Distribution" in titles
    assert "API Requests (Counter)" in titles
    assert "WS Connect Latency (p50/p95/p99)" in titles
    assert "WS Errors (Counter)" in titles


def test_dashboard_queries_use_custom_metric_prefix() -> None:
    dashboard = build_dashboard_spec(project_id="demo-project", region="us-central1")

    filters: list[str] = []
    for tile in dashboard["mosaicLayout"]["tiles"]:
        widget = tile["widget"]
        if "xyChart" in widget:
            for ds in widget["xyChart"].get("dataSets", []):
                ts_filter = ds.get("timeSeriesQuery", {}).get("timeSeriesFilter")
                if ts_filter:
                    filters.append(ts_filter["filter"])
        if "scorecard" in widget:
            ts_filter = widget["scorecard"]["timeSeriesQuery"].get("timeSeriesFilter")
            if ts_filter:
                filters.append(ts_filter["filter"])

    assert filters, "No metric filters were found in dashboard definition"
    for expression in filters:
        assert 'metric.type = "custom.googleapis.com/geminilive/' in expression


def test_concurrency_and_quota_widgets_do_not_group_by_session_id() -> None:
    dashboard = build_dashboard_spec(project_id="demo-project", region="us-central1")

    for tile in dashboard["mosaicLayout"]["tiles"]:
        widget = tile["widget"]
        title = widget["title"]
        if title not in {"Concurrent Sessions", "Quota Utilization (%)"}:
            continue
        data_sets = widget["xyChart"]["dataSets"]
        for data_set in data_sets:
            group_by = data_set["timeSeriesQuery"]["timeSeriesFilter"]["secondaryAggregation"].get(
                "groupByFields", []
            )
            assert "metric.label.session_id" not in group_by


def test_widgets_are_no_data_safe_by_using_time_series_filters_only() -> None:
    dashboard = build_dashboard_spec(project_id="demo-project", region="us-central1")

    # Guardrail: avoid MQL arithmetic joins for now so empty charts show no data instead of query errors.
    for tile in dashboard["mosaicLayout"]["tiles"]:
        widget = tile["widget"]
        xy = widget.get("xyChart")
        if xy:
            for data_set in xy["dataSets"]:
                query = data_set["timeSeriesQuery"]
                assert "timeSeriesFilter" in query
                assert "timeSeriesQueryLanguage" not in query
                assert "prometheusQuery" not in query
        scorecard = widget.get("scorecard")
        if scorecard:
            query = scorecard["timeSeriesQuery"]
            assert "timeSeriesFilter" in query
            assert "timeSeriesQueryLanguage" not in query
            assert "prometheusQuery" not in query


def test_session_grouping_is_applied_for_session_groupable_widgets() -> None:
    dashboard = build_dashboard_spec(
        project_id="demo-project",
        region="us-central1",
        group_by_session_id=True,
    )
    titles_with_session_grouping = {
        "TTFAB (p50/p95/p99)",
        "Turn End-to-End Latency (p50/p95/p99)",
        "WS Connect Latency (p50/p95/p99)",
        "Tool Call Roundtrip Latency",
        "Model Wait After Tool Response",
        "Audio Chunk Duration Distribution",
        "Audio Chunk Size Distribution",
        "Audio Chunk Noncompliance Rate",
        "Token Throughput (tokens/sec)",
        "Request QPS",
        "Model Success Rate",
        "Modality Token Distribution",
    }

    for tile in dashboard["mosaicLayout"]["tiles"]:
        widget = tile["widget"]
        title = widget["title"]
        expect_session_id = title in titles_with_session_grouping
        if "xyChart" in widget:
            group_fields = widget["xyChart"]["dataSets"][0]["timeSeriesQuery"]["timeSeriesFilter"][
                "aggregation"
            ].get("groupByFields", [])
            has_session_field = "metric.label.session_id" in group_fields
            assert has_session_field == expect_session_id
        if "scorecard" in widget:
            group_fields = widget["scorecard"]["timeSeriesQuery"]["timeSeriesFilter"]["aggregation"].get(
                "groupByFields", []
            )
            has_session_field = "metric.label.session_id" in group_fields
            assert has_session_field is False


def test_counter_scorecards_use_integer_friendly_aggregation() -> None:
    dashboard = build_dashboard_spec(project_id="demo-project", region="us-central1")
    counter_titles = {
        "Turns Completed (Counter)",
        "Successful Responses (Counter)",
        "API Errors (Counter)",
        "Tool Calls (Counter)",
        "Total Tokens (Counter)",
        "Prompt Tokens (Counter)",
        "Response Tokens (Counter)",
        "Turn Complete Events (Counter)",
        "Server VAD Events (Counter)",
        "Client Activity Signals (Counter)",
        "VAD Interruptions (Counter)",
        "Rate Limit / Quota Errors (Counter)",
        "API Requests (Counter)",
        "WS Errors (Counter)",
    }

    for tile in dashboard["mosaicLayout"]["tiles"]:
        widget = tile["widget"]
        title = widget["title"]
        if title not in counter_titles:
            continue
        scorecard = widget["scorecard"]
        agg = scorecard["timeSeriesQuery"]["timeSeriesFilter"]["aggregation"]
        assert agg["perSeriesAligner"] == "ALIGN_DELTA"
        assert agg["crossSeriesReducer"] == "REDUCE_SUM"
        assert agg.get("groupByFields", []) == []


def test_top_four_scorecards_have_sparklines() -> None:
    dashboard = build_dashboard_spec(project_id="demo-project", region="us-central1")
    sparkline_titles = {
        "Turns Completed (Counter)",
        "Successful Responses (Counter)",
        "API Errors (Counter)",
        "Tool Calls (Counter)",
    }
    non_sparkline_counter_titles = {
        "Total Tokens (Counter)",
        "Prompt Tokens (Counter)",
        "Response Tokens (Counter)",
        "Turn Complete Events (Counter)",
        "Server VAD Events (Counter)",
        "Client Activity Signals (Counter)",
        "VAD Interruptions (Counter)",
        "Rate Limit / Quota Errors (Counter)",
        "API Requests (Counter)",
        "WS Errors (Counter)",
    }

    for tile in dashboard["mosaicLayout"]["tiles"]:
        widget = tile["widget"]
        title = widget["title"]
        if "scorecard" not in widget:
            continue
        scorecard = widget["scorecard"]
        if title in sparkline_titles:
            assert "sparkChartView" in scorecard, f"{title} should have sparkline"
            assert scorecard["sparkChartView"]["sparkChartType"] == "SPARK_LINE"
        elif title in non_sparkline_counter_titles:
            assert "sparkChartView" not in scorecard, f"{title} should not have sparkline"


def test_section_headers_present() -> None:
    dashboard = build_dashboard_spec(project_id="demo-project", region="us-central1")
    section_titles = []
    for tile in dashboard["mosaicLayout"]["tiles"]:
        widget = tile["widget"]
        if "sectionHeader" in widget:
            section_titles.append(widget["title"])
            header = widget["sectionHeader"]
            assert "subtitle" in header
            assert header["dividerBelow"] is True
            assert tile["width"] == 48

    assert "Key Metrics" in section_titles
    assert "Latency" in section_titles
    assert "Tool & Audio" in section_titles
    assert "Traffic & Health" in section_titles
    assert "Counters" in section_titles
    assert "Distribution" in section_titles
    assert len(section_titles) == 6


def test_default_group_by_session_id_is_false() -> None:
    dashboard = build_dashboard_spec(project_id="demo-project", region="us-central1")
    # With default group_by_session_id=False, no xy chart should group by session_id
    for tile in dashboard["mosaicLayout"]["tiles"]:
        widget = tile["widget"]
        if "xyChart" in widget:
            group_fields = widget["xyChart"]["dataSets"][0]["timeSeriesQuery"]["timeSeriesFilter"][
                "aggregation"
            ].get("groupByFields", [])
            assert "metric.label.session_id" not in group_fields


def test_dashboard_contains_ws_connect_latency_widget() -> None:
    dashboard = build_dashboard_spec(project_id="demo-project", region="us-central1")
    titles = [tile["widget"]["title"] for tile in dashboard["mosaicLayout"]["tiles"]]
    assert "WS Connect Latency (p50/p95/p99)" in titles


def test_dashboard_contains_ws_errors_widget() -> None:
    dashboard = build_dashboard_spec(project_id="demo-project", region="us-central1")
    titles = [tile["widget"]["title"] for tile in dashboard["mosaicLayout"]["tiles"]]
    assert "WS Errors (Counter)" in titles


def test_turns_completed_scorecard_uses_turn_complete_total() -> None:
    """L1: The 'Turns Completed' scorecard should query geminilive_turn_complete_total, not geminilive_turns_total."""
    dashboard = build_dashboard_spec(project_id="demo-project", region="us-central1")
    for tile in dashboard["mosaicLayout"]["tiles"]:
        widget = tile["widget"]
        if widget["title"] == "Turns Completed (Counter)":
            ts_filter = widget["scorecard"]["timeSeriesQuery"]["timeSeriesFilter"]["filter"]
            assert "geminilive_turn_complete_total" in ts_filter
            assert "geminilive_turns_total" not in ts_filter
            return
    raise AssertionError("Turns Completed (Counter) widget not found")
