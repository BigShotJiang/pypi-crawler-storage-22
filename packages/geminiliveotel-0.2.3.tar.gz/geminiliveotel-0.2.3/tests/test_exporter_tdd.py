from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from geminiliveotel.exporter import CloudMonitoringMetricExporter
from geminiliveotel.sidecar import LiveTelemetrySidecar


TARGET_MODEL = "gemini-live-2.5-flash-native-audio"
REGION = "us-central1"


@dataclass
class _Response:
    status_code: int
    payload: dict[str, Any]

    @property
    def text(self) -> str:
        return str(self.payload)

    def json(self) -> dict[str, Any]:
        return self.payload


class _FakeSession:
    def __init__(self) -> None:
        self.calls: list[tuple[str, str, dict[str, Any] | None]] = []

    def get(self, url: str, *, params: dict | None = None, timeout: int = 30) -> _Response:
        del timeout
        self.calls.append(("GET", url, params))
        return _Response(200, {})

    def post(self, url: str, *, json: dict | None = None, timeout: int = 30) -> _Response:
        del timeout
        self.calls.append(("POST", url, json))
        return _Response(200, {})


def _sidecar() -> LiveTelemetrySidecar:
    return LiveTelemetrySidecar(
        target_model=TARGET_MODEL,
        region=REGION,
        concurrency_quota=1000,
    )


def test_exporter_creates_descriptors_and_writes_timeseries() -> None:
    sidecar = _sidecar()
    sidecar.on_session_started("s1", TARGET_MODEL, REGION, automatic_vad=True, timestamp_ms=0)
    sidecar.on_client_request(
        "s1",
        "realtime_input",
        timestamp_ms=100,
        audio_chunk_duration_ms=40,
        audio_chunk_bytes=960,
    )
    sidecar.on_server_message(
        "s1",
        {
            "server_content": {
                "model_turn": {
                    "parts": [
                        {
                            "inline_data": {
                                "mime_type": "audio/pcm",
                                "data": b"x",
                            }
                        }
                    ]
                },
                "turn_complete": True,
            },
            "usage_metadata": {
                "total_token_count": 12,
                "prompt_token_count": 5,
                "response_token_count": 7,
                "prompt_tokens_details": [{"modality": "AUDIO", "token_count": 5}],
                "response_tokens_details": [{"modality": "AUDIO", "token_count": 7}],
            },
        },
        timestamp_ms=600,
    )

    fake_session = _FakeSession()
    exporter = CloudMonitoringMetricExporter(
        project_id="demo-project",
        session=fake_session,
        flush_interval_sec=9999,
    )
    exporter.start(sidecar, start_background=False)
    exporter.flush_once()

    descriptor_posts = [call for call in fake_session.calls if "/metricDescriptors" in call[1]]
    timeseries_posts = [call for call in fake_session.calls if "/timeSeries" in call[1]]

    assert descriptor_posts
    assert timeseries_posts

    written_series = timeseries_posts[-1][2]["timeSeries"]
    metric_types = {item["metric"]["type"] for item in written_series}

    assert "custom.googleapis.com/geminilive/geminilive_api_requests_total" in metric_types
    assert "custom.googleapis.com/geminilive/geminilive_ttfab_ms" in metric_types


def test_exporter_distribution_payload_is_used_for_histograms() -> None:
    sidecar = _sidecar()
    sidecar.on_session_started("s1", TARGET_MODEL, REGION, automatic_vad=True, timestamp_ms=0)
    sidecar.on_client_request(
        "s1",
        "realtime_input",
        timestamp_ms=100,
        audio_chunk_duration_ms=45,
    )

    fake_session = _FakeSession()
    exporter = CloudMonitoringMetricExporter(
        project_id="demo-project",
        session=fake_session,
        flush_interval_sec=9999,
    )
    exporter.start(sidecar, start_background=False)
    exporter.flush_once()

    timeseries_posts = [call for call in fake_session.calls if "/timeSeries" in call[1]]
    assert timeseries_posts

    found_distribution = False
    for series in timeseries_posts[-1][2]["timeSeries"]:
        if series["metric"]["type"].endswith("/geminilive_input_audio_chunk_duration_ms"):
            points = series.get("points", [])
            if points and "distributionValue" in points[0]["value"]:
                found_distribution = True
                break
    assert found_distribution


def test_exporter_cumulative_counter_uses_start_time_before_end_time() -> None:
    sidecar = _sidecar()
    sidecar.on_session_started("s1", TARGET_MODEL, REGION, automatic_vad=True, timestamp_ms=0)
    sidecar.on_client_request("s1", "realtime_input", timestamp_ms=100)

    fake_session = _FakeSession()
    exporter = CloudMonitoringMetricExporter(
        project_id="demo-project",
        session=fake_session,
        flush_interval_sec=9999,
    )
    exporter.start(sidecar, start_background=False)
    exporter.flush_once()

    timeseries_posts = [call for call in fake_session.calls if "/timeSeries" in call[1]]
    assert timeseries_posts

    found_counter = False
    for series in timeseries_posts[-1][2]["timeSeries"]:
        if series["metric"]["type"].endswith("/geminilive_api_requests_total"):
            point = series["points"][0]
            interval = point["interval"]
            assert interval["startTime"] < interval["endTime"]
            found_counter = True
            break
    assert found_counter


def test_exporter_throttles_gauge_writes_within_flush_interval() -> None:
    sidecar = _sidecar()
    sidecar.on_session_started("s1", TARGET_MODEL, REGION, automatic_vad=True, timestamp_ms=0)

    fake_session = _FakeSession()
    exporter = CloudMonitoringMetricExporter(
        project_id="demo-project",
        session=fake_session,
        flush_interval_sec=5,
    )
    exporter.start(sidecar, start_background=False)
    exporter.flush_once()
    exporter.flush_once()

    timeseries_posts = [call for call in fake_session.calls if "/timeSeries" in call[1]]
    assert len(timeseries_posts) == 1

    concurrency_points = 0
    for series in timeseries_posts[0][2]["timeSeries"]:
        if series["metric"]["type"].endswith("/geminilive_concurrent_sessions"):
            concurrency_points += 1
    assert concurrency_points == 1


def test_exporter_creates_descriptor_for_ws_metrics() -> None:
    sidecar = _sidecar()
    fake_session = _FakeSession()
    exporter = CloudMonitoringMetricExporter(
        project_id="demo-project",
        session=fake_session,
        flush_interval_sec=9999,
    )
    exporter.start(sidecar, start_background=False)

    descriptor_posts = [call for call in fake_session.calls if "/metricDescriptors" in call[1]]
    descriptor_types = {call[2]["type"] for call in descriptor_posts}

    assert "custom.googleapis.com/geminilive/geminilive_ws_connect_latency_ms" in descriptor_types
    assert "custom.googleapis.com/geminilive/geminilive_ws_errors_total" in descriptor_types


def test_exporter_stop_does_final_flush() -> None:
    """L14: stop() should perform a final flush before returning."""
    sidecar = _sidecar()
    sidecar.on_session_started("s1", TARGET_MODEL, REGION, automatic_vad=True, timestamp_ms=0)
    sidecar.on_client_request("s1", "realtime_input", timestamp_ms=100)

    fake_session = _FakeSession()
    exporter = CloudMonitoringMetricExporter(
        project_id="demo-project",
        session=fake_session,
        flush_interval_sec=9999,
    )
    exporter.start(sidecar, start_background=False)

    # No flush_once called yet — only descriptors should be posted
    timeseries_posts_before = [call for call in fake_session.calls if "/timeSeries" in call[1]]
    assert len(timeseries_posts_before) == 0

    # stop() should do a final flush
    exporter.stop()

    timeseries_posts_after = [call for call in fake_session.calls if "/timeSeries" in call[1]]
    assert len(timeseries_posts_after) >= 1
