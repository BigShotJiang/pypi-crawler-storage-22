from __future__ import annotations

import asyncio
import time

from google.genai.types import Blob, Content, LiveServerContent, LiveServerMessage, Part

from geminiliveotel.integration import _default_now_ms, instrument_live_session
from geminiliveotel.sidecar import LiveTelemetrySidecar


TARGET_MODEL = "gemini-live-2.5-flash-native-audio"
REGION = "us-central1"


class _FakeLiveSession:
    def __init__(self) -> None:
        self.session_id = "s_wrap"
        self.sent_realtime_inputs: list[dict] = []
        self.sent_tool_responses: list[dict] = []
        self.sent_client_contents: list[dict] = []
        self.closed = False

    async def send_realtime_input(self, **kwargs) -> None:
        self.sent_realtime_inputs.append(kwargs)

    async def send_tool_response(self, **kwargs) -> None:
        self.sent_tool_responses.append(kwargs)

    async def send_client_content(self, **kwargs) -> None:
        self.sent_client_contents.append(kwargs)

    async def close(self) -> None:
        self.closed = True

    async def receive(self):
        yield LiveServerMessage(
            server_content=LiveServerContent(
                model_turn=Content(
                    parts=[Part(inline_data=Blob(mime_type="audio/pcm", data=b"x"))],
                ),
            ),
        )
        yield LiveServerMessage(
            server_content=LiveServerContent(turn_complete=True),
        )


class _FailingLiveSession(_FakeLiveSession):
    async def send_realtime_input(self, **kwargs) -> None:
        del kwargs
        raise RuntimeError("RESOURCE_EXHAUSTED: quota exceeded")


class _FailingToolResponseSession(_FakeLiveSession):
    async def send_tool_response(self, **kwargs) -> None:
        del kwargs
        raise RuntimeError("DEADLINE_EXCEEDED: timeout")


class _WsErrorSession(_FakeLiveSession):
    async def send_realtime_input(self, **kwargs) -> None:
        del kwargs
        raise RuntimeError("websocket connection closed abnormally")


def test_instrumented_wrapper_tracks_session_and_metrics() -> None:
    sidecar = LiveTelemetrySidecar(
        target_model=TARGET_MODEL,
        region=REGION,
        concurrency_quota=1000,
    )

    fake = _FakeLiveSession()
    wrapper = instrument_live_session(
        session=fake,
        sidecar=sidecar,
        model_id=TARGET_MODEL,
        region=REGION,
        automatic_vad=True,
        now_ms=lambda: 100,
    )

    snapshot = sidecar.snapshot()
    assert snapshot.gauge("geminilive_concurrent_sessions", model_id=TARGET_MODEL, region=REGION) == 1

    async def _exercise() -> None:
        await wrapper.send_realtime_input(
            audio={"data": b"123", "mime_type": "audio/pcm"},
            audio_chunk_duration_ms=40,
            audio_chunk_bytes=960,
        )
        async for _ in wrapper.receive():
            pass
        await wrapper.close()

    asyncio.run(_exercise())

    snapshot = sidecar.snapshot()
    labels = {"session_id": "s_wrap", "model_id": TARGET_MODEL, "region": REGION}
    assert snapshot.counter("geminilive_api_requests_total", **labels) == 1
    assert snapshot.counter("geminilive_turn_complete_total", **labels) == 1
    assert snapshot.counter("geminilive_successful_model_responses_total", **labels) == 1
    assert snapshot.histogram_samples("geminilive_input_audio_chunk_duration_ms", **labels) == [40]
    assert snapshot.gauge("geminilive_concurrent_sessions", model_id=TARGET_MODEL, region=REGION) == 0
    assert fake.closed is True


def test_instrumented_wrapper_forwards_tool_response_and_records_timing() -> None:
    sidecar = LiveTelemetrySidecar(
        target_model=TARGET_MODEL,
        region=REGION,
        concurrency_quota=1000,
    )
    fake = _FakeLiveSession()

    tick = {"value": 0}

    def _now() -> int:
        tick["value"] += 100
        return tick["value"]

    wrapper = instrument_live_session(
        session=fake,
        sidecar=sidecar,
        model_id=TARGET_MODEL,
        region=REGION,
        automatic_vad=True,
        now_ms=_now,
    )

    async def _exercise() -> None:
        sidecar.on_server_message(
            "s_wrap",
            {"tool_call": {"function_calls": [{"id": "c1", "name": "lookup"}]}},
            timestamp_ms=_now(),
        )
        await wrapper.send_tool_response(function_responses=[{"id": "c1", "name": "lookup", "response": {}}])

    asyncio.run(_exercise())

    labels = {
        "session_id": "s_wrap",
        "model_id": TARGET_MODEL,
        "region": REGION,
        "function_name": "lookup",
    }
    snapshot = sidecar.snapshot()
    assert snapshot.histogram_samples("geminilive_tool_call_roundtrip_ms", **labels) == [100]


def test_instrumented_wrapper_records_api_errors_from_send_failures() -> None:
    sidecar = LiveTelemetrySidecar(
        target_model=TARGET_MODEL,
        region=REGION,
        concurrency_quota=1000,
    )
    failing = _FailingLiveSession()
    wrapper = instrument_live_session(
        session=failing,
        sidecar=sidecar,
        model_id=TARGET_MODEL,
        region=REGION,
        automatic_vad=True,
        now_ms=lambda: 100,
    )

    async def _exercise() -> None:
        try:
            await wrapper.send_realtime_input(audio={"data": b"123", "mime_type": "audio/pcm"})
        except RuntimeError:
            pass

    asyncio.run(_exercise())

    labels = {
        "session_id": "s_wrap",
        "model_id": TARGET_MODEL,
        "region": REGION,
        "error_code": "RESOURCE_EXHAUSTED",
    }
    snapshot = sidecar.snapshot()
    assert snapshot.counter("geminilive_api_errors_total", **labels) == 1


def test_instrumented_wrapper_records_tool_roundtrip_when_client_content_carries_tool_ids() -> None:
    sidecar = LiveTelemetrySidecar(
        target_model=TARGET_MODEL,
        region=REGION,
        concurrency_quota=1000,
    )
    fake = _FakeLiveSession()
    ticks = {"value": 0}

    def _now() -> int:
        ticks["value"] += 100
        return ticks["value"]

    wrapper = instrument_live_session(
        session=fake,
        sidecar=sidecar,
        model_id=TARGET_MODEL,
        region=REGION,
        automatic_vad=True,
        now_ms=_now,
    )

    async def _exercise() -> None:
        sidecar.on_server_message(
            "s_wrap",
            {"tool_call": {"function_calls": [{"id": "c1", "name": "lookup"}]}},
            timestamp_ms=_now(),
        )
        await wrapper.send_client_content(
            turns={"parts": [{"text": "done"}], "role": "user"},
            turn_complete=True,
            __otel_tool_call_ids=["c1"],
        )

    asyncio.run(_exercise())

    labels = {
        "session_id": "s_wrap",
        "model_id": TARGET_MODEL,
        "region": REGION,
        "function_name": "lookup",
    }
    snapshot = sidecar.snapshot()
    assert snapshot.counter("geminilive_tool_calls_total", **labels) == 1
    assert snapshot.histogram_samples("geminilive_tool_call_roundtrip_ms", **labels) == [200]


def test_instrumented_wrapper_passes_connect_duration_to_sidecar() -> None:
    sidecar = LiveTelemetrySidecar(
        target_model=TARGET_MODEL,
        region=REGION,
        concurrency_quota=1000,
    )
    fake = _FakeLiveSession()
    instrument_live_session(
        session=fake,
        sidecar=sidecar,
        model_id=TARGET_MODEL,
        region=REGION,
        automatic_vad=True,
        now_ms=lambda: 100,
        connect_duration_ms=250.0,
    )

    snapshot = sidecar.snapshot()
    labels = {"session_id": "s_wrap", "model_id": TARGET_MODEL, "region": REGION}
    assert snapshot.histogram_samples("geminilive_ws_connect_latency_ms", **labels) == [250.0]


def test_default_now_ms_uses_monotonic_clock() -> None:
    """_default_now_ms() returns values consistent with time.monotonic(), not time.time()."""
    mono_before = int(time.monotonic() * 1000)
    result = _default_now_ms()
    mono_after = int(time.monotonic() * 1000)

    assert mono_before <= result <= mono_after


def test_tool_response_not_recorded_on_send_failure() -> None:
    sidecar = LiveTelemetrySidecar(
        target_model=TARGET_MODEL,
        region=REGION,
        concurrency_quota=1000,
    )
    failing = _FailingToolResponseSession()

    tick = {"value": 0}

    def _now() -> int:
        tick["value"] += 100
        return tick["value"]

    wrapper = instrument_live_session(
        session=failing,
        sidecar=sidecar,
        model_id=TARGET_MODEL,
        region=REGION,
        automatic_vad=True,
        now_ms=_now,
    )

    async def _exercise() -> None:
        sidecar.on_server_message(
            "s_wrap",
            {"tool_call": {"function_calls": [{"id": "c1", "name": "lookup"}]}},
            timestamp_ms=_now(),
        )
        try:
            await wrapper.send_tool_response(function_responses=[{"id": "c1", "name": "lookup", "response": {}}])
        except RuntimeError:
            pass

    asyncio.run(_exercise())

    labels = {
        "session_id": "s_wrap",
        "model_id": TARGET_MODEL,
        "region": REGION,
        "function_name": "lookup",
    }
    snapshot = sidecar.snapshot()
    assert snapshot.counter("geminilive_tool_calls_total", **labels) == 0


def test_send_realtime_input_forwards_media_parameter() -> None:
    from google.genai.types import Blob

    sidecar = LiveTelemetrySidecar(
        target_model=TARGET_MODEL,
        region=REGION,
        concurrency_quota=1000,
    )
    fake = _FakeLiveSession()
    wrapper = instrument_live_session(
        session=fake,
        sidecar=sidecar,
        model_id=TARGET_MODEL,
        region=REGION,
        automatic_vad=True,
        now_ms=lambda: 100,
    )

    media_blob = Blob(data=b"img", mime_type="image/jpeg")

    async def _exercise() -> None:
        await wrapper.send_realtime_input(media=media_blob)

    asyncio.run(_exercise())

    assert len(fake.sent_realtime_inputs) == 1
    assert fake.sent_realtime_inputs[0]["media"] is media_blob


def test_close_delegates_to_underlying_session() -> None:
    """close() must call self._session.close() to release the WebSocket."""
    sidecar = LiveTelemetrySidecar(
        target_model=TARGET_MODEL,
        region=REGION,
        concurrency_quota=1000,
    )
    fake = _FakeLiveSession()
    wrapper = instrument_live_session(
        session=fake,
        sidecar=sidecar,
        model_id=TARGET_MODEL,
        region=REGION,
        automatic_vad=True,
        now_ms=lambda: 100,
    )

    async def _exercise() -> None:
        await wrapper.close()

    asyncio.run(_exercise())

    assert fake.closed is True


def test_ws_error_detected_and_recorded() -> None:
    sidecar = LiveTelemetrySidecar(
        target_model=TARGET_MODEL,
        region=REGION,
        concurrency_quota=1000,
    )
    failing = _WsErrorSession()
    wrapper = instrument_live_session(
        session=failing,
        sidecar=sidecar,
        model_id=TARGET_MODEL,
        region=REGION,
        automatic_vad=True,
        now_ms=lambda: 100,
    )

    async def _exercise() -> None:
        try:
            await wrapper.send_realtime_input(audio={"data": b"123", "mime_type": "audio/pcm"})
        except RuntimeError:
            pass

    asyncio.run(_exercise())

    base_labels = {
        "session_id": "s_wrap",
        "model_id": TARGET_MODEL,
        "region": REGION,
    }
    snapshot = sidecar.snapshot()
    # API error should be recorded
    assert snapshot.counter(
        "geminilive_api_errors_total",
        **{**base_labels, "error_code": "RUNTIMEERROR"},
    ) == 1
    # WS error should also be recorded
    assert snapshot.counter(
        "geminilive_ws_errors_total",
        **{**base_labels, "error_type": "WS_ERROR"},
    ) == 1


def test_session_id_none_generates_fallback() -> None:
    """L5: If session.session_id is None, a fallback ID should be generated instead of literal 'None'."""
    sidecar = LiveTelemetrySidecar(
        target_model=TARGET_MODEL,
        region=REGION,
        concurrency_quota=1000,
    )
    fake = _FakeLiveSession()
    fake.session_id = None

    wrapper = instrument_live_session(
        session=fake,
        sidecar=sidecar,
        model_id=TARGET_MODEL,
        region=REGION,
        automatic_vad=True,
        now_ms=lambda: 100,
    )

    assert wrapper.session_id != "None"
    assert wrapper.session_id.startswith("session-")
