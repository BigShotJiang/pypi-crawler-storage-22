from __future__ import annotations

import math

from google.genai.types import (
    Content,
    LiveServerContent,
    LiveServerMessage,
    MediaModality,
    ModalityTokenCount,
    Part,
    UsageMetadata,
)

from geminiliveotel.sidecar import LiveTelemetrySidecar
from geminiliveotel.tool_ids import stable_tool_call_id


def _to_payload(message: LiveServerMessage) -> dict:
    """Convert real SDK object to dict, same as auto.py does in production."""
    return message.model_dump(exclude_none=True, mode="json")


TARGET_MODEL = "gemini-live-2.5-flash-native-audio"
REGION = "us-central1"


def _labels(session_id: str = "s1") -> dict[str, str]:
    return {
        "session_id": session_id,
        "model_id": TARGET_MODEL,
        "region": REGION,
    }


def _sidecar(quota: int = 1000) -> LiveTelemetrySidecar:
    return LiveTelemetrySidecar(
        target_model=TARGET_MODEL,
        region=REGION,
        concurrency_quota=quota,
    )


def test_metric_registry_covers_agreed_metrics() -> None:
    sidecar = _sidecar()
    assert sidecar.metric_names() == {
        "geminilive_ttfab_ms",
        "geminilive_turn_e2e_latency_ms",
        "geminilive_tool_call_roundtrip_ms",
        "geminilive_model_wait_after_tool_ms",
        "geminilive_tool_calls_total",
        "geminilive_input_audio_chunk_duration_ms",
        "geminilive_input_audio_chunk_bytes",
        "geminilive_input_audio_chunk_noncompliant_total",
        "geminilive_total_tokens_total",
        "geminilive_prompt_tokens_total",
        "geminilive_response_tokens_total",
        "geminilive_modality_tokens_total",
        "geminilive_turn_complete_total",
        "geminilive_server_vad_events_total",
        "geminilive_client_activity_signals_total",
        "geminilive_vad_interruptions_total",
        "geminilive_turns_total",
        "geminilive_api_requests_total",
        "geminilive_request_qps",
        "geminilive_concurrent_sessions",
        "geminilive_token_throughput_tps",
        "geminilive_api_errors_total",
        "geminilive_rate_limit_quota_errors_total",
        "geminilive_concurrency_quota_utilization_pct",
        "geminilive_successful_model_responses_total",
        "geminilive_model_success_rate",
        "geminilive_ws_connect_latency_ms",
        "geminilive_ws_errors_total",
    }


def test_metric_definitions_have_expected_units_and_instruments() -> None:
    sidecar = _sidecar()
    defs = sidecar.metric_definitions()

    assert defs["geminilive_ttfab_ms"].unit == "ms"
    assert defs["geminilive_ttfab_ms"].kind == "histogram"
    assert defs["geminilive_turn_e2e_latency_ms"].unit == "ms"
    assert defs["geminilive_input_audio_chunk_bytes"].unit == "bytes"
    assert defs["geminilive_total_tokens_total"].unit == "tokens"
    assert defs["geminilive_token_throughput_tps"].unit == "tokens/s"
    assert defs["geminilive_request_qps"].unit == "req/s"
    assert defs["geminilive_concurrency_quota_utilization_pct"].unit == "%"

    for metric_name, definition in defs.items():
        if metric_name in {"geminilive_concurrent_sessions", "geminilive_concurrency_quota_utilization_pct"}:
            assert definition.session_groupable is False
        else:
            assert definition.session_groupable is True


def test_only_target_model_is_instrumented() -> None:
    sidecar = _sidecar()

    accepted = sidecar.on_session_started(
        session_id="other",
        model="gemini-live-2.5-flash",
        region=REGION,
        automatic_vad=True,
        timestamp_ms=0,
    )
    assert accepted is False

    accepted = sidecar.on_session_started(
        session_id="s1",
        model=TARGET_MODEL,
        region=REGION,
        automatic_vad=True,
        timestamp_ms=10,
    )
    assert accepted is True

    snapshot = sidecar.snapshot()
    assert snapshot.gauge("geminilive_concurrent_sessions", model_id=TARGET_MODEL, region=REGION) == 1


def test_ttfab_and_turn_latency_and_success() -> None:
    sidecar = _sidecar()
    sidecar.on_session_started("s1", TARGET_MODEL, REGION, automatic_vad=True, timestamp_ms=0)

    sidecar.on_client_request(
        session_id="s1",
        request_type="realtime_input",
        timestamp_ms=0,
    )
    sidecar.on_server_message(
        session_id="s1",
        message={
            "server_content": {
                "model_turn": {
                    "parts": [
                        {
                            "inline_data": {
                                "mime_type": "audio/pcm",
                                "data": b"abc",
                            }
                        }
                    ]
                }
            }
        },
        timestamp_ms=120,
    )
    sidecar.on_server_message(
        session_id="s1",
        message={"server_content": {"turn_complete": True}},
        timestamp_ms=450,
    )

    snapshot = sidecar.snapshot()

    assert snapshot.histogram_samples("geminilive_ttfab_ms", **_labels("s1")) == [120]
    assert snapshot.histogram_samples("geminilive_turn_e2e_latency_ms", **_labels("s1")) == [450]
    assert snapshot.counter("geminilive_turn_complete_total", **_labels("s1")) == 1
    assert snapshot.counter("geminilive_turns_total", **_labels("s1")) == 0
    assert snapshot.counter("geminilive_successful_model_responses_total", **_labels("s1")) == 1
    assert snapshot.gauge("geminilive_model_success_rate", **_labels("s1")) == 1.0


def test_turn_latency_percentiles_from_histogram() -> None:
    sidecar = _sidecar()
    sidecar.on_session_started("s1", TARGET_MODEL, REGION, automatic_vad=True, timestamp_ms=0)

    for index, latency in enumerate([100, 200, 300], start=1):
        t0 = index * 1000
        sidecar.on_client_request("s1", "realtime_input", timestamp_ms=t0)
        sidecar.on_server_message("s1", {"server_content": {"turn_complete": True}}, timestamp_ms=t0 + latency)

    snapshot = sidecar.snapshot()
    assert snapshot.percentile("geminilive_turn_e2e_latency_ms", 0.50, **_labels("s1")) == 200
    assert snapshot.percentile("geminilive_turn_e2e_latency_ms", 0.95, **_labels("s1")) == 300
    assert snapshot.percentile("geminilive_turn_e2e_latency_ms", 0.99, **_labels("s1")) == 300


def test_tool_roundtrip_and_model_wait_after_tool() -> None:
    sidecar = _sidecar()
    sidecar.on_session_started("s1", TARGET_MODEL, REGION, automatic_vad=True, timestamp_ms=0)

    sidecar.on_server_message(
        "s1",
        {"tool_call": {"function_calls": [{"id": "c1", "name": "get_weather"}]}},
        timestamp_ms=100,
    )
    sidecar.on_tool_response("s1", call_ids=["c1"], timestamp_ms=260)
    sidecar.on_server_message(
        "s1",
        {
            "server_content": {
                "model_turn": {
                    "parts": [
                        {
                            "inline_data": {
                                "mime_type": "audio/pcm",
                                "data": b"x",
                            }
                        }
                    ]
                }
            }
        },
        timestamp_ms=310,
    )

    snapshot = sidecar.snapshot()
    labels = {**_labels("s1"), "function_name": "get_weather"}
    assert snapshot.histogram_samples("geminilive_tool_call_roundtrip_ms", **labels) == [160]
    assert snapshot.histogram_samples("geminilive_model_wait_after_tool_ms", **_labels("s1")) == [50]
    assert snapshot.counter("geminilive_tool_calls_total", **labels) == 1


def test_audio_chunk_duration_and_compliance_metrics() -> None:
    sidecar = _sidecar()
    sidecar.on_session_started("s1", TARGET_MODEL, REGION, automatic_vad=True, timestamp_ms=0)

    sidecar.on_client_request(
        "s1",
        "realtime_input",
        timestamp_ms=10,
        audio_chunk_duration_ms=10,
        audio_chunk_bytes=320,
    )
    sidecar.on_client_request(
        "s1",
        "realtime_input",
        timestamp_ms=20,
        audio_chunk_duration_ms=40,
        audio_chunk_bytes=640,
    )
    sidecar.on_client_request(
        "s1",
        "realtime_input",
        timestamp_ms=30,
        audio_chunk_duration_ms=120,
        audio_chunk_bytes=1920,
    )

    snapshot = sidecar.snapshot()
    assert snapshot.histogram_samples("geminilive_input_audio_chunk_duration_ms", **_labels("s1")) == [10, 40, 120]
    assert snapshot.histogram_samples("geminilive_input_audio_chunk_bytes", **_labels("s1")) == [320, 640, 1920]
    assert snapshot.counter("geminilive_input_audio_chunk_noncompliant_total", **_labels("s1")) == 2


def test_usage_tokens_modality_distribution_and_throughput() -> None:
    """Uses real SDK LiveServerMessage, UsageMetadata, and ModalityTokenCount types."""
    sidecar = _sidecar()
    sidecar.on_session_started("s1", TARGET_MODEL, REGION, automatic_vad=True, timestamp_ms=0)

    msg = LiveServerMessage(
        usage_metadata=UsageMetadata(
            total_token_count=300,
            prompt_token_count=120,
            response_token_count=180,
            prompt_tokens_details=[
                ModalityTokenCount(modality=MediaModality.AUDIO, token_count=40),
                ModalityTokenCount(modality=MediaModality.IMAGE, token_count=80),
            ],
            response_tokens_details=[
                ModalityTokenCount(modality=MediaModality.AUDIO, token_count=120),
                ModalityTokenCount(modality=MediaModality.VIDEO, token_count=60),
                ModalityTokenCount(modality=MediaModality.TEXT, token_count=10),
            ],
        ),
    )
    sidecar.on_server_message("s1", _to_payload(msg), timestamp_ms=5000)

    snapshot = sidecar.snapshot()
    assert snapshot.counter("geminilive_total_tokens_total", **_labels("s1")) == 300
    assert snapshot.counter("geminilive_prompt_tokens_total", **_labels("s1")) == 120
    assert snapshot.counter("geminilive_response_tokens_total", **_labels("s1")) == 180

    assert snapshot.counter("geminilive_modality_tokens_total", **{**_labels("s1"), "modality": "audio"}) == 160
    assert snapshot.counter("geminilive_modality_tokens_total", **{**_labels("s1"), "modality": "video"}) == 60
    assert snapshot.counter("geminilive_modality_tokens_total", **{**_labels("s1"), "modality": "image"}) == 80
    assert snapshot.counter("geminilive_modality_tokens_total", **{**_labels("s1"), "modality": "text"}) == 0

    assert math.isclose(
        snapshot.gauge("geminilive_token_throughput_tps", **_labels("s1")),
        60.0,
    )


def test_vad_metrics_for_builtin_automatic_vad_mode() -> None:
    sidecar = _sidecar()
    sidecar.on_session_started("s1", TARGET_MODEL, REGION, automatic_vad=True, timestamp_ms=0)

    sidecar.on_server_message(
        "s1",
        {"voice_activity": {"voice_activity_type": "ACTIVITY_START"}},
        timestamp_ms=100,
    )
    sidecar.on_server_message(
        "s1",
        {"voice_activity": {"voice_activity_type": "ACTIVITY_END"}},
        timestamp_ms=200,
    )
    sidecar.on_client_request(
        "s1",
        "realtime_input",
        timestamp_ms=250,
        activity_start=True,
        activity_end=True,
    )

    snapshot = sidecar.snapshot()
    assert snapshot.counter("geminilive_server_vad_events_total", **_labels("s1")) == 2
    assert snapshot.counter("geminilive_client_activity_signals_total", **_labels("s1")) == 0


def test_vad_metrics_for_custom_vad_mode() -> None:
    sidecar = _sidecar()
    sidecar.on_session_started("s1", TARGET_MODEL, REGION, automatic_vad=False, timestamp_ms=0)

    sidecar.on_client_request(
        "s1",
        "realtime_input",
        timestamp_ms=100,
        activity_start=True,
    )
    sidecar.on_client_request(
        "s1",
        "realtime_input",
        timestamp_ms=200,
        activity_end=True,
    )
    sidecar.on_server_message(
        "s1",
        {"voice_activity": {"voice_activity_type": "ACTIVITY_START"}},
        timestamp_ms=250,
    )

    snapshot = sidecar.snapshot()
    assert snapshot.counter("geminilive_client_activity_signals_total", **_labels("s1")) == 2
    assert snapshot.counter("geminilive_server_vad_events_total", **_labels("s1")) == 0


def test_vad_interruptions_are_counted() -> None:
    sidecar = _sidecar()
    sidecar.on_session_started("s1", TARGET_MODEL, REGION, automatic_vad=True, timestamp_ms=0)

    sidecar.on_server_message("s1", {"server_content": {"interrupted": True}}, timestamp_ms=100)

    snapshot = sidecar.snapshot()
    assert snapshot.counter("geminilive_vad_interruptions_total", **_labels("s1")) == 1


def test_request_qps_and_request_counter() -> None:
    sidecar = _sidecar()
    sidecar.on_session_started("s1", TARGET_MODEL, REGION, automatic_vad=True, timestamp_ms=0)

    sidecar.on_client_request("s1", "realtime_input", timestamp_ms=0)
    sidecar.on_client_request("s1", "realtime_input", timestamp_ms=500)
    sidecar.on_client_request("s1", "realtime_input", timestamp_ms=1000)
    sidecar.on_server_message("s1", {"server_content": {"turn_complete": True}}, timestamp_ms=1200)
    sidecar.on_client_request("s1", "realtime_input", timestamp_ms=2000)

    snapshot = sidecar.snapshot()
    assert snapshot.counter("geminilive_api_requests_total", **_labels("s1")) == 2
    assert math.isclose(snapshot.gauge("geminilive_request_qps", **_labels("s1")), 1.0)


def test_concurrency_and_quota_utilization_without_session_label() -> None:
    sidecar = _sidecar(quota=1000)
    sidecar.on_session_started("s1", TARGET_MODEL, REGION, automatic_vad=True, timestamp_ms=0)
    sidecar.on_session_started("s2", TARGET_MODEL, REGION, automatic_vad=True, timestamp_ms=10)

    snapshot = sidecar.snapshot()
    assert snapshot.gauge("geminilive_concurrent_sessions", model_id=TARGET_MODEL, region=REGION) == 2
    assert math.isclose(
        snapshot.gauge("geminilive_concurrency_quota_utilization_pct", model_id=TARGET_MODEL, region=REGION),
        0.2,
    )

    sidecar.on_session_closed("s1", timestamp_ms=20)
    snapshot = sidecar.snapshot()
    assert snapshot.gauge("geminilive_concurrent_sessions", model_id=TARGET_MODEL, region=REGION) == 1


def test_errors_rate_limit_and_success_rate() -> None:
    sidecar = _sidecar()
    sidecar.on_session_started("s1", TARGET_MODEL, REGION, automatic_vad=True, timestamp_ms=0)
    sidecar.on_client_request("s1", "realtime_input", timestamp_ms=0)

    sidecar.on_api_error("s1", code="RESOURCE_EXHAUSTED", message="quota exceeded", timestamp_ms=100)
    sidecar.on_server_message("s1", {"server_content": {"turn_complete": True}}, timestamp_ms=200)

    snapshot = sidecar.snapshot()
    assert snapshot.counter("geminilive_api_errors_total", **{**_labels("s1"), "error_code": "RESOURCE_EXHAUSTED"}) == 1
    assert snapshot.counter("geminilive_rate_limit_quota_errors_total", **{**_labels("s1"), "error_code": "RESOURCE_EXHAUSTED"}) == 1
    assert snapshot.counter("geminilive_turns_total", **_labels("s1")) == 0
    assert snapshot.counter("geminilive_successful_model_responses_total", **_labels("s1")) == 0
    assert snapshot.gauge("geminilive_model_success_rate", **_labels("s1")) == 0.0


def test_session_id_grouping_policy() -> None:
    sidecar = _sidecar()
    sidecar.on_session_started("s1", TARGET_MODEL, REGION, automatic_vad=True, timestamp_ms=0)
    sidecar.on_client_request("s1", "realtime_input", timestamp_ms=0)

    snapshot = sidecar.snapshot()

    assert snapshot.has_labels("geminilive_api_requests_total", session_id="s1", model_id=TARGET_MODEL, region=REGION)
    assert not snapshot.has_labels("geminilive_concurrent_sessions", session_id="s1", model_id=TARGET_MODEL, region=REGION)
    assert snapshot.has_labels("geminilive_concurrent_sessions", model_id=TARGET_MODEL, region=REGION)


def test_tool_call_counter_and_roundtrip_require_matching_response_ids() -> None:
    sidecar = _sidecar()
    sidecar.on_session_started("s1", TARGET_MODEL, REGION, automatic_vad=True, timestamp_ms=0)

    tool_args = {"contact_name": "John"}
    sidecar.on_server_message(
        "s1",
        {"tool_call": {"function_calls": [{"name": "call_someone", "args": tool_args}]}},
        timestamp_ms=100,
    )

    labels = {**_labels("s1"), "function_name": "call_someone"}
    snapshot = sidecar.snapshot()
    assert snapshot.counter("geminilive_tool_calls_total", **labels) == 0

    fallback_id = stable_tool_call_id(function_name="call_someone", function_args=tool_args, seq=1)
    sidecar.on_tool_response("s1", [fallback_id], timestamp_ms=220)
    sidecar.on_tool_response("s1", [fallback_id], timestamp_ms=300)

    snapshot = sidecar.snapshot()
    assert snapshot.counter("geminilive_tool_calls_total", **labels) == 1
    assert snapshot.histogram_samples("geminilive_tool_call_roundtrip_ms", **labels) == [120]


def test_completed_tool_call_not_double_counted_on_server_resend() -> None:
    """If the server re-sends a tool_call with the same ID after it was already
    responded to, the sidecar must NOT re-add it to pending_tool_calls and must
    NOT count it again when a second tool_response arrives."""
    sidecar = _sidecar()
    sidecar.on_session_started("s1", TARGET_MODEL, REGION, automatic_vad=True, timestamp_ms=0)

    # Server sends a tool call
    sidecar.on_server_message(
        "s1",
        {"tool_call": {"function_calls": [{"name": "lookup", "args": {"q": "x"}, "id": "tc1"}]}},
        timestamp_ms=100,
    )

    # Client responds
    sidecar.on_tool_response("s1", ["tc1"], timestamp_ms=200)

    labels = {**_labels("s1"), "function_name": "lookup"}
    snapshot = sidecar.snapshot()
    assert snapshot.counter("geminilive_tool_calls_total", **labels) == 1
    assert snapshot.histogram_samples("geminilive_tool_call_roundtrip_ms", **labels) == [100]

    # Server re-sends the same tool call (duplicate / retry)
    sidecar.on_server_message(
        "s1",
        {"tool_call": {"function_calls": [{"name": "lookup", "args": {"q": "x"}, "id": "tc1"}]}},
        timestamp_ms=300,
    )

    # Client sends another tool_response for the same ID
    sidecar.on_tool_response("s1", ["tc1"], timestamp_ms=400)

    # Counts must NOT have increased
    snapshot = sidecar.snapshot()
    assert snapshot.counter("geminilive_tool_calls_total", **labels) == 1
    assert snapshot.histogram_samples("geminilive_tool_call_roundtrip_ms", **labels) == [100]


def test_tool_response_turn_does_not_inflate_turn_counters() -> None:
    """When the app sends a tool result via client_content (which triggers
    on_client_request + on_tool_response), the subsequent turn_complete from
    Gemini must NOT increment turns_total, turn_complete_total, or
    successful_model_responses_total."""
    sidecar = _sidecar()
    sidecar.on_session_started("s1", TARGET_MODEL, REGION, automatic_vad=True, timestamp_ms=0)

    # Normal user turn: user speaks, model responds with turn_complete
    sidecar.on_client_request("s1", "realtime_input", timestamp_ms=100)
    sidecar.on_server_message(
        "s1",
        {"server_content": {"turn_complete": True}},
        timestamp_ms=200,
    )

    snapshot = sidecar.snapshot()
    assert snapshot.counter("geminilive_turns_total", **_labels("s1")) == 0
    assert snapshot.counter("geminilive_turn_complete_total", **_labels("s1")) == 1
    assert snapshot.counter("geminilive_successful_model_responses_total", **_labels("s1")) == 1

    # Model requests a tool call
    sidecar.on_server_message(
        "s1",
        {"tool_call": {"function_calls": [{"name": "get_weather", "args": {"city": "NYC"}, "id": "tc1"}]}},
        timestamp_ms=300,
    )

    # App sends tool result via client_content (triggers on_client_request then on_tool_response)
    sidecar.on_client_request("s1", "client_content", timestamp_ms=400)
    sidecar.on_tool_response("s1", ["tc1"], timestamp_ms=400)

    # Gemini processes tool result and sends turn_complete -- this is a phantom turn
    sidecar.on_server_message(
        "s1",
        {"server_content": {"turn_complete": True}},
        timestamp_ms=500,
    )

    # Turn counters must NOT have increased
    snapshot = sidecar.snapshot()
    assert snapshot.counter("geminilive_turns_total", **_labels("s1")) == 0
    assert snapshot.counter("geminilive_turn_complete_total", **_labels("s1")) == 1
    assert snapshot.counter("geminilive_successful_model_responses_total", **_labels("s1")) == 1

    # A real user turn after the tool-response turn should still be counted
    sidecar.on_client_request("s1", "realtime_input", timestamp_ms=600)
    sidecar.on_server_message(
        "s1",
        {"server_content": {"turn_complete": True}},
        timestamp_ms=700,
    )

    snapshot = sidecar.snapshot()
    assert snapshot.counter("geminilive_turns_total", **_labels("s1")) == 0
    assert snapshot.counter("geminilive_turn_complete_total", **_labels("s1")) == 2
    assert snapshot.counter("geminilive_successful_model_responses_total", **_labels("s1")) == 2


def test_tool_response_turn_does_not_record_phantom_latency() -> None:
    """TTFAB and E2E latency histograms must NOT get samples from
    tool-result turns, only from real user-speech turns."""
    sidecar = _sidecar()
    sidecar.on_session_started("s1", TARGET_MODEL, REGION, automatic_vad=True, timestamp_ms=0)

    # Real user turn with audio output
    sidecar.on_client_request("s1", "realtime_input", timestamp_ms=100)
    sidecar.on_server_message(
        "s1",
        {"server_content": {"model_turn": {"parts": [{"inline_data": {"mime_type": "audio/pcm"}}]}}},
        timestamp_ms=150,
    )
    sidecar.on_server_message(
        "s1",
        {"server_content": {"turn_complete": True}},
        timestamp_ms=200,
    )

    labels = _labels("s1")
    snapshot = sidecar.snapshot()
    assert snapshot.histogram_samples("geminilive_ttfab_ms", **labels) == [50]
    assert snapshot.histogram_samples("geminilive_turn_e2e_latency_ms", **labels) == [100]

    # Tool call + tool-response turn
    sidecar.on_server_message(
        "s1",
        {"tool_call": {"function_calls": [{"name": "fn", "args": {}, "id": "tc1"}]}},
        timestamp_ms=300,
    )
    sidecar.on_client_request("s1", "client_content", timestamp_ms=400)
    sidecar.on_tool_response("s1", ["tc1"], timestamp_ms=400)

    # Gemini sends audio and turn_complete for the tool-response turn
    sidecar.on_server_message(
        "s1",
        {"server_content": {"model_turn": {"parts": [{"inline_data": {"mime_type": "audio/pcm"}}]}}},
        timestamp_ms=450,
    )
    sidecar.on_server_message(
        "s1",
        {"server_content": {"turn_complete": True}},
        timestamp_ms=500,
    )

    # Latency histograms must NOT have gained phantom samples
    snapshot = sidecar.snapshot()
    assert snapshot.histogram_samples("geminilive_ttfab_ms", **labels) == [50]
    assert snapshot.histogram_samples("geminilive_turn_e2e_latency_ms", **labels) == [100]


def test_tool_call_cancellation_counts_as_vad_interruption_events() -> None:
    sidecar = _sidecar()
    sidecar.on_session_started("s1", TARGET_MODEL, REGION, automatic_vad=True, timestamp_ms=0)
    sidecar.on_server_message(
        "s1",
        {"tool_call_cancellation": {"ids": ["a", "b", "c"]}},
        timestamp_ms=50,
    )
    snapshot = sidecar.snapshot()
    assert snapshot.counter("geminilive_vad_interruptions_total", **_labels("s1")) == 3


def test_ws_connect_latency_recorded_on_session_start() -> None:
    sidecar = _sidecar()
    sidecar.on_session_started(
        "s1", TARGET_MODEL, REGION, automatic_vad=True, timestamp_ms=0, connect_duration_ms=150.0
    )

    snapshot = sidecar.snapshot()
    assert snapshot.histogram_samples("geminilive_ws_connect_latency_ms", **_labels("s1")) == [150.0]


def test_ws_connect_latency_not_recorded_when_none() -> None:
    sidecar = _sidecar()
    sidecar.on_session_started(
        "s1", TARGET_MODEL, REGION, automatic_vad=True, timestamp_ms=0
    )

    snapshot = sidecar.snapshot()
    assert snapshot.histogram_samples("geminilive_ws_connect_latency_ms", **_labels("s1")) == []


def test_modality_tokens_with_real_sdk_enum_via_payload() -> None:
    """Real SDK MediaModality enums are correctly handled through _to_payload() production path.
    Uses real google.genai.types: LiveServerMessage, UsageMetadata, ModalityTokenCount, MediaModality."""
    from google.genai.types import Blob

    sidecar = _sidecar()
    sidecar.on_session_started("s1", TARGET_MODEL, REGION, automatic_vad=True, timestamp_ms=0)
    sidecar.on_client_request("s1", "realtime_input", timestamp_ms=0)

    msg = LiveServerMessage(
        server_content=LiveServerContent(
            model_turn=Content(
                parts=[Part(inline_data=Blob(mime_type="audio/pcm", data=b"x"))],
            ),
        ),
        usage_metadata=UsageMetadata(
            total_token_count=100,
            prompt_token_count=40,
            response_token_count=60,
            prompt_tokens_details=[
                ModalityTokenCount(modality=MediaModality.AUDIO, token_count=40),
            ],
            response_tokens_details=[
                ModalityTokenCount(modality=MediaModality.VIDEO, token_count=30),
                ModalityTokenCount(modality=MediaModality.IMAGE, token_count=30),
            ],
        ),
    )
    sidecar.on_server_message("s1", _to_payload(msg), timestamp_ms=100)

    snapshot = sidecar.snapshot()
    assert snapshot.counter("geminilive_modality_tokens_total", **{**_labels("s1"), "modality": "audio"}) == 40
    assert snapshot.counter("geminilive_modality_tokens_total", **{**_labels("s1"), "modality": "video"}) == 30
    assert snapshot.counter("geminilive_modality_tokens_total", **{**_labels("s1"), "modality": "image"}) == 30


def test_modality_tokens_with_real_sdk_enum_direct() -> None:
    """Sidecar handles real SDK MediaModality enum objects directly (defensive fallback path).
    This tests the sidecar's .value extraction when enums aren't serialized by model_dump."""
    sidecar = _sidecar()
    sidecar.on_session_started("s1", TARGET_MODEL, REGION, automatic_vad=True, timestamp_ms=0)
    sidecar.on_client_request("s1", "realtime_input", timestamp_ms=0)

    sidecar.on_server_message(
        "s1",
        {
            "server_content": {
                "model_turn": {"parts": [{"inline_data": {"mime_type": "audio/pcm", "data": b"x"}}]},
            },
            "usage_metadata": {
                "total_token_count": 100,
                "prompt_token_count": 40,
                "response_token_count": 60,
                "prompt_tokens_details": [
                    {"modality": MediaModality.AUDIO, "token_count": 40},
                ],
                "response_tokens_details": [
                    {"modality": MediaModality.VIDEO, "token_count": 30},
                    {"modality": MediaModality.IMAGE, "token_count": 30},
                ],
            },
        },
        timestamp_ms=100,
    )

    snapshot = sidecar.snapshot()
    assert snapshot.counter("geminilive_modality_tokens_total", **{**_labels("s1"), "modality": "audio"}) == 40
    assert snapshot.counter("geminilive_modality_tokens_total", **{**_labels("s1"), "modality": "video"}) == 30
    assert snapshot.counter("geminilive_modality_tokens_total", **{**_labels("s1"), "modality": "image"}) == 30


def test_ws_errors_counted() -> None:
    sidecar = _sidecar()
    sidecar.on_session_started("s1", TARGET_MODEL, REGION, automatic_vad=True, timestamp_ms=0)

    sidecar.on_ws_error("s1", error_type="CONNECTION_FAILED", timestamp_ms=100)

    snapshot = sidecar.snapshot()
    assert snapshot.counter(
        "geminilive_ws_errors_total", **{**_labels("s1"), "error_type": "CONNECTION_FAILED"}
    ) == 1


def test_usage_tokens_incremental_mode_default() -> None:
    """Default incremental mode: two usage messages are additive.
    Uses real SDK LiveServerMessage and UsageMetadata types."""
    sidecar = _sidecar()
    sidecar.on_session_started("s1", TARGET_MODEL, REGION, automatic_vad=True, timestamp_ms=0)

    msg1 = LiveServerMessage(
        usage_metadata=UsageMetadata(
            total_token_count=100, prompt_token_count=40, response_token_count=60,
        ),
    )
    msg2 = LiveServerMessage(
        usage_metadata=UsageMetadata(
            total_token_count=50, prompt_token_count=20, response_token_count=30,
        ),
    )
    sidecar.on_server_message("s1", _to_payload(msg1), timestamp_ms=1000)
    sidecar.on_server_message("s1", _to_payload(msg2), timestamp_ms=2000)

    snapshot = sidecar.snapshot()
    assert snapshot.counter("geminilive_total_tokens_total", **_labels("s1")) == 150
    assert snapshot.counter("geminilive_prompt_tokens_total", **_labels("s1")) == 60
    assert snapshot.counter("geminilive_response_tokens_total", **_labels("s1")) == 90


def test_usage_tokens_cumulative_mode() -> None:
    """Cumulative mode: deltas are computed between consecutive messages.
    Uses real SDK LiveServerMessage and UsageMetadata types."""
    sidecar = LiveTelemetrySidecar(
        target_model=TARGET_MODEL,
        region=REGION,
        token_counting="cumulative",
    )
    sidecar.on_session_started("s1", TARGET_MODEL, REGION, automatic_vad=True, timestamp_ms=0)

    msg1 = LiveServerMessage(
        usage_metadata=UsageMetadata(
            total_token_count=100, prompt_token_count=40, response_token_count=60,
        ),
    )
    msg2 = LiveServerMessage(
        usage_metadata=UsageMetadata(
            total_token_count=250, prompt_token_count=100, response_token_count=150,
        ),
    )
    sidecar.on_server_message("s1", _to_payload(msg1), timestamp_ms=1000)
    sidecar.on_server_message("s1", _to_payload(msg2), timestamp_ms=2000)

    snapshot = sidecar.snapshot()
    # Total should be delta: 100 + (250-100) = 250
    assert snapshot.counter("geminilive_total_tokens_total", **_labels("s1")) == 250
    assert snapshot.counter("geminilive_prompt_tokens_total", **_labels("s1")) == 100
    assert snapshot.counter("geminilive_response_tokens_total", **_labels("s1")) == 150


def test_usage_tokens_cumulative_mode_handles_reset() -> None:
    """Cumulative mode: if value drops, delta is clamped to 0.
    Uses real SDK LiveServerMessage and UsageMetadata types."""
    sidecar = LiveTelemetrySidecar(
        target_model=TARGET_MODEL,
        region=REGION,
        token_counting="cumulative",
    )
    sidecar.on_session_started("s1", TARGET_MODEL, REGION, automatic_vad=True, timestamp_ms=0)

    msg1 = LiveServerMessage(
        usage_metadata=UsageMetadata(
            total_token_count=200, prompt_token_count=80, response_token_count=120,
        ),
    )
    # Value drops (reset) — delta should be 0
    msg2 = LiveServerMessage(
        usage_metadata=UsageMetadata(
            total_token_count=50, prompt_token_count=20, response_token_count=30,
        ),
    )
    sidecar.on_server_message("s1", _to_payload(msg1), timestamp_ms=1000)
    sidecar.on_server_message("s1", _to_payload(msg2), timestamp_ms=2000)

    snapshot = sidecar.snapshot()
    assert snapshot.counter("geminilive_total_tokens_total", **_labels("s1")) == 200
    assert snapshot.counter("geminilive_prompt_tokens_total", **_labels("s1")) == 80
    assert snapshot.counter("geminilive_response_tokens_total", **_labels("s1")) == 120


def test_usage_tokens_cumulative_mode_throughput() -> None:
    """Cumulative mode: throughput is computed from cumulative deltas.
    Uses real SDK LiveServerMessage and UsageMetadata types."""
    sidecar = LiveTelemetrySidecar(
        target_model=TARGET_MODEL,
        region=REGION,
        token_counting="cumulative",
    )
    sidecar.on_session_started("s1", TARGET_MODEL, REGION, automatic_vad=True, timestamp_ms=0)

    msg1 = LiveServerMessage(
        usage_metadata=UsageMetadata(
            total_token_count=100, prompt_token_count=40, response_token_count=60,
        ),
    )
    msg2 = LiveServerMessage(
        usage_metadata=UsageMetadata(
            total_token_count=300, prompt_token_count=120, response_token_count=180,
        ),
    )
    sidecar.on_server_message("s1", _to_payload(msg1), timestamp_ms=1000)
    sidecar.on_server_message("s1", _to_payload(msg2), timestamp_ms=5000)

    snapshot = sidecar.snapshot()
    # session.total_tokens = 100 + 200 = 300
    # elapsed = 5 seconds
    # throughput = 300/5 = 60.0
    assert math.isclose(
        snapshot.gauge("geminilive_token_throughput_tps", **_labels("s1")),
        60.0,
    )


def test_update_quota_recalculates_utilization() -> None:
    sidecar = _sidecar(quota=1000)
    sidecar.on_session_started("s1", TARGET_MODEL, REGION, automatic_vad=True, timestamp_ms=0)
    sidecar.on_session_started("s2", TARGET_MODEL, REGION, automatic_vad=True, timestamp_ms=10)

    snapshot = sidecar.snapshot()
    assert math.isclose(
        snapshot.gauge("geminilive_concurrency_quota_utilization_pct", model_id=TARGET_MODEL, region=REGION),
        0.2,
    )

    sidecar.update_quota(100)

    snapshot = sidecar.snapshot()
    assert math.isclose(
        snapshot.gauge("geminilive_concurrency_quota_utilization_pct", model_id=TARGET_MODEL, region=REGION),
        2.0,
    )


def test_update_quota_zero_or_negative_is_ignored() -> None:
    sidecar = _sidecar(quota=1000)
    sidecar.on_session_started("s1", TARGET_MODEL, REGION, automatic_vad=True, timestamp_ms=0)

    sidecar.update_quota(0)
    assert sidecar._concurrency_quota == 1000

    sidecar.update_quota(-5)
    assert sidecar._concurrency_quota == 1000


def test_update_quota_with_no_active_sessions() -> None:
    sidecar = _sidecar(quota=1000)
    sidecar.update_quota(500)
    assert sidecar._concurrency_quota == 500


def test_qps_sliding_window_excludes_old_events() -> None:
    """QPS sliding window should only count events within the window period."""
    sidecar = LiveTelemetrySidecar(
        target_model=TARGET_MODEL,
        region=REGION,
        concurrency_quota=1000,
        rate_window_sec=10,
    )
    sidecar.on_session_started("s1", TARGET_MODEL, REGION, automatic_vad=True, timestamp_ms=0)

    # Send requests within the first few seconds
    sidecar.on_client_request("s1", "realtime_input", timestamp_ms=0)
    sidecar.on_server_message("s1", {"server_content": {"turn_complete": True}}, timestamp_ms=500)
    sidecar.on_client_request("s1", "realtime_input", timestamp_ms=1000)
    sidecar.on_server_message("s1", {"server_content": {"turn_complete": True}}, timestamp_ms=1500)
    sidecar.on_client_request("s1", "realtime_input", timestamp_ms=2500)
    sidecar.on_server_message("s1", {"server_content": {"turn_complete": True}}, timestamp_ms=3000)

    # Now send one request well after the window (t=15000 > 10s window)
    sidecar.on_client_request("s1", "realtime_input", timestamp_ms=15000)

    snapshot = sidecar.snapshot()
    # Only the last request should be in the window (t=15000, window starts at t=5000)
    # window_sec = min(10, max(1.0, (15000 - 0) / 1000.0)) = 10
    # QPS = 1 / 10 = 0.1
    assert math.isclose(snapshot.gauge("geminilive_request_qps", **_labels("s1")), 0.1)


def test_throughput_sliding_window_excludes_old_tokens() -> None:
    """Token throughput sliding window should only count tokens within the window."""
    sidecar = LiveTelemetrySidecar(
        target_model=TARGET_MODEL,
        region=REGION,
        concurrency_quota=1000,
        rate_window_sec=10,
    )
    sidecar.on_session_started("s1", TARGET_MODEL, REGION, automatic_vad=True, timestamp_ms=0)

    # Send tokens at t=1000 (within window)
    msg1 = LiveServerMessage(
        usage_metadata=UsageMetadata(
            total_token_count=500, prompt_token_count=200, response_token_count=300,
        ),
    )
    sidecar.on_server_message("s1", _to_payload(msg1), timestamp_ms=1000)

    # Send tokens at t=15000 (old tokens should have fallen out of window)
    msg2 = LiveServerMessage(
        usage_metadata=UsageMetadata(
            total_token_count=100, prompt_token_count=40, response_token_count=60,
        ),
    )
    sidecar.on_server_message("s1", _to_payload(msg2), timestamp_ms=15000)

    snapshot = sidecar.snapshot()
    # Only msg2 tokens (100) should be in the window
    # window_sec = min(10, max(1.0, (15000 - 0) / 1000.0)) = 10
    # throughput = 100 / 10 = 10.0
    assert math.isclose(
        snapshot.gauge("geminilive_token_throughput_tps", **_labels("s1")),
        10.0,
    )


def test_duplicate_tool_calls_without_explicit_id_tracked_separately() -> None:
    """Two identical tool calls (no explicit id, same function+args) should each
    get a unique fallback ID (via seq counter) and be tracked independently."""
    sidecar = _sidecar()
    sidecar.on_session_started("s1", TARGET_MODEL, REGION, automatic_vad=True, timestamp_ms=0)

    tool_args = {"contact_name": "John"}

    # Server sends first tool call (no explicit id)
    sidecar.on_server_message(
        "s1",
        {"tool_call": {"function_calls": [{"name": "call_someone", "args": tool_args}]}},
        timestamp_ms=100,
    )
    # Server sends second identical tool call (no explicit id)
    sidecar.on_server_message(
        "s1",
        {"tool_call": {"function_calls": [{"name": "call_someone", "args": tool_args}]}},
        timestamp_ms=200,
    )

    # Respond to both using the seq-aware fallback IDs
    fallback_id_1 = stable_tool_call_id(function_name="call_someone", function_args=tool_args, seq=1)
    fallback_id_2 = stable_tool_call_id(function_name="call_someone", function_args=tool_args, seq=2)

    sidecar.on_tool_response("s1", [fallback_id_1], timestamp_ms=300)
    sidecar.on_tool_response("s1", [fallback_id_2], timestamp_ms=400)

    labels = {**_labels("s1"), "function_name": "call_someone"}
    snapshot = sidecar.snapshot()
    assert snapshot.counter("geminilive_tool_calls_total", **labels) == 2
    assert len(snapshot.histogram_samples("geminilive_tool_call_roundtrip_ms", **labels)) == 2


def test_ws_error_ignored_for_unknown_session() -> None:
    sidecar = _sidecar()
    # No session started -- should not crash and should not record any metric
    sidecar.on_ws_error("unknown_session", error_type="CONNECTION_FAILED", timestamp_ms=100)

    snapshot = sidecar.snapshot()
    assert snapshot.counter(
        "geminilive_ws_errors_total",
        session_id="unknown_session",
        model_id=TARGET_MODEL,
        region=REGION,
        error_type="CONNECTION_FAILED",
    ) == 0


def test_turns_total_is_deprecated_and_not_incremented() -> None:
    """L1: geminilive_turns_total should never be incremented (deprecated)."""
    sidecar = _sidecar()
    sidecar.on_session_started("s1", TARGET_MODEL, REGION, automatic_vad=True, timestamp_ms=0)

    sidecar.on_client_request("s1", "realtime_input", timestamp_ms=100)
    sidecar.on_server_message("s1", {"server_content": {"turn_complete": True}}, timestamp_ms=200)

    snapshot = sidecar.snapshot()
    assert snapshot.counter("geminilive_turns_total", **_labels("s1")) == 0
    assert snapshot.counter("geminilive_turn_complete_total", **_labels("s1")) == 1

    defs = sidecar.metric_definitions()
    assert "deprecated" in defs["geminilive_turns_total"].description.lower()


def test_ws_connect_latency_clamps_negative_to_zero() -> None:
    """L2: Negative connect_duration_ms should be clamped to 0.0."""
    sidecar = _sidecar()
    sidecar.on_session_started(
        "s1", TARGET_MODEL, REGION, automatic_vad=True, timestamp_ms=0, connect_duration_ms=-50.0
    )

    snapshot = sidecar.snapshot()
    assert snapshot.histogram_samples("geminilive_ws_connect_latency_ms", **_labels("s1")) == [0.0]


def test_api_error_on_closed_session_is_logged(caplog) -> None:
    """L3: on_api_error on unknown/closed session should log a debug message."""
    import logging

    sidecar = _sidecar()

    with caplog.at_level(logging.DEBUG, logger="geminiliveotel.sidecar"):
        sidecar.on_api_error("unknown_sess", code="UNAVAILABLE", message="err", timestamp_ms=100)

    assert "unknown/closed session" in caplog.text
    assert "unknown_sess" in caplog.text


def test_duplicate_turn_complete_does_not_double_count() -> None:
    """L4: Two turn_complete messages without intervening client request should only count once."""
    sidecar = _sidecar()
    sidecar.on_session_started("s1", TARGET_MODEL, REGION, automatic_vad=True, timestamp_ms=0)

    sidecar.on_client_request("s1", "realtime_input", timestamp_ms=100)
    sidecar.on_server_message("s1", {"server_content": {"turn_complete": True}}, timestamp_ms=200)
    # Duplicate turn_complete without intervening client request
    sidecar.on_server_message("s1", {"server_content": {"turn_complete": True}}, timestamp_ms=300)

    snapshot = sidecar.snapshot()
    assert snapshot.counter("geminilive_turn_complete_total", **_labels("s1")) == 1
    assert snapshot.counter("geminilive_successful_model_responses_total", **_labels("s1")) == 1


def test_completed_tool_calls_bounded() -> None:
    """L7: completed_tool_calls dict should be bounded with eviction."""
    sidecar = _sidecar()
    sidecar.on_session_started("s1", TARGET_MODEL, REGION, automatic_vad=True, timestamp_ms=0)

    session = sidecar._sessions["s1"]
    # Populate 10001 entries directly
    for i in range(10_001):
        session.completed_tool_calls[f"tc_{i}"] = None

    # Add one more via on_tool_response — this triggers eviction
    sidecar.on_server_message(
        "s1",
        {"tool_call": {"function_calls": [{"id": "tc_new", "name": "fn"}]}},
        timestamp_ms=100,
    )
    sidecar.on_tool_response("s1", ["tc_new"], timestamp_ms=200)

    assert len(session.completed_tool_calls) <= 10_001


def test_overlapping_turns_reset_latency_tracking() -> None:
    """L11: client_content during an existing turn resets the turn start timestamp."""
    sidecar = _sidecar()
    sidecar.on_session_started("s1", TARGET_MODEL, REGION, automatic_vad=True, timestamp_ms=0)

    # Start a turn with realtime_input at t=100
    sidecar.on_client_request("s1", "realtime_input", timestamp_ms=100)
    # Send client_content at t=500, which should reset turn start
    sidecar.on_client_request("s1", "client_content", timestamp_ms=500)
    # turn_complete at t=600 — e2e should be 100ms (600 - 500), not 500ms (600 - 100)
    sidecar.on_server_message("s1", {"server_content": {"turn_complete": True}}, timestamp_ms=600)

    snapshot = sidecar.snapshot()
    assert snapshot.histogram_samples("geminilive_turn_e2e_latency_ms", **_labels("s1")) == [100]


def test_metric_store_thread_safe_increment() -> None:
    """L12: _MetricStore should be thread-safe."""
    import threading

    from geminiliveotel.sidecar import _MetricStore

    store = _MetricStore()
    labels = {"session_id": "s1", "model_id": TARGET_MODEL, "region": REGION}

    def _increment_100():
        for _ in range(100):
            store.inc_counter("test_counter", labels)

    threads = [threading.Thread(target=_increment_100) for _ in range(4)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    snapshot = store.snapshot()
    assert snapshot.counter("test_counter", **labels) == 400
