"""
OpenAI-specific implementation of the BaseAIClient.

This module provides the OpenAIClient class, which implements the BaseAIClient
interface specifically for OpenAI's API, supporting both text-only and
multimodal content (text + images).

Also used for OpenAI-compatible APIs like OpenRouter and sciCORE.
"""

import base64
import json
import logging
from datetime import datetime, timezone
from typing import List, Tuple, Any, Optional

from openai import OpenAI

from .base_client import BaseAIClient
from .response import LLMResponse, Usage
from .pricing import calculate_cost
from .utils import extract_json_from_text

logger = logging.getLogger(__name__)


class OpenAIClient(BaseAIClient):
    """
    OpenAI-specific implementation of the BaseAIClient.

    This class implements the BaseAIClient interface for OpenAI's API,
    handling both text-only and multimodal (text + images) requests through
    the OpenAI Chat Completions API.

    Key features:
    - Full support for multimodal content via GPT-4 Vision models
    - Image encoding and formatting specific to OpenAI's requirements
    - Support for OpenAI-specific parameters like frequency_penalty, top_p, etc.
    - Support for structured output via response_format
    - Custom base_url support for OpenRouter, sciCORE, and other OpenAI-compatible APIs
    """

    PROVIDER_ID = "openai"
    SUPPORTS_MULTIMODAL = True
    SUPPORTS_TOOLS = True

    def _init_client(self):
        """Initialize the OpenAI client with the provided API key and optional base URL."""
        kwargs = {"api_key": self.api_key}

        # Support custom base URLs (for OpenRouter, sciCORE, etc.)
        if self.base_url:
            kwargs["base_url"] = self.base_url

        # Add custom headers if provided
        if "default_headers" in self.settings:
            kwargs["default_headers"] = self.settings["default_headers"]

        self.api_client = OpenAI(**kwargs)

    def _prepare_message_with_images(
        self, prompt: str, images: List[str], system_prompt: str
    ) -> List[dict]:
        """
        Prepare an OpenAI message object with text and images.

        Args:
            prompt: The text prompt
            images: List of image paths/URLs
            system_prompt: System prompt

        Returns:
            List of OpenAI message objects with content
        """
        # Prepare user content with text
        user_content = [{"type": "text", "text": prompt}]

        # Add images if any
        for resource in images:
            if self.is_url(resource):
                # For URLs, directly use the URL in the prompt
                user_content.append({"type": "image_url", "image_url": {"url": resource}})
            else:
                # For local files, read and encode as base64
                try:
                    with open(resource, "rb") as image_file:
                        image_data = image_file.read()
                        base64_image = base64.b64encode(image_data).decode("utf-8")

                    # Detect MIME type from file extension
                    from .utils import detect_image_mime_type

                    mime_type = detect_image_mime_type(resource)

                    user_content.append(
                        {
                            "type": "image_url",
                            "image_url": {"url": f"data:{mime_type};base64,{base64_image}"},
                        }
                    )
                except Exception as e:
                    logger.error(f"Error reading image file {resource}: {e}")

        # Return the complete message structure
        return [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_content},
        ]

    def _do_prompt(
        self,
        model: str,
        prompt: str,
        messages: Optional[List[dict]] = None,
        images: Optional[List[str]] = None,
        system_prompt: Optional[str] = None,
        response_format: Optional[Any] = None,
        cache: bool = False,
        file_content: str = "",
        **kwargs,
    ) -> LLMResponse:
        """
        Send a prompt to the OpenAI model and get the response.

        OpenAI has automatic prompt caching for 1024+ tokens.

        Args:
            model: The OpenAI model identifier (e.g., "gpt-4o", "gpt-3.5-turbo")
            prompt: The text prompt to send
            messages: Optional conversation history (multi-turn)
            images: List of image paths/URLs to include
            system_prompt: System prompt to use
            response_format: Optional Pydantic model for structured output
            cache: Informational only (caching is always automatic)
            file_content: Not used (files already appended to prompt)
            **kwargs: Additional OpenAI-specific parameters
                prompt_cache_key: Routing hint for cache optimization
                prompt_cache_retention: "in_memory" (5-10min) or "24h"

        Returns:
            LLMResponse object with the provider's response
        """
        # Handle conversation messages
        images = images or []
        if messages and len(messages) > 1:
            # Multi-turn conversation: use provided messages
            api_messages = []

            # Add system prompt first
            if system_prompt:
                api_messages.append({"role": "system", "content": system_prompt})

            # Add conversation messages, attaching images to the last user message
            for i, msg in enumerate(messages):
                if msg["role"] == "user" and i == len(messages) - 1 and images:
                    # Last user message - add images
                    content = [{"type": "text", "text": msg["content"]}]
                    for resource in images:
                        if self.is_url(resource):
                            content.append({"type": "image_url", "image_url": {"url": resource}})
                        else:
                            try:
                                with open(resource, "rb") as image_file:
                                    image_data = image_file.read()
                                    base64_image = base64.b64encode(image_data).decode("utf-8")
                                from .utils import detect_image_mime_type

                                mime_type = detect_image_mime_type(resource)
                                content.append(
                                    {
                                        "type": "image_url",
                                        "image_url": {
                                            "url": f"data:{mime_type};base64,{base64_image}"
                                        },
                                    }
                                )
                            except Exception as e:
                                logger.error(f"Error reading image file {resource}: {e}")
                    api_messages.append({"role": msg["role"], "content": content})
                else:
                    api_messages.append(msg)
        else:
            # Single-turn request: use original method
            api_messages = self._prepare_message_with_images(prompt, images, system_prompt)

        # Extract OpenAI-specific parameters from settings and kwargs
        params = {
            "model": model,
            "messages": api_messages,
        }

        # Add OpenAI caching parameters (from kwargs)
        if "prompt_cache_key" in kwargs:
            params["prompt_cache_key"] = kwargs["prompt_cache_key"]

        if "prompt_cache_retention" in kwargs and kwargs["prompt_cache_retention"] in [
            "in_memory",
            "24h",
        ]:
            params["prompt_cache_retention"] = kwargs["prompt_cache_retention"]

        # Add optional parameters if specified
        optional_params = [
            "temperature",
            "max_tokens",
            "top_p",
            "frequency_penalty",
            "presence_penalty",
            "seed",
            "n",
            "stop",
        ]
        for param in optional_params:
            value = kwargs.get(param, self.settings.get(param))
            if value is not None:
                params[param] = value

        # Handle tool calling
        tool_definitions = kwargs.pop("_tool_definitions", None)
        if tool_definitions:
            # Convert to OpenAI tools format
            params["tools"] = [
                {
                    "type": "function",
                    "function": {
                        "name": tool.get("function", tool.get("name", "unknown")),
                        "description": tool.get("description", ""),
                        "parameters": tool.get("parameters", {}),
                    },
                }
                for tool in tool_definitions
            ]
            params["tool_choice"] = "auto"

        # Handle structured output
        if response_format:
            # Check if it's a Pydantic model (v1 or v2)
            is_pydantic_v2 = hasattr(response_format, "model_json_schema")
            is_pydantic_v1 = hasattr(response_format, "schema")

            if is_pydantic_v2:
                # Use beta.chat.completions.parse for Pydantic v2 structured output
                try:
                    params["response_format"] = response_format
                    raw_response = self.api_client.beta.chat.completions.parse(**params)
                    return self._create_response_from_parsed(raw_response, model)
                except Exception as e:
                    logger.warning(f"Structured output failed, falling back to JSON mode: {e}")
                    # Fall through to JSON object mode

            # Fallback to JSON object mode (for Pydantic v1 or when v2 parse fails)
            params["response_format"] = {"type": "json_object"}

            # Get JSON schema (support both Pydantic v1 and v2)
            if is_pydantic_v2:
                schema_dict = response_format.model_json_schema()
            elif is_pydantic_v1:
                schema_dict = response_format.schema()
            else:
                schema_dict = None

            if schema_dict:
                schema_prompt = f"\n\nYou MUST respond with valid JSON matching this exact schema: {json.dumps(schema_dict)}"

                # Find the last user message and append the schema prompt
                last_user_idx = None
                for i in range(len(params["messages"]) - 1, -1, -1):
                    if params["messages"][i].get("role") == "user":
                        last_user_idx = i
                        break

                if last_user_idx is not None:
                    msg = params["messages"][last_user_idx]
                    # Handle both string and array content
                    if isinstance(msg["content"], str):
                        msg["content"] += schema_prompt
                    elif isinstance(msg["content"], list):
                        # Content is an array (multimodal) - append text block
                        msg["content"].append({"type": "text", "text": schema_prompt})
                else:
                    # No user message found, add a new one
                    params["messages"].append({"role": "user", "content": schema_prompt})

        # Send the request to OpenAI
        raw_response = self.api_client.chat.completions.create(**params)

        return self._create_response_from_raw(raw_response, model, response_format)

    def _create_response_from_parsed(self, raw_response: Any, model: str) -> LLMResponse:
        """
        Create LLMResponse from OpenAI parsed response (structured output).

        Args:
            raw_response: Raw OpenAI response object
            model: Model identifier

        Returns:
            LLMResponse object
        """
        choice = raw_response.choices[0]

        # For structured output, the parsed object is in message.parsed
        parsed_data = None
        if hasattr(choice.message, "parsed") and choice.message.parsed:
            text = choice.message.parsed.model_dump_json()
            # Parse the JSON to dict/list for convenience
            try:
                parsed_data = json.loads(text)
            except Exception:
                pass
        else:
            text = choice.message.content or ""
            # Try to extract JSON even if structured output wasn't used
            parsed_data = extract_json_from_text(text)

        usage = Usage()
        if hasattr(raw_response, "usage") and raw_response.usage:
            # Extract cached tokens from prompt_tokens_details
            cached_tokens = 0
            if hasattr(raw_response.usage, "prompt_tokens_details"):
                details = raw_response.usage.prompt_tokens_details
                if hasattr(details, "cached_tokens"):
                    cached_tokens = details.cached_tokens
                elif isinstance(details, dict):
                    cached_tokens = details.get("cached_tokens", 0)

            usage = Usage(
                input_tokens=raw_response.usage.prompt_tokens,
                output_tokens=raw_response.usage.completion_tokens,
                total_tokens=raw_response.usage.total_tokens,
                cached_tokens=cached_tokens if cached_tokens > 0 else None,
            )
            # Calculate cost if pricing data is available
            costs = calculate_cost(
                self.PROVIDER_ID,
                raw_response.model,
                usage.input_tokens,
                usage.output_tokens,
            )
            if costs is not None:
                usage.input_cost_usd, usage.output_cost_usd, usage.estimated_cost_usd = costs

        return LLMResponse(
            text=text,
            model=raw_response.model,
            provider=self.PROVIDER_ID,
            finish_reason=choice.finish_reason or "unknown",
            usage=usage,
            raw_response=raw_response,
            parsed=parsed_data,
        )

    def _create_response_from_raw(
        self, raw_response: Any, model: str, response_format: Optional[Any]
    ) -> LLMResponse:
        """
        Create LLMResponse from OpenAI raw response.

        Args:
            raw_response: Raw OpenAI response object
            model: Model identifier
            response_format: Pydantic model if structured output was requested

        Returns:
            LLMResponse object
        """
        choice = raw_response.choices[0]
        text = choice.message.content or ""
        parsed_data = None

        # Extract tool calls if present
        tool_calls = None
        if hasattr(choice.message, "tool_calls") and choice.message.tool_calls:
            tool_calls = [
                {
                    "id": tc.id,
                    "name": tc.function.name,
                    "arguments": json.loads(tc.function.arguments),
                }
                for tc in choice.message.tool_calls
            ]

        # Try to extract JSON from the response (works with or without response_format)
        extracted_json = extract_json_from_text(text)

        # If response_format was provided, validate with Pydantic (v1 or v2)
        is_pydantic = response_format and (
            hasattr(response_format, "model_json_schema") or hasattr(response_format, "schema")
        )

        if is_pydantic and extracted_json:
            try:
                # Validate with Pydantic (works for both v1 and v2)
                validated = response_format(**extracted_json)
                # Use appropriate dump method based on Pydantic version
                if hasattr(validated, "model_dump_json"):
                    # Pydantic v2
                    text = validated.model_dump_json()
                else:
                    # Pydantic v1
                    text = validated.json()
                parsed_data = extracted_json
            except Exception as e:
                logger.warning(f"Failed to validate structured response with Pydantic: {e}")
                # Keep original text but still set parsed_data if JSON was valid
                parsed_data = extracted_json
        elif extracted_json:
            # No response_format, but we found valid JSON - populate parsed attribute
            parsed_data = extracted_json

        usage = Usage()
        if hasattr(raw_response, "usage") and raw_response.usage:
            # Extract cached tokens from prompt_tokens_details (correct location)
            cached_tokens = 0
            if hasattr(raw_response.usage, "prompt_tokens_details"):
                details = raw_response.usage.prompt_tokens_details
                if hasattr(details, "cached_tokens"):
                    cached_tokens = details.cached_tokens
                elif isinstance(details, dict):
                    cached_tokens = details.get("cached_tokens", 0)

            # Safely handle cached_tokens (might be Mock in tests)
            cached_tokens_value = None
            if isinstance(cached_tokens, (int, float)) and cached_tokens > 0:
                cached_tokens_value = cached_tokens

            usage = Usage(
                input_tokens=raw_response.usage.prompt_tokens,
                output_tokens=raw_response.usage.completion_tokens,
                total_tokens=raw_response.usage.total_tokens,
                cached_tokens=cached_tokens_value,
            )
            # OpenRouter may include cost information
            if hasattr(raw_response.usage, "cost"):
                usage.estimated_cost_usd = raw_response.usage.cost
            else:
                # Calculate cost if pricing data is available
                costs = calculate_cost(
                    self.PROVIDER_ID,
                    raw_response.model,
                    usage.input_tokens,
                    usage.output_tokens,
                )
                if costs is not None:
                    usage.input_cost_usd, usage.output_cost_usd, usage.estimated_cost_usd = costs

        response = LLMResponse(
            text=text,
            model=raw_response.model,
            provider=self.PROVIDER_ID,
            finish_reason=choice.finish_reason or "unknown",
            usage=usage,
            raw_response=raw_response,
            parsed=parsed_data,
            tool_calls=tool_calls,
        )

        return response

    def get_model_list(self) -> List[Tuple[str, Optional[str]]]:
        """
        Get a list of available models from OpenAI.

        Returns:
            List of tuples (model_id, created_date)
        """
        if self.api_client is None:
            raise ValueError("OpenAI client is not initialized.")

        raw_list = self.api_client.models.list()
        model_list = []

        for model in raw_list:
            readable_date = datetime.fromtimestamp(model.created, tz=timezone.utc).strftime(
                "%Y-%m-%d"
            )
            model_list.append((model.id, readable_date))

        return model_list

    def _build_tool_messages(
        self,
        original_prompt: str,
        tool_calls: List[dict[str, Any]],
        tool_results: List[dict[str, Any]],
    ) -> List[dict[str, Any]]:
        """
        Build OpenAI message format with tool calls and results.

        Args:
            original_prompt: The original user prompt
            tool_calls: List of tool calls made by LLM
            tool_results: List of tool execution results

        Returns:
            List of message dicts in OpenAI format
        """
        return [
            {"role": "user", "content": original_prompt},
            {
                "role": "assistant",
                "content": None,
                "tool_calls": [
                    {
                        "id": tc["id"],
                        "type": "function",
                        "function": {
                            "name": tc["name"],
                            "arguments": json.dumps(tc["arguments"]),
                        },
                    }
                    for tc in tool_calls
                ],
            },
            *[
                {
                    "role": "tool",
                    "tool_call_id": result["tool_call_id"],
                    "content": result["content"],
                }
                for result in tool_results
            ],
        ]
