use std::collections::HashMap;

use pyo3::exceptions::{PyValueError, PyIndexError};
use pyo3::prelude::*;


#[pyclass]
struct TimeSeriesObject {
    timestamps: Vec<i32>,
    values: Vec<Py<PyAny>>,
}


impl TimeSeriesObject {
    fn get_insertion_index(&self, ts: i32) -> usize {
        self.timestamps.binary_search(&ts).unwrap_or_else(|idx| idx)
    }

    fn is_empty(&self) -> bool {
        self.timestamps.is_empty()
    }
}


#[pymethods]
impl TimeSeriesObject {

    #[new]
    fn new() -> Self {
        TimeSeriesObject {timestamps: Vec::new(), values: Vec::new()}
    }

    fn __len__(&self) -> usize {
        self.timestamps.len()
    }

    fn __repr__(&self) -> String {
        let timestamps = &self.timestamps;
        format!("TimeSeriesObject(timestamps={timestamps:?})")
    }

    fn __bool__(&self) -> bool {
        !self.is_empty()
    }

    #[pyo3(signature = (ts, value, overwrite = false))]
    fn insert(&mut self, ts: i32, value: Py<PyAny>, overwrite: bool) -> PyResult<()> {
        if self.is_empty() || (ts > self.timestamps[self.timestamps.len()-1]) {
            self.timestamps.push(ts);
            self.values.push(value);
            return Ok(())
        }
        let idx = self.get_insertion_index(ts);

        let current_ts_at_idx = self.timestamps[idx];

        if (current_ts_at_idx == ts) & overwrite{
            self.values[idx] = value;
            return Ok(())
        }

        if (current_ts_at_idx == ts) & !overwrite{
            return Err(PyValueError::new_err("Timestamp already exists in TimeSeriesObject, set overwrite=True to overwrite this value"))
        }

        self.timestamps.insert(idx, ts);
        self.values.insert(idx, value);
        Ok(())
    }

    fn delete(&mut self, ts: i32) -> PyResult<()> {
        if self.is_empty() {
            return Err(PyValueError::new_err("TimeSeriesObject is empty"))
        }
        let delete_idx = self.get_insertion_index(ts);
        if self.timestamps[delete_idx] != ts {
            return Err(PyIndexError::new_err("Timestamp does not exist in TimeSeriesObject"))
        }
        self.timestamps.remove(delete_idx);
        self.values.remove(delete_idx);
        Ok(())
    }

    fn update(&mut self, ts: i32, value: Py<PyAny>) -> PyResult<()> {
        if self.is_empty() {
            return Err(PyValueError::new_err("TimeSeriesObject is empty"))
        }
        let update_idx = self.get_insertion_index(ts);
        if self.timestamps[update_idx] != ts {
            return Err(PyIndexError::new_err("Timestamp does not exist in TimeSeriesObject"))
        }
        self.values[update_idx] = value;
        Ok(())
    }

    fn point(&self, ts: i32) -> Option<(&i32, &Py<PyAny>)> {
        if self.is_empty() {
            return None
        }

        let idx = self.get_insertion_index(ts);
        if idx == 0 && self.timestamps[idx] == ts {
            return Some((&self.timestamps[idx], &self.values[idx]))
        }
        if idx == 0 && self.timestamps[idx] != ts{
            return None
        }

        if (idx == self.__len__()) || self.timestamps[idx] != ts {
            Some((&self.timestamps[idx-1], &self.values[idx-1]))
        } else if self.timestamps[idx] == ts{
            Some((&self.timestamps[idx], &self.values[idx]))
        } else {
            None
        }
    }

    fn point_on(&self, ts: i32) -> Option<(&i32, &Py<PyAny>)> {
        if self.is_empty() {
            return None
        }
        let idx = self.get_insertion_index(ts);
        if (idx != self.__len__()) && self.timestamps[idx] == ts {
            Some((&self.timestamps[idx], &self.values[idx]))
        } else {
            None
        }
    }

    fn points_between(&self, start_ts: i32, end_ts: i32) -> Vec<(&i32,&Py<PyAny>)> {
        let start_idx = self.get_insertion_index(start_ts);
        let end_idx = self.get_insertion_index(end_ts);
        let mut return_vec = Vec::new();
        for idx in start_idx..end_idx {
            let point_ts = &self.timestamps[idx];
            let value_ts = &self.values[idx];
            return_vec.push((point_ts, value_ts))
        }
        return_vec
    }

    fn as_dict(&self) -> HashMap<&i32, &Py<PyAny>> {
        let mut return_dict = HashMap::new();
        for idx in 0..self.__len__() {
            let point_ts = &self.timestamps[idx];
            let value_ts = &self.values[idx];
            return_dict.insert(point_ts, value_ts);
        }
        return_dict
    }

    fn as_list(&self) -> Vec<(&i32, &Py<PyAny>)> {
        let mut return_list = Vec::new();
        for idx in 0..self.__len__() {
            let point_ts = &self.timestamps[idx];
            let value_ts = &self.values[idx];
            return_list.push((point_ts, value_ts));
        }
        return_list
    }
}


#[pymodule]
fn generic_time_series_objects(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<TimeSeriesObject>()?;
    Ok(())
}
