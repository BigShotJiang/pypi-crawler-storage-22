"""
Metrics module for gene expression evaluation.

Provides per-gene and aggregate metrics for comparing distributions:
- Reconstruction metrics (MSE, RMSE, MAE, R²)
- Correlation metrics (Pearson, Spearman)
- Distribution distances (Wasserstein, MMD, Energy)
- Multivariate distances
"""

from .base_metric import (
    BaseMetric,
    MetricResult,
    DistributionMetric,
    CorrelationMetric,
)
from .correlation import (
    PearsonCorrelation,
    SpearmanCorrelation,
    MeanPearsonCorrelation,
    MeanSpearmanCorrelation,
)
from .distances import (
    Wasserstein1Distance,
    Wasserstein2Distance,
    MMDDistance,
    EnergyDistance,
    MultivariateWasserstein,
    MultivariateMMD,
)
from .reconstruction import (
    MSEDistance,
    RMSEDistance,
    MAEDistance,
    R2Score,
)

# All available metrics
ALL_METRICS = [
    # Reconstruction
    MSEDistance,
    RMSEDistance,
    MAEDistance,
    R2Score,
    # Correlation
    PearsonCorrelation,
    SpearmanCorrelation,
    MeanPearsonCorrelation,
    MeanSpearmanCorrelation,
    # Distribution
    Wasserstein1Distance,
    Wasserstein2Distance,
    MMDDistance,
    EnergyDistance,
    MultivariateWasserstein,
    MultivariateMMD,
]

__all__ = [
    # Base classes
    "BaseMetric",
    "MetricResult",
    "DistributionMetric",
    "CorrelationMetric",
    # Reconstruction metrics
    "MSEDistance",
    "RMSEDistance",
    "MAEDistance",
    "R2Score",
    # Correlation metrics
    "PearsonCorrelation",
    "SpearmanCorrelation",
    "MeanPearsonCorrelation",
    "MeanSpearmanCorrelation",
    # Distance metrics
    "Wasserstein1Distance",
    "Wasserstein2Distance",
    "MMDDistance",
    "EnergyDistance",
    "MultivariateWasserstein",
    "MultivariateMMD",
    # Collections
    "ALL_METRICS",
]