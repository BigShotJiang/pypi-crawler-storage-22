# GenEval: Gene Expression Evaluation Framework

[![PyPI version](https://badge.fury.io/py/gengeneeval.svg)](https://badge.fury.io/py/gengeneeval)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Tests](https://github.com/AndreaRubbi/GenGeneEval/actions/workflows/test.yml/badge.svg)](https://github.com/AndreaRubbi/GenGeneEval/actions)

**Comprehensive evaluation of generated gene expression data against real datasets.**

GenEval is a modular, object-oriented Python framework for computing metrics between real and generated gene expression datasets stored in AnnData (h5ad) format. It supports condition-based matching, train/test splits, memory-efficient lazy loading for large datasets, and generates publication-quality visualizations.

## Features

### Metrics
All metrics are computed **per-gene** (returning a vector) and **aggregated**:

| Metric | Description | Direction |
|--------|-------------|-----------|
| **MSE** | Mean Squared Error | Lower is better |
| **RMSE** | Root Mean Squared Error | Lower is better |
| **MAE** | Mean Absolute Error | Lower is better |
| **R²** | Coefficient of Determination | Higher is better |
| **Pearson Correlation** | Linear correlation between expression profiles | Higher is better |
| **Spearman Correlation** | Rank correlation (robust to outliers) | Higher is better |
| **Wasserstein-1** | Earth Mover's Distance (L1) | Lower is better |
| **Wasserstein-2** | Quadratic optimal transport | Lower is better |
| **MMD** | Maximum Mean Discrepancy (kernel-based) | Lower is better |
| **Energy Distance** | Statistical potential energy | Lower is better |

### Visualizations
- **Boxplots & Violin plots**: Metric distributions across conditions
- **Radar plots**: Multi-metric comparison
- **Scatter plots**: Real vs generated expression
- **Embedding plots**: PCA/UMAP of real vs generated data
- **Heatmaps**: Per-gene metric values

### Key Features
- ✅ Condition-based matching (perturbation, cell type, etc.)
- ✅ Train/test split support
- ✅ Per-gene and aggregate metrics
- ✅ **Memory-efficient lazy loading** for large datasets
- ✅ **Batched evaluation** to avoid OOM errors
- ✅ **CPU parallelization** via joblib (multi-core speedup)
- ✅ **GPU acceleration** via PyTorch (10-100x speedup)
- ✅ Modular, extensible architecture
- ✅ Command-line interface
- ✅ Publication-quality visualizations

## Installation

### Using pip
```bash
pip install -e .
```

### With GPU support (faster distance metrics)
```bash
pip install -e ".[gpu]"
```

## Quick Start

### Python API

```python
from geneval import evaluate

# Run evaluation
results = evaluate(
    real_path="real_data.h5ad",
    generated_path="generated_data.h5ad",
    condition_columns=["perturbation", "cell_type"],
    split_column="split",  # Optional: for train/test
    output_dir="evaluation_output/"
)

# Access results
print(results.summary())

# Get metric for specific split
test_results = results.get_split("test")
for condition, cond_result in test_results.conditions.items():
    print(f"{condition}: Pearson={cond_result.get_metric_value('pearson'):.3f}")
```

### Command Line

```bash
# Basic usage
geneval --real real.h5ad --generated generated.h5ad \
        --conditions perturbation cell_type \
        --output results/

# With split column
geneval --real real.h5ad --generated generated.h5ad \
        --conditions perturbation \
        --split-column split \
        --splits test \
        --output results/

# Specify metrics
geneval --real real.h5ad --generated generated.h5ad \
        --conditions perturbation \
        --metrics pearson spearman wasserstein_1 mmd \
        --output results/
```

### Memory-Efficient Mode (for Large Datasets)

For datasets too large to fit in memory, use the lazy evaluation API:

```python
from geneval import evaluate_lazy, load_data_lazy

# Memory-efficient evaluation (streams data one condition at a time)
results = evaluate_lazy(
    real_path="large_real.h5ad",
    generated_path="large_generated.h5ad",
    condition_columns=["perturbation"],
    batch_size=256,                    # Process in batches
    use_backed=True,                   # Memory-mapped file access
    output_dir="eval_output/",
    save_per_condition=True,           # Save each condition to disk
)

# Get summary statistics
print(results.get_summary())

# Or use the lazy loader directly for custom workflows
with load_data_lazy("real.h5ad", "gen.h5ad", ["perturbation"]) as loader:
    print(f"Memory estimate: {loader.estimate_memory_usage()}")
    
    # Process one condition at a time
    for key, real, gen, info in loader.iterate_conditions():
        # Your custom evaluation logic
        pass
```

### Accelerated Evaluation (CPU Parallelization & GPU)

GenEval supports CPU parallelization and GPU acceleration for significant speedups:

```python
from geneval import evaluate, get_available_backends

# Check available backends
print(get_available_backends())
# {'joblib': True, 'torch': True, 'geomloss': True, 'cuda': True, 'mps': False}

# Parallel CPU evaluation (use all cores)
results = evaluate(
    real_path="real.h5ad",
    generated_path="generated.h5ad",
    condition_columns=["perturbation"],
    n_jobs=-1,  # Use all available CPU cores
)

# GPU-accelerated evaluation
results = evaluate(
    real_path="real.h5ad",
    generated_path="generated.h5ad",
    condition_columns=["perturbation"],
    device="cuda",  # Use NVIDIA GPU
)

# Combined: parallel CPU + auto device selection
results = evaluate(..., n_jobs=8, device="auto")
```

#### Low-level Accelerated API

For custom workflows, use the accelerated metrics directly:

```python
from geneval.metrics.accelerated import (
    compute_metrics_accelerated,
    GPUWasserstein1,
    GPUMMD,
    vectorized_wasserstein1,
)
import numpy as np

# Load your data
real = np.random.randn(1000, 5000)      # 1000 cells, 5000 genes
generated = np.random.randn(1000, 5000)

# Compute multiple metrics with acceleration
results = compute_metrics_accelerated(
    real, generated,
    metrics=["wasserstein_1", "wasserstein_2", "mmd", "energy"],
    n_jobs=8,          # CPU parallelization
    device="cuda",     # GPU acceleration
    verbose=True,
)

# Access results
print(f"W1: {results['wasserstein_1'].aggregate_value:.4f}")
print(f"MMD: {results['mmd'].aggregate_value:.4f}")
```

#### Performance Tips

| Optimization | Speedup | When to Use |
|--------------|---------|-------------|
| `n_jobs=-1` (all cores) | 4-16x | Always (if joblib available) |
| `device="cuda"` | 10-100x | Large datasets, NVIDIA GPU available |
| `device="mps"` | 5-20x | Apple Silicon Macs |
| Vectorized NumPy | 2-5x | Automatic fallback |

## Expected Data Format

GenEval expects AnnData (h5ad) files with:

### Required
- `adata.X`: Gene expression matrix (samples × genes)
- `adata.var_names`: Gene identifiers (must overlap between datasets)
- `adata.obs[condition_columns]`: Columns for matching conditions

### Optional
- `adata.obs[split_column]`: Train/test split indicator

## Output Structure

```
output/
├── summary.json          # Aggregate metrics and metadata
├── results.csv           # Per-condition metrics table
├── per_gene_*.csv        # Per-gene metric values
└── plots/
    ├── boxplot_metrics.png
    ├── violin_metrics.png
    ├── radar_split.png
    ├── scatter_grid.png
    └── embedding_pca.png
```

## Contributing

Contributions are welcome! Please feel free to submit a pull request or open an issue.

## License

This project is licensed under the MIT License. See the LICENSE file for details.