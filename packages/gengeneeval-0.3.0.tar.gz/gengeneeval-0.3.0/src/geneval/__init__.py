"""
GenEval: Comprehensive evaluation of generated gene expression data.

A modular, object-oriented framework for computing metrics between real
and generated gene expression datasets stored in AnnData (h5ad) format.

Features:
- Multiple distance and correlation metrics (per-gene and aggregate)
- Condition-based matching (perturbation, cell type, etc.)
- Train/test split support
- Memory-efficient lazy loading for large datasets
- Publication-quality visualizations
- Command-line interface

Quick Start:
    >>> from geneval import evaluate
    >>> results = evaluate(
    ...     real_path="real.h5ad",
    ...     generated_path="generated.h5ad", 
    ...     condition_columns=["perturbation"],
    ...     output_dir="output/"
    ... )

Memory-Efficient Mode (for large datasets):
    >>> from geneval import evaluate_lazy
    >>> results = evaluate_lazy(
    ...     real_path="real.h5ad",
    ...     generated_path="generated.h5ad",
    ...     condition_columns=["perturbation"],
    ...     batch_size=256,
    ...     use_backed=True,  # Memory-mapped access
    ... )

CLI Usage:
    $ geneval --real real.h5ad --generated generated.h5ad \\
              --conditions perturbation cell_type --output results/
"""

__version__ = "0.3.0"
__author__ = "GenEval Team"

# Main evaluation interface
from .evaluator import (
    evaluate,
    GeneEvalEvaluator,
    MetricRegistry,
)

# Memory-efficient evaluation
from .lazy_evaluator import (
    evaluate_lazy,
    MemoryEfficientEvaluator,
    StreamingEvaluationResult,
)

# Data loading
from .data.loader import (
    GeneExpressionDataLoader,
    load_data,
)

# Memory-efficient data loading
from .data.lazy_loader import (
    LazyGeneExpressionDataLoader,
    load_data_lazy,
    ConditionBatch,
)

# Results
from .results import (
    EvaluationResult,
    SplitResult,
    ConditionResult,
)

# Metrics
from .metrics.base_metric import (
    BaseMetric,
    MetricResult,
    DistributionMetric,
    CorrelationMetric,
)
from .metrics.correlation import (
    PearsonCorrelation,
    SpearmanCorrelation,
    MeanPearsonCorrelation,
    MeanSpearmanCorrelation,
)
from .metrics.distances import (
    Wasserstein1Distance,
    Wasserstein2Distance,
    MMDDistance,
    EnergyDistance,
    MultivariateWasserstein,
    MultivariateMMD,
)
from .metrics.reconstruction import (
    MSEDistance,
    RMSEDistance,
    MAEDistance,
    R2Score,
)

# Accelerated computation
from .metrics.accelerated import (
    AccelerationConfig,
    ParallelMetricComputer,
    get_available_backends,
    compute_metrics_accelerated,
)

# Visualization
from .visualization.visualizer import (
    EvaluationVisualizer,
    visualize,
)

# Legacy support
from .data.gene_expression_datamodule import GeneExpressionDataModule

# Testing utilities (for users to generate test data)
from .testing import (
    MockDataGenerator,
    MockMetricData,
    create_test_data,
)

__all__ = [
    # Version
    "__version__",
    # Main API
    "evaluate",
    "GeneEvalEvaluator",
    "MetricRegistry",
    # Memory-efficient evaluation
    "evaluate_lazy",
    "MemoryEfficientEvaluator",
    "StreamingEvaluationResult",
    # Data loading
    "GeneExpressionDataLoader",
    "load_data",
    # Memory-efficient data loading
    "LazyGeneExpressionDataLoader",
    "load_data_lazy",
    "ConditionBatch",
    # Results
    "EvaluationResult",
    "SplitResult", 
    "ConditionResult",
    # Base metrics
    "BaseMetric",
    "MetricResult",
    "DistributionMetric",
    "CorrelationMetric",
    # Correlation metrics
    "PearsonCorrelation",
    "SpearmanCorrelation",
    "MeanPearsonCorrelation",
    "MeanSpearmanCorrelation",
    # Distance metrics
    "Wasserstein1Distance",
    "Wasserstein2Distance",
    "MMDDistance",
    "EnergyDistance",
    "MultivariateWasserstein",
    "MultivariateMMD",
    # Reconstruction metrics
    "MSEDistance",
    "RMSEDistance",
    "MAEDistance",
    "R2Score",
    # Acceleration
    "AccelerationConfig",
    "ParallelMetricComputer",
    "get_available_backends",
    "compute_metrics_accelerated",
    # Visualization
    "EvaluationVisualizer",
    "visualize",
    # Testing utilities
    "MockDataGenerator",
    "MockMetricData",
    "create_test_data",
    # Legacy
    "GeneExpressionDataModule",
]