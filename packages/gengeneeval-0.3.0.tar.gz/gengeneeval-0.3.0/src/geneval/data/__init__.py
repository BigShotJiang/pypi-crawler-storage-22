"""
Data loading module for gene expression evaluation.

Provides data loaders for paired real and generated datasets.
Includes both standard and memory-efficient lazy loading options.
"""

from .loader import (
    GeneExpressionDataLoader,
    load_data,
    DataLoaderError,
)
from .lazy_loader import (
    LazyGeneExpressionDataLoader,
    load_data_lazy,
    LazyDataLoaderError,
    ConditionBatch,
)
from .gene_expression_datamodule import (
    GeneExpressionDataModule,
    DataModuleError,
)

__all__ = [
    # Standard loader
    "GeneExpressionDataLoader",
    "load_data",
    "DataLoaderError",
    # Lazy loader (memory-efficient)
    "LazyGeneExpressionDataLoader",
    "load_data_lazy",
    "LazyDataLoaderError",
    "ConditionBatch",
    # DataModule
    "GeneExpressionDataModule",
    "DataModuleError",
]