"""
Reconstruction metrics for gene expression evaluation.

Provides MSE (Mean Squared Error) and related reconstruction quality metrics.
"""
from __future__ import annotations

import numpy as np
from typing import Optional

from .base_metric import BaseMetric


def _ensure_2d(arr: np.ndarray) -> np.ndarray:
    """Ensure array is 2D (samples x genes)."""
    arr = np.asarray(arr, dtype=np.float64)
    if arr.ndim == 1:
        arr = arr.reshape(-1, 1)
    return arr


class MSEDistance(BaseMetric):
    """
    Mean Squared Error (MSE) between real and generated distributions.
    
    Computes the average squared difference between samples. When sample
    sizes differ, compares mean expression profiles.
    
    Lower values indicate better reconstruction.
    
    Parameters
    ----------
    compare_means : bool
        If True, always compare mean profiles regardless of sample sizes.
        If False, compute sample-wise MSE when sizes match.
        
    Examples
    --------
    >>> mse = MSEDistance()
    >>> result = mse.compute(real_data, generated_data, gene_names)
    >>> print(f"MSE: {result.aggregate_value:.4f}")
    """
    
    def __init__(self, compare_means: bool = False):
        super().__init__(
            name="mse",
            description="Mean Squared Error per gene",
            higher_is_better=False,
            requires_distribution=True,
        )
        self.compare_means = compare_means
    
    def compute_per_gene(
        self,
        real: np.ndarray,
        generated: np.ndarray,
    ) -> np.ndarray:
        """
        Compute MSE for each gene.
        
        Parameters
        ----------
        real : np.ndarray
            Real data, shape (n_samples_real, n_genes)
        generated : np.ndarray
            Generated data, shape (n_samples_gen, n_genes)
            
        Returns
        -------
        np.ndarray
            MSE per gene, shape (n_genes,)
        """
        real = _ensure_2d(real)
        generated = _ensure_2d(generated)
        n_genes = real.shape[1]
        
        mse = np.zeros(n_genes)
        
        # Compare mean profiles when sample sizes differ or compare_means is True
        if self.compare_means or real.shape[0] != generated.shape[0]:
            real_mean = np.mean(real, axis=0)
            gen_mean = np.mean(generated, axis=0)
            mse = (real_mean - gen_mean) ** 2
        else:
            # Sample-wise MSE when sizes match
            for i in range(n_genes):
                r_vals = real[:, i]
                g_vals = generated[:, i]
                
                # Filter NaN values
                valid = ~(np.isnan(r_vals) | np.isnan(g_vals))
                if not valid.any():
                    mse[i] = np.nan
                    continue
                
                mse[i] = np.mean((r_vals[valid] - g_vals[valid]) ** 2)
        
        return mse


class RMSEDistance(BaseMetric):
    """
    Root Mean Squared Error (RMSE) between real and generated distributions.
    
    Square root of MSE, in the same units as the original data.
    Lower values indicate better reconstruction.
    """
    
    def __init__(self, compare_means: bool = False):
        super().__init__(
            name="rmse",
            description="Root Mean Squared Error per gene",
            higher_is_better=False,
            requires_distribution=True,
        )
        self.compare_means = compare_means
        self._mse = MSEDistance(compare_means=compare_means)
    
    def compute_per_gene(
        self,
        real: np.ndarray,
        generated: np.ndarray,
    ) -> np.ndarray:
        """
        Compute RMSE for each gene.
        """
        mse = self._mse.compute_per_gene(real, generated)
        return np.sqrt(mse)


class MAEDistance(BaseMetric):
    """
    Mean Absolute Error (MAE) between real and generated distributions.
    
    More robust to outliers than MSE.
    Lower values indicate better reconstruction.
    """
    
    def __init__(self, compare_means: bool = False):
        super().__init__(
            name="mae",
            description="Mean Absolute Error per gene",
            higher_is_better=False,
            requires_distribution=True,
        )
        self.compare_means = compare_means
    
    def compute_per_gene(
        self,
        real: np.ndarray,
        generated: np.ndarray,
    ) -> np.ndarray:
        """
        Compute MAE for each gene.
        """
        real = _ensure_2d(real)
        generated = _ensure_2d(generated)
        n_genes = real.shape[1]
        
        mae = np.zeros(n_genes)
        
        if self.compare_means or real.shape[0] != generated.shape[0]:
            real_mean = np.mean(real, axis=0)
            gen_mean = np.mean(generated, axis=0)
            mae = np.abs(real_mean - gen_mean)
        else:
            for i in range(n_genes):
                r_vals = real[:, i]
                g_vals = generated[:, i]
                
                valid = ~(np.isnan(r_vals) | np.isnan(g_vals))
                if not valid.any():
                    mae[i] = np.nan
                    continue
                
                mae[i] = np.mean(np.abs(r_vals[valid] - g_vals[valid]))
        
        return mae


class R2Score(BaseMetric):
    """
    Coefficient of Determination (R²) between real and generated data.
    
    Measures the proportion of variance explained. Values close to 1
    indicate good fit, 0 means no better than mean prediction.
    
    Higher values indicate better reconstruction.
    """
    
    def __init__(self):
        super().__init__(
            name="r2",
            description="R² (coefficient of determination) per gene",
            higher_is_better=True,
            requires_distribution=True,
        )
    
    def compute_per_gene(
        self,
        real: np.ndarray,
        generated: np.ndarray,
    ) -> np.ndarray:
        """
        Compute R² for each gene.
        """
        real = _ensure_2d(real)
        generated = _ensure_2d(generated)
        n_genes = real.shape[1]
        
        r2 = np.zeros(n_genes)
        
        # R² only makes sense when sample sizes match
        if real.shape[0] != generated.shape[0]:
            # Fall back to using mean comparison
            real_mean = np.mean(real, axis=0)
            gen_mean = np.mean(generated, axis=0)
            
            ss_tot = np.var(real, axis=0) * real.shape[0]
            ss_res = (real_mean - gen_mean) ** 2
            
            with np.errstate(invalid='ignore', divide='ignore'):
                r2 = 1 - ss_res / (ss_tot / real.shape[0] + 1e-10)
            r2 = np.nan_to_num(r2, nan=0.0)
        else:
            for i in range(n_genes):
                r_vals = real[:, i]
                g_vals = generated[:, i]
                
                valid = ~(np.isnan(r_vals) | np.isnan(g_vals))
                if not valid.any():
                    r2[i] = np.nan
                    continue
                
                ss_tot = np.sum((r_vals[valid] - np.mean(r_vals[valid])) ** 2)
                ss_res = np.sum((r_vals[valid] - g_vals[valid]) ** 2)
                
                if ss_tot < 1e-10:
                    r2[i] = 1.0 if ss_res < 1e-10 else 0.0
                else:
                    r2[i] = 1 - ss_res / ss_tot
        
        return r2
