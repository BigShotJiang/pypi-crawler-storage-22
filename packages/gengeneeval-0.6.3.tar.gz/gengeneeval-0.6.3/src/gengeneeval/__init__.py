"""
GenEval: Comprehensive evaluation of generated gene expression data.

A modular, object-oriented framework for computing metrics between real
and generated gene expression datasets stored in AnnData (h5ad) format.

Features:
- Multiple distance and correlation metrics (per-gene and aggregate)
- Condition-based matching (perturbation, cell type, etc.)
- DEG-focused evaluation with per-context (covariate × perturbation) support
- Train/test split support
- Memory-efficient lazy loading for large datasets
- CPU parallelization and GPU acceleration
- Publication-quality visualizations
- Command-line interface

Quick Start:
    >>> from gengeneeval import evaluate
    >>> results = evaluate(
    ...     real_path="real.h5ad",
    ...     generated_path="generated.h5ad", 
    ...     condition_columns=["perturbation"],
    ...     output_dir="output/"
    ... )

DEG-Focused Evaluation:
    >>> from gengeneeval import evaluate_degs
    >>> results = evaluate_degs(
    ...     real_data, generated_data,
    ...     real_obs, generated_obs,
    ...     condition_columns=["cell_type", "perturbation"],
    ...     control_key="control",
    ...     deg_method="welch",
    ...     device="cuda",  # GPU acceleration
    ... )

Memory-Efficient Mode (for large datasets):
    >>> from gengeneeval import evaluate_lazy
    >>> results = evaluate_lazy(
    ...     real_path="real.h5ad",
    ...     generated_path="generated.h5ad",
    ...     condition_columns=["perturbation"],
    ...     batch_size=256,
    ...     use_backed=True,  # Memory-mapped access
    ... )

CLI Usage:
    $ gengeneeval --real real.h5ad --generated generated.h5ad \\
              --conditions perturbation cell_type --output results/
"""

__version__ = "0.6.1"
__author__ = "GenGeneEval Team"

# Main evaluation interface
from .evaluator import (
    evaluate,
    GeneEvalEvaluator,
    MetricRegistry,
)

# Memory-efficient evaluation
from .lazy_evaluator import (
    evaluate_lazy,
    MemoryEfficientEvaluator,
    StreamingEvaluationResult,
    ALL_METRICS,
    DEFAULT_METRICS,
)

# Data loading
from .data.loader import (
    GeneExpressionDataLoader,
    load_data,
)

# Robust h5ad loader (fallback for problematic files)
from .data.robust_loader import (
    load_h5ad_robust,
    load_paired_h5ad,
)

# Memory-efficient data loading
from .data.lazy_loader import (
    LazyGeneExpressionDataLoader,
    load_data_lazy,
    ConditionBatch,
)

# Results
from .results import (
    EvaluationResult,
    SplitResult,
    ConditionResult,
)

# Metrics
from .metrics.base_metric import (
    BaseMetric,
    MetricResult,
    DistributionMetric,
    CorrelationMetric,
)
from .metrics.correlation import (
    PearsonCorrelation,
    SpearmanCorrelation,
    MeanPearsonCorrelation,  # Deprecated: same as PearsonCorrelation
    MeanSpearmanCorrelation,  # Deprecated: same as SpearmanCorrelation
)
from .metrics.distances import (
    # Legacy per-gene metrics (deprecated)
    Wasserstein1Distance,
    Wasserstein2Distance,
    MMDDistance,
    EnergyDistance,
    MultivariateWasserstein,
    MultivariateMMD,
)
# NEW: Proper distributional metrics (compare full sample distributions)
from .metrics.distributional import (
    DistributionalWasserstein,
    DistributionalMMD,
    DistributionalEnergy,
    W1, W2, MMD, Energy,  # Factory functions
    get_distributional_metrics,  # Get all distributional metrics
    compute_all_distributional,  # Compute all at once
    get_available_devices,  # Check MPS/CUDA availability
    SpaceType,  # Type hint for space parameter
    DistributionalMetricConfig,  # Configuration dataclass
)
from .metrics.reconstruction import (
    MSEDistance,
    RMSEDistance,
    MAEDistance,
    R2Score,
)

# Accelerated computation
from .metrics.accelerated import (
    AccelerationConfig,
    ParallelMetricComputer,
    get_available_backends,
    compute_metrics_accelerated,
)

# DEG-focused evaluation
from .deg import (
    DEGEvaluator,
    DEGResult,
    DEGEvaluationResult,
    ContextEvaluator,
    ContextResult,
    compute_degs_fast,
    compute_degs_gpu,
    get_contexts,
    plot_deg_distributions,
    plot_context_heatmap,
    create_deg_report,
)
from .deg.evaluator import evaluate_degs

# Visualization
from .visualization.visualizer import (
    EvaluationVisualizer,
    visualize,
)

# Legacy support
from .data.gene_expression_datamodule import GeneExpressionDataModule

# Testing utilities (for users to generate test data)
from .testing import (
    MockDataGenerator,
    MockMetricData,
    create_test_data,
)

__all__ = [
    # Version
    "__version__",
    # Main API
    "evaluate",
    "GeneEvalEvaluator",
    "MetricRegistry",
    # Memory-efficient evaluation
    "evaluate_lazy",
    "MemoryEfficientEvaluator",
    "StreamingEvaluationResult",
    # Data loading
    "GeneExpressionDataLoader",
    "load_data",
    # Memory-efficient data loading
    "LazyGeneExpressionDataLoader",
    "load_data_lazy",
    "ConditionBatch",
    # Results
    "EvaluationResult",
    "SplitResult", 
    "ConditionResult",
    # Base metrics
    "BaseMetric",
    "MetricResult",
    "DistributionMetric",
    "CorrelationMetric",
    # Correlation metrics
    "PearsonCorrelation",
    "SpearmanCorrelation",
    "MeanPearsonCorrelation",
    "MeanSpearmanCorrelation",
    # Distance metrics
    "Wasserstein1Distance",
    "Wasserstein2Distance",
    "MMDDistance",
    "EnergyDistance",
    "MultivariateWasserstein",
    "MultivariateMMD",
    # Reconstruction metrics
    "MSEDistance",
    "RMSEDistance",
    "MAEDistance",
    "R2Score",
    # Acceleration
    "AccelerationConfig",
    "ParallelMetricComputer",
    "get_available_backends",
    "compute_metrics_accelerated",
    # DEG evaluation
    "DEGEvaluator",
    "DEGResult",
    "DEGEvaluationResult",
    "ContextEvaluator",
    "ContextResult",
    "compute_degs_fast",
    "compute_degs_gpu",
    "evaluate_degs",
    "get_contexts",
    "plot_deg_distributions",
    "plot_context_heatmap",
    "create_deg_report",
    # Visualization
    "EvaluationVisualizer",
    "visualize",
    # Testing utilities
    "MockDataGenerator",
    "MockMetricData",
    "create_test_data",
    # Legacy
    "GeneExpressionDataModule",
]