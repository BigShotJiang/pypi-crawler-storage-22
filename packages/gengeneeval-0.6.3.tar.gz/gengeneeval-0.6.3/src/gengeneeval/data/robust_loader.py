"""
Robust h5ad loader with fallback for problematic files.

Handles sparse matrices, compressed data, and metadata issues
that can cause standard anndata/scanpy loading to fail.
"""
from __future__ import annotations

from typing import Optional, Union
from pathlib import Path
import warnings
import numpy as np
import pandas as pd
from scipy import sparse

try:
    import anndata as ad
    import scanpy as sc
except ImportError:
    raise ImportError("anndata and scanpy required: pip install anndata scanpy")

try:
    import h5py
    HAS_H5PY = True
except ImportError:
    HAS_H5PY = False


def load_h5ad_robust(
    path: Union[str, Path],
    use_fallback: bool = True,
) -> ad.AnnData:
    """
    Load h5ad file with robust fallback for problematic files.
    
    First attempts standard scanpy loading. If that fails, uses
    h5py-based fallback that bypasses problematic metadata.
    
    Parameters
    ----------
    path : str or Path
        Path to h5ad file
    use_fallback : bool
        If True, use h5py fallback when scanpy fails
        
    Returns
    -------
    ad.AnnData
        Loaded AnnData object
        
    Notes
    -----
    The fallback loader:
    - Handles CSR/CSC sparse matrices
    - Handles categorical columns properly
    - Preserves original gene names when possible
    - Skips problematic uns metadata
    """
    path = Path(path)
    
    if not path.exists():
        raise FileNotFoundError(f"File not found: {path}")
    
    # Try standard loading first
    try:
        return sc.read_h5ad(path)
    except Exception as e:
        if not use_fallback:
            raise
        warnings.warn(
            f"Standard h5ad loading failed: {e}. "
            "Using robust fallback loader."
        )
    
    # Fallback using h5py
    if not HAS_H5PY:
        raise ImportError(
            "h5py required for robust loading fallback. "
            "Install with: pip install h5py"
        )
    
    return _load_h5ad_h5py(path)


def load_paired_h5ad(
    real_path: Union[str, Path],
    generated_path: Union[str, Path],
    assume_gene_order: bool = False,
) -> tuple:
    """
    Load paired real and generated h5ad files with gene alignment.
    
    Handles cases where gene names may differ between files.
    
    Parameters
    ----------
    real_path : str or Path
        Path to real data h5ad file
    generated_path : str or Path
        Path to generated data h5ad file
    assume_gene_order : bool
        If True and gene counts match but names differ, assume genes
        are in the same order and rename generated genes to match real.
        If False, raises an error when gene names don't match.
        
    Returns
    -------
    tuple[AnnData, AnnData]
        (real_adata, generated_adata) with aligned gene names
        
    Raises
    ------
    ValueError
        If gene names don't match and assume_gene_order is False,
        or if gene counts differ.
    """
    real = load_h5ad_robust(real_path)
    gen = load_h5ad_robust(generated_path)
    
    real_genes = set(real.var_names)
    gen_genes = set(gen.var_names)
    
    # Case 1: Perfect match
    if real_genes == gen_genes:
        return real, gen
    
    # Case 2: Partial overlap - find common genes
    common = real_genes & gen_genes
    if len(common) > 0:
        n_real_only = len(real_genes) - len(common)
        n_gen_only = len(gen_genes) - len(common)
        warnings.warn(
            f"Partial gene overlap: {len(common)} common genes. "
            f"Dropping {n_real_only} from real, {n_gen_only} from generated."
        )
        # Subset to common genes in same order
        common_list = sorted(common)
        real = real[:, common_list].copy()
        gen = gen[:, common_list].copy()
        return real, gen
    
    # Case 3: No overlap but same count - possibly same genes, different names
    if real.n_vars == gen.n_vars:
        if assume_gene_order:
            warnings.warn(
                f"Gene names don't match but counts are equal ({real.n_vars}). "
                f"Assuming genes are in the same order. "
                f"Real genes: {list(real.var_names[:3])}... "
                f"Generated genes: {list(gen.var_names[:3])}... "
                f"Renaming generated genes to match real."
            )
            gen.var_names = real.var_names.copy()
            return real, gen
        else:
            raise ValueError(
                f"Gene names don't match between files but counts are equal ({real.n_vars}). "
                f"Real genes: {list(real.var_names[:5])}... "
                f"Generated genes: {list(gen.var_names[:5])}... "
                f"If genes are in the same order, use assume_gene_order=True."
            )
    
    # Case 4: Different counts and no overlap - incompatible
    raise ValueError(
        f"Incompatible gene sets: real has {real.n_vars} genes, "
        f"generated has {gen.n_vars} genes, with no overlap. "
        f"Real genes: {list(real.var_names[:5])}... "
        f"Generated genes: {list(gen.var_names[:5])}..."
    )


def _load_h5ad_h5py(path: Path) -> ad.AnnData:
    """Load h5ad using h5py directly, bypassing problematic metadata."""
    with h5py.File(path, 'r') as f:
        # Load X matrix
        X = _load_X(f)
        
        # Load obs (cell metadata)
        obs = _load_obs(f, n_cells=X.shape[0])
        
        # Load var (gene metadata)
        var = _load_var(f, n_genes=X.shape[1])
        
        return ad.AnnData(X=X, obs=obs, var=var)


def _load_X(f: "h5py.File") -> Union[np.ndarray, sparse.csr_matrix]:
    """Load expression matrix from h5py file."""
    if 'X' not in f:
        raise ValueError("No 'X' key found in h5ad file")
    
    x_item = f['X']
    
    # Check if sparse (group with data/indices/indptr)
    if isinstance(x_item, h5py.Group):
        return _load_sparse_matrix(x_item)
    else:
        # Dense array
        return x_item[:]


def _load_sparse_matrix(group: "h5py.Group") -> sparse.csr_matrix:
    """Load sparse matrix from h5py group."""
    data = group['data'][:]
    indices = group['indices'][:]
    indptr = group['indptr'][:]
    
    # Get shape
    if 'shape' in group.attrs:
        shape = tuple(group.attrs['shape'])
    else:
        # Infer shape
        n_rows = len(indptr) - 1
        n_cols = int(indices.max()) + 1 if len(indices) > 0 else 0
        shape = (n_rows, n_cols)
    
    # Determine sparse format
    encoding = group.attrs.get('encoding-type', b'csr_matrix')
    if isinstance(encoding, bytes):
        encoding = encoding.decode()
    
    if 'csc' in encoding.lower():
        return sparse.csc_matrix((data, indices, indptr), shape=shape).tocsr()
    else:
        return sparse.csr_matrix((data, indices, indptr), shape=shape)


def _load_obs(f: "h5py.File", n_cells: int) -> pd.DataFrame:
    """Load obs DataFrame from h5py file."""
    if 'obs' not in f:
        return pd.DataFrame(index=[str(i) for i in range(n_cells)])
    
    obs_group = f['obs']
    obs_dict = {}
    
    for key in obs_group.keys():
        if key.startswith('_'):
            continue
        
        item = obs_group[key]
        
        try:
            if isinstance(item, h5py.Group):
                # Categorical column
                if 'categories' in item and 'codes' in item:
                    cats = _decode_strings(item['categories'][:])
                    codes = item['codes'][:]
                    obs_dict[key] = pd.Categorical.from_codes(codes, categories=cats)
                else:
                    continue
            elif isinstance(item, h5py.Dataset):
                vals = item[:]
                if vals.dtype.kind in ('S', 'O', 'U'):
                    vals = _decode_strings(vals)
                obs_dict[key] = vals
        except Exception as e:
            warnings.warn(f"Could not load obs column '{key}': {e}")
    
    # Get index
    index = _get_index(obs_group, n_cells)
    
    return pd.DataFrame(obs_dict, index=index)


def _load_var(f: "h5py.File", n_genes: int) -> pd.DataFrame:
    """Load var DataFrame from h5py file."""
    if 'var' not in f:
        # No var group - use positional indices
        return pd.DataFrame(index=[f'gene_{i}' for i in range(n_genes)])
    
    var_group = f['var']
    var_dict = {}
    
    for key in var_group.keys():
        if key.startswith('_'):
            continue
        
        item = var_group[key]
        
        try:
            if isinstance(item, h5py.Group):
                if 'categories' in item and 'codes' in item:
                    cats = _decode_strings(item['categories'][:])
                    codes = item['codes'][:]
                    var_dict[key] = pd.Categorical.from_codes(codes, categories=cats)
            elif isinstance(item, h5py.Dataset):
                vals = item[:]
                if vals.dtype.kind in ('S', 'O', 'U'):
                    vals = _decode_strings(vals)
                var_dict[key] = vals
        except Exception:
            pass
    
    # Get index (gene names) - try to preserve original names
    index = _get_index(var_group, n_genes, default_prefix='gene_')
    
    return pd.DataFrame(var_dict, index=index)


def _get_index(
    group: "h5py.Group",
    n: int,
    default_prefix: str = ''
) -> pd.Index:
    """Get index from h5py group."""
    # Try _index key
    if '_index' in group:
        try:
            idx = group['_index'][:]
            return pd.Index(_decode_strings(idx))
        except Exception:
            pass
    
    # Try index key
    if 'index' in group:
        try:
            idx = group['index'][:]
            return pd.Index(_decode_strings(idx))
        except Exception:
            pass
    
    # Default numeric index
    return pd.Index([f'{default_prefix}{i}' for i in range(n)])


def _decode_strings(arr: np.ndarray) -> np.ndarray:
    """Decode byte strings to unicode."""
    if arr.dtype.kind == 'S':
        return np.array([s.decode('utf-8') if isinstance(s, bytes) else s for s in arr])
    elif arr.dtype.kind == 'O':
        return np.array([s.decode('utf-8') if isinstance(s, bytes) else str(s) for s in arr])
    return arr
