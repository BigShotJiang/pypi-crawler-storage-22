"""
Differentially Expressed Genes (DEG) module for GenGeneEval.

This module provides:
- Fast DEG detection using vectorized statistical tests
- Per-context evaluation (covariates × perturbations)
- DEG-focused metrics computation
- Integration with GPU acceleration

Example usage:
    >>> from gengeneeval.deg import DEGEvaluator, compute_degs_fast
    >>> degs = compute_degs_fast(control_data, perturbed_data, method="welch")
    >>> evaluator = DEGEvaluator(loader, deg_method="welch", pval_threshold=0.05)
    >>> results = evaluator.evaluate()
"""

from .detection import (
    compute_degs_fast,
    compute_degs_gpu,
    compute_degs_auto,
    DEGResult,
    DEGMethod,
)
from .context import (
    ContextEvaluator,
    ContextResult,
    get_contexts,
    get_context_id,
    filter_by_context,
)
from .evaluator import (
    DEGEvaluator,
    DEGEvaluationResult,
    DEGSettings,
    ContextMetrics,
    evaluate_degs,
)
from .visualization import (
    plot_deg_distributions,
    plot_context_heatmap,
    plot_deg_counts,
    create_deg_report,
)

__all__ = [
    # Detection
    "compute_degs_fast",
    "compute_degs_gpu",
    "compute_degs_auto",
    "DEGResult",
    "DEGMethod",
    # Context
    "ContextEvaluator",
    "ContextResult",
    "get_contexts",
    "get_context_id",
    "filter_by_context",
    # Evaluator
    "DEGEvaluator",
    "DEGEvaluationResult",
    "DEGSettings",
    "ContextMetrics",
    "evaluate_degs",
    # Visualization
    "plot_deg_distributions",
    "plot_context_heatmap",
    "plot_deg_counts",
    "create_deg_report",
]
