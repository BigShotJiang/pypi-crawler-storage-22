"""
Visualization module for DEG evaluation results.

Provides:
- Distribution plots for metrics across contexts
- Heatmaps for context × metric results
- Comprehensive DEG reports
"""
from __future__ import annotations

from typing import Optional, List, Dict, Union, Any, TYPE_CHECKING
from pathlib import Path
import numpy as np

if TYPE_CHECKING:
    import matplotlib.pyplot as plt
    import pandas as pd
    from .evaluator import DEGEvaluationResult


def _check_matplotlib():
    """Check if matplotlib is available."""
    try:
        import matplotlib.pyplot as plt
        return plt
    except ImportError:
        raise ImportError("matplotlib is required for visualization. Install with: pip install matplotlib")


def _check_seaborn():
    """Check if seaborn is available."""
    try:
        import seaborn as sns
        return sns
    except ImportError:
        return None  # Seaborn is optional


def plot_deg_distributions(
    results: "DEGEvaluationResult",
    metrics: Optional[List[str]] = None,
    figsize: tuple = (12, 4),
    save_path: Optional[Union[str, Path]] = None,
    show: bool = True,
) -> "plt.Figure":
    """
    Plot distribution of metrics across contexts.
    
    Creates violin/box plots showing metric distributions across all contexts.
    
    Parameters
    ----------
    results : DEGEvaluationResult
        DEG evaluation results
    metrics : List[str], optional
        Metrics to plot. If None, plots all available.
    figsize : tuple
        Figure size per metric
    save_path : str or Path, optional
        Path to save figure
    show : bool
        Whether to display the figure
        
    Returns
    -------
    plt.Figure
        Matplotlib figure
    """
    plt = _check_matplotlib()
    sns = _check_seaborn()
    
    df = results.expanded_metrics
    
    if metrics is None:
        # Get all numeric columns that are metrics
        metrics = [c for c in df.columns if c in results.settings.get("metrics", [])]
    
    if len(metrics) == 0:
        raise ValueError("No metrics to plot")
    
    n_metrics = len(metrics)
    fig, axes = plt.subplots(1, n_metrics, figsize=(figsize[0], figsize[1]))
    
    if n_metrics == 1:
        axes = [axes]
    
    for ax, metric in zip(axes, metrics):
        values = df[metric].dropna()
        
        if sns is not None:
            sns.violinplot(y=values, ax=ax, inner="box")
        else:
            ax.boxplot(values, vert=True)
        
        ax.set_title(metric)
        ax.set_ylabel("Value")
        
        # Add mean annotation
        mean_val = values.mean()
        ax.axhline(mean_val, color='red', linestyle='--', alpha=0.5, label=f'Mean: {mean_val:.3f}')
        ax.legend(loc='upper right', fontsize=8)
    
    plt.suptitle("Metric Distributions Across Contexts (DEGs only)", y=1.02)
    plt.tight_layout()
    
    if save_path:
        fig.savefig(save_path, dpi=150, bbox_inches='tight')
    
    if show:
        plt.show()
    
    return fig


def plot_context_heatmap(
    results: "DEGEvaluationResult",
    metrics: Optional[List[str]] = None,
    figsize: tuple = (12, 8),
    cmap: str = "RdYlBu_r",
    save_path: Optional[Union[str, Path]] = None,
    show: bool = True,
) -> "plt.Figure":
    """
    Plot heatmap of metrics across contexts.
    
    Parameters
    ----------
    results : DEGEvaluationResult
        DEG evaluation results
    metrics : List[str], optional
        Metrics to include
    figsize : tuple
        Figure size
    cmap : str
        Colormap name
    save_path : str or Path, optional
        Path to save figure
    show : bool
        Whether to display
        
    Returns
    -------
    plt.Figure
        Matplotlib figure
    """
    plt = _check_matplotlib()
    sns = _check_seaborn()
    
    df = results.expanded_metrics
    
    if metrics is None:
        metrics = [c for c in df.columns if c in results.settings.get("metrics", [])]
    
    # Create matrix for heatmap
    heatmap_data = df.set_index("context_id")[metrics]
    
    fig, ax = plt.subplots(figsize=figsize)
    
    if sns is not None:
        sns.heatmap(
            heatmap_data,
            ax=ax,
            cmap=cmap,
            annot=True,
            fmt=".3f",
            cbar_kws={"label": "Metric Value"},
        )
    else:
        im = ax.imshow(heatmap_data.values, cmap=cmap, aspect='auto')
        plt.colorbar(im, ax=ax, label="Metric Value")
        ax.set_xticks(range(len(metrics)))
        ax.set_xticklabels(metrics, rotation=45, ha='right')
        ax.set_yticks(range(len(heatmap_data)))
        ax.set_yticklabels(heatmap_data.index)
    
    ax.set_title("Metrics per Context (DEGs only)")
    ax.set_xlabel("Metric")
    ax.set_ylabel("Context")
    
    plt.tight_layout()
    
    if save_path:
        fig.savefig(save_path, dpi=150, bbox_inches='tight')
    
    if show:
        plt.show()
    
    return fig


def plot_deg_counts(
    results: "DEGEvaluationResult",
    figsize: tuple = (10, 6),
    save_path: Optional[Union[str, Path]] = None,
    show: bool = True,
) -> "plt.Figure":
    """
    Plot DEG counts per context.
    
    Parameters
    ----------
    results : DEGEvaluationResult
        DEG evaluation results
    figsize : tuple
        Figure size
    save_path : str or Path, optional
        Path to save figure
    show : bool
        Whether to display
        
    Returns
    -------
    plt.Figure
        Matplotlib figure
    """
    plt = _check_matplotlib()
    
    df = results.deg_summary
    
    if len(df) == 0:
        raise ValueError("No DEG data to plot")
    
    fig, ax = plt.subplots(figsize=figsize)
    
    x = range(len(df))
    width = 0.35
    
    if "n_upregulated" in df.columns and "n_downregulated" in df.columns:
        ax.bar(x, df["n_upregulated"], width, label='Upregulated', color='red', alpha=0.7)
        ax.bar(x, -df["n_downregulated"], width, label='Downregulated', color='blue', alpha=0.7)
        ax.axhline(0, color='black', linewidth=0.5)
        ax.set_ylabel("Number of DEGs")
    else:
        ax.bar(x, df["n_degs"], color='purple', alpha=0.7)
        ax.set_ylabel("Number of DEGs")
    
    ax.set_xlabel("Context")
    ax.set_xticks(x)
    ax.set_xticklabels(df["context_id"], rotation=45, ha='right')
    ax.set_title("DEG Counts per Context")
    ax.legend()
    
    plt.tight_layout()
    
    if save_path:
        fig.savefig(save_path, dpi=150, bbox_inches='tight')
    
    if show:
        plt.show()
    
    return fig


def create_deg_report(
    results: "DEGEvaluationResult",
    output_dir: Union[str, Path],
    include_plots: bool = True,
) -> None:
    """
    Create a comprehensive DEG evaluation report.
    
    Creates:
    - Summary statistics (CSV)
    - Aggregated metrics (CSV)
    - Expanded per-context metrics (CSV)
    - DEG summary per context (CSV)
    - Visualization plots (PNG, if include_plots=True)
    - Markdown report
    
    Parameters
    ----------
    results : DEGEvaluationResult
        DEG evaluation results
    output_dir : str or Path
        Output directory
    include_plots : bool
        Whether to generate plots
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Save CSVs
    results.save(output_dir)
    
    # Generate plots
    if include_plots:
        try:
            plt = _check_matplotlib()
            
            # Distribution plot
            if len(results.expanded_metrics) > 0:
                plot_deg_distributions(
                    results,
                    save_path=output_dir / "deg_metric_distributions.png",
                    show=False,
                )
                plt.close()
                
                # Heatmap
                plot_context_heatmap(
                    results,
                    save_path=output_dir / "deg_context_heatmap.png",
                    show=False,
                )
                plt.close()
            
            # DEG counts
            if len(results.deg_summary) > 0:
                plot_deg_counts(
                    results,
                    save_path=output_dir / "deg_counts.png",
                    show=False,
                )
                plt.close()
                
        except ImportError:
            pass  # Skip plots if matplotlib not available
    
    # Create markdown report
    report_lines = [
        "# DEG Evaluation Report",
        "",
        "## Summary",
        "",
        f"- **Number of contexts evaluated**: {len(results.context_results)}",
        f"- **DEG detection method**: {results.settings.get('deg_method', 'N/A')}",
        f"- **P-value threshold**: {results.settings.get('pval_threshold', 'N/A')}",
        f"- **Log fold change threshold**: {results.settings.get('lfc_threshold', 'N/A')}",
        f"- **Compute device**: {results.settings.get('device', 'N/A')}",
        "",
        "## Aggregated Metrics",
        "",
    ]
    
    if len(results.aggregated_metrics) > 0:
        for col in results.aggregated_metrics.columns:
            val = results.aggregated_metrics[col].iloc[0]
            if isinstance(val, float):
                report_lines.append(f"- **{col}**: {val:.4f}")
            else:
                report_lines.append(f"- **{col}**: {val}")
    else:
        report_lines.append("No aggregated metrics available.")
    
    report_lines.extend([
        "",
        "## DEG Summary",
        "",
    ])
    
    if len(results.deg_summary) > 0:
        report_lines.append(results.deg_summary.to_markdown(index=False))
    else:
        report_lines.append("No DEG data available.")
    
    report_lines.extend([
        "",
        "## Files Generated",
        "",
        "- `deg_aggregated_metrics.csv`: Summary metrics across all contexts",
        "- `deg_expanded_metrics.csv`: Per-context metrics",
        "- `deg_summary.csv`: DEG detection summary",
        "- `deg_per_context/`: Individual DEG results per context",
    ])
    
    if include_plots:
        report_lines.extend([
            "- `deg_metric_distributions.png`: Distribution plots",
            "- `deg_context_heatmap.png`: Context × metric heatmap",
            "- `deg_counts.png`: DEG counts per context",
        ])
    
    with open(output_dir / "DEG_REPORT.md", "w") as f:
        f.write("\n".join(report_lines))
    
    print(f"DEG report saved to {output_dir}")
