"""
Memory-efficient evaluator for large-scale gene expression datasets.

Uses lazy loading and batched processing to minimize memory footprint.
"""
from __future__ import annotations

from typing import Dict, List, Optional, Union, Type, Any, Generator
from pathlib import Path
import numpy as np
import warnings
from dataclasses import dataclass, field
import gc
import json

from .data.lazy_loader import (
    LazyGeneExpressionDataLoader,
    load_data_lazy,
    ConditionBatch,
)
from .metrics.base_metric import BaseMetric, MetricResult
from .metrics.correlation import (
    PearsonCorrelation,
    SpearmanCorrelation,
    MeanPearsonCorrelation,
    MeanSpearmanCorrelation,
)
from .metrics.reconstruction import (
    MSEDistance,
    RMSEDistance,
    MAEDistance,
)
# NEW: Proper distributional metrics (compare full sample distributions)
from .metrics.distributional import (
    DistributionalWasserstein,
    DistributionalMMD,
    DistributionalEnergy,
    W1, W2, MMD, Energy,
    get_distributional_metrics,
    SpaceType,
    get_no_deg_conditions,  # Track conditions with no DEGs
)


# Recommended metrics for comprehensive evaluation
# - Correlation metrics: Compare mean expression profiles (1×G vectors)
# - Distributional metrics: Compare full sample distributions (n×G matrices)
ALL_METRICS = [
    # Correlation on mean expression (correct usage)
    PearsonCorrelation,
    SpearmanCorrelation,
    # Reconstruction on mean expression
    MSEDistance,
    RMSEDistance,
    MAEDistance,
]

# Default metrics (balanced set) - distributional metrics added at runtime
DEFAULT_METRICS = [
    PearsonCorrelation,
    SpearmanCorrelation,
    MSEDistance,
    DistributionalWasserstein,
]

# Metrics that support incremental/batched computation
BATCHABLE_METRICS = [
    MSEDistance,
    PearsonCorrelation,
    SpearmanCorrelation,
]

# Distributional metrics (require full sample data, GPU accelerated)
DISTRIBUTIONAL_METRICS = [
    DistributionalWasserstein,
    DistributionalMMD,
    DistributionalEnergy,
]


@dataclass
class StreamingMetricAccumulator:
    """Accumulates values for streaming mean/std computation."""
    n: int = 0
    sum: float = 0.0
    sum_sq: float = 0.0
    values: List[float] = field(default_factory=list)
    
    def add(self, value: float, count: int = 1):
        """Add a value (or batch of values with same value)."""
        self.n += count
        self.sum += value * count
        self.sum_sq += (value ** 2) * count
        self.values.append(value)
    
    def add_batch(self, values: np.ndarray):
        """Add multiple values."""
        self.n += len(values)
        self.sum += np.sum(values)
        self.sum_sq += np.sum(values ** 2)
    
    @property
    def mean(self) -> float:
        return self.sum / self.n if self.n > 0 else 0.0
    
    @property
    def std(self) -> float:
        if self.n <= 1:
            return 0.0
        variance = (self.sum_sq / self.n) - (self.mean ** 2)
        return np.sqrt(max(0, variance))


@dataclass
class StreamingConditionResult:
    """Lightweight result for a single condition."""
    condition_key: str
    n_real_samples: int = 0
    n_generated_samples: int = 0
    metrics: Dict[str, float] = field(default_factory=dict)
    real_mean: Optional[np.ndarray] = None
    generated_mean: Optional[np.ndarray] = None


@dataclass
class StreamingEvaluationResult:
    """Memory-efficient evaluation result that streams to disk."""
    output_dir: Path
    n_conditions: int = 0
    metric_accumulators: Dict[str, StreamingMetricAccumulator] = field(default_factory=dict)
    condition_keys: List[str] = field(default_factory=list)
    
    def add_condition(self, result: StreamingConditionResult):
        """Add a condition result and update accumulators."""
        self.n_conditions += 1
        self.condition_keys.append(result.condition_key)
        
        for metric_name, value in result.metrics.items():
            if metric_name not in self.metric_accumulators:
                self.metric_accumulators[metric_name] = StreamingMetricAccumulator()
            self.metric_accumulators[metric_name].add(value)
    
    def get_summary(self) -> Dict[str, Dict[str, float]]:
        """Get summary statistics."""
        summary = {}
        for name, acc in self.metric_accumulators.items():
            summary[name] = {
                "mean": acc.mean,
                "std": acc.std,
                "n": acc.n,
            }
        return summary
    
    def save_summary(self):
        """Save summary to output directory."""
        import json
        
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        summary = {
            "n_conditions": self.n_conditions,
            "metrics": self.get_summary(),
            "condition_keys": self.condition_keys,
        }
        
        with open(self.output_dir / "summary.json", "w") as f:
            json.dump(summary, f, indent=2)


class MemoryEfficientEvaluator:
    """
    Memory-efficient evaluator using lazy loading and batched processing.
    
    Features:
    - Lazy data loading (one condition at a time)
    - Batched processing within conditions
    - Streaming metric accumulation
    - Periodic garbage collection
    - Progress streaming to disk
    
    Parameters
    ----------
    data_loader : LazyGeneExpressionDataLoader
        Lazy data loader
    metrics : List[BaseMetric], optional
        Metrics to compute. Note: Some metrics (like MMD) may not support
        batched computation and will use full condition data.
    batch_size : int
        Batch size for within-condition processing
    gc_every_n_conditions : int
        Run garbage collection every N conditions
    verbose : bool
        Print progress
    """
    
    def __init__(
        self,
        data_loader: LazyGeneExpressionDataLoader,
        metrics: Optional[List[Union[BaseMetric, Type[BaseMetric]]]] = None,
        batch_size: int = 256,
        gc_every_n_conditions: int = 10,
        verbose: bool = True,
    ):
        self.data_loader = data_loader
        self.batch_size = batch_size
        self.gc_every_n_conditions = gc_every_n_conditions
        self.verbose = verbose
        
        # Initialize metrics
        self.metrics: List[BaseMetric] = []
        metric_classes = metrics or [
            MSEDistance,
            PearsonCorrelation,
            SpearmanCorrelation,
            MeanPearsonCorrelation,
            MeanSpearmanCorrelation,
        ]
        
        for m in metric_classes:
            if isinstance(m, type):
                self.metrics.append(m())
            else:
                self.metrics.append(m)
    
    def _log(self, msg: str):
        if self.verbose:
            print(msg)
    
    def evaluate(
        self,
        split: Optional[str] = None,
        output_dir: Optional[Union[str, Path]] = None,
        save_per_condition: bool = False,
    ) -> StreamingEvaluationResult:
        """
        Run memory-efficient evaluation.
        
        Parameters
        ----------
        split : str, optional
            Split to evaluate
        output_dir : str or Path, optional
            Directory to save results. If provided, results are streamed to disk.
        save_per_condition : bool
            If True, save individual condition results to disk
            
        Returns
        -------
        StreamingEvaluationResult
            Evaluation result with aggregated metrics
        """
        if output_dir is not None:
            output_dir = Path(output_dir)
            output_dir.mkdir(parents=True, exist_ok=True)
        else:
            output_dir = Path(".")
        
        result = StreamingEvaluationResult(output_dir=output_dir)
        
        # Get conditions
        conditions = self.data_loader.get_common_conditions(split)
        self._log(f"Evaluating {len(conditions)} conditions")
        self._log(f"Memory estimate: {self.data_loader.estimate_memory_usage()}")
        
        # Iterate conditions (one at a time in memory)
        for i, (cond_key, real_data, gen_data, cond_info) in enumerate(
            self.data_loader.iterate_conditions(split)
        ):
            if self.verbose and (i + 1) % 10 == 0:
                self._log(f"  Processing {i + 1}/{len(conditions)}: {cond_key}")
            
            # Compute metrics for this condition
            cond_result = self._evaluate_condition(
                cond_key, real_data, gen_data, cond_info
            )
            
            # Add to streaming result
            result.add_condition(cond_result)
            
            # Optionally save per-condition result
            if save_per_condition and output_dir:
                self._save_condition_result(cond_result, output_dir)
            
            # Periodic garbage collection
            if (i + 1) % self.gc_every_n_conditions == 0:
                gc.collect()
        
        # Final summary
        result.save_summary()
        
        if self.verbose:
            self._print_summary(result)
        
        # Generate visualizations
        if output_dir:
            self._generate_plots(result, output_dir)
        
        return result
    
    def _evaluate_condition(
        self,
        cond_key: str,
        real_data: np.ndarray,
        gen_data: np.ndarray,
        cond_info: Dict[str, str],
    ) -> StreamingConditionResult:
        """Evaluate a single condition."""
        result = StreamingConditionResult(
            condition_key=cond_key,
            n_real_samples=real_data.shape[0],
            n_generated_samples=gen_data.shape[0],
        )
        
        # Compute means
        result.real_mean = real_data.mean(axis=0)
        result.generated_mean = gen_data.mean(axis=0)
        
        # Get control data for DEG computation (if available)
        control_data = self.data_loader.control_data
        
        # Compute metrics
        for metric in self.metrics:
            try:
                # Pass cache_key for DEG caching and control_data for proper DEG detection
                metric_result = metric.compute(
                    real=real_data,
                    generated=gen_data,
                    gene_names=self.data_loader.gene_names,
                    aggregate_method="mean",
                    condition=cond_key,
                    cache_key=cond_key,  # Use condition key for DEG caching
                    control_data=control_data,  # Control cells for proper DEG computation
                )
                # Handle None result (e.g., no DEGs found for DEG-space metrics)
                if metric_result is not None:
                    result.metrics[metric.name] = metric_result.aggregate_value
            except Exception as e:
                warnings.warn(f"Failed to compute {metric.name} for {cond_key}: {e}")
        
        return result
    
    def _save_condition_result(
        self,
        result: StreamingConditionResult,
        output_dir: Path,
    ):
        """Save a single condition result to disk."""
        condition_dir = output_dir / "conditions"
        condition_dir.mkdir(exist_ok=True)
        
        # Safe filename
        safe_key = result.condition_key.replace("/", "_").replace("\\", "_")
        
        data = {
            "condition_key": result.condition_key,
            "n_real": result.n_real_samples,
            "n_generated": result.n_generated_samples,
            "metrics": result.metrics,
        }
        
        with open(condition_dir / f"{safe_key}.json", "w") as f:
            json.dump(data, f, indent=2)
    
    def _print_summary(self, result: StreamingEvaluationResult):
        """Print summary table."""
        summary = result.get_summary()
        
        # Build table
        self._log("\n" + "=" * 70)
        self._log("EVALUATION RESULTS")
        self._log("=" * 70)
        self._log(f"  Conditions evaluated: {result.n_conditions}")
        
        # Report conditions with no DEGs (if any)
        no_deg_conditions = get_no_deg_conditions()
        if no_deg_conditions:
            self._log(f"  Conditions with no DEGs: {len(no_deg_conditions)} (see no_deg_conditions.txt)")
        
        self._log("-" * 70)
        self._log(f"  {'Metric':<25} {'Mean':>12} {'Std':>12} {'Min':>10} {'Max':>10}")
        self._log("-" * 70)
        
        for name, acc in result.metric_accumulators.items():
            if acc.values:
                min_val = min(acc.values)
                max_val = max(acc.values)
            else:
                min_val = max_val = acc.mean
            
            self._log(
                f"  {name:<25} {acc.mean:>12.4f} {acc.std:>12.4f} "
                f"{min_val:>10.4f} {max_val:>10.4f}"
            )
        
        self._log("=" * 70)
    
    def _generate_plots(self, result: StreamingEvaluationResult, output_dir: Path):
        """Generate evaluation plots with standardized scales and CSV output."""
        try:
            import matplotlib.pyplot as plt
            import pandas as pd
        except ImportError:
            warnings.warn("matplotlib/pandas required for plots")
            return
        
        # Load per-condition data
        cond_dir = output_dir / "conditions"
        if not cond_dir.exists():
            return
        
        data = []
        for f in cond_dir.glob("*.json"):
            with open(f) as fp:
                data.append(json.load(fp))
        
        if not data:
            return
        
        df = pd.DataFrame([d['metrics'] for d in data])
        df['condition'] = [d['condition_key'] for d in data]
        df['n_real'] = [d.get('n_real', 0) for d in data]
        df['n_generated'] = [d.get('n_generated', 0) for d in data]
        
        # =====================================================================
        # SAVE CSV OUTPUT
        # =====================================================================
        csv_path = output_dir / "metrics.csv"
        df.to_csv(csv_path, index=False)
        self._log(f"Metrics CSV saved to: {csv_path}")
        
        # Also save summary CSV
        summary = result.get_summary()
        summary_rows = []
        for name, stats in summary.items():
            summary_rows.append({
                "metric": name,
                "mean": stats["mean"],
                "std": stats["std"],
                "n": stats["n"],
            })
        summary_df = pd.DataFrame(summary_rows)
        summary_df.to_csv(output_dir / "metrics_summary.csv", index=False)
        
        # Save no-DEG conditions list (if any)
        no_deg_conditions = get_no_deg_conditions()
        if no_deg_conditions:
            no_deg_path = output_dir / "no_deg_conditions.txt"
            with open(no_deg_path, 'w') as f:
                f.write(f"# Conditions with no differentially expressed genes found\n")
                f.write(f"# Total: {len(no_deg_conditions)} conditions\n")
                f.write(f"# These conditions were skipped for DEG-space metrics\n\n")
                for cond in sorted(no_deg_conditions):
                    f.write(f"{cond}\n")
            self._log(f"No-DEG conditions list: {no_deg_path}")
        
        # =====================================================================
        # STANDARDIZED PLOTS
        # =====================================================================
        metric_cols = [c for c in df.columns if c not in ['condition', 'n_real', 'n_generated']]
        
        if not metric_cols:
            return
            
        # Classify metrics by type for proper scaling
        correlation_metrics = [c for c in metric_cols if any(x in c.lower() for x in ['pearson', 'spearman', 'r2'])]
        distance_metrics = [c for c in metric_cols if any(x in c.lower() for x in ['w1', 'w2', 'mmd', 'energy', 'mse', 'rmse', 'mae'])]
        
        # 1. STANDARDIZED BAR PLOT - All metrics on comparable [0,1] scale
        try:
            import seaborn as sns
            
            # Compute standardized values and keep track of original
            standardized_data = []
            for col in metric_cols:
                values = df[col].dropna()
                if len(values) == 0:
                    continue
                    
                mean_val = values.mean()
                std_val = values.std()
                
                # Determine if higher is better
                higher_is_better = col in correlation_metrics
                
                # Standardize to [0, 1] where 1 = best
                if higher_is_better:
                    # Correlation: already ~[0,1], clamp
                    std_mean = max(0, min(1, mean_val))
                else:
                    # Distance: lower is better, use 1/(1+x) transform
                    std_mean = 1 / (1 + mean_val)
                
                standardized_data.append({
                    "metric": col,
                    "standardized": std_mean,
                    "original_mean": mean_val,
                    "original_std": std_val,
                    "higher_is_better": higher_is_better,
                })
            
            if standardized_data:
                std_df = pd.DataFrame(standardized_data)
                
                # Create figure with two subplots
                fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))
                
                # Left: Standardized bar plot (0-1 scale, higher = better)
                colors = ['#2ecc71' if row['higher_is_better'] else '#3498db' 
                         for _, row in std_df.iterrows()]
                bars = ax1.barh(std_df['metric'], std_df['standardized'], color=colors, alpha=0.8)
                ax1.set_xlim(0, 1)
                ax1.set_xlabel("Standardized Score (higher = better)")
                ax1.set_title("Metrics Comparison (Standardized Scale)")
                ax1.axvline(x=0.5, color='gray', linestyle='--', alpha=0.5)
                
                # Add original values as annotations
                for i, (_, row) in enumerate(std_df.iterrows()):
                    ax1.annotate(
                        f"  {row['original_mean']:.3f} ± {row['original_std']:.3f}",
                        xy=(row['standardized'], i),
                        va='center', ha='left', fontsize=8, color='gray'
                    )
                
                # Right: Legend explaining the transformation
                ax2.axis('off')
                legend_text = """
METRIC INTERPRETATION
━━━━━━━━━━━━━━━━━━━━━

GREEN bars: Correlation metrics (higher = better)
  • Standardized = clamp(value, 0, 1)
  • Example: Pearson 0.85 → 0.85

BLUE bars: Distance metrics (lower = better)  
  • Standardized = 1 / (1 + value)
  • Example: W2 = 0.5 → 0.67
  • Example: W2 = 2.0 → 0.33

Original values shown next to bars as:
  mean ± std

SPACE SUFFIXES:
  • _pca50: PCA-reduced (50 components)
  • _raw: Original gene space
  • _deg_welch: DEG subset (Welch's t-test)
"""
                ax2.text(0.1, 0.9, legend_text, transform=ax2.transAxes,
                        fontsize=10, verticalalignment='top', fontfamily='monospace',
                        bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
                
                plt.tight_layout()
                fig.savefig(output_dir / "metrics_standardized.png", dpi=150)
                fig.savefig(output_dir / "metrics_standardized.pdf")
                plt.close()
        except Exception as e:
            warnings.warn(f"Failed to create standardized plot: {e}")
        
        # 2. Combined violin/strip plot showing all metric distributions
        try:
            import seaborn as sns
            
            # Melt data for grouped plotting
            plot_data = []
            for col in metric_cols:
                values = df[col].dropna()
                higher_is_better = col in correlation_metrics
                for v in values:
                    plot_data.append({
                        'Metric': col,
                        'Value': v,
                        'Type': 'Correlation' if higher_is_better else 'Distance'
                    })
            
            if plot_data:
                plot_df = pd.DataFrame(plot_data)
                
                # Group metrics by type for better visualization
                corr_df = plot_df[plot_df['Type'] == 'Correlation']
                dist_df = plot_df[plot_df['Type'] == 'Distance']
                
                # Create figure with two subplots
                fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))
                
                # Correlation metrics (higher is better)
                if len(corr_df) > 0:
                    sns.violinplot(data=corr_df, x='Metric', y='Value', ax=ax1, 
                                   inner=None, color='lightgreen', alpha=0.6)
                    sns.stripplot(data=corr_df, x='Metric', y='Value', ax=ax1,
                                  size=3, alpha=0.6, color='darkgreen')
                    ax1.set_title('Correlation Metrics (higher = better)', fontsize=11)
                    ax1.set_xlabel('')
                    ax1.set_ylim(-0.1, 1.1)
                    ax1.axhline(y=1.0, color='green', linestyle='--', alpha=0.3, label='Perfect')
                    ax1.axhline(y=0.0, color='red', linestyle='--', alpha=0.3, label='No correlation')
                    ax1.tick_params(axis='x', rotation=45)
                    
                    # Add mean annotations
                    for i, metric in enumerate(corr_df['Metric'].unique()):
                        mean_val = corr_df[corr_df['Metric'] == metric]['Value'].mean()
                        ax1.annotate(f'μ={mean_val:.2f}', xy=(i, mean_val), 
                                     xytext=(5, 0), textcoords='offset points',
                                     fontsize=8, color='darkgreen', fontweight='bold')
                else:
                    ax1.text(0.5, 0.5, 'No correlation metrics', ha='center', va='center')
                    ax1.set_title('Correlation Metrics')
                
                # Distance metrics (lower is better)
                if len(dist_df) > 0:
                    sns.violinplot(data=dist_df, x='Metric', y='Value', ax=ax2,
                                   inner=None, color='lightblue', alpha=0.6)
                    sns.stripplot(data=dist_df, x='Metric', y='Value', ax=ax2,
                                  size=3, alpha=0.6, color='darkblue')
                    ax2.set_title('Distance Metrics (lower = better)', fontsize=11)
                    ax2.set_xlabel('')
                    ax2.axhline(y=0.0, color='green', linestyle='--', alpha=0.3, label='Perfect')
                    ax2.tick_params(axis='x', rotation=45)
                    
                    # Add mean annotations
                    for i, metric in enumerate(dist_df['Metric'].unique()):
                        mean_val = dist_df[dist_df['Metric'] == metric]['Value'].mean()
                        ax2.annotate(f'μ={mean_val:.2f}', xy=(i, mean_val),
                                     xytext=(5, 0), textcoords='offset points',
                                     fontsize=8, color='darkblue', fontweight='bold')
                else:
                    ax2.text(0.5, 0.5, 'No distance metrics', ha='center', va='center')
                    ax2.set_title('Distance Metrics')
                
                plt.suptitle('Metric Distributions Across Conditions', fontsize=12, fontweight='bold')
                plt.tight_layout()
                fig.savefig(output_dir / "metric_distributions.png", dpi=150)
                fig.savefig(output_dir / "metric_distributions.pdf")
                plt.close()
        except Exception as e:
            warnings.warn(f"Failed to create distribution plot: {e}")
        
        # 3. Correlation heatmap
        if len(metric_cols) > 2:
            try:
                import seaborn as sns
                fig, ax = plt.subplots(figsize=(10, 8))
                corr_matrix = df[metric_cols].corr()
                sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', center=0, ax=ax, fmt='.2f')
                ax.set_title("Metric Correlation Matrix")
                plt.tight_layout()
                fig.savefig(output_dir / "metric_correlation.png", dpi=150)
                fig.savefig(output_dir / "metric_correlation.pdf")
                plt.close()
            except Exception:
                pass
        
        # 4. Per-condition heatmap (top N conditions) - STANDARDIZED
        n_show = min(30, len(df))
        if n_show > 5:
            try:
                import seaborn as sns
                df_sorted = df.sort_values('condition')
                df_plot = df_sorted.head(n_show).set_index('condition')[metric_cols].copy()
                
                # Standardize each column
                for col in df_plot.columns:
                    higher_is_better = col in correlation_metrics
                    if higher_is_better:
                        df_plot[col] = df_plot[col].clip(0, 1)
                    else:
                        df_plot[col] = 1 / (1 + df_plot[col])
                
                fig, ax = plt.subplots(figsize=(12, max(6, n_show * 0.3)))
                sns.heatmap(df_plot, annot=False, cmap='RdYlGn', vmin=0, vmax=1, ax=ax)
                ax.set_title(f"Metrics by Condition (Standardized, top {n_show})\n(Green = Good, Red = Poor)")
                plt.tight_layout()
                fig.savefig(output_dir / "condition_heatmap.png", dpi=150)
                fig.savefig(output_dir / "condition_heatmap.pdf")
                plt.close()
            except Exception:
                pass
        
        self._log(f"\nPlots saved to: {output_dir}")


def evaluate_lazy(
    real_path: Union[str, Path],
    generated_path: Union[str, Path],
    condition_columns: List[str],
    split_column: Optional[str] = None,
    output_dir: Optional[Union[str, Path]] = None,
    batch_size: int = 256,
    use_backed: bool = False,
    metrics: Optional[List[Union[BaseMetric, Type[BaseMetric]]]] = None,
    verbose: bool = True,
    save_per_condition: bool = False,
    control_key: Optional[str] = None,
    **kwargs
) -> StreamingEvaluationResult:
    """
    Memory-efficient evaluation using lazy loading.
    
    Use this function for large datasets that don't fit in memory.
    
    Parameters
    ----------
    real_path : str or Path
        Path to real data h5ad file
    generated_path : str or Path
        Path to generated data h5ad file
    condition_columns : List[str]
        Columns to match between datasets
    split_column : str, optional
        Column for train/test split
    output_dir : str or Path, optional
        Directory to save results
    batch_size : int
        Batch size for processing
    use_backed : bool
        Use memory-mapped file access (for very large files)
    metrics : List, optional
        Metrics to compute. If None, uses default metrics.
        Pass ALL_METRICS for comprehensive evaluation.
    verbose : bool
        Print progress
    save_per_condition : bool
        Save individual condition results
    control_key : str, optional
        String identifying control cells (e.g., "ctrl", "control", "NT").
        REQUIRED for proper DEG-space metrics. When provided, DEGs are computed
        by comparing control cells vs perturbed cells in the real data.
        If not provided, DEG metrics fall back to comparing real vs generated.
        
    Returns
    -------
    StreamingEvaluationResult
        Aggregated evaluation results
        
    Examples
    --------
    >>> # For large datasets with proper DEG computation
    >>> results = evaluate_lazy(
    ...     "real.h5ad",
    ...     "generated.h5ad",
    ...     condition_columns=["perturbation"],
    ...     output_dir="eval_output/",
    ...     control_key="ctrl",  # Cells containing "ctrl" are control cells
    ...     metrics=[
    ...         PearsonCorrelation(space="deg"),  # Now works properly!
    ...         W1(space="pca"),
    ...     ],
    ... )
    >>> print(results.get_summary())
    """
    # Create lazy loader
    with load_data_lazy(
        real_path=real_path,
        generated_path=generated_path,
        condition_columns=condition_columns,
        split_column=split_column,
        batch_size=batch_size,
        use_backed=use_backed,
        control_key=control_key,
    ) as loader:
        # Create evaluator
        evaluator = MemoryEfficientEvaluator(
            data_loader=loader,
            metrics=metrics,
            batch_size=batch_size,
            verbose=verbose,
        )
        
        # Run evaluation
        return evaluator.evaluate(
            output_dir=output_dir,
            save_per_condition=save_per_condition,
        )
