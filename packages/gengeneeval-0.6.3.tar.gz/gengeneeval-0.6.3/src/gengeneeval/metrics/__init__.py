"""
Metrics module for gene expression evaluation.

All metrics support multiple computation spaces:
- raw: Original gene expression space  
- pca: PCA-reduced latent space (recommended for stability)
- deg: Differentially expressed genes only (biologically relevant)

Metrics:
- Reconstruction metrics (MSE, RMSE, MAE, R²)
- Correlation metrics (Pearson, Spearman)
- Distributional metrics (W1, W2, MMD, Energy) - compare full sample distributions
"""

from .base_metric import (
    BaseMetric,
    MetricResult,
    DistributionMetric,
    CorrelationMetric,
)

# Space utilities (shared across all metrics)
from .space_utils import (
    SpaceType,
    DEGMethodType,
    apply_space_transform,
    apply_pca,
    compute_deg_indices,
    apply_deg_filter,
    make_metric_name,
    # DEG cache management
    clear_deg_cache,
    get_deg_cache,
    set_deg_cache,
    get_no_deg_conditions,
)

from .correlation import (
    PearsonCorrelation,
    SpearmanCorrelation,
    MeanPearsonCorrelation,
    MeanSpearmanCorrelation,
)
from .reconstruction import (
    MSEDistance,
    RMSEDistance,
    MAEDistance,
    R2Score,
)

# Simple aliases for reconstruction metrics
MSE = MSEDistance
RMSE = RMSEDistance
MAE = MAEDistance
R2 = R2Score

# Primary distributional metrics (proper multivariate comparison)
from .distributional import (
    # Main metric classes
    DistributionalWasserstein,
    DistributionalMMD,
    DistributionalEnergy,
    # Factory functions (preferred interface)
    W1, W2, MMD, Energy,
    # Utilities
    get_distributional_metrics,
    compute_all_distributional,
    get_available_devices,
    DistributionalMetricConfig,
)

# Legacy per-gene distance metrics (kept for backward compatibility)
from .distances import (
    Wasserstein1Distance,
    Wasserstein2Distance,
    MMDDistance,
    EnergyDistance,
    MultivariateWasserstein,
    MultivariateMMD,
)

# Accelerated computation
from .accelerated import (
    AccelerationConfig,
    ParallelMetricComputer,
    get_available_backends,
    compute_metrics_accelerated,
    GPUWasserstein1,
    GPUWasserstein2,
    GPUMMD,
    GPUEnergyDistance,
    vectorized_wasserstein1,
    vectorized_mmd,
)

# Recommended metrics for comprehensive evaluation
ALL_METRICS = [
    PearsonCorrelation,
    SpearmanCorrelation,
    MSE,
    RMSE,
    MAE,
    # Use factory functions for distributional metrics:
    # W1(), W2(), MMD(), Energy()
]

__all__ = [
    # Base classes
    "BaseMetric",
    "MetricResult",
    "DistributionMetric",
    "CorrelationMetric",
    # Reconstruction metrics (full names)
    "MSEDistance",
    "RMSEDistance",
    "MAEDistance",
    "R2Score",
    # Reconstruction metrics (simple aliases - preferred)
    "MSE",
    "RMSE",
    "MAE",
    "R2",
    # Correlation metrics
    "PearsonCorrelation",
    "SpearmanCorrelation",
    "MeanPearsonCorrelation",
    "MeanSpearmanCorrelation",
    # Distributional metrics (multivariate) - RECOMMENDED
    "DistributionalWasserstein",
    "DistributionalMMD",
    "DistributionalEnergy",
    "W1", "W2", "MMD", "Energy",  # Factory functions (preferred)
    "get_distributional_metrics",
    "compute_all_distributional",
    "get_available_devices",
    "DistributionalMetricConfig",
    "SpaceType",
    "DEGMethodType",
    # DEG cache management
    "clear_deg_cache",
    "get_deg_cache",
    "set_deg_cache",
    "get_no_deg_conditions",
    # Legacy per-gene metrics (backward compatibility)
    "Wasserstein1Distance",
    "Wasserstein2Distance",
    "MMDDistance",
    "EnergyDistance",
    "MultivariateWasserstein",
    "MultivariateMMD",
    # Collections
    "ALL_METRICS",
    # Acceleration
    "AccelerationConfig",
    "ParallelMetricComputer",
    "get_available_backends",
    "compute_metrics_accelerated",
    "GPUWasserstein1",
    "GPUWasserstein2",
    "GPUMMD",
    "GPUEnergyDistance",
    "vectorized_wasserstein1",
    "vectorized_mmd",
]