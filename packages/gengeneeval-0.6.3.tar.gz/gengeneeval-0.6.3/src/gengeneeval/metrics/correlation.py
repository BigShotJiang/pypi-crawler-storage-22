"""
Correlation metrics for gene expression evaluation.

Provides Pearson and Spearman correlation metrics with optional space transformations.
All metrics can compute in raw, PCA, or DEG space.

When using DEG space with control_data:
- Computes correlation of PERTURBATION EFFECTS (delta from control)
- This measures whether the model captures the biological effect of perturbation
- More meaningful than raw expression correlation for perturbation modeling
"""
from __future__ import annotations

import numpy as np
from scipy.stats import pearsonr, spearmanr
from typing import Optional, List

from .base_metric import BaseMetric, MetricResult, CorrelationMetric
from .space_utils import (
    SpaceType, DEGMethodType, apply_space_transform, make_metric_name
)


def _compute_pearson_single(
    real: np.ndarray, 
    generated: np.ndarray,
    control: Optional[np.ndarray] = None,
) -> float:
    """
    Compute single Pearson correlation between mean profiles.
    
    Parameters
    ----------
    real : np.ndarray
        Real expression data (n_samples, n_features)
    generated : np.ndarray
        Generated expression data (n_samples, n_features)
    control : np.ndarray, optional
        Control expression data. If provided, computes correlation of 
        perturbation effects (delta from control) rather than raw expression.
        
    Returns
    -------
    float
        Pearson correlation coefficient
    """
    real_mean = np.mean(real, axis=0)
    gen_mean = np.mean(generated, axis=0)
    
    # If control provided, compute perturbation effects
    if control is not None:
        ctrl_mean = np.mean(control, axis=0)
        real_mean = real_mean - ctrl_mean
        gen_mean = gen_mean - ctrl_mean
    
    # Need at least 2 features for correlation
    if len(real_mean) < 2:
        return np.nan
    
    if np.std(real_mean) == 0 or np.std(gen_mean) == 0:
        return np.nan
    
    corr, _ = pearsonr(real_mean, gen_mean)
    return corr


def _compute_spearman_single(
    real: np.ndarray, 
    generated: np.ndarray,
    control: Optional[np.ndarray] = None,
) -> float:
    """
    Compute single Spearman correlation between mean profiles.
    
    Parameters
    ----------
    real : np.ndarray
        Real expression data (n_samples, n_features)
    generated : np.ndarray
        Generated expression data (n_samples, n_features)
    control : np.ndarray, optional
        Control expression data. If provided, computes correlation of 
        perturbation effects (delta from control) rather than raw expression.
        
    Returns
    -------
    float
        Spearman correlation coefficient
    """
    real_mean = np.mean(real, axis=0)
    gen_mean = np.mean(generated, axis=0)
    
    # If control provided, compute perturbation effects
    if control is not None:
        ctrl_mean = np.mean(control, axis=0)
        real_mean = real_mean - ctrl_mean
        gen_mean = gen_mean - ctrl_mean
    
    # Need at least 2 features for correlation
    if len(real_mean) < 2:
        return np.nan
    
    if np.std(real_mean) == 0 or np.std(gen_mean) == 0:
        return np.nan
    
    corr, _ = spearmanr(real_mean, gen_mean)
    return corr


class PearsonCorrelation(BaseMetric):
    """
    Pearson correlation coefficient between real and generated gene expression.
    
    Supports computation in different spaces:
    - raw: Original gene expression space (default)
    - pca: PCA-reduced latent space  
    - deg: Differentially expressed genes only
    
    Parameters
    ----------
    space : str
        Computation space: "raw", "pca", or "deg"
    n_pca_components : int
        Number of PCA components (only for space="pca")
    deg_method : str
        DEG detection method (only for space="deg")
    deg_pval : float
        P-value threshold for DEG detection
    deg_lfc : float
        Log fold change threshold for DEG detection
        
    Examples
    --------
    >>> # Raw space (default)
    >>> pearson = PearsonCorrelation()
    
    >>> # PCA space
    >>> pearson_pca = PearsonCorrelation(space="pca", n_pca_components=50)
    
    >>> # DEG space
    >>> pearson_deg = PearsonCorrelation(space="deg", deg_method="welch")
    """
    
    def __init__(
        self,
        space: SpaceType = "raw",
        n_pca_components: int = 50,
        deg_method: DEGMethodType = "welch",
        deg_pval: float = 0.05,
        deg_lfc: float = 0.5,
    ):
        self.space = space
        self.n_pca_components = n_pca_components
        self.deg_method = deg_method
        self.deg_pval = deg_pval
        self.deg_lfc = deg_lfc
        
        name = make_metric_name("pearson", space, n_pca_components, deg_method)
        
        super().__init__(
            name=name,
            description=f"Pearson correlation coefficient ({space} space)",
            higher_is_better=True,
        )
    
    def compute_per_gene(
        self,
        real: np.ndarray,
        generated: np.ndarray,
    ) -> np.ndarray:
        """Compute Pearson correlation (for backward compatibility)."""
        real = np.atleast_2d(real)
        generated = np.atleast_2d(generated)
        n_genes = real.shape[1]
        
        corr = _compute_pearson_single(real, generated)
        return np.full(n_genes, corr)
    
    def compute(
        self,
        real: np.ndarray,
        generated: np.ndarray,
        gene_names: Optional[List[str]] = None,
        cache_key: Optional[str] = None,
        control_data: Optional[np.ndarray] = None,
        **kwargs,
    ) -> Optional[MetricResult]:
        """
        Compute Pearson correlation with space transformation.
        
        Parameters
        ----------
        real : np.ndarray
            Real expression data
        generated : np.ndarray
            Generated expression data
        gene_names : list, optional
            Gene names
        cache_key : str, optional
            Cache key for DEG results
        control_data : np.ndarray, optional
            Control cells for proper DEG computation. When provided with space="deg",
            computes correlation of perturbation effects (delta from control).
            
        Returns None if space="deg" and no DEGs found.
        """
        # Apply space transformation
        real_proj, gen_proj, n_features, has_data, space_info, control_proj = apply_space_transform(
            real=np.atleast_2d(real),
            generated=np.atleast_2d(generated),
            space=self.space,
            n_pca_components=self.n_pca_components,
            deg_method=self.deg_method,
            deg_pval=self.deg_pval,
            deg_lfc=self.deg_lfc,
            cache_key=cache_key,
            control_data=control_data,
        )
        
        if not has_data:
            return None  # No DEGs found
        
        # Compute correlation (pass control for computing perturbation effects in DEG space)
        corr = _compute_pearson_single(real_proj, gen_proj, control=control_proj)
        
        n_genes = real.shape[1] if real.ndim > 1 else 1
        if gene_names is None:
            gene_names = [f"gene_{i}" for i in range(n_genes)]
        
        return MetricResult(
            name=self.name,
            per_gene_values=np.full(n_genes, corr),
            gene_names=gene_names,
            aggregate_value=float(corr),
            aggregate_method="correlation",
            metadata={
                "higher_is_better": True,
                "n_features": n_features,
                **space_info,
            }
        )


class SpearmanCorrelation(BaseMetric):
    """
    Spearman rank correlation between real and generated gene expression.
    
    More robust to outliers than Pearson. Measures monotonic relationship.
    
    Supports computation in different spaces:
    - raw: Original gene expression space (default)
    - pca: PCA-reduced latent space  
    - deg: Differentially expressed genes only
    
    Parameters
    ----------
    space : str
        Computation space: "raw", "pca", or "deg"
    n_pca_components : int
        Number of PCA components (only for space="pca")
    deg_method : str
        DEG detection method (only for space="deg")
    deg_pval : float
        P-value threshold for DEG detection
    deg_lfc : float
        Log fold change threshold for DEG detection
    """
    
    def __init__(
        self,
        space: SpaceType = "raw",
        n_pca_components: int = 50,
        deg_method: DEGMethodType = "welch",
        deg_pval: float = 0.05,
        deg_lfc: float = 0.5,
    ):
        self.space = space
        self.n_pca_components = n_pca_components
        self.deg_method = deg_method
        self.deg_pval = deg_pval
        self.deg_lfc = deg_lfc
        
        name = make_metric_name("spearman", space, n_pca_components, deg_method)
        
        super().__init__(
            name=name,
            description=f"Spearman rank correlation ({space} space)",
            higher_is_better=True,
        )
    
    def compute_per_gene(
        self,
        real: np.ndarray,
        generated: np.ndarray,
    ) -> np.ndarray:
        """Compute Spearman correlation (for backward compatibility)."""
        real = np.atleast_2d(real)
        generated = np.atleast_2d(generated)
        n_genes = real.shape[1]
        
        corr = _compute_spearman_single(real, generated)
        return np.full(n_genes, corr)
    
    def compute(
        self,
        real: np.ndarray,
        generated: np.ndarray,
        gene_names: Optional[List[str]] = None,
        cache_key: Optional[str] = None,
        control_data: Optional[np.ndarray] = None,
        **kwargs,
    ) -> Optional[MetricResult]:
        """
        Compute Spearman correlation with space transformation.
        
        Parameters
        ----------
        real : np.ndarray
            Real expression data
        generated : np.ndarray
            Generated expression data
        gene_names : list, optional
            Gene names
        cache_key : str, optional
            Cache key for DEG results
        control_data : np.ndarray, optional
            Control cells for proper DEG computation. When provided with space="deg",
            computes correlation of perturbation effects (delta from control).
            
        Returns None if space="deg" and no DEGs found.
        """
        # Apply space transformation
        real_proj, gen_proj, n_features, has_data, space_info, control_proj = apply_space_transform(
            real=np.atleast_2d(real),
            generated=np.atleast_2d(generated),
            space=self.space,
            n_pca_components=self.n_pca_components,
            deg_method=self.deg_method,
            deg_pval=self.deg_pval,
            deg_lfc=self.deg_lfc,
            cache_key=cache_key,
            control_data=control_data,
        )
        
        if not has_data:
            return None  # No DEGs found
        
        # Compute correlation (pass control for computing perturbation effects in DEG space)
        corr = _compute_spearman_single(real_proj, gen_proj, control=control_proj)
        
        n_genes = real.shape[1] if real.ndim > 1 else 1
        if gene_names is None:
            gene_names = [f"gene_{i}" for i in range(n_genes)]
        
        return MetricResult(
            name=self.name,
            per_gene_values=np.full(n_genes, corr),
            gene_names=gene_names,
            aggregate_value=float(corr),
            aggregate_method="correlation",
            metadata={
                "higher_is_better": True,
                "n_features": n_features,
                **space_info,
            }
        )


class MeanPearsonCorrelation(CorrelationMetric):
    """
    Pearson correlation on mean expression profiles.
    
    Computes mean expression per gene, then correlates the profiles.
    Returns single value replicated across genes.
    
    Note: For space-aware correlation, use PearsonCorrelation(space=...).
    """
    
    def __init__(self):
        super().__init__(
            name="mean_pearson",
            description="Pearson correlation on mean expression profiles"
        )
    
    def compute_per_gene(
        self,
        real: np.ndarray,
        generated: np.ndarray,
    ) -> np.ndarray:
        """Compute correlation between mean profiles."""
        real = np.atleast_2d(real)
        generated = np.atleast_2d(generated)
        n_genes = real.shape[1]
        
        corr = _compute_pearson_single(real, generated)
        return np.full(n_genes, corr)


class MeanSpearmanCorrelation(CorrelationMetric):
    """
    Spearman correlation on mean expression profiles.
    
    Note: For space-aware correlation, use SpearmanCorrelation(space=...).
    """
    
    def __init__(self):
        super().__init__(
            name="mean_spearman",
            description="Spearman correlation on mean expression profiles"
        )
    
    def compute_per_gene(
        self,
        real: np.ndarray,
        generated: np.ndarray,
    ) -> np.ndarray:
        """Compute Spearman correlation between mean profiles."""
        real = np.atleast_2d(real)
        generated = np.atleast_2d(generated)
        n_genes = real.shape[1]
        
        corr = _compute_spearman_single(real, generated)
        return np.full(n_genes, corr)

