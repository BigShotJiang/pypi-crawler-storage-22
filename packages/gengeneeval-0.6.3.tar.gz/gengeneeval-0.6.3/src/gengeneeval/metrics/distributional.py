"""
Proper distributional distance metrics for gene expression evaluation.

These metrics compare FULL SAMPLE DISTRIBUTIONS (n_samples × n_features matrices),
not per-gene 1D distributions or aggregated means.

Methodology:
- Compute in raw gene expression space OR latent (PCA) space OR DEG subspace
- Use geomloss for GPU-accelerated optimal transport (supports MPS/CUDA)
- Compare distribution of points, not point-to-point

This is the correct way to compute distributional distances:
- W1/W2: Compare distributions of samples in expression/PCA/DEG space
- MMD/Energy: Kernel-based distribution comparison

Space Options:
- "raw": Compute in original gene expression space (high-dimensional)
- "pca": Compute in PCA-reduced latent space (recommended for stability)
- "deg": Compute on differentially expressed genes only

References:
- geomloss documentation: https://www.kernel-operations.io/geomloss/
"""
from __future__ import annotations

import numpy as np
import warnings
from typing import Optional, Literal, Union, Dict, Tuple, Any, List
from dataclasses import dataclass, field

from .base_metric import BaseMetric, MetricResult

# Import shared space utilities (all space processing is centralized here)
from .space_utils import (
    SpaceType,
    DEGMethodType,
    apply_space_transform,
    apply_pca as _apply_pca,
    compute_deg_indices as _compute_deg_indices,
    apply_deg_filter as _apply_deg_filter,
    make_metric_name,
    # DEG cache management (re-export for backward compatibility)
    clear_deg_cache,
    get_deg_cache,
    set_deg_cache,
    get_no_deg_conditions,
)


# Check for optional dependencies
try:
    import torch
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False
    
try:
    from geomloss import SamplesLoss
    HAS_GEOMLOSS = True
except ImportError:
    HAS_GEOMLOSS = False


def _get_device(device_str: str = "auto") -> "torch.device":
    """Get best available device (MPS > CUDA > CPU).
    
    Parameters
    ----------
    device_str : str
        Device specification: "auto", "mps", "cuda", "cpu"
        
    Returns
    -------
    torch.device
        The selected device
    """
    if not HAS_TORCH:
        raise ImportError("PyTorch required for distributional metrics")
    
    if device_str == "auto":
        if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
            return torch.device("mps")
        elif torch.cuda.is_available():
            return torch.device("cuda")
        else:
            return torch.device("cpu")
    return torch.device(device_str)


def get_available_devices() -> dict:
    """Check which compute devices are available.
    
    Returns
    -------
    dict
        Dictionary with device availability: {"cpu": True, "cuda": bool, "mps": bool}
    """
    if not HAS_TORCH:
        return {"cpu": True, "cuda": False, "mps": False}
    
    return {
        "cpu": True,
        "cuda": torch.cuda.is_available(),
        "mps": hasattr(torch.backends, "mps") and torch.backends.mps.is_available(),
    }


@dataclass
class DistributionalMetricConfig:
    """Configuration for distributional metric computation.
    
    Attributes
    ----------
    space : str
        Computation space: "raw" for gene expression, "pca" for latent, "deg" for DEG subset
    n_pca_components : int
        Number of PCA components (only used if space="pca")
    device : str
        Compute device: "auto", "mps", "cuda", "cpu"
    blur : float
        Sinkhorn regularization parameter
    deg_method : str
        DEG detection method (only used if space="deg")
    deg_pval : float
        P-value threshold for DEG detection
    deg_lfc : float
        Log fold change threshold for DEG detection
    """
    space: SpaceType = "pca"
    n_pca_components: int = 50
    device: str = "auto"
    blur: float = 0.01
    deg_method: DEGMethodType = "welch"
    deg_pval: float = 0.05
    deg_lfc: float = 0.5
    
    def __post_init__(self):
        if self.space not in ("raw", "pca", "deg"):
            raise ValueError(f"space must be 'raw', 'pca', or 'deg', got {self.space}")


class DistributionalWasserstein(BaseMetric):
    """
    Wasserstein distance between sample distributions.
    
    Computes optimal transport distance between two point clouds
    in gene expression space, PCA-reduced latent space, or DEG subset.
    
    This is the CORRECT way to compute Wasserstein for gene expression:
    - Takes full sample matrices (n × G)
    - Computes in raw, PCA, or DEG space
    - Uses geomloss for GPU-accelerated Sinkhorn
    
    Parameters
    ----------
    p : int
        Order of Wasserstein distance (1 or 2)
    blur : float
        Sinkhorn regularization (lower = more accurate, slower)
    space : str
        Computation space: "raw", "pca", or "deg"
    n_pca_components : int
        Number of PCA components (only used if space="pca")
    device : str
        Compute device ("auto", "mps", "cuda", "cpu")
    deg_method : str
        DEG detection method: "welch", "student", "wilcoxon", "logfc"
    deg_pval : float
        P-value threshold for DEG detection
    deg_lfc : float
        Log fold change threshold for DEG detection
        
    Examples
    --------
    >>> # Compute W2 in PCA space (recommended)
    >>> w2_pca = DistributionalWasserstein(p=2, space="pca", n_pca_components=50)
    >>> result = w2_pca.compute(real_data, generated_data)
    
    >>> # Compute W1 on DEGs only
    >>> w1_deg = DistributionalWasserstein(p=1, space="deg", deg_method="welch")
    >>> result = w1_deg.compute(real_data, generated_data)
    """
    
    def __init__(
        self,
        p: int = 2,
        blur: float = 0.01,
        space: SpaceType = "pca",
        n_pca_components: int = 50,
        device: str = "auto",
        deg_method: DEGMethodType = "welch",
        deg_pval: float = 0.05,
        deg_lfc: float = 0.5,
    ):
        self.p = p
        self.blur = blur
        self.space = space
        self.n_pca_components = n_pca_components
        self.device_str = device
        self.deg_method = deg_method
        self.deg_pval = deg_pval
        self.deg_lfc = deg_lfc
        
        # Create descriptive name including space and method
        if space == "pca":
            name = f"W{p}_pca{n_pca_components}"
        elif space == "deg":
            name = f"W{p}_deg_{deg_method}"
        else:
            name = f"W{p}_raw"
            
        super().__init__(
            name=name,
            description=f"Wasserstein-{p} distance ({space} space)",
            higher_is_better=False,
        )
        
        if not HAS_GEOMLOSS:
            warnings.warn("geomloss not installed. Install with: pip install geomloss")
    
    def compute(
        self,
        real: np.ndarray,
        generated: np.ndarray,
        gene_names: Optional[list] = None,
        cache_key: Optional[str] = None,
        control_data: Optional[np.ndarray] = None,
        **kwargs,
    ) -> MetricResult:
        """
        Compute Wasserstein distance between sample distributions.
        
        Parameters
        ----------
        real : np.ndarray
            Real samples (n_real, n_genes)
        generated : np.ndarray
            Generated samples (n_gen, n_genes)
        gene_names : list, optional
            Gene names for metadata
        cache_key : str, optional
            Key for DEG caching (only used if space="deg")
        control_data : np.ndarray, optional
            Control cells for proper DEG computation
            
        Returns
        -------
        MetricResult or None
            Distance value (lower = more similar distributions)
            Returns None if space="deg" and no DEGs found (condition skipped)
        """
        if not HAS_GEOMLOSS or not HAS_TORCH:
            raise ImportError("geomloss and torch required. Install: pip install geomloss torch")
        
        real = np.asarray(real, dtype=np.float32)
        generated = np.asarray(generated, dtype=np.float32)
        
        # Apply space transformation
        if self.space == "pca":
            real_proj, gen_proj, n_features = _apply_pca(
                real, generated, self.n_pca_components
            )
            space_info = {"n_pca_components": self.n_pca_components}
        elif self.space == "deg":
            # Compute DEG indices (with caching)
            deg_indices = _compute_deg_indices(
                control=real,
                perturbed=generated,
                method=self.deg_method,
                pval_threshold=self.deg_pval,
                lfc_threshold=self.deg_lfc,
                cache_key=cache_key,
                control_data=control_data,
            )
            real_proj, gen_proj, n_features, has_degs = _apply_deg_filter(
                real, generated, deg_indices, cache_key=cache_key
            )
            if not has_degs:
                return None  # Skip this condition
            space_info = {
                "deg_method": self.deg_method,
                "deg_pval": self.deg_pval,
                "deg_lfc": self.deg_lfc,
                "n_degs": n_features,
            }
        else:
            real_proj = real
            gen_proj = generated
            n_features = real.shape[1]
            space_info = {}
        
        # Get device
        device = _get_device(self.device_str)
        
        # Convert to tensors
        real_tensor = torch.tensor(real_proj, device=device)
        gen_tensor = torch.tensor(gen_proj, device=device)
        
        # Compute Wasserstein
        loss_fn = SamplesLoss(
            loss="sinkhorn",
            p=self.p,
            blur=self.blur,
            backend="tensorized",
        )
        
        distance = loss_fn(real_tensor, gen_tensor).item()
        
        return MetricResult(
            name=self.name,
            aggregate_value=distance,
            per_gene_values=np.full(real.shape[1], distance),
            gene_names=gene_names if gene_names else [f"gene_{i}" for i in range(real.shape[1])],
            aggregate_method="distributional",
            metadata={
                "n_real_samples": real.shape[0],
                "n_generated_samples": generated.shape[0],
                "n_features": n_features,
                "space": self.space,
                "device": str(device),
                "p": self.p,
                "blur": self.blur,
                **space_info,
            }
        )
    
    def compute_per_gene(self, real: np.ndarray, generated: np.ndarray) -> np.ndarray:
        """Not applicable for distributional metrics."""
        result = self.compute(real, generated)
        return np.full(real.shape[1], result.aggregate_value)


class DistributionalMMD(BaseMetric):
    """
    Maximum Mean Discrepancy between sample distributions.
    
    Kernel-based distance comparing distributions via RKHS embeddings.
    Uses Gaussian kernel with configurable bandwidth.
    
    Parameters
    ----------
    blur : float
        Kernel bandwidth (sigma for Gaussian kernel)
    space : str
        Computation space: "raw", "pca", or "deg"
    n_pca_components : int
        Number of PCA components (only used if space="pca")
    device : str
        Compute device ("auto", "mps", "cuda", "cpu")
    deg_method : str
        DEG detection method (only used if space="deg")
    deg_pval : float
        P-value threshold for DEG detection
    deg_lfc : float
        Log fold change threshold for DEG detection
        
    Examples
    --------
    >>> # Compute MMD in PCA space
    >>> mmd = DistributionalMMD(space="pca", n_pca_components=50)
    >>> result = mmd.compute(real_data, generated_data)
    """
    
    def __init__(
        self,
        blur: float = 0.5,
        space: SpaceType = "pca",
        n_pca_components: int = 50,
        device: str = "auto",
        deg_method: DEGMethodType = "welch",
        deg_pval: float = 0.05,
        deg_lfc: float = 0.5,
    ):
        self.blur = blur
        self.space = space
        self.n_pca_components = n_pca_components
        self.device_str = device
        self.deg_method = deg_method
        self.deg_pval = deg_pval
        self.deg_lfc = deg_lfc
        
        if space == "pca":
            name = f"MMD_pca{n_pca_components}"
        elif space == "deg":
            name = f"MMD_deg_{deg_method}"
        else:
            name = "MMD_raw"
            
        super().__init__(
            name=name,
            description=f"MMD distance ({space} space)",
            higher_is_better=False,
        )
    
    def compute(
        self,
        real: np.ndarray,
        generated: np.ndarray,
        gene_names: Optional[list] = None,
        cache_key: Optional[str] = None,
        control_data: Optional[np.ndarray] = None,
        **kwargs,
    ) -> MetricResult:
        """Compute MMD between sample distributions.
        
        Returns None if space="deg" and no DEGs found.
        """
        if not HAS_GEOMLOSS or not HAS_TORCH:
            raise ImportError("geomloss and torch required")
        
        real = np.asarray(real, dtype=np.float32)
        generated = np.asarray(generated, dtype=np.float32)
        
        # Apply space transformation
        if self.space == "pca":
            real_proj, gen_proj, n_features = _apply_pca(
                real, generated, self.n_pca_components
            )
            space_info = {"n_pca_components": self.n_pca_components}
        elif self.space == "deg":
            deg_indices = _compute_deg_indices(
                control=real,
                perturbed=generated,
                method=self.deg_method,
                pval_threshold=self.deg_pval,
                lfc_threshold=self.deg_lfc,
                cache_key=cache_key,
                control_data=control_data,
            )
            real_proj, gen_proj, n_features, has_degs = _apply_deg_filter(
                real, generated, deg_indices, cache_key=cache_key
            )
            if not has_degs:
                return None  # Skip this condition
            space_info = {
                "deg_method": self.deg_method,
                "n_degs": n_features,
            }
        else:
            real_proj = real
            gen_proj = generated
            n_features = real.shape[1]
            space_info = {}
        
        device = _get_device(self.device_str)
        
        real_tensor = torch.tensor(real_proj, device=device)
        gen_tensor = torch.tensor(gen_proj, device=device)
        
        loss_fn = SamplesLoss(
            loss="gaussian",
            blur=self.blur,
            backend="tensorized",
        )
        
        distance = loss_fn(real_tensor, gen_tensor).item()
        
        return MetricResult(
            name=self.name,
            aggregate_value=distance,
            per_gene_values=np.full(real.shape[1], distance),
            gene_names=gene_names if gene_names else [f"gene_{i}" for i in range(real.shape[1])],
            aggregate_method="distributional",
            metadata={
                "n_real_samples": real.shape[0],
                "n_generated_samples": generated.shape[0],
                "n_features": n_features,
                "space": self.space,
                "device": str(device),
                **space_info,
            }
        )
    
    def compute_per_gene(self, real: np.ndarray, generated: np.ndarray) -> np.ndarray:
        result = self.compute(real, generated)
        return np.full(real.shape[1], result.aggregate_value)


class DistributionalEnergy(BaseMetric):
    """
    Energy distance between sample distributions.
    
    Based on pairwise Euclidean distances between samples.
    More robust than Wasserstein for high dimensions.
    
    Parameters
    ----------
    blur : float
        Smoothing parameter
    space : str
        Computation space: "raw", "pca", or "deg"
    n_pca_components : int
        Number of PCA components (only used if space="pca")
    device : str
        Compute device ("auto", "mps", "cuda", "cpu")
    deg_method : str
        DEG detection method (only used if space="deg")
    deg_pval : float
        P-value threshold for DEG detection
    deg_lfc : float
        Log fold change threshold for DEG detection
        
    Examples
    --------
    >>> # Compute Energy distance in raw space
    >>> energy = DistributionalEnergy(space="raw")
    >>> result = energy.compute(real_data, generated_data)
    """
    
    def __init__(
        self,
        blur: float = 0.5,
        space: SpaceType = "pca",
        n_pca_components: int = 50,
        device: str = "auto",
        deg_method: DEGMethodType = "welch",
        deg_pval: float = 0.05,
        deg_lfc: float = 0.5,
    ):
        self.blur = blur
        self.space = space
        self.n_pca_components = n_pca_components
        self.device_str = device
        self.deg_method = deg_method
        self.deg_pval = deg_pval
        self.deg_lfc = deg_lfc
        
        if space == "pca":
            name = f"Energy_pca{n_pca_components}"
        elif space == "deg":
            name = f"Energy_deg_{deg_method}"
        else:
            name = "Energy_raw"
            
        super().__init__(
            name=name,
            description=f"Energy distance ({space} space)",
            higher_is_better=False,
        )
    
    def compute(
        self,
        real: np.ndarray,
        generated: np.ndarray,
        gene_names: Optional[list] = None,
        cache_key: Optional[str] = None,
        control_data: Optional[np.ndarray] = None,
        **kwargs,
    ) -> MetricResult:
        """Compute Energy distance between sample distributions.
        
        Returns None if space="deg" and no DEGs found.
        """
        if not HAS_GEOMLOSS or not HAS_TORCH:
            raise ImportError("geomloss and torch required")
        
        real = np.asarray(real, dtype=np.float32)
        generated = np.asarray(generated, dtype=np.float32)
        
        # Apply space transformation
        if self.space == "pca":
            real_proj, gen_proj, n_features = _apply_pca(
                real, generated, self.n_pca_components
            )
            space_info = {"n_pca_components": self.n_pca_components}
        elif self.space == "deg":
            deg_indices = _compute_deg_indices(
                control=real,
                perturbed=generated,
                method=self.deg_method,
                pval_threshold=self.deg_pval,
                lfc_threshold=self.deg_lfc,
                cache_key=cache_key,
                control_data=control_data,
            )
            real_proj, gen_proj, n_features, has_degs = _apply_deg_filter(
                real, generated, deg_indices, cache_key=cache_key
            )
            if not has_degs:
                return None  # Skip this condition
            space_info = {
                "deg_method": self.deg_method,
                "n_degs": n_features,
            }
        else:
            real_proj = real
            gen_proj = generated
            n_features = real.shape[1]
            space_info = {}
        
        device = _get_device(self.device_str)
        
        real_tensor = torch.tensor(real_proj, device=device)
        gen_tensor = torch.tensor(gen_proj, device=device)
        
        loss_fn = SamplesLoss(
            loss="energy",
            blur=self.blur,
            backend="tensorized",
        )
        
        distance = loss_fn(real_tensor, gen_tensor).item()
        
        return MetricResult(
            name=self.name,
            aggregate_value=distance,
            per_gene_values=np.full(real.shape[1], distance),
            gene_names=gene_names if gene_names else [f"gene_{i}" for i in range(real.shape[1])],
            aggregate_method="distributional",
            metadata={
                "n_real_samples": real.shape[0],
                "n_generated_samples": generated.shape[0],
                "n_features": n_features,
                "space": self.space,
                "device": str(device),
                **space_info,
            }
        )
    
    def compute_per_gene(self, real: np.ndarray, generated: np.ndarray) -> np.ndarray:
        result = self.compute(real, generated)
        return np.full(real.shape[1], result.aggregate_value)


# =============================================================================
# Factory functions for convenient metric creation
# =============================================================================

def W1(
    space: SpaceType = "pca",
    n_components: int = 50,
    device: str = "auto",
    blur: float = 0.01,
    deg_method: DEGMethodType = "welch",
    deg_pval: float = 0.05,
    deg_lfc: float = 0.5,
) -> DistributionalWasserstein:
    """Create Wasserstein-1 (Earth Mover's) distance metric.
    
    Parameters
    ----------
    space : str
        "pca" for latent space, "raw" for gene expression space, "deg" for DEG subset
    n_components : int
        PCA components (only used if space="pca")
    device : str
        Compute device: "auto", "mps", "cuda", "cpu"
    blur : float
        Sinkhorn regularization
    deg_method : str
        DEG detection method: "welch", "student", "wilcoxon", "logfc" (only used if space="deg")
    deg_pval : float
        P-value threshold for DEG detection (only used if space="deg")
    deg_lfc : float
        Log fold change threshold for DEG detection (only used if space="deg")
        
    Returns
    -------
    DistributionalWasserstein
        Configured W1 metric
        
    Examples
    --------
    >>> w1 = W1(space="pca", n_components=50)
    >>> result = w1.compute(real, generated)
    
    >>> w1_deg = W1(space="deg", deg_method="welch")
    >>> result = w1_deg.compute(real, generated)
    """
    return DistributionalWasserstein(
        p=1, blur=blur, space=space, n_pca_components=n_components, device=device,
        deg_method=deg_method, deg_pval=deg_pval, deg_lfc=deg_lfc,
    )


def W2(
    space: SpaceType = "pca",
    n_components: int = 50,
    device: str = "auto",
    blur: float = 0.01,
    deg_method: DEGMethodType = "welch",
    deg_pval: float = 0.05,
    deg_lfc: float = 0.5,
) -> DistributionalWasserstein:
    """Create Wasserstein-2 (squared cost) distance metric.
    
    Parameters
    ----------
    space : str
        "pca" for latent space, "raw" for gene expression space, "deg" for DEG subset
    n_components : int
        PCA components (only used if space="pca")
    device : str
        Compute device: "auto", "mps", "cuda", "cpu"
    blur : float
        Sinkhorn regularization
    deg_method : str
        DEG detection method (only used if space="deg")
    deg_pval : float
        P-value threshold for DEG detection (only used if space="deg")
    deg_lfc : float
        Log fold change threshold for DEG detection (only used if space="deg")
        
    Returns
    -------
    DistributionalWasserstein
        Configured W2 metric
    """
    return DistributionalWasserstein(
        p=2, blur=blur, space=space, n_pca_components=n_components, device=device,
        deg_method=deg_method, deg_pval=deg_pval, deg_lfc=deg_lfc,
    )


def MMD(
    space: SpaceType = "pca",
    n_components: int = 50,
    device: str = "auto",
    blur: float = 0.5,
    deg_method: DEGMethodType = "welch",
    deg_pval: float = 0.05,
    deg_lfc: float = 0.5,
) -> DistributionalMMD:
    """Create Maximum Mean Discrepancy metric.
    
    Parameters
    ----------
    space : str
        "pca" for latent space, "raw" for gene expression space, "deg" for DEG subset
    n_components : int
        PCA components (only used if space="pca")
    device : str
        Compute device: "auto", "mps", "cuda", "cpu"
    blur : float
        Kernel bandwidth
    deg_method : str
        DEG detection method (only used if space="deg")
    deg_pval : float
        P-value threshold for DEG detection (only used if space="deg")
    deg_lfc : float
        Log fold change threshold for DEG detection (only used if space="deg")
        
    Returns
    -------
    DistributionalMMD
        Configured MMD metric
    """
    return DistributionalMMD(
        blur=blur, space=space, n_pca_components=n_components, device=device,
        deg_method=deg_method, deg_pval=deg_pval, deg_lfc=deg_lfc,
    )


def Energy(
    space: SpaceType = "pca",
    n_components: int = 50,
    device: str = "auto",
    blur: float = 0.5,
    deg_method: DEGMethodType = "welch",
    deg_pval: float = 0.05,
    deg_lfc: float = 0.5,
) -> DistributionalEnergy:
    """Create Energy distance metric.
    
    Parameters
    ----------
    space : str
        "pca" for latent space, "raw" for gene expression space, "deg" for DEG subset
    n_components : int
        PCA components (only used if space="pca")
    device : str
        Compute device: "auto", "mps", "cuda", "cpu"
    blur : float
        Smoothing parameter
    deg_method : str
        DEG detection method (only used if space="deg")
    deg_pval : float
        P-value threshold for DEG detection (only used if space="deg")
    deg_lfc : float
        Log fold change threshold for DEG detection (only used if space="deg")
        
    Returns
    -------
    DistributionalEnergy
        Configured Energy metric
    """
    return DistributionalEnergy(
        blur=blur, space=space, n_pca_components=n_components, device=device,
        deg_method=deg_method, deg_pval=deg_pval, deg_lfc=deg_lfc,
    )


# =============================================================================
# Convenience function for computing all distributional metrics
# =============================================================================

def compute_all_distributional(
    real: np.ndarray,
    generated: np.ndarray,
    space: SpaceType = "pca",
    n_components: int = 50,
    device: str = "auto",
    gene_names: Optional[list] = None,
) -> dict:
    """Compute all distributional metrics at once.
    
    Parameters
    ----------
    real : np.ndarray
        Real samples (n_real, n_genes)
    generated : np.ndarray
        Generated samples (n_gen, n_genes)
    space : str
        "pca" or "raw"
    n_components : int
        PCA components
    device : str
        Compute device
    gene_names : list, optional
        Gene names
        
    Returns
    -------
    dict
        Dictionary with metric names as keys and MetricResult objects as values
        
    Examples
    --------
    >>> results = compute_all_distributional(real, generated, space="pca")
    >>> print(results["W2_pca50"].aggregate_value)
    """
    metrics = [
        W1(space=space, n_components=n_components, device=device),
        W2(space=space, n_components=n_components, device=device),
        MMD(space=space, n_components=n_components, device=device),
        Energy(space=space, n_components=n_components, device=device),
    ]
    
    results = {}
    for metric in metrics:
        try:
            result = metric.compute(real, generated, gene_names=gene_names)
            results[metric.name] = result
        except Exception as e:
            warnings.warn(f"Failed to compute {metric.name}: {e}")
    
    return results


# =============================================================================
# Default metric sets
# =============================================================================

def get_distributional_metrics(
    space: SpaceType = "pca",
    n_components: int = 50,
    device: str = "auto",
) -> list:
    """Get a list of all distributional metrics with specified configuration.
    
    Parameters
    ----------
    space : str
        "pca" or "raw"
    n_components : int
        PCA components (if space="pca")
    device : str
        Compute device
        
    Returns
    -------
    list
        List of configured metric instances
    """
    return [
        W1(space=space, n_components=n_components, device=device),
        W2(space=space, n_components=n_components, device=device),
        MMD(space=space, n_components=n_components, device=device),
        Energy(space=space, n_components=n_components, device=device),
    ]
