"""
Reconstruction metrics for gene expression evaluation.

Provides MSE, RMSE, MAE, and R² metrics with optional space transformations.
All metrics can compute in raw, PCA, or DEG space.
"""
from __future__ import annotations

import numpy as np
from typing import Optional, List

from .base_metric import BaseMetric, MetricResult
from .space_utils import (
    SpaceType, DEGMethodType, apply_space_transform, make_metric_name
)


def _ensure_2d(arr: np.ndarray) -> np.ndarray:
    """Ensure array is 2D (samples x genes)."""
    arr = np.asarray(arr, dtype=np.float64)
    if arr.ndim == 1:
        arr = arr.reshape(-1, 1)
    return arr


def _compute_mse(real: np.ndarray, generated: np.ndarray) -> float:
    """Compute MSE between mean profiles."""
    real_mean = np.mean(real, axis=0)
    gen_mean = np.mean(generated, axis=0)
    return float(np.mean((real_mean - gen_mean) ** 2))


def _compute_rmse(real: np.ndarray, generated: np.ndarray) -> float:
    """Compute RMSE between mean profiles."""
    return np.sqrt(_compute_mse(real, generated))


def _compute_mae(real: np.ndarray, generated: np.ndarray) -> float:
    """Compute MAE between mean profiles."""
    real_mean = np.mean(real, axis=0)
    gen_mean = np.mean(generated, axis=0)
    return float(np.mean(np.abs(real_mean - gen_mean)))


class MSEDistance(BaseMetric):
    """
    Mean Squared Error (MSE) between real and generated distributions.
    
    Computes the average squared difference between mean expression profiles.
    Lower values indicate better reconstruction.
    
    Supports computation in different spaces:
    - raw: Original gene expression space (default)
    - pca: PCA-reduced latent space  
    - deg: Differentially expressed genes only
    
    Parameters
    ----------
    space : str
        Computation space: "raw", "pca", or "deg"
    n_pca_components : int
        Number of PCA components (only for space="pca")
    deg_method : str
        DEG detection method (only for space="deg")
    deg_pval : float
        P-value threshold for DEG detection
    deg_lfc : float
        Log fold change threshold for DEG detection
        
    Examples
    --------
    >>> # Raw space (default)
    >>> mse = MSEDistance()
    
    >>> # PCA space
    >>> mse_pca = MSEDistance(space="pca", n_pca_components=50)
    
    >>> # DEG space
    >>> mse_deg = MSEDistance(space="deg", deg_method="welch")
    """
    
    def __init__(
        self,
        space: SpaceType = "raw",
        n_pca_components: int = 50,
        deg_method: DEGMethodType = "welch",
        deg_pval: float = 0.05,
        deg_lfc: float = 0.5,
        compare_means: bool = False,  # Kept for backward compatibility
    ):
        self.space = space
        self.n_pca_components = n_pca_components
        self.deg_method = deg_method
        self.deg_pval = deg_pval
        self.deg_lfc = deg_lfc
        self.compare_means = compare_means
        
        name = make_metric_name("mse", space, n_pca_components, deg_method)
        
        super().__init__(
            name=name,
            description=f"Mean Squared Error ({space} space)",
            higher_is_better=False,
            requires_distribution=True,
        )
    
    def compute_per_gene(
        self,
        real: np.ndarray,
        generated: np.ndarray,
    ) -> np.ndarray:
        """Compute MSE per gene (for backward compatibility)."""
        real = _ensure_2d(real)
        generated = _ensure_2d(generated)
        
        real_mean = np.mean(real, axis=0)
        gen_mean = np.mean(generated, axis=0)
        return (real_mean - gen_mean) ** 2
    
    def compute(
        self,
        real: np.ndarray,
        generated: np.ndarray,
        gene_names: Optional[List[str]] = None,
        cache_key: Optional[str] = None,
        control_data: Optional[np.ndarray] = None,
        **kwargs,
    ) -> Optional[MetricResult]:
        """
        Compute MSE with space transformation.
        
        Parameters
        ----------
        real : np.ndarray
            Real expression data
        generated : np.ndarray
            Generated expression data
        gene_names : list, optional
            Gene names
        cache_key : str, optional
            Cache key for DEG results
        control_data : np.ndarray, optional
            Control cells for proper DEG computation
            
        Returns None if space="deg" and no DEGs found.
        """
        real = _ensure_2d(real)
        generated = _ensure_2d(generated)
        
        # Apply space transformation
        real_proj, gen_proj, n_features, has_data, space_info, _ = apply_space_transform(
            real=real,
            generated=generated,
            space=self.space,
            n_pca_components=self.n_pca_components,
            deg_method=self.deg_method,
            deg_pval=self.deg_pval,
            deg_lfc=self.deg_lfc,
            cache_key=cache_key,
            control_data=control_data,
        )
        
        if not has_data:
            return None  # No DEGs found
        
        # Compute MSE
        mse_value = _compute_mse(real_proj, gen_proj)
        
        n_genes = real.shape[1]
        if gene_names is None:
            gene_names = [f"gene_{i}" for i in range(n_genes)]
        
        return MetricResult(
            name=self.name,
            per_gene_values=np.full(n_genes, mse_value),
            gene_names=gene_names,
            aggregate_value=mse_value,
            aggregate_method="mse",
            metadata={
                "higher_is_better": False,
                "n_features": n_features,
                **space_info,
            }
        )


class RMSEDistance(BaseMetric):
    """
    Root Mean Squared Error (RMSE) between real and generated distributions.
    
    Square root of MSE, in the same units as the original data.
    Lower values indicate better reconstruction.
    
    Supports computation in different spaces (raw, pca, deg).
    """
    
    def __init__(
        self,
        space: SpaceType = "raw",
        n_pca_components: int = 50,
        deg_method: DEGMethodType = "welch",
        deg_pval: float = 0.05,
        deg_lfc: float = 0.5,
        compare_means: bool = False,
    ):
        self.space = space
        self.n_pca_components = n_pca_components
        self.deg_method = deg_method
        self.deg_pval = deg_pval
        self.deg_lfc = deg_lfc
        self.compare_means = compare_means
        
        name = make_metric_name("rmse", space, n_pca_components, deg_method)
        
        super().__init__(
            name=name,
            description=f"Root Mean Squared Error ({space} space)",
            higher_is_better=False,
            requires_distribution=True,
        )
    
    def compute_per_gene(
        self,
        real: np.ndarray,
        generated: np.ndarray,
    ) -> np.ndarray:
        """Compute RMSE per gene (for backward compatibility)."""
        real = _ensure_2d(real)
        generated = _ensure_2d(generated)
        
        real_mean = np.mean(real, axis=0)
        gen_mean = np.mean(generated, axis=0)
        return np.sqrt((real_mean - gen_mean) ** 2)
    
    def compute(
        self,
        real: np.ndarray,
        generated: np.ndarray,
        gene_names: Optional[List[str]] = None,
        cache_key: Optional[str] = None,
        control_data: Optional[np.ndarray] = None,
        **kwargs,
    ) -> Optional[MetricResult]:
        """
        Compute RMSE with space transformation.
        
        Returns None if space="deg" and no DEGs found.
        """
        real = _ensure_2d(real)
        generated = _ensure_2d(generated)
        
        # Apply space transformation
        real_proj, gen_proj, n_features, has_data, space_info, _ = apply_space_transform(
            real=real,
            generated=generated,
            space=self.space,
            n_pca_components=self.n_pca_components,
            deg_method=self.deg_method,
            deg_pval=self.deg_pval,
            deg_lfc=self.deg_lfc,
            cache_key=cache_key,
            control_data=control_data,
        )
        
        if not has_data:
            return None  # No DEGs found
        
        # Compute RMSE
        rmse_value = _compute_rmse(real_proj, gen_proj)
        
        n_genes = real.shape[1]
        if gene_names is None:
            gene_names = [f"gene_{i}" for i in range(n_genes)]
        
        return MetricResult(
            name=self.name,
            per_gene_values=np.full(n_genes, rmse_value),
            gene_names=gene_names,
            aggregate_value=rmse_value,
            aggregate_method="rmse",
            metadata={
                "higher_is_better": False,
                "n_features": n_features,
                **space_info,
            }
        )


class MAEDistance(BaseMetric):
    """
    Mean Absolute Error (MAE) between real and generated distributions.
    
    More robust to outliers than MSE.
    Lower values indicate better reconstruction.
    
    Supports computation in different spaces (raw, pca, deg).
    """
    
    def __init__(
        self,
        space: SpaceType = "raw",
        n_pca_components: int = 50,
        deg_method: DEGMethodType = "welch",
        deg_pval: float = 0.05,
        deg_lfc: float = 0.5,
        compare_means: bool = False,
    ):
        self.space = space
        self.n_pca_components = n_pca_components
        self.deg_method = deg_method
        self.deg_pval = deg_pval
        self.deg_lfc = deg_lfc
        self.compare_means = compare_means
        
        name = make_metric_name("mae", space, n_pca_components, deg_method)
        
        super().__init__(
            name=name,
            description=f"Mean Absolute Error ({space} space)",
            higher_is_better=False,
            requires_distribution=True,
        )
    
    def compute_per_gene(
        self,
        real: np.ndarray,
        generated: np.ndarray,
    ) -> np.ndarray:
        """Compute MAE per gene (for backward compatibility)."""
        real = _ensure_2d(real)
        generated = _ensure_2d(generated)
        
        real_mean = np.mean(real, axis=0)
        gen_mean = np.mean(generated, axis=0)
        return np.abs(real_mean - gen_mean)
    
    def compute(
        self,
        real: np.ndarray,
        generated: np.ndarray,
        gene_names: Optional[List[str]] = None,
        cache_key: Optional[str] = None,
        control_data: Optional[np.ndarray] = None,
        **kwargs,
    ) -> Optional[MetricResult]:
        """
        Compute MAE with space transformation.
        
        Returns None if space="deg" and no DEGs found.
        """
        real = _ensure_2d(real)
        generated = _ensure_2d(generated)
        
        # Apply space transformation
        real_proj, gen_proj, n_features, has_data, space_info, _ = apply_space_transform(
            real=real,
            generated=generated,
            space=self.space,
            n_pca_components=self.n_pca_components,
            deg_method=self.deg_method,
            deg_pval=self.deg_pval,
            deg_lfc=self.deg_lfc,
            cache_key=cache_key,
            control_data=control_data,
        )
        
        if not has_data:
            return None  # No DEGs found
        
        # Compute MAE
        mae_value = _compute_mae(real_proj, gen_proj)
        
        n_genes = real.shape[1]
        if gene_names is None:
            gene_names = [f"gene_{i}" for i in range(n_genes)]
        
        return MetricResult(
            name=self.name,
            per_gene_values=np.full(n_genes, mae_value),
            gene_names=gene_names,
            aggregate_value=mae_value,
            aggregate_method="mae",
            metadata={
                "higher_is_better": False,
                "n_features": n_features,
                **space_info,
            }
        )


class R2Score(BaseMetric):
    """
    Coefficient of Determination (R²) between real and generated data.
    
    Measures the proportion of variance explained. Values close to 1
    indicate good fit, 0 means no better than mean prediction.
    
    Higher values indicate better reconstruction.
    
    Supports computation in different spaces (raw, pca, deg).
    """
    
    def __init__(
        self,
        space: SpaceType = "raw",
        n_pca_components: int = 50,
        deg_method: DEGMethodType = "welch",
        deg_pval: float = 0.05,
        deg_lfc: float = 0.5,
    ):
        self.space = space
        self.n_pca_components = n_pca_components
        self.deg_method = deg_method
        self.deg_pval = deg_pval
        self.deg_lfc = deg_lfc
        
        name = make_metric_name("r2", space, n_pca_components, deg_method)
        
        super().__init__(
            name=name,
            description=f"R² coefficient of determination ({space} space)",
            higher_is_better=True,
            requires_distribution=True,
        )
    
    def compute_per_gene(
        self,
        real: np.ndarray,
        generated: np.ndarray,
    ) -> np.ndarray:
        """Compute R² per gene (for backward compatibility)."""
        real = _ensure_2d(real)
        generated = _ensure_2d(generated)
        n_genes = real.shape[1]
        
        r2 = np.zeros(n_genes)
        
        if real.shape[0] != generated.shape[0]:
            # Use mean comparison
            real_mean = np.mean(real, axis=0)
            gen_mean = np.mean(generated, axis=0)
            
            ss_tot = np.var(real, axis=0) * real.shape[0]
            ss_res = (real_mean - gen_mean) ** 2
            
            with np.errstate(invalid='ignore', divide='ignore'):
                r2 = 1 - ss_res / (ss_tot / real.shape[0] + 1e-10)
            r2 = np.nan_to_num(r2, nan=0.0)
        else:
            for i in range(n_genes):
                r_vals = real[:, i]
                g_vals = generated[:, i]
                
                valid = ~(np.isnan(r_vals) | np.isnan(g_vals))
                if not valid.any():
                    r2[i] = np.nan
                    continue
                
                ss_tot = np.sum((r_vals[valid] - np.mean(r_vals[valid])) ** 2)
                ss_res = np.sum((r_vals[valid] - g_vals[valid]) ** 2)
                
                if ss_tot < 1e-10:
                    r2[i] = 1.0 if ss_res < 1e-10 else 0.0
                else:
                    r2[i] = 1 - ss_res / ss_tot
        
        return r2
    
    def compute(
        self,
        real: np.ndarray,
        generated: np.ndarray,
        gene_names: Optional[List[str]] = None,
        cache_key: Optional[str] = None,
        control_data: Optional[np.ndarray] = None,
        **kwargs,
    ) -> Optional[MetricResult]:
        """
        Compute R² with space transformation.
        
        Returns None if space="deg" and no DEGs found.
        """
        real = _ensure_2d(real)
        generated = _ensure_2d(generated)
        
        # Apply space transformation
        real_proj, gen_proj, n_features, has_data, space_info, _ = apply_space_transform(
            real=real,
            generated=generated,
            space=self.space,
            n_pca_components=self.n_pca_components,
            deg_method=self.deg_method,
            deg_pval=self.deg_pval,
            deg_lfc=self.deg_lfc,
            cache_key=cache_key,
            control_data=control_data,
        )
        
        if not has_data:
            return None  # No DEGs found
        
        # Compute R² on mean profiles
        real_mean = np.mean(real_proj, axis=0)
        gen_mean = np.mean(gen_proj, axis=0)
        
        ss_tot = np.sum((real_mean - np.mean(real_mean)) ** 2)
        ss_res = np.sum((real_mean - gen_mean) ** 2)
        
        if ss_tot < 1e-10:
            r2_value = 1.0 if ss_res < 1e-10 else 0.0
        else:
            r2_value = max(0.0, 1 - ss_res / ss_tot)  # Clamp to non-negative
        
        n_genes = real.shape[1]
        if gene_names is None:
            gene_names = [f"gene_{i}" for i in range(n_genes)]
        
        return MetricResult(
            name=self.name,
            per_gene_values=np.full(n_genes, r2_value),
            gene_names=gene_names,
            aggregate_value=float(r2_value),
            aggregate_method="r2",
            metadata={
                "higher_is_better": True,
                "n_features": n_features,
                **space_info,
            }
        )

