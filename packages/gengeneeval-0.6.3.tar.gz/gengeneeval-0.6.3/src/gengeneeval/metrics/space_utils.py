"""
Shared utilities for space transformations (PCA, DEG) across all metrics.

This module provides a unified interface for computing metrics in different spaces:
- raw: Original gene expression space (high-dimensional)
- pca: PCA-reduced latent space (recommended for stability)
- deg: Differentially expressed genes only (biologically relevant subset)

The space processing is shared across all metric types (correlation, reconstruction, distributional).
"""
from __future__ import annotations

import numpy as np
import warnings
from typing import Optional, Literal, Dict, Tuple, List, Any


# Type aliases
SpaceType = Literal["raw", "pca", "deg"]
DEGMethodType = Literal["welch", "student", "wilcoxon", "logfc"]


# =============================================================================
# Global cache for DEG indices (shared across metrics)
# =============================================================================

_DEG_CACHE: Dict[str, np.ndarray] = {}
_NO_DEG_CONDITIONS: List[str] = []


def clear_deg_cache():
    """Clear the global DEG cache and no-DEG conditions list."""
    _DEG_CACHE.clear()
    _NO_DEG_CONDITIONS.clear()


def get_deg_cache() -> Dict[str, np.ndarray]:
    """Get the current DEG cache (for inspection/saving)."""
    return _DEG_CACHE.copy()


def set_deg_cache(cache: Dict[str, np.ndarray]):
    """Set the DEG cache (for loading pre-computed DEGs)."""
    global _DEG_CACHE
    _DEG_CACHE = cache.copy()


def get_no_deg_conditions() -> List[str]:
    """Get list of conditions where no DEGs were found."""
    return _NO_DEG_CONDITIONS.copy()


def _record_no_deg_condition(cache_key: str):
    """Record a condition with no DEGs (internal use)."""
    if cache_key and cache_key not in _NO_DEG_CONDITIONS:
        _NO_DEG_CONDITIONS.append(cache_key)


# =============================================================================
# Space Transformations
# =============================================================================

def apply_pca(
    real: np.ndarray,
    generated: np.ndarray,
    n_components: int = 50,
) -> Tuple[np.ndarray, np.ndarray, int]:
    """
    Apply PCA for dimensionality reduction.
    
    Fits PCA on combined data for consistent projection.
    
    Parameters
    ----------
    real : np.ndarray
        Real data matrix (n_samples_real, n_genes)
    generated : np.ndarray
        Generated data matrix (n_samples_gen, n_genes)
    n_components : int
        Number of PCA components
        
    Returns
    -------
    tuple
        (real_proj, gen_proj, n_components_used)
    """
    from sklearn.decomposition import PCA
    
    combined = np.vstack([real, generated])
    n_comp = min(n_components, combined.shape[0], combined.shape[1])
    
    pca = PCA(n_components=n_comp)
    pca.fit(combined)
    
    real_proj = pca.transform(real).astype(np.float32)
    gen_proj = pca.transform(generated).astype(np.float32)
    
    return real_proj, gen_proj, n_comp


def compute_deg_indices(
    control: np.ndarray,
    perturbed: np.ndarray,
    method: DEGMethodType = "welch",
    pval_threshold: float = 0.05,
    lfc_threshold: float = 0.5,
    cache_key: Optional[str] = None,
    control_data: Optional[np.ndarray] = None,
) -> np.ndarray:
    """
    Compute DEG indices with optional caching.
    
    Parameters
    ----------
    control : np.ndarray
        Control expression matrix (n_samples, n_genes). This is ONLY used
        when control_data is not provided (fallback mode).
    perturbed : np.ndarray
        Perturbed expression matrix (n_samples, n_genes). This is ONLY used
        when control_data is not provided (fallback mode).
    method : str
        DEG detection method: "welch", "student", "wilcoxon", "logfc"
    pval_threshold : float
        P-value threshold
    lfc_threshold : float
        Log fold change threshold
    cache_key : str, optional
        Key for caching. If provided, uses cached value if available.
    control_data : np.ndarray, optional
        If provided, uses this as control and 'control' param as perturbed.
        This is the PROPER mode - real control cells vs real perturbed cells.
        
    Returns
    -------
    np.ndarray
        Indices of DEGs
    """
    # Check cache first
    if cache_key is not None and cache_key in _DEG_CACHE:
        return _DEG_CACHE[cache_key]
    
    # Import DEG detection
    try:
        from ..deg import compute_degs_fast
    except ImportError:
        raise ImportError("DEG detection requires scipy. Install with: pip install scipy")
    
    # Determine which data to use for DEG computation
    if control_data is not None:
        # PROPER MODE: Use actual control cells vs real perturbed cells
        deg_control = control_data
        deg_perturbed = control  # 'control' param is actually the real perturbed data
    else:
        # FALLBACK MODE: Use real vs generated (less meaningful but still works)
        deg_control = control
        deg_perturbed = perturbed
    
    # Compute DEGs
    deg_result = compute_degs_fast(
        control=deg_control,
        perturbed=deg_perturbed,
        method=method,
        pval_threshold=pval_threshold,
        lfc_threshold=lfc_threshold,
    )
    
    deg_indices = deg_result.deg_indices
    
    # Cache if key provided
    if cache_key is not None:
        _DEG_CACHE[cache_key] = deg_indices
    
    return deg_indices


def apply_deg_filter(
    real: np.ndarray,
    generated: np.ndarray,
    deg_indices: np.ndarray,
    cache_key: Optional[str] = None,
) -> Tuple[Optional[np.ndarray], Optional[np.ndarray], int, bool]:
    """
    Filter data to DEG subset.
    
    Parameters
    ----------
    real : np.ndarray
        Real data matrix (n_samples_real, n_genes)
    generated : np.ndarray
        Generated data matrix (n_samples_gen, n_genes)
    deg_indices : np.ndarray
        Indices of DEGs to keep
    cache_key : str, optional
        Cache key for tracking no-DEG conditions
        
    Returns
    -------
    tuple
        (real_filtered, gen_filtered, n_degs, has_degs)
        If no DEGs found, returns (None, None, 0, False)
    """
    if len(deg_indices) == 0:
        _record_no_deg_condition(cache_key)
        return None, None, 0, False
    
    real_filtered = real[:, deg_indices].astype(np.float32)
    gen_filtered = generated[:, deg_indices].astype(np.float32)
    
    return real_filtered, gen_filtered, len(deg_indices), True


def apply_space_transform(
    real: np.ndarray,
    generated: np.ndarray,
    space: SpaceType = "raw",
    n_pca_components: int = 50,
    deg_method: DEGMethodType = "welch",
    deg_pval: float = 0.05,
    deg_lfc: float = 0.5,
    cache_key: Optional[str] = None,
    control_data: Optional[np.ndarray] = None,
) -> Tuple[Optional[np.ndarray], Optional[np.ndarray], int, bool, Dict[str, Any], Optional[np.ndarray]]:
    """
    Apply space transformation to data.
    
    This is the main entry point for space transformations used by all metrics.
    
    Parameters
    ----------
    real : np.ndarray
        Real data matrix (n_samples_real, n_genes)
    generated : np.ndarray
        Generated data matrix (n_samples_gen, n_genes)
    space : str
        Space to compute in: "raw", "pca", or "deg"
    n_pca_components : int
        Number of PCA components (only for space="pca")
    deg_method : str
        DEG detection method (only for space="deg")
    deg_pval : float
        P-value threshold for DEG (only for space="deg")
    deg_lfc : float
        Log fold change threshold for DEG (only for space="deg")
    cache_key : str, optional
        Key for DEG caching
    control_data : np.ndarray, optional
        Control cells for proper DEG computation (comparing control vs real perturbed).
        If not provided, falls back to comparing real vs generated (less meaningful).
        
    Returns
    -------
    tuple
        (real_transformed, gen_transformed, n_features, has_data, space_info, control_transformed)
        If space="deg" and no DEGs found, returns (None, None, 0, False, info, None)
        control_transformed is the control data in the same space (for computing perturbation effects)
    """
    real = np.asarray(real, dtype=np.float32)
    generated = np.asarray(generated, dtype=np.float32)
    
    if space == "pca":
        real_proj, gen_proj, n_features = apply_pca(real, generated, n_pca_components)
        space_info = {
            "space": "pca",
            "n_pca_components": n_features,
        }
        return real_proj, gen_proj, n_features, True, space_info, None
        
    elif space == "deg":
        deg_indices = compute_deg_indices(
            control=real,
            perturbed=generated,
            method=deg_method,
            pval_threshold=deg_pval,
            lfc_threshold=deg_lfc,
            cache_key=cache_key,
            control_data=control_data,
        )
        real_proj, gen_proj, n_features, has_degs = apply_deg_filter(
            real, generated, deg_indices, cache_key=cache_key
        )
        
        # Also transform control data if provided (for computing perturbation effects)
        control_transformed = None
        if control_data is not None and has_degs:
            control_transformed = control_data[:, deg_indices].astype(np.float32)
        
        space_info = {
            "space": "deg",
            "deg_method": deg_method,
            "deg_pval": deg_pval,
            "deg_lfc": deg_lfc,
            "n_degs": n_features,
            "used_control_data": control_data is not None,
        }
        return real_proj, gen_proj, n_features, has_degs, space_info, control_transformed
        
    else:  # raw
        space_info = {
            "space": "raw",
            "n_features": real.shape[1],
        }
        return real, generated, real.shape[1], True, space_info, None


def make_metric_name(
    base_name: str,
    space: SpaceType,
    n_pca_components: int = 50,
    deg_method: DEGMethodType = "welch",
) -> str:
    """
    Create descriptive metric name including space.
    
    Parameters
    ----------
    base_name : str
        Base metric name (e.g., "pearson", "mse")
    space : str
        Space type
    n_pca_components : int
        PCA components (for space="pca")
    deg_method : str
        DEG method (for space="deg")
        
    Returns
    -------
    str
        Descriptive name like "pearson_pca50" or "mse_deg_welch"
    """
    if space == "pca":
        return f"{base_name}_pca{n_pca_components}"
    elif space == "deg":
        return f"{base_name}_deg_{deg_method}"
    else:
        return base_name  # raw space uses base name
