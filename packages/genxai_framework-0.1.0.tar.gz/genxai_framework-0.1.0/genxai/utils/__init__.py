"""Utility functions for GenXAI."""
