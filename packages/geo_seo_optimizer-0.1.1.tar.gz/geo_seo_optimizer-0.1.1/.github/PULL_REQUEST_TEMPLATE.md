## Summary
<!-- Brief description of the changes -->

## Test Plan
- [ ] Unit tests pass (`pytest tests/`)
- [ ] Coverage maintained (>90%)
- [ ] Type checking passes (`mypy src/`)
- [ ] Linting passes (`ruff check src/`)

## Changes
<!-- List of changes made -->
-

## Checklist
- [ ] Code follows project style guidelines
- [ ] Self-review completed
- [ ] Comments added for complex logic
- [ ] Documentation updated (if needed)
- [ ] Tests added for new features
- [ ] All CI checks pass

## Related Issues
<!-- Link to related issues -->
Fixes #
