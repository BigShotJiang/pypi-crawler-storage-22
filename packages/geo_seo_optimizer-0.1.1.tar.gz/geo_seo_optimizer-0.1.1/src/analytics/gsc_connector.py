"""GSC Connector module - re-exports from metrics_tracker."""

from src.analytics.metrics_tracker import GSCConnector

__all__ = ["GSCConnector"]
