"""CLI 入口."""

import typer
from rich.console import Console

app = typer.Typer(help="GEO-SEO Optimizer CLI")
console = Console()


@app.command()
def keywords(
    action: str = typer.Argument(...),
    query: str = typer.Argument(...),
    output: str = typer.Option(None, "--output", "-o"),
) -> None:
    """关键词研究命令."""
    console.print(f"[green]关键词研究: {query}[/green]")


@app.command()
def content(
    action: str = typer.Argument(...),
    source: str = typer.Argument(...),
    platform: str = typer.Option(None, "--platform", "-p"),
    seo: bool = typer.Option(True, "--seo/--no-seo"),
    geo: bool = typer.Option(True, "--geo/--no-geo"),
) -> None:
    """内容生成命令."""
    console.print(f"[green]内容生成: {source}[/green]")


@app.command()
def adapt(
    content_file: str = typer.Argument(...),
    platform: str = typer.Option(..., "--platform", "-p"),
    output: str = typer.Option(None, "--output", "-o"),
) -> None:
    """平台适配命令."""
    console.print(f"[green]适配到 {platform}[/green]")


@app.command()
def analytics(
    action: str = typer.Argument(...),
    target: str = typer.Argument(None),
    days: int = typer.Option(30, "--days", "-d"),
) -> None:
    """分析命令."""
    console.print(f"[green]分析: {action}[/green]")


def main() -> None:
    app()


if __name__ == "__main__":
    main()
