# Schema Builder
from dataclasses import dataclass
from typing import Any


@dataclass
class FAQItem:
    question: str
    answer: str


class SchemaBuilder:
    def build_faq_schema(self, items: list[FAQItem]) -> dict[str, Any]:
        return {
            "@context": "https://schema.org",
            "@type": "FAQPage",
            "mainEntity": [
                {
                    "@type": "Question",
                    "name": item.question,
                    "acceptedAnswer": {"@type": "Answer", "text": item.answer},
                }
                for item in items
            ],
        }

    def build_howto_schema(self, title: str, steps: list[str]) -> dict[str, Any]:
        return {
            "@context": "https://schema.org",
            "@type": "HowTo",
            "name": title,
            "step": [
                {"@type": "HowToStep", "text": step, "position": i + 1}
                for i, step in enumerate(steps)
            ],
        }

    def build_article_schema(
        self, title: str, description: str, author: str, date: str
    ) -> dict[str, Any]:
        return {
            "@context": "https://schema.org",
            "@type": "Article",
            "headline": title,
            "description": description,
            "author": {"@type": "Person", "name": author},
            "datePublished": date,
        }
