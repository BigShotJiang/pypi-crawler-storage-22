"""模板引擎."""

from __future__ import annotations

from typing import Any

from jinja2 import BaseLoader, Environment, FileSystemLoader


class TemplateEngine:
    def __init__(self, template_dir: str | None = None) -> None:
        if template_dir:
            self.env = Environment(loader=FileSystemLoader(template_dir))
        else:
            self.env = Environment(loader=BaseLoader())

    def render(self, template_str: str, context: dict[str, Any]) -> str:
        template = self.env.from_string(template_str)
        return template.render(**context)  # type: ignore[no-any-return]

    def render_file(self, template_file: str, context: dict[str, Any]) -> str:
        template = self.env.get_template(template_file)
        return template.render(**context)  # type: ignore[no-any-return]
