# Base Adapter
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any


@dataclass
class PlatformContent:
    title: str | None
    body: str
    metadata: dict[str, Any]


class BaseAdapter(ABC):
    def __init__(self, config: dict[str, Any] | None = None):
        self.config = config or {}

    @abstractmethod
    def get_max_length(self) -> int:
        pass

    @abstractmethod
    def format_content(self, content: str, **kwargs: Any) -> PlatformContent:
        pass

    def truncate_content(self, content: str, max_length: int | None = None) -> str:
        max_len = max_length or self.get_max_length()
        if len(content) <= max_len:
            return content
        return content[: max_len - 3] + "..."
