from __future__ import annotations

from typing import Any

from src.platform_adapter.base_adapter import BaseAdapter, PlatformContent


class MediumAdapter(BaseAdapter):
    def get_max_length(self) -> int:
        return 50000

    def format_content(self, content: str, **kwargs: Any) -> PlatformContent:
        truncated = self.truncate_content(content)
        return PlatformContent(
            title=kwargs.get("title"), body=truncated, metadata={"platform": "medium"}
        )
