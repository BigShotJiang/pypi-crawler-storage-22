"""日志模块.

基于 Rich 的彩色终端输出和文件日志支持。
"""

import logging
from pathlib import Path

from rich.console import Console
from rich.logging import RichHandler


def get_logger(
    name: str,
    level: str = "INFO",
    log_file: str | None = None,
    console_output: bool = True,
) -> logging.Logger:
    """获取配置好的日志记录器.

    Args:
        name: 日志记录器名称
        level: 日志级别 (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        log_file: 日志文件路径（可选）
        console_output: 是否输出到终端

    Returns:
        配置好的 Logger 实例

    Example:
        >>> logger = get_logger(__name__)
        >>> logger.info("Hello, World!")
    """
    logger = logging.getLogger(name)
    logger.setLevel(getattr(logging, level.upper()))

    # 清除已有处理器
    logger.handlers = []

    # 终端处理器（Rich）
    if console_output:
        console_handler = RichHandler(
            console=Console(stderr=True),
            show_time=True,
            show_path=True,
            rich_tracebacks=True,
            markup=True,
        )
        console_handler.setLevel(getattr(logging, level.upper()))
        console_handler.setFormatter(logging.Formatter("%(message)s", datefmt="[%X]"))
        logger.addHandler(console_handler)

    # 文件处理器
    if log_file:
        log_path = Path(log_file)
        log_path.parent.mkdir(parents=True, exist_ok=True)

        file_handler = logging.FileHandler(log_file, encoding="utf-8")
        file_handler.setLevel(logging.DEBUG)
        file_formatter = logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
        file_handler.setFormatter(file_formatter)
        logger.addHandler(file_handler)

    return logger
