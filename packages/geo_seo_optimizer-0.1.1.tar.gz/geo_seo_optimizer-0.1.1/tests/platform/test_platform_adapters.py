"""Platform Adapter Tests for GEO-SEO Optimizer.

Agent: Agent-4 (平台适配测试专家)
Scope: 各平台格式验证、字符限制、线程分割
"""

import pytest

from src.platform_adapter.linkedin_adapter import LinkedInAdapter
from src.platform_adapter.medium_adapter import MediumAdapter
from src.platform_adapter.quora_adapter import QuoraAdapter
from src.platform_adapter.reddit_adapter import RedditAdapter
from src.platform_adapter.twitter_adapter import TwitterAdapter


@pytest.mark.platform
def test_twitter_character_limit():
    """平台: Twitter 280字符限制."""
    adapter = TwitterAdapter()
    long_content = "a" * 300
    result = adapter.format_content(long_content)
    assert len(result.body) <= 280


@pytest.mark.platform
def test_twitter_thread_format():
    """平台: Twitter 线程格式验证."""
    adapter = TwitterAdapter()
    long_text = "This is a long content. " * 20
    result = adapter.format_content(long_text, format="thread")

    assert result.metadata.get("is_thread")
    assert "tweet_count" in result.metadata
    assert "1/" in result.body


@pytest.mark.platform
def test_medium_markdown_format():
    """平台: Medium Markdown格式验证."""
    adapter = MediumAdapter()
    content = "# Title\n\n## Subtitle\n\nContent here."
    result = adapter.format_content(content, title="Test")

    assert result.title == "Test"
    assert result.metadata.get("platform") == "medium"


@pytest.mark.platform
def test_reddit_markdown_conversion():
    """平台: Reddit Markdown转换验证."""
    adapter = RedditAdapter()
    content = "**Bold** and *italic* text"
    result = adapter.format_content(content)

    assert result.metadata.get("platform") == "reddit"


@pytest.mark.platform
def test_linkedin_professional_tone():
    """平台: LinkedIn专业语气调整."""
    adapter = LinkedInAdapter()
    content = "Check out these awesome tools!"
    result = adapter.format_content(content)

    assert result.metadata.get("platform") == "linkedin"
    assert len(result.body) <= 3000


@pytest.mark.platform
def test_quora_qa_format():
    """平台: Quora问答格式验证."""
    adapter = QuoraAdapter()
    content = "Q: What is SEO?\nA: SEO is..."
    result = adapter.format_content(content)

    assert result.metadata.get("platform") == "quora"


@pytest.mark.platform
def test_chinese_character_limits():
    """平台: 中文字符限制测试.

    Twitter historically counted CJK characters differently.
    Modern Twitter counts all characters as 1, but we test
    that the adapter handles CJK content correctly.
    """
    adapter = TwitterAdapter()

    # Test Chinese content (中文内容)
    chinese_content = "中" * 150  # 150 Chinese characters
    result = adapter.format_content(chinese_content)
    # Should be truncated to fit within limit
    assert len(result.body) <= 280
    assert result.metadata.get("platform") == "twitter"

    # Test Japanese content (日本語コンテンツ)
    japanese_content = "あ" * 150  # 150 Japanese hiragana
    result = adapter.format_content(japanese_content)
    assert len(result.body) <= 280

    # Test Korean content (한국어 콘텐츠)
    korean_content = "한" * 150  # 150 Korean characters
    result = adapter.format_content(korean_content)
    assert len(result.body) <= 280

    # Test mixed content (中英文混合内容)
    mixed_content = "Hello世界" * 50  # Mixed English and Chinese
    result = adapter.format_content(mixed_content)
    assert len(result.body) <= 280


@pytest.mark.platform
def test_twitter_truncate_preserves_mention():
    """平台: Twitter截断保留提及和话题标签."""
    adapter = TwitterAdapter()

    # Long content with mention and hashtag
    content = "This is a very long tweet that exceeds the character limit " * 5
    content += "@username #hashtag"

    result = adapter.format_content(content)
    assert len(result.body) <= 280
    # Truncation should add ellipsis
    assert result.body.endswith("...")


@pytest.mark.platform
def test_medium_code_block_preservation():
    """平台: Medium代码块保留测试."""
    adapter = MediumAdapter()

    content = """# Code Example

```python
def hello():
    print("Hello World")
```

Some text after code.
"""
    result = adapter.format_content(content, title="Code Test")

    assert result.title == "Code Test"
    assert "```python" in result.body
    assert result.metadata.get("platform") == "medium"


@pytest.mark.platform
def test_reddit_link_formatting():
    """平台: Reddit链接格式化测试."""
    adapter = RedditAdapter()

    content = "Check out [this link](https://example.com) for more info."
    result = adapter.format_content(content)

    assert "[this link]" in result.body or "https://example.com" in result.body
    assert result.metadata.get("platform") == "reddit"


@pytest.mark.platform
def test_linkedin_hashtag_extraction():
    """平台: LinkedIn话题标签提取测试."""
    adapter = LinkedInAdapter()

    content = "Great article about #AI and #MachineLearning! #Tech"
    result = adapter.format_content(content)

    # LinkedIn adapter should preserve hashtags
    assert "#AI" in result.body or "#AI".lower() in result.body.lower()
    assert result.metadata.get("platform") == "linkedin"
    assert len(result.body) <= 3000


@pytest.mark.platform
def test_quora_link_handling():
    """平台: Quora链接处理测试."""
    adapter = QuoraAdapter()

    content = """Q: What are the best SEO tools?

A: Here are some recommendations:

1. Tool A - https://example.com/tool-a
2. Tool B - https://example.com/tool-b

Hope this helps!
"""
    result = adapter.format_content(content)

    assert result.metadata.get("platform") == "quora"
    # Quora should preserve links
    assert "https://" in result.body


@pytest.mark.platform
def test_all_adapters_max_length():
    """平台: 所有适配器最大长度限制测试."""
    adapters = [
        (TwitterAdapter(), 280, "twitter"),
        (LinkedInAdapter(), 3000, "linkedin"),
        (MediumAdapter(), 50000, "medium"),
        (RedditAdapter(), 40000, "reddit"),
        (QuoraAdapter(), 10000, "quora"),
    ]

    long_content = "x" * 100000  # Very long content

    for adapter, max_len, platform in adapters:
        result = adapter.format_content(long_content)
        assert len(result.body) <= max_len, f"{platform} 超出最大长度限制"
        assert result.metadata.get("platform") == platform
