"""Tests for CLI module."""

from typer.testing import CliRunner

from src.cli import app

runner = CliRunner()


class TestCLICommands:
    """Test CLI commands."""

    def test_main_command(self):
        """Test main CLI command."""
        result = runner.invoke(app, ["--help"])
        assert result.exit_code == 0
        assert "GEO-SEO Optimizer" in result.output

    def test_keywords_command_help(self):
        """Test keywords command help."""
        result = runner.invoke(app, ["keywords", "--help"])
        assert result.exit_code == 0
        assert "关键词研究" in result.output or "keyword" in result.output.lower()

    def test_content_command_help(self):
        """Test content command help."""
        result = runner.invoke(app, ["content", "--help"])
        assert result.exit_code == 0
        assert "内容生成" in result.output or "content" in result.output.lower()

    def test_analytics_command_help(self):
        """Test analytics command help."""
        result = runner.invoke(app, ["analytics", "--help"])
        assert result.exit_code == 0
        assert "数据分析" in result.output or "analytics" in result.output.lower()

    def test_keywords_research_command(self):
        """Test keywords research command."""
        result = runner.invoke(app, ["keywords", "research", "test keyword"])
        # Should fail without API key but command should be recognized
        assert result.exit_code in [0, 1]  # 0 if mocked, 1 if requires API key

    def test_version_flag(self):
        """Test version flag - CLI may not support it."""
        result = runner.invoke(app, ["--version"])
        # CLI may not have --version flag
        assert result.exit_code in [0, 2]


class TestCLIErrorHandling:
    """Test CLI error handling."""

    def test_invalid_command(self):
        """Test invalid command."""
        result = runner.invoke(app, ["invalid-command"])
        assert result.exit_code != 0

    def test_missing_argument(self):
        """Test missing required argument."""
        result = runner.invoke(app, ["keywords", "research"])
        assert result.exit_code != 0
