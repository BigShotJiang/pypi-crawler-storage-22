"""Tests for platform adapter modules."""

import pytest

from src.platform_adapter.base_adapter import BaseAdapter, PlatformContent
from src.platform_adapter.linkedin_adapter import LinkedInAdapter
from src.platform_adapter.medium_adapter import MediumAdapter
from src.platform_adapter.quora_adapter import QuoraAdapter
from src.platform_adapter.reddit_adapter import RedditAdapter
from src.platform_adapter.twitter_adapter import TwitterAdapter


class TestBaseAdapter:
    """Test Base Adapter."""

    def test_base_adapter_is_abstract(self):
        """Test BaseAdapter cannot be instantiated directly."""
        with pytest.raises(TypeError):
            BaseAdapter()


class TestTwitterAdapter:
    """Test Twitter Adapter."""

    def test_initialization(self):
        """Test adapter initialization."""
        adapter = TwitterAdapter()
        assert adapter.get_max_length() == 280

    def test_format_content_simple(self):
        """Test formatting simple content."""
        adapter = TwitterAdapter()
        result = adapter.format_content("Hello World!")
        assert isinstance(result, PlatformContent)
        assert result.body == "Hello World!"
        assert result.metadata["platform"] == "twitter"

    def test_format_content_truncate(self):
        """Test content truncation."""
        adapter = TwitterAdapter()
        long_content = "a" * 300
        result = adapter.format_content(long_content)
        assert len(result.body) <= 280

    def test_format_thread(self):
        """Test thread formatting."""
        adapter = TwitterAdapter()
        long_content = "This is a long content. " * 20
        result = adapter.format_content(long_content, format="thread")
        assert result.metadata.get("is_thread")
        assert "1/" in result.body


class TestMediumAdapter:
    """Test Medium Adapter."""

    def test_initialization(self):
        """Test adapter initialization."""
        adapter = MediumAdapter()
        assert adapter.get_max_length() == 50000

    def test_format_content(self):
        """Test formatting content."""
        adapter = MediumAdapter()
        content = "# Title\n\n## Subtitle\n\nContent here."
        result = adapter.format_content(content, title="Test Title")
        assert isinstance(result, PlatformContent)
        assert result.title == "Test Title"
        assert result.metadata["platform"] == "medium"


class TestLinkedInAdapter:
    """Test LinkedIn Adapter."""

    def test_initialization(self):
        """Test adapter initialization."""
        adapter = LinkedInAdapter()
        assert adapter.get_max_length() == 3000

    def test_format_content(self):
        """Test formatting content."""
        adapter = LinkedInAdapter()
        content = "Check out these awesome tools!"
        result = adapter.format_content(content)
        assert isinstance(result, PlatformContent)
        assert result.metadata["platform"] == "linkedin"
        assert len(result.body) <= 3000


class TestRedditAdapter:
    """Test Reddit Adapter."""

    def test_initialization(self):
        """Test adapter initialization."""
        adapter = RedditAdapter()
        assert adapter.get_max_length() > 0

    def test_format_content(self):
        """Test formatting content."""
        adapter = RedditAdapter()
        content = "**Bold** and *italic* text"
        result = adapter.format_content(content)
        assert isinstance(result, PlatformContent)
        assert result.metadata["platform"] == "reddit"


class TestQuoraAdapter:
    """Test Quora Adapter."""

    def test_initialization(self):
        """Test adapter initialization."""
        adapter = QuoraAdapter()
        assert adapter.get_max_length() > 0

    def test_format_content(self):
        """Test formatting content."""
        adapter = QuoraAdapter()
        content = "Q: What is SEO?\nA: SEO is..."
        result = adapter.format_content(content)
        assert isinstance(result, PlatformContent)
        assert result.metadata["platform"] == "quora"
