"""GeoAgent core module."""
