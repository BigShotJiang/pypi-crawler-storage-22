"""Top-level package for geocif."""

__author__ = """Ritvik Sahajpal"""
__email__ = "ritvik@umd.edu"
__version__ = "0.3.96"

__all__ = ["ml", "cid", "viz"]
