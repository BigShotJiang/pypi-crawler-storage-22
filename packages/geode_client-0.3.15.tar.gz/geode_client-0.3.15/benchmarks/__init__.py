# Benchmarks for geode_client
