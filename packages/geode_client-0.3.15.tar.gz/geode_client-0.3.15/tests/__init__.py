"""Integration tests for Geode Python client."""
