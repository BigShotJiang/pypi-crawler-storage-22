# Integration tests for geode_client
