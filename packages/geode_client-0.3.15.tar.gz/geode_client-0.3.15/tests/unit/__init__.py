# Unit tests for geode_client
