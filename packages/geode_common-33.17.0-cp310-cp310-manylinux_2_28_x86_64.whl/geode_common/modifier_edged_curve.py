#
# Copyright (c) 2019 - 2025 Geode-solutions. All rights reserved.
#

import opengeode

from .lib64.geode_common_py_modifier_edged_curve import *
CommonModifierEdgedCurveLibrary.initialize()
