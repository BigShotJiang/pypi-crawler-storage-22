#
# Copyright (c) 2019 - 2026 Geode-solutions. All rights reserved.
#

import opengeode

from .lib64.geode_common_py_orchestrator import *

CommonOrchestratorCommonLibrary.initialize()
