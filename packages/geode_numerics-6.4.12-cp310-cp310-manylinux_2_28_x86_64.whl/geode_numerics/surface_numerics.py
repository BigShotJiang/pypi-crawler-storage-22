#
# Copyright (c) 2019 - 2026 Geode-solutions. All rights reserved.
#

import opengeode

from .lib64.geode_numerics_py_surface import *
NumericsSurfaceLibrary.initialize()
