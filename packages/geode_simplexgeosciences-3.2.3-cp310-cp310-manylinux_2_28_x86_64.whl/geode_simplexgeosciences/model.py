#
# Copyright (c) 2019 - 2025 Geode-solutions. All rights reserved.
#

import opengeode
import opengeode_geosciences
import geode_simplex

from .lib64.geode_simplexgeosciences_py_model import *
SimplexGeosciencesModelLibrary.initialize()
