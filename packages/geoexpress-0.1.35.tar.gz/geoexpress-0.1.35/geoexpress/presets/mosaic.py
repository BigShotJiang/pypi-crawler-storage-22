MOSAIC_BASIC = {
    "mosaic": True,
    "overlap": "blend"
}

MOSAIC_FAST = {
    "mosaic": True,
    "overlap": "crop"
}
