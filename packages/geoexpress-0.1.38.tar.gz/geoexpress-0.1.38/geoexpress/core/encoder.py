
# from typing import Optional, Dict
# from geoexpress.core.base import GeoExpressCommand
# from geoexpress.core.format_detect import detect_format_from_output

# _encoder = GeoExpressCommand("mrsidgeoencoder")


# def encode(
#     input: str,
#     output: str,
#     options: Optional[Dict] = None,
#     format: Optional[str] = None,
#     password: Optional[str] = None,
# ) -> str:

#     args = ["-i", input, "-o", output]

#     # ------------------------------------------------
#     # Output format resolution priority
#     # 1. password → mg3
#     # 2. explicit format argument
#     # 3. auto-detect from output extension
#     # ------------------------------------------------

#     if password:
#         args.extend(["-of", "mg3", "-pwd", password])

#     else:
#         fmt = format.lower() if format else detect_format_from_output(output)

#         if fmt:
#             # NO validation – GeoExpress CLI decides
#             args.extend(["-of", fmt])

#     # ------------------------------------------------
#     # Encoder options
#     # ------------------------------------------------
#     if options:
#         for k, v in options.items():
#             flag = f"-{k}"

#             if isinstance(v, bool):
#                 if v:
#                     args.append(flag)
#                 continue

#             args.extend([flag, str(v)])

#     return _encoder.run(args)

from typing import Optional, Dict
from geoexpress.core.base import GeoExpressCommand
from geoexpress.core.format_detect import detect_format_from_output
from geoexpress.core.validation import validate_supported_file

_encoder = GeoExpressCommand("mrsidgeoencoder")


def encode(
    input: str,
    output: str,
    options: Optional[Dict] = None,
    format: Optional[str] = None,
    password: Optional[str] = None,
) -> str:

    # -------------------------------
    # Validate input/output extensions
    # -------------------------------
    validate_supported_file(input, "input")
    validate_supported_file(output, "output")

    args = ["-i", input, "-o", output]

    # -------------------------------
    # Output format resolution
    # Priority:
    # 1. Password → MG3
    # 2. Explicit format argument
    # 3. Auto-detect from output extension
    # -------------------------------
    if password:
        args.extend(["-of", "mg3", "-pwd", password])

    else:
        fmt = format.lower() if format else detect_format_from_output(output)

        if fmt:
            args.extend(["-of", fmt])

    # -------------------------------
    # Encoder options
    # -------------------------------
    if options:
        for k, v in options.items():
            flag = f"-{k}"

            if isinstance(v, bool):
                if v:
                    args.append(flag)
                continue

            args.extend([flag, str(v)])

    return _encoder.run(args)
