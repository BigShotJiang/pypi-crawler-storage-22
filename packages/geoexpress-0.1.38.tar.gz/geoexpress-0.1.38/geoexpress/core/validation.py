from pathlib import Path
from geoexpress.core.format_detect import EXTENSION_TO_FORMAT


def validate_supported_file(path: str, role: str):
    """
    Validate input/output file extension.

    role: 'input' or 'output'
    """
    ext = Path(path).suffix.lower()

    if not ext:
        raise ValueError(
            f"{role.capitalize()} file has no extension: {path}"
        )

    if ext not in EXTENSION_TO_FORMAT:
        allowed = ", ".join(sorted(EXTENSION_TO_FORMAT.keys()))
        raise ValueError(
            f"Unsupported {role} file format '{ext}'.\n"
            f"Allowed formats: {allowed}"
        )
