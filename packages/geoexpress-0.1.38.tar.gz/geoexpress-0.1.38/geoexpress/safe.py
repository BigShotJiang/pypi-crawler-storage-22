from typing import Callable
import functools

def _safe_call(func: Callable):
    """
    Generic decorator to suppress tracebacks
    and show only user-friendly error messages.
    """
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            print(f"❌ {e}")
            return None
    return wrapper


from geoexpress.core.encoder import encode
from geoexpress.core.decoder import decode
from geoexpress.core.info import info_parsed
from geoexpress.core.metadata import set_metadata, get_metadata
from geoexpress.core.utilities import locking_code
from geoexpress.core.security import lock_image, unlock_image

encode_safe = _safe_call(encode)
decode_safe = _safe_call(decode)
info_safe = _safe_call(info_parsed)
set_metadata_safe = _safe_call(set_metadata)
get_metadata_safe = _safe_call(get_metadata)
locking_code_safe = _safe_call(locking_code)
lock_image_safe = _safe_call(lock_image)
unlock_image_safe = _safe_call(unlock_image)
