# GeoExpress Python Package

•  GeoExpress:  Python Package for compression of Satellite, Aerial and Drone Imgery

•  The GeoExpress Python Package provides a thin, Pythonic wrapper around the GeoExpress engine, enabling programmatic access to MrSID raster compression, decompression, metadata management, and security operations. It is designed for automation, batch pipelines, and integration into larger GIS, remote sensing, and GeoAI workflows.

-   MrSID raster compression & decompression\
-   JPEG2000 (JP2 / GMLJP2) encoding\
-   NITF / NITFJP2 workflows\
-   LiDAR (LAZ ↔ SID) conversion\
-   Metadata management\
-   Password protection (locking/unlocking)\
-   Batch automation

------------------------------------------------------------------------

# Installation

pip install geoexpress

## Python Compatibility

-   Python 3.9\
-   Python 3.10\
-   Python 3.11\
-   Python 3.12

------------------------------------------------------------------------

# Prerequisites

-   GeoExpress Desktop or Server must be installed
-   A valid and activated Float or Local license must be available
-   GeoExpress binaries must be accessible via system PATH

------------------------------------------------------------------------

# Supported Conversions

## TIFF → MG2 / MG3 / MG4 (MrSID)

``` python
from geoexpress import encode_safe

encode_safe("c:/data/input.tif", "c:/data/output.sid", format="MG4", options={"cr": 20})
encode_safe("c:/data/input.tif", "c:/data/output.sid", password="1234")  # Auto MG3
```

## TIFF → JP2 / GMLJP2

``` python
encode_safe("c:/data/input.tif", "c:/data/output.jp2", options={"cr": 10})
encode_safe("c:/data/input.tif", "c:/data/output.jp2", format="JP2")
```

## TIFF → NITF / NITFJP2

``` python
encode_safe("c:/data/input.tif", "c:/data/output.ntf")
encode_safe("c:/data/input.tif", "c:/data/output.ntf", format="NITFJP2")
```

------------------------------------------------------------------------

# SID Decoding (Recommended Method)

SID conversions, use `decode()` for


## SID → TIFF

``` python
from geoexpress import decode_safe

decode_safe(
    input=r"C:\data\input.sid",
    output=r"C:\data\output.tif"
)
```

## SID → JP2

``` python
decode_safe(
    input=r"C:\data\input.sid",
    output=r"C:\data\output.jp2"
)
```

## SID → NITF

``` python
decode_safe(
    input=r"C:\data\input.sid",
    output=r"C:\data\output.ntf"
)
```

------------------------------------------------------------------------

## JP2 → SID / TIFF

``` python
from geoexpress import encode_safe

encode_safe("c:/data/input.jp2", "c:/data/output.sid", format="MG4")
encode_safe("c:/data/input.jp2", "c:/data/output.tif")
```

## NITF → TIFF

``` python
encode_safe("c:/data/input.ntf", "c:/data/output.tif")
```

------------------------------------------------------------------------

# LiDAR Support

## LAZ ↔ SID

``` python
from geoexpress import encode_safe

encode_safe("c:/data/input.laz", "c:/data/output.sid")
```

------------------------------------------------------------------------

# Image Information

``` python
from geoexpress import info_parsed

info = info_parsed("c:/data/image.sid")
print(info["parsed"])
```

------------------------------------------------------------------------

# Metadata

## Set Metadata

``` python
from geoexpress import set_metadata_safe

set_metadata_safe("c:/data/image.sid", "Author", "GeoExpress Package")
```

## Get Metadata

``` python
from geoexpress import get_metadata_safe

print(get_metadata_safe("c:/data/image.sid"))
```

------------------------------------------------------------------------

# Lock / Unlock

## Lock

``` python
from geoexpress import lock_image_safe

lock_image_safe("c:/data/input.sid", "c:/data/locked.sid", "1234")
```

## Unlock

``` python
from geoexpress import unlock_image_safe

unlock_image_safe("c:/data/locked.sid", "c:/data/unlocked.sid", "1234")
```

------------------------------------------------------------------------

# Batch Encoding

``` python
from geoexpress.batch import batch_encode_safe

jobs = [
    {
        "input": "c:/data/input_a.tif",
        "output": "c:/data/output_a.sid",
        "options": {"cr": 20}
    },
    {
        "input": "c:/data/input_b.tif",
        "output": "c:/data/output_b.sid",
        "options": {"lossless": True}
    }
]

results = batch_encode_safe(jobs)
print(results)
```

------------------------------------------------------------------------

# CLI

``` bash
geoexpress encode input.tif output.sid --of mg4 --cr 20
geoexpress info output.sid
geoexpress meta set output.sid Author=GeoExpress
```

------------------------------------------------------------------------

# Troubleshooting

## License Not Found

-   Ensure GeoExpress is installed\
-   Verify license activation\
-   Confirm license visibility for executing user

## Binary Not Found

-   Confirm installation path\
-   Ensure GeoExpress is added to system PATH

------------------------------------------------------------------------

# Summary

GeoExpress enables enterprise-grade raster compression, LiDAR workflows,
metadata control, and secure distribution in automated geospatial
pipelines.
