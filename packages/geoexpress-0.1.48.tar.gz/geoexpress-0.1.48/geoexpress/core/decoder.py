# from typing import Optional
# from geoexpress.core.base import GeoExpressCommand
# from geoexpress.core.guard import ensure_geoexpress_ready

# _decoder = GeoExpressCommand("mrsidgeodecode")


# def decode(
#     input: str,
#     output: str,
#     password: Optional[str] = None
# ) -> str:
#     """
#     Decode MrSID to GeoTIFF.
#     """

#     args = [
#         "-i", input,
#         "-o", output
#     ]

#     if password:
#         args.extend(["-pwd", password])

#     return _decoder.run(args)

from typing import Optional
from geoexpress.core.base import GeoExpressCommand
from geoexpress.core.guard import ensure_geoexpress_ready
from geoexpress.core.validation import validate_supported_file

_decoder = GeoExpressCommand("mrsidgeodecode")


def decode(
    input: str,
    output: str,
    password: Optional[str] = None
) -> str:
    """
    Decode MrSID / JP2 / NITF to TIFF.
    """

    # ---- License & installation check ----
    ensure_geoexpress_ready()

    # ---- Validate input/output ----
    validate_supported_file(input, "input")
    validate_supported_file(output, "output")

    args = ["-i", input, "-o", output]

    if password:
        args.extend(["-pwd", password])

    return _decoder.run(args)
