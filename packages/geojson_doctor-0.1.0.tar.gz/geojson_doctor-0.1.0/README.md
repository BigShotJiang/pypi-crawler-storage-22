# Geojson Doctor

A Python utility library for cleaning, normalizing, and transforming GeoJSON geometries.

Developed at Concordia university in Canada as part of the research group from the Next Generation Cities Institute.

It provides functions to:

- Fix invalid geometries.
- Ensure proper polygon ring orientation.
- Removes redundant vertices.
- Add ID field based on properties
- Reproject geometries between coordinate reference systems (CRS).
- Convert single-polygon MultiPolygons to Polygons.
- Remove interior points from Polygons

## Usage

```bash
pip install geojson-doctor
```

### Imports
```python
from geojson_doctor import fix
from geojson_doctor.transform import change_crs, multipolygon_to_polygon, remove_interior
from geojson_doctor.utilities import generate_ids
```

##### Simple example
```python
with open('data/example.geojson', encoding='utf-8') as f:
  data = json.load(f)

data = fix(data)
```


##### Full example
```python
with open('data/example.geojson', encoding='utf-8') as f:
  data = json.load(f)

data = generate_ids(data, from_property="name")
data = change_crs(data, 'EPSG:32188', 'EPSG:4326')
data = multipolygon_to_polygon(data, method='keep_first')
data = remove_interior(data)
data = fix(data, workflow=['fix_validity'])
```

## Logging

This package uses Python’s built-in logging to provide warnings whenever geometries are modified.

Modifications to geometry are all applied as a warning. Use logging level to suppress warnings.

```python
import logging

logging.getLogger().setLevel(logging.ERROR)
```
