"""
Fixer functions
SPDX - License - Identifier: LGPL - 3.0 - or -later
Copyright © 2026 Concordia CERC group
Project Coder Connor Brackley connor.brackley@concordia.ca
"""

import logging

from shapely.geometry import mapping, shape
from shapely.lib import make_valid
from shapely.ops import orient
from shapely.validation import explain_validity

FIXERS = {}


def register_fixer(func):
  """
  Register a geometry fixer function.

  :param func: Geometry-fixing function to register.
  :return: The original function.
  """
  FIXERS[func.__name__] = func
  return func


@register_fixer
def fix_validity(geom: dict, name: str) -> dict:
  """
  Applies shapely's make_valid function to repair an invalid geometry.

  :param geom: GeoJSON-like dictionary representing a geometry.
  :param name: Identifier used for logging.
  :return: GeoJSON-like dictionary of the original or repaired geometry.
  """

  shapley_object = shape(geom)

  if not shapley_object.is_valid:
    issue = explain_validity(shapley_object)
    logging.warning('%s is is not valid for reason %s, fixed', name, issue)
    shapley_object = make_valid(shapley_object)

  return mapping(shapley_object)


@register_fixer
def fix_orientation(geom: dict, name: str) -> dict:
  """
  Applies Shaply's `orient` function to enforce polygon ring orientation conventions. 
  Ensures polygon exterior rings are counter-clockwise (CCW) and interior rings (holes) 
  are clockwise (CW). 

  :param geom_dict: GeoJSON-like dictionary representing a Polygon or MultiPolygon.
  :param name: Identifier used for logging.
  :return: GeoJSON-like dictionary with corrected ring orientations.
  """
  shapley_object = shape(geom)
  oriented = orient(shapley_object, sign=1.0)

  if not shapley_object.equals_exact(oriented):
    logging.warning("%s: polygon does not follow orientation convention, fixed", name)

  return mapping(oriented)


@register_fixer
def fix_redundant_vertices(geom, name: str):
  """
  Applies shapely's `simplify` to simplify geometry using the Douglas-Peucker algorithm.
  Removes redundant vertices (e.g., duplicate and collinear points) using
  geometry simplification.

  :param geom_dict: GeoJSON-like dictionary representing a Polygon or MultiPolygon.
  :param name: Identifier used for logging.
  :return: GeoJSON-like dictionary with simplified geometry
  """
  shapley_object = shape(geom)
  simplified = shapley_object.simplify(0)

  if not shapley_object.equals_exact(simplified):
    logging.warning("%s: redundant vertices removed", name)

  return mapping(simplified)
