"""
Change CRS tranformer
SPDX - License - Identifier: LGPL - 3.0 - or -later
Copyright © 2026 Concordia CERC group
Project Coder Connor Brackley connor.brackley@concordia.ca
"""

from pyproj import Transformer
from shapely.ops import transform
from shapely.geometry import shape, mapping

def change_crs(geojson: dict, source_crs: str, destination_crs: str) -> dict:
  """
  Reproject all geometries in a GeoJSON from one CRS to another.

  :param geojson: GeoJSON dictionary 
  :param source_crs: Source coordinate reference system (CRS), e.g., "EPSG:4326".
  :param destination_crs: Destination coordinate reference system (CRS), e.g., "EPSG:3857".
  :return: A new GeoJSON dictionary with all features reprojected to `destination_crs`.
  """

  crs_transformer = Transformer.from_crs(source_crs, destination_crs, always_xy=True)

  new_geojson = { **geojson, "features": [] }
  for feature in geojson["features"]:
    geom = feature["geometry"]

    geom = _transformer(geom, crs_transformer)

    new_feature = { **feature, "geometry": geom }
    new_geojson["features"].append(new_feature)

  return new_geojson


def _transformer(geom: dict, crs_transformer: Transformer) -> dict:
  """
  Transform a GeoJSON geometry using a pyproj Transformer.

  :param geom: A GeoJSON geometry dictionary.
  :param crs_transformer: A pyproj.Transformer instance.
  :return: The transformed geometry as a GeoJSON-compatible dictionary.
  """
  shapley_object = shape(geom)
  geom_transformed = transform(crs_transformer.transform, shapley_object)
  return mapping(geom_transformed)
