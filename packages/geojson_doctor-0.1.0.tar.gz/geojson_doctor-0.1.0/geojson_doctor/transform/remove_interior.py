"""
remove interior tranformer
SPDX - License - Identifier: LGPL - 3.0 - or -later
Copyright © 2026 Concordia CERC group
Project Coder Connor Brackley connor.brackley@concordia.ca
"""

import logging
from shapely import MultiPolygon, Polygon
from shapely.geometry import mapping, shape

from geojson_doctor.helpers.helpers import get_id, check_polygon_multipolygon


def remove_interior(geojson: dict):
  """
  Remove all interior rings (holes) from Polygon and MultiPolygon geometries.

  'id' field is used for logging. 'id' field missing logging will display index.

  :param geojson: GeoJSON dictionary
  :return: GeoJSON dictionary containing only exterior coordinates.
  """

  new_geojson = {**geojson, "features": []}
  for i, feature in enumerate(geojson["features"]):
    geom = feature["geometry"]
    name = get_id(feature, i)

    geom = _transformer(geom, name)

    new_feature = {**feature, "geometry": geom}
    new_geojson["features"].append(new_feature)

  return new_geojson


def _transformer(geom: dict, name: str) -> dict:
  """
  Remove all interior rings (holes) from a Polygon or MultiPolygon geometry.

  :param geom: GeoJSON-like dictionary representing a Polygon or MultiPolygon.
  :param name: Name of the feature (e.g., building) for logging purposes.
  :return: GeoJSON-like dictionary with interiors removed.
  """

  shapely_object = shape(geom)
  shapely_object = check_polygon_multipolygon(shapely_object, name, "remove_interior")

  if isinstance(shapely_object, Polygon):
    if shapely_object.interiors:
      logging.warning("%s: interior rings removed from polygon", name)
    cleaned_geom = Polygon(shapely_object.exterior)

  else:

    cleaned_polygons = []
    for i, poly in enumerate(shapely_object.geoms):
      if poly.interiors:
        logging.warning(
            "%s: interior rings removed from MultiPolygon, polygon #%d",
            name, i
        )
      cleaned_polygons.append(Polygon(poly.exterior))
    cleaned_geom = MultiPolygon(cleaned_polygons)

  return mapping(cleaned_geom)
