"""
Test fix functions
SPDX - License - Identifier: LGPL - 3.0 - or -later
Copyright © 2026 Concordia CERC group
Project Coder Connor Brackley connor.brackley@concordia.ca
"""

import json
from pathlib import Path
from copy import deepcopy

import pytest
from shapely import Polygon
from shapely.geometry import shape

from geojson_doctor.fix.fix import fix
from geojson_doctor.fix.fix_functions import fix_redundant_vertices, fix_orientation, fix_validity


@pytest.fixture(scope="session")
def geojson():
  """
  Load GeoJSON test data
  """
  path = Path(__file__).parent / "data" / "fix_polygon.geojson"
  with path.open() as f:
    return json.load(f)


def test_fix_validity(geojson):  # pylint: disable=redefined-outer-name
  """
  Test fix_validity correctly repairs invalid geometries.

  :param geojson: GeoJSON test fixture
  """
  feature = geojson['features'][0]
  geom = feature['geometry']
  name = feature['id']

  fixed_geom = fix_validity(geom, name)
  fixed_shapely = shape(fixed_geom)

  assert fixed_shapely.is_valid, "Geometry should be valid after fix_validity"


def test_fix_orientation(geojson):  # pylint: disable=redefined-outer-name
  """
  Test fix_orentation reorients polygon exteriors to counter-clockwise.

  :param geojson: GeoJSON test fixture
  """
  feature = geojson['features'][0]
  geom = feature['geometry']
  name = feature['id']
  fixed = fix_orientation(geom, name)
  fixed_shapely = shape(fixed)

  assert isinstance(fixed_shapely, Polygon)
  assert fixed_shapely.exterior.is_ccw


def test_fix_redundant_vertices(geojson):  # pylint: disable=redefined-outer-name
  """
  Test fix_redundant_vertices removes consecutive duplicate coordinates.

  :param geojson: GeoJSON test fixture
  """
  feature = geojson['features'][0]
  geom = feature['geometry']
  name = feature['id']
  fixed = fix_redundant_vertices(geom, name)
  fixed_shapely = shape(fixed)

  assert isinstance(fixed_shapely, Polygon)
  coords = list(fixed_shapely.exterior.coords)
  for i in range(1, len(coords)):
    assert coords[i] != coords[i - 1]


def test_fix_input_mutation(geojson):  # pylint: disable=redefined-outer-name
  """
  Test to ensure input data is not mutated by fix functions

  :param geojson: GeoJSON test fixture
  """
  copy_geojson = deepcopy(geojson)
  fix(geojson)
  assert copy_geojson == geojson, 'Function fix modified input data'
