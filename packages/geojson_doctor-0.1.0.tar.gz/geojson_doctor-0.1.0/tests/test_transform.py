"""
Test transform functions
SPDX - License - Identifier: LGPL - 3.0 - or -later
Copyright © 2026 Concordia CERC group
Project Coder Connor Brackley connor.brackley@concordia.ca
"""

import json
from pathlib import Path
from copy import deepcopy

import pytest
from shapely import Polygon
from shapely.geometry import shape

from geojson_doctor.transform import change_crs, remove_interior, multipolygon_to_polygon


@pytest.fixture(scope="session")
def geojson():
  """
  Load GeoJSON test data
  """
  path = Path(__file__).parent / "data" / "interior.geojson"
  with path.open() as f:
    return json.load(f)


@pytest.fixture(scope="session")
def multipolygon_geojson():
  """
  Load GeoJSON test data
  """
  path = Path(__file__).parent / "data" / "multipolygon.geojson"
  with path.open() as f:
    return json.load(f)


def test_change_crs(geojson):  # pylint: disable=redefined-outer-name
  """
  Test change_crs results in the same area

  :param geojson: GeoJSON test fixture
  """
  original_shapely = shape(geojson['features'][0]['geometry'])

  fixed_geojson = change_crs(geojson, 'EPSG:32188', 'EPSG:4326')
  fixed_shapely = shape(fixed_geojson['features'][0]['geometry'])

  assert original_shapely != fixed_shapely, 'Geojson geometry was not modified by change_crs'

  reverted_geojson = change_crs(fixed_geojson, 'EPSG:4326', 'EPSG:32188')
  reverted_shaply = shape(reverted_geojson['features'][0]['geometry'])

  assert original_shapely.equals_exact(
      reverted_shaply, tolerance=1e-6), 'Geojson do not match after reverting to and from crs'


def test_remove_interior(geojson):  # pylint: disable=redefined-outer-name
  """
  Test remove_interior removes interior rings from polygons

  :param geojson: GeoJSON test fixture
  """
  cleaned_geojson = remove_interior(geojson)
  cleaned_shapely = shape(cleaned_geojson['features'][0]['geometry'])

  assert isinstance(cleaned_shapely, Polygon)
  assert len(cleaned_shapely.interiors) == 0, "Interior rings were not removed"


def test_multipolygon_to_polygon(multipolygon_geojson):  # pylint: disable=redefined-outer-name
  """
  Test converting MultiPolygon geometries to Polygon.

  :param multipolygon_geojson: GeoJSON test fixture
  """
  cleaned_geojson = multipolygon_to_polygon(multipolygon_geojson)
  converted_polygon = shape(cleaned_geojson['features'][0])

  assert isinstance(converted_polygon, Polygon), 'Multipolygon with single polygon was not converted to polygon'


def test_transform_input_mutation(geojson, multipolygon_geojson):  # pylint: disable=redefined-outer-name
  """
  Test to ensure input data is not mutated by transform functions

  :param geojson: GeoJSON test fixture
  :param multipolygon_geojson: GeoJSON test fixture
  """
  copy_geojson = deepcopy(geojson)
  copy_multipolygon_geojson = deepcopy(multipolygon_geojson)

  change_crs(geojson, 'EPSG:32188', 'EPSG:4326')
  assert copy_geojson == geojson, 'Function change_crs mutated input data'

  remove_interior(geojson)
  assert copy_geojson == geojson, 'Function remove_interior mutated input data'

  multipolygon_to_polygon(multipolygon_geojson)
  assert copy_multipolygon_geojson == multipolygon_geojson, 'Function multipolygon_geojson mutated input data'
