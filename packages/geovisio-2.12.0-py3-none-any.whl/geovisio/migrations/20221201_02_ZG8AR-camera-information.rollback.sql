-- add-account
-- depends: 20221201_01_wpCGc-initial-schema

-- the camera info has been deprecated since versions > 2.7.1__. Newer versions uses data from Geo-picture tag reader directly.
DROP TABLE IF EXISTS cameras;
