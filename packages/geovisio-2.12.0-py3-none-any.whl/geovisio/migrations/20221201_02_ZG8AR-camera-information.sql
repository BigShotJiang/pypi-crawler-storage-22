-- add-account
-- depends: 20221201_01_wpCGc-initial-schema

-- the camera info has been deprecated since versions > 2.7.1__. Newer versions uses data from Geo-picture tag reader directly.
CREATE TABLE cameras(
	model VARCHAR PRIMARY KEY,
	sensor_width FLOAT NOT NULL
);

CREATE INDEX cameras_model_idx ON cameras USING GIST(model gist_trgm_ops);
