from pydantic import BaseModel
from typing import Optional, List
from flask import url_for


class Link(BaseModel):
    rel: str
    type: str
    title: Optional[str] = None
    href: str
    method: Optional[str] = None
    attributes: Optional[List[str]] = None


def make_link(
    rel: str,
    route: str,
    title: Optional[str] = None,
    type: str = "application/json",
    method: Optional[str] = None,
    attributes: Optional[List[str]] = None,
    **args,
):
    kwargs = {"title": title} if title else {}  # do not pass none title, to know if it has been set or not
    return Link(rel=rel, type=type, href=url_for(route, **args, _external=True), method=method, attributes=attributes, **kwargs)
