import json

class Geoviz:
    """
    A Python wrapper for the geoviz JavaScript library.
    Allows creating maps by chaining commands and rendering them to an HTML file.
    """
    def __init__(self, **kwargs):
        self.commands = []
        self.commands.append({"name": "create", "args": kwargs})

    def _add_command(self, name, args):
        self.commands.append({"name": name, "args": args})
        return self

    # Marks
    def outline(self, **kwargs):
        return self._add_command("outline", kwargs)

    def graticule(self, **kwargs):
        return self._add_command("graticule", kwargs)

    def path(self, **kwargs):
        return self._add_command("path", kwargs)

    def header(self, **kwargs):
        return self._add_command("header", kwargs)

    def footer(self, **kwargs):
        return self._add_command("footer", kwargs)

    def circle(self, **kwargs):
        return self._add_command("circle", kwargs)

    def square(self, **kwargs):
        return self._add_command("square", kwargs)

    def spike(self, **kwargs):
        return self._add_command("spike", kwargs)

    def text(self, **kwargs):
        return self._add_command("text", kwargs)

    def tile(self, **kwargs):
        return self._add_command("tile", kwargs)

    def scalebar(self, **kwargs):
        return self._add_command("scalebar", kwargs)

    def north(self, **kwargs):
        return self._add_command("north", kwargs)

    def plot(self, **kwargs):
        return self._add_command("plot", kwargs)

    def tissot(self, **kwargs):
        return self._add_command("tissot", kwargs)

    def rhumbs(self, **kwargs):
        return self._add_command("rhumbs", kwargs)

    def earth(self, **kwargs):
        return self._add_command("earth", kwargs)

    def empty(self, **kwargs):
        return self._add_command("empty", kwargs)

    def halfcircle(self, **kwargs):
        return self._add_command("halfcircle", kwargs)

    def symbol(self, **kwargs):
        return self._add_command("symbol", kwargs)

    def grid(self, **kwargs):
        return self._add_command("grid", kwargs)

    # Plot shortcuts (sugar syntax for plot({type: ...}))
    def choro(self, **kwargs):
        return self._add_command("plot", {"type": "choro", **kwargs})

    def typo(self, **kwargs):
        return self._add_command("plot", {"type": "typo", **kwargs})

    def prop(self, **kwargs):
        return self._add_command("plot", {"type": "prop", **kwargs})

    def propchoro(self, **kwargs):
        return self._add_command("plot", {"type": "propchoro", **kwargs})

    def proptypo(self, **kwargs):
        return self._add_command("plot", {"type": "proptypo", **kwargs})

    def picto(self, **kwargs):
        return self._add_command("plot", {"type": "picto", **kwargs})

    def bertin(self, **kwargs):
        return self._add_command("plot", {"type": "bertin", **kwargs})

    # Legends
    def legend_circles_nested(self, **kwargs):
        return self._add_command("legend.circles_nested", kwargs)

    def legend_circles(self, **kwargs):
        return self._add_command("legend.circles", kwargs)

    def legend_squares(self, **kwargs):
        return self._add_command("legend.squares", kwargs)

    def legend_squares_nested(self, **kwargs):
        return self._add_command("legend.squares_nested", kwargs)

    def legend_circles_half(self, **kwargs):
        return self._add_command("legend.circles_half", kwargs)

    def legend_spikes(self, **kwargs):
        return self._add_command("legend.spikes", kwargs)

    def legend_mushrooms(self, **kwargs):
        return self._add_command("legend.mushrooms", kwargs)

    def legend_choro_vertical(self, **kwargs):
        return self._add_command("legend.choro_vertical", kwargs)

    def legend_choro_horizontal(self, **kwargs):
        return self._add_command("legend.choro_horizontal", kwargs)

    def legend_typo_vertical(self, **kwargs):
        return self._add_command("legend.typo_vertical", kwargs)

    def legend_typo_horizontal(self, **kwargs):
        return self._add_command("legend.typo_horizontal", kwargs)

    def legend_symbol_vertical(self, **kwargs):
        return self._add_command("legend.symbol_vertical", kwargs)

    def legend_symbol_horizontal(self, **kwargs):
        return self._add_command("legend.symbol_horizontal", kwargs)

    def legend_box(self, **kwargs):
        return self._add_command("legend.box", kwargs)

    # Effects
    def effect_blur(self, **kwargs):
        return self._add_command("effect.blur", kwargs)

    def effect_shadow(self, **kwargs):
        return self._add_command("effect.shadow", kwargs)

    def effect_radialGradient(self, **kwargs):
        return self._add_command("effect.radialGradient", kwargs)

    def effect_clipPath(self, **kwargs):
        return self._add_command("effect.clipPath", kwargs)

    def get_config(self):
        """
        Returns the configuration as a JSON-compatible list of commands.
        """
        def process_args(args):
            new_args = {}
            for k, v in args.items():
                if isinstance(v, str) and (v.strip().startswith("(") or v.strip().startswith("function") or "=>" in v):
                     new_args[k] = {"__js_func__": v}
                elif isinstance(v, dict):
                    new_args[k] = process_args(v)
                else:
                    new_args[k] = v
            return new_args

        processed_commands = []
        for cmd in self.commands:
            processed_commands.append({"name": cmd["name"], "args": process_args(cmd["args"])})
        
        return processed_commands

    def to_json(self):
        """
        Returns the configuration as a JSON string.
        """
        return json.dumps(self.get_config())

    def render_html(self, filename="map.html"):
        """
        Renders the map to an HTML file.
        """
        json_commands = self.to_json()
        
        html_content = f"""
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8" />
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Tangerine"/>
  <script src="https://cdn.jsdelivr.net/npm/d3@7"></script>
  <script src="https://cdn.jsdelivr.net/npm/geoviz@0.9.8"></script>
</head>
<body>
<script>
  const commands = {json_commands};
  let svg;

  // Helper to revive functions
  function revive(obj) {{
    if (typeof obj === 'object' && obj !== null) {{
      if (obj.hasOwnProperty('__js_func__')) {{
         try {{
            return eval(obj['__js_func__']);
         }} catch (e) {{
            console.error("Failed to eval function:", obj['__js_func__'], e);
            return null;
         }}
      }} else {{
         for (let key in obj) {{
            obj[key] = revive(obj[key]);
         }}
      }}
    }}
    return obj;
  }}

  const revivedCommands = revive(commands);

  revivedCommands.forEach(cmd => {{
    if (cmd.name === "create") {{
      svg = geoviz.create(cmd.args);
    }} else {{
      const parts = cmd.name.split(".");
      if (parts.length === 1) {{
         if (svg[parts[0]]) {{
            svg[parts[0]](cmd.args);
         }} else {{
            console.warn("Method " + parts[0] + " not found");
         }}
      }} else if (parts.length === 2) {{
         if (svg[parts[0]] && svg[parts[0]][parts[1]]) {{
            svg[parts[0]][parts[1]](cmd.args);
         }} else {{
            console.warn("Method " + cmd.name + " not found");
         }}
      }}
    }}
  }});

  if (svg) {{
    document.body.appendChild(svg.render());
  }}
</script>
</body>
</html>
"""
        with open(filename, "w") as f:
            f.write(html_content)
        print(f"Map saved to {filename}")
