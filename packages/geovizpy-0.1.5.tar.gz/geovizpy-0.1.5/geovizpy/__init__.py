"""
Geovizpy: A Python wrapper for the geoviz JavaScript library.
"""

from .geoviz import Geoviz

__all__ = ["Geoviz"]
