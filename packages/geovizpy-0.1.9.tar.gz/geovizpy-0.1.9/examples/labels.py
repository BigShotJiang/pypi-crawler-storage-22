"""Example script for adding text labels to a map."""

import json
import os
from geovizpy import Geoviz

# Define output directory
output_dir = os.path.join(os.path.dirname(__file__), "html")
os.makedirs(output_dir, exist_ok=True)

data_path = os.path.join(os.path.dirname(__file__), "data", "world.json")
try:
    with open(data_path) as f:
        world_data = json.load(f)
except FileNotFoundError:
    print(f"{data_path} not found.")
    world_data = {}

countries_to_label = ["Brazil", "China", "United States", "France", "South Africa", "Australia"]
labeled_features = [f for f in world_data.get("features", []) if f["properties"].get("NAMEen") in countries_to_label]
labeled_data = {"type": "FeatureCollection", "features": labeled_features}

viz = Geoviz(projection="EqualEarth")
viz.outline()
viz.graticule(stroke="white", strokeWidth=0.4)

viz.path(datum=world_data, fill="#e0e0e0", stroke="white")

viz.text(
    data=labeled_data,
    text="NAMEen",
    fill="#333",
    fontSize=14,
    fontWeight="bold",
    stroke="white",
    strokeWidth=3,
    paintOrder="stroke"
)



viz.header(text="Map with Labels", fontSize=20)
viz.render_html(os.path.join(output_dir, "labels.html"))
