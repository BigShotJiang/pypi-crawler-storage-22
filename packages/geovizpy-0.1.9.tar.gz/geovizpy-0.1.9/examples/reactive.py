"""Example script for a reactive map (zoomable)."""

import json
import os
from geovizpy import Geoviz

# Define output directory
output_dir = os.path.join(os.path.dirname(__file__), "html")
os.makedirs(output_dir, exist_ok=True)

data_path = os.path.join(os.path.dirname(__file__), "data", "world.json")
try:
    with open(data_path) as f:
        world_data = json.load(f)
except FileNotFoundError:
    print(f"{data_path} not found.")
    world_data = {}

viz = Geoviz(projection="polar", width=700, zoomable=True)
viz.outline()
viz.graticule(stroke="white", strokeWidth=0.4)
viz.path(datum=world_data, fill="white", fillOpacity=0.3)

viz.prop(
    id="bubbles",
    symbol="circle",
    data=world_data,
    var="pop",
    fill="#F13C47",
    dodge=False,
    k=50,
    leg_title="Population",
    tip=True
)

print("Generating a static snapshot of the map.")
viz.render_html(os.path.join(output_dir, "reactive_snapshot.html"))
