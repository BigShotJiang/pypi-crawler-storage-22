import importlib.metadata

__author__ = "Blank Spruce"
__title__ = "gersemi"
__version__ = importlib.metadata.metadata(__title__)["Version"]
