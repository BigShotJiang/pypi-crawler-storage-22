def noop(*_):
    pass
