# Gestión Banco Correa 🏦

Proyecto desarrollado en Python que simula el funcionamiento básico de un sistema bancario.

Permite crear cuentas, realizar depósitos, retiros y mostrar el saldo final, aplicando Programación Orientada a Objetos (POO).

---

## 📌 Funcionalidades

- Crear cuenta de ahorros
- Registrar depósitos
- Registrar retiros
- Validar saldo disponible
- Generar comprobantes de transacción
- Mostrar saldo final

---

## 🛠 Tecnologías utilizadas

- Python 3
- Visual Studio Code

---

## ▶️ Cómo ejecutar el proyecto

1. Abrir la carpeta del proyecto en VS Code.

2. Abrir la terminal integrada.

3. Ejecutar:

```bash
python gestion_banco_correa/gestion_banco_correa.py
---

## 📊 Ejemplo de ejecución

El sistema realiza:

- Depósito de 100
- Retiro de 40

Resultado en consola:
---

## ✍️ Autor


Jhon Correa  
Estudiante
```md
```text
Comprobante de Transacción
Tipo: Retiro
Monto: $40.00
Fecha: 2026-02-03 18:23:25
Estado: Exitosa

Saldo final: 60.0



