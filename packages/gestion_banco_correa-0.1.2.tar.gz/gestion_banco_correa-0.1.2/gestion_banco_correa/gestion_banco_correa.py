from datetime import datetime

class Cliente:
    def __init__(self, nombre: str, identificacion: str):
        self.nombre = nombre
        self.identificacion = identificacion

    def obtener_datos(self) -> str:
        return f"Cliente: {self.nombre}, ID: {self.identificacion}"


class Transaccion:
    def __init__(self, tipo: str, monto: float):
        self.tipo = tipo
        self.monto = monto
        self.fecha = datetime.now()
        self.estado = "Exitosa"

    def obtener_detalles(self) -> str:
        return (f"Tipo: {self.tipo}\n"
                f"Monto: ${self.monto:.2f}\n"
                f"Fecha: {self.fecha.strftime('%Y-%m-%d %H:%M:%S')}\n"
                f"Estado: {self.estado}")

    def imprimir_comprobante(self):
        print("----- Comprobante de Transacción -----")
        print(self.obtener_detalles())
        print("-------------------------------------\n")


class CuentaAhorros:
    def __init__(self, numero_cuenta: str, cliente: Cliente):
        self.numero_cuenta = numero_cuenta
        self.cliente = cliente
        self.saldo = 0.0
        self.transacciones = []

    def depositar(self, monto: float) -> bool:
        if monto <= 0:
            print("Error: El monto a depositar debe ser positivo.")
            return False
        self.saldo += monto
        transaccion = Transaccion("Depósito", monto)
        self.transacciones.append(transaccion)
        transaccion.imprimir_comprobante()
        return True

    def retirar(self, monto: float) -> bool:
        if monto <= 0:
            print("Error: El monto a retirar debe ser positivo.")
            return False
        if monto > self.saldo:
            print("Error: Saldo insuficiente.")
            return False
        self.saldo -= monto
        transaccion = Transaccion("Retiro", monto)
        self.transacciones.append(transaccion)
        transaccion.imprimir_comprobante()
        return True

    def obtener_saldo(self):
        return self.saldo


class Cajero:
    def __init__(self, nombre):
        self.nombre = nombre

    def crear_cuenta(self, cliente, numero):
        cuenta = CuentaAhorros(numero, cliente)
        print("Cuenta creada")
        return cuenta

    def registrar_deposito(self, cuenta, monto):
        cuenta.depositar(monto)

    def registrar_retiro(self, cuenta, monto):
        cuenta.retirar(monto)

