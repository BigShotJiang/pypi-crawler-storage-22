from setuptools import setup, find_packages

with open("README.md", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="gestion_banco_correa",
   version="0.1.2",
    packages=find_packages(),
    include_package_data=True,
    author="Jhon Alexander Correa Gallegos",
    author_email="jhon@example.com",
    description="Paquete bancario con Programación Orientada a Objetos",
    long_description=long_description,
    long_description_content_type="text/markdown",
    python_requires=">=3.8",
)



