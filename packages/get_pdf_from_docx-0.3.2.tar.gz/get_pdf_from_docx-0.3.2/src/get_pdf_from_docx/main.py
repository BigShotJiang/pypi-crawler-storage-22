import os
import re
import datetime
from contextlib import contextmanager

from pypdf import PdfReader, PdfWriter
from tqdm import tqdm
import win32com.client
from win32com.client import constants


PDF_FILE_FORMAT = 17

SIGN_KEYWORDS = ["พ.ต.อ.", "พ.ต.ท.", "พ.ต.ต.", "ร.ต.อ.", "ร.ต.ท.", "ร.ต.ต."]

TARGET_DEPARTMENT = "กลุ่มงานตรวจพิสูจน์พยานหลักฐานดิจิทัล"


@contextmanager
def word_app():
    word = win32com.client.gencache.EnsureDispatch("Word.Application")
    word.Visible = False
    try:
        yield word
    finally:
        word.Quit()


def should_change_color(text: str) -> bool:
    if any(k in text for k in SIGN_KEYWORDS) and TARGET_DEPARTMENT in text:
        return True

    if re.search(r"\bตรวจ\b", text):
        return True

    return False


def change_text_color(doc, color: int):
    for i in range(1, doc.Paragraphs.Count + 1):
        paragraph = doc.Paragraphs(i)
        text = paragraph.Range.Text

        if should_change_color(text):
            paragraph.Range.Font.Color = color


def hide_textboxes_with_keyword(doc, keyword: str):
    for shape in doc.Shapes:
        if shape.TextFrame.HasText:
            text = shape.TextFrame.TextRange.Text
            if keyword in text:
                print(f"Hiding textbox with text: {text.strip()}")
                shape.Visible = False


def export_docx_to_pdf(word, input_path: str, color: int, output_path: str, hide_textbox: bool = False):
    doc = word.Documents.Open(os.path.abspath(input_path))
    try:
        change_text_color(doc, color)

        if hide_textbox:
            hide_textboxes_with_keyword(doc, "ลำดับผลการตรวจพิสูจน์")

        doc.SaveAs(output_path, FileFormat=PDF_FILE_FORMAT)
    finally:
        doc.Close(False)


def generate_temp_pdf_paths(input_path: str):
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    base_name = os.path.splitext(os.path.basename(input_path))[0]

    sign_pdf = os.path.abspath(f"{timestamp}_sign.pdf")
    no_sign_pdf = os.path.abspath(f"{timestamp}_no_sign.pdf")

    return base_name, sign_pdf, no_sign_pdf


def find_signature_pages(reader: PdfReader) -> list:
    pages = []

    for index, page in enumerate(reader.pages):
        text = page.extract_text() or ""

        if any(k in text for k in SIGN_KEYWORDS) and TARGET_DEPARTMENT in text:
            pages.append(index)

    return pages


def merge_pdfs(output_name: str, sign_pdf: str, no_sign_pdf: str):
    writer = PdfWriter()

    reader_sign = PdfReader(sign_pdf)
    reader_no_sign = PdfReader(no_sign_pdf)

    sign_page_indexes = find_signature_pages(reader_sign)

    for index, page in enumerate(reader_sign.pages):
        writer.add_page(page)
        if index in sign_page_indexes:
            writer.add_page(reader_no_sign.pages[index])

    with open(f"{output_name}.pdf", "wb") as f:
        writer.write(f)


def process_docx(input_path: str):
    base_name, sign_pdf, no_sign_pdf = generate_temp_pdf_paths(input_path)

    with word_app() as word:
        export_docx_to_pdf(word, input_path, constants.wdColorBlack, sign_pdf, hide_textbox=False)
        export_docx_to_pdf(word, input_path, constants.wdColorWhite, no_sign_pdf, hide_textbox=True)

    merge_pdfs(base_name, sign_pdf, no_sign_pdf)

    os.remove(sign_pdf)
    os.remove(no_sign_pdf)


def pick_docx_files():
    files = [f for f in os.listdir('.') if f.lower().endswith(".docx")]

    if not files:
        print("No .docx files found.")
        exit(0)

    print("1) All .docx files")
    for i, file in enumerate(files, start=2):
        print(f"{i}) {file}")

    choice = input("Select file to export: ").strip()

    if choice.isdigit():
        choice = int(choice)
        if choice == 1:
            return files
        if 2 <= choice <= len(files) + 1:
            return [files[choice - 2]]

    print("Canceled.")
    exit(0)


def hide_textboxes_with_keyword(doc, keyword: str):
    for shape in doc.Shapes:
        if shape.TextFrame.HasText:
            text = shape.TextFrame.TextRange.Text
            if keyword in text:
                shape.Visible = False


def main():
    selected_files = pick_docx_files()

    for file in tqdm(selected_files, desc="Exporting PDFs", unit="files"):
        process_docx(file)


if __name__ == "__main__":
    main()
