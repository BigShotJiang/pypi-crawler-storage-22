# get_uuid
Library for getting your motherboard UUID

Code example:
```python
import get_uuid

print("Your motherboard UUID: " + get_uuid.get_uuid())
```

## Supported OS
- Windows

## Notes
Check the "Supported OS" section before installing this library.