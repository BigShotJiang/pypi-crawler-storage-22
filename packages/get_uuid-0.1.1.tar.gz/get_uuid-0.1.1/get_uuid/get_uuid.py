import subprocess
import platform

class OSError(Exception):
    """
    If OS is invalid, this error class will raised.
    """
    pass

def get_uuid():
    """
    Get UUID of your computer motherboard.
    """
    # Check computer operating system (this library works only in Windows)
    system = platform.system()
    if system != "Windows":
        raise OSError("This library works only in Windows.")

    # Run wmic command to get the serial number of the motherboard
    raw_output = subprocess.check_output('wmic baseboard get serialnumber', shell=True)
    
    # Decode bytes to string and split into lines
    # We take the second line [1] because the first line is the header "SerialNumber"
    lines = raw_output.decode('utf-8').splitlines()
    
    for line in lines:
        clean_line = line.strip()
        # Check if line is not empty and not the header
        if clean_line and "SerialNumber" not in clean_line:
            return clean_line
    return "Unknown"