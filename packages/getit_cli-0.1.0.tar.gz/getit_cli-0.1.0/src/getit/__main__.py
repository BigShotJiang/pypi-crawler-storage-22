"""Entry point for python -m getit"""

from getit.cli import app

if __name__ == "__main__":
    app()
