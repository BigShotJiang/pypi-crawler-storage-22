from getit.tui.app import GetItApp

__all__ = ["GetItApp"]
