"""TUI screens package for getit application."""
