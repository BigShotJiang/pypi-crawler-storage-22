"""Test suite for getred."""
