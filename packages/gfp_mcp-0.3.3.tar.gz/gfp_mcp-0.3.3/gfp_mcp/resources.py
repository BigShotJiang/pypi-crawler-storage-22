"""MCP resource definitions for GDSFactory+.

This module defines the MCP resources that are exposed to AI assistants.
Resources provide read-only access to documentation and instruction content.
"""

from __future__ import annotations

from mcp.types import Resource

__all__ = [
    "RESOURCES",
    "get_all_resources",
    "get_resource_content",
]


RESOURCES: list[Resource] = [
    Resource(
        uri="instructions://build_custom_cell",
        name="Build Custom Cell Instructions",
        description=(
            "Comprehensive instructions for building custom photonic cells "
            "in GDSFactory+. Covers component creation, file organization, "
            "PDK integration, and best practices."
        ),
        mimeType="text/markdown",
    ),
]


RESOURCE_CONTENT = {
    "instructions://build_custom_cell": """---
Workflow: Creating Custom Components in GDSFactory+ Projects

Overview

When users request custom photonic components, keep user-defined components separate from PDK-defined
objects to maintain clean project organization.

Step-by-Step Process

1. File Organization

- DO NOT add custom components to cells.py - this file is reserved for PDK-defined objects
- CREATE or use custom_components.py in the package directory (e.g., myph18da/custom_components.py)
- This keeps custom user components separate from the PDK

2. Component Creation

\"\"\"Custom user-defined components.\"\"\"

import gdsfactory as gf
from ph18da.cells import <relevant_pdk_functions>  # Use PDK functions when available

__all__ = ["custom_component_name"]

@gf.cell
def custom_component_name(
    param1: float = default_value,
    param2: float = default_value,
) -> gf.Component:
    \"\"\"Component description.

    Args:
        param1: Description
        param2: Description

    Returns:
        Component description
    \"\"\"
    c = pdk_function(parameters...)
    return c

3. Key Implementation Guidelines

- Use @gf.cell decorator for all components
- Prefer using existing PDK functions (e.g., mzi_swg) over internal functions (e.g., _mzi)
- Import from ph18da.cells for PDK-specific components
- Use standard PDK component names (e.g., "c_mmi_2x2_swg", "wg_straight_swg", "wg_arc_swg")
- Keep component parameters clear and well-documented

4. Register the Component

Update the package __init__.py to import and expose the custom component:
from myph18da.custom_components import custom_component_name

5. Build the Component

Use the MCP build tool:
mcp__gdsfactoryplus__build_cell(
    name="custom_component_name",
    project="project-name"
)

6. Verification

- Check build status with get_cell_info
- Verify GDS file exists in build/gds/ directory
- Ensure status is "SUCCESS"

Troubleshooting

If build fails with import errors:
- Use PDK public functions instead of internal _functions
- Check that imports are from the correct PDK modules

If component not found:
- Ensure it's imported in __init__.py
- Rebuild the component after changes

If parameter errors occur:
- Check PDK component compatibility
- Verify parameter names match PDK expectations
---
""",
}


def get_all_resources() -> list[Resource]:
    """Get all available MCP resources.

    Returns:
        List of all resource definitions
    """
    return RESOURCES


def get_resource_content(uri: str) -> str | None:
    """Get resource content by URI.

    Args:
        uri: Resource URI

    Returns:
        Resource content string or None if not found
    """
    return RESOURCE_CONTENT.get(uri)
