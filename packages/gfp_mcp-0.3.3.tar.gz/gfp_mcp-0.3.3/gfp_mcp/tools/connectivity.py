"""Connectivity check tool handler.

This module provides the handler for running local connectivity
checks on GDS files.
"""

from __future__ import annotations

from typing import Any

from mcp.types import Tool

from .base import EndpointMapping, ToolHandler, add_project_param

__all__ = ["CheckConnectivityHandler"]


class CheckConnectivityHandler(ToolHandler):
    """Handler for running connectivity checks on GDS files.

    This is a fast, local check that verifies all layers are properly
    connected and identifies any connectivity violations.
    """

    @property
    def name(self) -> str:
        return "check_connectivity"

    @property
    def definition(self) -> Tool:
        return Tool(
            name="check_connectivity",
            description=(
                "Run a local connectivity check on a GDS file. This verifies that "
                "all layers are properly connected and identifies any connectivity "
                "violations. This is a fast, local check (does not require uploading "
                "to a remote server). Use this to quickly check for disconnected "
                "components. Returns XML results showing connectivity issues."
            ),
            inputSchema=add_project_param(
                {
                    "type": "object",
                    "properties": {
                        "path": {
                            "type": "string",
                            "description": (
                                "Path to the GDS file to check. Can be absolute or "
                                "relative to the project directory."
                            ),
                        },
                    },
                    "required": ["path"],
                }
            ),
        )

    @property
    def mapping(self) -> EndpointMapping:
        return EndpointMapping(method="POST", path="/api/check-connectivity")

    def transform_request(self, args: dict[str, Any]) -> dict[str, Any]:
        """Transform check_connectivity MCP args to FastAPI params.

        Args:
            args: MCP tool arguments

        Returns:
            Dict with 'json_data' key for request body
        """
        return {"json_data": {"path": args["path"]}}
