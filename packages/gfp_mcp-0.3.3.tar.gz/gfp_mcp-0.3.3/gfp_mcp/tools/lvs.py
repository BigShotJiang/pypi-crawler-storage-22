"""LVS (Layout vs. Schematic) check tool handler.

This module provides the handler for running LVS verification
on cells against reference netlists.
"""

from __future__ import annotations

from typing import Any

from mcp.types import Tool

from .base import EndpointMapping, ToolHandler, add_project_param

__all__ = ["CheckLvsHandler"]


class CheckLvsHandler(ToolHandler):
    """Handler for running LVS verification.

    Compares physical layout to schematic representation
    to ensure they match.
    """

    @property
    def name(self) -> str:
        return "check_lvs"

    @property
    def definition(self) -> Tool:
        return Tool(
            name="check_lvs",
            description=(
                "Run LVS (Layout vs. Schematic) verification on a cell against a "
                "reference netlist. This compares the physical layout to the "
                "schematic representation to ensure they match. Returns XML results "
                "showing any mismatches between layout and schematic."
            ),
            inputSchema=add_project_param(
                {
                    "type": "object",
                    "properties": {
                        "cell": {
                            "type": "string",
                            "description": "Name of the cell to verify",
                        },
                        "netpath": {
                            "type": "string",
                            "description": (
                                "Path to the reference netlist file to compare against"
                            ),
                        },
                        "cellargs": {
                            "type": "string",
                            "description": (
                                "Optional cell arguments as a JSON string. "
                                "Default is empty string."
                            ),
                            "default": "",
                        },
                    },
                    "required": ["cell", "netpath"],
                }
            ),
        )

    @property
    def mapping(self) -> EndpointMapping:
        return EndpointMapping(method="POST", path="/api/check-lvs")

    def transform_request(self, args: dict[str, Any]) -> dict[str, Any]:
        """Transform check_lvs MCP args to FastAPI params.

        Args:
            args: MCP tool arguments

        Returns:
            Dict with 'json_data' key for request body
        """
        return {
            "json_data": {
                "cell": args["cell"],
                "netpath": args["netpath"],
                "cellargs": args.get("cellargs", ""),
            }
        }
