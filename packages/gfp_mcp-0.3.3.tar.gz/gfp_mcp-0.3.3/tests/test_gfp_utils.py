"""Tests for gfp_mcp.utils module.

These tests verify the utility functions in the new gfp_mcp package.
"""

from __future__ import annotations

import asyncio
import time
from pathlib import Path

import pytest

from gfp_mcp.utils import wait_for_gds_file


class TestWaitForGdsFile:
    """Tests for wait_for_gds_file function."""

    @pytest.mark.anyio
    async def test_file_exists_immediately(self, tmp_path: Path) -> None:
        """Test waiting for a file that already exists."""
        gds_file = tmp_path / "test.gds"
        gds_file.write_bytes(b"test content")
        time.sleep(0.2)

        result = await wait_for_gds_file(gds_file, timeout=5.0, min_age=0.1)

        assert result is True

    @pytest.mark.anyio
    async def test_file_does_not_exist_timeout(self, tmp_path: Path) -> None:
        """Test timeout when file never appears."""
        gds_file = tmp_path / "nonexistent.gds"

        result = await wait_for_gds_file(gds_file, timeout=0.5, poll_interval=0.1)

        assert result is False

    @pytest.mark.anyio
    async def test_file_appears_during_polling(self, tmp_path: Path) -> None:
        """Test file appearing while polling."""
        gds_file = tmp_path / "delayed.gds"

        async def create_file_later() -> None:
            await asyncio.sleep(0.3)
            gds_file.write_bytes(b"delayed content")

        asyncio.create_task(create_file_later())

        result = await wait_for_gds_file(
            gds_file, timeout=2.0, poll_interval=0.1, min_age=0.0
        )

        assert result is True
        assert gds_file.exists()

    @pytest.mark.anyio
    async def test_file_too_new(self, tmp_path: Path) -> None:
        """Test file exists but is too new (still being written)."""
        gds_file = tmp_path / "new.gds"
        gds_file.write_bytes(b"content")

        result = await wait_for_gds_file(
            gds_file, timeout=0.3, poll_interval=0.1, min_age=10.0
        )

        assert result is False

    @pytest.mark.anyio
    async def test_default_parameters(self, tmp_path: Path) -> None:
        """Test with default parameters."""
        gds_file = tmp_path / "default.gds"
        gds_file.write_bytes(b"content")
        time.sleep(0.2)

        result = await wait_for_gds_file(gds_file, timeout=1.0)

        assert result is True


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
