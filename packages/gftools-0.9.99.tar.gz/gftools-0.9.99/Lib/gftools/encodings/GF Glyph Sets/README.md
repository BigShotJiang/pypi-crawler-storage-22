The glyph set files previously found here were moved to the [googlefonts/glyphsets](https://github.com/googlefonts/glyphsets) repository.
