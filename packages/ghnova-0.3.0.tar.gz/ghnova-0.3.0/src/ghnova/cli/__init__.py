"""Command line interface for ghnova."""
