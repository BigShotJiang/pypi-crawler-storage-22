"""Command line interface for configurations."""
