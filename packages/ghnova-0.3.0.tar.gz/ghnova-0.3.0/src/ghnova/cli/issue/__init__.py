"""Command line interface for issue-related operations."""

from __future__ import annotations

from ghnova.cli.issue.main import issue_app

__all__ = ["issue_app"]
