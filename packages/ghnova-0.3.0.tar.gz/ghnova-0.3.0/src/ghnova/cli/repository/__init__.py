"""Command line interface for repository-related operations."""
