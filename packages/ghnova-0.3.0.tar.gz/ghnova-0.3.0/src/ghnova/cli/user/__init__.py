"""Command line interface for user-related operations."""
