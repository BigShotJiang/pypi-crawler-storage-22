"""Unit tests for the ghnova package."""
