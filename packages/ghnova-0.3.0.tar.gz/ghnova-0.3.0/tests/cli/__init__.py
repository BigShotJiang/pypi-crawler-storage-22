"""Unit tests for the CLI package."""
