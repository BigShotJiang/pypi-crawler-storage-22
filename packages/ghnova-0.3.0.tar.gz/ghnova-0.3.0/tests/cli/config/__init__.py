"""Unit tests for the ghnova.cli.config package."""
