"""Unit tests for repository CLI commands."""
