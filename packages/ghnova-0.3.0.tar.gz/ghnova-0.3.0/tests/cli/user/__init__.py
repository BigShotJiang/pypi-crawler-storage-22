"""Unit tests for user CLI commands."""
