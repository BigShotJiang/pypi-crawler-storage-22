"""Unit tests for the ghnova.client package."""
