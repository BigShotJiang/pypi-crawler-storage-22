"""Unit tests for the ghnova.resource package."""
