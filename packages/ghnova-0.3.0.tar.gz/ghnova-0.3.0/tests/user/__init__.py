"""Unit tests for the ghnova.user package."""
