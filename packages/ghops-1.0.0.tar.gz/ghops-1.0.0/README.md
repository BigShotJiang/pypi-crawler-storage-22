# ghops (DEPRECATED)

**This package is deprecated and no longer maintained.**

Use [repoindex](https://pypi.org/project/repoindex/) instead -- a complete rewrite with a better approach to managing your GitHub repository collection.

```bash
pip install repoindex
```

See https://github.com/queelius/repoindex for details.
