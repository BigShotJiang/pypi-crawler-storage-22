"""GhostPC CLI package."""
