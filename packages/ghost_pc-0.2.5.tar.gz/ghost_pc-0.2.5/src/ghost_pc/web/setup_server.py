"""Web-based setup wizard backend — aiohttp server on port 9876."""

from __future__ import annotations

import asyncio
import json
import logging
import shutil
import subprocess
import sys
import webbrowser
from typing import Any

from aiohttp import WSMsgType, web

from ghost_pc import __version__
from ghost_pc.config.schema import GHOST_HOME, GhostConfig
from ghost_pc.web import get_web_root

logger = logging.getLogger(__name__)

_SETUP_PORT = 9876


class SetupServer:
    """Standalone aiohttp server for the browser-based setup wizard."""

    def __init__(self) -> None:
        self._app: web.Application | None = None
        self._runner: web.AppRunner | None = None
        self._done = asyncio.Event()
        self._ws_clients: list[web.WebSocketResponse] = []

    # ── Routes ──────────────────────────────────────────────────────

    async def _handle_setup_page(self, request: web.Request) -> web.Response:
        """Serve the setup wizard HTML."""
        template = get_web_root() / "templates" / "setup.html"
        html = template.read_text(encoding="utf-8")
        return web.Response(text=html, content_type="text/html")

    async def _handle_static(self, request: web.Request) -> web.FileResponse:
        """Serve static files (CSS/JS/images)."""
        rel_path = request.match_info["path"]
        file_path = get_web_root() / "static" / rel_path
        if not file_path.is_file():
            raise web.HTTPNotFound()
        return web.FileResponse(file_path)

    async def _handle_prerequisites(self, request: web.Request) -> web.Response:
        """Check prerequisites and return results."""
        checks: list[dict[str, Any]] = []

        # Python version
        py = sys.version_info
        checks.append(
            {
                "name": "Python",
                "status": "ok" if py >= (3, 12) else "fail",
                "detail": f"{py.major}.{py.minor}.{py.micro}",
                "required": "3.12+",
            }
        )

        # Platform
        checks.append(
            {
                "name": "Platform",
                "status": "ok" if sys.platform == "win32" else "warn",
                "detail": sys.platform,
                "required": "win32",
            }
        )

        # Node.js
        node_path = shutil.which("node")
        if node_path:
            try:
                result = subprocess.run(
                    ["node", "--version"],
                    capture_output=True,
                    text=True,
                    timeout=5,
                )
                checks.append(
                    {
                        "name": "Node.js",
                        "status": "ok",
                        "detail": result.stdout.strip(),
                    }
                )
            except (subprocess.SubprocessError, OSError):
                checks.append(
                    {
                        "name": "Node.js",
                        "status": "warn",
                        "detail": "Found but version check failed",
                    }
                )
        else:
            checks.append(
                {
                    "name": "Node.js",
                    "status": "fail",
                    "detail": "Not found — install from https://nodejs.org",
                }
            )

        # npm
        checks.append(
            {
                "name": "npm",
                "status": "ok" if shutil.which("npm") else "fail",
                "detail": "Available" if shutil.which("npm") else "Not found",
            }
        )

        return web.json_response({"checks": checks})

    async def _handle_get_config(self, request: web.Request) -> web.Response:
        """Return current config as JSON."""
        cfg = GhostConfig.load()
        data = cfg.model_dump()
        data["version"] = __version__
        # Mask the API key for display
        if data.get("gemini_api_key"):
            data["gemini_api_key_masked"] = data["gemini_api_key"][:8] + "..."
        else:
            data["gemini_api_key_masked"] = ""
        return web.json_response(data)

    async def _handle_validate_key(self, request: web.Request) -> web.Response:
        """Validate a Gemini API key."""
        body = await request.json()
        api_key = body.get("api_key", "").strip()
        if not api_key:
            return web.json_response({"valid": False, "error": "No API key provided"})

        try:
            from google import genai

            client = genai.Client(api_key=api_key)
            next(iter(client.models.list()))
            return web.json_response({"valid": True})
        except Exception as exc:
            return web.json_response({"valid": False, "error": str(exc)})

    async def _handle_save(self, request: web.Request) -> web.Response:
        """Validate and save the full config."""
        body = await request.json()

        cfg = GhostConfig.load()

        # Apply fields from the wizard
        if "gemini_api_key" in body:
            cfg.gemini_api_key = body["gemini_api_key"]
        if "model_tier" in body:
            cfg.model_tier = body["model_tier"]
            from ghost_pc.config.settings import _resolve_model_tier

            model, cu_model = _resolve_model_tier(body["model_tier"])
            cfg.gemini_model = model
            cfg.gemini_computer_use_model = cu_model
        if "browser_method" in body:
            cfg.browser_method = body["browser_method"]
        if "features" in body:
            cfg.installed_extras = body["features"]
        if "allowed_numbers" in body:
            cfg.allowed_numbers = body["allowed_numbers"]
        if "stream_port" in body:
            cfg.stream_port = int(body["stream_port"])
        if "screen_fps" in body:
            cfg.screen_fps = int(body["screen_fps"])
        if "jpeg_quality" in body:
            cfg.jpeg_quality = int(body["jpeg_quality"])
        if "autostart_enabled" in body:
            cfg.autostart_enabled = body["autostart_enabled"]

        cfg.setup_completed = True
        cfg.save()

        return web.json_response({"ok": True, "path": str(GHOST_HOME / "config.json")})

    async def _handle_install_bridge(self, request: web.Request) -> web.Response:
        """Install the WhatsApp bridge — copies files and runs npm install.

        Streams progress via WebSocket.
        """
        cfg = GhostConfig.load()
        bridge_dir = cfg.get_bridge_dir()
        bridge_dir.mkdir(parents=True, exist_ok=True)

        await self._ws_send(
            {
                "type": "progress",
                "step": "bridge",
                "message": "Copying bridge files...",
            }
        )

        # Copy bundled bridge files
        try:
            from ghost_pc._bridge import get_bundled_bridge_path

            src_dir = get_bundled_bridge_path()
            if src_dir is None:
                return web.json_response(
                    {
                        "ok": False,
                        "error": "Bundled bridge not found. Copy bridge/ to " + str(bridge_dir),
                    }
                )

            import shutil as sh

            for filename in ("index.js", "package.json"):
                src_file = src_dir / filename
                dst_file = bridge_dir / filename
                if src_file.exists():
                    sh.copy2(src_file, dst_file)
                    await self._ws_send(
                        {
                            "type": "progress",
                            "step": "bridge",
                            "message": f"Copied {filename}",
                        }
                    )
        except ImportError:
            return web.json_response(
                {
                    "ok": False,
                    "error": "Bridge bundle not available",
                }
            )

        # npm install
        if not shutil.which("npm"):
            return web.json_response({"ok": False, "error": "npm not found"})

        await self._ws_send(
            {
                "type": "progress",
                "step": "bridge",
                "message": "Running npm install...",
            }
        )

        try:
            result = subprocess.run(
                ["npm", "install", "--production"],
                cwd=str(bridge_dir),
                capture_output=True,
                text=True,
                timeout=120,
            )
            if result.returncode == 0:
                await self._ws_send(
                    {
                        "type": "progress",
                        "step": "bridge",
                        "message": "npm dependencies installed",
                        "done": True,
                    }
                )
                return web.json_response({"ok": True})
            else:
                return web.json_response({"ok": False, "error": result.stderr.strip()})
        except subprocess.TimeoutExpired:
            return web.json_response({"ok": False, "error": "npm install timed out"})
        except OSError as exc:
            return web.json_response({"ok": False, "error": str(exc)})

    async def _handle_install_extras(self, request: web.Request) -> web.Response:
        """Install selected pip extras."""
        # Frozen exe: extras can't be pip-installed into a bundled build
        if getattr(sys, "frozen", False):
            return web.json_response(
                {
                    "ok": False,
                    "error": (
                        "Optional extras cannot be installed in a standalone build. "
                        "Reinstall from pip: pip install ghost-pc[desktop,voice,browser]"
                    ),
                }
            )

        body = await request.json()
        extras: list[str] = body.get("extras", [])
        if not extras:
            return web.json_response({"ok": True, "message": "No extras to install"})

        extras_str = ",".join(extras)
        pip_spec = f"ghost-pc[{extras_str}]"

        await self._ws_send(
            {
                "type": "progress",
                "step": "extras",
                "message": f"Installing {pip_spec}...",
            }
        )

        # Use the Python that owns this process (not sys.executable in frozen builds)
        python = sys.executable
        if getattr(sys, "frozen", False):
            python = shutil.which("python") or shutil.which("python3") or "python"

        try:
            result = subprocess.run(
                [python, "-m", "pip", "install", pip_spec],
                capture_output=True,
                text=True,
                timeout=300,
            )
            if result.returncode == 0:
                await self._ws_send(
                    {
                        "type": "progress",
                        "step": "extras",
                        "message": f"Installed {pip_spec}",
                        "done": True,
                    }
                )
                return web.json_response({"ok": True})
            else:
                err_lines = result.stderr.strip().splitlines()
                last_err = err_lines[-1] if err_lines else "Unknown error"
                return web.json_response({"ok": False, "error": last_err})
        except subprocess.TimeoutExpired:
            return web.json_response({"ok": False, "error": "pip install timed out"})
        except OSError as exc:
            return web.json_response({"ok": False, "error": str(exc)})

    async def _handle_pair_whatsapp(self, request: web.Request) -> web.Response:
        """Start the WhatsApp bridge for pairing — sends QR via WebSocket."""
        cfg = GhostConfig.load()
        bridge_dir = cfg.get_bridge_dir()
        index_js = bridge_dir / "index.js"

        if not index_js.exists():
            return web.json_response({"ok": False, "error": "Bridge not installed"})

        import os

        env = {
            **os.environ,
            "GHOST_CREDENTIALS_DIR": str(cfg.get_credentials_dir()),
        }

        try:
            proc = subprocess.Popen(
                ["node", str(index_js)],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                env=env,
            )

            await self._ws_send(
                {
                    "type": "progress",
                    "step": "pairing",
                    "message": "Waiting for QR code...",
                }
            )

            # Read stdout lines for QR data (bridge outputs JSON-RPC)
            loop = asyncio.get_running_loop()

            def _read_bridge() -> None:
                if proc.stdout is None:
                    return
                for line in proc.stdout:
                    line_str = line.decode("utf-8", errors="replace").strip()
                    if not line_str:
                        continue
                    try:
                        msg = json.loads(line_str)
                        if msg.get("type") == "qr":
                            asyncio.run_coroutine_threadsafe(
                                self._ws_send(
                                    {
                                        "type": "qr",
                                        "data": msg.get("data", ""),
                                    }
                                ),
                                loop,
                            )
                        elif msg.get("type") == "connection" and msg.get("connected"):
                            asyncio.run_coroutine_threadsafe(
                                self._ws_send(
                                    {
                                        "type": "paired",
                                        "message": "WhatsApp connected!",
                                    }
                                ),
                                loop,
                            )
                    except json.JSONDecodeError:
                        pass

            # Run reader in a thread
            await loop.run_in_executor(None, _read_bridge)

            # Give it a moment, then terminate
            if proc.poll() is None:
                proc.terminate()

            return web.json_response({"ok": True})

        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)})

    async def _handle_set_autostart(self, request: web.Request) -> web.Response:
        """Configure Windows scheduled task for autostart."""
        if sys.platform != "win32":
            return web.json_response({"ok": False, "error": "Only supported on Windows"})

        body = await request.json()
        enable = body.get("enable", False)

        if enable:
            ghost_cmd = shutil.which("ghost") or "ghost"
            try:
                subprocess.run(
                    [
                        "schtasks",
                        "/Create",
                        "/TN",
                        "GhostPC",
                        "/SC",
                        "ONLOGON",
                        "/RL",
                        "LIMITED",
                        "/TR",
                        f'"{ghost_cmd}" start',
                        "/F",
                    ],
                    capture_output=True,
                    text=True,
                    timeout=10,
                )
                return web.json_response({"ok": True})
            except (subprocess.SubprocessError, OSError) as exc:
                return web.json_response({"ok": False, "error": str(exc)})
        else:
            try:
                subprocess.run(
                    ["schtasks", "/Delete", "/TN", "GhostPC", "/F"],
                    capture_output=True,
                    text=True,
                    timeout=10,
                )
            except (subprocess.SubprocessError, OSError):
                pass
            return web.json_response({"ok": True})

    async def _handle_ws(self, request: web.Request) -> web.WebSocketResponse:
        """WebSocket for real-time feedback (QR codes, install progress)."""
        ws = web.WebSocketResponse()
        await ws.prepare(request)
        self._ws_clients.append(ws)

        try:
            async for msg in ws:
                if msg.type == WSMsgType.TEXT:
                    data = json.loads(msg.data)
                    if data.get("action") == "done":
                        self._done.set()
                elif msg.type in (WSMsgType.ERROR, WSMsgType.CLOSE):
                    break
        finally:
            self._ws_clients.remove(ws)

        return ws

    # ── Helpers ─────────────────────────────────────────────────────

    async def _ws_send(self, data: dict[str, Any]) -> None:
        """Broadcast a message to all connected WebSocket clients."""
        dead: list[web.WebSocketResponse] = []
        for ws in self._ws_clients:
            try:
                await ws.send_json(data)
            except (ConnectionResetError, RuntimeError):
                dead.append(ws)
        for ws in dead:
            self._ws_clients.remove(ws)

    # ── Server lifecycle ────────────────────────────────────────────

    async def _start(self) -> None:
        """Create and start the aiohttp server."""
        self._app = web.Application()
        self._app.router.add_get("/setup", self._handle_setup_page)
        self._app.router.add_get("/static/{path:.*}", self._handle_static)
        self._app.router.add_get("/api/setup/prerequisites", self._handle_prerequisites)
        self._app.router.add_get("/api/setup/config", self._handle_get_config)
        self._app.router.add_post("/api/setup/validate-key", self._handle_validate_key)
        self._app.router.add_post("/api/setup/save", self._handle_save)
        self._app.router.add_post("/api/setup/install-bridge", self._handle_install_bridge)
        self._app.router.add_post("/api/setup/install-extras", self._handle_install_extras)
        self._app.router.add_post("/api/setup/pair-whatsapp", self._handle_pair_whatsapp)
        self._app.router.add_post("/api/setup/set-autostart", self._handle_set_autostart)
        self._app.router.add_get("/ws/setup", self._handle_ws)

        self._runner = web.AppRunner(self._app)
        await self._runner.setup()
        site = web.TCPSite(self._runner, "127.0.0.1", _SETUP_PORT)
        await site.start()

        logger.info("Setup wizard running on http://127.0.0.1:%d/setup", _SETUP_PORT)

    async def _stop(self) -> None:
        """Shut down the server."""
        if self._runner:
            await self._runner.cleanup()

    async def run(self) -> None:
        """Start server, open browser, wait until wizard signals done, then stop."""
        await self._start()

        # Open browser
        url = f"http://127.0.0.1:{_SETUP_PORT}/setup"
        webbrowser.open(url)

        # Wait for the wizard to finish (signalled via WebSocket "done" action)
        # Also allow Ctrl+C to stop
        try:
            await self._done.wait()
        except asyncio.CancelledError:
            pass
        finally:
            await self._stop()


def run_setup_gui() -> None:
    """Entry point for ``ghost setup`` — starts the web wizard."""
    from rich.console import Console

    console = Console()
    console.print(
        f"[bold cyan]GhostPC Setup Wizard[/] v{__version__}\n"
        f"Opening browser at http://127.0.0.1:{_SETUP_PORT}/setup ...\n"
        "[dim]Press Ctrl+C to cancel.[/]\n"
    )

    server = SetupServer()
    try:
        asyncio.run(server.run())
    except KeyboardInterrupt:
        console.print("\n[yellow]Setup cancelled.[/]")
