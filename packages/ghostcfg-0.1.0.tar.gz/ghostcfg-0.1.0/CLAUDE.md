# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What This Is

ghostcfg is a Python TUI (Textual) application for interactively editing Ghostty terminal configuration. It provides tabbed category browsing, live theme preview, type-aware input widgets, and hot-reload via SIGUSR2 signaling to a running Ghostty process.

## Commands

```bash
pip install -e .          # Install in editable mode
ghostcfg                  # Run the app (or: gcfg, python -m ghostcfg)
pytest                    # Run all tests
pytest tests/test_schema.py            # Run a single test file
pytest tests/test_schema.py::test_name # Run a single test
```

No linter or formatter is configured.

## Architecture

**Entry point:** `src/ghostcfg/app.py:main()` → `GhostCfg(App).run()`

**Data flow:** Ghostty CLI → schema + config parsing → Textual widgets → config write → SIGUSR2 reload

### Core Modules

- **schema.py** — Static metadata for 200+ Ghostty options: type (`string`, `boolean`, `enum`, `integer`, `float`, `color`, `path`, `duration`), default value, category, hot_reload flag, platform filter, repeatability. Options are grouped into `CATEGORIES` (Font, Colors, Cursor, Window, Background, Input, Shell, Advanced) which drive the tab layout.

- **config_io.py** — Roundtrip-safe config parser. `GhosttyConfig` stores a list of `ConfigEntry` objects (kind: `option`/`comment`/`blank`) preserving original comments, blank lines, and ordering through read→modify→write cycles. Creates `.bak` backups before first write per session.

- **ghostty.py** — Ghostty process interface. Detects config path per platform (macOS: `~/Library/Application Support/com.mitchellh.ghostty/config`, Linux: `~/.config/ghostty/config`). Calls `ghostty +list-themes --plain` and `ghostty +show-config --default --docs` for runtime data. Finds Ghostty PIDs with `pgrep -a` (needed since ghostcfg runs inside Ghostty as an ancestor process) and sends SIGUSR2 for hot-reload.

- **app.py** — Main Textual App. Composes a `TabbedContent` with a Themes tab and one tab per category. Tracks `_pending_changes` dict that accumulates until Ctrl+S save. Theme changes bypass pending—they write and reload immediately.

### Widgets (`src/ghostcfg/widgets/`)

- **ThemeBrowser** — Searchable theme list with dark/light filter. Emits `ThemeHighlighted` (live preview on cursor move), `ThemeSelected` (Enter confirms), `ThemeReverted` (Escape restores original).

- **ConfigPanel** — Container for `OptionRow` widgets in a category, with a documentation pane that updates on focus.

- **OptionRow** — Single config option. Selects input widget by type: `Switch` for boolean, `Select` for enum, `Input` for string/number/color. Color options show a live swatch. Tracks original vs current value for modification detection.

### Key Patterns

- **Message-based communication** — Widgets communicate via Textual `Message` subclasses (e.g., `ValueChanged`, `ThemeHighlighted`, `OptionFocused`), not direct method calls.
- **Reactive properties** — `reactive[bool]` for `has_unsaved` drives the `[modified]` subtitle indicator.
- **Theme application removes color overrides** — When a theme is applied, `THEME_COLOR_KEYS` (background, foreground, palette, etc.) are stripped from config so the theme's colors take effect.
- **Platform filtering** — Schema entries with `"platform": "macos"` or `"linux"` are filtered at runtime via `platform.system()`.

## Dependencies

- Python ≥ 3.10
- textual ≥ 1.0.0
- Ghostty must be installed and on PATH for runtime data (themes, docs, reload)
