"""ghostcfg screens."""
