"""ghostcfg widgets."""
