"""Gibs Python SDK — multi-regulation compliance API for developers.

Usage::

    from gibs import GibsClient

    client = GibsClient(api_key="gbs_live_xxx")
    result = client.classify("Facial recognition system for airport security")
    print(result.risk_level)

Async usage::

    from gibs import AsyncGibsClient

    client = AsyncGibsClient(api_key="gbs_live_xxx")
    result = await client.classify("Facial recognition system for airport security")
"""

from gibs.async_client import AsyncGibsClient
from gibs.client import GibsClient
from gibs.exceptions import GibsAPIError, GibsAuthError, GibsError, GibsRateLimitError
from gibs.types import (
    APIKey,
    CheckRequest,
    CheckResponse,
    ClassifyRequest,
    ClassifyResponse,
    CreateKeyResponse,
    DeleteKeyResponse,
    HealthResponse,
    Obligation,
    SourceCitation,
)

__all__ = [
    # Clients
    "GibsClient",
    "AsyncGibsClient",
    # Exceptions
    "GibsError",
    "GibsAPIError",
    "GibsAuthError",
    "GibsRateLimitError",
    # Types
    "ClassifyRequest",
    "ClassifyResponse",
    "CheckRequest",
    "CheckResponse",
    "HealthResponse",
    "APIKey",
    "CreateKeyResponse",
    "DeleteKeyResponse",
    "SourceCitation",
    "Obligation",
]

__version__ = "0.1.1"
