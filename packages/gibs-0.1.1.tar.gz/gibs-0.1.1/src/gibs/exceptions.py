"""Exceptions for the Gibs SDK."""

from __future__ import annotations


class GibsError(Exception):
    """Base exception for all Gibs SDK errors."""

    def __init__(self, message: str) -> None:
        self.message = message
        super().__init__(message)


class GibsAPIError(GibsError):
    """Raised when the API returns a 4xx or 5xx response."""

    def __init__(
        self,
        message: str,
        status_code: int,
        response_body: dict | str | None = None,
    ) -> None:
        self.status_code = status_code
        self.response_body = response_body
        super().__init__(message)

    def __str__(self) -> str:
        return f"[{self.status_code}] {self.message}"


class GibsAuthError(GibsAPIError):
    """Raised on 401 Unauthorized responses."""

    def __init__(
        self,
        message: str = "Invalid or missing API key",
        response_body: dict | str | None = None,
    ) -> None:
        super().__init__(message=message, status_code=401, response_body=response_body)


class GibsRateLimitError(GibsAPIError):
    """Raised on 429 Too Many Requests responses."""

    retry_after: float | None

    def __init__(
        self,
        message: str = "Rate limit exceeded",
        retry_after: float | None = None,
        response_body: dict | str | None = None,
    ) -> None:
        self.retry_after = retry_after
        super().__init__(message=message, status_code=429, response_body=response_body)
