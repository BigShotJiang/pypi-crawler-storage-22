from gigaplate.cli import cli

cli()
