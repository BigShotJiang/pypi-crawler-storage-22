"""Hugin: Gimle's agentic framework for creative reasoning tasks."""

from gimle.hugin._version import __version__

__all__ = ["__version__"]
