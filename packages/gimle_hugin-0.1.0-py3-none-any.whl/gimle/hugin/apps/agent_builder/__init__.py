"""Agent Builder - A meta-agent that creates new Hugin agents."""
