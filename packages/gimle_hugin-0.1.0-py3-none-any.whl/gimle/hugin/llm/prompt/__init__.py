"""Gimle LLM Prompt Logic."""
