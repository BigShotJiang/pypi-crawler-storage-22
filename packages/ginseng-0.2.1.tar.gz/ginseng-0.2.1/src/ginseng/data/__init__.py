# Copyright (c) 2025, Tom Ouellette
# Licensed under the MIT License

from .dataset import GinsengDataset

__all__ = ["GinsengDataset"]
