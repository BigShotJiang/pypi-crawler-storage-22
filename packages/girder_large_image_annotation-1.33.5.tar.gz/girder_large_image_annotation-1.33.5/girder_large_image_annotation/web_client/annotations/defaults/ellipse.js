export default {
    fillColor: 'rgba(0,0,0,0)',
    lineColor: 'rgb(0,0,0)',
    lineWidth: 2,
    rotation: 0,
    normal: [0, 0, 1]
};
