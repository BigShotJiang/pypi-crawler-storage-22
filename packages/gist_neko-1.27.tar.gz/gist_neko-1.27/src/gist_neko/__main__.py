#!/usr/bin/env python3

# Execute with
# $ python3 -m gist_neko

from .cli import main

if __name__ == "__main__":
    raise SystemExit(main())
