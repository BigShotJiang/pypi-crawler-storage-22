# Contributing

Thanks for contributing to `git-agent-memory`.

## 1. Development Setup

1. Clone the repository:

```bash
git clone <repo-url>
cd git-agent-memory
```

2. Create and activate a virtual environment:

```bash
python -m venv .venv
# Linux/macOS
source .venv/bin/activate
# Windows PowerShell
.venv\Scripts\Activate.ps1
```

3. Install in editable mode with development dependencies:

```bash
pip install -e .[dev]
```

4. Run tests:

```bash
pytest
```

## 2. Code Style

- Use `black` for formatting.
- Type hints are required for new/modified code.
- Docstrings are required for public functions, classes, and modules.

Recommended commands:

```bash
black src tests
pytest
```

## 3. Testing Requirements

- All PRs must include tests for new behavior or bug fixes.
- Existing tests must continue to pass.
- Project coverage must remain above `80%`.

Recommended coverage check:

```bash
pytest --cov=src/git_agent_memory --cov-report=term-missing --cov-report=html --cov-fail-under=80
```

## 4. Pull Request Process

1. Create a focused branch for your change.
2. Keep commits small and descriptive.
3. Ensure formatting, tests, and coverage checks pass locally.
4. Open a PR with:
   - Problem statement
   - Summary of changes
   - Test evidence (commands + output summary)
   - Any known limitations or follow-up work
5. Address review feedback and keep discussion in the PR thread.

## 5. Code of Conduct

This project follows the [Contributor Covenant](https://www.contributor-covenant.org/version/2/1/code_of_conduct/).

By participating, you agree to maintain a respectful, inclusive environment.
