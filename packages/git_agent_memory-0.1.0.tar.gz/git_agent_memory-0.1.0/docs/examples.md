# Examples

This document shows example outputs and configuration for `git-agent-memory`.

## 1. Example `commits.md` Output

```markdown
# Commit History

Last updated: 2026-02-15 18:00:12

---

<!-- git-agent-memory:hash=2d2c7b6b7e91adcd2c6e3d6f8b32d589f558f4e3 -->
<!-- git-agent-memory:version=1 -->

## [feat] feat: add repository status command
**Commit:** `2d2c7b6` (full: `2d2c7b6b7e91adcd2c6e3d6f8b32d589f558f4e3`)  
**Date:** 2026-02-15 17:58:34  
**Author:** Jane Developer <jane@example.com>  
**Branch:** main

### Message
feat: add repository status command

Adds status reporting for global hook installation and health checks.

### Files Changed (3 files, +42/-5)
- `src/git_agent_memory/cli.py` - Modified (+30/-3)
- `src/git_agent_memory/hooks.py` - Modified (+10/-2)
- `tests/test_cli.py` - Added (+2/-0)

**Impact:** Low

---
```

## 2. Example with Merge Commit

```markdown
<!-- git-agent-memory:hash=8e8c7e589f3afdb13f4dd28c8d0589df76352c18 -->
<!-- git-agent-memory:version=1 -->

## [chore] merge branch 'feature/parser-hardening'
**Commit:** `8e8c7e5` (full: `8e8c7e589f3afdb13f4dd28c8d0589df76352c18`)  
**Date:** 2026-02-15 16:42:01  
**Author:** Jane Developer <jane@example.com>  
**Branch:** main
**Merge commit:** 2 parents (4f02a11, 3bd6c4f)
**Note:** File changes shown relative to first parent

### Message
merge branch 'feature/parser-hardening'

### Files Changed (2 files, +18/-7)
- `src/git_agent_memory/parser.py` - Modified (+15/-5)
- `tests/test_parser.py` - Modified (+3/-2)

**Impact:** Low

---
```

## 3. Example with Renamed Files

```markdown
<!-- git-agent-memory:hash=4b4a92ecf7ee6b2f4497f50e9ef6efcf9f180df4 -->
<!-- git-agent-memory:version=1 -->

## [refactor] refactor: rename parser module
**Commit:** `4b4a92e` (full: `4b4a92ecf7ee6b2f4497f50e9ef6efcf9f180df4`)  
**Date:** 2026-02-15 14:13:55  
**Author:** Jane Developer <jane@example.com>  
**Branch:** main

### Message
refactor: rename parser module

### Files Changed (2 files, +4/-4)
- `src/git_agent_memory/commit_parser.py` - Renamed from `src/git_agent_memory/parser.py` (+4/-4)
- `tests/test_commit_parser.py` - Renamed from `tests/test_parser.py` (+0/-0)

**Impact:** Low

---
```

## 4. Example Configuration Files

### Global config: `~/.git-agent-memory/config.yaml`

```yaml
enabled: true
max_entries: 200
file_name: "commits.md"
track_commits_file: false
excluded_repos:
  - "/home/user/work/private-repo"
  - "C:/Users/you/work/vendor-mirror"
```

### Repo-local override: `.git-agent-memory.yaml`

```yaml
enabled: true
max_entries: 50
file_name: "commits.md"
track_commits_file: false
```

### Repo disabled locally: `.git-agent-memory.yaml`

```yaml
enabled: false
```

