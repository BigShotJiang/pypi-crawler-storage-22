# Repository Secrets

This project uses a GitHub Actions secret for publishing packages:

- `PYPI_API_TOKEN`

## `PYPI_API_TOKEN` Setup

1. Create or sign in to your [PyPI](https://pypi.org/) account.
2. Generate an API token in PyPI:
   - Go to **Account settings** -> **API tokens**.
   - Create a token with the minimum required scope.
3. In GitHub, open the repository settings:
   - **Settings** -> **Secrets and variables** -> **Actions**.
4. Create a new repository secret:
   - Name: `PYPI_API_TOKEN`
   - Value: your PyPI token (starts with `pypi-`).

## Notes

- The release workflow (`.github/workflows/release.yml`) reads `PYPI_API_TOKEN`
  and publishes on tags matching `v*`.
- Keep the token private and rotate it if it is exposed.
