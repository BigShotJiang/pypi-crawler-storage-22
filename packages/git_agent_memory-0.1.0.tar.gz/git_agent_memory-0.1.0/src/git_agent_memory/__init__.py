"""git-agent-memory package."""

__version__ = "0.1.0"

from .hooks import install_global_hook
from .parser import parse_latest_commit
from .writer import write_commit


def capture_with_timeout(timeout_seconds: float = 0.5) -> None:
    """Proxy export for capture flow without importing CLI eagerly."""
    from .cli import capture_with_timeout as _capture_with_timeout

    _capture_with_timeout(timeout_seconds=timeout_seconds)


__all__ = [
    "__version__",
    "parse_latest_commit",
    "write_commit",
    "install_global_hook",
    "capture_with_timeout",
]
