"""Module entrypoint for ``python -m git_agent_memory``."""

from __future__ import annotations

from .cli import cli


def main() -> None:
    """Run the Click CLI as a module entrypoint."""
    cli(prog_name="git-agent-memory")


if __name__ == "__main__":
    main()
