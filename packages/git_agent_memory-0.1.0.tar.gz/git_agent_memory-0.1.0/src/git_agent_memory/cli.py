"""CLI commands for git-agent-memory."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
import os
from pathlib import Path
import subprocess
import time

import click
import yaml

from . import __version__
from . import hooks
from .config import (
    LOCAL_CONFIG_FILENAME,
    exclude_repo_globally,
    include_repo_globally,
    load_config,
    should_skip_repo,
)
from .git_utils import GitError, resolve_git_paths, run_git_command
from .parser import CommitData, parse_file_changes_z, parse_latest_commit
from .writer import atomic_write, build_document, ensure_local_ignore, format_commit, write_commit

_HOOK_NAME = "post-commit"
_STATE_DIR_NAME = ".git-agent-memory"


@dataclass
class _StatusSnapshot:
    """Snapshot of hook installation state for status/doctor commands."""

    git_ok: bool
    git_version: str
    hooks_path_raw: str | None
    hooks_path_absolute: Path | None
    hooks_path_is_relative: bool
    hook_file: Path | None
    hook_exists: bool
    hook_managed: bool
    backup_file: Path | None
    backup_exists: bool


@click.group()
@click.version_option(version=__version__, prog_name="git-agent-memory")
def cli() -> None:
    """git-agent-memory: Git history for AI coding agents."""
    pass


def _state_dir() -> Path:
    """Return the absolute package state directory."""
    return (Path.home() / _STATE_DIR_NAME).resolve()


def _default_hooks_dir() -> Path:
    """Return the default global hooks directory."""
    return (_state_dir() / "hooks").resolve()


def _error_log_path() -> Path:
    """Return the absolute error log path used for hook/capture failures."""
    return (_state_dir() / "errors.log").resolve()


def _append_error_log(message: str) -> None:
    """Append one line to the package error log, swallowing all exceptions."""
    try:
        path = _error_log_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with path.open("a", encoding="utf-8") as handle:
            handle.write(f"[{timestamp}] {message}\n")
    except Exception:
        return


def _git_version() -> tuple[bool, str]:
    """Return ``(available, version_or_error)`` for Git."""
    try:
        result = subprocess.run(
            ["git", "--version"],
            capture_output=True,
            text=True,
            check=False,
            timeout=2.0,
        )
    except Exception as exc:
        return (False, str(exc))

    if result.returncode != 0:
        stderr = (result.stderr or "").strip() or "unknown error"
        return (False, stderr)

    return (True, (result.stdout or "").strip())


def _read_hooks_path() -> str | None:
    """Read global ``core.hooksPath`` and return ``None`` when unset."""
    result = subprocess.run(
        ["git", "config", "--global", "--get", "core.hooksPath"],
        capture_output=True,
        text=True,
        check=False,
        timeout=2.0,
    )
    if result.returncode != 0:
        return None
    value = (result.stdout or "").strip()
    return value or None


def _set_hooks_path(path: Path) -> tuple[bool, str]:
    """Set global ``core.hooksPath`` and return success status with message."""
    result = subprocess.run(
        ["git", "config", "--global", "core.hooksPath", str(path)],
        capture_output=True,
        text=True,
        check=False,
        timeout=2.0,
    )
    if result.returncode != 0:
        stderr = (result.stderr or "").strip() or "unknown error"
        return (False, stderr)
    return (True, "")


def _hook_snapshot() -> _StatusSnapshot:
    """Collect the current installation snapshot for status and diagnostics."""
    git_ok, git_version = _git_version()
    hooks_path_raw = _read_hooks_path() if git_ok else None

    hooks_path_absolute: Path | None = None
    hooks_path_is_relative = False
    hook_file: Path | None = None
    backup_file: Path | None = None
    hook_exists = False
    hook_managed = False
    backup_exists = False

    if hooks_path_raw:
        hooks_path_is_relative = not Path(hooks_path_raw).is_absolute()
        if not hooks_path_is_relative:
            hooks_path_absolute = Path(hooks_path_raw).expanduser().resolve()
            hook_file = hooks_path_absolute / _HOOK_NAME
            backup_file = hooks_path_absolute / f"{_HOOK_NAME}{hooks.BACKUP_SUFFIX}"
            hook_exists = hook_file.exists()
            backup_exists = backup_file.exists()
            if hook_exists:
                try:
                    hook_managed = hooks.HOOK_MARKER in hook_file.read_text(
                        encoding="utf-8",
                        errors="replace",
                    )
                except OSError:
                    hook_managed = False

    return _StatusSnapshot(
        git_ok=git_ok,
        git_version=git_version,
        hooks_path_raw=hooks_path_raw,
        hooks_path_absolute=hooks_path_absolute,
        hooks_path_is_relative=hooks_path_is_relative,
        hook_file=hook_file,
        hook_exists=hook_exists,
        hook_managed=hook_managed,
        backup_file=backup_file,
        backup_exists=backup_exists,
    )


def _is_writable_directory(path: Path) -> bool:
    """Return True when directory exists and is writable."""
    return path.exists() and path.is_dir() and os.access(path, os.W_OK | os.X_OK)


def _is_executable(path: Path) -> bool:
    """Return True when file is executable on this platform."""
    if os.name == "nt":
        return path.exists()
    return os.access(path, os.X_OK)


def _resolve_git_repo_or_message() -> tuple[Path | None, Path | None]:
    """Resolve repo paths and print a friendly message if not in a repository."""
    try:
        repo_root, git_dir = resolve_git_paths()
        return (repo_root, git_dir)
    except GitError as exc:
        click.echo(f"Not in a git repository: {exc}")
        return (None, None)
    except Exception as exc:
        click.echo(f"Failed to resolve repository: {exc}")
        return (None, None)


def _resolve_git_repo_silent() -> tuple[Path | None, Path | None]:
    """Resolve repo paths without emitting user-facing messages."""
    try:
        return resolve_git_paths()
    except Exception:
        return (None, None)


def _remove_local_disable_override(repo_root: Path) -> tuple[bool, str | None]:
    """Remove local `enabled: false` override for a repository, if present."""
    local_config = repo_root / LOCAL_CONFIG_FILENAME
    if not local_config.exists():
        return (False, None)

    try:
        loaded = yaml.safe_load(local_config.read_text(encoding="utf-8")) or {}
    except Exception as exc:
        return (False, f"Failed to parse {local_config}: {exc}")

    if not isinstance(loaded, dict):
        return (False, f"Invalid YAML structure in {local_config}; remove it manually.")

    if "enabled" not in loaded:
        return (False, None)

    loaded.pop("enabled", None)
    try:
        if not loaded:
            local_config.unlink()
        else:
            local_config.write_text(yaml.safe_dump(loaded, sort_keys=True), encoding="utf-8")
    except Exception as exc:
        return (False, f"Failed to update {local_config}: {exc}")

    return (True, None)


def capture_with_timeout(timeout_seconds: float = 0.5) -> None:
    """Capture latest commit with a strict monotonic time budget.

    This function is safe for use from hooks:
    - It never raises exceptions to the caller.
    - It logs failures to the error log.
    - It does not print to stderr.
    - It records slow captures (>200ms) for diagnostics.

    Implementation constraints:
    - Uses ``time.monotonic()`` for wall-clock-safe budget tracking.
    - Uses per-call subprocess timeouts in downstream helpers.
    - Does not use shell timeout commands or ``signal.alarm``.
    """
    start = time.monotonic()

    def remaining() -> float:
        return timeout_seconds - (time.monotonic() - start)

    try:
        repo_root, git_dir = resolve_git_paths()

        should_skip, _reason = should_skip_repo(repo_root)
        if should_skip:
            return

        if remaining() <= 0:
            _append_error_log("Time budget exhausted before commit parse")
            return

        commit_data = parse_latest_commit(timeout=remaining())

        if remaining() <= 0:
            _append_error_log("Time budget exhausted before write")
            return

        write_commit(
            commit_data,
            repo_root=repo_root,
            git_dir=git_dir,
            timeout=remaining(),
        )
    except subprocess.TimeoutExpired:
        _append_error_log("Git command timed out during capture")
    except Exception as exc:
        _append_error_log(f"Capture failed: {exc}")
    finally:
        elapsed = time.monotonic() - start
        if elapsed > 0.2:
            _append_error_log(f"Slow capture: {elapsed:.3f}s")


def _parse_commit_for_rebuild(commit_hash: str, branch: str, cwd: str) -> CommitData:
    """Parse one commit by hash for rebuild flows using git subprocess commands."""
    metadata_result = run_git_command(
        [
            "git",
            "log",
            "-1",
            "--pretty=format:%H%x00%h%x00%an%x00%ae%x00%aI%x00%s%x00%b",
            commit_hash,
        ],
        timeout=5.0,
        text=False,
        cwd=cwd,
    )
    if metadata_result.returncode != 0:
        stderr = (metadata_result.stderr or b"").decode("utf-8", errors="replace").strip()
        raise GitError(f"Failed metadata for {commit_hash[:7]}: {stderr or 'unknown error'}")

    tokens = (metadata_result.stdout or b"").split(b"\x00")
    if len(tokens) < 7:
        raise GitError(f"Unexpected metadata output for {commit_hash[:7]}")

    full_hash = tokens[0].decode("utf-8", errors="replace").strip()
    short_hash = tokens[1].decode("utf-8", errors="replace").strip()
    author = tokens[2].decode("utf-8", errors="replace").strip()
    email = tokens[3].decode("utf-8", errors="replace").strip()
    timestamp_raw = tokens[4].decode("utf-8", errors="replace").strip()
    subject = tokens[5].decode("utf-8", errors="replace").rstrip("\n")
    body = b"\x00".join(tokens[6:]).decode("utf-8", errors="replace").rstrip("\n")
    message = subject if not body else f"{subject}\n\n{body}"

    timestamp = datetime.fromisoformat(timestamp_raw.replace("Z", "+00:00"))

    parents_result = run_git_command(
        ["git", "rev-list", "--parents", "-n", "1", commit_hash],
        timeout=5.0,
        text=True,
        cwd=cwd,
    )
    if parents_result.returncode != 0:
        parent_hashes: list[str] = []
    else:
        parent_tokens = (parents_result.stdout or "").strip().split()
        parent_hashes = parent_tokens[1:] if parent_tokens else []

    status_result = run_git_command(
        [
            "git",
            "diff-tree",
            "--no-commit-id",
            "--name-status",
            "-z",
            "-r",
            "-M",
            "-C",
            "--root",
            commit_hash,
        ],
        timeout=5.0,
        text=False,
        cwd=cwd,
    )
    if status_result.returncode != 0:
        stderr = (status_result.stderr or b"").decode("utf-8", errors="replace").strip()
        raise GitError(f"Failed name-status for {commit_hash[:7]}: {stderr or 'unknown error'}")

    numstat_result = run_git_command(
        [
            "git",
            "diff-tree",
            "--no-commit-id",
            "--numstat",
            "-z",
            "-r",
            "-M",
            "-C",
            "--root",
            commit_hash,
        ],
        timeout=5.0,
        text=False,
        cwd=cwd,
    )
    if numstat_result.returncode != 0:
        stderr = (numstat_result.stderr or b"").decode("utf-8", errors="replace").strip()
        raise GitError(f"Failed numstat for {commit_hash[:7]}: {stderr or 'unknown error'}")

    files_changed = parse_file_changes_z(
        status_output=status_result.stdout or b"",
        numstat_output=numstat_result.stdout or b"",
    )

    is_merge = len(parent_hashes) > 1
    return CommitData(
        hash=full_hash,
        hash_short=short_hash,
        author=author,
        email=email,
        timestamp=timestamp,
        message=message,
        subject=subject,
        body=body,
        branch=branch,
        files_changed=files_changed,
        is_merge=is_merge,
        parent_hashes=parent_hashes if is_merge else None,
    )


def _run_setup(dry_run: bool, force_absolute: bool) -> None:
    """Shared implementation for setup/install commands."""
    snapshot = _hook_snapshot()
    if not snapshot.git_ok:
        click.echo(f"[FAIL] Git unavailable: {snapshot.git_version}")
        return

    current = snapshot.hooks_path_raw

    if current and snapshot.hooks_path_is_relative and force_absolute:
        target = Path(current).expanduser().resolve()
        if dry_run:
            click.echo(f"[DRY-RUN] Would convert core.hooksPath: {current} -> {target}")
            current = str(target)
        else:
            ok, message = _set_hooks_path(target)
            if not ok:
                click.echo(f"[FAIL] Could not set absolute core.hooksPath: {message}")
                return
            click.echo(f"[OK] Converted core.hooksPath to absolute: {target}")
            current = str(target)

    if dry_run:
        click.echo("Dry-run setup plan:")
        if current:
            if Path(current).is_absolute():
                click.echo(f"  - Use existing hooksPath: {Path(current).expanduser().resolve()}")
            else:
                click.echo(f"  - Relative hooksPath detected: {current}")
                click.echo("  - Setup would fail unless --force-absolute is used.")
        else:
            click.echo(f"  - Set global core.hooksPath to: {_default_hooks_dir()}")

        hooks_dir = Path(current).expanduser().resolve() if current and Path(current).is_absolute() else _default_hooks_dir()
        hook_file = hooks_dir / _HOOK_NAME
        backup_file = hooks_dir / f"{_HOOK_NAME}{hooks.BACKUP_SUFFIX}"
        click.echo(f"  - Target hook file: {hook_file}")
        if hook_file.exists():
            try:
                existing_hook = hook_file.read_text(encoding="utf-8", errors="replace")
                if hooks.HOOK_MARKER in existing_hook:
                    click.echo("  - Existing hook is already managed (idempotent no-op).")
                else:
                    click.echo(f"  - Existing unmanaged hook will be backed up to: {backup_file}")
            except OSError as exc:
                click.echo(f"  - Existing hook is unreadable ({exc}); setup may fail.")
        else:
            click.echo("  - No existing hook found; managed hook will be created.")
        click.echo(f"  - Error log path in hook will be: {_error_log_path()}")
        return

    click.echo("Running git-agent-memory setup...")
    installed = hooks.install_global_hook()
    if installed:
        click.echo("[OK] Setup complete.")
        click.echo("[OK] Default mode: active for all repositories for this user.")
        click.echo("[OK] Use `git-agent-memory exclude` inside a repo to opt out.")

        repo_root, _git_dir = _resolve_git_repo_silent()
        if repo_root is not None:
            changed, error = _remove_local_disable_override(repo_root)
            if error:
                click.echo(f"[WARN] {error}")
            elif changed:
                click.echo("[OK] Removed local disable override for current repository.")
    else:
        click.echo("[FAIL] Setup failed. Run `git-agent-memory doctor` for diagnostics.")


@cli.command(name="setup")
@click.option("--dry-run", is_flag=True, help="Show installation actions without changing anything.")
@click.option(
    "--force-absolute",
    is_flag=True,
    help="Convert a relative global core.hooksPath to an absolute path before install.",
)
def setup(dry_run: bool, force_absolute: bool) -> None:
    """Set up global hook capture (default-on for all repos)."""
    _run_setup(dry_run=dry_run, force_absolute=force_absolute)


@cli.command(name="install", hidden=True)
@click.option("--dry-run", is_flag=True, help="Show installation actions without changing anything.")
@click.option(
    "--force-absolute",
    is_flag=True,
    help="Convert a relative global core.hooksPath to an absolute path before setup.",
)
def install_alias(dry_run: bool, force_absolute: bool) -> None:
    """Backward-compatible alias for setup."""
    click.echo("[WARN] `install` is deprecated; use `git-agent-memory setup`.")
    _run_setup(dry_run=dry_run, force_absolute=force_absolute)


@cli.command()
def uninstall() -> None:
    """Remove global Git hooks."""
    before = _hook_snapshot()
    hooks.uninstall_global_hook()
    after = _hook_snapshot()

    if before.hook_managed and not after.hook_managed:
        click.echo("[OK] Managed global hook removed.")
    elif before.hook_managed and after.hook_managed:
        click.echo("[WARN] Managed hook still present after uninstall attempt.")
    else:
        click.echo("[OK] No managed global hook was installed.")


@cli.command()
def status() -> None:
    """Check installation status."""
    snapshot = _hook_snapshot()

    if not snapshot.git_ok:
        click.echo(f"[FAIL] Git: unavailable ({snapshot.git_version})")
        return
    click.echo(f"[OK] Git: {snapshot.git_version}")

    if not snapshot.hooks_path_raw:
        click.echo("[WARN] core.hooksPath: not set")
        click.echo("[WARN] Global post-commit hook is not installed.")
        return

    click.echo(f"[OK] core.hooksPath: {snapshot.hooks_path_raw}")

    if snapshot.hooks_path_is_relative:
        click.echo("[FAIL] core.hooksPath is relative; installer refuses unsafe chaining.")
        return

    assert snapshot.hooks_path_absolute is not None
    click.echo(f"[OK] Resolved hooks directory: {snapshot.hooks_path_absolute}")

    if not snapshot.hook_exists or snapshot.hook_file is None:
        click.echo(f"[FAIL] Hook file missing: {snapshot.hooks_path_absolute / _HOOK_NAME}")
        return

    click.echo(f"[OK] Hook file exists: {snapshot.hook_file}")

    if snapshot.hook_managed:
        click.echo(f"[OK] Hook marker found: {hooks.HOOK_MARKER}")
        click.echo("[OK] Installation status: managed hook installed")
    else:
        click.echo("[WARN] Hook exists but is not managed by git-agent-memory.")

    if snapshot.backup_file is not None and snapshot.backup_exists:
        click.echo(f"[OK] Backup hook found: {snapshot.backup_file}")

    repo_root, _git_dir = _resolve_git_repo_silent()
    if repo_root is None:
        return

    skip, reason = should_skip_repo(repo_root)
    if skip:
        if reason == "disabled via local config":
            click.echo(
                "[WARN] Current repo is excluded via legacy `.git-agent-memory.yaml` (enabled: false)."
            )
            click.echo("[WARN] Run `git-agent-memory include` to re-enable this repo.")
        elif reason == "in global exclusion list":
            click.echo("[WARN] Current repo is excluded in global config.")
            click.echo("[WARN] Run `git-agent-memory include` to re-enable this repo.")
        else:
            click.echo(f"[WARN] Current repo capture is skipped: {reason}")
    else:
        click.echo("[OK] Current repo capture: enabled (default mode).")


@cli.command()
def doctor() -> None:
    """Diagnose installation issues."""
    successes: list[str] = []
    warnings: list[str] = []
    issues: list[str] = []

    snapshot = _hook_snapshot()
    if snapshot.git_ok:
        successes.append(f"Git available: {snapshot.git_version}")
    else:
        issues.append(f"Git unavailable: {snapshot.git_version}")

    if snapshot.hooks_path_raw is None:
        warnings.append("core.hooksPath is not set (global hooks not installed)")
    elif snapshot.hooks_path_is_relative:
        issues.append(f"core.hooksPath is relative: {snapshot.hooks_path_raw}")
    else:
        assert snapshot.hooks_path_absolute is not None
        successes.append(f"core.hooksPath is absolute: {snapshot.hooks_path_absolute}")
        if snapshot.hooks_path_absolute.exists():
            successes.append("Hooks directory exists")
            if _is_writable_directory(snapshot.hooks_path_absolute):
                successes.append("Hooks directory is writable")
            else:
                issues.append(f"Hooks directory is not writable: {snapshot.hooks_path_absolute}")
        else:
            warnings.append(f"Hooks directory does not exist: {snapshot.hooks_path_absolute}")

        if snapshot.hook_file is not None:
            if snapshot.hook_exists:
                successes.append(f"Hook file exists: {snapshot.hook_file}")
                if snapshot.hook_managed:
                    successes.append("Hook contains managed marker")
                else:
                    warnings.append("Hook file is not managed by git-agent-memory")

                if _is_executable(snapshot.hook_file):
                    successes.append("Hook file appears executable")
                else:
                    warnings.append("Hook file is not executable")
            else:
                warnings.append(f"Hook file missing: {snapshot.hook_file}")

        if snapshot.backup_file is not None and snapshot.backup_exists:
            try:
                backup_text = snapshot.backup_file.read_text(encoding="utf-8", errors="replace")
                if hooks.HOOK_MARKER in backup_text:
                    issues.append(
                        "Backup hook contains managed marker; this can create recursion"
                    )
                else:
                    successes.append("Backup hook exists and is unmanaged")
            except OSError as exc:
                warnings.append(f"Could not read backup hook file: {exc}")

    try:
        binary_path = hooks.get_executable_path()
        successes.append(f"Executable found: {binary_path}")
    except Exception as exc:
        issues.append(f"Could not resolve executable path: {exc}")

    log_path = _error_log_path()
    if log_path.is_absolute():
        successes.append(f"Error log path is absolute: {log_path}")
    else:
        issues.append(f"Error log path is not absolute: {log_path}")

    log_dir = log_path.parent
    if log_dir.exists():
        if _is_writable_directory(log_dir):
            successes.append(f"Error log directory is writable: {log_dir}")
        else:
            issues.append(f"Error log directory is not writable: {log_dir}")
    else:
        warnings.append(f"Error log directory does not exist yet: {log_dir}")

    if log_path.exists():
        if os.access(log_path, os.W_OK):
            successes.append("Error log file is writable")
        else:
            warnings.append(f"Error log file is not writable: {log_path}")
    else:
        warnings.append("Error log file does not exist yet (it is created on first error)")

    repo_root, git_dir = _resolve_git_repo_or_message()
    if repo_root is not None and git_dir is not None:
        successes.append(f"Current repository root: {repo_root}")
        skip, reason = should_skip_repo(repo_root)
        if skip:
            warnings.append(f"Current repo would be skipped by capture: {reason}")
        else:
            successes.append("Current repo is eligible for capture")

    click.echo("Doctor report:")
    click.echo("")

    click.echo("Successes:")
    if successes:
        for item in successes:
            click.echo(f"  [OK] {item}")
    else:
        click.echo("  (none)")

    click.echo("")
    click.echo("Warnings:")
    if warnings:
        for item in warnings:
            click.echo(f"  [WARN] {item}")
    else:
        click.echo("  (none)")

    click.echo("")
    click.echo("Issues:")
    if issues:
        for item in issues:
            click.echo(f"  [FAIL] {item}")
    else:
        click.echo("  (none)")

    click.echo("")
    if issues:
        click.echo(f"Doctor finished with {len(issues)} issue(s).")
    else:
        click.echo("Doctor finished with no blocking issues.")


@cli.command()
def capture() -> None:
    """Capture the most recent commit."""
    try:
        capture_with_timeout(timeout_seconds=0.5)
    except Exception as exc:
        _append_error_log(f"Unexpected capture wrapper failure: {exc}")
    return


@cli.command()
def exclude() -> None:
    """Disable for current repo via global exclusions."""
    repo_root, _git_dir = _resolve_git_repo_or_message()
    if repo_root is None:
        return

    changed, error = exclude_repo_globally(repo_root)
    if error:
        click.echo(error)
        return

    # Remove legacy local override to keep behavior consistent with global-only exclusion.
    _changed_local, local_error = _remove_local_disable_override(repo_root)
    if local_error:
        click.echo(f"[WARN] {local_error}")

    if changed:
        click.echo(f"[OK] Disabled git-agent-memory for repo: {repo_root}")
    else:
        click.echo(f"[OK] Repo already excluded: {repo_root}")


@cli.command()
def include() -> None:
    """Re-enable for current repo."""
    repo_root, _git_dir = _resolve_git_repo_or_message()
    if repo_root is None:
        return

    changed_global, error_global = include_repo_globally(repo_root)
    if error_global:
        click.echo(error_global)
        return

    changed_local, error_local = _remove_local_disable_override(repo_root)
    if error_local:
        click.echo(error_local)
        return

    changed = changed_global or changed_local
    if changed:
        click.echo("[OK] Re-enabled repository capture.")
    else:
        click.echo("[OK] Repository is already enabled (no exclusion found).")


@cli.command()
@click.option("--max-entries", type=int, default=100, show_default=True)
def rebuild(max_entries: int) -> None:
    """Rebuild commits.md from git log."""
    if max_entries < 1:
        click.echo("--max-entries must be >= 1")
        return

    repo_root, git_dir = _resolve_git_repo_or_message()
    if repo_root is None or git_dir is None:
        return

    cfg = load_config(repo_root)
    commits_file = repo_root / cfg.file_name

    rev_list_result = run_git_command(
        ["git", "rev-list", f"--max-count={max_entries}", "HEAD"],
        timeout=5.0,
        text=True,
        cwd=str(repo_root),
    )
    if rev_list_result.returncode != 0:
        stderr = (rev_list_result.stderr or "").strip() or "unknown error"
        click.echo(f"Failed to enumerate commits: {stderr}")
        return

    hashes = [line.strip() for line in (rev_list_result.stdout or "").splitlines() if line.strip()]
    if not hashes:
        atomic_write(commits_file, build_document([]))
        if not cfg.track_commits_file:
            ensure_local_ignore(repo_root, git_dir, cfg.file_name)
        click.echo(f"[OK] Rebuilt empty history file: {commits_file}")
        return

    branch_result = run_git_command(
        ["git", "rev-parse", "--abbrev-ref", "HEAD"],
        timeout=5.0,
        text=True,
        cwd=str(repo_root),
    )
    if branch_result.returncode == 0:
        branch_name = (branch_result.stdout or "").strip() or "unknown"
    else:
        branch_name = "unknown"
    if branch_name == "HEAD":
        branch_name = "Detached HEAD"

    entries: list[str] = []
    failed = 0
    for commit_hash in hashes:
        try:
            commit_data = _parse_commit_for_rebuild(commit_hash, branch_name, cwd=str(repo_root))
            entries.append(format_commit(commit_data))
        except Exception as exc:
            failed += 1
            _append_error_log(f"Rebuild skipped commit {commit_hash[:7]}: {exc}")

    atomic_write(commits_file, build_document(entries))
    if not cfg.track_commits_file:
        ensure_local_ignore(repo_root, git_dir, cfg.file_name)

    click.echo(f"[OK] Rebuilt {commits_file} with {len(entries)} entries.")
    if failed:
        click.echo(f"[WARN] Skipped {failed} commit(s); see {_error_log_path()} for details.")


@cli.command(hidden=True)
@click.option("--version", is_flag=True, help="Show package version.")
def main(version: bool) -> None:
    """Show version or help."""
    if version:
        click.echo(__version__)
        return

    ctx = click.get_current_context()
    root_ctx = ctx.find_root()
    click.echo(root_ctx.command.get_help(root_ctx))
