"""Configuration management for git-agent-memory.

This module provides global and per-repository configuration loading, saving,
and repository skip decisions used by capture/write flows.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
import logging
from pathlib import Path
import subprocess
from typing import Any

import yaml

LOGGER = logging.getLogger(__name__)

GLOBAL_CONFIG_PATH = Path.home() / ".git-agent-memory" / "config.yaml"
LOCAL_CONFIG_FILENAME = ".git-agent-memory.yaml"
DEFAULT_FILE_NAME = "commits.md"

# Section 3.0.1 patterns from build spec.
SKIP_PATH_PATTERNS = (
    "/node_modules/",
    "/vendor/",
    "/.venv/",
    "/venv/",
    "/.cache/",
    "/cache/",
    "/.tox/",
    "/site-packages/",
)


@dataclass
class Config:
    """Runtime configuration for git-agent-memory behavior."""

    enabled: bool = True
    max_entries: int = 100
    file_name: str = DEFAULT_FILE_NAME
    track_commits_file: bool = False
    excluded_repos: list[str] = field(default_factory=list)


def load_config(repo_root: Path | None = None) -> Config:
    """Load merged configuration from global and repository-local files.

    Precedence order:
    1. Built-in defaults
    2. Global config: ``~/.git-agent-memory/config.yaml``
    3. Local config: ``<repo_root>/.git-agent-memory.yaml`` (if available)

    Args:
        repo_root: Optional repository root. If omitted, this function attempts
            to detect the current repository root from the working directory.

    Returns:
        Merged and validated config. On any load/parse issue, defaults are used.
    """
    merged: dict[str, Any] = asdict(Config())

    global_data = _read_yaml_dict(GLOBAL_CONFIG_PATH)
    _apply_known_keys(merged, global_data)

    resolved_repo_root = _resolve_repo_root(repo_root)
    if resolved_repo_root is not None:
        local_data = _read_yaml_dict(resolved_repo_root / LOCAL_CONFIG_FILENAME)
        _apply_known_keys(merged, local_data)

    return _coerce_config(merged)


def load_global_config() -> Config:
    """Load only global config without repository-local overrides."""
    global_data = _read_yaml_dict(GLOBAL_CONFIG_PATH)
    return _coerce_config(global_data)


def save_config(config: Config, global_config: bool = True) -> None:
    """Save config to global or repository-local file.

    Save destination:
    - ``global_config=True``: ``~/.git-agent-memory/config.yaml``
    - ``global_config=False``: ``<repo_root>/.git-agent-memory.yaml`` where
      ``repo_root`` is detected from current directory (fallback: cwd)

    This function never raises; failures are logged.

    Args:
        config: Config object to persist.
        global_config: If true, writes global config; otherwise writes local.
    """
    try:
        if global_config:
            target = GLOBAL_CONFIG_PATH
        else:
            repo_root = _resolve_repo_root(None)
            if repo_root is None:
                repo_root = Path.cwd().resolve()
            target = repo_root / LOCAL_CONFIG_FILENAME

        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("w", encoding="utf-8") as handle:
            yaml.safe_dump(asdict(config), handle, sort_keys=True)
    except Exception as exc:
        LOGGER.warning("Failed to save config to %s: %s", target if "target" in locals() else "<unknown>", exc)


def is_repo_excluded(repo_root: Path) -> bool:
    """Check whether a repository should be treated as excluded.

    Checks:
    1. Global ``excluded_repos`` list
    2. Local config ``enabled: false``

    Args:
        repo_root: Repository root path.

    Returns:
        ``True`` if excluded/disabled, otherwise ``False``.
    """
    try:
        resolved_repo = Path(repo_root).expanduser().resolve()
    except Exception:
        resolved_repo = Path(repo_root)

    if _is_repo_in_global_exclusions(resolved_repo):
        return True

    local_data = _read_yaml_dict(resolved_repo / LOCAL_CONFIG_FILENAME)
    local_enabled = local_data.get("enabled")
    return isinstance(local_enabled, bool) and not local_enabled


def should_skip_repo(repo_root: Path) -> tuple[bool, str]:
    """Decide whether commit capture should be skipped for this repository.

    Section 3.0.1 checks:
    - Bare repositories
    - Local config disabled (``enabled: false``)
    - Vendor/cache/virtualenv path patterns
    - Global excluded repository list

    Args:
        repo_root: Repository root path.

    Returns:
        Tuple ``(should_skip, reason)`` where reason is empty when not skipped.
    """
    try:
        resolved_repo = Path(repo_root).expanduser().resolve()
    except Exception:
        resolved_repo = Path(repo_root)

    try:
        result = subprocess.run(
            ["git", "rev-parse", "--is-bare-repository"],
            capture_output=True,
            text=True,
            timeout=1.0,
            check=False,
            cwd=str(resolved_repo),
        )
        if result.returncode == 0 and (result.stdout or "").strip().lower() == "true":
            return (True, "bare repository")
    except Exception:
        # Continue with other checks.
        pass

    try:
        local_data = _read_yaml_dict(resolved_repo / LOCAL_CONFIG_FILENAME)
        if isinstance(local_data.get("enabled"), bool) and not local_data.get("enabled"):
            return (True, "disabled via local config")
    except Exception:
        pass

    normalized_repo = _normalize_path(resolved_repo)
    for pattern in SKIP_PATH_PATTERNS:
        if pattern in normalized_repo:
            return (True, f"inside {pattern}")

    try:
        if _is_repo_in_global_exclusions(resolved_repo):
            return (True, "in global exclusion list")
    except Exception:
        pass

    return (False, "")


def exclude_repo_globally(repo_root: Path) -> tuple[bool, str | None]:
    """Add a repository path to global exclusions.

    Returns:
        Tuple ``(changed, error_message)``.
    """
    try:
        normalized_repo = _normalize_path(repo_root)
    except Exception as exc:
        return (False, f"Failed to normalize repository path: {exc}")

    cfg = load_global_config()
    excluded = set(cfg.excluded_repos)
    if normalized_repo in excluded:
        return (False, None)

    cfg.excluded_repos = sorted([*excluded, normalized_repo])
    save_config(cfg, global_config=True)
    reloaded = load_global_config()
    if normalized_repo not in set(reloaded.excluded_repos):
        return (False, f"Failed to persist exclusion to {GLOBAL_CONFIG_PATH}")
    return (True, None)


def include_repo_globally(repo_root: Path) -> tuple[bool, str | None]:
    """Remove a repository path from global exclusions.

    Returns:
        Tuple ``(changed, error_message)``.
    """
    try:
        normalized_repo = _normalize_path(repo_root)
    except Exception as exc:
        return (False, f"Failed to normalize repository path: {exc}")

    cfg = load_global_config()
    excluded = [entry for entry in cfg.excluded_repos if entry != normalized_repo]
    if len(excluded) == len(cfg.excluded_repos):
        return (False, None)

    cfg.excluded_repos = excluded
    save_config(cfg, global_config=True)
    reloaded = load_global_config()
    if normalized_repo in set(reloaded.excluded_repos):
        return (False, f"Failed to persist inclusion to {GLOBAL_CONFIG_PATH}")
    return (True, None)


def _resolve_repo_root(repo_root: Path | None) -> Path | None:
    """Resolve repository root from explicit argument or current directory."""
    if repo_root is not None:
        try:
            return Path(repo_root).expanduser().resolve()
        except Exception:
            return Path(repo_root)

    try:
        result = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            capture_output=True,
            text=True,
            timeout=1.0,
            check=False,
        )
        if result.returncode != 0:
            return None
        root = (result.stdout or "").strip()
        if not root:
            return None
        return Path(root).resolve()
    except Exception:
        return None


def _read_yaml_dict(path: Path) -> dict[str, Any]:
    """Read YAML file into a dictionary, returning empty dict on failure."""
    try:
        if not path.exists():
            return {}
        with path.open("r", encoding="utf-8") as handle:
            data = yaml.safe_load(handle) or {}
        if isinstance(data, dict):
            return data
        LOGGER.warning("Ignoring non-dict config at %s", str(path))
    except Exception as exc:
        LOGGER.warning("Failed to read config %s: %s", str(path), exc)
    return {}


def _apply_known_keys(target: dict[str, Any], source: dict[str, Any]) -> None:
    """Apply known config keys from source into target dict."""
    for key in target.keys():
        if key in source:
            target[key] = source[key]


def _coerce_config(raw: dict[str, Any]) -> Config:
    """Coerce untyped config dictionary into a validated Config dataclass."""
    enabled = raw.get("enabled", True)
    if not isinstance(enabled, bool):
        enabled = _coerce_bool(enabled, default=True)

    max_entries = raw.get("max_entries", 100)
    try:
        max_entries = int(max_entries)
    except (TypeError, ValueError):
        max_entries = 100
    if max_entries < 1:
        max_entries = 1

    file_name = _coerce_file_name(raw.get("file_name", DEFAULT_FILE_NAME))

    track_commits_file = raw.get("track_commits_file", False)
    if not isinstance(track_commits_file, bool):
        track_commits_file = _coerce_bool(track_commits_file, default=False)

    excluded_repos_raw = raw.get("excluded_repos", [])
    excluded_repos: list[str] = []
    if isinstance(excluded_repos_raw, list):
        for value in excluded_repos_raw:
            if isinstance(value, str) and value.strip():
                excluded_repos.append(_normalize_path(Path(value.strip())))

    return Config(
        enabled=enabled,
        max_entries=max_entries,
        file_name=file_name,
        track_commits_file=track_commits_file,
        excluded_repos=excluded_repos,
    )


def _coerce_bool(value: Any, default: bool) -> bool:
    """Coerce common string/int bool values with a default fallback."""
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        lowered = value.strip().lower()
        if lowered in {"true", "1", "yes", "on"}:
            return True
        if lowered in {"false", "0", "no", "off"}:
            return False
        return default
    if isinstance(value, int):
        return value != 0
    return default


def _coerce_file_name(value: Any) -> str:
    """Coerce output filename to a safe in-repo basename.

    Security policy:
    - Reject absolute paths.
    - Reject traversal and directory separators.
    - Accept basename only (for example ``commits.md``).
    """
    if not isinstance(value, str):
        return DEFAULT_FILE_NAME

    candidate = value.strip()
    if not candidate:
        return DEFAULT_FILE_NAME

    normalized = candidate.replace("\\", "/")
    path = Path(normalized)
    if path.is_absolute():
        LOGGER.warning("Ignoring absolute file_name %r; using %s", candidate, DEFAULT_FILE_NAME)
        return DEFAULT_FILE_NAME

    if normalized.startswith("/") or normalized.startswith("./"):
        LOGGER.warning("Ignoring unsafe file_name %r; using %s", candidate, DEFAULT_FILE_NAME)
        return DEFAULT_FILE_NAME

    parts = [part for part in normalized.split("/") if part and part != "."]
    if len(parts) != 1 or ".." in parts:
        LOGGER.warning("Ignoring path-like file_name %r; using %s", candidate, DEFAULT_FILE_NAME)
        return DEFAULT_FILE_NAME

    safe_name = parts[0]
    if safe_name in {".", ".."} or ":" in safe_name:
        return DEFAULT_FILE_NAME
    return safe_name


def _is_repo_in_global_exclusions(repo_root: Path) -> bool:
    """Check whether a repo path is present in global excluded_repos."""
    global_data = _read_yaml_dict(GLOBAL_CONFIG_PATH)
    global_config = _coerce_config(global_data)
    repo_str = _normalize_path(repo_root)
    return repo_str in set(global_config.excluded_repos)


def _normalize_path(path: Path) -> str:
    """Normalize path for case-insensitive cross-platform comparisons."""
    try:
        normalized = str(path.expanduser().resolve())
    except Exception:
        normalized = str(path)
    return normalized.replace("\\", "/").rstrip("/").lower()
