"""Git subprocess helpers with worktree-safe path resolution."""

from __future__ import annotations

from pathlib import Path
import subprocess


class GitError(RuntimeError):
    """Raised when git metadata cannot be resolved or validated."""


def run_git_command(
    cmd: list[str],
    timeout: float,
    cwd: str | None = None,
    text: bool = True,
) -> subprocess.CompletedProcess:
    """Run a git command with bounded execution time.

    Args:
        cmd: Command and arguments as a tokenized list (for example:
            ``["git", "rev-parse", "--git-dir"]``).
        timeout: Maximum execution time in seconds. Must be greater than zero.
        cwd: Optional working directory for the command.
        text: When ``True``, decode output as text. Set to ``False`` for
            NUL-separated ``-z`` git commands so callers can parse raw bytes.

    Returns:
        ``subprocess.CompletedProcess`` from ``subprocess.run``.

    Raises:
        ValueError: If ``timeout`` is not positive.
        subprocess.TimeoutExpired: If command execution exceeds timeout.
        OSError: If the git executable cannot be launched.

    Notes:
        This wrapper always uses ``shell=False`` (the subprocess default).
    """
    if timeout <= 0:
        raise ValueError("timeout must be greater than 0")

    return subprocess.run(
        cmd,
        capture_output=True,
        text=text,
        timeout=timeout,
        check=False,
        cwd=cwd,
    )


def resolve_git_paths(cwd: str = ".") -> tuple[Path, Path]:
    """Resolve repository root and git directory in a worktree-safe way.

    Returns:
        A tuple ``(repo_root, git_dir)`` where:
        - ``repo_root`` is the absolute path returned by
          ``git rev-parse --show-toplevel``.
        - ``git_dir`` is the absolute path to the repository's effective
          Git directory (for example ``.git`` in normal repos, or the shared
          gitdir for worktrees/submodules).

    Worktree/submodule safety:
        In worktrees and submodules, ``git rev-parse --git-dir`` often returns
        a relative path rather than an absolute path. That relative value must
        be resolved against ``repo_root`` (the working tree root), not against
        the caller's current directory. Resolving against ``cwd`` is incorrect
        when the command is executed from nested directories.

    Args:
        cwd: Directory from which git commands should be executed.

    Raises:
        GitError: If not in a git repository, git metadata cannot be read, or
            returned paths are empty/invalid.
        subprocess.TimeoutExpired: If a git command times out.
        OSError: If git cannot be started.
    """
    repo_result = run_git_command(
        ["git", "rev-parse", "--show-toplevel"],
        timeout=5.0,
        cwd=cwd,
        text=True,
    )
    if repo_result.returncode != 0:
        stderr = (repo_result.stderr or "").strip()
        raise GitError(f"Not in a git repository: {stderr or 'unknown error'}")

    repo_root_raw = (repo_result.stdout or "").strip()
    if not repo_root_raw:
        raise GitError("git rev-parse --show-toplevel returned empty output")
    repo_root = Path(repo_root_raw).resolve()

    git_dir_result = run_git_command(
        ["git", "rev-parse", "--git-dir"],
        timeout=5.0,
        cwd=cwd,
        text=True,
    )
    if git_dir_result.returncode != 0:
        stderr = (git_dir_result.stderr or "").strip()
        raise GitError(f"Cannot resolve git directory: {stderr or 'unknown error'}")

    git_dir_raw = (git_dir_result.stdout or "").strip()
    if not git_dir_raw:
        raise GitError("git rev-parse --git-dir returned empty output")

    git_dir = Path(git_dir_raw)
    if not git_dir.is_absolute():
        git_dir = (repo_root / git_dir).resolve()
    else:
        git_dir = git_dir.resolve()

    return repo_root, git_dir
