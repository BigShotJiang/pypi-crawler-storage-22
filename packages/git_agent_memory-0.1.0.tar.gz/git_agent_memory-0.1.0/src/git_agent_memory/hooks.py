"""Global Git hook installation and removal for git-agent-memory.

This module manages a global ``post-commit`` hook using ``core.hooksPath``.
The installer is designed to be:

- Idempotent: repeated installs are safe.
- Non-destructive: existing hooks are preserved via backup chaining.
- Recursion-safe: managed backups are detected and installation aborts.
- Cross-platform: Windows uses ``python -m git_agent_memory``, Unix uses the
  resolved ``git-agent-memory`` executable path.

The generated hook script always exits success so commits are never blocked.
"""

from __future__ import annotations

from pathlib import Path
import shlex
import shutil
import subprocess
import sys

HOOK_MARKER = "# managed-by: git-agent-memory"
BACKUP_SUFFIX = ".gam.orig"

_HOOK_NAME = "post-commit"
_STATE_DIR_NAME = ".git-agent-memory"


class InstallError(RuntimeError):
    """Raised when hook installation prerequisites are not satisfied."""


def _default_state_dir() -> Path:
    """Return the absolute state directory path used by this package."""
    return (Path.home() / _STATE_DIR_NAME).resolve()


def _default_hooks_dir() -> Path:
    """Return the default absolute hooks directory for global installation."""
    return (_default_state_dir() / "hooks").resolve()


def _error_log_path() -> Path:
    """Return the absolute path of the hook error log file."""
    return (_default_state_dir() / "errors.log").resolve()


def _run_git_config_global(args: list[str]) -> subprocess.CompletedProcess[str]:
    """Run ``git config --global`` and return the completed process result."""
    return subprocess.run(
        ["git", "config", "--global", *args],
        capture_output=True,
        text=True,
        check=False,
        timeout=2.0,
    )


def _get_core_hooks_path() -> str | None:
    """Return global ``core.hooksPath`` if set, otherwise ``None``."""
    result = _run_git_config_global(["--get", "core.hooksPath"])
    if result.returncode != 0:
        return None

    value = (result.stdout or "").strip()
    return value or None


def _set_core_hooks_path(path: Path) -> bool:
    """Set global ``core.hooksPath`` to ``path`` and report success."""
    result = _run_git_config_global(["core.hooksPath", str(path)])
    if result.returncode != 0:
        stderr = (result.stderr or "").strip() or "unknown error"
        print(f"Failed to set core.hooksPath: {stderr}")
        return False
    return True


def _unset_core_hooks_path() -> bool:
    """Unset global ``core.hooksPath`` and report success."""
    result = _run_git_config_global(["--unset", "core.hooksPath"])
    if result.returncode != 0:
        stderr = (result.stderr or "").strip() or "unknown error"
        print(f"Failed to unset core.hooksPath: {stderr}")
        return False
    return True


def _read_text(path: Path) -> str:
    """Read UTF-8 text from ``path`` with replacement fallback on decode errors."""
    return path.read_text(encoding="utf-8", errors="replace")


def _contains_marker(path: Path) -> bool:
    """Return ``True`` if file text contains the managed hook marker."""
    try:
        return HOOK_MARKER in _read_text(path)
    except OSError:
        return False


def _make_executable(path: Path) -> None:
    """Set executable bits on ``path`` when supported by the platform."""
    try:
        current_mode = path.stat().st_mode
        path.chmod(current_mode | 0o111)
    except OSError:
        # Best-effort only; do not fail installation if chmod is unsupported.
        pass


def get_executable_path() -> str:
    """Return the absolute path to the ``git-agent-memory`` executable.

    Resolution strategy:
    1. Find ``git-agent-memory`` via ``shutil.which``.
    2. On Windows, resolve ``.exe`` shims when needed.
    3. Return an absolute resolved path.

    Raises:
        InstallError: If the executable cannot be found in ``PATH``.
    """
    binary = shutil.which("git-agent-memory")
    if sys.platform == "win32" and not binary:
        binary = shutil.which("git-agent-memory.exe")

    if not binary:
        raise InstallError("Cannot find git-agent-memory in PATH")

    if sys.platform == "win32" and not binary.lower().endswith(".exe"):
        exe_candidate = Path(f"{binary}.exe")
        if exe_candidate.exists():
            binary = str(exe_candidate)
        else:
            shim = shutil.which("git-agent-memory.exe")
            if shim:
                binary = shim

    return str(Path(binary).resolve())


def create_hook_script(binary_path: str, has_backup: bool) -> str:
    """Create the managed ``post-commit`` hook shell script.

    The generated script is always safe for commits:
    - It uses ``set +e`` and ends with ``exit 0``.
    - Any errors from capture are appended to an absolute error log path.
    - If a backup hook exists, it is executed via ``sh`` to avoid shebang or
      executable-bit compatibility issues.

    Args:
        binary_path: Absolute or relative path to ``git-agent-memory``.
            Relative values are normalized to absolute paths in the output.
        has_backup: Whether backup chaining logic should be included.

    Returns:
        Full hook script text with a trailing newline.
    """
    binary_abs = str(Path(binary_path).expanduser().resolve())
    error_log_abs = str(_error_log_path())

    if sys.platform == "win32":
        python_exe = str(Path(sys.executable).resolve())
        # Git hooks run under sh; use POSIX single-quote escaping for Windows paths.
        safe_path = python_exe.replace("'", "'\\''")
        invocation = f"'{safe_path}' -m git_agent_memory capture"
    else:
        invocation = f"{shlex.quote(binary_abs)} capture"

    lines = [
        "#!/bin/sh",
        HOOK_MARKER,
        "# Auto-generated by git-agent-memory",
        "# Never fail the commit",
        "set +e",
        "",
    ]

    if has_backup:
        lines.extend(
            [
                "# Run original post-commit hook when available",
                'HOOK_DIR="$(cd "$(dirname "$0")" && pwd)"',
                f'ORIGINAL="$HOOK_DIR/{_HOOK_NAME}{BACKUP_SUFFIX}"',
                'if [ -f "$ORIGINAL" ]; then',
                '    sh "$ORIGINAL" "$@" || true',
                "fi",
                "",
            ]
        )

    lines.extend(
        [
            f"ERROR_LOG={shlex.quote(error_log_abs)}",
            f'{invocation} 2>> "$ERROR_LOG" || true',
            "",
            "exit 0",
        ]
    )

    return "\n".join(lines) + "\n"


def install_global_hook() -> bool:
    """Install the managed global ``post-commit`` hook.

    Behavior:
    - Reads global ``core.hooksPath``.
    - Refuses to install when ``core.hooksPath`` is relative.
    - Uses ``~/.git-agent-memory/hooks`` when hooks path is unset.
    - Installs in existing absolute hooks directory when configured.
    - Is idempotent using ``HOOK_MARKER``.
    - Backs up unmanaged existing hook to ``.gam.orig``.
    - Prevents recursion by rejecting backups containing ``HOOK_MARKER``.
    - Marks the resulting hook executable.

    Returns:
        ``True`` when installation is complete or already installed, otherwise
        ``False`` when a recoverable installation constraint is encountered.
    """
    try:
        configured = _get_core_hooks_path()
    except OSError as exc:
        print(f"Failed to read core.hooksPath: {exc}")
        return False

    if configured:
        if not Path(configured).is_absolute():
            print(f"Error: core.hooksPath is relative: {configured}")
            print("Refusing to install global hook safely.")
            return False
        hooks_dir = Path(configured).expanduser().resolve()
    else:
        hooks_dir = _default_hooks_dir()

    try:
        hooks_dir.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        print(f"Failed to create hooks directory {hooks_dir}: {exc}")
        return False

    if not configured and not _set_core_hooks_path(hooks_dir):
        return False

    # Ensure error log directory exists before hook execution begins.
    try:
        _error_log_path().parent.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        print(f"Failed to create error log directory: {exc}")
        return False

    hook_file = hooks_dir / _HOOK_NAME
    backup_file = hooks_dir / f"{_HOOK_NAME}{BACKUP_SUFFIX}"

    if hook_file.exists() and _contains_marker(hook_file):
        return True

    if backup_file.exists() and _contains_marker(backup_file):
        print(f"Refusing installation: backup hook contains marker ({backup_file})")
        print("This would create recursive hook chaining.")
        return False

    if hook_file.exists():
        if backup_file.exists():
            try:
                current_bytes = hook_file.read_bytes()
                backup_bytes = backup_file.read_bytes()
            except OSError as exc:
                print(f"Failed to compare hook and backup files: {exc}")
                return False

            # Preserve non-destructive behavior: do not overwrite an unmanaged hook
            # when an older backup already exists with different contents.
            if current_bytes != backup_bytes and not _contains_marker(hook_file):
                print("Refusing installation: existing unmanaged hook differs from backup.")
                print("Overwriting would discard the current hook chain.")
                return False
        else:
            try:
                shutil.copy2(hook_file, backup_file)
            except OSError as exc:
                print(f"Failed to back up existing hook {hook_file}: {exc}")
                return False

    try:
        binary_path = get_executable_path()
    except InstallError as exc:
        print(str(exc))
        return False

    script = create_hook_script(binary_path=binary_path, has_backup=backup_file.exists())
    try:
        hook_file.write_text(script, encoding="utf-8")
    except OSError as exc:
        print(f"Failed to write hook script {hook_file}: {exc}")
        return False

    _make_executable(hook_file)
    return True


def uninstall_global_hook() -> None:
    """Uninstall the managed global ``post-commit`` hook.

    Behavior:
    - Reads global ``core.hooksPath`` and exits silently if unset.
    - Refuses mutation when ``core.hooksPath`` is relative.
    - Removes only managed hooks (must contain ``HOOK_MARKER``).
    - Restores backup hook from ``.gam.orig`` when available.
    - Optionally unsets ``core.hooksPath`` only when:
      - it points to the default managed hooks directory, and
      - no active ``post-commit`` hook remains after uninstall.
    """
    try:
        configured = _get_core_hooks_path()
    except OSError as exc:
        print(f"Failed to read core.hooksPath: {exc}")
        return

    if not configured:
        return

    if not Path(configured).is_absolute():
        print(f"Warning: core.hooksPath is relative, refusing uninstall changes: {configured}")
        return

    hooks_dir = Path(configured).expanduser().resolve()
    hook_file = hooks_dir / _HOOK_NAME
    backup_file = hooks_dir / f"{_HOOK_NAME}{BACKUP_SUFFIX}"

    if not hook_file.exists() or not _contains_marker(hook_file):
        return

    try:
        if backup_file.exists():
            backup_file.replace(hook_file)
            _make_executable(hook_file)
        else:
            hook_file.unlink()
    except OSError as exc:
        print(f"Failed to uninstall hook {hook_file}: {exc}")
        return

    if hooks_dir == _default_hooks_dir() and not hook_file.exists():
        _unset_core_hooks_path()
