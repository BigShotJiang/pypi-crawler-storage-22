"""Commit parsing utilities for git-agent-memory.

This module reads the latest commit using Git plumbing commands and converts
the result into structured dataclasses for downstream markdown generation.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
import re

from .git_utils import GitError, run_git_command


@dataclass
class FileChange:
    """Represents a single file change in a commit."""

    path: str
    additions: int
    deletions: int
    status: str
    is_binary: bool
    old_path: str | None = None


@dataclass
class CommitData:
    """Structured metadata for one commit."""

    hash: str
    hash_short: str
    author: str
    email: str
    timestamp: datetime
    message: str
    subject: str
    body: str
    branch: str
    files_changed: list[FileChange]
    is_merge: bool = False
    parent_hashes: list[str] | None = None


def parse_latest_commit(timeout: float = 5.0) -> CommitData:
    """Parse the latest commit (`HEAD`) into a :class:`CommitData` object.

    The parser intentionally uses Git CLI commands (via subprocess) instead of
    GitPython for predictable behavior across environments.

    Parsing strategy:
    1. Read metadata via ``git log -1 --pretty=format:...`` (NUL-separated
       bytes mode).
    2. Detect detached HEAD via ``git rev-parse --abbrev-ref HEAD``.
    3. Detect merge commits via ``git rev-list --parents -n 1 HEAD``.
    4. Read changed files via NUL-separated `-z` outputs in bytes mode:
       - ``git diff-tree --name-status -z ...``
       - ``git diff-tree --numstat -z ...``
    5. For merge commits, compare first parent to HEAD (``HEAD^1 -> HEAD``).

    Worktree-safe behavior:
        The command execution itself is repository-aware through Git, and file
        parsing is NUL-safe so filenames with spaces, tabs, or newlines are
        handled without relying on shell parsing.

    Args:
        timeout: Timeout (seconds) applied to each git command invocation.

    Returns:
        Parsed latest commit data.

    Raises:
        GitError: If git command execution fails, output is malformed, or
            timeout is invalid.
    """
    if timeout <= 0:
        raise GitError("timeout must be greater than 0")

    metadata_result = run_git_command(
        [
            "git",
            "log",
            "-1",
            "--pretty=format:%H%x00%h%x00%an%x00%ae%x00%aI%x00%s%x00%x00%b",
        ],
        timeout=timeout,
        text=False,
    )
    if metadata_result.returncode != 0:
        stderr_raw = metadata_result.stderr or b""
        if isinstance(stderr_raw, bytes):
            stderr = _decode_token(stderr_raw).strip()
        else:
            stderr = str(stderr_raw).strip()
        raise GitError(f"Failed to get commit metadata: {stderr or 'unknown error'}")

    (
        full_hash,
        short_hash,
        author,
        email,
        timestamp,
        subject,
        body,
    ) = _parse_metadata_output(metadata_result.stdout or b"")

    branch_result = run_git_command(
        ["git", "rev-parse", "--abbrev-ref", "HEAD"],
        timeout=timeout,
        text=True,
    )
    if branch_result.returncode != 0:
        stderr = (branch_result.stderr or "").strip()
        raise GitError(f"Failed to get branch name: {stderr or 'unknown error'}")
    branch = (branch_result.stdout or "").strip()
    if branch == "HEAD":
        branch = f"Detached HEAD (at {short_hash})"

    parents_result = run_git_command(
        ["git", "rev-list", "--parents", "-n", "1", "HEAD"],
        timeout=timeout,
        text=True,
    )
    if parents_result.returncode != 0:
        stderr = (parents_result.stderr or "").strip()
        raise GitError(f"Failed to get parent hashes: {stderr or 'unknown error'}")

    parent_tokens = (parents_result.stdout or "").strip().split()
    if not parent_tokens:
        raise GitError("Unexpected empty output from git rev-list --parents")

    parent_hashes = parent_tokens[1:]
    is_merge = len(parent_hashes) > 1

    if is_merge:
        status_cmd = [
            "git",
            "diff-tree",
            "--no-commit-id",
            "--name-status",
            "-z",
            "-r",
            "-M",
            "-C",
            "HEAD^1",
            "HEAD",
        ]
        numstat_cmd = [
            "git",
            "diff-tree",
            "--no-commit-id",
            "--numstat",
            "-z",
            "-r",
            "-M",
            "-C",
            "HEAD^1",
            "HEAD",
        ]
    else:
        # --root ensures initial commits still produce file changes.
        status_cmd = [
            "git",
            "diff-tree",
            "--no-commit-id",
            "--name-status",
            "-z",
            "-r",
            "-M",
            "-C",
            "--root",
            "HEAD",
        ]
        numstat_cmd = [
            "git",
            "diff-tree",
            "--no-commit-id",
            "--numstat",
            "-z",
            "-r",
            "-M",
            "-C",
            "--root",
            "HEAD",
        ]

    status_result = run_git_command(status_cmd, timeout=timeout, text=False)
    if status_result.returncode != 0:
        stderr = _decode_token(status_result.stderr or b"").strip()
        raise GitError(f"Failed to get file status: {stderr or 'unknown error'}")

    numstat_result = run_git_command(numstat_cmd, timeout=timeout, text=False)
    if numstat_result.returncode != 0:
        stderr = _decode_token(numstat_result.stderr or b"").strip()
        raise GitError(f"Failed to get file stats: {stderr or 'unknown error'}")

    files_changed = parse_file_changes_z(
        status_output=status_result.stdout or b"",
        numstat_output=numstat_result.stdout or b"",
    )

    message = subject if not body else f"{subject}\n\n{body}"
    return CommitData(
        hash=full_hash,
        hash_short=short_hash,
        author=author,
        email=email,
        timestamp=timestamp,
        message=message,
        subject=subject,
        body=body,
        branch=branch,
        files_changed=files_changed,
        is_merge=is_merge,
        parent_hashes=parent_hashes if is_merge else None,
    )


def parse_file_changes_z(status_output: bytes, numstat_output: bytes) -> list[FileChange]:
    """Parse file changes from NUL-separated git diff outputs.

    Inputs must come from commands run with ``text=False``:
    - ``git diff-tree --name-status -z ...`` (status + path mapping)
    - ``git diff-tree --numstat -z ...`` (additions/deletions)

    CRITICAL parsing rules:
    - Split bytes outputs on ``b'\\0'``.
    - Decode each token independently with ``errors='replace'``.
    - For rename/copy statuses (`R*`/`C*`), consume two path tokens:
      ``old_path`` and ``new_path``.
    - Name-status is authoritative for path/status mapping.
    - Numstat provides add/del counts; if no mapping is found for a path,
      use ``0/0`` and keep the status/path from name-status.

    Args:
        status_output: Raw bytes from ``--name-status -z``.
        numstat_output: Raw bytes from ``--numstat -z``.

    Returns:
        Parsed list of :class:`FileChange` entries.
    """
    status_entries: list[tuple[str, str, str | None]] = []
    status_by_path: dict[str, tuple[str, str | None]] = {}

    status_tokens = status_output.split(b"\0")
    i = 0
    while i < len(status_tokens):
        status_token = status_tokens[i]
        if not status_token:
            i += 1
            continue

        status_raw = _decode_token(status_token).strip()
        if not status_raw:
            i += 1
            continue

        status_code = status_raw[0]
        if status_code in {"R", "C"}:
            if i + 2 >= len(status_tokens):
                break
            old_path = _decode_token(status_tokens[i + 1])
            new_path = _decode_token(status_tokens[i + 2])
            status_entries.append((new_path, status_code, old_path))
            status_by_path[new_path] = (status_code, old_path)
            i += 3
            continue

        if i + 1 >= len(status_tokens):
            break
        path = _decode_token(status_tokens[i + 1])
        status_entries.append((path, status_code, None))
        status_by_path[path] = (status_code, None)
        i += 2

    numstat_map: dict[str, tuple[int, int, bool]] = {}
    numstat_order: list[str] = []

    def record_numstat(path: str, additions_raw: str, deletions_raw: str) -> None:
        additions, deletions, is_binary = _parse_numstat_counts(
            additions_raw, deletions_raw
        )
        numstat_map[path] = (additions, deletions, is_binary)
        numstat_order.append(path)

    numstat_tokens = numstat_output.split(b"\0")
    i = 0
    while i < len(numstat_tokens):
        token = numstat_tokens[i]
        if not token:
            i += 1
            continue

        if b"\t" in token:
            parts = token.split(b"\t", 2)
            if len(parts) < 2:
                i += 1
                continue

            additions_raw = _decode_token(parts[0])
            deletions_raw = _decode_token(parts[1])
            path_inline = parts[2] if len(parts) > 2 else b""

            if path_inline:
                path = _decode_token(path_inline)
                if path:
                    record_numstat(path, additions_raw, deletions_raw)
                i += 1
                continue

            # Rename/copy form in real -z numstat output:
            # "adds\\tdels\\t\\0old\\0new\\0"
            old_path_token = numstat_tokens[i + 1] if i + 1 < len(numstat_tokens) else b""
            new_path_token = numstat_tokens[i + 2] if i + 2 < len(numstat_tokens) else b""

            path_token = new_path_token or old_path_token
            path = _decode_token(path_token) if path_token else ""
            if path:
                record_numstat(path, additions_raw, deletions_raw)

            if i + 2 < len(numstat_tokens):
                i += 3
            elif i + 1 < len(numstat_tokens):
                i += 2
            else:
                i += 1
            continue

        # Fallback for token streams represented as:
        # adds\0dels\0path\0...
        if i + 2 >= len(numstat_tokens):
            break

        additions_raw = _decode_token(numstat_tokens[i])
        deletions_raw = _decode_token(numstat_tokens[i + 1])
        path = _decode_token(numstat_tokens[i + 2])
        if path:
            record_numstat(path, additions_raw, deletions_raw)
        i += 3

    changes: list[FileChange] = []
    seen_paths: set[str] = set()

    for path, status_code, old_path in status_entries:
        additions, deletions, is_binary = numstat_map.get(path, (0, 0, False))
        changes.append(
            FileChange(
                path=path,
                additions=additions,
                deletions=deletions,
                status=status_code,
                is_binary=is_binary,
                old_path=old_path,
            )
        )
        seen_paths.add(path)

    # Include any numstat entries not present in name-status output.
    for path in numstat_order:
        if path in seen_paths:
            continue
        additions, deletions, is_binary = numstat_map[path]
        status_code, old_path = status_by_path.get(path, ("M", None))
        changes.append(
            FileChange(
                path=path,
                additions=additions,
                deletions=deletions,
                status=status_code,
                is_binary=is_binary,
                old_path=old_path,
            )
        )

    return changes


def detect_commit_type(message: str) -> str:
    """Detect a Conventional Commit type from a commit message.

    Supports common prefixes such as:
    ``feat``, ``fix``, ``docs``, ``style``, ``refactor``, ``perf``,
    ``test``, ``build``, ``ci``, ``chore``, ``revert``.

    Args:
        message: Full commit message (subject and optional body).

    Returns:
        The detected type string, or ``"chore"`` as a safe default when no
        known pattern matches.
    """
    subject = message.splitlines()[0].strip().lower() if message else ""
    pattern = re.compile(
        r"^(feat|fix|docs|style|refactor|perf|test|build|ci|chore|revert)(\(.+\))?!?:"
    )
    match = pattern.match(subject)
    if match:
        return match.group(1)
    return "chore"


def _parse_metadata_output(output: bytes) -> tuple[str, str, str, str, datetime, str, str]:
    """Parse NUL-separated metadata from ``git log -1 --pretty=format``.

    Expected layout:
    1. full hash
    2. short hash
    3. author
    4. email
    5. ISO-8601 timestamp
    6. subject
    7. body payload (prefixed by one NUL separator for compatibility with
       the ``%x00%x00%b`` format marker sequence)
    """
    parts = output.split(b"\0", 6)
    if len(parts) < 7:
        raise GitError("Malformed git log output for latest commit metadata")

    full_hash = _decode_token(parts[0]).strip()
    short_hash = _decode_token(parts[1]).strip()
    author = _decode_token(parts[2]).strip()
    email = _decode_token(parts[3]).strip()
    iso_timestamp = _decode_token(parts[4]).strip()
    subject = _decode_token(parts[5]).strip()
    remainder = parts[6]
    if not all([full_hash, short_hash, author, email, iso_timestamp]):
        raise GitError("Incomplete commit metadata from git log output")

    try:
        timestamp = datetime.fromisoformat(iso_timestamp.replace("Z", "+00:00"))
    except ValueError as exc:
        raise GitError(f"Invalid commit timestamp: {iso_timestamp}") from exc

    # Output includes an explicit extra NUL separator before body payload.
    if remainder.startswith(b"\0"):
        remainder = remainder[1:]
    body = _decode_token(remainder).rstrip("\n")

    return full_hash, short_hash, author, email, timestamp, subject, body


def _parse_numstat_counts(additions_raw: str, deletions_raw: str) -> tuple[int, int, bool]:
    """Parse numstat counters, handling binary `-` markers safely."""
    is_binary = additions_raw == "-" and deletions_raw == "-"
    if is_binary:
        return 0, 0, True

    try:
        additions = int(additions_raw)
    except ValueError:
        additions = 0
    try:
        deletions = int(deletions_raw)
    except ValueError:
        deletions = 0
    return additions, deletions, False


def _decode_token(token: bytes) -> str:
    """Decode one bytes token safely for NUL-separated parsing."""
    return token.decode("utf-8", errors="replace")
