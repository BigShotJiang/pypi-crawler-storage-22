"""Markdown rendering and file persistence utilities for commit memory."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
import errno
import logging
import os
import re
import tempfile
import time
from pathlib import Path
from typing import IO, Any

from .parser import CommitData, detect_commit_type

MARKER_VERSION = "1"
MAX_FILES_DISPLAY = 20

_HASH_MARKER_RE = re.compile(r"<!-- git-agent-memory:hash=[a-f0-9]+ -->")
_LOCK_LOG_INTERVAL_SECONDS = 30.0
_LAST_LOCK_TIMEOUT_LOG_BY_PATH: dict[str, float] = {}
_LOGGER = logging.getLogger(__name__)


@dataclass
class WriterConfig:
    """Fallback/default writer configuration."""

    file_name: str = "commits.md"
    max_entries: int = 100


class LockTimeoutError(Exception):
    """Raised when a file lock cannot be acquired within the timeout budget."""


class FileLock:
    """Cross-platform non-blocking file lock with a bounded wait budget.

    This class uses:
    - Unix/macOS: ``fcntl.flock(..., LOCK_EX | LOCK_NB)``
    - Windows: ``msvcrt.locking(..., LK_NBLCK, 1)``

    Design rules from the build spec:
    - Lock files are persistent and are never deleted by this class.
    - Lock acquisition uses non-blocking attempts only.
    - Wait time is bounded (200ms default), then ``LockTimeoutError`` is raised.
    - Lock file is opened in append mode (creates file if missing).

    The context manager always closes the lock file handle on exit and releases
    the lock if it was acquired.
    """

    def __init__(
        self,
        target_file: Path,
        timeout_ms: int = 200,
        poll_interval_ms: int = 10,
    ) -> None:
        """Initialize a persistent lock for a target file path.

        Args:
            target_file: File whose associated lock should be acquired.
            timeout_ms: Maximum wait budget in milliseconds.
            poll_interval_ms: Delay between non-blocking retry attempts.
        """
        self.lock_file = target_file.with_suffix(".lock")
        self.timeout_ms = timeout_ms
        self.poll_interval_ms = poll_interval_ms
        self._file: IO[str] | None = None
        self._acquired = False

    def __enter__(self) -> "FileLock":
        """Acquire the file lock within the bounded timeout budget."""
        self.lock_file.parent.mkdir(parents=True, exist_ok=True)
        self._file = self.lock_file.open("a", encoding="utf-8")

        # Windows byte-range locking needs at least one byte available.
        self._ensure_lock_file_has_content()

        deadline = time.monotonic() + (self.timeout_ms / 1000.0)
        poll_interval_seconds = max(self.poll_interval_ms, 1) / 1000.0

        while True:
            try:
                self._try_acquire_non_blocking()
                self._acquired = True
                return self
            except OSError as exc:
                if not _is_lock_contention(exc):
                    self._close_file()
                    raise

                if time.monotonic() >= deadline:
                    _log_lock_timeout_once(self.lock_file, self.timeout_ms)
                    self._close_file()
                    raise LockTimeoutError(
                        f"Could not acquire lock within {self.timeout_ms}ms"
                    )

                time.sleep(poll_interval_seconds)

    def __exit__(self, exc_type, exc, tb) -> None:
        """Release lock and close file handle, leaving lock file in place."""
        try:
            if self._acquired:
                self._release_lock()
        finally:
            self._close_file()
            # Intentionally do not delete self.lock_file (persistent policy).

    def _ensure_lock_file_has_content(self) -> None:
        """Ensure the lock file contains at least one byte for Windows locking."""
        if self._file is None:
            return
        self._file.seek(0, os.SEEK_END)
        if self._file.tell() == 0:
            self._file.write("\n")
            self._file.flush()
        self._file.seek(0)

    def _try_acquire_non_blocking(self) -> None:
        """Attempt a single non-blocking lock acquisition."""
        if self._file is None:
            raise OSError("Lock file handle is not open")

        if os.name == "nt":
            import msvcrt

            self._file.seek(0)
            msvcrt.locking(self._file.fileno(), msvcrt.LK_NBLCK, 1)
            return

        import fcntl

        fcntl.flock(self._file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)

    def _release_lock(self) -> None:
        """Release an already acquired lock."""
        if self._file is None:
            return

        if os.name == "nt":
            import msvcrt

            self._file.seek(0)
            msvcrt.locking(self._file.fileno(), msvcrt.LK_UNLCK, 1)
            return

        import fcntl

        fcntl.flock(self._file.fileno(), fcntl.LOCK_UN)

    def _close_file(self) -> None:
        """Close and reset lock file handle state."""
        if self._file is not None:
            try:
                self._file.close()
            finally:
                self._file = None
                self._acquired = False


def _is_lock_contention(exc: OSError) -> bool:
    """Return True when the error indicates lock contention."""
    if isinstance(exc, BlockingIOError):
        return True

    if exc.errno in (errno.EACCES, errno.EAGAIN):
        return True

    # Windows lock violation is often surfaced via winerror 33.
    if getattr(exc, "winerror", None) == 33:
        return True

    return False


def _log_lock_timeout_once(lock_file: Path, timeout_ms: int) -> None:
    """Log lock timeout with per-path throttling to avoid noisy logs."""
    now = time.monotonic()
    lock_key = str(lock_file.resolve())
    previous = _LAST_LOCK_TIMEOUT_LOG_BY_PATH.get(lock_key, 0.0)
    if now - previous < _LOCK_LOG_INTERVAL_SECONDS:
        return

    _LAST_LOCK_TIMEOUT_LOG_BY_PATH[lock_key] = now
    _LOGGER.warning(
        "Lock timeout after %sms for %s; skipping write",
        timeout_ms,
        lock_key,
    )


def format_commit(commit_data: CommitData) -> str:
    """Format one commit entry in markdown with machine-parseable markers.

    Output includes:
    - Hash/version markers used for deduplication and parsing
    - Commit metadata (type, hash, date, author, branch)
    - Merge details and first-parent diff note when applicable
    - File summary with truncation above ``MAX_FILES_DISPLAY``
    - Impact classification (Low/Medium/High)

    Args:
        commit_data: Parsed commit metadata and file changes.
    Returns:
        Formatted markdown entry including a trailing separator line.
    """
    commit_type = detect_commit_type(commit_data.message)
    total_additions = sum(change.additions for change in commit_data.files_changed)
    total_deletions = sum(change.deletions for change in commit_data.files_changed)
    num_files = len(commit_data.files_changed)

    status_label = {
        "A": "Added",
        "M": "Modified",
        "D": "Deleted",
        "R": "Renamed",
        "C": "Copied",
    }

    file_lines: list[str] = []
    for file_change in commit_data.files_changed[:MAX_FILES_DISPLAY]:
        label = status_label.get(file_change.status, "Modified")

        if file_change.status == "R" and file_change.old_path:
            if file_change.is_binary:
                file_lines.append(
                    f"- `{file_change.path}` - Renamed from `{file_change.old_path}` (binary file)"
                )
            else:
                file_lines.append(
                    f"- `{file_change.path}` - Renamed from `{file_change.old_path}` "
                    f"(+{file_change.additions}/-{file_change.deletions})"
                )
            continue

        if file_change.status == "C" and file_change.old_path:
            if file_change.is_binary:
                file_lines.append(
                    f"- `{file_change.path}` - Copied from `{file_change.old_path}` (binary file)"
                )
            else:
                file_lines.append(
                    f"- `{file_change.path}` - Copied from `{file_change.old_path}` "
                    f"(+{file_change.additions}/-{file_change.deletions})"
                )
            continue

        if file_change.is_binary:
            file_lines.append(f"- `{file_change.path}` - Binary file ({label})")
            continue

        file_lines.append(
            f"- `{file_change.path}` - {label} (+{file_change.additions}/-{file_change.deletions})"
        )

    if num_files > MAX_FILES_DISPLAY:
        remaining = num_files - MAX_FILES_DISPLAY
        file_lines.append(f"- ...and {remaining} more files")

    impact = _calculate_impact(total_additions + total_deletions)

    merge_info = ""
    if commit_data.is_merge and commit_data.parent_hashes:
        parent_shorts = [parent[:7] for parent in commit_data.parent_hashes]
        merge_info = (
            f"\n**Merge commit:** {len(parent_shorts)} parents ({', '.join(parent_shorts)})"
            "\n**Note:** File changes shown relative to first parent"
        )

    timestamp_text = commit_data.timestamp.strftime("%Y-%m-%d %H:%M:%S")

    return f"""<!-- git-agent-memory:hash={commit_data.hash} -->
<!-- git-agent-memory:version={MARKER_VERSION} -->

## [{commit_type}] {commit_data.subject}
**Commit:** `{commit_data.hash_short}` (full: `{commit_data.hash}`)  
**Date:** {timestamp_text}  
**Author:** {commit_data.author} <{commit_data.email}>  
**Branch:** {commit_data.branch}{merge_info}

### Message
{commit_data.message}

### Files Changed ({num_files} files, +{total_additions}/-{total_deletions})
{chr(10).join(file_lines)}

**Impact:** {impact}

---
"""


def commit_exists(commits_file: Path, commit_hash: str) -> bool:
    """Check whether a commit hash marker already exists in a commits file.

    Args:
        commits_file: Path to ``commits.md``.
        commit_hash: Full commit hash to search for.

    Returns:
        ``True`` if a matching machine marker is present, otherwise ``False``.
    """
    if not commits_file.exists():
        return False

    marker = f"<!-- git-agent-memory:hash={commit_hash} -->"
    try:
        content = commits_file.read_text(encoding="utf-8")
    except OSError:
        return False
    return marker in content


def parse_entries(content: str) -> list[str]:
    """Split document content into entry blocks using hash markers.

    Args:
        content: Full markdown document content.

    Returns:
        List of entry blocks, each starting with a hash marker.
    """
    matches = list(_HASH_MARKER_RE.finditer(content))
    if not matches:
        return []

    entries: list[str] = []
    for index, match in enumerate(matches):
        start = match.start()
        end = matches[index + 1].start() if index + 1 < len(matches) else len(content)
        entry = content[start:end].strip()
        if entry:
            entries.append(entry + "\n")
    return entries


def build_document(entries: list[str]) -> str:
    """Build a full markdown document from ordered commit entries.

    Args:
        entries: Commit entries, typically newest first.

    Returns:
        Complete markdown content with top-level header and update timestamp.
    """
    updated_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    header = f"# Commit History\n\nLast updated: {updated_at}\n\n---\n\n"

    if not entries:
        return header

    body = "\n".join(entry.rstrip() for entry in entries).rstrip() + "\n"
    return header + body


def atomic_write(filepath: Path, content: str) -> None:
    """Write content atomically by replacing the target with a temp file.

    The temp file is created in the same directory to ensure ``replace`` is
    atomic on the same filesystem.

    Args:
        filepath: Destination file path.
        content: Full text content to persist.
    """
    filepath.parent.mkdir(parents=True, exist_ok=True)

    temp_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            delete=False,
            dir=str(filepath.parent),
            prefix=f".{filepath.name}.",
            suffix=".tmp",
        ) as temp_file:
            temp_file.write(content)
            temp_path = Path(temp_file.name)

        if temp_path is None:
            raise OSError("Temporary file path was not created")

        temp_path.replace(filepath)
    except Exception:
        if temp_path and temp_path.exists():
            temp_path.unlink()
        raise


def ensure_local_ignore(repo_root: Path, git_dir: Path, filename: str) -> None:
    """Ensure commit memory and lock files are ignored in ``.git/info/exclude``.

    This updates the resolved Git directory's exclude file, which works for
    regular repos, worktrees, and submodules when ``git_dir`` is resolved
    correctly upstream.

    Behavior:
    - Creates ``<git_dir>/info`` if missing.
    - Ensures both the commits file and its lock file are excluded.
    - Appends only missing entries (respects existing absolute/relative forms).
    - Never raises exceptions (logs failures and returns).

    Args:
        repo_root: Repository root path (used only for logging context).
        git_dir: Resolved git directory where ``info/exclude`` lives.
        filename: Name of the generated commits file to ignore locally.
    """
    if not filename:
        return

    exclude_file = git_dir / "info" / "exclude"
    try:
        exclude_file.parent.mkdir(parents=True, exist_ok=True)

        existing_content = ""
        if exclude_file.exists():
            existing_content = exclude_file.read_text(encoding="utf-8", errors="replace")

        existing_entries = {
            line.strip()
            for line in existing_content.splitlines()
            if line.strip() and not line.strip().startswith("#")
        }

        files_to_exclude = [filename]
        lock_filename = str(Path(filename).with_suffix(".lock"))
        if lock_filename and lock_filename not in files_to_exclude:
            files_to_exclude.append(lock_filename)

        missing_entries: list[str] = []
        for target in files_to_exclude:
            candidates = {target, f"/{target}"}
            if not existing_entries.intersection(candidates):
                missing_entries.append(target)

        if not missing_entries:
            return

        with exclude_file.open("a", encoding="utf-8") as handle:
            if existing_content and not existing_content.endswith("\n"):
                handle.write("\n")
            handle.write("# Added by git-agent-memory\n")
            for target in missing_entries:
                handle.write(f"{target}\n")
    except Exception as exc:
        _LOGGER.warning(
            "Failed to update local exclude for %s in %s: %s",
            filename,
            str(repo_root),
            exc,
        )


def write_commit(
    commit_data: CommitData,
    repo_root: Path,
    git_dir: Path,
    timeout: float = 0.5,
) -> None:
    """Persist one commit entry to the repository markdown memory file.

    Workflow:
    1. Load writer config.
    2. Ensure local ignore (`.git/info/exclude`) includes the commits filename.
    3. Acquire file lock with a bounded 200ms timeout.
    4. Skip if commit hash already exists.
    5. Read and parse existing entries.
    6. Prepend the new entry and prune to ``max_entries``.
    7. Write final content atomically.

    Reliability requirements:
    - Never raises exceptions.
    - Lock acquisition timeout is handled via ``LockTimeoutError``.
    - All other failures are logged and swallowed.

    Args:
        commit_data: Commit payload to render and persist.
        repo_root: Repository root where the commits file is written.
        git_dir: Resolved Git directory for local exclude updates.
        timeout: Reserved operation budget in seconds.
    """
    try:
        if timeout <= 0:
            _LOGGER.debug("Skipping write_commit because timeout budget is exhausted")
            return

        config = _load_writer_config(repo_root)
        commits_file = repo_root / config.file_name

        ensure_local_ignore(repo_root, git_dir, config.file_name)

        try:
            with FileLock(commits_file, timeout_ms=200):
                if commit_exists(commits_file, commit_data.hash):
                    return

                existing_entries: list[str] = []
                if commits_file.exists():
                    try:
                        content = commits_file.read_text(encoding="utf-8", errors="replace")
                    except Exception as exc:
                        _LOGGER.warning(
                            "Failed reading existing commit memory %s: %s",
                            str(commits_file),
                            exc,
                        )
                        content = ""

                    if content:
                        existing_entries = parse_entries(content)

                new_entry = format_commit(commit_data)
                all_entries = [new_entry] + existing_entries

                max_entries = max(1, int(config.max_entries))
                pruned_entries = all_entries[:max_entries]

                final_document = build_document(pruned_entries)
                atomic_write(commits_file, final_document)
        except LockTimeoutError:
            # Timeout logging is handled inside FileLock with throttling.
            return
        except Exception as exc:
            _LOGGER.error(
                "Failed to write commit memory for %s: %s",
                str(commits_file),
                exc,
            )
            return
    except Exception as exc:
        _LOGGER.error("write_commit failed for repo %s: %s", str(repo_root), exc)
        return


def _calculate_impact(total_lines_changed: int) -> str:
    """Classify commit impact based on total line changes."""
    if total_lines_changed < 50:
        return "Low"
    if total_lines_changed < 200:
        return "Medium"
    return "High"


def _load_writer_config(repo_root: Path) -> WriterConfig:
    """Load writer config from project config module when available.

    If no config module exists yet, or loading fails, defaults are returned.
    This function never raises.
    """
    defaults = WriterConfig()

    try:
        from .config import load_config  # type: ignore
    except Exception:
        return defaults

    try:
        loaded: Any = load_config(repo_root)
    except Exception as exc:
        _LOGGER.warning("Failed to load config for %s: %s", str(repo_root), exc)
        return defaults

    file_name = getattr(loaded, "file_name", defaults.file_name)
    if not isinstance(file_name, str) or not file_name.strip():
        file_name = defaults.file_name

    max_entries_raw = getattr(loaded, "max_entries", defaults.max_entries)
    try:
        max_entries = int(max_entries_raw)
    except (TypeError, ValueError):
        max_entries = defaults.max_entries
    max_entries = max(1, max_entries)

    return WriterConfig(file_name=file_name, max_entries=max_entries)
