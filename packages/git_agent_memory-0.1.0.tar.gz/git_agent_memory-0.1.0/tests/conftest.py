"""Shared pytest fixtures for git-agent-memory tests."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
import subprocess
import sys
from typing import Any, Callable

import pytest

# Ensure src-layout package imports work when the project is not installed.
PROJECT_ROOT = Path(__file__).resolve().parents[1]
SRC_PATH = PROJECT_ROOT / "src"
if str(SRC_PATH) not in sys.path:
    sys.path.insert(0, str(SRC_PATH))

from git_agent_memory import config as config_module
from git_agent_memory.parser import CommitData, FileChange


def _run_git(repo: Path, *args: str) -> subprocess.CompletedProcess[str]:
    """Run a git command in a repository and fail fast on errors."""
    result = subprocess.run(
        ["git", *args],
        cwd=str(repo),
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        raise AssertionError(
            f"git {' '.join(args)} failed in {repo}:\n"
            f"stdout={result.stdout}\n"
            f"stderr={result.stderr}"
        )
    return result


@pytest.fixture
def git_repo(tmp_path: Path) -> Path:
    """Create a temporary Git repository with one initial commit."""
    repo = tmp_path / "repo"
    repo.mkdir(parents=True, exist_ok=True)

    _run_git(repo, "init")
    _run_git(repo, "config", "user.name", "Test User")
    _run_git(repo, "config", "user.email", "test@example.com")

    (repo / "README.md").write_text("hello\n", encoding="utf-8")
    _run_git(repo, "add", "README.md")
    _run_git(repo, "commit", "-m", "feat: initial commit")
    return repo


@pytest.fixture
def mock_git_commands(
    monkeypatch: pytest.MonkeyPatch,
) -> Callable[[Any], tuple[Callable[..., None], list[dict[str, Any]]]]:
    """Patch a module's ``run_git_command`` with queued fake responses."""

    def _factory(module: Any) -> tuple[Callable[..., None], list[dict[str, Any]]]:
        queued: list[subprocess.CompletedProcess[Any]] = []
        calls: list[dict[str, Any]] = []

        def _fake_run_git_command(
            cmd: list[str],
            timeout: float,
            cwd: str | None = None,
            text: bool = True,
        ) -> subprocess.CompletedProcess[Any]:
            calls.append({"cmd": cmd, "timeout": timeout, "cwd": cwd, "text": text})
            if not queued:
                raise AssertionError(f"No queued response for command: {cmd}")
            return queued.pop(0)

        def _queue(*responses: subprocess.CompletedProcess[Any]) -> None:
            queued.extend(responses)

        monkeypatch.setattr(module, "run_git_command", _fake_run_git_command)
        return _queue, calls

    return _factory


@pytest.fixture
def temp_config_files(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> Path:
    """Point global config path to a temp location for isolated tests."""
    global_config_path = tmp_path / ".git-agent-memory" / "config.yaml"
    monkeypatch.setattr(config_module, "GLOBAL_CONFIG_PATH", global_config_path)
    return global_config_path


@pytest.fixture
def sample_commit_data() -> CommitData:
    """Return a stable commit payload for formatter/writer tests."""
    return CommitData(
        hash="a" * 40,
        hash_short="a" * 7,
        author="Test User",
        email="test@example.com",
        timestamp=datetime(2025, 1, 2, 3, 4, 5, tzinfo=timezone.utc),
        message="feat: add widget\n\nDetailed body",
        subject="feat: add widget",
        body="Detailed body",
        branch="main",
        files_changed=[
            FileChange(
                path="src/widget.py",
                additions=10,
                deletions=2,
                status="M",
                is_binary=False,
            ),
            FileChange(
                path="docs/image.png",
                additions=0,
                deletions=0,
                status="A",
                is_binary=True,
            ),
        ],
        is_merge=False,
        parent_hashes=None,
    )
