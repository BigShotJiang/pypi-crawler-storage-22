"""Tests for CLI command behavior and helper flows."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
import subprocess

from click.testing import CliRunner
import pytest

from git_agent_memory import cli as cli_module
import git_agent_memory.__main__ as module_main
from git_agent_memory.parser import CommitData, FileChange


def _commit_data(hash_value: str = "a" * 40) -> CommitData:
    """Build a small commit object for CLI test stubs."""
    return CommitData(
        hash=hash_value,
        hash_short=hash_value[:7],
        author="Test User",
        email="test@example.com",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        message="feat: test commit",
        subject="feat: test commit",
        body="",
        branch="main",
        files_changed=[
            FileChange(
                path="file.txt",
                additions=1,
                deletions=0,
                status="A",
                is_binary=False,
            )
        ],
        is_merge=False,
        parent_hashes=None,
    )


def _snapshot(
    *,
    git_ok: bool = True,
    git_version: str = "git version 2.0.0",
    hooks_path_raw: str | None = None,
    hooks_path_absolute: Path | None = None,
    hooks_path_is_relative: bool = False,
    hook_file: Path | None = None,
    hook_exists: bool = False,
    hook_managed: bool = False,
    backup_file: Path | None = None,
    backup_exists: bool = False,
) -> cli_module._StatusSnapshot:
    """Build status snapshots for status/doctor command tests."""
    return cli_module._StatusSnapshot(
        git_ok=git_ok,
        git_version=git_version,
        hooks_path_raw=hooks_path_raw,
        hooks_path_absolute=hooks_path_absolute,
        hooks_path_is_relative=hooks_path_is_relative,
        hook_file=hook_file,
        hook_exists=hook_exists,
        hook_managed=hook_managed,
        backup_file=backup_file,
        backup_exists=backup_exists,
    )


def test_cli_help_lists_commands() -> None:
    """Top-level help should include the expected command surface."""
    result = CliRunner().invoke(cli_module.cli, ["--help"])
    assert result.exit_code == 0
    for command in (
        "setup",
        "uninstall",
        "status",
        "doctor",
        "capture",
        "exclude",
        "include",
        "rebuild",
    ):
        assert command in result.output


def test_cli_top_level_version() -> None:
    """Top-level --version should be supported."""
    result = CliRunner().invoke(cli_module.cli, ["--version"])
    assert result.exit_code == 0
    assert cli_module.__version__ in result.output


def test_install_dry_run_unset(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """Dry-run install should show planned default installation path."""
    monkeypatch.setattr(cli_module, "_hook_snapshot", lambda: _snapshot())
    monkeypatch.setattr(cli_module, "_default_hooks_dir", lambda: tmp_path / "hooks")
    monkeypatch.setattr(cli_module, "_error_log_path", lambda: tmp_path / "errors.log")
    result = CliRunner().invoke(cli_module.cli, ["setup", "--dry-run"])
    assert result.exit_code == 0
    assert "Dry-run setup plan:" in result.output
    assert "Set global core.hooksPath" in result.output


def test_install_force_absolute(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """Force-absolute install should convert relative hooksPath before install."""
    called: dict[str, object] = {}

    monkeypatch.setattr(
        cli_module,
        "_hook_snapshot",
        lambda: _snapshot(
            hooks_path_raw="relative/hooks",
            hooks_path_is_relative=True,
        ),
    )
    monkeypatch.setattr(
        cli_module,
        "_set_hooks_path",
        lambda p: (called.setdefault("path", p) or True, "") if False else (True, ""),
    )
    monkeypatch.setattr(cli_module.hooks, "install_global_hook", lambda: True)

    result = CliRunner().invoke(cli_module.cli, ["setup", "--force-absolute"])
    assert result.exit_code == 0
    assert "Converted core.hooksPath to absolute" in result.output
    assert "[OK] Setup complete." in result.output
    assert "Default mode: active for all repositories" in result.output


def test_install_calls_hook_and_reports_failure(monkeypatch: pytest.MonkeyPatch) -> None:
    """Non-dry install should call hook installer and report failure states."""
    monkeypatch.setattr(cli_module, "_hook_snapshot", lambda: _snapshot())
    monkeypatch.setattr(cli_module.hooks, "install_global_hook", lambda: False)
    result = CliRunner().invoke(cli_module.cli, ["setup"])
    assert result.exit_code == 0
    assert "[FAIL] Setup failed" in result.output


def test_uninstall_reports_removed(monkeypatch: pytest.MonkeyPatch) -> None:
    """Uninstall should report successful managed-hook removal."""
    snapshots = iter(
        [
            _snapshot(hook_managed=True),
            _snapshot(hook_managed=False),
        ]
    )
    monkeypatch.setattr(cli_module, "_hook_snapshot", lambda: next(snapshots))
    monkeypatch.setattr(cli_module.hooks, "uninstall_global_hook", lambda: None)
    result = CliRunner().invoke(cli_module.cli, ["uninstall"])
    assert result.exit_code == 0
    assert "Managed global hook removed" in result.output


def test_status_not_set(monkeypatch: pytest.MonkeyPatch) -> None:
    """Status should warn when hooksPath is unset."""
    monkeypatch.setattr(cli_module, "_hook_snapshot", lambda: _snapshot())
    result = CliRunner().invoke(cli_module.cli, ["status"])
    assert result.exit_code == 0
    assert "core.hooksPath: not set" in result.output


def test_status_managed(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """Status should report managed hook and backup details when present."""
    hooks_dir = tmp_path / "hooks"
    hook_file = hooks_dir / "post-commit"
    backup_file = hooks_dir / "post-commit.gam.orig"
    monkeypatch.setattr(
        cli_module,
        "_hook_snapshot",
        lambda: _snapshot(
            hooks_path_raw=str(hooks_dir),
            hooks_path_absolute=hooks_dir,
            hook_file=hook_file,
            hook_exists=True,
            hook_managed=True,
            backup_file=backup_file,
            backup_exists=True,
        ),
    )
    monkeypatch.setattr(cli_module, "_resolve_git_repo_silent", lambda: (None, None))
    result = CliRunner().invoke(cli_module.cli, ["status"])
    assert result.exit_code == 0
    assert "Hook marker found" in result.output
    assert "Backup hook found" in result.output


def test_status_repo_excluded_shows_include_hint(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Status should explain legacy local repo exclusion and how to re-enable."""
    hooks_dir = tmp_path / "hooks"
    hook_file = hooks_dir / "post-commit"
    monkeypatch.setattr(
        cli_module,
        "_hook_snapshot",
        lambda: _snapshot(
            hooks_path_raw=str(hooks_dir),
            hooks_path_absolute=hooks_dir,
            hook_file=hook_file,
            hook_exists=True,
            hook_managed=True,
        ),
    )
    monkeypatch.setattr(cli_module, "_resolve_git_repo_silent", lambda: (tmp_path, tmp_path / ".git"))
    monkeypatch.setattr(cli_module, "should_skip_repo", lambda _repo_root: (True, "disabled via local config"))

    result = CliRunner().invoke(cli_module.cli, ["status"])
    assert result.exit_code == 0
    assert "Current repo is excluded" in result.output
    assert "git-agent-memory include" in result.output


def test_status_repo_excluded_globally_shows_include_hint(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Status should explain global exclusion and how to re-enable."""
    hooks_dir = tmp_path / "hooks"
    hook_file = hooks_dir / "post-commit"
    monkeypatch.setattr(
        cli_module,
        "_hook_snapshot",
        lambda: _snapshot(
            hooks_path_raw=str(hooks_dir),
            hooks_path_absolute=hooks_dir,
            hook_file=hook_file,
            hook_exists=True,
            hook_managed=True,
        ),
    )
    monkeypatch.setattr(cli_module, "_resolve_git_repo_silent", lambda: (tmp_path, tmp_path / ".git"))
    monkeypatch.setattr(cli_module, "should_skip_repo", lambda _repo_root: (True, "in global exclusion list"))

    result = CliRunner().invoke(cli_module.cli, ["status"])
    assert result.exit_code == 0
    assert "excluded in global config" in result.output
    assert "git-agent-memory include" in result.output


def test_install_alias_warns_and_works(monkeypatch: pytest.MonkeyPatch) -> None:
    """Hidden install alias should still work with a deprecation warning."""
    monkeypatch.setattr(cli_module, "_hook_snapshot", lambda: _snapshot())
    monkeypatch.setattr(cli_module.hooks, "install_global_hook", lambda: True)

    result = CliRunner().invoke(cli_module.cli, ["install"])
    assert result.exit_code == 0
    assert "deprecated" in result.output
    assert "[OK] Setup complete." in result.output


def test_status_repo_enabled_default_mode(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Status should report enabled capture in default mode for current repo."""
    hooks_dir = tmp_path / "hooks"
    hook_file = hooks_dir / "post-commit"
    monkeypatch.setattr(
        cli_module,
        "_hook_snapshot",
        lambda: _snapshot(
            hooks_path_raw=str(hooks_dir),
            hooks_path_absolute=hooks_dir,
            hook_file=hook_file,
            hook_exists=True,
            hook_managed=True,
        ),
    )
    monkeypatch.setattr(cli_module, "_resolve_git_repo_silent", lambda: (tmp_path, tmp_path / ".git"))
    monkeypatch.setattr(cli_module, "should_skip_repo", lambda _repo_root: (False, ""))

    result = CliRunner().invoke(cli_module.cli, ["status"])
    assert result.exit_code == 0
    assert "Current repo capture: enabled (default mode)." in result.output


def test_doctor_reports_issues_and_successes(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """Doctor should emit successes, warnings, and issues sections."""
    hooks_dir = tmp_path / "hooks"
    hooks_dir.mkdir(parents=True, exist_ok=True)
    hook_file = hooks_dir / "post-commit"
    hook_file.write_text("#!/bin/sh\n", encoding="utf-8")
    backup_file = hooks_dir / "post-commit.gam.orig"
    backup_file.write_text("# managed-by: git-agent-memory\n", encoding="utf-8")
    log_path = tmp_path / ".git-agent-memory" / "errors.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)

    monkeypatch.setattr(
        cli_module,
        "_hook_snapshot",
        lambda: _snapshot(
            hooks_path_raw=str(hooks_dir),
            hooks_path_absolute=hooks_dir,
            hook_file=hook_file,
            hook_exists=True,
            hook_managed=False,
            backup_file=backup_file,
            backup_exists=True,
        ),
    )
    monkeypatch.setattr(cli_module.hooks, "get_executable_path", lambda: str(tmp_path / "bin"))
    monkeypatch.setattr(cli_module, "_error_log_path", lambda: log_path)
    monkeypatch.setattr(cli_module, "_resolve_git_repo_or_message", lambda: (None, None))

    result = CliRunner().invoke(cli_module.cli, ["doctor"])
    assert result.exit_code == 0
    assert "Doctor report:" in result.output
    assert "Successes:" in result.output
    assert "Warnings:" in result.output
    assert "Issues:" in result.output


def test_capture_with_timeout_success(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """Capture should parse and write when budget remains."""
    calls: dict[str, object] = {}

    monkeypatch.setattr(cli_module, "resolve_git_paths", lambda: (tmp_path, tmp_path / ".git"))
    monkeypatch.setattr(cli_module, "should_skip_repo", lambda _r: (False, ""))
    monkeypatch.setattr(cli_module, "parse_latest_commit", lambda timeout: _commit_data("b" * 40))

    def _write(commit_data, repo_root, git_dir, timeout):
        calls["hash"] = commit_data.hash
        calls["repo_root"] = repo_root
        calls["git_dir"] = git_dir
        calls["timeout"] = timeout

    monkeypatch.setattr(cli_module, "write_commit", _write)
    logs: list[str] = []
    monkeypatch.setattr(cli_module, "_append_error_log", lambda msg: logs.append(msg))
    cli_module.capture_with_timeout(timeout_seconds=0.5)

    assert calls["hash"] == "b" * 40
    assert calls["repo_root"] == tmp_path
    assert calls["git_dir"] == tmp_path / ".git"
    assert isinstance(calls["timeout"], float)
    assert all("Capture failed" not in item for item in logs)


def test_capture_with_timeout_skip(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """Repos marked as skipped should return silently."""
    monkeypatch.setattr(cli_module, "resolve_git_paths", lambda: (tmp_path, tmp_path / ".git"))
    monkeypatch.setattr(cli_module, "should_skip_repo", lambda _r: (True, "disabled"))
    monkeypatch.setattr(
        cli_module,
        "parse_latest_commit",
        lambda timeout: (_ for _ in ()).throw(AssertionError("should not parse")),
    )
    cli_module.capture_with_timeout(timeout_seconds=0.5)


def test_capture_with_timeout_logs_timeout(monkeypatch: pytest.MonkeyPatch) -> None:
    """Subprocess timeouts should be logged and swallowed."""
    monkeypatch.setattr(
        cli_module,
        "resolve_git_paths",
        lambda: (_ for _ in ()).throw(subprocess.TimeoutExpired(cmd=["git"], timeout=0.1)),
    )
    logs: list[str] = []
    monkeypatch.setattr(cli_module, "_append_error_log", lambda msg: logs.append(msg))
    cli_module.capture_with_timeout(timeout_seconds=0.5)
    assert any("timed out" in line for line in logs)


def test_capture_command_swallow_exception(monkeypatch: pytest.MonkeyPatch) -> None:
    """Capture command should always return success and avoid stderr noise."""
    monkeypatch.setattr(
        cli_module,
        "capture_with_timeout",
        lambda timeout_seconds: (_ for _ in ()).throw(RuntimeError("boom")),
    )
    logs: list[str] = []
    monkeypatch.setattr(cli_module, "_append_error_log", lambda msg: logs.append(msg))

    result = CliRunner().invoke(cli_module.cli, ["capture"])
    assert result.exit_code == 0
    try:
        stderr_value = (result.stderr or "")
    except ValueError:
        stderr_bytes = getattr(result, "stderr_bytes", None)
        stderr_value = (
            stderr_bytes.decode("utf-8", errors="replace")
            if isinstance(stderr_bytes, (bytes, bytearray))
            else ""
        )
    assert stderr_value == ""
    assert any("Unexpected capture wrapper failure" in line for line in logs)


def test_exclude_updates_global_exclusions_without_local_file(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Exclude should update global exclusions and avoid creating local config."""
    monkeypatch.setattr(cli_module, "_resolve_git_repo_or_message", lambda: (tmp_path, tmp_path / ".git"))
    monkeypatch.setattr(cli_module, "exclude_repo_globally", lambda repo_root: (True, None))
    monkeypatch.setattr(cli_module, "_remove_local_disable_override", lambda _repo_root: (False, None))
    result = CliRunner().invoke(cli_module.cli, ["exclude"])
    assert result.exit_code == 0
    assert "Disabled git-agent-memory for repo" in result.output
    assert not (tmp_path / ".git-agent-memory.yaml").exists()


def test_include_removes_only_enabled(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """Include should remove enabled override and preserve other keys."""
    cfg = tmp_path / ".git-agent-memory.yaml"
    cfg.write_text("enabled: false\nmax_entries: 25\n", encoding="utf-8")
    monkeypatch.setattr(cli_module, "_resolve_git_repo_or_message", lambda: (tmp_path, tmp_path / ".git"))
    monkeypatch.setattr(cli_module, "include_repo_globally", lambda _repo_root: (False, None))
    result = CliRunner().invoke(cli_module.cli, ["include"])
    assert result.exit_code == 0
    assert cfg.exists()
    content = cfg.read_text(encoding="utf-8")
    assert "enabled:" not in content
    assert "max_entries: 25" in content


def test_rebuild_invalid_max_entries() -> None:
    """Rebuild should reject invalid max_entries values."""
    result = CliRunner().invoke(cli_module.cli, ["rebuild", "--max-entries", "0"])
    assert result.exit_code == 0
    assert "must be >= 1" in result.output


def test_rebuild_empty_history(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """Rebuild should create an empty commits document when there is no history."""
    monkeypatch.setattr(cli_module, "_resolve_git_repo_or_message", lambda: (tmp_path, tmp_path / ".git"))
    monkeypatch.setattr(
        cli_module,
        "load_config",
        lambda repo_root: type(
            "Cfg",
            (),
            {"file_name": "commits.md", "track_commits_file": False, "max_entries": 10},
        )(),
    )

    def _fake_run(cmd, timeout, text=True, cwd=None):
        if cmd[:2] == ["git", "rev-list"]:
            return subprocess.CompletedProcess(cmd, 0, stdout="", stderr="")
        return subprocess.CompletedProcess(cmd, 0, stdout="", stderr="")

    monkeypatch.setattr(cli_module, "run_git_command", _fake_run)
    called: dict[str, object] = {}
    monkeypatch.setattr(cli_module, "atomic_write", lambda path, content: called.update({"path": path, "content": content}))
    monkeypatch.setattr(cli_module, "ensure_local_ignore", lambda *args, **kwargs: called.update({"ignored": True}))

    result = CliRunner().invoke(cli_module.cli, ["rebuild", "--max-entries", "5"])
    assert result.exit_code == 0
    assert "[OK] Rebuilt empty history file" in result.output
    assert str(called["path"]).endswith("commits.md")
    assert "Commit History" in str(called["content"])
    assert called.get("ignored") is True


def test_main_version_and_help() -> None:
    """Main command should provide both version and help flows."""
    runner = CliRunner()
    v = runner.invoke(cli_module.cli, ["main", "--version"])
    assert v.exit_code == 0
    assert v.output.strip()

    h = runner.invoke(cli_module.cli, ["main"])
    assert h.exit_code == 0
    assert "Usage:" in h.output


def test_module_entrypoint_calls_cli(monkeypatch: pytest.MonkeyPatch) -> None:
    """python -m git_agent_memory should dispatch to the Click CLI."""
    called: dict[str, object] = {}

    def _fake_cli(*args, **kwargs):
        called["prog_name"] = kwargs.get("prog_name")

    monkeypatch.setattr(module_main, "cli", _fake_cli)
    module_main.main()
    assert called["prog_name"] == "git-agent-memory"
