"""Tests for configuration loading/merging and skip decisions."""

from __future__ import annotations

from pathlib import Path
import subprocess

import yaml

from git_agent_memory import config


def test_load_config_defaults(temp_config_files: Path, tmp_path: Path) -> None:
    """Missing config files should return default configuration values."""
    repo_root = tmp_path / "repo-defaults"
    repo_root.mkdir(parents=True, exist_ok=True)

    loaded = config.load_config(repo_root=repo_root)
    assert loaded.enabled is True
    assert loaded.max_entries == 100
    assert loaded.file_name == "commits.md"
    assert loaded.track_commits_file is False
    assert loaded.excluded_repos == []

    assert not temp_config_files.exists()


def test_load_config_merge(temp_config_files: Path, tmp_path: Path) -> None:
    """Local repo config should override global values when both exist."""
    repo_root = tmp_path / "repo-merge"
    repo_root.mkdir(parents=True, exist_ok=True)

    excluded_repo = tmp_path / "sensitive"
    global_payload = {
        "enabled": True,
        "max_entries": 250,
        "file_name": "global-commits.md",
        "track_commits_file": False,
        "excluded_repos": [str(excluded_repo)],
    }
    temp_config_files.parent.mkdir(parents=True, exist_ok=True)
    temp_config_files.write_text(yaml.safe_dump(global_payload), encoding="utf-8")

    local_payload = {
        "max_entries": 15,
        "file_name": "local-commits.md",
        "track_commits_file": True,
    }
    (repo_root / config.LOCAL_CONFIG_FILENAME).write_text(
        yaml.safe_dump(local_payload),
        encoding="utf-8",
    )

    loaded = config.load_config(repo_root=repo_root)
    assert loaded.enabled is True
    assert loaded.max_entries == 15
    assert loaded.file_name == "local-commits.md"
    assert loaded.track_commits_file is True
    assert any("sensitive" in path for path in loaded.excluded_repos)


def test_should_skip_repo(temp_config_files: Path, tmp_path: Path) -> None:
    """Skip logic should cover local disable, vendor patterns, and global exclusion."""
    repo_root = tmp_path / "repo-skip"
    repo_root.mkdir(parents=True, exist_ok=True)

    (repo_root / config.LOCAL_CONFIG_FILENAME).write_text(
        yaml.safe_dump({"enabled": False}),
        encoding="utf-8",
    )
    skip, reason = config.should_skip_repo(repo_root=repo_root)
    assert skip is True
    assert "disabled via local config" in reason

    (repo_root / config.LOCAL_CONFIG_FILENAME).unlink()
    temp_config_files.parent.mkdir(parents=True, exist_ok=True)
    temp_config_files.write_text(
        yaml.safe_dump({"excluded_repos": [str(repo_root)]}),
        encoding="utf-8",
    )
    skip, reason = config.should_skip_repo(repo_root=repo_root)
    assert skip is True
    assert "global exclusion" in reason

    vendor_repo = tmp_path / "vendor" / "embedded"
    vendor_repo.mkdir(parents=True, exist_ok=True)
    skip, reason = config.should_skip_repo(repo_root=vendor_repo)
    assert skip is True
    assert "inside /vendor/" in reason


def test_save_config_global_and_local(
    temp_config_files: Path,
    tmp_path: Path,
    monkeypatch,
) -> None:
    """save_config should write global and local config files safely."""
    cfg = config.Config(max_entries=33, file_name="memory.md")
    config.save_config(cfg, global_config=True)
    assert temp_config_files.exists()
    global_loaded = yaml.safe_load(temp_config_files.read_text(encoding="utf-8"))
    assert global_loaded["max_entries"] == 33

    local_repo = tmp_path / "local-repo"
    local_repo.mkdir(parents=True, exist_ok=True)
    monkeypatch.setattr(config, "_resolve_repo_root", lambda repo_root: local_repo)
    config.save_config(cfg, global_config=False)
    local_path = local_repo / config.LOCAL_CONFIG_FILENAME
    assert local_path.exists()
    local_loaded = yaml.safe_load(local_path.read_text(encoding="utf-8"))
    assert local_loaded["file_name"] == "memory.md"


def test_is_repo_excluded_global_and_local(temp_config_files: Path, tmp_path: Path) -> None:
    """Exclusion checks should honor global list and local enabled flag."""
    repo_global = tmp_path / "repo-global"
    repo_global.mkdir(parents=True, exist_ok=True)
    temp_config_files.parent.mkdir(parents=True, exist_ok=True)
    temp_config_files.write_text(
        yaml.safe_dump({"excluded_repos": [str(repo_global)]}),
        encoding="utf-8",
    )
    assert config.is_repo_excluded(repo_global) is True

    repo_local = tmp_path / "repo-local"
    repo_local.mkdir(parents=True, exist_ok=True)
    (repo_local / config.LOCAL_CONFIG_FILENAME).write_text(
        yaml.safe_dump({"enabled": False}),
        encoding="utf-8",
    )
    assert config.is_repo_excluded(repo_local) is True


def test_load_config_type_coercion(temp_config_files: Path, tmp_path: Path) -> None:
    """load_config should coerce common non-canonical value types."""
    repo_root = tmp_path / "repo-coerce"
    repo_root.mkdir(parents=True, exist_ok=True)
    temp_config_files.parent.mkdir(parents=True, exist_ok=True)
    temp_config_files.write_text(
        yaml.safe_dump(
            {
                "enabled": "yes",
                "max_entries": "0",
                "file_name": "  ",
                "track_commits_file": "true",
                "excluded_repos": [str(tmp_path / "X")],
            }
        ),
        encoding="utf-8",
    )

    loaded = config.load_config(repo_root=repo_root)
    assert loaded.enabled is True
    assert loaded.max_entries == 1
    assert loaded.file_name == "commits.md"
    assert loaded.track_commits_file is True
    assert len(loaded.excluded_repos) == 1


def test_load_config_file_name_sanitization(temp_config_files: Path, tmp_path: Path) -> None:
    """Unsafe file_name values should fall back to the safe default."""
    repo_root = tmp_path / "repo-file-name"
    repo_root.mkdir(parents=True, exist_ok=True)

    for file_name in ("../outside.md", "/tmp/outside.md", "nested/commits.md", "C:/temp/x.md"):
        temp_config_files.parent.mkdir(parents=True, exist_ok=True)
        temp_config_files.write_text(
            yaml.safe_dump({"file_name": file_name}),
            encoding="utf-8",
        )
        loaded = config.load_config(repo_root=repo_root)
        assert loaded.file_name == "commits.md"


def test_exclude_and_include_repo_globally(temp_config_files: Path, tmp_path: Path) -> None:
    """Global exclusion helpers should persist and remove repo path entries."""
    repo_root = tmp_path / "repo-global-toggle"
    repo_root.mkdir(parents=True, exist_ok=True)

    changed, error = config.exclude_repo_globally(repo_root)
    assert changed is True
    assert error is None
    assert config.should_skip_repo(repo_root)[0] is True

    changed_again, error_again = config.exclude_repo_globally(repo_root)
    assert changed_again is False
    assert error_again is None

    included, include_error = config.include_repo_globally(repo_root)
    assert included is True
    assert include_error is None
    assert config.should_skip_repo(repo_root)[0] is False


def test_should_skip_repo_bare(monkeypatch, tmp_path: Path) -> None:
    """Bare repositories should be skipped with the correct reason."""
    repo_root = tmp_path / "repo-bare"
    repo_root.mkdir(parents=True, exist_ok=True)

    def _fake_run(*args, **kwargs):
        return subprocess.CompletedProcess(
            args=args[0] if args else ["git"],
            returncode=0,
            stdout="true\n",
            stderr="",
        )

    monkeypatch.setattr(config.subprocess, "run", _fake_run)
    skip, reason = config.should_skip_repo(repo_root=repo_root)
    assert skip is True
    assert reason == "bare repository"
