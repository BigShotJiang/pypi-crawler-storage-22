"""Tests for git subprocess helpers and path resolution."""

from __future__ import annotations

from pathlib import Path
import subprocess
import sys

import pytest

from git_agent_memory import git_utils
from git_agent_memory.git_utils import GitError, resolve_git_paths, run_git_command


def _run_git(repo: Path, *args: str) -> subprocess.CompletedProcess[str]:
    """Run a git command in ``repo`` and return the process result."""
    return subprocess.run(
        ["git", *args],
        cwd=str(repo),
        capture_output=True,
        text=True,
        check=False,
    )


def test_resolve_git_paths_normal_repo(git_repo: Path) -> None:
    """Normal repositories should resolve worktree root and absolute git dir."""
    repo_root, git_dir = resolve_git_paths(cwd=str(git_repo))

    assert repo_root == git_repo.resolve()
    assert git_dir.is_absolute()
    assert git_dir.exists()


def test_resolve_git_paths_worktree(git_repo: Path, tmp_path: Path) -> None:
    """Worktrees should resolve to worktree root and effective shared git dir."""
    branch_name = "worktree-branch"
    branch_result = _run_git(git_repo, "branch", branch_name)
    if branch_result.returncode != 0:
        pytest.skip(f"Could not create branch for worktree test: {branch_result.stderr.strip()}")

    worktree_path = tmp_path / "linked-worktree"
    add_result = _run_git(git_repo, "worktree", "add", str(worktree_path), branch_name)
    if add_result.returncode != 0:
        pytest.skip(f"git worktree add unavailable in this environment: {add_result.stderr.strip()}")

    repo_root, git_dir = resolve_git_paths(cwd=str(worktree_path))
    assert repo_root == worktree_path.resolve()
    assert git_dir.is_absolute()
    assert git_dir.exists()


def test_run_git_command_timeout() -> None:
    """Timeouts should raise ``subprocess.TimeoutExpired``."""
    with pytest.raises(subprocess.TimeoutExpired):
        run_git_command(
            [sys.executable, "-c", "import time; time.sleep(0.5)"],
            timeout=0.05,
            text=True,
        )


def test_run_git_command_text_vs_bytes() -> None:
    """text=True should decode output, text=False should preserve bytes."""
    text_result = run_git_command(
        [sys.executable, "-c", "import sys; sys.stdout.write('ok')"],
        timeout=1.0,
        text=True,
    )
    assert text_result.returncode == 0
    assert isinstance(text_result.stdout, str)
    assert text_result.stdout == "ok"

    bytes_result = run_git_command(
        [sys.executable, "-c", "import sys; sys.stdout.buffer.write(b'a\\x00b')"],
        timeout=1.0,
        text=False,
    )
    assert bytes_result.returncode == 0
    assert isinstance(bytes_result.stdout, bytes)
    assert bytes_result.stdout == b"a\x00b"


def test_run_git_command_invalid_timeout() -> None:
    """Non-positive timeout values should raise a validation error."""
    with pytest.raises(ValueError):
        run_git_command(["git", "status"], timeout=0.0)


def test_resolve_git_paths_not_repo(monkeypatch: pytest.MonkeyPatch) -> None:
    """resolve_git_paths should raise GitError when not in a repository."""
    monkeypatch.setattr(
        git_utils,
        "run_git_command",
        lambda *args, **kwargs: subprocess.CompletedProcess(
            ["git"],
            1,
            stdout="",
            stderr="not a repo",
        ),
    )
    with pytest.raises(GitError, match="Not in a git repository"):
        resolve_git_paths(cwd=".")


def test_resolve_git_paths_empty_show_toplevel(monkeypatch: pytest.MonkeyPatch) -> None:
    """Empty --show-toplevel output should raise GitError."""
    responses = iter(
        [
            subprocess.CompletedProcess(["git"], 0, stdout="", stderr=""),
        ]
    )
    monkeypatch.setattr(git_utils, "run_git_command", lambda *args, **kwargs: next(responses))
    with pytest.raises(GitError, match="show-toplevel returned empty output"):
        resolve_git_paths(cwd=".")


def test_resolve_git_paths_git_dir_failures(monkeypatch: pytest.MonkeyPatch) -> None:
    """Git-dir failures and empty output should raise descriptive GitError."""
    repo = str(Path(".").resolve())
    responses = iter(
        [
            subprocess.CompletedProcess(["git"], 0, stdout=repo + "\n", stderr=""),
            subprocess.CompletedProcess(["git"], 1, stdout="", stderr="cannot resolve"),
        ]
    )
    monkeypatch.setattr(git_utils, "run_git_command", lambda *args, **kwargs: next(responses))
    with pytest.raises(GitError, match="Cannot resolve git directory"):
        resolve_git_paths(cwd=".")

    responses2 = iter(
        [
            subprocess.CompletedProcess(["git"], 0, stdout=repo + "\n", stderr=""),
            subprocess.CompletedProcess(["git"], 0, stdout="", stderr=""),
        ]
    )
    monkeypatch.setattr(git_utils, "run_git_command", lambda *args, **kwargs: next(responses2))
    with pytest.raises(GitError, match="rev-parse --git-dir returned empty output"):
        resolve_git_paths(cwd=".")
