"""Tests for global hook installation and removal behavior."""

from __future__ import annotations

from pathlib import Path
import shlex
import subprocess

import pytest

from git_agent_memory import hooks


class FakeGitConfig:
    """Mutable in-memory stand-in for global git config state."""

    def __init__(self, hooks_path: str | None) -> None:
        self.hooks_path = hooks_path
        self.set_calls: list[str] = []
        self.unset_calls = 0

    def get(self) -> str | None:
        """Return the current simulated core.hooksPath value."""
        return self.hooks_path

    def set(self, path: Path) -> bool:
        """Set simulated hooks path and track set operations."""
        self.hooks_path = str(path)
        self.set_calls.append(str(path))
        return True

    def unset(self) -> bool:
        """Unset simulated hooks path and track unset operations."""
        self.hooks_path = None
        self.unset_calls += 1
        return True


def _patch_config(monkeypatch: pytest.MonkeyPatch, fake_config: FakeGitConfig) -> None:
    """Patch hook module git-config helpers with an in-memory fake."""
    monkeypatch.setattr(hooks, "_get_core_hooks_path", fake_config.get)
    monkeypatch.setattr(hooks, "_set_core_hooks_path", fake_config.set)
    monkeypatch.setattr(hooks, "_unset_core_hooks_path", fake_config.unset)


def test_get_executable_path_returns_absolute(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """Executable lookup should return an absolute resolved path."""
    bin_dir = tmp_path / "bin"
    bin_dir.mkdir()
    binary = bin_dir / "git-agent-memory"
    binary.write_text("", encoding="utf-8")

    monkeypatch.setattr(
        hooks.shutil,
        "which",
        lambda name: str(binary) if name == "git-agent-memory" else None,
    )
    monkeypatch.setattr(hooks.sys, "platform", "linux")

    assert hooks.get_executable_path() == str(binary.resolve())


def test_get_executable_path_windows_prefers_exe(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Windows shim lookup should prefer .exe when present."""
    scripts_dir = tmp_path / "Scripts"
    scripts_dir.mkdir()
    base = scripts_dir / "git-agent-memory"
    exe = scripts_dir / "git-agent-memory.exe"
    exe.write_text("", encoding="utf-8")

    def fake_which(name: str) -> str | None:
        if name == "git-agent-memory":
            return str(base)
        if name == "git-agent-memory.exe":
            return str(exe)
        return None

    monkeypatch.setattr(hooks.shutil, "which", fake_which)
    monkeypatch.setattr(hooks.sys, "platform", "win32")

    assert hooks.get_executable_path() == str(exe.resolve())


def test_get_executable_path_raises_when_missing(monkeypatch: pytest.MonkeyPatch) -> None:
    """Missing executable should raise InstallError."""
    monkeypatch.setattr(hooks.shutil, "which", lambda _name: None)
    monkeypatch.setattr(hooks.sys, "platform", "linux")

    with pytest.raises(hooks.InstallError):
        hooks.get_executable_path()


def test_create_hook_script_unix_uses_binary_and_backup_chain(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Unix hook script should use direct binary invocation and HOOK_DIR backup logic."""
    state_dir = tmp_path / "state"
    monkeypatch.setattr(hooks, "_default_state_dir", lambda: state_dir)
    monkeypatch.setattr(hooks.sys, "platform", "linux")

    binary_path = "/usr/local/bin/git-agent-memory"
    script = hooks.create_hook_script(binary_path=binary_path, has_backup=True)

    assert hooks.HOOK_MARKER in script
    assert 'HOOK_DIR="$(cd "$(dirname "$0")" && pwd)"' in script
    assert 'ORIGINAL="$HOOK_DIR/post-commit.gam.orig"' in script
    assert 'sh "$ORIGINAL" "$@" || true' in script
    expected_binary = str(Path(binary_path).expanduser().resolve())
    assert f"{shlex.quote(expected_binary)} capture" in script
    assert "-m git_agent_memory capture" not in script
    assert "~/" not in script
    assert str((state_dir / "errors.log").resolve()) in script


def test_create_hook_script_windows_uses_python_module(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Windows hook script should call python -m with POSIX-safe path quoting."""
    state_dir = tmp_path / "state"
    fake_python = tmp_path / "Program Files" / "O'Brien" / "python.exe"
    monkeypatch.setattr(hooks, "_default_state_dir", lambda: state_dir)
    monkeypatch.setattr(hooks.sys, "platform", "win32")
    monkeypatch.setattr(hooks.sys, "executable", str(fake_python))

    script = hooks.create_hook_script(binary_path="/ignored", has_backup=False)
    resolved_python = str(fake_python.resolve())
    escaped_python = resolved_python.replace("'", "'\\''")

    assert f"'{escaped_python}' -m git_agent_memory capture" in script
    assert "/ignored capture" not in script
    assert str((state_dir / "errors.log").resolve()) in script
    assert "~/" not in script


def test_install_global_hook_unset_path_creates_default(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Unset hooksPath should install into default directory and configure git."""
    state_dir = tmp_path / "state"
    default_hooks = state_dir / "hooks"
    fake_config = FakeGitConfig(hooks_path=None)

    monkeypatch.setattr(hooks, "_default_state_dir", lambda: state_dir)
    monkeypatch.setattr(hooks, "_default_hooks_dir", lambda: default_hooks)
    _patch_config(monkeypatch, fake_config)
    monkeypatch.setattr(
        hooks,
        "get_executable_path",
        lambda: str((tmp_path / "bin" / "git-agent-memory").resolve()),
    )

    assert hooks.install_global_hook() is True

    hook_file = default_hooks / "post-commit"
    assert hook_file.exists()
    assert hooks.HOOK_MARKER in hook_file.read_text(encoding="utf-8")
    assert fake_config.set_calls == [str(default_hooks)]
    assert state_dir.exists()


def test_install_global_hook_refuses_relative_hookspath(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    """Relative core.hooksPath values must be rejected."""
    fake_config = FakeGitConfig(hooks_path="relative/hooks")
    _patch_config(monkeypatch, fake_config)

    assert hooks.install_global_hook() is False

    out = capsys.readouterr().out
    assert "relative" in out
    assert fake_config.set_calls == []


def test_install_global_hook_is_idempotent_for_managed_hook(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Installer should return success without rewriting an already managed hook."""
    hooks_dir = tmp_path / "hooks"
    hooks_dir.mkdir(parents=True, exist_ok=True)
    hook_file = hooks_dir / "post-commit"
    original = f"#!/bin/sh\n{hooks.HOOK_MARKER}\n# existing managed hook\n"
    hook_file.write_text(original, encoding="utf-8")

    fake_config = FakeGitConfig(hooks_path=str(hooks_dir.resolve()))
    _patch_config(monkeypatch, fake_config)
    monkeypatch.setattr(
        hooks,
        "get_executable_path",
        lambda: (_ for _ in ()).throw(AssertionError("should not be called")),
    )

    assert hooks.install_global_hook() is True
    assert hook_file.read_text(encoding="utf-8") == original
    assert not (hooks_dir / f"post-commit{hooks.BACKUP_SUFFIX}").exists()


def test_install_global_hook_backs_up_existing_unmanaged_hook(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Existing unmanaged hook should be backed up before managed wrapper is written."""
    hooks_dir = tmp_path / "hooks"
    hooks_dir.mkdir(parents=True, exist_ok=True)
    hook_file = hooks_dir / "post-commit"
    original = "#!/bin/sh\necho original\n"
    hook_file.write_text(original, encoding="utf-8")

    fake_config = FakeGitConfig(hooks_path=str(hooks_dir.resolve()))
    _patch_config(monkeypatch, fake_config)
    monkeypatch.setattr(
        hooks,
        "get_executable_path",
        lambda: str((tmp_path / "bin" / "git-agent-memory").resolve()),
    )

    assert hooks.install_global_hook() is True

    backup_file = hooks_dir / f"post-commit{hooks.BACKUP_SUFFIX}"
    assert backup_file.exists()
    assert backup_file.read_text(encoding="utf-8") == original
    assert hooks.HOOK_MARKER in hook_file.read_text(encoding="utf-8")


def test_install_global_hook_refuses_unmanaged_hook_when_backup_differs(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    """Installer should refuse overwrite when current unmanaged hook differs from existing backup."""
    hooks_dir = tmp_path / "hooks"
    hooks_dir.mkdir(parents=True, exist_ok=True)
    hook_file = hooks_dir / "post-commit"
    backup_file = hooks_dir / f"post-commit{hooks.BACKUP_SUFFIX}"
    hook_file.write_text("#!/bin/sh\necho current\n", encoding="utf-8")
    backup_file.write_text("#!/bin/sh\necho stale-backup\n", encoding="utf-8")

    fake_config = FakeGitConfig(hooks_path=str(hooks_dir.resolve()))
    _patch_config(monkeypatch, fake_config)
    monkeypatch.setattr(
        hooks,
        "get_executable_path",
        lambda: str((tmp_path / "bin" / "git-agent-memory").resolve()),
    )

    assert hooks.install_global_hook() is False
    assert "discard the current hook chain" in capsys.readouterr().out
    assert "echo current" in hook_file.read_text(encoding="utf-8")
    assert "echo stale-backup" in backup_file.read_text(encoding="utf-8")


def test_install_global_hook_blocks_recursive_backup(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    """Installer should abort when backup already contains managed marker."""
    hooks_dir = tmp_path / "hooks"
    hooks_dir.mkdir(parents=True, exist_ok=True)
    hook_file = hooks_dir / "post-commit"
    backup_file = hooks_dir / f"post-commit{hooks.BACKUP_SUFFIX}"
    unmanaged = "#!/bin/sh\necho unmanaged\n"
    hook_file.write_text(unmanaged, encoding="utf-8")
    backup_file.write_text(f"#!/bin/sh\n{hooks.HOOK_MARKER}\n", encoding="utf-8")

    fake_config = FakeGitConfig(hooks_path=str(hooks_dir.resolve()))
    _patch_config(monkeypatch, fake_config)
    monkeypatch.setattr(
        hooks,
        "get_executable_path",
        lambda: (_ for _ in ()).throw(AssertionError("should not be called")),
    )

    assert hooks.install_global_hook() is False
    assert hook_file.read_text(encoding="utf-8") == unmanaged
    assert "recursive" in capsys.readouterr().out.lower()


def test_uninstall_global_hook_restores_backup_without_unset(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Uninstall should restore backup hook and keep custom hooksPath configured."""
    hooks_dir = tmp_path / "custom-hooks"
    hooks_dir.mkdir(parents=True, exist_ok=True)
    hook_file = hooks_dir / "post-commit"
    backup_file = hooks_dir / f"post-commit{hooks.BACKUP_SUFFIX}"
    backup_content = "#!/bin/sh\necho original\n"
    hook_file.write_text(f"#!/bin/sh\n{hooks.HOOK_MARKER}\n", encoding="utf-8")
    backup_file.write_text(backup_content, encoding="utf-8")

    fake_config = FakeGitConfig(hooks_path=str(hooks_dir.resolve()))
    monkeypatch.setattr(hooks, "_default_hooks_dir", lambda: tmp_path / "other-default")
    _patch_config(monkeypatch, fake_config)

    hooks.uninstall_global_hook()

    assert hook_file.exists()
    assert hook_file.read_text(encoding="utf-8") == backup_content
    assert not backup_file.exists()
    assert fake_config.unset_calls == 0


def test_uninstall_global_hook_unsets_default_hookspath_when_removed(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Uninstall should unset core.hooksPath only for default path with no remaining hook."""
    default_hooks = tmp_path / "state" / "hooks"
    default_hooks.mkdir(parents=True, exist_ok=True)
    hook_file = default_hooks / "post-commit"
    hook_file.write_text(f"#!/bin/sh\n{hooks.HOOK_MARKER}\n", encoding="utf-8")

    fake_config = FakeGitConfig(hooks_path=str(default_hooks.resolve()))
    monkeypatch.setattr(hooks, "_default_hooks_dir", lambda: default_hooks.resolve())
    _patch_config(monkeypatch, fake_config)

    hooks.uninstall_global_hook()

    assert not hook_file.exists()
    assert fake_config.unset_calls == 1


def test_git_config_helpers(monkeypatch: pytest.MonkeyPatch) -> None:
    """Internal git config helpers should map process results correctly."""
    responses = iter(
        [
            subprocess.CompletedProcess(["git"], 0, stdout="C:/hooks\n", stderr=""),
            subprocess.CompletedProcess(["git"], 0, stdout="", stderr=""),
            subprocess.CompletedProcess(["git"], 0, stdout="", stderr=""),
            subprocess.CompletedProcess(["git"], 1, stdout="", stderr="boom"),
            subprocess.CompletedProcess(["git"], 1, stdout="", stderr="boom"),
        ]
    )

    monkeypatch.setattr(hooks.subprocess, "run", lambda *args, **kwargs: next(responses))
    assert hooks._get_core_hooks_path() == "C:/hooks"
    assert hooks._set_core_hooks_path(Path("/tmp/hooks")) is True
    assert hooks._unset_core_hooks_path() is True
    assert hooks._set_core_hooks_path(Path("/tmp/hooks")) is False
    assert hooks._unset_core_hooks_path() is False


def test_install_global_hook_binary_missing(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Installation should fail cleanly when executable lookup fails."""
    hooks_dir = tmp_path / "hooks"
    fake_config = FakeGitConfig(hooks_path=str(hooks_dir.resolve()))
    _patch_config(monkeypatch, fake_config)
    monkeypatch.setattr(
        hooks,
        "get_executable_path",
        lambda: (_ for _ in ()).throw(hooks.InstallError("missing bin")),
    )

    assert hooks.install_global_hook() is False


def test_uninstall_global_hook_noop_when_hook_unmanaged(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Uninstall should no-op when hook is not managed by our marker."""
    hooks_dir = tmp_path / "hooks"
    hooks_dir.mkdir(parents=True, exist_ok=True)
    hook_file = hooks_dir / "post-commit"
    hook_file.write_text("#!/bin/sh\necho unmanaged\n", encoding="utf-8")

    fake_config = FakeGitConfig(hooks_path=str(hooks_dir.resolve()))
    _patch_config(monkeypatch, fake_config)
    hooks.uninstall_global_hook()

    assert hook_file.exists()
    assert fake_config.unset_calls == 0
