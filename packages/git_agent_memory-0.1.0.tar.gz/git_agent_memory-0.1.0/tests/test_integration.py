"""Integration tests aligned with minimal v1.0 acceptance criteria."""

from __future__ import annotations

from pathlib import Path
import subprocess

from git_agent_memory.git_utils import resolve_git_paths
from git_agent_memory.parser import parse_latest_commit
from git_agent_memory.writer import parse_entries, write_commit


def _run_git(repo: Path, *args: str) -> subprocess.CompletedProcess[str]:
    """Run a git command in ``repo`` and fail if the command fails."""
    result = subprocess.run(
        ["git", *args],
        cwd=str(repo),
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        raise AssertionError(
            f"git {' '.join(args)} failed in {repo}:\n"
            f"stdout={result.stdout}\n"
            f"stderr={result.stderr}"
        )
    return result


def _current_branch(repo: Path) -> str:
    """Return the current branch name for a repository."""
    return _run_git(repo, "rev-parse", "--abbrev-ref", "HEAD").stdout.strip()


def test_normal_repo(git_repo: Path, monkeypatch) -> None:
    """Normal repository flow: parse and write latest commit memory."""
    monkeypatch.chdir(git_repo)
    repo_root, git_dir = resolve_git_paths(cwd=str(git_repo))
    commit_data = parse_latest_commit(timeout=5.0)
    write_commit(commit_data, repo_root=repo_root, git_dir=git_dir, timeout=0.5)

    commits_file = repo_root / "commits.md"
    assert commits_file.exists()
    content = commits_file.read_text(encoding="utf-8")
    assert f"<!-- git-agent-memory:hash={commit_data.hash} -->" in content


def test_detached_head(git_repo: Path, monkeypatch) -> None:
    """Detached HEAD state should be reported in parsed branch info."""
    head_hash = _run_git(git_repo, "rev-parse", "HEAD").stdout.strip()
    _run_git(git_repo, "checkout", head_hash)

    monkeypatch.chdir(git_repo)
    commit_data = parse_latest_commit(timeout=5.0)
    assert commit_data.branch.startswith("Detached HEAD (at ")


def test_merge_commit(git_repo: Path, monkeypatch) -> None:
    """Merge commits should parse with parent metadata and merge flag."""
    main_branch = _current_branch(git_repo)

    _run_git(git_repo, "checkout", "-b", "feature-branch")
    (git_repo / "feature.txt").write_text("feature\n", encoding="utf-8")
    _run_git(git_repo, "add", "feature.txt")
    _run_git(git_repo, "commit", "-m", "feat: feature change")

    _run_git(git_repo, "checkout", main_branch)
    (git_repo / "main.txt").write_text("main\n", encoding="utf-8")
    _run_git(git_repo, "add", "main.txt")
    _run_git(git_repo, "commit", "-m", "feat: mainline change")
    _run_git(git_repo, "merge", "--no-ff", "feature-branch", "-m", "merge: feature-branch")

    monkeypatch.chdir(git_repo)
    commit_data = parse_latest_commit(timeout=5.0)
    assert commit_data.is_merge is True
    assert commit_data.parent_hashes is not None
    assert len(commit_data.parent_hashes) >= 2


def test_amend_no_duplicate(git_repo: Path, monkeypatch) -> None:
    """Repeated capture for the same amended hash should not duplicate entries."""
    (git_repo / "amend.txt").write_text("first\n", encoding="utf-8")
    _run_git(git_repo, "add", "amend.txt")
    _run_git(git_repo, "commit", "-m", "feat: add amend file")

    _run_git(git_repo, "commit", "--amend", "-m", "feat: add amend file (amended)")

    monkeypatch.chdir(git_repo)
    repo_root, git_dir = resolve_git_paths(cwd=str(git_repo))
    commit_data = parse_latest_commit(timeout=5.0)

    write_commit(commit_data, repo_root=repo_root, git_dir=git_dir, timeout=0.5)
    write_commit(commit_data, repo_root=repo_root, git_dir=git_dir, timeout=0.5)

    commits_file = repo_root / "commits.md"
    assert commits_file.exists()
    entries = parse_entries(commits_file.read_text(encoding="utf-8"))
    hash_markers = [
        entry for entry in entries if f"<!-- git-agent-memory:hash={commit_data.hash} -->" in entry
    ]
    assert len(hash_markers) == 1


def test_worktree(git_repo: Path, tmp_path: Path, monkeypatch) -> None:
    """Worktree repository paths should resolve correctly in linked worktrees."""
    main_branch = _current_branch(git_repo)
    _run_git(git_repo, "branch", "worktree-branch", main_branch)

    worktree_dir = tmp_path / "worktree-repo"
    _run_git(git_repo, "worktree", "add", str(worktree_dir), "worktree-branch")

    monkeypatch.chdir(worktree_dir)
    repo_root, git_dir = resolve_git_paths(cwd=str(worktree_dir))
    assert repo_root == worktree_dir.resolve()
    assert git_dir.is_absolute()
    assert git_dir.exists()


def test_special_characters(git_repo: Path, monkeypatch) -> None:
    """Parser should handle filenames with spaces/brackets/unicode correctly."""
    special_name = "weird [name] ünicode file.txt"
    (git_repo / special_name).write_text("data\n", encoding="utf-8")
    _run_git(git_repo, "add", special_name)
    _run_git(git_repo, "commit", "-m", "feat: add special filename")

    monkeypatch.chdir(git_repo)
    commit_data = parse_latest_commit(timeout=5.0)
    parsed_paths = [change.path for change in commit_data.files_changed]
    assert special_name in parsed_paths
