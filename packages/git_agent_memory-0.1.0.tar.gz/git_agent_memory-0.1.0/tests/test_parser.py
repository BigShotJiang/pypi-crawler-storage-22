"""Tests for commit parsing and NUL-separated file change parsing."""

from __future__ import annotations

import subprocess

import pytest

from git_agent_memory import parser


def _metadata_bytes(
    full_hash: str,
    short_hash: str,
    author: str,
    email: str,
    iso_timestamp: str,
    subject: str,
    body: str = "",
) -> bytes:
    """Build parser metadata output in NUL-separated bytes format."""
    return (
        f"{full_hash}\0"
        f"{short_hash}\0"
        f"{author}\0"
        f"{email}\0"
        f"{iso_timestamp}\0"
        f"{subject}\0"
        f"\0{body}"
    ).encode("utf-8")


def _cp(
    *,
    stdout: str | bytes,
    stderr: str | bytes = "",
    returncode: int = 0,
) -> subprocess.CompletedProcess[str | bytes]:
    """Build a ``CompletedProcess`` suitable for mocked command responses."""
    return subprocess.CompletedProcess(
        args=["git"],
        returncode=returncode,
        stdout=stdout,
        stderr=stderr,
    )


def test_parse_latest_commit_normal(mock_git_commands) -> None:
    """Normal commits should parse metadata, branch, parents, and file changes."""
    queue, calls = mock_git_commands(parser)

    full_hash = "a" * 40
    short_hash = "a" * 7
    queue(
        _cp(
            stdout=_metadata_bytes(
                full_hash=full_hash,
                short_hash=short_hash,
                author="Alice",
                email="alice@example.com",
                iso_timestamp="2025-01-01T12:34:56+00:00",
                subject="feat: add parser tests",
                body="Body line\n",
            ),
        ),
        _cp(stdout="main\n"),
        _cp(stdout=f"{full_hash} {'b' * 40}\n"),
        _cp(stdout=b"M\0src/main.py\0"),
        _cp(stdout=b"10\t2\tsrc/main.py\0"),
    )

    commit = parser.parse_latest_commit(timeout=5.0)
    assert commit.hash == full_hash
    assert commit.hash_short == short_hash
    assert commit.branch == "main"
    assert commit.is_merge is False
    assert commit.parent_hashes is None
    assert commit.subject == "feat: add parser tests"
    assert commit.files_changed[0].path == "src/main.py"
    assert commit.files_changed[0].status == "M"
    assert commit.files_changed[0].additions == 10
    assert commit.files_changed[0].deletions == 2

    assert calls[0]["text"] is False
    assert "--root" in calls[3]["cmd"]
    assert calls[3]["text"] is False
    assert calls[4]["text"] is False


def test_parse_latest_commit_merge(mock_git_commands) -> None:
    """Merge commits should use first-parent diff strategy and parent metadata."""
    queue, calls = mock_git_commands(parser)

    full_hash = "c" * 40
    short_hash = "c" * 7
    p1 = "d" * 40
    p2 = "e" * 40
    queue(
        _cp(
            stdout=_metadata_bytes(
                full_hash=full_hash,
                short_hash=short_hash,
                author="Bob",
                email="bob@example.com",
                iso_timestamp="2025-01-02T01:02:03+00:00",
                subject="merge: feature branch",
            ),
        ),
        _cp(stdout="main\n"),
        _cp(stdout=f"{full_hash} {p1} {p2}\n"),
        _cp(stdout=b"R100\0old.py\0new.py\0"),
        _cp(stdout=b"7\t4\t\0old.py\0new.py\0"),
    )

    commit = parser.parse_latest_commit(timeout=5.0)
    assert commit.is_merge is True
    assert commit.parent_hashes == [p1, p2]
    assert commit.files_changed[0].status == "R"
    assert commit.files_changed[0].old_path == "old.py"
    assert commit.files_changed[0].path == "new.py"
    assert commit.files_changed[0].additions == 7
    assert commit.files_changed[0].deletions == 4

    assert "HEAD^1" in calls[3]["cmd"]
    assert "HEAD" in calls[3]["cmd"]
    assert "--root" not in calls[3]["cmd"]


def test_parse_latest_commit_detached_head(mock_git_commands) -> None:
    """Detached HEAD should be surfaced as a descriptive branch string."""
    queue, _calls = mock_git_commands(parser)

    full_hash = "f" * 40
    short_hash = "f" * 7
    queue(
        _cp(
            stdout=_metadata_bytes(
                full_hash=full_hash,
                short_hash=short_hash,
                author="Carol",
                email="carol@example.com",
                iso_timestamp="2025-01-03T00:00:00+00:00",
                subject="fix: detached head behavior",
            ),
        ),
        _cp(stdout="HEAD\n"),
        _cp(stdout=f"{full_hash} {'1' * 40}\n"),
        _cp(stdout=b"M\0README.md\0"),
        _cp(stdout=b"1\t0\tREADME.md\0"),
    )

    commit = parser.parse_latest_commit(timeout=5.0)
    assert commit.branch == f"Detached HEAD (at {short_hash})"


def test_parse_latest_commit_allows_empty_subject(mock_git_commands) -> None:
    """Empty-message commits should parse instead of failing metadata validation."""
    queue, _calls = mock_git_commands(parser)

    full_hash = "1" * 40
    short_hash = "1" * 7
    queue(
        _cp(
            stdout=_metadata_bytes(
                full_hash=full_hash,
                short_hash=short_hash,
                author="Dana",
                email="dana@example.com",
                iso_timestamp="2025-01-04T00:00:00+00:00",
                subject="",
                body="",
            ),
        ),
        _cp(stdout="main\n"),
        _cp(stdout=f"{full_hash} {'2' * 40}\n"),
        _cp(stdout=b"M\0README.md\0"),
        _cp(stdout=b"1\t0\tREADME.md\0"),
    )

    commit = parser.parse_latest_commit(timeout=5.0)
    assert commit.subject == ""
    assert commit.message == ""


def test_parse_file_changes_z_normal() -> None:
    """Normal add/modify/delete status entries should map to numstat values."""
    status_output = b"M\0src/a.py\0A\0src/b.py\0D\0src/c.py\0"
    numstat_output = b"4\t1\tsrc/a.py\0" b"2\t0\tsrc/b.py\0" b"0\t3\tsrc/c.py\0"

    changes = parser.parse_file_changes_z(status_output, numstat_output)
    assert len(changes) == 3
    assert [c.status for c in changes] == ["M", "A", "D"]
    assert [c.path for c in changes] == ["src/a.py", "src/b.py", "src/c.py"]
    assert (changes[0].additions, changes[0].deletions) == (4, 1)


def test_parse_file_changes_z_renames() -> None:
    """Rename token streams should consume old/new paths and map stats to new path."""
    status_output = b"R100\0old name.py\0new name.py\0"
    numstat_output = b"9\t2\t\0old name.py\0new name.py\0"

    changes = parser.parse_file_changes_z(status_output, numstat_output)
    assert len(changes) == 1
    change = changes[0]
    assert change.status == "R"
    assert change.old_path == "old name.py"
    assert change.path == "new name.py"
    assert change.additions == 9
    assert change.deletions == 2


def test_parse_file_changes_z_special_chars() -> None:
    """NUL-safe parsing should preserve tabs/newlines/spaces in filenames."""
    path = "dir/space name\tline\nfile.txt"
    status_output = f"M\0{path}\0".encode("utf-8")
    numstat_output = f"12\t3\t{path}\0".encode("utf-8")

    changes = parser.parse_file_changes_z(status_output, numstat_output)
    assert len(changes) == 1
    assert changes[0].path == path
    assert changes[0].additions == 12
    assert changes[0].deletions == 3


def test_parse_file_changes_z_binary() -> None:
    """Binary numstat markers should map to binary files with zero line deltas."""
    status_output = b"M\0assets/logo.png\0"
    numstat_output = b"-\t-\tassets/logo.png\0"

    changes = parser.parse_file_changes_z(status_output, numstat_output)
    assert len(changes) == 1
    change = changes[0]
    assert change.path == "assets/logo.png"
    assert change.is_binary is True
    assert change.additions == 0
    assert change.deletions == 0


def test_detect_commit_type() -> None:
    """Conventional commit detection should fall back to chore when unknown."""
    assert parser.detect_commit_type("feat(parser): improve parsing") == "feat"
    assert parser.detect_commit_type("fix!: breaking fix") == "fix"
    assert parser.detect_commit_type("Random message without prefix") == "chore"


def test_parse_latest_commit_invalid_timeout() -> None:
    """Invalid timeout values should raise GitError."""
    with pytest.raises(parser.GitError, match="timeout must be greater than 0"):
        parser.parse_latest_commit(timeout=0)


def test_parse_latest_commit_metadata_error(mock_git_commands) -> None:
    """Metadata command failures should raise GitError."""
    queue, _calls = mock_git_commands(parser)
    queue(_cp(stdout=b"", stderr=b"bad metadata", returncode=1))
    with pytest.raises(parser.GitError, match="Failed to get commit metadata"):
        parser.parse_latest_commit(timeout=5.0)


def test_parse_latest_commit_branch_error(mock_git_commands) -> None:
    """Branch command failures should raise GitError."""
    queue, _calls = mock_git_commands(parser)
    full_hash = "a" * 40
    short_hash = "a" * 7
    queue(
        _cp(
            stdout=_metadata_bytes(
                full_hash=full_hash,
                short_hash=short_hash,
                author="A",
                email="a@x",
                iso_timestamp="2025-01-01T00:00:00+00:00",
                subject="feat: test",
            )
        ),
        _cp(stdout="", stderr="no branch", returncode=1),
    )
    with pytest.raises(parser.GitError, match="Failed to get branch name"):
        parser.parse_latest_commit(timeout=5.0)


def test_parse_latest_commit_parent_error(mock_git_commands) -> None:
    """Parent hash command failures and empty output should raise GitError."""
    queue, _calls = mock_git_commands(parser)
    full_hash = "b" * 40
    short_hash = "b" * 7
    queue(
        _cp(
            stdout=_metadata_bytes(
                full_hash=full_hash,
                short_hash=short_hash,
                author="B",
                email="b@x",
                iso_timestamp="2025-01-01T00:00:00+00:00",
                subject="feat: test",
            )
        ),
        _cp(stdout="main\n"),
        _cp(stdout="", stderr="no parents", returncode=1),
    )
    with pytest.raises(parser.GitError, match="Failed to get parent hashes"):
        parser.parse_latest_commit(timeout=5.0)

    queue2, _calls2 = mock_git_commands(parser)
    queue2(
        _cp(
            stdout=_metadata_bytes(
                full_hash=full_hash,
                short_hash=short_hash,
                author="B",
                email="b@x",
                iso_timestamp="2025-01-01T00:00:00+00:00",
                subject="feat: test",
            )
        ),
        _cp(stdout="main\n"),
        _cp(stdout="\n"),
    )
    with pytest.raises(parser.GitError, match="Unexpected empty output"):
        parser.parse_latest_commit(timeout=5.0)


def test_parse_latest_commit_status_numstat_errors(mock_git_commands) -> None:
    """Status/numstat failures should raise GitError."""
    queue, _calls = mock_git_commands(parser)
    full_hash = "c" * 40
    short_hash = "c" * 7
    queue(
        _cp(
            stdout=_metadata_bytes(
                full_hash=full_hash,
                short_hash=short_hash,
                author="C",
                email="c@x",
                iso_timestamp="2025-01-01T00:00:00+00:00",
                subject="feat: test",
            )
        ),
        _cp(stdout="main\n"),
        _cp(stdout=f"{full_hash} {'d' * 40}\n"),
        _cp(stdout=b"", stderr=b"bad status", returncode=1),
    )
    with pytest.raises(parser.GitError, match="Failed to get file status"):
        parser.parse_latest_commit(timeout=5.0)

    queue2, _calls2 = mock_git_commands(parser)
    queue2(
        _cp(
            stdout=_metadata_bytes(
                full_hash=full_hash,
                short_hash=short_hash,
                author="C",
                email="c@x",
                iso_timestamp="2025-01-01T00:00:00+00:00",
                subject="feat: test",
            )
        ),
        _cp(stdout="main\n"),
        _cp(stdout=f"{full_hash} {'d' * 40}\n"),
        _cp(stdout=b"M\0x.py\0"),
        _cp(stdout=b"", stderr=b"bad numstat", returncode=1),
    )
    with pytest.raises(parser.GitError, match="Failed to get file stats"):
        parser.parse_latest_commit(timeout=5.0)


def test_parse_metadata_output_validation() -> None:
    """Metadata parser should reject malformed and invalid timestamp output."""
    with pytest.raises(parser.GitError, match="Malformed git log output"):
        parser._parse_metadata_output(b"too\0short\0")

    malformed = _metadata_bytes(
        full_hash="h" * 40,
        short_hash="h" * 7,
        author="Author",
        email="mail@example.com",
        iso_timestamp="not-a-timestamp",
        subject="subject",
    )
    with pytest.raises(parser.GitError, match="Invalid commit timestamp"):
        parser._parse_metadata_output(malformed)


def test_parse_numstat_counts_invalid_values() -> None:
    """Invalid numeric fields should coerce to zero safely."""
    adds, dels, is_binary = parser._parse_numstat_counts("x", "9")
    assert (adds, dels, is_binary) == (0, 9, False)

    adds2, dels2, is_binary2 = parser._parse_numstat_counts("3", "x")
    assert (adds2, dels2, is_binary2) == (3, 0, False)
