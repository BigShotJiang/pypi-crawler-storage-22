"""Tests for markdown writer utilities and locking behavior."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

import pytest

from git_agent_memory import writer
from git_agent_memory.parser import CommitData, FileChange


def test_format_commit(sample_commit_data) -> None:
    """Formatted commit markdown should include markers, metadata, and impact."""
    rendered = writer.format_commit(sample_commit_data)

    assert f"<!-- git-agent-memory:hash={sample_commit_data.hash} -->" in rendered
    assert "## [feat] feat: add widget" in rendered
    assert "**Author:** Test User <test@example.com>" in rendered
    assert "src/widget.py" in rendered
    assert "**Impact:**" in rendered


def test_commit_exists(tmp_path: Path, sample_commit_data) -> None:
    """Hash marker lookup should detect existing commit entries."""
    commits_file = tmp_path / "commits.md"
    marker = f"<!-- git-agent-memory:hash={sample_commit_data.hash} -->\n"
    commits_file.write_text(marker + "content\n", encoding="utf-8")

    assert writer.commit_exists(commits_file, sample_commit_data.hash) is True
    assert writer.commit_exists(commits_file, "b" * 40) is False


def test_parse_entries() -> None:
    """Entry parsing should split on hash markers and preserve block content."""
    content = (
        "# Commit History\n\n"
        "Last updated: 2025-01-01 00:00:00\n\n---\n\n"
        "<!-- git-agent-memory:hash=aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa -->\n"
        "entry-a\n"
        "<!-- git-agent-memory:hash=bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb -->\n"
        "entry-b\n"
    )

    entries = writer.parse_entries(content)
    assert len(entries) == 2
    assert "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" in entries[0]
    assert "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb" in entries[1]


def test_parse_entries_no_markers() -> None:
    """Parsing should return an empty list when no hash markers exist."""
    assert writer.parse_entries("# Commit History\nno markers here\n") == []


def test_build_document_empty_and_non_empty() -> None:
    """Document builder should include header and optional entry body."""
    empty_doc = writer.build_document([])
    assert empty_doc.startswith("# Commit History")
    assert "Last updated:" in empty_doc

    doc = writer.build_document(["entry-one\n", "entry-two\n"])
    assert "entry-one" in doc
    assert "entry-two" in doc


def test_atomic_write(tmp_path: Path) -> None:
    """Atomic write should create/update target file with exact content."""
    target = tmp_path / "nested" / "commits.md"
    writer.atomic_write(target, "first")
    assert target.read_text(encoding="utf-8") == "first"

    writer.atomic_write(target, "second")
    assert target.read_text(encoding="utf-8") == "second"


def test_file_lock_acquire(tmp_path: Path) -> None:
    """Lock acquisition should succeed and leave a persistent lock file."""
    target = tmp_path / "commits.md"

    with writer.FileLock(target, timeout_ms=200, poll_interval_ms=5):
        pass

    lock_file = target.with_suffix(".lock")
    assert lock_file.exists()
    assert lock_file.read_text(encoding="utf-8") != ""


def test_file_lock_timeout(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Repeated lock contention should raise ``LockTimeoutError``."""
    target = tmp_path / "commits.md"

    def _always_busy(_self) -> None:
        raise BlockingIOError()

    monkeypatch.setattr(writer.FileLock, "_try_acquire_non_blocking", _always_busy)

    with pytest.raises(writer.LockTimeoutError):
        with writer.FileLock(target, timeout_ms=20, poll_interval_ms=1):
            pass


def test_format_commit_merge_and_truncation() -> None:
    """Formatting should include merge info and truncate long file lists."""
    files = [
        FileChange(path=f"src/file_{i}.py", additions=1, deletions=0, status="M", is_binary=False)
        for i in range(22)
    ]
    files[0] = FileChange(
        path="new_name.py",
        additions=5,
        deletions=1,
        status="R",
        is_binary=False,
        old_path="old_name.py",
    )
    files[1] = FileChange(
        path="copied.py",
        additions=3,
        deletions=0,
        status="C",
        is_binary=False,
        old_path="source.py",
    )
    files[2] = FileChange(
        path="image.png",
        additions=0,
        deletions=0,
        status="A",
        is_binary=True,
    )

    commit = CommitData(
        hash="f" * 40,
        hash_short="f" * 7,
        author="Merge Bot",
        email="merge@example.com",
        timestamp=datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc),
        message="merge: test",
        subject="merge: test",
        body="",
        branch="main",
        files_changed=files,
        is_merge=True,
        parent_hashes=["a" * 40, "b" * 40],
    )

    rendered = writer.format_commit(commit)
    assert "Merge commit:" in rendered
    assert "Note:** File changes shown relative to first parent" in rendered
    assert "Renamed from `old_name.py`" in rendered
    assert "Copied from `source.py`" in rendered
    assert "Binary file" in rendered
    assert "...and 2 more files" in rendered


def test_ensure_local_ignore(tmp_path: Path) -> None:
    """Local ignore helper should add commits and lock entries without duplicates."""
    repo_root = tmp_path / "repo"
    git_dir = tmp_path / "repo.git"
    repo_root.mkdir(parents=True, exist_ok=True)
    (git_dir / "info").mkdir(parents=True, exist_ok=True)

    # Simulate the commits file already being ignored by a prior tool run.
    exclude_file = git_dir / "info" / "exclude"
    exclude_file.write_text("commits.md\n", encoding="utf-8")

    writer.ensure_local_ignore(repo_root, git_dir, "commits.md")
    writer.ensure_local_ignore(repo_root, git_dir, "commits.md")

    content = exclude_file.read_text(encoding="utf-8")
    assert content.count("commits.md\n") == 1
    assert content.count("commits.lock\n") == 1


def test_write_commit_timeout_exhausted(tmp_path: Path, sample_commit_data) -> None:
    """write_commit should return early when timeout budget is exhausted."""
    repo_root = tmp_path / "repo"
    git_dir = tmp_path / "repo.git"
    repo_root.mkdir(parents=True, exist_ok=True)
    git_dir.mkdir(parents=True, exist_ok=True)

    writer.write_commit(sample_commit_data, repo_root=repo_root, git_dir=git_dir, timeout=0.0)
    assert not (repo_root / "commits.md").exists()


def test_write_commit_ignores_unsafe_file_name_from_local_config(
    tmp_path: Path, sample_commit_data
) -> None:
    """Unsafe file_name config should not allow writing outside repository root."""
    base = tmp_path
    repo_root = base / "repo"
    git_dir = repo_root / ".git"
    repo_root.mkdir(parents=True, exist_ok=True)
    (git_dir / "info").mkdir(parents=True, exist_ok=True)

    (repo_root / ".git-agent-memory.yaml").write_text(
        'file_name: "../outside.md"\n',
        encoding="utf-8",
    )
    outside_file = base / "outside.md"

    writer.write_commit(sample_commit_data, repo_root=repo_root, git_dir=git_dir, timeout=0.5)

    assert (repo_root / "commits.md").exists()
    assert not outside_file.exists()
