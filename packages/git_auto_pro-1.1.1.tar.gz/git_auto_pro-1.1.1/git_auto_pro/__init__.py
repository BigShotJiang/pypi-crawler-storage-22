"""Git-Auto Pro - Complete Git + GitHub automation CLI tool."""

__version__ = "1.1.0"
__author__ = "Himanshu Singh"
__email__ = "choudharyhimanshusingh966@gmail.com"
