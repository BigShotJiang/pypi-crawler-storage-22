======================
Git Cola Documentation
======================
.. toctree::
    :maxdepth: 3

    git-cola
    git-dag
    thanks

Release Notes
=============
.. toctree::
    :maxdepth: 2

    relnotes

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
