# ────────────────────────────────────────────────────────────────────────────────────────
#   scan/run.py
#   ───────────
#
#   CLI runner for the scan subcommand.
#
#   (c) 2026 Cyber Assessment Labs — MIT License; see LICENSE in the project root.
#
#   Authors
#   ───────
#   bena (via Claude)
#
#   Version History
#   ───────────────
#   Jan 2026 - Created
# ────────────────────────────────────────────────────────────────────────────────────────

# ────────────────────────────────────────────────────────────────────────────────────────
#   Imports
# ────────────────────────────────────────────────────────────────────────────────────────

import sys
from typing import TYPE_CHECKING
from ..common import DEFAULT_CONFIG_PATH
from ..common import bold
from ..common import cyan
from ..common import find_default_config
from ..common import green
from ..common import red
from ..common import yellow
from ..sanitise.config import load_config
from .scanner import find_excluded_files
from .scanner import scan_repository

if TYPE_CHECKING:
    import argparse

# ────────────────────────────────────────────────────────────────────────────────────────
#   Runner
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def run(args: argparse.Namespace) -> int:
    """Run the scan subcommand."""
    # Try to find default config if not provided
    if not args.config:
        default_config = find_default_config()
        if default_config:
            print(cyan(f"Using default config: {default_config}"))
            args.config = default_config

    # Validate required arguments - collect ALL missing ones
    missing: list[str] = []
    if not args.repo:
        missing.append("-r/--repo")
    if not args.config:
        missing.append("-c/--config")

    if missing:
        print(red("Error:") + " Missing required arguments:", file=sys.stderr)
        for arg in missing:
            print(f"  {arg}", file=sys.stderr)
        print(file=sys.stderr)
        print(
            yellow("Tip:") + " You can provide -c/--config (or place a config at"
            f" {DEFAULT_CONFIG_PATH})",
            file=sys.stderr,
        )
        print("     to specify repository settings in a JSON file.", file=sys.stderr)
        return 1

    # Validate paths exist
    if not args.repo.exists():
        print(red("Error:") + f" Repository not found: {args.repo}", file=sys.stderr)
        return 1
    if not args.config.exists():
        print(red("Error:") + f" Config file not found: {args.config}", file=sys.stderr)
        return 1

    # Load config
    config = load_config(args.config)
    words = config.get("words", [])
    exclude_patterns = config.get("exclude_files", [])

    if not words:
        print(red("Error:") + " No words specified in config file", file=sys.stderr)
        return 1

    print(f"Scanning for {len(words)} dirty words...")
    blob_matches, commit_matches = scan_repository(args.repo, words, args.verbose)

    # Find files that would be excluded
    excluded_files: list[str] = []
    if exclude_patterns:
        print(f"\nChecking {len(exclude_patterns)} exclude patterns...")
        excluded_files = find_excluded_files(args.repo, exclude_patterns, args.verbose)

    # Report results
    total_blob = sum(blob_matches.values())
    total_commit = sum(commit_matches.values())

    print("\n" + "=" * 60)
    print(bold("SCAN RESULTS"))
    print("=" * 60)

    if blob_matches:
        print(yellow("\nMatches in file contents:"))
        for word, count in sorted(blob_matches.items(), key=lambda x: -x[1]):
            print(f"  {word}: {count}")

    if commit_matches:
        print(yellow("\nMatches in commit messages:"))
        for word, count in sorted(commit_matches.items(), key=lambda x: -x[1]):
            print(f"  {word}: {count}")

    print(f"\nTotal: {total_blob} in files, {total_commit} in commits")

    if total_blob == 0 and total_commit == 0:
        print(green("\nNo dirty words found!"))

    # Report excluded files
    if exclude_patterns:
        print("\n" + "-" * 60)
        print(bold("FILES THAT WOULD BE EXCLUDED"))
        print("-" * 60)
        if excluded_files:
            print(f"\n{len(excluded_files)} file(s) match exclude patterns:")
            for filepath in excluded_files:
                print(f"  {filepath}")
        else:
            print("\nNo files match the exclude patterns.")

    return 0
