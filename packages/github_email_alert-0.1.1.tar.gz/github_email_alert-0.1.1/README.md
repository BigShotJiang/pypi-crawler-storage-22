# GitHub Email Alert

Reusable Python package to send email alerts from GitHub Actions.

## Features

- Send alerts for:
  - New Pull Request
  - PR Merge
  - Merge Conflicts
- SMTP configurable
- CLI support
- Works with GitHub Actions
- CC support
- Environment variable driven

## Installation

```bash
pip install github-email-alert
```

Usage
```
github-email-alert feature/login new_pr
```

Required Environment Variables
```
EMAIL_USER
EMAIL_PASS
EMAIL_TO
```

Optional
```
EMAIL_CC
SMTP_HOST
SMTP_PORT
```