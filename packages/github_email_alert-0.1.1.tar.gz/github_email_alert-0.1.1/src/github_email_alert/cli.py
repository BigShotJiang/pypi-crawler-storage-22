import os
import argparse
from .emailer import send_email
from .templates import build_email


def parse_list(value):
    if not value:
        return []
    return [x.strip() for x in value.split(",") if x.strip()]


def main():
    parser = argparse.ArgumentParser(description="GitHub Email Alert")
    parser.add_argument("branch_ref")
    parser.add_argument("event_type")

    args = parser.parse_args()

    context = {
        "actor": os.getenv("GITHUB_ACTOR", "Unknown"),
        "pr_title": os.getenv("PR_TITLE", "N/A"),
        "branch_ref": args.branch_ref,
        "base_ref": os.getenv("BASE_REF", "main"),
        "repo_name": os.getenv("REPO_NAME", "Unknown"),
    }

    email_user = os.getenv("EMAIL_USER")
    email_pass = os.getenv("EMAIL_PASS")
    email_to = parse_list(os.getenv("EMAIL_TO"))
    email_cc = parse_list(os.getenv("EMAIL_CC"))

    if not all([email_user, email_pass, email_to]):
        raise ValueError("EMAIL_USER, EMAIL_PASS, EMAIL_TO required")

    subject, body = build_email(args.event_type, context)

    send_email(
        smtp_host=os.getenv("SMTP_HOST", "smtp.gmail.com"),
        smtp_port=int(os.getenv("SMTP_PORT", 587)),
        email_user=email_user,
        email_pass=email_pass,
        to_list=email_to,
        cc_list=email_cc,
        subject=subject,
        body=body,
    )


if __name__ == "__main__":
    main()
