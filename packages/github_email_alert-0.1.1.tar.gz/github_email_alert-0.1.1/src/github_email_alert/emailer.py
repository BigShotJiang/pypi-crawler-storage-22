import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText


def send_email(
    smtp_host,
    smtp_port,
    email_user,
    email_pass,
    to_list,
    cc_list,
    subject,
    body,
):
    msg = MIMEMultipart()
    msg["From"] = email_user
    msg["To"] = ", ".join(to_list)

    if cc_list:
        msg["Cc"] = ", ".join(cc_list)

    msg["Subject"] = subject
    msg.attach(MIMEText(body, "html"))

    recipients = to_list + cc_list

    with smtplib.SMTP(smtp_host, smtp_port) as server:
        server.starttls()
        server.login(email_user, email_pass)
        server.sendmail(email_user, recipients, msg.as_string())
