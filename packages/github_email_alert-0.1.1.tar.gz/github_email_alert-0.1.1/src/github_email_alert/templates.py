def build_email(event_type, context):
    templates = {
        "new_pr": {
            "subject": f"🆕 [NEW PR] {context['pr_title']}",
            "header": "New Pull Request Created",
            "color": "#0076D7",
        },
        "merge_pr": {
            "subject": f"✅ [MERGED PR] {context['pr_title']}",
            "header": "Pull Request Merged",
            "color": "#28A745",
        },
        "conflict": {
            "subject": f"⚠️ [CONFLICT] {context['branch_ref']}",
            "header": "Merge Conflict Detected",
            "color": "#DC3545",
        },
    }

    template = templates.get(event_type)

    if not template:
        return f"[TEST] {event_type}", "<h2>Test Email</h2>"

    body = f"""
    <html>
    <body>
        <h2 style="color:{template['color']};">{template['header']}</h2>
        <p><strong>Actor:</strong> {context['actor']}</p>
        <p><strong>Title:</strong> {context['pr_title']}</p>
        <p><strong>Source Branch:</strong> {context['branch_ref']}</p>
        <p><strong>Target Branch:</strong> {context['base_ref']}</p>
        <p><strong>Repository:</strong> {context['repo_name']}</p>
        <hr>
        <p><em>Automated GitHub Notification</em></p>
    </body>
    </html>
    """

    return template["subject"], body
