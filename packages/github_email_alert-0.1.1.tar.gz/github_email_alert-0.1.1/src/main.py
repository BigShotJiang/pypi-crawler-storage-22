def main():
    print("Hello from github-email-alert!")


if __name__ == "__main__":
    main()
