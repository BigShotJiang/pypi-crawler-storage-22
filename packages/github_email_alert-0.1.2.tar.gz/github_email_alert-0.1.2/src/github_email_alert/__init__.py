"""GitHub Email Alert - Send email notifications for GitHub events.

A reusable Python package for sending email alerts from GitHub Actions workflows.
Supports notifications for branch creation/deletion, pull requests, merges, and conflicts.

Example:
    Basic usage in Python code:
        >>> from github_email_alert import send_email, build_email
        >>> context = {
        ...     "actor": "john_doe",
        ...     "pr_title": "Add feature",
        ...     "branch_ref": "feature/login",
        ...     "base_ref": "main",
        ...     "repo_name": "my-repo"
        ... }
        >>> subject, body = build_email("new_pr", context)
        >>> send_email(
        ...     smtp_host="smtp.gmail.com",
        ...     smtp_port=587,
        ...     email_user="sender@example.com",
        ...     email_pass="password",
        ...     to_list=["recipient@example.com"],
        ...     cc_list=[],
        ...     subject=subject,
        ...     body=body
        ... )
"""

__version__ = "0.1.2"
__author__ = "Pandiyaraj Karuppasamy"

from .emailer import send_email
from .templates import build_email

__all__ = ["send_email", "build_email"]
