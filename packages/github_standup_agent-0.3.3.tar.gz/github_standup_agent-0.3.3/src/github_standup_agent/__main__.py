"""Allow running as `python -m github_standup_agent`."""

from github_standup_agent.cli import app

if __name__ == "__main__":
    app()
