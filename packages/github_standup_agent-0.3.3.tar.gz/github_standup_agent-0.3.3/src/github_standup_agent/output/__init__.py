"""Output handlers for standup summaries."""

# Re-export from tools for convenience
from github_standup_agent.tools.clipboard import copy_to_clipboard

__all__ = ["copy_to_clipboard"]
