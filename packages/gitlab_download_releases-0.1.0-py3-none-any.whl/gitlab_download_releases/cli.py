# ----------------------------------------------------------------------------------------
#   cli
#   ---
#
#   CLI definition and command dispatch
#
#   License
#   -------
#   MIT License - Copyright 2026 Cyber Assessment Labs
#
#   Authors
#   -------
#   bena (via claude)
#
#   Version History
#   ---------------
#   Feb 2026 - Created
# ----------------------------------------------------------------------------------------

# ----------------------------------------------------------------------------------------
#   Imports
# ----------------------------------------------------------------------------------------

import logging
import os
import sys
import traceback
from pathlib import Path
from .argbuilder import ArgsParser
from .argbuilder import Namespace
from .colour import set_colours_enabled
from .config import DEFAULT_CONFIG_PATH
from .config import TOKEN_ENV
from .config import load_config
from .download import DownloadConfig
from .download import download_releases
from .download import format_result_summary
from .download import list_projects
from .download import list_releases
from .version import VERSION_STR
from .version_filter import FILTER_MODES

# ----------------------------------------------------------------------------------------
#   Functions
# ----------------------------------------------------------------------------------------


# ----------------------------------------------------------------------------------------
def get_args(argv: list[str]) -> Namespace:
    """
    Parse the CLI args
    """

    p = ArgsParser(
        prog="gitlab-download-releases",
        description=(
            "Download release assets from GitLab projects and groups. "
            "Automatically detects whether the given path is a group or project. "
            "For groups, all projects (including subgroups) are processed.\n"
            "\n"
            "Settings can be provided via CLI args, environment variables, or a "
            f"config file (default: {DEFAULT_CONFIG_PATH})."
        ),
        version=f"gitlab-download-releases: {VERSION_STR}",
    )

    # =========== Connection ===========

    connection = p.add_group("Connection")

    connection.add_argument(
        "--gitlab-url",
        "-u",
        metavar="URL",
        help="GitLab instance URL (e.g., https://gitlab.com)",
    )

    connection.add_argument(
        "--token",
        "-t",
        metavar="TOKEN",
        help=(
            "Access token for private GitLab groups/projects"
            f" (or set {TOKEN_ENV} env var, or config file)"
        ),
    )

    connection.add_argument(
        "--config",
        "-c",
        metavar="FILE",
        type=Path,
        help=f"Config file path (default: {DEFAULT_CONFIG_PATH})",
    )

    # =========== Target ===========

    target = p.add_group("Target")

    target.add_argument(
        "--path",
        "-p",
        metavar="PATH",
        help=(
            "Group or project path (e.g., group/subgroup or group/subgroup/project)."
            " If base_group is set in config, path is relative to it"
        ),
    )

    target.add_argument(
        "--output",
        "-o",
        metavar="DIR",
        help="Output directory for downloaded release assets",
    )

    # =========== Filtering ===========

    filtering = p.add_group("Filtering")

    filtering.add_argument(
        "--version-filter",
        "-m",
        metavar="MODE",
        default=None,
        choices=FILTER_MODES,
        help=(
            "Version filter mode (default: release).\n"
            "  release - Only full releases (x.y.z)\n"
            "  beta    - Full releases and beta versions\n"
            "  all     - All releases including pre-release"
        ),
    )

    filtering.add_argument(
        "--project-filter",
        "-f",
        metavar="FILTER",
        help=(
            "Filter projects by name (substring match, case-insensitive). Only used"
            " when path is a group"
        ),
    )

    # =========== Actions ===========

    actions = p.add_group("Actions")

    actions.add_argument(
        "--list-projects",
        "-L",
        action="store_true",
        help="List projects and exit (no download)",
    )

    actions.add_argument(
        "--list-releases",
        "-R",
        action="store_true",
        help="List releases and exit (no download)",
    )

    actions.add_argument(
        "--json",
        "-j",
        action="store_true",
        help="Output in JSON format (with --list-projects or --list-releases)",
    )

    actions.add_argument(
        "--manifest",
        "-M",
        metavar="FILE",
        help=(
            "Path to a JSON manifest file for incremental downloads. When set,"
            " tracks downloaded assets so subsequent runs only fetch new items"
        ),
    )

    actions.add_argument(
        "--overwrite",
        "-O",
        action="store_true",
        help="Overwrite existing files instead of skipping",
    )

    actions.add_argument(
        "--flat",
        "-F",
        action="store_true",
        help="Download all files directly into the output directory (no subdirectories)",
    )

    actions.add_argument(
        "--jobs",
        metavar="N",
        type=int,
        default=None,
        help="Number of parallel download threads (default: 32)",
    )

    # =========== Output ===========

    output_opts = p.add_group("Output")

    output_opts.add_argument(
        "--verbose",
        "-v",
        action="count",
        default=0,
        help="Display verbose output. Use twice for debug logging",
    )

    output_opts.add_argument(
        "--no-colour",
        "--no-color",
        action="store_true",
        dest="no_colour",
        help="Disable coloured output",
    )

    return p.parse(argv)


# ----------------------------------------------------------------------------------------
def main(argv: list[str] | None = None) -> int:
    """
    Main entry point for the CLI.

    Parameters:
        argv: Command line arguments (without program name). If None, uses sys.argv[1:].

    Returns:
        Exit code (0 for success, non-zero for error)
    """
    if argv is None:
        argv = sys.argv[1:]

    try:
        return _main_inner(argv)
    except KeyboardInterrupt:
        print()
        print("---- Manually Terminated ----")
        print()
        return 1
    except SystemExit:
        raise
    except BaseException as e:
        t = "-----------------------------------------------------------------------------\n"
        t += "UNHANDLED EXCEPTION OCCURRED!!\n"
        t += "\n"
        t += traceback.format_exc()
        t += "\n"
        t += f"EXCEPTION: {type(e)} {e}\n"
        t += "-----------------------------------------------------------------------------\n"
        t += "\n"
        print(t, file=sys.stderr)
        return 1


# ----------------------------------------------------------------------------------------
def _main_inner(argv: list[str]) -> int:
    """Inner main function that does the actual work."""
    args = get_args(argv)

    # Configure colour output - CLI > config (loaded below)
    # Note: colour must be configured early so warnings from config loading are coloured
    if args.no_colour:
        set_colours_enabled(False)

    # Configure logging
    if args.verbose >= 2:
        logging.basicConfig(level=logging.DEBUG, format="%(levelname)s: %(message)s")
    elif args.verbose >= 1:
        logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
    else:
        logging.basicConfig(level=logging.WARNING, format="%(levelname)s: %(message)s")

    # Load config file
    config_file = load_config(args.config)

    # Apply colour from config if not set via CLI
    if not args.no_colour and config_file.get("no_colour"):
        set_colours_enabled(False)

    # Resolve settings: CLI arg > env var > config file > default
    gitlab_url: str | None = args.gitlab_url or config_file.get("gitlab_url")
    token: str | None = (
        args.token or os.environ.get(TOKEN_ENV) or config_file.get("token")
    )
    output: str | None = args.output or config_file.get("output")
    version_filter: str = (
        args.version_filter or config_file.get("version_filter") or "release"
    )
    project_filter: str | None = args.project_filter or config_file.get(
        "project_filter"
    )
    parallel: int = args.jobs or config_file.get("parallel") or 32
    manifest: str | None = args.manifest or config_file.get("manifest")
    flat: bool = args.flat or config_file.get("flat", False)

    # Resolve path: prepend base_group from config if set
    base_group: str | None = config_file.get("base_group")
    if args.path and base_group:
        path: str = f"{base_group.rstrip('/')}/{args.path}"
    elif args.path:
        path = args.path
    elif base_group:
        path = base_group.rstrip("/")
    else:
        print(
            "Error: --path is required (or set base_group in config file)",
            file=sys.stderr,
        )
        return 1

    # Validate required settings
    if not gitlab_url:
        print(
            "Error: --gitlab-url is required (or set gitlab_url in config file)",
            file=sys.stderr,
        )
        return 1

    # Handle list modes (no output dir needed)
    if args.list_projects or args.list_releases:
        config = DownloadConfig(
            gitlab_url=gitlab_url,
            path=path,
            output_dir=Path("."),
            token=token,
            version_filter=version_filter,
            project_filter=project_filter,
            parallel=parallel,
        )
        if args.list_projects:
            return list_projects(config, json_output=args.json)
        return list_releases(config, json_output=args.json)

    if not output:
        print(
            "Error: --output is required (or set output in config file)",
            file=sys.stderr,
        )
        return 1

    # Build configuration
    config = DownloadConfig(
        gitlab_url=gitlab_url,
        path=path,
        output_dir=Path(output).resolve(),
        token=token,
        version_filter=version_filter,
        project_filter=project_filter,
        overwrite=args.overwrite,
        flat=flat,
        parallel=parallel,
        manifest_path=Path(manifest).resolve() if manifest else None,
    )

    # Perform download
    result = download_releases(config)

    if not result.success:
        print(f"\nError: {result.error_message}")
        return 1

    # Print summary
    print(format_result_summary(result))

    if result.failed_files > 0:
        return 1

    return 0
