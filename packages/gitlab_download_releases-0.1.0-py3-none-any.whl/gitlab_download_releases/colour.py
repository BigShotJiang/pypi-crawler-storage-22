# ----------------------------------------------------------------------------------------
#   colour
#   ------
#
#   ANSI colour output for terminal. Only applies colours when stdout is a TTY
#   and colours are not disabled.
#
#   Uses colours that work well on both light and dark backgrounds.
#
#   License
#   -------
#   MIT License - Copyright 2026 Cyber Assessment Labs
#
#   Authors
#   -------
#   bena (via claude)
#
#   Version History
#   ---------------
#   Feb 2026 - Created
# ----------------------------------------------------------------------------------------

# ----------------------------------------------------------------------------------------
#   Imports
# ----------------------------------------------------------------------------------------

import sys

# ----------------------------------------------------------------------------------------
#   ANSI Codes
# ----------------------------------------------------------------------------------------

# These colours work well on both light and dark backgrounds
RESET = "\033[0m"
BOLD = "\033[1m"
GREEN = "\033[32m"
YELLOW = "\033[33m"
RED = "\033[31m"
CYAN = "\033[36m"

# ----------------------------------------------------------------------------------------
#   State
# ----------------------------------------------------------------------------------------

_colours_enabled: bool | None = None


# ----------------------------------------------------------------------------------------
#   Functions
# ----------------------------------------------------------------------------------------


# ----------------------------------------------------------------------------------------
def set_colours_enabled(enabled: bool) -> None:
    """Explicitly enable or disable colours."""
    global _colours_enabled
    _colours_enabled = enabled


# ----------------------------------------------------------------------------------------
def _should_use_colours() -> bool:
    """Determine if colours should be used."""
    global _colours_enabled

    # If explicitly set, use that
    if _colours_enabled is not None:
        return _colours_enabled

    # Auto-detect: use colours if stdout is a TTY
    return sys.stdout.isatty()


# ----------------------------------------------------------------------------------------
def green(text: str) -> str:
    """Return text in green (for success/downloaded)."""
    if _should_use_colours():
        return f"{GREEN}{text}{RESET}"
    return text


# ----------------------------------------------------------------------------------------
def yellow(text: str) -> str:
    """Return text in yellow (for skipped/warning)."""
    if _should_use_colours():
        return f"{YELLOW}{text}{RESET}"
    return text


# ----------------------------------------------------------------------------------------
def red(text: str) -> str:
    """Return text in red (for error)."""
    if _should_use_colours():
        return f"{RED}{text}{RESET}"
    return text


# ----------------------------------------------------------------------------------------
def cyan(text: str) -> str:
    """Return text in cyan (for info)."""
    if _should_use_colours():
        return f"{CYAN}{text}{RESET}"
    return text


# ----------------------------------------------------------------------------------------
def bold(text: str) -> str:
    """Return text in bold."""
    if _should_use_colours():
        return f"{BOLD}{text}{RESET}"
    return text
