# ----------------------------------------------------------------------------------------
#   download
#   --------
#
#   Core download orchestration - resolves GitLab paths (group or project), fetches
#   release assets, and saves them to disk. Skips already-downloaded files by default.
#
#   Downloads are parallelised using a thread pool for fast I/O throughput.
#
#   License
#   -------
#   MIT License - Copyright 2026 Cyber Assessment Labs
#
#   Authors
#   -------
#   bena (via claude)
#
#   Version History
#   ---------------
#   Feb 2026 - Created
# ----------------------------------------------------------------------------------------

# ----------------------------------------------------------------------------------------
#   Imports
# ----------------------------------------------------------------------------------------

import json
import logging
import sys
import urllib.error
from collections.abc import Iterator
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import as_completed
from dataclasses import dataclass
from dataclasses import field
from datetime import UTC
from datetime import datetime
from pathlib import Path
from typing import Any
from .colour import bold
from .colour import cyan
from .colour import green
from .colour import red
from .colour import yellow
from .gitlab_api import GitLabClient
from .gitlab_api import ProjectInfo
from .gitlab_api import ReleaseInfo
from .version_filter import matches_version_filter

# ----------------------------------------------------------------------------------------
#   Types
# ----------------------------------------------------------------------------------------


@dataclass
class DownloadResult:
    """Result of a download operation."""

    success: bool
    total_projects: int = 0
    total_releases: int = 0
    total_files: int = 0
    downloaded_files: int = 0
    skipped_files: int = 0
    failed_files: int = 0
    error_message: str | None = None
    downloaded_paths: list[Path] = field(default_factory=lambda: list[Path]())


@dataclass
class DownloadConfig:
    """Configuration for the download operation."""

    gitlab_url: str
    path: str
    output_dir: Path
    token: str | None = None
    version_filter: str = "release"
    project_filter: str | None = None
    overwrite: bool = False
    flat: bool = False
    parallel: int = 32
    manifest_path: Path | None = None


@dataclass
class _DownloadTask:
    """A single file download task."""

    url: str
    file_path: Path
    release_tag: str
    asset_name: str
    project_path: str


# ----------------------------------------------------------------------------------------
#   Functions
# ----------------------------------------------------------------------------------------


# ----------------------------------------------------------------------------------------
def download_releases(config: DownloadConfig) -> DownloadResult:
    """
    Download release assets from a GitLab project or group.

    If the path is a group, all projects within the group (including subgroups)
    are processed. If the path is a project, only that project is processed.

    Downloads are executed in parallel using a thread pool.

    Parameters:
        config: Download configuration

    Returns:
        DownloadResult with statistics about the download
    """
    logger = logging.getLogger(__name__)

    # Validate output directory
    output_dir = config.output_dir
    if not output_dir.exists():
        print(f"Creating output directory: {output_dir}")
        output_dir.mkdir(parents=True, exist_ok=True)

    # Create GitLab client
    client = GitLabClient(config.gitlab_url, token=config.token)

    # Resolve path to group or project
    print(f"Connecting to {config.gitlab_url}...")

    try:
        path_type, path_id = client.resolve_path(config.path)
    except ValueError as e:
        return DownloadResult(success=False, error_message=str(e))
    except urllib.error.URLError as e:
        return DownloadResult(
            success=False,
            error_message=f"Failed to connect to GitLab: {e}",
        )

    # Gather list of projects to process
    projects: list[ProjectInfo] = []

    if path_type == "group":
        print(f"Found group: {config.path}")

        try:
            projects = client.get_group_projects(
                path_id, project_filter=config.project_filter
            )
        except urllib.error.HTTPError as e:
            return DownloadResult(
                success=False,
                error_message=f"Failed to list group projects: {e}",
            )

        if config.project_filter:
            print(
                f"Found {len(projects)} project(s) matching filter "
                f"'{config.project_filter}'"
            )
        else:
            print(f"Found {len(projects)} project(s) in group")

    else:
        # Single project
        print(f"Found project: {config.path}")
        project_info = client.get_project_info(path_id)
        if project_info is None:
            return DownloadResult(
                success=False,
                error_message=f"Project not found: {config.path}",
            )
        projects = [project_info]

    if not projects:
        print("No projects found matching the specified filters.")
        return DownloadResult(success=True, total_projects=0)

    result = DownloadResult(
        success=True,
        total_projects=len(projects),
    )

    # Load manifest for incremental downloads
    manifest: dict[str, dict[str, str]] = {}
    if config.manifest_path:
        manifest = _load_manifest(config.manifest_path)

    # Phase 1: Fetch release lists in parallel, then gather download tasks
    all_tasks: list[_DownloadTask] = []
    is_group = path_type == "group"
    group_path = config.path if is_group else None

    # Fetch release listings in parallel, processing each project as results arrive
    for project, releases in _fetch_releases_streaming(
        client, projects, config.parallel
    ):
        tasks, skipped, release_count = _gather_project_tasks(
            project=project,
            releases=releases,
            config=config,
            output_dir=output_dir,
            is_group=is_group,
            group_path=group_path,
            manifest=manifest,
        )
        all_tasks.extend(tasks)
        result.skipped_files += skipped
        result.total_releases += release_count

    result.total_files = len(all_tasks) + result.skipped_files

    if not all_tasks:
        if config.manifest_path and manifest:
            _save_manifest(config.manifest_path, manifest)
        return result

    # Phase 2: Download in parallel
    print(f"\nDownloading {len(all_tasks)} file(s) with {config.parallel} threads...")

    with ThreadPoolExecutor(max_workers=config.parallel) as executor:
        futures_list = [
            executor.submit(_download_single_file, client, task) for task in all_tasks
        ]
        future_to_idx = {f: i for i, f in enumerate(futures_list)}
        completed_dl: dict[int, BaseException | None] = {}
        next_to_print = 0
        printed = 0

        for future in as_completed(future_to_idx):
            idx = future_to_idx[future]
            error: BaseException | None = None
            try:
                future.result()
            except (urllib.error.HTTPError, urllib.error.URLError) as e:
                error = e
            completed_dl[idx] = error

            # Flush consecutive results in submission order
            while next_to_print in completed_dl:
                err = completed_dl.pop(next_to_print)
                task = all_tasks[next_to_print]
                printed += 1
                progress = f"[{printed}/{len(all_tasks)}]"

                if err is None:
                    result.downloaded_files += 1
                    result.downloaded_paths.append(task.file_path)
                    print(
                        f"  {green('Downloaded')} - "
                        f"{task.release_tag}: {task.asset_name}  {progress}"
                    )
                else:
                    logger.debug(f"Failed to download {task.asset_name}: {err}")
                    result.failed_files += 1
                    reason = ""
                    if isinstance(err, urllib.error.HTTPError):
                        reason = f" ({err.code})"
                    print(
                        f"  {red('Error')}{reason:6s} - "
                        f"{task.release_tag}: {task.asset_name}  {progress}"
                    )
                next_to_print += 1

    # Update manifest with all attempted downloads (successful and failed)
    if config.manifest_path:
        now = datetime.now(UTC).isoformat()
        for task in all_tasks:
            key = str(task.file_path.relative_to(output_dir))
            status = (
                "downloaded" if task.file_path in result.downloaded_paths else "failed"
            )
            manifest[key] = {"path": key, "status": status, "downloaded": now}
        _save_manifest(config.manifest_path, manifest)

    return result


# ----------------------------------------------------------------------------------------
def _fetch_releases_streaming(
    client: GitLabClient,
    projects: list[ProjectInfo],
    max_workers: int,
) -> Iterator[tuple[ProjectInfo, list[ReleaseInfo]]]:
    """
    Fetch release listings for multiple projects in parallel, yielding results
    in the original project order as they become available.

    Results are buffered so that earlier projects are always yielded first,
    even if later projects finish sooner.

    Parameters:
        client: GitLab API client
        projects: Projects to fetch releases for
        max_workers: Number of parallel threads

    Yields:
        (project, releases) tuples in the original project order
    """
    logger = logging.getLogger(__name__)

    def fetch(project: ProjectInfo) -> list[ReleaseInfo]:
        try:
            return client.list_releases(project.id)
        except urllib.error.HTTPError as e:
            logger.warning(
                f"Failed to list releases for {project.path_with_namespace}: {e}"
            )
            return []

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures_list = [executor.submit(fetch, p) for p in projects]
        future_to_idx = {f: i for i, f in enumerate(futures_list)}
        completed: dict[int, list[ReleaseInfo]] = {}
        next_idx = 0

        for future in as_completed(future_to_idx):
            idx = future_to_idx[future]
            completed[idx] = future.result()

            while next_idx in completed:
                yield projects[next_idx], completed.pop(next_idx)
                next_idx += 1


# ----------------------------------------------------------------------------------------
def _gather_project_tasks(
    *,
    project: ProjectInfo,
    releases: list[ReleaseInfo] | None,
    config: DownloadConfig,
    output_dir: Path,
    is_group: bool,
    group_path: str | None,
    manifest: dict[str, dict[str, str]],
) -> tuple[list[_DownloadTask], int, int]:
    """
    Gather all download tasks for a single project from pre-fetched releases.

    Parameters:
        project: Project to gather tasks from
        releases: Pre-fetched releases (None or empty if fetch failed)
        config: Download configuration
        output_dir: Base output directory
        is_group: Whether we're processing a group
        group_path: The group path (for calculating relative project paths)
        manifest: Dict mapping relative paths to manifest entries

    Returns:
        Tuple of (download_tasks, skipped_count, release_count)
    """
    print(f"\n{bold(project.path_with_namespace)}")

    # Determine project output directory
    if config.flat:
        project_dir = output_dir
    elif is_group and group_path:
        relative_path = project.path_with_namespace
        if relative_path.startswith(group_path + "/"):
            relative_path = relative_path[len(group_path) + 1 :]
        project_dir = output_dir / relative_path
    else:
        project_dir = output_dir

    if not releases:
        print(f"  {cyan('No releases found')}")
        return [], 0, 0

    # Filter releases by version
    filtered_releases = [
        r for r in releases if matches_version_filter(r.tag_name, config.version_filter)
    ]

    if len(filtered_releases) < len(releases):
        print(
            f"  Filtered to {len(filtered_releases)} of {len(releases)} release(s) "
            f"(mode: {config.version_filter})"
        )

    if not filtered_releases:
        print(f"  {cyan('No releases match version filter')}")
        return [], 0, 0

    # Gather tasks from each release
    tasks: list[_DownloadTask] = []
    skipped = 0

    for release in filtered_releases:
        release_tasks, release_skipped = _gather_release_tasks(
            release=release,
            project_dir=project_dir,
            output_dir=output_dir,
            config=config,
            project_path=project.path_with_namespace,
            manifest=manifest,
        )
        tasks.extend(release_tasks)
        skipped += release_skipped

    return tasks, skipped, len(filtered_releases)


# ----------------------------------------------------------------------------------------
def _gather_release_tasks(
    *,
    release: ReleaseInfo,
    project_dir: Path,
    output_dir: Path,
    config: DownloadConfig,
    project_path: str,
    manifest: dict[str, dict[str, str]],
) -> tuple[list[_DownloadTask], int]:
    """
    Gather download tasks for a single release.

    Parameters:
        release: Release to gather tasks from
        project_dir: Project output directory
        output_dir: Base output directory (for computing manifest keys)
        config: Download configuration
        project_path: Full project path for display
        manifest: Dict mapping relative paths to manifest entries

    Returns:
        Tuple of (download_tasks, skipped_count)
    """
    if not release.assets:
        return [], 0

    release_dir = project_dir if config.flat else project_dir / release.tag_name
    dir_created = False

    tasks: list[_DownloadTask] = []
    skipped = 0

    for asset in release.assets:
        file_path = release_dir / asset.name
        file_desc = f"{release.tag_name}: {asset.name}"
        relative_key = str(file_path.relative_to(output_dir))

        # Skip if already in manifest or file exists on disk
        if not config.overwrite:
            if relative_key in manifest or file_path.exists():
                if relative_key not in manifest:
                    manifest[relative_key] = {"path": relative_key, "status": "exists"}
                skipped += 1
                print(f"  {yellow('Skipped')}    - {file_desc}")
                continue

        if not dir_created:
            release_dir.mkdir(parents=True, exist_ok=True)
            dir_created = True

        tasks.append(
            _DownloadTask(
                url=asset.direct_asset_url,
                file_path=file_path,
                release_tag=release.tag_name,
                asset_name=asset.name,
                project_path=project_path,
            )
        )

    return tasks, skipped


# ----------------------------------------------------------------------------------------
def _download_single_file(client: GitLabClient, task: _DownloadTask) -> None:
    """
    Download a single file and write it to disk.

    This function runs in a worker thread.

    Parameters:
        client: GitLab API client
        task: Download task with URL and destination path
    """
    content = client.download_file(task.url)
    task.file_path.write_bytes(content)


# ----------------------------------------------------------------------------------------
def _load_manifest(manifest_path: Path) -> dict[str, dict[str, str]]:
    """
    Load the download manifest from disk.

    Parameters:
        manifest_path: Path to the manifest JSON file

    Returns:
        Dict mapping relative file paths to entry dicts (status, downloaded)
    """
    if not manifest_path.exists():
        return {}

    try:
        with manifest_path.open() as f:
            data: dict[str, Any] = json.load(f)
            entries: list[dict[str, str]] = data.get("entries", [])
            return {e["path"]: e for e in entries if "path" in e}
    except (json.JSONDecodeError, OSError, TypeError) as e:
        print(
            yellow(f"Warning: Could not read manifest {manifest_path}: {e}"),
            file=sys.stderr,
        )

    return {}


# ----------------------------------------------------------------------------------------
def _save_manifest(manifest_path: Path, manifest: dict[str, dict[str, str]]) -> None:
    """
    Save the download manifest to disk.

    Parameters:
        manifest_path: Path to the manifest JSON file
        manifest: Dict mapping relative file paths to entry dicts
    """
    entries = sorted(manifest.values(), key=lambda e: e.get("path", ""))
    data = {"entries": entries}
    try:
        with manifest_path.open("w") as f:
            json.dump(data, f, indent=2)
            f.write("\n")
    except OSError as e:
        print(
            yellow(f"Warning: Could not write manifest {manifest_path}: {e}"),
            file=sys.stderr,
        )


# ----------------------------------------------------------------------------------------
def list_projects(config: DownloadConfig, *, json_output: bool = False) -> int:
    """
    List projects for the given path and exit.

    Parameters:
        config: Download configuration
        json_output: If True, output as JSON

    Returns:
        Exit code (0 for success, 1 for error)
    """
    client = GitLabClient(config.gitlab_url, token=config.token)

    if not json_output:
        print(f"Connecting to {config.gitlab_url}...")

    try:
        path_type, path_id = client.resolve_path(config.path)
    except ValueError as e:
        print(f"\nError: {e}")
        return 1
    except urllib.error.URLError as e:
        print(f"\nError: Failed to connect to GitLab: {e}")
        return 1

    projects: list[ProjectInfo] = []

    if path_type == "group":
        try:
            projects = client.get_group_projects(
                path_id, project_filter=config.project_filter
            )
        except urllib.error.HTTPError as e:
            print(f"\nError: Failed to list group projects: {e}")
            return 1
    else:
        project_info = client.get_project_info(path_id)
        if project_info is None:
            print(f"\nError: Project not found: {config.path}")
            return 1
        projects = [project_info]

    if json_output:
        data = [
            {"id": p.id, "path": p.path_with_namespace, "name": p.name}
            for p in projects
        ]
        print(json.dumps(data, indent=2))
    else:
        for project in projects:
            print(project.path_with_namespace)

    return 0


# ----------------------------------------------------------------------------------------
def list_releases(config: DownloadConfig, *, json_output: bool = False) -> int:
    """
    List releases for the given path and exit.

    Parameters:
        config: Download configuration
        json_output: If True, output as JSON

    Returns:
        Exit code (0 for success, 1 for error)
    """
    client = GitLabClient(config.gitlab_url, token=config.token)

    if not json_output:
        print(f"Connecting to {config.gitlab_url}...")

    try:
        path_type, path_id = client.resolve_path(config.path)
    except ValueError as e:
        print(f"\nError: {e}")
        return 1
    except urllib.error.URLError as e:
        print(f"\nError: Failed to connect to GitLab: {e}")
        return 1

    projects: list[ProjectInfo] = []

    if path_type == "group":
        try:
            projects = client.get_group_projects(
                path_id, project_filter=config.project_filter
            )
        except urllib.error.HTTPError as e:
            print(f"\nError: Failed to list group projects: {e}")
            return 1
    else:
        project_info = client.get_project_info(path_id)
        if project_info is None:
            print(f"\nError: Project not found: {config.path}")
            return 1
        projects = [project_info]

    json_data: list[dict[str, object]] = []

    # Fetch release listings in parallel, processing each project as results arrive
    for project, releases in _fetch_releases_streaming(
        client, projects, config.parallel
    ):
        if not json_output:
            print(f"\n{bold(project.path_with_namespace)}")

        if not releases:
            if not json_output:
                print(f"  {cyan('No releases found')}")
            continue

        # Filter releases by version
        filtered = [
            r
            for r in releases
            if matches_version_filter(r.tag_name, config.version_filter)
        ]

        if not json_output and len(filtered) < len(releases):
            print(
                f"  Filtered to {len(filtered)} of {len(releases)} release(s) "
                f"(mode: {config.version_filter})"
            )

        if json_output:
            for release in filtered:
                json_data.append(
                    {
                        "project": project.path_with_namespace,
                        "tag": release.tag_name,
                        "name": release.name,
                        "assets": [
                            {"name": a.name, "url": a.direct_asset_url}
                            for a in release.assets
                        ],
                    }
                )
        else:
            for release in filtered:
                asset_count = len(release.assets)
                suffix = "asset" if asset_count == 1 else "assets"
                print(f"  {release.tag_name} ({asset_count} {suffix})")

    if json_output:
        print(json.dumps(json_data, indent=2))

    return 0


# ----------------------------------------------------------------------------------------
def format_result_summary(result: DownloadResult) -> str:
    """
    Format a human-readable summary of the download result.

    Parameters:
        result: The download result to summarise

    Returns:
        Formatted summary string
    """
    lines: list[str] = []
    lines.append("")
    lines.append("Download Summary")
    lines.append("================")
    lines.append(f"Total projects: {result.total_projects}")
    lines.append(f"Total releases: {result.total_releases}")
    lines.append(f"Total files:    {result.total_files}")
    lines.append(f"Downloaded:     {result.downloaded_files}")

    if result.skipped_files > 0:
        lines.append(f"Skipped:        {result.skipped_files} (already exist)")

    if result.failed_files > 0:
        lines.append(f"Failed:         {result.failed_files}")

    return "\n".join(lines)
