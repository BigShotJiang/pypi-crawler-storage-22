# ----------------------------------------------------------------------------------------
#   version_filter
#   --------------
#
#   Version filtering utilities for release tag matching. Supports three modes:
#
#   - release: Only full semantic versions (x.y.z)
#   - beta:    Full releases plus beta pre-releases (x.y.z-beta, x.y.zb1, etc.)
#   - all:     All release tags with no filtering
#
#   Tag names may optionally have a "v" prefix (e.g., v1.0.0).
#
#   License
#   -------
#   MIT License - Copyright 2026 Cyber Assessment Labs
#
#   Authors
#   -------
#   bena (via claude)
#
#   Version History
#   ---------------
#   Feb 2026 - Created
# ----------------------------------------------------------------------------------------

# ----------------------------------------------------------------------------------------
#   Imports
# ----------------------------------------------------------------------------------------

import re

# ----------------------------------------------------------------------------------------
#   Constants
# ----------------------------------------------------------------------------------------

# Valid filter modes
FILTER_MODES = ("release", "beta", "all")

# Full release: v1.0.0 or 1.0.0
RELEASE_PATTERN = re.compile(r"^v?\d+\.\d+\.\d+$")

# Beta release: v1.0.0-beta, v1.0.0-beta.1, v1.0.0b1, v1.0.0-b2, etc.
# Also matches full releases (the beta suffix is optional)
BETA_PATTERN = re.compile(r"^v?\d+\.\d+\.\d+(-?b(eta)?\.?\d*)?$", re.IGNORECASE)


# ----------------------------------------------------------------------------------------
#   Functions
# ----------------------------------------------------------------------------------------


# ----------------------------------------------------------------------------------------
def matches_version_filter(tag_name: str, mode: str) -> bool:
    """
    Check if a release tag name matches the specified version filter mode.

    Parameters:
        tag_name: The release tag name (e.g., "v1.0.0", "1.0.0-beta.1")
        mode: Filter mode - one of "release", "beta", or "all"

    Returns:
        True if the tag matches the filter, False otherwise

    Examples:
        >>> matches_version_filter("v1.0.0", "release")
        True
        >>> matches_version_filter("1.0.0", "release")
        True
        >>> matches_version_filter("v1.0.0-beta.1", "release")
        False
        >>> matches_version_filter("v1.0.0-beta.1", "beta")
        True
        >>> matches_version_filter("v1.0.0b2", "beta")
        True
        >>> matches_version_filter("v1.0.0-rc1", "beta")
        False
        >>> matches_version_filter("v1.0.0-rc1", "all")
        True
        >>> matches_version_filter("nightly-2026-01-01", "all")
        True
    """
    if mode == "all":
        return True

    if mode == "beta":
        return bool(BETA_PATTERN.match(tag_name))

    # Default: release only
    return bool(RELEASE_PATTERN.match(tag_name))
