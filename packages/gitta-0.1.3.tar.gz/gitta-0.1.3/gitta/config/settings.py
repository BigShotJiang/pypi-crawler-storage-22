# config/settings.py
# Purpose: Load and validate configuration.
#
# Responsibilities:
#   - Read config file
#   - Validate required fields
#   - Return structured config object

import keyring

from gitta.config.storage import load_config
from gitta.constants import DEFAULT_MAX_DIFF_CHARS, KEYRING_SERVICE, VALID_STYLES

REQUIRED_FIELDS = ["provider", "base_url", "model", "style"]


class Settings:
    def __init__(self):
        data = load_config()

        missing = [f for f in REQUIRED_FIELDS if not data.get(f)]
        if missing:
            raise RuntimeError(
                f"Missing config field(s): {', '.join(missing)}. Run 'gitta init' to fix."
            )

        if data["style"] not in VALID_STYLES:
            raise RuntimeError(
                f"Invalid commit style '{data['style']}'. Must be one of: {', '.join(VALID_STYLES)}. Run 'gitta init' to fix."
            )

        self.provider = data["provider"]
        self.base_url = data["base_url"]
        self.model = data["model"]
        self.style = data["style"]
        self.max_diff_chars = int(data.get("max_diff_chars", DEFAULT_MAX_DIFF_CHARS))

    def validate_api_key(self) -> None:
        """Check that an API key exists in keyring for this provider."""
        api_key = keyring.get_password(KEYRING_SERVICE, self.provider)
        if not api_key:
            raise RuntimeError(
                f"API key not found for '{self.provider}'. Run 'gitta init' to configure."
            )
