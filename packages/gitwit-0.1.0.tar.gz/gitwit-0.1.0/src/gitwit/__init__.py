"""GitWit - AI-powered git commit messages using free APIs."""

__version__ = "0.1.0"
__author__ = "GitWit Contributors"
