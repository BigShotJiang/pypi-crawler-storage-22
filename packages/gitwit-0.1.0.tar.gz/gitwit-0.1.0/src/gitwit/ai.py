"""AI provider implementations for GitWit."""

import asyncio
import time
from abc import ABC, abstractmethod
from typing import Any

import httpx

from .config import get_api_key, get_model, get_provider


class AIError(Exception):
    """Exception raised for AI-related errors."""
    pass


class RateLimitError(AIError):
    """Exception raised when rate limited."""
    pass


class AuthenticationError(AIError):
    """Exception raised for authentication failures."""
    pass


class AIProvider(ABC):
    """Abstract base class for AI providers."""

    @abstractmethod
    async def generate(self, system_prompt: str, user_prompt: str) -> str:
        """
        Generate a response from the AI model.

        Args:
            system_prompt: The system prompt.
            user_prompt: The user prompt.

        Returns:
            The generated text response.
        """
        pass

    @property
    @abstractmethod
    def name(self) -> str:
        """The provider name."""
        pass


class GroqProvider(AIProvider):
    """Groq API provider (OpenAI-compatible)."""

    BASE_URL = "https://api.groq.com/openai/v1/chat/completions"
    DEFAULT_MODEL = "llama-3.3-70b-versatile"

    def __init__(self, api_key: str, model: str | None = None):
        self.api_key = api_key
        self.model = model or self.DEFAULT_MODEL

    @property
    def name(self) -> str:
        return "Groq"

    async def generate(self, system_prompt: str, user_prompt: str) -> str:
        """Generate a response using Groq API."""
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "temperature": 0.3,  # Low temperature for consistent commit messages
            "max_tokens": 256,
        }

        async with httpx.AsyncClient(timeout=30.0) as client:
            try:
                response = await client.post(
                    self.BASE_URL,
                    headers=headers,
                    json=payload,
                )

                if response.status_code == 401:
                    raise AuthenticationError(
                        "Invalid Groq API key. Get one at https://console.groq.com"
                    )
                elif response.status_code == 429:
                    raise RateLimitError(
                        "Groq rate limit exceeded. Wait a moment and try again."
                    )
                elif response.status_code != 200:
                    raise AIError(
                        f"Groq API error ({response.status_code}): {response.text}"
                    )

                data = response.json()
                return data["choices"][0]["message"]["content"].strip()

            except httpx.TimeoutException:
                raise AIError("Groq API request timed out")
            except httpx.RequestError as e:
                raise AIError(f"Network error: {e}")


class GeminiProvider(AIProvider):
    """Google Gemini API provider."""

    BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models"
    DEFAULT_MODEL = "gemini-1.5-flash"

    def __init__(self, api_key: str, model: str | None = None):
        self.api_key = api_key
        self.model = model or self.DEFAULT_MODEL

    @property
    def name(self) -> str:
        return "Gemini"

    async def generate(self, system_prompt: str, user_prompt: str) -> str:
        """Generate a response using Gemini API."""
        url = f"{self.BASE_URL}/{self.model}:generateContent"

        payload = {
            "contents": [
                {
                    "parts": [
                        {"text": f"{system_prompt}\n\n{user_prompt}"}
                    ]
                }
            ],
            "generationConfig": {
                "temperature": 0.3,
                "maxOutputTokens": 256,
            }
        }

        async with httpx.AsyncClient(timeout=30.0) as client:
            try:
                response = await client.post(
                    url,
                    params={"key": self.api_key},
                    json=payload,
                )

                if response.status_code == 401 or response.status_code == 403:
                    raise AuthenticationError(
                        "Invalid Gemini API key. Get one at https://aistudio.google.com"
                    )
                elif response.status_code == 429:
                    raise RateLimitError(
                        "Gemini rate limit exceeded. Wait a moment and try again."
                    )
                elif response.status_code != 200:
                    raise AIError(
                        f"Gemini API error ({response.status_code}): {response.text}"
                    )

                data = response.json()
                return data["candidates"][0]["content"]["parts"][0]["text"].strip()

            except httpx.TimeoutException:
                raise AIError("Gemini API request timed out")
            except httpx.RequestError as e:
                raise AIError(f"Network error: {e}")


class OllamaProvider(AIProvider):
    """Ollama local API provider."""

    BASE_URL = "http://localhost:11434/api/generate"
    DEFAULT_MODEL = "llama3.2"

    def __init__(self, model: str | None = None, base_url: str | None = None):
        self.model = model or self.DEFAULT_MODEL
        self.base_url = base_url or self.BASE_URL

    @property
    def name(self) -> str:
        return "Ollama"

    async def generate(self, system_prompt: str, user_prompt: str) -> str:
        """Generate a response using Ollama API."""
        payload = {
            "model": self.model,
            "prompt": f"{system_prompt}\n\n{user_prompt}",
            "stream": False,
            "options": {
                "temperature": 0.3,
                "num_predict": 256,
            }
        }

        async with httpx.AsyncClient(timeout=60.0) as client:
            try:
                response = await client.post(
                    self.base_url,
                    json=payload,
                )

                if response.status_code == 404:
                    raise AIError(
                        f"Model '{self.model}' not found. "
                        f"Run 'ollama pull {self.model}' first."
                    )
                elif response.status_code != 200:
                    raise AIError(
                        f"Ollama API error ({response.status_code}): {response.text}"
                    )

                data = response.json()
                return data["response"].strip()

            except httpx.ConnectError:
                raise AIError(
                    "Cannot connect to Ollama. "
                    "Make sure Ollama is running: https://ollama.ai"
                )
            except httpx.TimeoutException:
                raise AIError("Ollama request timed out (model may be loading)")
            except httpx.RequestError as e:
                raise AIError(f"Network error: {e}")


def get_ai_provider() -> AIProvider:
    """
    Get the configured AI provider instance.

    Returns:
        An AI provider instance based on configuration.

    Raises:
        AIError: If configuration is invalid.
    """
    provider_name = get_provider()
    api_key = get_api_key()
    model = get_model()

    if provider_name == "groq":
        if not api_key:
            raise AuthenticationError(
                "Groq API key not configured. Run:\n"
                "  gitwit config set api-key YOUR_GROQ_KEY\n\n"
                "Get a free key at: https://console.groq.com"
            )
        return GroqProvider(api_key, model or None)

    elif provider_name == "gemini":
        if not api_key:
            raise AuthenticationError(
                "Gemini API key not configured. Run:\n"
                "  gitwit config set api-key YOUR_GEMINI_KEY\n\n"
                "Get a free key at: https://aistudio.google.com"
            )
        return GeminiProvider(api_key, model or None)

    elif provider_name == "ollama":
        return OllamaProvider(model or None)

    else:
        raise AIError(
            f"Unknown provider: {provider_name}. "
            f"Supported: groq, gemini, ollama"
        )


async def generate_with_retry(
    provider: AIProvider,
    system_prompt: str,
    user_prompt: str,
    max_retries: int = 3,
    initial_delay: float = 1.0,
) -> str:
    """
    Generate a response with automatic retry on rate limits.

    Args:
        provider: The AI provider to use.
        system_prompt: The system prompt.
        user_prompt: The user prompt.
        max_retries: Maximum number of retries.
        initial_delay: Initial delay between retries (exponential backoff).

    Returns:
        The generated text response.
    """
    last_error = None
    delay = initial_delay

    for attempt in range(max_retries + 1):
        try:
            return await provider.generate(system_prompt, user_prompt)
        except RateLimitError as e:
            last_error = e
            if attempt < max_retries:
                await asyncio.sleep(delay)
                delay *= 2  # Exponential backoff
            continue
        except (AuthenticationError, AIError):
            raise

    raise last_error or AIError("Failed after retries")


def generate_sync(system_prompt: str, user_prompt: str) -> str:
    """
    Synchronous wrapper for AI generation.

    Args:
        system_prompt: The system prompt.
        user_prompt: The user prompt.

    Returns:
        The generated text response.
    """
    provider = get_ai_provider()
    return asyncio.run(generate_with_retry(provider, system_prompt, user_prompt))
