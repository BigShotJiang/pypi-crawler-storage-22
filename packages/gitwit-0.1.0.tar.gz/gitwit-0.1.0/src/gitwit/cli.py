"""CLI commands for GitWit."""

import subprocess
import sys
from typing import Optional

import click

from . import __version__
from .ai import AIError, AuthenticationError, generate_sync
from .config import (
    get_api_key,
    get_config_value,
    get_model,
    get_provider,
    is_configured,
    load_config,
    set_config_value,
    DEFAULT_MODELS,
)
from .git import (
    GitError,
    NoStagedChangesError,
    NotAGitRepoError,
    commit,
    get_branch_diff,
    get_current_branch,
    get_default_branch,
    get_staged_diff,
    has_staged_changes,
    is_git_repo,
    parse_diff_stats,
    stage_all_changes,
)
from .prompts import get_commit_prompt, get_pr_prompt


def style_error(message: str) -> str:
    """Style an error message."""
    return click.style(f"Error: {message}", fg="red")


def style_success(message: str) -> str:
    """Style a success message."""
    return click.style(message, fg="green")


def style_info(message: str) -> str:
    """Style an info message."""
    return click.style(message, fg="cyan")


def style_warning(message: str) -> str:
    """Style a warning message."""
    return click.style(message, fg="yellow")


def style_commit(message: str) -> str:
    """Style a commit message."""
    return click.style(message, fg="bright_white", bold=True)


@click.group(invoke_without_command=True)
@click.option("--version", "-v", is_flag=True, help="Show version and exit.")
@click.pass_context
def main(ctx: click.Context, version: bool) -> None:
    """GitWit - AI-powered git commit messages using free APIs."""
    if version:
        click.echo(f"gitwit {__version__}")
        return

    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@main.command(name="commit")
@click.option("--all", "-a", "stage_all", is_flag=True, help="Stage all changes before committing.")
@click.option("--yes", "-y", is_flag=True, help="Accept the generated message without confirmation.")
@click.option("--dry-run", "-n", is_flag=True, help="Show the message without committing.")
def commit_cmd(stage_all: bool, yes: bool, dry_run: bool) -> None:
    """Generate a commit message from staged changes."""
    # Check if we're in a git repo
    if not is_git_repo():
        click.echo(style_error("Not a git repository. Run 'git init' first."))
        sys.exit(1)

    # Check configuration
    if not is_configured():
        click.echo(style_warning("GitWit is not configured yet."))
        click.echo()
        if click.confirm("Would you like to configure it now?"):
            ctx = click.Context(config)
            ctx.invoke(interactive_setup)
        else:
            click.echo("\nRun 'gitwit config set provider groq' to get started.")
            sys.exit(1)

    # Stage all changes if requested
    if stage_all:
        click.echo(style_info("Staging all changes..."))
        stage_all_changes()

    # Check for staged changes
    if not has_staged_changes():
        click.echo(style_error(
            "No staged changes. Stage changes with 'git add' first, "
            "or use 'gitwit commit --all' to stage all changes."
        ))
        sys.exit(1)

    # Get the diff
    try:
        diff = get_staged_diff()
    except NoStagedChangesError as e:
        click.echo(style_error(str(e)))
        sys.exit(1)
    except GitError as e:
        click.echo(style_error(str(e)))
        sys.exit(1)

    # Show diff stats
    stats = parse_diff_stats(diff)
    click.echo(style_info(
        f"Analyzing {len(stats.files_changed)} file(s): "
        f"+{stats.additions} -{stats.deletions}"
    ))

    # Generate commit message
    provider = get_provider()
    model = get_model()
    click.echo(style_info(f"Generating commit message using {provider} ({model})..."))
    click.echo()

    try:
        system_prompt, user_prompt = get_commit_prompt(diff)
        message = generate_sync(system_prompt, user_prompt)

        # Clean up the message (remove quotes if present)
        message = message.strip().strip('"').strip("'")

        # Remove any trailing punctuation that shouldn't be there
        if message.endswith('.'):
            message = message[:-1]

    except AuthenticationError as e:
        click.echo(style_error(str(e)))
        sys.exit(1)
    except AIError as e:
        click.echo(style_error(str(e)))
        sys.exit(1)

    # Display the generated message
    click.echo("Generated commit message:")
    click.echo()
    click.echo(f"  {style_commit(message)}")
    click.echo()

    if dry_run:
        click.echo(style_info("Dry run - no commit created."))
        return

    if yes:
        # Auto-accept
        action = "y"
    else:
        # Interactive prompt
        click.echo("Options: [y]es, [e]dit, [r]egenerate, [n]o/cancel")
        action = click.prompt(
            "Accept this message?",
            type=click.Choice(["y", "e", "r", "n"], case_sensitive=False),
            default="y",
            show_choices=False,
        )

    while True:
        if action == "y":
            # Accept and commit
            try:
                output = commit(message)
                click.echo()
                click.echo(style_success("Committed successfully!"))
                # Show abbreviated output
                for line in output.strip().split('\n')[:3]:
                    click.echo(f"  {line}")
            except GitError as e:
                click.echo(style_error(str(e)))
                sys.exit(1)
            break

        elif action == "e":
            # Edit the message
            edited = click.edit(message)
            if edited:
                message = edited.strip()
                click.echo()
                click.echo("Edited message:")
                click.echo(f"  {style_commit(message)}")
                click.echo()
                action = click.prompt(
                    "Accept this message?",
                    type=click.Choice(["y", "e", "r", "n"], case_sensitive=False),
                    default="y",
                    show_choices=False,
                )
            else:
                click.echo(style_warning("Edit cancelled."))
                action = click.prompt(
                    "Action?",
                    type=click.Choice(["y", "e", "r", "n"], case_sensitive=False),
                    default="y",
                    show_choices=False,
                )

        elif action == "r":
            # Regenerate
            click.echo()
            click.echo(style_info("Regenerating..."))
            try:
                message = generate_sync(system_prompt, user_prompt)
                message = message.strip().strip('"').strip("'")
                if message.endswith('.'):
                    message = message[:-1]
            except AIError as e:
                click.echo(style_error(str(e)))
                sys.exit(1)

            click.echo()
            click.echo("Generated commit message:")
            click.echo(f"  {style_commit(message)}")
            click.echo()
            action = click.prompt(
                "Accept this message?",
                type=click.Choice(["y", "e", "r", "n"], case_sensitive=False),
                default="y",
                show_choices=False,
            )

        elif action == "n":
            click.echo(style_info("Commit cancelled."))
            break


@main.command(name="pr")
@click.option("--base", "-b", default=None, help="Base branch to compare against (default: main or master).")
@click.option("--dry-run", "-n", is_flag=True, help="Show the PR description without copying.")
def pr_cmd(base: str | None, dry_run: bool) -> None:
    """Generate a PR title and description from branch diff."""
    # Check if we're in a git repo
    if not is_git_repo():
        click.echo(style_error("Not a git repository."))
        sys.exit(1)

    # Check configuration
    if not is_configured():
        click.echo(style_warning("GitWit is not configured yet."))
        click.echo()
        if click.confirm("Would you like to configure it now?"):
            ctx = click.Context(config)
            ctx.invoke(interactive_setup)
        else:
            click.echo("\nRun 'gitwit config set provider groq' to get started.")
            sys.exit(1)

    # Get current branch
    current_branch = get_current_branch()
    if not current_branch:
        click.echo(style_error("Could not determine current branch."))
        sys.exit(1)

    # Detect base branch if not specified
    if base is None:
        try:
            base = get_default_branch()
        except GitError:
            click.echo(style_error("Could not detect default branch. Use --base to specify."))
            sys.exit(1)

    # Check if we're on the base branch
    if current_branch == base:
        click.echo(style_error(f"Already on {base} branch. Switch to a feature branch first."))
        sys.exit(1)

    click.echo(style_info(f"Comparing {current_branch} → {base}"))

    # Get the diff
    try:
        diff = get_branch_diff(base)
    except GitError as e:
        click.echo(style_error(str(e)))
        sys.exit(1)

    if not diff.strip():
        click.echo(style_error(f"No changes between {current_branch} and {base}."))
        sys.exit(1)

    # Show diff stats
    stats = parse_diff_stats(diff)
    click.echo(style_info(
        f"Analyzing {len(stats.files_changed)} file(s): "
        f"+{stats.additions} -{stats.deletions}"
    ))

    # Generate PR description
    provider = get_provider()
    model = get_model()
    click.echo(style_info(f"Generating PR description using {provider} ({model})..."))
    click.echo()

    try:
        system_prompt, user_prompt = get_pr_prompt(diff, current_branch)
        description = generate_sync(system_prompt, user_prompt)
        description = description.strip()

    except AuthenticationError as e:
        click.echo(style_error(str(e)))
        sys.exit(1)
    except AIError as e:
        click.echo(style_error(str(e)))
        sys.exit(1)

    # Display the generated description
    click.echo(style_commit("=" * 60))
    click.echo()
    click.echo(description)
    click.echo()
    click.echo(style_commit("=" * 60))
    click.echo()

    if dry_run:
        click.echo(style_info("Dry run - PR description displayed above."))
        return

    # Offer to copy to clipboard
    click.echo("Options: [c]opy to clipboard, [r]egenerate, [q]uit")
    action = click.prompt(
        "Action?",
        type=click.Choice(["c", "r", "q"], case_sensitive=False),
        default="c",
        show_choices=False,
    )

    while True:
        if action == "c":
            # Try to copy to clipboard
            try:
                import subprocess
                process = subprocess.Popen(
                    ["pbcopy"] if sys.platform == "darwin" else ["xclip", "-selection", "clipboard"],
                    stdin=subprocess.PIPE
                )
                process.communicate(description.encode())
                click.echo(style_success("Copied to clipboard!"))
            except Exception:
                click.echo(style_warning("Could not copy to clipboard. Copy manually from above."))
            break

        elif action == "r":
            click.echo()
            click.echo(style_info("Regenerating..."))
            try:
                description = generate_sync(system_prompt, user_prompt)
                description = description.strip()
            except AIError as e:
                click.echo(style_error(str(e)))
                sys.exit(1)

            click.echo()
            click.echo(style_commit("=" * 60))
            click.echo()
            click.echo(description)
            click.echo()
            click.echo(style_commit("=" * 60))
            click.echo()
            action = click.prompt(
                "Action?",
                type=click.Choice(["c", "r", "q"], case_sensitive=False),
                default="c",
                show_choices=False,
            )

        elif action == "q":
            click.echo(style_info("Done."))
            break


@main.group()
def config() -> None:
    """Manage GitWit configuration."""
    pass


@config.command("set")
@click.argument("key")
@click.argument("value")
def config_set(key: str, value: str) -> None:
    """Set a configuration value."""
    valid_keys = ["provider", "api-key", "api_key", "model"]

    if key not in valid_keys:
        click.echo(style_error(f"Unknown key: {key}"))
        click.echo(f"Valid keys: {', '.join(valid_keys)}")
        sys.exit(1)

    # Validate provider
    if key == "provider":
        valid_providers = ["groq", "gemini", "ollama"]
        if value.lower() not in valid_providers:
            click.echo(style_error(f"Unknown provider: {value}"))
            click.echo(f"Valid providers: {', '.join(valid_providers)}")
            sys.exit(1)
        value = value.lower()

    set_config_value(key, value)
    click.echo(style_success(f"Set {key} = {value if key != 'api-key' and key != 'api_key' else '***'}"))

    # Show next steps if provider was set
    if key == "provider" and value != "ollama":
        api_key = get_api_key()
        if not api_key:
            click.echo()
            click.echo(style_info("Next step: Set your API key:"))
            if value == "groq":
                click.echo("  gitwit config set api-key YOUR_GROQ_KEY")
                click.echo("  Get a free key at: https://console.groq.com")
            elif value == "gemini":
                click.echo("  gitwit config set api-key YOUR_GEMINI_KEY")
                click.echo("  Get a free key at: https://aistudio.google.com")


@config.command("show")
def config_show() -> None:
    """Show current configuration."""
    cfg = load_config()

    click.echo()
    click.echo(style_info("GitWit Configuration"))
    click.echo(style_info("=" * 40))

    provider = cfg.get("provider", "groq")
    click.echo(f"Provider:  {provider}")

    model = cfg.get("model") or DEFAULT_MODELS.get(provider, "")
    click.echo(f"Model:     {model}")

    api_key = cfg.get("api_key", "")
    if api_key:
        masked = api_key[:4] + "..." + api_key[-4:] if len(api_key) > 8 else "***"
        click.echo(f"API Key:   {masked}")
    else:
        click.echo(f"API Key:   {style_warning('not set')}")

    click.echo()

    if not is_configured():
        click.echo(style_warning("Configuration incomplete. Run:"))
        if provider == "ollama":
            click.echo("  Make sure Ollama is running: https://ollama.ai")
        else:
            click.echo(f"  gitwit config set api-key YOUR_{provider.upper()}_KEY")


def interactive_setup() -> None:
    """Run interactive configuration setup."""
    click.echo()
    click.echo(style_info("GitWit Setup"))
    click.echo(style_info("=" * 40))
    click.echo()

    # Choose provider
    click.echo("Choose your AI provider:")
    click.echo("  1. Groq (recommended) - 30 req/min free, fastest inference")
    click.echo("  2. Gemini - 1,500 req/day free")
    click.echo("  3. Ollama - Unlimited, runs locally")
    click.echo()

    choice = click.prompt(
        "Provider",
        type=click.Choice(["1", "2", "3"]),
        default="1",
    )

    provider_map = {"1": "groq", "2": "gemini", "3": "ollama"}
    provider = provider_map[choice]
    set_config_value("provider", provider)

    # Get API key for cloud providers
    if provider != "ollama":
        click.echo()
        if provider == "groq":
            click.echo("Get your free Groq API key at: https://console.groq.com")
        else:
            click.echo("Get your free Gemini API key at: https://aistudio.google.com")

        click.echo()
        api_key = click.prompt("API Key", hide_input=True)
        set_config_value("api_key", api_key)
    else:
        click.echo()
        click.echo(style_info("Make sure Ollama is running: https://ollama.ai"))
        click.echo(f"Default model: {DEFAULT_MODELS['ollama']}")
        if click.confirm("Use a different model?", default=False):
            model = click.prompt("Model name")
            set_config_value("model", model)

    click.echo()
    click.echo(style_success("Configuration complete!"))
    click.echo()
    click.echo("Try it out:")
    click.echo("  git add .")
    click.echo("  gitwit commit")


@config.command("init")
def config_init() -> None:
    """Run interactive configuration setup."""
    interactive_setup()


if __name__ == "__main__":
    main()
