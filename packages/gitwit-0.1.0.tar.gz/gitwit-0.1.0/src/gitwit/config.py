"""Configuration management for GitWit."""

import os
import sys
from pathlib import Path
from typing import Any

if sys.version_info >= (3, 11):
    import tomllib
else:
    import tomli as tomllib

import tomli_w


# Default configuration
DEFAULT_CONFIG = {
    "provider": "groq",
    "model": "",  # Empty means use provider default
    "api_key": "",
}

# Default models per provider
DEFAULT_MODELS = {
    "groq": "llama-3.3-70b-versatile",
    "gemini": "gemini-1.5-flash",
    "ollama": "llama3.2",
}


def get_config_dir() -> Path:
    """Get the GitWit configuration directory."""
    return Path.home() / ".gitwit"


def get_config_path() -> Path:
    """Get the path to the config file."""
    return get_config_dir() / "config.toml"


def ensure_config_dir() -> None:
    """Ensure the config directory exists."""
    config_dir = get_config_dir()
    config_dir.mkdir(parents=True, exist_ok=True)


def load_config() -> dict[str, Any]:
    """
    Load configuration from file.

    Returns:
        Configuration dictionary with defaults applied.
    """
    config_path = get_config_path()

    if not config_path.exists():
        return DEFAULT_CONFIG.copy()

    try:
        with open(config_path, "rb") as f:
            config = tomllib.load(f)
    except Exception:
        return DEFAULT_CONFIG.copy()

    # Merge with defaults
    result = DEFAULT_CONFIG.copy()
    result.update(config)
    return result


def save_config(config: dict[str, Any]) -> None:
    """
    Save configuration to file.

    Args:
        config: Configuration dictionary to save.
    """
    ensure_config_dir()
    config_path = get_config_path()

    with open(config_path, "wb") as f:
        tomli_w.dump(config, f)


def get_config_value(key: str) -> Any:
    """
    Get a specific configuration value.

    Args:
        key: Configuration key (supports dot notation for nested keys).

    Returns:
        The configuration value or None if not found.
    """
    config = load_config()

    # Handle dot notation for nested keys
    keys = key.replace("-", "_").split(".")
    value = config

    for k in keys:
        if isinstance(value, dict):
            value = value.get(k)
        else:
            return None

    return value


def set_config_value(key: str, value: str) -> None:
    """
    Set a specific configuration value.

    Args:
        key: Configuration key (supports dot notation for nested keys).
        value: Value to set.
    """
    config = load_config()

    # Normalize key (api-key -> api_key)
    key = key.replace("-", "_")

    # Handle dot notation for nested keys
    keys = key.split(".")

    if len(keys) == 1:
        config[keys[0]] = value
    else:
        # Navigate to parent and set value
        current = config
        for k in keys[:-1]:
            if k not in current:
                current[k] = {}
            current = current[k]
        current[keys[-1]] = value

    save_config(config)


def get_api_key() -> str | None:
    """Get the API key for the current provider."""
    return get_config_value("api_key") or os.environ.get("GITWIT_API_KEY")


def get_provider() -> str:
    """Get the current AI provider."""
    return get_config_value("provider") or "groq"


def get_model() -> str:
    """Get the current model, with provider default fallback."""
    model = get_config_value("model")
    if model:
        return model

    provider = get_provider()
    return DEFAULT_MODELS.get(provider, "")


def is_configured() -> bool:
    """Check if GitWit has been configured with necessary credentials."""
    provider = get_provider()

    # Ollama doesn't need an API key
    if provider == "ollama":
        return True

    api_key = get_api_key()
    return bool(api_key)
