"""Git operations for GitWit."""

import subprocess
from dataclasses import dataclass
from pathlib import Path


class GitError(Exception):
    """Exception raised for git-related errors."""
    pass


class NotAGitRepoError(GitError):
    """Exception raised when not in a git repository."""
    pass


class NoStagedChangesError(GitError):
    """Exception raised when there are no staged changes."""
    pass


@dataclass
class DiffStats:
    """Statistics about a git diff."""
    files_changed: list[str]
    additions: int
    deletions: int
    total_lines: int


def run_git_command(args: list[str], cwd: Path | None = None) -> str:
    """
    Run a git command and return its output.

    Args:
        args: List of arguments to pass to git.
        cwd: Working directory for the command.

    Returns:
        The command output as a string.

    Raises:
        GitError: If the command fails.
        NotAGitRepoError: If not in a git repository.
    """
    try:
        result = subprocess.run(
            ["git"] + args,
            capture_output=True,
            text=True,
            cwd=cwd,
            timeout=30,
        )

        if result.returncode != 0:
            stderr = result.stderr.strip()
            if "not a git repository" in stderr.lower():
                raise NotAGitRepoError("Not a git repository. Run 'git init' first.")
            raise GitError(f"Git command failed: {stderr}")

        return result.stdout

    except subprocess.TimeoutExpired:
        raise GitError("Git command timed out")
    except FileNotFoundError:
        raise GitError("Git is not installed or not in PATH")


def is_git_repo(path: Path | None = None) -> bool:
    """
    Check if the current directory is a git repository.

    Args:
        path: Path to check. Defaults to current directory.

    Returns:
        True if in a git repository, False otherwise.
    """
    try:
        run_git_command(["rev-parse", "--git-dir"], cwd=path)
        return True
    except GitError:
        return False


def get_repo_root(path: Path | None = None) -> Path:
    """
    Get the root directory of the git repository.

    Args:
        path: Path to start from. Defaults to current directory.

    Returns:
        Path to the repository root.

    Raises:
        NotAGitRepoError: If not in a git repository.
    """
    output = run_git_command(["rev-parse", "--show-toplevel"], cwd=path)
    return Path(output.strip())


def get_staged_diff(path: Path | None = None) -> str:
    """
    Get the diff of staged changes.

    Args:
        path: Repository path. Defaults to current directory.

    Returns:
        The staged diff as a string.

    Raises:
        NoStagedChangesError: If there are no staged changes.
    """
    diff = run_git_command(["diff", "--cached"], cwd=path)

    if not diff.strip():
        raise NoStagedChangesError(
            "No staged changes. Stage changes with 'git add' first, "
            "or use 'gitwit commit --all' to stage all changes."
        )

    return diff


def get_staged_files(path: Path | None = None) -> list[str]:
    """
    Get a list of staged files.

    Args:
        path: Repository path. Defaults to current directory.

    Returns:
        List of staged file paths.
    """
    output = run_git_command(["diff", "--cached", "--name-only"], cwd=path)
    return [f for f in output.strip().split("\n") if f]


def has_staged_changes(path: Path | None = None) -> bool:
    """
    Check if there are any staged changes.

    Args:
        path: Repository path. Defaults to current directory.

    Returns:
        True if there are staged changes, False otherwise.
    """
    try:
        get_staged_diff(path)
        return True
    except NoStagedChangesError:
        return False


def stage_all_changes(path: Path | None = None) -> None:
    """
    Stage all changes in the repository.

    Args:
        path: Repository path. Defaults to current directory.
    """
    run_git_command(["add", "-A"], cwd=path)


def commit(message: str, path: Path | None = None) -> str:
    """
    Create a commit with the given message.

    Args:
        message: Commit message.
        path: Repository path. Defaults to current directory.

    Returns:
        The commit output.
    """
    return run_git_command(["commit", "-m", message], cwd=path)


def get_branch_name(path: Path | None = None) -> str:
    """
    Get the current branch name.

    Args:
        path: Repository path. Defaults to current directory.

    Returns:
        The current branch name.
    """
    output = run_git_command(["branch", "--show-current"], cwd=path)
    return output.strip()


def get_branch_diff(base_branch: str = "main", path: Path | None = None) -> str:
    """
    Get the diff between the current branch and a base branch.

    Args:
        base_branch: The base branch to compare against.
        path: Repository path. Defaults to current directory.

    Returns:
        The diff as a string.
    """
    # Try the specified branch, fall back to 'master' if 'main' doesn't exist
    try:
        return run_git_command(["diff", f"{base_branch}...HEAD"], cwd=path)
    except GitError:
        if base_branch == "main":
            return run_git_command(["diff", "master...HEAD"], cwd=path)
        raise


def parse_diff_stats(diff: str) -> DiffStats:
    """
    Parse a diff string and extract statistics.

    Args:
        diff: The git diff string.

    Returns:
        DiffStats with information about the changes.
    """
    lines = diff.split('\n')
    files = []
    additions = 0
    deletions = 0

    for line in lines:
        if line.startswith('diff --git'):
            # Extract filename from "diff --git a/path b/path"
            parts = line.split(' ')
            if len(parts) >= 4:
                files.append(parts[2][2:])  # Remove 'a/' prefix
        elif line.startswith('+') and not line.startswith('+++'):
            additions += 1
        elif line.startswith('-') and not line.startswith('---'):
            deletions += 1

    return DiffStats(
        files_changed=files,
        additions=additions,
        deletions=deletions,
        total_lines=len(lines)
    )


def get_current_branch(path: Path | None = None) -> str:
    """
    Get the current branch name.

    Args:
        path: Repository path. Defaults to current directory.

    Returns:
        The current branch name.
    """
    return get_branch_name(path)


def get_default_branch(path: Path | None = None) -> str:
    """
    Detect the default branch (main or master).

    Args:
        path: Repository path. Defaults to current directory.

    Returns:
        'main' if it exists, otherwise 'master'.

    Raises:
        GitError: If neither main nor master exists.
    """
    # Check if 'main' branch exists
    try:
        run_git_command(["rev-parse", "--verify", "main"], cwd=path)
        return "main"
    except GitError:
        pass

    # Check if 'master' branch exists
    try:
        run_git_command(["rev-parse", "--verify", "master"], cwd=path)
        return "master"
    except GitError:
        pass

    raise GitError("Could not find default branch (main or master)")


def get_recent_commits(count: int = 5, path: Path | None = None) -> list[str]:
    """
    Get recent commit messages for style reference.

    Args:
        count: Number of commits to retrieve.
        path: Repository path. Defaults to current directory.

    Returns:
        List of recent commit messages.
    """
    try:
        output = run_git_command(
            ["log", f"-{count}", "--pretty=format:%s"],
            cwd=path
        )
        return [msg for msg in output.strip().split("\n") if msg]
    except GitError:
        return []
