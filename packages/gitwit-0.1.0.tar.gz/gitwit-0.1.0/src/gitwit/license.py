"""License validation for GitWit (LemonSqueezy integration stub)."""

from dataclasses import dataclass
from typing import Any


@dataclass
class LicenseInfo:
    """Information about a validated license."""
    valid: bool
    license_key: str | None = None
    email: str | None = None
    plan: str = "free"  # free, pro, team
    features: list[str] | None = None

    def __post_init__(self):
        if self.features is None:
            self.features = self._get_plan_features()

    def _get_plan_features(self) -> list[str]:
        """Get features for the current plan."""
        free_features = ["commit"]
        pro_features = free_features + ["pr", "changelog", "release", "custom-prompts"]
        team_features = pro_features + ["team-config", "priority-support"]

        if self.plan == "team":
            return team_features
        elif self.plan == "pro":
            return pro_features
        return free_features

    def has_feature(self, feature: str) -> bool:
        """Check if a feature is available in the current plan."""
        return feature in (self.features or [])


# Global license state
_current_license: LicenseInfo | None = None


def get_license() -> LicenseInfo:
    """
    Get the current license information.

    Returns:
        LicenseInfo with current license status.
    """
    global _current_license

    if _current_license is None:
        # For MVP, return free license
        # TODO: Implement LemonSqueezy validation
        _current_license = LicenseInfo(valid=True, plan="free")

    return _current_license


def validate_license(license_key: str) -> LicenseInfo:
    """
    Validate a license key with LemonSqueezy.

    Args:
        license_key: The license key to validate.

    Returns:
        LicenseInfo with validation result.

    Note:
        This is a stub for MVP. Full implementation will call LemonSqueezy API.
    """
    global _current_license

    # TODO: Implement actual LemonSqueezy API validation
    # API endpoint: https://api.lemonsqueezy.com/v1/licenses/validate
    #
    # For now, accept any key that looks valid (for testing)
    if license_key and len(license_key) >= 10:
        _current_license = LicenseInfo(
            valid=True,
            license_key=license_key,
            plan="pro",
        )
    else:
        _current_license = LicenseInfo(valid=False, plan="free")

    return _current_license


def require_feature(feature: str) -> bool:
    """
    Check if a feature is available, showing upgrade message if not.

    Args:
        feature: The feature to check.

    Returns:
        True if feature is available, False otherwise.
    """
    license_info = get_license()

    if license_info.has_feature(feature):
        return True

    # Feature not available
    return False


def get_upgrade_message(feature: str) -> str:
    """Get the upgrade message for a feature."""
    feature_names = {
        "pr": "PR description generation",
        "changelog": "Changelog generation",
        "release": "Release notes generation",
        "custom-prompts": "Custom prompt templates",
        "team-config": "Team configuration",
    }

    feature_name = feature_names.get(feature, feature)

    return (
        f"\n{feature_name} is a Pro feature.\n\n"
        f"Upgrade to GitWit Pro: https://gitwit.dev/pricing\n"
        f"Use code LAUNCH50 for 50% off!\n"
    )
