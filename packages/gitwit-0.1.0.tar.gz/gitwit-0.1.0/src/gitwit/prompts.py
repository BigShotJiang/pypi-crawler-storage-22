"""Prompt templates for AI operations."""

COMMIT_SYSTEM_PROMPT = """You are a git commit message generator. Generate a single conventional commit message following the format:

type(scope): description

Rules:
- Types: feat, fix, docs, style, refactor, test, chore, perf, ci, build
- Scope is optional but encouraged (e.g., auth, api, ui, config)
- Description must be lowercase, imperative mood, no period at end
- Keep the first line under 72 characters
- Only output the commit message, nothing else
- No quotes around the message
- No explanation or preamble

Examples of good commit messages:
- feat(auth): add OAuth2 login support
- fix(api): handle null response from user endpoint
- docs: update installation instructions
- refactor(utils): simplify date parsing logic
- chore: update dependencies to latest versions"""

COMMIT_USER_PROMPT = """Generate a commit message for the following git diff:

{diff}"""

COMMIT_SUMMARY_USER_PROMPT = """Generate a commit message for the following changes:

Files changed: {files}
Total additions: +{additions}
Total deletions: -{deletions}

Partial diff (truncated due to size):
{diff}"""


def get_commit_prompt(diff: str, max_diff_chars: int = 4000) -> tuple[str, str]:
    """
    Get the system and user prompts for commit message generation.

    If the diff is too long, summarizes it to fit within token limits.

    Args:
        diff: The git diff string
        max_diff_chars: Maximum characters for the diff in the prompt

    Returns:
        Tuple of (system_prompt, user_prompt)
    """
    if len(diff) <= max_diff_chars:
        return COMMIT_SYSTEM_PROMPT, COMMIT_USER_PROMPT.format(diff=diff)

    # Parse diff to get summary info
    lines = diff.split('\n')
    files = []
    additions = 0
    deletions = 0

    for line in lines:
        if line.startswith('diff --git'):
            # Extract filename from "diff --git a/path b/path"
            parts = line.split(' ')
            if len(parts) >= 4:
                files.append(parts[2][2:])  # Remove 'a/' prefix
        elif line.startswith('+') and not line.startswith('+++'):
            additions += 1
        elif line.startswith('-') and not line.startswith('---'):
            deletions += 1

    # Truncate diff to fit
    truncated_diff = diff[:max_diff_chars - 500]  # Leave room for summary

    user_prompt = COMMIT_SUMMARY_USER_PROMPT.format(
        files=', '.join(files[:10]) + ('...' if len(files) > 10 else ''),
        additions=additions,
        deletions=deletions,
        diff=truncated_diff
    )

    return COMMIT_SYSTEM_PROMPT, user_prompt


# PR (Pull Request) prompts

PR_SYSTEM_PROMPT = """You are a pull request description generator. Generate a PR title and description in the following exact format:

Title: <short descriptive title under 72 characters>

## Summary
<1-3 sentences describing what this PR does and why>

## Changes
<bullet list of key changes>

Rules:
- Title should be concise and descriptive, no type prefix needed
- Summary should explain the purpose and impact
- Changes should list the main modifications made
- Keep it professional and clear
- No code blocks unless absolutely necessary
- Output ONLY the formatted content, no extra text"""

PR_USER_PROMPT = """Generate a PR title and description for the following branch diff:

Branch: {branch_name}

{diff}"""

PR_SUMMARY_USER_PROMPT = """Generate a PR title and description for the following changes:

Branch: {branch_name}
Files changed: {files}
Total additions: +{additions}
Total deletions: -{deletions}

Partial diff (truncated due to size):
{diff}"""


def get_pr_prompt(diff: str, branch_name: str, max_diff_chars: int = 6000) -> tuple[str, str]:
    """
    Get the system and user prompts for PR description generation.

    Args:
        diff: The git diff string
        branch_name: The current branch name
        max_diff_chars: Maximum characters for the diff in the prompt

    Returns:
        Tuple of (system_prompt, user_prompt)
    """
    if len(diff) <= max_diff_chars:
        return PR_SYSTEM_PROMPT, PR_USER_PROMPT.format(branch_name=branch_name, diff=diff)

    # Parse diff to get summary info
    lines = diff.split('\n')
    files = []
    additions = 0
    deletions = 0

    for line in lines:
        if line.startswith('diff --git'):
            parts = line.split(' ')
            if len(parts) >= 4:
                files.append(parts[2][2:])
        elif line.startswith('+') and not line.startswith('+++'):
            additions += 1
        elif line.startswith('-') and not line.startswith('---'):
            deletions += 1

    truncated_diff = diff[:max_diff_chars - 500]

    user_prompt = PR_SUMMARY_USER_PROMPT.format(
        branch_name=branch_name,
        files=', '.join(files[:10]) + ('...' if len(files) > 10 else ''),
        additions=additions,
        deletions=deletions,
        diff=truncated_diff
    )

    return PR_SYSTEM_PROMPT, user_prompt
