"""Tests for GitWit."""
