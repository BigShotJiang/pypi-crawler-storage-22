"""Tests for AI providers."""

import pytest

from gitwit.ai import GroqProvider, GeminiProvider, OllamaProvider


class TestGroqProvider:
    """Tests for GroqProvider."""

    def test_provider_name(self):
        """Test provider name."""
        provider = GroqProvider(api_key="test-key")
        assert provider.name == "Groq"

    def test_default_model(self):
        """Test default model."""
        provider = GroqProvider(api_key="test-key")
        assert provider.model == "llama-3.3-70b-versatile"

    def test_custom_model(self):
        """Test custom model."""
        provider = GroqProvider(api_key="test-key", model="custom-model")
        assert provider.model == "custom-model"


class TestGeminiProvider:
    """Tests for GeminiProvider."""

    def test_provider_name(self):
        """Test provider name."""
        provider = GeminiProvider(api_key="test-key")
        assert provider.name == "Gemini"

    def test_default_model(self):
        """Test default model."""
        provider = GeminiProvider(api_key="test-key")
        assert provider.model == "gemini-1.5-flash"


class TestOllamaProvider:
    """Tests for OllamaProvider."""

    def test_provider_name(self):
        """Test provider name."""
        provider = OllamaProvider()
        assert provider.name == "Ollama"

    def test_default_model(self):
        """Test default model."""
        provider = OllamaProvider()
        assert provider.model == "llama3.2"

    def test_custom_url(self):
        """Test custom URL."""
        provider = OllamaProvider(base_url="http://custom:11434/api/generate")
        assert provider.base_url == "http://custom:11434/api/generate"
