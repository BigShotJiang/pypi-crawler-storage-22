"""Tests for CLI commands."""

import pytest
from click.testing import CliRunner

from gitwit.cli import main


class TestCLI:
    """Tests for CLI."""

    def test_help(self):
        """Test --help option."""
        runner = CliRunner()
        result = runner.invoke(main, ["--help"])

        assert result.exit_code == 0
        assert "GitWit" in result.output
        assert "commit" in result.output
        assert "config" in result.output

    def test_version(self):
        """Test --version option."""
        runner = CliRunner()
        result = runner.invoke(main, ["--version"])

        assert result.exit_code == 0
        assert "gitwit" in result.output

    def test_config_help(self):
        """Test config --help."""
        runner = CliRunner()
        result = runner.invoke(main, ["config", "--help"])

        assert result.exit_code == 0
        assert "set" in result.output
        assert "show" in result.output


class TestConfigCommand:
    """Tests for config command."""

    def test_config_show(self):
        """Test config show command."""
        runner = CliRunner()
        result = runner.invoke(main, ["config", "show"])

        assert result.exit_code == 0
        assert "Provider" in result.output
