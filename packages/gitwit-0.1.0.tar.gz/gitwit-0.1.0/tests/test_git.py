"""Tests for git operations."""

import pytest

from gitwit.git import parse_diff_stats


class TestParseDiffStats:
    """Tests for parse_diff_stats function."""

    def test_simple_diff(self):
        """Test parsing a simple diff."""
        diff = """diff --git a/src/main.py b/src/main.py
index 1234567..abcdefg 100644
--- a/src/main.py
+++ b/src/main.py
@@ -1,3 +1,4 @@
 import os
+import sys

 def main():
-    pass
+    print("Hello")
"""
        stats = parse_diff_stats(diff)

        assert stats.files_changed == ["src/main.py"]
        assert stats.additions == 2  # +import sys, +print("Hello")
        assert stats.deletions == 1  # -pass

    def test_multiple_files(self):
        """Test parsing diff with multiple files."""
        diff = """diff --git a/file1.py b/file1.py
--- a/file1.py
+++ b/file1.py
+new line
diff --git a/file2.py b/file2.py
--- a/file2.py
+++ b/file2.py
-old line
+new line
"""
        stats = parse_diff_stats(diff)

        assert len(stats.files_changed) == 2
        assert "file1.py" in stats.files_changed
        assert "file2.py" in stats.files_changed
        assert stats.additions == 2
        assert stats.deletions == 1

    def test_empty_diff(self):
        """Test parsing empty diff."""
        stats = parse_diff_stats("")

        assert stats.files_changed == []
        assert stats.additions == 0
        assert stats.deletions == 0
