
# 📧 GYAM - GiveYouAMail CLI

**GYAM** é uma ferramenta de elite para provisionamento de identidades temporárias via terminal. Esqueça o spam no seu e-mail pessoal e pare de caçar contas compartilhadas. Aqui, cada identidade é sua, exclusiva e gerada em segundos.

---

## 🛠️ Instalação

Para instalar essa joia no seu sistema (Termux ou Linux):

```bash
pip install .

Como usar a Máquina
O GYAM trabalha com dois pilares: Criação e Acesso.

1. Criando sua Identidade (Login)
Para gerar uma conta nova com um domínio ativo e exclusivo:

Bash
GYAM -Login CF -- pswd:SUA_SENHA_AQUI

O sistema escolherá um domínio aleatório e seguro.

Sua sessão será salva localmente em session.json.

Nota: Se quiser um e-mail específico, use M:seu_nome@dominio.com.

. Acessando a Inbox (OAuth)
Uma vez logado, entre no painel de controle:

Bash
GYAM -oauth

Controles da TUI (Interface)
Dentro do painel, você manda na porra toda:

SETAS (↑/↓): Navega entre as mensagens recebidas.

ENTER: Abre o conteúdo completo do e-mail selecionado.

R: Dá um Refresh nervoso para buscar novos e-mails.

ESC / B: Volta da leitura para a lista.

Q / ESC: Sai da ferramenta e volta para o prompt.

(GYAM foi feito para ser rápido, bruto e funcional.

Desenvolvido por: MurilooPrDev)
