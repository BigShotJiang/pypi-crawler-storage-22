#!/usr/bin/env python
import requests, time, os, sys, tty, termios, json, re

API_URL = "https://api.mail.tm"

class TUI:
    def __init__(self, email, token, name):
        self.email, self.token, self.name = email, token, name
        self.messages, self.selected, self.action_idx, self.running = [], 0, 0, True

    def fetch(self):
        try:
            h = {"Authorization": f"Bearer {self.token}"}
            res = requests.get(f"{API_URL}/messages", headers=h).json()
            self.messages = res.get('hydra:member', [])
        except: pass

    def read_msg(self, msg_id):
        h = {"Authorization": f"Bearer {self.token}"}
        res = requests.get(f"{API_URL}/messages/{msg_id}", headers=h).json()
        os.system('clear')
        print(f"\033[1;33m--- Message Content ---\033[0m\n\n{res.get('text', 'Empty')}")
        print("\n\033[1;31mPress any key to go back...\033[0m")
        self.get_key()

    def delete_msg(self, msg_id):
        h = {"Authorization": f"Bearer {self.token}"}
        requests.delete(f"{API_URL}/messages/{msg_id}", headers=h)
        self.fetch()

    def draw(self):
        os.system('clear')
        print(f"\033[1;44m  GiveYouAMail CLI  \033[0m\nADDR: {self.email}\n" + "-"*50)
        if not self.messages: print("\n      Empty Inbox...")
        for i, m in enumerate(self.messages):
            sel = (i == self.selected)
            pre = "\033[1;37m>\033[0m " if sel else "  "
            line = f"{pre}{m['from']['address'][:20]:<20} | {m['subject'][:20]}"
            if sel:
                o = "\033[1;42m OPEN \033[0m" if self.action_idx==0 else " OPEN "
                d = "\033[1;41m DEL \033[0m" if self.action_idx==1 else " DEL "
                line += f"  {o} {d}"
            print(line)
        print("-"*50 + "\n[ARROWS] Nav | [ENTER] Exec | [Q] Quit")

    def get_key(self):
        fd = sys.stdin.fileno()
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = sys.stdin.read(1)
            if ch == '\x1b': return ch + sys.stdin.read(2)
            return ch
        finally: termios.tcsetattr(fd, termios.TCSADRAIN, old)

    def run(self):
        self.fetch()
        while self.running:
            self.draw()
            k = self.get_key()
            if k == 'q': self.running = False
            elif k == '\x1b[A' and self.selected > 0: self.selected -= 1
            elif k == '\x1b[B' and self.selected < len(self.messages)-1: self.selected += 1
            elif k == '\x1b[D': self.action_idx = 0
            elif k == '\x1b[C': self.action_idx = 1
            elif k == '\r' and self.messages:
                mid = self.messages[self.selected]['id']
                if self.action_idx == 0: self.read_msg(mid)
                else: self.delete_msg(mid)

def main():
    raw = " ".join(sys.argv)
    if "-Login" in raw:
        try:
            # Regex sagrado: busca o que está entre aspas ou logo após o prefixo
            m_mail = re.search(r'M:\s*"?([^"\s]+)"?', raw)
            m_pswd = re.search(r'pswd:\s*"?([^"\s]+)"?', raw)
            m_nome = re.search(r'nm\s*"?([^"]+)"?', raw)
            
            email, pswd, nome = m_mail.group(1), m_pswd.group(1), m_nome.group(1)
            
            requests.post(f"{API_URL}/accounts", json={"address": email, "password": pswd})
            with open("session.json", "w") as f:
                json.dump({"email": email, "password": pswd, "name": nome}, f)
            print(f"Session generated for {nome}.")
        except Exception as e:
            print(f"Syntax Error: {e}")
    
    elif "-oauth" in raw:
        if not os.path.exists("session.json"): return
        with open("session.json", "r") as f: s = json.load(f)
        res = requests.post(f"{API_URL}/token", json={"address": s['email'], "password": s['password']})
        if res.status_code == 200:
            TUI(s['email'], res.json()['token'], s['name']).run()
        else: print("Auth Error.")

if __name__ == "__main__":
    main()
