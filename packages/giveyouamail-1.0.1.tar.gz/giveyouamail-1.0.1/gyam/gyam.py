#!/usr/bin/env python
import requests, sys, re, json, os, curses

API = "https://api.mail.tm"

def read_msg(stdscr, token, msg_id):
    headers = {"Authorization": f"Bearer {token}"}
    res = requests.get(f"{API}/messages/{msg_id}", headers=headers).json()
    body = res.get('text', res.get('intro', 'Sem conteúdo'))
    
    while True:
        stdscr.clear()
        h, w = stdscr.getmaxyx()
        stdscr.attron(curses.color_pair(1))
        stdscr.addstr(1, 2, "╔" + "═"*(w-6) + "╗")
        stdscr.addstr(2, 2, f"║  CONTEÚDO DA MENSAGEM {' '*(w-29)}║")
        stdscr.addstr(3, 2, "╚" + "═"*(w-6) + "╝")
        stdscr.attroff(curses.color_pair(1))
        
        # Exibe o corpo do e-mail (quebra linha simples)
        lines = body.split('\n')
        for i, line in enumerate(lines[:h-10]):
            stdscr.addstr(5+i, 4, line[:w-8])
            
        stdscr.attron(curses.color_pair(3))
        stdscr.addstr(h-2, 2, " [ESC/B] VOLTAR ", curses.A_REVERSE)
        stdscr.attroff(curses.color_pair(3))
        
        stdscr.refresh()
        k = stdscr.getch()
        if k in [27, ord('b'), ord('B')]: break

def tui_original(stdscr, token, email):
    curses.start_color()
    curses.init_pair(1, curses.COLOR_CYAN, curses.COLOR_BLACK)
    curses.init_pair(2, curses.COLOR_WHITE, curses.COLOR_BLUE)
    curses.init_pair(3, curses.COLOR_GREEN, curses.COLOR_BLACK)
    curses.curs_set(0)
    idx = 0

    while True:
        stdscr.clear()
        h, w = stdscr.getmaxyx()

        stdscr.attron(curses.color_pair(1) | curses.A_BOLD)
        stdscr.addstr(1, 2, "╔" + "═"*(w-6) + "╗")
        stdscr.addstr(2, 2, f"║  GiveYouAMail CLI {' '*(w-25)}║")
        stdscr.addstr(3, 2, f"║  User: {email.ljust(w-16)} ║")
        stdscr.addstr(4, 2, "╚" + "═"*(w-6) + "╝")
        stdscr.attroff(curses.color_pair(1) | curses.A_BOLD)

        headers = {"Authorization": f"Bearer {token}"}
        try:
            r = requests.get(f"{API}/messages", headers=headers, timeout=5)
            items = r.json().get('hydra:member', [])
        except: items = []

        if not items:
            stdscr.addstr(h//2, w//2-9, ">> NO INCOMING <<", curses.A_BOLD)
        else:
            for i, m in enumerate(items[:h-10]):
                style = curses.color_pair(2) if i == idx else curses.A_NORMAL
                sender = m['from']['address'][:20].ljust(22)
                subj = m['subject'][:w-40].ljust(w-40)
                stdscr.addstr(6+i, 4, f" {sender} | {subj} ", style)

        stdscr.attron(curses.color_pair(3))
        stdscr.addstr(h-2, 2, " [Q] QUIT  [R] REFRESH  [ENTER] OPEN ", curses.A_REVERSE)
        stdscr.attroff(curses.color_pair(3))

        stdscr.refresh()
        k = stdscr.getch()
        
        if k in [ord('q'), ord('Q'), 27]: break
        elif k == curses.KEY_UP and idx > 0: idx -= 1
        elif k == curses.KEY_DOWN and idx < len(items)-1: idx += 1
        elif k in [10, 13]: # ENTER
            if items:
                read_msg(stdscr, token, items[idx]['id'])
        elif k in [ord('r'), ord('R')]: idx = 0

def main():
    raw = " ".join(sys.argv)
    m_mail = re.search(r'M:[\s"]*([^\s"]+)', raw)
    m_pswd = re.search(r'pswd:[\s"]*([^\s"]+)', raw)

    if "-Login" in raw:
        if not m_pswd: return
        try:
            doms = requests.get(f"{API}/domains").json()['hydra:member']
            target_dom = doms[0]['domain']
        except: target_dom = "moakt.cc"
        email = m_mail.group(1) if m_mail else f"user_{os.urandom(2).hex()}@{target_dom}"
        pswd = m_pswd.group(1)
        res = requests.post(f"{API}/accounts", json={"address": email, "password": pswd})
        if res.status_code in [201, 200, 422]:
            with open("session.json", "w") as f:
                json.dump({"email": email, "password": pswd}, f)
            print(f"Sessão Criada: {email}")
        return

    if "-oauth" in raw:
        if not os.path.exists("session.json"): return
        with open("session.json", "r") as f:
            s = json.load(f); email, pswd = s['email'], s['password']
        res = requests.post(f"{API}/token", json={"address": email, "password": pswd})
        if res.status_code == 200:
            curses.wrapper(tui_original, res.json()['token'], email)

if __name__ == "__main__":
    main()
