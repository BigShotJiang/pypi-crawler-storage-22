from setuptools import setup, find_packages

setup(
    name='GiveYouAMail',
    version='1.0.1',
    packages=find_packages(),
    install_requires=['requests'],
    entry_points={
        'console_scripts': [
            'GYAM=gyam.main_script:main'
        ]
    },
    author='MurilooPrDev',
    description='CLI Temporary Email Tool - GYAM Edition'
)
