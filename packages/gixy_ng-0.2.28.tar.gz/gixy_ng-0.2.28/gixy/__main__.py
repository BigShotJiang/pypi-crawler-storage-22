"""Used to run the CLI package as a module."""

from gixy.cli import main

main.main()
