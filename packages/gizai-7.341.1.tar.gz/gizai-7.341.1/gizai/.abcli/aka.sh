#! /usr/bin/env bash

function gizai() {
    giza "$@"
}
