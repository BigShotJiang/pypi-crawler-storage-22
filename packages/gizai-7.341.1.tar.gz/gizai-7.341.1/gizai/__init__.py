NAME = "gizai"

ICON = "🔻"

DESCRIPTION = (
    f"{ICON} Access, Automation, Analytics, AI - A Mathematical model for AI languages."
)

VERSION = "7.341.1"

REPO_NAME = "giza"

MARQUEE = "https://github.com/kamangir/giza/raw/main/assets/giza.png"

ALIAS = "giza"
