"""Gjalla Pre-commit Analysis CLI."""

__version__ = "1.0.0"
