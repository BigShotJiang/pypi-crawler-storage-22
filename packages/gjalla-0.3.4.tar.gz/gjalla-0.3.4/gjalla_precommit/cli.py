"""Main CLI entry point."""

import click

from .commands import init, status, sync, auth, mcp, setup, check


@click.group()
@click.version_option(version="0.2.0", prog_name="gjalla")
def main():
    """Gjalla — architecture guardrails for AI coding agents."""
    pass


main.add_command(init.init)
main.add_command(status.status)
main.add_command(sync.sync)
main.add_command(auth.auth)
main.add_command(mcp.mcp)
main.add_command(setup.setup)
main.add_command(check.check)


if __name__ == "__main__":
    main()
