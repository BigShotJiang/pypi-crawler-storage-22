"""Output formatting and display."""

from typing import Any

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.syntax import Syntax
from rich.markdown import Markdown


console = Console()


def success(message: str) -> None:
    """Display success message."""
    console.print(f"[green]✓[/green] {message}")


def error(message: str) -> None:
    """Display error message."""
    console.print(f"[red]✗[/red] {message}")


def warning(message: str) -> None:
    """Display warning message."""
    console.print(f"[yellow]![/yellow] {message}")


def info(message: str) -> None:
    """Display info message."""
    console.print(f"[blue]i[/blue] {message}")


def panel(content: str, title: str | None = None) -> None:
    """Display content in a panel."""
    console.print(Panel(content, title=title))


def code(content: str, language: str = "python") -> None:
    """Display syntax-highlighted code."""
    syntax = Syntax(content, language, theme="monokai", line_numbers=True)
    console.print(syntax)


def table(data: list[dict[str, Any]], title: str | None = None) -> None:
    """Display data as a table."""
    if not data:
        return

    t = Table(title=title)
    for key in data[0].keys():
        t.add_column(key)

    for row in data:
        t.add_row(*[str(v) for v in row.values()])

    console.print(t)


def markdown(content: str) -> None:
    """Display markdown content."""
    console.print(Markdown(content))
