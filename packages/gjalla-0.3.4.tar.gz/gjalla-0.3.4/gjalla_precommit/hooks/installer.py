"""Install gjalla pre-commit and post-commit hooks."""

from dataclasses import dataclass
from enum import Enum
from pathlib import Path


class InstallStatus(Enum):
    INSTALLED = "installed"
    ALREADY_EXISTS = "already_exists"
    ADDED_TO_EXISTING = "added_to_existing"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass
class HookInstallResult:
    status: InstallStatus
    message: str
    hook_path: Path | None = None


@dataclass
class HooksInstallResult:
    pre_commit: HookInstallResult
    post_commit: HookInstallResult


GJALLA_MARKER = "# gjalla-precommit-hook"
GJALLA_POST_COMMIT_MARKER = "# gjalla-post-commit-hook"


def is_gjalla_installed(repo_path: Path) -> bool:
    """Check if gjalla hook is already installed."""
    hook_path = repo_path / ".git" / "hooks" / "pre-commit"
    if not hook_path.exists():
        return False
    try:
        content = hook_path.read_text()
        return GJALLA_MARKER in content or "gjalla-precommit" in content
    except OSError:
        return False


def install_hook(repo_path: Path, command: str = "") -> HookInstallResult:
    """Install gjalla pre-commit hook.

    If a hook already exists, prepends gjalla to it without overwriting.
    """
    hooks_dir = repo_path / ".git" / "hooks"
    hook_path = hooks_dir / "pre-commit"

    if not hooks_dir.exists():
        return HookInstallResult(
            status=InstallStatus.FAILED,
            message="Not a git repository (no .git/hooks directory)",
        )

    if not command:
        return HookInstallResult(
            status=InstallStatus.SKIPPED,
            message="No hook command specified",
        )

    # Ensure the command propagates its exit code so a failing check
    # actually blocks the commit (the hook shell may not have set -e).
    guarded_command = f"{command} || exit $?" if "exit" not in command else command

    if hook_path.exists():
        try:
            existing = hook_path.read_text()

            if GJALLA_MARKER in existing:
                return HookInstallResult(
                    status=InstallStatus.ALREADY_EXISTS,
                    message="Gjalla hook already installed",
                    hook_path=hook_path,
                )

            lines = existing.split("\n")
            insert_idx = 0
            for i, line in enumerate(lines):
                if line.startswith("#!"):
                    insert_idx = i + 1
                elif line.startswith("#") or line.strip() == "":
                    insert_idx = i + 1
                else:
                    break

            lines.insert(insert_idx, "")
            lines.insert(insert_idx + 1, GJALLA_MARKER)
            lines.insert(insert_idx + 2, guarded_command)
            lines.insert(insert_idx + 3, "")

            hook_path.write_text("\n".join(lines))
            hook_path.chmod(0o755)

            return HookInstallResult(
                status=InstallStatus.ADDED_TO_EXISTING,
                message="Added gjalla to existing pre-commit hook",
                hook_path=hook_path,
            )
        except OSError as e:
            return HookInstallResult(
                status=InstallStatus.FAILED,
                message=f"Failed to modify hook: {e}",
            )
    else:
        hook_content = f"#!/bin/sh\n{GJALLA_MARKER}\n{guarded_command}\n"
        try:
            hook_path.write_text(hook_content)
            hook_path.chmod(0o755)
            return HookInstallResult(
                status=InstallStatus.INSTALLED,
                message="Installed git pre-commit hook",
                hook_path=hook_path,
            )
        except OSError as e:
            return HookInstallResult(
                status=InstallStatus.FAILED,
                message=f"Failed to create hook: {e}",
            )


def install_post_commit_hook(repo_path: Path, command: str = "") -> HookInstallResult:
    """Install gjalla post-commit hook.

    If a hook already exists, appends gjalla to it without overwriting.
    """
    hooks_dir = repo_path / ".git" / "hooks"
    hook_path = hooks_dir / "post-commit"

    if not hooks_dir.exists():
        return HookInstallResult(
            status=InstallStatus.FAILED,
            message="Not a git repository (no .git/hooks directory)",
        )

    if not command:
        return HookInstallResult(
            status=InstallStatus.SKIPPED,
            message="No hook command specified",
        )

    if hook_path.exists():
        try:
            existing = hook_path.read_text()

            if GJALLA_POST_COMMIT_MARKER in existing:
                return HookInstallResult(
                    status=InstallStatus.ALREADY_EXISTS,
                    message="Gjalla post-commit hook already installed",
                    hook_path=hook_path,
                )

            new_content = existing.rstrip() + f"\n\n{GJALLA_POST_COMMIT_MARKER}\n{command}\n"
            hook_path.write_text(new_content)
            hook_path.chmod(0o755)

            return HookInstallResult(
                status=InstallStatus.ADDED_TO_EXISTING,
                message="Added gjalla to existing post-commit hook",
                hook_path=hook_path,
            )
        except OSError as e:
            return HookInstallResult(
                status=InstallStatus.FAILED,
                message=f"Failed to modify hook: {e}",
            )
    else:
        hook_content = f"#!/bin/sh\n{GJALLA_POST_COMMIT_MARKER}\n{command}\n"
        try:
            hook_path.write_text(hook_content)
            hook_path.chmod(0o755)
            return HookInstallResult(
                status=InstallStatus.INSTALLED,
                message="Installed git post-commit hook",
                hook_path=hook_path,
            )
        except OSError as e:
            return HookInstallResult(
                status=InstallStatus.FAILED,
                message=f"Failed to create hook: {e}",
            )


def install_hooks(
    repo_path: Path,
    pre_commit_command: str = "",
    post_commit_command: str = "",
) -> HooksInstallResult:
    """Install both pre-commit and post-commit hooks."""
    pre_commit_result = install_hook(repo_path, command=pre_commit_command)
    post_commit_result = install_post_commit_hook(repo_path, command=post_commit_command)

    return HooksInstallResult(
        pre_commit=pre_commit_result,
        post_commit=post_commit_result,
    )
