import importlib

import pytest


git_tools = importlib.import_module("gjalla_precommit.tools.git_tools")
settings = importlib.import_module("gjalla_precommit.config.settings")


def test_trailer_format():
    trailer = git_tools.format_receipt_trailer("gj:abc123")
    assert trailer == "Gjalla-Receipt: gj:abc123"


def test_trailer_vs_notes_config(home_dir):
    config = {"receipt_method": "trailer"}
    settings.save_config(config)
    loaded = settings.load_config()
    assert settings.get_receipt_method(loaded) == "trailer"


def test_trailer_preserves_existing():
    message = "Fix bug\n\nSigned-off-by: Test User\n"
    updated = git_tools.append_receipt_trailer(message, "gj:abc123")
    assert "Signed-off-by: Test User" in updated
    assert "Gjalla-Receipt: gj:abc123" in updated


def test_trailer_no_duplicates():
    message = "Update\n\nGjalla-Receipt: gj:abc123\n"
    updated = git_tools.append_receipt_trailer(message, "gj:abc123")
    assert updated.count("Gjalla-Receipt: gj:abc123") == 1


def test_notes_is_default(home_dir):
    settings.save_config({"api_key": "gj_live_test"})
    loaded = settings.load_config()
    assert settings.get_receipt_method(loaded) == "notes"
