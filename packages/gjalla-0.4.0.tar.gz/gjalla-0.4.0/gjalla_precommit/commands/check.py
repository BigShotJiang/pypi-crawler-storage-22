"""Validate commit attestation."""

import json
import os
import sys
from pathlib import Path

import click

from ..display.output import console, success, error, info
from ._shared import get_repo_root as _get_repo_root, get_staged_diff_hash as _get_staged_diff_hash


def _parse_attestation(path: Path) -> dict[str, str]:
    """Parse key-value pairs from attestation file."""
    content = path.read_text()
    result = {}
    for line in content.splitlines():
        line = line.strip()
        if ":" in line and not line.startswith("#") and not line.startswith("---"):
            key, _, value = line.partition(":")
            key = key.strip().replace(" ", "_")
            value = value.strip().strip("\"'")
            if key and value:
                result[key] = value
    return result


@click.command()
def check() -> None:
    """Validate commit attestation.

    Checks that .commit-attestation.md exists and its staged_diff_hash
    matches the current staged changes. Used by the pre-commit hook,
    also usable standalone.

    \b
    Exit codes:
        0 - Attestation valid (or no .gjalla config)
        1 - Attestation missing or stale
    """
    repo_root = _get_repo_root()

    # No .gjalla config = not a guardrails project, pass through
    gjalla_config = repo_root / ".gjalla" / "config.json"
    if not gjalla_config.exists():
        # Also check old format (.gjalla as a file)
        old_config = repo_root / ".gjalla"
        if not old_config.is_file():
            return
        gjalla_config = old_config

    # Skip if env var set
    if os.environ.get("SKIP_ATTESTATION") == "1":
        info("Attestation skipped (SKIP_ATTESTATION=1)")
        return

    attestation_path = repo_root / ".commit-attestation.md"
    if not attestation_path.exists():
        try:
            config = json.loads(gjalla_config.read_text())
            project_id = config.get("project_id", "unknown")
            api_url = config.get("api_url", "https://gjalla.io")
        except (json.JSONDecodeError, OSError):
            project_id = "unknown"
            api_url = "https://gjalla.io"

        diff_hash = _get_staged_diff_hash()
        console.print()
        console.print("[bold red]gjalla: Attestation Required[/bold red]")
        console.print()
        console.print(f"  staged_diff_hash: {diff_hash}")
        console.print()
        console.print("  Create your attestation:")
        console.print("    gjalla attest --staged-diff-hash <hash> --agent <name> \\")
        console.print("      --provider <provider> --model <model> --summary \"...\"")
        console.print()
        console.print("  Run [bold]gjalla attest --help[/bold] for full options and")
        console.print("  guidance on where to find rules and architecture context.")
        console.print()
        # Only show skip hint to humans — agents should always attest
        _agent_env_vars = ("CLAUDE_CODE", "CURSOR_SESSION_ID", "AIDER_MODEL", "CODEX_ENV")
        if sys.stdin.isatty() and not any(os.environ.get(v) for v in _agent_env_vars):
            console.print("  Human? Skip: SKIP_ATTESTATION=1 git commit ...")
            console.print()
        raise SystemExit(1)

    # Validate diff hash
    fields = _parse_attestation(attestation_path)
    attested_hash = fields.get("staged_diff_hash", "")
    current_hash = _get_staged_diff_hash()

    if attested_hash != current_hash:
        error("Attestation stale — staged changes differ from attested hash")
        console.print(f"  Expected: {attested_hash[:16]}...")
        console.print(f"  Current:  {current_hash[:16]}...")
        raise SystemExit(1)

    success("Attestation verified")
