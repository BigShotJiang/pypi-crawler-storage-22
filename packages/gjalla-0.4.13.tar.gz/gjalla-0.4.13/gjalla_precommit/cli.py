"""Main CLI entry point."""

import click

from . import __version__
from .commands import init, status, sync, auth, mcp, setup, check, attest, connect
from . import telemetry


@click.group()
@click.version_option(version=__version__, prog_name="gjalla")
@click.pass_context
def main(ctx):
    """Gjalla — architecture guardrails for AI coding agents."""
    ctx.ensure_object(dict)
    if not ctx.resilient_parsing:
        telemetry.check_consent()


@main.result_callback()
@click.pass_context
def _track(ctx, *_args, **_kwargs):
    telemetry.track(ctx.info_name if ctx.invoked_subcommand is None else ctx.invoked_subcommand)


main.add_command(init.init)
main.add_command(status.status)
main.add_command(sync.sync)
main.add_command(auth.auth)
main.add_command(mcp.mcp)
main.add_command(setup.setup)
main.add_command(check.check)
main.add_command(attest.attest)
main.add_command(connect.connect)


if __name__ == "__main__":
    main()
