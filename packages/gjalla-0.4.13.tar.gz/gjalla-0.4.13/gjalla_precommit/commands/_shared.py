"""Shared git helpers used across CLI commands."""

import hashlib
import subprocess
from pathlib import Path

import click


def get_repo_root() -> Path:
    """Find git repository root from current directory."""
    cwd = Path.cwd()
    for parent in [cwd, *cwd.parents]:
        if (parent / ".git").exists():
            return parent
    raise click.ClickException("Not in a git repository")


def get_staged_diff_hash() -> str:
    """Get SHA-256 hash of staged changes."""
    result = subprocess.run(
        ["git", "diff", "--staged"],
        capture_output=True,
        text=True,
    )
    return hashlib.sha256(result.stdout.encode()).hexdigest()


def get_git_user_name() -> str:
    """Get git user.name, falling back to 'unknown'."""
    result = subprocess.run(
        ["git", "config", "user.name"],
        capture_output=True,
        text=True,
    )
    return result.stdout.strip() or "unknown"
