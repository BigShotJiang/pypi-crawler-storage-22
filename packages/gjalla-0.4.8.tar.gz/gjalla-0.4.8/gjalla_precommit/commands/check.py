"""Validate commit attestation."""

import json
import os
import sys
from pathlib import Path

import click
import yaml

from ..display.output import console, success, error, info
from ..hooks.agent_detection import AGENT_ENV_VARS
from ._shared import get_repo_root as _get_repo_root, get_staged_diff_hash as _get_staged_diff_hash


def _parse_attestation(path: Path) -> dict[str, str]:
    """Parse attestation file using YAML safe_load."""
    content = path.read_text()
    # Strip YAML front-matter delimiters if present
    content = content.strip()
    if content.startswith("---"):
        content = content[3:]
    if content.endswith("---"):
        content = content[:-3]
    try:
        # Use BaseLoader to keep all values as raw strings (no auto-conversion
        # of timestamps, booleans, etc.) — we only need string comparisons.
        data = yaml.load(content, Loader=yaml.BaseLoader)  # noqa: S506
        if not isinstance(data, dict):
            return {}
        result: dict[str, str] = {}
        for k, v in data.items():
            if not v:
                continue
            # Normalize keys: replace spaces with underscores (backward compat)
            key = str(k).replace(" ", "_")
            result[key] = str(v)
        return result
    except yaml.YAMLError:
        return {}


@click.command()
def check() -> None:
    """Validate commit attestation.

    Checks that .commit-attestation.md exists and its staged_diff_hash
    matches the current staged changes. Used by the pre-commit hook,
    also usable standalone.

    \b
    Exit codes:
        0 - Attestation valid (or no .gjalla config)
        1 - Attestation missing or stale
    """
    repo_root = _get_repo_root()

    # No .gjalla config = not a guardrails project, pass through
    gjalla_config = repo_root / ".gjalla" / "config.json"
    if not gjalla_config.exists():
        # Also check old format (.gjalla as a file)
        old_config = repo_root / ".gjalla"
        if not old_config.is_file():
            return
        gjalla_config = old_config

    # Skip if env var set — but log it for audit trail
    if os.environ.get("SKIP_ATTESTATION") == "1":
        info("Attestation skipped (SKIP_ATTESTATION=1)")
        try:
            import subprocess
            import datetime
            branch = subprocess.run(
                ["git", "rev-parse", "--abbrev-ref", "HEAD"],
                capture_output=True, text=True, cwd=str(repo_root),
            ).stdout.strip() or "unknown"
            log_path = repo_root / ".gjallalog"
            (repo_root / ".gjalla" / "attestations").mkdir(parents=True, exist_ok=True)
            entry = json.dumps({
                "event": "attestation_skipped",
                "branch": branch,
                "timestamp": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
                "synced": False,
            })
            with open(log_path, "a") as f:
                f.write(entry + "\n")
        except Exception:
            pass  # audit logging is best-effort
        return

    attestation_path = repo_root / ".commit-attestation.md"
    if not attestation_path.exists():
        try:
            config = json.loads(gjalla_config.read_text())
            project_id = config.get("project_id", "unknown")
            api_url = config.get("api_url", "https://gjalla.io")
        except (json.JSONDecodeError, OSError):
            project_id = "unknown"
            api_url = "https://gjalla.io"

        diff_hash = _get_staged_diff_hash()
        is_agent = any(os.environ.get(v) for v in AGENT_ENV_VARS)

        console.print()
        console.print("[bold red]gjalla: Attestation Required[/bold red]")
        console.print()

        if is_agent:
            console.print("  YOU must create the attestation before committing. Run:")
            console.print()
            console.print(f"    gjalla attest --staged-diff-hash {diff_hash} \\", markup=False, highlight=False)
            console.print("      --agent <your-name> --provider <provider> \\")
            console.print("      --model <model> --summary \"...\"")
            console.print()
            console.print("  Then retry your git commit.")
            console.print()
        else:
            console.print(f"  staged_diff_hash: {diff_hash}", markup=False, highlight=False)
            console.print()
            console.print("  Create your attestation:")
            console.print("    gjalla attest --staged-diff-hash <hash> --agent <name> \\")
            console.print("      --provider <provider> --model <model> --summary \"...\"")
            console.print()
            console.print("  Run [bold]gjalla attest --help[/bold] for full options and")
            console.print("  guidance on where to find rules and architecture context.")
            console.print()
            if sys.stdin.isatty():
                console.print("  Human? Skip: SKIP_ATTESTATION=1 git commit ...")
                console.print()
        raise SystemExit(1)

    # Validate diff hash
    fields = _parse_attestation(attestation_path)
    attested_hash = fields.get("staged_diff_hash", "")
    current_hash = _get_staged_diff_hash()

    if attested_hash != current_hash:
        error("Attestation stale — staged changes differ from attested hash")
        console.print(f"  Expected: {attested_hash[:16]}...")
        console.print(f"  Current:  {current_hash[:16]}...")
        raise SystemExit(1)

    success("Attestation verified")
