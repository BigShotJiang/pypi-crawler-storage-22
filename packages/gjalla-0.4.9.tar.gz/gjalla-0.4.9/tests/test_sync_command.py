"""Tests for the sync command."""

import importlib
import json
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest
from click.testing import CliRunner

sync_module = importlib.import_module("gjalla_precommit.commands.sync")
cli_module = importlib.import_module("gjalla_precommit.cli")
settings_module = importlib.import_module("gjalla_precommit.config.settings")


class TestSyncCommand:
    """Tests for gjalla sync command."""

    def test_sync_command_exists(self):
        """Sync command should be registered."""
        main = cli_module.main
        assert "sync" in main.commands

    def test_sync_not_in_git_repo(self, tmp_path, monkeypatch):
        """Sync should fail when not in a git repo."""
        monkeypatch.chdir(tmp_path)
        runner = CliRunner()
        result = runner.invoke(cli_module.main, ["sync"])
        assert result.exit_code != 0
        assert "Not in a git repository" in result.output or "git repository" in result.output.lower()

    def test_sync_no_api_key(self, temp_repo, home_dir, monkeypatch):
        """Sync should fail when API key is not configured."""
        monkeypatch.chdir(temp_repo)
        monkeypatch.delenv("GJALLA_API_KEY", raising=False)
        runner = CliRunner()
        result = runner.invoke(cli_module.main, ["sync"])
        assert result.exit_code != 0
        assert "API key" in result.output or "not configured" in result.output.lower()

    def test_sync_no_gjalla_config_skips_gracefully(self, temp_repo, home_dir, monkeypatch):
        """Sync should succeed with info message when no .gjalla config exists."""
        monkeypatch.chdir(temp_repo)
        # Set API key but no .gjalla project config
        config_dir = home_dir / ".gjalla"
        config_dir.mkdir(parents=True, exist_ok=True)
        (config_dir / "config.yaml").write_text("api_key: gj_test_key\n")

        runner = CliRunner()
        result = runner.invoke(cli_module.main, ["sync"])
        assert result.exit_code == 0
        assert "No .gjalla config" in result.output or "skipping" in result.output.lower()

    def test_sync_help_flag(self):
        """Sync --help should show help text."""
        runner = CliRunner()
        result = runner.invoke(cli_module.main, ["sync", "--help"])
        assert result.exit_code == 0
        assert "attestation" in result.output.lower() or "upload" in result.output.lower()


class TestGetRepoRoot:
    """Tests for _get_repo_root helper."""

    def test_get_repo_root_finds_git_dir(self, temp_repo, monkeypatch):
        """Should find .git directory in current or parent dirs."""
        # Create a subdirectory
        subdir = temp_repo / "src" / "nested"
        subdir.mkdir(parents=True)
        monkeypatch.chdir(subdir)

        # Should still find repo root
        root = sync_module.get_repo_root()
        assert root == temp_repo

    def test_get_repo_root_raises_not_in_repo(self, tmp_path, monkeypatch):
        """Should raise ClickException when not in a repo."""
        monkeypatch.chdir(tmp_path)
        import click
        with pytest.raises(click.ClickException, match="Not in a git repository"):
            sync_module.get_repo_root()
