"""GL Connector SDK Models."""
