from _typeshed import Incomplete
from gl_observability.traces.backend.opentelemetry import OpenTelemetryBackendConfig as OpenTelemetryBackendConfig, init_otel_with_external_exporter as init_otel_with_external_exporter
from gl_observability.traces.backend.sentry import SentryBackendConfig as SentryBackendConfig, init_sentry as init_sentry
from gl_observability.traces.config import FastAPIConfig as FastAPIConfig, OpenTelemetryTraceConfig as OpenTelemetryTraceConfig, auto_initialize_services as auto_initialize_services, setup_tracer_provider as setup_tracer_provider
from opentelemetry.sdk.trace.sampling import Sampler

class TelemetryConfig:
    """Configuration for telemetry initialization.

    All instrumentation is done via OpenTelemetry.
    """
    trace_sampler: Incomplete
    attributes: Incomplete
    fastapi_config: Incomplete
    use_langchain: Incomplete
    use_httpx: Incomplete
    use_requests: Incomplete
    log_trace_context: Incomplete
    backend_config: Incomplete
    def __init__(self, *, attributes: dict[str, str] | None = None, trace_sampler: Sampler | None = None, fastapi_config: FastAPIConfig | None = None, use_langchain: bool = False, use_httpx: bool = True, use_requests: bool = True, log_trace_context: bool = True, backend_config: OpenTelemetryBackendConfig | SentryBackendConfig | None = None) -> None:
        """Initialize the telemetry configuration.

        Args:
            attributes (dict[str, str] | None, optional): Resource attributes. Defaults to None.
            trace_sampler (Sampler | None, optional): The sampler for traces. Defaults to None.
            fastapi_config (FastAPIConfig | None, optional): FastAPI configuration for instrumentation.
                Defaults to None.
            use_langchain (bool, optional): Enable Langchain instrumentation. Defaults to False.
            use_httpx (bool, optional): Enable HTTPX instrumentation. Defaults to True.
            use_requests (bool, optional): Enable Requests instrumentation. Defaults to True.
            log_trace_context (bool, optional): Add trace context to logs. You have to set the formatter to
                include the trace context. Defaults to True.
            backend_config (OpenTelemetryBackendConfig | SentryBackendConfig | None, optional): The telemetry
                backend configuration. Defaults to None. Make sure to set at least one backend configuration,
                if not traces will not be exported.
        """

def init_telemetry(config: TelemetryConfig) -> None:
    '''Initialize telemetry for tracing.

    This function initializes OpenTelemetry instrumentation with the specified backend.
    All tracing is done via OpenTelemetry regardless of the backend.

    Supported backends:
    - OTLP: Export traces to an OTLP endpoint (Jaeger, Tempo, etc.)
    - Sentry: Export traces to Sentry using OpenTelemetry

    Examples:
        Basic OTLP setup:
        >>> from gl_observability import TelemetryConfig, init_telemetry, OpenTelemetryBackendConfig
        >>>
        >>> config = TelemetryConfig(
        ...     attributes={"service.name": "my-service"},
        ...     backend_config=OpenTelemetryBackendConfig(endpoint="localhost:4317")
        ... )
        >>> init_telemetry(config)

        Sentry setup:
        >>> from gl_observability import TelemetryConfig, init_telemetry, SentryBackendConfig
        >>>
        >>> config = TelemetryConfig(
        ...     attributes={"service.name": "my-service"},
        ...     backend_config=SentryBackendConfig(dsn="https://...")
        ... )
        >>> init_telemetry(config)

    Args:
        config (TelemetryConfig): The telemetry configuration.
    '''
