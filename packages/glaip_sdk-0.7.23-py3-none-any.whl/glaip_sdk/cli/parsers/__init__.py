"""CLI input parsers.

Authors:
    Putu Ravindra Wiguna (putu.r.wiguna@gdplabs.id)
"""

__all__: list[str] = []
