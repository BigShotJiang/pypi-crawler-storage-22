"""
Glass AI Python SDK - OpenTelemetry tracing for AI applications.
"""

from .init import init
from .trace import trace
from .interaction import interaction
from .task_span import task_span

__version__ = "0.1.0"

__all__ = [
    "init",
    "trace",
    "interaction",
    "task_span",
    "__version__",
]

