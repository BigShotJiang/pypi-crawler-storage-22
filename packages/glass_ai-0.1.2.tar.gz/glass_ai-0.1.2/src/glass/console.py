import os
import json
import logging
from typing import Any, Dict, List, Tuple, Union, Optional, cast

from rich.tree import Tree
from rich.panel import Panel
from rich.table import Table
from rich.syntax import Syntax
from rich.console import Console, RenderableType
from rich.spinner import Spinner
from rich.markdown import Markdown
from rich.progress import (
    Progress,
    BarColumn,
    TextColumn,
    SpinnerColumn,
    MofNCompleteColumn,
    TimeRemainingColumn,
)

logger = logging.getLogger("glass")

# Global flag to ensure the OpenTelemetry configuration warning is issued only once per session
_otel_config_warning_issued = False

# Default spinner style for Glass operations
DEFAULT_SPINNER = "dots"

class GlassConsole:
    """Centralized console management for Glass with rich formatting capabilities."""

    _instance: Optional["GlassConsole"] = None
    _console: Console

    def __new__(cls) -> "GlassConsole":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._console = Console(stderr=True, highlight=True)
        return cls._instance

    @property
    def console(self) -> Console:
        return self._console

    def print(self, *args: Any, **kwargs: Any) -> None:
        """Print with rich formatting."""
        self._console.print(*args, **kwargs)

    def log(self, message: str, style: Optional[str] = None) -> None:
        """Print a log message with optional styling."""
        if style:
            self._console.print(f"[{style}]{message}[/{style}]")
        else:
            self._console.print(message)

    def success(self, message: str) -> None:
        """Print a success message."""
        self._console.print(f"[green]✓[/green] {message}")

    def error(self, message: str) -> None:
        """Print an error message."""
        self._console.print(f"[red]✗[/red] {message}")

    def warning(self, message: str) -> None:
        """Print a warning message."""
        self._console.print(f"[yellow]⚠[/yellow] {message}")

    def info(self, message: str) -> None:
        """Print an info message."""
        self._console.print(f"[blue]ℹ[/blue] {message}")

    def step_progress(self, text: str = "") -> Spinner:
        """Create a spinner for step progress."""
        return Spinner(DEFAULT_SPINNER, text, style="blue")

    def step_completed(self, message: str) -> RenderableType:
        """Return a renderable for completed step."""
        return f"[green]✓[/green] {message}"

    def create_panel(
        self, content: Union[str, RenderableType], title: Optional[str] = None, border_style: str = "blue"
    ) -> Panel:
        """Create a styled panel."""
        return Panel(content, title=title, border_style=border_style, title_align="left")

    def create_table(self, title: Optional[str] = None, **kwargs: Any) -> Table:
        """Create a styled table."""
        return Table(title=title, show_header=True, header_style="bold magenta", **kwargs)

    def create_progress_bar(self) -> Progress:
        """Create a styled progress bar."""
        return Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            MofNCompleteColumn(),
            TimeRemainingColumn(),
            console=self._console,
            transient=True,
        )

    def create_tree(self, label: RenderableType, guide_style: str = "gray50") -> Tree:
        """Create a tree structure for hierarchical display."""
        return Tree(label, guide_style=guide_style)

    def display_dict(self, data: Dict[str, Any], title: Optional[str] = None) -> None:
        """Display a dictionary in a formatted table."""
        table = self.create_table(title=title)
        table.add_column("Key", style="cyan", no_wrap=True)
        table.add_column("Value", style="white")

        for key, value in data.items():
            table.add_row(str(key), str(value))

        self._console.print(table)

    def display_list(self, items: List[Any], title: Optional[str] = None, columns: Optional[List[str]] = None) -> None:
        """Display a list in a formatted table."""
        if not items:
            self.info("No items to display")
            return

        table = self.create_table(title=title)

        if columns:
            for col in columns:
                table.add_column(col)
        else:
            table.add_column("Item")

        for item in items:
            if isinstance(item, (list, tuple)) and columns:
                # Cast item to sequence to help type checker
                elem_list = cast(Union[List[Any], Tuple[Any, ...]], item)
                table.add_row(*[str(elem) for elem in elem_list])
            else:
                # Cast to help type checker with the str() call
                table.add_row(str(cast(Any, item)))

        self._console.print(table)

    def code_block(self, code: str, language: str = "python", title: Optional[str] = None) -> None:
        """Display a syntax-highlighted code block."""
        syntax = Syntax(code, language, theme="monokai", line_numbers=True)
        if title:
            self._console.print(self.create_panel(syntax, title=title))
        else:
            self._console.print(syntax)

    def markdown(self, text: str) -> None:
        """Display markdown formatted text."""
        md = Markdown(text)
        self._console.print(md)


def get_console() -> GlassConsole:
    """Get the singleton GlassConsole instance."""
    return GlassConsole()


def pretty_print_json(data: Any, title: Optional[str] = None) -> None:
    """Pretty print JSON data with syntax highlighting."""
    console = get_console()
    json_str = json.dumps(data, indent=2)
    console.code_block(json_str, language="json", title=title)

def display_glass_warning(warning: Any) -> None:
    """Display a Glass warning with consistent formatting.

    Args:
        warning: The GlassWarning instance to display (from warnings module)
    """
    warning.display()

def pretty_print_error(error: Exception, show_traceback: bool = True) -> None:
    """Pretty print an error with optional traceback."""
    console = get_console()

    error_panel = Panel(
        str(error),
        title=f"[red]{type(error).__name__}[/red]",
        border_style="red",
        title_align="left",
    )
    console.console.print(error_panel)

    if show_traceback:
        import traceback

        tb = traceback.format_exc()
        console.code_block(tb, language="python", title="Traceback")




__all__ = [
    "GlassConsole",
    "get_console",
    "pretty_print_json",
    "pretty_print_error",
    "display_glass_warning",
]
