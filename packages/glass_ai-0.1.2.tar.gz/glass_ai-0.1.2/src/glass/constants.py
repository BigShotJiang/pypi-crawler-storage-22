# The ATTR_ prefix follows OpenTelemetry semantic convention naming
# from their packages.
ANONYMOUS_SPAN_NAME = "anonymous_function"

ATTR_GLASS_FN_ARGS_EVENT_NAME = "glass.fn.args"
ATTR_GLASS_FN_OUTPUT_EVENT_NAME = "glass.fn.output"

__all__ = [
    "ANONYMOUS_SPAN_NAME",
    "ATTR_GLASS_FN_ARGS_EVENT_NAME",
    "ATTR_GLASS_FN_OUTPUT_EVENT_NAME",
]
