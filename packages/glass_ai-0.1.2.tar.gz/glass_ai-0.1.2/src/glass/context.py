"""Shared context storage for Glass.

This module provides a ContextVar-based storage mechanism for sharing
metadata across traced functions and decorators. It works correctly
with both sync and async code.
"""

from contextvars import ContextVar, Token
from typing import Any, Dict

# Shared ContextVar for storing active metadata across async contexts
# This allows `interaction()`, `@trace`, and other decorators to share metadata
active_metadata: ContextVar[Dict[str, Any]] = ContextVar("active_metadata", default={})


def get_active_metadata() -> Dict[str, Any]:
    """Get the current active metadata from the ContextVar.

    Returns:
        A copy of the current metadata dictionary.
    """
    return active_metadata.get().copy()


def set_active_metadata(metadata: Dict[str, Any]) -> Token[Dict[str, Any]]:
    """Set the active metadata and return a token for restoration.

    Args:
        metadata: The metadata dictionary to set.

    Returns:
        A token that can be used with `reset_active_metadata()` to restore
        the previous state.
    """
    return active_metadata.set(metadata)


def reset_active_metadata(token: Token[Dict[str, Any]]) -> None:
    """Reset the active metadata to a previous state using a token.

    Args:
        token: The token returned from a previous `set_active_metadata()` call.
    """
    active_metadata.reset(token)


def merge_metadata(**kwargs: Any) -> tuple[Dict[str, Any], Token[Dict[str, Any]]]:
    """Merge new metadata with existing metadata and set it.

    New values take precedence over existing values.

    Args:
        **kwargs: Key-value pairs to merge into the existing metadata.

    Returns:
        A tuple of (merged_metadata, token) where token can be used to restore
        the previous state.
    """
    current = active_metadata.get()
    merged = {**current, **kwargs}
    token = active_metadata.set(merged)
    return merged, token


__all__ = [
    "active_metadata",
    "get_active_metadata",
    "set_active_metadata",
    "reset_active_metadata",
    "merge_metadata",
]


