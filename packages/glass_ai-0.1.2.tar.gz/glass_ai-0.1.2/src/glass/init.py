import traceback
from typing import Any, Dict, List, Optional
from datetime import datetime

from .utils import generate_config_diff
from .warnings import GlassWarnings
from .otel_setup import setup as _setup_otel


# Module-level variables to track initialization history
class InitCall:
    """Record of an init() call"""
    def __init__(self, timestamp: datetime, options: Dict[str, Any], call_number: int, stack_trace: Optional[str] = None):
        self.timestamp = timestamp
        self.options = options
        self.call_number = call_number
        self.stack_trace = stack_trace


_init_history: List[InitCall] = []
_init_call_count: int = 0


def _get_init_history() -> List[InitCall]:
    """Get the initialization history"""
    return _init_history


def _add_init_call(options: Dict[str, Any]) -> InitCall:
    """Record a new init call"""
    global _init_call_count
    _init_call_count += 1
    
    # Capture stack trace for debugging
    stack = None
    try:
        stack = ''.join(traceback.format_stack()[:-1])  # Exclude this function
    except Exception:
        pass
    
    init_call = InitCall(
        timestamp=datetime.now(),
        options=options,
        call_number=_init_call_count,
        stack_trace=stack
    )
    _init_history.append(init_call)
    return init_call


def init(
    *,
    api_key: Optional[str] = None,
    instrumentations: Optional[List[Any]] = None,
    skip_default_instrumentations: bool = False,
    debug: bool = False,
    **kwargs: Any,
) -> None:
    """
    Initializes the Glass SDK and configures OpenTelemetry by default.

    This function sets up OpenTelemetry tracing with automatic instrumentation
    for OpenAI, Anthropic (Claude), and Google (Gemini) by default.

    If `api_key` is not provided, the GLASS_API_KEY environment variable is used.

    All arguments must be passed as keyword arguments.

    Args:
        api_key (Optional[str]): The Glass API key.
            If None, GLASS_API_KEY environment variable is used.
        instrumentations (Optional[List[Any]]): Custom list of OpenTelemetry instrumentors.
            If None and skip_default_instrumentations is False, auto-instruments
            OpenAI, Anthropic, and Google Generative AI.
        skip_default_instrumentations (bool): If True, skips auto-instrumenting
            OpenAI, Anthropic, and Gemini. Defaults to False.
        debug (bool): If True, also logs traces to console. Defaults to False.
        **kwargs (Any): Additional keyword arguments for advanced configuration.

    Side Effects:
        - Configures OpenTelemetry with Glass exporter
        - Instruments AI/LLM libraries (unless skipped)

    Example:
        ```python
        from glass import init
        
        # Simple initialization - auto-instruments OpenAI, Claude, Gemini
        init(api_key="your-api-key")
        
        # With custom instrumentations only
        from openinference.instrumentation.openai import OpenAIInstrumentor
        init(
            api_key="your-api-key",
            instrumentations=[OpenAIInstrumentor()],
            skip_default_instrumentations=True
        )
        ```
    """
    # Build the complete options for comparison
    all_options: Dict[str, Any] = {}
    if api_key is not None:
        all_options["api_key"] = api_key
    all_options.update(kwargs)
    
    # Check initialization history
    init_history = _get_init_history()
    if init_history:
        # Compare with the most recent initialization
        previous_call = init_history[-1]
        diff_lines = generate_config_diff(previous_call.options, all_options)
        
        if diff_lines:
            # Only show warning if configuration actually changed
            warning = GlassWarnings.MultipleInitWarning(
                call_number=_init_call_count + 1,
                diff_lines=diff_lines,
                init_history=[{
                    'timestamp': call.timestamp,
                    'callNumber': call.call_number
                } for call in init_history]
            )
            warning.display()
    
    # Record this initialization
    _add_init_call(all_options)
    
    constructor_args: Dict[str, Any] = {}
    if api_key is not None:
        constructor_args["api_key"] = api_key

    constructor_args.update(kwargs)

    # Set a global flag to indicate that init() has been called
    import sys
    setattr(sys.modules["glass"], "__glass_initialized", True)
    
    # Configure OpenTelemetry with instrumentations
    _setup_otel(
        glass_api_key=api_key,
        instrumentations=instrumentations,
        skip_default_instrumentations=skip_default_instrumentations,
        debug=debug,
    )


__all__ = ["init", "_get_init_history", "_add_init_call"]
