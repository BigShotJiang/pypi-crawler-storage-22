from typing import Any, Dict, Optional

from opentelemetry import trace
from opentelemetry.trace import Span
from opentelemetry.trace.status import Status, StatusCode

from .context import reset_active_metadata, merge_metadata
from .utils import ensure_initialized, glass_format_otel_attributes, _glass_json_dumps

# Constants
INTERACTION_SPAN_NAME = "glass.interaction"
ATTR_GLASS_INTERACTION_OUTPUT_EVENT_NAME = "glass.interaction.final_output"


class Interaction:
    """
    A wrapper around an OpenTelemetry span that provides convenient methods
    for recording interaction outputs.
    """

    def __init__(self, span: Span) -> None:
        self._span = span

    def finish(self, output: Any) -> None:
        """
        Record output data for this interaction.

        Args:
            output: The output data to record. Will be JSON serialized.
        """
        serialized = _glass_json_dumps(output)
        self._span.add_event(ATTR_GLASS_INTERACTION_OUTPUT_EVENT_NAME, {"output": serialized})

    def set_attribute(self, key: str, value: Any) -> None:
        """
        Set an attribute on the span.

        Args:
            key: The attribute key.
            value: The attribute value.
        """
        self._span.set_attribute(key, value)

    def record_exception(self, exception: BaseException) -> None:
        """
        Record an exception on the span and set error status.

        Args:
            exception: The exception to record.
        """
        self._span.record_exception(exception)
        self._span.set_status(Status(StatusCode.ERROR, description=str(exception)))
        self._span.set_attribute("error.type", exception.__class__.__name__)

    @property
    def span(self) -> Span:
        """Access the underlying OpenTelemetry span."""
        return self._span


class interaction:
    """
    Context manager for setting metadata on spans.

    This class serves two purposes:
    1. If a current span exists (e.g., from @trace), it updates that span with the metadata
    2. If no span exists, it creates a root span with the metadata

    The metadata is also stored in a ContextVar so that nested @trace functions
    will inherit the metadata.

    Supports both synchronous and asynchronous usage:

    Sync usage:
        ```python
        with interaction(user_id="123", session_id="abc") as agent_interaction:
            result = do_work()
            agent_interaction.finish(output={"result": result})
        ```

    Async usage:
        ```python
        async with interaction(user_id="123") as agent_interaction:
            result = await do_async_work()
            agent_interaction.finish(output={"result": result})
        ```

    Args:
        **kwargs: Metadata key-value pairs to set on spans (e.g., user_id="123", session_id="abc")
    """

    def __init__(
        self,
        user_id: Optional[str] = None,
        input: Optional[str] = None,
        session_id: Optional[str] = None,
        service: Optional[str] = None,
        **kwargs: Any
    ) -> None:
        # Allow user_id, session_id, and service to be provided as explicit arguments,
        # and also allow them to be included in **kwargs (explicit args take precedence).
        if user_id is not None:
            kwargs["user_id"] = user_id
        if input is not None:
            kwargs["user_input"] = input
        if session_id is not None:
            kwargs["session_id"] = session_id
        if service is not None:
            kwargs["service"] = service
        self._kwargs = kwargs
        self._formatted_attributes: Dict[str, Any] = {}
        self._token: Any = None
        self._span_context: Any = None
        self._interaction: Optional[Interaction] = None
        self._owns_span: bool = False


    def _start(self) -> Interaction:
        """Start the interaction and return an Interaction wrapper."""
        ensure_initialized()

        # Merge new metadata with existing metadata (new takes precedence)
        # and get a token for restoration
        _, self._token = merge_metadata(**self._kwargs)

        # Format attributes for OpenTelemetry compatibility
        self._formatted_attributes = glass_format_otel_attributes(self._kwargs)

        # Check if there's a current span
        current_span = trace.get_current_span()

        if current_span.is_recording():
            # Update the existing span with the new metadata
            for key, value in self._formatted_attributes.items():
                current_span.set_attribute(key, value)
            self._interaction = Interaction(current_span)
            self._owns_span = False
        else:
            # No active span, create a root span
            tracer = trace.get_tracer("glass")
            self._span_context = tracer.start_as_current_span(
                INTERACTION_SPAN_NAME, attributes=self._formatted_attributes
            )
            span = self._span_context.__enter__()
            self._interaction = Interaction(span)
            self._owns_span = True

        return self._interaction

    def _end(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """End the interaction, recording any exception."""
        try:
            if exc_val is not None and self._interaction is not None:
                self._interaction.record_exception(exc_val)
            if self._owns_span and self._span_context is not None:
                self._span_context.__exit__(exc_type, exc_val, exc_tb)
        finally:
            # Restore the previous metadata
            if self._token is not None:
                reset_active_metadata(self._token)

    # Sync context manager protocol
    def __enter__(self) -> Interaction:
        return self._start()

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        self._end(exc_type, exc_val, exc_tb)

    # Async context manager protocol
    async def __aenter__(self) -> Interaction:
        return self._start()

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        self._end(exc_type, exc_val, exc_tb)


__all__ = [
    "interaction",
    "Interaction",
    "INTERACTION_SPAN_NAME",
    "ATTR_GLASS_INTERACTION_OUTPUT_EVENT_NAME",
]
