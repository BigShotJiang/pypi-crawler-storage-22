import json
import atexit
from typing import Any, Dict, List, Optional, Union
from pathlib import Path

from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace.export import ConsoleSpanExporter, SimpleSpanProcessor
from opentelemetry.sdk.trace.sampling import Sampler
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter

from .console import get_console

GLASS_TRACE_ENDPOINT = "https://api.glasshq.ai/v1/traces"

def _get_default_instrumentations() -> List[Any]:
    """
    Get default AI/LLM instrumentations for OpenAI, Anthropic (Claude), and Google (Gemini).
    Returns instances of available instrumentors, silently skipping unavailable ones.
    """
    instrumentors: List[Any] = []

    # OpenAI instrumentation
    try:
        from opentelemetry.instrumentation.openai import OpenAIInstrumentor
        instrumentors.append(OpenAIInstrumentor())
    except ImportError:
        pass

    # Anthropic (Claude) instrumentation
    try:
        from opentelemetry.instrumentation.anthropic import AnthropicInstrumentor
        instrumentors.append(AnthropicInstrumentor())
    except ImportError:
        pass

    # Google Generative AI (Gemini) instrumentation
    try:
        from opentelemetry.instrumentation.google_generativeai import GoogleGenerativeAiInstrumentor
        instrumentors.append(GoogleGenerativeAiInstrumentor())
    except ImportError:
        pass

    return instrumentors

def setup(
    *,
    glass_api_key: Optional[str] = None,
    resource_attributes: Optional[Dict[str, Any]] = None,
    instrumentations: Optional[List[Any]] = None,
    skip_default_instrumentations: bool = False,
    sampler: Optional[Sampler] = None,
    debug: bool = False,
) -> TracerProvider:
    """
    Sets up OpenTelemetry with Glass configuration.

    This is the simplest way to initialize OpenTelemetry for use with Glass.
    By default, it configures everything needed to send traces to Glass.

    The setup function automatically registers process exit handlers to ensure
    spans are properly flushed when the process exits.

    IMPORTANT: You must call init() before setup() to initialize Glass with your API key.

    Returns:
        The configured TracerProvider instance

    Example:
        ```python
        from glass import init

        # First, initialize Glass
        init(api_key="your-api-key")


        ```
    """
    # Build resource attributes
    all_resource_attributes = {
        **(resource_attributes or {}),
    }

    # Create resource
    resource = Resource(attributes=all_resource_attributes)

    # Create the tracer provider with sampler only if explicitly provided
    if sampler:
        tracer_provider = TracerProvider(resource=resource, sampler=sampler)
    else:
        # No sampler specified - use OpenTelemetry's default behavior
        tracer_provider = TracerProvider(resource=resource)

    # Configure trace exporter
    exporter_headers: Dict[str, str] = {
        "Content-Type": "application/json",
    }

    # Add authorization header if we have an API key
    if glass_api_key:
        exporter_headers["X-API-Key"] = f"{glass_api_key}"

    trace_endpoint = GLASS_TRACE_ENDPOINT
    otlp_exporter = OTLPSpanExporter(
        endpoint=trace_endpoint,
        headers=exporter_headers,
    )

    # Add main export processor
    export_processor = SimpleSpanProcessor(otlp_exporter)
    tracer_provider.add_span_processor(export_processor)

    # Add console exporter if debug mode
    if debug:
        console_processor = SimpleSpanProcessor(ConsoleSpanExporter())
        tracer_provider.add_span_processor(console_processor)

    # Set as global tracer provider
    trace.set_tracer_provider(tracer_provider)

    # Register shutdown handlers
    def shutdown_handler() -> None:
        try:
            tracer_provider.shutdown()
        except Exception as e:
            console = get_console()
            console.error(f"Error during OpenTelemetry shutdown: {e}")

    # Register for different exit scenarios
    atexit.register(shutdown_handler)

    # Configure instrumentations if provided
    # If no instrumentations provided and not skipping defaults, use default AI instrumentations
    if instrumentations is None and not skip_default_instrumentations:
        instrumentations = _get_default_instrumentations()

    # Standard pattern is to pass instances: RequestsInstrumentor().instrument()
    if instrumentations:
        for instrumentation in instrumentations:
            try:
                print(f"Instrumenting {type(instrumentation).__name__}")
                # All standard OpenTelemetry instrumentations inherit from BaseInstrumentor
                # which provides the instrument() method
                if hasattr(instrumentation, "instrument") and callable(instrumentation.instrument):
                    print(f"Instrumenting {type(instrumentation).__name__} with tracer_provider")
                    # Check if this is an OpenInference instrumentor which needs tracer_provider
                    # OpenInference instrumentors are in the openinference.instrumentation namespace
                    module_name = type(instrumentation).__module__
                    if module_name and "openinference.instrumentation" in module_name:
                        print(f"Instrumenting {type(instrumentation).__name__} with tracer_provider (openinference)")
                        # OpenInference instrumentors need the tracer_provider
                        instrumentation.instrument(tracer_provider=tracer_provider)
                    else:
                        print(f"Instrumenting {type(instrumentation).__name__} with tracer_provider (not openinference)")
                        # Standard OpenTelemetry instrumentors
                        instrumentation.instrument()
                else:
                    import warnings

                    warnings.warn(
                        f"Instrumentation {type(instrumentation).__name__} does not have an 'instrument' method. "
                        f"Ensure you're passing an instance, not a class.",
                        UserWarning,
                        stacklevel=2,
                    )
            except Exception as e:
                import warnings

                warnings.warn(
                    f"Failed to configure instrumentation {type(instrumentation).__name__}: {e}",
                    UserWarning,
                    stacklevel=2,
                )

    return tracer_provider


__all__ = ["setup"]
