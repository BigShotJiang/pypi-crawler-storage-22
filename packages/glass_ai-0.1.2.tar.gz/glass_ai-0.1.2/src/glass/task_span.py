from typing import Any, Dict, Optional

from opentelemetry import trace
from opentelemetry.trace import Span
from opentelemetry.trace.status import Status, StatusCode

from .context import active_metadata
from .utils import ensure_initialized, _glass_json_dumps, glass_format_otel_attributes


# Event names for task span inputs/outputs
ATTR_GLASS_TASK_INPUT_EVENT_NAME = "glass.task.input"
ATTR_GLASS_TASK_OUTPUT_EVENT_NAME = "glass.task.output"


class TaskSpan:
    """
    A wrapper around an OpenTelemetry span that provides convenient methods
    for recording task inputs and outputs.
    """

    def __init__(self, span: Span) -> None:
        self._span = span

    def record_input(self, data: Any) -> None:
        """
        Record input data for this task span.

        Args:
            data: The input data to record. Will be JSON serialized.
        """
        serialized = _glass_json_dumps(data)
        self._span.add_event(ATTR_GLASS_TASK_INPUT_EVENT_NAME, {"input": serialized})

    def record_output(self, data: Any) -> None:
        """
        Record output data for this task span.

        Args:
            data: The output data to record. Will be JSON serialized.
        """
        serialized = _glass_json_dumps(data)
        self._span.add_event(ATTR_GLASS_TASK_OUTPUT_EVENT_NAME, {"output": serialized})

    def set_attribute(self, key: str, value: Any) -> None:
        """
        Set an attribute on the span.

        Args:
            key: The attribute key.
            value: The attribute value.
        """
        self._span.set_attribute(key, value)

    def record_exception(self, exception: BaseException) -> None:
        """
        Record an exception on the span and set error status.

        Args:
            exception: The exception to record.
        """
        self._span.record_exception(exception)
        self._span.set_status(Status(StatusCode.ERROR, description=str(exception)))
        self._span.set_attribute("error.type", exception.__class__.__name__)

    @property
    def span(self) -> Span:
        """Access the underlying OpenTelemetry span."""
        return self._span


class task_span:
    """
    Context manager for creating task spans with input/output recording.

    Supports both synchronous and asynchronous usage:

    Sync usage:
        ```python
        with task_span("my_task") as task:
            task.record_input({"query": "hello"})
            result = do_work()
            task.record_output({"result": result})
        ```

    Async usage:
        ```python
        async with task_span("my_task") as task:
            task.record_input({"query": "hello"})
            result = await do_async_work()
            task.record_output({"result": result})
        ```

    Args:
        name: The name of the task span.
        attributes: Optional dictionary of additional attributes to set on the span.
    """

    def __init__(self, name: str, attributes: Optional[Dict[str, Any]] = None) -> None:
        self._name = name
        self._explicit_attributes = attributes
        self._span_context: Any = None
        self._task_span: Optional[TaskSpan] = None

    def _start_span(self) -> TaskSpan:
        """Start the span and return a TaskSpan wrapper."""
        ensure_initialized()

        # Merge ContextVar metadata with explicit attributes (explicit takes precedence)
        context_meta = active_metadata.get()
        merged_attrs = {**context_meta, **(self._explicit_attributes or {})}
        final_attributes = glass_format_otel_attributes(merged_attrs) if merged_attrs else None

        tracer = trace.get_tracer("glass")
        self._span_context = tracer.start_as_current_span(self._name, attributes=final_attributes)
        span = self._span_context.__enter__()
        self._task_span = TaskSpan(span)
        return self._task_span

    def _end_span(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """End the span, recording any exception."""
        if exc_val is not None and self._task_span is not None:
            self._task_span.record_exception(exc_val)
        if self._span_context is not None:
            self._span_context.__exit__(exc_type, exc_val, exc_tb)

    # Sync context manager protocol
    def __enter__(self) -> TaskSpan:
        return self._start_span()

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        self._end_span(exc_type, exc_val, exc_tb)

    # Async context manager protocol
    async def __aenter__(self) -> TaskSpan:
        return self._start_span()

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        self._end_span(exc_type, exc_val, exc_tb)


__all__ = [
    "task_span",
    "TaskSpan",
    "ATTR_GLASS_TASK_INPUT_EVENT_NAME",
    "ATTR_GLASS_TASK_OUTPUT_EVENT_NAME",
]
