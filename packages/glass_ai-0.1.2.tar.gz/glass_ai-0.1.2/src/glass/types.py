"""Type definitions for the Glass library."""

from typing import TYPE_CHECKING, Any, Dict, List, Optional
from typing_extensions import TypedDict

if TYPE_CHECKING:
    from opentelemetry.sdk.trace.sampling import Sampler  # type: ignore

    _ = Sampler  # Keep import for type checking
else:
    Sampler = Any


class OtelConfigOptions(TypedDict, total=False):
    """
    Configuration options for OpenTelemetry setup.

    All fields are optional. When not provided, sensible defaults are used.
    """

    trace_endpoint: Optional[str]
    """Custom OTLP endpoint URL. Defaults to Glass' OTLP endpoint."""

    instrumentations: Optional[List[Any]]
    """List of OpenTelemetry instrumentation instances to configure."""

    skip_default_instrumentations: bool
    """Skip default instrumentations. Defaults to False."""

    debug: bool
    """Enable console exporter for debugging. Defaults to False."""


__all__ = ["OtelConfigOptions"]
