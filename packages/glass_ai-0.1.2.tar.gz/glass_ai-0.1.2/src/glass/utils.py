import sys
import json
import logging
import warnings
from typing import Any, Set, Dict, List, Union, cast
from datetime import datetime

from pydantic import BaseModel
from opentelemetry import trace as trace_api
from opentelemetry.util import types as otel_types
from opentelemetry.sdk.trace import TracerProvider as SDKTracerProvider

logger = logging.getLogger("glass")

OTLP_MAX_INT_SIZE = (2**63) - 1  # Max 64-bit signed integer
OTLP_MIN_INT_SIZE = -(2**63)  # Min 64-bit signed integer

CIRCULAR_REFERENCE_PLACEHOLDER = "[CircularReference]"

GLASS_BASE_URL = "https://api.glasshq.ai" # Default base URL for Glass API

def _show_otel_warning() -> None:
    """Show a warning if OpenTelemetry is not configured."""
    logger.warning("OpenTelemetry is not configured. Please configure OpenTelemetry before using Glass.")


def _is_otel_configured() -> bool:
    """Check if OpenTelemetry SDK TracerProvider is configured."""
    provider = trace_api.get_tracer_provider()
    return isinstance(provider, SDKTracerProvider)


def _is_glass_initialized() -> bool:
    """Check if Glass has been initialized via init()."""
    glass_module = sys.modules.get("glass")
    return bool(glass_module and getattr(glass_module, "__glass_initialized", False))


def _convert_pydantic_model_to_dict_if_applicable(obj: Any) -> Any:
    """Checks if an object is a Pydantic model and converts it to a dict.
    Returns the original object if it's not a Pydantic model or conversion fails.
    """
    if isinstance(obj, BaseModel):
        try:
            # Pydantic V2
            return obj.model_dump()
        except AttributeError:
            # Pydantic V1
            try:
                return obj.dict()  # type: ignore
            except AttributeError:
                # Should not happen if isinstance check passed and it's a Pydantic model
                pass  # Fall through, returning original obj
    return obj


def _glass_json_dumps(value: Any) -> str:
    """Helper to dump objects to JSON string, handling circular references and non-serializable types.

    This is a serialization function designed to help properly convert Open Telemetry span attributes
    or convert the function arguments and outputs to a serializable format.
    """

    # Attempt to convert top-level value if it's a Pydantic model
    value = _convert_pydantic_model_to_dict_if_applicable(value)

    seen_objects_for_this_dump: Set[int] = set()

    def default_handler(obj: Any) -> Any:
        obj_id = id(obj)
        if obj_id in seen_objects_for_this_dump:
            return CIRCULAR_REFERENCE_PLACEHOLDER

        seen_objects_for_this_dump.add(obj_id)

        # Attempt to convert Pydantic models to dict
        # Must be done before trying str(obj) as Pydantic models might have custom __str__
        processed_obj = _convert_pydantic_model_to_dict_if_applicable(obj)

        # If the object was a Pydantic model and successfully converted,
        # processed_obj will be a dict. Otherwise, it's the original obj.
        # We only proceed to str(obj) if it wasn't a Pydantic model or conversion failed.
        if processed_obj is not obj:  # Check if conversion happened
            # If it was converted (e.g. to a dict), it's ready for json.dumps
            return processed_obj

        try:
            return str(obj)
        except Exception:
            return f"[UnserializableType: {type(obj).__name__}]"

    try:
        return json.dumps(value, default=default_handler)
    except ValueError as e:
        if "Circular reference detected" in str(e):
            # This case should ideally be caught by the default_handler.
            # If it still occurs, it means a very complex or deep cycle was not fully handled before json.dumps itself gave up.
            # We return a simple placeholder for the entire problematic value.
            # To be more granular, the default_handler would need to be even more sophisticated
            # or we'd need a pre-processing step to replace cycles before calling json.dumps.
            warnings.warn(
                f"Fallback to placeholder for entire value due to complex circular reference: {e}",
                UserWarning,
                stacklevel=2,
            )
            return json.dumps(CIRCULAR_REFERENCE_PLACEHOLDER)
        raise  # Re-raise other ValueErrors
    except TypeError as e:
        # Fallback if default_handler somehow returns a type json.dumps still can't handle,
        # or if the initial `value` itself is problematic in a way that bypasses the default logic early.
        warnings.warn(
            f"Fallback JSON serialization due to TypeError: {e}. Result may be lossy.", UserWarning, stacklevel=2
        )
        # Final fallback to simple str conversion for the whole object if custom logic fails.
        return json.dumps(str(value), default=str)


def glass_format_otel_value(value: Any) -> otel_types.AttributeValue:
    """Convert a user attribute value to an OpenTelemetry compatible type.

    Simple types (str, bool, float) are passed through.
    Integers are checked against OTel's 64-bit range and converted to string if outside.
    All other types (lists, dicts, complex objects) are JSON stringified using a safe dumper.
    """
    if isinstance(value, (str, bool, float)):
        return value
    elif isinstance(value, int):
        if not (OTLP_MIN_INT_SIZE <= value <= OTLP_MAX_INT_SIZE):
            warnings.warn(
                f"Integer value {value} is outside the OTLP 64-bit signed integer range "
                f"({OTLP_MIN_INT_SIZE} to {OTLP_MAX_INT_SIZE}), it will be converted to a string.",
                UserWarning,
                stacklevel=2,
            )
            return str(value)
        return value
    else:
        # For lists, dicts, complex objects, etc., JSON stringify safely.
        return _glass_json_dumps(value)


def glass_format_otel_attributes(attributes: Dict[str, Any]) -> Dict[str, otel_types.AttributeValue]:
    """Prepare an attributes dictionary for OpenTelemetry by formatting each value."""
    return {key: glass_format_otel_value(value) for key, value in attributes.items()}


def ensure_initialized(suppress_warnings: bool = False) -> None:
    """
    Ensures Glass is properly initialized with OpenTelemetry configured.

    This function:
    1. First attempts auto-initialization if environment variables are set
    2. Then checks if OpenTelemetry is configured
    3. Shows a warning if otel_setup was explicitly set to False but OTEL is not configured

    Args:
        suppress_warnings: If True, suppresses auto-initialization warnings.
    """
    import os

    # First, try auto-initialization if needed
    if not _is_otel_configured() and not _is_glass_initialized():
        api_key = os.environ.get("GLASS_API_KEY")
        if api_key:
            # Show warning about auto-initialization unless suppressed
            if not suppress_warnings:
                _show_otel_warning()

            from .init import init

            init_kwargs: Dict[str, Any] = {"api_key": api_key}
            init_kwargs["base_url"] = GLASS_BASE_URL
            init(**init_kwargs)
            # After auto-init, OTEL should be configured, so we can return
            return


def generate_config_diff(previous_config: Dict[str, Any], current_config: Dict[str, Any]) -> List[str]:
    """
    Generate a diff between two configuration dictionaries.

    Args:
        previous_config: The previous configuration
        current_config: The current configuration

    Returns:
        List of formatted diff lines showing changes
    """
    diff_lines: List[str] = []
    all_keys = set(previous_config.keys()) | set(current_config.keys())

    for key in sorted(all_keys):
        prev_value = previous_config.get(key)
        curr_value = current_config.get(key)

        # Handle sensitive keys generically
        display_prev = mask_sensitive_value(key, prev_value)
        display_curr = mask_sensitive_value(key, curr_value)

        if key not in previous_config and key in current_config:
            # Added
            diff_lines.append(f"  {key}:")
            diff_lines.append(f"    + {format_config_value(display_curr)}")
        elif key in previous_config and key not in current_config:
            # Removed
            diff_lines.append(f"  {key}:")
            diff_lines.append(f"    - {format_config_value(display_prev)}")
        elif prev_value != curr_value:
            # Changed
            diff_lines.append(f"  {key}:")
            diff_lines.append(f"    - {format_config_value(display_prev)} → {format_config_value(display_curr)}")

    return diff_lines


def format_timestamp(timestamp: Union[int, float, datetime], relative: bool = False) -> str:
    """Format a timestamp for display."""
    if isinstance(timestamp, (int, float)):
        dt = datetime.fromtimestamp(timestamp)
    else:
        dt = timestamp

    if relative:
        # Calculate relative time
        now = datetime.now()
        delta = now - dt

        if delta.days > 0:
            return f"{delta.days}d ago"
        elif delta.seconds > 3600:
            return f"{delta.seconds // 3600}h ago"
        elif delta.seconds > 60:
            return f"{delta.seconds // 60}m ago"
        else:
            return "just now"
    else:
        return dt.strftime("%Y-%m-%d %H:%M:%S")


def format_config_value(value: Any) -> str:
    """Format a configuration value for display in diffs."""
    if value is None:
        return "None"
    elif isinstance(value, str):
        return f'"{value}"'
    elif isinstance(value, bool):
        return str(value)
    elif isinstance(value, (int, float)):
        return str(value)
    elif callable(value):
        return "<function>"
    elif isinstance(value, dict):
        # For dicts, show a summary
        if not value:
            return "{}"
        value_dict = cast(Dict[Any, Any], value)
        key_list: List[str] = [str(k) for k in value_dict.keys()]
        if len(key_list) <= 3:
            return f"{{ {', '.join(key_list)} }}"
        return f"{{ {', '.join(key_list[:3])}, ... }}"
    elif isinstance(value, list):
        value_list = cast(List[Any], value)
        return f"[List({len(value_list)})]"
    else:
        return f"<{type(value).__name__}>"


def mask_sensitive_value(key: str, value: Any) -> Any:
    """
    Mask sensitive values based on key patterns.

    Args:
        key: The configuration key name
        value: The value to potentially mask

    Returns:
        The masked value if sensitive, otherwise the original value
    """
    import re

    sensitive_patterns = [
        re.compile(r"key", re.IGNORECASE),
        re.compile(r"token", re.IGNORECASE),
        re.compile(r"secret", re.IGNORECASE),
        re.compile(r"password", re.IGNORECASE),
        re.compile(r"auth", re.IGNORECASE),
        re.compile(r"credential", re.IGNORECASE),
        re.compile(r"apikey", re.IGNORECASE),
        re.compile(r"api_key", re.IGNORECASE),
    ]

    if isinstance(value, str) and any(pattern.search(key) for pattern in sensitive_patterns):
        # Show first 6 chars and mask the rest
        if len(value) > 10:
            return f"{value[:6]}***"
        return "***"

    return value


__all__ = [
    "glass_format_otel_attributes",
    "glass_format_otel_value",
    "_glass_json_dumps",
    "ensure_initialized",
    "format_timestamp",
]
