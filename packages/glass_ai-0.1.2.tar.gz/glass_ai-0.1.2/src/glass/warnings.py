"""
Centralized warning system for Glass Python SDK.
Mirrors the pattern from the Node.js SDK with GT_ prefixed warning IDs.
"""

from typing import Any, Set, Dict, List, Union, Optional

from rich.text import Text
from rich.panel import Panel
from rich.console import Group, Console

# Global tracking of displayed warnings
_displayed_warnings: Set[str] = set()


class GlassWarningOptions:
    """Options for creating a GlassWarning."""
    
    def __init__(
        self,
        warning_id: str,
        title: str,
        message: Union[str, List[str]],
        learn_more_url: Optional[str] = None,
        suppression_hint: Optional[str] = None,
        border_color: str = "yellow"
    ):
        self.warning_id = warning_id
        self.title = title
        self.message = message
        self.learn_more_url = learn_more_url
        self.suppression_hint = suppression_hint
        self.border_color = border_color


class GlassWarning:
    """Base class for Glass warning display."""
    
    def __init__(self, options: GlassWarningOptions):
        self.warning_id = options.warning_id
        self.title = options.title
        self.message = options.message if isinstance(options.message, list) else [options.message]
        self.learn_more_url = options.learn_more_url
        self.suppression_hint = options.suppression_hint
        self.border_color = options.border_color
    
    def get_simple_message(self) -> str:
        """Get the warning message as a simple string."""
        return " ".join(self.message)
    
    def display(self) -> None:
        """Display the warning with rich formatting."""
        # Check if this warning has already been displayed
        if self.warning_id in _displayed_warnings:
            return
        
        # Mark as displayed
        _displayed_warnings.add(self.warning_id)
        
        try:
            # Build content parts
            content_parts: List[Text] = []
            
            # Add main message
            for line in self.message:
                content_parts.append(Text(line))
            
            # Add learn more URL if provided
            if self.learn_more_url:
                content_parts.append(Text(""))  # Empty line
                content_parts.append(Text(f"Learn more: {self.learn_more_url}", style="cyan"))
            
            # Add suppression hint if provided
            if self.suppression_hint:
                content_parts.append(Text(""))  # Empty line
                content_parts.append(Text(self.suppression_hint, style="dim"))
            
            # Create panel with consistent title format
            formatted_title = f"⚠ {self.title} [{self.warning_id}]"
            warning_panel = Panel(
                Group(*content_parts),
                title=f"[bold {self.border_color}]{formatted_title}[/bold {self.border_color}]",
                border_style=self.border_color,
                title_align="center",
                padding=(1, 2),
            )
            
            # Print with padding
            console: Console = Console(stderr=True)
            console.print("")
            console.print(warning_panel)
            console.print("")
            
        except Exception:
            # Fallback to simple console warning if formatting fails
            print(f"\n⚠ {self.title} [{self.warning_id}]\n\n{self.get_simple_message()}\n", file=__import__('sys').stderr)


# Pre-defined warning types (factory functions)
class GlassWarnings:
    """Factory functions for creating specific warning types."""
    
    @staticmethod
    def MissingApiKeyError() -> GlassWarning:
        return GlassWarning(GlassWarningOptions(
            warning_id="GT_MissingApiKeyError",
            title="Glass API Key Missing",
            message=[
                "Glass API key is missing or invalid. The SDK cannot connect to Glass",
                "without a valid API key.",
                "",
                "To fix this, provide your API key in one of these ways:",
                "",
                "1. Set the GLASS_API_KEY environment variable:",
                "   export GLASS_API_KEY=\"your-api-key\"",
                "",
                "2. Pass it directly to init():",
                "   init(api_key=\"your-api-key\")",
                "",
                "Get your API key from: https://glasshq.ai/s/api-keys",
            ],
            learn_more_url="https://glasshq.ai/docs/reference/sdk-errors#gt-missingapikeyerror",
            border_color="red"
        ))
    
    @staticmethod
    def MultipleInitWarning(call_number: int, diff_lines: List[str], init_history: List[Dict[str, Any]]) -> GlassWarning:
        from ..lib.utils import format_timestamp
        
        # Build history display
        history_lines: List[str] = []
        for init_call in init_history:
            timestamp = init_call.get('timestamp')
            if timestamp is not None:
                if hasattr(timestamp, 'timestamp'):
                    # It's a datetime object
                    timestamp_str = format_timestamp(timestamp, relative=True)
                elif isinstance(timestamp, (int, float)):
                    timestamp_str = format_timestamp(timestamp, relative=True)
                else:
                    timestamp_str = str(timestamp)
            else:
                timestamp_str = ''
            history_lines.append(f"  - Call #{init_call['callNumber']}: {timestamp_str}")
        
        # Build message
        message_lines = [
            f"Glass init() has been called {call_number} times.",
            "",
            "Previous initializations:",
        ] + history_lines + [
            "",
            "Configuration changes detected:",
        ] + diff_lines + [
            "",
            "Note: Multiple init() calls can lead to unexpected behavior.",
            "The most recent configuration will be used.",
        ]
        
        return GlassWarning(GlassWarningOptions(
            warning_id="GT_MultipleInitWarning",
            title="Multiple Initialization Detected",
            message=message_lines,
            learn_more_url=None,
            suppression_hint="To suppress this warning, ensure init() is only called once",
            border_color="yellow"
        ))

