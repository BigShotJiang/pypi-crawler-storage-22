# GlavnaQt

GlavnaQt is a PyQt6-based GUI framework for building desktop applications with customizable layouts and basic UI features.

## Features

- Layouts with splitters and sidebars (`CollapsibleSplitter`, `LayoutManager`)
- Event handling (`EventBus`, `transitions.py`)
- Configuration via `UIConfig` (Confumo)
- Status bar updates (`StatusBarManager`)
- Background tasks (`ThreadManager`, `TaskRunnable`)
- Light/dark theme support (`ThemeManager`, `ThemeWatcher`)
- Optional profiling (`profiler.py`) and logging (`logger.py`)

## Installation

1. Clone the repo:
   ```bash
   git clone https://github.com/your-username/glavnaqt.git
   cd glavnaqt
   ```

2. Set up a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. Install requirements:
   ```bash
   pip install -r requirements.txt
   ```

4. Run the example:
   ```bash
   python glavnaqt/examples/example.py
   ```

## Usage

- Start the app:
  ```bash
  python glavnaqt/examples/example.py
  ```
- Cycle layouts:
  ```bash
  python glavnaqt/examples/example.py --cycle-layouts
  ```
- Change settings in `glavnaqt/core/config.py`.

## Project Structure

```
glavnaqt/
├── core/
│   ├── config.py
│   ├── logger.py
│   ├── profiler.py
│   └── thread_manager.py
├── ui/
│   ├── main_window.py
│   ├── layout.py
│   ├── status_bar_manager.py
│   ├── theme_manager.py
│   ├── theme_watcher.py
│   └── widget_adjustment.py
├── events/
│   ├── bus.py
│   └── window.py
├── examples/
│   └── example.py
├── transitions.py
├── setup.py
└── requirements.txt
```

## Development

- Install dev tools:
  ```bash
  pip install -r dev-requirements.txt
  ```
- Run tests:
  ```bash
  pytest tests/
  ```

## License

AGPLv3. See [LICENSE](LICENSE).

## Contact

Open an issue on GitHub.
