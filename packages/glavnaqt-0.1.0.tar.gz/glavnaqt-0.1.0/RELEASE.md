# Releasing GlavnaQt

GlavnaQt uses **setuptools-scm** to derive its version from git tags.

## Local checks

```bash
python -m pip install --upgrade build twine
python -m build
python -m twine check dist/*
```

## Trusted Publishing setup

Create two GitHub environments in the repo:

- `testpypi`
- `pypi`

Then add **Trusted Publishers** on both TestPyPI and PyPI for:

- Owner: `actx4gh`
- Repository: `GlavnaQt`
- Workflow: `.github/workflows/publish.yml`
- Environment: `testpypi` (on TestPyPI) / `pypi` (on PyPI)
- Project name: `GlavnaQt`

## Release

```bash
git tag -a v0.1.0 -m "v0.1.0"
git push origin v0.1.0
```

Tag push triggers build + publish.
