# GlavnaQt — PyQt6 app framework
# Copyright (C) 2025 Aaron Colichia
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# See <https://www.gnu.org/licenses/> for details.

# config.py  (GlavnaQt)
import os
import argparse
from confuse import NotFoundError
from platformdirs import user_config_dir
from PyQt6.QtCore import Qt

from confumo import Confumo

LOGGER_NAME = 'glavnaqt'
LOG_FILE_NAME = f'{LOGGER_NAME}.log'
APP_NAME     = LOGGER_NAME
LOG_LEVEL    = 'INFO'

# Alignment constants for UI components
ALIGN_CENTER    = Qt.AlignmentFlag.AlignCenter
ALIGN_LEFT      = Qt.AlignmentFlag.AlignLeft
ALIGN_RIGHT     = Qt.AlignmentFlag.AlignRight
ALIGN_TOP       = Qt.AlignmentFlag.AlignTop
ALIGN_BOTTOM    = Qt.AlignmentFlag.AlignBottom
ALIGN_VCENTER   = Qt.AlignmentFlag.AlignVCenter
ALIGN_HCENTER   = Qt.AlignmentFlag.AlignHCenter
ALIGN_JUSTIFY   = Qt.AlignmentFlag.AlignJustify
ALIGN_ABSOLUTE  = Qt.AlignmentFlag.AlignAbsolute
ALIGN_LEADING   = Qt.AlignmentFlag.AlignLeading
ALIGN_TRAILING  = Qt.AlignmentFlag.AlignTrailing
ALIGN_HORZ_MASK = Qt.AlignmentFlag.AlignHorizontal_Mask
ALIGN_VERT_MASK = Qt.AlignmentFlag.AlignVertical_Mask

ALIGNMENT_NAMES_REVERSE_LOOKUP = {
    Qt.AlignmentFlag.AlignCenter          : 'ALIGN_CENTER',
    Qt.AlignmentFlag.AlignLeft            : 'ALIGN_LEFT',
    Qt.AlignmentFlag.AlignRight           : 'ALIGN_RIGHT',
    Qt.AlignmentFlag.AlignTop             : 'ALIGN_TOP',
    Qt.AlignmentFlag.AlignBottom          : 'ALIGN_BOTTOM',
    Qt.AlignmentFlag.AlignVCenter         : 'ALIGN_VCENTER',
    Qt.AlignmentFlag.AlignHCenter         : 'ALIGN_HCENTER',
    Qt.AlignmentFlag.AlignJustify         : 'ALIGN_JUSTIFY',
    Qt.AlignmentFlag.AlignAbsolute        : 'ALIGN_ABSOLUTE',
    Qt.AlignmentFlag.AlignLeading         : 'ALIGN_LEADING',
    Qt.AlignmentFlag.AlignTrailing        : 'ALIGN_TRAILING',
    Qt.AlignmentFlag.AlignHorizontal_Mask : 'ALIGN_HORZ_MASK',
    Qt.AlignmentFlag.AlignVertical_Mask   : 'ALIGN_VERT_MASK',
}


class UIConfig(Confumo):
    """Loads GlavnaQt UI settings via Confumo base class."""
    ALIGN_CENTER    = ALIGN_CENTER
    ALIGN_LEFT      = ALIGN_LEFT
    ALIGN_RIGHT     = ALIGN_RIGHT
    ALIGN_TOP       = ALIGN_TOP
    ALIGN_BOTTOM    = ALIGN_BOTTOM
    ALIGN_VCENTER   = ALIGN_VCENTER
    ALIGN_HCENTER   = ALIGN_HCENTER
    ALIGN_JUSTIFY   = ALIGN_JUSTIFY
    ALIGN_ABSOLUTE  = ALIGN_ABSOLUTE
    ALIGN_LEADING   = ALIGN_LEADING
    ALIGN_TRAILING  = ALIGN_TRAILING
    ALIGN_HORZ_MASK = ALIGN_HORZ_MASK
    ALIGN_VERT_MASK = ALIGN_VERT_MASK

    _hide_cycle_flag = False

    def add_args(self, parser: argparse.ArgumentParser):
        parser.add_argument('--cycle-layouts', action='store_true',
                            help=argparse.SUPPRESS if self._hide_cycle_flag else 
                            "Enable cycling through layouts")
        parser.add_argument('--theme', choices=['light','dark','auto'],
                            help="UI theme: light, dark, or auto (time-based)")

    def _init_subclass(self):
        args = self.args
        cfg  = self.cfg

        def _get(key, typ, default):
            try:
                return cfg[key].get(typ)
            except (NotFoundError, AttributeError):
                return default

        # exactly the same peeling logic as before
        self.config_dir                = os.path.abspath(args.config_dir)
        self.cycle_layouts             = args.cycle_layouts or _get('cycle_layouts', bool, False)
        self.font_face                 = _get('font_face', str, "Helvetica")
        self.font_size                 = _get('font_size', int, 12)
        self.splitter_handle_width     = _get('splitter_handle_width', int, 5)
        self.window_size               = tuple(_get('window_size', list, [640, 480]))
        self.window_position           = tuple(_get('window_position', list, [100, 100]))
        self.theme                     = args.theme or _get('theme', str, 'auto')
        self.light_start               = _get('light_start', str, '07:00')
        self.dark_start                = _get('dark_start', str, '19:00')
        self.enable_status_bar_manager = _get('enable_status_bar_manager', bool, False)
        self.collapsible_sections      = _get(
            'collapsible_sections', dict,
            {"main_content": {"text": "Main Content", "alignment": Qt.AlignmentFlag.AlignCenter}}
        )

    def to_dict(self):
        return {
            'cycle_layouts':             self.cycle_layouts,
            'font_face':                 self.font_face,
            'font_size':                 self.font_size,
            'splitter_handle_width':     self.splitter_handle_width,
            'window_size':               self.window_size,
            'window_position':           self.window_position,
            'enable_status_bar_manager': self.enable_status_bar_manager,
            'collapsible_sections':      self.collapsible_sections,
        }

    def get_section_widget(self, section_name):
        return self.collapsible_sections.get(section_name, {}).get("widget")

    def update_collapsible_section(self,
                                   section_name,
                                   text=None,
                                   alignment=Qt.AlignmentFlag.AlignCenter,
                                   widget=None,
                                   status_label=None):
        self.collapsible_sections[section_name] = {
            "text": text,
            "alignment": alignment,
            "widget": widget,
        }
        if status_label:
            self.collapsible_sections[section_name]["status_label"] = status_label

    def get_section_alignment(self, section_name):
        return self.collapsible_sections.get(section_name, {}) \
                                       .get("alignment", Qt.AlignmentFlag.AlignCenter)

    def replace_alignment_constants(self, data=None):
        if data is None:
            data = self.collapsible_sections

        def _fmt(d):
            if isinstance(d, dict):
                parts = [f"{repr(k)}: {_fmt(v)}" for k, v in d.items()]
                return '{' + ', '.join(parts) + '}'
            if isinstance(d, tuple):
                return '(' + ', '.join(_fmt(v) for v in d) + ')'
            if isinstance(d, Qt.AlignmentFlag):
                return ALIGNMENT_NAMES_REVERSE_LOOKUP[d]
            return repr(d)

        return _fmt(data)

config = Confumo.expose(
    APP_NAME,
    UIConfig,
    globals(),
    root=False
) 
