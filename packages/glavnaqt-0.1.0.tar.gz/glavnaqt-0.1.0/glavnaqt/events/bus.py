# GlavnaQt — PyQt6 app framework
# Copyright (C) 2025 Aaron Colichia
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# See <https://www.gnu.org/licenses/> for details.

class EventBus:
    """Simple pub‑sub hub that is totally agnostic to Qt."""
    def __init__(self):
        self._listeners: dict[str, list] = {}

    def subscribe(self, event: str, cb):
        self._listeners.setdefault(event, []).append(cb)

    def unsubscribe(self, event: str, cb):
        try:
            self._listeners[event].remove(cb)
            if not self._listeners[event]:
                del self._listeners[event]
        except (KeyError, ValueError):
            pass

    def emit(self, event: str, *args, **kw):
        for cb in self._listeners.get(event, ()):
            cb(*args, **kw)


# — shared instances — -------------------------------------------------------
_shared: dict[str, EventBus] = {}


def create_or_get_shared_event_bus(name: str = "glavna") -> EventBus:
    """Factory for a named, process‑wide bus."""
    return _shared.setdefault(name, EventBus())


def get_shared_event_bus(name: str = "glavna") -> EventBus | None:
    return _shared.get(name)

