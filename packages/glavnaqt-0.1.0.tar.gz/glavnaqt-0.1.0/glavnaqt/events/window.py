# GlavnaQt — PyQt6 app framework
# Copyright (C) 2025 Aaron Colichia
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# See <https://www.gnu.org/licenses/> for details.

"""
Helpers that bridge native Qt resize events with the Qt‑free EventBus.

They attach timers to avoid hammering layout code while the user drags.
"""

from PyQt6.QtCore import QTimer
from glavnaqt.core import logger


def setup_event_handling(win):
    """
    Plug resize throttling into *win*.
      • connects `win.resized_signal` to `win.on_resize_timeout`
      • sets up an internal single‑shot timer
    """
    win.resize_timer = QTimer()
    win.resize_timer.setSingleShot(True)
    win.resize_timer.timeout.connect(lambda: win.resized_signal.emit(win.width(), win.height()))
    logger.debug("Resize timer configured.")


def handle_resize_event(win, event):
    """
    Called from `MainWindow.resizeEvent`.  Restarts the single‑shot timer;
    when it elapses we emit the high‑level `resized_signal`.
    """
    if win.resize_timer.isActive():
        win.resize_timer.stop()
    win.resize_timer.start(50)     # 50 ms debounce window

