# GlavnaQt — PyQt6 app framework
# Copyright (C) 2025 Aaron Colichia
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# See <https://www.gnu.org/licenses/> for details.

from PyQt6.QtGui import QFontMetrics, QFont

from glavnaqt.core import logger

from PyQt6.QtGui import QFontMetrics, QFont

def calculate_scaling_factor(parent_width, actual_text, initial_text_width, 
                             font_face, max_font_size, min_font_size=3, 
                             log_required=False):
    """
    Calculates an appropriate font pixel size so that 'actual_text' fits 
    within 'parent_width'. Respects min and max font size limits.
    """
    if initial_text_width <= 0:
        return min_font_size
    # Initial proportional scaling
    scaling_factor = parent_width / initial_text_width
    new_size = max_font_size * scaling_factor

    # Clamp initial size to [min_font_size, max_font_size]
    if new_size < min_font_size:
        new_size = min_font_size
    elif new_size > max_font_size:
        new_size = max_font_size

    if log_required:
        logger.debug(f"Initial calculated font size: {new_size}px")

    iteration_count = 0
    max_iterations = 50
    last_adjustment = None  # Tracks last direction: 'increase' or 'decrease'

    while iteration_count < max_iterations:
        # Measure text width at the current font size
        font = QFont(font_face)
        font.setPixelSize(int(new_size))
        metrics = QFontMetrics(font)
        predicted_text_width = metrics.horizontalAdvance(actual_text)


        if log_required:
            logger.debug(f"Iteration {iteration_count}: Font Size={new_size}px, "
                         f"Predicted Width={predicted_text_width}px, Parent Width={parent_width}px")

        # If the text fits exactly, we’re done
        if predicted_text_width == parent_width:
            break

        if predicted_text_width > parent_width:
            # Text is still too wide – decrease font size
            if last_adjustment == 'increase':
                # We *just* tried to increase and overshot the width – revert that increase
                new_size -= 0.5
                if new_size < min_font_size:
                    new_size = min_font_size
                break  # Stop – now it definitely fits within width
            new_size -= 0.5
            last_adjustment = 'decrease'
        else:
            # Text width is under the parent width – try increasing to use remaining space
            # (allow one increase even if last action was a decrease, to approach the max fit)
            new_size += 0.5
            last_adjustment = 'increase'

        # Ensure the new_size stays within bounds
        if new_size < min_font_size:
            new_size = min_font_size
            break
        if new_size > max_font_size:
            new_size = max_font_size
            break

        iteration_count += 1

    if log_required:
        logger.debug(f"Final chosen font size: {new_size}px (Predicted Width={predicted_text_width}px)")

    final_size = int(new_size)
    
    # Only bump up if we're within ~0.1px of next whole size and it still fits
    font = QFont(font_face)
    font.setPixelSize(final_size + 1)
    metrics = QFontMetrics(font)
    if metrics.horizontalAdvance(actual_text) <= parent_width:
        final_size += 1

    return final_size

