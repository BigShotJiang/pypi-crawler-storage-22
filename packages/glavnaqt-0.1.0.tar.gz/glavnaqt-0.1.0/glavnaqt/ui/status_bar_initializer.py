# GlavnaQt — PyQt6 app framework
# Copyright (C) 2025 Aaron Colichia
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# See <https://www.gnu.org/licenses/> for details.

# status_bar_initializer.py
from PyQt6.QtCore import QObject
from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import QStatusBar, QLabel
#from glavnaqt.ui.scaling_status_label import AutoFitLabel
from glavnaqt.core.config import config as ui_config

class StatusBarInitializer(QObject):
    """
    Owns the status bar: constructs QStatusBar + QLabel, manages a busy indicator,
    and listens for lifecycle events to update the bar.
    """
    def __init__(self, main_window, ui_config, event_bus):
        super().__init__(main_window)
        self._main   = main_window
        self._config = ui_config
        self._bus    = event_bus

        """
        Programmatically create and register the status bar and label.
        Emits initialize_status_bar for immediate handler invocation.
        """
        bar = QStatusBar(self._main)
        label = QLabel(parent=bar)
        label.setFont(QFont(self._config.font_face, self._config.font_size))
        bar.addPermanentWidget(label)
        self._main.status_bar   = bar
        self._main.status_label = label
        # Persist in config for catch-up logic
        self._config.update_collapsible_section(
            'bottom', widget=bar, status_label=label
        )
        # Notify subscribers that bar is ready
        self._bus.emit('initialize_status_bar', bar, label)
        
