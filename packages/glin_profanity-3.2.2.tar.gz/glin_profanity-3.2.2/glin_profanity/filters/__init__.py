"""Profanity filtering components."""

from .filter import Filter

__all__ = ["Filter"]
