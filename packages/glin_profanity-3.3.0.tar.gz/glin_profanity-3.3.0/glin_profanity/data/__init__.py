"""Dictionary data loader for profanity detection."""
