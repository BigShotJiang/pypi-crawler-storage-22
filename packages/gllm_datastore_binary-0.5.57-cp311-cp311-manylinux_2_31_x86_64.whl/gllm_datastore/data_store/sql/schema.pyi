from _typeshed import Incomplete

Base: Incomplete

class ChunkModel(Base):
    '''SQLAlchemy model for the chunk table.

    Attributes:
        id (Column): The ID of the chunk.
        content (Column): The content of the chunk.
        metadata_column (Column): The metadata of the chunk stored as JSON.
            Database column name is "metadata" (SQLAlchemy reserves "metadata" as an attribute name).
    '''
    __tablename__: str
    id: Incomplete
    content: Incomplete
    metadata_column: Incomplete
