from _typeshed import Incomplete
from enum import StrEnum
from gllm_datastore.graph_data_store.graph_data_store import BaseGraphDataStore as BaseGraphDataStore
from typing import Any

class CypherIdentifierKind(StrEnum):
    """Enumeration of valid Cypher identifier kinds."""
    LABEL: str
    RELATIONSHIP: str
    PROPERTY_KEY: str

class FalkorDBGraphDataStore(BaseGraphDataStore):
    '''Implementation of BaseGraphDataStore for FalkorDB.

    Notes:
        FalkorDB provides an asyncio client (`falkordb.asyncio.FalkorDB`) that supports awaiting
        graph queries using an async Redis connection pool.

    Attributes:
        _pool (BlockingConnectionPool): Async Redis connection pool used by the client.
        _db (FalkorDB): The FalkorDB async client instance.
        _graph (Any): The selected graph handle returned by the FalkorDB client.
        graph_name (str): The graph name used by this data store.

    Example:
        ```python
        store = FalkorDBGraphDataStore(
            host="localhost",
            port=6379,
            graph_name="my_graph",
        )

        await store.upsert_node(
            label="Person",
            identifier_key="name",
            identifier_value="John",
            properties={"age": 30},
        )

        results = await store.query("MATCH (n:Person) RETURN n LIMIT 5")
        await store.close()
        ```
    '''
    graph_name: Incomplete
    def __init__(self, host: str, port: int, graph_name: str, password: str | None = None, decode_responses: bool = True, max_connections: int = 16, **kwargs: Any) -> None:
        """Initialize FalkorDBGraphDataStore.

        Args:
            host (str): FalkorDB host.
            port (int): FalkorDB port.
            graph_name (str): Graph name.
            password (str | None, optional): FalkorDB password. Defaults to None.
            decode_responses (bool, optional): Decode responses to string. Defaults to True.
            max_connections (int, optional): Max async Redis connections. Defaults to 16.
            **kwargs (Any): Extra kwargs forwarded to FalkorDB client (if supported).
        """
    async def upsert_node(self, label: str, identifier_key: str, identifier_value: str, properties: dict[str, Any] | None = None) -> Any:
        """Upsert a node in the graph.

        Args:
            label (str): Node label.
            identifier_key (str): Unique identifier property key.
            identifier_value (str): Unique identifier property value.
            properties (dict[str, Any] | None, optional): Additional node properties. Defaults to None.

        Returns:
            Any: Result of the operation.
        """
    async def upsert_relationship(self, node_source_key: str, node_source_value: str, relation: str, node_target_key: str, node_target_value: str, properties: dict[str, Any] | None = None) -> Any:
        """Upsert a relationship between two nodes.

        Args:
            node_source_key (str): Source node identifier key.
            node_source_value (str): Source node identifier value.
            relation (str): Relationship type.
            node_target_key (str): Target node identifier key.
            node_target_value (str): Target node identifier value.
            properties (dict[str, Any] | None, optional): Relationship properties. Defaults to None.

        Returns:
            Any: Result of the operation.
        """
    async def delete_node(self, label: str, identifier_key: str, identifier_value: str) -> Any:
        """Delete a node from the graph.

        Args:
            label (str): Node label.
            identifier_key (str): Unique identifier property key.
            identifier_value (str): Unique identifier property value.

        Returns:
            Any: Result of the operation.
        """
    async def delete_relationship(self, node_source_key: str, node_source_value: str, relation: str, node_target_key: str, node_target_value: str) -> Any:
        """Delete a relationship between two nodes.

        Args:
            node_source_key (str): Source node identifier key.
            node_source_value (str): Source node identifier value.
            relation (str): Relationship type.
            node_target_key (str): Target node identifier key.
            node_target_value (str): Target node identifier value.

        Returns:
            Any: Result of the operation.
        """
    async def query(self, query: str, parameters: dict[str, Any] | None = None) -> list[dict[str, Any]]:
        """Execute a query against FalkorDB.

        Args:
            query (str): Cypher query.
            parameters (dict[str, Any] | None, optional): Query parameters. Defaults to None.

        Returns:
            list[dict[str, Any]]: Query results.
        """
    async def traverse_graph(self, node_properties: dict[str, Any], extracted_node_properties: list[str] | None = None, extracted_relationship_properties: list[str] | None = None, depth: int = 3) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
        """Traverse graph from a node with specified properties up to a given depth.

        This traversal ignores relationship direction.

        Args:
            node_properties (dict[str, Any]): Properties of the starting node.
            extracted_node_properties (list[str] | None, optional): Node properties to extract. If None, returns all.
            extracted_relationship_properties (list[str] | None, optional): Relationship properties to extract.
                If None, returns all.
            depth (int, optional): Maximum traversal depth. Defaults to 3.

        Returns:
            tuple[list[dict[str, Any]], list[dict[str, Any]]]: (nodes, relationships)

        Raises:
            ValueError: If node_properties is empty, depth < 1, or property keys are invalid.
        """
    async def close(self) -> None:
        """Close resources held by the data store."""
