from _typeshed import Incomplete
from gllm_datastore.graph_data_store.llama_index_graph_rag_data_store import LlamaIndexGraphRAGDataStore
from gllm_docproc.indexer.graph.graph_rag_indexer import BaseGraphRAGIndexer as BaseGraphRAGIndexer
from gllm_docproc.indexer.graph.utils.schema_validator import validate_kg_schema as validate_kg_schema
from gllm_docproc.model.element import Element as Element
from llama_index.core.base.embeddings.base import BaseEmbedding
from llama_index.core.base.llms.base import BaseLLM
from llama_index.core.schema import TransformComponent as TransformComponent
from llama_index.core.vector_stores.types import BasePydanticVectorStore
from typing import Any

logger: Incomplete

class LlamaIndexGraphRAGIndexer(BaseGraphRAGIndexer):
    """Indexer for graph RAG using LlamaIndex.

    Attributes:
        _index (PropertyGraphIndex): Property graph index.
        _graph_store (LlamaIndexGraphRAGDataStore): Storage for property graph.
        _strict_mode (bool): Whether strict schema validation is enabled.
    """
    def __init__(self, graph_store: LlamaIndexGraphRAGDataStore, llama_index_llm: BaseLLM | None = None, allowed_entity_types: list[str] | None = None, allowed_relation_types: list[str] | None = None, kg_validation_schema: dict[str, list[str]] | None = None, strict_mode: bool = False, kg_extractors: list[TransformComponent] | None = None, embed_model: BaseEmbedding | None = None, vector_store: BasePydanticVectorStore | None = None, max_triplets_per_chunk: int = 10, num_workers: int = 4, **kwargs: Any) -> None:
        '''Initialize the LlamaIndexGraphRAGIndexer.

        Args:
            graph_store (LlamaIndexGraphRAGDataStore): Storage for property graph.
            llama_index_llm (BaseLLM | None, optional): Language model for LlamaIndex. Defaults to None.
                Deprecated: Use graph_store.llm instead. Instantiate the LLM via LlamaIndexGraphRAGDataStore
                (e.g., LlamaIndexGraphRAGDataStore(lm_invoker=...)).
            allowed_entity_types (list[str] | None, optional): List of allowed entity types. When strict_mode=True,
                only these types are extracted. When strict_mode=False, serves as hints. Defaults to None.
            allowed_relation_types (list[str] | None, optional): List of allowed relationship types. Behavior depends
                on strict_mode. Defaults to None.
            kg_validation_schema (dict[str, list[str]] | None, optional): Validation schema for
                strict mode. Maps entity types to their allowed outgoing relationship types.
                Format:
                {"ENTITY_TYPE": ["ALLOWED_REL1", "ALLOWED_REL2"], ...}
                Example: {"PERSON": ["WORKS_AT", "FOUNDED"], "ORGANIZATION": ["LOCATED_IN"]}
                Defaults to None.
            strict_mode (bool, optional): If True, uses SchemaLLMPathExtractor with strict validation.
                If False (default), uses DynamicLLMPathExtractor with optional guidance. Defaults to False.
            kg_extractors (list[TransformComponent] | None, optional): Custom list of extractors.
                If provided, overrides automatic extractor selection based on strict_mode. Defaults to None.
            embed_model (BaseEmbedding | None, optional): Embedding model for vector representations. Defaults to None.
                Deprecated: Use graph_store.embed_model instead. Instantiate the embedding model via
                LlamaIndexGraphRAGDataStore (e.g., LlamaIndexGraphRAGDataStore(em_invoker=...)).
            vector_store (BasePydanticVectorStore | None, optional): Storage for vector data. Defaults to None.
            max_triplets_per_chunk (int, optional): Maximum triplets to extract per chunk. Defaults to 10.
            num_workers (int, optional): Number of parallel workers. Defaults to 4.
            **kwargs (Any): Additional keyword arguments.
        '''
    def index(self, elements: list[dict[str, Any]], **kwargs: Any) -> dict[str, Any]:
        """Index elements into the graph.

        This method indexes elements into the graph. It validates that file_id or document_id is present
        in kwargs and delegates to index_file_chunks. If only document_id is provided, it is used as file_id.

        Args:
            elements (list[dict[str, Any]]): List of dictionaries representing elements to be indexed.
            **kwargs (Any): Additional keyword arguments.

        Kwargs:
            file_id (str, optional): The ID of the file these chunks belong to.
            document_id (str, optional): The document ID. If file_id is not provided, document_id is used as file_id.

        Returns:
            dict[str, Any]: Response with success status, error message, and total count.
                - success (bool): True if indexing succeeded, False otherwise.
                - error_message (str): Error message if indexing failed, empty string otherwise.
                - total (int): The total number of chunks indexed.

        Raises:
            ValueError: If neither file_id nor document_id is provided in kwargs.
        """
    def resolve_entities(self) -> None:
        """Resolve entities in the graph.

        Currently, this method does nothing.
        """
    def delete(self, **kwargs: Any) -> dict[str, Any]:
        """Delete elements from the knowledge graph.

        This method deletes elements from the knowledge graph. It validates that file_id or document_id is present
        in kwargs and delegates to delete_file_chunks. If only document_id is provided, it is used as file_id.

        Args:
            **kwargs (Any): Additional keyword arguments.

        Kwargs:
            file_id (str, optional): The ID of the file whose chunks should be deleted.
            document_id (str, optional): The document ID. If file_id is not provided, document_id is used as file_id.

        Returns:
            dict[str, Any]: Response with success status and error message.
                - success (bool): True if deletion succeeded, False otherwise.
                - error_message (str): Error message if deletion failed, empty string otherwise.

        Raises:
            ValueError: If neither file_id nor document_id is provided in kwargs.
        """
    def index_file_chunks(self, elements: list[dict[str, Any]], file_id: str, **kwargs: Any) -> dict[str, Any]:
        """Index chunks for a specific file.

        This method indexes chunks for a file.

        Notes:
        - Currently only Neo4jPropertyGraphStore that is supported for indexing the metadata from the TextNode.
        - The 'chunk_id' parameter is used to specify the chunk ID for the elements.

        Args:
            elements (list[dict[str, Any]]): The chunks to be indexed.
            file_id (str): The ID of the file these chunks belong to.
            **kwargs (Any): Additional keyword arguments for customization.

        Returns:
            dict[str, Any]: Response with success status, error message, and total count.

        """
    def get_file_chunks(self, file_id: str, page: int = 0, size: int = 20, **kwargs: Any) -> dict[str, Any]:
        """Get chunks for a specific file with pagination support.

        Args:
            file_id (str): The ID of the file to get chunks from.
            page (int, optional): The page number (0-indexed). Defaults to 0.
            size (int, optional): The number of chunks per page. Defaults to 20.
            **kwargs (Any): Additional keyword arguments for customization.

        Returns:
            dict[str, Any]: Response with chunks list, total count, and pagination info.

        Raises:
            NotImplementedError: This method is not yet implemented.
        """
    def delete_file_chunks(self, file_id: str, **kwargs: Any) -> dict[str, Any]:
        """Delete all chunks for a specific file.

        This method deletes all chunks from the knowledge graph based on the provided file_id.

        Args:
            file_id (str): The ID of the file whose chunks should be deleted.
            **kwargs (Any): Additional keyword arguments for customization.

        Returns:
            dict[str, Any]: Response with success status and error message.
        """
    def index_chunk(self, element: dict[str, Any], **kwargs: Any) -> dict[str, Any]:
        """Index a single chunk.

        This method only indexes the chunk. It does NOT update the metadata of neighboring chunks
        (previous_chunk/next_chunk). The caller is responsible for maintaining chunk relationships by updating
        adjacent chunks' metadata separately.

        Args:
            element (dict[str, Any]): The chunk to be indexed.
            **kwargs (Any): Additional keyword arguments for customization.

        Returns:
            dict[str, Any]: Response with success status, error message, and chunk_id.

        Raises:
            NotImplementedError: This method is not yet implemented.
        """
    def get_chunk(self, chunk_id: str, file_id: str, **kwargs: Any) -> dict[str, Any] | None:
        """Get a single chunk by chunk ID and file ID.

        Args:
            chunk_id (str): The ID of the chunk to retrieve.
            file_id (str): The ID of the file the chunk belongs to.
            **kwargs (Any): Additional keyword arguments for customization.

        Returns:
            dict[str, Any] | None: The chunk data, or None if not found.

        Raises:
            NotImplementedError: This method is not yet implemented.
        """
    def update_chunk(self, element: dict[str, Any], **kwargs: Any) -> dict[str, Any]:
        """Update a chunk by chunk ID.

        This method updates both the text content and metadata of a chunk. When text content is updated, the chunk
        should be re-processed through data generators and re-indexed with updated vector embeddings.

        Args:
            element (dict[str, Any]): The updated chunk data.
            **kwargs (Any): Additional keyword arguments for customization.

        Returns:
            dict[str, Any]: Response with success status, error message, and chunk_id.

        Raises:
            NotImplementedError: This method is not yet implemented.
        """
    def update_chunk_metadata(self, chunk_id: str, file_id: str, metadata: dict[str, Any], **kwargs: Any) -> dict[str, Any]:
        """Update metadata for a specific chunk.

        This method patches new metadata into the existing chunk metadata. Existing metadata fields will be
        overwritten, and new fields will be added. System-managed metadata fields (file_id, chunk_id, etc.) should
        be preserved and not overwritten.

        Args:
            chunk_id (str): The ID of the chunk to update.
            file_id (str): The ID of the file the chunk belongs to.
            metadata (dict[str, Any]): The metadata fields to update.
            **kwargs (Any): Additional keyword arguments for customization.

        Returns:
            dict[str, Any]: Response with success status and error message.

        Raises:
            NotImplementedError: This method is not yet implemented.
        """
    def delete_chunk(self, chunk_id: str, file_id: str, **kwargs: Any) -> dict[str, Any]:
        """Delete a single chunk by chunk ID and file ID.

        Args:
            chunk_id (str): The ID of the chunk to delete.
            file_id (str): The ID of the file the chunk belongs to.
            **kwargs (Any): Additional keyword arguments for customization.

        Returns:
            dict[str, Any]: Response with success status and error message.

        Raises:
            NotImplementedError: This method is not yet implemented.
        """
