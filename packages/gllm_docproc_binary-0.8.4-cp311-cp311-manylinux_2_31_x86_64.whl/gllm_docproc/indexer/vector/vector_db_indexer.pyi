from _typeshed import Incomplete
from gllm_datastore.core.capabilities import VectorCapability
from gllm_docproc.indexer import BaseIndexer as BaseIndexer
from gllm_docproc.model.element import Element as Element
from gllm_inference.schema import Vector as Vector
from typing import Any, TypeVar

T = TypeVar('T')

class VectorDBIndexer(BaseIndexer):
    """Index elements into a vector datastore capability."""
    logger: Incomplete
    vector_capability: Incomplete
    def __init__(self, vector_capability: VectorCapability) -> None:
        """Initialize the indexer with an optional vector capability instance.

        Args:
            vector_capability (VectorCapability): The capability implementation
                (for example, `ElasticsearchVectorCapability`) that will receive
                chunks for indexing operations. Must be set before calling
                indexing methods.
        """
    def index(self, elements: list[dict[str, Any]], **kwargs: Any) -> None:
        """Index elements into the configured vector capability.

        Args:
            elements (list[dict[str, Any]]): Parsed elements containing text and metadata.
            **kwargs (Any): Additional keyword arguments for customization.

        Kwargs:
            replace_file_id (str, optional): File identifier to be replaced before indexing.
                Defaults to None. If provided, existing records for this file_id are removed first.
            batch_size (int, optional): The number of chunks to process in each batch.
                Defaults to 100.
            max_retries (int, optional): The maximum number of retry attempts for failed batches.
                Defaults to 3.
            vectors (list[Vector] | None, optional): Pre-computed vectors for the elements.
                If provided, uses create_from_vector instead of create. Must match the length
                of elements. Defaults to None.

        Raises:
            Exception: If an error occurs during indexing.
        """
    def delete(self, **kwargs: Any) -> None:
        """Delete documents from the vector capability based on the file ID.

        Kwargs:
            file_id (str): The ID of the file(s) to be deleted.

        Raises:
            ValueError: If file_id is not provided.
            Exception: If an error occurs during deletion.
        """
    def index_file_chunks(self, elements: list[dict[str, Any]], file_id: str, **kwargs: Any) -> dict[str, Any]:
        """Index chunks for a specific file.

        This method indexes chunks for a file. The indexer is responsible for deleting any existing chunks for the
        file_id before indexing the new chunks to ensure consistency.

        Args:
            elements (list[dict[str, Any]]): The chunks to be indexed.
            file_id (str): The ID of the file these chunks belong to.
            **kwargs (Any): Additional keyword arguments for customization.

        Returns:
            dict[str, Any]: Response with success status, error message, and total count.

        Raises:
            NotImplementedError: This method is not yet implemented.
        """
    def get_file_chunks(self, file_id: str, page: int = 0, size: int = 20, **kwargs: Any) -> dict[str, Any]:
        """Get chunks for a specific file with pagination support.

        Args:
            file_id (str): The ID of the file to get chunks from.
            page (int, optional): The page number (0-indexed). Defaults to 0.
            size (int, optional): The number of chunks per page. Defaults to 20.
            **kwargs (Any): Additional keyword arguments for customization.

        Returns:
            dict[str, Any]: Response with chunks list, total count, and pagination info.

        Raises:
            NotImplementedError: This method is not yet implemented.
        """
    def delete_file_chunks(self, file_id: str, **kwargs: Any) -> dict[str, Any]:
        """Delete all chunks for a specific file.

        Args:
            file_id (str): The ID of the file whose chunks should be deleted.
            **kwargs (Any): Additional keyword arguments for customization.

        Returns:
            dict[str, Any]: Response with success status and error message.

        Raises:
            NotImplementedError: This method is not yet implemented.
        """
    def index_chunk(self, element: dict[str, Any], **kwargs: Any) -> dict[str, Any]:
        """Index a single chunk.

        This method only indexes the chunk. It does NOT update the metadata of neighboring chunks
        (previous_chunk/next_chunk). The caller is responsible for maintaining chunk relationships by updating
        adjacent chunks' metadata separately.

        Args:
            element (dict[str, Any]): The chunk to be indexed.
            **kwargs (Any): Additional keyword arguments for customization.

        Returns:
            dict[str, Any]: Response with success status, error message, and chunk_id.

        Raises:
            NotImplementedError: This method is not yet implemented.
        """
    def get_chunk(self, chunk_id: str, file_id: str, **kwargs: Any) -> dict[str, Any] | None:
        """Get a single chunk by chunk ID and file ID.

        Args:
            chunk_id (str): The ID of the chunk to retrieve.
            file_id (str): The ID of the file the chunk belongs to.
            **kwargs (Any): Additional keyword arguments for customization.

        Returns:
            dict[str, Any] | None: The chunk data, or None if not found.

        Raises:
            NotImplementedError: This method is not yet implemented.
        """
    def update_chunk(self, element: dict[str, Any], **kwargs: Any) -> dict[str, Any]:
        """Update a chunk by chunk ID.

        This method updates both the text content and metadata of a chunk. When text content is updated, the chunk
        should be re-processed through data generators and re-indexed with updated vector embeddings.

        Args:
            element (dict[str, Any]): The updated chunk data.
            **kwargs (Any): Additional keyword arguments for customization.

        Returns:
            dict[str, Any]: Response with success status, error message, and chunk_id.

        Raises:
            NotImplementedError: This method is not yet implemented.
        """
    def update_chunk_metadata(self, chunk_id: str, file_id: str, metadata: dict[str, Any], **kwargs: Any) -> dict[str, Any]:
        """Update metadata for a specific chunk.

        This method patches new metadata into the existing chunk metadata. Existing metadata fields will be
        overwritten, and new fields will be added. System-managed metadata fields (file_id, chunk_id, etc.) should
        be preserved and not overwritten.

        Args:
            chunk_id (str): The ID of the chunk to update.
            file_id (str): The ID of the file the chunk belongs to.
            metadata (dict[str, Any]): The metadata fields to update.
            **kwargs (Any): Additional keyword arguments for customization.

        Returns:
            dict[str, Any]: Response with success status and error message.

        Raises:
            NotImplementedError: This method is not yet implemented.
        """
    def delete_chunk(self, chunk_id: str, file_id: str, **kwargs: Any) -> dict[str, Any]:
        """Delete a single chunk by chunk ID and file ID.

        Args:
            chunk_id (str): The ID of the chunk to delete.
            file_id (str): The ID of the file the chunk belongs to.
            **kwargs (Any): Additional keyword arguments for customization.

        Returns:
            dict[str, Any]: Response with success status and error message.

        Raises:
            NotImplementedError: This method is not yet implemented.
        """
