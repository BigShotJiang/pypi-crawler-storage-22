from _typeshed import Incomplete
from gllm_datastore.core.capabilities import VectorCapability
from gllm_datastore.data_store.base import BaseDataStore as BaseDataStore
from gllm_inference.em_invoker.em_invoker import BaseEMInvoker as BaseEMInvoker
from typing import Any

logger: Incomplete

def dict_to_hashable(dict_obj: dict[str, Any]) -> frozenset[tuple[str, Any]]:
    """Recursively convert a dictionary to a hashable frozenset.

    Converts dicts to frozensets and lists to tuples, making the entire structure hashable.
    Items are sorted to ensure consistent hashable representation regardless of insertion order.
    This is useful for caching dictionaries with nested structures.

    Args:
        dict_obj (dict[str, Any]): Dictionary to convert.

    Returns:
        frozenset[tuple[str, Any]]: Hashable frozenset representation of the dictionary.
            Each element is a (key, value) pair where nested dicts and lists are recursively converted.
            Items are sorted by key for consistent hashing.
    """
def hashable_to_dict(hashable: frozenset[tuple[str, Any]]) -> dict[str, Any]:
    """Recursively convert a hashable frozenset back to a dictionary.

    Converts frozensets back to dicts and tuples back to lists.

    Args:
        hashable (frozenset[tuple[str, Any]]): Hashable frozenset representation to convert.

    Returns:
        dict[str, Any]: Dictionary representation of the hashable structure.
    """
def create_vector_db(vectorizer_kwargs: dict[str, Any], db_config: dict[str, Any], embedding_class: type[BaseEMInvoker], data_store_class: type[BaseDataStore]) -> VectorCapability:
    """Create a vector capability instance.

    This function initializes the embedding class and BaseDataStore class. The vector
    capability is accessed via the BaseDataStore's `.vector` property after calling `.with_vector()`.

    Args:
        vectorizer_kwargs (dict[str, Any]): Vectorizer configuration that must follow the
            embedding_class.__init__ signature.
        db_config (dict[str, Any]): Vector DB configuration that must follow the
            data_store_class.__init__ signature and the with_vector() method signature.
        embedding_class (Type[BaseEMInvoker]): The embedding model invoker class to instantiate.
        data_store_class (Type[BaseDataStore]): The data store class to instantiate.

    Returns:
        VectorCapability: The initialized vector capability instance accessed via `.vector` property.

    Raises:
        ValueError: If invalid parameters are provided.
    """
