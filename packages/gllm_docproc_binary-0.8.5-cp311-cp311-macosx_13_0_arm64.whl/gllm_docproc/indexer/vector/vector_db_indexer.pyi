from _typeshed import Incomplete
from gllm_datastore.data_store.base import BaseDataStore as BaseDataStore
from gllm_docproc.indexer import BaseIndexer as BaseIndexer
from gllm_docproc.indexer.vector.utils import create_vector_db as create_vector_db, dict_to_hashable as dict_to_hashable, hashable_to_dict as hashable_to_dict
from gllm_docproc.model.element import Element as Element
from gllm_inference.em_invoker.em_invoker import BaseEMInvoker as BaseEMInvoker
from typing import Any, TypeVar

T = TypeVar('T')
DEFAULT_BATCH_SIZE: int
DEFAULT_MAX_RETRIES: int
DEFAULT_CACHE_SIZE: int
DEFAULT_DATA_STORE_MAP: Incomplete
DEFAULT_EM_INVOKER_MAP: Incomplete
DEFAULT_RETRYABLE_EXCEPTIONS: Incomplete

class VectorDBIndexer(BaseIndexer):
    """Index elements into a vector datastore capability."""
    logger: Incomplete
    data_store_map: Incomplete
    em_invoker_map: Incomplete
    retryable_exceptions: Incomplete
    def __init__(self, data_store_map: dict[str, type[BaseDataStore]] | None = None, em_invoker_map: dict[str, type[BaseEMInvoker]] | None = None, cache_size: int = ..., retryable_exceptions: tuple[type[Exception], ...] | None = None) -> None:
        '''Initialize the indexer with mappings for vector DB capabilities and embeddings.

        Args:
            data_store_map (dict[str, Type[BaseDataStore]] | None, optional): Mapping of db_engine strings
                to BaseDataStore classes. If not provided, uses DEFAULT_DATA_STORE_MAP which includes
                "chroma", "elasticsearch", and "opensearch". Defaults to None.
            em_invoker_map (dict[str, Type[BaseEMInvoker]] | None, optional): Mapping of provider strings
                to embedding classes (BaseEMInvoker subclasses). If not provided, uses DEFAULT_EM_INVOKER_MAP
                which includes "azure-openai", "bedrock", "google", "openai", and "voyage". Defaults to None.
            cache_size (int, optional): Maximum number of vector capability instances to cache using LRU policy.
                Defaults to DEFAULT_CACHE_SIZE (128).
            retryable_exceptions (tuple[type[Exception], ...] | None, optional): Tuple of exception types
                to retry on during batch processing. Defaults to DEFAULT_RETRYABLE_EXCEPTIONS.
        '''
    def index(self, elements: list[dict[str, Any]], **kwargs: Any) -> dict[str, Any]:
        '''Index elements into the configured vector capability.

        This method validates that file_id is present in kwargs and delegates to index_file_chunks.

        Args:
            elements (list[dict[str, Any]]): Parsed elements containing text and metadata.
            **kwargs (Any): Additional keyword arguments for customization.

        Kwargs:
            file_id (str): The ID of the file these chunks belong to.
            vectorizer_kwargs (dict[str, Any]): Vectorizer configuration containing "model" key
                in format "provider/model_name" (e.g., "openai/text-embedding-ada-002").
            db_engine (str): The database engine to use (e.g., "chroma", "elasticsearch", "opensearch").
            db_config (dict[str, Any]): Vector DB configuration.
            batch_size (int, optional): The number of chunks to process in each batch.
                Defaults to 100.
            max_retries (int, optional): The maximum number of retry attempts for failed batches.
                Defaults to 3.

        Returns:
            dict[str, Any]: Response with success status, error message, and total count.
                - success (bool): True if indexing succeeded, False otherwise.
                - error_message (str): Error message if indexing failed, empty string otherwise.
                - total (int): The total number of chunks indexed.

        Raises:
            ValueError: If file_id is not provided in kwargs.
        '''
    def delete(self, **kwargs: Any) -> dict[str, Any]:
        '''Delete documents from the vector capability based on the file ID.

        This method validates that file_id is present in kwargs and delegates to delete_file_chunks.

        Kwargs:
            file_id (str): The ID of the file(s) to be deleted.
            vectorizer_kwargs (dict[str, Any]): Vectorizer configuration containing "model" key
                in format "provider/model_name" (e.g., "openai/text-embedding-ada-002").
            db_engine (str): The database engine to use (e.g., "chroma", "elasticsearch", "opensearch").
            db_config (dict[str, Any]): Vector DB configuration.

        Returns:
            dict[str, Any]: Response with success status and error message.
                - success (bool): True if deletion succeeded, False otherwise.
                - error_message (str): Error message if deletion failed, empty string otherwise.

        Raises:
            ValueError: If file_id is not provided in kwargs.
        '''
    def index_file_chunks(self, elements: list[dict[str, Any]], file_id: str, **kwargs: Any) -> dict[str, Any]:
        '''Index chunks for a specific file.

        This method indexes chunks for a file. The indexer is responsible for deleting any existing
        chunks for the file_id before indexing the new chunks to ensure consistency.

        Args:
            elements (list[dict[str, Any]]): The chunks to be indexed.
            file_id (str): The ID of the file these chunks belong to.
            **kwargs (Any): Additional keyword arguments for customization.

        Kwargs:
            vectorizer_kwargs (dict[str, Any]): Vectorizer configuration containing "model" key
                in format "provider/model_name" (e.g., "openai/text-embedding-ada-002").
            db_engine (str): The database engine to use (e.g., "chroma", "elasticsearch", "opensearch").
            db_config (dict[str, Any]): Vector DB configuration.
            batch_size (int, optional): The number of chunks to process in each batch.
                Defaults to 100.
            max_retries (int, optional): The maximum number of retry attempts for failed batches.
                Defaults to 3.

        Returns:
            dict[str, Any]: Response with success status, error message, and total count.
        '''
    def delete_file_chunks(self, file_id: str, **kwargs: Any) -> dict[str, Any]:
        '''Delete all chunks for a specific file.

        - No index: treated as success (nothing to delete).
        - Index exists, no matching chunks: success.
        - Index exists, matching chunks: success if delete succeeds, otherwise failed.

        Args:
            file_id (str): The ID of the file whose chunks should be deleted.
            **kwargs (Any): Additional keyword arguments for customization.

        Kwargs:
            vectorizer_kwargs (dict[str, Any]): Vectorizer configuration containing "model" key
                in format "provider/model_name" (e.g., "openai/text-embedding-ada-002").
            db_engine (str): The database engine to use (e.g., "chroma", "elasticsearch", "opensearch").
            db_config (dict[str, Any]): Vector DB configuration.

        Returns:
            dict[str, Any]: Response with success status and error message.
        '''
    def get_file_chunks(self, file_id: str, page: int = 0, size: int = 20, **kwargs: Any) -> dict[str, Any]:
        """Get chunks for a specific file with pagination support.

        Args:
            file_id (str): The ID of the file to get chunks from.
            page (int, optional): The page number (0-indexed). Defaults to 0.
            size (int, optional): The number of chunks per page. Defaults to 20.
            **kwargs (Any): Additional keyword arguments for customization.

        Returns:
            dict[str, Any]: Response with chunks list, total count, and pagination info.

        Raises:
            NotImplementedError: This method is not yet implemented.
        """
    def index_chunk(self, element: dict[str, Any], **kwargs: Any) -> dict[str, Any]:
        """Index a single chunk.

        This method only indexes the chunk. It does NOT update the metadata of neighboring chunks
        (previous_chunk/next_chunk). The caller is responsible for maintaining chunk relationships by updating
        adjacent chunks' metadata separately.

        Args:
            element (dict[str, Any]): The chunk to be indexed.
            **kwargs (Any): Additional keyword arguments for customization.

        Returns:
            dict[str, Any]: Response with success status, error message, and chunk_id.

        Raises:
            NotImplementedError: This method is not yet implemented.
        """
    def get_chunk(self, chunk_id: str, file_id: str, **kwargs: Any) -> dict[str, Any] | None:
        """Get a single chunk by chunk ID and file ID.

        Args:
            chunk_id (str): The ID of the chunk to retrieve.
            file_id (str): The ID of the file the chunk belongs to.
            **kwargs (Any): Additional keyword arguments for customization.

        Returns:
            dict[str, Any] | None: The chunk data, or None if not found.

        Raises:
            NotImplementedError: This method is not yet implemented.
        """
    def update_chunk(self, element: dict[str, Any], **kwargs: Any) -> dict[str, Any]:
        """Update a chunk by chunk ID.

        This method updates both the text content and metadata of a chunk. When text content is updated, the chunk
        should be re-processed through data generators and re-indexed with updated vector embeddings.

        Args:
            element (dict[str, Any]): The updated chunk data.
            **kwargs (Any): Additional keyword arguments for customization.

        Returns:
            dict[str, Any]: Response with success status, error message, and chunk_id.

        Raises:
            NotImplementedError: This method is not yet implemented.
        """
    def update_chunk_metadata(self, chunk_id: str, file_id: str, metadata: dict[str, Any], **kwargs: Any) -> dict[str, Any]:
        """Update metadata for a specific chunk.

        This method patches new metadata into the existing chunk metadata. Existing metadata fields will be
        overwritten, and new fields will be added. System-managed metadata fields (file_id, chunk_id, etc.) should
        be preserved and not overwritten.

        Args:
            chunk_id (str): The ID of the chunk to update.
            file_id (str): The ID of the file the chunk belongs to.
            metadata (dict[str, Any]): The metadata fields to update.
            **kwargs (Any): Additional keyword arguments for customization.

        Returns:
            dict[str, Any]: Response with success status and error message.

        Raises:
            NotImplementedError: This method is not yet implemented.
        """
    def delete_chunk(self, chunk_id: str, file_id: str, **kwargs: Any) -> dict[str, Any]:
        """Delete a single chunk by chunk ID and file ID.

        Args:
            chunk_id (str): The ID of the chunk to delete.
            file_id (str): The ID of the file the chunk belongs to.
            **kwargs (Any): Additional keyword arguments for customization.

        Returns:
            dict[str, Any]: Response with success status and error message.

        Raises:
            NotImplementedError: This method is not yet implemented.
        """
