from _typeshed import Incomplete
from gllm_inference.em_invoker.vector_fuser.vector_fuser import BaseVectorFuser as BaseVectorFuser
from gllm_inference.schema import Vector as Vector

class AverageVectorFuser(BaseVectorFuser):
    """A vector fuser that averages a list of vectors into a single vector.

    Examples:
        Input:
            [[a1, a2, a3, a4], [b1, b2, b3, b4]]
        Output:
            [(a1 + b1) / 2, (a2 + b2) / 2, (a3 + b3) / 2, (a4 + b4) / 2]

        Input (with weights=[0.7, 0.3]):
            [[a1, a2, a3, a4], [b1, b2, b3, b4]]
        Output:
            [
                (a1 * 0.7 + b1 * 0.3),
                (a2 * 0.7 + b2 * 0.3),
                (a3 * 0.7 + b3 * 0.3),
                (a4 * 0.7 + b4 * 0.3)
            ]

    Attributes:
        weights (list[float] | None): The weights for the weighted average.
            If None, regular average is performed. Defaults to None.
    """
    weights: Incomplete
    def __init__(self, weights: list[float] | None = None) -> None:
        """Initializes the AverageVectorFuser.

        Args:
            weights (list[float] | None, optional): The weights for the weighted average.
                If None, regular average is performed. Defaults to None.
        """
