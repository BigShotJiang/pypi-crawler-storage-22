from _typeshed import Incomplete
from enum import Enum, StrEnum as StrEnum
from typing import TypeVar

E = TypeVar('E', bound=Enum)
SAFE_URL_SCHEMES: Incomplete
LOCALHOSTS: Incomplete
logger: Incomplete

def validate_string_enum(enum_type: type[StrEnum], value: str) -> None:
    """Validates that the provided value is a valid string enum value.

    Args:
        enum_type (type[StrEnum]): The type of the string enum.
        value (str): The value to validate.

    Raises:
        ValueError: If the provided value is not a valid string enum value.
    """
def validate_enum(enum_type: type[E], value: object) -> None:
    """Validates that the provided value is a valid enum value.

    Args:
        enum_type (type[E]): The type of the enum.
        value (object): The value to validate.

    Raises:
        ValueError: If the provided value is not a valid enum value.
    """
def is_valid_url(text: str) -> bool:
    """Check if a URL is valid.

    This method validate URL format and rejects dangerous schemes and private/local addresses.

    Args:
        text (str): The URL string to validate.

    Returns:
        bool: True if URL is valid, False otherwise.
    """
def redact_url_for_logging(url: str, max_length: int = 50) -> str:
    '''Redact sensitive information from URL for safe logging.

    Removes query parameters and fragments that may contain API keys, tokens, or other
    sensitive data. Truncates to max_length if needed.

    Args:
        url (str): The URL to redact.
        max_length (int, optional): Maximum length of returned string. Defaults to 50.

    Returns:
        str: Redacted URL safe for logging (scheme + hostname + path only).

    Examples:
        ```python
        # Full URL with sensitive query params
        url = "https://example.com/image.jpg?token=secret123&api_key=sk-1234"
        redacted = redact_url_for_logging(url)
        # Returns: "https://example.com/image.jpg"

        # URL with fragment
        url = "https://example.com/file.pdf#section=secret"
        redacted = redact_url_for_logging(url)
        # Returns: "https://example.com/file.pdf"

        # Long URL gets truncated
        url = "https://very-long-domain-name.example.com/path/to/very/long/file.jpg"
        redacted = redact_url_for_logging(url, max_length=30)
        # Returns: "https://very-long-domain-n..."
        ```
    '''
