## Module: `{{ path }}`

**Lines:** {{ lines }}
**Priority:** {{ priority }}
**Reviewers required:** {{ reviewers_required }}

### Module Contents
{{ module_contents }}

{% if previous_commit %}
### Changes Since Last Review

**Previous review:** {{ previous_commit }} ({{ previous_date }})
**Current HEAD:** {{ current_commit }}

[View diff]({{ diff_url }})

**Previous reviewers:** {{ previous_reviewers }}
{% else %}
### First Review

This module has not been formally reviewed before.

**Current HEAD:** {{ current_commit }}
{% endif %}

---

## Review Checklist

### Correctness
- [ ] Algorithm correctly implements intended logic
- [ ] Edge cases handled (empty input, boundaries, None)
- [ ] Error handling is appropriate and messages are clear

### Scientific Rigor
- [ ] Numerical operations are stable (no overflow/division-by-zero)
- [ ] Units and dimensions are consistent
- [ ] Implementation matches established methods

### Robustness
- [ ] Inputs validated at module boundaries
- [ ] Resources properly managed (files closed, memory reasonable)

### Maintainability
- [ ] Code is readable and well-structured
- [ ] Public functions have docstrings
- [ ] No unnecessary complexity

---

## Findings

_Add findings below. Use `glreview claude-review {{ path }}` for AI-assisted review._

---

When complete, close this issue and run:
```
glreview signoff {{ path }}
```
