"""Custom exceptions for glreview."""

from __future__ import annotations


class ReviewError(Exception):
    """Base exception for review errors."""

    pass


class ModuleNotFoundError(ReviewError):
    """Module not found in registry."""

    def __init__(self, path: str):
        self.path = path
        super().__init__(f"Module not found in registry: {path}")


class InvalidStateTransitionError(ReviewError):
    """Invalid state transition."""

    def __init__(
        self, current: str, target: str, valid_targets: list[str] | None = None
    ):
        self.current = current
        self.target = target
        self.valid_targets = valid_targets or []

        msg = f"Cannot transition from '{current}' to '{target}'"
        if valid_targets:
            msg += f". Valid transitions: {valid_targets}"
        super().__init__(msg)


class AlreadyInStateError(ReviewError):
    """Module is already in the requested state."""

    def __init__(self, path: str, status: str):
        self.path = path
        self.status = status
        super().__init__(f"{path} is already in '{status}' status")


class GitError(ReviewError):
    """Git operation failed."""

    def __init__(self, operation: str, message: str):
        self.operation = operation
        super().__init__(f"Git {operation} failed: {message}")


class GitLabError(ReviewError):
    """GitLab API error."""

    def __init__(self, operation: str, message: str):
        self.operation = operation
        super().__init__(f"GitLab {operation} failed: {message}")


class GitLabNotAvailableError(GitLabError):
    """GitLab API not available (no token)."""

    def __init__(self):
        super().__init__("authentication", "No GitLab token configured")


class IssueNotClosedError(ReviewError):
    """Issue is not closed."""

    def __init__(self, issue_number: str, state: str):
        self.issue_number = issue_number
        self.state = state
        super().__init__(f"Issue #{issue_number} is not closed (state: {state})")


class FileChangedDuringReviewError(ReviewError):
    """File changed during review."""

    def __init__(self, path: str, start_commit: str, current_commit: str):
        self.path = path
        self.start_commit = start_commit
        self.current_commit = current_commit
        super().__init__(
            f"{path} changed during review "
            f"(started at {start_commit}, now at {current_commit})"
        )


class ConfigurationError(ReviewError):
    """Configuration error."""

    pass
