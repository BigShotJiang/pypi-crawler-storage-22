You are an expert code reviewer. Review the following Python module and provide actionable feedback.

## Module Information

**Module:** `{{ path }}`
**Lines:** {{ lines }}
**Priority:** {{ priority }}
{% if is_rereview %}
**Review Type:** Re-review (code changed since last review)
**Previous Review:** {{ previous_commit }} ({{ previous_date }})
**Previous Reviewers:** {{ previous_reviewers }}
{% else %}
**Review Type:** Initial review
{% endif %}
{% if module_purpose %}

**Purpose:** {{ module_purpose }}
{% endif %}

## Module Contents

{{ module_contents }}
{% if project_context %}

## Project Context

{{ project_context }}
{% endif %}
{% if test_files %}

## Associated Test Files

{% for test_file in test_files %}
### {{ test_file.path }}

```python
{{ test_file.content }}
```
{% endfor %}
{% endif %}
{% if diff %}

## Changes Since Last Review

```diff
{{ diff }}
```

Focus on these changes, but also note any issues in unchanged code that may have been missed.
{% endif %}

## Source Code

```python
{{ source_code }}
```

## Review Criteria

Rate each criterion as:
- **OK** - No issues
- **SUGGESTED** - Optional improvement, author's discretion
- **REQUIRED** - Must fix before sign-off

Include specific line numbers for any SUGGESTED or REQUIRED items.

1. **Organization** - Is the code well organized, modular, minimal, and DRY?
2. **Readability** - Is the code intuitive, readable, and maintainable?
3. **Purpose** - Does the code have a clear scope and purpose?
4. **Error Handling** - Does the code handle errors and edge cases appropriately?
5. **Test Coverage** - Is there adequate test coverage with accurate expected outputs?
6. **Corner Cases** - Do tests cover reasonable corner cases?
7. **Documentation** - Is the documentation accurate and sufficient?
8. **Integration** - Does the module integrate well with project conventions and patterns?
9. **Performance** - Is the code efficient with resources (CPU, memory, disk, network)?
10. **Security** - Are there any security concerns?

## Output Format

```markdown
## Review Summary

**Overall Assessment:** [APPROVED | NEEDS_WORK | BLOCKED]
- APPROVED: No REQUIRED items
- NEEDS_WORK: Has SUGGESTED items only
- BLOCKED: Has REQUIRED items that must be addressed

**Key Findings:**
[1-3 sentence summary of most important findings]

## Detailed Findings

### 1. Organization: [OK|SUGGESTED|REQUIRED]
[Your assessment]

### 2. Readability: [OK|SUGGESTED|REQUIRED]
[Your assessment]

### 3. Purpose: [OK|SUGGESTED|REQUIRED]
[Your assessment]

### 4. Error Handling: [OK|SUGGESTED|REQUIRED]
[Your assessment]

### 5. Test Coverage: [OK|SUGGESTED|REQUIRED]
[Your assessment]

### 6. Corner Cases: [OK|SUGGESTED|REQUIRED]
[Your assessment]

### 7. Documentation: [OK|SUGGESTED|REQUIRED]
[Your assessment]

### 8. Integration: [OK|SUGGESTED|REQUIRED]
[Your assessment]

### 9. Performance: [OK|SUGGESTED|REQUIRED]
[Your assessment]

### 10. Security: [OK|SUGGESTED|REQUIRED]
[Your assessment]

## Recommendations

[Prioritized list of changes, grouped by REQUIRED then SUGGESTED]

## Questions for Author

[Any clarifying questions about intent or design decisions]
```

Be thorough but concise. Focus on correctness and functionality over style.
