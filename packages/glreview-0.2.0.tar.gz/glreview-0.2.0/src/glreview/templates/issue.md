## Module: `{{ path }}`

**Lines:** {{ lines }}
**Priority:** {{ priority }}
**Reviewers required:** {{ reviewers_required }}

### Module Contents
{{ module_contents }}

{% if previous_commit %}
### Changes Since Last Review

**Previous review:** {{ previous_commit }} ({{ previous_date }})
**Current HEAD:** {{ current_commit }}

[View diff]({{ diff_url }})

**Previous reviewers:** {{ previous_reviewers }}
{% else %}
### First Review

This module has not been formally reviewed before.

**Current HEAD:** {{ current_commit }}
{% endif %}

---

## Review Checklist

Rate each item: **OK** | **SUGGESTED** | **REQUIRED**
- OK: No issues
- SUGGESTED: Optional improvement, author's discretion
- REQUIRED: Must fix before sign-off

| # | Criterion | Rating | Notes |
|---|-----------|--------|-------|
| 1 | **Organization** - Well organized, modular, minimal, DRY? | | |
| 2 | **Readability** - Intuitive, readable, maintainable? | | |
| 3 | **Purpose** - Clear scope and purpose? | | |
| 4 | **Error Handling** - Handles errors and edge cases? | | |
| 5 | **Test Coverage** - Adequate coverage with accurate expected outputs? | | |
| 6 | **Corner Cases** - Tests cover reasonable corner cases? | | |
| 7 | **Documentation** - Accurate and sufficient? | | |
| 8 | **Integration** - Follows project conventions and patterns? | | |
| 9 | **Performance** - Efficient with resources? | | |
| 10 | **Security** - Any security concerns? | | |

---

## Findings

_Add detailed findings below. Use `glreview claude-review {{ path }}` for AI-assisted review._

---

When complete (no REQUIRED items remaining), close this issue and run:
```
glreview signoff {{ path }}
```
