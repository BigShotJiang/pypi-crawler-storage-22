"""Tests for glreview.config module."""

from __future__ import annotations

from pathlib import Path

import pytest

from glreview.config import Config, find_project_root, load_config


class TestConfig:
    """Tests for Config dataclass."""

    def test_default_values(self):
        """Default values are correct."""
        config = Config()
        assert config.sources == []  # No default - must be configured
        assert config.exclude == []  # No default
        assert config.registry == ".glreview/registry.json"
        assert config.issue_labels == ["review::pending"]
        assert config.issue_template is None
        assert config.teams == {}

    def test_custom_values(self):
        """Custom values are stored."""
        config = Config(
            sources=["lib/**/*.py"],
            exclude=["**/test_*.py"],
            registry="custom_registry.json",
            issue_labels=["review", "code-quality"],
            issue_template="templates/issue.md",
            teams={"core": ["@alice", "@bob"]},
        )
        assert config.sources == ["lib/**/*.py"]
        assert config.exclude == ["**/test_*.py"]
        assert config.registry == "custom_registry.json"
        assert config.issue_labels == ["review", "code-quality"]
        assert config.issue_template == "templates/issue.md"
        assert config.teams == {"core": ["@alice", "@bob"]}

    def test_registry_path(self, temp_dir):
        """registry_path returns absolute path."""
        config = Config(root=temp_dir, registry="my_registry.json")
        assert config.registry_path == temp_dir / "my_registry.json"


class TestLoadConfig:
    """Tests for load_config function."""

    def test_load_defaults_no_pyproject(self, temp_dir):
        """Returns defaults when no pyproject.toml."""
        config = load_config(temp_dir)
        assert config.sources == []  # No default - must be configured
        assert config.exclude == []
        assert config.root == temp_dir

    def test_load_from_pyproject(self, temp_dir):
        """Loads config from pyproject.toml."""
        pyproject = temp_dir / "pyproject.toml"
        pyproject.write_text("""
[tool.glreview]
sources = ["lib/**/*.py", "src/**/*.py"]
exclude = ["**/test_*.py", "**/_version.py"]
registry = "custom_registry.json"
issue_labels = ["review", "needs-attention"]
issue_template = "templates/review_issue.md"

[tool.glreview.teams]
core = ["@alice", "@bob"]
docs = ["@charlie"]
""")
        config = load_config(temp_dir)

        assert config.sources == ["lib/**/*.py", "src/**/*.py"]
        assert config.exclude == ["**/test_*.py", "**/_version.py"]
        assert config.registry == "custom_registry.json"
        assert config.issue_labels == ["review", "needs-attention"]
        assert config.issue_template == "templates/review_issue.md"
        assert config.teams == {"core": ["@alice", "@bob"], "docs": ["@charlie"]}

    def test_load_partial_config(self, temp_dir):
        """Loads partial config, using defaults for missing."""
        pyproject = temp_dir / "pyproject.toml"
        pyproject.write_text("""
[tool.glreview]
sources = ["custom/**/*.py"]
""")
        config = load_config(temp_dir)

        assert config.sources == ["custom/**/*.py"]
        # Defaults for missing
        assert config.exclude == []
        assert config.registry == ".glreview/registry.json"

    def test_load_empty_glreview_section(self, temp_dir):
        """Handles empty glreview section - sources required but empty."""
        pyproject = temp_dir / "pyproject.toml"
        pyproject.write_text("""
[tool.glreview]
""")
        config = load_config(temp_dir)
        assert config.sources == []  # No default

    def test_load_no_glreview_section(self, temp_dir):
        """Handles pyproject.toml without glreview section."""
        pyproject = temp_dir / "pyproject.toml"
        pyproject.write_text("""
[tool.black]
line-length = 88
""")
        config = load_config(temp_dir)
        assert config.sources == []  # No default


class TestFindProjectRoot:
    """Tests for find_project_root function."""

    def test_finds_pyproject(self, temp_dir):
        """Finds directory with pyproject.toml."""
        pyproject = temp_dir / "pyproject.toml"
        pyproject.write_text("[project]\nname = 'test'\n")

        subdir = temp_dir / "src" / "subdir"
        subdir.mkdir(parents=True)

        root = find_project_root(subdir)
        # Resolve both to handle symlinks (e.g., macOS /var -> /private/var)
        assert root == temp_dir.resolve()

    def test_finds_git_dir(self, temp_dir):
        """Finds directory with .git."""
        git_dir = temp_dir / ".git"
        git_dir.mkdir()

        subdir = temp_dir / "src" / "subdir"
        subdir.mkdir(parents=True)

        root = find_project_root(subdir)
        # Resolve both to handle symlinks (e.g., macOS /var -> /private/var)
        assert root == temp_dir.resolve()

    def test_prefers_pyproject_over_git(self, temp_dir):
        """Prefers pyproject.toml over .git when both exist."""
        # Create .git in parent
        git_dir = temp_dir / ".git"
        git_dir.mkdir()

        # Create pyproject.toml in subdir
        subdir = temp_dir / "subproject"
        subdir.mkdir()
        pyproject = subdir / "pyproject.toml"
        pyproject.write_text("[project]\nname = 'test'\n")

        inner = subdir / "src"
        inner.mkdir()

        root = find_project_root(inner)
        # Resolve both to handle symlinks (e.g., macOS /var -> /private/var)
        assert root == subdir.resolve()

    def test_falls_back_to_start(self, temp_dir):
        """Falls back to start directory when nothing found."""
        subdir = temp_dir / "orphan"
        subdir.mkdir()

        root = find_project_root(subdir)
        assert root == subdir.resolve()

    def test_defaults_to_cwd(self):
        """Defaults to current working directory."""
        # This should not raise
        root = find_project_root()
        assert root.exists()
