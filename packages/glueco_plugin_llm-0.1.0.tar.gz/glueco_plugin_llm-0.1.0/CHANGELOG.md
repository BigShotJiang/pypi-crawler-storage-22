# Changelog

All notable changes to this project will be documented in this file.

## [0.1.0] - 2026-02-09

### ✨ Added

- Initial release
- `LLMClient` with `chat_completions()` and `chat_completions_stream()` methods
- Typed messages: `ChatMessage`, `ChatCompletionRequest`
- Typed responses: `ChatCompletion`, `ChatCompletionChoice`, `ChatCompletionUsage`
- Streaming types: `ChatCompletionChunk`, `ChatCompletionChunkChoice`, `ChatCompletionChunkDelta`
- Support for OpenAI, Groq, Gemini providers
- Factory function `llm_client(transport)` for easy setup
