"""
Glueco LLM Plugin

Provides typed chat completion support for the Glueco Gateway SDK.
Supports OpenAI, Groq, Gemini, and other LLM providers.

Example:
    >>> from glueco_sdk import create_transport
    >>> from glueco_plugin_llm import llm_client
    >>> 
    >>> transport = create_transport(proxy_url="...", app_id="...")
    >>> llm = llm_client(transport)
    >>> 
    >>> response = llm.chat_completions(
    ...     provider="groq",
    ...     model="llama-3.1-8b-instant",
    ...     messages=[{"role": "user", "content": "Hello!"}],
    ... )
    >>> print(response.content)
"""

__version__ = "0.1.0"

# Main client factory
from .client import llm_client, LLMClient

# Types
from .types import (
    ChatMessage,
    ChatCompletionRequest,
    ChatCompletion,
    ChatCompletionChoice,
    ChatCompletionUsage,
    ChatCompletionChunk,
    ChatCompletionChunkChoice,
    ChatCompletionChunkDelta,
)

__all__ = [
    # Version
    "__version__",
    # Client
    "llm_client",
    "LLMClient",
    # Types
    "ChatMessage",
    "ChatCompletionRequest",
    "ChatCompletion",
    "ChatCompletionChoice",
    "ChatCompletionUsage",
    "ChatCompletionChunk",
    "ChatCompletionChunkChoice",
    "ChatCompletionChunkDelta",
]
