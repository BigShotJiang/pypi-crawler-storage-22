"""Integration tests for the Python CCDB bindings."""

from __future__ import annotations

import datetime as dt
import os
from pathlib import Path

import gluex_ccdb
import pytest

TABLE_PATH = "/test/demo/mytable"
FIRST_AVAILABLE = dt.datetime(2013, 2, 22, 19, 40, 35, tzinfo=dt.timezone.utc)


def resolve_db_path() -> Path:
    raw = os.environ.get("CCDB_CONNECTION")
    if not raw:
        raise RuntimeError("CCDB_CONNECTION must be set for CCDB tests")
    return Path(raw)


@pytest.fixture(scope="module")
def db() -> gluex_ccdb.CCDB:
    return gluex_ccdb.CCDB(str(resolve_db_path()))


def test_directory_and_table_metadata(db: gluex_ccdb.CCDB):
    root = db.root()
    assert root.full_path() == "/"

    test_dir = db.dir("/test")
    assert test_dir.full_path() == "/test"

    demo_dir = test_dir.dir("demo")
    assert demo_dir.full_path() == "/test/demo"

    table = demo_dir.table("mytable")
    assert table.full_path() == TABLE_PATH

    meta = table.meta
    assert meta.n_rows == 2
    assert meta.n_columns == 3

    columns = table.columns()
    assert [c.name for c in columns] == ["x", "y", "z"]
    assert [c.column_type.name for c in columns] == ["double", "double", "double"]


def test_fetch_across_runs_timestamps_and_variations(db: gluex_ccdb.CCDB):
    table = db.table(TABLE_PATH)

    before_first = db.fetch(
        TABLE_PATH, runs=[0, 1, 2, 3], timestamp="2013-02-22 19:40:34"
    )
    assert before_first == {}

    first = db.fetch(TABLE_PATH, runs=[0, 1, 2, 3], timestamp=FIRST_AVAILABLE)
    assert set(first) == {0, 1, 2, 3}
    for data in first.values():
        assert data.n_rows == 2
        assert data.column_names == ["x", "y", "z"]
        assert data.value("x", 0) == 0.0
        assert data.value("y", 0) == 1.0
        assert data.value("z", 0) == 2.0
        assert data.value("x", 1) == 3.0
        assert data.value("y", 1) == 4.0
        assert data.value("z", 1) == 5.0

    mc = table.fetch(runs=[2], variation="mc", timestamp=FIRST_AVAILABLE)
    assert set(mc) == {2}
    mc_row = mc[2].row(1)
    assert mc_row.value("z") == 5.0

    updated = db.fetch(TABLE_PATH, runs=[0, 1, 2, 3], timestamp="2020-02-01 00:00:00")
    assert set(updated) == {0, 1, 2, 3}
    for data in updated.values():
        assert data.value(0, 0) == 1.0
        assert data.value(1, 0) == 2.0
        assert data.value(2, 0) == 3.0
        row_columns = data.row(1).columns()
        assert [name for name, _, _ in row_columns] == ["x", "y", "z"]
        assert [ctype.name for _, ctype, _ in row_columns] == [
            "double",
            "double",
            "double",
        ]
        assert [value for _, _, value in row_columns] == [4.0, 5.0, 6.0]


def test_fetch_run_period_accepts_datetime_rest_version(db: gluex_ccdb.CCDB):
    query_timestamp = dt.datetime(2017, 6, 12, 18, 2, 0, tzinfo=dt.timezone.utc)

    by_rest_version = db.fetch_run_period(
        TABLE_PATH,
        run_period="s17",
        rest_version=query_timestamp,
    )
    by_timestamp = db.fetch_run_period(
        TABLE_PATH,
        run_period="s17",
        timestamp=query_timestamp,
    )
    assert set(by_rest_version) == set(by_timestamp)

    table = db.table(TABLE_PATH)
    table_by_rest_version = table.fetch_run_period(
        run_period="s17",
        rest_version=query_timestamp,
    )
    table_by_timestamp = table.fetch_run_period(
        run_period="s17",
        timestamp=query_timestamp,
    )
    assert set(table_by_rest_version) == set(table_by_timestamp)
