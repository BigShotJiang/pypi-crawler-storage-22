"""Gmail draft tools — list, get, create, update, send, delete."""

from __future__ import annotations

import json
from typing import Annotated

from pydantic import Field

from ..server import mcp, get_client, _error_response, _slim_response


@mcp.tool()
def gmail_drafts_list(
    account: Annotated[str | None, Field(description="Account alias or email. Omit to auto-select if only one account is configured.")] = None,
    max_results: Annotated[int, Field(description="Maximum number of drafts to return")] = 10,
    page_token: Annotated[str | None, Field(description="Token for fetching the next page of results")] = None,
    query: Annotated[str | None, Field(description="Gmail search query to filter drafts")] = None,
) -> str:
    """List drafts in the account."""
    try:
        client = get_client(account)
        result = client.list_drafts(max_results=max_results, page_token=page_token, query=query)
        return json.dumps(_slim_response(result), indent=2)
    except Exception as exc:
        return _error_response(exc)


@mcp.tool()
def gmail_draft_get(
    draft_id: Annotated[str, Field(description="The draft ID to retrieve")],
    account: Annotated[str | None, Field(description="Account alias or email")] = None,
    response_format: Annotated[str, Field(description="Response format: 'full', 'metadata', 'minimal', or 'raw'")] = "full",
) -> str:
    """Get a single draft by ID."""
    try:
        client = get_client(account)
        result = client.get_draft(draft_id, format_=response_format)
        return json.dumps(_slim_response(result), indent=2)
    except Exception as exc:
        return _error_response(exc)


@mcp.tool()
def gmail_draft_create(
    to: Annotated[str, Field(description="Recipient email address")],
    subject: Annotated[str, Field(description="Email subject line")],
    body: Annotated[str, Field(description="Email body (plain text)")],
    account: Annotated[str | None, Field(description="Account alias or email")] = None,
    cc: Annotated[str | None, Field(description="CC recipients (comma-separated)")] = None,
    bcc: Annotated[str | None, Field(description="BCC recipients (comma-separated)")] = None,
    thread_id: Annotated[str | None, Field(description="Thread ID to associate the draft with (for replies)")] = None,
) -> str:
    """Create a new draft email."""
    try:
        client = get_client(account)
        result = client.create_draft(
            to=to, subject=subject, body=body, cc=cc, bcc=bcc, thread_id=thread_id,
        )
        return json.dumps(_slim_response(result), indent=2)
    except Exception as exc:
        return _error_response(exc)


@mcp.tool()
def gmail_draft_update(
    draft_id: Annotated[str, Field(description="The draft ID to update")],
    to: Annotated[str, Field(description="Recipient email address")],
    subject: Annotated[str, Field(description="Email subject line")],
    body: Annotated[str, Field(description="Email body (plain text)")],
    account: Annotated[str | None, Field(description="Account alias or email")] = None,
    cc: Annotated[str | None, Field(description="CC recipients (comma-separated)")] = None,
    bcc: Annotated[str | None, Field(description="BCC recipients (comma-separated)")] = None,
) -> str:
    """Update an existing draft with new content."""
    try:
        client = get_client(account)
        result = client.update_draft(
            draft_id, to=to, subject=subject, body=body, cc=cc, bcc=bcc,
        )
        return json.dumps(_slim_response(result), indent=2)
    except Exception as exc:
        return _error_response(exc)


@mcp.tool()
def gmail_draft_send(
    draft_id: Annotated[str, Field(description="The draft ID to send")],
    account: Annotated[str | None, Field(description="Account alias or email")] = None,
) -> str:
    """Send an existing draft."""
    try:
        client = get_client(account)
        result = client.send_draft(draft_id)
        return json.dumps(_slim_response(result), indent=2)
    except Exception as exc:
        return _error_response(exc)


@mcp.tool()
def gmail_draft_delete(
    draft_id: Annotated[str, Field(description="The draft ID to delete")],
    account: Annotated[str | None, Field(description="Account alias or email")] = None,
) -> str:
    """Permanently delete a draft."""
    try:
        client = get_client(account)
        client.delete_draft(draft_id)
        return json.dumps({"success": True, "draft_id": draft_id, "action": "deleted"}, indent=2)
    except Exception as exc:
        return _error_response(exc)
