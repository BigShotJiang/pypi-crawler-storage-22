# gmail-mcp-remote
HTTP/Streamable-HTTP wrapper for gmail-mcp — 3-party OAuth proxy for Claude.ai and cluster integration
