"""
Configuration and constants for Google Maps Business Extractor.
"""

import os
import time
import httpx

# Proxy Configuration
# Option 1: Set via environment variables (for production/public use)
#   GMAPS_PROXY_HOST: proxy host:port (e.g., "geo.iproyal.com:12321")
#   GMAPS_PROXY_USER: proxy username
#   GMAPS_PROXY_PASS: proxy password
# Option 2: Set directly below (for testing - clear before making public!)

# Direct proxy settings (clear these before making repo public!)
_DIRECT_PROXY_HOST = "geo.iproyal.com:12321"
_DIRECT_PROXY_USER = "ci98nbbrZ66zqMo9"
_DIRECT_PROXY_PASS = "fl3yaMmHkkTX7Epc_country-us_session-SjLhRS8s_lifetime-5s_streaming-1"

# Use environment variables if set, otherwise fall back to direct settings
PROXY_HOST = os.environ.get("GMAPS_PROXY_HOST", _DIRECT_PROXY_HOST)
PROXY_USER = os.environ.get("GMAPS_PROXY_USER", _DIRECT_PROXY_USER)
PROXY_PASS = os.environ.get("GMAPS_PROXY_PASS", _DIRECT_PROXY_PASS)

def get_proxy_url():
    """Get proxy URL. Returns single URL string for httpx."""
    if PROXY_HOST and PROXY_USER and PROXY_PASS:
        return f"http://{PROXY_USER}:{PROXY_PASS}@{PROXY_HOST}"
    return None

# API Server
API_HOST = "0.0.0.0"
API_PORT = 8000
API_BASE_URL = f"http://localhost:{API_PORT}"

# Google Cookies (required for reviews endpoint)
# These cookies enable fetching full review data from Google Maps.
# Cookies EXPIRE periodically and need to be refreshed from your browser.
#
# HOW TO GET FRESH COOKIES:
# 1. Open Chrome in incognito mode
# 2. Go to https://www.google.com/maps
# 3. Open DevTools (F12) -> Network tab
# 4. Search for any place and view its reviews
# 5. Find a request to google.com in the Network tab
# 6. Look at Request Headers -> Cookie
# 7. Copy the values for: NID, SOCS, AEC, __Secure-BUCKET
# 8. Update _DEFAULT_COOKIES below
#
# IMPORTANT: NID is the main session cookie and expires frequently.
# SOCS is a consent cookie that requires clicking "Accept" on cookie banner.
#
# Option 1: Set via environment variable GMAPS_COOKIES as JSON string
# Option 2: Set directly below (update when reviews stop working)
_DEFAULT_COOKIES = {
    '__Secure-BUCKET': 'CGA',
    'SOCS': 'CAISNQgEEitib3FfaWRlbnRpdHlmcm9udGVuZHVpc2VydmVyXzIwMjYwMTE4LjA5X3AwGgJlbiACGgYIgIu7ywY',
    'AEC': 'AaJma5sxFTkfILGJxhvFfDl9X8ZlIArLp8KqMlWv6U7FlH2ZgvpWLOnWKxQ',
    'NID': '528=FztmE0fZq8h__hytYiZUizw297TqJgTGMfA2pIopWi-ZCdFoUQoRyHTI7kQHmxBvdOnsQIewOxXySj6xUdCghxae1F54gUjeIQMPLcy79XqDUkRbL-YaigmrxdFGGKPMF3XTGtu9-d5eSoGQz4lQ0XRu9Ngkox-a3Eg-P_e-Wa0J9b-Q9ONGEH-CpxzzKbTConKT8rDiuIZZGpX4Wk2dFnKSwvfKc_EVhiWeKxLauTNxWWmEJgbC46isiA',
}

# Cache for fetched cookies
_CACHED_COOKIES = None
_COOKIES_FETCH_TIME = 0
_COOKIES_TTL = 3600  # Refresh cookies every hour


def _encode_varint(value: int) -> bytes:
    """Encode integer as protobuf varint."""
    result = b''
    while value > 127:
        result += bytes([(value & 0x7F) | 0x80])
        value >>= 7
    result += bytes([value])
    return result


def generate_socs_cookie(date_str: str = None, language: str = 'en') -> str:
    """
    Generate a SOCS (consent) cookie.

    NOTE: Generated SOCS cookies may not work - Google seems to validate
    them against when/how they were originally set. This function is kept
    for experimentation. In practice, reuse SOCS from a browser session.

    Args:
        date_str: Date in YYYYMMDD format (defaults to today)
        language: Language code (default 'en')

    Returns:
        Base64-encoded SOCS cookie value
    """
    import base64
    from datetime import datetime

    if date_str is None:
        date_str = datetime.now().strftime('%Y%m%d')

    server_version = f'boq_identityfrontenduiserver_{date_str}.09_p0'

    # Build inner message (field 2 content)
    inner = bytearray()
    inner.extend(b'\x08\x04')  # field 1: varint 4
    inner.extend(b'\x12')  # field 2: string
    inner.append(len(server_version))
    inner.extend(server_version.encode())
    inner.extend(b'\x1a')  # field 3: string
    inner.append(len(language))
    inner.extend(language.encode())
    inner.extend(b'\x20\x02')  # field 4: varint 2

    # Build outer message
    outer = bytearray()
    outer.extend(b'\x08\x02')  # field 1: consent type = 2
    outer.extend(b'\x12')  # field 2: inner message
    outer.append(len(inner))
    outer.extend(inner)

    # Field 3: timestamp
    ts = int(time.time())
    ts_inner = b'\x08' + _encode_varint(ts)
    outer.extend(b'\x1a')
    outer.append(len(ts_inner))
    outer.extend(ts_inner)

    return base64.b64encode(bytes(outer)).decode().rstrip('=')


def fetch_fresh_cookies(verbose: bool = False) -> dict:
    """
    Fetch fresh cookies from Google by building a proper session.

    This visits multiple Google pages in sequence to establish a session,
    then adds the SOCS consent cookie from defaults.

    IMPORTANT: Requires a sticky IP proxy (30+ minute session recommended).
    Rotating IPs will cause cookie validation to fail.

    Returns:
        Dictionary of cookies or None on failure
    """
    global _CACHED_COOKIES, _COOKIES_FETCH_TIME

    # Return cached cookies if still valid
    if _CACHED_COOKIES and (time.time() - _COOKIES_FETCH_TIME) < _COOKIES_TTL:
        return _CACHED_COOKIES

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
        'Upgrade-Insecure-Requests': '1',
    }

    try:
        proxy_url = get_proxy_url()
        client_kwargs = {'timeout': 30.0, 'follow_redirects': True}
        if proxy_url:
            client_kwargs['proxy'] = proxy_url

        with httpx.Client(**client_kwargs) as client:
            # Step 1: Visit google.com to get initial cookies
            if verbose:
                print("[Cookie] Step 1: Visiting google.com...")
            client.get('https://www.google.com/', headers=headers)

            # Step 2: Visit consent.google.com to establish consent context
            if verbose:
                print("[Cookie] Step 2: Visiting consent.google.com...")
            client.get('https://consent.google.com/', headers=headers)

            # Step 3: Visit maps to get maps-specific cookies
            if verbose:
                print("[Cookie] Step 3: Visiting maps.google.com...")
            client.get('https://www.google.com/maps', headers=headers)

            # Collect all cookies
            cookies = {}
            for cookie in client.cookies.jar:
                cookies[cookie.name] = cookie.value

            # Check if we got the required NID cookie
            if cookies.get('NID'):
                # Add SOCS from defaults (consent cookie - requires user click to obtain fresh)
                if 'SOCS' not in cookies and _DEFAULT_COOKIES.get('SOCS'):
                    cookies['SOCS'] = _DEFAULT_COOKIES['SOCS']
                    if verbose:
                        print("[Cookie] Added SOCS from defaults")

                if verbose:
                    print(f"[Cookie] Success! Got cookies: {list(cookies.keys())}")

                _CACHED_COOKIES = cookies
                _COOKIES_FETCH_TIME = time.time()
                return cookies
            else:
                if verbose:
                    print(f"[Cookie] Warning: NID not received. Got: {list(cookies.keys())}")
                return None

    except Exception as e:
        if verbose:
            print(f"[Cookie] Error: {e}")
        return None


def parse_cookie_string(cookie_string: str) -> dict:
    """
    Parse a cookie string from browser into a dictionary.

    Example input: "NID=abc123; SOCS=xyz; AEC=def"
    Returns: {"NID": "abc123", "SOCS": "xyz", "AEC": "def"}
    """
    cookies = {}
    for pair in cookie_string.split(';'):
        pair = pair.strip()
        if '=' in pair:
            key, value = pair.split('=', 1)
            cookies[key.strip()] = value.strip()
    return cookies


def update_cookies_from_string(cookie_string: str) -> dict:
    """
    Update the cached cookies from a browser cookie string.

    Usage:
        from gmaps_extractor.config import update_cookies_from_string
        update_cookies_from_string("NID=abc; SOCS=xyz; AEC=def; __Secure-BUCKET=CGA")
    """
    global _CACHED_COOKIES, _COOKIES_FETCH_TIME

    cookies = parse_cookie_string(cookie_string)
    if cookies.get('NID'):
        _CACHED_COOKIES = cookies
        _COOKIES_FETCH_TIME = time.time()
        print(f"[Cookie] Updated cookies: {list(cookies.keys())}")
        return cookies
    else:
        print("[Cookie] Warning: NID cookie not found in string")
        return None


def get_google_cookies(auto_fetch: bool = True, verbose: bool = False):
    """
    Get Google cookies for reviews.

    Args:
        auto_fetch: If True, attempt to fetch fresh cookies automatically
        verbose: Print debug info

    Returns:
        Dictionary of cookies or None
    """
    import json

    # First check environment variable
    env_cookies = os.environ.get("GMAPS_COOKIES")
    if env_cookies:
        try:
            return json.loads(env_cookies)
        except json.JSONDecodeError:
            pass

    # Check if we have cached cookies
    if _CACHED_COOKIES and (time.time() - _COOKIES_FETCH_TIME) < _COOKIES_TTL:
        return _CACHED_COOKIES

    # Try auto-fetch if enabled (gets NID, adds SOCS from defaults)
    if auto_fetch:
        cookies = fetch_fresh_cookies(verbose=verbose)
        if cookies:
            return cookies

    # Fall back to default cookies
    if _DEFAULT_COOKIES.get('NID'):
        return _DEFAULT_COOKIES

    return None

# Search Parameters
DEFAULT_RESULTS_PER_PAGE = 400  # Max results per request (~400 is Google's limit)
DEFAULT_MAX_RADIUS = 5000  # 5km radius
DEFAULT_VIEWPORT_DIST = 10000  # 10km viewport

# Rate Limiting (seconds)
DELAY_BETWEEN_CELLS = 0.05  # Minimal delay for parallel mode
DELAY_BETWEEN_PAGES = 0.1
DELAY_BETWEEN_DETAILS = 0.2
DELAY_BETWEEN_REVIEWS = 0.2

# Parallel Processing
DEFAULT_PARALLEL_WORKERS = 20  # Number of concurrent cell queries
MAX_PARALLEL_WORKERS = 50  # Allow high parallelism for speed

# Grid Configuration
# Cell size is auto-calculated based on area, but these are the thresholds
CELL_SIZE_SMALL = 1000  # 1km for areas < 10km
CELL_SIZE_MEDIUM = 2000  # 2km for areas < 30km
CELL_SIZE_LARGE = 5000  # 5km for areas < 100km
CELL_SIZE_XLARGE = 50000  # 50km for areas < 500km
CELL_SIZE_XXLARGE = 100000  # 100km for countries

# Geographic Constants
METERS_PER_LAT_DEGREE = 111320

# Curl Template for Search Requests
# Parameters: query, query_encoded, lat, lng, viewport_dist, results_count, offset, max_radius
SEARCH_CURL_TEMPLATE = '''curl 'https://www.google.com/search?tbm=map&authuser=0&hl=en&gl=us&q={query}&pb=!1s{query_encoded}!4m8!1m3!1d{viewport_dist}!2d{lng}!3d{lat}!3m2!1i1024!2i768!4f13.1!7i{results_count}!8i{offset}!10b1!12m50!1m5!18b1!30b1!31m1!1b1!34e1!2m4!5m1!6e2!20e3!39b1!6m23!49b1!63m0!66b1!74i{max_radius}!85b1!91b1!114b1!149b1!206b1!209b1!212b1!213b1!223b1!232b1!233b1!234b1!244b1!246b1!250b1!253b1!258b1!260b1!263b1!10b1!12b1!13b1!14b1!16b1!17m1!3e1!20m3!5e2!6b1!14b1!46m1!1b0!96b1!99b1' -H 'User-Agent: Mozilla/5.0' '''

# Output Schema
OUTPUT_SCHEMA = {
    "name": "string",
    "address": "string",
    "place_id": "string",
    "rating": "float",
    "review_count": "integer",
    "latitude": "float",
    "longitude": "float",
    "phone": "string",
    "website": "string",
    "category": "string",
    "categories": "list[string]",
    "hours": "dict",
    "reviews_data": "list[dict]",
}

# CSV Output Columns
CSV_COLUMNS = [
    "name",
    "address",
    "place_id",
    "hex_id",
    "ftid",
    "rating",
    "review_count",
    "latitude",
    "longitude",
    "phone",
    "website",
    "category",
    "categories",
    "hours",
    "found_in",
    "reviews_data",
]
