"""
Comprehensive tests for the pip-installable library conversion.

Tests verify that:
1. All public API imports work correctly
2. Submodule imports work correctly
3. _config_defaults.py fallback has all required exports from config.py
4. ExtractorConfig creation and apply() bridge correctly
5. CollectionResult behaves correctly (len, iter, getitem, to_dict, repr)
6. GMapsExtractor instantiation, context manager, shutdown, __del__
7. CLI modules have main() functions and parse args
8. Exception hierarchy is correct
9. Package metadata is correct
10. Backwards compatibility (CLI entry points)
"""

import importlib
import inspect
import subprocess
import sys
import types
import os

import pytest


# ---------------------------------------------------------------------------
# 1. PUBLIC API IMPORTS
# ---------------------------------------------------------------------------

class TestPublicAPIImports:
    """Test that all advertised public API symbols are importable."""

    def test_import_gmaps_extractor_package(self):
        import gmaps_extractor
        assert hasattr(gmaps_extractor, "__version__")
        assert gmaps_extractor.__version__ == "1.0.0"

    def test_import_GMapsExtractor(self):
        from gmaps_extractor import GMapsExtractor
        assert inspect.isclass(GMapsExtractor)

    def test_import_CollectionResult(self):
        from gmaps_extractor import CollectionResult
        assert inspect.isclass(CollectionResult)

    def test_import_collect_businesses(self):
        from gmaps_extractor import collect_businesses
        assert callable(collect_businesses)

    def test_import_collect_businesses_v2(self):
        from gmaps_extractor import collect_businesses_v2
        assert callable(collect_businesses_v2)

    def test_import_OUTPUT_SCHEMA(self):
        from gmaps_extractor import OUTPUT_SCHEMA
        assert isinstance(OUTPUT_SCHEMA, dict)
        assert "name" in OUTPUT_SCHEMA
        assert "address" in OUTPUT_SCHEMA
        assert "place_id" in OUTPUT_SCHEMA
        assert "rating" in OUTPUT_SCHEMA
        assert "latitude" in OUTPUT_SCHEMA
        assert "longitude" in OUTPUT_SCHEMA

    def test_all_exports_match(self):
        """Verify __all__ matches what is actually exported."""
        import gmaps_extractor
        for name in gmaps_extractor.__all__:
            assert hasattr(gmaps_extractor, name), (
                f"'{name}' listed in __all__ but not accessible on the package"
            )


# ---------------------------------------------------------------------------
# 2. SUBMODULE IMPORTS
# ---------------------------------------------------------------------------

class TestSubmoduleImports:
    """Test that low-level API imports from subpackages work."""

    def test_extraction_submodule(self):
        from gmaps_extractor.extraction import (
            execute_search,
            build_search_curl,
            fetch_place_details,
            fetch_reviews,
            enrich_businesses,
            collect_businesses,
            collect_businesses_v2,
            enrich_businesses_parallel,
            RateLimiter,
            CollectionState,
            TaggedCell,
        )
        assert callable(execute_search)
        assert callable(collect_businesses_v2)
        assert inspect.isclass(RateLimiter)
        assert inspect.isclass(CollectionState)

    def test_decoder_submodule(self):
        from gmaps_extractor.decoder import (
            PbDecoder,
            decode_pb,
            decode_pb_to_dict,
            decode_pb_to_flat,
            CurlParser,
            parse_curl,
            GoogleMapsRequestDecoder,
            decode_google_maps_curl,
            DecodedRequest,
        )
        assert inspect.isclass(PbDecoder)
        assert inspect.isclass(CurlParser)
        assert inspect.isclass(GoogleMapsRequestDecoder)

    def test_parsers_submodule(self):
        from gmaps_extractor.parsers import (
            extract_businesses,
            extract_place_details,
            extract_place_details_from_place_response,
            extract_reviews,
            extract_reviews_from_place_response,
        )
        assert callable(extract_businesses)
        assert callable(extract_reviews)

    def test_geo_submodule(self):
        from gmaps_extractor.geo import (
            GridCell,
            AreaBoundary,
            generate_grid,
            is_in_boundary,
            calculate_cell_size,
            get_area_boundary,
            get_sub_areas,
            get_subdivision_areas,
            SubArea,
        )
        assert callable(generate_grid)
        assert callable(is_in_boundary)

    def test_server_module(self):
        from gmaps_extractor.server import app, run_server
        assert app is not None
        assert callable(run_server)

    def test_config_module(self):
        from gmaps_extractor import config
        assert hasattr(config, "PROXY_HOST")
        assert hasattr(config, "OUTPUT_SCHEMA")
        assert hasattr(config, "get_proxy_url")

    def test_exceptions_module(self):
        from gmaps_extractor.exceptions import (
            GMapsExtractorError,
            ServerError,
            BoundaryError,
            ConfigurationError,
            RateLimitError,
            AuthenticationError,
        )
        assert inspect.isclass(GMapsExtractorError)
        assert inspect.isclass(ServerError)

    def test_config_manager_module(self):
        from gmaps_extractor.config_manager import ExtractorConfig
        assert inspect.isclass(ExtractorConfig)

    def test_extractor_module(self):
        from gmaps_extractor.extractor import GMapsExtractor, CollectionResult
        assert inspect.isclass(GMapsExtractor)
        assert inspect.isclass(CollectionResult)


# ---------------------------------------------------------------------------
# 3. CONFIG FALLBACK (_config_defaults.py vs config.py)
# ---------------------------------------------------------------------------

class TestConfigFallback:
    """Verify _config_defaults.py has all symbols that config.py exports.

    Internal modules do `from .config import SOME_CONST`, so _config_defaults
    must provide every public name that config.py does.
    """

    def _get_public_names(self, mod):
        """Return set of public (non-dunder, non-private) names from a module."""
        return {
            name for name in dir(mod)
            if not name.startswith('_')
        }

    def test_config_defaults_has_all_constants(self):
        """Every constant in config.py must also exist in _config_defaults.py."""
        from gmaps_extractor import config
        from gmaps_extractor import _config_defaults

        config_names = self._get_public_names(config)
        defaults_names = self._get_public_names(_config_defaults)

        # These are the critical names that internal modules import.
        # We exclude stdlib imports (os, time, httpx, json) from the check.
        stdlib_names = {"os", "time", "httpx", "json", "base64", "datetime"}
        config_names -= stdlib_names
        defaults_names -= stdlib_names

        missing = config_names - defaults_names
        assert not missing, (
            f"_config_defaults.py is missing these exports from config.py: {missing}"
        )

    def test_config_defaults_constants_have_same_types(self):
        """Key constants should have the same types in both modules."""
        from gmaps_extractor import config
        from gmaps_extractor import _config_defaults

        key_constants = [
            "PROXY_HOST", "PROXY_USER", "PROXY_PASS",
            "API_HOST", "API_PORT", "API_BASE_URL",
            "DEFAULT_RESULTS_PER_PAGE", "DEFAULT_MAX_RADIUS", "DEFAULT_VIEWPORT_DIST",
            "DELAY_BETWEEN_CELLS", "DELAY_BETWEEN_PAGES",
            "DELAY_BETWEEN_DETAILS", "DELAY_BETWEEN_REVIEWS",
            "DEFAULT_PARALLEL_WORKERS", "MAX_PARALLEL_WORKERS",
            "CELL_SIZE_SMALL", "CELL_SIZE_MEDIUM", "CELL_SIZE_LARGE",
            "CELL_SIZE_XLARGE", "CELL_SIZE_XXLARGE",
            "METERS_PER_LAT_DEGREE",
            "SEARCH_CURL_TEMPLATE",
            "OUTPUT_SCHEMA", "CSV_COLUMNS",
        ]

        for name in key_constants:
            config_val = getattr(config, name)
            defaults_val = getattr(_config_defaults, name, "__MISSING__")
            assert defaults_val != "__MISSING__", (
                f"_config_defaults.py missing constant: {name}"
            )
            assert type(config_val) == type(defaults_val), (
                f"Type mismatch for {name}: "
                f"config.py has {type(config_val).__name__}, "
                f"_config_defaults.py has {type(defaults_val).__name__}"
            )

    def test_config_defaults_functions_exist(self):
        """Functions in config.py should also exist in _config_defaults.py."""
        from gmaps_extractor import config
        from gmaps_extractor import _config_defaults

        functions_in_config = [
            "get_proxy_url",
            "generate_socs_cookie",
            "fetch_fresh_cookies",
            "parse_cookie_string",
            "update_cookies_from_string",
            "get_google_cookies",
        ]
        for fn_name in functions_in_config:
            assert hasattr(config, fn_name), f"config.py missing: {fn_name}"
            assert callable(getattr(config, fn_name)), f"config.py {fn_name} not callable"
            assert hasattr(_config_defaults, fn_name), (
                f"_config_defaults.py missing function: {fn_name}"
            )
            assert callable(getattr(_config_defaults, fn_name)), (
                f"_config_defaults.py {fn_name} not callable"
            )

    def test_config_defaults_output_schema_matches(self):
        """OUTPUT_SCHEMA should have identical keys."""
        from gmaps_extractor import config
        from gmaps_extractor import _config_defaults

        assert set(config.OUTPUT_SCHEMA.keys()) == set(_config_defaults.OUTPUT_SCHEMA.keys()), (
            "OUTPUT_SCHEMA keys differ between config.py and _config_defaults.py"
        )

    def test_config_defaults_csv_columns_match(self):
        """CSV_COLUMNS should have identical entries."""
        from gmaps_extractor import config
        from gmaps_extractor import _config_defaults

        assert config.CSV_COLUMNS == _config_defaults.CSV_COLUMNS, (
            "CSV_COLUMNS differ between config.py and _config_defaults.py"
        )

    def test_config_defaults_proxy_is_empty(self):
        """_config_defaults should NOT contain real proxy credentials."""
        from gmaps_extractor import _config_defaults

        # These must be empty strings for the fallback
        assert _config_defaults._DIRECT_PROXY_HOST == ""
        assert _config_defaults._DIRECT_PROXY_USER == ""
        assert _config_defaults._DIRECT_PROXY_PASS == ""


# ---------------------------------------------------------------------------
# 4. CONFIG MANAGER (ExtractorConfig)
# ---------------------------------------------------------------------------

class TestExtractorConfig:
    """Test ExtractorConfig dataclass creation and apply() bridging."""

    def test_default_creation(self):
        from gmaps_extractor.config_manager import ExtractorConfig
        cfg = ExtractorConfig()
        assert cfg.default_workers == 20
        assert cfg.max_workers == 50
        assert cfg.server_port == 8000
        assert cfg.delay_between_cells == 0.05
        assert cfg.results_per_page == 400
        assert cfg.max_radius == 5000
        assert cfg.verbose is True
        assert cfg.proxy_url is None
        assert cfg.cookies is None

    def test_creation_with_custom_params(self):
        from gmaps_extractor.config_manager import ExtractorConfig
        cfg = ExtractorConfig(
            proxy_url="http://user:pass@host:1234",
            cookies={"NID": "test"},
            default_workers=10,
            max_workers=30,
            server_port=9000,
            delay_between_cells=0.1,
            delay_between_pages=0.2,
            results_per_page=200,
            max_radius=3000,
            verbose=False,
        )
        assert cfg.proxy_url == "http://user:pass@host:1234"
        assert cfg.cookies == {"NID": "test"}
        assert cfg.default_workers == 10
        assert cfg.max_workers == 30
        assert cfg.server_port == 9000
        assert cfg.delay_between_cells == 0.1
        assert cfg.results_per_page == 200
        assert cfg.verbose is False

    def test_proxy_resolution_from_env_vars(self, monkeypatch):
        """If proxy_url is None, resolve from GMAPS_PROXY_* env vars."""
        from gmaps_extractor.config_manager import ExtractorConfig

        monkeypatch.setenv("GMAPS_PROXY_HOST", "myproxy.com:8080")
        monkeypatch.setenv("GMAPS_PROXY_USER", "testuser")
        monkeypatch.setenv("GMAPS_PROXY_PASS", "testpass")

        cfg = ExtractorConfig()
        assert cfg.proxy_url == "http://testuser:testpass@myproxy.com:8080"

    def test_proxy_resolution_skipped_when_explicit(self, monkeypatch):
        """If proxy_url is set explicitly, env vars are ignored."""
        from gmaps_extractor.config_manager import ExtractorConfig

        monkeypatch.setenv("GMAPS_PROXY_HOST", "envproxy.com:8080")
        monkeypatch.setenv("GMAPS_PROXY_USER", "envuser")
        monkeypatch.setenv("GMAPS_PROXY_PASS", "envpass")

        cfg = ExtractorConfig(proxy_url="http://explicit:pass@host:1234")
        assert cfg.proxy_url == "http://explicit:pass@host:1234"

    def test_proxy_resolution_partial_env_vars(self, monkeypatch):
        """If only some GMAPS_PROXY_* vars set, proxy_url stays None."""
        from gmaps_extractor.config_manager import ExtractorConfig

        monkeypatch.setenv("GMAPS_PROXY_HOST", "host.com:8080")
        monkeypatch.delenv("GMAPS_PROXY_USER", raising=False)
        monkeypatch.delenv("GMAPS_PROXY_PASS", raising=False)

        cfg = ExtractorConfig()
        assert cfg.proxy_url is None

    def test_apply_sets_config_module_constants(self):
        """apply() should bridge values onto the config module."""
        from gmaps_extractor.config_manager import ExtractorConfig
        from gmaps_extractor import config

        # Save originals to restore later
        orig_workers = config.DEFAULT_PARALLEL_WORKERS
        orig_port = config.API_PORT
        orig_delay = config.DELAY_BETWEEN_CELLS
        orig_radius = config.DEFAULT_MAX_RADIUS

        try:
            cfg = ExtractorConfig(
                default_workers=42,
                server_port=9999,
                delay_between_cells=0.99,
                max_radius=12345,
            )
            cfg.apply()

            assert config.DEFAULT_PARALLEL_WORKERS == 42
            assert config.API_PORT == 9999
            assert config.API_BASE_URL == "http://localhost:9999"
            assert config.DELAY_BETWEEN_CELLS == 0.99
            assert config.DEFAULT_MAX_RADIUS == 12345
        finally:
            # Restore originals
            config.DEFAULT_PARALLEL_WORKERS = orig_workers
            config.API_PORT = orig_port
            config.API_BASE_URL = f"http://localhost:{orig_port}"
            config.DELAY_BETWEEN_CELLS = orig_delay
            config.DEFAULT_MAX_RADIUS = orig_radius

    def test_apply_with_proxy_url(self):
        """apply() should parse proxy URL into host/user/pass on config module."""
        from gmaps_extractor.config_manager import ExtractorConfig
        from gmaps_extractor import config

        orig_host = config.PROXY_HOST
        orig_user = config.PROXY_USER
        orig_pass = config.PROXY_PASS

        try:
            cfg = ExtractorConfig(proxy_url="http://myuser:mypass@proxy.example.com:8080")
            cfg.apply()

            assert config.PROXY_HOST == "proxy.example.com:8080"
            assert config.PROXY_USER == "myuser"
            assert config.PROXY_PASS == "mypass"
        finally:
            config.PROXY_HOST = orig_host
            config.PROXY_USER = orig_user
            config.PROXY_PASS = orig_pass

    def test_apply_without_proxy_url_preserves_config(self):
        """apply() without proxy_url should not clobber existing config proxy settings."""
        from gmaps_extractor.config_manager import ExtractorConfig
        from gmaps_extractor import config

        orig_host = config.PROXY_HOST

        try:
            cfg = ExtractorConfig()  # No proxy_url
            cfg.apply()

            # Should be unchanged
            assert config.PROXY_HOST == orig_host
        finally:
            config.PROXY_HOST = orig_host

    def test_apply_with_cookies(self):
        """apply() with cookies should set _CACHED_COOKIES."""
        from gmaps_extractor.config_manager import ExtractorConfig
        from gmaps_extractor import config

        orig_cached = config._CACHED_COOKIES
        orig_time = config._COOKIES_FETCH_TIME

        try:
            test_cookies = {"NID": "test123", "SOCS": "test456"}
            cfg = ExtractorConfig(cookies=test_cookies)
            cfg.apply()

            assert config._CACHED_COOKIES == test_cookies
            assert config._COOKIES_FETCH_TIME > 0
        finally:
            config._CACHED_COOKIES = orig_cached
            config._COOKIES_FETCH_TIME = orig_time

    def test_apply_without_cookies_preserves_config(self):
        """apply() without cookies should not touch cookie cache."""
        from gmaps_extractor.config_manager import ExtractorConfig
        from gmaps_extractor import config

        config._CACHED_COOKIES = {"ORIGINAL": "cookies"}
        orig = config._CACHED_COOKIES

        try:
            cfg = ExtractorConfig()  # No cookies
            cfg.apply()
            assert config._CACHED_COOKIES == orig
        finally:
            config._CACHED_COOKIES = None


# ---------------------------------------------------------------------------
# 5. COLLECTION RESULT
# ---------------------------------------------------------------------------

class TestCollectionResult:
    """Test CollectionResult wrapper object."""

    def _make_result(self, n_businesses=3, area="Test Area", category="test"):
        from gmaps_extractor.extractor import CollectionResult

        businesses = [
            {"name": f"Business {i}", "address": f"Address {i}", "place_id": f"id_{i}"}
            for i in range(n_businesses)
        ]
        data = {
            "businesses": businesses,
            "metadata": {"area": area, "category": category},
            "statistics": {"total_collected": n_businesses},
        }
        return CollectionResult(data)

    def test_len(self):
        result = self._make_result(5)
        assert len(result) == 5

    def test_len_empty(self):
        result = self._make_result(0)
        assert len(result) == 0

    def test_iter(self):
        result = self._make_result(3)
        items = list(result)
        assert len(items) == 3
        assert items[0]["name"] == "Business 0"
        assert items[2]["name"] == "Business 2"

    def test_iter_empty(self):
        result = self._make_result(0)
        items = list(result)
        assert items == []

    def test_getitem_index(self):
        result = self._make_result(3)
        assert result[0]["name"] == "Business 0"
        assert result[1]["name"] == "Business 1"
        assert result[2]["name"] == "Business 2"

    def test_getitem_negative_index(self):
        result = self._make_result(3)
        assert result[-1]["name"] == "Business 2"

    def test_getitem_slice(self):
        result = self._make_result(5)
        sliced = result[1:3]
        assert len(sliced) == 2
        assert sliced[0]["name"] == "Business 1"

    def test_getitem_index_out_of_range(self):
        result = self._make_result(2)
        with pytest.raises(IndexError):
            _ = result[5]

    def test_to_dict(self):
        result = self._make_result(2, area="NYC", category="lawyers")
        d = result.to_dict()
        assert isinstance(d, dict)
        assert "businesses" in d
        assert "metadata" in d
        assert "statistics" in d
        assert d["metadata"]["area"] == "NYC"
        assert d["metadata"]["category"] == "lawyers"
        assert len(d["businesses"]) == 2

    def test_to_dict_returns_original_data(self):
        """to_dict() should return the same dict object passed to the constructor."""
        from gmaps_extractor.extractor import CollectionResult

        data = {"businesses": [], "metadata": {}, "statistics": {}}
        result = CollectionResult(data)
        assert result.to_dict() is data

    def test_repr(self):
        result = self._make_result(7, area="Paris", category="restaurants")
        r = repr(result)
        assert "7 businesses" in r
        assert "restaurants" in r
        assert "Paris" in r

    def test_repr_empty(self):
        result = self._make_result(0, area="Empty", category="nothing")
        r = repr(result)
        assert "0 businesses" in r

    def test_repr_unknown_metadata(self):
        from gmaps_extractor.extractor import CollectionResult

        result = CollectionResult({"businesses": []})
        r = repr(result)
        assert "unknown" in r

    def test_metadata_attribute(self):
        result = self._make_result(1, area="Tokyo", category="hotels")
        assert result.metadata["area"] == "Tokyo"
        assert result.metadata["category"] == "hotels"

    def test_statistics_attribute(self):
        result = self._make_result(5)
        assert result.statistics["total_collected"] == 5

    def test_businesses_attribute(self):
        result = self._make_result(3)
        assert len(result.businesses) == 3
        assert result.businesses[0]["place_id"] == "id_0"

    def test_missing_keys_default_to_empty(self):
        """If data dict is missing keys, they default to empty."""
        from gmaps_extractor.extractor import CollectionResult

        result = CollectionResult({})
        assert result.businesses == []
        assert result.metadata == {}
        assert result.statistics == {}
        assert len(result) == 0


# ---------------------------------------------------------------------------
# 6. GMAPS EXTRACTOR
# ---------------------------------------------------------------------------

class TestGMapsExtractor:
    """Test GMapsExtractor instantiation and lifecycle.

    All tests use auto_start_server=False to avoid needing a running server.
    """

    def test_instantiation_no_server(self):
        from gmaps_extractor.extractor import GMapsExtractor

        ext = GMapsExtractor(auto_start_server=False)
        assert ext._auto_start is False
        assert ext._server_instance is None
        assert ext._server_started is False
        ext.shutdown()

    def test_instantiation_with_params(self):
        from gmaps_extractor.extractor import GMapsExtractor

        ext = GMapsExtractor(
            proxy="http://u:p@h:1234",
            cookies={"NID": "test"},
            workers=15,
            server_port=9999,
            auto_start_server=False,
            verbose=False,
        )
        assert ext._config.proxy_url == "http://u:p@h:1234"
        assert ext._config.cookies == {"NID": "test"}
        assert ext._config.default_workers == 15
        assert ext._config.server_port == 9999
        assert ext._config.verbose is False
        ext.shutdown()

    def test_is_server_running_false(self):
        """Without a running server on an unusual port, should return False."""
        from gmaps_extractor.extractor import GMapsExtractor

        ext = GMapsExtractor(
            server_port=59123,  # unlikely to be in use
            auto_start_server=False,
        )
        assert ext._is_server_running() is False
        ext.shutdown()

    def test_context_manager_enter_returns_self(self):
        from gmaps_extractor.extractor import GMapsExtractor

        ext = GMapsExtractor(auto_start_server=False)
        result = ext.__enter__()
        assert result is ext
        ext.__exit__(None, None, None)

    def test_context_manager_exit_returns_false(self):
        """__exit__ should return False (do not suppress exceptions)."""
        from gmaps_extractor.extractor import GMapsExtractor

        ext = GMapsExtractor(auto_start_server=False)
        ext.__enter__()
        assert ext.__exit__(None, None, None) is False

    def test_context_manager_with_statement(self):
        from gmaps_extractor.extractor import GMapsExtractor

        with GMapsExtractor(auto_start_server=False) as ext:
            assert isinstance(ext, GMapsExtractor)
            assert ext._server_instance is None

    def test_shutdown_idempotent(self):
        """Calling shutdown multiple times should not raise."""
        from gmaps_extractor.extractor import GMapsExtractor

        ext = GMapsExtractor(auto_start_server=False)
        ext.shutdown()
        ext.shutdown()  # Should not raise
        ext.shutdown()  # Should not raise

    def test_del_calls_shutdown(self):
        """__del__ should call shutdown without raising."""
        from gmaps_extractor.extractor import GMapsExtractor

        ext = GMapsExtractor(auto_start_server=False)
        ext.__del__()  # Should not raise
        assert ext._server_instance is None

    def test_config_applied_on_init(self):
        """Config values should be applied to config module on init."""
        from gmaps_extractor.extractor import GMapsExtractor
        from gmaps_extractor import config

        orig = config.DEFAULT_PARALLEL_WORKERS
        try:
            ext = GMapsExtractor(workers=33, auto_start_server=False)
            assert config.DEFAULT_PARALLEL_WORKERS == 33
            ext.shutdown()
        finally:
            config.DEFAULT_PARALLEL_WORKERS = orig

    def test_collect_method_exists(self):
        from gmaps_extractor.extractor import GMapsExtractor

        ext = GMapsExtractor(auto_start_server=False)
        assert hasattr(ext, "collect")
        assert callable(ext.collect)
        ext.shutdown()

    def test_collect_v2_method_exists(self):
        from gmaps_extractor.extractor import GMapsExtractor

        ext = GMapsExtractor(auto_start_server=False)
        assert hasattr(ext, "collect_v2")
        assert callable(ext.collect_v2)
        ext.shutdown()

    def test_collect_method_signature(self):
        """collect() should accept the documented keyword arguments."""
        from gmaps_extractor.extractor import GMapsExtractor

        sig = inspect.signature(GMapsExtractor.collect)
        params = list(sig.parameters.keys())
        assert "area" in params
        assert "category" in params
        assert "enrich" in params
        assert "reviews" in params
        assert "reviews_limit" in params
        assert "workers" in params
        assert "subdivide" in params
        assert "output_file" in params

    def test_collect_v2_method_signature(self):
        """collect_v2() should accept the documented keyword arguments."""
        from gmaps_extractor.extractor import GMapsExtractor

        sig = inspect.signature(GMapsExtractor.collect_v2)
        params = list(sig.parameters.keys())
        assert "area" in params
        assert "category" in params
        assert "enrich" in params
        assert "reviews" in params
        assert "reviews_limit" in params
        assert "workers" in params
        assert "enrichment_workers" in params
        assert "checkpoint_interval" in params
        assert "resume" in params
        assert "subdivide" in params


# ---------------------------------------------------------------------------
# 7. CLI MODULES
# ---------------------------------------------------------------------------

class TestCLIModules:
    """Test that CLI modules have main() and can parse --help."""

    def test_cli_has_main(self):
        from gmaps_extractor.cli import main
        assert callable(main)

    def test_cli_v2_has_main(self):
        from gmaps_extractor.cli_v2 import main
        assert callable(main)

    def test_cli_enrich_has_main(self):
        from gmaps_extractor.cli_enrich import main
        assert callable(main)

    def test_cli_help(self):
        """python -m gmaps_extractor --help should exit 0."""
        result = subprocess.run(
            [sys.executable, "-m", "gmaps_extractor", "--help"],
            capture_output=True,
            text=True,
            timeout=15,
        )
        assert result.returncode == 0, f"stderr: {result.stderr}"
        assert "Google Maps" in result.stdout or "area" in result.stdout.lower()

    def test_cli_v2_help(self):
        """cli_v2 --help should produce valid output via argparse SystemExit(0)."""
        from gmaps_extractor.cli_v2 import main
        with pytest.raises(SystemExit) as exc_info:
            sys.argv = ["gmaps-collect-v2", "--help"]
            main()
        assert exc_info.value.code == 0

    def test_cli_enrich_help(self):
        """cli_enrich --help should produce valid output via argparse SystemExit(0)."""
        from gmaps_extractor.cli_enrich import main
        with pytest.raises(SystemExit) as exc_info:
            sys.argv = ["gmaps-enrich-reviews", "--help"]
            main()
        assert exc_info.value.code == 0

    def test_collect_py_help(self):
        """python collect.py --help should work."""
        result = subprocess.run(
            [sys.executable, os.path.join(
                os.path.dirname(os.path.dirname(__file__)), "collect.py"
            ), "--help"],
            capture_output=True,
            text=True,
            timeout=15,
        )
        assert result.returncode == 0, f"stderr: {result.stderr}"

    def test_collect_v2_py_help(self):
        """python collect_v2.py --help should work."""
        result = subprocess.run(
            [sys.executable, os.path.join(
                os.path.dirname(os.path.dirname(__file__)), "collect_v2.py"
            ), "--help"],
            capture_output=True,
            text=True,
            timeout=15,
        )
        assert result.returncode == 0, f"stderr: {result.stderr}"

    def test_cli_v2_argparse_accepts_required_args(self):
        """cli_v2 parser should accept area and category positional args."""
        import argparse
        from gmaps_extractor.cli_v2 import main

        # Simulate arg parsing without actually running
        # By checking the parser directly
        parser = argparse.ArgumentParser()
        parser.add_argument("area")
        parser.add_argument("category")

        args = parser.parse_args(["New York", "lawyers"])
        assert args.area == "New York"
        assert args.category == "lawyers"


# ---------------------------------------------------------------------------
# 8. EXCEPTION HIERARCHY
# ---------------------------------------------------------------------------

class TestExceptionHierarchy:
    """Verify all custom exceptions subclass GMapsExtractorError."""

    def test_base_exception_subclasses_exception(self):
        from gmaps_extractor.exceptions import GMapsExtractorError
        assert issubclass(GMapsExtractorError, Exception)

    def test_server_error(self):
        from gmaps_extractor.exceptions import GMapsExtractorError, ServerError
        assert issubclass(ServerError, GMapsExtractorError)
        assert issubclass(ServerError, Exception)

    def test_boundary_error(self):
        from gmaps_extractor.exceptions import GMapsExtractorError, BoundaryError
        assert issubclass(BoundaryError, GMapsExtractorError)

    def test_configuration_error(self):
        from gmaps_extractor.exceptions import GMapsExtractorError, ConfigurationError
        assert issubclass(ConfigurationError, GMapsExtractorError)

    def test_rate_limit_error(self):
        from gmaps_extractor.exceptions import GMapsExtractorError, RateLimitError
        assert issubclass(RateLimitError, GMapsExtractorError)

    def test_authentication_error(self):
        from gmaps_extractor.exceptions import GMapsExtractorError, AuthenticationError
        assert issubclass(AuthenticationError, GMapsExtractorError)

    def test_exceptions_are_catchable_as_base(self):
        """All specific exceptions should be catchable via GMapsExtractorError."""
        from gmaps_extractor.exceptions import (
            GMapsExtractorError,
            ServerError,
            BoundaryError,
            ConfigurationError,
            RateLimitError,
            AuthenticationError,
        )

        for ExcClass in [ServerError, BoundaryError, ConfigurationError,
                         RateLimitError, AuthenticationError]:
            exc = ExcClass("test message")
            assert isinstance(exc, GMapsExtractorError)
            assert str(exc) == "test message"

    def test_exceptions_are_not_related_to_each_other(self):
        """Specific exceptions should not subclass each other."""
        from gmaps_extractor.exceptions import (
            ServerError,
            BoundaryError,
            ConfigurationError,
            RateLimitError,
            AuthenticationError,
        )

        exceptions = [ServerError, BoundaryError, ConfigurationError,
                      RateLimitError, AuthenticationError]
        for i, exc_a in enumerate(exceptions):
            for j, exc_b in enumerate(exceptions):
                if i != j:
                    assert not issubclass(exc_a, exc_b), (
                        f"{exc_a.__name__} should not subclass {exc_b.__name__}"
                    )


# ---------------------------------------------------------------------------
# 9. PACKAGE METADATA
# ---------------------------------------------------------------------------

class TestPackageMetadata:
    """Verify package metadata via pip and pyproject.toml."""

    def test_pip_show(self):
        """pip show gmaps-extractor should return correct metadata."""
        result = subprocess.run(
            [sys.executable, "-m", "pip", "show", "gmaps-extractor"],
            capture_output=True,
            text=True,
            timeout=15,
        )
        assert result.returncode == 0, f"pip show failed: {result.stderr}"
        output = result.stdout

        assert "gmaps-extractor" in output.lower() or "gmaps_extractor" in output.lower()
        assert "1.0.0" in output
        assert "MIT" in output

    def test_pip_show_dependencies(self):
        """Package should declare its core dependencies."""
        result = subprocess.run(
            [sys.executable, "-m", "pip", "show", "gmaps-extractor"],
            capture_output=True,
            text=True,
            timeout=15,
        )
        output = result.stdout.lower()
        assert "fastapi" in output
        assert "uvicorn" in output
        assert "httpx" in output
        assert "pydantic" in output

    def test_console_scripts_declared(self):
        """pyproject.toml should declare console_scripts entry points."""
        import tomllib
        pyproject_path = os.path.join(
            os.path.dirname(os.path.dirname(__file__)), "pyproject.toml"
        )
        with open(pyproject_path, "rb") as f:
            data = tomllib.load(f)

        scripts = data.get("project", {}).get("scripts", {})
        assert "gmaps-collect" in scripts, "Missing gmaps-collect console script"
        assert "gmaps-collect-v2" in scripts, "Missing gmaps-collect-v2 console script"
        assert "gmaps-enrich-reviews" in scripts, "Missing gmaps-enrich-reviews console script"
        assert "gmaps-server" in scripts, "Missing gmaps-server console script"

    def test_console_script_targets_valid(self):
        """Each console script target should point to an importable callable."""
        import tomllib
        pyproject_path = os.path.join(
            os.path.dirname(os.path.dirname(__file__)), "pyproject.toml"
        )
        with open(pyproject_path, "rb") as f:
            data = tomllib.load(f)

        scripts = data["project"]["scripts"]
        for script_name, target in scripts.items():
            module_path, func_name = target.rsplit(":", 1)
            mod = importlib.import_module(module_path)
            assert hasattr(mod, func_name), (
                f"Console script '{script_name}' targets '{target}' "
                f"but {module_path} has no attribute '{func_name}'"
            )
            assert callable(getattr(mod, func_name)), (
                f"Console script target '{target}' exists but is not callable"
            )

    def test_version_consistent(self):
        """Version in pyproject.toml should match __version__ in package."""
        import tomllib
        import gmaps_extractor

        pyproject_path = os.path.join(
            os.path.dirname(os.path.dirname(__file__)), "pyproject.toml"
        )
        with open(pyproject_path, "rb") as f:
            data = tomllib.load(f)

        pyproject_version = data["project"]["version"]
        assert pyproject_version == gmaps_extractor.__version__, (
            f"pyproject.toml version ({pyproject_version}) != "
            f"__init__.py __version__ ({gmaps_extractor.__version__})"
        )

    def test_python_requires(self):
        """Package should require Python >= 3.9."""
        import tomllib
        pyproject_path = os.path.join(
            os.path.dirname(os.path.dirname(__file__)), "pyproject.toml"
        )
        with open(pyproject_path, "rb") as f:
            data = tomllib.load(f)

        assert data["project"]["requires-python"] == ">=3.9"

    def test_setuptools_includes_package(self):
        """Setuptools config should include gmaps_extractor."""
        import tomllib
        pyproject_path = os.path.join(
            os.path.dirname(os.path.dirname(__file__)), "pyproject.toml"
        )
        with open(pyproject_path, "rb") as f:
            data = tomllib.load(f)

        includes = data["tool"]["setuptools"]["packages"]["find"]["include"]
        assert "gmaps_extractor*" in includes

    def test_setuptools_excludes_tests(self):
        """Setuptools config should exclude tests from the package."""
        import tomllib
        pyproject_path = os.path.join(
            os.path.dirname(os.path.dirname(__file__)), "pyproject.toml"
        )
        with open(pyproject_path, "rb") as f:
            data = tomllib.load(f)

        excludes = data["tool"]["setuptools"]["packages"]["find"]["exclude"]
        assert "tests*" in excludes


# ---------------------------------------------------------------------------
# 10. BACKWARDS COMPATIBILITY
# ---------------------------------------------------------------------------

class TestBackwardsCompatibility:
    """Verify that existing usage patterns still work after the conversion."""

    def test_python_m_gmaps_extractor_help(self):
        """python -m gmaps_extractor --help should still work."""
        result = subprocess.run(
            [sys.executable, "-m", "gmaps_extractor", "--help"],
            capture_output=True,
            text=True,
            timeout=15,
        )
        assert result.returncode == 0, (
            f"python -m gmaps_extractor --help failed with rc={result.returncode}\n"
            f"stderr: {result.stderr}"
        )

    def test_collect_py_still_works(self):
        """Top-level collect.py --help should still function."""
        collect_path = os.path.join(
            os.path.dirname(os.path.dirname(__file__)), "collect.py"
        )
        assert os.path.exists(collect_path), "collect.py not found at project root"
        result = subprocess.run(
            [sys.executable, collect_path, "--help"],
            capture_output=True,
            text=True,
            timeout=15,
        )
        assert result.returncode == 0, f"collect.py --help failed: {result.stderr}"

    def test_collect_v2_py_still_works(self):
        """Top-level collect_v2.py --help should still function."""
        collect_v2_path = os.path.join(
            os.path.dirname(os.path.dirname(__file__)), "collect_v2.py"
        )
        assert os.path.exists(collect_v2_path), "collect_v2.py not found at project root"
        result = subprocess.run(
            [sys.executable, collect_v2_path, "--help"],
            capture_output=True,
            text=True,
            timeout=15,
        )
        assert result.returncode == 0, f"collect_v2.py --help failed: {result.stderr}"

    def test_run_server_py_exists(self):
        """run_server.py should still exist at project root."""
        server_path = os.path.join(
            os.path.dirname(os.path.dirname(__file__)), "run_server.py"
        )
        assert os.path.exists(server_path), "run_server.py not found at project root"

    def test_enrich_reviews_only_py_exists(self):
        """enrich_reviews_only.py should still exist at project root."""
        enrich_path = os.path.join(
            os.path.dirname(os.path.dirname(__file__)), "enrich_reviews_only.py"
        )
        assert os.path.exists(enrich_path), "enrich_reviews_only.py not found at project root"

    def test_config_example_exists(self):
        """config.example.py should still exist for repo-clone users."""
        example_path = os.path.join(
            os.path.dirname(os.path.dirname(__file__)),
            "gmaps_extractor", "config.example.py"
        )
        assert os.path.exists(example_path), "config.example.py not found"

    def test_manifest_in_exists(self):
        """MANIFEST.in should exist for sdist builds."""
        manifest_path = os.path.join(
            os.path.dirname(os.path.dirname(__file__)), "MANIFEST.in"
        )
        assert os.path.exists(manifest_path), "MANIFEST.in not found"

    def test_manifest_includes_required_files(self):
        """MANIFEST.in should include README, LICENSE, requirements.txt."""
        manifest_path = os.path.join(
            os.path.dirname(os.path.dirname(__file__)), "MANIFEST.in"
        )
        with open(manifest_path, "r") as f:
            content = f.read()
        assert "README.md" in content
        assert "LICENSE" in content
        assert "requirements.txt" in content

    def test_import_shim_in_init(self):
        """__init__.py should have the config import shim."""
        init_path = os.path.join(
            os.path.dirname(os.path.dirname(__file__)),
            "gmaps_extractor", "__init__.py"
        )
        with open(init_path, "r") as f:
            content = f.read()
        assert "_config_defaults" in content
        assert "sys.modules" in content or "_sys.modules" in content


# ---------------------------------------------------------------------------
# 11. ADDITIONAL EDGE CASE / INTEGRATION TESTS
# ---------------------------------------------------------------------------

class TestConfigShimMechanism:
    """Test the import shim that provides _config_defaults when config.py is absent."""

    def test_config_module_is_importable(self):
        """gmaps_extractor.config should always be importable."""
        from gmaps_extractor import config
        assert config is not None
        assert hasattr(config, "OUTPUT_SCHEMA")

    def test_config_shim_registers_in_sys_modules(self):
        """gmaps_extractor.config should be in sys.modules after import."""
        import gmaps_extractor
        assert "gmaps_extractor.config" in sys.modules


class TestExtractorConfigEdgeCases:
    """Edge cases for ExtractorConfig."""

    def test_proxy_url_without_port(self):
        """Proxy URL without explicit port should still parse."""
        from gmaps_extractor.config_manager import ExtractorConfig
        from gmaps_extractor import config

        orig_host = config.PROXY_HOST
        try:
            cfg = ExtractorConfig(proxy_url="http://user:pass@host.com")
            cfg.apply()
            assert config.PROXY_HOST == "host.com"
            assert config.PROXY_USER == "user"
            assert config.PROXY_PASS == "pass"
        finally:
            config.PROXY_HOST = orig_host

    def test_proxy_url_with_special_chars_in_password(self):
        """Proxy URL with special chars in password should parse."""
        from gmaps_extractor.config_manager import ExtractorConfig

        cfg = ExtractorConfig(
            proxy_url="http://user:p%40ss%3Aword@host.com:8080"
        )
        # The proxy URL is stored as-is; apply() parses it
        assert cfg.proxy_url == "http://user:p%40ss%3Aword@host.com:8080"

    def test_config_is_dataclass(self):
        """ExtractorConfig should be a dataclass."""
        import dataclasses
        from gmaps_extractor.config_manager import ExtractorConfig
        assert dataclasses.is_dataclass(ExtractorConfig)


class TestCollectionResultEdgeCases:
    """Additional edge case tests for CollectionResult."""

    def test_multiple_iterations(self):
        """Should support multiple iterations over the same result."""
        from gmaps_extractor.extractor import CollectionResult

        data = {"businesses": [{"name": "A"}, {"name": "B"}]}
        result = CollectionResult(data)

        first = list(result)
        second = list(result)
        assert first == second

    def test_boolean_truthiness(self):
        """Empty result is falsy because __len__ returns 0 (standard Python protocol).

        When __len__ is defined, Python uses it for bool evaluation.
        An empty CollectionResult is falsy, a non-empty one is truthy.
        """
        from gmaps_extractor.extractor import CollectionResult

        empty = CollectionResult({"businesses": []})
        assert len(empty) == 0
        assert not empty  # falsy because __len__ returns 0

        non_empty = CollectionResult({"businesses": [{"name": "A"}]})
        assert len(non_empty) == 1
        assert non_empty  # truthy because __len__ returns > 0

    def test_businesses_list_is_mutable(self):
        """Businesses list should be the actual list from data (not a copy)."""
        from gmaps_extractor.extractor import CollectionResult

        data = {"businesses": [{"name": "Test"}]}
        result = CollectionResult(data)
        result.businesses.append({"name": "Added"})
        assert len(result) == 2
