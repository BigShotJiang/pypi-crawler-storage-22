"""gmcp - Transform any FastAPI server into an MCP server."""

__version__ = "0.2.0"
