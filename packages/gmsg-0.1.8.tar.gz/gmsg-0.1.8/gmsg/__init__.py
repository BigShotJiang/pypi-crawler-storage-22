from .gmsg import main
