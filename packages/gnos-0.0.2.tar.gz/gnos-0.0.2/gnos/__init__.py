"""gnos: local-first verifier for content-addressed documents."""

__all__ = ["__version__"]
__version__ = "0.0.0"
