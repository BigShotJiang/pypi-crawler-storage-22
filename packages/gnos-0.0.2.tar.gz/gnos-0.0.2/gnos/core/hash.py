"""Hashing utilities.

gnos v1 treats documents as raw bytes. No byte normalization is performed.
"""

from __future__ import annotations

import hashlib


def canonicalize_bytes(data: bytes) -> bytes:
    """Return document bytes unchanged.

    gnos intentionally does not normalize bytes (including newlines). Document
    identity is defined over raw bytes.
    """
    return data


def sha256_hex(data: bytes) -> str:
    """Return lowercase hex SHA-256 digest for bytes."""
    return hashlib.sha256(data).hexdigest()


def hash_canonical_bytes(data: bytes) -> str:
    """Canonicalize bytes then hash (SHA-256)."""
    return sha256_hex(canonicalize_bytes(data))
