"""Local index helpers (optional)."""
