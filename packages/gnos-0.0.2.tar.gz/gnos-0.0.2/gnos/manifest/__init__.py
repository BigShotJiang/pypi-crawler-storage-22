"""Manifest schema and codec."""
