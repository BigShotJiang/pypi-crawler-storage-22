import tempfile
import unittest
from pathlib import Path

from gnos.core.add import add_path
from gnos.core.store import ObjectStore


class TestAddChunkingDefaults(unittest.TestCase):
    def test_add_sequential_v1_sets_default_params(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            store = ObjectStore(root / ".gnos")
            store.init()
            path = root / "a.txt"
            path.write_text("hello\n", encoding="utf-8")
            result = add_path(path, store, chunking="sequential-v1").results[0]
            self.assertEqual(result.chunking["method"], "sequential-v1")
            self.assertEqual(result.chunking["params"]["chunk_size"], 1024 * 1024)


if __name__ == "__main__":
    unittest.main()

