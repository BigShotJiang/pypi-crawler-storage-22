import tempfile
import unittest
from pathlib import Path

from gnos.core.add import add_collection
from gnos.core.store import ObjectStore
from gnos.manifest.codec import load_collection_bytes


class TestAddCollection(unittest.TestCase):
    def test_add_collection_dir(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            store = ObjectStore(root / ".gnos")
            store.init()

            docs = root / "docs"
            docs.mkdir()
            (docs / "a.md").write_text("# A\n", encoding="utf-8")
            (docs / "b.md").write_text("# B\n", encoding="utf-8")

            result = add_collection(docs, store)
            self.assertTrue(store.has(result.collection_id))

            blob = store.get(result.collection_id)
            self.assertIsNotNone(blob)
            col = load_collection_bytes(blob)
            self.assertEqual(len(col.documents), 2)
            self.assertEqual(col.documents[0].path, "a.md")
            self.assertEqual(col.documents[1].path, "b.md")


if __name__ == "__main__":
    unittest.main()
