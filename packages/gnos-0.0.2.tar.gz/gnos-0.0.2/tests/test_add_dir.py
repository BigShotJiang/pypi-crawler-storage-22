import tempfile
import unittest
from pathlib import Path

from gnos.core.add import add_path
from gnos.core.store import ObjectStore


class TestAddDir(unittest.TestCase):
    def test_add_directory(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            store = ObjectStore(root / ".gnos")
            store.init()

            docs = root / "docs"
            docs.mkdir()
            (docs / "a.md").write_text("# A\n", encoding="utf-8")
            (docs / "b.md").write_text("# B\n", encoding="utf-8")

            result = add_path(docs, store)
            self.assertEqual(len(result.results), 2)


if __name__ == "__main__":
    unittest.main()
