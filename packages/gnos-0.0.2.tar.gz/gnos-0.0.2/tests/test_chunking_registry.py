import unittest

from gnos.chunking.registry import get_method


class TestChunkingRegistry(unittest.TestCase):
    def test_get_method(self) -> None:
        m = get_method("sequential-v1")
        self.assertEqual(m.name, "sequential-v1")
        self.assertEqual(m.describe(), "sequential-v1")

    def test_unknown_method(self) -> None:
        with self.assertRaises(ValueError):
            get_method("unknown")


if __name__ == "__main__":
    unittest.main()
