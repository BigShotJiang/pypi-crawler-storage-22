import tempfile
import unittest
from pathlib import Path

from gnos.cli.main import main
from gnos.core.store import ObjectStore


class TestCliAddDryRun(unittest.TestCase):
    def test_add_dry_run_writes_nothing(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            old = Path.cwd()
            try:
                import os

                os.chdir(root)
                Path("a.txt").write_text("hello\n", encoding="utf-8")
                self.assertEqual(main(["init"]), 0)

                store = ObjectStore(Path(".gnos"))
                self.assertEqual(len([p for p in store.objects_dir().rglob("*") if p.is_file()]), 0)

                self.assertEqual(main(["add", "a.txt", "--dry-run", "--verbose"]), 0)

                # No objects and no index on dry-run.
                self.assertEqual(len([p for p in store.objects_dir().rglob("*") if p.is_file()]), 0)
                self.assertFalse((Path(".gnos") / "index.json").exists())
            finally:
                os.chdir(old)

    def test_add_collection_dry_run_writes_nothing(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            old = Path.cwd()
            try:
                import os

                os.chdir(root)
                (Path("docs") / "sub").mkdir(parents=True)
                Path("docs/a.md").write_text("# a\n", encoding="utf-8")
                Path("docs/sub/b.md").write_text("# b\n", encoding="utf-8")

                self.assertEqual(main(["init"]), 0)
                store = ObjectStore(Path(".gnos"))
                self.assertEqual(len([p for p in store.objects_dir().rglob("*") if p.is_file()]), 0)

                self.assertEqual(main(["add", "--collection", "docs", "--dry-run", "--verbose"]), 0)
                self.assertEqual(len([p for p in store.objects_dir().rglob("*") if p.is_file()]), 0)
                self.assertFalse((Path(".gnos") / "index.json").exists())
            finally:
                os.chdir(old)


if __name__ == "__main__":
    unittest.main()

