import io
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path

from gnos.cli.main import main


class TestCliAddQuiet(unittest.TestCase):
    def test_add_quiet_by_default(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            old_cwd = Path.cwd()
            try:
                import os

                os.chdir(root)
                main(["init"])
                (root / "a.md").write_text("# A\n", encoding="utf-8")

                buf = io.StringIO()
                with redirect_stdout(buf):
                    exit_code = main(["add", "a.md"])

                self.assertEqual(exit_code, 0)
                self.assertEqual(buf.getvalue(), "")
            finally:
                os.chdir(old_cwd)


if __name__ == "__main__":
    unittest.main()
