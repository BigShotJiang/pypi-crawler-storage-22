import io
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path

from gnos.cli.main import main


class TestCliAddVerbose(unittest.TestCase):
    def test_add_verbose_prints_details(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            old_cwd = Path.cwd()
            try:
                import os

                os.chdir(root)
                self.assertEqual(main(["init"]), 0)
                (root / "a.md").write_text("# A\n", encoding="utf-8")

                buf = io.StringIO()
                with redirect_stdout(buf):
                    exit_code = main(["add", "a.md", "--verbose"])
                self.assertEqual(exit_code, 0)
                out = buf.getvalue()
                self.assertIn("added document:", out)
                self.assertIn("chunking:", out)
            finally:
                os.chdir(old_cwd)

    def test_add_collection_verbose_prints_collection_id(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            old_cwd = Path.cwd()
            try:
                import os

                os.chdir(root)
                self.assertEqual(main(["init"]), 0)
                docs = root / "docs"
                docs.mkdir()
                (docs / "a.md").write_text("# A\n", encoding="utf-8")

                buf = io.StringIO()
                with redirect_stdout(buf):
                    exit_code = main(["add", "-C", "docs", "--verbose"])
                self.assertEqual(exit_code, 0)
                out = buf.getvalue()
                self.assertIn("added collection:", out)
                self.assertIn("collection_id:", out)
            finally:
                os.chdir(old_cwd)


if __name__ == "__main__":
    unittest.main()
