import io
import tempfile
import unittest
from contextlib import redirect_stderr
from pathlib import Path

from gnos.cli.main import main


class TestCliAddWithoutInit(unittest.TestCase):
    def test_add_without_init_fails(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            old_cwd = Path.cwd()
            try:
                import os

                os.chdir(root)
                (root / "a.md").write_text("# A\n", encoding="utf-8")
                err = io.StringIO()
                with redirect_stderr(err):
                    exit_code = main(["add", "a.md"])
                self.assertEqual(exit_code, 1)
                self.assertIn("store not initialized", err.getvalue())
            finally:
                os.chdir(old_cwd)


if __name__ == "__main__":
    unittest.main()

