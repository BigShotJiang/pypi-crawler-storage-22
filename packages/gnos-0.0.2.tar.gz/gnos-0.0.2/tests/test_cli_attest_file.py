import tempfile
import unittest
from pathlib import Path

from gnos.cli.main import main
from gnos.core.hash import sha256_hex, canonicalize_bytes


class TestCliAttestFile(unittest.TestCase):
    def test_attest_file_ok(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "a.txt"
            path.write_text("hello\n", encoding="utf-8")
            doc_id = sha256_hex(canonicalize_bytes(path.read_bytes()))
            exit_code = main(["attest", "file", str(path), "--doc-id", doc_id])
            self.assertEqual(exit_code, 0)

    def test_attest_file_fail(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "a.txt"
            path.write_text("hello\n", encoding="utf-8")
            exit_code = main(["attest", "file", str(path), "--doc-id", "0" * 64])
            self.assertEqual(exit_code, 2)


if __name__ == "__main__":
    unittest.main()
