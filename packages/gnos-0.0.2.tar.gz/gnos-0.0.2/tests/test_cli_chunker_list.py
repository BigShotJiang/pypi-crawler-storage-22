import io
import unittest
from contextlib import redirect_stdout

from gnos.cli.main import main


class TestCliChunkerList(unittest.TestCase):
    def test_chunker_list(self) -> None:
        buf = io.StringIO()
        with redirect_stdout(buf):
            exit_code = main(["chunker", "list"])
        self.assertEqual(exit_code, 0)
        out = buf.getvalue()
        self.assertIn("identity-v1", out)
        self.assertIn("sequential-v1", out)
        self.assertIn("framed-sequential-v1", out)

    def test_chunker_list_verbose_includes_source(self) -> None:
        buf = io.StringIO()
        with redirect_stdout(buf):
            exit_code = main(["chunker", "list", "--verbose"])
        self.assertEqual(exit_code, 0)
        out = buf.getvalue()
        self.assertIn("identity-v1\tcore", out)


if __name__ == "__main__":
    unittest.main()

