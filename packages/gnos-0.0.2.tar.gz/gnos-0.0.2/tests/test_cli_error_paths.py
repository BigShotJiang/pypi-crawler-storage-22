import tempfile
import unittest
from pathlib import Path

from gnos.cli.main import main


class TestCliErrorPaths(unittest.TestCase):
    def test_attest_manifest_missing(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            old_cwd = Path.cwd()
            try:
                import os

                os.chdir(root)
                main(["init"])
                exit_code = main(["attest", "manifest", "0" * 64])
                self.assertEqual(exit_code, 1)
            finally:
                os.chdir(old_cwd)

    def test_attest_file_bad_path(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            old_cwd = Path.cwd()
            try:
                import os

                os.chdir(root)
                exit_code = main(["attest", "file", "missing.txt", "--doc-id", "0" * 64])
                self.assertEqual(exit_code, 1)
            finally:
                os.chdir(old_cwd)


if __name__ == "__main__":
    unittest.main()
