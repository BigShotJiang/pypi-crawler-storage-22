import io
import tempfile
import unittest
from contextlib import redirect_stderr
from pathlib import Path

from gnos.cli.main import main


class TestCliMaterializeDocFailure(unittest.TestCase):
    def test_materialize_doc_failure_exit_code(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            old_cwd = Path.cwd()
            try:
                import os

                os.chdir(root)
                self.assertEqual(main(["init"]), 0)
                err = io.StringIO()
                with redirect_stderr(err):
                    exit_code = main(["materialize", "doc", "0" * 64, "--output", "out.txt"])
                self.assertEqual(exit_code, 2)
                self.assertIn("materialize failed:", err.getvalue())
            finally:
                os.chdir(old_cwd)


if __name__ == "__main__":
    unittest.main()

