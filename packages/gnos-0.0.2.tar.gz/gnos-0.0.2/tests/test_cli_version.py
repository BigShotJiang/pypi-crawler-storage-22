import io
import unittest
from contextlib import redirect_stdout

from gnos.cli.main import main


class TestCliVersion(unittest.TestCase):
    def test_version_flag(self) -> None:
        buf = io.StringIO()
        with redirect_stdout(buf):
            exit_code = main(["--version"])
        self.assertEqual(exit_code, 0)
        self.assertTrue(buf.getvalue().strip())


if __name__ == "__main__":
    unittest.main()
