import unittest

from gnos.manifest.schema import CollectionManifest
from gnos.manifest.codec import dump_collection_bytes, load_collection_bytes


class TestCollectionManifest(unittest.TestCase):
    def test_roundtrip(self) -> None:
        data = {
            "type": "collection-manifest",
            "version": 1,
            "documents": [
                {"doc_id": "a" * 64, "path": "README.md"},
                {"doc_id": "b" * 64},
            ],
        }
        manifest = CollectionManifest.from_dict(data)
        blob = dump_collection_bytes(manifest)
        loaded = load_collection_bytes(blob)
        self.assertEqual(loaded.documents[0].doc_id, "a" * 64)
        self.assertEqual(loaded.documents[0].path, "README.md")
        self.assertEqual(loaded.documents[1].doc_id, "b" * 64)
        self.assertIsNone(loaded.documents[1].path)

    def test_missing_doc_id(self) -> None:
        data = {
            "type": "collection-manifest",
            "version": 1,
            "documents": [{"path": "README.md"}],
        }
        with self.assertRaises(ValueError):
            CollectionManifest.from_dict(data)


if __name__ == "__main__":
    unittest.main()
