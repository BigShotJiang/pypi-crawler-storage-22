import tempfile
import unittest
from pathlib import Path

from gnos.core.add import add_path
from gnos.core.store import ObjectStore


class TestFormatInfer(unittest.TestCase):
    def test_infer_markdown(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            store = ObjectStore(root / ".gnos")
            store.init()
            path = root / "README.md"
            path.write_text("# Title\n", encoding="utf-8")
            result = add_path(path, store).results[0]
            self.assertEqual(result.format, "markdown")
            self.assertEqual(result.chunking["method"], "framed-sequential-v1")

    def test_infer_python(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            store = ObjectStore(root / ".gnos")
            store.init()
            path = root / "script.py"
            path.write_text("print('hi')\n", encoding="utf-8")
            result = add_path(path, store).results[0]
            self.assertEqual(result.format, "python")
            self.assertEqual(result.chunking["method"], "framed-sequential-v1")

    def test_infer_json(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            store = ObjectStore(root / ".gnos")
            store.init()
            path = root / "data.json"
            path.write_text('{"a": 1}\n', encoding="utf-8")
            result = add_path(path, store).results[0]
            self.assertEqual(result.format, "json")
            self.assertEqual(result.chunking["method"], "framed-sequential-v1")

    def test_infer_unknown_extension_defaults_text(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            store = ObjectStore(root / ".gnos")
            store.init()
            path = root / "data.bin"
            path.write_bytes(b"\x00\x01\x02")
            result = add_path(path, store).results[0]
            self.assertEqual(result.format, "text")
            self.assertEqual(result.chunking["method"], "framed-sequential-v1")


if __name__ == "__main__":
    unittest.main()
