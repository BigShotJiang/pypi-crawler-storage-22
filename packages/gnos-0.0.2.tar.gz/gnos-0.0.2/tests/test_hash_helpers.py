import unittest

from gnos.core.hash import hash_canonical_bytes


class TestHashHelpers(unittest.TestCase):
    def test_hash_canonical_bytes(self) -> None:
        a = hash_canonical_bytes(b"a\r\nb\r\n")
        b = hash_canonical_bytes(b"a\nb\n")
        self.assertNotEqual(a, b)


if __name__ == "__main__":
    unittest.main()
