import tempfile
import unittest
from pathlib import Path

from gnos.index.local import LocalIndex


class TestLocalIndex(unittest.TestCase):
    def test_record_manifest(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            index = LocalIndex(root / "index.json")
            index.record_manifest(
                doc_id="d" * 64,
                manifest_hash="m" * 64,
                format="markdown",
                chunking={"method": "sequential-v1", "params": {"chunk_size": 1024}},
                chunks=[{"hash": "c" * 64}],
            )
            data = index.load()
            self.assertIn("d" * 64, data["documents"])
            self.assertIn("m" * 64, data["manifests"])
            self.assertIn("c" * 64, data["chunks"])


if __name__ == "__main__":
    unittest.main()
