import unittest

from gnos.manifest.schema import DocManifest


class TestManifestChunking(unittest.TestCase):
    def test_chunking_requires_method(self) -> None:
        data = {
            "type": "doc-manifest",
            "version": 1,
            "doc_id": "x",
            "format": "markdown",
            "chunking": {"params": {}},
            "chunks": [],
        }
        with self.assertRaises(ValueError):
            DocManifest.from_dict(data)

    def test_chunking_params_defaults(self) -> None:
        data = {
            "type": "doc-manifest",
            "version": 1,
            "doc_id": "x",
            "format": "markdown",
            "chunking": {"method": "sequential-v1"},
            "chunks": [{"hash": "a"}],
        }
        manifest = DocManifest.from_dict(data)
        self.assertEqual(manifest.chunking["method"], "sequential-v1")
        self.assertEqual(manifest.chunking["params"], {})


if __name__ == "__main__":
    unittest.main()
