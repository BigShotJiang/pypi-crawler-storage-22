import unittest

from gnos.manifest.schema import CollectionManifest


class TestCollectionSchemaErrors(unittest.TestCase):
    def test_missing_fields(self) -> None:
        with self.assertRaises(ValueError):
            CollectionManifest.from_dict({"type": "collection-manifest"})

    def test_wrong_type(self) -> None:
        data = {"type": "wrong", "version": 1, "documents": []}
        with self.assertRaises(ValueError):
            CollectionManifest.from_dict(data)

    def test_wrong_version(self) -> None:
        data = {"type": "collection-manifest", "version": 2, "documents": []}
        with self.assertRaises(ValueError):
            CollectionManifest.from_dict(data)

    def test_documents_not_list(self) -> None:
        data = {"type": "collection-manifest", "version": 1, "documents": "x"}
        with self.assertRaises(ValueError):
            CollectionManifest.from_dict(data)


if __name__ == "__main__":
    unittest.main()
