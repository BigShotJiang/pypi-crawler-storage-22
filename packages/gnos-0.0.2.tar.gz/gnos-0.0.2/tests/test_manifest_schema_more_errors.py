import unittest

from gnos.manifest.schema import DocManifest


class TestManifestSchemaMoreErrors(unittest.TestCase):
    def test_chunking_method_empty(self) -> None:
        data = {
            "type": "doc-manifest",
            "version": 1,
            "doc_id": "x",
            "format": "text",
            "chunking": {"method": "", "params": {}},
            "chunks": [{"hash": "a"}],
        }
        with self.assertRaises(ValueError):
            DocManifest.from_dict(data)

    def test_chunking_params_wrong_type(self) -> None:
        data = {
            "type": "doc-manifest",
            "version": 1,
            "doc_id": "x",
            "format": "text",
            "chunking": {"method": "sequential-v1", "params": "nope"},
            "chunks": [{"hash": "a"}],
        }
        with self.assertRaises(ValueError):
            DocManifest.from_dict(data)

    def test_chunking_params_key_not_string(self) -> None:
        data = {
            "type": "doc-manifest",
            "version": 1,
            "doc_id": "x",
            "format": "text",
            "chunking": {"method": "sequential-v1", "params": {1: "nope"}},
            "chunks": [{"hash": "a"}],
        }
        with self.assertRaises(ValueError):
            DocManifest.from_dict(data)

    def test_chunking_params_none_defaults(self) -> None:
        data = {
            "type": "doc-manifest",
            "version": 1,
            "doc_id": "x",
            "format": "text",
            "chunking": {"method": "sequential-v1", "params": None},
            "chunks": [{"hash": "a"}],
        }
        manifest = DocManifest.from_dict(data)
        self.assertEqual(manifest.chunking["params"], {})

    def test_chunking_not_object(self) -> None:
        data = {
            "type": "doc-manifest",
            "version": 1,
            "doc_id": "x",
            "format": "text",
            "chunking": "nope",
            "chunks": [{"hash": "a"}],
        }
        with self.assertRaises(ValueError):
            DocManifest.from_dict(data)

    def test_chunk_entry_not_object(self) -> None:
        data = {
            "type": "doc-manifest",
            "version": 1,
            "doc_id": "x",
            "format": "text",
            "chunking": {"method": "sequential-v1", "params": {}},
            "chunks": ["not-an-object"],
        }
        with self.assertRaises(ValueError):
            DocManifest.from_dict(data)

    def test_chunk_entry_missing_hash(self) -> None:
        data = {
            "type": "doc-manifest",
            "version": 1,
            "doc_id": "x",
            "format": "text",
            "chunking": {"method": "sequential-v1", "params": {}},
            "chunks": [{}],
        }
        with self.assertRaises(ValueError):
            DocManifest.from_dict(data)

    def test_chunk_entry_key_not_string(self) -> None:
        data = {
            "type": "doc-manifest",
            "version": 1,
            "doc_id": "x",
            "format": "text",
            "chunking": {"method": "sequential-v1", "params": {}},
            "chunks": [{1: "nope", "hash": "a"}],
        }
        with self.assertRaises(ValueError):
            DocManifest.from_dict(data)

    def test_chunk_hash_empty(self) -> None:
        data = {
            "type": "doc-manifest",
            "version": 1,
            "doc_id": "x",
            "format": "text",
            "chunking": {"method": "sequential-v1", "params": {}},
            "chunks": [{"hash": ""}],
        }
        with self.assertRaises(ValueError):
            DocManifest.from_dict(data)


if __name__ == "__main__":
    unittest.main()
