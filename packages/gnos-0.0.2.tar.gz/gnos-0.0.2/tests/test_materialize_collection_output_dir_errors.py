import tempfile
import unittest
from pathlib import Path

from gnos.cli.main import main


class TestMaterializeCollectionOutputDirErrors(unittest.TestCase):
    def test_materialize_collection_refuses_non_empty_dir(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            old_cwd = Path.cwd()
            try:
                import os

                os.chdir(root)
                self.assertEqual(main(["init"]), 0)
                docs = root / "docs"
                docs.mkdir()
                (docs / "a.md").write_text("# A\n", encoding="utf-8")
                self.assertEqual(main(["add", "-C", "docs"]), 0)

                # Find collection_id by scanning store for the collection manifest blob.
                store_dir = root / ".gnos" / "objects"
                collection_id = None
                for obj in store_dir.rglob("*"):
                    if not obj.is_file():
                        continue
                    if b"collection-manifest" in obj.read_bytes():
                        collection_id = obj.name
                        break
                self.assertIsNotNone(collection_id)

                out_dir = root / "out"
                out_dir.mkdir()
                (out_dir / "keep.txt").write_text("keep\n", encoding="utf-8")

                exit_code = main(["materialize", "collection", collection_id, "--dir", "out"])
                self.assertNotEqual(exit_code, 0)
                self.assertTrue((out_dir / "keep.txt").exists())
            finally:
                os.chdir(old_cwd)


if __name__ == "__main__":
    unittest.main()

