import unittest

from gnos.manifest.schema import DocManifest


class TestManifestSchemaErrors(unittest.TestCase):
    def test_missing_fields(self) -> None:
        with self.assertRaises(ValueError):
            DocManifest.from_dict({"type": "doc-manifest"})

    def test_wrong_type(self) -> None:
        data = {
            "type": "wrong",
            "version": 1,
            "doc_id": "x",
            "format": "markdown",
            "chunking": {"method": "sequential-v1", "params": {"chunk_size": 1024}},
            "chunks": [{"hash": "a"}],
        }
        with self.assertRaises(ValueError):
            DocManifest.from_dict(data)

    def test_wrong_version(self) -> None:
        data = {
            "type": "doc-manifest",
            "version": 2,
            "doc_id": "x",
            "format": "markdown",
            "chunking": {"method": "sequential-v1", "params": {"chunk_size": 1024}},
            "chunks": [{"hash": "a"}],
        }
        with self.assertRaises(ValueError):
            DocManifest.from_dict(data)

    def test_chunks_not_list(self) -> None:
        data = {
            "type": "doc-manifest",
            "version": 1,
            "doc_id": "x",
            "format": "markdown",
            "chunking": {"method": "sequential-v1", "params": {"chunk_size": 1024}},
            "chunks": "not-a-list",
        }
        with self.assertRaises(ValueError):
            DocManifest.from_dict(data)


if __name__ == "__main__":
    unittest.main()
