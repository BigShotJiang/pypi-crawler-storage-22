import io
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path

from gnos.cli.main import main


class TestStatusManifestCounts(unittest.TestCase):
    def test_status_counts_doc_manifests(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            old_cwd = Path.cwd()
            try:
                import os

                os.chdir(root)
                self.assertEqual(main(["init"]), 0)
                (root / "a.md").write_text("# A\n", encoding="utf-8")
                self.assertEqual(main(["add", "a.md"]), 0)
                buf = io.StringIO()
                with redirect_stdout(buf):
                    self.assertEqual(main(["status"]), 0)
                out = buf.getvalue().splitlines()
                # Find store status doc-manifests line (after "store status:")
                store_docs = None
                for i, line in enumerate(out):
                    if line.strip() == "store status:" and i + 1 < len(out):
                        for j in range(i + 1, len(out)):
                            if out[j].strip().startswith("doc-manifests:"):
                                store_docs = out[j].strip()
                                break
                        break
                self.assertIsNotNone(store_docs)
                self.assertNotIn("doc-manifests: 0", store_docs)
            finally:
                os.chdir(old_cwd)


if __name__ == "__main__":
    unittest.main()
