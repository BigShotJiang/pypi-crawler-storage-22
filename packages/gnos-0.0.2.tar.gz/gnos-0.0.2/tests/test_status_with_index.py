import tempfile
import unittest
from pathlib import Path

from gnos.cli.main import main


class TestStatusWithIndex(unittest.TestCase):
    def test_status_counts(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            old_cwd = Path.cwd()
            try:
                import os

                os.chdir(root)
                main(["init"])
                (root / "a.md").write_text("# A\n", encoding="utf-8")
                main(["add", "a.md"])
                exit_code = main(["status"])
                self.assertEqual(exit_code, 0)
            finally:
                os.chdir(old_cwd)


if __name__ == "__main__":
    unittest.main()
