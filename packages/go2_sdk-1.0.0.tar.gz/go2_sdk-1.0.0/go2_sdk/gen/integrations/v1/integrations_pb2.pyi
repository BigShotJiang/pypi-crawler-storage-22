import datetime

from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class IntegrationType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    INTEGRATION_TYPE_UNSPECIFIED: _ClassVar[IntegrationType]
    INTEGRATION_TYPE_SLACK: _ClassVar[IntegrationType]
    INTEGRATION_TYPE_DISCORD: _ClassVar[IntegrationType]
    INTEGRATION_TYPE_TELEGRAM: _ClassVar[IntegrationType]
    INTEGRATION_TYPE_SEGMENT: _ClassVar[IntegrationType]
    INTEGRATION_TYPE_ZAPIER: _ClassVar[IntegrationType]
INTEGRATION_TYPE_UNSPECIFIED: IntegrationType
INTEGRATION_TYPE_SLACK: IntegrationType
INTEGRATION_TYPE_DISCORD: IntegrationType
INTEGRATION_TYPE_TELEGRAM: IntegrationType
INTEGRATION_TYPE_SEGMENT: IntegrationType
INTEGRATION_TYPE_ZAPIER: IntegrationType

class Integration(_message.Message):
    __slots__ = ("id", "user_id", "type", "name", "config", "events", "is_active", "last_triggered_at", "trigger_count", "created_at", "updated_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    USER_ID_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    CONFIG_FIELD_NUMBER: _ClassVar[int]
    EVENTS_FIELD_NUMBER: _ClassVar[int]
    IS_ACTIVE_FIELD_NUMBER: _ClassVar[int]
    LAST_TRIGGERED_AT_FIELD_NUMBER: _ClassVar[int]
    TRIGGER_COUNT_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    user_id: str
    type: IntegrationType
    name: str
    config: IntegrationConfig
    events: _containers.RepeatedScalarFieldContainer[str]
    is_active: bool
    last_triggered_at: _timestamp_pb2.Timestamp
    trigger_count: int
    created_at: _timestamp_pb2.Timestamp
    updated_at: _timestamp_pb2.Timestamp
    def __init__(self, id: _Optional[str] = ..., user_id: _Optional[str] = ..., type: _Optional[_Union[IntegrationType, str]] = ..., name: _Optional[str] = ..., config: _Optional[_Union[IntegrationConfig, _Mapping]] = ..., events: _Optional[_Iterable[str]] = ..., is_active: bool = ..., last_triggered_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., trigger_count: _Optional[int] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., updated_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class IntegrationConfig(_message.Message):
    __slots__ = ("webhook_url", "channel", "bot_token", "chat_id", "write_key")
    WEBHOOK_URL_FIELD_NUMBER: _ClassVar[int]
    CHANNEL_FIELD_NUMBER: _ClassVar[int]
    BOT_TOKEN_FIELD_NUMBER: _ClassVar[int]
    CHAT_ID_FIELD_NUMBER: _ClassVar[int]
    WRITE_KEY_FIELD_NUMBER: _ClassVar[int]
    webhook_url: str
    channel: str
    bot_token: str
    chat_id: str
    write_key: str
    def __init__(self, webhook_url: _Optional[str] = ..., channel: _Optional[str] = ..., bot_token: _Optional[str] = ..., chat_id: _Optional[str] = ..., write_key: _Optional[str] = ...) -> None: ...

class ListIntegrationsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListIntegrationsResponse(_message.Message):
    __slots__ = ("integrations",)
    INTEGRATIONS_FIELD_NUMBER: _ClassVar[int]
    integrations: _containers.RepeatedCompositeFieldContainer[Integration]
    def __init__(self, integrations: _Optional[_Iterable[_Union[Integration, _Mapping]]] = ...) -> None: ...

class CreateIntegrationRequest(_message.Message):
    __slots__ = ("type", "name", "config", "events")
    TYPE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    CONFIG_FIELD_NUMBER: _ClassVar[int]
    EVENTS_FIELD_NUMBER: _ClassVar[int]
    type: IntegrationType
    name: str
    config: IntegrationConfig
    events: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, type: _Optional[_Union[IntegrationType, str]] = ..., name: _Optional[str] = ..., config: _Optional[_Union[IntegrationConfig, _Mapping]] = ..., events: _Optional[_Iterable[str]] = ...) -> None: ...

class GetIntegrationRequest(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...

class UpdateIntegrationRequest(_message.Message):
    __slots__ = ("id", "name", "config", "events", "is_active")
    ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    CONFIG_FIELD_NUMBER: _ClassVar[int]
    EVENTS_FIELD_NUMBER: _ClassVar[int]
    IS_ACTIVE_FIELD_NUMBER: _ClassVar[int]
    id: str
    name: str
    config: IntegrationConfig
    events: _containers.RepeatedScalarFieldContainer[str]
    is_active: bool
    def __init__(self, id: _Optional[str] = ..., name: _Optional[str] = ..., config: _Optional[_Union[IntegrationConfig, _Mapping]] = ..., events: _Optional[_Iterable[str]] = ..., is_active: bool = ...) -> None: ...

class DeleteIntegrationRequest(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...

class DeleteIntegrationResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class TestIntegrationRequest(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...

class TestIntegrationResponse(_message.Message):
    __slots__ = ("success", "message")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    success: bool
    message: str
    def __init__(self, success: bool = ..., message: _Optional[str] = ...) -> None: ...

class GetIntegrationTypesRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class GetIntegrationTypesResponse(_message.Message):
    __slots__ = ("types", "events")
    TYPES_FIELD_NUMBER: _ClassVar[int]
    EVENTS_FIELD_NUMBER: _ClassVar[int]
    types: _containers.RepeatedCompositeFieldContainer[IntegrationTypeInfo]
    events: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, types: _Optional[_Iterable[_Union[IntegrationTypeInfo, _Mapping]]] = ..., events: _Optional[_Iterable[str]] = ...) -> None: ...

class IntegrationTypeInfo(_message.Message):
    __slots__ = ("type", "name", "description", "icon", "available", "config_fields")
    TYPE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    ICON_FIELD_NUMBER: _ClassVar[int]
    AVAILABLE_FIELD_NUMBER: _ClassVar[int]
    CONFIG_FIELDS_FIELD_NUMBER: _ClassVar[int]
    type: IntegrationType
    name: str
    description: str
    icon: str
    available: bool
    config_fields: _containers.RepeatedCompositeFieldContainer[ConfigField]
    def __init__(self, type: _Optional[_Union[IntegrationType, str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., icon: _Optional[str] = ..., available: bool = ..., config_fields: _Optional[_Iterable[_Union[ConfigField, _Mapping]]] = ...) -> None: ...

class ConfigField(_message.Message):
    __slots__ = ("name", "label", "field_type", "required", "placeholder", "help_text")
    NAME_FIELD_NUMBER: _ClassVar[int]
    LABEL_FIELD_NUMBER: _ClassVar[int]
    FIELD_TYPE_FIELD_NUMBER: _ClassVar[int]
    REQUIRED_FIELD_NUMBER: _ClassVar[int]
    PLACEHOLDER_FIELD_NUMBER: _ClassVar[int]
    HELP_TEXT_FIELD_NUMBER: _ClassVar[int]
    name: str
    label: str
    field_type: str
    required: bool
    placeholder: str
    help_text: str
    def __init__(self, name: _Optional[str] = ..., label: _Optional[str] = ..., field_type: _Optional[str] = ..., required: bool = ..., placeholder: _Optional[str] = ..., help_text: _Optional[str] = ...) -> None: ...
