"""Goal - Automated git push with smart commit messages, changelog updates, and version tagging."""

__version__ = "2.1.4"
