"""Memory ingestion components for multimodal content."""

from gobby.memory.ingestion.multimodal import MultimodalIngestor

__all__ = ["MultimodalIngestor"]
