"""Memory services for cross-referencing and linking."""

from gobby.memory.services.crossref import CrossrefService

__all__ = ["CrossrefService"]
