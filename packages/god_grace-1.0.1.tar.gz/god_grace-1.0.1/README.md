﻿# 🛠️ God-Grace: Python Multi-Utility Toolkit

**God-Grace** ek comprehensive collection hai Python utility functions ki jo arithmetic, mathematical logic, string analysis, aur data management ko asaan banati hai. Ye toolkit multiple data types ko handle karne aur user-provided data ke detailed insights dene ke liye design kiya gaya hai.

---

## 🚀 Features & Usage Examples

### 1. Arithmetic & Power Operations
Ye functions `*args` ka use karte hain taaki aap ek saath kai saare inputs handle kar sakein.

| Function | Description | Example Usage | Result |
| :--- | :--- | :--- | :--- |
| `addends()` | Numbers ko jodta hai ya strings ko join karta hai. | `addends(10, 20)` / `addends("Py", "thon")` | `30` / `"Python"` |
| `minuend()` | Pehle value se baaki sab ko subtract karta hai. | `minuend(100, 10, 5)` | `85` |
| `product()` | Multiply karta hai ya strings ko repeat karta hai. | `product(5, 4)` / `product("Go", 3)` | `20` / `"GoGoGo"` |
| `divide()` | Sequence mein division karta hai (with error handling). | `divide(50, 5)` | `10.0` |
| `cube()` | Diye gaye numbers ka cube print karta hai. | `cube(2, 3)` | `Cube of 2 is 8...` |
| `squa()` | Diye gaye numbers ka square print karta hai. | `squa(4, 5)` | `Square of 4 is 16...` |

---

### 2. Mathematical Logic Checks
Functions jo numbers ki properties aur scientific categories verify karte hain.

* **`check_prime()`**: Check karta hai ki number sirf 1 aur khud se divide hota hai ya nahi.
* **`check_armstrong()`**: Verifies if the sum of digits raised to the power of 3 equals the number.
* **`check_perfect()`**: Check karta hai agar proper divisors ka sum number ke barabar hai.
* **`check_palindrome()`**: Verifies if a string/number reads the same backward.
* **`check_leap_year(year)`**: Logic-based check for leap years.

---

### 3. Sequences & Calculations
* **`factorial()`**: 1 se lekar `n` tak ke saare integers ka product calculate karta hai.
* **`fibonacci_series()`**: Fibonacci sequence generate karta hai (e.g., 0, 1, 1, 2, 3).
* **`simple_intrest()`**: Principle, Rate, aur Time ke basis par interest calculate karta hai.
* **`sum_integer()`**: `n` se 0 tak ka total sum nikalta hai (supports negative input).

---

### 4. String & Text Analysis
* **`alphabet()`**: String ka detailed analysis (Vowels, Consonants, Case, Digits).
* **`count_frequency()`**: String mein kisi specific character ki frequency count karta hai.
* **`num_to_words()`**: Digits ko English word equivalents mein badalta hai (e.g., `45` → `"Four Five"`).

---

### 5. Data & Comparison Tools
* **`friends_phone()` / `friends_salary()`**: Data manage karta hai aur use **Tuple**, **List**, ya **Dictionary** format mein display karta hai.
* **`largest_number()` / `smallest_number()`**: Multiple numbers ko compare karke max/min aur unki frequency batata hai.
* **`count_odd_even()`**: 1 se `n` tak ki range mein Odd aur Even numbers count karta hai.
* **`traversing(*args)`**: Kisi bhi collection (List, Dict, Tuple) ko iterate karke elements print karta hai.

---

### 6. Loop-Based Utilities
* **`table()`**: 1 se lekar number `n` tak multiplication tables generate karta hai.
* **`reverse_counting()`**: `n` se 1 tak reverse counting print karta hai.

---

## 🛠️ How to Use

1.  **Library Import Karein:**
    ```python
    import God-Grace
    ```
2.  **Function Call Karein:**
    Aap function ko directly call kar sakte hain. Kuch functions input terminal mein mangenge:
    ```python
    # Table generator chalane ke liye:
    God-Grace.table()
    
    # Prime number check karne ke liye:
    God-Grace.check_prime()
    ```
3.  **Terminal Mein Run Karein:**
    ```bash
    pip install God-Grace
    ```

## 📝 License
This toolkit is open-source and free to use for educational purposes.