# __init__.py file ke andar
from .ganit import addends,minuend,product,divide,traversing,friends_phone,friends_salary,num_to_words,count_frequency,largest_number,smallest_number,check_perfect,check_armstrong,check_palindrome,check_prime,fibonacci_series,valid_age,factorial,reverse_counting,sum_integer,simple_intrest,cube,cube_sum,squa,squa_sum,table,count_odd_even,leap_year,alphabet
