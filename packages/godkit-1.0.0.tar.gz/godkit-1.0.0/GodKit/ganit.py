def addends(*args):
    string_hai = False
    for x in args:
        if type(x) == str:
            string_hai = True
            break
    
    if string_hai == True:
        sara_text = ""
        for x in args:
            sara_text = sara_text + str(x)
        return sara_text
    else:
        kul_jod = 0
        for x in args:
            kul_jod = kul_jod + x
        return kul_jod
    
def minuend(*args):
    result = args[0]
    for x in args[1:]:
        result = result - x
    return result

def product(*args):
    string_data = None
    number_data = 1
    
    for x in args:
        if type(x) == str:
            string_data = x
        else:
            number_data = number_data * x
            
    if string_data != None:
        return string_data * number_data
    else:
        return number_data

def divide(*args):
    for x in args:
        if type(x) == str:
            return "Error: Strings divide nahi hoti!"
            
    result = args[0]
    for x in args[1:]:
        if x == 0:
            return "Error: 0 se bhag nahi de sakte!"
        result = result / x
    return result

def traversing(*args):
    for data in args:
        print(f"\nTraversing data type: {type(data)}")
        if type(data) == dict:
            for key in data:
                print(f"Key: {key}, Value: {data[key]}")
        else:
            for item in data:
                print(item)
    return "Program Executed"

def friends_phone():
    friends_tupp = ()
    friends_dict = {}
    friends_list = []
    n = int(input("Enter a number of friends you want to add:- "))
    for i in range(n):
        name = input(f"Enter friend {i+1} name:- ")
        phone = int(input("Enter phone number:- "))
        friends_dict[name] = phone
        friends_list.append(name)
        friends_list.append(phone)
    print("\nSelect Options: \n () for Tuple \n [] for List \n {} for Dictionary \n (),[], {} for List, or all together")
    choice = input("Enter the format you want to see: ").strip()
    if "()" in choice and "[]" in choice and "{}" in choice:
        print("Tuple:", tuple(friends_list))
        print("List:", friends_list)
        print("Dictionary:", friends_dict)
    elif "{}" in choice:
        print("Dictionary:", friends_dict)
    elif "[]" in choice:
        print("List:", friends_list)
    elif "()" in choice:
        print("Tuple:", tuple(friends_list))
    else:
        print("Invalid choice! Showing everything by default:")
        print(friends_dict)
        print(friends_list)
    return "Program Executed"

def friends_salary():
    friends_tupp = ()
    friends_dict = {}
    friends_list = []
    n = int(input("Enter a number of friends you want to add:- "))
    for i in range(n):
        name = input(f"Enter friend {i+1} name:- ")
        sallery = int(input("Enter sallery:- "))
        friends_dict[name] = sallery
        friends_list.append(name)
        friends_list.append(sallery)
    print("\nSelect Options: \n () for Tuple \n [] for List \n {} for Dictionary \n (),[], {} for List, or all together")
    choice = input("Enter the format you want to see: ").strip()
    if "()" in choice and "[]" in choice and "{}" in choice:
        print("Tuple:", tuple(friends_list))
        print("List:", friends_list)
        print("Dictionary:", friends_dict)
    elif "{}" in choice:
        print("Dictionary:", friends_dict)
    elif "[]" in choice:
        print("List:", friends_list)
    elif "()" in choice:
        print("Tuple:", tuple(friends_list))
    else:
        print("Invalid choice! Showing everything by default:")
        print(friends_dict)
        print(friends_list)
    return "Program Executed"

def num_to_words():
    words_map = {'0':'Zero','1':'One','2':'Two','3':'Three',
                 '4':'Four','5':'Five','6':'Six','7':'Seven',
                 '8':'Eight','9':'Nine'}
    n=int(input("Enter a Number:- "))
    num_str=str(n)
    result=""
    for digit in num_str:
        result+=words_map[digit]+" "
    print(result)
    return "Program Executed"

def count_frequency():
    string=input("Enter a String:- ")
    char = input("Enter character to count:- ")
    count = 0
    for chars in string:
        if chars == char:
            count+=1
    print(f"{count} times")
    return "Program Executed"

def largest_number():
    n = int(input("Enter how many numbers to compare: "))
    max_no = float('-inf') 
    count = 0 
    for i in range(n):
        a = int(input(f"Enter Number {i+1}: "))
        if a > max_no:
            max_no = a
            count = 1
        elif a == max_no:
            count += 1
    print("---")
    print(f"The final Largest Number is: {max_no}")
    if count > 1:
        print(f"Note: This number was entered {count} times.")
    return "Program Executed"

def smallest_number():
    n = int(input("Enter how many numbers to compare: "))
    min_no = float('inf') 
    count = 0   
    for i in range(n):
        a = int(input(f"Enter Number {i+1}: "))
        if a < min_no:
            min_no = a
            count = 1
        elif a == min_no:
            count += 1
    print("---")
    print(f"The final Smallest Number is: {min_no}")
    if count > 1:
        print(f"Note: This number appeared {count} times.")
    return "Program Executed"

def check_perfect():
    num = int(input("Enter Number You Want To Check:- "))
    Sum = 0
    for i in range(1, num):
        if num % i == 0:
            Sum += i
    if Sum == num:
        print(num, "is a Perfect Number")
    else:
        print(num, "is not a Perfect Number")
    return "Program Executed"

def check_armstrong():
    num=int(input("Enter Number You Want To Check:- "))
    Sum=0
    ph=num
    while ph>0:
        digit = ph%10
        Sum+=digit**3
        ph//=10
    if num==Sum:
         print(num, "is a Armstrong Number")
    else:
        print(num, "is not a Armstrong Number")
    return "Program Executed"

def check_palindrome():
    a=eval(input("Enter a Name or Number:- "))
    if a==a[::-1]:
        print("Yes, It's Palindrome")
    else:
        print("Ohh, It's not Palindrome")
    return "Program Executed"

def check_prime():
    num = int(input("Enter a Number:- "))
    if num < 2:
        print(num, "is not a Prime Number")
        return
    a = int(num / 2) + 1
    for i in range(2, a):
        r = num % i
        if r == 0:
            print(num, "is not a Prime Number")
            break
    else:
        print(num, "is a Prime Number")

def fibonacci_series():
    t=int(input("Enter Number:- "))
    f=0
    s=1
    print(f,',',s,end=",")
    for i in range(2,t):
        n=f+s
        print(n,end=",")
        f=s
        s=n
    print("\n")
    return "Program Executed"

def valid_age():
    age = int(input("Enter Your Age:- "))
    if age>=18:
        print("yes, this age is valid for voting")
    else:
        print("No,this age is not valid for voting")
    return "Program Executed"

def factorial():
    num=int(input("Enter Number"))
    fact=1
    x=1
    while x<=num:
        fact=fact*x
        x+=1
    print("Factorial of",num,"is",fact)
    return "Program Executed"

def reverse_counting():
    n=int(input("Enter Number to Count Reverse:- "))
    for i in range(n,0,-1):
        print(i)
    return "Program Executed"

def sum_integer():
    print("Its return the sum from given number to 0, either number is + or -")
    n = int(input("Enter Last No to get sum:- "))
    su = 0
    if n >= 1:
        for i in range(1, n + 1):
            su += i
    elif n <= -1:
        for i in range(n, 1):
            su += i
    else:
        su = 0
    print("Total Sum is:", su)
    return "Program Executed"

def simple_intrest():
    P=int(input("Enter value of Principle:- "))
    R=int(input("Enter value of Rate:- "))
    T=int(input("Enter value of Time:- "))
    SI=(P*R*T)/100
    print("Simple Intrest is:- ",SI)
    return "Program Executed"

def cube(*numbers):
    cubes = [num ** 3 for num in numbers]
    for i, val in enumerate(numbers):
        print(f"Cube of {val} is {cubes[i]}")
    return "Program Executed"
        
def cube_sum(*args):
    return sum(x**3 for x in args)
    return "Program Executed"

def squa(*numbers):
    cubes = [num ** 2 for num in numbers]
    for i, val in enumerate(numbers):
        print(f"Cube of {val} is {cubes[i]}")
    return "Program Executed"

def squa_sum(*args):
    return sum(x**2 for x in args)
    return "Program Executed"

def table():
    n = int(input("Kahan tak table print karni hai? "))
    for i in range(1, n + 1):
        print(f"\n\nTable of {i}:")
        for j in range(1, 11):
            print(f"{i*j}", end=",")
    print()
    return "Program Executed"

def count_odd_even():
    n = int(input("Enter a no for range:- "))
    ec = 0
    oc = 0
    for num in range(1, n + 1):
        if num % 2 == 0: 
            ec += 1
        else:
            oc += 1
    print("Total Even-Numbers in given range:", ec)
    print("Total Odd-Numbers in given range:", oc)
    return "Program Executed"

def check_leap_year(year):
    # Ye sirf logic check karega
    if (year % 4 == 0 and year % 100 != 0) or (year % 400 == 0):
        return True
    else:
        return False

def leap_year():
    saal = int(input("Enter a year to check: "))
    
    if check_leap_year(saal):
        print(f"{saal} is a Leap Year!")
    else:
        print(f"{saal} is not a Leap Year.")
    return "Program Executed"

def analyze_string(text):
    vowels = "aeiouAEIOU"
    v = 0 # Vowels count
    c = 0 # Consonants count
    u = 0 # Uppercase count
    l = 0 # Lowercase count
    d = 0 # Digits count
    for char in text:
        if char.isupper():
            u += 1
        elif char.islower():
            l += 1
        if char.isdigit():
            d += 1
        if char.isalpha():
            if char in vowels:
                v += 1
            else:
                c += 1
    print(f"Results for: '{text}'")
    print(f"Vowels: {v}")
    print(f"Consonants: {c}")
    print(f"Uppercase: {u}")
    print(f"Lowercase: {l}")
    print(f"Digits: {d}")
def alphabet():
    user_input = input("Enter your string: ")
    analyze_string(user_input)
    return "Program Executed"


