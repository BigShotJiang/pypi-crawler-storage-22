from setuptools import setup, find_packages
import os

# README file ko UTF-8 encoding ke sath read karna zaroori hai
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="GodKit",  # 'boon' pehle se exist karta hai, isliye ye unique name rakha hai
    version="1.0.0",            # Version badal diya hai upload error se bachne ke liye
    author="PHarsh",
    description='''This library has been created for school CS students so that they can do their assignments easily. This library is currently under development more functions will be added in the next version.''',
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)
