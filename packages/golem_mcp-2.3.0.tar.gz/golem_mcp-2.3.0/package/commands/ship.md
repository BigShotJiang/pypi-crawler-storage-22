---
description: Version sync, clean dist, build for PyPI deployment
---
# /ship — Prepare and ship a release

> **Synonymes** : ship, release, publish, deploy, version bump

Pre-flight checks + version sync + clean build for PyPI deployment.

## Input

The user provides the new version string (e.g. `2.4.0`). If not provided, ask for it.

## Steps

### 1. Version audit

Read ALL version sources and display a comparison table:

| File | Current | Target |
|------|---------|--------|
| `pyproject.toml` → `version` | ? | $NEW_VERSION |
| `package/godot-plugin/plugin.cfg` → `version` | ? | $NEW_VERSION |

Flag any file that is **already different from the others** (desync warning).

### 2. Version bump

For each file where the version differs from the target:

- **`pyproject.toml`** line `version = "X.Y.Z"` → replace with `version = "$NEW_VERSION"`
- **`package/godot-plugin/plugin.cfg`** line `version="X.Y.Z"` → replace with `version="$NEW_VERSION"`

After editing, re-read both files to **confirm** the version is correct. Display the confirmation table.

### 3. Clean dist/

```bash
rm -rf dist/*
```

Confirm the `dist/` directory is empty (but keep the directory and its `.gitignore`).

### 4. Build

```bash
uv build
```

Verify the output filenames contain the correct version:
- `dist/golem_mcp-$NEW_VERSION.tar.gz`
- `dist/golem_mcp-$NEW_VERSION-py3-none-any.whl`

If the filenames don't match the target version, STOP and flag the issue.

### 5. Wheel content verification

Inspect the wheel to confirm `package/` content was correctly bundled:

```bash
python3 -m zipfile -l dist/golem_mcp-$NEW_VERSION-py3-none-any.whl | grep golem_mcp_data
```

For each subdirectory of `package/`, count the source files and verify the wheel contains exactly the same number:

```bash
for d in commands skills rules hooks tools recipes references godot-plugin; do
  src=$(find package/$d -type f | wc -l)
  whl=$(python3 -m zipfile -l dist/golem_mcp-*.whl | grep "golem_mcp_data/$d/" | wc -l)
  echo "$d: source=$src wheel=$whl $([ "$src" = "$whl" ] && echo OK || echo MISMATCH)"
done
```

If any count mismatches → STOP. Likely cause: `pyproject.toml` `[tool.hatch.build.targets.wheel.force-include]` paths are stale.

Also verify no symlinks leaked into the wheel (`.claude/rules/` symlinks should NOT be included — only `package/rules/` real files).

### 6. README version check

Verify that `README.md` header version matches `$NEW_VERSION`:
- Line matching `**vX.Y.Z**` should show the target version
- If mismatched → update it

### 7. Summary

Display:

```
## Ship $NEW_VERSION — Ready

Version synced:
  ✓ pyproject.toml
  ✓ package/godot-plugin/plugin.cfg

Build artifacts:
  ✓ dist/golem_mcp-$NEW_VERSION.tar.gz
  ✓ dist/golem_mcp-$NEW_VERSION-py3-none-any.whl

Next steps:
  1. git add -A && git commit -m "Bump version to $NEW_VERSION"
  2. uv publish (or twine upload dist/*)
  3. git tag v$NEW_VERSION && git push --tags
```

Do NOT auto-commit or auto-publish. Just present the next steps.

## Rules

- **Never skip the audit** — always show the comparison table first, even if all versions already match
- **Never leave dist/ dirty** — old artifacts cause PyPI upload conflicts
- **Never auto-publish** — the user decides when to push
- If version argument looks wrong (not semver-like), ask for confirmation
