#!/usr/bin/env python3
"""Golem MCP — Bridge between AI coding agents and Godot 4.x via FastMCP."""

import asyncio
import base64
import logging
import os
import sys
import io
from mcp.server.fastmcp import FastMCP, Image
from golem_client import GolemClient

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("golem_mcp")

mcp = FastMCP(
    "golem-mcp",
    instructions=(
        "Golem MCP — live bridge to a running Godot 4.x editor via persistent TCP connection. "
        "Tools manipulate the EDITOR state (scene tree, properties, scripts), not the running game. "
        "Key workflow: open_scene → add_nodes/update_property → save_scene → play_scene → get_logs/game_screenshot → stop_scene. "
        "IMPORTANT: always call godot_save_scene after scene modifications (add/delete/update nodes). "
        "Never edit .tscn files on disk — use the scene manipulation tools instead. "
        "For game runtime data, use get_logs (requires GolemCapture.log() in scripts) and get_game_screenshot. "
        "For script edits, prefer godot_edit_script (find-and-replace) over godot_write_script (full rewrite) when changing small parts."
    ),
)
client = GolemClient()


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------

async def _ensure_connected():
    await client.ensure_connected()


async def _call(tool: str, args: dict | None = None, timeout: float | None = None) -> str | Image:
    """Call Godot and return the appropriate MCP content."""
    await _ensure_connected()
    result = await client.call(tool, args or {}, timeout=timeout)

    if result.get("type") == "image":
        image_data = base64.b64decode(result["result"])
        return Image(data=image_data, format=result.get("mime", "image/png"))

    return result.get("result", "")


async def _call_with_retry(
    tool: str,
    args: dict | None = None,
    timeout: float | None = None,
    retries: int = 2,
    delay: float = 1.0,
) -> str | Image:
    """Call Godot with automatic retry on transient failures (ConnectionError, TimeoutError)."""
    last_error = None
    for attempt in range(retries + 1):
        try:
            return await _call(tool, args, timeout)
        except (ConnectionError, TimeoutError) as exc:
            last_error = exc
            if attempt < retries:
                logger.info("Retry %d/%d for '%s' after %s", attempt + 1, retries, tool, type(exc).__name__)
                await asyncio.sleep(delay)
    raise last_error


# ==================================================================
# Core tools
# ==================================================================

@mcp.tool(annotations={"readOnlyHint": True})
async def godot_get_scene_tree(detail_level: str = "full") -> str:
    """Get the full node hierarchy of the currently edited scene.

    Use this to understand scene structure, verify nodes after add/delete operations, or plan modifications.
    For detailed properties of a single node, use godot_inspect_node instead.
    For a broad project overview (settings, autoloads, file lists), use godot_project_context instead.

    Returns the tree with indentation showing parent-child relationships.
    Safe to call while a game is running (reads the editor scene, not the running game).

    Args:
        detail_level: "full" (default) includes script paths on each node. "summary" shows only names and types (faster for large scenes).
    """
    return await _call_with_retry("get_scene_tree", {"detail_level": detail_level})


@mcp.tool(annotations={"readOnlyHint": True})
async def godot_inspect_node(path: str, detail_level: str = "full") -> str:
    """Get all properties, signals, and groups of a specific node in the edited scene.

    Use this when you need to read or verify property values on a known node.
    Use godot_get_scene_tree first if you don't know the node path.

    Args:
        path: Node path relative to scene root. Use "." for the root node, "Player" for a direct child, "Player/Sprite" for nested nodes.
        detail_level: "full" (default) shows all editor-visible properties, signals with connections, and groups. "summary" shows only type, path, script, and transform properties (position, rotation, scale, size, visible).
    """
    return await _call("inspect_node", {"path": path, "detail_level": detail_level})


@mcp.tool(annotations={"readOnlyHint": True})
async def godot_get_editor_screenshot() -> Image:
    """Capture a screenshot of the Godot editor's 2D/3D viewport (not the running game).

    Use this to see the current scene layout, verify visual changes after node operations, or audit the design.
    For screenshots of the running game, use godot_get_game_screenshot instead (requires the game to be playing).
    """
    return await _call("get_editor_screenshot")


@mcp.tool(annotations={"readOnlyHint": True})
async def godot_get_game_screenshot() -> Image:
    """Capture a screenshot of the currently running game window.

    REQUIREMENTS: The game must be playing (call godot_play_scene first) and the GolemCapture autoload
    must be active in the project (added automatically by the Golem installer).
    Uses a file-based protocol — GolemCapture in the game process captures and writes the screenshot,
    then the editor plugin reads it. This may take 1-2 seconds.

    WARNING: May fail right after play_scene due to TCP reconnect timing. Built-in retry handles this.
    For editor viewport screenshots (no game running), use godot_get_editor_screenshot instead.
    """
    return await _call_with_retry("get_game_screenshot", timeout=10.0)


@mcp.tool()
async def godot_play_scene(path: str = "") -> str:
    """Start playing a scene in the Godot editor (equivalent to pressing F5/F6).

    Only one scene can run at a time. Call godot_stop_scene first if a scene is already running.
    After starting, use godot_get_logs and godot_get_game_screenshot to observe the game.
    Save your scene (godot_save_scene) before playing to ensure changes are included.

    Args:
        path: Scene file path (e.g. "res://scenes/main.tscn"). Empty string plays the current scene. If no main scene is set and path is empty, plays the currently edited scene.
    """
    return await _call("play_scene", {"path": path})


@mcp.tool()
async def godot_stop_scene() -> str:
    """Stop the currently running game scene.

    Waits until Godot has fully torn down the game process before returning (deferred).
    This means you can safely call godot_play_scene immediately after without getting
    "A scene is already running" errors.

    Typical workflow: stop_scene → modify scene/scripts → save_scene → play_scene.
    """
    return await _call("stop_scene")


@mcp.tool(annotations={"readOnlyHint": True})
async def godot_get_errors() -> str:
    """Get GDScript compilation errors and runtime errors captured by the editor.

    Returns errors accumulated since the last clear_logs call. Includes both parse/compile
    errors (from script saves) and runtime errors (from the running game).
    Reliable even right after play_scene (unlike screenshots, this rarely fails).
    """
    return await _call("get_errors")


@mcp.tool()
async def godot_clear_logs() -> str:
    """Clear all error records, game log files, and engine log cursors.

    Resets: the error buffer (get_errors), the game log file (GolemCapture logs),
    the engine log read position, and input simulation files.
    Call this before a test run to get a clean slate.
    Note: play_scene also resets game logs automatically.
    """
    return await _call("clear_logs")


@mcp.tool()
async def godot_execute_script(code: str) -> str:
    """Execute GDScript code in the EDITOR context (not the running game) and return the result.

    The code is wrapped in a function body and compiled at runtime. Use 'return <value>' to get a result back.
    Best for: assigning Resources (load()), setting SpriteFrames, enabling unique_name_in_owner, reading data.

    CRITICAL LIMITATIONS:
    - NO await allowed (editor @tool context). Use godot_write_script for async code.
    - Runs in EDITOR, not the game. Cannot access game autoloads (GameState, etc.).
    - Keep scripts simple — complex arrays + loops + string concat may fail (error code 36).
      For complex logic, write a .gd file with godot_write_script instead.
    - Results must be JSON-serializable. Return strings, numbers, arrays, dicts.

    Args:
        code: GDScript code body. Example: 'var node = get_node("/root/Main/Sprite")\\nnode.texture = load("res://icon.png")\\nreturn "done"'
    """
    return await _call("execute_script", {"code": code})


@mcp.tool(annotations={"readOnlyHint": True})
async def godot_view_script(path: str) -> str:
    """Read the content of a GDScript (.gd) or shader (.gdshader) file from the Godot project.

    Resolves res:// paths through Godot, so it works even if the project is in a non-standard location.
    For writing scripts, use godot_write_script instead.

    Args:
        path: Script file path (e.g. "res://scripts/player.gd", "res://shaders/outline.gdshader").
    """
    return await _call("view_script", {"path": path})


@mcp.tool()
async def godot_write_script(path: str, content: str) -> str:
    """Write or overwrite a GDScript file in the project. Creates directories if needed.

    Godot auto-reloads scripts on save, so changes take effect immediately in the editor.
    After writing, attach the script to a node with godot_attach_script if it's a new file.

    Args:
        path: File path (e.g. "res://scripts/player.gd"). Auto-prefixed with res:// if missing.
        content: Full GDScript source code to write. Must include the complete file content (not a diff).
    """
    return await _call("write_script", {"path": path, "content": content})


@mcp.tool()
async def godot_attach_script(node: str, script: str) -> str:
    """Attach an existing GDScript file to a node in the currently edited scene.

    The script must already exist on disk (use godot_write_script first).
    Call godot_save_scene after to persist the attachment.

    Args:
        node: Node path relative to scene root (e.g. "Player", "UI/HUD"). Use "." for the root node.
        script: Script file path (e.g. "res://scripts/player.gd"). Must be a valid res:// path.
    """
    return await _call("attach_script", {"node": node, "script": script})


@mcp.tool(annotations={"readOnlyHint": True})
async def godot_get_logs(max_lines: int = 100, source: str = "game") -> str:
    """Get logs from the running game or the Godot engine. INCREMENTAL: each call returns only NEW lines since the last call.

    Game logs require GolemCapture.log("msg") in your scripts — standard print() goes to stdout and is NOT captured.
    Engine logs come from Godot's godot.log file.
    Use godot_clear_logs to reset read positions. godot_play_scene also resets game logs.

    Args:
        max_lines: Maximum number of log lines to return. Default 100.
        source: "game" for GolemCapture output, "engine" for Godot engine logs, "all" for both. Default "game".
    """
    return await _call("get_logs", {"max_lines": max_lines, "source": source})


@mcp.tool()
async def godot_simulate_input(sequence: list, loop: int = 1, timeout: float = 30.0) -> str:
    """Simulate input actions in the running game via GolemCapture (file-based protocol).

    The game must be playing (call godot_play_scene first). Sends a sequence of input steps
    that GolemCapture executes in order. Only works with named Input Map actions — does NOT
    simulate raw mouse/keyboard events.

    Step types:
      - {"action": "move_right", "duration": 2.0} — press, hold N sec, release
      - {"wait": 0.5} — pause N seconds between steps
      - {"action": "jump", "pressed": true} — toggle on (no auto-release)
      - {"action": "jump", "pressed": false} — toggle off

    Workflow: play_scene → simulate_input → get_logs / get_game_screenshot → stop_scene.

    Args:
        sequence: Array of step dicts. Each must have "action" (with optional "duration" or "pressed") or "wait".
        loop: Number of times to repeat the full sequence. Default 1.
        timeout: Max wait time in seconds for the full sequence to complete. Default 30.
    """
    return await _call("simulate_input", {"sequence": sequence, "loop": loop}, timeout=timeout)


# ==================================================================
# Scene manipulation
# ==================================================================

@mcp.tool()
async def godot_add_node(
    type: str = "Node",
    name: str = "",
    parent: str = "",
    unique_name: bool = False,
) -> str:
    """Add a single new node to the currently edited scene.

    For creating multiple nodes at once (with hierarchy and properties), use godot_add_nodes instead.
    This tool creates a bare node with no properties set — use godot_update_property after.
    IMPORTANT: call godot_save_scene after adding nodes to persist changes to disk.

    Args:
        type: Godot node class name (e.g. "Sprite2D", "CharacterBody2D", "Label", "Area2D").
        name: Name for the new node. Auto-generated from type if empty.
        parent: Path to parent node relative to scene root (e.g. "Player", "UI/HUD"). Empty = scene root.
        unique_name: If true, sets unique_name_in_owner so the node can be accessed with %Name syntax in GDScript.
    """
    args = {"type": type, "name": name, "parent": parent}
    if unique_name:
        args["unique_name"] = True
    return await _call("add_node", args)


@mcp.tool()
async def godot_delete_node(path: str) -> str:
    """Delete a node and all its children from the currently edited scene.

    Cannot delete the scene root node. Call godot_save_scene after to persist the change.

    Args:
        path: Node path relative to scene root (e.g. "Player", "UI/OldButton"). Cannot be ".".
    """
    return await _call("delete_node", {"path": path})


@mcp.tool()
async def godot_update_property(path: str, property: str, value) -> str:
    """Set a property value on a node in the currently edited scene.

    Supports automatic type conversion: arrays → Vector2/Vector3/Rect2/Color, strings → Color ("#ff0000"),
    res:// strings → loaded Resources, dicts with "type" → new Resource instances.
    If type conversion fails (e.g. complex Resources like SpriteFrames), use godot_execute_script with load() instead.
    IMPORTANT: call godot_save_scene after to persist changes.

    Args:
        path: Node path relative to scene root. Use "." for the root node.
        property: Property name (e.g. "position", "modulate", "text", "texture", "visible").
        value: New value. Type conversion examples:
            - Vector2: [100, 200]
            - Vector3: [1, 2, 3]
            - Color: "#ff0000" or [1.0, 0.0, 0.0, 1.0]
            - Resource: "res://icon.png" (loaded automatically)
            - Resource from spec: {"type": "RectangleShape2D", "properties": {"size": [32, 32]}}
    """
    return await _call("update_property", {"path": path, "property": property, "value": value})


@mcp.tool()
async def godot_move_node(path: str, new_parent: str) -> str:
    """Reparent a node (and its children) to a different parent in the scene tree.

    Call godot_save_scene after to persist.

    Args:
        path: Current node path relative to scene root.
        new_parent: Path to the new parent node relative to scene root.
    """
    return await _call("move_node", {"path": path, "new_parent": new_parent})


@mcp.tool()
async def godot_duplicate_node(path: str) -> str:
    """Duplicate a node and all its children as a sibling in the scene tree.

    The duplicate gets an auto-incremented name (e.g. "Sprite2" if "Sprite" is duplicated).
    Call godot_save_scene after to persist.

    Args:
        path: Node path to duplicate relative to scene root.
    """
    return await _call("duplicate_node", {"path": path})


@mcp.tool()
async def godot_add_nodes(nodes: list) -> str:
    """Create an entire node hierarchy in one call (batch). Preferred over multiple add_node calls.

    Supports nested children and property assignment with automatic type conversion (Vector2, Color, etc.).
    IMPORTANT: Resource properties (Texture, SpriteFrames, Material, Theme) passed as res:// strings will
    return an error if the resource file doesn't exist. For complex Resources, use godot_execute_script
    with load() after creating nodes.
    IMPORTANT: call godot_save_scene after to persist the new nodes.

    Args:
        nodes: Array of node specs. Each spec is a dict with:
            - name: Node name (required)
            - type: Godot class (e.g. "Sprite2D", "CharacterBody2D"). Default "Node"
            - parent: Parent path relative to scene root (optional, default = scene root)
            - properties: Dict of property values to set (optional). Same conversion rules as update_property.
            - children: Array of child node specs (optional, recursive)
            - unique_name: If true, enables unique_name_in_owner (%Name access in GDScript). Default false.

    Example:
        [{"name": "Player", "type": "CharacterBody2D", "properties": {"position": [100, 200]}, "children": [
            {"name": "Sprite", "type": "Sprite2D"},
            {"name": "Collision", "type": "CollisionShape2D", "properties": {"shape": {"type": "RectangleShape2D", "properties": {"size": [32, 64]}}}}
        ]}]
    """
    return await _call("add_nodes", {"nodes": nodes})


@mcp.tool()
async def godot_create_scene(
    path: str,
    root_type: str = "Node2D",
    root_name: str = "",
) -> str:
    """Create a new .tscn scene file, save it to disk, and open it in the editor.

    Creates parent directories if they don't exist. After creation, the scene is the active edited scene
    and you can immediately add nodes to it.

    Args:
        path: Scene file path (e.g. "res://scenes/main.tscn"). Auto-adds res:// prefix and .tscn extension if missing.
        root_type: Root node class (e.g. "Node2D", "Node3D", "Control", "CharacterBody2D"). Default "Node2D".
        root_name: Name for root node. Default = derived from filename.
    """
    return await _call("create_scene", {"path": path, "root_type": root_type, "root_name": root_name})


@mcp.tool()
async def godot_open_scene(path: str) -> str:
    """Open an existing .tscn scene file in the editor, making it the active edited scene.

    If a game is currently running, it will NOT be stopped — but the edited scene context changes.
    Call godot_stop_scene first if you need to stop the game before switching scenes.
    After opening, use godot_get_scene_tree to see the scene's node hierarchy.

    Args:
        path: Scene file path (e.g. "res://scenes/main.tscn"). Auto-prefixed with res:// if missing.
    """
    return await _call("open_scene", {"path": path})


@mcp.tool(annotations={"readOnlyHint": True})
async def godot_find_nodes(
    type: str = "",
    group: str = "",
    name: str = "",
    script: str = "",
    max_results: int = 50,
) -> str:
    """Search the edited scene tree for nodes matching one or more filters. At least one filter required.

    Useful to find nodes by type ("all Area2D nodes"), by group, by name pattern, or by attached script.
    Returns node paths, types, script paths, and groups for each match.

    Args:
        type: Godot class name (e.g. "Label", "Area2D"). Matches subclasses too (e.g. "Control" matches Button, Label, etc.).
        group: Group name (e.g. "enemies", "saveable").
        name: Name pattern with optional * wildcards (e.g. "Score*", "*Button", "*Health*"). Case-insensitive.
        script: Script filename suffix (e.g. "player.gd", "ui/hud.gd"). Matches end of script path.
        max_results: Maximum nodes to return. Default 50.
    """
    args = {"max_results": max_results}
    if type:
        args["type"] = type
    if group:
        args["group"] = group
    if name:
        args["name"] = name
    if script:
        args["script"] = script
    return await _call("find_nodes", args)


# ==================================================================
# Advanced tools
# ==================================================================

@mcp.tool()
async def godot_create_sprite_frames(
    animations: list,
    node_path: str = "",
) -> str:
    """Create a SpriteFrames resource with animations and optionally assign it to an AnimatedSprite2D node.

    Replaces the common 10+ line execute_script pattern for setting up SpriteFrames.
    If node_path is provided, the resource is assigned to that node's sprite_frames property.
    IMPORTANT: call godot_save_scene after to persist changes.

    Args:
        animations: Array of animation specs. Each spec is a dict with:
            - name: Animation name (e.g. "idle", "run", "attack"). Required.
            - fps: Playback speed in frames per second. Default 5.
            - loop: Whether the animation loops. Default true.
            - frames: Array of texture paths (e.g. ["res://sprites/idle_0.png", "res://sprites/idle_1.png"]). Required.
        node_path: Path to an AnimatedSprite2D node to assign the SpriteFrames to (e.g. "Player/Sprite"). Optional — if empty, creates the resource without assigning it.

    Example:
        godot_create_sprite_frames(
            animations=[
                {"name": "idle", "fps": 8, "loop": true, "frames": ["res://sprites/idle_0.png", "res://sprites/idle_1.png"]},
                {"name": "run", "fps": 12, "loop": true, "frames": ["res://sprites/run_0.png", "res://sprites/run_1.png", "res://sprites/run_2.png"]}
            ],
            node_path="Player/Sprite"
        )
    """
    args = {"animations": animations}
    if node_path:
        args["node_path"] = node_path
    return await _call("create_sprite_frames", args)


@mcp.tool(annotations={"readOnlyHint": True})
async def godot_get_input_map() -> str:
    """Get all custom input actions defined in the project and their key/button bindings.

    Returns only actions defined in Project Settings > Input Map (not built-in Godot actions).
    NOTE: this reads from the editor's Input Map, which may not include actions added at runtime.
    For the raw [input] section, read project.godot directly.
    """
    return await _call("get_input_map")


@mcp.tool()
async def godot_project_settings(
    action: str = "list",
    key: str = "",
    value=None,
) -> str:
    """Read or modify Godot project settings (project.godot). Changes are persisted by Godot automatically.

    IMPORTANT: always use the full path format for keys: "display/window/size/viewport_width"
    (not the .ini section format "window/size/viewport_width" under [display]).
    Verify changes with action="get" after setting.

    Args:
        action: "list" to show common settings, "get" to read a specific setting, "set" to modify one.
        key: Full setting key path (e.g. "application/config/name", "display/window/size/viewport_width"). Required for get/set.
        value: New value (only for action="set"). Type must match the setting's expected type.
    """
    args = {"action": action, "key": key}
    if value is not None:
        args["value"] = value
    return await _call("project_settings", args)


@mcp.tool()
async def godot_save_scene() -> str:
    """Save the currently edited scene to its .tscn file on disk.

    REQUIRED after any scene modification: add_node(s), delete_node, update_property, move_node,
    duplicate_node, attach_script, or execute_script that modifies the scene tree.
    Without saving, changes exist only in editor memory and will be lost.
    """
    return await _call("save_scene")


@mcp.tool(annotations={"readOnlyHint": True})
async def godot_project_context() -> str:
    """Get a comprehensive project overview in one call — ideal as a first tool call to understand the project.

    Returns: project name, viewport size, renderer, autoloads, custom input actions,
    and lists of all .gd/.tscn/.tres files (excluding addons/).
    Use this instead of multiple project_settings + get_input_map calls.
    For the scene tree of the currently open scene, use godot_get_scene_tree instead.
    """
    return await _call("project_context")


@mcp.tool(annotations={"readOnlyHint": True})
async def godot_list_resources(
    type: str = "",
    path: str = "res://",
    max_results: int = 200,
) -> str:
    """List project files filtered by type/extension and directory.

    Scans the project (excluding addons/ and hidden directories) and returns file paths sorted by directory.
    Use this to discover assets, scripts, scenes, or resources in the project.
    For a full project overview (settings + autoloads + files), use godot_project_context instead.

    Args:
        type: File extension filter (e.g. "gd", "tscn", "tres", "png", "wav", "gdshader"). Empty = all common types.
        path: Directory to scan (e.g. "res://scenes/", "res://assets/"). Default "res://" (whole project).
        max_results: Maximum files to return. Default 200.
    """
    return await _call("list_resources", {"type": type, "path": path, "max_results": max_results})


@mcp.tool(annotations={"readOnlyHint": True})
async def godot_get_signals(path: str) -> str:
    """List all signals of a node and their current connections in the edited scene.

    Shows signal signatures (name + argument types) and connected targets (node path, method, flags).
    Use this to understand signal wiring before connecting or debugging signal flow.
    For general node inspection (properties, groups), use godot_inspect_node instead.

    Args:
        path: Node path relative to scene root. Use "." for root, "Player" for direct child, "Player/Sprite" for nested.
    """
    return await _call("get_signals", {"path": path})


@mcp.tool()
async def godot_connect_signal(
    source: str,
    signal_name: str,
    target: str,
    method: str,
) -> str:
    """Connect a signal between two nodes in the edited scene.

    The connection is persisted when you call godot_save_scene (serialized in the .tscn file).
    Validates that the signal exists and isn't already connected.
    Use godot_get_signals first to see available signals and existing connections.

    Args:
        source: Path to the node emitting the signal (e.g. "Player", "UI/Button").
        signal_name: Signal name (e.g. "pressed", "body_entered", "health_changed").
        target: Path to the node receiving the signal (e.g. ".", "Player/HealthBar").
        method: Method name on the target node (e.g. "_on_button_pressed", "update_health").
    """
    return await _call("connect_signal", {
        "source": source,
        "signal_name": signal_name,
        "target": target,
        "method": method,
    })


@mcp.tool()
async def godot_set_anchor(
    path: str,
    preset: str = "full_rect",
    keep_offsets: bool = False,
) -> str:
    """Set anchor preset on a Control node, properly resetting offsets (fixes the common anchors_preset pitfall).

    By default uses set_anchors_and_offsets_preset() which resets both anchors AND offsets — the correct way
    to apply layout presets. Set keep_offsets=True to only change anchors (preserving current offsets).
    IMPORTANT: call godot_save_scene after to persist changes.

    Args:
        path: Node path relative to scene root (e.g. "UI/Panel", "HUD/HealthBar").
        preset: Layout preset name. Options: "full_rect", "center", "center_top", "center_bottom",
            "center_left", "center_right", "top_left", "top_right", "bottom_left", "bottom_right",
            "top_wide", "bottom_wide", "left_wide", "right_wide", "hcenter_wide", "vcenter_wide".
            Default "full_rect".
        keep_offsets: If True, only sets anchors without resetting offsets. Default False.
    """
    return await _call("set_anchor", {
        "path": path,
        "preset": preset,
        "keep_offsets": keep_offsets,
    })


@mcp.tool()
async def godot_add_resource(
    type: str,
    path: str,
    properties: dict | None = None,
) -> str:
    """Create a standalone .tres resource file and save it to disk.

    Creates any Resource subclass (StyleBoxFlat, GradientTexture2D, Theme, AudioBusLayout, etc.),
    sets properties using the same conversion rules as godot_update_property, and saves to a .tres file.
    After creation, the resource can be loaded with load("res://path.tres") or assigned via godot_update_property.

    Args:
        type: Godot Resource class name (e.g. "StyleBoxFlat", "GradientTexture2D", "Theme", "RectangleShape2D").
        path: Save path (e.g. "res://resources/my_style.tres"). Auto-prefixed with res:// and .tres if missing.
        properties: Dict of property values to set on the resource. Same conversion rules as godot_update_property
            (arrays → Vector2/Color, res:// strings → loaded Resources, dicts with "type" → nested Resources).
    """
    args = {"type": type, "path": path}
    if properties:
        args["properties"] = properties
    return await _call("add_resource", args)


@mcp.tool()
async def godot_create_theme(
    path: str = "res://theme.tres",
    colors: dict | None = None,
    fonts: dict | None = None,
    font_sizes: dict | None = None,
    styleboxes: list | None = None,
    constants: dict | None = None,
    apply_global: bool = False,
) -> str:
    """Create a complete Godot Theme resource in one call. Replaces the verbose 100+ line execute_script pattern.

    Generates a .tres file with colors, fonts, font sizes, styleboxes, and constants, all properly typed.
    Much more reliable than execute_script for theme creation — no string escaping issues, no code 36 errors.

    Args:
        path: Save path for the theme file (e.g. "res://theme.tres"). Default "res://theme.tres".
        colors: Color overrides. Format: {"color_name": {"Component": "#hex_or_rgba"}}. Example:
            {"font_color": {"Label": "#e8e8e8", "Button": "#ffffff"}, "font_disabled_color": {"Button": "#555566"}}
            Supports: hex strings ("#ff0000", "#ff000088"), "transparent", rgba arrays ([1.0, 0.0, 0.0, 1.0]).
        fonts: Font assignments. Format: {"font_name": {"Component": "res://fonts/file.ttf"}}. Example:
            {"font": {"Label": "res://fonts/Inter.ttf", "Button": "res://fonts/Inter.ttf"}}
            For FontVariation (bold/italic): {"font": {"Label": {"base": "res://fonts/Inter.ttf", "weight": 700}}}
        font_sizes: Font size overrides. Format: {"size_name": {"Component": int}}. Example:
            {"font_size": {"Label": 16, "Button": 16, "LineEdit": 16}}
        styleboxes: Array of StyleBoxFlat specs. Each spec is a dict with:
            - component: Godot Control class name (e.g. "Button", "PanelContainer", "LineEdit")
            - variant: Style variant (e.g. "normal", "hover", "pressed", "disabled", "focus", "panel")
            - bg_color: Background color (hex string, rgba array, or "transparent")
            - corner_radius: Uniform int or [top_left, top_right, bottom_left, bottom_right]
            - border_color: Border color
            - border_width: Uniform int or [left, top, right, bottom]
            - content_margin: Uniform int, [horizontal, vertical], or [left, top, right, bottom]
            - shadow_color, shadow_size, shadow_offset: Shadow properties
        constants: Theme constants. Format: {"constant_name": {"Component": int}}. Example:
            {"separation": {"VBoxContainer": 16, "HBoxContainer": 8},
             "margin_left": {"MarginContainer": 24}, "margin_right": {"MarginContainer": 24}}
        apply_global: If True, sets this theme as the project's global theme in Project Settings. Default False.
    """
    args = {"path": path, "apply_global": apply_global}
    if colors:
        args["colors"] = colors
    if fonts:
        args["fonts"] = fonts
    if font_sizes:
        args["font_sizes"] = font_sizes
    if styleboxes:
        args["styleboxes"] = styleboxes
    if constants:
        args["constants"] = constants
    return await _call("create_theme", args)


@mcp.tool()
async def godot_edit_script(
    path: str,
    old_text: str,
    new_text: str,
    replace_all: bool = False,
) -> str:
    """Find-and-replace text in a GDScript file without rewriting the entire file.

    Preferred over godot_write_script when making small, targeted changes (renaming a variable,
    changing a value, modifying a function signature). Godot auto-reloads the script after the edit.
    If old_text appears multiple times and replace_all is False, the tool returns an error asking
    you to either provide more context or set replace_all=True.

    Args:
        path: Script file path (e.g. "res://scripts/player.gd"). Auto-prefixed with res:// if missing.
        old_text: Exact text to find in the file. Must match exactly (including whitespace/indentation).
        new_text: Replacement text. Can be empty to delete old_text.
        replace_all: If True, replaces ALL occurrences. If False (default), requires exactly one match.
    """
    return await _call("edit_script", {
        "path": path,
        "old_text": old_text,
        "new_text": new_text,
        "replace_all": replace_all,
    })


# ------------------------------------------------------------------
# Entry point
# ------------------------------------------------------------------

GOLEM_BANNER = """\
   █████████     ███████    █████       ██████████ ██████   ██████
  ███░░░░░███  ███░░░░░███ ░░███       ░░███░░░░░█░░██████ ██████
 ███     ░░░  ███     ░░███ ░███        ░███  █ ░  ░███░█████░███
░███         ░███      ░███ ░███        ░██████    ░███░░███ ░███
░███    █████░███      ░███ ░███        ░███░░█    ░███ ░░░  ░███
░░███  ░░███ ░░███     ███  ░███      █ ░███ ░   █ ░███      ░███
 ░░█████████  ░░░███████░   ███████████ ██████████ █████     █████
  ░░░░░░░░░     ░░░░░░░    ░░░░░░░░░░░ ░░░░░░░░░░ ░░░░░     ░░░░░\
"""


def _print_banner():
    """Print the Golem ASCII banner."""
    use_color = sys.stdout.isatty() and not os.environ.get("NO_COLOR")
    c = "\033[38;5;80m" if use_color else ""
    r = "\033[0m" if use_color else ""
    d = "\033[2m" if use_color else ""
    print(f"{c}{GOLEM_BANNER}{r}")
    print(f"{d}{'Godot 4.x <-> AI Agents':^67}{r}")
    print()


def main():
    # Fix Windows encoding
    if sys.platform == "win32" and hasattr(sys.stdout, "buffer"):
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

    if len(sys.argv) > 1:
        cmd = sys.argv[1]

        if cmd == "install":
            from golem_installer import run_install
            run_install(sys.argv[2:])
            return

        if cmd == "uninstall":
            from golem_installer import run_uninstall
            run_uninstall(sys.argv[2:])
            return

        if cmd in ("--help", "-h", "help"):
            _print_banner()
            print("  Bridge between AI coding agents and Godot 4.x")
            print()
            print("  Usage:")
            print("    golem-mcp                     Run the MCP server")
            print("    golem-mcp install <project>   Install in a Godot project")
            print("    golem-mcp uninstall <project> Remove from a project")
            print()
            print("  Install options:")
            print("    --agent <name>   claude, cursor, windsurf, continue, cline")
            print("    --force          Overwrite existing installation")
            print("    --local <path>   Use local dev server instead of uvx")
            print()
            return

        if cmd == "--version":
            from golem_installer import _get_version
            print(f"Golem MCP v{_get_version()}")
            return

    # Run the MCP server (no lock file — multiple instances allowed for Agent Teams)
    mcp.run()


if __name__ == "__main__":
    main()
