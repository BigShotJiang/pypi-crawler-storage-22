# Golem MCP — Package Manifest

> Source of truth for distributed content. Verified by `/audit`.

## Commands (9) — user-invocable

| File | Description |
|------|-------------|
| build.md | Build a deliverable — pre-flight, manifest, code, validation |
| checkpoint.md | Snapshot the current project state into CHECKPOINT.md |
| deliverable.md | Focus work on completing a specific project deliverable |
| fix.md | Debug, diagnose, and repair issues in a Godot project |
| init.md | Bootstrap a new Godot project from vision to deliverables and structure |
| learn.md | Synthesize errors and solutions from the current session into structured feedback |
| references.md | Extract and document reusable patterns from the current project |
| ship.md | Prepare and ship a release — version sync, clean build, PyPI deployment |
| think.md | Brainstorm, plan, and explore ideas — read-only, no code |

## Skills (18 + router + index) — internal, Claude routing

| File | Description |
|------|-------------|
| godot.md | Router — dispatch user intent to the correct skill |
| INDEX.md | Skill discovery and dependency graph |
| godot-architecture.md | Design modular pseudo-ECS architecture — EventBus, components, script organization |
| godot-audio.md | Set up audio — bus layout, music manager, SFX pool, spatial audio, volume UI |
| godot-behavior.md | Add UI states, transitions, tweens, and feedback loops to existing components |
| godot-camera.md | Configure 2D camera — smooth follow, zoom, area limits, cinematic mode |
| godot-composition.md | Structure UI — design tokens, container roles, responsive layout, torture tests |
| godot-debug.md | Diagnose and fix issues in a Godot project step by step |
| godot-design-audit.md | Audit UX via screenshots and produce an improvement report |
| godot-gate.md | Validate readiness before construction — auto-checks and qualitative questions |
| godot-juice.md | Add game feel — screenshake, freeze frames, squash and stretch, hit effects |
| godot-plan.md | Plan a Godot feature — interrogate, structure, produce a mini-PRD before building |
| godot-save.md | Implement save and load — settings, game state, slots, migration |
| godot-scene.md | Build a Godot scene from a description using MCP tools |
| godot-sequence.md | Define game flow as structured YAML — loops, states, emotional arc, edge cases |
| godot-simulate.md | Paper-prototype a game sequence to find friction and imbalance before coding |
| godot-status.md | Scan project state, generate DEVLOG, track progress |
| godot-test.md | Run automated tests via input simulation and log verification |
| godot-theme.md | Create a design token system via Godot Theme resource |
| godot-vfx.md | Create visual effects — particles, shaders, lighting, WorldEnvironment |

## Rules (7) — auto-loaded by glob

| File | Globs | Description |
|------|-------|-------------|
| gdscript.md | `**/*.gd`, `godot-plugin/**` | GDScript timing, types, architecture & UI patterns |
| shaders.md | `**/*.gdshader`, `**/vfx/**`, `**/particles/**`, `**/lighting/**`, `**/effects/**`, `**/juice/**`, `**/shake/**`, `**/screenshake/**`, `**/camera_shake*`, `**/hit_*`, `**/damage_*`, `**/freeze_*`, `**/trail*`, `**/squash*`, `**/audio/**`, `**/sfx/**`, `**/music/**`, `**/sound/**`, `**/*_audio*`, `**/*_sfx*`, `**/*_music*` | VFX, game feel & audio guardrails |
| mcp-pitfalls.md | `**/*.gd`, `godot-plugin/**` | MCP tools & TCP pitfalls |
| recipes.md | `**/*.gd`, `**/*.gdshader`, `**/*.tres` | Recipe gate — mandatory recipe lookup before implementation |
| audio.md | `**/audio/**`, `**/sfx/**`, `**/music/**`, `**/sound/**`, `**/*_audio*`, `**/*_sfx*`, `**/*_music*` | Audio guardrails — invoke /godot-audio before writing audio code |
| game-feel.md | `**/juice/**`, `**/shake/**`, `**/screenshake/**`, `**/camera_shake*`, `**/hit_*`, `**/damage_*`, `**/freeze_*`, `**/trail*`, `**/squash*` | Game feel guardrails — invoke /godot-juice before writing game feel code |
| multi-agent.md | *(no globs — always available)* | Multi-agent orchestration for game dev |

## Hooks (5 + config)

| File | Event | Description |
|------|-------|-------------|
| check_connection.py | PreToolUse | TCP check with TTL 10s cache — prevents timeout when Godot is not running |
| block_tscn_edit.py | PreToolUse | Blocks Edit/Write on .tscn files — forces MCP tool usage |
| gdscript_lint.py | PostToolUse | Lints GDScript after write via MCP — catches common mistakes |
| compact_context.py | SessionStart | Re-injects Golem MCP context after compaction |
| pre_compact.py | PreCompact | Saves project state snapshot before context compaction |
| settings.example.json | — | Template for `.claude/settings.json` — hook wiring config |

## Tools (2)

| File | Description |
|------|-------------|
| preflight.py | Pre-build validation — surfaces recipes, pitfalls, and project files |
| validate_skills.py | Coherence validator — checks skill references, recipes, and stale names |

## Recipes (20)

| File | Description |
|------|-------------|
| INDEX.md | Recipe index — concept-to-file mapping and keyword detection |
| ai_telegraph_and_weight.md | AI telegraphing & weight — timings, visual patterns, movement curves for enemies |
| audio_layering.md | Audio layering & SFX — bus hierarchy, impact layering, pitch curves, ducking, adaptive music |
| card_feel_and_shaders.md | Card feel & card shaders — CCG/TCG 2D game feel (Balatro, Slay the Spire, Inscryption) |
| collection_feel.md | Collection & inventory feel — pickup chain, fly-to-UI, counter juice, rarity communication |
| color_and_mood.md | Color & mood — palettes, color-shifting techniques, shader values for 2D mood |
| data_pipeline.md | Data pipeline — Custom Resources, Registry pattern, JSON import, validation, migration |
| dialogue_engine.md | Dialogue engine — conversation graph, condition system, state tracking, EventBus |
| dialogue_presence.md | Dialogue presence — portrait expressiveness, speaker identity, dialogue box staging |
| hit_feedback.md | Hit feedback pipeline — hitstop, flash, knockback, screenshake, particles, damage numbers |
| lights_and_shadows.md | Lights & shadows — CanvasModulate, PointLight2D, posterization, normal maps, mood lighting |
| movement_feel.md | Movement feel 2D — coyote time, input buffering, acceleration curves, variable jump |
| narrative_ui_patterns.md | Narrative UI patterns — choice card, stat chip, affliction grid, equipment grid, narrative panel |
| particle_presets.md | Particle presets 2D — tested GPUParticles2D configurations for common game effects |
| screen_transitions.md | Screen transitions — types by emotional context, timing values, shader implementations |
| shader_cookbook_2d.md | Shader cookbook 2D — dissolve, outline, flash, distortion, and creative combinations |
| turn_combat_feel.md | Turn-based combat feel — anticipation-action-reaction, camera choreography, turn transitions |
| tweens_and_juice.md | Tweens & juice — easing selection, duration ratios, squash & stretch, chain patterns |
| typewriter_and_text_fx.md | Typewriter & text FX — character-by-character reveal, vocal blips, emotional pacing |
| viewport_patterns.md | Viewport patterns — SubViewport use cases, stretch modes, split screen, pixel art rendering |

## References (2)

| File | Description |
|------|-------------|
| gdscript_pitfalls.md | GDScript 4.x pitfalls quick-scan checklist — symptom, cause, fix for each |
| workflow_patterns.md | Multi-agent patterns, architecture, scaffolding, .tscn editing |

## Godot Plugin (12 files)

| File | Description |
|------|-------------|
| plugin.cfg | Plugin metadata — name, version, entry point |
| golem_plugin.gd | EditorPlugin entry point — registers handlers, autoload, TCP server |
| golem_server.gd | TCP server multi-client — JSON-line routing, deferred responses |
| golem_capture.gd | Game autoload — screenshot capture, log capture, input simulation reader |
| handlers/input_handler.gd | Input simulation — writes command files for GolemCapture |
| handlers/inspect_handler.gd | Node property inspection and update, including Resource types |
| handlers/project_handler.gd | ProjectSettings and input map read/write |
| handlers/run_handler.gd | Play/stop scene, error/log collection from running game |
| handlers/scene_handler.gd | Scene tree read and manipulation in the editor |
| handlers/screenshot_handler.gd | Editor viewport and game screenshot capture |
| handlers/script_handler.gd | GDScript view, write, execute, and attach in editor context |
| handlers/theme_handler.gd | Theme resource creation from structured specification |
