---
description: Snapshot the current project state into CHECKPOINT.md
---
# /checkpoint — Snapshot état projet

> **Synonymes** : checkpoint, snapshot, sauvegarde, save state, état, status, où on en est, bilan, point, milestone

Tu es un project manager. Ton rôle : capturer l'état actuel du projet.

## Process

### 1. Scanner le projet

Via MCP et lecture de fichiers :
- Lire tous les `deliverables/*.md` → extraire status
- Lire `references/index.md` → lister les patterns ajoutés
- Lire `CHECKPOINT.md` précédent si existe → comparer
- Scanner les fichiers .gd/.tscn via `get_scene_tree`

### 2. Calculer les métriques

```
Livrables :
- Total : {N}
- Completed : {X}
- In Progress : {Y}
- Pending : {Z}
- Blocked : {W}

Vertical Slice : {X/N * 100}% complete
```

### 3. Générer/mettre à jour CHECKPOINT.md

```markdown
# Checkpoint — {Project Name}

> Last update: {YYYY-MM-DD HH:MM}

## Current State
- Phase: {INIT | BUILDING | POLISHING}
- Focus: {livrable in_progress ou "None"}
- Vertical Slice: {X}% complete

## Livrables

| Livrable | Status | Files |
|----------|--------|-------|
| {nom} | {status} | {count} |

## Completed Since Last Checkpoint
- {liste des livrables passés à completed}

## In Progress
- {liste des livrables in_progress}

## Next Suggested
- {livrable} — {raison de la suggestion}

## Blockers
- {liste ou "None"}

## References Added
- {nouveaux patterns depuis dernier checkpoint}

## Health Check
- [ ] Tous les scripts ont `extends`
- [ ] Pas de `print()` orphelins (utiliser GolemCapture.log)
- [ ] EventBus à jour avec les signaux utilisés
- [ ] Pas de fichiers orphelins dans scenes/
```

### 4. Health Check automatique

Vérifications via MCP :

| Check | Méthode | Action si échec |
|-------|---------|-----------------|
| Scripts valides | `get_scene_tree` | Lister les erreurs |
| Signaux EventBus | Lire `core/event_bus.gd` | Comparer avec usages |
| Fichiers orphelins | Scanner scenes/ | Lister les non-référencés |

### 5. Proposer des actions

Basé sur l'état détecté :

**Si blockers présents :**
```
⚠ {N} blockers détectés
→ /godot-debug pour diagnostic ?
```

**Si livrable prêt :**
```
✓ Prochain livrable disponible : {nom}
→ /deliverable {nom} ?
```

**Si vertical slice complet :**
```
✓ Vertical slice 100% complete !
→ /godot-design-audit pour review UX ?
```

**Si tout est complet :**
```
✓ Tous les livrables terminés
→ Prêt pour polish ou nouvelle feature
```

---

## Comparaison avec checkpoint précédent

Si un CHECKPOINT.md existe déjà, afficher le diff :

```
## Progression depuis dernier checkpoint

Durée : {temps écoulé}

Livrables :
- Nouveaux completed : {liste}
- Passés in_progress : {liste}
- Nouveaux blockers : {liste}

Fichiers :
- Créés : {count}
- Modifiés : {count}

Références :
- Ajoutées : {liste}
```

---

## Output final

```
✓ Checkpoint enregistré

État : {PHASE} — {X}% vertical slice
Focus : {livrable_en_cours}

Depuis dernier checkpoint :
- {N} livrables complétés
- {M} fichiers modifiés
- {P} références ajoutées

→ Suggestion : {action_recommandée}
```

## See also

| Skill | Quand l'utiliser |
|-------|-----------------|
| `/godot-status` | Rapport d'état complet (DEVLOG, progress.txt) |
| `/deliverable` | Reprendre le travail sur un livrable après le checkpoint |
