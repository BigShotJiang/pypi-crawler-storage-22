---
description: Debug, diagnose, and repair issues in a Godot project
---
# /fix — Debug & Repair

Tu es un debugger Godot 4.x. Quelque chose ne marche pas — trouve et répare.

## Quand utiliser

- "ça crash"
- "le joueur passe à travers les murs"
- "écran noir"
- "mon shader est cassé"
- Tout bug, erreur, comportement inattendu

## Workflow

### 1. Diagnostic séquentiel

Exécuter ces étapes DANS L'ORDRE. Ne pas sauter d'étape. Tout collecter avant de proposer un fix.

**Étape 1 — Visual state**
```
godot_get_editor_screenshot
godot_get_game_screenshot  (si le jeu tourne)
```

**Étape 2 — Logs et erreurs**
```
godot_get_errors
godot_get_logs(source="all")
```

**Étape 3 — Structure de la scène**
```
godot_get_scene_tree
```
Chercher : bodies sans CollisionShape, nodes sans script, doublons de noms, mauvais types.

**Étape 4 — Inspecter les nodes suspects**
```
godot_inspect_node(path="NodeName")
```
Chercher : position (0,0), visible=false, script=null, collision_layer=0, shape vide.

**Étape 5 — Lire les scripts**
```
godot_view_script(path="res://scripts/suspect.gd")
```
Chercher : mauvais `extends`, `_process` vs `_physics_process`, `move_and_slide()` manquant, signaux mal connectés.

### 2. Consulter le skill debug

Lire `.claude/skills/godot-debug.md` pour les bugs courants et le format de rapport.

### 3. Rapport + Fix

Présenter les findings :
```
## Diagnostic

**Problème :** [une phrase]
**Cause :** [ce qui est cassé et pourquoi]
**Preuves :** [ce qu'on a trouvé]
**Fix :** [actions précises]
```

Exécuter le fix via MCP tools. Après le fix, re-diagnostiquer pour vérifier.

### 4. Consulter les références

Avant d'écrire du code correctif, consulter :
- `references/gdscript_pitfalls.md` — pièges GDScript connus
- `recipes/INDEX.md` — si le fix implique une technique documentée

### 5. Tester si possible

Après le fix :
```
godot_play_scene → godot_get_errors → godot_get_logs
```
Si le skill `test.md` est pertinent (bug reproductible automatiquement), le consulter.

## Règles

1. **JAMAIS deviner** — si pas sûr, inspecter plus de nodes et lire plus de scripts
2. **Diagnostic avant fix** — collecter toutes les infos avant de toucher au code
3. **Un fix à la fois** — pas de fix en cascade, vérifier après chaque changement
4. **Screenshots statiques** — les effets dynamiques (shake, tweens, particules en mouvement) ne sont PAS visibles sur screenshot. Vérifier via scripts et logs

## See also

| Skill / Commande | Quand l'utiliser |
|-------------------|-----------------|
| `/godot-test` | Valider que le fix fonctionne via test automatisé |
| `/deliverable` | Reprendre le livrable après le fix |
