@tool
extends Node

## Reads and modifies ProjectSettings and input map.


func register(server: Node) -> void:
	server.register_handler("project_settings", _project_settings)
	server.register_handler("get_input_map", _get_input_map)
	server.register_handler("save_scene", _save_scene)
	server.register_handler("project_context", _project_context)
	server.register_handler("list_resources", _list_resources)


func _project_settings(args: Dictionary) -> Dictionary:
	var action: String = args.get("action", "get")
	var key: String = args.get("key", "")

	if action == "list":
		# Return commonly useful settings
		var settings := [
			"application/config/name",
			"application/config/description",
			"application/run/main_scene",
			"display/window/size/viewport_width",
			"display/window/size/viewport_height",
			"display/window/stretch/mode",
			"display/window/stretch/aspect",
			"rendering/renderer/rendering_method",
			"physics/2d/default_gravity",
			"physics/3d/default_gravity",
		]
		var lines: PackedStringArray = []
		for s in settings:
			if ProjectSettings.has_setting(s):
				lines.append("%s = %s" % [s, str(ProjectSettings.get_setting(s))])
		return {"ok": true, "type": "text", "result": "\n".join(lines)}

	if key.is_empty():
		return {"ok": false, "error": "Missing 'key' argument"}

	if action == "get":
		if not ProjectSettings.has_setting(key):
			return {"ok": false, "error": "Setting not found: %s" % key}
		var value = ProjectSettings.get_setting(key)
		return {"ok": true, "type": "text", "result": "%s = %s" % [key, str(value)]}

	if action == "set":
		var value = args.get("value")
		if value == null:
			return {"ok": false, "error": "Missing 'value' argument for set"}
		ProjectSettings.set_setting(key, value)
		ProjectSettings.save()
		return {"ok": true, "type": "text", "result": "Set %s = %s" % [key, str(value)]}

	return {"ok": false, "error": "Unknown action: %s (use 'get', 'set', or 'list')" % action}


func _get_input_map(_args: Dictionary) -> Dictionary:
	var project_actions := _parse_project_input_actions()
	var actions := InputMap.get_actions()
	var lines: PackedStringArray = []

	for action in actions:
		var action_str := str(action)
		# If we parsed project.godot successfully, only show project-defined actions
		if project_actions.size() > 0:
			if action_str not in project_actions:
				continue
		else:
			# Fallback: skip built-in UI actions
			if action_str.begins_with("ui_"):
				continue
		var events := InputMap.action_get_events(action)
		var event_strs: PackedStringArray = []
		for event in events:
			event_strs.append(event.as_text())
		if event_strs.size() > 0:
			lines.append("%s: %s" % [action_str, ", ".join(event_strs)])
		else:
			lines.append("%s: (no bindings)" % action_str)

	if lines.size() == 0:
		return {"ok": true, "type": "text", "result": "No custom input actions defined."}

	return {"ok": true, "type": "text", "result": "\n".join(lines)}


func _save_scene(_args: Dictionary) -> Dictionary:
	var root := EditorInterface.get_edited_scene_root()
	if root == null:
		return {"ok": false, "error": "No scene open"}

	var scene_path := root.scene_file_path
	if scene_path.is_empty():
		return {"ok": false, "error": "Scene has no file path — save it manually first"}

	EditorInterface.save_scene()
	return {"ok": true, "type": "text", "result": "Scene saved: %s" % scene_path}


# ------------------------------------------------------------------
# Project context dump
# ------------------------------------------------------------------

func _project_context(_args: Dictionary) -> Dictionary:
	var lines: PackedStringArray = []

	# -- Project info --
	lines.append("== Project Info ==")
	var info_keys := [
		"application/config/name",
		"application/run/main_scene",
		"display/window/size/viewport_width",
		"display/window/size/viewport_height",
		"rendering/renderer/rendering_method",
	]
	for key in info_keys:
		if ProjectSettings.has_setting(key):
			lines.append("  %s = %s" % [key.get_file(), str(ProjectSettings.get_setting(key))])

	# -- Autoloads --
	var autoloads: PackedStringArray = []
	for prop in ProjectSettings.get_property_list():
		var pname: String = prop["name"]
		if pname.begins_with("autoload/"):
			var al_name := pname.substr(9)
			var al_path := str(ProjectSettings.get_setting(pname)).lstrip("*")
			autoloads.append("  %s -> %s" % [al_name, al_path])
	lines.append("")
	lines.append("== Autoloads (%d) ==" % autoloads.size())
	lines.append_array(autoloads)

	# -- Input map (project-defined only) --
	var project_actions := _parse_project_input_actions()
	var input_lines: PackedStringArray = []
	for action in InputMap.get_actions():
		var action_str := str(action)
		if project_actions.size() > 0:
			if action_str not in project_actions:
				continue
		else:
			if action_str.begins_with("ui_"):
				continue
		var events := InputMap.action_get_events(action)
		var event_strs: PackedStringArray = []
		for event in events:
			event_strs.append(event.as_text())
		if event_strs.size() > 0:
			input_lines.append("  %s: %s" % [action_str, ", ".join(event_strs)])
		else:
			input_lines.append("  %s: (no bindings)" % action_str)
	lines.append("")
	lines.append("== Input Map (%d actions) ==" % input_lines.size())
	lines.append_array(input_lines)

	# -- File scan --
	var scripts: PackedStringArray = []
	var scenes: PackedStringArray = []
	var resources: PackedStringArray = []
	_scan_project_files("res://", scripts, scenes, resources)

	lines.append("")
	lines.append("== Scripts (%d) ==" % scripts.size())
	for s in scripts:
		lines.append("  %s" % s)

	lines.append("")
	lines.append("== Scenes (%d) ==" % scenes.size())
	for s in scenes:
		lines.append("  %s" % s)

	if resources.size() > 0:
		lines.append("")
		lines.append("== Resources (%d) ==" % resources.size())
		for r in resources:
			lines.append("  %s" % r)

	return {"ok": true, "type": "text", "result": "\n".join(lines)}


func _parse_project_input_actions() -> PackedStringArray:
	"""Parse project.godot [input] section to extract project-defined action names."""
	var actions: PackedStringArray = []
	var godot_cfg := ProjectSettings.globalize_path("res://project.godot")
	var file := FileAccess.open(godot_cfg, FileAccess.READ)
	if file == null:
		return actions

	var in_input_section := false
	while not file.eof_reached():
		var line := file.get_line().strip_edges()
		if line == "[input]":
			in_input_section = true
			continue
		if line.begins_with("[") and in_input_section:
			break  # Entered a new section
		if in_input_section and line.contains("=") and not line.begins_with(";"):
			var action_name := line.get_slice("=", 0).strip_edges()
			if not action_name.is_empty():
				actions.append(action_name)

	return actions


func _scan_project_files(path: String, scripts: PackedStringArray, scenes: PackedStringArray, resources: PackedStringArray) -> void:
	var dir := DirAccess.open(path)
	if dir == null:
		return
	dir.list_dir_begin()
	var file_name := dir.get_next()
	while file_name != "":
		var full_path: String = path.path_join(file_name)
		if dir.current_is_dir():
			if not file_name.begins_with(".") and file_name != "addons":
				_scan_project_files(full_path, scripts, scenes, resources)
		else:
			if file_name.ends_with(".gd"):
				scripts.append(full_path)
			elif file_name.ends_with(".tscn"):
				scenes.append(full_path)
			elif file_name.ends_with(".tres"):
				resources.append(full_path)
		file_name = dir.get_next()
	dir.list_dir_end()


# ------------------------------------------------------------------
# List resources — scan project files with optional type filter
# ------------------------------------------------------------------

const DEFAULT_EXTENSIONS: PackedStringArray = ["gd", "tscn", "tres", "png", "jpg", "wav", "ogg", "mp3", "gdshader", "cfg"]

func _list_resources(args: Dictionary) -> Dictionary:
	var type_filter: String = args.get("type", "")
	var scan_path: String = args.get("path", "res://")
	var max_results: int = args.get("max_results", 200)

	if not scan_path.begins_with("res://"):
		scan_path = "res://" + scan_path

	var extensions: PackedStringArray
	if type_filter.is_empty():
		extensions = DEFAULT_EXTENSIONS
	else:
		extensions = [type_filter.lstrip(".")]

	var results: PackedStringArray = []
	_scan_files_by_ext(scan_path, extensions, results, max_results)

	if results.size() == 0:
		var ext_str := ", ".join(extensions)
		return {"ok": true, "type": "text", "result": "No files found matching extension(s): %s in %s" % [ext_str, scan_path]}

	var truncated := ""
	if results.size() >= max_results:
		truncated = "\n(truncated at %d results)" % max_results

	return {"ok": true, "type": "text", "result": "\n".join(results) + truncated}


func _scan_files_by_ext(path: String, extensions: PackedStringArray, results: PackedStringArray, max_results: int) -> void:
	if results.size() >= max_results:
		return
	var dir := DirAccess.open(path)
	if dir == null:
		return
	dir.list_dir_begin()
	var file_name := dir.get_next()
	while file_name != "" and results.size() < max_results:
		var full_path: String = path.path_join(file_name)
		if dir.current_is_dir():
			if not file_name.begins_with(".") and file_name != "addons":
				_scan_files_by_ext(full_path, extensions, results, max_results)
		else:
			var ext := file_name.get_extension()
			if ext in extensions:
				results.append(full_path)
		file_name = dir.get_next()
	dir.list_dir_end()
