# Recipes — Index

> **OBLIGATOIRE** : avant d'implémenter un concept listé ci-dessous, lire la recette correspondante.
> Si aucune recette n'existe pour le concept, informer l'utilisateur et proposer d'en créer une après implémentation.

## Qu'est-ce qu'une recette ?

**Une recette ≠ de la documentation.** Les skills couvrent le "comment faire" (l'API, les outils, la technique). Les recettes couvrent le "comment bien faire" — la marinade, pas le four.

Concrètement, une recette contient :
- **Des patterns non-évidents** — combinaisons, ordres d'exécution, techniques que la doc officielle ne donne pas
- **Des valeurs testées** — timings, ratios, intensités issus de jeux publiés (Celeste, Dead Cells, Hades, Capcom...)
- **Des résultats créatifs** — ce que le joueur RESSENT, pas ce que le code fait
- **Des pièges de design** — pas les pièges API (ça c'est dans les skills/rules), mais les erreurs qui tuent le feeling

Une recette ne contient PAS :
- De la documentation d'API (c'est dans les skills)
- Des tutoriels "comment utiliser X" (c'est dans la doc Godot)
- Des patterns d'architecture génériques (c'est dans `.claude/skills/godot-architecture.md`)

**Test de la marinade** : si un agent Claude pourrait déduire l'info de la doc officielle, ça n'a pas sa place dans une recette.

## Recettes disponibles

| Concept | Fichier | Dim | Mots-clés (détection) |
|---|---|---|---|
| Lights & Shadows | `lights_and_shadows.md` | 2D | light, shadow, CanvasModulate, PointLight2D, DirectionalLight2D, LightOccluder2D, normal map, specular, posterization, dithering, void light() |
| Color & Mood | `color_and_mood.md` | — | color palette, mood, color grading, vignette, desaturation, temperature, rarity, damage type, corruption, day night, CanvasModulate tint, saturation, film grain, LUT, limited palette, accent color, color shift |
| Dialogue Presence | `dialogue_presence.md` | — | dialogue, portrait, expression, text speed, voice blip, dialogue box, nameplate, choice, timed choice, internal voice, priority queue, contextual dialogue, BBCode, RichTextLabel, text effect, shake, wave, conversation, NPC, speaker identity |
| Particle Presets | `particle_presets.md` | 2D | particle, GPUParticles2D, CPUParticles2D, ParticleProcessMaterial, explosion, dust puff, blood, trail, fire, torch, rain, snow, motes, sparkle, collectible, emission, burst, one_shot, color_ramp, scale_curve, additive blend, glow, VFX |
| Typewriter & Text FX | `typewriter_and_text_fx.md` | — | typewriter, visible_characters, per character, cps, characters per second, punctuation pause, ellipsis, RichTextEffect, CharFXTransform, fadein, tremble, custom effect, blip interval, pitch_scale, AudioStreamRandomizer, text skip, auto-advance, speed tag, inline tag, emotional pacing, mood speed |
| Shader Cookbook 2D | `shader_cookbook_2d.md` | 2D | dissolve, hit flash, outline, shockwave, chromatic aberration, CRT, retro, palette swap, LUT, water distortion, heat haze, screen damage, speed lines, blur vignette, screenshake, hitstop, freeze frame, burn edge, additive flash, HDR glow, overbright |
| AI Telegraph & Weight | `ai_telegraph_and_weight.md` | — | telegraph, anticipation, wind-up, recovery, weight, momentum, acceleration, enemy AI, boss design, phase transition, attack pattern, frame data, window of opportunity, squash stretch, flash, stagger, cooldown, pattern mixing |
| Card Feel & Shaders | `card_feel_and_shaders.md` | 2D | card, hand, hover, drag, tilt, foil, holographic, polychrome, flip, dissolve, burn, CCG, TCG, deckbuilder, fan layout, card play, rarity glow, idle sway, rubber band, snap back |
| Hit Feedback Pipeline | `hit_feedback.md` | 2D | hit, hitstop, freeze frame, screenshake, knockback, hit flash, damage number, impact, combo, hit feedback, juice, white flash, additive flash, camera shake |
| Movement Feel 2D | `movement_feel.md` | 2D | coyote time, input buffer, acceleration, jump, variable jump, air control, corner correction, ledge assist, dash, wall slide, CharacterBody2D, platformer, movement |
| Tweens & Juice | `tweens_and_juice.md` | — | tween, ease, easing, squash, stretch, overshoot, bounce, pop-in, BACK_OUT, ELASTIC, chain, parallel, juice, scale, alpha, rotation, Tween API |
| Screen Transitions | `screen_transitions.md` | — | transition, fade, iris, wipe, diamond, dissolve, scene change, CanvasLayer, loading, crossfade, shader transition, room transition, door |
| Audio Layering & SFX | `audio_layering.md` | — | audio, SFX, music, bus, ducking, pitch variation, spatial, AudioStreamPlayer, AudioStreamRandomizer, impact layer, transient, reverb, volume, dB, compression |
| Collection & Inventory Feel | `collection_feel.md` | — | pickup, collect, fly-to-UI, counter, toast, rarity, glow, inventory, grid, loot, item, reward, dopamine, feedback chain |
| Turn-Based Combat Feel | `turn_combat_feel.md` | — | turn-based, combat, action beat, anticipation, reaction, damage number, camera, status effect, menu, battle, RPG, Persona, combo, chain |
| Narrative UI Patterns | `narrative_ui_patterns.md` | — | choice card, stat chip, affliction, equipment grid, narrative panel, HUD narratif, RPG, dialogue UI, skill check, character sheet, status effect, inventory, portrait, speaker, Disco Elysium, Persona, Hades, Darkest Dungeon |
| Data Pipeline | `data_pipeline.md` | — | Resource, custom resource, registry, data-driven, JSON, import, validation, schema, migration, save version, hot-reload, RPG data, card data, database, preload, lazy load, typed resource |
| Dialogue Engine | `dialogue_engine.md` | — | dialogue, conversation, graph, branching, condition, flag, choice, skill check, timed choice, NPC, speaker, state tracking, relationship, quest, event bus, dialogue tree, Ink, Yarn, narrative |
| Viewport Patterns | `viewport_patterns.md` | — | SubViewport, viewport, SubViewportContainer, split screen, minimap, pixel art, stretch mode, canvas_items, 3D in UI, portrait, ViewportTexture, render to texture, security camera, scope, sniper zoom, Window, multi-monitor, hybrid rendering, display, window size, resolution, fullscreen, scaling, project setup, screen size, 1920, 1080, render size |
| FBX Animation Retargeting | `fbx_retargeting.md` | 3D | FBX, retargeting, BoneMap, Skeleton3D, SkeletonProfileHumanoid, animation, T-pose, skeleton path, track remap, .import, _subresources, reimport, cross-skeleton, Synty, bone convention, skinning, MeshInstance3D |

## Format attendu

Chaque recette suit cette structure :

1. **Progression** — du setup de base au stack complet, pas un catalogue à plat
2. **Shaders complets** — code copié-collé, pas de pseudocode
3. **Pièges nommés** — gotchas spécifiques, pas des avertissements génériques
4. **Résultat visuel décrit** — ce que le joueur voit, pas ce que le code fait
5. **Stack final** — comment les techniques se combinent entre elles
