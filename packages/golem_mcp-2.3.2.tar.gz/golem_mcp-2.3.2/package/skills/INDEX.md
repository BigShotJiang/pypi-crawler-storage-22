---
description: Reference index of all Golem MCP skills and their relationships
user-invocable: false
---
# Golem MCP — Index des Skills

> Ce fichier est une référence rapide pour trouver le bon skill. Chaque skill a des **synonymes** qui aident Claude à le matcher.

---

## Routeur

| Skill | Description | Synonymes |
|-------|-------------|-----------|
| `/godot` | Point d'entrée principal, analyse l'intent et dispatche | godot, router, dispatch, aide, help |

---

## Workflow & Projet

| Skill | Description | Synonymes |
|-------|-------------|-----------|
| `/init` | Bootstrap projet (nouveau ou reprise) | init, bootstrap, nouveau projet, commencer, démarrer, reprendre, setup |
| `/deliverable` | Focus sur un livrable spécifique | deliverable, livrable, feature, tâche, focus, implémenter |
| `/checkpoint` | Snapshot état projet | checkpoint, snapshot, sauvegarde, état, bilan, milestone |
| `/references` | Patterns et conventions réutilisables | references, patterns, conventions, guidelines, bonnes pratiques |
| `/golem-dev` | Mode développement du MCP | golem-dev, mcp, plugin, modifier le mcp, meta, contribuer |

---

## Planification & Simulation

| Skill | Description | Synonymes |
|-------|-------------|-----------|
| `/godot-plan` | Mini-PRD avant construction | plan, planning, design, PRD, spec, vision, mécaniques |
| `/godot-sequence` | Définir le game flow en YAML | sequence, séquence, flow, game loop, boucle, states, core loop, parcours |
| `/godot-simulate` | Paper prototyping : simuler le jeu sur papier | simulate, simuler, simulation, paper prototype, tester, vérifier, persona |
| `/godot-gate` | Validation avant construction | gate, valider, vérifier, prêt, ready, check, passer en dev |

---

## Architecture

| Skill | Description | Synonymes |
|-------|-------------|-----------|
| `/godot-architecture` | Scaffolding modulaire ECS/EventBus | architecture, ECS, EventBus, structure, refactoring, modules, découplage |

---

## Construction

| Skill | Description | Synonymes |
|-------|-------------|-----------|
| `/godot-scene` | Construire une scène | scene, scène, level, niveau, build, créer, nodes, tscn |

---

## UI

| Skill | Description | Synonymes |
|-------|-------------|-----------|
| `/godot-composition` | Structure UI (layout, containers, rôles) | composition, layout, containers, HBox, VBox, tokens, spacing, anchors |
| `/godot-behavior` | Vie UI (états, tweens, feedback sonore) | behavior, UI animation, tween, hover, focus, pressed, états, transitions |
| `/godot-theme` | Design tokens via Theme resource | theme, palette, colors, fonts, StyleBox, style, skin, dark mode |

---

## Game Feel & VFX

| Skill | Description | Synonymes |
|-------|-------------|-----------|
| `/godot-juice` | Game feel : screenshake, freeze, squash, trails, damage numbers | juice, game feel, polish, impact, punch, screenshake, hitstop, squash, stretch, trail, damage numbers |
| `/godot-vfx` | Effets visuels : particules, shaders, lighting | vfx, particles, shader, glow, bloom, lighting, WorldEnvironment, HDR, dissolve, outline, sway |

---

## Audio, Sauvegarde & Caméra

| Skill | Description | Synonymes |
|-------|-------------|-----------|
| `/godot-audio` | Audio : bus, musique, SFX, spatial, volume | audio, son, sound, music, musique, sfx, bus, volume, crossfade, spatial |
| `/godot-save` | Sauvegarde : settings, save/load, persistence | save, load, sauvegarde, chargement, settings, config, persistence, configfile, json |
| `/godot-camera` | Caméra 2D : suivi, zoom, limites, cinematic | camera, caméra, camera2d, follow, suivi, zoom, limit, limites, dead zone, cinematic |

---

## Test & Debug

| Skill | Description | Synonymes |
|-------|-------------|-----------|
| `/godot-test` | Test automatisé via input simulation + logs | test, tester, run test, vérifier, simulate, essayer, play test, automated test, test loop |
| `/godot-debug` | Diagnostic et fix de bugs | debug, fix, bug, crash, error, broken, problem, not working, écran noir, freeze |
| `/godot-design-audit` | Audit UX de l'UI existante | audit, review, UX, usability, critique, améliorer, qu'est-ce que t'en penses |
| `/godot-status` | Documentation état projet | status, état, progress, devlog, rapport, scan, résumé |

---

## Graphe des dépendances

```
/init ─────────────────┐
                       ▼
              /godot-plan ──────[GAME_PLAN.md]
                       │
                       ▼
            /godot-sequence ──────[GAME_SEQUENCE.yaml + data/*.yaml]
                       │
                       ▼
            /godot-simulate ──────[rapport simulation]
                       │
                       ▼
              /godot-gate ──────[gate result]
                       │
                       ▼
            /godot-architecture ──────[core/, entities/]
                       │
         ┌─────────────┼─────────────┐
         ▼             ▼             ▼
   /godot-scene  /godot-juice  /godot-vfx
         │
         ▼
  /godot-composition ──────[rôles metadata]
         │
         ▼
    /godot-theme ──────[theme.tres]
         │
         ▼
   /godot-behavior

/godot-audio  ← indépendant
/godot-save   ← indépendant
/godot-camera ← indépendant (ref /godot-juice pour le shake)
/godot-test   ← indépendant (utilise simulate_input + get_logs + find_nodes)
/godot-debug  ← indépendant
/godot-status ← indépendant
/godot-design-audit ← indépendant
```

---

## Comment choisir ?

| Tu veux... | Skill |
|------------|-------|
| Commencer un projet | `/init` |
| Planifier avant de coder | `/godot-plan` |
| Définir le game flow | `/godot-sequence` |
| Tester le jeu sur papier | `/godot-simulate` |
| Valider avant de coder | `/godot-gate` |
| Structurer le projet | `/godot-architecture` |
| Construire une scène | `/godot-scene` |
| Créer une UI | `/godot-composition` → `/godot-theme` → `/godot-behavior` |
| Ajouter du game feel | `/godot-juice` |
| Ajouter des effets visuels | `/godot-vfx` |
| Gérer l'audio (musique, SFX, bus) | `/godot-audio` |
| Sauvegarder / charger / settings | `/godot-save` |
| Configurer la caméra 2D | `/godot-camera` |
| Tester automatiquement (inputs + logs) | `/godot-test` |
| Chercher des nodes dans la scène | `godot_find_nodes` (tool MCP) |
| Fixer un bug | `/godot-debug` |
| Avoir un avis sur l'UX | `/godot-design-audit` |
| Voir l'état du projet | `/godot-status` ou `/checkpoint` |
| Modifier le MCP | `/golem-dev` |
