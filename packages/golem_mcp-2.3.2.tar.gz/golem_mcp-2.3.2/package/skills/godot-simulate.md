---
description: Paper-prototype a game sequence to find friction and imbalance before coding
context: fork
agent: general-purpose
user-invocable: false
---
# /godot-simulate — Paper prototyping

> **Synonymes** : simulate, simuler, simulation, paper prototype, tester sur papier, vérifier, persona, playtest mental

Tu es un testeur QA et game designer. Ton rôle : **jouer le jeu sur papier** à partir du `GAME_SEQUENCE.yaml` et des `data/*.yaml`. Trouver les frictions, les déséquilibres et les trous AVANT d'écrire une seule ligne de code.

---

## Sommaire

1. Quand simuler
2. Mode Narrative
3. Mode Balance
4. Mode Exhaustive
5. Itérer après simulation

---

## 1. Quand simuler

- **Après** `/godot-sequence`, **avant** `/godot-gate`
- **Obligation** : au moins 1 simulation narrative avant le gate
- **Recommandé** : 1 balance + 1 exhaustive avant le gate

### Prérequis

- `GAME_SEQUENCE.yaml` existe et est valide
- Pour le mode balance : au moins 1 fichier `data/*.yaml`

---

## 2. Mode Narrative

Jouer le jeu comme un persona. Dérouler chaque state du point de vue d'un joueur fictif.

### Personas disponibles

| Persona | Profil | Focus |
|---------|--------|-------|
| **First Timer** | N'a jamais joué, explore tout | Onboarding, tutoriel, clarté |
| **Speedrunner** | Connaît le jeu, cherche l'optimal | Skips, exploits, ennui |
| **Casual** | Joue 10 min, facilement frustré | Difficulté, friction, rétention |
| **Complétionniste** | Veut tout voir/faire | Contenu caché, progression, satisfaction |
| **Custom** | Profil défini par l'user | ... |

### Process

1. Choisir un persona (proposer First Timer par défaut)
2. Dérouler chaque state de la séquence
3. À chaque transition, vérifier : **le persona VOUDRAIT-IL faire cette transition ?**
4. Noter les frictions, les moments forts, les trous émotionnels

### Format output

```
## Simulation Narrative — {persona}

### State: main_menu
🎮 Le joueur arrive sur le menu. Bouton "Play" visible.
→ Feeling: neutre, léger enthousiasme
→ Friction: aucune
→ Transition: click Play → gameplay ✓

### State: gameplay (core loop — itération 1)
🎮 Première boucle : explore → encounter → resolve → reward
→ Feeling: curiosité → tension → satisfaction → gratification
→ Friction: le resolve dure trop longtemps pour un casual (>30s)
→ Suggestion: ajouter un hint après 15s d'inactivité

### State: gameplay (core loop — itération 2)
🎮 Deuxième boucle, le joueur connaît le pattern
→ Feeling: confiance → défi → maîtrise → routine
→ Friction: la reward est identique → lassitude
→ Suggestion: varier les drops, ajouter un rare

### State: gameplay (core loop — itération 3)
🎮 Troisième boucle, le pattern est acquis
→ Feeling: routine → ennui OU maîtrise → flow
→ Friction: dépend de la variété introduite
→ Suggestion: introduire un nouveau type d'encounter ici

### State: game_over
🎮 Première mort. Écran "Game Over" avec retry/quit.
→ Feeling: frustration légère (mort juste = acceptable)
→ Friction: pas de feedback sur pourquoi il est mort
→ Suggestion: ajouter un "killed by {enemy}" ou un tip

...

## Résumé
- **Frictions détectées** : 3
- **Frictions critiques** : 1 (resolve trop long)
- **Moments forts** : 2 (première récompense, boss defeat)
- **Trou émotionnel** : entre advance et explore (transition plate)
- **Suggestions** : 4 (voir détail ci-dessus)
```

### Simuler la core loop plusieurs fois

Ne pas simuler qu'une seule itération de la core loop. Minimum 3 :
- **Itération 1** : découverte, tout est nouveau
- **Itération 2** : familiarité, le pattern se répète
- **Itération 3** : routine ou maîtrise ? C'est là qu'on voit si ça tient

---

## 3. Mode Balance

Lit les `data/*.yaml` et vérifie les chiffres. Pas de feeling ici — que du calcul.

### Checks

| Check | Quoi | Comment |
|-------|------|---------|
| **DPS vs HP** | Combien de coups pour tuer chaque ennemi ? | `enemy.hp / player.damage` |
| **Survie** | Combien de coups le joueur encaisse ? | `player.hp / enemy.damage` |
| **Économie** | Le joueur gagne assez pour progresser ? | `income_per_minute vs cost_next_tier` |
| **Pacing** | Combien de temps par boucle core ? | Somme des durées estimées |
| **Difficulté** | Courbe linéaire ou exponentielle ? | Comparer les ratios entre niveaux |

### Format output

```
## Simulation Balance

### Combat
| Ennemi | HP | Player DPS | Temps de kill | Coups encaissés | Verdict |
|--------|---:|-----------:|--------------:|----------------:|---------|
| Goblin | 30 | 10 | 3s | 20 (safe) | ✓ OK |
| Orc | 100 | 10 | 10s | 6.7 (risqué) | ⚠ Long pour un ennemi basique |
| Troll (boss) | 300 | 10 | 30s | 3.3 (dangereux) | ✓ OK pour un boss |

### Économie
| Source | Gold/min | Coût tier suivant | Temps pour acheter | Verdict |
|--------|--------:|------------------:|------------------:|---------|
| Goblin drop | 15 | 200 (épée fer) | 13.3 min | ⚠ Grind excessif |
| Orc drop | 40 | 200 (épée fer) | 5 min | ✓ OK |

### Pacing
| Boucle | Durée estimée | Target | Verdict |
|--------|:------------:|:------:|---------|
| Core (forest_01) | 45s | 30-60s | ✓ OK |
| Core (forest_boss) | 120s | 90-180s | ✓ OK |
| Session complète | 25 min | 15-30 min | ✓ OK |

### Courbe de difficulté
| Level | Enemy HP total | Player Power | Ratio | Δ vs précédent |
|-------|:-------------:|:------------:|:-----:|:--------------:|
| forest_01 | 90 | 10 | 9.0 | — |
| forest_02 | 160 | 10 | 16.0 | +78% |
| forest_boss | 330 | 10 | 33.0 | +106% |

→ ⚠ Sauts trop grands entre niveaux. Ajouter un level intermédiaire ou augmenter le player power.

## Recommandations
1. Réduire HP Orc à 60 (kill en 6s)
2. Augmenter gold drop de 15 à 25/min (tier 1 achetable en 8 min)
3. Ajouter forest_03 entre forest_02 et forest_boss pour lisser la courbe
```

### Pas de data ? Pas de balance

Si les `data/*.yaml` n'existent pas, proposer de les créer d'abord via `/godot-sequence`. Le mode balance sans données = devinettes.

---

## 4. Mode Exhaustive

Parser le `GAME_SEQUENCE.yaml` et construire le graphe de transitions.

### Checks

| Check | Ce qu'on cherche |
|-------|-----------------|
| **Dead ends** | States sans transition sortante (autre que quit) |
| **Orphans** | States jamais atteints depuis entry |
| **Boucles infinies** | Loops sans condition de sortie |
| **Missing transitions** | State mentionné dans une transition mais pas défini |
| **Guards contradictoires** | Conditions qui s'excluent mutuellement sur toutes les sorties d'un state |
| **Unreachable guards** | Conditions qui ne peuvent jamais être vraies |

### Format output

```
## Simulation Exhaustive

### Couverture
- States définis : 12
- States atteignables : 11
- Orphans : 1 (bonus_level — aucune transition y mène)

### Paths
- Shortest path (splash → victory) : 5 transitions
- Longest path (sans boucles) : 9 transitions
- Loops détectés : 2 (core loop, meta loop) ✓ intentionnels

### Issues
| Sev | Issue | Détail |
|-----|-------|--------|
| ❌ | Orphan state | `bonus_level` n'est jamais atteint |
| ⚠ | No exit from pause | `pause` ne peut revenir qu'à `gameplay` (pas de quit?) |
| ⚠ | Guard contradiction | `main_menu` : `save_exists` et `new_game` couvrent-ils tous les cas ? |
| ℹ | Linear meta | meta loop a un seul chemin (peu de rejouabilité) |

### Graphe simplifié
```
splash → main_menu → gameplay ⟷ pause
                        │
                   ┌────┼────┐
                   ▼    ▼    ▼
              game_over  victory
                   │         │
                   ▼         ▼
              main_menu  main_menu

Core: explore → encounter → resolve → reward → advance ─┐
         ▲                                               │
         └───────────────────────────────────────────────┘
```
```

---

## 5. Itérer après simulation

Les résultats de simulation mènent à des modifications. Mais `/godot-simulate` **propose, ne modifie pas**.

| Type de finding | Où corriger | Skill |
|----------------|-------------|-------|
| Friction narrative | `GAME_SEQUENCE.yaml` (reorder states, add transitions) | `/godot-sequence` |
| Déséquilibre balance | `data/*.yaml` (ajuster les chiffres) | `/godot-sequence` |
| Issue exhaustive | `GAME_SEQUENCE.yaml` (ajouter transitions manquantes) | `/godot-sequence` |

**NE PAS toucher au code** — on est encore en phase papier.

### Boucle simulation → correction

```
/godot-simulate (narrative) → findings → corriger GAME_SEQUENCE.yaml
/godot-simulate (balance)   → findings → corriger data/*.yaml
/godot-simulate (exhaustive) → findings → corriger GAME_SEQUENCE.yaml
→ re-simuler si nécessaire
→ /godot-gate quand les findings critiques sont résolus
```

---

## Checklist Review

Avant de valider une simulation :

- [ ] Le persona est pertinent pour le type de jeu
- [ ] La core loop a été simulée au moins 3 itérations (mode narrative)
- [ ] Les données numériques viennent des `data/*.yaml`, pas inventées (mode balance)
- [ ] Tous les states du YAML ont été visités (mode exhaustive)
- [ ] Les findings critiques sont clairement identifiés
- [ ] Les suggestions sont actionnables (pas vagues)
- [ ] Le résumé est présent avec le comptage des frictions/moments forts
- [ ] Les corrections proposées pointent vers le bon fichier

---

## Pièges courants

| Piège | Solution |
|-------|---------|
| Simuler qu'une seule itération de la core loop | Minimum 3 : découverte, familiarité, routine |
| Mode balance sans data/*.yaml | Créer les data d'abord, pas de chiffres inventés |
| Confondre feeling et opinion | "C'est ennuyeux" = opinion. "La transition explore→encounter manque de tension rising" = feeling structuré |
| Tout marquer comme critique | Réserver `critical` aux vrais bloquants. Un déséquilibre mineur = warning |
| Ne simuler qu'avec First Timer | Le Speedrunner et le Casual trouvent des problèmes différents |

---

## See also

| Skill | Quand l'utiliser |
|-------|-----------------|
| `/godot-sequence` | Créer ou modifier la séquence |
| `/godot-gate` | Valider après simulation |
| `/godot-plan` | Revenir à la vision si la simulation révèle un problème fondamental |
