---
description: Run automated tests via input simulation and log verification
user-invocable: false
---
# /godot-test — Test automatisé via input simulation

> **Synonymes** : test, tester, run test, vérifier, simulate, essayer, play test, automated test, test loop

Tu es un testeur automatisé. Ton rôle : jouer le jeu, lire les résultats, itérer.

---

## Prérequis

1. **GolemCapture autoload actif** — vérifier dans Project Settings > Autoload
2. **Actions Input Map définies** — `godot_get_input_map` ou lire `project.godot` section `[input]`
3. **Logs structurés dans le code** — le jeu doit exposer son état via `GolemCapture.game_log("key=value")`

Si les prérequis ne sont pas remplis, **dire ce qui manque** et proposer de le corriger avant de tester.

---

## Process

### Étape 1 — Analyser le contexte

```
godot_get_scene_tree()          → comprendre la scène
godot_get_input_map()           → lister les actions disponibles
```

Lire les scripts pertinents (joueur, ennemis, score) pour identifier :
- Quelles actions le jeu supporte
- Quels `GolemCapture.game_log()` existent déjà
- Ce qu'il faudrait ajouter comme logs pour vérifier les résultats

### Étape 2 — Préparer les logs

Si le code ne log pas l'état qu'on veut vérifier, **ajouter les logs d'abord** :

```gdscript
# Convention : key=value, parseable, pas de prose
GolemCapture.game_log("player_position=%s" % str(global_position))
GolemCapture.game_log("score=%d" % score)
GolemCapture.game_log("health=%d" % health)
GolemCapture.game_log("enemy_count=%d" % get_tree().get_nodes_in_group("enemies").size())
```

### Étape 3 — Construire la séquence

Concevoir une séquence d'inputs qui teste le comportement voulu :

```python
# Pattern : setup → action → vérification
[
    {"wait": 0.5},                           # Laisser le jeu s'initialiser
    {"action": "move_right", "duration": 1.0},  # Action à tester
    {"wait": 0.3}                            # Laisser le résultat se propager
]
```

**Règles de conception** :
- Commencer par un `wait` de 0.3-0.5s (laisser _ready() tourner)
- Finir par un `wait` de 0.2-0.3s (laisser les logs se flusher)
- Garder les séquences courtes (<10 steps). Diviser si besoin
- Un test = un comportement vérifié

### Étape 4 — Exécuter

```
1. godot_play_scene()
2. godot_get_logs()                          → purger le buffer initial
3. godot_simulate_input(sequence=..., loop=1)
4. godot_get_logs()                          → lire les NOUVELLES lignes
5. Analyser les logs
```

### Étape 5 — Analyser et décider

Chercher dans les logs les clés attendues :

| Résultat | Action |
|----------|--------|
| Clé présente, valeur correcte | Test PASS — passer au test suivant |
| Clé présente, valeur incorrecte | Bug identifié — stop, corriger, recommencer |
| Clé absente | Log manquant — ajouter le `GolemCapture.game_log()` et recommencer |
| Erreur/crash dans les logs | Bug — `godot_get_errors()` pour plus de détails |

### Étape 6 — Itérer ou conclure

Si un test échoue :
1. `godot_stop_scene()`
2. Corriger le script
3. Retour à l'étape 4

**Max 3 itérations par test.** Si ça ne passe pas après 3 essais, le problème est probablement plus profond — basculer vers `/godot-debug`.

---

## Scénarios de test types

### Mouvement
```python
# Le joueur bouge-t-il quand on presse une direction ?
sequence = [
    {"wait": 0.5},
    {"action": "move_right", "duration": 1.0},
    {"wait": 0.3}
]
# Vérifier : player_position.x a augmenté
```

### Collision
```python
# Le joueur s'arrête-t-il contre un mur ?
sequence = [
    {"wait": 0.3},
    {"action": "move_right", "duration": 5.0},  # Assez long pour atteindre le mur
    {"wait": 0.3}
]
# Vérifier : player_position.x < wall_x
```

### Combat
```python
# L'attaque inflige-t-elle des dégâts ?
sequence = [
    {"wait": 0.5},
    {"action": "move_right", "duration": 0.5},  # S'approcher de l'ennemi
    {"action": "attack", "duration": 0.15},
    {"wait": 0.5}
]
# Vérifier : enemy_hit=true ou enemy_health diminué
```

### Inactivité (smoke test)
```python
# Le jeu crash-t-il si on ne fait rien ?
sequence = [{"wait": 3.0}]
# Vérifier : pas d'erreur dans get_errors()
```

### Stress
```python
# Input rapide en boucle
sequence = [
    {"action": "attack", "duration": 0.1},
    {"wait": 0.05}
]
# loop=20, vérifier : pas de crash, pas de memory leak
```

---

## Format de rapport

Après les tests, résumer :

```
## Test Report

| Test | Séquence | Résultat | Notes |
|------|----------|----------|-------|
| Mouvement droite | move_right 1s | PASS | position.x += ~200 |
| Collision mur | move_right 5s | PASS | bloqué à x=480 |
| Attaque | move + attack | FAIL | enemy_health inchangé |
| Smoke test | wait 3s | PASS | aucune erreur |

### Bugs trouvés
- L'attaque ne connecte pas → vérifier la hitbox CollisionShape2D

### Logs manquants
- Pas de log sur le score → ajouter GolemCapture.game_log("score=%d")
```

---

## Quand utiliser find_nodes

`godot_find_nodes` permet de vérifier l'état de la scène éditée **avant** de lancer le jeu :

```
godot_find_nodes(type="Area2D")              → vérifier que les hitboxes existent
godot_find_nodes(group="enemies")            → compter les ennemis dans la scène
godot_find_nodes(name="*Score*")             → trouver le node qui affiche le score
godot_find_nodes(script="player.gd")         → vérifier que le script est attaché
```

Utile pour diagnostiquer **avant** de tester : "est-ce que la scène est bien construite ?"

---

## Règles

1. **Logs d'abord, inputs ensuite** — sans `GolemCapture.game_log()`, tu testes en aveugle
2. **Séquences courtes** — 1 test = 1 comportement. Pas de méga-séquence de 30 steps
3. **3 itérations max** — après ça, c'est `/godot-debug` qui prend le relais
4. **Convention key=value** — pas de `GolemCapture.game_log("Le joueur a pris des dégâts")` mais `GolemCapture.game_log("player_hit damage=5 health=95")`
5. **Purger les logs** — toujours un `get_logs()` de purge entre `play_scene` et `simulate_input`
6. **Ne pas boucler sur les screenshots** — les logs sont plus fiables après play

---

## See also

| Skill | Quand l'utiliser |
|-------|-----------------|
| `/godot-debug` | Quand un test échoue après 3 itérations |
| `/godot-scene` | Quand il manque des nodes (hitbox, spawn point) |
| `/godot-juice` | Après que les tests passent, pour le polish |
