---
description: Quickly load project context at the start of a new session
---
# /catchup — Reprise de contexte rapide

> **Synonymes** : catchup, catch-up, rattraper, contexte, reprendre, where was I, où j'en suis, c'est quoi le projet, recap

Tu es un assistant qui reprend le fil. Ton rôle : scanner le projet et synthétiser l'état en 30 secondes. Zéro question, zéro création de fichier.

**Le projet Godot lui-même EST le contexte.** Les fichiers de suivi (GAME_PLAN, CHECKPOINT, deliverables) sont un bonus — pas un prérequis.

## Process

### 1. Scanner le projet réel

Toujours exécuter, c'est la base :

| Source | Méthode | Ce qu'on en tire |
|--------|---------|-----------------|
| `project.godot` | Read | Nom du projet, version, autoloads, renderer, input map |
| Arborescence | Glob `**/*.gd`, `**/*.tscn` | Structure du projet, taille, organisation |
| `CLAUDE.md` (projet) | Read | Instructions spécifiques, conventions, liens |
| Scène ouverte | MCP `get_scene_tree` (si connecté) | Contexte de travail immédiat |
| Erreurs | MCP `get_errors` (si connecté) | Problèmes en cours |

### 2. Scanner les fichiers de suivi (si présents)

Lire s'ils existent, ignorer silencieusement sinon :

| Fichier | Ce qu'on en tire |
|---------|-----------------|
| `GAME_PLAN.md` | Vision, feeling, mécaniques core, gameplay loop |
| `CHECKPOINT.md` | Phase actuelle, focus, blockers, progression |
| `deliverables/*.md` | Status de chaque livrable (pending/in_progress/completed) |
| `references/index.md` | Conventions établies (spacing, colors, components) |

### 3. Synthétiser

Adapter le format selon ce qui existe :

#### Projet avec fichiers de suivi (post-`/init`)

```
# {Nom du projet}

## Vision
{Pitch 1-2 phrases depuis GAME_PLAN — feeling visé, pas features}

## État
- Phase : {INIT | BUILDING | POLISHING}
- Focus : {livrable in_progress ou "aucun"}
- Progression : {X}/{N} livrables ({%})

## Livrables
| Livrable | Status |
|----------|--------|
| {nom} | {status emoji + texte} |

## Conventions actives
{Résumé des patterns de references/index.md, ou "Aucune encore"}

## Blockers
{Liste ou "Aucun"}

## Scène ouverte
{Nom de la scène via MCP, ou "MCP non connecté"}

→ Suggestion : {action la plus pertinente basée sur l'état}
```

#### Projet sans fichiers de suivi (projet existant)

```
# {Nom du projet}

## Structure
- {N} scripts .gd, {M} scènes .tscn
- Autoloads : {liste depuis project.godot}
- Dossiers principaux : {top-level dirs pertinents}

## Architecture détectée
{Ce qu'on devine de l'organisation — ECS-like, monolithique, scene-based, etc.}

## Scène ouverte
{Nom + structure résumée via MCP, ou "MCP non connecté"}

## Erreurs
{Liste via MCP ou "Aucune" ou "MCP non connecté"}

→ Prêt à travailler. Pour structurer le suivi : `/init`
```

### Status emojis (si deliverables présents)

- `⬡ pending` — pas encore commencé
- `▶ in_progress` — en cours
- `✓ completed` — terminé
- `⚠ blocked` — bloqué

---

## Règles

1. **Read-only** — ne rien créer, ne rien modifier, ne rien écrire
2. **Pas de questions** — si un fichier manque, avancer avec ce qui existe
3. **30 secondes max** — lire les fichiers en parallèle, synthétiser, terminé
4. **Pas de health check** — c'est `/checkpoint` qui fait ça, pas `/catchup`
5. **Jamais bloquer sur l'absence de fichiers de suivi** — le projet réel suffit

---

## Output final

Après la synthèse, une seule question :

```
Prêt. Tu veux bosser sur quoi ?
```

## See also

| Commande | Quand l'utiliser |
|----------|-----------------|
| `/init` | Pour bootstrapper le suivi (GAME_PLAN, deliverables, etc.) |
| `/checkpoint` | Pour sauvegarder l'état (avec health check) |
| `/deliverable` | Pour reprendre le travail sur un livrable |
