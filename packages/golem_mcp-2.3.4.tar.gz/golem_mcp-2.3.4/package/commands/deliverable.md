---
description: Focus work on completing a specific project deliverable
---
# /deliverable <nom> — Focus sur un livrable

> **Synonymes** : deliverable, livrable, feature, fonctionnalité, tâche, task, focus, implémenter, implement, construire, build

Tu es un développeur focalisé. Ton rôle : implémenter UN livrable jusqu'à complétion.

## Entrée

1. Lire `deliverables/{nom}.md`
2. Vérifier les dépendances (autres livrables requis)
3. Lire `references/index.md` pour appliquer les patterns

Si le livrable n'existe pas → proposer de le créer avec le template :

```markdown
# Livrable : {nom}

## Status
pending

## Description
{À remplir}

## Requirements
- [ ] {À définir}

## Acceptance Criteria
- [ ] {À définir}

## Dependencies
- None

## Files
- {À déterminer}
```

---

## Process

### 1. Afficher le brief

```
## Livrable : {nom}

Status: {status}
Dependencies: {liste ou "None"}

Golem Resources: {N skills, M recettes}
Pitfalls: {N warnings}
Assets: {N requis, M placeholders, P finals}

Requirements:
- [ ] {req1}
- [ ] {req2}

Acceptance Criteria:
- [ ] {crit1}
- [ ] {crit2}
```

### 1b. Pre-flight (STOP — bloquant)

Avant de coder quoi que ce soit :

**Si le livrable a une section "Golem Resources"** (format enrichi) :
1. Lire les sections Golem Resources et Pitfalls du livrable
2. Lire EN ENTIER chaque recette listée dans Golem Resources
3. Annoncer les recettes et pitfalls actifs :
   ```
   [RECIPE] recipes/xxx.md — pattern : {résumé en 1 ligne}
   [PITFALLS] {N} warnings actifs pour ce livrable
   ```

**Si le livrable est ancien format** (pas de Golem Resources) :
1. Déléguer au sub-agent `preflight-advisor` avec la description du livrable — il exécute le preflight, lit les recettes, et retourne un brief compact
2. **Enrichir le livrable** avec les résultats du brief (ajouter sections Golem Resources, Pitfalls, Assets) avant de continuer
3. Annoncer : `[ENRICHED] Livrable mis à jour avec {N} skills, {M} recettes, {P} pitfalls`

Si l'agent n'est pas disponible, exécuter manuellement : `python .claude/tools/preflight.py "DESCRIPTION_DU_LIVRABLE"`

Ne pas passer à l'étape suivante sans annonce `[RECIPE]`/`[NO RECIPE]` ou `[ENRICHED]`.

### 2. Vérifier les dépendances

Si des dépendances ne sont pas `completed` :
```
⚠ Dépendances non résolues :
- {livrable_dep} — status: {status}

Options :
1. Travailler d'abord sur {livrable_dep}
2. Ignorer et continuer (risqué)
```

### 3. Proposer le plan d'implémentation

Lister les étapes avec les skills à utiliser. **Chaque étape inclut la mécanique ET son juice** — pas de pass séparé.

Exemple gameplay :

| Étape | Skill | Description |
|-------|-------|-------------|
| 1 | `/godot-scene` | Scène + nodes + collisions |
| 2 | (code) | Mécanique core + VFX/SFX liés |
| 3 | `/godot-juice` | Screenshake, hitstop, polish feedback |
| 4 | `/godot-test` | Validation feeling via play + logs |

Exemple UI :

| Étape | Skill | Description |
|-------|-------|-------------|
| 1 | `/godot-composition` | Layout et structure |
| 2 | `/godot-scene` | Créer les composants |
| 3 | `/godot-behavior` | États, transitions, feedback |
| 4 | `/godot-theme` | Appliquer le style |

### 4. Implémenter step by step

Pour chaque étape :
1. **Exécuter** via MCP tools
2. **Vérifier** via screenshot ou scene tree
3. **Proposer référence** si pattern réutilisable détecté

### 4b. Review GDScript (optionnel)

Si des fichiers .gd ont été créés ou modifiés, déléguer au sub-agent `gdscript-reviewer` avec la liste des fichiers modifiés. Corriger les CRITICAL avant validation.

### 5. Valider les acceptance criteria

**Si une scène a été modifiée** → déléguer au sub-agent `scene-inspector` (foreground, besoin MCP) pour vérifier structure, propriétés, erreurs, et screenshot.

Cocher chaque critère avec preuve :
```
✓ Critère 1 — vérifié via screenshot
✓ Critère 2 — vérifié via inspect_node
✗ Critère 3 — en échec, raison: {x}
```

### 5b. Mettre à jour les assets

Après validation, mettre à jour les assets :
- Cocher les assets utilisés dans le livrable (`[x]`)
- Mettre à jour `deliverables/ASSETS.md` : passer les status de `needed` à `placeholder` ou `final`

### 6. Mettre à jour le livrable

Modifier `deliverables/{nom}.md` :
- `Status: completed`
- `Files:` liste des fichiers créés/modifiés
- Requirements cochés

### 7. Proposer checkpoint

```
Livrable {nom} terminé.

Fichiers modifiés :
- {liste}

Patterns détectés :
- {spacing_value} → ajouter aux références ?
- {color_value} → ajouter aux références ?

→ Lancer /checkpoint pour snapshot ?
→ Prochain livrable suggéré : {next}
```

---

## Règles strictes

1. **UN livrable à la fois** — pas de multi-tasking
2. **Pas de scope creep** — si nouveau besoin découvert, créer un nouveau livrable
3. **Références proposées, pas forcées** — l'utilisateur décide
4. **Preuves visuelles** — chaque acceptance criteria validé avec screenshot ou inspect
5. **État persisté** — toujours mettre à jour le fichier .md avant de terminer
6. **Le juice fait partie du livrable** — VFX, SFX, screenshake, particles liés à la mécanique sont implémentés DANS le même livrable, pas dans un pass séparé. Un dash sans implosion visuelle et crépitement sonore n'est pas terminé. Si le deliverable a une section "Feeling cible", le feeling doit être vérifiable à la fin
7. **Les modules sont portables** — si le deliverable liste des "Modules produits", chaque module doit être un script autonome avec config @export, communicant par signaux, sans dépendance hardcodée au jeu. Vérifier avant de marquer completed : le module pourrait-il être copié dans un autre projet et fonctionner ?
8. **Les pitfalls sont des warnings actifs** — les pitfalls listés dans la section Pitfalls du livrable sont des garde-fous à relire AVANT chaque étape de code. Si un pitfall concerne l'étape en cours, l'appliquer explicitement

---

## Gestion des blocages

Si bloqué pendant l'implémentation :

```
⚠ Blocage détecté

Problème : {description}
Tentatives : {ce qui a été essayé}

Options :
1. /godot-debug pour diagnostic
2. Créer un nouveau livrable pour résoudre le problème
3. Marquer comme bloqué et passer au suivant
```

Mettre à jour le livrable avec :
```markdown
## Blockers
- {description du blocage}
```

## See also

| Skill | Quand l'utiliser |
|-------|-----------------|
| `/checkpoint` | Sauvegarder l'état après avoir complété un livrable |
| `/references` | Consulter/ajouter des patterns pendant l'implémentation |
| `/godot-scene` | Si le livrable implique de construire une scène |
