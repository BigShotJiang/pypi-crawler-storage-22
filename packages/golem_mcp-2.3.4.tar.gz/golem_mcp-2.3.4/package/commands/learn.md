---
description: Synthesize errors and solutions from the current session into structured feedback
---
# /learn — Session Feedback

Tu es un extracteur de connaissances. Ton rôle : scanner la session en cours et produire un document structuré des erreurs, solutions, et découvertes.

## Quand utiliser

- En fin de session de game dev
- Après une session particulièrement riche en pièges/solutions
- Quand l'utilisateur veut capitaliser sur ce qu'on a appris

## Ce que /learn fait

1. Scanner la conversation pour extraire :
   - **Erreurs rencontrées** : tools MCP qui ont échoué, erreurs GDScript, bugs Godot
   - **Solutions qui ont marché** : et POURQUOI elles ont marché
   - **Nouveaux pièges** : non documentés dans `references/` ou les rules
   - **Candidats recette** : techniques qui méritent une recette dans `recipes/`
   - **Manques outils** : tools MCP manquants ou insuffisants
   - **Manques skills** : skills invoqués mais lacunaires

2. Écrire un fichier dans `learnings/`

## Format de sortie

```markdown
# Learning — {date} — {sujet}

## Erreurs & Solutions
| Erreur | Cause | Solution |
|--------|-------|----------|
| ... | ... | ... |

## Nouveaux pièges
- [PIEGE] Description — devrait aller dans `references/gdscript_pitfalls.md` section X
- [PIEGE] Description — devrait aller dans rules `mcp-pitfalls.md`

## Candidats recette
- [RECIPE] Technique X — testée, digne d'une recette dans `recipes/`

## Manques outils MCP
- [TOOL] Description du manque — obligé de passer par execute_script / workaround

## Manques / améliorations skills
- [SKILL] `skill.md` ne mentionne pas le pattern X
- [SKILL] `skill.md` devrait rappeler le piège Y

## Notes libres
- Observations ou suggestions hors catégories
```

## Règles

1. **Factuel** — ne documenter que ce qui a été réellement rencontré dans la session, pas des suppositions
2. **Actionnable** — chaque item pointe vers où il devrait aller (quel fichier, quelle section)
3. **Pas de modification** — /learn ne modifie PAS les references, skills, ou recipes du projet. Il produit un document pour un humain
4. **Pas de MEMORY.md** — /learn ne touche pas à la mémoire auto de Claude. C'est un système séparé
5. **Standalone** — /learn n'est pas invoqué par les autres commandes. C'est une action volontaire de l'utilisateur

## See also

| Commande | Quand l'utiliser |
|----------|-----------------|
| `/references` | Intégrer les patterns découverts dans des références réutilisables |
| `/deliverable` | Appliquer les learnings au prochain livrable |
