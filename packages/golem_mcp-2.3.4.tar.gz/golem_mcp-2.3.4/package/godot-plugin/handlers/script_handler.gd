@tool
extends Node

## Views, writes, executes, and attaches GDScript in the editor context.


func register(server: Node) -> void:
	server.register_handler("view_script", _view_script)
	server.register_handler("execute_script", _execute_script)
	server.register_handler("write_script", _write_script)
	server.register_handler("attach_script", _attach_script)
	server.register_handler("edit_script", _edit_script)


func _view_script(args: Dictionary) -> Dictionary:
	var script_path: String = args.get("path", "")
	if script_path.is_empty():
		return {"ok": false, "error": "Missing 'path' argument"}

	if not FileAccess.file_exists(script_path):
		return {"ok": false, "error": "Script not found: %s" % script_path}

	var file := FileAccess.open(script_path, FileAccess.READ)
	if file == null:
		return {"ok": false, "error": "Cannot open file: %s" % script_path}

	var content := file.get_as_text()
	file.close()
	return {"ok": true, "type": "text", "result": content}


func _execute_script(args: Dictionary) -> Dictionary:
	var code: String = args.get("code", "")
	if code.is_empty():
		return {"ok": false, "error": "Missing 'code' argument"}

	# Detect await — not supported in RefCounted context (no scene tree)
	if code.contains("await ") or code.contains("await\t") or code.contains("await("):
		return {"ok": false, "error": "execute_script does not support 'await'. Code runs inside a RefCounted (not in the scene tree). Use synchronous code only, or write an external .gd file with godot_write_script + godot_attach_script."}

	# Detect autoload references — execute_script runs in EDITOR context, not game
	var autoload_names := _get_project_autoloads()
	for aname in autoload_names:
		# Skip GolemCapture — it's an editor-side autoload
		if aname == "GolemCapture":
			continue
		# Check for direct usage patterns: AutoloadName.method(), AutoloadName.property
		if code.contains(aname + ".") or code.contains(aname + "["):
			return {"ok": false, "error": "execute_script runs in the EDITOR context, not the running game. '%s' is a game autoload and is not accessible here. To test autoloads, use play_scene + get_logs instead." % aname}

	var script := GDScript.new()
	script.source_code = """
extends RefCounted

func _run():
%s
""" % _indent_code(code)

	var err := script.reload()
	if err != OK:
		return {"ok": false, "error": "Script compilation failed (code %d). Common causes: syntax error, using Node-only APIs (get_tree, add_child), or complex expressions (arrays/loops). Simplify the code or use godot_write_script for complex logic." % err}

	var instance = script.new()
	if instance == null:
		return {"ok": false, "error": "Failed to instantiate script"}

	var result = instance._run()
	if result == null:
		return {"ok": true, "type": "text", "result": "Script executed (no return value)"}

	return {"ok": true, "type": "text", "result": str(result)}


func _write_script(args: Dictionary) -> Dictionary:
	var script_path: String = args.get("path", "")
	var content: String = args.get("content", "")

	if script_path.is_empty():
		return {"ok": false, "error": "Missing 'path' argument"}
	if content.is_empty():
		return {"ok": false, "error": "Missing 'content' argument"}

	# Ensure path starts with res://
	if not script_path.begins_with("res://"):
		script_path = "res://" + script_path

	# Create directories if needed
	var dir_path := script_path.get_base_dir()
	if not DirAccess.dir_exists_absolute(dir_path):
		var err := DirAccess.make_dir_recursive_absolute(dir_path)
		if err != OK:
			return {"ok": false, "error": "Cannot create directory: %s (error %d)" % [dir_path, err]}

	var file := FileAccess.open(script_path, FileAccess.WRITE)
	if file == null:
		return {"ok": false, "error": "Cannot write to: %s (error %d)" % [script_path, FileAccess.get_open_error()]}

	file.store_string(content)
	file.close()

	# Tell the editor to reimport/rescan
	EditorInterface.get_resource_filesystem().scan()

	return {"ok": true, "type": "text", "result": "Script written: %s" % script_path}


func _attach_script(args: Dictionary) -> Dictionary:
	var node_path: String = args.get("node", "")
	var script_path: String = args.get("script", "")

	if node_path.is_empty() or script_path.is_empty():
		return {"ok": false, "error": "Missing 'node' or 'script' argument"}

	if not script_path.begins_with("res://"):
		script_path = "res://" + script_path

	var root := EditorInterface.get_edited_scene_root()
	if root == null:
		return {"ok": false, "error": "No scene open"}

	var target: Node
	if node_path == "." or node_path.is_empty():
		target = root
	else:
		target = root.get_node_or_null(node_path)
	if target == null:
		return {"ok": false, "error": "Node not found: %s" % node_path}

	if not FileAccess.file_exists(script_path):
		return {"ok": false, "error": "Script file not found: %s" % script_path}

	var script := load(script_path) as Script
	if script == null:
		return {"ok": false, "error": "Failed to load script: %s" % script_path}

	target.set_script(script)
	return {"ok": true, "type": "text", "result": "Attached %s to %s" % [script_path, target.name]}


func _get_project_autoloads() -> PackedStringArray:
	var names: PackedStringArray = []
	for prop in ProjectSettings.get_property_list():
		var pname: String = prop["name"]
		if pname.begins_with("autoload/"):
			names.append(pname.get_slice("/", 1))
	return names


func _indent_code(code: String) -> String:
	var lines := code.split("\n")
	var indented: PackedStringArray = []
	for line in lines:
		indented.append("\t" + line)
	return "\n".join(indented)


# ------------------------------------------------------------------
# Edit script — find-and-replace in a script file
# ------------------------------------------------------------------

func _edit_script(args: Dictionary) -> Dictionary:
	var script_path: String = args.get("path", "")
	var old_text: String = args.get("old_text", "")
	var new_text: String = args.get("new_text", "")
	var replace_all: bool = args.get("replace_all", false)

	if script_path.is_empty() or old_text.is_empty():
		return {"ok": false, "error": "Missing 'path' or 'old_text' argument"}

	if not script_path.begins_with("res://"):
		script_path = "res://" + script_path

	if not FileAccess.file_exists(script_path):
		return {"ok": false, "error": "File not found: %s" % script_path}

	var file := FileAccess.open(script_path, FileAccess.READ)
	if file == null:
		return {"ok": false, "error": "Cannot open file: %s" % script_path}
	var content := file.get_as_text()
	file.close()

	var count := content.count(old_text)
	if count == 0:
		return {"ok": false, "error": "Text not found in %s" % script_path}

	if not replace_all and count > 1:
		return {"ok": false, "error": "Ambiguous: found %d occurrences of old_text in %s — use replace_all=true or provide more context" % [count, script_path]}

	var new_content: String
	if replace_all:
		new_content = content.replace(old_text, new_text)
	else:
		var pos := content.find(old_text)
		new_content = content.substr(0, pos) + new_text + content.substr(pos + old_text.length())

	var write_file := FileAccess.open(script_path, FileAccess.WRITE)
	if write_file == null:
		return {"ok": false, "error": "Cannot write to: %s (error %d)" % [script_path, FileAccess.get_open_error()]}
	write_file.store_string(new_content)
	write_file.close()

	EditorInterface.get_resource_filesystem().scan()

	var replaced := count if replace_all else 1
	return {"ok": true, "type": "text", "result": "Edited %s — replaced %d occurrence(s)" % [script_path, replaced]}
