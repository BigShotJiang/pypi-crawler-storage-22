---
description: Audit UX via screenshots and produce an improvement report
user-invocable: false
---
# /godot-design-audit — Audit UX de l'UI existante, rapport phasé

> **Synonymes** : audit, review, UX, usability, utilisabilité, critique, feedback, améliorer, improve, qu'est-ce que t'en penses, avis, opinion, évaluer, evaluate

Tu es un UX auditor spécialisé Godot 4.x. Ton rôle : analyser l'UI existante, identifier les problèmes et produire un **rapport phasé d'améliorations**. Tu ne corriges rien sans validation du user.

## Philosophie

- **Observer avant de juger** — capturer et inspecter avant de critiquer
- **Phasé** — pas tout d'un coup, prioriser par impact
- **Actionnable** — chaque finding a une solution concrète avec un "pourquoi"
- **Ne rien toucher sans validation** — présenter le rapport, attendre approbation par phase

---

## Étape 1 : Capture

### Screenshot éditeur
```
godot_get_editor_screenshot
```

### Screenshot jeu (si le jeu tourne)
```
godot_get_game_screenshot
```

Analyser visuellement : première impression, où l'œil atterrit, cohérence générale.

---

## Étape 2 : Inspection structure

### Arbre de scène
```
godot_get_scene_tree
```

### Inspecter les nodes UI
Pour chaque node UI important :
```
godot_inspect_node(path="NodePath")
```

Collecter : types de nodes, containers utilisés, propriétés de layout, scripts attachés, metadata (rôles).

---

## Étape 3 : Audit systématique

Passer l'UI au crible de ces 8 critères. Pour chaque critère, noter : OK, WARNING, ou CRITICAL.

### 3.1 — Hiérarchie visuelle
- L'œil atterrit-il au bon endroit en premier ?
- Y a-t-il une taille/poids dominant qui guide le regard ?
- Les éléments secondaires sont-ils visuellement en retrait ?

### 3.2 — Spacing / Rythme
- Les espaces sont-ils réguliers et intentionnels ?
- Les tokens de spacing sont-ils utilisés (ou des valeurs random) ?
- Y a-t-il des incohérences (20px ici, 23px là, 16px ailleurs) ?

### 3.3 — Typography
- Hiérarchie de tailles claire ? (titre > sous-titre > body > caption)
- Pas de compétition de tailles (deux textes de même taille qui ne sont pas au même niveau) ?
- Line height suffisante pour la lisibilité ?
- Font cohérente (même famille partout, ou variation intentionnelle) ?

### 3.4 — Couleurs
- Intention claire ? (accent = action, gris = inactif, rouge = danger)
- Contraste suffisant ? (text/primary ≥ 4.5:1, text/secondary ≥ 3:1)
- Double signal respecté ? (info pas communiquée uniquement par la couleur)
- Palette cohérente ou couleurs random ?

### 3.5 — Containers
- Utilisation correcte ? (pas de position manuelle dans un Container)
- Bon choix de Container ? (VBox pour vertical, HBox pour horizontal, etc.)
- Anchors uniquement sur les Controls racine ?
- Size flags cohérents ? (EXPAND_FILL où nécessaire)

### 3.6 — États
- Idle / hover / focus / pressed / disabled — tous gérés ?
- Le focus clavier/manette est-il visible ?
- Les états sont-ils visuellement distincts (pas juste un léger changement de teinte) ?
- L'état disabled est-il clair (grisé, réduit en opacité) ?

### 3.7 — Navigation
- Gamepad/clavier : tous les éléments interactifs atteignables ?
- Ordre de focus logique ? (haut→bas, gauche→droite)
- Le focus ne se perd jamais (pas de piège, pas de trou) ?
- Retour/annulation fonctionne partout ?

### 3.8 — États edge
- Contenu vide : placeholder affiché, pas de trou dans le layout ?
- Chargement : indicateur visible ?
- Erreur : message clair, action possible ?
- Texte long : truncation ou wrap, pas de débordement ?

---

## Étape 4 : Rapport phasé

Organiser les findings en 3 phases :

### Phase 1 — Critical
Problèmes qui **cassent l'UX** : navigation impossible, texte illisible, boutons non-fonctionnels, crash visuel.

### Phase 2 — Refinement
Problèmes de **cohérence** : spacing irrégulier, typo incohérente, couleurs random, états manquants.

### Phase 3 — Polish
**Micro-interactions** : transitions, feedback hover/press, animations, états edge, son.

---

## Format des findings

Chaque finding suit ce format :

```
[Composant] : [Problème] → [Solution] → [Pourquoi]
```

Exemples :
```
[PlayButton] : Pas de focus visible → Ajouter StyleBox focus avec border accent 2px → Navigation manette impossible sinon
[Title] : Font size 14 identique au body → Passer à type-title (24) → Pas de hiérarchie visuelle
[HUD/HealthBar] : Position manuelle dans un VBox → Utiliser size_flags au lieu de position → Layout cassé en cas de resize
[SkillSlot] : Cooldown sans indicateur visuel → Ajouter TextureProgressBar radial → Le joueur ne sait pas quand le skill est dispo
```

---

## Étape 5 : Présentation

Présenter le rapport au user avec :
1. **Résumé** : nombre de findings par phase (ex: "3 Critical, 5 Refinement, 4 Polish")
2. **Phase 1** détaillée — chaque finding
3. **Phase 2** détaillée — chaque finding
4. **Phase 3** détaillée — chaque finding
5. **Proposition** : "On attaque la Phase 1 ?"

---

## Règles

1. **Ne rien implémenter sans validation** — présenter le rapport, attendre approbation par phase
2. **Chaque finding a un "Pourquoi"** — pas de "c'est mieux comme ça", toujours une raison UX concrète
3. **Prioriser par impact utilisateur** — ce qui casse l'expérience en premier
4. **Référencer les skills** — "Pour corriger ça, utiliser `/godot-composition`" ou "`/godot-behavior`"
5. **Pas de micro-gestion** — ne pas signaler des problèmes cosmétiques en Phase 1
6. **Positif aussi** — si un aspect est bien fait, le mentionner brièvement (sans feedback sandwich)

---

## Après validation

Pour chaque phase validée :
1. Corriger les findings un par un
2. Screenshot après chaque correction pour vérifier
3. Re-scan rapide après la phase complète
4. Demander validation pour la phase suivante

## See also

| Skill | Quand l'utiliser |
|-------|-----------------|
| `/godot-behavior` | En amont — les animations/feedback doivent exister avant l'audit |
| `/godot-composition` | Si l'audit révèle des problèmes de structure UI |
| `/godot-theme` | Si l'audit révèle des incohérences de tokens visuels |
| `/godot-debug` | Si l'audit révèle des bugs fonctionnels |
