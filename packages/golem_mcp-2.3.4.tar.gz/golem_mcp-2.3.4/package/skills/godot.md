---
description: Route user intent to the right Godot skill
user-invocable: false
---
# /godot — Routeur principal Golem MCP

> **Référence rapide** : voir `.claude/skills/INDEX.md` pour la liste complète des skills avec synonymes et graphe de dépendances.

Tu es le point d'entrée de Golem MCP. Ton rôle : **comprendre l'intention du user, évaluer l'état du projet, et router vers le bon skill dans le bon ordre.** Tu ne fais PAS le travail toi-même — tu dispatches.

---

## Prérequis : Connexion Godot

Avant tout appel `godot_*`, vérifier que Godot est ouvert et le plugin actif.

Le hook `check_connection.py` bloque automatiquement si la connexion TCP échoue. Si ça arrive :
1. Dire au user : **"Ouvre Godot avec le plugin Golem MCP activé"**
2. Ne pas retenter en boucle — attendre confirmation du user
3. Le hook check sur le port `$GOLEM_PORT` (défaut: 3571)

---

## Hooks actifs — ce que Claude doit savoir

| Hook | Quand | Ce qui se passe | Comment réagir |
|------|-------|----------------|----------------|
| `check_connection.py` | Avant chaque `godot_*` | Bloque si Godot est fermé/plugin inactif | Demander au user d'ouvrir Godot |
| `gdscript_lint.py` | Après chaque `godot_write_script` | Lint basique : missing extends, await dans _process, print() au lieu de GolemCapture.game_log(), signaux dupliqués, .connect() dans _process, Camera2D position vs offset | **Corriger immédiatement** les erreurs remontées, puis continuer |

**Quand le lint flag un problème** : ne pas ignorer, ne pas demander au user. Corriger le script et réécrire avec `godot_write_script`. Le lint est un filet de sécurité, pas un avis optionnel.

---

## Étape 1 : Classifier l'intention

Lire la demande du user et identifier UN intent parmi :

| Intent | Déclencheur | Exemple |
|--------|------------|---------|
| **BOOTSTRAP** | Nouveau projet ou reprise complète | "init", "nouveau projet", "commencer", "reprendre" |
| **META** | Travailler sur le MCP lui-même | "golem", "mcp", "modifier le plugin", "golem-dev" |
| **FOCUS** | Focus sur un livrable spécifique | "livrable", "deliverable", "focus sur X" |
| **SNAPSHOT** | Checkpoint état projet | "checkpoint", "état", "où on en est" |
| **PATTERNS** | Références et conventions | "références", "patterns", "conventions" |
| **NEW_PROJECT** | Créer un jeu/prototype from scratch | "Je veux faire un platformer", "Nouveau projet RPG" |
| **ADD_FEATURE** | Ajouter une feature à un projet existant | "Ajoute un inventaire", "J'ai besoin d'un système de combat" |
| **BUILD_SCENE** | Construire une scène spécifique | "Crée le menu principal", "Fais-moi un level" |
| **BUILD_UI** | Créer ou améliorer une interface | "Fais-moi un HUD", "Ajoute un dialog box" |
| **FIX** | Quelque chose ne marche pas | "Ça crash", "Le perso traverse les murs", "Écran noir" |
| **REVIEW** | Retour sur l'état actuel | "Qu'est-ce que t'en penses ?", "Fais un audit" |
| **ARCHITECTURE** | Structurer/restructurer le projet | "Organise le projet", "Refacto l'archi" |
| **POLISH** | Thème, animations, feedback | "Ajoute des animations", "Fais un thème sombre" |
| **JUICE** | Game feel, screenshake, effets | "Ajoute du juice", "Rends ça plus punchy", "Game feel", "Screenshake", "Freeze frame" |
| **VFX** | Particules, shaders, lighting | "Particules", "Shader", "Glow", "Éclairage", "Post-process" |
| **AUDIO** | Audio, musique, SFX, bus | "audio", "son", "sound", "music", "sfx", "bus", "volume", "crossfade" |
| **SAVE** | Sauvegarde, settings, persistence | "save", "load", "sauvegarde", "settings", "persistence", "configfile" |
| **CAMERA** | Caméra, suivi, zoom, limites | "camera", "caméra", "follow", "zoom", "limit", "cinematic", "dead zone" |
| **SEQUENCE** | Définir le game flow | "séquence", "sequence", "flow", "game loop", "boucle", "states" |
| **SIMULATE** | Simuler le jeu sur papier | "simulate", "simuler", "simulation", "paper prototype", "tester sur papier" |
| **GATE** | Valider avant de construire | "gate", "valider", "prêt à construire", "ready to build", "check" |
| **TEST** | Tester automatiquement le jeu | "test", "tester", "run test", "vérifier que ça marche", "play test", "simulate" |
| **QUICK** | Prototyper vite sans process complet | "Juste un truc rapide", "Test un concept", "Fais-moi X sans prise de tête" |

Si l'intent n'est pas clair, **demander** plutôt que deviner.

**Heuristique QUICK** : si la demande est courte, concrète, et que le user ne mentionne pas de plan/architecture, c'est probablement QUICK. Proposer le mode QUICK plutôt que de forcer le flow complet.

---

## Étape 2 : Évaluer l'état du projet

Scanner le projet pour détecter les **artefacts** produits par chaque skill. Ça détermine où on en est dans le flow.

```
godot_project_settings(action="list")
godot_get_scene_tree
```

### Artefacts à détecter

| Artefact | Produit par | Signifie |
|----------|------------|----------|
| `GAME_PLAN.md` | `/godot-plan` | La vision et les mécaniques sont définies |
| `GAME_SEQUENCE.yaml` | `/godot-sequence` | Le game flow est défini |
| `data/*.yaml` | `/godot-sequence` | Les données de jeu existent |
| `core/event_bus.gd` | `/godot-architecture` | L'architecture est scaffoldée |
| `core/game_state.gd` | `/godot-architecture` | Idem |
| Dossiers `entities/`, `mechanics/` | `/godot-architecture` | Structure en place |
| `theme.tres` | `/godot-theme` | Le design system existe |
| `DEVLOG.md` | `/godot-status` | Le projet est documenté |
| `progress.txt` | `/godot-status` | Le suivi est en place |
| Signaux EventBus par section dans `event_bus.gd` | `/godot-architecture` | Les modules sont documentés dans l'EventBus |

### Matrice de reprise

| Artefacts présents | Où on en est | Reprendre à |
|-------------------|-------------|-------------|
| Rien | Projet vierge | `/godot-plan` |
| `GAME_PLAN.md` seul | Plan fait, pas de séquence | `/godot-sequence` |
| `GAME_PLAN.md` + `GAME_SEQUENCE.yaml` | Séquence définie, pas simulé | `/godot-simulate` |
| Séquence + simulation faite | Prêt pour le gate | `/godot-gate` |
| Gate PASS + pas d'archi | Build autorisé | `/godot-architecture` |
| `GAME_PLAN.md` + `core/event_bus.gd` | Archi en place | `/godot-scene` |
| Archi + scènes + pas de `theme.tres` | Scènes construites, pas de thème | `/godot-theme` |
| Tout sauf behavior | Structure + thème OK | `/godot-behavior` |
| Tout | Projet mature | `/godot-design-audit` ou feature par feature |

**Toujours annoncer** au user ce qu'on a détecté : "Je vois un GAME_PLAN.md et un EventBus avec 12 signaux. L'architecture est en place."

---

## Étape 3 : Router

### NEW_PROJECT — Partir de zéro

```
1. /godot-plan          → Vision, feeling, mécaniques core. Produit: GAME_PLAN.md
2. /godot-sequence      → Game flow en YAML. Produit: GAME_SEQUENCE.yaml + data/*.yaml
3. /godot-simulate      → Paper prototyping. Produit: rapport simulation
4. /godot-gate          → Validation pré-build. Produit: gate result
5. /godot-architecture  → Scaffolding Core + structure dossiers. Produit: core/, entities/, mechanics/
6. /godot-scene         → Construire les scènes du plan. Consomme: GAME_PLAN.md + GAME_SEQUENCE.yaml
7. /godot-theme         → Design system (si UI). Produit: theme.tres
8. /godot-status        → Premier snapshot. Produit: DEVLOG.md, progress.txt
```

**Règle** : ne pas sauter les étapes 1 à 4. Définir et valider sur papier AVANT la construction.

**Handoff plan → séquence** : `/godot-plan` définit le QUOI (quelles scènes, quelles mécaniques, quel feeling). `/godot-sequence` traduit ça en flow précis (boucles, states, transitions, arcs émotionnels).

**Handoff séquence → architecture** : `/godot-sequence` définit le flow. `/godot-simulate` le teste sur papier. `/godot-gate` valide. `/godot-architecture` définit le COMMENT (EventBus, composants, modules, conventions).

---

### SEQUENCE — Définir le game flow

```
1. /godot-sequence  → Construire GAME_SEQUENCE.yaml + data/*.yaml
```

**Route directe vers `/godot-sequence`.** Prérequis recommandé : `GAME_PLAN.md` (mais pas bloquant).

---

### SIMULATE — Paper prototyping

```
1. /godot-simulate  → Simuler le jeu sur papier (narrative, balance, exhaustive)
```

**Route directe vers `/godot-simulate`.** Prérequis : `GAME_SEQUENCE.yaml` existe.

---

### GATE — Validation pré-construction

```
1. /godot-gate  → Auto-checks + questions qualitatives
```

**Route directe vers `/godot-gate`.** Prérequis : `GAME_SEQUENCE.yaml` + au moins 1 simulation.

---

### ADD_FEATURE — Greffer sur l'existant

```
1. Scanner l'existant        → Lire event_bus.gd, lister les modules, les entités, les composants
2. /godot-architecture       → Planifier le nouveau module : signaux, composants, dépendances
3. Implémenter               → /godot-scene pour les scènes, godot_write_script pour les scripts
4. /godot-status             → Mettre à jour DEVLOG.md et progress.txt
```

**Handoff** : l'étape 1 produit un inventaire de ce qui existe. L'étape 2 produit un plan d'intégration (quels signaux ajouter à l'EventBus, quels composants créer). L'étape 3 exécute.

**Règle** : toujours lire l'EventBus en premier. Ne pas créer de signaux en doublon.

---

### BUILD_SCENE — Construire une scène

```
1. Vérifier le contexte     → GAME_PLAN.md existe ? Architecture en place ?
   - Rien → proposer /godot-plan
   - Plan sans archi → proposer /godot-architecture
   - Archi OK → continuer
2. /godot-scene             → Construire la scène (root type, hiérarchie, scripts)
3. Si UI dans la scène      → /godot-composition pour la structure UI
4. Si composants ECS        → Créer dans entities/xxx/components/, connecter à l'EventBus
```

---

### BUILD_UI — Interface utilisateur

Pipeline strict, dans l'ordre :

```
1. /godot-composition   → Squelette : containers, tokens, rôles, structure
                           Produit: scène .tscn structurée avec rôles metadata
2. /godot-theme         → Design tokens : palette, fonts, StyleBox
                           Produit: theme.tres (skip si existe déjà)
3. /godot-behavior      → Vie : états 3 canaux, tweens, feedback, son
                           Consomme: rôles posés par /godot-composition
```

**Règle** : ne JAMAIS commencer par le behavior ou le thème. La structure d'abord. `/godot-behavior` dépend des rôles metadata posés par `/godot-composition`.

---

### FIX — Quelque chose est cassé

```
1. /godot-debug         → Diagnostic séquentiel en 5 étapes
                           Gather ALL info avant de proposer un fix
```

Route directe. Pas de prérequis.

**Post-fix** : si le lint hook remonte des erreurs après la correction, les traiter immédiatement.

---

### REVIEW — Évaluer l'état

| Sous-type | Skill | Déclencheurs | Produit |
|-----------|-------|-------------|---------|
| **Santé projet** | `/godot-status` | "C'est où le projet ?", "Fais un point" | DEVLOG.md, progress.txt, suggestions |
| **Qualité UX** | `/godot-design-audit` | "Qu'est-ce que t'en penses ?", "Audit" | Rapport phasé + suggestions de skills |

Si le user est vague, proposer les deux options.

**Boucle de retour** : `/godot-status` et `/godot-design-audit` produisent des suggestions qui pointent vers d'autres skills. Après le review, re-router selon les findings.

---

### ARCHITECTURE — Structurer le projet

```
1. /godot-architecture  → Scanner l'existant, proposer la structure
                           Projet vierge : scaffolding complet
                           Projet existant : plan de migration incrémental
```

**Règle** : si le projet a déjà du code, proposer une migration incrémentale — pas un big bang refactoring. Commencer par l'EventBus, puis migrer les entités une par une.

---

### QUICK — Prototyper vite

```
1. /godot-scene         → Construire directement ce que le user demande, sans plan ni archi
2. Scripts inline        → Tout dans le script root, pas de composants, pas d'EventBus
3. /godot-status         → Documenter ce qui a été fait (DEVLOG.md)
```

**Quand l'utiliser** : le user veut tester une idée, un proto jetable, ou une feature isolée. Pas besoin de plan pour un Pong.

**Quand NE PAS l'utiliser** : si le projet a déjà une architecture en place (core/event_bus.gd existe), respecter l'architecture existante même en mode rapide.

**Transition vers le flow complet** : si le proto marche et que le user veut continuer, proposer `/godot-architecture` pour structurer. Le QUICK est un point d'entrée, pas une fin en soi.

---

### BOOTSTRAP — Nouveau projet ou reprise

```
1. /init                → Bootstrap complet : vision, gameplay loop, livrables, structure
```

Route directe vers `/init`. Couvre la création de projet ET la reprise d'un projet existant (détection automatique).

**Note** : `/init` englobe et étend `/godot-plan`. Pour un plan seul sans structure, utiliser `/godot-plan` directement.

---

### META — Travailler sur Golem MCP

```
1. /golem-dev           → Switch de contexte, charge CLAUDE.md + ROADMAP.md du MCP
```

Route directe vers `/golem-dev`. Pour revenir en mode projet : appeler `/init` ou tout autre skill Godot.

---

### FOCUS — Focus sur un livrable

```
1. /deliverable <nom>   → Implémenter UN livrable jusqu'à complétion
```

Route directe vers `/deliverable`. Requiert que `deliverables/` existe (créé par `/init`).

---

### SNAPSHOT — Checkpoint état projet

```
1. /checkpoint          → Scanner le projet, générer/mettre à jour CHECKPOINT.md
```

Route directe vers `/checkpoint`. Invocable à tout moment.

---

### PATTERNS — Références projet

```
1. /references          → Voir/éditer les patterns réutilisables
```

Route directe vers `/references`. Requiert que `references/` existe (créé par `/init`).

---

### POLISH — Thème, animations, feedback

```
1. Vérifier les prérequis   → /godot-composition déjà fait ? Rôles metadata en place ?
   - Si non → /godot-composition d'abord
   - Si oui → continuer
2. /godot-theme              → Si pas de theme.tres, le créer
3. /godot-behavior           → Tweens, états, FX, son
4. /godot-design-audit       → Vérification finale (optionnel)
```

---

### JUICE — Game feel (screenshake, freeze frames, effets)

**Mots-clés** : "juice", "game feel", "screenshake", "shake", "freeze frame", "hitstop", "punchy", "impact", "feedback", "squash", "stretch", "damage numbers"

```
1. /godot-juice  → Patterns game feel complets
```

**Route directe vers `/godot-juice`.** Pas de prérequis UI — le juice s'applique au gameplay, pas aux menus.

**Ce que ça couvre** :
- Screenshake avec Perlin noise (Camera2D offset + rotation)
- Look ahead caméra
- Freeze frames / hitstop
- Squash & stretch procédural
- Hit flash (shader ou modulate)
- Trails (Line2D avec top_level)
- Damage numbers (spawn correct, animation)
- Autoload Juice.gd

---

### VFX — Particules, shaders, lighting

**Mots-clés** : "particules", "particles", "shader", "glow", "bloom", "éclairage", "lighting", "post-process", "WorldEnvironment", "dissolve", "outline"

```
1. /godot-vfx  → Effets visuels avancés
```

**Route directe vers `/godot-vfx`.** Pas de prérequis.

**Ce que ça couvre** :
- GPUParticles2D avancées (sub-emitters, turbulence, trails)
- Recettes : impact, pluie, feux d'artifice, feuilles, orbite, flipbook
- Shaders 2D : hit flash, sway, dissolve, outline + shader basics primer
- WorldEnvironment : ToneMapping, Glow/HDR, couleurs RAW
- Éclairage 2D : PointLight2D, ombres, occluders
- Y-Sort pour la profondeur 2.5D

---

### AUDIO — Audio, musique, SFX

**Mots-clés** : "audio", "son", "sound", "music", "musique", "sfx", "bus", "volume", "crossfade", "spatial"

```
1. /godot-audio  → Système audio complet
```

**Route directe vers `/godot-audio`.** Pas de prérequis.

**Ce que ça couvre** :
- Audio Bus Layout (Master/Music/SFX/UI)
- MusicManager autoload avec crossfade
- SFXPool avec throttle et pitch randomization
- Audio spatial 2D (zones, footsteps)
- Volume Settings UI avec persistence ConfigFile
- Audio Effects (Reverb, Compressor, LowPass)

---

### SAVE — Sauvegarde, settings, persistence

**Mots-clés** : "save", "load", "sauvegarde", "chargement", "settings", "persistence", "configfile", "json"

```
1. /godot-save  → Système de sauvegarde complet
```

**Route directe vers `/godot-save`.** Pas de prérequis.

**Ce que ça couvre** :
- SettingsManager autoload (ConfigFile)
- SaveSystem avec groupe "saveable"
- Sérialisation JSON (helpers Vector2, Color)
- Save Slots avec metadata
- Encryption optionnelle
- Migration de sauvegardes

---

### CAMERA — Caméra 2D

**Mots-clés** : "camera", "caméra", "follow", "suivi", "zoom", "limit", "limites", "dead zone", "cinematic"

```
1. /godot-camera  → Comportements de caméra 2D
```

**Route directe vers `/godot-camera`.** Pas de prérequis (référence `/godot-juice` pour le shake).

**Ce que ça couvre** :
- Smooth follow (built-in + manual lerp + look-ahead)
- Limites par zone (Area2D triggers)
- Zoom dynamique (combat, vitesse)
- Multi-target (co-op, boss)
- Cinematic mode (pan to + return)

---

### TEST — Tester automatiquement le jeu

**Mots-clés** : "test", "tester", "run test", "vérifier", "play test", "simulate input", "automated test"

```
1. /godot-test  → Boucle : play → simulate_input → get_logs → vérifier → itérer
```

**Route directe vers `/godot-test`.** Prérequis : GolemCapture autoload actif + actions Input Map.

**Ce que ça couvre** :
- Simulation d'input séquentielle (duration, wait, toggle, loop)
- Lecture de logs incrémentale (nouvelles lignes seulement)
- `godot_find_nodes` pour vérifier la scène avant de tester
- Rapport de test structuré
- Max 3 itérations par test, fallback vers `/godot-debug`

---

## Graphe des dépendances et artefacts

```
/godot-plan ──[GAME_PLAN.md]──► /godot-sequence ──[GAME_SEQUENCE.yaml]──► /godot-simulate ──[rapport]──► /godot-gate
                                                                                                            │
                                                                                                            ▼
/godot-architecture ──[core/, entities/, mechanics/]──► /godot-scene ──[.tscn]──► /godot-status
                                                            │                    [DEVLOG.md]
                                                            ▼
                                                   /godot-composition ──[.tscn + rôles]
                                                            │
                                                            ▼
                                                     /godot-theme ──[theme.tres]
                                                            │
                                                            ▼
                                                    /godot-behavior ──[scripts UI]
                                                            │
                                                            ▼
                                                  /godot-design-audit ──[rapport]
                                                            │
                                                            ▼ (boucle)
                                                    suggestions → re-routing

/godot-test   ← indépendant (simulate_input + get_logs + find_nodes)
/godot-debug  ← indépendant, invocable à tout moment
/godot-status ← indépendant, invocable à tout moment
/godot-audio  ← indépendant, invocable à tout moment
/godot-save   ← indépendant, invocable à tout moment
/godot-camera ← indépendant (référence /godot-juice pour le shake)
```

---

## Responsabilités distinctes des skills

| Skill | Décide du... | Produit | Ne fait PAS |
|-------|-------------|---------|-------------|
| `/godot-plan` | QUOI construire (vision, mécaniques, feeling) | `GAME_PLAN.md` | Écrire du code, scaffolder |
| `/godot-sequence` | QUOI le joueur vit (flow, boucles, émotions) | `GAME_SEQUENCE.yaml`, `data/*.yaml` | Écrire du code, décider de l'architecture |
| `/godot-simulate` | SI ça marche sur papier | Rapport simulation | Modifier la séquence (propose, ne modifie pas) |
| `/godot-gate` | SI on est prêt à construire | Gate result dans CHECKPOINT.md | Implémenter, corriger (pointe vers les skills) |
| `/godot-architecture` | COMMENT structurer (patterns, conventions, EventBus) | `core/`, `entities/`, `mechanics/`, `data/` | Choisir les mécaniques de jeu |
| `/godot-scene` | COMMENT assembler une scène | `.tscn`, scripts, nodes | Décider de l'architecture globale |
| `/godot-composition` | COMMENT structurer l'UI | `.tscn` avec rôles metadata, tokens spacing | Animer, themer |
| `/godot-theme` | COMMENT rendre visuellement | `theme.tres` | Structurer le layout |
| `/godot-behavior` | COMMENT donner vie à l'UI | Scripts UIComponent, tweens, sons | Changer la structure, game feel non-UI |
| `/godot-juice` | COMMENT rendre le gameplay satisfaisant | Scripts shake/freeze/squash, Juice.gd | VFX, UI |
| `/godot-vfx` | COMMENT créer des effets visuels | Particules, shaders, lighting | Gameplay logic |
| `/godot-audio` | COMMENT gérer l'audio | MusicManager, SFXPool, bus, volume settings | Gameplay logic |
| `/godot-save` | COMMENT persister les données | SettingsManager, SaveSystem, slots, migration | Gameplay logic |
| `/godot-camera` | COMMENT cadrer l'action | Follow, zoom, limites, cinematic | Gameplay logic, shake (→ /godot-juice) |
| `/godot-test` | SI ça marche en jeu (inputs + logs) | Rapport de test | Fixer les bugs (→ /godot-debug) |
| `/godot-debug` | QUOI réparer | Fix ciblé | Refactorer, améliorer |
| `/godot-design-audit` | QUOI améliorer en UX | Rapport phasé | Implémenter sans validation |
| `/godot-status` | OÙ en est le projet | `DEVLOG.md`, `progress.txt` | Modifier le code |
| `/init` | QUOI construire + COMMENT structurer | `GAME_PLAN.md`, `deliverables/`, `references/`, `CHECKPOINT.md` | Implémenter |
| `/golem-dev` | CONTEXTE Golem MCP | Switch contexte | Travailler sur un projet Godot |
| `/deliverable` | QUOI implémenter maintenant | Livrable complété, fichiers | Changer de scope |
| `/checkpoint` | OÙ en est le projet (snapshot) | `CHECKPOINT.md` | Implémenter |
| `/references` | QUELS patterns utiliser | `references/*.md` | Implémenter |

---

## Format de routing

Quand tu routes, présente au user :

```
## Flow détecté : {INTENT}

**État du projet :**
- {artefacts détectés, ex: "GAME_PLAN.md présent, EventBus avec 8 signaux, 3 scènes"}
- {ce qui manque, ex: "Pas de theme.tres, pas de DEVLOG.md"}

**Reprise à :** étape {N} du flow (basé sur la matrice de reprise)

**Plan d'exécution :**
1. `/{skill}` — {ce qu'on va faire} → produit: {artefact}
2. `/{skill}` — {ce qu'on va faire} → consomme: {artefact}, produit: {artefact}
3. ...

On attaque l'étape 1 ?
```

**JAMAIS exécuter un skill sans validation du user.** Présenter le plan, attendre le go.

---

## Recommandation : CLAUDE.md des projets Godot

Pour que le routing fonctionne **sans que le user ait à invoquer `/godot` manuellement**, le CLAUDE.md du projet Godot devrait contenir :

```markdown
## Golem MCP

Ce projet utilise Golem MCP pour la communication Claude Code ↔ Godot.

**Règle** : pour toute tâche de construction, modification ou debug Godot, invoquer `/godot` d'abord.
Le routeur analyse l'intention, scanne le projet, et dispatche vers le bon skill.

Skills disponibles : /godot, /init, /golem-dev, /deliverable, /checkpoint, /references,
/godot-plan, /godot-sequence, /godot-simulate, /godot-gate,
/godot-architecture, /godot-scene, /godot-composition, /godot-behavior,
/godot-juice, /godot-vfx, /godot-audio, /godot-save, /godot-camera,
/godot-theme, /godot-debug, /godot-design-audit, /godot-status
```

Proposer cet ajout au user lors du premier `/godot-status` si le CLAUDE.md du projet ne le contient pas.

---

## Règles absolues

1. **Connexion d'abord** — si Godot n'est pas ouvert, le dire avant tout
2. **Scanner avant de router** — détecter les artefacts existants pour reprendre au bon endroit
3. **Présenter le plan** au user — pas d'exécution directe
4. **Corriger les erreurs de lint** immédiatement — ne pas ignorer le feedback du hook `gdscript_lint.py`
5. **Un intent = un flow** — si le user change d'intent en cours de route, re-router
6. **Le flow est un guide, pas une prison** — si le user veut sauter une étape et sait ce qu'il fait, le laisser
7. **Feeling first** — dans le doute, demander "c'est quoi l'émotion visée ?" avant les mécaniques
8. **Anti-perfectionnisme** — si le user refait un truc pour la 3e fois, le signaler. Ship > perfect
