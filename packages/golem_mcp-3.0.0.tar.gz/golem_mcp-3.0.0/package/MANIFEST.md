# Golem MCP — Package Manifest

> Source of truth for distributed content. Verified by `/audit`.

## Commands (10) — thin pointers

| File | Agent | Description |
|------|-------|-------------|
| build.md | Builder | Build a deliverable → loads build workflow |
| catchup.md | Maintainer | Load project context → loads catchup workflow |
| checkpoint.md | Maintainer | Snapshot project state → loads checkpoint workflow |
| deliverable.md | Builder | Focus on a deliverable → loads deliverable workflow |
| fix.md | Builder | Debug and repair → loads fix workflow |
| init.md | Designer | Bootstrap project → loads init workflow |
| learn.md | Maintainer | Extract session learnings → loads learn workflow |
| references.md | Maintainer | Manage project patterns → loads references workflow |
| ship.md | Maintainer | Version sync and publish → loads ship workflow |
| think.md | Designer | Brainstorm and design → loads think workflow |

## `_golem/` Module

### Agents (3) — personas with menus

| File | Role | Menu |
|------|------|------|
| builder.md | Godot 4.x developer | [B] Build, [D] Deliverable, [F] Fix |
| designer.md | Game designer / architect | [T] Think, [I] Init |
| maintainer.md | Curator / shipper | [S] Ship, [C] Catchup, [K] Checkpoint, [L] Learn, [R] References |

### Workflows (31 files across 10 workflows)

| Workflow | Steps | Description |
|----------|-------|-------------|
| build/ | 5 | Preflight → manifest → implement → review → validate |
| think/ | 3 | Interrogate → scan → document |
| fix/ | 2 | Diagnose → repair |
| init/ | 4 | Experience → gameplay loop → vertical slice → scaffold |
| deliverable/ | 2 | Brief → plan (routes to build) |
| ship/ | 3 | Audit → bump → publish |
| catchup/ | 1 | Single-file, read-only context loading |
| checkpoint/ | 1 | Single-file, project state snapshot |
| learn/ | 1 | Single-file, session extraction |
| references/ | 1 | Single-file, pattern management |

### Knowledge (10) — loaded JIT by workflow steps

| File | Source (V2 skill) | Description |
|------|-------------------|-------------|
| architecture.md | godot-architecture.md | Pseudo-ECS, EventBus, components, folder structure |
| audio.md | godot-audio.md | Bus layout, music manager, SFX pool, spatial audio |
| camera.md | godot-camera.md | Smooth follow, zoom, limits, cinematic, parallax |
| game-feel.md | godot-juice.md | Screenshake, freeze, squash & stretch, hit effects |
| save-system.md | godot-save.md | Settings, game state, slots, migration |
| scene-building.md | godot-scene.md | MCP tool sequences, node creation, scene manipulation |
| theme-tokens.md | godot-theme.md | Theme resource, design tokens, StyleBox patterns |
| ui-behavior.md | godot-behavior.md | State machines, tweens, focus, feedback loops |
| ui-composition.md | godot-composition.md | Containers, layout patterns, Game Board pattern |
| vfx.md | godot-vfx.md | GPUParticles2D, shaders, lighting, WorldEnvironment |

### Recipes (21)

| File | Description |
|------|-------------|
| INDEX.md | Recipe index — concept-to-file mapping and keyword detection |
| ai_telegraph_and_weight.md | AI telegraphing & weight |
| audio_layering.md | Audio layering & SFX |
| card_feel_and_shaders.md | Card feel & card shaders |
| collection_feel.md | Collection & inventory feel |
| color_and_mood.md | Color & mood |
| data_pipeline.md | Data pipeline — Custom Resources, Registry |
| dialogue_engine.md | Dialogue engine — conversation graph |
| dialogue_presence.md | Dialogue presence — portraits, staging |
| fbx_retargeting.md | FBX retargeting pipeline |
| hit_feedback.md | Hit feedback pipeline |
| lights_and_shadows.md | Lights & shadows |
| movement_feel.md | Movement feel 2D |
| narrative_ui_patterns.md | Narrative UI patterns |
| particle_presets.md | Particle presets 2D |
| screen_transitions.md | Screen transitions |
| shader_cookbook_2d.md | Shader cookbook 2D |
| turn_combat_feel.md | Turn-based combat feel |
| tweens_and_juice.md | Tweens & juice |
| typewriter_and_text_fx.md | Typewriter & text FX |
| viewport_patterns.md | Viewport patterns |

### References (2)

| File | Description |
|------|-------------|
| gdscript_pitfalls.md | GDScript 4.x pitfalls quick-scan checklist |
| workflow_patterns.md | Multi-agent patterns, architecture, scaffolding |

### Tools (2)

| File | Description |
|------|-------------|
| preflight.py | Pre-build validation |
| validate_skills.py | Coherence validator |

### Sub-agents (3) — optional, for context isolation

| File | Description |
|------|-------------|
| gdscript-reviewer.md | Post-build GDScript review |
| preflight-advisor.md | Pre-build validation brief |
| scene-inspector.md | Post-build scene validation |

### Config

| File | Description |
|------|-------------|
| config.yaml | Project paths and TCP config |

## Rules (7) — auto-loaded by glob

| File | Globs | Description |
|------|-------|-------------|
| gdscript.md | `**/*.gd`, `godot-plugin/**` | GDScript timing, types, architecture |
| shaders.md | `**/*.gdshader`, `**/vfx/**`, etc. | VFX, game feel & audio guardrails |
| mcp-pitfalls.md | `**/*.gd`, `godot-plugin/**` | MCP tools & TCP pitfalls |
| recipes.md | `**/*.gd`, `**/*.gdshader`, `**/*.tres` | Recipe gate |
| audio.md | `**/audio/**`, `**/sfx/**`, etc. | Audio guardrails |
| game-feel.md | `**/juice/**`, `**/shake/**`, etc. | Game feel guardrails |
| multi-agent.md | *(no globs)* | Multi-agent orchestration |

## Hooks (5 + config)

| File | Event | Description |
|------|-------|-------------|
| check_connection.py | PreToolUse | TCP check with TTL cache |
| block_tscn_edit.py | PreToolUse | Blocks Edit/Write on .tscn |
| gdscript_lint.py | PostToolUse | Lints GDScript after write |
| compact_context.py | SessionStart | Re-injects context after compaction |
| pre_compact.py | PreCompact | Saves state before compaction |

## Godot Plugin (12 files)

| File | Description |
|------|-------------|
| plugin.cfg | Plugin metadata |
| golem_plugin.gd | EditorPlugin entry point |
| golem_server.gd | TCP server multi-client |
| golem_capture.gd | Game autoload — screenshots + logs |
| handlers/input_handler.gd | Input simulation |
| handlers/inspect_handler.gd | Node inspection |
| handlers/project_handler.gd | ProjectSettings |
| handlers/run_handler.gd | Play/stop scene |
| handlers/scene_handler.gd | Scene tree manipulation |
| handlers/screenshot_handler.gd | Screenshot capture |
| handlers/script_handler.gd | GDScript operations |
| handlers/theme_handler.gd | Theme resource creation |
