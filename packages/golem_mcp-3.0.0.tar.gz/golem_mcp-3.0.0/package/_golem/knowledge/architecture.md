# Architecture — Knowledge

Godot 4.x modular pseudo-ECS architecture. Composition over inheritance, EventBus decoupling, convention-driven structure.

---

## Mandates

[MANDATE] **EventBus for global signals, local signals in scripts.** Components emit local signals (`damaged`, `died`). The root script routes to EventBus. Components never import or reference EventBus directly.

[MANDATE] **Modules are portable.** Every component uses `@export`, signals, zero hardcoded game deps. A `HealthComponent` works on a bare `Node2D` — no assumption about parent type.

[MANDATE] **Autoloads for singletons only.** `EventBus`, `GameState`, `SceneLoader`, `SaveSystem`, `Logger`. One file = one responsibility. No God Autoload.

[MANDATE] **No direct calls between modules.** `CombatSystem` never calls `InventorySystem.add_item()`. Everything goes through EventBus signals.

[MANDATE] **Typed signals only.** EventBus signals are declared with typed parameters in `event_bus.gd`. No string-based emit, no dynamic signals.

[MANDATE] **`class_name` on all components and Resources.** Required for `@export` typing, inspector validation, and AI readability.

[MANDATE] **Core does not know Mechanics.** Autoloads are gameplay-agnostic. They provide infrastructure, not game logic.

[MANDATE] **Components expose `setup(data)` and `reset()`.** `setup()` injects data at spawn. `reset()` returns to post-setup state (for pooling/respawn). `reset()` never changes `@export` values.

---

## Folder Structure

```
project/
├── core/               # Autoloads — EventBus, GameState, SceneLoader, SaveSystem, Logger
├── entities/           # Game actors — scenes composed of component-nodes
│   ├── player/
│   │   ├── player.tscn
│   │   ├── player.gd
│   │   ├── player_sprite.png      # Co-located: entity-specific assets live here
│   │   └── components/
│   │       ├── health_component.gd
│   │       └── movement_component.gd
│   ├── enemy/
│   └── shared_components/          # Components reused across entities verbatim
├── mechanics/          # Gameplay modules — isolated features
│   ├── combat/
│   │   ├── combat_system.gd
│   │   └── ui/                     # Module-specific UI lives in module
│   └── inventory/
│       ├── inventory_system.gd
│       └── item_registry.gd        # Domain registry, NOT a global Database
├── data/               # Custom Resources (.tres) — declarative content
│   ├── items/
│   └── quests/
├── shared/             # Cross-entity assets (fonts, global shaders, UI textures)
├── scenes/             # Levels, maps, assemblages — no logic, just composition
├── builds/             # Exports (.gitignore this)
└── assets/             # Raw sources (.blend, .psd) — add .gdignore inside
```

**Co-location rule:** entity-specific assets (sprites, SFX) live in the entity folder. Only assets used by 2+ unrelated entities go in `shared/`.

**ECS mapping:**

| ECS concept | Godot equivalent |
|-------------|-----------------|
| Entity (ID) | Scene root node (.tscn) |
| Component (data) | Child node with @exports + local logic |
| System (global logic) | Autoload or node in a mechanic module |
| World query | `get_tree().get_nodes_in_group("group_name")` |

---

## Patterns

### [PATTERN] EventBus — Typed Signal Hub

Single autoload, section-commented, typed parameters. The only place global signals are declared.

```gdscript
# core/event_bus.gd
extends Node

# -- Player
signal player_died(entity: Node)
signal player_damaged(entity: Node, amount: int, source: String)

# -- Items
signal item_acquired(item_id: String, quantity: int)

# -- Combat
signal damage_applied(source: Node, target: Node, amount: int)
signal entity_killed(entity: Node, killer: Node)
```

**Signal naming taxonomy:**

| Pattern | When | Example |
|---------|------|---------|
| `<subject>_<past_participle>` | Event happened (80% of cases) | `player_died`, `item_acquired` |
| `<subject>_<action>_requested` | Request from UI/system | `weapon_swap_requested` |
| `<subject>_<property>_changed` | Observable state change | `score_changed`, `day_changed` |

Rules: always past tense, subject = affected entity (not agent), one signal per atomic event, no duplicates (`player_damaged` exists = no `player_hit` alongside).

### [PATTERN] Component-Node Contract

```gdscript
extends Node
class_name HealthComponent

@export var max_hp: int = 100
@export var current_hp: int = 100
@export var invincible: bool = false

# Local signals — component IS the subject, no prefix
signal damaged(amount: int)
signal healed(amount: int)
signal died

func take_damage(amount: int) -> void:
    if invincible:
        return
    current_hp = max(0, current_hp - amount)
    damaged.emit(amount)
    if current_hp <= 0:
        died.emit()

func setup(data: Resource) -> void:
    max_hp = data.get("max_hp") if data else max_hp
    current_hp = max_hp

func reset() -> void:
    current_hp = max_hp
    invincible = false
```

Local signal naming: `<past_participle>` or `<property>_changed`. Always past tense. Never `dies`, `taking_damage`.

### [PATTERN] Root Orchestration — Wiring Components

The root script owns `@export` refs to components, connects their local signals, and routes to EventBus.

```gdscript
# player.gd (root script)
@export var health: HealthComponent
@export var movement: MovementComponent
@export var vfx: VFXComponent

func _ready():
    health.died.connect(_on_health_died)
    health.damaged.connect(_on_health_damaged)

func _on_health_died():
    movement.disable()
    vfx.play_death()
    EventBus.player_died.emit(self)

func _on_health_damaged(amount: int):
    EventBus.player_damaged.emit(self, amount, "unknown")
```

**Why `@export` typed over `@onready $`:** survives node renames, validates type in inspector, visible via drag-and-drop. Use `%UniqueName` for quick prototyping only.

### [PATTERN] Mechanic Module — Isolated Feature

```gdscript
# mechanics/combat/combat_system.gd
extends Node

func _ready():
    EventBus.damage_applied.connect(_on_damage_applied)

func _on_damage_applied(source: Node, target: Node, amount: int):
    var health = target.get_node_or_null("HealthComponent") as HealthComponent
    if health == null:
        return
    health.take_damage(amount)
```

Module rules:
1. Modules never call other modules directly — EventBus only
2. Modules can read entities (access components)
3. Modules never modify Core
4. Module-specific UI lives inside the module folder
5. Domain registries (`ItemRegistry`) live in their module, not a global Database

### [PATTERN] GameState — Explicit FSM

```gdscript
# core/game_state.gd
extends Node

signal state_changed(old_state: String, new_state: String)
enum State { BOOT, MENU, PLAYING, PAUSED, GAME_OVER }
var current: State = State.BOOT

func transition_to(new_state: State):
    var old = current
    current = new_state
    state_changed.emit(State.keys()[old], State.keys()[new_state])
```

This script does ONLY this. No gameplay logic, no input handling, no scene loading. Other scripts listen to `state_changed`.

### [PATTERN] Lightweight Component FSM

One script, one enum, explicit transitions. No framework, no node-per-state.

```gdscript
extends Node
class_name StateMachineComponent

signal state_changed(old_state: int, new_state: int)
enum State { IDLE, CHASE, ATTACK, STUNNED, DEAD }

var current_state: State = State.IDLE
var _transitions: Dictionary = {
    State.IDLE: [State.CHASE, State.ATTACK, State.STUNNED, State.DEAD],
    State.CHASE: [State.IDLE, State.ATTACK, State.STUNNED, State.DEAD],
    State.ATTACK: [State.IDLE, State.CHASE, State.STUNNED, State.DEAD],
    State.STUNNED: [State.IDLE, State.DEAD],
    State.DEAD: [],
}

func transition_to(new_state: State) -> void:
    if new_state == current_state:
        return
    if new_state not in _transitions.get(current_state, []):
        push_warning("FSM: invalid %s -> %s" % [State.keys()[current_state], State.keys()[new_state]])
        return
    var old = current_state
    _exit_state(old)
    current_state = new_state
    _enter_state(new_state)
    state_changed.emit(old, new_state)
```

When NOT to FSM: 2 states (use bool), non-exclusive states like buffs (use flags), animation states (use AnimationTree), pure event-driven reactions (use signals).

### [PATTERN] Data Resources + Domain Registry

Content in typed `.tres` files. One registry per domain loads its folder.

```gdscript
# data/item_data.gd
extends Resource
class_name ItemData

@export var id: String = ""
@export var display_name: String = ""
@export var icon: Texture2D
@export var rarity: Rarity = Rarity.COMMON
@export var effects: Array[EffectData] = []

enum Rarity { COMMON, UNCOMMON, RARE, EPIC, LEGENDARY }
```

```gdscript
# mechanics/inventory/item_registry.gd — loads res://data/items/
var _items: Dictionary = {}

func get_item(id: String) -> ItemData:
    return _items.get(id)
```

### [PATTERN] Spawn — Factory in the System

The factory lives in the **system** (mechanic module), not the entity. The entity doesn't know how it was created.

```gdscript
func spawn_enemy(data: EnemyData, pos: Vector2) -> Node:
    var enemy = load(data.scene_path).instantiate()
    enemy.setup(data)
    enemy.global_position = pos
    enemy.add_to_group("enemies")
    enemy_container.call_deferred("add_child", enemy)
    return enemy
```

### [PATTERN] Query-Based Modifiers (vs Direct Mutation)

Never mutate base stats for buffs/debuffs. Query modifiers at resolution time.

```gdscript
# BAD: card.damage += buff_value  (who restores it? when? what order?)
# GOOD:
func calculate_damage(card: CardData) -> int:
    var base: int = card.damage
    var modifier: int = modifier_system.get_damage_modifier(card)
    return base + modifier
```

---

## Signal Conventions

**EventBus (global):** `<subject>_<past_participle>(typed_params)`
- Subject = the affected entity, not the actor
- Always past tense: `player_died`, never `player_dies`
- One atomic event per signal: no `combat_update` catch-all
- No duplicates: `player_damaged` exists = no `player_hit` or `player_took_damage`

**Component (local):** `<past_participle>(typed_params)`
- Component IS the implicit subject: `damaged`, `died`, `healed`
- Same past-tense rule, same `_changed` suffix for observable state

**Connection pattern:**
```gdscript
func _ready():
    EventBus.player_damaged.connect(_on_player_damaged)
    health.died.connect(_on_health_died)
```

**`_requested` suffix** for intent signals (UI asking a system to do something): `weapon_swap_requested`, `dialogue_open_requested`.

---

## Anti-patterns

[ANTI-PATTERN] **God Manager.** One autoload managing everything. Impossible to modify without breaking the world. Split: one autoload per responsibility.

[ANTI-PATTERN] **String-based EventBus.** `emit("player_died")` — silent typos, no autocomplete, AI can't reason about it. Use typed signal declarations.

[ANTI-PATTERN] **Monolithic Database.** One registry loading all game data at boot. Use one registry per domain, each loading its own `data/` subfolder.

[ANTI-PATTERN] **Component for 5 lines.** `HealthComponent` that's just `var hp = 100`. Put it in the root script. Components are for reusable logic with its own state (50+ lines).

[ANTI-PATTERN] **Deep inheritance.** `Enemy > Character > Entity > Node`. Rigid, fragile, forces AI to trace the full chain. Use composition with component-nodes instead.

[ANTI-PATTERN] **Direct module calls.** `InventorySystem.add_item()` from `CombatSystem`. Hard coupling, one module breaks the other. Route through EventBus.

[ANTI-PATTERN] **Sort by file type.** `scripts/`, `sprites/`, `sounds/` folders. Deleting an enemy means hunting across 5 directories. Co-locate entity assets. Shared assets in `shared/`.

[ANTI-PATTERN] **200 EventBus signals.** Signal noise, impossible to navigate. EventBus is for inter-module communication only. Intra-component = local signals.

[ANTI-PATTERN] **Components referencing siblings.** `$../MovementComponent.disable()` inside `HealthComponent`. Components never know each other. Root orchestrates: signal local -> root catches -> root calls sibling.

[ANTI-PATTERN] **transition_to() inside _exit_state().** Infinite loop. Exit = cleanup only, never trigger new transitions.

[ANTI-PATTERN] **Direct stat mutation for buffs.** `card.damage += buff_value` — who restores? when? Use query-based modifiers that leave base stats untouched.
