# Audio — Knowledge

Godot 4.x audio architecture: bus layout, music manager, SFX pool, spatial audio, volume UI.

---

## Mandates

### [MANDATE] Bus hierarchy: Master > Music + SFX + UI + Ambient

Every project must have at minimum Master, Music, and SFX buses. UI and Ambient are recommended. All buses route to Master. Configure in editor via Audio > Show Audio Buses, saved to `res://default_bus_layout.tres`.

| Bus | Usage | Parent |
|-----|-------|--------|
| **Master** | Final output | - |
| **Music** | Background music | Master |
| **SFX** | Gameplay sound effects | Master |
| **UI** | Interface sounds | Master |
| **Ambient** | Environment loops (wind, water) | Master |

### [MANDATE] SFX pool — never create AudioStreamPlayer per sound

Pre-instantiate 8-16 players at boot. Reuse them. If all busy, steal the oldest. Never `AudioStreamPlayer.new()` at runtime per sound event.

### [MANDATE] Volume in dB, not linear

`AudioServer` works in dB. Sliders expose 0.0-1.0 linear. Always convert with `linear_to_db()` / `db_to_linear()`. Clamp slider min to 0.01 to avoid `-INF`. Save settings in linear, convert on load.

| dB | Perception | Usage |
|----|------------|-------|
| 0 dB | Full scale | Peak ceiling |
| -6 dB | Half perceived | Background music |
| -20 dB | Subtle | Distant ambiance |
| -80 dB | Silence | Mute equivalent |

### [MANDATE] Pitch variation for repeated sounds (0.9-1.1)

Any SFX that can fire multiple times (footsteps, hits, shots) must have pitch randomization in the 0.9-1.1 range. Prevents machine-gun repetition. Add slight volume variation (-2 to 0 dB) too.

---

## Bus Layout

### Player type mapping

| Type | Use case | Bus |
|------|----------|-----|
| `AudioStreamPlayer` | Music, UI, global ambiance | Music / UI / Ambient |
| `AudioStreamPlayer2D` | Positional SFX (impacts, steps) | SFX |
| `AudioStreamPlayer3D` | 3D positional (rare in 2D) | SFX |

### Audio formats

| Format | Use case | Why |
|--------|----------|-----|
| WAV | SFX < 2s | Zero decode latency |
| OGG | Music, long ambiance | Streaming, small files |
| MP3 | Avoid | Decode latency, compression artifacts |

### Bus creation via code (fallback)

```gdscript
func _create_bus_layout():
    if AudioServer.get_bus_index("Music") != -1:
        return  # Already set up

    for bus_name in ["Music", "SFX", "UI"]:
        var idx = AudioServer.bus_count
        AudioServer.add_bus(idx)
        AudioServer.set_bus_name(idx, bus_name)
        AudioServer.set_bus_send(idx, "Master")
```

---

## Patterns

### [PATTERN] MusicManager — Crossfade with dual players

Two `AudioStreamPlayer` alternate. One fades out while the other fades in. No silence gap.

```gdscript
## music_manager.gd — Autoload
extends Node

@export var fade_duration: float = 1.0

var _player_a: AudioStreamPlayer
var _player_b: AudioStreamPlayer
var _current: AudioStreamPlayer
var _next: AudioStreamPlayer

func _ready():
    for p in [AudioStreamPlayer.new(), AudioStreamPlayer.new()]:
        p.bus = "Music"
        add_child(p)
    _player_a = get_child(0)
    _player_b = get_child(1)
    _current = _player_a
    _next = _player_b
    _player_a.finished.connect(_on_track_finished)
    _player_b.finished.connect(_on_track_finished)

func change_music(stream: AudioStream, fade: float = -1.0):
    if fade < 0:
        fade = fade_duration
    if _current.playing:
        var tw = create_tween()
        tw.tween_property(_current, "volume_db", -80.0, fade)
        tw.tween_callback(_current.stop)
    # Swap
    var tmp = _current
    _current = _next
    _next = tmp
    _current.stream = stream
    _current.volume_db = -80.0
    _current.play()
    create_tween().tween_property(_current, "volume_db", 0.0, fade)

func stop_music(fade: float = -1.0):
    if fade < 0:
        fade = fade_duration / 2.0
    if _current.playing:
        var tw = create_tween()
        tw.tween_property(_current, "volume_db", -80.0, fade)
        tw.tween_callback(_current.stop)

func _on_track_finished():
    pass  # Hook for playlist auto-advance
```

### [PATTERN] SFX Pool — Pre-instantiated with throttle

```gdscript
## sfx_pool.gd — Autoload
extends Node

@export var pool_size: int = 12

var _pool: Array[AudioStreamPlayer] = []
var _last_played: Dictionary = {}
var _throttle_ms: int = 80

func _ready():
    for i in pool_size:
        var p = AudioStreamPlayer.new()
        p.bus = "SFX"
        add_child(p)
        _pool.append(p)

func play(stream: AudioStream, pitch: float = 1.0, vol_db: float = 0.0):
    if not stream:
        return
    var path = stream.resource_path
    var now = Time.get_ticks_msec()
    if _last_played.has(path) and now - _last_played[path] < _throttle_ms:
        return
    _last_played[path] = now
    var p = _get_available()
    p.stream = stream
    p.pitch_scale = pitch
    p.volume_db = vol_db
    p.play()

func play_random(stream: AudioStream):
    play(stream, randf_range(0.9, 1.1), randf_range(-2.0, 0.0))

func _get_available() -> AudioStreamPlayer:
    for p in _pool:
        if not p.playing:
            return p
    return _pool[0]  # Steal oldest
```

### [PATTERN] Spatial audio zone (positional ambiance)

Attach to an `Area2D` with an `AudioStreamPlayer2D` child. Fades in/out when player enters/exits.

```gdscript
## zone_audio.gd
extends Area2D

@export var audio_stream: AudioStream
@export var max_volume_db: float = 0.0
@export var fade_duration: float = 1.0

@onready var player: AudioStreamPlayer2D = $AudioStreamPlayer2D

func _ready():
    player.stream = audio_stream
    player.max_distance = 500.0
    player.attenuation = 2.0
    player.volume_db = -80.0
    player.autoplay = true
    body_entered.connect(_on_enter)
    body_exited.connect(_on_exit)

func _on_enter(body: Node2D):
    if body.is_in_group("player"):
        create_tween().tween_property(player, "volume_db", max_volume_db, fade_duration)

func _on_exit(body: Node2D):
    if body.is_in_group("player"):
        create_tween().tween_property(player, "volume_db", -80.0, fade_duration)
```

Key spatial properties: `max_distance` (500-2000), `attenuation` (2.0 = inverse square), `panning_strength` (0.7-1.0).

### [PATTERN] Volume settings UI with persistence

```gdscript
## volume_settings.gd
extends Control

@onready var master_slider: HSlider = $VBox/MasterSlider
@onready var music_slider: HSlider = $VBox/MusicSlider
@onready var sfx_slider: HSlider = $VBox/SFXSlider
var _config := ConfigFile.new()

func _ready():
    _load_settings()
    master_slider.value_changed.connect(func(v): _set_bus("Master", v); _save())
    music_slider.value_changed.connect(func(v): _set_bus("Music", v); _save())
    sfx_slider.value_changed.connect(func(v): _set_bus("SFX", v); _save())

func _set_bus(bus_name: String, linear_val: float):
    var idx = AudioServer.get_bus_index(bus_name)
    if idx == -1: return
    AudioServer.set_bus_volume_db(idx, linear_to_db(maxf(linear_val, 0.01)))

func _save():
    for key in ["master", "music", "sfx"]:
        _config.set_value("audio", key, get(key + "_slider").value)
    _config.save("user://settings.cfg")

func _load_settings():
    if _config.load("user://settings.cfg") != OK:
        master_slider.value = 1.0; music_slider.value = 0.8; sfx_slider.value = 1.0
        return
    master_slider.value = _config.get_value("audio", "master", 1.0)
    music_slider.value = _config.get_value("audio", "music", 0.8)
    sfx_slider.value = _config.get_value("audio", "sfx", 1.0)
    _set_bus("Master", master_slider.value)
    _set_bus("Music", music_slider.value)
    _set_bus("SFX", sfx_slider.value)
```

### [PATTERN] LowPass for pause/underwater effect

```gdscript
func _toggle_lowpass(muffled: bool):
    var lp = AudioServer.get_bus_effect(
        AudioServer.get_bus_index("Master"), 0
    ) as AudioEffectLowPassFilter
    var target = 800.0 if muffled else 20000.0
    create_tween().tween_property(lp, "cutoff_hz", target, 0.3)
```

### [PATTERN] Compressor on Master

```gdscript
func _setup_compressor():
    var comp = AudioEffectCompressor.new()
    comp.threshold = -6.0
    comp.ratio = 4.0
    comp.gain = 3.0
    comp.attack_us = 20.0
    comp.release_ms = 100.0
    AudioServer.add_bus_effect(AudioServer.get_bus_index("Master"), comp)
```

---

## Anti-patterns

### [ANTI-PATTERN] Instantiate player per sound event

Creating `AudioStreamPlayer.new()` every time a sound fires causes GC spam and lag spikes. Use the SFX pool pattern.

### [ANTI-PATTERN] No bus assignment

Leaving players on the default Master bus makes per-category volume control impossible. Always assign Music/SFX/UI bus explicitly.

### [ANTI-PATTERN] OGG for short SFX

OGG has decode latency on first play. Use WAV for any SFX under 2 seconds.

### [ANTI-PATTERN] Saving volume in dB

Saving raw dB values produces unreadable config (`-6.02059...`). Save linear (0-1), convert with `linear_to_db()` at load time.

### [ANTI-PATTERN] No throttle on rapid-fire SFX

Without a cooldown gate (~80ms), overlapping identical sounds cause saturation and crackling. The SFX pool throttle handles this.

### [ANTI-PATTERN] linear_to_db(0.0)

Returns `-INF`. Clamp slider minimum to 0.01, or use `AudioServer.set_bus_mute()` for true silence.

### [ANTI-PATTERN] Missing max_distance on AudioStreamPlayer2D

Without `max_distance` set, spatial sounds are audible everywhere with no attenuation. Always configure it (500-2000 depending on context).

### [ANTI-PATTERN] No pitch variation on repeated SFX

Identical repeated sounds feel robotic. Always randomize pitch (0.9-1.1) for footsteps, hits, shots, and similar repeating effects.
