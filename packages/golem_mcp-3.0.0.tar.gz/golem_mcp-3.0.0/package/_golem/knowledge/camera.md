# Camera -- Knowledge

> 2D camera behaviors for Godot 4.x: smooth follow, zoom, area limits, cinematic mode, parallax.

---

## Mandates

### [MANDATE] Camera shake via offset, not position

Camera shake MUST use `camera.offset`, never `camera.global_position`. Shaking position permanently displaces the camera. The offset resets naturally. The follow script owns `global_position`; the shake system owns `offset`.

```gdscript
# CORRECT -- shake on offset
func _apply_shake(camera: Camera2D, intensity: float) -> void:
    camera.offset = Vector2(
        randf_range(-intensity, intensity),
        randf_range(-intensity, intensity)
    )

# WRONG -- shake on position (drift, conflicts with follow)
# camera.global_position += shake_vector
```

### [MANDATE] Smooth follow via lerp in _physics_process, not _process

Frame-rate independent lerp uses `1.0 - exp(-speed * delta)`. Place follow logic in `_physics_process` when tracking a CharacterBody2D to stay in sync with physics movement. Use `_process` only for purely visual cameras (cinematic, UI).

```gdscript
extends Camera2D

@export var target_path: NodePath
@export var follow_speed: float = 5.0
@export var offset: Vector2 = Vector2.ZERO

var _target: Node2D

func _ready() -> void:
    _target = get_node(target_path)
    position_smoothing_enabled = false  # manual control

func _physics_process(delta: float) -> void:
    if not _target:
        return
    var goal := _target.global_position + offset
    global_position = global_position.lerp(goal, 1.0 - exp(-follow_speed * delta))
```

### [MANDATE] Camera limits set from tilemap / level bounds

Never hardcode pixel limits. Derive them from the level geometry (TileMapLayer used_rect, or a dedicated Rect2 export). Cast to int to avoid sub-pixel jitter.

```gdscript
func set_limits_from_tilemap(tilemap: TileMapLayer, camera: Camera2D) -> void:
    var used := tilemap.get_used_rect()
    var tile_size := tilemap.tile_set.tile_size
    camera.limit_left   = int(used.position.x * tile_size.x)
    camera.limit_top    = int(used.position.y * tile_size.y)
    camera.limit_right  = int(used.end.x * tile_size.x)
    camera.limit_bottom = int(used.end.y * tile_size.y)
    camera.limit_smoothed = true
```

---

## Patterns

### [PATTERN] Smooth follow with look-ahead

Offset toward movement direction so the player sees more of what's ahead.

```gdscript
extends Camera2D

@export var target_path: NodePath
@export var follow_speed: float = 5.0
@export var look_ahead_factor: float = 50.0
@export var look_ahead_smoothing: float = 3.0

var _target: Node2D
var _look_ahead: Vector2 = Vector2.ZERO

func _ready() -> void:
    _target = get_node(target_path)
    position_smoothing_enabled = false

func _physics_process(delta: float) -> void:
    if not _target:
        return
    var vel: Vector2 = _target.velocity if "velocity" in _target else Vector2.ZERO
    _look_ahead = _look_ahead.lerp(
        vel.normalized() * look_ahead_factor,
        1.0 - exp(-look_ahead_smoothing * delta)
    )
    var goal := _target.global_position + _look_ahead
    global_position = global_position.lerp(goal, 1.0 - exp(-follow_speed * delta))
```

### [PATTERN] Zoom -- tween-based contextual

Zoom out for combat (see the arena), zoom in for dialogue (intimacy).

```gdscript
func zoom_to(target_zoom: float, duration: float = 0.3) -> void:
    var tw := create_tween()
    tw.tween_property(self, "zoom", Vector2(target_zoom, target_zoom), duration) \
        .set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_CUBIC)
```

### [PATTERN] Zoom -- speed-based progressive

Camera pulls back when the player moves fast, tightens when idle.

```gdscript
@export var min_zoom: float = 0.7
@export var max_zoom: float = 1.2
@export var speed_threshold: float = 400.0
@export var zoom_smoothing: float = 2.0

func _physics_process(delta: float) -> void:
    if not _target or not "velocity" in _target:
        return
    var ratio := clampf(_target.velocity.length() / speed_threshold, 0.0, 1.0)
    var goal_zoom := lerpf(max_zoom, min_zoom, ratio)
    var z := lerpf(zoom.x, goal_zoom, 1.0 - exp(-zoom_smoothing * delta))
    zoom = Vector2(z, z)
```

### [PATTERN] Area limits -- zone transition via Area2D

An Area2D reconfigures camera limits when the player enters. Tween for smooth transition.

```gdscript
## camera_zone.gd -- attach to Area2D with CollisionShape2D
extends Area2D

@export var camera_limits: Rect2 = Rect2(-500, -300, 1000, 600)
@export var transition_duration: float = 0.5

func _ready() -> void:
    body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node2D) -> void:
    var camera := body.get_viewport().get_camera_2d()
    if not camera:
        return
    var tw := create_tween().set_parallel(true)
    tw.tween_property(camera, "limit_left",   int(camera_limits.position.x), transition_duration)
    tw.tween_property(camera, "limit_top",    int(camera_limits.position.y), transition_duration)
    tw.tween_property(camera, "limit_right",  int(camera_limits.end.x),      transition_duration)
    tw.tween_property(camera, "limit_bottom", int(camera_limits.end.y),      transition_duration)
```

### [PATTERN] Cinematic pan -- disconnect, pan, return

Temporarily detach from the player to show a point of interest, then return.

```gdscript
extends Camera2D

signal cinematic_finished

var _cinematic_active := false

func pan_to_and_return(target_pos: Vector2, return_target: Node2D,
        duration: float = 1.0, hold: float = 1.0) -> void:
    _cinematic_active = true
    var tw := create_tween()
    tw.tween_property(self, "global_position", target_pos, duration) \
        .set_ease(Tween.EASE_IN_OUT).set_trans(Tween.TRANS_CUBIC)
    tw.tween_interval(hold)
    tw.tween_property(self, "global_position", return_target.global_position, duration) \
        .set_ease(Tween.EASE_IN_OUT).set_trans(Tween.TRANS_CUBIC)
    tw.tween_callback(_end_cinematic)

func _end_cinematic() -> void:
    _cinematic_active = false
    cinematic_finished.emit()

func is_in_cinematic() -> bool:
    return _cinematic_active
```

Usage in a level script:

```gdscript
func _on_door_unlocked() -> void:
    var camera := get_viewport().get_camera_2d()
    camera.pan_to_and_return($Door.global_position, $Player, 1.0, 2.0)
    await camera.cinematic_finished
```

### [PATTERN] Parallax -- CanvasLayer offset

Parallax backgrounds use `CanvasLayer` or `Parallax2D` (Godot 4.3+). Each layer scrolls at a fraction of camera movement. No custom code needed -- configure `scroll_scale` in the editor. Foreground layers > 1.0, background layers < 1.0.

```
Layer stack (back to front):
  Sky          scroll_scale = Vector2(0.1, 0.1)
  Far hills    scroll_scale = Vector2(0.3, 0.3)
  Near trees   scroll_scale = Vector2(0.6, 0.6)
  Gameplay     scroll_scale = Vector2(1.0, 1.0)   # default
  Foreground   scroll_scale = Vector2(1.3, 0.0)   # moves faster, no vertical
```

### [PATTERN] Multi-target -- co-op / boss arena

Center between multiple targets, auto-zoom to keep all visible.

```gdscript
extends Camera2D

@export var targets: Array[NodePath] = []
@export var smoothing: float = 5.0
@export var min_zoom: float = 0.5
@export var max_zoom: float = 1.5
@export var margin: float = 100.0

var _nodes: Array[Node2D] = []

func _ready() -> void:
    for p in targets:
        var n := get_node_or_null(p)
        if n is Node2D:
            _nodes.append(n)

func _physics_process(delta: float) -> void:
    if _nodes.is_empty():
        return
    var mn := _nodes[0].global_position
    var mx := mn
    for t in _nodes:
        mn.x = minf(mn.x, t.global_position.x)
        mn.y = minf(mn.y, t.global_position.y)
        mx.x = maxf(mx.x, t.global_position.x)
        mx.y = maxf(mx.y, t.global_position.y)
    var center := (mn + mx) / 2.0
    global_position = global_position.lerp(center, 1.0 - exp(-smoothing * delta))
    var vp := get_viewport_rect().size
    var spread := mx - mn + Vector2(margin * 2, margin * 2)
    var tz := clampf(minf(vp.x / maxf(spread.x, 1.0), vp.y / maxf(spread.y, 1.0)), min_zoom, max_zoom)
    var z := lerpf(zoom.x, tz, 1.0 - exp(-smoothing * delta))
    zoom = Vector2(z, z)
```

---

## Anti-patterns

### [ANTI-PATTERN] Camera as child of the player

Symptom: shake displaces the player, zoom scales the player sprite.
Fix: Camera as sibling of the player (or at scene root). Follow via script targeting the player node.

### [ANTI-PATTERN] Raw delta lerp instead of exponential

```gdscript
# WRONG -- frame-rate dependent
global_position = global_position.lerp(goal, speed * delta)

# CORRECT -- frame-rate independent
global_position = global_position.lerp(goal, 1.0 - exp(-speed * delta))
```

### [ANTI-PATTERN] Float limits causing sub-pixel jitter

Camera `limit_*` properties accept int. Passing float causes jitter on pixel-art games. Always cast: `camera.limit_left = int(value)`.

### [ANTI-PATTERN] Two Camera2D nodes both enabled

Only one Camera2D can be current. Two enabled cameras produce undefined behavior. Use `make_current()` explicitly when switching, and disable the other.

### [ANTI-PATTERN] Zoom 1.0 on pixel art

A 16px sprite at zoom 1.0 on a 1920px viewport is microscopic (0.8% of screen). Pixel art needs higher zoom. Formula: `zoom = viewport_width / target_visible_width`. For 16px tiles visible at ~40 tiles wide: `zoom = 1920 / 640 = 3.0`.

### [ANTI-PATTERN] Follow logic in _process tracking physics bodies

CharacterBody2D updates position in `_physics_process`. A camera following in `_process` reads stale positions on frames between physics ticks, causing visible stutter. Match the tick: follow in `_physics_process`.
