# Game Feel — Knowledge

> Juice makes the game feel alive. Every action has weight, every impact registers.

## Mandates

### [MANDATE] Juice is part of the deliverable, not a separate pass
Juice is not polish. It ships with the feature. A hit without feedback is an incomplete hit.
Do NOT plan a "juice pass" after the feature is done — bake it in from the start.

### [MANDATE] Camera shake via offset, not position
Always use `Camera2D.offset` for screenshake. Never `position`.
Position shift breaks framing permanently. Offset is additive and resets cleanly.

### [MANDATE] Freeze frame minimum 0.05s, sweet spot 0.08-0.15s
Any freeze below 0.05s is imperceptible waste. The sweet spot for impactful hitstop is 0.08-0.15s.
The 4th parameter of `create_timer()` MUST be `true` (ignore_time_scale), otherwise the game stays frozen forever.

### [MANDATE] create_tween() on dying nodes -> get_tree().create_tween()
If the node running the tween might be freed before the tween completes (enemy death, projectile hit),
use `get_tree().create_tween()` instead of `create_tween()`. A tween bound to a freed node is killed silently.

### [MANDATE] Sound is 50% of juice
Visual feedback without audio feels hollow. Every impact, hit, land, dash needs an accompanying SFX.
Even a placeholder `AudioStreamPlayer` with a pitch-randomized click is better than silence.

### [MANDATE] Dosage — frequent = subtle, rare = heavy
Actions the player does 100 times per minute get minimal feedback (0-0.05 shake).
Actions that happen once per fight get the full treatment (shake + freeze + particles + SFX).
Constant juice = no juice. Contrast is everything.

---

## Patterns

### [PATTERN] Camera Shake — Perlin Noise

Perlin noise produces organic shake. `randf()` produces seizures.

```gdscript
## camera_shake.gd — attach to Camera2D
extends Camera2D

@export var decay: float = 2.0
@export var max_offset: float = 16.0
@export var max_rotation: float = 0.05  # radians
@export var noise_speed: float = 30.0

var trauma: float = 0.0
var _noise := FastNoiseLite.new()
var _noise_y: float = 0.0

func _ready() -> void:
    _noise.seed = randi()
    _noise.frequency = 0.5

func _process(delta: float) -> void:
    if trauma > 0.0:
        trauma = maxf(0.0, trauma - delta * decay)
        var shake := trauma * trauma  # quadratic = natural falloff

        _noise_y += delta * noise_speed
        offset.x = _noise.get_noise_2d(0.0, _noise_y) * max_offset * shake
        offset.y = _noise.get_noise_2d(100.0, _noise_y) * max_offset * shake
        rotation = _noise.get_noise_2d(200.0, _noise_y) * max_rotation * shake
    else:
        offset = Vector2.ZERO
        rotation = 0.0

func add_trauma(amount: float) -> void:
    trauma = minf(1.0, trauma + amount)

func shake(intensity: float) -> void:
    add_trauma(intensity)
```

### [PATTERN] Freeze Frame (Hitstop)

Pauses the world so the player's brain registers the impact.

```gdscript
## In a Juice autoload singleton
func freeze_frame(duration: float = 0.08) -> void:
    Engine.time_scale = 0.0
    # 4th param = ignore_time_scale — MANDATORY
    await get_tree().create_timer(duration, true, false, true).timeout
    Engine.time_scale = 1.0
```

### [PATTERN] Squash & Stretch — Procedural

Deformation that gives elasticity. Squash on land/impact, stretch on jump/dash.

```gdscript
## squash_stretch.gd — attach to the visual node (Sprite2D child)
extends Node

@export var squash_ratio: float = 0.8
@export var stretch_ratio: float = 1.2

var _target: Node2D

func _ready() -> void:
    _target = get_parent()

func squash() -> void:
    _target.scale = Vector2(1.0 / squash_ratio, squash_ratio)
    _spring_back()

func stretch() -> void:
    _target.scale = Vector2(squash_ratio, 1.0 / squash_ratio)
    _spring_back()

func _spring_back() -> void:
    var tween := get_tree().create_tween()
    tween.tween_property(_target, "scale", Vector2.ONE, 0.15) \
        .set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_ELASTIC)
```

### [PATTERN] Hit Flash — Shader

Shader-based flash is cleaner than modulate (modulate bleeds into children).

```gdshader
// hit_flash.gdshader
shader_type canvas_item;

uniform float flash_intensity : hint_range(0.0, 1.0) = 0.0;
uniform vec4 flash_color : source_color = vec4(1.0, 1.0, 1.0, 1.0);

void fragment() {
    vec4 tex = texture(TEXTURE, UV);
    COLOR = mix(tex, flash_color, flash_intensity);
    COLOR.a = tex.a;
}
```

```gdscript
## hit_flash.gd — attach as child of Sprite2D
extends Node

@export var flash_duration: float = 0.08
@export var flash_color: Color = Color.WHITE

var _sprite: CanvasItem

func _ready() -> void:
    _sprite = get_parent()
    if not _sprite.material:
        var mat := ShaderMaterial.new()
        mat.shader = preload("res://shaders/hit_flash.gdshader")
        _sprite.material = mat

func flash() -> void:
    var mat := _sprite.material as ShaderMaterial
    mat.set_shader_parameter("flash_color", flash_color)
    mat.set_shader_parameter("flash_intensity", 1.0)

    var tween := get_tree().create_tween()
    tween.tween_property(mat, "shader_parameter/flash_intensity", 0.0, flash_duration)
```

### [PATTERN] Hit Flash — Simple (no shader)

When a shader is overkill. Store and restore original modulate.

```gdscript
func flash_simple(sprite: CanvasItem, duration: float = 0.08) -> void:
    var original := sprite.modulate
    sprite.modulate = Color.WHITE
    await get_tree().create_timer(duration).timeout
    sprite.modulate = original
```

### [PATTERN] Trail — Line2D

Motion trail behind fast-moving objects.

```gdscript
## trail.gd — add as child of moving object
extends Line2D

@export var max_points: int = 20
@export var point_interval: float = 0.02

var _timer: float = 0.0
var _target: Node2D

func _ready() -> void:
    top_level = true  # CRUCIAL: use global coordinates
    _target = get_parent()
    width = 4.0
    default_color = Color(1.0, 1.0, 1.0, 0.5)

    gradient = Gradient.new()
    gradient.set_color(0, Color(1.0, 1.0, 1.0, 0.6))
    gradient.set_color(1, Color(1.0, 1.0, 1.0, 0.0))

func _process(delta: float) -> void:
    _timer += delta
    if _timer >= point_interval:
        _timer = 0.0
        add_point(_target.global_position)
        if get_point_count() > max_points:
            remove_point(0)
```

### [PATTERN] Trail — Speed-gated

Only emit trail above a velocity threshold.

```gdscript
@export var min_speed: float = 200.0

func _process(delta: float) -> void:
    if not _target is CharacterBody2D:
        return
    if _target.velocity.length() < min_speed:
        if get_point_count() > 0:
            remove_point(0)
        return
    # ... normal trail logic
```

### [PATTERN] Damage Numbers

Pop-up numbers that float and fade. NEVER add as child of the damaged entity.

```gdscript
## damage_number.gd
extends Node2D

@onready var label: Label = $Label

func setup(value: int, is_crit: bool = false) -> void:
    label.text = str(value)
    if is_crit:
        label.add_theme_color_override("font_color", Color.YELLOW)
        scale = Vector2(1.2, 1.2)
    z_index = 100
    _animate()

func _animate() -> void:
    var tween := get_tree().create_tween()  # scene-bound, not self-bound
    tween.set_parallel(true)

    tween.tween_property(self, "position:y", position.y - 50.0, 0.5) \
        .set_ease(Tween.EASE_OUT)
    tween.tween_property(self, "position:x",
        position.x + randf_range(-20.0, 20.0), 0.5)

    # Pop: small -> big -> normal -> vanish
    tween.tween_property(self, "scale", Vector2(1.3, 1.3), 0.1)
    tween.chain().tween_property(self, "scale", Vector2.ONE, 0.1)
    tween.chain().tween_property(self, "scale", Vector2.ZERO, 0.2).set_delay(0.3)

    tween.tween_property(self, "modulate:a", 0.0, 0.3).set_delay(0.4)
    tween.chain().tween_callback(queue_free)
```

Spawner:

```gdscript
func spawn_damage_number(pos: Vector2, damage: int, is_crit: bool = false) -> void:
    var dmg_num := preload("res://ui/damage_number.tscn").instantiate()
    dmg_num.global_position = pos + Vector2(0, -20)
    dmg_num.setup(damage, is_crit)
    # Add to scene root, NOT to the enemy — survives enemy death
    get_tree().current_scene.call_deferred("add_child", dmg_num)
```

### [PATTERN] Juice Autoload — Central access point

```gdscript
## juice.gd — register as Autoload
extends Node

var _camera: Camera2D

func _ready() -> void:
    await get_tree().process_frame
    _camera = get_viewport().get_camera_2d()

func shake(intensity: float = 0.3) -> void:
    if _camera and _camera.has_method("shake"):
        _camera.shake(intensity)

func freeze_frame(duration: float = 0.08) -> void:
    Engine.time_scale = 0.0
    await get_tree().create_timer(duration, true, false, true).timeout
    Engine.time_scale = 1.0

func impact(shake_intensity: float = 0.2, freeze_duration: float = 0.05) -> void:
    shake(shake_intensity)
    if freeze_duration > 0.0:
        freeze_frame(freeze_duration)
```

---

## Timing Reference

### Camera Shake

| Action | Intensity | Duration | Example |
|--------|-----------|----------|---------|
| Light attack / shot | 0.0 - 0.05 | 50ms | Pew pew |
| Hit received / impact | 0.1 - 0.2 | 100ms | Punch |
| Explosion / death | 0.3 - 0.5 | 150ms | Boom |
| Boss hit / major event | 0.5 - 0.8 | 200ms | Climax |

### Freeze Frame

| Action | Duration | Notes |
|--------|----------|-------|
| Light hit | 0.0 - 0.03s | Skip or barely perceptible |
| Heavy hit | 0.05 - 0.08s | Perceptible, satisfying |
| Kill / finisher | 0.08 - 0.12s | Moment of glory |
| Perfect parry | 0.10 - 0.15s | Rewards timing |

### Squash & Stretch

| Action | Squash ratio | Stretch ratio | Spring-back |
|--------|-------------|---------------|-------------|
| Land (low fall) | 0.85 | - | 0.12s elastic |
| Land (high fall) | 0.7 | - | 0.18s elastic |
| Jump | - | 1.2 | 0.15s elastic |
| Dash | - | 1.3 | 0.12s elastic |
| Bounce | 0.75 | 1.25 | 0.15s elastic |

### Hit Flash

| Context | Duration | Color |
|---------|----------|-------|
| Standard damage | 0.06 - 0.08s | White |
| Critical hit | 0.10 - 0.12s | Yellow / Orange |
| Heal | 0.08s | Green |
| Shield hit | 0.06s | Cyan |

### General Tweens

| Effect | Duration | Easing |
|--------|----------|--------|
| UI pop-in | 0.15 - 0.2s | EASE_OUT + TRANS_BACK |
| UI fade-out | 0.1 - 0.15s | EASE_IN |
| Damage number float | 0.5s | EASE_OUT |
| Scale bounce | 0.15s | EASE_OUT + TRANS_ELASTIC |

---

## Anti-patterns

### [ANTI-PATTERN] Shake on position instead of offset
Camera permanently drifts off-center. Use `Camera2D.offset` exclusively.

### [ANTI-PATTERN] randf() for shake values
Produces erratic, nauseating jitter. Use `FastNoiseLite` for organic motion.

### [ANTI-PATTERN] Freeze without ignore_time_scale
`create_timer(duration)` respects `Engine.time_scale`. If time_scale is 0, the timer never fires.
Always pass `true` as 4th argument: `create_timer(duration, true, false, true)`.

### [ANTI-PATTERN] Trail as child without top_level
Trail points are recorded in local coordinates. When the parent moves, old points shift with it.
Set `top_level = true` in `_ready()` so the Line2D uses global coordinates.

### [ANTI-PATTERN] Damage numbers as children of the damaged entity
Enemy dies, children get freed, numbers vanish mid-animation.
Always `add_child` to `get_tree().current_scene`, never to the enemy node.

### [ANTI-PATTERN] create_tween() on a node about to die
The tween is bound to the node. Node freed = tween killed silently.
Use `get_tree().create_tween()` for tweens that must outlive their creator.

### [ANTI-PATTERN] Juice on every single action
Constant feedback = white noise. The player stops noticing.
Reserve heavy juice (shake + freeze + flash) for rare, meaningful moments.
Keep frequent actions (basic attacks, jumps) subtle or silent.

### [ANTI-PATTERN] Modulate for hit flash on nodes with children
`modulate` cascades to all children. If the sprite has sub-sprites, particles, or labels,
everything turns white. Use a shader on the specific `CanvasItem` instead.

### [ANTI-PATTERN] Planning a "juice pass" after feature completion
Juice added retroactively is disconnected from the mechanic's intent.
Build the feedback loop while building the feature. Ship them together.
