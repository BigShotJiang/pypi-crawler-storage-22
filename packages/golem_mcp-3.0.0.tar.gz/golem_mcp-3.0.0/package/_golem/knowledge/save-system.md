# Save System — Knowledge

Persistence in Godot 4.x: settings via ConfigFile, game state via JSON, slot management, version migration.

---

## Mandates

### [MANDATE] Settings saved on change, game state saved explicitly

Settings persist immediately when the player changes them (auto-save on set). Game state is only saved when the player or the game explicitly triggers a save (manual save, checkpoint, autosave event). Never auto-save game state on every frame or every change.

### [MANDATE] Save format: JSON for readability, binary for security

Use JSON (human-readable) during development and for single-player releases. Switch to encrypted binary (`FileAccess.open_encrypted_with_pass`) for multiplayer or competitive contexts where anti-cheat matters. Settings always use ConfigFile (INI-like), never JSON.

### [MANDATE] Always include version number in save data for migration

Every save file must contain a `"version": N` key at the root level. Without it, migration is impossible and old saves become dead data. Increment the version whenever the save schema changes.

### [MANDATE] user:// for saves, never res://

`res://` is read-only in exported builds. All persistence (settings, saves, logs) goes to `user://`. Debug the real path with `OS.get_user_data_dir()`.

| OS | user:// resolves to |
|---------|---------------------------------------------|
| Windows | `%APPDATA%/Godot/app_userdata/<project>/` |
| macOS | `~/Library/Application Support/Godot/app_userdata/<project>/` |
| Linux | `~/.local/share/godot/app_userdata/<project>/` |

---

## Patterns

### [PATTERN] Settings persistence — ConfigFile autoload

ConfigFile gives you INI-like sections, human-readable output, and a fail-safe API. Every setting must have a default defined in code.

```gdscript
# settings_manager.gd — Autoload
extends Node

const SETTINGS_PATH = "user://settings.cfg"

var _config := ConfigFile.new()
var _defaults := {
    "audio/master_volume": 1.0,
    "audio/music_volume": 0.8,
    "audio/sfx_volume": 1.0,
    "audio/mute": false,
    "graphics/fullscreen": false,
    "graphics/vsync": true,
    "graphics/quality": "medium",
    "controls/mouse_sensitivity": 0.5,
}

func _ready():
    _load_settings()

func get_setting(key: String) -> Variant:
    var parts := key.split("/")
    return _config.get_value(parts[0], parts[1], _defaults.get(key))

func set_setting(key: String, value: Variant) -> void:
    var parts := key.split("/")
    _config.set_value(parts[0], parts[1], value)
    _config.save(SETTINGS_PATH)  # Immediate persist — MANDATE

func reset_to_defaults() -> void:
    _config = ConfigFile.new()
    for key in _defaults:
        var parts := key.split("/")
        _config.set_value(parts[0], parts[1], _defaults[key])
    _config.save(SETTINGS_PATH)

func _load_settings() -> void:
    if _config.load(SETTINGS_PATH) != OK:
        reset_to_defaults()
```

### [PATTERN] Game state save/load — saveable group

Nodes that participate in saves join the `"saveable"` group and expose `save_data() -> Dictionary` / `load_data(data: Dictionary)`. The save system collects and restores them.

```gdscript
# save_system.gd — Autoload
extends Node

const SAVE_DIR := "user://saves/"
const SAVE_EXT := ".json"
var CURRENT_VERSION := 1

func _ready() -> void:
    DirAccess.make_dir_recursive_absolute(SAVE_DIR)

func save_game(slot: int = 0) -> bool:
    var save_data := {
        "version": CURRENT_VERSION,
        "timestamp": Time.get_datetime_string_from_system(),
        "scene": get_tree().current_scene.scene_file_path,
        "nodes": {},
    }
    for node in get_tree().get_nodes_in_group("saveable"):
        if node.has_method("save_data"):
            save_data["nodes"][node.get_path()] = node.save_data()

    var path := SAVE_DIR + "save_" + str(slot) + SAVE_EXT
    var file := FileAccess.open(path, FileAccess.WRITE)
    if not file:
        push_error("Cannot open save file: " + path)
        return false
    file.store_string(JSON.stringify(save_data, "\t"))
    return true

func load_game(slot: int = 0) -> bool:
    var path := SAVE_DIR + "save_" + str(slot) + SAVE_EXT
    var file := FileAccess.open(path, FileAccess.READ)
    if not file:
        push_error("Save file not found: " + path)
        return false

    var json := JSON.new()
    if json.parse(file.get_as_text()) != OK:
        push_error("Corrupted save: " + json.get_error_message())
        return false

    var save_data: Dictionary = json.data
    if save_data.get("version", 1) < CURRENT_VERSION:
        save_data = _migrate(save_data)
        if save_data.is_empty():
            return false

    get_tree().change_scene_to_file(save_data["scene"])
    await get_tree().tree_changed

    for node_path in save_data["nodes"]:
        var node := get_node_or_null(node_path)
        if node and node.has_method("load_data"):
            node.load_data(save_data["nodes"][node_path])
    return true

func has_save(slot: int = 0) -> bool:
    return FileAccess.file_exists(SAVE_DIR + "save_" + str(slot) + SAVE_EXT)

func delete_save(slot: int = 0) -> void:
    var path := SAVE_DIR + "save_" + str(slot) + SAVE_EXT
    if FileAccess.file_exists(path):
        DirAccess.remove_absolute(path)
```

Saveable node example:

```gdscript
extends CharacterBody2D

var health := 100
var inventory: Array = []

func _ready() -> void:
    add_to_group("saveable")

func save_data() -> Dictionary:
    return {
        "position_x": global_position.x,
        "position_y": global_position.y,
        "health": health,
        "inventory": inventory,
    }

func load_data(data: Dictionary) -> void:
    global_position = Vector2(data["position_x"], data["position_y"])
    health = data.get("health", 100)
    inventory = data.get("inventory", [])
```

### [PATTERN] Save slots with metadata

Each slot is a separate file. Expose metadata (timestamp, scene, playtime) for the save/load UI without loading the full data.

```gdscript
func get_slot_info(slot: int) -> Dictionary:
    var path := SAVE_DIR + "save_" + str(slot) + SAVE_EXT
    if not FileAccess.file_exists(path):
        return {"empty": true}

    var file := FileAccess.open(path, FileAccess.READ)
    var json := JSON.new()
    if json.parse(file.get_as_text()) != OK:
        return {"empty": true, "corrupted": true}

    var data: Dictionary = json.data
    return {
        "empty": false,
        "timestamp": data.get("timestamp", ""),
        "scene": data.get("scene", ""),
        "playtime": data.get("playtime", 0),
    }
```

### [PATTERN] Version migration — sequential chain

Migrations run sequentially: v1 -> v2 -> v3 -> ... -> current. Each step is a pure function that transforms the dictionary. Never skip versions. Refuse to load saves from the future.

```gdscript
func _migrate(save_data: Dictionary) -> Dictionary:
    var version: int = save_data.get("version", 1)
    if version > CURRENT_VERSION:
        push_error("Save version %d > current %d. Refusing to load." % [version, CURRENT_VERSION])
        return {}

    while version < CURRENT_VERSION:
        match version:
            1: save_data = _migrate_v1_to_v2(save_data)
            2: save_data = _migrate_v2_to_v3(save_data)
        version += 1

    save_data["version"] = CURRENT_VERSION
    return save_data

func _migrate_v1_to_v2(data: Dictionary) -> Dictionary:
    # Example: rename "hp" -> "health", add default "mana"
    for path in data.get("nodes", {}):
        var nd: Dictionary = data["nodes"][path]
        if "hp" in nd:
            nd["health"] = nd["hp"]
            nd.erase("hp")
        if "mana" not in nd:
            nd["mana"] = 100
    data["version"] = 2
    return data
```

### [PATTERN] JSON serialization helpers for Godot types

JSON does not support Vector2, Vector3, or Color natively. Convert them explicitly.

```gdscript
class_name SaveUtils

static func vec2_to_dict(v: Vector2) -> Dictionary:
    return {"x": v.x, "y": v.y}

static func dict_to_vec2(d: Dictionary) -> Vector2:
    return Vector2(d["x"], d["y"])

static func vec3_to_dict(v: Vector3) -> Dictionary:
    return {"x": v.x, "y": v.y, "z": v.z}

static func dict_to_vec3(d: Dictionary) -> Vector3:
    return Vector3(d["x"], d["y"], d["z"])

static func color_to_dict(c: Color) -> Dictionary:
    return {"r": c.r, "g": c.g, "b": c.b, "a": c.a}

static func dict_to_color(d: Dictionary) -> Color:
    return Color(d["r"], d["g"], d["b"], d["a"])
```

---

## Anti-patterns

### [ANTI-PATTERN] Saving to res://

`res://` is read-only in exported builds. The write fails silently — no crash, no error in the console, just data that never persists. Always use `user://`.

### [ANTI-PATTERN] No version field in save data

Without `"version": N`, you cannot migrate old saves when the schema changes. Players lose their progress or get corrupted loads. Include it from day one.

### [ANTI-PATTERN] Storing node paths or references

Node paths break when the scene tree is restructured. Signals, resources, and full node references cannot be serialized. Save **data** (positions, stats, flags), not **structure** (paths, nodes, resources).

### [ANTI-PATTERN] JSON.parse without error check

If the save file is corrupted or hand-edited badly, `JSON.parse()` returns an error code. Ignoring it leads to null access crashes. Always check the return value.

```gdscript
# Wrong
json.parse(file.get_as_text())
var data = json.data  # null if parse failed -> crash

# Right
if json.parse(file.get_as_text()) != OK:
    push_error("Corrupted save: " + json.get_error_message())
    return false
```

### [ANTI-PATTERN] Saving entire Resources as JSON

JSON cannot serialize Godot Resources. Save the `resource_path` string and `load()` it back. If the resource is dynamic (not on disk), serialize its individual properties.

### [ANTI-PATTERN] Trusting client-side encryption as security

`FileAccess.open_encrypted_with_pass` deters casual cheaters but a determined player can dump RAM or reverse the binary. Treat it as a deterrent, not a guarantee. Real anti-cheat requires server-side validation.
