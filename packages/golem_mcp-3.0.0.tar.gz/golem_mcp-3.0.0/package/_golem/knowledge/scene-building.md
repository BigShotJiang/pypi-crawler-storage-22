# Scene Building — Knowledge

## Mandates

### [MANDATE] Never edit .tscn on disk

Godot keeps its own in-memory state. Any disk edit to `.tscn` or `project.godot` is silently overwritten on the next save. Always use the MCP API (`godot_add_node`, `godot_update_property`, `godot_delete_node`) followed by `godot_save_scene`.

Scripts (`.gd`) are the exception — Godot auto-reloads them on disk change.

### [MANDATE] Scene change sequence: stop -> API -> save -> verify -> play

Every scene modification follows this exact order:

```
godot_stop_scene
  -> godot_add_node / godot_update_property / godot_delete_node (as many as needed)
    -> godot_save_scene
      -> godot_get_scene_tree  (verify structure)
        -> godot_play_scene
```

Breaking this order causes data loss, stale state, or crashes. Notably:
- Calling `play_scene` immediately after `stop_scene` can fail ("A scene is already running"). Insert an intermediate operation (e.g. `get_errors`, `Read`) to let Godot tear down.
- Never skip `save_scene` — unsaved changes are lost.
- Never skip `get_scene_tree` — silent failures happen (nodes not added, properties not set).

### [MANDATE] global_position only AFTER add_child()

Setting `global_position` on a node that is not yet in the scene tree is silently ignored. Store the position in a variable, then apply it in `_ready()` or after the `add_child()` call.

```gdscript
# WRONG — position is lost
var enemy := Enemy.new()
enemy.global_position = Vector2(400, 300)
add_child(enemy)

# RIGHT — position applied after tree entry
var enemy := Enemy.new()
add_child(enemy)
enemy.global_position = Vector2(400, 300)

# ALSO RIGHT — deferred via _ready()
var spawn_pos: Vector2
func _ready():
    global_position = spawn_pos
```

### [MANDATE] Every physics body needs a CollisionShape child

A `CharacterBody2D`, `StaticBody2D`, `RigidBody2D`, or `Area2D` without a `CollisionShape2D` child does nothing — no collisions, no physics, no signal triggers. Always add one.

```
CharacterBody2D
  ├── CollisionShape2D (with a shape resource assigned)
  ├── Sprite2D or AnimatedSprite2D
```

### [MANDATE] Root node path is ".", not its name

The root of the currently edited scene is always referenced as `"."`. Children are `"Player"`, grandchildren `"Player/Sprite"`. Using the root's actual name (e.g. `"Main"`) returns "Node not found".

### [MANDATE] add_child() during physics flush = crash

If a signal fires during physics processing (e.g. `enemy_died` -> spawn loot `Area2D`), calling `add_child()` directly crashes with "Can't change this state while flushing queries". Always use `call_deferred`:

```gdscript
container.call_deferred("add_child", node)
```

### [MANDATE] set_owner must be recursive when instancing PackedScenes

`instance.owner = root` only sets ownership on the instance root. All descendants need it too, or `save_scene` silently drops them. Use iterative traversal (not recursion — stack overflow risk on large scenes):

```gdscript
var stack: Array[Node] = [instance]
while stack.size() > 0:
    var node: Node = stack.pop_back()
    node.owner = root
    for child in node.get_children():
        stack.push_back(child)
```

### [MANDATE] Use containers for UI layout — never manual positioning

UI scenes must use `VBoxContainer`, `HBoxContainer`, `CenterContainer`, `MarginContainer`, etc. Manually setting `position` on Control nodes breaks at different resolutions and is unmaintainable.

---

## Patterns

### [PATTERN] Scene type -> Root node selection

| Scene type | Root node | Notes |
|------------|-----------|-------|
| 2D game | `Node2D` | Children: `CharacterBody2D`, `StaticBody2D`, `Area2D`, etc. |
| 3D game | `Node3D` | Children: `CharacterBody3D`, `MeshInstance3D`, etc. |
| UI / Menu | `Control` | Use containers for layout. Never position manually. |
| 2D level | `Node2D` | `TileMapLayer` for tile-based levels. |
| 3D level | `Node3D` | `GridMap` for block-based levels. |
| Game + UI overlay | `Node2D`/`Node3D` | Add a `CanvasLayer` child for the UI layer. |

### [PATTERN] Platformer character

```json
{"name": "Player", "type": "CharacterBody2D", "children": [
  {"name": "PlayerSprite", "type": "Sprite2D"},
  {"name": "PlayerCollision", "type": "CollisionShape2D"},
  {"name": "Camera", "type": "Camera2D"}
]}
```

### [PATTERN] UI menu

```json
{"name": "Menu", "type": "CenterContainer", "children": [
  {"name": "VBox", "type": "VBoxContainer", "children": [
    {"name": "Title", "type": "Label"},
    {"name": "PlayButton", "type": "Button"},
    {"name": "QuitButton", "type": "Button"}
  ]}
]}
```

### [PATTERN] Top-down game with HUD

```json
[
  {"name": "Player", "type": "CharacterBody2D", "children": [
    {"name": "PlayerSprite", "type": "Sprite2D"},
    {"name": "PlayerCollision", "type": "CollisionShape2D"}
  ]},
  {"name": "Enemies", "type": "Node2D"},
  {"name": "UI", "type": "CanvasLayer", "children": [
    {"name": "HUD", "type": "Control", "children": [
      {"name": "HealthBar", "type": "ProgressBar"},
      {"name": "ScoreLabel", "type": "Label"}
    ]}
  ]}
]
```

### [PATTERN] Collision layers convention

| Layer | Usage | Example |
|-------|-------|---------|
| 1 | Player | Player's CharacterBody2D |
| 2 | Enemies | All enemy bodies |
| 3 | World | StaticBody2D, walls, floor |
| 4 | Projectiles | Bullets, arrows, spells |
| 5 | Pickups | Collectible items, loot |
| 6 | Triggers | Area2D zones (spawn, dialogue, transition) |

`collision_layer` = "I exist on these layers" (identity).
`collision_mask` = "I detect these layers" (perception).

In GDScript, always use the explicit setters:

```gdscript
set_collision_layer_value(2, true)   # I am an enemy
set_collision_mask_value(1, true)    # I detect the player
set_collision_mask_value(3, true)    # I detect the world
```

### [PATTERN] Canvas positioning (2D)

Origin `(0, 0)` is the top-left corner. Y axis goes down.

| Target position | Formula | Example (1920x1080) |
|-----------------|---------|---------------------|
| Screen center | `viewport_size / 2` | `(960, 540)` |
| Top-left | `(0, 0)` | `(0, 0)` |
| Bottom-right | `viewport_size` | `(1920, 1080)` |
| Center horizontal, 80% down | `(viewport_w / 2, viewport_h * 0.8)` | `(960, 864)` |

Rule: if you place a game node at `(0, 0)`, pause — is the top-left corner really the intended position? For gameplay entities, screen center is almost always the right initial placement.

### [PATTERN] Camera2D for fixed-viewport games

For 2D games with a fixed viewport (Pong, puzzle, card games), Camera2D defaults can mislead:

| Situation | Problem | Solution |
|-----------|---------|----------|
| Content from (0,0) to viewport_size | `DRAG_CENTER` (default) at (0,0) shows negative coords | Position camera at `(viewport_w/2, viewport_h/2)`, or use `FIXED_TOP_LEFT` |
| No scrolling | Camera follows position, shifts everything | `anchor_mode = FIXED_TOP_LEFT` + position `(0,0)` |
| Screenshake | Modifying `position` breaks framing | Use `offset` for shake, never `position` |

```gdscript
extends Camera2D

func _ready():
    anchor_mode = Camera2D.ANCHOR_MODE_FIXED_TOP_LEFT
    position = Vector2.ZERO

func shake(intensity: float):
    offset = Vector2(randf_range(-1, 1), randf_range(-1, 1)) * intensity
```

### [PATTERN] Instance a PackedScene as sub-scene (editor context)

```gdscript
# 1. Load and instance with editor state
var packed: PackedScene = load("res://scenes/dungeon.tscn")
var instance: Node = packed.instantiate(PackedScene.GEN_EDIT_STATE_INSTANCE)

# 2. Add to scene tree
var root: Node = get_editor_interface().get_edited_scene_root()
root.add_child(instance)

# 3. CRITICAL — set_owner recursively on ALL descendants (see [MANDATE] above)
var stack: Array[Node] = [instance]
while stack.size() > 0:
    var node: Node = stack.pop_back()
    node.owner = root
    for child in node.get_children():
        stack.push_back(child)

# 4. Remove unwanted nodes — use .free() NOT queue_free()
# queue_free() defers to end of frame; save_scene in the same frame still sees the node
var cam: Node = instance.get_node_or_null("Camera3D")
if cam:
    cam.free()

# 5. Save
get_editor_interface().save_scene()
```

Key: `GEN_EDIT_STATE_INSTANCE` keeps the sub-scene as a reference (editable instance). Without it, all nodes are flattened inline into the parent .tscn.

### [PATTERN] Script template structure

Every script should include:
- `extends` matching the node type
- Typed variable declarations at the top
- `_ready()` for initialization
- `_process(delta)` or `_physics_process(delta)` as needed
- `GolemCapture.game_log()` instead of `print()` for output visible via `godot_get_logs`

### [PATTERN] Naming conventions

- **Node names**: PascalCase — `PlayerSprite`, `EnemyCollision`, `MainMenu`
- **Scripts match their node**: `player.gd` for `Player`, `main_menu.gd` for `MainMenu`
- **Scene files**: `res://scenes/scene_name.tscn`
- **Scripts**: `res://scripts/script_name.gd` or alongside the scene

---

## MCP Tool Sequences

### Create a scene from scratch

```
1. godot_create_scene(root_type="Node2D", path="res://scenes/level.tscn")
2. godot_add_nodes(nodes=[...])          # batch — always prefer over individual add_node
3. godot_update_property(...)             # set shapes, colors, positions, etc.
4. godot_write_script(path="res://scripts/player.gd", content="...")
5. godot_attach_script(node_path="Player", script_path="res://scripts/player.gd")
6. godot_save_scene()
7. godot_get_scene_tree()                 # verify
```

### Set a Resource property (e.g. collision shape)

```
godot_update_property(
  path="Player/PlayerCollision",
  property="shape",
  value={"type": "RectangleShape2D", "properties": {"size": [32, 64]}}
)
```

### Set a color

```
godot_update_property(path="Background", property="color", value="#1a1a2e")
```

### Set a Vector2

```
godot_update_property(path="Player", property="position", value=[100, 300])
```

### Assign a Resource (texture, material, theme)

`add_nodes` does NOT `load()` Resources — passing `"texture": "res://img.png"` results in null. Always assign Resources via `execute_script` after node creation:

```
godot_execute_script(code='get_editor_interface().get_edited_scene_root().get_node("Sprite").texture = load("res://icon.svg")')
```

### Set main scene

```
godot_project_settings(
  action="set",
  key="application/run/main_scene",
  value="res://scenes/main.tscn"
)
```

### Modify a source scene (not an instance)

When a property on an instanced node in a parent scene doesn't stick, modify the source:

```
1. godot_open_scene("res://scenes/player.tscn")
2. godot_update_property(path=".", property="...", value=...)
3. godot_save_scene()
4. godot_open_scene("res://scenes/arena.tscn")   # return to parent
```

### Full play-test cycle

```
1. godot_stop_scene()
2. (make changes via API)
3. godot_save_scene()
4. godot_get_scene_tree()                  # verify structure
5. godot_play_scene()
6. (wait a moment)
7. godot_get_logs()                        # check runtime output
8. godot_get_game_screenshot()             # visual check (one attempt only, no retry)
```

---

## Anti-patterns

### [ANTI-PATTERN] Editing .tscn files with Write or Edit tools

Godot keeps scene state in memory. Disk edits are overwritten on save. This also leaves orphaned `ext_resource` entries. Always use the MCP API.

### [ANTI-PATTERN] Using godot_add_node in a loop instead of godot_add_nodes

`godot_add_nodes` (batch) creates the entire hierarchy in one call. Using individual `godot_add_node` calls is slower, more error-prone, and generates unnecessary TCP round-trips.

### [ANTI-PATTERN] Setting collision_mask as a raw integer

`collision_mask = 4` enables layer 3 (bit 3), NOT layer 4. This is a bitmask, not a layer number. Use the explicit setters:

```gdscript
# WRONG
collision_mask = 4  # activates layer 3, not layer 4

# RIGHT
set_collision_mask_value(4, true)  # activates layer 4
```

Via MCP:
```
godot_update_property(path="Enemy", property="collision_layer", value=2)
```
Note: `update_property` with an integer sets the raw bitmask. For precise control, use `execute_script` with `set_collision_layer_value()`.

### [ANTI-PATTERN] Positioning game entities at (0, 0)

`(0, 0)` is the top-left corner in Godot 2D. Placing a player, enemy, or spawn point there is almost never intentional. Default to screen center (`viewport_size / 2`) for gameplay entities.

### [ANTI-PATTERN] Using anchors_preset without resetting offsets

`set_anchors_preset(PRESET_FULL_RECT)` changes anchors but NOT offsets. The Control node won't actually fill its parent. Always reset offsets too:

```
offset_left = 0
offset_top = 0
offset_right = 0
offset_bottom = 0
```

Or use `set_anchors_and_offsets_preset()` which does both.

### [ANTI-PATTERN] Expecting update_property to persist on imported scenes (FBX/GLB)

`godot_update_property` on a node inherited from an FBX/GLB import returns OK. `godot_save_scene` returns OK. `godot_inspect_node` confirms the new value. But at runtime, the old value is used. Godot refuses to write property overrides on imported scene nodes into the .tscn.

`inspect_node` gives a false positive (it reads editor memory, not disk).

**Diagnostic**: `grep property_name file.tscn` — if the override isn't in the file, it won't be at runtime.
**Fix**: set the property in `_ready()` of an attached GDScript.

### [ANTI-PATTERN] Using PRESET_CENTER on VBoxContainer

`PRESET_CENTER` does not work for `VBoxContainer`. Use `PRESET_FULL_RECT` + `alignment = ALIGNMENT_CENTER`.

### [ANTI-PATTERN] Retrying game screenshots

The JPEG encode + base64 is several MB over TCP. Retrying on failure triggers connection storms. One attempt only. If it fails, fall back to `godot_get_logs` or ask the user.

### [ANTI-PATTERN] Using queue_free() in editor scripts

In editor context (`execute_script`), `queue_free()` defers deletion to end of frame. If `save_scene` runs in the same frame, the "deleted" node is still present. Use `.free()` for immediate removal.

### [ANTI-PATTERN] Forgetting GEN_EDIT_STATE_INSTANCE when instancing sub-scenes

Without `PackedScene.GEN_EDIT_STATE_INSTANCE`, the instanced scene's nodes are flattened inline into the parent .tscn instead of kept as a scene reference. This bloats the parent file and breaks the source-instance relationship.

### [ANTI-PATTERN] Using := on Variant sources

`:=` type inference fails on `Array`, `Dictionary`, ternary expressions, and `.duplicate()`. Use explicit typing:

```gdscript
# WRONG
var items := some_array.duplicate()

# RIGHT
var items: Array = some_array.duplicate()
```
