# Theme Tokens — Knowledge

Design token system via Godot 4.x Theme resource. All visual values (colors, spacing, fonts, radii) live in a single `.tres` Theme — no magic numbers scattered across scripts.

---

## Mandates

[MANDATE] **Design tokens live in Theme resource, not hardcoded in scripts.**
Every color, font size, spacing value, and radius must be defined as a named token in the Theme. No `Color("#3a7bd5")` in GDScript — always reference the palette through the Theme resource.

[MANDATE] **`get_theme_stylebox().duplicate()` before modifying.**
StyleBox resources are shared. If you grab one from the theme and mutate it directly, you corrupt every node using that StyleBox. Always `.duplicate()` first.

[MANDATE] **Base theme on root Control node, propagates to children.**
Set the Theme on the topmost Control (or via `gui/theme/custom` project setting). Child nodes inherit automatically — don't re-assign the Theme on every node.

[MANDATE] **All Button states must be defined.** Normal, hover, pressed, disabled, focus. No missing state. Focus must be visually clear for keyboard/gamepad navigation (accent border, not a subtle color shift).

[MANDATE] **Save as `.tres`, not `.res`.** Keeps the file human-readable and diffable in version control.

[MANDATE] **No `add_theme_*_override` when the Theme can handle it.** Overrides are for one-off exceptions, not the design system. If you find yourself overriding the same property on multiple nodes, it belongs in the Theme.

---

## Theme Structure

### How Godot Theme resources work

A Theme is a Resource (`.tres`) that maps `(property_name, node_type)` pairs to values. Godot Control nodes look up their visual properties through this mapping.

**Property types in a Theme:**

| Type | API | Example |
|------|-----|---------|
| Color | `theme.set_color(name, type, value)` | `set_color("font_color", "Label", Color("#e8e8e8"))` |
| Font | `theme.set_font(name, type, value)` | `set_font("font", "Button", loaded_font)` |
| Font size | `theme.set_font_size(name, type, value)` | `set_font_size("font_size", "Label", 16)` |
| Constant | `theme.set_constant(name, type, value)` | `set_constant("separation", "VBoxContainer", 16)` |
| StyleBox | `theme.set_stylebox(name, type, value)` | `set_stylebox("normal", "Button", stylebox)` |
| Icon | `theme.set_icon(name, type, value)` | `set_icon("checked", "CheckBox", texture)` |

**Inheritance chain:** Node checks its own theme overrides first, then walks up the tree looking for a Theme resource on parent Controls, then falls back to the project-level theme (`gui/theme/custom`), then Godot's built-in default theme.

**One Theme per project** unless you explicitly need multiple (dark/light toggle, per-world skin). Start with one, split later if needed.

### Applying the Theme globally

```
godot_project_settings(action="set", key="gui/theme/custom", value="res://theme.tres")
```

---

## Patterns

### [PATTERN] Color token palette

Define a named palette. Every value has a role — no unnamed hex values.

| Token | Role | Dark example | Light example |
|-------|------|-------------|---------------|
| `bg` | Main background | `#0f0f1a` | `#f5f5f5` |
| `surface` | Panels, cards | `#1a1a2e` | `#ffffff` |
| `surface_variant` | Secondary cards | `#252540` | `#e8e8e8` |
| `text_primary` | Primary text | `#e8e8e8` | `#1a1a1a` |
| `text_secondary` | Secondary text | `#8888aa` | `#666666` |
| `text_disabled` | Inactive text | `#555566` | `#aaaaaa` |
| `accent` | Accent, focus rings | `#4a9eff` | `#2563eb` |
| `btn_bg` | Button resting | `#2a2a4a` | `#e0e0e0` |
| `btn_hover` | Button hover | `#3a3a5a` | `#d0d0d0` |
| `btn_pressed` | Button pressed | `#1a1a3a` | `#c0c0c0` |
| `btn_disabled_bg` | Button disabled | `#1a1a2e` | `#f0f0f0` |
| `input_bg` | Input field bg | `#151528` | `#ffffff` |
| `input_border` | Input border | `#333355` | `#cccccc` |
| `status_success` | Success | `#4ade80` | `#16a34a` |
| `status_warning` | Warning | `#facc15` | `#ca8a04` |
| `status_error` | Error | `#f87171` | `#dc2626` |

Contrast requirement: text on background must be >= 4.5:1 ratio for primary text.

### [PATTERN] Spacing, radius, and typography tokens

| Token | Value | Usage |
|-------|-------|-------|
| `space_xs` | 4 | Micro-gaps (icon-text) |
| `space_sm` | 8 | Light internal padding |
| `space_md` | 16 | Standard separation |
| `space_lg` | 24 | Section separation |
| `space_xl` | 32 | Large separation |
| `space_2xl` | 40 | Page margins |
| `space_3xl` | 48 | Hero spacing |
| `radius_sm` | 6 | Small elements (badges, tags) |
| `radius_md` | 10 | Standard elements (buttons, inputs) |
| `radius_lg` | 14 | Large elements (cards) |
| `radius_xl` | 18 | Extra large elements (modals) |
| `type_caption` | 12 | Captions, hints |
| `type_body` | 16 | Body text |
| `type_subtitle` | 18 | Subtitles |
| `type_big` | 20 | Secondary titles |
| `type_title` | 24 | Titles |
| `type_hero` | 32 | Hero titles |
| `type_display` | 48 | Display elements |

### [PATTERN] StyleBox creation — Button with all states

```gdscript
# Normal state
var btn_normal = StyleBoxFlat.new()
btn_normal.bg_color = Color("#2a2a4a")
btn_normal.corner_radius_top_left = 10
btn_normal.corner_radius_top_right = 10
btn_normal.corner_radius_bottom_left = 10
btn_normal.corner_radius_bottom_right = 10
btn_normal.content_margin_left = 16
btn_normal.content_margin_right = 16
btn_normal.content_margin_top = 8
btn_normal.content_margin_bottom = 8
theme.set_stylebox("normal", "Button", btn_normal)

# Hover — duplicate, change bg
var btn_hover = btn_normal.duplicate()
btn_hover.bg_color = Color("#3a3a5a")
theme.set_stylebox("hover", "Button", btn_hover)

# Pressed — duplicate, change bg
var btn_pressed = btn_normal.duplicate()
btn_pressed.bg_color = Color("#1a1a3a")
theme.set_stylebox("pressed", "Button", btn_pressed)

# Disabled — duplicate, change bg + set disabled font color
var btn_disabled = btn_normal.duplicate()
btn_disabled.bg_color = Color("#1a1a2e")
theme.set_stylebox("disabled", "Button", btn_disabled)
theme.set_color("font_disabled_color", "Button", Color("#555566"))

# Focus — separate StyleBox with accent border
var btn_focus = StyleBoxFlat.new()
btn_focus.bg_color = Color.TRANSPARENT
btn_focus.border_color = Color("#4a9eff")
btn_focus.border_width_bottom = 2
btn_focus.border_width_top = 2
btn_focus.border_width_left = 2
btn_focus.border_width_right = 2
btn_focus.corner_radius_top_left = 10
btn_focus.corner_radius_top_right = 10
btn_focus.corner_radius_bottom_left = 10
btn_focus.corner_radius_bottom_right = 10
theme.set_stylebox("focus", "Button", btn_focus)
```

### [PATTERN] StyleBox — Panel with border

```gdscript
var style = StyleBoxFlat.new()
style.bg_color = Color("#1a1a2e")
style.border_color = Color("#333355")
style.border_width_bottom = 1
style.border_width_top = 1
style.border_width_left = 1
style.border_width_right = 1
style.corner_radius_top_left = 10
style.corner_radius_top_right = 10
style.corner_radius_bottom_left = 10
style.corner_radius_bottom_right = 10
```

### [PATTERN] StyleBox — Panel with shadow

```gdscript
var style = StyleBoxFlat.new()
style.bg_color = Color("#1a1a2e")
style.shadow_color = Color(0, 0, 0, 0.3)
style.shadow_size = 4
style.shadow_offset = Vector2(0, 2)
```

### [PATTERN] StyleBoxEmpty — Strip default styling

```gdscript
var empty = StyleBoxEmpty.new()
theme.set_stylebox("panel", "PanelContainer", empty)
```

### [PATTERN] LineEdit with normal + focus states

```gdscript
var lineedit_normal = StyleBoxFlat.new()
lineedit_normal.bg_color = Color("#151528")
lineedit_normal.border_color = Color("#333355")
lineedit_normal.border_width_bottom = 1
lineedit_normal.border_width_top = 1
lineedit_normal.border_width_left = 1
lineedit_normal.border_width_right = 1
lineedit_normal.corner_radius_top_left = 10
lineedit_normal.corner_radius_top_right = 10
lineedit_normal.corner_radius_bottom_left = 10
lineedit_normal.corner_radius_bottom_right = 10
lineedit_normal.content_margin_left = 12
lineedit_normal.content_margin_right = 12
lineedit_normal.content_margin_top = 8
lineedit_normal.content_margin_bottom = 8
theme.set_stylebox("normal", "LineEdit", lineedit_normal)

var lineedit_focus = lineedit_normal.duplicate()
lineedit_focus.border_color = Color("#4a9eff")
lineedit_focus.border_width_bottom = 2
lineedit_focus.border_width_top = 2
lineedit_focus.border_width_left = 2
lineedit_focus.border_width_right = 2
theme.set_stylebox("focus", "LineEdit", lineedit_focus)
```

### [PATTERN] Font setup

```gdscript
var theme = load("res://theme.tres")
var font = load("res://fonts/my_font.ttf")
theme.set_font("font", "Label", font)
theme.set_font("font", "Button", font)
theme.set_font("font", "LineEdit", font)
theme.set_font("font", "RichTextLabel", font)
ResourceSaver.save(theme, "res://theme.tres")
```

Font sources:
- **Open source display/body fonts:** [freefaces.gallery](https://freefaces.gallery)
- **Pixel fonts:** Use `.ttf` pixel art fonts (not bitmap). Import as-is into `res://fonts/`.

### [PATTERN] Container spacing via Theme constants

```gdscript
theme.set_constant("separation", "VBoxContainer", 16)
theme.set_constant("separation", "HBoxContainer", 8)
theme.set_constant("margin_left", "MarginContainer", 24)
theme.set_constant("margin_right", "MarginContainer", 24)
theme.set_constant("margin_top", "MarginContainer", 24)
theme.set_constant("margin_bottom", "MarginContainer", 24)
```

### [PATTERN] Full Theme creation via MCP execute_script

```
godot_execute_script(code="""
var theme = Theme.new()

# Colors
theme.set_color("font_color", "Label", Color("#e8e8e8"))
theme.set_color("font_color", "Button", Color("#e8e8e8"))
theme.set_color("font_color", "LineEdit", Color("#e8e8e8"))

# Font sizes
theme.set_font_size("font_size", "Label", 16)
theme.set_font_size("font_size", "Button", 16)
theme.set_font_size("font_size", "LineEdit", 16)

# Constants
theme.set_constant("separation", "VBoxContainer", 16)
theme.set_constant("separation", "HBoxContainer", 8)
theme.set_constant("margin_left", "MarginContainer", 24)
theme.set_constant("margin_right", "MarginContainer", 24)
theme.set_constant("margin_top", "MarginContainer", 24)
theme.set_constant("margin_bottom", "MarginContainer", 24)

# StyleBoxes (panel, button states, input states...)
# ... (see patterns above for full examples)

ResourceSaver.save(theme, "res://theme.tres")
return "Theme saved to res://theme.tres"
""")
```

Then apply globally:

```
godot_project_settings(action="set", key="gui/theme/custom", value="res://theme.tres")
```

---

## MCP Theme Tool

There is no dedicated `godot_create_theme` MCP tool. Theme creation goes through `godot_execute_script` — you write the GDScript that builds the Theme resource, sets all tokens, and saves the `.tres` file.

**Workflow:**

1. **Create the Theme** via `godot_execute_script` with `Theme.new()`, set all colors/fonts/constants/styleboxes, then `ResourceSaver.save()`.
2. **Apply globally** via `godot_project_settings(action="set", key="gui/theme/custom", value="res://theme.tres")`.
3. **Add fonts** with a second `godot_execute_script` that loads the `.tres`, loads the `.ttf`, assigns via `set_font()`, and re-saves.
4. **Verify** with `godot_get_editor_screenshot` — check palette consistency, text hierarchy, button states, and contrast.

**Verification checklist:**
- Colors follow the defined palette?
- Text sizes create a readable hierarchy?
- All Button states present (normal, hover, pressed, disabled, focus)?
- Text/background contrast >= 4.5:1?

---

## Anti-patterns

[ANTI-PATTERN] **Hardcoded colors in GDScript.**
`label.add_theme_color_override("font_color", Color("#ff0000"))` scattered across scripts. If the palette changes, you hunt through every file. Put it in the Theme.

[ANTI-PATTERN] **Mutating a shared StyleBox without `.duplicate()`.**
```gdscript
# WRONG — corrupts every node using this StyleBox
var style = get_theme_stylebox("panel")
style.bg_color = Color.RED

# CORRECT
var style = get_theme_stylebox("panel").duplicate()
style.bg_color = Color.RED
add_theme_stylebox_override("panel", style)
```

[ANTI-PATTERN] **Missing Button states.**
Defining only `normal` and `hover` but forgetting `pressed`, `disabled`, and `focus`. The button looks broken on gamepad navigation (no focus ring) and when disabled (falls back to Godot's default gray).

[ANTI-PATTERN] **Saving Theme as `.res` instead of `.tres`.**
Binary `.res` is not human-readable, not diffable, and harder to debug. Always use `.tres`.

[ANTI-PATTERN] **Multiple Themes without a reason.**
Creating a separate Theme per scene "just in case." Start with one project-wide Theme. Split only when you have a concrete need (dark/light mode, per-world skin).

[ANTI-PATTERN] **Setting Theme on every Control node.**
Assigning the Theme resource to each individual node instead of the root. The inheritance system exists — use it. Set the Theme on the topmost Control or via the project setting.

[ANTI-PATTERN] **Using `add_theme_*_override` as the default approach.**
Overrides bypass the Theme system. They are for one-off exceptions (a single button that needs a unique color). If you find the same override on 3+ nodes, it belongs in the Theme.
