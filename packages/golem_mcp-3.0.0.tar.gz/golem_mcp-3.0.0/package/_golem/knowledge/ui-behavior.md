# UI Behavior — Knowledge

State machines, tween patterns, focus management, and feedback loops for Godot 4.x UI.

---

## Mandates

### [MANDATE] Every interactive element needs hover + pressed + disabled states

No exceptions. A button, a card, a slot — if the player can interact with it, it must visually respond to `hover`, `pressed`, and `disabled`. Missing any of these makes the UI feel dead.

The full interaction state set:
| State | Trigger |
|-------|---------|
| `idle` | Default, no interaction |
| `hover` | Mouse enters |
| `focus` | Keyboard/gamepad focus |
| `pressed` | Mouse down or accept pressed |
| `disabled` | SystemState override — grayed out, non-interactive |

### [MANDATE] Tween during pause = PROCESS_MODE_ALWAYS + TWEEN_PAUSE_PROCESS

When `get_tree().paused = true` (pause menus, popups), tweens freeze by default. You need **both** conditions — one alone is not enough:

```gdscript
# On the node that creates the tween
process_mode = Node.PROCESS_MODE_ALWAYS

# On every tween created in that context
var tween := create_tween()
tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
```

### [MANDATE] get_theme_stylebox().duplicate() before modification

Theme StyleBoxes are shared resources. Modifying one without duplicating it mutates every node that uses that style.

```gdscript
# WRONG — mutates the shared resource
var style := get_theme_stylebox("normal")
style.bg_color = Color.RED  # Every node using "normal" is now red

# CORRECT — local copy
var style := get_theme_stylebox("normal").duplicate()
style.bg_color = Color.RED
add_theme_stylebox_override("normal", style)
```

### [MANDATE] Kill previous tweens before creating new ones

Tween accumulation is the #1 cause of jittery UI animations. Every state change must clean up active tweens first.

```gdscript
var _active_tweens: Array[Tween] = []

func _cleanup_tweens():
    for tween in _active_tweens:
        if tween.is_valid():
            tween.kill()
    _active_tweens.clear()

func _create_tween() -> Tween:
    var tween := create_tween()
    _active_tweens.append(tween)
    return tween
```

### [MANDATE] Animations never block interaction

The player must be able to act during a tween. Transitions are visual polish, not gates. If a tween is still playing when the player clicks, the tween gets interrupted — never the click.

---

## Patterns

### [PATTERN] 3-channel orthogonal state machine

UI state is a triplet `(SystemState, GameState, InteractionState)`. Three independent channels, combined:

**SystemState** (highest priority — overrides everything):
- `enabled` — normal, interactive
- `disabled` — grayed out, non-interactive (opacity 0.5)
- `hidden` — invisible, removed from layout (opacity 0.0)

**GameState** (game logic):
- `locked` — not yet unlocked (tinted gray)
- `unlockable` — condition close to being met
- `active` — available, usable
- `equipped` — selected/equipped (glow)
- `cooldown` — recharging (desaturated, radial mask)

**InteractionState** (player input):
- `idle` — rest
- `hover` — mouse over
- `focus` — keyboard/gamepad focus
- `pressed` — being clicked/pressed

**Dominance rule**: System > Game > Interaction. If `SystemState = disabled`, Game and Interaction visuals are overridden with the grayed-out look.

Example triplets:
- `(enabled, active, hover)` — button hovered, available
- `(enabled, cooldown, idle)` — skill recharging, no interaction
- `(disabled, locked, idle)` — grayed and locked
- `(enabled, equipped, focus)` — equipped item, gamepad focus

### [PATTERN] Channel-property ownership

Each visual property is controlled by exactly one channel. No conflicts, no fighting.

| Property | Primary channel | Secondary (additive only) |
|----------|----------------|--------------------------|
| **Scale** | InteractionState | — |
| **Outline** | InteractionState | — |
| **Emission/Glow** | GameState | InteractionState (+glow on hover) |
| **Tint/Color** | GameState | — |
| **Radial mask** | GameState | — |
| **Particles** | GameState | InteractionState (+sparks on hover) |
| **Sound trigger** | InteractionState | GameState (determines which sound) |
| **Opacity** | SystemState | — |

Rule: a channel NEVER touches another channel's property except in explicit additive mode.

### [PATTERN] Event-driven state transitions

State changes go through `emit_event(channel, event)`. Never set state directly.

InteractionState graph:
```
idle -> hover    (mouse_enter)
hover -> idle    (mouse_exit)
idle -> focus    (focus_entered, gamepad)
focus -> idle    (focus_exited)
hover -> pressed (mouse_down)
focus -> pressed (accept_pressed)
pressed -> hover (mouse_up, mouse still inside)
pressed -> idle  (mouse_up, mouse exited)
pressed -> focus (accept_released, gamepad)
```

GameState graph:
```
locked -> unlockable    (condition_progress)
unlockable -> active    (condition_met)
active -> equipped      (equip_action)
equipped -> active      (unequip_action)
active -> cooldown      (use_action)
cooldown -> active      (cooldown_end)
```

### [PATTERN] Conductor — orchestrating multi-component behavior

One Conductor per UI context (screen, panel). Declarative routing table maps events to actions on components by role.

```gdscript
extends Node
class_name UIConductor

## Routing table: {event_name: [{target_role, channel, event}]}
var _routes := {
    "item_selected": [
        {"role": "item_info", "channel": "system", "event": "show"},
        {"role": "equip_button", "channel": "system", "event": "enable"},
    ],
    "item_equipped": [
        {"role": "equipped_icon", "channel": "game", "event": "equip"},
        {"role": "equip_button", "channel": "game", "event": "equipped"},
    ],
}

var _components := {}

func _ready():
    _discover_components(get_parent())

func _discover_components(node: Node):
    if node.has_meta("role"):
        _components[node.get_meta("role")] = node
    for child in node.get_children():
        _discover_components(child)

func dispatch(event_name: String):
    if event_name not in _routes:
        return
    for action in _routes[event_name]:
        var comp = _components.get(action["role"])
        if comp and comp.has_method("emit_event"):
            comp.emit_event(action["channel"], action["event"])
```

Key rules:
- One Conductor per context — no God Object managing all UI
- Component absent = silent skip, no crash
- Inter-context communication goes through an EventBus autoload

### [PATTERN] Focus management for gamepad/keyboard

Focus must always be visible. Not a subtle glow — a frank outline that works on any background.

```gdscript
func _apply_interaction_focus():
    var focus_node = get_role("focus_outline")
    if focus_node:
        focus_node.visible = true

    # Subtle pulse loop for extra visibility
    var tween := _create_tween().set_loops()
    tween.tween_property(self, "modulate:a", 0.85, 0.6).set_ease(Tween.EASE_IN_OUT)
    tween.tween_property(self, "modulate:a", 1.0, 0.6).set_ease(Tween.EASE_IN_OUT)
```

### [PATTERN] Sound design with throttle

Sound events are tied to InteractionState but the sound content depends on GameState.

```gdscript
var _last_sound_time := {}
var _throttle := {"hover": 0.12, "focus": 0.08}

func play_sound(event: String, stream: AudioStream):
    var now := Time.get_ticks_msec() / 1000.0
    var min_interval: float = _throttle.get(event, 0.0)
    if event in _last_sound_time and now - _last_sound_time[event] < min_interval:
        return
    _last_sound_time[event] = now
    var player := AudioStreamPlayer.new()
    player.stream = stream
    player.bus = "UI"
    add_child(player)
    player.play()
    player.finished.connect(player.queue_free)
```

Sound timing reference:
| Event | Duration | Throttle |
|-------|----------|----------|
| hover | < 50ms | 120ms |
| focus | < 80ms | 80ms |
| pressed | < 100ms | none |
| equip | 200-400ms | none |
| cooldown_end | 100-200ms | none |
| error | 100-200ms | none |

Max 4 simultaneous voices. Priority: action > feedback > navigation > ambiance.

### [PATTERN] Performance tiers — graceful degradation

| Aspect | Tier High | Tier Medium | Tier Low |
|--------|-----------|-------------|----------|
| Tweens | Full (ease, overshoot, bounce) | Simplified (ease out, no bounce) | Snap instant (spammable) or 60ms fade (one-shot) |
| Particles | All FX | FX / 2 | None |
| Shaders | Outline + mask + glow | Outline + mask | Outline only |
| Lights | All | 1 light max | None |
| Sounds | All | Action + Feedback | Muted |

Even in Tier Low, one-shot transitions (show, hide, scene change) keep a 60ms minimum fade. Only spammable transitions (hover, focus) snap instantly.

```gdscript
enum PerformanceTier { HIGH, MEDIUM, LOW }
var current_tier := PerformanceTier.HIGH

func tween_property_tiered(node: Node, property: String, value: Variant, duration_high: float):
    match current_tier:
        PerformanceTier.HIGH:
            var tween := _create_tween()
            tween.tween_property(node, property, value, duration_high) \
                .set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
        PerformanceTier.MEDIUM:
            var tween := _create_tween()
            tween.tween_property(node, property, value, duration_high * 0.6) \
                .set_ease(Tween.EASE_OUT)
        PerformanceTier.LOW:
            node.set(property, value)
```

---

## Tween Recipes

### Hover scale

```gdscript
func _apply_interaction_hover():
    var tween := _create_tween()
    tween.tween_property(self, "scale", Vector2(1.05, 1.05), 0.12) \
        .set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)

func _apply_interaction_idle():
    var tween := _create_tween()
    tween.tween_property(self, "scale", Vector2.ONE, 0.1) \
        .set_ease(Tween.EASE_OUT)
```

### Press squash + overshoot release

```gdscript
func _apply_interaction_pressed():
    var tween := _create_tween()
    # Squash down
    tween.tween_property(self, "scale", Vector2(0.92, 0.92), 0.06) \
        .set_ease(Tween.EASE_IN)

func _apply_interaction_released():
    var tween := _create_tween()
    # Overshoot bounce back
    tween.tween_property(self, "scale", Vector2(1.08, 1.08), 0.1) \
        .set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
    tween.tween_property(self, "scale", Vector2.ONE, 0.08) \
        .set_ease(Tween.EASE_IN_OUT)
```

### Focus pulsation (looping)

```gdscript
func _apply_interaction_focus():
    var focus_node = get_role("focus_outline")
    if focus_node:
        focus_node.visible = true
    var tween := _create_tween().set_loops()
    tween.tween_property(self, "modulate:a", 0.85, 0.6) \
        .set_ease(Tween.EASE_IN_OUT)
    tween.tween_property(self, "modulate:a", 1.0, 0.6) \
        .set_ease(Tween.EASE_IN_OUT)
```

### Cooldown radial mask

```gdscript
func _apply_game_cooldown(duration: float):
    var overlay := get_role("skill_cooldown") as TextureProgressBar
    if not overlay:
        return
    overlay.visible = true
    overlay.value = 100
    overlay.fill_mode = TextureProgressBar.FILL_CLOCKWISE

    var tween := _create_tween()
    tween.tween_property(overlay, "value", 0.0, duration)
    tween.tween_callback(func(): emit_event("game", "cooldown_end"))
```

### Tween during pause (popup/menu context)

```gdscript
# Node setup
func _ready():
    process_mode = Node.PROCESS_MODE_ALWAYS

# Tween creation in paused context
func _animate_popup():
    var tween := create_tween()
    tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
    tween.tween_property(self, "modulate:a", 1.0, 0.2) \
        .from(0.0).set_ease(Tween.EASE_OUT)
```

### UIComponent base class

Full base class for components with behavior:

```gdscript
extends Control
class_name UIComponent

signal state_changed(channel: String, old_state: String, new_state: String)

var _system_state := "enabled"
var _game_state := "active"
var _interaction_state := "idle"
var _roles := {}
var _active_tweens: Array[Tween] = []

func _ready():
    _cache_roles(self)
    _apply_all_states()

func _cache_roles(node: Node):
    if node.has_meta("role"):
        _roles[node.get_meta("role")] = node
    for child in node.get_children():
        _cache_roles(child)

func get_role(role: String) -> Node:
    return _roles.get(role)

func get_state(channel: String) -> String:
    match channel:
        "system": return _system_state
        "game": return _game_state
        "interaction": return _interaction_state
    return ""

func emit_event(channel: String, event: String):
    var old_state := get_state(channel)
    var new_state := _resolve_transition(channel, old_state, event)
    if new_state == old_state:
        return
    _set_channel(channel, new_state)
    _cleanup_tweens()
    _apply_state(channel, old_state, new_state)
    state_changed.emit(channel, old_state, new_state)

func _set_channel(channel: String, state: String):
    match channel:
        "system": _system_state = state
        "game": _game_state = state
        "interaction": _interaction_state = state

func _resolve_transition(channel: String, current: String, event: String) -> String:
    # Override in subclasses to define the transition graph
    return current

func _apply_all_states():
    _apply_state("system", "", _system_state)
    _apply_state("game", "", _game_state)
    _apply_state("interaction", "", _interaction_state)

func _apply_state(_channel: String, _old: String, _new: String):
    # Override in subclasses
    pass

func _cleanup_tweens():
    for tween in _active_tweens:
        if tween.is_valid():
            tween.kill()
    _active_tweens.clear()

func _create_tween() -> Tween:
    var tween := create_tween()
    _active_tweens.append(tween)
    return tween
```

---

## Anti-patterns

### [ANTI-PATTERN] Direct state mutation

Never set `_interaction_state = "hover"` directly. Always go through `emit_event("interaction", "mouse_enter")` so the transition graph is respected and the signal fires.

### [ANTI-PATTERN] Tween accumulation

Creating tweens without killing previous ones causes jitter — multiple tweens fight over the same property.

```gdscript
# WRONG — tweens stack up
func _on_hover():
    create_tween().tween_property(self, "scale", Vector2(1.05, 1.05), 0.12)

# CORRECT — clean before creating
func _on_hover():
    _cleanup_tweens()
    var tween := _create_tween()
    tween.tween_property(self, "scale", Vector2(1.05, 1.05), 0.12)
```

### [ANTI-PATTERN] Cross-channel property conflicts

Two channels animating the same property = visual chaos. Scale is owned by InteractionState. If GameState also tweens scale, they'll fight.

If you need additive effects, use a secondary property:
```gdscript
# GameState controls a "base_scale" multiplier
# InteractionState controls the actual scale using base_scale as reference
var base_scale := Vector2.ONE  # Set by GameState (e.g. 0.8 for locked)

func _apply_interaction_hover():
    var tween := _create_tween()
    tween.tween_property(self, "scale", base_scale * 1.05, 0.12)
```

### [ANTI-PATTERN] Tween on a freed node

Creating a tween on a node that gets `queue_free()`d will crash. Use `get_tree().create_tween()` if the node's lifetime is uncertain, and always check `is_instance_valid(node)` in signal callbacks.

### [ANTI-PATTERN] Blocking animations

Tweens that prevent player input until completion. The player clicks during a 300ms transition and nothing happens — feels broken. Animations are visual feedback, not gates.

### [ANTI-PATTERN] Mutating shared theme StyleBox

Calling `get_theme_stylebox("normal").bg_color = Color.RED` without `.duplicate()` modifies the shared resource for every node using that style. Always duplicate first, then apply as override.

### [ANTI-PATTERN] Missing focus visuals for gamepad

A hover effect on mouse but no visible focus state for keyboard/gamepad navigation. The player tabbing or using a d-pad has no idea what's selected. Focus outline must be frank and always visible — not a subtle glow.

### [ANTI-PATTERN] Sound spam without throttle

Playing a hover sound on every `mouse_entered` without throttle creates machine-gun audio when the player moves the mouse across a list. Minimum 120ms between hover sounds, 80ms between focus sounds.

### [ANTI-PATTERN] Flash rate above 3Hz

Any animation that flashes more than 3 times per second is an epilepsy risk. Pulsations, blinks, and loops must stay well under this threshold.
