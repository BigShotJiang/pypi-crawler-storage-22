# UI Composition — Knowledge

Practical reference for building UI layouts in Godot 4.x. Covers container hierarchy, common patterns, game board layouts, torture tests, and anti-patterns.

---

## Mandates

[MANDATE] **NEVER use Node2D for UI** — always use Control-derived nodes and Containers. Node2D has no layout system, no anchors, no size flags. Even for "simple" UI like a health bar above a sprite, use a `Control` subtree or `CanvasLayer`.

[MANDATE] **NEVER position UI in code** — use anchors and containers to handle layout. Manual `position = Vector2(x, y)` on UI elements breaks on resolution changes, language switches, and content length variations. The only exception is drag-and-drop during an active gesture.

[MANDATE] **Container hierarchy: PanelContainer > MarginContainer > VBox/HBox > content** — this is the universal building block. PanelContainer provides the visual background (StyleBox). MarginContainer provides padding (spacing tokens). VBox/HBox provides flow. Content nodes sit inside.

```
PanelContainer          # Visual surface (background, border, shadow)
  MarginContainer       # Padding (space-sm to space-xl)
    VBoxContainer       # Vertical flow
      Label             # Content
      Button            # Content
```

[MANDATE] **One responsibility per Container** — a Container manages ONE axis or ONE concern. VBox = vertical stack. HBox = horizontal row. MarginContainer = padding. CenterContainer = centering. Never overload a single container with multiple layout jobs.

[MANDATE] **Tokens over magic numbers** — every spacing, radius, and font size must come from the token system. No `16` scattered in code — use `space-md`. This applies to `add_theme_constant_override("separation", ...)`, margin overrides, and `custom_minimum_size`.

[MANDATE] **Double signal for accessibility** — never communicate information through color alone. Always pair with an icon, shape, text, or opacity change. Applies to error states, selection, health levels, status effects.

---

## Container Hierarchy

The fundamental pattern for any UI panel, card, dialog, or overlay:

```
PanelContainer              # Background / visual frame
  MarginContainer           # Inner padding
    VBoxContainer           # Primary layout axis
      [header nodes]
      [content nodes]
      [footer/action nodes]
```

### Why this order matters

1. **PanelContainer** draws the StyleBox behind everything — background color, border, rounded corners, shadow. Without it, there is no visual surface.
2. **MarginContainer** creates breathing room between the panel edge and the content. Set all four margins to a spacing token (`space-sm` = 8, `space-md` = 16, `space-lg` = 24).
3. **VBox/HBox** handles flow direction. Children stack without needing manual positions.
4. **Content** (Labels, Buttons, TextureRects, nested containers) sits inside and inherits the layout.

### Applying margins via MCP

```gdscript
# Apply space-lg (24) padding to a MarginContainer
var margin = get_node("Panel/Margin")
for side in ["left", "top", "right", "bottom"]:
    margin.add_theme_constant_override("margin_" + side, 24)
```

### Spacing tokens reference

| Token | Value | Usage |
|-------|-------|-------|
| `space-xs` | 4 | Icon-to-text gap, badge internals |
| `space-sm` | 8 | Same-group elements |
| `space-md` | 16 | Standard separation |
| `space-lg` | 24 | Section separation |
| `space-xl` | 32 | Header-to-body, page margins |
| `space-2xl` | 40 | Page/panel outer margins |
| `space-3xl` | 48 | Hero spacing (splash, title screen) |

**Decision rule**: same group = `sm`, different groups = `md`, sections = `lg`, page = `xl+`.

### Anchors

- Only set anchors on **root-level Controls** (direct children of the viewport or CanvasLayer). Children of Containers inherit their position from the parent — anchors on them are ignored or cause conflicts.
- Always use presets:

```gdscript
node.set_anchors_preset(Control.PRESET_FULL_RECT)
```

Common presets: `PRESET_TOP_LEFT`, `PRESET_CENTER`, `PRESET_FULL_RECT`, `PRESET_BOTTOM_WIDE`, `PRESET_HCENTER_WIDE`.

### Size flags

```gdscript
# SIZE_FILL = 1, SIZE_EXPAND = 2, SIZE_EXPAND_FILL = 3
spacer.size_flags_vertical = Control.SIZE_EXPAND_FILL
```

Use `SIZE_EXPAND_FILL` on spacer/filler Controls to push siblings apart (e.g., top bar vs bottom bar in a HUD).

---

## Patterns

### [PATTERN] Full-Screen Menu

```
Control (anchors: full rect)
  ColorRect "Background"        # anchors: full rect
  CenterContainer "Center"      # anchors: full rect
    VBoxContainer "Content"     # separation: space-lg (24)
      Label "Title"             # font_size: 32, center aligned
      Control "Spacer"          # SIZE_EXPAND_FILL, min height 32
      VBoxContainer "Buttons"   # separation: space-sm (8)
        Button "Play"
        Button "Options"
        Button "Quit"
```

### [PATTERN] HUD Overlay

```
CanvasLayer "UI"
  MarginContainer "HUD"         # anchors: full rect, margins: space-lg (24)
    VBoxContainer "Layout"
      HBoxContainer "TopBar"
        ProgressBar "HealthBar"
        Control "Spacer"        # SIZE_EXPAND_FILL
        Label "Score"
      Control "Filler"          # SIZE_EXPAND_FILL
      HBoxContainer "BottomBar"
        HBoxContainer "ItemSlots"
```

### [PATTERN] Dialog Box

```
ColorRect "Overlay"             # anchors: full rect, color: rgba(0,0,0,0.5)
  CenterContainer "Center"     # anchors: full rect
    PanelContainer "Panel"
      MarginContainer "Margin"  # margins: space-lg (24)
        VBoxContainer "VBox"    # separation: space-md (16)
          Label "Title"
          RichTextLabel "Body"  # min height 60, fit_content = true
          HBoxContainer "Actions"
            Control "Spacer"    # SIZE_EXPAND_FILL
            Button "Cancel"
            Button "Confirm"
```

### [PATTERN] Tooltip

```
PanelContainer "Tooltip"        # min width 200, max width 350
  MarginContainer "Margin"      # margins: space-sm (8)
    VBoxContainer "VBox"        # separation: space-xs (4)
      HBoxContainer "Header"   # separation: space-xs (4)
        TextureRect "Icon"
        Label "Title"
      HSeparator
      RichTextLabel "Desc"      # fit_content = true, bbcode_enabled = true
```

### [PATTERN] Skill/Item Slot

```
PanelContainer "Slot"           # min size: 64x64
  CenterContainer "Content"
    TextureRect "Icon"
  Label "Keybind"               # anchored bottom-right, font_size: 12
  TextureProgressBar "Cooldown" # anchors: full rect, radial fill
```

For a hotbar: `HBoxContainer` with separation `space-xs` (4), containing N slots with the pattern above. Assign collection role `hotbar_slot` to each.

### [PATTERN] Popup (Programmatic)

For transient overlays (level-up, weapon swap, confirmation), prefer code-only over `.tscn`:

```gdscript
# Single .gd file, no scene to maintain
var layer := CanvasLayer.new()
layer.layer = 100
add_child(layer)

var panel := PanelContainer.new()
# ... build hierarchy in code ...
layer.add_child(panel)
```

Use when the popup is structurally simple and its lifetime is short.

---

## Game Board Pattern

[PATTERN] **Game boards** are the hybrid zone where gameplay elements coexist with UI overlays. Card game tables, inventory grids, tactical maps, deck builders. The challenge: gameplay needs spatial relationships (positions, zones, drag targets), but the surrounding chrome (score, hand, buttons) is pure UI.

### Architecture: Split the layers

```
Control "BoardRoot"                     # anchors: full rect
  # Layer 1 — Pure UI chrome (top)
  MarginContainer "TopBar"              # anchors: top wide
    HBoxContainer
      Label "TurnIndicator"
      Control "Spacer"
      Label "Score"

  # Layer 2 — Game board (center, takes remaining space)
  MarginContainer "BoardArea"           # anchors: full rect, margins push away from chrome
    AspectRatioContainer "BoardFrame"   # keeps board proportional
      Control "Board"                   # the actual play surface
        # Grid-based: use GridContainer
        GridContainer "CardGrid"        # columns: N, separation: space-sm
          PanelContainer "Slot_0_0"
          PanelContainer "Slot_0_1"
          # ...
        # OR free-form: use plain Control with positioned children
        Control "FreeBoard"
          # Children positioned via layout logic, NOT manual pixel coords

  # Layer 3 — Player hand / action bar (bottom)
  MarginContainer "BottomBar"           # anchors: bottom wide
    HBoxContainer "Hand"                # separation: space-sm (8)
      PanelContainer "Card1"
      PanelContainer "Card2"
      PanelContainer "Card3"
```

### Key principles

**Use `AspectRatioContainer` for the board** — gameplay areas usually need a fixed aspect ratio (e.g., 16:9 board, square grid). Wrap the board in `AspectRatioContainer` so it scales without distortion.

**Grid-based boards use `GridContainer`** — inventory grids, card grids, tactical grids. Set `columns` and let the container handle cell placement. Each cell is a `PanelContainer` following the standard hierarchy.

**Free-form boards use `Control` with code-driven placement** — when elements need arbitrary positions (e.g., a map with pinned locations), use a plain `Control` as the board surface. Position children via normalized coordinates (0-1 range) mapped to the board's `size`, not absolute pixel values:

```gdscript
# Place a pin at 30% from left, 60% from top of the board
func place_on_board(element: Control, norm_x: float, norm_y: float) -> void:
    var board_size := board_control.size
    element.position = Vector2(
        board_size.x * norm_x - element.size.x * 0.5,
        board_size.y * norm_y - element.size.y * 0.5
    )
```

**Drag-and-drop is the exception to "no manual positioning"** — during an active drag gesture, moving a Control by code is expected. But on drop, snap to a Container slot or a normalized board position. Never leave an element at a raw pixel coordinate after the gesture ends.

**Separate interaction zones with `Control.mouse_filter`** — the board area should have `MOUSE_FILTER_PASS` on wrapper containers so clicks reach the correct game element. UI chrome should have `MOUSE_FILTER_STOP` to prevent accidental board interaction through buttons.

### Card in hand (sub-pattern)

```
PanelContainer "Card"           # min size: 80x120
  MarginContainer "Margin"      # margins: space-sm (8)
    VBoxContainer "Layout"      # separation: space-xs (4)
      TextureRect "Art"         # SIZE_EXPAND_FILL
      Label "Name"              # font_size: 12, center
      HBoxContainer "Stats"
        Label "Cost"
        Control "Spacer"
        Label "Power"
```

Cards in a hand HBox get `SIZE_SHRINK_CENTER` vertically. For fan layouts (curved hand), use code to apply rotation and offset per card — this is a visual polish pass, not a structural concern.

### Board slot (sub-pattern)

```
PanelContainer "Slot"           # min size matches card or grid cell
  CenterContainer "Content"
    TextureRect "Placeholder"   # visible when empty
  # Card placed here at runtime replaces/overlays placeholder
```

Slots accept drops. When occupied, the card Control is reparented into the slot. The Container handles centering automatically.

---

## Torture Tests

After building any UI, verify with these content extremes:

| Test | Content | Must NOT happen |
|------|---------|-----------------|
| Long title | 45+ characters | Text overflows container |
| Long description | 600 characters | Text truncated without scroll/wrap |
| Language test | DE (long compounds), JA (wide chars) | Layout breaks |
| Extreme values | 0, 9999, 120s, -5 | Numeric overflow |
| Empty content | Empty string | Hole in layout (needs placeholder) |
| Long player name | "XXXXXXXXXXXXXXXXXXXXXXXXX" (25 chars) | Overflows container |
| Many items | 2x expected grid/list count | Scroll works, no overlap |
| Single item | 1 item in a list/grid designed for many | No weird centering or collapse |

### How to run torture tests via MCP

```
godot_execute_script(code="""
var label = EditorInterface.get_edited_scene_root().get_node("Path/To/Label")
label.text = "This is a very long title that should test wrapping and truncation behavior in all layouts"
return "Torture test applied"
""")
```

Then verify visually:

```
godot_get_editor_screenshot
```

### For game boards specifically

| Test | Content | Must NOT happen |
|------|---------|-----------------|
| Full grid | Every slot occupied | Slots overlap or push outside board |
| Empty grid | All slots empty | Board collapses or looks broken |
| Drag to edge | Drag element to board boundary | Element escapes board area |
| Resolution change | 1920x1080 to 1280x720 | Board aspect ratio distorts |
| Hand overflow | 10+ cards in a hand designed for 5 | Cards overlap unreadably or escape |

---

## Anti-patterns

[ANTI-PATTERN] **Node2D for UI** — using `Sprite2D`, `Node2D`, or `Area2D` to build UI elements. These have no layout system. They break on resolution changes. They cannot participate in Container flow. Use Control-derived nodes.

[ANTI-PATTERN] **Manual pixel positioning** — `position = Vector2(320, 180)` on a UI element. This breaks on every resolution that is not your dev resolution. Use Containers and anchors.

[ANTI-PATTERN] **Skipping MarginContainer** — putting content directly inside a PanelContainer. The content hugs the panel edges with zero padding. Always insert a MarginContainer between the panel and the content.

[ANTI-PATTERN] **Nested CenterContainers** — `CenterContainer > CenterContainer > Content`. One CenterContainer centers its child. Two nested ones do the same thing with an extra node. Remove the redundant one.

[ANTI-PATTERN] **Size flags on root Controls** — setting `SIZE_EXPAND_FILL` on a Control that is the direct child of the viewport (not inside a Container). Size flags only work inside Containers. For root-level Controls, use anchors.

[ANTI-PATTERN] **"Container3" naming** — generic names like `HBoxContainer2`, `VBoxContainer3`. Every node should have a semantic name: `TopBar`, `ButtonRow`, `StatsGroup`. The name should describe the role, not the type.

[ANTI-PATTERN] **Hardcoded separation in multiple places** — setting `add_theme_constant_override("separation", 16)` with raw numbers scattered across the codebase. Define token constants and reference them:

```gdscript
const SPACE_SM := 8
const SPACE_MD := 16
const SPACE_LG := 24

vbox.add_theme_constant_override("separation", SPACE_MD)
```

[ANTI-PATTERN] **Raw pixel coordinates on a game board** — placing game elements at absolute positions (`card.position = Vector2(450, 300)`). This breaks on resolution changes and board resizing. Use normalized coordinates mapped to the board surface, or Container slots.

[ANTI-PATTERN] **UI and gameplay in the same node tree without layer separation** — mixing `CanvasLayer` UI elements and game board elements without clear boundaries. Input events leak between layers, z-ordering becomes unpredictable. Always separate UI chrome (CanvasLayer) from the board surface, and use `mouse_filter` to control event routing.
