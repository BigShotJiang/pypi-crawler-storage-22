# VFX — Knowledge

Godot 4.x visual effects: particles, shaders, lighting, post-processing.

---

## Mandates

[MANDATE] **Particles: one_shot for impacts, looping for ambient.**
`one_shot = true` + `explosiveness = 1.0` for hits/explosions. `one_shot = false` + `explosiveness = 0.0` for rain, smoke, fire.

[MANDATE] **Test particles in-game, not just editor.**
Editor preview hides timing issues, blend mode conflicts, and performance under real conditions. Always run the scene.

[MANDATE] **CanvasGroup for composite effects.**
When an effect has 3+ overlapping layers (flash + sparks + smoke), wrap them in a CanvasGroup so blend modes and modulate apply to the composite, not each child individually.

[MANDATE] **Every GPUParticles2D needs a ParticleProcessMaterial and a texture.**
Without both, nothing renders. No exceptions.

[MANDATE] **Generate Visibility Rect after every particle config change.**
Particles > Generate Visibility Rect. Skip this and particles vanish at screen edges.

[MANDATE] **Noise + Scroll before complex shaders.**
Water, fire, lasers, portals = two noise textures scrolling at different speeds. Try this first before writing a 50-line shader.

[MANDATE] **AnimationPlayer as VFX orchestrator.**
One timeline controls emitting, flash intensity, screenshake signals, fade-out, and queue_free. Replaces 30+ lines of _process timing code.

---

## Patterns

### [PATTERN] Composition by Layers

A good VFX is never a single node. 3-5 layers, each with a role:

| Layer | Role | Timing | Node |
|-------|------|--------|------|
| Flash | Immediate attention grab | 1-2 frames | PointLight2D energy burst or white Sprite |
| Sparks | Energy, direction | 0.1-0.3s | GPUParticles2D (explosiveness=1, amount=8-15) |
| Core | Body of the effect | 0.3-0.8s | GPUParticles2D main |
| Smoke | Residue, settling | 0.5-2s | GPUParticles2D (low amount, large scale) |
| Shockwave | Spatial feedback | 0.2-0.4s | Sprite2D + scale tween or distortion shader |

```
EffectRoot (Node2D)
+-- Flash (PointLight2D)        -- one_shot tween
+-- Sparks (GPUParticles2D)     -- one_shot, explosiveness=1
+-- Core (GPUParticles2D)       -- one_shot
+-- Smoke (GPUParticles2D)      -- one_shot, slower lifetime
+-- Shockwave (Sprite2D)        -- scale tween 0->max + fade
```

Blend modes: **ADD** for fire/sparks/magic (adds brightness). **MIX** for smoke/dust/solids (covers what's behind).

### [PATTERN] VFX as Dedicated Scene

Never scatter VFX nodes inside Player or Enemy. One effect = one `.tscn`.

```
VFX_Effect.tscn (Node2D root)
+-- GPUParticles2D
+-- Sprite2D (shockwave ring, ShaderMaterial)
+-- AudioStreamPlayer2D
+-- AnimationPlayer (orchestrator)
+-- PointLight2D (optional)
```

### [PATTERN] Impact Particles

```gdscript
## one_shot burst with directional spread
extends GPUParticles2D

@export var particle_color: Color = Color.WHITE
@export var particle_count: int = 12

func _ready():
    emitting = false
    one_shot = true
    explosiveness = 1.0
    amount = particle_count
    lifetime = 0.3

    var mat := ParticleProcessMaterial.new()
    mat.direction = Vector3(1, 0, 0)
    mat.spread = 45.0
    mat.initial_velocity_min = 150.0
    mat.initial_velocity_max = 300.0
    mat.gravity = Vector3.ZERO
    mat.damping_min = 100.0
    mat.damping_max = 200.0
    mat.color = particle_color
    process_material = mat

    var img := Image.create(8, 8, false, Image.FORMAT_RGBA8)
    img.fill(Color.WHITE)
    texture = ImageTexture.create_from_image(img)

func emit_at(pos: Vector2, direction: Vector2 = Vector2.RIGHT):
    global_position = pos
    rotation = direction.angle()
    restart()
    emitting = true
```

### [PATTERN] Orbit / Magic Circle

```gdscript
extends GPUParticles2D

func _ready():
    amount = 20
    lifetime = 2.0

    var mat := ParticleProcessMaterial.new()
    mat.orbit_velocity_min = 0.5
    mat.orbit_velocity_max = 0.5
    mat.radial_accel_min = -50.0
    mat.radial_accel_max = -50.0
    mat.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_RING
    mat.emission_ring_radius = 60.0
    mat.emission_ring_inner_radius = 55.0
    mat.emission_ring_height = 0.0
    mat.emission_ring_axis = Vector3(0, 0, 1)
    mat.scale_min = 0.3
    mat.scale_max = 0.6
    process_material = mat
```

### [PATTERN] Ghost Trail (Dash After-images)

Sprite clones, not particles — particles can't sync the current animation frame.

```gdscript
extends Node2D

@export var ghost_color: Color = Color(0.5, 0.5, 1.0, 0.6)
@export var ghost_lifetime: float = 0.4
@export var spawn_interval: float = 0.05
var _timer: float = 0.0
var _active: bool = false

func start(): _active = true; _timer = 0.0
func stop(): _active = false

func _process(delta: float) -> void:
    if not _active: return
    _timer -= delta
    if _timer <= 0.0:
        _timer = spawn_interval
        var sprite: AnimatedSprite2D = get_parent().get_node("AnimatedSprite2D")
        var ghost := Sprite2D.new()
        ghost.texture = sprite.sprite_frames.get_frame_texture(sprite.animation, sprite.frame)
        ghost.global_position = get_parent().global_position
        ghost.flip_h = sprite.flip_h
        ghost.modulate = ghost_color
        get_tree().current_scene.add_child(ghost)
        var tween: Tween = get_tree().create_tween()
        tween.tween_property(ghost, "modulate:a", 0.0, ghost_lifetime)
        tween.tween_callback(ghost.queue_free)
```

### [PATTERN] Pooling (Frequent VFX)

Mandatory for hits, dash, footsteps. No runtime alloc/free in combat.

```gdscript
var _pool: Array[Node2D] = []
var _scene: PackedScene

func _init(scene: PackedScene, size: int = 10) -> void:
    _scene = scene
    for i in size:
        var instance := scene.instantiate() as Node2D
        instance.visible = false
        _pool.append(instance)

func get_instance() -> Node2D:
    for vfx in _pool:
        if not vfx.visible:
            vfx.visible = true
            return vfx
    var instance := _scene.instantiate() as Node2D
    instance.visible = true
    _pool.append(instance)
    return instance
```

### [PATTERN] Lighting 2D — PointLight2D + CanvasModulate

**CanvasModulate** sets ambient darkness. Everything unlit gets this color.
- Black pure `(0.0, 0.0, 0.0)` for full darkness halos.
- Max tolerated: `(0.02, 0.02, 0.02)`. Beyond that, halo edges become visible.

**PointLight2D gradient rules:**
- Use **RGB opaque** (white to black), not alpha. Alpha causes ring artifacts.
- Use **GRADIENT_INTERPOLATE_CUBIC**. Linear = visible banding.
- **Max 3 stops** with cubic. More = spline overshoot = dark rings.
- Texture **512x512 minimum**. Smaller = banding at high `texture_scale`.
- Gradient must reach **exactly Color.BLACK** at the edge.

Flickering torch with noise:

```gdscript
extends PointLight2D

@export var base_energy: float = 1.0
@export var flicker_amount: float = 0.2
@export var flicker_speed: float = 10.0
var noise := FastNoiseLite.new()
var noise_y: float = 0.0

func _ready():
    noise.seed = randi()
    noise.frequency = 0.5

func _process(delta):
    noise_y += delta * flicker_speed
    energy = base_energy + noise.get_noise_1d(noise_y) * flicker_amount
```

### [PATTERN] WorldEnvironment Glow (Bloom)

- `Background > Mode` = `Canvas` (for 2D)
- `Glow > Enabled` = true
- `Glow > HDR Threshold` = 1.0 or 1.2
- `Glow > Blend Mode` = Screen or Additive
- `Glow > Intensity` = 0.5 to 1.0
- ToneMapping: **Filmic** or **ACES** recommended

**Make ONE object glow:** set its Modulate to RAW mode, RGB values > 1.0 (e.g. R=3, G=0.2, B=0.2). Only that object exceeds the HDR threshold.

### [PATTERN] Auto-disable Off-screen

```gdscript
func _ready():
    var notifier := VisibleOnScreenNotifier2D.new()
    add_child(notifier)
    notifier.screen_exited.connect(func(): emitting = false)
    notifier.screen_entered.connect(func(): emitting = true)
```

### [PATTERN] Y-Sort (2.5D Depth)

Parent node: `Y Sort Enabled = true`. Origin point at the **feet**, not center.
```gdscript
$Sprite.offset.y = -sprite_height / 2
```

---

## Shader Templates

### Hit Flash

```gdshader
shader_type canvas_item;
uniform float flash_intensity : hint_range(0.0, 1.0) = 0.0;
uniform vec4 flash_color : source_color = vec4(1.0, 1.0, 1.0, 1.0);

void fragment() {
    vec4 tex = texture(TEXTURE, UV);
    COLOR = mix(tex, flash_color, flash_intensity);
    COLOR.a = tex.a;
}
```

Trigger: `material.set_shader_parameter("flash_intensity", 1.0)` then tween back to 0.

### Dissolve

```gdshader
shader_type canvas_item;
uniform float progress : hint_range(0.0, 1.0) = 0.0;
uniform float edge_width : hint_range(0.0, 0.2) = 0.05;
uniform vec4 edge_color : source_color = vec4(1.0, 0.5, 0.0, 1.0);
uniform sampler2D noise_texture;

void fragment() {
    vec4 tex = texture(TEXTURE, UV);
    float noise = texture(noise_texture, UV).r;
    if (noise < progress) {
        discard;
    } else if (noise < progress + edge_width) {
        COLOR = edge_color;
        COLOR.a = tex.a;
    } else {
        COLOR = tex;
    }
}
```

### Outline

```gdshader
shader_type canvas_item;
uniform vec4 outline_color : source_color = vec4(1.0, 1.0, 1.0, 1.0);
uniform float outline_width : hint_range(0.0, 10.0) = 1.0;

void fragment() {
    vec4 tex = texture(TEXTURE, UV);
    vec2 size = TEXTURE_PIXEL_SIZE * outline_width;
    float outline = texture(TEXTURE, UV + vec2(-size.x, 0)).a;
    outline += texture(TEXTURE, UV + vec2(size.x, 0)).a;
    outline += texture(TEXTURE, UV + vec2(0, -size.y)).a;
    outline += texture(TEXTURE, UV + vec2(0, size.y)).a;
    outline = min(outline, 1.0);
    vec4 final_color = mix(outline_color, tex, tex.a);
    COLOR = final_color;
    COLOR.a = max(tex.a, outline * outline_color.a);
}
```

### Sway (Wind on Vegetation)

```gdshader
shader_type canvas_item;
uniform float speed : hint_range(0.0, 10.0) = 2.0;
uniform float amplitude : hint_range(0.0, 50.0) = 10.0;
uniform float instance_offset : hint_range(0.0, 100.0) = 0.0;

void vertex() {
    float mask = 1.0 - UV.y;  // bottom pinned, top moves
    VERTEX.x += sin(TIME * speed + instance_offset) * amplitude * mask;
}
```

Set "Local to Scene" on the material, then randomize per instance:
```gdscript
func _ready():
    material.set_shader_parameter("instance_offset", randf() * 100.0)
```

---

## Anti-patterns

[ANTI-PATTERN] **Glow everywhere.**
The eye adapts. If everything glows, nothing glows. Glow is an accent for critical elements (collectibles, projectiles, UI focus), not a style.

[ANTI-PATTERN] **Shader glow + PointLight2D on the same object.**
Two light sources with different falloff rates create a visible double-bubble ring. Shaders define the surface, PointLight2D lights it. Never both.

[ANTI-PATTERN] **PointLight2D gradient using alpha.**
`Color(1,1,1, 0.5)` instead of `Color(0.5, 0.5, 0.5)`. Alpha behaves differently in PointLight2D. Use RGB luminance only.

[ANTI-PATTERN] **Skipping to shaders before validating timing.**
The classic trap: writing a dissolve shader before the effect's timing and readability are confirmed. A beautiful shader with bad timing = a failed effect. Prototype with sprites + color + tween first.

[ANTI-PATTERN] **Duplicating particles without Make Unique.**
Modifying one modifies ALL copies. Always "Make Unique" recursively on the ProcessMaterial after duplication.

[ANTI-PATTERN] **floor(TIME * speed) in shaders.**
Causes pixel-snapping flicker. Use `sin(TIME * speed)` / `cos()` for smooth animation.

[ANTI-PATTERN] **ColorRect fullscreen shader with default white.**
Flash white on GPU hiccup. Set base color to `Color(0, 0, 0, 0)` in `_ready()`.

[ANTI-PATTERN] **3 separate textures for one shader.**
Wastes samplers. Pack into RGBA channels: shape (R), noise (G), mask (B). Access: `texture(tex, UV).g`. One sampler instead of three.

[ANTI-PATTERN] **Starting VFX at full intensity.**
Vignette + glow + CanvasModulate at max = opaque screen, hard to diagnose. Always start at 20% intensity and increase. Begin vignette at alpha 0.35, radius 0.6.

[ANTI-PATTERN] **Preprocess = 0 on ambient particles.**
Smoke/fire appears empty when the scene loads. Set `preprocess` to 2.0-5.0 so particles are pre-filled.

[ANTI-PATTERN] **Flipbook particles without BLEND_MODE_ADD.**
Black squares around frames. Set `CanvasItemMaterial.blend_mode = BLEND_MODE_ADD`.

---

## Performance Budgets

| Resource | Per effect | Screen total |
|----------|-----------|-------------|
| Active particles | 50-100 | <=500 |
| PointLight2D with shadows | 1-2 | <=5 |
| Custom shaders | - | <=10 simultaneous |
| Draw calls | - | <=100 |

Optimizations: reduce `amount` + increase `scale` to compensate. Disable shadows on small lights. Avoid loops in shaders, minimize `texture()` calls. Use VisibleOnScreenNotifier2D for off-screen culling.
