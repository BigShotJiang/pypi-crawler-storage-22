"""Coherence validator — checks cross-references, recipes, and stale paths in V3 structure."""

import re
import sys
from pathlib import Path


def _find_repo_root() -> Path:
    """Find the golem-mcp repo root (has pyproject.toml + package/)."""
    cwd = Path.cwd()
    for parent in [cwd, *cwd.parents]:
        if (parent / "pyproject.toml").exists() and (parent / "package").exists():
            return parent
    # Fallback: assume script is in _golem/tools/
    return Path(__file__).parent.parent.parent


def _read_text(path: Path) -> str:
    if path.exists():
        return path.read_text(encoding="utf-8")
    return ""


def check_commands_reference_agents(root: Path) -> list[str]:
    """Check that every agent referenced in commands/*.md exists in _golem/agents/."""
    errors = []
    agents_dir = root / "_golem" / "agents"
    agent_files = {f.name for f in agents_dir.glob("*.md")} if agents_dir.exists() else set()

    commands_dir = root / "commands"
    if not commands_dir.exists():
        return ["commands/ directory not found"]

    for cmd in commands_dir.glob("*.md"):
        content = _read_text(cmd)
        # Match references like `_golem/agents/builder.md`
        for m in re.finditer(r"`_golem/agents/([\w-]+\.md)`", content):
            ref = m.group(1)
            if ref not in agent_files:
                errors.append(f"commands/{cmd.name} references `_golem/agents/{ref}` but file not found")
    return errors


def check_agents_reference_workflows(root: Path) -> list[str]:
    """Check that every workflow referenced in agents/*.md exists in _golem/workflows/."""
    errors = []
    agents_dir = root / "_golem" / "agents"
    if not agents_dir.exists():
        return ["_golem/agents/ directory not found"]

    workflows_dir = root / "_golem" / "workflows"

    for agent in agents_dir.glob("*.md"):
        content = _read_text(agent)
        # Match references like `_golem/workflows/build/workflow.md`
        for m in re.finditer(r"`_golem/workflows/([\w/-]+\.md)`", content):
            ref = m.group(1)
            if not (workflows_dir / ref).exists():
                errors.append(f"_golem/agents/{agent.name} references `_golem/workflows/{ref}` but file not found")
    return errors


def check_workflows_reference_steps(root: Path) -> list[str]:
    """Check that workflow.md files reference steps that actually exist."""
    errors = []
    workflows_dir = root / "_golem" / "workflows"
    if not workflows_dir.exists():
        return ["_golem/workflows/ directory not found"]

    for workflow_md in workflows_dir.rglob("workflow.md"):
        content = _read_text(workflow_md)
        workflow_rel = workflow_md.parent.relative_to(root / "_golem" / "workflows")

        # Match references like `steps/01-preflight.md`
        for m in re.finditer(r"`steps/([\w-]+\.md)`", content):
            step_ref = m.group(1)
            step_path = workflow_md.parent / "steps" / step_ref
            if not step_path.exists():
                errors.append(
                    f"_golem/workflows/{workflow_rel}/workflow.md references "
                    f"`steps/{step_ref}` but file not found"
                )
    return errors


def check_recipes_index(root: Path) -> list[str]:
    """Check that every recipe in INDEX.md has a corresponding file."""
    errors = []
    index_path = root / "_golem" / "recipes" / "INDEX.md"
    if not index_path.exists():
        return ["_golem/recipes/INDEX.md not found"]

    content = _read_text(index_path)
    recipes_dir = root / "_golem" / "recipes"

    for m in re.finditer(r"`(\w[\w-]*\.md)`", content):
        filename = m.group(1)
        if filename == "INDEX.md":
            continue
        if not (recipes_dir / filename).exists():
            errors.append(f"_golem/recipes/INDEX.md references `{filename}` but _golem/recipes/{filename} not found")
    return errors


def check_knowledge_files(root: Path) -> list[str]:
    """Check that knowledge files referenced in workflow steps exist."""
    errors = []
    knowledge_dir = root / "_golem" / "knowledge"
    if not knowledge_dir.exists():
        return ["_golem/knowledge/ directory not found"]

    knowledge_files = {f.name for f in knowledge_dir.glob("*.md")}

    # Scan workflow steps for knowledge references
    workflows_dir = root / "_golem" / "workflows"
    if not workflows_dir.exists():
        return errors

    for step in workflows_dir.rglob("steps/*.md"):
        content = _read_text(step)
        step_rel = step.relative_to(root / "_golem")
        # Match references like `_golem/knowledge/scene-building.md` or `knowledge/scene-building.md`
        for m in re.finditer(r"`(?:_golem/)?knowledge/([\w-]+\.md)`", content):
            ref = m.group(1)
            if ref not in knowledge_files:
                errors.append(f"_golem/{step_rel} references `knowledge/{ref}` but file not found")

    return errors


def check_hooks_exist(root: Path) -> list[str]:
    """Check that hook files referenced in installer exist."""
    errors = []
    hooks_dir = root / "hooks"
    if not hooks_dir.exists():
        return ["hooks/ directory not found"]

    expected = [
        "check_connection.py",
        "block_tscn_edit.py",
        "gdscript_lint.py",
        "compact_context.py",
        "pre_compact.py",
    ]
    for hook in expected:
        if not (hooks_dir / hook).exists():
            errors.append(f"hooks/{hook} not found (expected by installer)")
    return errors


def check_claude_md_references(root: Path) -> list[str]:
    """Check that reference files cited in CLAUDE.md exist."""
    errors = []
    claude_md = root / "CLAUDE.md"
    if not claude_md.exists():
        return []

    content = _read_text(claude_md)

    # Check _golem/ paths
    for m in re.finditer(r"_golem/([\w/-]+\.(?:md|py|yaml))", content):
        ref = m.group(1)
        if not (root / "_golem" / ref).exists():
            errors.append(f"CLAUDE.md references `_golem/{ref}` but file not found")

    # Check rules/ files
    for m in re.finditer(r"(?:package/)?rules/(\w[\w-]*\.md)", content):
        ref = m.group(1)
        if not (root / "rules" / ref).exists():
            errors.append(f"CLAUDE.md references `rules/{ref}` but file not found")

    # Check commands/ files
    for m in re.finditer(r"(?:package/)?commands/(\w[\w-]*\.md)", content):
        ref = m.group(1)
        if not (root / "commands" / ref).exists():
            errors.append(f"CLAUDE.md references `commands/{ref}` but file not found")

    return errors


def main() -> None:
    root = _find_repo_root()

    # Use package/ as the root for validation (contains the actual files)
    pkg = root / "package"
    if not pkg.exists():
        print("✗ package/ directory not found — are you in the golem-mcp repo?", file=sys.stderr)
        sys.exit(1)

    all_errors = []

    checks = [
        ("Commands → Agents references", check_commands_reference_agents),
        ("Agents → Workflows references", check_agents_reference_workflows),
        ("Workflows → Steps references", check_workflows_reference_steps),
        ("Recipes INDEX.md → files", check_recipes_index),
        ("Knowledge files referenced by steps", check_knowledge_files),
        ("Hooks exist", check_hooks_exist),
        ("CLAUDE.md → reference files", check_claude_md_references),
    ]

    for name, check_fn in checks:
        errors = check_fn(pkg)
        if errors:
            print(f"\n✗ {name}:", file=sys.stderr)
            for err in errors:
                print(f"  - {err}", file=sys.stderr)
            all_errors.extend(errors)
        else:
            print(f"✓ {name}", file=sys.stderr)

    if all_errors:
        print(f"\n{len(all_errors)} issue(s) found.", file=sys.stderr)
        sys.exit(1)
    else:
        print("\nAll checks passed.", file=sys.stderr)
        sys.exit(0)


if __name__ == "__main__":
    main()
