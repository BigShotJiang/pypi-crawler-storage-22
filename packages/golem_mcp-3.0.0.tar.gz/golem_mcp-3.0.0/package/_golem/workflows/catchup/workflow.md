# Catchup Workflow

> Quickly load project context at the start of a session. Zero questions, zero file creation.

## Config

- **Agent**: Maintainer
- **Constraint**: READ-ONLY — nothing created, nothing modified

## Instructions (execute in order)

### 1. Scan the project

Always execute — this is the base:

| Source | Method | Extract |
|--------|--------|---------|
| `project.godot` | Read | Name, version, autoloads, renderer, input map |
| File tree | Glob `**/*.gd`, `**/*.tscn` | Structure, size, organization |
| `CLAUDE.md` (project) | Read | Instructions, conventions, links |
| Open scene | MCP `get_scene_tree` (if connected) | Current working context |
| Errors | MCP `get_errors` (if connected) | Active problems |

### 2. Scan tracking files (if present)

Read if they exist, ignore silently otherwise:

| File | Extract |
|------|---------|
| `GAME_PLAN.md` | Vision, feeling, core mechanics, gameplay loop |
| `CHECKPOINT.md` | Current phase, focus, blockers, progress |
| `deliverables/*.md` | Status of each deliverable |
| `references/index.md` | Established patterns |

### 3. Synthesize

**With tracking files (post-/init):**
```
# {Project Name}

## Vision
{Pitch from GAME_PLAN — feeling, not features}

## State
- Phase: {INIT | BUILDING | POLISHING}
- Focus: {in_progress deliverable or "none"}
- Progress: {X}/{N} deliverables ({%})

## Deliverables
| Deliverable | Status |
|-------------|--------|
| {name} | {⬡ pending / ▶ in_progress / ✓ completed / ⚠ blocked} |

## Blockers
{list or "None"}

→ Suggestion: {most pertinent action}
```

**Without tracking files (existing project):**
```
# {Project Name}

## Structure
- {N} scripts .gd, {M} scenes .tscn
- Autoloads: {list}

## Architecture
{What the organization suggests}

## Errors
{list or "None"}

→ Ready. /init to set up tracking.
```

### 4. Done

```
Prêt. Tu veux bosser sur quoi ?
```

## Rules

1. **Read-only** — create nothing, modify nothing
2. **No questions** — if a file is missing, work with what exists
3. **30 seconds max** — read in parallel, synthesize, done
4. **Not a health check** — that's `/checkpoint`, not `/catchup`
