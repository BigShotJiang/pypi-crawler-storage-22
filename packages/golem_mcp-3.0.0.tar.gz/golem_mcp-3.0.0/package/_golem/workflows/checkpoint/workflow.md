# Checkpoint Workflow

> Snapshot the current project state into CHECKPOINT.md.

## Config

- **Agent**: Maintainer
- **Output**: CHECKPOINT.md (created or updated)

## Instructions (execute in order)

### 1. Scan the project

| Source | Method |
|--------|--------|
| `deliverables/*.md` | Read → extract status |
| `references/index.md` | Read → list patterns added |
| `CHECKPOINT.md` (previous) | Read → compare |
| Scene files | MCP `get_scene_tree` → scan structure |

### 2. Calculate metrics

```
Deliverables:
- Total: {N}
- Completed: {X}
- In Progress: {Y}
- Pending: {Z}
- Blocked: {W}

Vertical Slice: {X/N * 100}% complete
```

### 3. Write CHECKPOINT.md

```markdown
# Checkpoint — {Project Name}

> Last update: {YYYY-MM-DD HH:MM}

## Current State
- Phase: {INIT | BUILDING | POLISHING}
- Focus: {in_progress deliverable or "None"}
- Vertical Slice: {X}% complete

## Deliverables
| Deliverable | Status | Files |
|-------------|--------|-------|
| {name} | {status} | {count} |

## Completed Since Last Checkpoint
- {list}

## In Progress
- {list}

## Next Suggested
- {deliverable} — {reason}

## Blockers
- {list or "None"}

## Health Check
- [ ] All scripts have `extends`
- [ ] No orphan `print()` (use GolemCapture.log)
- [ ] EventBus up to date with used signals
- [ ] No orphan files in scenes/
```

### 4. Compare with previous (if exists)

```
## Progress since last checkpoint

Deliverables:
- Newly completed: {list}
- Moved to in_progress: {list}
- New blockers: {list}
```

### 5. Suggest next action

Based on state:
- Blockers present → `/fix`
- Deliverable ready → `/deliverable {name}`
- Vertical slice complete → design audit
- All complete → polish or new feature

### 6. Done

```
✓ Checkpoint saved

State: {PHASE} — {X}% vertical slice
Focus: {current deliverable}

→ Suggestion: {recommended action}
```
