# Step 01 — Brief

**Progress: Step 1 of 2**

## MANDATORY RULES
- Read this entire file before acting
- Do NOT skip to the next step
- Do NOT load future steps

## Instructions (execute in order)

1. **Load the deliverable** from `deliverables/{name}.md`
   - If it doesn't exist, propose creating it using the template at `_golem/workflows/build/templates/manifest.md`

2. **Check dependencies**: if any dependency is not `completed`, warn:
   ```
   ⚠ Dependencies not resolved:
   - {dep_name} — status: {status}
   ```

3. **Display the brief**:
   ```
   [DELIVERABLE] {name}

   Status: {status}
   Feeling: {feeling from manifest}
   Dependencies: {list or "None"}

   Golem Resources: {N knowledge, M recipes}
   Pitfalls: {N warnings}
   Assets: {N required, M placeholders, P final}

   Requirements:
   - [ ] {req1}
   - [ ] {req2}

   Acceptance Criteria:
   - [ ] {crit1}
   - [ ] {crit2}
   ```

4. **If the deliverable has no Golem Resources section** (old format):
   - Run preflight: `python _golem/tools/preflight.py "DELIVERABLE_DESCRIPTION"`
   - Enrich the deliverable with results (add Golem Resources, Pitfalls, Assets sections)
   - Announce: `[ENRICHED] Deliverable updated with {N} knowledge, {M} recipes, {P} pitfalls`

## Gate

Deliverable loaded and brief displayed.

## Completion

- **[C] Continue** to Step 02 — Plan
- **[E] Edit** the deliverable

STOP and WAIT for user input.
