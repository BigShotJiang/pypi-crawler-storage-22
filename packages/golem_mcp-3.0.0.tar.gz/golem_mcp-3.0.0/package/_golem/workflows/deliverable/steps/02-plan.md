# Step 02 — Plan

**Progress: Step 2 of 2**

## MANDATORY RULES
- Read this entire file before acting
- This step produces a plan then routes to the Build workflow

## Instructions (execute in order)

1. **Build the implementation plan** based on the deliverable's requirements:

   | Step | Knowledge | Description |
   |------|-----------|-------------|
   | 1 | `scene-building.md` | Create scene + nodes |
   | 2 | `ui-composition.md` | Layout structure |
   | 3 | (code) | Core mechanic + VFX/SFX |
   | 4 | `game-feel.md` | Polish feedback |

   Each step MUST include its juice — no separate polish pass.

2. **Present the plan** for approval:
   ```
   [PLAN] {deliverable_name}

   Steps: {N}
   Knowledge to load: {list}
   Estimated files: {list of files to create/modify}
   ```

3. **Update the deliverable manifest** with the plan (add/update the Plan section).

4. **Route to Build workflow**:
   ```
   Plan approved. Routing to Build workflow.
   → Loading _golem/workflows/build/workflow.md
   → Starting at Step 01 — Preflight
   ```
   Load `_golem/workflows/build/steps/01-preflight.md` and continue from there.

## Gate

Plan approved by user.

## Completion

- **[C] Continue** — route to Build workflow Step 01
- **[R] Revise** — adjust the plan

STOP and WAIT for user input.
