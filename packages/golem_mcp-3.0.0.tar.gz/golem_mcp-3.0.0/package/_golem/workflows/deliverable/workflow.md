# Deliverable Workflow

> Focus on a specific deliverable — brief, plan, then route to build.

## Config

- **Agent**: Builder
- **Steps**: 2
- **Outputs**: deliverable brief, implementation plan → routes to build workflow

## Init

1. Confirm agent is Builder (if not, load `_golem/agents/builder.md`)
2. Identify the deliverable name from user input
3. Begin Step 01

## Steps

| # | File | Gate |
|---|------|------|
| 01 | `steps/01-brief.md` | Deliverable loaded and brief displayed |
| 02 | `steps/02-plan.md` | Plan approved → routes to build workflow |

## Flow control

- After Step 02, the deliverable routes into the Build workflow (Step 01-preflight)
- This workflow is a focused entry point for known deliverables
