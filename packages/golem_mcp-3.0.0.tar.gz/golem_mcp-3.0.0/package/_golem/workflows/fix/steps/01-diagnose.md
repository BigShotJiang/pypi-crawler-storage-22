# Step 01 — Diagnose

**Progress: Step 1 of 2**

## MANDATORY RULES
- Read this entire file before acting
- Do NOT skip to the next step
- Do NOT fix anything yet — collect ALL information first
- Execute steps IN ORDER — do not skip

## Instructions (execute in order)

### 1. Visual state
```
godot_get_editor_screenshot
godot_get_game_screenshot    (if game is running)
```

### 2. Logs and errors
```
godot_get_errors
godot_get_logs(source="all")
```

### 3. Scene structure
```
godot_get_scene_tree
```
Look for: bodies without CollisionShape, nodes without script, duplicate names, wrong types.

### 4. Inspect suspect nodes
```
godot_inspect_node(path="NodeName")
```
Look for: position (0,0), visible=false, script=null, collision_layer=0, empty shape.

### 5. Read suspect scripts
```
godot_view_script(path="res://scripts/suspect.gd")
```
Look for: wrong `extends`, `_process` vs `_physics_process`, missing `move_and_slide()`, disconnected signals.

### 6. Consult references
- Read `_golem/references/gdscript_pitfalls.md` for known traps
- Check `_golem/recipes/INDEX.md` if the fix involves a documented technique

### 7. Present diagnostic
```
[DIAGNOSTIC]

Problem: {one sentence}
Cause: {what's broken and why}
Evidence: {what was found in steps 1-5}
Proposed fix: {precise actions}
```

## Gate

Root cause identified with evidence.

## Completion

- **[C] Continue** to Step 02 — Repair
- **[I] Investigate more** — inspect additional nodes/scripts

STOP and WAIT for user input.
