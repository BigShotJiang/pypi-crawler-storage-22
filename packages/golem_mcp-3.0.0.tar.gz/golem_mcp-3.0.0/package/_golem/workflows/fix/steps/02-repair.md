# Step 02 — Repair

**Progress: Step 2 of 2**

## MANDATORY RULES
- Read this entire file before acting
- One fix at a time — verify after each change
- This is the final step

## Instructions (execute in order)

1. **Apply the fix** from the diagnostic:
   - For scripts: edit via `Write`/`Edit` (Godot auto-reloads)
   - For scene nodes: use MCP tools (`godot_update_property`, `godot_add_node`, etc.) → `godot_save_scene`
   - For project settings: use `godot_project_settings action=set`

2. **Verify the fix**:
   ```
   godot_get_errors           → should improve or reach 0
   godot_play_scene
   godot_get_logs(source="all")
   godot_get_game_screenshot  → visual confirmation
   ```

3. **If the fix didn't work**: go back to diagnosis, do NOT stack more fixes. One fix at a time.

4. **If the fix worked**, present:
   ```
   [FIXED]

   Problem: {what was broken}
   Cause: {root cause}
   Fix: {what was changed}
   Verified: {how it was confirmed}

   Files modified:
   - {list}
   ```

5. **Screenshots are static** — dynamic effects (shake, tweens, particles in motion) are NOT visible on screenshots. Verify those via scripts and logs.

## Gate

Fix verified — error resolved or behavior corrected.

## Completion

Fix is done. Suggest next actions:

- **[D] Deliverable** — resume work on the current deliverable
- **[F] Fix more** — another issue to address
- **[K] Checkpoint** — snapshot project state

STOP and WAIT for user input.
