# Fix Workflow

> Debug, diagnose, and repair issues.

## Config

- **Agent**: Builder
- **Steps**: 2
- **Outputs**: diagnostic report, applied fix

## Init

1. Confirm agent is Builder (if not, load `_golem/agents/builder.md`)
2. Identify the problem from user input
3. Begin Step 01

## Steps

| # | File | Gate |
|---|------|------|
| 01 | `steps/01-diagnose.md` | Root cause identified |
| 02 | `steps/02-repair.md` | Fix applied and verified |

## Flow control

- Each step ends with `[C] Continue` — WAIT for user input
- NEVER guess — if unsure, inspect more
- Diagnostic BEFORE fix — always
