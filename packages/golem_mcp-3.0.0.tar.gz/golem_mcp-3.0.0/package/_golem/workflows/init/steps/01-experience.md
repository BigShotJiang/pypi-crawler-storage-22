# Step 01 — Experience

**Progress: Step 1 of 4**

## MANDATORY RULES
- Read this entire file before acting
- Do NOT skip to the next step
- Do NOT load future steps
- This step is CONVERSATIONAL — ask questions, don't create files

## Instructions

1. **Ask the feeling question**:
   > "C'est quoi le feeling visé ? Pas les features — le RESSENTI. Qu'est-ce que le joueur doit ressentir ?"

2. **Ask target and context**:
   > "C'est pour qui ? Quel contexte d'usage ?"

3. **Ask the wow moment**:
   > "Il y a un moment 'wow' que tu veux créer ? Le truc qui fait que le joueur se dit 'holy shit'."

4. **Synthesize** as a pitch:
   ```
   [EXPERIENCE]
   Feeling: {primary emotion}
   Target: {audience}
   Wow: {the moment}
   Pitch: {2-3 sentences, feeling-first}
   ```

5. **If the user already has a GDD or design doc**: read it. The GDD is the source of truth — its phases and deliverables are taken verbatim, not reinterpreted.

## Gate

Feeling, target, and wow moment are defined (even if rough).

## Completion

- **[C] Continue** to Step 02 — Gameplay Loop
- **[D] Deeper** — explore the feeling or target further

STOP and WAIT for user input.
