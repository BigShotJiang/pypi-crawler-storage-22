# Step 02 — Gameplay Loop

**Progress: Step 2 of 4**

## MANDATORY RULES
- Read this entire file before acting
- Do NOT skip to the next step
- Do NOT load future steps
- This step is CONVERSATIONAL

## Instructions

1. **Ask the sequence question**:
   > "Décris la séquence de moments du splash screen au game over. Quels écrans sont nécessaires ? Comment on passe de l'un à l'autre ?"

2. **Build the moments table**:

   | Moment | Screen | From | To |
   |--------|--------|------|----|
   | Boot | Splash | — | Menu |
   | Menu | MainMenu | Splash, GameOver | Gameplay |
   | ... | ... | ... | ... |

3. **Optional — formalize as YAML** (if the user is ready):
   Propose writing `GAME_SEQUENCE.yaml` with the structured flow. If not ready, note in GAME_PLAN.md: "Sequence to define before building."

4. **Optional — paper prototype** (if the user wants to test ideas):
   Simulate a play session mentally:
   - Walk through the sequence moment by moment
   - At each transition: "What happens if the player does X?"
   - Look for friction points, unclear transitions, missing states

5. **Synthesize**:
   ```
   [LOOP]
   Screens: {count}
   Key transitions: {the critical ones}
   Missing: {gaps identified}
   ```

## Gate

Moments table exists. Key transitions identified.

## Completion

- **[C] Continue** to Step 03 — Vertical Slice
- **[S] Simulate** — paper prototype a session
- **[Y] YAML** — formalize the sequence

STOP and WAIT for user input.
