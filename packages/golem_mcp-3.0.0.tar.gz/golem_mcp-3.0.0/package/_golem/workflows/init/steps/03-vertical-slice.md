# Step 03 — Vertical Slice

**Progress: Step 3 of 4**

## MANDATORY RULES
- Read this entire file before acting
- Do NOT skip to the next step
- Do NOT load future steps
- This step is CONVERSATIONAL

## Instructions

1. **Ask the scope questions**:
   > "Qu'est-ce qui prouve que l'expérience fonctionne ? Quels moments sont essentiels pour le vertical slice ? Qu'est-ce qu'on coupe pour la v0 ?"

2. **Define the scope**: max 3 mechanics, max 5 screens.

3. **Cut deliverables** following these rules:
   - **By player verb, never by technical component** — "Movement + Glitch-Step" (what the player DOES) not "01 Movement, 05 Dash, 06 Chains" (what the code IS)
   - **GDD = source of truth** — if a GDD defines Phase 1 deliverables, take them 1:1. Do not atomize or reinterpret.
   - **Each deliverable includes its juice** — VFX, SFX, screenshake, particles related to a mechanic are PART of that mechanic. No separate "VFX Core" deliverable.
   - **Each deliverable is testable with its feeling** — if you can't play the deliverable and FEEL something, the split is wrong.
   - **Each deliverable produces reusable modules** — list modules explicitly (script with @export, signals, zero hardcoded game dependency).

4. **Present the deliverable list**:
   ```
   [VERTICAL SLICE]
   Mechanics: {max 3}
   Screens: {max 5}
   Deliverables:
   1. {name} — {one-line description, feeling-focused}
   2. {name} — ...
   3. {name} — ...
   ```

## Gate

Deliverable list defined with feeling-first descriptions.

## Completion

- **[C] Continue** to Step 04 — Scaffold
- **[R] Revise** — adjust scope or deliverables

STOP and WAIT for user input.
