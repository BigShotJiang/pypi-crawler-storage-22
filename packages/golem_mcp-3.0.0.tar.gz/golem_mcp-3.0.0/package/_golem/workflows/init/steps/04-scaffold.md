# Step 04 — Scaffold

**Progress: Step 4 of 4**

## MANDATORY RULES
- Read this entire file before acting
- This is the final step — EXECUTION, not conversation
- Create all files and structure

## Instructions (execute in order)

### 1. Write GAME_PLAN.md
Using the output from Steps 01-03:
- Vision (feeling, genre, reference, audience, input)
- Core mechanics (max 3)
- Gameplay loop (moments table)
- Vertical slice scope

### 2. Configure display defaults
Via `godot_project_settings action=set`:

| Key | Value |
|-----|-------|
| `display/window/size/viewport_width` | `1920` |
| `display/window/size/viewport_height` | `1080` |
| `display/window/size/window_width_override` | `1920` |
| `display/window/size/window_height_override` | `1080` |
| `display/window/stretch/mode` | `canvas_items` |
| `display/window/stretch/aspect` | `expand` |
| `display/window/size/resizable` | `true` |

**Pixel art variant** (if user mentioned pixel art/retro/low-res):
- viewport = pixel resolution (320x180, 384x216, etc.)
- window override = 1920x1080
- stretch/mode = `viewport`
- stretch/aspect = `keep`
- `rendering/textures/canvas_textures/default_texture_filter` = `0` (Nearest)

### 3. Create folder structure
Via MCP (`godot_write_script` for core scripts):
```
core/       → event_bus.gd, game_state.gd
entities/
mechanics/
data/
```
Register autoloads via `godot_project_settings`.

### 4. Create deliverables/
One `.md` file per deliverable from Step 03. Use the enrichment process:
1. Match skills from `_golem/knowledge/`
2. Match recipes from `_golem/recipes/INDEX.md`
3. Extract 3-7 pitfalls from references
4. List assets required
5. Write each deliverable file

Also create `deliverables/ASSETS.md` — consolidated asset table.

### 5. Create references/index.md
```markdown
# Project References
## Spacing
(empty — fills as you work)
## Colors
(empty)
## Components
(empty)
## Conventions
(empty)
```

### 6. Create CHECKPOINT.md
Initial checkpoint with Phase: INIT.

### 7. Present summary
```
✓ Project {name} initialized

Structure: {folders created}
Deliverables: {count} defined + ASSETS.md
Documents: GAME_PLAN.md, CHECKPOINT.md, references/index.md

→ /deliverable {first_deliverable} to start building
→ /build for direct implementation
```

## Gate

All files created. Project ready to build.

## Completion

Init is done. Suggest next actions:

- **[D] Deliverable** — start the first deliverable
- **[B] Build** — jump to implementation
- **[T] Think** — explore another aspect first

STOP and WAIT for user input.
