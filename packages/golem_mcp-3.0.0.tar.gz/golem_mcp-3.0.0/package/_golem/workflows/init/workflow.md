# Init Workflow

> Bootstrap a new Godot project from vision to deliverables and structure.

## Config

- **Agent**: Designer
- **Steps**: 4
- **Outputs**: GAME_PLAN.md, deliverables/, references/index.md, CHECKPOINT.md, project structure

## Init

1. Confirm agent is Designer (if not, load `_golem/agents/designer.md`)
2. Check if project already exists (`project.godot` present?)
3. If existing project, read state (GAME_PLAN, CHECKPOINT, deliverables)
4. Begin Step 01

## Steps

| # | File | Gate |
|---|------|------|
| 01 | `steps/01-experience.md` | Feeling + target + wow moment defined |
| 02 | `steps/02-gameplay-loop.md` | Screens/moments table + optional YAML |
| 03 | `steps/03-vertical-slice.md` | Scope defined, deliverables listed |
| 04 | `steps/04-scaffold.md` | Files created, project ready to build |

## Flow control

- Steps 01-03 are conversational (questions + answers)
- Step 04 is execution (creates files and structure)
- Each step ends with `[C] Continue` — WAIT for user input
