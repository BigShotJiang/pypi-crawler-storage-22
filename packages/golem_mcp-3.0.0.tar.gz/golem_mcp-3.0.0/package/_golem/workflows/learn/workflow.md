# Learn Workflow

> Extract errors, solutions, and discoveries from the current session.

## Config

- **Agent**: Maintainer
- **Output**: `learnings/{date}-{topic}.md`
- **Constraint**: does NOT modify references, skills, or recipes — produces a document for a human

## Instructions (execute in order)

### 1. Scan the conversation

Extract:
- **Errors encountered**: MCP tool failures, GDScript errors, Godot bugs
- **Solutions that worked**: and WHY they worked
- **New pitfalls**: not yet documented in references or rules
- **Recipe candidates**: techniques that deserve a recipe
- **Tool gaps**: missing or insufficient MCP tools
- **Knowledge gaps**: knowledge files that were lacking

### 2. Write learning file

```markdown
# Learning — {date} — {topic}

## Errors & Solutions
| Error | Cause | Solution |
|-------|-------|----------|
| ... | ... | ... |

## New Pitfalls
- [PITFALL] {description} — should go in `_golem/references/gdscript_pitfalls.md` section {X}
- [PITFALL] {description} — should go in rules `mcp-pitfalls.md`

## Recipe Candidates
- [RECIPE] {technique} — tested, worthy of a recipe in `_golem/recipes/`

## Tool Gaps
- [TOOL] {description} — had to use execute_script / workaround

## Knowledge Gaps
- [KNOWLEDGE] `{file}.md` doesn't mention pattern {X}
- [KNOWLEDGE] `{file}.md` should warn about pitfall {Y}

## Notes
- {Observations outside categories}
```

### 3. Done

```
✓ Learning saved to learnings/{filename}

Summary:
- {N} errors documented
- {M} new pitfalls
- {P} recipe candidates
- {Q} tool/knowledge gaps

→ /references to integrate patterns into project references
```

## Rules

1. **Factual** — only document what was actually encountered, not suppositions
2. **Actionable** — each item points to where it should go
3. **No modification** — /learn does NOT modify references, knowledge, or recipes
4. **No MEMORY.md** — /learn does not touch Claude's auto memory
5. **Standalone** — not invoked by other commands
