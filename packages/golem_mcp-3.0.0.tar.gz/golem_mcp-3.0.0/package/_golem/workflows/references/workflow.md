# References Workflow

> Maintain reusable patterns for the project.

## Config

- **Agent**: Maintainer
- **Output**: `references/` files

## Actions

### 1. View references
Read and display `references/index.md` with an overview of each section.

### 2. Add a reference
When a reusable pattern is detected:
```
New pattern: {name}
Category: spacing | colors | components | conventions
Value: {value}
Usage: {context}

Add to references? [y/n]
```
If yes: update `references/index.md` + category file.

### 3. Edit a reference
```
Reference: {name}
Current: {value}
New: {input}

Update? [y/n]
```
Propagate change if used elsewhere.

### 4. Delete a reference
```
⚠ Deleting reference

Reference: {name}
Used in: {file list}

Confirm? [y/n]
```

## Auto-detection during implementation

When code is being written:
- **Known value used** → silently apply from references
- **New value detected** → propose adding to references
- **Close value exists** → suggest using the reference instead

## Initialization

If `references/` doesn't exist, create:
```
references/
├── index.md
├── spacing.md
├── colors.md
├── components.md
└── conventions.md
```

## Rules

1. **Proposed, not forced** — the user decides what becomes a reference
2. **index.md is always loaded** — it's the quick reference
3. **Category files are detailed** — full specs and rules
