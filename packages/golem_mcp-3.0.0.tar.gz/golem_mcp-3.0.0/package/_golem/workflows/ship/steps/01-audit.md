# Step 01 — Audit

**Progress: Step 1 of 3**

## MANDATORY RULES
- Read this entire file before acting
- Do NOT skip to the next step
- ALWAYS show the comparison table, even if all versions match

## Instructions (execute in order)

1. **Read ALL version sources**:
   - `pyproject.toml` → `version`
   - `package/godot-plugin/plugin.cfg` → `version`
   - `README.md` → `**vX.Y.Z**`

2. **Flag desyncs** — any file already different from others.

3. **Compute target version**:
   - Take current from `pyproject.toml` (format `MAJOR.MINOR.PATCH`)
   - If user gave explicit version → use it
   - If bump type: patch = `X.Y.(Z+1)`, minor = `X.(Y+1).0`, major = `(X+1).0.0`
   - Default: patch

4. **Display comparison table**:
   ```
   | File | Current | Target |
   |------|---------|--------|
   | pyproject.toml | $CURRENT | $NEW |
   | plugin.cfg | ? | $NEW |
   | README.md | ? | $NEW |
   ```

5. **PyPI collision check**:
   ```bash
   pip index versions golem-mcp 2>/dev/null | head -1
   ```
   If target version exists on PyPI → bump again until unpublished version found.

## Gate

Comparison table displayed. Target version confirmed.

## Completion

- **[C] Continue** to Step 02 — Bump
- **[V] Version** — use a different target version

STOP and WAIT for user input.
