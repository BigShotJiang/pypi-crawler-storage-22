# Step 02 — Bump

**Progress: Step 2 of 3**

## MANDATORY RULES
- Read this entire file before acting
- Do NOT skip to the next step

## Instructions (execute in order)

1. **Bump each file** where version differs from target:
   - `pyproject.toml`: `version = "X.Y.Z"` → `version = "$NEW"`
   - `package/godot-plugin/plugin.cfg`: `version="X.Y.Z"` → `version="$NEW"`
   - `README.md`: `**vX.Y.Z**` → `**v$NEW**`

2. **Re-read all three files** to confirm the version is correct.

3. **Display confirmation table**:
   ```
   | File | Version | Status |
   |------|---------|--------|
   | pyproject.toml | $NEW | ✓ |
   | plugin.cfg | $NEW | ✓ |
   | README.md | $NEW | ✓ |
   ```

## Gate

All versions synced to target.

## Completion

- **[C] Continue** to Step 03 — Publish

STOP and WAIT for user input.
