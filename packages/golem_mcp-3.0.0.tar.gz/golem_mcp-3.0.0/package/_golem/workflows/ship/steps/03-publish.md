# Step 03 — Publish

**Progress: Step 3 of 3**

## MANDATORY RULES
- Read this entire file before acting
- NEVER auto-commit or auto-publish
- This is the final step

## Instructions (execute in order)

1. **Clean dist/**:
   ```bash
   rm -rf dist/*
   ```

2. **Build**:
   ```bash
   uv build
   ```
   Verify output filenames contain the correct version.

3. **Verify wheel content**:
   ```bash
   python3 -m zipfile -l dist/golem_mcp-$NEW-py3-none-any.whl | grep golem_mcp_data
   ```
   Count files per subdirectory, compare with source. If mismatch → STOP.

4. **Check for symlink leaks** — `.claude/rules/` symlinks should NOT be in the wheel.

5. **Present summary**:
   ```
   ## Ship $NEW — Ready

   Version synced ($NEW):
     ✓ pyproject.toml
     ✓ plugin.cfg
     ✓ README.md

   Build artifacts:
     ✓ dist/golem_mcp-$NEW.tar.gz
     ✓ dist/golem_mcp-$NEW-py3-none-any.whl

   Next steps:
     1. git add -A && git commit -m "Bump version to $NEW"
     2. uv publish (or twine upload dist/*)
     3. git tag v$NEW && git push --tags
   ```

## Gate

Build artifacts verified. Summary displayed.

## Completion

Ship is ready. Do NOT auto-commit or auto-publish. The user decides.

- **[K] Checkpoint** — snapshot before shipping
- **[L] Learn** — capture release learnings

STOP and WAIT for user input.
