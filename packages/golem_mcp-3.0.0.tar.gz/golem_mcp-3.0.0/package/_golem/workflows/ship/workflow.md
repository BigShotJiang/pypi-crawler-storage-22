# Ship Workflow

> Version sync, clean build, PyPI deployment.

## Config

- **Agent**: Maintainer
- **Steps**: 3
- **Outputs**: bumped versions, build artifacts, summary

## Init

1. Confirm agent is Maintainer (if not, load `_golem/agents/maintainer.md`)
2. Parse input: bump type (patch/minor/major) or explicit version
3. Default to `patch` if nothing specified
4. Begin Step 01

## Steps

| # | File | Gate |
|---|------|------|
| 01 | `steps/01-audit.md` | Version comparison table displayed |
| 02 | `steps/02-bump.md` | All versions synced to target |
| 03 | `steps/03-publish.md` | Build artifacts verified |

## Flow control

- Each step ends with `[C] Continue` — WAIT for user input
- NEVER auto-commit or auto-publish
