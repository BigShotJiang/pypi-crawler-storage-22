# Step 01 — Interrogate

**Progress: Step 1 of 3**

## MANDATORY RULES
- Read this entire file before acting
- Do NOT skip to the next step
- Do NOT load future steps
- Feeling first — ALWAYS

## Instructions

1. **Ask the feeling question FIRST**:
   > "C'est quoi l'émotion visée ? Qu'est-ce que le joueur/utilisateur doit RESSENTIR ?"

   Do NOT proceed to mechanics until the user has answered this question.

2. **Follow-up questions** (adapt to context):
   - Genre? 2D/3D? Input method?
   - Core mechanics? (max 3 — if the user proposes more, challenge the scope)
   - Visual reference? A game, a moment, a screenshot?
   - Who is the target audience?

3. **If the user doesn't know**, propose concrete options:
   - "Tu veux que le joueur ressente de la tension, de la puissance, de la découverte ?"
   - "Plutôt Elden Ring (vertige d'échelle) ou Balatro (satisfaction de synergie) ?"

4. **Synthesize** as a pitch in 2-3 sentences:
   ```
   [PITCH] {The game/feature in 2-3 sentences, feeling-first}
   ```

## Gate

The pitch must exist and contain a feeling statement.

## Completion

- **[C] Continue** to Step 02 — Scan
- **[D] Deeper** — explore the feeling further

STOP and WAIT for user input.
