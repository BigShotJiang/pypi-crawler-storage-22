# Step 02 — Scan

**Progress: Step 2 of 3**

## MANDATORY RULES
- Read this entire file before acting
- Do NOT skip to the next step
- Do NOT load future steps
- Read-only — no modifications

## Instructions

1. **Scan the project** (if a Godot project exists):
   ```
   godot_project_context
   godot_get_scene_tree
   godot_get_editor_screenshot
   ```
   Read existing scripts to understand what's already built. NEVER propose a feature without checking it doesn't already exist.

2. **Scan tracking files** (if they exist, ignore silently if not):
   - `GAME_PLAN.md` — existing vision and mechanics
   - `CHECKPOINT.md` — current phase and progress
   - `deliverables/*.md` — existing deliverables and their status
   - `references/index.md` — established patterns

3. **Identify gaps** between the pitch (Step 01) and current state:
   ```
   [SCAN] Project state:
   - Existing: {what's already built}
   - Missing: {what needs to be built for the pitch}
   - Conflicts: {anything that contradicts the pitch}
   ```

4. **If no project exists**: skip scan, note it, move to Step 03.

## Gate

Project state understood (or acknowledged as non-existent).

## Completion

- **[C] Continue** to Step 03 — Document
- **[S] Scan more** — inspect specific nodes or scripts

STOP and WAIT for user input.
