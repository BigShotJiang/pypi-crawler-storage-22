# Step 03 — Document

**Progress: Step 3 of 3**

## MANDATORY RULES
- Read this entire file before acting
- This is the final step
- Write the document to the PROJECT, not just the conversation

## Instructions

1. **Choose the document format** based on what was discussed:

   | Discussion type | Output | Location |
   |-----------------|--------|----------|
   | New game/project | GAME_PLAN.md | Project root |
   | New feature/system | Design section in GAME_PLAN.md | Project root |
   | Architecture | Architecture section in plan | Project root |
   | UX audit | Audit report | Conversation only |
   | Game flow | GAME_SEQUENCE.yaml | Project root |

2. **Write GAME_PLAN.md** (if new game/project):
   ```markdown
   # {Project Name} — Game Plan

   ## Vision
   > {Pitch from Step 01 — feeling-first, 2-3 sentences}

   ## Feeling
   {Primary emotion the player should feel}

   ## Core Mechanics (max 3)
   1. {mechanic} — serves feeling: {how}
   2. {mechanic} — serves feeling: {how}
   3. {mechanic} — serves feeling: {how}

   ## Gameplay Loop
   | Moment | Screen | From | To |
   |--------|--------|------|----|
   | {moment} | {screen} | {prev} | {next} |

   ## Vertical Slice Scope
   - Max 3 mechanics, max 5 screens
   - {what proves the experience works}

   ## Phases
   - Phase 1: {shippable MVP}
   - Phase 2: {better}
   - Phase 3: {polish}

   ## Wow Moment
   > {The one moment that makes the player go "holy shit"}
   ```

3. **Present next actions**:
   ```
   [DOCUMENT] {filename} written.

   → /build to start implementing
   → /init to bootstrap project structure
   → /think to explore another aspect
   ```

## Gate

Document written to project.

## Completion

Design is done. Suggest next actions:

- **[B] Build** — start implementing with `/build`
- **[I] Init** — bootstrap project structure with `/init`
- **[T] Think more** — explore another aspect

STOP and WAIT for user input.
