# Think Workflow

> Brainstorm, design, plan — read-only, no code.

## Config

- **Agent**: Designer
- **Steps**: 3
- **Outputs**: GAME_PLAN.md or design document
- **Constraint**: READ-ONLY — no write_script, no add_node, no execute_script

## Allowed MCP tools

`godot_get_scene_tree`, `godot_inspect_node`, `godot_view_script`, `godot_project_context`, `godot_get_editor_screenshot`, `godot_project_settings(action="list"|"get")`, `godot_find_nodes`, `godot_get_input_map`

## Init

1. Confirm agent is Designer (if not, load `_golem/agents/designer.md`)
2. Identify the topic from user input
3. Begin Step 01

## Steps

| # | File | Gate |
|---|------|------|
| 01 | `steps/01-interrogate.md` | Feeling identified, core questions answered |
| 02 | `steps/02-scan.md` | Project state understood |
| 03 | `steps/03-document.md` | Design document written to project |

## Flow control

- Each step ends with `[C] Continue` — WAIT for user input
- Steps MUST execute in order
- The user may stay in any step to explore further
