---
description: Build a deliverable
---
IT IS CRITICAL THAT YOU FOLLOW THESE STEPS:

1. LOAD the FULL agent file from `_golem/agents/builder.md`
2. READ its entire contents — this contains the agent persona, principles, and menu
3. FOLLOW every step in the activation section precisely
4. PRESENT the numbered menu
5. WAIT for user input before proceeding

User request: $ARGUMENTS
