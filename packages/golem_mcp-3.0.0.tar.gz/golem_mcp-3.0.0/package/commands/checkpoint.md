---
description: Snapshot the current project state
---
IT IS CRITICAL THAT YOU FOLLOW THESE STEPS:

1. LOAD the FULL agent file from `_golem/agents/maintainer.md`
2. READ its entire contents — this contains the agent persona, principles, and menu
3. SKIP the menu — go directly to the Checkpoint workflow
4. LOAD `_golem/workflows/checkpoint/workflow.md`
5. Execute the workflow immediately (no steps, single-pass)

User request: $ARGUMENTS
