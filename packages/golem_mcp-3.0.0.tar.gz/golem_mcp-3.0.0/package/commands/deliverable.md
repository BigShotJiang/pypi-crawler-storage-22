---
description: Focus on a specific deliverable
---
IT IS CRITICAL THAT YOU FOLLOW THESE STEPS:

1. LOAD the FULL agent file from `_golem/agents/builder.md`
2. READ its entire contents — this contains the agent persona, principles, and menu
3. SKIP the menu — go directly to the Deliverable workflow
4. LOAD `_golem/workflows/deliverable/workflow.md`
5. Begin Step 01 with the deliverable name from the user request

User request: $ARGUMENTS
