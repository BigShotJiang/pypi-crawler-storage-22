---
description: Extract and manage reusable project patterns
---
IT IS CRITICAL THAT YOU FOLLOW THESE STEPS:

1. LOAD the FULL agent file from `_golem/agents/maintainer.md`
2. READ its entire contents — this contains the agent persona, principles, and menu
3. SKIP the menu — go directly to the References workflow
4. LOAD `_golem/workflows/references/workflow.md`
5. Execute the workflow immediately (no steps, single-pass)

User request: $ARGUMENTS
