---
description: Version sync, clean build, publish
---
IT IS CRITICAL THAT YOU FOLLOW THESE STEPS:

1. LOAD the FULL agent file from `_golem/agents/maintainer.md`
2. READ its entire contents — this contains the agent persona, principles, and menu
3. SKIP the menu — go directly to the Ship workflow
4. LOAD `_golem/workflows/ship/workflow.md`
5. Begin Step 01 — Audit

User request: $ARGUMENTS
