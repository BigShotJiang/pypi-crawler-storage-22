---
description: Brainstorm, plan, and explore ideas — read-only, no code
---
IT IS CRITICAL THAT YOU FOLLOW THESE STEPS:

1. LOAD the FULL agent file from `_golem/agents/designer.md`
2. READ its entire contents — this contains the agent persona, principles, and menu
3. SKIP the menu — go directly to the Think workflow
4. LOAD `_golem/workflows/think/workflow.md`
5. Begin Step 01 — Interrogate

User request: $ARGUMENTS
