#!/usr/bin/env python3

"""
GoodGute(V1.0.1) - AI-powered EN→DE translator
==================================

Author: Paddy
Version: 0.1.0
Date: 2026-02-13
"""

__author__ = "Paddy"
__version__ = "1.0.1"

import argparse
from .translator import translate_preserve_paragraphs, print_translation_header, quality_evaluate, render_qe_output, safe_json_loads,text_stat_before
from . import translator, cache
import warnings
from .dev_logging import setup_logging
import time
from colorama import Fore, Style, init
init(autoreset=True)
import webbrowser
from .trans_docx import *
from .trans_pdf import *
import sys
from .logo import handle_goodgute_cli_logo
from pathlib import Path
FIRST_RUN_FILE = Path.home() / ".goodgute_first_run"


def Access_UI():
    url = "https://www.goodgute.app"
    webbrowser.open(url)

def Access_UI_Dev():
    url = "https://www.goodgute.dev"
    webbrowser.open(url)

def main():
    parser = argparse.ArgumentParser(
    prog="goodgute",
    description="GoodGute(V1.0.1) - AI-powered EN→DE translator",
    epilog='Example: goodgute -t "Hello, World!"'
)

    # ----------------------USER mode-----------------------------#
    trans_group = parser.add_mutually_exclusive_group()

    trans_group.add_argument("-t", "--text", type=str, help="Text to translate")
    trans_group.add_argument("-f", "--file", action="store_true", help="File to translate")

    parser.add_argument("--format", choices=["pdf", "docx", "txt"], help="File Format: TXT, DOCX or PDF")
    parser.add_argument("-i", "--input", help="File Input Directory")
    parser.add_argument("-o", "--output", help="File Output Directory")
    parser.add_argument("-q", "--quality_eval", action="store_true", help="Translation Quality Evaluation By AI Perplexity")
    parser.add_argument("-D", "--dev", action="store_true", help="Development Mode")
    parser.add_argument("-s", "--stat", action="store_true", help="Transaltion Service Statistics: API_CALLS, WORDS_COUNT, ..")
    parser.add_argument("--time", action="store_true", help="Translation Execution Time")
    #parser.add_argument("--ui", action="store_true", help="Transaltion Service Web UI")
    #parser.add_argument("--ui-dev", action="store_true", help="Transaltion Service Web Dev UI")
    parser.add_argument("-v", "--version", action="store_true", help="Translation Service Version")
    parser.add_argument("-c", "--clean_cache", action="store_true", help="Clean the cache if have")

    if len(sys.argv) == 1:
        handle_goodgute_cli_logo()
        parser.print_usage()
        print('\nExample: goodgute -t "Hello, World!"')
        sys.exit(0)


    cache_group = parser.add_mutually_exclusive_group()
    cache_group.add_argument(
        "--cache",
        action="store_true",
        help="Enable cache"
    )
    cache_group.add_argument(
        "--no-cache",
        action="store_true",
        help="Disable cache, Default: [ON]"
    )

    verbose_group = parser.add_mutually_exclusive_group()
    verbose_group.add_argument(
        "--verbose",
        action="store_true",
        help="Enable verbose mode, Default: [ON]"
    )
    verbose_group.add_argument(
        "--no-verbose",
        action="store_true",
        help="Disable verbose mode"
    )

    ui_group = parser.add_mutually_exclusive_group()

    ui_group.add_argument(
        "--ui",
        action="store_true",
        help="Transaltion Service Web UI"
    )
    ui_group.add_argument(
        "--ui-dev",
        action="store_true",
        help="Transaltion Service Web Dev UI"
    )

    args = parser.parse_args()

    if args.version:
        print(f"{Fore.GREEN}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute] V1.0.1")
        sys.exit(0)


    if args.ui:
        print(f"{Fore.GREEN}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute] Web UI is starting...")
        Access_UI()
        sys.exit(0)

    if args.ui_dev:
        print(f"{Fore.GREEN}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute] Web Dev UI is starting...")
        Access_UI_Dev()
        sys.exit(0)

    
    if (args.cache or args.no_cache) and not (args.text or args.file):
        parser.error(
            "--cache / --no-cache requires --text or --file to be specified"
        )

    if (args.verbose or args.no_verbose) and not (args.text or args.file):
        parser.error(
            "--verbose / --no-verbose requires --text or --file to be specified"
        )
   
    
    if args.no_cache:
        translator.CACHE_ENABLED = False
    elif args.cache:
        translator.CACHE_ENABLED = True

    if args.verbose:
        translator.VERBOSE_ENABLED = True
    elif args.no_verbose:
        translator.VERBOSE_ENABLED = False

    if args.quality_eval and not (args.text or args.file):
        parser.error(
                f"when using --quality_eval, the following arguments are required: "
                f"{', '.join(['--file or --text'])}"
            )

    if args.file:
        missing = []

        if not args.format:
            missing.append("--format")
        if not args.input:
            missing.append("--input")
        if not args.output:
            missing.append("--output")

        if missing:
            parser.error(
                f"when using --file, the following arguments are required: "
                f"{', '.join(missing)}"
            )

    #---------------------------DEV mode------------------------------#

    if args.time and not args.dev:
            parser.error(
                f"when using --time, the following arguments are required: "
                f"{', '.join(['--dev'])}"
            )

    if args.stat and not args.dev:
        parser.error(
            f"when using --stat, the following arguments are required: "
            f"{', '.join(['--dev'])}"
        )

    if args.clean_cache and not args.dev:
        parser.error(
            f"when using --clean_cache, the following arguments are required: "
            f"{', '.join(['--dev'])}"
        )

    logger = None
    if args.dev:
        translator.DEV_ENABLED = True
        logger = setup_logging()
        print("\n")
        logger.info(f"{Fore.MAGENTA}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute {Fore.MAGENTA}{Style.BRIGHT}Dev{Style.RESET_ALL}] GoodGute CLI Development mode: [{Fore.GREEN}{Style.BRIGHT}ON{Style.RESET_ALL}]")
        logger.info(f"{Fore.MAGENTA}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute {Fore.MAGENTA}{Style.BRIGHT}Dev{Style.RESET_ALL}] GoodGute CLI [{Fore.MAGENTA}{Style.BRIGHT}Config{Style.RESET_ALL}]: ")
        if args.text:
            logger.info(f"{Fore.MAGENTA}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute {Fore.MAGENTA}{Style.BRIGHT}Dev{Style.RESET_ALL}] Translation Type: [{Fore.GREEN}{Style.BRIGHT}TEXT{Style.RESET_ALL}]")
            preview_words_strip = (args.text).strip()
            if len(preview_words_strip) > 3:
                words = preview_words_strip.split()
                preview_words = ' '.join(words[:3])
                logger.info(f"{Fore.MAGENTA}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute {Fore.MAGENTA}{Style.BRIGHT}Dev{Style.RESET_ALL}] Text Preview: {Fore.GREEN}{Style.BRIGHT}'{Style.RESET_ALL}{preview_words} ...{Fore.GREEN}{Style.BRIGHT}'{Style.RESET_ALL}")
        elif args.file:
            logger.info(f"{Fore.MAGENTA}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute {Fore.MAGENTA}{Style.BRIGHT}Dev{Style.RESET_ALL}] Translation Type: [{Fore.GREEN}{Style.BRIGHT}FILE{Style.RESET_ALL}] Format: [{Fore.GREEN}{Style.BRIGHT}{args.format}{Style.RESET_ALL}]")
            logger.info(f"{Fore.MAGENTA}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute {Fore.MAGENTA}{Style.BRIGHT}Dev{Style.RESET_ALL}] Input_Dir: {Fore.GREEN}{Style.BRIGHT}'{Style.RESET_ALL}{args.input}{Fore.GREEN}{Style.BRIGHT}'{Style.RESET_ALL}")
            logger.info(f"{Fore.MAGENTA}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute {Fore.MAGENTA}{Style.BRIGHT}Dev{Style.RESET_ALL}] Output_Dir: {Fore.GREEN}{Style.BRIGHT}'{Style.RESET_ALL}{args.output}{Fore.GREEN}{Style.BRIGHT}'{Style.RESET_ALL}")

        if args.cache:
            logger.info(f"{Fore.MAGENTA}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute {Fore.MAGENTA}{Style.BRIGHT}Dev{Style.RESET_ALL}] Cache_Mode: [{Fore.GREEN}{Style.BRIGHT}ON{Style.RESET_ALL}], Using cache file: {cache.CACHE_PATH}")
        elif args.no_cache:
            logger.info(f"{Fore.MAGENTA}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute {Fore.MAGENTA}{Style.BRIGHT}Dev{Style.RESET_ALL}] Cache_Mode: [{Fore.RED}{Style.BRIGHT}OFF]{Style.RESET_ALL}")


        if args.verbose:
            logger.info(f"{Fore.MAGENTA}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute {Fore.MAGENTA}{Style.BRIGHT}Dev{Style.RESET_ALL}] Verbose_Mode: [{Fore.GREEN}{Style.BRIGHT}ON{Style.RESET_ALL}]")
        elif args.no_verbose:
            logger.info(f"{Fore.MAGENTA}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute {Fore.MAGENTA}{Style.BRIGHT}Dev{Style.RESET_ALL}] Verbose_Mode: [{Fore.RED}{Style.BRIGHT}OFF{Style.RESET_ALL}]")
    
        if args.quality_eval:
            logger.info(f"{Fore.MAGENTA}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute {Fore.MAGENTA}{Style.BRIGHT}Dev{Style.RESET_ALL}] Quality_Eval_Mode: [{Fore.GREEN}{Style.BRIGHT}ON{Style.RESET_ALL}]")
        elif not args.quality_eval:
            logger.info(f"{Fore.MAGENTA}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute {Fore.MAGENTA}{Style.BRIGHT}Dev{Style.RESET_ALL}] Quality_Eval_Mode: [{Fore.RED}{Style.BRIGHT}OFF{Style.RESET_ALL}]")
        
        if args.clean_cache:
            cache.cache_clean()
            logger.info(f"{Fore.MAGENTA}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute {Fore.MAGENTA}{Style.BRIGHT}Dev{Style.RESET_ALL}] Clean_Cache: [{Fore.GREEN}{Style.BRIGHT}DONE{Style.RESET_ALL}]")

    else:
        translator.DEV_ENABLED = False
        

    
    #------------------------ Translation arguments logic------------------------#

    if args.text or args.file:
        if not FIRST_RUN_FILE.exists():
            handle_goodgute_cli_logo()
            FIRST_RUN_FILE.touch()

        if args.time:
            start_time = time.time()
        
        if args.file:
            if args.format  == "txt":
                try:
                    with open(args.input, "r", encoding="utf-8") as f:
                        text = f.read()
                except Exception as e:
                    if args.dev:
                        raise RuntimeError(e)
                    else:
                        print(f"\n\n {Fore.RED}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute] Error: {e}")
                        sys.exit(1)
                    
                if args.dev:
                    text_copy = text
                    para_num, words_count, chunk_num, API_calling_times, block_max_chars = text_stat_before(text_copy)
                    logger.info(f"{Fore.MAGENTA}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute {Fore.MAGENTA}{Style.BRIGHT}Dev{Style.RESET_ALL}] Para_Num: {Fore.GREEN}{Style.BRIGHT}{para_num}{Style.RESET_ALL}")
                    logger.info(f"{Fore.MAGENTA}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute {Fore.MAGENTA}{Style.BRIGHT}Dev{Style.RESET_ALL}] Words_Count: {Fore.GREEN}{Style.BRIGHT}{words_count}{Style.RESET_ALL}")
                    logger.info(f"{Fore.MAGENTA}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute {Fore.MAGENTA}{Style.BRIGHT}Dev{Style.RESET_ALL}] Split_Text_Chunk_Num: {Fore.GREEN}{Style.BRIGHT}{chunk_num}{Style.RESET_ALL}")
                    logger.info(f"{Fore.MAGENTA}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute {Fore.MAGENTA}{Style.BRIGHT}Dev{Style.RESET_ALL}] Chunk_Max_Words: {Fore.GREEN}{Style.BRIGHT}{block_max_chars}{Style.RESET_ALL}")
                    logger.info(f"{Fore.MAGENTA}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute {Fore.MAGENTA}{Style.BRIGHT}Dev{Style.RESET_ALL}] [HF] Est_API_Req_Calls: {Fore.GREEN}{Style.BRIGHT}{API_calling_times}{Style.RESET_ALL}")
                if args.quality_eval:
                    logger.info(f"{Fore.MAGENTA}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute {Fore.MAGENTA}{Style.BRIGHT}Dev{Style.RESET_ALL}] [Pplx] Est_API_Req_Calls: {Fore.GREEN}{Style.BRIGHT}1{Style.RESET_ALL}")
                
                translation_result, para_num, words_count_before, words_count_after, total_api_req_calls, total_num_cache_hit, total_num_cache_miss = translate_preserve_paragraphs(text)
                
                print_translation_header()
                print(translation_result+"\n\n")
                print(f"{Fore.GREEN}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute] File_Translation_Status: [{Fore.GREEN}{Style.BRIGHT}DONE{Style.RESET_ALL}]\n\n")
                
                try:
                    with open(args.output, 'w', encoding='utf-8') as f:
                        text = f.write(translation_result)
                except Exception as e:
                    if args.dev:
                        raise RuntimeError(e)
                    else:
                        print(f"\n\n {Fore.RED}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute] Error: {e}")
                        sys.exit(1)

                print(f"{Fore.GREEN}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute] File_Output_Status: [{Fore.GREEN}{Style.BRIGHT}DONE{Style.RESET_ALL}]\n\n")

                if args.quality_eval:
                    try:
                        eval = quality_evaluate(text, translation_result)
                        render_qe_output(safe_json_loads(eval))
                    except Exception:
                        pass
                    if translator.PPLX_SUCCESS:
                        print(f"{Fore.GREEN}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute] Quality_Eval_Status: [{Fore.GREEN}{Style.BRIGHT}DONE{Style.RESET_ALL}]\n\n")
                    elif not translator.PPLX_SUCCESS:
                        print(f"{Fore.GREEN}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute] Quality_Eval_Status: [{Fore.RED}{Style.BRIGHT}ERROR{Style.RESET_ALL}]\n\n")

            elif args.format == "docx":

                if args.dev:
                    if args.quality_eval:
                        logger.info(f"{Fore.MAGENTA}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute {Fore.MAGENTA}{Style.BRIGHT}Dev{Style.RESET_ALL}] [Pplx] Est_API_Req_Calls: {Fore.GREEN}{Style.BRIGHT}1{Style.RESET_ALL}")
                items, para_num, words_count_before, words_count_after, total_api_req_calls, total_num_cache_hit, total_num_cache_miss = extract_and_translate_docx(args.input)
                render_docx(items, args.output)
                print(f"{Fore.GREEN}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute] File_Translation_Status: [{Fore.GREEN}{Style.BRIGHT}DONE{Style.RESET_ALL}]\n\n")
                print(f"{Fore.GREEN}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute] File_Output_Status: [{Fore.GREEN}{Style.BRIGHT}DONE{Style.RESET_ALL}]\n\n")
                
                if args.quality_eval:
                    try:
                        text = extract_docx_text(input_path=args.input)
                        translation_result = translate_docx(text)
                        eval = quality_evaluate(text, translation_result)
                        render_qe_output(safe_json_loads(eval))
                    except Exception:
                        pass
                    if translator.PPLX_SUCCESS:
                        print(f"{Fore.GREEN}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute] Quality_Eval_Status: [{Fore.GREEN}{Style.BRIGHT}DONE{Style.RESET_ALL}]\n\n")
                    elif not translator.PPLX_SUCCESS:
                        print(f"{Fore.GREEN}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute] Quality_Eval_Status: [{Fore.RED}{Style.BRIGHT}ERROR{Style.RESET_ALL}]\n\n")
            
            elif args.format == "pdf":

                if args.dev:
                    if args.quality_eval:
                        logger.info(f"{Fore.MAGENTA}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute {Fore.MAGENTA}{Style.BRIGHT}Dev{Style.RESET_ALL}] [Pplx] Est_API_Req_Calls: {Fore.GREEN}{Style.BRIGHT}1{Style.RESET_ALL}")
                items, para_num, words_count_before, words_count_after, total_api_req_calls, total_num_cache_hit, total_num_cache_miss = extract_and_process_pdf(args.input)
                render_pdf(items, args.output)
                print(f"{Fore.GREEN}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute] File_Translation_Status: [{Fore.GREEN}{Style.BRIGHT}DONE{Style.RESET_ALL}]\n\n")
                print(f"{Fore.GREEN}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute] File_Output_Status: [{Fore.GREEN}{Style.BRIGHT}DONE{Style.RESET_ALL}]\n\n")
                
                if args.quality_eval:
                    try:
                        text = extract_pdf_text(input_path=args.input)
                        translation_result = translate_pdf(text)
                        eval = quality_evaluate(text, translation_result)
                        render_qe_output(safe_json_loads(eval))
                    except Exception:
                        pass
                    if translator.PPLX_SUCCESS:
                        print(f"{Fore.GREEN}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute] Quality_Eval_Status: [{Fore.GREEN}{Style.BRIGHT}DONE{Style.RESET_ALL}]\n\n")
                    elif not translator.PPLX_SUCCESS:
                        print(f"{Fore.GREEN}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute] Quality_Eval_Status: [{Fore.RED}{Style.BRIGHT}ERROR{Style.RESET_ALL}]\n\n")

        else:   
            
            text = args.text
            if args.dev:
                text_copy = text
                para_num, words_count, chunk_num, API_calling_times, block_max_chars = text_stat_before(text_copy)
                logger.info(f"{Fore.MAGENTA}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute {Fore.MAGENTA}{Style.BRIGHT}Dev{Style.RESET_ALL}] Para_Num: {Fore.GREEN}{Style.BRIGHT}{para_num}{Style.RESET_ALL}")
                logger.info(f"{Fore.MAGENTA}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute {Fore.MAGENTA}{Style.BRIGHT}Dev{Style.RESET_ALL}] Words_Count: {Fore.GREEN}{Style.BRIGHT}{words_count}{Style.RESET_ALL}")
                logger.info(f"{Fore.MAGENTA}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute {Fore.MAGENTA}{Style.BRIGHT}Dev{Style.RESET_ALL}] Split_Text_Chunk_Num: {Fore.GREEN}{Style.BRIGHT}{chunk_num}{Style.RESET_ALL}")
                logger.info(f"{Fore.MAGENTA}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute {Fore.MAGENTA}{Style.BRIGHT}Dev{Style.RESET_ALL}] Chunk_Max_Words: {Fore.GREEN}{Style.BRIGHT}{block_max_chars}{Style.RESET_ALL}")
                logger.info(f"{Fore.MAGENTA}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute {Fore.MAGENTA}{Style.BRIGHT}Dev{Style.RESET_ALL}] [HF] Est_API_Req_Calls: {Fore.GREEN}{Style.BRIGHT}{API_calling_times}{Style.RESET_ALL}")
            if args.quality_eval:
                logger.info(f"{Fore.MAGENTA}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute {Fore.MAGENTA}{Style.BRIGHT}Dev{Style.RESET_ALL}] [Pplx] Est_API_Req_Calls: {Fore.GREEN}{Style.BRIGHT}1{Style.RESET_ALL}")
            
        
            translation_result, para_num, words_count_before, words_count_after, total_api_req_calls, total_num_cache_hit, total_num_cache_miss = translate_preserve_paragraphs(text)
            print_translation_header()
            print(translation_result+"\n\n")
            print(f"{Fore.GREEN}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute] Text_Translation_Status: [{Fore.GREEN}{Style.BRIGHT}DONE{Style.RESET_ALL}]\n\n")
                
            if args.quality_eval:
                try:
                    eval = quality_evaluate(text, translation_result)
                    render_qe_output(safe_json_loads(eval))
                except Exception:
                    pass
                if translator.PPLX_SUCCESS:
                        print(f"{Fore.GREEN}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute] Quality_Eval_Status: [{Fore.GREEN}{Style.BRIGHT}DONE{Style.RESET_ALL}]\n\n")
                elif not translator.PPLX_SUCCESS:
                        print(f"{Fore.GREEN}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute] Quality_Eval_Status: [{Fore.RED}{Style.BRIGHT}ERROR{Style.RESET_ALL}]\n\n")


        if args.time:
            end_time = time.time()
            logger.info(f"{Fore.MAGENTA}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute {Fore.MAGENTA}{Style.BRIGHT}Dev{Style.RESET_ALL}] GoodGute CLI [{Fore.MAGENTA}{Style.BRIGHT}Time{Style.RESET_ALL}] Execution time: {Fore.GREEN}{Style.BRIGHT}{end_time - start_time:.2f}{Style.RESET_ALL} s")

        if args.stat:
            logger.info(f"{Fore.MAGENTA}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute {Fore.MAGENTA}{Style.BRIGHT}Dev{Style.RESET_ALL}] GoodGute CLI [{Fore.MAGENTA}{Style.BRIGHT}Stat{Style.RESET_ALL}]:")
            logger.info(f"{Fore.MAGENTA}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute {Fore.MAGENTA}{Style.BRIGHT}Dev{Style.RESET_ALL}] Para_Num: {Fore.GREEN}{Style.BRIGHT}{para_num}{Style.RESET_ALL}")
            logger.info(f"{Fore.MAGENTA}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute {Fore.MAGENTA}{Style.BRIGHT}Dev{Style.RESET_ALL}] Words_Count_Before_Translation: {Fore.GREEN}{Style.BRIGHT}{words_count_before}{Style.RESET_ALL}")
            logger.info(f"{Fore.MAGENTA}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute {Fore.MAGENTA}{Style.BRIGHT}Dev{Style.RESET_ALL}] Words_Count_After_Translation: {Fore.GREEN}{Style.BRIGHT}{words_count_after}{Style.RESET_ALL}")
            if args.cache:
                cache_hit_rate = float(total_num_cache_hit / (total_num_cache_hit + total_num_cache_miss) * 100)
                logger.info(f"{Fore.MAGENTA}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute {Fore.MAGENTA}{Style.BRIGHT}Dev{Style.RESET_ALL}] Cache_Hit: {Fore.GREEN}{Style.BRIGHT}{total_num_cache_hit}{Style.RESET_ALL}")
                logger.info(f"{Fore.MAGENTA}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute {Fore.MAGENTA}{Style.BRIGHT}Dev{Style.RESET_ALL}] Cache_Miss: {Fore.GREEN}{Style.BRIGHT}{total_num_cache_miss}{Style.RESET_ALL}")
                logger.info(f"{Fore.MAGENTA}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute {Fore.MAGENTA}{Style.BRIGHT}Dev{Style.RESET_ALL}] Cache_Hit_Rate: {Fore.GREEN}{Style.BRIGHT}{cache_hit_rate:.2f}{Style.RESET_ALL}%")
                
            logger.info(f"{Fore.MAGENTA}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute {Fore.MAGENTA}{Style.BRIGHT}Dev{Style.RESET_ALL}] [HF] API_Req_Calls: {Fore.GREEN}{Style.BRIGHT}{total_api_req_calls}{Style.RESET_ALL}")
            if total_api_req_calls > 0:
                logger.info(f"{Fore.MAGENTA}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute {Fore.MAGENTA}{Style.BRIGHT}Dev{Style.RESET_ALL}] [HF] API_Req_Success_Rate: {Fore.GREEN}{Style.BRIGHT}100.0{Style.RESET_ALL}%")
            if args.cache:
                logger.info(f"{Fore.MAGENTA}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute {Fore.MAGENTA}{Style.BRIGHT}Dev{Style.RESET_ALL}] [HF] API_Req_Calls_Saved: {Fore.GREEN}{Style.BRIGHT}{total_num_cache_hit}{Style.RESET_ALL}")
            

            if args.quality_eval:
                if args.dev:
                    logger.info(f"{Fore.MAGENTA}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute {Fore.MAGENTA}{Style.BRIGHT}Dev{Style.RESET_ALL}] [Pplx] API_Req_Calls: {Fore.GREEN}{Style.BRIGHT}1{Style.RESET_ALL}")
                if not translator.PPLX_SUCCESS:
                    logger.info(f"{Fore.MAGENTA}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute {Fore.MAGENTA}{Style.BRIGHT}Dev{Style.RESET_ALL}] [Pplx] API_Req_Success_Rate: {Fore.GREEN}{Style.BRIGHT}0.0{Style.RESET_ALL}%")
                else:
                    logger.info(f"{Fore.MAGENTA}{Style.BRIGHT}>{Style.RESET_ALL} [GoodGute {Fore.MAGENTA}{Style.BRIGHT}Dev{Style.RESET_ALL}] [Pplx] API_Req_Success_Rate: {Fore.GREEN}{Style.BRIGHT}100.0{Style.RESET_ALL}%")
                
                    
    warnings.filterwarnings("ignore")


if __name__ == "__main__":

    main()
