import logging
import sys

# 工厂函数，方便在 CLI 初始化时设置
def setup_logging(develop_mode=False, verbose=False):
    logger = logging.getLogger("GoodGute")
    logger.setLevel(logging.INFO)

    # 避免重复添加 Handler
    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        formatter = logging.Formatter(
            "[%(levelname)s] %(asctime)s - %(message)s", datefmt="%H:%M:%S"
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)

    return logger

