



from colorama import Fore, Style, init
init(autoreset=True)


icon = """                        
                                                   
                 ++++             ++++             
               +++++++++        +++++++++          
              ++++++++++++     ++++++++++++        
            ++++++++++++++++ ++++++++++++++++      
           ++++++     +++++++++ +++    +++++++++   
         +++++++        ++++++++          +++++++  
        ++++++            ++++++           ++++++  
      +++++++           +++++++          +++++++   
     +++++++           ++++++           +++++++    
     ++++++          +++++++           ++++++      
     ++++++++         ++++++++       +++++++       
       ++++++++   ++++++++++++++    ++++++*        
         +++++++++++++++  +++++++++++++++          
           +++++++++++       +++++++++++           
              +++++++          +++++++             
                                   ++              
"""

icon_small = """
        +++     +++      
      +++++++  ++++++    
     ++++ ++++++++++++++ 
    ++++    ++++     +++ 
  ++++     ++++    ++++  
  +++++  +++++++  ++++   
    ++++++++++++++++     
       +++     ++++   
"""

goodgute = """
 ________  ________  ________  ________         
|\   ____\|\   __  \|\   __  \|\   ___ \        
\ \  \___|\ \  \|\  \ \  \|\  \ \  \_|\ \       
 \ \  \  __\ \  \\\  \ \  \\\  \ \  \ \\ \  \      
  \ \  \|\  \ \  \\\  \ \  \\\  \ \  \_\\ \  \     
   \ \_______\ \_______\ \_______\ \_______\    
    \|_______|\|_______|\|_______|\|_______|    
                                                
                                                
                                                
 ________  ___  ___  _________  _______         
|\   ____\|\  \|\  \|\___   ___\\  ___ \        
\ \  \___|\ \  \\\  \|___ \  \_\ \   __/|       
 \ \  \  __\ \  \\\  \   \ \  \ \ \  \_|/__     
  \ \  \|\  \ \  \\\  \   \ \  \ \ \  \_|\ \    
   \ \_______\ \______\   \ \__\ \ \_______\   
    \|_______|\|______|    \|__|  \|_______|   
"""


def handle_goodgute_cli_logo():

    icon_lines = [line for line in icon_small.splitlines() if line.strip()]
    good_lines = [line for line in goodgute.splitlines() if line.strip()]

    top_padding = (len(good_lines) - len(icon_lines)) // 2
    icon_lines = [""] * top_padding + icon_lines
    icon_lines += [""] * (len(good_lines) - len(icon_lines))


    icon_width = max(len(line) for line in icon_lines) 
    good_width = max(len(line) for line in good_lines) 

    for i in range(len(good_lines)):
        line = f"{icon_lines[i].ljust(icon_width)}{good_lines[i].ljust(good_width)}"
        print( Fore.MAGENTA + line)

    print("\n     GoodGute(V1.0.1) - AI-powered EN→DE translator\n")

if __name__ == "__main__":
  handle_goodgute_cli_logo()