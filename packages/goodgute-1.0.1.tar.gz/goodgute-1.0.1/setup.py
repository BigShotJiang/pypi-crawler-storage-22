from setuptools import setup, find_packages


setup(
    name="goodgute",  
    author="Paddy",
    version="1.0.1",
    packages=find_packages(),
        install_requires=[
       # "fastapi==0.115.0",
       # "uvicorn==0.30.0",
        "pydantic==2.8.2",
        "nltk==3.9.1",
        "requests",
        "colorama",
        "python-docx",
        "PyMuPDF",
    ],
    entry_points={
        "console_scripts": [
            "GoodGute=goodgute.cli:main",
        ],
    },
)
