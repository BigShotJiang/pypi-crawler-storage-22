# GoodMem Python SDK II

A Python SDK designed to be easy to use and easy to maintain. OpenAI-style API with auto-inference of model parameters, streaming retrieval, async support, and auto-pagination.

To see how this SDK compares to the previous `goodmem-client` SDK, see [Then vs Now](docs/then_vs_now.md).

## Installation

```bash
pip install goodmem
```

## Usage

```python
from goodmem import GoodMemClient

client = GoodMemClient(
    base_url="http://localhost:8080",
    token="your-api-token"
)

embedder = client.embedders.create(
    display_name="OpenAI Embedder",
    model_identifier="text-embedding-3-large",
    api_key="sk-your-openai-key",
)

print(f"Created: {embedder.embedder_id}")
```

## How It Works

The SDK has two layers:

- **Generated layer** (`goodmem/_generated/models/`) — Pydantic v2 models auto-generated from the server's OpenAPI spec via `openapi-generator`. These define request/response schemas.
- **Convenience layer** (`goodmem/api/`, `goodmem/client.py`, etc.) — Hand-written wrapper that adds model registry auto-inference, parameter forwarding, streaming, pagination, and a clean client interface. Users never directly import from `_generated/`.

The convenience layer transforms the raw generated SDK into something pleasant to use: `client.embedders.create(model_identifier="...", api_key="...")` instead of manually constructing nested request objects.

## Documentation

* [Build a basic RAG agent](docs/getting_started.md)
* [API reference](docs/manual.md)
* [Old vs new SDK](docs/then_vs_now.md)
* [Design and maintenance guide](docs/design_and_maintenance.md) — for developers understanding the architecture and re-generation workflows


## TODO

1. Add CI/CD pipeline to publish to PyPI. Integrate into ../build_all.sh and build_client.sh.
2. Add `gemini-embedding-001` to embedder registry once backend adds `OPENAI_COMPATIBLE` to `ProviderType`.
3. Add Anthropic, Google, Cohere, and Mistral LLMs to registry once backend adds matching `LLMProviderType` values.
