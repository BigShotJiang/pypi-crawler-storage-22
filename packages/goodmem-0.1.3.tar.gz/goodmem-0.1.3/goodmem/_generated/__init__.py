# Auto-generated code from openapi-generator. DO NOT EDIT.
# Re-generate with: library=httpx, --package-name goodmem._generated
