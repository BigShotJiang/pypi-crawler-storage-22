"""Model registries for auto-inferring provider_type, dimensionality, etc.

Data sourced from knowledge/embedders.md, knowledge/llms.md, knowledge/rerankers.md
via generate_registries.py -> goodmem/registries/*.json.

Dimensions are capped at 1536 (largest supported value <= 1536).
"""

import json
from pathlib import Path

_REG_DIR = Path(__file__).parent / "registries"


def _load_registry(name: str) -> dict[str, dict]:
    with open(_REG_DIR / f"{name}.json") as f:
        return json.load(f)


EMBEDDER_MODEL_REGISTRY: dict[str, dict] = _load_registry("embedders")
LLM_MODEL_REGISTRY: dict[str, dict] = _load_registry("llms")
RERANKER_MODEL_REGISTRY: dict[str, dict] = _load_registry("rerankers")
