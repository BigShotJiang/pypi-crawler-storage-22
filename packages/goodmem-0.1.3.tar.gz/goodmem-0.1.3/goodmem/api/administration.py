"""Administration API namespace."""

from __future__ import annotations

from typing import Any

import httpx

from goodmem._generated.models.admin_drain_response import AdminDrainResponse
from goodmem._generated.models.admin_purge_jobs_response import AdminPurgeJobsResponse
from goodmem._generated.models.admin_reload_license_response import AdminReloadLicenseResponse
from goodmem.errors import raise_for_status


class AdministrationAPI:
    """Administration API — drain, purge, license operations."""

    def __init__(self, http: httpx.Client, headers: dict[str, str]) -> None:
        self._http = http
        self._headers = headers

    def drain(self, **kwargs: Any) -> AdminDrainResponse:
        """Drain the server for graceful shutdown."""
        resp = self._http.post(
            "/v1/admin:drain",
            json=kwargs if kwargs else None,
            headers=self._headers,
        )
        raise_for_status(resp)
        return AdminDrainResponse.model_validate(resp.json())

    def purge_jobs(self, **kwargs: Any) -> AdminPurgeJobsResponse:
        """Purge background jobs."""
        resp = self._http.post(
            "/v1/admin/background-jobs:purge",
            json=kwargs if kwargs else None,
            headers=self._headers,
        )
        raise_for_status(resp)
        return AdminPurgeJobsResponse.model_validate(resp.json())

    def reload_license(self) -> AdminReloadLicenseResponse:
        """Reload the server license."""
        resp = self._http.post(
            "/v1/admin/license:reload",
            headers=self._headers,
        )
        raise_for_status(resp)
        return AdminReloadLicenseResponse.model_validate(resp.json())


class AsyncAdministrationAPI:
    def __init__(self, http: httpx.AsyncClient, headers: dict[str, str]) -> None:
        self._http = http
        self._headers = headers

    async def drain(self, **kwargs: Any) -> AdminDrainResponse:
        resp = await self._http.post(
            "/v1/admin:drain",
            json=kwargs if kwargs else None,
            headers=self._headers,
        )
        raise_for_status(resp)
        return AdminDrainResponse.model_validate(resp.json())

    async def purge_jobs(self, **kwargs: Any) -> AdminPurgeJobsResponse:
        resp = await self._http.post(
            "/v1/admin/background-jobs:purge",
            json=kwargs if kwargs else None,
            headers=self._headers,
        )
        raise_for_status(resp)
        return AdminPurgeJobsResponse.model_validate(resp.json())

    async def reload_license(self) -> AdminReloadLicenseResponse:
        resp = await self._http.post(
            "/v1/admin/license:reload",
            headers=self._headers,
        )
        raise_for_status(resp)
        return AdminReloadLicenseResponse.model_validate(resp.json())
