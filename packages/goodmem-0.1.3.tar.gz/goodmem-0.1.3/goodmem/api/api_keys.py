"""API Keys namespace."""

from __future__ import annotations

from goodmem._base import AsyncCRUDNamespace, CRUDNamespace
from goodmem._generated.models.api_key_response import ApiKeyResponse
from goodmem._generated.models.create_api_key_request import CreateApiKeyRequest
from goodmem._generated.models.list_api_keys_response import ListApiKeysResponse
from goodmem._generated.models.update_api_key_request import UpdateApiKeyRequest


class ApiKeysAPI(CRUDNamespace):
    _base_path = "/v1/apikeys"
    _create_model = CreateApiKeyRequest
    _update_model = UpdateApiKeyRequest
    _response_model = ApiKeyResponse
    _list_response_model = ListApiKeysResponse
    _list_items_field = "keys"


class AsyncApiKeysAPI(AsyncCRUDNamespace):
    _base_path = "/v1/apikeys"
    _create_model = CreateApiKeyRequest
    _update_model = UpdateApiKeyRequest
    _response_model = ApiKeyResponse
    _list_response_model = ListApiKeysResponse
    _list_items_field = "keys"
