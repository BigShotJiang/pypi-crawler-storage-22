"""OCR API namespace."""

from __future__ import annotations

from typing import Any

import httpx

from goodmem._generated.models.ocr_document_request import OcrDocumentRequest
from goodmem._generated.models.ocr_document_response import OcrDocumentResponse
from goodmem.errors import raise_for_status


class OcrAPI:
    """OCR API — one-off operations."""

    def __init__(self, http: httpx.Client, headers: dict[str, str]) -> None:
        self._http = http
        self._headers = headers

    def document(self, **kwargs: Any) -> OcrDocumentResponse:
        """Process a document with OCR."""
        body = OcrDocumentRequest.model_validate(kwargs)
        resp = self._http.post(
            "/v1/ocr:document",
            json=body.model_dump(by_alias=True, exclude_unset=True),
            headers=self._headers,
        )
        raise_for_status(resp)
        return OcrDocumentResponse.model_validate(resp.json())


class AsyncOcrAPI:
    def __init__(self, http: httpx.AsyncClient, headers: dict[str, str]) -> None:
        self._http = http
        self._headers = headers

    async def document(self, **kwargs: Any) -> OcrDocumentResponse:
        body = OcrDocumentRequest.model_validate(kwargs)
        resp = await self._http.post(
            "/v1/ocr:document",
            json=body.model_dump(by_alias=True, exclude_unset=True),
            headers=self._headers,
        )
        raise_for_status(resp)
        return OcrDocumentResponse.model_validate(resp.json())
