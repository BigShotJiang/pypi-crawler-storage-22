"""Rerankers API namespace."""

from __future__ import annotations

from typing import Any

from goodmem._base import AsyncCRUDNamespace, CRUDNamespace
from goodmem._generated.models.list_rerankers_response import ListRerankersResponse
from goodmem._generated.models.reranker_creation_request import RerankerCreationRequest
from goodmem._generated.models.reranker_response import RerankerResponse
from goodmem._generated.models.update_reranker_request import UpdateRerankerRequest
from goodmem._registries import RERANKER_MODEL_REGISTRY
from goodmem._schema_bridge import build_api_key_credentials

_PROVIDER_ENDPOINT_MAP = {
    "COHERE": "https://api.cohere.com",
    "JINA": "https://api.jina.ai",
    "VOYAGE": "https://api.voyageai.com/v1",
}


def _apply_reranker_defaults(kwargs: dict[str, Any]) -> dict[str, Any]:
    """Apply model registry defaults and api_key convenience."""
    model_id = kwargs.get("model_identifier")
    if model_id and model_id in RERANKER_MODEL_REGISTRY:
        defaults = RERANKER_MODEL_REGISTRY[model_id]
        for key, value in defaults.items():
            kwargs.setdefault(key, value)
        pt = kwargs.get("provider_type")
        if pt and "endpoint_url" not in kwargs and pt in _PROVIDER_ENDPOINT_MAP:
            kwargs["endpoint_url"] = _PROVIDER_ENDPOINT_MAP[pt]

    api_key = kwargs.pop("api_key", None)
    if api_key:
        kwargs.setdefault("credentials", build_api_key_credentials(api_key))

    return kwargs


class RerankersAPI(CRUDNamespace):
    _base_path = "/v1/rerankers"
    _create_model = RerankerCreationRequest
    _update_model = UpdateRerankerRequest
    _response_model = RerankerResponse
    _list_response_model = ListRerankersResponse
    _list_items_field = "rerankers"

    def create(self, **kwargs: Any) -> RerankerResponse:
        """Create a reranker. Model registry auto-infers provider_type, etc."""
        kwargs = _apply_reranker_defaults(kwargs)
        return super().create(**kwargs)


class AsyncRerankersAPI(AsyncCRUDNamespace):
    _base_path = "/v1/rerankers"
    _create_model = RerankerCreationRequest
    _update_model = UpdateRerankerRequest
    _response_model = RerankerResponse
    _list_response_model = ListRerankersResponse
    _list_items_field = "rerankers"

    async def create(self, **kwargs: Any) -> RerankerResponse:
        kwargs = _apply_reranker_defaults(kwargs)
        return await super().create(**kwargs)
