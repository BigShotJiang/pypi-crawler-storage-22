"""System API namespace."""

from __future__ import annotations

from typing import Any

import httpx

from goodmem._generated.models.system_info_response import SystemInfoResponse
from goodmem._generated.models.system_init_response import SystemInitResponse
from goodmem.errors import raise_for_status


class SystemAPI:
    """System API — info and initialization."""

    def __init__(self, http: httpx.Client, headers: dict[str, str]) -> None:
        self._http = http
        self._headers = headers

    def info(self) -> SystemInfoResponse:
        """Get system information."""
        resp = self._http.get("/v1/system/info", headers=self._headers)
        raise_for_status(resp)
        return SystemInfoResponse.model_validate(resp.json())

    def initialize(self, **kwargs: Any) -> SystemInitResponse:
        """Initialize the system."""
        resp = self._http.post(
            "/v1/system/init",
            json=kwargs if kwargs else None,
            headers=self._headers,
        )
        raise_for_status(resp)
        return SystemInitResponse.model_validate(resp.json())


class AsyncSystemAPI:
    def __init__(self, http: httpx.AsyncClient, headers: dict[str, str]) -> None:
        self._http = http
        self._headers = headers

    async def info(self) -> SystemInfoResponse:
        resp = await self._http.get("/v1/system/info", headers=self._headers)
        raise_for_status(resp)
        return SystemInfoResponse.model_validate(resp.json())

    async def initialize(self, **kwargs: Any) -> SystemInitResponse:
        resp = await self._http.post(
            "/v1/system/init",
            json=kwargs if kwargs else None,
            headers=self._headers,
        )
        raise_for_status(resp)
        return SystemInitResponse.model_validate(resp.json())
