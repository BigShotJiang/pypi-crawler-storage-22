"""Users API namespace (read-only, no CRUD base class)."""

from __future__ import annotations

from typing import Any

import httpx

from goodmem._generated.models.user_response import UserResponse
from goodmem.errors import raise_for_status


class UsersAPI:
    """Users API — read-only operations."""

    def __init__(self, http: httpx.Client, headers: dict[str, str]) -> None:
        self._http = http
        self._headers = headers

    def get_current(self) -> UserResponse:
        """Get the currently authenticated user."""
        resp = self._http.get("/v1/users/me", headers=self._headers)
        raise_for_status(resp)
        return UserResponse.model_validate(resp.json())

    def get(self, id: str) -> UserResponse:
        """Get a user by ID."""
        resp = self._http.get(f"/v1/users/{id}", headers=self._headers)
        raise_for_status(resp)
        return UserResponse.model_validate(resp.json())

    def get_by_email(self, email: str) -> UserResponse:
        """Get a user by email address."""
        resp = self._http.get(f"/v1/users/email/{email}", headers=self._headers)
        raise_for_status(resp)
        return UserResponse.model_validate(resp.json())


class AsyncUsersAPI:
    """Async Users API — read-only operations."""

    def __init__(self, http: httpx.AsyncClient, headers: dict[str, str]) -> None:
        self._http = http
        self._headers = headers

    async def get_current(self) -> UserResponse:
        resp = await self._http.get("/v1/users/me", headers=self._headers)
        raise_for_status(resp)
        return UserResponse.model_validate(resp.json())

    async def get(self, id: str) -> UserResponse:
        resp = await self._http.get(f"/v1/users/{id}", headers=self._headers)
        raise_for_status(resp)
        return UserResponse.model_validate(resp.json())

    async def get_by_email(self, email: str) -> UserResponse:
        resp = await self._http.get(f"/v1/users/email/{email}", headers=self._headers)
        raise_for_status(resp)
        return UserResponse.model_validate(resp.json())
