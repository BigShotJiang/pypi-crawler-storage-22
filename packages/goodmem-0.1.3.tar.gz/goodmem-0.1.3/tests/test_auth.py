"""Tests for _auth_headers function."""

from goodmem.client import _auth_headers


def test_gm_prefix_uses_x_api_key():
    headers = _auth_headers("gm_abc123")
    assert headers == {"x-api-key": "gm_abc123"}


def test_sk_prefix_uses_bearer():
    headers = _auth_headers("sk-proj-abc123")
    assert headers == {"Authorization": "Bearer sk-proj-abc123"}


def test_arbitrary_token_uses_bearer():
    headers = _auth_headers("some-random-token")
    assert headers == {"Authorization": "Bearer some-random-token"}


def test_empty_string_uses_bearer():
    headers = _auth_headers("")
    assert headers == {"Authorization": "Bearer "}


def test_gm_underscore_boundary():
    """Token must start with 'gm_' to use x-api-key."""
    headers = _auth_headers("gm")
    assert headers == {"Authorization": "Bearer gm"}

    headers = _auth_headers("gm_")
    assert headers == {"x-api-key": "gm_"}
