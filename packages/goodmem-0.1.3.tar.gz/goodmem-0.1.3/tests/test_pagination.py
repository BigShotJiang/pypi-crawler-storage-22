"""Tests for auto-pagination."""

import httpx

from goodmem.pagination import Paginator


class FakeItem:
    def __init__(self, name: str):
        self.name = name


class FakePage:
    def __init__(self, items: list | None, next_token: str | None = None):
        self.items = items
        self.next_token = next_token

    @classmethod
    def model_validate(cls, data: dict) -> "FakePage":
        raw_items = data.get("items")
        items = [FakeItem(i) for i in raw_items] if raw_items else raw_items
        return cls(items=items, next_token=data.get("nextToken"))


def _make_fetch_fn(pages: list[dict]):
    """Create a fetch function that returns pages in sequence."""
    call_count = [0]

    def fetch(token: str | None) -> httpx.Response:
        idx = call_count[0]
        call_count[0] += 1
        return httpx.Response(200, json=pages[idx])

    return fetch


def test_single_page_iteration():
    pages = [{"items": ["a", "b", "c"]}]
    paginator = Paginator(
        fetch_fn=_make_fetch_fn(pages),
        response_model=FakePage,
        items_field="items",
    )

    items = [item.name for item in paginator]
    assert items == ["a", "b", "c"]


def test_multi_page_iteration():
    pages = [
        {"items": ["a", "b"], "nextToken": "page2"},
        {"items": ["c", "d"], "nextToken": "page3"},
        {"items": ["e"]},
    ]
    paginator = Paginator(
        fetch_fn=_make_fetch_fn(pages),
        response_model=FakePage,
        items_field="items",
    )

    items = [item.name for item in paginator]
    assert items == ["a", "b", "c", "d", "e"]


def test_empty_page():
    pages = [{"items": []}]
    paginator = Paginator(
        fetch_fn=_make_fetch_fn(pages),
        response_model=FakePage,
        items_field="items",
    )

    items = list(paginator)
    assert items == []


def test_stops_at_no_next_token():
    """Paginator should stop when nextToken is absent."""
    call_count = [0]

    def fetch(token: str | None) -> httpx.Response:
        call_count[0] += 1
        if call_count[0] == 1:
            return httpx.Response(200, json={"items": ["a"], "nextToken": "t2"})
        return httpx.Response(200, json={"items": ["b"]})

    paginator = Paginator(
        fetch_fn=fetch,
        response_model=FakePage,
        items_field="items",
    )

    items = [item.name for item in paginator]
    assert items == ["a", "b"]
    assert call_count[0] == 2


def test_first_page():
    pages = [{"items": ["a", "b"], "nextToken": "page2"}]
    paginator = Paginator(
        fetch_fn=_make_fetch_fn(pages),
        response_model=FakePage,
        items_field="items",
    )

    page = paginator.first_page()
    assert len(page.items) == 2
    assert page.next_token == "page2"


def test_none_items_treated_as_empty():
    """If the items field is None, treat it as empty list."""
    pages = [{"items": None}]
    paginator = Paginator(
        fetch_fn=_make_fetch_fn(pages),
        response_model=FakePage,
        items_field="items",
    )

    items = list(paginator)
    assert items == []
