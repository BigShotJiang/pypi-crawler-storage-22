
# Getting Started with Google Maps Platform

## Introduction

API Specification for Google Maps Platform

## Install the Package

The package is compatible with Python versions `3.7+`.
Install the package from PyPi using the following pip command:

```bash
pip install google-maps-api-sdk==1.0.0
```

You can also view the package at:
https://pypi.python.org/pypi/google-maps-api-sdk/1.0.0

## Initialize the API Client

**_Note:_** Documentation for the client can be found [here.](https://www.github.com/apimatic/google-maps-api-python-sdk/tree/1.0.0/doc/client.md)

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| environment | [`Environment`](https://www.github.com/apimatic/google-maps-api-python-sdk/tree/1.0.0/README.md#environments) | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| http_client_instance | `Union[Session, HttpClientProvider]` | The Http Client passed from the sdk user for making requests |
| override_http_client_configuration | `bool` | The value which determines to override properties of the passed Http Client from the sdk user |
| http_call_back | `HttpCallBack` | The callback value that is invoked before and after an HTTP call is made to an endpoint |
| timeout | `float` | The value to use for connection timeout. <br> **Default: 30** |
| max_retries | `int` | The number of times to retry an endpoint call if it fails. <br> **Default: 0** |
| backoff_factor | `float` | A backoff factor to apply between attempts after the second try. <br> **Default: 2** |
| retry_statuses | `Array of int` | The http statuses on which retry is to be done. <br> **Default: [408, 413, 429, 500, 502, 503, 504, 521, 522, 524]** |
| retry_methods | `Array of string` | The http methods on which retry is to be done. <br> **Default: ["GET", "PUT"]** |
| proxy_settings | [`ProxySettings`](https://www.github.com/apimatic/google-maps-api-python-sdk/tree/1.0.0/doc/proxy-settings.md) | Optional proxy configuration to route HTTP requests through a proxy server. |
| logging_configuration | [`LoggingConfiguration`](https://www.github.com/apimatic/google-maps-api-python-sdk/tree/1.0.0/doc/logging-configuration.md) | The SDK logging configuration for API calls |
| custom_query_authentication_credentials | [`CustomQueryAuthenticationCredentials`](https://www.github.com/apimatic/google-maps-api-python-sdk/tree/1.0.0/doc/auth/custom-query-parameter.md) | The credential object for Custom Query Parameter |

The API client can be initialized as follows:

### Code-Based Client Initialization

```python
import logging

from googlemapsplatform.configuration import Environment
from googlemapsplatform.googlemapsplatform_client import GooglemapsplatformClient
from googlemapsplatform.http.auth.custom_query_authentication import CustomQueryAuthenticationCredentials
from googlemapsplatform.logging.configuration.api_logging_configuration import LoggingConfiguration
from googlemapsplatform.logging.configuration.api_logging_configuration import RequestLoggingConfiguration
from googlemapsplatform.logging.configuration.api_logging_configuration import ResponseLoggingConfiguration

client = GooglemapsplatformClient(
    custom_query_authentication_credentials=CustomQueryAuthenticationCredentials(
        key='key'
    ),
    environment=Environment.PRODUCTION,
    logging_configuration=LoggingConfiguration(
        log_level=logging.INFO,
        request_logging_config=RequestLoggingConfiguration(
            log_body=True
        ),
        response_logging_config=ResponseLoggingConfiguration(
            log_headers=True
        )
    )
)
```

### Environment-Based Client Initialization

```python
from googlemapsplatform.googlemapsplatform_client import GooglemapsplatformClient

# Specify the path to your .env file if it’s located outside the project’s root directory.
client = GooglemapsplatformClient.from_environment(dotenv_path='/path/to/.env')
```

See the [Environment-Based Client Initialization](https://www.github.com/apimatic/google-maps-api-python-sdk/tree/1.0.0/doc/environment-based-client-initialization.md) section for details.

## Environments

The SDK can be configured to use a different environment for making API calls. Available environments are:

### Fields

| Name | Description |
|  --- | --- |
| PRODUCTION | **Default** |
| ENVIRONMENT2 | - |
| ENVIRONMENT3 | - |

## Authorization

This API uses the following authentication schemes.

* [`ApiKeyAuth (Custom Query Parameter)`](https://www.github.com/apimatic/google-maps-api-python-sdk/tree/1.0.0/doc/auth/custom-query-parameter.md)

## List of APIs

* [Geolocation API](https://www.github.com/apimatic/google-maps-api-python-sdk/tree/1.0.0/doc/controllers/geolocation-api.md)
* [Directions API](https://www.github.com/apimatic/google-maps-api-python-sdk/tree/1.0.0/doc/controllers/directions-api.md)
* [Elevation API](https://www.github.com/apimatic/google-maps-api-python-sdk/tree/1.0.0/doc/controllers/elevation-api.md)
* [Geocoding API](https://www.github.com/apimatic/google-maps-api-python-sdk/tree/1.0.0/doc/controllers/geocoding-api.md)
* [Time Zone API](https://www.github.com/apimatic/google-maps-api-python-sdk/tree/1.0.0/doc/controllers/time-zone-api.md)
* [Roads API](https://www.github.com/apimatic/google-maps-api-python-sdk/tree/1.0.0/doc/controllers/roads-api.md)
* [Distance Matrix API](https://www.github.com/apimatic/google-maps-api-python-sdk/tree/1.0.0/doc/controllers/distance-matrix-api.md)
* [Places API](https://www.github.com/apimatic/google-maps-api-python-sdk/tree/1.0.0/doc/controllers/places-api.md)
* [Street View API](https://www.github.com/apimatic/google-maps-api-python-sdk/tree/1.0.0/doc/controllers/street-view-api.md)

## SDK Infrastructure

### Configuration

* [ProxySettings](https://www.github.com/apimatic/google-maps-api-python-sdk/tree/1.0.0/doc/proxy-settings.md)
* [Environment-Based Client Initialization](https://www.github.com/apimatic/google-maps-api-python-sdk/tree/1.0.0/doc/environment-based-client-initialization.md)
* [AbstractLogger](https://www.github.com/apimatic/google-maps-api-python-sdk/tree/1.0.0/doc/abstract-logger.md)
* [LoggingConfiguration](https://www.github.com/apimatic/google-maps-api-python-sdk/tree/1.0.0/doc/logging-configuration.md)
* [RequestLoggingConfiguration](https://www.github.com/apimatic/google-maps-api-python-sdk/tree/1.0.0/doc/request-logging-configuration.md)
* [ResponseLoggingConfiguration](https://www.github.com/apimatic/google-maps-api-python-sdk/tree/1.0.0/doc/response-logging-configuration.md)

### HTTP

* [HttpResponse](https://www.github.com/apimatic/google-maps-api-python-sdk/tree/1.0.0/doc/http-response.md)
* [HttpRequest](https://www.github.com/apimatic/google-maps-api-python-sdk/tree/1.0.0/doc/http-request.md)

### Utilities

* [ApiResponse](https://www.github.com/apimatic/google-maps-api-python-sdk/tree/1.0.0/doc/api-response.md)
* [ApiHelper](https://www.github.com/apimatic/google-maps-api-python-sdk/tree/1.0.0/doc/api-helper.md)
* [HttpDateTime](https://www.github.com/apimatic/google-maps-api-python-sdk/tree/1.0.0/doc/http-date-time.md)
* [RFC3339DateTime](https://www.github.com/apimatic/google-maps-api-python-sdk/tree/1.0.0/doc/rfc3339-date-time.md)
* [UnixDateTime](https://www.github.com/apimatic/google-maps-api-python-sdk/tree/1.0.0/doc/unix-date-time.md)

