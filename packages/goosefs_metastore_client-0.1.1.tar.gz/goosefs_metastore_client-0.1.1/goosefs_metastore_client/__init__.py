"""GooseFS Metastore Client."""
from goosefs_metastore_client.goosefs_metastore_client import GoosefsMetastoreClient

__all__ = ["GoosefsMetastoreClient"]
