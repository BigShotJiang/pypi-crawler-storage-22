# US Government Websites: Business & Professional License Data

> Research compiled: 2026-02-16
> Focus: Real estate license lookups + Business entity searches for all 50 states

---

## Table of Contents
1. [Big 3 States — Deep Dive (CA, TX, FL)](#big-3-states--deep-dive)
2. [All 50 States — Real Estate License Lookups](#all-50-states--real-estate-license-lookups)
3. [All 50 States — Business Entity Search (Secretary of State)](#all-50-states--business-entity-search)
4. [Multi-State / Aggregator APIs](#multi-state--aggregator-apis)
5. [States with Known Public APIs or Bulk Data](#states-with-known-public-apis-or-bulk-data)

---

## Big 3 States — Deep Dive

### 🟡 CALIFORNIA

#### Real Estate License Lookup (DRE)

| Field | Details |
|-------|---------|
| **Agency** | California Department of Real Estate (DRE) |
| **Search URL** | `https://pplinfo2.dre.ca.gov/` |
| **Legacy URL** | `https://www2.dre.ca.gov/PublicASP/pplinfo.asp` |
| **Direct link (by license #)** | `https://pplinfo2.dre.ca.gov/PPLInfo/PplInfoStart?LicenseID={LICENSE_NUMBER}` |
| **Multi-department lookup** | `https://www.dre.ca.gov/MultipleDepartment.html` |
| **Method** | GET with query parameters (new system). Legacy was ASP form POST. |
| **Search Fields** | Name (Last, First), Company Name, License ID Number |
| **Data Returned** | License number, licensee name, license type (Salesperson/Broker/Corp), license status (Licensed/Expired/Revoked/etc.), expiration date, mailing address (city only), sponsoring broker |
| **API** | No public REST API for DRE specifically. The pplinfo2 system is a Java web app. Can be queried via GET parameter `LicenseID`. |
| **Notes** | Partial name searches supported. The new pplinfo2 system replaced the old ASP system. |

#### Business Entity Search (Secretary of State)

| Field | Details |
|-------|---------|
| **Agency** | California Secretary of State |
| **Search URL** | `https://bizfileonline.sos.ca.gov/search/business` |
| **Method** | JavaScript SPA (Angular/React) — makes internal API calls |
| **API Portal** | **`https://calicodev.sos.ca.gov/`** ⭐ Official API Developer Portal |
| **API Guide PDF** | `https://calicodev.sos.ca.gov/content/California%20SOS%20BE%20Public%20Search%20API%20Guide%20v1.0.4.pdf` |
| **Search Fields** | Business name, entity number (new "B" prefix format since 2024), entity type |
| **Data Returned** | Entity name, entity number, formation date, entity type (Corp/LLC/LP), current status (Active/Suspended/Dissolved/Forfeited/Surrendered), registered agent (name + address), principal address, filing history |
| **NOT Available** | Shareholder info (private under CA law), detailed officer data (limited) |
| **API Auth** | Account creation + subscription key required |
| **API Format** | JSON responses |
| **Cost** | Check portal — may have usage tiers |
| **Notes** | 17+ million entity records. California is one of the few states with an official REST API. Entity numbers transitioned to "B" prefix in 2024. |

---

### 🟡 TEXAS

#### Real Estate License Lookup (TREC)

| Field | Details |
|-------|---------|
| **Agency** | Texas Real Estate Commission (TREC) |
| **Search URL** | `https://www.trec.texas.gov/apps/license-holder-search/index.php` |
| **Redirects to** | `https://www.trec.texas.gov/license-search/` |
| **Method** | **GET with query parameters** |
| **URL Pattern** | `?lic_name={NAME}&lic_hp={LICENSE_NUMBER}&industry={INDUSTRY_TYPE}` |
| **Example** | `https://www.trec.texas.gov/apps/license-holder-search/index.php?lic_name=smith,j&lic_hp=&industry=Real+Estate` |
| **Search Fields** | `lic_name` (Last, First — partial allowed), `lic_hp` (license number), `industry` (Real Estate, Inspector, Easement) |
| **Data Returned** | License holder name, license number, license type, status, expiration date, sponsoring broker, city/state |
| **API** | No public REST API. GET parameters make it scrapeable. |
| **Notes** | Partial name matching supported ("smith, j" matches "smith, john" and "goldsmith, james"). Now redirected to an Accela-based system at `https://aca-prod.accela.com/TREC/`. |

#### Business Entity Search (Secretary of State / Comptroller)

| Field | Details |
|-------|---------|
| **Agency** | Texas Secretary of State (SOSDirect) + Texas Comptroller |
| **SOSDirect URL** | `https://www.sos.state.tx.us/corp/sosda/index.shtml` (requires account, $1/search) |
| **Free Search URL** | `https://mycpa.cpa.state.tx.us/coa/` (Comptroller Franchise Tax Account Status) |
| **Sales Taxpayer Search** | `https://mycpa.cpa.state.tx.us/staxpayersearch/` |
| **Method (Comptroller)** | Form POST via `search.do` endpoint |
| **Search Fields** | Taxpayer name, Taxpayer number, SOS file number |
| **Data Returned (Comptroller)** | Taxpayer name, taxpayer number, SOS file number, right to transact business status, state of formation |
| **Data Returned (SOSDirect)** | Full entity details, registered agent, officers/directors, filing history, assumed names |
| **API** | No public API. SOSDirect requires account + fee. |
| **Notes** | Texas is unique: free public search is through the Comptroller (tax status), not the SOS directly. SOSDirect ($1/search) gives full corporate records. |

---

### 🟡 FLORIDA

#### Real Estate License Lookup (DBPR)

| Field | Details |
|-------|---------|
| **Agency** | Florida Department of Business and Professional Regulation (DBPR) |
| **Search URL (by name)** | `https://www.myfloridalicense.com/wl11.asp?mode=2&SID=&brd=&search=Name&typ=` |
| **Search URL (by license #)** | `https://www.myfloridalicense.com/wl11.asp?mode=1&SID=&brd=&typ=` |
| **New Portal** | `https://www2.myfloridalicense.com/how-to-verify-a-license/` |
| **Method** | ASP form with GET parameters: `mode` (0=default, 1=by license#, 2=by name), `brd` (board code), `search` (Name/LicenseNumber), `typ` (license type) |
| **Search Fields** | First Name, Last Name, City, License Number, Board (e.g., "25" for Real Estate) |
| **Data Returned** | Licensee name, license number, license type, license status (Current/Delinquent/Null & Void), expiration date, primary/secondary/alternate addresses, county |
| **API** | No official public API. The legacy ASP system is form-based. |
| **Notes** | Florida also has a mobile app. "Null & Void" is a Florida-specific terminal status. |

#### Business Entity Search (Division of Corporations / Sunbiz)

| Field | Details |
|-------|---------|
| **Agency** | Florida Department of State, Division of Corporations |
| **Search URL** | `https://search.sunbiz.org/Inquiry/CorporationSearch/ByName` |
| **All Search Types** | See below |
| **Method** | GET requests — URL-based routing with MVC pattern |
| **Data Returned** | Entity name, document number, FEI/EIN number, date filed, status (Active/Inactive/Dissolved), principal address, mailing address, registered agent, officer/director details, annual report history |
| **API** | No REST API, but **FREE BULK DATA DOWNLOADS** available ⭐ |
| **Bulk Data Host** | `https://sftp.floridados.gov` (Username: `Public`, Password: `PubAccess1845!`) |
| **Bulk Data** | Daily files (new filings each business day) + Quarterly files (all active records — Jan/Apr/Jul/Oct) |

**Sunbiz Search Endpoints:**

| Search Type | URL |
|------------|-----|
| By Entity Name | `https://search.sunbiz.org/Inquiry/CorporationSearch/ByName` |
| By Officer/Registered Agent | `https://search.sunbiz.org/Inquiry/CorporationSearch/ByOfficerOrRegisteredAgent` |
| By Registered Agent | `https://search.sunbiz.org/Inquiry/CorporationSearch/ByRegisteredAgent` |
| By FEI/EIN Number | `https://search.sunbiz.org/Inquiry/CorporationSearch/ByFeiNumber` |
| By Document Number | `https://search.sunbiz.org/Inquiry/CorporationSearch/ByDocumentNumber` |
| By Zip Code | `https://search.sunbiz.org/Inquiry/CorporationSearch/ByZip` |
| By Street Address | `https://search.sunbiz.org/Inquiry/CorporationSearch/ByAddress` |
| By Trademark | `https://search.sunbiz.org/Inquiry/CorporationSearch/ByTrademark` |
| By Trademark Owner | `https://search.sunbiz.org/Inquiry/CorporationSearch/ByTrademarkOwner` |

---

## All 50 States — Real Estate License Lookups

### Legend
- 🔗 = Direct search URL
- 📋 = Method (GET/POST/JS)
- 📊 = Key data returned

| State | Agency | License Search URL | Method |
|-------|--------|-------------------|--------|
| **Alabama** | AREC | `https://arec.alabama.gov/apps/LicenseSearch` | Web form |
| **Alaska** | CBPL | `https://www.commerce.alaska.gov/web/cbpl/ProfessionalLicensing/ProfessionalLicenseSearch.aspx` | Web form |
| **Arizona** | ADRE | `https://services.azre.gov/publicdatabase/SearchIndividuals.aspx` | ASP.NET form POST |
| **Arkansas** | AREC | `https://www.arec.arkansas.gov/licensee-search/` | Web form |
| **California** | DRE | `https://pplinfo2.dre.ca.gov/` | GET params |
| **Colorado** | DORA/DRE | `https://apps2.colorado.gov/dre/licensing/lookup/licenselookup.aspx` | ASP.NET form |
| **Connecticut** | DCP | `https://www.elicense.ct.gov/Lookup/LicenseLookup.aspx` | ASP.NET form |
| **Delaware** | DPRM | `https://delpros.delaware.gov/OH_Verification` | Web form |
| **Florida** | DBPR | `https://www.myfloridalicense.com/wl11.asp?mode=2&SID=&brd=&search=Name&typ=` | GET params/ASP |
| **Georgia** | GREC | `https://grec.state.ga.us/licensee-search/` | Web form |
| **Hawaii** | DCCA/PVL | `https://pvl.ehawaii.gov/pvlsearch/` | Web form |
| **Idaho** | IREC | `https://irec.idaho.gov/licensing/license-lookup/` | Web form |
| **Illinois** | IDFPR | `https://ilesonline.idfpr.illinois.gov/DPR/Verification/Search.aspx` | ASP.NET form |
| **Indiana** | PLA | `https://mylicense.in.gov/EVerification/Search.aspx` | ASP.NET form |
| **Iowa** | IREC | `https://iowaonline.state.ia.us/irecpub/licensee_search` | Web form |
| **Kansas** | KREC | `https://accesskansas.krec.ks.gov/publicaccess/licenseeSearch.html` | Web form |
| **Kentucky** | KREC | `https://mykyverification.ky.gov/verification/Search.aspx` | ASP.NET form |
| **Louisiana** | LREC | `https://portal.lrec.state.la.us/Lookup/Search` | Web form |
| **Maine** | MREC | `https://www.pfr.maine.gov/almsonline/almsquery/SearchIndividual.aspx` | ASP.NET form |
| **Maryland** | MREC/DLLR | `https://www.dllr.state.md.us/cgi-bin/ElicenseSearch/OP_Search/OP_search.cgi?calling_app=REC::REC_qselect` | CGI/GET |
| **Massachusetts** | BRE | `https://elicensing.mass.gov/CitizenAccess/` | Web form |
| **Michigan** | LARA | `https://aca-prod.accela.com/MILARA/` | Accela platform |
| **Minnesota** | MDC | `https://www.cards.commerce.state.mn.us/CARDS/security/search.do?searchType=statusLookup` | Java form |
| **Mississippi** | MREC | `https://www.mrec.ms.gov/licensee-search/` | Web form |
| **Missouri** | MREC | `https://pr.mo.gov/licensee-search-REC.asp` | Web form |
| **Montana** | BRR | `https://ebiz.mt.gov/POL/Default.aspx` | ASP.NET form |
| **Nebraska** | NREC | `https://nrec.igovsolution.net/online/Verification/Individual` | Web form |
| **Nevada** | NRED | `https://red.prod.secure.nv.gov/Lookup/LicenseLookup.aspx` | ASP.NET form |
| **New Hampshire** | NHREC | `https://forms.nh.gov/licenseverification/` | Web form |
| **New Jersey** | NJREC | `https://newjersey.mylicense.com/verification/Search.aspx` | ASP.NET form |
| **New Mexico** | NMREC | `https://www.rld.nm.gov/boards-and-commissions/real-estate-commission/real-estate-licensee-look-up/` | Web form |
| **New York** | DOS | `https://appext20.dos.ny.gov/nydos/selSearchType.do` | Java form POST |
| **North Carolina** | NCREC | `https://my.ncrec.gov/Search/Licensee` | Web form |
| **North Dakota** | NDREC | `https://www.ndrealestateboard.com/licensee-search/` | Web form |
| **Ohio** | ODRE | `https://elicense3.com.ohio.gov/lookup/licenselookup.aspx` | ASP.NET form |
| **Oklahoma** | OREC | `https://www.ok.gov/orec/License_Search/index.html` | Web form |
| **Oregon** | OREA | `https://orea.elicense.irondata.com/` | Web form |
| **Pennsylvania** | SREC | `https://www.pals.pa.gov/#/page/search` | JavaScript SPA |
| **Rhode Island** | RIDRE | `https://elicense.ri.gov/Lookup/LicenseLookup.aspx` | ASP.NET form |
| **South Carolina** | SCLLR | `https://verify.llr.sc.gov/` | Web form |
| **South Dakota** | SDREC | `https://dlr.sd.gov/bdcomm/realestate/licensee_search.aspx` | ASP.NET form |
| **Tennessee** | TREC | `https://verify.tn.gov/` | Web form |
| **Texas** | TREC | `https://www.trec.texas.gov/apps/license-holder-search/index.php?lic_name=&lic_hp=&industry=Real+Estate` | GET params |
| **Utah** | DRE | `https://secure.utah.gov/llv/search/index.html` | Web form |
| **Vermont** | VREC | `https://sos.vermont.gov/opr/real-estate/license-lookup/` | Web form |
| **Virginia** | DPOR | `https://dhp.virginiainteractive.org/Lookup/Index` | Web form |
| **Washington** | DOL | `https://fortress.wa.gov/dol/dolprod/bpdLicenseQuery.asp` | ASP form |
| **West Virginia** | WVREC | `https://www.wvrec.org/licensing/verify-a-license/` | Web form |
| **Wisconsin** | DSPS | `https://licensesearch.wi.gov/` | Web form |
| **Wyoming** | WREC | `https://realestate.wyo.gov/consumer-information/licensee-search/` | Web form |

---

## All 50 States — Business Entity Search

All URLs below go directly to the public business entity search page.

| State | Search URL | Notes |
|-------|-----------|-------|
| **Alabama** | `https://www.sos.alabama.gov/government-records/business-entity-records` | |
| **Alaska** | `https://www.commerce.alaska.gov/cbp/main/search/entities` | |
| **Arizona** | `https://arizonabusinesscenter.azcc.gov/businesssearch` | Corporation Commission |
| **Arkansas** | `https://www.ark.org/corp-search/index.php` | |
| **California** | `https://bizfileonline.sos.ca.gov/search/business` | ⭐ Has API: `calicodev.sos.ca.gov` |
| **Colorado** | `https://www.sos.state.co.us/biz/BusinessEntityCriteriaExt.do?resetTransTyp=Y` | |
| **Connecticut** | `https://service.ct.gov/business/s/onlinebusinesssearch` | |
| **Delaware** | `https://icis.corp.delaware.gov/Ecorp/EntitySearch/NameSearch.aspx` | |
| **DC** | `https://corponline.dcra.dc.gov/Home.aspx` | Login required |
| **Florida** | `https://search.sunbiz.org/Inquiry/CorporationSearch/ByName` | ⭐ Free bulk data downloads |
| **Georgia** | `https://ecorp.sos.ga.gov/BusinessSearch` | |
| **Hawaii** | `https://hbe.ehawaii.gov/documents/search.html` | |
| **Idaho** | `https://sosbiz.idaho.gov/search/business` | |
| **Illinois** | `https://apps.ilsos.gov/corporatellc/` | |
| **Indiana** | `https://bsd.sos.in.gov/publicbusinesssearch` | |
| **Iowa** | `https://sos.iowa.gov/search/business/search.aspx` | Has JSON API (subscription) |
| **Kansas** | `https://www.sos.ks.gov/eforms/BusinessEntity/Search.aspx` | |
| **Kentucky** | `https://sosbes.sos.ky.gov/BusSearchNProfile/search.aspx` | |
| **Louisiana** | `https://coraweb.sos.la.gov/CommercialSearch/CommercialSearch.aspx` | CAPTCHA protected |
| **Maine** | `https://apps3.web.maine.gov/nei-sos-icrs/ICRS?MainPage=x` | |
| **Maryland** | `https://egov.maryland.gov/BusinessExpress/EntitySearch` | |
| **Massachusetts** | `https://corp.sec.state.ma.us/corpweb/CorpSearch/CorpSearch.aspx` | |
| **Michigan** | `https://mibusinessregistry.lara.state.mi.us/search/business` | |
| **Minnesota** | `https://mblsportal.sos.state.mn.us/Business/Search` | |
| **Mississippi** | `https://corp.sos.ms.gov/corp/portal/c/page/corpBusinessIdSearch/portal.aspx?#clear=1` | |
| **Missouri** | `https://bsd.sos.mo.gov/BusinessEntity/BESearch.aspx?SearchType=0` | |
| **Montana** | `https://biz.sosmt.gov/search/business` | |
| **Nebraska** | `https://www.nebraska.gov/sos/corp/corpsearch.cgi?nav=search` | |
| **Nevada** | `https://esos.nv.gov/EntitySearch/OnlineEntitySearch` | |
| **New Hampshire** | `https://quickstart.sos.nh.gov/online/BusinessInquire` | Works best in Firefox/Edge |
| **New Jersey** | `https://www.njportal.com/DOR/BusinessNameSearch/Search/BusinessName` | |
| **New Mexico** | `https://enterprise.sos.nm.gov/search/business` | |
| **New York** | `https://apps.dos.ny.gov/publicInquiry/` | |
| **North Carolina** | `https://www.sosnc.gov/online_services/search/by_title/_Business_Registration` | |
| **North Dakota** | `https://firststop.sos.nd.gov/search/business` | |
| **Ohio** | `https://businesssearch.ohiosos.gov/` | |
| **Oklahoma** | `https://www.sos.ok.gov/corp/corpinquiryfind.aspx` | |
| **Oregon** | `http://egov.sos.state.or.us/br/pkg_web_name_srch_inq.login` | |
| **Pennsylvania** | `https://file.dos.pa.gov/search/business` | |
| **Rhode Island** | `http://business.sos.ri.gov/CorpWeb/CorpSearch/CorpSearch.aspx` | |
| **South Carolina** | `https://businessfilings.sc.gov/BusinessFiling/Entity/Search` | |
| **South Dakota** | `https://sosenterprise.sd.gov/BusinessServices/Business/FilingSearch.aspx` | |
| **Tennessee** | `https://tncab.tnsos.gov/business-entity-search` | |
| **Texas** | `https://mycpa.cpa.state.tx.us/coa/` (free, Comptroller) / SOSDirect ($1/search) | |
| **Utah** | `https://businessregistration.utah.gov/EntitySearch/OnlineEntitySearch` | |
| **Vermont** | `https://bizfilings.vermont.gov/business/businesssearch` | |
| **Virginia** | `https://cis.scc.virginia.gov/EntitySearch/Index` | State Corporation Commission |
| **Washington** | `https://ccfs.sos.wa.gov/#/AdvancedSearch` | |
| **West Virginia** | `https://apps.wv.gov/SOS/BusinessEntitySearch/` | |
| **Wisconsin** | `https://apps.dfi.wi.gov/apps/corpsearch/search.aspx` | Dept. of Financial Institutions |
| **Wyoming** | `https://wyobiz.wyo.gov/Business/FilingSearch.aspx` | |

---

## Multi-State / Aggregator APIs

### ARELLO — Real Estate License Verification Web Service
| Field | Details |
|-------|---------|
| **URL** | `https://www.arello.com/` |
| **API Docs** | `https://www.arello.com/docs/ARELLO-LVWSv2-Documentation.pdf` |
| **API Info** | `https://www.arello.com/information.cfm` |
| **Records** | 2,975,000+ real estate license records |
| **Method** | HTTP POST request |
| **Parameters** | Jurisdiction, license number, last name, first name |
| **Response** | Licensee verification data |
| **Coverage** | Most US states/jurisdictions (not all participate) |
| **Limitations** | NAR records only available via manual search (not API). No bulk downloads. Subscription required. |
| **Notes** | Best centralized source for multi-state real estate license verification. Data received directly from participating jurisdictions, mostly updated daily. |

### National Corporation Directory
| Field | Details |
|-------|---------|
| **URL** | `https://www.secstates.com/` |
| **Cost** | $25/day unlimited searches |
| **Coverage** | All 50 state SOS databases |
| **Notes** | Paid aggregator, not government-run |

---

## States with Known Public APIs or Bulk Data

### ⭐ States with Official APIs

| State | System | Details |
|-------|--------|---------|
| **California** | Business Entity API | `https://calicodev.sos.ca.gov/` — Full REST API with subscription keys. JSON responses. Search by name, entity number. Returns entity details, status, registered agent, filing history. |
| **Iowa** | Business Entity API | Subscription-based JSON API for business entity data. |

### ⭐ States with Free Bulk Data Downloads

| State | System | Details |
|-------|--------|---------|
| **Florida** | Sunbiz Corporate Data | SFTP: `sftp.floridados.gov` (User: `Public` / Pass: `PubAccess1845!`). Daily + quarterly files. All active corporate records. |

### States with URL-Based Searchable Patterns (Scrapeable)

These states use GET parameters or predictable URL patterns, making them more accessible for automated lookups:

| State | System | URL Pattern |
|-------|--------|-------------|
| **Texas (TREC)** | Real Estate License | `?lic_name={name}&lic_hp={license}&industry=Real+Estate` |
| **California (DRE)** | Real Estate License | `PPLInfo/PplInfoStart?LicenseID={license_number}` |
| **Florida (DBPR)** | Professional License | `wl11.asp?mode={0-2}&SID=&brd={board_code}&search={type}&typ=` |
| **Florida (Sunbiz)** | Business Entity | MVC URL routing: `/Inquiry/CorporationSearch/By{SearchType}` |
| **New York (DOS)** | Real Estate License | `/nydos/searchByName.do` and `/nydos/searchByLicNumber.do` (Java servlets) |

---

## Technical Notes

### Common Platforms Used by States
- **Accela** — Used by TX TREC (newer system), MI LARA, others. Often harder to scrape.
- **ASP.NET WebForms** — Very common (NV, OH, NJ, CT, IL, IN, KY, etc.). Uses ViewState, making POST scraping more complex.
- **iGov Solutions** — Used by NE (Nebraska) for real estate. Common pattern.
- **elicense/eLicensing platforms** — Used by OH, CT, RI for multi-profession licensing.
- **IronData** — Used by OR (Oregon) for real estate licensing.

### Scraping Considerations
1. **ASP.NET ViewState** — Many state sites use ASP.NET which requires maintaining ViewState tokens between requests
2. **CAPTCHA** — Louisiana (SOS), and increasingly others are adding CAPTCHA
3. **Session management** — Many sites (FL DBPR, TX SOSDirect) use server-side sessions with SID parameters
4. **JavaScript SPAs** — PA (PALS), CA (bizfileonline), WA use JavaScript-heavy frontends
5. **Rate limiting** — Most state sites don't explicitly rate-limit but may block aggressive scraping
6. **Terms of service** — Most state sites prohibit automated scraping in their ToS

### Data Freshness
- **Real estate licenses**: Generally updated within 24-48 hours of status changes
- **Business entities**: Varies widely. CA LLCs only file biennially; corporations file annually
- **Sunbiz bulk data**: Daily files available next business day; quarterly files each Jan/Apr/Jul/Oct
- **ARELLO**: Most jurisdictions update daily

---

## Summary & Recommendations

### For Real Estate License Data
1. **Best centralized option**: ARELLO API (paid, ~3M records, multi-state)
2. **Best free options for big 3**:
   - CA: DRE pplinfo2 (GET-based, scrapeable by license #)
   - TX: TREC search (GET parameters, very scrapeable)
   - FL: DBPR myfloridalicense (ASP form, session-based)
3. **Most states**: ASP.NET WebForms requiring POST with ViewState

### For Business Entity Data
1. **Best option**: California has an official REST API (`calicodev.sos.ca.gov`)
2. **Best free bulk data**: Florida Sunbiz (free SFTP downloads of all records)
3. **Most comprehensive search**: Florida Sunbiz (9 different search types including by officer, address, zip)
4. **Texas**: Free via Comptroller for basic status; SOSDirect ($1/search) for full records
5. **Most states**: Web-based searches only, no APIs
