# Bot Detection & Evasion Research — Gov Websites Collector
## Date: 2026-02-16

---

## Protection Systems Found Across All 51 States

### 1. Cloudflare (JS Challenge) — 6 states
**States:** GA (ecorp), NC (SOS), MI (LARA), HI (PVL), FL (Sunbiz — light CF), CO (SOS — 404 behind CF)

**How it works:**
- Cloudflare sits as a reverse proxy between user and origin server
- Issues a JS challenge that runs in-browser, collecting 100+ fingerprint signals
- Generates `cf_clearance` cookie after solving — valid for ~30 min
- Checks TLS fingerprint (JA3/JA4), IP reputation, browser fingerprint

**Detection signals:**
- `cf-ray` header in response
- `__cf_chl_f_tk` token in HTML
- `challenge-platform` scripts
- 403 status with "attention required" page

**Evasion strategy (best → worst):**
1. **Camoufox + ISP proxy** (best, ~95% success) — custom Firefox build that patches ALL fingerprint leaks at C++ level, not JS injection. Wraps Playwright API natively.
2. **Playwright + stealth plugin + ISP proxy** (~70% success) — `playwright-stealth` patches webdriver, plugins, languages. ISP/residential IP crucial because CF auto-blocks datacenter ranges.
3. **curl_cffi** (~40% success for CF JS challenges) — only fixes TLS fingerprint, doesn't execute JS challenges. Only works on light CF (like FL Sunbiz).

**Key insight:** Cloudflare's JS challenge is NOT a CAPTCHA — it's an invisible browser integrity check. With a real-looking browser + clean IP, it auto-solves. No captcha service needed.

---

### 2. Imperva/Incapsula — 2 states
**States:** NV (eSOS), MA (SOS)

**How it works:**
- Similar to Cloudflare but with additional `reese84` cookie challenge
- Collects 180+ encrypted browser fingerprint values via JS
- Checks TLS fingerprint, IP reputation, behavioral patterns
- Sets `visid_incap_*` and `incap_ses_*` cookies

**Detection signals:**
- "Powered by Incapsula" or incident ID in response
- `X-Iinfo` response header
- `visid_incap` / `incap_ses` cookies
- `_Incapsula_Resource` in page source

**Evasion strategy:**
1. **Camoufox + ISP proxy** (best) — handles the reese84 challenge by running real JS in a stealthy browser
2. **curl_cffi with Chrome impersonation + ISP proxy** (~60% for basic Imperva) — fixes TLS but can't solve reese84
3. **nodriver (undetected-chromedriver successor)** — Chrome-based, very stealthy, but Python-only and Chromium

**Key insight:** Imperva is harder than Cloudflare because of the reese84 cookie. HTTP-only approaches almost never work. Need a real browser.

---

### 3. reCAPTCHA — 3 states
**States:** LA (SOS — reCAPTCHA v3 invisible), CO (DORA — on form), HI (PVL — v2 + CF)

**Types found:**

#### reCAPTCHA v3 (invisible) — LA SOS
- No visible checkbox or puzzle
- Runs silently in background, assigns a risk score (0.0 to 1.0)
- Score based on: mouse movement, scrolling patterns, interaction timing, browser fingerprint
- If score > 0.5, typically passes without user interaction

**Evasion for v3:**
1. **freecaptcha** (FREE, Python, no browser needed) — open-source library that generates valid v3 tokens by replaying the reCAPTCHA anchor flow. `pip install freecaptcha`
2. **Camoufox/Playwright with human-like behavior** — real browser with mouse movement/scrolling usually scores 0.7+ automatically
3. **2captcha/anticaptcha API** (~$3/1000 solves) — sends sitekey + URL, returns token. Works but costs money.

#### reCAPTCHA v2 (checkbox/image) — CO DORA, HI PVL
- Visible checkbox ("I'm not a robot") or image selection puzzle
- Requires either human solving or a solving service

**Evasion for v2:**
1. **2captcha API** ($2.99/1000) — most reliable, 15-30 second solve time
2. **Audio challenge + speech-to-text** — PyPasser library automates this, free but fragile
3. **Camoufox with pre-warmed profile** — sometimes auto-passes v2 checkbox without images if browser profile has good history

---

### 4. Generic 403 / IP Blocking — 4 states
**States:** MN (CARDS), NH (SOS), ME (SOS), DC (DCRA)

**How it works:**
- Simple IP-based blocking of known datacenter/hosting ranges
- No sophisticated JS challenges or CAPTCHAs
- Just checks if your IP looks like a server (DigitalOcean, AWS, Hetzner, etc.)

**Evasion strategy:**
1. **ISP proxy — that's it.** These are the EASIEST to bypass. Just route through an ISP/residential IP and use normal headers. No stealth browser needed.
2. **curl_cffi or plain httpx** with residential proxy will work fine
3. No need for Playwright, Camoufox, or captcha services

---

### 5. ASP.NET ViewState — 6+ states
**States:** OK (SOS), WY, SD, OH, RI, NJ, NV

**How it works:**
- Not really "protection" — it's ASP.NET's server-side state management
- Page sends hidden `__VIEWSTATE` and `__EVENTVALIDATION` tokens
- Must extract these from the initial page load and include them in POST requests
- Some also require `__VIEWSTATEGENERATOR`

**Evasion strategy:**
- **No evasion needed** — just proper implementation:
  1. GET the form page, parse out ViewState tokens
  2. Include tokens in subsequent POST requests
  3. Maintain session cookies between requests
- Works with plain HTTP, no browser needed
- The existing code already handles this for some states

---

### 6. Dead/Moved URLs — 5 states
**States with new URLs found:**

| State | Old URL | New URL | Status |
|-------|---------|---------|--------|
| KY SOS | `web.sos.ky.gov/corpscansrch/` | `www.sos.ky.gov/bus/business-filings/OnlineServices/` | Needs browser |
| KY KREC | `krec.ky.gov/licensee-lookup/` | `krec.ky.gov/` → eServices portal (changed Feb 3, 2026) | Needs research |
| CO SOS | `sos.state.co.us/biz/BusinessEntitySearchCriteria.do` | `sos.state.co.us/biz/BusinessEntityCriteriaExt.do` | Behind CF |
| CO DORA | `apps.colorado.gov/dora/licensing/Lookup/LicenseLookup.aspx` | Same URL, 405 error, CloudFront + reCAPTCHA | Needs v2 solving |
| MD DLLR | `dllr.state.md.us/cgi-bin/ElicenseSearch/` | `labor.maryland.gov/pq/` (moved to Dept of Labor) | May work with HTTP |
| SC LLR | `verify.llr.sc.gov` | DNS dead — `llr.sc.gov/re/` exists | Needs research |
| DC DCRA | `eservices.dcra.dc.gov` | 403 — may need ISP proxy | Try with proxy |
| DC Corp | `corponline.dcra.dc.gov` | Connection timeout | Likely dead |

---

## Recommended Stack

### Browser Engine: **Camoufox** (PRIMARY)
- Free, open-source, Python, wraps Playwright API
- Custom Firefox build with C++ level fingerprint injection (not JS patches)
- Proven against: Cloudflare, Imperva, DataDome, reCAPTCHA, Fingerprint.com
- Memory: ~200MB per instance (debloated Firefox)
- Install: `pip install camoufox[geoip]` + `python -m camoufox fetch`

### Proxy: **ISP proxies** (Youssef will provide)
- ISP proxies = static residential IPs from actual ISPs
- Not datacenter, not rotating residential — these are the cleanest IPs
- One proxy per state or rotate across a pool
- Critical for: ALL Cloudflare, Imperva, and 403-blocked states

### reCAPTCHA v3: **freecaptcha** (free) or Camoufox auto-pass
- `pip install freecaptcha` — generates tokens without browser
- Only needed for LA SOS
- Camoufox with mouse simulation typically scores 0.7+ on v3 automatically

### reCAPTCHA v2: **2captcha** ($2.99/1000 solves)
- Only needed for CO DORA and HI PVL
- Or: try Camoufox first — sometimes auto-passes checkbox
- $3 covers thousands of searches

### ViewState: **Plain HTTP (httpx)**
- No special tools needed
- Parse tokens from initial GET, include in POST
- Works for OK, WY, SD, OH, RI, NJ

---

## Implementation Plan

### Tier 1: Quick wins (no proxy needed) — fix code bugs
- AK, AR: Fix `async for` coroutine bug
- OK: Already returns 200, fix URL/parsing
- ME PFR: Returns 200 on probe, investigate why code says 403
- FL DBPR: Returns 200, no CF — may work with plain HTTP
- NV RED: Returns 200, no protection detected

### Tier 2: ISP proxy only (no browser) — simple HTTP + proxy
- MN, NH, ME SOS, DC: Just 403 due to datacenter IP, ISP proxy fixes it
- MD: New URL at labor.maryland.gov, probably works with proxy
- ViewState states with working URLs: Try httpx + proxy

### Tier 3: Camoufox + ISP proxy (browser automation)
- GA, NC, MI, HI, FL Sunbiz, CT: Cloudflare JS challenge
- NV eSOS, MA SOS: Imperva
- IA, IL, KS, MO, OR, PA, SC, UT, VA, WI: Various JS/SPA requiring browser

### Tier 4: Camoufox + ISP proxy + CAPTCHA solving
- LA SOS: reCAPTCHA v3 (freecaptcha or auto-pass)
- CO DORA: reCAPTCHA v2 (2captcha or auto-pass attempt)
- HI PVL: reCAPTCHA v2 + Cloudflare (2captcha + Camoufox)

---

## Cost Estimate

| Item | Cost | Notes |
|------|------|-------|
| Camoufox | Free | Open source |
| freecaptcha | Free | reCAPTCHA v3 bypass |
| ISP proxies | TBD | Youssef providing |
| 2captcha (optional) | ~$3/1000 | Only for v2 CAPTCHAs on 2-3 states |
| **Total** | **ISP proxy cost + ~$3** | |
