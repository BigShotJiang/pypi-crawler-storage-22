# State Collector Status

Last updated: 2026-02-17

## Working States (27)

### HTTP-based (no browser needed)
| State | Category | Method | Notes |
|-------|----------|--------|-------|
| AL | Licenses | HTTP POST | AREC license search |
| AZ | Licenses | HTTP POST | ADRE license search |
| CA | Licenses | HTTP GET | DRE public records |
| CO | Licenses+Biz | HTTP POST | DORA lookup + SOS search |
| DE | Licenses | HTTP POST | DelPros verification |
| ID | Biz | JSON API | sosbiz.idaho.gov API |
| IN | Licenses+Biz | HTTP POST | MyLicense + SOS search |
| KY | Biz | HTTP POST (ASP.NET) | SOS business search - **FIXED** |
| MN | Biz | JSON API | SOS portal API |
| MS | Licenses | HTTP POST | MREC licensee search |
| ND | Biz | JSON API | FirstStop API |
| NJ | Licenses | HTTP POST | MyLicense verification |
| NY | Biz | HTTP POST | DOS search |
| SC | Biz | HTTP POST | Business filings search |
| TX | Licenses+Biz | HTTP GET/POST | TREC + Comptroller data search |
| GA | Licenses | HTTP POST (CSRF) | GREC search - **FIXED** |
| LA | Licenses | HTTP AJAX | LREC portal /Public/_Search/ - **FIXED** |
| ME | Licenses | HTTP POST (ASP.NET) | Real Estate Commission ViewState form - **FIXED** |

### Camoufox-based (browser automation required)
| State | Category | Method | Notes |
|-------|----------|--------|-------|
| AK | Licenses | Camoufox | Commerce license search |
| CT | Licenses+Biz | Camoufox | eLicense + Concord SOTS |
| FL | Licenses+Biz | Camoufox | SunBiz + DBPR |
| IA | Biz | Camoufox | SOS business search |
| MT | Biz | Camoufox | SOS MT business search |
| TN | Licenses+Biz | Camoufox | Verify TN + SOS |
| VA | Licenses+Biz | Camoufox | DPOR + SCC search |
| NH | Biz | Camoufox | QuickStart SOS (403 via HTTP) - **FIXED** |

### Camoufox + Proxy
| State | Category | Method | Notes |
|-------|----------|--------|-------|
| OR | Biz | Camoufox+proxy | Oregon SOS business search |

### Intermittent
| State | Category | Notes |
|-------|----------|-------|
| MO | Licenses+Biz | Works sometimes, Missouri SOS can be flaky |

## Broken States (23)

### CAPTCHA/Anti-bot Protected (cannot bypass without CAPTCHA solving)
| State | Issue | Details |
|-------|-------|---------|
| AR | reCAPTCHA v2 + Livewire | ark.org uses Laravel Livewire + reCAPTCHA |
| HI (lic) | reCAPTCHA | mypvl.dcca.hawaii.gov Cloudflare + reCAPTCHA |
| KS | WAF (202 empty body) | SOS returns 202 with 0 bytes |
| MD | reCAPTCHA (invisible) | egov.maryland.gov BusinessExpress has invisible reCAPTCHA |
| NE | reCAPTCHA | nebraska.gov/sos/corp has reCAPTCHA v2 |
| OK | Cloudflare Turnstile | sos.ok.gov uses Turnstile on search form |
| SD | reCAPTCHA | sosenterprise.sd.gov returns "reCAPTCHA failed" |
| WV | reCAPTCHA v3 | apps.wv.gov/SOS requires reCAPTCHA v3 token |
| WY | Visual CAPTCHA | wyobiz.wyo.gov has image-based CAPTCHA |
| WA | Cloudflare Turnstile | ccfs-api.prod.sos.wa.gov requires Turnstile token |

### Cloudflare/Incapsula Blocked (needs Camoufox+proxy, may not work)
| State | Issue | Details |
|-------|-------|---------|
| GA (biz) | Cloudflare | ecorp.sos.ga.gov blocked even with proxy |
| NC (biz) | Cloudflare | sosnc.gov aggressive Cloudflare |
| NV | Incapsula | esos.nv.gov and nvsilverflume.gov both Incapsula |
| VT | Incapsula | All Vermont government sites blocked by Incapsula |

### Site Down / DNS / Authentication Required
| State | Issue | Details |
|-------|-------|---------|
| DC | Angular SPA + timeout | corponline.dlcp.dc.gov needs browser; often times out |
| IL | NS_ERROR_NET_INTERRUPT | apps.ilsos.gov intermittent; works with Camoufox+proxy |
| MA | Infinite redirects | corp.sec.state.ma.us redirect loop |
| MI | SSL errors / blocked | LARA blocked even with proxy; SSL issues |
| NC (lic) | O4W Framework | NCREC uses O4W CGI with JS-based AJAX that doesn't render in browser |
| PA | SSL errors | corporations.pa.gov SSL_ERROR_BAD_CERT_DOMAIN |
| RI | DNS down / UpdatePanel | elicense.ri.gov DNS not resolving; SOS uses ScriptManager async |

### JS-Rendered (need browser but complex)
| State | Issue | Details |
|-------|-------|---------|
| HI (biz) | JS search | hbe.ehawaii.gov search returns no results via HTTP |
| NM | React SPA + OAuth | enterprise.sos.nm.gov requires Microsoft OAuth |
| OH | SPA + 403 API | businesssearch.ohiosos.gov API returns 403 |
| UT | JS error | secure.utah.gov/llv POST returns error page |
| WI | Timeout | dsps.wi.gov and wsos.state.wi.us both timeout |

## Dead URLs (need replacement)
| State | Old URL | Notes |
|-------|---------|-------|
| IA (lic) | elicense.iowa.gov | Need to find new IA license search URL |
| KS (lic) | aceonline.kansas.gov | Need to find new KS Accela license URL |
| NC (lic) | portal.ncrec.gov | Current O4W framework URL works but parsing is complex |
| NV (lic) | nred.nv.gov | red.prod.secure.nv.gov returns 405 |
| OR (lic) | orea.oregon.gov | Need to find new OR license lookup |
| WI (lic) | online.drl.wi.gov | WI DSPS lookup URL times out |
| AZ (biz) | ecorp.azcc.gov | Need to find new AZ business search |

## Summary

- **Working**: 27 states (4 newly fixed: KY, GA, LA, NH, ME)
- **Broken**: 23 states
- **Key blockers**: reCAPTCHA (8 states), Cloudflare/Incapsula (4), Site down (7), JS/SPA (5)
