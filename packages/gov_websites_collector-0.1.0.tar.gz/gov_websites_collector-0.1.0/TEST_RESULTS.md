# Test Results — Gov Websites Collector

**Date:** Feb 16, 2026  
**Query:** `Smith`  
**Test Mode:** HTTP-only (no browser)  
**Proxy:** SOCKS5 (US Phoenix)

## Summary

| Metric | Count |
|--------|-------|
| **Working (HTTP)** | 15 |
| **Need Camoufox Browser** | 18 |
| **Blocked/Down/CAPTCHA** | 9 |
| **Known Down (skip)** | 9 |
| **Total** | 51 |

## Working States (HTTP Only) — 15

| State | Businesses | Licenses | Method | Notes |
|-------|-----------|----------|--------|-------|
| AL | 10 | 0 | HTTP POST | AL SOS CGI form |
| AZ | 0 | 10 | HTTP POST | **NEW** — ADRE license search via anti-forgery token POST |
| CA | 0 | 10 | HTTP API | CA DRE API |
| CO | 7 | 0 | HTTP API | CO SOS API |
| DE | 5 | 0 | HTTP API | DE SOS API |
| ID | 0 | 10 | HTTP | ID REC license search |
| IN | 0 | 1 | HTTP | IN PLA license search |
| MN | 10 | 0 | HTTP API | MN SOS API |
| MO | 10 | 0 | ASP.NET | MO SOS ViewState form |
| MS | 0 | 1 | HTTP | MS REC license search |
| ND | 10 | 0 | JSON API | ND FirstStop API |
| NJ | 0 | 10 | ASP.NET | **NEW** — Fixed ViewState POST, corrected field names & table parser |
| NY | 0 | 4 | HTTP POST | NY DOS license form |
| SC | 10 | 0 | HTTP POST | **NEW** — SC SOS business search via anti-forgery token |
| TX | 10 | 0 | JSON API | TX Comptroller API |

## Need Camoufox Browser — 18

These states have the correct browser automation code but need `use_camoufox=True`:

| State | Category | Why Browser Needed | Notes |
|-------|----------|--------------------|-------|
| AK | biz+lic | ASP.NET DNN portal | CBPL search requires full page render |
| AZ | biz | Angular SPA | ACC blocks HTTP requests (403) |
| CT | biz+lic | CONCORD + eLicense | eLicense returns 500 via HTTP |
| FL | biz+lic | Cloudflare | Sunbiz + DBPR — confirmed working with Camoufox |
| GA | biz+lic | JavaScript | GREC + ecorp — confirmed working with Camoufox |
| HI | lic | Cloudflare | PVL site has Cloudflare protection |
| IA | biz+lic | Salesforce / 403 | PLB is Salesforce; SOS returns 403 |
| IL | biz+lic | Timeout / SPA | IDFPR eLicense, SOS JS SPA |
| KS | biz+lic | Accela + CAPTCHA | KREC uses Accela platform; SOS has CAPTCHA |
| MT | biz+lic | SPA + CAPTCHA | SOS is SPA; eBiz has CAPTCHA |
| NC | biz+lic | O4W CGI + Cloudflare | NCREC O4W CGI needs browser; SOSNC Cloudflare |
| NV | lic | CAPTCHA | NRED has CAPTCHA; SOS entity search blocked |
| OK | biz | Cloudflare Turnstile | SOS has Turnstile CAPTCHA on form submit |
| OR | biz+lic | JS + CAPTCHA | SOS has CAPTCHA; REA is ASP.NET |
| PA | biz+lic | Angular SPA | PALS is Angular; DOS protected |
| TN | biz+lic | Next.js SPA | Commerce Next.js; TNBEAR new endpoints |
| VA | biz+lic | Drupal + SCC portal | DPOR is Drupal CMS; SCC has custom search |
| WI | lic | JS search | DSPS uses JavaScript-based search |

## Blocked / Down / CAPTCHA — 9

| State | Status | Notes |
|-------|--------|-------|
| HI (biz) | SPA | HBE is SPA, API returns HTML not JSON |
| MA | Unreachable/403 | ols.state.ma.us unreachable; MA SOS returns 403 |
| MI | 403 | LARA and business registry both return 403 |
| NE | CAPTCHA | iGov Solutions requires verification code |
| NM | 404 / SPA | RLD license URL returns 404; SOS is SPA |
| OH | Maintenance/JSF | SOS in maintenance (403); eLicense is Salesforce VF |
| RI | Unreachable/500 | eLicense host unreachable; SOS returns 500 |
| SD (biz) | ASP.NET issue | ViewState POST returns empty response |
| WA | 404 / SPA | DOL license 404; CCFS API returns 404 |

## Known Down (Skip) — 9

| State | Notes |
|-------|-------|
| AR | reCAPTCHA; AREC 404 |
| DC | All sites 503/522/timeout |
| KY | eServices 404; SOS 404 |
| LA | CAPTCHA; LREC DNS error |
| MD | DLLR 404; BusinessExpress needs login |
| ME | ICRS 403; PFR 403 |
| NH | QuickStart 403; license 403 |
| WV | All sites 502 |
| WY | WREC 404; WyoBiz CAPTCHA |

## Changes Made (Round 3)

1. **AZ License** — Converted from browser to HTTP POST with anti-forgery token. Now returns ~1780 results for "Smith".
2. **NJ License** — Fixed field name from `t_web_lookup__license_number` to `t_web_lookup__license_no`. Fixed result table parser to handle `datagrid_results` table (10-cell rows with Name, LicNum, Profession, Type, Status, City, State).
3. **SC Business** — Converted from browser to HTTP POST with `__RequestVerificationToken`. SC SOS returns table with Entity Name, Date, Type, Status, State.
4. **SC License** — Updated to ASP.NET ViewState POST with correct field prefix `ctl00$ContentPlaceHolder1$UserInputGen$`.
5. **NC License** — Switched from HTTP to browser automation (O4W CGI framework doesn't accept standard HTTP POST).
6. **SD Business** — Fixed ViewState field name from `txtSearchName` to `txtSearchValue`; fixed URL type check bug (`str(response.url)` instead of `response.url`).
7. **OK Business** — Added browser-first approach with HTTP fallback (Cloudflare Turnstile blocks HTTP POST).

## Architecture Notes

- States marked "Need Camoufox Browser" already have browser automation code with selectors that match current HTML. Run with `use_camoufox=True` to activate.
- A SOCKS5 proxy works well for HTTP requests but many gov sites still block datacenter IPs. A residential proxy would improve success rates for blocked states.
- Several states (CT, NV, WI, KS, MI) use the same **eLicense/Accela** platform. Fixing one platform's selectors fixes all of them.
- States using Salesforce VisualForce (OH) or Salesforce Communities (IA) are the hardest to scrape via HTTP.
