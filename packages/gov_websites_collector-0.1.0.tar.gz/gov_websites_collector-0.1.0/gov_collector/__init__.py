"""
gov-websites-collector: Collect US business and professional license data
from government websites across all 50 states + DC.

Quick start:
    import asyncio
    from gov_collector import collect

    results = asyncio.run(collect("CA", "Smith"))
    for r in results:
        print(r.data.holder_name, r.data.license_number)
"""

from gov_collector.models import (
    Business,
    CollectorResult,
    License,
    Property,
    SearchParams,
    StateInfo,
)
from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.registry import StateRegistry, get_collector, list_states

__version__ = "0.1.0"


async def collect(
    state: str,
    query: str,
    *,
    category: str | None = None,
    proxy: str | None = None,
    timeout: float = 30.0,
    rate_limit: float = 1.0,
    use_browser: bool = False,
    use_camoufox: bool = False,
    max_results: int = 100,
) -> list[CollectorResult]:
    """
    High-level convenience function to collect data from a state.

    Args:
        state: Two-letter state code (e.g. "CA", "TX", "FL")
        query: Search term (name, business name, keyword)
        category: Data category ("licenses", "businesses", "properties").
                  If None, searches all supported categories.
        proxy: HTTP/SOCKS5 proxy URL (e.g. "http://user:pass@host:port").
               Required for some states with bot protection.
        timeout: Request timeout in seconds (default: 30)
        rate_limit: Minimum seconds between requests (default: 1.0)
        use_browser: Enable Playwright browser automation
        use_camoufox: Enable Camoufox browser (anti-detection)
        max_results: Maximum results to return (default: 100)

    Returns:
        List of CollectorResult objects containing the collected data.

    Example:
        import asyncio
        from gov_collector import collect

        # Search California licenses
        results = asyncio.run(collect("CA", "Smith"))

        # Search with proxy for states that need it
        results = asyncio.run(collect("OR", "Smith", proxy="http://user:pass@host:port"))

        # Use browser for JS-heavy sites
        results = asyncio.run(collect("FL", "Realty", use_camoufox=True))
    """
    params = SearchParams(
        query=query,
        state=state.upper(),
        max_results=max_results,
    )

    categories = None
    if category:
        categories = [DataCategory(category)]

    collector = get_collector(
        state,
        proxy=proxy,
        timeout=timeout,
        rate_limit=rate_limit,
        use_browser=use_browser,
        use_camoufox=use_camoufox,
    )

    results: list[CollectorResult] = []
    async with collector:
        async for result in collector.collect(params, categories=categories):
            results.append(result)

    return results


__all__ = [
    "BaseStateCollector",
    "Business",
    "CollectorResult",
    "DataCategory",
    "License",
    "Property",
    "SearchParams",
    "StateInfo",
    "StateRegistry",
    "collect",
    "get_collector",
    "list_states",
]
