"""
ASP.NET WebForms helper for ViewState management.

Many state government websites use ASP.NET WebForms which requires:
1. GET the page first to extract __VIEWSTATE and related hidden fields
2. POST back with ViewState + form data
3. Parse the result page
"""

from __future__ import annotations

import logging
import re
from typing import Any

from gov_collector.parsers import parse_html

logger = logging.getLogger(__name__)


def extract_viewstate(html: str) -> dict[str, str]:
    """Extract ASP.NET ViewState and related hidden fields from HTML."""
    tree = parse_html(html)
    fields: dict[str, str] = {}
    
    for name in [
        "__VIEWSTATE",
        "__VIEWSTATEGENERATOR", 
        "__EVENTVALIDATION",
        "__EVENTTARGET",
        "__EVENTARGUMENT",
        "__LASTFOCUS",
    ]:
        el = tree.css_first(f'input[name="{name}"]')
        if el:
            fields[name] = el.attributes.get("value", "")
    
    return fields


def extract_all_hidden_fields(html: str) -> dict[str, str]:
    """Extract all hidden input fields from HTML."""
    tree = parse_html(html)
    fields: dict[str, str] = {}
    
    for el in tree.css('input[type="hidden"]'):
        name = el.attributes.get("name", "")
        value = el.attributes.get("value", "")
        if name:
            fields[name] = value
    
    return fields


async def aspnet_search(
    client,
    url: str,
    form_fields: dict[str, str],
    *,
    submit_target: str | None = None,
    submit_value: str = "Search",
    extra_hidden_fields: dict[str, str] | None = None,
) -> str:
    """
    Perform a search on an ASP.NET WebForms page.
    
    Steps:
    1. GET the page to extract ViewState
    2. POST with ViewState + form fields + submit button
    3. Return the result HTML
    
    Args:
        client: HttpClient instance
        url: Page URL
        form_fields: Dict of form field names and values to fill
        submit_target: The __EVENTTARGET value for the submit button
        submit_value: The value of the submit button
        extra_hidden_fields: Additional hidden fields to include
    
    Returns:
        Result HTML string
    """
    # Step 1: GET page to extract ViewState
    try:
        page_resp = await client.get(url)
        page_html = page_resp.text
    except Exception as e:
        logger.error("ASP.NET GET failed for %s: %s", url, e)
        raise

    # Extract hidden fields
    hidden = extract_all_hidden_fields(page_html)
    viewstate = extract_viewstate(page_html)
    
    if not viewstate.get("__VIEWSTATE"):
        logger.warning("No __VIEWSTATE found in %s", url)
    
    # Build POST data
    post_data = {**hidden}
    post_data.update(form_fields)
    
    if extra_hidden_fields:
        post_data.update(extra_hidden_fields)
    
    # Set submit target if provided (for __doPostBack-style submissions)
    if submit_target:
        post_data["__EVENTTARGET"] = submit_target
        post_data["__EVENTARGUMENT"] = ""
    
    # Step 2: POST with ViewState + form data
    try:
        result_resp = await client.post(url, data=post_data)
        return result_resp.text
    except Exception as e:
        logger.error("ASP.NET POST failed for %s: %s", url, e)
        raise
