"""
Base collector class that all state modules must implement.
"""

from __future__ import annotations

import abc
import logging
from enum import Enum
from typing import AsyncIterator

from gov_collector.models import (
    CollectorResult,
    SearchParams,
    StateInfo,
)
from gov_collector.http import HttpClient

logger = logging.getLogger(__name__)

# Lazy-loaded browser clients
_BrowserClient = None
_CamoufoxBrowser = None


def _get_browser_class():
    global _BrowserClient
    if _BrowserClient is None:
        from gov_collector.browser import BrowserClient
        _BrowserClient = BrowserClient
    return _BrowserClient


def _get_camoufox_class():
    global _CamoufoxBrowser
    if _CamoufoxBrowser is None:
        from gov_collector.camoufox_browser import CamoufoxBrowser
        _CamoufoxBrowser = CamoufoxBrowser
    return _CamoufoxBrowser


class DataCategory(str, Enum):
    """Categories of data that can be collected."""

    BUSINESSES = "businesses"
    LICENSES = "licenses"
    PROPERTIES = "properties"


class BaseStateCollector(abc.ABC):
    """
    Abstract base class for state-specific collectors.

    Every state module must subclass this and implement at least one
    of the collect_* methods. Register with @StateRegistry.register().

    Usage:
        async with MyStateCollector() as collector:
            async for result in collector.collect(params):
                process(result)
    """

    def __init__(
        self,
        *,
        proxy: str | None = None,
        timeout: float = 30.0,
        max_retries: int = 3,
        rate_limit: float = 1.0,
        use_browser: bool = False,
        use_camoufox: bool = False,
    ) -> None:
        self._proxy = proxy
        self._timeout = timeout
        self._max_retries = max_retries
        self._rate_limit = rate_limit
        self._use_browser = use_browser
        self._use_camoufox = use_camoufox
        self._client: HttpClient | None = None
        self._browser_client = None
        self._camoufox_client = None

    @property
    @abc.abstractmethod
    def state_info(self) -> StateInfo:
        """Return metadata about this state collector."""
        ...

    @property
    def state_code(self) -> str:
        return self.state_info.code

    @property
    def state_name(self) -> str:
        return self.state_info.name

    @property
    def supported_categories(self) -> list[DataCategory]:
        return [
            DataCategory(c) for c in self.state_info.supported_categories
        ]

    # --- Lifecycle ---

    async def __aenter__(self) -> BaseStateCollector:
        self._client = HttpClient(
            proxy=self._proxy,
            timeout=self._timeout,
            max_retries=self._max_retries,
            rate_limit=self._rate_limit,
        )
        await self._client.__aenter__()

        if self._use_camoufox:
            try:
                CamoufoxBrowser = _get_camoufox_class()
                self._camoufox_client = CamoufoxBrowser(
                    proxy=self._proxy,
                    timeout=self._timeout * 1000,  # convert to ms
                )
                await self._camoufox_client.__aenter__()
                # Camoufox serves as the browser client too
                self._browser_client = self._camoufox_client
            except ImportError:
                logger.warning("Camoufox not available, falling back to Playwright")
                self._use_camoufox = False

        if self._use_browser and not self._browser_client:
            BrowserClient = _get_browser_class()
            self._browser_client = BrowserClient(
                proxy=self._proxy,
                timeout=self._timeout * 1000,  # convert to ms
            )
            await self._browser_client.__aenter__()

        return self

    async def __aexit__(self, *args: object) -> None:
        if self._camoufox_client and self._camoufox_client is not self._browser_client:
            await self._camoufox_client.__aexit__(*args)
            self._camoufox_client = None
        if self._browser_client:
            await self._browser_client.__aexit__(*args)
            self._browser_client = None
            self._camoufox_client = None
        if self._client:
            await self._client.__aexit__(*args)
            self._client = None

    @property
    def client(self) -> HttpClient:
        if self._client is None:
            raise RuntimeError(
                "Collector not initialized. Use 'async with' context manager."
            )
        return self._client

    @property
    def browser(self):
        """Access the browser client. Available when use_browser=True."""
        if self._browser_client is None:
            raise RuntimeError(
                "Browser not available. Initialize with use_browser=True."
            )
        return self._browser_client

    @property
    def has_browser(self) -> bool:
        """Check if browser automation is available."""
        return self._browser_client is not None

    # --- Main interface ---

    async def collect(
        self,
        params: SearchParams,
        categories: list[DataCategory] | None = None,
    ) -> AsyncIterator[CollectorResult]:
        """
        Collect data across one or more categories.

        Streams results as they're found. Categories default to all
        supported by this state.
        """
        if categories is None:
            categories = self.supported_categories

        for category in categories:
            if category not in self.supported_categories:
                logger.warning(
                    "%s does not support category '%s', skipping",
                    self.state_code,
                    category.value,
                )
                continue

            logger.info(
                "Collecting %s from %s (%s)",
                category.value,
                self.state_name,
                self.state_code,
            )

            method = self._get_collect_method(category)
            async for result in method(params):
                yield result

    def _get_collect_method(self, category: DataCategory):  # type: ignore[no-untyped-def]
        methods = {
            DataCategory.BUSINESSES: self.collect_businesses,
            DataCategory.LICENSES: self.collect_licenses,
            DataCategory.PROPERTIES: self.collect_properties,
        }
        return methods[category]

    # --- Category methods (override in subclasses) ---

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """Collect registered business entities."""
        raise NotImplementedError(
            f"{self.state_code} does not implement business collection"
        )
        yield  # type: ignore[misc]  # Makes this an async generator

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """Collect professional/occupational licenses."""
        raise NotImplementedError(
            f"{self.state_code} does not implement license collection"
        )
        yield  # type: ignore[misc]

    async def collect_properties(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """Collect property records."""
        raise NotImplementedError(
            f"{self.state_code} does not implement property collection"
        )
        yield  # type: ignore[misc]
