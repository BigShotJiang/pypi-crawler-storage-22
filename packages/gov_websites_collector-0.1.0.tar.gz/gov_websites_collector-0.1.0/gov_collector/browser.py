"""
Browser automation client using Playwright for JS-rendered government sites.

Used as a fallback when HTTP-only scraping fails due to:
- JavaScript SPAs (React, Angular, etc.)
- Cloudflare / Incapsula bot protection
- Complex form interactions requiring real browser
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any

logger = logging.getLogger(__name__)

# Lazy import — only load playwright when actually needed
_playwright_available: bool | None = None


def _check_playwright() -> bool:
    global _playwright_available
    if _playwright_available is None:
        try:
            import playwright.async_api  # noqa: F401
            _playwright_available = True
        except ImportError:
            _playwright_available = False
    return _playwright_available


class BrowserClient:
    """
    Async browser client wrapping Playwright for headless Chrome.

    Usage:
        async with BrowserClient() as browser:
            page = await browser.new_page()
            await page.goto("https://example.gov")
            html = await page.content()
    """

    def __init__(
        self,
        *,
        headless: bool = True,
        proxy: str | None = None,
        timeout: float = 30_000,  # ms
        user_agent: str | None = None,
    ) -> None:
        if not _check_playwright():
            raise ImportError(
                "playwright is required for browser automation. "
                "Install with: pip install playwright && playwright install chromium"
            )
        self._headless = headless
        self._proxy = proxy
        self._timeout = timeout
        self._user_agent = user_agent or (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/131.0.0.0 Safari/537.36"
        )
        self._playwright = None
        self._browser = None
        self._context = None

    async def __aenter__(self) -> BrowserClient:
        from playwright.async_api import async_playwright

        self._playwright = await async_playwright().start()

        launch_opts: dict[str, Any] = {
            "headless": self._headless,
        }
        if self._proxy:
            launch_opts["proxy"] = {"server": self._proxy}

        self._browser = await self._playwright.chromium.launch(**launch_opts)
        self._context = await self._browser.new_context(
            user_agent=self._user_agent,
            viewport={"width": 1280, "height": 800},
            java_script_enabled=True,
            locale="en-US",
        )
        self._context.set_default_timeout(self._timeout)
        return self

    async def __aexit__(self, *args: object) -> None:
        if self._context:
            await self._context.close()
        if self._browser:
            await self._browser.close()
        if self._playwright:
            await self._playwright.stop()
        self._context = None
        self._browser = None
        self._playwright = None

    async def new_page(self):
        """Create a new browser page/tab."""
        if self._context is None:
            raise RuntimeError("Browser not initialized. Use 'async with'.")
        return await self._context.new_page()

    async def get_page_html(
        self,
        url: str,
        *,
        wait_selector: str | None = None,
        wait_timeout: float = 15_000,
        wait_for_load: str = "networkidle",
    ) -> str:
        """
        Navigate to URL and return the fully rendered HTML.

        Args:
            url: URL to navigate to
            wait_selector: Optional CSS selector to wait for before extracting HTML
            wait_timeout: Timeout for waiting on selector (ms)
            wait_for_load: Playwright load state ('load', 'domcontentloaded', 'networkidle')
        """
        page = await self.new_page()
        try:
            await page.goto(url, wait_until=wait_for_load, timeout=self._timeout)
            if wait_selector:
                await page.wait_for_selector(wait_selector, timeout=wait_timeout)
            return await page.content()
        finally:
            await page.close()

    async def fill_and_submit(
        self,
        url: str,
        fields: dict[str, str],
        submit_selector: str,
        *,
        result_selector: str | None = None,
        wait_timeout: float = 15_000,
        pre_fill_wait: str | None = None,
    ) -> str:
        """
        Navigate, fill form fields, submit, and return result HTML.

        Args:
            url: Form page URL
            fields: Dict of CSS selector -> value to fill
            submit_selector: CSS selector for the submit button
            result_selector: Optional selector to wait for after submission
            wait_timeout: Timeout for results to appear (ms)
            pre_fill_wait: Optional selector to wait for before filling form
        """
        page = await self.new_page()
        try:
            await page.goto(url, wait_until="networkidle", timeout=self._timeout)

            if pre_fill_wait:
                await page.wait_for_selector(pre_fill_wait, timeout=wait_timeout)

            for selector, value in fields.items():
                await page.fill(selector, value)

            await page.click(submit_selector)

            if result_selector:
                await page.wait_for_selector(result_selector, timeout=wait_timeout)
            else:
                await page.wait_for_load_state("networkidle", timeout=wait_timeout)

            return await page.content()
        finally:
            await page.close()

    async def execute_search(
        self,
        url: str,
        *,
        actions: list[dict[str, Any]],
        result_selector: str | None = None,
        wait_timeout: float = 15_000,
    ) -> str:
        """
        Execute a sequence of browser actions and return resulting HTML.

        Actions are dicts with 'type' key and relevant params:
        - {"type": "fill", "selector": "...", "value": "..."}
        - {"type": "click", "selector": "..."}
        - {"type": "select", "selector": "...", "value": "..."}
        - {"type": "wait", "selector": "...", "timeout": 5000}
        - {"type": "wait_ms", "ms": 1000}
        - {"type": "press", "key": "Enter"}
        """
        page = await self.new_page()
        try:
            await page.goto(url, wait_until="networkidle", timeout=self._timeout)

            for action in actions:
                atype = action["type"]
                if atype == "fill":
                    await page.fill(action["selector"], action["value"])
                elif atype == "click":
                    await page.click(action["selector"])
                elif atype == "select":
                    await page.select_option(action["selector"], action["value"])
                elif atype == "wait":
                    await page.wait_for_selector(
                        action["selector"],
                        timeout=action.get("timeout", wait_timeout),
                    )
                elif atype == "wait_ms":
                    await asyncio.sleep(action["ms"] / 1000)
                elif atype == "press":
                    await page.keyboard.press(action["key"])
                else:
                    logger.warning("Unknown browser action type: %s", atype)

            if result_selector:
                await page.wait_for_selector(result_selector, timeout=wait_timeout)
            else:
                await page.wait_for_load_state("networkidle", timeout=wait_timeout)

            return await page.content()
        finally:
            await page.close()
