"""
Camoufox browser client for bypassing bot protection on government sites.

Wraps the AsyncCamoufox context manager to provide a Playwright-compatible
interface with anti-detection features:
- Humanized mouse/keyboard input
- GeoIP-based fingerprint
- Proxy support with authentication
- Auto-retry on Cloudflare/Imperva challenges
"""

from __future__ import annotations

import asyncio
import logging
import re
from typing import Any

logger = logging.getLogger(__name__)

# Lazy check for camoufox availability
_camoufox_available: bool | None = None


def _check_camoufox() -> bool:
    global _camoufox_available
    if _camoufox_available is None:
        try:
            from camoufox.async_api import AsyncCamoufox  # noqa: F401
            _camoufox_available = True
        except ImportError:
            _camoufox_available = False
    return _camoufox_available


def _is_challenge_page(html: str) -> bool:
    """Detect if the page is a Cloudflare/Imperva challenge."""
    indicators = [
        "Just a moment...",
        "Checking your browser",
        "cf-browser-verification",
        "challenge-platform",
        "Attention Required! | Cloudflare",
        "_cf_chl_opt",
        "cdn-cgi/challenge-platform",
        "Incapsula incident",
        "Request unsuccessful. Incapsula",
        "_Incapsula_Resource",
        "Access Denied",
    ]
    for indicator in indicators:
        if indicator in html:
            return True
    return False


class CamoufoxBrowser:
    """
    Async browser client using Camoufox for anti-detection browsing.

    Features:
    - Camoufox with humanize=True and geoip=True for realistic fingerprinting
    - Proxy support (HTTP with auth)
    - Auto-retry with increasing waits when challenge pages detected
    - Same interface as BrowserClient for drop-in replacement

    Usage:
        async with CamoufoxBrowser(proxy_url="http://user:pass@host:port") as browser:
            page = await browser.new_page()
            await page.goto("https://example.gov")
            html = await page.content()
    """

    def __init__(
        self,
        *,
        proxy: str | dict | None = None,
        timeout: float = 60_000,  # ms
        humanize: bool = True,
        geoip: bool = True,
        headless: bool = True,
        max_challenge_retries: int = 3,
        challenge_wait_base: float = 10.0,  # seconds
    ) -> None:
        if not _check_camoufox():
            raise ImportError(
                "camoufox is required. Install with: pip install camoufox[geoip]"
            )
        self._proxy = proxy
        self._timeout = timeout
        self._humanize = humanize
        self._geoip = geoip
        self._headless = headless
        self._max_challenge_retries = max_challenge_retries
        self._challenge_wait_base = challenge_wait_base
        self._camoufox_cm = None
        self._browser = None
        self._context = None

    def _parse_proxy(self) -> dict | None:
        """Parse proxy config into Camoufox format."""
        if self._proxy is None:
            return None
        if isinstance(self._proxy, dict):
            return self._proxy
        # Parse URL format: http://user:pass@host:port
        proxy_str = self._proxy
        if "://" not in proxy_str:
            proxy_str = f"http://{proxy_str}"

        from urllib.parse import urlparse
        parsed = urlparse(proxy_str)
        result = {
            "server": f"{parsed.scheme}://{parsed.hostname}:{parsed.port}",
        }
        if parsed.username:
            result["username"] = parsed.username
        if parsed.password:
            result["password"] = parsed.password
        return result

    async def __aenter__(self) -> CamoufoxBrowser:
        from camoufox.async_api import AsyncCamoufox

        proxy_config = self._parse_proxy()

        # Build Camoufox kwargs
        kwargs: dict[str, Any] = {
            "humanize": self._humanize,
            "geoip": self._geoip,
            "headless": self._headless,
        }
        if proxy_config:
            kwargs["proxy"] = proxy_config

        self._camoufox_cm = AsyncCamoufox(**kwargs)
        self._browser = await self._camoufox_cm.__aenter__()

        # Create default context with timeout
        self._context = self._browser
        return self

    async def __aexit__(self, *args: object) -> None:
        if self._camoufox_cm:
            await self._camoufox_cm.__aexit__(*args)
        self._camoufox_cm = None
        self._browser = None
        self._context = None

    async def new_page(self):
        """Create a new browser page/tab."""
        if self._browser is None:
            raise RuntimeError("Browser not initialized. Use 'async with'.")
        page = await self._browser.new_page()
        page.set_default_timeout(self._timeout)
        return page

    async def get_page_html(
        self,
        url: str,
        *,
        wait_selector: str | None = None,
        wait_timeout: float = 15_000,
        wait_for_load: str = "domcontentloaded",
        bypass_challenge: bool = True,
    ) -> str:
        """
        Navigate to URL, auto-bypass challenges, and return rendered HTML.

        Args:
            url: URL to navigate to
            wait_selector: Optional CSS selector to wait for
            wait_timeout: Timeout for selector wait (ms)
            wait_for_load: Load state to wait for
            bypass_challenge: Auto-retry if challenge page detected
        """
        page = await self.new_page()
        try:
            await page.goto(url, wait_until=wait_for_load, timeout=self._timeout)

            if bypass_challenge:
                html = await page.content()
                retries = 0
                while _is_challenge_page(html) and retries < self._max_challenge_retries:
                    wait_time = self._challenge_wait_base * (retries + 1)
                    logger.info(
                        "Challenge detected on %s, waiting %.0fs (attempt %d/%d)",
                        url, wait_time, retries + 1, self._max_challenge_retries,
                    )
                    await asyncio.sleep(wait_time)
                    html = await page.content()
                    retries += 1

                if _is_challenge_page(html):
                    logger.warning(
                        "Challenge page persists after %d retries on %s",
                        self._max_challenge_retries, url,
                    )

            if wait_selector:
                try:
                    await page.wait_for_selector(wait_selector, timeout=wait_timeout)
                except Exception:
                    logger.debug("Selector '%s' not found within timeout", wait_selector)

            return await page.content()
        finally:
            await page.close()

    async def fill_and_submit(
        self,
        url: str,
        fields: dict[str, str],
        submit_selector: str,
        *,
        result_selector: str | None = None,
        wait_timeout: float = 15_000,
        pre_fill_wait: str | None = None,
        challenge_wait: float = 10.0,
    ) -> str:
        """
        Navigate, bypass challenge, fill form, submit, and return result HTML.
        """
        page = await self.new_page()
        try:
            await page.goto(url, wait_until="domcontentloaded", timeout=self._timeout)

            # Wait for potential challenge to resolve
            html = await page.content()
            retries = 0
            while _is_challenge_page(html) and retries < self._max_challenge_retries:
                wait_time = challenge_wait * (retries + 1)
                logger.info("Challenge detected, waiting %.0fs...", wait_time)
                await asyncio.sleep(wait_time)
                html = await page.content()
                retries += 1

            if pre_fill_wait:
                try:
                    await page.wait_for_selector(pre_fill_wait, timeout=wait_timeout)
                except Exception:
                    pass

            # Fill fields with human-like delays
            for selector, value in fields.items():
                try:
                    await page.wait_for_selector(selector, timeout=5000)
                    await page.fill(selector, value)
                    await asyncio.sleep(0.3)  # Human-like delay between fields
                except Exception as e:
                    logger.debug("Could not fill %s: %s", selector, e)

            # Click submit
            try:
                await page.click(submit_selector)
            except Exception:
                # Fallback: try pressing Enter
                await page.keyboard.press("Enter")

            if result_selector:
                try:
                    await page.wait_for_selector(result_selector, timeout=wait_timeout)
                except Exception:
                    pass
            else:
                try:
                    await page.wait_for_load_state("domcontentloaded", timeout=wait_timeout)
                except Exception:
                    pass

            return await page.content()
        finally:
            await page.close()

    async def execute_search(
        self,
        url: str,
        *,
        actions: list[dict[str, Any]],
        result_selector: str | None = None,
        wait_timeout: float = 15_000,
        challenge_wait: float = 10.0,
    ) -> str:
        """
        Execute browser actions with challenge bypass. Same interface as BrowserClient.
        """
        page = await self.new_page()
        try:
            await page.goto(url, wait_until="domcontentloaded", timeout=self._timeout)

            # Auto-bypass challenge
            html = await page.content()
            retries = 0
            while _is_challenge_page(html) and retries < self._max_challenge_retries:
                wait_time = challenge_wait * (retries + 1)
                logger.info("Challenge detected, waiting %.0fs...", wait_time)
                await asyncio.sleep(wait_time)
                html = await page.content()
                retries += 1

            for action in actions:
                atype = action["type"]
                if atype == "fill":
                    await page.fill(action["selector"], action["value"])
                elif atype == "click":
                    await page.click(action["selector"])
                elif atype == "select":
                    await page.select_option(action["selector"], action["value"])
                elif atype == "wait":
                    await page.wait_for_selector(
                        action["selector"],
                        timeout=action.get("timeout", wait_timeout),
                    )
                elif atype == "wait_ms":
                    await asyncio.sleep(action["ms"] / 1000)
                elif atype == "press":
                    await page.keyboard.press(action["key"])
                else:
                    logger.warning("Unknown action type: %s", atype)

            if result_selector:
                try:
                    await page.wait_for_selector(result_selector, timeout=wait_timeout)
                except Exception:
                    pass
            else:
                try:
                    await page.wait_for_load_state("domcontentloaded", timeout=wait_timeout)
                except Exception:
                    pass

            return await page.content()
        finally:
            await page.close()
