"""
CLI interface for gov-websites-collector.

Usage:
    gov-collect search --state CA --query "Smith" --category licenses
    gov-collect search --state FL --query "Realty" --category businesses
    gov-collect states
    gov-collect states --category licenses
    gov-collect info CA
"""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import sys
from typing import Any

from rich.console import Console
from rich.table import Table

from gov_collector.base import DataCategory
from gov_collector.models import SearchParams
from gov_collector.registry import StateRegistry, get_collector, list_states

console = Console()


def main() -> None:
    """CLI entry point."""
    parser = argparse.ArgumentParser(
        prog="gov-collect",
        description="Collect US business and license data from government websites",
    )
    parser.add_argument(
        "-v", "--verbose", action="store_true", help="Enable verbose logging"
    )

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # --- search ---
    search_parser = subparsers.add_parser("search", help="Search government databases")
    search_parser.add_argument(
        "--state", "-s", required=True, help="Two-letter state code (e.g. CA, TX, FL)"
    )
    search_parser.add_argument(
        "--query", "-q", help="Search query (name, keyword)"
    )
    search_parser.add_argument(
        "--category", "-c",
        choices=["licenses", "businesses", "properties"],
        help="Data category to search",
    )
    search_parser.add_argument(
        "--license-number", help="Search by license number"
    )
    search_parser.add_argument("--city", help="Filter by city")
    search_parser.add_argument("--county", help="Filter by county")
    search_parser.add_argument("--zip", help="Filter by ZIP code")
    search_parser.add_argument(
        "--max-results", type=int, default=50, help="Max results (default: 50)"
    )
    search_parser.add_argument(
        "--format", "-f",
        choices=["table", "json", "jsonl"],
        default="table",
        help="Output format (default: table)",
    )
    search_parser.add_argument("--proxy", help="HTTP proxy URL")
    search_parser.add_argument(
        "--rate-limit", type=float, default=1.0,
        help="Seconds between requests (default: 1.0)",
    )
    search_parser.add_argument(
        "--browser", action="store_true",
        help="Enable Playwright browser automation",
    )
    search_parser.add_argument(
        "--camoufox", action="store_true",
        help="Enable Camoufox browser (anti-detection, bypasses CF/Imperva)",
    )

    # --- states ---
    states_parser = subparsers.add_parser("states", help="List available states")
    states_parser.add_argument(
        "--category", "-c",
        choices=["licenses", "businesses", "properties"],
        help="Filter by supported category",
    )

    # --- info ---
    info_parser = subparsers.add_parser("info", help="Show state collector info")
    info_parser.add_argument("state", help="Two-letter state code")

    args = parser.parse_args()

    if args.verbose:
        logging.basicConfig(level=logging.DEBUG, format="%(name)s: %(message)s")
    else:
        logging.basicConfig(level=logging.WARNING)

    if args.command == "search":
        asyncio.run(_cmd_search(args))
    elif args.command == "states":
        _cmd_states(args)
    elif args.command == "info":
        _cmd_info(args)
    else:
        parser.print_help()


async def _cmd_search(args: argparse.Namespace) -> None:
    """Execute a search command."""
    params = SearchParams(
        query=args.query,
        state=args.state.upper(),
        city=args.city,
        county=args.county,
        zip_code=args.zip,
        license_number=args.license_number,
        max_results=args.max_results,
    )

    categories = None
    if args.category:
        categories = [DataCategory(args.category)]

    try:
        collector = get_collector(
            args.state,
            proxy=args.proxy,
            rate_limit=args.rate_limit,
            use_browser=getattr(args, 'browser', False),
            use_camoufox=getattr(args, 'camoufox', False),
        )
    except ValueError as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)

    results: list[dict[str, Any]] = []

    async with collector:
        console.print(
            f"[cyan]Searching {collector.state_name} ({collector.state_code})...[/cyan]"
        )
        try:
            async for result in collector.collect(params, categories=categories):
                record = result.data.model_dump(exclude_none=True, exclude={"raw_data"})
                record["_category"] = result.category
                record["_source"] = result.source
                results.append(record)

                if args.format == "jsonl":
                    print(json.dumps(record, default=str))

        except Exception as e:
            console.print(f"[red]Error during collection:[/red] {e}")
            if args.verbose:
                import traceback
                traceback.print_exc()
            sys.exit(1)

    if not results:
        console.print("[yellow]No results found.[/yellow]")
        return

    if args.format == "json":
        print(json.dumps(results, indent=2, default=str))
    elif args.format == "table":
        _print_results_table(results)
    # jsonl already printed above

    console.print(f"\n[green]Found {len(results)} results.[/green]")


def _print_results_table(results: list[dict[str, Any]]) -> None:
    """Print results as a rich table."""
    if not results:
        return

    table = Table(show_header=True, header_style="bold cyan")

    # Determine columns from first result (skip internal fields)
    sample = results[0]
    columns = [k for k in sample.keys() if not k.startswith("_")]

    # Prioritize certain columns
    priority = ["name", "holder_name", "license_number", "license_type", "status", "state", "city"]
    ordered = [c for c in priority if c in columns]
    ordered += [c for c in columns if c not in ordered]

    # Limit columns for readability
    display_cols = ordered[:8]

    for col in display_cols:
        table.add_column(col.replace("_", " ").title(), overflow="fold")

    for record in results:
        row = []
        for col in display_cols:
            val = record.get(col, "")
            if isinstance(val, dict):
                # For nested objects like address, show compact form
                val = val.get("raw") or val.get("city") or str(val)
            row.append(str(val) if val else "")
        table.add_row(*row)

    console.print(table)


def _cmd_states(args: argparse.Namespace) -> None:
    """List available state collectors."""
    if args.category:
        category = DataCategory(args.category)
        states = StateRegistry.list_by_category(category)
        console.print(
            f"[cyan]States supporting '{args.category}':[/cyan]"
        )
    else:
        states = list_states()
        console.print("[cyan]Available state collectors:[/cyan]")

    if not states:
        console.print("[yellow]No state collectors found.[/yellow]")
        return

    table = Table(show_header=True, header_style="bold cyan")
    table.add_column("Code", style="bold")
    table.add_column("State")
    table.add_column("Categories")
    table.add_column("Sources")

    for info in states:
        table.add_row(
            info.code,
            info.name,
            ", ".join(info.supported_categories),
            "\n".join(info.sources),
        )

    console.print(table)


def _cmd_info(args: argparse.Namespace) -> None:
    """Show detailed info about a state collector."""
    cls = StateRegistry.get(args.state.upper())
    if cls is None:
        console.print(f"[red]No collector for state: {args.state}[/red]")
        available = list_states()
        if available:
            codes = ", ".join(s.code for s in available)
            console.print(f"[yellow]Available: {codes}[/yellow]")
        sys.exit(1)

    info = cls.state_info.fget(cls)  # type: ignore[union-attr]

    console.print(f"\n[bold cyan]{info.name} ({info.code})[/bold cyan]")
    console.print(f"  Categories: {', '.join(info.supported_categories)}")
    console.print(f"  Sources:")
    for source in info.sources:
        console.print(f"    • {source}")
    if info.notes:
        console.print(f"  Notes: {info.notes}")
    console.print()


if __name__ == "__main__":
    main()
