"""
Custom exceptions for government website collectors.
"""


class CollectorError(Exception):
    """Base exception for all collector errors."""


class StateNotSupportedError(CollectorError):
    """Raised when a state doesn't have a collector implementation."""

    def __init__(self, state_code: str) -> None:
        self.state_code = state_code
        super().__init__(f"No collector available for state: {state_code}")


class CategoryNotSupportedError(CollectorError):
    """Raised when a state doesn't support a requested data category."""

    def __init__(self, state_code: str, category: str) -> None:
        self.state_code = state_code
        self.category = category
        super().__init__(
            f"State {state_code} does not support category: {category}"
        )


class ScrapingError(CollectorError):
    """Raised when scraping fails (unexpected page structure, etc.)."""


class RateLimitError(CollectorError):
    """Raised when rate limited by the target site."""


class AuthenticationError(CollectorError):
    """Raised when authentication/captcha is required."""


class ParseError(CollectorError):
    """Raised when response parsing fails."""

    def __init__(self, message: str, raw_content: str | None = None) -> None:
        self.raw_content = raw_content
        super().__init__(message)
