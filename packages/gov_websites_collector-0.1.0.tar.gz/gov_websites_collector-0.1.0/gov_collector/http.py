"""
HTTP client with rate limiting, retries, and proxy support.
"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Any

import httpx
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

logger = logging.getLogger(__name__)

DEFAULT_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/131.0.0.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
}


class HttpClient:
    """
    Async HTTP client with built-in rate limiting and retries.

    Usage:
        async with HttpClient(rate_limit=1.0) as client:
            response = await client.get("https://example.gov/search")
    """

    def __init__(
        self,
        *,
        proxy: str | None = None,
        timeout: float = 30.0,
        max_retries: int = 3,
        rate_limit: float = 1.0,
        headers: dict[str, str] | None = None,
    ) -> None:
        self._proxy = proxy
        self._timeout = timeout
        self._max_retries = max_retries
        self._rate_limit = rate_limit
        self._headers = {**DEFAULT_HEADERS, **(headers or {})}
        self._client: httpx.AsyncClient | None = None
        self._last_request_time: float = 0.0
        self._lock = asyncio.Lock()

    async def __aenter__(self) -> HttpClient:
        self._client = httpx.AsyncClient(
            proxy=self._proxy,
            timeout=httpx.Timeout(self._timeout),
            headers=self._headers,
            follow_redirects=True,
            limits=httpx.Limits(
                max_connections=10,
                max_keepalive_connections=5,
            ),
        )
        return self

    async def __aexit__(self, *args: object) -> None:
        if self._client:
            await self._client.aclose()
            self._client = None

    @property
    def raw(self) -> httpx.AsyncClient:
        """Access the underlying httpx client for advanced usage."""
        if self._client is None:
            raise RuntimeError("Client not initialized. Use 'async with'.")
        return self._client

    async def _rate_limit_wait(self) -> None:
        """Enforce minimum delay between requests."""
        if self._rate_limit <= 0:
            return
        async with self._lock:
            now = time.monotonic()
            elapsed = now - self._last_request_time
            if elapsed < self._rate_limit:
                delay = self._rate_limit - elapsed
                logger.debug("Rate limiting: waiting %.2fs", delay)
                await asyncio.sleep(delay)
            self._last_request_time = time.monotonic()

    async def get(
        self,
        url: str,
        *,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> httpx.Response:
        """GET request with rate limiting and retries."""
        return await self._request("GET", url, params=params, headers=headers)

    async def post(
        self,
        url: str,
        *,
        data: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> httpx.Response:
        """POST request with rate limiting and retries."""
        return await self._request(
            "POST", url, data=data, json=json, params=params, headers=headers
        )

    @retry(
        retry=retry_if_exception_type((httpx.TimeoutException, httpx.ConnectError)),
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=30),
        before_sleep=lambda retry_state: logger.warning(
            "Request failed, retrying (attempt %d)...", retry_state.attempt_number
        ),
    )
    async def _request(
        self,
        method: str,
        url: str,
        **kwargs: Any,
    ) -> httpx.Response:
        """Execute an HTTP request with rate limiting."""
        await self._rate_limit_wait()

        if self._client is None:
            raise RuntimeError("Client not initialized. Use 'async with'.")

        logger.debug("%s %s", method, url)
        response = await self._client.request(method, url, **kwargs)
        response.raise_for_status()
        return response

    async def get_text(
        self,
        url: str,
        *,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> str:
        """GET request returning response text."""
        response = await self.get(url, params=params, headers=headers)
        return response.text

    async def get_json(
        self,
        url: str,
        *,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> Any:
        """GET request returning parsed JSON."""
        response = await self.get(url, params=params, headers=headers)
        return response.json()

    async def post_json(
        self,
        url: str,
        *,
        json: dict[str, Any] | None = None,
        data: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> Any:
        """POST request returning parsed JSON."""
        response = await self.post(url, json=json, data=data, headers=headers)
        return response.json()
