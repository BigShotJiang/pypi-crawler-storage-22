"""
Data models for government website collectors.

All models use Pydantic for validation. Fields are intentionally broad
to accommodate varying data availability across states.
"""

from __future__ import annotations

from datetime import date, datetime
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field, HttpUrl


class EntityType(str, Enum):
    """Type of business entity."""

    LLC = "llc"
    CORPORATION = "corporation"
    SOLE_PROPRIETORSHIP = "sole_proprietorship"
    PARTNERSHIP = "partnership"
    LP = "limited_partnership"
    LLP = "limited_liability_partnership"
    NONPROFIT = "nonprofit"
    TRUST = "trust"
    OTHER = "other"


class LicenseStatus(str, Enum):
    """Status of a professional license."""

    ACTIVE = "active"
    INACTIVE = "inactive"
    EXPIRED = "expired"
    SUSPENDED = "suspended"
    REVOKED = "revoked"
    PENDING = "pending"
    CANCELLED = "cancelled"
    OTHER = "other"


class EntityStatus(str, Enum):
    """Status of a business entity."""

    ACTIVE = "active"
    INACTIVE = "inactive"
    DISSOLVED = "dissolved"
    SUSPENDED = "suspended"
    WITHDRAWN = "withdrawn"
    MERGED = "merged"
    CONVERTED = "converted"
    OTHER = "other"


class Address(BaseModel):
    """Physical or mailing address."""

    street: str | None = None
    street2: str | None = None
    city: str | None = None
    state: str | None = None
    zip_code: str | None = None
    county: str | None = None
    country: str = "US"
    raw: str | None = Field(
        None, description="Unparsed address string from source"
    )


class Person(BaseModel):
    """A person associated with a business or license."""

    first_name: str | None = None
    last_name: str | None = None
    full_name: str | None = None
    title: str | None = None
    email: str | None = None
    phone: str | None = None

    def get_display_name(self) -> str:
        if self.full_name:
            return self.full_name
        parts = [p for p in [self.first_name, self.last_name] if p]
        return " ".join(parts) if parts else "Unknown"


class Business(BaseModel):
    """A registered business entity from Secretary of State or similar."""

    name: str
    entity_type: EntityType | None = None
    status: EntityStatus | None = None
    state: str = Field(..., description="Two-letter state code")
    filing_number: str | None = Field(None, description="State filing/registration number")
    formation_date: date | None = None
    expiration_date: date | None = None
    address: Address | None = None
    mailing_address: Address | None = None
    registered_agent: Person | None = None
    officers: list[Person] = Field(default_factory=list)
    industry: str | None = None
    naics_code: str | None = None
    source_url: HttpUrl | None = None
    raw_data: dict[str, Any] = Field(
        default_factory=dict, description="Original unprocessed fields from source"
    )


class License(BaseModel):
    """A professional or occupational license."""

    license_number: str
    license_type: str = Field(..., description="e.g. 'Real Estate Salesperson', 'Broker'")
    status: LicenseStatus = LicenseStatus.OTHER
    state: str = Field(..., description="Two-letter state code")
    holder_name: str | None = None
    holder: Person | None = None
    business_name: str | None = None
    address: Address | None = None
    issue_date: date | None = None
    expiration_date: date | None = None
    discipline_history: list[str] = Field(default_factory=list)
    specializations: list[str] = Field(default_factory=list)
    source_url: HttpUrl | None = None
    raw_data: dict[str, Any] = Field(
        default_factory=dict, description="Original unprocessed fields from source"
    )


class Property(BaseModel):
    """A real property record from county assessor or similar."""

    parcel_id: str | None = None
    address: Address | None = None
    owner_name: str | None = None
    owner_address: Address | None = None
    property_type: str | None = None
    assessed_value: float | None = None
    market_value: float | None = None
    land_value: float | None = None
    building_value: float | None = None
    year_built: int | None = None
    square_feet: float | None = None
    lot_size: float | None = None
    bedrooms: int | None = None
    bathrooms: float | None = None
    last_sale_date: date | None = None
    last_sale_price: float | None = None
    tax_amount: float | None = None
    state: str = Field(..., description="Two-letter state code")
    county: str | None = None
    source_url: HttpUrl | None = None
    raw_data: dict[str, Any] = Field(
        default_factory=dict, description="Original unprocessed fields from source"
    )


class SearchParams(BaseModel):
    """Parameters for searching government databases."""

    query: str | None = Field(None, description="General search term (name, keyword)")
    state: str | None = Field(None, description="Two-letter state code or 'all'")
    city: str | None = None
    county: str | None = None
    zip_code: str | None = None
    license_type: str | None = None
    license_number: str | None = None
    entity_type: EntityType | None = None
    status: str | None = None
    max_results: int = Field(100, ge=1, le=10000)
    extra: dict[str, Any] = Field(
        default_factory=dict,
        description="State-specific search parameters",
    )


class StateInfo(BaseModel):
    """Metadata about a state collector's capabilities."""

    code: str = Field(..., description="Two-letter state code (e.g. 'CA')")
    name: str = Field(..., description="Full state name (e.g. 'California')")
    supported_categories: list[str] = Field(
        default_factory=list,
        description="Data categories this state supports",
    )
    sources: list[str] = Field(
        default_factory=list,
        description="Government data sources used",
    )
    notes: str | None = None


class CollectorResult(BaseModel):
    """Wrapper for a single result from a collector."""

    category: str
    state: str
    data: Business | License | Property
    collected_at: datetime = Field(default_factory=lambda: datetime.now(tz=None))
    source: str | None = None
