"""
HTML parsing utilities shared across state collectors.
"""

from __future__ import annotations

import re
from typing import Any

from selectolax.parser import HTMLParser, Node

from gov_collector.models import Address


def parse_html(html: str) -> HTMLParser:
    """Parse HTML string into a selectolax tree."""
    return HTMLParser(html)


def clean_text(text: str | None) -> str | None:
    """Clean whitespace from extracted text."""
    if text is None:
        return None
    cleaned = re.sub(r"\s+", " ", text).strip()
    return cleaned if cleaned else None


def extract_text(node: Node | None) -> str | None:
    """Extract and clean text from an HTML node."""
    if node is None:
        return None
    return clean_text(node.text(deep=True))


def extract_table_rows(
    html: str,
    table_selector: str = "table",
    header_row: int = 0,
) -> list[dict[str, str]]:
    """
    Extract rows from an HTML table as a list of dicts.

    Args:
        html: HTML string containing a table
        table_selector: CSS selector for the table
        header_row: Which <tr> to use as headers (0-indexed)

    Returns:
        List of dicts mapping header names to cell values
    """
    tree = parse_html(html)
    table = tree.css_first(table_selector)
    if table is None:
        return []

    rows = table.css("tr")
    if len(rows) <= header_row + 1:
        return []

    # Extract headers
    header_cells = rows[header_row].css("th, td")
    headers = [clean_text(cell.text(deep=True)) or f"col_{i}" for i, cell in enumerate(header_cells)]

    # Extract data rows
    results = []
    for row in rows[header_row + 1 :]:
        cells = row.css("td")
        if not cells:
            continue
        row_data = {}
        for i, cell in enumerate(cells):
            key = headers[i] if i < len(headers) else f"col_{i}"
            row_data[key] = clean_text(cell.text(deep=True)) or ""
        results.append(row_data)

    return results


def extract_detail_pairs(
    html: str,
    container_selector: str = "table",
    label_selector: str = "th, td.label, dt",
    value_selector: str = "td, dd",
) -> dict[str, str]:
    """
    Extract label-value pairs from a detail/description page.

    Common patterns:
    - <table> with <th>Label</th><td>Value</td>
    - <dl> with <dt>Label</dt><dd>Value</dd>
    - <div class="row"><span class="label">Label</span><span>Value</span></div>
    """
    tree = parse_html(html)
    container = tree.css_first(container_selector)
    if container is None:
        return {}

    pairs: dict[str, str] = {}

    # Try table rows first
    for row in container.css("tr"):
        cells = row.css("th, td")
        if len(cells) >= 2:
            label = clean_text(cells[0].text(deep=True))
            value = clean_text(cells[1].text(deep=True))
            if label and value:
                pairs[label] = value

    # Try definition lists
    if not pairs:
        for dt in container.css("dt"):
            dd = dt.next
            while dd and dd.tag != "dd":
                dd = dd.next
            if dd:
                label = clean_text(dt.text(deep=True))
                value = clean_text(dd.text(deep=True))
                if label and value:
                    pairs[label] = value

    return pairs


def parse_address_text(text: str) -> Address:
    """
    Best-effort parse of an address string.

    Handles common US formats:
    - "123 Main St, City, ST 12345"
    - "123 Main St\\nCity, ST 12345"
    """
    text = text.replace("\n", ", ").replace("\r", "")
    text = re.sub(r",\s*,", ",", text)

    # Try to extract zip code
    zip_match = re.search(r"\b(\d{5}(?:-\d{4})?)\b", text)
    zip_code = zip_match.group(1) if zip_match else None

    # Try to extract state code
    state_match = re.search(r"\b([A-Z]{2})\b(?:\s+\d{5})?", text)
    state = state_match.group(1) if state_match else None

    # Split into parts
    parts = [p.strip() for p in text.split(",") if p.strip()]

    address = Address(raw=text, zip_code=zip_code, state=state)

    if len(parts) >= 3:
        address.street = parts[0]
        address.city = parts[-2].strip() if len(parts) >= 3 else None
    elif len(parts) == 2:
        address.street = parts[0]
        # Second part might be "City, ST ZIP" combined
        city_state = parts[1].strip()
        city_match = re.match(r"^(.+?)\s+[A-Z]{2}\s+\d{5}", city_state)
        if city_match:
            address.city = city_match.group(1).strip()

    return address


def normalize_name(name: str) -> str:
    """Normalize a person/business name for comparison."""
    name = name.upper().strip()
    name = re.sub(r"\s+", " ", name)
    # Remove common suffixes (only strip once, longest match first)
    suffixes = [", LLC", ", INC.", ", INC", ", CORP.", ", CORP", ", LTD.", ", LTD",
                " LLC", " INC.", " INC", " CORP.", " CORP", " LTD.", " LTD"]
    for suffix in suffixes:
        if name.endswith(suffix):
            name = name[: -len(suffix)].rstrip()
            break
    return name
