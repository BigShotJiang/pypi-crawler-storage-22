"""
Proxy configuration utilities for government website collectors.

Provides a ProxyInfo dataclass and rotation support for proxying requests
through HTTP/SOCKS5 proxies. Users must supply their own proxy credentials.

Usage:
    from gov_collector.proxy_config import ProxyInfo, ProxyRotator

    # Single proxy
    proxy = ProxyInfo(host="myproxy.example.com", port=8080, username="user", password="pass")
    print(proxy.url)  # http://user:pass@myproxy.example.com:8080

    # Rotation
    proxies = [
        ProxyInfo(host="proxy1.example.com", port=8080, username="u", password="p"),
        ProxyInfo(host="proxy2.example.com", port=8080, username="u", password="p"),
    ]
    rotator = ProxyRotator(proxies=proxies)
    url = rotator.get_url()
"""

from __future__ import annotations

import itertools
import os
import random
from dataclasses import dataclass, field


@dataclass
class ProxyInfo:
    """A single proxy server configuration."""

    host: str = ""
    port: int = 8080
    username: str = ""
    password: str = ""
    location: str = ""
    country: str = ""
    priority: int = 0  # Lower = preferred

    @property
    def url(self) -> str:
        """HTTP proxy URL with authentication."""
        if self.username and self.password:
            return f"http://{self.username}:{self.password}@{self.host}:{self.port}"
        return f"http://{self.host}:{self.port}"

    @property
    def url_no_auth(self) -> str:
        """HTTP proxy URL without authentication."""
        return f"http://{self.host}:{self.port}"

    @property
    def socks5_url(self) -> str:
        """SOCKS5 proxy URL with authentication."""
        if self.username and self.password:
            return f"socks5://{self.username}:{self.password}@{self.host}:{self.port}"
        return f"socks5://{self.host}:{self.port}"

    @property
    def playwright_proxy(self) -> dict:
        """Proxy config dict for Playwright/Camoufox."""
        result: dict[str, str] = {
            "server": f"http://{self.host}:{self.port}",
        }
        if self.username:
            result["username"] = self.username
        if self.password:
            result["password"] = self.password
        return result

    @property
    def camoufox_proxy(self) -> dict:
        """Proxy config dict for Camoufox (uses same format as Playwright)."""
        return self.playwright_proxy


def proxy_from_url(url: str) -> ProxyInfo:
    """
    Create a ProxyInfo from a proxy URL string.

    Supports formats:
    - http://user:pass@host:port
    - socks5://user:pass@host:port
    - host:port
    """
    from urllib.parse import urlparse

    if "://" not in url:
        url = f"http://{url}"

    parsed = urlparse(url)
    return ProxyInfo(
        host=parsed.hostname or "",
        port=parsed.port or 8080,
        username=parsed.username or "",
        password=parsed.password or "",
    )


def proxy_from_env(
    env_var: str = "GOV_COLLECTOR_PROXY",
) -> ProxyInfo | None:
    """
    Create a ProxyInfo from an environment variable.

    Returns None if the env var is not set.
    """
    url = os.environ.get(env_var)
    if not url:
        return None
    return proxy_from_url(url)


class ProxyRotator:
    """
    Rotate through proxies with optional priority ordering.

    Usage:
        rotator = ProxyRotator(proxies=[proxy1, proxy2, proxy3])
        proxy = rotator.next()
        proxy_url = proxy.url
    """

    def __init__(
        self,
        proxies: list[ProxyInfo] | None = None,
        shuffle: bool = True,
    ):
        if not proxies:
            raise ValueError(
                "No proxies provided. Supply a list of ProxyInfo objects "
                "or set the GOV_COLLECTOR_PROXY environment variable."
            )

        self._proxies = list(proxies)

        if shuffle:
            # Shuffle within same priority groups
            random.shuffle(self._proxies)
            self._proxies.sort(key=lambda p: p.priority)

        self._cycle = itertools.cycle(self._proxies)

    def next(self) -> ProxyInfo:
        """Get the next proxy in rotation."""
        return next(self._cycle)

    def get_url(self) -> str:
        """Get the next proxy URL."""
        return self.next().url

    @property
    def first(self) -> ProxyInfo:
        """Get the first (highest priority) proxy without advancing."""
        return self._proxies[0]


def get_default_proxy() -> ProxyInfo | None:
    """
    Get the default proxy from environment variable GOV_COLLECTOR_PROXY.

    Returns None if not configured.
    """
    return proxy_from_env()


def get_proxy_url() -> str | None:
    """
    Get the default proxy URL from environment variable GOV_COLLECTOR_PROXY.

    Returns None if not configured.
    """
    proxy = get_default_proxy()
    return proxy.url if proxy else None
