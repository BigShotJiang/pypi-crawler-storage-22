"""
State collector registry — auto-discovers and manages state modules.
"""

from __future__ import annotations

import importlib
import logging
import pkgutil
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from gov_collector.base import BaseStateCollector, DataCategory
    from gov_collector.models import StateInfo

logger = logging.getLogger(__name__)


class StateRegistry:
    """
    Registry for state collector classes.

    Collectors register themselves using the @StateRegistry.register decorator:

        @StateRegistry.register
        class CaliforniaCollector(BaseStateCollector):
            ...
    """

    _collectors: dict[str, type[BaseStateCollector]] = {}

    @classmethod
    def register(cls, collector_cls: type[BaseStateCollector]) -> type[BaseStateCollector]:
        """
        Register a state collector class.

        Can be used as a decorator:
            @StateRegistry.register
            class CaliforniaCollector(BaseStateCollector):
                ...
        """
        # Instantiate temporarily to get state info
        # We need the state_info property which is on the class
        info = collector_cls.state_info.fget(collector_cls)  # type: ignore[union-attr]

        code = info.code.upper()
        if code in cls._collectors:
            logger.warning(
                "Overwriting existing collector for %s with %s",
                code,
                collector_cls.__name__,
            )
        cls._collectors[code] = collector_cls
        logger.debug("Registered collector: %s (%s)", code, collector_cls.__name__)
        return collector_cls

    @classmethod
    def get(cls, state_code: str) -> type[BaseStateCollector] | None:
        """Get a collector class by state code."""
        cls._ensure_loaded()
        return cls._collectors.get(state_code.upper())

    @classmethod
    def list_states(cls) -> list[StateInfo]:
        """List all registered states and their capabilities."""
        cls._ensure_loaded()
        results = []
        for code, collector_cls in sorted(cls._collectors.items()):
            info = collector_cls.state_info.fget(collector_cls)  # type: ignore[union-attr]
            results.append(info)
        return results

    @classmethod
    def list_by_category(cls, category: DataCategory) -> list[StateInfo]:
        """List states that support a given data category."""
        return [
            info
            for info in cls.list_states()
            if category.value in info.supported_categories
        ]

    @classmethod
    def _ensure_loaded(cls) -> None:
        """Auto-discover and import all state modules."""
        if cls._collectors:
            return
        _discover_state_modules()


def _discover_state_modules() -> None:
    """Import all submodules under gov_collector.states to trigger registration."""
    try:
        import gov_collector.states as states_pkg
    except ImportError:
        logger.warning("gov_collector.states package not found")
        return

    for importer, modname, ispkg in pkgutil.iter_modules(
        states_pkg.__path__, states_pkg.__name__ + "."
    ):
        try:
            importlib.import_module(modname)
            logger.debug("Loaded state module: %s", modname)
        except Exception:
            logger.exception("Failed to load state module: %s", modname)


def get_collector(
    state_code: str,
    *,
    proxy: str | None = None,
    timeout: float = 30.0,
    rate_limit: float = 1.0,
    use_browser: bool = False,
    use_camoufox: bool = False,
) -> BaseStateCollector:
    """
    Convenience function to get an initialized collector instance.

    Usage:
        async with get_collector("CA", use_camoufox=True) as collector:
            async for result in collector.collect(params):
                ...
    """
    cls = StateRegistry.get(state_code)
    if cls is None:
        available = [s.code for s in StateRegistry.list_states()]
        raise ValueError(
            f"No collector for state '{state_code}'. "
            f"Available: {', '.join(available) or 'none'}"
        )
    return cls(
        proxy=proxy,
        timeout=timeout,
        rate_limit=rate_limit,
        use_browser=use_browser,
        use_camoufox=use_camoufox,
    )


def list_states() -> list[StateInfo]:
    """List all available state collectors."""
    return StateRegistry.list_states()
