"""
State-specific collector modules.

Each submodule implements a collector for a single US state.
Collectors auto-register with the StateRegistry when imported.
"""
