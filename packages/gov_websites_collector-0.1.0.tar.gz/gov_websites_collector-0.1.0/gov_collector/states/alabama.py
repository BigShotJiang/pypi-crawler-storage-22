"""
Alabama state collector.

Sources:
- AREC (Alabama Real Estate Commission): Real estate license lookups
  https://arec.alabama.gov/apps/LicenseSearch
- Alabama Secretary of State: Business entity records
  https://www.sos.alabama.gov/government-records/business-entity-records
"""

from __future__ import annotations

import logging
import re
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.exceptions import ParseError, ScrapingError
from gov_collector.models import (
    Address,
    Business,
    CollectorResult,
    EntityStatus,
    EntityType,
    License,
    LicenseStatus,
    Person,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import (
    clean_text,
    extract_table_rows,
    extract_text,
    parse_html,
)
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

# --- AREC (Real Estate) ---

AREC_SEARCH_URL = "https://arec.alabama.gov/apps/LicenseSearch"

# Status mapping for AREC license statuses
AREC_LICENSE_STATUS_MAP: dict[str, LicenseStatus] = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
    "SUSPENDED": LicenseStatus.SUSPENDED,
    "REVOKED": LicenseStatus.REVOKED,
    "CANCELLED": LicenseStatus.CANCELLED,
    "PENDING": LicenseStatus.PENDING,
}

# --- Alabama SOS (Business Entity) ---

AL_SOS_SEARCH_URL = (
    "https://www.sos.alabama.gov/government-records/business-entity-records"
)
# The actual search endpoint (form POST target)
AL_SOS_ENTITY_SEARCH_URL = (
    "https://arc-sos.state.al.us/cgi/corpname.mbr/output"
)

AL_ENTITY_TYPE_MAP: dict[str, EntityType] = {
    "DOMESTIC LIMITED LIABILITY COMPANY": EntityType.LLC,
    "FOREIGN LIMITED LIABILITY COMPANY": EntityType.LLC,
    "DOMESTIC CORPORATION": EntityType.CORPORATION,
    "FOREIGN CORPORATION": EntityType.CORPORATION,
    "DOMESTIC NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "FOREIGN NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "LIMITED PARTNERSHIP": EntityType.LP,
    "LIMITED LIABILITY PARTNERSHIP": EntityType.LLP,
    "GENERAL PARTNERSHIP": EntityType.PARTNERSHIP,
    "SOLE PROPRIETORSHIP": EntityType.SOLE_PROPRIETORSHIP,
}

AL_STATUS_MAP: dict[str, EntityStatus] = {
    "EXISTS": EntityStatus.ACTIVE,
    "ACTIVE": EntityStatus.ACTIVE,
    "DISSOLVED": EntityStatus.DISSOLVED,
    "SUSPENDED": EntityStatus.SUSPENDED,
    "WITHDRAWN": EntityStatus.WITHDRAWN,
    "MERGED": EntityStatus.MERGED,
    "REVOKED": EntityStatus.DISSOLVED,
}


@StateRegistry.register
class AlabamaCollector(BaseStateCollector):
    """Collector for Alabama government data."""

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="AL",
            name="Alabama",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "Alabama Real Estate Commission (AREC)",
                "Alabama Secretary of State",
            ],
        )

    # --- Real Estate Licenses ---

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search Alabama AREC for real estate licenses.

        Supports searching by name or license number.
        """
        if params.license_number:
            async for result in self._arec_search_by_number(params.license_number):
                yield result
            return

        if not params.query:
            raise ValueError(
                "Either 'query' (name) or 'license_number' is required for AL AREC"
            )

        async for result in self._arec_search_by_name(
            params.query, params.max_results
        ):
            yield result

    async def _arec_search_by_name(
        self, name: str, max_results: int = 100
    ) -> AsyncIterator[CollectorResult]:
        """Search AREC by licensee name."""
        parts = name.strip().split(maxsplit=1)
        last_name = parts[0] if parts else name
        first_name = parts[1] if len(parts) > 1 else ""

        form_data = {
            "last_name": last_name,
            "first_name": first_name,
            "license_number": "",
            "Submit": "Search",
        }

        try:
            response = await self.client.post(AREC_SEARCH_URL, data=form_data)
            html = response.text
        except Exception as e:
            logger.error("AREC license search failed: %s", e)
            return

        count = 0
        async for result in self._parse_arec_results(html):
            yield result
            count += 1
            if count >= max_results:
                return

    async def _arec_search_by_number(
        self, license_number: str
    ) -> AsyncIterator[CollectorResult]:
        """Search AREC by license number."""
        form_data = {
            "license_number": license_number,
            "last_name": "",
            "first_name": "",
            "Submit": "Search",
        }

        try:
            response = await self.client.post(AREC_SEARCH_URL, data=form_data)
            html = response.text
        except Exception as e:
            logger.error("AREC license lookup failed: %s", e)
            return

        async for result in self._parse_arec_results(html):
            yield result

    async def _parse_arec_results(
        self, html: str
    ) -> AsyncIterator[CollectorResult]:
        """Parse AREC search results page."""
        tree = parse_html(html)

        rows = tree.css("table tr")
        if not rows:
            logger.debug("No AREC results found")
            return

        for row in rows:
            cells = row.css("td")
            if len(cells) < 4:
                continue

            name_text = extract_text(cells[0])
            license_id = extract_text(cells[1])
            license_type_text = extract_text(cells[2])
            status_text = extract_text(cells[3])

            if not name_text or not license_id:
                continue

            # Map status
            status = LicenseStatus.OTHER
            if status_text:
                status_upper = status_text.upper().strip()
                status = AREC_LICENSE_STATUS_MAP.get(status_upper, LicenseStatus.OTHER)

            # Parse address if available
            address = None
            if len(cells) > 4:
                addr_text = extract_text(cells[4])
                if addr_text:
                    address = Address(raw=addr_text, state="AL")

            license_obj = License(
                license_number=license_id.strip(),
                license_type=license_type_text or "Real Estate",
                status=status,
                state="AL",
                holder_name=name_text.strip(),
                address=address,
                source_url=AREC_SEARCH_URL,
                raw_data={
                    "name": name_text,
                    "license_type": license_type_text,
                    "status_text": status_text,
                },
            )

            yield CollectorResult(
                category=DataCategory.LICENSES.value,
                state="AL",
                data=license_obj,
                source="Alabama Real Estate Commission (AREC)",
            )

    # --- Business Entity Search ---

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search Alabama Secretary of State for business entities.

        Uses the ARC-SOS entity search endpoint.
        """
        if not params.query:
            raise ValueError(
                "'query' (business name) is required for AL business search"
            )

        # Alabama SOS uses a CGI-based search
        form_data = {
            "name": params.query,
            "type": "ALL",
            "status": "ALL",
            "place": "",
            "Submit": "Search",
        }

        try:
            response = await self.client.post(
                AL_SOS_ENTITY_SEARCH_URL, data=form_data
            )
            html = response.text
        except Exception as e:
            logger.error("AL SOS business search failed: %s", e)
            return

        count = 0
        rows = extract_table_rows(html)
        for row in rows:
            if count >= params.max_results:
                return

            business = self._parse_al_sos_record(row)
            if business:
                yield CollectorResult(
                    category=DataCategory.BUSINESSES.value,
                    state="AL",
                    data=business,
                    source="Alabama Secretary of State",
                )
                count += 1

    def _parse_al_sos_record(self, row: dict[str, str]) -> Business | None:
        """Parse a single AL SOS search result row."""
        name = row.get("Entity Name") or row.get("Name", "")
        if not name:
            return None

        # Map entity type
        type_str = (row.get("Entity Type") or row.get("Type") or "").upper()
        entity_type = AL_ENTITY_TYPE_MAP.get(type_str, EntityType.OTHER)

        # Map status
        status_str = (row.get("Status") or "").upper().strip()
        status = AL_STATUS_MAP.get(status_str, EntityStatus.OTHER)

        # Filing number
        filing_number = row.get("Entity ID") or row.get("ID")

        # Formation date
        formation_date = None
        date_str = row.get("Formation Date") or row.get("Date")
        if date_str:
            try:
                from datetime import date as date_cls

                for fmt in ("%m/%d/%Y", "%Y-%m-%d"):
                    try:
                        formation_date = date_cls(
                            *map(int, date_cls.strftime(
                                date_cls.today(), fmt
                            ).split("/"))
                        )
                    except (ValueError, AttributeError):
                        continue
                # Simple parse
                parts = re.split(r"[/\-]", date_str)
                if len(parts) == 3:
                    from datetime import date as d

                    if len(parts[0]) == 4:
                        formation_date = d(int(parts[0]), int(parts[1]), int(parts[2]))
                    else:
                        formation_date = d(int(parts[2]), int(parts[0]), int(parts[1]))
            except Exception:
                pass

        # Agent
        agent_name = row.get("Registered Agent") or row.get("Agent")
        agent = Person(full_name=agent_name) if agent_name else None

        return Business(
            name=name.strip(),
            entity_type=entity_type,
            status=status,
            state="AL",
            filing_number=filing_number,
            formation_date=formation_date,
            registered_agent=agent,
            source_url=AL_SOS_SEARCH_URL,
            raw_data=row,
        )
