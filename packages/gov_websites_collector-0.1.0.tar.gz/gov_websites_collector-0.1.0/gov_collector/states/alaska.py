"""
Alaska state collector.

Sources:
- CBPL (Commerce, Business & Professional Licensing): Professional license data
  https://www.commerce.alaska.gov/cbp/main/DbDownload/ProfessionalLicenseDownload
- Alaska DCCED: Business entity data
  https://www.commerce.alaska.gov/cbp/main/DbDownload/CorporationsDownload

NOTE: The Alaska CBP search pages require Google reCAPTCHA. We use the
freely available CSV database downloads instead, which don't require captcha.
These CSVs contain the full database and are updated regularly by the state.
"""

from __future__ import annotations

import csv
import io
import logging
import re
from datetime import date
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.models import (
    Address,
    Business,
    CollectorResult,
    EntityStatus,
    EntityType,
    License,
    LicenseStatus,
    Person,
    SearchParams,
    StateInfo,
)
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

# CSV download URLs (no captcha required)
AK_CORP_CSV_URL = (
    "https://www.commerce.alaska.gov/cbp/main/DbDownload/CorporationsDownload"
)
AK_LIC_CSV_URL = (
    "https://www.commerce.alaska.gov/cbp/main/DbDownload/ProfessionalLicenseDownload"
)

# Web search URLs (for source_url references)
AK_BIZ_SEARCH_URL = (
    "https://www.commerce.alaska.gov/cbp/main/search/entities"
)
AK_LIC_SEARCH_URL = (
    "https://www.commerce.alaska.gov/cbp/main/search/professional"
)

AK_LICENSE_STATUS_MAP: dict[str, LicenseStatus] = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
    "SUSPENDED": LicenseStatus.SUSPENDED,
    "REVOKED": LicenseStatus.REVOKED,
    "CANCELLED": LicenseStatus.CANCELLED,
    "LAPSED": LicenseStatus.EXPIRED,
}

AK_ENTITY_TYPE_MAP: dict[str, EntityType] = {
    "LIMITED LIABILITY COMPANY": EntityType.LLC,
    "CORPORATION": EntityType.CORPORATION,
    "NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "LIMITED PARTNERSHIP": EntityType.LP,
    "LIMITED LIABILITY PARTNERSHIP": EntityType.LLP,
    "GENERAL PARTNERSHIP": EntityType.PARTNERSHIP,
    "BUSINESS TRUST": EntityType.TRUST,
    "SOLE PROPRIETORSHIP": EntityType.SOLE_PROPRIETORSHIP,
    "BUSINESS NAME REGISTRATION": EntityType.OTHER,
}

AK_STATUS_MAP: dict[str, EntityStatus] = {
    "GOOD STANDING": EntityStatus.ACTIVE,
    "ACTIVE": EntityStatus.ACTIVE,
    "ACTIVE NAME": EntityStatus.ACTIVE,
    "NONCOMPLIANT": EntityStatus.ACTIVE,
    "DISSOLVED": EntityStatus.DISSOLVED,
    "REVOKED": EntityStatus.DISSOLVED,
    "CANCELLED": EntityStatus.DISSOLVED,
    "WITHDRAWN": EntityStatus.WITHDRAWN,
    "MERGED": EntityStatus.MERGED,
    "INACTIVE": EntityStatus.INACTIVE,
}


def _parse_date(text: str | None) -> date | None:
    """Parse a date string like '5/30/2001' or '2001-05-30'."""
    if not text or text.strip().lower() in ("", "perpetual"):
        return None
    text = text.strip()
    try:
        parts = re.split(r"[/\-]", text)
        if len(parts) == 3:
            if len(parts[0]) == 4:
                return date(int(parts[0]), int(parts[1]), int(parts[2]))
            else:
                return date(int(parts[2]), int(parts[0]), int(parts[1]))
    except (ValueError, IndexError):
        pass
    return None


@StateRegistry.register
class AlaskaCollector(BaseStateCollector):
    """Collector for Alaska government data using CSV database downloads.

    The Alaska CBPL search pages require Google reCAPTCHA, so we use the
    free CSV database download endpoints instead. These provide the full
    database of corporations and professional licenses.

    CSV endpoints:
    - Corporations: /cbp/main/DbDownload/CorporationsDownload (~41MB)
    - Professional Licenses: /cbp/main/DbDownload/ProfessionalLicenseDownload (~15MB)
    """

    # No browser needed — we use CSV downloads
    needs_browser_for: list[DataCategory] = []

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="AK",
            name="Alaska",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "Alaska CBPL Professional License Database (CSV)",
                "Alaska DCCED Corporations Database (CSV)",
            ],
            notes=(
                "Uses CSV database downloads instead of web scraping. "
                "Search pages require reCAPTCHA."
            ),
        )

    # --- Professional Licenses ---

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search Alaska professional licenses via CSV database download.

        CSV columns: Program, ProfType, LicenseNum, DBA, Owners, Status,
        DateIssued, DateEffective, DateExpired, ADDRESS1, ADDRESS2, CITY, STATE, ZIP
        """
        if not params.query and not params.license_number:
            raise ValueError(
                "Either 'query' (name) or 'license_number' is required for AK license search"
            )

        query = (params.query or "").upper()
        lic_num = (params.license_number or "").upper()

        logger.info(
            "AK: Downloading professional license database CSV (%s)...",
            "~15MB",
        )

        try:
            response = await self.client.get(AK_LIC_CSV_URL)
            if response.status_code != 200:
                logger.error(
                    "AK license CSV download failed: HTTP %d", response.status_code
                )
                return
        except Exception as e:
            logger.error("AK license CSV download failed: %s", e)
            return

        reader = csv.DictReader(io.StringIO(response.text))
        count = 0

        for row in reader:
            if count >= params.max_results:
                break

            # Filter by license number
            if lic_num:
                row_lic = (row.get("LicenseNum") or "").upper()
                if lic_num not in row_lic:
                    continue
            # Filter by name (check Owners and DBA)
            elif query:
                owners = (row.get("Owners") or "").upper()
                dba = (row.get("DBA") or "").upper()
                if query not in owners and query not in dba:
                    continue

            # Filter by license type if specified
            if params.license_type:
                lt = params.license_type.upper()
                prog = (row.get("Program") or "").upper()
                prof_type = (row.get("ProfType") or "").upper()
                if lt not in prog and lt not in prof_type:
                    continue

            # Parse the record
            status_text = (row.get("Status") or "").strip()
            status = AK_LICENSE_STATUS_MAP.get(
                status_text.upper(), LicenseStatus.OTHER
            )

            # Build address
            addr = None
            addr1 = row.get("ADDRESS1")
            city = row.get("CITY")
            if addr1 or city:
                addr = Address(
                    street=addr1,
                    street2=row.get("ADDRESS2"),
                    city=city,
                    state=row.get("STATE"),
                    zip_code=row.get("ZIP"),
                )

            license_obj = License(
                license_number=(row.get("LicenseNum") or "").strip() or "N/A",
                license_type=f"{row.get('Program', '')} - {row.get('ProfType', '')}".strip(" -"),
                status=status,
                state="AK",
                holder_name=(row.get("Owners") or "").strip(),
                business_name=(row.get("DBA") or "").strip() or None,
                address=addr,
                issue_date=_parse_date(row.get("DateIssued")),
                expiration_date=_parse_date(row.get("DateExpired")),
                source_url=AK_LIC_SEARCH_URL,
                raw_data=dict(row),
            )

            yield CollectorResult(
                category=DataCategory.LICENSES.value,
                state="AK",
                data=license_obj,
                source="Alaska CBPL (CSV Download)",
            )
            count += 1

        logger.info("AK license search: returned %d results", count)

    # --- Business Entity Search ---

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search Alaska business entities via CSV database download.

        CSV columns: CORPTYPE, ENTITYNUMBER, LEGALNAME, ASSUMEDNAME, STATUS,
        AKFORMEDDATE, DURATIONEXPIRATIONDATE, HOMESTATE, HOMECOUNTRY,
        NEXTBRDUEDATE, REGISTEREDAGENT, ENTITYMAILINGADDRESS1, ...
        """
        if not params.query:
            raise ValueError(
                "'query' (business name) is required for AK business search"
            )

        query = params.query.upper()

        logger.info(
            "AK: Downloading corporations database CSV (%s)...",
            "~41MB",
        )

        try:
            response = await self.client.get(AK_CORP_CSV_URL)
            if response.status_code != 200:
                logger.error(
                    "AK corps CSV download failed: HTTP %d", response.status_code
                )
                return
        except Exception as e:
            logger.error("AK corps CSV download failed: %s", e)
            return

        reader = csv.DictReader(io.StringIO(response.text))
        count = 0

        for row in reader:
            if count >= params.max_results:
                break

            # Filter by name (check LEGALNAME and ASSUMEDNAME)
            legal_name = (row.get("LEGALNAME") or "").upper()
            assumed_name = (row.get("ASSUMEDNAME") or "").upper()
            if query not in legal_name and query not in assumed_name:
                continue

            # Filter by entity type if specified
            if params.entity_type:
                row_type = (row.get("CORPTYPE") or "").upper()
                if params.entity_type.value.upper() not in row_type:
                    continue

            # Parse the record
            type_str = (row.get("CORPTYPE") or "").upper()
            entity_type = AK_ENTITY_TYPE_MAP.get(type_str, EntityType.OTHER)

            status_str = (row.get("STATUS") or "").upper().strip()
            status = AK_STATUS_MAP.get(status_str, EntityStatus.OTHER)

            agent_name = row.get("REGISTEREDAGENT")
            agent = Person(full_name=agent_name) if agent_name else None

            # Build address from entity mailing address fields
            # CSV has: ENTITYMAILINGADDRESS1, ENTITYMAILINGADDRESS2(?),
            # then CITY, STATE, ZIP, COUNTRY fields
            addr = None
            addr1 = row.get("ENTITYMAILINGADDRESS1")
            if addr1:
                # Column names vary; try common patterns
                addr = Address(
                    street=addr1,
                    street2=row.get("ENTITYMAILINGADDRESS2"),
                    raw=addr1,
                )

            name = (row.get("LEGALNAME") or "").strip()
            business = Business(
                name=name,
                entity_type=entity_type,
                status=status,
                state="AK",
                filing_number=row.get("ENTITYNUMBER"),
                formation_date=_parse_date(row.get("AKFORMEDDATE")),
                registered_agent=agent,
                address=addr,
                source_url=AK_BIZ_SEARCH_URL,
                raw_data=dict(row),
            )

            yield CollectorResult(
                category=DataCategory.BUSINESSES.value,
                state="AK",
                data=business,
                source="Alaska DCCED (CSV Download)",
            )
            count += 1

        logger.info("AK business search: returned %d results", count)
