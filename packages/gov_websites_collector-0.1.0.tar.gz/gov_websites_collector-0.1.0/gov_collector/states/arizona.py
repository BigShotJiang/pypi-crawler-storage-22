"""
Arizona state collector.

Sources:
- ADRE (Arizona Department of Real Estate): Real estate license lookups
  https://services.azre.gov/PdbWeb/IndividualLicense/SearchIndividualLicenses
  HTTP POST with anti-forgery token. Returns HTML table.
- Arizona Corporation Commission (ACC): Business entity search
  https://ecorp.azcc.gov/EntitySearch/Index
  Angular SPA — needs browser automation (blocks HTTP).

Strategy:
- Licenses: HTTP POST (confirmed working)
- Businesses: Browser required (ACC blocks non-browser requests)
"""

from __future__ import annotations

import logging
import re
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.models import (
    Business,
    CollectorResult,
    EntityStatus,
    EntityType,
    License,
    LicenseStatus,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import clean_text, extract_text, parse_html
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

# --- ADRE (Real Estate) ---

ADRE_SEARCH_URL = "https://services.azre.gov/PdbWeb/IndividualLicense/SearchIndividualLicenses"

AZ_LICENSE_STATUS_MAP = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
    "SUSPENDED": LicenseStatus.SUSPENDED,
    "REVOKED": LicenseStatus.REVOKED,
    "CANCELLED": LicenseStatus.CANCELLED,
    "PENDING": LicenseStatus.PENDING,
}

# --- Arizona Corporation Commission ---

AZ_ACC_SEARCH_URL = "https://ecorp.azcc.gov/EntitySearch/Index"

AZ_ENTITY_TYPE_MAP = {
    "DOMESTIC LIMITED LIABILITY COMPANY": EntityType.LLC,
    "FOREIGN LIMITED LIABILITY COMPANY": EntityType.LLC,
    "LIMITED LIABILITY COMPANY": EntityType.LLC,
    "LLC": EntityType.LLC,
    "DOMESTIC CORPORATION": EntityType.CORPORATION,
    "FOREIGN CORPORATION": EntityType.CORPORATION,
    "CORPORATION": EntityType.CORPORATION,
    "NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "NON-PROFIT CORPORATION": EntityType.NONPROFIT,
    "LIMITED PARTNERSHIP": EntityType.LP,
    "GENERAL PARTNERSHIP": EntityType.PARTNERSHIP,
}

AZ_STATUS_MAP = {
    "ACTIVE": EntityStatus.ACTIVE,
    "GOOD STANDING": EntityStatus.ACTIVE,
    "INACTIVE": EntityStatus.INACTIVE,
    "DISSOLVED": EntityStatus.DISSOLVED,
    "SUSPENDED": EntityStatus.SUSPENDED,
    "WITHDRAWN": EntityStatus.WITHDRAWN,
    "MERGED": EntityStatus.MERGED,
    "CANCELLED": EntityStatus.DISSOLVED,
}


@StateRegistry.register
class ArizonaCollector(BaseStateCollector):
    """Collector for Arizona government data."""

    needs_browser_for = [DataCategory.BUSINESSES]

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="AZ",
            name="Arizona",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "Arizona Department of Real Estate (ADRE)",
                "Arizona Corporation Commission (ACC)",
            ],
            notes="Licenses via HTTP POST; businesses require Camoufox browser.",
        )

    # --- Licenses: HTTP POST approach (confirmed working) ---

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search Arizona ADRE for real estate licenses via HTTP POST.

        The form uses an anti-forgery token. Fields:
        - LastName, FirstName, LicenseNo, City, Zip, County
        - LicenseStatusId (1=Active), LicenseTypeId (1=All)
        - __RequestVerificationToken
        """
        if not params.query and not params.license_number:
            logger.warning("AZ ADRE: query or license_number is required")
            return

        count = 0
        max_results = params.max_results

        try:
            # Step 1: GET the form page to extract anti-forgery token
            page_resp = await self.client.get(ADRE_SEARCH_URL)
            page_html = page_resp.text
            token_match = re.search(
                r'name="__RequestVerificationToken"[^>]*value="([^"]*)"',
                page_html,
            )

            # Step 2: Build POST data
            form_data = {
                "LicenseStatusId": "1",  # Active
                "LicenseTypeId": "1",  # All types
            }
            if token_match:
                form_data["__RequestVerificationToken"] = token_match.group(1)

            if params.license_number:
                form_data["LicenseNo"] = params.license_number
            elif params.query:
                parts = params.query.strip().split(maxsplit=1)
                form_data["LastName"] = parts[0]
                if len(parts) > 1:
                    form_data["FirstName"] = parts[1]

            # Step 3: POST the search
            response = await self.client.post(ADRE_SEARCH_URL, data=form_data)
            html = response.text

        except Exception as e:
            logger.error("AZ ADRE license search failed: %s", e)
            return

        # Step 4: Parse the results table
        # Table headers: [checkbox, License No, Name, Status, Employer Name, Employer City, Employer Zip]
        tree = parse_html(html)
        table = tree.css_first("table")
        if not table:
            logger.debug("AZ ADRE: no results table found")
            return

        rows = table.css("tr")
        for row in rows:
            if count >= max_results:
                break

            cells = row.css("td")
            if len(cells) < 4:
                continue

            # Columns: [View checkbox, License No, Name, Status, Employer, City, Zip]
            license_num = extract_text(cells[1])
            name = extract_text(cells[2])
            status_text = extract_text(cells[3])
            employer = extract_text(cells[4]) if len(cells) > 4 else None
            city = extract_text(cells[5]) if len(cells) > 5 else None
            zip_code = extract_text(cells[6]) if len(cells) > 6 else None

            if not license_num or not name:
                continue
            # Skip header rows
            if "license" in license_num.lower():
                continue

            status = LicenseStatus.ACTIVE
            if status_text:
                status = AZ_LICENSE_STATUS_MAP.get(
                    status_text.upper().strip(), LicenseStatus.OTHER
                )

            license_obj = License(
                license_number=license_num.strip(),
                license_type="Real Estate",
                status=status,
                state="AZ",
                holder_name=name.strip(),
                business_name=employer.strip() if employer else None,
                source_url=ADRE_SEARCH_URL,
                raw_data={
                    "status_text": status_text,
                    "employer": employer,
                    "city": city,
                    "zip": zip_code,
                },
            )

            yield CollectorResult(
                category=DataCategory.LICENSES.value,
                state="AZ",
                data=license_obj,
                source="Arizona Department of Real Estate (ADRE)",
            )
            count += 1

        logger.info("AZ ADRE: returned %d license results", count)

    # --- Businesses: Browser required (ACC is Angular SPA) ---

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search Arizona Corporation Commission for business entities.
        Requires Camoufox browser (ACC site blocks HTTP requests).
        """
        if not params.query:
            logger.warning("AZ ACC: query (business name) is required")
            return

        if not self.has_browser:
            logger.warning(
                "AZ ACC requires browser automation. "
                "Initialize with use_camoufox=True."
            )
            return

        try:
            page = await self.browser.new_page()
        except Exception as e:
            logger.error("AZ ACC: failed to create browser page: %s", e)
            return

        count = 0
        max_results = params.max_results

        try:
            await page.goto(
                AZ_ACC_SEARCH_URL,
                wait_until="domcontentloaded",
                timeout=30000,
            )

            # Fill in entity name search
            name_input = await page.query_selector(
                'input[name="EntityName"], input#EntityName, input[placeholder*="name"]'
            )
            if name_input:
                await name_input.fill(params.query)

            # Submit search
            submit_button = await page.query_selector(
                'input[type="submit"], button[type="submit"], button:has-text("Search")'
            )
            if submit_button:
                await submit_button.click()
            else:
                await page.keyboard.press("Enter")

            # Wait for results
            await page.wait_for_load_state("domcontentloaded", timeout=15000)

            import asyncio
            await asyncio.sleep(3)  # Wait for Angular to render

            html = await page.content()
            tree = parse_html(html)

            rows = tree.css("table tr, .search-results tr")
            for row in rows:
                if count >= max_results:
                    break

                cells = row.css("td")
                if len(cells) < 2:
                    continue

                name = extract_text(cells[0])
                if not name or "entity" in name.lower():
                    continue

                entity_id = extract_text(cells[1]) if len(cells) > 1 else None
                entity_type_text = extract_text(cells[2]) if len(cells) > 2 else None
                status_text = extract_text(cells[3]) if len(cells) > 3 else None

                entity_type = AZ_ENTITY_TYPE_MAP.get(
                    (entity_type_text or "").upper().strip(), EntityType.OTHER
                )
                status = AZ_STATUS_MAP.get(
                    (status_text or "").upper().strip(), EntityStatus.OTHER
                )

                business = Business(
                    name=name.strip(),
                    entity_type=entity_type,
                    status=status,
                    state="AZ",
                    filing_number=entity_id,
                    source_url=AZ_ACC_SEARCH_URL,
                    raw_data={
                        "entity_type_text": entity_type_text,
                        "status_text": status_text,
                    },
                )

                yield CollectorResult(
                    category=DataCategory.BUSINESSES.value,
                    state="AZ",
                    data=business,
                    source="Arizona Corporation Commission (ACC)",
                )
                count += 1

            logger.info("AZ ACC: returned %d business results", count)

        except Exception as e:
            logger.error("AZ ACC browser search failed: %s", e)
        finally:
            await page.close()
