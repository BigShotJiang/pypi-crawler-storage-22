"""
Arkansas state collector.

Sources:
- AREC (Arkansas Real Estate Commission): NO PUBLIC SEARCH AVAILABLE  
  https://www.arec.arkansas.gov/licensee-search/ - returns 404
  https://www.arec.arkansas.gov/roster-search/ - returns 404
- Arkansas Secretary of State: Business entity search (WORKING)
  https://www.ark.org/corp-search/index.php

SCAN RESULTS: AREC 404, SOS working with form fields
"""

from __future__ import annotations

import logging
import re
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.exceptions import ParseError, ScrapingError
from gov_collector.models import (
    Address,
    Business,
    CollectorResult,
    EntityStatus,
    EntityType,
    License,
    LicenseStatus,
    Person,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import (
    clean_text,
    extract_table_rows,
    extract_text,
    parse_html,
)
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

# --- AREC (Real Estate) ---

AREC_SEARCH_URL = "https://www.arec.arkansas.gov/licensee-search/"

AR_LICENSE_STATUS_MAP: dict[str, LicenseStatus] = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
    "SUSPENDED": LicenseStatus.SUSPENDED,
    "REVOKED": LicenseStatus.REVOKED,
    "CANCELLED": LicenseStatus.CANCELLED,
    "PENDING": LicenseStatus.PENDING,
}

AR_LICENSE_TYPES: dict[str, str] = {
    "EBR": "Executive Broker",
    "PBR": "Principal Broker",
    "ABR": "Associate Broker",
    "SAL": "Salesperson",
    "PM": "Property Manager",
}

# --- Arkansas SOS (Business Entity) ---

AR_SOS_SEARCH_URL = "https://www.ark.org/corp-search/index.php"

AR_ENTITY_TYPE_MAP: dict[str, EntityType] = {
    "DOMESTIC LLC": EntityType.LLC,
    "FOREIGN LLC": EntityType.LLC,
    "DOMESTIC FOR PROFIT": EntityType.CORPORATION,
    "FOREIGN FOR PROFIT": EntityType.CORPORATION,
    "DOMESTIC NONPROFIT": EntityType.NONPROFIT,
    "FOREIGN NONPROFIT": EntityType.NONPROFIT,
    "DOMESTIC LIMITED PARTNERSHIP": EntityType.LP,
    "FOREIGN LIMITED PARTNERSHIP": EntityType.LP,
    "LIMITED LIABILITY PARTNERSHIP": EntityType.LLP,
    "GENERAL PARTNERSHIP": EntityType.PARTNERSHIP,
}

AR_STATUS_MAP: dict[str, EntityStatus] = {
    "ACTIVE": EntityStatus.ACTIVE,
    "GOOD STANDING": EntityStatus.ACTIVE,
    "REVOKED": EntityStatus.DISSOLVED,
    "DISSOLVED": EntityStatus.DISSOLVED,
    "WITHDRAWN": EntityStatus.WITHDRAWN,
    "SUSPENDED": EntityStatus.SUSPENDED,
    "INACTIVE": EntityStatus.INACTIVE,
    "MERGED": EntityStatus.MERGED,
}


@StateRegistry.register
class ArkansasCollector(BaseStateCollector):
    """Collector for Arkansas government data."""

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="AR",
            name="Arkansas",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            notes="AR SOS uses reCAPTCHA. Automated access requires CAPTCHA solving.",
            sources=[
                "Arkansas Real Estate Commission (AREC)",
                "Arkansas Secretary of State",
            ],
        )

    # --- Real Estate Licenses ---

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Arkansas Real Estate Commission license search.
        
        The main AREC site is accessible, but specific license search URLs
        like /licensee-search/ and /roster-search/ return 404. Need to find
        the current public license search functionality if available.
        """
        if not params.query:
            logger.warning("AR AREC: query (licensee name) is required")
            return
            yield  # type: ignore[misc]  # Make this an async generator
            
        logger.warning(
            "AR AREC: Public license search URLs return 404. "
            "License search not currently accessible."
        )
        return
        yield  # type: ignore[misc]

    async def _parse_arec_results(
        self, html: str
    ) -> AsyncIterator[CollectorResult]:
        """Parse AR AREC search results page."""
        tree = parse_html(html)

        rows = tree.css("table tr")
        if not rows:
            logger.debug("No AR AREC results found")
            return

        for row in rows:
            cells = row.css("td")
            if len(cells) < 4:
                continue

            name_text = extract_text(cells[0])
            license_id = extract_text(cells[1])
            license_type_code = extract_text(cells[2])
            status_text = extract_text(cells[3])

            if not name_text or not license_id:
                continue

            status = LicenseStatus.OTHER
            if status_text:
                status_upper = status_text.upper().strip()
                status = AR_LICENSE_STATUS_MAP.get(
                    status_upper, LicenseStatus.OTHER
                )

            license_type = AR_LICENSE_TYPES.get(
                (license_type_code or "").strip().upper(),
                license_type_code or "Real Estate",
            )

            # Address
            address = None
            if len(cells) > 4:
                addr_text = extract_text(cells[4])
                if addr_text:
                    address = Address(raw=addr_text, state="AR")

            # Expiration date
            expiration_date = None
            if len(cells) > 5:
                exp_text = extract_text(cells[5])
                if exp_text:
                    try:
                        parts = re.split(r"[/\-]", exp_text.strip())
                        if len(parts) == 3:
                            from datetime import date as d

                            if len(parts[0]) == 4:
                                expiration_date = d(
                                    int(parts[0]), int(parts[1]), int(parts[2])
                                )
                            else:
                                expiration_date = d(
                                    int(parts[2]), int(parts[0]), int(parts[1])
                                )
                    except (ValueError, IndexError):
                        pass

            license_obj = License(
                license_number=license_id.strip(),
                license_type=license_type,
                status=status,
                state="AR",
                holder_name=name_text.strip(),
                address=address,
                expiration_date=expiration_date,
                source_url=AREC_SEARCH_URL,
                raw_data={
                    "name": name_text,
                    "license_type_code": license_type_code,
                    "status_text": status_text,
                },
            )

            yield CollectorResult(
                category=DataCategory.LICENSES.value,
                state="AR",
                data=license_obj,
                source="Arkansas Real Estate Commission (AREC)",
            )

    # --- Business Entity Search ---

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search Arkansas Secretary of State for business entities.

        Uses the ark.org corp-search PHP interface with form fields:
        - Corporation Type, Enter Either Name, OR Fictitious Name
        - Registered Agent (RA), RA City, RA State, Filing #
        """
        if not params.query:
            raise ValueError(
                "'query' (business name) is required for AR business search"
            )

        # Arkansas SOS form fields based on live site inspection
        form_data = {
            "corpType": "",  # Corporation Type dropdown
            "eitherName": params.query,  # Enter Either Name field
            "fictName": "",  # OR Fictitious Name field  
            "regAgent": "",  # Registered Agent (RA)
            "raCity": "",  # RA City
            "raState": "",  # RA State
            "filingNo": "",  # Filing #
        }

        try:
            response = await self.client.post(AR_SOS_SEARCH_URL, data=form_data)
            html = response.text
        except Exception as e:
            logger.error("AR SOS business search failed: %s", e)
            return

        count = 0
        rows = extract_table_rows(html)
        for row in rows:
            if count >= params.max_results:
                return

            business = self._parse_ar_sos_record(row)
            if business:
                yield CollectorResult(
                    category=DataCategory.BUSINESSES.value,
                    state="AR",
                    data=business,
                    source="Arkansas Secretary of State",
                )
                count += 1

    def _parse_ar_sos_record(self, row: dict[str, str]) -> Business | None:
        """Parse a single AR SOS search result row."""
        name = row.get("Filing Name") or row.get("Entity Name") or row.get("Name", "")
        if not name:
            return None

        type_str = (row.get("Filing Type") or row.get("Type") or "").upper()
        entity_type = AR_ENTITY_TYPE_MAP.get(type_str, EntityType.OTHER)

        status_str = (row.get("Status") or "").upper().strip()
        status = AR_STATUS_MAP.get(status_str, EntityStatus.OTHER)

        filing_number = row.get("Filing Number") or row.get("File Number")

        # Formation date
        formation_date = None
        date_str = row.get("Filing Date") or row.get("Date Filed")
        if date_str:
            try:
                parts = re.split(r"[/\-]", date_str.strip())
                if len(parts) == 3:
                    from datetime import date as d

                    if len(parts[0]) == 4:
                        formation_date = d(
                            int(parts[0]), int(parts[1]), int(parts[2])
                        )
                    else:
                        formation_date = d(
                            int(parts[2]), int(parts[0]), int(parts[1])
                        )
            except (ValueError, IndexError):
                pass

        agent_name = row.get("Registered Agent") or row.get("Agent")
        agent = Person(full_name=agent_name) if agent_name else None

        return Business(
            name=name.strip(),
            entity_type=entity_type,
            status=status,
            state="AR",
            filing_number=filing_number,
            formation_date=formation_date,
            registered_agent=agent,
            source_url=AR_SOS_SEARCH_URL,
            raw_data=row,
        )
