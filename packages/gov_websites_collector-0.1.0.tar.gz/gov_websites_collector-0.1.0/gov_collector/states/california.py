"""
California state collector.

Sources:
- DRE (Department of Real Estate): Real estate license lookups
  https://www2.dre.ca.gov/PublicASP/pplinfo.asp
  Form fields: LICENSEE_NAME, CITY_STATE, LICENSE_ID
  Action: pplinfo.asp?start=1
  Returns server-rendered HTML table with results.

- bizfile Online (Secretary of State): Business entity search
  https://bizfileonline.sos.ca.gov/search/business
  NOTE: bizfile is a JavaScript SPA. HTTP scraping returns no data.
  Needs browser or the official CA SOS API (calicodev.sos.ca.gov, requires subscription).
"""

from __future__ import annotations

import logging
import re
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.models import (
    Address,
    Business,
    CollectorResult,
    EntityType,
    License,
    LicenseStatus,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import parse_html, extract_text
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

DRE_BASE_URL = "https://www2.dre.ca.gov/PublicASP/pplinfo.asp"
DRE_SEARCH_URL = "https://www2.dre.ca.gov/PublicASP/pplinfo.asp?start=1"

# DRE license type abbreviations (from result table column 3)
DRE_LICENSE_TYPES = {
    "salesperson": "Real Estate Salesperson",
    "broker": "Real Estate Broker",
    "corporation": "Corporation License",
    "officer": "Corporation Officer",
}


@StateRegistry.register
class CaliforniaCollector(BaseStateCollector):
    """Collector for California government data.
    
    DRE license search: fully functional via HTTP.
    Business entity search: requires browser (JavaScript SPA) or CA SOS API key.
    """

    needs_browser_for = [DataCategory.BUSINESSES]

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="CA",
            name="California",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "California Department of Real Estate (DRE)",
                "California Secretary of State (bizfile Online)",
            ],
            notes="Business search requires browser or CA SOS API subscription.",
        )

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search California DRE for real estate licenses.
        
        Tested and verified against live site. Returns server-rendered HTML.
        Form fields: LICENSEE_NAME, LICENSE_ID, CITY_STATE
        """
        form_data = {"B2": "Search for this person"}
        
        if params.license_number:
            form_data["LICENSE_ID"] = params.license_number
            form_data["LICENSEE_NAME"] = ""
            form_data["CITY_STATE"] = ""
        elif params.query:
            form_data["LICENSEE_NAME"] = params.query
            form_data["LICENSE_ID"] = ""
            form_data["CITY_STATE"] = ""
            if params.city:
                form_data["CITY_STATE"] = params.city
        else:
            raise ValueError("Either 'query' (name) or 'license_number' is required for CA DRE")

        try:
            response = await self.client.post(DRE_SEARCH_URL, data=form_data)
            html = response.text
        except Exception as e:
            logger.error("CA DRE search failed: %s", e)
            return

        tree = parse_html(html)
        
        # DRE returns results in a single <table> with rows like:
        # <tr>
        #   <td>LICENSE_NUMBER</td>
        #   <td>NAME</td>
        #   <td>TYPE</td>
        #   <td>CITY</td>
        #   <td>&nbsp; or STATUS</td>
        # </tr>
        rows = tree.css("table tr")
        
        count = 0
        for row in rows:
            if count >= params.max_results:
                return
            
            cells = row.css("td")
            if len(cells) < 4:
                continue
            
            license_num = extract_text(cells[0])
            name = extract_text(cells[1])
            license_type_raw = extract_text(cells[2])
            city = extract_text(cells[3])
            status_raw = extract_text(cells[4]) if len(cells) > 4 else None
            
            # Skip empty/header rows
            if not license_num or not name:
                continue
            if license_num.lower().startswith("license"):
                continue
            
            # Map license type
            license_type = "Real Estate"
            if license_type_raw:
                lt_lower = license_type_raw.strip().lower()
                license_type = DRE_LICENSE_TYPES.get(lt_lower, license_type_raw.strip())
            
            # Status — DRE uses the 5th column but often it's &nbsp;
            # Active licenses typically don't show a status
            status = LicenseStatus.ACTIVE
            if status_raw and status_raw.strip() and status_raw.strip() != "\xa0":
                s_upper = status_raw.strip().upper()
                if "EXPIRED" in s_upper:
                    status = LicenseStatus.EXPIRED
                elif "REVOKED" in s_upper:
                    status = LicenseStatus.REVOKED
                elif "SUSPENDED" in s_upper:
                    status = LicenseStatus.SUSPENDED
                elif "INACTIVE" in s_upper:
                    status = LicenseStatus.INACTIVE
                elif "CANCELLED" in s_upper or "CANCELED" in s_upper:
                    status = LicenseStatus.CANCELLED
            
            address = Address(city=city, state="CA") if city else None

            license_obj = License(
                license_number=license_num.strip(),
                license_type=license_type,
                status=status,
                state="CA",
                holder_name=name.strip(),
                address=address,
                source_url=DRE_BASE_URL,
            )

            yield CollectorResult(
                category=DataCategory.LICENSES.value,
                state="CA",
                data=license_obj,
                source="California DRE",
            )
            count += 1

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        California business entity search.
        
        NOTE: bizfile Online is a JavaScript SPA — results are not in the initial HTML.
        This method will log a warning. Use browser-based scraping or the CA SOS API
        (https://calicodev.sos.ca.gov/) for actual results.
        """
        logger.warning(
            "CA bizfile Online is a JavaScript SPA. HTTP scraping will not return results. "
            "Use a browser backend or the CA SOS API (calicodev.sos.ca.gov) instead."
        )
        # Return nothing from HTTP - needs browser
        return
        yield  # Make it a generator
