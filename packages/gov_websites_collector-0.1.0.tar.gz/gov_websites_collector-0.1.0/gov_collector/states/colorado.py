"""
Colorado state collector.

Sources:
- DORA (Department of Regulatory Agencies): Professional license lookup
  https://apps.colorado.gov/dora/licensing/Lookup/LicenseLookup.aspx
- Colorado Secretary of State: Business entity search
  https://www.sos.state.co.us/biz/BusinessEntitySearchCriteria.do

Strategy: HTTP approach for both sources
- DORA uses ASP.NET forms that can work with HTTP
- SOS business search uses form submission
"""

from __future__ import annotations

import logging
import re
from datetime import date as date_cls
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.models import (
    Address,
    Business,
    CollectorResult,
    EntityStatus,
    EntityType,
    License,
    LicenseStatus,
    Person,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import (
    clean_text,
    extract_text,
    parse_html,
    parse_address_text,
)
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

# --- Colorado DORA (License Lookup) ---

CO_DORA_LOOKUP_URL = "https://apps.colorado.gov/dora/licensing/Lookup/LicenseLookup.aspx"

CO_LICENSE_STATUS_MAP = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "CURRENT": LicenseStatus.ACTIVE,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
    "SUSPENDED": LicenseStatus.SUSPENDED,
    "REVOKED": LicenseStatus.REVOKED,
    "CANCELLED": LicenseStatus.CANCELLED,
}

# --- Colorado SOS (Business Entity) ---

CO_SOS_SEARCH_URL = "https://www.sos.state.co.us/biz/BusinessEntityCriteriaExt.do"

CO_ENTITY_TYPE_MAP = {
    "LIMITED LIABILITY COMPANY": EntityType.LLC,
    "DOMESTIC LIMITED LIABILITY COMPANY": EntityType.LLC,
    "FOREIGN LIMITED LIABILITY COMPANY": EntityType.LLC,
    "CORPORATION": EntityType.CORPORATION,
    "DOMESTIC CORPORATION": EntityType.CORPORATION,
    "FOREIGN CORPORATION": EntityType.CORPORATION,
    "NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "LIMITED PARTNERSHIP": EntityType.LP,
    "GENERAL PARTNERSHIP": EntityType.PARTNERSHIP,
    "LIMITED LIABILITY PARTNERSHIP": EntityType.LLP,
}

CO_STATUS_MAP = {
    "GOOD STANDING": EntityStatus.ACTIVE,
    "ACTIVE": EntityStatus.ACTIVE,
    "INACTIVE": EntityStatus.INACTIVE,
    "DISSOLVED": EntityStatus.DISSOLVED,
    "SUSPENDED": EntityStatus.SUSPENDED,
    "WITHDRAWN": EntityStatus.WITHDRAWN,
    "DELINQUENT": EntityStatus.INACTIVE,
}


@StateRegistry.register
class ColoradoCollector(BaseStateCollector):
    """Collector for Colorado government data using HTTP."""

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="CO",
            name="Colorado",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "Colorado Department of Regulatory Agencies (DORA)",
                "Colorado Secretary of State",
            ],
            notes="Both sources support HTTP-based scraping.",
        )

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search Colorado DORA for professional licenses.
        """
        if not params.query and not params.license_number:
            logger.warning("CO DORA: query (name) or license_number is required")
            return

        # Get initial page for ViewState
        try:
            init_response = await self.client.get(CO_DORA_LOOKUP_URL)
            init_html = init_response.text
        except Exception as e:
            logger.error("CO DORA initial page load failed: %s", e)
            return

        viewstate = self._extract_aspnet_field(init_html, "__VIEWSTATE")
        viewstate_gen = self._extract_aspnet_field(init_html, "__VIEWSTATEGENERATOR")
        event_validation = self._extract_aspnet_field(init_html, "__EVENTVALIDATION")

        form_data = {
            "__VIEWSTATE": viewstate or "",
            "__VIEWSTATEGENERATOR": viewstate_gen or "",
            "__EVENTVALIDATION": event_validation or "",
            "ctl00$ContentPlaceHolder1$txtLicenseNumber": params.license_number or "",
            "ctl00$ContentPlaceHolder1$txtLastName": "",
            "ctl00$ContentPlaceHolder1$txtFirstName": "",
            "ctl00$ContentPlaceHolder1$txtBusinessName": "",
            "ctl00$ContentPlaceHolder1$btnSearch": "Search",
        }

        if params.query and not params.license_number:
            parts = params.query.strip().split(maxsplit=1)
            form_data["ctl00$ContentPlaceHolder1$txtLastName"] = parts[0]
            if len(parts) > 1:
                form_data["ctl00$ContentPlaceHolder1$txtFirstName"] = parts[1]

        try:
            response = await self.client.post(CO_DORA_LOOKUP_URL, data=form_data)
            html = response.text
        except Exception as e:
            logger.error("CO DORA license search failed: %s", e)
            return

        tree = parse_html(html)
        rows = tree.css("table tr")

        count = 0
        for row in rows:
            if count >= params.max_results:
                break

            cells = row.css("td")
            if len(cells) < 3:
                continue

            name = extract_text(cells[0])
            license_num = extract_text(cells[1]) if len(cells) > 1 else None
            license_type = extract_text(cells[2]) if len(cells) > 2 else "Professional License"
            status_text = extract_text(cells[3]) if len(cells) > 3 else None

            if not name or not license_num:
                continue

            status = LicenseStatus.ACTIVE
            if status_text:
                status = CO_LICENSE_STATUS_MAP.get(
                    status_text.upper().strip(), LicenseStatus.OTHER
                )

            license_obj = License(
                license_number=license_num.strip(),
                license_type=license_type.strip() if license_type else "Professional License",
                status=status,
                state="CO",
                holder_name=name.strip(),
                source_url=CO_DORA_LOOKUP_URL,
                raw_data={"status_text": status_text},
            )

            yield CollectorResult(
                category=DataCategory.LICENSES.value,
                state="CO",
                data=license_obj,
                source="Colorado Department of Regulatory Agencies (DORA)",
            )
            count += 1

        logger.info("CO DORA: returned %d license results", count)

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search Colorado Secretary of State for business entities.
        """
        if not params.query:
            logger.warning("CO SOS: query (business name) is required")
            return

        form_data = {
            "entityName": params.query,
            "entityNameSearchType": "CONTAINS",
            "masterEntityId": "",
            "principalName": "",
            "agentName": "",
            "entityTypeFilter": "ALL",
            "entityStatusFilter": "ALL",
            "submitName": "Search",
        }

        try:
            response = await self.client.post(CO_SOS_SEARCH_URL, data=form_data)
            html = response.text
        except Exception as e:
            logger.error("CO SOS business search failed: %s", e)
            return

        tree = parse_html(html)
        rows = tree.css("table tr, .results tr")

        count = 0
        for row in rows:
            if count >= params.max_results:
                break

            cells = row.css("td")
            if len(cells) < 2:
                continue

            name = extract_text(cells[0])
            entity_id = extract_text(cells[1]) if len(cells) > 1 else None
            entity_type_text = extract_text(cells[2]) if len(cells) > 2 else None
            status_text = extract_text(cells[3]) if len(cells) > 3 else None

            if not name:
                continue

            entity_type = CO_ENTITY_TYPE_MAP.get(
                (entity_type_text or "").upper().strip(), EntityType.OTHER
            )
            status = CO_STATUS_MAP.get(
                (status_text or "").upper().strip(), EntityStatus.OTHER
            )

            business = Business(
                name=name.strip(),
                entity_type=entity_type,
                status=status,
                state="CO",
                filing_number=entity_id,
                source_url=CO_SOS_SEARCH_URL,
                raw_data={
                    "entity_type_text": entity_type_text,
                    "status_text": status_text,
                },
            )

            yield CollectorResult(
                category=DataCategory.BUSINESSES.value,
                state="CO",
                data=business,
                source="Colorado Secretary of State",
            )
            count += 1

        logger.info("CO SOS: returned %d business results", count)

    def _extract_aspnet_field(self, html: str, field_name: str) -> str | None:
        """Extract ASP.NET hidden form field value."""
        pattern = rf'<input[^>]*name="{re.escape(field_name)}"[^>]*value="([^"]*)"'
        match = re.search(pattern, html, re.IGNORECASE)
        if match:
            return match.group(1)
        return None