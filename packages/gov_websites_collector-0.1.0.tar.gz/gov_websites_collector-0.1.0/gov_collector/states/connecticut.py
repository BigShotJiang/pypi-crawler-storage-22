"""
Connecticut state collector.

Sources:
- DCP (Department of Consumer Protection): License lookup
  https://www.elicense.ct.gov/Lookup/LicenseLookup.aspx
- Connecticut Secretary of State: Business entity search
  https://www.concord-sots.ct.gov/CONCORD/online?sn=PublicInquiry&eid=9740
  NOTE: business.ct.gov is a Salesforce Lightning SPA — NOT feasible with
  simple form fill. The Concord system also requires complex JS interaction.
  Business search is currently marked as needing a different approach.

Strategy: HYBRID approach
- Licenses: Browser automation (ASP.NET eLicense with JS-triggered search)
- Businesses: DEFERRED — Salesforce Lightning SPA requires API or headless approach
"""

from __future__ import annotations

import logging
import re
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.models import (
    Business,
    CollectorResult,
    EntityStatus,
    EntityType,
    License,
    LicenseStatus,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import extract_text, parse_html
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

CT_LICENSE_URL = "https://www.elicense.ct.gov/Lookup/LicenseLookup.aspx"
CT_BUSINESS_URL = "https://www.concord-sots.ct.gov/CONCORD/online?sn=PublicInquiry&eid=9740"

CT_LICENSE_STATUS_MAP = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "CURRENT": LicenseStatus.ACTIVE,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
    "PENDING": LicenseStatus.PENDING,
}

CT_ENTITY_TYPE_MAP = {
    "LIMITED LIABILITY COMPANY": EntityType.LLC,
    "CORPORATION": EntityType.CORPORATION,
    "NONPROFIT CORPORATION": EntityType.NONPROFIT,
}

CT_STATUS_MAP = {
    "ACTIVE": EntityStatus.ACTIVE,
    "GOOD STANDING": EntityStatus.ACTIVE,
    "INACTIVE": EntityStatus.INACTIVE,
}

# eLicense form field IDs (from current HTML snapshot)
_CT_LIC_PFX_ID = "ctl00_MainContentPlaceHolder_ucLicenseLookup_ctl03"
_CT_LIC_LAST_NAME_ID = f"#{_CT_LIC_PFX_ID}_tbLastName_Contact"
_CT_LIC_FIRST_NAME_ID = f"#{_CT_LIC_PFX_ID}_tbFirstName_Contact"
_CT_LIC_NUMBER_ID = f"#{_CT_LIC_PFX_ID}_tbLicenseNumber"
_CT_LIC_DBA_ID = f"#{_CT_LIC_PFX_ID}_tbDBA_Contact"
_CT_LIC_STATUS_ID = f"#{_CT_LIC_PFX_ID}_ddStatus"
_CT_LIC_TYPE_ID = f"#{_CT_LIC_PFX_ID}_lbMultipleCredentialTypePrefix"
_CT_LIC_SUBMIT_ID = "#ctl00_MainContentPlaceHolder_ucLicenseLookup_btnLookup"


@StateRegistry.register
class ConnecticutCollector(BaseStateCollector):
    """Collector for Connecticut government data using hybrid approach."""

    needs_browser_for = [DataCategory.LICENSES, DataCategory.BUSINESSES]

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="CT",
            name="Connecticut",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "Connecticut Department of Consumer Protection (DCP)",
                "Connecticut Secretary of State",
            ],
            notes=(
                "Business search uses Salesforce Lightning SPA — requires "
                "browser automation with careful JS handling. License search "
                "uses ASP.NET eLicense with UpdatePanel AJAX."
            ),
        )

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """Search Connecticut DCP for professional licenses.

        The eLicense platform uses a JS-triggered AJAX search via
        ClickSearchLicenses() which populates an UpdatePanel with results.
        Requires browser automation.
        """
        if not params.query and not params.license_number:
            logger.warning("CT DCP: query or license_number is required")
            return

        if self.has_browser:
            async for result in self._collect_licenses_browser(params):
                yield result
            return

        logger.warning(
            "CT DCP requires browser automation (eLicense JS submit). "
            "Use use_camoufox=True."
        )
        return

    async def _collect_licenses_browser(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """Browser-based CT license search using eLicense AJAX form."""
        page = None
        try:
            import asyncio as _aio

            page = await self.browser.new_page()
            await page.goto(
                CT_LICENSE_URL, wait_until="domcontentloaded", timeout=30000
            )

            # Wait for the form to be fully loaded (eLicense is heavy)
            try:
                await page.wait_for_selector(
                    _CT_LIC_LAST_NAME_ID, timeout=15000
                )
            except Exception:
                # Fallback: wait a bit and hope it loaded
                await _aio.sleep(5)

            # Fill search fields
            if params.license_number:
                try:
                    await page.fill(_CT_LIC_NUMBER_ID, params.license_number)
                except Exception as e:
                    logger.debug("Could not fill license number: %s", e)
            elif params.query:
                parts = params.query.strip().split(maxsplit=1)
                # First part = last name
                try:
                    await page.fill(_CT_LIC_LAST_NAME_ID, parts[0])
                except Exception as e:
                    logger.debug("Could not fill last name: %s", e)
                # Second part = first name (if available)
                if len(parts) > 1:
                    try:
                        await page.fill(_CT_LIC_FIRST_NAME_ID, parts[1])
                    except Exception as e:
                        logger.debug("Could not fill first name: %s", e)

            # Click Submit button — triggers ClickSearchLicenses(0) JS
            # which does an ASP.NET AJAX UpdatePanel postback
            try:
                await page.click(_CT_LIC_SUBMIT_ID)
            except Exception:
                # Fallback: try pressing Enter in the last filled field
                await page.keyboard.press("Enter")

            # Wait for AJAX response — the UpdatePanel populates a modal
            # with results. Look for the results modal to become visible.
            await _aio.sleep(3)
            try:
                await page.wait_for_selector(
                    ".modal-window-lookup-results, "
                    ".bs-example-modal-lg, "
                    "table.table, "
                    "#ctl00_MainContentPlaceHolder_ucLicenseLookup_UpdtPanelGridLookup table",
                    timeout=20000,
                )
            except Exception:
                # Results might already be in the page
                await _aio.sleep(3)

            html = await page.content()

        except Exception as e:
            logger.error("CT DCP browser license search failed: %s", e)
            return
        finally:
            if page:
                await page.close()

        # Parse results from the AJAX-populated content
        tree = parse_html(html)

        # Results appear in the UpdatePanel area in a table
        # Table structure (eLicense):
        #   Row 0: pagination (1 cell)
        #   Row 1+: data rows with 8 cells:
        #     [0] "Detail" link, [1] Name, [2] License #, [3] License Type,
        #     [4] Status, [5] Status detail, [6] City, [7] DBA/Business Name
        result_tables = tree.css(
            "#ctl00_MainContentPlaceHolder_ucLicenseLookup_UpdtPanelGridLookup table tr"
        )
        if not result_tables:
            result_tables = tree.css(
                ".modal-window-lookup-results table tr, "
                ".bs-example-modal-lg table tr"
            )
        if not result_tables:
            result_tables = tree.css("table.table tr")

        count = 0
        for row in result_tables:
            if count >= params.max_results:
                break

            cells = row.css("td")
            if len(cells) < 4:
                continue

            # Detect eLicense layout: first cell is "Detail" link
            first_text = extract_text(cells[0]) or ""
            if first_text.strip().lower() == "detail" and len(cells) >= 5:
                # eLicense format: Detail | Name | License# | Type | Status | ...
                name = extract_text(cells[1])
                license_num = extract_text(cells[2])
                license_type = extract_text(cells[3])
                status_text = extract_text(cells[4])
                city = extract_text(cells[6]) if len(cells) > 6 else None
                dba = extract_text(cells[7]) if len(cells) > 7 else None
            else:
                # Generic layout: Name | License# | Type | Status
                name = extract_text(cells[0])
                license_num = extract_text(cells[1])
                license_type = extract_text(cells[2])
                status_text = extract_text(cells[3]) if len(cells) > 3 else None
                city = None
                dba = None

            if not name or not license_num:
                continue

            # Skip header-like rows
            if name.upper() in ("NAME", "LICENSEE NAME", "RESPONDENT NAME"):
                continue

            status = CT_LICENSE_STATUS_MAP.get(
                (status_text or "").upper().strip(), LicenseStatus.OTHER
            )

            raw = {
                "status_text": status_text,
                "license_type": license_type,
            }
            if city:
                raw["city"] = city
            if dba:
                raw["dba"] = dba

            yield CollectorResult(
                category=DataCategory.LICENSES.value,
                state="CT",
                data=License(
                    license_number=license_num.strip(),
                    license_type=license_type or "Professional License",
                    status=status,
                    state="CT",
                    holder_name=name.strip(),
                    business_name=dba,
                    source_url=CT_LICENSE_URL,
                    raw_data=raw,
                ),
                source="Connecticut DCP (eLicense)",
            )
            count += 1

        logger.info("CT DCP: returned %d license results", count)

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """Search Connecticut SOS for business entities.

        NOTE: The Connecticut business search (business.ct.gov) is built on
        Salesforce Lightning — a full client-side SPA that cannot be driven
        with simple form fill. The Concord system at concord-sots.ct.gov
        also uses complex JavaScript interactions.

        This method attempts browser-based search on the Concord system
        but may fail if the site structure has changed significantly.
        """
        if not params.query:
            logger.warning("CT SOS: query (business name) is required")
            return

        if not self.has_browser:
            logger.warning(
                "CT SOS requires browser automation. "
                "Business search on business.ct.gov is a Salesforce SPA — "
                "may not work with current approach."
            )
            return

        page = None
        try:
            page = await self.browser.new_page()
            await page.goto(
                CT_BUSINESS_URL,
                wait_until="domcontentloaded",
                timeout=20000,
            )

            import asyncio as _aio
            await _aio.sleep(3)

            # The Concord system is a Java-based web app
            # Try to find and fill the business name search field
            name_field = await page.query_selector(
                'input[name*="busName"], '
                'input[name*="BUSNAME"], '
                'input[id*="busName"], '
                'input[name*="name" i], '
                'input[type="text"]'
            )
            if name_field:
                await name_field.fill(params.query)
            else:
                logger.warning(
                    "CT SOS: Could not find name input field. "
                    "Concord system may have changed."
                )
                return

            # Try to find and click search button
            search_btn = await page.query_selector(
                'input[type="submit"][value*="Search" i], '
                'button:has-text("Search"), '
                'input[name*="search" i], '
                'a:has-text("Search")'
            )
            if search_btn:
                await search_btn.click()
            else:
                await page.keyboard.press("Enter")

            await _aio.sleep(3)
            try:
                await page.wait_for_load_state(
                    "domcontentloaded", timeout=15000
                )
            except Exception:
                pass

            html = await page.content()
            tree = parse_html(html)

            # Parse results table
            rows = tree.css("table tr")
            count = 0
            for row in rows:
                if count >= params.max_results:
                    break

                cells = row.css("td")
                if len(cells) < 2:
                    continue

                name = extract_text(cells[0])
                filing_number = (
                    extract_text(cells[1]) if len(cells) > 1 else None
                )
                type_text = (
                    extract_text(cells[2]) if len(cells) > 2 else None
                )
                status_text = (
                    extract_text(cells[3]) if len(cells) > 3 else None
                )

                if not name:
                    continue

                # Skip header rows
                if name.upper() in ("NAME", "BUSINESS NAME", "ENTITY NAME"):
                    continue

                type_key = (type_text or "").upper().strip()
                entity_type = CT_ENTITY_TYPE_MAP.get(
                    type_key, EntityType.OTHER
                )
                status_key = (status_text or "").upper().strip()
                status = CT_STATUS_MAP.get(status_key, EntityStatus.OTHER)

                business = Business(
                    name=name.strip(),
                    entity_type=entity_type,
                    status=status,
                    state="CT",
                    filing_number=filing_number,
                    source_url=CT_BUSINESS_URL,
                    raw_data={
                        "type_text": type_text,
                        "status_text": status_text,
                    },
                )

                yield CollectorResult(
                    category=DataCategory.BUSINESSES.value,
                    state="CT",
                    data=business,
                    source="Connecticut Secretary of State",
                )
                count += 1

            logger.info("CT SOS: returned %d business results", count)

        except Exception as e:
            logger.error("CT SOS business search failed: %s", e)
        finally:
            if page:
                await page.close()

    def _extract_aspnet_field(self, html: str, field_name: str) -> str | None:
        """Extract ASP.NET hidden form field value."""
        pattern = (
            rf'<input[^>]*name="{re.escape(field_name)}"[^>]*value="([^"]*)"'
        )
        match = re.search(pattern, html, re.IGNORECASE)
        if match:
            return match.group(1)
        return None
