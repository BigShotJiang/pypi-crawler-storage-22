"""
District of Columbia collector.

Sources:
- DC Real Estate Commission (DCRA): SERVICE UNAVAILABLE
  https://eservices.dcra.dc.gov/BBLV/Default.aspx - returns 503 Service Unavailable  
  https://app.dcra.dc.gov/professional_licenses/search - DNS error (ENOTFOUND)
- DCRA CorpOnline: CONNECTION TIMEOUT
  https://corponline.dcra.dc.gov/Home.aspx - returns 522 Connection timed out

SCAN RESULTS: License 500/503, Corp TIMEOUT (522)
DC is a special jurisdiction — not a state, but the District of Columbia.
Uses "DC" as the state code.
"""

from __future__ import annotations

import logging
import re
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.exceptions import ParseError, ScrapingError
from gov_collector.models import (
    Address,
    Business,
    CollectorResult,
    EntityStatus,
    EntityType,
    License,
    LicenseStatus,
    Person,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import (
    clean_text,
    extract_table_rows,
    extract_text,
    parse_html,
    parse_address_text,
)
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

# --- DC Real Estate License ---

DC_LICENSE_SEARCH_URL = "https://dlcp.dc.gov/professional-licensing"
# Legacy URLs (dead):
# https://eservices.dcra.dc.gov/BBLV/Default.aspx
# https://app.dcra.dc.gov/professional_licenses/search
DC_LICENSE_PORTAL_URL = "https://dlcp.dc.gov/professional-licensing"

DC_LICENSE_STATUS_MAP: dict[str, LicenseStatus] = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "CURRENT": LicenseStatus.ACTIVE,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
    "SUSPENDED": LicenseStatus.SUSPENDED,
    "REVOKED": LicenseStatus.REVOKED,
    "CANCELLED": LicenseStatus.CANCELLED,
    "PENDING": LicenseStatus.PENDING,
    "LAPSED": LicenseStatus.EXPIRED,
}

# --- DCRA CorpOnline (Business Entity) ---

DC_CORP_SEARCH_URL = "https://corponline.dlcp.dc.gov/"
DC_CORP_SEARCH_API_URL = "https://corponline.dlcp.dc.gov/Search.aspx"

DC_ENTITY_TYPE_MAP: dict[str, EntityType] = {
    "DOMESTIC LIMITED LIABILITY COMPANY": EntityType.LLC,
    "FOREIGN LIMITED LIABILITY COMPANY": EntityType.LLC,
    "LLC": EntityType.LLC,
    "DOMESTIC CORPORATION": EntityType.CORPORATION,
    "FOREIGN CORPORATION": EntityType.CORPORATION,
    "CORPORATION": EntityType.CORPORATION,
    "NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "DOMESTIC NONPROFIT": EntityType.NONPROFIT,
    "LIMITED PARTNERSHIP": EntityType.LP,
    "LIMITED LIABILITY PARTNERSHIP": EntityType.LLP,
    "GENERAL PARTNERSHIP": EntityType.PARTNERSHIP,
    "SOLE PROPRIETORSHIP": EntityType.SOLE_PROPRIETORSHIP,
    "TRADE NAME": EntityType.OTHER,
}

DC_STATUS_MAP: dict[str, EntityStatus] = {
    "ACTIVE": EntityStatus.ACTIVE,
    "GOOD STANDING": EntityStatus.ACTIVE,
    "INACTIVE": EntityStatus.INACTIVE,
    "DISSOLVED": EntityStatus.DISSOLVED,
    "REVOKED": EntityStatus.DISSOLVED,
    "CANCELLED": EntityStatus.DISSOLVED,
    "EXPIRED": EntityStatus.DISSOLVED,
    "SUSPENDED": EntityStatus.SUSPENDED,
    "WITHDRAWN": EntityStatus.WITHDRAWN,
}


@StateRegistry.register
class DistrictOfColumbiaCollector(BaseStateCollector):
    """Collector for District of Columbia government data.
    
    Note: DC licensing services return 503 Service Unavailable.
    Corporate search experiences connection timeouts.
    """

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="DC",
            name="District of Columbia",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "DC Department of Consumer and Regulatory Affairs (DCRA)",
                "DC CorpOnline (Business Entity Search)",
            ],
            notes=(
                "DC government websites are down (503/timeout) as of Feb 2026. "
                "Services unavailable for automated access."
            ),
        )

    # --- Real Estate Licenses ---

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        DC DCRA license services are unavailable.
        
        - eservices.dcra.dc.gov returns 503 Service Unavailable
        - app.dcra.dc.gov returns DNS error (domain not found)
        
        DCRA license lookup services appear to be down or discontinued.
        """
        logger.error(
            "DC DCRA: License services unavailable. "
            "eservices returns 503, app.dcra.dc.gov returns DNS error."
        )
        return
        yield  # Make it a generator

    async def _parse_dc_license_results(
        self, html: str
    ) -> AsyncIterator[CollectorResult]:
        """Parse DC license search results."""
        tree = parse_html(html)

        rows = tree.css("table tr")
        if not rows:
            logger.debug("No DC license results found")
            return

        for row in rows:
            cells = row.css("td")
            if len(cells) < 4:
                continue

            name_text = extract_text(cells[0])
            license_id = extract_text(cells[1])
            license_type_text = extract_text(cells[2])
            status_text = extract_text(cells[3])

            if not name_text or not license_id:
                continue

            status = LicenseStatus.OTHER
            if status_text:
                status_upper = status_text.upper().strip()
                status = DC_LICENSE_STATUS_MAP.get(
                    status_upper, LicenseStatus.OTHER
                )

            # Expiration date
            expiration_date = None
            if len(cells) > 4:
                exp_text = extract_text(cells[4])
                if exp_text:
                    try:
                        parts = re.split(r"[/\-]", exp_text.strip())
                        if len(parts) == 3:
                            from datetime import date as d

                            if len(parts[0]) == 4:
                                expiration_date = d(
                                    int(parts[0]), int(parts[1]), int(parts[2])
                                )
                            else:
                                expiration_date = d(
                                    int(parts[2]), int(parts[0]), int(parts[1])
                                )
                    except (ValueError, IndexError):
                        pass

            license_obj = License(
                license_number=license_id.strip(),
                license_type=license_type_text or "Real Estate",
                status=status,
                state="DC",
                holder_name=name_text.strip(),
                expiration_date=expiration_date,
                source_url=DC_LICENSE_PORTAL_URL,
                raw_data={
                    "name": name_text,
                    "license_type": license_type_text,
                    "status_text": status_text,
                },
            )

            yield CollectorResult(
                category=DataCategory.LICENSES.value,
                state="DC",
                data=license_obj,
                source="DC DCRA",
            )

    # --- Business Entity Search ---

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        DC CorpOnline business search is unavailable.
        
        corponline.dcra.dc.gov returns 522 Connection timed out error 
        from Cloudflare, indicating the origin server is not responding.
        The service appears to be down or experiencing technical issues.
        """
        logger.error(
            "DC CorpOnline: Business search unavailable. "
            "Site returns 522 Connection timed out (Cloudflare error)."
        )
        return
        yield  # Make it a generator

    def _extract_asp_field(self, tree, field_name: str) -> str | None:
        """Extract a hidden ASP.NET form field value."""
        node = tree.css_first(f'input[name="{field_name}"]')
        if node:
            return node.attributes.get("value", "")
        return None

    def _parse_dc_corp_record(self, row: dict[str, str]) -> Business | None:
        """Parse a single DC CorpOnline search result row."""
        name = (
            row.get("Entity Name")
            or row.get("Business Name")
            or row.get("Name", "")
        )
        if not name:
            return None

        type_str = (row.get("Entity Type") or row.get("Type") or "").upper()
        entity_type = DC_ENTITY_TYPE_MAP.get(type_str, EntityType.OTHER)

        status_str = (row.get("Status") or "").upper().strip()
        status = DC_STATUS_MAP.get(status_str, EntityStatus.OTHER)

        filing_number = (
            row.get("File Number")
            or row.get("Entity Number")
            or row.get("Registration Number")
        )

        # Formation date
        formation_date = None
        date_str = row.get("Date Filed") or row.get("Formation Date")
        if date_str:
            try:
                parts = re.split(r"[/\-]", date_str.strip())
                if len(parts) == 3:
                    from datetime import date as d

                    if len(parts[0]) == 4:
                        formation_date = d(
                            int(parts[0]), int(parts[1]), int(parts[2])
                        )
                    else:
                        formation_date = d(
                            int(parts[2]), int(parts[0]), int(parts[1])
                        )
            except (ValueError, IndexError):
                pass

        # Agent
        agent_name = row.get("Registered Agent") or row.get("Agent")
        agent = Person(full_name=agent_name) if agent_name else None

        return Business(
            name=name.strip(),
            entity_type=entity_type,
            status=status,
            state="DC",
            filing_number=filing_number,
            formation_date=formation_date,
            registered_agent=agent,
            source_url=DC_CORP_SEARCH_URL,
            raw_data=row,
        )
