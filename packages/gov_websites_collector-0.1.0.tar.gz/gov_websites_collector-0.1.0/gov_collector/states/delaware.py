"""
Delaware state collector.

Sources:
- DPRM (Division of Professional Regulation): UNAVAILABLE - 404 ERROR
  https://delpros.delaware.gov/OH_Verification - returns "Page Not Found"
- Delaware Division of Corporations (ICIS): WORKING
  https://icis.corp.delaware.gov/Ecorp/EntitySearch/NameSearch.aspx
  ASP.NET WebForms — requires ViewState handling.

SCAN RESULTS: DPRM 404, ICIS working
Note: Delaware is the #1 state for business incorporations (60%+ of
Fortune 500 are incorporated in DE). The Division of Corporations
site is heavily used and may rate-limit.
"""

from __future__ import annotations

import logging
import re
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.exceptions import ParseError, ScrapingError
from gov_collector.models import (
    Address,
    Business,
    CollectorResult,
    EntityStatus,
    EntityType,
    License,
    LicenseStatus,
    Person,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import (
    clean_text,
    extract_table_rows,
    extract_text,
    parse_html,
    parse_address_text,
)
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

# --- DPRM (Professional License Verification) ---

DPRM_SEARCH_URL = "https://delpros.delaware.gov/OH_Verification"

DE_LICENSE_STATUS_MAP: dict[str, LicenseStatus] = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "CURRENT": LicenseStatus.ACTIVE,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
    "SUSPENDED": LicenseStatus.SUSPENDED,
    "REVOKED": LicenseStatus.REVOKED,
    "CANCELLED": LicenseStatus.CANCELLED,
    "PENDING": LicenseStatus.PENDING,
    "LAPSED": LicenseStatus.EXPIRED,
}

# --- Delaware Division of Corporations (ICIS) ---

DE_CORP_SEARCH_URL = (
    "https://icis.corp.delaware.gov/Ecorp/EntitySearch/NameSearch.aspx"
)

DE_ENTITY_TYPE_MAP: dict[str, EntityType] = {
    "CORPORATION": EntityType.CORPORATION,
    "LLC": EntityType.LLC,
    "LIMITED LIABILITY COMPANY": EntityType.LLC,
    "LIMITED PARTNERSHIP": EntityType.LP,
    "LP": EntityType.LP,
    "LIMITED LIABILITY PARTNERSHIP": EntityType.LLP,
    "LLP": EntityType.LLP,
    "GENERAL PARTNERSHIP": EntityType.PARTNERSHIP,
    "GP": EntityType.PARTNERSHIP,
    "STATUTORY TRUST": EntityType.TRUST,
    "NONPROFIT": EntityType.NONPROFIT,
    "NOT FOR PROFIT": EntityType.NONPROFIT,
}

DE_STATUS_MAP: dict[str, EntityStatus] = {
    "GOOD STANDING": EntityStatus.ACTIVE,
    "ACTIVE": EntityStatus.ACTIVE,
    "VOID": EntityStatus.DISSOLVED,
    "VOIDED": EntityStatus.DISSOLVED,
    "DISSOLVED": EntityStatus.DISSOLVED,
    "CANCELLED": EntityStatus.DISSOLVED,
    "INACTIVE": EntityStatus.INACTIVE,
    "WITHDRAWN": EntityStatus.WITHDRAWN,
    "MERGED": EntityStatus.MERGED,
    "CONVERTED": EntityStatus.CONVERTED,
    "REVOKED": EntityStatus.DISSOLVED,
    "FORFEITED": EntityStatus.DISSOLVED,
}


@StateRegistry.register
class DelawareCollector(BaseStateCollector):
    """Collector for Delaware government data."""

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="DE",
            name="Delaware",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "Delaware Division of Professional Regulation (DPRM)",
                "Delaware Division of Corporations (ICIS)",
            ],
            notes=(
                "Delaware is the top state for business incorporations. "
                "The ICIS system uses ASP.NET WebForms with ViewState."
            ),
        )

    # --- Real Estate Licenses ---

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Delaware DPRM license search is unavailable.
        
        The OH_Verification URL returns "Page Not Found" (404).
        Professional license search may have been moved or discontinued.
        """
        logger.warning(
            "DE DPRM: Professional license search unavailable. "
            "OH_Verification URL returns 404 (Page Not Found)."
        )
        return
        yield  # Make it a generator

    async def _parse_dprm_results(
        self, html: str
    ) -> AsyncIterator[CollectorResult]:
        """Parse DPRM search results."""
        tree = parse_html(html)

        rows = tree.css("table tr")
        if not rows:
            logger.debug("No DE DPRM results found")
            return

        for row in rows:
            cells = row.css("td")
            if len(cells) < 4:
                continue

            name_text = extract_text(cells[0])
            license_id = extract_text(cells[1])
            license_type_text = extract_text(cells[2])
            status_text = extract_text(cells[3])

            if not name_text or not license_id:
                continue

            status = LicenseStatus.OTHER
            if status_text:
                status_upper = status_text.upper().strip()
                status = DE_LICENSE_STATUS_MAP.get(
                    status_upper, LicenseStatus.OTHER
                )

            # Expiration date
            expiration_date = None
            if len(cells) > 4:
                exp_text = extract_text(cells[4])
                if exp_text:
                    try:
                        parts = re.split(r"[/\-]", exp_text.strip())
                        if len(parts) == 3:
                            from datetime import date as d

                            if len(parts[0]) == 4:
                                expiration_date = d(
                                    int(parts[0]), int(parts[1]), int(parts[2])
                                )
                            else:
                                expiration_date = d(
                                    int(parts[2]), int(parts[0]), int(parts[1])
                                )
                    except (ValueError, IndexError):
                        pass

            license_obj = License(
                license_number=license_id.strip(),
                license_type=license_type_text or "Real Estate",
                status=status,
                state="DE",
                holder_name=name_text.strip(),
                expiration_date=expiration_date,
                source_url=DPRM_SEARCH_URL,
                raw_data={
                    "name": name_text,
                    "license_type": license_type_text,
                    "status_text": status_text,
                },
            )

            yield CollectorResult(
                category=DataCategory.LICENSES.value,
                state="DE",
                data=license_obj,
                source="Delaware DPRM",
            )

    # --- Business Entity Search ---

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search Delaware Division of Corporations (ICIS) for business entities.

        ASP.NET WebForms — requires ViewState management.
        """
        if not params.query:
            raise ValueError(
                "'query' (business name) is required for DE business search"
            )

        # Step 1: GET the search page for ViewState
        try:
            page_response = await self.client.get(DE_CORP_SEARCH_URL)
            page_html = page_response.text
        except Exception as e:
            logger.error("Failed to load DE ICIS search page: %s", e)
            return

        tree = parse_html(page_html)

        viewstate = self._extract_asp_field(tree, "__VIEWSTATE")
        viewstate_gen = self._extract_asp_field(tree, "__VIEWSTATEGENERATOR")
        event_validation = self._extract_asp_field(tree, "__EVENTVALIDATION")

        if not viewstate:
            logger.error("Could not extract ViewState from DE ICIS page")
            return

        # Step 2: POST the search - Use correct form field names from live site
        form_data = {
            "__VIEWSTATE": viewstate,
            "__VIEWSTATEGENERATOR": viewstate_gen or "",
            "__EVENTVALIDATION": event_validation or "",
            "ctl00$ContentPlaceHolder$frmEntityName": params.query,  # Entity Name field  
            "ctl00$ContentPlaceHolder$frmFileNumber": "",  # File Number field
            "ctl00$ContentPlaceHolder$btnSubmit": "Search",  # Submit button
        }

        try:
            response = await self.client.post(
                DE_CORP_SEARCH_URL, data=form_data
            )
            html = response.text
        except Exception as e:
            logger.error("DE ICIS business search failed: %s", e)
            return

        count = 0
        async for result in self._parse_icis_results(html):
            yield result
            count += 1
            if count >= params.max_results:
                return

    def _extract_asp_field(self, tree, field_name: str) -> str | None:
        """Extract a hidden ASP.NET form field value."""
        node = tree.css_first(f'input[name="{field_name}"]')
        if node:
            return node.attributes.get("value", "")
        return None

    async def _parse_icis_results(
        self, html: str
    ) -> AsyncIterator[CollectorResult]:
        """Parse ICIS search results."""
        tree = parse_html(html)

        rows = tree.css(
            "table#ContentPlaceHolder1_gvResults tr, "
            "table.GridView tr, table tr"
        )
        if not rows:
            logger.debug("No DE ICIS results found")
            return

        for row in rows:
            cells = row.css("td")
            if len(cells) < 3:
                continue

            name_text = extract_text(cells[0])
            file_number = extract_text(cells[1])
            type_text = extract_text(cells[2])
            status_text = extract_text(cells[3]) if len(cells) > 3 else None
            state_text = extract_text(cells[4]) if len(cells) > 4 else None

            if not name_text:
                continue

            # Map entity type
            type_str = (type_text or "").upper().strip()
            entity_type = DE_ENTITY_TYPE_MAP.get(type_str, EntityType.OTHER)

            # Map status
            status = EntityStatus.OTHER
            if status_text:
                status_upper = status_text.upper().strip()
                status = DE_STATUS_MAP.get(status_upper, EntityStatus.OTHER)

            # Formation date
            formation_date = None
            if len(cells) > 5:
                date_text = extract_text(cells[5])
                if date_text:
                    try:
                        parts = re.split(r"[/\-]", date_text.strip())
                        if len(parts) == 3:
                            from datetime import date as d

                            if len(parts[0]) == 4:
                                formation_date = d(
                                    int(parts[0]), int(parts[1]), int(parts[2])
                                )
                            else:
                                formation_date = d(
                                    int(parts[2]), int(parts[0]), int(parts[1])
                                )
                    except (ValueError, IndexError):
                        pass

            business = Business(
                name=name_text.strip(),
                entity_type=entity_type,
                status=status,
                state="DE",
                filing_number=file_number.strip() if file_number else None,
                formation_date=formation_date,
                source_url=DE_CORP_SEARCH_URL,
                raw_data={
                    "name": name_text,
                    "file_number": file_number,
                    "type": type_text,
                    "status": status_text,
                    "state_of_formation": state_text,
                },
            )

            yield CollectorResult(
                category=DataCategory.BUSINESSES.value,
                state="DE",
                data=business,
                source="Delaware Division of Corporations (ICIS)",
            )
