"""
Florida state collector.

Sources:
- DBPR (Department of Business and Professional Regulation): License lookups
  https://www.myfloridalicense.com/wl11.asp
- Sunbiz (Division of Corporations): Business entity search
  https://search.sunbiz.org/Inquiry/CorporationSearch/ByName

Strategy: Browser automation (Playwright) — Sunbiz is Cloudflare protected + JS rendered.
DBPR uses a multi-step form flow:
  1. wl11.asp (mode=0): Select search type (Name/LicNbr/City/LicTyp)
  2. wl11.asp (mode=1): Enter search criteria (Last Name, First Name, etc.)
  3. Results page
"""

from __future__ import annotations

import logging
import re
from datetime import datetime
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.models import (
    Business,
    CollectorResult,
    EntityStatus,
    License,
    LicenseStatus,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import clean_text, parse_html
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

SUNBIZ_SEARCH_URL = "https://search.sunbiz.org/Inquiry/CorporationSearch/ByName"
SUNBIZ_DETAIL_BASE = "https://search.sunbiz.org/Inquiry/CorporationSearch/SearchResultDetail"
DBPR_SEARCH_URL = "https://www.myfloridalicense.com/wl11.asp"

STATUS_MAP = {
    "Active": EntityStatus.ACTIVE,
    "INACT": EntityStatus.INACTIVE,
    "INACT/CV": EntityStatus.INACTIVE,
    "ADMIN DISSOLVED": EntityStatus.DISSOLVED,
    "VOLUNTARILY DISSOLVED": EntityStatus.DISSOLVED,
    "WITHDRAWN": EntityStatus.WITHDRAWN,
}


@StateRegistry.register
class FloridaCollector(BaseStateCollector):
    """Collector for Florida government data using browser automation."""

    needs_browser_for = [DataCategory.LICENSES, DataCategory.BUSINESSES]

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="FL",
            name="Florida",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "Florida DBPR (Dept. of Business & Professional Regulation)",
                "Florida Sunbiz (Division of Corporations)",
            ],
        )

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Florida Sunbiz business entity search using browser automation.
        """
        query = params.query
        if not query:
            logger.warning("FL Sunbiz: query is required")
            return

        if not self.has_browser:
            logger.warning(
                "FL Sunbiz requires browser automation. "
                "Initialize with use_browser=True."
            )
            return

        try:
            page = await self.browser.new_page()
        except Exception as e:
            logger.error("FL Sunbiz: failed to create browser page: %s", e)
            return

        count = 0
        max_results = params.max_results

        try:
            await page.goto(
                SUNBIZ_SEARCH_URL,
                wait_until="domcontentloaded",
                timeout=15000,
            )
            await page.wait_for_selector("#SearchTerm", timeout=10000)
            await page.fill("#SearchTerm", query)
            await page.click('input[type="submit"][value="Search Now"]')

            # Wait for results table
            await page.wait_for_selector(
                "table.search-results, .search-result-table, #search-results table, table",
                timeout=15000,
            )

            html = await page.content()
            tree = parse_html(html)

            # Parse results table - rows have: Name, Doc Number, Status
            rows = tree.css("table tr")
            for row in rows:
                if count >= max_results:
                    break

                cells = row.css("td")
                if len(cells) < 3:
                    continue

                name = clean_text(cells[0].text(deep=True))
                doc_number = clean_text(cells[1].text(deep=True))
                status_text = clean_text(cells[2].text(deep=True)) or ""

                if not name:
                    continue

                status = STATUS_MAP.get(status_text, EntityStatus.OTHER)

                biz = Business(
                    name=name,
                    state="FL",
                    filing_number=doc_number,
                    status=status,
                    source_url=SUNBIZ_SEARCH_URL,
                    raw_data={
                        "status_text": status_text,
                        "document_number": doc_number,
                    },
                )

                yield CollectorResult(
                    category="businesses",
                    state="FL",
                    data=biz,
                    source="Florida Sunbiz",
                )
                count += 1

            logger.info("FL Sunbiz: returned %d business results", count)

        except Exception as e:
            logger.error("FL Sunbiz business search failed: %s", e)
        finally:
            await page.close()

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Florida DBPR professional license search using browser automation.

        The DBPR site uses a multi-step flow:
        1. wl11.asp (mode=0): Select search type (Name/LicNbr/City/LicTyp)
        2. POST or navigate to mode=1 with the search type
        3. Fill search criteria (LastName, FirstName, OrgName, etc.)
        4. Submit to get results

        For name search, we navigate directly to mode=1 with search=Name.
        """
        query = params.query
        if not query:
            logger.warning("FL DBPR: query is required")
            return

        if not self.has_browser:
            logger.warning(
                "FL DBPR requires browser automation. "
                "Initialize with use_browser=True."
            )
            return

        try:
            page = await self.browser.new_page()
        except Exception as e:
            logger.error("FL DBPR: failed to create browser page: %s", e)
            return

        count = 0
        max_results = params.max_results

        try:
            import asyncio as _aio

            # Step 1: Navigate to search type selection page
            await page.goto(
                DBPR_SEARCH_URL,
                wait_until="domcontentloaded",
                timeout=20000,
            )
            await _aio.sleep(2)

            # Step 2: Select "Search by Name" (default) and click Search
            # The radio buttons are: SearchType with values Name, LicNbr, City, LicTyp
            # "Name" is checked by default. Click the Search/Submit button.
            name_radio = await page.query_selector(
                'input[name="SearchType"][value="Name"]'
            )
            if name_radio:
                await name_radio.check()

            # Find and click the Search button (first button in the form)
            search_btn = await page.query_selector(
                'button[name="SelectSearchType"], '
                'button.button:has-text("Search")'
            )
            if search_btn:
                await search_btn.click()
            else:
                # Fallback: submit the form directly
                await page.keyboard.press("Enter")

            # Step 3: Wait for mode=1 page (name search form) to load
            await _aio.sleep(3)
            try:
                await page.wait_for_load_state(
                    "domcontentloaded", timeout=15000
                )
            except Exception:
                pass

            # Step 4: Fill in search criteria on the mode=1 page
            # Try to find name fields (LastName, FirstName, OrgName)
            # Parse the query: if comma-separated, treat as "Last, First"
            # Otherwise first word = last name, rest = first name
            parts = query.strip().split(maxsplit=1)
            last_name = parts[0]
            first_name = parts[1] if len(parts) > 1 else ""

            # Fill Last Name
            last_name_field = await page.query_selector(
                'input[name="LastName"]'
            )
            if last_name_field:
                await last_name_field.fill(last_name)
            else:
                # Try organization name field as fallback
                org_field = await page.query_selector(
                    'input[name="OrgName"]'
                )
                if org_field:
                    await org_field.fill(query)
                else:
                    # Last resort: find any text input
                    text_input = await page.query_selector(
                        'input[type="text"]'
                    )
                    if text_input:
                        await text_input.fill(query)
                    else:
                        logger.warning(
                            "FL DBPR: could not find name input on mode=1 page"
                        )
                        return

            # Fill First Name if available
            if first_name:
                first_name_field = await page.query_selector(
                    'input[name="FirstName"]'
                )
                if first_name_field:
                    await first_name_field.fill(first_name)

            # Step 5: Submit the search form
            submit_btn = await page.query_selector(
                'button.button:has-text("Search"), '
                'input[type="submit"][value*="Search" i], '
                'button[name="Search"], '
                'input[name="Submit"]'
            )
            if submit_btn:
                await submit_btn.click()
            else:
                await page.keyboard.press("Enter")

            # Step 6: Wait for results page
            await _aio.sleep(3)
            try:
                await page.wait_for_load_state(
                    "domcontentloaded", timeout=15000
                )
            except Exception:
                pass

            html = await page.content()
            tree = parse_html(html)

            # Step 7: Parse results
            # DBPR results are in a 5-column table:
            #   [License Type, Name, NameType, LicenseNumber/Rank, Status/Expires]
            # Data rows alternate with address rows (starting with "Main Address*:")
            #
            # Find the results table (5-column header with "License Type")
            result_table = None
            for tbl in tree.css("table"):
                trs = tbl.css("tr")
                if trs:
                    first_cells = trs[0].css("th, td")
                    if len(first_cells) == 5:
                        header_text = clean_text(
                            first_cells[0].text(deep=True)
                        )
                        if header_text and "license type" in header_text.lower():
                            result_table = tbl
                            break

            if not result_table:
                logger.debug(
                    "FL DBPR: Could not find 5-column results table"
                )
                return

            rows = result_table.css("tr")
            for row in rows[1:]:  # Skip header
                if count >= max_results:
                    break

                cells = row.css("td")
                if len(cells) < 5:
                    continue

                # Skip address rows
                first_text = clean_text(cells[0].text(deep=True)) or ""
                if "address" in first_text.lower():
                    continue

                lic_type = first_text
                holder_name = clean_text(cells[1].text(deep=True))
                name_type = clean_text(cells[2].text(deep=True)) or ""
                lic_num_rank = clean_text(cells[3].text(deep=True)) or ""
                status_expires = clean_text(cells[4].text(deep=True)) or ""

                if not holder_name or not lic_type:
                    continue

                # Skip header rows
                if holder_name.upper() == "NAME":
                    continue

                # Parse License Number from "CFC056678Cert Plumbing" format
                # Split at the last digit-to-alpha boundary
                lic_match = re.match(r"^(.*\d)(\D.*)$", lic_num_rank)
                if lic_match:
                    lic_number = lic_match.group(1)
                else:
                    lic_number = lic_num_rank.split()[0] if lic_num_rank else ""

                # Parse Status/Expires from "Current, Active08/31/2026"
                exp_match = re.search(
                    r"(\d{2}/\d{2}/\d{4})\s*$", status_expires
                )
                if exp_match:
                    status_text = status_expires[
                        : exp_match.start()
                    ].strip()
                    exp_date_str = exp_match.group(1)
                else:
                    status_text = status_expires
                    exp_date_str = None

                # Determine license status
                status_lower = status_text.lower()
                if "current" in status_lower or "active" in status_lower:
                    status = LicenseStatus.ACTIVE
                elif "expired" in status_lower:
                    status = LicenseStatus.EXPIRED
                elif "null" in status_lower or "void" in status_lower:
                    status = LicenseStatus.CANCELLED
                elif "inactive" in status_lower:
                    status = LicenseStatus.INACTIVE
                else:
                    status = LicenseStatus.OTHER

                # Parse expiration date
                expiration_date = None
                if exp_date_str:
                    try:
                        parts = exp_date_str.split("/")
                        from datetime import date as _date

                        expiration_date = _date(
                            int(parts[2]), int(parts[0]), int(parts[1])
                        )
                    except (ValueError, IndexError):
                        pass

                lic = License(
                    license_number=lic_number or "N/A",
                    license_type=lic_type or "Professional License",
                    status=status,
                    state="FL",
                    holder_name=holder_name,
                    expiration_date=expiration_date,
                    source_url=DBPR_SEARCH_URL,
                    raw_data={
                        "status_text": status_text,
                        "name_type": name_type,
                        "raw_lic_num_rank": lic_num_rank,
                        "raw_status_expires": status_expires,
                    },
                )

                yield CollectorResult(
                    category="licenses",
                    state="FL",
                    data=lic,
                    source="Florida DBPR",
                )
                count += 1

            logger.info("FL DBPR: returned %d license results", count)

        except Exception as e:
            logger.error("FL DBPR license search failed: %s", e)
        finally:
            await page.close()
