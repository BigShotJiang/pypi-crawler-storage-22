"""
Georgia state collector.

Sources:
- GREC (Georgia Real Estate Commission): Real estate license lookups
  https://ata.grec.state.ga.us/Account/Search (working search form)
- Georgia Secretary of State (ecorp): Business entity search  
  https://ecorp.sos.ga.gov/BusinessSearch (Cloudflare protected)
"""

from __future__ import annotations

import logging
import re
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.models import (
    Address,
    Business,
    CollectorResult,
    EntityStatus,
    License,
    LicenseStatus,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import clean_text, parse_html
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

# --- GREC (Real Estate) ---

GREC_SEARCH_URL = "https://ata.grec.state.ga.us/Account/Search"

# --- Georgia SOS ecorp (Business Entity) ---

GA_ECORP_SEARCH_URL = "https://ecorp.sos.ga.gov/BusinessSearch"

LICENSE_STATUS_MAP = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
    "REVOKED": LicenseStatus.REVOKED,
    "SUSPENDED": LicenseStatus.SUSPENDED,
}

@StateRegistry.register
class GeorgiaCollector(BaseStateCollector):
    """Collector for Georgia government data.
    
    GREC license search: working HTTP form at ata.grec.state.ga.us.
    ecorp business search: Cloudflare blocked, needs browser.
    """

    needs_browser_for = [DataCategory.BUSINESSES]

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="GA",
            name="Georgia",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "Georgia Real Estate Commission (GREC) - ATA Portal",
                "Georgia Secretary of State (ecorp)",
            ],
            notes="License search works with HTTP, business search needs browser (Cloudflare).",
        )

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Georgia GREC real estate license search via HTTP form.

        The form at ata.grec.state.ga.us/Account/Search uses
        ASP.NET anti-forgery tokens.  Entity types: RE-PR (real estate),
        AP-PR (appraiser), Company, School, Instructor.

        Results table columns:
        Full Name | License | License Type | License Status |
        Renewal Due Date | Firm Name | Firm Role | History
        """
        query = params.query
        if not query:
            logger.warning("GA GREC: query is required")
            return

        count = 0
        max_results = params.max_results

        try:
            # Step 1: GET page to obtain CSRF token
            initial = await self.client.get(GREC_SEARCH_URL)
            tree = parse_html(initial.text)
            token = ""
            for inp in tree.css('input[name="__RequestVerificationToken"]'):
                token = inp.attributes.get("value", "")

            # Split query into last and first name if possible
            parts = query.strip().split(None, 1)
            last_name = parts[0] if parts else query

            # Step 2: POST with token and form fields
            form_data = {
                "__RequestVerificationToken": token,
                "EntityType": "RE-PR",
                "LastName": last_name,
                "AuthorizationNumber": "",
                "City": params.city or "",
                "submit": "Search",
            }

            response = await self.client.post(GREC_SEARCH_URL, data=form_data)
            html = response.text
            tree = parse_html(html)

            # Parse results table
            rows = tree.css("table tr")
            for row in rows:
                if count >= max_results:
                    break

                cells = row.css("td")
                if len(cells) < 4:
                    continue

                holder_name = clean_text(cells[0].text(deep=True))
                license_number = clean_text(cells[1].text(deep=True))
                license_type = clean_text(cells[2].text(deep=True)) if len(cells) > 2 else "Real Estate"
                status_text = clean_text(cells[3].text(deep=True)) if len(cells) > 3 else ""
                renewal_date = clean_text(cells[4].text(deep=True)) if len(cells) > 4 else ""
                firm_name = clean_text(cells[5].text(deep=True)) if len(cells) > 5 else ""

                if not holder_name or not license_number:
                    continue

                # Skip header rows
                if "name" in holder_name.lower() or "license" in license_number.lower():
                    continue

                # Map status
                status = LicenseStatus.ACTIVE
                if status_text:
                    st_upper = status_text.upper().strip()
                    status = LICENSE_STATUS_MAP.get(st_upper, LicenseStatus.OTHER)
                    # Handle extra statuses
                    if "LAPSED" in st_upper:
                        status = LicenseStatus.EXPIRED
                    elif "DECEASED" in st_upper:
                        status = LicenseStatus.INACTIVE

                lic = License(
                    license_number=license_number,
                    license_type=license_type or "Real Estate",
                    status=status,
                    state="GA",
                    holder_name=holder_name,
                    source_url=GREC_SEARCH_URL,
                    raw_data={
                        "status_text": status_text,
                        "renewal_date": renewal_date,
                        "firm_name": firm_name,
                    },
                )

                yield CollectorResult(
                    category="licenses",
                    state="GA",
                    data=lic,
                    source="Georgia GREC",
                )
                count += 1

            logger.info("GA GREC: returned %d license results", count)

        except Exception as e:
            logger.error("GA GREC license search failed: %s", e)

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Georgia ecorp business entity search via browser automation.
        
        The ecorp system is Cloudflare protected and requires browser.
        """
        query = params.query
        if not query:
            logger.warning("GA ecorp: query is required")
            return

        if not self.has_browser:
            logger.warning(
                "GA ecorp requires browser automation. Initialize with use_browser=True."
            )
            return

        try:
            page = await self.browser.new_page()
        except Exception as e:
            logger.error("GA ecorp: failed to create browser page: %s", e)
            return

        count = 0
        max_results = params.max_results

        try:
            await page.goto(
                GA_ECORP_SEARCH_URL,
                wait_until="domcontentloaded",
                timeout=20000,
            )

            # Wait for Cloudflare check to complete
            await page.wait_for_timeout(5000)

            # Look for search input
            search_input = await page.query_selector(
                'input[name="businessName"], input[name="name"], input[type="text"], #businessName'
            )
            
            if search_input:
                await search_input.fill(query)
                
                # Submit search
                submit_btn = await page.query_selector(
                    'button[type="submit"], input[type="submit"], button:has-text("Search")'
                )
                if submit_btn:
                    await submit_btn.click()
                else:
                    await page.keyboard.press("Enter")

                await page.wait_for_load_state("domcontentloaded", timeout=15000)
                await page.wait_for_timeout(3000)  # Wait for JS results

                html = await page.content()
                tree = parse_html(html)

                # Parse results
                rows = tree.css("table tr, .result-row, .business-result")
                for row in rows:
                    if count >= max_results:
                        break
                        
                    cells = row.css("td")
                    if len(cells) >= 2:
                        name = clean_text(cells[0].text(deep=True))
                        filing_number = clean_text(cells[1].text(deep=True))
                        status_text = clean_text(cells[2].text(deep=True)) if len(cells) > 2 else "ACTIVE"
                        
                        if name and "entity name" not in name.lower():
                            status = EntityStatus.ACTIVE
                            if status_text:
                                st = status_text.lower()
                                if "inactive" in st:
                                    status = EntityStatus.INACTIVE
                                elif "dissolved" in st:
                                    status = EntityStatus.DISSOLVED

                            biz = Business(
                                name=name,
                                state="GA",
                                filing_number=filing_number,
                                status=status,
                                source_url=GA_ECORP_SEARCH_URL,
                                raw_data={"status_text": status_text},
                            )

                            yield CollectorResult(
                                category="businesses",
                                state="GA",
                                data=biz,
                                source="Georgia SOS ecorp",
                            )
                            count += 1
            else:
                logger.warning("GA ecorp: could not find search input field")

            logger.info("GA ecorp: returned %d business results", count)

        except Exception as e:
            logger.error("GA ecorp business search failed: %s", e)
        finally:
            await page.close()