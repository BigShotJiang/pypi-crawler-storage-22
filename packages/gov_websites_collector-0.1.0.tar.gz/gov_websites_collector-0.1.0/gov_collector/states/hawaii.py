"""
Hawaii state collector.

Sources:
- DCCA/PVL (Department of Commerce & Consumer Affairs / Professional
  & Vocational Licensing): License search
  https://mypvl.dcca.hawaii.gov/public-license-search/
  WordPress site with jQuery/DataTables — behind Cloudflare, needs proxy.
  Search tabs: License #, Business/Individual, Pending Application.

- Hawaii Business Express (HBE): Business entity search
  https://hbe.ehawaii.gov/documents/search.html
  NOTE: HBE API often fails; HTML fallback unreliable. Kept but may not work.
"""

from __future__ import annotations

import asyncio
import logging
import re
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.exceptions import ParseError, ScrapingError
from gov_collector.models import (
    Address,
    Business,
    CollectorResult,
    EntityStatus,
    EntityType,
    License,
    LicenseStatus,
    Person,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import (
    clean_text,
    extract_table_rows,
    extract_text,
    parse_html,
    parse_address_text,
)
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

# --- DCCA/PVL (Professional Licensing) ---
# New URL (old pvl.ehawaii.gov redirects or is blocked by Cloudflare)
PVL_SEARCH_URL = "https://mypvl.dcca.hawaii.gov/public-license-search/"

HI_LICENSE_STATUS_MAP: dict[str, LicenseStatus] = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "CURRENT": LicenseStatus.ACTIVE,
    "FORFEITED": LicenseStatus.EXPIRED,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
    "SUSPENDED": LicenseStatus.SUSPENDED,
    "REVOKED": LicenseStatus.REVOKED,
    "CANCELLED": LicenseStatus.CANCELLED,
    "PENDING": LicenseStatus.PENDING,
    "RESTORED": LicenseStatus.ACTIVE,
    "TERMINATED": LicenseStatus.CANCELLED,
}

HI_LICENSE_TYPES: dict[str, str] = {
    "RS": "Real Estate Salesperson",
    "RB": "Real Estate Broker",
    "RBC": "Real Estate Broker-in-Charge",
    "PB": "Principal Broker",
}

# --- Hawaii Business Express (HBE) ---
HBE_SEARCH_URL = "https://hbe.ehawaii.gov/documents/search.html"
HBE_API_URL = "https://hbe.ehawaii.gov/documents/api/search"

HI_ENTITY_TYPE_MAP: dict[str, EntityType] = {
    "DOMESTIC LLC": EntityType.LLC,
    "FOREIGN LLC": EntityType.LLC,
    "LIMITED LIABILITY COMPANY": EntityType.LLC,
    "DOMESTIC PROFIT CORPORATION": EntityType.CORPORATION,
    "FOREIGN PROFIT CORPORATION": EntityType.CORPORATION,
    "DOMESTIC CORPORATION": EntityType.CORPORATION,
    "FOREIGN CORPORATION": EntityType.CORPORATION,
    "CORPORATION": EntityType.CORPORATION,
    "DOMESTIC NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "FOREIGN NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "NONPROFIT": EntityType.NONPROFIT,
    "LIMITED PARTNERSHIP": EntityType.LP,
    "LIMITED LIABILITY PARTNERSHIP": EntityType.LLP,
    "GENERAL PARTNERSHIP": EntityType.PARTNERSHIP,
    "PARTNERSHIP": EntityType.PARTNERSHIP,
    "SOLE PROPRIETORSHIP": EntityType.SOLE_PROPRIETORSHIP,
    "TRADE NAME": EntityType.OTHER,
}

HI_STATUS_MAP: dict[str, EntityStatus] = {
    "ACTIVE": EntityStatus.ACTIVE,
    "REGISTERED": EntityStatus.ACTIVE,
    "GOOD STANDING": EntityStatus.ACTIVE,
    "ADMINISTRATIVELY TERMINATED": EntityStatus.DISSOLVED,
    "TERMINATED": EntityStatus.DISSOLVED,
    "DISSOLVED": EntityStatus.DISSOLVED,
    "WITHDRAWN": EntityStatus.WITHDRAWN,
    "CANCELLED": EntityStatus.DISSOLVED,
    "SUSPENDED": EntityStatus.SUSPENDED,
    "INACTIVE": EntityStatus.INACTIVE,
    "CONVERTED": EntityStatus.CONVERTED,
    "MERGED": EntityStatus.MERGED,
    "EXPIRED": EntityStatus.DISSOLVED,
    "DELINQUENT": EntityStatus.ACTIVE,
}


@StateRegistry.register
class HawaiiCollector(BaseStateCollector):
    """Collector for Hawaii government data."""

    needs_browser_for = [DataCategory.LICENSES]  # Cloudflare protection

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="HI",
            name="Hawaii",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "Hawaii DCCA Professional & Vocational Licensing (PVL)",
                "Hawaii Business Express (HBE)",
            ],
            notes=(
                "License search requires browser + proxy (Cloudflare). "
                "Business search uses HTTP API (may be unreliable)."
            ),
        )

    # ------------------------------------------------------------------ #
    #  Lifecycle — auto-inject proxy for Cloudflare bypass
    # ------------------------------------------------------------------ #

    async def __aenter__(self):
        """Ensure a proxy is configured when using Camoufox (Cloudflare)."""
        if self._use_camoufox and not self._proxy:
            # Try to load proxy from environment variable
            import os
            env_proxy = os.environ.get("GOV_COLLECTOR_PROXY")
            if env_proxy:
                self._proxy = env_proxy
                logger.info(
                    "HI: auto-configured proxy from GOV_COLLECTOR_PROXY env var"
                )
            else:
                logger.warning(
                    "HI: Camoufox enabled but no proxy configured. "
                    "Set GOV_COLLECTOR_PROXY env var or pass proxy= parameter. "
                    "Cloudflare-protected sites may not work without a proxy."
                )
        return await super().__aenter__()

    # ------------------------------------------------------------------ #
    #  License Search (PVL)
    # ------------------------------------------------------------------ #

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search Hawaii PVL for professional/vocational licenses.

        The site at mypvl.dcca.hawaii.gov uses a WordPress REST API
        backed by Salesforce.  Every search is gated by reCAPTCHA v2.

        Flow:
        1. Load page (Camoufox + proxy bypasses Cloudflare).
        2. Extract the WP REST ``pvlsc_nonce`` from inline JS.
        3. Ask ``/wp-json/pvlsc/v1/check_captcha`` whether a challenge
           is required.
        4. If required, try to auto-solve the reCAPTCHA checkbox (works
           when Google gives a trust pass — no image challenge).
        5. Build a SOQL WHERE clause and call
           ``/wp-json/pvlsc/v1/get_list`` via ``page.evaluate()``.
        """
        if not params.query and not params.license_number:
            logger.warning(
                "HI PVL: query (name) or license_number is required"
            )
            return

        if not self.has_browser:
            logger.warning(
                "HI PVL requires browser automation (Cloudflare). "
                "Use use_camoufox=True."
            )
            return

        page = await self.browser.new_page()
        count = 0
        try:
            await page.goto(
                PVL_SEARCH_URL,
                wait_until="networkidle",
                timeout=45000,
            )
            await asyncio.sleep(3)

            # ---- Extract nonce from inline <script> ----
            html = await page.content()
            nonce_match = re.search(
                r'var\s+pvlsc_nonce\s*=\s*"([a-f0-9]+)"', html
            )
            if not nonce_match:
                logger.error("HI PVL: could not find pvlsc_nonce")
                return
            nonce = nonce_match.group(1)
            logger.debug("HI PVL: nonce=%s", nonce)

            # ---- Check if captcha is needed ----
            captcha_check = await page.evaluate(
                """async (nonce) => {
                    const body = new URLSearchParams();
                    body.append('_wpnonce', nonce);
                    const resp = await fetch(
                        '/wp-json/pvlsc/v1/check_captcha',
                        {method:'POST', body,
                         headers:{'Content-Type':
                                  'application/x-www-form-urlencoded'}}
                    );
                    return await resp.json();
                }""",
                nonce,
            )
            need_captcha = captcha_check.get("show_captcha", True)
            logger.debug("HI PVL: need captcha=%s", need_captcha)

            if need_captcha:
                # Attempt reCAPTCHA auto-solve: click checkbox, hope for
                # no image challenge.
                solved = await self._attempt_recaptcha(page, nonce)
                if not solved:
                    logger.warning(
                        "HI PVL: reCAPTCHA could not be auto-solved "
                        "(image challenge). Automated search blocked."
                    )
                    return
                logger.info("HI PVL: reCAPTCHA auto-solved!")

            # ---- Build SOQL WHERE clause ----
            import json as _json

            where = self._build_pvl_where(params)
            payload = _json.dumps(
                {"nonce": nonce, "where": where, "limit": params.max_results}
            )

            raw = await page.evaluate(
                """async (payload) => {
                    const p = JSON.parse(payload);
                    const body = new URLSearchParams();
                    body.append('module', 'License__c');
                    body.append('where', p.where);
                    body.append('_wpnonce', p.nonce);
                    body.append('limit', String(p.limit));
                    const resp = await fetch(
                        '/wp-json/pvlsc/v1/get_list',
                        {method:'POST', body,
                         headers:{'Content-Type':
                                  'application/x-www-form-urlencoded'}}
                    );
                    return await resp.text();
                }""",
                payload,
            )

            try:
                import json

                data = json.loads(raw)
            except Exception:
                logger.error("HI PVL: bad JSON from get_list: %s", raw[:200])
                return

            if data.get("error"):
                logger.warning("HI PVL API error: %s", data.get("message"))
                return

            records = data.get("data", [])
            logger.debug("HI PVL: got %d records from API", len(records))

            for rec in records:
                if count >= params.max_results:
                    break
                result = self._pvl_record_to_result(rec)
                if result:
                    yield result
                    count += 1

        except Exception as e:
            logger.error("HI PVL license search failed: %s", e)
            return
        finally:
            await page.close()

        logger.info("HI PVL: returned %d license results", count)

    # ---- reCAPTCHA helpers ----

    async def _attempt_recaptcha(self, page, nonce: str) -> bool:
        """Try to auto-solve the reCAPTCHA v2 checkbox.

        Returns True if solved, False if an image challenge appeared.
        """
        # The captcha needs grecaptcha to be rendered first.
        # Trigger the search button to make the page show the captcha.
        # Use the Business/Individual tab by default.
        try:
            await page.click("#nav-business-individual-tab")
            await asyncio.sleep(0.5)
        except Exception:
            pass

        # Fill something so the button handler doesn't bail
        try:
            await page.fill("#business_individual", "test")
        except Exception:
            pass

        try:
            await page.click("#business_individual-search-btn")
        except Exception:
            pass
        await asyncio.sleep(2)

        # Find the visible reCAPTCHA iframe and click the checkbox
        frames = await page.query_selector_all('iframe[title="reCAPTCHA"]')
        for frame_el in frames:
            box = await frame_el.bounding_box()
            if not box or box["width"] == 0:
                continue

            frame = await frame_el.content_frame()
            if not frame:
                continue

            checkbox = await frame.query_selector(
                "#recaptcha-anchor, .recaptcha-checkbox"
            )
            if not checkbox:
                continue

            await checkbox.click()
            # Wait up to 10 seconds for auto-solve
            for _ in range(20):
                await asyncio.sleep(0.5)
                checked = await frame.query_selector(
                    ".recaptcha-checkbox-checked"
                )
                if checked:
                    break
            else:
                return False  # image challenge appeared

            # Extract the response token
            token = await page.evaluate(
                """() => {
                    try { return grecaptcha.getResponse(1); }
                    catch(e) {
                        try { return grecaptcha.getResponse(0); }
                        catch(e2) { return ''; }
                    }
                }"""
            )
            if not token:
                return False

            # Validate with server
            import json as _json

            validated = await page.evaluate(
                """async (params) => {
                    const p = JSON.parse(params);
                    const body = new URLSearchParams();
                    body.append('captcha_code', p.token);
                    body.append('_wpnonce', p.nonce);
                    const resp = await fetch(
                        '/wp-json/pvlsc/v1/validate_captcha',
                        {method:'POST', body,
                         headers:{'Content-Type':
                                  'application/x-www-form-urlencoded'}}
                    );
                    return await resp.json();
                }""",
                _json.dumps({"token": token, "nonce": nonce}),
            )
            return bool(validated.get("success"))

        return False

    # ---- SOQL WHERE builder ----

    @staticmethod
    def _build_pvl_where(params: SearchParams) -> str:
        """Build a SOQL WHERE clause for the PVL License__c object."""
        if params.license_number:
            lic = params.license_number.strip().replace("'", "\\'")
            return (
                f"(Name = '{lic}' OR "
                f"TemporaryLicenseNumber__c = '{lic}')"
            )

        # Name search — search across name-for-search fields
        q = params.query.strip().replace("'", "\\'")
        parts = q.split()
        if not parts:
            return "Name != null"

        # Build OR conditions across first/last/business name fields
        clauses = []
        for part in parts:
            p = part.replace("'", "").replace("-", "")
            clauses.append(
                f"(NameForSearch__c LIKE '%{p}%' "
                f"OR BPNameForSearch__c LIKE '%{p}%' "
                f"OR Licensee__r.AccountNameForSearch__c LIKE '%{p}%')"
            )

        return " AND ".join(clauses)

    # ---- Record parser ----

    def _pvl_record_to_result(self, rec: dict) -> CollectorResult | None:
        """Convert a PVL Salesforce License__c record to CollectorResult."""
        license_number = rec.get("Name", "")
        if not license_number:
            return None

        # Extract licensee info from related objects
        licensee = rec.get("Licensee__r", {}) or {}
        holder_parts = [
            licensee.get("FirstName", ""),
            licensee.get("MiddleName", ""),
            licensee.get("LastName", ""),
        ]
        holder_name = " ".join(p for p in holder_parts if p).strip()
        if not holder_name:
            holder_name = (
                licensee.get("Name", "")
                or rec.get("Licensee__c", "")
                or "Unknown"
            )

        # License type
        license_type = (
            rec.get("RecordType", {}) or {}
        ).get("Name", "") or rec.get("LicenseType__c", "")
        if not license_type:
            # Derive from license number prefix
            prefix = license_number.split("-")[0] if "-" in license_number else ""
            license_type = HI_LICENSE_TYPES.get(
                prefix.upper(), "Professional License"
            )

        # Status
        status_text = (rec.get("Status__c") or "").upper().strip()
        status = HI_LICENSE_STATUS_MAP.get(status_text, LicenseStatus.OTHER)

        # Expiration date
        expiration_date = None
        exp_str = rec.get("ExpirationDate__c") or rec.get("ExpirationDate")
        if exp_str:
            try:
                from datetime import date as d

                parts = re.split(r"[/\-T]", exp_str)
                if len(parts) >= 3:
                    expiration_date = d(
                        int(parts[0]), int(parts[1]), int(parts[2])
                    )
            except (ValueError, IndexError):
                pass

        lic = License(
            license_number=license_number,
            license_type=license_type or "Professional License",
            status=status,
            state="HI",
            holder_name=holder_name,
            expiration_date=expiration_date,
            source_url=PVL_SEARCH_URL,
            raw_data=rec,
        )

        return CollectorResult(
            category=DataCategory.LICENSES.value,
            state="HI",
            data=lic,
            source="Hawaii DCCA PVL",
        )

    # ------------------------------------------------------------------ #
    #  Business Entity Search (HBE)  —  HTTP only, may be unreliable
    # ------------------------------------------------------------------ #

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search Hawaii Business Express (HBE) for business entities.

        HBE has a public document search. We try an API endpoint first,
        falling back to HTML scraping.
        """
        if not params.query:
            raise ValueError(
                "'query' (business name) is required for HI business search"
            )

        # Try API endpoint
        try:
            response = await self.client.get(
                HBE_API_URL,
                params={
                    "searchTerm": params.query,
                    "searchType": "BusinessName",
                },
            )
            if response.status_code == 200:
                try:
                    data = response.json()
                    results = (
                        data
                        if isinstance(data, list)
                        else data.get("results", data.get("data", []))
                    )
                    count = 0
                    for record in results:
                        if count >= params.max_results:
                            return
                        business = self._parse_hbe_api_record(record)
                        if business:
                            yield CollectorResult(
                                category=DataCategory.BUSINESSES.value,
                                state="HI",
                                data=business,
                                source="Hawaii Business Express (HBE)",
                            )
                            count += 1
                    return
                except Exception:
                    logger.debug("HBE API parse failed, trying HTML")
        except Exception as e:
            logger.debug("HBE API not available: %s", e)

        # Fallback: HTML form scraping
        try:
            response = await self.client.get(
                HBE_SEARCH_URL,
                params={"searchTerm": params.query},
            )
            html = response.text
        except Exception as e:
            logger.error("HI HBE business search failed: %s", e)
            return

        count = 0
        rows = extract_table_rows(html)
        for row in rows:
            if count >= params.max_results:
                return
            business = self._parse_hbe_html_record(row)
            if business:
                yield CollectorResult(
                    category=DataCategory.BUSINESSES.value,
                    state="HI",
                    data=business,
                    source="Hawaii Business Express (HBE)",
                )
                count += 1

    def _parse_hbe_api_record(self, record: dict) -> Business | None:
        """Parse a single HBE API JSON record."""
        name = (
            record.get("entityName")
            or record.get("businessName")
            or record.get("name")
        )
        if not name:
            return None

        type_str = (
            record.get("entityType") or record.get("type") or ""
        ).upper()
        entity_type = HI_ENTITY_TYPE_MAP.get(type_str, EntityType.OTHER)

        status_str = (
            record.get("status") or record.get("entityStatus") or ""
        ).upper()
        status = HI_STATUS_MAP.get(status_str, EntityStatus.OTHER)

        filing_number = (
            record.get("fileNumber")
            or record.get("registrationNumber")
            or record.get("entityId")
        )

        formation_date = None
        date_str = (
            record.get("registrationDate")
            or record.get("formationDate")
            or record.get("dateFiled")
        )
        if date_str:
            try:
                parts = re.split(r"[/\-T]", date_str)
                if len(parts) >= 3:
                    from datetime import date as d

                    if len(parts[0]) == 4:
                        formation_date = d(
                            int(parts[0]), int(parts[1]), int(parts[2])
                        )
                    else:
                        formation_date = d(
                            int(parts[2]), int(parts[0]), int(parts[1])
                        )
            except (ValueError, IndexError):
                pass

        agent_name = record.get("registeredAgent") or record.get("agent")
        agent = Person(full_name=agent_name) if agent_name else None

        address = None
        addr_str = record.get("principalAddress") or record.get("address")
        if addr_str:
            address = parse_address_text(addr_str)

        return Business(
            name=name.strip(),
            entity_type=entity_type,
            status=status,
            state="HI",
            filing_number=filing_number,
            formation_date=formation_date,
            address=address,
            registered_agent=agent,
            source_url=HBE_SEARCH_URL,
            raw_data=record,
        )

    def _parse_hbe_html_record(self, row: dict[str, str]) -> Business | None:
        """Parse a single HBE HTML table row."""
        name = (
            row.get("Entity Name")
            or row.get("Business Name")
            or row.get("Name", "")
        )
        if not name:
            return None

        type_str = (row.get("Entity Type") or row.get("Type") or "").upper()
        entity_type = HI_ENTITY_TYPE_MAP.get(type_str, EntityType.OTHER)

        status_str = (row.get("Status") or "").upper().strip()
        status = HI_STATUS_MAP.get(status_str, EntityStatus.OTHER)

        filing_number = (
            row.get("File Number")
            or row.get("Registration Number")
            or row.get("ID")
        )

        formation_date = None
        date_str = (
            row.get("Registration Date")
            or row.get("Filing Date")
            or row.get("Date Filed")
        )
        if date_str:
            try:
                parts = re.split(r"[/\-]", date_str.strip())
                if len(parts) == 3:
                    from datetime import date as d

                    if len(parts[0]) == 4:
                        formation_date = d(
                            int(parts[0]), int(parts[1]), int(parts[2])
                        )
                    else:
                        formation_date = d(
                            int(parts[2]), int(parts[0]), int(parts[1])
                        )
            except (ValueError, IndexError):
                pass

        agent_name = row.get("Registered Agent") or row.get("Agent")
        agent = Person(full_name=agent_name) if agent_name else None

        return Business(
            name=name.strip(),
            entity_type=entity_type,
            status=status,
            state="HI",
            filing_number=filing_number,
            formation_date=formation_date,
            registered_agent=agent,
            source_url=HBE_SEARCH_URL,
            raw_data=row,
        )
