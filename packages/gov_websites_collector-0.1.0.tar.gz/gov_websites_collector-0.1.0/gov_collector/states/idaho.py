"""
Idaho state collector.

Sources:
- IREC (Idaho Real Estate Commission): Real estate license lookups
  https://irec.idaho.gov/licensing/license-lookup/
- Idaho Secretary of State: Business entity search
  https://sosbiz.idaho.gov/search/business
"""

from __future__ import annotations

import logging
import re
from datetime import date as date_cls
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.exceptions import ParseError, ScrapingError
from gov_collector.models import (
    Address,
    Business,
    CollectorResult,
    EntityStatus,
    EntityType,
    License,
    LicenseStatus,
    Person,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import (
    clean_text,
    extract_table_rows,
    extract_text,
    parse_address_text,
    parse_html,
)
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

# --- IREC (Real Estate) ---

IREC_SEARCH_URL = "https://irec.idaho.gov/licensing/license-lookup/"

IREC_LICENSE_STATUS_MAP = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
    "SUSPENDED": LicenseStatus.SUSPENDED,
    "REVOKED": LicenseStatus.REVOKED,
    "CANCELLED": LicenseStatus.CANCELLED,
}

# --- SOS (Business Entity) ---

SOSBIZ_SEARCH_URL = "https://sosbiz.idaho.gov/search/business"
SOSBIZ_API_URL = "https://sosbiz.idaho.gov/api/Records/businesssearch"

ID_ENTITY_TYPES = {
    "LIMITED LIABILITY COMPANY": EntityType.LLC,
    "DOMESTIC LLC": EntityType.LLC,
    "FOREIGN LLC": EntityType.LLC,
    "CORPORATION": EntityType.CORPORATION,
    "DOMESTIC CORPORATION": EntityType.CORPORATION,
    "FOREIGN CORPORATION": EntityType.CORPORATION,
    "DOMESTIC NONPROFIT": EntityType.NONPROFIT,
    "NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "LIMITED PARTNERSHIP": EntityType.LP,
    "LIMITED LIABILITY PARTNERSHIP": EntityType.LLP,
    "GENERAL PARTNERSHIP": EntityType.PARTNERSHIP,
}

ID_STATUS_MAP = {
    "ACTIVE": EntityStatus.ACTIVE,
    "GOOD STANDING": EntityStatus.ACTIVE,
    "INACTIVE": EntityStatus.INACTIVE,
    "DISSOLVED": EntityStatus.DISSOLVED,
    "ADMIN DISSOLVED": EntityStatus.DISSOLVED,
    "ADMINISTRATIVELY DISSOLVED": EntityStatus.DISSOLVED,
    "REVOKED": EntityStatus.DISSOLVED,
    "WITHDRAWN": EntityStatus.WITHDRAWN,
    "CANCELLED": EntityStatus.DISSOLVED,
    "MERGED": EntityStatus.MERGED,
}


@StateRegistry.register
class IdahoCollector(BaseStateCollector):
    """Collector for Idaho government data."""

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="ID",
            name="Idaho",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "Idaho Real Estate Commission (IREC)",
                "Idaho Secretary of State (sosbiz)",
            ],
        )

    # --- Real Estate Licenses ---

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search Idaho IREC for real estate licenses.

        Supports searching by name or license number.
        """
        if not params.query and not params.license_number:
            raise ValueError(
                "Either 'query' (name) or 'license_number' is required for ID IREC"
            )

        search_term = params.license_number or params.query or ""

        try:
            response = await self.client.get(
                IREC_SEARCH_URL,
                params={"search": search_term},
            )
            html = response.text
        except Exception as e:
            logger.error("IREC license search failed: %s", e)
            return

        count = 0
        async for result in self._parse_irec_results(html):
            yield result
            count += 1
            if count >= params.max_results:
                return

    async def _parse_irec_results(
        self, html: str
    ) -> AsyncIterator[CollectorResult]:
        """Parse IREC search results page."""
        tree = parse_html(html)

        rows = tree.css("table.results tr, table tbody tr")
        if not rows:
            logger.debug("No IREC results found")
            return

        for row in rows:
            cells = row.css("td")
            if len(cells) < 3:
                continue

            name_text = extract_text(cells[0])
            license_id = extract_text(cells[1])
            license_type = extract_text(cells[2])
            status_text = extract_text(cells[3]) if len(cells) > 3 else None
            expiry_text = extract_text(cells[4]) if len(cells) > 4 else None

            if not name_text or not license_id:
                continue

            # Map status
            status = LicenseStatus.OTHER
            if status_text:
                status = IREC_LICENSE_STATUS_MAP.get(
                    status_text.upper().strip(), LicenseStatus.OTHER
                )

            # Parse expiration date
            expiration_date = None
            if expiry_text:
                for fmt in ("%m/%d/%Y", "%Y-%m-%d"):
                    try:
                        expiration_date = date_cls.strptime(expiry_text.strip(), fmt)
                        break
                    except (ValueError, AttributeError):
                        continue

            license_obj = License(
                license_number=license_id.strip(),
                license_type=license_type or "Real Estate",
                status=status,
                state="ID",
                holder_name=name_text.strip(),
                expiration_date=expiration_date,
                source_url=IREC_SEARCH_URL,
                raw_data={
                    "name": name_text,
                    "license_type": license_type,
                    "status_text": status_text,
                    "expiry_text": expiry_text,
                },
            )

            yield CollectorResult(
                category=DataCategory.LICENSES.value,
                state="ID",
                data=license_obj,
                source="Idaho IREC",
            )

    # --- Business Entity Search ---

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search Idaho Secretary of State for business entities.

        WARNING: Idaho SOS business search is protected by Cloudflare.
        HTTP scraping may not work reliably. Consider using browser automation.
        """
        if not params.query:
            raise ValueError(
                "'query' (business name) is required for ID business search"
            )

        logger.warning(
            "ID Secretary of State business search is protected by Cloudflare. "
            "HTTP scraping may fail. Consider using browser automation for reliable results."
        )

        # Idaho sosbiz uses a JSON API similar to California bizfile
        search_payload = {
            "SearchType": "BUSINESS",
            "SearchCriteria": {
                "SearchValue": params.query,
            },
            "SearchSubType": "Keyword",
        }

        try:
            response = await self.client.post(
                SOSBIZ_API_URL,
                json=search_payload,
                headers={"Content-Type": "application/json"},
            )
            data = response.json()
        except Exception as e:
            # Fallback: try HTML scraping if API isn't available
            logger.warning("ID SOS API failed (%s), trying HTML fallback", e)
            async for result in self._scrape_sosbiz_html(params):
                yield result
            return

        results = data if isinstance(data, list) else data.get("Results", [])

        count = 0
        for record in results:
            if count >= params.max_results:
                return

            business = self._parse_sosbiz_record(record)
            if business:
                yield CollectorResult(
                    category=DataCategory.BUSINESSES.value,
                    state="ID",
                    data=business,
                    source="Idaho Secretary of State",
                )
                count += 1

    async def _scrape_sosbiz_html(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """Fallback HTML scraping for Idaho SOS business search."""
        try:
            response = await self.client.get(
                SOSBIZ_SEARCH_URL,
                params={"SearchValue": params.query},
            )
            html = response.text
        except Exception as e:
            logger.error("ID SOS HTML search failed: %s", e)
            return

        rows = extract_table_rows(html)
        count = 0
        for row in rows:
            if count >= params.max_results:
                return

            name = row.get("Entity Name") or row.get("Name", "")
            if not name:
                continue

            filing_number = row.get("Filing Number") or row.get("Entity Number")
            type_str = (row.get("Entity Type") or row.get("Type") or "").upper()
            status_str = (row.get("Status") or "").upper()

            entity_type = ID_ENTITY_TYPES.get(type_str, EntityType.OTHER)
            status = ID_STATUS_MAP.get(status_str, EntityStatus.OTHER)

            business = Business(
                name=name.strip(),
                entity_type=entity_type,
                status=status,
                state="ID",
                filing_number=filing_number,
                source_url=SOSBIZ_SEARCH_URL,
                raw_data=row,
            )

            yield CollectorResult(
                category=DataCategory.BUSINESSES.value,
                state="ID",
                data=business,
                source="Idaho Secretary of State",
            )
            count += 1

    def _parse_sosbiz_record(self, record: dict) -> Business | None:
        """Parse a single sosbiz API record into a Business model."""
        name = record.get("TITLE") or record.get("EntityName")
        if not name:
            return None

        type_str = (
            record.get("ENTITY_TYPE") or record.get("EntityType") or ""
        ).upper()
        entity_type = ID_ENTITY_TYPES.get(type_str, EntityType.OTHER)

        status_str = (
            record.get("STATUS") or record.get("Status") or ""
        ).upper()
        status = ID_STATUS_MAP.get(status_str, EntityStatus.OTHER)

        filing_number = record.get("FILING_NUMBER") or record.get("EntityNumber")

        formation_date = None
        date_str = record.get("FILING_DATE") or record.get("FormationDate")
        if date_str:
            for fmt in ("%m/%d/%Y", "%Y-%m-%d", "%m-%d-%Y"):
                try:
                    formation_date = date_cls.strptime(date_str, fmt)
                    break
                except (ValueError, AttributeError):
                    continue

        address = None
        addr_str = record.get("ADDRESS") or record.get("PrincipalAddress")
        if addr_str:
            address = parse_address_text(addr_str)

        agent_name = record.get("AGENT") or record.get("AgentForServiceOfProcess")
        agent = Person(full_name=agent_name) if agent_name else None

        return Business(
            name=name.strip(),
            entity_type=entity_type,
            status=status,
            state="ID",
            filing_number=filing_number,
            formation_date=formation_date,
            address=address,
            registered_agent=agent,
            source_url=SOSBIZ_SEARCH_URL,
            raw_data=record,
        )
