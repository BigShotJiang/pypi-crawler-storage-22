"""
Illinois state collector.

Sources:
- IDFPR (Illinois Department of Financial and Professional Regulation):
  Real estate license verification 
  https://online-dfpr.micropact.com/lookup/licenselookup.aspx (Micropact portal)
- Illinois Secretary of State: Business entity search
  https://apps.ilsos.gov/businessentitysearch/ (official business entity search)
"""

from __future__ import annotations

import logging
import re
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.models import (
    Address,
    Business,
    CollectorResult,
    EntityStatus,
    License,
    LicenseStatus,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import clean_text, parse_html
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

# --- IDFPR (Real Estate License) ---

IDFPR_SEARCH_URL = "https://online-dfpr.micropact.com/lookup/licenselookup.aspx"

# --- SOS (Business Entity) ---

ILSOS_SEARCH_URL = "https://apps.ilsos.gov/businessentitysearch/"

LICENSE_STATUS_MAP = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
    "REVOKED": LicenseStatus.REVOKED,
    "SUSPENDED": LicenseStatus.SUSPENDED,
}

ENTITY_STATUS_MAP = {
    "ACTIVE": EntityStatus.ACTIVE,
    "GOOD STANDING": EntityStatus.ACTIVE,
    "INACTIVE": EntityStatus.INACTIVE,
    "NOT IN GOOD STANDING": EntityStatus.INACTIVE,
    "DISSOLVED": EntityStatus.DISSOLVED,
    "REVOKED": EntityStatus.DISSOLVED,
}

@StateRegistry.register
class IllinoisCollector(BaseStateCollector):
    """Collector for Illinois government data.
    
    IDFPR license search: Micropact portal requires browser (captcha/JS).
    Illinois SOS business search: requires browser automation.
    """

    needs_browser_for = [DataCategory.LICENSES, DataCategory.BUSINESSES]

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="IL",
            name="Illinois",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "Illinois IDFPR (Micropact eLicensing Portal)",
                "Illinois Secretary of State (Business Entity Search)",
            ],
            notes="Both searches require browser automation (captcha/JS forms).",
        )

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Illinois IDFPR real estate license search via browser automation.
        
        The Micropact portal has human verification and JavaScript requirements.
        """
        query = params.query
        if not query:
            logger.warning("IL IDFPR: query is required")
            return

        if not self.has_browser:
            logger.warning(
                "IL IDFPR requires browser automation. Initialize with use_browser=True."
            )
            return

        try:
            page = await self.browser.new_page()
        except Exception as e:
            logger.error("IL IDFPR: failed to create browser page: %s", e)
            return

        count = 0
        max_results = params.max_results

        try:
            await page.goto(
                IDFPR_SEARCH_URL,
                wait_until="domcontentloaded",
                timeout=20000,
            )

            # Handle potential human verification
            await page.wait_for_timeout(3000)

            # Look for license lookup form
            # The form may have different field configurations
            name_input = await page.query_selector(
                'input[name="tbName"], input[name="LicenseeName"], input[type="text"]'
            )
            
            if name_input:
                await name_input.fill(query)
            else:
                # Try alternative selectors
                all_inputs = await page.query_selector_all('input[type="text"]')
                if all_inputs:
                    await all_inputs[0].fill(query)
                else:
                    logger.warning("IL IDFPR: could not find name input field")
                    return

            # Select Real Estate board if there's a dropdown
            board_select = await page.query_selector('select[name*="Board"], select[name*="board"]')
            if board_select:
                await page.select_option(board_select, label="Real Estate")

            # Submit form
            submit_btn = await page.query_selector(
                'input[type="submit"], button[type="submit"], button:has-text("Search")'
            )
            
            if submit_btn:
                await submit_btn.click()
            else:
                await page.keyboard.press("Enter")

            await page.wait_for_load_state("domcontentloaded", timeout=15000)
            await page.wait_for_timeout(2000)  # Wait for results to load

            html = await page.content()
            tree = parse_html(html)

            # Parse results table
            rows = tree.css("table tr")
            for row in rows:
                if count >= max_results:
                    break
                    
                cells = row.css("td")
                if len(cells) < 3:
                    continue

                holder_name = clean_text(cells[0].text(deep=True))
                license_number = clean_text(cells[1].text(deep=True))
                license_type = clean_text(cells[2].text(deep=True)) if len(cells) > 2 else "Real Estate"
                status_text = clean_text(cells[3].text(deep=True)) if len(cells) > 3 else ""
                city = clean_text(cells[4].text(deep=True)) if len(cells) > 4 else ""

                if not holder_name or not license_number:
                    continue
                    
                # Skip header rows
                if "name" in holder_name.lower() or "license" in license_number.lower():
                    continue

                status = LICENSE_STATUS_MAP.get(status_text.upper(), LicenseStatus.ACTIVE)
                address = Address(city=city, state="IL") if city else None

                lic = License(
                    license_number=license_number,
                    license_type=license_type or "Real Estate",
                    status=status,
                    state="IL",
                    holder_name=holder_name,
                    address=address,
                    source_url=IDFPR_SEARCH_URL,
                    raw_data={
                        "status_text": status_text,
                        "city": city,
                    },
                )

                yield CollectorResult(
                    category="licenses",
                    state="IL",
                    data=lic,
                    source="Illinois IDFPR",
                )
                count += 1

            logger.info("IL IDFPR: returned %d license results", count)

        except Exception as e:
            logger.error("IL IDFPR license search failed: %s", e)
        finally:
            await page.close()

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Illinois SOS business entity search via browser automation.
        """
        query = params.query
        if not query:
            logger.warning("IL SOS: query is required")
            return

        if not self.has_browser:
            logger.warning(
                "IL SOS requires browser automation. Initialize with use_browser=True."
            )
            return

        try:
            page = await self.browser.new_page()
        except Exception as e:
            logger.error("IL SOS: failed to create browser page: %s", e)
            return

        count = 0
        max_results = params.max_results

        try:
            await page.goto(
                ILSOS_SEARCH_URL,
                wait_until="domcontentloaded",
                timeout=20000,
            )

            # Find business name search field
            name_input = await page.query_selector(
                'input[name="businessname"], input[name="name"], input[placeholder*="name"], input[type="text"]'
            )
            
            if name_input:
                await name_input.fill(query)
            else:
                logger.warning("IL SOS: could not find business name input field")
                return

            # Submit search
            submit_btn = await page.query_selector(
                'input[type="submit"], button[type="submit"], button:has-text("Search")'
            )
            
            if submit_btn:
                await submit_btn.click()
            else:
                await page.keyboard.press("Enter")

            await page.wait_for_load_state("domcontentloaded", timeout=15000)
            await page.wait_for_timeout(3000)  # Wait for results to load

            html = await page.content()
            tree = parse_html(html)

            # Parse results
            rows = tree.css("table tr, .result-row")
            for row in rows:
                if count >= max_results:
                    break
                    
                cells = row.css("td")
                if len(cells) >= 3:
                    name = clean_text(cells[0].text(deep=True))
                    file_number = clean_text(cells[1].text(deep=True))
                    status_text = clean_text(cells[2].text(deep=True))
                    entity_type = clean_text(cells[3].text(deep=True)) if len(cells) > 3 else ""
                    
                    if name and "entity name" not in name.lower():
                        status = ENTITY_STATUS_MAP.get(status_text.upper(), EntityStatus.OTHER)

                        biz = Business(
                            name=name,
                            state="IL",
                            filing_number=file_number,
                            status=status,
                            entity_type=entity_type,
                            source_url=ILSOS_SEARCH_URL,
                            raw_data={
                                "status_text": status_text,
                                "entity_type": entity_type,
                            },
                        )

                        yield CollectorResult(
                            category="businesses",
                            state="IL",
                            data=biz,
                            source="Illinois SOS",
                        )
                        count += 1

            logger.info("IL SOS: returned %d business results", count)

        except Exception as e:
            logger.error("IL SOS business search failed: %s", e)
        finally:
            await page.close()