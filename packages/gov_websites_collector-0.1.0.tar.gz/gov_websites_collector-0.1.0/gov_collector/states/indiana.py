"""
Indiana state collector.

Sources:
- PLA (Professional Licensing Agency): Real estate license verification
  https://mylicense.in.gov/EVerification/Search.aspx
- Indiana Secretary of State: Business entity search
  https://bsd.sos.in.gov/publicbusinesssearch

Strategy: HTTP approach for both sources
- PLA uses ASP.NET WebForms with ViewState
- SOS business search uses standard form submission
"""

from __future__ import annotations

import logging
import re
from datetime import date as date_cls
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.models import (
    Address,
    Business,
    CollectorResult,
    EntityStatus,
    EntityType,
    License,
    LicenseStatus,
    Person,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import (
    clean_text,
    extract_text,
    parse_html,
    parse_address_text,
)
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

# --- Indiana PLA (License Verification) ---

IN_PLA_SEARCH_URL = "https://mylicense.in.gov/EVerification/Search.aspx"

IN_LICENSE_STATUS_MAP = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "CURRENT": LicenseStatus.ACTIVE,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
    "SUSPENDED": LicenseStatus.SUSPENDED,
    "REVOKED": LicenseStatus.REVOKED,
    "CANCELLED": LicenseStatus.CANCELLED,
    "PENDING": LicenseStatus.PENDING,
}

# --- Indiana SOS (Business Entity) ---

IN_SOS_SEARCH_URL = "https://bsd.sos.in.gov/publicbusinesssearch"

IN_ENTITY_TYPE_MAP = {
    "LIMITED LIABILITY COMPANY": EntityType.LLC,
    "DOMESTIC LIMITED LIABILITY COMPANY": EntityType.LLC,
    "FOREIGN LIMITED LIABILITY COMPANY": EntityType.LLC,
    "LLC": EntityType.LLC,
    "CORPORATION": EntityType.CORPORATION,
    "DOMESTIC CORPORATION": EntityType.CORPORATION,
    "FOREIGN CORPORATION": EntityType.CORPORATION,
    "PROFIT CORPORATION": EntityType.CORPORATION,
    "NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "NOT-FOR-PROFIT CORPORATION": EntityType.NONPROFIT,
    "LIMITED PARTNERSHIP": EntityType.LP,
    "GENERAL PARTNERSHIP": EntityType.PARTNERSHIP,
    "LIMITED LIABILITY PARTNERSHIP": EntityType.LLP,
}

IN_STATUS_MAP = {
    "ACTIVE": EntityStatus.ACTIVE,
    "GOOD STANDING": EntityStatus.ACTIVE,
    "IN GOOD STANDING": EntityStatus.ACTIVE,
    "INACTIVE": EntityStatus.INACTIVE,
    "DISSOLVED": EntityStatus.DISSOLVED,
    "SUSPENDED": EntityStatus.SUSPENDED,
    "WITHDRAWN": EntityStatus.WITHDRAWN,
    "MERGED": EntityStatus.MERGED,
    "CANCELLED": EntityStatus.DISSOLVED,
    "TERMINATED": EntityStatus.DISSOLVED,
}


@StateRegistry.register
class IndianaCollector(BaseStateCollector):
    """Collector for Indiana government data using HTTP."""

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="IN",
            name="Indiana",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "Indiana Professional Licensing Agency (PLA)",
                "Indiana Secretary of State (SOS)",
            ],
            notes="Both sources support HTTP-based scraping.",
        )

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search Indiana PLA for professional licenses using ASP.NET form.
        """
        if not params.query and not params.license_number:
            logger.warning("IN PLA: query (name) or license_number is required")
            return

        # Step 1: GET initial page to extract ViewState
        try:
            init_response = await self.client.get(IN_PLA_SEARCH_URL)
            init_html = init_response.text
        except Exception as e:
            logger.error("IN PLA initial page load failed: %s", e)
            return

        viewstate = self._extract_aspnet_field(init_html, "__VIEWSTATE")
        viewstate_gen = self._extract_aspnet_field(init_html, "__VIEWSTATEGENERATOR")
        event_validation = self._extract_aspnet_field(init_html, "__EVENTVALIDATION")

        # Build form data
        form_data = {
            "__VIEWSTATE": viewstate or "",
            "__VIEWSTATEGENERATOR": viewstate_gen or "",
            "__EVENTVALIDATION": event_validation or "",
            "ctl00$MainContent$ddlProfession": "",  # All professions
            "ctl00$MainContent$ddlLicenseType": "",  # All license types
            "ctl00$MainContent$ddlLicenseStatus": "",  # All statuses
            "ctl00$MainContent$txtFirstName": "",
            "ctl00$MainContent$txtLastName": "",
            "ctl00$MainContent$txtLicenseNumber": "",
            "ctl00$MainContent$txtCity": "",
            "ctl00$MainContent$ddlState": "",
            "ctl00$MainContent$txtZipCode": "",
            "ctl00$MainContent$txtDBA": "",
            "ctl00$MainContent$btnSearch": "Search",
        }

        if params.license_number:
            form_data["ctl00$MainContent$txtLicenseNumber"] = params.license_number
        elif params.query:
            # Try to split name
            parts = params.query.strip().split(maxsplit=1)
            form_data["ctl00$MainContent$txtLastName"] = parts[0]
            if len(parts) > 1:
                form_data["ctl00$MainContent$txtFirstName"] = parts[1]

        if params.city:
            form_data["ctl00$MainContent$txtCity"] = params.city

        # Step 2: POST search
        try:
            response = await self.client.post(IN_PLA_SEARCH_URL, data=form_data)
            html = response.text
        except Exception as e:
            logger.error("IN PLA license search failed: %s", e)
            return

        tree = parse_html(html)
        
        # Look for results table
        rows = tree.css("table tr, .search-results tr, #gvResults tr")
        
        count = 0
        for row in rows:
            if count >= params.max_results:
                break

            cells = row.css("td")
            if len(cells) < 3:
                continue

            # Common layout: Name, License#, Type, Status, Expiration
            name = extract_text(cells[0])
            license_num = extract_text(cells[1]) if len(cells) > 1 else None
            license_type = extract_text(cells[2]) if len(cells) > 2 else None
            status_text = extract_text(cells[3]) if len(cells) > 3 else None
            exp_text = extract_text(cells[4]) if len(cells) > 4 else None

            if not name or not license_num:
                continue

            # Skip header rows
            if "name" in name.lower() or "license" in name.lower():
                continue

            status = LicenseStatus.ACTIVE
            if status_text:
                status = IN_LICENSE_STATUS_MAP.get(
                    status_text.upper().strip(), LicenseStatus.OTHER
                )

            expiration_date = self._parse_date(exp_text)

            license_obj = License(
                license_number=license_num.strip(),
                license_type=license_type.strip() if license_type else "Professional License",
                status=status,
                state="IN",
                holder_name=name.strip(),
                expiration_date=expiration_date,
                source_url=IN_PLA_SEARCH_URL,
                raw_data={
                    "status_text": status_text,
                    "expiration": exp_text,
                },
            )

            yield CollectorResult(
                category=DataCategory.LICENSES.value,
                state="IN",
                data=license_obj,
                source="Indiana Professional Licensing Agency (PLA)",
            )
            count += 1

        logger.info("IN PLA: returned %d license results", count)

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search Indiana Secretary of State for business entities.
        """
        if not params.query:
            logger.warning("IN SOS: query (business name) is required")
            return

        form_data = {
            "searchType": "Contains",  # or "Starts With", "Exact Match"
            "businessName": params.query,
            "businessId": "",
            "filingNumber": "",
            "registeredAgentName": "",
            "incorporatorName": "",
            # Advanced search fields
            "entityType": "",
            "entityStatus": "",
            "nameType": "",
            "streetAddress": "",
            "city": "",
            "zipCode": "",
        }

        try:
            response = await self.client.post(IN_SOS_SEARCH_URL, data=form_data)
            html = response.text
        except Exception as e:
            logger.error("IN SOS business search failed: %s", e)
            return

        tree = parse_html(html)
        
        # Look for results in various table formats
        rows = tree.css("table tr, .search-results tr, .results-table tr, tbody tr")
        
        count = 0
        for row in rows:
            if count >= params.max_results:
                break

            cells = row.css("td")
            if len(cells) < 2:
                continue

            # Common layout: Name, ID/Filing#, Type, Status
            name = extract_text(cells[0])
            filing_number = extract_text(cells[1]) if len(cells) > 1 else None
            entity_type_text = extract_text(cells[2]) if len(cells) > 2 else None
            status_text = extract_text(cells[3]) if len(cells) > 3 else None

            if not name:
                continue

            # Skip header rows
            if "name" in name.lower() or "entity" in name.lower():
                continue

            entity_type = EntityType.OTHER
            if entity_type_text:
                entity_type = IN_ENTITY_TYPE_MAP.get(
                    entity_type_text.upper().strip(), EntityType.OTHER
                )

            status = EntityStatus.OTHER
            if status_text:
                status = IN_STATUS_MAP.get(
                    status_text.upper().strip(), EntityStatus.OTHER
                )

            business = Business(
                name=name.strip(),
                entity_type=entity_type,
                status=status,
                state="IN",
                filing_number=filing_number,
                source_url=IN_SOS_SEARCH_URL,
                raw_data={
                    "entity_type_text": entity_type_text,
                    "status_text": status_text,
                },
            )

            yield CollectorResult(
                category=DataCategory.BUSINESSES.value,
                state="IN",
                data=business,
                source="Indiana Secretary of State (SOS)",
            )
            count += 1

        logger.info("IN SOS: returned %d business results", count)

    def _extract_aspnet_field(self, html: str, field_name: str) -> str | None:
        """Extract ASP.NET hidden form field value."""
        pattern = rf'<input[^>]*name="{re.escape(field_name)}"[^>]*value="([^"]*)"'
        match = re.search(pattern, html, re.IGNORECASE)
        if match:
            return match.group(1)
        return None

    def _parse_date(self, date_str: str | None) -> date_cls | None:
        """Parse a date string in common formats."""
        if not date_str:
            return None
        
        date_str = date_str.strip()
        
        # MM/DD/YYYY format
        match = re.match(r"(\d{1,2})/(\d{1,2})/(\d{4})", date_str)
        if match:
            try:
                month, day, year = match.groups()
                return date_cls(int(year), int(month), int(day))
            except ValueError:
                pass
        
        # ISO format
        try:
            return date_cls.fromisoformat(date_str)
        except (ValueError, AttributeError):
            pass
        
        return None