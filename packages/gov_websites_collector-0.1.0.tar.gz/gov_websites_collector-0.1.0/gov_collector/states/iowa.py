"""
Iowa state collector.

Sources:
- Iowa Professional Licensing Board: Real estate license lookups
  https://ia-plb.my.site.com/LicenseSearchPage
  NOTE: elicense.iowa.gov DNS is dead as of Feb 2026; PLB uses Salesforce now.
- Iowa Secretary of State: Business entity search
  https://sos.iowa.gov/search/business/search.aspx
  ASP.NET form with reCAPTCHA; requires Camoufox browser automation.
"""

from __future__ import annotations

import asyncio
import logging
import re
from datetime import date as date_cls
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.exceptions import ParseError, ScrapingError
from gov_collector.models import (
    Address,
    Business,
    CollectorResult,
    EntityStatus,
    EntityType,
    License,
    LicenseStatus,
    Person,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import (
    clean_text,
    extract_table_rows,
    extract_text,
    parse_address_text,
    parse_html,
)
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

# --- Iowa Professional Licensing Board (Real Estate License) ---
# NOTE: elicense.iowa.gov is DNS-dead as of Feb 2026.
# The PLB has moved to a Salesforce-based site.
IREC_SEARCH_URL = "https://ia-plb.my.site.com/LicenseSearchPage"

IA_LICENSE_STATUS_MAP = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "CURRENT": LicenseStatus.ACTIVE,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
    "SUSPENDED": LicenseStatus.SUSPENDED,
    "REVOKED": LicenseStatus.REVOKED,
    "CANCELLED": LicenseStatus.CANCELLED,
    "LAPSED": LicenseStatus.EXPIRED,
}

# --- SOS (Business Entity) ---

IASOS_SEARCH_URL = "https://sos.iowa.gov/search/business/search.aspx"

IA_ENTITY_TYPES = {
    "DOMESTIC LIMITED LIABILITY COMPANY": EntityType.LLC,
    "FOREIGN LIMITED LIABILITY COMPANY": EntityType.LLC,
    "LLC": EntityType.LLC,
    "DOMESTIC PROFIT CORPORATION": EntityType.CORPORATION,
    "DOMESTIC BUSINESS CORPORATION": EntityType.CORPORATION,
    "FOREIGN PROFIT CORPORATION": EntityType.CORPORATION,
    "FOREIGN BUSINESS CORPORATION": EntityType.CORPORATION,
    "CORPORATION": EntityType.CORPORATION,
    "DOMESTIC NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "FOREIGN NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "NONPROFIT": EntityType.NONPROFIT,
    "NOT FOR PROFIT": EntityType.NONPROFIT,
    "DOMESTIC LIMITED PARTNERSHIP": EntityType.LP,
    "FOREIGN LIMITED PARTNERSHIP": EntityType.LP,
    "LP": EntityType.LP,
    "LIMITED LIABILITY PARTNERSHIP": EntityType.LLP,
    "LLP": EntityType.LLP,
    "GENERAL PARTNERSHIP": EntityType.PARTNERSHIP,
}

IA_STATUS_MAP = {
    "ACTIVE": EntityStatus.ACTIVE,
    "GOOD STANDING": EntityStatus.ACTIVE,
    "IN GOOD STANDING": EntityStatus.ACTIVE,
    "INACTIVE": EntityStatus.INACTIVE,
    "DISSOLVED": EntityStatus.DISSOLVED,
    "ADMIN DISSOLVED": EntityStatus.DISSOLVED,
    "ADMINISTRATIVELY DISSOLVED": EntityStatus.DISSOLVED,
    "VOLUNTARILY DISSOLVED": EntityStatus.DISSOLVED,
    "REVOKED": EntityStatus.DISSOLVED,
    "CANCELLED": EntityStatus.DISSOLVED,
    "WITHDRAWN": EntityStatus.WITHDRAWN,
    "MERGED": EntityStatus.MERGED,
    "CONVERTED": EntityStatus.CONVERTED,
}


@StateRegistry.register
class IowaCollector(BaseStateCollector):
    """Collector for Iowa government data."""

    needs_browser_for = [DataCategory.LICENSES, DataCategory.BUSINESSES]

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="IA",
            name="Iowa",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "Iowa Professional Licensing Board (Salesforce)",
                "Iowa Secretary of State",
            ],
            notes="Iowa SOS uses reCAPTCHA; license site moved to Salesforce.",
        )

    # --- Real Estate Licenses ---
    # NOTE: elicense.iowa.gov is DNS-dead as of Feb 2026.
    # The PLB migrated to ia-plb.my.site.com (Salesforce).

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search Iowa Professional Licensing Board for real estate licenses.
        Uses browser automation for Salesforce-based interface.
        """
        if not params.query and not params.license_number:
            logger.warning("IA PLB: query or license_number is required")
            return

        if not self.has_browser:
            logger.warning(
                "IA Professional Licensing Board requires browser automation. "
                "Initialize with use_browser=True."
            )
            return

        try:
            page = await self.browser.new_page()
        except Exception as e:
            logger.error("IA PLB: failed to create browser page: %s", e)
            return

        count = 0
        max_results = params.max_results

        try:
            await page.goto(
                IREC_SEARCH_URL,
                wait_until="domcontentloaded",
                timeout=15000,
            )

            # Wait for the search form to load
            await page.wait_for_selector("input, select", timeout=10000)

            if params.license_number:
                license_input = await page.query_selector(
                    'input[name*="License"], input[id*="license"], input[placeholder*="license" i]'
                )
                if license_input:
                    await license_input.fill(params.license_number)
            elif params.query:
                parts = params.query.strip().split(maxsplit=1)
                last_name_input = await page.query_selector(
                    'input[name*="Last"], input[id*="last"], input[placeholder*="last" i]'
                )
                if last_name_input:
                    await last_name_input.fill(parts[0])
                if len(parts) > 1:
                    first_name_input = await page.query_selector(
                        'input[name*="First"], input[id*="first"], input[placeholder*="first" i]'
                    )
                    if first_name_input:
                        await first_name_input.fill(parts[1])

            submit_button = await page.query_selector(
                'input[type="submit"], button[type="submit"], button:has-text("Search")'
            )
            if submit_button:
                await submit_button.click()
            else:
                await page.keyboard.press("Enter")

            await page.wait_for_load_state("domcontentloaded", timeout=15000)
            html = await page.content()
            tree = parse_html(html)

            rows = tree.css("table tr, div.search-result, div.result-row")
            for row in rows:
                if count >= max_results:
                    break
                cells = row.css("td")
                if len(cells) >= 3:
                    holder_name = clean_text(cells[0].text(deep=True))
                    license_id = clean_text(cells[1].text(deep=True))
                    license_type = clean_text(cells[2].text(deep=True))
                    status_text = clean_text(cells[3].text(deep=True)) if len(cells) > 3 else ""
                else:
                    text = clean_text(row.text(deep=True))
                    if not text:
                        continue
                    lines = [line.strip() for line in text.split('\n') if line.strip()]
                    if len(lines) < 2:
                        continue
                    holder_name = lines[0]
                    license_id = lines[1] if len(lines) > 1 else ""
                    license_type = "Real Estate"
                    status_text = "ACTIVE"

                if not holder_name or not license_id:
                    continue

                status = IA_LICENSE_STATUS_MAP.get(
                    status_text.upper().strip(), LicenseStatus.ACTIVE
                )

                license_obj = License(
                    license_number=license_id.strip(),
                    license_type=license_type or "Real Estate",
                    status=status,
                    state="IA",
                    holder_name=holder_name.strip(),
                    source_url=IREC_SEARCH_URL,
                    raw_data={
                        "status_text": status_text,
                        "license_type": license_type,
                    },
                )

                yield CollectorResult(
                    category="licenses",
                    state="IA",
                    data=license_obj,
                    source="Iowa Professional Licensing Board",
                )
                count += 1

            logger.info("IA PLB: returned %d license results", count)

        except Exception as e:
            logger.error("IA Professional Licensing Board search failed: %s", e)
        finally:
            await page.close()

    # --- Business Entity Search ---

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search Iowa Secretary of State for business entities.

        The form at sos.iowa.gov/search/business/search.aspx has:
        - Radio buttons for search by name vs number (default: name)
        - Text input #txtName (name: ctl00$ContentPlaceHolder$txtName)
        - Submit button (name: btnNumber, type: submit)
        - reCAPTCHA protection
        Requires Camoufox browser automation.
        """
        if not params.query:
            logger.warning("IA SOS: query is required")
            return

        if not self.has_browser:
            logger.warning(
                "IA Secretary of State requires browser automation. "
                "Initialize with use_browser=True or use_camoufox=True."
            )
            return

        try:
            page = await self.browser.new_page()
        except Exception as e:
            logger.error("IA SOS: failed to create browser page: %s", e)
            return

        count = 0
        max_results = params.max_results

        try:
            await page.goto(
                IASOS_SEARCH_URL,
                wait_until="domcontentloaded",
                timeout=30000,
            )

            # Wait for the search form to load — the name input has id="txtName"
            await page.wait_for_selector("#txtName", timeout=15000)

            # Ensure "Search by Business Name" radio is selected (it's default)
            search_name_radio = await page.query_selector("#searchName")
            if search_name_radio:
                is_checked = await search_name_radio.is_checked()
                if not is_checked:
                    await search_name_radio.click()
                    await asyncio.sleep(0.3)

            # Fill the business name search field
            await page.fill("#txtName", params.query)
            await asyncio.sleep(0.5)

            # Click the submit button — the form uses a <button type="submit" name="btnNumber">
            submit_btn = await page.query_selector(
                'button[type="submit"][name="btnNumber"], '
                'button[type="submit"].btn-primary, '
                'button[type="submit"]'
            )
            if submit_btn:
                await submit_btn.click()
            else:
                # Fallback: submit the form via Enter
                await page.press("#txtName", "Enter")

            # Wait for results page to load (form POSTs to Search.aspx)
            await page.wait_for_load_state("domcontentloaded", timeout=20000)
            await asyncio.sleep(2)  # Extra wait for any dynamic content

            html = await page.content()

            # Use extract_table_rows to auto-detect headers and map them
            # IA SOS table columns: "Business No.", "Name", "Status", "Type"
            rows = extract_table_rows(html)
            for row in rows:
                if count >= max_results:
                    break

                name = (
                    row.get("Name")
                    or row.get("Entity Name")
                    or row.get("Business Name")
                    or row.get("col_1", "")
                )
                if not name:
                    continue

                filing_number = (
                    row.get("Business No.")
                    or row.get("Filing Number")
                    or row.get("Number")
                    or row.get("Entity Number")
                    or row.get("col_0")
                )
                status_text = (
                    row.get("Status")
                    or row.get("col_2", "")
                )
                entity_type_text = (
                    row.get("Type")
                    or row.get("Entity Type")
                    or row.get("col_3", "")
                )

                entity_type = IA_ENTITY_TYPES.get(
                    entity_type_text.upper().strip(), EntityType.OTHER
                ) if entity_type_text else EntityType.OTHER

                status = IA_STATUS_MAP.get(
                    status_text.upper().strip(), EntityStatus.OTHER
                ) if status_text else EntityStatus.ACTIVE

                business = Business(
                    name=name.strip(),
                    entity_type=entity_type,
                    status=status,
                    state="IA",
                    filing_number=filing_number.strip() if filing_number else None,
                    source_url=IASOS_SEARCH_URL,
                    raw_data=row,
                )

                yield CollectorResult(
                    category="businesses",
                    state="IA",
                    data=business,
                    source="Iowa Secretary of State",
                )
                count += 1

            logger.info("IA SOS: returned %d business results", count)

        except Exception as e:
            logger.error("IA Secretary of State search failed: %s", e)
        finally:
            await page.close()
