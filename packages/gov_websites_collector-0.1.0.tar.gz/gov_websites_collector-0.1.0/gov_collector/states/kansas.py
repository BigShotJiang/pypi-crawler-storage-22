"""
Kansas state collector.

Sources:
- KREC (Kansas Real Estate Commission): Real estate license lookups
  https://licensing.ks.gov/verification_krec/
  NOTE: aceonline.kansas.gov DNS is dead as of Feb 2026.
- Kansas Secretary of State: Business entity search
  https://www.sos.ks.gov/eforms/BusinessEntity/Search.aspx
  ASP.NET WebForms behind CloudFront WAF; requires Camoufox browser.
"""

from __future__ import annotations

import asyncio
import logging
import re
from datetime import date as date_cls
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.exceptions import ParseError, ScrapingError
from gov_collector.models import (
    Address,
    Business,
    CollectorResult,
    EntityStatus,
    EntityType,
    License,
    LicenseStatus,
    Person,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import (
    clean_text,
    extract_table_rows,
    extract_text,
    parse_address_text,
    parse_html,
)
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

# --- KREC (Real Estate License) ---
# NOTE: aceonline.kansas.gov DNS is dead as of Feb 2026.
# License verification may now be at licensing.ks.gov
KREC_SEARCH_URL = "https://licensing.ks.gov/verification_krec/"

KS_LICENSE_STATUS_MAP = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "CURRENT": LicenseStatus.ACTIVE,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
    "SUSPENDED": LicenseStatus.SUSPENDED,
    "REVOKED": LicenseStatus.REVOKED,
    "CANCELLED": LicenseStatus.CANCELLED,
    "LAPSED": LicenseStatus.EXPIRED,
}

# --- SOS (Business Entity) ---

KSSOS_SEARCH_URL = "https://www.sos.ks.gov/eforms/BusinessEntity/Search.aspx"

KS_ENTITY_TYPES = {
    "DOMESTIC LIMITED LIABILITY COMPANY": EntityType.LLC,
    "FOREIGN LIMITED LIABILITY COMPANY": EntityType.LLC,
    "LIMITED LIABILITY COMPANY": EntityType.LLC,
    "LLC": EntityType.LLC,
    "DOMESTIC FOR PROFIT CORPORATION": EntityType.CORPORATION,
    "DOMESTIC CORPORATION": EntityType.CORPORATION,
    "FOREIGN FOR PROFIT CORPORATION": EntityType.CORPORATION,
    "FOREIGN CORPORATION": EntityType.CORPORATION,
    "CORPORATION": EntityType.CORPORATION,
    "FOR PROFIT": EntityType.CORPORATION,
    "DOMESTIC NOT FOR PROFIT": EntityType.NONPROFIT,
    "FOREIGN NOT FOR PROFIT": EntityType.NONPROFIT,
    "NOT FOR PROFIT": EntityType.NONPROFIT,
    "NONPROFIT": EntityType.NONPROFIT,
    "DOMESTIC LIMITED PARTNERSHIP": EntityType.LP,
    "FOREIGN LIMITED PARTNERSHIP": EntityType.LP,
    "LIMITED PARTNERSHIP": EntityType.LP,
    "LP": EntityType.LP,
    "LIMITED LIABILITY PARTNERSHIP": EntityType.LLP,
    "LLP": EntityType.LLP,
    "GENERAL PARTNERSHIP": EntityType.PARTNERSHIP,
}

KS_STATUS_MAP = {
    "ACTIVE": EntityStatus.ACTIVE,
    "ACTIVE - GOOD STANDING": EntityStatus.ACTIVE,
    "GOOD STANDING": EntityStatus.ACTIVE,
    "IN GOOD STANDING": EntityStatus.ACTIVE,
    "INACTIVE": EntityStatus.INACTIVE,
    "DISSOLVED": EntityStatus.DISSOLVED,
    "FORFEITED": EntityStatus.DISSOLVED,
    "ADMINISTRATIVELY DISSOLVED": EntityStatus.DISSOLVED,
    "CANCELLED": EntityStatus.DISSOLVED,
    "REVOKED": EntityStatus.DISSOLVED,
    "WITHDRAWN": EntityStatus.WITHDRAWN,
    "MERGED": EntityStatus.MERGED,
    "CONVERTED": EntityStatus.CONVERTED,
}


@StateRegistry.register
class KansasCollector(BaseStateCollector):
    """Collector for Kansas government data."""

    needs_browser_for = [DataCategory.LICENSES, DataCategory.BUSINESSES]

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="KS",
            name="Kansas",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "Kansas Real Estate Commission (KREC)",
                "Kansas Secretary of State",
            ],
            notes="aceonline.kansas.gov DNS dead; KS SOS behind CloudFront WAF.",
        )

    # --- Real Estate Licenses ---
    # NOTE: aceonline.kansas.gov DNS is dead as of Feb 2026.
    # License verification may have moved to licensing.ks.gov.

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search Kansas KREC for real estate licenses.
        NOTE: aceonline.kansas.gov is DNS-dead. Attempting licensing.ks.gov fallback.
        """
        if not params.query and not params.license_number:
            logger.warning("KS KREC: query or license_number is required")
            return

        if not self.has_browser:
            logger.warning(
                "Kansas KREC requires browser automation. "
                "Initialize with use_browser=True."
            )
            return

        try:
            page = await self.browser.new_page()
        except Exception as e:
            logger.error("KS KREC: failed to create browser page: %s", e)
            return

        count = 0
        max_results = params.max_results

        try:
            await page.goto(
                KREC_SEARCH_URL,
                wait_until="domcontentloaded",
                timeout=20000,
            )

            await page.wait_for_selector(
                "input[type='text'], .search-input, input[placeholder]",
                timeout=15000,
            )

            search_input = await page.query_selector(
                'input[type="text"]:not([style*="display: none"]), '
                '.search-input, input[placeholder*="search" i]'
            )
            if search_input:
                search_query = params.query or params.license_number
                await search_input.fill(search_query)
                await page.keyboard.press("Enter")
            else:
                logger.warning("KS KREC: could not find search input")
                return

            await page.wait_for_load_state("domcontentloaded", timeout=15000)

            try:
                await page.wait_for_selector(
                    "table, .search-results, .results-list, .license-result",
                    timeout=10000,
                )
            except Exception:
                logger.debug("KS KREC: no results selector found")

            html = await page.content()
            tree = parse_html(html)

            rows = tree.css("table tr, .search-result, .result-item, .license-item")
            for row in rows:
                if count >= max_results:
                    break
                cells = row.css("td")
                if len(cells) >= 2:
                    holder_name = clean_text(cells[0].text(deep=True))
                    license_info = clean_text(cells[1].text(deep=True))
                    license_id = ""
                    license_type = "Real Estate"
                    if license_info:
                        license_match = re.search(
                            r'\b(?:RE|License[:\s]*)?(\d+)\b', license_info, re.I
                        )
                        if license_match:
                            license_id = license_match.group(1)
                        if 'broker' in license_info.lower():
                            license_type = "Real Estate Broker"
                        elif 'sales' in license_info.lower():
                            license_type = "Real Estate Salesperson"
                    status_text = (
                        clean_text(cells[2].text(deep=True))
                        if len(cells) > 2
                        else "ACTIVE"
                    )
                else:
                    text = clean_text(row.text(deep=True))
                    if not text or len(text.split()) < 2:
                        continue
                    lines = [line.strip() for line in text.split('\n') if line.strip()]
                    if len(lines) < 1:
                        continue
                    holder_name = lines[0]
                    license_id = lines[1] if len(lines) > 1 else ""
                    license_type = "Real Estate"
                    status_text = "ACTIVE"

                if not holder_name:
                    continue

                status = KS_LICENSE_STATUS_MAP.get(
                    status_text.upper().strip(), LicenseStatus.ACTIVE
                )

                license_obj = License(
                    license_number=license_id or "N/A",
                    license_type=license_type,
                    status=status,
                    state="KS",
                    holder_name=holder_name.strip(),
                    source_url=KREC_SEARCH_URL,
                    raw_data={"status_text": status_text},
                )

                yield CollectorResult(
                    category="licenses",
                    state="KS",
                    data=license_obj,
                    source="Kansas KREC",
                )
                count += 1

            logger.info("KS KREC: returned %d license results", count)

        except Exception as e:
            logger.error("Kansas KREC search failed: %s", e)
        finally:
            await page.close()

    # --- Business Entity Search ---

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search Kansas Secretary of State for business entities.

        The search page at sos.ks.gov/eforms/BusinessEntity/Search.aspx is an
        ASP.NET WebForms page behind CloudFront WAF. Requires Camoufox to
        solve the WAF challenge and interact with the form.

        Form structure (ASP.NET):
        - Entity name text input
        - Search button
        - Results appear in a GridView table
        """
        if not params.query:
            logger.warning("KS SOS: query is required")
            return

        if not self.has_browser:
            logger.warning(
                "Kansas SOS requires browser automation. "
                "Initialize with use_browser=True or use_camoufox=True."
            )
            return

        try:
            page = await self.browser.new_page()
        except Exception as e:
            logger.error("KS SOS: failed to create browser page: %s", e)
            return

        count = 0
        max_results = params.max_results

        try:
            await page.goto(
                KSSOS_SEARCH_URL,
                wait_until="domcontentloaded",
                timeout=30000,
            )

            # CloudFront WAF may present a challenge — wait for it to resolve
            await asyncio.sleep(5)

            # Wait for a text input to appear (ASP.NET form)
            try:
                await page.wait_for_selector(
                    "input[type='text'], input[name*='EntityName'], input[name*='txtEntity']",
                    timeout=20000,
                )
            except Exception:
                logger.warning("KS SOS: form not loaded after WAF wait, retrying...")
                await asyncio.sleep(10)
                await page.wait_for_selector("input[type='text']", timeout=15000)

            # Fill entity name field — try ASP.NET naming patterns
            name_input = await page.query_selector(
                'input[name*="EntityName"], '
                'input[name*="txtEntityName"], '
                'input[name*="txtName"], '
                'input[name*="SearchText"], '
                'input[id*="EntityName"], '
                'input[id*="txtEntityName"], '
                'input[type="text"]:not([style*="display:none"])'
            )
            if name_input:
                await name_input.fill(params.query)
                await asyncio.sleep(0.5)
            else:
                logger.warning("KS SOS: could not find entity name input")
                return

            # Click search button
            search_button = await page.query_selector(
                'input[name*="btnSearch"], '
                'input[name*="SearchButton"], '
                'input[type="submit"][value*="Search"], '
                'button[type="submit"]:has-text("Search"), '
                'input[type="submit"]'
            )
            if search_button:
                await search_button.click()
            else:
                await page.keyboard.press("Enter")

            # Wait for results to load
            await page.wait_for_load_state("domcontentloaded", timeout=20000)
            await asyncio.sleep(3)  # Wait for any AJAX/postback

            html = await page.content()

            # Try extracting results using extract_table_rows (auto-detects headers)
            rows = extract_table_rows(html)
            if rows:
                for row in rows:
                    if count >= max_results:
                        break
                    business = self._parse_ks_business_row(row)
                    if business:
                        yield CollectorResult(
                            category="businesses",
                            state="KS",
                            data=business,
                            source="Kansas Secretary of State",
                        )
                        count += 1
            else:
                # Fallback: parse table manually
                tree = parse_html(html)
                for table in tree.css("table"):
                    trs = table.css("tr")
                    if len(trs) < 2:
                        continue
                    # Find header row
                    header_cells = trs[0].css("th, td")
                    headers = [
                        clean_text(c.text(deep=True)) or f"col_{i}"
                        for i, c in enumerate(header_cells)
                    ]
                    for tr in trs[1:]:
                        if count >= max_results:
                            break
                        cells = tr.css("td")
                        if len(cells) < 2:
                            continue
                        row_data = {}
                        for i, cell in enumerate(cells):
                            key = headers[i] if i < len(headers) else f"col_{i}"
                            row_data[key] = clean_text(cell.text(deep=True)) or ""
                        business = self._parse_ks_business_row(row_data)
                        if business:
                            yield CollectorResult(
                                category="businesses",
                                state="KS",
                                data=business,
                                source="Kansas Secretary of State",
                            )
                            count += 1

            logger.info("KS SOS: returned %d business results", count)

        except Exception as e:
            logger.error("Kansas SOS search failed: %s", e)
        finally:
            await page.close()

    def _parse_ks_business_row(self, row: dict[str, str]) -> Business | None:
        """Parse a single KS SOS business row (dict of header->value)."""
        name = (
            row.get("Entity Name")
            or row.get("Business Name")
            or row.get("Name")
            or row.get("col_0")
        )
        if not name:
            return None

        filing_number = (
            row.get("Entity Number")
            or row.get("Filing Number")
            or row.get("ID")
            or row.get("col_1")
        )
        type_str = (
            row.get("Entity Type") or row.get("Type") or row.get("col_2", "")
        ).upper().strip()
        status_str = (
            row.get("Status") or row.get("col_3", "")
        ).upper().strip()

        entity_type = KS_ENTITY_TYPES.get(type_str, EntityType.OTHER)
        status = KS_STATUS_MAP.get(status_str, EntityStatus.OTHER)

        formation_date = None
        date_str = (
            row.get("Date of Organization")
            or row.get("Date Filed")
            or row.get("Formation Date")
        )
        if date_str:
            for fmt in ("%m/%d/%Y", "%Y-%m-%d"):
                try:
                    formation_date = date_cls.strptime(date_str.strip(), fmt)
                    break
                except (ValueError, AttributeError):
                    continue

        agent_name = row.get("Resident Agent") or row.get("Registered Agent")
        agent = Person(full_name=agent_name) if agent_name else None

        address = None
        addr_str = row.get("Principal Office") or row.get("Address")
        if addr_str:
            address = parse_address_text(addr_str)

        return Business(
            name=name.strip(),
            entity_type=entity_type,
            status=status,
            state="KS",
            filing_number=filing_number,
            formation_date=formation_date,
            address=address,
            registered_agent=agent,
            source_url=KSSOS_SEARCH_URL,
            raw_data=row,
        )
