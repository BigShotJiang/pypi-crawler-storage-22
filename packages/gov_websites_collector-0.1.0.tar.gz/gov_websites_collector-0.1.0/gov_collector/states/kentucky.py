"""
Kentucky state collector.

Sources:
- KREC (Kentucky Real Estate Commission): License verification
  https://krec.ky.gov/licensee-lookup/
- Kentucky Secretary of State: Business entity search  
  https://web.sos.ky.gov/corpscansrch/

Strategy: HTTP approach for both sources
- KREC has a standard lookup form
- SOS search uses standard form submission
"""

from __future__ import annotations

import logging
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.models import (
    Business,
    CollectorResult,
    EntityStatus,
    EntityType,
    License,
    LicenseStatus,
    SearchParams,
    StateInfo,
)
import re
from gov_collector.parsers import clean_text, extract_text, parse_html
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

KY_LICENSE_URL = "https://krec.ky.gov/eservices/"
KY_BUSINESS_URL = "https://sosbes.sos.ky.gov/BusSearchNProfile/search.aspx"

KY_LICENSE_STATUS_MAP = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "CURRENT": LicenseStatus.ACTIVE,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
}

KY_ENTITY_TYPE_MAP = {
    "LIMITED LIABILITY COMPANY": EntityType.LLC,
    "CORPORATION": EntityType.CORPORATION,
    "NONPROFIT CORPORATION": EntityType.NONPROFIT,
}

KY_STATUS_MAP = {
    "ACTIVE": EntityStatus.ACTIVE,
    "GOOD STANDING": EntityStatus.ACTIVE,
    "INACTIVE": EntityStatus.INACTIVE,
}


@StateRegistry.register
class KentuckyCollector(BaseStateCollector):
    """Collector for Kentucky government data using HTTP."""

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="KY",
            name="Kentucky",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "Kentucky Real Estate Commission (KREC)",
                "Kentucky Secretary of State",
            ],
            notes="Both sources support HTTP-based scraping.",
        )

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """Search Kentucky KREC for real estate licenses."""
        if not params.query and not params.license_number:
            logger.warning("KY KREC: query or license_number is required")
            return

        form_data = {
            "license_number": params.license_number or "",
            "last_name": "",
            "first_name": "",
        }

        if params.query and not params.license_number:
            parts = params.query.strip().split(maxsplit=1)
            form_data["last_name"] = parts[0]
            if len(parts) > 1:
                form_data["first_name"] = parts[1]

        try:
            response = await self.client.post(KY_LICENSE_URL, data=form_data)
            html = response.text
        except Exception as e:
            logger.error("KY KREC license search failed: %s", e)
            return

        tree = parse_html(html)
        rows = tree.css("table tr")

        count = 0
        for row in rows:
            if count >= params.max_results:
                break

            cells = row.css("td")
            if len(cells) < 3:
                continue

            name = extract_text(cells[0])
            license_num = extract_text(cells[1]) if len(cells) > 1 else None
            status_text = extract_text(cells[2]) if len(cells) > 2 else None

            if not name or not license_num:
                continue

            status = KY_LICENSE_STATUS_MAP.get(
                (status_text or "").upper().strip(), LicenseStatus.OTHER
            )

            license_obj = License(
                license_number=license_num.strip(),
                license_type="Real Estate",
                status=status,
                state="KY",
                holder_name=name.strip(),
                source_url=KY_LICENSE_URL,
                raw_data={"status_text": status_text},
            )

            yield CollectorResult(
                category=DataCategory.LICENSES.value,
                state="KY",
                data=license_obj,
                source="Kentucky Real Estate Commission (KREC)",
            )
            count += 1

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """Search Kentucky SOS for business entities.
        
        Uses the ASP.NET WebForms search at sosbes.sos.ky.gov.
        Form fields: ddlSearchBy (OrgName), txtSearch, BSearch.
        Results table columns: Company Name, Company ID, Status, Company Type.
        """
        if not params.query:
            logger.warning("KY SOS: query (business name) is required")
            return

        # Step 1: GET the search page to get ViewState
        try:
            initial = await self.client.get(KY_BUSINESS_URL)
            tree = parse_html(initial.text)
        except Exception as e:
            logger.error("KY SOS: failed to load search page: %s", e)
            return

        # Extract all hidden form fields
        form_data = {}
        for inp in tree.css('input[type="hidden"]'):
            name = inp.attributes.get("name", "")
            value = inp.attributes.get("value", "")
            if name:
                form_data[name] = value

        form_data["ctl00$MainContent$txtSearch"] = params.query
        form_data["ctl00$MainContent$ddlSearchBy"] = "OrgName"
        form_data["ctl00$MainContent$BSearch"] = "Search"
        form_data["__EVENTTARGET"] = ""
        form_data["__EVENTARGUMENT"] = ""

        # Step 2: POST the search
        try:
            response = await self.client.post(KY_BUSINESS_URL, data=form_data)
            html = response.text
        except Exception as e:
            logger.error("KY SOS business search failed: %s", e)
            return

        tree = parse_html(html)
        rows = tree.css("table tr")

        count = 0
        for row in rows:
            if count >= params.max_results:
                break

            cells = row.css("td")
            if len(cells) < 3:
                continue

            name = clean_text(cells[0].text(deep=True))
            filing_number = clean_text(cells[1].text(deep=True)) if len(cells) > 1 else None
            status_text = clean_text(cells[2].text(deep=True)) if len(cells) > 2 else ""
            entity_type_text = clean_text(cells[3].text(deep=True)) if len(cells) > 3 else ""

            if not name or name.upper() == "COMPANY NAME":
                continue

            # Parse status from "A - Active", "I - Inactive" format
            status = EntityStatus.ACTIVE
            if status_text:
                st = status_text.lower()
                if "inactive" in st or st.startswith("i "):
                    status = EntityStatus.INACTIVE
                elif "dissolved" in st or st.startswith("d "):
                    status = EntityStatus.DISSOLVED

            entity_type = KY_ENTITY_TYPE_MAP.get(
                (entity_type_text or "").upper().strip(), EntityType.OTHER
            )
            # Also check for keywords in entity type text
            if entity_type == EntityType.OTHER and entity_type_text:
                et = entity_type_text.upper()
                if "LLC" in et or "LIMITED LIABILITY" in et:
                    entity_type = EntityType.LLC
                elif "CORPORATION" in et:
                    entity_type = EntityType.CORPORATION
                elif "PARTNERSHIP" in et:
                    entity_type = EntityType.PARTNERSHIP

            business = Business(
                name=name.strip(),
                entity_type=entity_type,
                status=status,
                state="KY",
                filing_number=filing_number,
                source_url=KY_BUSINESS_URL,
                raw_data={
                    "entity_type_text": entity_type_text,
                    "status_text": status_text,
                },
            )

            yield CollectorResult(
                category=DataCategory.BUSINESSES.value,
                state="KY",
                data=business,
                source="Kentucky Secretary of State",
            )
            count += 1