"""
Louisiana state collector.

Sources:
- LREC (Louisiana Real Estate Commission): License search
  https://portal.lrec.gov/public/search (jQuery AJAX endpoint: /Public/_Search/)
- Louisiana Secretary of State: Business entity search (CORA Web)
  https://coraweb.sos.la.gov/CommercialSearch/CommercialSearch.aspx

Limitations:
- The Louisiana SOS business search (CORA Web) is CAPTCHA-protected.
  Automated access will fail without CAPTCHA solving.
"""

from __future__ import annotations

import logging
import re
from datetime import date as date_cls
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.exceptions import (
    AuthenticationError,
    ParseError,
    ScrapingError,
)
from gov_collector.models import (
    Address,
    Business,
    CollectorResult,
    EntityStatus,
    EntityType,
    License,
    LicenseStatus,
    Person,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import (
    clean_text,
    extract_table_rows,
    extract_text,
    parse_address_text,
    parse_html,
)
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

# --- LREC (Real Estate License) ---

LREC_SEARCH_URL = "https://portal.lrec.gov/public/search"
LREC_AJAX_URL = "https://portal.lrec.gov/Public/_Search/"

LA_LICENSE_STATUS_MAP = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "CURRENT": LicenseStatus.ACTIVE,
    "LICENSED": LicenseStatus.ACTIVE,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
    "SUSPENDED": LicenseStatus.SUSPENDED,
    "REVOKED": LicenseStatus.REVOKED,
    "CANCELLED": LicenseStatus.CANCELLED,
    "RETIRED": LicenseStatus.INACTIVE,
    "PENDING": LicenseStatus.PENDING,
}

# --- SOS (Business Entity) ---
# CAPTCHA PROTECTED — automated access will likely fail

LASOS_SEARCH_URL = (
    "https://coraweb.sos.la.gov/CommercialSearch/CommercialSearch.aspx"
)

LA_ENTITY_TYPES = {
    "DOMESTIC LIMITED LIABILITY COMPANY": EntityType.LLC,
    "FOREIGN LIMITED LIABILITY COMPANY": EntityType.LLC,
    "LIMITED LIABILITY COMPANY": EntityType.LLC,
    "LLC": EntityType.LLC,
    "DOMESTIC CORPORATION": EntityType.CORPORATION,
    "DOMESTIC PROFIT CORPORATION": EntityType.CORPORATION,
    "DOMESTIC BUSINESS CORPORATION": EntityType.CORPORATION,
    "FOREIGN CORPORATION": EntityType.CORPORATION,
    "FOREIGN PROFIT CORPORATION": EntityType.CORPORATION,
    "CORPORATION": EntityType.CORPORATION,
    "DOMESTIC NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "FOREIGN NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "NONPROFIT": EntityType.NONPROFIT,
    "DOMESTIC LIMITED PARTNERSHIP": EntityType.LP,
    "FOREIGN LIMITED PARTNERSHIP": EntityType.LP,
    "LIMITED PARTNERSHIP": EntityType.LP,
    "LP": EntityType.LP,
    "LIMITED LIABILITY PARTNERSHIP": EntityType.LLP,
    "LLP": EntityType.LLP,
    "GENERAL PARTNERSHIP": EntityType.PARTNERSHIP,
    "SOLE PROPRIETORSHIP": EntityType.SOLE_PROPRIETORSHIP,
}

LA_STATUS_MAP = {
    "ACTIVE": EntityStatus.ACTIVE,
    "GOOD STANDING": EntityStatus.ACTIVE,
    "IN GOOD STANDING": EntityStatus.ACTIVE,
    "INACTIVE": EntityStatus.INACTIVE,
    "DISSOLVED": EntityStatus.DISSOLVED,
    "REVOKED": EntityStatus.DISSOLVED,
    "TERMINATED": EntityStatus.DISSOLVED,
    "CANCELLED": EntityStatus.DISSOLVED,
    "WITHDRAWN": EntityStatus.WITHDRAWN,
    "MERGED": EntityStatus.MERGED,
    "CONVERTED": EntityStatus.CONVERTED,
}


@StateRegistry.register
class LouisianaCollector(BaseStateCollector):
    """Collector for Louisiana government data."""
    
    needs_browser_for = [DataCategory.BUSINESSES]

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="LA",
            name="Louisiana",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "Louisiana Real Estate Commission (LREC)",
                "Louisiana Secretary of State (CORA Web)",
            ],
            notes=(
                "License search works via LREC AJAX endpoint. "
                "LA SOS (CORA Web) is CAPTCHA-protected for business search."
            ),
        )

    # --- Real Estate Licenses ---

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search Louisiana LREC for real estate licenses.

        Uses jQuery AJAX endpoint at /Public/_Search/.
        First loads /public/search for cookies, then POSTs to the AJAX URL.
        Form fields: LastName, FirstName, CompanyName, PhoneNumber,
                     streetAddress, PostalCode, City, StateCode, AccountTypeID.
        Results table columns: Account #, Type, Owner.
        """
        if not params.query and not params.license_number:
            raise ValueError(
                "Either 'query' (name) or 'license_number' is required for LA LREC"
            )

        # Step 1: Load the search page for session cookies
        try:
            await self.client.get(LREC_SEARCH_URL)
        except Exception as e:
            logger.warning("LA LREC: failed to load search page: %s", e)

        form_data: dict[str, str] = {
            "LastName": "",
            "FirstName": "",
            "CompanyName": "",
            "PhoneNumber": "",
            "streetAddress": "",
            "PostalCode": "",
            "City": "",
            "StateCode": "",
            "AccountTypeID": "",
        }

        if params.license_number:
            # Account # search not directly supported, use CompanyName
            form_data["CompanyName"] = params.license_number
        elif params.query:
            parts = params.query.strip().split(maxsplit=1)
            form_data["LastName"] = parts[0]
            if len(parts) > 1:
                form_data["FirstName"] = parts[1]

        # Step 2: POST to the AJAX endpoint
        try:
            response = await self.client.post(LREC_AJAX_URL, data=form_data)
            html = response.text
        except Exception as e:
            logger.error("LA LREC license search failed: %s", e)
            return

        count = 0
        async for result in self._parse_lrec_results(html):
            yield result
            count += 1
            if count >= params.max_results:
                return

    async def _parse_lrec_results(
        self, html: str
    ) -> AsyncIterator[CollectorResult]:
        """Parse LREC AJAX search results.

        Table columns: Account # | Type | Owner
        """
        tree = parse_html(html)

        rows = tree.css("table tr")
        if not rows:
            logger.debug("No LREC results found")
            return

        for row in rows:
            cells = row.css("td")
            if len(cells) < 3:
                continue

            license_id = clean_text(cells[0].text(deep=True))
            license_type = clean_text(cells[1].text(deep=True))
            holder_name = clean_text(cells[2].text(deep=True))

            if not holder_name or not license_id:
                continue

            # Skip header-like rows
            if license_id.upper() == "ACCOUNT #":
                continue

            license_obj = License(
                license_number=license_id.strip(),
                license_type=license_type or "Real Estate",
                status=LicenseStatus.ACTIVE,
                state="LA",
                holder_name=holder_name.strip(),
                source_url=LREC_SEARCH_URL,
                raw_data={
                    "account_number": license_id,
                    "license_type": license_type,
                },
            )

            yield CollectorResult(
                category=DataCategory.LICENSES.value,
                state="LA",
                data=license_obj,
                source="Louisiana LREC",
            )

    # --- Business Entity Search ---

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search Louisiana Secretary of State (CORA Web) for business entities.

        ⚠️ CAPTCHA PROTECTED: The CORA Web business search requires CAPTCHA
        verification. Automated access will detect the CAPTCHA challenge and
        raise AuthenticationError. For automated access, consider:
        - Using a CAPTCHA-solving service (2captcha, anti-captcha, etc.)
        - Manual browser-based lookups
        - Louisiana SOS data purchase/bulk access programs

        If a CAPTCHA token is provided via params.extra['captcha_token'],
        it will be included in the form submission.
        """
        if not params.query:
            raise ValueError(
                "'query' (business name) is required for LA business search"
            )

        # Step 1: GET the search page
        try:
            initial = await self.client.get(LASOS_SEARCH_URL)
            initial_html = initial.text
        except Exception as e:
            logger.error("Failed to load LA SOS search page: %s", e)
            return

        # Check for CAPTCHA
        if self._detect_captcha(initial_html):
            captcha_token = (
                params.extra.get("captcha_token") if params.extra else None
            )
            if not captcha_token:
                logger.error(
                    "Louisiana SOS business search requires CAPTCHA. "
                    "Provide captcha_token in params.extra or use manual search."
                )
                raise AuthenticationError(
                    "Louisiana SOS (CORA Web) requires CAPTCHA verification. "
                    "Automated search cannot proceed without a CAPTCHA token."
                )

        # Extract ASP.NET ViewState (CORA Web is ASP.NET)
        asp_fields = self._extract_asp_fields(initial_html)

        # Step 2: Build form POST data
        form_data = {
            **asp_fields,
            "ctl00$cphMainContent$txtEntityName": params.query,
            "ctl00$cphMainContent$btnSearch": "Search",
        }

        # Include CAPTCHA token if provided
        captcha_token = (
            params.extra.get("captcha_token") if params.extra else None
        )
        if captcha_token:
            form_data["g-recaptcha-response"] = captcha_token

        # Step 3: POST the search
        try:
            response = await self.client.post(
                LASOS_SEARCH_URL, data=form_data
            )
            html = response.text
        except Exception as e:
            logger.error("LA SOS business search failed: %s", e)
            return

        # Verify we got results and not a CAPTCHA page
        if self._detect_captcha(html):
            raise AuthenticationError(
                "Louisiana SOS returned CAPTCHA challenge. "
                "The provided captcha_token may be invalid or expired."
            )

        count = 0
        async for result in self._parse_lasos_results(html):
            yield result
            count += 1
            if count >= params.max_results:
                return

    def _detect_captcha(self, html: str) -> bool:
        """Check if the response page contains a CAPTCHA challenge."""
        captcha_indicators = [
            "g-recaptcha",
            "recaptcha",
            "captcha-container",
            "hcaptcha",
            "cf-turnstile",
        ]
        html_lower = html.lower()
        return any(indicator in html_lower for indicator in captcha_indicators)

    def _extract_asp_fields(self, html: str) -> dict[str, str]:
        """Extract ASP.NET hidden form fields from HTML page."""
        tree = parse_html(html)
        fields: dict[str, str] = {}

        for field_name in (
            "__VIEWSTATE",
            "__VIEWSTATEGENERATOR",
            "__EVENTVALIDATION",
            "__EVENTTARGET",
            "__EVENTARGUMENT",
        ):
            node = tree.css_first(f'input[name="{field_name}"]')
            if node:
                fields[field_name] = node.attributes.get("value", "")

        return fields

    async def _parse_lasos_results(
        self, html: str
    ) -> AsyncIterator[CollectorResult]:
        """Parse Louisiana SOS search results."""
        rows = extract_table_rows(html)
        if not rows:
            logger.debug("No LA SOS results found")
            return

        for row in rows:
            name = (
                row.get("Entity Name")
                or row.get("Name")
                or row.get("Charter Name", "")
            )
            if not name:
                continue

            filing_number = (
                row.get("Charter Number")
                or row.get("Entity Number")
                or row.get("Filing Number")
            )
            type_str = (
                row.get("Entity Type") or row.get("Type") or ""
            ).upper()
            status_str = (
                row.get("Status") or row.get("Standing") or ""
            ).upper()

            entity_type = LA_ENTITY_TYPES.get(type_str, EntityType.OTHER)
            status = LA_STATUS_MAP.get(status_str, EntityStatus.OTHER)

            formation_date = None
            date_str = (
                row.get("Date of Formation")
                or row.get("Registration Date")
                or row.get("Date Filed")
            )
            if date_str:
                for fmt in ("%m/%d/%Y", "%Y-%m-%d"):
                    try:
                        formation_date = date_cls.strptime(
                            date_str.strip(), fmt
                        )
                        break
                    except (ValueError, AttributeError):
                        continue

            agent_name = row.get("Registered Agent") or row.get("Agent")
            agent = Person(full_name=agent_name) if agent_name else None

            address = None
            addr_str = (
                row.get("Registered Office")
                or row.get("Principal Office")
                or row.get("Address")
            )
            if addr_str:
                address = parse_address_text(addr_str)

            business = Business(
                name=name.strip(),
                entity_type=entity_type,
                status=status,
                state="LA",
                filing_number=filing_number,
                formation_date=formation_date,
                address=address,
                registered_agent=agent,
                source_url=LASOS_SEARCH_URL,
                raw_data=row,
            )

            yield CollectorResult(
                category=DataCategory.BUSINESSES.value,
                state="LA",
                data=business,
                source="Louisiana Secretary of State (CORA Web)",
            )
