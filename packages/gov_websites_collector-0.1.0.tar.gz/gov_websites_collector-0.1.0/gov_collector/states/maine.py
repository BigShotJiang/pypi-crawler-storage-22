"""
Maine state collector.

Sources:
- MREC / PFR (Professional and Financial Regulation): Real estate license lookup
  https://www.pfr.maine.gov/almsonline/almsquery/SearchIndividual.aspx
- Maine Secretary of State: Business entity search (ICRS)
  https://apps3.web.maine.gov/nei-sos-icrs/ICRS?MainPage=x

Notes:
- PFR (ALMS Online) uses ASP.NET WebForms — requires ViewState token management.
  GET the search page first to extract __VIEWSTATE, __VIEWSTATEGENERATOR,
  __EVENTVALIDATION hidden fields, then include them in the POST request.
- Maine SOS ICRS is a Java-based web app with session management.
"""

from __future__ import annotations

import logging
import re
from datetime import date as date_cls
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.exceptions import ParseError, ScrapingError
from gov_collector.models import (
    Address,
    Business,
    CollectorResult,
    EntityStatus,
    EntityType,
    License,
    LicenseStatus,
    Person,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import (
    clean_text,
    extract_table_rows,
    extract_text,
    parse_address_text,
    parse_html,
)
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

# --- PFR/ALMS (Real Estate License) ---
# ASP.NET WebForms — ViewState required

PFR_SEARCH_URL = (
    "https://www.pfr.maine.gov/almsonline/almsquery/SearchIndividual.aspx"
)

ME_LICENSE_STATUS_MAP = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "CURRENT": LicenseStatus.ACTIVE,
    "LICENSED": LicenseStatus.ACTIVE,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
    "SUSPENDED": LicenseStatus.SUSPENDED,
    "REVOKED": LicenseStatus.REVOKED,
    "CANCELLED": LicenseStatus.CANCELLED,
    "LAPSED": LicenseStatus.EXPIRED,
    "PENDING": LicenseStatus.PENDING,
}

# --- SOS (Business Entity) ---

MESOS_SEARCH_URL = (
    "https://apps3.web.maine.gov/nei-sos-icrs/ICRS?MainPage=x"
)
MESOS_SEARCH_ACTION = (
    "https://apps3.web.maine.gov/nei-sos-icrs/ICRS"
)

ME_ENTITY_TYPES = {
    "DOMESTIC LIMITED LIABILITY COMPANY": EntityType.LLC,
    "FOREIGN LIMITED LIABILITY COMPANY": EntityType.LLC,
    "LIMITED LIABILITY COMPANY": EntityType.LLC,
    "LLC": EntityType.LLC,
    "DOMESTIC BUSINESS CORPORATION": EntityType.CORPORATION,
    "DOMESTIC PROFIT CORPORATION": EntityType.CORPORATION,
    "FOREIGN BUSINESS CORPORATION": EntityType.CORPORATION,
    "FOREIGN PROFIT CORPORATION": EntityType.CORPORATION,
    "CORPORATION": EntityType.CORPORATION,
    "DOMESTIC NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "FOREIGN NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "NONPROFIT": EntityType.NONPROFIT,
    "NOT FOR PROFIT": EntityType.NONPROFIT,
    "DOMESTIC LIMITED PARTNERSHIP": EntityType.LP,
    "FOREIGN LIMITED PARTNERSHIP": EntityType.LP,
    "LIMITED PARTNERSHIP": EntityType.LP,
    "LP": EntityType.LP,
    "LIMITED LIABILITY PARTNERSHIP": EntityType.LLP,
    "LLP": EntityType.LLP,
    "GENERAL PARTNERSHIP": EntityType.PARTNERSHIP,
}

ME_STATUS_MAP = {
    "ACTIVE": EntityStatus.ACTIVE,
    "GOOD STANDING": EntityStatus.ACTIVE,
    "IN GOOD STANDING": EntityStatus.ACTIVE,
    "INACTIVE": EntityStatus.INACTIVE,
    "DISSOLVED": EntityStatus.DISSOLVED,
    "ADMIN DISSOLVED": EntityStatus.DISSOLVED,
    "ADMINISTRATIVELY DISSOLVED": EntityStatus.DISSOLVED,
    "VOLUNTARILY DISSOLVED": EntityStatus.DISSOLVED,
    "REVOKED": EntityStatus.DISSOLVED,
    "CANCELLED": EntityStatus.DISSOLVED,
    "WITHDRAWN": EntityStatus.WITHDRAWN,
    "MERGED": EntityStatus.MERGED,
    "CONVERTED": EntityStatus.CONVERTED,
}


def _extract_asp_fields(html: str) -> dict[str, str]:
    """
    Extract ASP.NET hidden form fields (__VIEWSTATE, __EVENTVALIDATION, etc.)
    Required for ASP.NET WebForms POST requests.
    """
    tree = parse_html(html)
    fields: dict[str, str] = {}

    for field_name in (
        "__VIEWSTATE",
        "__VIEWSTATEGENERATOR",
        "__EVENTVALIDATION",
        "__EVENTTARGET",
        "__EVENTARGUMENT",
    ):
        node = tree.css_first(f'input[name="{field_name}"]')
        if node:
            fields[field_name] = node.attributes.get("value", "")

    return fields


@StateRegistry.register
class MaineCollector(BaseStateCollector):
    """Collector for Maine government data."""

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="ME",
            name="Maine",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "Maine Professional and Financial Regulation (PFR/ALMS)",
                "Maine Secretary of State (ICRS)",
            ],
            notes="PFR uses ASP.NET ViewState. ICRS uses CSRF + reCAPTCHA (needs browser).",
        )

    # --- Real Estate Licenses ---

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search Maine PFR (ALMS Online) for real estate licenses.

        ASP.NET WebForms: must GET the page first to capture ViewState,
        then POST the form with search parameters.
        """
        if not params.query and not params.license_number:
            raise ValueError(
                "Either 'query' (name) or 'license_number' is required for ME PFR"
            )

        # Step 1: GET the search page to extract ASP.NET ViewState
        try:
            initial = await self.client.get(PFR_SEARCH_URL)
            asp_fields = _extract_asp_fields(initial.text)
        except Exception as e:
            logger.error("Failed to load PFR search page: %s", e)
            return

        if not asp_fields.get("__VIEWSTATE"):
            # Handle split ViewState (e.g. __VIEWSTATE, __VIEWSTATE1, ... __VIEWSTATE10)
            tree = parse_html(initial.text)
            viewstate_parts = []
            fc_node = tree.css_first('input[name="__VIEWSTATEFIELDCOUNT"]')
            if fc_node:
                field_count = int(fc_node.attributes.get("value", "1"))
                vs0 = tree.css_first('input[name="__VIEWSTATE"]')
                if vs0:
                    viewstate_parts.append(vs0.attributes.get("value", ""))
                for i in range(1, field_count):
                    vsi = tree.css_first(f'input[name="__VIEWSTATE{i}"]')
                    if vsi:
                        viewstate_parts.append(vsi.attributes.get("value", ""))
                if viewstate_parts:
                    asp_fields["__VIEWSTATE"] = "".join(viewstate_parts)
            
            if not asp_fields.get("__VIEWSTATE"):
                logger.error("Could not extract ViewState from PFR page")
                return

        # Also extract split ViewState fields for the POST
        tree = parse_html(initial.text)
        fc_node = tree.css_first('input[name="__VIEWSTATEFIELDCOUNT"]')
        
        # Step 2: Build form POST data
        # Use the correct field names from the actual form
        form_data = {}
        
        # Include all hidden fields from the form
        for inp in tree.css('input[type="hidden"]'):
            name = inp.attributes.get("name", "")
            value = inp.attributes.get("value", "")
            if name:
                form_data[name] = value
        
        # Set required Regulator field to Real Estate Commission
        form_data["ctl00$ctl00$mainContent$mainContent$scRegulator"] = "4060"
        
        if params.license_number:
            form_data["ctl00$ctl00$mainContent$mainContent$scLicenseNo"] = (
                params.license_number
            )
        elif params.query:
            parts = params.query.strip().split(maxsplit=1)
            form_data["ctl00$ctl00$mainContent$mainContent$scLastName"] = parts[0]
            if len(parts) > 1:
                form_data["ctl00$ctl00$mainContent$mainContent$scFirstName"] = parts[1]

        form_data["ctl00$ctl00$mainContent$mainContent$btnSearch"] = "Search"
        form_data["__EVENTTARGET"] = ""
        form_data["__EVENTARGUMENT"] = ""

        # Step 3: POST the search
        try:
            response = await self.client.post(PFR_SEARCH_URL, data=form_data)
            html = response.text
        except Exception as e:
            logger.error("PFR license search POST failed: %s", e)
            return

        count = 0
        async for result in self._parse_pfr_results(html):
            yield result
            count += 1
            if count >= params.max_results:
                return

    async def _parse_pfr_results(
        self, html: str
    ) -> AsyncIterator[CollectorResult]:
        """Parse PFR search results page.
        
        Results table id=gvLicensees with columns:
        Name, Number, Location, Profession, Status
        """
        tree = parse_html(html)

        # Results in GridView table
        result_table = tree.css_first(
            "table#gvLicensees, "
            "table.tbstriped, "
            "table#ContentPlaceHolder1_gvSearchResults, "
            "table.GridView"
        )
        if not result_table:
            logger.debug("No PFR results table found")
            return
        
        rows = result_table.css("tr")
        if not rows:
            return

        for row in rows:
            cells = row.css("td")
            if len(cells) < 4:
                continue

            name_text = clean_text(cells[0].text(deep=True))
            license_id = clean_text(cells[1].text(deep=True))
            location_text = clean_text(cells[2].text(deep=True)) if len(cells) > 2 else None
            license_type = clean_text(cells[3].text(deep=True)) if len(cells) > 3 else None
            status_text = clean_text(cells[4].text(deep=True)) if len(cells) > 4 else None

            if not name_text or not license_id:
                continue
            
            # Skip header rows
            if name_text.upper() == "NAME" or license_id.upper() == "NUMBER":
                continue

            status = LicenseStatus.OTHER
            if status_text:
                status_upper = status_text.upper().strip()
                status = ME_LICENSE_STATUS_MAP.get(status_upper, LicenseStatus.OTHER)
                # Additional status checks
                if "ACTIVE" in status_upper:
                    status = LicenseStatus.ACTIVE
                elif "EXPIRED" in status_upper or "FAILED TO RENEW" in status_upper:
                    status = LicenseStatus.EXPIRED
                elif "INACTIVE" in status_upper:
                    status = LicenseStatus.INACTIVE

            # Parse location into address
            address = None
            if location_text:
                address = Address(raw=location_text, state="ME")

            license_obj = License(
                license_number=license_id.strip(),
                license_type=license_type or "Real Estate",
                status=status,
                state="ME",
                holder_name=name_text.strip(),
                address=address,
                source_url=PFR_SEARCH_URL,
                raw_data={
                    "name": name_text,
                    "license_type": license_type,
                    "status_text": status_text,
                    "location": location_text,
                },
            )

            yield CollectorResult(
                category=DataCategory.LICENSES.value,
                state="ME",
                data=license_obj,
                source="Maine PFR (ALMS)",
            )

    # --- Business Entity Search ---

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search Maine Secretary of State (ICRS) for business entities.

        ICRS is a Java-based web app that requires session management.
        We first load the main page to establish a session, then POST
        the search query.
        """
        if not params.query:
            raise ValueError(
                "'query' (business name) is required for ME business search"
            )

        html = ""
        
        if self.has_browser:
            # Use browser for reCAPTCHA bypass
            try:
                page = await self.browser.new_page()
                try:
                    await page.goto(MESOS_SEARCH_URL, wait_until="domcontentloaded", timeout=20000)
                    
                    import asyncio as _aio
                    await _aio.sleep(3)
                    
                    # Fill the search field
                    name_input = await page.query_selector('input[name="WAISqueryString"]')
                    if name_input:
                        await name_input.fill(params.query)
                    
                    # Click the search button (reCAPTCHA-protected)
                    submit_btn = await page.query_selector('button.g-recaptcha')
                    if submit_btn:
                        await submit_btn.click()
                    else:
                        await page.keyboard.press("Enter")
                    
                    await _aio.sleep(5)
                    await page.wait_for_load_state("domcontentloaded", timeout=15000)
                    html = await page.content()
                finally:
                    await page.close()
            except Exception as e:
                logger.error("ME SOS browser search failed: %s", e)
                return
        else:
            # HTTP fallback - load main page to get CSRF, then POST
            try:
                initial = await self.client.get(MESOS_SEARCH_URL)
                init_tree = parse_html(initial.text)
                csrf_node = init_tree.css_first('input[name="_csrf"]')
                csrf_token = csrf_node.attributes.get("value", "") if csrf_node else ""
                
                form_data = {
                    "_csrf": csrf_token,
                    "WAISqueryString": params.query,
                    "number": "",
                    "search": "Click Here to Search",
                }
                
                response = await self.client.post(
                    MESOS_SEARCH_ACTION, data=form_data
                )
                html = response.text
            except Exception as e:
                logger.error("ME SOS business search failed: %s", e)
                return

        count = 0
        async for result in self._parse_mesos_results(html):
            yield result
            count += 1
            if count >= params.max_results:
                return

    async def _parse_mesos_results(
        self, html: str
    ) -> AsyncIterator[CollectorResult]:
        """Parse Maine SOS search results."""
        rows = extract_table_rows(html)
        if not rows:
            logger.debug("No ME SOS results found")
            return

        for row in rows:
            name = (
                row.get("Entity Name")
                or row.get("Name")
                or row.get("Business Name", "")
            )
            if not name:
                continue

            filing_number = (
                row.get("Charter Number")
                or row.get("Entity Number")
                or row.get("Filing Number")
            )
            type_str = (
                row.get("Entity Type") or row.get("Type") or ""
            ).upper()
            status_str = (
                row.get("Status") or row.get("Standing") or ""
            ).upper()

            entity_type = ME_ENTITY_TYPES.get(type_str, EntityType.OTHER)
            status = ME_STATUS_MAP.get(status_str, EntityStatus.OTHER)

            formation_date = None
            date_str = (
                row.get("Filing Date")
                or row.get("Date Filed")
                or row.get("Formation Date")
            )
            if date_str:
                for fmt in ("%m/%d/%Y", "%Y-%m-%d"):
                    try:
                        formation_date = date_cls.strptime(
                            date_str.strip(), fmt
                        )
                        break
                    except (ValueError, AttributeError):
                        continue

            agent_name = row.get("Clerk/Registered Agent") or row.get("Registered Agent")
            agent = Person(full_name=agent_name) if agent_name else None

            address = None
            addr_str = (
                row.get("Principal Office")
                or row.get("Address")
                or row.get("Registered Office")
            )
            if addr_str:
                address = parse_address_text(addr_str)

            business = Business(
                name=name.strip(),
                entity_type=entity_type,
                status=status,
                state="ME",
                filing_number=filing_number,
                formation_date=formation_date,
                address=address,
                registered_agent=agent,
                source_url=MESOS_SEARCH_URL,
                raw_data=row,
            )

            yield CollectorResult(
                category=DataCategory.BUSINESSES.value,
                state="ME",
                data=business,
                source="Maine Secretary of State (ICRS)",
            )
