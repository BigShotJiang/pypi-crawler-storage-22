"""
Maryland state collector.

Sources:
- MREC / DLLR (Department of Labor, Licensing and Regulation):
  Real estate license search
  https://www.dllr.state.md.us/cgi-bin/ElicenseSearch/OP_Search/OP_search.cgi?calling_app=REC::REC_qselect
- Maryland Department of Assessments and Taxation (SDAT): Business entity search
  https://egov.maryland.gov/BusinessExpress/EntitySearch

Notes:
- Maryland DLLR uses a CGI-based system with GET parameters — simpler than
  ASP.NET but still requires form-style queries.
- BusinessExpress (SDAT) is a more modern web app.
"""

from __future__ import annotations

import logging
import re
from datetime import date as date_cls
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.exceptions import ParseError, ScrapingError
from gov_collector.models import (
    Address,
    Business,
    CollectorResult,
    EntityStatus,
    EntityType,
    License,
    LicenseStatus,
    Person,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import (
    clean_text,
    extract_table_rows,
    extract_text,
    parse_address_text,
    parse_html,
)
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

# --- DLLR (Real Estate License) ---
# CGI-based system with GET parameters

DLLR_SEARCH_URL = (
    "https://labor.maryland.gov/pq/"
)
DLLR_CALLING_APP = "REC::REC_qselect"  # Legacy, may not apply to new URL

MD_LICENSE_STATUS_MAP = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "CURRENT": LicenseStatus.ACTIVE,
    "LICENSED": LicenseStatus.ACTIVE,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
    "SUSPENDED": LicenseStatus.SUSPENDED,
    "REVOKED": LicenseStatus.REVOKED,
    "CANCELLED": LicenseStatus.CANCELLED,
    "SURRENDERED": LicenseStatus.CANCELLED,
    "PENDING": LicenseStatus.PENDING,
}

# --- SDAT / BusinessExpress (Business Entity) ---

SDAT_SEARCH_URL = (
    "https://egov.maryland.gov/BusinessExpress/EntitySearch"
)
SDAT_API_URL = (
    "https://egov.maryland.gov/BusinessExpress/EntitySearch/Search"
)

MD_ENTITY_TYPES = {
    "DOMESTIC LIMITED LIABILITY COMPANY": EntityType.LLC,
    "FOREIGN LIMITED LIABILITY COMPANY": EntityType.LLC,
    "LIMITED LIABILITY COMPANY": EntityType.LLC,
    "LLC": EntityType.LLC,
    "MARYLAND DOMESTIC CORPORATION": EntityType.CORPORATION,
    "DOMESTIC STOCK CORPORATION": EntityType.CORPORATION,
    "DOMESTIC CORPORATION": EntityType.CORPORATION,
    "FOREIGN CORPORATION": EntityType.CORPORATION,
    "STOCK CORPORATION": EntityType.CORPORATION,
    "CORPORATION": EntityType.CORPORATION,
    "DOMESTIC NONSTOCK CORPORATION": EntityType.NONPROFIT,
    "FOREIGN NONSTOCK CORPORATION": EntityType.NONPROFIT,
    "NONPROFIT": EntityType.NONPROFIT,
    "NONSTOCK CORPORATION": EntityType.NONPROFIT,
    "DOMESTIC LIMITED PARTNERSHIP": EntityType.LP,
    "FOREIGN LIMITED PARTNERSHIP": EntityType.LP,
    "LIMITED PARTNERSHIP": EntityType.LP,
    "LP": EntityType.LP,
    "LIMITED LIABILITY PARTNERSHIP": EntityType.LLP,
    "LLP": EntityType.LLP,
    "GENERAL PARTNERSHIP": EntityType.PARTNERSHIP,
    "SOLE PROPRIETORSHIP": EntityType.SOLE_PROPRIETORSHIP,
}

MD_STATUS_MAP = {
    "ACTIVE": EntityStatus.ACTIVE,
    "GOOD STANDING": EntityStatus.ACTIVE,
    "IN GOOD STANDING": EntityStatus.ACTIVE,
    "INACTIVE": EntityStatus.INACTIVE,
    "DISSOLVED": EntityStatus.DISSOLVED,
    "FORFEITED": EntityStatus.DISSOLVED,
    "REVOKED": EntityStatus.DISSOLVED,
    "CANCELLED": EntityStatus.DISSOLVED,
    "WITHDRAWN": EntityStatus.WITHDRAWN,
    "MERGED": EntityStatus.MERGED,
    "CONVERTED": EntityStatus.CONVERTED,
    "SUSPENDED": EntityStatus.SUSPENDED,
}


@StateRegistry.register
class MarylandCollector(BaseStateCollector):
    """Collector for Maryland government data."""

    needs_browser_for = [DataCategory.LICENSES, DataCategory.BUSINESSES]

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="MD",
            name="Maryland",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "Maryland DLLR (Department of Labor, Licensing and Regulation) - WARNING: Returns 404",
                "Maryland SDAT (BusinessExpress) - WARNING: Requires authentication",
            ],
            notes="DLLR site returns 404. BusinessExpress requires user account login.",
        )

    # --- Real Estate Licenses ---

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search Maryland DLLR for real estate licenses.

        Uses CGI GET parameters for searching.
        """
        if not params.query and not params.license_number:
            raise ValueError(
                "Either 'query' (name) or 'license_number' is required for MD DLLR"
            )

        query_params: dict[str, str] = {
            "calling_app": DLLR_CALLING_APP,
        }

        if params.license_number:
            query_params["license_number"] = params.license_number
        elif params.query:
            parts = params.query.strip().split(maxsplit=1)
            query_params["last_name"] = parts[0]
            if len(parts) > 1:
                query_params["first_name"] = parts[1]

        logger.warning("Maryland DLLR site returns 404 as of Feb 2026. Unable to search licenses.")
        return
        
        # Legacy code kept for reference when site is restored:
        try:
            response = await self.client.get(
                DLLR_SEARCH_URL, params=query_params
            )
            html = response.text
        except Exception as e:
            logger.error("DLLR license search failed: %s", e)
            return

        count = 0
        async for result in self._parse_dllr_results(html):
            yield result
            count += 1
            if count >= params.max_results:
                return

    async def _parse_dllr_results(
        self, html: str
    ) -> AsyncIterator[CollectorResult]:
        """Parse DLLR search results page."""
        tree = parse_html(html)

        rows = tree.css("table tr, table.results tr, table tbody tr")
        if not rows:
            logger.debug("No DLLR results found")
            return

        for row in rows:
            cells = row.css("td")
            if len(cells) < 3:
                continue

            name_text = extract_text(cells[0])
            license_id = extract_text(cells[1])
            license_type = extract_text(cells[2])
            status_text = extract_text(cells[3]) if len(cells) > 3 else None
            expiry_text = extract_text(cells[4]) if len(cells) > 4 else None
            county_text = extract_text(cells[5]) if len(cells) > 5 else None

            if not name_text or not license_id:
                continue

            status = LicenseStatus.OTHER
            if status_text:
                status = MD_LICENSE_STATUS_MAP.get(
                    status_text.upper().strip(), LicenseStatus.OTHER
                )

            expiration_date = None
            if expiry_text:
                for fmt in ("%m/%d/%Y", "%Y-%m-%d"):
                    try:
                        expiration_date = date_cls.strptime(
                            expiry_text.strip(), fmt
                        )
                        break
                    except (ValueError, AttributeError):
                        continue

            address = None
            if county_text:
                address = Address(county=county_text.strip(), state="MD")

            license_obj = License(
                license_number=license_id.strip(),
                license_type=license_type or "Real Estate",
                status=status,
                state="MD",
                holder_name=name_text.strip(),
                expiration_date=expiration_date,
                address=address,
                source_url=DLLR_SEARCH_URL,
                raw_data={
                    "name": name_text,
                    "license_type": license_type,
                    "status_text": status_text,
                    "expiry_text": expiry_text,
                    "county": county_text,
                },
            )

            yield CollectorResult(
                category=DataCategory.LICENSES.value,
                state="MD",
                data=license_obj,
                source="Maryland DLLR",
            )

    # --- Business Entity Search ---

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search Maryland SDAT (BusinessExpress) for business entities.

        The BusinessExpress portal supports name-based and entity ID searches.
        """
        if not params.query:
            raise ValueError(
                "'query' (business name) is required for MD business search"
            )

        logger.warning("Maryland BusinessExpress requires user account authentication as of Feb 2026. Unable to search without login.")
        return
        
        # Legacy code kept for reference when public access is restored:
        try:
            response = await self.client.post(
                SDAT_API_URL,
                data={
                    "BusinessName": params.query,
                    "SearchType": "Department",
                },
                headers={
                    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                },
            )
            html = response.text
        except Exception as e:
            logger.error("MD SDAT business search failed: %s", e)
            return

        count = 0
        async for result in self._parse_sdat_results(html):
            yield result
            count += 1
            if count >= params.max_results:
                return

    async def _parse_sdat_results(
        self, html: str
    ) -> AsyncIterator[CollectorResult]:
        """Parse Maryland SDAT search results."""
        rows = extract_table_rows(html)
        if not rows:
            # Try alternate parsing — BusinessExpress may use div-based layout
            tree = parse_html(html)
            result_cards = tree.css(
                ".search-result, .entity-result, .result-item"
            )
            if result_cards:
                for card in result_cards:
                    async for result in self._parse_sdat_card(card):
                        yield result
                return

            logger.debug("No MD SDAT results found")
            return

        for row in rows:
            name = (
                row.get("Business Name")
                or row.get("Entity Name")
                or row.get("Name", "")
            )
            if not name:
                continue

            filing_number = (
                row.get("Department ID")
                or row.get("Entity ID")
                or row.get("Filing Number")
            )
            type_str = (
                row.get("Entity Type") or row.get("Type") or ""
            ).upper()
            status_str = (
                row.get("Status") or row.get("Standing") or ""
            ).upper()

            entity_type = MD_ENTITY_TYPES.get(type_str, EntityType.OTHER)
            status = MD_STATUS_MAP.get(status_str, EntityStatus.OTHER)

            formation_date = None
            date_str = (
                row.get("Date of Formation")
                or row.get("Date Filed")
                or row.get("Formation Date")
            )
            if date_str:
                for fmt in ("%m/%d/%Y", "%Y-%m-%d"):
                    try:
                        formation_date = date_cls.strptime(
                            date_str.strip(), fmt
                        )
                        break
                    except (ValueError, AttributeError):
                        continue

            agent_name = row.get("Resident Agent") or row.get("Registered Agent")
            agent = Person(full_name=agent_name) if agent_name else None

            address = None
            addr_str = (
                row.get("Principal Office")
                or row.get("Address")
                or row.get("Principal Address")
            )
            if addr_str:
                address = parse_address_text(addr_str)

            business = Business(
                name=name.strip(),
                entity_type=entity_type,
                status=status,
                state="MD",
                filing_number=filing_number,
                formation_date=formation_date,
                address=address,
                registered_agent=agent,
                source_url=SDAT_SEARCH_URL,
                raw_data=row,
            )

            yield CollectorResult(
                category=DataCategory.BUSINESSES.value,
                state="MD",
                data=business,
                source="Maryland SDAT (BusinessExpress)",
            )

    async def _parse_sdat_card(
        self, card_node
    ) -> AsyncIterator[CollectorResult]:
        """Parse a single BusinessExpress result card (div-based layout)."""
        name_node = card_node.css_first(
            ".entity-name, .business-name, h3, h4, a"
        )
        name = extract_text(name_node) if name_node else None
        if not name:
            return

        status_node = card_node.css_first(
            ".entity-status, .status, .badge"
        )
        status_text = extract_text(status_node) if status_node else None

        type_node = card_node.css_first(
            ".entity-type, .type"
        )
        type_text = extract_text(type_node) if type_node else None

        id_node = card_node.css_first(
            ".entity-id, .department-id"
        )
        filing_number = extract_text(id_node) if id_node else None

        entity_type = EntityType.OTHER
        if type_text:
            entity_type = MD_ENTITY_TYPES.get(
                type_text.upper().strip(), EntityType.OTHER
            )

        status = EntityStatus.OTHER
        if status_text:
            status = MD_STATUS_MAP.get(
                status_text.upper().strip(), EntityStatus.OTHER
            )

        business = Business(
            name=name.strip(),
            entity_type=entity_type,
            status=status,
            state="MD",
            filing_number=filing_number,
            source_url=SDAT_SEARCH_URL,
            raw_data={"name": name, "status": status_text, "type": type_text},
        )

        yield CollectorResult(
            category=DataCategory.BUSINESSES.value,
            state="MD",
            data=business,
            source="Maryland SDAT (BusinessExpress)",
        )
