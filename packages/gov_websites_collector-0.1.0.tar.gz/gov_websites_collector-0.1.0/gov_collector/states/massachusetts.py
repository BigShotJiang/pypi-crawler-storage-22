"""
Massachusetts state collector.

Sources:
- BRE (Board of Registration of Real Estate Brokers and Salespersons):
  License verification via updated ePlace Portal
  https://ols.state.ma.us/
- Massachusetts Secretary of the Commonwealth: Business entity search
  https://corp.sec.state.ma.us/CorpWeb/CorpSearch/CorpSearch.aspx

Strategy: HYBRID approach
- Licenses: Browser automation (modern portal interface)
- Businesses: HTTP with ASP.NET forms
"""

from __future__ import annotations

import logging
import re
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.models import (
    Business,
    CollectorResult,
    EntityStatus,
    EntityType,
    License,
    LicenseStatus,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import extract_text, parse_html
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

MA_LICENSE_URL = "https://ols.state.ma.us/"
MA_BUSINESS_URL = "https://corp.sec.state.ma.us/CorpWeb/CorpSearch/CorpSearch.aspx"

MA_LICENSE_STATUS_MAP = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "CURRENT": LicenseStatus.ACTIVE,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
}

MA_ENTITY_TYPE_MAP = {
    "LIMITED LIABILITY COMPANY": EntityType.LLC,
    "CORPORATION": EntityType.CORPORATION,
    "NONPROFIT CORPORATION": EntityType.NONPROFIT,
}

MA_STATUS_MAP = {
    "ACTIVE": EntityStatus.ACTIVE,
    "GOOD STANDING": EntityStatus.ACTIVE,
    "INACTIVE": EntityStatus.INACTIVE,
}


@StateRegistry.register
class MassachusettsCollector(BaseStateCollector):
    """Collector for Massachusetts government data using hybrid approach."""

    needs_browser_for = [DataCategory.LICENSES]

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="MA",
            name="Massachusetts",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "Massachusetts Board of Registration of Real Estate Brokers and Salespersons",
                "Massachusetts Secretary of the Commonwealth",
            ],
            notes="License lookup requires browser automation.",
        )

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """Search Massachusetts BRE for real estate licenses using browser."""
        if not params.query and not params.license_number:
            logger.warning("MA BRE: query or license_number is required")
            return

        if not self.has_browser:
            logger.warning("MA BRE requires browser automation.")
            return

        try:
            page = await self.browser.new_page()
            await page.goto(MA_LICENSE_URL, wait_until="domcontentloaded", timeout=15000)
            
            # Navigate to license lookup
            lookup_link = await page.query_selector('a:has-text("License Lookup"), a:has-text("Search")')
            if lookup_link:
                await lookup_link.click()
                await page.wait_for_load_state("domcontentloaded", timeout=10000)
            
            # Fill search form
            if params.license_number:
                license_field = await page.query_selector('input[name*="license"], input[id*="license"]')
                if license_field:
                    await license_field.fill(params.license_number)
            elif params.query:
                name_field = await page.query_selector('input[name*="name"], input[id*="name"]')
                if name_field:
                    await name_field.fill(params.query)

            # Submit search
            submit_btn = await page.query_selector('button:has-text("Search"), input[type="submit"]')
            if submit_btn:
                await submit_btn.click()
                
            await page.wait_for_load_state("domcontentloaded", timeout=15000)
            html = await page.content()
            
            tree = parse_html(html)
            rows = tree.css("table tr")
            
            count = 0
            for row in rows:
                if count >= params.max_results:
                    break
                    
                cells = row.css("td")
                if len(cells) < 3:
                    continue
                    
                name = extract_text(cells[0])
                license_num = extract_text(cells[1])
                status_text = extract_text(cells[2]) if len(cells) > 2 else None
                
                if not name or not license_num:
                    continue
                    
                status = MA_LICENSE_STATUS_MAP.get(
                    (status_text or "").upper().strip(), LicenseStatus.OTHER
                )
                
                license_obj = License(
                    license_number=license_num.strip(),
                    license_type="Real Estate",
                    status=status,
                    state="MA",
                    holder_name=name.strip(),
                    source_url=MA_LICENSE_URL,
                    raw_data={"status_text": status_text},
                )
                
                yield CollectorResult(
                    category=DataCategory.LICENSES.value,
                    state="MA",
                    data=license_obj,
                    source="Massachusetts BRE",
                )
                count += 1
                
        except Exception as e:
            logger.error("MA BRE license search failed: %s", e)
        finally:
            await page.close()

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """Search Massachusetts SOS for business entities using HTTP."""
        if not params.query:
            logger.warning("MA SOS: query (business name) is required")
            return

        # Get ViewState
        try:
            init_response = await self.client.get(MA_BUSINESS_URL)
            init_html = init_response.text
        except Exception as e:
            logger.error("MA SOS initial page load failed: %s", e)
            return

        viewstate = self._extract_aspnet_field(init_html, "__VIEWSTATE")
        viewstate_gen = self._extract_aspnet_field(init_html, "__VIEWSTATEGENERATOR")

        form_data = {
            "__VIEWSTATE": viewstate or "",
            "__VIEWSTATEGENERATOR": viewstate_gen or "",
            "ctl00$MainContent$txtCorpName": params.query,
            "ctl00$MainContent$btnCorpName": "Search by Corporation Name",
        }

        try:
            response = await self.client.post(MA_BUSINESS_URL, data=form_data)
            html = response.text
        except Exception as e:
            logger.error("MA SOS business search failed: %s", e)
            return

        tree = parse_html(html)
        rows = tree.css("table tr")

        count = 0
        for row in rows:
            if count >= params.max_results:
                break

            cells = row.css("td")
            if len(cells) < 2:
                continue

            name = extract_text(cells[0])
            filing_number = extract_text(cells[1]) if len(cells) > 1 else None
            entity_type_text = extract_text(cells[2]) if len(cells) > 2 else None

            if not name:
                continue

            entity_type = MA_ENTITY_TYPE_MAP.get(
                (entity_type_text or "").upper().strip(), EntityType.OTHER
            )

            business = Business(
                name=name.strip(),
                entity_type=entity_type,
                status=EntityStatus.ACTIVE,
                state="MA",
                filing_number=filing_number,
                source_url=MA_BUSINESS_URL,
                raw_data={"entity_type_text": entity_type_text},
            )

            yield CollectorResult(
                category=DataCategory.BUSINESSES.value,
                state="MA",
                data=business,
                source="Massachusetts Secretary of the Commonwealth",
            )
            count += 1

    def _extract_aspnet_field(self, html: str, field_name: str) -> str | None:
        """Extract ASP.NET hidden form field value."""
        pattern = rf'<input[^>]*name="{re.escape(field_name)}"[^>]*value="([^"]*)"'
        match = re.search(pattern, html, re.IGNORECASE)
        if match:
            return match.group(1)
        return None