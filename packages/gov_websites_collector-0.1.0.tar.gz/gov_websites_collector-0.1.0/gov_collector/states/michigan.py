"""
Michigan state collector.

Sources:
- LARA (Licensing and Regulatory Affairs): Real estate license lookups
  Uses Accela Citizen Access platform
  https://aca-prod.accela.com/MILARA/
- LARA Business Registry: Business entity search
  https://mibusinessregistry.lara.state.mi.us/search/business
"""

from __future__ import annotations

import logging
import re
from datetime import date as date_cls
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.exceptions import ParseError, ScrapingError
from gov_collector.models import (
    Address,
    Business,
    CollectorResult,
    EntityStatus,
    EntityType,
    License,
    LicenseStatus,
    Person,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import (
    clean_text,
    extract_text,
    parse_html,
    parse_address_text,
    extract_table_rows,
)
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

# --- LARA Accela (Real Estate Licenses) ---

LARA_BASE_URL = "https://aca-prod.accela.com/MILARA"
LARA_SEARCH_URL = f"{LARA_BASE_URL}/GeneralProperty/LicenseeSearch.aspx"
LARA_MODULE = "Licensing"

# Accela uses internal IDs for license types — MI real estate board
LARA_LICENSE_TYPES = {
    "Real Estate Broker": "Real Estate Broker",
    "Real Estate Salesperson": "Real Estate Salesperson",
    "Associate Broker": "Associate Broker",
    "Broker Company": "Real Estate Broker Company",
}

LARA_STATUS_MAP = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
    "SUSPENDED": LicenseStatus.SUSPENDED,
    "REVOKED": LicenseStatus.REVOKED,
    "CANCELLED": LicenseStatus.CANCELLED,
    "PENDING": LicenseStatus.PENDING,
    "LAPSED": LicenseStatus.EXPIRED,
    "DENIED": LicenseStatus.REVOKED,
}

# --- Business Registry ---

MI_BIZ_SEARCH_URL = "https://mibusinessregistry.lara.state.mi.us/search/business"
MI_BIZ_API_URL = "https://mibusinessregistry.lara.state.mi.us/api/search"

MI_ENTITY_TYPES = {
    "DOMESTIC LIMITED LIABILITY COMPANY": EntityType.LLC,
    "FOREIGN LIMITED LIABILITY COMPANY": EntityType.LLC,
    "DOMESTIC PROFIT CORPORATION": EntityType.CORPORATION,
    "DOMESTIC BUSINESS CORPORATION": EntityType.CORPORATION,
    "FOREIGN PROFIT CORPORATION": EntityType.CORPORATION,
    "FOREIGN BUSINESS CORPORATION": EntityType.CORPORATION,
    "DOMESTIC NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "FOREIGN NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "DOMESTIC LIMITED PARTNERSHIP": EntityType.LP,
    "FOREIGN LIMITED PARTNERSHIP": EntityType.LP,
    "LIMITED LIABILITY PARTNERSHIP": EntityType.LLP,
    "DOMESTIC LIMITED LIABILITY PARTNERSHIP": EntityType.LLP,
    "SOLE PROPRIETORSHIP": EntityType.SOLE_PROPRIETORSHIP,
}

MI_STATUS_MAP = {
    "ACTIVE": EntityStatus.ACTIVE,
    "GOOD STANDING": EntityStatus.ACTIVE,
    "INACTIVE": EntityStatus.INACTIVE,
    "DISSOLVED": EntityStatus.DISSOLVED,
    "SUSPENDED": EntityStatus.SUSPENDED,
    "WITHDRAWN": EntityStatus.WITHDRAWN,
    "MERGED": EntityStatus.MERGED,
    "CONVERTED": EntityStatus.CONVERTED,
    "ADMINISTRATIVELY DISSOLVED": EntityStatus.DISSOLVED,
    "VOLUNTARILY DISSOLVED": EntityStatus.DISSOLVED,
    "AUTOMATICALLY DISSOLVED": EntityStatus.DISSOLVED,
}


@StateRegistry.register
class MichiganCollector(BaseStateCollector):
    """Collector for Michigan government data.

    Note: Michigan LARA uses the Accela Citizen Access platform for license
    lookups. This platform uses ASP.NET WebForms with ViewState, making it
    more complex to scrape than standard HTML forms.
    """

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="MI",
            name="Michigan",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "Michigan LARA (Licensing and Regulatory Affairs)",
                "Michigan Business Registry (LARA)",
            ],
            notes="LARA uses Accela platform — may require ViewState handling",
        )

    # --- Real Estate Licenses ---

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search Michigan LARA for real estate licenses.

        Uses the Accela Citizen Access platform. This is a complex ASP.NET
        WebForms application that requires maintaining ViewState between
        requests.
        """
        if not params.query and not params.license_number:
            raise ValueError(
                "Either 'query' (name) or 'license_number' required for MI LARA"
            )

        # Step 1: GET the search page to obtain ViewState and form tokens
        try:
            page_response = await self.client.get(LARA_SEARCH_URL)
            page_html = page_response.text
        except Exception as e:
            logger.error("MI LARA: failed to load search page: %s", e)
            return

        # Extract ASP.NET form tokens
        viewstate = self._extract_aspnet_field(page_html, "__VIEWSTATE")
        viewstate_gen = self._extract_aspnet_field(page_html, "__VIEWSTATEGENERATOR")
        event_validation = self._extract_aspnet_field(page_html, "__EVENTVALIDATION")

        if not viewstate:
            logger.error("MI LARA: could not extract ViewState — page structure may have changed")
            return

        # Step 2: POST search form
        form_data = {
            "__VIEWSTATE": viewstate,
            "__VIEWSTATEGENERATOR": viewstate_gen or "",
            "__EVENTVALIDATION": event_validation or "",
            "__EVENTTARGET": "",
            "__EVENTARGUMENT": "",
        }

        if params.license_number:
            form_data["ctl00$PlaceHolderMain$generalSearchForm$txtGSPermitNumber"] = (
                params.license_number
            )
        elif params.query:
            parts = params.query.strip().split(maxsplit=1)
            last_name = parts[0]
            first_name = parts[1] if len(parts) > 1 else ""
            form_data["ctl00$PlaceHolderMain$generalSearchForm$txtGSLastName"] = last_name
            form_data["ctl00$PlaceHolderMain$generalSearchForm$txtGSFirstName"] = first_name

        form_data["ctl00$PlaceHolderMain$btnNewSearch"] = "Search"

        try:
            response = await self.client.post(LARA_SEARCH_URL, data=form_data)
            html = response.text
        except Exception as e:
            logger.error("MI LARA: search POST failed: %s", e)
            return

        count = 0
        async for result in self._parse_lara_results(html):
            yield result
            count += 1
            if count >= params.max_results:
                return

    async def _parse_lara_results(
        self, html: str
    ) -> AsyncIterator[CollectorResult]:
        """Parse Accela LARA search results page."""
        tree = parse_html(html)

        # Accela results are typically in a GridView table
        rows = tree.css(
            "table.ACA_GridView_OverFlow tr, "
            "table[id*='GridView'] tr, "
            "div.ACA_Grid_Row"
        )
        if not rows:
            logger.debug("MI LARA: no results found in response")
            return

        for row in rows:
            cells = row.css("td")
            if len(cells) < 3:
                continue

            # Accela GridView typical columns: License#, Name, Type, Status, Expiration
            license_num = extract_text(cells[0])
            name = extract_text(cells[1])
            license_type = extract_text(cells[2]) if len(cells) > 2 else None
            status_text = extract_text(cells[3]) if len(cells) > 3 else None
            expiration = extract_text(cells[4]) if len(cells) > 4 else None
            address_text = extract_text(cells[5]) if len(cells) > 5 else None

            if not license_num or not name:
                continue

            # Map status
            status = LicenseStatus.OTHER
            if status_text:
                status = LARA_STATUS_MAP.get(
                    status_text.upper().strip(), LicenseStatus.OTHER
                )

            # Map license type
            mapped_type = LARA_LICENSE_TYPES.get(
                (license_type or "").strip(), license_type or "Real Estate"
            )

            # Parse expiration date
            exp_date = None
            if expiration:
                for fmt in ("%m/%d/%Y", "%Y-%m-%d", "%m-%d-%Y"):
                    try:
                        exp_date = date_cls(*[int(x) for x in (
                            expiration if "-" in expiration
                            else expiration
                        ).replace("/", "-").split("-")[:3]])
                        break
                    except (ValueError, IndexError):
                        continue

            address = None
            if address_text:
                address = Address(raw=address_text, state="MI")

            license_obj = License(
                license_number=license_num.strip(),
                license_type=mapped_type,
                status=status,
                state="MI",
                holder_name=name.strip(),
                address=address,
                expiration_date=exp_date,
                source_url=LARA_SEARCH_URL,
                raw_data={
                    "name": name,
                    "license_type": license_type,
                    "status_text": status_text,
                    "expiration": expiration,
                },
            )

            yield CollectorResult(
                category=DataCategory.LICENSES.value,
                state="MI",
                data=license_obj,
                source="Michigan LARA (Accela)",
            )

    @staticmethod
    def _extract_aspnet_field(html: str, field_name: str) -> str | None:
        """Extract a hidden ASP.NET form field value."""
        pattern = rf'<input[^>]*name="{re.escape(field_name)}"[^>]*value="([^"]*)"'
        match = re.search(pattern, html, re.IGNORECASE)
        if match:
            return match.group(1)
        # Try alternate attribute order
        pattern2 = rf'<input[^>]*value="([^"]*)"[^>]*name="{re.escape(field_name)}"'
        match2 = re.search(pattern2, html, re.IGNORECASE)
        return match2.group(1) if match2 else None

    # --- Business Entity Search ---

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search Michigan LARA Business Registry for business entities.

        Uses the modern LARA business registry which has a searchable interface.
        """
        if not params.query:
            raise ValueError("'query' (business name) required for MI business search")

        # Try the API endpoint first
        search_payload = {
            "searchTerm": params.query,
            "searchType": "ENTITY_NAME",
        }

        try:
            response = await self.client.post(
                MI_BIZ_API_URL,
                json=search_payload,
                headers={"Content-Type": "application/json"},
            )
            data = response.json()
        except Exception:
            logger.info("MI Business Registry API failed, falling back to HTML")
            async for result in self._mi_biz_html_search(params):
                yield result
            return

        results = data if isinstance(data, list) else data.get("results", data.get("data", []))

        count = 0
        for record in results:
            if count >= params.max_results:
                return

            business = self._parse_mi_biz_record(record)
            if business:
                yield CollectorResult(
                    category=DataCategory.BUSINESSES.value,
                    state="MI",
                    data=business,
                    source="Michigan Business Registry (LARA)",
                )
                count += 1

    async def _mi_biz_html_search(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """Fallback HTML scraping for MI business registry."""
        try:
            response = await self.client.get(
                MI_BIZ_SEARCH_URL,
                params={"search": params.query},
            )
            html = response.text
        except Exception as e:
            logger.error("MI business HTML search failed: %s", e)
            return

        tree = parse_html(html)
        rows = tree.css("table tbody tr, .search-result-item")

        count = 0
        for row in rows:
            if count >= params.max_results:
                return

            cells = row.css("td")
            if len(cells) < 2:
                # Try alternative layout (div-based results)
                name_el = row.css_first(".entity-name, a")
                id_el = row.css_first(".entity-id, .filing-number")
                status_el = row.css_first(".entity-status, .status")
                type_el = row.css_first(".entity-type, .type")

                name = extract_text(name_el) if name_el else None
                filing_num = extract_text(id_el) if id_el else None
                status_text = extract_text(status_el) if status_el else None
                type_text = extract_text(type_el) if type_el else None
            else:
                name = extract_text(cells[0])
                filing_num = extract_text(cells[1]) if len(cells) > 1 else None
                type_text = extract_text(cells[2]) if len(cells) > 2 else None
                status_text = extract_text(cells[3]) if len(cells) > 3 else None

            if not name:
                continue

            entity_type = MI_ENTITY_TYPES.get(
                (type_text or "").upper().strip(), EntityType.OTHER
            )
            status = MI_STATUS_MAP.get(
                (status_text or "").upper().strip(), EntityStatus.OTHER
            )

            business = Business(
                name=name.strip(),
                entity_type=entity_type,
                status=status,
                state="MI",
                filing_number=filing_num,
                source_url=MI_BIZ_SEARCH_URL,
                raw_data={
                    "type_text": type_text,
                    "status_text": status_text,
                },
            )

            yield CollectorResult(
                category=DataCategory.BUSINESSES.value,
                state="MI",
                data=business,
                source="Michigan Business Registry (LARA)",
            )
            count += 1

    def _parse_mi_biz_record(self, record: dict) -> Business | None:
        """Parse a single MI business registry API record."""
        name = (
            record.get("entityName")
            or record.get("name")
            or record.get("businessName")
        )
        if not name:
            return None

        type_str = (
            record.get("entityType") or record.get("type") or ""
        ).upper().strip()
        entity_type = MI_ENTITY_TYPES.get(type_str, EntityType.OTHER)

        status_str = (
            record.get("status") or record.get("entityStatus") or ""
        ).upper().strip()
        status = MI_STATUS_MAP.get(status_str, EntityStatus.OTHER)

        filing_number = record.get("filingNumber") or record.get("entityId")

        formation_date = None
        date_str = record.get("formationDate") or record.get("filingDate")
        if date_str:
            for fmt in ("%m/%d/%Y", "%Y-%m-%d"):
                try:
                    formation_date = date_cls.fromisoformat(date_str) if "-" in str(date_str) else None
                    if formation_date:
                        break
                except (ValueError, AttributeError):
                    continue

        agent_name = record.get("registeredAgent") or record.get("agentName")
        agent = Person(full_name=agent_name) if agent_name else None

        address = None
        addr_str = record.get("address") or record.get("principalAddress")
        if addr_str:
            address = parse_address_text(str(addr_str))

        return Business(
            name=name.strip(),
            entity_type=entity_type,
            status=status,
            state="MI",
            filing_number=str(filing_number) if filing_number else None,
            formation_date=formation_date,
            address=address,
            registered_agent=agent,
            source_url=MI_BIZ_SEARCH_URL,
            raw_data=record,
        )
