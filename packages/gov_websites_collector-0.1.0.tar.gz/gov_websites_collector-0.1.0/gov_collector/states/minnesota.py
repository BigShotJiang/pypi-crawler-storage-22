"""
Minnesota state collector.

Sources:
- Minnesota Department of Commerce (CARDS): Real estate license lookups
  https://www.cards.commerce.state.mn.us/CARDS/security/search.do?searchType=statusLookup
  WARNING: Site returns 403 Forbidden for automated requests (bot protection)
- Minnesota Secretary of State (MBLS): Business entity search
  https://mblsportal.sos.state.mn.us/Business/Search
  Works via fallback HTML scraping. API endpoint at /api/BusinessSearch returns 404.
"""

from __future__ import annotations

import logging
import re
from datetime import date as date_cls
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.exceptions import ParseError, ScrapingError
from gov_collector.models import (
    Address,
    Business,
    CollectorResult,
    EntityStatus,
    EntityType,
    License,
    LicenseStatus,
    Person,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import (
    clean_text,
    extract_text,
    parse_html,
    parse_address_text,
    extract_table_rows,
)
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

# --- MN Commerce (Real Estate Licenses) ---

MN_LICENSE_SEARCH_URL = (
    "https://mn.gov/commerce/licensing/license-lookup/"
)
MN_LICENSE_RESULTS_URL = (
    "https://www.commerce.state.mn.us/LicenseLookupMain.html"
)
# Legacy CARDS URL (no longer works):
# https://www.cards.commerce.state.mn.us/CARDS/security/search.do

MN_LICENSE_STATUS_MAP = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "CURRENT": LicenseStatus.ACTIVE,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
    "SUSPENDED": LicenseStatus.SUSPENDED,
    "REVOKED": LicenseStatus.REVOKED,
    "CANCELLED": LicenseStatus.CANCELLED,
    "PENDING": LicenseStatus.PENDING,
    "LAPSED": LicenseStatus.EXPIRED,
    "TERMINATED": LicenseStatus.CANCELLED,
}

MN_LICENSE_TYPES = {
    "Real Estate Salesperson": "Real Estate Salesperson",
    "Real Estate Broker": "Real Estate Broker",
    "Real Estate Closing Agent": "Real Estate Closing Agent",
}

# --- MN SOS (Business Entity) ---

MN_BIZ_SEARCH_URL = "https://mblsportal.sos.state.mn.us/Business/Search"
MN_BIZ_API_URL = "https://mblsportal.sos.state.mn.us/api/BusinessSearch"

MN_ENTITY_TYPES = {
    "LIMITED LIABILITY COMPANY": EntityType.LLC,
    "DOMESTIC LIMITED LIABILITY COMPANY": EntityType.LLC,
    "FOREIGN LIMITED LIABILITY COMPANY": EntityType.LLC,
    "BUSINESS CORPORATION": EntityType.CORPORATION,
    "DOMESTIC BUSINESS CORPORATION": EntityType.CORPORATION,
    "FOREIGN BUSINESS CORPORATION": EntityType.CORPORATION,
    "NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "DOMESTIC NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "FOREIGN NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "LIMITED PARTNERSHIP": EntityType.LP,
    "DOMESTIC LIMITED PARTNERSHIP": EntityType.LP,
    "FOREIGN LIMITED PARTNERSHIP": EntityType.LP,
    "LIMITED LIABILITY PARTNERSHIP": EntityType.LLP,
    "GENERAL PARTNERSHIP": EntityType.PARTNERSHIP,
    "SOLE PROPRIETORSHIP": EntityType.SOLE_PROPRIETORSHIP,
    "ASSUMED NAME": EntityType.OTHER,
}

MN_STATUS_MAP = {
    "ACTIVE": EntityStatus.ACTIVE,
    "ACTIVE / IN GOOD STANDING": EntityStatus.ACTIVE,
    "IN GOOD STANDING": EntityStatus.ACTIVE,
    "INACTIVE": EntityStatus.INACTIVE,
    "DISSOLVED": EntityStatus.DISSOLVED,
    "VOLUNTARILY DISSOLVED": EntityStatus.DISSOLVED,
    "ADMINISTRATIVELY DISSOLVED": EntityStatus.DISSOLVED,
    "REVOKED": EntityStatus.DISSOLVED,
    "WITHDRAWN": EntityStatus.WITHDRAWN,
    "MERGED": EntityStatus.MERGED,
    "CONVERTED": EntityStatus.CONVERTED,
    "CANCELLED": EntityStatus.DISSOLVED,
}


@StateRegistry.register
class MinnesotaCollector(BaseStateCollector):
    """Collector for Minnesota government data."""

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="MN",
            name="Minnesota",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "Minnesota Department of Commerce (CARDS)",
                "Minnesota Secretary of State (MBLS Portal)",
            ],
        )

    # --- Real Estate Licenses ---

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search Minnesota Department of Commerce CARDS for real estate licenses.

        WARNING: This site currently returns 403 Forbidden for automated requests.
        Bot protection has been implemented. May require browser-based access.
        """
        logger.warning(
            "MN Commerce CARDS appears to have bot protection (403 Forbidden). "
            "License search may fail."
        )
        if not params.query and not params.license_number:
            raise ValueError(
                "Either 'query' (name) or 'license_number' required for MN license search"
            )

        form_data = {
            "searchType": "statusLookup",
            "licenseType": "RE",  # Real Estate
        }

        if params.license_number:
            form_data["licenseNumber"] = params.license_number
        elif params.query:
            parts = params.query.strip().split(maxsplit=1)
            form_data["lastName"] = parts[0]
            if len(parts) > 1:
                form_data["firstName"] = parts[1]

        if params.city:
            form_data["city"] = params.city

        try:
            response = await self.client.post(MN_LICENSE_SEARCH_URL, data=form_data)
            html = response.text
        except Exception as e:
            logger.error("MN Commerce CARDS search failed: %s", e)
            return

        count = 0
        async for result in self._parse_mn_license_results(html):
            yield result
            count += 1
            if count >= params.max_results:
                return

    async def _parse_mn_license_results(
        self, html: str
    ) -> AsyncIterator[CollectorResult]:
        """Parse MN Commerce CARDS search results."""
        tree = parse_html(html)

        # CARDS uses table-based results
        rows = tree.css("table.searchResults tr, table.dataTable tr, table tr")
        if not rows:
            logger.debug("MN CARDS: no results found")
            return

        for row in rows:
            cells = row.css("td")
            if len(cells) < 3:
                continue

            # Typical columns: Name, License#, Type, Status, Expiration, City
            name = extract_text(cells[0])
            license_num = extract_text(cells[1])
            license_type = extract_text(cells[2]) if len(cells) > 2 else None
            status_text = extract_text(cells[3]) if len(cells) > 3 else None
            expiration = extract_text(cells[4]) if len(cells) > 4 else None
            city = extract_text(cells[5]) if len(cells) > 5 else None

            if not name or not license_num:
                continue

            status = LicenseStatus.OTHER
            if status_text:
                status = MN_LICENSE_STATUS_MAP.get(
                    status_text.upper().strip(), LicenseStatus.OTHER
                )

            mapped_type = MN_LICENSE_TYPES.get(
                (license_type or "").strip(), license_type or "Real Estate"
            )

            exp_date = self._parse_date(expiration)

            address = None
            if city:
                address = Address(city=city, state="MN")

            license_obj = License(
                license_number=license_num.strip(),
                license_type=mapped_type,
                status=status,
                state="MN",
                holder_name=name.strip(),
                address=address,
                expiration_date=exp_date,
                source_url=MN_LICENSE_SEARCH_URL,
                raw_data={
                    "name": name,
                    "license_type": license_type,
                    "status_text": status_text,
                    "expiration": expiration,
                    "city": city,
                },
            )

            yield CollectorResult(
                category=DataCategory.LICENSES.value,
                state="MN",
                data=license_obj,
                source="Minnesota Department of Commerce (CARDS)",
            )

    # --- Business Entity Search ---

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search Minnesota Secretary of State MBLS portal for business entities.
        """
        if not params.query:
            raise ValueError("'query' (business name) required for MN business search")

        # Try the API endpoint first
        search_payload = {
            "SearchValue": params.query,
            "SearchType": "BeginsWith",
        }

        try:
            response = await self.client.post(
                MN_BIZ_API_URL,
                json=search_payload,
                headers={"Content-Type": "application/json"},
            )
            data = response.json()
        except Exception:
            logger.info("MN SOS API failed, falling back to HTML search")
            async for result in self._mn_biz_html_search(params):
                yield result
            return

        results = data if isinstance(data, list) else data.get("results", data.get("data", []))

        count = 0
        for record in results:
            if count >= params.max_results:
                return

            business = self._parse_mn_biz_record(record)
            if business:
                yield CollectorResult(
                    category=DataCategory.BUSINESSES.value,
                    state="MN",
                    data=business,
                    source="Minnesota Secretary of State (MBLS)",
                )
                count += 1

    async def _mn_biz_html_search(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """Fallback: scrape MN SOS HTML results."""
        try:
            response = await self.client.get(
                MN_BIZ_SEARCH_URL,
                params={"SearchValue": params.query},
            )
            html = response.text
        except Exception as e:
            logger.error("MN SOS HTML search failed: %s", e)
            return

        tree = parse_html(html)
        rows = tree.css("table tbody tr, .search-results tr")

        count = 0
        for row in rows:
            if count >= params.max_results:
                return

            cells = row.css("td")
            if len(cells) < 2:
                continue

            name = extract_text(cells[0])
            filing_num = extract_text(cells[1]) if len(cells) > 1 else None
            type_text = extract_text(cells[2]) if len(cells) > 2 else None
            status_text = extract_text(cells[3]) if len(cells) > 3 else None
            filing_date = extract_text(cells[4]) if len(cells) > 4 else None

            if not name:
                continue

            entity_type = MN_ENTITY_TYPES.get(
                (type_text or "").upper().strip(), EntityType.OTHER
            )
            status = MN_STATUS_MAP.get(
                (status_text or "").upper().strip(), EntityStatus.OTHER
            )

            formation_date = self._parse_date(filing_date)

            business = Business(
                name=name.strip(),
                entity_type=entity_type,
                status=status,
                state="MN",
                filing_number=filing_num,
                formation_date=formation_date,
                source_url=MN_BIZ_SEARCH_URL,
                raw_data={
                    "type_text": type_text,
                    "status_text": status_text,
                    "filing_date": filing_date,
                },
            )

            yield CollectorResult(
                category=DataCategory.BUSINESSES.value,
                state="MN",
                data=business,
                source="Minnesota Secretary of State (MBLS)",
            )
            count += 1

    def _parse_mn_biz_record(self, record: dict) -> Business | None:
        """Parse a single MN SOS API record."""
        name = (
            record.get("Name")
            or record.get("entityName")
            or record.get("businessName")
        )
        if not name:
            return None

        type_str = (
            record.get("Type") or record.get("entityType") or ""
        ).upper().strip()
        entity_type = MN_ENTITY_TYPES.get(type_str, EntityType.OTHER)

        status_str = (
            record.get("Status") or record.get("status") or ""
        ).upper().strip()
        status = MN_STATUS_MAP.get(status_str, EntityStatus.OTHER)

        filing_number = record.get("FileNumber") or record.get("filingNumber")

        formation_date = self._parse_date(
            record.get("DateFiled") or record.get("formationDate")
        )

        agent_name = record.get("RegisteredAgent") or record.get("agentName")
        agent = Person(full_name=agent_name) if agent_name else None

        address = None
        addr_str = record.get("Address") or record.get("principalAddress")
        if addr_str:
            address = parse_address_text(str(addr_str))

        return Business(
            name=name.strip(),
            entity_type=entity_type,
            status=status,
            state="MN",
            filing_number=str(filing_number) if filing_number else None,
            formation_date=formation_date,
            address=address,
            registered_agent=agent,
            source_url=MN_BIZ_SEARCH_URL,
            raw_data=record,
        )

    @staticmethod
    def _parse_date(date_str: str | None) -> date_cls | None:
        """Parse a date string in common US formats."""
        if not date_str:
            return None
        date_str = date_str.strip()
        for fmt in ("%m/%d/%Y", "%Y-%m-%d", "%m-%d-%Y", "%b %d, %Y"):
            try:
                return date_cls(
                    *[
                        int(x)
                        for x in date_cls.fromisoformat(
                            date_str if "-" in date_str else "1970-01-01"
                        ).__str__().split("-")
                    ]
                )
            except (ValueError, AttributeError):
                continue
        # Manual parse for MM/DD/YYYY
        m = re.match(r"(\d{1,2})/(\d{1,2})/(\d{4})", date_str)
        if m:
            try:
                return date_cls(int(m.group(3)), int(m.group(1)), int(m.group(2)))
            except ValueError:
                pass
        return None
