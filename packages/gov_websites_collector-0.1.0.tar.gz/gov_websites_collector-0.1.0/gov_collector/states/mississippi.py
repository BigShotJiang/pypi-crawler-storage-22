"""
Mississippi state collector.

Sources:
- MREC (Mississippi Real Estate Commission): NO PUBLIC SEARCH AVAILABLE
  https://www.mrec.ms.gov/ - licensee search returns 404
- Mississippi Secretary of State: ACCESS RESTRICTED
  https://corp.sos.ms.gov/ - returns 403 access denied

SCAN RESULTS: MREC 404, SOS 403
"""

from __future__ import annotations

import logging
import re
from datetime import date as date_cls
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.exceptions import ParseError, ScrapingError
from gov_collector.models import (
    Address,
    Business,
    CollectorResult,
    EntityStatus,
    EntityType,
    License,
    LicenseStatus,
    Person,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import (
    clean_text,
    extract_text,
    parse_html,
    parse_address_text,
    extract_table_rows,
)
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

# --- MREC (Real Estate Licenses) ---

MREC_SEARCH_URL = "https://www.mrec.ms.gov/licensee-search/"

MREC_STATUS_MAP = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "CURRENT": LicenseStatus.ACTIVE,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
    "SUSPENDED": LicenseStatus.SUSPENDED,
    "REVOKED": LicenseStatus.REVOKED,
    "CANCELLED": LicenseStatus.CANCELLED,
    "PENDING": LicenseStatus.PENDING,
}

MREC_LICENSE_TYPES = {
    "Salesperson": "Real Estate Salesperson",
    "Broker": "Real Estate Broker",
    "Associate Broker": "Associate Broker",
    "Appraiser": "Real Estate Appraiser",
}

# --- MS SOS (Business Entity) ---

MS_SOS_SEARCH_URL = (
    "https://corp.sos.ms.gov/corp/portal/c/page/corpBusinessIdSearch/portal.aspx"
)

MS_ENTITY_TYPES = {
    "LIMITED LIABILITY COMPANY": EntityType.LLC,
    "DOMESTIC LLC": EntityType.LLC,
    "FOREIGN LLC": EntityType.LLC,
    "DOMESTIC PROFIT CORPORATION": EntityType.CORPORATION,
    "FOREIGN PROFIT CORPORATION": EntityType.CORPORATION,
    "CORPORATION": EntityType.CORPORATION,
    "DOMESTIC NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "FOREIGN NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "NONPROFIT": EntityType.NONPROFIT,
    "LIMITED PARTNERSHIP": EntityType.LP,
    "DOMESTIC LIMITED PARTNERSHIP": EntityType.LP,
    "FOREIGN LIMITED PARTNERSHIP": EntityType.LP,
    "LIMITED LIABILITY PARTNERSHIP": EntityType.LLP,
    "GENERAL PARTNERSHIP": EntityType.PARTNERSHIP,
}

MS_STATUS_MAP = {
    "ACTIVE": EntityStatus.ACTIVE,
    "GOOD STANDING": EntityStatus.ACTIVE,
    "INACTIVE": EntityStatus.INACTIVE,
    "DISSOLVED": EntityStatus.DISSOLVED,
    "ADMINISTRATIVELY DISSOLVED": EntityStatus.DISSOLVED,
    "VOLUNTARILY DISSOLVED": EntityStatus.DISSOLVED,
    "WITHDRAWN": EntityStatus.WITHDRAWN,
    "CANCELLED": EntityStatus.DISSOLVED,
    "REVOKED": EntityStatus.DISSOLVED,
    "MERGED": EntityStatus.MERGED,
    "CONVERTED": EntityStatus.CONVERTED,
}


@StateRegistry.register
class MississippiCollector(BaseStateCollector):
    """Collector for Mississippi government data."""

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="MS",
            name="Mississippi",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "Mississippi Real Estate Commission (MREC)",
                "Mississippi Secretary of State",
            ],
        )

    # --- Real Estate Licenses ---

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Mississippi Real Estate Commission license search.
        
        The MREC website at mrec.ms.gov has a public licensee search, but the
        direct URL /licensee-search/ returns 404. The search may be available
        through the main site navigation. Attempting to find public search functionality.
        """
        if not params.query:
            logger.warning("MS MREC: query (licensee name) is required")
            return
        yield  # Make it a generator
            
        # Try to find the public license search through the main site
        # The main site mentions "Find Licensee" in navigation
        try:
            # First try the main site to find the search form
            response = await self.client.get("https://www.mrec.ms.gov/")
            html = response.text
            
            # Look for "Find Licensee" or similar search links
            tree = parse_html(html)
            search_links = tree.css('a[href*="search"], a[href*="licensee"], a[href*="find"]')
            
            if not search_links:
                logger.warning(
                    "MS MREC: Public license search not found. May require login or be discontinued."
                )
                return
                
            # If we find a potential search URL, try it
            search_url = None
            for link in search_links:
                href = link.get("href", "")
                if "licensee" in href.lower() or "find" in href.lower():
                    if href.startswith("/"):
                        search_url = f"https://www.mrec.ms.gov{href}"
                    else:
                        search_url = href
                    break
            
            if not search_url:
                logger.warning("MS MREC: No valid license search URL found")
                return
                
            # Try the found search URL
            search_response = await self.client.get(search_url)
            if search_response.status_code == 404:
                logger.warning(f"MS MREC: License search URL {search_url} returns 404")
                return
                
            # If we get here, we might have a working search page
            # Implementation would depend on the actual search form structure
            logger.info("MS MREC: Found potential license search, but implementation needed")
            return
            
        except Exception as e:
            logger.error("MS MREC license search failed: %s", e)
            return

    async def _parse_mrec_results(
        self, html: str
    ) -> AsyncIterator[CollectorResult]:
        """Parse MREC search results page."""
        tree = parse_html(html)

        rows = tree.css("table tbody tr, .licensee-result, .search-result")
        if not rows:
            logger.debug("MS MREC: no results found")
            return

        for row in rows:
            cells = row.css("td")
            if len(cells) < 3:
                # Try div-based layout
                name_el = row.css_first(".name, .licensee-name")
                lic_el = row.css_first(".license-number, .lic-num")
                status_el = row.css_first(".status, .lic-status")
                type_el = row.css_first(".type, .lic-type")

                name = extract_text(name_el) if name_el else None
                license_num = extract_text(lic_el) if lic_el else None
                status_text = extract_text(status_el) if status_el else None
                license_type = extract_text(type_el) if type_el else None
            else:
                name = extract_text(cells[0])
                license_num = extract_text(cells[1])
                license_type = extract_text(cells[2]) if len(cells) > 2 else None
                status_text = extract_text(cells[3]) if len(cells) > 3 else None

            if not name or not license_num:
                continue

            status = LicenseStatus.OTHER
            if status_text:
                status = MREC_STATUS_MAP.get(
                    status_text.upper().strip(), LicenseStatus.OTHER
                )

            mapped_type = MREC_LICENSE_TYPES.get(
                (license_type or "").strip(), license_type or "Real Estate"
            )

            license_obj = License(
                license_number=license_num.strip(),
                license_type=mapped_type,
                status=status,
                state="MS",
                holder_name=name.strip(),
                source_url=MREC_SEARCH_URL,
                raw_data={
                    "name": name,
                    "license_type": license_type,
                    "status_text": status_text,
                },
            )

            yield CollectorResult(
                category=DataCategory.LICENSES.value,
                state="MS",
                data=license_obj,
                source="Mississippi Real Estate Commission (MREC)",
            )

    # --- Business Entity Search ---

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Mississippi Secretary of State business entity search.
        
        The MS SOS portal at corp.sos.ms.gov returns 403 Access Denied.
        This appears to be geo-blocked or requires special access permissions.
        """
        if not params.query:
            logger.warning("MS SOS: query (business name) is required")
            return
            yield  # type: ignore[misc]  # Make this an async generator
            
        # Try with browser if available (site blocks HTTP requests with 403)
        if self.has_browser:
            page = None
            try:
                page = await self.browser.new_page()
                await page.goto("https://corp.sos.ms.gov/", wait_until="domcontentloaded", timeout=20000)
                import asyncio
                await asyncio.sleep(5)  # Wait for any challenge
                
                html = await page.content()
                if "403" in html or "Access Denied" in html:
                    logger.warning("MS SOS: Access denied even with browser")
                else:
                    logger.info("MS SOS: Page loaded, searching...")
                    # Look for search form and interact
                    name_input = await page.query_selector('input[name*="name"], input[name*="Name"], input[type="text"]')
                    if name_input:
                        await name_input.fill(params.query)
                        submit = await page.query_selector('input[type="submit"], button[type="submit"]')
                        if submit:
                            await submit.click()
                            await page.wait_for_load_state("domcontentloaded", timeout=15000)
                            
                        result_html = await page.content()
                        tree = parse_html(result_html)
                        rows = tree.css("table tr")
                        count = 0
                        for row in rows:
                            if count >= params.max_results:
                                break
                            cells = row.css("td")
                            if len(cells) < 2:
                                continue
                            name = extract_text(cells[0])
                            if not name:
                                continue
                            filing_number = extract_text(cells[1]) if len(cells) > 1 else None
                            business = Business(
                                name=name.strip(),
                                state="MS",
                                filing_number=filing_number,
                                status=EntityStatus.OTHER,
                                source_url="https://corp.sos.ms.gov/",
                                raw_data={},
                            )
                            yield CollectorResult(
                                category=DataCategory.BUSINESSES.value,
                                state="MS",
                                data=business,
                                source="Mississippi Secretary of State",
                            )
                            count += 1
            except Exception as e:
                logger.error("MS SOS business search failed: %s", e)
            finally:
                if page:
                    await page.close()
            return
        
        logger.warning(
            "MS SOS: Business search access denied (403). "
            "Use browser/camoufox to bypass. Service may be geo-blocked."
        )
        return
        yield  # type: ignore[misc]

    @staticmethod
    def _extract_aspnet_field(html: str, field_name: str) -> str | None:
        """Extract a hidden ASP.NET form field value."""
        pattern = rf'<input[^>]*name="{re.escape(field_name)}"[^>]*value="([^"]*)"'
        match = re.search(pattern, html, re.IGNORECASE)
        if match:
            return match.group(1)
        pattern2 = rf'<input[^>]*value="([^"]*)"[^>]*name="{re.escape(field_name)}"'
        match2 = re.search(pattern2, html, re.IGNORECASE)
        return match2.group(1) if match2 else None

    @staticmethod
    def _parse_date(date_str: str | None) -> date_cls | None:
        """Parse a date string in common US formats."""
        if not date_str:
            return None
        date_str = date_str.strip()
        m = re.match(r"(\d{1,2})/(\d{1,2})/(\d{4})", date_str)
        if m:
            try:
                return date_cls(int(m.group(3)), int(m.group(1)), int(m.group(2)))
            except ValueError:
                pass
        # Try ISO format
        try:
            return date_cls.fromisoformat(date_str)
        except (ValueError, AttributeError):
            pass
        return None
