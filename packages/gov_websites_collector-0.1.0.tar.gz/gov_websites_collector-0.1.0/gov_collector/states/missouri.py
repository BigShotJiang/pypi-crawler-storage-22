"""
Missouri state collector.

Sources:
- Missouri Division of Professional Registration: License search
  https://mopro.mo.gov/license/s/license-search
- Missouri Secretary of State: Business entity search
  https://bsd.sos.mo.gov/BusinessEntity/BESearch.aspx?SearchType=0

Strategy: HYBRID approach
- Licenses: Browser automation (JavaScript portal)
- Businesses: HTTP with ASP.NET forms
"""

from __future__ import annotations

import logging
import re
from datetime import date as date_cls
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.models import (
    Business,
    CollectorResult,
    EntityStatus,
    EntityType,
    License,
    LicenseStatus,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import extract_text, parse_html
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

MO_LICENSE_URL = "https://mopro.mo.gov/license/s/license-search"
MO_BUSINESS_URL = "https://bsd.sos.mo.gov/BusinessEntity/BESearch.aspx?SearchType=0"

MO_LICENSE_STATUS_MAP = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "CURRENT": LicenseStatus.ACTIVE,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
    "SUSPENDED": LicenseStatus.SUSPENDED,
    "REVOKED": LicenseStatus.REVOKED,
}

MO_ENTITY_TYPE_MAP = {
    "LIMITED LIABILITY COMPANY": EntityType.LLC,
    "CORPORATION": EntityType.CORPORATION,
    "NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "LIMITED PARTNERSHIP": EntityType.LP,
}

MO_STATUS_MAP = {
    "ACTIVE": EntityStatus.ACTIVE,
    "GOOD STANDING": EntityStatus.ACTIVE,
    "INACTIVE": EntityStatus.INACTIVE,
    "DISSOLVED": EntityStatus.DISSOLVED,
}


@StateRegistry.register
class MissouriCollector(BaseStateCollector):
    """Collector for Missouri government data using hybrid approach."""

    needs_browser_for = [DataCategory.LICENSES]

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="MO",
            name="Missouri",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "Missouri Division of Professional Registration",
                "Missouri Secretary of State",
            ],
            notes="License search requires browser automation.",
        )

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """Search Missouri PRO for professional licenses using browser."""
        if not params.query and not params.license_number:
            logger.warning("MO PRO: query or license_number is required")
            return

        if not self.has_browser:
            logger.warning("MO PRO requires browser automation.")
            return

        try:
            page = await self.browser.new_page()
            await page.goto(MO_LICENSE_URL, wait_until="domcontentloaded", timeout=15000)
            
            # Wait for the search interface to load (JavaScript portal)
            await page.wait_for_selector('input[type="text"], .search-input', timeout=10000)
            
            # Fill search form
            if params.license_number:
                license_field = await page.query_selector('input[name*="license"], input[id*="license"]')
                if license_field:
                    await license_field.fill(params.license_number)
            elif params.query:
                name_field = await page.query_selector('input[name*="name"], input[id*="name"]')
                if name_field:
                    await name_field.fill(params.query)

            # Submit search
            search_btn = await page.query_selector('button:has-text("Search"), input[type="submit"]')
            if search_btn:
                await search_btn.click()
                
            await page.wait_for_load_state("domcontentloaded", timeout=15000)
            html = await page.content()
            
            tree = parse_html(html)
            rows = tree.css("table tr, .search-results tr")
            
            count = 0
            for row in rows:
                if count >= params.max_results:
                    break
                    
                cells = row.css("td")
                if len(cells) < 3:
                    continue
                    
                name = extract_text(cells[0])
                license_num = extract_text(cells[1])
                license_type = extract_text(cells[2]) if len(cells) > 2 else "Professional License"
                status_text = extract_text(cells[3]) if len(cells) > 3 else None
                
                if not name or not license_num:
                    continue
                    
                status = MO_LICENSE_STATUS_MAP.get(
                    (status_text or "").upper().strip(), LicenseStatus.OTHER
                )
                
                license_obj = License(
                    license_number=license_num.strip(),
                    license_type=license_type.strip() if license_type else "Professional License",
                    status=status,
                    state="MO",
                    holder_name=name.strip(),
                    source_url=MO_LICENSE_URL,
                    raw_data={"status_text": status_text},
                )
                
                yield CollectorResult(
                    category=DataCategory.LICENSES.value,
                    state="MO",
                    data=license_obj,
                    source="Missouri Division of Professional Registration",
                )
                count += 1
                
        except Exception as e:
            logger.error("MO PRO license search failed: %s", e)
        finally:
            await page.close()

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """Search Missouri SOS for business entities using HTTP."""
        if not params.query:
            logger.warning("MO SOS: query (business name) is required")
            return

        from gov_collector.aspnet_helper import extract_all_hidden_fields

        # Get ViewState
        try:
            init_response = await self.client.get(MO_BUSINESS_URL)
            init_html = init_response.text
        except Exception as e:
            logger.error("MO SOS initial page load failed: %s", e)
            return

        hidden = extract_all_hidden_fields(init_html)

        # Build form data with correct ASP.NET field names
        form_data = {**hidden}
        form_data["ctl00$ctl00$ContentPlaceHolderMain$ContentPlaceHolderMainSingle$ppBESearch$bsPanel$tbBusinessName"] = params.query
        form_data["ctl00$ctl00$ContentPlaceHolderMain$ContentPlaceHolderMainSingle$ppBESearch$bsPanel$ddlBESearchType"] = "0"
        form_data["ctl00$ctl00$ContentPlaceHolderMain$ContentPlaceHolderMainSingle$ppBESearch$bsPanel$ddlNameSearchMethod"] = "0"
        # Submit via __doPostBack
        form_data["__EVENTTARGET"] = "ctl00$ctl00$ContentPlaceHolderMain$ContentPlaceHolderMainSingle$ppBESearch$bsPanel$stdbtnSearch$LinkStandardButton"
        form_data["__EVENTARGUMENT"] = ""

        try:
            response = await self.client.post(MO_BUSINESS_URL, data=form_data)
            html = response.text
        except Exception as e:
            logger.error("MO SOS business search failed: %s", e)
            return

        tree = parse_html(html)
        rows = tree.css("table tr")

        count = 0
        for row in rows:
            if count >= params.max_results:
                break

            cells = row.css("td")
            if len(cells) < 2:
                continue

            name = extract_text(cells[0])
            filing_number = extract_text(cells[1]) if len(cells) > 1 else None
            entity_type_text = extract_text(cells[2]) if len(cells) > 2 else None
            status_text = extract_text(cells[3]) if len(cells) > 3 else None

            if not name:
                continue

            entity_type = MO_ENTITY_TYPE_MAP.get(
                (entity_type_text or "").upper().strip(), EntityType.OTHER
            )
            status = MO_STATUS_MAP.get(
                (status_text or "").upper().strip(), EntityStatus.OTHER
            )

            business = Business(
                name=name.strip(),
                entity_type=entity_type,
                status=status,
                state="MO",
                filing_number=filing_number,
                source_url=MO_BUSINESS_URL,
                raw_data={
                    "entity_type_text": entity_type_text,
                    "status_text": status_text,
                },
            )

            yield CollectorResult(
                category=DataCategory.BUSINESSES.value,
                state="MO",
                data=business,
                source="Missouri Secretary of State",
            )
            count += 1

    def _extract_aspnet_field(self, html: str, field_name: str) -> str | None:
        """Extract ASP.NET hidden form field value."""
        pattern = rf'<input[^>]*name="{re.escape(field_name)}"[^>]*value="([^"]*)"'
        match = re.search(pattern, html, re.IGNORECASE)
        if match:
            return match.group(1)
        return None