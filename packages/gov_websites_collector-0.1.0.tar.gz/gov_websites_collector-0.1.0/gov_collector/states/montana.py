"""
Montana state collector.

Sources:
- Montana Board of Realty Regulation (BRR): Real estate license lookups
  https://ebizws.mt.gov/PUBLICPORTAL/searchform?mylist=licenses
  (Accela public portal with verification question / math CAPTCHA)
- Montana Secretary of State: Business entity search
  https://biz.sosmt.gov/search/business
  (React SPA with .search-input / .search-button / .stacked-data-result)
"""

from __future__ import annotations

import asyncio
import logging
import re
from datetime import date as date_cls
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.exceptions import ParseError, ScrapingError
from gov_collector.models import (
    Address,
    Business,
    CollectorResult,
    EntityStatus,
    EntityType,
    License,
    LicenseStatus,
    Person,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import (
    clean_text,
    extract_text,
    parse_html,
    parse_address_text,
    extract_table_rows,
)
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

# --- MT BRR (Real Estate Licenses) ---
# The eBiz portal hosts an Accela public portal with verification question
MT_LICENSE_SEARCH_URL = "https://ebizws.mt.gov/PUBLICPORTAL/searchform?mylist=licenses"

MT_LICENSE_STATUS_MAP = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "CURRENT": LicenseStatus.ACTIVE,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
    "SUSPENDED": LicenseStatus.SUSPENDED,
    "REVOKED": LicenseStatus.REVOKED,
    "CANCELLED": LicenseStatus.CANCELLED,
    "PENDING": LicenseStatus.PENDING,
    "LAPSED": LicenseStatus.EXPIRED,
    "VOLUNTARY SURRENDER": LicenseStatus.CANCELLED,
}

MT_LICENSE_TYPES = {
    "Salesperson": "Real Estate Salesperson",
    "Broker": "Real Estate Broker",
    "Associate Broker": "Associate Broker",
    "Property Manager": "Property Manager",
}

# --- MT SOS (Business Entity) ---
# React SPA at biz.sosmt.gov with classes:
#   .search-input, .search-button[aria-label="Execute search"]
#   Results: button.stacked-data-result with .primary, .secondary, .value spans
MT_BIZ_SEARCH_URL = "https://biz.sosmt.gov/search/business"

MT_ENTITY_TYPES = {
    "LIMITED LIABILITY COMPANY": EntityType.LLC,
    "DOMESTIC LLC": EntityType.LLC,
    "FOREIGN LLC": EntityType.LLC,
    "DOMESTIC LIMITED LIABILITY COMPANY": EntityType.LLC,
    "FOREIGN LIMITED LIABILITY COMPANY": EntityType.LLC,
    "DOMESTIC PROFIT CORPORATION": EntityType.CORPORATION,
    "FOREIGN PROFIT CORPORATION": EntityType.CORPORATION,
    "BUSINESS CORPORATION": EntityType.CORPORATION,
    "DOMESTIC NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "FOREIGN NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "LIMITED PARTNERSHIP": EntityType.LP,
    "DOMESTIC LIMITED PARTNERSHIP": EntityType.LP,
    "FOREIGN LIMITED PARTNERSHIP": EntityType.LP,
    "LIMITED LIABILITY PARTNERSHIP": EntityType.LLP,
    "GENERAL PARTNERSHIP": EntityType.PARTNERSHIP,
}

MT_STATUS_MAP = {
    "ACTIVE": EntityStatus.ACTIVE,
    "GOOD STANDING": EntityStatus.ACTIVE,
    "IN GOOD STANDING": EntityStatus.ACTIVE,
    "INACTIVE": EntityStatus.INACTIVE,
    "DISSOLVED": EntityStatus.DISSOLVED,
    "ADMINISTRATIVELY DISSOLVED": EntityStatus.DISSOLVED,
    "VOLUNTARILY DISSOLVED": EntityStatus.DISSOLVED,
    "REVOKED": EntityStatus.DISSOLVED,
    "WITHDRAWN": EntityStatus.WITHDRAWN,
    "MERGED": EntityStatus.MERGED,
    "CONVERTED": EntityStatus.CONVERTED,
}


@StateRegistry.register
class MontanaCollector(BaseStateCollector):
    """Collector for Montana government data.

    MT SOS business search is a React SPA at biz.sosmt.gov.
    MT license lookup uses the Accela eBiz portal with a verification question.
    """

    needs_browser_for = [DataCategory.LICENSES, DataCategory.BUSINESSES]

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="MT",
            name="Montana",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "Montana Board of Realty Regulation (eBiz/Accela)",
                "Montana Secretary of State (biz.sosmt.gov React SPA)",
            ],
            notes="License search has verification CAPTCHA; SOS is React SPA.",
        )

    # --- Real Estate Licenses ---

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search Montana eBiz for professional/real estate licenses.

        The Accela public portal at ebizws.mt.gov has a verification question
        (math CAPTCHA). Camoufox browser automation attempts to solve it.
        """
        if not params.query and not params.license_number:
            logger.warning("MT eBiz: query (name) or license_number is required")
            return

        if not self.has_browser:
            logger.warning(
                "MT eBiz requires browser automation for verification question. "
                "Initialize with use_browser=True or use_camoufox=True."
            )
            return

        page = None
        try:
            page = await self.browser.new_page()
        except Exception as e:
            logger.error("MT eBiz: failed to create browser page: %s", e)
            return

        count = 0
        max_results = params.max_results

        try:
            await page.goto(
                MT_LICENSE_SEARCH_URL,
                wait_until="domcontentloaded",
                timeout=20000,
            )
            await asyncio.sleep(3)

            # The portal may show a verification question (simple math)
            # Try to detect and solve it
            html = await page.content()
            if "verification" in html.lower() or "remaining attempts" in html.lower():
                solved = await self._solve_verification(page)
                if not solved:
                    logger.warning("MT eBiz: could not solve verification question")
                    return

            # After verification, we should see the search form
            # Wait for search inputs to appear
            try:
                await page.wait_for_selector(
                    "input[type='text'], input[name*='name' i], select",
                    timeout=15000,
                )
            except Exception:
                logger.debug("MT eBiz: search form not found after verification")

            # Fill search form
            if params.query:
                # Try to find name input fields (Last Name / First Name / Business Name)
                name_input = await page.query_selector(
                    'input[name*="Name" i], '
                    'input[name*="name" i], '
                    'input[placeholder*="name" i], '
                    'input[type="text"]'
                )
                if name_input:
                    await name_input.fill(params.query)
                    await asyncio.sleep(0.3)

            # Try to click search button
            submit = await page.query_selector(
                'button[type="submit"], '
                'input[type="submit"], '
                'button:has-text("Search"), '
                'a:has-text("Search")'
            )
            if submit:
                await submit.click()
            else:
                await page.keyboard.press("Enter")

            await page.wait_for_load_state("domcontentloaded", timeout=15000)
            await asyncio.sleep(3)

            html = await page.content()
            tree = parse_html(html)

            # Parse results — Accela portals typically use tables or stacked results
            rows = tree.css("table tr")
            for row in rows:
                if count >= max_results:
                    break
                cells = row.css("td")
                if len(cells) < 2:
                    continue
                name = extract_text(cells[0])
                license_num = extract_text(cells[1]) if len(cells) > 1 else None
                license_type_text = extract_text(cells[2]) if len(cells) > 2 else None
                status_text = extract_text(cells[3]) if len(cells) > 3 else None

                if not name or not license_num:
                    continue

                status = LicenseStatus.ACTIVE
                if status_text and status_text.upper().strip() in MT_LICENSE_STATUS_MAP:
                    status = MT_LICENSE_STATUS_MAP[status_text.upper().strip()]

                mapped_type = MT_LICENSE_TYPES.get(
                    (license_type_text or "").strip(),
                    license_type_text or "Real Estate",
                )

                license_obj = License(
                    license_number=license_num.strip(),
                    license_type=mapped_type,
                    status=status,
                    state="MT",
                    holder_name=name.strip(),
                    source_url=MT_LICENSE_SEARCH_URL,
                    raw_data={
                        "status_text": status_text,
                        "license_type": license_type_text,
                    },
                )
                yield CollectorResult(
                    category=DataCategory.LICENSES.value,
                    state="MT",
                    data=license_obj,
                    source="Montana Board of Realty Regulation",
                )
                count += 1

            # Also try stacked-data-result format (Accela newer portal)
            if count == 0:
                results = tree.css(
                    ".stacked-data-result, .search-result, "
                    "[class*='result'], div[class*='record']"
                )
                for result in results:
                    if count >= max_results:
                        break
                    primary = result.css_first(".primary, .name, strong, b")
                    if not primary:
                        continue
                    name = extract_text(primary)
                    if not name:
                        continue

                    # Extract values from child spans
                    values = result.css(".value, .secondary, span")
                    license_num = ""
                    status_text = ""
                    license_type_text = ""
                    for v in values:
                        vtext = extract_text(v) or ""
                        if re.search(r'\d{4,}', vtext):
                            license_num = vtext
                        elif vtext.upper() in MT_LICENSE_STATUS_MAP:
                            status_text = vtext
                        elif any(
                            kw in vtext.lower()
                            for kw in ["broker", "sales", "agent", "real estate"]
                        ):
                            license_type_text = vtext

                    if not license_num:
                        license_num = "N/A"

                    status = MT_LICENSE_STATUS_MAP.get(
                        status_text.upper().strip(), LicenseStatus.ACTIVE
                    )
                    mapped_type = MT_LICENSE_TYPES.get(
                        license_type_text.strip(),
                        license_type_text or "Real Estate",
                    )

                    license_obj = License(
                        license_number=license_num.strip(),
                        license_type=mapped_type,
                        status=status,
                        state="MT",
                        holder_name=name.strip(),
                        source_url=MT_LICENSE_SEARCH_URL,
                        raw_data={"raw_text": extract_text(result)},
                    )
                    yield CollectorResult(
                        category=DataCategory.LICENSES.value,
                        state="MT",
                        data=license_obj,
                        source="Montana Board of Realty Regulation",
                    )
                    count += 1

            logger.info("MT eBiz: returned %d license results", count)

        except Exception as e:
            logger.error("MT eBiz license search failed: %s", e)
        finally:
            if page:
                await page.close()

    async def _solve_verification(self, page) -> bool:
        """
        Attempt to solve the eBiz verification question (simple math CAPTCHA).

        The verification page typically shows a simple arithmetic question like
        "What is 3 + 4?" with an input field for the answer.
        """
        try:
            html = await page.content()

            # Look for a math question pattern like "What is X + Y?" or "X + Y = ?"
            math_match = re.search(
                r'(\d+)\s*[\+\-\*x×]\s*(\d+)', html
            )
            if math_match:
                a, b = int(math_match.group(1)), int(math_match.group(2))
                # Determine operator
                op_match = re.search(
                    r'\d+\s*([\+\-\*x×])\s*\d+', html
                )
                op = op_match.group(1) if op_match else '+'
                if op == '+':
                    answer = a + b
                elif op == '-':
                    answer = a - b
                elif op in ('*', 'x', '×'):
                    answer = a * b
                else:
                    answer = a + b

                # Fill the answer input
                answer_input = await page.query_selector(
                    'input[type="text"], input[type="number"], '
                    'input[name*="answer" i], input[name*="verify" i], '
                    'input[id*="answer" i]'
                )
                if answer_input:
                    await answer_input.fill(str(answer))
                    await asyncio.sleep(0.3)

                    # Submit the verification
                    submit = await page.query_selector(
                        'button[type="submit"], input[type="submit"], '
                        'button:has-text("Submit"), button:has-text("Verify"), '
                        'a:has-text("Submit")'
                    )
                    if submit:
                        await submit.click()
                    else:
                        await page.keyboard.press("Enter")

                    await page.wait_for_load_state("domcontentloaded", timeout=10000)
                    await asyncio.sleep(2)

                    # Check if we passed
                    new_html = await page.content()
                    if "verification" not in new_html.lower() or "search" in new_html.lower():
                        return True

            logger.warning("MT eBiz: verification question not recognized")
            return False

        except Exception as e:
            logger.error("MT eBiz: verification solve failed: %s", e)
            return False

    # --- Business Entity Search ---

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search Montana Secretary of State for business entities.

        The biz.sosmt.gov site is a React SPA. The search form has:
        - Input with class 'search-input'
        - Button with class 'search-button' and aria-label="Execute search"
        - Results appear as button.stacked-data-result with:
          .primary (business name), .secondary (section label), .value (field values)
        """
        if not params.query:
            logger.warning("MT SOS: query (business name) is required")
            return

        if not self.has_browser:
            logger.warning(
                "MT SOS requires browser automation for React SPA. "
                "Initialize with use_browser=True or use_camoufox=True."
            )
            return

        try:
            page = await self.browser.new_page()
        except Exception as e:
            logger.error("MT SOS: failed to create browser page: %s", e)
            return

        count = 0
        max_results = params.max_results

        try:
            await page.goto(
                MT_BIZ_SEARCH_URL,
                wait_until="domcontentloaded",
                timeout=20000,
            )

            # Wait for the React SPA to hydrate and the search input to appear
            await page.wait_for_selector(
                '.search-input, input[type="text"], input[placeholder*="search" i]',
                timeout=15000,
            )
            await asyncio.sleep(1)  # Extra time for React hydration

            # Fill the search input
            search_input = await page.query_selector(
                '.search-input, '
                'input[type="text"][placeholder*="search" i], '
                'input[type="text"]'
            )
            if not search_input:
                logger.warning("MT SOS: could not find search input")
                return

            await search_input.fill(params.query)
            await asyncio.sleep(0.5)

            # Click the search button
            search_button = await page.query_selector(
                'button[aria-label="Execute search"], '
                '.search-button, '
                'button[type="submit"]:has-text("Search"), '
                'button:has-text("Search")'
            )
            if search_button:
                await search_button.click()
            else:
                await page.keyboard.press("Enter")

            # Wait for results to render
            # Wait for the div-table results to appear
            try:
                await page.wait_for_selector(
                    '.div-table-row, .div-table-body',
                    timeout=15000,
                )
            except Exception:
                logger.debug("MT SOS: no results table found, checking page content")

            await asyncio.sleep(2)  # Wait for React to finish rendering

            html = await page.content()
            tree = parse_html(html)

            # Parse results from div-table-row elements
            # Structure: each row has 4 cells:
            # [0] Form Info (interactive cell with name + type in span.cell elements)
            # [1] Status
            # [2] Registration Date
            # [3] Agent
            results = tree.css(".div-table-row")
            for result in results:
                if count >= max_results:
                    break

                cells = result.css(".div-table-cell")
                if len(cells) < 3:
                    continue

                # Cell 0: Business name and type
                first_cell = cells[0]
                cell_spans = first_cell.css("span.cell")
                if cell_spans:
                    name = extract_text(cell_spans[0]) if cell_spans else None
                    entity_type_text = extract_text(cell_spans[1]) if len(cell_spans) > 1 else ""
                else:
                    # Fallback: get text from interactive-cell-button
                    btn = first_cell.css_first(".interactive-cell-button")
                    raw = extract_text(btn) if btn else extract_text(first_cell)
                    name = raw
                    entity_type_text = ""

                if not name:
                    continue

                # Extract filing number from name like "SMITH LLC (C1376082)"
                filing_number = None
                name_match = re.match(r'^(.+?)\s*\(([A-Z]?\d{5,})\)\s*$', name.strip())
                if name_match:
                    name = name_match.group(1).strip()
                    filing_number = name_match.group(2)

                # Cell 1: Status
                status_text = extract_text(cells[1]) if len(cells) > 1 else ""

                # Cell 2: Registration date
                reg_date_text = extract_text(cells[2]) if len(cells) > 2 else ""

                # Cell 3: Agent
                agent_text = extract_text(cells[3]) if len(cells) > 3 else ""

                entity_type = MT_ENTITY_TYPES.get(
                    (entity_type_text or "").upper().strip(), EntityType.OTHER
                ) if entity_type_text else EntityType.OTHER

                status = MT_STATUS_MAP.get(
                    (status_text or "").upper().strip(), EntityStatus.OTHER
                ) if status_text else EntityStatus.ACTIVE

                business = Business(
                    name=name.strip(),
                    entity_type=entity_type,
                    status=status,
                    state="MT",
                    filing_number=filing_number,
                    source_url=MT_BIZ_SEARCH_URL,
                    raw_data={
                        "type_text": entity_type_text,
                        "status_text": status_text,
                    },
                )

                yield CollectorResult(
                    category=DataCategory.BUSINESSES.value,
                    state="MT",
                    data=business,
                    source="Montana Secretary of State",
                )
                count += 1

            # Fallback: try table-based results if no stacked results found
            if count == 0:
                rows = extract_table_rows(html)
                for row in rows:
                    if count >= max_results:
                        break
                    name = (
                        row.get("Business Name")
                        or row.get("Entity Name")
                        or row.get("Name")
                        or row.get("col_0")
                    )
                    if not name:
                        continue

                    filing_num = (
                        row.get("Filing Number")
                        or row.get("ID")
                        or row.get("col_1")
                    )
                    type_text = (
                        row.get("Entity Type")
                        or row.get("Type")
                        or row.get("col_2", "")
                    )
                    status_text = (
                        row.get("Status")
                        or row.get("col_3", "")
                    )

                    entity_type = MT_ENTITY_TYPES.get(
                        type_text.upper().strip(), EntityType.OTHER
                    ) if type_text else EntityType.OTHER

                    status = MT_STATUS_MAP.get(
                        status_text.upper().strip(), EntityStatus.OTHER
                    ) if status_text else EntityStatus.ACTIVE

                    business = Business(
                        name=name.strip(),
                        entity_type=entity_type,
                        status=status,
                        state="MT",
                        filing_number=filing_num,
                        source_url=MT_BIZ_SEARCH_URL,
                        raw_data=row,
                    )

                    yield CollectorResult(
                        category=DataCategory.BUSINESSES.value,
                        state="MT",
                        data=business,
                        source="Montana Secretary of State",
                    )
                    count += 1

            logger.info("MT SOS: returned %d business results", count)

        except Exception as e:
            logger.error("MT SOS business search failed: %s", e)
        finally:
            await page.close()

    @staticmethod
    def _parse_date(date_str: str | None) -> date_cls | None:
        """Parse a date string in common US formats."""
        if not date_str:
            return None
        date_str = date_str.strip()
        m = re.match(r"(\d{1,2})/(\d{1,2})/(\d{4})", date_str)
        if m:
            try:
                return date_cls(int(m.group(3)), int(m.group(1)), int(m.group(2)))
            except ValueError:
                pass
        try:
            return date_cls.fromisoformat(date_str)
        except (ValueError, AttributeError):
            pass
        return None
