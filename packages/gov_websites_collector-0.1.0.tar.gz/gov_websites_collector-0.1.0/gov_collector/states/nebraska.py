"""
Nebraska state collector.

Sources:
- NREC (Nebraska Real Estate Commission): License lookups via iGov Solutions
  https://nrec.igovsolution.net/online/Verification/Individual
- Nebraska Secretary of State: Business entity search
  https://www.nebraska.gov/sos/corp/corpsearch.cgi?nav=search
"""

from __future__ import annotations

import logging
import re
from datetime import date as date_cls
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.exceptions import ParseError, ScrapingError
from gov_collector.models import (
    Address,
    Business,
    CollectorResult,
    EntityStatus,
    EntityType,
    License,
    LicenseStatus,
    Person,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import (
    clean_text,
    extract_text,
    parse_html,
    parse_address_text,
    extract_table_rows,
)
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

# --- NREC iGov (Real Estate Licenses) ---

NREC_SEARCH_URL = "https://nrec.igovsolution.net/online/Verification/Individual"
NREC_API_URL = "https://nrec.igovsolution.net/api/verification/search"

# iGov Solutions platform fields
NREC_LICENSE_STATUS_MAP = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "CURRENT": LicenseStatus.ACTIVE,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
    "SUSPENDED": LicenseStatus.SUSPENDED,
    "REVOKED": LicenseStatus.REVOKED,
    "CANCELLED": LicenseStatus.CANCELLED,
    "PENDING": LicenseStatus.PENDING,
    "LAPSED": LicenseStatus.EXPIRED,
    "TERMINATED": LicenseStatus.CANCELLED,
    "SURRENDERED": LicenseStatus.CANCELLED,
}

NREC_LICENSE_TYPES = {
    "Salesperson": "Real Estate Salesperson",
    "Broker": "Real Estate Broker",
    "Associate Broker": "Associate Broker",
    "Branch Broker": "Branch Broker",
}

# --- NE SOS (Business Entity) ---

NE_SOS_SEARCH_URL = "https://www.nebraska.gov/sos/corp/corpsearch.cgi"

NE_ENTITY_TYPES = {
    "LIMITED LIABILITY COMPANY": EntityType.LLC,
    "DOMESTIC LIMITED LIABILITY COMPANY": EntityType.LLC,
    "FOREIGN LIMITED LIABILITY COMPANY": EntityType.LLC,
    "DOMESTIC CORPORATION": EntityType.CORPORATION,
    "FOREIGN CORPORATION": EntityType.CORPORATION,
    "BUSINESS CORPORATION": EntityType.CORPORATION,
    "PROFIT CORPORATION": EntityType.CORPORATION,
    "DOMESTIC NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "FOREIGN NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "LIMITED PARTNERSHIP": EntityType.LP,
    "DOMESTIC LIMITED PARTNERSHIP": EntityType.LP,
    "FOREIGN LIMITED PARTNERSHIP": EntityType.LP,
    "LIMITED LIABILITY PARTNERSHIP": EntityType.LLP,
    "GENERAL PARTNERSHIP": EntityType.PARTNERSHIP,
}

NE_STATUS_MAP = {
    "ACTIVE": EntityStatus.ACTIVE,
    "GOOD STANDING": EntityStatus.ACTIVE,
    "IN GOOD STANDING": EntityStatus.ACTIVE,
    "INACTIVE": EntityStatus.INACTIVE,
    "DISSOLVED": EntityStatus.DISSOLVED,
    "ADMINISTRATIVELY DISSOLVED": EntityStatus.DISSOLVED,
    "VOLUNTARILY DISSOLVED": EntityStatus.DISSOLVED,
    "CANCELLED": EntityStatus.DISSOLVED,
    "REVOKED": EntityStatus.DISSOLVED,
    "WITHDRAWN": EntityStatus.WITHDRAWN,
    "MERGED": EntityStatus.MERGED,
    "CONVERTED": EntityStatus.CONVERTED,
    "FORFEITED": EntityStatus.DISSOLVED,
    "DELINQUENT": EntityStatus.INACTIVE,
}


@StateRegistry.register
class NebraskaCollector(BaseStateCollector):
    """Collector for Nebraska government data.

    Note: Nebraska NREC uses verification codes requiring browser automation.
    """
    
    needs_browser_for = [DataCategory.LICENSES]

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="NE",
            name="Nebraska",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "Nebraska Real Estate Commission (NREC / iGov Solutions)",
                "Nebraska Secretary of State",
            ],
            notes="License search uses iGov Solutions platform",
        )

    # --- Real Estate Licenses ---

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search Nebraska Real Estate Commission for licenses.

        Uses the iGov Solutions platform.
        """
        if not params.query and not params.license_number:
            raise ValueError(
                "Either 'query' (name) or 'license_number' required for NE NREC"
            )

        logger.warning(
            "NE Real Estate Commission (iGov Solutions) may require verification code (CAPTCHA). "
            "Automated searches may not work reliably."
        )

        # Try the iGov API endpoint first
        api_params = {}
        if params.license_number:
            api_params["licenseNumber"] = params.license_number
        elif params.query:
            parts = params.query.strip().split(maxsplit=1)
            api_params["lastName"] = parts[0]
            if len(parts) > 1:
                api_params["firstName"] = parts[1]

        try:
            response = await self.client.post(
                NREC_API_URL,
                json=api_params,
                headers={"Content-Type": "application/json"},
            )
            data = response.json()
        except Exception:
            logger.info("NE NREC API failed, falling back to HTML form")
            async for result in self._nrec_html_search(params):
                yield result
            return

        results = data if isinstance(data, list) else data.get("results", data.get("data", []))

        count = 0
        for record in results:
            if count >= params.max_results:
                return

            result = self._parse_nrec_api_record(record)
            if result:
                yield result
                count += 1

    async def _nrec_html_search(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """Fallback: scrape iGov HTML form results."""
        form_data = {}
        if params.license_number:
            form_data["LicenseNumber"] = params.license_number
        elif params.query:
            parts = params.query.strip().split(maxsplit=1)
            form_data["LastName"] = parts[0]
            if len(parts) > 1:
                form_data["FirstName"] = parts[1]

        try:
            response = await self.client.post(NREC_SEARCH_URL, data=form_data)
            html = response.text
        except Exception as e:
            logger.error("NE NREC HTML search failed: %s", e)
            return

        tree = parse_html(html)

        # iGov typically uses Bootstrap tables
        rows = tree.css(
            "table.table tbody tr, "
            "#searchResults tr, "
            ".verification-results tr"
        )
        if not rows:
            logger.debug("NE NREC: no results found")
            return

        count = 0
        for row in rows:
            if count >= params.max_results:
                return

            cells = row.css("td")
            if len(cells) < 3:
                continue

            # iGov typical columns: Name, License#, Type, Status, Exp Date, City
            name = extract_text(cells[0])
            license_num = extract_text(cells[1])
            license_type = extract_text(cells[2]) if len(cells) > 2 else None
            status_text = extract_text(cells[3]) if len(cells) > 3 else None
            expiration = extract_text(cells[4]) if len(cells) > 4 else None
            city = extract_text(cells[5]) if len(cells) > 5 else None

            if not name or not license_num:
                continue

            status = LicenseStatus.OTHER
            if status_text:
                status = NREC_LICENSE_STATUS_MAP.get(
                    status_text.upper().strip(), LicenseStatus.OTHER
                )

            mapped_type = NREC_LICENSE_TYPES.get(
                (license_type or "").strip(), license_type or "Real Estate"
            )

            exp_date = self._parse_date(expiration)

            address = None
            if city:
                address = Address(city=city, state="NE")

            license_obj = License(
                license_number=license_num.strip(),
                license_type=mapped_type,
                status=status,
                state="NE",
                holder_name=name.strip(),
                address=address,
                expiration_date=exp_date,
                source_url=NREC_SEARCH_URL,
                raw_data={
                    "name": name,
                    "license_type": license_type,
                    "status_text": status_text,
                    "expiration": expiration,
                },
            )

            yield CollectorResult(
                category=DataCategory.LICENSES.value,
                state="NE",
                data=license_obj,
                source="Nebraska Real Estate Commission (iGov)",
            )
            count += 1

    def _parse_nrec_api_record(self, record: dict) -> CollectorResult | None:
        """Parse a single NREC iGov API record."""
        name = (
            record.get("fullName")
            or record.get("name")
            or record.get("licenseName")
        )
        license_num = (
            record.get("licenseNumber")
            or record.get("license_number")
        )

        if not name or not license_num:
            return None

        status_text = record.get("status") or record.get("licenseStatus")
        status = LicenseStatus.OTHER
        if status_text:
            status = NREC_LICENSE_STATUS_MAP.get(
                status_text.upper().strip(), LicenseStatus.OTHER
            )

        license_type = record.get("licenseType") or record.get("type") or "Real Estate"
        mapped_type = NREC_LICENSE_TYPES.get(license_type, license_type)

        exp_date = self._parse_date(record.get("expirationDate"))

        city = record.get("city")
        address = Address(city=city, state="NE") if city else None

        license_obj = License(
            license_number=str(license_num).strip(),
            license_type=mapped_type,
            status=status,
            state="NE",
            holder_name=name.strip(),
            address=address,
            expiration_date=exp_date,
            source_url=NREC_SEARCH_URL,
            raw_data=record,
        )

        return CollectorResult(
            category=DataCategory.LICENSES.value,
            state="NE",
            data=license_obj,
            source="Nebraska Real Estate Commission (iGov)",
        )

    # --- Business Entity Search ---

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search Nebraska Secretary of State for business entities.

        Uses the CGI-based search form at nebraska.gov.
        """
        if not params.query:
            raise ValueError("'query' (business name) required for NE business search")

        form_data = {
            "search": "1",
            "search_type": "keyword_search",
            "keyword_type": "all",
            "corpname": params.query,
        }

        try:
            response = await self.client.post(NE_SOS_SEARCH_URL, data=form_data)
            html = response.text
        except Exception as e:
            logger.error("NE SOS search failed: %s", e)
            return

        tree = parse_html(html)
        rows = tree.css("table tbody tr, table.searchresults tr, table tr")

        count = 0
        for row in rows:
            if count >= params.max_results:
                return

            cells = row.css("td")
            if len(cells) < 2:
                continue

            # Typical: Name, Type, Status, Filing Date, Filing Number
            name = extract_text(cells[0])
            type_text = extract_text(cells[1]) if len(cells) > 1 else None
            status_text = extract_text(cells[2]) if len(cells) > 2 else None
            filing_date_text = extract_text(cells[3]) if len(cells) > 3 else None
            filing_num = extract_text(cells[4]) if len(cells) > 4 else None

            if not name:
                continue

            entity_type = NE_ENTITY_TYPES.get(
                (type_text or "").upper().strip(), EntityType.OTHER
            )
            status = NE_STATUS_MAP.get(
                (status_text or "").upper().strip(), EntityStatus.OTHER
            )

            formation_date = self._parse_date(filing_date_text)

            business = Business(
                name=name.strip(),
                entity_type=entity_type,
                status=status,
                state="NE",
                filing_number=filing_num,
                formation_date=formation_date,
                source_url=NE_SOS_SEARCH_URL,
                raw_data={
                    "type_text": type_text,
                    "status_text": status_text,
                    "filing_date": filing_date_text,
                },
            )

            yield CollectorResult(
                category=DataCategory.BUSINESSES.value,
                state="NE",
                data=business,
                source="Nebraska Secretary of State",
            )
            count += 1

    @staticmethod
    def _parse_date(date_str: str | None) -> date_cls | None:
        """Parse a date string in common US formats."""
        if not date_str:
            return None
        date_str = date_str.strip()
        m = re.match(r"(\d{1,2})/(\d{1,2})/(\d{4})", date_str)
        if m:
            try:
                return date_cls(int(m.group(3)), int(m.group(1)), int(m.group(2)))
            except ValueError:
                pass
        try:
            return date_cls.fromisoformat(date_str)
        except (ValueError, AttributeError):
            pass
        return None
