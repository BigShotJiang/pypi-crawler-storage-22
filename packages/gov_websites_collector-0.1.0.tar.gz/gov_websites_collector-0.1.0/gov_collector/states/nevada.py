"""
Nevada state collector.

Sources:
- NRED (Nevada Real Estate Division): License lookups
  https://red.prod.secure.nv.gov/Lookup/LicenseLookup.aspx
- Nevada Secretary of State: Business entity search
  https://esos.nv.gov/EntitySearch/OnlineEntitySearch
"""

from __future__ import annotations

import logging
import re
from datetime import date as date_cls
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.exceptions import ParseError, ScrapingError
from gov_collector.models import (
    Address,
    Business,
    CollectorResult,
    EntityStatus,
    EntityType,
    License,
    LicenseStatus,
    Person,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import (
    clean_text,
    extract_text,
    parse_html,
    parse_address_text,
    extract_table_rows,
)
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

# --- NRED (Real Estate Licenses) ---

NRED_SEARCH_URL = "https://red.prod.secure.nv.gov/Lookup/LicenseLookup.aspx"

NRED_LICENSE_STATUS_MAP = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "CURRENT": LicenseStatus.ACTIVE,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
    "SUSPENDED": LicenseStatus.SUSPENDED,
    "REVOKED": LicenseStatus.REVOKED,
    "CANCELLED": LicenseStatus.CANCELLED,
    "PENDING": LicenseStatus.PENDING,
    "LAPSED": LicenseStatus.EXPIRED,
    "VOLUNTARY SURRENDER": LicenseStatus.CANCELLED,
    "SURRENDERED": LicenseStatus.CANCELLED,
}

NRED_LICENSE_TYPES = {
    "Salesperson": "Real Estate Salesperson",
    "Broker": "Real Estate Broker",
    "Broker-Salesperson": "Broker-Salesperson",
    "Property Manager": "Property Manager",
    "Business Broker": "Business Broker",
}

# --- NV SOS (Business Entity) ---

NV_SOS_SEARCH_URL = "https://esos.nv.gov/EntitySearch/OnlineEntitySearch"

NV_ENTITY_TYPES = {
    "LIMITED-LIABILITY COMPANY": EntityType.LLC,
    "LIMITED LIABILITY COMPANY": EntityType.LLC,
    "DOMESTIC LLC": EntityType.LLC,
    "FOREIGN LLC": EntityType.LLC,
    "DOMESTIC LIMITED-LIABILITY COMPANY": EntityType.LLC,
    "FOREIGN LIMITED-LIABILITY COMPANY": EntityType.LLC,
    "CORPORATION": EntityType.CORPORATION,
    "DOMESTIC CORPORATION": EntityType.CORPORATION,
    "FOREIGN CORPORATION": EntityType.CORPORATION,
    "PROFIT CORPORATION": EntityType.CORPORATION,
    "NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "DOMESTIC NONPROFIT": EntityType.NONPROFIT,
    "FOREIGN NONPROFIT": EntityType.NONPROFIT,
    "LIMITED PARTNERSHIP": EntityType.LP,
    "DOMESTIC LIMITED PARTNERSHIP": EntityType.LP,
    "FOREIGN LIMITED PARTNERSHIP": EntityType.LP,
    "LIMITED-LIABILITY PARTNERSHIP": EntityType.LLP,
    "LIMITED LIABILITY PARTNERSHIP": EntityType.LLP,
    "GENERAL PARTNERSHIP": EntityType.PARTNERSHIP,
    "SOLE PROPRIETORSHIP": EntityType.SOLE_PROPRIETORSHIP,
    "BUSINESS TRUST": EntityType.TRUST,
}

NV_STATUS_MAP = {
    "ACTIVE": EntityStatus.ACTIVE,
    "IN GOOD STANDING": EntityStatus.ACTIVE,
    "DEFAULT": EntityStatus.INACTIVE,
    "DELINQUENT": EntityStatus.INACTIVE,
    "REVOKED": EntityStatus.DISSOLVED,
    "PERMANENTLY REVOKED": EntityStatus.DISSOLVED,
    "DISSOLVED": EntityStatus.DISSOLVED,
    "WITHDRAWN": EntityStatus.WITHDRAWN,
    "MERGED": EntityStatus.MERGED,
    "CONVERTED": EntityStatus.CONVERTED,
    "EXPIRED": EntityStatus.DISSOLVED,
    "VOID": EntityStatus.DISSOLVED,
}


@StateRegistry.register
class NevadaCollector(BaseStateCollector):
    """Collector for Nevada government data.

    Note: Nevada NRED and SOS both have CAPTCHA/verification protection
    requiring browser automation.
    """
    
    needs_browser_for = [DataCategory.LICENSES, DataCategory.BUSINESSES]

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="NV",
            name="Nevada",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "Nevada Real Estate Division (NRED)",
                "Nevada Secretary of State (ESOS)",
            ],
            notes="Both systems use ASP.NET WebForms with ViewState",
        )

    # --- Real Estate Licenses ---

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search Nevada Real Estate Division for licenses.

        Uses ASP.NET WebForms with ViewState — requires fetching the page
        first to obtain form tokens.
        """
        if not params.query and not params.license_number:
            raise ValueError(
                "Either 'query' (name) or 'license_number' required for NV NRED"
            )

        if not self.has_browser:
            logger.warning("NV NRED requires browser automation (CAPTCHA protection). Use use_browser=True.")
            return
            
        page = await self.browser.new_page()
        count = 0
        try:
            await page.goto(NRED_SEARCH_URL, wait_until="domcontentloaded", timeout=15000)
            
            # Fill search form
            if params.license_number:
                license_input = await page.query_selector("input[id*='txtLicenseNumber']")
                if license_input:
                    await license_input.fill(params.license_number)
            elif params.query:
                parts = params.query.strip().split(maxsplit=1)
                
                last_name_input = await page.query_selector("input[id*='txtLastName']")
                if last_name_input:
                    await last_name_input.fill(parts[0])
                
                if len(parts) > 1:
                    first_name_input = await page.query_selector("input[id*='txtFirstName']")
                    if first_name_input:
                        await first_name_input.fill(parts[1])
            
            # Submit search
            search_btn = await page.query_selector("input[id*='btnSearch'], button[type='submit']")
            if search_btn:
                await search_btn.click()
                
                # Wait for results (or CAPTCHA)
                await page.wait_for_selector("table, .results, .captcha", timeout=10000)
                
                # Check for CAPTCHA
                captcha_element = await page.query_selector(".captcha, input[id*='captcha'], img[alt*='captcha']")
                if captcha_element:
                    logger.error("NV NRED: CAPTCHA detected - cannot proceed with automated search")
                    return
                
                html = await page.content()
                async for result in self._parse_nred_results(html):
                    yield result
                    count += 1
                    if count >= params.max_results:
                        break
                        
        except Exception as e:
            logger.error("NV NRED search failed: %s", e)
            logger.warning("NV NRED has CAPTCHA/405 errors as of Feb 2026")
        finally:
            await page.close()

    async def _parse_nred_results(
        self, html: str
    ) -> AsyncIterator[CollectorResult]:
        """Parse Nevada NRED ASP.NET search results."""
        tree = parse_html(html)

        rows = tree.css(
            "table.GridView tr, table[id*='GridView'] tr, "
            "#MainContent_grdResults tr, #MainContent_GridView1 tr"
        )
        if not rows:
            logger.debug("NV NRED: no results found")
            return

        for row in rows:
            cells = row.css("td")
            if len(cells) < 3:
                continue

            # Typical ASP.NET GridView: Name, License#, Type, Status, Exp Date
            name = extract_text(cells[0])
            license_num = extract_text(cells[1])
            license_type = extract_text(cells[2]) if len(cells) > 2 else None
            status_text = extract_text(cells[3]) if len(cells) > 3 else None
            expiration = extract_text(cells[4]) if len(cells) > 4 else None

            if not name or not license_num:
                continue

            status = LicenseStatus.OTHER
            if status_text:
                status = NRED_LICENSE_STATUS_MAP.get(
                    status_text.upper().strip(), LicenseStatus.OTHER
                )

            mapped_type = NRED_LICENSE_TYPES.get(
                (license_type or "").strip(), license_type or "Real Estate"
            )

            exp_date = self._parse_date(expiration)

            license_obj = License(
                license_number=license_num.strip(),
                license_type=mapped_type,
                status=status,
                state="NV",
                holder_name=name.strip(),
                expiration_date=exp_date,
                source_url=NRED_SEARCH_URL,
                raw_data={
                    "name": name,
                    "license_type": license_type,
                    "status_text": status_text,
                    "expiration": expiration,
                },
            )

            yield CollectorResult(
                category=DataCategory.LICENSES.value,
                state="NV",
                data=license_obj,
                source="Nevada Real Estate Division (NRED)",
            )

    # --- Business Entity Search ---

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search Nevada Secretary of State for business entities.

        Uses the ESOS (Electronic Secretary of State) portal, which is also
        ASP.NET based with ViewState.
        """
        if not params.query:
            raise ValueError("'query' (business name) required for NV business search")

        # Step 1: GET search page for ViewState
        try:
            page_response = await self.client.get(NV_SOS_SEARCH_URL)
            page_html = page_response.text
        except Exception as e:
            logger.error("NV SOS: failed to load search page: %s", e)
            return

        viewstate = self._extract_aspnet_field(page_html, "__VIEWSTATE")
        viewstate_gen = self._extract_aspnet_field(page_html, "__VIEWSTATEGENERATOR")
        event_validation = self._extract_aspnet_field(page_html, "__EVENTVALIDATION")

        # Step 2: POST business name search
        form_data = {
            "__VIEWSTATE": viewstate or "",
            "__VIEWSTATEGENERATOR": viewstate_gen or "",
            "__EVENTVALIDATION": event_validation or "",
            "__EVENTTARGET": "",
            "__EVENTARGUMENT": "",
            "ctl00$MainContent$txtEntityName": params.query,
            "ctl00$MainContent$btnSearch": "Search",
        }

        try:
            response = await self.client.post(NV_SOS_SEARCH_URL, data=form_data)
            html = response.text
        except Exception as e:
            logger.error("NV SOS search failed: %s", e)
            return

        tree = parse_html(html)
        rows = tree.css(
            "table.GridView tr, table[id*='GridView'] tr, "
            "#MainContent_grdResults tr"
        )

        count = 0
        for row in rows:
            if count >= params.max_results:
                return

            cells = row.css("td")
            if len(cells) < 2:
                continue

            name = extract_text(cells[0])
            filing_num = extract_text(cells[1]) if len(cells) > 1 else None
            type_text = extract_text(cells[2]) if len(cells) > 2 else None
            status_text = extract_text(cells[3]) if len(cells) > 3 else None
            formation_text = extract_text(cells[4]) if len(cells) > 4 else None
            nv_biz_id = extract_text(cells[5]) if len(cells) > 5 else None

            if not name:
                continue

            entity_type = NV_ENTITY_TYPES.get(
                (type_text or "").upper().strip(), EntityType.OTHER
            )
            status = NV_STATUS_MAP.get(
                (status_text or "").upper().strip(), EntityStatus.OTHER
            )

            formation_date = self._parse_date(formation_text)

            business = Business(
                name=name.strip(),
                entity_type=entity_type,
                status=status,
                state="NV",
                filing_number=filing_num or nv_biz_id,
                formation_date=formation_date,
                source_url=NV_SOS_SEARCH_URL,
                raw_data={
                    "type_text": type_text,
                    "status_text": status_text,
                    "formation_date": formation_text,
                    "nv_business_id": nv_biz_id,
                },
            )

            yield CollectorResult(
                category=DataCategory.BUSINESSES.value,
                state="NV",
                data=business,
                source="Nevada Secretary of State (ESOS)",
            )
            count += 1

    @staticmethod
    def _extract_aspnet_field(html: str, field_name: str) -> str | None:
        """Extract a hidden ASP.NET form field value."""
        pattern = rf'<input[^>]*name="{re.escape(field_name)}"[^>]*value="([^"]*)"'
        match = re.search(pattern, html, re.IGNORECASE)
        if match:
            return match.group(1)
        # Try alternate attribute order
        pattern2 = rf'<input[^>]*value="([^"]*)"[^>]*name="{re.escape(field_name)}"'
        match2 = re.search(pattern2, html, re.IGNORECASE)
        return match2.group(1) if match2 else None

    @staticmethod
    def _parse_date(date_str: str | None) -> date_cls | None:
        """Parse a date string in common US formats."""
        if not date_str:
            return None
        date_str = date_str.strip()
        m = re.match(r"(\d{1,2})/(\d{1,2})/(\d{4})", date_str)
        if m:
            try:
                return date_cls(int(m.group(3)), int(m.group(1)), int(m.group(2)))
            except ValueError:
                pass
        try:
            return date_cls.fromisoformat(date_str)
        except (ValueError, AttributeError):
            pass
        return None
