"""
New Hampshire state collector.

Sources:
- NHREC (New Hampshire Real Estate Commission): License lookups
  https://forms.nh.gov/licenseverification/
- New Hampshire Secretary of State (QuickStart): Business entity search
  https://quickstart.sos.nh.gov/online/BusinessInquire
"""

from __future__ import annotations

import logging
import re
from datetime import date as date_cls
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.exceptions import ParseError, ScrapingError
from gov_collector.models import (
    Address,
    Business,
    CollectorResult,
    EntityStatus,
    EntityType,
    License,
    LicenseStatus,
    Person,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import (
    clean_text,
    extract_text,
    parse_html,
    parse_address_text,
    extract_table_rows,
)
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

# --- NHREC (Real Estate Licenses) ---

NH_LICENSE_SEARCH_URL = "https://forms.nh.gov/licenseverification/"

NH_LICENSE_STATUS_MAP = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "CURRENT": LicenseStatus.ACTIVE,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
    "SUSPENDED": LicenseStatus.SUSPENDED,
    "REVOKED": LicenseStatus.REVOKED,
    "CANCELLED": LicenseStatus.CANCELLED,
    "PENDING": LicenseStatus.PENDING,
    "LAPSED": LicenseStatus.EXPIRED,
    "VOLUNTARY SURRENDER": LicenseStatus.CANCELLED,
}

NH_LICENSE_TYPES = {
    "Salesperson": "Real Estate Salesperson",
    "Sales Agent": "Real Estate Salesperson",
    "Broker": "Real Estate Broker",
    "Associate Broker": "Associate Broker",
    "Principal Broker": "Principal Broker",
}

# --- NH SOS (Business Entity) ---

NH_BIZ_SEARCH_URL = "https://quickstart.sos.nh.gov/online/BusinessInquire"

NH_ENTITY_TYPES = {
    "LIMITED LIABILITY COMPANY": EntityType.LLC,
    "DOMESTIC LIMITED LIABILITY COMPANY": EntityType.LLC,
    "FOREIGN LIMITED LIABILITY COMPANY": EntityType.LLC,
    "DOMESTIC LLC": EntityType.LLC,
    "FOREIGN LLC": EntityType.LLC,
    "CORPORATION": EntityType.CORPORATION,
    "DOMESTIC BUSINESS CORPORATION": EntityType.CORPORATION,
    "FOREIGN BUSINESS CORPORATION": EntityType.CORPORATION,
    "DOMESTIC PROFIT CORPORATION": EntityType.CORPORATION,
    "FOREIGN PROFIT CORPORATION": EntityType.CORPORATION,
    "DOMESTIC NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "FOREIGN NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "LIMITED PARTNERSHIP": EntityType.LP,
    "DOMESTIC LIMITED PARTNERSHIP": EntityType.LP,
    "FOREIGN LIMITED PARTNERSHIP": EntityType.LP,
    "LIMITED LIABILITY PARTNERSHIP": EntityType.LLP,
    "GENERAL PARTNERSHIP": EntityType.PARTNERSHIP,
    "SOLE PROPRIETORSHIP": EntityType.SOLE_PROPRIETORSHIP,
    "TRADE NAME": EntityType.OTHER,
}

NH_STATUS_MAP = {
    "ACTIVE": EntityStatus.ACTIVE,
    "GOOD STANDING": EntityStatus.ACTIVE,
    "IN GOOD STANDING": EntityStatus.ACTIVE,
    "INACTIVE": EntityStatus.INACTIVE,
    "DISSOLVED": EntityStatus.DISSOLVED,
    "ADMIN DISSOLVED": EntityStatus.DISSOLVED,
    "ADMINISTRATIVELY DISSOLVED": EntityStatus.DISSOLVED,
    "VOLUNTARILY DISSOLVED": EntityStatus.DISSOLVED,
    "CANCELLED": EntityStatus.DISSOLVED,
    "REVOKED": EntityStatus.DISSOLVED,
    "WITHDRAWN": EntityStatus.WITHDRAWN,
    "EXPIRED": EntityStatus.DISSOLVED,
    "MERGED": EntityStatus.MERGED,
}


@StateRegistry.register
class NewHampshireCollector(BaseStateCollector):
    """Collector for New Hampshire government data."""
    
    needs_browser_for = [DataCategory.LICENSES, DataCategory.BUSINESSES]

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="NH",
            name="New Hampshire",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "New Hampshire Real Estate Commission (NHREC) - WARNING: Returns 403 Forbidden",
                "New Hampshire Secretary of State (QuickStart) - WARNING: Returns 403 Forbidden",
            ],
            notes="Both license and business sites return 403 Forbidden as of Feb 2026.",
        )

    # --- Real Estate Licenses ---

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search New Hampshire Real Estate Commission for licenses.

        Uses the NH.gov license verification form.
        """
        if not params.query and not params.license_number:
            raise ValueError(
                "Either 'query' (name) or 'license_number' required for NH license search"
            )

        logger.warning("New Hampshire license verification returns 403 Forbidden as of Feb 2026. Unable to search licenses.")
        return
        
        # Legacy code kept for reference when access is restored:

        form_data = {
            "board": "real_estate",
        }

        if params.license_number:
            form_data["license_number"] = params.license_number
        elif params.query:
            parts = params.query.strip().split(maxsplit=1)
            form_data["last_name"] = parts[0]
            if len(parts) > 1:
                form_data["first_name"] = parts[1]

        if params.city:
            form_data["city"] = params.city

        try:
            response = await self.client.post(NH_LICENSE_SEARCH_URL, data=form_data)
            html = response.text
        except Exception as e:
            logger.error("NH license search failed: %s", e)
            return

        count = 0
        async for result in self._parse_nh_license_results(html):
            yield result
            count += 1
            if count >= params.max_results:
                return

    async def _parse_nh_license_results(
        self, html: str
    ) -> AsyncIterator[CollectorResult]:
        """Parse NH license verification results."""
        tree = parse_html(html)

        rows = tree.css("table tbody tr, table.results tr, .search-results tr")
        if not rows:
            logger.debug("NH license search: no results found")
            return

        for row in rows:
            cells = row.css("td")
            if len(cells) < 3:
                continue

            name = extract_text(cells[0])
            license_num = extract_text(cells[1])
            license_type = extract_text(cells[2]) if len(cells) > 2 else None
            status_text = extract_text(cells[3]) if len(cells) > 3 else None
            expiration = extract_text(cells[4]) if len(cells) > 4 else None
            city = extract_text(cells[5]) if len(cells) > 5 else None

            if not name or not license_num:
                continue

            status = LicenseStatus.OTHER
            if status_text:
                status = NH_LICENSE_STATUS_MAP.get(
                    status_text.upper().strip(), LicenseStatus.OTHER
                )

            mapped_type = NH_LICENSE_TYPES.get(
                (license_type or "").strip(), license_type or "Real Estate"
            )

            exp_date = self._parse_date(expiration)

            address = None
            if city:
                address = Address(city=city, state="NH")

            license_obj = License(
                license_number=license_num.strip(),
                license_type=mapped_type,
                status=status,
                state="NH",
                holder_name=name.strip(),
                address=address,
                expiration_date=exp_date,
                source_url=NH_LICENSE_SEARCH_URL,
                raw_data={
                    "name": name,
                    "license_type": license_type,
                    "status_text": status_text,
                    "expiration": expiration,
                },
            )

            yield CollectorResult(
                category=DataCategory.LICENSES.value,
                state="NH",
                data=license_obj,
                source="New Hampshire Real Estate Commission (NHREC)",
            )

    # --- Business Entity Search ---

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search New Hampshire Secretary of State QuickStart for business entities.

        HTTP access returns 403 Forbidden.  Requires Camoufox browser.
        Form: POST to /online/BusinessInquire/BusinessSearch
        Fields: rbBasicSearch=BusinessName, rbBusinessNameSearch=Contains,
                txtBusinessName=<query>
        Result table columns: Business Name, Business ID, Homestate Name,
                Previous Name, Business Type, Principal Office Address,
                Registered Agent Name, Status
        """
        if not params.query:
            raise ValueError("'query' (business name) required for NH business search")

        if not self.has_browser:
            logger.warning(
                "NH SOS requires Camoufox browser (site blocks HTTP). "
                "Use use_camoufox=True."
            )
            return

        import asyncio as _aio

        page = None
        try:
            page = await self.browser.new_page()
            await page.goto(
                NH_BIZ_SEARCH_URL,
                wait_until="domcontentloaded",
                timeout=20000,
            )
            await _aio.sleep(2)

            # Select business name search + contains
            await page.click("#rbBusinessName")
            await _aio.sleep(0.3)
            await page.click("#rbContains")
            await _aio.sleep(0.3)
            await page.fill("#txtBusinessName", params.query)

            # Click search
            submit = await page.query_selector('input[type="submit"]')
            if submit:
                await submit.click()
            else:
                await page.keyboard.press("Enter")

            await _aio.sleep(5)

            html = await page.content()
        except Exception as e:
            logger.error("NH SOS browser search failed: %s", e)
            return
        finally:
            if page:
                await page.close()

        tree = parse_html(html)

        # Find the results table (largest table with > 2 rows)
        result_table = None
        for t in tree.css("table"):
            rows = t.css("tr")
            if len(rows) > 2:
                result_table = t
                break

        if not result_table:
            logger.info("NH SOS: no results found")
            return

        rows = result_table.css("tr")
        count = 0
        for row in rows:
            if count >= params.max_results:
                return

            cells = row.css("td")
            if len(cells) != 8:
                continue

            # Columns: Business Name, Business ID, Homestate Name,
            #          Previous Name, Business Type, Principal Office Address,
            #          Registered Agent Name, Status
            name = clean_text(cells[0].text(deep=True))
            biz_id = clean_text(cells[1].text(deep=True))
            type_text = clean_text(cells[4].text(deep=True))
            address_text = clean_text(cells[5].text(deep=True))
            agent_text = clean_text(cells[6].text(deep=True))
            status_text = clean_text(cells[7].text(deep=True))

            if not name or name.upper() == "BUSINESS NAME":
                continue

            entity_type = NH_ENTITY_TYPES.get(
                (type_text or "").upper().strip(), EntityType.OTHER
            )
            status = NH_STATUS_MAP.get(
                (status_text or "").upper().strip(), EntityStatus.OTHER
            )
            # Extra status mappings
            if status == EntityStatus.OTHER and status_text:
                st = status_text.upper().strip()
                if "GOOD STANDING" in st:
                    status = EntityStatus.ACTIVE
                elif "EXPIRED" in st:
                    status = EntityStatus.INACTIVE
                elif "DISSOLUTION" in st or "DISSOLVED" in st:
                    status = EntityStatus.DISSOLVED

            address = None
            if address_text and address_text != "N/A":
                address = parse_address_text(address_text)

            business = Business(
                name=name.strip(),
                entity_type=entity_type,
                status=status,
                state="NH",
                filing_number=biz_id,
                address=address,
                source_url=NH_BIZ_SEARCH_URL,
                raw_data={
                    "type_text": type_text,
                    "status_text": status_text,
                    "agent": agent_text,
                },
            )

            yield CollectorResult(
                category=DataCategory.BUSINESSES.value,
                state="NH",
                data=business,
                source="New Hampshire Secretary of State (QuickStart)",
            )
            count += 1

    @staticmethod
    def _parse_date(date_str: str | None) -> date_cls | None:
        """Parse a date string in common US formats."""
        if not date_str:
            return None
        date_str = date_str.strip()
        m = re.match(r"(\d{1,2})/(\d{1,2})/(\d{4})", date_str)
        if m:
            try:
                return date_cls(int(m.group(3)), int(m.group(1)), int(m.group(2)))
            except ValueError:
                pass
        try:
            return date_cls.fromisoformat(date_str)
        except (ValueError, AttributeError):
            pass
        return None
