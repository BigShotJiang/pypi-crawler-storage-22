"""
New Jersey state collector.

Sources:
- NJREC (New Jersey Real Estate Commission): License lookups
  https://newjersey.mylicense.com/verification/Search.aspx
- New Jersey Division of Revenue: Business entity search
  https://www.njportal.com/DOR/BusinessNameSearch/Search/BusinessName
"""

from __future__ import annotations

import logging
import re
from datetime import date as date_cls
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.exceptions import ParseError, ScrapingError
from gov_collector.models import (
    Address,
    Business,
    CollectorResult,
    EntityStatus,
    EntityType,
    License,
    LicenseStatus,
    Person,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import (
    clean_text,
    extract_text,
    parse_html,
    parse_address_text,
    extract_table_rows,
)
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

# --- NJREC (Real Estate Licenses) ---

NJ_LICENSE_SEARCH_URL = "https://newjersey.mylicense.com/verification/Search.aspx"

NJ_LICENSE_STATUS_MAP = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "CURRENT": LicenseStatus.ACTIVE,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
    "SUSPENDED": LicenseStatus.SUSPENDED,
    "REVOKED": LicenseStatus.REVOKED,
    "CANCELLED": LicenseStatus.CANCELLED,
    "PENDING": LicenseStatus.PENDING,
    "LAPSED": LicenseStatus.EXPIRED,
    "SURRENDERED": LicenseStatus.CANCELLED,
    "VOLUNTARILY SURRENDERED": LicenseStatus.CANCELLED,
}

NJ_LICENSE_TYPES = {
    "Salesperson": "Real Estate Salesperson",
    "Broker": "Real Estate Broker",
    "Broker-Salesperson": "Broker-Salesperson",
    "Referral Agent": "Referral Agent",
    "Branch Office": "Branch Office",
}

# --- NJ DOR (Business Entity) ---

NJ_BIZ_SEARCH_URL = (
    "https://www.njportal.com/DOR/BusinessNameSearch/Search/BusinessName"
)

NJ_ENTITY_TYPES = {
    "LIMITED LIABILITY COMPANY": EntityType.LLC,
    "DOMESTIC LIMITED LIABILITY COMPANY": EntityType.LLC,
    "FOREIGN LIMITED LIABILITY COMPANY": EntityType.LLC,
    "DOMESTIC LLC": EntityType.LLC,
    "FOREIGN LLC": EntityType.LLC,
    "PROFIT CORPORATION": EntityType.CORPORATION,
    "DOMESTIC CORPORATION": EntityType.CORPORATION,
    "FOREIGN CORPORATION": EntityType.CORPORATION,
    "DOMESTIC PROFIT CORPORATION": EntityType.CORPORATION,
    "FOREIGN PROFIT CORPORATION": EntityType.CORPORATION,
    "NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "DOMESTIC NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "FOREIGN NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "LIMITED PARTNERSHIP": EntityType.LP,
    "DOMESTIC LIMITED PARTNERSHIP": EntityType.LP,
    "FOREIGN LIMITED PARTNERSHIP": EntityType.LP,
    "LIMITED LIABILITY PARTNERSHIP": EntityType.LLP,
    "GENERAL PARTNERSHIP": EntityType.PARTNERSHIP,
    "SOLE PROPRIETORSHIP": EntityType.SOLE_PROPRIETORSHIP,
    "TRADE NAME": EntityType.OTHER,
}

NJ_STATUS_MAP = {
    "ACTIVE": EntityStatus.ACTIVE,
    "IN GOOD STANDING": EntityStatus.ACTIVE,
    "GOOD STANDING": EntityStatus.ACTIVE,
    "INACTIVE": EntityStatus.INACTIVE,
    "DISSOLVED": EntityStatus.DISSOLVED,
    "ADMINISTRATIVELY DISSOLVED": EntityStatus.DISSOLVED,
    "VOLUNTARILY DISSOLVED": EntityStatus.DISSOLVED,
    "CANCELLED": EntityStatus.DISSOLVED,
    "REVOKED": EntityStatus.DISSOLVED,
    "WITHDRAWN": EntityStatus.WITHDRAWN,
    "EXPIRED": EntityStatus.DISSOLVED,
    "MERGED": EntityStatus.MERGED,
    "CONVERTED": EntityStatus.CONVERTED,
    "SUSPENDED": EntityStatus.SUSPENDED,
}


@StateRegistry.register
class NewJerseyCollector(BaseStateCollector):
    """Collector for New Jersey government data.

    Note: NJ uses ASP.NET WebForms with ViewState for license search
    (newjersey.mylicense.com), requiring a two-step GET+POST approach.
    The business name search portal uses a different system.
    """

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="NJ",
            name="New Jersey",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "New Jersey Real Estate Commission (NJREC / mylicense.com)",
                "New Jersey Division of Revenue (Business Name Search)",
            ],
            notes="License search uses ASP.NET with ViewState",
        )

    # --- Real Estate Licenses ---

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search New Jersey Real Estate Commission for licenses.

        Uses the mylicense.com ASP.NET platform with ViewState.
        """
        if not params.query and not params.license_number:
            raise ValueError(
                "Either 'query' (name) or 'license_number' required for NJ NJREC"
            )

        # Step 1: GET the search page for ViewState tokens
        try:
            page_response = await self.client.get(NJ_LICENSE_SEARCH_URL)
            page_html = page_response.text
        except Exception as e:
            logger.error("NJ license search: failed to load page: %s", e)
            return

        viewstate = self._extract_aspnet_field(page_html, "__VIEWSTATE")
        viewstate_gen = self._extract_aspnet_field(page_html, "__VIEWSTATEGENERATOR")
        event_validation = self._extract_aspnet_field(page_html, "__EVENTVALIDATION")

        if not viewstate:
            logger.error("NJ license search: could not extract ViewState")
            return

        # Step 2: POST search form
        form_data = {
            "__VIEWSTATE": viewstate,
            "__VIEWSTATEGENERATOR": viewstate_gen or "",
            "__EVENTVALIDATION": event_validation or "",
            "__EVENTTARGET": "",
            "__EVENTARGUMENT": "",
        }

        if params.license_number:
            form_data["t_web_lookup__license_no"] = params.license_number
        elif params.query:
            parts = params.query.strip().split(maxsplit=1)
            form_data["t_web_lookup__last_name"] = parts[0]
            if len(parts) > 1:
                form_data["t_web_lookup__first_name"] = parts[1]

        form_data["sch_button"] = "Search"

        try:
            response = await self.client.post(NJ_LICENSE_SEARCH_URL, data=form_data)
            html = response.text
        except Exception as e:
            logger.error("NJ license search failed: %s", e)
            return

        count = 0
        async for result in self._parse_nj_license_results(html):
            yield result
            count += 1
            if count >= params.max_results:
                return

    async def _parse_nj_license_results(
        self, html: str
    ) -> AsyncIterator[CollectorResult]:
        """Parse NJ mylicense.com ASP.NET search results.

        The results table (id=datagrid_results) has rows with 10 cells:
        [Name, Name(dup), "", "", LicenseNo, Profession, LicenseType, Status, City, State]
        Each result has 3 rows (main + 2 detail sub-rows with 1 cell each).
        """
        tree = parse_html(html)

        table = tree.css_first("table#datagrid_results")
        if not table:
            # Fallback: try other table selectors
            table = tree.css_first(
                "table.datagrid, table[id*='datagrid'], table.DataGrid"
            )
        if not table:
            logger.debug("NJ license search: no results table found")
            return

        rows = table.css("tr")
        # Skip header row
        for row in rows[1:]:
            cells = row.css("td")
            # Only process main data rows (10 cells), skip sub-rows (1 cell)
            if len(cells) < 7:
                continue

            # Columns: Name, Name(dup), spacer, spacer, LicenseNo, Profession, Type, Status, City, State
            name = extract_text(cells[0])
            license_num = extract_text(cells[4]) if len(cells) > 4 else None
            profession = extract_text(cells[5]) if len(cells) > 5 else None
            license_type = extract_text(cells[6]) if len(cells) > 6 else None
            status_text = extract_text(cells[7]) if len(cells) > 7 else None
            city = extract_text(cells[8]) if len(cells) > 8 else None
            state = extract_text(cells[9]) if len(cells) > 9 else None

            if not name or not license_num:
                continue

            status = LicenseStatus.OTHER
            if status_text:
                status_key = status_text.upper().strip()
                # Handle compound statuses like "Not Active"
                if status_key == "NOT ACTIVE":
                    status = LicenseStatus.INACTIVE
                else:
                    status = NJ_LICENSE_STATUS_MAP.get(
                        status_key, LicenseStatus.OTHER
                    )

            type_label = license_type or profession or "Real Estate"

            address = None
            if city:
                address = Address(
                    city=city.strip(),
                    state=state.strip() if state else "NJ",
                )

            license_obj = License(
                license_number=license_num.strip(),
                license_type=type_label.strip(),
                status=status,
                state="NJ",
                holder_name=name.strip(),
                address=address,
                source_url=NJ_LICENSE_SEARCH_URL,
                raw_data={
                    "name": name,
                    "profession": profession,
                    "license_type": license_type,
                    "status_text": status_text,
                    "city": city,
                    "state": state,
                },
            )

            yield CollectorResult(
                category=DataCategory.LICENSES.value,
                state="NJ",
                data=license_obj,
                source="New Jersey Real Estate Commission (mylicense.com)",
            )

    # --- Business Entity Search ---

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search New Jersey Division of Revenue for business entities.

        Uses the NJ Portal business name search.
        """
        if not params.query:
            raise ValueError("'query' (business name) required for NJ business search")

        form_data = {
            "BusinessName": params.query,
            "SelectedSearchType": "Contains",
        }

        try:
            response = await self.client.post(NJ_BIZ_SEARCH_URL, data=form_data)
            html = response.text
        except Exception as e:
            logger.error("NJ DOR business search failed: %s", e)
            return

        tree = parse_html(html)
        rows = tree.css(
            "table tbody tr, .search-results tr, "
            "#searchResults tr, .result-row"
        )

        count = 0
        for row in rows:
            if count >= params.max_results:
                return

            cells = row.css("td")
            if len(cells) < 2:
                # Try div-based layout
                name_el = row.css_first(".business-name, a, .name")
                id_el = row.css_first(".filing-number, .entity-id")
                type_el = row.css_first(".entity-type, .type")
                status_el = row.css_first(".entity-status, .status")
                date_el = row.css_first(".filing-date, .date")

                name = extract_text(name_el) if name_el else None
                filing_num = extract_text(id_el) if id_el else None
                type_text = extract_text(type_el) if type_el else None
                status_text = extract_text(status_el) if status_el else None
                filing_date_text = extract_text(date_el) if date_el else None
            else:
                name = extract_text(cells[0])
                filing_num = extract_text(cells[1]) if len(cells) > 1 else None
                type_text = extract_text(cells[2]) if len(cells) > 2 else None
                status_text = extract_text(cells[3]) if len(cells) > 3 else None
                filing_date_text = extract_text(cells[4]) if len(cells) > 4 else None

            if not name:
                continue

            entity_type = NJ_ENTITY_TYPES.get(
                (type_text or "").upper().strip(), EntityType.OTHER
            )
            status = NJ_STATUS_MAP.get(
                (status_text or "").upper().strip(), EntityStatus.OTHER
            )

            formation_date = self._parse_date(filing_date_text)

            business = Business(
                name=name.strip(),
                entity_type=entity_type,
                status=status,
                state="NJ",
                filing_number=filing_num,
                formation_date=formation_date,
                source_url=NJ_BIZ_SEARCH_URL,
                raw_data={
                    "type_text": type_text,
                    "status_text": status_text,
                    "filing_date": filing_date_text,
                },
            )

            yield CollectorResult(
                category=DataCategory.BUSINESSES.value,
                state="NJ",
                data=business,
                source="New Jersey Division of Revenue",
            )
            count += 1

    @staticmethod
    def _extract_aspnet_field(html: str, field_name: str) -> str | None:
        """Extract a hidden ASP.NET form field value."""
        pattern = rf'<input[^>]*name="{re.escape(field_name)}"[^>]*value="([^"]*)"'
        match = re.search(pattern, html, re.IGNORECASE)
        if match:
            return match.group(1)
        pattern2 = rf'<input[^>]*value="([^"]*)"[^>]*name="{re.escape(field_name)}"'
        match2 = re.search(pattern2, html, re.IGNORECASE)
        return match2.group(1) if match2 else None

    @staticmethod
    def _parse_date(date_str: str | None) -> date_cls | None:
        """Parse a date string in common US formats."""
        if not date_str:
            return None
        date_str = date_str.strip()
        m = re.match(r"(\d{1,2})/(\d{1,2})/(\d{4})", date_str)
        if m:
            try:
                return date_cls(int(m.group(3)), int(m.group(1)), int(m.group(2)))
            except ValueError:
                pass
        try:
            return date_cls.fromisoformat(date_str)
        except (ValueError, AttributeError):
            pass
        return None
