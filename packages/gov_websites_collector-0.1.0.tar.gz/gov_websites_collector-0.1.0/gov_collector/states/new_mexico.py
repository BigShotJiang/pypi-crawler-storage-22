"""
New Mexico state collector.

Sources:
- NMREC (New Mexico Real Estate Commission): License lookups
  https://www.rld.nm.gov/boards-and-commissions/real-estate-commission/real-estate-licensee-look-up/
- New Mexico Secretary of State: Business entity search
  https://enterprise.sos.nm.gov/search/business
"""

from __future__ import annotations

import logging
import re
from datetime import date as date_cls
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.exceptions import ParseError, ScrapingError
from gov_collector.models import (
    Address,
    Business,
    CollectorResult,
    EntityStatus,
    EntityType,
    License,
    LicenseStatus,
    Person,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import (
    clean_text,
    extract_text,
    parse_html,
    parse_address_text,
    extract_table_rows,
)
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

# --- NMREC (Real Estate Licenses) ---

NM_LICENSE_SEARCH_URL = (
    "https://www.rld.nm.gov/boards-and-commissions/"
    "real-estate-commission/real-estate-licensee-look-up/"
)
NM_RLD_VERIFY_URL = "https://rfrpapi.rld.nm.gov/api/license/search"

NM_LICENSE_STATUS_MAP = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "CURRENT": LicenseStatus.ACTIVE,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
    "SUSPENDED": LicenseStatus.SUSPENDED,
    "REVOKED": LicenseStatus.REVOKED,
    "CANCELLED": LicenseStatus.CANCELLED,
    "PENDING": LicenseStatus.PENDING,
    "LAPSED": LicenseStatus.EXPIRED,
    "SURRENDERED": LicenseStatus.CANCELLED,
    "VOLUNTARY SURRENDER": LicenseStatus.CANCELLED,
}

NM_LICENSE_TYPES = {
    "Qualifying Broker": "Qualifying Broker",
    "Associate Broker": "Associate Broker",
    "Salesperson": "Real Estate Salesperson",
    "Sales Associate": "Real Estate Salesperson",
    "Broker": "Real Estate Broker",
    "Appraiser": "Real Estate Appraiser",
}

# --- NM SOS (Business Entity) ---

NM_BIZ_SEARCH_URL = "https://enterprise.sos.nm.gov/search/business"
NM_BIZ_API_URL = "https://enterprise.sos.nm.gov/api/search"

NM_ENTITY_TYPES = {
    "LIMITED LIABILITY COMPANY": EntityType.LLC,
    "DOMESTIC LIMITED LIABILITY COMPANY": EntityType.LLC,
    "FOREIGN LIMITED LIABILITY COMPANY": EntityType.LLC,
    "DOMESTIC LLC": EntityType.LLC,
    "FOREIGN LLC": EntityType.LLC,
    "CORPORATION": EntityType.CORPORATION,
    "DOMESTIC PROFIT CORPORATION": EntityType.CORPORATION,
    "FOREIGN PROFIT CORPORATION": EntityType.CORPORATION,
    "DOMESTIC BUSINESS CORPORATION": EntityType.CORPORATION,
    "FOREIGN BUSINESS CORPORATION": EntityType.CORPORATION,
    "DOMESTIC NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "FOREIGN NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "LIMITED PARTNERSHIP": EntityType.LP,
    "DOMESTIC LIMITED PARTNERSHIP": EntityType.LP,
    "FOREIGN LIMITED PARTNERSHIP": EntityType.LP,
    "LIMITED LIABILITY PARTNERSHIP": EntityType.LLP,
    "GENERAL PARTNERSHIP": EntityType.PARTNERSHIP,
    "SOLE PROPRIETORSHIP": EntityType.SOLE_PROPRIETORSHIP,
}

NM_STATUS_MAP = {
    "ACTIVE": EntityStatus.ACTIVE,
    "GOOD STANDING": EntityStatus.ACTIVE,
    "IN GOOD STANDING": EntityStatus.ACTIVE,
    "CURRENT": EntityStatus.ACTIVE,
    "INACTIVE": EntityStatus.INACTIVE,
    "DISSOLVED": EntityStatus.DISSOLVED,
    "ADMINISTRATIVELY DISSOLVED": EntityStatus.DISSOLVED,
    "VOLUNTARILY DISSOLVED": EntityStatus.DISSOLVED,
    "REVOKED": EntityStatus.DISSOLVED,
    "CANCELLED": EntityStatus.DISSOLVED,
    "WITHDRAWN": EntityStatus.WITHDRAWN,
    "EXPIRED": EntityStatus.DISSOLVED,
    "MERGED": EntityStatus.MERGED,
    "CONVERTED": EntityStatus.CONVERTED,
    "SUSPENDED": EntityStatus.SUSPENDED,
}


@StateRegistry.register
class NewMexicoCollector(BaseStateCollector):
    """Collector for New Mexico government data.

    Note: New Mexico uses a newer platform (enterprise.sos.nm.gov) for
    business entity search which may have an API backend. The RLD
    (Regulation and Licensing Department) handles real estate licenses.
    """

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="NM",
            name="New Mexico",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "New Mexico Real Estate Commission (RLD/NMREC)",
                "New Mexico Secretary of State (Enterprise Portal)",
            ],
            notes="SOS uses newer enterprise platform; RLD may have API",
        )

    # --- Real Estate Licenses ---

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search New Mexico Real Estate Commission for licenses.

        Tries the RLD API first, then falls back to HTML scraping.
        """
        if not params.query and not params.license_number:
            raise ValueError(
                "Either 'query' (name) or 'license_number' required for NM license search"
            )

        logger.warning(
            "NM Real Estate Commission (RLD) API may have timeout issues. "
            "Searches may hang or fail with network timeouts."
        )

        # Try the RLD API first
        api_params = {
            "boardCode": "REC",  # Real Estate Commission
        }
        if params.license_number:
            api_params["licenseNumber"] = params.license_number
        elif params.query:
            parts = params.query.strip().split(maxsplit=1)
            api_params["lastName"] = parts[0]
            if len(parts) > 1:
                api_params["firstName"] = parts[1]

        try:
            response = await self.client.post(
                NM_RLD_VERIFY_URL,
                json=api_params,
                headers={"Content-Type": "application/json"},
            )
            data = response.json()
        except Exception:
            logger.info("NM RLD API failed, falling back to HTML")
            async for result in self._nm_license_html_search(params):
                yield result
            return

        results = data if isinstance(data, list) else data.get("results", data.get("data", []))

        count = 0
        for record in results:
            if count >= params.max_results:
                return

            result = self._parse_nm_license_record(record)
            if result:
                yield result
                count += 1

    async def _nm_license_html_search(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """Fallback: HTML scraping for NM license search."""
        form_data = {}
        if params.license_number:
            form_data["license_number"] = params.license_number
        elif params.query:
            parts = params.query.strip().split(maxsplit=1)
            form_data["last_name"] = parts[0]
            if len(parts) > 1:
                form_data["first_name"] = parts[1]

        form_data["board"] = "REC"

        try:
            response = await self.client.post(NM_LICENSE_SEARCH_URL, data=form_data)
            html = response.text
        except Exception as e:
            logger.error("NM license HTML search failed: %s", e)
            return

        tree = parse_html(html)
        rows = tree.css("table tbody tr, .search-results tr, .licensee-results tr")
        if not rows:
            logger.debug("NM license search: no results found")
            return

        count = 0
        for row in rows:
            if count >= params.max_results:
                return

            cells = row.css("td")
            if len(cells) < 3:
                continue

            name = extract_text(cells[0])
            license_num = extract_text(cells[1])
            license_type = extract_text(cells[2]) if len(cells) > 2 else None
            status_text = extract_text(cells[3]) if len(cells) > 3 else None
            expiration = extract_text(cells[4]) if len(cells) > 4 else None
            city = extract_text(cells[5]) if len(cells) > 5 else None

            if not name or not license_num:
                continue

            status = LicenseStatus.OTHER
            if status_text:
                status = NM_LICENSE_STATUS_MAP.get(
                    status_text.upper().strip(), LicenseStatus.OTHER
                )

            mapped_type = NM_LICENSE_TYPES.get(
                (license_type or "").strip(), license_type or "Real Estate"
            )

            exp_date = self._parse_date(expiration)

            address = None
            if city:
                address = Address(city=city, state="NM")

            license_obj = License(
                license_number=license_num.strip(),
                license_type=mapped_type,
                status=status,
                state="NM",
                holder_name=name.strip(),
                address=address,
                expiration_date=exp_date,
                source_url=NM_LICENSE_SEARCH_URL,
                raw_data={
                    "name": name,
                    "license_type": license_type,
                    "status_text": status_text,
                    "expiration": expiration,
                },
            )

            yield CollectorResult(
                category=DataCategory.LICENSES.value,
                state="NM",
                data=license_obj,
                source="New Mexico Real Estate Commission (RLD)",
            )
            count += 1

    def _parse_nm_license_record(self, record: dict) -> CollectorResult | None:
        """Parse a single NM RLD API record."""
        name = (
            record.get("fullName")
            or record.get("name")
            or record.get("licenseName")
        )
        license_num = (
            record.get("licenseNumber")
            or record.get("license_number")
        )

        if not name or not license_num:
            return None

        status_text = record.get("status") or record.get("licenseStatus")
        status = LicenseStatus.OTHER
        if status_text:
            status = NM_LICENSE_STATUS_MAP.get(
                status_text.upper().strip(), LicenseStatus.OTHER
            )

        license_type = record.get("licenseType") or record.get("type") or "Real Estate"
        mapped_type = NM_LICENSE_TYPES.get(license_type, license_type)

        exp_date = self._parse_date(record.get("expirationDate"))

        city = record.get("city")
        address = Address(city=city, state="NM") if city else None

        license_obj = License(
            license_number=str(license_num).strip(),
            license_type=mapped_type,
            status=status,
            state="NM",
            holder_name=name.strip(),
            address=address,
            expiration_date=exp_date,
            source_url=NM_LICENSE_SEARCH_URL,
            raw_data=record,
        )

        return CollectorResult(
            category=DataCategory.LICENSES.value,
            state="NM",
            data=license_obj,
            source="New Mexico Real Estate Commission (RLD)",
        )

    # --- Business Entity Search ---

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search New Mexico Secretary of State for business entities.

        Uses the newer enterprise.sos.nm.gov platform. Tries an API
        endpoint first, then falls back to HTML scraping.
        """
        if not params.query:
            raise ValueError("'query' (business name) required for NM business search")

        # Try the API endpoint first
        search_payload = {
            "query": params.query,
            "searchType": "BusinessName",
        }

        try:
            response = await self.client.post(
                NM_BIZ_API_URL,
                json=search_payload,
                headers={"Content-Type": "application/json"},
            )
            data = response.json()
        except Exception:
            logger.info("NM SOS API failed, falling back to HTML search")
            async for result in self._nm_biz_html_search(params):
                yield result
            return

        results = data if isinstance(data, list) else data.get("results", data.get("data", []))

        count = 0
        for record in results:
            if count >= params.max_results:
                return

            business = self._parse_nm_biz_record(record)
            if business:
                yield CollectorResult(
                    category=DataCategory.BUSINESSES.value,
                    state="NM",
                    data=business,
                    source="New Mexico Secretary of State (Enterprise)",
                )
                count += 1

    async def _nm_biz_html_search(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """Fallback: scrape NM SOS HTML results."""
        try:
            response = await self.client.get(
                NM_BIZ_SEARCH_URL,
                params={"query": params.query},
            )
            html = response.text
        except Exception as e:
            logger.error("NM SOS HTML search failed: %s", e)
            return

        tree = parse_html(html)
        rows = tree.css("table tbody tr, .search-result, .entity-row")

        count = 0
        for row in rows:
            if count >= params.max_results:
                return

            cells = row.css("td")
            if len(cells) < 2:
                # Try div-based layout
                name_el = row.css_first(".entity-name, a, .name")
                id_el = row.css_first(".entity-id, .filing-number")
                type_el = row.css_first(".entity-type, .type")
                status_el = row.css_first(".entity-status, .status")

                name = extract_text(name_el) if name_el else None
                filing_num = extract_text(id_el) if id_el else None
                type_text = extract_text(type_el) if type_el else None
                status_text = extract_text(status_el) if status_el else None
            else:
                name = extract_text(cells[0])
                filing_num = extract_text(cells[1]) if len(cells) > 1 else None
                type_text = extract_text(cells[2]) if len(cells) > 2 else None
                status_text = extract_text(cells[3]) if len(cells) > 3 else None

            if not name:
                continue

            entity_type = NM_ENTITY_TYPES.get(
                (type_text or "").upper().strip(), EntityType.OTHER
            )
            status = NM_STATUS_MAP.get(
                (status_text or "").upper().strip(), EntityStatus.OTHER
            )

            business = Business(
                name=name.strip(),
                entity_type=entity_type,
                status=status,
                state="NM",
                filing_number=filing_num,
                source_url=NM_BIZ_SEARCH_URL,
                raw_data={
                    "type_text": type_text,
                    "status_text": status_text,
                },
            )

            yield CollectorResult(
                category=DataCategory.BUSINESSES.value,
                state="NM",
                data=business,
                source="New Mexico Secretary of State (Enterprise)",
            )
            count += 1

    def _parse_nm_biz_record(self, record: dict) -> Business | None:
        """Parse a single NM SOS API record."""
        name = (
            record.get("businessName")
            or record.get("name")
            or record.get("entityName")
        )
        if not name:
            return None

        type_str = (
            record.get("entityType") or record.get("type") or ""
        ).upper().strip()
        entity_type = NM_ENTITY_TYPES.get(type_str, EntityType.OTHER)

        status_str = (
            record.get("status") or record.get("entityStatus") or ""
        ).upper().strip()
        status = NM_STATUS_MAP.get(status_str, EntityStatus.OTHER)

        filing_number = record.get("filingNumber") or record.get("businessId")

        formation_date = self._parse_date(
            record.get("formationDate") or record.get("filingDate")
        )

        agent_name = record.get("registeredAgent") or record.get("agentName")
        agent = Person(full_name=agent_name) if agent_name else None

        address = None
        addr_str = record.get("principalAddress") or record.get("address")
        if addr_str:
            address = parse_address_text(str(addr_str))

        return Business(
            name=name.strip(),
            entity_type=entity_type,
            status=status,
            state="NM",
            filing_number=str(filing_number) if filing_number else None,
            formation_date=formation_date,
            address=address,
            registered_agent=agent,
            source_url=NM_BIZ_SEARCH_URL,
            raw_data=record,
        )

    @staticmethod
    def _parse_date(date_str: str | None) -> date_cls | None:
        """Parse a date string in common US formats."""
        if not date_str:
            return None
        date_str = date_str.strip()
        m = re.match(r"(\d{1,2})/(\d{1,2})/(\d{4})", date_str)
        if m:
            try:
                return date_cls(int(m.group(3)), int(m.group(1)), int(m.group(2)))
            except ValueError:
                pass
        try:
            return date_cls.fromisoformat(date_str)
        except (ValueError, AttributeError):
            pass
        return None
