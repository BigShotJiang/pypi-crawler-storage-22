"""
New York state collector.

Sources:
- DOS (Department of State): Real estate license lookups
  https://appext20.dos.ny.gov/nydos/searchByName.do
- DOS Corporation & Business Entity Database
  https://apps.dos.ny.gov/publicInquiry/
"""

from __future__ import annotations

import logging
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.models import (
    Business,
    CollectorResult,
    EntityStatus,
    License,
    LicenseStatus,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import clean_text, parse_html
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

DOS_SEARCH_URL = "https://appext20.dos.ny.gov/nydos/searchByName.do"
NY_BIZ_SEARCH_URL = "https://apps.dos.ny.gov/publicInquiry/"


@StateRegistry.register
class NewYorkCollector(BaseStateCollector):
    """Collector for New York government data.
    
    License search: POST form to DOS — works with HTTP.
    Business search: requires browser (JS SPA).
    """

    needs_browser_for = [DataCategory.LICENSES, DataCategory.BUSINESSES]

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="NY",
            name="New York",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "New York Department of State (DOS) — License Search",
                "New York Department of State — Corporation/Business Entity Database",
            ],
        )

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        NY DOS real estate license search.
        
        Uses HTTP POST directly to the DOS search form.
        Form requires: surname (2+ chars), firstName (2+ chars), indOrgInd=I
        """
        query = params.query or ""
        if not query:
            logger.warning("NY DOS: query is required")
            return

        count = 0
        max_results = params.max_results

        # Split query into surname/firstName
        parts = query.strip().split(None, 1)
        surname = parts[0] if parts else query
        first_name = parts[1] if len(parts) > 1 else ""

        # Ensure minimum 2 characters for each field
        if len(surname) < 2:
            surname = surname + "a"
        if first_name and len(first_name) < 2:
            first_name = first_name + "a"

        form_data = {
            "indOrgInd": "I",
            "surname": surname,
            "firstName": first_name,
        }

        try:
            response = await self.client.post(DOS_SEARCH_URL, data=form_data)
            html = response.text
        except Exception as e:
            logger.error("NY DOS license search failed: %s", e)
            return

        if "no licenses found" in html.lower() or "no records found" in html.lower():
            logger.info("NY DOS: no licenses found for query: %s", query)
            return

        tree = parse_html(html)

        # Look for results table
        rows = tree.css("table tr")
        if not rows:
            logger.debug("NY DOS: no result table found")
            return

        for row in rows:
            if count >= max_results:
                break

            cells = row.css("td")
            if len(cells) < 2:
                continue

            # Extract license data from cells
            holder_name = clean_text(cells[0].text(deep=True))
            lic_number = clean_text(cells[1].text(deep=True)) if len(cells) > 1 else None
            lic_type = clean_text(cells[2].text(deep=True)) if len(cells) > 2 else "Real Estate"
            status_text = clean_text(cells[3].text(deep=True)) if len(cells) > 3 else ""

            if not holder_name or not lic_number:
                continue

            # Skip header rows
            if "name" in (holder_name or "").lower() and ("license" in (lic_number or "").lower() or "number" in (lic_number or "").lower()):
                continue

            status = LicenseStatus.ACTIVE
            if status_text:
                st = status_text.lower()
                if "expired" in st:
                    status = LicenseStatus.EXPIRED
                elif "inactive" in st:
                    status = LicenseStatus.INACTIVE
                elif "revoked" in st:
                    status = LicenseStatus.REVOKED
                elif "suspended" in st:
                    status = LicenseStatus.SUSPENDED

            lic = License(
                license_number=lic_number,
                license_type=lic_type or "Real Estate",
                status=status,
                state="NY",
                holder_name=holder_name,
                source_url=DOS_SEARCH_URL,
                raw_data={"status_text": status_text},
            )
            yield CollectorResult(
                category="licenses",
                state="NY",
                data=lic,
                source="NY DOS",
            )
            count += 1

        logger.info("NY DOS: returned %d license results", count)

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """NY DOS business entity search — requires browser."""
        query = params.query
        if not query:
            logger.warning("NY business: query is required")
            return

        if not self.has_browser:
            logger.warning("NY business search requires browser. Use use_browser=True.")
            return

        count = 0
        max_results = params.max_results

        try:
            page = await self.browser.new_page()
        except Exception as e:
            logger.error("NY business: failed to create browser page: %s", e)
            return

        try:
            await page.goto(NY_BIZ_SEARCH_URL, wait_until="domcontentloaded", timeout=15000)
            
            # Give time for JS to load
            await page.wait_for_timeout(3000)

            # The publicInquiry page is a JS SPA - look for search inputs
            search_selectors = [
                'input[name="nameinput"]',
                'input[name="EntityName"]', 
                'input[placeholder*="name"]',
                'input[placeholder*="entity"]',
                '#EntityName',
                '#nameinput',
                'input[type="text"]',
            ]
            
            search_input = None
            for selector in search_selectors:
                search_input = await page.query_selector(selector)
                if search_input:
                    logger.debug("NY business: found search input with selector: %s", selector)
                    break

            if search_input:
                await search_input.fill(query)
                await page.keyboard.press("Enter")
                
                # Wait for results to load
                await page.wait_for_load_state("domcontentloaded", timeout=15000)
                await page.wait_for_timeout(3000)  # Extra time for AJAX
            else:
                logger.warning("NY business: could not find search input")
                return

            html = await page.content()
            tree = parse_html(html)

            # Look for results in various formats
            result_selectors = [
                "table tr",
                ".search-result", 
                ".result-row",
                "[class*='result'] tr",
                ".entity-result",
            ]

            rows = []
            for selector in result_selectors:
                found_rows = tree.css(selector)
                if found_rows and len(found_rows) > 1:
                    rows = found_rows
                    break

            if not rows:
                logger.warning("NY business: no result rows found")
                return

            for row in rows:
                if count >= max_results:
                    break
                
                cells = row.css("td")
                if len(cells) < 1:
                    continue

                name = clean_text(cells[0].text(deep=True))
                if not name:
                    continue

                filing_number = clean_text(cells[1].text(deep=True)) if len(cells) > 1 else None
                status_text = clean_text(cells[2].text(deep=True)) if len(cells) > 2 else ""

                # Skip header rows
                if "entity" in name.lower() and "name" in name.lower():
                    continue

                # Map status
                status = EntityStatus.ACTIVE
                if status_text:
                    st = status_text.lower()
                    if "inactive" in st:
                        status = EntityStatus.INACTIVE
                    elif "dissolved" in st:
                        status = EntityStatus.DISSOLVED

                biz = Business(
                    name=name,
                    state="NY",
                    filing_number=filing_number,
                    status=status,
                    source_url=NY_BIZ_SEARCH_URL,
                    raw_data={"status_text": status_text},
                )
                yield CollectorResult(
                    category="businesses",
                    state="NY",
                    data=biz,
                    source="NY DOS",
                )
                count += 1

            logger.info("NY business: returned %d results", count)

        except Exception as e:
            logger.error("NY business search failed: %s", e)
        finally:
            await page.close()