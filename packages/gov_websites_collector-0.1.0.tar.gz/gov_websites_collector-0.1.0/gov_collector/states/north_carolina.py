"""
North Carolina state collector.

Sources:
- NCREC (North Carolina Real Estate Commission): License search
  https://license.ncrec.gov/ncrec/oecgi3.exe/O4W_LIC_SEARCH_NEW (working HTTP form)
- SOSNC (Secretary of State): Business entity search
  https://sosnc.gov/online_services/search/by_title/search_Business_Registration (Cloudflare blocked)
"""

from __future__ import annotations

import logging
import re
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.models import (
    Address,
    Business,
    CollectorResult,
    EntityStatus,
    License,
    LicenseStatus,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import clean_text, parse_html
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

# --- NCREC (Real Estate) ---

NCREC_SEARCH_URL = "https://license.ncrec.gov/ncrec/oecgi3.exe/O4W_LIC_SEARCH_NEW"

# --- SOSNC (Business Entity) ---

SOSNC_SEARCH_URL = "https://sosnc.gov/online_services/search/by_title/search_Business_Registration"

LICENSE_STATUS_MAP = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
}

@StateRegistry.register
class NorthCarolinaCollector(BaseStateCollector):
    """Collector for North Carolina government data.
    
    NCREC license search: works with HTTP form submission.
    SOSNC business search: Cloudflare blocked, needs browser.
    """

    needs_browser_for = [DataCategory.LICENSES, DataCategory.BUSINESSES]

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="NC",
            name="North Carolina",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "North Carolina Real Estate Commission (NCREC)",
                "North Carolina Secretary of State (SOSNC)",
            ],
            notes="License search works with HTTP, business search needs browser (Cloudflare).",
        )

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        North Carolina NCREC real estate license search.
        
        Requires browser automation — the O4W CGI framework doesn't accept
        standard HTTP POST. Form fields: Name, LIC_NO, CITY, County, NO, SUBMITBTN.
        """
        query = params.query
        if not query:
            logger.warning("NC NCREC: query is required")
            return

        if not self.has_browser:
            logger.warning(
                "NC NCREC requires browser automation (O4W CGI). "
                "Initialize with use_camoufox=True."
            )
            return

        count = 0
        max_results = params.max_results

        try:
            page = await self.browser.new_page()
            await page.goto(NCREC_SEARCH_URL, wait_until="domcontentloaded", timeout=20000)

            import asyncio as _asyncio
            await _asyncio.sleep(3)

            # Fill in the Name field (actual field name from HTML)
            name_input = await page.query_selector('input#Name, input[name="Name"]')
            if name_input:
                await name_input.fill(query)

            # Submit the form
            submit_btn = await page.query_selector('input#SUBMITBTN, input[name="SUBMITBTN"]')
            if submit_btn:
                await submit_btn.click()
            else:
                await page.keyboard.press("Enter")

            await page.wait_for_load_state("domcontentloaded", timeout=15000)
            await _asyncio.sleep(3)

            html = await page.content()
            tree = parse_html(html)

            # Parse results - check for table rows or text blocks
            rows = tree.css("table tr")
            for row in rows:
                if count >= max_results:
                    break
                cells = row.css("td")
                if len(cells) >= 3:
                    license_number = clean_text(cells[0].text(deep=True))
                    holder_name = clean_text(cells[1].text(deep=True))
                    city = clean_text(cells[2].text(deep=True)) if len(cells) > 2 else ""
                    status_text = clean_text(cells[3].text(deep=True)) if len(cells) > 3 else "ACTIVE"
                    if license_number and holder_name and "license" not in license_number.lower():
                        status = LICENSE_STATUS_MAP.get(
                            (status_text or "").upper(), LicenseStatus.ACTIVE
                        )
                        address = Address(city=city, state="NC") if city else None
                        yield CollectorResult(
                            category="licenses",
                            state="NC",
                            data=License(
                                license_number=license_number,
                                license_type="Real Estate",
                                status=status,
                                state="NC",
                                holder_name=holder_name,
                                address=address,
                                source_url=NCREC_SEARCH_URL,
                                raw_data={"status_text": status_text, "city": city},
                            ),
                            source="North Carolina NCREC",
                        )
                        count += 1

            # Also try parsing text blocks (NCREC sometimes uses pre-formatted text)
            if count == 0:
                text_content = clean_text(tree.text(deep=True)) or ""
                license_blocks = re.split(r'\n\s*\n', text_content)
                for block in license_blocks:
                    if count >= max_results:
                        break
                    license_match = re.search(r'License No\.?\s*:?\s*(\d+)', block, re.I)
                    name_match = re.search(r'Name\s*:?\s*([^\n]+)', block, re.I)
                    if license_match and name_match:
                        yield CollectorResult(
                            category="licenses",
                            state="NC",
                            data=License(
                                license_number=license_match.group(1).strip(),
                                license_type="Real Estate",
                                status=LicenseStatus.ACTIVE,
                                state="NC",
                                holder_name=clean_text(name_match.group(1)) or "",
                                source_url=NCREC_SEARCH_URL,
                            ),
                            source="North Carolina NCREC",
                        )
                        count += 1

            logger.info("NC NCREC: returned %d license results", count)

        except Exception as e:
            logger.error("NC NCREC license search failed: %s", e)
        finally:
            if 'page' in dir():
                await page.close()

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        North Carolina SOSNC business entity search via browser automation.
        
        The SOSNC system is Cloudflare protected.
        """
        query = params.query
        if not query:
            logger.warning("NC SOSNC: query is required")
            return

        if not self.has_browser:
            logger.warning(
                "NC SOSNC requires browser automation. Initialize with use_browser=True."
            )
            return

        try:
            page = await self.browser.new_page()
        except Exception as e:
            logger.error("NC SOSNC: failed to create browser page: %s", e)
            return

        count = 0
        max_results = params.max_results

        try:
            await page.goto(
                SOSNC_SEARCH_URL,
                wait_until="domcontentloaded",
                timeout=20000,
            )

            # Wait for Cloudflare check
            await page.wait_for_timeout(8000)

            # Look for business search form
            search_input = await page.query_selector(
                'input[name*="name"], input[placeholder*="name"], input[type="text"]'
            )
            
            if search_input:
                await search_input.fill(query)
            else:
                logger.warning("NC SOSNC: could not find search input field")
                return

            # Submit search
            submit_btn = await page.query_selector(
                'button[type="submit"], input[type="submit"], button:has-text("Search")'
            )
            
            if submit_btn:
                await submit_btn.click()
            else:
                await page.keyboard.press("Enter")

            await page.wait_for_load_state("domcontentloaded", timeout=15000)
            await page.wait_for_timeout(5000)

            html = await page.content()
            tree = parse_html(html)

            # Parse business results
            rows = tree.css("table tr, .result, .business-record")
            for row in rows:
                if count >= max_results:
                    break
                    
                cells = row.css("td")
                if len(cells) >= 2:
                    name = clean_text(cells[0].text(deep=True))
                    sosid = clean_text(cells[1].text(deep=True))
                    status_text = clean_text(cells[2].text(deep=True)) if len(cells) > 2 else "ACTIVE"
                    entity_type = clean_text(cells[3].text(deep=True)) if len(cells) > 3 else ""
                    
                    if name and "entity name" not in name.lower():
                        status = EntityStatus.ACTIVE
                        if status_text:
                            st = status_text.lower()
                            if "inactive" in st:
                                status = EntityStatus.INACTIVE
                            elif "dissolved" in st:
                                status = EntityStatus.DISSOLVED

                        biz = Business(
                            name=name,
                            state="NC",
                            filing_number=sosid,
                            status=status,
                            entity_type=entity_type,
                            source_url=SOSNC_SEARCH_URL,
                            raw_data={
                                "status_text": status_text,
                                "entity_type": entity_type,
                            },
                        )

                        yield CollectorResult(
                            category="businesses",
                            state="NC",
                            data=biz,
                            source="North Carolina SOSNC",
                        )
                        count += 1

            logger.info("NC SOSNC: returned %d business results", count)

        except Exception as e:
            logger.error("NC SOSNC business search failed: %s", e)
        finally:
            await page.close()