"""
North Dakota state collector.

Sources:
- NDREC (North Dakota Real Estate Commission): WEBSITE DOES NOT EXIST
  https://www.ndrealestateboard.com/ - DNS error (ENOTFOUND)
- First Stop (Secretary of State): JAVASCRIPT SPA
  https://firststop.sos.nd.gov/search/business - loads but minimal content
  API endpoint may still work: https://firststop.sos.nd.gov/api/Records/businesssearch

SCAN RESULTS: NDREC ERROR, FirstStop OK but API 405
"""

from __future__ import annotations

import logging
import re
from datetime import date as date_cls
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.models import (
    Address,
    Business,
    CollectorResult,
    EntityStatus,
    EntityType,
    License,
    LicenseStatus,
    Person,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import (
    clean_text,
    extract_table_rows,
    extract_text,
    parse_address_text,
    parse_html,
)
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

# --- NDREC (Real Estate) ---

NDREC_SEARCH_URL = "https://www.ndrealestateboard.com/licensee-search/"

NDREC_STATUS_MAP = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "CURRENT": LicenseStatus.ACTIVE,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
    "SUSPENDED": LicenseStatus.SUSPENDED,
    "REVOKED": LicenseStatus.REVOKED,
    "CANCELLED": LicenseStatus.CANCELLED,
}

# --- First Stop (Business Entity) ---

FIRSTSTOP_SEARCH_URL = "https://firststop.sos.nd.gov/search/business"
FIRSTSTOP_API_URL = "https://firststop.sos.nd.gov/api/Records/businesssearch"

ND_ENTITY_TYPE_MAP = {
    "LIMITED LIABILITY COMPANY": EntityType.LLC,
    "DOMESTIC LIMITED LIABILITY COMPANY": EntityType.LLC,
    "FOREIGN LIMITED LIABILITY COMPANY": EntityType.LLC,
    "CORPORATION": EntityType.CORPORATION,
    "DOMESTIC CORPORATION": EntityType.CORPORATION,
    "FOREIGN CORPORATION": EntityType.CORPORATION,
    "DOMESTIC BUSINESS CORPORATION": EntityType.CORPORATION,
    "NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "DOMESTIC NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "LIMITED PARTNERSHIP": EntityType.LP,
    "LIMITED LIABILITY PARTNERSHIP": EntityType.LLP,
}

ND_STATUS_MAP = {
    "ACTIVE": EntityStatus.ACTIVE,
    "ACTIVE/IN GOOD STANDING": EntityStatus.ACTIVE,
    "IN GOOD STANDING": EntityStatus.ACTIVE,
    "INACTIVE": EntityStatus.INACTIVE,
    "DISSOLVED": EntityStatus.DISSOLVED,
    "REVOKED": EntityStatus.DISSOLVED,
    "WITHDRAWN": EntityStatus.WITHDRAWN,
    "EXPIRED": EntityStatus.INACTIVE,
}


@StateRegistry.register
class NorthDakotaCollector(BaseStateCollector):
    """Collector for North Dakota government data."""
    
    needs_browser_for = [DataCategory.BUSINESSES]

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="ND",
            name="North Dakota",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "North Dakota Real Estate Commission (NDREC)",
                "North Dakota Secretary of State (First Stop)",
            ],
        )

    # --- Real Estate Licenses ---

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        North Dakota Real Estate Commission website does not exist.
        
        The domain www.ndrealestateboard.com returns DNS error (ENOTFOUND).
        The real estate licensing authority for ND may have moved to a 
        different website or may be handled by a different agency.
        """
        logger.error(
            "ND NDREC: Website www.ndrealestateboard.com does not exist (DNS error). "
            "Real estate licensing authority may have moved."
        )
        return
        yield  # Make it a generator

    async def _ndrec_search(
        self,
        name: str | None = None,
        license_number: str | None = None,
        max_results: int = 100,
    ) -> AsyncIterator[CollectorResult]:
        """Search NDREC by name or license number."""
        form_data: dict[str, str] = {}

        if license_number:
            form_data["LicenseNumber"] = license_number
        elif name:
            parts = name.strip().split(maxsplit=1)
            form_data["LastName"] = parts[0] if parts else name
            form_data["FirstName"] = parts[1] if len(parts) > 1 else ""

        try:
            response = await self.client.post(NDREC_SEARCH_URL, data=form_data)
            html = response.text
        except Exception as e:
            logger.error("NDREC search failed: %s", e)
            return

        tree = parse_html(html)
        rows = tree.css("table tr")
        if not rows:
            logger.debug("No NDREC results found")
            return

        count = 0
        for row in rows:
            cells = row.css("td")
            if len(cells) < 3:
                continue

            name_text = extract_text(cells[0])
            license_id = extract_text(cells[1])
            license_type = extract_text(cells[2])
            status_text = extract_text(cells[3]) if len(cells) > 3 else None
            city_text = extract_text(cells[4]) if len(cells) > 4 else None

            if not name_text or not license_id:
                continue

            status = LicenseStatus.OTHER
            if status_text:
                status = NDREC_STATUS_MAP.get(
                    status_text.upper().strip(), LicenseStatus.OTHER
                )

            address = None
            if city_text:
                address = Address(city=city_text.strip(), state="ND")

            license_obj = License(
                license_number=license_id.strip(),
                license_type=license_type.strip() if license_type else "Real Estate",
                status=status,
                state="ND",
                holder_name=name_text.strip(),
                address=address,
                source_url=NDREC_SEARCH_URL,
                raw_data={
                    "name": name_text,
                    "license_type": license_type,
                    "status_text": status_text,
                    "city": city_text,
                },
            )

            yield CollectorResult(
                category=DataCategory.LICENSES.value,
                state="ND",
                data=license_obj,
                source="North Dakota Real Estate Commission",
            )

            count += 1
            if count >= max_results:
                return

    # --- Business Entity Search ---

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search ND Secretary of State (First Stop) for business entities.

        Uses the JSON API endpoint directly — no browser needed.
        POST https://firststop.sos.nd.gov/api/Records/businesssearch
        Returns JSON with 'rows' dict keyed by record ID.
        """
        if not params.query:
            logger.warning("ND First Stop: query (business name) is required")
            return

        count = 0
        max_results = params.max_results

        try:
            response = await self.client.post(
                FIRSTSTOP_API_URL,
                json={
                    "SEARCH_VALUE": params.query,
                    "STARTS_WITH_YN": "false",
                    "ACTIVE_ONLY_YN": "false",
                },
                headers={"Content-Type": "application/json"},
            )
            data = response.json()
        except Exception as e:
            logger.error("ND First Stop API failed: %s", e)
            return

        rows = data.get("rows", {})
        if not rows:
            logger.debug("ND First Stop: No business results found")
            return

        for record_id, record in rows.items():
            if count >= max_results:
                break

            business = self._parse_nd_business(record)
            if business:
                yield CollectorResult(
                    category=DataCategory.BUSINESSES.value,
                    state="ND",
                    data=business,
                    source="North Dakota Secretary of State (First Stop)",
                )
                count += 1

        logger.info("ND First Stop: returned %d business results", count)

    def _parse_nd_business(self, record: dict) -> Business | None:
        """Parse a single ND First Stop business record.
        
        API response format per row:
        {
            "SORT_INDEX": 0,
            "TITLE": ["Business Name", "Entity Type Description"],
            "ID": 270964,
            "FILING_DATE": "03/24/2018",
            "RECORD_NUM": "0000271344",
            "STATUS": "Inactive - Expired",
            "STANDING": "Good Standing",
            ...
        }
        """
        # TITLE is a list: [name, entity_type_description]
        title = record.get("TITLE", [])
        if isinstance(title, list) and len(title) >= 1:
            name = title[0]
            type_desc = title[1] if len(title) > 1 else ""
        elif isinstance(title, str):
            name = title
            type_desc = ""
        else:
            name = record.get("BUSINESS_NAME") or record.get("EntityName")
            type_desc = ""
        
        if not name:
            return None

        # Parse entity type from description
        type_upper = type_desc.upper().strip() if type_desc else ""
        entity_type = EntityType.OTHER
        for key, val in ND_ENTITY_TYPE_MAP.items():
            if key in type_upper:
                entity_type = val
                break

        # Parse status
        status_str = (record.get("STATUS") or "").upper().strip()
        status = EntityStatus.OTHER
        for key, val in ND_STATUS_MAP.items():
            if key in status_str:
                status = val
                break

        filing_number = record.get("RECORD_NUM") or str(record.get("ID", ""))

        formation_date = None
        date_str = record.get("FILING_DATE", "")
        if date_str:
            try:
                from datetime import datetime as dt
                formation_date = dt.strptime(date_str.strip(), "%m/%d/%Y").date()
            except (ValueError, AttributeError):
                pass

        agent_name = record.get("REGISTERED_AGENT") or record.get("AGENT")
        agent = Person(full_name=agent_name) if agent_name else None

        return Business(
            name=name.strip(),
            entity_type=entity_type,
            status=status,
            state="ND",
            filing_number=filing_number,
            formation_date=formation_date,
            registered_agent=agent,
            source_url=FIRSTSTOP_SEARCH_URL,
            raw_data=record,
        )
