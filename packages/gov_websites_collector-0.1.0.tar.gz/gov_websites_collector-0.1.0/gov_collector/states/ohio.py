"""
Ohio state collector.

Sources:
- ODRE / eLicense Ohio: Real estate license lookups (ASP.NET WebForms)
  https://elicense3.com.ohio.gov/lookup/licenselookup.aspx
  Note: ASP.NET ViewState must be maintained across requests.
- Ohio SOS: Business entity search
  https://businesssearch.ohiosos.gov/
"""

from __future__ import annotations

import logging
import re
from datetime import date as date_cls
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.models import (
    Address,
    Business,
    CollectorResult,
    EntityStatus,
    EntityType,
    License,
    LicenseStatus,
    Person,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import (
    clean_text,
    extract_table_rows,
    extract_text,
    parse_address_text,
    parse_html,
)
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

# --- eLicense Ohio (Real Estate) ---

ELICENSE_URL = "https://elicense.ohio.gov/OH_VerifyLicense"
ELICENSE_OLD_URL = "https://elicense3.com.ohio.gov/lookup/licenselookup.aspx"  # Retired 10/16/25

ELICENSE_STATUS_MAP = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "CURRENT": LicenseStatus.ACTIVE,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
    "SUSPENDED": LicenseStatus.SUSPENDED,
    "REVOKED": LicenseStatus.REVOKED,
    "CANCELLED": LicenseStatus.CANCELLED,
    "PENDING": LicenseStatus.PENDING,
}

# Real estate board/profession identifiers for eLicense
ELICENSE_BOARD_CODE = "RES"  # Real Estate & Professional Licensing

# --- Ohio SOS (Business Entity) ---

OH_BIZ_SEARCH_URL = "https://businesssearch.ohiosos.gov/"
OH_BIZ_API_URL = "https://businesssearch.ohiosos.gov/api/BusinessSearch"

OH_ENTITY_TYPE_MAP = {
    "DOMESTIC LIMITED LIABILITY COMPANY": EntityType.LLC,
    "FOREIGN LIMITED LIABILITY COMPANY": EntityType.LLC,
    "DOMESTIC FOR-PROFIT CORPORATION": EntityType.CORPORATION,
    "FOREIGN FOR-PROFIT CORPORATION": EntityType.CORPORATION,
    "DOMESTIC CORPORATION": EntityType.CORPORATION,
    "FOREIGN CORPORATION": EntityType.CORPORATION,
    "DOMESTIC NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "FOREIGN NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "DOMESTIC LIMITED PARTNERSHIP": EntityType.LP,
    "FOREIGN LIMITED PARTNERSHIP": EntityType.LP,
    "DOMESTIC LIMITED LIABILITY PARTNERSHIP": EntityType.LLP,
    "FOREIGN LIMITED LIABILITY PARTNERSHIP": EntityType.LLP,
    "GENERAL PARTNERSHIP": EntityType.PARTNERSHIP,
    "PROFESSIONAL ASSOCIATION": EntityType.OTHER,
}

OH_STATUS_MAP = {
    "ACTIVE": EntityStatus.ACTIVE,
    "IN GOOD STANDING": EntityStatus.ACTIVE,
    "ALIVE": EntityStatus.ACTIVE,
    "CANCELLED": EntityStatus.DISSOLVED,
    "DISSOLVED": EntityStatus.DISSOLVED,
    "DEAD": EntityStatus.DISSOLVED,
    "SUSPENDED": EntityStatus.SUSPENDED,
    "WITHDRAWN": EntityStatus.WITHDRAWN,
    "INACTIVE": EntityStatus.INACTIVE,
}


@StateRegistry.register
class OhioCollector(BaseStateCollector):
    """Collector for Ohio government data."""

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="OH",
            name="Ohio",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "Ohio eLicense (Division of Real Estate & Professional Licensing)",
                "Ohio Secretary of State — Business Search",
            ],
            notes="eLicense uses ASP.NET WebForms requiring ViewState token management.",
        )

    # --- Real Estate Licenses (eLicense Ohio) ---

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search Ohio eLicense for real estate licenses.

        ASP.NET WebForms pattern: first GET to retrieve ViewState,
        then POST with form data + ViewState token.
        """
        if not params.query and not params.license_number:
            raise ValueError(
                "Either 'query' (name) or 'license_number' is required for OH license search"
            )

        # Step 1: GET the page to obtain ViewState and other ASP.NET hidden fields
        try:
            init_response = await self.client.get(ELICENSE_URL)
            init_html = init_response.text
        except Exception as e:
            logger.error("OH eLicense initial page load failed: %s", e)
            return

        viewstate = self._extract_aspnet_field(init_html, "__VIEWSTATE")
        viewstate_gen = self._extract_aspnet_field(init_html, "__VIEWSTATEGENERATOR")
        event_validation = self._extract_aspnet_field(init_html, "__EVENTVALIDATION")

        if not viewstate:
            logger.error("Failed to extract ASP.NET ViewState from OH eLicense")
            return

        # Step 2: POST the search form
        form_data = {
            "__VIEWSTATE": viewstate,
            "__VIEWSTATEGENERATOR": viewstate_gen or "",
            "__EVENTVALIDATION": event_validation or "",
            "ctl00$MainContentPlaceHolder$ucLicenseLookup$ddlBoard": ELICENSE_BOARD_CODE,
            "ctl00$MainContentPlaceHolder$ucLicenseLookup$btnLookup": "Search",
        }

        if params.license_number:
            form_data[
                "ctl00$MainContentPlaceHolder$ucLicenseLookup$txtLicenseNumber"
            ] = params.license_number
        elif params.query:
            parts = params.query.strip().split(maxsplit=1)
            form_data[
                "ctl00$MainContentPlaceHolder$ucLicenseLookup$txtLastName"
            ] = parts[0]
            if len(parts) > 1:
                form_data[
                    "ctl00$MainContentPlaceHolder$ucLicenseLookup$txtFirstName"
                ] = parts[1]

        try:
            response = await self.client.post(ELICENSE_URL, data=form_data)
            html = response.text
        except Exception as e:
            logger.error("OH eLicense search POST failed: %s", e)
            return

        count = 0
        async for result in self._parse_elicense_results(html):
            yield result
            count += 1
            if count >= params.max_results:
                return

    def _extract_aspnet_field(self, html: str, field_name: str) -> str | None:
        """Extract an ASP.NET hidden form field value."""
        pattern = rf'id="{re.escape(field_name)}"[^>]*value="([^"]*)"'
        match = re.search(pattern, html)
        if match:
            return match.group(1)

        # Try alternate pattern
        pattern2 = rf'name="{re.escape(field_name)}"[^>]*value="([^"]*)"'
        match2 = re.search(pattern2, html)
        return match2.group(1) if match2 else None

    async def _parse_elicense_results(
        self, html: str
    ) -> AsyncIterator[CollectorResult]:
        """Parse eLicense Ohio search results."""
        tree = parse_html(html)

        # eLicense typically uses a GridView control rendered as a table
        results_table = tree.css_first(
            "table[id*='GridView'], table[id*='grdSearchResults'], table.results"
        )
        if not results_table:
            logger.debug("No OH eLicense results table found")
            return

        rows = results_table.css("tr")
        if len(rows) < 2:
            return

        # First row is headers
        header_cells = rows[0].css("th, td")
        headers = [
            clean_text(cell.text(deep=True)) or f"col_{i}"
            for i, cell in enumerate(header_cells)
        ]

        for row in rows[1:]:
            cells = row.css("td")
            if not cells:
                continue

            row_data = {}
            for i, cell in enumerate(cells):
                key = headers[i] if i < len(headers) else f"col_{i}"
                row_data[key] = clean_text(cell.text(deep=True)) or ""

            name_text = (
                row_data.get("Name")
                or row_data.get("Licensee Name")
                or row_data.get("col_0")
            )
            license_id = (
                row_data.get("License Number")
                or row_data.get("License #")
                or row_data.get("col_1")
            )

            if not name_text or not license_id:
                continue

            license_type = (
                row_data.get("License Type")
                or row_data.get("Type")
                or "Real Estate"
            )

            status_text = (
                row_data.get("Status") or row_data.get("License Status") or ""
            )
            status = ELICENSE_STATUS_MAP.get(
                status_text.upper().strip(), LicenseStatus.OTHER
            )

            # Parse expiration date
            exp_date = None
            exp_str = row_data.get("Expiration Date") or row_data.get("Exp Date")
            if exp_str:
                for fmt in ("%m/%d/%Y", "%Y-%m-%d"):
                    try:
                        exp_date = date_cls.strptime(exp_str.strip(), fmt).date() if hasattr(date_cls, "strptime") else None
                    except (ValueError, AttributeError):
                        continue

            address_text = row_data.get("City") or row_data.get("Address")
            address = None
            if address_text:
                address = Address(raw=address_text, state="OH")

            license_obj = License(
                license_number=license_id.strip(),
                license_type=license_type.strip(),
                status=status,
                state="OH",
                holder_name=name_text.strip(),
                address=address,
                expiration_date=exp_date,
                source_url=ELICENSE_URL,
                raw_data=row_data,
            )

            yield CollectorResult(
                category=DataCategory.LICENSES.value,
                state="OH",
                data=license_obj,
                source="Ohio eLicense",
            )

    # --- Business Entity Search ---

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search Ohio Secretary of State for business entities.

        Uses the businesssearch.ohiosos.gov API endpoint.
        """
        if not params.query:
            raise ValueError(
                "'query' (business name) is required for OH business search"
            )

        search_payload = {
            "BusinessName": params.query,
            "NameType": "contains",
            "State": "",
            "Status": "",
        }

        try:
            response = await self.client.post(
                OH_BIZ_API_URL,
                json=search_payload,
                headers={"Content-Type": "application/json"},
            )
            data = response.json()
        except Exception as e:
            logger.error("OH SOS business search failed: %s", e)
            return

        results = data if isinstance(data, list) else data.get("businesses", [])
        count = 0

        for record in results:
            if count >= params.max_results:
                return

            business = self._parse_oh_business(record)
            if business:
                yield CollectorResult(
                    category=DataCategory.BUSINESSES.value,
                    state="OH",
                    data=business,
                    source="Ohio Secretary of State",
                )
                count += 1

    def _parse_oh_business(self, record: dict) -> Business | None:
        """Parse a single Ohio SOS business record."""
        name = (
            record.get("businessName")
            or record.get("BUSINESS_NAME")
            or record.get("EntityName")
        )
        if not name:
            return None

        type_str = (
            record.get("entityType") or record.get("ENTITY_TYPE") or ""
        ).upper()
        entity_type = OH_ENTITY_TYPE_MAP.get(type_str, EntityType.OTHER)

        status_str = (
            record.get("status") or record.get("STATUS") or ""
        ).upper()
        status = OH_STATUS_MAP.get(status_str, EntityStatus.OTHER)

        filing_number = (
            record.get("entityNumber")
            or record.get("charterNumber")
            or record.get("FILING_NUMBER")
        )

        formation_date = None
        date_str = (
            record.get("filingDate")
            or record.get("originalFilingDate")
            or record.get("FILING_DATE")
        )
        if date_str:
            for fmt in ("%m/%d/%Y", "%Y-%m-%d", "%Y-%m-%dT%H:%M:%S"):
                try:
                    formation_date = date_cls.strptime(
                        date_str.strip()[:10], fmt
                    ).date()
                except (ValueError, AttributeError):
                    continue

        address = None
        addr_parts = []
        for key in ("address1", "address2", "city", "state", "zipCode"):
            val = record.get(key)
            if val:
                addr_parts.append(val)
        if addr_parts:
            address = parse_address_text(", ".join(addr_parts))

        agent_name = record.get("agentName") or record.get("REGISTERED_AGENT")
        agent = Person(full_name=agent_name) if agent_name else None

        return Business(
            name=name.strip(),
            entity_type=entity_type,
            status=status,
            state="OH",
            filing_number=str(filing_number) if filing_number else None,
            formation_date=formation_date,
            address=address,
            registered_agent=agent,
            source_url=OH_BIZ_SEARCH_URL,
            raw_data=record,
        )
