"""
Oklahoma state collector.

Sources:
- OREC (Oklahoma Real Estate Commission): License search
  https://www.ok.gov/orec/License_Search/index.html
  WARNING: Returns 404 Not Found — site may have moved or shut down.
- Oklahoma SOS: Business entity search
  https://www.sos.ok.gov/corp/corpinquiryfind.aspx
  ASP.NET WebForms with Cloudflare Turnstile CAPTCHA and AJAX UpdatePanel.

  Form structure (from current HTML):
  - Entity name: name="ctl00$DefaultContent$CorpNameSearch1$_singlename"
                  id="ctl00_DefaultContent_CorpNameSearch1__singlename"
  - Search button: name="ctl00$DefaultContent$CorpNameSearch1$SearchButton"
                    id="ctl00_DefaultContent_CorpNameSearch1_SearchButton"
  - Results in UpdatePanel: id="ctl00_DefaultContent_CorpNameSearch1_ResultsUpdatePanel"
  - GridView: id="ctl00_DefaultContent_CorpNameSearch1_EntityGridView"
  - Turnstile sitekey: 0x4AAAAAAAVxO2nq6EgdlYh-
"""

from __future__ import annotations

import asyncio
import logging
import re
from datetime import date as date_cls
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.models import (
    Address,
    Business,
    CollectorResult,
    EntityStatus,
    EntityType,
    License,
    LicenseStatus,
    Person,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import (
    clean_text,
    extract_table_rows,
    extract_text,
    parse_address_text,
    parse_html,
)
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

# --- OREC (Real Estate) ---
# WARNING: Returns 404 as of Feb 2026 — site appears offline.
OREC_SEARCH_URL = "https://www.ok.gov/orec/License_Search/index.html"

OREC_STATUS_MAP = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "CURRENT": LicenseStatus.ACTIVE,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
    "SUSPENDED": LicenseStatus.SUSPENDED,
    "REVOKED": LicenseStatus.REVOKED,
    "CANCELLED": LicenseStatus.CANCELLED,
}

# --- Oklahoma SOS (Business Entity) ---

OK_SOS_SEARCH_URL = "https://www.sos.ok.gov/corp/corpinquiryfind.aspx"

OK_ENTITY_TYPE_MAP = {
    "DOMESTIC LIMITED LIABILITY COMPANY": EntityType.LLC,
    "FOREIGN LIMITED LIABILITY COMPANY": EntityType.LLC,
    "DOMESTIC FOR PROFIT BUSINESS CORPORATION": EntityType.CORPORATION,
    "DOMESTIC BUSINESS CORPORATION": EntityType.CORPORATION,
    "FOREIGN FOR PROFIT BUSINESS CORPORATION": EntityType.CORPORATION,
    "FOREIGN BUSINESS CORPORATION": EntityType.CORPORATION,
    "DOMESTIC NOT FOR PROFIT CORPORATION": EntityType.NONPROFIT,
    "FOREIGN NOT FOR PROFIT CORPORATION": EntityType.NONPROFIT,
    "DOMESTIC LIMITED PARTNERSHIP": EntityType.LP,
    "FOREIGN LIMITED PARTNERSHIP": EntityType.LP,
    "LIMITED LIABILITY PARTNERSHIP": EntityType.LLP,
    "GENERAL PARTNERSHIP": EntityType.PARTNERSHIP,
}

OK_STATUS_MAP = {
    "ACTIVE": EntityStatus.ACTIVE,
    "IN EXISTENCE": EntityStatus.ACTIVE,
    "INACTIVE": EntityStatus.INACTIVE,
    "DISSOLVED": EntityStatus.DISSOLVED,
    "CANCELLED": EntityStatus.DISSOLVED,
    "EXPIRED": EntityStatus.INACTIVE,
    "SUSPENDED": EntityStatus.SUSPENDED,
    "WITHDRAWN": EntityStatus.WITHDRAWN,
    "REVOKED": EntityStatus.DISSOLVED,
}


@StateRegistry.register
class OklahomaCollector(BaseStateCollector):
    """Collector for Oklahoma government data."""

    needs_browser_for = [DataCategory.BUSINESSES]

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="OK",
            name="Oklahoma",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "Oklahoma Real Estate Commission (OREC) - WARNING: Returns 404",
                "Oklahoma Secretary of State Corp Search",
            ],
            notes="OREC returns 404. SOS uses Cloudflare Turnstile + ASP.NET UpdatePanel.",
        )

    # --- Real Estate Licenses ---

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search OREC for real estate licenses.
        WARNING: OREC site returns 404 as of Feb 2026.
        """
        if params.license_number:
            async for result in self._orec_search(
                license_number=params.license_number, max_results=1
            ):
                yield result
            return

        if not params.query:
            raise ValueError(
                "Either 'query' (name) or 'license_number' is required for OK RE search"
            )

        async for result in self._orec_search(
            name=params.query, max_results=params.max_results
        ):
            yield result

    async def _orec_search(
        self,
        name: str | None = None,
        license_number: str | None = None,
        max_results: int = 100,
    ) -> AsyncIterator[CollectorResult]:
        """Search OREC by name or license number."""
        logger.warning(
            "Oklahoma OREC site returns 404 as of Feb 2026. Unable to search licenses."
        )
        return
        yield  # type: ignore[misc]  # Make this an async generator

    # --- Business Entity Search ---

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search Oklahoma SOS for business entities.

        Uses Camoufox browser to handle the Cloudflare Turnstile CAPTCHA
        and interact with the ASP.NET WebForms page.

        Form elements (from current HTML):
        - Entity Name input: #ctl00_DefaultContent_CorpNameSearch1__singlename
        - Search button: #ctl00_DefaultContent_CorpNameSearch1_SearchButton
        - Results UpdatePanel: #ctl00_DefaultContent_CorpNameSearch1_ResultsUpdatePanel
        - Results GridView: #ctl00_DefaultContent_CorpNameSearch1_EntityGridView
        """
        if not params.query:
            raise ValueError(
                "'query' (business name) is required for OK business search"
            )

        if not self.has_browser:
            # Fallback to HTTP (likely won't work due to Turnstile)
            logger.warning(
                "OK SOS requires Camoufox browser for Turnstile CAPTCHA. "
                "Attempting HTTP fallback (may fail)."
            )
            async for result in self._ok_biz_http_fallback(params):
                yield result
            return

        try:
            page = await self.browser.new_page()
        except Exception as e:
            logger.error("OK SOS: failed to create browser page: %s", e)
            return

        count = 0
        max_results = params.max_results

        try:
            await page.goto(
                OK_SOS_SEARCH_URL,
                wait_until="domcontentloaded",
                timeout=30000,
            )

            # Wait for Turnstile to load and auto-solve with Camoufox
            await asyncio.sleep(5)

            # Wait for the entity name input to be ready
            name_selector = (
                '#ctl00_DefaultContent_CorpNameSearch1__singlename, '
                'input[name*="_singlename"], '
                'input[name*="CorpNameSearch1$_singlename"]'
            )
            try:
                await page.wait_for_selector(name_selector, timeout=20000)
            except Exception:
                logger.warning("OK SOS: form not ready, waiting more for Turnstile...")
                await asyncio.sleep(10)
                await page.wait_for_selector(name_selector, timeout=15000)

            # Fill the entity name field
            name_input = await page.query_selector(name_selector)
            if name_input:
                await name_input.fill(params.query)
                await asyncio.sleep(0.5)
            else:
                logger.error("OK SOS: could not find entity name input")
                return

            # Click the search button
            search_selector = (
                '#ctl00_DefaultContent_CorpNameSearch1_SearchButton, '
                'input[name*="CorpNameSearch1$SearchButton"], '
                'input[name*="SearchButton"][type="submit"]'
            )
            submit_btn = await page.query_selector(search_selector)
            if submit_btn:
                await submit_btn.click()
            else:
                await page.keyboard.press("Enter")

            # Wait for the AJAX UpdatePanel to return results
            # The GridView will appear inside the ResultsUpdatePanel
            try:
                await page.wait_for_selector(
                    '#ctl00_DefaultContent_CorpNameSearch1_EntityGridView, '
                    'table[id*="EntityGridView"], '
                    '#ctl00_DefaultContent_CorpNameSearch1_ResultsUpdatePanel table, '
                    'table.grid, table[class*="grid"]',
                    timeout=20000,
                )
            except Exception:
                # Maybe results loaded but with different structure
                logger.debug("OK SOS: GridView not found, checking page content...")
                await asyncio.sleep(3)

            html = await page.content()

            # Parse results from the GridView table
            # Try the specific GridView first
            tree = parse_html(html)
            grid_table = tree.css_first(
                '#ctl00_DefaultContent_CorpNameSearch1_EntityGridView, '
                'table[id*="EntityGridView"], '
                '#ctl00_DefaultContent_CorpNameSearch1_ResultsUpdatePanel table'
            )

            if grid_table:
                rows_els = grid_table.css("tr")
                # First row is usually headers
                headers = []
                data_start = 0
                for i, row in enumerate(rows_els):
                    ths = row.css("th")
                    if ths:
                        headers = [
                            clean_text(th.text(deep=True)) or f"col_{j}"
                            for j, th in enumerate(ths)
                        ]
                        data_start = i + 1
                        break

                if not headers and rows_els:
                    # No th elements; first row might be header using td
                    first_cells = rows_els[0].css("td")
                    if first_cells:
                        headers = [
                            clean_text(c.text(deep=True)) or f"col_{j}"
                            for j, c in enumerate(first_cells)
                        ]
                        data_start = 1

                for row_el in rows_els[data_start:]:
                    if count >= max_results:
                        break
                    cells = row_el.css("td")
                    if len(cells) < 2:
                        continue

                    row_data = {}
                    for i, cell in enumerate(cells):
                        key = headers[i] if i < len(headers) else f"col_{i}"
                        # Check for links (filing number is usually a hyperlink)
                        link = cell.css_first("a")
                        if link:
                            row_data[key] = clean_text(link.text(deep=True)) or ""
                            href = link.attributes.get("href", "")
                            if href:
                                row_data[f"{key}_href"] = href
                        else:
                            row_data[key] = clean_text(cell.text(deep=True)) or ""

                    business = self._parse_ok_business_row(row_data)
                    if business:
                        yield CollectorResult(
                            category=DataCategory.BUSINESSES.value,
                            state="OK",
                            data=business,
                            source="Oklahoma Secretary of State",
                        )
                        count += 1
            else:
                # Fallback: use extract_table_rows on the full page
                rows = extract_table_rows(html)
                for row in rows:
                    if count >= max_results:
                        break
                    business = self._parse_ok_business_row(row)
                    if business:
                        yield CollectorResult(
                            category=DataCategory.BUSINESSES.value,
                            state="OK",
                            data=business,
                            source="Oklahoma Secretary of State",
                        )
                        count += 1

            logger.info("OK SOS: returned %d business results", count)

        except Exception as e:
            logger.error("OK SOS browser search failed: %s", e)
        finally:
            await page.close()

    async def _ok_biz_http_fallback(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """HTTP fallback for OK SOS (likely fails due to Turnstile)."""
        from gov_collector.aspnet_helper import extract_all_hidden_fields

        try:
            init_resp = await self.client.get(OK_SOS_SEARCH_URL)
            init_html = init_resp.text
            hidden = extract_all_hidden_fields(init_html)
            form_data = {**hidden}
            form_data["ctl00$DefaultContent$CorpNameSearch1$_singlename"] = params.query
            form_data["ctl00$DefaultContent$CorpNameSearch1$SearchButton"] = "Search"
            response = await self.client.post(OK_SOS_SEARCH_URL, data=form_data)
            html = response.text
        except Exception as e:
            logger.error("OK SOS HTTP fallback failed: %s", e)
            return

        count = 0
        rows = extract_table_rows(html)
        for row in rows:
            if count >= params.max_results:
                break
            business = self._parse_ok_business_row(row)
            if business:
                yield CollectorResult(
                    category=DataCategory.BUSINESSES.value,
                    state="OK",
                    data=business,
                    source="Oklahoma Secretary of State",
                )
                count += 1

        logger.info("OK SOS (HTTP): returned %d business results", count)

    def _parse_ok_business_row(self, row: dict[str, str]) -> Business | None:
        """Parse a single OK SOS business row."""
        name = (
            row.get("Entity Name")
            or row.get("Name")
            or row.get("Filing Name")
            or row.get("col_0")
        )
        if not name:
            return None

        # Skip header-like rows
        if name.upper() in ("ENTITY NAME", "NAME", "FILING NAME"):
            return None

        type_str = (
            row.get("Entity Type")
            or row.get("Type")
            or row.get("col_1", "")
        ).upper().strip()
        entity_type = OK_ENTITY_TYPE_MAP.get(type_str, EntityType.OTHER)

        status_str = (
            row.get("Status") or row.get("col_2", "")
        ).upper().strip()
        status = OK_STATUS_MAP.get(status_str, EntityStatus.OTHER)

        filing_number = (
            row.get("Filing Number")
            or row.get("File Number")
            or row.get("Filing No")
            or row.get("col_3")
        )

        formation_date = None
        date_str = row.get("Filing Date") or row.get("Date Filed")
        if date_str:
            for fmt in ("%m/%d/%Y", "%Y-%m-%d"):
                try:
                    formation_date = date_cls.strptime(date_str.strip(), fmt).date()
                except (ValueError, AttributeError):
                    continue

        address = None
        addr_str = row.get("Principal Address") or row.get("Address")
        if addr_str:
            address = parse_address_text(addr_str)

        agent_name = row.get("Registered Agent")
        agent = Person(full_name=agent_name) if agent_name else None

        return Business(
            name=name.strip(),
            entity_type=entity_type,
            status=status,
            state="OK",
            filing_number=filing_number,
            formation_date=formation_date,
            address=address,
            registered_agent=agent,
            source_url=OK_SOS_SEARCH_URL,
            raw_data=row,
        )
