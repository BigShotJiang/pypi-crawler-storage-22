"""
Oregon state collector.

Sources:
- Oregon Secretary of State: Business entity search
  https://sos.oregon.gov/business/pages/find.aspx
  Quick search widget redirects to egov.sos.state.or.us for results.
- Oregon Real Estate Agency: License lookup
  NOTE: orea.oregon.gov DNS is dead as of Feb 2026. License search disabled.

Strategy: Browser automation (Incapsula/JS protection on SOS search)
"""

from __future__ import annotations

import asyncio
import logging
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.models import (
    Business,
    CollectorResult,
    EntityStatus,
    EntityType,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import extract_text, parse_html
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

# NOTE: orea.oregon.gov DNS is dead as of Feb 2026. License search disabled.
OR_LICENSE_URL = "https://www.oregon.gov/rea/Pages/License-Lookup.aspx"

# SOS quick search page — contains #busSearchInput + .business-search-button
OR_BUSINESS_URL = "https://sos.oregon.gov/business/pages/find.aspx"

OR_ENTITY_TYPE_MAP = {
    "LIMITED LIABILITY COMPANY": EntityType.LLC,
    "DOMESTIC LIMITED LIABILITY COMPANY": EntityType.LLC,
    "FOREIGN LIMITED LIABILITY COMPANY": EntityType.LLC,
    "ASSUMED BUSINESS NAME": EntityType.OTHER,
    "CORPORATION": EntityType.CORPORATION,
    "DOMESTIC BUSINESS CORPORATION": EntityType.CORPORATION,
    "FOREIGN BUSINESS CORPORATION": EntityType.CORPORATION,
    "DOMESTIC NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "FOREIGN NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "LIMITED PARTNERSHIP": EntityType.LP,
    "LIMITED LIABILITY PARTNERSHIP": EntityType.LLP,
}

OR_STATUS_MAP = {
    "ACT": EntityStatus.ACTIVE,
    "ACTIVE": EntityStatus.ACTIVE,
    "GOOD STANDING": EntityStatus.ACTIVE,
    "INA": EntityStatus.INACTIVE,
    "INACTIVE": EntityStatus.INACTIVE,
    "DIS": EntityStatus.DISSOLVED,
    "DISSOLVED": EntityStatus.DISSOLVED,
}


@StateRegistry.register
class OregonCollector(BaseStateCollector):
    """Collector for Oregon government data using browser automation."""

    needs_browser_for = [DataCategory.BUSINESSES]

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="OR",
            name="Oregon",
            supported_categories=[
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "Oregon Secretary of State",
            ],
            notes=(
                "Business search uses browser automation (JS protection). "
                "License search disabled — orea.oregon.gov DNS is dead as of Feb 2026."
            ),
        )

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """Oregon Real Estate Agency license search.

        NOTE: orea.oregon.gov DNS is dead as of Feb 2026. This method is disabled.
        """
        logger.warning(
            "OR license search disabled: orea.oregon.gov DNS is dead as of Feb 2026."
        )
        return
        yield  # type: ignore[misc]  # Makes this an async generator

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """Search Oregon SOS for business entities.

        Uses the SOS quick-search widget on sos.oregon.gov which triggers
        a JavaScript redirect to egov.sos.state.or.us for results.
        Requires Camoufox + ISP proxy to bypass Shape Security/Akamai bot
        protection on egov.sos.state.or.us.
        """
        if not params.query:
            logger.warning("OR SOS: query (business name) is required")
            return

        if not self.has_browser:
            logger.warning(
                "OR SOS requires browser automation (JS protection). "
                "Use use_camoufox=True."
            )
            return

        html = ""
        page = await self.browser.new_page()
        try:
            await page.goto(
                OR_BUSINESS_URL,
                wait_until="domcontentloaded",
                timeout=20000,
            )

            # Wait for the quick-search input
            await page.wait_for_selector("#busSearchInput", timeout=10000)
            await page.fill("#busSearchInput", params.query)

            # The JS handler navigates the current page to
            # egov.sos.state.or.us with query-string parameters.
            await page.click("button.business-search-button")

            # Wait for navigation to the egov.sos results page
            try:
                await page.wait_for_url(
                    "**/egov.sos.state.or.us/**", timeout=15000
                )
            except Exception:
                pass
            await page.wait_for_load_state(
                "domcontentloaded", timeout=15000
            )
            # egov.sos has Shape Security bot protection — wait for JS challenge to clear
            await asyncio.sleep(5)
            html = await page.content()

        except Exception as e:
            logger.error("OR SOS business search failed: %s", e)
            return
        finally:
            try:
                await page.close()
            except Exception:
                pass

        # --- Parse results ---
        # The egov.sos result table has columns:
        #   Record No | Entity Type | Entity Status | Registry Number |
        #   Name Status | Name | Assoc Search
        tree = parse_html(html)
        rows = tree.css("table tr")

        count = 0
        for row in rows:
            if count >= params.max_results:
                break

            cells = row.css("td")
            # Need at least 6 cells (the data columns)
            if len(cells) < 6:
                continue

            record_no = (cells[0].text(deep=True) or "").strip()
            entity_type_text = (cells[1].text(deep=True) or "").strip()
            status_text = (cells[2].text(deep=True) or "").strip()
            registry_number = (cells[3].text(deep=True) or "").strip()
            # cells[4] = Name Status (CUR/PRE)
            name = (cells[5].text(deep=True) or "").strip()

            # Skip header row
            if record_no.upper() == "RECORD NO" or not name:
                continue

            entity_type = OR_ENTITY_TYPE_MAP.get(
                entity_type_text.upper(), EntityType.OTHER
            )

            status = OR_STATUS_MAP.get(
                status_text.upper(), EntityStatus.OTHER
            )

            business = Business(
                name=name,
                entity_type=entity_type,
                status=status,
                state="OR",
                filing_number=registry_number or None,
                source_url=OR_BUSINESS_URL,
                raw_data={
                    "entity_type_text": entity_type_text,
                    "status_text": status_text,
                    "record_no": record_no,
                },
            )

            yield CollectorResult(
                category=DataCategory.BUSINESSES.value,
                state="OR",
                data=business,
                source="Oregon Secretary of State",
            )
            count += 1

        logger.info("OR SOS: returned %d business results", count)
