"""
Pennsylvania state collector.

Sources:
- PALS (Pennsylvania Licensing System): Real estate license lookups
  https://www.pals.pa.gov/verify (license verification portal)
- PA DOS: Business entity search
  https://file.dos.pa.gov/forms/business (business registry portal - Cloudflare protected)
"""

from __future__ import annotations

import logging
import re
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.models import (
    Address,
    Business,
    CollectorResult,
    EntityStatus,
    License,
    LicenseStatus,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import clean_text, parse_html
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

# --- PALS (Real Estate License) ---

PALS_VERIFY_URL = "https://www.pals.pa.gov/verify"

# --- PA DOS (Business Entity) ---

PA_BIZ_SEARCH_URL = "https://file.dos.pa.gov/forms/business"

LICENSE_STATUS_MAP = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "CURRENT": LicenseStatus.ACTIVE,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
    "REVOKED": LicenseStatus.REVOKED,
    "SUSPENDED": LicenseStatus.SUSPENDED,
}

ENTITY_STATUS_MAP = {
    "ACTIVE": EntityStatus.ACTIVE,
    "GOOD STANDING": EntityStatus.ACTIVE,
    "INACTIVE": EntityStatus.INACTIVE,
    "DISSOLVED": EntityStatus.DISSOLVED,
    "TERMINATED": EntityStatus.DISSOLVED,
}

@StateRegistry.register
class PennsylvaniaCollector(BaseStateCollector):
    """Collector for Pennsylvania government data.
    
    PALS license search: requires browser automation (SPA).
    PA DOS business search: requires browser automation (Cloudflare protected).
    """

    needs_browser_for = [DataCategory.LICENSES, DataCategory.BUSINESSES]

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="PA",
            name="Pennsylvania",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "Pennsylvania Licensing System (PALS)",
                "Pennsylvania Department of State — Business Registry Portal",
            ],
            notes="Both searches require browser automation (SPA/Cloudflare).",
        )

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Pennsylvania PALS real estate license search via browser automation.
        """
        query = params.query
        if not query:
            logger.warning("PA PALS: query is required")
            return

        if not self.has_browser:
            logger.warning(
                "PA PALS requires browser automation. Initialize with use_browser=True."
            )
            return

        try:
            page = await self.browser.new_page()
        except Exception as e:
            logger.error("PA PALS: failed to create browser page: %s", e)
            return

        count = 0
        max_results = params.max_results

        try:
            await page.goto(
                PALS_VERIFY_URL,
                wait_until="domcontentloaded",
                timeout=20000,
            )

            # Wait for the SPA to load
            await page.wait_for_timeout(5000)

            # Look for Real Estate Commission option
            await page.wait_for_selector('select, input, button', timeout=10000)
            
            # Try to find and select Real Estate Commission
            board_select = await page.query_selector('select[name*="board"], select[name*="Board"]')
            if board_select:
                await page.select_option(board_select, label="Real Estate Commission")
                await page.wait_for_timeout(2000)

            # Find name search field
            name_input = await page.query_selector(
                'input[placeholder*="name"], input[name*="name"], input[type="text"]'
            )
            
            if name_input:
                await name_input.fill(query)
            else:
                logger.warning("PA PALS: could not find name input field")
                return

            # Submit search
            search_btn = await page.query_selector(
                'button[type="submit"], button:has-text("Search"), input[type="submit"]'
            )
            
            if search_btn:
                await search_btn.click()
            else:
                await page.keyboard.press("Enter")

            await page.wait_for_load_state("domcontentloaded", timeout=15000)
            await page.wait_for_timeout(3000)  # Wait for results

            html = await page.content()
            tree = parse_html(html)

            # Parse results
            rows = tree.css("table tr, .result, .license-record")
            for row in rows:
                if count >= max_results:
                    break
                    
                text_content = clean_text(row.text(deep=True))
                if not text_content or len(text_content) < 20:
                    continue

                # Extract license information
                license_match = re.search(r'License #:?\s*(\d+)', text_content, re.I)
                license_number = license_match.group(1) if license_match else None

                # Extract name
                name_match = re.search(r'Name:?\s*([^,\n]+)', text_content, re.I)
                holder_name = name_match.group(1) if name_match else query

                if license_number:
                    # Extract status
                    status = LicenseStatus.ACTIVE
                    for status_keyword, mapped_status in LICENSE_STATUS_MAP.items():
                        if status_keyword.lower() in text_content.lower():
                            status = mapped_status
                            break

                    lic = License(
                        license_number=license_number,
                        license_type="Real Estate",
                        status=status,
                        state="PA",
                        holder_name=holder_name.strip(),
                        source_url=PALS_VERIFY_URL,
                        raw_data={"raw_text": text_content},
                    )

                    yield CollectorResult(
                        category="licenses",
                        state="PA",
                        data=lic,
                        source="Pennsylvania PALS",
                    )
                    count += 1

            logger.info("PA PALS: returned %d license results", count)

        except Exception as e:
            logger.error("PA PALS license search failed: %s", e)
        finally:
            await page.close()

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Pennsylvania DOS business entity search via browser automation.
        
        The PA Business Registry Portal is Cloudflare protected.
        """
        query = params.query
        if not query:
            logger.warning("PA DOS: query is required")
            return

        if not self.has_browser:
            logger.warning(
                "PA DOS requires browser automation. Initialize with use_browser=True."
            )
            return

        try:
            page = await self.browser.new_page()
        except Exception as e:
            logger.error("PA DOS: failed to create browser page: %s", e)
            return

        count = 0
        max_results = params.max_results

        try:
            await page.goto(
                PA_BIZ_SEARCH_URL,
                wait_until="domcontentloaded",
                timeout=20000,
            )

            # Wait for Cloudflare check
            await page.wait_for_timeout(8000)

            # Look for business search form
            search_input = await page.query_selector(
                'input[name*="name"], input[placeholder*="name"], input[type="text"]'
            )
            
            if search_input:
                await search_input.fill(query)
            else:
                logger.warning("PA DOS: could not find search input field")
                return

            # Submit search
            submit_btn = await page.query_selector(
                'button[type="submit"], input[type="submit"], button:has-text("Search")'
            )
            
            if submit_btn:
                await submit_btn.click()
            else:
                await page.keyboard.press("Enter")

            await page.wait_for_load_state("domcontentloaded", timeout=15000)
            await page.wait_for_timeout(5000)  # Wait for results

            html = await page.content()
            tree = parse_html(html)

            # Parse business results
            rows = tree.css("table tr, .result, .business-record")
            for row in rows:
                if count >= max_results:
                    break
                    
                cells = row.css("td")
                if len(cells) >= 2:
                    name = clean_text(cells[0].text(deep=True))
                    entity_number = clean_text(cells[1].text(deep=True))
                    status_text = clean_text(cells[2].text(deep=True)) if len(cells) > 2 else "ACTIVE"
                    entity_type = clean_text(cells[3].text(deep=True)) if len(cells) > 3 else ""
                    
                    if name and "entity name" not in name.lower():
                        status = ENTITY_STATUS_MAP.get(status_text.upper(), EntityStatus.OTHER)

                        biz = Business(
                            name=name,
                            state="PA",
                            filing_number=entity_number,
                            status=status,
                            entity_type=entity_type,
                            source_url=PA_BIZ_SEARCH_URL,
                            raw_data={
                                "status_text": status_text,
                                "entity_type": entity_type,
                            },
                        )

                        yield CollectorResult(
                            category="businesses",
                            state="PA",
                            data=biz,
                            source="Pennsylvania DOS",
                        )
                        count += 1

            logger.info("PA DOS: returned %d business results", count)

        except Exception as e:
            logger.error("PA DOS business search failed: %s", e)
        finally:
            await page.close()