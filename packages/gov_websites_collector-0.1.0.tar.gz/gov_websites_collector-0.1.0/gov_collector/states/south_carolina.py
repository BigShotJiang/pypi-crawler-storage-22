"""
South Carolina state collector.

Sources:
- SCLLR (SC Dept of Labor, Licensing and Regulation): Real estate license verification
  https://verify.llronline.com/LicLookup/Rec/Rec.aspx?div=19
  ASP.NET ViewState form. Fields: txt_lastName, txt_firstName, txt_licNum, txt_city, txt_state.
  
- SC SOS: Business entity search
  https://businessfilings.sc.gov/BusinessFiling/Entity/Search
  MVC form with anti-forgery token. Table: Entity Name, Date, Type, Status, State.

Strategy: HTTP POST for both (confirmed working).
"""

from __future__ import annotations

import logging
import re
from datetime import date as date_cls
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.models import (
    Business,
    CollectorResult,
    EntityStatus,
    EntityType,
    License,
    LicenseStatus,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import extract_text, parse_html
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

SC_LICENSE_URL = "https://verify.llronline.com/LicLookup/Rec/Rec.aspx?div=19"
SC_BUSINESS_URL = "https://businessfilings.sc.gov/BusinessFiling/Entity/Search"

SC_LICENSE_STATUS_MAP = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "CURRENT": LicenseStatus.ACTIVE,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
    "SUSPENDED": LicenseStatus.SUSPENDED,
    "REVOKED": LicenseStatus.REVOKED,
}

SC_ENTITY_TYPE_MAP = {
    "LIMITED LIABILITY COMPANY": EntityType.LLC,
    "CORPORATION": EntityType.CORPORATION,
    "DOMESTIC CORPORATION": EntityType.CORPORATION,
    "FOREIGN CORPORATION": EntityType.CORPORATION,
    "NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "LIMITED PARTNERSHIP": EntityType.LP,
    "LIMITED LIABILITY PARTNERSHIP": EntityType.LLP,
    "GENERAL PARTNERSHIP": EntityType.PARTNERSHIP,
}

SC_STATUS_MAP = {
    "ACTIVE": EntityStatus.ACTIVE,
    "GOOD STANDING": EntityStatus.ACTIVE,
    "INACTIVE": EntityStatus.INACTIVE,
    "DISSOLVED": EntityStatus.DISSOLVED,
    "WITHDRAWN": EntityStatus.WITHDRAWN,
}


def _extract_viewstate(html: str) -> dict:
    """Extract ASP.NET ViewState fields from HTML."""
    fields = {}
    for name in ["__VIEWSTATE", "__VIEWSTATEGENERATOR", "__VIEWSTATEENCRYPTED", "__EVENTVALIDATION"]:
        m = re.search(rf'name="{name}"[^>]*value="([^"]*)"', html)
        if m:
            fields[name] = m.group(1)
    return fields


@StateRegistry.register
class SouthCarolinaCollector(BaseStateCollector):
    """Collector for South Carolina government data using HTTP POST."""

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="SC",
            name="South Carolina",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "South Carolina SCLLR (LLR Online Verification)",
                "South Carolina Secretary of State (Business Filings)",
            ],
            notes="Both sources work via HTTP POST.",
        )

    # --- Licenses: ASP.NET ViewState POST ---

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search SC SCLLR for real estate licenses via ASP.NET ViewState POST.
        
        Form fields (from actual HTML):
        - ctl00$ContentPlaceHolder1$UserInputGen$txt_lastName
        - ctl00$ContentPlaceHolder1$UserInputGen$txt_firstName
        - ctl00$ContentPlaceHolder1$UserInputGen$txt_licNum
        - ctl00$ContentPlaceHolder1$UserInputGen$txt_city
        - ctl00$ContentPlaceHolder1$UserInputGen$txt_state
        - ctl00$ContentPlaceHolder1$UserInputGen$ddl_type (license type dropdown)
        - ctl00$ContentPlaceHolder1$btn_find (submit)
        """
        if not params.query and not params.license_number:
            logger.warning("SC SCLLR: query or license_number is required")
            return

        try:
            # Step 1: GET the form for ViewState
            page_resp = await self.client.get(SC_LICENSE_URL)
            vs = _extract_viewstate(page_resp.text)
            if not vs.get("__VIEWSTATE"):
                logger.error("SC SCLLR: could not extract ViewState")
                return

            # Step 2: Build POST data
            prefix = "ctl00$ContentPlaceHolder1$UserInputGen$"
            form_data = {
                **vs,
                "__EVENTTARGET": "",
                "__EVENTARGUMENT": "",
                "ctl00$ContentPlaceHolder1$btn_find": "Find",
            }

            if params.license_number:
                form_data[f"{prefix}txt_licNum"] = params.license_number
            elif params.query:
                parts = params.query.strip().split(",", maxsplit=1)
                if len(parts) == 1:
                    parts = params.query.strip().split(maxsplit=1)
                form_data[f"{prefix}txt_lastName"] = parts[0].strip()
                if len(parts) > 1:
                    form_data[f"{prefix}txt_firstName"] = parts[1].strip()

            # Step 3: POST
            response = await self.client.post(SC_LICENSE_URL, data=form_data)
            html = response.text

        except Exception as e:
            logger.error("SC SCLLR license search failed: %s", e)
            return

        # Step 4: Parse results
        tree = parse_html(html)
        # Results appear in a table after the search form
        tables = tree.css("table")
        
        count = 0
        for table in tables:
            rows = table.css("tr")
            for row in rows:
                if count >= params.max_results:
                    return

                cells = row.css("td")
                if len(cells) < 3:
                    continue

                # Look for license number pattern
                name = extract_text(cells[0])
                license_num = extract_text(cells[1]) if len(cells) > 1 else None
                license_type = extract_text(cells[2]) if len(cells) > 2 else None
                status_text = extract_text(cells[3]) if len(cells) > 3 else None

                if not name or not license_num:
                    continue
                # Skip form labels
                if "last" in (name or "").lower() or "name" in (name or "").lower():
                    continue

                status = SC_LICENSE_STATUS_MAP.get(
                    (status_text or "").upper().strip(), LicenseStatus.OTHER
                )

                yield CollectorResult(
                    category=DataCategory.LICENSES.value,
                    state="SC",
                    data=License(
                        license_number=license_num.strip(),
                        license_type=license_type or "Real Estate",
                        status=status,
                        state="SC",
                        holder_name=name.strip(),
                        source_url=SC_LICENSE_URL,
                        raw_data={"status_text": status_text},
                    ),
                    source="South Carolina SCLLR",
                )
                count += 1

        logger.info("SC SCLLR: returned %d license results", count)

    # --- Businesses: MVC POST with anti-forgery token ---

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search SC SOS for business entities via HTTP POST.
        
        Form: EntityName input + EntitySearchTypeEnumId select + __RequestVerificationToken.
        Results table: Entity Name, Date of Incorporation, Entity Type, Entity Status, State.
        """
        if not params.query:
            logger.warning("SC SOS: query (business name) is required")
            return

        try:
            # Step 1: GET the page for anti-forgery token
            page_resp = await self.client.get(SC_BUSINESS_URL)
            token_match = re.search(
                r'name="__RequestVerificationToken"[^>]*value="([^"]*)"',
                page_resp.text,
            )

            form_data = {
                "EntityName": params.query,
                "EntitySearchTypeEnumId": "1",  # Contains
            }
            if token_match:
                form_data["__RequestVerificationToken"] = token_match.group(1)

            # Step 2: POST
            response = await self.client.post(SC_BUSINESS_URL, data=form_data)
            html = response.text

        except Exception as e:
            logger.error("SC SOS business search failed: %s", e)
            return

        # Step 3: Parse results table
        # Headers: Entity Name, Date of Incorporation, Entity Type, Entity Status, Incorporated State
        tree = parse_html(html)
        table = tree.css_first("table")
        if not table:
            logger.debug("SC SOS: no results table")
            return

        rows = table.css("tr")
        count = 0
        for row in rows:
            if count >= params.max_results:
                return

            cells = row.css("td")
            if len(cells) < 4:
                continue

            name = extract_text(cells[0])
            date_text = extract_text(cells[1]) if len(cells) > 1 else None
            type_text = extract_text(cells[2]) if len(cells) > 2 else None
            status_text = extract_text(cells[3]) if len(cells) > 3 else None

            if not name:
                continue
            # Skip pagination rows
            if name.startswith("1 2 3") or ">" in name[:10]:
                continue

            entity_type = SC_ENTITY_TYPE_MAP.get(
                (type_text or "").upper().strip(), EntityType.OTHER
            )
            status = SC_STATUS_MAP.get(
                (status_text or "").upper().strip(), EntityStatus.OTHER
            )

            formation_date = None
            if date_text:
                m = re.match(r"(\d{2})/(\d{2})/(\d{4})", date_text)
                if m:
                    try:
                        formation_date = date_cls(int(m.group(3)), int(m.group(1)), int(m.group(2)))
                    except ValueError:
                        pass

            business = Business(
                name=name.strip(),
                entity_type=entity_type,
                status=status,
                state="SC",
                formation_date=formation_date,
                source_url=SC_BUSINESS_URL,
                raw_data={
                    "date": date_text,
                    "type": type_text,
                    "status": status_text,
                },
            )

            yield CollectorResult(
                category=DataCategory.BUSINESSES.value,
                state="SC",
                data=business,
                source="South Carolina Secretary of State",
            )
            count += 1

        logger.info("SC SOS: returned %d business results", count)
