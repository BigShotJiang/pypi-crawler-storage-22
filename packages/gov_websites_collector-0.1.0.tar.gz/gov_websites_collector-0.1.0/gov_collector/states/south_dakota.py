"""
South Dakota state collector.

Sources:
- SDREC / DLR: Real estate license search (ASP.NET WebForms)
  https://dlr.sd.gov/bdcomm/realestate/licensee_search.aspx
  Note: ASP.NET WebForms with ViewState token management.
- SD SOS Enterprise: Business entity search (ASP.NET WebForms)
  https://sosenterprise.sd.gov/BusinessServices/Business/FilingSearch.aspx
"""

from __future__ import annotations

import logging
import re
from datetime import date as date_cls
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.models import (
    Address,
    Business,
    CollectorResult,
    EntityStatus,
    EntityType,
    License,
    LicenseStatus,
    Person,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import (
    clean_text,
    extract_table_rows,
    extract_text,
    parse_address_text,
    parse_html,
)
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

# --- SDREC / DLR (Real Estate) ---

SDREC_SEARCH_URL = "https://dlr.sd.gov/bdcomm/realestate/licensee_search.aspx"

SDREC_STATUS_MAP = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "CURRENT": LicenseStatus.ACTIVE,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
    "SUSPENDED": LicenseStatus.SUSPENDED,
    "REVOKED": LicenseStatus.REVOKED,
    "CANCELLED": LicenseStatus.CANCELLED,
    "PENDING": LicenseStatus.PENDING,
}

# --- SD SOS Enterprise (Business Entity) ---

SD_SOS_SEARCH_URL = "https://sosenterprise.sd.gov/BusinessServices/Business/FilingSearch.aspx"

SD_ENTITY_TYPE_MAP = {
    "DOMESTIC LIMITED LIABILITY COMPANY": EntityType.LLC,
    "FOREIGN LIMITED LIABILITY COMPANY": EntityType.LLC,
    "DOMESTIC BUSINESS CORPORATION": EntityType.CORPORATION,
    "DOMESTIC CORPORATION": EntityType.CORPORATION,
    "DOMESTIC FOR PROFIT CORPORATION": EntityType.CORPORATION,
    "FOREIGN BUSINESS CORPORATION": EntityType.CORPORATION,
    "FOREIGN CORPORATION": EntityType.CORPORATION,
    "DOMESTIC NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "FOREIGN NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "DOMESTIC LIMITED PARTNERSHIP": EntityType.LP,
    "FOREIGN LIMITED PARTNERSHIP": EntityType.LP,
    "LIMITED LIABILITY PARTNERSHIP": EntityType.LLP,
    "GENERAL PARTNERSHIP": EntityType.PARTNERSHIP,
    "SOLE PROPRIETORSHIP": EntityType.SOLE_PROPRIETORSHIP,
}

SD_STATUS_MAP = {
    "ACTIVE": EntityStatus.ACTIVE,
    "IN GOOD STANDING": EntityStatus.ACTIVE,
    "GOOD STANDING": EntityStatus.ACTIVE,
    "INACTIVE": EntityStatus.INACTIVE,
    "DISSOLVED": EntityStatus.DISSOLVED,
    "ADMIN DISSOLVED": EntityStatus.DISSOLVED,
    "ADMINISTRATIVELY DISSOLVED": EntityStatus.DISSOLVED,
    "REVOKED": EntityStatus.DISSOLVED,
    "SUSPENDED": EntityStatus.SUSPENDED,
    "WITHDRAWN": EntityStatus.WITHDRAWN,
    "DELINQUENT": EntityStatus.SUSPENDED,
    "CANCELLED": EntityStatus.DISSOLVED,
}


@StateRegistry.register
class SouthDakotaCollector(BaseStateCollector):
    """Collector for South Dakota government data."""

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="SD",
            name="South Dakota",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "South Dakota Dept. of Labor & Regulation (DLR) — Real Estate Commission",
                "South Dakota Secretary of State — SOS Enterprise",
            ],
            notes="Both systems use ASP.NET WebForms requiring ViewState token management.",
        )

    # --- Real Estate Licenses (SDREC / DLR) ---

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search SD DLR for real estate licenses.

        ASP.NET WebForms: GET for ViewState, then POST with search data.
        """
        if not params.query and not params.license_number:
            raise ValueError(
                "Either 'query' (name) or 'license_number' is required for SD license search"
            )

        # Step 1: GET initial page for ViewState
        try:
            init_response = await self.client.get(SDREC_SEARCH_URL)
            init_html = init_response.text
            
            # Check if we got redirected to error page
            if "error.aspx" in str(init_response.url) or "An error has occurred" in init_html:
                logger.warning(
                    "SD DLR: License search page redirected to error page. "
                    "Service may be temporarily unavailable or URL has changed."
                )
                return
                
        except Exception as e:
            logger.error("SD DLR initial page load failed: %s", e)
            return

        viewstate = self._extract_aspnet_field(init_html, "__VIEWSTATE")
        viewstate_gen = self._extract_aspnet_field(init_html, "__VIEWSTATEGENERATOR")
        event_validation = self._extract_aspnet_field(init_html, "__EVENTVALIDATION")

        if not viewstate:
            logger.warning("SD DLR: Failed to extract ViewState - page may have changed or be unavailable")
            return

        # Step 2: POST search form
        form_data = {
            "__VIEWSTATE": viewstate,
            "__VIEWSTATEGENERATOR": viewstate_gen or "",
            "__EVENTVALIDATION": event_validation or "",
            "ctl00$MainContent$btnSearch": "Search",
        }

        if params.license_number:
            form_data[
                "ctl00$MainContent$txtLicenseNumber"
            ] = params.license_number
        elif params.query:
            parts = params.query.strip().split(maxsplit=1)
            form_data[
                "ctl00$MainContent$txtLastName"
            ] = parts[0]
            if len(parts) > 1:
                form_data[
                    "ctl00$MainContent$txtFirstName"
                ] = parts[1]

        try:
            response = await self.client.post(SDREC_SEARCH_URL, data=form_data)
            html = response.text
        except Exception as e:
            logger.error("SD DLR license search failed: %s", e)
            return

        count = 0
        async for result in self._parse_sdrec_results(html):
            yield result
            count += 1
            if count >= params.max_results:
                return

    def _extract_aspnet_field(self, html: str, field_name: str) -> str | None:
        """Extract an ASP.NET hidden form field value."""
        pattern = rf'id="{re.escape(field_name)}"[^>]*value="([^"]*)"'
        match = re.search(pattern, html)
        if match:
            return match.group(1)
        pattern2 = rf'name="{re.escape(field_name)}"[^>]*value="([^"]*)"'
        match2 = re.search(pattern2, html)
        return match2.group(1) if match2 else None

    async def _parse_sdrec_results(
        self, html: str
    ) -> AsyncIterator[CollectorResult]:
        """Parse SD DLR real estate license results."""
        tree = parse_html(html)

        results_table = tree.css_first(
            "table[id*='GridView'], table[id*='grdResults'], table[id*='gvResults'], table.results"
        )
        if not results_table:
            logger.debug("No SD DLR results table found")
            return

        rows = results_table.css("tr")
        if len(rows) < 2:
            return

        header_cells = rows[0].css("th, td")
        headers = [
            clean_text(cell.text(deep=True)) or f"col_{i}"
            for i, cell in enumerate(header_cells)
        ]

        for row in rows[1:]:
            cells = row.css("td")
            if not cells:
                continue

            row_data = {}
            for i, cell in enumerate(cells):
                key = headers[i] if i < len(headers) else f"col_{i}"
                row_data[key] = clean_text(cell.text(deep=True)) or ""

            name_text = (
                row_data.get("Name")
                or row_data.get("Licensee Name")
                or row_data.get("Licensee")
                or row_data.get("col_0")
            )
            license_id = (
                row_data.get("License Number")
                or row_data.get("License #")
                or row_data.get("License")
                or row_data.get("col_1")
            )

            if not name_text or not license_id:
                continue

            license_type = (
                row_data.get("License Type")
                or row_data.get("Type")
                or "Real Estate"
            )

            status_text = row_data.get("Status") or ""
            status = SDREC_STATUS_MAP.get(
                status_text.upper().strip(), LicenseStatus.OTHER
            )

            exp_date = None
            exp_str = row_data.get("Expiration Date") or row_data.get("Exp Date")
            if exp_str:
                for fmt in ("%m/%d/%Y", "%Y-%m-%d"):
                    try:
                        exp_date = date_cls.strptime(exp_str.strip(), fmt).date()
                    except (ValueError, AttributeError):
                        continue

            city = row_data.get("City")
            address = Address(city=city, state="SD") if city else None

            license_obj = License(
                license_number=license_id.strip(),
                license_type=license_type.strip(),
                status=status,
                state="SD",
                holder_name=name_text.strip(),
                address=address,
                expiration_date=exp_date,
                source_url=SDREC_SEARCH_URL,
                raw_data=row_data,
            )

            yield CollectorResult(
                category=DataCategory.LICENSES.value,
                state="SD",
                data=license_obj,
                source="South Dakota DLR",
            )

    # --- Business Entity Search ---

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search SD Secretary of State for business entities.

        ASP.NET WebForms at sosenterprise.sd.gov with ViewState.
        """
        if not params.query:
            raise ValueError(
                "'query' (business name) is required for SD business search"
            )

        # Step 1: GET initial page for ViewState
        try:
            init_response = await self.client.get(SD_SOS_SEARCH_URL)
            init_html = init_response.text
        except Exception as e:
            logger.error("SD SOS initial page load failed: %s", e)
            return

        viewstate = self._extract_aspnet_field(init_html, "__VIEWSTATE")
        viewstate_gen = self._extract_aspnet_field(init_html, "__VIEWSTATEGENERATOR")
        event_validation = self._extract_aspnet_field(init_html, "__EVENTVALIDATION")

        if not viewstate:
            logger.error("Failed to extract ViewState from SD SOS page")
            return

        # Step 2: POST search form
        form_data = {
            "__VIEWSTATE": viewstate,
            "__VIEWSTATEGENERATOR": viewstate_gen or "",
            "__EVENTVALIDATION": event_validation or "",
            "ctl00$MainContent$txtSearchValue": params.query,
            "ctl00$MainContent$searchOpt": "chkSearchIncludes",
            "__EVENTTARGET": "ctl00$MainContent$btnSearch",
            "__EVENTARGUMENT": "",
        }

        try:
            response = await self.client.post(SD_SOS_SEARCH_URL, data=form_data)
            html = response.text
        except Exception as e:
            logger.error("SD SOS business search failed: %s", e)
            return

        rows = extract_table_rows(html)
        count = 0

        for row in rows:
            if count >= params.max_results:
                return

            business = self._parse_sd_business_row(row)
            if business:
                yield CollectorResult(
                    category=DataCategory.BUSINESSES.value,
                    state="SD",
                    data=business,
                    source="South Dakota Secretary of State",
                )
                count += 1

    def _parse_sd_business_row(self, row: dict[str, str]) -> Business | None:
        """Parse a single SD SOS business row."""
        name = (
            row.get("Entity Name")
            or row.get("Business Name")
            or row.get("Name")
            or row.get("col_0")
        )
        if not name:
            return None

        type_str = (
            row.get("Entity Type") or row.get("Type") or row.get("col_1", "")
        ).upper()
        entity_type = SD_ENTITY_TYPE_MAP.get(type_str, EntityType.OTHER)

        status_str = (
            row.get("Status") or row.get("Standing") or row.get("col_2", "")
        ).upper()
        status = SD_STATUS_MAP.get(status_str, EntityStatus.OTHER)

        filing_number = (
            row.get("Filing Number")
            or row.get("ID")
            or row.get("col_3")
        )

        formation_date = None
        date_str = (
            row.get("Date Filed")
            or row.get("Filing Date")
            or row.get("Date of Formation")
        )
        if date_str:
            for fmt in ("%m/%d/%Y", "%Y-%m-%d"):
                try:
                    formation_date = date_cls.strptime(date_str.strip(), fmt).date()
                except (ValueError, AttributeError):
                    continue

        address = None
        addr_str = (
            row.get("Principal Address")
            or row.get("Principal Office Address")
            or row.get("Address")
        )
        if addr_str:
            address = parse_address_text(addr_str)

        agent_name = row.get("Registered Agent") or row.get("Agent")
        agent = Person(full_name=agent_name) if agent_name else None

        return Business(
            name=name.strip(),
            entity_type=entity_type,
            status=status,
            state="SD",
            filing_number=filing_number,
            formation_date=formation_date,
            address=address,
            registered_agent=agent,
            source_url=SD_SOS_SEARCH_URL,
            raw_data=row,
        )
