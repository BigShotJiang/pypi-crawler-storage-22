"""
Tennessee state collector.

Sources:
- Tennessee Department of Commerce & Insurance: License/credential verification
  https://verify.tn.gov/
  React SPA (Next.js + Material UI) — requires browser automation.
  API backend: access.cloud.commerce.tn.gov/entellitrak/api/endpoints/v1
- Tennessee Secretary of State: Business entity search
  NOTE: tnbear.tn.gov / tncab.tnsos.gov times out as of Feb 2026.
  Business search disabled.
"""

from __future__ import annotations

import asyncio
import logging
import re
from datetime import date as date_cls
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.models import (
    Business,
    CollectorResult,
    EntityStatus,
    EntityType,
    License,
    LicenseStatus,
    Person,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import (  # noqa: F401 (clean_text/extract_text unused but kept)
    clean_text,
    extract_text,
    parse_html,
)
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

# --- License Verification (Commerce & Insurance) ---
# React SPA at verify.tn.gov. Search input: input[type="search"],
# submit: button[type="submit"]. Results rendered client-side via MUI.
TREC_SEARCH_URL = "https://verify.tn.gov/"

TN_LICENSE_STATUS_MAP = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "CURRENT": LicenseStatus.ACTIVE,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
    "SUSPENDED": LicenseStatus.SUSPENDED,
    "REVOKED": LicenseStatus.REVOKED,
    "CANCELLED": LicenseStatus.CANCELLED,
    "RETIRED": LicenseStatus.INACTIVE,
    "PENDING": LicenseStatus.PENDING,
}

# --- Secretary of State (Business Entity) ---
# NOTE: tnbear.tn.gov / tncab.tnsos.gov times out as of Feb 2026.
SOS_SEARCH_URL = "https://tncab.tnsos.gov/business-entity-search"

TN_ENTITY_TYPES = {
    "LIMITED LIABILITY COMPANY": EntityType.LLC,
    "DOMESTIC LIMITED LIABILITY COMPANY": EntityType.LLC,
    "FOREIGN LIMITED LIABILITY COMPANY": EntityType.LLC,
    "CORPORATION": EntityType.CORPORATION,
    "DOMESTIC CORPORATION": EntityType.CORPORATION,
    "FOREIGN CORPORATION": EntityType.CORPORATION,
    "DOMESTIC NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "FOREIGN NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "LIMITED PARTNERSHIP": EntityType.LP,
    "DOMESTIC LIMITED PARTNERSHIP": EntityType.LP,
    "FOREIGN LIMITED PARTNERSHIP": EntityType.LP,
    "GENERAL PARTNERSHIP": EntityType.PARTNERSHIP,
    "LIMITED LIABILITY PARTNERSHIP": EntityType.LLP,
}

TN_STATUS_MAP = {
    "ACTIVE": EntityStatus.ACTIVE,
    "ACTIVE/GOOD STANDING": EntityStatus.ACTIVE,
    "GOOD STANDING": EntityStatus.ACTIVE,
    "INACTIVE": EntityStatus.INACTIVE,
    "DISSOLVED": EntityStatus.DISSOLVED,
    "CANCELLED": EntityStatus.DISSOLVED,
    "REVOKED": EntityStatus.DISSOLVED,
    "SUSPENDED": EntityStatus.SUSPENDED,
    "WITHDRAWN": EntityStatus.WITHDRAWN,
    "MERGED": EntityStatus.MERGED,
    "CONVERTED": EntityStatus.CONVERTED,
}


@StateRegistry.register
class TennesseeCollector(BaseStateCollector):
    """Collector for Tennessee government data."""

    needs_browser_for = [DataCategory.LICENSES]

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="TN",
            name="Tennessee",
            supported_categories=[
                DataCategory.LICENSES.value,
            ],
            sources=[
                "Tennessee Dept of Commerce & Insurance (verify.tn.gov)",
            ],
            notes=(
                "License verification requires browser automation (React SPA). "
                "Business search disabled — tnbear.tn.gov times out as of Feb 2026."
            ),
        )

    # ------------------------------------------------------------------ #
    #  License Verification (verify.tn.gov)
    # ------------------------------------------------------------------ #

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search Tennessee license verification at verify.tn.gov.

        The site is a React SPA (Next.js + MUI). We fill the single
        search input and submit, then parse the rendered results.
        """
        query = params.query or params.license_number
        if not query:
            logger.warning("TN: query or license_number is required")
            return

        if not self.has_browser:
            logger.warning(
                "TN license search requires browser automation (React SPA). "
                "Use use_camoufox=True."
            )
            return

        page = await self.browser.new_page()
        try:
            await page.goto(
                TREC_SEARCH_URL,
                wait_until="domcontentloaded",
                timeout=20000,
            )

            # Wait for the MUI search input to render.
            # Note: input[type="search"] fails in Camoufox/Firefox;
            # use 'form input' which reliably finds the single form input.
            search_sel = "form input"
            await page.wait_for_selector(search_sel, timeout=15000)

            await page.fill(search_sel, query)
            await asyncio.sleep(0.3)

            # Submit — SPA navigates to search.cloud.commerce.tn.gov/search
            submit_sel = 'button[type="submit"]'
            try:
                await page.click(submit_sel)
            except Exception:
                await page.keyboard.press("Enter")

            # Wait for MUI result cards to render
            try:
                await page.wait_for_selector(
                    "[class*='MuiCard-root']",
                    timeout=15000,
                )
            except Exception:
                pass

            await asyncio.sleep(2)

            # Extract structured data from MUI cards via JS
            # (selectolax loses line-breaks between MUI block elements)
            raw_cards = await page.evaluate("""() => {
                const cards = document.querySelectorAll('[class*="MuiCard-root"]');
                return Array.from(cards).map(card => {
                    const title = card.querySelector('[class*="MuiCardHeader-title"]');
                    const sub = card.querySelector('[class*="MuiCardHeader-subheader"]');
                    const lines = card.innerText.split('\\n').map(l => l.trim()).filter(Boolean);
                    return {
                        name: title ? title.innerText.trim() : '',
                        entity_type: sub ? sub.innerText.trim() : '',
                        lines: lines
                    };
                });
            }""")

        except Exception as e:
            logger.error("TN license search failed: %s", e)
            return
        finally:
            await page.close()

        # --- Build results from extracted card data ---
        yield_count = 0
        for card_data in raw_cards:
            if yield_count >= params.max_results:
                return

            result = self._parse_card(card_data)
            if result:
                yield result
                yield_count += 1

        logger.info("TN: returned %d license results", yield_count)

    # Known status strings for field identification
    _STATUS_STRINGS = {
        "ACTIVE", "INACTIVE", "EXPIRED", "SUSPENDED", "REVOKED",
        "CANCELLED", "PENDING", "RETIRED", "CLOSED",
        "APPLICATION EXPIRED", "FAILED TO RENEW", "CURRENT",
    }

    def _parse_card(self, card_data: dict) -> CollectorResult | None:
        """Parse a single MUI card extracted via JS into a CollectorResult.

        card_data keys: name, entity_type, lines.
        The lines between "License Details" and "Primary Contact Information"
        contain license type (1-2 lines), number, status, and expiry — but
        the count varies, so we identify fields by pattern.
        """
        name_text = card_data.get("name", "")
        lines = card_data.get("lines", [])

        if not name_text or len(lines) < 4:
            return None

        # Extract the slice between "License Details" and
        # "Primary Contact Information"
        try:
            ld_idx = lines.index("License Details")
        except ValueError:
            return None

        try:
            pc_idx = lines.index("Primary Contact Information")
        except ValueError:
            pc_idx = len(lines)

        detail_lines = lines[ld_idx + 1 : pc_idx]
        if not detail_lines:
            return None

        # Identify fields by pattern:
        #   - license number: purely numeric (or mostly numeric)
        #   - status: matches a known status string
        #   - expiry date: MM/DD/YYYY pattern
        #   - everything else before the number = license type parts
        license_id = ""
        status_text = ""
        expiry_text = ""
        type_parts: list[str] = []

        number_found = False
        for line in detail_lines:
            upper = line.upper().strip()
            if not number_found and re.match(r"^\d+$", line.strip()):
                license_id = line.strip()
                number_found = True
            elif upper in self._STATUS_STRINGS:
                status_text = line.strip()
            elif re.match(r"\d{2}/\d{2}/\d{4}", line.strip()):
                expiry_text = line.strip()
            elif not number_found:
                # Part of the license type description
                type_parts.append(line.strip())
            # else: ignore lines after number that aren't status/date

        license_type_text = " — ".join(type_parts) if type_parts else ""

        if not license_id and not license_type_text:
            return None

        status = self._map_license_status(status_text)

        expiration_date = None
        if expiry_text:
            try:
                from datetime import datetime

                expiration_date = datetime.strptime(
                    expiry_text, "%m/%d/%Y"
                ).date()
            except (ValueError, AttributeError):
                pass

        lic = License(
            license_number=license_id or "N/A",
            license_type=license_type_text or "Professional License",
            status=status,
            state="TN",
            holder_name=name_text.strip(),
            expiration_date=expiration_date,
            source_url=TREC_SEARCH_URL,
            raw_data={
                "name": name_text,
                "entity_type": card_data.get("entity_type", ""),
                "license_type": license_type_text,
                "status_text": status_text,
                "expiry_text": expiry_text,
            },
        )

        return CollectorResult(
            category=DataCategory.LICENSES.value,
            state="TN",
            data=lic,
            source="Tennessee Commerce & Insurance",
        )

    @staticmethod
    def _map_license_status(text: str) -> LicenseStatus:
        if not text:
            return LicenseStatus.OTHER
        return TN_LICENSE_STATUS_MAP.get(
            text.upper().strip(), LicenseStatus.OTHER
        )

    # ------------------------------------------------------------------ #
    #  Business Entity Search (DISABLED)
    # ------------------------------------------------------------------ #

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Tennessee SOS business entity search.

        NOTE: tnbear.tn.gov / tncab.tnsos.gov times out as of Feb 2026.
        This method is disabled.
        """
        logger.warning(
            "TN business search disabled: tnbear.tn.gov / tncab.tnsos.gov "
            "times out as of Feb 2026."
        )
        return
        yield  # type: ignore[misc]
