"""
Texas state collector.

Sources:
- TREC (Texas Real Estate Commission): License lookups
  https://www.trec.texas.gov/apps/license-holder-search/
  Browser needed — JavaScript SPA with search form.

- TX Comptroller: Business entity search (franchise tax account status)
  JSON API at: https://comptroller.texas.gov/data-search/franchise-tax?name=QUERY
  Returns JSON with name, taxpayerId, mailingAddressZip.
  Note: API rejects queries returning >500 results (HTTP 413).
"""

from __future__ import annotations

import logging
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.models import (
    Address,
    Business,
    CollectorResult,
    EntityStatus,
    License,
    LicenseStatus,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import clean_text, parse_html
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

TREC_SEARCH_URL = "https://www.trec.texas.gov/apps/license-holder-search/"
TX_API_URL = "https://comptroller.texas.gov/data-search/franchise-tax"


@StateRegistry.register
class TexasCollector(BaseStateCollector):
    """Collector for Texas government data.
    
    License search: TREC license holder search (browser needed).
    Business search: TX Comptroller JSON API (HTTP, no browser needed).
    """

    needs_browser_for = [DataCategory.LICENSES]

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="TX",
            name="Texas",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "Texas Real Estate Commission (TREC) — License Holder Search",
                "Texas Comptroller of Public Accounts — Franchise Tax API",
            ],
        )

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """TX Comptroller franchise tax API — no browser needed."""
        query = params.query
        if not query:
            return

        count = 0
        max_results = params.max_results

        try:
            resp = await self.client.raw.get(
                TX_API_URL,
                params={"name": query},
                timeout=15,
            )
            
            # API returns 413 when too many results (>500)
            if resp.status_code == 413:
                logger.info("TX Comptroller: query '%s' too broad (413), retrying with longer query", query)
                # Try appending common suffixes to narrow results
                for suffix in ["field", "son", "ing", "er"]:
                    try:
                        resp2 = await self.client.raw.get(
                            TX_API_URL,
                            params={"name": query + suffix},
                            timeout=15,
                        )
                        if resp2.status_code == 200:
                            resp = resp2
                            break
                    except Exception:
                        continue
                else:
                    logger.warning("TX Comptroller: all queries returned too many results")
                    return
            
            data = resp.json()

            if not data.get("success"):
                error = data.get("error", "Unknown error")
                logger.warning("TX Comptroller API: %s", error)
                return

            results = data.get("data", [])
            for item in results:
                if count >= max_results:
                    break

                name = item.get("name", "")
                if not name:
                    continue

                taxpayer_id = item.get("taxpayerId", "")
                zip_code = item.get("mailingAddressZip", "")

                address = None
                if zip_code:
                    address = Address(zip_code=zip_code, state="TX")

                biz = Business(
                    name=name,
                    state="TX",
                    filing_number=taxpayer_id,
                    status=EntityStatus.ACTIVE,  # API only returns active accounts
                    address=address,
                    source_url=f"{TX_API_URL}?name={query}",
                    raw_data=item,
                )
                yield CollectorResult(
                    category="businesses",
                    state="TX",
                    data=biz,
                    source="TX Comptroller",
                )
                count += 1

            logger.info("TX Comptroller: returned %d business results", count)

        except Exception as e:
            logger.error("TX Comptroller business search failed: %s", e)

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """TX TREC license holder search — requires browser."""
        query = params.query
        if not query:
            return

        if not self.has_browser:
            logger.warning("TX TREC requires browser. Use use_browser=True.")
            return

        try:
            page = await self.browser.new_page()
        except Exception as e:
            logger.error("TX TREC: failed to create browser page: %s", e)
            return

        count = 0
        max_results = params.max_results

        try:
            await page.goto(
                TREC_SEARCH_URL,
                wait_until="domcontentloaded",
                timeout=20000,
            )

            # Find and fill the search input
            search_input = await page.query_selector(
                'input[name="name"], input[name="search"], input[type="text"], #name, #search, '
                'input[placeholder*="name" i], input[placeholder*="search" i]'
            )
            if search_input:
                await search_input.fill(query)
            else:
                logger.warning("TX TREC: could not find search input")
                return

            # Submit
            submit_btn = await page.query_selector(
                'button[type="submit"], input[type="submit"], '
                'button:has-text("Search"), button:has-text("Find")'
            )
            if submit_btn:
                await submit_btn.click()
            else:
                await page.keyboard.press("Enter")

            await page.wait_for_load_state("domcontentloaded", timeout=15000)

            # Wait for results
            try:
                await page.wait_for_selector(
                    "table, .search-results, .results",
                    timeout=10000,
                )
            except Exception:
                pass

            html = await page.content()
            tree = parse_html(html)

            rows = tree.css("table tr, .result-row")
            for row in rows:
                if count >= max_results:
                    break
                cells = row.css("td")
                if len(cells) < 2:
                    continue

                holder_name = clean_text(cells[0].text(deep=True))
                if not holder_name:
                    continue
                if any(kw in holder_name.lower() for kw in ["name", "license holder"]):
                    continue

                lic_number = clean_text(cells[1].text(deep=True)) if len(cells) > 1 else None
                lic_type = clean_text(cells[2].text(deep=True)) if len(cells) > 2 else "Real Estate"
                status_text = clean_text(cells[3].text(deep=True)) if len(cells) > 3 else ""

                if not lic_number:
                    continue

                status = LicenseStatus.ACTIVE
                if status_text:
                    st = status_text.lower()
                    if "expired" in st:
                        status = LicenseStatus.EXPIRED
                    elif "inactive" in st:
                        status = LicenseStatus.INACTIVE

                lic = License(
                    license_number=lic_number,
                    license_type=lic_type or "Real Estate",
                    status=status,
                    state="TX",
                    holder_name=holder_name,
                    source_url=TREC_SEARCH_URL,
                    raw_data={"status_text": status_text},
                )
                yield CollectorResult(
                    category="licenses",
                    state="TX",
                    data=lic,
                    source="TX TREC",
                )
                count += 1

            logger.info("TX TREC: returned %d license results", count)

        except Exception as e:
            logger.error("TX TREC license search failed: %s", e)
        finally:
            await page.close()
