"""
Utah state collector.

Sources:
- DOPL (Department of Commerce - Division of Occupational and Professional Licensing):
  License verification
  https://secure.utah.gov/llv/search/index.html
- Utah Division of Corporations: Business entity search
  https://secure.utah.gov/bes/

Strategy: HYBRID approach
- Licenses: HTTP with form submission
- Businesses: Browser automation (JavaScript interface)
"""

from __future__ import annotations

import logging
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.models import (
    Business,
    CollectorResult,
    EntityStatus,
    EntityType,
    License,
    LicenseStatus,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import extract_text, parse_html
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

UT_LICENSE_URL = "https://secure.utah.gov/llv/search/index.html"
UT_BUSINESS_URL = "https://secure.utah.gov/bes/"

UT_LICENSE_STATUS_MAP = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "CURRENT": LicenseStatus.ACTIVE,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
}

UT_ENTITY_TYPE_MAP = {
    "LIMITED LIABILITY COMPANY": EntityType.LLC,
    "CORPORATION": EntityType.CORPORATION,
    "NONPROFIT CORPORATION": EntityType.NONPROFIT,
}

UT_STATUS_MAP = {
    "ACTIVE": EntityStatus.ACTIVE,
    "GOOD STANDING": EntityStatus.ACTIVE,
    "INACTIVE": EntityStatus.INACTIVE,
}


@StateRegistry.register
class UtahCollector(BaseStateCollector):
    """Collector for Utah government data using hybrid approach."""

    needs_browser_for = [DataCategory.LICENSES, DataCategory.BUSINESSES]

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="UT",
            name="Utah",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "Utah Department of Commerce - DOPL",
                "Utah Division of Corporations",
            ],
            notes="Business search requires browser automation.",
        )

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """Search Utah DOPL for professional licenses using HTTP."""
        if not params.query and not params.license_number:
            logger.warning("UT DOPL: query or license_number is required")
            return

        form_data = {
            "licenseNumber": params.license_number or "",
            "lastName": "",
            "firstName": "",
            "businessName": "",
        }

        if params.query and not params.license_number:
            parts = params.query.strip().split(maxsplit=1)
            form_data["lastName"] = parts[0]
            if len(parts) > 1:
                form_data["firstName"] = parts[1]

        try:
            response = await self.client.post(UT_LICENSE_URL, data=form_data)
            html = response.text
        except Exception as e:
            logger.error("UT DOPL license search failed: %s", e)
            return

        tree = parse_html(html)
        rows = tree.css("table tr")

        count = 0
        for row in rows:
            if count >= params.max_results:
                break

            cells = row.css("td")
            if len(cells) < 3:
                continue

            name = extract_text(cells[0])
            license_num = extract_text(cells[1]) if len(cells) > 1 else None
            status_text = extract_text(cells[2]) if len(cells) > 2 else None

            if not name or not license_num:
                continue

            status = UT_LICENSE_STATUS_MAP.get(
                (status_text or "").upper().strip(), LicenseStatus.OTHER
            )

            license_obj = License(
                license_number=license_num.strip(),
                license_type="Professional License",
                status=status,
                state="UT",
                holder_name=name.strip(),
                source_url=UT_LICENSE_URL,
                raw_data={"status_text": status_text},
            )

            yield CollectorResult(
                category=DataCategory.LICENSES.value,
                state="UT",
                data=license_obj,
                source="Utah Department of Commerce - DOPL",
            )
            count += 1

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """Search Utah Division of Corporations for business entities using browser."""
        if not params.query:
            logger.warning("UT Corporations: query (business name) is required")
            return

        if not self.has_browser:
            logger.warning("UT Corporations requires browser automation.")
            return

        try:
            page = await self.browser.new_page()
            await page.goto(UT_BUSINESS_URL, wait_until="domcontentloaded", timeout=15000)
            
            # Fill search form
            name_field = await page.query_selector('input[name*="name"], input[id*="name"]')
            if name_field:
                await name_field.fill(params.query)
                
            # Submit search
            search_btn = await page.query_selector('button:has-text("Search"), input[type="submit"]')
            if search_btn:
                await search_btn.click()
                
            await page.wait_for_load_state("domcontentloaded", timeout=15000)
            html = await page.content()
            
            tree = parse_html(html)
            rows = tree.css("table tr")
            
            count = 0
            for row in rows:
                if count >= params.max_results:
                    break
                    
                cells = row.css("td")
                if len(cells) < 2:
                    continue
                    
                name = extract_text(cells[0])
                filing_number = extract_text(cells[1]) if len(cells) > 1 else None
                entity_type_text = extract_text(cells[2]) if len(cells) > 2 else None
                
                if not name:
                    continue
                    
                entity_type = UT_ENTITY_TYPE_MAP.get(
                    (entity_type_text or "").upper().strip(), EntityType.OTHER
                )
                    
                business = Business(
                    name=name.strip(),
                    entity_type=entity_type,
                    status=EntityStatus.ACTIVE,
                    state="UT",
                    filing_number=filing_number,
                    source_url=UT_BUSINESS_URL,
                    raw_data={"entity_type_text": entity_type_text},
                )
                
                yield CollectorResult(
                    category=DataCategory.BUSINESSES.value,
                    state="UT",
                    data=business,
                    source="Utah Division of Corporations",
                )
                count += 1
                
        except Exception as e:
            logger.error("UT Corporations business search failed: %s", e)
        finally:
            await page.close()