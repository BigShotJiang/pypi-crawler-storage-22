"""
Vermont state collector.

Sources:
- Vermont Real Estate Commission (VREC): BLOCKED BY INCAPSULA
  https://sos.vermont.gov/opr/real-estate/license-lookup/ - returns 403 Forbidden
- Vermont Secretary of State: BLOCKED BY INCAPSULA 
  https://bizfilings.vermont.gov/business/businesssearch - returns 403 Forbidden

SCAN RESULTS: All FORBIDDEN (Incapsula security service blocking access)
"""

from __future__ import annotations

import logging
import re
from datetime import date as date_cls, datetime
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.models import (
    Address,
    Business,
    CollectorResult,
    EntityStatus,
    EntityType,
    License,
    LicenseStatus,
    Person,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import (
    clean_text,
    extract_table_rows,
    extract_text,
    parse_address_text,
    parse_html,
)
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

# --- VREC (Real Estate) ---

VREC_SEARCH_URL = "https://sos.vermont.gov/opr/real-estate/license-lookup/"
OPR_SEARCH_URL = "https://sos.vermont.gov/opr/licensee-search/"

VT_LICENSE_STATUS_MAP = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "CURRENT": LicenseStatus.ACTIVE,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
    "SUSPENDED": LicenseStatus.SUSPENDED,
    "REVOKED": LicenseStatus.REVOKED,
    "CANCELLED": LicenseStatus.CANCELLED,
    "PENDING": LicenseStatus.PENDING,
    "LAPSED": LicenseStatus.EXPIRED,
}

# --- Secretary of State (Business Entity) ---

BIZFILE_SEARCH_URL = "https://bizfilings.vermont.gov/business/businesssearch"
BIZFILE_API_URL = "https://bizfilings.vermont.gov/api/FilingSearch"

VT_ENTITY_TYPES = {
    "LIMITED LIABILITY COMPANY": EntityType.LLC,
    "DOMESTIC LLC": EntityType.LLC,
    "FOREIGN LLC": EntityType.LLC,
    "DOMESTIC LIMITED LIABILITY COMPANY": EntityType.LLC,
    "FOREIGN LIMITED LIABILITY COMPANY": EntityType.LLC,
    "CORPORATION": EntityType.CORPORATION,
    "DOMESTIC CORPORATION": EntityType.CORPORATION,
    "DOMESTIC BUSINESS CORPORATION": EntityType.CORPORATION,
    "FOREIGN CORPORATION": EntityType.CORPORATION,
    "FOREIGN BUSINESS CORPORATION": EntityType.CORPORATION,
    "NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "DOMESTIC NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "FOREIGN NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "LIMITED PARTNERSHIP": EntityType.LP,
    "DOMESTIC LIMITED PARTNERSHIP": EntityType.LP,
    "FOREIGN LIMITED PARTNERSHIP": EntityType.LP,
    "GENERAL PARTNERSHIP": EntityType.PARTNERSHIP,
    "LIMITED LIABILITY PARTNERSHIP": EntityType.LLP,
}

VT_STATUS_MAP = {
    "ACTIVE": EntityStatus.ACTIVE,
    "GOOD STANDING": EntityStatus.ACTIVE,
    "ACTIVE/GOOD STANDING": EntityStatus.ACTIVE,
    "INACTIVE": EntityStatus.INACTIVE,
    "DISSOLVED": EntityStatus.DISSOLVED,
    "ADMINISTRATIVELY DISSOLVED": EntityStatus.DISSOLVED,
    "VOLUNTARILY DISSOLVED": EntityStatus.DISSOLVED,
    "REVOKED": EntityStatus.DISSOLVED,
    "EXPIRED": EntityStatus.INACTIVE,
    "SUSPENDED": EntityStatus.SUSPENDED,
    "WITHDRAWN": EntityStatus.WITHDRAWN,
    "MERGED": EntityStatus.MERGED,
    "CONVERTED": EntityStatus.CONVERTED,
    "CANCELLED": EntityStatus.DISSOLVED,
}


@StateRegistry.register
class VermontCollector(BaseStateCollector):
    """Collector for Vermont government data.
    
    Note: Vermont sites are protected by Incapsula security service
    which blocks automated access with 403 Forbidden responses.
    """

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="VT",
            name="Vermont",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "Vermont Office of Professional Regulation (OPR) / Real Estate Commission",
                "Vermont Secretary of State (Business Filings)",
            ],
        )

    # --- Real Estate Licenses ---

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Vermont license search is blocked by Incapsula security service.
        
        All Vermont government websites return 403 Forbidden with Incapsula
        incident IDs, indicating automated access is blocked.
        """
        logger.warning(
            "VT: License search blocked by Incapsula security service. "
            "All Vermont government sites return 403 Forbidden."
        )
        return
        yield  # Make it a generator

    async def _license_search_by_name(
        self, name: str, max_results: int = 100
    ) -> AsyncIterator[CollectorResult]:
        """Search VT OPR by licensee name."""
        parts = name.strip().split(maxsplit=1)
        last_name = parts[0] if parts else name
        first_name = parts[1] if len(parts) > 1 else ""

        form_data = {
            "LastName": last_name,
            "FirstName": first_name,
            "Profession": "Real Estate",
            "Submit": "Search",
        }

        try:
            response = await self.client.post(OPR_SEARCH_URL, data=form_data)
            html = response.text
        except Exception as e:
            logger.error("VT OPR license search failed: %s", e)
            return

        count = 0
        async for result in self._parse_license_results(html):
            yield result
            count += 1
            if count >= max_results:
                return

    async def _license_search_by_number(
        self, license_number: str
    ) -> AsyncIterator[CollectorResult]:
        """Search VT OPR by license number."""
        form_data = {
            "LicenseNumber": license_number,
            "Profession": "Real Estate",
            "Submit": "Search",
        }

        try:
            response = await self.client.post(OPR_SEARCH_URL, data=form_data)
            html = response.text
        except Exception as e:
            logger.error("VT OPR license lookup failed: %s", e)
            return

        async for result in self._parse_license_results(html):
            yield result

    async def _parse_license_results(
        self, html: str
    ) -> AsyncIterator[CollectorResult]:
        """Parse VT OPR license search results page."""
        tree = parse_html(html)
        rows = tree.css("table tr")

        if not rows:
            logger.debug("No VT license results found")
            return

        for row in rows:
            cells = row.css("td")
            if len(cells) < 4:
                continue

            name_text = extract_text(cells[0])
            license_id = extract_text(cells[1])
            license_type_text = extract_text(cells[2])
            status_text = extract_text(cells[3])
            expiry_text = extract_text(cells[4]) if len(cells) > 4 else None

            if not name_text or not license_id:
                continue

            status = LicenseStatus.OTHER
            if status_text:
                status_upper = status_text.upper().strip()
                status = VT_LICENSE_STATUS_MAP.get(
                    status_upper, LicenseStatus.OTHER
                )

            expiration_date = None
            if expiry_text:
                for fmt in ("%m/%d/%Y", "%Y-%m-%d"):
                    try:
                        expiration_date = datetime.strptime(
                            expiry_text.strip(), fmt
                        ).date()
                        break
                    except (ValueError, AttributeError):
                        continue

            license_obj = License(
                license_number=license_id.strip(),
                license_type=license_type_text or "Real Estate",
                status=status,
                state="VT",
                holder_name=name_text.strip(),
                expiration_date=expiration_date,
                source_url=OPR_SEARCH_URL,
                raw_data={
                    "name": name_text,
                    "license_type": license_type_text,
                    "status_text": status_text,
                    "expiry_text": expiry_text,
                },
            )

            yield CollectorResult(
                category=DataCategory.LICENSES.value,
                state="VT",
                data=license_obj,
                source="Vermont Office of Professional Regulation",
            )

    # --- Business Entity Search ---

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Vermont business search is blocked by Incapsula security service.
        
        All Vermont government websites return 403 Forbidden with Incapsula
        incident IDs, indicating automated access is blocked.
        """
        logger.warning(
            "VT: Business search blocked by Incapsula security service. "
            "All Vermont government sites return 403 Forbidden."
        )
        return
        yield  # Make it a generator

    def _parse_business_record(self, record: dict) -> Business | None:
        """Parse a single VT bizfilings API record into a Business model."""
        name = (
            record.get("BusinessName")
            or record.get("businessName")
            or record.get("EntityName")
        )
        if not name:
            return None

        type_str = (
            record.get("EntityType") or record.get("entityType") or ""
        ).upper()
        entity_type = VT_ENTITY_TYPES.get(type_str, EntityType.OTHER)

        status_str = (record.get("Status") or record.get("status") or "").upper()
        status = VT_STATUS_MAP.get(status_str, EntityStatus.OTHER)

        filing_number = (
            record.get("BusinessID")
            or record.get("businessId")
            or record.get("FilingNumber")
        )

        formation_date = None
        date_str = record.get("FilingDate") or record.get("formationDate")
        if date_str:
            for fmt in ("%m/%d/%Y", "%Y-%m-%d"):
                try:
                    formation_date = datetime.strptime(
                        date_str.strip(), fmt
                    ).date()
                    break
                except (ValueError, AttributeError):
                    continue

        agent_name = record.get("RegisteredAgent") or record.get("registeredAgent")
        agent = Person(full_name=agent_name) if agent_name else None

        address = None
        addr_str = (
            record.get("PrincipalAddress")
            or record.get("principalAddress")
            or record.get("address")
        )
        if addr_str:
            address = parse_address_text(addr_str)

        return Business(
            name=name.strip(),
            entity_type=entity_type,
            status=status,
            state="VT",
            filing_number=filing_number,
            formation_date=formation_date,
            address=address,
            registered_agent=agent,
            source_url=BIZFILE_SEARCH_URL,
            raw_data=record,
        )
