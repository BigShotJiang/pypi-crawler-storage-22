"""
Virginia state collector.

Sources:
- DPOR (Department of Professional and Occupational Regulation): License lookups
  https://www.dpor.virginia.gov/LicenseLookup
  The page embeds an iframe pointing to:
    https://dporweb.dpor.virginia.gov/LicenseLookup/
  We navigate directly to the iframe URL for reliability.

- SCC (State Corporation Commission): Business entity search
  NOTE: cis.scc.virginia.gov has SSL errors as of Feb 2026. Disabled.
"""

from __future__ import annotations

import asyncio
import logging
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.models import (
    Business,
    CollectorResult,
    EntityStatus,
    License,
    LicenseStatus,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import clean_text, parse_html  # noqa: F401
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

# Main DPOR page (embeds the lookup in an iframe)
DPOR_SEARCH_URL = "https://www.dpor.virginia.gov/LicenseLookup"
# Direct iframe URL — navigate here for the actual search form
DPOR_IFRAME_URL = "https://dporweb.dpor.virginia.gov/LicenseLookup/"

# NOTE: cis.scc.virginia.gov has SSL errors as of Feb 2026. Disabled.
SCC_SEARCH_URL = "https://cis.scc.virginia.gov/EntitySearch/Index"

STATUS_MAP = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "CURRENT": LicenseStatus.ACTIVE,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
    "REVOKED": LicenseStatus.REVOKED,
    "SUSPENDED": LicenseStatus.SUSPENDED,
    "CANCELLED": LicenseStatus.CANCELLED,
}

ENTITY_STATUS_MAP = {
    "ACTIVE": EntityStatus.ACTIVE,
    "GOOD STANDING": EntityStatus.ACTIVE,
    "INACTIVE": EntityStatus.INACTIVE,
    "DISSOLVED": EntityStatus.DISSOLVED,
    "SUSPENDED": EntityStatus.SUSPENDED,
    "WITHDRAWN": EntityStatus.WITHDRAWN,
    "MERGED": EntityStatus.MERGED,
}


@StateRegistry.register
class VirginiaCollector(BaseStateCollector):
    """Collector for Virginia government data using browser automation."""

    needs_browser_for = [DataCategory.LICENSES]

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="VA",
            name="Virginia",
            supported_categories=[
                DataCategory.LICENSES.value,
            ],
            sources=[
                "Virginia DPOR (Department of Professional & Occupational Regulation)",
            ],
            notes=(
                "License lookup uses browser automation (iframe at dporweb.dpor.virginia.gov). "
                "Business search disabled — cis.scc.virginia.gov has SSL errors as of Feb 2026."
            ),
        )

    # ------------------------------------------------------------------ #
    #  License Lookup (DPOR)
    # ------------------------------------------------------------------ #

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Virginia DPOR professional license search.

        The main DPOR page embeds an <iframe> pointing to
        dporweb.dpor.virginia.gov/LicenseLookup/. We navigate directly
        to the iframe URL to interact with the search form.
        """
        query = params.query
        if not query:
            logger.warning("VA DPOR: query is required")
            return

        if not self.has_browser:
            logger.warning(
                "VA DPOR requires browser automation. "
                "Use use_camoufox=True."
            )
            return

        page = await self.browser.new_page()
        count = 0
        max_results = params.max_results

        try:
            # Navigate directly to the iframe URL
            await page.goto(
                DPOR_IFRAME_URL,
                wait_until="domcontentloaded",
                timeout=20000,
            )
            await asyncio.sleep(2)

            # The iframe has:
            #   input#search-text (placeholder="Search here...")
            #   input#phone-number (HONEYPOT — do NOT fill)
            #   input[type="submit"] / button "Search"
            search_sel = 'input#search-text'
            await page.wait_for_selector(search_sel, timeout=10000)
            await page.fill(search_sel, query)
            await asyncio.sleep(0.3)

            await page.click('input[type="submit"]')

            # Wait for DataTables to populate #search-results
            try:
                await page.wait_for_selector(
                    "#search-results tbody tr", timeout=15000
                )
            except Exception:
                pass
            await asyncio.sleep(2)

            # Extract table data via JS (DataTables renders rows in DOM).
            # Columns: License Number | Name | Address | License Type | Board
            # The first <td> contains a form with a honeypot + hidden
            # input[name="license-number"]. Use td[data-search] or the
            # hidden input's value for the actual license number.
            raw_rows = await page.evaluate("""() => {
                const rows = document.querySelectorAll('#search-results tbody tr');
                return Array.from(rows).map(row => {
                    const cells = row.querySelectorAll('td');
                    const firstTd = cells[0];
                    // License number from data attribute or hidden input
                    const licNum = firstTd
                        ? (firstTd.getAttribute('data-search')
                           || (firstTd.querySelector('input[name="license-number"]') || {}).value
                           || '')
                        : '';
                    return [
                        licNum,
                        ...Array.from(cells).slice(1).map(c => c.innerText.trim())
                    ];
                });
            }""")

            for cells in raw_rows:
                if count >= max_results:
                    break
                if len(cells) < 4:
                    continue

                license_number = cells[0]
                holder_name = cells[1]
                address_text = cells[2] if len(cells) > 2 else ""
                license_type = cells[3] if len(cells) > 3 else "Professional License"
                board = cells[4] if len(cells) > 4 else ""

                if not holder_name or not license_number:
                    continue

                # Skip header-like rows
                if "license number" in license_number.lower():
                    continue

                lic = License(
                    license_number=license_number,
                    license_type=license_type or "Professional License",
                    status=LicenseStatus.OTHER,  # status not in search results
                    state="VA",
                    holder_name=holder_name,
                    source_url=DPOR_IFRAME_URL,
                    raw_data={
                        "address": address_text,
                        "board": board,
                    },
                )

                yield CollectorResult(
                    category="licenses",
                    state="VA",
                    data=lic,
                    source="Virginia DPOR",
                )
                count += 1

            logger.info("VA DPOR: returned %d license results", count)

        except Exception as e:
            logger.error("VA DPOR license search failed: %s", e)
        finally:
            await page.close()

    # ------------------------------------------------------------------ #
    #  Business Entity Search (DISABLED)
    # ------------------------------------------------------------------ #

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Virginia SCC business entity search.

        NOTE: cis.scc.virginia.gov has SSL errors as of Feb 2026.
        This method is disabled.
        """
        logger.warning(
            "VA business search disabled: cis.scc.virginia.gov "
            "has SSL errors as of Feb 2026."
        )
        return
        yield  # type: ignore[misc]
