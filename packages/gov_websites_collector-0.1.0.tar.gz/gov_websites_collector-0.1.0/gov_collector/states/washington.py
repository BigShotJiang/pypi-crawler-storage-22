"""
Washington state collector.

Sources:
- DOL (Department of Licensing): Real estate license lookups
  https://fortress.wa.gov/dol/dolprod/bpdLicenseQuery.asp
- Secretary of State (CCFS): Business entity search
  https://ccfs.sos.wa.gov/#/AdvancedSearch

Note: Washington's business entity search (CCFS) is a JavaScript SPA
(Single Page Application). The frontend makes API calls to backend
endpoints. We target those API endpoints directly rather than trying
to render the SPA.

Known CCFS API endpoints:
- Search: POST https://ccfs.sos.wa.gov/api/BusinessSearch
- Detail: GET  https://ccfs.sos.wa.gov/api/BusinessSearch/{UBI}
"""

from __future__ import annotations

import logging
import re
from datetime import date as date_cls, datetime
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.models import (
    Address,
    Business,
    CollectorResult,
    EntityStatus,
    EntityType,
    License,
    LicenseStatus,
    Person,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import (
    clean_text,
    extract_table_rows,
    extract_text,
    parse_address_text,
    parse_html,
)
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

# --- DOL (Real Estate) ---

DOL_SEARCH_URL = "https://fortress.wa.gov/dol/dolprod/bpdLicenseQuery.asp"

WA_LICENSE_STATUS_MAP = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "CURRENT": LicenseStatus.ACTIVE,
    "LICENSED": LicenseStatus.ACTIVE,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
    "SUSPENDED": LicenseStatus.SUSPENDED,
    "REVOKED": LicenseStatus.REVOKED,
    "CANCELLED": LicenseStatus.CANCELLED,
    "PENDING": LicenseStatus.PENDING,
    "SURRENDERED": LicenseStatus.CANCELLED,
}

# --- Secretary of State CCFS (Business Entity) ---
# CCFS = Corporations and Charities Filing System
# This is a JavaScript SPA — we target the underlying API endpoints.

CCFS_SEARCH_URL = "https://ccfs.sos.wa.gov/#/AdvancedSearch"
CCFS_API_SEARCH_URL = "https://ccfs.sos.wa.gov/api/BusinessSearch"
CCFS_API_DETAIL_URL = "https://ccfs.sos.wa.gov/api/BusinessSearch"

WA_ENTITY_TYPES = {
    "LIMITED LIABILITY COMPANY": EntityType.LLC,
    "WA LIMITED LIABILITY COMPANY": EntityType.LLC,
    "FOREIGN LIMITED LIABILITY COMPANY": EntityType.LLC,
    "PROFIT CORPORATION": EntityType.CORPORATION,
    "WA PROFIT CORPORATION": EntityType.CORPORATION,
    "FOREIGN PROFIT CORPORATION": EntityType.CORPORATION,
    "CORPORATION": EntityType.CORPORATION,
    "DOMESTIC CORPORATION": EntityType.CORPORATION,
    "FOREIGN CORPORATION": EntityType.CORPORATION,
    "NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "WA NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "FOREIGN NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "LIMITED PARTNERSHIP": EntityType.LP,
    "WA LIMITED PARTNERSHIP": EntityType.LP,
    "FOREIGN LIMITED PARTNERSHIP": EntityType.LP,
    "GENERAL PARTNERSHIP": EntityType.PARTNERSHIP,
    "LIMITED LIABILITY PARTNERSHIP": EntityType.LLP,
    "WA LIMITED LIABILITY PARTNERSHIP": EntityType.LLP,
}

WA_STATUS_MAP = {
    "ACTIVE": EntityStatus.ACTIVE,
    "OPEN": EntityStatus.ACTIVE,
    "INACTIVE": EntityStatus.INACTIVE,
    "DISSOLVED": EntityStatus.DISSOLVED,
    "ADMINISTRATIVELY DISSOLVED": EntityStatus.DISSOLVED,
    "VOLUNTARILY DISSOLVED": EntityStatus.DISSOLVED,
    "EXPIRED": EntityStatus.INACTIVE,
    "DELINQUENT": EntityStatus.SUSPENDED,
    "SUSPENDED": EntityStatus.SUSPENDED,
    "WITHDRAWN": EntityStatus.WITHDRAWN,
    "MERGED": EntityStatus.MERGED,
    "CONVERTED": EntityStatus.CONVERTED,
    "REVOKED": EntityStatus.DISSOLVED,
    "CANCELLED": EntityStatus.DISSOLVED,
}


@StateRegistry.register
class WashingtonCollector(BaseStateCollector):
    """Collector for Washington state government data."""

    needs_browser_for = [DataCategory.LICENSES, DataCategory.BUSINESSES]

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="WA",
            name="Washington",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "Washington Department of Licensing (DOL)",
                "Washington Secretary of State (CCFS — Corporations and Charities Filing System)",
            ],
            notes=(
                "Business entity search (CCFS) is a JavaScript SPA. "
                "This collector targets the underlying REST API at "
                "ccfs.sos.wa.gov/api/BusinessSearch."
            ),
        )

    # --- Real Estate Licenses ---

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search Washington DOL for real estate licenses.

        WARNING: The DOL search URL returns 404 errors as of 2026-02-16.
        This method requires browser automation to work properly.
        """
        logger.warning(
            "WA DOL license search requires browser automation. "
            "The fortress.wa.gov URL is returning 404 errors."
        )
        return
        if params.license_number:
            async for result in self._license_search_by_number(params.license_number):
                yield result
            return

        if not params.query:
            raise ValueError(
                "Either 'query' (name) or 'license_number' is required for WA license search"
            )

        async for result in self._license_search_by_name(
            params.query, params.max_results
        ):
            yield result

    async def _license_search_by_name(
        self, name: str, max_results: int = 100
    ) -> AsyncIterator[CollectorResult]:
        """Search WA DOL by licensee name."""
        parts = name.strip().split(maxsplit=1)
        last_name = parts[0] if parts else name
        first_name = parts[1] if len(parts) > 1 else ""

        form_data = {
            "LastName": last_name,
            "FirstName": first_name,
            "LicType": "RE",  # Real Estate
            "Submit": "Search",
        }

        try:
            response = await self.client.post(DOL_SEARCH_URL, data=form_data)
            html = response.text
        except Exception as e:
            logger.error("WA DOL license search failed: %s", e)
            return

        count = 0
        async for result in self._parse_license_results(html):
            yield result
            count += 1
            if count >= max_results:
                return

    async def _license_search_by_number(
        self, license_number: str
    ) -> AsyncIterator[CollectorResult]:
        """Search WA DOL by license number."""
        form_data = {
            "LicenseNo": license_number,
            "LicType": "RE",
            "Submit": "Search",
        }

        try:
            response = await self.client.post(DOL_SEARCH_URL, data=form_data)
            html = response.text
        except Exception as e:
            logger.error("WA DOL license lookup failed: %s", e)
            return

        async for result in self._parse_license_results(html):
            yield result

    async def _parse_license_results(
        self, html: str
    ) -> AsyncIterator[CollectorResult]:
        """Parse WA DOL license search results page."""
        tree = parse_html(html)
        rows = tree.css("table tr")

        if not rows:
            logger.debug("No WA license results found")
            return

        for row in rows:
            cells = row.css("td")
            if len(cells) < 4:
                continue

            name_text = extract_text(cells[0])
            license_id = extract_text(cells[1])
            license_type_text = extract_text(cells[2])
            status_text = extract_text(cells[3])
            expiry_text = extract_text(cells[4]) if len(cells) > 4 else None
            address_text = extract_text(cells[5]) if len(cells) > 5 else None

            if not name_text or not license_id:
                continue

            status = LicenseStatus.OTHER
            if status_text:
                status_upper = status_text.upper().strip()
                status = WA_LICENSE_STATUS_MAP.get(
                    status_upper, LicenseStatus.OTHER
                )

            expiration_date = None
            if expiry_text:
                for fmt in ("%m/%d/%Y", "%Y-%m-%d"):
                    try:
                        expiration_date = datetime.strptime(
                            expiry_text.strip(), fmt
                        ).date()
                        break
                    except (ValueError, AttributeError):
                        continue

            address = None
            if address_text:
                address = Address(raw=address_text, state="WA")

            license_obj = License(
                license_number=license_id.strip(),
                license_type=license_type_text or "Real Estate",
                status=status,
                state="WA",
                holder_name=name_text.strip(),
                expiration_date=expiration_date,
                address=address,
                source_url=DOL_SEARCH_URL,
                raw_data={
                    "name": name_text,
                    "license_type": license_type_text,
                    "status_text": status_text,
                    "expiry_text": expiry_text,
                },
            )

            yield CollectorResult(
                category=DataCategory.LICENSES.value,
                state="WA",
                data=license_obj,
                source="Washington Department of Licensing",
            )

    # --- Business Entity Search (CCFS API) ---

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search Washington Secretary of State for business entities.

        Uses browser automation to interact with the JavaScript SPA.
        """
        if not params.query:
            logger.warning("WA business search: query is required")
            return

        if not self.has_browser:
            logger.warning(
                "WA business search requires browser automation. "
                "Initialize with use_browser=True."
            )
            return

        try:
            page = await self.browser.new_page()
        except Exception as e:
            logger.error("WA business search: failed to create browser page: %s", e)
            return

        count = 0
        max_results = params.max_results

        try:
            await page.goto(
                "https://ccfs.sos.wa.gov/#/BusinessSearch/BusinessInformation",
                wait_until="domcontentloaded",
                timeout=15000,
            )

            # Wait for the SPA to load
            await asyncio.sleep(3)

            # Try to find search input
            search_selectors = [
                'input[placeholder*="business name"]',
                'input[placeholder*="entity name"]', 
                'input[name*="search"]',
                'input[id*="search"]',
                'input[type="text"]'
            ]
            
            search_input = None
            for selector in search_selectors:
                try:
                    await page.wait_for_selector(selector, timeout=5000)
                    search_input = await page.query_selector(selector)
                    if search_input:
                        break
                except:
                    continue

            if search_input:
                await page.fill(selector, params.query)
                
                # Try to find and click search button
                search_button_selectors = [
                    'button:has-text("Search")',
                    'input[type="submit"]',
                    'button[type="submit"]',
                    'button:has-text("Find")',
                    '[role="button"]:has-text("Search")'
                ]
                
                for btn_selector in search_button_selectors:
                    try:
                        await page.click(btn_selector)
                        break
                    except:
                        continue
                else:
                    # Fallback: Enter key
                    await page.keyboard.press('Enter')

                # Wait for results
                await page.wait_for_load_state('domcontentloaded', timeout=15000)
                await asyncio.sleep(3)  # Allow SPA to render results

                html = await page.content()
                tree = parse_html(html)

                # Try to find results in various table structures
                table_selectors = [
                    'table tr',
                    '.results tr',
                    '.search-results tr',
                    '[class*="result"] tr',
                    '.entity-list tr',
                    '.business-list tr'
                ]
                
                results_found = False
                for table_selector in table_selectors:
                    rows = tree.css(table_selector)
                    if len(rows) > 1:  # Header + data rows
                        for row in rows[1:]:  # Skip header
                            if count >= max_results:
                                break
                            
                            cells = row.css('td, th')
                            if len(cells) >= 2:
                                name = clean_text(cells[0].text(deep=True))
                                if name and name.lower() not in ['name', 'entity name', 'business name']:
                                    # Extract other fields
                                    entity_type = EntityType.OTHER
                                    status = EntityStatus.OTHER
                                    filing_number = None
                                    
                                    if len(cells) > 1:
                                        type_text = clean_text(cells[1].text(deep=True))
                                        if type_text:
                                            entity_type = WA_ENTITY_TYPES.get(type_text.upper(), EntityType.OTHER)
                                    
                                    if len(cells) > 2:
                                        status_text = clean_text(cells[2].text(deep=True))
                                        if status_text:
                                            status = WA_STATUS_MAP.get(status_text.upper(), EntityStatus.OTHER)
                                    
                                    if len(cells) > 3:
                                        filing_number = clean_text(cells[3].text(deep=True))

                                    biz = Business(
                                        name=name,
                                        entity_type=entity_type,
                                        status=status,
                                        state="WA",
                                        filing_number=filing_number,
                                        source_url="https://ccfs.sos.wa.gov/#/BusinessSearch/BusinessInformation",
                                        raw_data={
                                            "type_text": type_text,
                                            "status_text": status_text,
                                        },
                                    )

                                    yield CollectorResult(
                                        category="businesses",
                                        state="WA",
                                        data=biz,
                                        source="Washington Secretary of State (CCFS)",
                                    )
                                    count += 1
                                    results_found = True
                        
                        if results_found:
                            break
                
                if not results_found:
                    logger.info("WA business search: no results found for query '%s'", params.query)
            
            else:
                logger.error("WA business search: could not find search input field")

        except Exception as e:
            logger.error("WA business search: failed: %s", e)
        finally:
            await page.close()
            
        return
        if not params.query:
            raise ValueError(
                "'query' (business name) is required for WA business search"
            )

        # Target the CCFS REST API directly
        search_payload = {
            "BusinessName": params.query,
            "SearchType": "Contains",
            "State": "",
            "City": params.city or "",
        }

        try:
            response = await self.client.post(
                CCFS_API_SEARCH_URL,
                json=search_payload,
                headers={
                    "Content-Type": "application/json",
                    "Accept": "application/json",
                },
            )
            data = response.json()
        except Exception as e:
            logger.error("WA CCFS API business search failed: %s", e)
            return

        results = data if isinstance(data, list) else data.get("results", data.get("Results", []))

        count = 0
        for record in results:
            if count >= params.max_results:
                return

            business = self._parse_ccfs_record(record)
            if business:
                yield CollectorResult(
                    category=DataCategory.BUSINESSES.value,
                    state="WA",
                    data=business,
                    source="Washington Secretary of State (CCFS)",
                )
                count += 1

    def _parse_ccfs_record(self, record: dict) -> Business | None:
        """Parse a single CCFS API record into a Business model."""
        name = (
            record.get("BusinessName")
            or record.get("businessName")
            or record.get("EntityName")
        )
        if not name:
            return None

        type_str = (
            record.get("BusinessType")
            or record.get("EntityType")
            or record.get("businessType")
            or ""
        ).upper()
        entity_type = WA_ENTITY_TYPES.get(type_str, EntityType.OTHER)

        status_str = (
            record.get("Status") or record.get("status") or ""
        ).upper()
        status = WA_STATUS_MAP.get(status_str, EntityStatus.OTHER)

        # Washington uses UBI (Unified Business Identifier)
        filing_number = (
            record.get("UBI")
            or record.get("ubi")
            or record.get("BusinessID")
            or record.get("EntityNumber")
        )

        formation_date = None
        date_str = (
            record.get("IncorporationDate")
            or record.get("FormationDate")
            or record.get("FilingDate")
            or record.get("incorporationDate")
        )
        if date_str:
            for fmt in ("%m/%d/%Y", "%Y-%m-%d", "%Y-%m-%dT%H:%M:%S"):
                try:
                    formation_date = datetime.strptime(
                        date_str.strip().split("T")[0] if "T" in date_str else date_str.strip(),
                        fmt.split("T")[0] if "T" in fmt else fmt,
                    ).date()
                    break
                except (ValueError, AttributeError):
                    continue

        agent_name = (
            record.get("AgentName")
            or record.get("RegisteredAgent")
            or record.get("agentName")
        )
        agent = Person(full_name=agent_name) if agent_name else None

        address = None
        addr_parts = []
        for key in ("PrincipalAddress", "Address", "principalAddress"):
            if record.get(key):
                addr_parts.append(record[key])
                break

        # Some records have structured address fields
        if not addr_parts:
            street = record.get("Street") or record.get("street") or ""
            city = record.get("City") or record.get("city") or ""
            state = record.get("State") or record.get("state") or "WA"
            zip_code = record.get("Zip") or record.get("zip") or ""
            if street or city:
                address = Address(
                    street=street or None,
                    city=city or None,
                    state=state,
                    zip_code=zip_code or None,
                )
        elif addr_parts:
            address = parse_address_text(addr_parts[0])

        expiration_date = None
        exp_str = record.get("ExpirationDate") or record.get("expirationDate")
        if exp_str:
            for fmt in ("%m/%d/%Y", "%Y-%m-%d"):
                try:
                    expiration_date = datetime.strptime(
                        exp_str.strip(), fmt
                    ).date()
                    break
                except (ValueError, AttributeError):
                    continue

        return Business(
            name=name.strip(),
            entity_type=entity_type,
            status=status,
            state="WA",
            filing_number=filing_number,
            formation_date=formation_date,
            expiration_date=expiration_date,
            address=address,
            registered_agent=agent,
            source_url=CCFS_SEARCH_URL,
            raw_data=record,
        )
