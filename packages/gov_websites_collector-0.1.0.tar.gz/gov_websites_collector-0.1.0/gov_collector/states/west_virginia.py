"""
West Virginia state collector.

Sources:
- WVREC (West Virginia Real Estate Commission): Real estate license lookups
  https://www.wvrec.org/licensing/verify-a-license/
- Secretary of State: Business entity search
  https://apps.wv.gov/SOS/BusinessEntitySearch/
"""

from __future__ import annotations

import logging
import re
from datetime import date as date_cls, datetime
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.models import (
    Address,
    Business,
    CollectorResult,
    EntityStatus,
    EntityType,
    License,
    LicenseStatus,
    Person,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import (
    clean_text,
    extract_table_rows,
    extract_text,
    parse_address_text,
    parse_html,
)
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

# --- WVREC (Real Estate) ---

WVREC_SEARCH_URL = "https://www.wvrec.org/licensing/verify-a-license/"
WVREC_RESULTS_URL = "https://www.wvrec.org/licensing/verify-a-license/"

WV_LICENSE_STATUS_MAP = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "CURRENT": LicenseStatus.ACTIVE,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
    "SUSPENDED": LicenseStatus.SUSPENDED,
    "REVOKED": LicenseStatus.REVOKED,
    "CANCELLED": LicenseStatus.CANCELLED,
    "PENDING": LicenseStatus.PENDING,
    "SURRENDERED": LicenseStatus.CANCELLED,
}

# --- Secretary of State (Business Entity) ---

SOS_SEARCH_URL = "https://apps.wv.gov/SOS/BusinessEntitySearch/"
SOS_API_URL = "https://apps.wv.gov/SOS/BusinessEntitySearch/api/Search"

WV_ENTITY_TYPES = {
    "LIMITED LIABILITY COMPANY": EntityType.LLC,
    "DOMESTIC LLC": EntityType.LLC,
    "FOREIGN LLC": EntityType.LLC,
    "DOMESTIC LIMITED LIABILITY COMPANY": EntityType.LLC,
    "FOREIGN LIMITED LIABILITY COMPANY": EntityType.LLC,
    "CORPORATION": EntityType.CORPORATION,
    "DOMESTIC CORPORATION": EntityType.CORPORATION,
    "DOMESTIC PROFIT CORPORATION": EntityType.CORPORATION,
    "FOREIGN CORPORATION": EntityType.CORPORATION,
    "FOREIGN PROFIT CORPORATION": EntityType.CORPORATION,
    "NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "DOMESTIC NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "FOREIGN NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "LIMITED PARTNERSHIP": EntityType.LP,
    "DOMESTIC LIMITED PARTNERSHIP": EntityType.LP,
    "FOREIGN LIMITED PARTNERSHIP": EntityType.LP,
    "GENERAL PARTNERSHIP": EntityType.PARTNERSHIP,
    "LIMITED LIABILITY PARTNERSHIP": EntityType.LLP,
    "DOMESTIC LIMITED LIABILITY PARTNERSHIP": EntityType.LLP,
    "FOREIGN LIMITED LIABILITY PARTNERSHIP": EntityType.LLP,
}

WV_STATUS_MAP = {
    "ACTIVE": EntityStatus.ACTIVE,
    "ACTIVE/GOOD STANDING": EntityStatus.ACTIVE,
    "GOOD STANDING": EntityStatus.ACTIVE,
    "INACTIVE": EntityStatus.INACTIVE,
    "DISSOLVED": EntityStatus.DISSOLVED,
    "ADMINISTRATIVELY DISSOLVED": EntityStatus.DISSOLVED,
    "VOLUNTARILY DISSOLVED": EntityStatus.DISSOLVED,
    "REVOKED": EntityStatus.DISSOLVED,
    "CANCELLED": EntityStatus.DISSOLVED,
    "SUSPENDED": EntityStatus.SUSPENDED,
    "WITHDRAWN": EntityStatus.WITHDRAWN,
    "MERGED": EntityStatus.MERGED,
    "CONVERTED": EntityStatus.CONVERTED,
}


@StateRegistry.register
class WestVirginiaCollector(BaseStateCollector):
    """Collector for West Virginia government data."""

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="WV",
            name="West Virginia",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            notes="SOS business search uses reCAPTCHA v3 (needs browser). WVREC may return 403.",
            sources=[
                "West Virginia Real Estate Commission (WVREC)",
                "West Virginia Secretary of State (Business Entity Search)",
            ],
        )

    # --- Real Estate Licenses ---

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search WV Real Estate Commission for license verification.

        WARNING: WVREC license verification page may be down (502 Bad Gateway).
        """
        logger.warning(
            "WV Real Estate Commission website may be experiencing issues (502 Bad Gateway errors reported). "
            "License searches may fail."
        )

        if params.license_number:
            async for result in self._license_search_by_number(params.license_number):
                yield result
            return

        if not params.query:
            raise ValueError(
                "Either 'query' (name) or 'license_number' is required for WV license search"
            )

        async for result in self._license_search_by_name(
            params.query, params.max_results
        ):
            yield result

    async def _license_search_by_name(
        self, name: str, max_results: int = 100
    ) -> AsyncIterator[CollectorResult]:
        """Search WVREC by licensee name."""
        parts = name.strip().split(maxsplit=1)
        last_name = parts[0] if parts else name
        first_name = parts[1] if len(parts) > 1 else ""

        form_data = {
            "lastName": last_name,
            "firstName": first_name,
            "searchType": "name",
        }

        try:
            response = await self.client.post(WVREC_RESULTS_URL, data=form_data)
            html = response.text
        except Exception as e:
            logger.error("WV WVREC license search failed: %s", e)
            return

        count = 0
        async for result in self._parse_license_results(html):
            yield result
            count += 1
            if count >= max_results:
                return

    async def _license_search_by_number(
        self, license_number: str
    ) -> AsyncIterator[CollectorResult]:
        """Search WVREC by license number."""
        form_data = {
            "licenseNumber": license_number,
            "searchType": "licenseNumber",
        }

        try:
            response = await self.client.post(WVREC_RESULTS_URL, data=form_data)
            html = response.text
        except Exception as e:
            logger.error("WV WVREC license lookup failed: %s", e)
            return

        async for result in self._parse_license_results(html):
            yield result

    async def _parse_license_results(
        self, html: str
    ) -> AsyncIterator[CollectorResult]:
        """Parse WVREC license search results."""
        tree = parse_html(html)
        rows = tree.css("table tr")

        if not rows:
            logger.debug("No WV license results found")
            return

        for row in rows:
            cells = row.css("td")
            if len(cells) < 4:
                continue

            name_text = extract_text(cells[0])
            license_id = extract_text(cells[1])
            license_type_text = extract_text(cells[2])
            status_text = extract_text(cells[3])
            expiry_text = extract_text(cells[4]) if len(cells) > 4 else None

            if not name_text or not license_id:
                continue

            status = LicenseStatus.OTHER
            if status_text:
                status_upper = status_text.upper().strip()
                status = WV_LICENSE_STATUS_MAP.get(
                    status_upper, LicenseStatus.OTHER
                )

            expiration_date = None
            if expiry_text:
                for fmt in ("%m/%d/%Y", "%Y-%m-%d"):
                    try:
                        expiration_date = datetime.strptime(
                            expiry_text.strip(), fmt
                        ).date()
                        break
                    except (ValueError, AttributeError):
                        continue

            license_obj = License(
                license_number=license_id.strip(),
                license_type=license_type_text or "Real Estate",
                status=status,
                state="WV",
                holder_name=name_text.strip(),
                expiration_date=expiration_date,
                source_url=WVREC_SEARCH_URL,
                raw_data={
                    "name": name_text,
                    "license_type": license_type_text,
                    "status_text": status_text,
                    "expiry_text": expiry_text,
                },
            )

            yield CollectorResult(
                category=DataCategory.LICENSES.value,
                state="WV",
                data=license_obj,
                source="West Virginia Real Estate Commission",
            )

    # --- Business Entity Search ---

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search West Virginia Secretary of State for business entities.

        Uses the apps.wv.gov business entity search system.
        """
        if not params.query:
            raise ValueError(
                "'query' (business name) is required for WV business search"
            )

        # Try the API endpoint
        search_payload = {
            "searchTerm": params.query,
            "searchType": "BusinessName",
        }

        try:
            response = await self.client.post(
                SOS_API_URL,
                json=search_payload,
                headers={"Content-Type": "application/json"},
            )
            if response.status_code == 200:
                data = response.json()
                results = (
                    data
                    if isinstance(data, list)
                    else data.get("results", data.get("Results", []))
                )
                count = 0
                for record in results:
                    if count >= params.max_results:
                        return
                    business = self._parse_business_record(record)
                    if business:
                        yield CollectorResult(
                            category=DataCategory.BUSINESSES.value,
                            state="WV",
                            data=business,
                            source="West Virginia Secretary of State",
                        )
                        count += 1
                return
        except Exception as e:
            logger.debug(
                "WV SOS API attempt failed, falling back to HTML: %s", e
            )

        # Fallback: HTML scraping
        try:
            response = await self.client.get(
                SOS_SEARCH_URL, params={"q": params.query}
            )
            html = response.text
        except Exception as e:
            logger.error("WV SOS business search failed: %s", e)
            return

        rows = extract_table_rows(html, table_selector="table")
        count = 0
        for row in rows:
            if count >= params.max_results:
                return

            name = (
                row.get("Entity Name")
                or row.get("Business Name")
                or row.get("Name", "")
            )
            if not name:
                continue

            entity_type_str = (
                row.get("Entity Type") or row.get("Type") or ""
            ).upper()
            entity_type = WV_ENTITY_TYPES.get(entity_type_str, EntityType.OTHER)

            status_str = (row.get("Status") or "").upper()
            entity_status = WV_STATUS_MAP.get(status_str, EntityStatus.OTHER)

            filing_number = (
                row.get("Charter Number")
                or row.get("Filing Number")
                or row.get("Entity ID")
            )

            formation_date = None
            date_str = (
                row.get("Formation Date")
                or row.get("Filing Date")
                or row.get("Organization Date")
            )
            if date_str:
                for fmt in ("%m/%d/%Y", "%Y-%m-%d"):
                    try:
                        formation_date = datetime.strptime(
                            date_str.strip(), fmt
                        ).date()
                        break
                    except (ValueError, AttributeError):
                        continue

            agent_name = row.get("Registered Agent")
            agent = Person(full_name=agent_name) if agent_name else None

            business = Business(
                name=name.strip(),
                entity_type=entity_type,
                status=entity_status,
                state="WV",
                filing_number=filing_number,
                formation_date=formation_date,
                registered_agent=agent,
                source_url=SOS_SEARCH_URL,
                raw_data=row,
            )

            yield CollectorResult(
                category=DataCategory.BUSINESSES.value,
                state="WV",
                data=business,
                source="West Virginia Secretary of State",
            )
            count += 1

    def _parse_business_record(self, record: dict) -> Business | None:
        """Parse a single WV SOS API record into a Business model."""
        name = (
            record.get("EntityName")
            or record.get("entityName")
            or record.get("BusinessName")
            or record.get("name")
        )
        if not name:
            return None

        type_str = (
            record.get("EntityType") or record.get("entityType") or ""
        ).upper()
        entity_type = WV_ENTITY_TYPES.get(type_str, EntityType.OTHER)

        status_str = (
            record.get("Status") or record.get("status") or ""
        ).upper()
        status = WV_STATUS_MAP.get(status_str, EntityStatus.OTHER)

        filing_number = (
            record.get("CharterNumber")
            or record.get("charterNumber")
            or record.get("FilingNumber")
            or record.get("EntityID")
        )

        formation_date = None
        date_str = (
            record.get("FormationDate")
            or record.get("formationDate")
            or record.get("FilingDate")
        )
        if date_str:
            for fmt in ("%m/%d/%Y", "%Y-%m-%d"):
                try:
                    formation_date = datetime.strptime(
                        date_str.strip(), fmt
                    ).date()
                    break
                except (ValueError, AttributeError):
                    continue

        agent_name = (
            record.get("RegisteredAgent")
            or record.get("registeredAgent")
        )
        agent = Person(full_name=agent_name) if agent_name else None

        address = None
        addr_str = (
            record.get("PrincipalAddress")
            or record.get("principalAddress")
            or record.get("Address")
        )
        if addr_str:
            address = parse_address_text(addr_str)

        return Business(
            name=name.strip(),
            entity_type=entity_type,
            status=status,
            state="WV",
            filing_number=filing_number,
            formation_date=formation_date,
            address=address,
            registered_agent=agent,
            source_url=SOS_SEARCH_URL,
            raw_data=record,
        )
