"""
Wisconsin state collector.

Sources:
- DSPS (Department of Safety and Professional Services): License lookup
  https://dsps.wi.gov/Pages/SelfService/LicenseLookUp.aspx
- Wisconsin Secretary of State: Business entity search
  https://www.wsos.state.wi.us/CorpSearch/Search.aspx

Strategy: HYBRID approach
- Licenses: Browser automation (JavaScript-heavy lookup system)
- Businesses: HTTP first, browser fallback
"""

from __future__ import annotations

import logging
import re
from datetime import date as date_cls
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.models import (
    Address,
    Business,
    CollectorResult,
    EntityStatus,
    EntityType,
    License,
    LicenseStatus,
    Person,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import (
    clean_text,
    extract_text,
    parse_html,
    parse_address_text,
)
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

# --- Wisconsin DSPS (License Lookup) ---

WI_DSPS_LOOKUP_URL = "https://dsps.wi.gov/Pages/SelfService/LicenseLookUp.aspx"

WI_LICENSE_STATUS_MAP = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "CURRENT": LicenseStatus.ACTIVE,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
    "SUSPENDED": LicenseStatus.SUSPENDED,
    "REVOKED": LicenseStatus.REVOKED,
    "CANCELLED": LicenseStatus.CANCELLED,
}

# --- Wisconsin SOS (Business Entity) ---

WI_SOS_SEARCH_URL = "https://www.wsos.state.wi.us/CorpSearch/Search.aspx"

WI_ENTITY_TYPE_MAP = {
    "LIMITED LIABILITY COMPANY": EntityType.LLC,
    "DOMESTIC LIMITED LIABILITY COMPANY": EntityType.LLC,
    "FOREIGN LIMITED LIABILITY COMPANY": EntityType.LLC,
    "CORPORATION": EntityType.CORPORATION,
    "DOMESTIC CORPORATION": EntityType.CORPORATION,
    "FOREIGN CORPORATION": EntityType.CORPORATION,
    "NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "LIMITED PARTNERSHIP": EntityType.LP,
    "GENERAL PARTNERSHIP": EntityType.PARTNERSHIP,
}

WI_STATUS_MAP = {
    "ACTIVE": EntityStatus.ACTIVE,
    "GOOD STANDING": EntityStatus.ACTIVE,
    "INACTIVE": EntityStatus.INACTIVE,
    "DISSOLVED": EntityStatus.DISSOLVED,
    "SUSPENDED": EntityStatus.SUSPENDED,
    "WITHDRAWN": EntityStatus.WITHDRAWN,
    "MERGED": EntityStatus.MERGED,
}


@StateRegistry.register
class WisconsinCollector(BaseStateCollector):
    """Collector for Wisconsin government data using hybrid approach."""

    needs_browser_for = [DataCategory.LICENSES]

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="WI",
            name="Wisconsin",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "Wisconsin Department of Safety and Professional Services (DSPS)",
                "Wisconsin Secretary of State",
            ],
            notes="License lookup requires browser due to JavaScript interface.",
        )

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search Wisconsin DSPS for professional licenses using browser automation.
        """
        if not params.query and not params.license_number:
            logger.warning("WI DSPS: query or license_number is required")
            return

        if not self.has_browser:
            logger.warning(
                "WI DSPS requires browser automation. "
                "Initialize with use_browser=True."
            )
            return

        try:
            page = await self.browser.new_page()
        except Exception as e:
            logger.error("WI DSPS: failed to create browser page: %s", e)
            return

        count = 0
        max_results = params.max_results

        try:
            await page.goto(
                WI_DSPS_LOOKUP_URL,
                wait_until="domcontentloaded",
                timeout=15000,
            )

            # Wait for the search interface to load
            await page.wait_for_selector(
                'input[type="text"], .search-field, #search',
                timeout=10000
            )

            if params.license_number:
                # Look for license number field
                license_input = await page.query_selector(
                    'input[placeholder*="license"], input[name*="License"], input[id*="license"]'
                )
                if license_input:
                    await license_input.fill(params.license_number)
            elif params.query:
                # Look for name field
                name_input = await page.query_selector(
                    'input[placeholder*="name"], input[name*="Name"], input[id*="name"]'
                )
                if name_input:
                    await name_input.fill(params.query)

            # Submit search
            search_button = await page.query_selector(
                'button:has-text("Search"), input[type="submit"], #searchBtn'
            )
            if search_button:
                await search_button.click()

            # Wait for results
            await page.wait_for_load_state("domcontentloaded", timeout=15000)
            await page.wait_for_selector("table, .results", timeout=10000)

            html = await page.content()
            tree = parse_html(html)

            rows = tree.css("table tr, .results tr")
            for row in rows:
                if count >= max_results:
                    break

                cells = row.css("td")
                if len(cells) < 3:
                    continue

                name = extract_text(cells[0])
                license_num = extract_text(cells[1]) if len(cells) > 1 else None
                license_type = extract_text(cells[2]) if len(cells) > 2 else "Professional License"
                status_text = extract_text(cells[3]) if len(cells) > 3 else None

                if not name or not license_num:
                    continue

                status = LicenseStatus.ACTIVE
                if status_text:
                    status = WI_LICENSE_STATUS_MAP.get(
                        status_text.upper().strip(), LicenseStatus.OTHER
                    )

                license_obj = License(
                    license_number=license_num.strip(),
                    license_type=license_type.strip() if license_type else "Professional License",
                    status=status,
                    state="WI",
                    holder_name=name.strip(),
                    source_url=WI_DSPS_LOOKUP_URL,
                    raw_data={"status_text": status_text},
                )

                yield CollectorResult(
                    category=DataCategory.LICENSES.value,
                    state="WI",
                    data=license_obj,
                    source="Wisconsin Department of Safety and Professional Services (DSPS)",
                )
                count += 1

            logger.info("WI DSPS: returned %d license results", count)

        except Exception as e:
            logger.error("WI DSPS license search failed: %s", e)
        finally:
            await page.close()

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Search Wisconsin Secretary of State for business entities.
        """
        if not params.query:
            logger.warning("WI SOS: query (business name) is required")
            return

        # Try HTTP first
        form_data = {
            "txtEntityName": params.query,
            "btnSearch": "Search",
        }

        try:
            response = await self.client.post(WI_SOS_SEARCH_URL, data=form_data)
            html = response.text
        except Exception as e:
            logger.error("WI SOS HTTP search failed: %s", e)
            # Could fall back to browser here
            return

        tree = parse_html(html)
        rows = tree.css("table tr")

        count = 0
        for row in rows:
            if count >= params.max_results:
                break

            cells = row.css("td")
            if len(cells) < 2:
                continue

            name = extract_text(cells[0])
            filing_number = extract_text(cells[1]) if len(cells) > 1 else None
            entity_type_text = extract_text(cells[2]) if len(cells) > 2 else None
            status_text = extract_text(cells[3]) if len(cells) > 3 else None

            if not name:
                continue

            entity_type = WI_ENTITY_TYPE_MAP.get(
                (entity_type_text or "").upper().strip(), EntityType.OTHER
            )
            status = WI_STATUS_MAP.get(
                (status_text or "").upper().strip(), EntityStatus.OTHER
            )

            business = Business(
                name=name.strip(),
                entity_type=entity_type,
                status=status,
                state="WI",
                filing_number=filing_number,
                source_url=WI_SOS_SEARCH_URL,
                raw_data={
                    "entity_type_text": entity_type_text,
                    "status_text": status_text,
                },
            )

            yield CollectorResult(
                category=DataCategory.BUSINESSES.value,
                state="WI",
                data=business,
                source="Wisconsin Secretary of State",
            )
            count += 1

        logger.info("WI SOS: returned %d business results", count)