"""
Wyoming state collector.

Sources:
- WREC (Wyoming Real Estate Commission): UNAVAILABLE - 404
  https://realestate.wyo.gov/consumer-information/licensee-search/ - returns 404
  (Site exists but licensee-search URL not found)
- Secretary of State (WyoBiz): CAPTCHA PROTECTED
  https://wyobiz.wyo.gov/Business/FilingSearch.aspx - shows CAPTCHA challenge

SCAN RESULTS: WREC 404, WyoBiz OK but CAPTCHA protected
Note: WyoBiz uses ASP.NET WebForms with ViewState + CAPTCHA protection.
"""

from __future__ import annotations

import logging
import re
from datetime import date as date_cls, datetime
from typing import AsyncIterator

from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.models import (
    Address,
    Business,
    CollectorResult,
    EntityStatus,
    EntityType,
    License,
    LicenseStatus,
    Person,
    SearchParams,
    StateInfo,
)
from gov_collector.parsers import (
    clean_text,
    extract_table_rows,
    extract_text,
    parse_address_text,
    parse_html,
)
from gov_collector.registry import StateRegistry

logger = logging.getLogger(__name__)

# --- WREC (Real Estate) ---

# NOTE: Returns 404 as of Feb 2026
WREC_SEARCH_URL = "https://realestate.wyo.gov/consumer-information/licensee-search/"

WY_LICENSE_STATUS_MAP = {
    "ACTIVE": LicenseStatus.ACTIVE,
    "CURRENT": LicenseStatus.ACTIVE,
    "INACTIVE": LicenseStatus.INACTIVE,
    "EXPIRED": LicenseStatus.EXPIRED,
    "SUSPENDED": LicenseStatus.SUSPENDED,
    "REVOKED": LicenseStatus.REVOKED,
    "CANCELLED": LicenseStatus.CANCELLED,
    "PENDING": LicenseStatus.PENDING,
    "SURRENDERED": LicenseStatus.CANCELLED,
}

# --- Secretary of State WyoBiz (Business Entity, ASP.NET) ---

WYOBIZ_SEARCH_URL = "https://wyobiz.wyo.gov/Business/FilingSearch.aspx"

WY_ENTITY_TYPES = {
    "LIMITED LIABILITY COMPANY": EntityType.LLC,
    "DOMESTIC LIMITED LIABILITY COMPANY": EntityType.LLC,
    "FOREIGN LIMITED LIABILITY COMPANY": EntityType.LLC,
    "PROFIT CORPORATION": EntityType.CORPORATION,
    "CORPORATION": EntityType.CORPORATION,
    "DOMESTIC PROFIT CORPORATION": EntityType.CORPORATION,
    "DOMESTIC CORPORATION": EntityType.CORPORATION,
    "FOREIGN PROFIT CORPORATION": EntityType.CORPORATION,
    "FOREIGN CORPORATION": EntityType.CORPORATION,
    "NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "DOMESTIC NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "FOREIGN NONPROFIT CORPORATION": EntityType.NONPROFIT,
    "LIMITED PARTNERSHIP": EntityType.LP,
    "DOMESTIC LIMITED PARTNERSHIP": EntityType.LP,
    "FOREIGN LIMITED PARTNERSHIP": EntityType.LP,
    "GENERAL PARTNERSHIP": EntityType.PARTNERSHIP,
    "LIMITED LIABILITY PARTNERSHIP": EntityType.LLP,
    "DOMESTIC LIMITED LIABILITY PARTNERSHIP": EntityType.LLP,
    "FOREIGN LIMITED LIABILITY PARTNERSHIP": EntityType.LLP,
    "STATUTORY TRUST": EntityType.TRUST,
}

WY_STATUS_MAP = {
    "ACTIVE": EntityStatus.ACTIVE,
    "ACTIVE/GOOD STANDING": EntityStatus.ACTIVE,
    "GOOD STANDING": EntityStatus.ACTIVE,
    "INACTIVE": EntityStatus.INACTIVE,
    "DISSOLVED": EntityStatus.DISSOLVED,
    "ADMINISTRATIVELY DISSOLVED": EntityStatus.DISSOLVED,
    "VOLUNTARILY DISSOLVED": EntityStatus.DISSOLVED,
    "REVOKED": EntityStatus.DISSOLVED,
    "FORFEITED": EntityStatus.DISSOLVED,
    "CANCELLED": EntityStatus.DISSOLVED,
    "SUSPENDED": EntityStatus.SUSPENDED,
    "WITHDRAWN": EntityStatus.WITHDRAWN,
    "MERGED": EntityStatus.MERGED,
    "CONVERTED": EntityStatus.CONVERTED,
    "DELINQUENT": EntityStatus.SUSPENDED,
}


@StateRegistry.register
class WyomingCollector(BaseStateCollector):
    """Collector for Wyoming government data.
    
    Note: WyoBiz business search is CAPTCHA protected.
    Real estate search URL returns 404.
    """
    
    needs_browser_for = [DataCategory.BUSINESSES]

    @property
    def state_info(self) -> StateInfo:
        return StateInfo(
            code="WY",
            name="Wyoming",
            supported_categories=[
                DataCategory.LICENSES.value,
                DataCategory.BUSINESSES.value,
            ],
            sources=[
                "Wyoming Real Estate Commission (WREC)",
                "Wyoming Secretary of State (WyoBiz)",
            ],
            notes="WyoBiz uses ASP.NET WebForms requiring ViewState token management.",
        )

    # --- Real Estate Licenses ---

    async def collect_licenses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Wyoming Real Estate Commission licensee search is unavailable.
        
        The WREC site exists but the licensee-search URL returns 404.
        License verification may be available under "Verify a License" 
        but the direct search endpoint is not working.
        """
        logger.warning(
            "WY WREC: Licensee search URL returns 404. "
            "License verification may be available elsewhere on the site."
        )
        return
        yield  # Make it a generator

    async def _license_search_by_name(
        self, name: str, max_results: int = 100
    ) -> AsyncIterator[CollectorResult]:
        """Search WREC by licensee name."""
        parts = name.strip().split(maxsplit=1)
        last_name = parts[0] if parts else name
        first_name = parts[1] if len(parts) > 1 else ""

        form_data = {
            "lastName": last_name,
            "firstName": first_name,
            "searchType": "name",
        }

        try:
            response = await self.client.post(WREC_SEARCH_URL, data=form_data)
            html = response.text
        except Exception as e:
            logger.error("WY WREC license search failed: %s", e)
            return

        count = 0
        async for result in self._parse_license_results(html):
            yield result
            count += 1
            if count >= max_results:
                return

    async def _license_search_by_number(
        self, license_number: str
    ) -> AsyncIterator[CollectorResult]:
        """Search WREC by license number."""
        form_data = {
            "licenseNumber": license_number,
            "searchType": "licenseNumber",
        }

        try:
            response = await self.client.post(WREC_SEARCH_URL, data=form_data)
            html = response.text
        except Exception as e:
            logger.error("WY WREC license lookup failed: %s", e)
            return

        async for result in self._parse_license_results(html):
            yield result

    async def _parse_license_results(
        self, html: str
    ) -> AsyncIterator[CollectorResult]:
        """Parse WREC license search results."""
        tree = parse_html(html)
        rows = tree.css("table tr")

        if not rows:
            logger.debug("No WY license results found")
            return

        for row in rows:
            cells = row.css("td")
            if len(cells) < 4:
                continue

            name_text = extract_text(cells[0])
            license_id = extract_text(cells[1])
            license_type_text = extract_text(cells[2])
            status_text = extract_text(cells[3])
            expiry_text = extract_text(cells[4]) if len(cells) > 4 else None

            if not name_text or not license_id:
                continue

            status = LicenseStatus.OTHER
            if status_text:
                status_upper = status_text.upper().strip()
                status = WY_LICENSE_STATUS_MAP.get(
                    status_upper, LicenseStatus.OTHER
                )

            expiration_date = None
            if expiry_text:
                for fmt in ("%m/%d/%Y", "%Y-%m-%d"):
                    try:
                        expiration_date = datetime.strptime(
                            expiry_text.strip(), fmt
                        ).date()
                        break
                    except (ValueError, AttributeError):
                        continue

            license_obj = License(
                license_number=license_id.strip(),
                license_type=license_type_text or "Real Estate",
                status=status,
                state="WY",
                holder_name=name_text.strip(),
                expiration_date=expiration_date,
                source_url=WREC_SEARCH_URL,
                raw_data={
                    "name": name_text,
                    "license_type": license_type_text,
                    "status_text": status_text,
                    "expiry_text": expiry_text,
                },
            )

            yield CollectorResult(
                category=DataCategory.LICENSES.value,
                state="WY",
                data=license_obj,
                source="Wyoming Real Estate Commission",
            )

    # --- Business Entity Search (WyoBiz / ASP.NET) ---

    async def collect_businesses(
        self, params: SearchParams
    ) -> AsyncIterator[CollectorResult]:
        """
        Wyoming Secretary of State business search is CAPTCHA protected.
        
        WyoBiz (wyobiz.wyo.gov) shows a CAPTCHA challenge that prevents
        automated access. The service is working but requires manual 
        human verification.
        """
        logger.warning(
            "WY WyoBiz: Business search is CAPTCHA protected. "
            "Site shows 'This question is for testing whether you are a human visitor'."
        )
        return
        yield  # Make it a generator
