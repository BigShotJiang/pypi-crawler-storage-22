"""Tests for data models."""

import pytest
from gov_collector.models import (
    Address,
    Business,
    CollectorResult,
    EntityStatus,
    EntityType,
    License,
    LicenseStatus,
    Person,
    Property,
    SearchParams,
    StateInfo,
)


class TestAddress:
    def test_minimal(self):
        addr = Address()
        assert addr.country == "US"
        assert addr.street is None

    def test_full(self):
        addr = Address(
            street="123 Main St",
            city="Los Angeles",
            state="CA",
            zip_code="90001",
        )
        assert addr.street == "123 Main St"
        assert addr.state == "CA"

    def test_raw_address(self):
        addr = Address(raw="123 Main St, Los Angeles, CA 90001")
        assert addr.raw is not None


class TestPerson:
    def test_display_name_full(self):
        p = Person(full_name="John Smith")
        assert p.get_display_name() == "John Smith"

    def test_display_name_parts(self):
        p = Person(first_name="John", last_name="Smith")
        assert p.get_display_name() == "John Smith"

    def test_display_name_empty(self):
        p = Person()
        assert p.get_display_name() == "Unknown"


class TestBusiness:
    def test_minimal(self):
        b = Business(name="Acme Corp", state="CA")
        assert b.name == "Acme Corp"
        assert b.state == "CA"
        assert b.entity_type is None

    def test_full(self):
        b = Business(
            name="Acme Corp",
            state="CA",
            entity_type=EntityType.CORPORATION,
            status=EntityStatus.ACTIVE,
            filing_number="C1234567",
            address=Address(city="Sacramento", state="CA"),
        )
        assert b.entity_type == EntityType.CORPORATION
        assert b.status == EntityStatus.ACTIVE


class TestLicense:
    def test_minimal(self):
        lic = License(
            license_number="123456",
            license_type="Real Estate Salesperson",
            state="CA",
        )
        assert lic.license_number == "123456"
        assert lic.status == LicenseStatus.OTHER

    def test_real_estate_license(self):
        lic = License(
            license_number="01234567",
            license_type="Real Estate Broker",
            status=LicenseStatus.ACTIVE,
            state="CA",
            holder_name="John Smith",
            holder=Person(first_name="John", last_name="Smith"),
            address=Address(city="Los Angeles", state="CA"),
        )
        assert lic.holder_name == "John Smith"
        assert lic.status == LicenseStatus.ACTIVE


class TestProperty:
    def test_minimal(self):
        prop = Property(state="FL")
        assert prop.state == "FL"
        assert prop.assessed_value is None

    def test_full(self):
        prop = Property(
            parcel_id="12-34-56-789",
            address=Address(street="100 Ocean Dr", city="Miami", state="FL"),
            owner_name="Jane Doe",
            assessed_value=500000.0,
            year_built=1990,
            state="FL",
            county="Miami-Dade",
        )
        assert prop.assessed_value == 500000.0


class TestSearchParams:
    def test_defaults(self):
        params = SearchParams()
        assert params.max_results == 100
        assert params.query is None

    def test_real_estate_search(self):
        params = SearchParams(
            query="Smith",
            state="CA",
            city="Los Angeles",
            license_type="Real Estate",
            max_results=50,
        )
        assert params.state == "CA"
        assert params.max_results == 50


class TestStateInfo:
    def test_basic(self):
        info = StateInfo(
            code="CA",
            name="California",
            supported_categories=["licenses", "businesses"],
            sources=["DRE", "SOS"],
        )
        assert info.code == "CA"
        assert len(info.supported_categories) == 2


class TestCollectorResult:
    def test_wraps_license(self):
        lic = License(
            license_number="123", license_type="RE", state="CA"
        )
        result = CollectorResult(
            category="licenses",
            state="CA",
            data=lic,
            source="test",
        )
        assert result.category == "licenses"
        assert result.collected_at is not None
