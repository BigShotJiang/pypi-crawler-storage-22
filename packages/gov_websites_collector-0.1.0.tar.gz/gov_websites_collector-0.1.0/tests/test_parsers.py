"""Tests for HTML parsing utilities."""

import pytest
from gov_collector.parsers import (
    clean_text,
    extract_table_rows,
    extract_detail_pairs,
    normalize_name,
    parse_address_text,
)


class TestCleanText:
    def test_whitespace(self):
        assert clean_text("  hello   world  ") == "hello world"

    def test_newlines(self):
        assert clean_text("hello\n\n  world") == "hello world"

    def test_none(self):
        assert clean_text(None) is None

    def test_empty(self):
        assert clean_text("   ") is None


class TestExtractTableRows:
    def test_basic_table(self):
        html = """
        <table>
            <tr><th>Name</th><th>License</th><th>Status</th></tr>
            <tr><td>John Smith</td><td>123456</td><td>Active</td></tr>
            <tr><td>Jane Doe</td><td>789012</td><td>Expired</td></tr>
        </table>
        """
        rows = extract_table_rows(html)
        assert len(rows) == 2
        assert rows[0]["Name"] == "John Smith"
        assert rows[0]["License"] == "123456"
        assert rows[1]["Status"] == "Expired"

    def test_empty_table(self):
        html = "<table><tr><th>Name</th></tr></table>"
        rows = extract_table_rows(html)
        assert rows == []

    def test_no_table(self):
        html = "<div>No table here</div>"
        rows = extract_table_rows(html)
        assert rows == []


class TestExtractDetailPairs:
    def test_th_td_pairs(self):
        html = """
        <table>
            <tr><th>Name:</th><td>John Smith</td></tr>
            <tr><th>License:</th><td>123456</td></tr>
        </table>
        """
        pairs = extract_detail_pairs(html)
        assert pairs["Name:"] == "John Smith"
        assert pairs["License:"] == "123456"


class TestParseAddress:
    def test_standard_format(self):
        addr = parse_address_text("123 Main St, Los Angeles, CA 90001")
        assert addr.zip_code == "90001"
        assert addr.state == "CA"
        assert addr.street == "123 Main St"

    def test_zip_only(self):
        addr = parse_address_text("Somewhere 90210")
        assert addr.zip_code == "90210"

    def test_raw_preserved(self):
        raw = "123 Main St, City, ST 12345"
        addr = parse_address_text(raw)
        assert addr.raw == raw


class TestNormalizeName:
    def test_basic(self):
        assert normalize_name("John Smith") == "JOHN SMITH"

    def test_strips_llc(self):
        assert normalize_name("Acme Corp, LLC") == "ACME CORP"

    def test_strips_inc(self):
        assert normalize_name("Acme Corp, INC") == "ACME CORP"

    def test_whitespace(self):
        assert normalize_name("  John   Smith  ") == "JOHN SMITH"
