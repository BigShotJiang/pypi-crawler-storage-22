"""Tests for the state registry."""

import pytest
from gov_collector.base import BaseStateCollector, DataCategory
from gov_collector.models import StateInfo
from gov_collector.registry import StateRegistry, get_collector, list_states


class TestStateRegistry:
    def test_list_states_not_empty(self):
        """After importing states, registry should have collectors."""
        states = list_states()
        assert len(states) >= 3  # CA, TX, FL minimum

    def test_california_registered(self):
        cls = StateRegistry.get("CA")
        assert cls is not None

    def test_texas_registered(self):
        cls = StateRegistry.get("TX")
        assert cls is not None

    def test_florida_registered(self):
        cls = StateRegistry.get("FL")
        assert cls is not None

    def test_case_insensitive(self):
        assert StateRegistry.get("ca") is not None
        assert StateRegistry.get("Ca") is not None

    def test_unknown_state(self):
        assert StateRegistry.get("ZZ") is None

    def test_get_collector(self):
        collector = get_collector("CA")
        assert collector is not None
        assert collector.state_code == "CA"

    def test_get_collector_unknown(self):
        with pytest.raises(ValueError, match="No collector"):
            get_collector("ZZ")

    def test_list_by_category(self):
        license_states = StateRegistry.list_by_category(DataCategory.LICENSES)
        assert any(s.code == "CA" for s in license_states)
        assert any(s.code == "TX" for s in license_states)
        assert any(s.code == "FL" for s in license_states)

    def test_state_info_structure(self):
        states = list_states()
        for info in states:
            assert len(info.code) == 2
            assert info.name
            assert len(info.supported_categories) > 0
            assert len(info.sources) > 0
