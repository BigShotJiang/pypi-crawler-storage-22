from typing import Callable, Dict, Any, Union, List
from PySide6.QtWidgets import QWidget

from .widget_type import WidgetType


class QtWidgetFactory:
    """
    WidgetType → Qt Widget 创建器注册表
    """

    _registry: Dict[WidgetType, Callable[..., QWidget]] = {}

    @classmethod
    def register(cls, widget_type: Union[WidgetType, List[WidgetType]]):
        def decorator(func: Callable[..., QWidget]):
            if isinstance(widget_type, list):
                for t in widget_type:
                    cls._registry[t] = func
            else:
                cls._registry[widget_type] = func
            return func
        return decorator

    @classmethod
    def create(
        cls,
        widget_type: WidgetType,
        *,
        key: str,
        meta: Dict[str, Any],
        value: Any,
        on_change: Callable[[str, Any], None],
        parent=None
    ) -> QWidget:
        if widget_type not in cls._registry:
            raise KeyError(f"No Qt widget registered for [{widget_type}]")

        return cls._registry[widget_type](
            key=key,
            meta=meta,
            value=value,
            on_change=on_change,
            parent=parent,
        )
