from PySide6.QtWidgets import (
    QWidget, QFormLayout,
    QGroupBox, QVBoxLayout,
)
from . import QtWidgetFactory


class ParamEditor(QWidget):
    """
    通用参数编辑器
    - 不依赖 Step / Action
    - 只依赖 param_schema + value accessors
    """
    def __init__(self, parent=None):
        super().__init__(parent)

        self.main_layout = QVBoxLayout(self)
        self.main_layout.setContentsMargins(0, 0, 0, 0)

        self.params_group = QGroupBox("参数设置")
        self.params_layout = QFormLayout(self.params_group)
        self.main_layout.addWidget(self.params_group)
        self.main_layout.addStretch()

        self._editors = {}
        self._getter = None
        self._setter = None

    # ---------- public API ----------

    def bind(
        self,
        param_schema: dict,
        get_value,
        set_value,
        enabled: bool = True,
    ):
        """
        get_value(key, meta) -> value
        set_value(key, value)
        """
        self._clear()
        self._getter = get_value
        self._setter = set_value

        self.params_group.setEnabled(enabled)

        if not param_schema:
            return

        for key, meta in param_schema.items():
            self._add_editor(key, meta)

    def clear(self):
        self._clear()
        self.params_group.setEnabled(False)

    # ---------- internal ----------

    def _clear(self):
        while self.params_layout.rowCount():
            self.params_layout.removeRow(0)
        self._editors.clear()

    def _add_editor(self, key, meta):
        value = self._getter(key, meta)
        widget_type = meta.get("widget", "text")

        editor = QtWidgetFactory.create(
            widget_type,
            key=key,
            meta=meta,
            value=value,
            on_change=self._on_value_changed,
            parent=self,
        )

        label = meta.get("label", key)
        self.params_layout.addRow(label, editor)
        self._editors[key] = editor

    def _on_value_changed(self, key, value):
        if self._setter:
            self._setter(key, value)
