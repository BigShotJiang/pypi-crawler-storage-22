

import inspect
import enum
import pathlib
from typing import Any, get_origin, get_args, Union, Literal, List, Tuple, Dict
from enum import Enum


class WidgetType(str, Enum):
    CHECKBOX = "checkbox"
    SPIN_INT = "spin_int"
    SPIN_FLOAT = "spin_float"
    LINE_EDIT = "line_edit"
    TEXT_EDIT = "text_edit"
    MULTILINE_EDIT = "multiline_edit"
    ENUM_COMBO = "enum_combo"
    LITERAL_COMBO = "literal_combo"
    FILE_PATH = "file_path"
    FOLDER_PATH = "folder_path"
    LIST_EDITOR = "list_editor"
    DICT_EDITOR = "dict_editor"

    # 旧类型兼容
    TEXT = "text"
    SPIN = "spin"
    COMBO = "combo"
    DOUBLE = "double"
    RECT = "rect"
    COLOR = "color"


WidgetTypeLiteral = Literal[
    "checkbox",
    "spin_int",
    "spin_float",
    "line_edit",
    "text_edit",
    "enum_combo",
    "literal_combo",
    "file_path",
    "list_editor",
    "dict_editor",
]


def infer_widget_type(
    param_type: Any,
    default_value: Any = None
) -> WidgetType:
    """
    根据参数类型与默认值推断 UI Widget 类型（语义层，不绑定 Qt）

    规则：
    - models.WidgetType 是唯一返回类型
    - 不做 UI 实现细节
    - 推断失败时给出安全兜底
    """

    origin = get_origin(param_type)
    args = get_args(param_type)

    # ---------- Optional[T] ----------
    if origin is Union and type(None) in args:
        non_none = [a for a in args if a is not type(None)]
        if non_none:
            return infer_widget_type(non_none[0], default_value)
        return WidgetType.LINE_EDIT

    # ---------- bool ----------
    if param_type is bool or isinstance(default_value, bool):
        return WidgetType.CHECKBOX

    # ---------- int / float ----------
    if param_type is int or isinstance(default_value, int):
        return WidgetType.SPIN_INT

    if param_type is float or isinstance(default_value, float):
        return WidgetType.SPIN_FLOAT

    # ---------- str / bytes ----------
    if param_type is str:
        return WidgetType.LINE_EDIT

    if param_type is bytes:
        return WidgetType.TEXT_EDIT

    # ---------- Path ----------
    if param_type in (pathlib.Path,):
        return WidgetType.FILE_PATH

    # ---------- Enum ----------
    if inspect.isclass(param_type) and issubclass(param_type, enum.Enum):
        return WidgetType.ENUM_COMBO

    # ---------- Literal ----------
    if origin is Literal:
        return WidgetType.LITERAL_COMBO

    # ---------- List / Tuple ----------
    if origin in (list, List, tuple, Tuple):
        return WidgetType.LIST_EDITOR

    # ---------- Dict ----------
    if origin in (dict, Dict) or param_type is dict:
        return WidgetType.DICT_EDITOR

    # ---------- 默认兜底 ----------
    return WidgetType.MULTILINE_EDIT


def build_widget_schema(param_type, default_value=None):
    """
    从类型构建一个完整的 widget schema（递归）
    """
    widget = infer_widget_type(param_type, default_value).value
    meta = extract_widget_metadata(param_type, default_value)

    schema = {
        "widget": widget,
        **meta
    }

    if default_value is not None:
        schema["default"] = normalize_default_value(default_value)

    return schema


def extract_widget_metadata(param_type, default_value):
    """
    从参数类型中提取 UI 所需的附加元数据
    """
    meta = {}

    origin = get_origin(param_type)
    args = get_args(param_type)

    # ---------- Optional ----------
    if origin is Union and type(None) in args:
        meta["nullable"] = True
        non_none = [a for a in args if a is not type(None)]
        if non_none:
            inner_meta = extract_widget_metadata(non_none[0], default_value)
            meta.update(inner_meta)
        return meta

    # ---------- Enum ----------
    if inspect.isclass(param_type) and issubclass(param_type, enum.Enum):
        meta["options"] = [e.value for e in param_type]
        meta["enum"] = param_type.__name__
        return meta

    # ---------- Literal ----------
    if origin is Literal:
        meta["options"] = list(args)
        return meta

    # ---------- List / Tuple ----------
    if origin in (list, tuple):
        meta["multiple"] = True
        if args:
            item_type = args[0]
            meta["item"] = build_widget_schema(
                item_type,
                None
            )
        return meta

    # ---------- Dict ----------
    if origin is dict or param_type is dict:
        meta["key_type"] = "str"
        meta["value_type"] = "Any"
        return meta

    # ---------- int ----------
    if param_type is int:
        meta["constraints"] = {
            "min": None,
            "max": None,
            "step": 1
        }
        return meta

    # ---------- float ----------
    if param_type is float:
        meta["constraints"] = {
            "min": None,
            "max": None,
            "step": 0.1
        }
        return meta

    return meta


def normalize_default_value(value):
    if value is None:
        return None

    # Enum → value
    if isinstance(value, enum.Enum):
        return value.value

    # Path → str
    if hasattr(value, "__fspath__"):
        return str(value)

    # list / tuple
    if isinstance(value, (list, tuple)):
        return [normalize_default_value(v) for v in value]

    # dict
    if isinstance(value, dict):
        return {k: normalize_default_value(v) for k, v in value.items()}

    return value
