from typing import Optional, List

from gp_ir import IRNode, IRCall, IRComment
from gp_ir import ActionRegistry
from gp_ir import IRExecutor, RuntimeContext, DebugController

from .node_def import NodeDefinition
from .graph import FlowNode, PortSpec, PortDirection, FlowType


def build_ir_from_node(node: FlowNode) -> List[IRNode]:
    return [
        IRCall(
            func=node.action_id,
            args=[],
            kwargs=node.params
        )
    ]


def run_action(node, ctx):
    ir = build_ir_from_node(node)

    def print_callback(*args):
        msgs = [repr(arg) for arg in args]
        msg = "Action: " + " ".join(msgs)
        ctx.log(msg)

    try:
        # 运行
        ir_ctx = RuntimeContext(step_callback=None, print_callback=print_callback)
        IRExecutor(ir_ctx).run(ir, None, None)
    except Exception as e:
        # 错误
        ctx.log(f"Action: {node.id} error => {e}")


class ActionNodeDef(NodeDefinition):
    type = "action"

    def ports(self):
        return [
            PortSpec("in", PortDirection.IN),
            PortSpec("out", PortDirection.OUT, required=False),
        ]

    def param_schema(self, node: Optional[FlowNode] = None):
        if node and node.action_id:
            action = ActionRegistry.get(node.action_id)
            action_def = action.param_schema if action else None
            return action_def

        return {
            "cmd": {
                "type": "string",
                "label": "Command",
                "widget": "text",
                "default": "",
            },
            "breakpoint": {
                "type": "bool",
                "label": "Breakpoint",
                "widget": "checkbox",
                "default": False,
            },
        }

    def execute(self, node, ctx):
        if node.action_id:
            run_action(node, ctx)
        else:
            cmd = node.params.get("cmd", "")
            ctx.log(f"Action: {node.id} => {cmd}")
        return "out"
