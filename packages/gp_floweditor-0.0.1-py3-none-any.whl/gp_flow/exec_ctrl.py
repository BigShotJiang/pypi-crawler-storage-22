from PySide6.QtCore import QTimer

from .executor import FlowExecutor


class ExecutionController:
    def __init__(self, graph, ui):
        self.graph = graph
        self.executor = FlowExecutor(graph)
        self.ui = ui   # FlowScene + Message hook

        self.ctx = None
        self.running = False

        self.timer = QTimer()
        self.timer.timeout.connect(self._continue_tick)

    # ========= 生命周期 =========

    def start(self):
        self.ui.reset_execution_states()
        self.ctx = self.executor.start()

    def reset(self):
        self.timer.stop()
        self.running = False
        self.ctx = None
        self.ui.reset_execution_states()

    # ========= 控制 =========

    def step_once(self):
        if self.ctx is None or self.ctx.finished:
            self.start()

        if self.ctx.current_node:
            current_node_id = self.ctx.current_node.id
        self.executor.step(self.ctx)
        if current_node_id:
            self.ui.activate_node(current_node_id)

        if self.ctx.trace:
            node_id, out_port = self.ctx.trace[-1]
            self.ui.activate_edge(node_id, out_port)
            if len(self.ctx.trace) > 1:
                done_id, _ = self.ctx.trace[-2]
                self.ui.mark_node_done(done_id)

        return self.ctx.finished

    def continue_run(self):
        if self.running:
            return

        if self.ctx is None:
            self.start()

        self.running = True
        self.timer.start(300)

    def pause(self):
        self.timer.stop()
        self.running = False

    # ========= 内部 =========

    def _continue_tick(self):
        if not self.running or self.ctx.finished or self.ctx.hit_breakpoint:
            self.timer.stop()
            self.running = False

            if self.ctx and self.ctx.finished:
                self.ui.show_finished()
                # ⚠️ 注意：是否 reset 由 Controller 决定
                self.ctx = None
            return

        self.step_once()
