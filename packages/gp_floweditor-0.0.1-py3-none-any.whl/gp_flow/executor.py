from typing import Optional, Dict, Any

from .graph import FlowGraph, FlowNode, FlowEdge
from .registry import get_node_def


class ExecutionContext:
    """
    最小执行上下文
    - 执行期状态
    - 可扩展，但目前不做复杂设计
    """

    def __init__(self):
        self.current_node : Optional[FlowNode] = None
        self.finished = False
        self.hit_breakpoint = False

        # 关键：执行轨迹（后面 UI / 调试 全靠它）
        self.trace = []
        # e.g. [(node_id, out_port)]

        # 可扩展：变量 / 环境
        self.vars: Dict[str, Any] = {}
        self.logs: list[str] = []
        
        self.loop_stack: list[str] = []
        self.nodes_states: Dict[str, Any] = {}

    def log(self, msg: str):
        self.logs.append(msg)
        print(f"[EXEC] {msg}")


class FlowExecutor:
    """
    最小但正确的 FlowGraph 执行器
    """

    def __init__(self, graph: FlowGraph):
        self.graph = graph

    # =====================================================
    # Public API
    # =====================================================

    def run(self, context: Optional[ExecutionContext] = None):
        ctx = context or ExecutionContext()

        self.start(ctx)
        ctx.log("Execution started.")

        while not ctx.finished:
            self.step(ctx)

        ctx.log("Execution finished.")
        return ctx

    def start(self, context: Optional[ExecutionContext] = None):
        ctx = context or ExecutionContext()
        ctx.trace = []
        ctx.finished = False
        ctx.current_node = self._find_start_node()

        if not ctx.current_node:
            ctx.log("No start node found. Abort.")
            ctx.finished = True

        return ctx

    def step(self, ctx: ExecutionContext):
        current = ctx.current_node
        if not current:
            ctx.finished = True
            return

        # 断点判断: 进入节点
        if current.params.get("breakpoint"):
            ctx.hit_breakpoint = True
        else:
            ctx.hit_breakpoint = False

        ctx.log(f"Enter node: {current.id} [{current.title}] ({current.type})")

        node_def = get_node_def(current.type)
        out_port = node_def.execute(current, ctx)

        # 如果是 loop 节点
        if current.type == "loop":
            if out_port == "loop":          # loop 进入
                ctx.loop_stack.append(current.id)

        # 记录轨迹
        ctx.trace.append((current.id, out_port))
        ctx.current_node = self._next_node(ctx, current, out_port)

        if ctx.current_node is None:
            ctx.finished = True

    # =====================================================
    # Routing
    # =====================================================

    def _next_node(
        self,
        ctx: ExecutionContext,
        node: FlowNode,
        out_port: Optional[str],
    ) -> Optional[FlowNode]:

        if out_port is None:
            return None

        edges = self.graph.outgoing_from(node.id, out_port)

        if not edges:
            # 如果在 loop 里，则自动回跳
            if ctx.loop_stack:
                loop_id = ctx.loop_stack.pop()
                return self.graph.nodes.get(loop_id)

            return None

        if len(edges) > 1:
            raise RuntimeError(
                f"Multiple outgoing edges from {node.id}:{out_port}"
            )

        edge = edges[0]
        return self.graph.nodes.get(edge.dst_node)

    def _find_start_node(self) -> Optional[FlowNode]:
        """Start Node 查找(显式、可报错)"""
        starts = [
            n for n in self.graph.nodes.values()
            if n.type == "start"
        ]

        if not starts:
            return None

        if len(starts) > 1:
            raise RuntimeError("Multiple start nodes found")

        return starts[0]
