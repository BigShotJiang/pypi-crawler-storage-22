from PySide6.QtWidgets import QWidget, QVBoxLayout, QLineEdit, QTextEdit, QCheckBox, QLabel, QFrame

from gp_aw import ParamEditor
from .graph import FlowNode


class FlowNodeEditor(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._node = None

        self._title_edit = QLineEdit(self)
        self._summary_edit = QTextEdit(self)
        self._breakpoint_cb = QCheckBox("Breakpoint", self)
        self._param_editor = ParamEditor(self)

        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Title"))
        layout.addWidget(self._title_edit)
        layout.addWidget(QLabel("Summary"))
        layout.addWidget(self._summary_edit)
        layout.addWidget(self._breakpoint_cb)
        layout.addWidget(QFrame(frameShape=QFrame.HLine))
        layout.addWidget(self._param_editor)

        self._wire_signals()

    # ---------- 信号 ----------
    def _wire_signals(self):
        self._title_edit.editingFinished.connect(self._on_title_changed)
        self._summary_edit.textChanged.connect(self._on_summary_changed)
        self._breakpoint_cb.toggled.connect(self._on_breakpoint_changed)

    # ---------- 接口 ----------

    def bind_node(self, node: FlowNode):
        self._node = node

        if not node:
            self.setEnabled(False)
            self._param_editor.clear()
            return
        
        self.setEnabled(True)

        # 固定属性
        self._title_edit.setText(node.title)
        self._summary_edit.setPlainText(node.summary)
        self._breakpoint_cb.setChecked(bool(node.params.get("breakpoint")))

        # 动态参数
        self._param_editor.bind(
            param_schema=node.get_definition().param_schema(node),
            get_value=self._get_value,
            set_value=self._set_value,
        )

    def clear(self):
        self._param_editor.clear()

    # ---------- adapter ----------

    def _get_value(self, key, meta):
        return self._node.params.get(key, meta.get("default"))

    def _set_value(self, key, value):
        self._node.params[key] = value
        print(f"[UI] {self._node.id}.{key} = {value}")

    def _on_title_changed(self):
        if not self._node:
            return
        self._node.title = self._title_edit.text()

    def _on_summary_changed(self):
        if not self._node:
            return
        self._node.summary = self._summary_edit.toPlainText()

    def _on_breakpoint_changed(self):
        if not self._node:
            return
        self._node.params["breakpoint"] = self._breakpoint_cb.isChecked()
