import json
import uuid
from typing import Optional, List, Dict, Literal, get_args
from dataclasses import dataclass
from enum import Enum


class FlowType(Enum):
    CONTROL = "control"
    DATA = "data"


class PortDirection(Enum):
    IN = "in"
    OUT = "out"


NODE_KINDS = Literal["start", "action", "if", "loop", "end", "set"]
KIND_LIST = get_args(NODE_KINDS)


@dataclass
class PortSpec:
    name: str
    direction: PortDirection
    flow_type: FlowType = FlowType.CONTROL
    required: bool = True  # 是否为必需端口（必须连接）


class FlowNode:
    """ 基础节点模型。子类化此类以定义特定逻辑 """
    def __init__(
        self,
        type : NODE_KINDS,
        node_id: Optional[str] = None,
        title: Optional[str] = None,
        summary: Optional[str] = None,
        params: Optional[dict] = None,
        action_id: Optional[str] = None,
        pos: Optional[tuple] = (0, 0)
    ):
        self.id = node_id or str(uuid.uuid4())
        self.action_id = action_id          # 这个影响 get_definition(), 要放到最前面
        self.type = type
        self.params = params or self.get_definition().default_params(self)
        self.pos = pos
        self.title = title or type
        self.summary = summary or "[no summary]"
        self.runtime_state = {}   # 运行期数据, 不参与持久化

    def get_definition(self):
        from .registry import get_node_def
        return get_node_def(self.type)

    # ---- Serialization ----

    def to_dict(self):
        return {
            "id": self.id,
            "type": self.type,
            "params": self.params,
            "pos": self.pos,
            "title": self.title,
            "summary": self.summary,
            "action_id": self.action_id,
        }

    @staticmethod
    def from_dict(d):
        node = FlowNode(
            type=d["type"],
            title=d.get("title", ""),
            summary=d.get("summary", ""),
            node_id=d["id"],
            params=d.get("params", {}),
            pos=d.get("pos", (0, 0)),
            action_id=d.get("action_id")
        )
        return node


class FlowEdge:
    def __init__(
        self,
        src_node: str,
        src_port: str,
        dst_node: str,
        dst_port: str,
        id: str = None,
    ):
        self.id = id or str(uuid.uuid4())
        self.src_node = src_node
        self.src_port = src_port
        self.dst_node = dst_node
        self.dst_port = dst_port

    def key(self):
        return (self.src_node, self.src_port)

    def to_dict(self):
        return {
            "id": self.id,
            "src": {
                "node": self.src_node,
                "port": self.src_port,
            },
            "dst": {
                "node": self.dst_node,
                "port": self.dst_port,
            },
        }

    @staticmethod
    def from_dict(d):
        e = FlowEdge(
            id=d["id"],
            src_node=d["src"]["node"],
            src_port=d["src"]["port"],
            dst_node=d["dst"]["node"],
            dst_port=d["dst"]["port"],
        )
        e.id = d["id"]
        return e


class FlowGraph:
    """Graph 唯一真相"""

    def __init__(self):
        self.nodes: Dict[str, FlowNode] = {}
        self.edges: Dict[str, FlowEdge] = {}

    # ---------- runtime ----------

    def clear_runtime_state(self):
        for node in self.nodes.values():
            node.runtime_state.clear()
    
    # ---------- Node ops ----------

    def add_node(self, node: FlowNode):
        if node.id in self.nodes:
            raise ValueError(f"Node {node.id} already exists")
        self.nodes[node.id] = node

    def remove_node(self, node_id) -> List[FlowNode]:
        """
        删除节点
        返回：被删除的 edge 列表
        """
        removed = []
        if node_id not in self.nodes:
            return removed

        # remove related edges
        for eid in list(self.edges):
            e = self.edges[eid]
            if e.src_node == node_id or e.dst_node == node_id:
                removed.append(e)
                del self.edges[eid]

        del self.nodes[node_id]
        return removed

    # ---------- Edge ops ----------


    def add_edge(
        self,
        src_node: str,
        src_port: str,
        dst_node: str,
        dst_port: str,
    ):
        """
        一个 out 口只能连接一个 in
        如果已存在，则删除旧 edge
        """

         # 1️⃣ 查找已有的 edge（同 src_node + src_port）
        to_remove = [
            eid for eid, e in self.edges.items()
            if e.src_node == src_node and e.src_port == src_port
        ]

        # 2️⃣ 删除旧 edge
        for eid in to_remove:
            del self.edges[eid]

        # 3️⃣ 创建新 edge
        edge = FlowEdge(src_node, src_port, dst_node, dst_port)
        self.edges[edge.id] = edge

        return edge

    def remove_edge(self, edge_id):
        if edge_id in self.edges:
            del self.edges[edge_id]

    def remove_outgoing_from(self, src_node: str, src_port: str):
        for eid in list(self.edges):
            e = self.edges[eid]
            if e.src_node == src_node and e.src_port == src_port:
                del self.edges[eid]

    # ---------- Port helpers ----------

    def node_ports(self, node_id: str) -> Dict[str, PortSpec]:
        node = self.nodes.get(node_id)
        if node is None:
            return {}
        return {spec .name: spec for spec in node.get_definition().ports()}

    def get_port_spec(self, node_id: str, port_name: str) -> Optional[PortSpec]:
        return self.node_ports(node_id).get(port_name)

    # ---------- Query helpers ----------

    def outgoing(self, node_id: str, port: Optional[str] = None):
        """
        ⚠ Deprecated for execution.
        Use outgoing_from(node_id, src_port) for control flow routing.
        """
        return [
            e for e in self.edges.values()
            if e.src_node == node_id
            and (port is None or e.src_port == port)
        ]
    
    def outgoing_from(self, node_id: str, src_port: str):
        return [
            e for e in self.edges.values()
            if e.src_node == node_id
            and e.src_port == src_port
        ]

    def incoming(self, node_id: str, port: Optional[str] = None):
        return [
            e for e in self.edges.values()
            if e.dst_node == node_id
            and (port is None or e.dst_port == port)
        ]

    # ---------- Serialization ----------

    def to_dict(self):
        return {
            "nodes": [n.to_dict() for n in self.nodes.values()],
            "edges": [e.to_dict() for e in self.edges.values()],
        }

    def to_json(self, indent=2):
        return json.dumps(self.to_dict(), indent=indent)
    
    def export_graph(self, path: str):
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, indent=2)

    @staticmethod
    def from_dict(d):
        g = FlowGraph()
        for nd in d.get("nodes", []):
            node = FlowNode.from_dict(nd)
            g.nodes[node.id] = node
        for ed in d.get("edges", []):
            edge = FlowEdge.from_dict(ed)
            g.edges[edge.id] = edge
        return g

    @staticmethod
    def from_json(text: str):
        return FlowGraph.from_dict(json.loads(text))
    
    @staticmethod
    def import_graph(path: str) -> 'FlowGraph':
        with open(path, "r", encoding="utf-8") as f:
            return FlowGraph.from_json(f.read())
    


def clone_graph(graph: FlowGraph) -> FlowGraph:
    data = graph.to_json()
    return FlowGraph.from_json(data)
