from typing import Optional, Literal, List, Dict
from PySide6.QtWidgets import QGraphicsItem, QGraphicsRectItem, QGraphicsPathItem, QGraphicsTextItem, QGraphicsEllipseItem, QGraphicsSimpleTextItem
from PySide6.QtGui import (
    QPainter, QPen, QBrush, QColor, QFont, QPainterPath, QPainterPathStroker, QPolygonF, QTransform
)
from PySide6.QtCore import QRectF, Qt, QPointF
from .graph import FlowNode, FlowEdge, PortSpec, FlowType, PortDirection

from enum import Enum


class ExecState(Enum):
    IDLE = 0
    ACTIVE = 1
    DONE = 2


class FlowPortItem(QGraphicsEllipseItem):
    """
    UI projection of a Flow Port (Graph-layer Port).

    - Belongs to a FlowNodeItem (as parent)
    - Does NOT own any graph logic
    - Only responsible for hit-test / hover / visual feedback
    """

    R = 5

    # 颜色语义：外边框区分进出，填充区分数据类型
    IN_COLOR = QColor("#582FC1")   # 浅灰
    OUT_COLOR = QColor("#9E9E9E")  # 深灰

    PORT_TYPE_COLOR = {
        FlowType.CONTROL: QColor("#8A8A8A"),
        FlowType.DATA: QColor("#4CAF50"),
    }

    def __init__(self, node_item, spec: PortSpec):
        # IMPORTANT: parented to node item
        super().__init__(-self.R, -self.R, self.R * 2, self.R * 2, node_item)
        # self.direction = direction
        self.node_item = node_item
        self.spec = spec    # PortSpec declared by FlowNode (UI uses only)

        self.setAcceptHoverEvents(True)
        self.setAcceptedMouseButtons(Qt.LeftButton)

        # 鼠标经过显示名称 (使用系统 ToolTip 最为高效)
        # self.setToolTip(f"Port: {spec.name}\nType: {spec.flow_type.value}")
        semantic = self._semantic_color()
        if semantic:
            self.setToolTip(
                f"{self.node_item.node.type.upper()} / {self.spec.name.upper()}\n"
                f"{self.spec.flow_type.value} flow"
            )

        self._hovered = False
        self._highlighted = False
        self._label_item = None
        self._init_label()
        self._update_style()

    def __repr__(self):
        return f"FlowPortItem({self.node_item.node.id}.{self.spec.name})"

    # ---------------- UI only ----------------

    def shape(self):
        path = QPainterPath()
        path.addEllipse(-8, -8, 16, 16)
        return path

    def set_highlighted(self, on: bool):
        self._highlighted = on
        if on:
            self.setBrush(QBrush(Qt.green))
        else:
            self.setBrush(QBrush(Qt.darkGray))

    # ---------------- 内部事件 ----------------

    def hoverEnterEvent(self, event):
        self._hovered = True
        self._update_style()
        super().hoverEnterEvent(event)

    def hoverLeaveEvent(self, event):
        self._hovered = False
        self._update_style()
        super().hoverLeaveEvent(event)

    # ---------------- UI 内部函数 ----------------

    def _update_style(self):
        # ---------- border ----------
        border_color = (
            self.OUT_COLOR
            if self.spec.direction == PortDirection.OUT
            else self.IN_COLOR
        )

        pen_width = 2 if self._hovered or self._highlighted else 1.5
        pen = QPen(border_color, pen_width)
        self.setPen(pen)

        # ---------- fill ----------
        base_fill = self.PORT_TYPE_COLOR.get(
            self.spec.flow_type,
            QColor("#666666")
        )

        semantic = self._semantic_color()

        if semantic and (self._hovered or self._highlighted):
            fill_color = semantic
        else:
            fill_color = base_fill

        self.setBrush(QBrush(fill_color))

    def _init_label(self):
        # node_type = self.node_item.node.type
        port = self.spec.name
        text = None

        if self.spec.direction == PortDirection.OUT:
            if port != "out":
                text = port

        if not text:
            return

        label = QGraphicsSimpleTextItem(text, self)
        label.setBrush(QColor("#333333"))
        label.setScale(0.8)

        # 位置：右侧 or 左侧
        dx = 8 if self.spec.direction == PortDirection.OUT else -label.boundingRect().width() - 8
        label.setPos(dx, -label.boundingRect().height() / 2)

        self._label_item = label

    def _semantic_color(self) -> Optional[QColor]:
        node_type = self.node_item.node.type
        port = self.spec.name

        if node_type == "if":
            if port == "true":
                return QColor("#4CAF50")   # green
            if port == "false":
                return QColor("#F44336")   # red

        if node_type == "loop":
            if port == "loop":
                return QColor("#2196F3")   # blue
            if port == "exit":
                return QColor("#FF9800")   # orange

        return None


class FlowNodeItem(QGraphicsRectItem):
    WIDTH = 140
    HEIGHT = 60
    HEADER_HEIGHT = 24

    def __init__(self, node: FlowNode):
        super().__init__(0, 0, self.WIDTH, self.HEIGHT)
        self.node = node
        self.port_items: Dict[str, FlowPortItem] = {}
        self.edges = []
        self._exec_state = ExecState.IDLE
        self._breakpoint = bool(self.node.params.get("breakpoint"))

        self.setPos(*node.pos)

        # 关键：启用 Qt 内建交互
        self.setFlags(
            QGraphicsItem.ItemIsMovable |
            QGraphicsItem.ItemIsSelectable |
            QGraphicsItem.ItemSendsGeometryChanges
        )
        self.setAcceptHoverEvents(True)
        self._init_ui()
        self._create_ports_from_spec()

    def __repr__(self):
        return f"FlowNodeItem({self.node.id})"

    # ---------- UI ----------

    def _init_ui(self):
        self.title_item = QGraphicsTextItem(self.node.title, self)
        self.title_item.setPos(8, 4)
        self.title_item.setZValue(1)

        self.summary_item = QGraphicsTextItem("", self)
        self.summary_item.setDefaultTextColor(QColor("#666"))
        self.summary_item.setTextWidth(self.WIDTH - 16)
        self.summary_item.setPos(8, self.HEADER_HEIGHT + 2)
        self.summary_item.setZValue(1)

        self._update_breakpoint_style()
        self.refresh_summary()

    def _update_execution_style(self):
        """
        执行态样式，不影响 hover / select
        """

        if self._exec_state == ExecState.ACTIVE:
            # 当前执行（强高亮）
            self.setPen(QPen(QColor("#FFD54F"), 4))
            self.setBrush(QBrush(QColor("#FFF8E1")))
        elif self._exec_state == ExecState.DONE:
            # 执行过（弱高亮）
            self.setPen(QPen(QColor("#90CAF9"), 2))
            self.setBrush(QBrush(Qt.NoBrush))
        else:
            self.setPen(QPen(Qt.black))
            self.setBrush(QBrush(Qt.NoBrush))

    def _update_breakpoint_style(self):
        if self._breakpoint:
            self.title_item.setDefaultTextColor(QColor("#D32F2F"))
        else:
            self.title_item.setDefaultTextColor(Qt.black)

    # ---------------- Ports ----------------

    def _create_ports_from_spec(self):
        in_ports = []
        out_ports = []

        for spec in self.node.get_definition().ports():
            port_item = FlowPortItem(self, spec)
            self.port_items[spec.name] = port_item

            if spec.direction == PortDirection.IN:
                in_ports.append(port_item)
            else:
                out_ports.append(port_item)

        self._layout_ports(in_ports, out_ports)

    def _layout_ports(self, ins, outs):
        h = self.HEIGHT

        for i, port in enumerate(ins):
            y = h * (i + 1) / (len(ins) + 1)
            port.setPos(0, y)

        for i, port in enumerate(outs):
            y = h * (i + 1) / (len(outs) + 1)
            port.setPos(self.WIDTH, y)

    # ---------------- sync back to graph ----------------

    def itemChange(self, change, value):
        if change == QGraphicsItem.ItemPositionHasChanged:
            self.node.pos = (value.x(), value.y())
            for edge in self.edges:
                edge.update_path()
        return super().itemChange(change, value)

    # ---------------- helpers ----------------

    def add_edge(self, edge):
        self.edges.append(edge)

    # ---------------- UI 外部接口 ----------------

    def toggle_breakpoint(self):
        self._breakpoint = not self._breakpoint
        self.node.params["breakpoint"] = self._breakpoint
        self._update_breakpoint_style()

    def set_exec_state(self, state: ExecState):
        self._exec_state = state
        self._update_execution_style()
        self.refresh_summary()

    def sync_from_node(self):
        self.title_item.setPlainText(self.node.title)
        self._breakpoint = bool(self.node.params.get("breakpoint"))
        self._update_breakpoint_style()
        self.refresh_summary()

    def refresh_summary(self, ctx=None):
        node_def = self.node.get_definition()
        text = node_def.summary(self.node, ctx)
        self.summary_item.setPlainText(text)

# ============================================================
# Edge Items
# ============================================================


class FlowEdgeTempItem(QGraphicsPathItem):
    def __init__(self, src_port: FlowPortItem):
        super().__init__()
        self.src_port = src_port
        self.setZValue(-1)

        pen = QPen(QColor("#888888"), 1, Qt.DashLine)
        pen.setCapStyle(Qt.RoundCap)
        self.setPen(pen)

    def update_path(self, end_pos):
        """重建贝塞尔曲线路径"""
        p1 = self.src_port.scenePos()
        p2 = end_pos

        path = QPainterPath(p1)

        dx = (p2.x() - p1.x()) * 0.5
        c1 = QPointF(p1.x() + dx, p1.y())
        c2 = QPointF(p2.x() - dx, p2.y())

        path.cubicTo(c1, c2, p2)
        self.setPath(path)


class FlowEdgeItem(QGraphicsPathItem):
    def __init__(self, src_port_item: FlowPortItem, dst_port_item: FlowPortItem, edge: FlowEdge):
        super().__init__()

        self.src_port_item = src_port_item
        self.dst_port_item = dst_port_item
        self.edge = edge  # FlowEdge（可选，纯引用）

        self.setFlag(QGraphicsItem.ItemIsSelectable, True)
        self.setAcceptHoverEvents(True)
        self.setZValue(-1)  # draw behind nodes

        pen = QPen(QColor("#444444"), 2)
        pen.setCapStyle(Qt.RoundCap)
        self.setPen(pen)

        self.default_pen = pen
        self.hover_pen = QPen(QColor("#ff8800"), 3)
        self.last_pen = self.default_pen

        self._show_arrow = True  # 默认显示箭头
        self._arrow_item = None  # 箭头图形项

        self._setup_debug_point()
        self._setup_arrow()
        self.update_path()

    # ---------- Interaction ----------

    def shape(self):
        stroker = QPainterPathStroker()
        stroker.setWidth(10)   # 👈 交互宽度（和视觉解耦）
        return stroker.createStroke(self.path())

    def hoverEnterEvent(self, event):
        self.last_pen = self.pen()
        self.setPen(self.hover_pen)
        super().hoverEnterEvent(event)

    def hoverLeaveEvent(self, event):
        self.setPen(self.last_pen)
        super().hoverLeaveEvent(event)

    # ---------- 外部 UI 接口 ----------

    def update_path(self):
        """重建贝塞尔曲线路径"""
        p1 = self.src_port_item.scenePos()
        p2 = self.dst_port_item.scenePos()

        path = QPainterPath(p1)
        self.setPen(self.default_pen)

        dx = (p2.x() - p1.x()) * 0.5
        dy = 0
        if p1.x() > p2.x():
            dx = 100
            dy = 200 - abs(p1.y() - p2.y())
            if dy < 0:
                dy = 0

            pen = QPen(QColor("#888888"), 1, Qt.DashLine)
            pen.setCapStyle(Qt.RoundCap)
            self.setPen(pen)

        c1 = QPointF(p1.x() + dx, p1.y() - dy)
        c2 = QPointF(p2.x() - dx, p2.y() - dy)

        if self._debug:
            self._debug_c1.setPos(c1)
            self._debug_c2.setPos(c2)

        path.cubicTo(c1, c2, p2)
        self.setPath(path)

        # 更新箭头位置和方向
        if self._show_arrow:
            angle = path.angleAtPercent(1.0)

            t = QTransform()
            t.translate(p2.x(), p2.y())  # 移动到终点
            t.rotate(-angle)            # 旋转角度

            self._arrow_item.setTransform(t)

    def set_exec_state(self, state: ExecState):
        self._exec_state = state
        self._update_style()

    def toggle_debug(self):
        self._debug = not self._debug
        self._debug_c1.setVisible(self._debug)
        self._debug_c2.setVisible(self._debug)
        self.update_path()

    def toggle_arrow(self):
        self._show_arrow = not self._show_arrow
        self._arrow_item.setVisible(self._show_arrow)
        self.update_path()

    # ---------- 内部 UI ----------

    def _setup_arrow(self):
        """初始化箭头图形项"""
        _arrow_item = QGraphicsPathItem(self)
        _arrow_item.setZValue(1)
        _arrow_item.setBrush(Qt.GlobalColor.black)

        arrow_size = 8
        arrow_head = QPolygonF([
            QPointF(0, 0),
            QPointF(-arrow_size, arrow_size / 2),
            QPointF(-arrow_size, -arrow_size / 2)
        ])
        arrow_path = QPainterPath()
        arrow_path.addPolygon(arrow_head)
        _arrow_item.setPath(arrow_path)
        self._arrow_item = _arrow_item

    def _setup_debug_point(self):
        _debug_c1 = QGraphicsEllipseItem(-3, -3, 6, 6, self)
        _debug_c1.setPos(0, 0)
        _debug_c1.setZValue(10)
        _debug_c1.setPen(self.hover_pen)

        _debug_c2 = QGraphicsEllipseItem(-3, -3, 6, 6, self)
        _debug_c2.setPos(0, 0)
        _debug_c2.setZValue(10)
        _debug_c2.setPen(self.default_pen)

        self._debug_c1 = _debug_c1
        self._debug_c2 = _debug_c2
        self._debug = False
        self._debug_c1.setVisible(self._debug)
        self._debug_c2.setVisible(self._debug)

    def _update_style(self):
        self.last_pen = self.pen()
        if self._exec_state == ExecState.ACTIVE:
            self.setPen(QPen(QColor("#FF9800"), 4))

        elif self._exec_state == ExecState.DONE:
            self.setPen(QPen(QColor("#64B5F6"), 2))

        else:
            self.setPen(QPen(QColor("#444444"), 2))

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @property
    def src_port(self):
        return self.edge.src_port

    @property
    def dst_port(self):
        return self.edge.dst_port
