"""
Flow Graph Layout Engine with Semantic Ordering Rules

架构设计:
- LevelComputer: 计算节点层级 (x坐标)
- OrderRule: 定义同层节点排序规则 (y坐标)
- LayoutEngine: 整合层级计算和排序规则,生成最终布局
"""
from collections import defaultdict, deque
from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Callable, Any
from dataclasses import dataclass

# ============================================================================
# 配置常量
# ============================================================================
X_GAP = 220  # 水平间距
Y_GAP = 120  # 垂直间距


# ============================================================================
# 规则系统 - 用于同层节点的排序
# ============================================================================
@dataclass
class NodeContext:
    """节点上下文信息，供排序规则使用"""
    node_id: str
    node_type: str
    level: int
    graph: Any  # FlowGraph
    
    @property
    def incoming_edges(self):
        """获取指向该节点的边"""
        return self.graph.incoming(self.node_id)
    
    @property
    def outgoing_edges(self):
        """获取从该节点出发的边"""
        return self.graph.outgoing(self.node_id)
    
    def get_source_port(self) -> Optional[str]:
        """获取入边的源端口名称（如果有）"""
        edges = self.incoming_edges
        if edges:
            return edges[0].src_port
        return None


class OrderRule(ABC):
    """
    节点排序规则基类
    
    子类需要实现 compare 方法，返回比较结果：
    - 负数: node_a 应该在 node_b 上面（y值更小）
    - 正数: node_a 应该在 node_b 下面（y值更大）
    - 0: 无法决定顺序，由其他规则或默认规则决定
    """
    
    name: str = "base_rule"
    priority: int = 100  # 优先级，数字越小越优先
    
    @abstractmethod
    def compare(self, a: NodeContext, b: NodeContext) -> int:
        """
        比较两个节点的相对位置
        返回: <0 (a在上), >0 (a在下), 0 (不确定)
        """
        pass
    
    def applies_to(self, ctx: NodeContext) -> bool:
        """判断此规则是否适用于给定节点，默认总是适用"""
        return True


class LoopPortOrderRule(OrderRule):
    """
    Loop节点端口排序规则：
    - 从 loop 端口出来的节点总在 exit 端口的上面
    
    示例场景:
        LoopNode
           ├── loop ──> NodeA
           └── exit ──> NodeB
        
        如果 NodeA 和 NodeB 在同一层，则 NodeA 在 NodeB 上方
    """
    
    name = "loop_port_order"
    priority = 10  # 高优先级
    
    PORT_PRIORITY = {
        "loop": 0,   # loop 端口优先级高（排前面，y值小）
        "exit": 1,   # exit 端口优先级低（排后面，y值大）
    }
    
    def compare(self, a: NodeContext, b: NodeContext) -> int:
        port_a = a.get_source_port()
        port_b = b.get_source_port()
        
        # 只处理来自 Loop 节点的边
        # 检查源节点是否是 loop 类型
        edges_a = a.incoming_edges
        edges_b = b.incoming_edges
        
        is_from_loop_a = False
        is_from_loop_b = False
        
        if edges_a:
            src_node_a = a.graph.nodes.get(edges_a[0].src_node)
            is_from_loop_a = src_node_a and src_node_a.type == "loop"
        
        if edges_b:
            src_node_b = b.graph.nodes.get(edges_b[0].src_node)
            is_from_loop_b = src_node_b and src_node_b.type == "loop"
        
        # 如果都不是来自 loop，不干预
        if not is_from_loop_a and not is_from_loop_b:
            return 0
        
        # 获取端口优先级
        prio_a = self.PORT_PRIORITY.get(port_a, 99)
        prio_b = self.PORT_PRIORITY.get(port_b, 99)
        
        return prio_a - prio_b


class IfPortOrderRule(OrderRule):
    """
    If节点端口排序规则：
    - true 端口出来的节点在 false 端口的上面
    
    示例场景:
        IfNode
          ├── true  ──> NodeA
          └── false ──> NodeB
        
        如果 NodeA 和 NodeB 在同一层，则 NodeA 在 NodeB 上方
    """
    
    name = "if_port_order"
    priority = 20
    
    PORT_PRIORITY = {
        "true": 0,   # true 端口在上面
        "false": 1,  # false 端口在下面
    }
    
    def compare(self, a: NodeContext, b: NodeContext) -> int:
        edges_a = a.incoming_edges
        edges_b = b.incoming_edges
        
        is_from_if_a = False
        is_from_if_b = False
        
        if edges_a:
            src_node_a = a.graph.nodes.get(edges_a[0].src_node)
            is_from_if_a = src_node_a and src_node_a.type == "if"
        
        if edges_b:
            src_node_b = b.graph.nodes.get(edges_b[0].src_node)
            is_from_if_b = src_node_b and src_node_b.type == "if"
        
        if not is_from_if_a and not is_from_if_b:
            return 0
        
        port_a = a.get_source_port()
        port_b = b.get_source_port()
        
        prio_a = self.PORT_PRIORITY.get(port_a, 99)
        prio_b = self.PORT_PRIORITY.get(port_b, 99)
        
        return prio_a - prio_b


class DefaultIdOrderRule(OrderRule):
    """
    默认规则：按节点ID字母顺序排序（保证稳定性）
    """
    
    name = "default_id_order"
    priority = 999  # 最低优先级
    
    def compare(self, a: NodeContext, b: NodeContext) -> int:
        if a.node_id < b.node_id:
            return -1
        elif a.node_id > b.node_id:
            return 1
        return 0


# ============================================================================
# 层级计算器
# ============================================================================
class LevelComputer:
    """
    计算每个节点在DAG中的层级（水平位置）
    
    算法基于拓扑排序思想（Kahn算法的变体）：
    1. 找到所有起始节点（没有入边的节点）
    2. BFS遍历，每个节点的层级 = max(所有前置节点层级) + 1
    """
    
    def compute(self, graph) -> Dict[str, int]:
        levels = {}
        
        # 找到所有起始节点（没有入边的节点）
        all_nodes = set(graph.nodes.keys())
        nodes_with_incoming = set()
        for edge in graph.edges.values():
            nodes_with_incoming.add(edge.dst_node)
        start_nodes = all_nodes - nodes_with_incoming
        
        # 如果没有起始节点但有节点，说明有环，任选一个作为起点
        if not start_nodes and all_nodes:
            # 优先选择 type="start" 的节点
            for node_id, node in graph.nodes.items():
                if node.type == "start":
                    start_nodes = {node_id}
                    break
            if not start_nodes:
                start_nodes = {next(iter(all_nodes))}
        
        # 初始化队列：所有起始节点 level = 0
        queue = []
        for nid in start_nodes:
            levels[nid] = 0
            queue.append(nid)
        
        processed = set()
        
        while queue:
            nid = queue.pop(0)
            
            if nid in processed:
                continue
            processed.add(nid)
            
            current_level = levels[nid]
            
            for e in graph.outgoing(nid):
                next_id = e.dst_node
                candidate_level = current_level + 1
                
                # 更新层级为最大值
                if next_id not in levels or levels[next_id] < candidate_level:
                    levels[next_id] = candidate_level
                
                if next_id not in processed:
                    queue.append(next_id)
        
        return levels


# ============================================================================
# 布局引擎
# ============================================================================
class LayoutEngine:
    """
    布局引擎：整合层级计算和排序规则
    
    使用方式:
        engine = LayoutEngine([
            LoopPortOrderRule(),
            IfPortOrderRule(),
            DefaultIdOrderRule(),
        ])
        positions = engine.layout(graph)
    """
    
    def __init__(self, rules: Optional[List[OrderRule]] = None):
        self.level_computer = LevelComputer()
        self.rules = rules or self._default_rules()
        # 按优先级排序规则
        self.rules.sort(key=lambda r: r.priority)
    
    def _default_rules(self) -> List[OrderRule]:
        """返回默认的规则列表"""
        return [
            LoopPortOrderRule(),
            IfPortOrderRule(),
            DefaultIdOrderRule(),
        ]
    
    def layout(self, graph) -> Dict[str, tuple]:
        """
        执行布局计算
        
        Returns:
            Dict[node_id, (x, y)]
        """
        # Step 1: 计算层级
        levels = self.level_computer.compute(graph)
        
        # Step 2: 按层级分组
        level_groups = self._group_by_level(levels)
        
        # Step 3: 对每层应用排序规则，然后计算坐标
        positions = {}
        for lvl in sorted(level_groups.keys()):
            node_ids = level_groups[lvl]
            sorted_nodes = self._sort_nodes(node_ids, lvl, graph)
            
            x = lvl * X_GAP
            for i, nid in enumerate(sorted_nodes):
                y = i * Y_GAP
                positions[nid] = (x, y)
        
        return positions
    
    def _group_by_level(self, levels: Dict[str, int]) -> Dict[int, List[str]]:
        """按层级分组节点"""
        groups = defaultdict(list)
        for nid, lvl in levels.items():
            groups[lvl].append(nid)
        return dict(groups)
    
    def _sort_nodes(self, node_ids: List[str], level: int, graph) -> List[str]:
        """
        使用规则系统对同层节点进行排序
        """
        # 创建节点上下文
        contexts = {
            nid: NodeContext(
                node_id=nid,
                node_type=graph.nodes[nid].type,
                level=level,
                graph=graph
            )
            for nid in node_ids
        }
        
        # 自定义比较函数
        def compare(a_id: str, b_id: str) -> int:
            a_ctx = contexts[a_id]
            b_ctx = contexts[b_id]
            
            # 依次应用规则，直到某个规则能做出决定
            for rule in self.rules:
                result = rule.compare(a_ctx, b_ctx)
                if result != 0:
                    return result
            
            return 0
        
        # Python 3 中 sort 不再接受 cmp 参数，使用 key 转换
        from functools import cmp_to_key
        return sorted(node_ids, key=cmp_to_key(compare))


# ============================================================================
# 便捷API
# ============================================================================
def dag_layout(graph) -> Dict[str, tuple]:
    """
    DAG 自动布局（带语义排序规则）
    
    当前支持的规则:
    - Loop节点: loop端口出来的节点在exit端口上方
    - If节点: true端口出来的节点在false端口上方
    - 默认: 按节点ID稳定排序
    
    Args:
        graph: FlowGraph 实例
        
    Returns:
        Dict[node_id, (x, y)] 坐标映射
    """
    engine = LayoutEngine()
    return engine.layout(graph)


# ============================================================================
# 扩展规则示例（供参考）
# ============================================================================
class CustomOrderRule(OrderRule):
    """
    示例：自定义排序规则模板
    
    可以继承 OrderRule 实现自己的排序逻辑，例如：
    - 按节点类型排序（action节点在前，if节点在后）
    - 按连接权重排序
    - 按节点参数排序
    """
    
    name = "custom_example"
    priority = 50
    
    def compare(self, a: NodeContext, b: NodeContext) -> int:
        # 示例：action 类型的节点排在最上面
        if a.node_type == "action" and b.node_type != "action":
            return -1
        if b.node_type == "action" and a.node_type != "action":
            return 1
        return 0
