from typing import Optional, Dict, List, Any
from abc import ABC, abstractmethod

from .graph import FlowNode, PortSpec, PortDirection, FlowType


class NodeDefinition(ABC):
    """
    节点“能力定义”
    - ports
    - param schema
    - execution behavior
    """

    type: str  # e.g. "if", "action"

    # ---------- structure ----------

    @abstractmethod
    def ports(self) -> List[PortSpec]:
        ...

    def default_params(self, node: Optional[FlowNode] = None) -> Dict[str, Any]:
        """
        根据 schema 生成默认参数
        """
        params = {}
        for key, meta in self.param_schema(node).items():
            params[key] = meta.get("default")
        return params


    def param_schema(self, node: Optional[FlowNode] = None) -> Dict[str, dict]:
        return {}

    def summary(self, node: FlowNode, ctx=None) -> str:
        """
        返回用于 UI 展示的摘要文本
        ctx=None 表示编辑态
        ctx!=None 表示运行态
        """
        return node.runtime_state.get("summary", node.summary or "")

    # ---------- execution ----------

    @abstractmethod
    def execute(
        self,
        node: FlowNode,
        ctx
    ) -> Optional[str]:
        """
        执行节点
        返回 out_port 名称
        返回 None 表示流程结束
        """
        ...


class StartNodeDef(NodeDefinition):
    type = "start"

    def _summary(self, node, ctx=None):
        vars_init = node.params.get("vars", {})
        if not vars_init:
            return "Initialize: <none>"

        keys = ", ".join(vars_init.keys())
        return f"Init vars: {keys}"

    def ports(self):
        return [
            PortSpec("out", PortDirection.OUT),
        ]

    def param_schema(self, node=None):
        return {
            "vars": {
                "type": "dict",
                "label": "",
                "widget": "dict_editor",
                "key_type": "str",
                "value_type": "any",
                "default": {},
                "help": "Variables initialized at start of execution",
            }
        }

    def execute(self, node, ctx):
        init_vars = node.params.get("vars", {})

        if init_vars:
            ctx.vars.update(init_vars)
            ctx.log(f"Start init vars: {init_vars}")
        else:
            ctx.log("Start init vars: <none>")

        node.runtime_state["summary"] = self._summary(node, ctx)

        return "out"


class IfNodeDef(NodeDefinition):
    type = "if"

    def _summary(self, node, ctx=None):
        expr = node.params.get("condition", "")

        if ctx:
            try:
                result = bool(eval(expr, {}, ctx.vars))
                return f"{expr} → {result}"
            except:
                return f"{expr} → error"

        return f"If: {expr}"

    def ports(self):
        return [
            PortSpec("in", PortDirection.IN),
            PortSpec("true", PortDirection.OUT),
            PortSpec("false", PortDirection.OUT),
        ]

    def param_schema(self, node=None):
        return {
            "condition": {
                "type": "expr",
                "label": "Condition",
                "widget": "line_edit",
                "default": "",
                "placeholder": "e.g. x > 10",
                "help": "Python expression, evaluated at runtime",
            }
        }

    def execute(self, node, ctx):
        expr = node.params.get("condition", "")

        try:
            result = bool(eval(
                expr,
                {},             # 不给 globals（安全第一步）
                ctx.vars        # 只允许访问运行变量
            ))
        except Exception as e:
            ctx.log(f"If condition error: {expr} ({e})")
            result = False

        node.runtime_state["summary"] = self._summary(node, ctx)

        ctx.log(f"If condition `{expr}` => {result}")
        return "true" if result else "false"


class LoopNodeDef(NodeDefinition):
    type = "loop"

    def _summary(self, node, ctx=None):
        expr = node.params.get("while_expr", "")
        max_iter = node.params.get("max_iter", 100)

        if ctx and node.id in ctx.nodes_states:
            executed = ctx.nodes_states[node.id].get("executed", 0)
            return f"Loop {executed}/{max_iter}"

        return f"While: {expr}"

    def ports(self):
        return [
            PortSpec("in", PortDirection.IN),
            PortSpec("loop", PortDirection.OUT),
            PortSpec("exit", PortDirection.OUT),
        ]

    def param_schema(self, node=None):
        return {
            "while_expr": {
                "type": "expr",
                "label": "While Condition",
                "widget": "line_edit",
                "default": "",
                "help": "Expression evaluated before each loop iteration",
            },
            "max_iter": {
                "type": "int",
                "label": "Max Iterations",
                "widget": "spin_int",
                "default": 100,
                "min": 1,
                "help": "Safety limit to avoid infinite loops",
            }
        }

    def execute(self, node, ctx):
        ctx.nodes_states.setdefault(node.id, {"executed": 0})
        expr = node.params.get("while_expr", "")
        max_iter = int(node.params.get("max_iter", 100))
        executed = ctx.nodes_states[node.id].get("executed", 0)

        node.runtime_state["summary"] = self._summary(node, ctx)

        if executed >= max_iter:
            ctx.log(f"Loop max_iter reached ({executed}/ {max_iter})")
            ctx.nodes_states[node.id].pop("executed")
            return "exit"

        # 计算 while_expr
        try:
            result = bool(eval(expr, {}, ctx.vars))
        except Exception as e:
            ctx.log(f"Loop expr error: {e}")
            ctx.nodes_states[node.id].pop("executed")
            return "exit"

        if result:
            ctx.nodes_states[node.id]["executed"] = executed + 1
            ctx.log(f"Loop {executed + 1}/{max_iter}")
            return "loop"
        else:
            ctx.log("Loop exit")
            ctx.nodes_states[node.id].pop("executed")
            return "exit"


class EndNodeDef(NodeDefinition):
    type = "end"

    def ports(self):
        return [
            PortSpec("in", PortDirection.IN),
        ]

    def execute(self, node, ctx):
        return None


class SetVarNodeDef(NodeDefinition):
    type = "set"

    def _summary(self, node, ctx=None):
        var = node.params.get("var", "")
        expr = node.params.get("expr", "")

        if ctx and var in ctx.vars:
            return f"{var} = {ctx.vars[var]}"

        return f"{var} = {expr}"

    def ports(self):
        return [
            PortSpec("in", PortDirection.IN),
            PortSpec("out", PortDirection.OUT),
        ]

    def param_schema(self, node=None):
        return {
            "var": {"type": "string"},
            "expr": {"type": "string"},
        }

    def execute(self, node, ctx):
        expr = node.params.get("expr", "")
        var = node.params.get("var", "[undefined]")
        try:
            value = eval(
                expr,
                {},             # 不给 globals（安全第一步）
                ctx.vars        # 只允许访问运行变量
            )
            ctx.vars[var] = value
        except Exception as e:
            ctx.log(f"SetVarNodeDef error: {expr} ({e})")

        node.runtime_state["summary"] = self._summary(node, ctx)

        return "out"
