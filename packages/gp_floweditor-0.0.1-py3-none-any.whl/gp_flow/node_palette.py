# node_palette.py
from PySide6.QtWidgets import QListWidget, QListWidgetItem
from PySide6.QtCore import Qt, QMimeData
from PySide6.QtGui import QDrag

from .graph import KIND_LIST


class FlowNodeList(QListWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setDragEnabled(True)
        self.setSelectionMode(QListWidget.SingleSelection)

        for kind in KIND_LIST:
            item = QListWidgetItem(kind)
            item.setData(Qt.UserRole, kind)
            self.addItem(item)

    def startDrag(self, supportedActions):
        item = self.currentItem()
        if not item:
            return

        kind = item.data(Qt.UserRole)

        mime = QMimeData()
        mime.setData(
            "application/x-flow-node",
            kind.encode("utf-8")
        )

        drag = QDrag(self)
        drag.setMimeData(mime)
        drag.exec(Qt.CopyAction)
