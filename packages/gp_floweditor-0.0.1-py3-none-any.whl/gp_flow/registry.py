from typing import Dict
from .node_def import (
    NodeDefinition, StartNodeDef, EndNodeDef,
    IfNodeDef, LoopNodeDef, SetVarNodeDef,
)
from .action_def import ActionNodeDef


NODE_DEFINITIONS: Dict[str, NodeDefinition] = {
    StartNodeDef.type: StartNodeDef(),
    EndNodeDef.type: EndNodeDef(),
    IfNodeDef.type: IfNodeDef(),
    LoopNodeDef.type: LoopNodeDef(),
    ActionNodeDef.type: ActionNodeDef(),
    SetVarNodeDef.type: SetVarNodeDef(),
}


def register_node(defn: NodeDefinition):
    if defn.type in NODE_DEFINITIONS:
        raise RuntimeError(f"Duplicate node type: {defn.type}")
    NODE_DEFINITIONS[defn.type] = defn


def get_node_def(node_type: str) -> NodeDefinition:
    try:
        return NODE_DEFINITIONS[node_type]
    except KeyError:
        raise RuntimeError(f"No NodeDefinition for type: {node_type}")
