"""
Flow Graph 验证规则系统

设计原则:
1. 规则与节点定义分离，但通过 NodeDefinition 获取元数据
2. 通用规则自动适用于所有节点类型
3. 特定规则处理特殊逻辑（如 start/end 数量限制）
4. 新增节点类型时，只需在 NodeDefinition 中标记端口属性
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Set, Optional

from .graph import FlowGraph, PortDirection, FlowType


@dataclass
class FlowRuleViolation:
    """规则违反记录"""
    message: str
    nodes: list = field(default_factory=list)
    edges: list = field(default_factory=list)
    severity: str = "error"  # error, warning, info

    def __repr__(self):
        return f"FlowRuleViolation({self.severity}: {self.message})"


class FlowRule(ABC):
    """规则基类"""
    name: str = ""
    description: str = ""

    @abstractmethod
    def check(self, graph: FlowGraph) -> list[FlowRuleViolation]:
        """
        检查图是否违反此规则

        Args:
            graph: 要检查的流程图

        Returns:
            违反记录列表，空列表表示无违反
        """
        ...


# =============================================================================
# 特定规则 - 处理特殊节点类型的约束
# =============================================================================

class SingleStartRule(FlowRule):
    """
    必须有且只能有一个 Start 节点

    每个流程图必须有一个入口点，多个 start 节点会造成歧义
    """
    name = "single_start"
    description = "必须有且只能有一个 Start 节点"

    def check(self, graph: FlowGraph) -> list[FlowRuleViolation]:
        starts = [n for n in graph.nodes.values() if n.type == "start"]
        count = len(starts)

        if count == 0:
            return [
                FlowRuleViolation(
                    message="缺少 Start 节点",
                    severity="error"
                )
            ]

        if count > 1:
            return [
                FlowRuleViolation(
                    message=f"只能有一个 Start 节点，当前有 {count} 个",
                    nodes=starts,
                    severity="error"
                )
            ]

        return []


class AtLeastOneEndRule(FlowRule):
    """
    至少有一个 End 节点

    流程图应该有明确的结束点，没有 end 节点可能是未完成的设计
    """
    name = "at_least_one_end"
    description = "至少有一个 End 节点"

    def check(self, graph: FlowGraph) -> list[FlowRuleViolation]:
        ends = [n for n in graph.nodes.values() if n.type == "end"]

        if len(ends) == 0:
            return [
                FlowRuleViolation(
                    message="缺少 End 节点",
                    severity="warning"
                )
            ]

        return []


class IfNodeBranchRule(FlowRule):
    """
    If 节点必须有 true / false 两条出边

    If 节点是条件分支，必须同时定义 true 和 false 两个出口
    """
    name = "if_branch"
    description = "If 节点需要 true / false 两条出口"

    REQUIRED_PORTS = {"true", "false"}

    def check(self, graph: FlowGraph) -> list[FlowRuleViolation]:
        violations = []

        for node in graph.nodes.values():
            if node.type != "if":
                continue

            # 收集已连接的出端口
            connected_ports: Set[str] = set()
            for edge in graph.edges.values():
                if edge.src_node == node.id:
                    connected_ports.add(edge.src_port)

            # 检查是否包含所有必需端口
            missing = self.REQUIRED_PORTS - connected_ports
            if missing:
                violations.append(
                    FlowRuleViolation(
                        message=f"If 节点 `{node.id}` 缺少出口: {', '.join(sorted(missing))}",
                        nodes=[node],
                        severity="error"
                    )
                )

        return violations


# =============================================================================
# 通用规则 - 自动适用于所有节点类型
# =============================================================================

class RequiredPortsRule(FlowRule):
    """
    检查所有必需端口是否已连接

    从 NodeDefinition 读取端口定义，自动检查 required=True 的端口
    """
    name = "required_ports"
    description = "检查必需端口是否已连接"

    def check(self, graph: FlowGraph) -> list[FlowRuleViolation]:
        violations = []

        for node in graph.nodes.values():
            node_def = node.get_definition()
            ports = node_def.ports()

            # 获取该节点的所有已连接端口
            connected_in: Set[str] = set()
            connected_out: Set[str] = set()

            for edge in graph.edges.values():
                if edge.dst_node == node.id:
                    connected_in.add(edge.dst_port)
                if edge.src_node == node.id:
                    connected_out.add(edge.src_port)

            # 检查每个必需端口
            for port_spec in ports:
                if not port_spec.required:
                    continue

                if port_spec.direction == PortDirection.IN:
                    if port_spec.name not in connected_in:
                        violations.append(
                            FlowRuleViolation(
                                message=f"节点 `{node.id}` ({node.type}) 的输入端口 `{port_spec.name}` 未连接",
                                nodes=[node],
                                severity="error"
                            )
                        )

                elif port_spec.direction == PortDirection.OUT:
                    if port_spec.name not in connected_out:
                        violations.append(
                            FlowRuleViolation(
                                message=f"节点 `{node.id}` ({node.type}) 的输出端口 `{port_spec.name}` 未连接",
                                nodes=[node],
                                severity="error"
                            )
                        )

        return violations


class NoOrphanNodesRule(FlowRule):
    """
    检测孤立节点

    既没有输入也没有输出的节点（除了 start 和 end）
    """
    name = "no_orphan_nodes"
    description = "检测孤立节点"

    EXCLUDED_TYPES = {"start", "end"}

    def check(self, graph: FlowGraph) -> list[FlowRuleViolation]:
        violations = []

        for node in graph.nodes.values():
            if node.type in self.EXCLUDED_TYPES:
                continue

            has_input = any(e.dst_node == node.id for e in graph.edges.values())
            has_output = any(e.src_node == node.id for e in graph.edges.values())

            if not has_input and not has_output:
                violations.append(
                    FlowRuleViolation(
                        message=f"节点 `{node.id}` ({node.type}) 是孤立节点",
                        nodes=[node],
                        severity="warning"
                    )
                )

        return violations


# =============================================================================
# 规则注册表
# =============================================================================

# 默认启用的规则列表
DEFAULT_RULES: list[FlowRule] = [
    SingleStartRule(),      # 必须有且只能有一个 start
    AtLeastOneEndRule(),    # 至少一个 end
    RequiredPortsRule(),    # 检查必需端口
    IfNodeBranchRule(),     # If 节点分支检查
    NoOrphanNodesRule(),    # 孤立节点检测
]


def validate_graph(graph: FlowGraph, rules: Optional[list[FlowRule]] = None) -> list[FlowRuleViolation]:
    """
    验证流程图

    Args:
        graph: 要验证的流程图
        rules: 要应用的规则列表，默认使用 DEFAULT_RULES

    Returns:
        所有违反记录的列表
    """
    if rules is None:
        rules = DEFAULT_RULES

    all_violations = []

    for rule in rules:
        try:
            violations = rule.check(graph)
            all_violations.extend(violations)
        except Exception as e:
            all_violations.append(
                FlowRuleViolation(
                    message=f"规则 `{rule.name}` 执行失败: {e}",
                    severity="error"
                )
            )

    return all_violations
