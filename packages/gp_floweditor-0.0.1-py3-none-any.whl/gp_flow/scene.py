from typing import Optional
from PySide6.QtWidgets import QGraphicsScene, QMenu, QMessageBox
from PySide6.QtCore import Signal, Qt, QRectF, QPoint
from PySide6.QtGui import QKeyEvent, QKeySequence, QTransform

from .item import (
    FlowNodeItem,
    FlowEdgeItem,
    FlowPortItem,
    FlowEdgeTempItem,
    ExecState,
)
from .graph import FlowGraph, PortDirection
from .rule import DEFAULT_RULES, validate_graph, FlowRuleViolation
from .undo import UndoStack


class FlowScene(QGraphicsScene):
    """
    Scene = Graph 的在线投影 + 控制流裁判

    - Graph 是唯一数据真相
    - Scene 是唯一 Graph 修改入口
    - Item 永远不参与业务判断
    """

    node_selected = Signal(object)           # FlowNode
    edge_created = Signal(object)            # FlowEdge
    structure_changed = Signal(list)         # list[FlowRuleViolation]

    def __init__(self, graph: FlowGraph):
        super().__init__()

        self.graph = graph
        self.undo_stack = UndoStack()

        # 使用新的规则系统
        self.rules = DEFAULT_RULES

        # ---- 运行期状态 ----
        self._node_items = {}
        self._edge_items = {}

        self.temp_edge: Optional[FlowEdgeTempItem] = None
        self.drag_src_port: Optional[FlowPortItem] = None
        self._highlighted_port: Optional[FlowPortItem] = None

    # ============================================================
    # Port hit-test / highlight
    # ============================================================

    def _port_at(self, scene_pos) -> Optional[FlowPortItem]:
        radius = 8
        area = QRectF(
            scene_pos.x() - radius,
            scene_pos.y() - radius,
            radius * 2,
            radius * 2,
        )

        for item in self.items(area):
            if isinstance(item, FlowPortItem):
                return item
            p = item.parentItem()
            if isinstance(p, FlowPortItem):
                return p

        return None

    def _highlight_port(self, port: Optional[FlowPortItem]):
        if port is self._highlighted_port:
            return

        if self._highlighted_port:
            self._highlighted_port.set_highlighted(False)

        self._highlighted_port = None

        if self.drag_src_port and port:
            if self.can_connect_ports(self.drag_src_port, port):
                port.set_highlighted(True)
                self._highlighted_port = port

    # ============================================================
    # 连接裁判（Scene 的核心）
    # ============================================================

    def can_connect_ports(
        self,
        src: FlowPortItem,
        dst: FlowPortItem,
    ) -> bool:
        """
        UI-level connection judge.
        Does NOT guarantee execution validity.
        """
        # 原则 1: 方向必须是 OUT -> IN
        if src.spec.direction != PortDirection.OUT:
            return False
        if dst.spec.direction != PortDirection.IN:
            return False

        # 原则 2: 类型必须匹配 (CONTROL -> CONTROL)
        if src.spec.flow_type != dst.spec.flow_type:
            return False

        # 原则 3: 禁止自连
        if src.node_item is dst.node_item:
            return False

        return True

    # ============================================================
    # Graph 写操作（唯一入口）
    # ============================================================

    def _connect_to(
        self,
        src_port_item: FlowPortItem,
        dst_port_item: FlowPortItem,
    ):
        self.undo_stack.push(self.graph)

        src_node_item = src_port_item.node_item
        dst_node_item = dst_port_item.node_item
        edge = self.graph.add_edge(
            src_node_item.node.id,
            src_port_item.spec.name,
            dst_node_item.node.id,
            dst_port_item.spec.name,
        )
        self.edge_created.emit(edge)
        self.rebuild()

    # ============================================================
    # 删除
    # ============================================================

    def _delete_selection(self):
        items = self.selectedItems()

        nodes = [i for i in items if isinstance(i, FlowNodeItem)]
        edges = [i for i in items if isinstance(i, FlowEdgeItem)]

        for node in nodes:
            self._delete_node_item(node)

        for edge in edges:
            if edge.scene():
                self._delete_edge_item(edge)

    def _delete_node_item(self, node_item: FlowNodeItem):
        self.undo_stack.push(self.graph)

        removed_edges = self.graph.remove_node(node_item.node.id)

        for edge in removed_edges:
            edge_item = self._find_edge_item(edge)
            if edge_item:
                self._remove_edge_item(edge_item)

        self.removeItem(node_item)
        self._after_structure_changed()

    def _delete_edge_item(self, edge_item: FlowEdgeItem):
        self.undo_stack.push(self.graph)

        if edge_item.edge:
            self.graph.remove_edge(edge_item.edge.id)

        self._remove_edge_item(edge_item)
        self._after_structure_changed()

    def _remove_edge_item(self, edge_item: FlowEdgeItem):
        src_node = edge_item.src_port_item.node_item
        dst_node = edge_item.dst_port_item.node_item

        if edge_item in src_node.edges:
            src_node.edges.remove(edge_item)
        if edge_item in dst_node.edges:
            dst_node.edges.remove(edge_item)

        self.removeItem(edge_item)

    def _find_edge_item(self, edge):
        for item in self.items():
            if isinstance(item, FlowEdgeItem) and item.edge == edge:
                return item
        return None

    # ============================================================
    # 规则系统
    # ============================================================

    def _check_rules(self) -> list[FlowRuleViolation]:
        """检查图是否违反规则"""
        return validate_graph(self.graph, self.rules)

    def _after_structure_changed(self):
        """结构变化后调用，执行规则检查"""
        violations = self._check_rules()
        # 发射信号通知外部UI组件
        self.structure_changed.emit(violations)

    # ============================================================
    # Qt Events
    # ============================================================

    def mousePressEvent(self, event):
        port = self._port_at(event.scenePos())

        if port and port.spec.direction == PortDirection.OUT:
            self.drag_src_port = port
            self.temp_edge = FlowEdgeTempItem(port)
            self.addItem(self.temp_edge)
            event.accept()
            return

        super().mousePressEvent(event)

        item = self.itemAt(event.scenePos(), self.views()[0].transform())
        if isinstance(item, FlowNodeItem):
            self.node_selected.emit(item.node)

    def mouseMoveEvent(self, event):
        if self.temp_edge:
            self.temp_edge.update_path(event.scenePos())
            self._highlight_port(self._port_at(event.scenePos()))
            event.accept()
            return

        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        if self.temp_edge and self.drag_src_port:
            dst_port = self._port_at(event.scenePos())
            self.removeItem(self.temp_edge)

            if dst_port and self.can_connect_ports(self.drag_src_port, dst_port):
                self._connect_to(
                    self.drag_src_port,
                    dst_port,
                )

            self.temp_edge = None
            self.drag_src_port = None
            self._highlight_port(None)
            event.accept()
            return

        super().mouseReleaseEvent(event)

    def keyPressEvent(self, event: QKeyEvent):
        if event.matches(QKeySequence.Undo):
            self.undo()
            return
        if event.matches(QKeySequence.Redo):
            self.redo()
            return
        if event.key() == Qt.Key_Delete:
            self._delete_selection()
            return
        if event.matches(QKeySequence.SelectAll):
            self._select_all_items()
            return

        super().keyPressEvent(event)

    def _select_all_items(self):
        """全选所有节点和边"""
        for item in self.items():
            if isinstance(item, (FlowNodeItem, FlowEdgeItem)):
                item.setSelected(True)

    # ============================================================
    # 上下文菜单
    # ============================================================
    def _show_node_menu(self, pos: QPoint, item: FlowNodeItem):
        menu = QMenu()
        menu.addAction("Delete", lambda item=item: self._delete_node_item(item))
        menu.addAction("Toggle Breakpoint", item.toggle_breakpoint)

        menu.exec(pos)

    def _show_edge_menu(self, pos: QPoint, item: FlowEdgeItem):
        menu = QMenu()
        menu.addAction("Delete", lambda item=item: self._delete_edge_item(item))
        menu.addAction("Toggle Debug", item.toggle_debug)
        menu.addAction("Toggle Arrow", item.toggle_arrow)

        menu.exec(pos)

    def contextMenuEvent(self, event):
        item = self.itemAt(event.scenePos(), self.views()[0].transform())

        if isinstance(item, FlowNodeItem):
            self._show_node_menu(event.screenPos(), item)
        if isinstance(item, FlowEdgeItem):
            self._show_edge_menu(event.screenPos(), item)
        else:
            return super().contextMenuEvent(event)

    # ============================================================
    # Undo / Redo
    # ============================================================

    def undo(self):
        self.graph = self.undo_stack.undo(self.graph)
        self.rebuild()

    def redo(self):
        self.graph = self.undo_stack.redo(self.graph)
        self.rebuild()

    # ===============================
    # Layout
    # ===============================

    def apply_layout(self, positions):
        for node_id, (x, y) in positions.items():
            item = self._node_items.get(node_id)
            if item:
                item.setPos(x, y)

    # ============================================================
    # Build / Rebuild
    # ============================================================

    def rebuild(self):
        self.clear_scene()
        self.build_from_graph()
        self._after_structure_changed()

    def clear_scene(self):
        for item in list(self.items()):
            if isinstance(item, FlowNodeItem):
                item.edges.clear()
            self.removeItem(item)

    def build_from_graph(self):
        node_items = {}
        edge_items = {}

        # Nodes
        for node in self.graph.nodes.values():
            item = FlowNodeItem(node)
            self.addItem(item)
            item.setPos(*node.pos)
            node_items[node.id] = item

        # Edges
        for edge in self.graph.edges.values():
            src_node = node_items.get(edge.src_node)
            dst_node = node_items.get(edge.dst_node)
            if not src_node or not dst_node:
                continue

            src_port = src_node.port_items.get(edge.src_port)
            dst_port = dst_node.port_items.get(edge.dst_port)
            if not src_port or not dst_port:
                continue

            edge_item = FlowEdgeItem(src_port, dst_port, edge)
            self.addItem(edge_item)
            key = edge.key()
            edge_items[key] = edge_item

            src_node.add_edge(edge_item)
            dst_node.add_edge(edge_item)

        self._node_items = node_items
        self._edge_items = edge_items

    # ============================================================
    # 外部UI接口
    # ============================================================
    def activate_node(self, node_id: str):
        item = self._node_items.get(node_id)
        if item:
            item.set_exec_state(ExecState.ACTIVE)
        else:
            print(f"[FlowScene] Node {node_id} not found")

    def mark_node_done(self, node_id: str):
        item = self._node_items.get(node_id)
        if item:
            item.set_exec_state(ExecState.DONE)

    def activate_edge(self, src_node_id, src_port):
        item = self._edge_items.get((src_node_id, src_port))
        if item:
            item.set_exec_state(ExecState.ACTIVE)
        else:
            print(f"[FlowScene] Edge {src_node_id}->{src_port} not found")

    def reset_execution_states(self):
        self.graph.clear_runtime_state()
        for item in self.items():
            if isinstance(item, (FlowNodeItem, FlowEdgeItem)):
                item.set_exec_state(ExecState.IDLE)


    def show_finished(self):
        QMessageBox.information(self.parent(), "提示", "执行完毕")