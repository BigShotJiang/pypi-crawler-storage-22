from PySide6.QtCore import QObject, Signal
from enum import Enum

from .item import FlowPortItem, FlowNodeItem, FlowEdgeItem


class SelectionKind(Enum):
    NODE = "node"
    EDGE = "edge"
    PORT = "port"


class Selection:
    def __init__(self, kind, item, target):
        self.kind = kind      # SelectionKind
        self.item = item      # FlowNodeItem / FlowEdgeItem / FlowPortItem
        self.target = target  # FlowNode / FlowEdge / PortSpec


class SelectionRouter(QObject):
    """
    Scene selection → Semantic selection
    """

    selection_changed = Signal(list)  # list[Selection]

    def __init__(self, scene):
        super().__init__()
        self.scene = scene
        self.scene.selectionChanged.connect(self._on_scene_selection)

    def _on_scene_selection(self):
        selections = []
        if self.scene is not None: 
            try:
                for item in self.scene.selectedItems():
                    if isinstance(item, FlowNodeItem):
                        selections.append(
                            Selection(
                                SelectionKind.NODE,
                                item,
                                item.node
                            )
                        )
                    elif isinstance(item, FlowEdgeItem):
                        selections.append(
                            Selection(
                                SelectionKind.EDGE,
                                item,
                                item.edge
                            )
                        )
                    elif isinstance(item, FlowPortItem):
                        selections.append(
                            Selection(
                                SelectionKind.PORT,
                                item,
                                item.spec
                            )
                        )
            
            except RuntimeError as e:
                if "already deleted" in str(e):
                    self.scene = None

        self.selection_changed.emit(selections)
