from .graph import FlowGraph, clone_graph

class UndoStack:
    def __init__(self):
        self.undo_stack = []
        self.redo_stack = []

    def push(self, graph: FlowGraph):
        snapshot = clone_graph(graph)
        self.undo_stack.append(snapshot)
        self.redo_stack.clear()

    def can_undo(self):
        return len(self.undo_stack) > 0

    def can_redo(self):
        return len(self.redo_stack) > 0

    def undo(self, current_graph):
        if not self.can_undo():
            return current_graph

        self.redo_stack.append(clone_graph(current_graph))
        return self.undo_stack.pop()

    def redo(self, current_graph):
        if not self.can_redo():
            return current_graph

        self.undo_stack.append(clone_graph(current_graph))
        return self.redo_stack.pop()
