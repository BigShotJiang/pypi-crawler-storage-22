from PySide6.QtWidgets import (
    QGraphicsView, QMessageBox, QMenu
)
from PySide6.QtGui import QPainter, QAction
from PySide6.QtCore import QTimer, Qt, QPointF, Signal

from gp_tm.models import ACTION_MIME_TYPE, ActionRegistry
from .graph import FlowGraph, FlowNode, FlowEdge
from .scene import FlowScene
from .layout import dag_layout
from .exec_ctrl import ExecutionController
from .selection import SelectionRouter, SelectionKind
from .rule import FlowRuleViolation

from .overlay import ViewOverlayLayer, ZoomIndicator, MiniConsole, RuntimeStatusCard
from .widgets import RuleStatusWidget


class FlowView(QGraphicsView):
    node_selected = Signal(object)  # FlowNode
    edge_selected = Signal(object)  # FlowEdge
    step_finished = Signal(dict)

    def __init__(self, graph: FlowGraph):
        super().__init__()
        self.setRenderHints(QPainter.Antialiasing)
        self.setDragMode(QGraphicsView.RubberBandDrag)
        self.setAcceptDrops(True)

        self.graph = graph
        self.router = None
        self.scene = None
        self.controller = None
        self._last_secction = None

        self._setup_ui()
        self.set_graph(graph)

    def _setup_ui(self):
        """设置UI布局"""

        self.overlay = ViewOverlayLayer(self.viewport())
        self.overlay.setGeometry(self.viewport().rect())

        self.rule_status = RuleStatusWidget()
        self.rule_status._overlay_pos = "top-left"

        self.zoom_indicator = ZoomIndicator(self)
        self.console = MiniConsole(self)
        self.runtime_card = RuntimeStatusCard(self)

        self.overlay.add_widget(self.rule_status)
        self.overlay.add_widget(self.zoom_indicator)
        self.overlay.add_widget(self.console)
        self.overlay.add_widget(self.runtime_card)

    def set_graph(self, graph: FlowGraph):
        if self.controller:
            self.controller.reset()
            self.router = None

        if self.router:
            self.router.selection_changed.disconnect(self._on_selection_changed)
            self.router = None

        if self.scene:
            self.scene.clear()
            self.scene.deleteLater()
            self.scene = None

        self.graph = graph
        self.scene = FlowScene(graph)
        self.scene.structure_changed.connect(self._on_structure_changed)
        self.scene.graph = graph
        self.setScene(self.scene)
        self.scene.rebuild()
        self.controller = ExecutionController(self.graph, self.scene)
        self.router = SelectionRouter(self.scene)
        self.router.selection_changed.connect(self._on_selection_changed)

        # 设置定时器定期更新日志显示
        self.timer = QTimer()
        self.timer.timeout.connect(self._update_log_display)
        self.timer.start(1000)  # 每秒更新一次
        self.step_finished.connect(lambda _: self._update_log_display())

    def _update_log_display(self):
        """更新日志显示"""
        if self.controller and self.controller.ctx:
            self.console.clear()
            for log in self.controller.ctx.logs:
                self.console.log(log)
            status = "Idle" if self.controller.ctx.finished else (
                     "Running" if self.controller.running else
                     "Paused")
            self.runtime_card.set_status(status)

    def _on_structure_changed(self, violations: list[FlowRuleViolation]):
        """处理结构变化信号"""
        if self.rule_status:
            self.rule_status.update_violations(violations)

    def auto_layout(self):
        positions = dag_layout(self.graph)
        self.scene.apply_layout(positions)
        # 调整视图以适应新布局
        # self.fitInView(self.scene.itemsBoundingRect(), Qt.KeepAspectRatio)
        self.centerOn(self.scene.itemsBoundingRect().center())

    # ---------- 运行 & 调试 ----------

    def step_once(self):
        fi = self.controller.step_once()
        self.step_finished.emit(self.controller.ctx.vars)

    def continue_run(self):
        self.runtime_card.set_status("Running")
        self.controller.continue_run()

    def pause(self):
        self.controller.pause()
        self.runtime_card.set_status("Paused")

    # ---------- drag & drop ----------

    def dragEnterEvent(self, event):
        if event.mimeData().hasFormat("application/x-flow-node"):
            event.acceptProposedAction()
        elif event.mimeData().hasFormat(ACTION_MIME_TYPE):
            event.acceptProposedAction()
        else:
            event.ignore()

    def dragMoveEvent(self, event):
        self.dragEnterEvent(event)

    def dropEvent(self, event):
        mime = event.mimeData()
        if mime.hasFormat("application/x-flow-node"):
            self._drop_flow_node(event.position().toPoint(), mime)
            event.acceptProposedAction()
        elif mime.hasFormat(ACTION_MIME_TYPE):
            self._drop_action_node(event.position().toPoint(), mime)
            event.acceptProposedAction()
        else:
            event.ignore()
            return

    def _drop_flow_node(self, pos, mime):
        kind = bytes(mime.data("application/x-flow-node")).decode("utf-8")

        # 视图坐标 → scene 坐标
        scene_pos = self.mapToScene(pos)

        node = FlowNode(
            type=kind,
            pos=(scene_pos.x(), scene_pos.y())
        )

        self.graph.add_node(node)
        self.scene.rebuild()

    def _drop_action_node(self, pos, mime):
        action_id = bytes(mime.data(ACTION_MIME_TYPE)).decode("utf-8")

        action = ActionRegistry.get(action_id)
        if not action:
            return

        # 视图坐标 → scene 坐标
        scene_pos = self.mapToScene(pos)

        node = FlowNode(
            type="action",
            action_id=action_id,
            title=action.name,
            summary=action.category,
            pos=(scene_pos.x(), scene_pos.y())
        )

        self.graph.add_node(node)
        self.scene.rebuild()

    # ---------- 节点选择 ----------

    def _on_selection_changed(self, selections):
        # 每次丢失焦点时更新
        if self._last_secction:
            self._last_secction.item.sync_from_node()
            self._last_secction = None

        if not selections:
            self.node_selected.emit(None)
            return

        # 单选 Node
        if len(selections) == 1 and selections[0].kind == SelectionKind.NODE:
            self._last_secction = selections[0]
            node = self._last_secction.target
            self.node_selected.emit(node)
            return

        # 单选 Edge
        if len(selections) == 1 and selections[0].kind == SelectionKind.EDGE:
            edge = selections[0].target
            self.edge_selected.emit(edge)
            return

        # 多选 / 混合
        # self.param_editor.show_multi_selection(selections)

    # ---------- 缩放功能 ----------

    def wheelEvent(self, event):
        """鼠标滚轮缩放"""
        if event.modifiers() == Qt.ControlModifier:
            delta = event.angleDelta().y()
            if delta > 0:
                self.zoom_in()
            else:
                self.zoom_out()
            event.accept()
        else:
            super().wheelEvent(event)

    def zoom_in(self):
        """放大视图"""
        self.scale(1.15, 1.15)
        self.zoom_indicator.update_zoom()

    def zoom_out(self):
        """缩小视图"""
        self.scale(0.87, 0.87)
        self.zoom_indicator.update_zoom()

    def reset_zoom(self):
        """恢复默认缩放"""
        self.resetTransform()
        self.zoom_indicator.update_zoom()

    def keyPressEvent(self, event):
        """键盘快捷键：Ctrl++ 放大，Ctrl+- 缩小，Ctrl+0 恢复默认"""
        if event.modifiers() == Qt.ControlModifier:
            if event.key() == Qt.Key_Plus or event.key() == Qt.Key_Equal:
                self.zoom_in()
                event.accept()
                return
            elif event.key() == Qt.Key_Minus:
                self.zoom_out()
                event.accept()
                return
            elif event.key() == Qt.Key_0:
                self.reset_zoom()
                event.accept()
                return
        super().keyPressEvent(event)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self.overlay.setGeometry(self.viewport().rect())

    # ---------- Ctrl+拖动移动场景 ----------

    def mousePressEvent(self, event):
        """按住Ctrl+左键时切换为手型光标，用于拖动场景"""
        if event.button() == Qt.LeftButton and event.modifiers() == Qt.ControlModifier:
            self.setDragMode(QGraphicsView.ScrollHandDrag)
            self.setCursor(Qt.ClosedHandCursor)
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        """释放鼠标时恢复默认拖动模式和光标"""
        if event.button() == Qt.LeftButton:
            self.setDragMode(QGraphicsView.NoDrag)
            self.unsetCursor()
        super().mouseReleaseEvent(event)

    # ---------- 右键菜单 ----------

    def contextMenuEvent(self, event):
        # 将视图坐标转换为场景坐标
        scene_pos = self.mapToScene(event.pos())

        # 检查点击位置是否有节点
        items_at_pos = self.scene.items(scene_pos)
        item_clicked = len(items_at_pos) > 0

        if item_clicked:
            # 点击在节点上，不显示view的菜单，由graph或scene处理
            # 直接调用父类方法，让scene的contextMenuEvent处理
            super().contextMenuEvent(event)
        else:
            # 点击在空白处，显示view的菜单
            menu = QMenu(self)

            # 运行
            run_action = QAction("运行", self)
            run_action.triggered.connect(self.continue_run)
            menu.addAction(run_action)

            # 暂停
            pause_action = QAction("暂停", self)
            pause_action.triggered.connect(self.pause)
            menu.addAction(pause_action)

            # 单步运行
            step_action = QAction("单步运行", self)
            step_action.triggered.connect(self.step_once)
            menu.addAction(step_action)

            # 自动布局
            layout_action = QAction("自动布局", self)
            layout_action.triggered.connect(self.auto_layout)
            menu.addAction(layout_action)

            # 显示菜单
            menu.exec_(event.globalPos())
