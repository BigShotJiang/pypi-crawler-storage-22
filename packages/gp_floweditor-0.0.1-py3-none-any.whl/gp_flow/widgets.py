from PySide6.QtWidgets import (
    QWidget,
    QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QDialog, QTableWidget, QTableWidgetItem, QHeaderView,
    QAbstractItemView
)
from PySide6.QtGui import QColor, QFont
from .rule import FlowRuleViolation


class RuleViolationsDialog(QDialog):
    """规则违规详情对话框"""

    def __init__(self, violations: list[FlowRuleViolation], parent=None):
        super().__init__(parent)
        self.setWindowTitle("Flow 规则检查")
        self.setMinimumSize(600, 400)
        self.violations = violations
        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)

        # 统计信息
        error_count = sum(1 for v in self.violations if v.severity == "error")
        warning_count = sum(1 for v in self.violations if v.severity == "warning")
        info_count = sum(1 for v in self.violations if v.severity == "info")

        stats_label = QLabel(f"错误: {error_count}  |  警告: {warning_count}  |  信息: {info_count}")
        stats_label.setStyleSheet("font-weight: bold; padding: 5px;")
        layout.addWidget(stats_label)

        # 违规列表表格
        self.table = QTableWidget()
        self.table.setColumnCount(3)
        self.table.setHorizontalHeaderLabels(["级别", "消息", "相关节点"])
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)

        header = self.table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.Stretch)
        header.setSectionResizeMode(2, QHeaderView.ResizeToContents)

        self.table.setRowCount(len(self.violations))

        severity_colors = {
            "error": QColor("#FF4444"),
            "warning": QColor("#FFAA00"),
            "info": QColor("#4488FF")
        }

        for row, violation in enumerate(self.violations):
            # 级别
            severity_item = QTableWidgetItem(violation.severity.upper())
            severity_item.setForeground(severity_colors.get(violation.severity, QColor("#000000")))
            font = severity_item.font()
            font.setBold(True)
            severity_item.setFont(font)
            self.table.setItem(row, 0, severity_item)

            # 消息
            message_item = QTableWidgetItem(violation.message)
            self.table.setItem(row, 1, message_item)

            # 相关节点
            node_names = [n.id for n in violation.nodes] if violation.nodes else []
            edge_info = [f"{e.src_node}->{e.dst_node}" for e in violation.edges] if violation.edges else []
            related = ", ".join(node_names + edge_info)
            if len(related) > 50:
                related = related[:47] + "..."
            self.table.setItem(row, 2, QTableWidgetItem(related))

        layout.addWidget(self.table)

        # 关闭按钮
        close_btn = QPushButton("关闭")
        close_btn.clicked.connect(self.accept)
        layout.addWidget(close_btn)


class RuleStatusWidget(QWidget):
    """规则状态指示器组件"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.violations: list[FlowRuleViolation] = []
        self.setMinimumWidth(220)
        self._setup_ui()

    def _setup_ui(self):
        layout = QHBoxLayout(self)
        layout.setContentsMargins(8, 4, 8, 4)
        layout.setSpacing(8)

        # 状态图标/文字
        self.status_label = QLabel("✓")
        self.status_label.setStyleSheet("""
            QLabel {
                font-size: 14px;
                font-weight: bold;
            }
        """)
        layout.addWidget(self.status_label)

        # 统计文字
        self.stats_label = QLabel("无违规")
        self.stats_label.setStyleSheet("""
            QLabel {
                font-size: 11px;
                color: #666;
            }
        """)
        layout.addWidget(self.stats_label)

        # 详情按钮
        self.detail_btn = QPushButton("详情")
        self.detail_btn.setFixedHeight(22)
        self.detail_btn.setStyleSheet("""
            QPushButton {
                font-size: 10px;
                padding: 2px 8px;
                border: 1px solid #ccc;
                border-radius: 3px;
                background: #f5f5f5;
            }
            QPushButton:hover {
                background: #e0e0e0;
            }
            QPushButton:pressed {
                background: #d0d0d0;
            }
        """)
        self.detail_btn.clicked.connect(self._show_details)
        self.detail_btn.setVisible(False)
        layout.addWidget(self.detail_btn)

        layout.addStretch()

        self.setStyleSheet("""
            RuleStatusWidget {
                background-color: #f8f8f8;
                border-top: 1px solid #ddd;
            }
        """)

    def update_violations(self, violations: list[FlowRuleViolation]):
        """更新违规列表并刷新显示"""
        self.violations = violations

        error_count = sum(1 for v in violations if v.severity == "error")
        warning_count = sum(1 for v in violations if v.severity == "warning")
        info_count = sum(1 for v in violations if v.severity == "info")

        if error_count > 0:
            self.status_label.setText("✗")
            self.status_label.setStyleSheet("QLabel { font-size: 16px; font-weight: bold; color: #FF4444; }")
            self.stats_label.setText(f"{error_count} 错误")
            if warning_count > 0:
                self.stats_label.setText(f"{error_count} 错误, {warning_count} 警告")
            self.detail_btn.setVisible(True)
        elif warning_count > 0:
            self.status_label.setText("!")
            self.status_label.setStyleSheet("QLabel { font-size: 16px; font-weight: bold; color: #FFAA00; }")
            self.stats_label.setText(f"{warning_count} 警告")
            self.detail_btn.setVisible(True)
        elif info_count > 0:
            self.status_label.setText("ℹ")
            self.status_label.setStyleSheet("QLabel { font-size: 14px; font-weight: bold; color: #4488FF; }")
            self.stats_label.setText(f"{info_count} 信息")
            self.detail_btn.setVisible(True)
        else:
            self.status_label.setText("✓")
            self.status_label.setStyleSheet("QLabel { font-size: 14px; font-weight: bold; color: #44AA44; }")
            self.stats_label.setText("无违规")
            self.detail_btn.setVisible(False)

    def _show_details(self):
        """显示违规详情对话框"""
        if self.violations:
            dialog = RuleViolationsDialog(self.violations, self)
            dialog.exec()

