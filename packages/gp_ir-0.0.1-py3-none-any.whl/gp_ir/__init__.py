"""
代码生成模块
提供IR定义、执行、代码生成等核心功能
"""

# IR定义
from .ir import IRNode, IRCall, IRComment, ExecutionPlan

# 运行时
from .context import RuntimeContext
from .executor import IRExecutor

# 调试
from .debug import DebugController

# 运行器
from .runner import CaseRunner, ExecutionListener, ListenableRunner

# 注册系统
from .registry import ContextRegistry, ConverterRegistry, ActionRegistry

# Action定义
from .action import Action

# 转换
from .converter import (
    register_default_converters
)

# 代码生成
from .emitter import emit_python, emit_function
from .template import wrap_python_script, wrap_class_script
from .generator import ScriptGenerator

# 导出所有公共API
__all__ = [
    # IR
    'IRNode', 'IRCall', 'IRComment', 'ExecutionPlan',
    # 运行时
    'RuntimeContext', 'IRExecutor',
    # 调试
    'DebugController',
    # 运行器
    'CaseRunner', 'ExecutionListener', 'ListenableRunner',
    # 注册系统
    'ContextRegistry', 'ConverterRegistry', 'ActionRegistry',
    # Action
    'Action',
    # 转换
    'register_default_converters',
    # 代码生成
    'emit_python', 'emit_function',
    'wrap_python_script', 'wrap_class_script',
    'ScriptGenerator',
]