from dataclasses import dataclass, field
from typing import Dict, Any


@dataclass(frozen=True)
class Action:
    """
    动作定义（模板）
    """
    id: str
    name: str
    category: str
    module: str = "builtin"  # 新增模块属性，默认为builtin
    param_schema: Dict[str, Any] = field(default_factory=dict)

    def default_params(self) -> Dict[str, Any]:
        """
        根据 schema 生成默认参数
        """
        params = {}
        for key, meta in self.param_schema.items():
            params[key] = meta.get("default")
        return params
