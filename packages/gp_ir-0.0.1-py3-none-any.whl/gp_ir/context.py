"""
运行时上下文
提供动作执行环境和变量管理
"""
import time
from typing import Callable, Dict, Any, Optional


class RuntimeContext:
    """
    运行时上下文，提供动作执行环境
    
    不依赖Qt，使用纯Python实现
    """
    
    def __init__(
        self,
        print_callback: Optional[Callable[..., None]] = None
    ):
        self.print_callback = print_callback
        self.variables: Dict[str, Any] = {}
        # 初始化result变量，避免未定义错误
        self.variables['result'] = None

    def sleep(self, ms: int):
        """休眠指定毫秒"""
        self.print(f"Sleeping for {ms} ms")
        time.sleep(ms / 1000.0)

    def assert_condition(self, expr: str):
        """
        断言条件
        
        Args:
            expr: 表达式字符串，可引用variables中的变量
        """
        try:
            result = eval(expr, {"__builtins__": {}}, self.variables)
            assert result, f"Assertion failed: {expr} evaluates to {result}"
        except AssertionError:
            raise
        except Exception as e:
            raise RuntimeError(f"Error evaluating expression '{expr}': {str(e)}")
        
    def set_result_value(self, value):
        """设置result值"""
        self.variables['result'] = value
        self.print(f"Set result to: {value}")
        return value
    
    def set_value(self, key: str, value: Any):
        """设置变量值"""
        self.variables[key] = value
        self.print(f"Set {key} to: {value}")
        return value
    
    def get_value(self, key: str):
        """获取变量值"""
        value = self.variables.get(key, None)
        self.print(f"Get {key}: {value}")
        return value

    def print(self, *args):
        """输出日志"""
        if self.print_callback is not None:
            self.print_callback(*args)
        else:
            print(*args)

    def register_plugin_function(self, func_name: str, func: Callable):
        """注册插件函数（兼容旧接口）"""
        setattr(self, func_name, func)
