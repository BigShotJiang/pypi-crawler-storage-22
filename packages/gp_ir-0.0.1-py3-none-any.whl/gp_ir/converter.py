"""
Action到IR的转换器
使用注册系统实现模型层与代码生成层的解耦
"""
from typing import List, Any

from .ir import IRNode, IRCall, IRComment
from .registry import ConverterRegistry
from .action import Action


# 默认转换器实现
def _convert_action(action: Action) -> List[IRNode]:
    """
    转换Action为IR节点（默认转换器）

    Args:
        action: Action对象

    Returns:
        IR节点列表，包含注释和调用
    """
    return [
        IRComment(origin=action.id, text=f"Action: {action.name}"),
        IRCall(
            origin=action.id,
            func=action.id,  # 直接使用action的id作为函数名
            args=[],
            kwargs=action.param_schema
        )
    ]


def register_default_converters():
    """注册默认转换器"""
    # 注册Action类型的转换器
    ConverterRegistry.register_converter(Action, _convert_action)  # 这里可能需要更合适的类型
