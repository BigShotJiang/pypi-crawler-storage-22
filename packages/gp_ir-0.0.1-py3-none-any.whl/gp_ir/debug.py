"""
调试控制器
使用Python标准库threading实现，替代Qt的QMutex/QWaitCondition
"""
import threading
from typing import Optional, Callable, Any, Set

from .ir import IRNode


class DebugController:
    """
    调试控制器，支持断点、单步执行、暂停/继续
    
    使用threading.Event和Lock实现线程同步，不依赖Qt
    """
    
    def __init__(self):
        self.single_step = False
        self._paused = False
        self._lock = threading.Lock()
        self._resume_event = threading.Event()
        self._resume_event.set()  # 默认状态为运行
        
        # 断点集合，存储 IRNode.origin 值
        self.breakpoints: Set[str] = set()
        
        # 可选的回调函数，用于通知UI状态变化
        self.on_state_changed: Optional[Callable[[str], None]] = None
        self.on_step_changed: Optional[Callable[[IRNode, Any], None]] = None
        self.on_breakpoint_hit: Optional[Callable[[str], None]] = None

    @property
    def paused(self) -> bool:
        """获取当前暂停状态"""
        with self._lock:
            return self._paused

    def wait_if_needed(self, timeout: Optional[float] = None) -> bool:
        """
        如果需要暂停，则等待
        
        Args:
            timeout: 超时时间（秒），None表示无限等待
            
        Returns:
            True表示正常恢复，False表示超时
        """
        if not self._resume_event.is_set():
            self._notify_state_changed("paused")
            result = self._resume_event.wait(timeout)
            self._notify_state_changed("running")
            return result
        return True

    def pause(self):
        """暂停执行"""
        with self._lock:
            self._paused = True
            self._resume_event.clear()
        self._notify_state_changed("paused")

    def resume(self):
        """继续执行"""
        with self._lock:
            self._paused = False
            self.single_step = False
        self._resume_event.set()
        self._notify_state_changed("running")

    def step_once(self):
        """单步执行（执行一步后暂停）"""
        with self._lock:
            self.single_step = True
            self._paused = False
        self._resume_event.set()
        self._notify_state_changed("single_step")

    def add_breakpoint(self, origin: str):
        """
        添加断点
        
        Args:
            origin: IRNode.origin 值
        """
        with self._lock:
            self.breakpoints.add(origin)

    def remove_breakpoint(self, origin: str):
        """
        删除断点
        
        Args:
            origin: IRNode.origin 值
        """
        with self._lock:
            self.breakpoints.discard(origin)

    def clear_breakpoints(self):
        """清空所有断点"""
        with self._lock:
            self.breakpoints.clear()

    def has_breakpoint(self, origin: str) -> bool:
        """
        检查是否存在断点
        
        Args:
            origin: IRNode.origin 值
            
        Returns:
            True表示存在断点，False表示不存在
        """
        with self._lock:
            return origin in self.breakpoints

    def _notify_state_changed(self, state: str):
        """通知状态变化"""
        if self.on_state_changed:
            try:
                self.on_state_changed(state)
            except Exception:
                pass  # 忽略回调异常，避免影响执行

    def _notify_step_changed(self, ir_node: IRNode, origin: Any):
        """通知当前执行的步骤变化"""
        if self.on_step_changed:
            try:
                self.on_step_changed(ir_node, origin)
            except Exception:
                pass  # 忽略回调异常，避免影响执行

    def _notify_breakpoint_hit(self, origin: str):
        """通知命中断点"""
        if self.on_breakpoint_hit:
            try:
                self.on_breakpoint_hit(origin)
            except Exception:
                pass  # 忽略回调异常，避免影响执行

    def reset(self):
        """重置控制器状态"""
        with self._lock:
            self.single_step = False
            self._paused = False
        self._resume_event.set()