"""
代码生成器
将IR节点转换为Python代码
"""
from typing import List

from .ir import IRComment, IRCall, IRNode


def emit_python(ir_nodes: List[IRNode], indent_level: int = 0) -> str:
    """
    将IR节点列表转换为Python代码
    
    Args:
        ir_nodes: IR节点列表
        indent_level: 缩进级别
        
    Returns:
        Python代码字符串
    """
    lines = []

    for node in ir_nodes:
        indent = "    " * indent_level

        if isinstance(node, IRComment):
            lines.append(f"{indent}# {node.text}")
        elif isinstance(node, IRCall):
            args = ", ".join(repr(a) for a in node.args)
            kwargs = ", ".join(f"{k}={v!r}" for k, v in node.kwargs.items())

            params = ", ".join(filter(None, [args, kwargs]))

            lines.append(f"{indent}{node.func}({params})")
        else:
            raise ValueError(f"Invalid IR node: {node}")
        
        # 添加空行分隔
        lines.append("")

    # 清理多余的空行
    cleaned_lines = []
    for i, line in enumerate(lines):
        # 避免连续多个空行
        if line.strip() != "" or (i > 0 and cleaned_lines[-1].strip() != ""):
            cleaned_lines.append(line)

    return "\n".join(cleaned_lines)


def emit_function(
    name: str,
    ir_nodes: List[IRNode],
    args: List[str] = None,
    indent_level: int = 0
) -> str:
    """
    将IR节点列表包装为函数定义
    
    Args:
        name: 函数名
        ir_nodes: IR节点列表
        args: 参数列表
        indent_level: 缩进级别
        
    Returns:
        Python函数代码
    """
    indent = "    " * indent_level
    args_str = ", ".join(args) if args else ""
    
    lines = [
        f"{indent}def {name}({args_str}):",
        emit_python(ir_nodes, indent_level + 1)
    ]
    return "\n".join(lines)