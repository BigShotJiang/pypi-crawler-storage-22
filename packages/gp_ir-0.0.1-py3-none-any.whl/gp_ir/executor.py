"""
IR执行器
执行执行计划
"""
from typing import Optional, Any

from .ir import IRNode, IRCall, ExecutionPlan
from .debug import DebugController


class IRExecutor:
    """
    IR执行器，负责执行ExecutionPlan
    """
    
    def __init__(self, context: Any):
        """
        初始化执行器
        
        Args:
            context: 运行时上下文（RuntimeContext）
        """
        self.ctx = context

    def run(
        self,
        plan: ExecutionPlan,
        debug_ctrl: Optional[DebugController] = None
    ):
        """
        执行ExecutionPlan
        
        Args:
            plan: 执行计划
            debug_ctrl: 调试控制器（可选）
        """
        
        for node in plan.ir_nodes:
            # 如果有调试控制器，检查是否需要暂停
            if debug_ctrl:
                # 检查是否暂停或单步
                debug_ctrl.wait_if_needed()
                
                # 通知当前执行的节点（可用于UI高亮）
                origin = plan.get_origin(node)
                debug_ctrl._notify_step_changed(node, origin)
                
                # 检查是否命中断点
                if debug_ctrl.has_breakpoint(node.origin):
                    debug_ctrl._notify_breakpoint_hit(node.origin)
                    debug_ctrl.pause()
                
                # 如果是单步模式，执行完当前节点后暂停
                if debug_ctrl.single_step:
                    debug_ctrl.pause()

            # 执行IR节点
            if isinstance(node, IRCall):
                self._execute_call(node)
            # IRComment 不需要执行，仅作为注释

    def _execute_call(self, node: IRCall):
        """
        执行函数调用节点
        
        Args:
            node: IRCall节点
        """
        func = getattr(self.ctx, node.func, None)
        if func is None:
            raise RuntimeError(f"Function '{node.func}' not found in context")
        
        result = func(*node.args, **node.kwargs)
        
        # 保存返回值到上下文（用于后续表达式求值）
        if node.func not in ['assert_condition', 'sleep', 'print']:
            self.ctx.variables['result'] = result