"""
脚本生成器
从用例生成完整Python脚本
"""
from typing import Any, List, Optional

from .emitter import emit_python
from .template import wrap_python_script
from .registry import ConverterRegistry


class ScriptGenerator:
    """
    脚本生成器，将用例转换为可执行的Python脚本
    """
    
    def __init__(self, template_func=None, imports: List[str] = None):
        """
        初始化生成器
        
        Args:
            template_func: 自定义模板函数，默认为wrap_python_script
            imports: 额外导入列表
        """
        self.template_func = template_func or wrap_python_script
        self.imports = imports or []

    def generate_from_actions(self, actions: List[Any]) -> str:
        """
        从动作列表生成Python脚本
        
        Args:
            actions: 动作对象列表
            
        Returns:
            完整Python脚本字符串
        """
        ir = ConverterRegistry.convert_all(actions)
        body = emit_python(ir)
        return self.template_func(body, imports=self.imports)

    def generate_from_ir(self, ir_nodes: List[Any]) -> str:
        """
        从IR节点直接生成Python脚本
        
        Args:
            ir_nodes: IR节点列表
            
        Returns:
            完整Python脚本字符串
        """
        body = emit_python(ir_nodes)
        return self.template_func(body, imports=self.imports)