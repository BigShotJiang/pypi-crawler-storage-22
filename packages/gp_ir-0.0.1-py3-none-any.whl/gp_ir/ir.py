from dataclasses import dataclass, field
from typing import Any, Dict, List


@dataclass
class IRNode:
    origin: str = ""
    pass


@dataclass
class IRCall(IRNode):
    func: str = field(default="")
    args: List[Any] = field(default_factory=list)
    kwargs: Dict[str, Any] = field(default_factory=dict)


@dataclass
class IRComment(IRNode):
    text: str = field(default="")


@dataclass
class ExecutionPlan:
    """执行计划，包含 IR 节点列表和来源映射"""
    ir_nodes: List[IRNode]
    origin_map: Dict[str, Any] = field(default_factory=dict)
    
    def get_origin(self, ir_node: IRNode) -> Any:
        """根据 IRNode 获取对应的原始对象"""
        return self.origin_map.get(ir_node.origin)
