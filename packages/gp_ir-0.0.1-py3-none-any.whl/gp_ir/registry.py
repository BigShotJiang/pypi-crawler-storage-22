"""
扩展注册系统
提供Context和Converter的注册机制，支持运行时扩展
"""
from typing import Callable, Dict, List, Type, Any
from functools import wraps
from pathlib import Path
import json
import os
from .ir import IRNode, ExecutionPlan
from .action import Action


class ContextRegistry:
    """
    上下文动作注册器
    用于向RuntimeContext注册自定义动作函数
    """
    _actions: Dict[str, Callable] = {}

    @classmethod
    def register(cls, name: str = None):
        """
        注册动作函数的装饰器
        
        Args:
            name: 动作名称，默认为函数名
        """
        def decorator(func: Callable) -> Callable:
            action_name = name or func.__name__
            cls._actions[action_name] = func
            
            @wraps(func)
            def wrapper(*args, **kwargs):
                return func(*args, **kwargs)
            return wrapper
        return decorator

    @classmethod
    def register_function(cls, name: str, func: Callable):
        """直接注册函数"""
        cls._actions[name] = func

    @classmethod
    def apply_to(cls, context: Any):
        """
        将所有注册的动作应用到上下文实例
        
        Args:
            context: RuntimeContext实例
        """
        for name, func in cls._actions.items():
            setattr(context, name, lambda *args, f=func, **kwargs: f(context, *args, **kwargs))

    @classmethod
    def get_actions(cls) -> Dict[str, Callable]:
        """获取所有注册的动作"""
        return cls._actions.copy()

    @classmethod
    def clear(cls):
        """清空注册表（主要用于测试）"""
        cls._actions.clear()


class ConverterRegistry:
    """
    Action到IR转换器注册器
    用于注册自定义Action类型的转换函数
    """
    _converters: Dict[Type, Callable[[Any], List[IRNode]]] = {}

    @classmethod
    def register(cls, action_type: Type):
        """
        注册转换器的装饰器
        
        Args:
            action_type: Action类类型
        """
        def decorator(func: Callable[[Any], List[IRNode]]) -> Callable[[Any], List[IRNode]]:
            cls._converters[action_type] = func
            return func
        return decorator

    @classmethod
    def register_converter(cls, action_type: Type, converter: Callable[[Any], List[IRNode]]):
        """直接注册转换器"""
        cls._converters[action_type] = converter

    @classmethod
    def convert(cls, action: Any) -> List[IRNode]:
        """
        将Action转换为IR节点列表
        
        Args:
            action: Action对象
            
        Returns:
            IR节点列表
            
        Raises:
            NotImplementedError: 未找到对应的转换器
        """
        # 按类型精确匹配
        if type(action) in cls._converters:
            return cls._converters[type(action)](action)
        
        # 尝试按继承关系查找
        for action_type, converter in cls._converters.items():
            if isinstance(action, action_type):
                return converter(action)

        raise NotImplementedError(
            f"No IR converter registered for action type: {type(action).__name__}"
        )

    @classmethod
    def convert_all(cls, actions: List[Any]) -> List[IRNode]:
        """
        批量转换Action列表
        
        Args:
            actions: Action对象列表
            
        Returns:
            合并后的IR节点列表
        """
        ir_nodes = []
        for action in actions:
            action_ir = cls.convert(action)
            ir_nodes.extend(action_ir)
        return ir_nodes
    
    @classmethod
    def convert_to_plan(cls, actions: List[Any]) -> ExecutionPlan:
        origin_map = {}
        ir_nodes = []
        for action in actions:
            action_ir = cls.convert(action)
            ir_nodes.extend(action_ir)
            _id = getattr(action, "id") if hasattr(action, "id") else None
            if _id: origin_map[_id] = action
        return ExecutionPlan(ir_nodes=ir_nodes, origin_map=origin_map)

    @classmethod
    def get_converters(cls) -> Dict[Type, Callable]:
        """获取所有注册的转换器"""
        return cls._converters.copy()

    @classmethod
    def clear(cls):
        """清空注册表（主要用于测试）"""
        cls._converters.clear()


class ActionRegistry:
    """
    动作注册器
    用于注册和管理Action对象（动作模板）
    """
    _actions: Dict[str, Action] = {}
    _builtin_actions: Dict[str, Action] = {}  # 保存内置动作，用于重置

    @classmethod
    def register(cls, action: Action):
        """注册动作"""
        cls._actions[action.id] = action

    @classmethod
    def get(cls, action_id: str) -> Action:
        """获取指定ID的动作"""
        return cls._actions.get(action_id)

    @classmethod
    def all(cls):
        """获取所有动作"""
        return cls._actions.values()
    
    @classmethod
    def get_by_category(cls, category: str) -> List[Action]:
        """获取指定类别的所有动作"""
        return [action for action in cls._actions.values() if action.category == category]
    
    @classmethod
    def get_by_module(cls, module: str) -> List[Action]:
        """获取指定模块的所有动作"""
        return [action for action in cls._actions.values() if action.module == module]
    
    @classmethod
    def get_categories(cls) -> List[str]:
        """获取所有动作类别"""
        categories = set()
        for action in cls._actions.values():
            categories.add(action.category)
        return sorted(list(categories))
    
    @classmethod
    def get_modules(cls) -> List[str]:
        """获取所有动作模块"""
        modules = set()
        for action in cls._actions.values():
            modules.add(action.module)
        return sorted(list(modules))
    
    @classmethod
    def get_all_ids(cls) -> List[str]:
        """获取所有动作ID"""
        return list(cls._actions.keys())
    
    @classmethod
    def load_from_config(cls, config_path: str = None):
        """从配置文件加载Actions"""
        if config_path is None:
            config_path = (
                Path(__file__)
                .resolve()
                .parent
                / "actions.json"
            )
        if not os.path.exists(config_path):
            raise FileNotFoundError(f"Configuration file not found: {config_path}")
        
        with open(config_path, 'r', encoding='utf-8') as f:
            config = json.load(f)
        
        # 清空现有内置动作
        cls._actions.clear()
        cls._builtin_actions.clear()
        
        for action_data in config.get("actions", []):
            action = Action(
                id=action_data["id"],
                name=action_data["name"],
                category=action_data["category"],
                module="builtin",  # 内置动作的模块设为builtin
                param_schema=action_data.get("param_schema", {})
            )
            cls.register(action)
            cls._builtin_actions[action.id] = action  # 保存内置动作副本

    @classmethod
    def reset_to_builtin_actions(cls):
        """重置为仅内置动作（移除插件动作）"""
        cls._actions.clear()
        for action_id, action in cls._builtin_actions.items():
            cls._actions[action_id] = action

    @classmethod
    def get_builtin_actions(cls):
        """获取内置动作副本"""
        return dict(cls._builtin_actions)