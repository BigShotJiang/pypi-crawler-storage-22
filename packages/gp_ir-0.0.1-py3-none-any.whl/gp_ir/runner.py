"""
案例运行器
使用Python原生回调替代Qt信号机制
"""
import time
import threading
from typing import Callable, List, Optional, Any

from .executor import IRExecutor
from .context import RuntimeContext
from .debug import DebugController
from .ir import ExecutionPlan


class CaseRunner:
    """
    案例运行器，不依赖Qt，使用回调函数进行事件通知
    
    事件回调:
    - on_execution_started: 执行开始时调用 () -> None
    - on_execution_completed: 执行完成时调用 () -> None
    - on_log: 日志输出时调用 (message: str) -> None
    - on_finished: 执行完成时调用 () -> None
    - on_error: 执行出错时调用 (error: str) -> None
    """
    
    def __init__(
        self,
        plan: ExecutionPlan,
        debug_ctrl: Optional[DebugController] = None,
        plugin_manager: Any = None
    ):
        self.plan = plan
        self.debug_ctrl = debug_ctrl
        self.plugin_manager = plugin_manager
        
        # 回调函数
        self.on_execution_started: Optional[Callable[[], None]] = None
        self.on_execution_completed: Optional[Callable[[], None]] = None
        self.on_log: Optional[Callable[[str], None]] = None
        self.on_finished: Optional[Callable[[], None]] = None
        self.on_error: Optional[Callable[[str], None]] = None
        
        self._stop = False
        self._thread: Optional[threading.Thread] = None

    def run(self):
        """
        执行案例（同步方式）
        如需异步执行，请使用 start() 方法
        """
        try:
            ctx = RuntimeContext(
                print_callback=self._on_print
            )
            
            # 应用Registry注册的扩展
            from .registry import ContextRegistry
            ContextRegistry.apply_to(ctx)
            
            # 激活插件
            if self.plugin_manager:
                self.plugin_manager.activate_plugins(ctx)
            
            IRExecutor(ctx).run(self.plan, self.debug_ctrl)
                
        except Exception as e:
            if not self._stop and self.on_error:
                self.on_error(str(e))
            
        if not self._stop and self.on_finished:
            self.on_finished()

    def start(self):
        """在后台线程中启动执行"""
        self._stop = False
        self._thread = threading.Thread(target=self.run, daemon=True)
        self._thread.start()

    def stop(self):
        """停止执行"""
        self._stop = True

    def wait(self, timeout: Optional[float] = None) -> bool:
        """
        等待执行完成
        
        Args:
            timeout: 超时时间（秒）
            
        Returns:
            True表示正常完成，False表示超时
        """
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout)
            return not self._thread.is_alive()
        return True

    # 移除 _on_step 方法，因为不再需要step回调

    def _on_print(self, *args):
        """打印回调"""
        msg = " ".join(str(a) for a in args)
        if self.on_log:
            self.on_log(msg)
        print(msg)


class ExecutionListener:
    """
    执行监听器接口（Java风格）
    如需结构化监听，可继承此类
    """
    
    def on_execution_started(self):
        """执行开始"""
        pass
    
    def on_execution_completed(self):
        """执行完成"""
        pass
    
    def on_log(self, message: str):
        """日志输出"""
        pass
    
    def on_finished(self):
        """执行完成"""
        pass
    
    def on_error(self, error: str):
        """执行错误"""
        pass


class ListenableRunner(CaseRunner):
    """
    支持多监听器的运行器
    允许添加多个ExecutionListener
    """
    
    def __init__(self, plan: ExecutionPlan, debug_ctrl: Optional[DebugController] = None):
        super().__init__(plan, debug_ctrl)
        self._listeners: List[ExecutionListener] = []
    
    def add_listener(self, listener: ExecutionListener):
        """添加监听器"""
        self._listeners.append(listener)
    
    def remove_listener(self, listener: ExecutionListener):
        """移除监听器"""
        if listener in self._listeners:
            self._listeners.remove(listener)
    
    def _on_print(self, *args):
        super()._on_print(*args)
        msg = " ".join(str(a) for a in args)
        for listener in self._listeners:
            try:
                listener.on_log(msg)
            except Exception:
                pass
    
    def run(self):
        try:
            super().run()
            for listener in self._listeners:
                try:
                    listener.on_finished()
                except Exception:
                    pass
        except Exception as e:
            error_msg = str(e)
            for listener in self._listeners:
                try:
                    listener.on_error(error_msg)
                except Exception:
                    pass
            raise