"""
脚本模板
包装生成的代码为可执行脚本
"""
from textwrap import indent
from typing import List


def wrap_python_script(body: str, imports: List[str] = None) -> str:
    """
    将代码体包装为完整Python脚本
    
    Args:
        body: 代码体（已缩进的函数内容）
        imports: 额外导入列表
        
    Returns:
        完整脚本字符串
    """
    import_lines = []
    
    # 默认导入
    import_lines.append("import time")
    
    # 自定义导入
    if imports:
        for imp in imports:
            if imp not in import_lines:
                import_lines.append(imp)
    
    import_section = "\n".join(import_lines)
    
    return f"""\
{import_section}

def run():
{indent(body, " " * 4)}

if __name__ == "__main__":
    run()
"""


def wrap_class_script(
    body: str,
    class_name: str = "TestScript",
    imports: List[str] = None
) -> str:
    """
    将代码体包装为类形式的脚本
    
    Args:
        body: 代码体
        class_name: 类名
        imports: 额外导入列表
        
    Returns:
        完整脚本字符串
    """
    import_lines = ["import time"]
    
    if imports:
        for imp in imports:
            if imp not in import_lines:
                import_lines.append(imp)
    
    import_section = "\n".join(import_lines)
    
    return f"""\
{import_section}

class {class_name}:
    def __init__(self):
        pass
    
    def run(self):
{indent(body, " " * 8)}
    
    def setup(self):
        pass
    
    def teardown(self):
        pass

if __name__ == "__main__":
    script = {class_name}()
    script.setup()
    script.run()
    script.teardown()
"""