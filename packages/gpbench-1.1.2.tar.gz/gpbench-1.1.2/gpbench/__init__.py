"""
GPBench: A benchmarking toolkit for genomic prediction.

This package provides implementations of various genomic prediction methods
including classic linear statistical approaches and machine learning/deep learning methods.
"""

__version__ = "1.0.0"
__author__ = "GPBench Contributors"
__email__ = ""


from ._selftest import run_import_test
def test(verbose=True):
    """
    Run GPBench import self-test.

    Usage:
        import gpbench
        gpbench.test()
    """
    return run_import_test(verbose=verbose)

__all__ = ["test"]

