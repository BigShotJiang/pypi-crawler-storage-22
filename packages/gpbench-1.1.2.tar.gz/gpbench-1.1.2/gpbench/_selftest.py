# gpbench/_selftest.py

import importlib


# 你要测试的所有导入路径（按你提供的41条命令整理）
IMPORT_TESTS = [

    # =========================
    # method_reg methods
    # =========================
    ("gpbench.method_reg.BayesA", "BayesA_reg"),
    ("gpbench.method_reg.BayesB", "BayesB_reg"),
    ("gpbench.method_reg.BayesC", "BayesC_reg"),
    ("gpbench.method_reg.CropARNet", "CropARNet_reg"),
    ("gpbench.method_reg.Cropformer", "Cropformer_reg"),
    ("gpbench.method_reg.DeepCCR", "DeepCCR_reg"),
    ("gpbench.method_reg.DeepGS", "DeepGS_reg"),
    ("gpbench.method_reg.DL_GWAS", "DL_GWAS_reg"),
    ("gpbench.method_reg.DNNGP", "DNNGP_reg"),
    ("gpbench.method_reg.EIR", "EIR_reg"),
    ("gpbench.method_reg.ElasticNet", "ElasticNet_reg"),
    ("gpbench.method_reg.G2PDeep", "G2PDeep_reg"),
    ("gpbench.method_reg.GBLUP", "GBLUP_reg"),
    ("gpbench.method_reg.GEFormer", "GEFormer_reg"),
    ("gpbench.method_reg.LightGBM", "LightGBM_reg"),
    ("gpbench.method_reg.MVP", "MVP_reg"),
    ("gpbench.method_reg.RF", "RF_reg"),
    ("gpbench.method_reg.rrBLUP", "rrBLUP_reg"),
    ("gpbench.method_reg.SoyDNGP", "SoyDNGP_reg"),
    ("gpbench.method_reg.SVC", "SVC_reg"),
    ("gpbench.method_reg.XGBoost", "XGBoost_reg"),

    # =========================
    # method_class methods
    # =========================
    ("gpbench.method_class.BayesA", "BayesA_class"),
    ("gpbench.method_class.BayesB", "BayesB_class"),
    ("gpbench.method_class.BayesC", "BayesC_class"),
    ("gpbench.method_class.CropARNet", "CropARNet_class"),
    ("gpbench.method_class.Cropformer", "Cropformer_class"),
    ("gpbench.method_class.DeepCCR", "DeepCCR_class"),
    ("gpbench.method_class.DeepGS", "DeepGS_class"),
    ("gpbench.method_class.DL_GWAS", "DL_GWAS_class"),
    ("gpbench.method_class.DNNGP", "DNNGP_class"),
    ("gpbench.method_class.EIR", "EIR_class"),
    ("gpbench.method_class.ElasticNet", "ElasticNet_class"),
    ("gpbench.method_class.G2PDeep", "G2PDeep_class"),
    ("gpbench.method_class.GBLUP", "GBLUP_class"),
    ("gpbench.method_class.GEFormer", "GEFormer_class"),
    ("gpbench.method_class.LightGBM", "LightGBM_class"),
    ("gpbench.method_class.RF", "RF_class"),
    ("gpbench.method_class.rrBLUP", "rrBLUP_class"),
    ("gpbench.method_class.SoyDNGP", "SoyDNGP_class"),
    ("gpbench.method_class.SVC", "SVC_class"),
    ("gpbench.method_class.XGBoost", "XGBoost_class"),
]


def run_import_test(verbose=True):
    """
    Run import test for all 41 methods.
    Returns True if all passed, False otherwise.
    """

    print("\n==============================")
    print("   GPBench Import Self Test   ")
    print("==============================\n")

    success = 0
    failed = []

    for module_name, obj_name in IMPORT_TESTS:
        try:
            module = importlib.import_module(module_name)
            obj = getattr(module, obj_name)

            success += 1
            if verbose:
                print(f"[OK]   from {module_name} import {obj_name}")

        except Exception as e:
            failed.append((module_name, obj_name, str(e)))
            print(f"[FAIL] from {module_name} import {obj_name}")
            print(f"       Error: {e}")

    # Summary
    print("\n==============================")
    print("         Test Summary         ")
    print("==============================")
    print(f"Total Methods Tested: {len(IMPORT_TESTS)}")
    print(f"Passed: {success}")
    print(f"Failed: {len(failed)}")

    if failed:
        print("\n❌ Failed Imports:")
        for mod, obj, err in failed:
            print(f" - {mod}.{obj}: {err}")

        print("\nSelf-test FAILED.\n")
        return False

    print("\n✅ All imports passed successfully!\n")
    return True
