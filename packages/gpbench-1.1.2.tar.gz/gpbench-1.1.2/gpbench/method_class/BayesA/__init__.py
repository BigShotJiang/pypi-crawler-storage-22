from .BayesA_class import BayesA_class

BayesA = BayesA_class

__all__ = ["BayesA","BayesA_class"]