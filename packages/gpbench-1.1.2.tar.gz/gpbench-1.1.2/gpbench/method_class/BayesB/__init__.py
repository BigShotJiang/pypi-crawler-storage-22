from .BayesB_class import BayesB_class

BayesB = BayesB_class

__all__ = ["BayesB","BayesB_class"]