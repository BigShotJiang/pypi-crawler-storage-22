from .BayesC_class import BayesC_class

BayesC = BayesC_class
__all__ = ["BayesC","BayesC_class"]