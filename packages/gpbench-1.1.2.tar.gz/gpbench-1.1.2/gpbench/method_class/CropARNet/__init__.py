from .CropARNet_class import CropARNet_class

CropARNet = CropARNet_class

__all__ = ["CropARNet","CropARNet_class"]