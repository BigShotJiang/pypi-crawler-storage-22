from .DL_GWAS_class import DL_GWAS_class

DL_GWAS = DL_GWAS_class

__all__ = ["DL_GWAS","DL_GWAS_class"]