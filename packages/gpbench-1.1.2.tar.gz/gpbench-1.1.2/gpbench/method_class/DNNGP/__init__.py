from .DNNGP_class import DNNGP_class

DNNGP = DNNGP_class

__all__ = ["DNNGP","DNNGP_class"]