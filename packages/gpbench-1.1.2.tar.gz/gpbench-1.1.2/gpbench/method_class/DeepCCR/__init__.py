from .DeepCCR_class import DeepCCR_class

DeepCCR = DeepCCR_class

__all__ = ["DeepCCR","DeepCCR_class"]