import os
import time
import psutil
import swanlab
import argparse
import random
import torch
import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold, train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score, precision_recall_fscore_support
from torch.utils.data import DataLoader, TensorDataset
from .base_deepgs_class import DeepGS
from . import DeepGS_he_class
import pynvml

def parse_args(
        methods='DeepGS/',
        species='Wheat/',
        phe='',
        data_dir='../../data/',
        result_dir='result/',
        genotype_file='genotype.npz',
        phenotype_file='phenotype.npz',
        x_key = 'arr_0',
        y_key = 'arr_0',
        names_key = 'arr_1',
        num_round=6000,
        batch_size=32,
        weight_decay=0.00001,
        momentum=0.5,
        learning_rate=0.01,
        patience=50,
):
    parser = argparse.ArgumentParser()
    parser.add_argument('--methods', type=str, default=methods)
    parser.add_argument('--species', type=str, default=species)
    parser.add_argument('--phe', type=str, default=phe)
    parser.add_argument('--data_dir', type=str, default=data_dir)
    parser.add_argument('--result_dir', type=str, default=result_dir)
    
    parser.add_argument('--num_round', type=int, default=num_round)
    parser.add_argument('--batch_size', type=int, default=batch_size)
    parser.add_argument('--weight_decay', type=float, default=weight_decay)
    parser.add_argument('--momentum', type=float, default=momentum)
    parser.add_argument('--learning_rate', type=float, default=learning_rate)
    parser.add_argument('--patience', type=int, default=patience)

    parser.add_argument('--genotype_file', type=str, default=genotype_file, help='Genotype file name (npz)')
    parser.add_argument('--phenotype_file', type=str, default=phenotype_file, help='Phenotype file name (npz)')
    parser.add_argument('--x_key', type=str, default=x_key, help='Key for genotype array inside npz')
    parser.add_argument('--y_key', type=str, default=y_key, help='Key for phenotype array inside npz')
    parser.add_argument('--names_key', type=str, default=names_key, help='Key for phenotype names inside npz')
    return parser.parse_args()

def load_data(args):
    X = np.load(os.path.join(args.data_dir, args.species, args.genotype_file))[args.x_key]
    Y = np.load(os.path.join(args.data_dir, args.species, args.phenotype_file))[args.y_key]
    names = np.load(os.path.join(args.data_dir, args.species, args.phenotype_file))[args.names_key]

    print("Samples:", X.shape[0], "SNPs:", X.shape[1])
    return X, Y, X.shape[0], X.shape[1], names

def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

def get_gpu_mem_by_pid(pid, handle=None):
    if handle is None:
        return 0.0
    try:
        procs = pynvml.nvmlDeviceGetComputeRunningProcesses(handle)
        for p in procs:
            if p.pid == pid:
                return p.usedGpuMemory / 1024**2
        return 0.0
    except Exception:
        return 0.0

def run_nested_cv(args, data, label, nsnp, num_classes, device, gpu_handle=None):

    result_dir = os.path.join(args.result_dir, args.methods + args.species + args.phe)
    os.makedirs(result_dir, exist_ok=True)

    kf = StratifiedKFold(n_splits=10, shuffle=True, random_state=42)

    all_acc, all_prec, all_rec, all_f1 = [], [], [], []
    cv_start_time = time.time()

    for fold, (train_idx, test_idx) in enumerate(kf.split(data, label)):
        fold_start = time.time()
        process = psutil.Process(os.getpid())
        print(f"\n===== Fold {fold} =====")

        X_train, X_test = data[train_idx], data[test_idx]
        y_train, y_test = label[train_idx], label[test_idx]

        X_tr, X_val, y_tr, y_val = train_test_split(
            X_train, y_train,
            test_size=0.1,
            stratify=y_train,
            random_state=42
        )

        x_tr = torch.from_numpy(X_tr).float().unsqueeze(1).to(device)
        x_val = torch.from_numpy(X_val).float().unsqueeze(1).to(device)
        x_te = torch.from_numpy(X_test).float().unsqueeze(1).to(device)

        y_tr = torch.from_numpy(y_tr).long().to(device)
        y_val = torch.from_numpy(y_val).long().to(device)
        y_te = torch.from_numpy(y_test).long().to(device)

        train_loader = DataLoader(TensorDataset(x_tr, y_tr), args.batch_size, shuffle=True)
        valid_loader = DataLoader(TensorDataset(x_val, y_val), args.batch_size, shuffle=False)
        test_loader  = DataLoader(TensorDataset(x_te, y_te), args.batch_size, shuffle=False)

        model = DeepGS(nsnp, num_classes=num_classes)

        model.train_model(
            train_loader,
            valid_loader,
            args.num_round,
            args.learning_rate,
            args.momentum,
            args.weight_decay,
            args.patience,
            device
        )

        y_pred = model.predict(test_loader)

        acc = accuracy_score(y_test, y_pred)
        prec, rec, f1, _ = precision_recall_fscore_support(
            y_test, y_pred,
            average="macro",
            zero_division=0
        )

        all_acc.append(acc)
        all_prec.append(prec)
        all_rec.append(rec)
        all_f1.append(f1)

        fold_time = time.time() - fold_start
        gpu_mem = get_gpu_mem_by_pid(os.getpid(), gpu_handle)
        cpu_mem = process.memory_info().rss / 1024**2

        print(
            f"Fold {fold}: "
            f"ACC={acc:.4f}, PREC={prec:.4f}, REC={rec:.4f}, F1={f1:.4f}, "
            f"Time={fold_time:.2f}s, GPU={gpu_mem:.2f}MB, CPU={cpu_mem:.2f}MB"
        )

        pd.DataFrame({
            "Y_test": y_test,
            "Y_pred": y_pred
        }).to_csv(os.path.join(result_dir, f"fold{fold}.csv"), index=False)

        torch.cuda.empty_cache()


def DeepGS_class(
        methods='DeepGS/',
        species='Wheat/',
        species_list=["Human/Sim/"],
        phe='',
        data_dir='../../data/',
        result_dir='result/',
        seed=42,
        genotype_file='genotype.npz',
        phenotype_file='phenotype.npz',
        x_key = 'arr_0',
        y_key = 'arr_0',
        names_key = 'arr_1',
        num_round=6000,
        batch_size=32,
        weight_decay=0.00001,
        momentum=0.5,
        learning_rate=0.01,
        patience=50,
        device = "cuda:0" if torch.cuda.is_available() else "cpu", 
):
    set_seed(seed)
    gpu_handle = None
    try:
        if torch.cuda.is_available():
            pynvml.nvmlInit()
            gpu_handle = pynvml.nvmlDeviceGetHandleByIndex(0)
    except Exception as e:
        print(f"Warning: GPU monitoring initialization failed: {e}")
        gpu_handle = None

    args = parse_args(
        methods=methods,
        species=species,
        phe=phe,
        data_dir=data_dir,
        result_dir=result_dir,
        genotype_file=genotype_file,
        phenotype_file=phenotype_file,
        x_key=x_key,
        y_key=y_key,
        names_key=names_key,
        num_round=num_round,
        batch_size=batch_size,
        weight_decay=weight_decay,
        momentum=momentum,
        learning_rate=learning_rate,
        patience=patience
    )
    device = torch.device(device=device)

    all_species = species_list

    for species in all_species:
        args.species = species
        X, Y, nsamples, nsnp, names = load_data(args)

        print("Starting:", args.methods + args.species)
        label_raw = np.nan_to_num(Y[:, 0])
        le = LabelEncoder()
        label = le.fit_transform(label_raw)
        num_classes = len(le.classes_)

        best_params = DeepGS_he_class.Hyperparameter(X, label, nsnp)
        args.learning_rate = best_params['learning_rate']
        args.batch_size = best_params['batch_size']
        args.momentum = best_params['momentum']
        args.weight_decay = best_params['weight_decay']
        args.patience = best_params['patience']

        start_time = time.time()
        run_nested_cv(args, X, label, nsnp, num_classes, device, gpu_handle)
        elapsed_time = time.time() - start_time
        print(f"Total running time: {elapsed_time:.2f}s")
        print("Successfully finished:", args.species, args.phe)


if __name__ == "__main__":
    DeepGS_class(
        methods='DeepGS/',
        species='Wheat/',
        species_list=["Human/Sim/"],
        phe='',
        data_dir='../../../data/',
        result_dir='result/',
        seed=42,
        genotype_file='genotype.npz',
        phenotype_file='phenotype.npz',
        x_key = 'arr_0',
        y_key = 'arr_0',
        names_key = 'arr_1',
        num_round=6000,
        batch_size=32,
        weight_decay=0.00001,
        momentum=0.5,
        learning_rate=0.01,
        patience=50,
        device = "cuda:0" if torch.cuda.is_available() else "cpu", 
    )
