from .DeepGS_class import DeepGS_class

DeepGS = DeepGS_class

__all__ = ["DeepGS","DeepGS_class"]