from .EIR_class import EIR_class

EIR = EIR_class

__all__ = ["EIR","EIR_class"]