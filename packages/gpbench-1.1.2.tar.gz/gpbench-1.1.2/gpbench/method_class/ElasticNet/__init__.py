from .ElasticNet_class import ElasticNet_class

ElasticNet = ElasticNet_class

__all__ = ["ElasticNet","ElasticNet_class"]