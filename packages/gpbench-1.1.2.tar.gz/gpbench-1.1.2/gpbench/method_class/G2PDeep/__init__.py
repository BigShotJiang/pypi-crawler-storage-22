from .G2Pdeep_class import G2PDeep_class

G2PDeep = G2PDeep_class

__all__ = ["G2PDeep","G2PDeep_class"]