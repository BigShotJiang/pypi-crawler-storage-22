from .GBLUP_class import GBLUP_class

GBLUP = GBLUP_class

__all__ = ["GBLUP","GBLUP_class"]