from .LightGBM_class import LightGBM_class

LightGBM = LightGBM_class

__all__ = ["LightGBM","LightGBM_class"]