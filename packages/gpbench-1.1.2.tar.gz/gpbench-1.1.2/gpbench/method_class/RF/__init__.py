from .RF_GPU_class import RF_class

RF = RF_class

__all__ = ["RF","RF_class"]