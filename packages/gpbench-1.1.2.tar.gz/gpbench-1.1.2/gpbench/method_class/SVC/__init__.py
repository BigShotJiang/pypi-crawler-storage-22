from .SVC_GPU import SVC_class

SVC = SVC_class

__all__ = ["SVC","SVC_class"]