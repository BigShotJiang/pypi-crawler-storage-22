from .SoyDNGP_class import SoyDNGP_class

SoyDNGP = SoyDNGP_class

__all__ = ["SoyDNGP","SoyDNGP_class"]