from .XGboost_GPU_class import XGBoost_class

XGBoost = XGBoost_class

__all__ = ["XGBoost","XGBoost_class"]