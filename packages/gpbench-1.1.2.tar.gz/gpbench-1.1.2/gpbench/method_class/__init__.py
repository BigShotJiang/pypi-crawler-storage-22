
#==============================================================
#使用示例:
#import method_class
#print(method_class.METHODS)
#m = method_class.load_method("BayesA")
#print(m)  # method_class.BayesA

#或

#from method_class.BayesA import BayesA_class
#BayesA_class()
#==============================================================
from __future__ import annotations
import importlib
from typing import List

METHODS: List[str] = [
    "BayesA",
    "BayesB",
    "BayesC",
    "LightGBM",
    "CropARNet",
    "Cropformer",
    "DeepCCR",
    "DeepGS",
    "DNNGP",
    "EIR",
    "G2PDeep",
    "GBLUP",
    "GEFormer",
    "RF",
    "rrBLUP",
    "SoyDNGP",
    "SVC",
    "XGBoost",
    "ElasticNet",
    "DL_GWAS"
]

__all__ = ["METHODS", "load_method"]

def load_method(name: str):
    """
    动态加载某个方法子包并返回该子包模块对象
    用法:
      m = method_class.load_method("BayesA")
      # m 里面就是 method_class.BayesA 包
    """
    if name not in METHODS:
        raise ValueError(f"Unknown method '{name}'. Available: {METHODS}")
    return importlib.import_module(f"{__name__}.{name}")
