from .rrBLUP_class import rrBLUP_class

rrBLUP = rrBLUP_class

__all__ = ["rrBLUP","rrBLUP_class"]