from .BayesA import BayesA_reg

BayesA = BayesA_reg

__all__ = ["BayesA","BayesA_reg"]