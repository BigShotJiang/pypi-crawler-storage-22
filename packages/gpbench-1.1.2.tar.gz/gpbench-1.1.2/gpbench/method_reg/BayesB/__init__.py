from .BayesB import BayesB_reg

BayesB = BayesB_reg

__all__ = ["BayesB","BayesB_reg"]