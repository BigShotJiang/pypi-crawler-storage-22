from .BayesC import BayesC_reg

BayesC = BayesC_reg

__all__ = ["BayesC","BayesC_reg"]