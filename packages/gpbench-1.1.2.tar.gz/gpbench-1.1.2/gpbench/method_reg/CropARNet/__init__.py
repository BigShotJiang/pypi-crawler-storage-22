from .CropARNet import CropARNet_reg

CropARNet = CropARNet_reg

__all__ = ["CropARNet","CropARNet_reg"]