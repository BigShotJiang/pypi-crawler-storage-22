import argparse
import random
import torch
import numpy as np
import pandas as pd
import torch.nn as nn
import time, psutil, os 
import torch.optim as optim 
from torch.optim import Adam
from torch.nn import MSELoss
from lightning.pytorch import LightningModule
from sklearn.model_selection import KFold
from torch.utils.data  import DataLoader, TensorDataset 
from sklearn.preprocessing  import StandardScaler
from sklearn.metrics  import mean_absolute_error, mean_squared_error, r2_score
from . import Cropformer_Hyperparameters
import pynvml

def parse_args(
        methods='Cropformer/',
        species='Chickpea/GSTP012/',
        phe='',
        data_dir='../../data/',
        result_dir='result/',
        genotype_file='genotype.npz',
        phenotype_file='phenotype.npz',
        x_key = 'arr_0',
        y_key = 'arr_0',
        names_key = 'arr_1',
        lr = 0.01,
        num_head = 1,
        dropout = 0.5,
        batch_size = 32,
        hidden_dim = 64,
        kernel_size = 3,
        patience = 5,
    ):
    parser = argparse.ArgumentParser(description="Argument parser")
    parser.add_argument('--methods', type=str, default=methods, help='Random seed')
    parser.add_argument('--species', type=str, default=species, help='Dataset name')
    parser.add_argument('--phe', type=str, default=phe, help='Dataset name')
    parser.add_argument('--data_dir', type=str, default=data_dir, help='Path to data directory')
    parser.add_argument('--result_dir', type=str, default=result_dir, help='Path to result directory')
    parser.add_argument('--lr', type=float, default=lr,help='Learning rate')
    parser.add_argument('--num_head', type=int, default=num_head, help='Number of attention heads')
    parser.add_argument('--dropout', type=float, default=dropout, help='Dropout probability')
    parser.add_argument('--batch_size', type=int, default=batch_size, help='Batch size')
    parser.add_argument('--hidden_dim', type=int, default=hidden_dim, help='Hidden dimension')
    parser.add_argument('--kernel_size', type=int, default=kernel_size, help='Kernel size')
    parser.add_argument('--patience', type=int, default=patience, help='Patience for early stopping')
    parser.add_argument('--genotype_file', type=str, default=genotype_file, help='Genotype file name (npz)')
    parser.add_argument('--phenotype_file', type=str, default=phenotype_file, help='Phenotype file name (npz)')
    parser.add_argument('--x_key', type=str, default=x_key, help='Key for genotype array inside npz')
    parser.add_argument('--y_key', type=str, default=y_key, help='Key for phenotype array inside npz')
    parser.add_argument('--names_key', type=str, default=names_key, help='Key for phenotype names inside npz')
    args = parser.parse_args()
    return args

def load_data(args):
    xData = np.load(os.path.join(args.data_dir, args.species, args.genotype_file))[args.x_key]
    yData = np.load(os.path.join(args.data_dir, args.species, args.phenotype_file))[args.y_key]
    names = np.load(os.path.join(args.data_dir, args.species, args.phenotype_file))[args.names_key]

    nsample = xData.shape[0]
    nsnp = xData.shape[1]
    print("Number of samples: ", nsample)
    print("Number of SNPs: ", nsnp)
    return xData, yData, nsample, nsnp, names

class LayerNorm(nn.Module):
    def __init__(self, hidden_size, eps=1e-12):
        super(LayerNorm, self).__init__()
        self.weight = nn.Parameter(torch.ones(hidden_size))
        self.bias = nn.Parameter(torch.zeros(hidden_size))
        self.variance_epsilon = eps

    def forward(self, x):
        u = x.mean(-1, keepdim=True)
        s = (x - u).pow(2).mean(-1, keepdim=True)
        x = (x - u) / torch.sqrt(s + self.variance_epsilon)
        return self.weight * x + self.bias
        
class SelfAttention(LightningModule):
    def __init__(self, num_attention_heads, input_size, hidden_size, output_dim=1, kernel_size=3,
                 hidden_dropout_prob=0.5, attention_probs_dropout_prob=0.5, learning_rate=0.001):
        super(SelfAttention, self).__init__()
        self.num_attention_heads = num_attention_heads
        self.attention_head_size = int(hidden_size / num_attention_heads)
        self.all_head_size = hidden_size

        self.query = torch.nn.Linear(input_size, self.all_head_size)
        self.key = torch.nn.Linear(input_size, self.all_head_size)
        self.value = torch.nn.Linear(input_size, self.all_head_size)

        self.attn_dropout = torch.nn.Dropout(attention_probs_dropout_prob)
        self.out_dropout = torch.nn.Dropout(hidden_dropout_prob)
        self.dense = torch.nn.Linear(hidden_size, input_size)
        self.LayerNorm = torch.nn.LayerNorm(input_size, eps=1e-12)
        self.relu = torch.nn.ReLU()
        self.out = torch.nn.Linear(input_size, output_dim)
        self.cnn = torch.nn.Conv1d(1, 1, kernel_size, stride=1, padding=1)

        self.learning_rate = learning_rate
        self.loss_fn = MSELoss()

    def forward(self, input_tensor):
        input_tensor = input_tensor.to(self.device)
        self.cnn = self.cnn.to(self.device)

        cnn_hidden = self.cnn(input_tensor.view(input_tensor.size(0), 1, -1))
        input_tensor = cnn_hidden
        mixed_query_layer = self.query(input_tensor)
        mixed_key_layer = self.key(input_tensor)
        mixed_value_layer = self.value(input_tensor)

        query_layer = mixed_query_layer
        key_layer = mixed_key_layer
        value_layer = mixed_value_layer

        attention_scores = torch.matmul(query_layer, key_layer.transpose(-1, -2))
        attention_scores = attention_scores / np.sqrt(self.attention_head_size)
        attention_probs = torch.nn.Softmax(dim=-1)(attention_scores)
        attention_probs = self.attn_dropout(attention_probs)

        context_layer = torch.matmul(attention_probs, value_layer)
        hidden_states = self.dense(context_layer)
        hidden_states = self.out_dropout(hidden_states)
        hidden_states = self.LayerNorm(hidden_states + input_tensor)
        output = self.out(self.relu(hidden_states.view(hidden_states.size(0), -1)))
        return output

    def training_step(self, batch, batch_idx):
        x, y = batch
        y_pred = self(x)
        loss = self.loss_fn(y_pred, y)
        return loss

    def validation_step(self, batch, batch_idx):
        x, y = batch
        y_pred = self(x)
        val_loss = self.loss_fn(y_pred, y)
        return val_loss

    def configure_optimizers(self):
        return Adam(self.parameters(), lr=self.learning_rate)

class EarlyStopping:
    def __init__(self, patience=10, delta=0):
        self.patience = patience
        self.delta = delta
        self.best_score = None
        self.counter = 0
        self.early_stop = False

    def __call__(self, score):
        if self.best_score is None:
            self.best_score = score
        elif score < self.best_score + self.delta:
            self.counter += 1
            if self.counter >= self.patience:
                self.early_stop = True
        else:
            self.best_score = score
            self.counter = 0

def get_gpu_mem_by_pid(pid):
    procs = pynvml.nvmlDeviceGetComputeRunningProcesses(handle)
    for p in procs:
        if p.pid == pid:
            return p.usedGpuMemory / 1024**2
    return 0.0

def run_nested_cv_with_early_stopping(args, data, label, outer_cv, learning_rate, batch_size, hidden_dim,
                                      output_dim, kernel_size, patience, DEVICE):
    result_dir = os.path.join(args.result_dir, args.methods + args.species + args.phe)
    os.makedirs(result_dir, exist_ok=True)
    best_corr_coefs = []
    best_maes = []
    best_r2s = []
    best_mses = []

    time_star = time.time()
    process = psutil.Process(os.getpid())
    for fold, (train_idx, test_idx) in enumerate(outer_cv.split(data)):
        fold_start_time = time.time()
        if torch.cuda.is_available():
            torch.cuda.reset_peak_memory_stats()
        process = psutil.Process(os.getpid())

        x_train, x_test = data[train_idx], data[test_idx]
        y_train, y_test = label[train_idx], label[test_idx]
        
        num_attention_heads = args.num_head
        attention_probs_dropout_prob = args.dropout
        hidden_dropout_prob = 0.5

        model = SelfAttention(num_attention_heads, x_train.shape[1], hidden_dim, output_dim,
                                hidden_dropout_prob=hidden_dropout_prob, kernel_size=kernel_size,
                                attention_probs_dropout_prob=attention_probs_dropout_prob).to(DEVICE)
        optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
        loss_function = torch.nn.MSELoss()
        scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='max', factor=0.1, patience=10)

        scaler = StandardScaler()
        x_train = scaler.fit_transform(x_train)
        x_test = scaler.transform(x_test)

        x_train_tensor = torch.from_numpy(x_train).float().to(DEVICE)
        y_train_tensor = torch.from_numpy(y_train).float().to(DEVICE)
        x_test_tensor = torch.from_numpy(x_test).float().to(DEVICE)
        y_test_tensor = torch.from_numpy(y_test).float().to(DEVICE)

        train_data = TensorDataset(x_train_tensor, y_train_tensor)
        test_data = TensorDataset(x_test_tensor, y_test_tensor)

        train_loader = DataLoader(train_data, batch_size, shuffle=True)
        test_loader = DataLoader(test_data, batch_size, shuffle=False)

        early_stopping = EarlyStopping(patience=patience)
        best_corr_coef = -float('inf')
        best_mae = float('inf')
        best_mse = float('inf')
        best_r2 = -float('inf')
        for epoch in range(100):
            model.train()
            for x_batch, y_batch in train_loader:
                optimizer.zero_grad()
                y_pred = model(x_batch)
                loss = loss_function(y_pred, y_batch.reshape(-1, 1))
                loss.backward()
                optimizer.step()

            model.eval()
            y_test_preds, y_test_trues = [], []
            
            with torch.no_grad():
                for x_batch, y_batch in test_loader:
                    y_test_pred = model(x_batch)
                    y_test_preds.extend(y_test_pred.cpu().numpy().reshape(-1).tolist())
                    y_test_trues.extend(y_batch.cpu().numpy().reshape(-1).tolist())

            corr_coef = np.corrcoef(y_test_preds, y_test_trues)[0, 1]
            mae = mean_absolute_error(np.array(y_test_trues), np.array(y_test_preds))
            mse = mean_squared_error(np.array(y_test_trues), np.array(y_test_preds))
            r2 = r2_score(np.array(y_test_trues), np.array(y_test_preds))
            scheduler.step(corr_coef)

            
            if corr_coef > best_corr_coef:
                best_mae = mae
                best_corr_coef = corr_coef
                best_mse = mse
                best_r2 = r2

            early_stopping(corr_coef)
            if early_stopping.early_stop:
                print(f"Early stopping at epoch {epoch + 1}")
                break
        
        best_corr_coefs.append(best_corr_coef)
        best_maes.append(best_mae)
        best_mses.append(best_mse)
        best_r2s.append(best_r2)

        fold_time = time.time() - fold_start_time
        fold_gpu_mem = get_gpu_mem_by_pid(os.getpid()) 
        fold_cpu_mem = process.memory_info().rss / 1024**2
        print(f'Fold {fold + 1}:  Corr={best_corr_coef:.4f}, MAE={best_mae:.4f}, MSE={best_mse:.4f}, R2={best_r2:.4f}, Time={fold_time:.2f}s, '
              f'GPU={fold_gpu_mem:.2f}MB, CPU={fold_cpu_mem:.2f}MB')
        
        results_df = pd.DataFrame({'Y_test': y_test_trues, 'Y_pred': y_test_preds})
        results_df.to_csv(os.path.join(result_dir, f"fold{fold}.csv"), index=False)

    print("==== Final Results ====")
    print(f"Corr: {np.mean(best_corr_coefs):.4f} ± {np.std(best_corr_coefs):.4f}")
    print(f"MAE: {np.mean(best_maes):.4f} ± {np.std(best_maes):.4f}")
    print(f"MSE: {np.mean(best_mses):.4f} ± {np.std(best_mses):.4f}")
    print(f"R2 : {np.mean(best_r2s):.4f} ± {np.std(best_r2s):.4f}")
    print(f"Time: {time.time() - time_star:.2f}s")


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

def Cropformer_reg(
        methods='Cropformer/',
        species='Chickpea/GSTP012/',
        species_list=['Cotton/'],
        phe='',
        data_dir='../../data/',
        result_dir='result/',
        seed=42,
        genotype_file='genotype.npz',
        phenotype_file='phenotype.npz',
        x_key = 'arr_0',
        y_key = 'arr_0',
        names_key = 'arr_1',
        lr = 0.01,
        num_head = 1,
        dropout = 0.5,
        batch_size = 32,
        hidden_dim = 64,
        kernel_size = 3,
        patience = 5,
        device = "cuda:0" if torch.cuda.is_available() else "cpu", 
):
    set_seed(seed)
    pynvml.nvmlInit()
    handle = pynvml.nvmlDeviceGetHandleByIndex(0)
    device = torch.device(device=device)

    args = parse_args(
        methods=methods,
        species=species,
        phe=phe,
        data_dir=data_dir,
        result_dir=result_dir,
        genotype_file=genotype_file,
        phenotype_file=phenotype_file,
        x_key = x_key,
        y_key = y_key,
        names_key = names_key,
        lr = lr,
        num_head = num_head,
        dropout = dropout,
        batch_size = batch_size,
        hidden_dim = hidden_dim,
        kernel_size = kernel_size,
        patience = patience,
    )

    all_species =species_list
    for i in range(len(all_species)):
        args.species = all_species[i]
        X, Y, nsamples, nsnp, names = load_data(args)
        for j in range(len(names)):
            args.phe = names[j]
            print("starting run " + args.methods + args.species + args.phe)
            label = Y[:, j]
            label = np.nan_to_num(label, nan=np.nanmean(label))
            best_params = Cropformer_Hyperparameters.Hyperparameter(X, label)
            args.lr = best_params['learning_rate']
            args.num_head = best_params['heads']
            args.dropout = best_params['dropout']
            args.batch_size = best_params['batch_size']

            outer_cv = KFold(n_splits=10, shuffle=True, random_state=42)
            
            start_time = time.time()
            torch.cuda.reset_peak_memory_stats()
            process = psutil.Process(os.getpid())

            run_nested_cv_with_early_stopping(args, 
                                            data=X,
                                            label=label,
                                            outer_cv=outer_cv,
                                            learning_rate= args.lr,
                                            batch_size=args.batch_size,
                                            hidden_dim=args.hidden_dim,
                                            output_dim=1,
                                            kernel_size=3,
                                            patience=args.patience,
                                            DEVICE='cuda:0' if torch.cuda.is_available() else 'cpu')
            
            elapsed_time = time.time() - start_time
            print(f"running time: {elapsed_time:.2f} s")
            print("successfully")


if __name__ == '__main__':
    Cropformer_reg(
        methods='Cropformer/',
        species='Chickpea/GSTP012/',
        species_list=['Cotton/'],
        phe='',
        data_dir='../../../data/',
        result_dir='result/',
        seed=42,
        genotype_file='genotype.npz',
        phenotype_file='phenotype.npz',
        x_key = 'arr_0',
        y_key = 'arr_0',
        names_key = 'arr_1',
        lr = 0.01,
        num_head = 1,
        dropout = 0.5,
        batch_size = 32,
        hidden_dim = 64,
        kernel_size = 3,
        patience = 5,
        device = "cuda:0",      
    )