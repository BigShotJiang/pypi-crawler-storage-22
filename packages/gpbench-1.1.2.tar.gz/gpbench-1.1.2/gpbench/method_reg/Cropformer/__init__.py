from .Cropformer import Cropformer_reg

Cropformer = Cropformer_reg

__all__ = ["Cropformer","Cropformer_reg"]