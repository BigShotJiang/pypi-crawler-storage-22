from .DL_GWAS import DL_GWAS_reg

DL_GWAS = DL_GWAS_reg

__all__ = ["DL_GWAS","DL_GWAS_reg"]