from .DNNGP import DNNGP_reg

DNNGP = DNNGP_reg

__all__ = ["DNNGP","DNNGP_reg"]