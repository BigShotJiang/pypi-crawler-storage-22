from .DeepCCR import DeepCCR_reg

DeepCCR = DeepCCR_reg

__all__ = ["DeepCCR","DeepCCR_reg"]