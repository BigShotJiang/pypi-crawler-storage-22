from .DeepGS import DeepGS_reg 

DeepGS = DeepGS_reg

__all__ = ["DeepGS","DeepGS_reg"]