from .EIR import EIR_reg

EIR = EIR_reg

__all__ = ["EIR","EIR_reg"]