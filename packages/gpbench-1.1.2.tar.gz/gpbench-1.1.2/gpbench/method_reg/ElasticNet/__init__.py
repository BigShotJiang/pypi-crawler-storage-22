from .ElasticNet import ElasticNet_reg

ElasticNet = ElasticNet_reg

__all__ = ["ElasticNet","ElasticNet_reg"]