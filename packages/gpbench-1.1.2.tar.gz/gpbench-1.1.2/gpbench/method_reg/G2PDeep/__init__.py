from .G2Pdeep import G2PDeep_reg

G2PDeep = G2PDeep_reg

__all__ = ["G2PDeep","G2PDeep_reg"]