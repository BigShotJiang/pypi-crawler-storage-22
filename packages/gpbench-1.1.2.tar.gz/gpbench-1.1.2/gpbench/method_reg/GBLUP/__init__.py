from .GBLUP_R import GBLUP_reg

GBLUP = GBLUP_reg

__all__ = ["GBLUP","GBLUP_reg"]