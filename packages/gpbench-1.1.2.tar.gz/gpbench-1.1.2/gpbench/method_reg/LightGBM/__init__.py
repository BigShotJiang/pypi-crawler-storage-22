from .LightGBM import LightGBM_reg

LightGBM = LightGBM_reg

__all__ = ["LightGBM","LightGBM_reg"]