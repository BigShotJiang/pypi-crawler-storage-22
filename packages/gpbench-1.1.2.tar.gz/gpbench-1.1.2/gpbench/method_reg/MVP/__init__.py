from .MVP import MVP_reg

MVP = MVP_reg

__all__ = ["MVP","MVP_reg"]