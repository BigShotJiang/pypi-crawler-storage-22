from .RF_GPU import RF_reg

RF = RF_reg

__all__ = ["RF","RF_reg"]