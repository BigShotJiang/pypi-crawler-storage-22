from .SVC_GPU import SVC_reg

SVC = SVC_reg

__all__ = ["SVC","SVC_reg"]