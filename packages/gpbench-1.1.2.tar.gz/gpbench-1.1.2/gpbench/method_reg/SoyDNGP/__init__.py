from .SoyDNGP import SoyDNGP_reg

SoyDNGP = SoyDNGP_reg

__all__ = ["SoyDNGP","SoyDNGP_reg"]