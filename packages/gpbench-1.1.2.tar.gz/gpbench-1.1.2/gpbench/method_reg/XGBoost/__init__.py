from .XGboost_GPU import XGBoost_reg

XGBoost = XGBoost_reg

__all__ = ["XGBoost","XGBoost_reg"]