from .rrBLUP import rrBLUP_reg

rrBLUP = rrBLUP_reg

__all__ = ["rrBLUP","rrBLUP_reg"]