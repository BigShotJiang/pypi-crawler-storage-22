import importlib
import pytest


def _try_import(name: str, required: bool = True, reason: str = ""):
    """
    required=True: 导入失败 -> 直接失败（这类是必须依赖）
    required=False: 导入失败 -> skip（这类是可选/平台相关依赖）
    """
    try:
        return importlib.import_module(name)
    except Exception as e:
        msg = f"import {name} failed: {type(e).__name__}: {e}"
        if required:
            raise AssertionError(msg) from e
        pytest.skip(reason or msg)

# ============================================================
# 1) 必须：本地包/目录必须能 import（安装/结构正确性）
# ============================================================

@pytest.mark.parametrize("pkg", [
    "gpbench",
    "method_reg",
    "method_class",
])
def test_import_local_packages(pkg):
    """
    这些要能 import 的前提：
    - 对应目录下存在 __init__.py
    - 已执行 pip install -e .[dev]
    """
    _try_import(pkg, required=True)


# ============================================================
# 2) 必须：核心数值/科学计算栈（绝大多数方法都会用）
# ============================================================

@pytest.mark.parametrize("pkg", [
    "numpy",
    "pandas",
    "scipy",
    "sklearn",     # scikit-learn 的 import 名是 sklearn
])
def test_import_core_deps(pkg):
    _try_import(pkg, required=True)


# ============================================================
# 3) 建议：训练相关（你项目里多方法可能会用，但个别机器可能不全）
#    - torch / xgboost / lightgbm：通常很关键，建议 required=True
# ============================================================

@pytest.mark.parametrize("pkg", [
    "torch",
    "xgboost",
    "lightgbm",
])
def test_import_ml_deps(pkg):
    _try_import(pkg, required=True)


# ============================================================
# 4) 可选：平台/系统/外部组件相关（容易因为机器环境不同而失败）
#    这些失败就 skip，不要直接让 A 阶段挂掉
# ============================================================

@pytest.mark.parametrize("pkg, reason", [
    ("rpy2", "R 相关：需要系统有 R + 对应库，某些环境可能缺"),
    ("tensorflow", "TF 相关：不同机器/驱动/GLIBC 可能不兼容，允许跳过"),
    ("keras", "与 tensorflow 相关联，允许跳过"),
    ("transformers", "大模型依赖链很长，某些机器可能不全，允许跳过"),
    ("tokenizers", "transformers 相关，允许跳过"),
    ("tiktoken", "LLM 相关，允许跳过"),
    ("openai", "仅当需要调用 OpenAI API 时才必须，允许跳过"),
    ("dashscope", "仅当需要调用 DashScope 时才必须，允许跳过"),
])
def test_import_optional_deps(pkg, reason):
    _try_import(pkg, required=False, reason=reason)
