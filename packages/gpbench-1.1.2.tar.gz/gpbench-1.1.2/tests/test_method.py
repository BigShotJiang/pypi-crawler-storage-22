import os
import re
import signal
import subprocess
import sys
import time
from pathlib import Path
from tqdm import tqdm

MAX_SECONDS = 180          # 每个脚本最多 3 分钟


def run_script(workdir: Path, script_name: str):
    """
    冒烟短跑测试（适配缓冲输出问题）：
    - cd 到 workdir
    - python -u 强制无缓冲输出
    - 满足任一条件就终止：
        1) 输出包含 "Fold 5"
        2) stdout+stderr 总输出行数 >= 10
        3) 运行超过 RUNNING_OK_SECONDS 且未崩溃（代表脚本确实跑起来了）
    - 不写入文件：测试端不创建文件；并通过环境变量提示脚本不要写文件（若脚本支持则生效）
    """
    script_path = workdir / script_name
    assert script_path.exists(), f"脚本不存在: {script_path}"

    env = os.environ.copy()
    # 尽量阻止脚本写文件（脚本不支持也不影响）
    env["SMOKE_TEST"] = "1"
    env["NO_SAVE"] = "1"
    env["NO_OUTPUT"] = "1"
    env["SAVE"] = "0"
    env["WRITE_FILES"] = "0"
    env["EPOCHS"] = "1"
    env["MAX_EPOCH"] = "1"

    # ✅ 关键：-u 强制 unbuffered
    cmd = [sys.executable, "-u", script_name]

    p = subprocess.Popen(
        cmd,
        cwd=workdir,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        env=env,
    )

    stdout_lines = []
    stderr_lines = []
    start = time.time()

    # ✅ 判定：匹配 Fold 1 或者运行到 MAX_SECONDS（3 分钟）且输出行数 >= 3
    fold1_hit = False
    total_lines = 0
    # 匹配 "Fold 1"、"fold 1"、"===== Fold 1 =====" 等
    FOLD1_PATTERN = re.compile(r"\bfold\s*1\b", re.IGNORECASE)
    try:
        while True:
            elapsed = time.time() - start

            # 进程结束
            if p.poll() is not None:
                break

            # 超时保护
            if elapsed > MAX_SECONDS:
                p.send_signal(signal.SIGINT)
                break

            # 读 stdout 一行
            if p.stdout:
                line = p.stdout.readline()
                if line:
                    s = line.strip()
                    stdout_lines.append(s)
                    total_lines += 1
                    if FOLD1_PATTERN.search(s):
                        fold1_hit = True

            # 读 stderr 一行
            if p.stderr:
                err = p.stderr.readline()
                if err:
                    s = err.strip()
                    stderr_lines.append(s)
                    total_lines += 1
                    if FOLD1_PATTERN.search(s):
                        fold1_hit = True

            # 早停条件：匹配到 Fold 1（立即停止）
            if fold1_hit:
                p.send_signal(signal.SIGINT)
                break

            time.sleep(0.05)

        # 等待退出（不强求一定优雅退出）
        try:
            p.wait(timeout=5)
        except subprocess.TimeoutExpired:
            p.kill()

    finally:
        if p.poll() is None:
            p.kill()

    elapsed = time.time() - start

    debug_msg = (
        f"\n运行脚本: {script_path}\n"
        f"CMD: {' '.join(cmd)}\n"
        f"CWD: {workdir}\n"
        f"ReturnCode: {p.returncode}\n"
        f"TOTAL lines: {total_lines}\n"
        f"FOLD1 hit: {fold1_hit}\n"
        f"ELAPSED: {elapsed:.1f}s\n"
        f"--- STDOUT tail ---\n" + "\n".join(stdout_lines[-30:]) + "\n"
        f"--- STDERR tail ---\n" + "\n".join(stderr_lines[-80:]) + "\n"
    )

    # ✅ 通过条件：匹配到 Fold 1，或运行到 MAX_SECONDS（3 分钟）且输出行数 >= 3
    passed = fold1_hit or (elapsed >= MAX_SECONDS and total_lines >= 3)

    assert passed, f"❌ 冒烟失败（未匹配 Fold 1，或运行 {MAX_SECONDS}s 后输出行数 < 3）\n{debug_msg}"



# ============================================================
# ✅ method_reg 测试用例列表
# ============================================================

METHOD_REG_CASES = [
    ("BayesA", "BayesA.py"),
    ("BayesB", "BayesB.py"),
    ("BayesC", "BayesC.py"),
    ("CropARNet", "CropARNet.py"),
    ("Cropformer", "Cropformer.py"),
    ("DeepCCR", "DeepCCR.py"),
    ("DeepGS", "DeepGS.py"),
    ("DL_GWAS", "DL_GWAS.py"),
    ("DNNGP", "DNNGP.py"),
    ("EIR", "EIR.py"),
    ("ElasticNet", "ElasticNet.py"),
    ("G2PDeep", "G2Pdeep.py"),
    ("GBLUP", "GBLUP_R.py"),
    ("GEFormer", "GEFormer.py"),
    ("LightGBM", "LightGBM.py"),
    ("MVP", "MVP.py"),
    ("RF", "RF_GPU.py"),
    ("rrBLUP", "rrBLUP.py"),
    ("SoyDNGP", "SoyDNGP.py"),
    ("SVR", "SVR_GPU.py"),
    ("XGBoost", "XGboost_GPU.py"),
]


def test_method_reg():
    """
    冒烟测试：
    对 method_reg 下所有方法逐个短跑验证
    """
    # base_dir = Path("method_reg")
    # total = len(METHOD_REG_CASES)

    # for i, (folder, script) in enumerate(METHOD_REG_CASES, 1):
    #     print(f"\n[{i}/{total}] Testing {folder}/{script} ...")

    #     workdir = base_dir / folder
    #     run_script(workdir, script)


    base_dir = Path("method_reg")
    for folder, script in tqdm(
        METHOD_REG_CASES,
        desc="🚀 Testing method_reg",
        unit="method",
        file=sys.stderr,     # ✅ 强制输出到 stderr（tqdm 默认也是 stderr，但这里显式指定更稳）
        dynamic_ncols=True,  # ✅ 自动适配终端宽度
        leave=False,          # ✅ 结束后保留进度条
        mininterval=0.2,     # ✅ 刷新频率
    ):
        workdir = base_dir / folder
        run_script(workdir, script)



# ============================================================
# ✅ method_class 测试用例列表
# ============================================================

METHOD_CLASS_CASES = [
    ("BayesA", "BayesA_class.py"),
    ("BayesB", "BayesB_class.py"),
    ("BayesC", "BayesC_class.py"),
    ("CropARNet", "CropARNet_class.py"),
    ("Cropformer", "Cropformer_class.py"),
    ("DeepCCR", "DeepCCR_class.py"),
    ("DeepGS", "DeepGS_class.py"),
    ("DL_GWAS", "DL_GWAS_class.py"),
    ("DNNGP", "DNNGP_class.py"),
    ("EIR", "EIR_class.py"),
    ("ElasticNet", "ElasticNet_class.py"),
    ("G2PDeep", "G2Pdeep_class.py"),
    ("GBLUP", "GBLUP_class.py"),
    ("GEFormer", "GEFormer_class.py"),
    ("LightGBM", "LightGBM_class.py"),
    ("RF", "RF_GPU_class.py"),
    ("rrBLUP", "rrBLUP_class.py"),
    ("SoyDNGP", "SoyDNGP_class.py"),
    ("SVR", "SVC_GPU.py"),
    ("XGBoost", "XGboost_GPU_class.py"),
]


def test_method_class():
    """
    冒烟测试：
    对 method_class 下所有方法逐个短跑验证
    """
    base_dir = Path("method_class")
    for folder, script in tqdm(
        METHOD_CLASS_CASES,
        desc="🚀 Testing method_class",
        unit="method",
        file=sys.stderr,     # ✅ 强制输出到 stderr（tqdm 默认也是 stderr，但这里显式指定更稳）
        dynamic_ncols=True,  # ✅ 自动适配终端宽度
        leave=False,          # ✅ 结束后保留进度条
        mininterval=0.2,     # ✅ 刷新频率
    ):
        workdir = base_dir / folder
        run_script(workdir, script)