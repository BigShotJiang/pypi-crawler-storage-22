"""GPMaster - GPG-backed lockbox for secrets management."""

__version__ = "1.0.0"
