from .observation import GOATSObservationCoordinator
from .program import GOATSProgramCoordinator

__all__ = ["GOATSObservationCoordinator", "GOATSProgramCoordinator"]
