"""Command-line interface demos."""
