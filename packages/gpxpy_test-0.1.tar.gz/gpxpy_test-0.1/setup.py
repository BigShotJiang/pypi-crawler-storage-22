from setuptools import setup, find_packages

setup(
    name='gpxpy_test',
    version='0.1',
    packages=find_packages(),
    install_requires=[
        # Add dependecies here.
        # e.g. 'numpy>=1.11.1'
    ],
)