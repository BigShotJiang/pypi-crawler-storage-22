
#csv

trip_id,vehicle_id,start_time,end_time,start_soc,end_soc,battery_capacity_kwh,gpx_filename
TRIP_001,EV_01,2025-02-10T08:00:00Z,2025-02-10T08:35:00Z,82,66,75,trip_001.gpx
TRIP_002,EV_02,2025-02-10T09:10:00Z,2025-02-10T09:55:00Z,78,52,60,trip_002.gpx
TRIP_003,EV_01,2025-02-11T14:05:00Z,2025-02-11T14:55:00Z,70,44,75,trip_003.gpx
TRIP_004,EV_03,2025-02-12T07:30:00Z,2025-02-12T08:05:00Z,90,83,85,trip_004.gpx
TRIP_005,EV_02,2025-02-12T12:00:00Z,2025-02-12T12:40:00Z,65,45,60,trip_005.gpx

#gpx

<?xml version="1.0" encoding="UTF-8"?>
<gpx version="1.1" creator="MinimalExample">
  <metadata>
    <name>TRIP_001</name>
    <time>2025-02-10T08:00:00Z</time>
  </metadata>
  <trk>
    <name>TRIP_001</name>
    <trkseg>
      <trkpt lat="55.751200" lon="37.618400"><ele>156.0</ele><time>2025-02-10T08:00:00Z</time></trkpt>
      <trkpt lat="55.751800" lon="37.619200"><ele>157.2</ele><time>2025-02-10T08:00:10Z</time></trkpt>
      <trkpt lat="55.752600" lon="37.620800"><ele>158.5</ele><time>2025-02-10T08:00:20Z</time></trkpt>
      <trkpt lat="55.753900" lon="37.623500"><ele>161.0</ele><time>2025-02-10T08:00:30Z</time></trkpt>
      <trkpt lat="55.755200" lon="37.626200"><ele>164.8</ele><time>2025-02-10T08:00:40Z</time></trkpt>
      <trkpt lat="55.756100" lon="37.628000"><ele>167.1</ele><time>2025-02-10T08:00:50Z</time></trkpt>
      <trkpt lat="55.757000" lon="37.629800"><ele>168.0</ele><time>2025-02-10T08:01:00Z</time></trkpt>
      <trkpt lat="55.758400" lon="37.632100"><ele>170.5</ele><time>2025-02-10T08:01:10Z</time></trkpt>
      <trkpt lat="55.759800" lon="37.634400"><ele>173.0</ele><time>2025-02-10T08:01:20Z</time></trkpt>
      <trkpt lat="55.761200" lon="37.636700"><ele>174.2</ele><time>2025-02-10T08:01:30Z</time></trkpt>
      <trkpt lat="55.762500" lon="37.639000"><ele>173.7</ele><time>2025-02-10T08:01:40Z</time></trkpt>
      <trkpt lat="55.763400" lon="37.640800"><ele>172.0</ele><time>2025-02-10T08:01:50Z</time></trkpt>
      <trkpt lat="55.764300" lon="37.642600"><ele>170.0</ele><time>2025-02-10T08:02:00Z</time></trkpt>
      <trkpt lat="55.765400" lon="37.644900"><ele>167.5</ele><time>2025-02-10T08:02:10Z</time></trkpt>
      <trkpt lat="55.766500" lon="37.647200"><ele>165.0</ele><time>2025-02-10T08:02:20Z</time></trkpt>
      <trkpt lat="55.767600" lon="37.649500"><ele>162.8</ele><time>2025-02-10T08:02:30Z</time></trkpt>
      <trkpt lat="55.768700" lon="37.651800"><ele>161.2</ele><time>2025-02-10T08:02:40Z</time></trkpt>
      <trkpt lat="55.769800" lon="37.654100"><ele>160.0</ele><time>2025-02-10T08:02:50Z</time></trkpt>
      <trkpt lat="55.770900" lon="37.656400"><ele>159.2</ele><time>2025-02-10T08:03:00Z</time></trkpt>
      <trkpt lat="55.772000" lon="37.658700"><ele>158.5</ele><time>2025-02-10T08:03:10Z</time></trkpt>
      <trkpt lat="55.773100" lon="37.661000"><ele>157.9</ele><time>2025-02-10T08:03:20Z</time></trkpt>
      <trkpt lat="55.774200" lon="37.663300"><ele>157.6</ele><time>2025-02-10T08:03:30Z</time></trkpt>
      <trkpt lat="55.775300" lon="37.665600"><ele>157.4</ele><time>2025-02-10T08:03:40Z</time></trkpt>
      <trkpt lat="55.776400" lon="37.667900"><ele>157.3</ele><time>2025-02-10T08:03:50Z</time></trkpt>
      <trkpt lat="55.777500" lon="37.670200"><ele>157.2</ele><time>2025-02-10T08:04:00Z</time></trkpt>
    </trkseg>
  </trk>
</gpx>
