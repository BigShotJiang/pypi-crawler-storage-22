# %%
import numpy as np, pandas as pd, sqlite3, matplotlib.pyplot as plt, seaborn as sns
import gpxpy, geopandas as gpd
from shapely.geometry import LineString
import contextily as cx
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.inspection import permutation_importance
from scipy.stats import skew
np.random.seed(42)

# %% [markdown]
# АААААААААААААААААААААА

# %%
# 1) Загрузка CSV и GPX через gpxpy
trips_csv = pd.read_csv("trips.csv")
with open("trips.gpx", "r") as f:
    gpx = gpxpy.parse(f)
gpx_points = []
for track in gpx.tracks:
    for segment in track.segments:
        for p in segment.points:
            gpx_points.append(dict(lat=p.latitude, lon=p.longitude, ele=p.elevation, time=p.time))
gpx_df = pd.DataFrame(gpx_points)

trips_csv.shape, gpx_df.shape

# %%
# 2) Статическая карта маршрута (показать)
route = gpd.GeoDataFrame([{"geometry": LineString(zip(gpx_df["lon"], gpx_df["lat"]))}], crs="EPSG:4326").to_crs(3857)
ax = route.plot(figsize=(6, 6), linewidth=2)
cx.add_basemap(ax, crs=route.crs)
ax.set_axis_off()
plt.show()

# %%
# 3) SQLite
DB_PATH = "trips.sqlite"
con = sqlite3.connect(DB_PATH)
trips_csv.to_sql("trips", con, if_exists="replace")
gpx_df.to_sql("gpx", con, if_exists="replace")
con.close()
DB_PATH

# %%
# 4) Сезонность в trips_csv (ПРОСТО)
trips_csv["month"] = np.random.randint(1, 13, len(trips_csv))
trips_csv["season"] = np.where(trips_csv["month"].isin([12,1,2]), "winter",
                     np.where(trips_csv["month"].isin([6,7,8]), "summer", "spring-fall"))

trips_csv[["month", "season"]].head()


# %%
# 5) Корреляции + permutation importance
target = next((c for c in trips_csv.select_dtypes(include="number").columns if "energy" in c.lower() or "power" in c.lower() or "wh" in c.lower()), "energy_wh_km")
print(f"Целевая колонка: {target}")

if target in trips_csv:
    num = trips_csv.select_dtypes(include="number").dropna(subset=[target])
    corr = num.corr(numeric_only=True)[target].sort_values(ascending=False)
    print("ТОП корреляции:")
    print(corr.head(10))
    
    X = num.drop(columns=[target])
    y = num[target]
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.25, random_state=42)
    rf = RandomForestRegressor(n_estimators=100, random_state=42).fit(Xtr, ytr)
    imp = pd.Series(permutation_importance(rf, Xte, yte, n_repeats=5, random_state=42)["importances_mean"], index=X.columns).sort_values(ascending=False)
    print("ТОП permutation importance:")
    print(imp.head(15))
else:
    print("Колонка расхода энергии не найдена!")


# %%
# 6) Violin + скошенность + трансформации 
numeric_cols = trips_csv.select_dtypes(include="number").columns.tolist()

if len(numeric_cols) < 3:
    trips_csv["demo_speed"] = np.random.normal(25, 10, len(trips_csv))
    trips_csv["demo_temp"] = np.random.normal(10, 8, len(trips_csv))
    trips_csv["demo_energy"] = np.random.exponential(50, len(trips_csv))
    numeric_cols += ["demo_speed", "demo_temp", "demo_energy"]

cols = numeric_cols[:4]
melt = trips_csv[cols].melt(var_name="feature", value_name="value").dropna()

plt.figure(figsize=(8, 4))
sns.violinplot(data=melt, x="feature", y="value")
plt.xticks(rotation=30)
plt.title("Распределения ключевых признаков")
plt.show()

# Обязательный анализ
sk = {c: float(skew(trips_csv[c].dropna())) for c in cols}
trans = {c: "log1p/Box-Cox" if s > 0.5 else "≈ нормальное" if abs(s) < 0.5 else "отражение+log1p" for c, s in sk.items()}
print("АНАЛИЗ РАСПРЕДЕЛЕНИЙ:")
for c, t in trans.items():
    print(f"{c}: skew={sk[c]:.2f} → {t}")


# %%
# 7) Аугментация trips_csv
trips_aug = trips_csv.copy()
for _ in range(3):
    t = trips_csv.copy()
    for col in ["speed_kmh", "payload_kg"]:
        if col in t: t[col] = np.clip(t[col] * np.random.normal(1, 0.05, len(t)), 0, None)
    if "temp_c" in t: t["temp_c"] = np.clip(t["temp_c"] + np.random.normal(0, 2, len(t)), -40, 45)
    t[target] = np.clip(t[target], 0, None)
    t["is_synthetic"] = 1
    trips_aug = pd.concat([trips_aug, t], ignore_index=True)
trips_aug.head()


# %%
# 8) Геометрическая аугментация gpx_df
gpx_aug = gpx_df.copy()
for _ in range(2):
    g = gpx_df.copy()
    g["lat"] += np.random.normal(0, 0.0001, len(g))
    g["lon"] += np.random.normal(0, 0.0001, len(g))
    g["is_synthetic"] = 1
    gpx_aug = pd.concat([gpx_aug, g], ignore_index=True)
gpx_aug.head()


# %%
# 9) Сохранение аугментаций
con = sqlite3.connect(DB_PATH)
trips_aug.to_sql("trips_aug", con, if_exists="replace")
gpx_aug.to_sql("gpx_aug", con, if_exists="replace")
con.close()
DB_PATH


# %% [markdown]
# ББББББББББББББ

# %%
con = sqlite3.connect("trips.sqlite")
df = pd.read_sql("SELECT * FROM trips_aug", con)
con.close()

df["energy_kwh"] = (df["start_soc"] - df["end_soc"]) * df["battery_capacity_kwh"] / 100

mean_energy = df["energy_kwh"].mean()
print(f"Средний расход: {mean_energy:.2f} kWh")

print("Температура:", df[["month", "energy_kwh"]].corr().iloc[0,1])
print("Автомобиль:", df.groupby("vehicle_id")["energy_kwh"].mean().sort_values())

route_eff = df.groupby("trip_id")["energy_kwh"].mean().sort_values()
print("Эффективные:", route_eff.head())
print("Неэффективные:", route_eff.tail())

fig, axes = plt.subplots(2, 2, figsize=(12, 8))

axes[0,0].scatter(df["month"], df["energy_kwh"])
axes[0,0].set_xlabel("Месяц"); axes[0,0].set_ylabel("Энергия")

df.boxplot(column="energy_kwh", by="vehicle_id", ax=axes[0,1])

sns.heatmap(df[["energy_kwh", "month", "start_soc", "end_soc"]].corr(), annot=True, ax=axes[1,0])

df["energy_per_kwh"] = df["energy_kwh"] / df["battery_capacity_kwh"]
axes[1,1].hist(df["energy_per_kwh"], bins=20)
axes[1,1].set_xlabel("Энергия на 1 kWh ёмкости")

plt.tight_layout()
plt.show()


# %%
from sklearn.cluster import KMeans, DBSCAN
from sklearn.preprocessing import StandardScaler

df["energy_kwh"] = (df["start_soc"] - df["end_soc"]) * df["battery_capacity_kwh"] / 100
df["soc_drop_pct"] = (df["start_soc"] - df["end_soc"]) * 100

df["trip_type"] = np.where(df["energy_kwh"] > df["energy_kwh"].quantile(0.9), "аномалия",
                  np.where(df["soc_drop_pct"] > 80, "риск разряда",
                  np.where(df["end_soc"] < 10, "требует зарядки", "оптимальная")))

print("Классификация:")
print(df["trip_type"].value_counts())

features = df[["energy_kwh", "soc_drop_pct", "month"]].fillna(0)
scaler = StandardScaler()
features_scaled = scaler.fit_transform(features)

kmeans = KMeans(n_clusters=3, random_state=42, n_init=10)
df["kmeans_cluster"] = kmeans.fit_predict(features_scaled)

dbscan = DBSCAN(eps=0.5, min_samples=5)
df["dbscan_cluster"] = dbscan.fit_predict(features_scaled)

print("\nK-means кластеры:", df["kmeans_cluster"].value_counts().sort_index())
print("DBSCAN кластеры:", pd.Series(df["dbscan_cluster"]).value_counts())


# %%
from sklearn.metrics import silhouette_score
import matplotlib.pyplot as plt

sil_k = silhouette_score(features_scaled, df["kmeans_cluster"])
print(f"K-means: {sil_k:.3f}")

plt.figure(figsize=(10, 4))
plt.subplot(121)
plt.scatter(features_scaled[:,0], features_scaled[:,1], c=df["kmeans_cluster"])
plt.title(f"K-means sil={sil_k:.3f}")
plt.show()


# %% [markdown]
# ВВВВВВВВВВВВВВВВВВВВВВВВ

# %%
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score
import joblib

df["energy_kwh"] = (df["start_soc"] - df["end_soc"]) * df["battery_capacity_kwh"] / 100
features = ["start_soc", "end_soc", "battery_capacity_kwh", "month"]
X = df[features].fillna(0)
y = df["energy_kwh"]

Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.25, random_state=42)

models = {
    "RF": RandomForestRegressor(n_estimators=50, random_state=42),
    "GB": GradientBoostingRegressor(random_state=42),
    "LR": LinearRegression()
}

scores = {}
for name, model in models.items():
    model.fit(Xtr, ytr)
    pred = model.predict(Xte)
    scores[name] = r2_score(yte, pred)
    print(f"{name}: R² = {scores[name]:.3f}")

best_model = max(scores, key=scores.get)
print(f"\nЛучшая: {best_model} (R²={scores[best_model]:.3f})")

joblib.dump(models[best_model], "best_energy_model.pkl")


# %%
import joblib
import numpy as np
import matplotlib.pyplot as plt

model = joblib.load("best_energy_model.pkl")
vehicles = df["vehicle_id"].unique()

forecasts = {}
for vehicle in vehicles:
    vehicle_data = df[df["vehicle_id"] == vehicle].iloc[0]
    soc_history = []
    
    current_soc = vehicle_data["start_soc"]
    for week in range(52):
        soc_history.append(current_soc)
        
        X_pred = np.array([[current_soc, current_soc-2, vehicle_data["battery_capacity_kwh"], (vehicle_data["month"] + week//4) % 12 + 1]])
        energy_use = abs(model.predict(X_pred)[0]) * 0.05  
        
        current_soc = max(20, current_soc - energy_use * 10)  
    
    forecasts[vehicle] = soc_history

plt.figure(figsize=(10, 6))
for vehicle, soc in forecasts.items():
    plt.plot(range(52), soc, label=vehicle)
plt.xlabel("Недели"); plt.ylabel("SOC (%)")
plt.title("Прогноз на год")
plt.legend(); plt.grid(True)
plt.show()



