from flask import Flask, request, jsonify
import joblib
import numpy as np
import sqlite3
import pandas as pd

app = Flask(__name__)
model = joblib.load("best_energy_model.pkl")

@app.route("/predict_energy", methods=["POST"])
def predict_energy():
    data = request.json
    X = np.array([[data["start_soc"], data["end_soc"], data["battery_kwh"], data["month"]]])
    energy = float(model.predict(X)[0])
    return jsonify({"energy_kwh": energy})

@app.route("/risk_assessment/<vehicle_id>", methods=["GET"])
def risk_assessment(vehicle_id):
    con = sqlite3.connect("trips.sqlite")
    df = pd.read_sql(f"SELECT * FROM trips_aug WHERE vehicle_id='{vehicle_id}'", con)
    con.close()
    risk = 0.15 if len(df) > 0 else 0.05
    return jsonify({"risk": risk})

@app.route("/battery_forecast/<vehicle_id>", methods=["GET"])
def battery_forecast(vehicle_id):
    soc_forecast = np.random.uniform(65, 85)
    return jsonify({"soc_forecast_pct": soc_forecast})

if __name__ == "__main__":
    app.run(debug=True, port=5000)
