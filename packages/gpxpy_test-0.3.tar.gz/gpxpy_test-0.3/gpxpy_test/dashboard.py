import streamlit as st
import sqlite3
import pandas as pd
import plotly.express as px

df = pd.read_sql("SELECT * FROM trips_aug", sqlite3.connect("trips.sqlite"))

col1, col2 = st.columns(2)
col1.metric("Поездок", len(df))
col2.metric("Синтетических", len(df[df["is_synthetic"]==1]))

st.dataframe(df)

fig1 = px.bar(df["month"].value_counts().sort_index().head(12))
st.plotly_chart(fig1)
