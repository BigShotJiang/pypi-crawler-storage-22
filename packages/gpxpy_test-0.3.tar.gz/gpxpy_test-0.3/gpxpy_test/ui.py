import streamlit as st
import requests

st.title("Планировщик")

vehicle_id = st.selectbox("Автомобиль", ["EV_01", "EV_02", "EV_03"])
start_soc = st.slider("SOC %", 20, 100, 80)
battery_kwh = st.slider("АКБ kWh", 50, 100, 75)
month = st.slider("Месяц", 1, 12, 7)

if st.button("Рассчитать"):
    try:
        resp = requests.post("http://localhost:5000/predict_energy", 
                           json={"start_soc": start_soc, "end_soc": start_soc-15, 
                                 "battery_kwh": battery_kwh, "month": month})
        energy = resp.json()["energy_kwh"]
        st.success(f"Расход: {energy:.1f} kWh")
        
        risk_resp = requests.get(f"http://localhost:5000/risk_assessment/{vehicle_id}")
        risk = risk_resp.json()["risk"]
        batt_resp = requests.get(f"http://localhost:5000/battery_forecast/{vehicle_id}")
        soc_forecast = batt_resp.json()["soc_forecast_pct"]
        
        col1, col2 = st.columns(2)
        col1.metric("Риск", f"{risk:.1%}")
        col2.metric("SOC прогноз", f"{soc_forecast:.0f}%")
        
    except:
        st.error("API недоступен")
