# gradzero

A lightweight deep learning framework built from scratch with automatic differentiation.

## Features

- **Automatic Differentiation**: Built-in autograd engine for computing gradients
- **Tensor Operations**: NumPy-based tensor with gradient tracking
- **Neural Network Layers**: Linear, ReLU, Sigmoid, and more
- **Optimizers**: SGD and Adam optimizers with momentum and weight decay support
- **Easy to Use**: Simple API similar to PyTorch

## Installation

```bash
pip install gradzero
```

## Quick Start

### Creating Tensors with Factory Methods (实例化方法)

```python
import gradzero as gz

# Create tensors using class method factories (实例化方法)
zeros = gz.Tensor.zeros((3, 3))          # Tensor filled with zeros
ones = gz.Tensor.ones((2, 4))            # Tensor filled with ones
randn = gz.Tensor.randn((3, 3))          # Random from normal distribution
rand = gz.Tensor.rand((2, 2))            # Random from uniform distribution
from_np = gz.Tensor.from_numpy(my_array) # From existing numpy array

# With gradient tracking
trainable = gz.Tensor.randn((3, 3), requires_grad=True)
```

### Building a Neural Network

```python
import gradzero as gz

# Define a model
model = gz.Sequential(
    gz.Linear(784, 128),
    gz.ReLU(),
    gz.Linear(128, 10),
)

# Loss and optimizer
criterion = gz.CrossEntropyLoss()
optimizer = gz.Adam(model.parameters(), lr=0.001)

# Training loop
for epoch in range(100):
    # Forward pass
    output = model(input_tensor)
    loss = criterion(output, target_tensor)

    # Backward pass
    model.zero_grad()
    loss.backward()

    # Update parameters
    optimizer.step()
```

## API Reference

### Tensor Factory Methods (实例化方法)

- `Tensor.zeros(shape, dtype=None, requires_grad=False)` - Create a tensor filled with zeros
- `Tensor.ones(shape, dtype=None, requires_grad=False)` - Create a tensor filled with ones
- `Tensor.randn(shape, dtype=None, requires_grad=False)` - Create a tensor with random values from standard normal distribution
- `Tensor.rand(shape, dtype=None, requires_grad=False)` - Create a tensor with random values from uniform distribution [0, 1)
- `Tensor.from_numpy(array, requires_grad=False)` - Create a tensor from a numpy array

### Neural Network Layers

- `Linear(in_features, out_features, bias=True)` - Fully connected layer
- `ReLU()` - ReLU activation
- `Sigmoid()` - Sigmoid activation
- `Sequential(*layers)` - Container for sequential layers

### Loss Functions

- `MSELoss()` - Mean squared error
- `CrossEntropyLoss()` - Cross entropy loss for classification

### Optimizers

- `SGD(parameters, lr=0.01, momentum=0.0, weight_decay=0.0)` - Stochastic gradient descent
- `Adam(parameters, lr=0.001, betas=(0.9, 0.999), eps=1e-8, weight_decay=0.0)` - Adam optimizer

## License

MIT License
