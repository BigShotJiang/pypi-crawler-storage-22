"""
gradzero: A lightweight deep learning framework from scratch.

This package provides a simple deep learning framework with automatic
differentiation, built from scratch using only numpy.
"""

__version__ = "0.1.0"

# Core components
from .tensor import Tensor

# Neural network modules
from .nn import (
    Module,
    Linear,
    ReLU,
    Sigmoid,
    Sequential,
    MSELoss,
    CrossEntropyLoss,
)

# Optimizers
from .optimizer import (
    Optimizer,
    SGD,
    Adam,
)

__all__ = [
    # Version
    "__version__",
    # Core
    "Tensor",
    # Modules
    "Module",
    "Linear",
    "ReLU",
    "Sigmoid",
    "Sequential",
    "MSELoss",
    "CrossEntropyLoss",
    # Optimizers
    "Optimizer",
    "SGD",
    "Adam",
]
