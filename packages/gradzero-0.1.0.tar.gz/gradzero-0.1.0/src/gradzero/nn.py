"""
Neural network layers and modules for gradzero.
"""
from typing import Optional, List, Iterator
import numpy as np
from .tensor import Tensor


class Module:
    """
    Base class for all neural network modules.

    All custom layers should inherit from this class and implement
    the forward method.
    """

    def __init__(self):
        self._modules: dict = {}
        self._parameters: dict = {}
        self._is_training = True

    def forward(self, *args, **kwargs) -> Tensor:
        """
        Forward pass of the module.

        Args:
            *args: Variable length argument list
            **kwargs: Arbitrary keyword arguments

        Returns:
            Output tensor
        """
        raise NotImplementedError("Subclasses must implement forward()")

    def __call__(self, *args, **kwargs) -> Tensor:
        """Call forward method."""
        return self.forward(*args, **kwargs)

    def parameters(self) -> Iterator[Tensor]:
        """
        Return an iterator over module parameters.

        Yields:
            Parameter tensors
        """
        for param in self._parameters.values():
            yield param
        for module in self._modules.values():
            yield from module.parameters()

    def named_parameters(self) -> Iterator[tuple]:
        """
        Return an iterator over module parameters with names.

        Yields:
            Tuples of (name, parameter)
        """
        for name, param in self._parameters.items():
            yield name, param
        for module_name, module in self._modules.items():
            for name, param in module.named_parameters():
                yield f"{module_name}.{name}", param

    def modules(self) -> Iterator["Module"]:
        """
        Return an iterator over all sub-modules.

        Yields:
            Sub-modules
        """
        yield from self._modules.values()

    def named_modules(self) -> Iterator[tuple]:
        """
        Return an iterator over all sub-modules with names.

        Yields:
            Tuples of (name, module)
        """
        yield from self._modules.items()

    def __setattr__(self, name: str, value):
        """Track sub-modules and parameters."""
        if isinstance(value, Module):
            self._modules[name] = value
        elif isinstance(value, Tensor) and value.requires_grad:
            self._parameters[name] = value
        super().__setattr__(name, value)

    def train(self, mode: bool = True) -> "Module":
        """
        Set the module in training mode.

        Args:
            mode: Whether to set training mode (True) or eval mode (False)

        Returns:
            self
        """
        self._is_training = mode
        for module in self._modules.values():
            module.train(mode)
        return self

    def eval(self) -> "Module":
        """
        Set the module in evaluation mode.

        Returns:
            self
        """
        return self.train(False)

    def zero_grad(self):
        """Zero out gradients for all parameters."""
        for param in self.parameters():
            param.zero_grad()

    def save_parameters(self, path: str):
        """
        Save module parameters to a file.

        Args:
            path: Path to save the parameters
        """
        params = {name: param.data for name, param in self.named_parameters()}
        np.savez(path, **params)

    def load_parameters(self, path: str):
        """
        Load module parameters from a file.

        Args:
            path: Path to the saved parameters
        """
        data = np.load(path)
        for name, param in self.named_parameters():
            if name in data:
                param.data = data[name].copy()


class Linear(Module):
    """
    Linear (fully connected) layer.

    Applies a linear transformation: y = x @ W^T + b
    """

    def __init__(
        self,
        in_features: int,
        out_features: int,
        bias: bool = True,
    ):
        """
        Initialize linear layer.

        Args:
            in_features: Size of input features
            out_features: Size of output features
            bias: Whether to include bias term
        """
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features

        # Xavier initialization
        bound = np.sqrt(6.0 / (in_features + out_features))
        self.weight = Tensor(
            np.random.uniform(-bound, bound, (out_features, in_features)),
            requires_grad=True,
        )

        if bias:
            self.bias = Tensor(
                np.zeros(out_features),
                requires_grad=True,
            )
        else:
            self.bias = None

    def forward(self, x: Tensor) -> Tensor:
        """
        Forward pass.

        Args:
            x: Input tensor of shape (..., in_features)

        Returns:
            Output tensor of shape (..., out_features)
        """
        output = x @ self.weight.T
        if self.bias is not None:
            output = output + self.bias
        return output

    def __repr__(self):
        return f"Linear({self.in_features}, {self.out_features}, bias={self.bias is not None})"


class ReLU(Module):
    """ReLU activation layer."""

    def forward(self, x: Tensor) -> Tensor:
        """Apply ReLU activation."""
        return x.relu()

    def __repr__(self):
        return "ReLU()"


class Sigmoid(Module):
    """Sigmoid activation layer."""

    def forward(self, x: Tensor) -> Tensor:
        """Apply sigmoid activation."""
        return x.sigmoid()

    def __repr__(self):
        return "Sigmoid()"


class Sequential(Module):
    """
    Sequential container for layers.

    Modules will be added to it in the order they are passed.
    """

    def __init__(self, *layers: Module):
        """
        Initialize sequential container.

        Args:
            *layers: Variable number of layers
        """
        super().__init__()
        self.layers = list(layers)
        for i, layer in enumerate(self.layers):
            setattr(self, f"layer_{i}", layer)

    def forward(self, x: Tensor) -> Tensor:
        """
        Forward pass through all layers.

        Args:
            x: Input tensor

        Returns:
            Output tensor
        """
        for layer in self.layers:
            x = layer(x)
        return x

    def __repr__(self):
        layers_str = "\n".join([f"  ({i}): {layer}" for i, layer in enumerate(self.layers)])
        return f"Sequential(\n{layers_str}\n)"


class MSELoss(Module):
    """Mean Squared Error loss."""

    def forward(self, pred: Tensor, target: Tensor) -> Tensor:
        """
        Compute MSE loss.

        Args:
            pred: Predicted values
            target: Target values

        Returns:
            Loss value
        """
        diff = pred - target
        return (diff * diff).mean()

    def __repr__(self):
        return "MSELoss()"


class CrossEntropyLoss(Module):
    """Cross-entropy loss for classification."""

    def forward(self, logits: Tensor, target: Tensor) -> Tensor:
        """
        Compute cross-entropy loss.

        Args:
            logits: Logits (before softmax)
            target: Target class indices

        Returns:
            Loss value
        """
        # Numerically stable softmax
        shifted = logits.data - np.max(logits.data, axis=-1, keepdims=True)
        exp_shifted = np.exp(shifted)
        probs = exp_shifted / np.sum(exp_shifted, axis=-1, keepdims=True)

        # Get batch size and number of classes
        batch_size = logits.data.shape[0]

        # Negative log likelihood
        if target.data.dtype in [np.int32, np.int64]:
            # target is class indices
            loss = -np.log(probs[np.arange(batch_size), target.data.astype(int)] + 1e-8)
        else:
            # target is one-hot
            loss = -np.sum(target.data * np.log(probs + 1e-8), axis=-1)

        return Tensor(loss.mean(), requires_grad=logits.requires_grad)

    def __repr__(self):
        return "CrossEntropyLoss()"
