"""
Optimizers for training neural networks.
"""
from typing import Iterator
import numpy as np
from .tensor import Tensor


class Optimizer:
    """Base class for all optimizers."""

    def __init__(self, parameters: Iterator[Tensor], lr: float = 0.01):
        """
        Initialize optimizer.

        Args:
            parameters: Iterator over parameters to optimize
            lr: Learning rate
        """
        self.parameters = list(parameters)
        self.lr = lr

    def zero_grad(self):
        """Zero out gradients for all parameters."""
        for param in self.parameters:
            param.zero_grad()

    def step(self):
        """Perform a single optimization step."""
        raise NotImplementedError("Subclasses must implement step()")


class SGD(Optimizer):
    """
    Stochastic Gradient Descent optimizer.

    Supports momentum and weight decay.
    """

    def __init__(
        self,
        parameters: Iterator[Tensor],
        lr: float = 0.01,
        momentum: float = 0.0,
        weight_decay: float = 0.0,
    ):
        """
        Initialize SGD optimizer.

        Args:
            parameters: Iterator over parameters to optimize
            lr: Learning rate
            momentum: Momentum factor (default: 0)
            weight_decay: Weight decay (L2 penalty) (default: 0)
        """
        super().__init__(parameters, lr)
        self.momentum = momentum
        self.weight_decay = weight_decay
        self._velocities = [np.zeros_like(p.data) for p in self.parameters]

    def step(self):
        """Perform a single SGD step."""
        for i, param in enumerate(self.parameters):
            if param.grad is None:
                continue

            grad = param.grad.copy()

            # Apply weight decay
            if self.weight_decay != 0:
                grad += self.weight_decay * param.data

            # Apply momentum
            if self.momentum != 0:
                self._velocities[i] = self.momentum * self._velocities[i] + grad
                grad = self._velocities[i]

            # Update parameters
            param.data -= self.lr * grad


class Adam(Optimizer):
    """
    Adam optimizer.

    Implements Adam algorithm with bias correction.
    """

    def __init__(
        self,
        parameters: Iterator[Tensor],
        lr: float = 0.001,
        betas: tuple = (0.9, 0.999),
        eps: float = 1e-8,
        weight_decay: float = 0.0,
    ):
        """
        Initialize Adam optimizer.

        Args:
            parameters: Iterator over parameters to optimize
            lr: Learning rate (default: 0.001)
            betas: Coefficients for running averages (default: (0.9, 0.999))
            eps: Term for numerical stability (default: 1e-8)
            weight_decay: Weight decay (L2 penalty) (default: 0)
        """
        super().__init__(parameters, lr)
        self.betas = betas
        self.eps = eps
        self.weight_decay = weight_decay
        self._step_count = 0

        self._m = [np.zeros_like(p.data) for p in self.parameters]  # First moment
        self._v = [np.zeros_like(p.data) for p in self.parameters]  # Second moment

    def step(self):
        """Perform a single Adam step."""
        self._step_count += 1
        beta1, beta2 = self.betas

        for i, param in enumerate(self.parameters):
            if param.grad is None:
                continue

            grad = param.grad.copy()

            # Apply weight decay
            if self.weight_decay != 0:
                grad += self.weight_decay * param.data

            # Update biased first moment estimate
            self._m[i] = beta1 * self._m[i] + (1 - beta1) * grad

            # Update biased second raw moment estimate
            self._v[i] = beta2 * self._v[i] + (1 - beta2) * (grad ** 2)

            # Compute bias-corrected estimates
            m_hat = self._m[i] / (1 - beta1 ** self._step_count)
            v_hat = self._v[i] / (1 - beta2 ** self._step_count)

            # Update parameters
            param.data -= self.lr * m_hat / (np.sqrt(v_hat) + self.eps)
