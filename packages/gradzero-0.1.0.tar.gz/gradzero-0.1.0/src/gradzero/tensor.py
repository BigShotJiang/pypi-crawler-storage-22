"""
Core tensor implementation for gradzero.
"""
import numpy as np
from typing import Optional, List, Union, Callable


class Tensor:
    """
    A Tensor class that supports automatic differentiation.
    """

    def __init__(
        self,
        data: Union[np.ndarray, List, float, int],
        dtype: Optional[np.dtype] = None,
        requires_grad: bool = False,
    ):
        """
        Initialize a Tensor.

        Args:
            data: Input data (numpy array, list, or scalar)
            dtype: Data type of the tensor
            requires_grad: Whether to track gradients for this tensor
        """
        if isinstance(data, (list, float, int)):
            data = np.array(data, dtype=dtype)
        elif not isinstance(data, np.ndarray):
            raise TypeError(f"Unsupported data type: {type(data)}")

        self.data = data.astype(dtype) if dtype else data
        self.requires_grad = requires_grad
        self.grad: Optional[np.ndarray] = None
        self._backward_fn: Optional[Callable] = None
        self._prev: List[Tensor] = []

        if requires_grad:
            self.grad = np.zeros_like(self.data)

    @classmethod
    def zeros(
        cls,
        shape: Union[int, tuple],
        dtype: Optional[np.dtype] = None,
        requires_grad: bool = False,
    ) -> "Tensor":
        """
        Create a tensor filled with zeros.

        Args:
            shape: Shape of the tensor
            dtype: Data type
            requires_grad: Whether to track gradients

        Returns:
            A new Tensor filled with zeros
        """
        data = np.zeros(shape, dtype=dtype or np.float32)
        return cls(data, requires_grad=requires_grad)

    @classmethod
    def ones(
        cls,
        shape: Union[int, tuple],
        dtype: Optional[np.dtype] = None,
        requires_grad: bool = False,
    ) -> "Tensor":
        """
        Create a tensor filled with ones.

        Args:
            shape: Shape of the tensor
            dtype: Data type
            requires_grad: Whether to track gradients

        Returns:
            A new Tensor filled with ones
        """
        data = np.ones(shape, dtype=dtype or np.float32)
        return cls(data, requires_grad=requires_grad)

    @classmethod
    def randn(
        cls,
        shape: Union[int, tuple],
        dtype: Optional[np.dtype] = None,
        requires_grad: bool = False,
    ) -> "Tensor":
        """
        Create a tensor with random values from standard normal distribution.

        Args:
            shape: Shape of the tensor
            dtype: Data type
            requires_grad: Whether to track gradients

        Returns:
            A new Tensor with random values
        """
        data = np.random.randn(*shape if isinstance(shape, tuple) else (shape,))
        if dtype:
            data = data.astype(dtype)
        return cls(data, requires_grad=requires_grad)

    @classmethod
    def rand(
        cls,
        shape: Union[int, tuple],
        dtype: Optional[np.dtype] = None,
        requires_grad: bool = False,
    ) -> "Tensor":
        """
        Create a tensor with random values from uniform distribution [0, 1).

        Args:
            shape: Shape of the tensor
            dtype: Data type
            requires_grad: Whether to track gradients

        Returns:
            A new Tensor with random values
        """
        data = np.random.rand(*shape if isinstance(shape, tuple) else (shape,))
        if dtype:
            data = data.astype(dtype)
        return cls(data, requires_grad=requires_grad)

    @classmethod
    def from_numpy(cls, array: np.ndarray, requires_grad: bool = False) -> "Tensor":
        """
        Create a tensor from a numpy array.

        Args:
            array: Input numpy array
            requires_grad: Whether to track gradients

        Returns:
            A new Tensor wrapping the numpy array
        """
        return cls(array.copy(), requires_grad=requires_grad)

    def backward(self, grad_output: Optional[np.ndarray] = None):
        """
        Compute gradients via backpropagation.

        Args:
            grad_output: Gradient from the next layer
        """
        if not self.requires_grad:
            return

        if grad_output is None:
            grad_output = np.ones_like(self.data)

        if self.grad is None:
            self.grad = grad_output
        else:
            self.grad += grad_output

        if self._backward_fn is not None:
            self._backward_fn(grad_output)

    def zero_grad(self):
        """Zero out the gradients."""
        if self.grad is not None:
            self.grad.fill(0)

    @property
    def shape(self):
        """Return the shape of the tensor."""
        return self.data.shape

    @property
    def ndim(self):
        """Return the number of dimensions."""
        return self.data.ndim

    @property
    def T(self) -> "Tensor":
        """Return the transpose of the tensor."""
        result = Tensor(self.data.T, requires_grad=self.requires_grad)

        if result.requires_grad:
            result._prev = [self]

            def backward_fn(grad_output):
                if self.requires_grad:
                    self.backward(grad_output.T)

            result._backward_fn = backward_fn

        return result

    def __repr__(self):
        return f"Tensor({self.data}, requires_grad={self.requires_grad})"

    def __add__(self, other: Union["Tensor", float, int]) -> "Tensor":
        """Element-wise addition."""
        if isinstance(other, (float, int)):
            other = Tensor(np.full_like(self.data, other))

        result = Tensor(self.data + other.data, requires_grad=self.requires_grad or other.requires_grad)

        if result.requires_grad:
            result._prev = [self, other]

            def backward_fn(grad_output):
                if self.requires_grad:
                    # Sum gradients over broadcasted dimensions if needed
                    grad = self._unbroadcast(grad_output, self.shape)
                    self.backward(grad)
                if other.requires_grad:
                    # Sum gradients over broadcasted dimensions if needed
                    grad = self._unbroadcast(grad_output, other.shape)
                    other.backward(grad)

            result._backward_fn = backward_fn

        return result

    def __sub__(self, other: Union["Tensor", float, int]) -> "Tensor":
        """Element-wise subtraction."""
        if isinstance(other, (float, int)):
            other = Tensor(np.full_like(self.data, other))

        result = Tensor(self.data - other.data, requires_grad=self.requires_grad or other.requires_grad)

        if result.requires_grad:
            result._prev = [self, other]

            def backward_fn(grad_output):
                if self.requires_grad:
                    # Sum gradients over broadcasted dimensions if needed
                    grad = self._unbroadcast(grad_output, self.shape)
                    self.backward(grad)
                if other.requires_grad:
                    # Sum gradients over broadcasted dimensions if needed
                    grad = self._unbroadcast(grad_output, other.shape)
                    other.backward(-grad)

            result._backward_fn = backward_fn

        return result

    def _unbroadcast(self, grad: np.ndarray, target_shape: tuple) -> np.ndarray:
        """Sum gradients over broadcasted dimensions to match target shape."""
        # Handle scalar case
        if target_shape == ():
            return grad.sum()
        # Handle case where grad is already the right shape
        if grad.shape == target_shape:
            return grad
        # Sum over extra dimensions at the front
        while len(grad.shape) > len(target_shape):
            grad = grad.sum(axis=0)
        # Sum over dimensions of size 1
        for i, (g, t) in enumerate(zip(grad.shape, target_shape)):
            if t == 1 and g > 1:
                grad = grad.sum(axis=i, keepdims=True)
        return grad

    def __mul__(self, other: Union["Tensor", float, int]) -> "Tensor":
        """Element-wise multiplication."""
        if isinstance(other, (float, int)):
            other = Tensor(np.full_like(self.data, other))

        result = Tensor(self.data * other.data, requires_grad=self.requires_grad or other.requires_grad)

        if result.requires_grad:
            result._prev = [self, other]

            def backward_fn(grad_output):
                if self.requires_grad:
                    self.backward(grad_output * other.data)
                if other.requires_grad:
                    other.backward(grad_output * self.data)

            result._backward_fn = backward_fn

        return result

    def __matmul__(self, other: "Tensor") -> "Tensor":
        """Matrix multiplication."""
        result = Tensor(self.data @ other.data, requires_grad=self.requires_grad or other.requires_grad)

        if result.requires_grad:
            result._prev = [self, other]

            def backward_fn(grad_output):
                if self.requires_grad:
                    self.backward(grad_output @ other.data.T)
                if other.requires_grad:
                    other.backward(self.data.T @ grad_output)

            result._backward_fn = backward_fn

        return result

    def sum(self, axis=None, keepdims=False) -> "Tensor":
        """Sum of tensor elements."""
        result = Tensor(
            self.data.sum(axis=axis, keepdims=keepdims),
            requires_grad=self.requires_grad
        )

        if result.requires_grad:
            result._prev = [self]

            def backward_fn(grad_output):
                if self.requires_grad:
                    if not keepdims and axis is not None:
                        grad_output = np.expand_dims(grad_output, axis=axis)
                    self.backward(np.broadcast_to(grad_output, self.shape))

            result._backward_fn = backward_fn

        return result

    def mean(self, axis=None, keepdims=False) -> "Tensor":
        """Mean of tensor elements."""
        if axis is None:
            n = self.data.size
        else:
            n = self.data.shape[axis] if not isinstance(axis, tuple) else np.prod([self.data.shape[a] for a in axis])

        return self.sum(axis=axis, keepdims=keepdims) * (1.0 / n)

    def relu(self) -> "Tensor":
        """ReLU activation function."""
        result = Tensor(np.maximum(0, self.data), requires_grad=self.requires_grad)

        if result.requires_grad:
            result._prev = [self]

            def backward_fn(grad_output):
                if self.requires_grad:
                    self.backward(grad_output * (self.data > 0))

            result._backward_fn = backward_fn

        return result

    def sigmoid(self) -> "Tensor":
        """Sigmoid activation function."""
        sig = 1 / (1 + np.exp(-self.data))
        result = Tensor(sig, requires_grad=self.requires_grad)

        if result.requires_grad:
            result._prev = [self]

            def backward_fn(grad_output):
                if self.requires_grad:
                    self.backward(grad_output * sig * (1 - sig))

            result._backward_fn = backward_fn

        return result
