# <span class="badge package-variant-panelcfg"></span> barchart

## Objects

 * <span class="badge object-type-class"></span> [FieldConfig](./object-FieldConfig.md)
 * <span class="badge object-type-class"></span> [Options](./object-Options.md)
## Builders

 * <span class="badge builder"></span> [Panel](./builder-Panel.md)
## Functions

### <span class="badge function"></span> variant_config

variant_config returns the configuration related to barchart panels.

This configuration describes how to unmarshal it, convert it to code, …

```python
def variant_config() -> variants.PanelcfgConfig
```

