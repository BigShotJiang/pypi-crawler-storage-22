---
title: <span class="badge builder"></span> QueryEditorProperty
---
# <span class="badge builder"></span> QueryEditorProperty

## Constructor

```python
QueryEditorProperty()
```
## Methods

### <span class="badge object-method"></span> build

Builds the object.

```python
def build() -> bigquery.QueryEditorProperty
```

### <span class="badge object-method"></span> name

```python
def name(name: str) -> typing.Self
```

## See also

 * <span class="badge object-type-class"></span> [QueryEditorProperty](./object-QueryEditorProperty.md)
