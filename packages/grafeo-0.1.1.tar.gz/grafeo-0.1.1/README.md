# pygrafeo

Python bindings for Grafeo, a pure-Rust, high-performance, embeddable graph database.

## Installation

```bash
pip install pygrafeo
```

## Usage

```python
import pygrafeo
```

## License

Apache-2.0
