from setuptools import setup, find_packages
import os
import re


def get_version():
    with open(os.path.join("graffiti_lookup", "__init__.py")) as f:
        content = f.read()
    match = re.search(r'__version__\s*=\s*["\']([^"\']+)["\']', content)
    if not match:
        raise RuntimeError("Version not found")
    return match.group(1)


setup(
    name="graffiti-lookup-nyc",
    version=get_version(),
    description="Query NYC 311 Graffiti Cleanup Requests via CLI and Python API.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Nabil Jamaleddine",
    author_email="me@nabiljamaleddine.com",
    url="https://github.com/njamaleddine/graffiti-lookup-nyc",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=["httpx>=0.23,<0.27", "beautifulsoup4>=4.9,<5.0"],
    entry_points={
        "console_scripts": ["graffiti-lookup-nyc=graffiti_lookup.__main__:cli_main"]
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    include_package_data=True,
    package_data={"": ["*.md"]},
)
