========================================
Tool API: package ``grammarinator.tool``
========================================

.. automodule:: grammarinator.tool
   :members:
   :imported-members:
   :special-members: __call__, __exit__
   :show-inheritance:
