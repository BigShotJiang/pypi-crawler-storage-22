=============
Grammarinator
=============
*ANTLRv4 grammar-based test generator*

.. toctree::
   :caption: Documentation
   :maxdepth: 1

   introduction
   user_guide


.. toctree::
   :caption: API Reference
   :maxdepth: 1

   grammarinator.runtime
   grammarinator.tool


.. toctree::
   :caption: Miscellaneous
   :maxdepth: 1

   relnotes
   license
