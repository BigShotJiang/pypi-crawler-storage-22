============
Introduction
============

.. include:: ../README.rst
   :start-after: .. start included documentation
   :end-before: .. end included documentation
