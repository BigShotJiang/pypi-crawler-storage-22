"""Granola Transcript Archiver.

Automated system to archive Granola meeting transcripts to GitHub.
"""

__version__ = "0.3.0"

from .main import main

__all__ = ["main"]
