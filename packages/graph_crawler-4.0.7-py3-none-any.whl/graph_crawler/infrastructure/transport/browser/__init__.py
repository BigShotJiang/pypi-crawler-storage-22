"""Module: infrastructure/transport/browser"""
