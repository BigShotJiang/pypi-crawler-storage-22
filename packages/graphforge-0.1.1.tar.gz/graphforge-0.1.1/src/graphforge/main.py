def main():
    print("Hello from graphforge!")


if __name__ == "__main__":
    main()
