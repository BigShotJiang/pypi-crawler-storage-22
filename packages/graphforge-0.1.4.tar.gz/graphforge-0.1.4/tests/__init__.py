"""GraphForge test suite."""
