"""
This is a placeholder for future tests.
"""

def test_placeholder():
	"""Just a placeholder"""
