"""Async Graphon client using httpx."""

import asyncio
import logging
import os
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any, Literal

import httpx

logger = logging.getLogger(__name__)

TIMEOUT = 60.0 * 35

# New BFF API URL
API_BASE_URL = "https://api.graphon.ai"
# API_BASE_URL = "http://localhost:8081"


def _create_fake_jwt(user_id: str = "test-user-local") -> str:
    """
    Create a fake JWT token for local testing.

    Uses HS256 algorithm with a test secret. The local validation function
    decodes without verification, so the signature doesn't matter.

    Args:
        user_id: User ID to include in 'sub' claim

    Returns:
        str: JWT token string (signed with test secret)
    """
    try:
        from jose import jwt
    except ImportError as e:
        raise ImportError(
            "python-jose is required for localhost testing. "
            "Install it with: pip install python-jose"
        ) from e

    payload = {
        "sub": user_id,
        "iat": int(time.time()),
        "exp": int(time.time()) + 3600,  # 1 hour expiry
    }

    # Sign with HS256 and a test secret (doesn't matter since validation ignores signature)
    token = jwt.encode(payload, key="test-secret-key", algorithm="HS256")
    return token


# ============================================================================
# Response Models
# ============================================================================


@dataclass
class FileObject:
    """Represents a file in the Graphon system."""

    file_id: str
    file_name: str
    file_type: str
    processing_status: str  # UNPROCESSED, PROCESSING, SUCCESS, FAILURE
    error_message: str | None = None


@dataclass
class FileDetail:
    """Detailed file information from the API."""

    file_id: str
    user_id: str
    file_name: str
    file_type: str
    file_size_bytes: int
    file_gcs_location: str
    processing_status: str
    processing_start_time: str | None = None
    error_message: str | None = None
    metadata: dict[str, Any] | None = None
    created_at: str | None = None
    updated_at: str | None = None


@dataclass
class GroupDetail:
    """Detailed group information from the API."""

    group_id: str
    user_id: str
    group_name: str
    file_ids: list[str]
    status: str  # UNPROCESSED, PROCESSING, SUCCESS, FAILURE
    graph_gcs_location: str | None = None
    graph_job_id: str | None = None
    metadata: dict[str, Any] | None = None
    created_at: str | None = None
    updated_at: str | None = None


@dataclass
class SkippedFile:
    """Information about a file that was skipped during group modification."""

    file_id: str
    reason: str  # "not_in_group" or "already_in_group"


@dataclass
class GroupModifyResult(GroupDetail):
    """Result from modifying group files, extends GroupDetail with skipped info."""

    skipped: list[SkippedFile] = field(default_factory=list)


@dataclass
class GroupListItem:
    """Group item in list response (summary view)."""

    group_id: str
    group_name: str
    file_count: int
    status: str  # UNPROCESSED, PROCESSING, SUCCESS, FAILURE
    created_at: str


@dataclass
class QueryResponseLegacy:
    """Response from querying a group's unified graph (legacy format).

    .. deprecated::
        This response model is deprecated and will be removed in a future version.
        Use :class:`QueryResponse` instead, which provides a cleaner sources structure.
    """

    answer: str
    sources: list[dict[str, Any]]
    attention_nodes: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class QueryResponse:
    """Response from querying a group's unified graph.

    Sources are returned as a dictionary mapping citation keys (e.g., "[1]", "[2]")
    to AttentionNodeV2 objects that include source metadata, relevance scores,
    and citation flags.

    Attributes:
        answer: The generated answer with inline citation markers like [1], [2].
        sources: Dictionary mapping citation keys to source metadata including:
            - source: Object with node_type, file_id, and type-specific fields
            - score: Relevance score (0.0 to 1.0)
            - is_cited: Whether this source was cited in the answer
    """

    answer: str
    sources: dict[str, dict[str, Any]]


# ============================================================================
# Graphon Client
# ============================================================================


class GraphonClient:
    """A client library for interacting with the Graphon API.

    Uses a shared connection pool internally for efficient resource usage.
    Supports use as an async context manager for automatic cleanup::

        async with GraphonClient(api_key="your-key") as client:
            response = await client.query_group(group_id, "my query")
    """

    def __init__(
        self,
        api_key: str,
        base_url: str | None = None,
        verify_ssl: bool = True,
        max_connections: int = 10,
        max_keepalive_connections: int = 5,
    ):
        """
        Initialize the client with an API key.

        Args:
            api_key: Your Graphon API key (get from dashboard)
            base_url: Optional custom base URL (defaults to production API)
            verify_ssl: Whether to verify SSL certificates (default: True)
            max_connections: Maximum number of concurrent connections (default: 10)
            max_keepalive_connections: Maximum number of idle keep-alive connections (default: 5)
        """
        self.api_base_url = (base_url or API_BASE_URL).rstrip("/")
        self._verify_ssl = verify_ssl

        # For localhost testing, use fake JWT instead of API key
        if "localhost" in self.api_base_url:
            fake_token = _create_fake_jwt()
            self._headers = {
                "Authorization": f"Bearer {fake_token}",
                "Content-Type": "application/json",
            }
            logger.info("Using fake JWT for localhost testing")
        else:
            self._headers = {
                "X-API-Key": api_key,
                "Content-Type": "application/json",
            }

        # Shared API client with auth headers and connection pool
        api_limits = httpx.Limits(
            max_connections=max_connections,
            max_keepalive_connections=max_keepalive_connections,
        )
        self._client = httpx.AsyncClient(
            timeout=TIMEOUT,
            verify=self._verify_ssl,
            limits=api_limits,
            headers=self._headers,
        )

        # Headerless upload client for GCS (no auth headers to avoid leaking)
        upload_limits = httpx.Limits(
            max_connections=max_connections,
            max_keepalive_connections=1,
        )
        self._upload_client = httpx.AsyncClient(
            timeout=None,
            verify=self._verify_ssl,
            limits=upload_limits,
        )

        self._closed = False

    # ========================================================================
    # Lifecycle Management
    # ========================================================================

    async def close(self) -> None:
        """Close the underlying HTTP clients and release resources.

        Idempotent — safe to call multiple times.
        Calling API methods after close() will raise an error.
        """
        if self._closed:
            return
        self._closed = True
        try:
            await self._client.aclose()
        finally:
            await self._upload_client.aclose()

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.close()

    # ========================================================================
    # Helper Methods
    # ========================================================================

    def _determine_file_type(self, filename: str) -> str:
        """
        Determine file type from extension.

        Args:
            filename: Name of the file

        Returns:
            One of: 'video', 'document', 'image', 'audio'
        """
        ext = filename.split(".")[-1].lower()

        # Video extensions
        if ext in ["mp4", "mov", "avi", "mkv", "webm", "flv", "wmv", "m4v", "3gp"]:
            return "video"

        # Document extensions
        if ext in ["pdf", "docx", "pptx", "xlsx", "txt", "md"]:
            return "document"

        # Image extensions
        if ext in ["png", "jpg", "jpeg"]:
            return "image"

        # Audio extensions
        if ext in ["mp3", "wav", "m4a", "ogg", "flac", "aac", "wma", "opus"]:
            return "audio"

        # Default to document
        return "document"

    async def _handle_response(self, response: httpx.Response) -> dict[str, Any]:
        """Handle API response and raise appropriate exceptions."""
        if response.status_code >= 400:
            try:
                error_data = response.json()
                error_msg = (
                    error_data.get("detail")
                    or error_data.get("message")
                    or str(error_data)
                )
            except Exception:
                error_msg = response.text or f"HTTP {response.status_code}"

            raise Exception(f"API error ({response.status_code}): {error_msg}")

        return response.json()

    # ========================================================================
    # File Operations
    # ========================================================================

    async def get_signed_upload_url(
        self, file_name: str, file_type: str, file_size_bytes: int
    ) -> dict[str, Any]:
        """
        Get a signed URL for uploading a file to GCS.

        Args:
            file_name: Name of the file
            file_type: Type of file ('video', 'document', 'image', or 'audio')
            file_size_bytes: Size of the file in bytes

        Returns:
            Dict with keys: file_id, upload_url, upload_fields, expires_at
        """
        response = await self._client.post(
            f"{self.api_base_url}/v1/files/upload-url",
            json={
                "file_name": file_name,
                "file_type": file_type,
                "file_size_bytes": file_size_bytes,
            },
        )
        return await self._handle_response(response)

    async def upload_to_gcs(
        self, file_path: str, upload_url: str, upload_fields: dict[str, str]
    ) -> None:
        """
        Upload a file to GCS using a signed URL.

        Args:
            file_path: Local path to the file
            upload_url: Signed URL from get_signed_upload_url
            upload_fields: Form fields from get_signed_upload_url
        """
        # Read file content
        with open(file_path, "rb") as f:
            file_content = f.read()

        # Create multipart form data
        files = {"file": (os.path.basename(file_path), file_content)}

        response = await self._upload_client.post(
            upload_url,
            data=upload_fields,
            files=files,
        )

        # GCS returns 204 No Content on success
        if response.status_code not in [200, 204]:
            raise Exception(
                f"GCS upload failed (status {response.status_code}): {response.text}"
            )

    async def _process_file(self, file_id: str) -> dict[str, Any]:
        """
        Start processing an uploaded file.

        Args:
            file_id: The file ID returned from get_signed_upload_url

        Returns:
            Dict with status information
        """
        response = await self._client.post(
            f"{self.api_base_url}/v1/files/{file_id}/process",
        )
        return await self._handle_response(response)

    async def _get_file_status(self, file_id: str) -> FileDetail:
        """
        Get the current status of a file.

        Args:
            file_id: The file ID

        Returns:
            FileDetail object with current status
        """
        response = await self._client.get(
            f"{self.api_base_url}/v1/files/{file_id}",
        )
        data = await self._handle_response(response)
        return FileDetail(**data)

    async def list_files(
        self, status_filter: str | None = None, file_type: str | None = None
    ) -> list[FileDetail]:
        """
        List all files for the authenticated user.

        Args:
            status_filter: Optional filter by processing status
            file_type: Optional filter by file type

        Returns:
            List of FileDetail objects
        """
        params = {}
        if status_filter:
            params["status"] = status_filter
        if file_type:
            params["file_type"] = file_type

        response = await self._client.get(
            f"{self.api_base_url}/v1/files",
            params=params,
        )
        data = await self._handle_response(response)
        return [FileDetail(**f) for f in data.get("files", [])]

    # ========================================================================
    # Polling Methods
    # ========================================================================

    async def poll_file_until_complete(
        self,
        file_id: str,
        timeout: int = 1800,
        poll_interval: int = 3,
        on_progress: Callable[[str], None] | None = None,
    ) -> FileDetail:
        """
        Poll a file until processing completes (SUCCESS or FAILURE).

        Args:
            file_id: The file ID to poll
            timeout: Maximum time to wait in seconds (default: 30 minutes)
            poll_interval: Time between polls in seconds (default: 3)
            on_progress: Optional callback(status: str) called on each poll

        Returns:
            FileDetail object with final status

        Raises:
            Exception: If processing fails or times out
        """
        start_time = asyncio.get_event_loop().time()

        while True:
            file = await self._get_file_status(file_id)

            if on_progress:
                on_progress(file.processing_status)

            if file.processing_status == "SUCCESS":
                return file

            if file.processing_status == "FAILURE":
                raise Exception(
                    f"File {file_id} ({file.file_name}) processing failed: {file.error_message or 'Unknown error'}"
                )

            # Check timeout
            elapsed = asyncio.get_event_loop().time() - start_time
            if elapsed > timeout:
                raise Exception(
                    f"File {file_id} ({file.file_name}) processing timed out after {timeout} seconds"
                )

            await asyncio.sleep(poll_interval)

    # ========================================================================
    # High-Level Upload & Process
    # ========================================================================

    async def upload_and_process_files(
        self,
        file_paths: list[str],
        poll_until_complete: bool = True,
        timeout: int = 1800,
        poll_interval: int = 3,
        on_progress: Callable[[str, int, int], None] | None = None,
    ) -> list[FileObject]:
        """
        Upload and process multiple files.

        This is the main method for getting files into Graphon:
        1. Generates signed URLs for all files
        2. Uploads all files to GCS concurrently
        3. Triggers processing for all files
        4. Optionally waits for processing to complete

        Args:
            file_paths: List of local file paths to upload
            poll_until_complete: If True, waits for all files to finish processing
            timeout: Maximum time to wait per file in seconds (default: 30 minutes)
            poll_interval: Time between status checks in seconds (default: 3)
            on_progress: Optional callback(step: str, current: int, total: int) for progress updates

        Returns:
            List of FileObject with file_id, file_name, processing_status, and error_message.
            processing_status will be "SUCCESS", "FAILURE", or "PROCESSING"
            error_message will contain details if status is "FAILURE"

        Raises:
            Exception: If any file fails to upload (but not if processing fails when poll_until_complete=True)
        """
        if not file_paths:
            return []

        total_files = len(file_paths)
        logger.info(f"Starting upload and process for {total_files} files")

        # Step 1: Generate signed URLs for all files
        if on_progress:
            on_progress("generating_urls", 0, total_files)

        upload_infos: list[dict[str, Any]] = []
        for i, file_path in enumerate(file_paths):
            file_name = os.path.basename(file_path)
            file_type = self._determine_file_type(file_name)
            file_size = os.path.getsize(file_path)

            logger.info(
                f"Requesting signed URL for {file_name} (type={file_type}, size={file_size})"
            )
            info = await self.get_signed_upload_url(file_name, file_type, file_size)
            upload_infos.append({"file_path": file_path, "info": info})

            if on_progress:
                on_progress("generating_urls", i + 1, total_files)

        logger.info(f"Generated {len(upload_infos)} signed URLs")

        # Step 2: Upload all files to GCS concurrently
        if on_progress:
            on_progress("uploading_files", 0, total_files)

        semaphore = asyncio.Semaphore(5)  # Limit concurrent uploads

        async def upload_one(idx: int, upload_info: dict) -> None:
            async with semaphore:
                file_path = upload_info["file_path"]
                info = upload_info["info"]
                logger.info(
                    f"Uploading {os.path.basename(file_path)} (file_id={info['file_id']})"
                )
                await self.upload_to_gcs(
                    file_path, info["upload_url"], info["upload_fields"]
                )
                if on_progress:
                    on_progress("uploading_files", idx + 1, total_files)

        await asyncio.gather(
            *(upload_one(i, info) for i, info in enumerate(upload_infos))
        )

        logger.info("All files uploaded to GCS")

        # Step 3: Trigger processing for all files
        if on_progress:
            on_progress("processing_files", 0, total_files)

        file_ids: list[str] = [info["info"]["file_id"] for info in upload_infos]

        for i, file_id in enumerate(file_ids):
            logger.info(f"Triggering processing for file_id={file_id}")
            await self._process_file(file_id)
            if on_progress:
                on_progress("processing_files", i + 1, total_files)

        logger.info("All processing jobs triggered")

        # Step 4: Optionally wait for processing to complete
        if poll_until_complete:
            if on_progress:
                on_progress("waiting_for_processing", 0, total_files)

            async def poll_one_safe(
                idx: int, file_id: str, file_name: str
            ) -> FileObject:
                """Poll a single file and return FileObject with success or error status."""
                try:
                    logger.info(f"Polling file_id={file_id} for completion")
                    result = await self.poll_file_until_complete(
                        file_id,
                        timeout=timeout,
                        poll_interval=poll_interval,
                        on_progress=lambda status: logger.debug(
                            f"File {file_id} status: {status}"
                        ),
                    )
                    if on_progress:
                        on_progress("waiting_for_processing", idx + 1, total_files)

                    return FileObject(
                        file_id=result.file_id,
                        file_name=result.file_name,
                        file_type=result.file_type,
                        processing_status="SUCCESS",
                        error_message=None,
                    )
                except Exception as e:
                    # Capture error and continue processing other files
                    logger.error(f"File {file_id} ({file_name}) failed: {str(e)}")
                    if on_progress:
                        on_progress("waiting_for_processing", idx + 1, total_files)

                    return FileObject(
                        file_id=file_id,
                        file_name=file_name,
                        file_type=self._determine_file_type(file_name),
                        processing_status="FAILURE",
                        error_message=str(e),
                    )

            # Poll all files and collect results (with error handling per file)
            file_objects = await asyncio.gather(
                *(
                    poll_one_safe(
                        i, fid, os.path.basename(upload_infos[i]["file_path"])
                    )
                    for i, fid in enumerate(file_ids)
                )
            )

            success_count = sum(
                1 for f in file_objects if f.processing_status == "SUCCESS"
            )
            failure_count = sum(
                1 for f in file_objects if f.processing_status == "FAILURE"
            )
            logger.info(
                f"Processing complete: {success_count} succeeded, {failure_count} failed"
            )

            return list(file_objects)
        else:
            # Return FileObject list with PROCESSING status
            return [
                FileObject(
                    file_id=info["info"]["file_id"],
                    file_name=os.path.basename(info["file_path"]),
                    file_type=self._determine_file_type(
                        os.path.basename(info["file_path"])
                    ),
                    processing_status="PROCESSING",
                    error_message=None,
                )
                for info in upload_infos
            ]

    # ========================================================================
    # Group Operations
    # ========================================================================

    async def create_group(
        self,
        file_ids: list[str],
        group_name: str,
        wait_for_ready: bool = False,
        timeout: int = 3600,
        poll_interval: int = 5,
        on_progress: Callable[[str], None] | None = None,
    ) -> str:
        """
        Create a group from processed files.

        Args:
            file_ids: List of file IDs (must all have processing_status=SUCCESS)
            group_name: Name for the group
            wait_for_ready: If True, waits for graph building to complete
            timeout: Maximum time to wait for graph building in seconds (default: 1 hour)
            poll_interval: Time between status checks in seconds (default: 5)
            on_progress: Optional callback(status: str) for progress updates

        Returns:
            group_id

        Raises:
            Exception: If group creation or graph building fails
        """
        logger.info(
            f"Creating group '{group_name}' with {len(file_ids)} files: {file_ids}"
        )

        response = await self._client.post(
            f"{self.api_base_url}/v1/groups",
            json={"group_name": group_name, "file_ids": file_ids},
        )
        data = await self._handle_response(response)

        group_id = data["group_id"]
        logger.info(f"Group created: {group_id}, status: {data.get('status')}")

        if wait_for_ready:
            logger.info(f"Waiting for group {group_id} to be ready...")
            await self.poll_group_until_ready(
                group_id,
                timeout=timeout,
                poll_interval=poll_interval,
                on_progress=on_progress,
            )
            logger.info(f"Group {group_id} is ready")

        return group_id

    async def modify_group_files(
        self,
        group_id: str,
        add: list[str] | None = None,
        remove: list[str] | None = None,
        wait_for_ready: bool = False,
        poll_interval: float = 2.0,
        timeout: int = 3600,
    ) -> GroupModifyResult:
        """
        Add and/or remove files from a group.

        When files are added or removed, the group's unified graph is automatically rebuilt.
        Files to add must have processing_status=SUCCESS.

        Args:
            group_id: The group to modify
            add: File IDs to add (must be SUCCESS status)
            remove: File IDs to remove
            wait_for_ready: If True, poll until graph rebuilds
            poll_interval: Seconds between polls (default: 2.0)
            timeout: Maximum time to wait for graph building in seconds (default: 3600)

        Returns:
            GroupModifyResult with updated group details and skipped files

        Raises:
            Exception: If modification fails or graph building fails/times out

        Example:
            >>> result = await client.modify_group_files(
            ...     group_id="grp_123",
            ...     add=["new_file_id"],
            ...     remove=["old_file_id"],
            ...     wait_for_ready=True
            ... )
            >>> print(f"Group now has {len(result.file_ids)} files")
            >>> for skipped in result.skipped:
            ...     print(f"Skipped {skipped.file_id}: {skipped.reason}")
        """
        logger.info(
            f"Modifying group {group_id}: add={add or []}, remove={remove or []}"
        )

        payload = {}
        if add:
            payload["add"] = add
        if remove:
            payload["remove"] = remove

        response = await self._client.patch(
            f"{self.api_base_url}/v1/groups/{group_id}/files",
            json=payload,
        )
        data = await self._handle_response(response)

        # Parse skipped files
        skipped_data = data.get("skipped", [])
        skipped = [SkippedFile(**s) for s in skipped_data]

        result = GroupModifyResult(
            group_id=data["group_id"],
            user_id=data["user_id"],
            group_name=data["group_name"],
            file_ids=data["file_ids"],
            status=data["status"],
            graph_gcs_location=data.get("graph_gcs_location"),
            graph_job_id=data.get("graph_job_id"),
            metadata=data.get("metadata"),
            created_at=data.get("created_at"),
            updated_at=data.get("updated_at"),
            skipped=skipped,
        )

        logger.info(
            f"Group modified: {group_id}, status: {result.status}, "
            f"skipped: {len(skipped)}"
        )

        if wait_for_ready and result.status == "PROCESSING":
            logger.info(
                f"Waiting for group {group_id} to be ready after modification..."
            )
            await self.poll_group_until_ready(
                group_id,
                timeout=timeout,
                poll_interval=int(poll_interval),
            )
            # Refresh the result with final status
            final_group = await self.get_group_status(group_id)
            result = GroupModifyResult(
                group_id=final_group.group_id,
                user_id=final_group.user_id,
                group_name=final_group.group_name,
                file_ids=final_group.file_ids,
                status=final_group.status,
                graph_gcs_location=final_group.graph_gcs_location,
                graph_job_id=final_group.graph_job_id,
                metadata=final_group.metadata,
                created_at=final_group.created_at,
                updated_at=final_group.updated_at,
                skipped=skipped,  # Keep original skipped info
            )
            logger.info(f"Group {group_id} is ready after modification")

        return result

    async def get_group_status(self, group_id: str) -> GroupDetail:
        """
        Get the current status of a group.

        Args:
            group_id: The group ID

        Returns:
            GroupDetail object with current status
        """
        response = await self._client.get(
            f"{self.api_base_url}/v1/groups/{group_id}",
        )
        data = await self._handle_response(response)
        return GroupDetail(**data)

    async def poll_group_until_ready(
        self,
        group_id: str,
        timeout: int = 3600,
        poll_interval: int = 5,
        on_progress: Callable[[str], None] | None = None,
    ) -> GroupDetail:
        """
        Poll a group until graph building completes (SUCCESS or FAILURE).

        Args:
            group_id: The group ID to poll
            timeout: Maximum time to wait in seconds (default: 1 hour)
            poll_interval: Time between polls in seconds (default: 5)
            on_progress: Optional callback(status: str) called on each poll

        Returns:
            GroupDetail object with final status

        Raises:
            Exception: If graph building fails or times out
        """
        start_time = asyncio.get_event_loop().time()

        while True:
            group = await self.get_group_status(group_id)

            if on_progress:
                on_progress(group.status)

            if group.status == "SUCCESS":
                return group

            if group.status == "FAILURE":
                error_msg = (
                    group.metadata.get("error_message")
                    if group.metadata
                    else "Unknown error"
                )
                raise Exception(f"Graph building failed: {error_msg}")

            # Check timeout
            elapsed = asyncio.get_event_loop().time() - start_time
            if elapsed > timeout:
                raise Exception(f"Graph building timed out after {timeout} seconds")

            await asyncio.sleep(poll_interval)

    async def list_groups(self) -> list[GroupListItem]:
        """
        List all groups for the authenticated user.

        Returns:
            List of GroupListItem objects (summary view)
        """
        response = await self._client.get(
            f"{self.api_base_url}/v1/groups",
        )
        data = await self._handle_response(response)
        return [GroupListItem(**g) for g in data.get("groups", [])]

    async def query_group(
        self,
        group_id: str,
        query: str,
        return_source_data: bool = False,
        web_search: bool = False,
        reasoning_effort: Literal["low", "high", "ultra"] | None = None,
    ) -> QueryResponse:
        """
        Query a group's unified graph.

        This is the recommended method for querying graphs. It returns a cleaner
        response structure where sources are mapped by citation keys.

        Args:
            group_id: The group ID to query
            query: Natural language query
            return_source_data: If True, include text content for documents and
                               time-limited signed URLs for images/videos in the response
            web_search: If True, augment the answer with web search results
            reasoning_effort: Level of reasoning effort for the query. If not specified,
                             the API defaults to "high".
                             "low": Faster response, skips deep re-analysis of sources.
                             "high" (API default): Full re-analysis of sources with Qwen/Molmo2.
                             "ultra": Maximum accuracy using Gemini 2.5 Pro for all sources.

        Returns:
            QueryResponse with:
                - answer: Generated answer with citation markers like [1], [2]
                - sources: Dictionary mapping citation keys to source metadata

        Raises:
            Exception: If group is not ready or query fails

        Example:
            >>> response = await client.query_group(group_id, "What are the main topics?")
            >>> print(response.answer)
            "The main topics include AI [1] and machine learning [2]..."
            >>> for key, source in response.sources.items():
            ...     print(f"{key}: {source['source']['node_type']}")
            "[1]": "document"
            "[2]": "video"
        """
        logger.info(f"Querying group {group_id}: {query}")

        # Build request payload, only including reasoning_effort if explicitly set
        payload: dict[str, Any] = {
            "query": query,
            "return_source_data": return_source_data,
            "web_search": web_search,
        }
        if reasoning_effort is not None:
            payload["reasoning_effort"] = reasoning_effort

        response = await self._client.post(
            f"{self.api_base_url}/v1/groups/{group_id}/query",
            json=payload,
        )
        data = await self._handle_response(response)
        return QueryResponse(
            answer=data.get("answer", ""),
            sources=data.get("sources", {}),
        )

    # ========================================================================
    # Convenience Methods
    # ========================================================================

    async def upload_process_and_create_group(
        self,
        file_paths: list[str],
        group_name: str,
        on_progress: Callable[[str, int, int], None] | None = None,
    ) -> str:
        """
        One-shot method: Upload files, process them, and create a group.

        This is the simplest way to create a graph from files.

        Args:
            file_paths: List of local file paths
            group_name: Name for the group
            on_progress: Optional callback(step: str, current: int, total: int)

        Returns:
            group_id

        Raises:
            Exception: If any step fails
        """
        # Upload and process files
        file_objects = await self.upload_and_process_files(
            file_paths, poll_until_complete=True, on_progress=on_progress
        )

        # Extract file IDs
        file_ids = [f.file_id for f in file_objects]

        # Create group and wait for it to be ready
        group_id = await self.create_group(
            file_ids,
            group_name,
            wait_for_ready=True,
            on_progress=lambda status: (
                on_progress("building_graph", 0, 1) if on_progress else None
            ),
        )

        return group_id
