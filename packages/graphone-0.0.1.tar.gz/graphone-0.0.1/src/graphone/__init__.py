"""GraphOne - библиотека для управления роем GraphEn Swarm."""

__version__ = "0.0.1"
