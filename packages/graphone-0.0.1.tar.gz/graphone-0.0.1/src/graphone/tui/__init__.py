"""TUI (Terminal User Interface) для Agentone."""
