from pathlib import Path
from graphone.tui.utils import Styles

styles = Styles(styles_directory=Path(__file__).parent / 'styles')
