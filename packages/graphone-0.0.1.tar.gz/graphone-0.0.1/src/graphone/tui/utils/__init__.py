"""
Пакет утилит для AgentOne TUI
"""
from .styles import Styles


__all__ = [
    'Styles'
]
