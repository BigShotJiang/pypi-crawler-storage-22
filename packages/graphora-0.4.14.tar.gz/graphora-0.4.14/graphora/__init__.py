"""
Graphora Client Library

A Python client for interacting with the Graphora API.
"""

from importlib.metadata import version, PackageNotFoundError

from graphora.client import GraphoraClient
from graphora.models import *  # noqa: F401,F403 - re-export public models

try:
    __version__ = version("graphora")
except PackageNotFoundError:
    __version__ = "0.0.0-dev"
