"""Config command - manage CLI configuration."""

import typer
from rich.console import Console
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich import print as rprint

from graphora.cli.config import (
    load_config,
    get_config_value,
    set_config_value,
    CONFIG_FILE,
    ensure_config_dir,
    is_embedded_available,
)
from graphora.cli.api_manager import (
    is_api_available,
    get_installed_version,
    setup_api,
)

app = typer.Typer(help="Manage Graphora CLI configuration")
console = Console()


@app.command("set")
def config_set(
    key: str = typer.Argument(..., help="Config key (e.g., llm.api_key)"),
    value: str = typer.Argument(..., help="Value to set"),
):
    """Set a configuration value.

    Examples:
        graphora config set llm.api_key "your-api-key"
        graphora config set llm.model "gemini-1.5-pro"
        graphora config set defaults.mode "remote"
        graphora config set api.url "https://api.graphora.io"
    """
    set_config_value(key, value)
    rprint(f"[green]Set {key} = {_mask_sensitive(key, value)}[/green]")


@app.command("get")
def config_get(
    key: str = typer.Argument(..., help="Config key to get"),
):
    """Get a configuration value.

    Examples:
        graphora config get llm.model
        graphora config get defaults.mode
    """
    value = get_config_value(key)

    if value is None:
        rprint(f"[yellow]Key '{key}' is not set[/yellow]")
        raise typer.Exit(1)

    rprint(f"{key} = {_mask_sensitive(key, value)}")


@app.command("show")
def config_show():
    """Show all configuration.

    Displays all config values with sensitive data masked.
    """
    config = load_config()

    table = Table(title="Graphora Configuration")
    table.add_column("Key", style="cyan")
    table.add_column("Value", style="green")

    def add_rows(d: dict, prefix: str = ""):
        for key, value in d.items():
            full_key = f"{prefix}{key}" if prefix else key
            if isinstance(value, dict):
                add_rows(value, f"{full_key}.")
            else:
                display_value = _mask_sensitive(full_key, value)
                table.add_row(full_key, str(display_value))

    add_rows(config)

    # Add embedded availability status
    table.add_row("", "")  # Empty row separator
    embedded_status = "[green]available[/green]" if is_embedded_available() else "[yellow]not installed[/yellow]"
    table.add_row("[dim]embedded mode[/dim]", embedded_status)

    console.print(table)
    rprint(f"\n[dim]Config file: {CONFIG_FILE}[/dim]")


@app.command("path")
def config_path():
    """Show the config file path."""
    ensure_config_dir()
    rprint(f"[cyan]{CONFIG_FILE}[/cyan]")


@app.command("init")
def config_init(
    mode: str = typer.Option(
        None, "--mode", "-m", help="CLI mode: 'embedded' or 'remote'"
    ),
    api_key: str = typer.Option(
        None, "--api-key", "-k", help="LLM API key (for embedded mode)"
    ),
    api_path: str = typer.Option(
        None, "--api-path", "-p", help="Custom path to graphora-api (optional, auto-downloads by default)"
    ),
    api_url: str = typer.Option(
        None, "--api-url", "-u", help="Remote API URL (for remote mode)"
    ),
    auth_token: str = typer.Option(
        None, "--auth-token", "-t", help="Auth token (for remote mode)"
    ),
    skip_download: bool = typer.Option(
        False, "--skip-download", help="Skip auto-download of graphora-api"
    ),
):
    """Initialize configuration interactively.

    For embedded mode, graphora-api is automatically downloaded and cached.
    You only need to provide your Gemini API key.

    Examples:
        graphora config init --api-key "your-gemini-key"
        graphora config init --mode remote --api-url "https://api.graphora.io" --auth-token "token"
        graphora config init --api-path "/path/to/local/graphora-api"  # Use local clone
    """
    import os

    # Determine mode
    if mode is None:
        rprint("[cyan]Select execution mode:[/cyan]")
        rprint("  [dim]embedded[/dim] - Run locally with Gemini API (recommended, auto-downloads)")
        rprint("  [dim]remote[/dim]   - Use hosted Graphora API (requires auth token)")
        mode = typer.prompt(
            "\nMode (embedded/remote)",
            default="embedded",
        )
        if mode not in ["embedded", "remote"]:
            rprint(f"[red]Invalid mode: {mode}. Must be 'embedded' or 'remote'[/red]")
            raise typer.Exit(1)

    set_config_value("defaults.mode", mode)

    if mode == "embedded":
        # Handle custom api_path if provided
        if api_path:
            api_path = os.path.expanduser(api_path)
            if os.path.isdir(api_path):
                set_config_value("embedded.api_path", api_path)
                rprint(f"[green]Using custom graphora-api path: {api_path}[/green]")
            else:
                rprint(f"[red]Directory not found: {api_path}[/red]")
                raise typer.Exit(1)
        elif not skip_download and not is_api_available():
            # Auto-download graphora-api
            rprint("\n[cyan]Setting up graphora-api...[/cyan]")

            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
            ) as progress:
                task = progress.add_task("Downloading graphora-api...", total=None)

                def update_progress(msg):
                    progress.update(task, description=msg)

                success, message = setup_api(progress_callback=update_progress)

            if success:
                rprint(f"[green]{message}[/green]")
            else:
                rprint(f"[red]{message}[/red]")
                rprint("\nYou can manually specify a path with --api-path")
                raise typer.Exit(1)

        # Get API key
        if api_key is None:
            rprint("")
            api_key = typer.prompt("Enter your Gemini API key")
        set_config_value("llm.api_key", api_key)

        # Always update model to current default (fixes stale configs with deprecated models)
        from graphora.cli.config import DEFAULT_CONFIG
        set_config_value("llm.model", DEFAULT_CONFIG["llm"]["model"])
        set_config_value("llm.provider", DEFAULT_CONFIG["llm"]["provider"])

        rprint("\n[green]Embedded mode configuration complete![/green]")
        version = get_installed_version()
        if version:
            rprint(f"  graphora-api: {version}")
    else:
        if api_url is None:
            api_url = typer.prompt(
                "Enter the Graphora API URL",
                default="https://api.graphora.io"
            )
        if auth_token is None:
            auth_token = typer.prompt("Enter your auth token")

        set_config_value("api.url", api_url)
        set_config_value("api.auth_token", auth_token)
        rprint("\n[green]Remote mode configuration complete![/green]")

    rprint("\nYou can now run:")
    rprint("  [cyan]graphora extract document.pdf -o graph.json[/cyan]")


def _mask_sensitive(key: str, value) -> str:
    """Mask sensitive values like API keys."""
    sensitive_keys = ["api_key", "password", "secret", "token"]

    if any(s in key.lower() for s in sensitive_keys):
        if value and isinstance(value, str) and len(value) > 8:
            return f"{value[:4]}...{value[-4:]}"
        elif value:
            return "****"

    return str(value) if value is not None else "(not set)"
