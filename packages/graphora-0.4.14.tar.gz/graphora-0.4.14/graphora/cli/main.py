"""Main CLI entry point for Graphora."""

import typer
from rich import print as rprint
from rich.console import Console

from graphora.cli import __version__
from graphora.cli.commands import config_cmd, extract, schema

app = typer.Typer(
    name="graphora",
    help="Graphora CLI - Extract knowledge graphs from documents",
    no_args_is_help=True,
)


def version_callback(value: bool):
    if value:
        from graphora.cli.api_manager import get_installed_version
        from graphora.cli.config import get_llm_model
        rprint(f"graphora-cli {__version__}")
        api_version = get_installed_version()
        if api_version:
            rprint(f"graphora-api {api_version}")
        rprint(f"llm model   {get_llm_model()}")
        raise typer.Exit()


@app.callback()
def main(
    version: bool = typer.Option(
        None,
        "--version",
        "-V",
        "-v",
        callback=version_callback,
        is_eager=True,
        help="Show version and exit",
    ),
):
    """Graphora CLI - Extract knowledge graphs from documents.

    Graphora transforms unstructured documents into structured knowledge graphs
    using LLM-powered extraction.

    Modes:
      - embedded: Run extraction locally using Gemini API (requires graphora[embedded])
      - remote: Use Graphora's hosted API (requires auth token)

    Quick Start:
      1. Configure: graphora config init
      2. Extract: graphora extract document.pdf -o graph.json

    For more help on a command: graphora <command> --help
    """
    pass


# Add subcommands
app.add_typer(config_cmd.app, name="config")
app.add_typer(schema.app, name="schema")

# Register extract as a direct command
app.command(name="extract")(extract.extract)


@app.command("version")
def version_cmd():
    """Show version information."""
    from graphora.cli.api_manager import get_installed_version
    from graphora.cli.config import get_llm_model
    rprint(f"graphora-cli {__version__}")
    api_version = get_installed_version()
    if api_version:
        rprint(f"graphora-api {api_version}")
    rprint(f"llm model   {get_llm_model()}")


@app.command("init")
def init_cmd(
    api_key: str = typer.Option(None, "--api-key", "-k", help="Gemini API key"),
    mode: str = typer.Option(None, "--mode", "-m", help="Mode: embedded or remote"),
):
    """Initialize Graphora CLI (shortcut for 'graphora config init')."""
    from graphora.cli.commands.config_cmd import config_init
    config_init(mode=mode, api_key=api_key, api_path=None, api_url=None, auth_token=None, skip_download=False)


@app.command("update")
def update_cmd(
    force: bool = typer.Option(False, "--force", "-f", help="Force re-download even if up to date"),
    version: str = typer.Option(None, "--version", "-v", help="Specific version to install (e.g., v1.2.0)"),
    channel: str = typer.Option(None, "--channel", "-c", help="Version channel: stable, nightly, or main"),
):
    """Update graphora-api to the latest version.

    Downloads the latest version of graphora-api from GitHub.

    Channels:
      - stable: Latest stable release (default)
      - nightly: Latest nightly build
      - main: Development branch

    Examples:
        graphora update
        graphora update --channel nightly
        graphora update --version v1.2.0
        graphora update --force
    """
    from rich.progress import Progress, SpinnerColumn, TextColumn
    from graphora.cli.api_manager import setup_api, get_installed_version, get_latest_version
    from graphora.cli.config import get_config_value, set_config_value

    current = get_installed_version()
    if current:
        rprint(f"Current version: {current}")

    # Determine channel
    if not channel:
        channel = get_config_value("embedded.channel") or "main"

    if not version:
        rprint(f"Checking for updates ({channel} channel)...")
        version = get_latest_version(channel)
        rprint(f"Latest version: {version}")

    if current == version and not force:
        rprint("[green]Already up to date![/green]")
        return

    # Save channel preference
    if channel:
        set_config_value("embedded.channel", channel)

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=Console(),
    ) as progress:
        task = progress.add_task("Updating...", total=None)

        def update_progress(msg):
            progress.update(task, description=msg)

        success, message = setup_api(
            version=version,
            channel=channel,
            force=force,
            progress_callback=update_progress
        )

    if success:
        rprint(f"[green]{message}[/green]")
    else:
        rprint(f"[red]{message}[/red]")
        raise typer.Exit(1)


@app.command("status")
def status():
    """Show current configuration status and mode availability."""
    from graphora.cli.config import (
        get_mode,
        get_api_key,
        get_api_url,
        get_auth_token,
        get_embedded_api_path,
        is_embedded_available,
        get_llm_model,
    )
    from graphora.cli.api_manager import get_installed_version

    rprint("\n[bold]Graphora CLI Status[/bold]")
    rprint(f"Version: {__version__}")
    rprint("")

    # Current mode
    current_mode = get_mode()
    rprint(f"[cyan]Current Mode:[/cyan] {current_mode}")
    rprint("")

    # Embedded mode status
    rprint("[bold]Embedded Mode:[/bold]")

    if is_embedded_available():
        api_path = get_embedded_api_path()
        installed_version = get_installed_version()

        if installed_version:
            rprint(f"  graphora-api: [green]{installed_version}[/green] (auto-managed)")
        elif api_path:
            rprint(f"  graphora-api: [green]available[/green] ({api_path})")
        else:
            rprint("  graphora-api: [green]available[/green]")

        api_key = get_api_key()
        if api_key:
            masked_key = f"{api_key[:4]}...{api_key[-4:]}" if len(api_key) > 8 else "****"
            rprint(f"  LLM API Key: [green]configured[/green] ({masked_key})")
            rprint(f"  LLM Model: {get_llm_model()}")
            rprint("  Status: [green]Ready[/green]")
        else:
            rprint("  LLM API Key: [yellow]not configured[/yellow]")
            rprint("  Status: [yellow]Needs API key[/yellow]")
    else:
        rprint("  graphora-api: [yellow]not installed[/yellow]")
        rprint("  Run: [cyan]graphora config init[/cyan] to download and configure")

    rprint("")

    # Remote mode status
    rprint("[bold]Remote Mode:[/bold]")
    api_url = get_api_url()
    auth_token = get_auth_token()

    if api_url:
        rprint(f"  API URL: [green]configured[/green] ({api_url})")
    else:
        rprint("  API URL: [yellow]not configured[/yellow]")

    if auth_token:
        masked_token = f"{auth_token[:4]}...{auth_token[-4:]}" if len(auth_token) > 8 else "****"
        rprint(f"  Auth Token: [green]configured[/green] ({masked_token})")
    else:
        rprint("  Auth Token: [yellow]not configured[/yellow]")

    if api_url and auth_token:
        rprint("  Status: [green]Ready[/green]")
    else:
        rprint("  Status: [yellow]Needs configuration[/yellow]")

    rprint("")


def cli():
    """CLI entry point."""
    app()


if __name__ == "__main__":
    cli()
