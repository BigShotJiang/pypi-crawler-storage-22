"""Runtime initialization for CLI.

Sets up the environment and services for direct usage without FastAPI.
"""

import logging
import os
import sys
from pathlib import Path
from typing import Optional


class _CLIModeFilter(logging.Filter):
    """Filter out expected warnings when running in CLI mode without a database."""

    SUPPRESSED_MESSAGES = [
        "No model pricing found",
        "Failed to create LLM usage record",
        "Error tracking LLM usage",
        "Failed to track Gemini usage",
        "Refreshed model pricing cache",
    ]

    def filter(self, record: logging.LogRecord) -> bool:
        msg = record.getMessage()
        return not any(suppressed in msg for suppressed in self.SUPPRESSED_MESSAGES)


def _suppress_db_warnings() -> None:
    """Suppress PostgreSQL pool warnings in CLI mode.

    The graphora-api tries to create a DB pool but we don't need it.
    """
    import warnings

    logging.getLogger("psycopg.pool").setLevel(logging.ERROR)
    logging.getLogger("psycopg_pool").setLevel(logging.ERROR)

    # Suppress the RuntimeWarning about async pool constructor
    warnings.filterwarnings(
        "ignore",
        message="opening the async pool.*",
        category=RuntimeWarning,
        module="psycopg_pool",
    )

    # Add filter to suppress expected DB-related warnings in CLI mode
    app_logger = logging.getLogger("app.utils.logger")
    app_logger.addFilter(_CLIModeFilter())


def _patch_db_operations() -> None:
    """Patch database operations to be no-ops in CLI mode.

    This prevents 30-second timeouts waiting for database connections
    when tracking usage and other non-essential DB operations.
    """
    try:
        import app.db.postgres as db

        # Store original functions
        _original_fetchrow = db.fetchrow
        _original_fetch = db.fetch
        _original_execute = db.execute

        async def fetchrow_noop(query: str, *args):
            # Skip usage tracking and other non-critical queries
            if any(skip in query.lower() for skip in [
                "llm_usage", "document_usage", "model_pricing",
                "user_ai_config", "user_api_key", "entity_ledger"
            ]):
                return None
            # For other queries, still try (but they may fail)
            try:
                return await _original_fetchrow(query, *args)
            except Exception:
                return None

        async def fetch_noop(query: str, *args):
            if any(skip in query.lower() for skip in [
                "llm_usage", "document_usage", "model_pricing"
            ]):
                return []
            try:
                return await _original_fetch(query, *args)
            except Exception:
                return []

        async def execute_noop(query: str, *args):
            if any(skip in query.lower() for skip in [
                "llm_usage", "document_usage", "entity_ledger"
            ]):
                return None
            try:
                return await _original_execute(query, *args)
            except Exception:
                return None

        db.fetchrow = fetchrow_noop
        db.fetch = fetch_noop
        db.execute = execute_noop

    except ImportError:
        pass


def init_embedded_environment(api_key: Optional[str] = None) -> None:
    """Initialize environment for embedded CLI execution.

    Sets up environment variables needed by the services when running
    in embedded mode (using graphora-api services directly).

    Args:
        api_key: Optional API key override. If not provided, uses config.
    """
    from graphora.cli.config import get_api_key, get_llm_model, get_llm_provider, setup_embedded_path

    # Set up graphora-api path first
    setup_embedded_path()

    # Set API key
    key = api_key or get_api_key()
    if key:
        os.environ["GEMINI_API_KEY"] = key
        os.environ["GOOGLE_API_KEY"] = key

    # Set LLM config
    os.environ.setdefault("LLM_PROVIDER", get_llm_provider())
    os.environ.setdefault("LLM_MODEL", get_llm_model())

    # Disable auth for CLI usage
    os.environ["AUTH_BYPASS_ENABLED"] = "true"

    # Use in-memory storage by default
    os.environ.setdefault("GRAPH_STORAGE_MODE", "memory")

    # Disable Prefect for direct execution
    os.environ["PREFECT_API_URL"] = ""

    # Set test mode to skip database requirements
    os.environ["TEST_MODE"] = "true"

    # Provide dummy database URL to satisfy config validation
    os.environ.setdefault("DATABASE_URL", "sqlite:///memory")

    # Suppress PostgreSQL pool warnings (we don't need the database)
    _suppress_db_warnings()

    # Patch database operations to be no-ops in CLI mode
    _patch_db_operations()

    # Patch LLM helper to bypass database for credentials
    _patch_llm_credentials()


_llm_patched = False


def _patch_llm_credentials() -> None:
    """Patch the LLM helper to use environment variables instead of database.

    This allows CLI mode to work without a database connection.
    """
    global _llm_patched
    if _llm_patched:
        return

    try:
        # Import and patch the llm_helper module
        import app.utils.llm_helper as llm_helper

        async def get_user_llm_credentials_cli(user_id: str):
            """CLI version that uses env vars instead of database."""
            api_key = os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY")
            model_name = os.environ.get("LLM_MODEL", "gemini-2.5-flash-lite")

            if not api_key:
                from app.exceptions import NoAIConfigurationError
                raise NoAIConfigurationError(user_id)

            return api_key, model_name

        # Replace the function in the module
        llm_helper.get_user_llm_credentials = get_user_llm_credentials_cli

        # Also patch it in the LLM client module since it may have already imported it
        try:
            import app.services.llm.client as llm_client_module
            llm_client_module.get_user_llm_credentials = get_user_llm_credentials_cli
        except ImportError:
            pass

        _llm_patched = True

    except ImportError:
        # API not available yet
        pass


def validate_embedded_environment() -> bool:
    """Validate that required configuration is present for embedded mode.

    Returns:
        True if environment is valid, False otherwise.
    """
    from graphora.cli.config import get_api_key, is_embedded_available

    if not is_embedded_available():
        return False

    api_key = get_api_key()
    if not api_key:
        return False

    return True


def validate_remote_environment() -> bool:
    """Validate that required configuration is present for remote mode.

    Returns:
        True if environment is valid, False otherwise.
    """
    from graphora.cli.config import get_api_url, get_auth_token

    if not get_api_url():
        return False

    if not get_auth_token():
        return False

    return True


def get_missing_config(mode: str = "embedded") -> list[str]:
    """Get list of missing required configuration.

    Args:
        mode: Either 'embedded' or 'remote'

    Returns:
        List of missing config keys.
    """
    from graphora.cli.config import (
        get_api_key,
        get_api_url,
        get_auth_token,
        is_embedded_available,
    )

    missing = []

    if mode == "embedded":
        if not is_embedded_available():
            missing.append("graphora-api package (pip install graphora[embedded])")

        if not get_api_key():
            missing.append("llm.api_key (or GRAPHORA_API_KEY env var)")

    else:  # remote mode
        if not get_api_url():
            missing.append("api.url (or GRAPHORA_API_URL env var)")

        if not get_auth_token():
            missing.append("api.auth_token (or GRAPHORA_AUTH_TOKEN env var)")

    return missing
