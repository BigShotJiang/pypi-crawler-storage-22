"""Graphora CLI - Command-line interface for knowledge graph extraction."""

__version__ = "0.4.7"
