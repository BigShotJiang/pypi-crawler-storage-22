"""Extract command - extract knowledge graphs from documents."""

import asyncio
import json
from pathlib import Path
from typing import List, Optional

import typer
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn
from rich import print as rprint

from graphora.cli import __version__ as cli_version
from graphora.cli.config import get_mode, get_api_key, is_embedded_available
from graphora.cli.api_manager import get_installed_version
from graphora.cli.runtime import (
    init_embedded_environment,
    validate_embedded_environment,
    validate_remote_environment,
    get_missing_config,
)

console = Console()


def extract(
    files: List[Path] = typer.Argument(
        ...,
        help="Document files or directories to process",
    ),
    output: Path = typer.Option(
        Path("graph.json"),
        "--output",
        "-o",
        help="Output file path",
    ),
    schema: Optional[Path] = typer.Option(
        None,
        "--schema",
        "-s",
        help="Ontology YAML file (auto-inferred if not provided)",
        exists=True,
    ),
    format: str = typer.Option(
        "json",
        "--format",
        "-f",
        help="Output format: json, cypher",
    ),
    api_key: Optional[str] = typer.Option(
        None,
        "--api-key",
        "-k",
        help="LLM API key (overrides config, embedded mode only)",
        envvar="GRAPHORA_API_KEY",
    ),
    mode: Optional[str] = typer.Option(
        None,
        "--mode",
        "-m",
        help="Execution mode: embedded, remote (overrides config)",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="Show detailed progress",
    ),
):
    """Extract knowledge graph from documents.

    Supports two modes:
    - embedded: Uses local LLM directly (requires graphora[embedded])
    - remote: Uses remote Graphora API (requires auth token)

    Examples:
        graphora extract document.pdf -o graph.json
        graphora extract doc1.pdf doc2.pdf -o combined.json
        graphora extract docs/ --schema ontology.yaml -o graph.json
        graphora extract report.pdf -f cypher -o import.cypher
        graphora extract document.pdf --mode remote
    """
    # Determine mode
    execution_mode = mode or get_mode()

    # Collect all files
    all_files = _collect_files(files)

    if not all_files:
        rprint("[red]No valid document files found.[/red]")
        raise typer.Exit(1)

    # Show version info
    api_version = get_installed_version() or "unknown"
    rprint(f"[dim]graphora-cli {cli_version} | graphora-api {api_version}[/dim]")

    rprint(f"[cyan]Processing {len(all_files)} document(s) in {execution_mode} mode...[/cyan]")

    try:
        if execution_mode == "embedded":
            result = _run_embedded_extraction(
                files=all_files,
                schema_path=schema,
                api_key=api_key,
                verbose=verbose,
            )
        else:
            result = _run_remote_extraction(
                files=all_files,
                schema_path=schema,
                verbose=verbose,
            )

        # Write output
        _write_output(result, output, format)

        # Summary
        node_count = len(result.get("nodes", []))
        edge_count = len(result.get("edges", []))
        rprint(f"\n[green]Extraction complete![/green]")
        rprint(f"  Nodes: {node_count}")
        rprint(f"  Relationships: {edge_count}")
        rprint(f"  Output: [cyan]{output}[/cyan]")

    except Exception as e:
        rprint(f"[red]Extraction failed: {str(e)}[/red]")
        if verbose:
            console.print_exception()
        raise typer.Exit(1)


def _collect_files(paths: List[Path]) -> List[Path]:
    """Collect all document files from paths (files or directories)."""
    supported_extensions = {".pdf", ".txt", ".md", ".docx", ".doc"}
    files = []

    for path in paths:
        if path.is_file():
            if path.suffix.lower() in supported_extensions:
                files.append(path)
        elif path.is_dir():
            for ext in supported_extensions:
                files.extend(path.glob(f"**/*{ext}"))

    return sorted(set(files))


async def _infer_schema_cli(text_chunks: List[str], max_sample_chars: int = 15000) -> dict:
    """CLI version of schema inference that uses env vars for credentials.

    This bypasses the database-based credential lookup.
    """
    import os
    from google import genai
    from google.genai import types

    # Get credentials from environment
    api_key = os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY")
    model_name = os.environ.get("LLM_MODEL", "gemini-2.5-flash-lite")

    if not api_key:
        raise ValueError(
            "No API key found. Set GEMINI_API_KEY or GOOGLE_API_KEY environment variable, "
            "or run 'graphora config init' to configure."
        )

    # Sample text from chunks
    sample = ""
    for chunk in text_chunks:
        remaining = max_sample_chars - len(sample)
        if remaining <= 0:
            break
        sample += chunk[:remaining] + "\n\n"

    if not sample.strip():
        raise ValueError("No text content available for schema inference")

    # Schema inference prompt
    prompt = f"""Analyze the following text and extract a knowledge graph schema.

<text>
{sample}
</text>

Generate a YAML ontology that captures:
1. Main entity types mentioned (people, organizations, concepts, events, locations, etc.)
2. Key relationships between entities
3. Important properties for each entity type

Rules:
- Only include entity types that are clearly present in the text
- Use PascalCase for entity names (e.g., Person, Organization, Event)
- Use SCREAMING_SNAKE_CASE for relationship types (e.g., WORKS_AT, KNOWS)
- Include 2-5 properties per entity type
- Mark key identifying properties as required
- Use appropriate data types: str, int, float, bool, datetime, list

Output ONLY valid YAML in this exact format (no markdown code blocks, no explanation):

version: "0.1.0"
entities:
  EntityName:
    description: "Brief description of the entity"
    properties:
      property_name:
        type: str
        description: "Property description"
        required: true
relationships:
  RELATIONSHIP_TYPE:
    description: "Brief description"
    source: SourceEntity
    target: TargetEntity
    properties: {{}}
"""

    # Call Gemini API
    client = genai.Client(api_key=api_key)
    response = client.models.generate_content(
        model=model_name,
        contents=[prompt],
        config=types.GenerateContentConfig(
            temperature=0.2,
            max_output_tokens=4096,
        ),
    )

    response_text = response.text.strip()

    # Parse YAML from response
    import re
    import yaml as yaml_lib

    yaml_match = re.search(r"```(?:yaml|yml)?\s*\n(.*?)```", response_text, re.DOTALL)
    if yaml_match:
        yaml_content = yaml_match.group(1)
    else:
        # Strip any stray backticks the LLM may have included
        yaml_content = response_text.replace("```yaml", "").replace("```yml", "").replace("```", "")
    yaml_content = yaml_content.strip()

    ontology = yaml_lib.safe_load(yaml_content)

    # Validate and normalize
    if not isinstance(ontology, dict):
        raise ValueError(f"Expected dict, got {type(ontology)}")

    if "entities" not in ontology or not ontology["entities"]:
        raise ValueError("Inferred schema has no entities")

    if "version" not in ontology:
        ontology["version"] = "0.1.0"

    if "relationships" not in ontology:
        ontology["relationships"] = {}

    return ontology


def _chunk_text(text: str, chunk_size: int = 2000, overlap: int = 200) -> List[str]:
    """Split text into overlapping chunks.

    Args:
        text: Text content to chunk
        chunk_size: Target size for each chunk
        overlap: Number of characters to overlap between chunks

    Returns:
        List of text chunks
    """
    if len(text) <= chunk_size:
        return [text]

    chunks = []
    start = 0

    while start < len(text):
        end = start + chunk_size

        # Try to find a good break point (paragraph or sentence boundary)
        if end < len(text):
            # Look for paragraph break
            break_point = text.rfind("\n\n", start, end)
            if break_point == -1 or break_point < start + chunk_size // 2:
                # Look for sentence break
                break_point = text.rfind(". ", start, end)
                if break_point != -1:
                    break_point += 1  # Include the period

            if break_point > start + chunk_size // 2:
                end = break_point

        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)

        # Move start with overlap
        start = end - overlap if end < len(text) else end

    return chunks


def _run_embedded_extraction(
    files: List[Path],
    schema_path: Optional[Path],
    api_key: Optional[str],
    verbose: bool,
) -> dict:
    """Run extraction using embedded graphora-api services."""
    # Check if embedded mode is available
    if not is_embedded_available():
        rprint("[red]Embedded mode not available.[/red]")
        rprint("Install with: [cyan]pip install graphora[embedded][/cyan]")
        raise typer.Exit(1)

    # Initialize environment
    init_embedded_environment(api_key)

    # Validate configuration
    if not validate_embedded_environment():
        missing = get_missing_config("embedded")
        rprint("[red]Missing required configuration:[/red]")
        for item in missing:
            rprint(f"  - {item}")
        rprint("\nRun [cyan]graphora config init[/cyan] to set up configuration.")
        raise typer.Exit(1)

    # Run the async extraction
    return asyncio.run(
        _run_embedded_extraction_async(
            files=files,
            schema_path=schema_path,
            verbose=verbose,
        )
    )


async def _run_embedded_extraction_async(
    files: List[Path],
    schema_path: Optional[Path],
    verbose: bool,
) -> dict:
    """Run the embedded extraction pipeline asynchronously."""
    import os
    import uuid
    import yaml as yaml_lib

    # Patch LLM credentials BEFORE importing graph_transformer (which imports LLMClient)
    async def get_user_llm_credentials_cli(user_id: str):
        """CLI version that uses env vars instead of database."""
        api_key = os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY")
        model_name = os.environ.get("LLM_MODEL", "gemini-2.5-flash-lite")
        if not api_key:
            raise ValueError("No API key found. Set GEMINI_API_KEY environment variable.")
        return api_key, model_name

    # Patch in the helper module before other imports
    import app.utils.llm_helper as llm_helper
    llm_helper.get_user_llm_credentials = get_user_llm_credentials_cli

    # Now import the rest - they will use our patched function
    from app.services.llm.client import LLMClient
    # Patch again in the client module where it's used
    import app.services.llm.client as llm_client_module
    llm_client_module.get_user_llm_credentials = get_user_llm_credentials_cli

    # Import graphora-api services (only available in embedded mode)
    from app.services.transform.graph_transformer import build_graph_from_chunks, build_graph_from_pdfs
    from app.services.transform.ontology_helper import OntologyParser
    from app.services.document_parser import DocumentParser

    all_nodes = []
    all_relationships = []
    parsed_ontology = None
    document_parser = DocumentParser()

    # Use a dummy user_id for CLI mode
    cli_user_id = "cli-user"

    # Separate PDF files from text files
    pdf_files = [f for f in files if f.suffix.lower() == ".pdf"]
    text_files = [f for f in files if f.suffix.lower() != ".pdf"]

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
        console=console,
    ) as progress:
        # For text files, parse and chunk them
        chunks = []
        if text_files:
            task = progress.add_task("Parsing text documents...", total=len(text_files))
            for file_path in text_files:
                try:
                    content = await document_parser.parse_file(str(file_path))
                    if content:
                        if len(content) > 2000:
                            doc_chunks = _chunk_text(content, chunk_size=2000)
                        else:
                            doc_chunks = [content]
                        chunks.extend(doc_chunks)
                        if verbose:
                            rprint(f"  [dim]Parsed {file_path.name}: {len(doc_chunks)} chunks[/dim]")
                    else:
                        rprint(f"  [yellow]Warning: No content from {file_path.name}[/yellow]")
                except Exception as e:
                    rprint(f"  [yellow]Warning: Failed to parse {file_path.name}: {e}[/yellow]")
                progress.advance(task)

        # For PDFs, we'll send them directly to Gemini (better OCR)
        if pdf_files and verbose:
            rprint(f"  [dim]Will process {len(pdf_files)} PDF(s) with Gemini's native PDF handling[/dim]")

        # Load or infer schema
        if schema_path:
            task = progress.add_task("Loading schema...", total=1)
            with open(schema_path, "r") as f:
                parsed_ontology = yaml_lib.safe_load(f.read())
            progress.advance(task)
        else:
            # For schema inference, we need some text content
            if chunks:
                sample_text = chunks
            elif pdf_files:
                # Extract first few pages for schema inference only
                task = progress.add_task("Sampling PDF for schema inference...", total=1)
                sample_text = []
                for pdf_file in pdf_files[:1]:  # Just first PDF
                    content = await document_parser.parse_file(str(pdf_file))
                    if content:
                        sample_text.append(content)
                progress.advance(task)
            else:
                raise ValueError("No content available for schema inference")

            task = progress.add_task("Inferring schema from content...", total=1)
            parsed_ontology = await _infer_schema_cli(text_chunks=sample_text)
            progress.advance(task)
            if verbose:
                entities = list(parsed_ontology.get("entities", {}).keys())
                rprint(f"  [dim]Inferred entities: {', '.join(entities)}[/dim]")

        # Create OntologyParser from the parsed schema
        ontology_yaml = yaml_lib.dump(parsed_ontology)
        ontology_parser = OntologyParser(ontology_yaml, user_id=cli_user_id)

        # Extract knowledge graph
        transform_id = f"cli-{uuid.uuid4().hex[:8]}"

        # Process PDFs with Gemini's native PDF handling
        if pdf_files:
            task = progress.add_task("Extracting from PDFs (Gemini native)...", total=1)
            try:
                pdf_paths = [str(f) for f in pdf_files]
                graph_result = await build_graph_from_pdfs(
                    ontology_parser=ontology_parser,
                    pdf_paths=pdf_paths,
                    transform_id=transform_id,
                    user_id=cli_user_id,
                )
                if graph_result:
                    all_nodes.extend(graph_result.nodes or [])
                    all_relationships.extend(graph_result.relationships or [])
                if verbose:
                    rprint(f"  [dim]Extracted {len(graph_result.nodes or [])} nodes from PDFs[/dim]")
            except Exception as e:
                if verbose:
                    rprint(f"  [yellow]Warning: PDF extraction failed: {e}[/yellow]")
                raise
            progress.advance(task)

        # Process text chunks
        if chunks:
            task = progress.add_task("Extracting from text...", total=1)
            try:
                graph_result = await build_graph_from_chunks(
                    ontology_parser=ontology_parser,
                    chunks=chunks,
                    transform_id=transform_id,
                    user_id=cli_user_id,
                )
                if graph_result:
                    all_nodes.extend(graph_result.nodes or [])
                    all_relationships.extend(graph_result.relationships or [])
                if verbose:
                    rprint(f"  [dim]Extracted {len(graph_result.nodes or [])} nodes from text[/dim]")
            except Exception as e:
                if verbose:
                    rprint(f"  [yellow]Warning: Text extraction failed: {e}[/yellow]")
                raise
            progress.advance(task)

    # Convert to output format
    return {
        "nodes": [_node_to_dict(n) for n in all_nodes],
        "edges": [_rel_to_dict(r) for r in all_relationships],
        "schema": parsed_ontology,
        "metadata": {
            "source_files": [str(f) for f in files],
            "node_count": len(all_nodes),
            "edge_count": len(all_relationships),
        },
    }


def _run_remote_extraction(
    files: List[Path],
    schema_path: Optional[Path],
    verbose: bool,
) -> dict:
    """Run extraction using remote Graphora API."""
    # Validate remote configuration
    if not validate_remote_environment():
        missing = get_missing_config("remote")
        rprint("[red]Missing required configuration:[/red]")
        for item in missing:
            rprint(f"  - {item}")
        rprint("\nRun [cyan]graphora config init --mode remote[/cyan] to set up configuration.")
        raise typer.Exit(1)

    from graphora import GraphoraClient
    from graphora.cli.config import get_api_url, get_auth_token

    # Initialize client
    client = GraphoraClient(
        base_url=get_api_url(),
        auth_token=get_auth_token(),
    )

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        # Register ontology
        ontology_id = None
        if schema_path:
            task = progress.add_task("Registering ontology...", total=1)
            with open(schema_path, "r") as f:
                ontology_yaml = f.read()
            response = client.register_ontology(ontology_yaml)
            ontology_id = response.id
            progress.advance(task)
            if verbose:
                rprint(f"  [dim]Ontology registered: {ontology_id}[/dim]")
        else:
            # For remote mode without schema, we need to use a default or
            # let the server infer it. The API may require an ontology.
            rprint("[yellow]Remote mode requires an ontology. Use --schema to provide one.[/yellow]")
            raise typer.Exit(1)

        # Upload and transform
        task = progress.add_task("Uploading and transforming documents...", total=1)
        transform_response = client.transform(ontology_id, files)
        transform_id = transform_response.id
        if verbose:
            rprint(f"  [dim]Transform started: {transform_id}[/dim]")
        progress.advance(task)

        # Wait for completion
        task = progress.add_task("Waiting for extraction to complete...", total=1)
        final_status = client.wait_for_transform(transform_id)
        progress.advance(task)

        if verbose:
            rprint(f"  [dim]Transform status: {final_status.overall_status}[/dim]")

        # Get graph data
        task = progress.add_task("Retrieving graph data...", total=1)
        graph_response = client.get_transformed_graph(transform_id)
        progress.advance(task)

    # Convert to output format
    nodes = [n.model_dump() if hasattr(n, 'model_dump') else n for n in graph_response.nodes]
    edges = [e.model_dump() if hasattr(e, 'model_dump') else e for e in graph_response.edges]

    return {
        "nodes": nodes,
        "edges": edges,
        "metadata": {
            "source_files": [str(f) for f in files],
            "transform_id": transform_id,
            "node_count": len(nodes),
            "edge_count": len(edges),
        },
    }


def _node_to_dict(node) -> dict:
    """Convert a node to dictionary format."""
    if hasattr(node, "model_dump"):
        return node.model_dump()
    elif hasattr(node, "dict"):
        return node.dict()
    elif hasattr(node, "__dict__"):
        return {
            "id": getattr(node, "id", None),
            "type": getattr(node, "type", None),
            "properties": getattr(node, "properties", {}),
        }
    return dict(node)


def _rel_to_dict(rel) -> dict:
    """Convert a relationship to dictionary format."""
    if hasattr(rel, "model_dump"):
        return rel.model_dump()
    elif hasattr(rel, "dict"):
        return rel.dict()
    elif hasattr(rel, "__dict__"):
        return {
            "source_id": getattr(rel, "source_id", None),
            "target_id": getattr(rel, "target_id", None),
            "type": getattr(rel, "type", None),
            "properties": getattr(rel, "properties", {}),
        }
    return dict(rel)


def _write_output(result: dict, output: Path, format: str) -> None:
    """Write extraction result to file."""
    if format == "json":
        with open(output, "w") as f:
            json.dump(result, f, indent=2, default=str)

    elif format == "cypher":
        cypher_statements = _to_cypher(result)
        with open(output, "w") as f:
            f.write(cypher_statements)

    else:
        raise ValueError(f"Unsupported output format: {format}")


def _to_cypher(result: dict) -> str:
    """Convert graph to Cypher CREATE statements."""
    statements = []

    # Create nodes
    for node in result.get("nodes", []):
        node_id = node.get("id", "")
        node_type = node.get("type", "Node")
        props = node.get("properties", {})

        # Format properties
        prop_str = ", ".join(
            f"{k}: {json.dumps(v)}" for k, v in props.items() if v is not None
        )
        if node_id:
            prop_str = f"id: {json.dumps(node_id)}" + (f", {prop_str}" if prop_str else "")

        statements.append(f"CREATE (:{node_type} {{{prop_str}}})")

    statements.append("")  # Empty line

    # Create relationships
    for edge in result.get("edges", []):
        source = edge.get("source_id", "")
        target = edge.get("target_id", "")
        rel_type = edge.get("type", "RELATED_TO")
        props = edge.get("properties", {})

        prop_str = ""
        if props:
            prop_str = " {" + ", ".join(
                f"{k}: {json.dumps(v)}" for k, v in props.items() if v is not None
            ) + "}"

        statements.append(
            f"MATCH (a {{id: {json.dumps(source)}}}), (b {{id: {json.dumps(target)}}}) "
            f"CREATE (a)-[:{rel_type}{prop_str}]->(b)"
        )

    return "\n".join(statements)
