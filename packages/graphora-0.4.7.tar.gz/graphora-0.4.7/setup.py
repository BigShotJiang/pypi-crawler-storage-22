"""
Setup script for the Graphora client library.
"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="graphora",
    version="0.4.7",
    author="Graphora Team",
    author_email="support@graphora.io",
    description="Python client for the Graphora API",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/graphora/graphora-client",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.9",
    install_requires=[
        "requests>=2.25.0",
        "pydantic>=2.0.0",
        "pyyaml>=5.4.0",
    ],
    extras_require={
        "cli": [
            "typer>=0.9.0",
            "rich>=13.0.0",
            "aiofiles>=23.0.0",
            # PDF parsing
            "pypdf>=4.0.0",
            "pdfplumber>=0.10.0",
            # LLM clients
            "google-genai>=1.0.0",
            # Note: graphora-api is auto-downloaded to ~/.graphora/api/
            # Additional deps may be installed from its requirements.txt
        ],
        "embedded": [
            "typer>=0.9.0",
            "rich>=13.0.0",
            "aiofiles>=23.0.0",
            # PDF parsing
            "pypdf>=4.0.0",
            "pdfplumber>=0.10.0",
            # LLM clients
            "google-genai>=1.0.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "graphora=graphora.cli.main:cli",
        ],
    },
)
