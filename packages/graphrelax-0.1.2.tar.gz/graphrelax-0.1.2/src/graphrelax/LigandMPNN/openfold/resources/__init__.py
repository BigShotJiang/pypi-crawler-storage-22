# flake8: noqa
# Resource files for OpenFold
