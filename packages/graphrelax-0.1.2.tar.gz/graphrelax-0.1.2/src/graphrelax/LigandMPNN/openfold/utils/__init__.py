# flake8: noqa
# This is vendored code from OpenFold - style issues are preserved from upstream
