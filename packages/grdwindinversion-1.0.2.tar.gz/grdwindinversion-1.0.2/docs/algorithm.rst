Algorithm description
=====================

TODO