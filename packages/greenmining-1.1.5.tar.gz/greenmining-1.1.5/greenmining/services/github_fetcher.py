# Legacy GitHub REST API fetcher (deprecated).
# Use github_graphql_fetcher.GitHubGraphQLFetcher instead.
