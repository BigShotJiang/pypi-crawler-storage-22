# Web dashboard module for GreenMining visualization.

from .app import create_app, run_dashboard

__all__ = ["create_app", "run_dashboard"]
