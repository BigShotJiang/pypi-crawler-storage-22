# Version information for greenmining.

__version__ = "1.0.5"
