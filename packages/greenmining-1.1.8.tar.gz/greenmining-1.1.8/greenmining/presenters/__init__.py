# Presenters Package - UI/CLI presentation layer.

from .console_presenter import ConsolePresenter

__all__ = [
    "ConsolePresenter",
]
