# Setup script for backward compatibility with older pip versions.

from setuptools import setup

# All configuration is now in pyproject.toml
# This file is kept for backward compatibility
setup()
