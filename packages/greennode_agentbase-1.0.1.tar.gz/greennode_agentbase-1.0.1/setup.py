"""Setup script for Cython extensions."""

from setuptools import Extension, setup
from setuptools.command.build_ext import build_ext

try:
    from Cython.Build import cythonize
    CYTHON_AVAILABLE = True
except ImportError:
    CYTHON_AVAILABLE = False
    print("Warning: Cython not available. Extensions will not be compiled.")


class BuildExt(build_ext):
    """Custom build extension to handle Cython compilation."""

    def build_extensions(self):
        """Build extensions."""
        if CYTHON_AVAILABLE:
            try:
                super().build_extensions()
            except Exception as e:
                print(f"Warning: Cython compilation failed: {e}")
                print("Falling back to Python implementation")


extensions = []
if CYTHON_AVAILABLE:
    extensions = [
        Extension(
            "greennode_agentbase.core.engine",
            ["src/greennode_agentbase/core/engine.pyx"],
            language="c",
        )
    ]
    extensions = cythonize(extensions, compiler_directives={"language_level": "3"})

setup(
    ext_modules=extensions,
    cmdclass={"build_ext": BuildExt},
)

