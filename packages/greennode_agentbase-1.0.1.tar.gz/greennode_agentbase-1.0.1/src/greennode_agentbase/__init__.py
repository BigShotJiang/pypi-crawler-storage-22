"""GreenNode AgentBase Runtime SDK - A Python SDK for building and deploying AI agents."""

from .exceptions import (
    GreenNodeAgentBaseError,
    GreenNodeConfigurationError,
    GreenNodeRequestError,
    GreenNodeRuntimeError,
    GreenNodeValidationError,
)
from .runtime import GreenNodeAgentBaseApp, GreenNodeAgentBaseContext, PingStatus, RequestContext

# Identity module - import explicitly to avoid circular dependencies
try:
    from .identity import (
        IAMCredentials,
        IdentityClient,
        requires_access_token,
        requires_api_key,
    )
    _identity_available = True
except ImportError:
    _identity_available = False

# Memory module - import explicitly to avoid circular dependencies
try:
    from .memory import (
        MemoryClient,
        MemoryCreateRequest,
        MemoryEntity,
        MemoryRecord,
        MemoryRecordSearchRequest,
        EventCreateRequest,
        EventEntity,
        SessionEntity,
        ChatMessage,
    )
    _memory_available = True
except ImportError:
    _memory_available = False

__all__ = [
    "GreenNodeAgentBaseApp",
    "RequestContext",
    "GreenNodeAgentBaseContext",
    "PingStatus",
    "GreenNodeAgentBaseError",
    "GreenNodeValidationError",
    "GreenNodeRuntimeError",
    "GreenNodeConfigurationError",
    "GreenNodeRequestError",
]

# Add identity exports if available
if _identity_available:
    __all__.extend(
        [
            "IdentityClient",
            "IAMCredentials",
            "requires_access_token",
            "requires_api_key",
        ]
    )

# Add memory exports if available
if _memory_available:
    __all__.extend(
        [
            "MemoryClient",
            "MemoryCreateRequest",
            "MemoryEntity",
            "MemoryRecord",
            "MemoryRecordSearchRequest",
            "EventCreateRequest",
            "EventEntity",
            "SessionEntity",
            "ChatMessage",
        ]
    )
