"""Deploy command for GreenNode AgentBase CLI."""

import asyncio
import logging
import os
import time
from collections import deque
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

import click
from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.prompt import Prompt

from ..core.logging import configure_logger
from ..exceptions import (
    GreenNodeConfigurationError,
    GreenNodeRuntimeError,
)
from ..identity.config import get_config_value
from ..identity.credentials import IAMCredentials
from ..runtime.client import RuntimeClient
from ..runtime.config import (
    ensure_runtime_config_exists,
    get_runtime_config_key,
    get_runtime_config_value,
    get_runtime_env_vars,
    save_runtime_config_key,
    save_runtime_env_vars,
)
from ..runtime.models import (
    AgentRuntimeAutoscaling,
    AgentRuntimeCreateRequest,
    AgentRuntimeImageAuth,
)
from ..runtime.utils import is_docker_running

logger = logging.getLogger("greennode_agentbase.cli.deploy")
configure_logger(logger)


def _format_config_item(name: str, is_present: bool, required: bool = True, is_file: bool = False) -> str:
    """Format a configuration item for display.

    Args:
        name: Configuration item name
        is_present: Whether the configuration is present
        required: Whether the configuration is required
        is_file: Whether this is a file check (not an env var)

    Returns:
        Formatted string with checkmark and color coding using rich markup
    """
    if is_present:
        if required:
            checkmark = "[green]✓[/green]"
        else:
            checkmark = "[dim green]○[/dim green]"
    else:
        if required:
            checkmark = "[red]✗[/red]"
        else:
            checkmark = "[dim]○[/dim]"

    if not required:
        suffix = " [dim](optional)[/dim]"
    else:
        suffix = ""

    return f"{checkmark} {name}{suffix}"


def _check_and_display_deploy_config() -> tuple[bool, dict[str, bool]]:
    """Check and display deployment configuration status.

    Displays a checklist of deployment-specific configuration items using rich visualization.
    Returns whether all required conditions are met and a status dictionary.

    Returns:
        Tuple of (all_required_met: bool, status_dict: dict) where status_dict contains
        the presence status of each configuration item.
    """
    console = Console()

    # Check deployment configurations
    greennode_client_id = get_config_value("GREENNODE_CLIENT_ID")
    greennode_client_secret = get_config_value("GREENNODE_CLIENT_SECRET")
    registry_url = get_config_value("GREENNODE_REGISTRY_URL")
    registry_username = get_config_value("GREENNODE_REGISTRY_USERNAME")
    registry_password = get_config_value("GREENNODE_REGISTRY_PASSWORD")
    requirements_exists = Path("requirements.txt").exists()
    dockerfile_exists = Path("Dockerfile").exists()
    docker_running = is_docker_running()

    # Build deployment configuration panel content
    deploy_lines = []
    deploy_lines.append(_format_config_item("GREENNODE_CLIENT_ID", greennode_client_id is not None, required=True))
    deploy_lines.append(_format_config_item("GREENNODE_CLIENT_SECRET", greennode_client_secret is not None, required=True))
    deploy_lines.append(_format_config_item("GREENNODE_REGISTRY_URL", registry_url is not None, required=True))
    deploy_lines.append(_format_config_item("GREENNODE_REGISTRY_USERNAME", registry_username is not None, required=True))
    deploy_lines.append(_format_config_item("GREENNODE_REGISTRY_PASSWORD", registry_password is not None, required=True))
    deploy_lines.append(_format_config_item("requirements.txt", requirements_exists, required=True, is_file=True))
    deploy_lines.append(_format_config_item("Dockerfile", dockerfile_exists, required=True, is_file=True))
    deploy_lines.append(_format_config_item("Docker", docker_running, required=True))

    deploy_panel = Panel(
        "\n".join(deploy_lines),
        title="Deployment Configuration",
        border_style="yellow",
    )

    # Display deployment configuration panel
    console.print(deploy_panel)

    # Check if all required conditions are met
    all_required_met = (
        greennode_client_id is not None
        and greennode_client_secret is not None
        and registry_url is not None
        and registry_username is not None
        and registry_password is not None
        and requirements_exists
        and dockerfile_exists
        and docker_running
    )

    status_dict = {
        "GREENNODE_CLIENT_ID": greennode_client_id is not None,
        "GREENNODE_CLIENT_SECRET": greennode_client_secret is not None,
        "GREENNODE_REGISTRY_URL": registry_url is not None,
        "GREENNODE_REGISTRY_USERNAME": registry_username is not None,
        "GREENNODE_REGISTRY_PASSWORD": registry_password is not None,
        "requirements.txt": requirements_exists,
        "Dockerfile": dockerfile_exists,
        "Docker": docker_running,
    }

    return all_required_met, status_dict


def _secure_display_value(value: str) -> str:
    """Display a secure value showing only first 10 characters.

    Args:
        value: The value to display securely

    Returns:
        Secure display string with first 10 chars visible, rest as asterisks
    """
    if not value or len(value) <= 10:
        return "*" * len(value) if value else "(empty)"
    return value[:10] + "*" * (len(value) - 10)


def _format_docker_log_chunk(chunk: Dict[str, Any]) -> Optional[str]:
    """Format a Docker API log chunk into a displayable string.

    Args:
        chunk: Docker API log chunk dictionary

    Returns:
        Formatted log line string, or None if chunk should be skipped
    """
    if "stream" in chunk:
        line = chunk["stream"].strip()
        return line if line else None
    elif "status" in chunk:
        status = chunk["status"]
        if "progress" in chunk:
            progress = chunk["progress"]
            return f"{status} {progress}"
        return status
    elif "error" in chunk:
        return f"ERROR: {chunk['error']}"
    elif "errorDetail" in chunk:
        error_detail = chunk["errorDetail"]
        message = error_detail.get("message", "Unknown error")
        return f"ERROR: {message}"
    return None


@click.group(name="deploy")
def deploy_group() -> None:
    """Deploy your AI agent to GreenNode runtime platform.
    
    This command group provides deployment operations for AI agents built with
    GreenNode AgentBase SDK.
    """
    pass


@deploy_group.command(name="run")
@click.option(
    "--image-name",
    "-i",
    type=str,
    default=None,
    help="Custom image name. If not provided, defaults to agentbase-worker-{access_control_name}",
)
@click.option(
    "--output",
    "-o",
    type=click.Choice(["id"]),
    default=None,
    help="Output only the runtime id (for scripting). Use -o id to print just the id.",
)
def deploy_command(image_name: Optional[str], output: Optional[str]) -> None:
    """Deploy your AI agent to GreenNode runtime platform.

    This command builds a Docker image, pushes it to the registry, and creates
    a runtime instance on the GreenNode platform.

    The deployment process includes:
    1. Checking deployment configuration (registry, Docker, files)
    2. Collecting GREENNODE environment variables
    3. Building Docker image
    4. Pushing image to registry
    5. Creating runtime on GreenNode platform

    Examples:
        \n
        # Deploy with default image name\n
        greennode deploy run

        \n
        # Deploy with custom image name\n
        greennode deploy run --image-name my-custom-agent
    """
    console = Console()

    # Check if running in runtime environment
    if get_config_value("GREENNODE_RUNTIME"):
        logger.info("Running in runtime environment, deployment bypassed")
        console.print("[yellow]Running in runtime environment, deployment bypassed[/yellow]")
        return

    logger.info("Starting deployment process...")
    console.print("[bold blue]Starting deployment process...[/bold blue]\n")

    # Display deployment configuration checklist
    all_required_met, status_dict = _check_and_display_deploy_config()

    # Early validation - return if required conditions are not met
    if not all_required_met:
        logger.warning("Deployment aborted: required conditions not met")
        missing_items = [key for key, value in status_dict.items() if not value]
        logger.warning("Missing required items: %s", ", ".join(missing_items))
        console.print(f"\n[red]Deployment aborted: Missing required items: {', '.join(missing_items)}[/red]")
        if "Docker" in missing_items:
            docker_cmd = "docker context inspect --format '{{ .Endpoints.docker.Host }}'"
            console.print(f"\n[red]⚠ Docker daemon is not running or engine mismatch.[/red]")
            console.print(f"[yellow]Check your socket with:[/yellow] [bold cyan]{docker_cmd}[/bold cyan]")
            console.print(f"[yellow]Then set it with:[/yellow] [bold cyan]export DOCKER_HOST=\"result_here\"[/bold cyan]")
        raise click.Abort()

    # Check/create .greennode_runtime.json and collect GREENNODE env vars
    ensure_runtime_config_exists()

    # Validate that sensitive env vars are NOT in config file
    config_env_vars = get_runtime_env_vars()
    sensitive_vars = [
        "GREENNODE_CLIENT_ID",
        "GREENNODE_CLIENT_SECRET",
        "GREENNODE_ACCESS_CONTROL_NAME",
    ]
    found_sensitive_vars = [var for var in sensitive_vars if var in config_env_vars]
    
    if found_sensitive_vars:
        logger.error("Sensitive environment variables found in .greennode_runtime.json: %s", ", ".join(found_sensitive_vars))
        console.print(
            f"\n[red]Error: The following sensitive environment variables are present in .greennode_runtime.json:[/red]\n"
            f"[red]{', '.join(found_sensitive_vars)}[/red]\n"
            f"[yellow]These variables should not be stored in the config file for security reasons.[/yellow]\n"
            f"[yellow]Please remove them from .greennode_runtime.json and use environment variables instead.[/yellow]"
        )
        raise click.Abort()

    # Required GREENNODE environment variables
    required_greennode_vars = [
        "GREENNODE_CLIENT_ID",
        "GREENNODE_CLIENT_SECRET",
        "GREENNODE_ACCESS_CONTROL_NAME",
    ]

    # Collect env vars from environment, config file, or prompt user
    env_vars = {}
    missing_vars = []

    for var_name in required_greennode_vars:
        # Get from env first, then .greennode.json
        value = get_config_value(var_name)
        if not value:
            missing_vars.append(var_name)
        else:
            env_vars[var_name] = value

    # Display current env vars with secure values
    env_lines = []
    for var_name in required_greennode_vars:
        value = env_vars.get(var_name, "")
        secure_value = _secure_display_value(value) if value else "[red](missing)[/red]"
        status = "[green]✓[/green]" if value else "[red]✗[/red]"
        env_lines.append(f"{status} {var_name}: {secure_value}")

    env_panel = Panel(
        "\n".join(env_lines),
        title="[bold blue]GREENNODE Environment Variables[/bold blue]",
        border_style="blue",
    )
    console.print("\n")
    console.print(env_panel)

    # Prompt for missing values
    if missing_vars:
        console.print("\n[yellow]Some required environment variables are missing.[/yellow]")
        for var_name in missing_vars:
            value = Prompt.ask(
                f"Enter {var_name}",
                password=True,
                default="",
            )
            if value:
                env_vars[var_name] = value
                # Also set in environment for immediate use
                os.environ[var_name] = value
            else:
                logger.error(f"{var_name} is required but was not provided")
                console.print(f"[red]Error: {var_name} is required for deployment[/red]")
                raise click.Abort()

    # Save all env vars to runtime config
    # save_runtime_env_vars(env_vars)

    # All validations passed, proceed with deployment
    registry_url = get_config_value("GREENNODE_REGISTRY_URL")
    registry_username = get_config_value("GREENNODE_REGISTRY_USERNAME")
    registry_password = get_config_value("GREENNODE_REGISTRY_PASSWORD")

    # Determine image name
    custom_image = False
    if image_name is None:
        access_control_name = get_config_value("GREENNODE_ACCESS_CONTROL_NAME")
        if not access_control_name:
            logger.error("GREENNODE_ACCESS_CONTROL_NAME environment variable is required when image_name is not provided")
            console.print("[red]Error: GREENNODE_ACCESS_CONTROL_NAME environment variable is required[/red]")
            raise click.Abort()
        image_name = f"agentbase-worker-{access_control_name}"
        # logger.info("Using default image name: %s", image_name)
    else:
        custom_image = True
        # logger.info("Using custom image name: %s", image_name)

    # Generate tag (timestamp-based format: YYYYMMDD-HHMMSS)
    if not custom_image:
        tag = datetime.now().strftime("%Y%m%d-%H%M%S")
        full_image_name = f"{registry_url}/{image_name}:{tag}"
        # logger.info("Generated tag: %s", tag)
    else:
        full_image_name = image_name
    logger.info("Full image name: %s", full_image_name)

    # Create RuntimeClient early (needed for flavor details and later for runtime creation)
    iam_credentials = IAMCredentials(
        access_key_id=env_vars.get("GREENNODE_CLIENT_ID"),
        secret_access_key=env_vars.get("GREENNODE_CLIENT_SECRET"),
    )
    runtime_client = RuntimeClient(iam_credentials=iam_credentials)

    # Get or prompt for flavorId
    flavor_id = get_runtime_config_key("flavorId")
    if not flavor_id:
        # Fetch available flavors and prompt user to select
        try:
            # Use asyncio.run to call async method from sync context
            flavors_response = asyncio.run(runtime_client.listAll_async())
            # Handle array response
            if isinstance(flavors_response, list):
                flavors = flavors_response
            elif hasattr(flavors_response, "list_data"):
                flavors = flavors_response.list_data or []
            else:
                flavors = []

            if not flavors:
                console.print("[yellow]Warning: No flavors available. You'll need to provide a flavorId.[/yellow]")
                flavor_id = Prompt.ask("Enter flavorId", default="")
                if not flavor_id:
                    console.print("[red]Error: flavorId is required for deployment[/red]")
                    raise click.Abort()
            else:
                # Display flavors
                flavor_lines = []
                for i, flavor in enumerate(flavors, 1):
                    flavor_name = flavor.get("name") if isinstance(flavor, dict) else getattr(flavor, "name", "Unknown")
                    flavor_cpu = flavor.get("cpu") if isinstance(flavor, dict) else getattr(flavor, "cpu", "N/A")
                    flavor_ram = flavor.get("ram") if isinstance(flavor, dict) else getattr(flavor, "ram", "N/A")
                    flavor_lines.append(f"  {i}. {flavor_name} (CPU: {flavor_cpu}, RAM: {flavor_ram}MB)")

                flavor_panel = Panel(
                    "\n".join(flavor_lines),
                    title="[bold blue]Available Flavors[/bold blue]",
                    border_style="blue",
                )
                console.print("\n")
                console.print(flavor_panel)

                # Prompt user to select
                selected = Prompt.ask(
                    f"\nSelect flavor (1-{len(flavors)})",
                    default="1",
                )
                try:
                    selected_idx = int(selected) - 1
                    if 0 <= selected_idx < len(flavors):
                        selected_flavor = flavors[selected_idx]
                        flavor_id = selected_flavor.get("id") if isinstance(selected_flavor, dict) else getattr(selected_flavor, "id", None)
                        if flavor_id:
                            save_runtime_config_key("flavorId", flavor_id)
                    else:
                        console.print("[red]Error: Invalid selection[/red]")
                        raise click.Abort()
                except (ValueError, IndexError):
                    console.print("[red]Error: Invalid selection[/red]")
                    raise click.Abort()
        except Exception as flavor_error:
            logger.warning("Failed to fetch flavors: %s", flavor_error)
            console.print(f"[yellow]Warning: Failed to fetch flavors: {flavor_error}[/yellow]")
            flavor_id = Prompt.ask("Enter flavorId", default="")
            if not flavor_id:
                console.print("[red]Error: flavorId is required for deployment[/red]")
                raise click.Abort()

    # Get all env vars from config file (includes all saved vars, not just required ones)
    all_env_vars = get_runtime_env_vars()

    # Display summary with secure values and get confirmation
    summary_lines = []

    # Add image name
    summary_lines.append(f"  Image Name: {full_image_name}")

    # Add flavor details if available
    if flavor_id:
        # Fetch flavor details to show name, CPU, RAM
        try:
            flavors_response = asyncio.run(runtime_client.listAll_async())
            flavors = flavors_response if isinstance(flavors_response, list) else (flavors_response.list_data if hasattr(flavors_response, "list_data") else [])
            selected_flavor = next((f for f in flavors if (f.get("id") if isinstance(f, dict) else getattr(f, "id", None)) == flavor_id), None)
            if selected_flavor:
                flavor_name = selected_flavor.get("name") if isinstance(selected_flavor, dict) else getattr(selected_flavor, "name", "Unknown")
                flavor_cpu = selected_flavor.get("cpu") if isinstance(selected_flavor, dict) else getattr(selected_flavor, "cpu", "N/A")
                flavor_ram = selected_flavor.get("ram") if isinstance(selected_flavor, dict) else getattr(selected_flavor, "ram", "N/A")
                summary_lines.append(f"  Flavor: {flavor_name} (CPU: {flavor_cpu}, RAM: {flavor_ram}MB)")
            else:
                summary_lines.append(f"  Flavor ID: {flavor_id}")
        except Exception:
            summary_lines.append(f"  Flavor ID: {flavor_id}")

    # Add all environment variables
    summary_lines.append("")  # Empty line separator
    summary_lines.append("  Environment Variables:")
    for var_name, value in sorted(all_env_vars.items()):
        secure_value = _secure_display_value(value) if value else "[red](empty)[/red]"
        summary_lines.append(f"    {var_name}: {secure_value}")

    summary_panel = Panel(
        "\n".join(summary_lines),
        title="[bold green]Runtime Configuration Summary[/bold green]",
        border_style="green",
    )
    console.print("\n")
    console.print(summary_panel)

    # Get user confirmation
    confirm = Prompt.ask("\nProceed with deployment?", default="Y", choices=["Y", "n", "N"])
    if confirm.upper() != "Y":
        logger.info("Deployment cancelled by user")
        console.print("[yellow]Deployment cancelled[/yellow]")
        return

    # Build and push Docker image (only if not using custom image)
    if not custom_image:
        # Import docker SDK and create client for build/push operations
        try:
            import docker
        except ImportError:
            logger.error("Docker Python SDK (docker package) is not installed")
            console.print("[red]Error: Docker Python SDK (docker package) is not installed[/red]")
            console.print("[yellow]Please install it with: pip install docker>=6.0.0[/yellow]")
            raise click.Abort()

        try:
            docker_client = docker.from_env()
        except Exception as e:
            logger.error("Failed to connect to Docker daemon: %s", e)
            console.print(f"[red]Error: Failed to connect to Docker daemon: {e}[/red]")
            raise click.Abort()

        # Build Docker image
        logger.info("Building Docker image...")
        console.print("\n[bold blue]Building Docker image...[/bold blue]")
        try:
            # Verify Dockerfile exists in current directory
            dockerfile_path = Path("Dockerfile")
            if not dockerfile_path.exists():
                raise GreenNodeConfigurationError(
                    "Dockerfile not found in current directory. "
                    "Please create a Dockerfile before deploying."
                )

            # Build image using API client for streaming (build from current directory)
            # logger.info("Building image with platform linux/amd64...")

            # Create rolling buffer for log lines
            log_buffer = deque(maxlen=30)

            # Use API client for streaming build logs (build from current directory)
            api_client = docker_client.api
            build_generator = api_client.build(
                path=".",
                tag=full_image_name,
                platform="linux/amd64",
                rm=True,
                decode=True,
            )

            console_instance = Console()
            # Create initial panel
            panel = Panel("", title="[bold blue]Building Docker Image...[/bold blue]", border_style="blue")

            try:
                with Live(panel, console=console_instance, refresh_per_second=10) as live:
                    try:
                        for chunk in build_generator:
                            log_line = _format_docker_log_chunk(chunk)
                            if log_line:
                                log_buffer.append(log_line)
                                # Update panel with current log buffer
                                panel_content = "\n".join(log_buffer) if log_buffer else "Starting build..."
                                live.update(
                                    Panel(
                                        panel_content,
                                        title="[bold blue]Building Docker Image...[/bold blue]",
                                        border_style="blue",
                                    )
                                )

                            # Check for errors in chunk
                            if "error" in chunk or "errorDetail" in chunk:
                                error_msg = chunk.get("error") or chunk.get("errorDetail", {}).get("message", "Unknown error")
                                log_buffer.append(f"ERROR: {error_msg}")
                                live.update(
                                    Panel(
                                        "\n".join(log_buffer),
                                        title="[bold red]Build Error[/bold red]",
                                        border_style="red",
                                    )
                                )
                    except Exception as stream_error:
                        # Display error in box before closing
                        error_msg = str(stream_error)
                        log_buffer.append(f"ERROR: {error_msg}")
                        live.update(
                            Panel(
                                "\n".join(log_buffer),
                                title="[bold red]Build Error[/bold red]",
                                border_style="red",
                            )
                        )
                        # Small delay to ensure error is visible
                        time.sleep(0.5)
                        raise
            finally:
                # Live context manager will close automatically
                pass

            # Verify image was built by getting it
            try:
                image = docker_client.images.get(full_image_name)
                logger.info("Docker image built successfully: %s", full_image_name)
                console.print(f"[green]✓ Docker image built successfully[/green]")
            except Exception as img_error:
                raise GreenNodeRuntimeError(
                    "Build completed but image not found",
                    details={"image_name": full_image_name},
                    cause=img_error,
                ) from img_error

        except Exception as e:
            logger.error("Failed to build Docker image: %s", e)
            console.print(f"[red]Error: Failed to build Docker image: {e}[/red]")
            raise click.Abort()

        # Push image to registry
        logger.info("Pushing image to registry...")
        console.print("\n[bold yellow]Pushing image to registry...[/bold yellow]")

        try:
            # Use API client for streaming push logs
            api_client = docker_client.api
            push_generator = api_client.push(
                full_image_name,
                auth_config={"username": registry_username, "password": registry_password},
                stream=True,
                decode=True,
            )

            # Create rolling buffer for log lines
            log_buffer = deque(maxlen=30)

            console_instance = Console()
            # Create initial panel
            panel = Panel("", title="[bold yellow]Pushing to Registry...[/bold yellow]", border_style="yellow")

            try:
                with Live(panel, console=console_instance, refresh_per_second=10) as live:
                    try:
                        for chunk in push_generator:
                            log_line = _format_docker_log_chunk(chunk)
                            if log_line:
                                log_buffer.append(log_line)
                                # Update panel with current log buffer
                                panel_content = "\n".join(log_buffer) if log_buffer else "Starting push..."
                                live.update(
                                    Panel(
                                        panel_content,
                                        title="[bold yellow]Pushing to Registry...[/bold yellow]",
                                        border_style="yellow",
                                    )
                                )

                            # Check for errors in chunk
                            if "error" in chunk or "errorDetail" in chunk:
                                error_msg = chunk.get("error") or chunk.get("errorDetail", {}).get("message", "Unknown error")
                                log_buffer.append(f"ERROR: {error_msg}")
                                live.update(
                                    Panel(
                                        "\n".join(log_buffer),
                                        title="[bold red]Push Error[/bold red]",
                                        border_style="red",
                                    )
                                )
                    except Exception as stream_error:
                        # Display error in box before closing
                        error_msg = str(stream_error)
                        log_buffer.append(f"ERROR: {error_msg}")
                        live.update(
                            Panel(
                                "\n".join(log_buffer),
                                title="[bold red]Push Error[/bold red]",
                                border_style="red",
                            )
                        )
                        # Small delay to ensure error is visible
                        time.sleep(0.5)
                        raise
            finally:
                # Live context manager will close automatically
                pass

            logger.info("Image pushed successfully to registry: %s", full_image_name)
            console.print(f"[green]✓ Image pushed successfully to registry[/green]")

        except Exception as e:
            logger.error("Failed to push Docker image: %s", e)
            console.print(f"[red]Error: Failed to push Docker image: {e}[/red]")
            raise click.Abort()
    else:
        # Custom image provided, skip build and push
        logger.info("Skipping build and push for custom image: %s", full_image_name)
        console.print(f"\n[yellow]Using existing custom image: {full_image_name}[/yellow]")
        console.print("[dim]Skipping build and push steps...[/dim]")

    # Create runtime using Runtime API (always runs)
    runtime_client = RuntimeClient(iam_credentials=iam_credentials)
    try:
        console.print("\n[bold blue]Creating runtime...[/bold blue]")

        # Get all env vars from config (includes all saved vars)
        all_env_vars_for_request = get_runtime_env_vars()

        # Get command and args from config, default to empty arrays
        command = get_runtime_config_key("command", [])
        if not isinstance(command, list):
            command = []
        args = get_runtime_config_key("args", [])
        if not isinstance(args, list):
            args = []
        # Build runtime create request
        access_control_name = env_vars.get("GREENNODE_ACCESS_CONTROL_NAME")
        runtime_name = access_control_name or image_name

        # Build imageAuth if credentials provided
        image_auth = None
        if registry_username and registry_password:
            image_auth = AgentRuntimeImageAuth(
                enabled=True,
                username=registry_username,
                password=registry_password,
            )

        # Create autoscaling with defaults
        autoscaling = AgentRuntimeAutoscaling()

        runtime_request = AgentRuntimeCreateRequest(
            name=runtime_name,
            description="",
            image_url=full_image_name,
            image_auth=image_auth,
            command=command,
            args=args,
            environment_variables=all_env_vars_for_request,
            flavor_id=flavor_id,
            autoscaling=autoscaling,
        )
        # Create runtime (using async method with asyncio.run)
        runtime_response = asyncio.run(runtime_client.create_async(request=runtime_request))

        # Handle response (could be dict or model)
        if hasattr(runtime_response, "id"):
            runtime_id = runtime_response.id
            runtime_name_resp = runtime_response.name
        else:
            runtime_id = runtime_response.get("id", "N/A") if isinstance(runtime_response, dict) else "N/A"
            runtime_name_resp = runtime_response.get("name", "N/A") if isinstance(runtime_response, dict) else "N/A"

        logger.info("Runtime created successfully: %s", runtime_id)
        if output == "id":
            console.print(runtime_id)
        else:
            # Display success message
            success_panel = Panel(
                f"[green]Runtime created successfully![/green]\n\n"
                f"Runtime ID: {runtime_id}\n"
                f"Runtime Name: {runtime_name_resp}\n"
                f"Image: {full_image_name}",
                title="[bold green]Runtime Deployment Complete[/bold green]",
                border_style="green",
            )
            console.print("\n")
            console.print(success_panel)
            console.print(f"[green]✓ Runtime created successfully with id: {runtime_id}[/green]")

    except Exception as runtime_error:
        # Log error and fail the deployment
        logger.error("Failed to create runtime: %s", runtime_error)
        console.print(f"\n[red]Error: Failed to create runtime: {runtime_error}[/red]")
        if not custom_image:
            console.print("[yellow]Image was built and pushed successfully, but runtime creation failed.[/yellow]")
        else:
            console.print("[yellow]Runtime creation failed.[/yellow]")
        console.print("[yellow]You can create the runtime manually using the Runtime API.[/yellow]")
        raise click.Abort()
