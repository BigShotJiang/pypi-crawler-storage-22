"""Main CLI entry point for GreenNode AgentBase."""

import sys
import click
from rich.console import Console

from .deploy import deploy_group
from .memory import memory_group
from .runtime import runtime_group

# Version will be read from package metadata at runtime
try:
    try:
        from importlib.metadata import version
    except ImportError:
        # Python < 3.8
        from importlib_metadata import version  # type: ignore

    __version__ = version("greennode-agentbase")
except Exception:
    # Fallback if package metadata is not available
    __version__ = "0.1.0"


# ASCII art for greennode
GREENNODE_ASCII_ART = r"""
   _____ _____  ______ ______ _   _ _   _  ____  _____  ______ 
  / ____|  __ \|  ____|  ____| \ | | \ | |/ __ \|  __ \|  ____|
 | |  __| |__) | |__  | |__  |  \| |  \| | |  | | |  | | |__   
 | | |_ |  _  /|  __| |  __| | . ` | . ` | |  | | |  | |  __|  
 | |__| | | \ \| |____| |____| |\  | |\  | |__| | |__| | |____ 
  \_____|_|  \_\______|______|_| \_|_| \_|\____/|_____/|______| AGENTBASE
"""


def print_banner() -> None:
    """Print the GreenNode ASCII art banner."""
    console = Console()
    console.print(GREENNODE_ASCII_ART, style="bold green")


@click.group(invoke_without_command=True)
@click.version_option(version=__version__, prog_name="greennode")
@click.pass_context
def main(ctx: click.Context) -> None:
    """GreenNode AgentBase CLI - Deploy and manage AI agents.
    
    This CLI tool provides commands for deploying AI agents built with
    GreenNode AgentBase SDK to the GreenNode runtime platform and managing
    memory operations.
    
    Examples:
        \n
        # Deploy with default image name\n
        greennode deploy
        
        \n
        # List memories\n
        greennode memory list --user-id 12345
        
        \n
        # Show help for a command\n
        greennode memory --help
    """
    # Check if help or version was requested
    should_skip_banner = any(
        arg in sys.argv for arg in ["--help", "-h", "--version", "-V", "-v"]
    )
    
    # Print banner on every command invocation (except help/version)
    if not should_skip_banner:
        print_banner()

    if ctx.invoked_subcommand is None and not should_skip_banner:
        click.echo(ctx.get_help())
        ctx.exit()
    
    ctx.ensure_object(dict)


# Register command groups
main.add_command(memory_group, name="memory")
main.add_command(deploy_group, name="deploy")
main.add_command(runtime_group, name="runtime")
