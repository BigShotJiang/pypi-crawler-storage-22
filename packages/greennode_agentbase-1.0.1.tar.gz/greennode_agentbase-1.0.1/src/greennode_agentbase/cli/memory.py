"""Memory commands for GreenNode AgentBase CLI."""

import asyncio
import json
import logging
from typing import List, Optional

import click
from rich.console import Console
from rich.table import Table

from ..core.logging import configure_logger
from ..exceptions import GreenNodeConfigurationError, GreenNodeRequestError
from ..identity.credentials import IAMCredentials
from ..memory.client import MemoryClient
from ..memory.models import (
    ChatMessage,
    EventCreateRequest,
    MemoryCreateRequest,
    MemoryRecordSearchRequest,
)

logger = logging.getLogger("greennode_agentbase.cli.memory")
configure_logger(logger)

console = Console()


@click.group(name="memory")
def memory_group() -> None:
    """Manage memories and memory operations.
    
    This command group provides operations for managing memories, memory records,
    sessions, and events in the GreenNode AgentBase platform.
    """
    pass


def get_memory_client() -> MemoryClient:
    """Get a configured MemoryClient instance.
    
    Returns:
        MemoryClient instance with IAM credentials
    """
    try:
        iam_credentials = IAMCredentials()
        return MemoryClient(iam_credentials=iam_credentials)
    except Exception as e:
        console.print(f"[red]Error: Failed to initialize memory client: {e}[/red]")
        raise click.Abort()


# Memory CRUD operations
@memory_group.command(name="create")
@click.option("--name", "-n", required=True, help="Memory name")
@click.option("--description", "-d", required=True, help="Memory description")
@click.option("--event-expiry-duration", type=int, help="Event expiry duration in seconds")
@click.option("--auto-generation-enabled", is_flag=True, help="Enable automatic memory record generation")
@click.option("--namespace-template", help="Namespace template for automatic generation")
def create_memory(
    name: str,
    description: str,
    event_expiry_duration: Optional[int],
    auto_generation_enabled: bool,
    namespace_template: Optional[str],
) -> None:
    """Create a new memory.
    
    Examples:
        \n
        # Create a simple memory\n
        greennode memory create -n "My Memory" -d "Description"
        
        \n
        # Create with auto-generation\n
        greennode memory create -n "My Memory" -d "Description" \\
            --auto-generation-enabled --namespace-template "default"
    """
    try:
        client = get_memory_client()
        
        # Build request
        request_data = {
            "name": name,
            "description": description,
        }
        
        if event_expiry_duration is not None:
            request_data["eventExpiryDuration"] = event_expiry_duration
        
        auto_gen = {}
        if auto_generation_enabled or namespace_template:
            if auto_generation_enabled:
                auto_gen["enabled"] = True
            else:
                auto_gen["enabled"] = False

            if namespace_template:
                auto_gen["namespaceTemplate"] = namespace_template
        
        request_data["automaticMemoryRecordGeneration"] = auto_gen
        
        request = MemoryCreateRequest(**request_data)
        
        # Create memory
        result = asyncio.run(
            client.create_async(request=request)
        )
        
        console.print(f"[green]✓ Memory created successfully with id: {result.id}[/green]")
        # console.print(json.dumps(result.model_dump(by_alias=True), indent=2, default=str))
        
    except Exception as e:
        console.print(f"[red]Error: Failed to create memory: {e}[/red]")
        raise click.Abort()


@memory_group.command(name="list")
@click.option("--page", "-p", type=int, default=1, help="Page number (default: 1)")
@click.option("--size", "-s", type=int, default=10, help="Page size (default: 10)")
def list_memories(page: int, size: int) -> None:
    """List all memories.
    
    Examples:
        \n
        # List first page\n
        greennode memory list
        
        \n
        # List with custom pagination\n
        greennode memory list --page 2 --size 20
    """
    try:
        client = get_memory_client()
        
        result = asyncio.run(
            client.list_async(page=page, size=size)
        )
        
        # Display results in a table
        table = Table(title="Memories")
        table.add_column("ID", style="cyan")
        table.add_column("Name", style="magenta")
        table.add_column("Description", style="green")
        table.add_column("Status", style="yellow")
        table.add_column("Created At", style="blue")
        
        if result.list_data:
            for memory in result.list_data:
                table.add_row(
                    memory.id or "",
                    memory.name or "",
                    (memory.description or "")[:50],
                    memory.status or "",
                    str(memory.created_at) if memory.created_at else "",
                )
        
        console.print(table)
        console.print(f"\n[dim]Page {result.page} of {result.total_page} (Total: {result.total_item})[/dim]")
        
    except Exception as e:
        console.print(f"[red]Error: Failed to list memories: {e}[/red]")
        raise click.Abort()


@memory_group.command(name="get")
@click.argument("memory-id", required=True)
def get_memory(memory_id: str) -> None:
    """Get a memory by ID.
    
    Examples:
        \n
        # Get memory\n
        greennode memory get memory-123
    """
    try:
        client = get_memory_client()
        
        result = asyncio.run(client.get_async(id=memory_id))
        
        console.print("[green]✓ Memory retrieved[/green]")
        console.print(json.dumps(result.model_dump(by_alias=True), indent=2, default=str))
        
    except Exception as e:
        console.print(f"[red]Error: Failed to get memory: {e}[/red]")
        raise click.Abort()


@memory_group.command(name="delete")
@click.argument("memory-id", required=True)
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation")
def delete_memory(memory_id: str, yes: bool) -> None:
    """Delete a memory by ID.
    
    Examples:
        \n
        # Delete memory (with confirmation)\n
        greennode memory delete memory-123
        
        \n
        # Delete without confirmation\n
        greennode memory delete memory-123 --yes
    """
    try:
        if not yes:
            if not click.confirm(f"Are you sure you want to delete memory '{memory_id}'?"):
                console.print("[yellow]Deletion cancelled[/yellow]")
                return
        
        client = get_memory_client()
        
        asyncio.run(client.delete_async(id=memory_id))
        
        console.print(f"[green]✓ Memory '{memory_id}' deleted successfully[/green]")
        
    except Exception as e:
        console.print(f"[red]Error: Failed to delete memory: {e}[/red]")
        raise click.Abort()


# Memory Records operations
@memory_group.group(name="records")
def records_group() -> None:
    """Manage memory records."""
    pass


@records_group.command(name="list")
@click.argument("memory-id", required=True)
@click.option("--namespace", "-n", required=True, help="Namespace")
def list_memory_records(memory_id: str, namespace: str) -> None:
    """List memory records for a memory.
    
    Examples:
        \n
        # List records\n
        greennode memory records list memory-123 -n default
    """
    try:
        client = get_memory_client()
        
        result = asyncio.run(
            client.listMemoryRecords_async(
                id=memory_id, namespace=namespace
            )
        )
        
        # Display results
        if isinstance(result, list):
            table = Table(title=f"Memory Records (namespace: {namespace})")
            table.add_column("ID", style="cyan")
            table.add_column("Memory", style="magenta")
            table.add_column("Score", style="green")
            table.add_column("Created At", style="blue")
            
            for record in result:
                table.add_row(
                    record.id or "",
                    (record.memory or "")[:50],
                    str(record.score) if record.score is not None else "",
                    str(record.created_at) if record.created_at else "",
                )
            
            console.print(table)
            console.print(f"\n[dim]Total: {len(result)} records[/dim]")
        else:
            console.print(json.dumps(result, indent=2, default=str))
        
    except Exception as e:
        console.print(f"[red]Error: Failed to list memory records: {e}[/red]")
        raise click.Abort()


@records_group.command(name="search")
@click.argument("memory-id", required=True)
@click.option("--namespace", "-n", required=True, help="Namespace")
@click.option("--query", "-q", required=True, help="Search query")
def search_memory_records(memory_id: str, namespace: str, query: str) -> None:
    """Search memory records.
    
    Examples:
        \n
        # Search records\n
        greennode memory records search memory-123 -n default -q "python"
    """
    try:
        client = get_memory_client()
        
        request = MemoryRecordSearchRequest(query=query)
        
        result = asyncio.run(
            client.searchMemoryRecords_async(
                id=memory_id,
                namespace=namespace,
                request=request,
            )
        )
        
        # Display results
        if isinstance(result, list):
            table = Table(title=f"Search Results (query: {query})")
            table.add_column("ID", style="cyan")
            table.add_column("Memory", style="magenta")
            table.add_column("Score", style="green")
            
            for record in result:
                table.add_row(
                    record.id or "",
                    (record.memory or "")[:50],
                    str(record.score) if record.score is not None else "",
                )
            
            console.print(table)
            console.print(f"\n[dim]Found: {len(result)} records[/dim]")
        else:
            console.print(json.dumps(result, indent=2, default=str))
        
    except Exception as e:
        console.print(f"[red]Error: Failed to search memory records: {e}[/red]")
        raise click.Abort()


@records_group.command(name="insert")
@click.argument("memory-id", required=True)
@click.option("--namespace", "-n", required=True, help="Namespace")
@click.option("--content", "-c", multiple=True, help="Content to insert (can be used multiple times)")
@click.option("--file", "-f", type=click.File("r"), help="File containing content (one per line)")
def insert_memory_records(
    memory_id: str, namespace: str, content: tuple, file: Optional[click.File]
) -> None:
    """Insert memory records directly.
    
    Examples:
        \n
        # Insert from command line\n
        greennode memory records insert memory-123 -n default -c "Content 1" -c "Content 2"
        
        \n
        # Insert from file\n
        greennode memory records insert memory-123 -n default -f content.txt
    """
    try:
        if not content and not file:
            console.print("[red]Error: Must provide either --content or --file[/red]")
            raise click.Abort()
        
        # Collect content
        records = list(content) if content else []
        
        if file:
            records.extend([line.strip() for line in file if line.strip()])
        
        if not records:
            console.print("[red]Error: No content to insert[/red]")
            raise click.Abort()
        
        client = get_memory_client()
        
        asyncio.run(
            client.insertMemoryRecordsDirectly_async(
                id=memory_id, namespace=namespace, request=records
            )
        )
        
        console.print(f"[green]✓ Inserted {len(records)} memory record(s)[/green]")
        
    except Exception as e:
        console.print(f"[red]Error: Failed to insert memory records: {e}[/red]")
        raise click.Abort()


@records_group.command(name="delete")
@click.argument("memory-id", required=True)
@click.argument("record-id", required=True)
def delete_memory_record(memory_id: str, record_id: str) -> None:
    """Delete a memory record.
    
    Examples:
        \n
        # Delete record\n
        greennode memory records delete memory-123 record-456
    """
    try:
        client = get_memory_client()
        
        asyncio.run(
            client.deleteMemoryRecord_async(
                id=memory_id, memoryRecordId=record_id
            )
        )
        
        console.print(f"[green]✓ Memory record '{record_id}' deleted successfully[/green]")
        
    except Exception as e:
        console.print(f"[red]Error: Failed to delete memory record: {e}[/red]")
        raise click.Abort()


@records_group.command(name="generate")
@click.argument("memory-id", required=True)
@click.option("--namespace", "-n", required=True, help="Namespace")
@click.option(
    "--from-session",
    is_flag=True,
    help="Generate from session (requires --actor-id and --session-id)",
)
@click.option("--actor-id", help="Actor ID (required for --from-session)")
@click.option("--session-id", help="Session ID (required for --from-session)")
@click.option("--content", "-c", multiple=True, help="Content messages (for --from-content)")
@click.option("--file", "-f", type=click.File("r"), help="File containing JSON messages")
def generate_memory_records(
    memory_id: str,
    namespace: str,
    from_session: bool,
    actor_id: Optional[str],
    session_id: Optional[str],
    content: tuple,
    file: Optional[click.File],
) -> None:
    """Generate memory records from session or content.
    
    Examples:
        \n
        # Generate from session\n
        greennode memory records generate memory-123 -n default \\
            --from-session --actor-id actor-1 --session-id session-1
        
        \n
        # Generate from content\n
        greennode memory records generate memory-123 -n default \\
            --content '{"role":"user","content":"Hello"}' \\
            --content '{"role":"assistant","content":"Hi there"}'
    """
    try:
        client = get_memory_client()
        
        if from_session:
            if not actor_id or not session_id:
                console.print("[red]Error: --actor-id and --session-id are required for --from-session[/red]")
                raise click.Abort()
            
            asyncio.run(
                client.generateMemoryRecordsFromSession_async(
                    id=memory_id,
                    namespace=namespace,
                    actorId=actor_id,
                    sessionId=session_id,
                )
            )
            
            console.print("[green]✓ Memory records generated from session[/green]")
        else:
            # Generate from content
            messages = []
            
            # Parse content from command line
            for c in content:
                try:
                    msg = json.loads(c)
                    messages.append(ChatMessage(**msg))
                except Exception as e:
                    console.print(f"[red]Error: Invalid JSON in content: {e}[/red]")
                    raise click.Abort()
            
            # Parse content from file
            if file:
                try:
                    file_data = json.load(file)
                    if isinstance(file_data, list):
                        messages.extend([ChatMessage(**msg) for msg in file_data])
                    else:
                        messages.append(ChatMessage(**file_data))
                except Exception as e:
                    console.print(f"[red]Error: Invalid JSON in file: {e}[/red]")
                    raise click.Abort()
            
            if not messages:
                console.print("[red]Error: No content provided[/red]")
                raise click.Abort()
            
            asyncio.run(
                client.generateMemoryRecordsFromContent_async(
                    id=memory_id, namespace=namespace, request=messages
                )
            )
            
            console.print(f"[green]✓ Generated memory records from {len(messages)} message(s)[/green]")
        
    except Exception as e:
        console.print(f"[red]Error: Failed to generate memory records: {e}[/red]")
        raise click.Abort()


# Sessions operations
@memory_group.group(name="sessions")
def sessions_group() -> None:
    """Manage sessions."""
    pass


@sessions_group.command(name="list")
@click.argument("memory-id", required=True)
@click.argument("actor-id", required=True)
def list_sessions(memory_id: str, actor_id: str) -> None:
    """List sessions for an actor.
    
    Examples:
        \n
        # List sessions\n
        greennode memory sessions list memory-123 actor-1
    """
    try:
        client = get_memory_client()
        
        result = asyncio.run(
            client.listSessions_async(
                id=memory_id, actorId=actor_id
            )
        )
        
        # Display results
        if isinstance(result, list):
            table = Table(title=f"Sessions (actor: {actor_id})")
            table.add_column("Session ID", style="cyan")
            table.add_column("Status", style="yellow")
            table.add_column("Last Processed", style="blue")
            
            for session in result:
                table.add_row(
                    session.session_id or "",
                    session.status or "",
                    str(session.last_processed_event_timestamp)
                    if session.last_processed_event_timestamp
                    else "",
                )
            
            console.print(table)
            console.print(f"\n[dim]Total: {len(result)} sessions[/dim]")
        else:
            console.print(json.dumps(result, indent=2, default=str))
        
    except Exception as e:
        console.print(f"[red]Error: Failed to list sessions: {e}[/red]")
        raise click.Abort()


# Events operations
@memory_group.group(name="events")
def events_group() -> None:
    """Manage events."""
    pass


@events_group.command(name="list")
@click.argument("memory-id", required=True)
@click.argument("actor-id", required=True)
@click.argument("session-id", required=True)
def list_events(memory_id: str, actor_id: str, session_id: str) -> None:
    """List events for a session.
    
    Examples:
        \n
        # List events\n
        greennode memory events list memory-123 actor-1 session-1
    """
    try:
        client = get_memory_client()
        
        result = asyncio.run(
            client.listEvents_async(
                id=memory_id,
                actorId=actor_id,
                sessionId=session_id,
            )
        )
        
        # Display results
        if isinstance(result, list):
            table = Table(title=f"Events (session: {session_id})")
            table.add_column("ID", style="cyan")
            table.add_column("Role", style="magenta")
            table.add_column("Content", style="green")
            table.add_column("Timestamp", style="blue")
            
            for event in result:
                table.add_row(
                    event.id or "",
                    event.role or "",
                    (event.content or "")[:50],
                    str(event.event_timestamp) if event.event_timestamp else "",
                )
            
            console.print(table)
            console.print(f"\n[dim]Total: {len(result)} events[/dim]")
        else:
            console.print(json.dumps(result, indent=2, default=str))
        
    except Exception as e:
        console.print(f"[red]Error: Failed to list events: {e}[/red]")
        raise click.Abort()


@events_group.command(name="create")
@click.argument("memory-id", required=True)
@click.argument("actor-id", required=True)
@click.argument("session-id", required=True)
@click.option("--role", "-r", required=True, help="Event role (e.g., user, assistant)")
@click.option("--content", "-c", required=True, help="Event content")
@click.option("--timestamp", "-t", required=True, help="Event timestamp (ISO format)")
def create_event(
    memory_id: str,
    actor_id: str,
    session_id: str,
    role: str,
    content: str,
    timestamp: str,
) -> None:
    """Create an event.
    
    Examples:
        \n
        # Create event\n
        greennode memory events create memory-123 actor-1 session-1 \\
            -r user -c "Hello" -t "2024-01-01T00:00:00Z"
    """
    try:
        client = get_memory_client()
        
        request = EventCreateRequest(
            payload=ChatMessage(role=role, content=content),
            eventTimestamp=timestamp,
        )
        
        asyncio.run(
            client.createEvent_async(
                id=memory_id,
                actorId=actor_id,
                sessionId=session_id,
                request=request,
            )
        )
        
        console.print("[green]✓ Event created successfully[/green]")
        
    except Exception as e:
        console.print(f"[red]Error: Failed to create event: {e}[/red]")
        raise click.Abort()


@events_group.command(name="delete")
@click.argument("memory-id", required=True)
@click.argument("actor-id", required=True)
@click.argument("session-id", required=True)
@click.argument("event-id", required=True)
def delete_event(
    memory_id: str, actor_id: str, session_id: str, event_id: str
) -> None:
    """Delete an event.
    
    Examples:
        \n
        # Delete event\n
        greennode memory events delete memory-123 actor-1 session-1 event-456
    """
    try:
        client = get_memory_client()
        
        asyncio.run(
            client.deleteEvent_async(
                id=memory_id,
                actorId=actor_id,
                sessionId=session_id,
                eventId=event_id,
            )
        )
        
        console.print(f"[green]✓ Event '{event_id}' deleted successfully[/green]")
        
    except Exception as e:
        console.print(f"[red]Error: Failed to delete event: {e}[/red]")
        raise click.Abort()
