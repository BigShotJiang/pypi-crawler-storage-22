"""Runtime commands for GreenNode AgentBase CLI."""

import asyncio
import json
import logging
from typing import Any, Dict, List, Optional

import click
from rich.console import Console
from rich.table import Table

from ..core.logging import configure_logger
from ..identity.credentials import IAMCredentials
from ..runtime.client import RuntimeClient
from ..runtime.models import (
    AgentRuntimeEndpointCreateRequest,
    AgentRuntimeUpdateRequest,
)

logger = logging.getLogger("greennode_agentbase.cli.runtime")
configure_logger(logger)

console = Console()


@click.group(name="runtime")
def runtime_group() -> None:
    """Manage runtimes and runtime endpoints.

    This command group provides operations for listing, getting, patching
    agent runtimes and managing their endpoints.
    """
    pass


def get_runtime_client() -> RuntimeClient:
    """Get a configured RuntimeClient instance.

    Returns:
        RuntimeClient instance with IAM credentials
    """
    try:
        iam_credentials = IAMCredentials()
        return RuntimeClient(iam_credentials=iam_credentials)
    except Exception as e:
        console.print(f"[red]Error: Failed to initialize runtime client: {e}[/red]")
        raise click.Abort()


@runtime_group.command(name="list")
@click.option("--page", "-p", type=int, default=1, help="Page number (default: 1)")
@click.option("--size", "-s", type=int, default=10, help="Page size (default: 10)")
def list_runtimes(page: int, size: int) -> None:
    """List agent runtimes.

    Examples:
        \n
        # List first page\n
        greennode runtime list

        \n
        # List with custom pagination\n
        greennode runtime list --page 2 --size 20
    """
    try:
        client = get_runtime_client()
        result = asyncio.run(client.list_async(page=page, size=size))
        table = Table(title="Runtimes")
        table.add_column("ID", style="cyan")
        table.add_column("Name", style="magenta")
        table.add_column("Status", style="yellow")
        table.add_column("Created At", style="blue")
        if result.list_data:
            for rt in result.list_data:
                table.add_row(
                    rt.id or "",
                    rt.name or "",
                    rt.status or "",
                    str(rt.created_at) if getattr(rt, "created_at", None) else "",
                )
        console.print(table)
        if getattr(result, "total_page", None) is not None:
            console.print(
                f"\n[dim]Page {getattr(result, 'page', 1)} of {result.total_page} "
                f"(Total: {getattr(result, 'total_item', '')})[/dim]"
            )
    except Exception as e:
        console.print(f"[red]Error: Failed to list runtimes: {e}[/red]")
        raise click.Abort()


@runtime_group.command(name="get")
@click.argument("runtime-id", required=True)
def get_runtime(runtime_id: str) -> None:
    """Get a runtime by ID.

    Examples:
        \n
        # Get runtime\n
        greennode runtime get my-runtime-id
    """
    try:
        client = get_runtime_client()
        result = asyncio.run(client.get_async(id=runtime_id))
        if hasattr(result, "model_dump"):
            console.print(json.dumps(result.model_dump(by_alias=True), indent=2, default=str))
        elif isinstance(result, dict):
            console.print(json.dumps(result, indent=2, default=str))
        else:
            console.print(result)
    except Exception as e:
        console.print(f"[red]Error: Failed to get runtime: {e}[/red]")
        raise click.Abort()


def _parse_env_vars(env: List[str]) -> Dict[str, str]:
    """Parse KEY=value list into a dict."""
    out: Dict[str, str] = {}
    for item in env:
        if "=" in item:
            k, _, v = item.partition("=")
            out[k.strip()] = v.strip()
    return out


@runtime_group.command(name="patch")
@click.argument("runtime-id", required=True)
@click.option("--image-url", type=str, help="Image URL to set")
@click.option("--flavor-id", type=str, help="Flavor ID to set")
@click.option("--command", type=str, multiple=True, help="Command (repeat for multiple)")
@click.option("--args", "args_list", type=str, multiple=True, help="Args (repeat for multiple)")
@click.option("--env", "env_vars", type=str, multiple=True, help="Env var KEY=value (repeat for multiple)")
def patch_runtime(
    runtime_id: str,
    image_url: Optional[str],
    flavor_id: Optional[str],
    command: tuple,
    args_list: tuple,
    env_vars: tuple,
) -> None:
    """Update (patch) a runtime by ID.

    Examples:
        \n
        # Update image URL\n
        greennode runtime patch my-runtime-id --image-url my-registry/my-image:tag

        \n
        # Update flavor and env vars\n
        greennode runtime patch my-runtime-id --flavor-id new-flavor --env FOO=bar
    """
    try:
        client = get_runtime_client()
        body: Dict[str, Any] = {}
        if image_url is not None:
            body["imageUrl"] = image_url
        if flavor_id is not None:
            body["flavorId"] = flavor_id
        if command:
            body["command"] = list(command)
        if args_list:
            body["args"] = list(args_list)
        if env_vars:
            body["environmentVariables"] = _parse_env_vars(list(env_vars))
        if not body:
            console.print("[yellow]No updates specified. Use --image-url, --flavor-id, --command, --args, or --env.[/yellow]")
            return
        request = AgentRuntimeUpdateRequest(**body)
        result = asyncio.run(client.update_async(id=runtime_id, request=request))
        if hasattr(result, "model_dump"):
            console.print(json.dumps(result.model_dump(by_alias=True), indent=2, default=str))
        elif isinstance(result, dict):
            console.print(json.dumps(result, indent=2, default=str))
        else:
            console.print(result)
        console.print(f"[green]✓ Runtime {runtime_id} updated[/green]")
    except Exception as e:
        console.print(f"[red]Error: Failed to patch runtime: {e}[/red]")
        raise click.Abort()


# Endpoints subgroup
@runtime_group.group(name="endpoints")
def endpoints_group() -> None:
    """Manage runtime endpoints."""
    pass


@endpoints_group.command(name="list")
@click.argument("runtime-id", required=True)
@click.option("--page", "-p", type=int, default=1, help="Page number")
@click.option("--size", "-s", type=int, default=10, help="Page size")
def list_endpoints(runtime_id: str, page: int, size: int) -> None:
    """List endpoints for a runtime.

    Examples:
        \n
        greennode runtime endpoints list my-runtime-id
    """
    try:
        client = get_runtime_client()
        result = asyncio.run(client.listEndpoints_async(id=runtime_id, page=page, size=size))
        table = Table(title=f"Endpoints for runtime {runtime_id}")
        table.add_column("ID", style="cyan")
        table.add_column("Name", style="magenta")
        table.add_column("Version", style="yellow")
        table.add_column("URL", style="green")
        table.add_column("Status", style="blue")
        if result.list_data:
            for ep in result.list_data:
                table.add_row(
                    ep.id or "",
                    ep.name or "",
                    str(ep.version) if ep.version is not None else "",
                    ep.url or "",
                    ep.status or "",
                )
        console.print(table)
    except Exception as e:
        console.print(f"[red]Error: Failed to list endpoints: {e}[/red]")
        raise click.Abort()


@endpoints_group.command(name="create")
@click.argument("runtime-id", required=True)
@click.option("--name", "-n", required=True, help="Endpoint name")
@click.option("--version", "-v", type=int, help="Version (optional)")
def create_endpoint(runtime_id: str, name: str, version: Optional[int]) -> None:
    """Create an endpoint for a runtime.

    Examples:
        \n
        greennode runtime endpoints create my-runtime-id -n my-endpoint

        \n
        greennode runtime endpoints create my-runtime-id -n my-endpoint --version 1
    """
    try:
        client = get_runtime_client()
        request = AgentRuntimeEndpointCreateRequest(name=name, version=version)
        result = asyncio.run(client.createEndpoint_async(id=runtime_id, request=request))
        if hasattr(result, "id"):
            console.print(f"[green]✓ Endpoint created with id: {result.id}[/green]")
        else:
            out = result if isinstance(result, dict) else str(result)
            console.print(json.dumps(out, indent=2) if isinstance(out, dict) else out)
    except Exception as e:
        console.print(f"[red]Error: Failed to create endpoint: {e}[/red]")
        raise click.Abort()


@endpoints_group.command(name="delete")
@click.argument("runtime-id", required=True)
@click.argument("endpoint-id", required=True)
def delete_endpoint(runtime_id: str, endpoint_id: str) -> None:
    """Delete an endpoint.

    Examples:
        \n
        greennode runtime endpoints delete my-runtime-id my-endpoint-id
    """
    try:
        client = get_runtime_client()
        asyncio.run(client.deleteEndpoint_async(id=runtime_id, endpointId=endpoint_id))
        console.print(f"[green]✓ Endpoint {endpoint_id} deleted[/green]")
    except Exception as e:
        console.print(f"[red]Error: Failed to delete endpoint: {e}[/red]")
        raise click.Abort()


@endpoints_group.command(name="update")
@click.argument("runtime-id", required=True)
@click.argument("endpoint-id", required=True)
@click.option("--version", "-v", type=int, help="Version to set")
def update_endpoint(
    runtime_id: str,
    endpoint_id: str,
    version: Optional[int],
) -> None:
    """Update an endpoint (version).

    Examples:
        \n
        greennode runtime endpoints update my-runtime-id my-endpoint-id --version 2
    """
    try:
        if version is None:
            console.print("[yellow]No updates specified. Use --version.[/yellow]")
            return
        client = get_runtime_client()
        result = asyncio.run(
            client.updateEndpoint_async(
                id=runtime_id, endpointId=endpoint_id, version=version
            )
        )
        console.print(f"[green]✓ Endpoint {endpoint_id} updated[/green]")
        if result is not None:
            console.print(json.dumps(result if isinstance(result, dict) else str(result), indent=2))
    except Exception as e:
        console.print(f"[red]Error: Failed to update endpoint: {e}[/red]")
        raise click.Abort()
