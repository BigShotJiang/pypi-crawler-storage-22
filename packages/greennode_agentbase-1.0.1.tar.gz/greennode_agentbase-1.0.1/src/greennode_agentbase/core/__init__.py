"""Core engine for data-driven API clients."""

from .authenticated_client import AuthenticatedAPIClient
from .base import BaseAPIClient
from .http_client import HttpxClient, HTTPClientProtocol

__all__ = ["BaseAPIClient", "AuthenticatedAPIClient", "HttpxClient", "HTTPClientProtocol"]

