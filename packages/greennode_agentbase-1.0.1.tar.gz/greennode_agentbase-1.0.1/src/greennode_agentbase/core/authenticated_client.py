"""Authenticated API client base class for GreenNode AgentBase SDK.

Provides shared OAuth2 authentication logic for all service clients.
"""

import base64
import logging
import time
from typing import TYPE_CHECKING, Optional

try:
    import httpx
except ImportError:
    httpx = None  # type: ignore

from ..exceptions import GreenNodeConfigurationError, GreenNodeRequestError
from .base import BaseAPIClient
from .http_client import HttpxClient, HTTPClientProtocol

if TYPE_CHECKING:
    from ..identity.credentials import IAMCredentials

logger = logging.getLogger("greennode_agentbase.core")


class AuthenticatedAPIClient(BaseAPIClient):
    """Base class for authenticated API clients with OAuth2 support.

    This class provides shared OAuth2 authentication logic including:
    - Token caching and validation
    - OAuth2 token retrieval using IAM credentials
    - Automatic token refresh
    - HTTP client initialization

    Subclasses should set SERVICE_NAME and will automatically use their
    own spec's oauth2_token_url for authentication.

    Args:
        base_url: Base URL for the API (default: from spec)
        http_client: Optional HTTP client implementation (default: HttpxClient)
        iam_credentials: Optional IAM credentials for authentication. If not provided,
            will attempt to load from environment variables or config file.
        access_token: Optional OAuth2 access token for API authentication (backward
            compatibility). If IAM credentials are available, they will be preferred.
    """

    # Default token cache time: 55 minutes (tokens typically last 1 hour)
    DEFAULT_TOKEN_CACHE_TIME = 55 * 60  # seconds

    def __init__(
        self,
        base_url: Optional[str] = None,
        http_client: Optional[HTTPClientProtocol] = None,
        iam_credentials: Optional["IAMCredentials"] = None,
        access_token: Optional[str] = None,
    ) -> None:
        """Initialize the authenticated API client."""
        # Import here to avoid circular dependency
        from ..identity.credentials import IAMCredentials as IAMCredentialsImpl
        
        self.iam_credentials = iam_credentials or IAMCredentialsImpl()
        self.access_token = access_token

        # Token caching
        self._cached_token: Optional[str] = None
        self._token_expires_at: Optional[float] = None

        # Initialize base class first to load spec and get base_url
        super().__init__(
            service_name=self.SERVICE_NAME,
            base_url=base_url,
            http_client=None,  # Will set after we have base_url from spec
            ensure_authenticated=self._ensure_authenticated,
        )

        # Get oauth2_token_url from service's own spec and validate
        self._oauth2_token_url = self._spec.get("oauth2_token_url")
        if not self._oauth2_token_url:
            raise GreenNodeConfigurationError(
                f"oauth2_token_url not found in spec for service '{self.SERVICE_NAME}'"
            )

        # Create HTTP client if not provided
        if http_client is None:
            self._http_client = HttpxClient(
                base_url=self._base_url,
                access_token=self.access_token,
            )
        else:
            self._http_client = http_client

    def _is_token_valid(self) -> bool:
        """Check if the cached token is still valid.

        Returns:
            True if token exists and hasn't expired, False otherwise
        """
        if self._cached_token is None or self._token_expires_at is None:
            return False
        # Add 60 second buffer to avoid using tokens that are about to expire
        return time.time() < (self._token_expires_at - 60)

    async def _get_oauth2_token(self) -> str:
        """Get OAuth2 access token using IAM credentials with caching.

        Returns:
            OAuth2 access token string

        Raises:
            GreenNodeConfigurationError: If IAM credentials are incomplete
            GreenNodeRequestError: If the token request fails
        """
        # Return cached token if still valid
        if self._is_token_valid():
            return self._cached_token

        self.iam_credentials.require()

        access_key_id = self.iam_credentials.access_key_id
        secret_access_key = self.iam_credentials.secret_access_key

        if not access_key_id or not secret_access_key:
            raise GreenNodeConfigurationError("IAM credentials are incomplete")

        # Create basic auth header
        credentials = f"{access_key_id}:{secret_access_key}"
        encoded = base64.b64encode(credentials.encode()).decode()

        headers = {
            "Authorization": f"Basic {encoded}",
            "Content-Type": "application/x-www-form-urlencoded",
        }

        data = {"grant_type": "client_credentials"}

        # Use a temporary httpx client for OAuth2 token request
        if httpx is None:
            raise GreenNodeConfigurationError("httpx is required for OAuth2 authentication")

        async with httpx.AsyncClient() as client:
            try:
                response = await client.post(
                    self._oauth2_token_url,
                    headers=headers,
                    data=data,
                    timeout=30.0,
                )
                response.raise_for_status()
                token_data = response.json()
                token = token_data["access_token"]

                # Cache the token
                self._cached_token = token

                # Parse expiration time if available, otherwise use default cache time
                expires_in = token_data.get("expires_in")
                if expires_in and isinstance(expires_in, (int, float)):
                    # Use 90% of the actual expiration time to be safe
                    cache_time = int(expires_in * 0.9)
                else:
                    cache_time = self.DEFAULT_TOKEN_CACHE_TIME

                self._token_expires_at = time.time() + cache_time

                return token
            except httpx.HTTPStatusError as e:
                status_code = e.response.status_code
                try:
                    error_data = e.response.json()
                    error_msg = error_data.get("message", e.response.text)
                except Exception:
                    error_msg = e.response.text or str(e)

                raise GreenNodeRequestError(
                    f"OAuth2 token request failed (HTTP {status_code}): {error_msg}",
                    status_code=status_code,
                    cause=e,
                ) from e
            except httpx.RequestError as e:
                raise GreenNodeRequestError(
                    f"OAuth2 token request failed: {str(e)}",
                    cause=e,
                ) from e

    async def _ensure_authenticated(self) -> None:
        """Ensure the HTTP client is authenticated with a valid OAuth2 token.

        This method checks if IAM credentials are available and gets an OAuth2 token
        using client_credentials flow. If IAM credentials are not available but
        access_token was provided, it uses that instead (backward compatibility).

        Raises:
            GreenNodeConfigurationError: If neither IAM credentials nor access_token are available
        """
        # If IAM credentials are available, use them to get a token
        if self.iam_credentials.is_available():
            token = await self._get_oauth2_token()
            # Update HTTP client with the token
            if isinstance(self._http_client, HttpxClient):
                await self._http_client.update_access_token(token)
            return

        # Backward compatibility: if access_token was provided, use it
        if self.access_token:
            if isinstance(self._http_client, HttpxClient):
                await self._http_client.update_access_token(self.access_token)
            return

        # Neither IAM credentials nor access_token available
        raise GreenNodeConfigurationError(
            "Authentication required: Either IAM credentials (access_key_id and secret_access_key) "
            "or access_token must be provided. IAM credentials can be set via constructor, "
            "environment variables (GREENNODE_CLIENT_ID, GREENNODE_CLIENT_SECRET), "
            "or .greennode.json config file."
        )
